"""HTTP routes for the whitelist domain.

All endpoints live under the ``/v1/whitelist`` prefix and implement
the email whitelist management contract: check, add, bulk add, list,
update, stats, clear, and remove.

The response envelope ``{ success, data, error, metadata }`` is
applied automatically by ``ResponseEnvelopeMiddleware`` -- handlers
return the raw *data* portion only.
"""

from __future__ import annotations

import logging
from uuid import UUID

from fastapi import APIRouter, Query, Response

from ...middleware.spaps_deps import Application, CurrentUser, DbSession
from . import service
from .schemas import (
    AddWhitelistRequest,
    AddWhitelistResponse,
    BulkAddWhitelistRequest,
    BulkAddWhitelistResponse,
    CheckWhitelistResponse,
    ClearWhitelistResponse,
    ListWhitelistResponse,
    RemoveWhitelistResponse,
    StatsResponse,
    TierType,
    UpdateWhitelistRequest,
    UpdateWhitelistResponse,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/v1/whitelist", tags=["whitelist"])


# ---------------------------------------------------------------------------
# Public endpoints (API-key authentication only)
# ---------------------------------------------------------------------------


@router.get("/check", response_model=CheckWhitelistResponse)
async def check_whitelist(
    db: DbSession,
    app: Application,
    email: str = Query(..., description="Email address to check"),
) -> CheckWhitelistResponse:
    """Check if an email is on the application whitelist.

    No JWT required -- only API key authentication.
    """
    # Validate email format (basic check)
    from ..errors import ValidationError as DomainValidationError

    if not email or "@" not in email:
        raise DomainValidationError("Invalid email format")

    result = await service.check_whitelist(
        db,
        application_id=app.id,
        email=email,
    )
    return CheckWhitelistResponse(**result)


# ---------------------------------------------------------------------------
# Authenticated endpoints (API key + JWT)
# ---------------------------------------------------------------------------


@router.post("", response_model=AddWhitelistResponse, status_code=201)
async def add_to_whitelist(
    body: AddWhitelistRequest,
    db: DbSession,
    app: Application,
    user: CurrentUser,
) -> AddWhitelistResponse:
    """Add an email to the application whitelist."""
    result = await service.add_to_whitelist(
        db,
        application_id=app.id,
        email=body.email,
        tier=body.tier,
        bypass_payment=body.bypass_payment,
        metadata=body.metadata,
        created_by=UUID(user.id) if isinstance(user.id, str) else user.id,
    )
    return AddWhitelistResponse(**result)


@router.post("/bulk", status_code=201)
async def bulk_add_to_whitelist(
    body: BulkAddWhitelistRequest,
    response: Response,
    db: DbSession,
    app: Application,
    user: CurrentUser,
) -> BulkAddWhitelistResponse:
    """Bulk-add emails to the application whitelist.

    Returns 201 if all succeed, 207 Multi-Status if some fail.
    """
    entries = [
        {
            "email": e.email,
            "tier": e.tier,
            "metadata": e.metadata,
        }
        for e in body.emails
    ]

    result = await service.bulk_add(
        db,
        application_id=app.id,
        entries=entries,
        created_by=UUID(user.id) if isinstance(user.id, str) else user.id,
    )

    # Set 207 Multi-Status if there are any failures
    if result["failed"]:
        response.status_code = 207

    return BulkAddWhitelistResponse(**result)


@router.get("", response_model=ListWhitelistResponse)
async def list_whitelist(
    db: DbSession,
    app: Application,
    user: CurrentUser,
    limit: int = Query(default=10, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    tier: TierType | None = Query(default=None),
) -> ListWhitelistResponse:
    """List all whitelist entries for the application."""
    result = await service.list_whitelist(
        db,
        application_id=app.id,
        limit=limit,
        offset=offset,
        tier=tier,
    )
    return ListWhitelistResponse(**result)


@router.put("/{email}", response_model=UpdateWhitelistResponse)
async def update_whitelist_entry(
    email: str,
    body: UpdateWhitelistRequest,
    db: DbSession,
    app: Application,
    user: CurrentUser,
) -> UpdateWhitelistResponse:
    """Update a whitelist entry by email address."""
    result = await service.update_entry(
        db,
        application_id=app.id,
        email=email,
        tier=body.tier,
        bypass_payment=body.bypass_payment,
        metadata=body.metadata,
    )
    return UpdateWhitelistResponse(**result)


@router.get("/stats", response_model=StatsResponse)
async def get_whitelist_stats(
    db: DbSession,
    app: Application,
    user: CurrentUser,
) -> StatsResponse:
    """Get whitelist statistics for the application."""
    whitelist_enabled = getattr(app, "whitelist_enabled", False)
    result = await service.get_stats(
        db,
        application_id=app.id,
        whitelist_enabled=whitelist_enabled,
    )
    return StatsResponse(**result)


@router.delete("/all", response_model=ClearWhitelistResponse)
async def clear_whitelist(
    db: DbSession,
    app: Application,
    user: CurrentUser,
) -> ClearWhitelistResponse:
    """Remove all whitelist entries for the application."""
    result = await service.clear_whitelist(
        db,
        application_id=app.id,
    )
    return ClearWhitelistResponse(**result)


@router.delete("/{email}", response_model=RemoveWhitelistResponse)
async def remove_from_whitelist(
    email: str,
    db: DbSession,
    app: Application,
    user: CurrentUser,
) -> RemoveWhitelistResponse:
    """Remove a single email from the whitelist."""
    result = await service.remove_from_whitelist(
        db,
        application_id=app.id,
        email=email,
    )
    return RemoveWhitelistResponse(**result)
