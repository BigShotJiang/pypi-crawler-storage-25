"""
SPAPS domain layer.

Each domain is a self-contained folder with models, schemas, service,
repository, and router. This subpackage has **zero FastAPI imports** —
pure SQLAlchemy + Pydantic. Routers live in api/domains/ and bridge
the domain layer to HTTP.
"""
