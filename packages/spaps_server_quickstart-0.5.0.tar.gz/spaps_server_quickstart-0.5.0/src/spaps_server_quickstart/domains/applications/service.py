"""Business logic for the applications domain.

Orchestrates repository calls, raises domain errors on invariant
violations, and provides validation helpers consumed by the API-key
middleware.

Pure async — no FastAPI imports.
"""

from __future__ import annotations

import hashlib
import logging
import secrets
from typing import Any, Literal

from sqlalchemy.ext.asyncio import AsyncSession

from ..errors import DomainError, InvalidApplicationError, NotFoundError, ValidationError
from . import repository as repo
from .models import Application

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Key generation helpers
# ---------------------------------------------------------------------------


def generate_api_key() -> str:
    """Generate a legacy API key prefixed with ``spaps_``."""
    return "spaps_" + secrets.token_hex(32)


def generate_publishable_key() -> str:
    """Generate a publishable key prefixed with ``spaps_pub_``."""
    return "spaps_pub_" + secrets.token_hex(32)


def generate_secret_key() -> str:
    """Generate a secret key prefixed with ``spaps_sec_``."""
    return "spaps_sec_" + secrets.token_hex(32)


def hash_key(key: str) -> str:
    """SHA-256 hash a key for storage."""
    return hashlib.sha256(key.encode("utf-8")).hexdigest()


# Default settings applied to newly created applications.
DEFAULT_APP_SETTINGS: dict[str, Any] = {
    "supported_chains": ["solana", "ethereum"],
    "allow_email_auth": True,
    "allow_wallet_auth": True,
    "allow_magic_link": True,
    "stripe_enabled": False,
    "rate_limit": {
        "window_ms": 900000,
        "max_requests": 100,
    },
}


# ---------------------------------------------------------------------------
# Existing service functions
# ---------------------------------------------------------------------------


async def get_application(db: AsyncSession, app_id: str) -> Application:
    """Return an application by ID or raise ``NotFoundError``."""
    app = await repo.get_application_by_id(db, app_id)
    if app is None:
        raise NotFoundError(f"Application {app_id} not found")
    return app


async def validate_api_key(db: AsyncSession, api_key: str) -> Application:
    """Validate a legacy API key and return the owning application.

    Raises ``InvalidApplicationError`` when the key does not match
    any registered application.
    """
    app = await repo.get_application_by_api_key(db, api_key)
    if app is None:
        raise InvalidApplicationError("Invalid API key")
    return app


async def validate_publishable_key(
    db: AsyncSession,
    key_hash: str,
) -> Application:
    """Validate a publishable key hash and return the owning application.

    Raises ``InvalidApplicationError`` when the hash does not match
    any registered application.
    """
    app = await repo.get_application_by_publishable_key_hash(db, key_hash)
    if app is None:
        raise InvalidApplicationError("Invalid publishable key")
    return app


async def validate_secret_key(
    db: AsyncSession,
    key_hash: str,
) -> Application:
    """Validate a secret key hash and return the owning application.

    Raises ``InvalidApplicationError`` when the hash does not match
    any registered application.
    """
    app = await repo.get_application_by_secret_key_hash(db, key_hash)
    if app is None:
        raise InvalidApplicationError("Invalid secret key")
    return app


# ---------------------------------------------------------------------------
# Admin CRUD operations
# ---------------------------------------------------------------------------


async def create_application_with_keys(
    db: AsyncSession,
    *,
    name: str,
    slug: str,
    description: str | None = None,
    webhook_url: str | None = None,
    allowed_origins: list[str] | None = None,
    settings: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Create a new application with generated publishable, secret, and legacy keys.

    Returns a dict containing the ``application`` model instance, the
    raw ``api_key`` (secret key) for the caller to display once, and a
    ``warning`` string.

    Raises ``ValidationError`` if name/slug are missing or a duplicate
    exists.  Raises ``DomainError`` (status 500) on unexpected failures.
    """
    if not name or not slug:
        raise ValidationError("name and slug are required")

    # Duplicate checks
    existing_name = await repo.get_application_by_name(db, name)
    if existing_name is not None:
        raise ValidationError(f"Application with name '{name}' already exists")

    existing_slug = await repo.get_application_by_slug(db, slug)
    if existing_slug is not None:
        raise ValidationError(f"Application with slug '{slug}' already exists")

    # Generate keys
    pub_key = generate_publishable_key()
    sec_key = generate_secret_key()
    generate_api_key()  # legacy key generation (kept for side-effect compat)

    # Merge caller-provided settings over the defaults
    merged_settings = {**DEFAULT_APP_SETTINGS, **(settings or {})}

    try:
        app = await repo.create_application(
            db,
            name=name,
            # Store the secret key hash in the legacy api_key column for
            # backward compatibility (matching TypeScript behaviour).
            api_key=hash_key(sec_key),
            slug=slug,
            description=description,
            webhook_url=webhook_url,
            allowed_origins=allowed_origins,
            settings=merged_settings,
            publishable_key_hash=hash_key(pub_key),
            secret_key_hash=hash_key(sec_key),
        )
    except Exception as exc:
        logger.exception("Failed to create application: %s", exc)
        raise DomainError(
            code="APPLICATION_CREATION_FAILED",
            message="Failed to create application",
            status_code=500,
        ) from exc

    return {
        "application": app,
        "api_key": sec_key,
        "warning": "Store this API key securely. It will not be shown again.",
    }


async def rotate_api_key(
    db: AsyncSession,
    app_id: str,
) -> dict[str, str]:
    """Generate a new legacy API key for an application.

    Returns a dict with the new ``api_key`` and a ``warning``.
    Raises ``NotFoundError`` if the application does not exist,
    ``DomainError`` (500) on failure.
    """
    app = await repo.get_application_by_id(db, app_id)
    if app is None:
        raise NotFoundError(f"Application {app_id} not found")

    new_key = generate_api_key()

    try:
        await repo.update_application(db, app_id, api_key=hash_key(new_key))
    except Exception as exc:
        logger.exception("Failed to rotate API key for %s: %s", app_id, exc)
        raise DomainError(
            code="API_KEY_ROTATION_FAILED",
            message="Failed to rotate API key",
            status_code=500,
        ) from exc

    return {
        "api_key": new_key,
        "warning": "Store this new API key securely. The old key is now invalid.",
    }


async def rotate_typed_key(
    db: AsyncSession,
    app_id: str,
    key_type: Literal["publishable", "secret"],
) -> dict[str, str]:
    """Generate a new publishable or secret key for an application.

    Returns a dict with the new ``key`` and a ``warning``.
    """
    app = await repo.get_application_by_id(db, app_id)
    if app is None:
        raise NotFoundError(f"Application {app_id} not found")

    if key_type == "publishable":
        new_key = generate_publishable_key()
        column = "publishable_key_hash"
    else:
        new_key = generate_secret_key()
        column = "secret_key_hash"

    try:
        await repo.update_application(db, app_id, **{column: hash_key(new_key)})
    except Exception as exc:
        logger.exception("Failed to rotate %s key for %s: %s", key_type, app_id, exc)
        raise DomainError(
            code="API_KEY_ROTATION_FAILED",
            message=f"Failed to rotate {key_type} key",
            status_code=500,
        ) from exc

    return {
        "key": new_key,
        "warning": f"Store this new {key_type} key securely. The old key is now invalid.",
    }


async def delete_application(
    db: AsyncSession,
    app_id: str,
) -> bool:
    """Delete an application by ID.

    Returns ``True`` on success.  Raises ``NotFoundError`` if the
    application does not exist.
    """
    deleted = await repo.delete_application(db, app_id)
    if not deleted:
        raise NotFoundError(f"Application {app_id} not found")
    return True
