"""Pydantic request/response schemas for the applications domain.

Used internally by middleware for API-key resolution — not directly
exposed as a user-facing API endpoint in Phase 1.

Zero FastAPI imports.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel


class ApplicationInfo(BaseModel):
    """Read-only projection of an application record.

    Used by auth middleware to attach resolved app context to the
    request without leaking sensitive fields (api_key hashes, etc.).
    """

    id: str
    name: str
    slug: str
    description: str | None = None
    webhook_url: str | None = None
    allowed_origins: list[str] | None = None
    settings: dict | None = None
    whitelist_enabled: bool = False


# ---------------------------------------------------------------------------
# Admin: Create Application
# ---------------------------------------------------------------------------

class CreateAppRequest(BaseModel):
    """Request body for ``POST /admin/create-app``."""

    name: str
    slug: str
    description: str | None = None
    webhook_url: str | None = None
    allowed_origins: list[str] | None = None
    settings: dict[str, Any] | None = None


class CreateAppApplicationOut(BaseModel):
    """Application projection returned after creation."""

    id: str
    name: str
    slug: str
    description: str | None = None
    webhook_url: str | None = None
    allowed_origins: list[str] | None = None
    settings: dict[str, Any] | None = None
    created_at: datetime


class CreateAppResponse(BaseModel):
    """Response for ``POST /admin/create-app``."""

    application: CreateAppApplicationOut
    api_key: str
    warning: str


# ---------------------------------------------------------------------------
# Admin: Rotate API Key
# ---------------------------------------------------------------------------


class RotateApiKeyResponse(BaseModel):
    """Response for ``POST /admin/rotate-api-key/{app_id}``."""

    api_key: str
    warning: str


# ---------------------------------------------------------------------------
# Admin: List Apps (self only)
# ---------------------------------------------------------------------------


class ListAppsResponse(BaseModel):
    """Response for ``GET /admin/apps``."""

    application: ApplicationInfo
    note: str


# ---------------------------------------------------------------------------
# Admin: Stripe webhook stubs
# ---------------------------------------------------------------------------


class StripeWebhookValidateResponse(BaseModel):
    """Stub response for ``GET /admin/stripe/webhooks/validate``."""

    valid: bool
    configured: list[str]
    missing: list[str]
    endpoints: list[str]
    required_events: list[str]
    note: str


class StripeWebhooksResponse(BaseModel):
    """Stub response for ``GET /admin/stripe/webhooks``."""

    endpoints: list[str]
    count: int
