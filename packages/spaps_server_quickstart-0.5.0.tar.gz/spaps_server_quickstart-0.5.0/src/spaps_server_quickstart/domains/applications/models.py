"""SQLAlchemy models for the applications domain."""

from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID, uuid4

from sqlalchemy import (
    ARRAY,
    Boolean,
    DateTime,
    Integer,
    Text,
    func,
)
from sqlalchemy.dialects.postgresql import JSON
from sqlalchemy.orm import Mapped, mapped_column

from .._db import Base, PGUUID


class Application(Base):
    """Client application registry.

    Each application gets a unique API key and can configure origins,
    webhooks, and whitelist behaviour.
    """

    __tablename__ = "applications"

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    name: Mapped[str] = mapped_column(Text, nullable=False)
    slug: Mapped[str] = mapped_column(Text, unique=True, nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    api_key: Mapped[str] = mapped_column(Text, unique=True, nullable=False)
    allowed_origins: Mapped[list[str] | None] = mapped_column(
        ARRAY(Text), nullable=True
    )
    webhook_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    settings: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)
    whitelist_enabled: Mapped[bool] = mapped_column(
        Boolean, server_default="false", default=False
    )
    whitelist_count: Mapped[int] = mapped_column(
        Integer, server_default="0", default=0
    )
    publishable_key_hash: Mapped[str | None] = mapped_column(Text, nullable=True)
    secret_key_hash: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    def __repr__(self) -> str:
        return f"<Application slug={self.slug!r}>"
