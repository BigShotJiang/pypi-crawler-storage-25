"""Applications domain — models, repository, service, and admin router."""

from .models import Application
from .router import router

__all__ = ["Application", "router"]
