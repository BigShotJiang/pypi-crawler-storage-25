"""SQLAlchemy models for the wallets domain."""

from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID, uuid4

from sqlalchemy import (
    Boolean,
    DateTime,
    ForeignKey,
    Index,
    Text,
    func,
)
from sqlalchemy.dialects.postgresql import JSON
from sqlalchemy.orm import Mapped, mapped_column

from .._db import Base, PGUUID


class UserWallet(Base):
    """Wallet address bound to a user.

    Supports multiple chains (Solana, Ethereum, Bitcoin, Base) and
    tracks which wallet is the user's primary.
    """

    __tablename__ = "user_wallets"
    __table_args__ = (
        Index("idx_user_wallets_user_id", "user_id"),
        Index("idx_user_wallets_wallet_address", "wallet_address"),
        Index("idx_user_wallets_chain_type", "chain_type"),
    )

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    user_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
    )
    wallet_address: Mapped[str] = mapped_column(Text, nullable=False)
    chain_type: Mapped[str] = mapped_column(Text, nullable=False)
    is_primary: Mapped[bool] = mapped_column(
        Boolean, server_default="false", default=False
    )
    verified_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    metadata_: Mapped[dict[str, Any] | None] = mapped_column(
        "metadata", JSON, nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    def __repr__(self) -> str:
        return (
            f"<UserWallet chain={self.chain_type!r} "
            f"address={self.wallet_address!r}>"
        )
