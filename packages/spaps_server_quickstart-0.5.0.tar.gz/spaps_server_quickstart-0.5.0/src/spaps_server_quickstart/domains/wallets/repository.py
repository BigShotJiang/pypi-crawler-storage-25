"""Database operations for the wallets domain.

All async functions accept an ``AsyncSession`` as their first parameter
so the caller controls the transaction boundary.

This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from sqlalchemy import delete, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from .models import UserWallet
from ..users.models import User

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Single-wallet lookups
# ---------------------------------------------------------------------------


async def get_wallet_by_address(
    session: AsyncSession,
    wallet_address: str,
    chain_type: str | None = None,
) -> UserWallet | None:
    """Look up a wallet by its on-chain address.

    If *chain_type* is provided the lookup is scoped to that chain;
    otherwise the first match across all chains is returned.
    """

    stmt = select(UserWallet).where(
        UserWallet.wallet_address == wallet_address,
    )
    if chain_type is not None:
        stmt = stmt.where(UserWallet.chain_type == chain_type)

    result = await session.execute(stmt)
    return result.scalar_one_or_none()


async def get_wallet_with_user(
    session: AsyncSession,
    wallet_address: str,
    chain_type: str,
) -> tuple[UserWallet | None, Any]:
    """Look up a wallet and eagerly load the owning user.

    Returns ``(wallet, user)``; both are ``None`` when the wallet does
    not exist.
    """

    wallet = await get_wallet_by_address(session, wallet_address, chain_type)
    if wallet is None:
        return None, None

    user_result = await session.execute(
        select(User).where(User.id == wallet.user_id)
    )
    user = user_result.scalar_one_or_none()
    return wallet, user


# ---------------------------------------------------------------------------
# Multi-wallet queries
# ---------------------------------------------------------------------------


async def get_wallets_for_user(
    session: AsyncSession,
    user_id: str,
    chain_type: str | None = None,
) -> list[UserWallet]:
    """Return all wallets belonging to *user_id*, optionally filtered by chain."""

    stmt = select(UserWallet).where(UserWallet.user_id == UUID(user_id))
    if chain_type is not None:
        stmt = stmt.where(UserWallet.chain_type == chain_type)
    stmt = stmt.order_by(UserWallet.created_at.desc())

    result = await session.execute(stmt)
    return list(result.scalars().all())


# ---------------------------------------------------------------------------
# Existence check
# ---------------------------------------------------------------------------


async def wallet_exists(
    session: AsyncSession,
    wallet_address: str,
    chain_type: str,
) -> bool:
    """Return ``True`` if a wallet record exists for the given address + chain."""

    stmt = select(UserWallet.id).where(
        UserWallet.wallet_address == wallet_address,
        UserWallet.chain_type == chain_type,
    )
    result = await session.execute(stmt)
    return result.scalar_one_or_none() is not None


# ---------------------------------------------------------------------------
# Mutations
# ---------------------------------------------------------------------------


async def create_wallet(
    session: AsyncSession,
    user_id: str,
    wallet_address: str,
    chain_type: str,
    is_primary: bool = False,
) -> UserWallet:
    """Create a new wallet record and flush to assign the ID.

    The caller is responsible for committing the transaction.
    """

    wallet = UserWallet(
        user_id=UUID(user_id),
        wallet_address=wallet_address,
        chain_type=chain_type,
        is_primary=is_primary,
        verified_at=datetime.now(UTC),
    )
    session.add(wallet)
    await session.flush()
    await session.refresh(wallet)

    logger.info(
        "Wallet created",
        extra={
            "user_id": user_id,
            "wallet_address": wallet_address,
            "chain_type": chain_type,
        },
    )
    return wallet


async def update_wallet(
    session: AsyncSession,
    wallet_id: str,
    **kwargs: Any,
) -> UserWallet | None:
    """Update arbitrary fields on a wallet record.

    Returns the refreshed wallet, or ``None`` if *wallet_id* was not found.
    """

    stmt = select(UserWallet).where(UserWallet.id == UUID(wallet_id))
    result = await session.execute(stmt)
    wallet = result.scalar_one_or_none()
    if wallet is None:
        return None

    for field, value in kwargs.items():
        if hasattr(wallet, field):
            setattr(wallet, field, value)

    wallet.updated_at = datetime.now(UTC)
    await session.flush()
    await session.refresh(wallet)
    return wallet


async def set_primary_wallet(
    session: AsyncSession,
    user_id: str,
    wallet_id: str,
) -> bool:
    """Designate *wallet_id* as the user's primary wallet.

    Unsets ``is_primary`` on all other wallets for the user first.
    Returns ``True`` on success, ``False`` if the wallet was not found
    or does not belong to *user_id*.
    """

    uid = UUID(user_id)
    wid = UUID(wallet_id)

    # Verify wallet belongs to user
    stmt = select(UserWallet).where(
        UserWallet.id == wid,
        UserWallet.user_id == uid,
    )
    result = await session.execute(stmt)
    target = result.scalar_one_or_none()
    if target is None:
        return False

    now = datetime.now(UTC)

    # Unset all existing primaries for this user
    await session.execute(
        update(UserWallet)
        .where(UserWallet.user_id == uid, UserWallet.is_primary.is_(True))
        .values(is_primary=False, updated_at=now)
    )

    # Set the target wallet as primary
    target.is_primary = True
    target.updated_at = now
    await session.flush()

    logger.info(
        "Primary wallet updated",
        extra={"user_id": user_id, "wallet_id": wallet_id},
    )
    return True


async def delete_wallet(
    session: AsyncSession,
    wallet_id: str,
) -> bool:
    """Delete a wallet by ID.

    Returns ``True`` if a row was deleted, ``False`` if not found.
    """

    stmt = delete(UserWallet).where(UserWallet.id == UUID(wallet_id))
    result = await session.execute(stmt)
    deleted = result.rowcount > 0  # type: ignore[attr-defined]

    if deleted:
        logger.info("Wallet deleted", extra={"wallet_id": wallet_id})

    return deleted
