"""Business logic for the wallets domain.

Orchestrates wallet repository operations with chain-specific signature
verification, nonce management, JWT session creation, and admin role
detection.

This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import logging
import re
from datetime import UTC, datetime
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from . import repository
from .chains import verify_wallet_signature
from .chains.ethereum import verify_typed_data_signature as _verify_typed_data
from ..errors import (
    InvalidMessageFormatError,
    InvalidSignatureError,
    NotFoundError,
    ValidationError,
)
from ..sessions.admin_detection import get_admin_permissions, get_user_roles
from ..sessions.jwt_service import generate_token_pair
from ..sessions.nonce_service import (
    create_auth_message,
    generate_nonce,
    store_nonce,
    validate_nonce,
)
from ..users import repository as user_repo
from ..users.models import User

logger = logging.getLogger(__name__)

# Regex to extract the nonce from a SIWE-style signed message.
_NONCE_RE = re.compile(r"Nonce:\s*([a-fA-F0-9]+)")


def _extract_nonce_from_message(message: str) -> str:
    """Extract the hex nonce from a SIWE-style signed message.

    Raises :class:`InvalidMessageFormatError` if no nonce is found.
    """
    match = _NONCE_RE.search(message)
    if not match:
        raise InvalidMessageFormatError("No nonce found in signed message")
    return match.group(1)


# ---------------------------------------------------------------------------
# Serialisation helpers
# ---------------------------------------------------------------------------


def _wallet_to_dict(wallet: Any) -> dict[str, Any]:
    """Convert a ``UserWallet`` instance to a JSON-serialisable dict."""

    return {
        "id": str(wallet.id),
        "wallet_address": wallet.wallet_address,
        "chain_type": wallet.chain_type,
        "is_primary": wallet.is_primary,
        "verified_at": (
            wallet.verified_at.isoformat() if wallet.verified_at else None
        ),
        "created_at": wallet.created_at.isoformat(),
    }


def _user_to_dict(
    user: Any,
    *,
    roles: list[str] | None = None,
) -> dict[str, Any]:
    """Convert a ``User`` instance to a JSON-serialisable dict."""

    _roles = roles or ["user"]
    return {
        "id": str(user.id),
        "email": user.email,
        "username": getattr(user, "username", None),
        "tier": getattr(user, "tier", None) or "basic",
        "roles": _roles,
        "is_admin": "admin" in _roles,
        "is_super_admin": "super_admin" in _roles,
    }


# ---------------------------------------------------------------------------
# Sign-in / linking
# ---------------------------------------------------------------------------


async def verify_and_sign_in(
    session: AsyncSession,
    wallet_address: str,
    signature: str,
    message: str,
    chain_type: str,
    *,
    application_id: str | None = None,
    access_secret: str,
    refresh_secret: str,
    access_expires_in: str = "1h",
    refresh_expires_in: str = "365d",
) -> dict[str, Any]:
    """Verify a wallet signature and create or resume a session.

    Workflow:
        1. Verify signature via the chain dispatcher.
        2. Find existing wallet or create a new user + wallet.
        3. Detect admin roles and permissions.
        4. Generate a JWT token pair.
        5. Return ``{user, wallet, session}`` dict.

    Args:
        session: Active SQLAlchemy async session.
        wallet_address: The wallet address that signed *message*.
        signature: The encoded signature.
        message: The original signed message.
        chain_type: Blockchain identifier (``solana``, ``ethereum``, etc.).
        application_id: Optional originating application ID.
        access_secret: HMAC secret for access token signing.
        refresh_secret: HMAC secret for refresh token signing.
        access_expires_in: Access token duration (default ``"1h"``).
        refresh_expires_in: Refresh token duration (default ``"365d"``).

    Returns:
        Dict with ``user``, ``wallet``, and ``session`` keys.

    Raises:
        InvalidSignatureError: If the signature is invalid.
    """

    # 1. Verify signature
    result = verify_wallet_signature(wallet_address, signature, message, chain_type)
    if not result.get("valid"):
        raise InvalidSignatureError(
            result.get("error", "Wallet signature verification failed")
        )

    # 1b. Extract and validate nonce to prevent replay attacks
    nonce = _extract_nonce_from_message(message)
    await validate_nonce(session, wallet_address, nonce)

    # 2. Find existing wallet or create new user + wallet
    wallet, user = await repository.get_wallet_with_user(
        session, wallet_address, chain_type,
    )

    if wallet is None:
        # Create a new user (bare minimum -- no email or password)
        user = User()
        session.add(user)
        await session.flush()
        await session.refresh(user)

        # Create the wallet linked to the new user
        wallet = await repository.create_wallet(
            session,
            user_id=str(user.id),
            wallet_address=wallet_address,
            chain_type=chain_type,
            is_primary=True,
        )

        logger.info(
            "New user created via wallet sign-in",
            extra={
                "user_id": str(user.id),
                "wallet_address": wallet_address,
                "chain_type": chain_type,
            },
        )
    else:
        # Update last sign-in timestamp on the existing user
        user.last_sign_in_at = datetime.now(UTC)
        await session.flush()

    # 3. Detect admin roles and permissions
    wallet_addresses = [wallet_address]
    roles = get_user_roles(
        email=user.email,
        user_id=str(user.id),
        wallet_addresses=wallet_addresses,
    )
    permissions = get_admin_permissions(roles)
    is_admin = "admin" in roles
    is_super_admin = "super_admin" in roles

    # 4. Generate JWT token pair
    app_id = application_id or "default"
    token_pair = generate_token_pair(
        user_id=str(user.id),
        application_id=app_id,
        email=user.email,
        wallets=wallet_addresses,
        tier=user.tier or "basic",
        roles=roles,
        permissions=permissions,
        is_admin=is_admin,
        is_super_admin=is_super_admin,
        access_secret=access_secret,
        refresh_secret=refresh_secret,
        access_expires_in=access_expires_in,
        refresh_expires_in=refresh_expires_in,
    )

    await session.flush()

    # 5. Return result
    return {
        "user": _user_to_dict(user, roles=roles),
        "wallet": _wallet_to_dict(wallet),
        "session": {
            "access_token": token_pair.access_token,
            "refresh_token": token_pair.refresh_token,
            "expires_in": token_pair.expires_in,
            "token_type": token_pair.token_type,
        },
    }


async def link_wallet_to_user(
    session: AsyncSession,
    user_id: str,
    wallet_address: str,
    signature: str,
    message: str,
    chain_type: str,
) -> dict[str, Any]:
    """Link a new wallet to an existing authenticated user.

    Workflow:
        1. Verify signature.
        2. Check wallet not already linked to another user.
        3. Create wallet record.
        4. Return ``{user, wallet}`` dict.

    Raises:
        InvalidSignatureError: If the signature is invalid.
        ValidationError: If the wallet is already linked.
    """

    # 1. Verify signature
    result = verify_wallet_signature(wallet_address, signature, message, chain_type)
    if not result.get("valid"):
        raise InvalidSignatureError(
            result.get("error", "Wallet signature verification failed")
        )

    # 2. Check wallet not already linked to another user
    existing = await repository.get_wallet_by_address(
        session, wallet_address, chain_type,
    )
    if existing is not None:
        if str(existing.user_id) == user_id:
            raise ValidationError("Wallet is already linked to your account")
        raise ValidationError("Wallet is already linked to another user")

    # 3. Create wallet record
    wallet = await repository.create_wallet(
        session,
        user_id=user_id,
        wallet_address=wallet_address,
        chain_type=chain_type,
        is_primary=False,
    )

    # Look up user for response
    user = await user_repo.get_user_by_id(session, user_id)

    await session.flush()

    return {
        "user": _user_to_dict(user) if user else {"id": user_id},
        "wallet": _wallet_to_dict(wallet),
    }


# ---------------------------------------------------------------------------
# Pure signature verification (no DB)
# ---------------------------------------------------------------------------


def verify_signature(
    wallet_address: str,
    signature: str,
    message: str,
    chain_type: str,
) -> dict[str, Any]:
    """Pure signature verification -- no database access required.

    Delegates to the chain-agnostic dispatcher.

    Returns:
        Dict with ``valid``, ``wallet_address``, and ``timestamp``.
    """

    result = verify_wallet_signature(wallet_address, signature, message, chain_type)
    return {
        "valid": result.get("valid", False),
        "wallet_address": wallet_address,
        "timestamp": datetime.now(UTC).isoformat(),
    }


def verify_typed_data(
    wallet_address: str,
    signature: str,
    domain: dict[str, Any],
    types: dict[str, Any],
    value: dict[str, Any],
) -> dict[str, Any]:
    """Verify an Ethereum EIP-712 typed-data signature.

    Delegates to :func:`verify_typed_data_signature` from the Ethereum
    chain module.  No database access required.

    Returns:
        Dict with ``valid``, ``wallet_address``, ``signature_type``,
        ``domain``, and ``timestamp``.
    """

    result = _verify_typed_data(wallet_address, signature, domain, types, value)
    return {
        "valid": result.get("valid", False),
        "wallet_address": result.get("wallet_address", wallet_address),
        "signature_type": result.get("signature_type", "EIP-712"),
        "domain": domain,
        "timestamp": result.get("timestamp", datetime.now(UTC).isoformat()),
    }


# ---------------------------------------------------------------------------
# Nonce / message generation
# ---------------------------------------------------------------------------


async def generate_auth_message_for_wallet(
    session: AsyncSession,
    wallet_address: str,
    chain_type: str,
    *,
    nonce: str | None = None,
) -> dict[str, Any]:
    """Generate a nonce-bearing message for the wallet to sign.

    If *nonce* is provided by the caller it is used directly; otherwise
    a fresh cryptographic nonce is generated.  Either way the nonce is
    stored in the database for later validation.

    Returns:
        Dict with ``message``, ``wallet_address``, and ``timestamp``.
    """

    if nonce is None:
        nonce = generate_nonce()
    message = create_auth_message(wallet_address, nonce)
    await store_nonce(session, wallet_address, nonce)
    await session.flush()

    return {
        "message": message,
        "wallet_address": wallet_address,
        "timestamp": datetime.now(UTC).isoformat(),
    }


async def generate_typed_data_message(
    session: AsyncSession,
    wallet_address: str,
) -> dict[str, Any]:
    """Generate EIP-712 typed data for Ethereum wallet signing.

    Creates a structured authentication message with a nonce and stores
    the nonce in the database for later validation.

    Returns:
        Dict with typed data fields (``domain``, ``types``, ``primaryType``,
        ``message``), plus ``wallet_address``, ``signature_type``, and
        ``timestamp``.
    """

    nonce = generate_nonce()
    timestamp = datetime.now(UTC).isoformat()

    await store_nonce(session, wallet_address, nonce)
    await session.flush()

    domain = {
        "name": "SPAPS",
        "version": "1",
        "chainId": 1,
    }
    types = {
        "Authentication": [
            {"name": "wallet", "type": "address"},
            {"name": "nonce", "type": "string"},
            {"name": "timestamp", "type": "string"},
        ],
    }
    message_data = {
        "wallet": wallet_address,
        "nonce": nonce,
        "timestamp": timestamp,
    }

    return {
        "domain": domain,
        "types": types,
        "primaryType": "Authentication",
        "message": message_data,
        "wallet_address": wallet_address,
        "signature_type": "EIP-712",
        "timestamp": timestamp,
    }


# ---------------------------------------------------------------------------
# Wallet queries
# ---------------------------------------------------------------------------


async def get_user_wallets(
    session: AsyncSession,
    user_id: str,
    chain_type: str | None = None,
) -> dict[str, Any]:
    """Return all wallets for a user, optionally filtered by chain.

    Returns:
        Dict with ``wallets`` list and ``count``.
    """

    wallets = await repository.get_wallets_for_user(
        session, user_id, chain_type,
    )
    return {
        "wallets": [_wallet_to_dict(w) for w in wallets],
        "count": len(wallets),
    }


# ---------------------------------------------------------------------------
# Ownership verification
# ---------------------------------------------------------------------------


async def verify_wallet_ownership(
    session: AsyncSession,
    user_id: str,
    wallet_address: str,
    signature: str,
    message: str,
    chain_type: str,
) -> dict[str, Any]:
    """Verify a signature and confirm the wallet belongs to the user.

    Combines cryptographic signature verification with a database
    ownership check.

    Returns:
        Dict with ``verified``, ``wallet_address``, and
        ``verification_timestamp``.

    Raises:
        InvalidSignatureError: If the signature is invalid.
        NotFoundError: If the wallet is not linked to the user.
    """

    # Verify the cryptographic signature
    result = verify_wallet_signature(wallet_address, signature, message, chain_type)
    if not result.get("valid"):
        raise InvalidSignatureError(
            result.get("error", "Wallet signature verification failed")
        )

    # Confirm wallet belongs to user
    wallet = await repository.get_wallet_by_address(
        session, wallet_address, chain_type,
    )
    if wallet is None or str(wallet.user_id) != user_id:
        raise NotFoundError("Wallet is not linked to your account")

    return {
        "verified": True,
        "wallet_address": wallet_address,
        "verification_timestamp": datetime.now(UTC).isoformat(),
    }


# ---------------------------------------------------------------------------
# Ethereum balance / contract helpers
# ---------------------------------------------------------------------------


async def get_ethereum_balance(
    wallet_address: str,
    rpc_url: str,
) -> dict[str, Any]:
    """Check the ETH balance for a wallet address.

    Uses the configured Ethereum RPC endpoint.  Returns a balance string
    in ETH (not wei).

    Returns:
        Dict with ``balance``, ``wallet_address``, and ``currency``.

    Raises:
        ValidationError: If no RPC URL is configured or web3 is unavailable.
    """

    if not rpc_url:
        raise ValidationError("Ethereum RPC URL not configured")

    try:
        from web3 import Web3

        w3 = Web3(Web3.HTTPProvider(rpc_url))
        balance_wei = w3.eth.get_balance(
            Web3.to_checksum_address(wallet_address),
        )
        balance_eth = str(w3.from_wei(balance_wei, "ether"))
    except ImportError:
        raise ValidationError(
            "web3 package not installed; ETH balance queries unavailable"
        )
    except Exception as exc:
        logger.exception("ethereum_balance_check_failed")
        raise ValidationError(f"Failed to fetch ETH balance: {exc}")

    return {
        "balance": balance_eth,
        "wallet_address": wallet_address,
        "currency": "ETH",
    }


async def check_contract_interaction(
    wallet_address: str,
    contract_address: str,
    rpc_url: str,
) -> dict[str, Any]:
    """Check if a wallet can interact with a smart contract.

    Performs a basic check by verifying the contract has code deployed
    at its address and the wallet has a non-zero ETH balance for gas.

    Returns:
        Dict with ``can_interact``, ``wallet_address``, and
        ``contract_address``.

    Raises:
        ValidationError: If no RPC URL is configured or web3 is unavailable.
    """

    if not rpc_url:
        raise ValidationError("Ethereum RPC URL not configured")

    try:
        from web3 import Web3

        w3 = Web3(Web3.HTTPProvider(rpc_url))
        checksum_contract = Web3.to_checksum_address(contract_address)
        checksum_wallet = Web3.to_checksum_address(wallet_address)

        # Check contract has code deployed
        code = w3.eth.get_code(checksum_contract)
        has_code = code != b"" and code != b"\x00"

        # Check wallet has balance for gas
        balance = w3.eth.get_balance(checksum_wallet)
        has_balance = balance > 0

        can_interact = has_code and has_balance
    except ImportError:
        raise ValidationError(
            "web3 package not installed; contract checks unavailable"
        )
    except Exception as exc:
        logger.exception("contract_interaction_check_failed")
        raise ValidationError(f"Failed to check contract interaction: {exc}")

    return {
        "can_interact": can_interact,
        "wallet_address": wallet_address,
        "contract_address": contract_address,
    }
