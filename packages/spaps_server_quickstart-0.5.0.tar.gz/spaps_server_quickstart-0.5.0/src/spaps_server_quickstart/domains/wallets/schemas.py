"""Pydantic request/response schemas for wallet endpoints (Solana & Ethereum).

These schemas define the *data* portion of each API response.
The standard response envelope ``{ success, data, error, metadata }``
is applied by middleware — domain schemas never reference it.

Zero FastAPI imports.
"""

from __future__ import annotations

from pydantic import BaseModel, Field


# ===========================================================================
# Solana
# ===========================================================================

# ---------------------------------------------------------------------------
# Solana — Request schemas
# ---------------------------------------------------------------------------


class SolanaSignInRequest(BaseModel):
    """POST /solana/sign-in"""

    wallet_address: str = Field(min_length=32, max_length=44)
    signature: str
    message: str
    application_id: str | None = None


class SolanaLinkWalletRequest(BaseModel):
    """POST /solana/link-wallet (authenticated)"""

    wallet_address: str
    signature: str
    message: str


class SolanaVerifySignatureRequest(BaseModel):
    """POST /solana/verify-signature"""

    wallet_address: str
    signature: str
    message: str


class SolanaVerifyOwnershipRequest(BaseModel):
    """POST /solana/verify-ownership (authenticated)"""

    wallet_address: str
    signature: str
    message: str


# ---------------------------------------------------------------------------
# Solana — Response schemas
# ---------------------------------------------------------------------------


class WalletSignInResponse(BaseModel):
    """POST /solana/sign-in — success payload."""

    user: dict  # UserResponse equivalent
    wallet: dict
    session: dict


class LinkWalletResponse(BaseModel):
    """POST /solana/link-wallet — success payload."""

    user: dict
    wallet: dict


class VerifySignatureResponse(BaseModel):
    """POST /solana/verify-signature — success payload."""

    valid: bool
    wallet_address: str
    timestamp: str


class GenerateMessageResponse(BaseModel):
    """GET /solana/generate-message — success payload."""

    message: str
    wallet_address: str
    timestamp: str


class WalletsListResponse(BaseModel):
    """GET /solana/wallets — success payload."""

    wallets: list[dict]
    count: int


class VerifyOwnershipResponse(BaseModel):
    """POST /solana/verify-ownership — success payload."""

    verified: bool
    wallet_address: str
    verification_timestamp: str


# ===========================================================================
# Ethereum
# ===========================================================================

# ---------------------------------------------------------------------------
# Ethereum — Request schemas
# ---------------------------------------------------------------------------


class EthereumSignInRequest(BaseModel):
    """POST /ethereum/sign-in"""

    wallet_address: str  # 0x-prefixed address
    signature: str  # 0x + 130 hex chars
    message: str
    application_id: str | None = None


class EthereumLinkWalletRequest(BaseModel):
    """POST /ethereum/link-wallet (authenticated)"""

    wallet_address: str
    signature: str
    message: str


class EthereumVerifySignatureRequest(BaseModel):
    """POST /ethereum/verify-signature"""

    wallet_address: str
    signature: str
    message: str


class EthereumVerifyOwnershipRequest(BaseModel):
    """POST /ethereum/verify-ownership (authenticated)"""

    wallet_address: str
    signature: str
    message: str


class EthereumVerifyTypedDataRequest(BaseModel):
    """POST /ethereum/verify-typed-data (EIP-712)"""

    wallet_address: str
    signature: str
    domain: dict
    types: dict
    value: dict


# ---------------------------------------------------------------------------
# Ethereum — Response schemas
# ---------------------------------------------------------------------------


class EthereumVerifySignatureResponse(BaseModel):
    """POST /ethereum/verify-signature — success payload."""

    valid: bool
    wallet_address: str
    signature_type: str = "EIP-191"
    timestamp: str


class EthereumVerifyTypedDataResponse(BaseModel):
    """POST /ethereum/verify-typed-data — success payload."""

    valid: bool
    wallet_address: str
    signature_type: str = "EIP-712"
    domain: dict
    timestamp: str


class EthereumGenerateMessageResponse(BaseModel):
    """GET /ethereum/generate-message — success payload."""

    message: str
    wallet_address: str
    signature_type: str = "EIP-191"
    timestamp: str


class EthereumGenerateTypedDataResponse(BaseModel):
    """GET /ethereum/generate-typed-data — success payload (EIP-712).

    Additional typed-data fields (domain, types, primaryType, message)
    are included at the top level alongside these fields.
    """

    wallet_address: str
    signature_type: str = "EIP-712"
    timestamp: str


class EthereumBalanceResponse(BaseModel):
    """GET /ethereum/balance — success payload."""

    balance: str
    wallet_address: str
    currency: str = "ETH"


class EthereumContractCheckResponse(BaseModel):
    """GET /ethereum/contract-check — success payload."""

    can_interact: bool
    wallet_address: str
    contract_address: str


# ===========================================================================
# Shared
# ===========================================================================


class NetworkInfoResponse(BaseModel):
    """GET /<chain>/network-info — success payload."""

    chain: str
    network: str
    rpc_url: str | None = None
    chain_id: int | None = None
