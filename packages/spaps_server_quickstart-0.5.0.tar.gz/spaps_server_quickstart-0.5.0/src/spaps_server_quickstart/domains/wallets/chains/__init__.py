"""Chain-specific wallet signature verification.

Re-exports the public API so callers can do::

    from spaps_server_quickstart.domains.wallets.chains import (
        verify_wallet_signature,
        verify_solana_signature,
        verify_ethereum_signature,
        verify_typed_data_signature,
        extract_chain_from_address,
        is_valid_solana_address,
        is_valid_ethereum_address,
        get_checksum_address,
    )
"""

from .solana import verify_solana_signature, is_valid_solana_address
from .ethereum import (
    verify_ethereum_signature,
    verify_typed_data_signature,
    is_valid_ethereum_address,
    get_checksum_address,
)
from .dispatcher import verify_wallet_signature, extract_chain_from_address

__all__ = [
    # Solana
    "verify_solana_signature",
    "is_valid_solana_address",
    # Ethereum / EVM
    "verify_ethereum_signature",
    "verify_typed_data_signature",
    "is_valid_ethereum_address",
    "get_checksum_address",
    # Dispatcher
    "verify_wallet_signature",
    "extract_chain_from_address",
]
