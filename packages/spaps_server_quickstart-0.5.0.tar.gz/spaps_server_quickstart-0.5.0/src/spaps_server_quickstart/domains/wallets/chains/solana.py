"""Solana Ed25519 wallet signature verification.

Ported from TypeScript ``src/services/solana-auth.ts`` and
``src/utils/wallet-auth.ts``.  Pure functions -- no DB or HTTP access.

Uses the *solders* library exclusively: ``Pubkey`` for address validation,
``Signature`` for base58 decoding, and ``Signature.verify()`` for native
Ed25519 verification of arbitrary ``signMessage`` payloads.
"""

from __future__ import annotations

import structlog

from solders.pubkey import Pubkey
from solders.signature import Signature as SoldersSignature

logger = structlog.get_logger(__name__)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def verify_solana_signature(
    wallet_address: str,
    signature: str,
    message: str,
) -> bool:
    """Verify a Solana Ed25519 detached signature.

    This handles the standard ``signMessage`` flow used by Phantom, Solflare,
    and other Solana wallets, where the wallet signs raw UTF-8 bytes with
    the Ed25519 private key corresponding to the user's public key.

    Args:
        wallet_address: Base58-encoded Solana public key (32-44 chars).
        signature: Base58-encoded 64-byte Ed25519 signature.
        message: The original UTF-8 message that was signed.

    Returns:
        ``True`` if the signature is cryptographically valid, ``False``
        otherwise.  Never raises on invalid input -- returns ``False``
        instead.
    """
    if not wallet_address or not signature or not message:
        return False

    try:
        # --- Decode public key -------------------------------------------
        try:
            pubkey = Pubkey.from_string(wallet_address)
        except (ValueError, Exception):
            logger.debug(
                "solana_invalid_address",
                address=wallet_address,
            )
            return False

        # --- Decode base58 signature ------------------------------------
        try:
            sol_sig = SoldersSignature.from_string(signature)
        except (ValueError, Exception):
            logger.debug(
                "solana_invalid_signature_format",
                address=wallet_address,
            )
            return False

        # --- Verify Ed25519 via solders ----------------------------------
        msg_bytes: bytes = message.encode("utf-8")
        return sol_sig.verify(pubkey, msg_bytes)

    except Exception:
        logger.exception("solana_signature_verification_error")
        return False


def is_valid_solana_address(address: str) -> bool:
    """Check whether *address* is a plausible Solana wallet address.

    Validates that the string is a base58-encoded value that ``solders``
    accepts as a ``Pubkey``.  Solana addresses are 32-44 characters of
    base58 (encoding a 32-byte Ed25519 public key).

    Args:
        address: Candidate wallet address string.

    Returns:
        ``True`` if valid, ``False`` otherwise.
    """
    if not address or not isinstance(address, str):
        return False

    # Quick length pre-check before heavier base58 decode
    if len(address) < 32 or len(address) > 44:
        return False

    try:
        Pubkey.from_string(address)
        return True
    except Exception:
        return False
