"""Ethereum ECDSA wallet signature verification.

Ported from TypeScript ``src/services/ethereum-auth.ts`` and
``src/utils/wallet-auth.ts``.  Pure functions -- no DB or HTTP access.

Supports:
- **EIP-191** (``personal_sign``) -- standard MetaMask / WalletConnect flow.
- **EIP-712** (typed structured data) -- used for dApp-specific auth.
- **EIP-55** checksum address normalisation.

Uses the *eth-account* library (``>=0.13.0``) for message encoding and
signature recovery, plus *eth-utils* (transitive dep) for checksum
addresses.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

import structlog

from eth_account import Account
from eth_account.messages import encode_defunct

logger = structlog.get_logger(__name__)


# ---------------------------------------------------------------------------
# EIP-191 personal_sign verification
# ---------------------------------------------------------------------------


def verify_ethereum_signature(
    wallet_address: str,
    signature: str,
    message: str,
) -> dict[str, Any]:
    """Verify an Ethereum EIP-191 ``personal_sign`` signature.

    Recovers the signer address from *signature* and compares it
    (case-insensitively) against *wallet_address*.

    Args:
        wallet_address: Expected signer address (``0x``-prefixed, 42 chars).
        signature: Hex-encoded ECDSA signature (``0x``-prefixed or raw hex).
        message: The original UTF-8 message that was signed.

    Returns:
        A dict with at least ``{"valid": bool}``.  On success the dict also
        contains ``wallet_address`` (checksummed), ``signature_type``, and
        ``timestamp``.  On failure it includes an ``error`` string.
    """
    if not wallet_address or not signature or not message:
        return {"valid": False, "error": "Missing required parameters"}

    try:
        if not is_valid_ethereum_address(wallet_address):
            return {"valid": False, "error": "Invalid Ethereum address format"}

        # Encode the plaintext message per EIP-191.
        signable = encode_defunct(text=message)

        # Recover the signer's address from the signature.
        try:
            recovered_address: str = Account.recover_message(
                signable, signature=signature
            )
        except Exception:
            return {"valid": False, "error": "Invalid signature format"}

        # Case-insensitive comparison.
        if recovered_address.lower() != wallet_address.lower():
            return {"valid": False, "error": "Signature does not match address"}

        return {
            "valid": True,
            "wallet_address": get_checksum_address(recovered_address),
            "signature_type": "EIP-191",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    except Exception:
        logger.exception("ethereum_signature_verification_error")
        return {"valid": False, "error": "Signature verification failed"}


# ---------------------------------------------------------------------------
# EIP-712 typed data verification
# ---------------------------------------------------------------------------


def verify_typed_data_signature(
    wallet_address: str,
    signature: str,
    domain: dict[str, Any],
    types: dict[str, Any],
    value: dict[str, Any],
) -> dict[str, Any]:
    """Verify an Ethereum EIP-712 typed-data signature.

    Uses ``eth_account.messages.encode_typed_data`` to hash the structured
    data and then recovers the signer address.

    Args:
        wallet_address: Expected signer address.
        signature: Hex-encoded ECDSA signature.
        domain: EIP-712 domain separator fields (name, version, chainId, ...).
        types: Type definitions **without** ``EIP712Domain`` (the library
            infers it from *domain*).
        value: The actual message data matching *types*.

    Returns:
        A dict with ``valid``, and on success ``wallet_address``,
        ``signature_type``, ``domain``, and ``timestamp``.
    """
    if not wallet_address or not signature:
        return {"valid": False, "error": "Missing required parameters"}

    try:
        if not is_valid_ethereum_address(wallet_address):
            return {"valid": False, "error": "Invalid Ethereum address format"}

        # Strip EIP712Domain from caller-supplied types -- the library
        # infers it automatically from domain_data.
        message_types = {k: v for k, v in types.items() if k != "EIP712Domain"}

        if not message_types:
            return {"valid": False, "error": "No message types found in types"}

        # Encode the typed-data structure.
        # eth-account >=0.13 uses positional args:
        #   encode_typed_data(domain_data, message_types, message_data)
        try:
            from eth_account.messages import encode_typed_data

            signable = encode_typed_data(
                domain_data=domain,
                message_types=message_types,
                message_data=value,
            )
        except Exception:
            logger.debug("eip712_encode_failed", types=list(message_types.keys()))
            return {"valid": False, "error": "Failed to encode typed data"}

        # Recover signer address.
        try:
            recovered_address: str = Account.recover_message(
                signable, signature=signature
            )
        except Exception:
            return {"valid": False, "error": "Invalid signature format"}

        if recovered_address.lower() != wallet_address.lower():
            return {"valid": False, "error": "Signature does not match address"}

        return {
            "valid": True,
            "wallet_address": get_checksum_address(recovered_address),
            "signature_type": "EIP-712",
            "domain": domain,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    except Exception:
        logger.exception("eip712_signature_verification_error")
        return {"valid": False, "error": "Typed data verification failed"}


# ---------------------------------------------------------------------------
# Address helpers
# ---------------------------------------------------------------------------


def is_valid_ethereum_address(address: str) -> bool:
    """Check whether *address* is a valid Ethereum address.

    Validates the ``0x`` prefix and 40 hex-character body (total 42 chars).
    Does **not** enforce EIP-55 checksumming -- both lower-case and
    mixed-case addresses are accepted.
    """
    if not address or not isinstance(address, str):
        return False
    if not address.startswith("0x"):
        return False
    if len(address) != 42:
        return False
    try:
        int(address[2:], 16)
        return True
    except ValueError:
        return False


def get_checksum_address(address: str) -> str:
    """Return the EIP-55 mixed-case checksum encoding of *address*.

    Falls back to returning the original string unchanged if the
    conversion fails (e.g. the address is already invalid).
    """
    try:
        from eth_utils import to_checksum_address

        return str(to_checksum_address(address))
    except Exception:
        return address
