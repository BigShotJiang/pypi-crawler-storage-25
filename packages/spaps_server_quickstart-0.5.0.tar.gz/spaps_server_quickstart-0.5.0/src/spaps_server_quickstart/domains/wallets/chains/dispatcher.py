"""Universal wallet signature verification dispatcher.

Ported from TypeScript ``src/utils/wallet-auth.ts``.

Routes verification requests to the correct chain-specific handler based
on an explicit ``chain_type`` argument or by inspecting the address format.
Pure function -- no DB or HTTP access.
"""

from __future__ import annotations

import re
from typing import Any

import structlog

from ...errors import UnsupportedWalletError
from .ethereum import verify_ethereum_signature, is_valid_ethereum_address
from .solana import verify_solana_signature, is_valid_solana_address

logger = structlog.get_logger(__name__)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def verify_wallet_signature(
    wallet_address: str,
    signature: str,
    message: str,
    chain_type: str | None = None,
) -> dict[str, Any]:
    """Verify a wallet signature, dispatching to the appropriate chain handler.

    If *chain_type* is not provided it is inferred from *wallet_address*
    via :func:`extract_chain_from_address`.

    Supported chains:

    * ``solana`` -- Ed25519 via :func:`verify_solana_signature`
    * ``ethereum`` / ``base`` -- ECDSA EIP-191 via :func:`verify_ethereum_signature`
      (Base uses the same Ethereum signing scheme).
    * ``bitcoin`` -- returns a "not yet implemented" result.

    Args:
        wallet_address: The wallet address that allegedly signed *message*.
        signature: The encoded signature (base58 for Solana, hex for EVM).
        message: The original UTF-8 message.
        chain_type: Optional explicit chain identifier.  When ``None`` the
            chain is detected from the address format.

    Returns:
        A dict with at least ``{"valid": bool}``.  Additional keys vary by
        chain (see chain-specific modules).

    Raises:
        UnsupportedWalletError: If the chain cannot be determined or is not
            supported.
    """
    if chain_type is None:
        chain_type = extract_chain_from_address(wallet_address)

    logger.debug(
        "wallet_signature_dispatch",
        chain_type=chain_type,
        address=wallet_address,
    )

    match chain_type:
        case "solana":
            valid = verify_solana_signature(wallet_address, signature, message)
            return {
                "valid": valid,
                "wallet_address": wallet_address,
                "chain_type": "solana",
            }

        case "ethereum" | "base":
            result = verify_ethereum_signature(wallet_address, signature, message)
            result["chain_type"] = chain_type
            return result

        case "bitcoin":
            return {
                "valid": False,
                "chain_type": "bitcoin",
                "error": "Bitcoin signature verification not yet implemented",
            }

        case _:
            raise UnsupportedWalletError(
                f"Unsupported chain type: {chain_type}"
            )


def extract_chain_from_address(address: str) -> str:
    """Infer the blockchain network from a wallet address format.

    Detection order (most specific first):

    1. **Ethereum** -- ``0x`` prefix + 40 hex characters.
    2. **Bitcoin** -- Legacy P2PKH (``1...``), P2SH (``3...``),
       SegWit v0 (``bc1q...``), Taproot/SegWit v1 (``bc1p...``).
    3. **Solana** -- Base58, 32-44 characters that ``solders.Pubkey`` accepts.

    Args:
        address: The wallet address to classify.

    Returns:
        One of ``"solana"``, ``"ethereum"``, or ``"bitcoin"``.

    Raises:
        UnsupportedWalletError: If the address format does not match any
            known chain.
    """
    if not address or not isinstance(address, str):
        raise UnsupportedWalletError("Empty or invalid wallet address")

    address = address.strip()

    # Ethereum / EVM -- 0x + 40 hex characters
    if re.match(r"^0x[a-fA-F0-9]{40}$", address):
        if is_valid_ethereum_address(address):
            return "ethereum"

    # Bitcoin -- legacy P2PKH (1...), P2SH (3...), SegWit v0 (bc1q...), Taproot (bc1p...)
    if re.match(r"^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$", address):
        return "bitcoin"
    if re.match(r"^bc1[a-z0-9]{39,59}$", address):
        return "bitcoin"

    # Solana -- base58, 32-44 chars, validated via solders Pubkey
    if is_valid_solana_address(address):
        return "solana"

    raise UnsupportedWalletError(
        f"Cannot determine chain type for address: {address}"
    )
