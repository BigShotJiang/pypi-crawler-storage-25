"""Wallets domain -- models, chain verification, and API routers.

Re-exports the SQLAlchemy model, chain verification public API, and
FastAPI routers so that consumers can import from a single location::

    from spaps_server_quickstart.domains.wallets import (
        UserWallet,
        verify_wallet_signature,
        solana_router,
        ethereum_router,
    )
"""

from .models import UserWallet

from .chains import (
    verify_wallet_signature,
    verify_solana_signature,
    verify_ethereum_signature,
    verify_typed_data_signature,
    extract_chain_from_address,
    is_valid_solana_address,
    is_valid_ethereum_address,
    get_checksum_address,
)

from .router import solana_router, ethereum_router

__all__ = [
    # Model
    "UserWallet",
    # Chain verification
    "verify_wallet_signature",
    "verify_solana_signature",
    "verify_ethereum_signature",
    "verify_typed_data_signature",
    "extract_chain_from_address",
    "is_valid_solana_address",
    "is_valid_ethereum_address",
    "get_checksum_address",
    # Routers
    "solana_router",
    "ethereum_router",
]
