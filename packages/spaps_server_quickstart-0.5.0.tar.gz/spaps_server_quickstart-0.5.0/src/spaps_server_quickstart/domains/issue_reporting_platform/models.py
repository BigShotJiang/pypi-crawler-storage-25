"""SQLAlchemy models for the issue reporting platform domain."""

from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID, uuid4

from sqlalchemy import DateTime, ForeignKey, Index, String, Text, func
from sqlalchemy.dialects.postgresql import JSON
from sqlalchemy.orm import Mapped, mapped_column

from .._db import Base, PGUUID


class IssueReport(Base):
    """Canonical end-user issue report linked to a support case."""

    __tablename__ = "issue_reports"

    id: Mapped[UUID] = mapped_column(PGUUID(as_uuid=True), primary_key=True, default=uuid4)
    application_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("applications.id", ondelete="CASCADE"),
        nullable=False,
    )
    reporter_user_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
    )
    reporter_role_hint: Mapped[str | None] = mapped_column(String(64), nullable=True)
    component_key: Mapped[str] = mapped_column(String(255), nullable=False)
    component_label: Mapped[str] = mapped_column(String(255), nullable=False)
    page_url: Mapped[str] = mapped_column(String(500), nullable=False)
    surface_ref: Mapped[str | None] = mapped_column(String(255), nullable=True)
    target_metadata: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False, default=dict)
    note: Mapped[str] = mapped_column(Text, nullable=False)
    parent_issue_report_id: Mapped[UUID | None] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("issue_reports.id", ondelete="SET NULL"),
        nullable=True,
    )
    support_case_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("support_cases.id", ondelete="RESTRICT"),
        nullable=False,
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    __table_args__ = (
        Index("ix_issue_reports_app_reporter_created", "application_id", "reporter_user_id", "created_at"),
        Index("ix_issue_reports_support_case", "support_case_id"),
        Index("ix_issue_reports_parent", "parent_issue_report_id"),
    )

