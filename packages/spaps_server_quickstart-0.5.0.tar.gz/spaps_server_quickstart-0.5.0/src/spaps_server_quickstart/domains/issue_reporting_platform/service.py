"""Business logic for the issue_reporting_platform domain."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import Any
from uuid import UUID, uuid4

from sqlalchemy.ext.asyncio import AsyncSession

from ..support_telemetry_platform import repository as support_repo
from ..support_telemetry_platform.models import SupportCase
from . import repository as repo
from .errors import (
    IssueReportCannotEditClosedError,
    IssueReportCannotReplyOpenError,
    IssueReportCaseLinkBrokenError,
    IssueReportNotFoundError,
    ValidationFailedError,
)
from .models import IssueReport

RECENT_RESOLVED_WINDOW_DAYS = 7
NOTE_MIN_LENGTH = 10


def _iso(dt: datetime | None) -> str | None:
    if dt is None:
        return None
    return dt.isoformat()


def _normalize_note(note: str) -> str:
    normalized = note.strip()
    if len(normalized) < NOTE_MIN_LENGTH:
        raise ValidationFailedError("note must be at least 10 characters")
    return normalized


def _normalize_target(target: dict[str, Any]) -> dict[str, Any]:
    component_key = str(target.get("component_key") or "").strip()
    component_label = str(target.get("component_label") or "").strip()
    page_url = str(target.get("page_url") or "").strip()
    surface_ref = target.get("surface_ref")
    metadata = target.get("metadata") or {}

    if not component_key or not component_label or not page_url:
        raise ValidationFailedError("target snapshot is required")
    if not isinstance(metadata, dict):
        raise ValidationFailedError("target metadata must be an object")

    return {
        "component_key": component_key,
        "component_label": component_label,
        "page_url": page_url,
        "surface_ref": str(surface_ref).strip() if surface_ref else None,
        "metadata": metadata,
    }


def _derive_reporter_role_hint(*, reporter_role_hint: str | None, user_roles: list[str] | set[str] | None) -> str:
    if reporter_role_hint and reporter_role_hint.strip():
        return reporter_role_hint.strip()

    roles = [str(role).strip() for role in (user_roles or []) if str(role).strip()]
    for preferred in ("practitioner", "patient", "user"):
        if preferred in roles:
            return preferred
    if roles:
        return roles[0]
    return "user"


def _actor_type_for_support_event(role_hint: str) -> str:
    if role_hint == "practitioner":
        return "practitioner"
    return "user"


def _linked_case_to_dict(case: SupportCase) -> dict[str, Any]:
    return {
        "case_id": str(case.id),
        "status": case.status,
        "priority": case.priority,
        "resolved_at": _iso(case.resolved_at),
    }


def _issue_report_to_dict(issue_report: IssueReport, case: SupportCase) -> dict[str, Any]:
    return {
        "id": str(issue_report.id),
        "application_id": str(issue_report.application_id),
        "reporter_user_id": str(issue_report.reporter_user_id),
        "reporter_role_hint": issue_report.reporter_role_hint,
        "target": {
            "component_key": issue_report.component_key,
            "component_label": issue_report.component_label,
            "page_url": issue_report.page_url,
            "surface_ref": issue_report.surface_ref,
            "metadata": issue_report.target_metadata or {},
        },
        "note": issue_report.note,
        "status": case.status,
        "parent_issue_report_id": (
            str(issue_report.parent_issue_report_id) if issue_report.parent_issue_report_id else None
        ),
        "linked_case": _linked_case_to_dict(case),
        "created_at": _iso(issue_report.created_at),
        "updated_at": _iso(issue_report.updated_at),
    }


def _ensure_linked_case(row: tuple[IssueReport, SupportCase | None] | None) -> tuple[IssueReport, SupportCase]:
    if row is None:
        raise IssueReportNotFoundError()
    issue_report, case = row
    if case is None:
        raise IssueReportCaseLinkBrokenError()
    return issue_report, case


async def create_issue_report(
    db: AsyncSession,
    *,
    application_id: UUID,
    reporter_user_id: UUID,
    reporter_role_hint: str | None,
    user_roles: list[str] | set[str] | None,
    target: dict[str, Any],
    note: str,
) -> dict[str, Any]:
    """Create one canonical issue report and linked support case."""
    normalized_target = _normalize_target(target)
    normalized_note = _normalize_note(note)
    effective_role_hint = _derive_reporter_role_hint(
        reporter_role_hint=reporter_role_hint,
        user_roles=user_roles,
    )
    now = datetime.now(UTC)

    case = await support_repo.create_case(
        db,
        application_id=application_id,
        external_case_ref=None,
        title=normalized_target["component_label"],
        status="open",
        priority="normal",
        highest_severity="warning",
        first_event_at=now,
        last_event_at=now,
    )

    issue_report = await repo.create_issue_report(
        db,
        application_id=application_id,
        reporter_user_id=reporter_user_id,
        reporter_role_hint=effective_role_hint,
        component_key=normalized_target["component_key"],
        component_label=normalized_target["component_label"],
        page_url=normalized_target["page_url"],
        surface_ref=normalized_target["surface_ref"],
        target_metadata=normalized_target["metadata"],
        note=normalized_note,
        parent_issue_report_id=None,
        support_case_id=case.id,
    )

    event = await support_repo.create_event(
        db,
        case_id=case.id,
        application_id=application_id,
        event_key=f"issue_report_created_{uuid4().hex}"[:128],
        source_channel="frontend",
        event_type="issue_reported",
        severity="warning",
        actor_type=_actor_type_for_support_event(effective_role_hint),
        actor_external_id=str(reporter_user_id),
        correlation_id=None,
        payload={
            "issue_report_id": str(issue_report.id),
            "reporter_role_hint": effective_role_hint,
            "target": normalized_target,
            "note": normalized_note,
        },
        redacted_keys=[],
        occurred_at=now,
        ingested_by_user_id=reporter_user_id,
    )
    case = await support_repo.update_case_summary(
        db,
        case=case,
        occurred_at=event.occurred_at,
        severity="warning",
        title=normalized_target["component_label"],
    )
    return _issue_report_to_dict(issue_report, case)


async def list_issue_reports(
    db: AsyncSession,
    *,
    application_id: UUID,
    reporter_user_id: UUID,
    status: str | None,
    limit: int,
    offset: int,
) -> dict[str, Any]:
    """List one reporter's issue reports inside the active app scope."""
    rows, total = await repo.list_issue_report_rows(
        db,
        application_id=application_id,
        reporter_user_id=reporter_user_id,
        status=status,
        limit=limit,
        offset=offset,
    )
    items = []
    for row in rows:
        issue_report, case = _ensure_linked_case(row)
        items.append(_issue_report_to_dict(issue_report, case))
    return {"items": items, "total": total}


async def get_issue_report_detail(
    db: AsyncSession,
    *,
    application_id: UUID,
    reporter_user_id: UUID,
    issue_report_id: UUID,
) -> dict[str, Any]:
    """Return one caller-owned issue report."""
    row = await repo.get_issue_report_row(
        db,
        issue_report_id=issue_report_id,
        application_id=application_id,
        reporter_user_id=reporter_user_id,
    )
    issue_report, case = _ensure_linked_case(row)
    return _issue_report_to_dict(issue_report, case)


async def update_issue_report_note(
    db: AsyncSession,
    *,
    application_id: UUID,
    reporter_user_id: UUID,
    issue_report_id: UUID,
    note: str,
    reporter_role_hint: str | None,
    user_roles: list[str] | set[str] | None,
) -> dict[str, Any]:
    """Edit the note of an unresolved issue report."""
    normalized_note = _normalize_note(note)
    row = await repo.get_issue_report_row(
        db,
        issue_report_id=issue_report_id,
        application_id=application_id,
        reporter_user_id=reporter_user_id,
    )
    issue_report, case = _ensure_linked_case(row)
    if case.status in {"resolved", "ignored"}:
        raise IssueReportCannotEditClosedError()

    previous_note = issue_report.note
    updated_issue_report = await repo.update_issue_report_note(
        db,
        issue_report=issue_report,
        note=normalized_note,
    )
    now = datetime.now(UTC)
    effective_role_hint = _derive_reporter_role_hint(
        reporter_role_hint=reporter_role_hint,
        user_roles=user_roles,
    )
    event = await support_repo.create_event(
        db,
        case_id=case.id,
        application_id=application_id,
        event_key=f"issue_report_edit_{uuid4().hex}"[:128],
        source_channel="frontend",
        event_type="issue_report_note_edited",
        severity="info",
        actor_type=_actor_type_for_support_event(effective_role_hint),
        actor_external_id=str(reporter_user_id),
        correlation_id=None,
        payload={
            "issue_report_id": str(updated_issue_report.id),
            "previous_note": previous_note,
            "note": normalized_note,
        },
        redacted_keys=[],
        occurred_at=now,
        ingested_by_user_id=reporter_user_id,
    )
    case = await support_repo.update_case_summary(
        db,
        case=case,
        occurred_at=event.occurred_at,
        severity="info",
        title=case.title,
    )
    return _issue_report_to_dict(updated_issue_report, case)


async def reply_to_issue_report(
    db: AsyncSession,
    *,
    application_id: UUID,
    reporter_user_id: UUID,
    issue_report_id: UUID,
    note: str,
    reporter_role_hint: str | None,
    user_roles: list[str] | set[str] | None,
) -> dict[str, Any]:
    """Create a child issue report and reopen the linked case."""
    normalized_note = _normalize_note(note)
    row = await repo.get_issue_report_row(
        db,
        issue_report_id=issue_report_id,
        application_id=application_id,
        reporter_user_id=reporter_user_id,
    )
    parent_issue_report, case = _ensure_linked_case(row)
    if case.status not in {"resolved", "ignored"}:
        raise IssueReportCannotReplyOpenError()

    effective_role_hint = _derive_reporter_role_hint(
        reporter_role_hint=reporter_role_hint,
        user_roles=user_roles,
    )
    previous_case_status = case.status
    child_issue_report = await repo.create_issue_report(
        db,
        application_id=application_id,
        reporter_user_id=reporter_user_id,
        reporter_role_hint=effective_role_hint,
        component_key=parent_issue_report.component_key,
        component_label=parent_issue_report.component_label,
        page_url=parent_issue_report.page_url,
        surface_ref=parent_issue_report.surface_ref,
        target_metadata=parent_issue_report.target_metadata or {},
        note=normalized_note,
        parent_issue_report_id=parent_issue_report.id,
        support_case_id=case.id,
    )

    reopened_case = await support_repo.update_case(
        db,
        case=case,
        status="open",
        resolved_at=None,
        set_resolved_at=True,
    )
    now = datetime.now(UTC)
    event = await support_repo.create_event(
        db,
        case_id=reopened_case.id,
        application_id=application_id,
        event_key=f"issue_report_reply_{uuid4().hex}"[:128],
        source_channel="frontend",
        event_type="issue_report_replied",
        severity="warning",
        actor_type=_actor_type_for_support_event(effective_role_hint),
        actor_external_id=str(reporter_user_id),
        correlation_id=None,
        payload={
            "issue_report_id": str(child_issue_report.id),
            "parent_issue_report_id": str(parent_issue_report.id),
            "previous_case_status": previous_case_status,
            "note": normalized_note,
        },
        redacted_keys=[],
        occurred_at=now,
        ingested_by_user_id=reporter_user_id,
    )
    reopened_case = await support_repo.update_case_summary(
        db,
        case=reopened_case,
        occurred_at=event.occurred_at,
        severity="warning",
        title=reopened_case.title,
    )
    return _issue_report_to_dict(child_issue_report, reopened_case)


async def get_issue_report_status(
    db: AsyncSession,
    *,
    application_id: UUID,
    reporter_user_id: UUID,
) -> dict[str, Any]:
    """Return aggregate reporter status used by the floating entrypoint."""
    open_count = await repo.count_open_issue_reports(
        db,
        application_id=application_id,
        reporter_user_id=reporter_user_id,
    )
    recent_resolved_count = await repo.count_recent_resolved_issue_reports(
        db,
        application_id=application_id,
        reporter_user_id=reporter_user_id,
        resolved_since=datetime.now(UTC) - timedelta(days=RECENT_RESOLVED_WINDOW_DAYS),
    )
    return {
        "has_open": open_count > 0,
        "has_recent_resolved": recent_resolved_count > 0,
        "open_count": open_count,
        "recent_resolved_count": recent_resolved_count,
    }
