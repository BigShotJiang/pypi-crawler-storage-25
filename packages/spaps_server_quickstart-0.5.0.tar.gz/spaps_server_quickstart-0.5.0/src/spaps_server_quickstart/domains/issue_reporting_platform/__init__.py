"""Issue reporting platform domain."""

