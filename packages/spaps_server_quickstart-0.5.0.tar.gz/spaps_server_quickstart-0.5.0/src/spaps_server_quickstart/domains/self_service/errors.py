"""Domain errors for the self-service domain."""

from __future__ import annotations

from ..errors import DomainError


class SelfServiceNetworkRestrictedError(DomainError):
    """TM-008: Raised when a request is blocked by network boundary policy."""

    def __init__(self, message: str = "Access restricted by network policy") -> None:
        super().__init__("SELF_SERVICE_NETWORK_RESTRICTED", message, status_code=403)
