"""Token management, rate limiting, and application CRUD for the self-service domain.

In-memory stores for tokens and auth attempt tracking. This mirrors the
Node.js implementation where session state lives in process memory.
"""

from __future__ import annotations

import secrets
import time
from datetime import datetime, timedelta, timezone

from ..applications import repository as apps_repo
from ..applications.service import (
    DEFAULT_APP_SETTINGS,
    generate_api_key,
    generate_publishable_key,
    generate_secret_key,
    hash_key,
)
from ..errors import (
    DomainError,
    InvalidCredentialsError,
    NotFoundError,
    RateLimitExceededError,
    ServiceUnavailableError,
)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

TOKEN_PREFIX = "ss_"
TOKEN_TTL = 3600  # 1 hour
RATE_LIMIT_WINDOW = 300  # 5 minutes
RATE_LIMIT_MAX = 5

# ---------------------------------------------------------------------------
# In-memory stores
# ---------------------------------------------------------------------------

_valid_tokens: set[str] = set()
_token_timers: dict[str, float] = {}  # token -> expiry timestamp
_auth_attempts: dict[str, dict] = {}  # ip -> { count, reset_time }


# ---------------------------------------------------------------------------
# Token operations
# ---------------------------------------------------------------------------


def generate_token() -> str:
    """Generate a new self-service token: ``ss_`` + 64 hex chars (67 total)."""
    return TOKEN_PREFIX + secrets.token_hex(32)


def store_token(token: str) -> None:
    """Store a token with a TTL of ``TOKEN_TTL`` seconds."""
    _valid_tokens.add(token)
    _token_timers[token] = time.time() + TOKEN_TTL


def validate_token(token: str | None) -> bool:
    """Return ``True`` if the token is valid and not expired."""
    if not token or not token.startswith(TOKEN_PREFIX) or len(token) != 67:
        return False
    if token not in _valid_tokens:
        return False
    if time.time() > _token_timers.get(token, 0):
        # Expired -- clean up
        _valid_tokens.discard(token)
        _token_timers.pop(token, None)
        return False
    return True


# ---------------------------------------------------------------------------
# Rate limiting
# ---------------------------------------------------------------------------


def check_rate_limit(ip: str) -> bool:
    """Return ``True`` if the IP is within the rate limit, ``False`` if exceeded."""
    now = time.time()
    attempts = _auth_attempts.get(ip)

    if attempts is None or now > attempts["reset_time"]:
        # Window has expired or first attempt -- start fresh
        _auth_attempts[ip] = {"count": 0, "reset_time": now + RATE_LIMIT_WINDOW}
        attempts = _auth_attempts[ip]

    if attempts["count"] >= RATE_LIMIT_MAX:
        return False
    return True


def record_attempt(ip: str) -> None:
    """Record a failed auth attempt for rate limiting."""
    now = time.time()
    attempts = _auth_attempts.get(ip)

    if attempts is None or now > attempts["reset_time"]:
        _auth_attempts[ip] = {"count": 1, "reset_time": now + RATE_LIMIT_WINDOW}
    else:
        attempts["count"] += 1


def reset_rate_limit(ip: str) -> None:
    """Clear rate limit tracking for an IP (called on successful auth)."""
    _auth_attempts.pop(ip, None)


# ---------------------------------------------------------------------------
# Authentication
# ---------------------------------------------------------------------------


def authenticate(*, password: str, configured_password: str, ip: str) -> dict:
    """Authenticate with the self-service password.

    Returns a bearer token that expires after 1 hour.
    Rate limited to 5 attempts per 5 minutes per IP.

    Args:
        password: The password provided by the user
        configured_password: The configured self-service password
        ip: The client IP address for rate limiting

    Returns:
        Dict containing token, expiresAt, and message

    Raises:
        ServiceUnavailableError: If self-service password is not configured
        RateLimitExceededError: If too many auth attempts from this IP
        ValidationError: If password is missing
        InvalidCredentialsError: If password is incorrect
    """
    # Service unavailable if password not configured
    if not configured_password:
        raise ServiceUnavailableError("Self-service is not configured")

    # Check rate limit BEFORE validating password
    if not check_rate_limit(ip):
        raise RateLimitExceededError("Too many authentication attempts. Try again later.")

    # Validate password presence
    if not password:
        record_attempt(ip)
        raise DomainError(
            code="MISSING_PASSWORD",
            message="Password is required",
            status_code=400,
        )

    # Validate password match
    if password != configured_password:
        record_attempt(ip)
        raise InvalidCredentialsError("Invalid password")

    # Success -- generate token and reset rate limit
    token = generate_token()
    store_token(token)
    reset_rate_limit(ip)

    expires_at = datetime.now(timezone.utc) + timedelta(seconds=TOKEN_TTL)

    return {
        "token": token,
        "expiresAt": expires_at.isoformat(),
        "message": "Use this token as a Bearer token in the Authorization header",
    }


# ---------------------------------------------------------------------------
# Application CRUD
# ---------------------------------------------------------------------------


def mask_application(app) -> dict:
    """Build a masked application dict suitable for list/detail responses."""
    return {
        "id": str(app.id),
        "name": app.name,
        "slug": app.slug,
        "description": app.description,
        "webhook_url": app.webhook_url,
        "allowed_origins": app.allowed_origins,
        "settings": app.settings,
        "created_at": app.created_at.isoformat() if app.created_at else None,
        "updated_at": app.updated_at.isoformat() if app.updated_at else None,
        "api_key": "spaps_****",
    }


async def create_application(
    db,
    *,
    name,
    slug,
    description=None,
    webhook_url=None,
    allowed_origins=None,
    settings=None,
):
    existing = await apps_repo.get_application_by_name(db, name)
    if existing is not None:
        raise DomainError(
            code="APPLICATION_EXISTS",
            message=f"Application with name '{name}' already exists",
            status_code=409,
        )

    publishable_key = generate_publishable_key()
    secret_key = generate_secret_key()
    api_key = generate_api_key()

    app_settings = {**DEFAULT_APP_SETTINGS, **(settings or {})}

    app = await apps_repo.create_application(
        db,
        name=name,
        api_key=hash_key(secret_key),  # backward compat: api_key column = secret_key_hash
        slug=slug,
        description=description,
        webhook_url=webhook_url,
        allowed_origins=allowed_origins,
        settings=app_settings,
        publishable_key_hash=hash_key(publishable_key),
        secret_key_hash=hash_key(secret_key),
    )
    await db.commit()

    return {
        "application": {
            "id": str(app.id),
            "name": app.name,
            "slug": app.slug,
            "description": app.description,
            "webhook_url": app.webhook_url,
            "allowed_origins": app.allowed_origins,
            "settings": app.settings,
            "created_at": app.created_at.isoformat() if app.created_at else None,
            "updated_at": app.updated_at.isoformat() if app.updated_at else None,
        },
        "publishable_key": publishable_key,
        "secret_key": secret_key,
        "api_key": api_key,
        "warning": "Store these keys securely. The secret key and API key will not be shown again.",
    }


async def list_applications(db):
    apps = await apps_repo.list_applications(db)
    masked = [mask_application(a) for a in apps]
    return {
        "applications": masked,
        "total": len(masked),
    }


async def get_application(db, app_id):
    app = await apps_repo.get_application_by_id(db, app_id)
    if app is None:
        raise NotFoundError("Application not found")
    return {"application": mask_application(app)}


async def rotate_key(db, app_id):
    app = await apps_repo.get_application_by_id(db, app_id)
    if app is None:
        raise NotFoundError("Application not found")

    new_key = generate_api_key()
    await apps_repo.update_application(
        db,
        app_id,
        api_key=hash_key(new_key),
    )
    await db.commit()

    return {
        "api_key": new_key,
        "warning": "Store this new API key securely. The old key is now invalid.",
    }


async def rotate_typed_key(db, app_id, key_type):
    if key_type not in ("publishable", "secret"):
        raise DomainError(
            code="INVALID_KEY_TYPE",
            message=f"Invalid key type '{key_type}'. Must be 'publishable' or 'secret'.",
            status_code=400,
        )

    app = await apps_repo.get_application_by_id(db, app_id)
    if app is None:
        raise NotFoundError("Application not found")

    if key_type == "publishable":
        new_key = generate_publishable_key()
        await apps_repo.update_application(
            db,
            app_id,
            publishable_key_hash=hash_key(new_key),
        )
    else:
        new_key = generate_secret_key()
        await apps_repo.update_application(
            db,
            app_id,
            secret_key_hash=hash_key(new_key),
            api_key=hash_key(new_key),  # backward compat
        )
    await db.commit()

    return {
        "key": new_key,
        "key_type": key_type,
        "warning": f"Store this new {key_type} key securely. The old key is now invalid.",
    }


async def delete_application(db, app_id):
    app = await apps_repo.get_application_by_id(db, app_id)
    if app is None:
        raise NotFoundError("Application not found")

    app_name = app.name
    await apps_repo.delete_application(db, app_id)
    await db.commit()

    return {
        "message": "Application deleted successfully",
        "application_name": app_name,
    }


# ---------------------------------------------------------------------------
# Test helpers
# ---------------------------------------------------------------------------


def _reset_stores() -> None:
    """Clear all in-memory stores. For testing only."""
    _valid_tokens.clear()
    _token_timers.clear()
    _auth_attempts.clear()
