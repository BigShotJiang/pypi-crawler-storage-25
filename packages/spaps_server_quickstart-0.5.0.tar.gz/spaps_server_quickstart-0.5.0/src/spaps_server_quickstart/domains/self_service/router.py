"""HTTP routes for the self-service domain.

The self-service console is a password-protected admin interface for
managing SPAPS applications. It has its own authentication mechanism
(not JWT, not API key):

1. POST password to ``/auth`` -> receive an ``ss_``-prefixed token
2. Use the token as a ``Bearer`` header for subsequent requests
3. Tokens are stored in-memory with a 1-hour TTL
4. Auth endpoint is rate limited: 5 attempts per 5 min per IP

TM-008: Network boundary enforcement is applied BEFORE authentication.
If ``self_service_allowed_ips`` is configured, requests from non-allowlisted
IPs are denied with 403 SELF_SERVICE_NETWORK_RESTRICTED.

The response envelope ``{ success, data, error, metadata }`` is applied
automatically by ``ResponseEnvelopeMiddleware`` -- handlers return the
raw *data* portion only.
"""

from __future__ import annotations

import ipaddress
import logging
from typing import Annotated

from fastapi import APIRouter, Depends, Request

from ...middleware.spaps_deps import DbSession
from ..errors import UnauthorizedError
from . import service
from .errors import SelfServiceNetworkRestrictedError
from .schemas import (
    AuthRequest,
    CreateApplicationRequest,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/self-service", tags=["self-service"])


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _client_ip(request: Request) -> str:
    """Best-effort client IP extraction."""
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        # TM-008: Use rightmost hop (trusted reverse proxy), not leftmost
        # attacker-controlled value.
        return forwarded.split(",")[-1].strip()
    if request.client:
        return request.client.host
    return "unknown"


def _check_network_boundary(request: Request) -> None:
    """TM-008: Enforce self-service network boundary policy.

    If ``self_service_allowed_ips`` is configured (non-empty), only requests
    from those IPs are allowed. Requests from other IPs are denied with 403.

    If ``self_service_allowed_ips`` is empty (default), no restriction is
    applied (backward compatible).

    Raises:
        SelfServiceNetworkRestrictedError: When client IP is not allowlisted.
    """
    settings = request.app.state.settings
    allowed_ips = getattr(settings, "self_service_allowed_ips", [])

    # Empty allowlist = no restriction (backward compatible default).
    # Production startup checks enforce non-empty SELF_SERVICE_ALLOWED_IPS.
    if not allowed_ips:
        return

    client_ip = _client_ip(request)

    if not _is_allowed_client_ip(client_ip=client_ip, allowed_ips=allowed_ips):
        logger.warning(
            "TM-008: Self-service access denied by network boundary policy",
            extra={
                "event": "self_service_network_denied",
                "threat_id": "TM-008",
                "client_ip": client_ip,
                "allowed_ips": allowed_ips,
                "path": request.url.path,
            },
        )
        raise SelfServiceNetworkRestrictedError(
            "Access restricted to authorized network sources"
        )


def _is_allowed_client_ip(*, client_ip: str, allowed_ips: list[str]) -> bool:
    """Return True if *client_ip* matches any exact IP or CIDR allowlist entry."""
    try:
        client_addr = ipaddress.ip_address(client_ip)
    except ValueError:
        return False

    for entry in allowed_ips:
        allow_entry = str(entry).strip()
        if not allow_entry:
            continue

        # CIDR/network allowlist entry.
        if "/" in allow_entry:
            try:
                if client_addr in ipaddress.ip_network(allow_entry, strict=False):
                    return True
            except ValueError:
                # Ignore malformed entries here; startup checks enforce validity in prod.
                continue
            continue

        # Exact IP entry.
        try:
            if client_addr == ipaddress.ip_address(allow_entry):
                return True
        except ValueError:
            # Backward-compatible exact string match fallback.
            if client_ip == allow_entry:
                return True

    return False


# ---------------------------------------------------------------------------
# Self-service dependencies
# ---------------------------------------------------------------------------


async def check_network_boundary_dep(request: Request) -> None:
    """Dependency: TM-008 network boundary check (runs BEFORE auth)."""
    _check_network_boundary(request)


async def get_self_service_auth(request: Request) -> str:
    """Validate self-service Bearer token.

    Extracts the token from the ``Authorization: Bearer <token>`` header
    and validates it against the in-memory token store.
    """
    auth_header = request.headers.get("Authorization", "")
    token: str | None = None
    if auth_header.startswith("Bearer "):
        token = auth_header.removeprefix("Bearer ").strip()

    if not service.validate_token(token):
        raise UnauthorizedError("Invalid authorization token")

    return token  # type: ignore[return-value]


NetworkBoundary = Annotated[None, Depends(check_network_boundary_dep)]
SelfServiceAuth = Annotated[str, Depends(get_self_service_auth)]


# ---------------------------------------------------------------------------
# POST /self-service/auth
# ---------------------------------------------------------------------------


@router.post("/auth")
async def authenticate(
    body: AuthRequest,
    request: Request,
    _network: NetworkBoundary,
):
    """Authenticate with the self-service password.

    Returns a bearer token that expires after 1 hour.
    Rate limited to 5 attempts per 5 minutes per IP.

    TM-008: Network boundary check is enforced before authentication.
    """
    settings = request.app.state.settings
    configured_password = getattr(settings, "self_service_password", "")
    ip = _client_ip(request)

    result = service.authenticate(
        password=body.password,
        configured_password=configured_password,
        ip=ip,
    )
    return result


# ---------------------------------------------------------------------------
# POST /self-service/applications
# ---------------------------------------------------------------------------


@router.post("/applications", status_code=201)
async def create_application(
    body: CreateApplicationRequest,
    _network: NetworkBoundary,
    _token: SelfServiceAuth,
    db: DbSession,
):
    """Create a new application via the self-service console."""
    return await service.create_application(
        db,
        name=body.name,
        slug=body.slug,
        description=body.description,
        webhook_url=body.webhook_url,
        allowed_origins=body.allowed_origins,
        settings=body.settings,
    )


# ---------------------------------------------------------------------------
# GET /self-service/applications
# ---------------------------------------------------------------------------


@router.get("/applications")
async def list_applications(
    _network: NetworkBoundary,
    _token: SelfServiceAuth,
    db: DbSession,
):
    """List all applications with masked API keys."""
    return await service.list_applications(db)


# ---------------------------------------------------------------------------
# GET /self-service/applications/{app_id}
# ---------------------------------------------------------------------------


@router.get("/applications/{id}")
async def get_application(
    id: str,
    _network: NetworkBoundary,
    _token: SelfServiceAuth,
    db: DbSession,
):
    """Get a single application by ID with masked API key."""
    return await service.get_application(db, id)


# ---------------------------------------------------------------------------
# POST /self-service/applications/{app_id}/rotate-key
# ---------------------------------------------------------------------------


@router.post("/applications/{id}/rotate-key")
async def rotate_key(
    id: str,
    _network: NetworkBoundary,
    _token: SelfServiceAuth,
    db: DbSession,
):
    """Rotate the legacy API key for an application."""
    return await service.rotate_key(db, id)


# ---------------------------------------------------------------------------
# POST /self-service/applications/{app_id}/rotate-key/{key_type}
# ---------------------------------------------------------------------------


@router.post("/applications/{id}/rotate-key/{type}")
async def rotate_typed_key(
    id: str,
    type: str,
    _network: NetworkBoundary,
    _token: SelfServiceAuth,
    db: DbSession,
):
    """Rotate a publishable or secret key for an application."""
    return await service.rotate_typed_key(db, id, type)


# ---------------------------------------------------------------------------
# DELETE /self-service/applications/{app_id}
# ---------------------------------------------------------------------------


@router.delete("/applications/{id}")
async def delete_application(
    id: str,
    _network: NetworkBoundary,
    _token: SelfServiceAuth,
    db: DbSession,
):
    """Delete an application."""
    return await service.delete_application(db, id)
