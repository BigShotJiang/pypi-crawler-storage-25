"""Pydantic request/response schemas for the self-service domain.

Covers all 7 endpoints:
- POST /auth (password authentication)
- POST /applications (create)
- GET  /applications (list)
- GET  /applications/{app_id} (detail)
- POST /applications/{app_id}/rotate-key (legacy rotation)
- POST /applications/{app_id}/rotate-key/{key_type} (typed rotation)
- DELETE /applications/{app_id} (delete)
"""

from __future__ import annotations

import re
from typing import Any

from pydantic import BaseModel, field_validator


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------


class AuthRequest(BaseModel):
    """Request body for ``POST /self-service/auth``."""

    password: str


class AuthResponse(BaseModel):
    """Response for ``POST /self-service/auth``."""

    token: str
    expiresAt: str
    message: str


# ---------------------------------------------------------------------------
# Create application
# ---------------------------------------------------------------------------

_SLUG_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
_URL_RE = re.compile(r"^https?://")


class CreateApplicationRequest(BaseModel):
    """Request body for ``POST /self-service/applications``."""

    name: str
    slug: str
    description: str | None = None
    webhook_url: str | None = None
    allowed_origins: list[str] | None = None
    settings: dict[str, Any] | None = None

    @field_validator("name")
    @classmethod
    def _name_not_empty(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("name must be a non-empty string")
        return v.strip()

    @field_validator("slug")
    @classmethod
    def _slug_format(cls, v: str) -> str:
        if not _SLUG_RE.match(v):
            raise ValueError(
                "slug must contain only lowercase letters, numbers, and hyphens"
            )
        return v

    @field_validator("allowed_origins")
    @classmethod
    def _origins_format(cls, v: list[str] | None) -> list[str] | None:
        if v is None:
            return v
        for origin in v:
            if not _URL_RE.match(origin):
                raise ValueError(
                    f"Each allowed_origin must be a valid http/https URL, got: {origin}"
                )
        return v


class ApplicationOut(BaseModel):
    """Application projection returned in self-service responses."""

    id: str
    name: str
    slug: str
    description: str | None = None
    webhook_url: str | None = None
    allowed_origins: list[str] | None = None
    settings: dict[str, Any] | None = None
    created_at: str | None = None
    updated_at: str | None = None
    api_key: str | None = None


class CreateApplicationResponse(BaseModel):
    """Response for ``POST /self-service/applications``."""

    application: ApplicationOut
    publishable_key: str
    secret_key: str
    api_key: str
    warning: str


# ---------------------------------------------------------------------------
# List applications
# ---------------------------------------------------------------------------


class ListApplicationsResponse(BaseModel):
    """Response for ``GET /self-service/applications``."""

    applications: list[ApplicationOut]
    total: int


# ---------------------------------------------------------------------------
# Get application
# ---------------------------------------------------------------------------


class GetApplicationResponse(BaseModel):
    """Response for ``GET /self-service/applications/{app_id}``."""

    application: ApplicationOut


# ---------------------------------------------------------------------------
# Rotate key (legacy)
# ---------------------------------------------------------------------------


class RotateKeyResponse(BaseModel):
    """Response for ``POST /self-service/applications/{app_id}/rotate-key``."""

    api_key: str
    warning: str


# ---------------------------------------------------------------------------
# Rotate key (typed)
# ---------------------------------------------------------------------------


class RotateTypedKeyResponse(BaseModel):
    """Response for ``POST /self-service/applications/{app_id}/rotate-key/{key_type}``."""

    key: str
    key_type: str
    warning: str


# ---------------------------------------------------------------------------
# Delete application
# ---------------------------------------------------------------------------


class DeleteApplicationResponse(BaseModel):
    """Response for ``DELETE /self-service/applications/{app_id}``."""

    message: str
    application_name: str
