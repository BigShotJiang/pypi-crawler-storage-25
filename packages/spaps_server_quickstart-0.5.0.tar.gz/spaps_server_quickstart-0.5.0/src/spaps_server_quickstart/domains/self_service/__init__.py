"""Self-service domain -- password-protected admin console for managing applications."""

from .router import router

__all__ = ["router"]
