"""Pydantic request/response schemas for auth endpoints.

These schemas define the *data* portion of each API response.
The standard response envelope ``{ success, data, error, metadata }``
is applied by middleware — domain schemas never reference it.

Zero FastAPI imports.
"""

from __future__ import annotations

from pydantic import BaseModel, EmailStr


# ---------------------------------------------------------------------------
# Request schemas
# ---------------------------------------------------------------------------


class LoginRequest(BaseModel):
    """POST /auth/login"""

    email: EmailStr
    password: str


class RegisterRequest(BaseModel):
    """POST /auth/register"""

    email: EmailStr
    password: str
    username: str | None = None
    phone_number: str | None = None
    referral_click_id: str | None = None
    ref: str | None = None


class RefreshRequest(BaseModel):
    """POST /auth/refresh"""

    refresh_token: str


class NonceRequest(BaseModel):
    """POST /auth/nonce — request a wallet-auth nonce."""

    wallet_address: str


class WalletSignInRequest(BaseModel):
    """POST /auth/wallet/sign-in"""

    wallet_address: str
    signature: str
    message: str
    chain_type: str | None = None
    username: str | None = None


class MagicLinkRequest(BaseModel):
    """POST /auth/magic-link"""

    email: EmailStr
    redirect_url: str | None = None
    state: str | None = None
    generate_state: bool | None = None


class VerifyMagicLinkRequest(BaseModel):
    """POST /auth/magic-link/verify"""

    token: str
    type: str
    state: str | None = None


class PasswordResetRequest(BaseModel):
    """POST /auth/password-reset"""

    email: EmailStr
    redirect_url: str | None = None


class ResetPasswordConfirmRequest(BaseModel):
    """POST /auth/password-reset/confirm"""

    token: str
    new_password: str


class SetPasswordRequest(BaseModel):
    """POST /auth/set-password (authenticated)"""

    current_password: str | None = None
    new_password: str


# ---------------------------------------------------------------------------
# Response schemas
# ---------------------------------------------------------------------------


class UserResponse(BaseModel):
    """Canonical user representation returned by most auth endpoints."""

    id: str
    username: str | None = None
    email: str | None = None
    phone_number: str | None = None
    wallets: list[dict] | None = None
    tier: str | None = None
    roles: list[str] | None = None
    permissions: list[str] | None = None
    isAdmin: bool = False
    metadata: dict | None = None


class LoginResponse(BaseModel):
    """POST /auth/login — success payload."""

    access_token: str
    refresh_token: str
    expires_in: int
    token_type: str = "Bearer"
    user: UserResponse


class RegisterTokens(BaseModel):
    """Token sub-object for registration auto-login."""

    access_token: str
    refresh_token: str | None = None
    expires_in: int | None = None


class RegisterResponse(BaseModel):
    """POST /auth/register — success payload.

    Tokens may be ``None`` when email confirmation is required before
    issuing credentials.
    """

    tokens: RegisterTokens | None = None
    token_type: str = "Bearer"
    user: UserResponse
    email_confirmed: bool = False


class RefreshResponse(BaseModel):
    """POST /auth/refresh — success payload."""

    access_token: str
    refresh_token: str
    expires_in: int
    token_type: str = "Bearer"


class LogoutResponse(BaseModel):
    """POST /auth/logout — success payload."""

    message: str = "Successfully logged out"


class NonceResponse(BaseModel):
    """POST /auth/nonce — success payload."""

    nonce: str
    message: str
    wallet_address: str
    expires_at: str


class WalletSignInResponse(BaseModel):
    """POST /auth/wallet/sign-in — success payload."""

    access_token: str
    refresh_token: str
    expires_in: int
    token_type: str = "Bearer"
    user: UserResponse
    is_new_user: bool


class MagicLinkResponse(BaseModel):
    """POST /auth/magic-link — success payload."""

    message: str
    email: str
    sent_at: str
    state: str | None = None


class VerifyMagicLinkTokens(BaseModel):
    """Token sub-object for magic-link verification."""

    access_token: str
    refresh_token: str
    expires_in: int


class VerifyMagicLinkResponse(BaseModel):
    """POST /auth/magic-link/verify — success payload."""

    tokens: VerifyMagicLinkTokens
    token_type: str = "Bearer"
    user: UserResponse


class PasswordResetResponse(BaseModel):
    """POST /auth/password-reset — success payload."""

    email: str
    sent_at: str


class ResetPasswordConfirmResponse(BaseModel):
    """POST /auth/password-reset/confirm — success payload."""

    message: str


class SetPasswordResponse(BaseModel):
    """POST /auth/set-password — success payload."""

    message: str


class GetUserResponse(BaseModel):
    """GET /auth/me — success payload."""

    user: UserResponse
