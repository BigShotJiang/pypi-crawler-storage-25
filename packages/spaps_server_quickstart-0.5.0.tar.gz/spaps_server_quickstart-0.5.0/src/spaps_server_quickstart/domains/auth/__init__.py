"""Authentication domain — orchestrator for all auth flows.

Re-exports the router for app-level inclusion and the service
module for programmatic access.
"""

from .router import router

__all__ = ["router"]
