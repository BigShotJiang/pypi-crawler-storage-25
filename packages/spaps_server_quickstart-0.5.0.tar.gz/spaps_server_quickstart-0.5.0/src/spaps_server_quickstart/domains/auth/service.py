"""Orchestration service for the auth domain.

Each public function implements a complete auth flow by coordinating
across repositories and session services (JWT, password, nonce,
blacklist, admin detection).  Functions accept an ``AsyncSession`` and
a ``SpapsSettings`` instance so the router controls the transaction
boundary and configuration injection.

This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import hashlib
import logging
import re
import secrets
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING, Any
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from ..errors import (
    EmailAlreadyExistsError,
    InvalidCredentialsError,
    InvalidMessageFormatError,
    InvalidRefreshTokenError,
    InvalidSignatureError,
    InvalidTokenError,
    NotFoundError,
)
from ..sessions import blacklist_service, nonce_service, password_service
from ..sessions.admin_detection import (
    get_admin_permissions,
    get_user_roles,
    is_admin_user,
    is_super_admin,
)
from ..sessions.jwt_service import (
    TokenPair,
    generate_token_pair,
    parse_duration,
    verify_refresh_token,
)
from ..wallets.chains.dispatcher import (
    extract_chain_from_address,
    verify_wallet_signature,
)
from . import repository as repo

if TYPE_CHECKING:
    from ...spaps_settings import SpapsSettings

logger = logging.getLogger(__name__)

# Regex to extract the nonce from a SIWE-style signed message.
_NONCE_RE = re.compile(r"Nonce:\s*([a-fA-F0-9]+)")

# Token type normalisation map — multiple aliases map to the canonical names.
_TOKEN_TYPE_MAP = {
    "magiclink": "magiclink",
    "magic_link": "magiclink",
    "magic-link": "magiclink",
    "recovery": "recovery",
    "password_reset": "recovery",
    "password-reset": "recovery",
}


def _normalize_token_type(t: str) -> str:
    """Normalise a token type string to its canonical form."""
    return _TOKEN_TYPE_MAP.get(t.lower(), t.lower())


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _build_user_response(
    user: Any,
    *,
    wallets: list[Any] | None = None,
    roles: list[str] | None = None,
    permissions: list[str] | None = None,
    is_admin_flag: bool = False,
    wallets_as_strings: bool = False,
) -> dict[str, Any]:
    """Build the canonical ``UserResponse`` dict from a User model.

    Centralises the mapping so every endpoint returns a consistent
    shape.

    When *wallets_as_strings* is ``True`` the ``wallets`` field is a
    plain list of address strings (used by login / wallet-sign-in
    responses where the SDK expects ``list[str]``).  Otherwise full
    wallet objects are returned (matching the ``/auth/user`` profile
    endpoint).
    """
    wallet_value: list[dict[str, Any]] | list[str] | None = None
    if wallets:
        if wallets_as_strings:
            wallet_value = [w.wallet_address for w in wallets]
        else:
            wallet_value = [
                {
                    "wallet_address": w.wallet_address,
                    "chain_type": w.chain_type,
                    "verified": w.is_primary,
                }
                for w in wallets
            ]

    return {
        "id": str(user.id),
        "username": user.username,
        "email": user.email,
        "phone_number": getattr(user, "phone_number", None),
        "wallets": wallet_value,
        "tier": user.tier or "basic",
        "roles": roles or ["user"],
        "permissions": permissions or ["view_products"],
        "isAdmin": is_admin_flag,
        "metadata": getattr(user, "metadata_", None),
    }


def _extract_nonce_from_message(message: str) -> str:
    """Extract the hex nonce from a SIWE-style signed message.

    Raises :class:`InvalidMessageFormatError` if no nonce is found.
    """
    match = _NONCE_RE.search(message)
    if not match:
        raise InvalidMessageFormatError("No nonce found in signed message")
    return match.group(1)


def _upsert_query_params(url: str, **params: str) -> str:
    """Return ``url`` with query params added/replaced."""
    split = urlsplit(url)
    query = dict(parse_qsl(split.query, keep_blank_values=True))
    query.update(params)
    return urlunsplit(
        (split.scheme, split.netloc, split.path, urlencode(query), split.fragment)
    )


def _sanitize_absolute_redirect_url(candidate: str | None) -> str | None:
    """Return a cleaned absolute HTTP(S) URL or ``None``."""
    if not isinstance(candidate, str):
        return None
    cleaned = candidate.strip()
    if not cleaned:
        return None
    split = urlsplit(cleaned)
    if split.scheme.lower() not in {"http", "https"} or not split.netloc:
        return None
    return cleaned


def _is_same_origin_url(left: str, right: str) -> bool:
    """Check whether two absolute URLs share the same scheme + host[:port]."""
    left_split = urlsplit(left)
    right_split = urlsplit(right)
    return (
        left_split.scheme.lower() == right_split.scheme.lower()
        and left_split.netloc.lower() == right_split.netloc.lower()
    )


def _is_disallowed_magic_link_redirect_url(url: str) -> bool:
    """Reject login-page redirects for magic-link email actions."""
    path = urlsplit(url).path.strip().lower().rstrip("/")
    if not path:
        path = "/"
    return path in {"/login", "/auth/login", "/signin", "/sign-in"}


async def _resolve_application_email_redirect_url(
    db: AsyncSession,
    application_id: str | None,
    *,
    requested_redirect_url: str | None = None,
    channel: str | None = None,
) -> str | None:
    """Resolve a safe redirect URL from ``applications.settings``.

    Resolution order:
    1. Channel-specific setting (`magic_link_redirect_url`/`password_reset_redirect_url`)
    2. Legacy shared setting (`email_redirect_url`)
    3. `None` (caller falls back to service defaults)

    A client-provided redirect may override only when:
    - it is an absolute HTTP(S) URL, and
    - it matches the origin of the resolved app redirect.
    """
    if not application_id:
        return None

    requested = _sanitize_absolute_redirect_url(requested_redirect_url)

    try:
        from ..applications import repository as app_repo

        app = await app_repo.get_application_by_id(db, application_id)
    except Exception:
        logger.debug(
            "Could not resolve application redirect URL for application %s",
            application_id,
            exc_info=True,
        )
        return None

    if app is None:
        return None

    settings_blob = getattr(app, "settings", None)
    if not isinstance(settings_blob, dict):
        return None

    channel_redirect_keys: tuple[str, ...] = ()
    if channel == "magic_link":
        channel_redirect_keys = ("magic_link_redirect_url", "magic_link_email_redirect_url")
    elif channel == "password_reset":
        channel_redirect_keys = ("password_reset_redirect_url", "password_reset_email_redirect_url")

    resolved: str | None = None

    for key in channel_redirect_keys:
        candidate = settings_blob.get(key)
        if isinstance(candidate, str):
            resolved = _sanitize_absolute_redirect_url(candidate)
            if resolved:
                break

    if resolved is None:
        legacy = settings_blob.get("email_redirect_url")
        if isinstance(legacy, str):
            resolved = _sanitize_absolute_redirect_url(legacy)

    requested_same_origin = (
        requested if requested and resolved and _is_same_origin_url(requested, resolved) else None
    )

    if channel == "magic_link":
        if requested_same_origin and not _is_disallowed_magic_link_redirect_url(requested_same_origin):
            return requested_same_origin
        if resolved and _is_disallowed_magic_link_redirect_url(resolved):
            logger.warning("Ignoring disallowed magic-link redirect URL", extra={"redirect_url": resolved})
            return None

    if requested_same_origin:
        return requested_same_origin

    return resolved


async def _generate_and_store_tokens(
    db: AsyncSession,
    user: Any,
    settings: SpapsSettings,
    *,
    application_id: str | None = None,
    wallets: list[str] | None = None,
    roles: list[str] | None = None,
    permissions: list[str] | None = None,
    is_admin_flag: bool = False,
    is_super_admin_flag: bool = False,
    client_ip: str | None = None,
    user_agent: str | None = None,
) -> TokenPair:
    """Generate a token pair and persist the refresh token in the DB.

    TM-011: Stores network context (IP, user agent) for anomaly detection.
    """
    token_pair = generate_token_pair(
        user_id=str(user.id),
        application_id=application_id or "",
        email=user.email,
        wallets=wallets,
        tier=user.tier or "basic",
        roles=roles,
        permissions=permissions,
        is_admin=is_admin_flag,
        is_super_admin=is_super_admin_flag,
        access_secret=settings.jwt_secret,
        refresh_secret=settings.refresh_token_secret,
        access_expires_in=settings.jwt_expires_in,
        refresh_expires_in=settings.jwt_refresh_expires_in,
    )

    # Persist refresh token with network context (TM-011)
    refresh_ttl = parse_duration(settings.jwt_refresh_expires_in)
    await repo.store_refresh_token(
        db,
        user_id=str(user.id),
        application_id=application_id,
        token=token_pair.refresh_token,
        expires_at=datetime.now(UTC) + timedelta(seconds=refresh_ttl),
        issued_ip=client_ip,
        issued_user_agent=user_agent,
    )

    return token_pair


def _resolve_roles_and_permissions(
    user: Any,
    wallet_addresses: list[str] | None = None,
) -> tuple[list[str], list[str], bool, bool]:
    """Compute roles, permissions, and admin flags for a user.

    Returns ``(roles, permissions, is_admin, is_super_admin)``.
    """
    roles = get_user_roles(
        email=user.email,
        user_id=str(user.id),
        wallet_addresses=wallet_addresses,
    )
    permissions = get_admin_permissions(roles)
    admin = is_admin_user(
        email=user.email,
        user_id=str(user.id),
        wallet_addresses=wallet_addresses,
    )
    super_admin = is_super_admin(
        email=user.email,
        user_id=str(user.id),
    )
    return roles, permissions, admin, super_admin


async def _attribute_signup_referral(
    db: AsyncSession,
    *,
    user_id: UUID,
    application_id: str | None,
    referral_click_id: str | None = None,
    referral_slug: str | None = None,
) -> None:
    """Best-effort referral attribution for user signup."""
    if not application_id or (not referral_click_id and not referral_slug):
        return

    try:
        app_uuid = UUID(application_id)
        click_uuid = UUID(referral_click_id) if referral_click_id else None
    except ValueError:
        logger.warning(
            "Skipping signup referral attribution due to invalid UUIDs",
            extra={
                "application_id": application_id,
                "referral_click_id": referral_click_id,
            },
        )
        return

    from ..affiliate_referrals import service as affiliate_referral_service
    from ..affiliate_referrals.errors import (
        AffiliateNotFoundError,
        AlreadyAttributedError,
        ClickExpiredError,
        ClickNotFoundError,
        SelfReferralError,
    )

    try:
        await affiliate_referral_service.attribute_referral(
            db,
            referred_entity_type="user",
            referred_entity_id=user_id,
            click_id=click_uuid,
            slug=referral_slug,
            application_id=app_uuid,
        )
    except (
        AffiliateNotFoundError,
        AlreadyAttributedError,
        ClickExpiredError,
        ClickNotFoundError,
        SelfReferralError,
    ):
        logger.info(
            "Signup referral attribution skipped",
            extra={
                "user_id": str(user_id),
                "application_id": str(app_uuid),
                "has_click_id": bool(click_uuid),
                "has_slug": bool(referral_slug),
            },
        )
    except Exception:
        logger.exception(
            "Unexpected error during signup referral attribution",
            extra={"user_id": str(user_id), "application_id": str(app_uuid)},
        )


# ---------------------------------------------------------------------------
# Public API — auth flows
# ---------------------------------------------------------------------------


async def login(
    db: AsyncSession,
    settings: SpapsSettings,
    *,
    email: str,
    password: str,
    application_id: str | None = None,
    device_info: str | None = None,
    ip_address: str | None = None,
) -> dict[str, Any]:
    """Email/password login.

    Steps:
        1. Find user by email.
        2. Verify password.
        3. Resolve admin status, roles, permissions.
        4. Generate and store token pair.
        5. Return ``LoginResponse``-shaped dict.

    Raises :class:`InvalidCredentialsError` on bad email or password.
    """
    user = await repo.find_user_for_login(db, email)
    if user is None:
        raise InvalidCredentialsError("Invalid email or password")

    if not user.password_hash:
        raise InvalidCredentialsError("Invalid email or password")

    if not password_service.verify_password(password, user.password_hash):
        raise InvalidCredentialsError("Invalid email or password")

    # TM-001: Only grant admin roles to email-confirmed users.
    # Unconfirmed accounts get basic "user" role regardless of admin lists.
    if user.email_confirmed_at is not None:
        roles, permissions, admin, super_admin = _resolve_roles_and_permissions(user)
    else:
        roles, permissions, admin, super_admin = ["user"], ["view_products"], False, False

    token_pair = await _generate_and_store_tokens(
        db, user, settings,
        application_id=application_id,
        roles=roles,
        permissions=permissions,
        is_admin_flag=admin,
        is_super_admin_flag=super_admin,
        client_ip=ip_address,
        user_agent=device_info,
    )

    # Update last sign-in
    user.last_sign_in_at = datetime.now(UTC)
    await db.flush()

    logger.info("Login successful user_id=%s email=%s", user.id, email)

    return {
        "access_token": token_pair.access_token,
        "refresh_token": token_pair.refresh_token,
        "expires_in": token_pair.expires_in,
        "token_type": "Bearer",
        "user": _build_user_response(
            user,
            roles=roles,
            permissions=permissions,
            is_admin_flag=admin,
            wallets_as_strings=True,
        ),
    }


async def register(
    db: AsyncSession,
    settings: SpapsSettings,
    *,
    email: str,
    password: str,
    username: str | None = None,
    phone_number: str | None = None,
    application_id: str | None = None,
    device_info: str | None = None,
    ip_address: str | None = None,
    referral_click_id: str | None = None,
    referral_slug: str | None = None,
) -> dict[str, Any]:
    """Create a new user account.

    Steps:
        1. Check email is not already registered.
        2. Validate password strength.
        3. Hash password.
        4. Create user record.
        5. Optionally generate tokens (auto-confirm in dev).
        6. Return ``RegisterResponse``-shaped dict.

    Raises :class:`EmailAlreadyExistsError` or :class:`WeakPasswordError`.
    """
    from ..users import repository as user_repo

    existing = await user_repo.get_user_by_email(db, email)
    if existing is not None:
        raise EmailAlreadyExistsError("Email already registered")

    password_service.validate_password_strength(password)
    hashed = password_service.hash_password(password)

    user = await user_repo.create_user(
        db,
        email=email,
        password_hash=hashed,
        username=username,
        phone_number=phone_number,
    )

    await _attribute_signup_referral(
        db,
        user_id=user.id,
        application_id=application_id,
        referral_click_id=referral_click_id,
        referral_slug=referral_slug,
    )

    roles, permissions, admin, super_admin = _resolve_roles_and_permissions(user)

    # In non-production or when email confirmation is not enforced,
    # auto-confirm and issue tokens immediately.
    auto_confirm = settings.env in ("dev", "development", "test")
    access_token: str | None = None
    refresh_token: str | None = None

    if auto_confirm:
        user.email_confirmed_at = datetime.now(UTC)
        user.confirmed_at = datetime.now(UTC)
        await db.flush()

        token_pair = await _generate_and_store_tokens(
            db, user, settings,
            application_id=application_id,
            roles=roles,
            permissions=permissions,
            is_admin_flag=admin,
            is_super_admin_flag=super_admin,
            client_ip=ip_address,
            user_agent=device_info,
        )
        access_token = token_pair.access_token
        refresh_token = token_pair.refresh_token

    logger.info(
        "Registration successful user_id=%s email=%s auto_confirm=%s",
        user.id, email, auto_confirm,
    )

    tokens: dict[str, Any] | None = None
    if access_token:
        tokens = {
            "access_token": access_token,
            "refresh_token": refresh_token,
            "expires_in": token_pair.expires_in if auto_confirm else None,
        }

    return {
        "tokens": tokens,
        "token_type": "Bearer",
        "user": _build_user_response(
            user,
            roles=roles,
            permissions=permissions,
            is_admin_flag=admin,
            wallets_as_strings=True,
        ),
        "email_confirmed": auto_confirm,
    }


async def _load_refresh_payload_and_token(
    db: AsyncSession,
    *,
    settings: SpapsSettings,
    refresh_token_str: str,
    application_id: str | None,
) -> tuple[Any, Any]:
    payload = verify_refresh_token(refresh_token_str, settings.refresh_token_secret)

    if application_id and payload.app_id and application_id != payload.app_id:
        raise InvalidRefreshTokenError("Refresh token application mismatch")

    if await blacklist_service.is_blacklisted(db, payload.jti):
        raise InvalidRefreshTokenError("Refresh token has been revoked")

    db_token = await repo.find_refresh_token_for_update(db, refresh_token_str)
    if db_token is None:
        raise InvalidRefreshTokenError("Refresh token not found or already used")

    return payload, db_token


def _hash_user_agent(user_agent: str | None) -> str | None:
    if not user_agent or not isinstance(user_agent, str):
        return None
    return hashlib.sha256(user_agent.encode()).hexdigest()[:16]


async def _detect_refresh_token_anomaly(
    db: AsyncSession,
    *,
    db_token: Any,
    payload: Any,
    settings: SpapsSettings,
    refresh_token_str: str,
    client_ip: str | None,
    user_agent: str | None,
) -> bool:
    if not (db_token.issued_ip and db_token.issued_user_agent and client_ip and user_agent):
        return False

    ip_changed = db_token.last_seen_ip != client_ip
    ua_changed = db_token.last_seen_user_agent != user_agent
    if not (ip_changed or ua_changed):
        return False

    enforcement_enabled = getattr(settings, "refresh_anomaly_enforcement_enabled", False) is True
    should_block = enforcement_enabled and ua_changed
    decision = "blocked" if should_block else "alert"
    db_token.anomaly_state = decision

    log_extra = {
        "threat_id": "TM-011",
        "event": "refresh_token_anomaly",
        "user_id": payload.sub,
        "app_id": payload.app_id,
        "jti": payload.jti,
        "decision": decision,
        "reason": f"ip_changed={ip_changed}, ua_changed={ua_changed}",
        "stored_ip": db_token.last_seen_ip,
        "current_ip": client_ip,
        "stored_ua_hash": _hash_user_agent(db_token.last_seen_user_agent),
        "current_ua_hash": _hash_user_agent(user_agent),
    }

    if should_block:
        logger.error(
            "Refresh token anomaly detected: user_id=%s decision=%s reason=%s",
            payload.sub,
            decision,
            log_extra["reason"],
            extra=log_extra,
        )
        await repo.revoke_refresh_token(db, refresh_token_str)
        raise InvalidRefreshTokenError(
            "Network context anomaly detected (IP or user agent changed)",
            code="REFRESH_TOKEN_ANOMALOUS",
        )

    logger.warning(
        "Refresh token anomaly detected: user_id=%s decision=%s reason=%s",
        payload.sub,
        decision,
        log_extra["reason"],
        extra=log_extra,
    )
    return True


def _log_refresh_event(
    *,
    payload: Any,
    client_ip: str | None,
    user_agent: str | None,
    anomaly_detected: bool,
) -> None:
    ua_hash = _hash_user_agent(user_agent)
    logger.info(
        "Token refresh event: user_id=%s app_id=%s jti=%s client_ip=%s user_agent_hash=%s anomaly=%s",
        payload.sub,
        payload.app_id,
        payload.jti,
        client_ip or "unknown",
        ua_hash or "none",
        anomaly_detected,
        extra={
            "event": "token_refresh",
            "user_id": payload.sub,
            "app_id": payload.app_id,
            "jti": payload.jti,
            "client_ip": client_ip,
            "user_agent_hash": ua_hash,
            "anomaly_detected": anomaly_detected,
        },
    )


async def _revoke_refresh_token_or_raise_replay(
    db: AsyncSession,
    *,
    payload: Any,
    refresh_token_str: str,
) -> None:
    revoked = await repo.revoke_refresh_token(db, refresh_token_str)
    if revoked:
        return

    logger.warning(
        "Refresh token replay detected: user_id=%s jti=%s — revoking all sessions",
        payload.sub,
        payload.jti,
        extra={
            "threat_id": "TM-011",
            "event": "refresh_token_replay",
            "user_id": payload.sub,
            "app_id": payload.app_id,
            "jti": payload.jti,
        },
    )
    await repo.revoke_all_user_refresh_tokens(db, payload.sub)
    raise InvalidRefreshTokenError(
        "Refresh token already consumed (possible replay)",
        code="REFRESH_TOKEN_REPLAY",
    )


async def refresh_tokens(
    db: AsyncSession,
    settings: SpapsSettings,
    *,
    refresh_token_str: str,
    application_id: str | None = None,
    device_info: str | None = None,
    ip_address: str | None = None,
    client_ip: str | None = None,
    user_agent: str | None = None,
) -> dict[str, Any]:
    """Rotate a refresh token and issue a new token pair.

    Steps:
        1. Verify refresh token JWT signature and claims.
        2. Check the token is not blacklisted.
        3. Find the token in the database (must not be consumed).
        4. TM-011: Detect network context anomalies (IP/UA changes).
        5. Revoke the old token.
        6. Generate a new token pair.
        7. Store the new refresh token.
        8. Return ``RefreshResponse``-shaped dict.

    Raises :class:`InvalidRefreshTokenError` on any failure.

    TM-011: IP/UA anomaly tracking for stolen refresh token detection.
    """
    payload, db_token = await _load_refresh_payload_and_token(
        db,
        settings=settings,
        refresh_token_str=refresh_token_str,
        application_id=application_id,
    )
    anomaly_detected = await _detect_refresh_token_anomaly(
        db,
        db_token=db_token,
        payload=payload,
        settings=settings,
        refresh_token_str=refresh_token_str,
        client_ip=client_ip,
        user_agent=user_agent,
    )
    _log_refresh_event(
        payload=payload,
        client_ip=client_ip,
        user_agent=user_agent,
        anomaly_detected=anomaly_detected,
    )
    await _revoke_refresh_token_or_raise_replay(
        db,
        payload=payload,
        refresh_token_str=refresh_token_str,
    )

    # Look up user for fresh role/permission calculation
    from ..users import repository as user_repo

    user = await user_repo.get_user_by_id(db, payload.sub)
    if user is None:
        raise InvalidRefreshTokenError("User no longer exists")

    roles, permissions, admin, super_admin = _resolve_roles_and_permissions(user)

    # Update last_seen context on the db_token before it's revoked (for audit trail)
    if client_ip or user_agent:
        db_token.last_seen_ip = client_ip or db_token.last_seen_ip
        db_token.last_seen_user_agent = user_agent or db_token.last_seen_user_agent
        await db.flush()

    token_pair = await _generate_and_store_tokens(
        db, user, settings,
        application_id=application_id or payload.app_id,
        roles=roles,
        permissions=permissions,
        is_admin_flag=admin,
        is_super_admin_flag=super_admin,
        client_ip=client_ip,
        user_agent=user_agent,
    )

    logger.info("Token refresh successful user_id=%s", payload.sub)

    return {
        "access_token": token_pair.access_token,
        "refresh_token": token_pair.refresh_token,
        "expires_in": token_pair.expires_in,
        "token_type": "Bearer",
    }


async def wallet_sign_in(
    db: AsyncSession,
    settings: SpapsSettings,
    *,
    wallet_address: str,
    signature: str,
    message: str,
    chain_type: str | None = None,
    username: str | None = None,
    application_id: str | None = None,
    device_info: str | None = None,
    ip_address: str | None = None,
) -> dict[str, Any]:
    """Wallet-based sign-in (Solana, Ethereum, etc.).

    Steps:
        1. Auto-detect chain if not provided.
        2. Verify cryptographic signature.
        3. Extract and validate nonce from the signed message.
        4. Find or create user + wallet.
        5. Generate token pair.
        6. Return ``WalletSignInResponse``-shaped dict.

    Raises domain errors on invalid signature, nonce, or unsupported chain.
    """
    # 1. Detect chain
    if chain_type is None:
        chain_type = extract_chain_from_address(wallet_address)

    # 2. Verify signature
    result = verify_wallet_signature(wallet_address, signature, message, chain_type)
    if not result.get("valid"):
        raise InvalidSignatureError(
            result.get("error", "Wallet signature verification failed")
        )

    # 3. Extract and validate nonce
    nonce = _extract_nonce_from_message(message)
    await nonce_service.validate_nonce(db, wallet_address, nonce)

    # 4. Find or create user
    user, wallet = await repo.find_user_by_wallet(db, wallet_address, chain_type)
    is_new_user = False

    if user is None:
        user, wallet = await repo.create_user_with_wallet(
            db, wallet_address, chain_type, username=username,
        )
        is_new_user = True

    # 5. Resolve roles/permissions
    wallet_addresses = [wallet_address]
    roles, permissions, admin, super_admin = _resolve_roles_and_permissions(
        user, wallet_addresses=wallet_addresses,
    )

    # 6. Generate tokens
    token_pair = await _generate_and_store_tokens(
        db, user, settings,
        application_id=application_id,
        wallets=wallet_addresses,
        roles=roles,
        permissions=permissions,
        is_admin_flag=admin,
        is_super_admin_flag=super_admin,
        client_ip=ip_address,
        user_agent=device_info,
    )

    # Update last sign-in
    user.last_sign_in_at = datetime.now(UTC)
    await db.flush()

    logger.info(
        "Wallet sign-in successful user_id=%s chain=%s is_new=%s",
        user.id, chain_type, is_new_user,
    )

    return {
        "access_token": token_pair.access_token,
        "refresh_token": token_pair.refresh_token,
        "expires_in": token_pair.expires_in,
        "token_type": "Bearer",
        "user": _build_user_response(
            user,
            wallets=[wallet],
            roles=roles,
            permissions=permissions,
            is_admin_flag=admin,
            wallets_as_strings=True,
        ),
        "is_new_user": is_new_user,
    }


async def request_nonce(
    db: AsyncSession,
    *,
    wallet_address: str,
) -> dict[str, Any]:
    """Generate and store a wallet-auth nonce.

    Steps:
        1. Generate a cryptographic nonce.
        2. Store it in the database with a TTL.
        3. Build the human-readable sign-in message.
        4. Return ``NonceResponse``-shaped dict.
    """
    nonce = nonce_service.generate_nonce()
    expires_in = 300  # 5 minutes

    await nonce_service.store_nonce(db, wallet_address, nonce, expires_in=expires_in)

    message = nonce_service.create_auth_message(wallet_address, nonce)
    expires_at = datetime.now(UTC) + timedelta(seconds=expires_in)

    logger.debug("Nonce requested for wallet %s", wallet_address)

    return {
        "nonce": nonce,
        "message": message,
        "wallet_address": wallet_address,
        "expires_at": expires_at.isoformat(),
    }


async def request_magic_link(
    db: AsyncSession,
    settings: SpapsSettings,
    *,
    email: str,
    application_id: str | None = None,
    redirect_url: str | None = None,
    state: str | None = None,
    generate_state: bool = False,
) -> dict[str, Any]:
    """Request a magic-link email.

    Steps:
        1. Generate a magic-link token.
        2. Store the token hash in ``auth_tokens``.
        3. Optionally generate and store state.
        4. Send the email (or log in dev mode).
        5. Return ``MagicLinkResponse``-shaped dict.
    """
    # Generate the magic-link token
    token = await repo.create_auth_token(
        db,
        user_id=None,  # User may not exist yet
        email=email,
        token_type=_normalize_token_type("magic_link"),
        application_id=application_id,
        expires_in=3600,
    )

    # Generate state if requested
    result_state: str | None = state
    if generate_state and not state:
        result_state = secrets.token_urlsafe(16)

    if result_state:
        await repo.store_magic_link_state(
            db,
            state=result_state,
            email=email,
            application_id=application_id,
        )

    sent_at = datetime.now(UTC)

    # Build action URL from app-level redirect (if configured) with a safe fallback.
    magic_link_type = _normalize_token_type("magic_link")
    resolved_redirect_url = await _resolve_application_email_redirect_url(
        db,
        application_id,
        requested_redirect_url=redirect_url,
        channel="magic_link",
    )
    if resolved_redirect_url:
        link = _upsert_query_params(
            resolved_redirect_url,
            token=token,
            type=magic_link_type,
        )
    else:
        base = settings.auth_base_url.rstrip("/")
        link = _upsert_query_params(
            f"{base}/auth/confirm",
            token=token,
            type=magic_link_type,
        )

    # TM-011: Log token prefix only (never full token) for security
    if settings.env in ("dev", "development", "test"):
        token_prefix = token[:8] + "..." if len(token) > 8 else token
        redacted_link = _upsert_query_params(link, token=token_prefix)
        logger.info(
            "Magic link token (dev mode, redacted): %s for email %s",
            token_prefix, email,
        )
        logger.info("Magic link URL (dev mode, redacted): %s", redacted_link)

    # TM-ENV-001: Send email with environment safety gates
    # force_send=True is only effective in production; in dev/test, emails are logged but never sent
    try:
        from ..email import service as email_service

        # Convert application_id to UUID if present
        app_uuid = UUID(application_id) if application_id else None

        if app_uuid:
            await email_service.send_email(
                db,
                application_id=app_uuid,
                template_key="auth_magic_link",
                to=email,
                settings_env=settings.env,
                settings_local_mode=settings.is_spaps_local_mode,
                context={
                    "link": link,
                    "expires_in_minutes": 60,  # 3600 seconds = 60 minutes
                },
                force_send=True,
            )
            logger.info("Magic link email sent to %s", email)
        else:
            logger.warning(
                "Magic link requested for email %s but no application_id provided, skipping email",
                email,
            )
    except Exception as e:
        # Best-effort: log the error but don't fail the request
        logger.error(
            "Failed to send magic link email to %s: %s",
            email,
            str(e),
            exc_info=True,
        )

    return {
        "message": "Magic link sent successfully",
        "email": email,
        "sent_at": sent_at.isoformat(),
        "state": result_state,
    }


async def verify_magic_link(
    db: AsyncSession,
    settings: SpapsSettings,
    *,
    token: str,
    token_type: str,
    application_id: str | None = None,
    state: str | None = None,
    device_info: str | None = None,
    ip_address: str | None = None,
) -> dict[str, Any]:
    """Verify a magic-link token and sign the user in.

    Steps:
        1. Validate and consume the token from the database.
        2. Optionally validate the state parameter.
        3. Find or create the user by email.
        4. Generate token pair.
        5. Return ``VerifyMagicLinkResponse``-shaped dict.

    Raises :class:`InvalidTokenError` if the token is invalid, expired,
    or already consumed.
    """
    from ..users import service as user_service

    # Validate token (normalise type so aliases match)
    normalized_type = _normalize_token_type(token_type)
    auth_token = await repo.validate_and_consume_auth_token(db, token, normalized_type)
    if auth_token is None:
        raise InvalidTokenError("Invalid, expired, or already-used magic link")

    email = auth_token.email
    if not email:
        raise InvalidTokenError("Magic link token has no associated email")

    # Validate state if provided
    if state:
        ml_state = await repo.find_magic_link_state(db, state)
        if ml_state is None or ml_state.email != email:
            raise InvalidTokenError("Magic link state mismatch")

    # Find or create user
    user, _is_new = await user_service.find_or_create_user(db, email)

    # Confirm email on magic-link verification
    if user.email_confirmed_at is None:
        user.email_confirmed_at = datetime.now(UTC)
        user.confirmed_at = datetime.now(UTC)
        await db.flush()

    roles, permissions, admin, super_admin = _resolve_roles_and_permissions(user)

    token_pair = await _generate_and_store_tokens(
        db, user, settings,
        application_id=application_id,
        roles=roles,
        permissions=permissions,
        is_admin_flag=admin,
        is_super_admin_flag=super_admin,
        client_ip=ip_address,
        user_agent=device_info,
    )

    user.last_sign_in_at = datetime.now(UTC)
    await db.flush()

    logger.info("Magic link verified for email %s user_id=%s", email, user.id)

    return {
        "tokens": {
            "access_token": token_pair.access_token,
            "refresh_token": token_pair.refresh_token,
            "expires_in": token_pair.expires_in,
        },
        "token_type": "Bearer",
        "user": _build_user_response(
            user,
            roles=roles,
            permissions=permissions,
            is_admin_flag=admin,
            wallets_as_strings=True,
        ),
    }


async def request_password_reset(
    db: AsyncSession,
    settings: SpapsSettings,
    *,
    email: str,
    application_id: str | None = None,
    redirect_url: str | None = None,
) -> dict[str, Any]:
    """Request a password reset email.

    Steps:
        1. Find the user by email (silent no-op if not found for security).
        2. Generate a reset token.
        3. Store the token hash.
        4. Send email (or log in dev mode).
        5. Return ``PasswordResetResponse``-shaped dict.

    Always returns success to prevent email enumeration.
    """
    from ..users import repository as user_repo

    user = await user_repo.get_user_by_email(db, email)
    sent_at = datetime.now(UTC)

    if user is not None:
        token = await repo.create_auth_token(
            db,
            user_id=str(user.id),
            email=email,
            token_type=_normalize_token_type("password_reset"),
            application_id=application_id,
            expires_in=3600,
        )

        # TM-011: Log token prefix only (never full token) for security
        if settings.env in ("dev", "development", "test"):
            token_prefix = token[:8] + "..." if len(token) > 8 else token
            logger.info(
                "Password reset token (dev mode, redacted): %s for email %s",
                token_prefix, email,
            )

        # TM-ENV-001: Send email with environment safety gates
        # force_send=True is only effective in production; in dev/test, emails are logged but never sent
        try:
            from ..email import service as email_service

            # Build action URL from app-level redirect (if configured) with a
            # safe fallback to the legacy reset path.
            reset_link_type = _normalize_token_type("password_reset")
            resolved_redirect_url = await _resolve_application_email_redirect_url(
                db,
                application_id,
                requested_redirect_url=redirect_url,
                channel="password_reset",
            )
            if resolved_redirect_url:
                link = _upsert_query_params(
                    resolved_redirect_url,
                    token=token,
                    type=reset_link_type,
                )
            else:
                base = settings.auth_base_url.rstrip("/")
                link = _upsert_query_params(
                    f"{base}/auth/reset-password-confirm",
                    token=token,
                    type=reset_link_type,
                )

            # Convert application_id to UUID if present
            app_uuid = UUID(application_id) if application_id else None

            if app_uuid:
                await email_service.send_email(
                    db,
                    application_id=app_uuid,
                    template_key="auth_password_reset",
                    to=email,
                    settings_env=settings.env,
                    settings_local_mode=settings.is_spaps_local_mode,
                    context={
                        "link": link,
                        "expires_in_minutes": 60,  # 3600 seconds = 60 minutes
                    },
                    user_id=user.id,
                    force_send=True,
                )
                logger.info("Password reset email sent to %s", email)
            else:
                logger.warning(
                    "Password reset requested for email %s but no application_id provided, skipping email",
                    email,
                )
        except Exception as e:
            # Best-effort: log the error but don't fail the request
            logger.error(
                "Failed to send password reset email to %s: %s",
                email,
                str(e),
                exc_info=True,
            )
    else:
        logger.info(
            "Password reset requested for unknown email %s (silent no-op)",
            email,
        )

    return {
        "email": email,
        "sent_at": sent_at.isoformat(),
    }


async def confirm_password_reset(
    db: AsyncSession,
    settings: SpapsSettings,
    *,
    token: str,
    new_password: str,
) -> dict[str, Any]:
    """Confirm a password reset with a valid token.

    Steps:
        1. Validate and consume the reset token.
        2. Validate the new password strength.
        3. Hash and update the password.
        4. Revoke all existing sessions for the user.
        5. Return ``ResetPasswordConfirmResponse``-shaped dict.

    Raises :class:`InvalidTokenError` or :class:`WeakPasswordError`.
    """
    from ..users import service as user_service

    # Validate token (normalise type so aliases match)
    auth_token = await repo.validate_and_consume_auth_token(
        db, token, _normalize_token_type("password_reset"),
    )
    if auth_token is None:
        raise InvalidTokenError("Invalid, expired, or already-used reset token")

    user_id = auth_token.user_id
    if user_id is None:
        raise InvalidTokenError("Reset token has no associated user")

    # Validate and hash new password
    password_service.validate_password_strength(new_password)
    hashed = password_service.hash_password(new_password)

    # Update password
    await user_service.set_password(db, str(user_id), hashed)

    # Revoke all existing sessions
    await repo.revoke_all_user_refresh_tokens(db, str(user_id))
    await blacklist_service.blacklist_all_user_tokens(
        db, str(user_id), reason="password_change",
    )

    logger.info("Password reset confirmed for user_id=%s", user_id)

    return {
        "message": "Password has been reset successfully",
    }


async def set_password(
    db: AsyncSession,
    settings: SpapsSettings,
    *,
    user_id: str,
    current_password: str | None = None,
    new_password: str,
) -> dict[str, Any]:
    """Set or change a user's password.

    If the user already has a password, ``current_password`` must be
    provided and verified.  Wallet-only users setting a password for
    the first time may omit it.

    Steps:
        1. If user has a password, verify ``current_password``.
        2. Validate new password strength.
        3. Hash and update.
        4. Return ``SetPasswordResponse``-shaped dict.

    Raises :class:`InvalidCredentialsError` or :class:`WeakPasswordError`.
    """
    from ..users import repository as user_repo
    from ..users import service as user_service

    user = await user_repo.get_user_by_id(db, user_id)
    if user is None:
        raise NotFoundError(f"User {user_id} not found")

    # If user has an existing password, verify the current one
    if user.password_hash:
        if current_password is None:
            raise InvalidCredentialsError(
                "Current password is required to change password"
            )
        if not password_service.verify_password(current_password, user.password_hash):
            raise InvalidCredentialsError("Current password is incorrect")

    # Validate and hash new password
    password_service.validate_password_strength(new_password)
    hashed = password_service.hash_password(new_password)

    await user_service.set_password(db, user_id, hashed)

    logger.info("Password set/changed for user_id=%s", user_id)

    return {
        "message": "Password updated successfully",
    }


async def get_me(
    db: AsyncSession,
    *,
    user_id: str,
) -> dict[str, Any]:
    """Get the current user's profile with wallet information.

    Steps:
        1. Fetch user + wallets from the database.
        2. Resolve roles and permissions.
        3. Return ``GetUserResponse``-shaped dict.

    Raises :class:`NotFoundError` if the user does not exist.
    """
    user, wallets = await repo.find_user_with_wallets(db, user_id)
    if user is None:
        raise NotFoundError(f"User {user_id} not found")

    wallet_addresses = [w.wallet_address for w in wallets]
    roles, permissions, admin, _super_admin = _resolve_roles_and_permissions(
        user, wallet_addresses=wallet_addresses,
    )

    return {
        "user": _build_user_response(
            user,
            wallets=wallets,
            roles=roles,
            permissions=permissions,
            is_admin_flag=admin,
        ),
    }


async def logout(
    db: AsyncSession,
    *,
    user_id: str,
    access_token_jti: str,
    access_token_exp: int,
    refresh_token: str | None = None,
) -> dict[str, Any]:
    """Log out a user by revoking their tokens.

    Steps:
        1. Blacklist the access token by JTI.
        2. If a refresh token is provided, revoke it in the DB.
        3. Return ``LogoutResponse``-shaped dict.
    """
    # Blacklist the access token
    expires_at = datetime.fromtimestamp(access_token_exp, tz=UTC)
    await blacklist_service.blacklist_token(
        db,
        jti=access_token_jti,
        user_id=user_id,
        reason="logout",
        expires_at=expires_at,
    )

    # Revoke refresh token if provided
    if refresh_token:
        revoked = await repo.revoke_refresh_token(db, refresh_token)
        if not revoked:
            logger.debug(
                "Refresh token not found or already revoked during logout "
                "user_id=%s",
                user_id,
            )

    logger.info("Logout successful user_id=%s", user_id)

    return {
        "message": "Successfully logged out",
    }
