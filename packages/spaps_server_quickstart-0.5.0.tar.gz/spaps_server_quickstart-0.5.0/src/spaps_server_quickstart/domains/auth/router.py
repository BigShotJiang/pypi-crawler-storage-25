"""HTTP routes for the auth domain.

All endpoints live under the ``/auth`` prefix and implement the
complete SPAPS authentication contract: login, register, wallet
sign-in, token refresh, magic link, password reset, and profile.

The response envelope ``{ success, data, error, metadata }`` is
applied automatically by ``ResponseEnvelopeMiddleware`` -- handlers
return the raw *data* portion only.

Rate limiting tiers (applied via ``rate_limiting`` middleware):
    STRICT  (5/min) : login, register, password-reset, magic-link
    TIGHT  (10/min) : wallet/sign-in, nonce, refresh
    MODERATE (15/min): me, set-password, logout
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Request

from ...middleware.spaps_deps import Application, CurrentUser, DbSession
from . import service
from .schemas import (
    GetUserResponse,
    LoginRequest,
    LoginResponse,
    LogoutResponse,
    MagicLinkRequest,
    MagicLinkResponse,
    NonceRequest,
    NonceResponse,
    PasswordResetRequest,
    PasswordResetResponse,
    RefreshRequest,
    RefreshResponse,
    RegisterRequest,
    RegisterResponse,
    ResetPasswordConfirmRequest,
    ResetPasswordConfirmResponse,
    SetPasswordRequest,
    SetPasswordResponse,
    VerifyMagicLinkRequest,
    VerifyMagicLinkResponse,
    WalletSignInRequest,
    WalletSignInResponse,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/auth", tags=["auth"])


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _client_ip(request: Request) -> str | None:
    """Best-effort client IP extraction."""
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()
    if request.client:
        return request.client.host
    return None


def _device_info(request: Request) -> str | None:
    """Extract device info from User-Agent header."""
    return request.headers.get("User-Agent")


# ---------------------------------------------------------------------------
# Public endpoints (API-key authentication only)
# ---------------------------------------------------------------------------


@router.post("/login", response_model=LoginResponse)
async def login(
    body: LoginRequest,
    request: Request,
    db: DbSession,
    _app: Application,
) -> LoginResponse:
    """Authenticate with email and password.

    Returns an access/refresh token pair and the user profile.
    """
    settings = request.app.state.settings
    app_id = getattr(request.state, "application_id", None)

    result = await service.login(
        db, settings,
        email=body.email,
        password=body.password,
        application_id=app_id,
        device_info=_device_info(request),
        ip_address=_client_ip(request),
    )
    return LoginResponse(**result)


@router.post("/register", response_model=RegisterResponse, status_code=201)
async def register(
    body: RegisterRequest,
    request: Request,
    db: DbSession,
    _app: Application,
) -> RegisterResponse:
    """Create a new user account.

    Returns the user profile and optionally tokens when email
    confirmation is not required (development environments).
    """
    settings = request.app.state.settings
    app_id = getattr(request.state, "application_id", None)

    result = await service.register(
        db, settings,
        email=body.email,
        password=body.password,
        username=body.username,
        phone_number=body.phone_number,
        application_id=app_id,
        device_info=_device_info(request),
        ip_address=_client_ip(request),
        referral_click_id=body.referral_click_id,
        referral_slug=body.ref,
    )
    return RegisterResponse(**result)


@router.post("/refresh", response_model=RefreshResponse)
async def refresh(
    body: RefreshRequest,
    request: Request,
    db: DbSession,
    _app: Application,
) -> RefreshResponse:
    """Rotate a refresh token and receive a new token pair.

    The old refresh token is revoked on success.
    """
    settings = request.app.state.settings
    app_id = getattr(request.state, "application_id", None)

    result = await service.refresh_tokens(
        db, settings,
        refresh_token_str=body.refresh_token,
        application_id=app_id,
        device_info=_device_info(request),
        ip_address=_client_ip(request),
        client_ip=_client_ip(request),  # TM-011: Pass IP for anomaly tracking
        user_agent=_device_info(request),  # TM-011: Pass UA for anomaly tracking
    )
    return RefreshResponse(**result)


@router.post("/nonce", response_model=NonceResponse)
async def request_nonce(
    body: NonceRequest,
    db: DbSession,
    _app: Application,
) -> NonceResponse:
    """Request a cryptographic nonce for wallet-based authentication.

    The client signs the returned message with their wallet and submits
    the signature to ``/auth/wallet/sign-in``.
    """
    result = await service.request_nonce(
        db,
        wallet_address=body.wallet_address,
    )
    return NonceResponse(**result)


@router.post("/wallet-sign-in", response_model=WalletSignInResponse)
async def wallet_sign_in(
    body: WalletSignInRequest,
    request: Request,
    db: DbSession,
    _app: Application,
) -> WalletSignInResponse:
    """Sign in with a wallet signature.

    Supports Solana, Ethereum, and Base wallets.  The chain type
    is auto-detected from the address format if not provided.
    """
    settings = request.app.state.settings
    app_id = getattr(request.state, "application_id", None)

    result = await service.wallet_sign_in(
        db, settings,
        wallet_address=body.wallet_address,
        signature=body.signature,
        message=body.message,
        chain_type=body.chain_type,
        username=body.username,
        application_id=app_id,
        device_info=_device_info(request),
        ip_address=_client_ip(request),
    )
    return WalletSignInResponse(**result)


@router.post("/magic-link", response_model=MagicLinkResponse)
async def request_magic_link(
    body: MagicLinkRequest,
    request: Request,
    db: DbSession,
    _app: Application,
) -> MagicLinkResponse:
    """Request a magic-link email for passwordless sign-in.

    The magic link contains a one-time token that the client submits
    to ``/auth/magic-link/verify``.
    """
    settings = request.app.state.settings
    app_id = getattr(request.state, "application_id", None)

    result = await service.request_magic_link(
        db, settings,
        email=body.email,
        application_id=app_id,
        redirect_url=body.redirect_url,
        state=body.state,
        generate_state=body.generate_state or False,
    )
    return MagicLinkResponse(**result)


@router.post("/verify-magic-link", response_model=VerifyMagicLinkResponse)
async def verify_magic_link(
    body: VerifyMagicLinkRequest,
    request: Request,
    db: DbSession,
    _app: Application,
) -> VerifyMagicLinkResponse:
    """Verify a magic-link token and sign in.

    The token is consumed on first use and cannot be replayed.
    """
    settings = request.app.state.settings
    app_id = getattr(request.state, "application_id", None)

    result = await service.verify_magic_link(
        db, settings,
        token=body.token,
        token_type=body.type,
        application_id=app_id,
        state=body.state,
        device_info=_device_info(request),
        ip_address=_client_ip(request),
    )
    return VerifyMagicLinkResponse(**result)


@router.post("/password-reset", response_model=PasswordResetResponse)
async def request_password_reset(
    body: PasswordResetRequest,
    request: Request,
    db: DbSession,
    _app: Application,
) -> PasswordResetResponse:
    """Request a password reset email.

    Always returns success to prevent email enumeration.
    """
    settings = request.app.state.settings
    app_id = getattr(request.state, "application_id", None)

    result = await service.request_password_reset(
        db, settings,
        email=body.email,
        application_id=app_id,
        redirect_url=body.redirect_url,
    )
    return PasswordResetResponse(**result)


@router.post(
    "/reset-password-confirm",
    response_model=ResetPasswordConfirmResponse,
)
async def confirm_password_reset(
    body: ResetPasswordConfirmRequest,
    request: Request,
    db: DbSession,
    _app: Application,
) -> ResetPasswordConfirmResponse:
    """Confirm a password reset with the token from the email.

    All existing sessions for the user are revoked.
    """
    settings = request.app.state.settings

    result = await service.confirm_password_reset(
        db, settings,
        token=body.token,
        new_password=body.new_password,
    )
    return ResetPasswordConfirmResponse(**result)


# ---------------------------------------------------------------------------
# Authenticated endpoints (JWT required)
# ---------------------------------------------------------------------------


@router.post("/set-password", response_model=SetPasswordResponse)
async def set_password(
    body: SetPasswordRequest,
    request: Request,
    db: DbSession,
    _app: Application,
    user: CurrentUser,
) -> SetPasswordResponse:
    """Set or change the current user's password.

    Wallet-only users setting a password for the first time may omit
    ``current_password``.  Users with an existing password must provide
    it for verification.
    """
    settings = request.app.state.settings

    result = await service.set_password(
        db, settings,
        user_id=user.id,
        current_password=body.current_password,
        new_password=body.new_password,
    )
    return SetPasswordResponse(**result)


@router.get("/user", response_model=GetUserResponse)
async def get_me(
    db: DbSession,
    _app: Application,
    user: CurrentUser,
) -> GetUserResponse:
    """Get the current authenticated user's profile.

    Includes linked wallets, roles, permissions, and tier information.
    """
    result = await service.get_me(db, user_id=user.id)
    return GetUserResponse(**result)


@router.post("/logout", response_model=LogoutResponse)
async def logout(
    request: Request,
    db: DbSession,
    _app: Application,
    user: CurrentUser,
) -> LogoutResponse:
    """Log out the current user.

    Blacklists the access token and optionally revokes the refresh
    token.  The client should discard both tokens after this call.
    """
    # Extract refresh token from body if provided
    refresh_token: str | None = None
    try:
        body = await request.json()
        refresh_token = body.get("refresh_token") if isinstance(body, dict) else None
    except (ValueError, TypeError, KeyError):
        # Body is empty, not JSON, or malformed — proceed without refresh token
        pass

    # Get JTI and expiry from the JWT payload set by the auth middleware
    jwt_payload = getattr(request.state, "jwt_payload", {})
    jti = jwt_payload.get("jti") or getattr(user, "jti", None) or ""
    exp = jwt_payload.get("exp", 0)

    result = await service.logout(
        db,
        user_id=user.id,
        access_token_jti=jti,
        access_token_exp=exp,
        refresh_token=refresh_token,
    )
    return LogoutResponse(**result)
