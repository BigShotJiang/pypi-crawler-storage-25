"""Pydantic request/response schemas for security endpoints.

These schemas define the *data* portion of each API response.
The standard response envelope ``{ success, data, error, metadata }``
is applied by middleware -- domain schemas never reference it.

Zero FastAPI imports.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Canonical representations
# ---------------------------------------------------------------------------


class SecurityAlertOut(BaseModel):
    """Canonical representation of a security alert."""

    id: str
    alert_type: str
    user_id: str | None = None
    elevated_by: str | None = None
    severity: str
    details: dict[str, Any] | None = None
    timestamp: str
    ip_address: str | None = None
    user_agent: str | None = None


class AlertCountByType(BaseModel):
    """Alert count grouped by type."""

    alert_type: str
    count: int


class AlertCountBySeverity(BaseModel):
    """Alert count grouped by severity."""

    severity: str
    count: int


# ---------------------------------------------------------------------------
# Request schemas
# ---------------------------------------------------------------------------


class ListAlertsParams(BaseModel):
    """GET /security/alerts query parameters."""

    alert_type: str | None = None
    severity: str | None = None
    limit: int = Field(default=50, ge=1, le=1000)


class SummaryParams(BaseModel):
    """GET /security/summary query parameters."""

    hours: int = Field(default=24, ge=1, le=720)


# ---------------------------------------------------------------------------
# Response schemas
# ---------------------------------------------------------------------------


class ListAlertsResponse(BaseModel):
    """GET /security/alerts -- success payload."""

    alerts: list[SecurityAlertOut]
    total: int


class SummaryResponse(BaseModel):
    """GET /security/summary -- success payload."""

    total: int
    by_type: list[AlertCountByType]
    by_severity: list[AlertCountBySeverity]
    window_hours: int
