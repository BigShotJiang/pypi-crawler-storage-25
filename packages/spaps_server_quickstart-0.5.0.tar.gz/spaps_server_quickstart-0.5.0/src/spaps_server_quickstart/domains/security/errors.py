"""Domain errors for the security domain."""

from __future__ import annotations

from ..errors import DomainError


class SecurityAlertNotFoundError(DomainError):
    """Raised when a security alert is not found."""

    def __init__(self, message: str = "Security alert not found") -> None:
        super().__init__("NOT_FOUND", message, status_code=404)


class SecurityAlertCreationError(DomainError):
    """Raised when security alert creation fails."""

    def __init__(self, message: str = "Failed to create security alert") -> None:
        super().__init__("DATABASE_ERROR", message, status_code=500)
