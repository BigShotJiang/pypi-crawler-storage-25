"""Security domain -- threat detection and alerting for SPAPS."""
