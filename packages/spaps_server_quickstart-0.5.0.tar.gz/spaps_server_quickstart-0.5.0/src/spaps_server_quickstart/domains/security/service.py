"""Business logic for the security domain.

Coordinates repository calls and raises domain errors.
This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime, timedelta
from typing import Any
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from . import repository as repo
from .models import SecurityAlert

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _alert_to_dict(alert: SecurityAlert) -> dict[str, Any]:
    """Convert a SecurityAlert model instance to a serialisable dict."""
    return {
        "id": str(alert.id),
        "alert_type": alert.alert_type,
        "user_id": str(alert.user_id) if alert.user_id else None,
        "elevated_by": alert.elevated_by,
        "severity": alert.severity,
        "details": alert.details,
        "timestamp": alert.timestamp.isoformat() if alert.timestamp else None,
        "ip_address": alert.ip_address,
        "user_agent": alert.user_agent,
    }


# ---------------------------------------------------------------------------
# Alert creation -- public API (called by other domains)
# ---------------------------------------------------------------------------


async def create_alert(
    db: AsyncSession,
    *,
    alert_type: str,
    severity: str = "medium",
    user_id: UUID | None = None,
    elevated_by: str | None = None,
    details: dict[str, Any] | None = None,
    ip_address: str | None = None,
    user_agent: str | None = None,
) -> dict[str, Any]:
    """Create a new security alert.

    This is the primary entry point used by other domains to record
    security-relevant events.
    """
    alert = await repo.create_alert(
        db,
        alert_type=alert_type,
        user_id=user_id,
        elevated_by=elevated_by,
        severity=severity,
        details=details,
        ip_address=ip_address,
        user_agent=user_agent,
    )

    logger.warning(
        "Security alert created",
        extra={
            "alert_type": alert_type,
            "severity": severity,
            "user_id": str(user_id) if user_id else None,
        },
    )

    return _alert_to_dict(alert)


async def check_privilege_escalation(
    db: AsyncSession,
    *,
    user_id: UUID,
    requested_roles: list[str],
    current_roles: list[str],
    elevated_by: str | None = None,
    ip_address: str | None = None,
    user_agent: str | None = None,
) -> dict[str, Any] | None:
    """Check for privilege escalation and create an alert if detected.

    Returns the alert dict if escalation detected, None otherwise.
    """
    # Detect escalation: requesting roles not in current set
    escalated_roles = set(requested_roles) - set(current_roles)

    if not escalated_roles:
        return None

    alert_data = await create_alert(
        db,
        alert_type="privilege_escalation",
        severity="high",
        user_id=user_id,
        elevated_by=elevated_by,
        details={
            "current_roles": current_roles,
            "requested_roles": requested_roles,
            "escalated_roles": list(escalated_roles),
        },
        ip_address=ip_address,
        user_agent=user_agent,
    )

    logger.warning(
        "Privilege escalation detected",
        extra={
            "user_id": str(user_id),
            "escalated_roles": list(escalated_roles),
        },
    )

    return alert_data


# ---------------------------------------------------------------------------
# Alert queries -- admin endpoints
# ---------------------------------------------------------------------------


async def get_alerts(
    db: AsyncSession,
    *,
    alert_type: str | None = None,
    severity: str | None = None,
    limit: int = 50,
) -> dict[str, Any]:
    """Get security alerts with optional filters.

    Used by the GET /security/alerts endpoint (admin access).
    """
    alerts, total = await repo.list_alerts(
        db,
        alert_type=alert_type,
        severity=severity,
        limit=limit,
    )

    return {
        "alerts": [_alert_to_dict(a) for a in alerts],
        "total": total,
    }


async def get_summary(
    db: AsyncSession,
    *,
    hours: int = 24,
) -> dict[str, Any]:
    """Get alert summary counts by type and severity over a time window.

    Used by the GET /security/summary endpoint (admin access).
    """
    since = datetime.now(UTC) - timedelta(hours=hours)

    summary = await repo.get_summary(db, since=since)

    return {
        "total": summary["total"],
        "by_type": summary["by_type"],
        "by_severity": summary["by_severity"],
        "window_hours": hours,
    }
