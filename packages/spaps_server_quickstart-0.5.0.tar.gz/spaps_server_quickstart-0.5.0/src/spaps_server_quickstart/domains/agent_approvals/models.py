"""SQLAlchemy models for the agent_approvals domain.

Three tables:
- agents: Registered AI agent identities
- agent_approvers: Additional approvers (users or agents) for an agent
- agent_approvals: Approval requests from agents to their approvers
"""

from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID, uuid4

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    DateTime,
    ForeignKey,
    Index,
    String,
    Text,
    func,
)
from sqlalchemy.dialects.postgresql import JSON
from sqlalchemy.orm import Mapped, mapped_column

from .._db import Base, PGUUID


class Agent(Base):
    """Registered AI agent identity.

    Each agent belongs to an application and is owned by a user.
    The agent_secret_hash stores a bcrypt hash of the secret returned
    once at registration time.
    """

    __tablename__ = "agents"

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    application_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("applications.id", ondelete="CASCADE"),
        nullable=False,
    )
    owner_user_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
    )
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[str | None] = mapped_column(String(500), nullable=True)
    agent_secret_hash: Mapped[str] = mapped_column(String(128), nullable=False)
    agent_secret_prefix: Mapped[str] = mapped_column(String(8), nullable=False)
    scopes: Mapped[list[str] | None] = mapped_column(
        JSON, nullable=True, default=list
    )
    metadata_: Mapped[dict[str, Any] | None] = mapped_column(
        "metadata", JSON, nullable=True, default=dict
    )
    is_active: Mapped[bool] = mapped_column(
        Boolean, server_default="true", default=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    __table_args__ = (
        Index(
            "uq_agents_app_name_active",
            "application_id",
            "name",
            unique=True,
            postgresql_where="is_active = true",
        ),
        Index("ix_agents_app_owner", "application_id", "owner_user_id"),
        Index("ix_agents_owner", "owner_user_id"),
    )

    def __repr__(self) -> str:
        return f"<Agent name={self.name!r} app={self.application_id!r}>"


class AgentApprover(Base):
    """Additional approver for an agent.

    The agent's owner is always an implicit approver (checked in code,
    not stored here). This table stores explicitly added approvers.
    """

    __tablename__ = "agent_approvers"

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    agent_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("agents.id", ondelete="CASCADE"),
        nullable=False,
    )
    approver_user_id: Mapped[UUID | None] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=True,
    )
    approver_agent_id: Mapped[UUID | None] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("agents.id", ondelete="CASCADE"),
        nullable=True,
    )
    approver_type: Mapped[str] = mapped_column(String(10), nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    __table_args__ = (
        CheckConstraint(
            "approver_type IN ('user', 'agent')",
            name="ck_agent_approvers_type",
        ),
        CheckConstraint(
            "(approver_type = 'user' AND approver_user_id IS NOT NULL AND approver_agent_id IS NULL) "
            "OR (approver_type = 'agent' AND approver_agent_id IS NOT NULL AND approver_user_id IS NULL)",
            name="ck_agent_approvers_exactly_one_fk",
        ),
        Index(
            "uq_agent_approvers_user",
            "agent_id",
            "approver_user_id",
            unique=True,
            postgresql_where="approver_type = 'user'",
        ),
        Index(
            "uq_agent_approvers_agent",
            "agent_id",
            "approver_agent_id",
            unique=True,
            postgresql_where="approver_type = 'agent'",
        ),
        Index("ix_agent_approvers_agent", "agent_id"),
        Index(
            "ix_agent_approvers_user",
            "approver_user_id",
            postgresql_where="approver_user_id IS NOT NULL",
        ),
        Index(
            "ix_agent_approvers_agent_id",
            "approver_agent_id",
            postgresql_where="approver_agent_id IS NOT NULL",
        ),
    )

    def __repr__(self) -> str:
        return f"<AgentApprover type={self.approver_type!r} agent={self.agent_id!r}>"


class AgentApproval(Base):
    """Approval request from an agent to its approvers.

    The status field follows a strict state machine:
    pending -> approved | denied | expired (all terminal).

    Transaction intent fields (tx_signing):
    - transaction_intent: Structured intent (EVM/Solana) set at creation, immutable
    - signed_transaction: Signed tx bytes provided by approver at respond time
    - signer_address: Wallet address that signed (for audit trail)
    - edited_intent: Modified intent if approver edited parameters
    """

    __tablename__ = "agent_approvals"

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    application_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("applications.id", ondelete="CASCADE"),
        nullable=False,
    )
    agent_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("agents.id", ondelete="CASCADE"),
        nullable=False,
    )
    code: Mapped[str] = mapped_column(String(9), unique=True, nullable=False)
    action: Mapped[str] = mapped_column(String(200), nullable=False)
    resource_type: Mapped[str | None] = mapped_column(String(100), nullable=True)
    resource_id: Mapped[str | None] = mapped_column(String(500), nullable=True)
    reason: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    metadata_: Mapped[dict[str, Any] | None] = mapped_column(
        "metadata", JSON, nullable=True, default=dict
    )
    status: Mapped[str] = mapped_column(
        String(20), nullable=False, server_default="pending", default="pending"
    )
    callback_url: Mapped[str | None] = mapped_column(String(2048), nullable=True)
    note: Mapped[str | None] = mapped_column(String(500), nullable=True)
    responded_by_user_id: Mapped[UUID | None] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("users.id", ondelete="SET NULL"),
        nullable=True,
    )
    responded_by_agent_id: Mapped[UUID | None] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("agents.id", ondelete="SET NULL"),
        nullable=True,
    )
    responder_type: Mapped[str | None] = mapped_column(String(10), nullable=True)
    responded_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    approval_token: Mapped[str | None] = mapped_column(Text, nullable=True)
    token_expires_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    expires_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    # Transaction intent fields (tx_signing)
    transaction_intent: Mapped[dict[str, Any] | None] = mapped_column(
        JSON, nullable=True, default=None
    )
    signed_transaction: Mapped[str | None] = mapped_column(Text, nullable=True)
    signer_address: Mapped[str | None] = mapped_column(String(500), nullable=True)
    edited_intent: Mapped[dict[str, Any] | None] = mapped_column(
        JSON, nullable=True, default=None
    )

    __table_args__ = (
        CheckConstraint(
            "status IN ('pending', 'approved', 'denied', 'expired')",
            name="ck_agent_approvals_status",
        ),
        Index(
            "ix_agent_approvals_app_agent_status",
            "application_id",
            "agent_id",
            "status",
        ),
        Index(
            "ix_agent_approvals_pending_expiry",
            "status",
            "expires_at",
            postgresql_where="status = 'pending'",
        ),
    )

    def __repr__(self) -> str:
        return f"<AgentApproval action={self.action!r} status={self.status!r}>"
