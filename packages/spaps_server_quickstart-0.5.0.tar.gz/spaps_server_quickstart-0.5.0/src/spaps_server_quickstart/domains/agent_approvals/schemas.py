"""Pydantic request/response schemas for agent_approvals endpoints.

These schemas define the *data* portion of each API response.
The standard response envelope ``{ success, data, error, metadata }``
is applied by middleware -- domain schemas never reference it.

Zero FastAPI imports.
"""

from __future__ import annotations

import json
from typing import Annotated, Any, Literal

from pydantic import BaseModel, Field, field_validator


# ---------------------------------------------------------------------------
# Agent schemas
# ---------------------------------------------------------------------------


_ScopeItem = Annotated[str, Field(min_length=1, max_length=100)]


class RegisterAgentRequest(BaseModel):
    """POST /api/agents request body."""

    name: str = Field(..., min_length=1, max_length=100)
    description: str | None = Field(default=None, max_length=500)
    scopes: list[_ScopeItem] | None = Field(default=None, max_length=50)
    metadata: dict[str, Any] | None = None
    referral_click_id: str | None = None
    ref: str | None = None

    @field_validator("metadata")
    @classmethod
    def _metadata_max_size(cls, v: dict[str, Any] | None) -> dict[str, Any] | None:
        if v is not None and len(json.dumps(v)) > 10240:
            msg = "metadata must be under 10KB"
            raise ValueError(msg)
        return v


class UpdateAgentRequest(BaseModel):
    """PUT /api/agents/:id request body (partial update)."""

    name: str | None = Field(default=None, min_length=1, max_length=100)
    description: str | None = Field(default=None, max_length=500)
    scopes: list[_ScopeItem] | None = Field(default=None, max_length=50)
    metadata: dict[str, Any] | None = None
    is_active: bool | None = None

    @field_validator("metadata")
    @classmethod
    def _metadata_max_size(cls, v: dict[str, Any] | None) -> dict[str, Any] | None:
        if v is not None and len(json.dumps(v)) > 10240:
            msg = "metadata must be under 10KB"
            raise ValueError(msg)
        return v


class AgentOut(BaseModel):
    """Agent detail response (never includes agent_secret)."""

    id: str
    name: str
    description: str | None = None
    application_id: str
    owner_user_id: str
    scopes: list[str] | None = None
    is_active: bool
    metadata: dict[str, Any] | None = None
    created_at: str
    updated_at: str


class AgentCreatedOut(AgentOut):
    """Agent creation response (includes agent_secret once)."""

    agent_secret: str


class AgentListItem(BaseModel):
    """Agent summary for list responses."""

    id: str
    name: str
    description: str | None = None
    scopes: list[str] | None = None
    is_active: bool
    created_at: str
    pending_approvals_count: int = 0


class ListAgentsResponse(BaseModel):
    """GET /api/agents response."""

    agents: list[AgentListItem]
    total: int


class DeactivateAgentResponse(BaseModel):
    """DELETE /api/agents/:id response."""

    id: str
    is_active: bool
    message: str


class RotateSecretResponse(BaseModel):
    """POST /api/agents/:id/rotate-secret response."""

    agent_secret: str
    message: str


# ---------------------------------------------------------------------------
# Approver schemas
# ---------------------------------------------------------------------------


class AddApproverRequest(BaseModel):
    """POST /api/agents/:id/approvers request body."""

    approver_type: Literal["user", "agent"]
    approver_user_id: str | None = None
    approver_agent_id: str | None = None


class ApproverOut(BaseModel):
    """Approver detail."""

    id: str
    approver_type: str
    approver_user_id: str | None = None
    approver_email: str | None = None
    approver_agent_id: str | None = None
    approver_agent_name: str | None = None
    created_at: str


class OwnerApprover(BaseModel):
    """Implicit owner-approver info."""

    user_id: str
    email: str | None = None
    implicit: bool = True


class ListApproversResponse(BaseModel):
    """GET /api/agents/:id/approvers response."""

    approvers: list[ApproverOut]
    owner: OwnerApprover
    total: int


class RemoveApproverResponse(BaseModel):
    """DELETE /api/agents/:id/approvers/:approver_id response."""

    message: str


# ---------------------------------------------------------------------------
# Transaction Intent schemas (tx_signing)
# ---------------------------------------------------------------------------


class TransactionIntentEVM(BaseModel):
    """EVM blockchain transaction intent."""

    chain: Literal["evm"]
    chain_id: int = Field(..., gt=0)
    to: str = Field(..., pattern=r"^0x[0-9a-fA-F]{40}$")
    value: str = Field(..., pattern=r"^\d+$")
    data: str = Field(default="0x", pattern=r"^0x[0-9a-fA-F]*$")
    gas_limit: int | None = Field(default=None, gt=0)


class TransactionIntentSolana(BaseModel):
    """Solana blockchain transaction intent."""

    chain: Literal["solana"]
    instructions: list[dict[str, Any]] = Field(..., min_length=1)
    fee_payer: str | None = None


TransactionIntent = Annotated[
    TransactionIntentEVM | TransactionIntentSolana,
    Field(discriminator="chain"),
]


# ---------------------------------------------------------------------------
# Approval schemas
# ---------------------------------------------------------------------------


class CreateApprovalRequest(BaseModel):
    """POST /api/approvals request body."""

    action: str = Field(..., min_length=1, max_length=200)
    resource_type: str | None = Field(default=None, max_length=100)
    resource_id: str | None = Field(default=None, max_length=500)
    reason: str | None = Field(default=None, max_length=1000)
    metadata: dict[str, Any] | None = None
    expires_in: int = Field(default=900, ge=60, le=86400)
    callback_url: str | None = Field(default=None, max_length=2048)
    transaction_intent: TransactionIntent | None = Field(default=None)

    @field_validator("metadata")
    @classmethod
    def _metadata_max_size(cls, v: dict[str, Any] | None) -> dict[str, Any] | None:
        if v is not None and len(json.dumps(v)) > 10240:
            msg = "metadata must be under 10KB"
            raise ValueError(msg)
        return v

    @field_validator("callback_url")
    @classmethod
    def _callback_url_https_only(cls, v: str | None) -> str | None:
        if v is not None and not v.startswith("https://"):
            msg = "callback_url must use HTTPS"
            raise ValueError(msg)
        return v


class ApprovalCreatedOut(BaseModel):
    """POST /api/approvals response."""

    id: str
    status: str
    verification_url: str
    code: str
    expires_at: str
    expires_in: int


class ApprovalDetailOut(BaseModel):
    """GET /api/approvals/:id response (varies by status)."""

    id: str
    status: str
    agent_id: str | None = None
    agent_name: str | None = None
    action: str | None = None
    resource_type: str | None = None
    resource_id: str | None = None
    reason: str | None = None
    code: str | None = None
    created_at: str | None = None
    expires_at: str | None = None
    # Approved fields
    approved_at: str | None = None
    approved_by: str | None = None
    note: str | None = None
    approval_token: str | None = None
    token_expires_at: str | None = None
    # Denied fields
    denied_at: str | None = None
    denied_by: str | None = None
    # Expired fields
    expired_at: str | None = None
    # Transaction signing fields (tx_signing)
    transaction_intent: dict[str, Any] | None = None
    signed_transaction: str | None = None
    signer_address: str | None = None
    edited_intent: dict[str, Any] | None = None


class RespondToApprovalRequest(BaseModel):
    """POST /api/approvals/:id/respond request body."""

    action: Literal["approve", "deny"]
    note: str | None = Field(default=None, max_length=500)
    # Transaction signing fields (tx_signing)
    signed_transaction: str | None = Field(default=None)
    signer_address: str | None = Field(default=None)
    edited_intent: TransactionIntent | None = Field(default=None)


class RespondToApprovalResponse(BaseModel):
    """POST /api/approvals/:id/respond response."""

    id: str
    status: str
    approved_at: str | None = None
    denied_at: str | None = None
    message: str


class ApprovalListItem(BaseModel):
    """Approval summary for list/history responses."""

    id: str
    agent_id: str
    agent_name: str | None = None
    action: str
    resource_type: str | None = None
    resource_id: str | None = None
    status: str
    created_at: str
    resolved_at: str | None = None
    note: str | None = None
    reason: str | None = None
    metadata: dict[str, Any] | None = None
    # Transaction signing fields (tx_signing)
    transaction_intent: dict[str, Any] | None = None
    signed_transaction: str | None = None


class ListApprovalsResponse(BaseModel):
    """GET /api/approvals response."""

    approvals: list[ApprovalListItem]
    total: int
