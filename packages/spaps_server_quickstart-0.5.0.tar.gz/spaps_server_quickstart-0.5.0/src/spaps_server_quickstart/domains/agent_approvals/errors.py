"""Domain errors for the agent_approvals domain.

Each error carries a machine-readable code that maps to the error codes
documented in shared.md (the locked API contract).
"""

from __future__ import annotations

from ..errors import DomainError


# --- Agent errors ---


class AgentNotFoundError(DomainError):
    """Raised when an agent ID does not exist in the application."""

    def __init__(self, message: str = "Agent not found") -> None:
        super().__init__("AGENT_NOT_FOUND", message, status_code=404)


class AgentInactiveError(DomainError):
    """Raised when an inactive agent tries to perform an action."""

    def __init__(self, message: str = "Agent is deactivated") -> None:
        super().__init__("AGENT_INACTIVE", message, status_code=403)


class AgentNameExistsError(DomainError):
    """Raised when the agent name is already taken in the application."""

    def __init__(self, message: str = "Agent name already exists in this application") -> None:
        super().__init__("AGENT_NAME_EXISTS", message, status_code=409)


class AgentAlreadyInactiveError(DomainError):
    """Raised when trying to deactivate an already-inactive agent."""

    def __init__(self, message: str = "Agent is already deactivated") -> None:
        super().__init__("AGENT_ALREADY_INACTIVE", message, status_code=400)


class InvalidAgentCredentialsError(DomainError):
    """Raised when agent_id or agent_secret is invalid."""

    def __init__(self, message: str = "Invalid agent credentials") -> None:
        super().__init__("INVALID_AGENT_CREDENTIALS", message, status_code=401)


class NotAgentOwnerError(DomainError):
    """Raised when the JWT user is not the agent's owner."""

    def __init__(self, message: str = "Not the agent owner") -> None:
        super().__init__("NOT_AGENT_OWNER", message, status_code=403)


class ScopeViolationError(DomainError):
    """Raised when the action does not match the agent's allowed scopes."""

    def __init__(self, message: str = "Action not in agent's allowed scopes") -> None:
        super().__init__("SCOPE_VIOLATION", message, status_code=403)


# --- Approver errors ---


class ApproverNotFoundError(DomainError):
    """Raised when the approver user/agent does not exist."""

    def __init__(self, message: str = "Approver not found") -> None:
        super().__init__("APPROVER_NOT_FOUND", message, status_code=404)


class ApproverAlreadyExistsError(DomainError):
    """Raised when the user/agent is already an approver."""

    def __init__(self, message: str = "Already an approver for this agent") -> None:
        super().__init__("APPROVER_ALREADY_EXISTS", message, status_code=409)


class MaxApproversExceededError(DomainError):
    """Raised when the agent already has 20 approvers."""

    def __init__(self, message: str = "Maximum 20 approvers per agent") -> None:
        super().__init__("MAX_APPROVERS_EXCEEDED", message, status_code=400)


# --- Approval errors ---


class ApprovalNotFoundError(DomainError):
    """Raised when an approval ID or code does not exist."""

    def __init__(self, message: str = "Approval not found") -> None:
        super().__init__("APPROVAL_NOT_FOUND", message, status_code=404)


class ApprovalAlreadyResolvedError(DomainError):
    """Raised when trying to respond to an already-resolved approval."""

    def __init__(self, message: str = "Approval already resolved") -> None:
        super().__init__("APPROVAL_ALREADY_RESOLVED", message, status_code=400)


class ApprovalExpiredError(DomainError):
    """Raised when the approval TTL has been exceeded."""

    def __init__(self, message: str = "Approval has expired") -> None:
        super().__init__("APPROVAL_EXPIRED", message, status_code=400)


class NotAuthorizedApproverError(DomainError):
    """Raised when the caller is not an authorized approver for the agent."""

    def __init__(self, message: str = "Not an authorized approver for this agent") -> None:
        super().__init__("NOT_AUTHORIZED_APPROVER", message, status_code=403)


class ApprovalTokenConfigurationError(DomainError):
    """Raised when approval-token signing settings are missing."""

    def __init__(
        self,
        message: str = "Approval token signing key is not configured",
    ) -> None:
        super().__init__("APPROVAL_TOKEN_CONFIG_ERROR", message, status_code=500)
