"""Agent approvals domain -- consent gateway for AI agents."""
