"""HTTP routes for the agent_approvals domain.

Provides TWO routers:

1. ``agents_router`` -- Agent management under ``/agents``
2. ``approvals_router`` -- Approval flow under ``/approvals``

The response envelope ``{ success, data, error, metadata }`` is
applied automatically by ``ResponseEnvelopeMiddleware`` -- handlers
return the raw *data* portion only.

Authorization hardening (approval_authz_prod_hardening):
- Read endpoints enforce ``approval_request.read`` capability gate.
- Decision/finalize endpoints enforce ``approval_request.review`` capability gate.
- Capability gates run BEFORE participant-role checks (defense-in-depth).
- Audit events are emitted for all allow/deny capability decisions.
"""

from __future__ import annotations

import logging
from uuid import UUID

from fastapi import APIRouter, Header, Query, Request

from ...middleware.spaps_deps import (
    Application,
    CurrentUser,
    DbSession,
    OptionalUser,
)
from . import service
from ..approval_authz_prod_hardening import service as authz_hardening_service
from ..approval_authz_prod_hardening.errors import ApprovalCapabilityRequiredError
from .schemas import (
    AddApproverRequest,
    CreateApprovalRequest,
    RegisterAgentRequest,
    RespondToApprovalRequest,
    UpdateAgentRequest,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Capability gate helpers (approval_authz_prod_hardening wiring)
# ---------------------------------------------------------------------------


async def _enforce_read_capability(db, user, application) -> None:
    """Enforce approval_request.read capability and emit audit event.

    Called from read endpoints (list, by-code) BEFORE participant checks.
    """
    user_permissions = getattr(user, "permissions", []) or []
    try:
        authz_hardening_service.check_capability(
            user_permissions, "approval_request.read"
        )
    except ApprovalCapabilityRequiredError:
        # Emit deny audit event (fire-and-forget)
        await authz_hardening_service.emit_authz_audit_event(
            db,
            principal_type="human",
            principal_id=str(user.id),
            tenant_id=str(getattr(user, "application_id", "")),
            app_id=str(application.id),
            capability="approval_request.read",
            decision="deny",
            reason_code="APPROVAL_CAPABILITY_REQUIRED",
        )
        raise

    # Emit allow audit event (fire-and-forget)
    await authz_hardening_service.emit_authz_audit_event(
        db,
        principal_type="human",
        principal_id=str(user.id),
        tenant_id=str(getattr(user, "application_id", "")),
        app_id=str(application.id),
        capability="approval_request.read",
        decision="allow",
        reason_code="AUTHORIZED",
    )


async def _enforce_review_capability(db, user, application) -> None:
    """Enforce approval_request.review capability and emit audit event.

    Called from decision/finalize endpoints BEFORE participant checks.
    Only applies to human users; agent-as-approver path skips this.
    """
    user_permissions = getattr(user, "permissions", []) or []
    try:
        authz_hardening_service.check_capability(
            user_permissions, "approval_request.review"
        )
    except ApprovalCapabilityRequiredError:
        # Emit deny audit event (fire-and-forget)
        await authz_hardening_service.emit_authz_audit_event(
            db,
            principal_type="human",
            principal_id=str(user.id),
            tenant_id=str(getattr(user, "application_id", "")),
            app_id=str(application.id),
            capability="approval_request.review",
            decision="deny",
            reason_code="APPROVAL_CAPABILITY_REQUIRED",
        )
        raise

    # Emit allow audit event (fire-and-forget)
    await authz_hardening_service.emit_authz_audit_event(
        db,
        principal_type="human",
        principal_id=str(user.id),
        tenant_id=str(getattr(user, "application_id", "")),
        app_id=str(application.id),
        capability="approval_request.review",
        decision="allow",
        reason_code="AUTHORIZED",
    )


def _as_uuid(value: str, field_name: str) -> UUID:
    """Parse UUID values from untrusted route/query/header inputs."""
    from ..errors import ValidationError

    try:
        return UUID(str(value))
    except (TypeError, ValueError):
        raise ValidationError(f"{field_name} must be a valid UUID")


# ===========================================================================
# Agents Router
# ===========================================================================

agents_router = APIRouter(prefix="/agents", tags=["agents"])


@agents_router.post("", status_code=201)
async def register_agent(
    body: RegisterAgentRequest,
    db: DbSession,
    application: Application,
    user: CurrentUser,
):
    """Register a new agent under the application.

    Returns agent details including the raw secret (shown once).
    """
    result = await service.register_agent(
        db,
        application_id=UUID(str(application.id)),
        owner_user_id=UUID(str(user.id)),
        name=body.name,
        description=body.description,
        scopes=body.scopes,
        metadata=body.metadata,
        referral_click_id=body.referral_click_id,
        referral_slug=body.ref,
    )
    return result


@agents_router.get("")
async def list_agents(
    db: DbSession,
    application: Application,
    user: CurrentUser,
    is_active: bool | None = Query(default=True),
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
):
    """List agents owned by the authenticated user (admin sees all)."""
    result = await service.list_agents(
        db,
        application_id=UUID(str(application.id)),
        user_id=UUID(str(user.id)),
        is_admin=getattr(user, "is_admin", False),
        is_active=is_active,
        limit=limit,
        offset=offset,
    )
    return result


@agents_router.get("/{agent_id}")
async def get_agent(
    agent_id: str,
    db: DbSession,
    application: Application,
    user: CurrentUser,
):
    """Get agent details (owner or admin only)."""
    result = await service.get_agent(
        db,
        agent_id=_as_uuid(agent_id, "agent_id"),
        application_id=UUID(str(application.id)),
        user_id=UUID(str(user.id)),
        is_admin=getattr(user, "is_admin", False),
    )
    return result


@agents_router.put("/{agent_id}")
async def update_agent(
    agent_id: str,
    body: UpdateAgentRequest,
    db: DbSession,
    application: Application,
    user: CurrentUser,
):
    """Update agent fields (owner or admin only)."""
    result = await service.update_agent(
        db,
        agent_id=_as_uuid(agent_id, "agent_id"),
        application_id=UUID(str(application.id)),
        user_id=UUID(str(user.id)),
        is_admin=getattr(user, "is_admin", False),
        name=body.name,
        description=body.description,
        scopes=body.scopes,
        metadata=body.metadata,
        is_active=body.is_active,
    )
    return result


@agents_router.delete("/{agent_id}")
async def deactivate_agent(
    agent_id: str,
    db: DbSession,
    application: Application,
    user: CurrentUser,
):
    """Deactivate an agent (soft delete). Expires pending approvals."""
    result = await service.deactivate_agent(
        db,
        agent_id=_as_uuid(agent_id, "agent_id"),
        application_id=UUID(str(application.id)),
        user_id=UUID(str(user.id)),
        is_admin=getattr(user, "is_admin", False),
    )
    return result


@agents_router.post("/{agent_id}/rotate-secret")
async def rotate_secret(
    agent_id: str,
    db: DbSession,
    application: Application,
    user: CurrentUser,
):
    """Rotate the agent secret. Owner only."""
    result = await service.rotate_agent_secret(
        db,
        agent_id=_as_uuid(agent_id, "agent_id"),
        application_id=UUID(str(application.id)),
        user_id=UUID(str(user.id)),
    )
    return result


# ---------------------------------------------------------------------------
# Approver sub-routes
# ---------------------------------------------------------------------------


@agents_router.post("/{agent_id}/approvers", status_code=201)
async def add_approver(
    agent_id: str,
    body: AddApproverRequest,
    db: DbSession,
    application: Application,
    user: CurrentUser,
):
    """Add a user or agent as approver. Owner only."""
    result = await service.add_approver(
        db,
        agent_id=_as_uuid(agent_id, "agent_id"),
        application_id=UUID(str(application.id)),
        user_id=UUID(str(user.id)),
        approver_type=body.approver_type,
        approver_user_id=_as_uuid(body.approver_user_id, "approver_user_id") if body.approver_user_id else None,
        approver_agent_id=_as_uuid(body.approver_agent_id, "approver_agent_id") if body.approver_agent_id else None,
    )
    return result


@agents_router.get("/{agent_id}/approvers")
async def list_approvers(
    agent_id: str,
    db: DbSession,
    application: Application,
    user: CurrentUser,
):
    """List approvers for an agent. Owner or admin."""
    result = await service.list_approvers(
        db,
        agent_id=_as_uuid(agent_id, "agent_id"),
        application_id=UUID(str(application.id)),
        user_id=UUID(str(user.id)),
        is_admin=getattr(user, "is_admin", False),
    )
    return result


@agents_router.delete("/{agent_id}/approvers/{approver_id}")
async def remove_approver(
    agent_id: str,
    approver_id: str,
    db: DbSession,
    application: Application,
    user: CurrentUser,
):
    """Remove an approver. Owner only."""
    result = await service.remove_approver(
        db,
        agent_id=_as_uuid(agent_id, "agent_id"),
        approver_id=_as_uuid(approver_id, "approver_id"),
        application_id=UUID(str(application.id)),
        user_id=UUID(str(user.id)),
    )
    return result


# ===========================================================================
# Approvals Router
# ===========================================================================

approvals_router = APIRouter(prefix="/approvals", tags=["approvals"])


@approvals_router.post("", status_code=201)
async def create_approval(
    body: CreateApprovalRequest,
    request: Request,
    db: DbSession,
    application: Application,
    x_agent_id: str | None = Header(default=None, alias="X-Agent-Id"),
    x_agent_secret: str | None = Header(default=None, alias="X-Agent-Secret"),
):
    """Create an approval request. Agent credentials required."""
    from ..errors import ValidationError

    if not x_agent_id or not x_agent_secret:
        raise ValidationError("X-Agent-Id and X-Agent-Secret headers are required")

    # Authenticate agent
    agent = await service.authenticate_agent(
        db,
        agent_id=_as_uuid(x_agent_id, "x_agent_id"),
        agent_secret=x_agent_secret,
        application_id=UUID(str(application.id)),
    )

    result = await service.create_approval(
        db,
        agent_id=UUID(str(agent.id)),
        application_id=UUID(str(application.id)),
        action=body.action,
        resource_type=body.resource_type,
        resource_id=body.resource_id,
        reason=body.reason,
        metadata=body.metadata,
        expires_in=body.expires_in,
        callback_url=body.callback_url,
        transaction_intent=body.transaction_intent.model_dump() if body.transaction_intent else None,
    )
    return result


@approvals_router.get("/by-code/{code}")
async def get_approval_by_code(
    code: str,
    db: DbSession,
    application: Application,
    user: CurrentUser,
):
    """Look up an approval by verification code. Authorized approvers only."""
    # Capability gate: approval_request.read (before participant check)
    await _enforce_read_capability(db, user, application)

    result = await service.get_approval_by_code(
        db,
        code=code,
        application_id=UUID(str(application.id)),
        user_id=UUID(str(user.id)),
    )
    return result


@approvals_router.get("/{approval_id}")
async def get_approval(
    approval_id: str,
    db: DbSession,
    application: Application,
):
    """Poll approval status. API key auth only."""
    result = await service.get_approval(
        db,
        approval_id=_as_uuid(approval_id, "approval_id"),
        application_id=UUID(str(application.id)),
    )
    return result


@approvals_router.post("/{approval_id}/respond")
async def respond_to_approval(
    approval_id: str,
    body: RespondToApprovalRequest,
    request: Request,
    db: DbSession,
    application: Application,
    user: OptionalUser = None,
    x_agent_id: str | None = Header(default=None, alias="X-Agent-Id"),
    x_agent_secret: str | None = Header(default=None, alias="X-Agent-Secret"),
):
    """Approve or deny a request. User (JWT) or agent credentials."""
    settings = request.app.state.settings

    # Determine responder identity
    responder_type: str
    responder_user_id = None
    responder_agent_id = None

    if x_agent_id and x_agent_secret:
        # Agent-as-approver authentication (no human capability check)
        supervisor = await service.authenticate_agent(
            db,
            agent_id=_as_uuid(x_agent_id, "x_agent_id"),
            agent_secret=x_agent_secret,
            application_id=UUID(str(application.id)),
        )
        responder_type = "agent"
        responder_agent_id = UUID(str(supervisor.id))
    elif user is not None:
        # Capability gate: approval_request.review (before participant check)
        await _enforce_review_capability(db, user, application)
        responder_type = "user"
        responder_user_id = UUID(str(user.id))
    else:
        from ..errors import UnauthorizedError
        raise UnauthorizedError("Authentication required")

    result = await service.respond_to_approval(
        db,
        approval_id=_as_uuid(approval_id, "approval_id"),
        application_id=UUID(str(application.id)),
        action=body.action,
        responder_type=responder_type,
        responder_user_id=responder_user_id,
        responder_agent_id=responder_agent_id,
        note=body.note,
        signed_transaction=body.signed_transaction,
        signer_address=body.signer_address,
        edited_intent=body.edited_intent.model_dump() if body.edited_intent else None,
        settings=settings,
    )
    return result


@approvals_router.get("")
async def list_approvals(
    db: DbSession,
    application: Application,
    user: CurrentUser,
    agent_id: str | None = Query(default=None),
    status: str | None = Query(default=None),
    since: str | None = Query(default=None),
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
):
    """List approval history for owned agents (admin sees all)."""
    # Capability gate: approval_request.read (before participant check)
    await _enforce_read_capability(db, user, application)

    result = await service.list_approvals(
        db,
        application_id=UUID(str(application.id)),
        user_id=UUID(str(user.id)),
        is_admin=getattr(user, "is_admin", False),
        agent_id=_as_uuid(agent_id, "agent_id") if agent_id else None,
        status=status,
        since=since,
        limit=limit,
        offset=offset,
    )
    return result
