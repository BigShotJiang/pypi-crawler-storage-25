"""Database operations for the agent_approvals domain.

Pure SQLAlchemy async repository -- no FastAPI imports.
All functions accept an ``AsyncSession`` as the first positional argument.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any, cast
from uuid import UUID

from sqlalchemy import func, select, update
from sqlalchemy.engine import CursorResult
from sqlalchemy.ext.asyncio import AsyncSession

from .models import Agent, AgentApproval, AgentApprover

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Agent lookups
# ---------------------------------------------------------------------------


async def get_agent_by_id(
    db: AsyncSession,
    agent_id: UUID,
    *,
    application_id: UUID | None = None,
) -> Agent | None:
    """Fetch a single agent by ID, optionally scoped to application."""
    stmt = select(Agent).where(Agent.id == agent_id)
    if application_id is not None:
        stmt = stmt.where(Agent.application_id == application_id)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def get_agent_by_name(
    db: AsyncSession,
    application_id: UUID,
    name: str,
) -> Agent | None:
    """Fetch agent by name within an application (active agents only)."""
    stmt = select(Agent).where(
        Agent.application_id == application_id,
        Agent.name == name,
        Agent.is_active == True,  # noqa: E712
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def list_agents(
    db: AsyncSession,
    application_id: UUID,
    *,
    owner_user_id: UUID | None = None,
    is_active: bool | None = True,
    limit: int = 20,
    offset: int = 0,
) -> list[Agent]:
    """List agents for an application with optional filters."""
    stmt = select(Agent).where(Agent.application_id == application_id)
    if owner_user_id is not None:
        stmt = stmt.where(Agent.owner_user_id == owner_user_id)
    if is_active is not None:
        stmt = stmt.where(Agent.is_active == is_active)
    stmt = stmt.order_by(Agent.created_at.desc()).limit(limit).offset(offset)
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def count_agents(
    db: AsyncSession,
    application_id: UUID,
    *,
    owner_user_id: UUID | None = None,
    is_active: bool | None = True,
) -> int:
    """Count agents matching filters."""
    stmt = select(func.count()).select_from(Agent).where(
        Agent.application_id == application_id
    )
    if owner_user_id is not None:
        stmt = stmt.where(Agent.owner_user_id == owner_user_id)
    if is_active is not None:
        stmt = stmt.where(Agent.is_active == is_active)
    result = await db.execute(stmt)
    return result.scalar() or 0


async def create_agent(
    db: AsyncSession,
    *,
    application_id: UUID,
    owner_user_id: UUID,
    name: str,
    description: str | None = None,
    agent_secret_hash: str,
    agent_secret_prefix: str,
    scopes: list[str] | None = None,
    metadata: dict[str, Any] | None = None,
) -> Agent:
    """Create a new agent record."""
    agent = Agent(
        application_id=application_id,
        owner_user_id=owner_user_id,
        name=name,
        description=description,
        agent_secret_hash=agent_secret_hash,
        agent_secret_prefix=agent_secret_prefix,
        scopes=scopes or [],
        metadata_=metadata or {},
    )
    db.add(agent)
    await db.flush()
    await db.refresh(agent)
    return agent


async def update_agent(
    db: AsyncSession,
    agent: Agent,
    **fields: Any,
) -> Agent:
    """Update agent fields."""
    for key, value in fields.items():
        if value is not None:
            if key == "metadata":
                setattr(agent, "metadata_", value)
            else:
                setattr(agent, key, value)
    agent.updated_at = datetime.now(UTC)
    await db.flush()
    await db.refresh(agent)
    return agent


async def deactivate_agent(
    db: AsyncSession,
    agent: Agent,
) -> None:
    """Set agent is_active to False."""
    agent.is_active = False
    agent.updated_at = datetime.now(UTC)
    await db.flush()


async def update_agent_secret(
    db: AsyncSession,
    agent: Agent,
    *,
    agent_secret_hash: str,
    agent_secret_prefix: str,
) -> None:
    """Update agent secret hash and prefix."""
    agent.agent_secret_hash = agent_secret_hash
    agent.agent_secret_prefix = agent_secret_prefix
    agent.updated_at = datetime.now(UTC)
    await db.flush()


# ---------------------------------------------------------------------------
# Approver lookups
# ---------------------------------------------------------------------------


async def get_approver(
    db: AsyncSession,
    agent_id: UUID,
    *,
    approver_user_id: UUID | None = None,
    approver_agent_id: UUID | None = None,
) -> AgentApprover | None:
    """Find a specific approver for an agent."""
    stmt = select(AgentApprover).where(AgentApprover.agent_id == agent_id)
    if approver_user_id is not None:
        stmt = stmt.where(AgentApprover.approver_user_id == approver_user_id)
    if approver_agent_id is not None:
        stmt = stmt.where(AgentApprover.approver_agent_id == approver_agent_id)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def get_approver_by_id(
    db: AsyncSession,
    approver_id: UUID,
    *,
    agent_id: UUID | None = None,
) -> AgentApprover | None:
    """Fetch an approver by its ID."""
    stmt = select(AgentApprover).where(AgentApprover.id == approver_id)
    if agent_id is not None:
        stmt = stmt.where(AgentApprover.agent_id == agent_id)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def list_approvers(
    db: AsyncSession,
    agent_id: UUID,
) -> list[AgentApprover]:
    """List all approvers for an agent."""
    stmt = (
        select(AgentApprover)
        .where(AgentApprover.agent_id == agent_id)
        .order_by(AgentApprover.created_at.asc())
    )
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def count_approvers(
    db: AsyncSession,
    agent_id: UUID,
) -> int:
    """Count approvers for an agent."""
    stmt = select(func.count()).select_from(AgentApprover).where(
        AgentApprover.agent_id == agent_id
    )
    result = await db.execute(stmt)
    return result.scalar() or 0


async def create_approver(
    db: AsyncSession,
    *,
    agent_id: UUID,
    approver_type: str,
    approver_user_id: UUID | None = None,
    approver_agent_id: UUID | None = None,
) -> AgentApprover:
    """Create a new approver record."""
    approver = AgentApprover(
        agent_id=agent_id,
        approver_type=approver_type,
        approver_user_id=approver_user_id,
        approver_agent_id=approver_agent_id,
    )
    db.add(approver)
    await db.flush()
    await db.refresh(approver)
    return approver


async def delete_approver(
    db: AsyncSession,
    approver: AgentApprover,
) -> None:
    """Delete an approver record."""
    await db.delete(approver)
    await db.flush()


async def is_authorized_approver(
    db: AsyncSession,
    agent_id: UUID,
    owner_user_id: UUID,
    *,
    user_id: UUID | None = None,
    approver_agent_id: UUID | None = None,
) -> bool:
    """Check whether a user or agent is an authorized approver.

    The agent's owner is always an implicit approver.
    """
    # Owner is always an approver
    if user_id is not None and user_id == owner_user_id:
        return True

    # Check explicit approvers table
    if user_id is not None:
        approver = await get_approver(db, agent_id, approver_user_id=user_id)
        return approver is not None

    if approver_agent_id is not None:
        approver = await get_approver(db, agent_id, approver_agent_id=approver_agent_id)
        return approver is not None

    return False


async def user_exists_in_app(
    db: AsyncSession,
    user_id: UUID,
    application_id: UUID,
) -> bool:
    """Check whether a user exists (for approver validation).

    Uses the user_applications join table to verify the user
    is associated with the application.
    """
    from ..users.models import UserApplication

    stmt = select(func.count()).select_from(UserApplication).where(
        UserApplication.user_id == user_id,
        UserApplication.application_id == application_id,
    )
    result = await db.execute(stmt)
    count = result.scalar() or 0
    return count > 0


# ---------------------------------------------------------------------------
# Approval lookups
# ---------------------------------------------------------------------------


async def get_approval_by_id(
    db: AsyncSession,
    approval_id: UUID,
    *,
    application_id: UUID | None = None,
) -> AgentApproval | None:
    """Fetch a single approval by ID."""
    stmt = select(AgentApproval).where(AgentApproval.id == approval_id)
    if application_id is not None:
        stmt = stmt.where(AgentApproval.application_id == application_id)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def get_approval_by_id_for_update(
    db: AsyncSession,
    approval_id: UUID,
    *,
    application_id: UUID | None = None,
) -> AgentApproval | None:
    """Fetch a single approval by ID with a row-level lock."""
    stmt = select(AgentApproval).where(AgentApproval.id == approval_id).with_for_update()
    if application_id is not None:
        stmt = stmt.where(AgentApproval.application_id == application_id)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def get_approval_by_code(
    db: AsyncSession,
    code: str,
    *,
    application_id: UUID | None = None,
) -> AgentApproval | None:
    """Fetch a single approval by verification code."""
    stmt = select(AgentApproval).where(AgentApproval.code == code)
    if application_id is not None:
        stmt = stmt.where(AgentApproval.application_id == application_id)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def create_approval(
    db: AsyncSession,
    *,
    application_id: UUID,
    agent_id: UUID,
    code: str,
    action: str,
    resource_type: str | None = None,
    resource_id: str | None = None,
    reason: str | None = None,
    metadata: dict[str, Any] | None = None,
    callback_url: str | None = None,
    expires_at: datetime,
    transaction_intent: dict[str, Any] | None = None,
) -> AgentApproval:
    """Create a new approval request."""
    approval = AgentApproval(
        application_id=application_id,
        agent_id=agent_id,
        code=code,
        action=action,
        resource_type=resource_type,
        resource_id=resource_id,
        reason=reason,
        metadata_=metadata or {},
        callback_url=callback_url,
        expires_at=expires_at,
        transaction_intent=transaction_intent,
    )
    db.add(approval)
    await db.flush()
    await db.refresh(approval)
    return approval


async def update_approval_status(
    db: AsyncSession,
    approval: AgentApproval,
    *,
    status: str,
    note: str | None = None,
    responded_by_user_id: UUID | None = None,
    responded_by_agent_id: UUID | None = None,
    responder_type: str | None = None,
    responded_at: datetime | None = None,
    approval_token: str | None = None,
    token_expires_at: datetime | None = None,
    signed_transaction: str | None = None,
    signer_address: str | None = None,
    edited_intent: dict[str, Any] | None = None,
) -> None:
    """Update approval status and response fields."""
    approval.status = status
    approval.note = note
    approval.responded_by_user_id = responded_by_user_id
    approval.responded_by_agent_id = responded_by_agent_id
    approval.responder_type = responder_type
    approval.responded_at = responded_at
    approval.approval_token = approval_token
    approval.token_expires_at = token_expires_at
    approval.signed_transaction = signed_transaction
    approval.signer_address = signer_address
    approval.edited_intent = edited_intent
    await db.flush()


async def list_approvals(
    db: AsyncSession,
    application_id: UUID,
    *,
    owner_user_id: UUID | None = None,
    agent_id: UUID | None = None,
    status: str | None = None,
    since: str | None = None,
    limit: int = 20,
    offset: int = 0,
) -> list[AgentApproval]:
    """List approvals with optional filters."""
    stmt = select(AgentApproval).where(
        AgentApproval.application_id == application_id
    )

    # If filtering by owner, join through agents table
    if owner_user_id is not None:
        stmt = stmt.join(Agent, AgentApproval.agent_id == Agent.id).where(
            Agent.owner_user_id == owner_user_id
        )

    if agent_id is not None:
        stmt = stmt.where(AgentApproval.agent_id == agent_id)
    if status is not None:
        stmt = stmt.where(AgentApproval.status == status)
    if since is not None:
        stmt = stmt.where(AgentApproval.created_at >= since)

    stmt = stmt.order_by(AgentApproval.created_at.desc()).limit(limit).offset(offset)
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def count_approvals(
    db: AsyncSession,
    application_id: UUID,
    *,
    owner_user_id: UUID | None = None,
    agent_id: UUID | None = None,
    status: str | None = None,
    since: str | None = None,
) -> int:
    """Count approvals matching filters."""
    stmt = select(func.count()).select_from(AgentApproval).where(
        AgentApproval.application_id == application_id
    )

    if owner_user_id is not None:
        stmt = stmt.join(Agent, AgentApproval.agent_id == Agent.id).where(
            Agent.owner_user_id == owner_user_id
        )

    if agent_id is not None:
        stmt = stmt.where(AgentApproval.agent_id == agent_id)
    if status is not None:
        stmt = stmt.where(AgentApproval.status == status)
    if since is not None:
        stmt = stmt.where(AgentApproval.created_at >= since)

    result = await db.execute(stmt)
    return result.scalar() or 0


async def expire_pending_approvals_for_agent(
    db: AsyncSession,
    agent_id: UUID,
) -> int:
    """Expire all pending approvals for an agent. Returns count expired."""
    stmt = (
        update(AgentApproval)
        .where(
            AgentApproval.agent_id == agent_id,
            AgentApproval.status == "pending",
        )
        .values(status="expired")
        .execution_options(synchronize_session=False)
    )
    result = await db.execute(stmt)
    await db.flush()
    cursor_result = cast(CursorResult[Any], result)
    return int(cursor_result.rowcount or 0)


async def count_pending_approvals_for_agents(
    db: AsyncSession,
    agent_ids: list[UUID],
) -> dict[UUID, int]:
    """Count pending approvals per agent for list enrichment."""
    if not agent_ids:
        return {}
    stmt = (
        select(AgentApproval.agent_id, func.count())
        .where(
            AgentApproval.agent_id.in_(agent_ids),
            AgentApproval.status == "pending",
        )
        .group_by(AgentApproval.agent_id)
    )
    result = await db.execute(stmt)
    rows = result.all()
    return {agent_id: count for agent_id, count in rows}


async def get_agents_by_ids(
    db: AsyncSession,
    agent_ids: list[UUID],
) -> dict[UUID, Agent]:
    """Fetch multiple agents by IDs for enrichment."""
    if not agent_ids:
        return {}
    stmt = select(Agent).where(Agent.id.in_(agent_ids))
    result = await db.execute(stmt)
    agents = result.scalars().all()
    return {a.id: a for a in agents}


async def get_user_emails_by_ids(
    db: AsyncSession,
    user_ids: list[UUID],
) -> dict[UUID, str | None]:
    """Fetch user emails by IDs for list enrichment."""
    if not user_ids:
        return {}
    from ..users.models import User

    stmt = select(User.id, User.email).where(User.id.in_(user_ids))
    result = await db.execute(stmt)
    return {row[0]: row[1] for row in result.all()}


async def get_application(
    db: AsyncSession,
    application_id: UUID,
) -> Any:
    """Fetch application by ID for verification_url_base lookup."""
    from ..applications.models import Application

    stmt = select(Application).where(Application.id == application_id)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()
