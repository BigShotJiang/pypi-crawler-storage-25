"""Domain errors for the audit domain."""

from __future__ import annotations

from ..errors import DomainError


class AuditLogNotFoundError(DomainError):
    """Raised when an audit log entry is not found."""

    def __init__(self, message: str = "Audit log entry not found") -> None:
        super().__init__("NOT_FOUND", message, status_code=404)


class AuditLogCreationError(DomainError):
    """Raised when audit log creation fails."""

    def __init__(self, message: str = "Failed to create audit log entry") -> None:
        super().__init__("DATABASE_ERROR", message, status_code=500)
