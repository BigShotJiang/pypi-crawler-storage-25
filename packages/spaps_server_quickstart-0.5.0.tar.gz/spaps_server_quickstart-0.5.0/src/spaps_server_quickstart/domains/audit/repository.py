"""Database operations for the audit domain.

Pure SQLAlchemy async repository -- no FastAPI imports.
All functions accept an ``AsyncSession`` as the first positional argument.
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any
from uuid import UUID

from sqlalchemy import delete, func, select, text
from sqlalchemy.ext.asyncio import AsyncSession

from .models import AuditLog, AuditLogArchive

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Audit log creation
# ---------------------------------------------------------------------------


async def create_audit_log(
    db: AsyncSession,
    **kwargs: Any,
) -> AuditLog:
    """Insert a new audit log entry and return the persisted instance."""
    log_entry = AuditLog(**kwargs)
    db.add(log_entry)
    await db.flush()
    await db.refresh(log_entry)
    return log_entry


# ---------------------------------------------------------------------------
# Audit log queries
# ---------------------------------------------------------------------------


async def list_logs_by_admin(
    db: AsyncSession,
    admin_user_id: UUID,
    *,
    action: str | None = None,
    resource_type: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> tuple[list[AuditLog], int]:
    """List audit logs for a specific admin user with optional filters.

    Returns (logs, total_count).
    """
    base = select(AuditLog).where(AuditLog.admin_user_id == admin_user_id)

    if action is not None:
        base = base.where(AuditLog.action == action)
    if resource_type is not None:
        base = base.where(AuditLog.resource_type == resource_type)

    # Total count
    count_stmt = select(func.count()).select_from(base.subquery())
    total = (await db.execute(count_stmt)).scalar_one()

    # Paginated results
    stmt = base.order_by(AuditLog.timestamp.desc()).offset(offset).limit(limit)
    result = await db.execute(stmt)

    return list(result.scalars().all()), total


async def list_all_logs(
    db: AsyncSession,
    *,
    admin_user_id: UUID | None = None,
    action: str | None = None,
    resource_type: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> tuple[list[AuditLog], int]:
    """List all audit logs (super admin) with optional filters.

    Returns (logs, total_count).
    """
    base = select(AuditLog)

    if admin_user_id is not None:
        base = base.where(AuditLog.admin_user_id == admin_user_id)
    if action is not None:
        base = base.where(AuditLog.action == action)
    if resource_type is not None:
        base = base.where(AuditLog.resource_type == resource_type)

    # Total count
    count_stmt = select(func.count()).select_from(base.subquery())
    total = (await db.execute(count_stmt)).scalar_one()

    # Paginated results
    stmt = base.order_by(AuditLog.timestamp.desc()).offset(offset).limit(limit)
    result = await db.execute(stmt)

    return list(result.scalars().all()), total


# ---------------------------------------------------------------------------
# Retention: archive + purge
# ---------------------------------------------------------------------------


async def archive_old_logs(
    db: AsyncSession,
    cutoff: datetime,
) -> int:
    """Move audit logs older than cutoff to the archive table.

    Uses bulk SQL (INSERT INTO ... SELECT + DELETE) to avoid loading
    all rows into memory.  Returns the number of rows archived.
    """
    # Count first
    count_stmt = select(func.count()).select_from(AuditLog).where(AuditLog.timestamp < cutoff)
    count = (await db.execute(count_stmt)).scalar() or 0

    if count == 0:
        return 0

    # Bulk insert into archive
    await db.execute(text("""
        INSERT INTO audit_logs_archive (
            id, admin_user_id, admin_email, action, resource_type,
            resource_id, resource_data, error_details, ip_address,
            user_agent, application_id, severity, timestamp
        )
        SELECT id, admin_user_id, admin_email, action, resource_type,
               resource_id, resource_data, error_details, ip_address,
               user_agent, application_id, severity, timestamp
        FROM audit_logs WHERE timestamp < :cutoff
    """), {"cutoff": cutoff})

    # Bulk delete
    await db.execute(delete(AuditLog).where(AuditLog.timestamp < cutoff))
    await db.flush()

    return count


async def purge_old_archives(
    db: AsyncSession,
    cutoff: datetime,
) -> int:
    """Delete archived logs older than cutoff.

    Returns the number of rows purged.
    """
    # Count first
    count_stmt = select(func.count()).where(AuditLogArchive.archived_at < cutoff)
    total = (await db.execute(count_stmt)).scalar_one()

    if total == 0:
        return 0

    # Delete
    delete_stmt = delete(AuditLogArchive).where(
        AuditLogArchive.archived_at < cutoff
    )
    await db.execute(delete_stmt)
    await db.flush()

    return total
