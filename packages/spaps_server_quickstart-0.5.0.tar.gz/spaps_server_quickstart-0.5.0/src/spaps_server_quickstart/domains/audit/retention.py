"""Audit log retention periodic task.

Runs as an in-process background task (matching the Node.js setInterval pattern).
Archives logs older than AUDIT_RETENTION_DAYS and purges archives older than
AUDIT_ARCHIVE_RETENTION_DAYS.

Usage:
    From the application lifespan, start the task:

        task = asyncio.create_task(run_retention_loop(session_factory))

    And cancel it on shutdown:

        task.cancel()
"""

from __future__ import annotations

import asyncio
import logging
import os

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from . import service

logger = logging.getLogger(__name__)

# Default intervals (configurable via environment)
DEFAULT_RETENTION_DAYS = 90
DEFAULT_ARCHIVE_RETENTION_DAYS = 365
DEFAULT_CLEANUP_INTERVAL_HOURS = 24


def _get_retention_config() -> tuple[int, int, int]:
    """Read retention configuration from environment variables.

    Returns (retention_days, archive_retention_days, cleanup_interval_hours).
    """
    retention_days = int(
        os.environ.get("AUDIT_RETENTION_DAYS", str(DEFAULT_RETENTION_DAYS))
    )
    archive_retention_days = int(
        os.environ.get(
            "AUDIT_ARCHIVE_RETENTION_DAYS",
            str(DEFAULT_ARCHIVE_RETENTION_DAYS),
        )
    )
    cleanup_interval_hours = int(
        os.environ.get(
            "AUDIT_CLEANUP_INTERVAL_HOURS",
            str(DEFAULT_CLEANUP_INTERVAL_HOURS),
        )
    )
    return retention_days, archive_retention_days, cleanup_interval_hours


async def run_retention_loop(
    session_factory: async_sessionmaker[AsyncSession],
    *,
    retention_days: int | None = None,
    archive_retention_days: int | None = None,
    interval_hours: int | None = None,
) -> None:
    """Run the retention cleanup loop forever.

    Matches the Node.js ``setInterval`` pattern: runs cleanup periodically
    as an in-process async background task.

    Parameters can be overridden for testing; otherwise reads from env vars.
    """
    config_retention, config_archive, config_interval = _get_retention_config()

    effective_retention = retention_days if retention_days is not None else config_retention
    effective_archive = archive_retention_days if archive_retention_days is not None else config_archive
    effective_interval = interval_hours if interval_hours is not None else config_interval

    logger.info(
        "Audit retention loop started",
        extra={
            "retention_days": effective_retention,
            "archive_retention_days": effective_archive,
            "interval_hours": effective_interval,
        },
    )

    while True:
        try:
            await asyncio.sleep(effective_interval * 3600)

            async with session_factory() as db:
                async with db.begin():
                    result = await service.retention_cleanup(
                        db,
                        retention_days=effective_retention,
                        archive_retention_days=effective_archive,
                    )
                    logger.info(
                        "Retention cleanup cycle complete",
                        extra=result,
                    )

        except asyncio.CancelledError:
            logger.info("Audit retention loop cancelled")
            break
        except Exception:
            logger.exception("Error in audit retention cleanup loop")
            # Continue the loop; don't crash on transient errors
            await asyncio.sleep(60)  # Brief pause before retry
