"""HTTP routes for the audit domain.

Provides the ``audit_router`` for admin-only audit log queries.

Audit log creation is done via the service layer (called by other domains),
not through HTTP endpoints. These routes are read-only query endpoints.
"""

from __future__ import annotations

import logging
from uuid import UUID

from fastapi import APIRouter, Query

from ...middleware.spaps_deps import AdminUser, Application, DbSession, SuperAdminUser
from . import service
from .schemas import (
    ListAllAuditLogsResponse,
    ListAuditLogsResponse,
)

logger = logging.getLogger(__name__)

audit_router = APIRouter(prefix="/audit", tags=["audit"])


@audit_router.get("/logs", response_model=ListAuditLogsResponse)
async def get_admin_logs(
    db: DbSession,
    app: Application,
    admin: AdminUser,
    admin_user_id: str | None = Query(default=None),
    action: str | None = Query(default=None),
    resource_type: str | None = Query(default=None),
    limit: int = Query(default=50, ge=1, le=1000),
    offset: int = Query(default=0, ge=0),
) -> ListAuditLogsResponse:
    """Get audit logs for the current admin (or filtered by admin_user_id).

    Requires API Key + JWT + Admin.
    """
    # Default to current admin's logs if no admin_user_id specified
    effective_admin_id = UUID(admin_user_id) if admin_user_id else (
        UUID(admin.id) if isinstance(admin.id, str) else admin.id
    )

    result = await service.get_admin_logs(
        db,
        admin_user_id=effective_admin_id,
        action=action,
        resource_type=resource_type,
        limit=limit,
        offset=offset,
    )
    return ListAuditLogsResponse(**result)


@audit_router.get("/all-logs", response_model=ListAllAuditLogsResponse)
async def get_all_logs(
    db: DbSession,
    app: Application,
    admin: SuperAdminUser,
    admin_user_id: str | None = Query(default=None),
    action: str | None = Query(default=None),
    resource_type: str | None = Query(default=None),
    limit: int = Query(default=50, ge=1, le=1000),
    offset: int = Query(default=0, ge=0),
) -> ListAllAuditLogsResponse:
    """Get all audit logs across all admins.

    Requires API Key + JWT + Super Admin.
    """
    result = await service.get_all_logs(
        db,
        admin_user_id=UUID(admin_user_id) if admin_user_id else None,
        action=action,
        resource_type=resource_type,
        limit=limit,
        offset=offset,
    )
    return ListAllAuditLogsResponse(**result)
