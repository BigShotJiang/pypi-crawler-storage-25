"""Audit domain -- immutable trail of admin actions for SPAPS."""
