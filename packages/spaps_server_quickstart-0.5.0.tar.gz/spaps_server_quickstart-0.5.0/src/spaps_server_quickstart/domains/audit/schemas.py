"""Pydantic request/response schemas for audit endpoints.

These schemas define the *data* portion of each API response.
The standard response envelope ``{ success, data, error, metadata }``
is applied by middleware -- domain schemas never reference it.

Zero FastAPI imports.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Canonical representations
# ---------------------------------------------------------------------------


class AuditLogOut(BaseModel):
    """Canonical representation of an audit log entry."""

    id: str
    admin_user_id: str | None = None
    admin_email: str | None = None
    action: str
    resource_type: str | None = None
    resource_id: str | None = None
    resource_data: dict[str, Any] | None = None
    error_details: dict[str, Any] | None = None
    ip_address: str | None = None
    user_agent: str | None = None
    application_id: str | None = None
    severity: str | None = None
    timestamp: str


# ---------------------------------------------------------------------------
# Request schemas
# ---------------------------------------------------------------------------


class ListAuditLogsParams(BaseModel):
    """GET /audit/logs query parameters."""

    admin_user_id: str | None = None
    action: str | None = None
    resource_type: str | None = None
    limit: int = Field(default=50, ge=1, le=1000)
    offset: int = Field(default=0, ge=0)


class ListAllAuditLogsParams(BaseModel):
    """GET /audit/all-logs query parameters (super admin)."""

    admin_user_id: str | None = None
    action: str | None = None
    resource_type: str | None = None
    limit: int = Field(default=50, ge=1, le=1000)
    offset: int = Field(default=0, ge=0)


# ---------------------------------------------------------------------------
# Response schemas
# ---------------------------------------------------------------------------


class ListAuditLogsResponse(BaseModel):
    """GET /audit/logs -- success payload."""

    logs: list[AuditLogOut]
    total: int


class ListAllAuditLogsResponse(BaseModel):
    """GET /audit/all-logs -- success payload."""

    logs: list[AuditLogOut]
    total: int
