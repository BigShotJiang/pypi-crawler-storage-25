"""
Application-level authorization context.

The Python rewrite replaces Supabase RLS with explicit application-level
filtering. Every repository method takes ``application_id`` and/or ``user_id``
as parameters — no implicit context via PostgreSQL session variables.

This module provides utilities for the rare cases where PostgreSQL-level
context is needed (e.g. future RLS policies on specific tables).

Mirrors consumer_server's ``domains/shared/rls.py`` pattern.
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from collections.abc import AsyncIterator
from uuid import UUID

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

APPLICATION_KEY = "app.application_id"
USER_KEY = "app.user_id"


async def _set_setting(session: AsyncSession, key: str, value: UUID | None) -> None:
    val = str(value) if value is not None else ""
    await session.execute(text(f"SELECT set_config('{key}', :val, true)"), {"val": val})


async def apply_context(
    session: AsyncSession,
    *,
    application_id: UUID | None = None,
    user_id: UUID | None = None,
) -> None:
    """Set PostgreSQL session settings for application-level filtering."""
    await _set_setting(session, APPLICATION_KEY, application_id)
    await _set_setting(session, USER_KEY, user_id)


async def clear_context(session: AsyncSession) -> None:
    """Remove all application context from the session."""
    await _set_setting(session, APPLICATION_KEY, None)
    await _set_setting(session, USER_KEY, None)


@asynccontextmanager
async def context(
    session: AsyncSession,
    *,
    application_id: UUID | None = None,
    user_id: UUID | None = None,
) -> AsyncIterator[None]:
    """Context manager to temporarily set application context."""
    await apply_context(session, application_id=application_id, user_id=user_id)
    try:
        yield
    finally:
        await clear_context(session)
