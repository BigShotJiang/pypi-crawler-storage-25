"""
Custom SQLAlchemy column types for SPAPS.
"""

from __future__ import annotations

from sqlalchemy import String, TypeDecorator


class EncryptedText(TypeDecorator):
    """
    Marker type for columns that store PII-encrypted data.

    At the database level this is just ``TEXT``. Encryption/decryption happens
    in the service layer using AES-256-GCM + HKDF-SHA256 (see the PII
    encryption service added in Phase 7).

    Using a custom type makes encrypted columns greppable and enables future
    hooks (e.g. automatic encryption in ``process_bind_param``).
    """

    impl = String
    cache_ok = True

    def process_bind_param(self, value, dialect):
        # Encryption is handled at the service layer, not the ORM layer.
        return value

    def process_result_value(self, value, dialect):
        # Decryption is handled at the service layer, not the ORM layer.
        return value
