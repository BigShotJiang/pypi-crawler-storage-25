"""
SQLAlchemy DeclarativeBase for SPAPS domains.

All domain models inherit from this Base. Alembic's env.py imports
``Base.metadata`` to auto-detect schema changes.
"""

from __future__ import annotations


from sqlalchemy.dialects.postgresql import UUID as PGUUID  # noqa: N811
from sqlalchemy.orm import (
    DeclarativeBase,
)


class Base(DeclarativeBase):
    """
    Shared declarative base for all SPAPS domain models.

    Convention: every table has a UUID primary key ``id`` and UTC timestamps
    ``created_at`` / ``updated_at`` (where applicable). Subclasses set
    ``__tablename__`` explicitly — no magic name derivation.
    """

    pass


# Re-export for convenience so domain models can do:
#   from ..._db import Base, PGUUID
__all__ = ["Base", "PGUUID"]
