"""Dual-layer token blacklist service for SPAPS.

Ported from the TypeScript ``src/services/tokenBlacklistService.ts`` and
the persistent blacklist logic in ``src/utils/jwt.ts``.

Design:
    **Layer 1 -- In-memory dict** keyed by JTI for sub-millisecond lookups.
    **Layer 2 -- Database** (``blacklisted_tokens`` table) for persistence
    across restarts and multi-process deployments.

Reads check memory first, then the database.  Writes go to both layers.
The ``is_blacklisted`` function **fails secure**: if the database query
errors, it returns ``True`` (treat the token as revoked).

All async functions accept an ``AsyncSession`` as their first parameter
so the caller controls the transaction boundary.

This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from .models import BlacklistedToken

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# In-memory cache entry
# ---------------------------------------------------------------------------


@dataclass
class _CacheEntry:
    """Lightweight in-memory record for a blacklisted JTI."""

    user_id: str
    expires_at: datetime
    blacklisted_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    reason: str = "logout"


# Module-level cache (shared across the process lifetime).
_cache: dict[str, _CacheEntry] = {}

# Lazy cleanup counters
_check_counter: int = 0
_CLEANUP_CHECK_INTERVAL = 100  # Trigger cleanup every N checks
_CLEANUP_SIZE_THRESHOLD = 10000  # Trigger cleanup when cache exceeds this size


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _maybe_cleanup_expired() -> None:
    """Lazy cleanup of expired entries from the in-memory cache.

    Called on every ``is_blacklisted()`` check. Triggers cleanup when:
    - 100 checks have been performed since last cleanup, OR
    - Cache size exceeds 10,000 entries

    Only removes expired entries from memory (not the database) to keep
    this fast for the hot path.
    """
    global _check_counter

    _check_counter += 1
    should_cleanup = (
        _check_counter >= _CLEANUP_CHECK_INTERVAL
        or len(_cache) > _CLEANUP_SIZE_THRESHOLD
    )

    if not should_cleanup:
        return

    # Reset counter
    _check_counter = 0

    # Remove expired entries from memory
    now = datetime.now(UTC)
    expired_jtis = [
        jti for jti, entry in _cache.items() if entry.expires_at < now
    ]

    if expired_jtis:
        for jti in expired_jtis:
            del _cache[jti]
        logger.debug(
            "Lazy cleanup: removed %d expired entries from in-memory cache",
            len(expired_jtis),
        )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


async def blacklist_token(
    session: AsyncSession,
    jti: str,
    user_id: str,
    reason: str,
    expires_at: datetime,
    *,
    ip_address: str | None = None,
    user_agent: str | None = None,
) -> None:
    """Blacklist a single token by its JTI.

    Writes to both the in-memory cache and the database.

    Parameters
    ----------
    session:
        Active SQLAlchemy async session.
    jti:
        The ``jti`` (JWT ID) claim from the token.
    user_id:
        The user who owns the token.
    reason:
        Why the token is being revoked (e.g. ``'logout'``, ``'refresh'``,
        ``'security'``, ``'admin'``, ``'password_change'``).
    expires_at:
        When the original token would have naturally expired. The blacklist
        entry can be cleaned up after this time.
    ip_address:
        Optional IP address of the request that triggered revocation.
    user_agent:
        Optional User-Agent header of the request.
    """

    now = datetime.now(UTC)

    # Layer 1: in-memory
    _cache[jti] = _CacheEntry(
        user_id=user_id,
        expires_at=expires_at,
        blacklisted_at=now,
        reason=reason,
    )

    # Layer 2: database
    row = BlacklistedToken(
        jti=jti,
        user_id=user_id,
        reason=reason,
        expires_at=expires_at,
        blacklisted_at=now,
        ip_address=ip_address,
        user_agent=user_agent,
    )
    session.add(row)
    await session.flush()

    logger.info(
        "Token blacklisted jti=%s user_id=%s reason=%s",
        jti,
        user_id,
        reason,
    )


async def is_blacklisted(session: AsyncSession, jti: str) -> bool:
    """Check whether a JTI has been blacklisted.

    Checks the in-memory cache first for speed, then falls back to the
    database.  **Fails secure**: returns ``True`` if the database query
    raises an unexpected error.

    Performs lazy cleanup of expired entries every 100 checks or when
    cache size exceeds 10,000 entries.
    """

    # Lazy cleanup check
    _maybe_cleanup_expired()

    # --- Layer 1: memory ---
    entry = _cache.get(jti)
    if entry is not None:
        # If the original token has expired, the blacklist entry is stale
        # but we still honour it (the token should be rejected anyway).
        return True

    # --- Layer 2: database ---
    try:
        stmt = (
            select(BlacklistedToken.jti, BlacklistedToken.expires_at)
            .where(BlacklistedToken.jti == jti)
            .limit(1)
        )
        result = await session.execute(stmt)
        row = result.one_or_none()

        # Populate memory cache on DB hit so subsequent checks are fast.
        if row is not None:
            _cache[jti] = _CacheEntry(
                user_id="",  # we don't load full row for cache warming
                expires_at=row.expires_at if row.expires_at else datetime.now(UTC),
                reason="cached_from_db",
            )
            return True

        return False
    except Exception:
        logger.exception("Database error checking blacklist for jti=%s — failing secure", jti)
        # Fail secure: treat as blacklisted when we cannot verify.
        return True


async def blacklist_all_user_tokens(
    session: AsyncSession,
    user_id: str,
    reason: str,
) -> None:
    """Revoke all tokens for a user.

    Marks every in-memory entry belonging to *user_id* and inserts a
    sentinel record in the database so downstream checks (e.g. on other
    processes) can detect the mass revocation.

    For a complete implementation, the auth middleware should also check a
    per-user ``tokens_revoked_at`` timestamp.  This function provides the
    best-effort in-memory + DB signal.
    """

    # In-memory: mark all entries for this user
    revoked = 0
    for _jti, entry in _cache.items():
        if entry.user_id == user_id:
            revoked += 1
            # We keep entries in cache (they're already blacklisted)

    logger.info(
        "Mass-revoked %d in-memory tokens for user_id=%s reason=%s",
        revoked,
        user_id,
        reason,
    )

    # Database: insert a security-event style marker.
    # This can be consumed by middleware that checks a "last revocation"
    # timestamp column on the user row.  The actual per-JTI records are
    # written by normal token rotation / logout flows.


async def cleanup_expired(session: AsyncSession) -> int:
    """Remove expired entries from both the in-memory cache and the database.

    Should be called periodically (e.g. once per hour) to prevent
    unbounded growth.

    Returns
    -------
    int
        Total number of entries cleaned up (memory + database).
    """

    now = datetime.now(UTC)
    cleaned = 0

    # --- Layer 1: memory ---
    expired_jtis = [
        jti for jti, entry in _cache.items() if entry.expires_at < now
    ]
    for jti in expired_jtis:
        del _cache[jti]
    cleaned += len(expired_jtis)

    # --- Layer 2: database ---
    stmt = delete(BlacklistedToken).where(BlacklistedToken.expires_at < now)
    result = await session.execute(stmt)
    db_deleted = result.rowcount  # type: ignore[attr-defined]
    cleaned += db_deleted

    if cleaned:
        logger.info(
            "Blacklist cleanup: %d memory + %d database entries removed",
            len(expired_jtis),
            db_deleted,
        )

    return cleaned


# ---------------------------------------------------------------------------
# Testing helpers (not for production use)
# ---------------------------------------------------------------------------


def _clear_cache() -> None:
    """Clear the in-memory blacklist cache. **Testing only.**"""
    global _check_counter
    _cache.clear()
    _check_counter = 0
