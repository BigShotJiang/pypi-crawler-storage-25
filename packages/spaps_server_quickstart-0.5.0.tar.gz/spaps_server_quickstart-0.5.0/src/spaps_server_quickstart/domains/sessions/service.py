"""Session management business logic for SPAPS.

Orchestrates the repository layer, JWT service, and blacklist service
to implement session lifecycle operations (create, refresh, validate,
revoke, logout).

Called by:
    - The **sessions router** for session introspection and management
      (get current, list, validate, revoke, touch).
    - The **auth domain** for login / refresh / logout flows
      (create_session, refresh_session, logout).

This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import hashlib
import logging
from datetime import UTC, datetime, timedelta
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from ..errors import (
    InvalidRefreshTokenError,
    NotFoundError,
)
from . import repository
from .blacklist_service import blacklist_token, is_blacklisted
from .jwt_service import (
    TokenPair,
    generate_token_pair,
    parse_duration,
    verify_refresh_token,
)
from .schemas import (
    CurrentSessionResponse,
    ListSessionsResponse,
    RevokeAllSessionsResponse,
    RevokeSessionResponse,
    SessionInfo,
    TouchSessionResponse,
    ValidateSessionResponse,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _hash_token(token: str) -> str:
    """SHA-256 hash a token string for secure storage."""
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def _token_to_session_info(
    token: repository.RefreshToken,
    *,
    tier: str | None = None,
    wallets_count: int = 0,
) -> SessionInfo:
    """Convert a ``RefreshToken`` model instance to a ``SessionInfo`` schema."""
    now = datetime.now(UTC)
    created = token.created_at
    last_activity = token.used_at or created or now

    duration_minutes: int | None = None
    if created:
        duration_minutes = int((now - created).total_seconds() / 60)

    idle_minutes: int | None = None
    if last_activity:
        idle_minutes = int((now - last_activity).total_seconds() / 60)

    last_activity_iso = last_activity.isoformat()
    return SessionInfo(
        id=str(token.id),
        user_id=str(token.user_id),
        application_id=str(token.application_id) if token.application_id else None,
        tier=tier,
        created_at=created.isoformat() if created else "",
        expires_at=token.expires_at.isoformat(),
        last_activity=last_activity_iso,
        last_used=last_activity_iso,
        user_agent=getattr(token, "user_agent", None) if isinstance(getattr(token, "user_agent", None), str) else None,
        ip_address=getattr(token, "ip_address", None) if isinstance(getattr(token, "ip_address", None), str) else None,
        wallets_count=wallets_count,
        duration_minutes=duration_minutes,
        idle_minutes=idle_minutes,
    )


# ---------------------------------------------------------------------------
# Session creation (called by auth domain during login)
# ---------------------------------------------------------------------------


async def create_session(
    db: AsyncSession,
    *,
    user_id: str,
    application_id: str = "",
    email: str | None = None,
    wallets: list[str] | None = None,
    tier: str = "basic",
    roles: list[str] | None = None,
    permissions: list[str] | None = None,
    is_admin: bool = False,
    is_super_admin: bool = False,
    jwt_secret: str,
    refresh_secret: str,
    access_expires_in: str = "1h",
    refresh_expires_in: str = "365d",
) -> dict:
    """Create a new authenticated session (access + refresh token pair).

    Generates a JWT token pair via ``jwt_service``, persists the refresh
    token hash in the database, and returns the tokens to the caller.

    This function is typically called by the auth domain during login
    flows (email/password, wallet, magic link).

    Parameters
    ----------
    db:
        Active SQLAlchemy async session.
    user_id:
        The authenticating user's ID.
    application_id:
        The client application ID.
    jwt_secret:
        HMAC secret for signing access tokens.
    refresh_secret:
        HMAC secret for signing refresh tokens.

    Returns
    -------
    dict
        ``{"access_token", "refresh_token", "expires_in", "token_type"}``
    """
    pair: TokenPair = generate_token_pair(
        user_id,
        application_id,
        email=email,
        wallets=wallets,
        tier=tier,
        roles=roles,
        permissions=permissions,
        is_admin=is_admin,
        is_super_admin=is_super_admin,
        access_secret=jwt_secret,
        refresh_secret=refresh_secret,
        access_expires_in=access_expires_in,
        refresh_expires_in=refresh_expires_in,
    )

    # Store a SHA-256 hash of the refresh token (not the raw JWT)
    refresh_hash = _hash_token(pair.refresh_token)
    refresh_ttl = parse_duration(refresh_expires_in)
    expires_at = datetime.now(UTC) + timedelta(seconds=refresh_ttl)

    await repository.create_refresh_token(
        db,
        user_id=UUID(user_id),
        token=refresh_hash,
        expires_at=expires_at,
        application_id=UUID(application_id) if application_id else None,
    )

    logger.info("Session created for user_id=%s", user_id)

    return {
        "access_token": pair.access_token,
        "refresh_token": pair.refresh_token,
        "expires_in": pair.expires_in,
        "token_type": pair.token_type,
    }


# ---------------------------------------------------------------------------
# Session refresh (called by auth domain)
# ---------------------------------------------------------------------------


async def refresh_session(
    db: AsyncSession,
    *,
    refresh_token_str: str,
    jwt_secret: str,
    refresh_secret: str,
    access_expires_in: str = "1h",
    refresh_expires_in: str = "365d",
) -> dict:
    """Rotate a refresh token and issue a new access + refresh pair.

    Steps:
        1. Verify the refresh token JWT signature and claims.
        2. Ensure the token has not been blacklisted.
        3. Look up the token hash in the database.
        4. Blacklist the old refresh token JTI.
        5. Delete the old refresh token row.
        6. Generate and persist a new token pair.

    Parameters
    ----------
    db:
        Active SQLAlchemy async session.
    refresh_token_str:
        The raw refresh token JWT from the client.
    jwt_secret:
        HMAC secret for signing access tokens.
    refresh_secret:
        HMAC secret for signing/verifying refresh tokens.

    Returns
    -------
    dict
        ``{"access_token", "refresh_token", "expires_in", "token_type"}``

    Raises
    ------
    InvalidRefreshTokenError
        If the token is expired, malformed, blacklisted, or not found in
        the database.
    """
    # 1. Verify the JWT
    payload = verify_refresh_token(refresh_token_str, refresh_secret)

    # 2. Check blacklist
    if await is_blacklisted(db, payload.jti):
        raise InvalidRefreshTokenError("Refresh token has been revoked")

    # 3. Look up the stored hash
    token_hash = _hash_token(refresh_token_str)
    stored = await repository.get_refresh_token_by_hash(db, token_hash)
    if stored is None:
        raise InvalidRefreshTokenError("Refresh token not found")

    # 4. Blacklist the old JTI so it cannot be replayed
    await blacklist_token(
        db,
        jti=payload.jti,
        user_id=payload.sub,
        reason="refresh",
        expires_at=datetime.fromtimestamp(payload.exp, tz=UTC),
    )

    # 5. Delete the old refresh token row
    await repository.revoke_token(db, stored.id)

    # 6. Generate new token pair
    new_pair: TokenPair = generate_token_pair(
        payload.sub,
        payload.app_id,
        email=payload.email,
        roles=payload.roles,
        is_admin=payload.isAdmin,
        access_secret=jwt_secret,
        refresh_secret=refresh_secret,
        access_expires_in=access_expires_in,
        refresh_expires_in=refresh_expires_in,
    )

    # 7. Persist the new refresh token hash
    new_hash = _hash_token(new_pair.refresh_token)
    new_expires_at = datetime.now(UTC) + timedelta(
        seconds=parse_duration(refresh_expires_in),
    )

    await repository.create_refresh_token(
        db,
        user_id=UUID(payload.sub),
        token=new_hash,
        expires_at=new_expires_at,
        application_id=UUID(payload.app_id) if payload.app_id else None,
    )

    logger.info("Session refreshed for user_id=%s", payload.sub)

    return {
        "access_token": new_pair.access_token,
        "refresh_token": new_pair.refresh_token,
        "expires_in": new_pair.expires_in,
        "token_type": new_pair.token_type,
    }


# ---------------------------------------------------------------------------
# Session introspection (called by sessions router)
# ---------------------------------------------------------------------------


async def get_current_session(
    db: AsyncSession,
    *,
    user_id: str,
    jti: str | None = None,
    application_id: str | None = None,
    tier: str | None = None,
    wallets_count: int = 0,
) -> CurrentSessionResponse:
    """Return information about the caller's current session.

    Looks up the most recent active refresh token for the user and
    enriches it with JWT-derived context (tier, wallet count).

    Parameters
    ----------
    db:
        Active SQLAlchemy async session.
    user_id:
        The authenticated user's ID.
    jti:
        The JTI claim from the current access token.
    application_id:
        The application ID from the current access token.
    tier:
        The user's tier from the current access token.
    wallets_count:
        Number of wallets associated with the user.
    """
    tokens = await repository.get_active_tokens_for_user(db, UUID(user_id))

    if not tokens:
        # Valid access token but no active refresh tokens
        now = datetime.now(UTC)
        now_iso = now.isoformat()
        session_info = SessionInfo(
            id=jti or "unknown",
            user_id=user_id,
            application_id=application_id,
            tier=tier,
            created_at=now_iso,
            expires_at=now_iso,
            last_activity=now_iso,
            last_used=now_iso,
            is_current=True,
            wallets_count=wallets_count,
        )
        return CurrentSessionResponse(session=session_info)

    # Most recent token represents the "current" session
    session_info = _token_to_session_info(
        tokens[0], tier=tier, wallets_count=wallets_count,
    )
    session_info.is_current = True
    return CurrentSessionResponse(session=session_info)


async def list_user_sessions(
    db: AsyncSession,
    *,
    user_id: str,
) -> ListSessionsResponse:
    """List all active sessions (refresh tokens) for a user.

    Parameters
    ----------
    db:
        Active SQLAlchemy async session.
    user_id:
        The authenticated user's ID.
    """
    tokens = await repository.get_active_tokens_for_user(db, UUID(user_id))
    sessions = [_token_to_session_info(t) for t in tokens]
    return ListSessionsResponse(sessions=sessions, total=len(sessions))


async def validate_session(
    db: AsyncSession,
    *,
    user_id: str,
    jti: str | None = None,
    application_id: str | None = None,
    tier: str | None = None,
    wallets_count: int = 0,
) -> ValidateSessionResponse:
    """Validate the caller's current session.

    If the request reached this point the access token was already
    verified by middleware.  This function performs additional checks
    (blacklist, active refresh token existence) and returns a detailed
    validation result.
    """
    # Check if the access token JTI has been blacklisted
    if jti and await is_blacklisted(db, jti):
        return ValidateSessionResponse(
            valid=False,
            reason="Token has been revoked",
        )

    tokens = await repository.get_active_tokens_for_user(db, UUID(user_id))
    if not tokens:
        return ValidateSessionResponse(
            valid=True,
            reason="Valid access token but no active refresh sessions",
        )

    session_info = _token_to_session_info(
        tokens[0], tier=tier, wallets_count=wallets_count,
    )
    return ValidateSessionResponse(valid=True, session=session_info)


# ---------------------------------------------------------------------------
# Session management (called by sessions router)
# ---------------------------------------------------------------------------


async def revoke_session(
    db: AsyncSession,
    *,
    user_id: str,
    session_id: str,
) -> RevokeSessionResponse:
    """Revoke a specific session by deleting its refresh token.

    Verifies that the session belongs to the requesting user before
    deletion.

    Raises
    ------
    NotFoundError
        If the session does not exist or does not belong to the user.
    """
    # Ownership check: ensure the token belongs to this user
    tokens = await repository.get_active_tokens_for_user(db, UUID(user_id))
    if not any(str(t.id) == session_id for t in tokens):
        raise NotFoundError(f"Session {session_id} not found")

    await repository.revoke_token(db, UUID(session_id))

    logger.info(
        "Session revoked session_id=%s user_id=%s", session_id, user_id,
    )

    return RevokeSessionResponse(
        message="Session revoked successfully",
        session_id=session_id,
    )


async def revoke_all_sessions(
    db: AsyncSession,
    *,
    user_id: str,
    current_token_jti: str | None = None,
) -> RevokeAllSessionsResponse:
    """Revoke all sessions for a user, optionally preserving the current one.

    When *current_token_jti* is provided the most recent refresh token is
    kept so the caller's session survives.

    Parameters
    ----------
    db:
        Active SQLAlchemy async session.
    user_id:
        The authenticated user's ID.
    current_token_jti:
        If provided, the most recent session is preserved.
    """
    tokens = await repository.get_active_tokens_for_user(db, UUID(user_id))

    # When preserving the current session, keep the most recent token
    except_id: UUID | None = None
    if current_token_jti and tokens:
        except_id = tokens[0].id

    revoked_ids = [
        str(t.id) for t in tokens
        if except_id is None or t.id != except_id
    ]

    count = await repository.revoke_all_user_tokens(
        db, UUID(user_id), except_token_id=except_id,
    )

    logger.info(
        "Revoked %d sessions for user_id=%s (kept=%s)",
        count,
        user_id,
        except_id,
    )

    return RevokeAllSessionsResponse(
        message=f"Revoked {count} sessions",
        revoked_count=count,
        revoked_sessions=revoked_ids,
    )


async def touch_session(
    db: AsyncSession,
    *,
    session_id: str,
    user_id: str,
) -> TouchSessionResponse:
    """Update last-activity timestamp on a session.

    Verifies ownership before updating.

    Raises
    ------
    NotFoundError
        If the session does not exist or does not belong to the user.
    """
    # Ownership check
    tokens = await repository.get_active_tokens_for_user(db, UUID(user_id))
    if not any(str(t.id) == session_id for t in tokens):
        raise NotFoundError(f"Session {session_id} not found")

    updated = await repository.touch_token(db, UUID(session_id))
    if updated is None:
        raise NotFoundError(f"Session {session_id} not found")

    return TouchSessionResponse(
        message="Session activity updated",
        session_id=session_id,
        last_activity=updated.used_at.isoformat() if updated.used_at else "",
    )


# ---------------------------------------------------------------------------
# Logout (called by auth domain)
# ---------------------------------------------------------------------------


async def logout(
    db: AsyncSession,
    *,
    access_token_jti: str,
    user_id: str,
    token_exp: int,
    refresh_token_str: str | None = None,
) -> dict:
    """Log the user out by blacklisting the access token and optionally
    revoking the refresh token.

    Parameters
    ----------
    db:
        Active SQLAlchemy async session.
    access_token_jti:
        The JTI of the access token to blacklist.
    user_id:
        The user's ID (required by the blacklist service).
    token_exp:
        The access token's ``exp`` claim (epoch seconds) so the blacklist
        entry can be cleaned up after natural expiry.
    refresh_token_str:
        If provided, the refresh token is looked up by hash and deleted.

    Returns
    -------
    dict
        ``{"message": "Logged out successfully"}``
    """
    # Blacklist the access token
    await blacklist_token(
        db,
        jti=access_token_jti,
        user_id=user_id,
        reason="logout",
        expires_at=datetime.fromtimestamp(token_exp, tz=UTC),
    )

    # Revoke the refresh token if provided
    if refresh_token_str:
        token_hash = _hash_token(refresh_token_str)
        stored = await repository.get_refresh_token_by_hash(db, token_hash)
        if stored:
            await repository.revoke_token(db, stored.id)

    logger.info("User logged out user_id=%s", user_id)

    return {"message": "Logged out successfully"}
