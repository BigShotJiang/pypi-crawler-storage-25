"""Password hashing and validation for SPAPS authentication.

Uses bcrypt directly (NOT passlib, which is incompatible with bcrypt >= 4.1).
Verified in Phase 0 that bcrypt reads Supabase's ``$2a$10$`` hashes.

This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import logging
import re

import bcrypt

from ..errors import WeakPasswordError

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Strength rules
# ---------------------------------------------------------------------------

_MIN_LENGTH = 8
_MAX_LENGTH = 128
_RE_UPPER = re.compile(r"[A-Z]")
_RE_LOWER = re.compile(r"[a-z]")
_RE_DIGIT = re.compile(r"[0-9]")


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def hash_password(password: str) -> str:
    """Hash *password* using bcrypt and return the encoded hash string.

    The result is a standard bcrypt hash (``$2b$12$...``) compatible with
    Supabase's ``$2a$`` prefix after the algorithm-id swap that bcrypt
    handles transparently.
    """

    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password.encode("utf-8"), salt)
    return hashed.decode("utf-8")


def verify_password(password: str, hashed: str) -> bool:
    """Verify *password* against a bcrypt *hashed* value.

    Returns ``True`` when the password matches, ``False`` otherwise.
    Handles both ``$2a$`` and ``$2b$`` prefixes transparently.
    """

    try:
        return bcrypt.checkpw(password.encode("utf-8"), hashed.encode("utf-8"))
    except (ValueError, TypeError):
        # Malformed hash or encoding issues -- treat as non-matching.
        logger.warning("Password verification failed due to malformed hash")
        return False


def validate_password_strength(password: str) -> None:
    """Validate that *password* meets minimum complexity requirements.

    Rules:
        - At least 8 characters
        - At most 128 characters (prevents bcrypt DoS)
        - At least 1 uppercase letter
        - At least 1 lowercase letter
        - At least 1 digit

    Raises :class:`WeakPasswordError` with a descriptive message when any
    rule is violated.
    """

    failures: list[str] = []

    if len(password) > _MAX_LENGTH:
        failures.append(f"at most {_MAX_LENGTH} characters")
    if len(password) < _MIN_LENGTH:
        failures.append(f"at least {_MIN_LENGTH} characters")
    if not _RE_UPPER.search(password):
        failures.append("at least 1 uppercase letter")
    if not _RE_LOWER.search(password):
        failures.append("at least 1 lowercase letter")
    if not _RE_DIGIT.search(password):
        failures.append("at least 1 digit")

    if failures:
        raise WeakPasswordError(
            f"Password must contain: {'; '.join(failures)}"
        )
