"""Database access layer for the sessions domain.

Pure data-access functions.  Each function takes an ``AsyncSession`` as its
first positional parameter so the caller controls the transaction boundary.

This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from uuid import UUID

from sqlalchemy import delete, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from .models import AuthMagicLinkState, AuthNonce, AuthToken, RefreshToken

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# RefreshToken operations
# ---------------------------------------------------------------------------


async def create_refresh_token(
    session: AsyncSession,
    *,
    user_id: UUID,
    token: str,
    expires_at: datetime,
    application_id: UUID | None = None,
    issued_ip: str | None = None,
    issued_user_agent: str | None = None,
) -> RefreshToken:
    """Persist a new refresh token.

    TM-011: Stores network context (IP, user agent) for anomaly detection.

    Parameters
    ----------
    session:
        Active SQLAlchemy async session.
    user_id:
        The owning user's ID.
    token:
        The refresh token value (or SHA-256 hash thereof).
    expires_at:
        When the token naturally expires.
    application_id:
        Optional application the session is scoped to.
    issued_ip:
        IP address from which this token was issued (TM-011).
    issued_user_agent:
        User agent from which this token was issued (TM-011).

    Returns
    -------
    RefreshToken
        The persisted model instance.
    """
    row = RefreshToken(
        user_id=user_id,
        token=token,
        expires_at=expires_at,
        application_id=application_id,
        issued_ip=issued_ip,
        issued_user_agent=issued_user_agent,
        last_seen_ip=issued_ip,
        last_seen_user_agent=issued_user_agent,
    )
    session.add(row)
    await session.flush()
    logger.debug("Refresh token created id=%s user_id=%s", row.id, user_id)
    return row


async def get_refresh_token_by_hash(
    session: AsyncSession,
    token_hash: str,
) -> RefreshToken | None:
    """Look up a refresh token by its stored token value.

    Returns ``None`` if no matching row exists.
    """
    stmt = select(RefreshToken).where(RefreshToken.token == token_hash)
    result = await session.execute(stmt)
    return result.scalar_one_or_none()


async def get_active_tokens_for_user(
    session: AsyncSession,
    user_id: UUID,
) -> list[RefreshToken]:
    """Return all non-expired refresh tokens for *user_id*.

    Results are ordered newest-first by ``created_at``.
    """
    now = datetime.now(UTC)
    stmt = (
        select(RefreshToken)
        .where(
            RefreshToken.user_id == user_id,
            RefreshToken.expires_at >= now,
        )
        .order_by(RefreshToken.created_at.desc())
    )
    result = await session.execute(stmt)
    return list(result.scalars().all())


async def revoke_token(
    session: AsyncSession,
    token_id: UUID,
) -> bool:
    """Delete a single refresh token by its primary key.

    Returns ``True`` if a row was deleted, ``False`` otherwise.
    """
    stmt = delete(RefreshToken).where(RefreshToken.id == token_id)
    result = await session.execute(stmt)
    deleted = result.rowcount > 0  # type: ignore[attr-defined]
    if deleted:
        logger.info("Refresh token revoked id=%s", token_id)
    return deleted


async def revoke_all_user_tokens(
    session: AsyncSession,
    user_id: UUID,
    *,
    except_token_id: UUID | None = None,
) -> int:
    """Delete all refresh tokens for *user_id*.

    Parameters
    ----------
    except_token_id:
        If provided, this token is preserved (e.g. the caller's current
        session).

    Returns
    -------
    int
        Number of tokens deleted.
    """
    conditions = [RefreshToken.user_id == user_id]
    if except_token_id is not None:
        conditions.append(RefreshToken.id != except_token_id)

    stmt = delete(RefreshToken).where(*conditions)
    result = await session.execute(stmt)
    count = result.rowcount  # type: ignore[attr-defined]
    logger.info(
        "Revoked %d refresh tokens for user_id=%s (except=%s)",
        count,
        user_id,
        except_token_id,
    )
    return count


async def touch_token(
    session: AsyncSession,
    token_id: UUID,
) -> RefreshToken | None:
    """Update ``used_at`` to the current UTC timestamp.

    Returns the updated model instance, or ``None`` if the token was
    not found.
    """
    now = datetime.now(UTC)
    stmt = (
        update(RefreshToken)
        .where(RefreshToken.id == token_id)
        .values(used_at=now)
        .returning(RefreshToken.id)
    )
    result = await session.execute(stmt)
    if result.first() is None:
        return None

    # Re-fetch the full row after the update
    fetch_stmt = select(RefreshToken).where(RefreshToken.id == token_id)
    row_result = await session.execute(fetch_stmt)
    return row_result.scalar_one_or_none()


async def cleanup_expired_tokens(session: AsyncSession) -> int:
    """Delete all expired refresh tokens.

    Should be called periodically to prevent unbounded table growth.

    Returns
    -------
    int
        Number of rows deleted.
    """
    now = datetime.now(UTC)
    stmt = delete(RefreshToken).where(RefreshToken.expires_at < now)
    result = await session.execute(stmt)
    count = result.rowcount  # type: ignore[attr-defined]
    if count:
        logger.info("Cleaned up %d expired refresh tokens", count)
    return count


# ---------------------------------------------------------------------------
# AuthNonce operations
# ---------------------------------------------------------------------------


async def create_nonce(
    session: AsyncSession,
    *,
    wallet_address: str,
    nonce: str,
    expires_at: datetime,
) -> AuthNonce:
    """Persist a new wallet authentication nonce.

    Parameters
    ----------
    session:
        Active SQLAlchemy async session.
    wallet_address:
        The wallet address the nonce is bound to.
    nonce:
        The random nonce string.
    expires_at:
        When the nonce expires.

    Returns
    -------
    AuthNonce
        The persisted model instance.
    """
    row = AuthNonce(
        wallet_address=wallet_address,
        nonce=nonce,
        expires_at=expires_at,
        used=False,
    )
    session.add(row)
    await session.flush()
    logger.debug("Nonce created for wallet %s", wallet_address)
    return row


async def get_valid_nonce(
    session: AsyncSession,
    wallet_address: str,
    nonce: str,
) -> AuthNonce | None:
    """Look up a valid (unused, non-expired) nonce.

    Returns ``None`` if no matching valid nonce exists.
    """
    now = datetime.now(UTC)
    stmt = select(AuthNonce).where(
        AuthNonce.wallet_address == wallet_address,
        AuthNonce.nonce == nonce,
        AuthNonce.used.is_(False),
        AuthNonce.expires_at >= now,
    )
    result = await session.execute(stmt)
    return result.scalar_one_or_none()


async def consume_nonce(
    session: AsyncSession,
    nonce_id: UUID,
) -> bool:
    """Atomically mark a nonce as used.

    Returns ``True`` if the nonce was found and consumed, ``False``
    if it was already used or did not exist.
    """
    stmt = (
        update(AuthNonce)
        .where(AuthNonce.id == nonce_id, AuthNonce.used.is_(False))
        .values(used=True)
        .returning(AuthNonce.id)
    )
    result = await session.execute(stmt)
    consumed = result.first() is not None
    if consumed:
        logger.debug("Nonce consumed id=%s", nonce_id)
    return consumed


async def cleanup_expired_nonces(session: AsyncSession) -> int:
    """Delete all expired or already-used nonces.

    Returns the number of rows deleted.
    """
    now = datetime.now(UTC)
    stmt = delete(AuthNonce).where(
        (AuthNonce.expires_at < now) | (AuthNonce.used.is_(True))
    )
    result = await session.execute(stmt)
    count = result.rowcount  # type: ignore[attr-defined]
    if count:
        logger.info("Cleaned up %d expired/used nonces", count)
    return count


# ---------------------------------------------------------------------------
# AuthToken operations (email verification, password reset)
# ---------------------------------------------------------------------------


async def create_auth_token(
    session: AsyncSession,
    *,
    user_id: UUID | None,
    token_hash: str,
    token_type: str,
    expires_at: datetime,
    email: str | None = None,
    application_id: UUID | None = None,
) -> AuthToken:
    """Persist a new auth token (email verification, password reset, etc.).

    Parameters
    ----------
    session:
        Active SQLAlchemy async session.
    user_id:
        The owning user's ID (nullable for pre-registration flows).
    token_hash:
        SHA-256 hash of the raw token value.
    token_type:
        Token purpose (e.g. ``'email_verification'``, ``'password_reset'``).
    expires_at:
        When the token expires.
    email:
        Optional email associated with the token.
    application_id:
        Optional application scope.

    Returns
    -------
    AuthToken
        The persisted model instance.
    """
    row = AuthToken(
        user_id=user_id,
        token_hash=token_hash,
        type=token_type,
        expires_at=expires_at,
        email=email,
        application_id=application_id,
    )
    session.add(row)
    await session.flush()
    logger.debug("Auth token created type=%s user_id=%s", token_type, user_id)
    return row


async def get_valid_auth_token(
    session: AsyncSession,
    token_hash: str,
    token_type: str,
) -> AuthToken | None:
    """Look up a valid (unused, non-expired) auth token.

    Returns ``None`` if no matching valid token exists.
    """
    now = datetime.now(UTC)
    stmt = select(AuthToken).where(
        AuthToken.token_hash == token_hash,
        AuthToken.type == token_type,
        AuthToken.used_at.is_(None),
        AuthToken.expires_at >= now,
    )
    result = await session.execute(stmt)
    return result.scalar_one_or_none()


async def consume_auth_token(
    session: AsyncSession,
    token_id: UUID,
) -> bool:
    """Mark an auth token as used by setting ``used_at``.

    Returns ``True`` if the token was found and consumed.
    """
    now = datetime.now(UTC)
    stmt = (
        update(AuthToken)
        .where(AuthToken.id == token_id, AuthToken.used_at.is_(None))
        .values(used_at=now)
        .returning(AuthToken.id)
    )
    result = await session.execute(stmt)
    consumed = result.first() is not None
    if consumed:
        logger.debug("Auth token consumed id=%s", token_id)
    return consumed


# ---------------------------------------------------------------------------
# AuthMagicLinkState operations
# ---------------------------------------------------------------------------


async def create_magic_link_state(
    session: AsyncSession,
    *,
    email: str,
    state: str,
    expires_at: datetime,
    application_id: UUID | None = None,
    metadata: dict | None = None,
) -> AuthMagicLinkState:
    """Persist a new magic-link authentication state.

    Parameters
    ----------
    session:
        Active SQLAlchemy async session.
    email:
        The email address the magic link targets.
    state:
        The opaque state parameter tying the link back to the session.
    expires_at:
        When the state expires.
    application_id:
        Optional application scope.
    metadata:
        Optional metadata dict (e.g. containing ``token_hash``).

    Returns
    -------
    AuthMagicLinkState
        The persisted model instance.
    """
    row = AuthMagicLinkState(
        email=email,
        state=state,
        expires_at=expires_at,
        application_id=application_id,
        metadata_=metadata,
    )
    session.add(row)
    await session.flush()
    logger.debug("Magic link state created for email=%s", email)
    return row


async def get_valid_magic_link_state(
    session: AsyncSession,
    state: str,
) -> AuthMagicLinkState | None:
    """Look up a valid (non-expired) magic link state.

    Returns ``None`` if no matching valid state exists.
    """
    now = datetime.now(UTC)
    stmt = select(AuthMagicLinkState).where(
        AuthMagicLinkState.state == state,
        AuthMagicLinkState.expires_at >= now,
    )
    result = await session.execute(stmt)
    return result.scalar_one_or_none()


async def consume_magic_link_state(
    session: AsyncSession,
    state_id: UUID,
) -> bool:
    """Delete a magic link state after it has been consumed.

    Returns ``True`` if the state was found and deleted.
    """
    stmt = delete(AuthMagicLinkState).where(AuthMagicLinkState.id == state_id)
    result = await session.execute(stmt)
    consumed = result.rowcount > 0  # type: ignore[attr-defined]
    if consumed:
        logger.debug("Magic link state consumed id=%s", state_id)
    return consumed
