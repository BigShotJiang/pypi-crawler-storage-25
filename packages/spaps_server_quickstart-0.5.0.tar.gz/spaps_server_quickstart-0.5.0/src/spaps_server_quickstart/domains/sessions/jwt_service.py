"""JWT generation and verification for SPAPS authentication.

Ported from the TypeScript ``src/utils/jwt.ts``. Uses PyJWT with HS256
and separate secrets for access vs. refresh tokens.

This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from datetime import UTC, datetime
from uuid import uuid4

import jwt

from ..errors import InvalidTokenError, InvalidRefreshTokenError

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_ISSUER = "spaps-auth-service"
_AUDIENCE = "spaps-client-apps"
_ALGORITHM = "HS256"

# Max caps per token type (mirrors the TypeScript implementation)
_MAX_ACCESS_SECONDS = 24 * 60 * 60       # 24 hours
_MAX_REFRESH_SECONDS = 365 * 24 * 60 * 60  # 365 days

# Regex for duration strings like "1h", "7d", "365d", "30m", "120s"
_DURATION_RE = re.compile(r"^(\d+)([smhd])$")

# ---------------------------------------------------------------------------
# Data classes for token payloads and token pair
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class AccessTokenPayload:
    """Decoded claims from a verified access token."""

    sub: str
    app_id: str
    email: str | None
    wallets: list[str]
    tier: str
    roles: list[str]
    permissions: list[str]
    isAdmin: bool
    isSuperAdmin: bool
    jti: str
    iat: int
    exp: int
    iss: str
    aud: str


@dataclass(frozen=True)
class RefreshTokenPayload:
    """Decoded claims from a verified refresh token."""

    sub: str
    app_id: str
    token_family: str
    email: str | None
    roles: list[str]
    isAdmin: bool
    jti: str
    iat: int
    exp: int
    iss: str
    aud: str


@dataclass(frozen=True)
class TokenPair:
    """Access + refresh token bundle returned on login / refresh."""

    access_token: str
    refresh_token: str
    expires_in: int
    token_type: str = "Bearer"


# ---------------------------------------------------------------------------
# Duration parsing
# ---------------------------------------------------------------------------


def parse_duration(duration_str: str) -> int:
    """Parse a human-readable duration string into seconds.

    Supported formats:
        - Plain integer: interpreted as raw seconds.
        - ``<number>s``: seconds
        - ``<number>m``: minutes
        - ``<number>h``: hours
        - ``<number>d``: days

    Returns ``3600`` (1 hour) for unparsable input (safe default).
    """

    # Plain integer (no unit suffix)
    if duration_str.isdigit():
        return int(duration_str)

    match = _DURATION_RE.match(duration_str)
    if not match:
        return 3600  # 1 hour default

    value = int(match.group(1))
    unit = match.group(2)

    if value < 0:
        return 3600

    multipliers = {"s": 1, "m": 60, "h": 3600, "d": 86400}
    return value * multipliers[unit]


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _capped_seconds(duration_str: str, token_type: str = "access") -> int:
    """Parse *duration_str* and cap to the type-specific maximum."""
    max_sec = _MAX_REFRESH_SECONDS if token_type == "refresh" else _MAX_ACCESS_SECONDS
    return min(parse_duration(duration_str), max_sec)


def _now_epoch() -> int:
    return int(datetime.now(UTC).timestamp())


# ---------------------------------------------------------------------------
# Token generation
# ---------------------------------------------------------------------------


def generate_access_token(
    user_id: str,
    application_id: str,
    *,
    email: str | None = None,
    wallets: list[str] | None = None,
    tier: str = "basic",
    roles: list[str] | None = None,
    permissions: list[str] | None = None,
    is_admin: bool = False,
    is_super_admin: bool = False,
    secret: str,
    expires_in: str = "1h",
) -> str:
    """Create a signed HS256 access token.

    Parameters
    ----------
    secret:
        HMAC signing secret. Must be >= 32 characters.
    expires_in:
        Duration string (e.g. ``'1h'``, ``'30m'``).
    """

    now = _now_epoch()
    jti = str(uuid4())
    exp_seconds = _capped_seconds(expires_in, "access")

    payload: dict = {
        "sub": user_id,
        "app_id": application_id,
        "email": email,
        "wallets": wallets or [],
        "tier": tier,
        "roles": roles or [],
        "permissions": permissions or [],
        "isAdmin": is_admin,
        "isSuperAdmin": is_super_admin,
        "jti": jti,
        "iat": now,
        "exp": now + exp_seconds,
        "iss": _ISSUER,
        "aud": _AUDIENCE,
    }

    return jwt.encode(payload, secret, algorithm=_ALGORITHM)


def generate_refresh_token(
    user_id: str,
    application_id: str,
    *,
    email: str | None = None,
    roles: list[str] | None = None,
    is_admin: bool = False,
    secret: str,
    expires_in: str = "365d",
) -> str:
    """Create a signed HS256 refresh token with a unique ``token_family``."""

    now = _now_epoch()
    jti = str(uuid4())
    token_family = str(uuid4())
    exp_seconds = _capped_seconds(expires_in, "refresh")

    payload: dict = {
        "sub": user_id,
        "app_id": application_id,
        "token_family": token_family,
        "email": email,
        "roles": roles or [],
        "isAdmin": is_admin,
        "jti": jti,
        "iat": now,
        "exp": now + exp_seconds,
        "iss": _ISSUER,
        "aud": _AUDIENCE,
    }

    return jwt.encode(payload, secret, algorithm=_ALGORITHM)


def generate_token_pair(
    user_id: str,
    application_id: str,
    *,
    email: str | None = None,
    wallets: list[str] | None = None,
    tier: str = "basic",
    roles: list[str] | None = None,
    permissions: list[str] | None = None,
    is_admin: bool = False,
    is_super_admin: bool = False,
    access_secret: str,
    refresh_secret: str,
    access_expires_in: str = "1h",
    refresh_expires_in: str = "365d",
) -> TokenPair:
    """Generate a paired access + refresh token.

    Both secrets are required and must differ from each other.
    """

    access_token = generate_access_token(
        user_id,
        application_id,
        email=email,
        wallets=wallets,
        tier=tier,
        roles=roles,
        permissions=permissions,
        is_admin=is_admin,
        is_super_admin=is_super_admin,
        secret=access_secret,
        expires_in=access_expires_in,
    )

    refresh_token = generate_refresh_token(
        user_id,
        application_id,
        email=email,
        roles=roles,
        is_admin=is_admin,
        secret=refresh_secret,
        expires_in=refresh_expires_in,
    )

    return TokenPair(
        access_token=access_token,
        refresh_token=refresh_token,
        expires_in=_capped_seconds(access_expires_in, "access"),
    )


# ---------------------------------------------------------------------------
# Token verification
# ---------------------------------------------------------------------------


def verify_access_token(token: str, secret: str) -> AccessTokenPayload:
    """Decode and verify an access token.

    Raises :class:`InvalidTokenError` on any validation failure (expired,
    bad signature, missing claims, etc.).
    """

    try:
        decoded: dict = jwt.decode(
            token,
            secret,
            algorithms=[_ALGORITHM],
            issuer=_ISSUER,
            audience=_AUDIENCE,
        )
    except jwt.ExpiredSignatureError:
        raise InvalidTokenError("Access token expired")
    except jwt.InvalidTokenError as exc:
        raise InvalidTokenError(f"Invalid access token: {exc}")

    # Structural validation
    missing = [k for k in ("sub", "app_id", "jti") if not decoded.get(k)]
    if missing:
        raise InvalidTokenError(f"Access token missing required claims: {', '.join(missing)}")

    return AccessTokenPayload(
        sub=decoded["sub"],
        app_id=decoded["app_id"],
        email=decoded.get("email"),
        wallets=decoded.get("wallets", []),
        tier=decoded.get("tier", "basic"),
        roles=decoded.get("roles", []),
        permissions=decoded.get("permissions", []),
        isAdmin=decoded.get("isAdmin", False),
        isSuperAdmin=decoded.get("isSuperAdmin", False),
        jti=decoded["jti"],
        iat=decoded.get("iat", 0),
        exp=decoded.get("exp", 0),
        iss=decoded.get("iss", _ISSUER),
        aud=decoded.get("aud", _AUDIENCE),
    )


def verify_refresh_token(token: str, secret: str) -> RefreshTokenPayload:
    """Decode and verify a refresh token.

    Raises :class:`InvalidRefreshTokenError` on any validation failure.
    """

    try:
        decoded: dict = jwt.decode(
            token,
            secret,
            algorithms=[_ALGORITHM],
            issuer=_ISSUER,
            audience=_AUDIENCE,
        )
    except jwt.ExpiredSignatureError:
        raise InvalidRefreshTokenError("Refresh token expired")
    except jwt.InvalidTokenError as exc:
        raise InvalidRefreshTokenError(f"Invalid refresh token: {exc}")

    missing = [
        k for k in ("sub", "app_id", "jti", "token_family") if not decoded.get(k)
    ]
    if missing:
        raise InvalidRefreshTokenError(
            f"Refresh token missing required claims: {', '.join(missing)}"
        )

    return RefreshTokenPayload(
        sub=decoded["sub"],
        app_id=decoded["app_id"],
        token_family=decoded["token_family"],
        email=decoded.get("email"),
        roles=decoded.get("roles", []),
        isAdmin=decoded.get("isAdmin", False),
        jti=decoded["jti"],
        iat=decoded.get("iat", 0),
        exp=decoded.get("exp", 0),
        iss=decoded.get("iss", _ISSUER),
        aud=decoded.get("aud", _AUDIENCE),
    )
