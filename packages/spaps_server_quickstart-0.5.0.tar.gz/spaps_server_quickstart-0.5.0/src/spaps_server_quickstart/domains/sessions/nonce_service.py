"""Wallet nonce management for SPAPS authentication.

Generates, stores, and validates one-time nonces used in wallet-based
sign-in flows (Solana, Ethereum, etc.).  The client signs the nonce with
their private key; the server verifies the signature and marks the nonce
as consumed to prevent replay attacks.

All async functions accept an ``AsyncSession`` as their first parameter
so the caller controls the transaction boundary.

This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import logging
import secrets
from datetime import UTC, datetime, timedelta

from sqlalchemy import delete, update
from sqlalchemy.ext.asyncio import AsyncSession

from ..errors import InvalidNonceError
from .models import AuthNonce

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Nonce generation (sync -- no DB required)
# ---------------------------------------------------------------------------


def generate_nonce() -> str:
    """Return a cryptographically random 64-character hex nonce."""
    return secrets.token_hex(32)


def create_auth_message(
    wallet_address: str,
    nonce: str,
    app_name: str = "SPAPS",
    domain: str = "sweetpotato.dev",
) -> str:
    """Build the human-readable sign-in message for wallet signing.

    The format intentionally mirrors SIWE-style messages so wallet UIs
    display something meaningful.

    Parameters
    ----------
    wallet_address:
        The wallet address being authenticated.
    nonce:
        The one-time nonce from :func:`generate_nonce`.
    app_name:
        Display name shown to the user in the wallet popup.
    domain:
        Origin domain for the request.
    """

    timestamp = datetime.now(UTC).isoformat()

    return (
        f"{app_name} wants you to sign in with your wallet:\n"
        f"{wallet_address}\n"
        f"\n"
        f"Nonce: {nonce}\n"
        f"Timestamp: {timestamp}\n"
        f"Domain: {domain}\n"
        f"\n"
        f"This request will not trigger a blockchain transaction "
        f"or cost any gas fees."
    )


# ---------------------------------------------------------------------------
# Database operations (async)
# ---------------------------------------------------------------------------


async def store_nonce(
    session: AsyncSession,
    wallet_address: str,
    nonce: str,
    expires_in: int = 300,
) -> AuthNonce:
    """Persist a new nonce for *wallet_address*.

    Parameters
    ----------
    session:
        Active SQLAlchemy async session.
    wallet_address:
        The wallet address the nonce is bound to.
    nonce:
        The hex nonce string from :func:`generate_nonce`.
    expires_in:
        TTL in seconds (default 300 = 5 minutes).

    Returns
    -------
    AuthNonce
        The persisted nonce model instance.
    """

    auth_nonce = AuthNonce(
        wallet_address=wallet_address,
        nonce=nonce,
        expires_at=datetime.now(UTC) + timedelta(seconds=expires_in),
        used=False,
    )
    session.add(auth_nonce)
    await session.flush()

    logger.debug(
        "Nonce stored for wallet %s (expires in %ds)",
        wallet_address,
        expires_in,
    )
    return auth_nonce


async def validate_nonce(
    session: AsyncSession,
    wallet_address: str,
    nonce: str,
) -> bool:
    """Atomically validate and consume a nonce.

    The nonce must:
        1. Exist for the given *wallet_address*.
        2. Not already be used.
        3. Not be expired (``expires_at >= now``).

    On success the nonce is marked ``used=True`` so it cannot be replayed.

    Parameters
    ----------
    session:
        Active SQLAlchemy async session.
    wallet_address:
        The wallet address the nonce is bound to.
    nonce:
        The nonce value to validate.

    Returns
    -------
    bool
        ``True`` if the nonce was valid and has been consumed.

    Raises
    ------
    InvalidNonceError
        When the nonce does not exist, was already used, or has expired.
    """

    now = datetime.now(UTC)

    # Atomic mark-as-used: UPDATE ... WHERE used=false AND expires_at >= now
    # returning the row to confirm it existed and qualified.
    stmt = (
        update(AuthNonce)
        .where(
            AuthNonce.wallet_address == wallet_address,
            AuthNonce.nonce == nonce,
            AuthNonce.used.is_(False),
            AuthNonce.expires_at >= now,
        )
        .values(used=True)
        .returning(AuthNonce.id)
    )

    result = await session.execute(stmt)
    row = result.first()

    if row is None:
        logger.warning(
            "Nonce validation failed for wallet %s",
            wallet_address,
        )
        raise InvalidNonceError()

    logger.debug("Nonce consumed for wallet %s", wallet_address)
    return True


async def cleanup_expired_nonces(session: AsyncSession) -> int:
    """Delete all expired or used nonces.

    Intended to be called periodically (e.g. via a background task or
    cron job) to keep the ``auth_nonces`` table lean.

    Returns
    -------
    int
        Number of rows deleted.
    """

    now = datetime.now(UTC)

    stmt = (
        delete(AuthNonce)
        .where(
            (AuthNonce.expires_at < now) | (AuthNonce.used.is_(True)),
        )
    )

    result = await session.execute(stmt)
    deleted = result.rowcount  # type: ignore[attr-defined]

    if deleted:
        logger.info("Cleaned up %d expired/used nonces", deleted)

    return deleted
