"""Pydantic request/response schemas for session endpoints.

These schemas define the *data* portion of each API response.
The standard response envelope ``{ success, data, error, metadata }``
is applied by middleware — domain schemas never reference it.

Zero FastAPI imports.
"""

from __future__ import annotations

from pydantic import BaseModel


# ---------------------------------------------------------------------------
# Shared sub-models
# ---------------------------------------------------------------------------


class SessionInfo(BaseModel):
    """Serialised representation of a single session."""

    id: str
    user_id: str
    application_id: str | None = None
    tier: str | None = None
    created_at: str
    expires_at: str
    last_activity: str
    last_used: str | None = None
    user_agent: str | None = None
    ip_address: str | None = None
    is_current: bool | None = None
    wallets_count: int = 0
    duration_minutes: int | None = None
    idle_minutes: int | None = None


# ---------------------------------------------------------------------------
# Response schemas
# ---------------------------------------------------------------------------


class CurrentSessionResponse(BaseModel):
    """GET /sessions/current — success payload."""

    session: SessionInfo


class ListSessionsResponse(BaseModel):
    """GET /sessions — success payload."""

    sessions: list[SessionInfo]
    total: int


class ValidateSessionResponse(BaseModel):
    """POST /sessions/validate — success payload."""

    valid: bool
    reason: str | None = None
    session: SessionInfo | None = None


class RevokeSessionResponse(BaseModel):
    """DELETE /sessions/:id — success payload."""

    message: str
    session_id: str


class RevokeAllSessionsResponse(BaseModel):
    """DELETE /sessions — success payload."""

    message: str
    revoked_count: int
    revoked_sessions: list[str]


class TouchSessionResponse(BaseModel):
    """POST /sessions/:id/touch — success payload."""

    message: str
    session_id: str
    last_activity: str
