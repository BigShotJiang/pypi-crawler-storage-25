"""FastAPI route handlers for session management.

Endpoints for inspecting and managing authenticated sessions.  All
routes require a valid JWT (enforced via the ``get_current_user``
dependency).  The standard response envelope is applied automatically
by ``ResponseEnvelopeMiddleware``.

Prefix: ``/sessions``
"""

from __future__ import annotations

import logging
from typing import Annotated, Any

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from ...middleware.spaps_deps import get_current_user, get_db_session
from . import service
from .schemas import (
    CurrentSessionResponse,
    ListSessionsResponse,
    RevokeAllSessionsResponse,
    RevokeSessionResponse,
    TouchSessionResponse,
    ValidateSessionResponse,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/sessions", tags=["sessions"])


# ---------------------------------------------------------------------------
# Session introspection
# ---------------------------------------------------------------------------


@router.get("/current", response_model=CurrentSessionResponse)
async def get_current_session(
    db: Annotated[AsyncSession, Depends(get_db_session)],
    user: Annotated[Any, Depends(get_current_user)],
) -> CurrentSessionResponse:
    """Get information about the caller's current session.

    Returns session metadata including tier, activity timestamps,
    and wallet count derived from the authenticated JWT context.
    """
    return await service.get_current_session(
        db,
        user_id=user.id,
        jti=user.jti,
        application_id=user.application_id,
        tier=user.tier,
        wallets_count=len(user.wallet_addresses),
    )


@router.get("/", response_model=ListSessionsResponse)
async def list_sessions(
    db: Annotated[AsyncSession, Depends(get_db_session)],
    user: Annotated[Any, Depends(get_current_user)],
) -> ListSessionsResponse:
    """List all active sessions for the authenticated user.

    Each session corresponds to an active refresh token.  Sessions
    are returned newest-first.
    """
    return await service.list_user_sessions(
        db,
        user_id=user.id,
    )


@router.post("/validate", response_model=ValidateSessionResponse)
async def validate_session(
    db: Annotated[AsyncSession, Depends(get_db_session)],
    user: Annotated[Any, Depends(get_current_user)],
) -> ValidateSessionResponse:
    """Validate the current session.

    Performs additional checks beyond JWT verification (blacklist
    lookup, active refresh token existence) and returns a detailed
    validation result.
    """
    return await service.validate_session(
        db,
        user_id=user.id,
        jti=user.jti,
        application_id=user.application_id,
        tier=user.tier,
        wallets_count=len(user.wallet_addresses),
    )


# ---------------------------------------------------------------------------
# Session management
# ---------------------------------------------------------------------------


@router.delete("/all", response_model=RevokeAllSessionsResponse)
async def revoke_all_sessions(
    db: Annotated[AsyncSession, Depends(get_db_session)],
    user: Annotated[Any, Depends(get_current_user)],
) -> RevokeAllSessionsResponse:
    """Revoke all sessions except the current one.

    Deletes all refresh tokens for the user while preserving the
    most recent session so the caller remains authenticated.
    """
    return await service.revoke_all_sessions(
        db,
        user_id=user.id,
        current_token_jti=user.jti,
    )


@router.delete("/{session_id}", response_model=RevokeSessionResponse)
async def revoke_session(
    session_id: str,
    db: Annotated[AsyncSession, Depends(get_db_session)],
    user: Annotated[Any, Depends(get_current_user)],
) -> RevokeSessionResponse:
    """Revoke a specific session by its ID.

    The session must belong to the authenticated user.
    Returns 404 if the session does not exist or belongs to
    another user.
    """
    return await service.revoke_session(
        db,
        user_id=user.id,
        session_id=session_id,
    )


@router.post("/touch", response_model=TouchSessionResponse)
async def touch_session(
    db: Annotated[AsyncSession, Depends(get_db_session)],
    user: Annotated[Any, Depends(get_current_user)],
) -> TouchSessionResponse:
    """Update last-activity timestamp for the current session.

    Used by clients to signal continued user activity, extending
    idle-timeout tracking.
    """
    return await service.touch_session(
        db,
        session_id=user.jti,
        user_id=user.id,
    )
