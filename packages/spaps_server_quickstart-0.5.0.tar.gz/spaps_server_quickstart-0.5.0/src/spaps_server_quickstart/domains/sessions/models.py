"""SQLAlchemy models for the sessions domain.

Covers refresh tokens, blacklisted tokens, auth tokens (email
verification / password reset), wallet auth nonces, and magic-link
state.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID, uuid4

from sqlalchemy import (
    Boolean,
    DateTime,
    ForeignKey,
    Index,
    Text,
    func,
)
from sqlalchemy.dialects.postgresql import JSON
from sqlalchemy.orm import Mapped, mapped_column

from .._db import Base, PGUUID


class RefreshToken(Base):
    """Long-lived refresh token issued alongside a JWT access token.

    TM-011: Network context fields (IP, user agent) enable detection of
    stolen refresh tokens by comparing the request context against the
    stored issuance and last-seen context.
    """

    __tablename__ = "refresh_tokens"
    __table_args__ = (
        Index("idx_refresh_tokens_user_id", "user_id"),
        Index("idx_refresh_tokens_application_id", "application_id"),
        Index("idx_refresh_tokens_expires_at", "expires_at"),
    )

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    user_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
    )
    application_id: Mapped[UUID | None] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("applications.id", ondelete="CASCADE"),
        nullable=True,
    )
    token: Mapped[str] = mapped_column(Text, unique=True, nullable=False)
    expires_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    used_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    # TM-011: Network context tracking for anomaly detection
    issued_ip: Mapped[str | None] = mapped_column(Text, nullable=True)
    issued_user_agent: Mapped[str | None] = mapped_column(Text, nullable=True)
    last_seen_ip: Mapped[str | None] = mapped_column(Text, nullable=True)
    last_seen_user_agent: Mapped[str | None] = mapped_column(Text, nullable=True)
    anomaly_state: Mapped[str | None] = mapped_column(
        Text, nullable=True
    )  # Values: none/alert/blocked

    def __repr__(self) -> str:
        return f"<RefreshToken id={self.id!r} user_id={self.user_id!r}>"


class BlacklistedToken(Base):
    """JWT that has been explicitly revoked before its natural expiry.

    The primary key is the ``jti`` (JWT ID) claim, not a UUID.
    """

    __tablename__ = "blacklisted_tokens"
    __table_args__ = (
        Index("idx_blacklisted_tokens_user_id", "user_id"),
        Index("idx_blacklisted_tokens_expires_at", "expires_at"),
    )

    jti: Mapped[str] = mapped_column(Text, primary_key=True)
    user_id: Mapped[UUID | None] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=True,
    )
    expires_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    blacklisted_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    ip_address: Mapped[str | None] = mapped_column(Text, nullable=True)
    user_agent: Mapped[str | None] = mapped_column(Text, nullable=True)

    def __repr__(self) -> str:
        return f"<BlacklistedToken jti={self.jti!r}>"


class AuthToken(Base):
    """Short-lived token for email verification, password reset, etc."""

    __tablename__ = "auth_tokens"
    __table_args__ = (
        Index("idx_auth_tokens_user_id", "user_id"),
        Index("idx_auth_tokens_application_id", "application_id"),
        Index("idx_auth_tokens_type", "type"),
        Index("idx_auth_tokens_expires_at", "expires_at"),
    )

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    user_id: Mapped[UUID | None] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=True,
    )
    token_hash: Mapped[str] = mapped_column(Text, unique=True, nullable=False)
    type: Mapped[str] = mapped_column(Text, nullable=False)
    email: Mapped[str | None] = mapped_column(Text, nullable=True)
    application_id: Mapped[UUID | None] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("applications.id", ondelete="CASCADE"),
        nullable=True,
    )
    expires_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    used_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    def __repr__(self) -> str:
        return f"<AuthToken id={self.id!r} type={self.type!r}>"


class AuthNonce(Base):
    """One-time nonce for wallet-based authentication.

    The client signs this nonce with their wallet private key to prove
    ownership of the address.
    """

    __tablename__ = "auth_nonces"
    __table_args__ = (
        Index("idx_auth_nonces_wallet_address", "wallet_address"),
        Index("idx_auth_nonces_expires_at", "expires_at"),
    )

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    wallet_address: Mapped[str] = mapped_column(Text, nullable=False)
    nonce: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    expires_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    used: Mapped[bool] = mapped_column(
        Boolean, server_default="false", default=False
    )

    def __repr__(self) -> str:
        return f"<AuthNonce wallet={self.wallet_address!r} used={self.used!r}>"


class AuthMagicLinkState(Base):
    """Ephemeral state for magic-link authentication flow.

    Stores the opaque ``state`` parameter that ties the emailed link
    back to the originating application and email address.
    """

    __tablename__ = "auth_magic_link_states"
    __table_args__ = (
        Index("idx_auth_magic_link_states_application_id", "application_id"),
        Index("idx_auth_magic_link_states_expires_at", "expires_at"),
    )

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    state: Mapped[str] = mapped_column(Text, unique=True, nullable=False)
    email: Mapped[str] = mapped_column(Text, nullable=False)
    application_id: Mapped[UUID | None] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("applications.id", ondelete="CASCADE"),
        nullable=True,
    )
    metadata_: Mapped[dict[str, Any] | None] = mapped_column(
        "metadata", JSON, nullable=True
    )
    expires_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    def __repr__(self) -> str:
        return f"<AuthMagicLinkState state={self.state!r} email={self.email!r}>"
