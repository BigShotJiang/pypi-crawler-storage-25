"""Domain errors for the crypto payments domain."""

from __future__ import annotations

from ..errors import DomainError


class CryptoPaymentsDisabledError(DomainError):
    """Raised when crypto payments feature is disabled."""

    def __init__(self, message: str = "Crypto payments are currently disabled") -> None:
        super().__init__("CRYPTO_PAYMENTS_DISABLED", message, status_code=503)


class UnsupportedAssetError(DomainError):
    """Raised when an unsupported crypto asset is requested."""

    def __init__(self, message: str = "Asset type not supported") -> None:
        super().__init__("UNSUPPORTED_ASSET", message, status_code=400)


class UnsupportedNetworkError(DomainError):
    """Raised when an unsupported blockchain network is requested."""

    def __init__(self, message: str = "Blockchain network not supported") -> None:
        super().__init__("UNSUPPORTED_NETWORK", message, status_code=400)


class InvoiceNotFoundError(DomainError):
    """Raised when a crypto invoice is not found."""

    def __init__(self, message: str = "Crypto invoice not found") -> None:
        super().__init__("INVOICE_NOT_FOUND", message, status_code=404)


class WebhookSignatureError(DomainError):
    """Raised when webhook HMAC signature verification fails."""

    def __init__(self, message: str = "Invalid webhook signature") -> None:
        super().__init__("INVALID_SIGNATURE", message, status_code=401)


class WebhookSignatureExpiredError(DomainError):
    """Raised when webhook signature timestamp exceeds tolerance."""

    def __init__(self, message: str = "Webhook signature expired") -> None:
        super().__init__("SIGNATURE_EXPIRED", message, status_code=401)


class DuplicateWebhookError(DomainError):
    """Raised when a duplicate webhook event is detected."""

    def __init__(self, message: str = "Duplicate webhook event") -> None:
        super().__init__("DUPLICATE_WEBHOOK", message, status_code=200)
