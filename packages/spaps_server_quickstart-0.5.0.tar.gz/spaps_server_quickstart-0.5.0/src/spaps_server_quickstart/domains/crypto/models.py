"""SQLAlchemy models for the crypto payments domain."""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any
from uuid import UUID, uuid4

from sqlalchemy import (
    DateTime,
    ForeignKey,
    Numeric,
    Text,
    func,
)
from sqlalchemy.dialects.postgresql import JSON
from sqlalchemy.orm import Mapped, mapped_column

from .._db import Base, PGUUID


class CryptoInvoice(Base):
    """Crypto payment invoice.

    Tracks a crypto payment request from creation through settlement.
    Supports multiple assets (BTC, ETH, SOL, USDC, etc.) and networks.
    """

    __tablename__ = "crypto_invoices"

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    application_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("applications.id", ondelete="CASCADE"),
        nullable=False,
    )
    asset: Mapped[str] = mapped_column(Text, nullable=False)
    network: Mapped[str] = mapped_column(Text, nullable=False)
    amount: Mapped[Decimal] = mapped_column(Numeric, nullable=False)
    status: Mapped[str] = mapped_column(Text, nullable=False, default="pending")
    underpaid: Mapped[Decimal | None] = mapped_column(Numeric, nullable=True)
    overpaid: Mapped[Decimal | None] = mapped_column(Numeric, nullable=True)
    beneficiary: Mapped[str | None] = mapped_column(Text, nullable=True)
    metadata_: Mapped[dict[str, Any] | None] = mapped_column(
        "metadata", JSON, nullable=True, default=dict
    )
    destination: Mapped[dict[str, Any] | None] = mapped_column(
        JSON, nullable=True
    )
    settlement: Mapped[dict[str, Any] | None] = mapped_column(
        JSON, nullable=True
    )
    expires_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    settled_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    def __repr__(self) -> str:
        return f"<CryptoInvoice asset={self.asset!r} status={self.status!r}>"


class LedgerTransaction(Base):
    """Ledger entry for a crypto payment.

    Each confirmed on-chain or off-chain transaction is recorded here,
    linked to the invoice it settles.
    """

    __tablename__ = "ledger_transactions"

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    invoice_id: Mapped[UUID | None] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("crypto_invoices.id", ondelete="SET NULL"),
        nullable=True,
    )
    application_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("applications.id", ondelete="CASCADE"),
        nullable=False,
    )
    asset: Mapped[str] = mapped_column(Text, nullable=False)
    network: Mapped[str] = mapped_column(Text, nullable=False)
    amount: Mapped[Decimal] = mapped_column(Numeric, nullable=False)
    source: Mapped[str | None] = mapped_column(Text, nullable=True)
    dedupe_key: Mapped[str] = mapped_column(Text, unique=True, nullable=False)
    state_detail: Mapped[str | None] = mapped_column(Text, nullable=True)
    settlement: Mapped[dict[str, Any] | None] = mapped_column(
        JSON, nullable=True
    )
    settled_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    def __repr__(self) -> str:
        return f"<LedgerTransaction asset={self.asset!r} amount={self.amount}>"


class CryptoWebhookDedupe(Base):
    """Webhook deduplication record.

    Prevents duplicate processing of the same webhook event from
    crypto payment providers.
    """

    __tablename__ = "crypto_webhook_dedupes"

    dedupe_key: Mapped[str] = mapped_column(Text, primary_key=True)
    payload: Mapped[dict[str, Any] | None] = mapped_column(
        JSON, nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    def __repr__(self) -> str:
        return f"<CryptoWebhookDedupe key={self.dedupe_key!r}>"


class AppReceivingAddress(Base):
    """Application receiving address for crypto payments.

    Maps an application to its receiving addresses per asset/network.
    """

    __tablename__ = "app_receiving_addresses"

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    application_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("applications.id", ondelete="CASCADE"),
        nullable=False,
    )
    asset: Mapped[str] = mapped_column(Text, nullable=False)
    network: Mapped[str] = mapped_column(Text, nullable=False)
    destination_type: Mapped[str | None] = mapped_column(Text, nullable=True)
    destination_address: Mapped[str | None] = mapped_column(Text, nullable=True)
    destination_details: Mapped[dict[str, Any] | None] = mapped_column(
        JSON, nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    def __repr__(self) -> str:
        return (
            f"<AppReceivingAddress asset={self.asset!r} "
            f"network={self.network!r}>"
        )


class ChainSyncState(Base):
    """Sync cursor for blockchain event providers.

    Tracks the last-processed event/block per provider to allow
    incremental syncing.
    """

    __tablename__ = "chain_sync_state"

    provider: Mapped[str] = mapped_column(Text, primary_key=True)
    cursor: Mapped[str | None] = mapped_column(Text, nullable=True)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    def __repr__(self) -> str:
        return f"<ChainSyncState provider={self.provider!r}>"
