"""Pydantic request/response schemas for crypto payment endpoints.

These schemas define the *data* portion of each API response.
The standard response envelope ``{ success, data, error, metadata }``
is applied by middleware -- domain schemas never reference it.

Zero FastAPI imports.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Canonical representations
# ---------------------------------------------------------------------------


class CryptoInvoiceOut(BaseModel):
    """Canonical representation of a crypto invoice."""

    id: str
    application_id: str
    asset: str
    network: str
    amount: str  # Decimal serialised as string for precision
    status: str
    underpaid: str | None = None
    overpaid: str | None = None
    beneficiary: str | None = None
    metadata: dict[str, Any] | None = None
    destination: dict[str, Any] | None = None
    settlement: dict[str, Any] | None = None
    expires_at: str | None = None
    settled_at: str | None = None
    created_at: str
    updated_at: str


# ---------------------------------------------------------------------------
# Request schemas
# ---------------------------------------------------------------------------


class CreateInvoiceRequest(BaseModel):
    """POST /payments/crypto/invoices body."""

    asset: str
    network: str
    amount: str = Field(..., description="Decimal amount as string")
    expires_in_seconds: int | None = Field(default=None, ge=60, le=86400)
    beneficiary: str | None = None
    metadata: dict[str, Any] | None = None


class WebhookPayload(BaseModel):
    """Generic webhook payload from a crypto provider."""

    provider: str
    event_type: str | None = None
    dedupe_key: str
    data: dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# Response schemas
# ---------------------------------------------------------------------------


class CreateInvoiceResponse(BaseModel):
    """POST /payments/crypto/invoices -- success payload."""

    invoice: CryptoInvoiceOut


class WebhookResponse(BaseModel):
    """Crypto webhook handler -- success payload."""

    received: bool = True
    message: str = "Webhook processed"


class NotImplementedResponse(BaseModel):
    """501 NOT_IMPLEMENTED stub response."""

    message: str = "Feature not yet available"
