"""Crypto payments domain — invoice creation and webhook processing for SPAPS."""
