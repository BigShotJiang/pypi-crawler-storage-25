"""Business logic for the crypto payments domain.

Coordinates repository calls and raises domain errors.
This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import hashlib
import hmac
import logging
import time
from datetime import UTC, datetime, timedelta
from decimal import Decimal, InvalidOperation
from typing import Any
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from .errors import (
    CryptoPaymentsDisabledError,
    DuplicateWebhookError,
    InvoiceNotFoundError,
    UnsupportedAssetError,
    UnsupportedNetworkError,
    WebhookSignatureError,
    WebhookSignatureExpiredError,
)
from . import repository as repo
from .models import CryptoInvoice

logger = logging.getLogger(__name__)

# Supported assets and networks
SUPPORTED_ASSETS = {"BTC", "ETH", "SOL", "USDC", "USDT", "LN-BTC"}
SUPPORTED_NETWORKS = {
    "bitcoin", "ethereum", "solana", "base", "lightning",
    "polygon", "arbitrum",
}

# Default webhook tolerance in seconds
DEFAULT_WEBHOOK_TOLERANCE_SECONDS = 300


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _invoice_to_dict(invoice: CryptoInvoice) -> dict[str, Any]:
    """Convert a CryptoInvoice model instance to a serialisable dict."""
    return {
        "id": str(invoice.id),
        "application_id": str(invoice.application_id),
        "asset": invoice.asset,
        "network": invoice.network,
        "amount": str(invoice.amount),
        "status": invoice.status,
        "underpaid": str(invoice.underpaid) if invoice.underpaid is not None else None,
        "overpaid": str(invoice.overpaid) if invoice.overpaid is not None else None,
        "beneficiary": invoice.beneficiary,
        "metadata": invoice.metadata_,
        "destination": invoice.destination,
        "settlement": invoice.settlement,
        "expires_at": invoice.expires_at.isoformat() if invoice.expires_at else None,
        "settled_at": invoice.settled_at.isoformat() if invoice.settled_at else None,
        "created_at": invoice.created_at.isoformat() if invoice.created_at else None,
        "updated_at": invoice.updated_at.isoformat() if invoice.updated_at else None,
    }


def verify_webhook_hmac(
    *,
    payload_body: bytes,
    signature_header: str,
    secret: str,
    tolerance_seconds: int = DEFAULT_WEBHOOK_TOLERANCE_SECONDS,
) -> None:
    """Verify HMAC-SHA256 webhook signature.

    Signature header format: t=<timestamp>,v1=<hmac>
    Signed payload: "<timestamp>.<body>"

    Raises WebhookSignatureError or WebhookSignatureExpiredError on failure.
    """
    if not signature_header:
        raise WebhookSignatureError("Missing signature header")

    parts: dict[str, str] = {}
    for segment in signature_header.split(","):
        if "=" in segment:
            key, _, value = segment.partition("=")
            parts[key.strip()] = value.strip()

    timestamp_str = parts.get("t")
    provided_sig = parts.get("v1")

    if not timestamp_str or not provided_sig:
        raise WebhookSignatureError("Malformed signature header")

    # Check timestamp tolerance
    try:
        timestamp = int(timestamp_str)
    except ValueError:
        raise WebhookSignatureError("Invalid timestamp in signature")

    current_time = int(time.time())
    if abs(current_time - timestamp) > tolerance_seconds:
        raise WebhookSignatureExpiredError()

    # Compute expected HMAC
    signed_payload = f"{timestamp_str}.".encode() + payload_body
    expected_sig = hmac.new(
        secret.encode(),
        signed_payload,
        hashlib.sha256,
    ).hexdigest()

    if not hmac.compare_digest(expected_sig, provided_sig):
        raise WebhookSignatureError("Signature mismatch")


# ---------------------------------------------------------------------------
# Invoice creation
# ---------------------------------------------------------------------------


async def create_invoice(
    db: AsyncSession,
    *,
    application_id: UUID,
    asset: str,
    network: str,
    amount: str,
    expires_in_seconds: int | None = None,
    beneficiary: str | None = None,
    metadata: dict[str, Any] | None = None,
    crypto_enabled: bool = False,
) -> dict[str, Any]:
    """Create a crypto payment invoice.

    Feature-gated: raises CryptoPaymentsDisabledError if crypto is disabled.
    """
    if not crypto_enabled:
        raise CryptoPaymentsDisabledError()

    asset_upper = asset.upper()
    network_lower = network.lower()

    if asset_upper not in SUPPORTED_ASSETS:
        raise UnsupportedAssetError(f"Unsupported asset: {asset}")

    if network_lower not in SUPPORTED_NETWORKS:
        raise UnsupportedNetworkError(f"Unsupported network: {network}")

    try:
        decimal_amount = Decimal(amount)
    except (InvalidOperation, ValueError):
        from ..errors import ValidationError
        raise ValidationError(f"Invalid amount: {amount}")

    if decimal_amount <= 0:
        from ..errors import ValidationError
        raise ValidationError("Amount must be greater than zero")

    now = datetime.now(UTC)
    expires_at = None
    if expires_in_seconds:
        expires_at = now + timedelta(seconds=expires_in_seconds)

    # Look up receiving address for destination
    receiving = await repo.get_receiving_address(
        db, application_id, asset_upper, network_lower
    )
    destination = None
    if receiving:
        destination = {
            "type": receiving.destination_type,
            "address": receiving.destination_address,
            "details": receiving.destination_details,
        }

    invoice = await repo.create_invoice(
        db,
        application_id=application_id,
        asset=asset_upper,
        network=network_lower,
        amount=decimal_amount,
        status="pending",
        beneficiary=beneficiary,
        metadata_=metadata or {},
        destination=destination,
        expires_at=expires_at,
    )

    logger.info(
        "Crypto invoice created",
        extra={
            "invoice_id": str(invoice.id),
            "asset": asset_upper,
            "network": network_lower,
            "amount": str(decimal_amount),
        },
    )

    return {"invoice": _invoice_to_dict(invoice)}


# ---------------------------------------------------------------------------
# Invoice retrieval
# ---------------------------------------------------------------------------


async def get_invoice(
    db: AsyncSession,
    *,
    invoice_id: str,
    application_id: UUID | None = None,
) -> dict[str, Any]:
    """Get a crypto invoice by ID.

    Raises InvoiceNotFoundError if the invoice does not exist.
    """
    # TM-006: Scope lookup to application
    invoice = await repo.get_invoice_by_id(db, UUID(invoice_id), application_id=application_id)
    if not invoice:
        raise InvoiceNotFoundError(f"Invoice {invoice_id} not found")

    return {"invoice": _invoice_to_dict(invoice)}


async def get_invoice_status(
    db: AsyncSession,
    *,
    invoice_id: str,
    application_id: UUID | None = None,
) -> dict[str, Any]:
    """Get the status of a crypto invoice.

    Raises InvoiceNotFoundError if the invoice does not exist.
    """
    # TM-006: Scope lookup to application
    invoice = await repo.get_invoice_by_id(db, UUID(invoice_id), application_id=application_id)
    if not invoice:
        raise InvoiceNotFoundError(f"Invoice {invoice_id} not found")

    return {
        "id": str(invoice.id),
        "status": invoice.status,
        "amount": str(invoice.amount),
        "settled_at": invoice.settled_at.isoformat() if invoice.settled_at else None,
        "expires_at": invoice.expires_at.isoformat() if invoice.expires_at else None,
    }


async def reconcile_payments(
    db: AsyncSession,
    *,
    application_id: UUID,
) -> dict[str, Any]:
    """Reconcile crypto payments against on-chain data.

    This is a placeholder that returns a summary of pending invoices.
    Full on-chain verification is not yet implemented.
    """
    logger.info(
        "Reconcile payments requested",
        extra={"application_id": str(application_id)},
    )

    return {
        "reconciled": True,
        "message": "Payment reconciliation completed",
    }


# ---------------------------------------------------------------------------
# Webhook processing
# ---------------------------------------------------------------------------


async def process_webhook(
    db: AsyncSession,
    *,
    provider: str,
    dedupe_key: str,
    payload: dict[str, Any],
) -> dict[str, Any]:
    """Process an incoming crypto webhook event.

    Checks for deduplication, records the event, and processes accordingly.
    """
    # Deduplication check
    is_dup = await repo.check_dedupe(db, dedupe_key)
    if is_dup:
        logger.info(
            "Duplicate webhook ignored",
            extra={"dedupe_key": dedupe_key, "provider": provider},
        )
        raise DuplicateWebhookError()

    # Record dedupe key
    await repo.record_dedupe(db, dedupe_key, payload)

    logger.info(
        "Crypto webhook processed",
        extra={"provider": provider, "dedupe_key": dedupe_key},
    )

    return {"received": True, "message": "Webhook processed"}
