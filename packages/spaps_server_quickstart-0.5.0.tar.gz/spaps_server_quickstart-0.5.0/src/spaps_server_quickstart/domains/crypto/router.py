"""HTTP routes for the crypto payments domain.

Provides:
1. ``crypto_router`` — crypto invoice creation and webhook handlers
2. ``payments_stub_router`` — 501 NOT_IMPLEMENTED stubs for wallet payments
3. ``usage_stub_router`` — 501 NOT_IMPLEMENTED stubs for usage tracking

Crypto endpoints use API Key auth (Application dependency).
Webhook endpoints verify HMAC-SHA256 signatures per provider.
"""

from __future__ import annotations

import json
import logging

from fastapi import APIRouter, Request

from ...middleware.spaps_deps import Application, DbSession
from ..errors import NotImplementedError_
from . import service
from .schemas import (
    CreateInvoiceRequest,
    CreateInvoiceResponse,
    NotImplementedResponse,
    WebhookResponse,
)

logger = logging.getLogger(__name__)


# ===========================================================================
# Crypto Payments Router
# ===========================================================================

crypto_router = APIRouter(prefix="/payments/crypto", tags=["crypto-payments"])


@crypto_router.post("/invoices", response_model=CreateInvoiceResponse, status_code=201)
async def create_invoice(
    body: CreateInvoiceRequest,
    db: DbSession,
    app: Application,
    request: Request,
) -> CreateInvoiceResponse:
    """Create a crypto payment invoice.

    Requires API key authentication.
    Feature-gated: CRYPTO_PAYMENTS_ENABLED must be True.
    """
    settings = request.app.state.settings
    crypto_enabled = getattr(settings, "crypto_payments_enabled", False)

    result = await service.create_invoice(
        db,
        application_id=app.id,
        asset=body.asset,
        network=body.network,
        amount=body.amount,
        expires_in_seconds=body.expires_in_seconds,
        beneficiary=body.beneficiary,
        metadata=body.metadata,
        crypto_enabled=crypto_enabled,
    )
    return CreateInvoiceResponse(**result)


# ---------------------------------------------------------------------------
# Webhook handlers (per provider)
# ---------------------------------------------------------------------------


async def _handle_webhook(
    request: Request,
    db: DbSession,
    provider: str,
) -> WebhookResponse:
    """Shared webhook handler logic for all crypto providers."""
    settings = request.app.state.settings
    secrets_json = getattr(settings, "crypto_webhook_secrets", "")

    # Parse provider-specific secret
    try:
        secrets = json.loads(secrets_json) if secrets_json else {}
    except (json.JSONDecodeError, TypeError):
        secrets = {}

    secret = secrets.get(provider, "")

    if not secret:
        logger.warning(
            "Crypto webhook secret not configured for provider %s; rejecting",
            provider,
        )
        from ..errors import ValidationError

        raise ValidationError(f"Webhook signing secret not configured for provider: {provider}")

    # Read raw body for signature verification
    body_bytes = await request.body()
    signature = request.headers.get("X-SPAPS-Signature", "")

    service.verify_webhook_hmac(
        payload_body=body_bytes,
        signature_header=signature,
        secret=secret,
    )

    # Parse payload
    try:
        payload = json.loads(body_bytes)
    except (json.JSONDecodeError, TypeError):
        from ..errors import ValidationError
        raise ValidationError("Invalid JSON payload")

    dedupe_key = payload.get("dedupe_key") or payload.get("id") or ""
    if not dedupe_key:
        from ..errors import ValidationError
        raise ValidationError("Missing dedupe_key in webhook payload")

    result = await service.process_webhook(
        db,
        provider=provider,
        dedupe_key=f"{provider}:{dedupe_key}",
        payload=payload,
    )
    return WebhookResponse(**result)


@crypto_router.get("/invoices/{invoice_id}")
async def get_invoice(
    invoice_id: str,
    db: DbSession,
    app: Application,
) -> dict:
    """Get a crypto payment invoice by ID.

    Requires API key authentication.
    """
    result = await service.get_invoice(db, invoice_id=invoice_id, application_id=app.id)
    return result


@crypto_router.get("/invoices/{invoice_id}/status")
async def get_invoice_status(
    invoice_id: str,
    db: DbSession,
    app: Application,
) -> dict:
    """Get the status of a crypto payment invoice.

    Requires API key authentication.
    """
    result = await service.get_invoice_status(db, invoice_id=invoice_id, application_id=app.id)
    return result


@crypto_router.post("/reconcile")
async def reconcile_payments(
    db: DbSession,
    app: Application,
) -> dict:
    """Reconcile crypto payments against on-chain data.

    Requires API key authentication.
    """
    result = await service.reconcile_payments(db, application_id=app.id)
    return result


@crypto_router.post("/webhooks/lightning", response_model=WebhookResponse)
async def lightning_webhook(
    request: Request,
    db: DbSession,
) -> WebhookResponse:
    """Handle Lightning Network payment webhooks."""
    return await _handle_webhook(request, db, "lightning")


@crypto_router.post("/webhooks/evm", response_model=WebhookResponse)
async def evm_webhook(
    request: Request,
    db: DbSession,
) -> WebhookResponse:
    """Handle EVM chain (Ethereum, Base, Polygon, etc.) payment webhooks."""
    return await _handle_webhook(request, db, "evm")


@crypto_router.post("/webhooks/solana", response_model=WebhookResponse)
async def solana_webhook(
    request: Request,
    db: DbSession,
) -> WebhookResponse:
    """Handle Solana payment webhooks."""
    return await _handle_webhook(request, db, "solana")


@crypto_router.post("/webhooks/bitcoin", response_model=WebhookResponse)
async def bitcoin_webhook(
    request: Request,
    db: DbSession,
) -> WebhookResponse:
    """Handle Bitcoin on-chain payment webhooks."""
    return await _handle_webhook(request, db, "bitcoin")


# ===========================================================================
# NOT_IMPLEMENTED Stubs — Wallet Payments
# ===========================================================================

payments_stub_router = APIRouter(prefix="/payments", tags=["payments-stubs"])


@payments_stub_router.post("/wallet-deposit", response_model=NotImplementedResponse, status_code=501)
async def wallet_deposit() -> NotImplementedResponse:
    """Wallet deposit — not yet implemented."""
    raise NotImplementedError_()


@payments_stub_router.get(
    "/wallet-transaction/{tx_id}",
    response_model=NotImplementedResponse,
    status_code=501,
)
async def wallet_transaction(tx_id: str) -> NotImplementedResponse:
    """Get wallet transaction — not yet implemented."""
    raise NotImplementedError_()


@payments_stub_router.post(
    "/create-checkout-session",
    response_model=NotImplementedResponse,
    status_code=501,
)
async def create_checkout_session() -> NotImplementedResponse:
    """Create checkout session — not yet implemented."""
    raise NotImplementedError_()


@payments_stub_router.post(
    "/create-payment-intent",
    response_model=NotImplementedResponse,
    status_code=501,
)
async def create_payment_intent() -> NotImplementedResponse:
    """Create payment intent — not yet implemented."""
    raise NotImplementedError_()


@payments_stub_router.get(
    "/subscription/{id}",
    response_model=NotImplementedResponse,
    status_code=501,
)
async def get_subscription(id: str) -> NotImplementedResponse:
    """Get subscription — not yet implemented."""
    raise NotImplementedError_()


@payments_stub_router.post(
    "/update-payment-method",
    response_model=NotImplementedResponse,
    status_code=501,
)
async def update_payment_method() -> NotImplementedResponse:
    """Update payment method — not yet implemented."""
    raise NotImplementedError_()


@payments_stub_router.post(
    "/cancel-subscription",
    response_model=NotImplementedResponse,
    status_code=501,
)
async def cancel_subscription() -> NotImplementedResponse:
    """Cancel subscription — not yet implemented."""
    raise NotImplementedError_()


@payments_stub_router.get("/balance", response_model=NotImplementedResponse, status_code=501)
async def get_balance() -> NotImplementedResponse:
    """Get balance — not yet implemented."""
    raise NotImplementedError_()


# ===========================================================================
# NOT_IMPLEMENTED Stubs — Usage Tracking
# ===========================================================================

usage_stub_router = APIRouter(prefix="/usage", tags=["usage-stubs"])


@usage_stub_router.get("/features", response_model=NotImplementedResponse, status_code=501)
async def get_features() -> NotImplementedResponse:
    """Get features — not yet implemented."""
    raise NotImplementedError_()


@usage_stub_router.post("/record", response_model=NotImplementedResponse, status_code=501)
async def record_usage() -> NotImplementedResponse:
    """Record usage — not yet implemented."""
    raise NotImplementedError_()


@usage_stub_router.get("/history", response_model=NotImplementedResponse, status_code=501)
async def get_usage_history() -> NotImplementedResponse:
    """Get usage history — not yet implemented."""
    raise NotImplementedError_()
