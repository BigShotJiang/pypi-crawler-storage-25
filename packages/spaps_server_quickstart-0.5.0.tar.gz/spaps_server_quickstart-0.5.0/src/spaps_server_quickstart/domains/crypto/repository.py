"""Database operations for the crypto payments domain.

Pure SQLAlchemy async repository -- no FastAPI imports.
All functions accept an ``AsyncSession`` as the first positional argument.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .models import (
    AppReceivingAddress,
    ChainSyncState,
    CryptoInvoice,
    CryptoWebhookDedupe,
    LedgerTransaction,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Invoice operations
# ---------------------------------------------------------------------------


async def create_invoice(
    db: AsyncSession,
    **kwargs: Any,
) -> CryptoInvoice:
    """Insert a new crypto invoice and return the persisted instance."""
    invoice = CryptoInvoice(**kwargs)
    db.add(invoice)
    await db.flush()
    await db.refresh(invoice)
    return invoice


async def get_invoice_by_id(
    db: AsyncSession,
    invoice_id: UUID,
    application_id: UUID | None = None,
) -> CryptoInvoice | None:
    """Fetch a single crypto invoice by ID, optionally scoped to application."""
    stmt = select(CryptoInvoice).where(CryptoInvoice.id == invoice_id)
    # TM-006: Scope to application when provided
    if application_id is not None:
        stmt = stmt.where(CryptoInvoice.application_id == application_id)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def update_invoice(
    db: AsyncSession,
    invoice_id: UUID,
    **kwargs: Any,
) -> CryptoInvoice | None:
    """Update a crypto invoice by ID."""
    invoice = await get_invoice_by_id(db, invoice_id)
    if invoice is None:
        return None

    for key, value in kwargs.items():
        if key == "metadata":
            invoice.metadata_ = value
        elif hasattr(invoice, key):
            setattr(invoice, key, value)

    invoice.updated_at = datetime.now(UTC)
    await db.flush()
    await db.refresh(invoice)
    return invoice


# ---------------------------------------------------------------------------
# Ledger operations
# ---------------------------------------------------------------------------


async def create_ledger_transaction(
    db: AsyncSession,
    **kwargs: Any,
) -> LedgerTransaction:
    """Insert a new ledger transaction."""
    txn = LedgerTransaction(**kwargs)
    db.add(txn)
    await db.flush()
    await db.refresh(txn)
    return txn


# ---------------------------------------------------------------------------
# Webhook deduplication
# ---------------------------------------------------------------------------


async def check_dedupe(
    db: AsyncSession,
    dedupe_key: str,
) -> bool:
    """Check if a webhook dedupe key already exists. Returns True if duplicate."""
    stmt = select(CryptoWebhookDedupe).where(
        CryptoWebhookDedupe.dedupe_key == dedupe_key
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none() is not None


async def record_dedupe(
    db: AsyncSession,
    dedupe_key: str,
    payload: dict[str, Any] | None = None,
) -> CryptoWebhookDedupe:
    """Record a webhook dedupe key to prevent reprocessing."""
    record = CryptoWebhookDedupe(dedupe_key=dedupe_key, payload=payload)
    db.add(record)
    await db.flush()
    await db.refresh(record)
    return record


# ---------------------------------------------------------------------------
# Receiving addresses
# ---------------------------------------------------------------------------


async def get_receiving_address(
    db: AsyncSession,
    application_id: UUID,
    asset: str,
    network: str,
) -> AppReceivingAddress | None:
    """Get the receiving address for an app/asset/network combination."""
    stmt = select(AppReceivingAddress).where(
        AppReceivingAddress.application_id == application_id,
        AppReceivingAddress.asset == asset,
        AppReceivingAddress.network == network,
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


# ---------------------------------------------------------------------------
# Chain sync state
# ---------------------------------------------------------------------------


async def get_sync_state(
    db: AsyncSession,
    provider: str,
) -> ChainSyncState | None:
    """Get the chain sync cursor for a provider."""
    stmt = select(ChainSyncState).where(ChainSyncState.provider == provider)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def upsert_sync_state(
    db: AsyncSession,
    provider: str,
    cursor: str,
) -> ChainSyncState:
    """Update or insert the chain sync cursor for a provider."""
    existing = await get_sync_state(db, provider)
    if existing:
        existing.cursor = cursor
        existing.updated_at = datetime.now(UTC)
        await db.flush()
        await db.refresh(existing)
        return existing

    state = ChainSyncState(provider=provider, cursor=cursor)
    db.add(state)
    await db.flush()
    await db.refresh(state)
    return state
