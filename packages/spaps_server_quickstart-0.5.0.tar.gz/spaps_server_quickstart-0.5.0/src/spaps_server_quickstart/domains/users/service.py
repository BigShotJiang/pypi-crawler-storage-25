"""Business logic for the users domain.

Orchestrates repository calls and translates results into response
schemas.  Raises domain errors when invariants are violated.

Pure async — no FastAPI imports.
"""

from __future__ import annotations

import logging

from sqlalchemy.ext.asyncio import AsyncSession

from ..dayrate import service as dayrate_service
from ..errors import NotFoundError
from . import repository as repo
from .models import User
from .schemas import (
    BatchEmailsResponse,
    BatchUsersResponse,
    UserBatchInfo,
)

logger = logging.getLogger(__name__)


async def get_user_profile(db: AsyncSession, user_id: str) -> User:
    """Return a user or raise ``NotFoundError``."""
    user = await repo.get_user_by_id(db, user_id)
    if user is None:
        raise NotFoundError(f"User {user_id} not found")
    return user


async def batch_get_emails(
    db: AsyncSession,
    user_ids: list[str],
    application_id: str | None = None,
) -> BatchEmailsResponse:
    """Resolve a list of user IDs to their email addresses.

    Returns a mapping of ``{user_id: email | null}`` together with
    summary counts.  IDs that do not exist in the database are
    included in the mapping with a ``None`` value.

    When *application_id* is provided, only users belonging to that
    application are resolved.
    """
    emails_map = await repo.get_user_emails_by_ids(
        db, user_ids, application_id=application_id,
    )

    # Include requested IDs that were not found as None
    full_map: dict[str, str | None] = {
        uid: emails_map.get(uid) for uid in user_ids
    }
    with_email = sum(1 for v in full_map.values() if v is not None)

    return BatchEmailsResponse(
        emails=full_map,
        total=len(full_map),
        with_email=with_email,
    )


async def batch_get_users(
    db: AsyncSession,
    user_ids: list[str],
    application_id: str | None = None,
) -> BatchUsersResponse:
    """Return profile info for a batch of user IDs.

    Unknown IDs are omitted from the result rather than raising.

    When *application_id* is provided, only users belonging to that
    application are returned.  Also includes upcoming_bookings (next 28 days)
    per user for the calling application (checkin_call_booking US-8).
    """
    from uuid import UUID

    users = await repo.get_users_by_ids(
        db, user_ids, application_id=application_id,
    )

    # Build user map with emails
    users_map: dict[str, UserBatchInfo] = {}
    emails: dict[str, str] = {}
    for user in users:
        uid = str(user.id)
        users_map[uid] = UserBatchInfo(
            email=user.email,
            active_entitlements=None,
            upcoming_bookings=[],
        )
        if user.email:
            emails[uid] = user.email

    # Fetch upcoming bookings if application_id is provided
    if application_id and users_map:
        try:
            app_uuid = UUID(application_id)
            bookings_map = await dayrate_service.get_upcoming_bookings_for_users(
                db,
                application_id=app_uuid,
                user_ids=list(users_map.keys()),
                emails=emails,
            )
            for uid, bookings in bookings_map.items():
                if uid in users_map:
                    users_map[uid].upcoming_bookings = bookings
        except Exception:
            logger.exception("Failed to fetch upcoming bookings for batch")
            # Non-fatal: upcoming_bookings defaults to empty list

    return BatchUsersResponse(users=users_map)


async def find_or_create_user(
    db: AsyncSession,
    email: str,
    password_hash: str | None = None,
    **kwargs,
) -> tuple[User, bool]:
    """Find an existing user by email or create a new one.

    Returns a ``(user, is_new)`` tuple where ``is_new`` is ``True``
    when the user was freshly created.
    """
    existing = await repo.get_user_by_email(db, email)
    if existing is not None:
        return existing, False

    user = await repo.create_user(
        db,
        email=email,
        password_hash=password_hash,
        username=kwargs.get("username"),
        phone_number=kwargs.get("phone_number"),
    )
    logger.info("Created new user %s for email %s", user.id, email)
    return user, True


async def set_password(
    db: AsyncSession,
    user_id: str,
    new_password_hash: str,
) -> bool:
    """Update a user's password hash.

    Returns ``True`` on success. Raises ``NotFoundError`` if the user
    does not exist.
    """
    updated = await repo.update_password(db, user_id, new_password_hash)
    if not updated:
        raise NotFoundError(f"User {user_id} not found")
    return True
