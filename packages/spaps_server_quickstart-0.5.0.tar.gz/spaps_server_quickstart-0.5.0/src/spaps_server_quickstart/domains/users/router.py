"""HTTP routes for the users domain.

Exposes server-to-server batch endpoints that require API-key
authentication only (no JWT).  The response envelope is applied
automatically by ``ResponseEnvelopeMiddleware``.
"""

from __future__ import annotations

import logging
from typing import Annotated, Any

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from ...middleware.spaps_deps import get_application, get_db_session
from . import service
from .schemas import (
    BatchEmailsRequest,
    BatchEmailsResponse,
    BatchUsersRequest,
    BatchUsersResponse,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/users", tags=["users"])


@router.post("/emails", response_model=BatchEmailsResponse)
@router.post("/batch/emails", response_model=BatchEmailsResponse, deprecated=True)
async def batch_get_emails(
    body: BatchEmailsRequest,
    db: Annotated[AsyncSession, Depends(get_db_session)],
    _app: Annotated[Any, Depends(get_application)],
) -> BatchEmailsResponse:
    """Get emails for a list of user IDs (max 100).

    Requires API-key authentication.  Returns a mapping of
    ``user_id -> email`` for each requested ID.  Missing users
    are included with a ``null`` email value.
    """
    application_id = str(_app.id)
    return await service.batch_get_emails(
        db, body.user_ids, application_id=application_id,
    )


@router.post("/batch", response_model=BatchUsersResponse)
async def batch_get_users(
    body: BatchUsersRequest,
    db: Annotated[AsyncSession, Depends(get_db_session)],
    _app: Annotated[Any, Depends(get_application)],
) -> BatchUsersResponse:
    """Get user info for a list of user IDs.

    Requires API-key authentication.  Returns profile data keyed
    by user ID.  Unknown IDs are omitted from the response.
    """
    application_id = str(_app.id)
    return await service.batch_get_users(
        db, body.user_ids, application_id=application_id,
    )
