"""Database operations for the users domain.

Pure SQLAlchemy async repository — no FastAPI imports.
All functions accept an ``AsyncSession`` as the first positional argument.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from .models import User, UserApplication

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Core CRUD — User
# ---------------------------------------------------------------------------


async def get_user_by_id(db: AsyncSession, user_id: str) -> User | None:
    """Fetch a single user by primary key."""
    result = await db.execute(select(User).where(User.id == user_id))
    return result.scalar_one_or_none()


async def get_user_by_email(db: AsyncSession, email: str) -> User | None:
    """Fetch a single user by email address."""
    result = await db.execute(select(User).where(User.email == email))
    return result.scalar_one_or_none()


async def create_user(
    db: AsyncSession,
    email: str,
    password_hash: str | None = None,
    username: str | None = None,
    phone_number: str | None = None,
) -> User:
    """Insert a new user and return the persisted instance."""
    user = User(
        email=email,
        password_hash=password_hash,
        username=username,
        phone_number=phone_number,
    )
    db.add(user)
    await db.flush()
    await db.refresh(user)
    return user


async def update_user(
    db: AsyncSession,
    user_id: str,
    **kwargs: Any,
) -> User | None:
    """Update arbitrary columns on a user row.

    Only keys that correspond to real model attributes are applied.
    Returns ``None`` if the user does not exist.
    """
    user = await get_user_by_id(db, user_id)
    if user is None:
        return None

    for key, value in kwargs.items():
        if hasattr(user, key):
            setattr(user, key, value)

    user.updated_at = datetime.now(UTC)
    await db.flush()
    await db.refresh(user)
    return user


async def update_password(
    db: AsyncSession,
    user_id: str,
    password_hash: str,
) -> bool:
    """Set the password hash for a user.

    Returns ``True`` if the user was found and updated, ``False`` otherwise.
    """
    stmt = (
        update(User)
        .where(User.id == user_id)
        .values(password_hash=password_hash, updated_at=datetime.now(UTC))
    )
    result = await db.execute(stmt)
    await db.flush()
    return result.rowcount > 0  # type: ignore[attr-defined]


# ---------------------------------------------------------------------------
# Batch operations
# ---------------------------------------------------------------------------


async def get_users_by_ids(
    db: AsyncSession,
    user_ids: list[str],
    application_id: str | None = None,
) -> list[User]:
    """Fetch multiple users in a single query.

    When *application_id* is provided, only users that belong to that
    application (via ``user_applications``) are returned.
    """
    if not user_ids:
        return []
    stmt = select(User).where(User.id.in_(user_ids))
    if application_id:
        stmt = stmt.join(
            UserApplication, User.id == UserApplication.user_id
        ).where(UserApplication.application_id == application_id)
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def get_user_emails_by_ids(
    db: AsyncSession,
    user_ids: list[str],
    application_id: str | None = None,
) -> dict[str, str | None]:
    """Return a ``{user_id: email | None}`` mapping for the given IDs.

    When *application_id* is provided, only users that belong to that
    application are included. Users that do not exist are omitted.
    """
    if not user_ids:
        return {}
    stmt = select(User.id, User.email).where(User.id.in_(user_ids))
    if application_id:
        stmt = stmt.join(
            UserApplication, User.id == UserApplication.user_id
        ).where(UserApplication.application_id == application_id)
    result = await db.execute(stmt)
    return {str(row.id): row.email for row in result.all()}


# ---------------------------------------------------------------------------
# User–Application relationships
# ---------------------------------------------------------------------------


async def get_user_application(
    db: AsyncSession,
    user_id: str,
    app_id: str,
) -> UserApplication | None:
    """Look up a user's association with a specific application."""
    stmt = select(UserApplication).where(
        UserApplication.user_id == user_id,
        UserApplication.application_id == app_id,
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def create_user_application(
    db: AsyncSession,
    user_id: str,
    app_id: str,
    permissions: dict | None = None,
) -> UserApplication:
    """Create a new user–application association."""
    ua = UserApplication(
        user_id=UUID(user_id) if isinstance(user_id, str) else user_id,
        application_id=UUID(app_id) if isinstance(app_id, str) else app_id,
        permissions=permissions,
    )
    db.add(ua)
    await db.flush()
    await db.refresh(ua)
    return ua


async def update_user_application(
    db: AsyncSession,
    user_id: str,
    app_id: str,
    **kwargs: Any,
) -> UserApplication | None:
    """Update columns on a user–application association.

    Returns ``None`` if the association does not exist.
    """
    ua = await get_user_application(db, user_id, app_id)
    if ua is None:
        return None

    for key, value in kwargs.items():
        if hasattr(ua, key):
            setattr(ua, key, value)

    ua.updated_at = datetime.now(UTC)
    await db.flush()
    await db.refresh(ua)
    return ua
