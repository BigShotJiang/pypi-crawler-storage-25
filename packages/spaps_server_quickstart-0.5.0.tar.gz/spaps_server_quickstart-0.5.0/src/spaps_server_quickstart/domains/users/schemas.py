"""Pydantic request/response schemas for user endpoints (server-to-server).

These schemas define the *data* portion of each API response.
The standard response envelope ``{ success, data, error, metadata }``
is applied by middleware — domain schemas never reference it.

Zero FastAPI imports.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Request schemas
# ---------------------------------------------------------------------------


class BatchEmailsRequest(BaseModel):
    """POST /users/batch/emails"""

    user_ids: list[str] = Field(max_length=100)


class BatchUsersRequest(BaseModel):
    """POST /users/batch"""

    user_ids: list[str]


# ---------------------------------------------------------------------------
# Response schemas
# ---------------------------------------------------------------------------


class BatchEmailsResponse(BaseModel):
    """POST /users/batch/emails — success payload."""

    emails: dict[str, str | None]  # {user_id: email | null}
    total: int
    with_email: int


class UserBatchInfo(BaseModel):
    """Per-user info returned by the batch-users endpoint.

    Enhanced with upcoming_bookings for checkin_call_booking (US-8).
    """

    email: str | None = None
    active_entitlements: list[dict] | None = None
    upcoming_bookings: list[dict[str, Any]] | None = None


class BatchUsersResponse(BaseModel):
    """POST /users/batch — success payload."""

    users: dict[str, UserBatchInfo]
