"""Database operations for the documentation domain.

Pure SQLAlchemy async repository -- no FastAPI imports.
All functions accept an ``AsyncSession`` as the first positional argument.
"""

from __future__ import annotations

import logging
from typing import Any
from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from .models import (
    CodeExample,
    DocEmbedding,
    DocFeedback,
    Documentation,
    DocumentationCategory,
    EndpointDocumentation,
    ErrorDoc,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Documentation search (hybrid keyword + vector)
# ---------------------------------------------------------------------------


async def search_docs_keyword(
    db: AsyncSession,
    *,
    query: str,
    context: str | None = None,
    limit: int = 10,
) -> list[Documentation]:
    """Keyword-based documentation search using ILIKE.

    This is the baseline search. Vector search can be layered on
    when embeddings are available.
    """
    pattern = f"%{query}%"
    stmt = (
        select(Documentation)
        .where(
            Documentation.is_published.is_(True),
            (Documentation.title.ilike(pattern)) | (Documentation.content.ilike(pattern)),
        )
    )

    if context is not None:
        stmt = stmt.where(Documentation.category == context)

    stmt = stmt.order_by(Documentation.created_at.desc()).limit(limit)

    result = await db.execute(stmt)
    return list(result.scalars().all())


async def search_docs_vector(
    db: AsyncSession,
    *,
    embedding: list[float],
    context: str | None = None,
    limit: int = 10,
) -> list[Any]:
    """Vector similarity search using pgvector cosine distance.

    Returns (Documentation, score) tuples sorted by relevance.
    """
    # Cosine distance: 1 - (a <=> b) gives similarity
    distance = DocEmbedding.embedding.cosine_distance(embedding)
    stmt = (
        select(Documentation, (1 - distance).label("score"))
        .join(DocEmbedding, DocEmbedding.doc_id == Documentation.id)
        .where(Documentation.is_published.is_(True))
    )

    if context is not None:
        stmt = stmt.where(Documentation.category == context)

    stmt = stmt.order_by(distance).limit(limit)

    result = await db.execute(stmt)
    return list(result.all())


# ---------------------------------------------------------------------------
# Documentation lookups
# ---------------------------------------------------------------------------


async def get_doc_by_id(
    db: AsyncSession,
    doc_id: UUID,
) -> Documentation | None:
    """Fetch a documentation article by ID."""
    stmt = select(Documentation).where(Documentation.id == doc_id)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


# ---------------------------------------------------------------------------
# Endpoint documentation
# ---------------------------------------------------------------------------


async def get_endpoint_doc(
    db: AsyncSession,
    method: str,
    path: str,
) -> EndpointDocumentation | None:
    """Fetch endpoint documentation by method and path."""
    stmt = select(EndpointDocumentation).where(
        func.upper(EndpointDocumentation.method) == method.upper(),
        EndpointDocumentation.path == path,
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


# ---------------------------------------------------------------------------
# Error documentation
# ---------------------------------------------------------------------------


async def get_error_doc(
    db: AsyncSession,
    code: str,
) -> ErrorDoc | None:
    """Fetch error documentation by error code."""
    stmt = select(ErrorDoc).where(ErrorDoc.code == code)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


# ---------------------------------------------------------------------------
# Code examples
# ---------------------------------------------------------------------------


async def get_examples_by_feature(
    db: AsyncSession,
    feature: str,
    *,
    language: str | None = None,
) -> list[CodeExample]:
    """Get code examples for a feature, optionally filtered by language."""
    stmt = select(CodeExample).where(CodeExample.feature == feature)

    if language is not None:
        stmt = stmt.where(CodeExample.language == language)

    stmt = stmt.order_by(CodeExample.created_at.asc())

    result = await db.execute(stmt)
    return list(result.scalars().all())


async def get_examples_by_error_code(
    db: AsyncSession,
    error_code: str,
    *,
    language: str | None = None,
) -> list[CodeExample]:
    """Get code examples for an error code."""
    stmt = select(CodeExample).where(CodeExample.error_code == error_code)

    if language is not None:
        stmt = stmt.where(CodeExample.language == language)

    stmt = stmt.order_by(CodeExample.created_at.asc())

    result = await db.execute(stmt)
    return list(result.scalars().all())


async def get_examples_by_doc_id(
    db: AsyncSession,
    doc_id: UUID,
    *,
    language: str | None = None,
) -> list[CodeExample]:
    """Get code examples linked to a documentation article."""
    stmt = select(CodeExample).where(CodeExample.doc_id == doc_id)

    if language is not None:
        stmt = stmt.where(CodeExample.language == language)

    stmt = stmt.order_by(CodeExample.created_at.asc())

    result = await db.execute(stmt)
    return list(result.scalars().all())


# ---------------------------------------------------------------------------
# Categories
# ---------------------------------------------------------------------------


async def list_categories(
    db: AsyncSession,
) -> list[DocumentationCategory]:
    """List all documentation categories ordered by order_index."""
    stmt = (
        select(DocumentationCategory)
        .order_by(DocumentationCategory.order_index.asc())
    )
    result = await db.execute(stmt)
    return list(result.scalars().all())


# ---------------------------------------------------------------------------
# Feedback
# ---------------------------------------------------------------------------


async def create_feedback(
    db: AsyncSession,
    *,
    document_id: str,
    helpful: bool,
    suggestion: str | None = None,
) -> DocFeedback:
    """Insert a documentation feedback record."""
    feedback = DocFeedback(
        document_id=document_id,
        helpful=helpful,
        suggestion=suggestion,
    )
    db.add(feedback)
    await db.flush()
    await db.refresh(feedback)
    return feedback


# ---------------------------------------------------------------------------
# Indexing (for service.index_document)
# ---------------------------------------------------------------------------


async def create_documentation(
    db: AsyncSession,
    **kwargs: Any,
) -> Documentation:
    """Insert a new documentation article."""
    doc = Documentation(**kwargs)
    db.add(doc)
    await db.flush()
    await db.refresh(doc)
    return doc


async def create_doc_embedding(
    db: AsyncSession,
    **kwargs: Any,
) -> DocEmbedding:
    """Insert a doc embedding chunk."""
    embedding = DocEmbedding(**kwargs)
    db.add(embedding)
    await db.flush()
    await db.refresh(embedding)
    return embedding
