"""HTTP routes for the documentation domain.

Provides:
1. ``docs_router`` -- documentation search, endpoint docs, error docs,
   examples, categories, and feedback under ``/docs``
2. ``openapi_router`` -- OpenAPI spec endpoints (JSON + YAML)
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Query, Request
from fastapi.responses import Response

from ...middleware.spaps_deps import Application, DbSession
from . import service
from .schemas import (
    CategoriesResponse,
    EndpointDocResponse,
    ErrorDocResponse,
    ExamplesResponse,
    FeedbackRequest,
    FeedbackResponse,
    SearchRequest,
    SearchResponse,
)

logger = logging.getLogger(__name__)


# ===========================================================================
# Documentation Router
# ===========================================================================

docs_router = APIRouter(prefix="/docs", tags=["docs"])


@docs_router.post("/search", response_model=SearchResponse)
async def search_docs(
    body: SearchRequest,
    db: DbSession,
    app: Application,
) -> SearchResponse:
    """Search documentation with hybrid keyword/vector matching.

    Requires API key authentication.
    """
    result = await service.search(
        db,
        query=body.query,
        context=body.context,
        limit=body.limit,
        include_examples=body.includeExamples,
        language=body.language,
    )
    return SearchResponse(**result)


@docs_router.get("/endpoints/{method}/{path:path}", response_model=EndpointDocResponse)
async def get_endpoint_doc(
    method: str,
    path: str,
    db: DbSession,
    app: Application,
) -> EndpointDocResponse:
    """Get documentation for a specific API endpoint.

    Requires API key authentication.
    """
    result = await service.get_endpoint_doc(
        db,
        method=method,
        path=path,
    )
    return EndpointDocResponse(**result)


@docs_router.get("/errors/{code}", response_model=ErrorDocResponse)
async def get_error_doc(
    code: str,
    db: DbSession,
    app: Application,
    includeExamples: bool = Query(default=False),
) -> ErrorDocResponse:
    """Get documentation for an error code.

    Requires API key authentication.
    """
    result = await service.get_error_doc(
        db,
        code=code,
        include_examples=includeExamples,
    )
    return ErrorDocResponse(**result)


@docs_router.get("/examples/{feature}", response_model=ExamplesResponse)
async def get_examples(
    feature: str,
    db: DbSession,
    app: Application,
    language: str | None = Query(default=None),
) -> ExamplesResponse:
    """Get code examples for a feature.

    Requires API key authentication.
    """
    result = await service.get_examples(
        db,
        feature=feature,
        language=language,
    )
    return ExamplesResponse(**result)


@docs_router.get("/categories", response_model=CategoriesResponse)
async def get_categories(
    db: DbSession,
    app: Application,
) -> CategoriesResponse:
    """List all documentation categories.

    Requires API key authentication.
    """
    result = await service.get_categories(db)
    return CategoriesResponse(**result)


@docs_router.post("/feedback", response_model=FeedbackResponse)
async def submit_feedback(
    body: FeedbackRequest,
    db: DbSession,
    app: Application,
) -> FeedbackResponse:
    """Submit feedback for a documentation article.

    Requires API key authentication.
    """
    result = await service.submit_feedback(
        db,
        document_id=body.documentId,
        helpful=body.helpful,
        suggestion=body.suggestion,
    )
    return FeedbackResponse(**result)


# ===========================================================================
# OpenAPI Router
# ===========================================================================

openapi_router = APIRouter(tags=["openapi"])


@openapi_router.get("/api-docs")
async def get_openapi_json(request: Request) -> Response:
    """Return the OpenAPI specification as JSON.

    No authentication required.
    """
    import json

    openapi_schema = request.app.openapi()
    return Response(
        content=json.dumps(openapi_schema, indent=2),
        media_type="application/json",
    )


@openapi_router.get("/api-docs.yaml")
async def get_openapi_yaml(request: Request) -> Response:
    """Return the OpenAPI specification as YAML.

    No authentication required.
    """
    import yaml

    openapi_schema = request.app.openapi()
    yaml_content = yaml.dump(openapi_schema, default_flow_style=False, sort_keys=False)
    return Response(
        content=yaml_content,
        media_type="application/x-yaml",
    )
