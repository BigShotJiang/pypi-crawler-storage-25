"""Business logic for the documentation domain.

Coordinates repository calls and raises domain errors.
This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import logging
from typing import Any
from uuid import uuid4

from sqlalchemy.exc import OperationalError, ProgrammingError
from sqlalchemy.ext.asyncio import AsyncSession

from . import repository as repo
from .errors import (
    DocSearchError,
    EndpointNotFoundError,
    ErrorDocNotFoundError,
    ExamplesNotFoundError,
)
from .models import (
    CodeExample,
    Documentation,
    DocumentationCategory,
    EndpointDocumentation,
    ErrorDoc,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _doc_to_dict(doc: Documentation, *, score: float | None = None) -> dict[str, Any]:
    """Convert a Documentation model instance to a serialisable dict."""
    return {
        "id": str(doc.id),
        "slug": doc.slug,
        "title": doc.title,
        "content": doc.content,
        "category": doc.category,
        "tags": doc.tags,
        "score": score,
    }


def _example_to_dict(example: CodeExample) -> dict[str, Any]:
    """Convert a CodeExample model instance to a serialisable dict."""
    return {
        "id": str(example.id),
        "title": example.title,
        "description": example.description,
        "language": example.language,
        "code": example.code,
        "dependencies": example.dependencies,
        "output": example.output,
    }


def _error_doc_to_dict(error: ErrorDoc) -> dict[str, Any]:
    """Convert an ErrorDoc model instance to a serialisable dict."""
    return {
        "id": str(error.id),
        "code": error.code,
        "http_status": error.http_status,
        "message": error.message,
        "description": error.description,
        "possible_causes": error.possible_causes,
        "solutions": error.solutions,
        "related_errors": error.related_errors,
    }


def _endpoint_doc_to_dict(endpoint: EndpointDocumentation) -> dict[str, Any]:
    """Convert an EndpointDocumentation model instance to a serialisable dict."""
    return {
        "id": str(endpoint.id),
        "method": endpoint.method,
        "path": endpoint.path,
        "description": endpoint.description,
        "authentication": endpoint.authentication,
        "request_body": endpoint.request_body,
        "response_body": endpoint.response_body,
        "error_codes": endpoint.error_codes,
        "rate_limit": endpoint.rate_limit,
        "deprecated": endpoint.deprecated,
    }


def _category_to_dict(cat: DocumentationCategory) -> dict[str, Any]:
    """Convert a DocumentationCategory model instance to a serialisable dict."""
    return {
        "id": str(cat.id),
        "name": cat.name,
        "slug": cat.slug,
        "description": cat.description,
        "order_index": cat.order_index,
    }


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------


async def search(
    db: AsyncSession,
    *,
    query: str,
    context: str | None = None,
    limit: int = 10,
    include_examples: bool = False,
    language: str | None = None,
    embedding: list[float] | None = None,
) -> dict[str, Any]:
    """Hybrid documentation search (vector first, keyword fallback).

    When ``embedding`` is provided, vector similarity search is attempted
    first via pgvector cosine distance.  If no vector results are found
    (or if ``embedding`` is ``None``), falls back to keyword ILIKE search.

    Returns the standard search response shape:
    ``{ query, results, total, searchId }``
    """
    search_id = str(uuid4())

    try:
        results: list[dict[str, Any]] = []

        # Try vector search first when an embedding is provided
        if embedding is not None:
            try:
                vector_rows = await repo.search_docs_vector(
                    db,
                    embedding=embedding,
                    context=context,
                    limit=limit,
                )
                for doc, score in vector_rows:
                    doc_dict = _doc_to_dict(doc, score=score)

                    if include_examples:
                        examples = await repo.get_examples_by_doc_id(
                            db, doc.id, language=language
                        )
                        doc_dict["examples"] = [_example_to_dict(e) for e in examples]

                    results.append(doc_dict)
            except (OperationalError, ProgrammingError, TimeoutError):
                logger.warning(
                    "Vector search failed, falling back to keyword",
                    extra={"query": query},
                )
                results = []

        # Keyword fallback when no vector results
        if not results:
            docs = await repo.search_docs_keyword(
                db,
                query=query,
                context=context,
                limit=limit,
            )

            for doc in docs:
                doc_dict = _doc_to_dict(doc)

                if include_examples:
                    examples = await repo.get_examples_by_doc_id(
                        db, doc.id, language=language
                    )
                    doc_dict["examples"] = [_example_to_dict(e) for e in examples]

                results.append(doc_dict)

        return {
            "query": query,
            "results": results,
            "total": len(results),
            "searchId": search_id,
        }
    except Exception as exc:
        logger.exception("Documentation search failed", extra={"query": query})
        raise DocSearchError(f"Search failed: {exc}") from exc


# ---------------------------------------------------------------------------
# Endpoint documentation
# ---------------------------------------------------------------------------


async def get_endpoint_doc(
    db: AsyncSession,
    *,
    method: str,
    path: str,
) -> dict[str, Any]:
    """Get documentation for a specific API endpoint."""
    endpoint = await repo.get_endpoint_doc(db, method, path)

    if endpoint is None:
        raise EndpointNotFoundError(
            f"No documentation found for {method.upper()} {path}"
        )

    return {"endpoint": _endpoint_doc_to_dict(endpoint)}


# ---------------------------------------------------------------------------
# Error documentation
# ---------------------------------------------------------------------------


async def get_error_doc(
    db: AsyncSession,
    *,
    code: str,
    include_examples: bool = False,
    language: str | None = None,
) -> dict[str, Any]:
    """Get documentation for an error code."""
    error = await repo.get_error_doc(db, code)

    if error is None:
        raise ErrorDocNotFoundError(f"No documentation found for error code: {code}")

    result = _error_doc_to_dict(error)

    if include_examples:
        examples = await repo.get_examples_by_error_code(
            db, code, language=language
        )
        result["examples"] = [_example_to_dict(e) for e in examples]

    return {"error": result}


# ---------------------------------------------------------------------------
# Code examples
# ---------------------------------------------------------------------------


async def get_examples(
    db: AsyncSession,
    *,
    feature: str,
    language: str | None = None,
) -> dict[str, Any]:
    """Get code examples for a feature."""
    examples = await repo.get_examples_by_feature(
        db, feature, language=language
    )

    if not examples:
        raise ExamplesNotFoundError(
            f"No code examples found for feature: {feature}"
        )

    # Collect distinct languages
    languages = sorted({e.language for e in examples})

    return {
        "feature": feature,
        "examples": [_example_to_dict(e) for e in examples],
        "languages": languages,
    }


# ---------------------------------------------------------------------------
# Categories
# ---------------------------------------------------------------------------


async def get_categories(
    db: AsyncSession,
) -> dict[str, Any]:
    """List all documentation categories."""
    categories = await repo.list_categories(db)
    return {
        "categories": [_category_to_dict(c) for c in categories],
    }


# ---------------------------------------------------------------------------
# Feedback
# ---------------------------------------------------------------------------


async def submit_feedback(
    db: AsyncSession,
    *,
    document_id: str,
    helpful: bool,
    suggestion: str | None = None,
) -> dict[str, Any]:
    """Submit feedback for a documentation article."""
    await repo.create_feedback(
        db,
        document_id=document_id,
        helpful=helpful,
        suggestion=suggestion,
    )

    logger.info(
        "Documentation feedback submitted",
        extra={
            "document_id": document_id,
            "helpful": helpful,
        },
    )

    return {"message": "Feedback submitted successfully"}


# ---------------------------------------------------------------------------
# Indexing (admin / internal)
# ---------------------------------------------------------------------------


async def index_document(
    db: AsyncSession,
    *,
    slug: str,
    title: str,
    content: str,
    category: str | None = None,
    category_id: str | None = None,
    tags: list[str] | None = None,
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Index a new documentation article.

    Creates the documentation record. Embedding generation is a
    separate step (not implemented in this phase).
    """
    from uuid import UUID as _UUID

    doc = await repo.create_documentation(
        db,
        slug=slug,
        title=title,
        content=content,
        category=category,
        category_id=_UUID(category_id) if category_id else None,
        tags=tags,
        metadata_=metadata or {},
    )

    logger.info(
        "Documentation article indexed",
        extra={"id": str(doc.id), "slug": slug},
    )

    return {"document": _doc_to_dict(doc)}
