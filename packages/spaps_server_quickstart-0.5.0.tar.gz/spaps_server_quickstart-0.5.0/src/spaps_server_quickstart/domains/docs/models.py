"""SQLAlchemy models for the documentation domain."""

from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID, uuid4

from sqlalchemy import (
    Boolean,
    DateTime,
    ForeignKey,
    Integer,
    Text,
    func,
)
from sqlalchemy.dialects.postgresql import ARRAY, JSON
from sqlalchemy.orm import Mapped, mapped_column

from pgvector.sqlalchemy import Vector

from .._db import Base, PGUUID


class DocumentationCategory(Base):
    """Documentation category for grouping docs."""

    __tablename__ = "documentation_categories"

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    name: Mapped[str] = mapped_column(Text, nullable=False)
    slug: Mapped[str] = mapped_column(Text, nullable=False, unique=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    order_index: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    def __repr__(self) -> str:
        return f"<DocumentationCategory slug={self.slug!r}>"


class Documentation(Base):
    """Documentation article."""

    __tablename__ = "documentation"

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    slug: Mapped[str] = mapped_column(Text, nullable=False, unique=True)
    title: Mapped[str] = mapped_column(Text, nullable=False)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    category_id: Mapped[UUID | None] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("documentation_categories.id", ondelete="SET NULL"),
        nullable=True,
    )
    category: Mapped[str | None] = mapped_column(Text, nullable=True)
    tags: Mapped[list[str] | None] = mapped_column(
        ARRAY(Text), nullable=True
    )
    metadata_: Mapped[dict[str, Any] | None] = mapped_column(
        "metadata", JSON, nullable=True, default=dict
    )
    related_endpoints: Mapped[dict[str, Any] | None] = mapped_column(
        JSON, nullable=True
    )
    last_updated: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    is_published: Mapped[bool] = mapped_column(
        Boolean, server_default="true", default=True
    )

    def __repr__(self) -> str:
        return f"<Documentation slug={self.slug!r} title={self.title!r}>"


class DocEmbedding(Base):
    """Vector embedding for documentation chunks (pgvector)."""

    __tablename__ = "doc_embeddings"

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    doc_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("documentation.id", ondelete="CASCADE"),
        nullable=False,
    )
    embedding = mapped_column(Vector(1536), nullable=True)
    chunk_index: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    chunk_text: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    def __repr__(self) -> str:
        return f"<DocEmbedding doc_id={self.doc_id!r} chunk={self.chunk_index}>"


class ErrorDoc(Base):
    """Error code documentation.

    Maps to the ``error_documentation`` table in the schema.
    """

    __tablename__ = "error_documentation"

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    code: Mapped[str] = mapped_column(Text, nullable=False, unique=True)
    http_status: Mapped[int] = mapped_column(Integer, nullable=False)
    message: Mapped[str] = mapped_column(Text, nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    possible_causes: Mapped[list[str] | None] = mapped_column(
        ARRAY(Text), nullable=True
    )
    solutions: Mapped[list[str] | None] = mapped_column(
        ARRAY(Text), nullable=True
    )
    related_errors: Mapped[list[str] | None] = mapped_column(
        ARRAY(Text), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    def __repr__(self) -> str:
        return f"<ErrorDoc code={self.code!r}>"


class EndpointDocumentation(Base):
    """REST endpoint documentation."""

    __tablename__ = "endpoint_documentation"

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    method: Mapped[str] = mapped_column(Text, nullable=False)
    path: Mapped[str] = mapped_column(Text, nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    authentication: Mapped[dict[str, Any] | None] = mapped_column(
        JSON, nullable=True
    )
    request_body: Mapped[dict[str, Any] | None] = mapped_column(
        JSON, nullable=True
    )
    response_body: Mapped[dict[str, Any] | None] = mapped_column(
        JSON, nullable=True
    )
    error_codes: Mapped[dict[str, Any] | None] = mapped_column(
        JSON, nullable=True
    )
    rate_limit: Mapped[str | None] = mapped_column(Text, nullable=True)
    deprecated: Mapped[bool] = mapped_column(
        Boolean, server_default="false", default=False
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    def __repr__(self) -> str:
        return f"<EndpointDocumentation {self.method} {self.path}>"


class CodeExample(Base):
    """Code examples linked to docs, endpoints, or error codes."""

    __tablename__ = "code_examples"

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    title: Mapped[str] = mapped_column(Text, nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    language: Mapped[str] = mapped_column(Text, nullable=False)
    code: Mapped[str] = mapped_column(Text, nullable=False)
    dependencies: Mapped[dict[str, Any] | None] = mapped_column(
        JSON, nullable=True
    )
    output: Mapped[str | None] = mapped_column(Text, nullable=True)
    doc_id: Mapped[UUID | None] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("documentation.id", ondelete="SET NULL"),
        nullable=True,
    )
    endpoint: Mapped[str | None] = mapped_column(Text, nullable=True)
    error_code: Mapped[str | None] = mapped_column(Text, nullable=True)
    feature: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    def __repr__(self) -> str:
        return f"<CodeExample title={self.title!r} lang={self.language!r}>"


class DocFeedback(Base):
    """User feedback on documentation."""

    __tablename__ = "doc_feedback"

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    document_id: Mapped[str] = mapped_column(Text, nullable=False)
    helpful: Mapped[bool] = mapped_column(Boolean, nullable=False)
    suggestion: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    def __repr__(self) -> str:
        return f"<DocFeedback doc={self.document_id!r} helpful={self.helpful}>"
