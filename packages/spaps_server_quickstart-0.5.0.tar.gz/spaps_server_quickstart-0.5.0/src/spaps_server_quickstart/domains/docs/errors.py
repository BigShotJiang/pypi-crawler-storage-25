"""Domain errors for the documentation domain."""

from __future__ import annotations

from ..errors import DomainError


class DocSearchError(DomainError):
    """Raised when documentation search fails."""

    def __init__(self, message: str = "Documentation search failed") -> None:
        super().__init__("DOC_SEARCH_ERROR", message, status_code=500)


class EndpointNotFoundError(DomainError):
    """Raised when endpoint documentation is not found."""

    def __init__(self, message: str = "Endpoint documentation not found") -> None:
        super().__init__("ENDPOINT_NOT_FOUND", message, status_code=404)


class ExamplesNotFoundError(DomainError):
    """Raised when code examples are not found for a feature."""

    def __init__(self, message: str = "Code examples not found") -> None:
        super().__init__("EXAMPLES_NOT_FOUND", message, status_code=404)


class ErrorDocNotFoundError(DomainError):
    """Raised when error documentation is not found."""

    def __init__(self, message: str = "Error documentation not found") -> None:
        super().__init__("NOT_FOUND", message, status_code=404)
