"""Device Flow domain — OAuth 2.0 RFC 8628 device authorization for CLI tools."""
