"""Business logic for the device flow domain.

Coordinates the in-memory device flow store with application lookups.
This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import logging
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from . import repository as repo
from ..errors import UnknownClientError, ValidationError
from .store import DeviceFlowStore

logger = logging.getLogger(__name__)

# Module-level singleton store
_store = DeviceFlowStore()

DEVICE_CODE_GRANT_TYPE = "urn:ietf:params:oauth:grant-type:device_code"


async def generate_device_flow_tokens(
    db: AsyncSession,
    *,
    user_id: str,
    application_id: str,
    email: str | None = None,
) -> dict[str, Any]:
    """Generate token pair for a device flow authorization.

    Wraps the auth service's internal token generation. This is a
    separate function to allow easy mocking in tests.
    """
    from ..sessions.jwt_service import generate_token_pair as _gen_tokens
    from ...spaps_settings import get_spaps_settings

    settings = get_spaps_settings()

    token_pair = _gen_tokens(
        user_id=user_id,
        application_id=application_id,
        email=email,
        wallets=None,
        tier="basic",
        roles=["user"],
        permissions=["view_products"],
        is_admin=False,
        is_super_admin=False,
        access_secret=settings.jwt_secret,
        refresh_secret=settings.refresh_token_secret,
        access_expires_in=settings.jwt_expires_in,
        refresh_expires_in=settings.jwt_refresh_expires_in,
    )

    return {
        "access_token": token_pair.access_token,
        "refresh_token": token_pair.refresh_token,
    }


def get_store() -> DeviceFlowStore:
    """Get the module-level device flow store singleton."""
    return _store


def reset_store() -> None:
    """Reset the store (for testing)."""
    global _store
    _store = DeviceFlowStore()


# ---------------------------------------------------------------------------
# Application lookup
# ---------------------------------------------------------------------------


async def resolve_application_by_slug(
    db: AsyncSession,
    slug: str,
) -> Any:
    """Look up an application by its slug (client_id).

    Returns the Application model or raises UnknownClientError.
    """
    app = await repo.get_application_by_slug(db, slug)

    if app is None:
        raise UnknownClientError(
            f"client_id '{slug}' does not match any application"
        )

    return app


# ---------------------------------------------------------------------------
# Authorize (Step 1)
# ---------------------------------------------------------------------------


async def initiate_device_flow(
    db: AsyncSession,
    *,
    client_id: str,
    verification_uri: str,
) -> dict[str, Any]:
    """Initiate a device authorization flow.

    Validates client_id against application slugs, then creates a
    device flow entry with generated codes.
    """
    if not client_id:
        raise ValidationError("client_id is required")

    # Resolve application
    app = await resolve_application_by_slug(db, client_id)

    store = get_store()
    entry = store.create(client_id)
    entry.application_id = str(app.id)

    # Build verification URI with user code
    verification_uri_complete = f"{verification_uri}?user_code={entry.user_code}"

    logger.info(
        "Device flow initiated",
        extra={
            "client_id": client_id,
            "device_code": entry.device_code[:8] + "...",
            "user_code": entry.user_code,
        },
    )

    return {
        "device_code": entry.device_code,
        "user_code": entry.user_code,
        "verification_uri": verification_uri,
        "verification_uri_complete": verification_uri_complete,
        "auth_url": verification_uri_complete,
        "expires_in": 900,
        "interval": 5,
    }


# ---------------------------------------------------------------------------
# Verify (Step 2 — browser side)
# ---------------------------------------------------------------------------


async def verify_device(
    db: AsyncSession,
    *,
    device_code: str | None = None,
    user_code: str,
    action: str,
    user_id: str,
    user_email: str | None = None,
) -> dict[str, Any]:
    """Verify a device flow from the browser side.

    The authenticated user authorizes or denies the device request.
    On authorize, generates tokens for the CLI app's application.
    Accepts lookup by device_code or user_code (browser only has user_code).
    """
    store = get_store()

    if device_code:
        entry = store.get_by_device_code(device_code)
    else:
        entry = store.get_by_user_code(user_code)

    if not entry:
        raise ValidationError("Invalid or expired device code")

    if entry.status != "pending":
        raise ValidationError(f"Device flow is already {entry.status}")

    # Verify user_code matches
    if entry.user_code != user_code:
        raise ValidationError("User code does not match")

    # Resolve the actual device_code for downstream operations
    device_code = entry.device_code

    if action == "deny":
        store.deny(device_code)
        logger.info("Device flow denied", extra={"device_code": device_code[:8] + "..."})
        return {"message": "Device authorization denied"}

    if action == "authorize":
        # Look up the application for the CLI client
        app = await resolve_application_by_slug(db, entry.client_id)

        # Generate tokens for the CLI application via the auth service
        token_pair = await generate_device_flow_tokens(
            db,
            user_id=user_id,
            application_id=str(app.id),
            email=user_email,
        )

        store.authorize(
            device_code,
            access_token=token_pair["access_token"],
            refresh_token=token_pair["refresh_token"],
            user_id=user_id,
        )

        logger.info(
            "Device flow authorized",
            extra={
                "device_code": device_code[:8] + "...",
                "user_id": user_id,
                "client_id": entry.client_id,
            },
        )
        return {"message": "Device authorized"}

    raise ValidationError(f"Invalid action: {action}")


# ---------------------------------------------------------------------------
# Token (Step 3 — CLI polling)
# ---------------------------------------------------------------------------


async def poll_token(
    *,
    grant_type: str,
    device_code: str,
    client_id: str,
) -> dict[str, Any]:
    """Poll for device flow token.

    Returns tokens when authorized, or error codes per RFC 8628
    when pending/denied/expired.
    """
    if grant_type != DEVICE_CODE_GRANT_TYPE:
        return {
            "error": "unsupported_grant_type",
            "error_description": (
                f"Expected {DEVICE_CODE_GRANT_TYPE}, got {grant_type}"
            ),
        }

    store = get_store()
    entry = store.get_by_device_code(device_code)

    if not entry:
        # Entry not found — could be expired or never existed
        return {
            "error": "expired_token",
            "error_description": "Device code has expired or is invalid",
        }

    # Verify client_id matches
    if entry.client_id != client_id:
        return {
            "error": "expired_token",
            "error_description": "Device code does not match client_id",
        }

    if entry.status == "pending":
        return {
            "error": "authorization_pending",
            "error_description": "The user has not yet completed authorization",
        }

    if entry.status == "denied":
        # Consume (remove) the entry
        store.consume(device_code)
        return {
            "error": "access_denied",
            "error_description": "The user denied the authorization request",
        }

    if entry.status == "authorized":
        # Consume (remove) the entry and return tokens
        consumed = store.consume(device_code)
        if consumed and consumed.access_token and consumed.refresh_token:
            return {
                "access_token": consumed.access_token,
                "refresh_token": consumed.refresh_token,
                "token_type": "Bearer",
                "expires_in": 3600,
                "user_id": consumed.user_id,
            }
        # Fallback — should not happen
        return {
            "error": "expired_token",
            "error_description": "Token data is missing",
        }

    # Should not reach here
    return {
        "error": "expired_token",
        "error_description": "Unknown device flow state",
    }
