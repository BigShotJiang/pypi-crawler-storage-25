"""HTTP routes for the device flow domain (RFC 8628).

Provides ``device_flow_router`` under ``/cli/device`` with three endpoints:

1. POST /authorize — No auth. Returns device_code, user_code, etc.
2. POST /verify — JWT auth. User authorizes/denies from browser.
3. POST /token — No auth. CLI polls for tokens.

The /authorize and /token endpoints require NO authentication (public).
The /verify endpoint requires JWT authentication (browser session).
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse

from ...middleware.spaps_deps import CurrentUser, DbSession
from . import service
from .schemas import (
    AuthorizeRequest,
    AuthorizeResponse,
    TokenRequest,
    VerifyRequest,
    VerifyResponse,
)

logger = logging.getLogger(__name__)


device_flow_router = APIRouter(prefix="/cli/device", tags=["device-flow"])


@device_flow_router.post("/authorize", response_model=AuthorizeResponse)
async def authorize(
    body: AuthorizeRequest,
    db: DbSession,
    request: Request,
) -> AuthorizeResponse:
    """Initiate device authorization flow.

    No authentication required. Returns device_code and user_code
    for the CLI to display to the user.
    """
    from ..errors import ValidationError

    if not body.client_id:
        raise ValidationError("client_id is required")

    settings = request.app.state.settings
    verification_uri = getattr(settings, "device_flow_verification_uri", "") or ""

    result = await service.initiate_device_flow(
        db,
        client_id=body.client_id,
        verification_uri=verification_uri,
    )
    return AuthorizeResponse(**result)


@device_flow_router.post("/verify", response_model=VerifyResponse)
async def verify(
    body: VerifyRequest,
    db: DbSession,
    user: CurrentUser,
) -> VerifyResponse:
    """Verify device authorization from the browser.

    Requires JWT authentication. The authenticated user authorizes
    or denies the pending device request.
    """
    result = await service.verify_device(
        db,
        device_code=body.device_code,
        user_code=body.user_code,
        action=body.action,
        user_id=str(user.id),
        user_email=getattr(user, "email", None),
    )
    return VerifyResponse(**result)


@device_flow_router.post("/token")
async def token(
    body: TokenRequest,
) -> JSONResponse:
    """Poll for device flow token.

    No authentication required. CLI polls this endpoint with device_code.

    Returns:
    - 200 with tokens when authorized
    - 400 with error code when pending/denied/expired
    """
    result = await service.poll_token(
        grant_type=body.grant_type,
        device_code=body.device_code,
        client_id=body.client_id,
    )

    # If result contains an error, return 400 per RFC 8628
    if "error" in result:
        return JSONResponse(status_code=400, content=result)

    # Success — return tokens
    return JSONResponse(status_code=200, content=result)
