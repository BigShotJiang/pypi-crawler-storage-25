"""Data access for the device flow domain.

Pure SQLAlchemy async repository — no FastAPI imports.
All functions accept an ``AsyncSession`` as the first positional argument.
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from ..applications import repository as apps_repo
from ..applications.models import Application


async def get_application_by_slug(
    db: AsyncSession,
    slug: str,
) -> Application | None:
    """Look up an application by its slug.

    Delegates to the applications repository for consistency.

    Args:
        db: Active SQLAlchemy async session.
        slug: The application slug (client_id).

    Returns:
        The Application instance if found, otherwise None.
    """
    return await apps_repo.get_application_by_slug(db, slug)
