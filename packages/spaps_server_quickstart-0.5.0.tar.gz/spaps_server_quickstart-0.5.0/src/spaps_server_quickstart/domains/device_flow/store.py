"""In-memory device flow store with TTL-based expiration.

No database models -- device flow entries are purely in-memory.
Entries auto-expire after the configured TTL (default 15 minutes).

Thread-safe via dict operations (single-process assumption for SPAPS).
"""

from __future__ import annotations

import secrets
import string
import time
from dataclasses import dataclass, field
from typing import Literal


DEFAULT_TTL_SECONDS = 900  # 15 minutes
USER_CODE_LENGTH = 8  # 8 uppercase chars, formatted as "ABCD-EFGH"

DeviceFlowStatus = Literal["pending", "authorized", "denied", "expired"]


@dataclass
class DeviceFlowEntry:
    """A single device flow entry in the store."""

    device_code: str
    user_code: str
    client_id: str
    status: DeviceFlowStatus = "pending"
    created_at: float = field(default_factory=time.time)
    expires_at: float = 0.0
    # Set when authorized:
    access_token: str | None = None
    refresh_token: str | None = None
    user_id: str | None = None
    # Application resolved from client_id
    application_id: str | None = None

    def is_expired(self) -> bool:
        """Check if this entry has expired based on TTL."""
        return time.time() > self.expires_at


class DeviceFlowStore:
    """In-memory store for device flow entries.

    Primary index: device_code -> DeviceFlowEntry
    Secondary index: user_code -> device_code (for verification lookup)
    """

    def __init__(self, ttl_seconds: int = DEFAULT_TTL_SECONDS) -> None:
        self._ttl_seconds = ttl_seconds
        self._entries: dict[str, DeviceFlowEntry] = {}
        self._user_code_index: dict[str, str] = {}  # user_code -> device_code
        self._last_cleanup: float = 0.0
        self._cleanup_interval: float = 30.0  # seconds

    def _generate_device_code(self) -> str:
        """Generate an opaque device code."""
        return secrets.token_urlsafe(32)

    def _generate_user_code(self) -> str:
        """Generate an 8-char uppercase user code formatted as XXXX-XXXX."""
        chars = string.ascii_uppercase
        raw = "".join(secrets.choice(chars) for _ in range(USER_CODE_LENGTH))
        return f"{raw[:4]}-{raw[4:]}"

    def _cleanup_expired(self) -> None:
        """Remove expired entries (lazy cleanup on access).

        Throttled to run at most once per ``_cleanup_interval`` seconds
        to avoid O(n) scans on every access.
        """
        now = time.time()
        if (now - self._last_cleanup) < self._cleanup_interval:
            return
        self._last_cleanup = now
        expired_codes = [
            code for code, entry in self._entries.items()
            if now > entry.expires_at
        ]
        for code in expired_codes:
            entry = self._entries.pop(code, None)
            if entry:
                self._user_code_index.pop(entry.user_code, None)

    def create(self, client_id: str) -> DeviceFlowEntry:
        """Create a new device flow entry.

        Returns the new entry with generated device_code and user_code.
        """
        self._cleanup_expired()

        device_code = self._generate_device_code()
        user_code = self._generate_user_code()

        # Ensure uniqueness of user_code
        while user_code in self._user_code_index:
            user_code = self._generate_user_code()

        now = time.time()
        entry = DeviceFlowEntry(
            device_code=device_code,
            user_code=user_code,
            client_id=client_id,
            created_at=now,
            expires_at=now + self._ttl_seconds,
        )

        self._entries[device_code] = entry
        self._user_code_index[user_code] = device_code

        return entry

    def get_by_device_code(self, device_code: str) -> DeviceFlowEntry | None:
        """Look up an entry by device code.

        Returns None if not found or expired.
        """
        self._cleanup_expired()
        entry = self._entries.get(device_code)
        if entry and entry.is_expired():
            self._remove(entry)
            return None
        return entry

    def get_by_user_code(self, user_code: str) -> DeviceFlowEntry | None:
        """Look up an entry by user code (secondary index).

        Returns None if not found or expired.
        """
        self._cleanup_expired()
        device_code = self._user_code_index.get(user_code)
        if not device_code:
            return None
        return self.get_by_device_code(device_code)

    def authorize(
        self,
        device_code: str,
        *,
        access_token: str,
        refresh_token: str,
        user_id: str,
    ) -> DeviceFlowEntry | None:
        """Transition an entry to authorized status with tokens.

        Returns the updated entry or None if not found/expired.
        """
        entry = self.get_by_device_code(device_code)
        if not entry or entry.status != "pending":
            return None

        entry.status = "authorized"
        entry.access_token = access_token
        entry.refresh_token = refresh_token
        entry.user_id = user_id
        return entry

    def deny(self, device_code: str) -> DeviceFlowEntry | None:
        """Transition an entry to denied status.

        Returns the updated entry or None if not found/expired.
        """
        entry = self.get_by_device_code(device_code)
        if not entry or entry.status != "pending":
            return None

        entry.status = "denied"
        return entry

    def consume(self, device_code: str) -> DeviceFlowEntry | None:
        """Consume an authorized entry (remove from store after token delivery).

        Returns the entry if it was authorized, None otherwise.
        """
        entry = self.get_by_device_code(device_code)
        if not entry:
            return None

        if entry.status in ("authorized", "denied"):
            self._remove(entry)
            return entry

        return entry  # Return pending entries without consuming

    def _remove(self, entry: DeviceFlowEntry) -> None:
        """Remove an entry from both indexes."""
        self._entries.pop(entry.device_code, None)
        self._user_code_index.pop(entry.user_code, None)

    @property
    def size(self) -> int:
        """Number of active (non-expired) entries."""
        self._cleanup_expired()
        return len(self._entries)
