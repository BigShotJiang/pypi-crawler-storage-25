"""Pydantic request/response schemas for device flow endpoints.

These schemas define the *data* portion of each API response.
The standard response envelope ``{ success, data, error, metadata }``
is applied by middleware -- domain schemas never reference it.

Zero FastAPI imports.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel


# ---------------------------------------------------------------------------
# Request schemas
# ---------------------------------------------------------------------------


class AuthorizeRequest(BaseModel):
    """POST /cli/device/authorize body."""

    client_id: str


class VerifyRequest(BaseModel):
    """POST /cli/device/verify body."""

    device_code: str | None = None
    user_code: str
    action: Literal["authorize", "deny"]


class TokenRequest(BaseModel):
    """POST /cli/device/token body."""

    grant_type: str
    device_code: str
    client_id: str


# ---------------------------------------------------------------------------
# Response schemas
# ---------------------------------------------------------------------------


class AuthorizeResponse(BaseModel):
    """POST /cli/device/authorize -- success payload."""

    device_code: str
    user_code: str
    verification_uri: str
    verification_uri_complete: str
    auth_url: str
    expires_in: int = 900
    interval: int = 5


class VerifyResponse(BaseModel):
    """POST /cli/device/verify -- success payload."""

    message: str


class TokenResponse(BaseModel):
    """POST /cli/device/token -- success payload (authorized)."""

    access_token: str
    refresh_token: str
    token_type: str = "Bearer"
    expires_in: int = 3600
    user_id: str | None = None


class TokenErrorResponse(BaseModel):
    """POST /cli/device/token -- error payload (pending/denied/expired)."""

    error: str
    error_description: str | None = None
