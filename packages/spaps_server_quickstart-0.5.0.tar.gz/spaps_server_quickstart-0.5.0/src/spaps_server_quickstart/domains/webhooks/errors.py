"""Domain errors for the webhooks domain."""

from __future__ import annotations

from ..errors import DomainError


class WebhookNotFoundError(DomainError):
    """Raised when a webhook is not found."""

    def __init__(self, message: str = "Webhook not found") -> None:
        super().__init__("NOT_FOUND", message, status_code=404)


class WebhookDeliveryError(DomainError):
    """Raised when a webhook delivery permanently fails."""

    def __init__(self, message: str = "Webhook delivery failed") -> None:
        super().__init__("WEBHOOK_DELIVERY_FAILED", message, status_code=500)


class InvalidWebhookSignatureError(DomainError):
    """Raised when a webhook signature verification fails."""

    def __init__(self, message: str = "Invalid webhook signature") -> None:
        super().__init__("INVALID_SIGNATURE", message, status_code=401)


class SignatureExpiredError(DomainError):
    """Raised when a webhook signature timestamp is too old."""

    def __init__(self, message: str = "Webhook signature timestamp too old") -> None:
        super().__init__("SIGNATURE_EXPIRED", message, status_code=401)


class InvalidWebhookUrlError(DomainError):
    """Raised when a webhook URL is invalid."""

    def __init__(self, message: str = "Invalid webhook URL") -> None:
        super().__init__("VALIDATION_ERROR", message, status_code=400)


class InvalidEventTypeError(DomainError):
    """Raised when an invalid event type is specified."""

    def __init__(self, message: str = "Invalid event type") -> None:
        super().__init__("VALIDATION_ERROR", message, status_code=400)


class WebhookNotConfiguredError(DomainError):
    """Raised when a required webhook configuration is missing."""

    def __init__(self, message: str = "Webhook is not configured") -> None:
        super().__init__("WEBHOOK_NOT_CONFIGURED", message, status_code=500)


class WebhookDestinationNotAllowedError(DomainError):
    """TM-007: Raised when destination fails governance policy check."""

    def __init__(self, message: str = "Webhook destination not allowed by policy") -> None:
        super().__init__("WEBHOOK_DESTINATION_NOT_ALLOWED", message, status_code=403)


class WebhookDestinationUnverifiedError(DomainError):
    """TM-007: Raised when destination cannot be verified (future: for verify mode)."""

    def __init__(self, message: str = "Webhook destination could not be verified") -> None:
        super().__init__("WEBHOOK_DESTINATION_UNVERIFIED", message, status_code=403)
