"""Database operations for the webhooks domain.

Pure SQLAlchemy async repository -- no FastAPI imports.
All functions accept an ``AsyncSession`` as the first positional argument.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .models import Webhook, WebhookDelivery, WebhookEvent

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Webhook lookups
# ---------------------------------------------------------------------------


async def get_webhook_by_id(
    db: AsyncSession,
    webhook_id: UUID,
    application_id: UUID,
) -> Webhook | None:
    """Fetch a single webhook by ID scoped to an application."""
    stmt = select(Webhook).where(
        Webhook.id == webhook_id,
        Webhook.application_id == application_id,
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def list_webhooks(
    db: AsyncSession,
    application_id: UUID,
) -> list[Webhook]:
    """List all webhooks for an application."""
    stmt = (
        select(Webhook)
        .where(Webhook.application_id == application_id)
        .order_by(Webhook.created_at.desc())
    )
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def find_active_webhooks_for_event(
    db: AsyncSession,
    application_id: UUID,
    event_type: str,
) -> list[Webhook]:
    """Find all active webhooks subscribed to a specific event type.

    Uses PostgreSQL array contains operator to check if the event_type
    is in the webhook's events array.
    """
    stmt = (
        select(Webhook)
        .where(
            Webhook.application_id == application_id,
            Webhook.is_active.is_(True),
            Webhook.events.any(event_type),  # type: ignore[arg-type]
        )
    )
    result = await db.execute(stmt)
    return list(result.scalars().all())


# ---------------------------------------------------------------------------
# Webhook mutations
# ---------------------------------------------------------------------------


async def create_webhook(
    db: AsyncSession,
    **kwargs: Any,
) -> Webhook:
    """Insert a new webhook and return the persisted instance."""
    webhook = Webhook(**kwargs)
    db.add(webhook)
    await db.flush()
    await db.refresh(webhook)
    return webhook


async def update_webhook(
    db: AsyncSession,
    webhook_id: UUID,
    application_id: UUID,
    **kwargs: Any,
) -> Webhook | None:
    """Update a webhook by ID scoped to an application."""
    webhook = await get_webhook_by_id(db, webhook_id, application_id)
    if webhook is None:
        return None

    for key, value in kwargs.items():
        if hasattr(webhook, key):
            setattr(webhook, key, value)

    webhook.updated_at = datetime.now(UTC)
    await db.flush()
    await db.refresh(webhook)
    return webhook


async def delete_webhook(
    db: AsyncSession,
    webhook_id: UUID,
    application_id: UUID,
) -> bool:
    """Delete a webhook by ID scoped to an application.

    Returns True if the webhook was found and deleted, False otherwise.
    """
    webhook = await get_webhook_by_id(db, webhook_id, application_id)
    if webhook is None:
        return False

    await db.delete(webhook)
    await db.flush()
    return True


# ---------------------------------------------------------------------------
# Webhook events
# ---------------------------------------------------------------------------


async def create_webhook_event(
    db: AsyncSession,
    **kwargs: Any,
) -> WebhookEvent:
    """Insert a new webhook event."""
    event = WebhookEvent(**kwargs)
    db.add(event)
    await db.flush()
    await db.refresh(event)
    return event


# ---------------------------------------------------------------------------
# Webhook deliveries
# ---------------------------------------------------------------------------


async def create_delivery(
    db: AsyncSession,
    **kwargs: Any,
) -> WebhookDelivery:
    """Insert a new webhook delivery record."""
    delivery = WebhookDelivery(**kwargs)
    db.add(delivery)
    await db.flush()
    await db.refresh(delivery)
    return delivery


async def update_delivery(
    db: AsyncSession,
    delivery_id: UUID,
    **kwargs: Any,
) -> WebhookDelivery | None:
    """Update a delivery record."""
    stmt = select(WebhookDelivery).where(WebhookDelivery.id == delivery_id)
    result = await db.execute(stmt)
    delivery = result.scalar_one_or_none()
    if delivery is None:
        return None

    for key, value in kwargs.items():
        if hasattr(delivery, key):
            setattr(delivery, key, value)

    await db.flush()
    await db.refresh(delivery)
    return delivery


async def list_deliveries(
    db: AsyncSession,
    webhook_id: UUID,
    *,
    limit: int = 100,
) -> list[WebhookDelivery]:
    """List deliveries for a webhook, ordered by most recent first."""
    stmt = (
        select(WebhookDelivery)
        .where(WebhookDelivery.webhook_id == webhook_id)
        .order_by(WebhookDelivery.delivered_at.desc().nulls_last())
        .limit(limit)
    )
    result = await db.execute(stmt)
    return list(result.scalars().all())
