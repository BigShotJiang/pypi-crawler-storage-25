"""Business logic for the webhooks domain.

Coordinates repository calls and raises domain errors.
This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import asyncio
import logging
import secrets
import socket
from datetime import datetime
from typing import Any
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from . import repository as repo
from .destination_security import (
    find_forbidden_ip,
    is_non_production_environment,
    parse_destination_url,
    resolve_destination_ips,
)
from .delivery import deliver_webhook
from .errors import (
    InvalidEventTypeError,
    InvalidWebhookUrlError,
    WebhookDestinationNotAllowedError,
    WebhookNotFoundError,
)
from .models import Webhook, WebhookDelivery, WebhookEvent
from .schemas import VALID_EVENT_TYPE_KEYS, WEBHOOK_EVENT_TYPES

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _webhook_to_dict(webhook: Webhook) -> dict[str, Any]:
    """Convert a Webhook model instance to a serialisable dict."""
    return {
        "id": str(webhook.id),
        "application_id": str(webhook.application_id),
        "url": webhook.url,
        "secret": webhook.secret,
        "events": webhook.events or [],
        "is_active": webhook.is_active,
        "headers": webhook.headers,
        "retry_config": webhook.retry_config,
        "created_at": webhook.created_at.isoformat() if webhook.created_at else None,
        "updated_at": webhook.updated_at.isoformat() if webhook.updated_at else None,
    }


def _delivery_to_dict(delivery: WebhookDelivery) -> dict[str, Any]:
    """Convert a WebhookDelivery model instance to a serialisable dict."""
    return {
        "id": str(delivery.id),
        "webhook_id": str(delivery.webhook_id),
        "event_type": delivery.event_type,
        "payload": delivery.payload or {},
        "response_status": delivery.response_status,
        "response_body": delivery.response_body,
        "delivered_at": delivery.delivered_at.isoformat() if delivery.delivered_at else None,
        "retry_count": delivery.retry_count,
        "attempt": delivery.attempt,
        "error_message": delivery.error_message,
    }


def _validate_url(url: str, *, environment: str = "production") -> None:
    """Validate webhook URL: scheme, host, and block private/internal IPs.

    TM-007: Prevents SSRF by resolving DNS and rejecting RFC1918,
    loopback, link-local, and cloud metadata destinations.
    """
    parsed = parse_destination_url(url)
    if not parsed.scheme:
        raise InvalidWebhookUrlError("Webhook URL must include a URL scheme")

    # Policy: only allow http:// in non-production (local/dev/test).
    # In production-like envs, require HTTPS to avoid plaintext delivery of
    # auth/payment/PII-adjacent event data.
    if is_non_production_environment(environment):
        if parsed.scheme not in ("https", "http"):
            raise InvalidWebhookUrlError("Webhook URL must use http:// or https:// scheme")
    else:
        if parsed.scheme != "https":
            raise InvalidWebhookUrlError("Webhook URL must use https:// in production")

    hostname = parsed.hostname
    if not hostname:
        raise InvalidWebhookUrlError("Webhook URL must have a valid hostname")

    # Resolve DNS and check all returned addresses
    try:
        ips = resolve_destination_ips(hostname, parsed.port or 443)
    except socket.gaierror:
        raise InvalidWebhookUrlError(f"Cannot resolve hostname: {hostname}")

    forbidden_ip = find_forbidden_ip(ips)
    if forbidden_ip is not None:
        raise InvalidWebhookUrlError(
            "Webhook URL must not resolve to a private, loopback, or reserved IP address"
        )


def _check_destination_governance(
    url: str,
    *,
    policy_mode: str = "off",
    allowed_domains: tuple[str, ...] = (),
) -> None:
    """TM-007: Enforce webhook destination governance policy.

    Modes:
    - off: No governance (existing behavior)
    - allowlist: Only domains in allowed_domains are permitted
    """
    if policy_mode == "off":
        return

    from urllib.parse import urlparse

    parsed = urlparse(url)
    hostname = parsed.hostname or ""

    if policy_mode == "allowlist":
        if not allowed_domains:
            # No domains configured means nothing is allowed
            logger.warning(
                "TM-007: Webhook destination denied — allowlist mode with empty allowlist",
                extra={
                    "event": "webhook_destination_denied",
                    "threat_id": "TM-007",
                    "destination": hostname,
                    "policy_mode": policy_mode,
                    "reason": "empty_allowlist",
                },
            )
            raise WebhookDestinationNotAllowedError(
                f"Webhook destination '{hostname}' not in allowed domains"
            )

        # Check if hostname matches any allowed domain (including subdomains)
        domain_allowed = any(
            hostname == d or hostname.endswith(f".{d}")
            for d in allowed_domains
        )
        if not domain_allowed:
            logger.warning(
                "TM-007: Webhook destination denied by allowlist policy",
                extra={
                    "event": "webhook_destination_denied",
                    "threat_id": "TM-007",
                    "destination": hostname,
                    "policy_mode": policy_mode,
                    "allowed_domains": list(allowed_domains),
                    "reason": "not_in_allowlist",
                },
            )
            raise WebhookDestinationNotAllowedError(
                f"Webhook destination '{hostname}' not in allowed domains"
            )


def _validate_event_types(events: list[str]) -> None:
    """Validate that all event types are recognized."""
    invalid = set(events) - VALID_EVENT_TYPE_KEYS
    if invalid:
        raise InvalidEventTypeError(
            f"Invalid event types: {', '.join(sorted(invalid))}"
        )


# ---------------------------------------------------------------------------
# Webhook management -- public API
# ---------------------------------------------------------------------------


async def list_webhooks(
    db: AsyncSession,
    *,
    application_id: UUID,
) -> dict[str, Any]:
    """List all webhooks for an application."""
    webhooks = await repo.list_webhooks(db, application_id)
    return {
        "webhooks": [_webhook_to_dict(w) for w in webhooks],
        "total": len(webhooks),
    }


async def create_webhook(
    db: AsyncSession,
    *,
    application_id: UUID,
    url: str,
    events: list[str],
    headers: dict[str, Any] | None = None,
    environment: str = "production",
    policy_mode: str = "off",
    allowed_domains: tuple[str, ...] = (),
) -> dict[str, Any]:
    """Register a new webhook.

    Auto-generates a secret using secrets.token_hex(32).
    Validates URL scheme, event types, and destination governance (TM-007).
    """
    _validate_url(url, environment=environment)
    _check_destination_governance(url, policy_mode=policy_mode, allowed_domains=allowed_domains)
    _validate_event_types(events)

    secret = secrets.token_hex(32)

    webhook = await repo.create_webhook(
        db,
        application_id=application_id,
        url=url,
        secret=secret,
        events=events,
        is_active=True,
        headers=headers or {},
        retry_config={
            "max_attempts": 3,
            "initial_delay_ms": 1000,
            "max_delay_ms": 10000,
        },
    )

    logger.info(
        "Webhook created",
        extra={
            "id": str(webhook.id),
            "url": url,
            "events": events,
        },
    )

    return {
        "webhook": _webhook_to_dict(webhook),
        "message": "Webhook registered successfully",
    }


async def update_webhook(
    db: AsyncSession,
    *,
    webhook_id: UUID,
    application_id: UUID,
    url: str | None = None,
    events: list[str] | None = None,
    is_active: bool | None = None,
    headers: dict[str, Any] | None = None,
    environment: str = "production",
    policy_mode: str = "off",
    allowed_domains: tuple[str, ...] = (),
) -> dict[str, Any]:
    """Update an existing webhook."""
    if url is not None:
        _validate_url(url, environment=environment)
        _check_destination_governance(url, policy_mode=policy_mode, allowed_domains=allowed_domains)
    if events is not None:
        _validate_event_types(events)

    kwargs: dict[str, Any] = {}
    if url is not None:
        kwargs["url"] = url
    if events is not None:
        kwargs["events"] = events
    if is_active is not None:
        kwargs["is_active"] = is_active
    if headers is not None:
        kwargs["headers"] = headers

    webhook = await repo.update_webhook(
        db, webhook_id, application_id, **kwargs
    )

    if webhook is None:
        raise WebhookNotFoundError()

    logger.info("Webhook updated", extra={"id": str(webhook_id)})

    return {"webhook": _webhook_to_dict(webhook)}


async def delete_webhook(
    db: AsyncSession,
    *,
    webhook_id: UUID,
    application_id: UUID,
) -> dict[str, Any]:
    """Delete a webhook."""
    deleted = await repo.delete_webhook(db, webhook_id, application_id)
    if not deleted:
        raise WebhookNotFoundError()

    logger.info("Webhook deleted", extra={"id": str(webhook_id)})

    return {
        "message": "Webhook deleted successfully",
        "webhook_id": str(webhook_id),
    }


async def list_deliveries(
    db: AsyncSession,
    *,
    webhook_id: UUID,
    application_id: UUID,
    limit: int = 100,
) -> dict[str, Any]:
    """List deliveries for a webhook."""
    # Verify webhook exists and belongs to application
    webhook = await repo.get_webhook_by_id(db, webhook_id, application_id)
    if webhook is None:
        raise WebhookNotFoundError()

    deliveries = await repo.list_deliveries(db, webhook_id, limit=limit)
    return {
        "deliveries": [_delivery_to_dict(d) for d in deliveries],
        "total": len(deliveries),
    }


async def list_event_types() -> dict[str, Any]:
    """List all supported webhook event types."""
    return {
        "events": WEBHOOK_EVENT_TYPES,
        "total": len(WEBHOOK_EVENT_TYPES),
    }


# ---------------------------------------------------------------------------
# Event triggering and delivery -- internal API
# ---------------------------------------------------------------------------


async def trigger_event(
    db: AsyncSession,
    *,
    event_type: str,
    application_id: UUID,
    data: dict[str, Any],
    user_id: UUID | None = None,
    session_factory: async_sessionmaker[AsyncSession] | None = None,
    environment: str = "production",
) -> WebhookEvent | None:
    """Trigger a webhook event.

    Creates the event record, finds matching webhooks, and fires
    async delivery tasks for each.

    This is the main entry point for other domains to trigger webhooks.
    Returns the created event, or None if the event type is not valid.

    Args:
        session_factory: Optional session factory for persisting delivery
            records in the background task.  When ``None``, delivery
            records are only logged (not persisted).
    """
    if event_type not in VALID_EVENT_TYPE_KEYS:
        logger.warning(
            "Ignoring unknown event type",
            extra={"event_type": event_type},
        )
        return None

    # Create event record
    event = await repo.create_webhook_event(
        db,
        type=event_type,
        application_id=application_id,
        user_id=user_id,
        data=data,
        schema_version=1,
    )

    logger.info(
        "Webhook event created",
        extra={
            "event_id": str(event.id),
            "event_type": event_type,
            "application_id": str(application_id),
        },
    )

    # Find matching active webhooks
    webhooks = await repo.find_active_webhooks_for_event(
        db, application_id, event_type
    )

    if not webhooks:
        logger.debug(
            "No active webhooks for event",
            extra={"event_type": event_type},
        )
        return event

    # Fire async delivery for each webhook
    for webhook in webhooks:
        retry_config = webhook.retry_config or {}
        max_attempts = retry_config.get("max_attempts", 3)
        initial_delay_ms = retry_config.get("initial_delay_ms", 1000)
        max_delay_ms = retry_config.get("max_delay_ms", 10000)

        asyncio.create_task(
            _deliver_and_record(
                session_factory=session_factory,
                db_event_id=event.id,
                webhook_id=webhook.id,
                webhook_url=webhook.url,
                webhook_secret=webhook.secret,
                event_id=str(event.id),
                event_type=event_type,
                schema_version=event.schema_version,
                application_id=str(application_id),
                created_at=event.created_at.isoformat(),
                data=data,
                custom_headers=webhook.headers or {},
                max_attempts=max_attempts,
                initial_delay_ms=initial_delay_ms,
                max_delay_ms=max_delay_ms,
                environment=environment,
            )
        )

    return event


async def _deliver_and_record(
    *,
    session_factory: async_sessionmaker[AsyncSession] | None,
    db_event_id: UUID,
    webhook_id: UUID,
    webhook_url: str,
    webhook_secret: str,
    event_id: str,
    event_type: str,
    schema_version: int,
    application_id: str,
    created_at: str,
    data: dict[str, Any],
    custom_headers: dict[str, str],
    max_attempts: int,
    initial_delay_ms: int,
    max_delay_ms: int,
    environment: str = "production",
) -> None:
    """Deliver a webhook and record the result.

    This is the fire-and-forget task spawned by trigger_event.
    Uses its own DB session via ``session_factory`` so it is fully
    decoupled from the original request lifecycle.
    """
    try:
        attempts = await deliver_webhook(
            webhook_url=webhook_url,
            webhook_secret=webhook_secret,
            event_id=event_id,
            event_type=event_type,
            schema_version=schema_version,
            application_id=application_id,
            created_at=created_at,
            data=data,
            custom_headers=custom_headers,
            max_attempts=max_attempts,
            initial_delay_ms=initial_delay_ms,
            max_delay_ms=max_delay_ms,
            environment=environment,
        )

        # Log final result
        final = attempts[-1] if attempts else None
        if final:
            logger.info(
                "Webhook delivery completed",
                extra={
                    "webhook_id": str(webhook_id),
                    "event_type": event_type,
                    "total_attempts": len(attempts),
                    "final_status": final.get("response_status"),
                    "final_error": final.get("error_message"),
                },
            )

        # Persist delivery records if a session factory is available
        if session_factory is not None:
            await _persist_delivery_records(
                session_factory=session_factory,
                webhook_id=webhook_id,
                event_type=event_type,
                data=data,
                attempts=attempts,
            )

    except Exception:
        logger.exception(
            "Webhook delivery task failed",
            extra={
                "webhook_id": str(webhook_id),
                "event_type": event_type,
            },
        )


async def _persist_delivery_records(
    *,
    session_factory: async_sessionmaker[AsyncSession],
    webhook_id: UUID,
    event_type: str,
    data: dict[str, Any],
    attempts: list[dict[str, Any]],
) -> None:
    """Persist webhook delivery attempt records to the database.

    Best-effort: logs on failure rather than raising.
    """
    try:
        async with session_factory() as db:
            for attempt in attempts:
                delivered_at = None
                if attempt.get("delivered_at"):
                    delivered_at = datetime.fromisoformat(attempt["delivered_at"])

                await repo.create_delivery(
                    db,
                    webhook_id=webhook_id,
                    event_type=event_type,
                    payload=data,
                    response_status=attempt.get("response_status"),
                    response_body=attempt.get("response_body"),
                    delivered_at=delivered_at,
                    retry_count=max(0, attempt.get("attempt", 1) - 1),
                    attempt=attempt.get("attempt", 1),
                    error_message=attempt.get("error_message"),
                )
            await db.commit()
    except Exception:
        logger.exception(
            "Failed to persist webhook delivery records",
            extra={
                "webhook_id": str(webhook_id),
                "event_type": event_type,
            },
        )


# ---------------------------------------------------------------------------
# Mailgun webhook processing -- internal API
# ---------------------------------------------------------------------------


async def process_mailgun_event(
    db: AsyncSession,
    *,
    body: dict[str, Any],
    mailgun_webhook_signing_key: str,
) -> dict[str, Any]:
    """Process a Mailgun webhook event.

    Verifies the signature, extracts event data, maps to email log status,
    and updates the email_log table.

    Args:
        db: Database session.
        body: Mailgun webhook payload (already parsed as dict).
        mailgun_webhook_signing_key: Mailgun signing key from settings.

    Returns:
        Dict with success status and event details.

    Raises:
        WebhookNotConfiguredError: If signing key is missing.
        InvalidWebhookSignatureError: If signature verification fails.
    """
    from datetime import UTC

    from .errors import InvalidWebhookSignatureError, WebhookNotConfiguredError
    from .signing import verify_mailgun_signature

    # Verify signing key is configured
    if not mailgun_webhook_signing_key:
        logger.warning("MAILGUN_WEBHOOK_SIGNING_KEY not configured; rejecting Mailgun webhook")
        raise WebhookNotConfiguredError("Mailgun webhook signing key is not configured")

    # Extract signature data from Mailgun payload
    signature_data = body.get("signature", {})
    mg_timestamp = signature_data.get("timestamp", "")
    mg_token = signature_data.get("token", "")
    mg_signature = signature_data.get("signature", "")

    # Verify Mailgun signature
    if not verify_mailgun_signature(
        signing_key=mailgun_webhook_signing_key,
        timestamp=mg_timestamp,
        token=mg_token,
        signature=mg_signature,
    ):
        raise InvalidWebhookSignatureError("Invalid Mailgun webhook signature")

    # Extract event data
    event_data = body.get("event-data", {})
    event_type = event_data.get("event", "unknown")
    message_headers = event_data.get("message", {}).get("headers", {})
    message_id = message_headers.get("message-id", "")

    # Map Mailgun event to email_log status
    status_mapping: dict[str, str] = {
        "delivered": "delivered",
        "opened": "opened",
        "clicked": "clicked",
        "complained": "complained",
        "failed": "failed",
        "bounced": "bounced",
    }

    mapped_status = status_mapping.get(event_type, event_type)

    logger.info(
        "Mailgun webhook event received",
        extra={
            "event": event_type,
            "message_id": message_id,
            "status": mapped_status,
        },
    )

    # Update email_log with delivery status timestamps (best-effort)
    updated = False
    if message_id:
        try:
            from sqlalchemy.exc import SQLAlchemyError

            from ..email import repository as email_repo

            log_entry = await email_repo.get_log_by_mailgun_message_id(db, message_id)
            if log_entry is not None:
                now = datetime.now(UTC)
                update_kwargs: dict[str, Any] = {"status": mapped_status}

                # Set the appropriate timestamp based on event type
                if event_type == "delivered" and log_entry.delivered_at is None:
                    update_kwargs["delivered_at"] = now
                elif event_type == "opened" and log_entry.opened_at is None:
                    update_kwargs["opened_at"] = now
                elif event_type == "clicked" and log_entry.clicked_at is None:
                    update_kwargs["clicked_at"] = now

                await email_repo.update_email_log(db, log_entry.id, **update_kwargs)
                updated = True
        except SQLAlchemyError:
            logger.exception(
                "Failed to update email_log from Mailgun event",
                extra={"message_id": message_id, "event": event_type},
            )

    return {
        "message": "Event processed",
        "event": event_type,
        "status": mapped_status,
        "email_log_updated": updated,
    }
