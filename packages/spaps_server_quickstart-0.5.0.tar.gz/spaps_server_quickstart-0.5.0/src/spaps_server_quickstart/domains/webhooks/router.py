"""HTTP routes for the webhooks domain.

Provides TWO routers:

1. ``webhooks_router`` -- webhook management under ``/webhooks``
2. ``webhooks_internal_router`` -- Mailgun event handler under ``/webhooks/mailgun``

Webhook management endpoints use API Key auth (Application dependency).
The Mailgun handler uses HMAC signature verification.
"""

from __future__ import annotations

import logging
from typing import Any
from uuid import UUID

from fastapi import APIRouter, Query, Request

from ...middleware.spaps_deps import Application, DbSession
from . import service
from .schemas import (
    CreateWebhookRequest,
    CreateWebhookResponse,
    DeleteWebhookResponse,
    ListDeliveriesResponse,
    ListEventTypesResponse,
    ListWebhooksResponse,
    UpdateWebhookRequest,
    UpdateWebhookResponse,
)

logger = logging.getLogger(__name__)


# ===========================================================================
# Webhooks Management Router
# ===========================================================================

webhooks_router = APIRouter(prefix="/webhooks", tags=["webhooks"])


@webhooks_router.get("", response_model=ListWebhooksResponse)
async def list_webhooks(
    db: DbSession,
    app: Application,
) -> ListWebhooksResponse:
    """List all registered webhooks for the application.

    Requires API key authentication.
    """
    result = await service.list_webhooks(db, application_id=app.id)
    return ListWebhooksResponse(**result)


@webhooks_router.post("", response_model=CreateWebhookResponse, status_code=201)
async def create_webhook(
    body: CreateWebhookRequest,
    request: Request,
    db: DbSession,
    app: Application,
) -> CreateWebhookResponse:
    """Register a new webhook.

    Auto-generates a secret for HMAC-SHA256 signing.
    Requires API key authentication.

    TM-007: Destination governance policy is enforced based on settings.
    """
    settings = request.app.state.settings
    result = await service.create_webhook(
        db,
        application_id=app.id,
        url=body.url,
        events=body.events,
        headers=body.headers,
        environment=getattr(settings, "env", "production"),
        policy_mode=getattr(settings, "webhook_destination_policy_mode", "off"),
        allowed_domains=tuple(getattr(settings, "webhook_allowed_domains", [])),
    )
    return CreateWebhookResponse(**result)


@webhooks_router.put("/{webhook_id}", response_model=UpdateWebhookResponse)
async def update_webhook(
    webhook_id: str,
    body: UpdateWebhookRequest,
    request: Request,
    db: DbSession,
    app: Application,
) -> UpdateWebhookResponse:
    """Update an existing webhook.

    Requires API key authentication.

    TM-007: Destination governance policy is enforced based on settings.
    """
    settings = request.app.state.settings
    result = await service.update_webhook(
        db,
        webhook_id=UUID(webhook_id),
        application_id=app.id,
        url=body.url,
        events=body.events,
        is_active=body.is_active,
        headers=body.headers,
        environment=getattr(settings, "env", "production"),
        policy_mode=getattr(settings, "webhook_destination_policy_mode", "off"),
        allowed_domains=tuple(getattr(settings, "webhook_allowed_domains", [])),
    )
    return UpdateWebhookResponse(**result)


@webhooks_router.delete("/{webhook_id}", response_model=DeleteWebhookResponse)
async def delete_webhook(
    webhook_id: str,
    db: DbSession,
    app: Application,
) -> DeleteWebhookResponse:
    """Delete a webhook.

    Requires API key authentication.
    """
    result = await service.delete_webhook(
        db,
        webhook_id=UUID(webhook_id),
        application_id=app.id,
    )
    return DeleteWebhookResponse(**result)


@webhooks_router.get(
    "/{webhook_id}/deliveries", response_model=ListDeliveriesResponse
)
async def list_deliveries(
    webhook_id: str,
    db: DbSession,
    app: Application,
    limit: int = Query(default=100, ge=1, le=1000),
) -> ListDeliveriesResponse:
    """List delivery attempts for a webhook.

    Requires API key authentication.
    """
    result = await service.list_deliveries(
        db,
        webhook_id=UUID(webhook_id),
        application_id=app.id,
        limit=limit,
    )
    return ListDeliveriesResponse(**result)


@webhooks_router.get("/events", response_model=ListEventTypesResponse)
async def list_event_types(
    app: Application,
) -> ListEventTypesResponse:
    """List all supported webhook event types.

    Requires API key authentication.
    """
    result = await service.list_event_types()
    return ListEventTypesResponse(**result)


# ===========================================================================
# Mailgun Webhook Router
# ===========================================================================

mailgun_router = APIRouter(prefix="/webhooks/mailgun", tags=["webhooks"])


@mailgun_router.post("/events")
async def handle_mailgun_event(
    request: Request,
    db: DbSession,
) -> dict[str, Any]:
    """Handle incoming Mailgun webhook events.

    Verifies Mailgun HMAC signature before processing.
    Updates email_log status based on event type.

    Events handled: delivered, opened, clicked, complained, failed, bounced.
    """
    body = await request.json()
    settings = request.app.state.settings

    result = await service.process_mailgun_event(
        db,
        body=body,
        mailgun_webhook_signing_key=settings.mailgun_webhook_signing_key,
    )

    return {"success": True, "data": result}
