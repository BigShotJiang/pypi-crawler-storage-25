"""Email domain — template management, sending via Mailgun, and logging."""
