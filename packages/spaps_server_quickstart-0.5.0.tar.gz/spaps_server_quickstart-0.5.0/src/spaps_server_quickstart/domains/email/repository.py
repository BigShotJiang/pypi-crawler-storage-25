"""Database operations for the email domain.

Pure SQLAlchemy async repository -- no FastAPI imports.
All functions accept an ``AsyncSession`` as the first positional argument.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .models import EmailLog, EmailTemplate

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Template lookups
# ---------------------------------------------------------------------------


async def get_template_by_key(
    db: AsyncSession,
    application_id: UUID,
    template_key: str,
) -> EmailTemplate | None:
    """Fetch a single template by key scoped to an application."""
    stmt = select(EmailTemplate).where(
        EmailTemplate.application_id == application_id,
        EmailTemplate.template_key == template_key,
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def get_template_by_id(
    db: AsyncSession,
    template_id: UUID,
) -> EmailTemplate | None:
    """Fetch a single template by ID."""
    stmt = select(EmailTemplate).where(EmailTemplate.id == template_id)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def list_templates(
    db: AsyncSession,
    application_id: UUID,
) -> list[EmailTemplate]:
    """List all templates for an application."""
    stmt = (
        select(EmailTemplate)
        .where(EmailTemplate.application_id == application_id)
        .order_by(EmailTemplate.created_at.desc())
    )
    result = await db.execute(stmt)
    return list(result.scalars().all())


# ---------------------------------------------------------------------------
# Template mutations
# ---------------------------------------------------------------------------


async def create_template(
    db: AsyncSession,
    **kwargs: Any,
) -> EmailTemplate:
    """Insert a new email template and return the persisted instance."""
    template = EmailTemplate(**kwargs)
    db.add(template)
    await db.flush()
    await db.refresh(template)
    return template


async def update_template(
    db: AsyncSession,
    application_id: UUID,
    template_key: str,
    **kwargs: Any,
) -> EmailTemplate | None:
    """Update a template by key scoped to an application."""
    template = await get_template_by_key(db, application_id, template_key)
    if template is None:
        return None

    for key, value in kwargs.items():
        if hasattr(template, key):
            setattr(template, key, value)

    template.updated_at = datetime.now(UTC)
    await db.flush()
    await db.refresh(template)
    return template


# ---------------------------------------------------------------------------
# Email log operations
# ---------------------------------------------------------------------------


async def create_email_log(
    db: AsyncSession,
    **kwargs: Any,
) -> EmailLog:
    """Insert an email log entry and return the persisted instance."""
    log_entry = EmailLog(**kwargs)
    db.add(log_entry)
    await db.flush()
    await db.refresh(log_entry)
    return log_entry


async def update_email_log(
    db: AsyncSession,
    log_id: UUID,
    **kwargs: Any,
) -> EmailLog | None:
    """Update an email log entry by ID."""
    stmt = select(EmailLog).where(EmailLog.id == log_id)
    result = await db.execute(stmt)
    log_entry = result.scalar_one_or_none()
    if log_entry is None:
        return None

    for key, value in kwargs.items():
        if hasattr(log_entry, key):
            setattr(log_entry, key, value)

    await db.flush()
    await db.refresh(log_entry)
    return log_entry


async def get_log_by_mailgun_message_id(
    db: AsyncSession,
    mailgun_message_id: str,
) -> EmailLog | None:
    """Fetch an email log entry by its Mailgun message ID."""
    stmt = select(EmailLog).where(
        EmailLog.mailgun_message_id == mailgun_message_id,
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def list_logs(
    db: AsyncSession,
    application_id: UUID,
    *,
    owner_id: UUID | None = None,
    user_id: UUID | None = None,
    limit: int = 50,
    offset: int = 0,
) -> tuple[list[EmailLog], int]:
    """List email logs for an application with optional filters.

    Returns a tuple of (logs, total_count).
    """
    stmt = (
        select(EmailLog)
        .where(EmailLog.application_id == application_id)
    )

    if owner_id is not None:
        stmt = stmt.where(EmailLog.owner_id == owner_id)

    if user_id is not None:
        stmt = stmt.where(EmailLog.user_id == user_id)

    # Count query (same filters, no limit/offset)
    from sqlalchemy import func as sa_func

    count_stmt = (
        select(sa_func.count())
        .select_from(EmailLog)
        .where(EmailLog.application_id == application_id)
    )
    if owner_id is not None:
        count_stmt = count_stmt.where(EmailLog.owner_id == owner_id)
    if user_id is not None:
        count_stmt = count_stmt.where(EmailLog.user_id == user_id)

    count_result = await db.execute(count_stmt)
    total = count_result.scalar() or 0

    # Apply ordering, limit, offset
    stmt = (
        stmt.order_by(EmailLog.created_at.desc())
        .limit(limit)
        .offset(offset)
    )

    result = await db.execute(stmt)
    logs = list(result.scalars().all())

    return logs, total
