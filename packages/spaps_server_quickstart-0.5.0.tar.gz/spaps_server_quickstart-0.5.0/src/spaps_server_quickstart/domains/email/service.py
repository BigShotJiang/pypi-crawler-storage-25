"""Business logic for the email domain.

Coordinates repository calls, template rendering, and Mailgun delivery.
This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import inspect
import logging
import os
import re
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from ..errors import ValidationError
from . import repository as repo
from .config import resolve_email_config
from .errors import (
    EmailConfigurationError,
    EmailSendFailedError,
    TemplateAlreadyExistsError,
    TemplateNotFoundError,
    TemplateOverrideNotFoundError,
)
from .mailgun import MailgunClient, MailgunConfig
from .models import EmailLog, EmailTemplate

logger = logging.getLogger(__name__)

_OVERRIDE_SAMPLE_CONTEXT_KEY = "__spaps_template_override__"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _template_to_dict(tpl: EmailTemplate) -> dict[str, Any]:
    """Convert an EmailTemplate model instance to a serialisable dict."""
    return {
        "id": str(tpl.id),
        "application_id": str(tpl.application_id),
        "template_key": tpl.template_key,
        "name": tpl.name,
        "description": tpl.description,
        "subject": tpl.subject,
        "html_body": tpl.html_body,
        "text_body": tpl.text_body,
        "from_email": tpl.from_email,
        "from_name": tpl.from_name,
        "reply_to": tpl.reply_to,
        "variables": tpl.variables,
        "sample_context": _strip_override_from_sample_context(tpl.sample_context),
        "is_active": tpl.is_active,
        "category": tpl.category,
        "created_at": tpl.created_at.isoformat() if tpl.created_at else None,
        "updated_at": tpl.updated_at.isoformat() if tpl.updated_at else None,
    }


def _log_to_dict(log: EmailLog) -> dict[str, Any]:
    """Convert an EmailLog model instance to a serialisable dict."""
    return {
        "id": str(log.id),
        "application_id": str(log.application_id),
        "template_id": str(log.template_id) if log.template_id else None,
        "user_id": str(log.user_id) if log.user_id else None,
        "owner_id": str(log.owner_id) if log.owner_id else None,
        "to_email": log.to_email,
        "template_key": log.template_key,
        "subject": log.subject,
        "status": log.status,
        "mailgun_message_id": log.mailgun_message_id,
        "error_message": log.error_message,
        "sent_at": log.sent_at.isoformat() if log.sent_at else None,
        "delivered_at": log.delivered_at.isoformat() if log.delivered_at else None,
        "opened_at": log.opened_at.isoformat() if log.opened_at else None,
        "clicked_at": log.clicked_at.isoformat() if log.clicked_at else None,
        "created_at": log.created_at.isoformat() if log.created_at else None,
    }


def _extract_template_override(
    sample_context: dict[str, Any] | None,
) -> dict[str, str | None] | None:
    """Extract template override payload from sample_context."""
    if not sample_context or not isinstance(sample_context, dict):
        return None

    raw = sample_context.get(_OVERRIDE_SAMPLE_CONTEXT_KEY)
    if not isinstance(raw, dict):
        return None

    subject_raw = raw.get("subject_override")
    body_raw = raw.get("body_override")
    subject_override = subject_raw if isinstance(subject_raw, str) else None
    body_override = body_raw if isinstance(body_raw, str) else None

    if subject_override is None and body_override is None:
        return None

    return {
        "subject_override": subject_override,
        "body_override": body_override,
    }


def _strip_override_from_sample_context(
    sample_context: dict[str, Any] | None,
) -> dict[str, Any] | None:
    """Hide internal override storage key from template payload responses."""
    if not sample_context or not isinstance(sample_context, dict):
        return sample_context
    if _OVERRIDE_SAMPLE_CONTEXT_KEY not in sample_context:
        return sample_context

    cleaned = dict(sample_context)
    cleaned.pop(_OVERRIDE_SAMPLE_CONTEXT_KEY, None)
    return cleaned


def _resolve_recipient_override(
    app_settings: dict[str, Any] | None,
) -> str | None:
    """Resolve an email recipient override destination, if configured.

    Precedence:
    1. app.settings.email.override_to
    2. app.settings.email.dev_override_to
    3. DEV_EMAIL_OVERRIDE_TO environment variable
    """
    if isinstance(app_settings, dict):
        raw_email_settings = app_settings.get("email")
        if isinstance(raw_email_settings, dict):
            for key in ("override_to", "dev_override_to"):
                value = raw_email_settings.get(key)
                if isinstance(value, str):
                    cleaned = value.strip()
                    if cleaned:
                        return cleaned

    env_override = os.environ.get("DEV_EMAIL_OVERRIDE_TO")
    if isinstance(env_override, str):
        cleaned = env_override.strip()
        if cleaned:
            return cleaned

    return None


def render_template(template_str: str, context: dict[str, Any]) -> str:
    """Render a template string by substituting ``{{ variable }}`` placeholders.

    Uses simple regex-based substitution. Supports ``{{ var }}`` and
    ``{{var}}`` syntax.
    """

    def _replace(match: re.Match) -> str:
        key = match.group(1).strip()
        return str(context.get(key, match.group(0)))

    return re.sub(r"\{\{\s*(\w+)\s*\}\}", _replace, template_str)


def _is_production(settings_env: str) -> bool:
    """Check if we are running in production.

    TM-ENV-001: Environment Safety for Email
    ----------------------------------------
    Uses settings.env as the canonical source of truth, with environment
    variable fallback for defense-in-depth. Logs warnings if they disagree.

    This prevents tests from accidentally sending real emails if developer
    shell ENV vars are set but Pydantic settings are overridden in tests.

    Args:
        settings_env: The environment from SpapsSettings.env (canonical)

    Returns:
        True if production, False otherwise
    """
    canonical = settings_env.lower() in ("production", "prod")
    env_var = os.environ.get("ENV", "").lower()

    # Defense-in-depth: warn if environment variable disagrees with settings
    if env_var and env_var in ("production", "prod") and not canonical:
        logger.warning(
            "ENV variable mismatch: ENV=%s but settings.env=%s. "
            "Using settings.env as canonical to prevent accidental email sends.",
            env_var, settings_env
        )

    return canonical


def _is_local_mode(settings_local_mode: bool) -> bool:
    """Check if SPAPS_LOCAL_MODE is active.

    TM-ENV-001: Uses settings.is_spaps_local_mode as canonical source,
    with environment variable fallback for defense-in-depth.

    Args:
        settings_local_mode: The value from settings.is_spaps_local_mode

    Returns:
        True if local mode is active
    """
    canonical = settings_local_mode
    env_var = os.environ.get("SPAPS_LOCAL_MODE", "").lower() == "true"

    # Defense-in-depth: warn if environment variable disagrees with settings
    if env_var and not canonical:
        logger.warning(
            "SPAPS_LOCAL_MODE variable mismatch: env=%s but settings=%s. "
            "Using settings as canonical.",
            env_var, canonical
        )

    return canonical


def _should_short_circuit(settings_env: str, settings_local_mode: bool) -> bool:
    """Safety invariant: skip Mailgun if local mode or non-production.

    TM-ENV-001: Environment Safety for Email
    ----------------------------------------
    This is the primary safety gate preventing accidental email sends in
    test/dev environments. Uses settings.env and settings.is_spaps_local_mode
    as canonical sources of truth.

    If SPAPS_LOCAL_MODE=true or ENV != production, email service MUST
    short-circuit. Log the email but never call Mailgun.

    Opt-in bypass: set SPAPS_FORCE_EMAIL_DELIVERY=true to allow real
    Mailgun delivery in non-prod (for use with DEV_EMAIL_OVERRIDE_TO
    in consuming services).

    Args:
        settings_env: The environment from SpapsSettings.env
        settings_local_mode: The value from settings.is_spaps_local_mode

    Returns:
        True if email should be short-circuited (not sent)
    """
    if os.environ.get("SPAPS_FORCE_EMAIL_DELIVERY", "").lower() == "true":
        logger.warning(
            "spaps_force_email_delivery_active: env=%s local_mode=%s",
            settings_env,
            settings_local_mode,
        )
        return False

    if _is_local_mode(settings_local_mode):
        return True
    if not _is_production(settings_env):
        return True
    return False


def _get_mailgun_client(domain_override: str | None = None) -> MailgunClient | None:
    """Build a MailgunClient from environment variables, or None if not configured."""
    api_key = os.environ.get("MAILGUN_API_KEY")
    domain = domain_override or os.environ.get("MAILGUN_DOMAIN")
    if not api_key or not domain:
        return None
    base_url = os.environ.get("MAILGUN_BASE_URL", "https://api.mailgun.net/v3")
    return MailgunClient(MailgunConfig(api_key=api_key, domain=domain, base_url=base_url))


def _apply_template_context_aliases(effective_context: dict[str, Any]) -> None:
    if "expires_in" not in effective_context and "expires_in_minutes" in effective_context:
        mins = effective_context["expires_in_minutes"]
        effective_context["expires_in"] = f"{mins} minutes"

    if "link" not in effective_context:
        return

    link_val = effective_context["link"]
    for alias in ("action_url", "magic_link", "reset_link", "confirmation_link"):
        if alias not in effective_context:
            effective_context[alias] = link_val


async def _build_email_context(
    db: AsyncSession,
    *,
    application_id: UUID,
    app_settings: dict[str, Any] | None,
    context: dict[str, Any] | None,
) -> tuple[dict[str, Any], dict[str, Any] | None]:
    effective_context = dict(context or {})
    effective_app_settings = app_settings

    if "current_year" not in effective_context:
        effective_context["current_year"] = str(datetime.now(UTC).year)

    needs_app_context = (
        "app_name" not in effective_context
        or "app_logo_url" not in effective_context
        or app_settings is None
    )
    if needs_app_context:
        try:
            from ..applications import repository as app_repo

            app = await app_repo.get_application_by_id(db, str(application_id))
            if inspect.isawaitable(app):
                app = await app
            if app:
                app_name_raw = getattr(app, "name", None)
                if "app_name" not in effective_context and isinstance(app_name_raw, str) and app_name_raw:
                    effective_context["app_name"] = app_name_raw

                app_settings_payload = getattr(app, "settings", None)
                if "app_logo_url" not in effective_context and isinstance(app_settings_payload, dict):
                    logo = app_settings_payload.get("logo_url")
                    if logo:
                        effective_context["app_logo_url"] = logo

                if effective_app_settings is None:
                    effective_app_settings = app_settings_payload
        except Exception:
            logger.debug("Could not resolve app context for application %s", application_id)

    _apply_template_context_aliases(effective_context)
    return effective_context, effective_app_settings


def _resolve_template_overrides(
    template: EmailTemplate,
    *,
    subject_override: str | None,
    body_override: str | None,
) -> tuple[str | None, str | None]:
    stored_override = _extract_template_override(template.sample_context)
    return (
        subject_override
        or (stored_override.get("subject_override") if stored_override else None),
        body_override
        or (stored_override.get("body_override") if stored_override else None),
    )


def _render_email_content(
    template: EmailTemplate,
    *,
    effective_context: dict[str, Any],
    subject_override: str | None,
    body_override: str | None,
) -> tuple[str, str, str | None]:
    effective_subject_override, effective_body_override = _resolve_template_overrides(
        template,
        subject_override=subject_override,
        body_override=body_override,
    )
    subject = effective_subject_override or render_template(
        template.subject,
        effective_context,
    )
    html_body = effective_body_override or render_template(
        template.html_body,
        effective_context,
    )
    text_body = (
        render_template(template.text_body, effective_context)
        if template.text_body
        else None
    )
    return subject, html_body, text_body


def _resolve_delivery_recipient(
    *,
    application_id: UUID,
    template_key: str,
    to: str,
    app_settings: dict[str, Any] | None,
) -> str:
    recipient_override_to = _resolve_recipient_override(app_settings)
    if not recipient_override_to:
        return to

    logger.warning(
        "email_recipient_override_active",
        extra={
            "application_id": str(application_id),
            "template_key": template_key,
            "original_to": to,
            "override_to": recipient_override_to,
        },
    )
    return recipient_override_to


async def _short_circuit_email_log(
    db: AsyncSession,
    *,
    log_entry: EmailLog,
    resolved_to: str,
    template_key: str,
    settings_env: str,
    settings_local_mode: bool,
    force_send: bool,
) -> dict[str, Any]:
    reason = "local_mode" if _is_local_mode(settings_local_mode) else "non_production"
    logger.info(
        "Email short-circuited (TM-ENV-001 safety gate)",
        extra={
            "to": resolved_to,
            "template_key": template_key,
            "log_id": str(log_entry.id),
            "reason": reason,
            "settings_env": settings_env,
            "settings_local_mode": settings_local_mode,
            "force_send": force_send,
        },
    )
    await repo.update_email_log(
        db,
        log_entry.id,
        status="short_circuited",
        sent_at=datetime.now(UTC),
        mailgun_message_id=f"local-{log_entry.id}",
    )
    return {"message_id": f"local-{log_entry.id}"}


async def _resolve_email_delivery_config(
    db: AsyncSession,
    *,
    log_entry: EmailLog,
    app_settings: dict[str, Any] | None,
    template: EmailTemplate,
) -> Any:
    try:
        return resolve_email_config(
            app_settings=app_settings,
            template_from_email=template.from_email,
            template_from_name=template.from_name,
            template_reply_to=template.reply_to,
            global_mailgun_domain=os.environ.get("MAILGUN_DOMAIN"),
        )
    except EmailConfigurationError:
        await repo.update_email_log(
            db,
            log_entry.id,
            status="failed",
            error_message="Mailgun not configured",
        )
        raise


async def _require_mailgun_client(
    db: AsyncSession,
    *,
    log_entry: EmailLog,
    domain_override: str | None,
) -> MailgunClient:
    mailgun = _get_mailgun_client(domain_override=domain_override)
    if mailgun is not None:
        return mailgun

    await repo.update_email_log(
        db,
        log_entry.id,
        status="failed",
        error_message="Mailgun not configured",
    )
    raise EmailConfigurationError("Mailgun API key or domain not configured")


async def _send_and_record_email(
    db: AsyncSession,
    *,
    log_entry: EmailLog,
    mailgun: MailgunClient,
    resolved_to: str,
    subject: str,
    html_body: str,
    text_body: str | None,
    resolved_email_config: Any,
) -> dict[str, Any]:
    result = await mailgun.send_email(
        to=resolved_to,
        subject=subject,
        html=html_body,
        text=text_body,
        from_email=resolved_email_config.from_email,
        from_name=resolved_email_config.from_name,
        reply_to=resolved_email_config.reply_to,
    )

    if result.success:
        await repo.update_email_log(
            db,
            log_entry.id,
            status="sent",
            sent_at=datetime.now(UTC),
            mailgun_message_id=result.message_id,
        )
        return {"message_id": result.message_id or str(log_entry.id)}

    await repo.update_email_log(
        db,
        log_entry.id,
        status="failed",
        error_message=result.error,
    )
    raise EmailSendFailedError(result.error or "Failed to send email")


# ---------------------------------------------------------------------------
# Send email
# ---------------------------------------------------------------------------


async def send_email(
    db: AsyncSession,
    *,
    application_id: UUID,
    app_settings: dict[str, Any] | None = None,
    template_key: str,
    to: str,
    settings_env: str = "dev",
    settings_local_mode: bool = False,
    context: dict[str, Any] | None = None,
    user_id: UUID | None = None,
    owner_id: UUID | None = None,
    subject_override: str | None = None,
    body_override: str | None = None,
    force_send: bool = False,
) -> dict[str, Any]:
    """Send an email using a template.

    TM-ENV-001: Environment Safety for Email
    ----------------------------------------
    Safety invariant: If local mode or non-production, the email is logged
    but Mailgun is never called, even with force_send=True.

    Args:
        db: Database session
        application_id: Application UUID
        app_settings: Optional app settings payload from the caller
        template_key: Email template key
        to: Recipient email address
        settings_env: Environment from settings.env (canonical source)
        settings_local_mode: Local mode flag from settings.is_spaps_local_mode
        context: Template variables
        user_id: Optional user UUID
        owner_id: Optional owner UUID
        subject_override: Override template subject
        body_override: Override template body
        force_send: If True, skip short-circuit ONLY in production environments.
                    In dev/test, email is still logged but never sent.

    Returns:
        Dict with message_id (real or local)
    """
    template = await repo.get_template_by_key(db, application_id, template_key)
    if template is None:
        raise TemplateNotFoundError(f"Template '{template_key}' not found")

    if not template.is_active:
        raise TemplateNotFoundError(f"Template '{template_key}' is not active")

    effective_context, effective_app_settings = await _build_email_context(
        db,
        application_id=application_id,
        app_settings=app_settings,
        context=context,
    )
    subject, html_body, text_body = _render_email_content(
        template,
        effective_context=effective_context,
        subject_override=subject_override,
        body_override=body_override,
    )
    resolved_to = _resolve_delivery_recipient(
        application_id=application_id,
        template_key=template_key,
        to=to,
        app_settings=effective_app_settings,
    )

    log_entry = await repo.create_email_log(
        db,
        application_id=application_id,
        template_id=template.id,
        user_id=user_id,
        owner_id=owner_id,
        to_email=resolved_to,
        template_key=template_key,
        subject=subject,
        status="pending",
    )

    if _should_short_circuit(settings_env, settings_local_mode):
        return await _short_circuit_email_log(
            db,
            log_entry=log_entry,
            resolved_to=resolved_to,
            template_key=template_key,
            settings_env=settings_env,
            settings_local_mode=settings_local_mode,
            force_send=force_send,
        )

    resolved_email_config = await _resolve_email_delivery_config(
        db,
        log_entry=log_entry,
        app_settings=effective_app_settings,
        template=template,
    )
    mailgun = await _require_mailgun_client(
        db,
        log_entry=log_entry,
        domain_override=resolved_email_config.mailgun_domain,
    )
    return await _send_and_record_email(
        db,
        log_entry=log_entry,
        mailgun=mailgun,
        resolved_to=resolved_to,
        subject=subject,
        html_body=html_body,
        text_body=text_body,
        resolved_email_config=resolved_email_config,
    )


# ---------------------------------------------------------------------------
# Template CRUD
# ---------------------------------------------------------------------------


async def list_templates(
    db: AsyncSession,
    *,
    application_id: UUID,
) -> dict[str, Any]:
    """List all templates for an application."""
    templates = await repo.list_templates(db, application_id)
    return {
        "templates": [_template_to_dict(t) for t in templates],
    }


async def get_template(
    db: AsyncSession,
    *,
    application_id: UUID,
    template_key: str,
) -> dict[str, Any]:
    """Get a single template by key."""
    template = await repo.get_template_by_key(db, application_id, template_key)
    if template is None:
        raise TemplateNotFoundError(f"Template '{template_key}' not found")
    return _template_to_dict(template)


async def preview_template(
    db: AsyncSession,
    *,
    application_id: UUID,
    template_key: str,
    context: dict[str, Any] | None = None,
) -> str:
    """Render a template with context (or sample_context) and return HTML."""
    template = await repo.get_template_by_key(db, application_id, template_key)
    if template is None:
        raise TemplateNotFoundError(f"Template '{template_key}' not found")

    effective_context = context or template.sample_context or {}
    return render_template(template.html_body, effective_context)


async def create_template(
    db: AsyncSession,
    *,
    application_id: UUID,
    template_key: str,
    name: str,
    subject: str,
    html_body: str,
    description: str | None = None,
    text_body: str | None = None,
    from_email: str | None = None,
    from_name: str | None = None,
    reply_to: str | None = None,
    variables: dict[str, Any] | None = None,
    sample_context: dict[str, Any] | None = None,
    is_active: bool = True,
    category: str | None = None,
) -> dict[str, Any]:
    """Create a new email template.

    Raises TemplateAlreadyExistsError if a template with the same key exists.
    """
    # Check for duplicate
    existing = await repo.get_template_by_key(db, application_id, template_key)
    if existing is not None:
        raise TemplateAlreadyExistsError(
            f"Template with key '{template_key}' already exists"
        )

    template = await repo.create_template(
        db,
        application_id=application_id,
        template_key=template_key,
        name=name,
        subject=subject,
        html_body=html_body,
        description=description,
        text_body=text_body,
        from_email=from_email,
        from_name=from_name,
        reply_to=reply_to,
        variables=variables or {},
        sample_context=sample_context or {},
        is_active=is_active,
        category=category,
    )

    logger.info(
        "Email template created",
        extra={
            "id": str(template.id),
            "template_key": template_key,
        },
    )

    return {"template": _template_to_dict(template)}


async def update_template(
    db: AsyncSession,
    *,
    application_id: UUID,
    template_key: str,
    name: str | None = None,
    description: str | None = None,
    subject: str | None = None,
    html_body: str | None = None,
    text_body: str | None = None,
    from_email: str | None = None,
    from_name: str | None = None,
    reply_to: str | None = None,
    variables: dict[str, Any] | None = None,
    sample_context: dict[str, Any] | None = None,
    is_active: bool | None = None,
    category: str | None = None,
) -> dict[str, Any]:
    """Update an existing email template."""
    kwargs: dict[str, Any] = {}
    if name is not None:
        kwargs["name"] = name
    if description is not None:
        kwargs["description"] = description
    if subject is not None:
        kwargs["subject"] = subject
    if html_body is not None:
        kwargs["html_body"] = html_body
    if text_body is not None:
        kwargs["text_body"] = text_body
    if from_email is not None:
        kwargs["from_email"] = from_email
    if from_name is not None:
        kwargs["from_name"] = from_name
    if reply_to is not None:
        kwargs["reply_to"] = reply_to
    if variables is not None:
        kwargs["variables"] = variables
    if sample_context is not None:
        kwargs["sample_context"] = sample_context
    if is_active is not None:
        kwargs["is_active"] = is_active
    if category is not None:
        kwargs["category"] = category

    template = await repo.update_template(
        db,
        application_id,
        template_key,
        **kwargs,
    )

    if template is None:
        raise TemplateNotFoundError(f"Template '{template_key}' not found")

    logger.info("Email template updated", extra={"template_key": template_key})

    return {"template": _template_to_dict(template)}


# ---------------------------------------------------------------------------
# Template overrides
# ---------------------------------------------------------------------------


async def get_template_override(
    db: AsyncSession,
    *,
    application_id: UUID,
    template_key: str,
) -> dict[str, str | None]:
    """Get the stored override for a template."""
    template = await repo.get_template_by_key(db, application_id, template_key)
    if template is None:
        raise TemplateNotFoundError(f"Template '{template_key}' not found")

    override = _extract_template_override(template.sample_context)
    if override is None:
        raise TemplateOverrideNotFoundError(
            f"Template override for '{template_key}' not found"
        )

    return override


async def create_or_update_template_override(
    db: AsyncSession,
    *,
    application_id: UUID,
    template_key: str,
    subject_override: str | None = None,
    body_override: str | None = None,
) -> dict[str, str | None]:
    """Create or update the stored override for a template."""
    if subject_override is None and body_override is None:
        raise ValidationError(
            "At least one of subject_override or body_override is required"
        )

    template = await repo.get_template_by_key(db, application_id, template_key)
    if template is None:
        raise TemplateNotFoundError(f"Template '{template_key}' not found")

    sample_context = dict(template.sample_context or {})
    existing_override = _extract_template_override(sample_context) or {}

    if subject_override is not None:
        existing_override["subject_override"] = subject_override
    if body_override is not None:
        existing_override["body_override"] = body_override

    sample_context[_OVERRIDE_SAMPLE_CONTEXT_KEY] = existing_override
    updated = await repo.update_template(
        db,
        application_id,
        template_key,
        sample_context=sample_context,
    )

    if updated is None:
        raise TemplateNotFoundError(f"Template '{template_key}' not found")

    override = _extract_template_override(updated.sample_context)
    if override is None:
        raise TemplateOverrideNotFoundError(
            f"Template override for '{template_key}' not found"
        )
    return override


async def delete_template_override(
    db: AsyncSession,
    *,
    application_id: UUID,
    template_key: str,
) -> dict[str, bool]:
    """Delete the stored override for a template."""
    template = await repo.get_template_by_key(db, application_id, template_key)
    if template is None:
        raise TemplateNotFoundError(f"Template '{template_key}' not found")

    sample_context = dict(template.sample_context or {})
    if _extract_template_override(sample_context) is None:
        raise TemplateOverrideNotFoundError(
            f"Template override for '{template_key}' not found"
        )

    sample_context.pop(_OVERRIDE_SAMPLE_CONTEXT_KEY, None)
    updated = await repo.update_template(
        db,
        application_id,
        template_key,
        sample_context=sample_context,
    )

    if updated is None:
        raise TemplateNotFoundError(f"Template '{template_key}' not found")

    return {"deleted": True}


# ---------------------------------------------------------------------------
# Email logs
# ---------------------------------------------------------------------------


async def get_logs(
    db: AsyncSession,
    *,
    application_id: UUID,
    owner_id: UUID | None = None,
    user_id: UUID | None = None,
    limit: int = 50,
    offset: int = 0,
) -> dict[str, Any]:
    """Get email logs for an application."""
    logs, total = await repo.list_logs(
        db,
        application_id,
        owner_id=owner_id,
        user_id=user_id,
        limit=limit,
        offset=offset,
    )
    return {
        "logs": [_log_to_dict(log) for log in logs],
        "total": total,
    }


# ---------------------------------------------------------------------------
# Auth email template seeding
# ---------------------------------------------------------------------------

# Default auth templates that must exist for auth flows to work.
_AUTH_TEMPLATES: list[dict[str, Any]] = [
    {
        "template_key": "auth_magic_link",
        "name": "Magic Link",
        "subject": "Your sign-in link",
        "html_body": (
            "<p>Click the link below to sign in:</p>"
            '<p><a href="{{ link }}">{{ link }}</a></p>'
            "<p>This link expires in {{ expires_in_minutes }} minutes.</p>"
        ),
        "text_body": (
            "Click the link below to sign in:\n\n{{ link }}\n\n"
            "This link expires in {{ expires_in_minutes }} minutes."
        ),
        "description": "Sent when a user requests a magic-link sign-in.",
        "variables": {"link": "string", "expires_in_minutes": "number"},
        "sample_context": {"link": "https://example.com/auth/ml/tok123", "expires_in_minutes": "15"},
        "category": "auth",
    },
    {
        "template_key": "auth_password_reset",
        "name": "Password Reset",
        "subject": "Reset your password",
        "html_body": (
            "<p>We received a request to reset your password.</p>"
            '<p><a href="{{ link }}">Reset password</a></p>'
            "<p>If you did not request this, you can ignore this email.</p>"
        ),
        "text_body": (
            "We received a request to reset your password.\n\n"
            "Reset password: {{ link }}\n\n"
            "If you did not request this, you can ignore this email."
        ),
        "description": "Sent when a user requests a password reset.",
        "variables": {"link": "string"},
        "sample_context": {"link": "https://example.com/auth/reset/tok123"},
        "category": "auth",
    },
    {
        "template_key": "auth_email_confirmation",
        "name": "Email Confirmation",
        "subject": "Confirm your email address",
        "html_body": (
            "<p>Please confirm your email address by clicking the link below:</p>"
            '<p><a href="{{ link }}">Confirm email</a></p>'
        ),
        "text_body": (
            "Please confirm your email address by clicking the link below:\n\n"
            "{{ link }}"
        ),
        "description": "Sent when a new user registers to verify their email.",
        "variables": {"link": "string"},
        "sample_context": {"link": "https://example.com/auth/confirm/tok123"},
        "category": "auth",
    },
    {
        "template_key": "auth_welcome",
        "name": "Welcome",
        "subject": "Welcome to {{ app_name }}",
        "html_body": (
            "<p>Welcome to {{ app_name }}, {{ name }}!</p>"
            "<p>Your account has been created successfully.</p>"
        ),
        "text_body": (
            "Welcome to {{ app_name }}, {{ name }}!\n\n"
            "Your account has been created successfully."
        ),
        "description": "Sent after a user completes registration.",
        "variables": {"app_name": "string", "name": "string"},
        "sample_context": {"app_name": "My App", "name": "User"},
        "category": "auth",
    },
]


async def ensure_auth_templates(
    db: AsyncSession,
    *,
    application_id: UUID,
) -> list[str]:
    """Seed default auth email templates if they don't already exist.

    Safe to call repeatedly -- skips templates that already exist.
    Returns a list of template_keys that were created.
    """
    created: list[str] = []
    for tpl_data in _AUTH_TEMPLATES:
        existing = await repo.get_template_by_key(
            db, application_id, tpl_data["template_key"]
        )
        if existing is not None:
            continue

        await repo.create_template(
            db,
            application_id=application_id,
            is_active=True,
            **tpl_data,
        )
        created.append(tpl_data["template_key"])

    if created:
        logger.info(
            "Auth email templates seeded",
            extra={"template_keys": created, "application_id": str(application_id)},
        )

    return created
