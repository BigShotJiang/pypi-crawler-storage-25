"""Email configuration resolution helpers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .errors import EmailConfigurationError


@dataclass(frozen=True)
class ResolvedEmailConfig:
    """Resolved sender and Mailgun domain values for a single send."""

    mailgun_domain: str
    from_email: str
    from_name: str | None
    reply_to: str | None


def _clean_optional_str(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    cleaned = value.strip()
    return cleaned or None


def _extract_email_settings(app_settings: dict[str, Any] | None) -> dict[str, Any]:
    if not isinstance(app_settings, dict):
        return {}
    raw = app_settings.get("email")
    if not isinstance(raw, dict):
        return {}
    return raw


def resolve_email_config(
    *,
    app_settings: dict[str, Any] | None,
    template_from_email: str | None = None,
    template_from_name: str | None = None,
    template_reply_to: str | None = None,
    global_mailgun_domain: str | None = None,
) -> ResolvedEmailConfig:
    """Resolve email config with deterministic precedence."""
    email_settings = _extract_email_settings(app_settings)

    app_mailgun_domain = _clean_optional_str(email_settings.get("mailgun_domain"))
    fallback_mailgun_domain = _clean_optional_str(global_mailgun_domain)
    mailgun_domain = app_mailgun_domain or fallback_mailgun_domain
    if not mailgun_domain:
        raise EmailConfigurationError("Mailgun domain not configured")

    from_email = (
        _clean_optional_str(template_from_email)
        or _clean_optional_str(email_settings.get("default_from_email"))
        or f"noreply@{mailgun_domain}"
    )
    from_name = _clean_optional_str(template_from_name) or _clean_optional_str(
        email_settings.get("default_from_name")
    )
    reply_to = _clean_optional_str(template_reply_to) or _clean_optional_str(
        email_settings.get("default_reply_to")
    )

    return ResolvedEmailConfig(
        mailgun_domain=mailgun_domain,
        from_email=from_email,
        from_name=from_name,
        reply_to=reply_to,
    )

