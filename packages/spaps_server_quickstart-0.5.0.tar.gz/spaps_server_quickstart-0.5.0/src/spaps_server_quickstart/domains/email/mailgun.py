"""Mailgun HTTP API client.

Uses httpx for async HTTP calls to the Mailgun API.
This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

import httpx

logger = logging.getLogger(__name__)


def _normalize_base_url(base_url: str) -> str:
    """Normalize Mailgun base URL to include exactly one ``/v3`` suffix."""
    normalized = base_url.strip().rstrip("/")
    if not normalized:
        return "https://api.mailgun.net/v3"
    if normalized.endswith("/v3"):
        return normalized
    return f"{normalized}/v3"


@dataclass
class MailgunConfig:
    """Configuration for the Mailgun API client."""

    api_key: str
    domain: str
    base_url: str = "https://api.mailgun.net/v3"


@dataclass
class MailgunResponse:
    """Response from a Mailgun send operation."""

    success: bool
    message_id: str | None = None
    error: str | None = None


class MailgunClient:
    """Async Mailgun API client using httpx."""

    def __init__(self, config: MailgunConfig) -> None:
        self.config = config
        base_url = _normalize_base_url(config.base_url)
        domain = config.domain.strip().strip("/")
        self._url = f"{base_url}/{domain}/messages"

    async def send_email(
        self,
        *,
        to: str,
        subject: str,
        html: str,
        text: str | None = None,
        from_email: str | None = None,
        from_name: str | None = None,
        reply_to: str | None = None,
    ) -> MailgunResponse:
        """Send an email via Mailgun HTTP API.

        Returns a MailgunResponse with message_id on success or error on failure.
        """
        sender = from_email or f"noreply@{self.config.domain}"
        if from_name:
            sender = f"{from_name} <{sender}>"

        data: dict[str, str] = {
            "from": sender,
            "to": to,
            "subject": subject,
            "html": html,
        }

        if text:
            data["text"] = text

        if reply_to:
            data["h:Reply-To"] = reply_to

        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    self._url,
                    auth=("api", self.config.api_key),
                    data=data,
                    timeout=30.0,
                )

            if 200 <= response.status_code < 300:
                body = response.json()
                message_id = body.get("id", "")
                logger.info(
                    "Email sent via Mailgun",
                    extra={"to": to, "message_id": message_id},
                )
                return MailgunResponse(success=True, message_id=message_id)

            error_msg = f"Mailgun returned {response.status_code}: {response.text}"
            logger.error(
                "Mailgun send failed",
                extra={"to": to, "status": response.status_code, "body": response.text},
            )
            return MailgunResponse(success=False, error=error_msg)

        except httpx.HTTPError as exc:
            error_msg = f"Mailgun HTTP error: {exc}"
            logger.exception("Mailgun HTTP error", extra={"to": to})
            return MailgunResponse(success=False, error=error_msg)
        except Exception as exc:
            error_msg = f"Unexpected error sending email: {exc}"
            logger.exception("Unexpected Mailgun error", extra={"to": to})
            return MailgunResponse(success=False, error=error_msg)
