"""Pydantic request/response schemas for email endpoints.

These schemas define the *data* portion of each API response.
The standard response envelope ``{ success, data, error, metadata }``
is applied by middleware -- domain schemas never reference it.

Zero FastAPI imports.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Canonical representations
# ---------------------------------------------------------------------------


class EmailTemplateOut(BaseModel):
    """Canonical representation of an email template."""

    id: str
    application_id: str
    template_key: str
    name: str
    description: str | None = None
    subject: str
    html_body: str
    text_body: str | None = None
    from_email: str | None = None
    from_name: str | None = None
    reply_to: str | None = None
    variables: list[dict[str, Any]] | dict[str, Any] | None = None
    sample_context: dict[str, Any] | None = None
    is_active: bool
    category: str | None = None
    created_at: str | None = None
    updated_at: str | None = None


class EmailLogOut(BaseModel):
    """Canonical representation of an email log entry."""

    id: str
    application_id: str
    template_id: str | None = None
    user_id: str | None = None
    owner_id: str | None = None
    to_email: str
    template_key: str | None = None
    subject: str | None = None
    status: str
    mailgun_message_id: str | None = None
    error_message: str | None = None
    sent_at: str | None = None
    delivered_at: str | None = None
    opened_at: str | None = None
    clicked_at: str | None = None
    created_at: str


# ---------------------------------------------------------------------------
# Request schemas
# ---------------------------------------------------------------------------


class SendEmailRequest(BaseModel):
    """POST /email/send body."""

    template_key: str
    to: str
    context: dict[str, Any] | None = None
    user_id: str | None = None
    owner_id: str | None = None
    subject_override: str | None = None
    body_override: str | None = None


class CreateTemplateRequest(BaseModel):
    """POST /email/templates body."""

    name: str
    template_key: str
    subject: str
    html_body: str
    description: str | None = None
    text_body: str | None = None
    from_email: str | None = None
    from_name: str | None = None
    reply_to: str | None = None
    variables: dict[str, Any] | None = None
    sample_context: dict[str, Any] | None = None
    is_active: bool | None = None
    category: str | None = None


class UpdateTemplateRequest(BaseModel):
    """PUT /email/templates/:key body."""

    name: str | None = None
    description: str | None = None
    subject: str | None = None
    html_body: str | None = None
    text_body: str | None = None
    from_email: str | None = None
    from_name: str | None = None
    reply_to: str | None = None
    variables: dict[str, Any] | None = None
    sample_context: dict[str, Any] | None = None
    is_active: bool | None = None
    category: str | None = None


class PreviewTemplateRequest(BaseModel):
    """POST /email/templates/:key/preview body."""

    context: dict[str, Any] = Field(default_factory=dict)


class TemplateOverrideRequest(BaseModel):
    """PUT /email/templates/:key/override body."""

    subject_override: str | None = None
    body_override: str | None = None


# ---------------------------------------------------------------------------
# Response schemas
# ---------------------------------------------------------------------------


class SendEmailResponse(BaseModel):
    """POST /email/send -- success payload."""

    message_id: str


class ListTemplatesResponse(BaseModel):
    """GET /email/templates -- success payload."""

    templates: list[EmailTemplateOut]


class GetTemplateResponse(BaseModel):
    """GET /email/templates/:key -- success payload (template object)."""

    id: str
    application_id: str
    template_key: str
    name: str
    description: str | None = None
    subject: str
    html_body: str
    text_body: str | None = None
    from_email: str | None = None
    from_name: str | None = None
    reply_to: str | None = None
    variables: dict[str, Any] | None = None
    sample_context: dict[str, Any] | None = None
    is_active: bool
    category: str | None = None
    created_at: str
    updated_at: str


class CreateTemplateResponse(BaseModel):
    """POST /email/templates -- success payload."""

    template: EmailTemplateOut


class UpdateTemplateResponse(BaseModel):
    """PUT /email/templates/:key -- success payload."""

    template: EmailTemplateOut


class TemplateOverrideResponse(BaseModel):
    """GET/PUT /email/templates/:key/override -- success payload."""

    subject_override: str | None = None
    body_override: str | None = None


class DeleteTemplateOverrideResponse(BaseModel):
    """DELETE /email/templates/:key/override -- success payload."""

    deleted: bool


class ListLogsResponse(BaseModel):
    """GET /email/logs -- success payload."""

    logs: list[EmailLogOut]
    total: int
