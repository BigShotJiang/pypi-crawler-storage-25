"""Domain errors for the email domain."""

from __future__ import annotations

from ..errors import DomainError


class TemplateNotFoundError(DomainError):
    """Raised when an email template is not found."""

    def __init__(self, message: str = "Email template not found") -> None:
        super().__init__("NOT_FOUND", message, status_code=404)


class TemplateAlreadyExistsError(DomainError):
    """Raised when a template with the same key already exists."""

    def __init__(self, message: str = "Template with this key already exists") -> None:
        super().__init__("ALREADY_EXISTS", message, status_code=409)


class TemplateOverrideNotFoundError(DomainError):
    """Raised when a template override is not found."""

    def __init__(self, message: str = "Template override not found") -> None:
        super().__init__("OVERRIDE_NOT_FOUND", message, status_code=404)


class EmailSendFailedError(DomainError):
    """Raised when email delivery fails."""

    def __init__(self, message: str = "Email delivery failed") -> None:
        super().__init__("EMAIL_SEND_FAILED", message, status_code=500)


class EmailConfigurationError(DomainError):
    """Raised when email service is misconfigured."""

    def __init__(self, message: str = "Email service misconfigured") -> None:
        super().__init__("EMAIL_CONFIGURATION_ERROR", message, status_code=400)
