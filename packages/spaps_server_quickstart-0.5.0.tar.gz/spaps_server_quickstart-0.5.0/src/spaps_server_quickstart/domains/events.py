"""
In-process event bus for domain-to-domain communication.

Keeps domains decoupled: the Stripe domain publishes "checkout.completed",
the Entitlements domain subscribes and grants access — neither imports the other.

Events are dispatched synchronously within the same request context (no Celery).
This matches the Node.js service's in-process event pattern.
"""

from __future__ import annotations

import logging
from collections import defaultdict
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

logger = logging.getLogger(__name__)

EventHandler = Callable[["DomainEvent"], Awaitable[None]]


@dataclass(frozen=True)
class DomainEvent:
    """Immutable event published by a domain."""

    event_type: str
    source_domain: str
    data: dict[str, Any]
    occurred_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    correlation_id: UUID | None = None


class EventBus:
    """
    Simple in-process event bus.

    Handlers are async callables registered per event_type. When an event is
    published, all matching handlers run sequentially. Handler errors are logged
    but do not prevent other handlers from executing.
    """

    def __init__(self) -> None:
        self._handlers: dict[str, list[EventHandler]] = defaultdict(list)

    def subscribe(self, event_type: str, handler: EventHandler) -> None:
        self._handlers[event_type].append(handler)

    def unsubscribe(self, event_type: str, handler: EventHandler) -> None:
        handlers = self._handlers.get(event_type, [])
        if handler in handlers:
            handlers.remove(handler)

    async def publish(self, event: DomainEvent) -> None:
        handlers = self._handlers.get(event.event_type, [])
        for handler in handlers:
            try:
                await handler(event)
            except Exception:
                logger.exception(
                    "Event handler %s failed for %s",
                    handler.__qualname__,
                    event.event_type,
                )


# Module-level singleton — shared across the application lifetime.
event_bus = EventBus()
