"""Domain errors for the affiliate_referrals domain.

Each error carries a machine-readable code that maps to the error codes
documented in shared.md (the locked API contract).
"""

from __future__ import annotations

from ..errors import DomainError


# --- Affiliate errors ---


class AffiliateNotFoundError(DomainError):
    def __init__(self, message: str = "Affiliate not found") -> None:
        super().__init__("AFFILIATE_NOT_FOUND", message, status_code=404)


class AffiliateAlreadyExistsError(DomainError):
    def __init__(self, message: str = "Entity already registered as affiliate") -> None:
        super().__init__("AFFILIATE_ALREADY_EXISTS", message, status_code=409)


class SlugAlreadyExistsError(DomainError):
    def __init__(self, message: str = "Vanity slug already taken") -> None:
        super().__init__("SLUG_ALREADY_EXISTS", message, status_code=409)


# --- Referral errors ---


class ClickNotFoundError(DomainError):
    def __init__(self, message: str = "Invalid referral click") -> None:
        super().__init__("CLICK_NOT_FOUND", message, status_code=404)


class ClickExpiredError(DomainError):
    def __init__(self, message: str = "Referral click has expired") -> None:
        super().__init__("CLICK_EXPIRED", message, status_code=400)


class ClickRateLimitedError(DomainError):
    def __init__(self, message: str = "Click rate limited for this IP and slug") -> None:
        super().__init__("CLICK_RATE_LIMITED", message, status_code=429)


class SelfReferralError(DomainError):
    def __init__(self, message: str = "Cannot refer yourself") -> None:
        super().__init__("SELF_REFERRAL", message, status_code=400)


class AlreadyAttributedError(DomainError):
    def __init__(self, message: str = "Entity already has a referral attribution") -> None:
        super().__init__("ALREADY_ATTRIBUTED", message, status_code=409)


# --- Payout errors ---


class InsufficientBalanceError(DomainError):
    def __init__(self, message: str = "Insufficient balance or below minimum payout") -> None:
        super().__init__("INSUFFICIENT_BALANCE", message, status_code=400)


class PayoutWalletNotSetError(DomainError):
    def __init__(self, message: str = "No payout wallet configured") -> None:
        super().__init__("PAYOUT_WALLET_NOT_SET", message, status_code=400)


class PayoutNotFoundError(DomainError):
    def __init__(self, message: str = "Payout not found") -> None:
        super().__init__("PAYOUT_NOT_FOUND", message, status_code=404)


class PayoutNotPendingError(DomainError):
    def __init__(self, message: str = "Payout is not in requested status") -> None:
        super().__init__("PAYOUT_NOT_PENDING", message, status_code=400)


class PayoutNotApprovedError(DomainError):
    def __init__(self, message: str = "Payout is not in approved status") -> None:
        super().__init__("PAYOUT_NOT_APPROVED", message, status_code=400)


# --- Application config errors ---


class NotApplicationOwnerError(DomainError):
    def __init__(self, message: str = "Not the application owner") -> None:
        super().__init__("NOT_APPLICATION_OWNER", message, status_code=403)
