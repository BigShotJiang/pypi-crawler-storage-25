"""HTTP routes for the affiliate_referrals domain.

Provides THREE routers:

1. ``affiliates_router`` -- Affiliate management under ``/affiliates``
2. ``referrals_router`` -- Referral tracking under ``/referrals``
3. ``affiliate_admin_router`` -- Admin payout management under ``/admin/payouts``

The response envelope ``{ success, data, error, metadata }`` is
applied automatically by ``ResponseEnvelopeMiddleware`` -- handlers
return the raw *data* portion only.
"""

from __future__ import annotations

import logging
from uuid import UUID

from fastapi import APIRouter, Query, Request

from ...middleware.spaps_deps import (
    AdminUser,
    Application,
    CurrentUser,
    DbSession,
)
from . import service
from .schemas import (
    AttributeReferralRequest,
    CompletePayoutRequest,
    DenyPayoutRequest,
    FailPayoutRequest,
    ProcessCommissionRequest,
    RecordClickRequest,
    RegisterAffiliateRequest,
    RequestPayoutRequest,
    UpdateAffiliateConfigRequest,
    UpdateAffiliateRequest,
)
from ..errors import ValidationError

logger = logging.getLogger(__name__)


# ===========================================================================
# Affiliates Router
# ===========================================================================

affiliates_router = APIRouter(prefix="/affiliates", tags=["affiliates"])


@affiliates_router.post("", status_code=201)
async def register_affiliate(
    body: RegisterAffiliateRequest,
    db: DbSession,
    application: Application,
    user: CurrentUser,
):
    """Register as an affiliate with a vanity slug."""
    result = await service.register_affiliate(
        db,
        user_id=UUID(str(user.id)),
        affiliate_type=body.affiliate_type,
        agent_id=UUID(body.agent_id) if body.agent_id else None,
        slug=body.slug,
        payout_wallet_address=body.payout_wallet_address,
        payout_chain=body.payout_chain,
    )
    return result


@affiliates_router.get("/me")
async def get_my_affiliate(
    db: DbSession,
    application: Application,
    user: CurrentUser,
    agent_id: str | None = Query(default=None),
):
    """Get my affiliate profile."""
    result = await service.get_my_affiliate(
        db,
        user_id=UUID(str(user.id)),
        agent_id=UUID(agent_id) if agent_id else None,
    )
    return result


@affiliates_router.put("/me")
async def update_my_affiliate(
    body: UpdateAffiliateRequest,
    db: DbSession,
    application: Application,
    user: CurrentUser,
    agent_id: str | None = Query(default=None),
):
    """Update my affiliate profile."""
    result = await service.update_my_affiliate(
        db,
        user_id=UUID(str(user.id)),
        agent_id=UUID(agent_id) if agent_id else None,
        slug=body.slug,
        payout_wallet_address=body.payout_wallet_address,
        payout_chain=body.payout_chain,
        is_active=body.is_active,
    )
    return result


# ---------------------------------------------------------------------------
# Commission / Earnings sub-routes
# ---------------------------------------------------------------------------


@affiliates_router.get("/me/commissions")
async def get_commissions(
    db: DbSession,
    application: Application,
    user: CurrentUser,
    agent_id: str | None = Query(default=None),
    level: int | None = Query(default=None, ge=1, le=3),
    since: str | None = Query(default=None),
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
):
    """Get commission history."""
    result = await service.get_commissions(
        db,
        user_id=UUID(str(user.id)),
        agent_id=UUID(agent_id) if agent_id else None,
        level=level,
        since=since,
        limit=limit,
        offset=offset,
    )
    return result


@affiliates_router.get("/me/referrals")
async def get_my_referrals(
    db: DbSession,
    application: Application,
    user: CurrentUser,
    agent_id: str | None = Query(default=None),
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
):
    """Get direct referrals."""
    result = await service.get_my_referrals(
        db,
        user_id=UUID(str(user.id)),
        agent_id=UUID(agent_id) if agent_id else None,
        limit=limit,
        offset=offset,
    )
    return result


@affiliates_router.get("/me/tree")
async def get_referral_tree(
    db: DbSession,
    application: Application,
    user: CurrentUser,
    agent_id: str | None = Query(default=None),
):
    """Get referral tree summary (3 levels)."""
    result = await service.get_referral_tree(
        db,
        user_id=UUID(str(user.id)),
        agent_id=UUID(agent_id) if agent_id else None,
    )
    return result


# ---------------------------------------------------------------------------
# Payout sub-routes
# ---------------------------------------------------------------------------


@affiliates_router.post("/me/payouts", status_code=201)
async def request_payout(
    body: RequestPayoutRequest,
    db: DbSession,
    application: Application,
    user: CurrentUser,
):
    """Request USDC payout."""
    result = await service.request_payout(
        db,
        user_id=UUID(str(user.id)),
        agent_id=UUID(body.agent_id) if body.agent_id else None,
        amount_cents=body.amount_cents,
        application_id=UUID(str(application.id)),
    )
    return result


@affiliates_router.get("/me/payouts")
async def get_my_payouts(
    db: DbSession,
    application: Application,
    user: CurrentUser,
    agent_id: str | None = Query(default=None),
    status: str | None = Query(default=None),
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
):
    """Get payout history."""
    result = await service.get_my_payouts(
        db,
        user_id=UUID(str(user.id)),
        agent_id=UUID(agent_id) if agent_id else None,
        status=status,
        limit=limit,
        offset=offset,
    )
    return result


# ===========================================================================
# Referrals Router
# ===========================================================================

referrals_router = APIRouter(prefix="/referrals", tags=["referrals"])


@referrals_router.post("/click", status_code=201)
async def record_click(
    body: RecordClickRequest,
    request: Request,
    db: DbSession,
    application: Application,
):
    """Record a referral link click (API key only, no JWT)."""
    try:
        request_application_id = UUID(body.application_id)
    except ValueError as exc:
        raise ValidationError("application_id must be a valid UUID") from exc

    if request_application_id != UUID(str(application.id)):
        raise ValidationError("application_id must match API key application")

    # Extract IP from request
    ip_address = request.client.host if request.client else "unknown"
    user_agent = request.headers.get("User-Agent")

    result = await service.record_click(
        db,
        slug=body.slug,
        application_id=request_application_id,
        ip_address=ip_address,
        user_agent=user_agent,
    )
    return result


@referrals_router.post("/attribute", status_code=201)
async def attribute_referral(
    body: AttributeReferralRequest,
    db: DbSession,
    application: Application,
    user: CurrentUser,
):
    """Attribute a signup to a referral."""
    result = await service.attribute_referral(
        db,
        referred_entity_type=body.referred_entity_type,
        referred_entity_id=UUID(body.referred_entity_id),
        click_id=UUID(body.click_id) if body.click_id else None,
        slug=body.slug,
        application_id=UUID(str(application.id)),
    )
    return result


# ===========================================================================
# Admin Payout Router
# ===========================================================================

affiliate_admin_router = APIRouter(prefix="/admin/payouts", tags=["admin-payouts"])


@affiliate_admin_router.get("")
async def list_admin_payouts(
    db: DbSession,
    application: Application,
    user: AdminUser,
    status: str | None = Query(default="requested"),
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
):
    """List payout queue (admin only)."""
    result = await service.list_admin_payouts(
        db,
        status=status,
        limit=limit,
        offset=offset,
    )
    return result


@affiliate_admin_router.post("/{payout_id}/approve")
async def approve_payout(
    payout_id: str,
    db: DbSession,
    application: Application,
    user: AdminUser,
):
    """Approve a payout request (admin only)."""
    result = await service.approve_payout(
        db,
        payout_id=UUID(payout_id),
        admin_user_id=UUID(str(user.id)),
    )
    return result


@affiliate_admin_router.post("/{payout_id}/complete")
async def complete_payout(
    payout_id: str,
    body: CompletePayoutRequest,
    db: DbSession,
    application: Application,
    user: AdminUser,
):
    """Mark payout as completed with tx_hash (admin only)."""
    result = await service.complete_payout(
        db,
        payout_id=UUID(payout_id),
        tx_hash=body.tx_hash,
        application_id=UUID(str(application.id)),
    )
    return result


@affiliate_admin_router.post("/{payout_id}/deny")
async def deny_payout(
    payout_id: str,
    body: DenyPayoutRequest,
    db: DbSession,
    application: Application,
    user: AdminUser,
):
    """Deny a payout request (admin only)."""
    result = await service.deny_payout(
        db,
        payout_id=UUID(payout_id),
        reason=body.reason,
    )
    return result


@affiliate_admin_router.post("/{payout_id}/fail")
async def fail_payout(
    payout_id: str,
    body: FailPayoutRequest,
    db: DbSession,
    application: Application,
    user: AdminUser,
):
    """Mark payout as failed (admin only)."""
    result = await service.fail_payout(
        db,
        payout_id=UUID(payout_id),
        reason=body.reason,
    )
    return result


# ===========================================================================
# Application Affiliate Config Router
# ===========================================================================

affiliate_config_router = APIRouter(prefix="/applications", tags=["affiliate-config"])


@affiliate_config_router.put("/{application_id}/affiliate-config")
async def update_affiliate_config(
    application_id: str,
    body: UpdateAffiliateConfigRequest,
    db: DbSession,
    application: Application,
    user: CurrentUser,
):
    """Configure affiliate rates for an application."""
    result = await service.update_affiliate_config(
        db,
        application_id=UUID(application_id),
        user_id=UUID(str(user.id)),
        is_admin=getattr(user, "is_admin", False),
        enabled=body.enabled,
        l1_rate_bps=body.l1_rate_bps,
        l2_rate_bps=body.l2_rate_bps,
        l3_rate_bps=body.l3_rate_bps,
        attribution_window_days=body.attribution_window_days,
        min_payout_cents=body.min_payout_cents,
    )
    return result


@affiliate_config_router.get("/{application_id}/affiliate-config")
async def get_affiliate_config(
    application_id: str,
    db: DbSession,
    application: Application,
):
    """Read affiliate config for an application."""
    result = await service.get_affiliate_config(
        db,
        application_id=UUID(application_id),
    )
    return result


# ===========================================================================
# Internal Commission Processing Router
# ===========================================================================

internal_commissions_router = APIRouter(
    prefix="/internal/commissions", tags=["internal-commissions"]
)


@internal_commissions_router.post("/process")
async def process_commissions(
    body: ProcessCommissionRequest,
    request: Request,
    db: DbSession,
):
    """Process payment event for affiliate commissions.

    Internal endpoint — authenticated via X-Service-Secret header.
    """
    from ...domains.errors import ForbiddenError

    settings = request.app.state.settings
    service_secret = settings.internal_service_secret

    # Validate X-Service-Secret header
    provided_secret = request.headers.get("X-Service-Secret")
    if not service_secret or provided_secret != service_secret:
        raise ForbiddenError("Invalid service credentials")

    result = await service.process_commissions(
        db,
        payer_entity_type=body.payer_entity_type,
        payer_entity_id=UUID(body.payer_entity_id),
        payment_amount_cents=body.payment_amount_cents,
        payment_event_type=body.payment_event_type,
        payment_reference=body.payment_reference,
        application_id=UUID(body.application_id),
    )
    return result
