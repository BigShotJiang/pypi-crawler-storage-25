"""Database operations for the affiliate_referrals domain.

Pure SQLAlchemy async repository -- no FastAPI imports.
All functions accept an ``AsyncSession`` as the first positional argument.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime, timedelta
from typing import Any
from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from .models import (
    Affiliate,
    AffiliateCommission,
    AffiliatePayout,
    AppAffiliateConfig,
    ReferralAttribution,
    ReferralClick,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Affiliate lookups
# ---------------------------------------------------------------------------


async def get_affiliate_by_id(
    db: AsyncSession,
    affiliate_id: UUID,
) -> Affiliate | None:
    stmt = select(Affiliate).where(Affiliate.id == affiliate_id)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def get_affiliate_by_slug(
    db: AsyncSession,
    slug: str,
) -> Affiliate | None:
    stmt = select(Affiliate).where(Affiliate.slug == slug)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def get_affiliate_by_user_id(
    db: AsyncSession,
    user_id: UUID,
) -> Affiliate | None:
    stmt = select(Affiliate).where(
        Affiliate.affiliate_type == "user",
        Affiliate.user_id == user_id,
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def get_affiliate_by_agent_id(
    db: AsyncSession,
    agent_id: UUID,
) -> Affiliate | None:
    stmt = select(Affiliate).where(
        Affiliate.affiliate_type == "agent",
        Affiliate.agent_id == agent_id,
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def create_affiliate(
    db: AsyncSession,
    *,
    affiliate_type: str,
    user_id: UUID | None = None,
    agent_id: UUID | None = None,
    slug: str,
    referred_by_affiliate_id: UUID | None = None,
    referral_depth: int = 0,
    payout_wallet_address: str | None = None,
    payout_chain: str | None = None,
) -> Affiliate:
    affiliate = Affiliate(
        affiliate_type=affiliate_type,
        user_id=user_id,
        agent_id=agent_id,
        slug=slug,
        referred_by_affiliate_id=referred_by_affiliate_id,
        referral_depth=referral_depth,
        payout_wallet_address=payout_wallet_address,
        payout_chain=payout_chain,
    )
    db.add(affiliate)
    await db.flush()
    await db.refresh(affiliate)
    return affiliate


async def update_affiliate(
    db: AsyncSession,
    affiliate: Affiliate,
    **fields: Any,
) -> Affiliate:
    for key, value in fields.items():
        if value is not None:
            setattr(affiliate, key, value)
    affiliate.updated_at = datetime.now(UTC)
    await db.flush()
    await db.refresh(affiliate)
    return affiliate


# ---------------------------------------------------------------------------
# Referral click operations
# ---------------------------------------------------------------------------


async def get_recent_click(
    db: AsyncSession,
    affiliate_id: UUID,
    ip_hash: str,
) -> ReferralClick | None:
    """Check for duplicate click within 24 hours."""
    cutoff = datetime.now(UTC) - timedelta(hours=24)
    stmt = select(ReferralClick).where(
        ReferralClick.affiliate_id == affiliate_id,
        ReferralClick.ip_hash == ip_hash,
        ReferralClick.clicked_at >= cutoff,
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def create_click(
    db: AsyncSession,
    *,
    affiliate_id: UUID,
    application_id: UUID,
    ip_hash: str,
    user_agent: str | None = None,
    expires_at: datetime,
) -> ReferralClick:
    click = ReferralClick(
        affiliate_id=affiliate_id,
        application_id=application_id,
        ip_hash=ip_hash,
        user_agent=user_agent,
        expires_at=expires_at,
    )
    db.add(click)
    await db.flush()
    await db.refresh(click)
    return click


async def get_click_by_id(
    db: AsyncSession,
    click_id: UUID,
) -> ReferralClick | None:
    stmt = select(ReferralClick).where(ReferralClick.id == click_id)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def update_click_conversion(
    db: AsyncSession,
    click: ReferralClick,
    *,
    converted_entity_type: str,
    converted_entity_id: UUID,
) -> None:
    click.converted_at = datetime.now(UTC)
    click.converted_entity_type = converted_entity_type
    click.converted_entity_id = converted_entity_id
    await db.flush()


# ---------------------------------------------------------------------------
# Referral attribution operations
# ---------------------------------------------------------------------------


async def get_attribution_by_entity(
    db: AsyncSession,
    entity_type: str,
    entity_id: UUID,
) -> ReferralAttribution | None:
    stmt = select(ReferralAttribution).where(
        ReferralAttribution.referred_entity_type == entity_type,
        ReferralAttribution.referred_entity_id == entity_id,
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def create_attribution(
    db: AsyncSession,
    *,
    referred_entity_type: str,
    referred_entity_id: UUID,
    affiliate_id: UUID,
    referral_click_id: UUID | None = None,
    application_id: UUID,
) -> ReferralAttribution:
    attribution = ReferralAttribution(
        referred_entity_type=referred_entity_type,
        referred_entity_id=referred_entity_id,
        affiliate_id=affiliate_id,
        referral_click_id=referral_click_id,
        application_id=application_id,
    )
    db.add(attribution)
    await db.flush()
    await db.refresh(attribution)
    return attribution


# ---------------------------------------------------------------------------
# Commission operations
# ---------------------------------------------------------------------------


async def get_commission_by_reference(
    db: AsyncSession,
    payment_reference: str,
    affiliate_id: UUID,
    commission_level: int,
) -> AffiliateCommission | None:
    """Check idempotency — has this commission already been created?"""
    stmt = select(AffiliateCommission).where(
        AffiliateCommission.payment_reference == payment_reference,
        AffiliateCommission.affiliate_id == affiliate_id,
        AffiliateCommission.commission_level == commission_level,
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def create_commission(
    db: AsyncSession,
    *,
    affiliate_id: UUID,
    source_entity_type: str,
    source_entity_id: UUID,
    payment_event_type: str,
    payment_amount_cents: int,
    commission_level: int,
    commission_rate_bps: int,
    commission_amount_cents: int,
    application_id: UUID,
    payment_reference: str,
) -> AffiliateCommission:
    commission = AffiliateCommission(
        affiliate_id=affiliate_id,
        source_entity_type=source_entity_type,
        source_entity_id=source_entity_id,
        payment_event_type=payment_event_type,
        payment_amount_cents=payment_amount_cents,
        commission_level=commission_level,
        commission_rate_bps=commission_rate_bps,
        commission_amount_cents=commission_amount_cents,
        application_id=application_id,
        payment_reference=payment_reference,
    )
    db.add(commission)
    await db.flush()
    await db.refresh(commission)
    return commission


async def credit_affiliate_balance(
    db: AsyncSession,
    affiliate: Affiliate,
    amount_cents: int,
) -> None:
    """Add commission amount to affiliate balance."""
    affiliate.credit_balance_cents += amount_cents
    affiliate.lifetime_earned_cents += amount_cents
    await db.flush()


async def list_commissions(
    db: AsyncSession,
    affiliate_id: UUID,
    *,
    level: int | None = None,
    since: str | None = None,
    limit: int = 20,
    offset: int = 0,
) -> list[AffiliateCommission]:
    stmt = select(AffiliateCommission).where(
        AffiliateCommission.affiliate_id == affiliate_id
    )
    if level is not None:
        stmt = stmt.where(AffiliateCommission.commission_level == level)
    if since is not None:
        stmt = stmt.where(AffiliateCommission.credited_at >= since)
    stmt = stmt.order_by(AffiliateCommission.credited_at.desc()).limit(limit).offset(offset)
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def count_commissions(
    db: AsyncSession,
    affiliate_id: UUID,
    *,
    level: int | None = None,
    since: str | None = None,
) -> int:
    stmt = select(func.count()).select_from(AffiliateCommission).where(
        AffiliateCommission.affiliate_id == affiliate_id
    )
    if level is not None:
        stmt = stmt.where(AffiliateCommission.commission_level == level)
    if since is not None:
        stmt = stmt.where(AffiliateCommission.credited_at >= since)
    result = await db.execute(stmt)
    return result.scalar() or 0


async def sum_commissions_by_level(
    db: AsyncSession,
    affiliate_id: UUID,
) -> dict[int, int]:
    """Sum commission_amount_cents grouped by level."""
    stmt = (
        select(
            AffiliateCommission.commission_level,
            func.coalesce(func.sum(AffiliateCommission.commission_amount_cents), 0),
        )
        .where(AffiliateCommission.affiliate_id == affiliate_id)
        .group_by(AffiliateCommission.commission_level)
    )
    result = await db.execute(stmt)
    return dict(result.all())  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# Referral tree / direct referrals
# ---------------------------------------------------------------------------


async def list_direct_referrals(
    db: AsyncSession,
    affiliate_id: UUID,
    *,
    limit: int = 20,
    offset: int = 0,
) -> list[Affiliate]:
    """List affiliates directly referred by this affiliate."""
    stmt = (
        select(Affiliate)
        .where(Affiliate.referred_by_affiliate_id == affiliate_id)
        .order_by(Affiliate.created_at.desc())
        .limit(limit)
        .offset(offset)
    )
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def count_direct_referrals(
    db: AsyncSession,
    affiliate_id: UUID,
) -> int:
    stmt = select(func.count()).select_from(Affiliate).where(
        Affiliate.referred_by_affiliate_id == affiliate_id
    )
    result = await db.execute(stmt)
    return result.scalar() or 0


async def get_referral_tree_stats(
    db: AsyncSession,
    affiliate_id: UUID,
) -> list[dict[str, Any]]:
    """Get referral tree statistics by level (up to 3 levels deep).

    Returns counts and earnings per level.
    """
    levels = []

    # Level 1: direct referrals
    l1_affiliates = await _get_referral_ids_at_depth(db, [affiliate_id])
    if l1_affiliates:
        l1_stats = await _level_stats(db, affiliate_id, l1_affiliates, 1)
        levels.append(l1_stats)

        # Level 2: referrals of L1
        l2_affiliates = await _get_referral_ids_at_depth(db, l1_affiliates)
        if l2_affiliates:
            l2_stats = await _level_stats(db, affiliate_id, l2_affiliates, 2)
            levels.append(l2_stats)

            # Level 3: referrals of L2
            l3_affiliates = await _get_referral_ids_at_depth(db, l2_affiliates)
            if l3_affiliates:
                l3_stats = await _level_stats(db, affiliate_id, l3_affiliates, 3)
                levels.append(l3_stats)

    return levels


async def _get_referral_ids_at_depth(
    db: AsyncSession,
    parent_ids: list[UUID],
) -> list[UUID]:
    """Get affiliate IDs that are directly referred by any of the parent IDs."""
    if not parent_ids:
        return []
    stmt = select(Affiliate.id).where(
        Affiliate.referred_by_affiliate_id.in_(parent_ids)
    )
    result = await db.execute(stmt)
    return [row[0] for row in result.all()]


async def _level_stats(
    db: AsyncSession,
    root_affiliate_id: UUID,
    affiliate_ids: list[UUID],
    level: int,
) -> dict[str, Any]:
    """Compute stats for a level of the referral tree."""
    # Count active
    active_stmt = select(func.count()).select_from(Affiliate).where(
        Affiliate.id.in_(affiliate_ids),
        Affiliate.is_active == True,  # noqa: E712
    )
    active_result = await db.execute(active_stmt)
    active_count = active_result.scalar() or 0

    # Sum earnings from this level's commissions
    earnings_stmt = (
        select(func.coalesce(func.sum(AffiliateCommission.commission_amount_cents), 0))
        .where(
            AffiliateCommission.affiliate_id == root_affiliate_id,
            AffiliateCommission.commission_level == level,
        )
    )
    earnings_result = await db.execute(earnings_stmt)
    total_earned = earnings_result.scalar() or 0

    return {
        "level": level,
        "referral_count": len(affiliate_ids),
        "total_earned_cents": total_earned,
        "active_count": active_count,
    }


# ---------------------------------------------------------------------------
# Payout operations
# ---------------------------------------------------------------------------


async def get_active_payout(
    db: AsyncSession,
    affiliate_id: UUID,
) -> AffiliatePayout | None:
    """Check for non-terminal payout (requested/approved)."""
    stmt = select(AffiliatePayout).where(
        AffiliatePayout.affiliate_id == affiliate_id,
        AffiliatePayout.status.in_(["requested", "approved"]),
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def create_payout(
    db: AsyncSession,
    *,
    affiliate_id: UUID,
    amount_cents: int,
    wallet_address: str,
    chain: str,
) -> AffiliatePayout:
    payout = AffiliatePayout(
        affiliate_id=affiliate_id,
        amount_cents=amount_cents,
        wallet_address=wallet_address,
        chain=chain,
    )
    db.add(payout)
    await db.flush()
    await db.refresh(payout)
    return payout


async def get_payout_by_id(
    db: AsyncSession,
    payout_id: UUID,
) -> AffiliatePayout | None:
    stmt = select(AffiliatePayout).where(AffiliatePayout.id == payout_id)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def update_payout(
    db: AsyncSession,
    payout: AffiliatePayout,
    **fields: Any,
) -> AffiliatePayout:
    for key, value in fields.items():
        setattr(payout, key, value)
    await db.flush()
    await db.refresh(payout)
    return payout


async def list_payouts(
    db: AsyncSession,
    *,
    affiliate_id: UUID | None = None,
    status: str | None = None,
    limit: int = 20,
    offset: int = 0,
) -> list[AffiliatePayout]:
    stmt = select(AffiliatePayout)
    if affiliate_id is not None:
        stmt = stmt.where(AffiliatePayout.affiliate_id == affiliate_id)
    if status is not None:
        stmt = stmt.where(AffiliatePayout.status == status)
    stmt = stmt.order_by(AffiliatePayout.requested_at.desc()).limit(limit).offset(offset)
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def count_payouts(
    db: AsyncSession,
    *,
    affiliate_id: UUID | None = None,
    status: str | None = None,
) -> int:
    stmt = select(func.count()).select_from(AffiliatePayout)
    if affiliate_id is not None:
        stmt = stmt.where(AffiliatePayout.affiliate_id == affiliate_id)
    if status is not None:
        stmt = stmt.where(AffiliatePayout.status == status)
    result = await db.execute(stmt)
    return result.scalar() or 0


async def refund_payout_to_balance(
    db: AsyncSession,
    payout: AffiliatePayout,
) -> None:
    """Return payout amount to affiliate's credit balance and reverse lifetime counter."""
    affiliate = await get_affiliate_by_id(db, payout.affiliate_id)
    if affiliate:
        affiliate.credit_balance_cents += payout.amount_cents
        affiliate.lifetime_paid_out_cents -= payout.amount_cents
        await db.flush()


# ---------------------------------------------------------------------------
# App affiliate config
# ---------------------------------------------------------------------------


async def get_app_config(
    db: AsyncSession,
    application_id: UUID,
) -> AppAffiliateConfig | None:
    stmt = select(AppAffiliateConfig).where(
        AppAffiliateConfig.application_id == application_id
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def upsert_app_config(
    db: AsyncSession,
    application_id: UUID,
    *,
    enabled: bool,
    l1_rate_bps: int,
    l2_rate_bps: int,
    l3_rate_bps: int,
    attribution_window_days: int,
    min_payout_cents: int,
) -> AppAffiliateConfig:
    existing = await get_app_config(db, application_id)
    if existing:
        existing.enabled = enabled
        existing.l1_rate_bps = l1_rate_bps
        existing.l2_rate_bps = l2_rate_bps
        existing.l3_rate_bps = l3_rate_bps
        existing.attribution_window_days = attribution_window_days
        existing.min_payout_cents = min_payout_cents
        existing.updated_at = datetime.now(UTC)
        await db.flush()
        await db.refresh(existing)
        return existing
    else:
        config = AppAffiliateConfig(
            application_id=application_id,
            enabled=enabled,
            l1_rate_bps=l1_rate_bps,
            l2_rate_bps=l2_rate_bps,
            l3_rate_bps=l3_rate_bps,
            attribution_window_days=attribution_window_days,
            min_payout_cents=min_payout_cents,
        )
        db.add(config)
        await db.flush()
        await db.refresh(config)
        return config


# ---------------------------------------------------------------------------
# Agent/application lookups (cross-domain)
# ---------------------------------------------------------------------------


async def get_agent_by_id(
    db: AsyncSession,
    agent_id: UUID,
) -> Any:
    from ..agent_approvals.models import Agent

    stmt = select(Agent).where(Agent.id == agent_id)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def get_application_by_id(
    db: AsyncSession,
    application_id: UUID,
) -> Any:
    from ..applications.models import Application

    stmt = select(Application).where(Application.id == application_id)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def get_application_owner_id(
    db: AsyncSession,
    application_id: UUID,
) -> UUID | None:
    """Get the owner_user_id for an application."""
    app = await get_application_by_id(db, application_id)
    if app and hasattr(app, "owner_user_id"):
        return app.owner_user_id
    return None


async def get_affiliate_with_slug_info(
    db: AsyncSession,
    affiliate_id: UUID,
) -> dict[str, Any] | None:
    """Get affiliate slug for enrichment of referral lists."""
    affiliate = await get_affiliate_by_id(db, affiliate_id)
    if not affiliate:
        return None
    return {
        "affiliate_id": str(affiliate.id),
        "slug": affiliate.slug,
    }


async def get_lifetime_revenue_for_affiliates(
    db: AsyncSession,
    affiliate_ids: list[UUID],
) -> dict[UUID, int]:
    """Sum payment amounts attributed to each affiliate's referrals (for list enrichment)."""
    if not affiliate_ids:
        return {}
    stmt = (
        select(
            AffiliateCommission.affiliate_id,
            func.coalesce(func.sum(AffiliateCommission.commission_amount_cents), 0),
        )
        .where(
            AffiliateCommission.affiliate_id.in_(affiliate_ids),
            AffiliateCommission.commission_level == 1,
        )
        .group_by(AffiliateCommission.affiliate_id)
    )
    result = await db.execute(stmt)
    return dict(result.all())  # type: ignore[arg-type]
