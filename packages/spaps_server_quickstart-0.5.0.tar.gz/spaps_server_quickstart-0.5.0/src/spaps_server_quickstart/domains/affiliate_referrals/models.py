"""SQLAlchemy models for the affiliate_referrals domain.

Six tables:
- affiliates: Polymorphic affiliate records (user or agent)
- referral_clicks: Click tracking with 30-day TTL
- referral_attributions: Signup → affiliate mapping
- affiliate_commissions: Commission records per payment event
- affiliate_payouts: USDC payout requests and lifecycle
- app_affiliate_config: Per-application commission rate configuration
"""

from __future__ import annotations

from datetime import datetime
from uuid import UUID, uuid4

from sqlalchemy import (
    BigInteger,
    Boolean,
    CheckConstraint,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    String,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column

from .._db import Base, PGUUID


class Affiliate(Base):
    """Polymorphic affiliate record — either a user or an agent."""

    __tablename__ = "affiliates"

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    affiliate_type: Mapped[str] = mapped_column(
        String(10), nullable=False
    )
    user_id: Mapped[UUID | None] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=True,
    )
    agent_id: Mapped[UUID | None] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("agents.id", ondelete="CASCADE"),
        nullable=True,
    )
    slug: Mapped[str] = mapped_column(
        String(50), unique=True, nullable=False
    )
    referred_by_affiliate_id: Mapped[UUID | None] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("affiliates.id", ondelete="SET NULL"),
        nullable=True,
    )
    referral_depth: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0
    )
    is_active: Mapped[bool] = mapped_column(
        Boolean, server_default="true", default=True
    )
    payout_wallet_address: Mapped[str | None] = mapped_column(
        String(200), nullable=True
    )
    payout_chain: Mapped[str | None] = mapped_column(
        String(50), nullable=True
    )
    credit_balance_cents: Mapped[int] = mapped_column(
        BigInteger, nullable=False, default=0
    )
    lifetime_earned_cents: Mapped[int] = mapped_column(
        BigInteger, nullable=False, default=0
    )
    lifetime_paid_out_cents: Mapped[int] = mapped_column(
        BigInteger, nullable=False, default=0
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    __table_args__ = (
        CheckConstraint(
            "affiliate_type IN ('user', 'agent')",
            name="ck_affiliates_type",
        ),
        CheckConstraint(
            "(affiliate_type = 'user' AND user_id IS NOT NULL AND agent_id IS NULL) "
            "OR (affiliate_type = 'agent' AND agent_id IS NOT NULL AND user_id IS NULL)",
            name="ck_affiliates_exactly_one_fk",
        ),
        Index(
            "uq_affiliates_user",
            "user_id",
            unique=True,
            postgresql_where="user_id IS NOT NULL",
        ),
        Index(
            "uq_affiliates_agent",
            "agent_id",
            unique=True,
            postgresql_where="agent_id IS NOT NULL",
        ),
        Index("ix_affiliates_referred_by", "referred_by_affiliate_id"),
    )

    def __repr__(self) -> str:
        return f"<Affiliate slug={self.slug!r} type={self.affiliate_type!r}>"


class ReferralClick(Base):
    """Tracks referral link clicks with a 30-day attribution window."""

    __tablename__ = "referral_clicks"

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    affiliate_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("affiliates.id", ondelete="CASCADE"),
        nullable=False,
    )
    application_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("applications.id", ondelete="CASCADE"),
        nullable=False,
    )
    clicked_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    ip_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    user_agent: Mapped[str | None] = mapped_column(String(500), nullable=True)
    expires_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    converted_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    converted_entity_type: Mapped[str | None] = mapped_column(
        String(10), nullable=True
    )
    converted_entity_id: Mapped[UUID | None] = mapped_column(
        PGUUID(as_uuid=True), nullable=True
    )

    __table_args__ = (
        Index("ix_referral_clicks_affiliate", "affiliate_id"),
        Index("ix_referral_clicks_app", "application_id"),
        Index("ix_referral_clicks_ip_slug", "ip_hash", "affiliate_id"),
        Index(
            "ix_referral_clicks_expires",
            "expires_at",
            postgresql_where="converted_at IS NULL",
        ),
    )

    def __repr__(self) -> str:
        return f"<ReferralClick affiliate={self.affiliate_id!r}>"


class ReferralAttribution(Base):
    """Links a signed-up entity to the affiliate that referred them."""

    __tablename__ = "referral_attributions"

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    referred_entity_type: Mapped[str] = mapped_column(
        String(10), nullable=False
    )
    referred_entity_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), nullable=False
    )
    affiliate_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("affiliates.id", ondelete="CASCADE"),
        nullable=False,
    )
    referral_click_id: Mapped[UUID | None] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("referral_clicks.id", ondelete="SET NULL"),
        nullable=True,
    )
    application_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("applications.id", ondelete="CASCADE"),
        nullable=False,
    )
    attributed_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    __table_args__ = (
        CheckConstraint(
            "referred_entity_type IN ('user', 'agent')",
            name="ck_referral_attributions_type",
        ),
        UniqueConstraint(
            "referred_entity_type",
            "referred_entity_id",
            name="uq_referral_attributions_entity",
        ),
        Index("ix_referral_attributions_affiliate", "affiliate_id"),
        Index(
            "ix_referral_attributions_entity",
            "referred_entity_type",
            "referred_entity_id",
        ),
    )

    def __repr__(self) -> str:
        return f"<ReferralAttribution entity={self.referred_entity_type!r}:{self.referred_entity_id!r}>"


class AffiliateCommission(Base):
    """Commission earned by an affiliate from a referred payment."""

    __tablename__ = "affiliate_commissions"

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    affiliate_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("affiliates.id", ondelete="CASCADE"),
        nullable=False,
    )
    source_entity_type: Mapped[str] = mapped_column(
        String(10), nullable=False
    )
    source_entity_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), nullable=False
    )
    payment_event_type: Mapped[str] = mapped_column(
        String(50), nullable=False
    )
    payment_amount_cents: Mapped[int] = mapped_column(
        BigInteger, nullable=False
    )
    commission_level: Mapped[int] = mapped_column(
        Integer, nullable=False
    )
    commission_rate_bps: Mapped[int] = mapped_column(
        Integer, nullable=False
    )
    commission_amount_cents: Mapped[int] = mapped_column(
        BigInteger, nullable=False
    )
    application_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("applications.id", ondelete="CASCADE"),
        nullable=False,
    )
    credited_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    payment_reference: Mapped[str] = mapped_column(
        String(500), nullable=False
    )

    __table_args__ = (
        CheckConstraint(
            "commission_level IN (1, 2, 3)",
            name="ck_affiliate_commissions_level",
        ),
        UniqueConstraint(
            "payment_reference",
            "affiliate_id",
            "commission_level",
            name="uq_affiliate_commissions_idempotent",
        ),
        Index("ix_affiliate_commissions_affiliate", "affiliate_id"),
        Index("ix_affiliate_commissions_app", "application_id"),
        Index("ix_affiliate_commissions_credited_at", "credited_at"),
    )

    def __repr__(self) -> str:
        return f"<AffiliateCommission level={self.commission_level} amount={self.commission_amount_cents}>"


class AffiliatePayout(Base):
    """USDC payout request and lifecycle tracking."""

    __tablename__ = "affiliate_payouts"

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    affiliate_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("affiliates.id", ondelete="CASCADE"),
        nullable=False,
    )
    amount_cents: Mapped[int] = mapped_column(
        BigInteger, nullable=False
    )
    payout_method: Mapped[str] = mapped_column(
        String(20), nullable=False, default="usdc_onchain"
    )
    wallet_address: Mapped[str] = mapped_column(
        String(200), nullable=False
    )
    chain: Mapped[str] = mapped_column(
        String(50), nullable=False
    )
    tx_hash: Mapped[str | None] = mapped_column(
        String(200), nullable=True
    )
    status: Mapped[str] = mapped_column(
        String(20), nullable=False, default="requested"
    )
    requested_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    approved_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    completed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    approved_by_user_id: Mapped[UUID | None] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("users.id", ondelete="SET NULL"),
        nullable=True,
    )
    denial_reason: Mapped[str | None] = mapped_column(
        String(500), nullable=True
    )
    failure_reason: Mapped[str | None] = mapped_column(
        String(500), nullable=True
    )

    __table_args__ = (
        CheckConstraint(
            "status IN ('requested', 'approved', 'completed', 'denied', 'failed')",
            name="ck_affiliate_payouts_status",
        ),
        Index("ix_affiliate_payouts_affiliate", "affiliate_id"),
        Index(
            "ix_affiliate_payouts_status",
            "status",
            postgresql_where="status IN ('requested', 'approved')",
        ),
    )

    def __repr__(self) -> str:
        return f"<AffiliatePayout status={self.status!r} amount={self.amount_cents}>"


class AppAffiliateConfig(Base):
    """Per-application affiliate commission rate configuration."""

    __tablename__ = "app_affiliate_config"

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    application_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("applications.id", ondelete="CASCADE"),
        unique=True,
        nullable=False,
    )
    enabled: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=True
    )
    l1_rate_bps: Mapped[int] = mapped_column(
        Integer, nullable=False, default=1000
    )
    l2_rate_bps: Mapped[int] = mapped_column(
        Integer, nullable=False, default=500
    )
    l3_rate_bps: Mapped[int] = mapped_column(
        Integer, nullable=False, default=200
    )
    attribution_window_days: Mapped[int] = mapped_column(
        Integer, nullable=False, default=30
    )
    min_payout_cents: Mapped[int] = mapped_column(
        BigInteger, nullable=False, default=2500
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    __table_args__ = (
        CheckConstraint(
            "l1_rate_bps >= 0 AND l1_rate_bps <= 5000",
            name="ck_app_affiliate_config_l1",
        ),
        CheckConstraint(
            "l2_rate_bps >= 0 AND l2_rate_bps <= 5000",
            name="ck_app_affiliate_config_l2",
        ),
        CheckConstraint(
            "l3_rate_bps >= 0 AND l3_rate_bps <= 5000",
            name="ck_app_affiliate_config_l3",
        ),
        CheckConstraint(
            "l1_rate_bps + l2_rate_bps + l3_rate_bps <= 5000",
            name="ck_app_affiliate_config_total_rate",
        ),
    )

    def __repr__(self) -> str:
        return f"<AppAffiliateConfig app={self.application_id!r} enabled={self.enabled}>"
