"""Pydantic request/response schemas for affiliate_referrals endpoints.

These schemas define the *data* portion of each API response.
The standard response envelope ``{ success, data, error, metadata }``
is applied by middleware -- domain schemas never reference it.
"""

from __future__ import annotations

import re
from typing import Literal

from pydantic import BaseModel, Field, field_validator, model_validator

SLUG_PATTERN = re.compile(r"^[a-z][a-z0-9-]{2,49}$")
EVM_WALLET_PATTERN = re.compile(r"^0x[a-fA-F0-9]{40}$")
SOLANA_WALLET_PATTERN = re.compile(r"^[1-9A-HJ-NP-Za-km-z]{32,44}$")
CHAIN_ID_PATTERN = re.compile(r"^[a-z0-9]+:[A-Za-z0-9._-]+$")


def _is_valid_wallet_address(value: str) -> bool:
    return bool(
        EVM_WALLET_PATTERN.match(value) or SOLANA_WALLET_PATTERN.match(value)
    )


def _validate_wallet_and_chain_pair(
    payout_wallet_address: str | None,
    payout_chain: str | None,
) -> None:
    if payout_chain and not payout_wallet_address:
        msg = "payout_chain requires payout_wallet_address"
        raise ValueError(msg)
    if payout_wallet_address and not payout_chain:
        msg = "payout_wallet_address requires payout_chain"
        raise ValueError(msg)


# ---------------------------------------------------------------------------
# Affiliate schemas
# ---------------------------------------------------------------------------


class RegisterAffiliateRequest(BaseModel):
    """POST /api/affiliates request body."""

    slug: str = Field(..., min_length=3, max_length=50)
    affiliate_type: Literal["user", "agent"]
    agent_id: str | None = None
    payout_wallet_address: str | None = None
    payout_chain: str | None = None

    @field_validator("slug")
    @classmethod
    def _slug_format(cls, v: str) -> str:
        if not SLUG_PATTERN.match(v):
            msg = "Slug must be 3-50 chars, lowercase alphanumeric + hyphens, start with letter"
            raise ValueError(msg)
        return v

    @field_validator("payout_wallet_address")
    @classmethod
    def _wallet_address_format(cls, v: str | None) -> str | None:
        if v is not None and not _is_valid_wallet_address(v):
            msg = "payout_wallet_address must be a valid EVM or Solana address"
            raise ValueError(msg)
        return v

    @field_validator("payout_chain")
    @classmethod
    def _payout_chain_format(cls, v: str | None) -> str | None:
        if v and not CHAIN_ID_PATTERN.match(v):
            msg = "payout_chain must be a valid chain identifier (e.g. eip155:8453)"
            raise ValueError(msg)
        return v

    @model_validator(mode="after")
    def _validate_payout_fields(self) -> RegisterAffiliateRequest:
        _validate_wallet_and_chain_pair(
            payout_wallet_address=self.payout_wallet_address,
            payout_chain=self.payout_chain,
        )
        return self


class UpdateAffiliateRequest(BaseModel):
    """PUT /api/affiliates/me request body (partial update)."""

    slug: str | None = Field(default=None, min_length=3, max_length=50)
    payout_wallet_address: str | None = None
    payout_chain: str | None = None
    is_active: bool | None = None

    @field_validator("slug")
    @classmethod
    def _slug_format(cls, v: str | None) -> str | None:
        if v is not None and not SLUG_PATTERN.match(v):
            msg = "Slug must be 3-50 chars, lowercase alphanumeric + hyphens, start with letter"
            raise ValueError(msg)
        return v

    @field_validator("payout_wallet_address")
    @classmethod
    def _wallet_address_format(cls, v: str | None) -> str | None:
        if v is not None and not _is_valid_wallet_address(v):
            msg = "payout_wallet_address must be a valid EVM or Solana address"
            raise ValueError(msg)
        return v

    @field_validator("payout_chain")
    @classmethod
    def _payout_chain_format(cls, v: str | None) -> str | None:
        if v and not CHAIN_ID_PATTERN.match(v):
            msg = "payout_chain must be a valid chain identifier (e.g. eip155:8453)"
            raise ValueError(msg)
        return v

    @model_validator(mode="after")
    def _validate_payout_fields(self) -> UpdateAffiliateRequest:
        _validate_wallet_and_chain_pair(
            payout_wallet_address=self.payout_wallet_address,
            payout_chain=self.payout_chain,
        )
        return self


# ---------------------------------------------------------------------------
# Referral tracking schemas
# ---------------------------------------------------------------------------


class RecordClickRequest(BaseModel):
    """POST /api/referrals/click request body."""

    slug: str
    application_id: str


class AttributeReferralRequest(BaseModel):
    """POST /api/referrals/attribute request body."""

    referred_entity_type: Literal["user", "agent"]
    referred_entity_id: str
    click_id: str | None = None
    slug: str | None = None

    @field_validator("slug")
    @classmethod
    def _click_id_or_slug(cls, v: str | None, info) -> str | None:
        click_id = info.data.get("click_id")
        if v and click_id:
            msg = "Provide either click_id or slug, not both"
            raise ValueError(msg)
        if not v and not click_id:
            msg = "Must provide click_id or slug"
            raise ValueError(msg)
        return v


# ---------------------------------------------------------------------------
# Payout schemas
# ---------------------------------------------------------------------------


class RequestPayoutRequest(BaseModel):
    """POST /api/affiliates/me/payouts request body."""

    amount_cents: int = Field(..., gt=0)
    agent_id: str | None = None


# ---------------------------------------------------------------------------
# Admin payout schemas
# ---------------------------------------------------------------------------


class CompletePayoutRequest(BaseModel):
    """POST /api/admin/payouts/:id/complete request body."""

    tx_hash: str = Field(..., min_length=1)


class DenyPayoutRequest(BaseModel):
    """POST /api/admin/payouts/:id/deny request body."""

    reason: str | None = Field(default=None, max_length=500)


class FailPayoutRequest(BaseModel):
    """POST /api/admin/payouts/:id/fail request body."""

    reason: str | None = Field(default=None, max_length=500)


# ---------------------------------------------------------------------------
# Application config schemas
# ---------------------------------------------------------------------------


class UpdateAffiliateConfigRequest(BaseModel):
    """PUT /api/applications/:id/affiliate-config request body."""

    enabled: bool
    l1_rate_bps: int = Field(default=1000, ge=0, le=5000)
    l2_rate_bps: int = Field(default=500, ge=0, le=5000)
    l3_rate_bps: int = Field(default=200, ge=0, le=5000)
    attribution_window_days: int = Field(default=30, ge=1, le=365)
    min_payout_cents: int = Field(default=2500, ge=100, le=100000)

    @field_validator("l3_rate_bps")
    @classmethod
    def _total_rate_cap(cls, v: int, info) -> int:
        l1 = info.data.get("l1_rate_bps", 0)
        l2 = info.data.get("l2_rate_bps", 0)
        if l1 + l2 + v > 5000:
            msg = "Total commission rate (l1 + l2 + l3) must not exceed 5000 bps (50%)"
            raise ValueError(msg)
        return v


# ---------------------------------------------------------------------------
# Internal commission processing
# ---------------------------------------------------------------------------


class ProcessCommissionRequest(BaseModel):
    """POST /api/internal/commissions/process request body."""

    payer_entity_type: Literal["user", "agent"]
    payer_entity_id: str
    payment_amount_cents: int = Field(..., gt=0)
    payment_event_type: str = Field(..., min_length=1)
    payment_reference: str = Field(..., min_length=1)
    application_id: str
