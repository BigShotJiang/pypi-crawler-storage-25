"""Pydantic schemas for support telemetry platform endpoints."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field

SupportCaseStatus = Literal["open", "in_progress", "resolved", "ignored"]
SupportCasePriority = Literal["low", "normal", "high", "urgent"]
SupportEventSeverity = Literal["info", "warning", "error", "critical"]
SupportSourceChannel = Literal["issue_log", "support_thread", "email", "frontend", "api", "webhook"]
SupportActorType = Literal["user", "practitioner", "anonymous", "service", "support_operator"]


class SupportActorIn(BaseModel):
    """Event actor identity from ingest requests."""

    type: SupportActorType
    id: str | None = Field(default=None, max_length=255)


class IngestEventRequest(BaseModel):
    """POST /v1/support-telemetry/events request body."""

    application_id: str | None = None
    event_key: str = Field(..., min_length=1, max_length=128)
    occurred_at: datetime
    source_channel: SupportSourceChannel
    event_type: str = Field(..., min_length=1, max_length=100)
    severity: SupportEventSeverity
    actor: SupportActorIn
    correlation_id: str | None = Field(default=None, max_length=255)
    external_case_ref: str | None = Field(default=None, max_length=255)
    title: str | None = Field(default=None, max_length=500)
    payload: dict[str, Any] = Field(default_factory=dict)


class IngestEventResponse(BaseModel):
    """Event ingest outcome."""

    event_id: str
    case_id: str
    created_case: bool
    deduplicated: bool
    case_status: SupportCaseStatus


class SupportActorOut(BaseModel):
    """Actor payload in case event responses."""

    type: SupportActorType
    id: str | None = None


class SupportCaseSummary(BaseModel):
    """Canonical support case summary."""

    id: str
    application_id: str
    external_case_ref: str | None = None
    title: str | None = None
    status: SupportCaseStatus
    priority: SupportCasePriority
    highest_severity: SupportEventSeverity
    assigned_to_user_id: str | None = None
    first_event_at: str
    last_event_at: str
    resolved_at: str | None = None
    created_at: str
    updated_at: str


class SupportCaseEventOut(BaseModel):
    """Case timeline event payload."""

    id: str
    case_id: str
    event_key: str
    source_channel: SupportSourceChannel
    event_type: str
    severity: SupportEventSeverity
    actor: SupportActorOut
    correlation_id: str | None = None
    occurred_at: str
    received_at: str
    payload: dict[str, Any]


class ListSupportCasesResponse(BaseModel):
    """GET /v1/support-telemetry/cases response."""

    items: list[SupportCaseSummary]
    total: int


class SupportCaseDetailResponse(BaseModel):
    """GET /v1/support-telemetry/cases/{case_id} response."""

    case: SupportCaseSummary
    events: list[SupportCaseEventOut]
    event_total: int


class PatchSupportCaseRequest(BaseModel):
    """PATCH /v1/support-telemetry/cases/{case_id} request."""

    status: SupportCaseStatus | None = None
    priority: SupportCasePriority | None = None
    assigned_to_user_id: str | None = None
    resolution_note: str | None = Field(default=None, max_length=2000)


class PatchSupportCaseOut(BaseModel):
    """Patched case summary for lifecycle updates."""

    id: str
    status: SupportCaseStatus
    priority: SupportCasePriority
    assigned_to_user_id: str | None = None
    resolved_at: str | None = None
    updated_at: str


class PatchSupportCaseResponse(BaseModel):
    """PATCH response payload."""

    case: PatchSupportCaseOut


class SupportCaseByExternalOut(BaseModel):
    """Case payload returned by external case reference lookup."""

    id: str
    application_id: str
    external_case_ref: str | None = None
    status: SupportCaseStatus
    priority: SupportCasePriority
    assigned_to_user_id: str | None = None
    resolved_at: str | None = None
    updated_at: str


class SupportCaseByExternalResponse(BaseModel):
    """GET /v1/support-telemetry/cases/by-external/{external_case_ref} response."""

    case: SupportCaseByExternalOut

