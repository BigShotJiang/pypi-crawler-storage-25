"""Domain errors for support_telemetry_platform."""

from __future__ import annotations

from ..errors import DomainError


class NotAuthorizedError(DomainError):
    """Raised when caller lacks support telemetry permissions."""

    def __init__(self, message: str = "Caller is not authorized for support telemetry") -> None:
        super().__init__("NOT_AUTHORIZED", message, status_code=403)


class ValidationFailedError(DomainError):
    """Raised when a support telemetry request fails validation."""

    def __init__(self, message: str = "Request validation failed") -> None:
        super().__init__("VALIDATION_FAILED", message, status_code=400)


class SupportTelemetryCaseNotFoundError(DomainError):
    """Raised when a requested support case is not found."""

    def __init__(self, message: str = "Support case not found") -> None:
        super().__init__("SUPPORT_TELEMETRY_CASE_NOT_FOUND", message, status_code=404)


class SupportTelemetryInvalidTransitionError(DomainError):
    """Raised when an invalid case lifecycle transition is requested."""

    def __init__(self, message: str = "Invalid support case lifecycle transition") -> None:
        super().__init__("SUPPORT_TELEMETRY_INVALID_TRANSITION", message, status_code=400)


class SupportTelemetryEventTooOldError(DomainError):
    """Raised when an event is older than accepted ingestion window."""

    def __init__(self, message: str = "Support telemetry event is too old") -> None:
        super().__init__("SUPPORT_TELEMETRY_EVENT_TOO_OLD", message, status_code=400)


class SupportTelemetryPayloadTooLargeError(DomainError):
    """Raised when payload size exceeds platform threshold."""

    def __init__(self, message: str = "Support telemetry payload too large") -> None:
        super().__init__("SUPPORT_TELEMETRY_PAYLOAD_TOO_LARGE", message, status_code=413)


class SupportTelemetryBackpressureError(DomainError):
    """Raised when ingestion is throttled under pressure."""

    def __init__(self, message: str = "Support telemetry ingestion backpressure") -> None:
        super().__init__("SUPPORT_TELEMETRY_BACKPRESSURE", message, status_code=429)

