"""SQLAlchemy models for support telemetry platform."""

from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID, uuid4

from sqlalchemy import (
    CheckConstraint,
    DateTime,
    ForeignKey,
    Index,
    String,
    func,
)
from sqlalchemy.dialects.postgresql import JSON
from sqlalchemy.orm import Mapped, mapped_column

from .._db import Base, PGUUID


class SupportCase(Base):
    """Canonical support case across downstream applications."""

    __tablename__ = "support_cases"

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    application_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("applications.id", ondelete="CASCADE"),
        nullable=False,
    )
    external_case_ref: Mapped[str | None] = mapped_column(String(255), nullable=True)
    title: Mapped[str | None] = mapped_column(String(500), nullable=True)
    status: Mapped[str] = mapped_column(String(20), nullable=False, server_default="open")
    priority: Mapped[str] = mapped_column(String(20), nullable=False, server_default="normal")
    highest_severity: Mapped[str] = mapped_column(String(20), nullable=False, server_default="info")
    assigned_to_user_id: Mapped[UUID | None] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("users.id", ondelete="SET NULL"),
        nullable=True,
    )
    first_event_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    last_event_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    __table_args__ = (
        CheckConstraint(
            "status IN ('open', 'in_progress', 'resolved', 'ignored')",
            name="ck_support_cases_status",
        ),
        CheckConstraint(
            "priority IN ('low', 'normal', 'high', 'urgent')",
            name="ck_support_cases_priority",
        ),
        CheckConstraint(
            "highest_severity IN ('info', 'warning', 'error', 'critical')",
            name="ck_support_cases_highest_severity",
        ),
        Index(
            "uq_support_cases_external_ref",
            "application_id",
            "external_case_ref",
            unique=True,
            postgresql_where="external_case_ref IS NOT NULL",
        ),
        Index("ix_support_cases_app_status_priority", "application_id", "status", "priority"),
        Index("ix_support_cases_assigned_user", "assigned_to_user_id"),
        Index("ix_support_cases_last_event_at", "last_event_at"),
    )


class SupportCaseEvent(Base):
    """Telemetry event attached to a canonical support case."""

    __tablename__ = "support_case_events"

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    case_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("support_cases.id", ondelete="CASCADE"),
        nullable=False,
    )
    application_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("applications.id", ondelete="CASCADE"),
        nullable=False,
    )
    event_key: Mapped[str] = mapped_column(String(128), nullable=False)
    source_channel: Mapped[str] = mapped_column(String(32), nullable=False)
    event_type: Mapped[str] = mapped_column(String(100), nullable=False)
    severity: Mapped[str] = mapped_column(String(20), nullable=False)
    actor_type: Mapped[str] = mapped_column(String(32), nullable=False)
    actor_external_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    correlation_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    payload: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False, default=dict)
    redacted_keys: Mapped[list[str] | None] = mapped_column(JSON, nullable=True, default=list)
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    received_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    ingested_by_user_id: Mapped[UUID | None] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("users.id", ondelete="SET NULL"),
        nullable=True,
    )

    __table_args__ = (
        CheckConstraint(
            "source_channel IN ('issue_log', 'support_thread', 'email', 'frontend', 'api', 'webhook')",
            name="ck_support_case_events_source_channel",
        ),
        CheckConstraint(
            "severity IN ('info', 'warning', 'error', 'critical')",
            name="ck_support_case_events_severity",
        ),
        CheckConstraint(
            "actor_type IN ('user', 'practitioner', 'anonymous', 'service', 'support_operator')",
            name="ck_support_case_events_actor_type",
        ),
        Index("uq_support_case_events_event_key", "application_id", "event_key", unique=True),
        Index("ix_support_case_events_case_occurred", "case_id", "occurred_at"),
        Index(
            "ix_support_case_events_app_correlation",
            "application_id",
            "correlation_id",
            postgresql_where="correlation_id IS NOT NULL",
        ),
    )

