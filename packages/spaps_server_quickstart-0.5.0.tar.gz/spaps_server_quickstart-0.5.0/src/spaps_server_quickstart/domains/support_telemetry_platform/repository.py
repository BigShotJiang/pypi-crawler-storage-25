"""Repository operations for support telemetry platform domain."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from sqlalchemy import Select, case as sql_case, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from .models import SupportCase, SupportCaseEvent

_SEVERITY_RANKS = {
    "info": 0,
    "warning": 1,
    "error": 2,
    "critical": 3,
}


def _severity_rank_expression():
    return sql_case(
        (SupportCase.highest_severity == "info", 0),
        (SupportCase.highest_severity == "warning", 1),
        (SupportCase.highest_severity == "error", 2),
        (SupportCase.highest_severity == "critical", 3),
        else_=0,
    )


def _apply_case_filters(
    stmt: Select[Any],
    *,
    application_id: UUID | None,
    status: str | None,
    priority: str | None,
    severity_gte: str | None,
    assigned_to_user_id: UUID | None,
) -> Select[Any]:
    if application_id is not None:
        stmt = stmt.where(SupportCase.application_id == application_id)
    if status is not None:
        stmt = stmt.where(SupportCase.status == status)
    if priority is not None:
        stmt = stmt.where(SupportCase.priority == priority)
    if severity_gte is not None:
        stmt = stmt.where(_severity_rank_expression() >= _SEVERITY_RANKS[severity_gte])
    if assigned_to_user_id is not None:
        stmt = stmt.where(SupportCase.assigned_to_user_id == assigned_to_user_id)
    return stmt


async def get_event_by_key(
    db: AsyncSession,
    *,
    application_id: UUID,
    event_key: str,
) -> SupportCaseEvent | None:
    stmt = select(SupportCaseEvent).where(
        SupportCaseEvent.application_id == application_id,
        SupportCaseEvent.event_key == event_key,
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def get_case_by_id(
    db: AsyncSession,
    *,
    case_id: UUID,
    application_id: UUID | None = None,
) -> SupportCase | None:
    stmt = select(SupportCase).where(SupportCase.id == case_id)
    if application_id is not None:
        stmt = stmt.where(SupportCase.application_id == application_id)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def get_case_by_external_ref(
    db: AsyncSession,
    *,
    application_id: UUID,
    external_case_ref: str,
) -> SupportCase | None:
    stmt = select(SupportCase).where(
        SupportCase.application_id == application_id,
        SupportCase.external_case_ref == external_case_ref,
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def find_open_case_by_correlation_id(
    db: AsyncSession,
    *,
    application_id: UUID,
    correlation_id: str,
) -> SupportCase | None:
    stmt = (
        select(SupportCase)
        .join(SupportCaseEvent, SupportCaseEvent.case_id == SupportCase.id)
        .where(
            SupportCase.application_id == application_id,
            SupportCase.status == "open",
            SupportCaseEvent.application_id == application_id,
            SupportCaseEvent.correlation_id == correlation_id,
        )
        .order_by(SupportCase.updated_at.desc())
        .limit(1)
    )
    result = await db.execute(stmt)
    return result.scalars().first()


async def count_open_cases_by_correlation_id(
    db: AsyncSession,
    *,
    application_id: UUID,
    correlation_id: str,
) -> int:
    stmt = (
        select(func.count(func.distinct(SupportCase.id)))
        .select_from(SupportCase)
        .join(SupportCaseEvent, SupportCaseEvent.case_id == SupportCase.id)
        .where(
            SupportCase.application_id == application_id,
            SupportCase.status == "open",
            SupportCaseEvent.application_id == application_id,
            SupportCaseEvent.correlation_id == correlation_id,
        )
    )
    result = await db.execute(stmt)
    return int(result.scalar() or 0)


async def create_case(
    db: AsyncSession,
    *,
    application_id: UUID,
    external_case_ref: str | None,
    title: str | None,
    status: str,
    priority: str,
    highest_severity: str,
    first_event_at: datetime,
    last_event_at: datetime,
) -> SupportCase:
    case = SupportCase(
        application_id=application_id,
        external_case_ref=external_case_ref,
        title=title,
        status=status,
        priority=priority,
        highest_severity=highest_severity,
        first_event_at=first_event_at,
        last_event_at=last_event_at,
    )
    db.add(case)
    await db.flush()
    await db.refresh(case)
    return case


async def create_event(
    db: AsyncSession,
    *,
    case_id: UUID,
    application_id: UUID,
    event_key: str,
    source_channel: str,
    event_type: str,
    severity: str,
    actor_type: str,
    actor_external_id: str | None,
    correlation_id: str | None,
    payload: dict[str, Any],
    redacted_keys: list[str] | None,
    occurred_at: datetime,
    ingested_by_user_id: UUID | None,
) -> SupportCaseEvent:
    event = SupportCaseEvent(
        case_id=case_id,
        application_id=application_id,
        event_key=event_key,
        source_channel=source_channel,
        event_type=event_type,
        severity=severity,
        actor_type=actor_type,
        actor_external_id=actor_external_id,
        correlation_id=correlation_id,
        payload=payload,
        redacted_keys=redacted_keys or [],
        occurred_at=occurred_at,
        ingested_by_user_id=ingested_by_user_id,
    )
    db.add(event)
    await db.flush()
    await db.refresh(event)
    return event


async def update_case_summary(
    db: AsyncSession,
    *,
    case: SupportCase,
    occurred_at: datetime,
    severity: str,
    title: str | None,
) -> SupportCase:
    now = datetime.now(UTC)
    if occurred_at < case.first_event_at:
        case.first_event_at = occurred_at
    if occurred_at > case.last_event_at:
        case.last_event_at = occurred_at

    if _SEVERITY_RANKS[severity] > _SEVERITY_RANKS[case.highest_severity]:
        case.highest_severity = severity

    if not case.title and title:
        case.title = title

    case.updated_at = now
    await db.flush()
    await db.refresh(case)
    return case


async def list_cases(
    db: AsyncSession,
    *,
    application_id: UUID | None,
    status: str | None,
    priority: str | None,
    severity_gte: str | None,
    assigned_to_user_id: UUID | None,
    limit: int,
    offset: int,
) -> tuple[list[SupportCase], int]:
    data_stmt = _apply_case_filters(
        select(SupportCase),
        application_id=application_id,
        status=status,
        priority=priority,
        severity_gte=severity_gte,
        assigned_to_user_id=assigned_to_user_id,
    ).order_by(SupportCase.last_event_at.desc()).limit(limit).offset(offset)

    count_stmt = _apply_case_filters(
        select(func.count()).select_from(SupportCase),
        application_id=application_id,
        status=status,
        priority=priority,
        severity_gte=severity_gte,
        assigned_to_user_id=assigned_to_user_id,
    )

    data_result = await db.execute(data_stmt)
    count_result = await db.execute(count_stmt)
    return list(data_result.scalars().all()), int(count_result.scalar() or 0)


async def list_case_events(
    db: AsyncSession,
    *,
    case_id: UUID,
    limit: int,
    offset: int,
) -> list[SupportCaseEvent]:
    stmt = (
        select(SupportCaseEvent)
        .where(SupportCaseEvent.case_id == case_id)
        .order_by(SupportCaseEvent.occurred_at.asc())
        .limit(limit)
        .offset(offset)
    )
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def count_case_events(
    db: AsyncSession,
    *,
    case_id: UUID,
) -> int:
    stmt = select(func.count()).select_from(SupportCaseEvent).where(
        SupportCaseEvent.case_id == case_id
    )
    result = await db.execute(stmt)
    return int(result.scalar() or 0)


async def update_case(
    db: AsyncSession,
    *,
    case: SupportCase,
    status: str | None = None,
    priority: str | None = None,
    assigned_to_user_id: UUID | None = None,
    set_assigned_to_user_id: bool = False,
    resolved_at: datetime | None = None,
    set_resolved_at: bool = False,
) -> SupportCase:
    now = datetime.now(UTC)
    if status is not None:
        case.status = status
    if priority is not None:
        case.priority = priority
    if set_assigned_to_user_id:
        case.assigned_to_user_id = assigned_to_user_id
    if set_resolved_at:
        case.resolved_at = resolved_at
    case.updated_at = now

    await db.flush()
    await db.refresh(case)
    return case
