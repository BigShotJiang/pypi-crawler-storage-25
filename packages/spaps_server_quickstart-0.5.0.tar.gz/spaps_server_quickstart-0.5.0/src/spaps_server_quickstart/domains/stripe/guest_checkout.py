"""Guest checkout service.

Handles guest checkout sessions (no JWT required) and conversion
to registered users. This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime, timedelta
from typing import Any
from uuid import UUID

import stripe
from sqlalchemy.ext.asyncio import AsyncSession

from spaps_server_quickstart.spaps_settings import get_spaps_settings

from .errors import (
    EmailMismatchError,
    GuestCheckoutError,
    SessionIncompleteError,
    SessionNotFoundError,
)
from . import repository as repo

logger = logging.getLogger(__name__)


def _ensure_stripe_api_key() -> None:
    """Initialize Stripe SDK API key from SPAPS settings."""
    settings = get_spaps_settings()
    if settings.stripe_secret_key:
        stripe.api_key = settings.stripe_secret_key


async def create_guest_checkout_session(
    db: AsyncSession,
    *,
    application_id: UUID,
    customer_email: str,
    mode: str = "payment",
    line_items: list[dict[str, Any]],
    success_url: str,
    cancel_url: str,
    metadata: dict[str, str] | None = None,
    client_reference_id: str | None = None,
    allow_promotion_codes: bool = False,
) -> dict[str, Any]:
    """Create a guest checkout session (no JWT required)."""
    _ensure_stripe_api_key()
    try:
        stripe_line_items = []
        for item in line_items:
            li: dict[str, Any] = {"quantity": item.get("quantity", 1)}
            if item.get("price_id"):
                li["price"] = item["price_id"]
            elif item.get("price_data"):
                li["price_data"] = item["price_data"]
            stripe_line_items.append(li)

        params: dict[str, Any] = {
            "mode": mode,
            "line_items": stripe_line_items,
            "success_url": success_url,
            "cancel_url": cancel_url,
            "customer_email": customer_email,
            "metadata": {
                "app_id": str(application_id),
                "is_guest": "true",
                **(metadata or {}),
            },
        }
        if client_reference_id:
            params["client_reference_id"] = client_reference_id
        if allow_promotion_codes:
            params["allow_promotion_codes"] = True

        # 60-minute expiry for guest sessions
        params["expires_at"] = int((datetime.now(UTC) + timedelta(minutes=60)).timestamp())

        stripe_session = stripe.checkout.Session.create(**params)
    except stripe.StripeError as e:
        raise GuestCheckoutError(str(e))

    session = await repo.create_checkout_session(
        db,
        session_id=stripe_session.id,
        application_id=application_id,
        status=stripe_session.get("status", "open"),
        mode=mode,
        success_url=success_url,
        cancel_url=cancel_url,
        amount_total=stripe_session.get("amount_total"),
        currency=stripe_session.get("currency"),
        metadata={
            "app_id": str(application_id),
            "is_guest": "true",
            **(metadata or {}),
        },
        is_guest=True,
        customer_email=customer_email,
        expires_at=datetime.now(UTC) + timedelta(minutes=60),
    )

    return {
        "id": session.session_id,
        "status": session.status,
        "url": stripe_session.get("url"),
        "customer_email": customer_email,
        "amount_total": session.amount_total,
        "currency": session.currency,
        "metadata": session.metadata_,
        "expires_at": session.expires_at.isoformat() if session.expires_at else None,
    }


async def get_guest_checkout_session(
    db: AsyncSession,
    *,
    session_id: str,
    application_id: UUID | None = None,
) -> dict[str, Any]:
    """Retrieve a guest checkout session."""
    session = await repo.get_checkout_session(db, session_id)
    if session is None:
        raise SessionNotFoundError()
    if not session.is_guest:
        raise GuestCheckoutError("This is not a guest checkout session")
    # TM-004: Verify session belongs to the requesting application
    if application_id is not None and session.application_id != application_id:
        raise SessionNotFoundError()
    return {
        "id": session.session_id,
        "status": session.status,
        "payment_status": session.payment_status,
        "customer_email": session.customer_email,
        "amount_total": session.amount_total,
        "currency": session.currency,
        "success_url": session.success_url,
        "cancel_url": session.cancel_url,
        "metadata": session.metadata_,
        "is_guest": True,
        "expires_at": session.expires_at.isoformat() if session.expires_at else None,
        "application_id": str(session.application_id) if session.application_id else None,
    }


async def list_guest_checkout_sessions(
    db: AsyncSession,
    *,
    application_id: UUID,
    limit: int = 10,
) -> dict[str, Any]:
    """List guest checkout sessions for an application."""
    sessions = await repo.list_checkout_sessions(
        db, application_id=application_id, limit=limit
    )
    guest_sessions = [s for s in sessions if s.is_guest]
    return {
        "sessions": [
            {
                "id": s.session_id,
                "status": s.status,
                "customer_email": s.customer_email,
                "amount_total": s.amount_total,
                "currency": s.currency,
                "created_at": s.created_at.isoformat() if s.created_at else None,
                "expires_at": s.expires_at.isoformat() if s.expires_at else None,
            }
            for s in guest_sessions
        ],
        "has_more": len(guest_sessions) >= limit,
    }


async def convert_guest_to_user(
    db: AsyncSession,
    *,
    session_id: str,
    email: str,
    application_id: UUID,
    password: str | None = None,
    send_magic_link: bool = False,
) -> dict[str, Any]:
    """Convert a completed guest checkout to a registered user.

    Steps:
    1. Find session and verify it's a guest session
    2. Verify the email matches
    3. Create user (stubbed -- actual user creation is out of scope)
    4. Record the conversion
    """
    session = await repo.get_checkout_session(db, session_id)
    if session is None:
        raise SessionNotFoundError("Guest checkout session not found or invalid")
    if not session.is_guest:
        raise GuestCheckoutError("This is not a guest checkout session")
    if session.status != "complete":
        raise SessionIncompleteError()
    if session.customer_email and session.customer_email.lower() != email.lower():
        raise EmailMismatchError()

    # Create user via the users repository
    from ..users import repository as user_repo
    from ..sessions import password_service

    password_hash = None
    if password:
        password_service.validate_password_strength(password)
        password_hash = password_service.hash_password(password)

    user = await user_repo.create_user(
        db,
        email=email,
        password_hash=password_hash,
    )
    user_id = user.id

    await repo.create_guest_conversion(
        db,
        session_id=session_id,
        guest_email=email,
        converted_user_id=user_id,
        converted_at=datetime.now(UTC),
    )

    return {
        "user_id": str(user_id),
        "email": email,
        "session_id": session_id,
        "message": "Guest checkout converted to user account",
    }
