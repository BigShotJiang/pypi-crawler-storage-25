"""Stripe domain -- products, prices, checkout, subscriptions, payments, portal, webhooks."""
