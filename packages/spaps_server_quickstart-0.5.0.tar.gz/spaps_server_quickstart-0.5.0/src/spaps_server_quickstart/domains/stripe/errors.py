"""Stripe-specific domain errors.

These extend the base DomainError and carry Stripe-relevant codes.
"""

from __future__ import annotations

from ..errors import DomainError


class StripeApiError(DomainError):
    """Generic Stripe API error wrapper."""

    def __init__(
        self,
        message: str = "Stripe API error",
        *,
        status_code: int = 500,
        stripe_code: str | None = None,
        request_id: str | None = None,
    ) -> None:
        details: dict = {}
        if stripe_code:
            details["stripe_code"] = stripe_code
        if request_id:
            details["request_id"] = request_id
        super().__init__(
            code="STRIPE_API_ERROR",
            message=message,
            status_code=status_code,
            details=details,
        )


class ProductNotFoundError(DomainError):
    def __init__(self, message: str = "Product not found") -> None:
        super().__init__("PRODUCT_NOT_FOUND", message, status_code=404)


class PriceNotFoundError(DomainError):
    def __init__(self, message: str = "Price not found") -> None:
        super().__init__("PRICE_NOT_FOUND", message, status_code=404)


class CheckoutSessionError(DomainError):
    def __init__(self, message: str = "Checkout session error") -> None:
        super().__init__("CHECKOUT_SESSION_ERROR", message, status_code=400)


class SubscriptionNotFoundError(DomainError):
    def __init__(self, message: str = "Subscription not found") -> None:
        super().__init__("SUBSCRIPTION_NOT_FOUND", message, status_code=404)


class SubscriptionError(DomainError):
    def __init__(self, message: str = "Subscription operation failed") -> None:
        super().__init__("SUBSCRIPTION_ERROR", message, status_code=400)


class PaymentNotFoundError(DomainError):
    def __init__(self, message: str = "Payment not found") -> None:
        super().__init__("PAYMENT_NOT_FOUND", message, status_code=404)


class WebhookSignatureError(DomainError):
    def __init__(self, message: str = "Invalid webhook signature") -> None:
        super().__init__("WEBHOOK_SIGNATURE_INVALID", message, status_code=400)


class WebhookProcessingError(DomainError):
    def __init__(self, message: str = "Webhook processing failed") -> None:
        super().__init__("WEBHOOK_PROCESSING_ERROR", message, status_code=500)


class GuestCheckoutError(DomainError):
    def __init__(self, message: str = "Guest checkout error") -> None:
        super().__init__("GUEST_CHECKOUT_ERROR", message, status_code=400)


class SessionNotFoundError(DomainError):
    def __init__(self, message: str = "Checkout session not found") -> None:
        super().__init__("SESSION_NOT_FOUND", message, status_code=404)


class SessionIncompleteError(DomainError):
    def __init__(self, message: str = "Checkout session must be complete before conversion") -> None:
        super().__init__("SESSION_INCOMPLETE", message, status_code=400)


class EmailMismatchError(DomainError):
    def __init__(self, message: str = "Email does not match the checkout session") -> None:
        super().__init__("EMAIL_MISMATCH", message, status_code=400)


class PortalSessionError(DomainError):
    def __init__(self, message: str = "Failed to create portal session") -> None:
        super().__init__("PORTAL_SESSION_ERROR", message, status_code=500)


class WebhookConfigurationError(DomainError):
    def __init__(self, message: str = "Webhook configuration error") -> None:
        super().__init__("WEBHOOK_CONFIGURATION_ERROR", message, status_code=500)
