"""Stripe webhook event handler.

Verifies signatures, stores events, and dispatches to type-specific
handlers. Entitlement-granting events use STUB functions that log
"TODO: wire to entitlements domain".
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

import stripe
from sqlalchemy.ext.asyncio import AsyncSession

from . import repository as repo
from ..entitlements import service as entitlement_service
from .errors import WebhookProcessingError, WebhookSignatureError

logger = logging.getLogger(__name__)


async def _process_affiliate_commissions(
    db: AsyncSession,
    *,
    payer_entity_type: str,
    payer_entity_id: str | None,
    payment_amount_cents: int | None,
    payment_event_type: str,
    payment_reference: str | None,
    application_id: str | None,
) -> None:
    """Best-effort affiliate commission processing for Stripe payments."""
    if (
        not payer_entity_id
        or not application_id
        or not payment_reference
        or not payment_amount_cents
        or payment_amount_cents <= 0
    ):
        return

    try:
        from ..affiliate_referrals import service as affiliate_referral_service

        await affiliate_referral_service.process_commissions(
            db,
            payer_entity_type=payer_entity_type,
            payer_entity_id=UUID(payer_entity_id),
            payment_amount_cents=payment_amount_cents,
            payment_event_type=payment_event_type,
            payment_reference=payment_reference,
            application_id=UUID(application_id),
        )
    except Exception:
        logger.exception(
            "Affiliate commission processing failed",
            extra={
                "payment_event_type": payment_event_type,
                "payment_reference": payment_reference,
                "application_id": application_id,
            },
        )


def verify_webhook_signature(
    payload: bytes,
    signature: str,
    webhook_secret: str,
) -> dict[str, Any]:
    """Verify a Stripe webhook signature and return the parsed event."""
    try:
        event = stripe.Webhook.construct_event(payload, signature, webhook_secret)
        return dict(event)
    except stripe.SignatureVerificationError:
        raise WebhookSignatureError()
    except Exception as exc:
        raise WebhookSignatureError(f"Webhook verification failed: {exc}")


async def handle_webhook_event(
    db: AsyncSession,
    *,
    event: dict[str, Any],
) -> dict[str, Any]:
    """Dispatch a webhook event to the appropriate handler.

    Stores the event first, then processes by type.
    Returns ``{"received": True}`` on success.
    """
    event_id = event.get("id", "unknown")
    event_type = event.get("type", "unknown")

    logger.info("Processing webhook event %s: %s", event_id, event_type)

    # Store the event
    try:
        await repo.store_webhook_event(
            db,
            event_id=event_id,
            event_type=event_type,
            data=event.get("data", {}),
        )
    except Exception as exc:
        logger.error("Failed to store webhook event %s: %s", event_id, exc)
        # Don't fail -- still process the event

    # Dispatch
    data_object = event.get("data", {}).get("object", {})

    handlers = {
        "checkout.session.completed": _handle_checkout_completed,
        "checkout.session.expired": _handle_checkout_expired,
        "payment_intent.succeeded": _handle_payment_intent_succeeded,
        "payment_intent.payment_failed": _handle_payment_intent_failed,
        "customer.subscription.created": _handle_subscription_created,
        "customer.subscription.updated": _handle_subscription_updated,
        "customer.subscription.deleted": _handle_subscription_deleted,
        "invoice.payment_succeeded": _handle_invoice_payment_succeeded,
        "invoice.payment_failed": _handle_invoice_payment_failed,
        "product.created": _handle_product_upsert,
        "product.updated": _handle_product_upsert,
        "price.created": _handle_price_upsert,
        "price.updated": _handle_price_upsert,
    }

    handler = handlers.get(event_type)
    if handler:
        try:
            await handler(db, data_object)
        except Exception as exc:
            logger.error("Error processing webhook %s (%s): %s", event_id, event_type, exc)
            raise WebhookProcessingError(f"Failed to process {event_type}")
    else:
        logger.info("Unhandled webhook event type: %s", event_type)

    return {"received": True}


# ---------------------------------------------------------------------------
# Event handlers
# ---------------------------------------------------------------------------


async def _handle_checkout_completed(
    db: AsyncSession, data: dict[str, Any]
) -> None:
    session_id = data.get("id")
    if session_id:
        await repo.update_checkout_session_status(
            db, session_id, "complete", completed_at=datetime.now(UTC)
        )

    # Grant entitlements from checkout
    app_id_str = data.get("metadata", {}).get("app_id")
    if app_id_str:
        from uuid import UUID as _UUID

        try:
            line_items = data.get("line_items", {}).get("data") if data.get("line_items") else None
            await entitlement_service.process_stripe_checkout(
                db, data, line_items, _UUID(app_id_str)
            )
        except Exception as exc:
            logger.error("Entitlement grant from checkout failed: %s", exc)

    metadata = data.get("metadata", {}) or {}
    await _process_affiliate_commissions(
        db,
        payer_entity_type="user",
        payer_entity_id=metadata.get("user_id"),
        payment_amount_cents=data.get("amount_total"),
        payment_event_type="stripe_onetime",
        payment_reference=data.get("payment_intent") or session_id,
        application_id=metadata.get("app_id"),
    )


async def _handle_checkout_expired(
    db: AsyncSession, data: dict[str, Any]
) -> None:
    session_id = data.get("id")
    if session_id:
        await repo.update_checkout_session_status(
            db, session_id, "expired", expired_at=datetime.now(UTC)
        )
    logger.info("Checkout session expired: %s", session_id)


async def _handle_payment_intent_succeeded(
    db: AsyncSession, data: dict[str, Any]
) -> None:
    pi_id = data.get("id")
    app_id = data.get("metadata", {}).get("app_id")
    from uuid import UUID as _UUID

    await repo.upsert_payment(
        db,
        payment_intent_id=pi_id or "unknown",
        application_id=_UUID(app_id) if app_id else None,
        customer_id=data.get("customer"),
        amount=data.get("amount", 0),
        currency=data.get("currency", "usd"),
        status="succeeded",
        metadata=data.get("metadata"),
    )
    metadata = data.get("metadata", {}) or {}
    await _process_affiliate_commissions(
        db,
        payer_entity_type="user",
        payer_entity_id=metadata.get("user_id"),
        payment_amount_cents=data.get("amount"),
        payment_event_type="stripe_onetime",
        payment_reference=pi_id,
        application_id=metadata.get("app_id"),
    )
    logger.info("Payment intent succeeded: %s", pi_id)


async def _handle_payment_intent_failed(
    db: AsyncSession, data: dict[str, Any]
) -> None:
    pi_id = data.get("id")
    logger.warning("Payment intent failed: %s", pi_id)


async def _handle_subscription_created(
    db: AsyncSession, data: dict[str, Any]
) -> None:
    app_id_str = (data.get("metadata") or {}).get("app_id")
    if app_id_str:
        from uuid import UUID as _UUID

        try:
            await entitlement_service.process_stripe_subscription(
                db, data, "created", _UUID(app_id_str)
            )
        except Exception as exc:
            logger.error("Entitlement grant from subscription.created failed: %s", exc)


async def _handle_subscription_updated(
    db: AsyncSession, data: dict[str, Any]
) -> None:
    sub_id = data.get("id")
    if sub_id:
        await repo.update_subscription(
            db,
            sub_id,
            status=data.get("status", "active"),
        )
    app_id_str = (data.get("metadata") or {}).get("app_id")
    if app_id_str:
        from uuid import UUID as _UUID

        try:
            await entitlement_service.process_stripe_subscription(
                db, data, "updated", _UUID(app_id_str)
            )
        except Exception as exc:
            logger.error("Entitlement update from subscription.updated failed: %s", exc)


async def _handle_subscription_deleted(
    db: AsyncSession, data: dict[str, Any]
) -> None:
    sub_id = data.get("id")
    if sub_id:
        await repo.update_subscription(
            db,
            sub_id,
            status="canceled",
            canceled_at=datetime.now(UTC),
        )
    app_id_str = (data.get("metadata") or {}).get("app_id")
    if app_id_str:
        from uuid import UUID as _UUID

        try:
            await entitlement_service.process_stripe_subscription(
                db, data, "deleted", _UUID(app_id_str)
            )
        except Exception as exc:
            logger.error("Entitlement update from subscription.deleted failed: %s", exc)


async def _handle_invoice_payment_succeeded(
    db: AsyncSession, data: dict[str, Any]
) -> None:
    invoice_id = data.get("id")
    await repo.upsert_invoice(
        db,
        invoice_id=invoice_id or "unknown",
        subscription_id=data.get("subscription"),
        customer_id=data.get("customer"),
        amount_paid=data.get("amount_paid"),
        amount_due=data.get("amount_due"),
        currency=data.get("currency", "usd"),
        status="paid",
        metadata=data.get("metadata"),
    )
    # Renew entitlements for subscription invoices
    app_id_str = (data.get("metadata") or {}).get("app_id")
    if app_id_str:
        from uuid import UUID as _UUID

        try:
            await entitlement_service.process_stripe_invoice(
                db, data, _UUID(app_id_str)
            )
        except Exception as exc:
            logger.error("Entitlement renewal from invoice failed: %s", exc)

    metadata = data.get("metadata", {}) or {}
    await _process_affiliate_commissions(
        db,
        payer_entity_type="user",
        payer_entity_id=metadata.get("user_id"),
        payment_amount_cents=data.get("amount_paid"),
        payment_event_type="stripe_subscription",
        payment_reference=invoice_id,
        application_id=metadata.get("app_id"),
    )


async def _handle_invoice_payment_failed(
    db: AsyncSession, data: dict[str, Any]
) -> None:
    invoice_id = data.get("id")
    logger.warning("Invoice payment failed: %s", invoice_id)


async def _handle_product_upsert(
    db: AsyncSession, data: dict[str, Any]
) -> None:
    product_id = data.get("id")
    if not product_id:
        return
    existing = await repo.get_product(db, product_id)
    if existing:
        await repo.update_product(
            db,
            product_id,
            name=data.get("name", ""),
            description=data.get("description"),
            active=data.get("active", True),
        )
    else:
        logger.info("Product upsert from webhook skipped (no local record): %s", product_id)


async def _handle_price_upsert(
    db: AsyncSession, data: dict[str, Any]
) -> None:
    price_id = data.get("id")
    if not price_id:
        return
    existing = await repo.get_price(db, price_id)
    if existing:
        existing.active = data.get("active", True)
        existing.unit_amount = data.get("unit_amount")
        await db.flush()
    else:
        logger.info("Price upsert from webhook skipped (no local record): %s", price_id)
