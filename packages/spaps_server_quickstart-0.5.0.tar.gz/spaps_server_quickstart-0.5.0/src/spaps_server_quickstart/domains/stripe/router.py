"""HTTP routes for the Stripe domain.

Multiple routers are defined:
- products_router: /stripe/ (products, prices, sync, super-admin)
- checkout_router: /stripe/ (checkout sessions)
- guest_checkout_router: /stripe/ (guest checkout)
- subscriptions_router: /stripe/ (subscriptions)
- portal_router: /stripe/ (billing portal)
- history_router: /stripe/ (payment history)
- webhooks_router: /stripe/ (webhook handler)

The response envelope ``{ success, data, error, metadata }`` is
applied automatically by ``ResponseEnvelopeMiddleware``.
"""

from __future__ import annotations

import logging
from typing import Any
from uuid import UUID

from fastapi import APIRouter, Query, Request

from ...middleware.spaps_deps import (
    AdminUser,
    Application,
    CurrentUser,
    DbSession,
    SuperAdminUser,
)
from . import service
from . import guest_checkout as guest_service
from . import webhook_handler
from .schemas import (
    ConvertGuestCheckoutRequest,
    CreateAndSetDefaultPriceRequest,
    CreateCheckoutSessionRequest,
    CreateGuestCheckoutRequest,
    CreatePriceRequest,
    CreateProductRequest,
    CreatePortalSessionRequest,
    CancelSubscriptionRequest,
    CreateSubscriptionRequest,
    ProductWithPriceRequest,
    SetDefaultPriceRequest,
    UpdateProductRequest,
    UpdateSubscriptionRequest,
)

logger = logging.getLogger(__name__)

# ===========================================================================
# Products Router
# ===========================================================================

products_router = APIRouter(prefix="/stripe", tags=["stripe-products"])


@products_router.get("/products")
async def list_products(
    db: DbSession,
    app: Application,
    user: CurrentUser,
    category: str | None = Query(None),
    active: bool | None = Query(None),
    limit: int = Query(default=100, ge=1, le=1000),
) -> dict[str, Any]:
    active_only = active if active is not None else False
    result = await service.list_products(
        db,
        application_id=app.id,
        category=category,
        active_only=active_only,
        limit=limit,
    )
    return result


@products_router.get("/products/{product_id}")
async def get_product(
    product_id: str,
    db: DbSession,
    app: Application,
    user: CurrentUser,
) -> dict[str, Any]:
    result = await service.get_product(db, stripe_product_id=product_id, application_id=app.id)
    return result


@products_router.post("/products", status_code=201)
async def create_product(
    body: CreateProductRequest,
    db: DbSession,
    app: Application,
    admin: AdminUser,
) -> dict[str, Any]:
    result = await service.create_product(
        db,
        application_id=app.id,
        application_slug=getattr(app, "slug", "unknown"),
        name=body.name,
        description=body.description,
        category=body.category,
        images=body.images,
        metadata=body.metadata,
        active=body.active,
    )
    return result


@products_router.put("/products/{product_id}")
async def update_product(
    product_id: str,
    body: UpdateProductRequest,
    db: DbSession,
    app: Application,
    admin: AdminUser,
) -> dict[str, Any]:
    update_data: dict[str, Any] = {}
    if body.name is not None:
        update_data["name"] = body.name
    if body.description is not None:
        update_data["description"] = body.description
    if body.active is not None:
        update_data["active"] = body.active
    if body.images is not None:
        update_data["images"] = body.images
    if body.metadata is not None:
        update_data["metadata"] = body.metadata

    result = await service.update_product(
        db, stripe_product_id=product_id, application_id=app.id, **update_data
    )
    return result


@products_router.delete("/products/{product_id}")
async def archive_product(
    product_id: str,
    db: DbSession,
    app: Application,
    admin: AdminUser,
) -> dict[str, Any]:
    result = await service.archive_product(db, stripe_product_id=product_id, application_id=app.id)
    return result


@products_router.post("/products/sync")
async def sync_products(
    db: DbSession,
    app: Application,
    super_admin: SuperAdminUser,
) -> dict[str, Any]:
    result = await service.sync_products(db, application_id=app.id)
    return result


@products_router.post("/products/with-price", status_code=201)
async def create_product_with_price(
    body: ProductWithPriceRequest,
    db: DbSession,
    app: Application,
    admin: AdminUser,
) -> dict[str, Any]:
    result = await service.create_product_with_price(
        db,
        application_id=app.id,
        application_slug=getattr(app, "slug", "unknown"),
        product_data=body.product.model_dump(),
        price_data=body.price,
    )
    return result


@products_router.get("/products/super-admin/all")
async def list_all_products(
    db: DbSession,
    app: Application,
    super_admin: SuperAdminUser,
) -> dict[str, Any]:
    result = await service.list_all_products(db)
    return result


@products_router.post("/products/super-admin/{application_id}", status_code=201)
async def super_admin_create_product(
    application_id: str,
    body: CreateProductRequest,
    db: DbSession,
    app: Application,
    super_admin: SuperAdminUser,
) -> dict[str, Any]:
    result = await service.create_product(
        db,
        application_id=UUID(application_id),
        application_slug="super-admin",
        name=body.name,
        description=body.description,
        category=body.category,
        images=body.images,
        metadata=body.metadata,
        active=body.active,
    )
    return result


@products_router.post("/products/super-admin/{application_id}/with-price", status_code=201)
async def super_admin_create_product_with_price(
    application_id: str,
    body: ProductWithPriceRequest,
    db: DbSession,
    app: Application,
    super_admin: SuperAdminUser,
) -> dict[str, Any]:
    result = await service.create_product_with_price(
        db,
        application_id=UUID(application_id),
        application_slug="super-admin",
        product_data=body.product.model_dump(),
        price_data=body.price,
    )
    return result


@products_router.put("/products/super-admin/{product_id}")
async def super_admin_update_product(
    product_id: str,
    body: UpdateProductRequest,
    db: DbSession,
    app: Application,
    super_admin: SuperAdminUser,
) -> dict[str, Any]:
    update_data: dict[str, Any] = {}
    if body.name is not None:
        update_data["name"] = body.name
    if body.description is not None:
        update_data["description"] = body.description
    if body.active is not None:
        update_data["active"] = body.active
    if body.metadata is not None:
        update_data["metadata"] = body.metadata

    result = await service.update_product(
        db, stripe_product_id=product_id, **update_data
    )
    return {"product": result}


@products_router.delete("/products/super-admin/{product_id}")
async def super_admin_archive_product(
    product_id: str,
    db: DbSession,
    app: Application,
    super_admin: SuperAdminUser,
) -> dict[str, Any]:
    result = await service.archive_product(db, stripe_product_id=product_id)
    return {"product": result}


@products_router.put("/products/super-admin/{product_id}/default-price")
async def super_admin_set_default_price(
    product_id: str,
    body: SetDefaultPriceRequest,
    db: DbSession,
    app: Application,
    super_admin: SuperAdminUser,
) -> dict[str, Any]:
    result = await service.set_default_price(
        db, stripe_product_id=product_id, stripe_price_id=body.price_id
    )
    return {"product": result}


@products_router.post("/products/{product_id}/prices/default-new", status_code=201)
async def create_and_set_default_price(
    product_id: str,
    body: CreateAndSetDefaultPriceRequest,
    db: DbSession,
    app: Application,
    admin: AdminUser,
) -> dict[str, Any]:
    result = await service.create_price_and_set_default(
        db,
        stripe_product_id=product_id,
        unit_amount=body.unit_amount,
        currency=body.currency,
        interval=body.interval,
        interval_count=body.interval_count,
        recurring=body.recurring,
        nickname=body.nickname,
        metadata=body.metadata,
        deactivate_previous=body.deactivate_previous,
    )
    return result


@products_router.post("/products/super-admin/{product_id}/prices/default-new", status_code=201)
async def super_admin_create_and_set_default_price(
    product_id: str,
    body: CreateAndSetDefaultPriceRequest,
    db: DbSession,
    app: Application,
    super_admin: SuperAdminUser,
) -> dict[str, Any]:
    result = await service.create_price_and_set_default(
        db,
        stripe_product_id=product_id,
        unit_amount=body.unit_amount,
        currency=body.currency,
        interval=body.interval,
        interval_count=body.interval_count,
        recurring=body.recurring,
        nickname=body.nickname,
        metadata=body.metadata,
        deactivate_previous=body.deactivate_previous,
    )
    return result


@products_router.get("/applications")
async def list_applications_with_stats(
    db: DbSession,
    app: Application,
    super_admin: SuperAdminUser,
) -> dict[str, Any]:
    # Stub: returns basic structure
    return {"applications": [], "total_applications": 0}


# ---------------------------------------------------------------------------
# Prices
# ---------------------------------------------------------------------------


@products_router.post("/prices", status_code=201)
async def create_price(
    body: CreatePriceRequest,
    db: DbSession,
    app: Application,
    admin: AdminUser,
) -> dict[str, Any]:
    result = await service.create_price(
        db,
        stripe_product_id=body.product_id,
        unit_amount=body.unit_amount,
        currency=body.currency,
        interval=body.interval,
        interval_count=body.interval_count,
        recurring=body.recurring,
        nickname=body.nickname,
        metadata=body.metadata,
        active=body.active,
    )
    return result


@products_router.delete("/prices/{price_id}")
async def deactivate_price(
    price_id: str,
    db: DbSession,
    app: Application,
    admin: AdminUser,
) -> dict[str, Any]:
    result = await service.deactivate_price(db, stripe_price_id=price_id, application_id=app.id)
    return result


@products_router.post("/products/{product_id}/default-price")
async def set_default_price(
    product_id: str,
    body: SetDefaultPriceRequest,
    db: DbSession,
    app: Application,
    admin: AdminUser,
) -> dict[str, Any]:
    result = await service.set_default_price(
        db, stripe_product_id=product_id, stripe_price_id=body.price_id
    )
    return {"product": result}


@products_router.put("/products/{product_id}/default-price")
async def set_default_price_put(
    product_id: str,
    body: SetDefaultPriceRequest,
    db: DbSession,
    app: Application,
    admin: AdminUser,
) -> dict[str, Any]:
    result = await service.set_default_price(
        db, stripe_product_id=product_id, stripe_price_id=body.price_id
    )
    return {"product": result}


# ===========================================================================
# Checkout Router
# ===========================================================================

checkout_router = APIRouter(prefix="/stripe", tags=["stripe-checkout"])


@checkout_router.post("/checkout-sessions")
async def create_checkout_session(
    body: CreateCheckoutSessionRequest,
    db: DbSession,
    app: Application,
    user: CurrentUser,
) -> dict[str, Any]:
    line_items = [li.model_dump() for li in body.line_items]
    result = await service.create_checkout_session(
        db,
        application_id=app.id,
        user_id=UUID(user.id) if isinstance(user.id, str) else user.id,
        mode=body.mode,
        line_items=line_items,
        success_url=body.success_url,
        cancel_url=body.cancel_url,
        metadata=body.metadata,
        customer_email=body.customer_email,
    )
    return result


@checkout_router.get("/checkout-sessions")
async def list_checkout_sessions(
    db: DbSession,
    app: Application,
    user: CurrentUser,
    limit: int = Query(default=10, ge=1, le=100),
) -> dict[str, Any]:
    result = await service.list_checkout_sessions(
        db,
        user_id=UUID(user.id) if isinstance(user.id, str) else user.id,
        application_id=app.id,
        limit=limit,
    )
    return result


@checkout_router.get("/checkout-sessions/{session_id}")
async def get_checkout_session(
    session_id: str,
    db: DbSession,
    app: Application,
    user: CurrentUser,
) -> dict[str, Any]:
    result = await service.get_checkout_session(
        db, session_id=session_id,
        application_id=app.id,
        user_id=UUID(user.id) if isinstance(user.id, str) else user.id,
    )
    return result


@checkout_router.post("/checkout-sessions/{session_id}/expire")
async def expire_checkout_session(
    session_id: str,
    db: DbSession,
    app: Application,
    user: CurrentUser,
) -> dict[str, Any]:
    result = await service.expire_checkout_session(
        db, session_id=session_id,
        application_id=app.id,
        user_id=UUID(user.id) if isinstance(user.id, str) else user.id,
    )
    return result


# ===========================================================================
# Guest Checkout Router
# ===========================================================================

guest_checkout_router = APIRouter(prefix="/stripe", tags=["stripe-guest-checkout"])


@guest_checkout_router.post("/guest-checkout-sessions")
async def create_guest_checkout_session(
    body: CreateGuestCheckoutRequest,
    db: DbSession,
    app: Application,
) -> dict[str, Any]:
    """Create guest checkout (API key only, no JWT required)."""
    line_items = [li.model_dump() for li in body.line_items]
    result = await guest_service.create_guest_checkout_session(
        db,
        application_id=app.id,
        customer_email=body.customer_email,
        mode=body.mode,
        line_items=line_items,
        success_url=body.success_url,
        cancel_url=body.cancel_url,
        metadata=body.metadata,
        client_reference_id=body.client_reference_id,
        allow_promotion_codes=body.allow_promotion_codes or False,
    )
    return result


@guest_checkout_router.get("/guest-checkout-sessions")
async def list_guest_checkout_sessions(
    db: DbSession,
    app: Application,
    limit: int = Query(default=10, ge=1, le=100),
) -> dict[str, Any]:
    result = await guest_service.list_guest_checkout_sessions(
        db, application_id=app.id, limit=limit
    )
    return result


@guest_checkout_router.get("/guest-checkout-sessions/{session_id}")
async def get_guest_checkout_session(
    session_id: str,
    db: DbSession,
    app: Application,
) -> dict[str, Any]:
    result = await guest_service.get_guest_checkout_session(
        db, session_id=session_id, application_id=app.id,
    )
    return result


@guest_checkout_router.post("/guest-checkout-sessions/convert")
async def convert_guest_checkout(
    body: ConvertGuestCheckoutRequest,
    db: DbSession,
    app: Application,
) -> dict[str, Any]:
    result = await guest_service.convert_guest_to_user(
        db,
        session_id=body.session_id,
        email=body.email,
        application_id=app.id,
        password=body.password,
        send_magic_link=body.send_magic_link,
    )
    return result


# ===========================================================================
# Subscriptions Router
# ===========================================================================

subscriptions_router = APIRouter(prefix="/stripe", tags=["stripe-subscriptions"])


@subscriptions_router.post("/subscriptions")
async def create_subscription(
    body: CreateSubscriptionRequest,
    db: DbSession,
    app: Application,
    user: CurrentUser,
) -> dict[str, Any]:
    result = await service.create_subscription(
        db,
        user_id=UUID(user.id) if isinstance(user.id, str) else user.id,
        customer_id=body.customer_id,
        price_id=body.price_id,
        application_id=app.id,
        metadata=body.metadata,
        trial_period_days=body.trial_period_days,
    )
    return result


@subscriptions_router.get("/subscriptions")
async def list_subscriptions(
    db: DbSession,
    app: Application,
    user: CurrentUser,
    status: str | None = Query(None),
    limit: int = Query(default=10, ge=1, le=100),
) -> list[dict[str, Any]]:
    result = await service.list_subscriptions(
        db,
        user_id=UUID(user.id) if isinstance(user.id, str) else user.id,
        application_id=app.id,
        status=status,
        limit=limit,
    )
    return result


@subscriptions_router.get("/subscription/{id}")
async def get_subscription(
    id: str,
    db: DbSession,
    app: Application,
    user: CurrentUser,
) -> dict[str, Any]:
    result = await service.get_subscription(
        db,
        subscription_id=id,
        user_id=UUID(user.id) if isinstance(user.id, str) else user.id,
        application_id=app.id,
    )
    return result


@subscriptions_router.post("/subscription/{id}/cancel")
async def cancel_subscription(
    id: str,
    db: DbSession,
    app: Application,
    user: CurrentUser,
    body: CancelSubscriptionRequest | None = None,
) -> dict[str, Any]:
    immediately = body.immediately if body else False
    result = await service.cancel_subscription(
        db,
        subscription_id=id,
        immediately=immediately,
        user_id=UUID(user.id) if isinstance(user.id, str) else user.id,
        application_id=app.id,
    )
    return result


@subscriptions_router.post("/subscription/{id}/update")
async def update_subscription(
    id: str,
    body: UpdateSubscriptionRequest,
    db: DbSession,
    app: Application,
    user: CurrentUser,
) -> dict[str, Any]:
    result = await service.update_subscription_plan(
        db,
        subscription_id=id,
        price_id=body.price_id,
        user_id=UUID(user.id) if isinstance(user.id, str) else user.id,
        application_id=app.id,
    )
    return result


# ===========================================================================
# Payment History Router
# ===========================================================================

history_router = APIRouter(prefix="/stripe", tags=["stripe-history"])


@history_router.get("/history")
async def list_payment_history(
    db: DbSession,
    app: Application,
    user: CurrentUser,
    limit: int = Query(default=10, ge=1, le=100),
    status: str | None = Query(None),
) -> dict[str, Any]:
    result = await service.list_payment_history(
        db,
        user_id=UUID(user.id) if isinstance(user.id, str) else user.id,
        limit=limit,
        status=status,
    )
    return result


@history_router.get("/payment/{payment_id}")
async def get_payment_detail(
    payment_id: str,
    db: DbSession,
    app: Application,
    user: CurrentUser,
) -> dict[str, Any]:
    result = await service.get_payment_detail(
        db,
        payment_id=UUID(payment_id),
        user_id=UUID(user.id) if isinstance(user.id, str) else user.id,
    )
    return result


# ===========================================================================
# Portal Router
# ===========================================================================

portal_router = APIRouter(prefix="/stripe", tags=["stripe-portal"])


@portal_router.post("/portal-session")
async def create_portal_session(
    body: CreatePortalSessionRequest,
    db: DbSession,
    app: Application,
    user: CurrentUser,
) -> dict[str, Any]:
    result = await service.create_portal_session(
        db,
        user_id=UUID(user.id) if isinstance(user.id, str) else user.id,
        application_id=app.id,
        return_url=body.return_url,
    )
    return result


# ===========================================================================
# Webhooks Router
# ===========================================================================

webhooks_router = APIRouter(prefix="/stripe", tags=["stripe-webhooks"])


@webhooks_router.post("/webhooks")
async def handle_stripe_webhook(
    request: Request,
    db: DbSession,
) -> dict[str, Any]:
    """Handle Stripe webhook events. Public endpoint verified by signature."""
    signature = request.headers.get("stripe-signature")
    if not signature:
        from .errors import WebhookSignatureError
        raise WebhookSignatureError("Missing stripe-signature header")

    body = await request.body()
    settings = request.app.state.settings
    webhook_secret = settings.stripe_webhook_secret
    if not webhook_secret:
        from .errors import WebhookConfigurationError
        raise WebhookConfigurationError("STRIPE_WEBHOOK_SECRET not configured")

    event = webhook_handler.verify_webhook_signature(body, signature, webhook_secret)
    result = await webhook_handler.handle_webhook_event(db, event=event)
    return result


# ===========================================================================
# Admin Webhooks Router
# ===========================================================================

admin_webhooks_router = APIRouter(prefix="/admin/stripe", tags=["admin-stripe-webhooks"])


@admin_webhooks_router.get("/webhooks/validate")
async def validate_webhook_config(
    db: DbSession,
    app: Application,
    admin: AdminUser,
) -> dict[str, Any]:
    return {"valid": True, "message": "Webhook configuration is valid"}


@admin_webhooks_router.get("/webhooks")
async def list_webhook_endpoints(
    db: DbSession,
    app: Application,
    admin: AdminUser,
) -> dict[str, Any]:
    return {"endpoints": [], "total": 0}


# Alternative sync endpoint
@products_router.post("/v1/admin/products/sync")
async def alt_sync_products(
    db: DbSession,
    app: Application,
    super_admin: SuperAdminUser,
) -> dict[str, Any]:
    result = await service.sync_products(db, application_id=app.id)
    return result
