"""Pydantic request/response schemas for Stripe endpoints.

These schemas define the *data* portion of each API response.
The standard response envelope is applied by middleware.
Zero FastAPI imports.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, EmailStr, Field


# ---------------------------------------------------------------------------
# Products
# ---------------------------------------------------------------------------


class CreateProductRequest(BaseModel):
    name: str
    description: str | None = None
    category: str
    images: list[str] | None = None
    metadata: dict[str, str] | None = None
    active: bool = True
    statement_descriptor: str | None = Field(None, max_length=22)
    unit_label: str | None = None


class UpdateProductRequest(BaseModel):
    name: str | None = None
    description: str | None = None
    category: str | None = None
    images: list[str] | None = None
    metadata: dict[str, str] | None = None
    active: bool | None = None
    statement_descriptor: str | None = Field(None, max_length=22)
    unit_label: str | None = None


class PriceOut(BaseModel):
    id: str
    unit_amount: int | None = None
    currency: str
    type: str
    recurring: dict[str, Any] | None = None
    nickname: str | None = None
    active: bool = True


class ProductOut(BaseModel):
    id: str
    name: str
    description: str | None = None
    images: list[str] | None = None
    active: bool = True
    metadata: dict[str, Any] | None = None
    prices: list[PriceOut] | None = None
    default_price: PriceOut | None = None
    created_at: str | None = None


class ListProductsResponse(BaseModel):
    products: list[ProductOut]
    total: int


class ProductWithPriceRequest(BaseModel):
    product: CreateProductRequest
    price: dict[str, Any]
    options: dict[str, Any] | None = None


# ---------------------------------------------------------------------------
# Prices
# ---------------------------------------------------------------------------


class CreatePriceRequest(BaseModel):
    product_id: str
    unit_amount: int = Field(..., gt=0)
    currency: str = Field(..., min_length=3, max_length=3)
    interval: Literal["day", "week", "month", "year"] | None = None
    interval_count: int | None = Field(None, ge=1)
    trial_period_days: int | None = Field(None, ge=1, le=730)
    metadata: dict[str, str] | None = None
    nickname: str | None = None
    active: bool = True
    recurring: bool = False


class CreateAndSetDefaultPriceRequest(BaseModel):
    unit_amount: int = Field(..., gt=0)
    currency: str = Field(..., min_length=3, max_length=3)
    interval: Literal["day", "week", "month", "year"] | None = None
    interval_count: int | None = Field(None, ge=1)
    trial_period_days: int | None = Field(None, ge=1, le=730)
    metadata: dict[str, str] | None = None
    nickname: str | None = None
    active: bool = True
    recurring: bool = False
    deactivate_previous: bool = False


class SetDefaultPriceRequest(BaseModel):
    price_id: str


# ---------------------------------------------------------------------------
# Checkout
# ---------------------------------------------------------------------------


class LineItem(BaseModel):
    price_id: str | None = None
    product_id: str | None = None
    quantity: int = Field(..., ge=1)
    price_data: dict[str, Any] | None = None


class CreateCheckoutSessionRequest(BaseModel):
    mode: Literal["payment", "subscription"]
    line_items: list[LineItem] = Field(..., min_length=1)
    success_url: str
    cancel_url: str
    metadata: dict[str, str] | None = None
    customer_email: str | None = None
    client_reference_id: str | None = None
    allow_promotion_codes: bool | None = None


class CheckoutSessionOut(BaseModel):
    id: str
    status: str
    payment_status: str | None = None
    customer_email: str | None = None
    amount_total: int | None = None
    currency: str | None = None
    url: str | None = None
    success_url: str | None = None
    cancel_url: str | None = None
    payment_intent: str | None = None
    subscription: str | None = None
    client_reference_id: str | None = None
    metadata: dict[str, Any] | None = None
    expires_at: str | None = None
    created_at: str | None = None


class ListCheckoutSessionsResponse(BaseModel):
    sessions: list[CheckoutSessionOut]
    has_more: bool = False


# ---------------------------------------------------------------------------
# Guest Checkout
# ---------------------------------------------------------------------------


class CreateGuestCheckoutRequest(BaseModel):
    customer_email: EmailStr
    mode: Literal["payment", "subscription"]
    line_items: list[LineItem] = Field(..., min_length=1)
    success_url: str
    cancel_url: str
    metadata: dict[str, str] | None = None
    client_reference_id: str | None = None
    allow_promotion_codes: bool | None = None


class ConvertGuestCheckoutRequest(BaseModel):
    session_id: str
    email: EmailStr
    password: str | None = Field(None, min_length=8)
    send_magic_link: bool = False


class ConvertGuestCheckoutResponse(BaseModel):
    user_id: str
    email: str
    session_id: str
    message: str


# ---------------------------------------------------------------------------
# Subscriptions
# ---------------------------------------------------------------------------


class CreateSubscriptionRequest(BaseModel):
    customer_id: str
    price_id: str
    metadata: dict[str, str] | None = None
    trial_period_days: int | None = None


class SubscriptionItemOut(BaseModel):
    id: str
    price: dict[str, Any]


class SubscriptionOut(BaseModel):
    id: str
    status: str
    current_period_start: int | None = None
    current_period_end: int | None = None
    cancel_at_period_end: bool = False
    canceled_at: int | None = None
    items: list[SubscriptionItemOut] | None = None


class CancelSubscriptionRequest(BaseModel):
    immediately: bool = False


class UpdateSubscriptionRequest(BaseModel):
    price_id: str


# ---------------------------------------------------------------------------
# Payment History
# ---------------------------------------------------------------------------


class PaymentRecordOut(BaseModel):
    id: str
    amount: int
    currency: str
    status: str
    description: str | None = None
    stripe_payment_intent_id: str | None = None
    created_at: str | None = None
    metadata: dict[str, Any] | None = None


class ListPaymentHistoryResponse(BaseModel):
    payments: list[PaymentRecordOut]
    has_more: bool = False
    total_count: int | None = None


# ---------------------------------------------------------------------------
# Portal
# ---------------------------------------------------------------------------


class CreatePortalSessionRequest(BaseModel):
    return_url: str


class PortalSessionOut(BaseModel):
    url: str
    session_id: str
    expires_at: str | None = None


# ---------------------------------------------------------------------------
# Webhooks
# ---------------------------------------------------------------------------


class WebhookValidateResponse(BaseModel):
    valid: bool
    message: str


class WebhookEndpointOut(BaseModel):
    id: str
    url: str
    status: str
    events: list[str] | None = None


# ---------------------------------------------------------------------------
# Applications (super admin)
# ---------------------------------------------------------------------------


class ApplicationWithStatsOut(BaseModel):
    id: str
    name: str
    slug: str | None = None
    product_count: int = 0
    active_products: int = 0
    created_at: str | None = None


class ListApplicationsWithStatsResponse(BaseModel):
    applications: list[ApplicationWithStatsOut]
    total_applications: int
