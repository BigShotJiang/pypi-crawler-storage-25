"""Domain errors for the CFO / QuickBooks domain."""

from __future__ import annotations

from ..errors import DomainError


class CfoConnectionNotFoundError(DomainError):
    """Raised when a CFO connection is not found."""

    def __init__(self, message: str = "Connection not found") -> None:
        super().__init__("NOT_FOUND", message, status_code=404)


class CfoInvalidTokenError(DomainError):
    """Raised when a magic link token is invalid or expired."""

    def __init__(self, message: str = "Invalid or expired token") -> None:
        super().__init__("INVALID_TOKEN", message, status_code=401)


class CfoInvalidCodeError(DomainError):
    """Raised when an auth code is invalid, expired, or already used."""

    def __init__(
        self,
        message: str = "Invalid, expired, or already used code",
    ) -> None:
        super().__init__("INVALID_CODE", message, status_code=401)


class CfoOAuthError(DomainError):
    """Raised when QuickBooks OAuth exchange fails."""

    def __init__(self, message: str = "QuickBooks OAuth error") -> None:
        super().__init__("SERVER_ERROR", message, status_code=500)


class CfoAdminKeyRequiredError(DomainError):
    """Raised when CFO admin API key is missing or invalid."""

    def __init__(self, message: str = "Invalid CFO admin API key") -> None:
        super().__init__("UNAUTHORIZED", message, status_code=401)


class CfoConnectionAlreadyRevokedError(DomainError):
    """Raised when attempting to revoke an already-revoked connection."""

    def __init__(self, message: str = "Connection already revoked") -> None:
        super().__init__("ALREADY_REVOKED", message, status_code=400)
