"""HTTP routes for the CFO / QuickBooks domain.

Provides ``cfo_router`` under ``/cfo``.

Admin endpoints authenticate via CFO_ADMIN_API_KEY header.
User endpoints authenticate via JWT.
Some endpoints have no authentication (OAuth callbacks, token validation).
"""

from __future__ import annotations

import hmac
import logging
from uuid import UUID

from fastapi import APIRouter, Body, Query, Request
from fastapi.responses import RedirectResponse

from ...middleware.spaps_deps import CurrentUser, DbSession
from . import service
from .errors import CfoAdminKeyRequiredError
from .schemas import (
    ConnectionsResponse,
    ConnectWithEmailRequest,
    ExchangeCodeRequest,
    ExchangeCodeResponse,
    GenerateLinkRequest,
    GenerateLinkResponse,
    RevokeRequest,
    RevokeResponse,
    RuntimeTokenResponse,
    StatusResponse,
    UserAddConnectionRequest,
    UserAddConnectionResponse,
    UserConnectionsResponse,
    UserConnectResponse,
    UserDeleteConnectionResponse,
    UserDisconnectResponse,
    UserStatusResponse,
    ValidateTokenResponse,
)

logger = logging.getLogger(__name__)

cfo_router = APIRouter(prefix="/cfo", tags=["cfo"])


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _require_cfo_admin_key(request: Request) -> None:
    """Validate the CFO_ADMIN_API_KEY header.

    The CFO admin key is a separate header from X-API-Key.
    Reads from SpapsSettings.cfo_admin_api_key.
    """
    settings = request.app.state.settings
    expected_key = settings.cfo_admin_api_key

    if not expected_key:
        raise CfoAdminKeyRequiredError("CFO admin API key not configured")

    provided_key = (
        request.headers.get("X-CFO-Admin-Key")
        or request.headers.get("CFO_ADMIN_API_KEY")
        or request.headers.get("Authorization", "").removeprefix("Bearer ").strip()
    )

    if not provided_key or not hmac.compare_digest(provided_key, expected_key):
        raise CfoAdminKeyRequiredError()


def _get_cfo_settings(request: Request) -> dict:
    """Extract CFO-related settings from the request."""
    settings = request.app.state.settings
    base_url = str(request.base_url).rstrip("/")
    configured_redirect_uri = (
        settings.quickbooks_redirect_uri.strip()
        if isinstance(settings.quickbooks_redirect_uri, str)
        else ""
    )
    redirect_uri = configured_redirect_uri or f"{base_url}/api/cfo/callback"

    if not settings.cfo_public_key:
        logger.warning("CFO public key not configured — refresh tokens will NOT be encrypted")

    return {
        "client_id": settings.quickbooks_client_id,
        "client_secret": settings.quickbooks_client_secret,
        "cfo_public_key": settings.cfo_public_key,
        "frontend_url": settings.cfo_frontend_url or base_url,
        "redirect_uri": redirect_uri,
    }


# ===========================================================================
# Admin endpoints (CFO_ADMIN_API_KEY auth)
# ===========================================================================


@cfo_router.post("/generate-link", response_model=GenerateLinkResponse)
async def generate_link(
    body: GenerateLinkRequest,
    request: Request,
    db: DbSession,
) -> GenerateLinkResponse:
    """Generate a magic link for a client to connect QuickBooks.

    Auth: CFO_ADMIN_API_KEY header.
    """
    _require_cfo_admin_key(request)
    cfo = _get_cfo_settings(request)

    result = await service.generate_magic_link(
        db,
        client_name=body.clientName,
        frontend_url=cfo["frontend_url"],
    )
    return GenerateLinkResponse(**result)


@cfo_router.get("/status", response_model=StatusResponse)
async def get_status(
    request: Request,
    db: DbSession,
    connectionId: str = Query(..., description="Connection ID"),
) -> StatusResponse:
    """Get connection status (admin).

    Auth: CFO_ADMIN_API_KEY header.
    """
    _require_cfo_admin_key(request)

    result = await service.get_connection_status(
        db,
        connection_id=UUID(connectionId),
    )
    return StatusResponse(**result)


@cfo_router.post("/revoke", response_model=RevokeResponse)
async def revoke_connection(
    body: RevokeRequest,
    request: Request,
    db: DbSession,
) -> RevokeResponse:
    """Revoke a connection (admin).

    Auth: CFO_ADMIN_API_KEY header.
    """
    _require_cfo_admin_key(request)

    result = await service.revoke_connection(
        db,
        connection_id=UUID(body.connectionId),
    )
    return RevokeResponse(**result)


@cfo_router.get("/connections", response_model=ConnectionsResponse)
async def list_connections(
    request: Request,
    db: DbSession,
    user_id: str | None = Query(default=None),
) -> ConnectionsResponse:
    """List connections (admin).

    Auth: CFO_ADMIN_API_KEY header.
    """
    _require_cfo_admin_key(request)

    result = await service.list_connections(
        db,
        user_id=UUID(user_id) if user_id else None,
    )
    return ConnectionsResponse(**result)


@cfo_router.get("/runtime-token", response_model=RuntimeTokenResponse)
async def get_runtime_token(
    request: Request,
    db: DbSession,
    connectionId: UUID | None = Query(
        default=None,
        alias="connectionId",
        description="Connection ID",
    ),
    realmId: str | None = Query(default=None, description="QuickBooks realm ID"),
) -> RuntimeTokenResponse:
    """Return the encrypted hosted refresh token for CFO MCP runtime sync.

    Auth: CFO_ADMIN_API_KEY header.
    """
    _require_cfo_admin_key(request)

    result = await service.get_runtime_connection_token(
        db,
        connection_id=connectionId,
        realm_id=realmId,
    )
    return RuntimeTokenResponse(**result)


# ===========================================================================
# Public endpoints (no auth)
# ===========================================================================


@cfo_router.get("/validate-token", response_model=ValidateTokenResponse)
async def validate_token(
    request: Request,
    db: DbSession,
    token: str = Query(..., description="Magic link token"),
) -> ValidateTokenResponse:
    """Validate a magic link token and get the auth URL.

    Auth: None.
    """
    cfo = _get_cfo_settings(request)

    result = await service.validate_magic_link_token(
        db,
        token=token,
        client_id=cfo["client_id"],
        redirect_uri=cfo["redirect_uri"],
    )
    return ValidateTokenResponse(**result)


@cfo_router.get("/callback")
async def oauth_callback(
    request: Request,
    db: DbSession,
    code: str | None = Query(default=None),
    state: str | None = Query(default=None),
    realmId: str | None = Query(default=None),
    error: str | None = Query(default=None),
):
    """Handle Intuit OAuth callback.

    Auth: None (OAuth callback).
    Redirects to success or error page.
    """
    cfo = _get_cfo_settings(request)
    frontend_url = cfo["frontend_url"]

    # Handle OAuth errors from Intuit
    if error:
        return RedirectResponse(
            url=f"{frontend_url}/cfo/expired?error={error}",
            status_code=302,
        )

    # Validate required params
    if not code or not state or not realmId:
        return RedirectResponse(
            url=f"{frontend_url}/cfo/expired?error=Missing+required+parameters",
            status_code=302,
        )

    # Validate realmId is numeric
    if not realmId.isdigit():
        return RedirectResponse(
            url=f"{frontend_url}/cfo/expired?error=Invalid+company+identifier",
            status_code=302,
        )

    # Fail closed: OAuth callback must not proceed if refresh-token encryption
    # is not configured.
    if not cfo["cfo_public_key"]:
        logger.error("OAuth callback rejected: CFO public key is not configured")
        return RedirectResponse(
            url=f"{frontend_url}/cfo/expired?error=Token+encryption+not+configured",
            status_code=302,
        )

    result = await service.process_oauth_callback(
        db,
        code=code,
        state=state,
        realm_id=realmId,
        client_id=cfo["client_id"],
        client_secret=cfo["client_secret"],
        redirect_uri=cfo["redirect_uri"],
        cfo_public_key=cfo["cfo_public_key"],
        frontend_url=frontend_url,
    )

    redirect_url = result.get("redirect", f"{frontend_url}/cfo/expired?error=Unknown+error")
    return RedirectResponse(url=redirect_url, status_code=302)


@cfo_router.get("/connect-start")
async def connect_start(
    request: Request,
    token: str | None = Query(default=None),
):
    """Start the direct OAuth flow.

    Auth: None.
    Redirects to Intuit OAuth or returns auth URL.
    """
    cfo = _get_cfo_settings(request)

    result = await service.get_connect_start_url(
        client_id=cfo["client_id"],
        redirect_uri=cfo["redirect_uri"],
        token=token,
    )

    return RedirectResponse(url=result["authUrl"], status_code=302)


@cfo_router.post("/connect-with-email")
async def connect_with_email(
    body: ConnectWithEmailRequest,
    request: Request,
    db: DbSession,
):
    """Start OAuth flow for a given email.

    Auth: None.
    """
    cfo = _get_cfo_settings(request)

    result = await service.connect_with_email(
        db,
        email=body.email,
        client_id=cfo["client_id"],
        redirect_uri=cfo["redirect_uri"],
    )
    return result


@cfo_router.post("/exchange-code", response_model=ExchangeCodeResponse)
async def exchange_code(
    body: ExchangeCodeRequest,
    db: DbSession,
) -> dict:
    """Exchange a one-time auth code for tokens + user info.

    Auth: None. The 64-char hex code itself is the authentication.
    """
    result = await service.exchange_auth_code(
        db,
        code=body.code,
    )

    # The actual token data is encrypted -- return minimal info
    return {
        "access_token": "",
        "refresh_token": "",
        "user": {
            "id": result.get("user_id", ""),
            "email": "",
        },
        "company_name": result.get("company_name"),
        "realm_id": result.get("realm_id"),
    }


# ===========================================================================
# User endpoints (JWT auth)
# ===========================================================================


@cfo_router.post("/user-connect", response_model=UserConnectResponse)
async def user_connect(
    request: Request,
    db: DbSession,
    user: CurrentUser,
) -> UserConnectResponse:
    """User-initiated QuickBooks connection.

    Auth: JWT.
    """
    cfo = _get_cfo_settings(request)
    user_id = UUID(user.id) if isinstance(user.id, str) else user.id

    result = await service.user_connect(
        db,
        user_id=user_id,
        client_id=cfo["client_id"],
        redirect_uri=cfo["redirect_uri"],
    )
    return UserConnectResponse(**result)


@cfo_router.get("/user-status", response_model=UserStatusResponse)
async def user_status(
    db: DbSession,
    user: CurrentUser,
) -> UserStatusResponse:
    """Get the user's QuickBooks connection status.

    Auth: JWT.
    """
    user_id = UUID(user.id) if isinstance(user.id, str) else user.id

    result = await service.user_status(
        db,
        user_id=user_id,
    )
    return UserStatusResponse(**result)


@cfo_router.post("/user-disconnect", response_model=UserDisconnectResponse)
async def user_disconnect(
    db: DbSession,
    user: CurrentUser,
) -> UserDisconnectResponse:
    """Disconnect the user's primary QuickBooks connection (deprecated).

    Auth: JWT. Use DELETE /user-connections/:id instead.
    """
    user_id = UUID(user.id) if isinstance(user.id, str) else user.id

    result = await service.user_disconnect(
        db,
        user_id=user_id,
    )
    return UserDisconnectResponse(**result)


@cfo_router.get("/user-connections", response_model=UserConnectionsResponse)
async def user_connections(
    db: DbSession,
    user: CurrentUser,
    all: bool = Query(default=False, alias="all"),
) -> UserConnectionsResponse:
    """Get the user's connections.

    Auth: JWT. With ?all=true (admin only) returns all connections.
    """
    user_id = UUID(user.id) if isinstance(user.id, str) else user.id
    is_admin = getattr(user, "is_admin", False)

    result = await service.user_connections(
        db,
        user_id=user_id,
        include_all=all,
        is_admin=is_admin,
    )
    return UserConnectionsResponse(**result)


@cfo_router.post(
    "/user-add-connection", response_model=UserAddConnectionResponse
)
async def user_add_connection(
    request: Request,
    db: DbSession,
    user: CurrentUser,
    body: UserAddConnectionRequest | None = Body(default=None),
) -> UserAddConnectionResponse:
    """Add another QuickBooks company connection.

    Auth: JWT.
    Optionally accepts ``{ company_id }`` to link the connection to a
    CFO company after OAuth completes.
    """
    cfo = _get_cfo_settings(request)
    user_id = UUID(user.id) if isinstance(user.id, str) else user.id

    result = await service.user_add_connection(
        db,
        user_id=user_id,
        client_id=cfo["client_id"],
        redirect_uri=cfo["redirect_uri"],
        company_id=str(body.company_id) if body and body.company_id else None,
    )
    return UserAddConnectionResponse(**result)


@cfo_router.delete(
    "/user-connections/{connection_id}",
    response_model=UserDeleteConnectionResponse,
)
async def user_delete_connection(
    connection_id: str,
    db: DbSession,
    user: CurrentUser,
) -> UserDeleteConnectionResponse:
    """Disconnect a specific QuickBooks connection.

    Auth: JWT. User can only disconnect their own connections.
    """
    user_id = UUID(user.id) if isinstance(user.id, str) else user.id

    result = await service.user_delete_connection(
        db,
        user_id=user_id,
        connection_id=UUID(connection_id),
    )
    return UserDeleteConnectionResponse(**result)
