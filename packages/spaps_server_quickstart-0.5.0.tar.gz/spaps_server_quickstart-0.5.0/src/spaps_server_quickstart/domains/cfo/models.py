"""SQLAlchemy models for the CFO / QuickBooks domain."""

from __future__ import annotations

from datetime import datetime
from uuid import UUID, uuid4

from sqlalchemy import DateTime, ForeignKey, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from .._db import Base, PGUUID


class CfoConnection(Base):
    """A QuickBooks connection linking a user to a QB company.

    Stores the encrypted refresh token (RSA public key encryption),
    realm ID, company metadata, and connection status.
    """

    __tablename__ = "cfo_connections"

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    user_id: Mapped[UUID | None] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("users.id", ondelete="SET NULL"),
        nullable=True,
    )
    company_id: Mapped[UUID | None] = mapped_column(
        PGUUID(as_uuid=True),
        nullable=True,
        comment="Soft reference to cfo_companies.id in CFO DB (no FK constraint)",
    )
    client_name: Mapped[str | None] = mapped_column(Text, nullable=True)
    realm_id: Mapped[str | None] = mapped_column(Text, nullable=True)
    company_name: Mapped[str | None] = mapped_column(Text, nullable=True)
    encrypted_refresh_token: Mapped[str | None] = mapped_column(
        Text, nullable=True
    )
    token_expires_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    accounting_method: Mapped[str | None] = mapped_column(Text, nullable=True)
    risk_tier: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(
        Text, nullable=False, server_default="pending"
    )
    connected_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    def __repr__(self) -> str:
        return (
            f"<CfoConnection id={self.id!r} realm={self.realm_id!r} "
            f"status={self.status!r}>"
        )


class CfoAuthCode(Base):
    """One-time auth code generated during direct OAuth flow.

    The code is a 64-character hex string, used once to exchange
    for tokens + user info after the OAuth callback redirect.
    """

    __tablename__ = "cfo_auth_codes"

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    code: Mapped[str] = mapped_column(Text, nullable=False, unique=True)
    user_id: Mapped[UUID | None] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("users.id", ondelete="SET NULL"),
        nullable=True,
    )
    company_name: Mapped[str | None] = mapped_column(Text, nullable=True)
    realm_id: Mapped[str | None] = mapped_column(Text, nullable=True)
    encrypted_auth_data: Mapped[str | None] = mapped_column(
        Text, nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    expires_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    used_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    def __repr__(self) -> str:
        return f"<CfoAuthCode code={self.code[:8]}... used={self.used_at is not None}>"


class CfoMagicLink(Base):
    """Admin-generated magic link for client QuickBooks onboarding.

    Contains a unique token sent to the client, linking to a
    pre-created CfoConnection. Expires after CFO_MAGIC_LINK_EXPIRY_HOURS.
    """

    __tablename__ = "cfo_magic_links"

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    token: Mapped[str] = mapped_column(Text, nullable=False, unique=True)
    client_name: Mapped[str | None] = mapped_column(Text, nullable=True)
    connection_id: Mapped[UUID | None] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("cfo_connections.id", ondelete="SET NULL"),
        nullable=True,
    )
    expires_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    used_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    def __repr__(self) -> str:
        return (
            f"<CfoMagicLink token={self.token[:8]}... "
            f"used={self.used_at is not None}>"
        )
