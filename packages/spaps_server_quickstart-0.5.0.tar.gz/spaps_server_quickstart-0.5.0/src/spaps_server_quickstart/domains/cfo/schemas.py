"""Pydantic request/response schemas for CFO / QuickBooks endpoints.

These schemas define the *data* portion of each API response.
The standard response envelope ``{ success, data, error, metadata }``
is applied by middleware -- domain schemas never reference it.

Zero FastAPI imports.
"""

from __future__ import annotations

from uuid import UUID

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Canonical representations
# ---------------------------------------------------------------------------


class CfoConnectionOut(BaseModel):
    """Canonical representation of a CFO connection."""

    id: str
    company_name: str | None = None
    realm_id: str | None = None
    status: str
    connected_at: str | None = None
    token_expires_at: str | None = None


class CfoConnectionDetailOut(BaseModel):
    """Detailed representation including user info (admin endpoints)."""

    id: str
    user_id: str | None = None
    client_name: str | None = None
    company_name: str | None = None
    realm_id: str | None = None
    status: str
    accounting_method: str | None = None
    risk_tier: str | None = None
    connected_at: str | None = None
    token_expires_at: str | None = None
    created_at: str


class CfoUserConnectionOut(BaseModel):
    """User-facing connection representation."""

    id: str
    status: str
    companyName: str | None = None
    realmId: str | None = None
    connectedAt: str | None = None
    tokenExpiresAt: str | None = None
    connectedBy: str | None = None


# ---------------------------------------------------------------------------
# Request schemas
# ---------------------------------------------------------------------------


class UserAddConnectionRequest(BaseModel):
    """POST /cfo/user-add-connection body (optional)."""

    company_id: UUID | None = None  # UUID of CFO company (cross-DB soft ref)


class GenerateLinkRequest(BaseModel):
    """POST /cfo/generate-link body."""

    clientName: str = Field(..., min_length=1, max_length=255)


class ConnectWithEmailRequest(BaseModel):
    """POST /cfo/connect-with-email body."""

    email: str = Field(..., min_length=1)


class RevokeRequest(BaseModel):
    """POST /cfo/revoke body."""

    connectionId: str


class ExchangeCodeRequest(BaseModel):
    """POST /cfo/exchange-code body."""

    code: str = Field(..., min_length=64, max_length=64)


# ---------------------------------------------------------------------------
# Response schemas
# ---------------------------------------------------------------------------


class GenerateLinkResponse(BaseModel):
    """POST /cfo/generate-link -- success payload."""

    url: str
    token: str
    expiresAt: str
    connectionId: str


class ValidateTokenResponse(BaseModel):
    """GET /cfo/validate-token -- success payload."""

    valid: bool
    clientName: str | None = None
    authUrl: str | None = None
    expiresAt: str | None = None


class StatusResponse(BaseModel):
    """GET /cfo/status -- success payload."""

    id: str
    user_id: str | None = None
    client_name: str | None = None
    company_name: str | None = None
    realm_id: str | None = None
    status: str
    accounting_method: str | None = None
    risk_tier: str | None = None
    connected_at: str | None = None
    token_expires_at: str | None = None
    created_at: str


class RevokeResponse(BaseModel):
    """POST /cfo/revoke -- success payload."""

    revoked: bool
    message: str


class ConnectionsResponse(BaseModel):
    """GET /cfo/connections -- success payload."""

    connections: list[CfoConnectionDetailOut]


class ExchangeCodeResponse(BaseModel):
    """POST /cfo/exchange-code -- success payload."""

    access_token: str
    refresh_token: str
    user: dict
    company_name: str | None = None
    realm_id: str | None = None


class RuntimeTokenResponse(BaseModel):
    """GET /cfo/runtime-token -- admin runtime bridge payload."""

    connection_id: str
    realm_id: str | None = None
    company_name: str | None = None
    status: str
    encrypted_refresh_token: str


class UserConnectResponse(BaseModel):
    """POST /cfo/user-connect -- success payload."""

    authUrl: str
    connectionId: str


class UserStatusResponse(BaseModel):
    """GET /cfo/user-status -- success payload."""

    connection: CfoUserConnectionOut | None = None
    totalConnections: int


class UserDisconnectResponse(BaseModel):
    """POST /cfo/user-disconnect -- success payload."""

    success: bool
    message: str


class UserConnectionsResponse(BaseModel):
    """GET /cfo/user-connections -- success payload."""

    connections: list[CfoUserConnectionOut]


class UserAddConnectionResponse(BaseModel):
    """POST /cfo/user-add-connection -- success payload."""

    authUrl: str
    connectionId: str
    existingConnections: int


class UserDeleteConnectionResponse(BaseModel):
    """DELETE /cfo/user-connections/:connectionId -- success payload."""

    success: bool
    message: str
