"""Database operations for the CFO / QuickBooks domain.

Pure SQLAlchemy async repository -- no FastAPI imports.
All functions accept an ``AsyncSession`` as the first positional argument.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from uuid import UUID

from sqlalchemy import func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from .models import CfoAuthCode, CfoConnection, CfoMagicLink

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# CfoConnection operations
# ---------------------------------------------------------------------------


async def get_connection_by_id(
    db: AsyncSession,
    connection_id: UUID,
) -> CfoConnection | None:
    """Fetch a single connection by ID."""
    stmt = select(CfoConnection).where(CfoConnection.id == connection_id)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def find_connection_by_realm_id(
    db: AsyncSession,
    realm_id: str,
) -> CfoConnection | None:
    """Fetch the most recent non-revoked connection for a QuickBooks realm."""
    stmt = (
        select(CfoConnection)
        .where(
            CfoConnection.realm_id == realm_id,
            CfoConnection.status.in_(["active", "connected", "pending"]),
        )
        .order_by(CfoConnection.created_at.desc())
        .limit(1)
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def list_connections(
    db: AsyncSession,
    *,
    user_id: UUID | None = None,
) -> list[CfoConnection]:
    """List connections, optionally filtered by user_id."""
    stmt = select(CfoConnection).order_by(CfoConnection.created_at.desc())

    if user_id is not None:
        stmt = stmt.where(CfoConnection.user_id == user_id)

    result = await db.execute(stmt)
    return list(result.scalars().all())


async def list_all_connections(
    db: AsyncSession,
) -> list[CfoConnection]:
    """List ALL connections across all users (admin only)."""
    stmt = select(CfoConnection).order_by(CfoConnection.created_at.desc())
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def create_connection(
    db: AsyncSession,
    **kwargs,
) -> CfoConnection:
    """Insert a new CFO connection."""
    connection = CfoConnection(**kwargs)
    db.add(connection)
    await db.flush()
    await db.refresh(connection)
    return connection


async def update_connection(
    db: AsyncSession,
    connection_id: UUID,
    **kwargs,
) -> CfoConnection | None:
    """Update a connection by ID."""
    connection = await get_connection_by_id(db, connection_id)
    if connection is None:
        return None

    for key, value in kwargs.items():
        if hasattr(connection, key):
            setattr(connection, key, value)

    await db.flush()
    await db.refresh(connection)
    return connection


async def find_user_primary_connection(
    db: AsyncSession,
    user_id: UUID,
) -> CfoConnection | None:
    """Find the most recent active connection for a user."""
    stmt = (
        select(CfoConnection)
        .where(
            CfoConnection.user_id == user_id,
            CfoConnection.status.in_(["active", "connected", "pending"]),
        )
        .order_by(CfoConnection.created_at.desc())
        .limit(1)
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def count_user_connections(
    db: AsyncSession,
    user_id: UUID,
) -> int:
    """Count active connections for a user."""
    stmt = select(func.count(CfoConnection.id)).where(
        CfoConnection.user_id == user_id,
        CfoConnection.status.in_(["active", "connected", "pending"]),
    )
    result = await db.execute(stmt)
    return result.scalar() or 0


# ---------------------------------------------------------------------------
# CfoMagicLink operations
# ---------------------------------------------------------------------------


async def create_magic_link(
    db: AsyncSession,
    **kwargs,
) -> CfoMagicLink:
    """Insert a new magic link."""
    link = CfoMagicLink(**kwargs)
    db.add(link)
    await db.flush()
    await db.refresh(link)
    return link


async def get_magic_link_by_token(
    db: AsyncSession,
    token: str,
) -> CfoMagicLink | None:
    """Fetch a magic link by its token value."""
    stmt = select(CfoMagicLink).where(CfoMagicLink.token == token)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def mark_magic_link_used(
    db: AsyncSession,
    link_id: UUID,
) -> None:
    """Mark a magic link as used."""
    stmt = (
        update(CfoMagicLink)
        .where(CfoMagicLink.id == link_id)
        .values(used_at=datetime.now(UTC))
    )
    await db.execute(stmt)
    await db.flush()


# ---------------------------------------------------------------------------
# CfoAuthCode operations
# ---------------------------------------------------------------------------


async def create_auth_code(
    db: AsyncSession,
    **kwargs,
) -> CfoAuthCode:
    """Insert a new auth code."""
    code = CfoAuthCode(**kwargs)
    db.add(code)
    await db.flush()
    await db.refresh(code)
    return code


async def get_auth_code_by_code(
    db: AsyncSession,
    code: str,
) -> CfoAuthCode | None:
    """Fetch an auth code by its code value."""
    stmt = select(CfoAuthCode).where(CfoAuthCode.code == code)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def mark_auth_code_used(
    db: AsyncSession,
    code_id: UUID,
) -> None:
    """Mark an auth code as used."""
    stmt = (
        update(CfoAuthCode)
        .where(CfoAuthCode.id == code_id)
        .values(used_at=datetime.now(UTC))
    )
    await db.execute(stmt)
    await db.flush()
