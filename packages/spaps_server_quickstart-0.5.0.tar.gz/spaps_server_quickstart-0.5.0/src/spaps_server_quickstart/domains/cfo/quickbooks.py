"""QuickBooks / Intuit API client.

Handles OAuth token exchange, company info retrieval, and user info
retrieval using httpx. This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import base64
import logging
from typing import Any
from urllib.parse import urlencode

import httpx

logger = logging.getLogger(__name__)

# Intuit OAuth endpoints
INTUIT_AUTH_URL = "https://appcenter.intuit.com/connect/oauth2"
INTUIT_TOKEN_URL = "https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer"
INTUIT_REVOKE_URL = "https://developer.api.intuit.com/v2/oauth2/tokens/revoke"
INTUIT_USERINFO_URL = "https://accounts.platform.intuit.com/v1/openid_connect/userinfo"

# QuickBooks API base
QB_API_BASE = "https://quickbooks.api.intuit.com/v3"


def build_authorization_url(
    *,
    client_id: str,
    redirect_uri: str,
    state: str,
    scope: str = "com.intuit.quickbooks.accounting openid profile email",
) -> str:
    """Build the Intuit OAuth2 authorization URL."""
    params = {
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "response_type": "code",
        "scope": scope,
        "state": state,
    }
    return f"{INTUIT_AUTH_URL}?{urlencode(params)}"


async def exchange_code_for_tokens(
    *,
    code: str,
    redirect_uri: str,
    client_id: str,
    client_secret: str,
) -> dict[str, Any]:
    """Exchange an OAuth authorization code for access and refresh tokens.

    Returns the token response dict from Intuit.
    """
    auth_header = base64.b64encode(
        f"{client_id}:{client_secret}".encode()
    ).decode()

    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.post(
            INTUIT_TOKEN_URL,
            headers={
                "Authorization": f"Basic {auth_header}",
                "Content-Type": "application/x-www-form-urlencoded",
                "Accept": "application/json",
            },
            data={
                "grant_type": "authorization_code",
                "code": code,
                "redirect_uri": redirect_uri,
            },
        )

    if resp.status_code != 200:
        logger.error(
            "Token exchange failed",
            extra={"status": resp.status_code, "body": resp.text},
        )
        raise QuickBooksAPIError(
            f"Token exchange failed: {resp.status_code}"
        )

    return resp.json()


async def fetch_company_info(
    *,
    access_token: str,
    realm_id: str,
) -> dict[str, Any]:
    """Fetch company info from QuickBooks API."""
    url = f"{QB_API_BASE}/company/{realm_id}/companyinfo/{realm_id}"

    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.get(
            url,
            headers={
                "Authorization": f"Bearer {access_token}",
                "Accept": "application/json",
            },
        )

    if resp.status_code != 200:
        logger.warning(
            "Failed to fetch company info",
            extra={"status": resp.status_code, "realm_id": realm_id},
        )
        return {}

    data = resp.json()
    return data.get("CompanyInfo", data)


async def fetch_user_info(
    *,
    access_token: str,
) -> dict[str, Any]:
    """Fetch user info from Intuit's OpenID Connect userinfo endpoint."""
    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.get(
            INTUIT_USERINFO_URL,
            headers={
                "Authorization": f"Bearer {access_token}",
                "Accept": "application/json",
            },
        )

    if resp.status_code != 200:
        logger.warning(
            "Failed to fetch user info",
            extra={"status": resp.status_code},
        )
        return {}

    return resp.json()


async def revoke_token(
    *,
    token: str,
    client_id: str,
    client_secret: str,
) -> bool:
    """Revoke an OAuth token (access or refresh) at Intuit."""
    auth_header = base64.b64encode(
        f"{client_id}:{client_secret}".encode()
    ).decode()

    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.post(
            INTUIT_REVOKE_URL,
            headers={
                "Authorization": f"Basic {auth_header}",
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            json={"token": token},
        )

    if resp.status_code == 200:
        return True

    logger.warning(
        "Token revocation failed",
        extra={"status": resp.status_code},
    )
    return False


class QuickBooksAPIError(Exception):
    """Raised when a QuickBooks API call fails."""

    pass
