"""CFO / QuickBooks domain -- OAuth connection management for SPAPS."""
