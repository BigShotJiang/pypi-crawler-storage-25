"""Pydantic request/response schemas for approval_authz_prod_hardening.

These schemas define the typed API surfaces for governance health,
capability gating, and authz audit events.

Zero FastAPI imports.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Governance Health
# ---------------------------------------------------------------------------


class GovernanceHealthResponse(BaseModel):
    """GET /api/v2/claw-governance/health response."""

    status: Literal["healthy", "degraded"]
    storage_mode: Literal["durable", "degraded"]
    blockers: list[str] = Field(default_factory=list)
    checked_at: str


# ---------------------------------------------------------------------------
# Capability Denied Error Detail
# ---------------------------------------------------------------------------


class CapabilityDeniedErrorDetail(BaseModel):
    """Detail payload for APPROVAL_CAPABILITY_REQUIRED errors."""

    code: Literal["APPROVAL_CAPABILITY_REQUIRED"] = "APPROVAL_CAPABILITY_REQUIRED"
    message: str
    required_capability: Literal["approval_request.read", "approval_request.review"]


# ---------------------------------------------------------------------------
# Governance Persistence Unavailable Error Detail
# ---------------------------------------------------------------------------


class GovernancePersistenceUnavailableErrorDetail(BaseModel):
    """Detail payload for GOVERNANCE_PERSISTENCE_UNAVAILABLE errors."""

    code: Literal["GOVERNANCE_PERSISTENCE_UNAVAILABLE"] = "GOVERNANCE_PERSISTENCE_UNAVAILABLE"
    message: str
    blocker: str


# ---------------------------------------------------------------------------
# Authz Audit Events
# ---------------------------------------------------------------------------


class AuthzAuditEventCreate(BaseModel):
    """Internal schema for creating an authz audit event."""

    principal_type: Literal["human", "machine"]
    principal_id: str
    tenant_id: str
    app_id: str
    approval_id: str | None = None
    machine_key_id: str | None = None
    capability: str | None = None
    decision: Literal["allow", "deny", "fail_closed"]
    reason_code: str


class AuthzAuditEventResponse(BaseModel):
    """Response schema for an authz audit event."""

    id: str
    seq: int
    principal_type: str
    principal_id: str
    tenant_id: str
    app_id: str
    approval_id: str | None = None
    machine_key_id: str | None = None
    capability: str | None = None
    decision: str
    reason_code: str
    created_at: str
