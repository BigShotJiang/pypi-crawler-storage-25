"""SQLAlchemy models for the approval_authz_prod_hardening domain.

Defines the governance_authz_audit_events table for auditable authorization
decisions. Other governance tables (machine_keys, scopes, rate_limit_counters,
idempotency) are defined in the claw_credentials_governance domain and are
referenced here via foreign keys where needed.

The audit event table captures every allow/deny/fail_closed authorization
decision with principal, tenant, app, capability, and reason code context.
"""

from __future__ import annotations

from datetime import datetime
from uuid import UUID, uuid4

from sqlalchemy import (
    DateTime,
    Index,
    Integer,
    String,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column

from .._db import Base, PGUUID


class GovernanceAuthzAuditEvent(Base):
    """Auditable record of an authorization decision.

    Every allow, deny, and fail_closed decision on governance-protected
    endpoints produces one row. Immutable once created.
    """

    __tablename__ = "governance_authz_audit_events"

    seq: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True,
    )
    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        unique=True,
        nullable=False,
        default=uuid4,
    )
    principal_type: Mapped[str] = mapped_column(
        String(20),
        nullable=False,
        comment="human or machine",
    )
    principal_id: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
        comment="user_id or machine_key_id",
    )
    tenant_id: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
    )
    app_id: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
    )
    approval_id: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
        comment="Target approval ID if applicable",
    )
    machine_key_id: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
        comment="Machine key ID if principal_type=machine",
    )
    capability: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True,
        comment="Capability or scope evaluated",
    )
    decision: Mapped[str] = mapped_column(
        String(20),
        nullable=False,
        comment="allow, deny, or fail_closed",
    )
    reason_code: Mapped[str] = mapped_column(
        String(100),
        nullable=False,
        comment="Machine-readable reason code matching shared.md deny matrix",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
    )

    __table_args__ = (
        Index(
            "ix_gov_authz_audit_tenant_created",
            "tenant_id",
            "created_at",
        ),
        Index(
            "ix_gov_authz_audit_principal",
            "principal_type",
            "principal_id",
        ),
        Index(
            "ix_gov_authz_audit_decision",
            "decision",
            "reason_code",
        ),
        Index(
            "ix_gov_authz_audit_approval",
            "approval_id",
            postgresql_where="approval_id IS NOT NULL",
        ),
        Index(
            "ix_gov_authz_audit_machine_key",
            "machine_key_id",
            postgresql_where="machine_key_id IS NOT NULL",
        ),
    )

    def __repr__(self) -> str:
        return (
            f"<GovernanceAuthzAuditEvent "
            f"seq={self.seq} decision={self.decision!r} "
            f"reason={self.reason_code!r}>"
        )
