"""Business logic for the approval_authz_prod_hardening domain.

Coordinates authorization evaluation, governance health checks,
capability gating, durable state verification, and audit event emission.

This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from . import repository as repo
from .errors import (
    ApprovalCapabilityRequiredError,
    GovernancePersistenceUnavailableError,
    MachineScopeDeniedError,
    NotAuthorizedError,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Governance Health
# ---------------------------------------------------------------------------


async def evaluate_governance_health(db: AsyncSession) -> dict[str, Any]:
    """Evaluate governance authorization readiness.

    Returns a typed health payload matching the GovernanceHealthResponse
    schema from shared.md.

    Algorithm (from backend.md):
    1. Evaluate durable-state dependency availability.
    2. Evaluate whether protected mutation guarantees can currently be met.
    3. Return status and blockers for operational gates.
    """
    checked_at = datetime.now(UTC).isoformat()
    blockers: list[str] = []

    try:
        persistence_ok = await repo.check_persistence_available(db)
    except Exception:
        logger.warning("Governance health: persistence check exception", exc_info=True)
        persistence_ok = False

    if not persistence_ok:
        blockers.append("GOVERNANCE_PERSISTENCE_UNAVAILABLE")

    status = "healthy" if not blockers else "degraded"
    storage_mode = "durable" if persistence_ok else "degraded"

    return {
        "status": status,
        "storage_mode": storage_mode,
        "blockers": blockers,
        "checked_at": checked_at,
    }


# ---------------------------------------------------------------------------
# Persistence Availability
# ---------------------------------------------------------------------------


async def is_persistence_available(db: AsyncSession) -> bool:
    """Check whether durable governance state is available.

    Returns True if the persistence layer is reachable, False otherwise.
    Safe wrapper that catches exceptions.
    """
    try:
        return await repo.check_persistence_available(db)
    except Exception:
        logger.warning("Persistence availability check failed", exc_info=True)
        return False


# ---------------------------------------------------------------------------
# Durable State Enforcement
# ---------------------------------------------------------------------------


async def ensure_durable_governance_state(db: AsyncSession) -> None:
    """Verify durable governance state is available or fail closed.

    Must be called before any protected governance mutation
    (machine-key lifecycle, social-reply ingest, etc.).

    Raises GovernancePersistenceUnavailableError if persistence is degraded.
    """
    try:
        available = await repo.check_persistence_available(db)
    except Exception:
        logger.warning("Durable state check exception -- failing closed", exc_info=True)
        available = False

    if not available:
        raise GovernancePersistenceUnavailableError(
            blocker="GOVERNANCE_PERSISTENCE_UNAVAILABLE",
            message="Governance persistence is unavailable for protected mutation",
        )


# ---------------------------------------------------------------------------
# Capability Gate
# ---------------------------------------------------------------------------


def check_capability(
    capabilities: list[str],
    required_capability: str,
) -> None:
    """Enforce that the caller has the required endpoint capability.

    This check runs BEFORE participant/object-level policy (Rule 2).

    Raises ApprovalCapabilityRequiredError if the capability is missing.
    """
    if required_capability not in (capabilities or []):
        raise ApprovalCapabilityRequiredError(
            required_capability=required_capability,
        )


# ---------------------------------------------------------------------------
# Participant Authorization
# ---------------------------------------------------------------------------


def check_participant_authorization(
    *,
    is_participant: bool,
) -> None:
    """Enforce participant/object-level authorization.

    This check runs AFTER capability gate (Rule 3).

    Raises NotAuthorizedError if the caller is not a valid participant.
    """
    if not is_participant:
        raise NotAuthorizedError(
            message="Not authorized: caller is not a participant for this resource",
        )


# ---------------------------------------------------------------------------
# Machine Scope Validation
# ---------------------------------------------------------------------------


def check_machine_scope(
    key_scopes: list[str] | None,
    required_scope: str,
) -> None:
    """Validate that a machine key has the required scope.

    Unlike agent scope matching (prefix), machine scope requires exact match.

    Raises MachineScopeDeniedError if the scope is missing.
    """
    if not key_scopes or required_scope not in key_scopes:
        raise MachineScopeDeniedError(required_scope=required_scope)


# ---------------------------------------------------------------------------
# Authz Audit Events
# ---------------------------------------------------------------------------


async def emit_authz_audit_event(
    db: AsyncSession,
    *,
    principal_type: str,
    principal_id: str,
    tenant_id: str,
    app_id: str,
    approval_id: str | None = None,
    machine_key_id: str | None = None,
    capability: str | None = None,
    decision: str,
    reason_code: str,
) -> None:
    """Emit an authorization audit event (Rule 5).

    Audit writes must never break the request path. If the write fails,
    the error is logged but not propagated.
    """
    try:
        await repo.create_authz_audit_event(
            db,
            principal_type=principal_type,
            principal_id=principal_id,
            tenant_id=tenant_id,
            app_id=app_id,
            approval_id=approval_id,
            machine_key_id=machine_key_id,
            capability=capability,
            decision=decision,
            reason_code=reason_code,
        )
    except Exception:
        logger.exception(
            "Failed to emit authz audit event: principal=%s decision=%s reason=%s",
            principal_id,
            decision,
            reason_code,
        )
