"""HTTP routes for the approval_authz_prod_hardening domain.

Provides:
1. ``governance_health_router`` -- Governance health endpoint
   GET /api/v2/claw-governance/health

The capability gate and fail-closed behaviors are implemented as
reusable service functions that existing approval/governance routers
call into. This router only exposes the NEW health endpoint.

The response envelope ``{ success, data, error, metadata }`` is
applied automatically by ``ResponseEnvelopeMiddleware`` -- handlers
return the raw *data* portion only.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter

from ...middleware.spaps_deps import (
    Application,
    CurrentUser,
    DbSession,
)
from . import service

logger = logging.getLogger(__name__)


# ===========================================================================
# Governance Health Router
# ===========================================================================

governance_health_router = APIRouter(
    prefix="/v2/claw-governance",
    tags=["claw-governance"],
)


@governance_health_router.get("/health")
async def get_governance_health(
    db: DbSession,
    application: Application,
    user: CurrentUser,
):
    """Report governance authorization readiness.

    Auth: Internal authenticated governance identity (same boundary as
    machine-key governance endpoints).

    Returns typed healthy/degraded status with blocker codes.
    """
    result = await service.evaluate_governance_health(db)
    return result


# ===========================================================================
# Capability Gate Dependency (for use by existing approval routers)
# ===========================================================================


def require_approval_read_capability(user_capabilities: list[str]) -> None:
    """Verify the caller has approval_request.read capability.

    Call this from existing read endpoints (list, detail, timeline, by-code).
    """
    service.check_capability(user_capabilities, "approval_request.read")


def require_approval_review_capability(user_capabilities: list[str]) -> None:
    """Verify the caller has approval_request.review capability.

    Call this from existing decision/finalize endpoints.
    """
    service.check_capability(user_capabilities, "approval_request.review")
