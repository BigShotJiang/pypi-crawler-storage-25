"""approval_authz_prod_hardening domain.

Production hardening of approval/governance authorization:
- Governance health endpoint
- Capability gates on approval endpoints
- Durable governance state
- Fail-closed degraded behavior
- Auditable authorization decisions
"""
