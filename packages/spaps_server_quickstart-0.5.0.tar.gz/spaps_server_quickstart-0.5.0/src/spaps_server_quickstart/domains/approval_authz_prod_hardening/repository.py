"""Data access for the approval_authz_prod_hardening domain.

Provides durable-state checks and audit event persistence.
All functions accept an AsyncSession and return model instances or scalars.
"""

from __future__ import annotations

import logging
from uuid import uuid4

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from .models import GovernanceAuthzAuditEvent

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Persistence Health Check
# ---------------------------------------------------------------------------


async def check_persistence_available(db: AsyncSession) -> bool:
    """Check whether the governance persistence layer is reachable.

    Executes a lightweight query to verify the database connection
    and that the audit event table is accessible.

    Returns True if available, False otherwise.
    """
    try:
        result = await db.execute(text("SELECT 1"))
        result.scalar()
        return True
    except Exception:
        logger.warning("Governance persistence check failed", exc_info=True)
        return False


# ---------------------------------------------------------------------------
# Authz Audit Events
# ---------------------------------------------------------------------------


async def create_authz_audit_event(
    db: AsyncSession,
    *,
    principal_type: str,
    principal_id: str,
    tenant_id: str,
    app_id: str,
    approval_id: str | None = None,
    machine_key_id: str | None = None,
    capability: str | None = None,
    decision: str,
    reason_code: str,
) -> GovernanceAuthzAuditEvent:
    """Persist an authorization audit event.

    Every allow/deny/fail_closed decision is recorded here for
    compliance and investigation purposes.
    """
    event = GovernanceAuthzAuditEvent(
        id=uuid4(),
        principal_type=principal_type,
        principal_id=principal_id,
        tenant_id=tenant_id,
        app_id=app_id,
        approval_id=approval_id,
        machine_key_id=machine_key_id,
        capability=capability,
        decision=decision,
        reason_code=reason_code,
    )
    db.add(event)
    await db.flush()
    await db.refresh(event)
    return event
