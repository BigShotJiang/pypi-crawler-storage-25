"""Domain errors for the approval_authz_prod_hardening domain.

Each error carries a machine-readable code matching the Authorization
Deny Matrix in shared.md (the locked API contract).
"""

from __future__ import annotations

from ..errors import DomainError


# --- Capability / Authorization ---


class ApprovalCapabilityRequiredError(DomainError):
    """Raised when the caller lacks a required approval capability."""

    def __init__(
        self,
        required_capability: str,
        message: str | None = None,
    ) -> None:
        msg = message or f"Missing required capability: {required_capability}"
        super().__init__(
            "APPROVAL_CAPABILITY_REQUIRED",
            msg,
            status_code=403,
            details={"required_capability": required_capability},
        )
        self.required_capability = required_capability


class NotAuthorizedError(DomainError):
    """Raised when the caller fails participant/object-level policy after capability pass."""

    def __init__(self, message: str = "Not authorized") -> None:
        super().__init__("NOT_AUTHORIZED", message, status_code=403)


class MachineScopeDeniedError(DomainError):
    """Raised when a machine key lacks the required scope."""

    def __init__(self, required_scope: str, message: str | None = None) -> None:
        msg = message or f"Machine key lacks required scope: {required_scope}"
        super().__init__(
            "MACHINE_SCOPE_DENIED",
            msg,
            status_code=403,
            details={"required_scope": required_scope},
        )
        self.required_scope = required_scope


class GovernancePersistenceUnavailableError(DomainError):
    """Raised when durable governance state is required but unavailable."""

    def __init__(
        self,
        blocker: str = "GOVERNANCE_PERSISTENCE_UNAVAILABLE",
        message: str = "Governance persistence is unavailable",
    ) -> None:
        super().__init__(
            "GOVERNANCE_PERSISTENCE_UNAVAILABLE",
            message,
            status_code=503,
            details={"blocker": blocker},
        )
        self.blocker = blocker


class RateLimitedError(DomainError):
    """Raised when per-key or per-tenant rate limit is exceeded."""

    def __init__(self, message: str = "Rate limit exceeded") -> None:
        super().__init__("RATE_LIMITED", message, status_code=429)


class GovernanceUnauthorizedError(DomainError):
    """Raised when auth material is missing or invalid on governance endpoints."""

    def __init__(self, message: str = "Authentication required") -> None:
        super().__init__("UNAUTHORIZED", message, status_code=401)
