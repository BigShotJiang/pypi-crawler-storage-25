"""DayRate domain -- day-rate booking and availability for SPAPS applications."""
