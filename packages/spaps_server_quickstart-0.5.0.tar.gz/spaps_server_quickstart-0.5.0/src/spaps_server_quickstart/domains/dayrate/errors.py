"""Domain errors for the dayrate domain."""

from __future__ import annotations

from ..errors import DomainError


class SlotUnavailableError(DomainError):
    """Raised when the requested slot is already booked."""

    def __init__(self, message: str = "Requested slot is already booked") -> None:
        super().__init__("SLOT_UNAVAILABLE", message, status_code=409)


class ConfigNotFoundError(DomainError):
    """Raised when no dayrate config exists for the application."""

    def __init__(self, message: str = "DayRate configuration not found") -> None:
        super().__init__("CONFIG_NOT_FOUND", message, status_code=404)


class NoticePeriodViolationError(DomainError):
    """Raised when a booking is within the minimum notice period."""

    def __init__(self, message: str = "Booking within minimum notice period") -> None:
        super().__init__("NOTICE_PERIOD_VIOLATION", message, status_code=400)


class BookingNotFoundError(DomainError):
    """Raised when a booking is not found."""

    def __init__(self, message: str = "Booking not found") -> None:
        super().__init__("BOOKING_NOT_FOUND", message, status_code=404)


class BookingAlreadyCancelledError(DomainError):
    """Raised when attempting to cancel/reschedule an already cancelled booking."""

    def __init__(self, message: str = "Booking is already cancelled") -> None:
        super().__init__("BOOKING_ALREADY_CANCELLED", message, status_code=400)


class NotBookingOwnerError(DomainError):
    """Raised when caller doesn't own the booking."""

    def __init__(self, message: str = "Not the booking owner") -> None:
        super().__init__("NOT_BOOKING_OWNER", message, status_code=403)


class PolicyNotFoundError(DomainError):
    """Raised when a referenced booking policy doesn't exist."""

    def __init__(self, message: str = "Booking policy not found") -> None:
        super().__init__("POLICY_NOT_FOUND", message, status_code=404)


class PolicyAlreadyExistsError(DomainError):
    """Raised when creating a duplicate (application_id, policy_key)."""

    def __init__(self, message: str = "Booking policy already exists") -> None:
        super().__init__("POLICY_ALREADY_EXISTS", message, status_code=409)


class AllotmentExhaustedError(DomainError):
    """Raised when free bookings used up and no overage allowed."""

    def __init__(self, message: str = "Free booking allotment exhausted") -> None:
        super().__init__("ALLOTMENT_EXHAUSTED", message, status_code=403)
