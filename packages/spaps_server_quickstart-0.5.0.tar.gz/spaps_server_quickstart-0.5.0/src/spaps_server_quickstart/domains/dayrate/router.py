"""HTTP routes for the dayrate domain.

Provides TWO routers:

1. ``dayrate_router`` -- public endpoints under ``/dayrate``
2. ``dayrate_admin_router`` -- admin endpoints under ``/dayrate/admin``

Public endpoints use API Key auth (Application dependency).
Admin endpoints use API Key + JWT + Admin auth.
"""

from __future__ import annotations

import logging
from functools import partial
from typing import Any
from uuid import UUID

import stripe
from fastapi import APIRouter, Query, Request

from ...middleware.spaps_deps import AdminUser, Application, DbSession
from . import service
from .schemas import (
    AllotmentResponse,
    AvailabilityResponse,
    BookingPolicyOut,
    BookMultiRequest,
    BookMultiResponse,
    BookRequest,
    BookResponse,
    CancelRequest,
    CancelResponse,
    CreatePolicyRequest,
    DeletePolicyResponse,
    FreeBookResponse,
    GetConfigResponse,
    ListBookingsResponse,
    ListPoliciesResponse,
    PolicyResponse,
    UpdateConfigRequest,
    UpdateConfigResponse,
    UpdatePolicyRequest,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Stripe adapter
# ---------------------------------------------------------------------------


def _stringify_metadata(metadata: dict[str, Any] | None) -> dict[str, str]:
    """Normalize metadata values to strings for Stripe compatibility."""
    return {k: str(v) for k, v in (metadata or {}).items()}


def _build_multi_checkout_line_items(
    line_items: list[dict[str, Any]],
    *,
    currency: str,
) -> list[stripe.checkout.Session.CreateParamsLineItem]:
    """Build Stripe line items for multi-slot checkout."""
    return [
        {
            "price_data": {
                "currency": currency,
                "unit_amount": item["price"] * 100,
                "product_data": {
                    "name": item["product_name"],
                    "description": item.get("description", ""),
                },
            },
            "quantity": 1,
        }
        for item in line_items
    ]


def _build_single_checkout_line_item(
    *,
    price: int | None,
    product_name: str | None,
    description: str | None,
    currency: str,
    metadata: dict[str, str],
) -> stripe.checkout.Session.CreateParamsLineItem:
    """Build a Stripe line item for single-slot checkout."""
    product_data: stripe.checkout.Session.CreateParamsLineItemPriceDataProductData = {
        "name": product_name or "",
        "metadata": metadata,
    }
    if description:
        product_data["description"] = description
    return {
        "price_data": {
            "currency": currency,
            "unit_amount": (price or 0) * 100,
            "product_data": product_data,
        },
        "quantity": 1,
    }


def _build_checkout_params(
    *,
    client_email: str,
    stripe_line_items: list[stripe.checkout.Session.CreateParamsLineItem],
    success_url: str,
    cancel_url: str,
    metadata: dict[str, str],
    branding_display_name: str | None,
) -> dict[str, Any]:
    """Build common Stripe checkout parameters."""
    checkout_params: dict[str, Any] = {
        "mode": "payment",
        "customer_email": client_email,
        "line_items": stripe_line_items,
        "success_url": success_url,
        "cancel_url": cancel_url,
        "metadata": metadata,
    }
    if branding_display_name:
        checkout_params["branding_settings"] = {"display_name": branding_display_name}
    return checkout_params


async def _create_stripe_checkout(
    settings: Any,
    *,
    # Single-item mode (book_slot)
    price: int | None = None,
    product_name: str | None = None,
    description: str | None = None,
    # Multi-item mode (book_multi)
    line_items: list[dict[str, Any]] | None = None,
    # Common
    currency: str,
    success_url: str,
    cancel_url: str,
    client_email: str,
    metadata: dict,
    branding_display_name: str | None = None,
) -> dict[str, Any]:
    """Create a Stripe checkout session with dynamic price_data.

    Matches Node's DayrateService patterns:
    - book_slot: single line item with price/product_name/description
    - book_multi: multiple line items, one per slot

    Price is in base currency units (dollars for USD); Stripe needs cents.
    """
    stripe.api_key = settings.stripe_secret_key
    str_metadata = _stringify_metadata(metadata)
    stripe_line_items = (
        _build_multi_checkout_line_items(line_items, currency=currency)
        if line_items is not None
        else [
            _build_single_checkout_line_item(
                price=price,
                product_name=product_name,
                description=description,
                currency=currency,
                metadata=str_metadata,
            )
        ]
    )
    checkout_params = _build_checkout_params(
        client_email=client_email,
        stripe_line_items=stripe_line_items,
        success_url=success_url,
        cancel_url=cancel_url,
        metadata=str_metadata,
        branding_display_name=branding_display_name,
    )
    session = stripe.checkout.Session.create(**checkout_params)
    return {"id": session.id, "url": session.url}


_POLICY_UPDATE_FIELD_MAP: dict[str, str] = {
    "entitlementKey": "entitlement_key",
    "freeBookingsPerPeriod": "free_bookings_per_period",
    "periodDays": "period_days",
    "overageRate": "overage_rate",
    "overageCurrency": "overage_currency",
    "overageProductName": "overage_product_name",
    "rescheduleIsFree": "reschedule_is_free",
    "isActive": "is_active",
    "metadata": "metadata",
}


def _build_policy_update_kwargs(body: UpdatePolicyRequest) -> dict[str, Any]:
    """Map non-null update payload fields into service kwargs."""
    update_kwargs: dict[str, Any] = {}
    for body_field, service_field in _POLICY_UPDATE_FIELD_MAP.items():
        value = getattr(body, body_field)
        if value is not None:
            update_kwargs[service_field] = value
    return update_kwargs


# ===========================================================================
# Public Router
# ===========================================================================

dayrate_router = APIRouter(prefix="/dayrate", tags=["dayrate"])


@dayrate_router.get("/availability", response_model=AvailabilityResponse)
async def get_availability(
    db: DbSession,
    app: Application,
) -> AvailabilityResponse:
    """Get available day-rate slots within the booking horizon.

    Requires API key authentication.
    """
    result = await service.get_availability(
        db,
        application_id=app.id,
    )
    return AvailabilityResponse(**result)


@dayrate_router.post("/book")
async def book_slot(
    body: BookRequest,
    db: DbSession,
    app: Application,
    request: Request,
):
    """Book a single day-rate slot.

    Enhanced with policy support: if policyKey is provided and user has
    entitlement with remaining allotment, the booking is auto-confirmed
    (free path). Otherwise, creates a Stripe checkout session (paid path).

    Requires API key authentication.
    """
    settings = request.app.state.settings
    resolved_branding_display_name = (
        body.brandingDisplayName or settings.stripe_checkout_branding_name or None
    )
    if isinstance(resolved_branding_display_name, str):
        resolved_branding_display_name = resolved_branding_display_name.strip() or None

    # Parse optional UUID fields
    user_id = UUID(body.userId) if body.userId else None
    replaces_booking_id = UUID(body.replacesBookingId) if body.replacesBookingId else None

    result = await service.book_slot(
        db,
        application_id=app.id,
        date_str=body.date,
        slot=body.slot,
        client_email=body.clientEmail,
        client_name=body.clientName,
        success_url=body.successUrl,
        cancel_url=body.cancelUrl,
        stripe_create_checkout=partial(_create_stripe_checkout, settings),
        branding_display_name=resolved_branding_display_name,
        policy_key=body.policyKey,
        enrollment_id=body.enrollmentId,
        replaces_booking_id=replaces_booking_id,
        user_id=user_id,
    )

    # Return the right response shape based on the booking path
    if "isFree" in result and result.get("isFree"):
        return FreeBookResponse(**result)
    elif "checkoutUrl" in result:
        return BookResponse(**result)
    else:
        # Reschedule or other non-standard response
        return result


@dayrate_router.post("/book-multi", response_model=BookMultiResponse)
async def book_multi(
    body: BookMultiRequest,
    db: DbSession,
    app: Application,
    request: Request,
) -> BookMultiResponse:
    """Book multiple day-rate slots in a single Stripe checkout session.

    Requires API key authentication.
    """
    settings = request.app.state.settings
    resolved_branding_display_name = (
        body.brandingDisplayName or settings.stripe_checkout_branding_name or None
    )
    if isinstance(resolved_branding_display_name, str):
        resolved_branding_display_name = resolved_branding_display_name.strip() or None

    slots = [{"date": s.date, "slot": s.slot} for s in body.slots]
    result = await service.book_multi(
        db,
        application_id=app.id,
        slots=slots,
        client_email=body.clientEmail,
        client_name=body.clientName,
        success_url=body.successUrl,
        cancel_url=body.cancelUrl,
        stripe_create_checkout=partial(_create_stripe_checkout, settings),
        branding_display_name=resolved_branding_display_name,
    )
    return BookMultiResponse(**result)


@dayrate_router.post("/cancel", response_model=CancelResponse)
async def cancel_booking(
    body: CancelRequest,
    db: DbSession,
    app: Application,
):
    """Cancel a booking by its owner (patient-facing).

    Ownership resolution: user_id match first, email fallback.
    Requires API key authentication.
    """
    booking_id = UUID(body.bookingId)
    user_id = UUID(body.userId) if body.userId else None

    result = await service.cancel_booking_by_owner(
        db,
        application_id=app.id,
        booking_id=booking_id,
        user_id=user_id,
        email=body.email,
    )
    return CancelResponse(**result)


@dayrate_router.get("/allotment", response_model=AllotmentResponse)
async def get_allotment(
    db: DbSession,
    app: Application,
    policyKey: str = Query(..., description="Booking policy key"),
    userId: str | None = Query(default=None, description="User ID"),
    email: str | None = Query(default=None, description="User email (fallback)"),
) -> AllotmentResponse:
    """Check a patient's booking allotment status.

    Requires API key authentication.
    """
    user_id = UUID(userId) if userId else None

    result = await service.check_allotment(
        db,
        application_id=app.id,
        policy_key=policyKey,
        user_id=user_id,
        email=email,
    )
    return AllotmentResponse(**result)


# ===========================================================================
# Admin Router
# ===========================================================================

dayrate_admin_router = APIRouter(
    prefix="/dayrate/admin", tags=["dayrate-admin"]
)


@dayrate_admin_router.get("/config", response_model=GetConfigResponse)
async def get_config(
    db: DbSession,
    app: Application,
    admin: AdminUser,
) -> GetConfigResponse:
    """Get the dayrate configuration for the application.

    Requires API key + JWT (admin).
    """
    result = await service.get_config(
        db,
        application_id=app.id,
    )
    return GetConfigResponse(**result)


@dayrate_admin_router.put("/config", response_model=UpdateConfigResponse)
async def update_config(
    body: UpdateConfigRequest,
    db: DbSession,
    app: Application,
    admin: AdminUser,
) -> UpdateConfigResponse:
    """Update (upsert) the dayrate configuration.

    Requires API key + JWT (admin).
    """
    result = await service.update_config(
        db,
        application_id=app.id,
        base_rate=body.base_rate,
        available_days=body.available_days,
        slots=body.slots,
        fill_tiers=body.fill_tiers,
        time_tiers=body.time_tiers,
        horizon_weeks=body.horizon_weeks,
        meeting_link=body.meeting_link,
        min_notice_hours=body.min_notice_hours,
        hold_duration_minutes=body.hold_duration_minutes,
        timezone=body.timezone,
        slot_definitions=body.slot_definitions,
        currency=body.currency,
        product_name=body.product_name,
    )
    return UpdateConfigResponse(**result)


@dayrate_admin_router.get("/bookings", response_model=ListBookingsResponse)
async def list_bookings(
    db: DbSession,
    app: Application,
    admin: AdminUser,
    status: str | None = Query(default=None),
    startDate: str | None = Query(default=None),
    endDate: str | None = Query(default=None),
    clientEmail: str | None = Query(default=None),
    enrollmentId: str | None = Query(default=None),
    userId: str | None = Query(default=None),
    isFree: bool | None = Query(default=None),
    limit: int = Query(default=100, ge=1, le=1000),
    offset: int = Query(default=0, ge=0),
) -> ListBookingsResponse:
    """List bookings for admin view.

    Enhanced with new filters: clientEmail, enrollmentId, userId, isFree.
    Requires API key + JWT (admin).
    """
    result = await service.list_bookings(
        db,
        application_id=app.id,
        status=status,
        start_date=startDate,
        end_date=endDate,
        client_email=clientEmail,
        enrollment_id=enrollmentId,
        user_id_filter=userId,
        is_free=isFree,
        limit=limit,
        offset=offset,
    )
    return ListBookingsResponse(**result)


# ---------------------------------------------------------------------------
# Policy CRUD (admin)
# ---------------------------------------------------------------------------


@dayrate_admin_router.get("/policies", response_model=ListPoliciesResponse)
async def list_policies(
    db: DbSession,
    app: Application,
    admin: AdminUser,
) -> ListPoliciesResponse:
    """List all active booking policies for the application.

    Requires API key + JWT (admin).
    """
    policies = await service.list_booking_policies(db, application_id=app.id)
    return ListPoliciesResponse(
        policies=[BookingPolicyOut(**p) for p in policies]
    )


@dayrate_admin_router.post(
    "/policies",
    response_model=PolicyResponse,
    status_code=201,
)
async def create_policy(
    body: CreatePolicyRequest,
    db: DbSession,
    app: Application,
    admin: AdminUser,
) -> PolicyResponse:
    """Create a booking policy.

    Requires API key + JWT (admin).
    """
    result = await service.create_booking_policy(
        db,
        application_id=app.id,
        policy_key=body.policyKey,
        entitlement_key=body.entitlementKey,
        free_bookings_per_period=body.freeBookingsPerPeriod,
        period_days=body.periodDays,
        overage_rate=body.overageRate,
        overage_currency=body.overageCurrency,
        overage_product_name=body.overageProductName,
        reschedule_is_free=body.rescheduleIsFree,
        metadata=body.metadata,
    )
    return PolicyResponse(policy=BookingPolicyOut(**result))


@dayrate_admin_router.put("/policies/{policy_id}", response_model=PolicyResponse)
async def update_policy(
    policy_id: str,
    body: UpdatePolicyRequest,
    db: DbSession,
    app: Application,
    admin: AdminUser,
) -> PolicyResponse:
    """Update a booking policy (partial update).

    Requires API key + JWT (admin).
    """
    pid = UUID(policy_id)

    result = await service.update_booking_policy(
        db,
        policy_id=pid,
        application_id=app.id,
        **_build_policy_update_kwargs(body),
    )
    return PolicyResponse(policy=BookingPolicyOut(**result))


@dayrate_admin_router.delete("/policies/{policy_id}", response_model=DeletePolicyResponse)
async def delete_policy(
    policy_id: str,
    db: DbSession,
    app: Application,
    admin: AdminUser,
) -> DeletePolicyResponse:
    """Delete a booking policy.

    Existing bookings referencing this policy_key are not affected (no FK).
    Requires API key + JWT (admin).
    """
    pid = UUID(policy_id)
    result = await service.delete_booking_policy(
        db,
        policy_id=pid,
        application_id=app.id,
    )
    return DeletePolicyResponse(**result)
