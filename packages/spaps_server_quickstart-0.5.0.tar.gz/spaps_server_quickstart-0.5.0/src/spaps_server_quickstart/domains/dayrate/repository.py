"""Database operations for the dayrate domain.

Pure SQLAlchemy async repository -- no FastAPI imports.
All functions accept an ``AsyncSession`` as the first positional argument.
"""

from __future__ import annotations

import datetime as dt
import logging
from typing import Any
from uuid import UUID

from sqlalchemy import CursorResult, delete, func, or_, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from .models import BookingPolicy, DayRateBooking, DayRateConfig

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------


async def get_config(
    db: AsyncSession,
    application_id: UUID,
) -> DayRateConfig | None:
    """Fetch the dayrate config for an application."""
    stmt = select(DayRateConfig).where(
        DayRateConfig.application_id == application_id
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def upsert_config(
    db: AsyncSession,
    application_id: UUID,
    **kwargs: Any,
) -> DayRateConfig:
    """Create or update the dayrate config for an application.

    If a config already exists, updates the provided fields.
    Otherwise, creates a new config row.
    """
    existing = await get_config(db, application_id)

    if existing is not None:
        for key, value in kwargs.items():
            if value is not None and hasattr(existing, key):
                setattr(existing, key, value)
        existing.updated_at = dt.datetime.now(dt.UTC)
        await db.flush()
        await db.refresh(existing)
        return existing

    config = DayRateConfig(application_id=application_id, **kwargs)
    db.add(config)
    await db.flush()
    await db.refresh(config)
    return config


# ---------------------------------------------------------------------------
# Bookings
# ---------------------------------------------------------------------------


async def get_booking_by_id(
    db: AsyncSession,
    booking_id: UUID,
) -> DayRateBooking | None:
    """Fetch a single booking by ID."""
    stmt = select(DayRateBooking).where(DayRateBooking.id == booking_id)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def get_bookings_for_date(
    db: AsyncSession,
    application_id: UUID,
    date: dt.date,
) -> list[DayRateBooking]:
    """Get all active bookings for a specific date.

    Excludes cancelled bookings, expired bookings, and pending bookings
    whose hold has elapsed (expires_at < now).
    """
    now = dt.datetime.now(dt.UTC)
    stmt = (
        select(DayRateBooking)
        .where(
            DayRateBooking.application_id == application_id,
            DayRateBooking.date == date,
            DayRateBooking.status.notin_(["cancelled", "expired"]),
            # Exclude pending bookings whose hold has expired
            ~(
                (DayRateBooking.status == "pending")
                & (DayRateBooking.expires_at.isnot(None))
                & (DayRateBooking.expires_at < now)
            ),
        )
        .order_by(DayRateBooking.slot_type)
    )
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def get_bookings_in_range(
    db: AsyncSession,
    application_id: UUID,
    start_date: dt.date,
    end_date: dt.date,
) -> list[DayRateBooking]:
    """Get all active bookings within a date range.

    Excludes cancelled bookings, expired bookings, and pending bookings
    whose hold has elapsed (expires_at < now).
    """
    now = dt.datetime.now(dt.UTC)
    stmt = (
        select(DayRateBooking)
        .where(
            DayRateBooking.application_id == application_id,
            DayRateBooking.date >= start_date,
            DayRateBooking.date <= end_date,
            DayRateBooking.status.notin_(["cancelled", "expired"]),
            ~(
                (DayRateBooking.status == "pending")
                & (DayRateBooking.expires_at.isnot(None))
                & (DayRateBooking.expires_at < now)
            ),
        )
        .order_by(DayRateBooking.date, DayRateBooking.slot_type)
    )
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def create_booking(
    db: AsyncSession,
    **kwargs: Any,
) -> DayRateBooking:
    """Insert a new booking and return the persisted instance."""
    booking = DayRateBooking(**kwargs)
    db.add(booking)
    await db.flush()
    await db.refresh(booking)
    return booking


async def expire_stale_pendings(
    db: AsyncSession,
    application_id: UUID,
    date: dt.date,
    slot_type: str,
) -> int:
    """Flip stale pending bookings to 'expired' for a specific date+slot.

    A pending booking is stale when its expires_at has passed.
    Returns the number of rows updated.
    """
    now = dt.datetime.now(dt.UTC)
    stmt = (
        update(DayRateBooking)
        .where(
            DayRateBooking.application_id == application_id,
            DayRateBooking.date == date,
            DayRateBooking.slot_type == slot_type,
            DayRateBooking.status == "pending",
            DayRateBooking.expires_at.isnot(None),
            DayRateBooking.expires_at < now,
        )
        .values(status="expired", updated_at=now)
    )
    result: CursorResult[Any] = await db.execute(stmt)  # type: ignore[assignment]
    return result.rowcount


async def update_booking(
    db: AsyncSession,
    booking_id: UUID,
    **kwargs: Any,
) -> DayRateBooking | None:
    """Update a booking by ID."""
    booking = await get_booking_by_id(db, booking_id)
    if booking is None:
        return None

    for key, value in kwargs.items():
        if key == "metadata":
            booking.metadata_ = value
        elif hasattr(booking, key):
            setattr(booking, key, value)

    booking.updated_at = dt.datetime.now(dt.UTC)
    await db.flush()
    await db.refresh(booking)
    return booking


async def list_bookings(
    db: AsyncSession,
    application_id: UUID,
    *,
    status: str | None = None,
    start_date: dt.date | None = None,
    end_date: dt.date | None = None,
    client_email: str | None = None,
    enrollment_id: str | None = None,
    user_id: UUID | None = None,
    is_free: bool | None = None,
    limit: int = 100,
    offset: int = 0,
) -> tuple[list[DayRateBooking], int]:
    """List bookings with optional filters.

    Returns (bookings, total_count).
    Enhanced with new filter params for checkin_call_booking.
    """
    stmt = (
        select(DayRateBooking)
        .where(DayRateBooking.application_id == application_id)
    )

    if status is not None:
        stmt = stmt.where(DayRateBooking.status == status)
    if start_date is not None:
        stmt = stmt.where(DayRateBooking.date >= start_date)
    if end_date is not None:
        stmt = stmt.where(DayRateBooking.date <= end_date)
    if client_email is not None:
        stmt = stmt.where(DayRateBooking.client_email == client_email)
    if enrollment_id is not None:
        stmt = stmt.where(DayRateBooking.enrollment_id == enrollment_id)
    if user_id is not None:
        stmt = stmt.where(DayRateBooking.user_id == user_id)
    if is_free is not None:
        stmt = stmt.where(DayRateBooking.is_free == is_free)

    # Get total count via SQL COUNT (same filters, no limit/offset)
    count_stmt = select(func.count()).select_from(DayRateBooking).where(
        DayRateBooking.application_id == application_id
    )
    if status is not None:
        count_stmt = count_stmt.where(DayRateBooking.status == status)
    if start_date is not None:
        count_stmt = count_stmt.where(DayRateBooking.date >= start_date)
    if end_date is not None:
        count_stmt = count_stmt.where(DayRateBooking.date <= end_date)
    if client_email is not None:
        count_stmt = count_stmt.where(DayRateBooking.client_email == client_email)
    if enrollment_id is not None:
        count_stmt = count_stmt.where(DayRateBooking.enrollment_id == enrollment_id)
    if user_id is not None:
        count_stmt = count_stmt.where(DayRateBooking.user_id == user_id)
    if is_free is not None:
        count_stmt = count_stmt.where(DayRateBooking.is_free == is_free)
    total = (await db.execute(count_stmt)).scalar() or 0

    # Apply ordering and pagination
    stmt = stmt.order_by(DayRateBooking.date.desc(), DayRateBooking.created_at.desc())
    stmt = stmt.limit(limit).offset(offset)

    result = await db.execute(stmt)
    bookings = list(result.scalars().all())

    return bookings, total


# ---------------------------------------------------------------------------
# Booking with row-level locking (reschedule)
# ---------------------------------------------------------------------------


async def get_booking_by_id_for_update(
    db: AsyncSession,
    booking_id: UUID,
) -> DayRateBooking | None:
    """Fetch a booking with FOR UPDATE lock for atomic operations."""
    stmt = (
        select(DayRateBooking)
        .where(DayRateBooking.id == booking_id)
        .with_for_update()
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


# ---------------------------------------------------------------------------
# Booking Policies
# ---------------------------------------------------------------------------


async def get_booking_policy_by_key(
    db: AsyncSession,
    application_id: UUID,
    policy_key: str,
) -> BookingPolicy | None:
    """Fetch a booking policy by (application_id, policy_key)."""
    stmt = select(BookingPolicy).where(
        BookingPolicy.application_id == application_id,
        BookingPolicy.policy_key == policy_key,
        BookingPolicy.is_active.is_(True),
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def get_booking_policy_by_id(
    db: AsyncSession,
    policy_id: UUID,
    application_id: UUID,
) -> BookingPolicy | None:
    """Fetch a booking policy by ID scoped to application."""
    stmt = select(BookingPolicy).where(
        BookingPolicy.id == policy_id,
        BookingPolicy.application_id == application_id,
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def lock_policy_for_allotment(
    db: AsyncSession,
    application_id: UUID,
    policy_key: str,
) -> BookingPolicy | None:
    """Lock the policy row (FOR UPDATE) to serialize allotment checks.

    This prevents race conditions where two concurrent requests both
    read remaining=1 and both get a free booking.
    """
    stmt = (
        select(BookingPolicy)
        .where(
            BookingPolicy.application_id == application_id,
            BookingPolicy.policy_key == policy_key,
            BookingPolicy.is_active.is_(True),
        )
        .with_for_update()
    )
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def create_booking_policy(
    db: AsyncSession,
    **kwargs: Any,
) -> BookingPolicy:
    """Insert a new booking policy and return the persisted instance."""
    policy = BookingPolicy(**kwargs)
    db.add(policy)
    await db.flush()
    await db.refresh(policy)
    return policy


async def update_booking_policy(
    db: AsyncSession,
    policy_id: UUID,
    application_id: UUID,
    **kwargs: Any,
) -> BookingPolicy | None:
    """Update a booking policy by ID scoped to application."""
    policy = await get_booking_policy_by_id(db, policy_id, application_id)
    if policy is None:
        return None

    for key, value in kwargs.items():
        if key == "metadata":
            policy.metadata_ = value
        elif hasattr(policy, key):
            setattr(policy, key, value)

    policy.updated_at = dt.datetime.now(dt.UTC)
    await db.flush()
    await db.refresh(policy)
    return policy


async def delete_booking_policy(
    db: AsyncSession,
    policy_id: UUID,
    application_id: UUID,
) -> bool:
    """Delete a booking policy. Returns True if deleted, False if not found."""
    policy = await get_booking_policy_by_id(db, policy_id, application_id)
    if policy is None:
        return False

    stmt = delete(BookingPolicy).where(
        BookingPolicy.id == policy_id,
        BookingPolicy.application_id == application_id,
    )
    await db.execute(stmt)
    await db.flush()
    return True


async def list_booking_policies(
    db: AsyncSession,
    application_id: UUID,
) -> list[BookingPolicy]:
    """List all active booking policies for an application."""
    stmt = (
        select(BookingPolicy)
        .where(
            BookingPolicy.application_id == application_id,
            BookingPolicy.is_active.is_(True),
        )
        .order_by(BookingPolicy.created_at.asc())
    )
    result = await db.execute(stmt)
    return list(result.scalars().all())


# ---------------------------------------------------------------------------
# Allotment counting
# ---------------------------------------------------------------------------


async def count_allotment_bookings(
    db: AsyncSession,
    application_id: UUID,
    period_start: dt.datetime,
    *,
    user_id: UUID | None = None,
    email: str | None = None,
) -> int:
    """Count non-cancelled, non-reschedule bookings in the rolling window.

    Matches by user_id (primary) OR client_email (fallback for legacy bookings).
    Only counts bookings where replaces_booking_id IS NULL (new bookings).
    """
    stmt = (
        select(func.count())
        .select_from(DayRateBooking)
        .where(
            DayRateBooking.application_id == application_id,
            DayRateBooking.status != "cancelled",
            DayRateBooking.replaces_booking_id.is_(None),
            DayRateBooking.created_at >= period_start,
        )
    )

    # Match by user_id or email
    if user_id is not None and email is not None:
        stmt = stmt.where(
            or_(
                DayRateBooking.user_id == user_id,
                DayRateBooking.client_email == email,
            )
        )
    elif user_id is not None:
        stmt = stmt.where(DayRateBooking.user_id == user_id)
    elif email is not None:
        stmt = stmt.where(DayRateBooking.client_email == email)

    result = await db.execute(stmt)
    return result.scalar() or 0


# ---------------------------------------------------------------------------
# Upcoming bookings (for user batch)
# ---------------------------------------------------------------------------


async def get_upcoming_bookings_by_user_ids(
    db: AsyncSession,
    application_id: UUID,
    user_ids: list[UUID],
    start_date: dt.date,
    end_date: dt.date,
) -> list[DayRateBooking]:
    """Get non-cancelled upcoming bookings for users by user_id."""
    if not user_ids:
        return []
    stmt = (
        select(DayRateBooking)
        .where(
            DayRateBooking.application_id == application_id,
            DayRateBooking.user_id.in_(user_ids),
            DayRateBooking.date >= start_date,
            DayRateBooking.date <= end_date,
            DayRateBooking.status != "cancelled",
        )
        .order_by(DayRateBooking.date.asc())
    )
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def get_upcoming_bookings_by_emails(
    db: AsyncSession,
    application_id: UUID,
    emails: list[str],
    start_date: dt.date,
    end_date: dt.date,
) -> list[DayRateBooking]:
    """Get non-cancelled upcoming bookings for legacy bookings (no user_id) by email."""
    if not emails:
        return []
    stmt = (
        select(DayRateBooking)
        .where(
            DayRateBooking.application_id == application_id,
            DayRateBooking.user_id.is_(None),
            DayRateBooking.client_email.in_(emails),
            DayRateBooking.date >= start_date,
            DayRateBooking.date <= end_date,
            DayRateBooking.status != "cancelled",
        )
        .order_by(DayRateBooking.date.asc())
    )
    result = await db.execute(stmt)
    return list(result.scalars().all())
