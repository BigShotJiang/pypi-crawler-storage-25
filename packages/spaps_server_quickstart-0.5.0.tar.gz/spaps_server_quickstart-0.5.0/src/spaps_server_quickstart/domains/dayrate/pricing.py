"""Day-rate pricing calculation.

Matches the Node/Express legacy pricing engine:
- Fill tiers use {maxPercent, multiplier} — picks ONE tier (first where
  fillPercent <= maxPercent, sorted ascending). Does NOT cascade.
- Time tiers use {minDays, multiplier} — picks ONE tier (first where
  daysUntil >= minDays, sorted descending). Does NOT cascade.
- Final price uses round() (nearest integer) to match JS Math.round().

This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations


def calculate_price(
    *,
    base_rate: int,
    fill_percent: float,
    days_until: int,
    fill_tiers: list[dict] | None = None,
    time_tiers: list[dict] | None = None,
) -> int:
    """Calculate the price for a slot.

    Args:
        base_rate: Base price in cents.
        fill_percent: Percentage of slots filled across the horizon (0-100).
        days_until: Number of days until the booking date.
        fill_tiers: List of {maxPercent: float, multiplier: float} dicts.
            Sorted by maxPercent ascending; first tier where
            fillPercent <= maxPercent applies. Single-pick, not cascading.
        time_tiers: List of {minDays: int, multiplier: float} dicts.
            Sorted by minDays descending; first tier where
            daysUntil >= minDays applies. Single-pick, not cascading.

    Returns:
        Final price in cents (integer, rounded to nearest).
    """
    fill_multiplier = 1.0
    time_multiplier = 1.0

    # Apply fill tier multiplier — single pick
    if fill_tiers:
        sorted_tiers = sorted(fill_tiers, key=lambda t: t.get("maxPercent", 0))
        for tier in sorted_tiers:
            if fill_percent <= tier.get("maxPercent", 0):
                fill_multiplier = tier.get("multiplier", 1.0)
                break
        else:
            # Above all tiers — use the highest tier's multiplier
            fill_multiplier = sorted_tiers[-1].get("multiplier", 1.0)

    # Apply time tier multiplier — single pick
    if time_tiers:
        sorted_tiers = sorted(
            time_tiers, key=lambda t: t.get("minDays", 0), reverse=True
        )
        for tier in sorted_tiers:
            if days_until >= tier.get("minDays", 0):
                time_multiplier = tier.get("multiplier", 1.0)
                break
        else:
            # Below all tiers — use the lowest tier's multiplier
            time_multiplier = sorted_tiers[-1].get("multiplier", 1.0)

    return round(base_rate * fill_multiplier * time_multiplier)


def calculate_price_with_breakdown(
    *,
    base_rate: int,
    fill_percent: float,
    days_until: int,
    fill_tiers: list[dict] | None = None,
    time_tiers: list[dict] | None = None,
) -> dict:
    """Calculate the price for a slot and return a full breakdown.

    Returns:
        Dict with camelCase keys matching the SDK/Node contract:
        ``{baseRate, fillMultiplier, timeMultiplier, finalPrice}``
    """
    fill_multiplier = 1.0
    time_multiplier = 1.0

    if fill_tiers:
        sorted_tiers = sorted(fill_tiers, key=lambda t: t.get("maxPercent", 0))
        for tier in sorted_tiers:
            if fill_percent <= tier.get("maxPercent", 0):
                fill_multiplier = tier.get("multiplier", 1.0)
                break
        else:
            fill_multiplier = sorted_tiers[-1].get("multiplier", 1.0)

    if time_tiers:
        sorted_tiers = sorted(
            time_tiers, key=lambda t: t.get("minDays", 0), reverse=True
        )
        for tier in sorted_tiers:
            if days_until >= tier.get("minDays", 0):
                time_multiplier = tier.get("multiplier", 1.0)
                break
        else:
            time_multiplier = sorted_tiers[-1].get("multiplier", 1.0)

    final_price = round(base_rate * fill_multiplier * time_multiplier)

    return {
        "baseRate": base_rate,
        "fillMultiplier": fill_multiplier,
        "timeMultiplier": time_multiplier,
        "finalPrice": final_price,
    }
