"""SQLAlchemy models for the dayrate domain."""

from __future__ import annotations

import datetime as dt
from typing import Any
from uuid import UUID, uuid4

from sqlalchemy import (
    Boolean,
    Date,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    Text,
    UniqueConstraint,
    func,
    text,
)
from sqlalchemy.dialects.postgresql import ARRAY, JSON
from sqlalchemy.orm import Mapped, mapped_column

from .._db import Base, PGUUID


class DayRateConfig(Base):
    """Per-application dayrate configuration.

    Controls pricing, availability windows, slot definitions, and
    horizon limits for the day-rate booking system.
    """

    __tablename__ = "dayrate_config"

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    application_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("applications.id", ondelete="CASCADE"),
        nullable=False,
    )
    base_rate: Mapped[int] = mapped_column(Integer, nullable=False)
    available_days: Mapped[list[str] | None] = mapped_column(
        ARRAY(Text), nullable=True
    )
    slots: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)
    fill_tiers: Mapped[list[dict[str, Any]] | None] = mapped_column(
        JSON, nullable=True
    )
    time_tiers: Mapped[list[dict[str, Any]] | None] = mapped_column(
        JSON, nullable=True
    )
    horizon_weeks: Mapped[int] = mapped_column(
        Integer, nullable=False, server_default="4"
    )
    meeting_link: Mapped[str | None] = mapped_column(Text, nullable=True)
    min_notice_hours: Mapped[int] = mapped_column(
        Integer, nullable=False, server_default="24"
    )
    hold_duration_minutes: Mapped[int] = mapped_column(
        Integer, nullable=False, server_default="30"
    )
    timezone: Mapped[str] = mapped_column(
        Text, nullable=False, server_default="'America/New_York'"
    )
    slot_definitions: Mapped[dict[str, Any] | None] = mapped_column(
        JSON, nullable=True
    )
    currency: Mapped[str] = mapped_column(
        Text, nullable=False, server_default="'usd'"
    )
    product_name: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[dt.datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    updated_at: Mapped[dt.datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    def __repr__(self) -> str:
        return f"<DayRateConfig app={self.application_id!r} rate={self.base_rate}>"


class DayRateBooking(Base):
    """A single day-rate booking.

    Created in 'pending' status when a checkout session is initiated.
    Transitions to 'confirmed' when the Stripe webhook fires.
    """

    __tablename__ = "dayrate_bookings"
    __table_args__ = (
        Index(
            "idx_dayrate_bookings_active_slot",
            "application_id",
            "date",
            "slot_type",
            unique=True,
            postgresql_where=text("status NOT IN ('cancelled', 'expired')"),
        ),
    )

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    application_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("applications.id", ondelete="CASCADE"),
        nullable=False,
    )
    user_id: Mapped[UUID | None] = mapped_column(
        PGUUID(as_uuid=True), nullable=True
    )
    date: Mapped[dt.date] = mapped_column(Date, nullable=False)
    slot_type: Mapped[str] = mapped_column(Text, nullable=False)
    client_email: Mapped[str] = mapped_column(Text, nullable=False)
    client_name: Mapped[str] = mapped_column(Text, nullable=False)
    price_paid: Mapped[int] = mapped_column(Integer, nullable=False)
    stripe_session_id: Mapped[str | None] = mapped_column(Text, nullable=True)
    stripe_payment_intent_id: Mapped[str | None] = mapped_column(
        Text, nullable=True
    )
    status: Mapped[str] = mapped_column(
        Text, nullable=False, server_default="'pending'"
    )
    metadata_: Mapped[dict[str, Any] | None] = mapped_column(
        "metadata", JSON, nullable=True, default=dict
    )
    booking_group_id: Mapped[str | None] = mapped_column(Text, nullable=True)
    expires_at: Mapped[dt.datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    # --- checkin_call_booking additions ---
    enrollment_id: Mapped[str | None] = mapped_column(
        Text, nullable=True
    )
    replaces_booking_id: Mapped[UUID | None] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("dayrate_bookings.id", ondelete="SET NULL"),
        nullable=True,
    )
    policy_key: Mapped[str | None] = mapped_column(Text, nullable=True)
    is_free: Mapped[bool] = mapped_column(
        Boolean, nullable=False, server_default="false"
    )
    created_at: Mapped[dt.datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    updated_at: Mapped[dt.datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    def __repr__(self) -> str:
        return (
            f"<DayRateBooking date={self.date!r} slot={self.slot_type!r} "
            f"status={self.status!r}>"
        )


class BookingPolicy(Base):
    """Per-application booking policy.

    Controls free allotment rules, overage pricing, and reschedule behavior
    for a specific entitlement-gated booking type (e.g. checkin_call).
    """

    __tablename__ = "booking_policies"
    __table_args__ = (
        UniqueConstraint(
            "application_id",
            "policy_key",
            name="uq_booking_policies_app_key",
        ),
    )

    id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), primary_key=True, default=uuid4
    )
    application_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("applications.id", ondelete="CASCADE"),
        nullable=False,
    )
    policy_key: Mapped[str] = mapped_column(Text, nullable=False)
    entitlement_key: Mapped[str] = mapped_column(Text, nullable=False)
    free_bookings_per_period: Mapped[int] = mapped_column(
        Integer, nullable=False, server_default="0"
    )
    period_days: Mapped[int] = mapped_column(
        Integer, nullable=False, server_default="28"
    )
    overage_rate: Mapped[int | None] = mapped_column(Integer, nullable=True)
    overage_currency: Mapped[str] = mapped_column(
        Text, nullable=False, server_default="'usd'"
    )
    overage_product_name: Mapped[str | None] = mapped_column(Text, nullable=True)
    reschedule_is_free: Mapped[bool] = mapped_column(
        Boolean, nullable=False, server_default="true"
    )
    is_active: Mapped[bool] = mapped_column(
        Boolean, nullable=False, server_default="true"
    )
    metadata_: Mapped[dict[str, Any] | None] = mapped_column(
        "metadata", JSON, nullable=True, default=dict
    )
    created_at: Mapped[dt.datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    updated_at: Mapped[dt.datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    def __repr__(self) -> str:
        return (
            f"<BookingPolicy app={self.application_id!r} "
            f"key={self.policy_key!r}>"
        )
