"""HTTP routes for the entitlements domain.

Provides TWO routers:

1. ``entitlements_router`` — entitlement CRUD under ``/v1/entitlements``
2. ``mappings_router`` — mapping management under ``/v1/entitlement-mappings``

Entitlement endpoints use API Key auth (Application dependency).
Mapping endpoints and admin entitlement operations use Admin auth.

Key-scope enforcement:
- Publishable keys (spaps_pub_*) require JWT and are restricted to
  user-scoped entitlements.  user_id/email must match the JWT user.
- Secret / legacy keys can query any resource_type without JWT.
"""

from __future__ import annotations

import logging
from uuid import UUID

from fastapi import APIRouter, Query, Request

from ...middleware.api_key import KeyType
from ...middleware.spaps_deps import (
    AdminUser,
    Application,
    CurrentUser,
    DbSession,
    OptionalUser,
)
from . import service
from .errors import (
    MissingAuthTokenError,
    NotAuthorizedError,
    ResourceValidationError,
    SecretKeyRequiredError,
)
from .schemas import (
    ChangesResponse,
    CheckEntitlementResponse,
    ClaimRequest,
    ClaimResponse,
    CreateMappingRequest,
    CreateMappingResponse,
    DeactivateMappingResponse,
    HistoryResponse,
    ListEntitlementsResponse,
    ListMappingsResponse,
    ManualGrantRequest,
    ManualGrantResponse,
    ResourceType,
    RevokeResponse,
    UpdateMappingRequest,
    UpdateMappingResponse,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _is_publishable_key(request: Request) -> bool:
    """Return True if the current request used a publishable API key."""
    return getattr(request.state, "key_type", None) == KeyType.PUBLISHABLE


# ===========================================================================
# Entitlements Router
# ===========================================================================

entitlements_router = APIRouter(prefix="/entitlements", tags=["entitlements"])


@entitlements_router.get("", response_model=ListEntitlementsResponse)
async def list_entitlements(
    request: Request,
    db: DbSession,
    app: Application,
    optional_user: OptionalUser,
    user_id: str | None = Query(default=None),
    email: str | None = Query(default=None),
    entitlement_key: str | None = Query(default=None),
    resource_type: ResourceType | None = Query(default=None),
    resource_id: str | None = Query(default=None),
    include_expired: bool = Query(default=False),
    include_revoked: bool = Query(default=False),
    limit: int | None = Query(default=None, ge=1, le=1000),
) -> ListEntitlementsResponse:
    """List entitlements with optional resource scoping.

    Publishable keys: JWT required, user-scoped only.
    Secret keys: any resource_type, user_id/email not required for
    non-user scopes.
    """
    from ..errors import ValidationError as DomainValidationError

    is_pub = _is_publishable_key(request)

    # -- Publishable key scope enforcement --
    if is_pub:
        # JWT required for publishable key reads
        if optional_user is None:
            raise MissingAuthTokenError()

        # Publishable keys: user-scoped only
        if resource_type is not None and resource_type != "user":
            raise SecretKeyRequiredError(
                "Publishable keys can only access user-scoped entitlements"
            )

        # If user_id or email supplied, must match JWT user
        jwt_user_id = str(optional_user.id)
        jwt_email = getattr(optional_user, "email", None)
        if user_id and user_id != jwt_user_id:
            raise NotAuthorizedError(
                "Cannot query entitlements for a different user"
            )
        if email and jwt_email and email.lower() != jwt_email.lower():
            raise NotAuthorizedError(
                "Cannot query entitlements for a different user"
            )

        # Default to JWT user if no user_id/email specified
        if not user_id and not email:
            user_id = jwt_user_id

    # -- Validate resource_id requirement --
    if resource_type in ("company", "org") and not resource_id:
        raise ResourceValidationError()

    # For user-scoped or unscoped queries with secret keys, require user
    effective_resource_type = resource_type or "user"
    if effective_resource_type == "user" and not user_id and not email:
        raise DomainValidationError(
            "Either user_id or email query parameter is required"
        )

    result = await service.get_entitlements(
        db,
        application_id=app.id,
        user_id=UUID(user_id) if user_id else None,
        email=email,
        entitlement_key=entitlement_key,
        resource_type=resource_type,
        resource_id=UUID(resource_id) if resource_id else None,
        include_expired=include_expired,
        include_revoked=include_revoked,
        limit=limit,
    )
    return ListEntitlementsResponse(**result)


@entitlements_router.get("/check", response_model=CheckEntitlementResponse)
async def check_entitlement(
    request: Request,
    db: DbSession,
    app: Application,
    optional_user: OptionalUser,
    user_id: str | None = Query(default=None),
    email: str | None = Query(default=None),
    entitlement_key: str | None = Query(default=None),
) -> CheckEntitlementResponse:
    """Quick boolean access check for entitlements.

    Publishable keys: JWT required, must match queried user.
    """
    is_pub = _is_publishable_key(request)

    if is_pub:
        if optional_user is None:
            raise MissingAuthTokenError()

        jwt_user_id = str(optional_user.id)
        jwt_email = getattr(optional_user, "email", None)
        if user_id and user_id != jwt_user_id:
            raise NotAuthorizedError(
                "Cannot check entitlements for a different user"
            )
        if email and jwt_email and email.lower() != jwt_email.lower():
            raise NotAuthorizedError(
                "Cannot check entitlements for a different user"
            )

        if not user_id and not email:
            user_id = jwt_user_id

    result = await service.check_entitlement(
        db,
        application_id=app.id,
        user_id=UUID(user_id) if user_id else None,
        email=email,
        entitlement_key=entitlement_key,
    )
    return CheckEntitlementResponse(**result)


@entitlements_router.get("/changes", response_model=ChangesResponse)
async def get_changes(
    request: Request,
    db: DbSession,
    app: Application,
    since: str | None = Query(default=None),
    limit: int | None = Query(default=None, ge=1, le=1000),
) -> ChangesResponse:
    """Sync endpoint for getting entitlement change events.

    Secret key only.  Publishable keys are rejected.
    """
    if _is_publishable_key(request):
        raise SecretKeyRequiredError(
            "The changes endpoint requires a secret key"
        )

    result = await service.get_changes(
        db,
        application_id=app.id,
        since=since,
        limit=limit,
    )
    return ChangesResponse(**result)


@entitlements_router.get("/history", response_model=HistoryResponse)
async def get_history(
    request: Request,
    db: DbSession,
    app: Application,
    optional_user: OptionalUser,
    user_id: str = Query(..., description="User ID to get history for"),
) -> HistoryResponse:
    """Get purchase/payment history for a user.

    Publishable keys: JWT required, user-scoped via JWT user.
    """
    is_pub = _is_publishable_key(request)

    if is_pub:
        if optional_user is None:
            raise MissingAuthTokenError()

        jwt_user_id = str(optional_user.id)
        if user_id != jwt_user_id:
            raise NotAuthorizedError(
                "Cannot view history for a different user"
            )

    result = await service.get_history(
        db,
        application_id=app.id,
        user_id=UUID(user_id),
    )
    return HistoryResponse(**result)


@entitlements_router.post("/claim", response_model=ClaimResponse)
async def claim_entitlements(
    body: ClaimRequest,
    db: DbSession,
    app: Application,
    user: CurrentUser,
) -> ClaimResponse:
    """Claim pending entitlements (email -> user_id).

    Requires API key + JWT authentication.
    """
    result = await service.claim_pending_entitlements(
        db,
        application_id=app.id,
        user_id=UUID(body.user_id),
        email=body.email,
    )
    return ClaimResponse(**result)


@entitlements_router.post(
    "/manual", response_model=ManualGrantResponse, status_code=201
)
async def manual_grant(
    body: ManualGrantRequest,
    db: DbSession,
    app: Application,
    admin: AdminUser,
) -> ManualGrantResponse:
    """Admin: grant a manual entitlement.

    Requires API key + JWT (admin).
    Supports resource_type and resource_id for non-user scopes.
    Beneficiary (user_id/email) not required for non-user resource types.
    """
    # Validate resource_id requirement for company/org types
    if body.resource_type in ("company", "org") and not body.resource_id:
        raise ResourceValidationError()

    result = await service.grant_manual_entitlement(
        db,
        application_id=app.id,
        beneficiary_user_id=UUID(body.beneficiary_user_id) if body.beneficiary_user_id else None,
        beneficiary_email=body.beneficiary_email,
        entitlement_key=body.entitlement_key,
        resource_type=body.resource_type,
        resource_id=UUID(body.resource_id) if body.resource_id else None,
        reason=body.reason,
        granted_by_user_id=UUID(admin.id) if isinstance(admin.id, str) else admin.id,
        metadata=body.metadata,
    )
    return ManualGrantResponse(**result)


@entitlements_router.delete("/{id}", response_model=RevokeResponse)
async def revoke_entitlement(
    id: str,
    db: DbSession,
    app: Application,
    admin: AdminUser,
    reason: str | None = Query(default=None),
) -> RevokeResponse:
    """Admin: revoke an entitlement.

    Requires API key + JWT (admin).
    """
    result = await service.revoke_entitlement(
        db,
        entitlement_id=UUID(id),
        revoked_by_user_id=UUID(admin.id) if isinstance(admin.id, str) else admin.id,
        reason=reason,
    )
    return RevokeResponse(**result)


# ===========================================================================
# Entitlement Mappings Router
# ===========================================================================

mappings_router = APIRouter(
    prefix="/entitlement-mappings", tags=["entitlement-mappings"]
)


@mappings_router.get("", response_model=ListMappingsResponse)
async def list_mappings(
    db: DbSession,
    app: Application,
    admin: AdminUser,
    active_only: bool = Query(default=False),
) -> ListMappingsResponse:
    """List all entitlement mappings for an application.

    Requires API key + JWT (admin).
    """
    result = await service.list_mappings(
        db,
        application_id=app.id,
        active_only=active_only,
    )
    return ListMappingsResponse(**result)


@mappings_router.post("", response_model=CreateMappingResponse, status_code=201)
async def create_mapping(
    body: CreateMappingRequest,
    db: DbSession,
    app: Application,
    admin: AdminUser,
) -> CreateMappingResponse:
    """Create a new entitlement mapping.

    Requires API key + JWT (admin).
    """
    result = await service.create_mapping(
        db,
        application_id=app.id,
        stripe_price_id=body.stripe_price_id,
        entitlement_key=body.entitlement_key,
        entitlement_type=body.entitlement_type,
        duration_days=body.duration_days,
        metadata=body.metadata,
    )
    return CreateMappingResponse(**result)


@mappings_router.put("/{id}", response_model=UpdateMappingResponse)
async def update_mapping(
    id: str,
    body: UpdateMappingRequest,
    db: DbSession,
    app: Application,
    admin: AdminUser,
) -> UpdateMappingResponse:
    """Update an existing entitlement mapping.

    Requires API key + JWT (admin).
    """
    result = await service.update_mapping(
        db,
        mapping_id=UUID(id),
        application_id=app.id,
        entitlement_key=body.entitlement_key,
        entitlement_type=body.entitlement_type,
        duration_days=body.duration_days,
        metadata=body.metadata,
        is_active=body.is_active,
    )
    return UpdateMappingResponse(**result)


@mappings_router.delete("/{id}", response_model=DeactivateMappingResponse)
async def deactivate_mapping(
    id: str,
    db: DbSession,
    app: Application,
    admin: AdminUser,
) -> DeactivateMappingResponse:
    """Deactivate (soft-delete) an entitlement mapping.

    Requires API key + JWT (admin).
    """
    result = await service.deactivate_mapping(
        db,
        mapping_id=UUID(id),
        application_id=app.id,
    )
    return DeactivateMappingResponse(**result)
