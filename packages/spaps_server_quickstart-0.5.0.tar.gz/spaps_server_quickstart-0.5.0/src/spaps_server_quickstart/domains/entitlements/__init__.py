"""Entitlements domain — entitlement management for SPAPS applications."""
