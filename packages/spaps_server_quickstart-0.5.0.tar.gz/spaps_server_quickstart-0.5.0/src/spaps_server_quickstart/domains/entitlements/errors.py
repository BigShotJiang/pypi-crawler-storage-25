"""Domain errors for the entitlements domain."""

from __future__ import annotations

from ..errors import DomainError


class EntitlementNotFoundError(DomainError):
    """Raised when an entitlement is not found."""

    def __init__(self, message: str = "Entitlement not found") -> None:
        super().__init__("NOT_FOUND", message, status_code=404)


class EntitlementAlreadyRevokedError(DomainError):
    """Raised when attempting to revoke an already-revoked entitlement."""

    def __init__(self, message: str = "Entitlement is already revoked") -> None:
        super().__init__("ALREADY_REVOKED", message, status_code=400)


class NoBeneficiaryError(DomainError):
    """Raised when neither user_id nor email is provided."""

    def __init__(
        self,
        message: str = "Either beneficiary_user_id or beneficiary_email is required",
    ) -> None:
        super().__init__("NO_BENEFICIARY", message, status_code=400)


class MappingNotFoundError(DomainError):
    """Raised when an entitlement mapping is not found."""

    def __init__(self, message: str = "Mapping not found") -> None:
        super().__init__("MAPPING_NOT_FOUND", message, status_code=404)


class MappingAlreadyExistsError(DomainError):
    """Raised when a mapping for the same price+key already exists."""

    def __init__(
        self,
        message: str = "A mapping for this price_id and entitlement_key already exists",
    ) -> None:
        super().__init__("ALREADY_EXISTS", message, status_code=409)


class SecretKeyRequiredError(DomainError):
    """Raised when a publishable key attempts non-user resource scope access."""

    def __init__(
        self,
        message: str = "This operation requires a secret key",
    ) -> None:
        super().__init__("SECRET_KEY_REQUIRED", message, status_code=403)


class NotAuthorizedError(DomainError):
    """Raised when a publishable key user_id/email doesn't match JWT user."""

    def __init__(
        self,
        message: str = "Not authorized to access this resource",
    ) -> None:
        super().__init__("NOT_AUTHORIZED", message, status_code=403)


class MissingAuthTokenError(DomainError):
    """Raised when JWT is required but missing for publishable key reads."""

    def __init__(
        self,
        message: str = "Authentication token required",
    ) -> None:
        super().__init__("MISSING_AUTH_TOKEN", message, status_code=401)


class ResourceValidationError(DomainError):
    """Raised when resource_id is missing for company/org resource types."""

    def __init__(
        self,
        message: str = "resource_id is required when resource_type is 'company' or 'org'",
    ) -> None:
        super().__init__("VALIDATION_FAILED", message, status_code=400)
