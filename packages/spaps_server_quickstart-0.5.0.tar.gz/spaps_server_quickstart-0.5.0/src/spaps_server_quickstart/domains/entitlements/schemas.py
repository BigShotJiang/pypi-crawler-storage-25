"""Pydantic request/response schemas for entitlement endpoints.

These schemas define the *data* portion of each API response.
The standard response envelope ``{ success, data, error, metadata }``
is applied by middleware -- domain schemas never reference it.

Zero FastAPI imports.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Shared types
# ---------------------------------------------------------------------------

EntitlementSourceType = Literal[
    "crypto", "stripe_subscription", "stripe_checkout", "manual"
]
EntitlementMappingTypeEnum = Literal["one_time", "subscription", "time_limited"]
EntitlementEventTypeEnum = Literal[
    "granted", "updated", "renewed", "expired", "revoked", "claimed"
]
ResourceType = Literal["user", "company", "system", "org"]


# ---------------------------------------------------------------------------
# Canonical representations
# ---------------------------------------------------------------------------


class EntitlementOut(BaseModel):
    """Canonical representation of an entitlement."""

    id: str
    application_id: str
    beneficiary_user_id: str | None = None
    beneficiary_email: str | None = None
    entitlement_type: str
    entitlement_key: str
    source: str
    resource_type: str = "user"
    resource_id: str | None = None
    starts_at: str | None = None
    ends_at: str | None = None
    revoked_at: str | None = None
    crypto_invoice_id: str | None = None
    stripe_product_id: str | None = None
    stripe_price_id: str | None = None
    stripe_subscription_id: str | None = None
    stripe_session_id: str | None = None
    stripe_invoice_id: str | None = None
    manual_grant_id: str | None = None
    manual_grant_reason: str | None = None
    granted_by_user_id: str | None = None
    revoked_by_user_id: str | None = None
    revoked_reason: str | None = None
    metadata: dict[str, Any] | None = None
    created_at: str
    updated_at: str


class EntitlementMappingOut(BaseModel):
    """Canonical representation of an entitlement mapping."""

    id: str
    application_id: str
    stripe_price_id: str
    entitlement_key: str
    entitlement_type: str
    duration_days: int | None = None
    metadata: dict[str, Any] | None = None
    is_active: bool
    created_at: str
    updated_at: str


class EntitlementEventOut(BaseModel):
    """Canonical representation of an entitlement event."""

    id: str
    entitlement_id: str | None = None
    event_type: str
    application_id: str | None = None
    user_id: str | None = None
    email: str | None = None
    entitlement_key: str | None = None
    source: str | None = None
    previous_state: dict[str, Any] | None = None
    new_state: dict[str, Any] | None = None
    triggered_by: str | None = None
    metadata: dict[str, Any] | None = None
    created_at: str


class PurchaseHistoryItem(BaseModel):
    """A single item in the purchase history."""

    id: str
    entitlement_key: str
    source: str
    status: Literal["active", "expired", "revoked"]
    purchased_at: str
    starts_at: str | None = None
    ends_at: str | None = None
    crypto_invoice_id: str | None = None
    stripe_subscription_id: str | None = None
    stripe_invoice_id: str | None = None
    amount: float | None = None
    currency: str | None = None
    product_name: str | None = None


# ---------------------------------------------------------------------------
# Request schemas — Entitlements
# ---------------------------------------------------------------------------


class ListEntitlementsParams(BaseModel):
    """GET /entitlements query parameters."""

    user_id: str | None = None
    email: str | None = None
    entitlement_key: str | None = None
    resource_type: ResourceType | None = None
    resource_id: str | None = None
    include_expired: bool = False
    include_revoked: bool = False
    limit: int | None = Field(default=None, ge=1, le=1000)


class CheckEntitlementParams(BaseModel):
    """GET /entitlements/check query parameters."""

    user_id: str | None = None
    email: str | None = None
    entitlement_key: str | None = None


class ChangesParams(BaseModel):
    """GET /entitlements/changes query parameters."""

    since: str | None = None
    limit: int | None = Field(default=None, ge=1, le=1000)


class HistoryParams(BaseModel):
    """GET /entitlements/history query parameters."""

    user_id: str


class ClaimRequest(BaseModel):
    """POST /entitlements/claim body."""

    email: str
    user_id: str


class ManualGrantRequest(BaseModel):
    """POST /entitlements/manual body."""

    beneficiary_user_id: str | None = None
    beneficiary_email: str | None = None
    entitlement_key: str
    resource_type: ResourceType = "user"
    resource_id: str | None = None
    starts_at: str | None = None
    ends_at: str | None = None
    reason: str | None = None
    metadata: dict[str, Any] | None = None


class RevokeRequest(BaseModel):
    """DELETE /entitlements/{id} optional body."""

    reason: str | None = None


# ---------------------------------------------------------------------------
# Request schemas — Mappings
# ---------------------------------------------------------------------------


class CreateMappingRequest(BaseModel):
    """POST /entitlement-mappings body."""

    stripe_price_id: str
    entitlement_key: str
    entitlement_type: EntitlementMappingTypeEnum = "one_time"
    duration_days: int | None = None
    metadata: dict[str, Any] | None = None


class UpdateMappingRequest(BaseModel):
    """PUT /entitlement-mappings/{id} body."""

    entitlement_key: str | None = None
    entitlement_type: EntitlementMappingTypeEnum | None = None
    duration_days: int | None = None
    metadata: dict[str, Any] | None = None
    is_active: bool | None = None


# ---------------------------------------------------------------------------
# Response schemas — Entitlements
# ---------------------------------------------------------------------------


class ListEntitlementsResponse(BaseModel):
    """GET /entitlements -- success payload."""

    entitlements: list[EntitlementOut]
    count: int


class CheckEntitlementResponse(BaseModel):
    """GET /entitlements/check -- success payload."""

    has_entitlement: bool
    entitlements: list[EntitlementOut]


class ChangesResponse(BaseModel):
    """GET /entitlements/changes -- success payload."""

    events: list[EntitlementEventOut]
    cursor: str | None = None
    has_more: bool


class HistoryResponse(BaseModel):
    """GET /entitlements/history -- success payload."""

    history: list[PurchaseHistoryItem]
    count: int


class ClaimResponse(BaseModel):
    """POST /entitlements/claim -- success payload."""

    claimed: list[EntitlementOut]
    count: int


class ManualGrantResponse(BaseModel):
    """POST /entitlements/manual -- success payload."""

    entitlement: EntitlementOut


class RevokeResponse(BaseModel):
    """DELETE /entitlements/{id} -- success payload."""

    entitlement: EntitlementOut


# ---------------------------------------------------------------------------
# Response schemas — Mappings
# ---------------------------------------------------------------------------


class ListMappingsResponse(BaseModel):
    """GET /entitlement-mappings -- success payload."""

    mappings: list[EntitlementMappingOut]
    count: int


class CreateMappingResponse(BaseModel):
    """POST /entitlement-mappings -- success payload."""

    mapping: EntitlementMappingOut


class UpdateMappingResponse(BaseModel):
    """PUT /entitlement-mappings/{id} -- success payload."""

    mapping: EntitlementMappingOut


class DeactivateMappingResponse(BaseModel):
    """DELETE /entitlement-mappings/{id} -- success payload."""

    mapping: EntitlementMappingOut
    message: str
