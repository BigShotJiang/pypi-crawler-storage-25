"""Business logic for the entitlements domain.

Coordinates repository calls and raises domain errors.
This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime, timedelta
from typing import Any
from uuid import UUID, uuid4

from sqlalchemy.ext.asyncio import AsyncSession

from ..errors import ValidationError
from . import repository as repo
from .errors import (
    EntitlementAlreadyRevokedError,
    EntitlementNotFoundError,
    MappingAlreadyExistsError,
    MappingNotFoundError,
    NoBeneficiaryError,
)
from .models import Entitlement, EntitlementEvent, EntitlementMapping

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _entitlement_to_dict(ent: Entitlement) -> dict[str, Any]:
    """Convert an Entitlement model instance to a serialisable dict."""
    return {
        "id": str(ent.id),
        "application_id": str(ent.application_id),
        "beneficiary_user_id": str(ent.beneficiary_user_id) if ent.beneficiary_user_id else None,
        "beneficiary_email": ent.beneficiary_email,
        "entitlement_type": ent.entitlement_type,
        "entitlement_key": ent.entitlement_key,
        "source": ent.source,
        "resource_type": getattr(ent, "resource_type", "user") or "user",
        "resource_id": str(ent.resource_id) if getattr(ent, "resource_id", None) else None,
        "starts_at": ent.starts_at.isoformat() if ent.starts_at else None,
        "ends_at": ent.ends_at.isoformat() if ent.ends_at else None,
        "revoked_at": ent.revoked_at.isoformat() if ent.revoked_at else None,
        "crypto_invoice_id": str(ent.crypto_invoice_id) if ent.crypto_invoice_id else None,
        "stripe_product_id": ent.stripe_product_id,
        "stripe_price_id": ent.stripe_price_id,
        "stripe_subscription_id": ent.stripe_subscription_id,
        "stripe_session_id": ent.stripe_session_id,
        "stripe_invoice_id": ent.stripe_invoice_id,
        "manual_grant_id": ent.manual_grant_id,
        "manual_grant_reason": ent.manual_grant_reason,
        "granted_by_user_id": str(ent.granted_by_user_id) if ent.granted_by_user_id else None,
        "revoked_by_user_id": str(ent.revoked_by_user_id) if ent.revoked_by_user_id else None,
        "revoked_reason": ent.revoked_reason,
        "metadata": ent.metadata_,
        "created_at": ent.created_at.isoformat() if ent.created_at else None,
        "updated_at": ent.updated_at.isoformat() if ent.updated_at else None,
    }


def _event_to_dict(event: EntitlementEvent) -> dict[str, Any]:
    """Convert an EntitlementEvent model instance to a serialisable dict."""
    return {
        "id": str(event.id),
        "entitlement_id": str(event.entitlement_id) if event.entitlement_id else None,
        "event_type": event.event_type,
        "application_id": str(event.application_id) if event.application_id else None,
        "user_id": str(event.user_id) if event.user_id else None,
        "email": event.email,
        "entitlement_key": event.entitlement_key,
        "source": event.source,
        "previous_state": event.previous_state,
        "new_state": event.new_state,
        "triggered_by": event.triggered_by,
        "metadata": event.metadata_,
        "created_at": event.created_at.isoformat() if event.created_at else None,
    }


def _mapping_to_dict(mapping: EntitlementMapping) -> dict[str, Any]:
    """Convert an EntitlementMapping model instance to a serialisable dict."""
    return {
        "id": str(mapping.id),
        "application_id": str(mapping.application_id),
        "stripe_price_id": mapping.stripe_price_id,
        "entitlement_key": mapping.entitlement_key,
        "entitlement_type": mapping.entitlement_type,
        "duration_days": mapping.duration_days,
        "metadata": mapping.metadata_,
        "is_active": mapping.is_active,
        "created_at": mapping.created_at.isoformat() if mapping.created_at else None,
        "updated_at": mapping.updated_at.isoformat() if mapping.updated_at else None,
    }


async def _create_event_for_entitlement(
    db: AsyncSession,
    entitlement: Entitlement,
    event_type: str,
    triggered_by: str | None,
    previous_state: dict[str, Any] | None,
) -> EntitlementEvent:
    """Create an entitlement event record."""
    return await repo.create_event(
        db,
        entitlement_id=entitlement.id,
        event_type=event_type,
        application_id=entitlement.application_id,
        user_id=entitlement.beneficiary_user_id,
        email=entitlement.beneficiary_email,
        entitlement_key=entitlement.entitlement_key,
        source=entitlement.source,
        previous_state=previous_state,
        new_state={
            "starts_at": entitlement.starts_at.isoformat() if entitlement.starts_at else None,
            "ends_at": entitlement.ends_at.isoformat() if entitlement.ends_at else None,
            "revoked_at": entitlement.revoked_at.isoformat() if entitlement.revoked_at else None,
        },
        triggered_by=triggered_by,
        metadata_={},
    )


# ---------------------------------------------------------------------------
# Entitlements — public API
# ---------------------------------------------------------------------------


async def grant_entitlement(
    db: AsyncSession,
    *,
    application_id: UUID,
    entitlement_key: str,
    source: str,
    beneficiary_user_id: UUID | None = None,
    beneficiary_email: str | None = None,
    entitlement_type: str = "access",
    resource_type: str = "user",
    resource_id: UUID | None = None,
    starts_at: datetime | None = None,
    ends_at: datetime | None = None,
    crypto_invoice_id: UUID | None = None,
    stripe_subscription_id: str | None = None,
    stripe_session_id: str | None = None,
    stripe_invoice_id: str | None = None,
    stripe_product_id: str | None = None,
    stripe_price_id: str | None = None,
    manual_grant_id: str | None = None,
    manual_grant_reason: str | None = None,
    granted_by_user_id: UUID | None = None,
    triggered_by: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Grant an entitlement (idempotent).

    Returns existing entitlement if duplicate source reference is found.
    For non-user resource types, beneficiary is not required.
    """
    # Beneficiary required only for user-scoped entitlements
    if resource_type == "user" and not beneficiary_user_id and not beneficiary_email:
        raise NoBeneficiaryError()

    logger.info(
        "Granting entitlement",
        extra={
            "application_id": str(application_id),
            "entitlement_key": entitlement_key,
            "source": source,
        },
    )

    # Idempotency check
    existing = await repo.find_existing_entitlement(
        db,
        application_id=application_id,
        entitlement_key=entitlement_key,
        source=source,
        beneficiary_user_id=beneficiary_user_id,
        beneficiary_email=beneficiary_email,
        stripe_session_id=stripe_session_id,
        stripe_subscription_id=stripe_subscription_id,
        crypto_invoice_id=crypto_invoice_id,
        manual_grant_id=manual_grant_id,
    )

    if existing is not None:
        logger.info("Found existing entitlement (idempotent)", extra={"id": str(existing.id)})
        return {
            "entitlement": _entitlement_to_dict(existing),
            "created": False,
        }

    now = datetime.now(UTC)
    entitlement = await repo.create_entitlement(
        db,
        application_id=application_id,
        beneficiary_user_id=beneficiary_user_id,
        beneficiary_email=beneficiary_email.lower() if beneficiary_email else None,
        entitlement_type=entitlement_type,
        entitlement_key=entitlement_key,
        source=source,
        resource_type=resource_type,
        resource_id=resource_id,
        starts_at=starts_at or now,
        ends_at=ends_at,
        crypto_invoice_id=crypto_invoice_id,
        stripe_subscription_id=stripe_subscription_id,
        stripe_session_id=stripe_session_id,
        stripe_invoice_id=stripe_invoice_id,
        stripe_product_id=stripe_product_id,
        stripe_price_id=stripe_price_id,
        manual_grant_id=manual_grant_id,
        manual_grant_reason=manual_grant_reason,
        granted_by_user_id=granted_by_user_id,
        metadata_=metadata or {},
    )

    # Create granted event
    await _create_event_for_entitlement(db, entitlement, "granted", triggered_by, None)

    logger.info(
        "Entitlement granted",
        extra={"id": str(entitlement.id), "entitlement_key": entitlement.entitlement_key},
    )

    return {
        "entitlement": _entitlement_to_dict(entitlement),
        "created": True,
    }


async def get_entitlements(
    db: AsyncSession,
    *,
    application_id: UUID,
    user_id: UUID | None = None,
    email: str | None = None,
    entitlement_key: str | None = None,
    resource_type: str | None = None,
    resource_id: UUID | None = None,
    include_expired: bool = False,
    include_revoked: bool = False,
    limit: int | None = None,
) -> dict[str, Any]:
    """Get entitlements for a user/email with optional filters."""
    entitlements = await repo.list_entitlements(
        db,
        application_id,
        user_id=user_id,
        email=email,
        entitlement_key=entitlement_key,
        resource_type=resource_type,
        resource_id=resource_id,
        include_expired=include_expired,
        include_revoked=include_revoked,
        limit=limit,
    )
    return {
        "entitlements": [_entitlement_to_dict(e) for e in entitlements],
        "count": len(entitlements),
    }


async def check_entitlement(
    db: AsyncSession,
    *,
    application_id: UUID,
    user_id: UUID | None = None,
    email: str | None = None,
    entitlement_key: str | None = None,
) -> dict[str, Any]:
    """Quick access check for entitlements.

    Returns active, non-revoked, non-expired entitlements.
    """
    if not user_id and not email:
        raise ValidationError("Either user_id or email is required")

    entitlements = await repo.list_entitlements(
        db,
        application_id,
        user_id=user_id,
        email=email,
        entitlement_key=entitlement_key,
        include_expired=False,
        include_revoked=False,
    )

    return {
        "has_entitlement": len(entitlements) > 0,
        "entitlements": [_entitlement_to_dict(e) for e in entitlements],
    }


async def get_changes(
    db: AsyncSession,
    *,
    application_id: UUID,
    since: str | None = None,
    limit: int | None = None,
) -> dict[str, Any]:
    """Get entitlement change events for sync."""
    effective_limit = limit or 100

    events = await repo.list_events(
        db,
        application_id,
        since=since,
        limit=effective_limit,
    )

    has_more = len(events) > effective_limit
    result_events = events[:effective_limit] if has_more else events

    cursor = (
        result_events[-1].created_at.isoformat()
        if result_events
        else None
    )

    return {
        "events": [_event_to_dict(e) for e in result_events],
        "cursor": cursor,
        "has_more": has_more,
    }


async def get_history(
    db: AsyncSession,
    *,
    application_id: UUID,
    user_id: UUID,
) -> dict[str, Any]:
    """Get purchase/payment history for a user."""
    entitlements = await repo.list_entitlements(
        db,
        application_id,
        user_id=user_id,
        include_expired=True,
        include_revoked=True,
    )

    now = datetime.now(UTC)
    history = []
    for ent in entitlements:
        if ent.revoked_at:
            status = "revoked"
        elif ent.ends_at and ent.ends_at < now:
            status = "expired"
        else:
            status = "active"

        meta = ent.metadata_ or {}
        history.append({
            "id": str(ent.id),
            "entitlement_key": ent.entitlement_key,
            "source": ent.source,
            "status": status,
            "purchased_at": ent.created_at.isoformat() if ent.created_at else None,
            "starts_at": ent.starts_at.isoformat() if ent.starts_at else None,
            "ends_at": ent.ends_at.isoformat() if ent.ends_at else None,
            "crypto_invoice_id": str(ent.crypto_invoice_id) if ent.crypto_invoice_id else None,
            "stripe_subscription_id": ent.stripe_subscription_id,
            "stripe_invoice_id": ent.stripe_invoice_id,
            "amount": meta.get("amount"),
            "currency": meta.get("currency"),
            "product_name": meta.get("product_name"),
        })

    return {
        "history": history,
        "count": len(history),
    }


async def claim_pending_entitlements(
    db: AsyncSession,
    *,
    application_id: UUID,
    user_id: UUID,
    email: str,
) -> dict[str, Any]:
    """Claim pending entitlements by associating email with user_id."""
    claimed = await repo.claim_entitlements_by_email(
        db, application_id, email, user_id
    )

    # Create claimed events
    for ent in claimed:
        await _create_event_for_entitlement(db, ent, "claimed", "claim", None)

    logger.info(
        "Claimed pending entitlements",
        extra={
            "user_id": str(user_id),
            "email": email.lower(),
            "count": len(claimed),
        },
    )

    return {
        "claimed": [_entitlement_to_dict(e) for e in claimed],
        "count": len(claimed),
    }


async def grant_manual_entitlement(
    db: AsyncSession,
    *,
    application_id: UUID,
    beneficiary_user_id: UUID | None = None,
    beneficiary_email: str | None = None,
    entitlement_key: str,
    resource_type: str = "user",
    resource_id: UUID | None = None,
    starts_at: datetime | None = None,
    ends_at: datetime | None = None,
    reason: str | None = None,
    granted_by_user_id: UUID,
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Admin: grant a manual entitlement.

    For non-user resource types (system, company, org), beneficiary is
    not required because the entitlement is scoped to a resource rather
    than a specific user.
    """
    # Beneficiary required only for user-scoped entitlements
    if resource_type == "user" and not beneficiary_user_id and not beneficiary_email:
        raise NoBeneficiaryError()

    result = await grant_entitlement(
        db,
        application_id=application_id,
        beneficiary_user_id=beneficiary_user_id,
        beneficiary_email=beneficiary_email,
        entitlement_key=entitlement_key,
        source="manual",
        entitlement_type="access",
        resource_type=resource_type,
        resource_id=resource_id,
        starts_at=starts_at,
        ends_at=ends_at,
        manual_grant_id=str(uuid4()),
        manual_grant_reason=reason,
        granted_by_user_id=granted_by_user_id,
        triggered_by="api",
        metadata=metadata,
    )

    return {"entitlement": result["entitlement"]}


async def revoke_entitlement(
    db: AsyncSession,
    *,
    entitlement_id: UUID,
    revoked_by_user_id: UUID,
    reason: str | None = None,
) -> dict[str, Any]:
    """Admin: revoke an entitlement."""
    entitlement = await repo.get_entitlement_by_id(db, entitlement_id)
    if entitlement is None:
        raise EntitlementNotFoundError()

    if entitlement.revoked_at is not None:
        raise EntitlementAlreadyRevokedError()

    previous_state = {
        "revoked_at": None,
        "revoked_by_user_id": None,
        "revoked_reason": None,
    }

    updated = await repo.update_entitlement(
        db,
        entitlement_id,
        revoked_at=datetime.now(UTC),
        revoked_by_user_id=revoked_by_user_id,
        revoked_reason=reason or "Revoked by admin",
    )

    if updated is None:
        raise EntitlementNotFoundError()

    await _create_event_for_entitlement(db, updated, "revoked", "api", previous_state)

    logger.info(
        "Entitlement revoked",
        extra={
            "id": str(updated.id),
            "by_user_id": str(revoked_by_user_id),
            "reason": reason,
        },
    )

    return {"entitlement": _entitlement_to_dict(updated)}


# ---------------------------------------------------------------------------
# Subscription renewal helpers (Stripe integration — signatures only, Phase 4)
# ---------------------------------------------------------------------------


async def renew_subscription_entitlements(
    db: AsyncSession,
    subscription_id: str,
    new_period_end: datetime,
) -> list[dict[str, Any]]:
    """Renew ALL entitlements for a subscription (multi-entitlement support).

    Phase 4 Stripe integration — full implementation wired later.
    """
    entitlements = await repo.find_entitlements_by_subscription(db, subscription_id)

    if not entitlements:
        logger.info(
            "No entitlements found for subscription",
            extra={"subscription_id": subscription_id},
        )
        return []

    renewed: list[dict[str, Any]] = []
    for ent in entitlements:
        previous_state = {
            "ends_at": ent.ends_at.isoformat() if ent.ends_at else None,
        }

        updated = await repo.update_entitlement(
            db,
            ent.id,
            ends_at=new_period_end,
        )

        if updated is not None:
            await _create_event_for_entitlement(
                db, updated, "renewed", "webhook", previous_state
            )
            renewed.append(_entitlement_to_dict(updated))

    logger.info(
        "Subscription entitlements renewed",
        extra={"subscription_id": subscription_id, "count": len(renewed)},
    )

    return renewed


async def get_mappings_for_price(
    db: AsyncSession,
    application_id: UUID,
    price_id: str,
) -> list[dict[str, Any]]:
    """Get active entitlement mappings for a Stripe price.

    Phase 4 Stripe integration helper.
    """
    mappings = await repo.get_mappings_for_price(db, application_id, price_id)
    return [_mapping_to_dict(m) for m in mappings]


def _extract_price_and_product_ids(item: dict[str, Any]) -> tuple[str | None, str | None]:
    price = item.get("price")
    price_id = price if isinstance(price, str) else (price.get("id") if isinstance(price, dict) else None)
    product_id = None
    if isinstance(price, dict):
        product = price.get("product")
        product_id = product if isinstance(product, str) else None
    return price_id, product_id


def _calculate_checkout_window(
    mapping: dict[str, Any],
    *,
    starts_at_str: str | None,
    ends_at_str: str | None,
) -> tuple[datetime | None, datetime | None]:
    starts_at = datetime.fromisoformat(starts_at_str) if starts_at_str else None
    if ends_at_str:
        return starts_at, datetime.fromisoformat(ends_at_str)
    if mapping.get("duration_days"):
        return starts_at, datetime.now(UTC) + timedelta(days=mapping["duration_days"])
    return starts_at, None


def _build_checkout_grant_metadata(
    session: dict[str, Any],
    item: dict[str, Any],
    mapping: dict[str, Any],
    *,
    price_id: str,
) -> dict[str, Any]:
    return {
        "stripe_price_id": price_id,
        "amount": session.get("amount_total"),
        "currency": session.get("currency"),
        "product_name": mapping.get("metadata", {}).get("product_name")
        or item.get("description"),
    }


async def _should_skip_created_subscription_mapping(
    db: AsyncSession,
    *,
    app_id: UUID,
    user_id: str,
    subscription_id: str,
    entitlement_key: str,
) -> bool:
    existing = await repo.find_existing_entitlement(
        db,
        application_id=app_id,
        entitlement_key=entitlement_key,
        source="stripe_checkout",
        beneficiary_user_id=UUID(user_id),
        stripe_subscription_id=subscription_id,
    )
    if not existing:
        return False

    logger.info(
        "Skipping subscription.created — already from checkout",
        extra={
            "subscription_id": subscription_id,
            "entitlement_key": entitlement_key,
        },
    )
    return True


async def _handle_deleted_subscription_mapping(
    db: AsyncSession,
    *,
    subscription_id: str,
    current_period_end: datetime | None,
    entitlement_key: str,
) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    existing_list = await repo.find_entitlements_by_subscription(db, subscription_id)
    for ent in existing_list:
        if ent.entitlement_key != entitlement_key or ent.revoked_at:
            continue
        prev = {"ends_at": ent.ends_at.isoformat() if ent.ends_at else None}
        updated = await repo.update_entitlement(db, ent.id, ends_at=current_period_end)
        if updated:
            await _create_event_for_entitlement(db, updated, "updated", "webhook", prev)
            results.append(_entitlement_to_dict(updated))
    return results


async def _maybe_renew_updated_subscription(
    db: AsyncSession,
    *,
    subscription_id: str,
    result: dict[str, Any],
    event_type: str,
    current_period_end: datetime | None,
) -> None:
    if result["created"] or event_type != "updated" or not current_period_end:
        return

    existing_ends = result["entitlement"].get("ends_at")
    if not existing_ends:
        return

    existing_dt = datetime.fromisoformat(existing_ends)
    if current_period_end > existing_dt:
        await renew_subscription_entitlements(db, subscription_id, current_period_end)


async def process_stripe_checkout(
    db: AsyncSession,
    session: dict[str, Any],
    line_items: list[dict[str, Any]] | None,
    app_id: UUID,
) -> list[dict[str, Any]]:
    """Process Stripe checkout session completion.

    For each line item, looks up entitlement mappings by price_id and grants
    entitlements. Idempotent — duplicate grants are safely skipped.
    """
    metadata = session.get("metadata") or {}
    user_id = metadata.get("user_id") or session.get("client_reference_id")
    customer_email = session.get("customer_email") or (
        (session.get("customer_details") or {}).get("email")
    )

    if not user_id and not customer_email:
        logger.warning(
            "Checkout session missing user_id and email",
            extra={"session_id": session.get("id")},
        )
        return []

    # Parse optional entitlement dates from metadata
    starts_at_str = metadata.get("entitlement_starts_at")
    ends_at_str = metadata.get("entitlement_ends_at")

    # Extract subscription ID for subscription-mode checkouts
    sub = session.get("subscription")
    subscription_id = (
        (sub if isinstance(sub, str) else sub.get("id") if isinstance(sub, dict) else None)
        if session.get("mode") == "subscription" and sub
        else None
    )

    if not line_items:
        logger.info("No line items for checkout", extra={"session_id": session.get("id")})
        return []

    created: list[dict[str, Any]] = []

    for item in line_items:
        price_id, product_id = _extract_price_and_product_ids(item)
        if not price_id:
            continue

        mappings = await get_mappings_for_price(db, app_id, price_id)
        if not mappings:
            continue

        for mapping in mappings:
            calculated_starts_at, calculated_ends_at = _calculate_checkout_window(
                mapping,
                starts_at_str=starts_at_str,
                ends_at_str=ends_at_str,
            )

            try:
                result = await grant_entitlement(
                    db,
                    application_id=app_id,
                    beneficiary_user_id=UUID(user_id) if user_id else None,
                    beneficiary_email=customer_email,
                    entitlement_key=mapping["entitlement_key"],
                    source="stripe_checkout",
                    starts_at=calculated_starts_at,
                    ends_at=calculated_ends_at,
                    stripe_session_id=session.get("id"),
                    stripe_subscription_id=subscription_id,
                    stripe_product_id=product_id,
                    stripe_price_id=price_id,
                    triggered_by="webhook",
                    metadata=_build_checkout_grant_metadata(
                        session,
                        item,
                        mapping,
                        price_id=price_id,
                    ),
                )
                if result["created"]:
                    created.append(result["entitlement"])
            except Exception:
                logger.exception(
                    "Failed to create entitlement from checkout",
                    extra={
                        "session_id": session.get("id"),
                        "entitlement_key": mapping["entitlement_key"],
                    },
                )

    return created


async def process_stripe_subscription(
    db: AsyncSession,
    subscription: dict[str, Any],
    event_type: str,
    app_id: UUID,
) -> list[dict[str, Any]]:
    """Process Stripe subscription event (created/updated/deleted).

    - created: Grant entitlements (skip if checkout already created them)
    - updated: Grant or renew entitlements
    - deleted: Set ends_at to current_period_end (don't revoke — user paid)
    """
    metadata = subscription.get("metadata") or {}
    user_id = metadata.get("user_id")
    if not user_id:
        logger.warning(
            "Subscription missing user_id in metadata",
            extra={"subscription_id": subscription.get("id")},
        )
        return []

    current_period_end_ts = subscription.get("current_period_end")
    current_period_end = (
        datetime.fromtimestamp(current_period_end_ts, tz=UTC)
        if current_period_end_ts
        else None
    )

    items_data = (subscription.get("items") or {}).get("data") or []
    results: list[dict[str, Any]] = []

    for item in items_data:
        price_id, product_id = _extract_price_and_product_ids(item)
        if not price_id:
            continue

        mappings = await get_mappings_for_price(db, app_id, price_id)
        if not mappings:
            continue

        for mapping in mappings:
            try:
                if event_type == "deleted":
                    results.extend(
                        await _handle_deleted_subscription_mapping(
                            db,
                            subscription_id=subscription["id"],
                            current_period_end=current_period_end,
                            entitlement_key=mapping["entitlement_key"],
                        )
                    )
                    continue

                if event_type == "created" and await _should_skip_created_subscription_mapping(
                    db,
                    app_id=app_id,
                    user_id=user_id,
                    subscription_id=subscription["id"],
                    entitlement_key=mapping["entitlement_key"],
                ):
                    continue

                result = await grant_entitlement(
                    db,
                    application_id=app_id,
                    beneficiary_user_id=UUID(user_id),
                    entitlement_key=mapping["entitlement_key"],
                    source="stripe_subscription",
                    ends_at=current_period_end,
                    stripe_subscription_id=subscription["id"],
                    stripe_product_id=product_id,
                    stripe_price_id=price_id,
                    triggered_by="webhook",
                    metadata={
                        "stripe_price_id": price_id,
                        "subscription_status": subscription.get("status"),
                    },
                )
                results.append(result["entitlement"])
                await _maybe_renew_updated_subscription(
                    db,
                    subscription_id=subscription["id"],
                    result=result,
                    event_type=event_type,
                    current_period_end=current_period_end,
                )

            except Exception:
                logger.exception(
                    "Failed to process subscription entitlement",
                    extra={
                        "subscription_id": subscription.get("id"),
                        "entitlement_key": mapping["entitlement_key"],
                        "event_type": event_type,
                    },
                )

    return results


async def process_stripe_invoice(
    db: AsyncSession,
    invoice: dict[str, Any],
    app_id: UUID,
) -> list[dict[str, Any]]:
    """Process Stripe invoice payment for subscription renewals.

    Only processes subscription invoices. Extends ends_at for all entitlements
    tied to the subscription.
    """
    subscription_id = invoice.get("subscription")
    if not subscription_id or not isinstance(subscription_id, str):
        return []

    # Find subscription line item to get new period end
    lines = (invoice.get("lines") or {}).get("data") or []
    sub_line = next(
        (
            line
            for line in lines
            if line.get("subscription_item") or line.get("subscription")
        ),
        None,
    )

    if not sub_line:
        logger.info("Invoice has no subscription line items", extra={"invoice_id": invoice.get("id")})
        return []

    period = sub_line.get("period") or {}
    period_end_ts = period.get("end")
    if not period_end_ts:
        logger.warning("Invoice line missing period end", extra={"invoice_id": invoice.get("id")})
        return []

    new_period_end = datetime.fromtimestamp(period_end_ts, tz=UTC)

    renewed = await renew_subscription_entitlements(db, subscription_id, new_period_end)

    if renewed:
        logger.info(
            "Renewed entitlements from invoice",
            extra={
                "count": len(renewed),
                "invoice_id": invoice.get("id"),
                "subscription_id": subscription_id,
            },
        )

    return renewed


# ---------------------------------------------------------------------------
# Mappings — public API
# ---------------------------------------------------------------------------


async def list_mappings(
    db: AsyncSession,
    *,
    application_id: UUID,
    active_only: bool = False,
) -> dict[str, Any]:
    """List entitlement mappings for an application."""
    mappings = await repo.list_mappings(
        db,
        application_id,
        active_only=active_only,
    )
    return {
        "mappings": [_mapping_to_dict(m) for m in mappings],
        "count": len(mappings),
    }


async def create_mapping(
    db: AsyncSession,
    *,
    application_id: UUID,
    stripe_price_id: str,
    entitlement_key: str,
    entitlement_type: str = "one_time",
    duration_days: int | None = None,
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Create a new entitlement mapping.

    Raises MappingAlreadyExistsError on duplicate.
    """
    # Validate time_limited requires duration_days
    if entitlement_type == "time_limited" and not duration_days:
        raise ValidationError(
            "duration_days is required for time_limited entitlement type"
        )

    # Check for duplicate
    existing = await repo.get_mappings_for_price(
        db, application_id, stripe_price_id
    )
    for m in existing:
        if m.entitlement_key == entitlement_key:
            raise MappingAlreadyExistsError()

    mapping = await repo.create_mapping(
        db,
        application_id=application_id,
        stripe_price_id=stripe_price_id,
        entitlement_key=entitlement_key,
        entitlement_type=entitlement_type,
        duration_days=duration_days,
        metadata_=metadata or {},
    )

    logger.info(
        "Entitlement mapping created",
        extra={
            "id": str(mapping.id),
            "stripe_price_id": stripe_price_id,
            "entitlement_key": entitlement_key,
        },
    )

    return {"mapping": _mapping_to_dict(mapping)}


async def update_mapping(
    db: AsyncSession,
    *,
    mapping_id: UUID,
    application_id: UUID,
    entitlement_key: str | None = None,
    entitlement_type: str | None = None,
    duration_days: int | None = None,
    metadata: dict[str, Any] | None = None,
    is_active: bool | None = None,
) -> dict[str, Any]:
    """Update an existing entitlement mapping."""
    kwargs: dict[str, Any] = {}
    if entitlement_key is not None:
        kwargs["entitlement_key"] = entitlement_key
    if entitlement_type is not None:
        kwargs["entitlement_type"] = entitlement_type
    if duration_days is not None:
        kwargs["duration_days"] = duration_days
    if metadata is not None:
        kwargs["metadata"] = metadata
    if is_active is not None:
        kwargs["is_active"] = is_active

    mapping = await repo.update_mapping(
        db, mapping_id, application_id, **kwargs
    )

    if mapping is None:
        raise MappingNotFoundError()

    logger.info("Entitlement mapping updated", extra={"id": str(mapping_id)})

    return {"mapping": _mapping_to_dict(mapping)}


async def deactivate_mapping(
    db: AsyncSession,
    *,
    mapping_id: UUID,
    application_id: UUID,
) -> dict[str, Any]:
    """Soft-delete (deactivate) an entitlement mapping."""
    mapping = await repo.deactivate_mapping(db, mapping_id, application_id)

    if mapping is None:
        raise MappingNotFoundError()

    logger.info("Entitlement mapping deactivated", extra={"id": str(mapping_id)})

    return {
        "mapping": _mapping_to_dict(mapping),
        "message": "Mapping deactivated successfully",
    }
