"""CFO RBAC domain -- role management, feature toggles, and admin API for Cloud CFO Assistant."""
