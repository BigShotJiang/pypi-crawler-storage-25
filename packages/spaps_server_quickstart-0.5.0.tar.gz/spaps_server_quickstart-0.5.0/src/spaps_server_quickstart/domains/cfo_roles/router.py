"""HTTP routes for the CFO RBAC admin domain.

Provides ``cfo_admin_router`` under ``/cfo/admin``.

All routes require CFO admin (via ``CfoAdmin`` dependency).
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from uuid import UUID

from fastapi import APIRouter, Query

from ...middleware.spaps_deps import Application, DbSession
from . import service
from .deps import CfoAdmin
from .schemas import (
    AssignRoleRequest,
    CompanyFeaturesResponse,
    ConvertProspectRequest,
    ConvertProspectResponse,
    CreateRoleAssignmentResponse,
    CreateUserRequest,
    CreateUserResponse,
    DeleteRoleAssignmentResponse,
    DeleteUserResponse,
    GrantSalesResponse,
    ListRoleAssignmentsResponse,
    ListUsersResponse,
    CfoUserDetailOut,
    RoleAssignmentOut,
    RevokeSalesResponse,
    SystemFeaturesResponse,
    UpdateCompanyFeaturesRequest,
    UpdateSystemFeaturesRequest,
)

logger = logging.getLogger(__name__)

cfo_admin_router = APIRouter(prefix="/cfo/admin", tags=["cfo-admin"])


# ===========================================================================
# User Management
# ===========================================================================


@cfo_admin_router.get("/users", response_model=ListUsersResponse)
async def list_users(
    db: DbSession,
    app: Application,
    admin: CfoAdmin,
    status: str | None = Query(default=None),
    search: str | None = Query(default=None),
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
) -> ListUsersResponse:
    """List all CFO users with role counts."""
    result = await service.list_cfo_users(
        db,
        application_id=app.id,
        status_filter=status,
        search=search,
        limit=limit,
        offset=offset,
    )
    return ListUsersResponse(**result)


@cfo_admin_router.post("/users", response_model=CreateUserResponse, status_code=201)
async def create_user(
    body: CreateUserRequest,
    db: DbSession,
    app: Application,
    admin: CfoAdmin,
) -> CreateUserResponse:
    """Register a user for CFO access."""
    result = await service.create_cfo_user(
        db,
        email=body.email,
        name=body.name,
    )
    return CreateUserResponse(**result)


@cfo_admin_router.get("/users/{user_id}", response_model=CfoUserDetailOut)
async def get_user(
    user_id: str,
    db: DbSession,
    app: Application,
    admin: CfoAdmin,
) -> CfoUserDetailOut:
    """Get user details with their role assignments."""
    from ..users import repository as user_repo
    from .errors import UserNotFoundError

    user = await user_repo.get_user_by_id(db, user_id)
    if user is None:
        raise UserNotFoundError()

    # Get role assignments
    companies = await service.get_user_companies(
        db, application_id=app.id, user_id=UUID(user_id)
    )
    status = await service.get_user_status(
        db, application_id=app.id, user_id=UUID(user_id)
    )

    # Avoid cross-application user enumeration: if there is no CFO relationship
    # to this application, treat the user as not found in this scope.
    if status == "pending" and not companies:
        raise UserNotFoundError()

    assignments = [
        RoleAssignmentOut(
            id="",  # Would need entitlement ID
            company_id=c["company_id"] or "",
            company_name=c.get("company_name"),
            role=c["role"],
            assigned_at=datetime.now(UTC).isoformat(),
        )
        for c in companies
    ]

    return CfoUserDetailOut(
        id=str(user.id),
        email=user.email or "",
        name=user.full_name,
        is_admin=getattr(user, "is_admin", False),
        status=status,  # type: ignore[arg-type]
        created_at=user.created_at.isoformat() if user.created_at else datetime.now(UTC).isoformat(),
        assignments=assignments,
    )


@cfo_admin_router.delete("/users/{user_id}", response_model=DeleteUserResponse)
async def delete_user(
    user_id: str,
    db: DbSession,
    app: Application,
    admin: CfoAdmin,
) -> DeleteUserResponse:
    """Soft revoke user — revokes ALL active role assignments."""
    count = await service.revoke_all_roles(
        db,
        application_id=app.id,
        user_id=UUID(user_id),
        by_user_id=UUID(admin.id) if isinstance(admin.id, str) else admin.id,
    )
    return DeleteUserResponse(
        id=user_id,
        status="revoked",
        roles_revoked=count,
    )


@cfo_admin_router.post(
    "/users/{user_id}/grant-sales",
    response_model=GrantSalesResponse,
    status_code=201,
)
async def grant_sales(
    user_id: str,
    db: DbSession,
    app: Application,
    admin: CfoAdmin,
) -> GrantSalesResponse:
    """Grant the system-level sales role to a user."""
    admin_id = UUID(admin.id) if isinstance(admin.id, str) else admin.id
    await service.grant_sales_role(
        db,
        application_id=app.id,
        user_id=UUID(user_id),
        granted_by=admin_id,
    )
    now = datetime.now(UTC).isoformat()
    return GrantSalesResponse(
        user_id=user_id,
        role="sales",
        granted_at=now,
        granted_by=str(admin_id),
    )


@cfo_admin_router.delete(
    "/users/{user_id}/revoke-sales",
    response_model=RevokeSalesResponse,
)
async def revoke_sales(
    user_id: str,
    db: DbSession,
    app: Application,
    admin: CfoAdmin,
) -> RevokeSalesResponse:
    """Revoke the system-level sales role from a user."""
    admin_id = UUID(admin.id) if isinstance(admin.id, str) else admin.id
    await service.revoke_sales_role(
        db,
        application_id=app.id,
        user_id=UUID(user_id),
        revoked_by=admin_id,
    )
    return RevokeSalesResponse(
        user_id=user_id,
        revoked_at=datetime.now(UTC).isoformat(),
    )


# ===========================================================================
# Role Assignments
# ===========================================================================


@cfo_admin_router.get("/role-assignments", response_model=ListRoleAssignmentsResponse)
async def list_role_assignments(
    db: DbSession,
    app: Application,
    admin: CfoAdmin,
    user_id: str | None = Query(default=None),
    company_id: str | None = Query(default=None),
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
) -> ListRoleAssignmentsResponse:
    """List role assignments with optional filters."""
    # Build assignments from entitlements
    from ..entitlements import repository as ent_repo

    kwargs: dict = {
        "resource_type": "company",
        "include_revoked": False,
    }
    if user_id:
        kwargs["user_id"] = UUID(user_id)
    if company_id:
        kwargs["resource_id"] = UUID(company_id)

    entitlements = await ent_repo.list_entitlements(
        db, app.id, **kwargs, limit=limit, offset=offset
    )

    assignments = []
    for ent in entitlements:
        if ent.entitlement_key.startswith("cfo:role:"):
            meta = ent.metadata_ or {}
            assignments.append(
                RoleAssignmentOut(
                    id=str(ent.id),
                    user_id=str(ent.beneficiary_user_id) if ent.beneficiary_user_id else None,
                    company_id=str(ent.resource_id) if ent.resource_id else "",
                    company_name=meta.get("company_name"),
                    role=ent.entitlement_key.replace("cfo:role:", ""),
                    assigned_at=ent.created_at.isoformat() if ent.created_at else "",
                    assigned_by=str(ent.granted_by_user_id) if ent.granted_by_user_id else None,
                )
            )

    return ListRoleAssignmentsResponse(
        assignments=assignments,
        total=len(assignments),
        limit=limit,
        offset=offset,
    )


@cfo_admin_router.post(
    "/role-assignments",
    response_model=CreateRoleAssignmentResponse,
    status_code=201,
)
async def create_role_assignment(
    body: AssignRoleRequest,
    db: DbSession,
    app: Application,
    admin: CfoAdmin,
) -> CreateRoleAssignmentResponse:
    """Assign a role to a user for a company."""
    admin_id = UUID(admin.id) if isinstance(admin.id, str) else admin.id

    # Look up company name (from entitlement metadata or just use the ID)
    # In a full implementation, this would query cfo_companies
    company_name = f"Company {body.company_id[:8]}"

    result = await service.assign_role(
        db,
        application_id=app.id,
        user_id=UUID(body.user_id),
        company_id=UUID(body.company_id),
        company_name=company_name,
        role=body.role,
        assigned_by=admin_id,
    )

    ent = result["entitlement"]
    now = datetime.now(UTC).isoformat()

    return CreateRoleAssignmentResponse(
        id=ent["id"],
        user_id=body.user_id,
        company_id=body.company_id,
        role=body.role,
        assigned_at=now,
        assigned_by=str(admin_id),
    )


@cfo_admin_router.delete(
    "/role-assignments/{assignment_id}",
    response_model=DeleteRoleAssignmentResponse,
)
async def delete_role_assignment(
    assignment_id: str,
    db: DbSession,
    app: Application,
    admin: CfoAdmin,
) -> DeleteRoleAssignmentResponse:
    """Revoke a role assignment (soft delete)."""
    admin_id = UUID(admin.id) if isinstance(admin.id, str) else admin.id

    await service.ent_service.revoke_entitlement(
        db,
        entitlement_id=UUID(assignment_id),
        revoked_by_user_id=admin_id,
        reason="Role assignment revoked by admin",
    )

    return DeleteRoleAssignmentResponse(
        id=assignment_id,
        revoked_at=datetime.now(UTC).isoformat(),
    )


@cfo_admin_router.post(
    "/role-assignments/{assignment_id}/convert",
    response_model=ConvertProspectResponse,
)
async def convert_prospect(
    assignment_id: str,
    body: ConvertProspectRequest,
    db: DbSession,
    app: Application,
    admin: CfoAdmin,
) -> ConvertProspectResponse:
    """Convert a prospect to client (or other role)."""
    admin_id = UUID(admin.id) if isinstance(admin.id, str) else admin.id

    # Get the entitlement to find user_id and company_id
    from ..entitlements import repository as ent_repo
    entitlement = await ent_repo.get_entitlement_by_id(db, UUID(assignment_id))
    if entitlement is None:
        from ..entitlements.errors import EntitlementNotFoundError
        raise EntitlementNotFoundError()

    meta = entitlement.metadata_ or {}

    if entitlement.beneficiary_user_id is None:
        from .errors import UserNotFoundError
        raise UserNotFoundError("Entitlement has no beneficiary user")
    if entitlement.resource_id is None:
        from .errors import CompanyNotFoundError
        raise CompanyNotFoundError("Entitlement has no company resource")

    result = await service.convert_prospect(
        db,
        application_id=app.id,
        entitlement_id=UUID(assignment_id),
        user_id=entitlement.beneficiary_user_id,
        company_id=entitlement.resource_id,
        company_name=meta.get("company_name", "Unknown"),
        new_role=body.new_role,
        converted_by=admin_id,
    )

    return ConvertProspectResponse(**result)


# ===========================================================================
# Company Features
# ===========================================================================


@cfo_admin_router.get(
    "/companies/{company_id}/features",
    response_model=CompanyFeaturesResponse,
)
async def get_company_features(
    company_id: str,
    db: DbSession,
    app: Application,
    admin: CfoAdmin,
) -> CompanyFeaturesResponse:
    """Get feature flags for a company."""
    features = await service.get_company_features(
        db, application_id=app.id, company_id=UUID(company_id)
    )
    return CompanyFeaturesResponse(
        company_id=company_id,
        features=features,
    )


@cfo_admin_router.put(
    "/companies/{company_id}/features",
    response_model=CompanyFeaturesResponse,
)
async def update_company_features(
    company_id: str,
    body: UpdateCompanyFeaturesRequest,
    db: DbSession,
    app: Application,
    admin: CfoAdmin,
) -> CompanyFeaturesResponse:
    """Update feature flags for a company."""
    admin_id = UUID(admin.id) if isinstance(admin.id, str) else admin.id

    for feature_name, enabled in body.features.items():
        await service.set_company_feature(
            db,
            application_id=app.id,
            company_id=UUID(company_id),
            feature_name=feature_name,
            enabled=enabled,
            set_by=admin_id,
        )

    # Return current features
    features = await service.get_company_features(
        db, application_id=app.id, company_id=UUID(company_id)
    )
    return CompanyFeaturesResponse(
        company_id=company_id,
        features=features,
        updated_at=datetime.now(UTC).isoformat(),
    )


# ===========================================================================
# System Kill Switches
# ===========================================================================


@cfo_admin_router.get("/system/features", response_model=SystemFeaturesResponse)
async def get_system_features(
    db: DbSession,
    app: Application,
    admin: CfoAdmin,
) -> SystemFeaturesResponse:
    """Get system-level feature flags."""
    features = await service.get_system_features(
        db, application_id=app.id
    )
    return SystemFeaturesResponse(features=features)


@cfo_admin_router.put("/system/features", response_model=SystemFeaturesResponse)
async def update_system_features(
    body: UpdateSystemFeaturesRequest,
    db: DbSession,
    app: Application,
    admin: CfoAdmin,
) -> SystemFeaturesResponse:
    """Update system-level feature flags."""
    admin_id = UUID(admin.id) if isinstance(admin.id, str) else admin.id

    for feature_name, enabled in body.features.items():
        await service.set_system_feature(
            db,
            application_id=app.id,
            feature_name=feature_name,
            enabled=enabled,
            set_by=admin_id,
        )

    features = await service.get_system_features(
        db, application_id=app.id
    )
    return SystemFeaturesResponse(
        features=features,
        updated_at=datetime.now(UTC).isoformat(),
    )
