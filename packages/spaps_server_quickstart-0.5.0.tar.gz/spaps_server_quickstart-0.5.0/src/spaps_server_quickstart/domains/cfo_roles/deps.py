"""FastAPI dependencies for CFO RBAC domain.

Provides require_cfo_admin dependency accepting either:
1. JWT with is_admin=True (browser/human callers)
2. X-CFO-Admin-Key header (service-to-service from CFO backend)
"""

from __future__ import annotations

import hmac
from types import SimpleNamespace
from typing import Annotated, Any

from fastapi import Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession

from ...middleware.spaps_deps import get_application, get_current_user, get_db_session
from ..errors import ForbiddenError


def _check_is_admin(user: Any) -> None:
    """Verify the user has is_admin flag set.

    Raises ForbiddenError if not admin.
    """
    if not getattr(user, "is_admin", False):
        raise ForbiddenError("Admin access required")


def _check_cfo_admin_key(request: Request) -> Any | None:
    """Check X-CFO-Admin-Key header for service-to-service auth.

    Returns a synthetic admin if key matches, None otherwise.
    """
    settings = getattr(request.app.state, "settings", None)
    if not settings:
        return None

    expected_key = getattr(settings, "cfo_admin_api_key", None)
    if not expected_key:
        return None

    provided_key = _get_cfo_admin_header(request)
    if not provided_key:
        return None

    if not hmac.compare_digest(provided_key, expected_key):
        return None
    return _build_cfo_service_admin()


def _get_cfo_admin_header(request: Request) -> str | None:
    return request.headers.get("X-CFO-Admin-Key") or request.headers.get(
        "CFO_ADMIN_API_KEY"
    )


def _build_cfo_service_admin() -> Any:
    return SimpleNamespace(id="cfo-service", is_admin=True, email="cfo@internal")


async def require_cfo_admin(
    request: Request,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    application: Annotated[Any, Depends(get_application)],
) -> Any:
    """FastAPI dependency: require CFO admin access.

    Accepts either:
    1. X-CFO-Admin-Key header (service-to-service, checked first)
    2. JWT with is_admin=True (browser/human callers)
    """
    # Try API key first (service-to-service)
    admin = _check_cfo_admin_key(request)
    if admin is not None:
        return admin

    # Fall back to JWT auth
    user = await get_current_user(request, session, application)
    _check_is_admin(user)
    return user


# Type alias for convenience in route signatures
CfoAdmin = Annotated[Any, Depends(require_cfo_admin)]
