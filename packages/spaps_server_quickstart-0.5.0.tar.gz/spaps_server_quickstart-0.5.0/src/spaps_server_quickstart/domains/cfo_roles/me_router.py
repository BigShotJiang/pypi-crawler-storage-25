"""HTTP routes for the CFO /me endpoints.

Provides ``cfo_me_router`` under ``/cfo/me``.

These endpoints return the current user's profile, role context,
and authorized companies. Requires JWT authentication only (no admin).
"""

from __future__ import annotations

import asyncio
import logging
from uuid import UUID

from fastapi import APIRouter, Query, Request

from ...middleware.spaps_deps import Application, CurrentUser, DbSession
from ..errors import ForbiddenError
from . import service
from .schemas import (
    MeCompaniesResponse,
    MeCompanyContext,
    MeCompanyItem,
    MeResponse,
    MeUserOut,
)

logger = logging.getLogger(__name__)

cfo_me_router = APIRouter(prefix="/cfo/me", tags=["cfo-me"])


@cfo_me_router.get("", response_model=MeResponse)
async def get_me(
    request: Request,
    db: DbSession,
    app: Application,
    user: CurrentUser,
    company_id: str | None = Query(default=None),
) -> MeResponse:
    """Get current user's profile and company context.

    If company_id not provided, auto-selects the user's first company.
    Returns current_company=None only if user has no companies.
    """
    user_id = UUID(user.id) if isinstance(user.id, str) else user.id

    # 1. Check system-level sales role
    is_sales = await service.has_sales_role(
        db, application_id=app.id, user_id=user_id
    )

    # 2. Get user's companies
    companies = await service.get_user_companies(
        db, application_id=app.id, user_id=user_id
    )

    # 3. Auto-select first company if no company_id provided
    if not company_id and companies:
        company_id = companies[0]["company_id"]

    is_admin = getattr(user, "is_admin", False)
    user_company_ids = {c.get("company_id") for c in companies if c.get("company_id")}

    if company_id and not is_admin and company_id not in user_company_ids:
        raise ForbiddenError("Company access denied")

    # 4. If company_id available (provided or auto-selected), get company context
    current_company = None
    if company_id:
        role = await service.get_user_role_for_company(
            db,
            application_id=app.id,
            user_id=user_id,
            company_id=UUID(company_id),
        )
        features = await service.get_company_features(
            db, application_id=app.id, company_id=UUID(company_id)
        )

        # Get company_name from user's entitlement metadata
        company_name = "Unknown"
        for c in companies:
            if c["company_id"] == company_id:
                company_name = c.get("company_name", "Unknown")
                break

        effective_role = "admin" if is_admin else role

        settings = request.app.state.settings
        connection_count = 0
        if settings.cfo_api_url and company_id:
            connection_count = await service.fetch_company_connection_count(
                cfo_api_url=settings.cfo_api_url,
                cfo_admin_api_key=settings.cfo_admin_api_key,
                company_id=company_id,
                user_id=str(user_id),
            )

        current_company = MeCompanyContext(
            id=company_id,
            company_name=company_name,
            role=effective_role,
            features=features,
            connection_count=connection_count,
        )

    return MeResponse(
        user=MeUserOut(
            id=str(user_id),
            email=getattr(user, "email", None),
            name=getattr(user, "full_name", None) or getattr(user, "username", None),
            is_admin=getattr(user, "is_admin", False),
            is_sales=is_sales,
        ),
        current_company=current_company,
    )


@cfo_me_router.get("/companies", response_model=MeCompaniesResponse)
async def get_my_companies(
    request: Request,
    db: DbSession,
    app: Application,
    user: CurrentUser,
) -> MeCompaniesResponse:
    """Get current user's authorized companies with roles."""
    user_id = UUID(user.id) if isinstance(user.id, str) else user.id

    user_companies = await service.get_user_companies(
        db, application_id=app.id, user_id=user_id
    )

    settings = request.app.state.settings
    counts: dict[str, int] = {}
    if settings.cfo_api_url and user_companies:
        tasks = {
            uc["company_id"]: service.fetch_company_connection_count(
                cfo_api_url=settings.cfo_api_url,
                cfo_admin_api_key=settings.cfo_admin_api_key,
                company_id=uc["company_id"],
                user_id=str(user_id),
            )
            for uc in user_companies
            if uc.get("company_id")
        }
        results = await asyncio.gather(*tasks.values(), return_exceptions=True)
        counts = {
            cid: (r if isinstance(r, int) else 0)
            for cid, r in zip(tasks.keys(), results)
        }

    return MeCompaniesResponse(
        companies=[
            MeCompanyItem(
                id=uc["company_id"] or "",
                name=uc.get("company_name"),
                role=uc["role"],
                connection_count=counts.get(uc["company_id"], 0),
            )
            for uc in user_companies
        ]
    )
