"""Pydantic request/response schemas for CFO RBAC endpoints.

These schemas define the *data* portion of each API response.
The standard response envelope ``{ success, data, error, metadata }``
is applied by middleware -- domain schemas never reference it.

Zero FastAPI imports.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Shared types
# ---------------------------------------------------------------------------

CfoRole = Literal["accountant", "client", "employee", "prospect"]
CfoUserStatus = Literal["pending", "active", "revoked"]


# ---------------------------------------------------------------------------
# Request schemas — User Management
# ---------------------------------------------------------------------------


class CreateUserRequest(BaseModel):
    """POST /admin/users body."""

    email: str = Field(..., min_length=1)
    name: str | None = None


# ---------------------------------------------------------------------------
# Request schemas — Role Assignments
# ---------------------------------------------------------------------------


class AssignRoleRequest(BaseModel):
    """POST /admin/role-assignments body."""

    user_id: str
    company_id: str
    role: CfoRole


class ConvertProspectRequest(BaseModel):
    """POST /admin/role-assignments/:id/convert body."""

    new_role: str


# ---------------------------------------------------------------------------
# Request schemas — Features
# ---------------------------------------------------------------------------


class UpdateCompanyFeaturesRequest(BaseModel):
    """PUT /admin/companies/:id/features body."""

    features: dict[str, bool]


class UpdateSystemFeaturesRequest(BaseModel):
    """PUT /admin/system/features body."""

    features: dict[str, bool]


# ---------------------------------------------------------------------------
# Response schemas — Users
# ---------------------------------------------------------------------------


class CfoUserOut(BaseModel):
    """Canonical representation of a CFO user."""

    id: str
    email: str
    name: str | None = None
    is_admin: bool = False
    status: CfoUserStatus
    created_at: str


class CfoUserDetailOut(CfoUserOut):
    """User with their role assignments."""

    assignments: list[RoleAssignmentOut] = []


class CfoUserListItem(CfoUserOut):
    """User in a list response with role count."""

    role_count: int = 0


class ListUsersResponse(BaseModel):
    """GET /admin/users -- success payload."""

    users: list[CfoUserListItem]
    total: int
    limit: int
    offset: int


class CreateUserResponse(BaseModel):
    """POST /admin/users -- success payload."""

    id: str
    email: str
    name: str | None = None
    is_admin: bool = False
    status: CfoUserStatus = "pending"
    created_at: str


class DeleteUserResponse(BaseModel):
    """DELETE /admin/users/:id -- success payload."""

    id: str
    status: str = "revoked"
    roles_revoked: int


class GrantSalesResponse(BaseModel):
    """POST /admin/users/:id/grant-sales -- success payload."""

    user_id: str
    role: str = "sales"
    granted_at: str
    granted_by: str


class RevokeSalesResponse(BaseModel):
    """DELETE /admin/users/:id/revoke-sales -- success payload."""

    user_id: str
    revoked_at: str


# ---------------------------------------------------------------------------
# Response schemas — Role Assignments
# ---------------------------------------------------------------------------


class RoleAssignmentOut(BaseModel):
    """Canonical representation of a role assignment."""

    id: str
    user_id: str | None = None
    user_email: str | None = None
    company_id: str
    company_name: str | None = None
    role: str
    assigned_at: str
    assigned_by: str | None = None


# Fix forward reference for CfoUserDetailOut
CfoUserDetailOut.model_rebuild()


class ListRoleAssignmentsResponse(BaseModel):
    """GET /admin/role-assignments -- success payload."""

    assignments: list[RoleAssignmentOut]
    total: int
    limit: int
    offset: int


class CreateRoleAssignmentResponse(BaseModel):
    """POST /admin/role-assignments -- success payload."""

    id: str
    user_id: str
    company_id: str
    role: str
    assigned_at: str
    assigned_by: str


class DeleteRoleAssignmentResponse(BaseModel):
    """DELETE /admin/role-assignments/:id -- success payload."""

    id: str
    revoked_at: str


class ConvertProspectResponse(BaseModel):
    """POST /admin/role-assignments/:id/convert -- success payload."""

    previous: dict[str, Any]
    current: dict[str, Any]
    company_status: str = "active"


# ---------------------------------------------------------------------------
# Response schemas — Features
# ---------------------------------------------------------------------------


class CompanyFeaturesResponse(BaseModel):
    """GET/PUT /admin/companies/:id/features -- success payload."""

    company_id: str
    company_name: str | None = None
    features: dict[str, bool]
    updated_at: str | None = None


class SystemFeaturesResponse(BaseModel):
    """GET/PUT /admin/system/features -- success payload."""

    features: dict[str, bool]
    updated_at: str | None = None


# ---------------------------------------------------------------------------
# Response schemas — Current User (/me)
# ---------------------------------------------------------------------------


class MeUserOut(BaseModel):
    """User info in /me response."""

    id: str
    email: str | None = None
    name: str | None = None
    is_admin: bool = False
    is_sales: bool = False


class MeCompanyContext(BaseModel):
    """Company context in /me response."""

    id: str
    company_name: str | None = None
    role: str | None = None
    features: dict[str, bool] = {}
    connection_count: int = 0


class MeResponse(BaseModel):
    """GET /me -- success payload."""

    user: MeUserOut
    current_company: MeCompanyContext | None = None


class MeCompanyItem(BaseModel):
    """Company item in /me/companies response."""

    id: str
    name: str | None = None
    role: str
    connection_count: int = 0


class MeCompaniesResponse(BaseModel):
    """GET /me/companies -- success payload."""

    companies: list[MeCompanyItem]
