"""Business logic for the CFO RBAC domain.

Coordinates entitlement service calls for CFO role management,
feature toggles, and system kill switches.
This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import logging
import re
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from sqlalchemy import case, func, literal, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..entitlements import repository as ent_repo
from ..entitlements.models import Entitlement
from ..users.models import User
from ..entitlements import service as ent_service
from ..users import repository as user_repo
from .errors import (
    AlreadyAssignedError,
    AlreadySalesError,
    InvalidEmailError,
    InvalidRoleError,
    NotProspectError,
    NotSalesError,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# CFO enrichment
# ---------------------------------------------------------------------------


async def fetch_company_connection_count(
    cfo_api_url: str,
    cfo_admin_api_key: str,
    company_id: str,
    user_id: str,
) -> int:
    """Fetch connection count from CFO server. Returns 0 on any failure."""
    import httpx

    if not cfo_api_url or not user_id:
        return 0

    url = f"{cfo_api_url.rstrip('/')}/api/companies/{company_id}"
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(3.0, connect=2.0)) as client:
            resp = await client.get(
                url,
                headers={
                    "X-API-Key": cfo_admin_api_key,
                    "X-User-Id": user_id,
                },
            )
        if resp.status_code != 200:
            logger.warning(
                "CFO enrichment failed: %s %s",
                resp.status_code,
                company_id,
            )
            return 0
        payload = resp.json()
        data = payload.get("data") if isinstance(payload, dict) and isinstance(payload.get("data"), dict) else payload
        if not isinstance(data, dict):
            return 0
        # Try connection_count directly, fall back to len(connections)
        if "connection_count" in data:
            return int(data["connection_count"])
        if "connections" in data and isinstance(data["connections"], list):
            return len(data["connections"])
        return 0
    except Exception:
        logger.warning("CFO enrichment error for company %s", company_id, exc_info=True)
        return 0


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Per-company roles (require company_id)
PER_COMPANY_ROLES = {"accountant", "client", "employee", "prospect"}

# All valid roles including per-company conversion targets
VALID_PER_COMPANY_ROLES = PER_COMPANY_ROLES

# Role hierarchy — higher level inherits all permissions of lower levels.
# Sales and prospect are NOT in this hierarchy.
ROLE_HIERARCHY: dict[str, int] = {
    "admin": 4,
    "accountant": 3,
    "client": 2,
    "employee": 1,
}

_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


# ---------------------------------------------------------------------------
# Role hierarchy helper
# ---------------------------------------------------------------------------


def has_minimum_role(user_role: str, required: str) -> bool:
    """Check if a user's role meets the minimum required level.

    Sales and prospect are NOT in the hierarchy — they always return False
    for hierarchy checks.
    """
    user_level = ROLE_HIERARCHY.get(user_role, 0)
    required_level = ROLE_HIERARCHY.get(required)
    if required_level is None:
        return False
    return user_level >= required_level


def is_feature_enabled_check(
    system_features: dict[str, bool],
    feature_name: str,
    is_admin: bool,
) -> bool:
    """Check if a feature is enabled. Admin always bypasses kill switches."""
    if is_admin:
        return True
    # Absent = enabled; stored = disabled (False)
    return system_features.get(feature_name, True)


# ---------------------------------------------------------------------------
# Role assignment
# ---------------------------------------------------------------------------


async def assign_role(
    db: AsyncSession,
    *,
    application_id: UUID,
    user_id: UUID,
    company_id: UUID,
    company_name: str,
    role: str,
    assigned_by: UUID,
) -> dict[str, Any]:
    """Assign a per-company role to a user.

    One role per user per company. Sales is system-level (use grant_sales_role).
    """
    if role not in PER_COMPANY_ROLES:
        raise InvalidRoleError(f"Role must be one of: {', '.join(sorted(PER_COMPANY_ROLES))}")

    # Check for existing role for this user+company
    existing = await ent_repo.list_entitlements(
        db,
        application_id,
        user_id=user_id,
        resource_type="company",
        resource_id=company_id,
        include_revoked=False,
    )
    # Filter to cfo:role:* only
    cfo_roles = [e for e in existing if e.entitlement_key.startswith("cfo:role:")]
    if cfo_roles:
        raise AlreadyAssignedError()

    result = await ent_service.grant_entitlement(
        db,
        application_id=application_id,
        beneficiary_user_id=user_id,
        entitlement_key=f"cfo:role:{role}",
        source="manual",
        resource_type="company",
        resource_id=company_id,
        granted_by_user_id=assigned_by,
        triggered_by="api",
        metadata={"company_name": company_name},
    )

    return result


async def get_user_role_for_company(
    db: AsyncSession,
    *,
    application_id: UUID,
    user_id: UUID,
    company_id: UUID,
) -> str | None:
    """Get user's CFO role for a specific company. Returns None if no role."""
    entitlements = await ent_repo.list_entitlements(
        db,
        application_id,
        user_id=user_id,
        resource_type="company",
        resource_id=company_id,
        include_revoked=False,
    )
    for ent in entitlements:
        if ent.entitlement_key.startswith("cfo:role:"):
            return ent.entitlement_key.replace("cfo:role:", "")
    return None


async def get_user_companies(
    db: AsyncSession,
    *,
    application_id: UUID,
    user_id: UUID,
) -> list[dict[str, Any]]:
    """Get all companies a user has roles for."""
    entitlements = await ent_repo.list_entitlements(
        db,
        application_id,
        user_id=user_id,
        resource_type="company",
        include_revoked=False,
    )
    companies = []
    for ent in entitlements:
        if ent.entitlement_key.startswith("cfo:role:"):
            meta = ent.metadata_ or {}
            companies.append({
                "company_id": str(ent.resource_id) if ent.resource_id else None,
                "company_name": meta.get("company_name", "Unknown"),
                "role": ent.entitlement_key.replace("cfo:role:", ""),
            })
    return companies


# ---------------------------------------------------------------------------
# Sales role (system-level)
# ---------------------------------------------------------------------------


async def has_sales_role(
    db: AsyncSession,
    *,
    application_id: UUID,
    user_id: UUID,
) -> bool:
    """Check if user has the system-level sales role."""
    entitlements = await ent_repo.list_entitlements(
        db,
        application_id,
        user_id=user_id,
        entitlement_key="cfo:role:sales",
        include_revoked=False,
    )
    return len(entitlements) > 0


async def grant_sales_role(
    db: AsyncSession,
    *,
    application_id: UUID,
    user_id: UUID,
    granted_by: UUID,
) -> dict[str, Any]:
    """Grant the system-level sales role to a user."""
    # Check if already has sales
    existing = await ent_repo.list_entitlements(
        db,
        application_id,
        user_id=user_id,
        entitlement_key="cfo:role:sales",
        include_revoked=False,
    )
    if existing:
        raise AlreadySalesError()

    result = await ent_service.grant_entitlement(
        db,
        application_id=application_id,
        beneficiary_user_id=user_id,
        entitlement_key="cfo:role:sales",
        source="manual",
        resource_type="user",
        granted_by_user_id=granted_by,
        triggered_by="api",
    )
    return result


async def revoke_sales_role(
    db: AsyncSession,
    *,
    application_id: UUID,
    user_id: UUID,
    revoked_by: UUID,
) -> dict[str, Any]:
    """Revoke the system-level sales role from a user."""
    existing = await ent_repo.list_entitlements(
        db,
        application_id,
        user_id=user_id,
        entitlement_key="cfo:role:sales",
        include_revoked=False,
    )
    if not existing:
        raise NotSalesError()

    result = await ent_service.revoke_entitlement(
        db,
        entitlement_id=existing[0].id,
        revoked_by_user_id=revoked_by,
        reason="Sales role revoked by admin",
    )
    return result


# ---------------------------------------------------------------------------
# Revoke all roles
# ---------------------------------------------------------------------------


async def revoke_all_roles(
    db: AsyncSession,
    *,
    application_id: UUID,
    user_id: UUID,
    by_user_id: UUID,
) -> int:
    """Soft revoke all cfo:role:* entitlements for a user. Returns count."""
    # Get all active role entitlements (both per-company and system-level)
    entitlements = await ent_repo.list_entitlements(
        db,
        application_id,
        user_id=user_id,
        include_revoked=False,
    )
    cfo_roles = [e for e in entitlements if e.entitlement_key.startswith("cfo:role:")]

    count = 0
    for ent in cfo_roles:
        await ent_service.revoke_entitlement(
            db,
            entitlement_id=ent.id,
            revoked_by_user_id=by_user_id,
            reason="User revoked by admin",
        )
        count += 1

    return count


# ---------------------------------------------------------------------------
# User status
# ---------------------------------------------------------------------------


async def get_user_status(
    db: AsyncSession,
    *,
    application_id: UUID,
    user_id: UUID,
) -> str:
    """Derive user status: pending / active / revoked."""
    # Check for active roles
    active = await ent_repo.list_entitlements(
        db,
        application_id,
        user_id=user_id,
        include_revoked=False,
    )
    active_roles = [e for e in active if e.entitlement_key.startswith("cfo:role:")]
    if active_roles:
        return "active"

    # Check for any revoked roles
    all_ents = await ent_repo.list_entitlements(
        db,
        application_id,
        user_id=user_id,
        include_revoked=True,
        include_expired=True,
    )
    revoked_roles = [
        e for e in all_ents
        if e.entitlement_key.startswith("cfo:role:") and e.revoked_at is not None
    ]
    if revoked_roles:
        return "revoked"

    return "pending"


# ---------------------------------------------------------------------------
# Company users
# ---------------------------------------------------------------------------


async def get_company_users(
    db: AsyncSession,
    *,
    application_id: UUID,
    company_id: UUID,
) -> list[dict[str, Any]]:
    """Get all users with roles for a company."""
    entitlements = await ent_repo.list_entitlements(
        db,
        application_id,
        resource_type="company",
        resource_id=company_id,
        include_revoked=False,
    )
    users = []
    for ent in entitlements:
        if ent.entitlement_key.startswith("cfo:role:"):
            users.append({
                "user_id": str(ent.beneficiary_user_id) if ent.beneficiary_user_id else None,
                "role": ent.entitlement_key.replace("cfo:role:", ""),
                "entitlement_id": str(ent.id),
                "assigned_at": ent.created_at.isoformat() if ent.created_at else None,
            })
    return users


# ---------------------------------------------------------------------------
# Prospect conversion
# ---------------------------------------------------------------------------


async def convert_prospect(
    db: AsyncSession,
    *,
    application_id: UUID,
    entitlement_id: UUID,
    user_id: UUID,
    company_id: UUID,
    company_name: str,
    new_role: str,
    converted_by: UUID,
) -> dict[str, Any]:
    """Convert a prospect to another role (atomic revoke + reassign).

    Steps:
    1. Revoke prospect role (SPAPS)
    2. Assign new role (SPAPS)
    3. Company status update is done by the caller (CFO server)
    """
    if new_role not in PER_COMPANY_ROLES and new_role not in ROLE_HIERARCHY:
        raise InvalidRoleError(f"Invalid target role: {new_role}")

    # Verify the entitlement is a prospect role
    entitlement = await ent_repo.get_entitlement_by_id(db, entitlement_id)
    if entitlement is None or entitlement.entitlement_key != "cfo:role:prospect":
        raise NotProspectError()

    # 1. Revoke prospect role
    await ent_service.revoke_entitlement(
        db,
        entitlement_id=entitlement_id,
        revoked_by_user_id=converted_by,
        reason=f"Converted to {new_role}",
    )

    # 2. Assign new role
    assign_result = await ent_service.grant_entitlement(
        db,
        application_id=application_id,
        beneficiary_user_id=user_id,
        entitlement_key=f"cfo:role:{new_role}",
        source="manual",
        resource_type="company",
        resource_id=company_id,
        granted_by_user_id=converted_by,
        triggered_by="api",
        metadata={"company_name": company_name},
    )

    now = datetime.now(UTC).isoformat()
    return {
        "previous": {
            "id": str(entitlement_id),
            "role": "prospect",
            "revoked_at": now,
        },
        "current": {
            "id": assign_result["entitlement"]["id"],
            "user_id": str(user_id),
            "company_id": str(company_id),
            "role": new_role,
            "assigned_at": now,
            "assigned_by": str(converted_by),
        },
        "company_status": "active",
    }


# ---------------------------------------------------------------------------
# Feature toggles (per-company)
# ---------------------------------------------------------------------------


async def get_company_features(
    db: AsyncSession,
    *,
    application_id: UUID,
    company_id: UUID,
) -> dict[str, bool]:
    """Get enabled features for a company."""
    entitlements = await ent_repo.list_entitlements(
        db,
        application_id,
        resource_type="company",
        resource_id=company_id,
        include_revoked=False,
    )
    features: dict[str, bool] = {}
    for ent in entitlements:
        if ent.entitlement_key.startswith("cfo:feature:"):
            feature_name = ent.entitlement_key.replace("cfo:feature:", "")
            features[feature_name] = True
    return features


async def set_company_feature(
    db: AsyncSession,
    *,
    application_id: UUID,
    company_id: UUID,
    feature_name: str,
    enabled: bool,
    set_by: UUID,
) -> None:
    """Enable or disable a feature for a company."""
    key = f"cfo:feature:{feature_name}"

    existing = await ent_repo.list_entitlements(
        db,
        application_id,
        entitlement_key=key,
        resource_type="company",
        resource_id=company_id,
        include_revoked=False,
    )

    if enabled and not existing:
        await ent_service.grant_entitlement(
            db,
            application_id=application_id,
            entitlement_key=key,
            source="manual",
            resource_type="company",
            resource_id=company_id,
            granted_by_user_id=set_by,
            triggered_by="api",
        )
    elif not enabled and existing:
        for ent in existing:
            await ent_service.revoke_entitlement(
                db,
                entitlement_id=ent.id,
                revoked_by_user_id=set_by,
                reason=f"Feature {feature_name} disabled by admin",
            )


# ---------------------------------------------------------------------------
# System kill switches
# ---------------------------------------------------------------------------


async def get_system_features(
    db: AsyncSession,
    *,
    application_id: UUID,
) -> dict[str, bool]:
    """Get system-level feature flags. Stored = disabled."""
    entitlements = await ent_repo.list_entitlements(
        db,
        application_id,
        resource_type="system",
        include_revoked=False,
    )
    killed: dict[str, bool] = {}
    for ent in entitlements:
        if ent.entitlement_key.startswith("cfo:system:"):
            feature_name = ent.entitlement_key.replace("cfo:system:", "")
            killed[feature_name] = False  # stored means disabled
    return killed


async def set_system_feature(
    db: AsyncSession,
    *,
    application_id: UUID,
    feature_name: str,
    enabled: bool,
    set_by: UUID,
) -> None:
    """Enable or disable a system-level feature (inverted: stored = disabled)."""
    key = f"cfo:system:{feature_name}"

    existing = await ent_repo.list_entitlements(
        db,
        application_id,
        entitlement_key=key,
        resource_type="system",
        include_revoked=False,
    )

    if not enabled and not existing:
        # Kill (disable) — create the entitlement
        await ent_service.grant_entitlement(
            db,
            application_id=application_id,
            entitlement_key=key,
            source="manual",
            resource_type="system",
            granted_by_user_id=set_by,
            triggered_by="api",
        )
    elif enabled and existing:
        # Re-enable — revoke the kill switch
        for ent in existing:
            await ent_service.revoke_entitlement(
                db,
                entitlement_id=ent.id,
                revoked_by_user_id=set_by,
                reason=f"System feature {feature_name} re-enabled by admin",
            )


# ---------------------------------------------------------------------------
# User listing (admin)
# ---------------------------------------------------------------------------


async def list_cfo_users(
    db: AsyncSession,
    *,
    application_id: UUID,
    status_filter: str | None = None,
    search: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> dict[str, Any]:
    """List CFO users with role counts, status, and pagination.

    A "CFO user" is any user who has at least one ``cfo:role:*``
    entitlement (active or revoked).

    Returns ``{"users": [...], "total": int, "limit": int, "offset": int}``.
    """
    now = datetime.now(UTC)

    # ── Build a subquery that aggregates per-user entitlement stats ──
    # active_count: number of non-revoked, non-expired cfo:role:* entitlements
    # has_revoked:  1 if any revoked cfo:role:* entitlement exists, else 0
    active_expr = case(
        (
            (Entitlement.revoked_at.is_(None))
            & ((Entitlement.ends_at.is_(None)) | (Entitlement.ends_at > now)),
            literal(1),
        ),
        else_=literal(0),
    )

    revoked_expr = case(
        (Entitlement.revoked_at.isnot(None), literal(1)),
        else_=literal(0),
    )

    ent_stats = (
        select(
            Entitlement.beneficiary_user_id.label("user_id"),
            func.sum(active_expr).label("active_count"),
            func.max(revoked_expr).label("has_revoked"),
        )
        .where(
            Entitlement.application_id == application_id,
            Entitlement.entitlement_key.like("cfo:role:%"),
            Entitlement.beneficiary_user_id.isnot(None),
        )
        .group_by(Entitlement.beneficiary_user_id)
        .subquery("ent_stats")
    )

    # ── Derive status column ──
    derived_status = case(
        (ent_stats.c.active_count > 0, literal("active")),
        (ent_stats.c.has_revoked > 0, literal("revoked")),
        else_=literal("pending"),
    ).label("status")

    # ── Main query: join users with the stats subquery ──
    base = (
        select(
            User.id,
            User.email,
            User.full_name.label("name"),
            User.is_admin,
            derived_status,
            ent_stats.c.active_count.label("role_count"),
            User.created_at,
        )
        .join(ent_stats, User.id == ent_stats.c.user_id)
    )

    # ── Apply optional filters ──
    if status_filter:
        base = base.where(derived_status == status_filter)

    if search:
        pattern = f"%{search}%"
        base = base.where(
            User.email.ilike(pattern) | User.full_name.ilike(pattern)
        )

    # ── Count total (before pagination) ──
    count_stmt = select(func.count()).select_from(base.subquery())
    total = (await db.execute(count_stmt)).scalar_one()

    # ── Apply pagination and ordering ──
    data_stmt = (
        base
        .order_by(User.email.asc())
        .limit(limit)
        .offset(offset)
    )
    rows = (await db.execute(data_stmt)).all()

    users = [
        {
            "id": str(row.id),
            "email": row.email or "",
            "name": row.name,
            "is_admin": row.is_admin,
            "status": row.status,
            "role_count": int(row.role_count),
            "created_at": row.created_at.isoformat() if row.created_at else now.isoformat(),
        }
        for row in rows
    ]

    return {
        "users": users,
        "total": total,
        "limit": limit,
        "offset": offset,
    }


# ---------------------------------------------------------------------------
# User management
# ---------------------------------------------------------------------------


async def create_cfo_user(
    db: AsyncSession,
    *,
    email: str,
    name: str | None = None,
) -> dict[str, Any]:
    """Register a user for CFO access.

    If email matches existing SPAPS user, links to it.
    Otherwise the user must sign up separately via SPAPS.
    """
    if not _EMAIL_RE.match(email):
        raise InvalidEmailError()

    existing_user = await user_repo.get_user_by_email(db, email.lower())
    if existing_user:
        return {
            "id": str(existing_user.id),
            "email": existing_user.email,
            "name": existing_user.full_name or name,
            "is_admin": getattr(existing_user, "is_admin", False),
            "status": "pending",
            "created_at": existing_user.created_at.isoformat() if existing_user.created_at else datetime.now(UTC).isoformat(),
        }

    # No existing SPAPS user — return a placeholder record
    # The user will be created when they sign up via SPAPS magic link / password
    # For now we rely on entitlement beneficiary_email for linking
    now = datetime.now(UTC)
    return {
        "id": "pending",
        "email": email.lower(),
        "name": name,
        "is_admin": False,
        "status": "pending",
        "created_at": now.isoformat(),
    }
