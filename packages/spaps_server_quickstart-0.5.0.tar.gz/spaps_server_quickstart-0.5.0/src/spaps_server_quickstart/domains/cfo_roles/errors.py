"""Domain errors for the cfo_roles domain."""

from __future__ import annotations

from ..errors import DomainError


class UserNotFoundError(DomainError):
    """Raised when a CFO user is not found."""

    def __init__(self, message: str = "User not found") -> None:
        super().__init__("USER_NOT_FOUND", message, status_code=404)


class CompanyNotFoundError(DomainError):
    """Raised when a company is not found."""

    def __init__(self, message: str = "Company not found") -> None:
        super().__init__("COMPANY_NOT_FOUND", message, status_code=404)


class InvalidRoleError(DomainError):
    """Raised when the role is not in the allowed list."""

    def __init__(self, message: str = "Invalid role") -> None:
        super().__init__("INVALID_ROLE", message, status_code=400)


class CompanyRequiredError(DomainError):
    """Raised when company_id is required but missing."""

    def __init__(self, message: str = "Per-company roles require company_id") -> None:
        super().__init__("COMPANY_REQUIRED", message, status_code=400)


class AlreadyAssignedError(DomainError):
    """Raised when user already has a role for this company."""

    def __init__(self, message: str = "User already has a role for this company") -> None:
        super().__init__("ALREADY_ASSIGNED", message, status_code=409)


class AlreadySalesError(DomainError):
    """Raised when user already has the sales role."""

    def __init__(self, message: str = "User already has the sales role") -> None:
        super().__init__("ALREADY_SALES", message, status_code=409)


class NotSalesError(DomainError):
    """Raised when user doesn't have the sales role."""

    def __init__(self, message: str = "User doesn't have the sales role") -> None:
        super().__init__("NOT_SALES", message, status_code=400)


class NotProspectError(DomainError):
    """Raised when trying to convert a non-prospect role."""

    def __init__(self, message: str = "Current role is not prospect") -> None:
        super().__init__("NOT_PROSPECT", message, status_code=400)


class InvalidEmailError(DomainError):
    """Raised when email format is invalid."""

    def __init__(self, message: str = "Invalid email format") -> None:
        super().__init__("INVALID_EMAIL", message, status_code=400)


class EmailExistsError(DomainError):
    """Raised when email is already registered in CFO."""

    def __init__(self, message: str = "Email already registered in CFO") -> None:
        super().__init__("EMAIL_EXISTS", message, status_code=409)
