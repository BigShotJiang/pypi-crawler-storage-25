"""Database operations for the secure_messages domain.

Pure SQLAlchemy async repository -- no FastAPI imports.
All functions accept an ``AsyncSession`` as the first positional argument.
"""

from __future__ import annotations

import logging
from typing import Any
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .models import SecureMessage

logger = logging.getLogger(__name__)


async def create_message(
    db: AsyncSession,
    **kwargs: Any,
) -> SecureMessage:
    """Insert a new secure message and return the persisted instance."""
    message = SecureMessage(**kwargs)
    db.add(message)
    await db.flush()
    await db.refresh(message)
    return message


async def list_messages(
    db: AsyncSession,
    application_id: UUID,
) -> list[SecureMessage]:
    """List all secure messages for an application, newest first."""
    stmt = (
        select(SecureMessage)
        .where(SecureMessage.application_id == application_id)
        .order_by(SecureMessage.created_at.desc())
    )
    result = await db.execute(stmt)
    return list(result.scalars().all())
