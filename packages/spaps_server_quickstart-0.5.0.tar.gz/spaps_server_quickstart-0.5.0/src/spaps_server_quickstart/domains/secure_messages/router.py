"""HTTP routes for the secure_messages domain.

Provides ``secure_messages_router`` under ``/secure-messages``.

TM-013: Endpoints require API Key + JWT authentication and enforce
participant authorization and fail-closed PII encryption.
"""

from __future__ import annotations

import logging
from uuid import UUID

from fastapi import APIRouter, Request

from ...middleware.spaps_deps import Application, CurrentUser, DbSession
from . import service
from .encryption import PiiEncryptionService
from .errors import SecureMessagesEncryptionRequiredError
from .schemas import (
    CreateSecureMessageRequest,
    CreateSecureMessageResponse,
    ListSecureMessagesResponse,
)

logger = logging.getLogger(__name__)


secure_messages_router = APIRouter(prefix="/secure-messages", tags=["secure-messages"])


def _get_pii_context(app: object, request: Request) -> tuple[bool, PiiEncryptionService | None]:
    """Resolve PII encryption context from the application settings.

    TM-013: Fail-closed enforcement - raises if pii_enabled but no key.

    Returns ``(pii_enabled, encryption_service_or_none)``.

    Raises:
        SecureMessagesEncryptionRequiredError: If pii_enabled but no master key
    """
    settings = getattr(app, "settings", None) or {}
    pii_enabled = bool(settings.get("pii_enabled", False))
    if not pii_enabled:
        return False, None

    # Get master key from app settings
    spaps_settings = request.app.state.settings
    master_key = getattr(spaps_settings, "spaps_pii_master_key", "")
    if not master_key:
        # TM-013: Fail closed instead of falling back to plaintext
        logger.error(
            "PII encryption required but SPAPS_PII_MASTER_KEY not configured",
            extra={
                "application_id": str(app.id) if hasattr(app, "id") else "unknown",
                "pii_enabled": pii_enabled,
                "threat_id": "TM-013",
            },
        )
        raise SecureMessagesEncryptionRequiredError(
            "PII encryption is required but SPAPS_PII_MASTER_KEY is not configured"
        )

    return True, PiiEncryptionService(master_key=master_key)


@secure_messages_router.post("", response_model=CreateSecureMessageResponse, status_code=201)
async def create_message(
    body: CreateSecureMessageRequest,
    db: DbSession,
    app: Application,
    user: CurrentUser,  # TM-013: JWT required
    request: Request,
) -> CreateSecureMessageResponse:
    """Create a secure message, encrypting content if PII is enabled.

    TM-013: Requires API key + JWT authentication and participant authorization.
    """
    pii_enabled, enc_svc = _get_pii_context(app, request)

    result = await service.create_message(
        db,
        application_id=app.id if isinstance(app.id, UUID) else UUID(str(app.id)),
        patient_id=body.patientId,
        practitioner_id=body.practitionerId,
        content=body.content,
        metadata=body.metadata,
        pii_enabled=pii_enabled,
        encryption_service=enc_svc,
        current_user_id=user.id,  # TM-013: Pass user for participant check
        is_admin=user.is_admin,
    )
    return CreateSecureMessageResponse(**result)


@secure_messages_router.get("", response_model=ListSecureMessagesResponse)
async def list_messages(
    db: DbSession,
    app: Application,
    user: CurrentUser,  # TM-013: JWT required
    request: Request,
) -> ListSecureMessagesResponse:
    """List secure messages for the application, decrypting if PII is enabled.

    TM-013: Requires API key + JWT authentication and filters by participant.
    """
    pii_enabled, enc_svc = _get_pii_context(app, request)

    result = await service.list_messages(
        db,
        application_id=app.id if isinstance(app.id, UUID) else UUID(str(app.id)),
        pii_enabled=pii_enabled,
        encryption_service=enc_svc,
        participant_id=user.id,  # TM-013: Filter by participant
        is_admin=user.is_admin,
    )
    return ListSecureMessagesResponse(**result)
