"""Pydantic request/response schemas for secure message endpoints.

Zero FastAPI imports.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel


# ---------------------------------------------------------------------------
# Request schemas
# ---------------------------------------------------------------------------


class CreateSecureMessageRequest(BaseModel):
    """POST /secure-messages request body."""

    patientId: str
    practitionerId: str
    content: str
    metadata: dict[str, Any] | None = None


# ---------------------------------------------------------------------------
# Response schemas
# ---------------------------------------------------------------------------


class SecureMessageOut(BaseModel):
    """Canonical representation of a secure message."""

    id: str
    application_id: str
    patient_id: str
    practitioner_id: str
    content: str
    metadata: dict[str, Any] | None = None
    created_at: str


class CreateSecureMessageResponse(BaseModel):
    """POST /secure-messages -- success payload."""

    id: str
    application_id: str
    patient_id: str
    practitioner_id: str
    content: str
    metadata: dict[str, Any] | None = None
    created_at: str


class ListSecureMessagesResponse(BaseModel):
    """GET /secure-messages -- success payload."""

    messages: list[SecureMessageOut]
