"""
PII encryption service: AES-256-GCM with HKDF-SHA256 key derivation.

This module MUST produce ciphertext byte-compatible with the existing
Node.js ``piiEncryptionService.ts``.  Compatibility hinges on:

1. HKDF parameters  (salt = ``spaps-pii-v1``, info = applicationId, len = 32)
2. Value serialisation  (JSON envelope with ``__type`` / ``value``)
3. Outer wrapper JSON field ordering  (v, alg, iv, tag, data)
4. Compact JSON with no spaces  (``separators=(',', ':')``)
5. Standard base64 encoding of IV, tag, data, and the full wrapper

No FastAPI imports.
"""

from __future__ import annotations

import base64
import json
import os
from typing import Any, Callable, Sequence

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.hashes import SHA256
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

# ---------------------------------------------------------------------------
# Constants -- must match Node.js piiEncryptionService.ts exactly
# ---------------------------------------------------------------------------

_HKDF_SALT: bytes = b"spaps-pii-v1"
_KEY_LENGTH_BYTES: int = 32
_IV_LENGTH_BYTES: int = 12
_DEFAULT_MASTER_KEY_ENV: str = "SPAPS_PII_MASTER_KEY"


# ---------------------------------------------------------------------------
# Value encoding (matches Node.js ``stringifyValue`` / ``parseValue``)
# ---------------------------------------------------------------------------


def _stringify_value(value: Any) -> str:
    """Encode *value* into the type-envelope JSON string.

    Strings  -> ``{"__type":"string","value":"<the string>"}``
    Others   -> ``{"__type":"json","value":<the value>}``
    ``None`` (Python equivalent of JS ``undefined``) -> literal ``"null"``
    """
    if value is None:
        return "null"
    if isinstance(value, str):
        return json.dumps({"__type": "string", "value": value}, separators=(",", ":"))
    return json.dumps({"__type": "json", "value": value}, separators=(",", ":"))


def _parse_value(serialised: str) -> Any:
    """Reverse of :func:`_stringify_value`."""
    try:
        payload = json.loads(serialised)
        if isinstance(payload, dict) and payload.get("__type") in ("string", "json"):
            return payload["value"]
    except (json.JSONDecodeError, TypeError, KeyError):
        pass
    return serialised


# ---------------------------------------------------------------------------
# Key derivation
# ---------------------------------------------------------------------------


def _require_master_key(explicit_key: str | None = None) -> bytes:
    master_key = explicit_key or os.environ.get(_DEFAULT_MASTER_KEY_ENV)
    if not master_key:
        raise RuntimeError(f"Missing PII encryption master key. Set {_DEFAULT_MASTER_KEY_ENV}.")
    key_bytes = master_key.encode("utf-8")
    if len(key_bytes) < 16:
        raise RuntimeError("PII encryption master key must be at least 16 bytes.")
    return key_bytes


def derive_key(master_key: bytes, application_id: str) -> bytes:
    """Derive a per-application 32-byte key using HKDF-SHA256.

    Parameters match Node.js exactly:
    - salt: ``b"spaps-pii-v1"``
    - info: ``application_id`` encoded as UTF-8
    - length: 32
    """
    if not application_id:
        raise ValueError("applicationId is required to derive encryption key")

    hkdf = HKDF(
        algorithm=SHA256(),
        length=_KEY_LENGTH_BYTES,
        salt=_HKDF_SALT,
        info=application_id.encode("utf-8"),
    )
    return hkdf.derive(master_key)


# ---------------------------------------------------------------------------
# Encrypt / Decrypt primitives
# ---------------------------------------------------------------------------


def _encrypt_field(
    key: bytes,
    value: Any,
    random_bytes_fn: Callable[[int], bytes] | None = None,
) -> str:
    """Encrypt a single value, returning the base64 outer-wrapper string."""
    iv = (random_bytes_fn or os.urandom)(_IV_LENGTH_BYTES)
    if len(iv) != _IV_LENGTH_BYTES:
        raise RuntimeError(f"PII encryption IV must be {_IV_LENGTH_BYTES} bytes")

    plaintext = _stringify_value(value).encode("utf-8")
    aesgcm = AESGCM(key)

    # AESGCM.encrypt returns ciphertext || tag (tag is last 16 bytes)
    ct_with_tag = aesgcm.encrypt(iv, plaintext, None)
    ciphertext = ct_with_tag[:-16]
    auth_tag = ct_with_tag[-16:]

    # Build the outer JSON wrapper with EXACT field order matching Node.js
    outer = json.dumps(
        {
            "v": 1,
            "alg": "aes-256-gcm",
            "iv": base64.b64encode(iv).decode("ascii"),
            "tag": base64.b64encode(auth_tag).decode("ascii"),
            "data": base64.b64encode(ciphertext).decode("ascii"),
        },
        separators=(",", ":"),
    )
    return base64.b64encode(outer.encode("utf-8")).decode("ascii")


def _decrypt_field(key: bytes, encoded: str) -> Any:
    """Decrypt a base64 outer-wrapper string, returning the original value."""
    try:
        outer_json = base64.b64decode(encoded).decode("utf-8")
        payload = json.loads(outer_json)
    except (json.JSONDecodeError, ValueError, TypeError, KeyError, UnicodeDecodeError):
        return encoded  # not encrypted or corrupt -- return as-is

    iv = base64.b64decode(payload["iv"])
    auth_tag = base64.b64decode(payload["tag"])
    ciphertext = base64.b64decode(payload["data"])

    aesgcm = AESGCM(key)
    # AESGCM.decrypt expects ciphertext || tag
    plaintext_bytes = aesgcm.decrypt(iv, ciphertext + auth_tag, None)
    return _parse_value(plaintext_bytes.decode("utf-8"))


# ---------------------------------------------------------------------------
# Public API -- record-level encrypt/decrypt
# ---------------------------------------------------------------------------


class PiiEncryptionService:
    """Stateful PII encryption service matching Node.js ``PiiEncryptionService``."""

    def __init__(
        self,
        *,
        master_key: str | None = None,
        random_bytes_fn: Callable[[int], bytes] | None = None,
    ) -> None:
        self._master_key = _require_master_key(master_key)
        self._random_bytes_fn = random_bytes_fn

    def derive_key(self, application_id: str) -> bytes:
        return derive_key(self._master_key, application_id)

    def encrypt_field(self, *, application_id: str, value: Any) -> str:
        """Encrypt a single value for an application."""
        key = self.derive_key(application_id)
        return _encrypt_field(key, value, self._random_bytes_fn)

    def decrypt_field(self, *, application_id: str, encoded: str) -> Any:
        """Decrypt a single encrypted value for an application."""
        key = self.derive_key(application_id)
        return _decrypt_field(key, encoded)

    def encrypt_record(
        self,
        *,
        application_id: str,
        record: dict[str, Any],
        fields: Sequence[str],
    ) -> dict[str, Any]:
        """Encrypt specified fields of a dict, returning a new dict."""
        key = self.derive_key(application_id)
        result = dict(record)
        for field in fields:
            value = record.get(field)
            if value is None:
                continue
            result[field] = _encrypt_field(key, value, self._random_bytes_fn)
        return result

    def decrypt_record(
        self,
        *,
        application_id: str,
        record: dict[str, Any],
        fields: Sequence[str],
    ) -> dict[str, Any]:
        """Decrypt specified fields of a dict, returning a new dict."""
        key = self.derive_key(application_id)
        result = dict(record)
        for field in fields:
            value = record.get(field)
            if not isinstance(value, str):
                continue
            result[field] = _decrypt_field(key, value)
        return result
