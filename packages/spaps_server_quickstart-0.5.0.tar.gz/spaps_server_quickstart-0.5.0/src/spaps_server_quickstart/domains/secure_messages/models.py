"""SQLAlchemy models for the secure_messages domain."""

from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID, uuid4

from sqlalchemy import (
    DateTime,
    ForeignKey,
    func,
)
from sqlalchemy.dialects.postgresql import JSON
from sqlalchemy.orm import Mapped, mapped_column

from .._db import Base, PGUUID, EncryptedText


class SecureMessage(Base):
    """Secure message with PII-encrypted content.

    The ``encrypted_content`` column stores either plaintext (when the
    application has ``pii_enabled=false``) or an AES-256-GCM encrypted
    payload in the canonical base64 wrapper format.
    """

    __tablename__ = "secure_messages"

    id: Mapped[UUID] = mapped_column(PGUUID(as_uuid=True), primary_key=True, default=uuid4)
    application_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("applications.id", ondelete="CASCADE"),
        nullable=False,
    )
    patient_id: Mapped[UUID] = mapped_column(PGUUID(as_uuid=True), nullable=False)
    practitioner_id: Mapped[UUID] = mapped_column(PGUUID(as_uuid=True), nullable=False)
    encrypted_content: Mapped[str | None] = mapped_column(EncryptedText, nullable=True)
    metadata_: Mapped[dict[str, Any] | None] = mapped_column(
        "metadata", JSON, nullable=True, default=dict
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    def __repr__(self) -> str:
        return f"<SecureMessage id={self.id!r} app={self.application_id!r}>"
