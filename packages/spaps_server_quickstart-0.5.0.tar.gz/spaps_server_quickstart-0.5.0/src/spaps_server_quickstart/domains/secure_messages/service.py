"""Business logic for the secure_messages domain.

Coordinates repository calls, encryption, and raises domain errors.
This module is pure domain logic -- no FastAPI imports.
"""

from __future__ import annotations

import logging
from typing import Any
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from .encryption import PiiEncryptionService
from .errors import (
    MissingIdentifiersError,
    SecureMessagesEncryptionRequiredError,
    SecureMessagesForbiddenParticipantError,
)
from . import repository as repo

logger = logging.getLogger(__name__)


def _message_to_dict(msg: Any, *, content: str) -> dict[str, Any]:
    """Convert a SecureMessage model instance to a serialisable dict."""
    return {
        "id": str(msg.id),
        "application_id": str(msg.application_id),
        "patient_id": str(msg.patient_id),
        "practitioner_id": str(msg.practitioner_id),
        "content": content,
        "metadata": msg.metadata_,
        "created_at": msg.created_at.isoformat() if msg.created_at else None,
    }


async def create_message(
    db: AsyncSession,
    *,
    application_id: UUID,
    patient_id: str,
    practitioner_id: str,
    content: str,
    metadata: dict[str, Any] | None = None,
    pii_enabled: bool = False,
    encryption_service: PiiEncryptionService | None = None,
    current_user_id: str | None = None,
    is_admin: bool = False,
) -> dict[str, Any]:
    """Create a new secure message, optionally encrypting content.

    TM-013: Requires participant authorization and fail-closed encryption.

    Args:
        db: Database session
        application_id: Application ID
        patient_id: Patient UUID
        practitioner_id: Practitioner UUID
        content: Message content
        metadata: Optional metadata
        pii_enabled: Whether PII encryption is enabled
        encryption_service: Encryption service (required if pii_enabled=True)
        current_user_id: Current authenticated user ID (for participant check)
        is_admin: Whether current user is admin (bypasses participant check)

    Returns:
        Dict suitable for the response envelope.

    Raises:
        MissingIdentifiersError: If required identifiers are missing
        SecureMessagesForbiddenParticipantError: If user is not a participant
        SecureMessagesEncryptionRequiredError: If pii_enabled but no encryption service
    """
    if not application_id or not patient_id or not practitioner_id:
        raise MissingIdentifiersError()

    # TM-013: Participant authorization check
    if current_user_id and not is_admin:
        if current_user_id != patient_id and current_user_id != practitioner_id:
            logger.warning(
                "Participant authorization denied",
                extra={
                    "user_id": current_user_id,
                    "patient_id": patient_id,
                    "practitioner_id": practitioner_id,
                    "threat_id": "TM-013",
                },
            )
            raise SecureMessagesForbiddenParticipantError()

    # TM-013: Fail-closed encryption enforcement
    if pii_enabled:
        if encryption_service is None:
            logger.error(
                "PII encryption required but not available",
                extra={
                    "application_id": str(application_id),
                    "pii_enabled": pii_enabled,
                    "threat_id": "TM-013",
                },
            )
            raise SecureMessagesEncryptionRequiredError()

        encrypted = encryption_service.encrypt_record(
            application_id=str(application_id),
            record={"content": content},
            fields=["content"],
        )
        stored_content = encrypted["content"]
    else:
        stored_content = content

    record_data: dict[str, Any] = {
        "application_id": application_id,
        "patient_id": patient_id,
        "practitioner_id": practitioner_id,
        "encrypted_content": stored_content,
        "metadata_": metadata or {},
    }

    msg = await repo.create_message(db, **record_data)

    logger.info(
        "Secure message created",
        extra={
            "id": str(msg.id),
            "application_id": str(application_id),
            "pii_enabled": pii_enabled,
        },
    )

    # Return the original (unencrypted) content in the response
    return _message_to_dict(msg, content=content)


async def list_messages(
    db: AsyncSession,
    *,
    application_id: UUID,
    pii_enabled: bool = False,
    encryption_service: PiiEncryptionService | None = None,
    participant_id: str | None = None,
    is_admin: bool = False,
) -> dict[str, Any]:
    """List secure messages for an application, decrypting if needed.

    TM-013: Filters by participant and enforces fail-closed encryption.

    Args:
        db: Database session
        application_id: Application ID
        pii_enabled: Whether PII encryption is enabled
        encryption_service: Encryption service (required if pii_enabled=True)
        participant_id: Current user ID (filters to messages where user is participant)
        is_admin: Whether current user is admin (sees all messages)

    Returns:
        Dict with a ``messages`` list.

    Raises:
        SecureMessagesEncryptionRequiredError: If pii_enabled but no encryption service
    """
    # TM-013: Fail-closed encryption enforcement
    if pii_enabled and encryption_service is None:
        logger.error(
            "PII encryption required but not available",
            extra={
                "application_id": str(application_id),
                "pii_enabled": pii_enabled,
                "threat_id": "TM-013",
            },
        )
        raise SecureMessagesEncryptionRequiredError()

    rows = await repo.list_messages(db, application_id)

    messages: list[dict[str, Any]] = []
    for row in rows:
        # TM-013: Participant filtering (unless admin)
        if participant_id and not is_admin:
            # Only include messages where user is patient or practitioner
            if str(row.patient_id) != participant_id and str(row.practitioner_id) != participant_id:
                continue

        content_value = ""

        if pii_enabled and encryption_service and isinstance(row.encrypted_content, str):
            decrypted = encryption_service.decrypt_record(
                application_id=str(application_id),
                record={"content": row.encrypted_content},
                fields=["content"],
            )
            content_value = str(decrypted.get("content", ""))
        elif isinstance(row.encrypted_content, str):
            content_value = row.encrypted_content

        messages.append(_message_to_dict(row, content=content_value))

    return {"messages": messages}
