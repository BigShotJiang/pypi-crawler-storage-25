"""Domain errors for the secure_messages domain."""

from __future__ import annotations

from ..errors import DomainError


class SecureMessageCreateError(DomainError):
    """Raised when a secure message cannot be created."""

    def __init__(self, message: str = "Failed to create secure message") -> None:
        super().__init__("SECURE_MESSAGE_CREATE_FAILED", message, status_code=500)


class SecureMessageListError(DomainError):
    """Raised when secure messages cannot be listed."""

    def __init__(self, message: str = "Failed to list secure messages") -> None:
        super().__init__("SECURE_MESSAGE_LIST_FAILED", message, status_code=500)


class MissingIdentifiersError(DomainError):
    """Raised when required identifiers are missing."""

    def __init__(
        self,
        message: str = "Missing required identifiers for secure message",
    ) -> None:
        super().__init__("VALIDATION_ERROR", message, status_code=400)


class SecureMessagesEncryptionRequiredError(DomainError):
    """Raised when PII encryption is required but not available."""

    def __init__(
        self,
        message: str = "PII encryption is required but encryption key is not configured",
    ) -> None:
        super().__init__("SECURE_MESSAGES_ENCRYPTION_REQUIRED", message, status_code=500)


class SecureMessagesForbiddenParticipantError(DomainError):
    """Raised when user is not a participant in the secure message."""

    def __init__(
        self,
        message: str = "Access denied: user is not a participant in this message",
    ) -> None:
        super().__init__("SECURE_MESSAGES_FORBIDDEN_PARTICIPANT", message, status_code=403)
