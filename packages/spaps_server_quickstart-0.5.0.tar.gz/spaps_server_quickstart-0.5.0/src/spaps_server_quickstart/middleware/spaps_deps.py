"""
SPAPS FastAPI dependency functions.

Provides reusable dependencies for route handlers:
- get_db_session: async database session
- get_application: validated application from API key
- get_current_user: authenticated user from JWT
- get_optional_user: authenticated user if JWT present, else None
- require_admin_user: admin-only access
- require_super_admin_user: super admin-only access
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Annotated, Any

from fastapi import Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession

if TYPE_CHECKING:
    from .jwt_auth import AuthenticatedUser

from ..db.session import DatabaseResources
from ..domains.errors import DomainError

logger = logging.getLogger(__name__)


async def get_db_session(request: Request):
    """Get an async database session from app state."""
    db_resources: DatabaseResources = request.app.state.db_resources
    async for session in db_resources.session_dependency():
        yield session


async def get_settings(request: Request):
    """Get SPAPS settings from app state."""
    return request.app.state.settings


async def get_application(
    request: Request,
    session: Annotated[AsyncSession, Depends(get_db_session)],
):
    """
    Validate API key and return the application.

    In local mode, returns a fake application.
    Otherwise, extracts X-API-Key and validates against DB.
    """
    from ..domains.errors import InvalidApplicationError
    from .api_key import KeyType, extract_api_key, validate_api_key
    from .key_scope import is_endpoint_allowed_for_publishable
    from .local_mode import LOCAL_APPLICATION, get_local_user
    from .origin_validation import validate_origin

    settings = request.app.state.settings

    # Local mode bypass
    if settings.is_spaps_local_mode:
        request.state.is_local_mode = True
        request.state.application = LOCAL_APPLICATION
        request.state.application_id = str(LOCAL_APPLICATION.id)
        request.state.key_type = KeyType.SECRET

        # Set local user context
        user_key = (
            request.query_params.get("_user")
            or request.headers.get("X-Test-User")
        )
        local_user = get_local_user(user_key)
        request.state.local_user = local_user
        return LOCAL_APPLICATION

    # Extract API key
    api_key = extract_api_key(request)
    if not api_key:
        raise InvalidApplicationError("Missing API key")

    # Validate key (TM-009: respect legacy_api_key_auth_enabled setting)
    app, key_type = await validate_api_key(
        session,
        api_key,
        legacy_api_key_auth_enabled=settings.legacy_api_key_auth_enabled,
    )
    if app is None:
        raise InvalidApplicationError("Invalid API key")

    request.state.application = app
    request.state.application_id = str(app.id)
    request.state.key_type = key_type

    # Publishable key scope enforcement
    if key_type == KeyType.PUBLISHABLE:
        if not is_endpoint_allowed_for_publishable(request.url.path):
            raise InvalidApplicationError(
                "This endpoint requires a secret key"
            )

        # Origin validation for publishable keys
        origin = request.headers.get("Origin")
        allowed = getattr(app, "allowed_origins", None) or []
        if not validate_origin(origin, allowed):
            raise InvalidApplicationError("Origin not allowed")

    return app


async def get_current_user(
    request: Request,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    application: Annotated[Any, Depends(get_application)],
):
    """
    Authenticate user via JWT Bearer token.

    In local mode, returns the selected local user.
    Raises UnauthorizedError if no valid JWT is present.
    """
    from ..domains.errors import UnauthorizedError
    from .jwt_auth import AuthenticatedUser, authenticate_jwt, extract_bearer_token
    from .local_mode import LocalTestUser

    settings = request.app.state.settings

    # Local mode: return local user as AuthenticatedUser
    if getattr(request.state, "is_local_mode", False):
        local_user: LocalTestUser = request.state.local_user
        user = AuthenticatedUser(
            id=local_user.id,
            email=local_user.email,
            username=local_user.username,
            application_id=str(application.id),
            tier=local_user.tier,
            roles=local_user.roles,
            permissions=local_user.permissions,
            is_admin=local_user.is_admin,
            is_super_admin=local_user.is_super_admin,
            wallet_addresses=local_user.wallet_addresses,
        )
        request.state.user = user
        request.state.jwt_payload = {}
        return user

    # Extract JWT
    token = extract_bearer_token(request)
    if not token:
        raise UnauthorizedError("Authentication required")

    payload, user = await authenticate_jwt(
        token,
        jwt_secret=settings.jwt_secret,
        session=session,
    )

    # TM-012: Enforce that JWT app_id matches the API key's application_id.
    # Prevents cross-app confusion where a token minted for app A is used
    # with app B's API key.
    api_key_app_id = getattr(request.state, "application_id", None)
    if api_key_app_id and user.application_id and user.application_id != api_key_app_id:
        from ..domains.errors import ForbiddenError
        raise ForbiddenError("Token application mismatch")

    request.state.user = user
    request.state.jwt_payload = payload
    return user


async def get_optional_user(
    request: Request,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    application: Annotated[Any, Depends(get_application)],
) -> AuthenticatedUser | None:
    """
    Optionally authenticate user via JWT.

    Returns None if no JWT is present (does not raise).
    """
    from .jwt_auth import AuthenticatedUser, authenticate_jwt, extract_bearer_token
    from .local_mode import LocalTestUser

    settings = request.app.state.settings

    # Local mode
    if getattr(request.state, "is_local_mode", False):
        local_user: LocalTestUser = request.state.local_user
        user = AuthenticatedUser(
            id=local_user.id,
            email=local_user.email,
            username=local_user.username,
            application_id=str(application.id),
            tier=local_user.tier,
            roles=local_user.roles,
            permissions=local_user.permissions,
            is_admin=local_user.is_admin,
            is_super_admin=local_user.is_super_admin,
            wallet_addresses=local_user.wallet_addresses,
        )
        request.state.user = user
        return user

    token = extract_bearer_token(request)
    if not token:
        return None

    try:
        payload, user = await authenticate_jwt(
            token,
            jwt_secret=settings.jwt_secret,
            session=session,
        )

        # TM-012: Enforce app binding for optional user too
        api_key_app_id = getattr(request.state, "application_id", None)
        if api_key_app_id and user.application_id and user.application_id != api_key_app_id:
            return None

        request.state.user = user
        request.state.jwt_payload = payload
        return user
    except (DomainError, ValueError, KeyError):
        return None


async def require_admin_user(
    user: Annotated[Any, Depends(get_current_user)],
):
    """Require the authenticated user to be an admin."""
    from .jwt_auth import require_admin

    require_admin(user)
    return user


async def require_super_admin_user(
    user: Annotated[Any, Depends(get_current_user)],
):
    """Require the authenticated user to be a super admin."""
    from .jwt_auth import require_super_admin

    require_super_admin(user)
    return user


# Type aliases for common dependency patterns
DbSession = Annotated[AsyncSession, Depends(get_db_session)]
CurrentUser = Annotated[Any, Depends(get_current_user)]
OptionalUser = Annotated[Any, Depends(get_optional_user)]
Application = Annotated[Any, Depends(get_application)]
AdminUser = Annotated[Any, Depends(require_admin_user)]
SuperAdminUser = Annotated[Any, Depends(require_super_admin_user)]
