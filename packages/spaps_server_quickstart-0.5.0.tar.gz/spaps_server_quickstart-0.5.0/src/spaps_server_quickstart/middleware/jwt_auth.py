"""
JWT authentication middleware for SPAPS.

Extracts Bearer token from Authorization header, verifies it,
checks the blacklist, and sets request.state.jwt_payload / request.state.user.
"""

from __future__ import annotations

import dataclasses
import logging
from dataclasses import dataclass, field
from typing import Any

from fastapi import Request
from sqlalchemy.ext.asyncio import AsyncSession

logger = logging.getLogger(__name__)


@dataclass
class AuthenticatedUser:
    """User context extracted from JWT + optional DB hydration."""

    id: str
    email: str | None = None
    username: str | None = None
    application_id: str | None = None
    tier: str | None = None
    roles: list[str] = field(default_factory=lambda: ["user"])
    permissions: list[str] = field(default_factory=lambda: ["view_products"])
    is_admin: bool = False
    is_super_admin: bool = False
    wallet_addresses: list[str] = field(default_factory=list)
    jti: str | None = None


def extract_bearer_token(request: Request) -> str | None:
    """Extract JWT from Authorization: Bearer header."""
    auth_header = request.headers.get("Authorization", "")
    if auth_header.startswith("Bearer "):
        token = auth_header[7:]
        # Must look like a JWT (3 dot-separated parts)
        if token.count(".") == 2:
            return token
    return None


async def authenticate_jwt(
    token: str,
    *,
    jwt_secret: str,
    session: AsyncSession | None = None,
) -> tuple[dict[str, Any], AuthenticatedUser]:
    """
    Verify JWT token, check blacklist, and return (payload, user).

    Raises:
        UnauthorizedError: if token is missing
        InvalidTokenError: if token is expired or invalid
        InvalidRefreshTokenError: if token is blacklisted
    """
    from ..domains.errors import InvalidTokenError
    from ..domains.sessions.jwt_service import verify_access_token

    try:
        payload = verify_access_token(token, jwt_secret)
    except Exception:
        raise InvalidTokenError("Invalid or expired access token")

    # Check blacklist
    jti = payload.jti
    if jti and session:
        from ..domains.sessions.blacklist_service import is_blacklisted

        if await is_blacklisted(session, jti):
            raise InvalidTokenError("Token has been revoked")

    # Build AuthenticatedUser from JWT claims
    user = AuthenticatedUser(
        id=payload.sub,
        email=payload.email,
        application_id=payload.app_id,
        tier=payload.tier,
        roles=payload.roles or ["user"],
        permissions=payload.permissions or ["view_products"],
        is_admin=payload.isAdmin,
        is_super_admin=payload.isSuperAdmin,
        wallet_addresses=payload.wallets,
        jti=jti,
    )

    return dataclasses.asdict(payload), user


def require_admin(user: AuthenticatedUser) -> None:
    """Raise ForbiddenError if user is not an admin."""
    from ..domains.errors import ForbiddenError

    if not user.is_admin and "admin" not in user.roles:
        raise ForbiddenError("Admin access required")


def require_super_admin(user: AuthenticatedUser) -> None:
    """Raise ForbiddenError if user is not a super admin."""
    from ..domains.errors import ForbiddenError

    if not user.is_super_admin and "super_admin" not in user.roles:
        raise ForbiddenError("Super admin access required")
