"""
Global error handlers for the SPAPS FastAPI application.

Translates DomainError exceptions and other errors into the standard
response envelope format.
"""

from __future__ import annotations

import logging
import uuid
from datetime import UTC, datetime
from typing import Any

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from ..domains.errors import DomainError

logger = logging.getLogger(__name__)


def _to_json_safe(value: Any) -> Any:
    """Recursively coerce non-JSON-serialisable values to strings."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(k): _to_json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_to_json_safe(v) for v in value]
    return str(value)


def _build_error_response(
    *,
    status_code: int,
    code: str,
    message: str,
    details: dict | None = None,
    request_id: str | None = None,
) -> JSONResponse:
    """Build a standard error response envelope."""
    return JSONResponse(
        status_code=status_code,
        content={
            "success": False,
            "data": None,
            "error": {
                "code": code,
                "message": message,
                "details": details or {},
            },
            "metadata": {
                "timestamp": datetime.now(UTC).isoformat(),
                "request_id": request_id or str(uuid.uuid4()),
            },
        },
    )


def _get_request_id(request: Request) -> str:
    return getattr(request.state, "request_id", None) or request.headers.get(  # type: ignore[return-value]
        "X-Request-ID", str(uuid.uuid4())
    )


def install_error_handlers(app: FastAPI) -> None:
    """Register global exception handlers on the FastAPI app."""

    @app.exception_handler(DomainError)
    async def domain_error_handler(request: Request, exc: DomainError) -> JSONResponse:
        return _build_error_response(
            status_code=exc.status_code,
            code=exc.code,
            message=exc.message,
            details=exc.details,
            request_id=_get_request_id(request),
        )

    @app.exception_handler(RequestValidationError)
    async def validation_error_handler(
        request: Request, exc: RequestValidationError
    ) -> JSONResponse:
        return _build_error_response(
            status_code=400,
            code="VALIDATION_ERROR",
            message="Request validation failed",
            details={"errors": _to_json_safe(exc.errors())},
            request_id=_get_request_id(request),
        )

    @app.exception_handler(Exception)
    async def unhandled_error_handler(request: Request, exc: Exception) -> JSONResponse:
        logger.exception("Unhandled exception: %s", exc)
        return _build_error_response(
            status_code=500,
            code="SERVER_ERROR",
            message="Internal server error",
            request_id=_get_request_id(request),
        )
