"""
Security headers middleware.

Sets standard security response headers on every response to protect against
common web vulnerabilities (XSS, clickjacking, MIME sniffing, etc.).

Mirrors the Helmet.js defaults from the legacy Node.js SPAPS service.

Headers set:
  Content-Security-Policy
  Strict-Transport-Security (HSTS)
  X-Frame-Options: DENY
  X-Content-Type-Options: nosniff
  X-XSS-Protection: 1; mode=block
  Referrer-Policy: strict-origin-when-cross-origin
  Permissions-Policy: geolocation=(), microphone=(), camera=(), payment=(self)
"""

from __future__ import annotations


from starlette.types import ASGIApp, Message, Receive, Scope, Send


# Default header values matching the SPAPS backend spec.
DEFAULT_CSP = (
    "default-src 'self'; "
    "script-src 'self' 'unsafe-inline' https://js.stripe.com; "
    "style-src 'self' 'unsafe-inline'; "
    "img-src 'self' data: https:; "
    "font-src 'self' data:; "
    "connect-src 'self' https://api.stripe.com; "
    "frame-src https://js.stripe.com https://hooks.stripe.com; "
    "object-src 'none'; "
    "base-uri 'self'; "
    "form-action 'self'"
)

DEFAULT_HSTS = "max-age=63072000; includeSubDomains; preload"

DEFAULT_PERMISSIONS_POLICY = (
    "geolocation=(), microphone=(), camera=(), payment=(self)"
)


class SecurityHeadersMiddleware:
    """Pure ASGI middleware that sets standard security headers on every HTTP response.

    Uses the raw ASGI protocol to inject headers into the ``http.response.start``
    message, ensuring headers are applied even when upstream middleware or the
    application raises an exception that is caught by a later handler.

    All header values can be overridden via constructor kwargs so deployments
    or tests can customise policy without subclassing.

    Parameters
    ----------
    app:
        The ASGI application to wrap.
    csp:
        Content-Security-Policy header value.
    hsts:
        Strict-Transport-Security header value.
    frame_options:
        X-Frame-Options header value.
    content_type_options:
        X-Content-Type-Options header value.
    xss_protection:
        X-XSS-Protection header value.
    referrer_policy:
        Referrer-Policy header value.
    permissions_policy:
        Permissions-Policy header value.
    """

    def __init__(
        self,
        app: ASGIApp,
        *,
        csp: str = DEFAULT_CSP,
        hsts: str = DEFAULT_HSTS,
        frame_options: str = "DENY",
        content_type_options: str = "nosniff",
        xss_protection: str = "1; mode=block",
        referrer_policy: str = "strict-origin-when-cross-origin",
        permissions_policy: str = DEFAULT_PERMISSIONS_POLICY,
    ) -> None:
        self.app = app
        self._raw_headers: list[tuple[bytes, bytes]] = [
            (b"content-security-policy", csp.encode()),
            (b"strict-transport-security", hsts.encode()),
            (b"x-frame-options", frame_options.encode()),
            (b"x-content-type-options", content_type_options.encode()),
            (b"x-xss-protection", xss_protection.encode()),
            (b"referrer-policy", referrer_policy.encode()),
            (b"permissions-policy", permissions_policy.encode()),
        ]

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        response_started = False

        async def send_with_headers(message: Message) -> None:
            nonlocal response_started
            if message["type"] == "http.response.start":
                response_started = True
                headers = list(message.get("headers", []))
                headers.extend(self._raw_headers)
                message = {**message, "headers": headers}
            await send(message)

        try:
            await self.app(scope, receive, send_with_headers)
        except Exception:
            # If the response has not started yet, emit a minimal 500
            # with security headers so that error pages are still protected.
            if not response_started:
                await send_with_headers(
                    {
                        "type": "http.response.start",
                        "status": 500,
                        "headers": [(b"content-type", b"text/plain; charset=utf-8")],
                    }
                )
                await send(
                    {
                        "type": "http.response.body",
                        "body": b"Internal Server Error",
                    }
                )
            else:
                raise
