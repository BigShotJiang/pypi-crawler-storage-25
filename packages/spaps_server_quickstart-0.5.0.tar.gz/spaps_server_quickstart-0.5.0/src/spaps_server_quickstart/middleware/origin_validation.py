"""
Origin validation middleware for SPAPS.

For publishable keys: validates Origin header against application.allowed_origins.
Secret and legacy keys skip origin validation.

Supports:
- Exact match: "https://example.com"
- Wildcard subdomain: "*.example.com"
- Deep wildcard: "**.example.com"
- Wildcard port: "localhost:*"
"""

from __future__ import annotations

import fnmatch
import logging
from urllib.parse import urlparse

logger = logging.getLogger(__name__)


def validate_origin(origin: str | None, allowed_origins: list[str] | None) -> bool:
    """
    Check if the origin is allowed.

    TM-009: Empty allowed_origins now DENIES all origins for publishable keys.
    Applications must explicitly configure allowed_origins.
    """
    if not allowed_origins:
        return False

    if not origin:
        # No origin header — reject for publishable keys
        return False

    for pattern in allowed_origins:
        if _origin_matches(origin, pattern):
            return True

    return False


def _origin_matches(origin: str, pattern: str) -> bool:
    """Check if an origin matches an allowed_origin pattern."""
    # Exact match (case-insensitive)
    if origin.lower() == pattern.lower():
        return True

    # Wildcard port: "localhost:*" matches "http://localhost:3000"
    if ":*" in pattern:
        base_pattern = pattern.replace(":*", "")
        parsed = urlparse(origin)
        origin_host = parsed.hostname or ""
        if origin_host == base_pattern or origin.rstrip("/").rsplit(":", 1)[0].endswith(base_pattern):
            return True

    # Deep wildcard: "**.example.com" matches any depth of subdomain
    if pattern.startswith("**."):
        domain = pattern[3:]
        parsed = urlparse(origin)
        origin_host = parsed.hostname or ""
        if origin_host == domain or origin_host.endswith("." + domain):
            return True

    # Wildcard subdomain: "*.example.com" matches one level of subdomain
    if pattern.startswith("*."):
        domain = pattern[2:]
        parsed = urlparse(origin)
        origin_host = parsed.hostname or ""
        if origin_host.endswith("." + domain):
            # Ensure only one subdomain level
            prefix = origin_host[: -len(domain)]
            if prefix and "." not in prefix.rstrip("."):
                return True

    # fnmatch for glob patterns
    parsed = urlparse(origin)
    origin_host = parsed.hostname or ""
    if fnmatch.fnmatch(origin_host, pattern):
        return True

    return False
