"""
Response envelope middleware.

Wraps ALL JSON responses in the standard SPAPS envelope:

    {
        "success": true/false,
        "data": { ... },
        "error": { "code": "...", "message": "...", "details": { ... } } | null,
        "metadata": { "timestamp": "ISO8601", "request_id": "uuid" }
    }

Responses that are already enveloped (contain a top-level "success" key) are
passed through unchanged. Non-JSON responses (HTML, plain text, binary) are
also passed through unchanged.
"""

from __future__ import annotations

import json
import uuid
from datetime import UTC, datetime

from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import Response


class ResponseEnvelopeMiddleware(BaseHTTPMiddleware):
    """Wrap JSON responses in the standard SPAPS response envelope."""

    # Paths that should NOT be enveloped (health, docs, metrics, OpenAPI)
    PASSTHROUGH_PREFIXES = (
        "/docs",
        "/redoc",
        "/openapi.json",
        "/api-docs",
        "/api/metrics",
    )

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        # Generate request_id early so error handlers can use it
        request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
        request.state.request_id = request_id

        response = await call_next(request)

        # Track metrics counters
        from ..api.domains.metrics_router import increment_error_count, increment_request_count

        increment_request_count()
        if response.status_code >= 400:
            increment_error_count()

        # Skip non-JSON and passthrough paths
        if self._should_skip(request, response):
            return response

        # Read body — use body_iterator when available, else response.body
        body_bytes = b""
        if hasattr(response, "body_iterator"):
            async for chunk in response.body_iterator:
                if isinstance(chunk, str):
                    body_bytes += chunk.encode("utf-8")
                else:
                    body_bytes += chunk
        elif hasattr(response, "body"):
            body_bytes = response.body
        else:
            return response

        if not body_bytes:
            return response

        try:
            body = json.loads(body_bytes)
        except (json.JSONDecodeError, UnicodeDecodeError):
            return Response(
                content=body_bytes,
                status_code=response.status_code,
                headers=dict(response.headers),
                media_type=response.media_type,
            )

        # Already enveloped — pass through
        if isinstance(body, dict) and "success" in body:
            return Response(
                content=body_bytes,
                status_code=response.status_code,
                headers=dict(response.headers),
                media_type="application/json",
            )

        # Build envelope — omit the irrelevant key to match Express
        is_success = 200 <= response.status_code < 400
        envelope: dict[str, object] = {
            "success": is_success,
        }
        if is_success:
            envelope["data"] = body
        else:
            envelope["error"] = body
        envelope["metadata"] = {
            "timestamp": datetime.now(UTC).isoformat(),
            "request_id": request_id,
        }

        envelope_bytes = json.dumps(envelope, default=str).encode("utf-8")
        headers = dict(response.headers)
        headers["content-length"] = str(len(envelope_bytes))

        return Response(
            content=envelope_bytes,
            status_code=response.status_code,
            headers=headers,
            media_type="application/json",
        )

    def _should_skip(self, request: Request, response: Response) -> bool:
        path = request.url.path
        for prefix in self.PASSTHROUGH_PREFIXES:
            if path.startswith(prefix):
                return True

        content_type = response.headers.get("content-type", "")
        if "application/json" not in content_type:
            return True

        return False
