"""
Key scope enforcement middleware for SPAPS.

Publishable keys (spaps_pub_) have limited endpoint access.
Secret keys (spaps_sec_, spaps_, legacy) can access everything.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

# Endpoints accessible with publishable keys
PUBLISHABLE_ENDPOINTS: set[str] = {
    # Auth
    "/api/auth/login",
    "/api/auth/register",
    "/api/auth/refresh",
    "/api/auth/logout",
    "/api/auth/nonce",
    "/api/auth/wallet-sign-in",
    "/api/auth/magic-link",
    "/api/auth/verify-magic-link",
    "/api/auth/password-reset",
    "/api/auth/reset-password-confirm",
    "/api/auth/set-password",
    "/api/auth/user",
    # Solana
    "/api/auth/solana/",
    # Ethereum
    "/api/auth/ethereum/",
    # Sessions
    "/api/sessions",
    # Stripe (consumer-facing)
    "/api/stripe/checkout-sessions",
    "/api/stripe/products",
    "/api/stripe/subscriptions",
    "/api/stripe/subscription",
    "/api/stripe/history",
    "/api/stripe/payment",
    "/api/stripe/portal-session",
    # Usage
    "/api/usage/",
    # Entitlements (read-only)
    "/api/entitlements",
    # End-user issue reporting
    "/api/v1/issue-reports",
    # DayRate
    "/api/dayrate/availability",
    "/api/dayrate/book",
    "/api/dayrate/book-multi",
    # Health
    "/health",
    # Docs
    "/api/docs/",
    "/docs",
    "/api-docs",
    # Device flow
    "/api/cli/device/",
}


def is_endpoint_allowed_for_publishable(path: str) -> bool:
    """
    Check if a publishable key can access this endpoint.
    Secret and legacy keys have unrestricted access.
    """
    # Exact match
    if path in PUBLISHABLE_ENDPOINTS:
        return True

    # Prefix match (handles parameterized paths)
    for endpoint in PUBLISHABLE_ENDPOINTS:
        if endpoint.endswith("/") and path.startswith(endpoint):
            return True
        if path.startswith(endpoint + "/"):
            return True
        if path == endpoint:
            return True

    return False
