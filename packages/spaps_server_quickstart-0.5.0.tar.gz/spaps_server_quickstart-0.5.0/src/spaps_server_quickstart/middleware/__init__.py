"""SPAPS-specific middleware.

Re-exports RequestLoggingMiddleware from the base middleware module
(../middleware.py) so that ``from .middleware import RequestLoggingMiddleware``
continues to work now that this package directory shadows the module file.
"""

from .envelope import ResponseEnvelopeMiddleware
from .error_handler import install_error_handlers
from .security_headers import SecurityHeadersMiddleware

# Re-export from the sibling module file (middleware.py) that this package shadows.
# Import the actual class from the module file via importlib to avoid circular issues.
import pathlib as _pathlib

_base_middleware_path = _pathlib.Path(__file__).parent.parent / "middleware.py"
if _base_middleware_path.exists():
    import importlib.util as _util

    _spec = _util.spec_from_file_location(
        "spaps_server_quickstart._middleware_base", str(_base_middleware_path)
    )
    if _spec and _spec.loader:
        _mod = _util.module_from_spec(_spec)
        _spec.loader.exec_module(_mod)
        RequestLoggingMiddleware = _mod.RequestLoggingMiddleware
        request_id_ctx_var = _mod.request_id_ctx_var
        REQUEST_ID_HEADER = _mod.REQUEST_ID_HEADER

__all__ = [
    "ResponseEnvelopeMiddleware",
    "SecurityHeadersMiddleware",
    "install_error_handlers",
    "RequestLoggingMiddleware",
    "request_id_ctx_var",
    "REQUEST_ID_HEADER",
]
