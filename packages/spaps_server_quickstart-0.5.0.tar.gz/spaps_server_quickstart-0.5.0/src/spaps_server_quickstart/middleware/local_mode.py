"""
Local development mode middleware for SPAPS.

When SPAPS_LOCAL_MODE=true (or ENV=development), bypasses authentication
with test users and a test application.

Test users selectable via ?_user= query param or X-Test-User header:
  - "user": user@localhost, tier=free
  - "admin": buildooor@gmail.com, tier=enterprise, is_admin=true
  - "premium": premium@localhost, tier=premium
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from uuid import UUID

logger = logging.getLogger(__name__)

# Local dev application
LOCAL_APP_ID = UUID("00000000-0000-0000-0000-000000000100")
LOCAL_APP_SLUG = "local-dev"
LOCAL_APP_API_KEY = "spaps_local_development_key"

# Super admin user ID (matches production)
SUPER_ADMIN_ID = "5bdb0db2-5ab1-4e2c-999b-1153cc329477"


@dataclass
class LocalTestUser:
    """A test user persona for local development."""

    id: str
    email: str
    username: str
    tier: str
    roles: list[str] = field(default_factory=lambda: ["user"])
    permissions: list[str] = field(default_factory=lambda: ["view_products"])
    is_admin: bool = False
    is_super_admin: bool = False
    wallet_addresses: list[str] = field(default_factory=list)


# Default test personas
LOCAL_USERS: dict[str, LocalTestUser] = {
    "user": LocalTestUser(
        id="00000000-0000-0000-0000-000000000001",
        email="user@localhost",
        username="dev-user",
        tier="free",
    ),
    "admin": LocalTestUser(
        id=SUPER_ADMIN_ID,
        email="buildooor@gmail.com",
        username="admin",
        tier="enterprise",
        roles=["admin", "super_admin"],
        permissions=[
            "view_products", "create_products", "edit_products", "manage_products",
            "delete_products", "view_users", "manage_users", "view_orders",
            "create_orders", "edit_orders", "manage_orders", "access_admin",
            "view_analytics", "manage_analytics", "view_subscriptions",
            "manage_subscriptions", "manage_system_settings", "audit_logs",
            "security_settings", "compliance_reports",
        ],
        is_admin=True,
        is_super_admin=True,
    ),
    "premium": LocalTestUser(
        id="00000000-0000-0000-0000-000000000002",
        email="premium@localhost",
        username="premium-user",
        tier="premium",
    ),
}

DEFAULT_LOCAL_USER = "user"


def get_local_user(request_user: str | None) -> LocalTestUser:
    """Get a local test user by name. Falls back to default."""
    if request_user and request_user in LOCAL_USERS:
        return LOCAL_USERS[request_user]
    return LOCAL_USERS[DEFAULT_LOCAL_USER]


@dataclass
class LocalApplication:
    """Fake application for local development."""

    id: UUID = LOCAL_APP_ID
    name: str = "Local Development"
    slug: str = LOCAL_APP_SLUG
    api_key: str = LOCAL_APP_API_KEY
    allowed_origins: list[str] = field(default_factory=lambda: ["*"])
    webhook_url: str | None = None
    settings: dict | None = field(
        default_factory=lambda: {"issue_reporting_required_capability": "view_products"}
    )
    whitelist_enabled: bool = False
    whitelist_count: int = 0
    publishable_key_hash: str | None = None
    secret_key_hash: str | None = None


LOCAL_APPLICATION = LocalApplication()
