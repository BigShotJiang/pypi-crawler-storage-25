"""
AdminTokenCache: auto-refreshing admin token management.

Supports two strategies for obtaining admin tokens:
- "password": authenticate with admin email + password via the auth client
- "api_key": use the API key directly as the token (no login needed)
- "auto": detect which strategy to use based on available settings
"""

from __future__ import annotations

import asyncio
import time
from typing import Any

import structlog

logger = structlog.get_logger("sdk.admin_token_cache")

# Backoff constants
_INITIAL_BACKOFF_SECONDS = 10.0
_MAX_BACKOFF_SECONDS = 300.0  # 5 minutes
_BACKOFF_MULTIPLIER = 2.0


class AdminTokenCacheError(Exception):
    """Raised when the AdminTokenCache cannot obtain a token."""


class AdminTokenCache:
    """
    Manages a cached admin token with automatic refresh.

    The cache ensures only one refresh happens at a time (via asyncio.Lock)
    and applies exponential backoff on authentication failures.
    """

    def __init__(
        self,
        settings: Any,
        strategy: str = "auto",
        *,
        expiry_buffer_seconds: float = 30.0,
        auth_client_factory: Any | None = None,
    ) -> None:
        """
        Initialize the AdminTokenCache.

        Args:
            settings: A BaseServiceSettings (or compatible) instance providing
                spaps_api_url, spaps_api_key, and optionally spaps_admin_email
                + spaps_admin_password.
            strategy: "auto" | "password" | "api_key"
                - auto: if admin_email + admin_password set -> password;
                        elif api_key -> api_key; else ConfigError
                - password: requires admin_email + admin_password
                - api_key: uses spaps_api_key directly as the token
            expiry_buffer_seconds: Refresh the token this many seconds before
                it actually expires. Default 30s.
            auth_client_factory: Optional factory for creating the auth client.
                If None, uses AsyncAuthClient from spaps_client.
        """
        self._settings = settings
        self._expiry_buffer = expiry_buffer_seconds
        self._auth_client_factory = auth_client_factory

        # Resolve strategy
        self._strategy = self._resolve_strategy(strategy)

        # Cache state
        self._token: str | None = None
        self._token_expires_at: float = 0.0  # monotonic timestamp
        self._lock = asyncio.Lock()

        # Backoff state
        self._consecutive_failures = 0
        self._backoff_until: float = 0.0

    def _resolve_strategy(self, strategy: str) -> str:
        """Determine the authentication strategy to use."""
        if strategy == "password":
            admin_email = getattr(self._settings, "spaps_admin_email", None)
            admin_password = getattr(self._settings, "spaps_admin_password", None)
            if not admin_email or not admin_password:
                raise AdminTokenCacheError(
                    "password strategy requires spaps_admin_email and spaps_admin_password"
                )
            return "password"

        if strategy == "api_key":
            api_key = getattr(self._settings, "spaps_api_key", None)
            if not api_key:
                raise AdminTokenCacheError("api_key strategy requires spaps_api_key")
            return "api_key"

        if strategy == "auto":
            admin_email = getattr(self._settings, "spaps_admin_email", None)
            admin_password = getattr(self._settings, "spaps_admin_password", None)
            if admin_email and admin_password:
                return "password"
            api_key = getattr(self._settings, "spaps_api_key", None)
            if api_key:
                return "api_key"
            raise AdminTokenCacheError(
                "auto strategy requires either (spaps_admin_email + spaps_admin_password) "
                "or spaps_api_key"
            )

        raise AdminTokenCacheError(f"Unknown strategy: {strategy!r}")

    async def get_token(self) -> str:
        """
        Return a valid admin token, refreshing if needed.

        Only one refresh runs at a time; concurrent callers wait on the lock.
        """
        # Fast path: check if current token is still valid
        now = time.monotonic()
        if self._token and now < (self._token_expires_at - self._expiry_buffer):
            return self._token

        async with self._lock:
            # Re-check under lock (another coroutine may have refreshed)
            now = time.monotonic()
            if self._token and now < (self._token_expires_at - self._expiry_buffer):
                return self._token

            return await self._refresh()

    async def _refresh(self) -> str:
        """Perform the actual token refresh."""
        now = time.monotonic()

        # Check backoff
        if now < self._backoff_until:
            raise AdminTokenCacheError(
                f"Token refresh in backoff period. Retry after "
                f"{self._backoff_until - now:.1f}s"
            )

        if self._strategy == "api_key":
            api_key = getattr(self._settings, "spaps_api_key", "")
            self._token = api_key
            # API keys don't expire, set a long TTL (24h)
            self._token_expires_at = now + 86400.0
            self._consecutive_failures = 0
            return api_key

        # Password strategy
        try:
            token_pair = await self._authenticate_with_password()
            token: str = token_pair.access_token
            self._token = token
            # Use expires_in from token pair if available, otherwise default 1h
            expires_in = getattr(token_pair, "expires_in", None) or 3600
            self._token_expires_at = now + float(expires_in)
            self._consecutive_failures = 0
            logger.info("admin_token_cache.refreshed", strategy=self._strategy)
            return token
        except Exception as exc:
            self._consecutive_failures += 1
            backoff = min(
                _INITIAL_BACKOFF_SECONDS * (_BACKOFF_MULTIPLIER ** (self._consecutive_failures - 1)),
                _MAX_BACKOFF_SECONDS,
            )
            self._backoff_until = time.monotonic() + backoff
            logger.warning(
                "admin_token_cache.refresh_failed",
                strategy=self._strategy,
                consecutive_failures=self._consecutive_failures,
                backoff_seconds=backoff,
                error=str(exc),
            )
            raise AdminTokenCacheError(f"Failed to refresh admin token: {exc}") from exc

    async def _authenticate_with_password(self) -> Any:
        """Authenticate using email + password and return a TokenPair."""
        from spaps_client import AsyncAuthClient

        factory = self._auth_client_factory
        if factory:
            auth_client = factory()
        else:
            auth_client = AsyncAuthClient(
                base_url=self._settings.spaps_api_url,
                api_key=self._settings.spaps_api_key or "",
            )

        try:
            return await auth_client.sign_in_with_password(
                email=self._settings.spaps_admin_email,
                password=self._settings.spaps_admin_password,
            )
        finally:
            await auth_client.aclose()

    def clear(self) -> None:
        """Clear the cached token, forcing a refresh on next get_token() call."""
        self._token = None
        self._token_expires_at = 0.0
        self._consecutive_failures = 0
        self._backoff_until = 0.0


__all__ = ["AdminTokenCache", "AdminTokenCacheError"]
