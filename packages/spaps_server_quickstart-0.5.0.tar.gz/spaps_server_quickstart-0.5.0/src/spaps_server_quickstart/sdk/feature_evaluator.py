"""
FeatureEvaluator: layered feature flag evaluation.

Evaluates feature availability through three ordered layers:
1. System kill switch: if a system entitlement exists -> feature DISABLED
2. Resource block: if a resource-scoped block entitlement exists -> feature DISABLED
3. Role minimum: check user role against RoleHierarchy

Layers 1 and 2 use inverted semantics: entitlement PRESENCE means blocked.
Admin bypass: only SPAPS super admin bypasses (not app-level admins).
Unknown/unconfigured features: enabled by default.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import structlog

if TYPE_CHECKING:
    from .role_hierarchy import RoleHierarchy
    from .server_clients import ServerEntitlementsClient

logger = structlog.get_logger("sdk.feature_evaluator")


@dataclass
class FeatureDefinition:
    """
    Defines a feature's evaluation layers.

    Attributes:
        kill_switch_key: Entitlement key for system-wide kill switch.
            If an entitlement with this key exists, the feature is DISABLED.
        resource_block_key: Entitlement key for resource-scoped block.
            If an entitlement with this key exists for the resource, the feature is DISABLED.
        minimum_role: Minimum role required to access the feature.
            Checked against the RoleHierarchy.
    """

    kill_switch_key: str | None = None
    resource_block_key: str | None = None
    minimum_role: str | None = None


@dataclass
class FeatureContext:
    """
    Context for evaluating a feature.

    Attributes:
        user_id: The user requesting the feature.
        user_roles: The user's roles (set of role name strings).
        resource_type: Optional resource type for resource-scoped checks.
        resource_id: Optional resource ID for resource-scoped checks.
        is_super_admin: Whether the user is a SPAPS super admin.
    """

    user_id: str
    user_roles: set[str] = field(default_factory=set)
    resource_type: str | None = None
    resource_id: str | None = None
    is_super_admin: bool = False


class FeatureEvaluator:
    """
    Evaluates whether features are enabled for a given context.

    Features are registered with FeatureDefinition objects that define
    the evaluation layers. Evaluation stops at the first failing layer.
    """

    def __init__(
        self,
        entitlements_client: ServerEntitlementsClient,
        role_hierarchy: RoleHierarchy,
    ) -> None:
        self._entitlements = entitlements_client
        self._hierarchy = role_hierarchy
        self._features: dict[str, FeatureDefinition] = {}

    def register_feature(self, name: str, definition: FeatureDefinition) -> None:
        """Register a feature definition for evaluation."""
        self._features[name] = definition

    async def is_enabled(self, feature_name: str, context: FeatureContext) -> bool:
        """
        Evaluate whether a feature is enabled for the given context.

        Returns True if the feature is enabled, False if any layer blocks it.

        Evaluation order:
        1. Admin bypass: SPAPS super admin always gets access
        2. System kill switch: check for system-wide block entitlement
        3. Resource block: check for resource-scoped block entitlement
        4. Role minimum: check user role meets minimum requirement

        Unknown/unconfigured features are enabled by default.
        """
        definition = self._features.get(feature_name)
        if definition is None:
            # Unknown feature: enabled by default
            logger.debug(
                "feature_evaluator.unknown_feature",
                feature=feature_name,
                result="enabled_by_default",
            )
            return True

        # Admin bypass: only SPAPS super admin
        if context.is_super_admin:
            logger.debug(
                "feature_evaluator.admin_bypass",
                feature=feature_name,
                user_id=context.user_id,
            )
            return True

        # Layer 1: System kill switch
        if definition.kill_switch_key:
            try:
                kill_switch_results = await self._entitlements.list(
                    resource_type="system",
                    entitlement_key=definition.kill_switch_key,
                )
                if len(kill_switch_results) > 0:
                    logger.info(
                        "feature_evaluator.kill_switch_active",
                        feature=feature_name,
                        key=definition.kill_switch_key,
                    )
                    return False
            except Exception:
                logger.warning(
                    "feature_evaluator.kill_switch_check_failed",
                    feature=feature_name,
                    key=definition.kill_switch_key,
                )
                # On error, allow through (fail open for kill switch check)

        # Layer 2: Resource block
        if definition.resource_block_key and context.resource_id:
            try:
                block_results = await self._entitlements.list(
                    resource_type=context.resource_type,
                    resource_id=context.resource_id,
                    entitlement_key=definition.resource_block_key,
                )
                if len(block_results) > 0:
                    logger.info(
                        "feature_evaluator.resource_blocked",
                        feature=feature_name,
                        resource_type=context.resource_type,
                        resource_id=context.resource_id,
                        key=definition.resource_block_key,
                    )
                    return False
            except Exception:
                logger.warning(
                    "feature_evaluator.resource_block_check_failed",
                    feature=feature_name,
                    key=definition.resource_block_key,
                )
                # On error, allow through (fail open for block check)

        # Layer 3: Role minimum
        if definition.minimum_role:
            has_role = False
            for role in context.user_roles:
                if self._hierarchy.has_minimum_role(role, definition.minimum_role):
                    has_role = True
                    break
            if not has_role:
                logger.debug(
                    "feature_evaluator.role_insufficient",
                    feature=feature_name,
                    user_roles=sorted(context.user_roles),
                    minimum_role=definition.minimum_role,
                )
                return False

        return True


__all__ = ["FeatureEvaluator", "FeatureDefinition", "FeatureContext"]
