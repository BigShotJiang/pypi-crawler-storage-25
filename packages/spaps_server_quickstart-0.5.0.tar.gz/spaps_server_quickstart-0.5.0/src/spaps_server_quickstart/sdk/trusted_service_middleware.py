"""Trusted-service middleware with signed assertion verification.

This middleware authenticates service-to-service proxy requests using:
- `X-API-Key` for trusted caller identification
- HMAC-signed request assertions (subject/timestamp/nonce/signature)
- In-memory nonce replay protection

When validation succeeds, it sets `request.state.authenticated_user` so
downstream auth middleware can treat the request as authenticated.
"""

from __future__ import annotations

import hashlib
import hmac
import time
from collections.abc import Iterable
from threading import Lock

import structlog
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from starlette.types import ASGIApp

from ..auth import AuthenticatedUser

logger = structlog.get_logger("sdk.trusted_service_middleware")


class TrustedServiceMiddleware(BaseHTTPMiddleware):
    """Authenticate trusted proxy requests using signed assertions."""

    def __init__(
        self,
        app: ASGIApp,
        *,
        trusted_service_key: str,
        exempt_paths: Iterable[str] | None = None,
        assertion_ttl_seconds: int = 60,
        max_nonce_cache_size: int = 10_000,
    ) -> None:
        super().__init__(app)
        if assertion_ttl_seconds <= 0:
            raise ValueError("assertion_ttl_seconds must be > 0")
        if max_nonce_cache_size <= 0:
            raise ValueError("max_nonce_cache_size must be > 0")

        self._trusted_key = trusted_service_key
        self._exempt_paths = set(exempt_paths or set())
        self._assertion_ttl_seconds = assertion_ttl_seconds
        self._max_nonce_cache_size = max_nonce_cache_size
        self._nonce_cache: dict[str, float] = {}
        self._nonce_lock = Lock()

    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        if self._is_exempt(request):
            return await call_next(request)

        api_key = request.headers.get("X-API-Key")
        if not api_key:
            return await call_next(request)

        if not self._trusted_key:
            return await call_next(request)

        if not hmac.compare_digest(api_key, self._trusted_key):
            return await call_next(request)

        subject = request.headers.get("X-Trusted-Subject")
        timestamp_header = request.headers.get("X-Trusted-Timestamp")
        nonce = request.headers.get("X-Trusted-Nonce")
        signature = request.headers.get("X-Trusted-Signature")

        if not subject or not timestamp_header or not nonce or not signature:
            logger.warning(
                "trusted_service.missing_assertion_headers",
                path=request.url.path,
            )
            return JSONResponse(
                {"detail": "Trusted assertion headers are required"},
                status_code=401,
            )

        timestamp = _parse_timestamp(timestamp_header)
        if timestamp is None:
            logger.warning(
                "trusted_service.invalid_timestamp",
                path=request.url.path,
            )
            return JSONResponse({"detail": "Invalid trusted assertion timestamp"}, status_code=401)

        now = time.time()
        if abs(now - timestamp) > self._assertion_ttl_seconds:
            logger.warning(
                "trusted_service.stale_timestamp",
                path=request.url.path,
                ttl_seconds=self._assertion_ttl_seconds,
            )
            return JSONResponse({"detail": "Trusted assertion expired"}, status_code=401)

        if not self._register_nonce(subject=subject, nonce=nonce, now=now):
            logger.warning(
                "trusted_service.replay_detected",
                path=request.url.path,
                subject=subject,
            )
            return JSONResponse({"detail": "Replay detected"}, status_code=401)

        body = await request.body()
        expected_signature = _build_signature(
            key=self._trusted_key,
            method=request.method,
            path=request.url.path,
            timestamp=timestamp_header,
            nonce=nonce,
            subject=subject,
            body=body,
        )

        if not hmac.compare_digest(signature, expected_signature):
            logger.warning(
                "trusted_service.invalid_signature",
                path=request.url.path,
                subject=subject,
            )
            return JSONResponse(
                {"detail": "Invalid trusted assertion signature"},
                status_code=401,
            )

        roles_header = request.headers.get("X-Trusted-Roles", "")
        roles: set[str] = {
            role.strip().lower() for role in roles_header.split(",") if role.strip()
        }

        request.state.authenticated_user = AuthenticatedUser(
            user_id=subject,
            session_id=f"trusted-service:{nonce}",
            application_id="trusted",
            roles=roles,
        )

        logger.debug(
            "trusted_service.authenticated",
            user_id=subject,
            roles=sorted(roles),
            path=request.url.path,
        )

        return await call_next(request)

    def _register_nonce(self, *, subject: str, nonce: str, now: float) -> bool:
        nonce_key = f"{subject}:{nonce}"
        expiry = now + self._assertion_ttl_seconds

        with self._nonce_lock:
            self._prune_expired_nonces(now)
            if nonce_key in self._nonce_cache:
                return False

            self._nonce_cache[nonce_key] = expiry
            if len(self._nonce_cache) > self._max_nonce_cache_size:
                oldest_key = min(self._nonce_cache, key=lambda key: self._nonce_cache[key])
                del self._nonce_cache[oldest_key]
            return True

    def _prune_expired_nonces(self, now: float) -> None:
        expired_keys = [
            key for key, expiry in self._nonce_cache.items() if expiry <= now
        ]
        for key in expired_keys:
            del self._nonce_cache[key]

    def _is_exempt(self, request: Request) -> bool:
        return request.url.path in self._exempt_paths


def _parse_timestamp(value: str) -> float | None:
    value = value.strip()
    if not value:
        return None
    try:
        return float(int(value))
    except ValueError:
        return None


def _build_signature(
    *,
    key: str,
    method: str,
    path: str,
    timestamp: str,
    nonce: str,
    subject: str,
    body: bytes,
) -> str:
    body_hash = hashlib.sha256(body).hexdigest()
    canonical = "\n".join(
        [
            method.upper(),
            path,
            timestamp,
            nonce,
            subject,
            body_hash,
        ]
    )
    return hmac.new(
        key.encode("utf-8"),
        canonical.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()


def _build_request_nonce(user_id: str, nonce: str | None) -> str:
    if nonce is not None:
        return nonce
    return hashlib.sha256(f"{user_id}:{time.time_ns()}".encode("utf-8")).hexdigest()


def _build_request_timestamp(timestamp: int | None) -> str:
    if timestamp is not None:
        return str(timestamp)
    return str(int(time.time()))


def _normalize_roles_header(roles: Iterable[str] | None) -> str | None:
    if not roles:
        return None
    cleaned_roles = [str(role).strip().lower() for role in roles if str(role).strip()]
    if not cleaned_roles:
        return None
    return ", ".join(cleaned_roles)


def build_trusted_service_headers(
    *,
    key: str,
    user_id: str,
    method: str,
    path: str,
    body: bytes = b"",
    roles: Iterable[str] | None = None,
    nonce: str | None = None,
    timestamp: int | None = None,
) -> dict[str, str]:
    """Build signed headers for trusted-service calls.

    This helper can be used by BFF callers to produce a valid assertion envelope.
    """
    request_nonce = _build_request_nonce(user_id, nonce)
    request_timestamp = _build_request_timestamp(timestamp)
    signature = _build_signature(
        key=key,
        method=method,
        path=path,
        timestamp=request_timestamp,
        nonce=request_nonce,
        subject=user_id,
        body=body,
    )

    headers: dict[str, str] = {
        "X-API-Key": key,
        "X-Trusted-Subject": user_id,
        "X-Trusted-Timestamp": request_timestamp,
        "X-Trusted-Nonce": request_nonce,
        "X-Trusted-Signature": signature,
    }
    roles_header = _normalize_roles_header(roles)
    if roles_header is not None:
        headers["X-Trusted-Roles"] = roles_header
    return headers


__all__ = [
    "TrustedServiceMiddleware",
    "build_trusted_service_headers",
]
