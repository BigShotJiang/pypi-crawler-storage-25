"""
Simple in-memory TTL cache for server-side client read caching.

Uses a dict with monotonic timestamps. No external dependencies.
"""

from __future__ import annotations

import time
from typing import Any


class TTLCache:
    """
    Simple TTL cache backed by a dict.

    Keys are strings; values can be anything.
    Expired entries are lazily cleaned up on access.
    """

    def __init__(self, ttl_seconds: float = 300.0, max_size: int = 1000) -> None:
        self._ttl = ttl_seconds
        self._max_size = max_size
        self._store: dict[str, tuple[Any, float]] = {}

    def get(self, key: str) -> Any | None:
        """Return cached value if present and not expired, else None."""
        entry = self._store.get(key)
        if entry is None:
            return None
        value, expires_at = entry
        if time.monotonic() > expires_at:
            del self._store[key]
            return None
        return value

    def set(self, key: str, value: Any) -> None:
        """Store a value with TTL."""
        now = time.monotonic()
        self._store[key] = (value, now + self._ttl)
        if len(self._store) > self._max_size:
            self._evict_expired(now)
            # If still over, remove oldest entries
            while len(self._store) > self._max_size:
                oldest_key = next(iter(self._store))
                del self._store[oldest_key]

    def invalidate(self, key: str) -> None:
        """Remove a specific key from the cache."""
        self._store.pop(key, None)

    def invalidate_prefix(self, prefix: str) -> None:
        """Remove all keys starting with the given prefix."""
        to_remove = [k for k in self._store if k.startswith(prefix)]
        for k in to_remove:
            del self._store[k]

    def clear(self) -> None:
        """Remove all cached entries."""
        self._store.clear()

    def _evict_expired(self, now: float | None = None) -> None:
        """Remove all expired entries."""
        now = now or time.monotonic()
        expired = [k for k, (_, exp) in self._store.items() if now > exp]
        for k in expired:
            del self._store[k]

    def __len__(self) -> int:
        return len(self._store)


__all__ = ["TTLCache"]
