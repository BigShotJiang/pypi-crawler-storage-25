"""
RoleHierarchy: numeric role level comparison for hierarchical RBAC.

Extends alongside the existing has_required_roles() and require_roles()
from spaps_server_quickstart.rbac — does NOT replace them.
"""

from __future__ import annotations

from typing import Awaitable, Callable

from fastapi import HTTPException, status
from starlette.requests import Request

from ..auth import AuthenticatedUser


class RoleHierarchy:
    """
    Defines a numeric hierarchy of roles for comparison.

    Example:
        hierarchy = RoleHierarchy({
            "admin": 4,
            "accountant": 3,
            "client": 2,
            "viewer": 1,
        })
        hierarchy.has_minimum_role("admin", "accountant")  # True (4 >= 3)
        hierarchy.has_minimum_role("viewer", "client")       # False (1 < 2)
    """

    def __init__(self, levels: dict[str, int]) -> None:
        """
        Initialize with a mapping of role names to numeric levels.

        Higher numbers indicate higher privilege.
        """
        # Normalize role names to lowercase
        self._levels: dict[str, int] = {
            role.lower(): level for role, level in levels.items()
        }

    def has_minimum_role(self, user_role: str, required_role: str) -> bool:
        """
        Check if user_role meets or exceeds required_role in the hierarchy.

        Returns False if either role is not in the hierarchy.
        """
        user_level = self.get_level(user_role)
        required_level = self.get_level(required_role)
        if user_level is None or required_level is None:
            return False
        return user_level >= required_level

    def get_level(self, role: str) -> int | None:
        """
        Return the numeric level for a role, or None if not in the hierarchy.
        """
        return self._levels.get(role.lower())


def require_minimum_role(
    hierarchy: RoleHierarchy,
    required: str,
    *,
    forbidden_detail: str | None = None,
) -> Callable[[Request], Awaitable[AuthenticatedUser]]:
    """
    FastAPI dependency that checks the user's highest role against the hierarchy.

    The dependency expects SpapsAuthMiddleware (or TrustedServiceMiddleware)
    to store an AuthenticatedUser on request.state.authenticated_user.

    The user passes if ANY of their roles meets or exceeds the required role
    in the hierarchy.

    Args:
        hierarchy: The RoleHierarchy instance defining role levels.
        required: The minimum role required to access the endpoint.
        forbidden_detail: Custom 403 message. Defaults to
            "Minimum role '{required}' required".
    """
    detail = forbidden_detail or f"Minimum role '{required}' required"

    async def _dependency(request: Request) -> AuthenticatedUser:
        user = getattr(request.state, "authenticated_user", None)
        if user is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Authentication required",
            )

        # Check if any of the user's roles meet the minimum
        user_roles: set[str] = getattr(user, "roles", set())
        for role in user_roles:
            if hierarchy.has_minimum_role(role, required):
                return user

        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=detail,
        )

    return _dependency


__all__ = ["RoleHierarchy", "require_minimum_role"]
