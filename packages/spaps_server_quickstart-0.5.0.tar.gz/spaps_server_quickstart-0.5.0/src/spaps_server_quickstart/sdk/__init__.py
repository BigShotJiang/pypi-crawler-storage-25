"""
SDK consolidation utilities for server-side SPAPS integration.

Provides:
- AdminTokenCache: auto-refreshing admin token management
- Server-side clients: entitlements, users, email, payments
- RoleHierarchy: numeric role level comparison
- TrustedServiceMiddleware: proxy service authentication
- FeatureEvaluator: layered feature flag evaluation
"""

from .admin_token_cache import AdminTokenCache, AdminTokenCacheError
from .server_clients import (
    ServerDayrateClient,
    ServerEntitlementsClient,
    ServerUsersClient,
    ServerEmailClient,
    ServerPaymentsClient,
)
from .role_hierarchy import RoleHierarchy, require_minimum_role
from .trusted_service_middleware import TrustedServiceMiddleware
from .feature_evaluator import FeatureEvaluator, FeatureDefinition, FeatureContext

__all__ = [
    "AdminTokenCache",
    "AdminTokenCacheError",
    "ServerEntitlementsClient",
    "ServerUsersClient",
    "ServerEmailClient",
    "ServerPaymentsClient",
    "ServerDayrateClient",
    "RoleHierarchy",
    "require_minimum_role",
    "TrustedServiceMiddleware",
    "FeatureEvaluator",
    "FeatureDefinition",
    "FeatureContext",
]
