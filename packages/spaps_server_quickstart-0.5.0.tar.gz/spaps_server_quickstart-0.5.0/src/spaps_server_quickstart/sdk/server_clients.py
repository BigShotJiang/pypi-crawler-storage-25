"""
Server-side wrapper clients that add admin auth injection and TTL caching.

Each client wraps a corresponding spaps-client Async*Client, automatically
injecting the admin token from AdminTokenCache and caching read results.
Write operations bypass and invalidate the cache.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

import structlog

from .admin_token_cache import AdminTokenCache
from ._ttl_cache import TTLCache

logger = structlog.get_logger("sdk.server_clients")


@dataclass
class _ManualGrantParams:
    """Local mirror of ManualGrantParams to avoid import version issues."""

    entitlement_key: str
    beneficiary_user_id: str | None = None
    beneficiary_email: str | None = None
    starts_at: str | None = None
    ends_at: str | None = None
    reason: str | None = None
    metadata: dict[str, Any] | None = None
    resource_type: str | None = None
    resource_id: str | None = None


class ServerEntitlementsClient:
    """
    Server-side entitlements client with admin auth and TTL caching.

    Wraps AsyncEntitlementsClient from spaps-client.
    """

    def __init__(
        self,
        token_cache: AdminTokenCache,
        *,
        base_url: str,
        api_key: str,
        cache_ttl_seconds: float = 300.0,
    ) -> None:
        self._token_cache = token_cache
        self._base_url = base_url
        self._api_key = api_key
        self._cache = TTLCache(ttl_seconds=cache_ttl_seconds)

    async def _get_client(self) -> Any:
        """Create an AsyncEntitlementsClient with the current admin token."""
        from spaps_client import AsyncEntitlementsClient  # type: ignore[attr-defined]

        token = await self._token_cache.get_token()
        return AsyncEntitlementsClient(
            base_url=self._base_url,
            api_key=self._api_key,
            access_token=token,
        )

    async def list(
        self,
        *,
        user_id: str | None = None,
        email: str | None = None,
        entitlement_key: str | None = None,
        resource_type: str | None = None,
        resource_id: str | None = None,
        include_expired: bool = False,
    ) -> list[Any]:
        """List entitlements with caching."""
        cache_key = f"entitlements:list:{user_id}:{email}:{entitlement_key}:{resource_type}:{resource_id}:{include_expired}"
        cached = self._cache.get(cache_key)
        if cached is not None:
            return cached

        client = await self._get_client()
        try:
            result = await client.get_user_entitlements(
                user_id=user_id,
                email=email,
                entitlement_key=entitlement_key,
                include_expired=include_expired,
                resource_type=resource_type,
                resource_id=resource_id,
            )
            self._cache.set(cache_key, result)
            return result
        finally:
            await client.aclose()

    async def check(self, user_id: str, key: str) -> bool:
        """Check if a user has a specific entitlement (cached)."""
        cache_key = f"entitlements:check:{user_id}:{key}"
        cached = self._cache.get(cache_key)
        if cached is not None:
            return cached

        client = await self._get_client()
        try:
            result = await client.check_access(user_id, key)
            self._cache.set(cache_key, result)
            return result
        finally:
            await client.aclose()

    async def grant(
        self,
        *,
        entitlement_key: str,
        beneficiary_user_id: str | None = None,
        beneficiary_email: str | None = None,
        resource_type: str = "user",
        resource_id: str | None = None,
        starts_at: str | None = None,
        ends_at: str | None = None,
        reason: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Any:
        """Grant an entitlement (bypasses and invalidates cache)."""
        params = _ManualGrantParams(
            entitlement_key=entitlement_key,
            beneficiary_user_id=beneficiary_user_id,
            beneficiary_email=beneficiary_email,
            starts_at=starts_at,
            ends_at=ends_at,
            reason=reason,
            metadata=metadata,
            resource_type=resource_type,
            resource_id=resource_id,
        )

        client = await self._get_client()
        try:
            result = await client.grant_manual(params)
            # Invalidate related cache entries
            self._cache.invalidate_prefix("entitlements:")
            return result
        finally:
            await client.aclose()

    async def revoke(self, entitlement_id: str, *, reason: str | None = None) -> Any:
        """Revoke an entitlement (bypasses and invalidates cache)."""
        client = await self._get_client()
        try:
            result = await client.revoke(entitlement_id, reason=reason)
            self._cache.invalidate_prefix("entitlements:")
            return result
        finally:
            await client.aclose()

    async def claim_pending(self, user_id: str, email: str) -> Any:
        """
        Claim pending entitlements for a user.

        Note: The underlying client's claim_pending requires a JWT access token.
        We use the admin token from the cache.
        """
        client = await self._get_client()
        try:
            token = await self._token_cache.get_token()
            result = await client.claim_pending(access_token=token)
            self._cache.invalidate_prefix("entitlements:")
            return result
        finally:
            await client.aclose()


class ServerUsersClient:
    """
    Server-side users client with admin auth and TTL caching.

    Wraps AsyncUsersClient from spaps-client.
    """

    def __init__(
        self,
        token_cache: AdminTokenCache,
        *,
        base_url: str,
        api_key: str,
        cache_ttl_seconds: float = 300.0,
    ) -> None:
        self._token_cache = token_cache
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._cache = TTLCache(ttl_seconds=cache_ttl_seconds)

    def _get_client(self) -> Any:
        from spaps_client import AsyncUsersClient  # type: ignore[attr-defined]

        return AsyncUsersClient(
            base_url=self._base_url,
            api_key=self._api_key,
        )

    async def get_email(self, user_id: str) -> str | None:
        """Get a single user's email address (cached)."""
        cache_key = f"users:email:{user_id}"
        cached = self._cache.get(cache_key)
        if cached is not None:
            return cached

        client = self._get_client()
        try:
            result = await client.get_emails_batch([user_id])
        finally:
            await client.aclose()
        email = result.emails.get(user_id)
        if email is not None:
            self._cache.set(cache_key, email)
        return email

    async def get_emails_batch(
        self, user_ids: list[str], *, chunk_size: int = 100
    ) -> dict[str, str | None]:
        """
        Get emails for multiple users, auto-chunking at chunk_size.

        Returns a mapping of {user_id: email | None}.
        """
        all_emails: dict[str, str | None] = {}

        for i in range(0, len(user_ids), chunk_size):
            chunk = user_ids[i : i + chunk_size]
            client = self._get_client()
            try:
                result = await client.get_emails_batch(chunk)
            finally:
                await client.aclose()
            all_emails.update(result.emails)

        return all_emails

    async def get_profiles_batch(self, user_ids: list[str]) -> dict[str, Any]:
        """Get user profiles for a batch of user IDs."""
        cache_key = f"users:profiles:{json.dumps(sorted(user_ids))}"
        cached = self._cache.get(cache_key)
        if cached is not None:
            return cached

        client = self._get_client()
        try:
            result = await client.get_users_batch(user_ids)
        finally:
            await client.aclose()
        users = {uid: info.model_dump() for uid, info in result.users.items()}
        self._cache.set(cache_key, users)
        return users


class ServerEmailClient:
    """
    Server-side email client with admin auth.

    Wraps AsyncEmailClient from spaps-client.
    """

    def __init__(
        self,
        token_cache: AdminTokenCache,
        *,
        base_url: str,
        api_key: str,
    ) -> None:
        self._token_cache = token_cache
        self._base_url = base_url
        self._api_key = api_key
        self._cache = TTLCache(ttl_seconds=300.0)

    async def _get_client(self) -> Any:
        """Create an AsyncEmailClient with API key auth.

        Keep constructor usage minimal for compatibility with older/newer
        python-client signatures, then attach bearer token if supported.
        """
        from spaps_client import AsyncEmailClient  # type: ignore[attr-defined]

        token = await self._token_cache.get_token()
        client = AsyncEmailClient(
            base_url=self._base_url,
            api_key=self._api_key,
        )
        # Some client versions expose access_token only as an attribute.
        if hasattr(client, "access_token"):
            setattr(client, "access_token", token)
        return client

    async def send(
        self,
        template_key: str,
        to: str,
        *,
        context: dict[str, Any] | None = None,
        subject_override: str | None = None,
        body_override: str | None = None,
        user_id: str | None = None,
        owner_id: str | None = None,
    ) -> Any:
        """Send an email using a template (write operation, no caching)."""
        client = await self._get_client()
        try:
            return await client.send(
                template_key=template_key,
                to=to,
                context=context or {},
                user_id=user_id,
                owner_id=owner_id,
                subject_override=subject_override,
                body_override=body_override,
            )
        finally:
            await client.aclose()

    async def list_templates(self) -> list[Any]:
        """List all email templates (cached)."""
        cache_key = "email:templates:list"
        cached = self._cache.get(cache_key)
        if cached is not None:
            return cached

        client = await self._get_client()
        try:
            result = await client.list_templates()
            self._cache.set(cache_key, result)
            return result
        finally:
            await client.aclose()

    async def get_template(self, template_key: str) -> Any:
        """Get a single template by key (cached)."""
        cache_key = f"email:template:{template_key}"
        cached = self._cache.get(cache_key)
        if cached is not None:
            return cached

        client = await self._get_client()
        try:
            result = await client.get_template(template_key)
            self._cache.set(cache_key, result)
            return result
        finally:
            await client.aclose()

    async def preview(self, template_key: str, context: dict[str, Any]) -> Any:
        """Preview a rendered template (not cached since context varies)."""
        client = await self._get_client()
        try:
            return await client.preview_template(template_key, context=context)
        finally:
            await client.aclose()

    async def update_template(self, template_key: str, **kwargs: Any) -> Any:
        """Update an email template and invalidate related cache entries."""
        client = await self._get_client()
        try:
            result = await client.update_template(template_key, **kwargs)
            self._cache.invalidate_prefix("email:template:")
            self._cache.invalidate("email:templates:list")
            return result
        finally:
            await client.aclose()

    async def get_override(self, template_key: str) -> Any:
        """Fetch a template override."""
        client = await self._get_client()
        try:
            return await client.get_override(template_key)
        finally:
            await client.aclose()

    async def create_or_update_override(self, template_key: str, **kwargs: Any) -> Any:
        """Create or update a template override."""
        client = await self._get_client()
        try:
            result = await client.create_or_update_override(template_key, **kwargs)
            self._cache.invalidate_prefix("email:template:")
            self._cache.invalidate("email:templates:list")
            return result
        finally:
            await client.aclose()

    async def delete_override(self, template_key: str) -> Any:
        """Delete a template override."""
        client = await self._get_client()
        try:
            result = await client.delete_override(template_key)
            self._cache.invalidate_prefix("email:template:")
            self._cache.invalidate("email:templates:list")
            return result
        finally:
            await client.aclose()

    async def create_template(self, **kwargs: Any) -> Any:
        """Create a template and invalidate template listing cache."""
        client = await self._get_client()
        try:
            result = await client.create_template(**kwargs)
            self._cache.invalidate("email:templates:list")
            return result
        finally:
            await client.aclose()

    async def list_email_logs(
        self,
        *,
        owner_id: str | None = None,
        user_id: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> Any:
        """List email logs with optional owner/user filtering."""
        client = await self._get_client()
        try:
            return await client.list_email_logs(
                owner_id=owner_id,
                user_id=user_id,
                limit=limit,
                offset=offset,
            )
        finally:
            await client.aclose()


class ServerPaymentsClient:
    """
    Server-side payments client with admin auth.

    Wraps AsyncPaymentsClient from spaps-client.
    """

    def __init__(
        self,
        token_cache: AdminTokenCache,
        *,
        base_url: str,
        api_key: str,
    ) -> None:
        self._token_cache = token_cache
        self._base_url = base_url
        self._api_key = api_key

    async def _get_client(self) -> Any:
        """Create an AsyncPaymentsClient with the current admin token."""
        from spaps_client import AsyncPaymentsClient

        token = await self._token_cache.get_token()
        return AsyncPaymentsClient(
            base_url=self._base_url,
            api_key=self._api_key,
            access_token=token,
        )

    async def create_checkout_session(
        self,
        *,
        price_id: str,
        mode: str,
        success_url: str,
        cancel_url: str,
        metadata: dict[str, Any] | None = None,
    ) -> Any:
        """Create a Stripe checkout session."""
        client = await self._get_client()
        try:
            return await client.create_checkout_session(
                price_id=price_id,
                mode=mode,
                success_url=success_url,
                cancel_url=cancel_url,
                metadata=metadata,
            )
        finally:
            await client.aclose()

    async def create_guest_checkout_session(
        self,
        *,
        customer_email: str,
        mode: str,
        line_items: list[dict[str, Any]],
        success_url: str,
        cancel_url: str,
        metadata: dict[str, str] | None = None,
    ) -> Any:
        """Create a guest checkout session."""
        client = await self._get_client()
        try:
            return await client.create_guest_checkout_session(
                customer_email=customer_email,
                mode=mode,
                line_items=line_items,
                success_url=success_url,
                cancel_url=cancel_url,
                metadata=metadata,
            )
        finally:
            await client.aclose()

    async def create_authenticated_checkout_session(self, **kwargs: Any) -> Any:
        """Create an authenticated checkout session using Stripe router surface."""
        client = await self._get_client()
        try:
            return await client.create_authenticated_checkout_session(**kwargs)
        finally:
            await client.aclose()

    async def list_all_products(self) -> Any:
        """List all products (including inactive) using super-admin surface."""
        client = await self._get_client()
        try:
            return await client.list_all_products()
        finally:
            await client.aclose()

    async def create_product(self, **kwargs: Any) -> Any:
        """Create a product."""
        client = await self._get_client()
        try:
            return await client.create_product(**kwargs)
        finally:
            await client.aclose()

    async def update_product(self, **kwargs: Any) -> Any:
        """Update a product."""
        client = await self._get_client()
        try:
            return await client.update_product(**kwargs)
        finally:
            await client.aclose()

    async def archive_product(self, *, product_id: str) -> Any:
        """Archive a product."""
        client = await self._get_client()
        try:
            return await client.archive_product(product_id=product_id)
        finally:
            await client.aclose()

    async def create_price(self, **kwargs: Any) -> Any:
        """Create a price."""
        client = await self._get_client()
        try:
            return await client.create_price(**kwargs)
        finally:
            await client.aclose()

    async def archive_price(self, *, price_id: str) -> Any:
        """Archive (deactivate) a price."""
        client = await self._get_client()
        try:
            return await client.archive_price(price_id=price_id)
        finally:
            await client.aclose()

    async def set_default_price(
        self,
        *,
        product_id: str,
        price_id: str,
    ) -> Any:
        """Set a product's default price."""
        client = await self._get_client()
        try:
            return await client.set_default_price(
                product_id=product_id,
                price_id=price_id,
            )
        finally:
            await client.aclose()

    async def create_price_and_set_default(
        self,
        *,
        product_id: str,
        unit_amount: int,
        currency: str,
        interval: str | None = None,
        interval_count: int | None = None,
        recurring: bool | None = None,
        nickname: str | None = None,
        metadata: dict[str, str] | None = None,
        deactivate_previous: bool | None = None,
        super_admin: bool = True,
    ) -> Any:
        """Create a new price and set it as default."""
        client = await self._get_client()
        try:
            return await client.create_price_and_set_default(
                product_id=product_id,
                unit_amount=unit_amount,
                currency=currency,
                interval=interval,
                interval_count=interval_count,
                recurring=recurring,
                nickname=nickname,
                metadata=metadata,
                deactivate_previous=deactivate_previous,
                super_admin=super_admin,
            )
        finally:
            await client.aclose()


class ServerDayrateClient:
    """Server-side dayrate client with admin auth passthrough."""

    def __init__(
        self,
        token_cache: AdminTokenCache,
        *,
        base_url: str,
        api_key: str,
    ) -> None:
        self._token_cache = token_cache
        self._base_url = base_url
        self._api_key = api_key

    async def _get_client(self) -> Any:
        from spaps_client import AsyncDayrateClient  # type: ignore[attr-defined]

        token = await self._token_cache.get_token()
        return AsyncDayrateClient(
            base_url=self._base_url,
            api_key=self._api_key,
            access_token=token,
        )

    async def get_availability(self) -> Any:
        client = await self._get_client()
        try:
            return await client.get_availability()
        finally:
            await client.aclose()

    async def get_allotment(
        self,
        *,
        policy_key: str,
        user_id: str | None = None,
        email: str | None = None,
    ) -> Any:
        client = await self._get_client()
        try:
            return await client.get_allotment(
                policy_key=policy_key,
                user_id=user_id,
                email=email,
            )
        finally:
            await client.aclose()

    async def create_booking(self, **kwargs: Any) -> Any:
        client = await self._get_client()
        try:
            return await client.create_booking(**kwargs)
        finally:
            await client.aclose()

    async def cancel_booking(
        self,
        *,
        booking_id: str,
        user_id: str | None = None,
        email: str | None = None,
    ) -> Any:
        client = await self._get_client()
        try:
            return await client.cancel_booking(
                booking_id=booking_id,
                user_id=user_id,
                email=email,
            )
        finally:
            await client.aclose()

    async def get_admin_bookings(
        self,
        *,
        status: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
        client_email: str | None = None,
        enrollment_id: str | None = None,
        user_id: str | None = None,
        is_free: bool | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> Any:
        client = await self._get_client()
        try:
            return await client.get_admin_bookings(
                status=status,
                start_date=start_date,
                end_date=end_date,
                client_email=client_email,
                enrollment_id=enrollment_id,
                user_id=user_id,
                is_free=is_free,
                limit=limit,
                offset=offset,
            )
        finally:
            await client.aclose()


__all__ = [
    "ServerEntitlementsClient",
    "ServerUsersClient",
    "ServerEmailClient",
    "ServerPaymentsClient",
    "ServerDayrateClient",
]
