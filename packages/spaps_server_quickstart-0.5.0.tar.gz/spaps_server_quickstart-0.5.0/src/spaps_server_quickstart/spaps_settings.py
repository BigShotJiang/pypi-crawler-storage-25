"""
SPAPS-specific settings.

Extends BaseServiceSettings with all environment variables needed by the
SPAPS auth & payment service. Used by the SPAPS app entry point (main.py),
NOT by consumer services like consumer_server.
"""

from __future__ import annotations

from collections.abc import Iterable
from functools import lru_cache
from typing import Annotated

from pydantic import field_validator
from pydantic_settings import NoDecode

from .settings import BaseServiceSettings


class SpapsSettings(BaseServiceSettings):
    """Configuration for the SPAPS service itself."""

    app_name: str = "SPAPS"
    version: str = "1.0.0"
    service_slug: str = "spaps"

    # --- JWT ---
    jwt_secret: str = ""
    jwt_expires_in: str = "1h"
    refresh_token_secret: str = ""
    jwt_refresh_expires_in: str = "365d"

    # --- Stripe ---
    stripe_secret_key: str = ""
    stripe_webhook_secret: str = ""
    stripe_checkout_branding_name: str = ""

    # --- Email / Mailgun ---
    mailgun_api_key: str = ""
    mailgun_domain: str = ""
    mailgun_from: str = ""
    mailgun_webhook_signing_key: str = ""

    # --- Crypto ---
    crypto_payments_enabled: bool = False
    crypto_webhook_secrets: str = ""

    # --- CFO / QuickBooks ---
    cfo_admin_api_key: str = ""
    cfo_api_url: str = ""  # Internal URL to CFO FastAPI server for /me enrichment
    quickbooks_client_id: str = ""
    quickbooks_client_secret: str = ""
    quickbooks_redirect_uri: str = ""
    cfo_public_key: str = ""
    cfo_frontend_url: str = ""

    # --- Blockchain RPCs ---
    solana_rpc_url: str = ""
    ethereum_rpc_url: str = ""

    # --- Lightning / Bitcoin ---
    lightning_grpc_host: str = ""
    lightning_macaroon: str = ""
    lightning_tls_cert: str = ""
    lightning_webhook_secret: str = ""

    # --- PII Encryption ---
    spaps_pii_master_key: str = ""

    # --- API Security ---
    spaps_api_secret: str = ""

    # --- Auth Links ---
    auth_base_url: str = "https://your-app.com"

    # --- Device Flow ---
    device_flow_verification_uri: str = ""

    # --- App ---
    port: int = 8000
    host: str = "0.0.0.0"

    # --- Self-service ---
    self_service_password: str = ""

    # --- Internal service auth (affiliate commissions endpoint) ---
    internal_service_secret: str = ""

    # --- Webhook delivery ---
    content_webhook_secret: str = ""

    # --- Local development ---
    spaps_local_mode: bool | None = None

    # --- Security (TM-009) ---
    # When False, rejects plaintext API key auth (applications.api_key column).
    # Default True for backwards compatibility during migration.
    # Production startup checks require this to be False.
    legacy_api_key_auth_enabled: bool = True

    # --- Security Audit Remediation 2026q1 Feature Flags ---

    # TM-013: Secure messages JWT requirement
    # When True, secure messages require API key + JWT identity (not just API key)
    secure_messages_require_jwt: bool = True

    # TM-011: Refresh token anomaly enforcement
    # When True, refresh token anomaly detection blocks suspicious requests
    # When False, anomalies are logged but requests proceed (alert-only mode)
    refresh_anomaly_enforcement_enabled: bool = True

    # TM-007: Webhook destination governance policy mode
    # Modes: "off" (no governance), "allowlist" (only allowed_domains permitted)
    # Production startup checks require mode="allowlist".
    webhook_destination_policy_mode: str = "off"

    # TM-007: Webhook allowed domains (for allowlist mode)
    # List of allowed domain names (e.g., ["example.com", "api.partner.com"])
    # Subdomains are automatically included (e.g., "api.example.com" matches "example.com")
    webhook_allowed_domains: Annotated[list[str], NoDecode] = []

    # TM-010: Rate limit backend
    # Backend for rate limiting: "memory" (single-instance) or "redis" (multi-replica)
    rate_limit_backend: str = "memory"

    # Support telemetry ingest backpressure guard.
    # 0 disables domain-level inflight limiting.
    support_telemetry_max_inflight_ingest: int = 0

    # TM-008: Self-service allowed IPs
    # Network boundary enforcement for self-service console
    # Empty list = no restriction (backward compatible default)
    # Production startup checks require non-empty IP/CIDR entries.
    # Non-empty list = only listed IPs can access self-service endpoints
    self_service_allowed_ips: Annotated[list[str], NoDecode] = []

    # --- CORS (wider defaults for SPAPS) ---
    cors_allow_origins: Annotated[tuple[str, ...], NoDecode] = ("*",)
    cors_allow_headers: Annotated[tuple[str, ...], NoDecode] = (
        "Authorization",
        "Content-Type",
        "X-API-Key",
        "X-Request-ID",
        "X-SPAPS-Signature",
        "X-Test-User",
    )
    cors_expose_headers: Annotated[tuple[str, ...], NoDecode] = (
        "X-SPAPS-Mode",
        "X-SPAPS-Environment",
    )

    @field_validator("webhook_allowed_domains", "self_service_allowed_ips", mode="before")
    @classmethod
    def _parse_csv_list_fields(cls, value: Iterable[str] | str | None) -> list[str]:
        if value is None:
            return []
        if isinstance(value, str):
            items = [item.strip() for item in value.split(",")]
        else:
            items = [str(item).strip() for item in value]
        return [item for item in items if item]

    @property
    def is_spaps_local_mode(self) -> bool:
        """Check if SPAPS local development mode is active."""
        if self.env in ("production", "prod"):
            return False
        if self.spaps_local_mode is not None:
            return self.spaps_local_mode  # explicit True or False honored
        return self.env in ("development", "dev", "test")  # default True in dev


@lru_cache(maxsize=1)
def get_spaps_settings() -> SpapsSettings:
    return SpapsSettings()
