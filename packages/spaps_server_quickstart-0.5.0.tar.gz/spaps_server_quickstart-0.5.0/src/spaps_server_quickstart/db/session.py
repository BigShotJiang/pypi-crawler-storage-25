"""
Async SQLAlchemy session helpers shared across services.
"""

from __future__ import annotations

from dataclasses import dataclass
from collections.abc import AsyncIterator, Awaitable, Callable
from typing import Any

from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

from ..settings import BaseServiceSettings


@dataclass(frozen=True, slots=True)
class DatabaseHelperSurface:
    """
    Stable module-level helper callables for downstream services.
    """

    get_engine: Callable[[], AsyncEngine]
    get_session_factory: Callable[[], async_sessionmaker[AsyncSession]]
    dispose_engine: Callable[[], Awaitable[None]]
    get_db_session: Callable[[], AsyncIterator[AsyncSession]]


class DatabaseResources:
    """
    Lazily instantiate the async SQLAlchemy engine/session factory for a service.
    """

    def __init__(
        self,
        settings: BaseServiceSettings,
        *,
        engine_overrides: dict[str, Any] | None = None,
    ) -> None:
        self._settings = settings
        self._engine_overrides = engine_overrides or {}
        self._engine: AsyncEngine | None = None
        self._session_factory: async_sessionmaker[AsyncSession] | None = None

    def get_engine(self) -> AsyncEngine:
        if self._engine is None:
            engine_kwargs = self._build_engine_kwargs()
            engine_kwargs.update(self._engine_overrides)
            self._engine = create_async_engine(self._settings.database_url, **engine_kwargs)
        return self._engine

    def get_session_factory(self) -> async_sessionmaker[AsyncSession]:
        if self._session_factory is None:
            self._session_factory = async_sessionmaker(
                self.get_engine(),
                expire_on_commit=False,
            )
        return self._session_factory

    async def dispose(self) -> None:
        if self._engine is not None:
            await self._engine.dispose()
        self._engine = None
        self._session_factory = None

    async def session_dependency(self) -> AsyncIterator[AsyncSession]:
        async with self.get_session_factory()() as session:
            yield session
            await session.commit()

    def _build_engine_kwargs(self) -> dict[str, Any]:
        # Always use QueuePool (default) with configured pool settings.
        # This prevents connection exhaustion in all environments (dev, test, prod).
        # NullPool creates new connections per request which causes issues with
        # parallel test workers and connection limits.
        return {
            "echo": self._settings.database_echo,
            "pool_size": self._settings.database_pool_size,
            "max_overflow": self._settings.database_max_overflow,
            "pool_timeout": self._settings.database_pool_timeout,
            "pool_pre_ping": self._settings.database_pool_pre_ping,
        }


def create_async_sessionmaker(
    settings: BaseServiceSettings,
    **engine_kwargs: Any,
) -> async_sessionmaker[AsyncSession]:
    """
    Convenience helper mirroring the previous service-level API.
    """

    resources = DatabaseResources(settings, engine_overrides=engine_kwargs)
    return resources.get_session_factory()


def session_dependency_factory(
    session_factory: async_sessionmaker[AsyncSession],
) -> Callable[[], AsyncIterator[AsyncSession]]:
    """
    Build a FastAPI dependency that yields an AsyncSession from the given factory.
    """

    async def _dependency() -> AsyncIterator[AsyncSession]:
        async with session_factory() as session:
            yield session
            await session.commit()

    return _dependency


def initialize_database_helpers(
    settings_loader: Callable[[], BaseServiceSettings],
    *,
    engine_overrides: dict[str, Any] | None = None,
) -> DatabaseHelperSurface:
    """
    Create stable module-level database helper callables for downstream services.
    """

    resources: DatabaseResources | None = None
    resolved_engine_overrides = dict(engine_overrides or {})

    def _get_resources() -> DatabaseResources:
        nonlocal resources
        if resources is None:
            resources = DatabaseResources(
                settings_loader(),
                engine_overrides=resolved_engine_overrides,
            )
        return resources

    def get_engine() -> AsyncEngine:
        return _get_resources().get_engine()

    def get_session_factory() -> async_sessionmaker[AsyncSession]:
        return _get_resources().get_session_factory()

    async def dispose_engine() -> None:
        nonlocal resources
        if resources is not None:
            await resources.dispose()
        resources = None

    async def get_db_session() -> AsyncIterator[AsyncSession]:
        async for session in _get_resources().session_dependency():
            yield session

    return DatabaseHelperSurface(
        get_engine=get_engine,
        get_session_factory=get_session_factory,
        dispose_engine=dispose_engine,
        get_db_session=get_db_session,
    )
