#!/usr/bin/env bash
# Fetch production database dump via SSH.
# Caches locally to avoid repeated slow fetches.
#
# Environment variables:
#   PROD_HOST        - SSH host (e.g., root@104.131.188.214)
#   DB_CONTAINER     - Docker container running Postgres on prod
#   DB_NAME          - Database name to dump
#   SERVICE_NAME     - Service name for cache directory (default: service)
#   {SERVICE}_PROD_DB_FRESH - Set to 1 to force fresh fetch
#
# Usage:
#   ./scripts/dev/fetch-prod-db.sh
#   HTMA_PROD_DB_FRESH=1 ./scripts/dev/fetch-prod-db.sh

set -euo pipefail

SERVICE_NAME="${SERVICE_NAME:-service}"
PROD_HOST="${PROD_HOST:?Set PROD_HOST (e.g., root@your-server)}"
DB_CONTAINER="${DB_CONTAINER:?Set DB_CONTAINER (e.g., myapp-db-1)}"
DB_NAME="${DB_NAME:?Set DB_NAME (e.g., myapp)}"

CACHE_ROOT="${CACHE_ROOT:-$HOME/.cache/${SERVICE_NAME}/db}"
CACHE_FILE="${CACHE_ROOT}/prod.sql.gz"
FRESH_VAR="${SERVICE_NAME^^}_PROD_DB_FRESH"

mkdir -p "${CACHE_ROOT}"

# Check if we should skip fetch (cached and not forcing fresh)
if [[ -f "${CACHE_FILE}" ]] && [[ "${!FRESH_VAR:-0}" != "1" ]]; then
    AGE_SECONDS=$(( $(date +%s) - $(stat -f %m "${CACHE_FILE}" 2>/dev/null || stat -c %Y "${CACHE_FILE}" 2>/dev/null || echo 0) ))
    AGE_HOURS=$(( AGE_SECONDS / 3600 ))
    echo "Using cached DB dump (${AGE_HOURS}h old): ${CACHE_FILE}"
    echo "  Set ${FRESH_VAR}=1 to force fresh fetch"
    exit 0
fi

echo "Fetching production DB from ${PROD_HOST}..."

# Test SSH connectivity
if ! ssh -o ConnectTimeout=5 "${PROD_HOST}" "echo ok" >/dev/null 2>&1; then
    echo "ERROR: Cannot connect to ${PROD_HOST}"
    if [[ -f "${CACHE_FILE}" ]]; then
        echo "  Falling back to cached dump"
        exit 0
    fi
    exit 1
fi

# Dump and compress (pipe through SSH, compress locally)
TEMP_FILE="${CACHE_FILE}.tmp"
ssh "${PROD_HOST}" "docker exec ${DB_CONTAINER} pg_dump -U postgres ${DB_NAME}" \
    | gzip > "${TEMP_FILE}"

# Atomic move
mv "${TEMP_FILE}" "${CACHE_FILE}"
echo "Cached production DB dump: ${CACHE_FILE}"
