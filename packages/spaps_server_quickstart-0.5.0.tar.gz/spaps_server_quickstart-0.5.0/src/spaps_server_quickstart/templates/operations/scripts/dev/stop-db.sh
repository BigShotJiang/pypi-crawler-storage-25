#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
COMPOSE_FILE="${ROOT_DIR}/docker-compose.yml"

compose_cmd() {
  if docker compose version >/dev/null 2>&1; then
    echo "docker compose"
  elif command -v docker-compose >/dev/null 2>&1; then
    echo "docker-compose"
  else
    echo "⚠️  docker compose is required but not installed." >&2
    exit 1
  fi
}

if ! command -v docker >/dev/null 2>&1; then
  echo "⚠️  Docker is required to stop the Postgres container." >&2
  exit 1
fi

COMPOSE_BIN=$(compose_cmd)

echo "🛑 Stopping pgvector Postgres..."
${COMPOSE_BIN} -f "${COMPOSE_FILE}" stop db >/dev/null 2>&1 || true
${COMPOSE_BIN} -f "${COMPOSE_FILE}" rm -f db >/dev/null 2>&1 || true

echo "✅ Postgres container stopped."
