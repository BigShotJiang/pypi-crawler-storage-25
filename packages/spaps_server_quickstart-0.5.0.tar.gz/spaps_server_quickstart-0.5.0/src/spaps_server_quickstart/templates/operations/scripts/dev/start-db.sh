#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
COMPOSE_FILE="${ROOT_DIR}/docker-compose.yml"

DEFAULT_DB_NAME="${PROJECT_DB_NAME:-service}"
DEFAULT_DSN="${PYTEST_DATABASE_URL:-postgresql+asyncpg://postgres:postgres@localhost:5433/${DEFAULT_DB_NAME}}"

compose_cmd() {
  if docker compose version >/dev/null 2>&1; then
    echo "docker compose"
  elif command -v docker-compose >/dev/null 2>&1; then
    echo "docker-compose"
  else
    echo "⚠️  docker compose is required but not installed." >&2
    exit 1
  fi
}

if ! command -v docker >/dev/null 2>&1; then
  echo "⚠️  Docker is required to start the Postgres container." >&2
  exit 1
fi

COMPOSE_BIN=$(compose_cmd)

echo "🚀 Starting pgvector Postgres using ${COMPOSE_BIN}..."
${COMPOSE_BIN} -f "${COMPOSE_FILE}" up -d db

echo "⏳ Waiting for database readiness at ${DEFAULT_DSN}..."
if [[ -x "${ROOT_DIR}/.venv/bin/python" ]]; then
  PYTHON_BIN="${ROOT_DIR}/.venv/bin/python"
else
  PYTHON_BIN="$(command -v python3)"
fi

"${PYTHON_BIN}" "${ROOT_DIR}/scripts/dev/await_db.py" --database-url "${DEFAULT_DSN}" --quiet || {
  echo "❌ Database did not become ready. Inspect the container logs with '${COMPOSE_BIN} logs db'." >&2
  exit 1
}

SYNC_DSN="${DEFAULT_DSN/+asyncpg/+psycopg}"

cat <<MESSAGE
✅ Postgres is ready.

Export these variables if they are not already set:
  export PYTEST_DATABASE_URL=${DEFAULT_DSN}
  export DATABASE_URL=${DEFAULT_DSN}
  export SYNC_DATABASE_URL=${SYNC_DSN}

Stop the database with: scripts/dev/stop-db.sh
MESSAGE
