#!/usr/bin/env python3
from __future__ import annotations

import argparse
import asyncio
import sys
from dataclasses import dataclass
from typing import Optional

import asyncpg


DEFAULT_DB_NAME = "service"
DEFAULT_DSN = f"postgresql+asyncpg://postgres:postgres@localhost:5433/{DEFAULT_DB_NAME}"


def normalise_dsn(raw_dsn: str) -> str:
    if "+asyncpg" in raw_dsn:
        return raw_dsn.replace("+asyncpg", "", 1)
    return raw_dsn


@dataclass
class WaitOptions:
    dsn: str
    timeout: float
    attempts: int
    quiet: bool


async def wait_for_database(options: WaitOptions) -> None:
    last_error: Optional[BaseException] = None
    for attempt in range(1, options.attempts + 1):
        try:
            conn = await asyncpg.connect(normalise_dsn(options.dsn), timeout=options.timeout)
        except BaseException as exc:  # noqa: BLE001
            last_error = exc
            if not options.quiet:
                print(f"Attempt {attempt}/{options.attempts} failed: {exc!s}", file=sys.stderr)
            await asyncio.sleep(1)
        else:
            await conn.close()
            if not options.quiet:
                print("Database connection established.")
            return
    message = (
        f"Timed out waiting for database at {options.dsn}. "
        "Start it with scripts/dev/start-db.sh or export PYTEST_DATABASE_URL for a reachable instance."
    )
    raise TimeoutError(message) from last_error


def parse_args() -> WaitOptions:
    parser = argparse.ArgumentParser(description="Wait for a Postgres database to accept connections.")
    parser.add_argument(
        "--database-url",
        dest="dsn",
        default=DEFAULT_DSN,
        help=f"Database URL to check (default: {DEFAULT_DSN})",
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=5.0,
        help="Per-attempt timeout in seconds (default: 5.0)",
    )
    parser.add_argument(
        "--attempts",
        type=int,
        default=30,
        help="Number of attempts before failing (default: 30)",
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Suppress per-attempt logging; only report success or failure.",
    )
    namespace = parser.parse_args()
    return WaitOptions(
        dsn=namespace.dsn,
        timeout=namespace.timeout,
        attempts=namespace.attempts,
        quiet=namespace.quiet,
    )


def main() -> int:
    options = parse_args()
    try:
        asyncio.run(wait_for_database(options))
    except TimeoutError as exc:
        print(str(exc), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
