#!/usr/bin/env bash
# Post-deployment verification checks
# Runs after deployment to verify the service is healthy

set -euo pipefail

# ============================================================================
# Configuration
# ============================================================================

SERVICE_NAME="${SERVICE_NAME:-quickstart}"
HEALTH_ENDPOINT="${HEALTH_ENDPOINT:-http://localhost:8000/health}"
MAX_HEALTH_WAIT="${MAX_HEALTH_WAIT:-60}"
CHECK_MIGRATIONS="${CHECK_MIGRATIONS:-1}"
EXPECTED_IMAGE="${EXPECTED_IMAGE:-}"
COMPOSE_FILE="${COMPOSE_FILE:-deploy/docker-compose.prod.yml}"
PREVIOUS_IMAGE="${PREVIOUS_IMAGE:-}"  # Set by deploy.sh for rollback

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# ============================================================================
# Helper Functions
# ============================================================================

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1" >&2
}

check_passed() {
    echo -e "  ${GREEN}✓${NC} $1"
}

check_failed() {
    echo -e "  ${RED}✗${NC} $1" >&2
}

# ============================================================================
# Check Functions
# ============================================================================

check_containers_running() {
    log_info "Checking container status..."

    if [[ ! -f "$COMPOSE_FILE" ]]; then
        log_warn "Compose file not found: $COMPOSE_FILE"
        return 0
    fi

    local services
    services=$(docker compose -f "$COMPOSE_FILE" ps --services 2>/dev/null || true)

    if [[ -z "$services" ]]; then
        log_warn "No services found in compose file"
        return 0
    fi

    local failed=0
    while IFS= read -r service; do
        local status
        status=$(docker compose -f "$COMPOSE_FILE" ps --status running "$service" --format '{{.State}}' 2>/dev/null || echo "unknown")

        if [[ "$status" == "running" ]]; then
            check_passed "Container $service is running"
        else
            check_failed "Container $service is not running (status: $status)"
            failed=1
        fi
    done <<< "$services"

    return $failed
}

check_image_version() {
    if [[ -z "$EXPECTED_IMAGE" ]]; then
        log_info "No expected image specified, skipping version check"
        return 0
    fi

    log_info "Checking deployed image version..."

    if [[ ! -f "$COMPOSE_FILE" ]]; then
        log_warn "Compose file not found, skipping image check"
        return 0
    fi

    # Get the API container's current image
    local current_image
    current_image=$(docker compose -f "$COMPOSE_FILE" images --format '{{.Repository}}:{{.Tag}}' 2>/dev/null | head -1 || echo "unknown")

    if [[ "$current_image" == "$EXPECTED_IMAGE" ]]; then
        check_passed "Correct image deployed: $current_image"
        return 0
    else
        log_warn "Image mismatch: expected $EXPECTED_IMAGE, got $current_image"
        return 0  # Don't fail, just warn
    fi
}

check_health_endpoint() {
    log_info "Checking health endpoint (timeout: ${MAX_HEALTH_WAIT}s)..."

    local attempt=1
    local wait_time=2
    local total_waited=0

    while [[ $total_waited -lt $MAX_HEALTH_WAIT ]]; do
        if curl -fsS "$HEALTH_ENDPOINT" -o /dev/null 2>/dev/null; then
            check_passed "Health endpoint responding at $HEALTH_ENDPOINT"
            return 0
        fi

        log_info "  Attempt $attempt: waiting ${wait_time}s..."
        sleep $wait_time
        total_waited=$((total_waited + wait_time))
        attempt=$((attempt + 1))

        # Exponential backoff with max 10s
        if [[ $wait_time -lt 10 ]]; then
            wait_time=$((wait_time * 2))
            if [[ $wait_time -gt 10 ]]; then
                wait_time=10
            fi
        fi
    done

    check_failed "Health endpoint not responding after ${MAX_HEALTH_WAIT}s"
    show_container_logs
    return 1
}

check_migration_status() {
    if [[ "$CHECK_MIGRATIONS" != "1" ]]; then
        log_info "Migration check disabled"
        return 0
    fi

    log_info "Checking migration status..."

    if [[ ! -f "$COMPOSE_FILE" ]]; then
        log_warn "Compose file not found, skipping migration check"
        return 0
    fi

    # Try to run alembic current inside the API container
    local migration_output
    migration_output=$(docker compose -f "$COMPOSE_FILE" exec -T api alembic current 2>&1 || echo "FAILED")

    if [[ "$migration_output" == *"FAILED"* ]]; then
        log_warn "Could not check migrations (alembic may not be installed or accessible)"
        return 0
    fi

    if [[ "$migration_output" == *"head"* ]] || [[ "$migration_output" == *"(head)"* ]]; then
        check_passed "Database is at latest migration"
        return 0
    else
        log_warn "Database may not be at latest migration"
        echo "  Migration output: $migration_output"
        return 0  # Don't fail, just warn
    fi
}

check_docker_healthcheck() {
    log_info "Checking Docker health status..."

    if [[ ! -f "$COMPOSE_FILE" ]]; then
        log_warn "Compose file not found, skipping health check"
        return 0
    fi

    local services
    services=$(docker compose -f "$COMPOSE_FILE" ps --services 2>/dev/null || true)

    if [[ -z "$services" ]]; then
        return 0
    fi

    while IFS= read -r service; do
        local health
        health=$(docker compose -f "$COMPOSE_FILE" ps "$service" --format '{{.Health}}' 2>/dev/null || echo "unknown")

        case "$health" in
            "healthy")
                check_passed "Container $service Docker healthcheck: healthy"
                ;;
            "unhealthy")
                check_failed "Container $service Docker healthcheck: unhealthy"
                ;;
            "starting")
                log_warn "Container $service Docker healthcheck: still starting"
                ;;
            *)
                log_info "  Container $service: no healthcheck configured"
                ;;
        esac
    done <<< "$services"

    return 0
}

check_service_connectivity() {
    log_info "Checking service connectivity..."

    # Check Redis if REDIS_URL is set
    if [[ -n "${REDIS_URL:-}" ]]; then
        if command -v redis-cli &> /dev/null; then
            if redis-cli -u "$REDIS_URL" ping &> /dev/null; then
                check_passed "Redis is reachable"
            else
                log_warn "Redis ping failed"
            fi
        else
            log_warn "redis-cli not available, skipping Redis check"
        fi
    fi

    # Check database if DATABASE_URL is set
    if [[ -n "${DATABASE_URL:-}" ]]; then
        if command -v pg_isready &> /dev/null; then
            local db_host db_port
            if [[ "$DATABASE_URL" =~ @([^:/]+)(:([0-9]+))? ]]; then
                db_host="${BASH_REMATCH[1]}"
                db_port="${BASH_REMATCH[3]:-5432}"

                if pg_isready -h "$db_host" -p "$db_port" -t 5 &> /dev/null; then
                    check_passed "Database is reachable at $db_host:$db_port"
                else
                    log_warn "Database ping failed at $db_host:$db_port"
                fi
            fi
        else
            log_warn "pg_isready not available, skipping database check"
        fi
    fi

    return 0
}

show_container_logs() {
    log_info "Showing recent container logs..."

    if [[ ! -f "$COMPOSE_FILE" ]]; then
        return 0
    fi

    echo ""
    echo "--- Recent API container logs ---"
    docker compose -f "$COMPOSE_FILE" logs --tail 50 api 2>/dev/null || true
    echo "--- End of logs ---"
    echo ""
}

show_rollback_instructions() {
    echo ""
    echo -e "${YELLOW}============================================${NC}"
    echo -e "${YELLOW}ROLLBACK INSTRUCTIONS${NC}"
    echo -e "${YELLOW}============================================${NC}"
    echo ""

    if [[ -n "$PREVIOUS_IMAGE" ]]; then
        echo "To rollback to the previous version ($PREVIOUS_IMAGE):"
        echo ""
        echo "  1. Update IMAGE_TAG in your .env or docker-compose:"
        echo "     IMAGE_TAG=${PREVIOUS_IMAGE##*:}"
        echo ""
        echo "  2. Redeploy with the previous image:"
        echo "     docker compose -f $COMPOSE_FILE up -d"
        echo ""
    else
        echo "To rollback to a previous version:"
        echo ""
        echo "  1. Find the previous image tag:"
        echo "     docker images | grep $SERVICE_NAME"
        echo ""
        echo "  2. Update IMAGE_TAG in your .env or docker-compose"
        echo ""
        echo "  3. Redeploy:"
        echo "     docker compose -f $COMPOSE_FILE up -d"
        echo ""
    fi

    echo "Other debugging steps:"
    echo "  - Check logs: docker compose -f $COMPOSE_FILE logs -f api"
    echo "  - Restart service: docker compose -f $COMPOSE_FILE restart api"
    echo "  - Shell into container: docker compose -f $COMPOSE_FILE exec api bash"
    echo ""
}

# ============================================================================
# Main
# ============================================================================

main() {
    echo ""
    echo "============================================"
    echo "Post-Deployment Verification for ${SERVICE_NAME}"
    echo "============================================"
    echo ""

    local exit_code=0

    # Critical checks (failure = deployment failed)
    check_containers_running || exit_code=1
    check_health_endpoint || exit_code=1

    # Important verifications
    check_image_version
    check_migration_status
    check_docker_healthcheck
    check_service_connectivity

    echo ""
    if [[ $exit_code -eq 0 ]]; then
        log_info "Post-deployment verification passed"
        echo ""
        echo "============================================"
        echo "Deployment successful!"
        echo "============================================"
    else
        log_error "Post-deployment verification failed"
        show_rollback_instructions
        echo "============================================"
        echo "Deployment may have issues - investigate!"
        echo "============================================"
    fi
    echo ""

    return $exit_code
}

main "$@"
