"""
Example local auth routes for development mode.

Copy this file to your service's auth domain to expose local persona management
endpoints. These routes are only useful when development_environment="local".

Usage in your app:
    from your_service.domains.auth.local_routes import router as local_auth_router

    if settings.is_local_development:
        app.include_router(local_auth_router, prefix="/v1/auth", tags=["local-auth"])
"""

from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Header
from pydantic import BaseModel

from spaps_server_quickstart.local_mode import (
    LocalPersona,
    LocalPersonaRegistry,
    get_default_registry,
)


def get_registry() -> LocalPersonaRegistry:
    """Dependency that provides the default persona registry."""
    return get_default_registry()


router = APIRouter()


class PersonaResponse(BaseModel):
    """Response model for persona information."""

    code: str
    token: str
    display_name: str
    user_id: str
    roles: list[str]


class LocalLoginRequest(BaseModel):
    """Request model for local login."""

    code: str | None = None
    token: str | None = None


class LocalLoginResponse(BaseModel):
    """Response model for local login."""

    token: str
    user: PersonaResponse


def _persona_to_response(persona: LocalPersona) -> PersonaResponse:
    """Convert a LocalPersona to a PersonaResponse."""
    return PersonaResponse(
        code=persona.code,
        token=persona.token,
        display_name=persona.display_name,
        user_id=persona.user_id,
        roles=list(persona.roles),
    )


@router.get("/local-personas", response_model=list[PersonaResponse])
async def list_local_personas(
    registry: Annotated[LocalPersonaRegistry, Depends(get_registry)],
) -> list[PersonaResponse]:
    """
    List all available local development personas.

    Returns a list of personas that can be used for local authentication.
    Use the returned token in the Authorization header as "Bearer <token>".
    """
    personas = registry.list_all()
    return [_persona_to_response(p) for p in personas]


@router.post("/local-login", response_model=LocalLoginResponse)
async def local_login(
    request: LocalLoginRequest,
    registry: Annotated[LocalPersonaRegistry, Depends(get_registry)],
) -> LocalLoginResponse:
    """
    Login with a local development persona.

    Provide either a persona code (e.g., "admin", "user") or token
    (e.g., "local-admin", "local-user"). Returns the authentication
    token to use in subsequent requests.
    """
    persona: LocalPersona | None = None

    if request.token:
        persona = registry.get_by_token(request.token)
    elif request.code:
        persona = registry.get_by_code(request.code)

    if persona is None:
        raise HTTPException(
            status_code=400,
            detail="Invalid persona code or token. Use /v1/auth/local-personas to see available options.",
        )

    return LocalLoginResponse(
        token=persona.token,
        user=_persona_to_response(persona),
    )


@router.get("/local-me", response_model=PersonaResponse)
async def get_current_local_persona(
    registry: Annotated[LocalPersonaRegistry, Depends(get_registry)],
    authorization: Annotated[str | None, Header()] = None,
) -> PersonaResponse:
    """
    Get the current local persona based on the Authorization header.

    Extracts the local-* token from the Authorization header and returns
    the corresponding persona information.
    """
    if not authorization or not authorization.startswith("Bearer local-"):
        raise HTTPException(
            status_code=401,
            detail="No local auth token provided. Use 'Bearer local-<persona>' in Authorization header.",
        )

    token = authorization.removeprefix("Bearer ").strip()
    persona = registry.get_by_token(token)

    if persona is None:
        raise HTTPException(
            status_code=401,
            detail=f"Unknown local persona token: {token}",
        )

    return _persona_to_response(persona)
