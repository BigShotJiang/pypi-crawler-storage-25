"""
API routes for the users domain.

Demonstrates domain-driven patterns:
- Dependency injection for services
- Pydantic schemas for request/response
- Role-based access control

Replace {{SERVICE_MODULE}} with your service module name.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

# Import your db session dependency
# from {{SERVICE_MODULE}}.db.session import get_db_session
# For template purposes, using a placeholder
try:
    from sqlalchemy.ext.asyncio import AsyncSession
except ImportError:
    AsyncSession = object  # type: ignore

from spaps_server_quickstart.auth import AuthenticatedUser
from spaps_server_quickstart.auth.dependencies import require_authenticated_user
from spaps_server_quickstart.rbac import require_roles

from .schemas import UserCreate, UserMeResponse, UserResponse, UserUpdate
from .service import UserService

router = APIRouter(prefix="/users", tags=["users"])


def get_user_service(
    # session: AsyncSession = Depends(get_db_session),
) -> UserService:
    """
    Dependency for UserService.

    In your implementation, uncomment the session parameter and import.
    """
    # return UserService(session)
    raise NotImplementedError("Replace with your db session dependency")


# ============================================================================
# Current user endpoints (/me)
# These must be defined BEFORE /{user_id} to avoid path conflicts
# ============================================================================


@router.get("/me", response_model=UserMeResponse)
async def get_current_user_profile(
    current_user: AuthenticatedUser = Depends(require_authenticated_user),
    service: UserService = Depends(get_user_service),
) -> UserMeResponse:
    """
    Get the current authenticated user's profile with auth context.

    Returns the user profile along with roles and authentication mode.
    Works with both local development personas and SPAPS authentication.
    """
    user = await service.get_user(current_user.user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User profile not found")

    # Determine auth mode based on tier (local mode sets tier="local")
    auth_mode = "local" if current_user.tier == "local" else "spaps"

    return UserMeResponse(
        id=user.id,
        email=user.email,
        display_name=user.display_name,
        status=user.status,
        created_at=user.created_at,
        updated_at=user.updated_at,
        roles=list(current_user.roles),
        auth_mode=auth_mode,
    )


@router.patch("/me", response_model=UserMeResponse)
async def update_current_user_profile(
    data: UserUpdate,
    current_user: AuthenticatedUser = Depends(require_authenticated_user),
    service: UserService = Depends(get_user_service),
) -> UserMeResponse:
    """
    Update the current authenticated user's profile.

    Users can only update their own profile (display_name, status, etc.).
    """
    user = await service.update_user(current_user.user_id, data)
    if not user:
        raise HTTPException(status_code=404, detail="User profile not found")

    auth_mode = "local" if current_user.tier == "local" else "spaps"

    return UserMeResponse(
        id=user.id,
        email=user.email,
        display_name=user.display_name,
        status=user.status,
        created_at=user.created_at,
        updated_at=user.updated_at,
        roles=list(current_user.roles),
        auth_mode=auth_mode,
    )


# ============================================================================
# Public endpoints (no auth required)
# ============================================================================


@router.get("/{user_id}", response_model=UserResponse)
async def get_user(
    user_id: str,
    service: UserService = Depends(get_user_service),
) -> UserResponse:
    """Get a user by ID (public)."""
    user = await service.get_user(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return UserResponse.model_validate(user)


# ============================================================================
# Authenticated endpoints
# ============================================================================


@router.get("/", summary="List users")
async def list_users(
    current_user: AuthenticatedUser = Depends(require_roles(["staff", "admin"])),
    service: UserService = Depends(get_user_service),
    limit: int = 50,
    offset: int = 0,
) -> list[UserResponse]:
    """List users (staff/admin only)."""
    users = await service.list_users(limit=limit, offset=offset)
    return [UserResponse.model_validate(u) for u in users]


@router.post("", response_model=UserResponse, status_code=201)
async def create_user(
    data: UserCreate,
    current_user: AuthenticatedUser = Depends(require_roles(["admin"])),
    service: UserService = Depends(get_user_service),
) -> UserResponse:
    """Create a new user (admin only)."""
    # Check for existing user
    existing = await service.get_user_by_email(data.email)
    if existing:
        raise HTTPException(status_code=409, detail="Email already registered")

    user = await service.create_user(data)
    return UserResponse.model_validate(user)


@router.patch("/{user_id}", response_model=UserResponse)
async def update_user(
    user_id: str,
    data: UserUpdate,
    current_user: AuthenticatedUser = Depends(require_roles(["admin"])),
    service: UserService = Depends(get_user_service),
) -> UserResponse:
    """Update a user (admin only)."""
    user = await service.update_user(user_id, data)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return UserResponse.model_validate(user)


@router.delete("/{user_id}", status_code=204)
async def delete_user(
    user_id: str,
    current_user: AuthenticatedUser = Depends(require_roles(["admin"])),
    service: UserService = Depends(get_user_service),
) -> None:
    """Delete a user (admin only)."""
    deleted = await service.delete_user(user_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="User not found")
