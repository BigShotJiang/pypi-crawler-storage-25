"""
Pydantic schemas for the users domain.
"""
from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, EmailStr


class UserBase(BaseModel):
    """Base user schema with common fields."""

    email: EmailStr
    display_name: str | None = None


class UserCreate(UserBase):
    """Schema for creating a user."""

    pass


class UserUpdate(BaseModel):
    """Schema for updating a user."""

    display_name: str | None = None
    status: str | None = None


class UserResponse(UserBase):
    """Schema for user API responses."""

    id: str
    status: str
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class UserMeResponse(UserResponse):
    """
    Schema for /users/me responses with authentication context.

    Extends UserResponse with:
    - roles: List of roles from the authentication token
    - auth_mode: Whether authenticated via local personas or SPAPS
    """

    roles: list[str]
    auth_mode: Literal["local", "spaps"]
