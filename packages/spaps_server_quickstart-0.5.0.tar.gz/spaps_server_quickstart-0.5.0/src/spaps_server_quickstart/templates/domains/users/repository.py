"""
Database operations for the users domain.

Replace {{SERVICE_MODULE}} with your service module name.
"""
from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .models import User
from .schemas import UserCreate, UserUpdate


async def get_user_by_id(
    session: AsyncSession,
    user_id: str,
) -> User | None:
    """Get a user by ID."""
    result = await session.execute(select(User).where(User.id == user_id))
    return result.scalar_one_or_none()


async def get_user_by_email(
    session: AsyncSession,
    email: str,
) -> User | None:
    """Get a user by email."""
    result = await session.execute(select(User).where(User.email == email))
    return result.scalar_one_or_none()


async def list_users(
    session: AsyncSession,
    *,
    limit: int = 50,
    offset: int = 0,
) -> list[User]:
    """List users with pagination."""
    result = await session.execute(select(User).limit(limit).offset(offset))
    return list(result.scalars().all())


async def create_user(
    session: AsyncSession,
    data: UserCreate,
) -> User:
    """Create a new user."""
    user = User(
        email=data.email,
        display_name=data.display_name,
    )
    session.add(user)
    await session.commit()
    await session.refresh(user)
    return user


async def update_user(
    session: AsyncSession,
    user: User,
    data: UserUpdate,
) -> User:
    """Update an existing user."""
    update_data = data.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(user, field, value)
    await session.commit()
    await session.refresh(user)
    return user


async def delete_user(
    session: AsyncSession,
    user: User,
) -> None:
    """Delete a user."""
    await session.delete(user)
    await session.commit()
