# Unit tests for business logic
