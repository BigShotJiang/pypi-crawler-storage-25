# Test Organization

This test structure follows patterns from spaps-server-quickstart.

## Directory Structure

- `api/` - API endpoint tests (use `async_client` fixture)
- `unit/` - Unit tests for business logic (minimal fixtures)
- `integration/` - Integration tests (use `db_session`)
- `domains/` - Domain-specific fixtures and helpers

## Fixtures

### From root conftest.py:

- `db_session` - App-level database session (RLS enforced)
- `admin_session` - Superuser session for fixture setup
- `async_client` - FastAPI test client
- `settings` - Test settings instance
- `database_urls` - Database connection URLs

### Creating domain fixtures:

1. Create `domains/<your_domain>/conftest.py`
2. Use `admin_session` to seed test data
3. Return data needed by tests

Example:
```python
@pytest_asyncio.fixture
async def user(admin_session):
    user_id = uuid4()
    await admin_session.execute(
        text("INSERT INTO users (id, email) VALUES (:id, :email)"),
        {"id": str(user_id), "email": "test@example.com"},
    )
    await admin_session.commit()
    return {"id": user_id, "email": "test@example.com"}
```

## Running Tests

```bash
# All tests
pytest

# Skip slow tests
pytest -m "not slow"

# Only integration tests
pytest -m integration

# Only API tests
pytest tests/api/

# With coverage
pytest --cov={{SERVICE_MODULE}}

# Parallel execution (requires pytest-xdist)
pytest -n auto
```

## Test Markers

- `@pytest.mark.integration` - Integration tests (DB required)
- `@pytest.mark.slow` - Slow tests (skip with `-m "not slow"`)
- `@pytest.mark.asyncio` - Async tests (auto-applied by pytest-asyncio)

## Best Practices

### API Tests (`api/`)
- Test HTTP status codes and response shapes
- Test authentication/authorization
- Use `async_client` fixture
- Mock external services

### Unit Tests (`unit/`)
- Test pure business logic
- Minimize database interaction
- Use mocks for dependencies
- Fast execution

### Integration Tests (`integration/`)
- Test database operations
- Test service interactions
- Use real database (testcontainers)
- May be slower

### Domain Fixtures (`domains/`)
- Create reusable test data factories
- Use `admin_session` for setup (bypasses RLS)
- Keep fixtures focused on one domain
- Document fixture behavior
