"""
Example domain-specific fixtures.

Copy this pattern for your domains.
Replace {{SERVICE_MODULE}} with your service module name.
"""
from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

import pytest_asyncio


@pytest_asyncio.fixture
async def example_entity(admin_session):
    """
    Create a test entity for this domain.

    Use admin_session for fixture setup (bypasses RLS).
    Use db_session in actual tests (enforces RLS).
    """
    entity_id = uuid4()
    now = datetime.now(UTC)

    # Example: seed a test record
    # await admin_session.execute(
    #     text("INSERT INTO examples (id, name, created_at) VALUES (:id, :name, :created_at)"),
    #     {"id": str(entity_id), "name": "Test Entity", "created_at": now},
    # )
    # await admin_session.commit()

    return {"id": entity_id, "name": "Test Entity"}


@pytest_asyncio.fixture
async def multiple_entities(admin_session):
    """
    Create multiple test entities for listing/pagination tests.
    """
    entities = []
    for i in range(5):
        entity_id = uuid4()
        entities.append({"id": entity_id, "name": f"Test Entity {i}"})
        # await admin_session.execute(...)

    # await admin_session.commit()
    return entities
