"""Auth-aware test fixtures for the users domain."""
