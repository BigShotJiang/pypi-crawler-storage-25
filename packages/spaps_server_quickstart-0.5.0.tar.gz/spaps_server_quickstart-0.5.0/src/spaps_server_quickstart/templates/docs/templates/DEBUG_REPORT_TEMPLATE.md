# [Incident Name] Investigation Report

**Date:** YYYY-MM-DD
**Severity:** [critical|high|medium|low]
**Status:** [investigating|resolved|monitoring]
**Duration:** HH:MM (start to resolution)
**Affected Services:** {{SERVICE_NAME}}

## Executive Summary

One paragraph summary of what happened and the impact.

## Problem Statement

What happened? What was the user-visible impact?

- Number of affected users/requests
- Error rates observed
- Services impacted

## Timeline

| Time (UTC) | Event |
|------------|-------|
| HH:MM | First alert/report received |
| HH:MM | Investigation started |
| HH:MM | Root cause identified |
| HH:MM | Fix deployed |
| HH:MM | Incident resolved |
| HH:MM | Post-incident monitoring began |

## Investigation Steps

### Step 1: Initial Triage

**Actions taken:**
```bash
# Commands run
docker logs {{SERVICE_NAME}}-api --tail 100
docker stats --no-stream
```

**Finding:** What did you discover?

**Decision:** What did you decide to do next?

### Step 2: Deep Dive

**Actions taken:**
```sql
-- Queries run
SELECT count(*), status FROM requests
WHERE created_at > NOW() - INTERVAL '1 hour'
GROUP BY status;
```

**Finding:** What did you discover?

**Decision:** What did you decide to do next?

### Step 3: Resolution

**Actions taken:**
```bash
# Fix commands
docker compose -f deploy/docker-compose.prod.yml restart api
```

**Finding:** Confirmation that the fix worked.

## Root Cause

What was the actual underlying issue?

- Technical explanation
- Why it happened (code, config, external factor)
- Why it wasn't caught earlier

## Resolution

What was done to fix it?

```bash
# Commands/code changes that fixed the issue
```

## Impact Assessment

### User Impact
- X users affected
- Y requests failed
- Z minutes of degraded service

### Business Impact
- Revenue impact (if any)
- SLA impact
- Customer communications sent

## Lessons Learned

### What Went Well
- Fast detection (alert fired within X minutes)
- Clear runbook available
- Team coordination effective

### What Could Be Improved
- Detection was slow because...
- Documentation was missing for...
- Communication could have been faster...

## Prevention

How do we prevent this from happening again?

### Immediate Actions (within 24 hours)
- [ ] Add monitoring for X
- [ ] Update runbook with findings

### Short-term Actions (within 1 week)
- [ ] Add validation for Y
- [ ] Improve alerting thresholds

### Long-term Actions (within 1 month)
- [ ] Architectural change to prevent Z
- [ ] Training for team on scenario

## Related Links

- PR that fixed: #123
- Related issue: #456
- Monitoring dashboard: [link]
- Relevant docs: [link]
- Slack thread: [link]

## Appendix

### Relevant Logs

```
[2024-01-01T12:00:00Z] ERROR: Connection refused to database
[2024-01-01T12:00:01Z] WARN: Retry attempt 1/3
```

### Configuration at Time of Incident

```yaml
# Relevant config values
database_pool_size: 10
request_timeout: 30s
```

### Metrics Graphs

[Include screenshots or links to monitoring dashboards showing the incident]
