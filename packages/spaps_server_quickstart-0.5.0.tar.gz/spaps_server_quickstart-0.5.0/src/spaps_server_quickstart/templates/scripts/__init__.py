"""Template scripts for service scaffolding."""
