"""
Pydantic schemas for validating user seed data loaded from YAML files.

These schemas ensure seed data is valid before loading into the database,
catching errors early in the development workflow.

Example usage:
    import yaml
    from scripts.seeds.schemas.users import UsersFileSchema

    with open("scripts/seeds/data/users.yaml") as f:
        data = yaml.safe_load(f)

    # Validate the data - raises ValidationError if invalid
    validated = UsersFileSchema(**data)

    # Use validated data
    for user in validated.users:
        print(f"Seeding user: {user.email}")
        await upsert_user(session, user)
"""
from __future__ import annotations

from pydantic import BaseModel, EmailStr, Field


class UserSeedSchema(BaseModel):
    """
    Schema for a single user record in seed data.

    Fields align with the User model in templates/domains/users/models.py.
    """

    id: str = Field(
        description="UUID for the user record. Use fixed UUIDs for deterministic seeding."
    )
    email: EmailStr = Field(
        description="User's email address. Must be unique across all users."
    )
    display_name: str | None = Field(
        default=None,
        description="Human-readable display name for the user.",
    )
    status: str = Field(
        default="active",
        description="User status: 'active', 'inactive', 'pending', etc.",
    )
    persona_code: str | None = Field(
        default=None,
        description=(
            "Optional link to a local persona code for development auth. "
            "Use 'admin' or 'user' to match the default personas."
        ),
    )

    model_config = {"extra": "forbid"}


class UsersFileSchema(BaseModel):
    """
    Schema for the users.yaml seed file.

    Validates the top-level structure with a list of user records.
    """

    users: list[UserSeedSchema] = Field(
        default_factory=list,
        description="List of user records to seed into the database.",
    )

    model_config = {"extra": "forbid"}


# Optional: Register with the quickstart seed validation framework
def register_with_seed_validator() -> None:
    """
    Register this schema with the quickstart seed validation CLI.

    Call this during application setup to enable validation via:
        python -m spaps_server_quickstart.seeds.cli validate scripts/seeds/data/
    """
    try:
        from spaps_server_quickstart.seeds.schemas import register_schema

        register_schema(r"users\.yaml$", UsersFileSchema)
    except ImportError:
        # Seed validation framework not available
        pass
