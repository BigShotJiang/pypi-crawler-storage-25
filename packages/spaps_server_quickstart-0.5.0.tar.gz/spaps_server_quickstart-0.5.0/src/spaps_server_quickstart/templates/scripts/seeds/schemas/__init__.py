"""Pydantic schemas for validating seed data files."""
