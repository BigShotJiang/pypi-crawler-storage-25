from __future__ import annotations

from datetime import datetime
from types import SimpleNamespace
from typing import Any

import httpx
import pytest

from spaps_server_quickstart.auth_channels import (
    AuthChannelError,
    AuthError,
    SpapsAuthChannelService,
    build_spaps_auth_channel_service,
)
from spaps_server_quickstart.settings import BaseServiceSettings


class ChannelSettings(BaseServiceSettings):
    spaps_api_key: str | None = "api-key"
    spaps_application_id: str | None = "app-id"
    spaps_auth_enabled: bool = True


class StubAsyncAuthClient:
    def __init__(self, *, base_url: str, api_key: str, **_: Any) -> None:
        self.base_url = base_url
        self.api_key = api_key
        self.calls: list[tuple[str, dict[str, Any]]] = []
        self.closed = False
        self._responses: dict[str, Any] = {}
        self._errors: dict[str, Exception] = {}

    def queue_response(self, method: str, response: Any) -> None:
        self._responses[method] = response

    def queue_error(self, method: str, error: Exception) -> None:
        self._errors[method] = error

    async def send_magic_link(self, *, email: str) -> Any:
        self.calls.append(("send_magic_link", {"email": email}))
        if "send_magic_link" in self._errors:
            raise self._errors["send_magic_link"]
        return self._responses.get(
            "send_magic_link",
            SimpleNamespace(message="sent", email=email, sent_at=datetime(2025, 1, 1)),
        )

    async def verify_magic_link(self, *, token: str, type: str = "magiclink") -> Any:
        self.calls.append(("verify_magic_link", {"token": token, "type": type}))
        if "verify_magic_link" in self._errors:
            raise self._errors["verify_magic_link"]
        return self._responses.get(
            "verify_magic_link",
            SimpleNamespace(
                message="ok",
                tokens=SimpleNamespace(access_token="access", refresh_token="refresh", expires_in=900),
                user=SimpleNamespace(id="user-1", email="user@example.com"),
            ),
        )

    async def request_nonce(self, *, wallet_address: str, chain: str | None = None) -> Any:
        self.calls.append(("request_nonce", {"wallet_address": wallet_address, "chain": chain}))
        if "request_nonce" in self._errors:
            raise self._errors["request_nonce"]
        return self._responses.get(
            "request_nonce",
            SimpleNamespace(
                nonce="Sign this message to authenticate with Sweet Potato: nonce",
                message="Sign this message to authenticate with Sweet Potato: nonce",
                wallet_address=wallet_address,
                expires_at=datetime(2025, 1, 1),
            ),
        )

    async def verify_wallet(
        self,
        *,
        wallet_address: str,
        signature: str,
        message: str,
        chain: str | None = None,
    ) -> Any:
        self.calls.append(
            (
                "verify_wallet",
                {
                    "wallet_address": wallet_address,
                    "signature": signature,
                    "message": message,
                    "chain": chain,
                },
            )
        )
        if "verify_wallet" in self._errors:
            raise self._errors["verify_wallet"]
        return self._responses.get(
            "verify_wallet",
            SimpleNamespace(
                access_token="wallet-access",
                refresh_token="wallet-refresh",
                expires_in=900,
                token_type="Bearer",
                user=SimpleNamespace(id="user-1", wallet_address=wallet_address, chain=chain),
            ),
        )

    async def request_password_reset(
        self,
        *,
        email: str,
        redirect_url: str | None = None,
    ) -> Any:
        self.calls.append(("request_password_reset", {"email": email, "redirect_url": redirect_url}))
        if "request_password_reset" in self._errors:
            raise self._errors["request_password_reset"]
        return self._responses.get(
            "request_password_reset",
            SimpleNamespace(message="Password reset email sent", email=email),
        )

    async def confirm_password_reset(
        self,
        *,
        token: str,
        new_password: str,
    ) -> Any:
        self.calls.append(("confirm_password_reset", {"token": token, "new_password": new_password}))
        if "confirm_password_reset" in self._errors:
            raise self._errors["confirm_password_reset"]
        return self._responses.get(
            "confirm_password_reset",
            SimpleNamespace(message="Password reset successful"),
        )

    async def set_password(
        self,
        *,
        new_password: str,
        current_password: str | None = None,
        access_token: str | None = None,
    ) -> Any:
        self.calls.append(
            ("set_password", {
                "new_password": new_password,
                "current_password": current_password,
                "access_token": access_token,
            })
        )
        if "set_password" in self._errors:
            raise self._errors["set_password"]
        return self._responses.get(
            "set_password",
            SimpleNamespace(message="Password set successfully"),
        )

    async def aclose(self) -> None:
        self.closed = True


@pytest.mark.asyncio()
async def test_send_magic_link_success() -> None:
    client = StubAsyncAuthClient(base_url="https://api.test", api_key="key")
    service = SpapsAuthChannelService(
        base_url="https://api.test",
        api_key="key",
        request_timeout=5.0,
        auth_client=client,
    )

    result = await service.send_magic_link(email="user@example.com")

    assert client.calls == [("send_magic_link", {"email": "user@example.com"})]
    assert result.email == "user@example.com"
    assert result.message == "sent"


@pytest.mark.asyncio()
async def test_send_magic_link_wraps_auth_error() -> None:
    client = StubAsyncAuthClient(base_url="https://api.test", api_key="key")
    client.queue_error(
        "send_magic_link",
        AuthError("Invalid email", status_code=422, error_code="INVALID_EMAIL"),
    )
    service = SpapsAuthChannelService(
        base_url="https://api.test",
        api_key="key",
        request_timeout=5.0,
        auth_client=client,
    )

    with pytest.raises(AuthChannelError) as excinfo:
        await service.send_magic_link(email="bad")

    error = excinfo.value
    assert error.status_code == 422
    assert error.error_code == "INVALID_EMAIL"
    assert "Invalid email" in str(error)


@pytest.mark.asyncio()
async def test_send_magic_link_wraps_http_error() -> None:
    client = StubAsyncAuthClient(base_url="https://api.test", api_key="key")
    client.queue_error("send_magic_link", httpx.HTTPError("boom"))
    service = SpapsAuthChannelService(
        base_url="https://api.test",
        api_key="key",
        request_timeout=5.0,
        auth_client=client,
    )

    with pytest.raises(AuthChannelError) as excinfo:
        await service.send_magic_link(email="user@example.com")

    assert excinfo.value.status_code == 503
    assert "unavailable" in str(excinfo.value)


@pytest.mark.asyncio()
async def test_verify_magic_link_success() -> None:
    response = SimpleNamespace(
        message="success",
        tokens=SimpleNamespace(access_token="access", refresh_token="refresh", expires_in=900),
        user=SimpleNamespace(id="user-1"),
    )
    client = StubAsyncAuthClient(base_url="https://api.test", api_key="key")
    client.queue_response("verify_magic_link", response)

    service = SpapsAuthChannelService(
        base_url="https://api.test",
        api_key="key",
        request_timeout=5.0,
        auth_client=client,
    )

    result = await service.verify_magic_link(token="token", link_type="magiclink")

    assert client.calls[-1] == ("verify_magic_link", {"token": "token", "type": "magiclink"})
    assert result is response
    assert result.tokens.access_token == "access"


@pytest.mark.asyncio()
async def test_request_nonce_success() -> None:
    client = StubAsyncAuthClient(base_url="https://api.test", api_key="key")
    service = SpapsAuthChannelService(
        base_url="https://api.test",
        api_key="key",
        request_timeout=5.0,
        auth_client=client,
    )

    result = await service.request_wallet_nonce(wallet_address="0xabc", chain="ethereum")

    assert client.calls[-1] == ("request_nonce", {"wallet_address": "0xabc", "chain": "ethereum"})
    assert result.wallet_address == "0xabc"
    assert "Sign this message" in result.message


@pytest.mark.asyncio()
async def test_verify_wallet_success() -> None:
    response = SimpleNamespace(
        access_token="access",
        refresh_token="refresh",
        expires_in=900,
        token_type="Bearer",
        user=SimpleNamespace(id="user-1", wallet_address="0xabc", chain="solana"),
    )
    client = StubAsyncAuthClient(base_url="https://api.test", api_key="key")
    client.queue_response("verify_wallet", response)

    service = SpapsAuthChannelService(
        base_url="https://api.test",
        api_key="key",
        request_timeout=5.0,
        auth_client=client,
    )

    result = await service.verify_wallet(
        wallet_address="0xabc",
        signature="signature",
        message="message",
        chain="solana",
    )

    assert client.calls[-1] == (
        "verify_wallet",
        {
            "wallet_address": "0xabc",
            "signature": "signature",
            "message": "message",
            "chain": "solana",
        },
    )
    assert result is response
    assert result.user.wallet_address == "0xabc"


@pytest.mark.asyncio()
async def test_verify_wallet_wraps_auth_error() -> None:
    client = StubAsyncAuthClient(base_url="https://api.test", api_key="key")
    client.queue_error(
        "verify_wallet",
        AuthError("Signature invalid", status_code=401, error_code="SIGNATURE_INVALID"),
    )

    service = SpapsAuthChannelService(
        base_url="https://api.test",
        api_key="key",
        request_timeout=5.0,
        auth_client=client,
    )

    with pytest.raises(AuthChannelError) as excinfo:
        await service.verify_wallet(
            wallet_address="0xabc",
            signature="bad",
            message="message",
            chain="solana",
        )

    error = excinfo.value
    assert error.status_code == 401
    assert error.error_code == "SIGNATURE_INVALID"
    assert "Signature invalid" in str(error)


def test_build_spaps_auth_channel_service_requires_keys() -> None:
    settings = BaseServiceSettings()

    with pytest.raises(ValueError):
        build_spaps_auth_channel_service(settings)

    configured = ChannelSettings()
    service = build_spaps_auth_channel_service(configured, logger_namespace="custom")
    assert isinstance(service, SpapsAuthChannelService)


@pytest.mark.asyncio()
async def test_request_password_reset_success() -> None:
    """Test password reset request."""
    response = SimpleNamespace(message="Password reset email sent", email="user@test.com")
    client = StubAsyncAuthClient(base_url="https://api.test", api_key="key")
    client.queue_response("request_password_reset", response)

    service = SpapsAuthChannelService(
        base_url="https://api.test",
        api_key="key",
        auth_client=client,
    )

    result = await service.request_password_reset(
        email="user@test.com",
        redirect_url="https://app.test/reset",
    )

    assert result is response
    assert result.message == "Password reset email sent"


@pytest.mark.asyncio()
async def test_request_password_reset_wraps_auth_error() -> None:
    """Test password reset request error handling."""
    client = StubAsyncAuthClient(base_url="https://api.test", api_key="key")
    client.queue_error(
        "request_password_reset",
        AuthError("Email not found", status_code=404, error_code="EMAIL_NOT_FOUND"),
    )

    service = SpapsAuthChannelService(
        base_url="https://api.test",
        api_key="key",
        auth_client=client,
    )

    with pytest.raises(AuthChannelError) as excinfo:
        await service.request_password_reset(email="unknown@test.com")

    error = excinfo.value
    assert error.status_code == 404
    assert error.error_code == "EMAIL_NOT_FOUND"


@pytest.mark.asyncio()
async def test_confirm_password_reset_success() -> None:
    """Test password reset confirmation."""
    response = SimpleNamespace(message="Password reset successful", user_id="user-1")
    client = StubAsyncAuthClient(base_url="https://api.test", api_key="key")
    client.queue_response("confirm_password_reset", response)

    service = SpapsAuthChannelService(
        base_url="https://api.test",
        api_key="key",
        auth_client=client,
    )

    result = await service.confirm_password_reset(
        token="reset-token",
        new_password="NewPassword123!",
    )

    assert result is response
    assert result.message == "Password reset successful"


@pytest.mark.asyncio()
async def test_confirm_password_reset_wraps_auth_error() -> None:
    """Test password reset confirmation error handling."""
    client = StubAsyncAuthClient(base_url="https://api.test", api_key="key")
    client.queue_error(
        "confirm_password_reset",
        AuthError("Invalid or expired token", status_code=400, error_code="TOKEN_INVALID"),
    )

    service = SpapsAuthChannelService(
        base_url="https://api.test",
        api_key="key",
        auth_client=client,
    )

    with pytest.raises(AuthChannelError) as excinfo:
        await service.confirm_password_reset(token="bad-token", new_password="Password123!")

    error = excinfo.value
    assert error.status_code == 400
    assert error.error_code == "TOKEN_INVALID"


@pytest.mark.asyncio()
async def test_set_password_success() -> None:
    """Test set password."""
    response = SimpleNamespace(message="Password set successfully")
    client = StubAsyncAuthClient(base_url="https://api.test", api_key="key")
    client.queue_response("set_password", response)

    service = SpapsAuthChannelService(
        base_url="https://api.test",
        api_key="key",
        auth_client=client,
    )

    result = await service.set_password(
        new_password="NewPassword123!",
        current_password="OldPassword123!",
        access_token="token",
    )

    assert result is response
    assert result.message == "Password set successfully"


@pytest.mark.asyncio()
async def test_set_password_wraps_auth_error() -> None:
    """Test set password error handling."""
    client = StubAsyncAuthClient(base_url="https://api.test", api_key="key")
    client.queue_error(
        "set_password",
        AuthError("Current password incorrect", status_code=401, error_code="PASSWORD_MISMATCH"),
    )

    service = SpapsAuthChannelService(
        base_url="https://api.test",
        api_key="key",
        auth_client=client,
    )

    with pytest.raises(AuthChannelError) as excinfo:
        await service.set_password(new_password="NewPassword123!", current_password="wrong")

    error = excinfo.value
    assert error.status_code == 401
    assert error.error_code == "PASSWORD_MISMATCH"


@pytest.mark.asyncio()
async def test_service_aclose_with_owned_client() -> None:
    """Test that aclose closes owned client."""
    # Service without injected client owns the client
    service = SpapsAuthChannelService(
        base_url="https://api.test",
        api_key="key",
    )

    # Should not raise
    await service.aclose()


@pytest.mark.asyncio()
async def test_service_aclose_with_injected_client() -> None:
    """Test that aclose does not close injected client."""
    client = StubAsyncAuthClient(base_url="https://api.test", api_key="key")
    service = SpapsAuthChannelService(
        base_url="https://api.test",
        api_key="key",
        auth_client=client,
    )

    await service.aclose()
    # Injected client should not be closed by service
    assert client.closed is False


@pytest.mark.asyncio()
async def test_handle_auth_error_maps_5xx_to_503() -> None:
    """Test that 500-level errors map to 503."""
    client = StubAsyncAuthClient(base_url="https://api.test", api_key="key")
    client.queue_error(
        "send_magic_link",
        AuthError("Internal server error", status_code=500, error_code="SERVER_ERROR"),
    )

    service = SpapsAuthChannelService(
        base_url="https://api.test",
        api_key="key",
        auth_client=client,
    )

    with pytest.raises(AuthChannelError) as excinfo:
        await service.send_magic_link(email="user@test.com")

    error = excinfo.value
    assert error.status_code == 503
    assert "unavailable" in str(error)


@pytest.mark.asyncio()
async def test_verify_magic_link_wraps_http_error() -> None:
    """Test verify_magic_link HTTP error handling."""
    client = StubAsyncAuthClient(base_url="https://api.test", api_key="key")
    client.queue_error("verify_magic_link", httpx.HTTPError("Network failure"))

    service = SpapsAuthChannelService(
        base_url="https://api.test",
        api_key="key",
        auth_client=client,
    )

    with pytest.raises(AuthChannelError) as excinfo:
        await service.verify_magic_link(token="token")

    assert excinfo.value.status_code == 503


@pytest.mark.asyncio()
async def test_request_nonce_wraps_http_error() -> None:
    """Test request_nonce HTTP error handling."""
    client = StubAsyncAuthClient(base_url="https://api.test", api_key="key")
    client.queue_error("request_nonce", httpx.HTTPError("Network failure"))

    service = SpapsAuthChannelService(
        base_url="https://api.test",
        api_key="key",
        auth_client=client,
    )

    with pytest.raises(AuthChannelError) as excinfo:
        await service.request_wallet_nonce(wallet_address="0xabc")

    assert excinfo.value.status_code == 503


@pytest.mark.asyncio()
async def test_verify_wallet_wraps_http_error() -> None:
    """Test verify_wallet HTTP error handling."""
    client = StubAsyncAuthClient(base_url="https://api.test", api_key="key")
    client.queue_error("verify_wallet", httpx.HTTPError("Network failure"))

    service = SpapsAuthChannelService(
        base_url="https://api.test",
        api_key="key",
        auth_client=client,
    )

    with pytest.raises(AuthChannelError) as excinfo:
        await service.verify_wallet(
            wallet_address="0xabc",
            signature="sig",
            message="msg",
        )

    assert excinfo.value.status_code == 503
