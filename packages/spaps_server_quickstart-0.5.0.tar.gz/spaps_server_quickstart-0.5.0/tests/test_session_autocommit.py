"""Tests for session dependency auto-commit / rollback behaviour.

Verifies that:
- The session is committed after a successful yield (request handler finishes normally).
- The session is NOT committed (i.e. rolled back via ``__aexit__``) when the
  request handler raises an exception.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from spaps_server_quickstart.db.session import DatabaseResources, session_dependency_factory


# ---------------------------------------------------------------------------
# DatabaseResources.session_dependency
# ---------------------------------------------------------------------------


class TestDatabaseResourcesSessionDependency:
    async def test_commit_on_success(self):
        """Session is committed when the generator completes normally."""
        mock_session = AsyncMock()

        mock_factory = MagicMock()
        mock_ctx = AsyncMock()
        mock_ctx.__aenter__.return_value = mock_session
        mock_ctx.__aexit__.return_value = False
        mock_factory.return_value = mock_ctx

        resources = DatabaseResources.__new__(DatabaseResources)
        resources.get_session_factory = MagicMock(return_value=mock_factory)

        gen = resources.session_dependency()
        session = await gen.__anext__()

        assert session is mock_session
        mock_session.commit.assert_not_called()

        # Simulate successful completion
        with pytest.raises(StopAsyncIteration):
            await gen.__anext__()

        mock_session.commit.assert_awaited_once()

    async def test_no_commit_on_exception(self):
        """Session is NOT committed when an exception occurs after yield."""
        mock_session = AsyncMock()

        mock_factory = MagicMock()
        mock_ctx = AsyncMock()
        mock_ctx.__aenter__.return_value = mock_session
        mock_ctx.__aexit__.return_value = False
        mock_factory.return_value = mock_ctx

        resources = DatabaseResources.__new__(DatabaseResources)
        resources.get_session_factory = MagicMock(return_value=mock_factory)

        gen = resources.session_dependency()
        session = await gen.__anext__()
        assert session is mock_session

        # Simulate exception — generator.athrow() skips code after yield
        with pytest.raises(ValueError):
            await gen.athrow(ValueError("route failed"))

        mock_session.commit.assert_not_called()


# ---------------------------------------------------------------------------
# session_dependency_factory
# ---------------------------------------------------------------------------


class TestSessionDependencyFactory:
    async def test_commit_on_success(self):
        """Factory-produced dependency commits on normal exit."""
        mock_session = AsyncMock()

        mock_factory = MagicMock()
        mock_ctx = AsyncMock()
        mock_ctx.__aenter__.return_value = mock_session
        mock_ctx.__aexit__.return_value = False
        mock_factory.return_value = mock_ctx

        dep = session_dependency_factory(mock_factory)
        gen = dep()
        session = await gen.__anext__()

        assert session is mock_session
        mock_session.commit.assert_not_called()

        with pytest.raises(StopAsyncIteration):
            await gen.__anext__()

        mock_session.commit.assert_awaited_once()

    async def test_no_commit_on_exception(self):
        """Factory-produced dependency does NOT commit when exception is thrown."""
        mock_session = AsyncMock()

        mock_factory = MagicMock()
        mock_ctx = AsyncMock()
        mock_ctx.__aenter__.return_value = mock_session
        mock_ctx.__aexit__.return_value = False
        mock_factory.return_value = mock_ctx

        dep = session_dependency_factory(mock_factory)
        gen = dep()
        session = await gen.__anext__()
        assert session is mock_session

        with pytest.raises(RuntimeError):
            await gen.athrow(RuntimeError("handler error"))

        mock_session.commit.assert_not_called()
