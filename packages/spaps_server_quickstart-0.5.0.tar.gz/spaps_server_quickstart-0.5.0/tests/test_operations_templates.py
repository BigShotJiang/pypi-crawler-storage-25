from __future__ import annotations

from importlib import resources

import pytest

import os

import spaps_server_quickstart


def _template_path(*parts: str):
    template_resource = resources.files(spaps_server_quickstart) / "templates"
    for part in parts:
        template_resource = template_resource / part
    return resources.as_file(template_resource)


def _load_operations_template(path: str) -> str:
    with _template_path("operations", path) as file_path:
        return file_path.read_text()


@pytest.mark.parametrize(
    "filename",
    [
        "Makefile",
        ".env.production.example",
        "docker-compose.prod.yml",
        "deploy/deploy.sh",
        "scripts/dev/start-db.sh",
        "scripts/dev/stop-db.sh",
        "scripts/dev/await_db.py",
    ],
)
def test_operations_templates_available(filename: str) -> None:
    content = _load_operations_template(filename)
    assert content.strip(), f"Template {filename} should not be empty"


def test_deploy_script_marked_executable() -> None:
    with _template_path("operations", "deploy", "deploy.sh") as script_path:
        assert os.access(script_path, os.X_OK), "deploy script should be executable"


def test_dev_scripts_marked_executable() -> None:
    for script in ("start-db.sh", "stop-db.sh", "await_db.py"):
        with _template_path("operations", "scripts", "dev", script) as script_path:
            assert os.access(script_path, os.X_OK), f"{script} should be executable"


@pytest.mark.parametrize(
    "filename",
    [
        ("domains", "users", "router.py"),
        ("domains", "admin", "router.py"),
    ],
)
def test_domain_templates_available(filename: tuple[str, ...]) -> None:
    with _template_path(*filename) as template_path:
        content = template_path.read_text()
        assert "require_roles" in content


def test_docker_compose_contains_placeholder_image() -> None:
    contents = _load_operations_template("docker-compose.prod.yml")
    assert "${SPAPS_IMAGE" in contents


# ============================================================================
# Pre/Post Deployment Checks Tests
# ============================================================================


@pytest.mark.parametrize(
    "script_name",
    [
        "deploy/pre-deploy-checks.sh",
        "deploy/post-deploy-verify.sh",
    ],
)
def test_deploy_check_scripts_exist(script_name: str) -> None:
    """Deployment check scripts should exist in templates."""
    content = _load_operations_template(script_name)
    assert content.strip(), f"Template {script_name} should not be empty"


@pytest.mark.parametrize(
    "script_name",
    [
        "deploy/pre-deploy-checks.sh",
        "deploy/post-deploy-verify.sh",
    ],
)
def test_deploy_check_scripts_marked_executable(script_name: str) -> None:
    """Deployment check scripts should be marked executable."""
    with _template_path("operations", *script_name.split("/")) as script_path:
        assert os.access(script_path, os.X_OK), f"{script_name} should be executable"


def test_pre_deploy_checks_uses_service_name_var() -> None:
    """pre-deploy-checks.sh should use SERVICE_NAME variable."""
    content = _load_operations_template("deploy/pre-deploy-checks.sh")
    assert "SERVICE_NAME" in content


def test_pre_deploy_checks_has_port_check() -> None:
    """pre-deploy-checks.sh should check for port availability."""
    content = _load_operations_template("deploy/pre-deploy-checks.sh")
    assert "port" in content.lower() or "REQUIRED_PORTS" in content


def test_pre_deploy_checks_has_disk_space_check() -> None:
    """pre-deploy-checks.sh should check disk space."""
    content = _load_operations_template("deploy/pre-deploy-checks.sh")
    assert "disk" in content.lower() or "MIN_DISK_SPACE" in content


def test_pre_deploy_checks_has_env_validation() -> None:
    """pre-deploy-checks.sh should validate environment variables."""
    content = _load_operations_template("deploy/pre-deploy-checks.sh")
    assert "REQUIRED_ENV" in content or "env" in content.lower()


def test_post_deploy_verify_has_health_check() -> None:
    """post-deploy-verify.sh should include health check."""
    content = _load_operations_template("deploy/post-deploy-verify.sh")
    assert "health" in content.lower() or "HEALTH_ENDPOINT" in content


def test_post_deploy_verify_has_container_check() -> None:
    """post-deploy-verify.sh should verify container status."""
    content = _load_operations_template("deploy/post-deploy-verify.sh")
    assert "docker" in content.lower()


def test_post_deploy_verify_has_max_wait() -> None:
    """post-deploy-verify.sh should have configurable timeout."""
    content = _load_operations_template("deploy/post-deploy-verify.sh")
    assert "MAX_" in content or "timeout" in content.lower()


def test_deploy_sh_calls_pre_deploy_checks() -> None:
    """deploy.sh should call pre-deploy-checks.sh."""
    content = _load_operations_template("deploy/deploy.sh")
    assert "pre-deploy-checks" in content


def test_deploy_sh_calls_post_deploy_verify() -> None:
    """deploy.sh should call post-deploy-verify.sh."""
    content = _load_operations_template("deploy/deploy.sh")
    assert "post-deploy-verify" in content


# ============================================================================
# Database Caching Tests (local-debug-loop.sh)
# ============================================================================


def test_local_debug_loop_exists_and_executable() -> None:
    """local-debug-loop.sh should exist and be executable."""
    with _template_path("operations", "scripts", "dev", "local-debug-loop.sh") as script_path:
        assert script_path.exists(), "local-debug-loop.sh should exist"
        assert os.access(script_path, os.X_OK), "local-debug-loop.sh should be executable"


def test_local_debug_loop_uses_service_name_var() -> None:
    """local-debug-loop.sh should use SERVICE_NAME variable."""
    content = _load_operations_template("scripts/dev/local-debug-loop.sh")
    assert "SERVICE_NAME" in content


def test_local_debug_loop_has_hash_computation() -> None:
    """local-debug-loop.sh should compute hash for cache validation."""
    content = _load_operations_template("scripts/dev/local-debug-loop.sh")
    assert "hash" in content.lower() or "sha" in content.lower() or "md5" in content.lower()


def test_local_debug_loop_has_cache_restore() -> None:
    """local-debug-loop.sh should have cache restore logic."""
    content = _load_operations_template("scripts/dev/local-debug-loop.sh")
    assert "cache" in content.lower() or "restore" in content.lower()


def test_local_debug_loop_has_cache_save() -> None:
    """local-debug-loop.sh should have cache save logic."""
    content = _load_operations_template("scripts/dev/local-debug-loop.sh")
    assert "save" in content.lower() or "pg_dump" in content.lower()


def test_makefile_has_local_up_targets() -> None:
    """Makefile should have local-up targets."""
    content = _load_operations_template("Makefile")
    assert "local-up" in content


def test_makefile_local_up_seed_sets_force_flag() -> None:
    """Makefile local-up-seed should force reseed."""
    content = _load_operations_template("Makefile")
    assert "FORCE_RESEED" in content or "force" in content.lower()


# ============================================================================
# Feature 5: Alembic Templates Tests
# ============================================================================


def _load_alembic_template(path: str) -> str:
    """Load template from alembic directory."""
    with _template_path("alembic", path) as file_path:
        return file_path.read_text()


def test_alembic_ini_template_exists() -> None:
    """alembic.ini template should exist."""
    with _template_path("alembic.ini") as file_path:
        content = file_path.read_text()
        assert content.strip(), "alembic.ini template should not be empty"


def test_alembic_env_py_template_exists() -> None:
    """alembic/env.py template should exist."""
    content = _load_alembic_template("env.py")
    assert content.strip(), "alembic/env.py template should not be empty"


def test_alembic_script_mako_template_exists() -> None:
    """alembic/script.py.mako template should exist."""
    content = _load_alembic_template("script.py.mako")
    assert content.strip(), "alembic/script.py.mako template should not be empty"


def test_alembic_ini_has_ruff_post_hook() -> None:
    """alembic.ini should configure ruff formatter as post-write hook."""
    with _template_path("alembic.ini") as file_path:
        content = file_path.read_text()
        assert "ruff" in content.lower()
        assert "post_write_hooks" in content or "formatter" in content


def test_alembic_ini_has_utc_timezone() -> None:
    """alembic.ini should set UTC timezone."""
    with _template_path("alembic.ini") as file_path:
        content = file_path.read_text()
        assert "UTC" in content or "utc" in content


def test_env_py_imports_models() -> None:
    """env.py should import models for autogenerate."""
    content = _load_alembic_template("env.py")
    assert "Base" in content or "metadata" in content


def test_env_py_handles_pgvector_extension() -> None:
    """env.py should handle pgvector extension creation."""
    content = _load_alembic_template("env.py")
    assert "vector" in content.lower() or "pgvector" in content.lower()


def test_env_py_uses_sync_database_url() -> None:
    """env.py should use sync database URL for Alembic."""
    content = _load_alembic_template("env.py")
    assert "sync" in content.lower() or "psycopg" in content.lower()


def test_env_py_has_compare_type_true() -> None:
    """env.py should enable compare_type for type change detection."""
    content = _load_alembic_template("env.py")
    assert "compare_type" in content


# ============================================================================
# Feature 6: Rollback GitHub Action Tests
# ============================================================================


def test_rollback_workflow_exists() -> None:
    """rollback.yml workflow should exist."""
    content = _load_operations_template(".github/workflows/rollback.yml")
    assert content.strip(), "rollback.yml should not be empty"


def test_rollback_has_workflow_dispatch() -> None:
    """rollback.yml should have workflow_dispatch trigger."""
    content = _load_operations_template(".github/workflows/rollback.yml")
    assert "workflow_dispatch" in content


def test_rollback_has_commit_sha_input() -> None:
    """rollback.yml should accept commit_sha input."""
    content = _load_operations_template(".github/workflows/rollback.yml")
    assert "commit_sha" in content


def test_rollback_verifies_image_exists() -> None:
    """rollback.yml should verify the image exists before deploying."""
    content = _load_operations_template(".github/workflows/rollback.yml")
    assert "docker pull" in content or "verify" in content.lower()


def test_rollback_has_health_check() -> None:
    """rollback.yml should include health check after deployment."""
    content = _load_operations_template(".github/workflows/rollback.yml")
    assert "health" in content.lower()


def test_rollback_uses_service_name() -> None:
    """rollback.yml should use SERVICE_NAME variable."""
    content = _load_operations_template(".github/workflows/rollback.yml")
    assert "SERVICE_NAME" in content


# ============================================================================
# Feature 7: Migration Gate in CI Tests
# ============================================================================


def test_migration_compose_exists() -> None:
    """docker-compose.migration.yml should exist."""
    content = _load_operations_template("deploy/docker-compose.migration.yml")
    assert content.strip(), "docker-compose.migration.yml should not be empty"


def test_migration_compose_has_isolated_network() -> None:
    """docker-compose.migration.yml should use isolated network."""
    content = _load_operations_template("deploy/docker-compose.migration.yml")
    assert "network" in content.lower()


def test_migration_compose_has_pgvector_image() -> None:
    """docker-compose.migration.yml should use pgvector-enabled postgres."""
    content = _load_operations_template("deploy/docker-compose.migration.yml")
    assert "pgvector" in content.lower() or "ankane" in content.lower()


def test_migration_compose_has_db_healthcheck() -> None:
    """docker-compose.migration.yml should have database healthcheck."""
    content = _load_operations_template("deploy/docker-compose.migration.yml")
    assert "healthcheck" in content.lower() or "pg_isready" in content.lower()


def test_deploy_workflow_has_migration_gate_job() -> None:
    """deploy.yml should have migration-gate job."""
    content = _load_operations_template(".github/workflows/deploy.yml")
    assert "migration" in content.lower()


def test_migration_gate_runs_alembic_upgrade() -> None:
    """Migration gate should run alembic upgrade head."""
    content = _load_operations_template(".github/workflows/deploy.yml")
    assert "alembic" in content.lower()


# ============================================================================
# Feature 10: Pre-commit Configuration Tests
# ============================================================================


def _load_root_template(path: str) -> str:
    """Load template from root templates directory (not operations/)."""
    with _template_path(path) as file_path:
        return file_path.read_text()


def test_precommit_config_exists() -> None:
    """.pre-commit-config.yaml template should exist."""
    content = _load_root_template(".pre-commit-config.yaml")
    assert content.strip(), ".pre-commit-config.yaml should not be empty"


def test_precommit_has_ruff_hooks() -> None:
    """Pre-commit config should include ruff linting and formatting."""
    content = _load_root_template(".pre-commit-config.yaml")
    assert "ruff" in content.lower()
    assert "ruff-pre-commit" in content or "astral-sh" in content


def test_precommit_has_mypy_hook() -> None:
    """Pre-commit config should include mypy type checking."""
    content = _load_root_template(".pre-commit-config.yaml")
    assert "mypy" in content.lower()


def test_precommit_has_standard_hooks() -> None:
    """Pre-commit config should include standard pre-commit hooks."""
    content = _load_root_template(".pre-commit-config.yaml")
    assert "pre-commit-hooks" in content
    # Should have common safety hooks
    assert "trailing-whitespace" in content or "end-of-file" in content


# ============================================================================
# Feature 9: Test Directory Structure Tests
# ============================================================================


def test_tests_api_directory_exists() -> None:
    """tests/api/ directory should exist with __init__.py."""
    with _template_path("tests", "api", "__init__.py") as file_path:
        assert file_path.exists(), "tests/api/__init__.py should exist"


def test_tests_unit_directory_exists() -> None:
    """tests/unit/ directory should exist with __init__.py."""
    with _template_path("tests", "unit", "__init__.py") as file_path:
        assert file_path.exists(), "tests/unit/__init__.py should exist"


def test_tests_integration_directory_exists() -> None:
    """tests/integration/ directory should exist with __init__.py."""
    with _template_path("tests", "integration", "__init__.py") as file_path:
        assert file_path.exists(), "tests/integration/__init__.py should exist"


def test_tests_domains_directory_exists() -> None:
    """tests/domains/ directory should exist with __init__.py."""
    with _template_path("tests", "domains", "__init__.py") as file_path:
        assert file_path.exists(), "tests/domains/__init__.py should exist"


def test_api_example_test_exists() -> None:
    """Example API test should exist."""
    with _template_path("tests", "api", "test_health.py") as file_path:
        content = file_path.read_text()
        assert "async_client" in content, "API test should use async_client fixture"
        assert "health" in content.lower(), "Health test should test health endpoint"


def test_unit_example_test_exists() -> None:
    """Example unit test should exist."""
    with _template_path("tests", "unit", "test_settings.py") as file_path:
        content = file_path.read_text()
        assert "settings" in content.lower(), "Settings test should test settings"


def test_integration_example_test_exists() -> None:
    """Example integration test should exist."""
    with _template_path("tests", "integration", "test_db_connectivity.py") as file_path:
        content = file_path.read_text()
        assert "db_session" in content or "database" in content.lower(), "Should test database"


def test_root_conftest_has_db_session() -> None:
    """Root conftest should provide db_session fixture."""
    with _template_path("tests", "conftest.py") as file_path:
        content = file_path.read_text()
        assert "db_session" in content, "conftest should have db_session fixture"


def test_root_conftest_has_admin_session() -> None:
    """Root conftest should provide admin_session fixture."""
    with _template_path("tests", "conftest.py") as file_path:
        content = file_path.read_text()
        assert "admin_session" in content, "conftest should have admin_session fixture"


def test_root_conftest_has_async_client() -> None:
    """Root conftest should provide async_client fixture."""
    with _template_path("tests", "conftest.py") as file_path:
        content = file_path.read_text()
        assert "async_client" in content, "conftest should have async_client fixture"


def test_domain_conftest_example_exists() -> None:
    """Example domain conftest should exist."""
    with _template_path("tests", "domains", "example", "conftest.py") as file_path:
        content = file_path.read_text()
        assert "fixture" in content.lower() or "@pytest" in content, "Should be a pytest conftest"


def test_tests_readme_exists() -> None:
    """tests/README.md should exist with testing guide."""
    with _template_path("tests", "README.md") as file_path:
        content = file_path.read_text()
        assert "api/" in content.lower() or "unit/" in content.lower(), "Should document structure"


# ============================================================================
# Feature 11: Domain-Driven Structure Example Tests
# ============================================================================


def test_users_domain_has_models() -> None:
    """Users domain should have models.py."""
    with _template_path("domains", "users", "models.py") as file_path:
        content = file_path.read_text()
        assert "class User" in content or "class" in content
        assert "Base" in content or "mapped_column" in content


def test_users_domain_has_router() -> None:
    """Users domain should have router.py."""
    with _template_path("domains", "users", "router.py") as file_path:
        content = file_path.read_text()
        assert "router" in content.lower()
        assert "APIRouter" in content


def test_users_domain_has_service() -> None:
    """Users domain should have service.py."""
    with _template_path("domains", "users", "service.py") as file_path:
        content = file_path.read_text()
        assert "class" in content or "def " in content
        assert "UserService" in content or "service" in content.lower()


def test_users_domain_has_repository() -> None:
    """Users domain should have repository.py."""
    with _template_path("domains", "users", "repository.py") as file_path:
        content = file_path.read_text()
        assert "session" in content.lower()
        assert "async def" in content


def test_users_domain_has_schemas() -> None:
    """Users domain should have schemas.py."""
    with _template_path("domains", "users", "schemas.py") as file_path:
        content = file_path.read_text()
        assert "BaseModel" in content or "pydantic" in content.lower()


def test_router_uses_dependency_injection() -> None:
    """Router should use FastAPI dependency injection."""
    with _template_path("domains", "users", "router.py") as file_path:
        content = file_path.read_text()
        assert "Depends" in content


def test_service_uses_repository_or_session() -> None:
    """Service should use repository or session."""
    with _template_path("domains", "users", "service.py") as file_path:
        content = file_path.read_text()
        assert "repository" in content.lower() or "session" in content.lower()


def test_repository_uses_session() -> None:
    """Repository should use SQLAlchemy session."""
    with _template_path("domains", "users", "repository.py") as file_path:
        content = file_path.read_text()
        assert "session" in content.lower() or "AsyncSession" in content


# ============================================================================
# Feature 12: Documentation Templates Tests
# ============================================================================


def test_api_doc_template_exists() -> None:
    """API documentation template should exist."""
    with _template_path("docs", "templates", "API_DOCUMENTATION_TEMPLATE.md") as file_path:
        content = file_path.read_text()
        assert "endpoint" in content.lower() or "api" in content.lower()
        assert "GET" in content or "POST" in content


def test_operations_playbook_template_exists() -> None:
    """Operations playbook template should exist."""
    with _template_path("docs", "templates", "OPERATIONS_PLAYBOOK_TEMPLATE.md") as file_path:
        content = file_path.read_text()
        assert "deploy" in content.lower()
        assert "rollback" in content.lower() or "recovery" in content.lower()


def test_debug_report_template_exists() -> None:
    """Debug report template should exist."""
    with _template_path("docs", "templates", "DEBUG_REPORT_TEMPLATE.md") as file_path:
        content = file_path.read_text()
        assert "timeline" in content.lower() or "investigation" in content.lower()
        assert "root cause" in content.lower() or "resolution" in content.lower()
