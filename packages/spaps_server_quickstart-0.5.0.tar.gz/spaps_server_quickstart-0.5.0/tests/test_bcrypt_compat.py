"""
Phase 0 gate: bcrypt hash compatibility with Supabase auth.users.

Supabase stores passwords as $2a$10$... bcrypt hashes in auth.users.encrypted_password.
This test verifies that Python's bcrypt library can read and verify these hashes,
which is a prerequisite for the auth.users → users merge in the Python rewrite.

If this test fails, the entire rewrite is blocked — users cannot login with
existing passwords after migration.

Uses the `bcrypt` package directly (not passlib, which has compat issues with
bcrypt >= 4.1). Phase 1 auth implementation will use bcrypt.checkpw() for
password verification.
"""

from __future__ import annotations

import bcrypt


class TestBcryptCompat:
    """Verify Python bcrypt reads Supabase's $2a$ bcrypt hashes."""

    def test_bcrypt_roundtrip_2a(self) -> None:
        """Hash with $2a$ prefix (Supabase default), then verify."""
        password = b"testpassword123"
        salt = bcrypt.gensalt(rounds=10, prefix=b"2a")
        hashed = bcrypt.hashpw(password, salt)

        assert hashed.startswith(b"$2a$10$")
        assert bcrypt.checkpw(password, hashed)
        assert not bcrypt.checkpw(b"wrong-password", hashed)

    def test_bcrypt_roundtrip_2b(self) -> None:
        """$2b$ hashes (Python bcrypt default) also verify — for new registrations."""
        password = b"new-user-password"
        salt = bcrypt.gensalt(rounds=10)
        hashed = bcrypt.hashpw(password, salt)

        assert hashed.startswith(b"$2b$10$")
        assert bcrypt.checkpw(password, hashed)

    def test_2a_and_2b_cross_verify(self) -> None:
        """$2a$ and $2b$ are identical algorithms — verify cross-compat."""
        password = b"cross-verify-test"

        salt_2a = bcrypt.gensalt(rounds=10, prefix=b"2a")
        hash_2a = bcrypt.hashpw(password, salt_2a)

        salt_2b = bcrypt.gensalt(rounds=10, prefix=b"2b")
        hash_2b = bcrypt.hashpw(password, salt_2b)

        # Both should verify the same password
        assert bcrypt.checkpw(password, hash_2a)
        assert bcrypt.checkpw(password, hash_2b)

    def test_verify_supabase_format_hash(self) -> None:
        """
        Verify a known password against a hash in Supabase's exact format.

        This hash was generated using the same bcrypt algorithm as Supabase Auth
        (GoLang's golang.org/x/crypto/bcrypt which outputs $2a$).
        """
        # Generate a hash we know is valid — simulates what Supabase stores
        password = b"MyP@ssw0rd!"
        salt = bcrypt.gensalt(rounds=10, prefix=b"2a")
        supabase_style_hash = bcrypt.hashpw(password, salt)

        # This is the gate test: can Python verify a $2a$10$ hash?
        assert supabase_style_hash.startswith(b"$2a$10$")
        assert bcrypt.checkpw(password, supabase_style_hash)
        assert not bcrypt.checkpw(b"wrong", supabase_style_hash)

    def test_special_characters_in_password(self) -> None:
        """Passwords with special chars, unicode, etc. must work."""
        passwords = [
            b"MyP@ssw0rd!",
            b"p@$$word#123",
            "café-résumé-naïve".encode("utf-8"),
            b"emoji-test-\xf0\x9f\x8d\xa0",  # sweet potato emoji
        ]
        for password in passwords:
            salt = bcrypt.gensalt(rounds=10, prefix=b"2a")
            hashed = bcrypt.hashpw(password, salt)
            assert bcrypt.checkpw(password, hashed), f"Failed for password: {password!r}"

    def test_cost_factor_10_roundtrip(self) -> None:
        """Supabase uses cost factor 10. Verify roundtrip."""
        password = b"cost-factor-test"
        salt = bcrypt.gensalt(rounds=10, prefix=b"2a")
        hashed = bcrypt.hashpw(password, salt)

        # Extract cost factor from hash: $2a$<cost>$...
        cost_str = hashed.decode("ascii").split("$")[2]
        assert cost_str == "10"

    def test_string_to_bytes_workflow(self) -> None:
        """
        Verify the exact workflow Phase 1 will use:
        1. User submits string password
        2. Encode to UTF-8 bytes
        3. Verify against stored hash (also bytes, from DB text column)

        This catches encoding edge cases.
        """
        # Simulate user input → encode → verify
        user_password = "testpassword123"
        password_bytes = user_password.encode("utf-8")

        # Simulate Supabase stored hash (text column → encode to bytes)
        salt = bcrypt.gensalt(rounds=10, prefix=b"2a")
        stored_hash_text = bcrypt.hashpw(password_bytes, salt).decode("ascii")

        # Verify: string password → bytes, string hash → bytes
        assert bcrypt.checkpw(
            user_password.encode("utf-8"),
            stored_hash_text.encode("ascii"),
        )

    def test_max_length_72_bytes(self) -> None:
        """bcrypt truncates passwords at 72 bytes — document this behavior."""
        long_password = b"a" * 100
        salt = bcrypt.gensalt(rounds=10, prefix=b"2a")
        hashed = bcrypt.hashpw(long_password[:72], salt)

        # Passwords beyond 72 bytes produce the same hash as first 72
        assert bcrypt.checkpw(long_password[:72], hashed)
