"""Tests for domains/sessions/nonce_service.py"""

from __future__ import annotations

import pytest
from unittest.mock import AsyncMock, MagicMock

from spaps_server_quickstart.domains.sessions.nonce_service import (
    generate_nonce,
    create_auth_message,
    store_nonce,
    validate_nonce,
    cleanup_expired_nonces,
)
from spaps_server_quickstart.domains.errors import InvalidNonceError


def test_generate_nonce_returns_64_char_hex():
    """Test nonce generation produces 64-character hex string."""
    nonce = generate_nonce()
    assert len(nonce) == 64
    assert all(c in "0123456789abcdef" for c in nonce)

    # Each call should produce different nonce
    nonce2 = generate_nonce()
    assert nonce != nonce2


def test_create_auth_message_format():
    """Test auth message format for wallet signing."""
    wallet = "0xabc123def456"
    nonce = "abc123"

    message = create_auth_message(wallet, nonce)

    assert "SPAPS" in message
    assert wallet in message
    assert nonce in message
    assert "sweetpotato.dev" in message
    assert "Nonce:" in message
    assert "not trigger a blockchain transaction" in message


def test_create_auth_message_custom_params():
    """Test auth message with custom app name and domain."""
    wallet = "0xtest"
    nonce = "nonce123"

    message = create_auth_message(
        wallet,
        nonce,
        app_name="MyApp",
        domain="example.com"
    )

    assert "MyApp" in message
    assert "example.com" in message
    assert wallet in message
    assert nonce in message


@pytest.mark.asyncio()
async def test_store_nonce_creates_record():
    """Test storing a nonce in the database."""
    session = AsyncMock()
    session.add = MagicMock()
    session.flush = AsyncMock()

    wallet = "0xtest"
    nonce = "test-nonce-123"

    result = await store_nonce(session, wallet, nonce, expires_in=300)

    session.add.assert_called_once()
    session.flush.assert_awaited_once()

    # Verify the created record
    added_record = session.add.call_args[0][0]
    assert added_record.wallet_address == wallet
    assert added_record.nonce == nonce
    assert added_record.used is False


@pytest.mark.asyncio()
async def test_validate_nonce_success():
    """Test successful nonce validation and consumption."""
    session = AsyncMock()

    wallet = "0xtest"
    nonce = "valid-nonce"

    # Mock successful update (returning row ID indicates update happened)
    mock_result = MagicMock()
    mock_result.first.return_value = (1,)  # Simulates RETURNING id
    session.execute.return_value = mock_result

    result = await validate_nonce(session, wallet, nonce)

    assert result is True
    session.execute.assert_awaited_once()


@pytest.mark.asyncio()
async def test_validate_nonce_fails_when_not_found():
    """Test nonce validation fails when nonce doesn't exist."""
    session = AsyncMock()

    wallet = "0xtest"
    nonce = "nonexistent"

    # Mock no rows updated
    mock_result = MagicMock()
    mock_result.first.return_value = None
    session.execute.return_value = mock_result

    with pytest.raises(InvalidNonceError):
        await validate_nonce(session, wallet, nonce)


@pytest.mark.asyncio()
async def test_validate_nonce_fails_when_already_used():
    """Test nonce validation fails when nonce already consumed."""
    session = AsyncMock()

    wallet = "0xtest"
    nonce = "used-nonce"

    # Mock no rows updated (because used=True filter didn't match)
    mock_result = MagicMock()
    mock_result.first.return_value = None
    session.execute.return_value = mock_result

    with pytest.raises(InvalidNonceError):
        await validate_nonce(session, wallet, nonce)


@pytest.mark.asyncio()
async def test_validate_nonce_fails_when_expired():
    """Test nonce validation fails when nonce is expired."""
    session = AsyncMock()

    wallet = "0xtest"
    nonce = "expired-nonce"

    # Mock no rows updated (because expires_at filter didn't match)
    mock_result = MagicMock()
    mock_result.first.return_value = None
    session.execute.return_value = mock_result

    with pytest.raises(InvalidNonceError):
        await validate_nonce(session, wallet, nonce)


@pytest.mark.asyncio()
async def test_cleanup_expired_nonces_deletes_old_entries():
    """Test cleanup removes expired and used nonces."""
    session = AsyncMock()

    # Mock delete result
    mock_result = MagicMock()
    mock_result.rowcount = 15  # Simulates 15 rows deleted
    session.execute.return_value = mock_result

    deleted = await cleanup_expired_nonces(session)

    assert deleted == 15
    session.execute.assert_awaited_once()


@pytest.mark.asyncio()
async def test_cleanup_expired_nonces_returns_zero_when_none_deleted():
    """Test cleanup returns 0 when nothing to delete."""
    session = AsyncMock()

    # Mock delete result with no rows
    mock_result = MagicMock()
    mock_result.rowcount = 0
    session.execute.return_value = mock_result

    deleted = await cleanup_expired_nonces(session)

    assert deleted == 0
