from __future__ import annotations

import asyncio
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest
from fastapi import Depends, FastAPI
from fastapi.testclient import TestClient

from spaps_server_quickstart.db import session as session_module
from spaps_server_quickstart.db.session import (
    DatabaseResources,
    create_async_sessionmaker,
    initialize_database_helpers,
    session_dependency_factory,
)
from spaps_server_quickstart.settings import BaseServiceSettings


class DevSettings(BaseServiceSettings):
    database_url: str = "postgresql+asyncpg://user:pass@localhost:5432/dev"


class ProdSettings(BaseServiceSettings):
    env: str = "prod"
    database_url: str = "postgresql+asyncpg://user:pass@localhost:5432/prod"


class DummySession:
    """Minimal session mock supporting the auto-commit contract."""

    committed: bool = False

    async def commit(self) -> None:
        self.committed = True

    def __repr__(self) -> str:
        return "DummySession"


class DummySessionContext:
    def __init__(self) -> None:
        self.session = DummySession()

    async def __aenter__(self) -> DummySession:
        return self.session

    async def __aexit__(self, exc_type, exc, tb) -> None:
        return None


class DummySessionFactory:
    def __init__(self) -> None:
        self.calls = 0

    def __call__(self) -> DummySessionContext:
        self.calls += 1
        return DummySessionContext()


def test_database_resources_dev_uses_queue_pool(monkeypatch) -> None:
    """Dev environment now uses QueuePool (same as prod) to prevent connection exhaustion."""
    captured: dict[str, Any] = {}

    def fake_create_async_engine(url: str, **kwargs: Any) -> str:
        captured["url"] = url
        captured["kwargs"] = kwargs
        return "engine"

    def fake_sessionmaker(engine: Any, expire_on_commit: bool) -> DummySessionFactory:
        captured["engine"] = engine
        captured["expire_on_commit"] = expire_on_commit
        return DummySessionFactory()

    monkeypatch.setattr(session_module, "create_async_engine", fake_create_async_engine)
    monkeypatch.setattr(session_module, "async_sessionmaker", fake_sessionmaker)

    resources = DatabaseResources(DevSettings())

    factory = resources.get_session_factory()
    assert captured["url"].endswith("/dev")
    # All environments now use QueuePool with configured settings
    kwargs = captured["kwargs"]
    assert "pool_size" in kwargs
    assert "max_overflow" in kwargs
    assert "pool_timeout" in kwargs
    assert "pool_pre_ping" in kwargs
    assert "poolclass" not in kwargs  # No explicit poolclass = default QueuePool

    async def consume_session() -> None:
        async for session in resources.session_dependency():
            assert isinstance(session, DummySession)

    asyncio.run(consume_session())
    assert isinstance(factory, DummySessionFactory)


def test_database_resources_prod_uses_pool(monkeypatch) -> None:
    """Prod environment uses QueuePool with all pool settings including pre_ping."""
    captured: dict[str, Any] = {}

    def fake_create_async_engine(url: str, **kwargs: Any) -> str:
        captured["url"] = url
        captured["kwargs"] = kwargs
        return "engine"

    def fake_sessionmaker(engine: Any, expire_on_commit: bool) -> DummySessionFactory:
        captured["engine"] = engine
        captured["expire_on_commit"] = expire_on_commit
        return DummySessionFactory()

    monkeypatch.setattr(session_module, "create_async_engine", fake_create_async_engine)
    monkeypatch.setattr(session_module, "async_sessionmaker", fake_sessionmaker)

    resources = DatabaseResources(ProdSettings())
    resources.get_session_factory()

    kwargs = captured["kwargs"]
    assert "pool_size" in kwargs
    assert "max_overflow" in kwargs
    assert "pool_timeout" in kwargs
    assert "pool_pre_ping" in kwargs
    assert kwargs["pool_pre_ping"] is True  # pre_ping enabled by default
    assert "poolclass" not in kwargs


def test_session_dependency_factory_wraps_session(monkeypatch) -> None:
    dummy_factory = DummySessionFactory()
    dependency = session_dependency_factory(dummy_factory)  # type: ignore[arg-type]

    async def consume_dependency() -> None:
        async for session in dependency():
            assert isinstance(session, DummySession)

    asyncio.run(consume_dependency())
    assert dummy_factory.calls == 1


def test_create_async_sessionmaker_delegates(monkeypatch) -> None:
    created = {}

    def fake_init(self, settings, engine_overrides=None):
        created["settings"] = settings
        created["engine_overrides"] = engine_overrides

    monkeypatch.setattr(DatabaseResources, "__init__", fake_init)
    monkeypatch.setattr(
        DatabaseResources,
        "get_session_factory",
        lambda self: "factory",  # type: ignore[no-untyped-def]
    )

    factory = create_async_sessionmaker(DevSettings(), echo=True)
    assert factory == "factory"
    assert created["engine_overrides"] == {"echo": True}


def test_database_resources_dispose_resets_engine(monkeypatch) -> None:
    engines: list[Any] = []

    class DummyEngine:
        def __init__(self) -> None:
            self.disposed = False

        async def dispose(self) -> None:
            self.disposed = True

    def fake_create_async_engine(url: str, **kwargs: Any) -> DummyEngine:
        engine = DummyEngine()
        engines.append(engine)
        return engine

    def fake_sessionmaker(engine: Any, expire_on_commit: bool) -> DummySessionFactory:
        return DummySessionFactory()

    monkeypatch.setattr(session_module, "create_async_engine", fake_create_async_engine)
    monkeypatch.setattr(session_module, "async_sessionmaker", fake_sessionmaker)

    resources = DatabaseResources(DevSettings())
    resources.get_session_factory()

    assert len(engines) == 1

    asyncio.run(resources.dispose())
    assert engines[0].disposed is True

    resources.get_engine()
    assert len(engines) == 2


def test_initialize_database_helpers_supports_dependency_overrides(monkeypatch) -> None:
    helpers = initialize_database_helpers(DevSettings)
    override_session = object()

    def fail_create_async_engine(*args: Any, **kwargs: Any) -> None:
        raise AssertionError("dependency override should skip engine creation")

    def fail_sessionmaker(*args: Any, **kwargs: Any) -> None:
        raise AssertionError("dependency override should skip session factory creation")

    monkeypatch.setattr(session_module, "create_async_engine", fail_create_async_engine)
    monkeypatch.setattr(session_module, "async_sessionmaker", fail_sessionmaker)

    app = FastAPI()

    @app.get("/probe")
    async def probe(session=Depends(helpers.get_db_session)):
        return {"is_override": session is override_session}

    async def override():
        yield override_session

    app.dependency_overrides[helpers.get_db_session] = override

    with TestClient(app) as client:
        response = client.get("/probe")

    assert response.status_code == 200
    assert response.json() == {"is_override": True}


def test_initialize_database_helpers_preserves_lazy_singletons(monkeypatch) -> None:
    helpers = initialize_database_helpers(DevSettings)
    created: dict[str, int] = {"engines": 0, "factories": 0}
    engine = object()
    factory = DummySessionFactory()

    def fake_create_async_engine(url: str, **kwargs: Any) -> object:
        del url, kwargs
        created["engines"] += 1
        return engine

    def fake_sessionmaker(created_engine: Any, expire_on_commit: bool) -> DummySessionFactory:
        assert created_engine is engine
        assert expire_on_commit is False
        created["factories"] += 1
        return factory

    monkeypatch.setattr(session_module, "create_async_engine", fake_create_async_engine)
    monkeypatch.setattr(session_module, "async_sessionmaker", fake_sessionmaker)

    assert helpers.get_engine() is engine
    assert helpers.get_engine() is engine
    assert helpers.get_session_factory() is factory
    assert helpers.get_session_factory() is factory
    assert created == {"engines": 1, "factories": 1}


@pytest.mark.asyncio
async def test_initialize_database_helpers_get_db_session_skips_commit_on_handler_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    mock_session = AsyncMock()
    mock_factory = MagicMock()
    mock_ctx = AsyncMock()
    mock_ctx.__aenter__.return_value = mock_session
    mock_ctx.__aexit__.return_value = False
    mock_factory.return_value = mock_ctx

    helpers = initialize_database_helpers(DevSettings)

    monkeypatch.setattr(session_module, "create_async_engine", lambda *args, **kwargs: object())
    monkeypatch.setattr(session_module, "async_sessionmaker", lambda engine, expire_on_commit: mock_factory)

    gen = helpers.get_db_session()
    session = await gen.__anext__()

    assert session is mock_session

    with pytest.raises(RuntimeError, match="handler error"):
        await gen.athrow(RuntimeError("handler error"))

    mock_session.commit.assert_not_called()


@pytest.mark.asyncio
async def test_initialize_database_helpers_dispose_engine_before_first_initialization(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    helpers = initialize_database_helpers(DevSettings)
    created: dict[str, int] = {"engines": 0, "factories": 0}
    engine = object()
    factory = DummySessionFactory()

    def fake_create_async_engine(url: str, **kwargs: Any) -> object:
        del url, kwargs
        created["engines"] += 1
        return engine

    def fake_sessionmaker(created_engine: Any, expire_on_commit: bool) -> DummySessionFactory:
        assert created_engine is engine
        assert expire_on_commit is False
        created["factories"] += 1
        return factory

    monkeypatch.setattr(session_module, "create_async_engine", fake_create_async_engine)
    monkeypatch.setattr(session_module, "async_sessionmaker", fake_sessionmaker)

    await helpers.dispose_engine()

    assert helpers.get_session_factory() is factory
    assert created == {"engines": 1, "factories": 1}
