"""
Contract tests for BaseServiceSettings and settings utilities.

These tests encode what consumer_server, cfo, and sweet-potato-chat depend on.
Breaking any of these tests means a consumer will break.
"""
from __future__ import annotations

import inspect

from spaps_server_quickstart.settings import BaseServiceSettings, create_settings_loader, get_settings


class TestBaseServiceSettingsFields:
    """Consumers depend on these fields existing with compatible types."""

    def test_database_url_field(self) -> None:
        settings = BaseServiceSettings()
        assert isinstance(settings.database_url, str)

    def test_database_pool_fields(self) -> None:
        settings = BaseServiceSettings()
        assert isinstance(settings.database_pool_size, int)
        assert isinstance(settings.database_max_overflow, int)
        assert isinstance(settings.database_pool_timeout, int)
        assert isinstance(settings.database_pool_pre_ping, bool)
        assert isinstance(settings.database_echo, bool)

    def test_redis_url_field(self) -> None:
        settings = BaseServiceSettings()
        assert isinstance(settings.redis_url, str)

    def test_app_identity_fields(self) -> None:
        settings = BaseServiceSettings()
        assert isinstance(settings.app_name, str)
        assert isinstance(settings.version, str)
        assert isinstance(settings.env, str)

    def test_resolved_service_slug(self) -> None:
        settings = BaseServiceSettings()
        assert isinstance(settings.resolved_service_slug, str)

    def test_celery_app_name_property(self) -> None:
        settings = BaseServiceSettings()
        assert isinstance(settings.celery_app_name, str)

    def test_celery_broker_and_backend(self) -> None:
        settings = BaseServiceSettings()
        assert isinstance(settings.resolved_celery_broker_url, str)
        assert isinstance(settings.resolved_celery_result_backend, str)

    def test_sync_database_url_property(self) -> None:
        settings = BaseServiceSettings()
        url = settings.sync_database_url
        assert isinstance(url, str)
        assert "asyncpg" not in url

    def test_spaps_auth_fields(self) -> None:
        settings = BaseServiceSettings()
        assert isinstance(settings.spaps_auth_enabled, bool)
        assert isinstance(settings.spaps_api_url, str)
        assert isinstance(settings.spaps_request_timeout, float)

    def test_cors_fields(self) -> None:
        settings = BaseServiceSettings()
        assert isinstance(settings.cors_allow_credentials, bool)
        assert isinstance(settings.cors_max_age, int)

    def test_logger_namespace(self) -> None:
        settings = BaseServiceSettings()
        assert isinstance(settings.logger_namespace, str)

    def test_is_local_development_property(self) -> None:
        settings = BaseServiceSettings()
        assert isinstance(settings.is_local_development, bool)


class TestCreateSettingsLoader:
    """Consumers use create_settings_loader to create lru_cache-backed loaders."""

    def test_returns_callable(self) -> None:
        loader = create_settings_loader(BaseServiceSettings)
        assert callable(loader)

    def test_loader_returns_settings_instance(self) -> None:
        loader = create_settings_loader(BaseServiceSettings)
        settings = loader()
        assert isinstance(settings, BaseServiceSettings)

    def test_loader_returns_same_instance_on_repeat(self) -> None:
        loader = create_settings_loader(BaseServiceSettings)
        first = loader()
        second = loader()
        assert first is second

    def test_accepts_subclass(self) -> None:
        class CustomSettings(BaseServiceSettings):
            custom_field: str = "test"

        loader = create_settings_loader(CustomSettings)
        settings = loader()
        assert isinstance(settings, CustomSettings)
        assert settings.custom_field == "test"


class TestGetSettings:
    """get_settings() is used as a zero-arg fallback."""

    def test_returns_base_settings(self) -> None:
        settings = get_settings()
        assert isinstance(settings, BaseServiceSettings)

    def test_accepts_no_arguments(self) -> None:
        sig = inspect.signature(get_settings)
        assert len(sig.parameters) == 0


class TestSubclassability:
    """consumer_server and cfo both subclass BaseServiceSettings."""

    def test_subclass_inherits_all_fields(self) -> None:
        class ServiceSettings(BaseServiceSettings):
            custom_api_key: str = "test-key"

        settings = ServiceSettings()
        assert settings.custom_api_key == "test-key"
        assert hasattr(settings, "database_url")
        assert hasattr(settings, "redis_url")
        assert hasattr(settings, "celery_app_name")

    def test_subclass_can_override_defaults(self) -> None:
        class ServiceSettings(BaseServiceSettings):
            app_name: str = "My Service"
            database_pool_size: int = 5

        settings = ServiceSettings()
        assert settings.app_name == "My Service"
        assert settings.database_pool_size == 5
