"""
Contract tests for the application factory.

These tests encode what consumers depend on from create_app.
"""
from __future__ import annotations

import inspect

from fastapi import APIRouter, FastAPI

from spaps_server_quickstart.app_factory import create_app
from spaps_server_quickstart.settings import BaseServiceSettings


class TestCreateAppSignature:
    """Consumers call create_app with these keyword arguments."""

    def test_accepts_settings_loader_and_router(self) -> None:
        settings = BaseServiceSettings(spaps_auth_enabled=False)
        router = APIRouter()
        app = create_app(
            settings_loader=lambda: settings,
            api_router=router,
            run_startup_checks=False,
        )
        assert isinstance(app, FastAPI)

    def test_accepts_additional_middlewares(self) -> None:
        sig = inspect.signature(create_app)
        assert "additional_middlewares" in sig.parameters

    def test_accepts_enable_request_logging(self) -> None:
        sig = inspect.signature(create_app)
        assert "enable_request_logging" in sig.parameters

    def test_accepts_request_logger_name(self) -> None:
        sig = inspect.signature(create_app)
        assert "request_logger_name" in sig.parameters

    def test_accepts_enable_spaps_auth(self) -> None:
        sig = inspect.signature(create_app)
        assert "enable_spaps_auth" in sig.parameters

    def test_accepts_auth_exempt_paths(self) -> None:
        sig = inspect.signature(create_app)
        assert "auth_exempt_paths" in sig.parameters

    def test_accepts_enable_cors(self) -> None:
        sig = inspect.signature(create_app)
        assert "enable_cors" in sig.parameters

    def test_returns_fastapi_instance(self) -> None:
        settings = BaseServiceSettings(spaps_auth_enabled=False)
        app = create_app(
            settings_loader=lambda: settings,
            api_router=APIRouter(),
            run_startup_checks=False,
        )
        assert isinstance(app, FastAPI)

    def test_includes_provided_router(self) -> None:
        settings = BaseServiceSettings(spaps_auth_enabled=False)
        router = APIRouter()

        @router.get("/test-route")
        async def test_endpoint():
            return {"ok": True}

        app = create_app(
            settings_loader=lambda: settings,
            api_router=router,
            run_startup_checks=False,
        )
        routes = [r.path for r in app.routes]
        assert "/test-route" in routes

    def test_all_params_are_keyword_only(self) -> None:
        sig = inspect.signature(create_app)
        for name, param in sig.parameters.items():
            assert param.kind == inspect.Parameter.KEYWORD_ONLY, (
                f"create_app param '{name}' should be keyword-only"
            )
