"""
Contract tests for HealthRouterFactory and health endpoint JSON shape.

CRITICAL: Deploy scripts parse the health endpoint response. The JSON shape
is a production contract. These tests are the safety net for A2 changes.
"""
from __future__ import annotations

from typing import Any, AsyncIterator

import pytest

from fastapi import FastAPI
from fastapi.testclient import TestClient

from spaps_server_quickstart.api.health import HealthRouterFactory
from spaps_server_quickstart.schemas.health import HealthResponse
from spaps_server_quickstart.settings import BaseServiceSettings


class _TestSettings(BaseServiceSettings):
    app_name: str = "Contract Test Service"
    service_slug: str = "contract-test"
    database_url: str = "postgresql+asyncpg://user:pass@localhost:5432/test"


class _SuccessSession:
    async def execute(self, *_: Any, **__: Any) -> None:
        return None


async def _session_dep() -> AsyncIterator[_SuccessSession]:
    yield _SuccessSession()


class TestHealthRouterFactoryInterface:
    """Consumers construct HealthRouterFactory with these params."""

    def test_constructor_accepts_settings_loader(self) -> None:
        factory = HealthRouterFactory(settings_loader=lambda: _TestSettings())
        assert factory is not None

    def test_constructor_accepts_session_dependency(self) -> None:
        factory = HealthRouterFactory(
            settings_loader=lambda: _TestSettings(),
            session_dependency=_session_dep,
        )
        assert factory is not None

    def test_constructor_accepts_extra_metrics_provider(self) -> None:
        def metrics(settings: BaseServiceSettings, session: Any) -> dict:
            return {}

        factory = HealthRouterFactory(
            settings_loader=lambda: _TestSettings(),
            extra_metrics_provider=metrics,
        )
        assert factory is not None

    def test_constructor_accepts_include_flags(self) -> None:
        factory = HealthRouterFactory(
            settings_loader=lambda: _TestSettings(),
            include_uptime=False,
            include_version=False,
            include_redis=False,
            include_started_at=False,
            include_migrations=False,
        )
        assert factory is not None

    def test_create_router_returns_api_router(self) -> None:
        from fastapi import APIRouter

        factory = HealthRouterFactory(settings_loader=lambda: _TestSettings())
        router = factory.create_router()
        assert isinstance(router, APIRouter)


class TestHealthResponseModel:
    """HealthResponse fields that consumers read."""

    def test_has_status_field(self) -> None:
        resp = HealthResponse(status="ok", service="test", version="1.0")
        assert resp.status == "ok"

    def test_has_service_field(self) -> None:
        resp = HealthResponse(status="ok", service="test", version="1.0")
        assert resp.service == "test"

    def test_has_version_field(self) -> None:
        resp = HealthResponse(status="ok", service="test", version="1.0")
        assert resp.version == "1.0"

    def test_has_database_ready_field(self) -> None:
        resp = HealthResponse(status="ok", service="test", version="1.0", database_ready=True)
        assert resp.database_ready is True

    def test_has_started_at_field(self) -> None:
        resp = HealthResponse(status="ok", service="test", version="1.0", started_at="2026-02-08T12:00:00+00:00")
        assert resp.started_at == "2026-02-08T12:00:00+00:00"

    def test_has_started_at_est_field(self) -> None:
        resp = HealthResponse(status="ok", service="test", version="1.0", started_at_est="2026-02-08 07:00:00 AM EST")
        assert resp.started_at_est == "2026-02-08 07:00:00 AM EST"

    def test_started_at_optional(self) -> None:
        resp = HealthResponse(status="ok", service="test", version="1.0")
        assert resp.started_at is None
        assert resp.started_at_est is None

    def test_has_details_field(self) -> None:
        resp = HealthResponse(status="ok", service="test", version="1.0", details={"key": "val"})
        assert resp.details == {"key": "val"}


class TestHealthEndpointShape:
    """
    The actual JSON shape returned by the health endpoint.

    CURRENT SHAPE (pre-A2). These tests document what exists today.
    After A2, some of these will be updated to reflect the new shape.
    """

    def _make_client(self, **factory_kwargs: Any) -> TestClient:
        factory = HealthRouterFactory(
            settings_loader=lambda: _TestSettings(),
            **factory_kwargs,
        )
        app = FastAPI()
        app.include_router(factory.create_router())
        return TestClient(app)

    def test_health_returns_200(self) -> None:
        client = self._make_client(include_redis=False)
        response = client.get("/health")
        assert response.status_code == 200

    def test_health_has_status(self) -> None:
        client = self._make_client(include_redis=False)
        data = client.get("/health").json()
        assert "status" in data
        assert data["status"] in ("ok", "degraded")

    def test_health_has_service(self) -> None:
        client = self._make_client(include_redis=False)
        data = client.get("/health").json()
        assert "service" in data
        assert data["service"] == "contract-test"

    def test_health_has_version(self) -> None:
        client = self._make_client(include_redis=False)
        data = client.get("/health").json()
        assert "version" in data

    def test_health_has_database_ready(self) -> None:
        client = self._make_client(include_redis=False)
        data = client.get("/health").json()
        assert "database_ready" in data

    def test_health_has_details_dict(self) -> None:
        client = self._make_client(include_redis=False)
        data = client.get("/health").json()
        assert "details" in data
        assert isinstance(data["details"], dict)

    def test_health_uptime_in_details(self) -> None:
        client = self._make_client(include_uptime=True, include_redis=False)
        data = client.get("/health").json()
        assert "uptime" in data["details"]
        uptime = data["details"]["uptime"]
        assert "display" in uptime
        assert "seconds" in uptime

    def test_health_version_info_in_details(self) -> None:
        client = self._make_client(include_version=True, include_redis=False)
        data = client.get("/health").json()
        assert "version" in data["details"]
        version_info = data["details"]["version"]
        assert "commit" in version_info

    def test_version_field_uses_git_commit_sha(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Deploy scripts parse response['version'] as GIT_COMMIT_SHA."""
        monkeypatch.setenv("GIT_COMMIT_SHA", "abc1234def5678")
        client = self._make_client(include_redis=False)
        data = client.get("/health").json()
        assert data["version"] == "abc1234def5678"

    def test_version_falls_back_to_settings_version(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """When GIT_COMMIT_SHA not set, falls back to settings.version."""
        monkeypatch.delenv("GIT_COMMIT_SHA", raising=False)
        client = self._make_client(include_redis=False)
        data = client.get("/health").json()
        assert data["version"] == "0.1.0"  # _TestSettings inherits BaseServiceSettings default

    def test_health_has_top_level_started_at(self) -> None:
        """Deploy scripts parse response['started_at'] for deploy timing."""
        client = self._make_client(include_redis=False)
        data = client.get("/health").json()
        assert "started_at" in data
        assert data["started_at"] is not None

    def test_health_has_top_level_started_at_est(self) -> None:
        """Human-readable EST timestamp for quick deploy verification."""
        client = self._make_client(include_redis=False)
        data = client.get("/health").json()
        assert "started_at_est" in data
        assert data["started_at_est"] is not None

    def test_health_with_database_session_ok(self) -> None:
        client = self._make_client(
            session_dependency=_session_dep,
            include_redis=False,
        )
        data = client.get("/health").json()
        assert data["status"] == "ok"
        assert data["database_ready"] is True

    def test_health_with_extra_metrics(self) -> None:
        def my_metrics(settings: BaseServiceSettings, session: Any) -> dict:
            return {"custom_key": 42}

        client = self._make_client(
            extra_metrics_provider=my_metrics,
            include_redis=False,
        )
        data = client.get("/health").json()
        assert data["details"]["custom_key"] == 42
