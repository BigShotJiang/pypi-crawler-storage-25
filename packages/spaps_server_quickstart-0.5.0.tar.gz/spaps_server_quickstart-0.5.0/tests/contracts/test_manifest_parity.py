"""
Contract test for manifest.json parity.

This test verifies that all endpoints documented in docs/manifest.json
are registered in the FastAPI application. This is a critical safety check
to ensure the Python rewrite maintains full API parity with the original
Node.js implementation.

RUNNING THE TEST:
    # Without database (fastest - tests only route registration):
    PYTEST_DATABASE_URL=sqlite:///dev/null pytest tests/contracts/test_manifest_parity.py

    # With full test database (slower, but tests work with real DB):
    pytest tests/contracts/test_manifest_parity.py

FAILURE MODES:
- Missing endpoint: A route in manifest.json is not registered in FastAPI
- Unexpected endpoint: A route in FastAPI is not documented in manifest.json
- Path parameter mismatch: Express-style `:param` vs FastAPI-style `{param}`

MAINTENANCE:
- When adding new endpoints, update BOTH the FastAPI router AND manifest.json
- When changing paths, update BOTH locations
- Run this test after major refactors to catch registration errors

PATH NORMALIZATION:
- Express uses `:userId`, FastAPI uses `{user_id}`
- The test normalizes both to `{user_id}` (snake_case)
- Trailing slashes are removed for comparison
- camelCase is converted to snake_case for parameters
"""
from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from spaps_server_quickstart.spaps_app import create_spaps_app


def _find_manifest_path() -> Path:
    """
    Locate docs/manifest.json relative to this test file.

    Test structure:
      sweet-potato/
        docs/manifest.json
        packages/python-server-quickstart/tests/contracts/test_manifest_parity.py

    Navigate up from test file to repo root.
    """
    test_file = Path(__file__)
    # Up to tests/, then tests/, then package/, then packages/, then repo root
    repo_root = test_file.parent.parent.parent.parent.parent
    manifest = repo_root / "docs" / "manifest.json"

    if not manifest.exists():
        raise FileNotFoundError(
            f"manifest.json not found at {manifest}. "
            f"Test file: {test_file}, computed repo root: {repo_root}"
        )

    return manifest


def _load_manifest() -> dict[str, Any]:
    """Load and parse docs/manifest.json."""
    manifest_path = _find_manifest_path()
    with manifest_path.open() as f:
        return json.load(f)


def _to_snake_case(name: str) -> str:
    """
    Convert camelCase to snake_case.

    Examples:
        userId -> user_id
        connectionId -> connection_id
        templateKey -> template_key
    """
    # Insert underscore before uppercase letters, then lowercase
    s1 = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', name)
    return re.sub('([a-z0-9])([A-Z])', r'\1_\2', s1).lower()


def _normalize_path(path: str) -> str:
    """
    Normalize path parameter syntax for comparison.

    Express/manifest: /api/users/:userId
    FastAPI: /api/users/{user_id}

    Convert both to a canonical form: /api/users/{user_id} (snake_case)

    This handles:
    1. Syntax differences (:param vs {param})
    2. Naming convention differences (camelCase vs snake_case)
    3. Trailing slash differences (FastAPI may add trailing slashes)
    4. Express wildcard (*) suffix (e.g. :path(*))
    5. FastAPI path converters (e.g. {path:path})
    """
    # Remove trailing slash (unless it's just "/")
    if len(path) > 1 and path.endswith('/'):
        path = path.rstrip('/')

    # Strip Express-style wildcard suffix: :param(*) -> :param
    path = re.sub(r'\(\*\)', '', path)

    # Convert FastAPI path converters BEFORE :param conversion
    # to avoid {path:path} -> {path{path}} mangling
    # e.g. {path:path} -> {path}
    normalized = re.sub(r'\{(\w+):(\w+)\}', r'{\1}', path)

    # Convert :param to {param}
    normalized = re.sub(r':(\w+)', r'{\1}', normalized)

    # Convert all {camelCase} parameters to {snake_case}
    def convert_param(match):
        param_name = match.group(1)
        snake_name = _to_snake_case(param_name)
        return f'{{{snake_name}}}'

    normalized = re.sub(r'\{(\w+)\}', convert_param, normalized)
    return normalized


def _extract_app_routes(app: Any) -> set[tuple[str, str]]:
    """
    Extract all (method, path) tuples from a FastAPI app.

    Returns normalized paths for comparison with manifest.json.
    Excludes auto-generated routes (HEAD, OPTIONS for CORS).
    """
    routes = set()

    for route in app.routes:
        # Only consider routes with methods and paths (APIRoute instances)
        if not hasattr(route, 'methods') or not hasattr(route, 'path'):
            continue

        for method in route.methods:
            method_upper = method.upper()

            # Skip auto-generated methods
            # FastAPI adds HEAD for GET routes and OPTIONS for CORS
            if method_upper in ('HEAD', 'OPTIONS'):
                continue

            path = _normalize_path(route.path)
            routes.add((method_upper, path))

    return routes


def _get_manifest_endpoints(manifest: dict[str, Any]) -> set[tuple[str, str]]:
    """
    Extract all (method, path) tuples from manifest.json.

    Returns normalized paths for comparison with FastAPI routes.
    """
    endpoints = set()

    for endpoint in manifest.get('endpoints', []):
        method = endpoint['method'].upper()
        path = _normalize_path(endpoint['path'])
        endpoints.add((method, path))

    return endpoints


def _is_openapi_endpoint(path: str) -> bool:
    """Check if path is an auto-generated OpenAPI/docs endpoint."""
    openapi_paths = {
        '/openapi.json',
        '/docs',
        '/docs/oauth2-redirect',
        '/redoc',
    }
    return path in openapi_paths


def _format_endpoint(method: str, path: str) -> str:
    """Format an endpoint for display in error messages."""
    return f"{method:6} {path}"


class TestManifestMetadata:
    """Verify manifest.json structure and metadata."""

    def test_manifest_exists(self) -> None:
        """Manifest.json must be present in docs/."""
        manifest_path = _find_manifest_path()
        assert manifest_path.exists()

    def test_manifest_is_valid_json(self) -> None:
        """Manifest must be valid JSON."""
        manifest = _load_manifest()
        assert isinstance(manifest, dict)

    def test_manifest_has_metadata(self) -> None:
        """Manifest must declare total endpoint count."""
        manifest = _load_manifest()
        assert 'metadata' in manifest
        assert 'totalEndpoints' in manifest['metadata']

    def test_manifest_declares_nontrivial_endpoint_count(self) -> None:
        """
        Manifest metadata must declare a realistic endpoint count.

        Keep this as a lower-bound sanity check so route growth does not
        require brittle test edits while still catching obviously broken
        manifests (for example, empty/truncated endpoint lists).
        """
        manifest = _load_manifest()
        total = manifest['metadata']['totalEndpoints']
        assert total >= 100, (
            f"Manifest declares only {total} endpoints. "
            "Expected at least 100 for SPAPS."
        )

    def test_manifest_endpoints_list_exists(self) -> None:
        """Manifest must have an endpoints array."""
        manifest = _load_manifest()
        assert 'endpoints' in manifest
        assert isinstance(manifest['endpoints'], list)

    def test_manifest_endpoints_count_matches_metadata(self) -> None:
        """Actual endpoint count must match declared metadata."""
        manifest = _load_manifest()
        declared_total = manifest['metadata']['totalEndpoints']
        actual_count = len(manifest['endpoints'])

        assert actual_count == declared_total, (
            f"Manifest declares {declared_total} endpoints but contains "
            f"{actual_count} endpoint entries. Update metadata.totalEndpoints."
        )


class TestEndpointParity:
    """Verify all manifest endpoints are registered in FastAPI."""

    @pytest.fixture
    def app(self) -> Any:
        """
        Create the FastAPI test app.

        Mock database operations to avoid requiring database setup.
        The app structure and routing don't need a real database.
        """
        # Skip database initialization during startup checks
        os.environ['SPAPS_ENV'] = 'test'

        # Mock database resources to avoid actual connections
        with patch('spaps_server_quickstart.spaps_app.DatabaseResources') as mock_db:
            mock_db_instance = MagicMock()
            mock_db.return_value = mock_db_instance

            # Create app (will use mocked database)
            app = create_spaps_app()
            return app

    @pytest.fixture
    def manifest(self) -> dict[str, Any]:
        """Load manifest.json."""
        return _load_manifest()

    @pytest.fixture
    def app_routes(self, app: Any) -> set[tuple[str, str]]:
        """Extract all routes from the FastAPI app."""
        return _extract_app_routes(app)

    @pytest.fixture
    def manifest_endpoints(self, manifest: dict[str, Any]) -> set[tuple[str, str]]:
        """Extract all endpoints from manifest.json."""
        return _get_manifest_endpoints(manifest)

    def test_all_manifest_endpoints_registered(
        self,
        manifest_endpoints: set[tuple[str, str]],
        app_routes: set[tuple[str, str]],
    ) -> None:
        """
        Every endpoint in manifest.json must be registered in FastAPI.

        This is the PRIMARY parity check. If this fails, the Python rewrite
        is missing routes from the original Node.js implementation.
        """
        missing = manifest_endpoints - app_routes

        if missing:
            # Format error message with sorted list for readability
            missing_list = sorted(missing, key=lambda x: (x[1], x[0]))
            formatted = '\n  '.join(_format_endpoint(m, p) for m, p in missing_list)

            pytest.fail(
                f"\n{'='*70}\n"
                f"MANIFEST PARITY FAILURE: {len(missing)} endpoints missing from FastAPI\n"
                f"{'='*70}\n\n"
                f"The following endpoints are documented in docs/manifest.json but\n"
                f"are NOT registered in the FastAPI application:\n\n"
                f"  {formatted}\n\n"
                f"ACTION REQUIRED:\n"
                f"1. Check if the endpoint is implemented in a domain router\n"
                f"2. Verify the router is imported and included in spaps_app.py\n"
                f"3. Check for typos in method or path\n"
                f"4. Verify path parameter syntax (FastAPI uses {{param}}, not :param)\n"
                f"\n"
                f"Total missing: {len(missing)}/{len(manifest_endpoints)}\n"
                f"{'='*70}\n"
            )

    def test_no_unexpected_app_endpoints(
        self,
        manifest_endpoints: set[tuple[str, str]],
        app_routes: set[tuple[str, str]],
    ) -> None:
        """
        Flag any FastAPI routes not documented in manifest.json.

        This is a SOFT check. Some undocumented routes are legitimate:
        - OpenAPI endpoints (/openapi.json, /docs, /redoc)
        - Health endpoints may have variations

        But this helps catch accidentally registered routes or refactor issues.
        """
        unexpected = app_routes - manifest_endpoints

        # Filter out known legitimate undocumented routes
        legitimate_undocumented = {
            (m, p) for m, p in unexpected
            if _is_openapi_endpoint(p)
        }

        unexpected_excluding_legitimate = unexpected - legitimate_undocumented

        if unexpected_excluding_legitimate:
            # Format for display
            unexpected_list = sorted(
                unexpected_excluding_legitimate,
                key=lambda x: (x[1], x[0])
            )
            formatted = '\n  '.join(
                _format_endpoint(m, p) for m, p in unexpected_list
            )

            # This is a warning, not a failure. Some undocumented routes
            # might be intentional (debugging endpoints, etc.)
            print(
                f"\n{'='*70}\n"
                f"WARNING: {len(unexpected_excluding_legitimate)} undocumented endpoints in FastAPI\n"
                f"{'='*70}\n\n"
                f"The following endpoints are registered in FastAPI but NOT\n"
                f"documented in docs/manifest.json:\n\n"
                f"  {formatted}\n\n"
                f"ACTION:\n"
                f"If these endpoints are intentional, add them to manifest.json.\n"
                f"If they're accidental or debugging routes, remove them.\n"
                f"\n"
                f"Legitimate undocumented: {len(legitimate_undocumented)} "
                f"(OpenAPI endpoints)\n"
                f"{'='*70}\n"
            )

    def test_endpoint_count_matches_metadata(
        self,
        manifest: dict[str, Any],
        manifest_endpoints: set[tuple[str, str]],
    ) -> None:
        """
        Total unique endpoint count should be close to declared metadata.

        NOTE: The manifest may include a small duplicate variance in
        (method, path) pairs. We test for reasonable closeness rather than
        exact match.
        """
        declared_total = manifest['metadata']['totalEndpoints']
        actual_count = len(manifest_endpoints)

        # Allow for a small discrepancy due to duplicates
        difference = abs(actual_count - declared_total)
        assert difference <= 2, (
            f"Manifest declares {declared_total} total endpoints but "
            f"contains {actual_count} unique entries. Difference of {difference} "
            f"is outside acceptable range (≤2)."
        )

    def test_method_distribution_reasonable(
        self,
        manifest_endpoints: set[tuple[str, str]],
    ) -> None:
        """
        Verify HTTP method distribution looks reasonable.

        This is a sanity check. Based on manifest.json analysis:
        - GET: 74 endpoints (41%)
        - POST: 83 endpoints (47%)
        - PUT: 9 endpoints (5%)
        - DELETE: 12 endpoints (7%)

        If these ratios change dramatically, something might be wrong.
        """
        methods = {}
        for method, _ in manifest_endpoints:
            methods[method] = methods.get(method, 0) + 1

        total = len(manifest_endpoints)

        # Verify we have GET and POST endpoints (most common)
        assert methods.get('GET', 0) > 0, "Expected GET endpoints"
        assert methods.get('POST', 0) > 0, "Expected POST endpoints"

        # Verify reasonable distribution (GET + POST should be majority)
        get_post_count = methods.get('GET', 0) + methods.get('POST', 0)
        get_post_ratio = get_post_count / total if total > 0 else 0

        assert get_post_ratio > 0.7, (
            f"GET+POST endpoints are only {get_post_ratio:.0%} of total. "
            f"Expected >70%. Distribution: {methods}"
        )


class TestOpenAPIGeneration:
    """Verify OpenAPI spec generation works."""

    def _create_test_app(self) -> Any:
        """Create app with mocked database."""
        os.environ['SPAPS_ENV'] = 'test'
        with patch('spaps_server_quickstart.spaps_app.DatabaseResources') as mock_db:
            mock_db_instance = MagicMock()
            mock_db.return_value = mock_db_instance
            return create_spaps_app()

    def test_openapi_spec_generates(self) -> None:
        """FastAPI must generate valid OpenAPI spec."""
        app = self._create_test_app()
        openapi_schema = app.openapi()

        assert openapi_schema is not None
        assert 'openapi' in openapi_schema
        assert 'info' in openapi_schema
        assert 'paths' in openapi_schema

    def test_openapi_has_title(self) -> None:
        """OpenAPI spec must have a title."""
        app = self._create_test_app()
        openapi_schema = app.openapi()

        assert 'title' in openapi_schema['info']
        assert openapi_schema['info']['title'] == "SPAPS - Sweet Potato Auth & Payment Service"

    def test_openapi_has_version(self) -> None:
        """OpenAPI spec must have a version."""
        app = self._create_test_app()
        openapi_schema = app.openapi()

        assert 'version' in openapi_schema['info']
        # Don't assert specific version, just that it exists
        assert openapi_schema['info']['version']

    def test_openapi_paths_not_empty(self) -> None:
        """OpenAPI spec must document endpoints."""
        app = self._create_test_app()
        openapi_schema = app.openapi()

        paths = openapi_schema.get('paths', {})
        assert len(paths) > 0, "OpenAPI spec has no documented paths"

        # Should have at least 100 paths (178 endpoints, some share paths)
        assert len(paths) >= 100, (
            f"Expected at least 100 unique paths in OpenAPI spec, "
            f"found {len(paths)}"
        )


class TestPathParameterNormalization:
    """Verify path parameter normalization works correctly."""

    def test_normalize_single_param_colon_to_braces(self) -> None:
        """Convert :userId to {user_id}."""
        assert _normalize_path('/api/users/:userId') == '/api/users/{user_id}'

    def test_normalize_camel_to_snake(self) -> None:
        """Convert {userId} to {user_id}."""
        assert _normalize_path('/api/users/{userId}') == '/api/users/{user_id}'

    def test_normalize_multiple_params(self) -> None:
        """Convert multiple params in one path."""
        input_path = '/api/apps/:appId/users/:userId'
        expected = '/api/apps/{app_id}/users/{user_id}'
        assert _normalize_path(input_path) == expected

    def test_normalize_already_snake_case(self) -> None:
        """Already snake_case paths should pass through."""
        assert _normalize_path('/api/users/{user_id}') == '/api/users/{user_id}'

    def test_normalize_no_params(self) -> None:
        """Paths without params should pass through."""
        assert _normalize_path('/api/health') == '/api/health'

    def test_normalize_trailing_param(self) -> None:
        """Params at end of path."""
        assert _normalize_path('/api/delete/:id') == '/api/delete/{id}'

    def test_normalize_connection_id(self) -> None:
        """Real example: connectionId -> connection_id."""
        input_path = '/api/cfo/user-connections/:connectionId'
        expected = '/api/cfo/user-connections/{connection_id}'
        assert _normalize_path(input_path) == expected

    def test_normalize_session_id(self) -> None:
        """Real example: sessionId -> session_id."""
        assert _normalize_path('/api/sessions/:sessionId') == '/api/sessions/{session_id}'

    def test_normalize_template_key(self) -> None:
        """Real example: templateKey -> template_key."""
        input_path = '/api/email/templates/:templateKey'
        expected = '/api/email/templates/{template_key}'
        assert _normalize_path(input_path) == expected

    def test_to_snake_case_simple(self) -> None:
        """Test camelCase to snake_case conversion."""
        assert _to_snake_case('userId') == 'user_id'
        assert _to_snake_case('connectionId') == 'connection_id'
        assert _to_snake_case('templateKey') == 'template_key'

    def test_to_snake_case_already_snake(self) -> None:
        """Already snake_case should pass through."""
        assert _to_snake_case('user_id') == 'user_id'
        assert _to_snake_case('connection_id') == 'connection_id'

    def test_to_snake_case_single_word(self) -> None:
        """Single word should pass through."""
        assert _to_snake_case('id') == 'id'
        assert _to_snake_case('email') == 'email'
