"""
Contract tests for the Celery application factory.

These tests encode what consumer_server depends on from create_celery_app.
"""
from __future__ import annotations


from celery import Celery

from spaps_server_quickstart.settings import BaseServiceSettings
from spaps_server_quickstart.tasks.celery_factory import create_celery_app


class _TestSettings(BaseServiceSettings):
    app_name: str = "Test Service"
    service_slug: str = "test-service"
    database_url: str = "postgresql+asyncpg://user:pass@localhost:5432/test"


class TestCreateCeleryApp:
    """consumer_server calls create_celery_app with settings + task_modules + extra_config."""

    def test_returns_celery_instance(self) -> None:
        app = create_celery_app(
            _TestSettings(),
            task_modules=["test.tasks"],
        )
        assert isinstance(app, Celery)

    def test_uses_celery_app_name_from_settings(self) -> None:
        settings = _TestSettings()
        app = create_celery_app(settings, task_modules=[])
        assert app.main == settings.celery_app_name

    def test_accepts_extra_config(self) -> None:
        app = create_celery_app(
            _TestSettings(),
            task_modules=[],
            extra_config={
                "task_always_eager": True,
                "task_eager_propagates": True,
            },
        )
        assert app.conf.task_always_eager is True
        assert app.conf.task_eager_propagates is True

    def test_accepts_beat_schedule_in_extra_config(self) -> None:
        """consumer_server passes beat_schedule as extra_config."""
        beat_schedule = {
            "my-task": {
                "task": "test.tasks.my_task",
                "schedule": 60,
            },
        }
        app = create_celery_app(
            _TestSettings(),
            task_modules=["test.tasks"],
            extra_config={"beat_schedule": beat_schedule},
        )
        assert "my-task" in app.conf.beat_schedule

    def test_default_timezone_utc(self) -> None:
        app = create_celery_app(_TestSettings(), task_modules=[])
        assert app.conf.timezone == "UTC"

    def test_default_queue_is_default(self) -> None:
        app = create_celery_app(_TestSettings(), task_modules=[])
        assert app.conf.task_default_queue == "default"

    def test_task_modules_empty_list_ok(self) -> None:
        app = create_celery_app(_TestSettings(), task_modules=[])
        assert isinstance(app, Celery)

    def test_uses_redis_url_as_broker(self) -> None:
        settings = _TestSettings(redis_url="redis://custom-host:6379/0")
        app = create_celery_app(settings, task_modules=[])
        broker_url = str(app.conf.broker_url)
        assert "custom-host" in broker_url
