"""
Contract tests for DatabaseResources and database utilities.

These tests encode what consumer_server depends on from the database module.
"""
from __future__ import annotations

import inspect

from sqlalchemy.ext.asyncio import AsyncEngine, async_sessionmaker

from spaps_server_quickstart.db.session import (
    DatabaseHelperSurface,
    DatabaseResources,
    create_async_sessionmaker,
    initialize_database_helpers,
    session_dependency_factory,
)
from spaps_server_quickstart.settings import BaseServiceSettings


class TestDatabaseResourcesInterface:
    """consumer_server delegates to DatabaseResources. These methods must exist."""

    def test_constructor_accepts_settings(self) -> None:
        settings = BaseServiceSettings()
        db = DatabaseResources(settings)
        assert db is not None

    def test_constructor_accepts_engine_overrides(self) -> None:
        settings = BaseServiceSettings()
        db = DatabaseResources(settings, engine_overrides={"echo": True})
        assert db is not None

    def test_get_engine_returns_async_engine(self) -> None:
        settings = BaseServiceSettings()
        db = DatabaseResources(settings)
        engine = db.get_engine()
        assert isinstance(engine, AsyncEngine)

    def test_get_session_factory_returns_sessionmaker(self) -> None:
        settings = BaseServiceSettings()
        db = DatabaseResources(settings)
        factory = db.get_session_factory()
        assert isinstance(factory, async_sessionmaker)

    def test_has_dispose_method(self) -> None:
        assert inspect.iscoroutinefunction(DatabaseResources.dispose)

    def test_has_session_dependency_method(self) -> None:
        assert inspect.isasyncgenfunction(DatabaseResources.session_dependency)

    def test_engine_uses_settings_database_url(self) -> None:
        settings = BaseServiceSettings(
            database_url="postgresql+asyncpg://user:pass@host:5432/mydb",
        )
        db = DatabaseResources(settings)
        engine = db.get_engine()
        assert "mydb" in str(engine.url)

    def test_engine_lazy_initialization(self) -> None:
        settings = BaseServiceSettings()
        db = DatabaseResources(settings)
        assert db._engine is None
        db.get_engine()
        assert db._engine is not None


class TestCreateAsyncSessionmaker:
    """Convenience helper used by some consumers."""

    def test_returns_sessionmaker(self) -> None:
        settings = BaseServiceSettings()
        factory = create_async_sessionmaker(settings)
        assert isinstance(factory, async_sessionmaker)


class TestSessionDependencyFactory:
    """Used to create FastAPI session dependencies."""

    def test_returns_callable(self) -> None:
        settings = BaseServiceSettings()
        db = DatabaseResources(settings)
        dep = session_dependency_factory(db.get_session_factory())
        assert callable(dep)

    def test_returned_callable_is_async_generator(self) -> None:
        settings = BaseServiceSettings()
        db = DatabaseResources(settings)
        dep = session_dependency_factory(db.get_session_factory())
        assert inspect.isasyncgenfunction(dep)


class TestInitializeDatabaseHelpers:
    def test_returns_helper_surface(self) -> None:
        helpers = initialize_database_helpers(BaseServiceSettings)
        assert isinstance(helpers, DatabaseHelperSurface)

    def test_exposes_stable_callables(self) -> None:
        helpers = initialize_database_helpers(BaseServiceSettings)
        assert callable(helpers.get_engine)
        assert callable(helpers.get_session_factory)
        assert callable(helpers.dispose_engine)
        assert callable(helpers.get_db_session)
        assert inspect.isasyncgenfunction(helpers.get_db_session)
