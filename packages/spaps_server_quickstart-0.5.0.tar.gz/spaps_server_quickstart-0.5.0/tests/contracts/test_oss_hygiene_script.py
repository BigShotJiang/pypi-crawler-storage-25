"""Tests for OSS hygiene CI guardrail helpers."""

from __future__ import annotations

import importlib.util
from pathlib import Path


def _load_oss_hygiene_module():
    script_path = (
        Path(__file__).resolve().parents[4] / "scripts" / "check-oss-hygiene.py"
    )
    spec = importlib.util.spec_from_file_location("check_oss_hygiene", script_path)
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_resolve_diff_range_for_pull_request() -> None:
    module = _load_oss_hygiene_module()
    env = {"GITHUB_EVENT_NAME": "pull_request", "GITHUB_BASE_REF": "main"}
    assert module.resolve_diff_range(env) == "origin/main...HEAD"


def test_resolve_diff_range_for_push() -> None:
    module = _load_oss_hygiene_module()
    env = {
        "GITHUB_EVENT_NAME": "push",
        "GITHUB_EVENT_BEFORE": "a" * 40,
        "GITHUB_SHA": "b" * 40,
    }
    assert module.resolve_diff_range(env) == f"{'a' * 40}...{'b' * 40}"


def test_resolve_diff_range_without_ci_context() -> None:
    module = _load_oss_hygiene_module()
    assert module.resolve_diff_range({}) is None


def test_find_deprecated_runtime_changes() -> None:
    module = _load_oss_hygiene_module()
    changed_files = [
        "src/routes/auth.ts",
        "src/services/stripe.ts",
        "docs/README.md",
        "packages/python-server-quickstart/src/spaps_server_quickstart/domains/auth/router.py",
    ]
    assert module.find_deprecated_runtime_changes(changed_files) == [
        "src/routes/auth.ts",
        "src/services/stripe.ts",
    ]
