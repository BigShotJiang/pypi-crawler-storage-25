"""
Contract tests for build_base_router.

These tests encode what consumers depend on from the router composition helper.
"""
from __future__ import annotations

from fastapi import APIRouter

from spaps_server_quickstart.api.router import build_base_router


class TestBuildBaseRouter:
    """Consumers compose their API router from sub-routers."""

    def test_returns_api_router(self) -> None:
        router = build_base_router()
        assert isinstance(router, APIRouter)

    def test_accepts_plain_routers(self) -> None:
        r1 = APIRouter()

        @r1.get("/test")
        async def endpoint():
            return {}

        base = build_base_router(r1)
        routes = [r.path for r in base.routes]
        assert "/test" in routes

    def test_accepts_router_tuple_with_kwargs(self) -> None:
        r1 = APIRouter()

        @r1.get("/items")
        async def items_endpoint():
            return {}

        base = build_base_router((r1, {"prefix": "/v1"}))
        routes = [r.path for r in base.routes]
        assert "/v1/items" in routes

    def test_composes_multiple_routers(self) -> None:
        r1 = APIRouter()
        r2 = APIRouter()

        @r1.get("/a")
        async def a():
            return {}

        @r2.get("/b")
        async def b():
            return {}

        base = build_base_router(r1, r2)
        routes = [r.path for r in base.routes]
        assert "/a" in routes
        assert "/b" in routes
