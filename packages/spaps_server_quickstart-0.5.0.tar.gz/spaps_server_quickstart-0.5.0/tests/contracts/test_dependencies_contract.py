"""
Contract tests for API dependencies (require_authenticated_user, require_role, require_any_role).

These tests encode what consumer_server depends on from the dependencies module.
consumer_server imports these and wraps them as:
  require_authenticated_practitioner = require_any_role("practitioner", "admin")
  require_authenticated_patient = require_role("patient")
"""
from __future__ import annotations

import pytest
from fastapi import HTTPException
from starlette.requests import Request

from spaps_server_quickstart.api.dependencies import (
    require_any_role,
    require_authenticated_user,
    require_role,
)
from spaps_server_quickstart.auth import AuthenticatedUser


def _build_request(user: AuthenticatedUser | None = None) -> Request:
    scope = {"type": "http", "method": "GET", "path": "/", "headers": []}
    request = Request(scope)
    if user is not None:
        request.state.authenticated_user = user
    return request


def _make_user(**kwargs: object) -> AuthenticatedUser:
    defaults = {
        "user_id": "user-1",
        "session_id": "sess-1",
        "application_id": "app-1",
        "roles": {"patient"},
    }
    defaults.update(kwargs)
    return AuthenticatedUser(**defaults)


class TestRequireAuthenticatedUser:
    """Consumers use this to extract the user from request state."""

    def test_returns_user_when_present(self) -> None:
        user = _make_user()
        request = _build_request(user)
        result = require_authenticated_user(request)
        assert result is user

    def test_raises_401_when_missing(self) -> None:
        request = _build_request(None)
        with pytest.raises(HTTPException) as exc:
            require_authenticated_user(request)
        assert exc.value.status_code == 401


class TestRequireRole:
    """require_role returns a dependency factory."""

    def test_is_callable_factory(self) -> None:
        dep = require_role("admin")
        assert callable(dep)

    def test_allows_matching_role(self) -> None:
        user = _make_user(roles={"admin", "patient"})
        request = _build_request(user)
        dep = require_role("admin")
        result = dep(request)
        assert result is user

    def test_case_insensitive(self) -> None:
        user = _make_user(roles={"Admin"})
        request = _build_request(user)
        dep = require_role("admin")
        result = dep(request)
        assert result is user

    def test_rejects_missing_role(self) -> None:
        user = _make_user(roles={"patient"})
        request = _build_request(user)
        dep = require_role("admin")
        with pytest.raises(HTTPException) as exc:
            dep(request)
        assert exc.value.status_code == 403

    def test_error_message_includes_role_name(self) -> None:
        user = _make_user(roles={"patient"})
        request = _build_request(user)
        dep = require_role("admin")
        with pytest.raises(HTTPException) as exc:
            dep(request)
        assert "admin" in exc.value.detail.lower()


class TestRequireAnyRole:
    """require_any_role returns a dependency factory checking for any matching role."""

    def test_is_callable_factory(self) -> None:
        dep = require_any_role("admin", "practitioner")
        assert callable(dep)

    def test_allows_when_user_has_one_of_roles(self) -> None:
        user = _make_user(roles={"practitioner"})
        request = _build_request(user)
        dep = require_any_role("practitioner", "admin")
        result = dep(request)
        assert result is user

    def test_rejects_when_user_has_none_of_roles(self) -> None:
        user = _make_user(roles={"patient"})
        request = _build_request(user)
        dep = require_any_role("practitioner", "admin")
        with pytest.raises(HTTPException) as exc:
            dep(request)
        assert exc.value.status_code == 403

    def test_error_message_lists_required_roles(self) -> None:
        user = _make_user(roles={"patient"})
        request = _build_request(user)
        dep = require_any_role("practitioner", "admin")
        with pytest.raises(HTTPException) as exc:
            dep(request)
        detail = exc.value.detail.lower()
        assert "practitioner" in detail
        assert "admin" in detail

    def test_case_insensitive(self) -> None:
        user = _make_user(roles={"Practitioner"})
        request = _build_request(user)
        dep = require_any_role("practitioner", "admin")
        result = dep(request)
        assert result is user
