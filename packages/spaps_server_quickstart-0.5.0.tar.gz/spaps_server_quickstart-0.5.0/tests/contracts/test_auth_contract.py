"""
Contract tests for authentication primitives.

These tests encode what consumers depend on from the auth module.
"""
from __future__ import annotations

import dataclasses
from datetime import UTC, datetime

from spaps_server_quickstart.auth import (
    AuthenticatedUser,
    AuthenticationError,
    SpapsAuthMiddleware,
    SpapsAuthService,
    build_spaps_auth_service,
)
from spaps_server_quickstart.settings import BaseServiceSettings


class TestAuthenticatedUserContract:
    """consumer_server, cfo, and chat all construct and read AuthenticatedUser fields."""

    def test_is_dataclass(self) -> None:
        assert dataclasses.is_dataclass(AuthenticatedUser)

    def test_required_fields(self) -> None:
        user = AuthenticatedUser(
            user_id="u-1",
            session_id="s-1",
            application_id="app-1",
        )
        assert user.user_id == "u-1"
        assert user.session_id == "s-1"
        assert user.application_id == "app-1"

    def test_optional_fields_default(self) -> None:
        user = AuthenticatedUser(
            user_id="u-1",
            session_id="s-1",
            application_id="app-1",
        )
        assert isinstance(user.roles, set)
        assert user.subscription_active is False
        assert user.subscription_plan is None
        assert user.tier is None
        assert user.session_expires_at is None

    def test_roles_is_set_of_strings(self) -> None:
        user = AuthenticatedUser(
            user_id="u-1",
            session_id="s-1",
            application_id="app-1",
            roles={"practitioner", "admin"},
        )
        assert isinstance(user.roles, set)
        assert "practitioner" in user.roles

    def test_session_expires_at_accepts_datetime(self) -> None:
        now = datetime.now(tz=UTC)
        user = AuthenticatedUser(
            user_id="u-1",
            session_id="s-1",
            application_id="app-1",
            session_expires_at=now,
        )
        assert user.session_expires_at == now


class TestAuthenticationError:
    """Consumers catch this and inspect status_code/error_code."""

    def test_is_exception(self) -> None:
        err = AuthenticationError("fail")
        assert isinstance(err, Exception)

    def test_has_status_code(self) -> None:
        err = AuthenticationError("fail", status_code=401)
        assert err.status_code == 401

    def test_has_error_code(self) -> None:
        err = AuthenticationError("fail", error_code="TOKEN_EXPIRED")
        assert err.error_code == "TOKEN_EXPIRED"


class TestSpapsAuthServiceContract:
    """Consumers construct via build_spaps_auth_service or directly."""

    def test_constructor_accepts_required_kwargs(self) -> None:
        service = SpapsAuthService(
            base_url="https://api.example.com",
            api_key="test-key",
            application_id="app-1",
        )
        assert service is not None

    def test_has_authenticate_method(self) -> None:
        assert hasattr(SpapsAuthService, "authenticate")

    def test_has_aclose_method(self) -> None:
        assert hasattr(SpapsAuthService, "aclose")


class TestBuildSpapsAuthService:
    """Consumers pass settings to build_spaps_auth_service."""

    def test_builds_from_settings(self) -> None:
        settings = BaseServiceSettings(
            spaps_api_key="key-123",
            spaps_application_id="app-123",
        )
        service = build_spaps_auth_service(settings)
        assert isinstance(service, SpapsAuthService)


class TestSpapsAuthMiddlewareContract:
    """Consumers add this middleware via create_app or manually."""

    def test_constructor_signature(self) -> None:
        import inspect

        sig = inspect.signature(SpapsAuthMiddleware.__init__)
        params = list(sig.parameters.keys())
        assert "app" in params
        assert "auth_service" in params
        assert "exempt_paths" in params
