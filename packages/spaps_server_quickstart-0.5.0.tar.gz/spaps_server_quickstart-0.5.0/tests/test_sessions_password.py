"""Tests for domains/sessions/password_service.py"""

from __future__ import annotations

import pytest
import bcrypt

from spaps_server_quickstart.domains.sessions.password_service import (
    hash_password,
    verify_password,
    validate_password_strength,
)
from spaps_server_quickstart.domains.errors import WeakPasswordError


def test_hash_password_returns_bcrypt_hash():
    """Test password hashing produces valid bcrypt hash."""
    password = "TestPassword123!"
    hashed = hash_password(password)

    # Bcrypt hashes start with $2b$ or $2a$
    assert hashed.startswith(("$2b$", "$2a$"))
    assert len(hashed) == 60  # Standard bcrypt hash length


def test_hash_password_unique_hashes():
    """Test that same password produces different hashes (due to random salt)."""
    password = "TestPassword123!"
    hash1 = hash_password(password)
    hash2 = hash_password(password)

    # Hashes should differ due to random salt
    assert hash1 != hash2

    # But both should verify against the original password
    assert bcrypt.checkpw(password.encode(), hash1.encode())
    assert bcrypt.checkpw(password.encode(), hash2.encode())


def test_verify_password_success():
    """Test successful password verification."""
    password = "CorrectPassword123!"
    hashed = hash_password(password)

    assert verify_password(password, hashed) is True


def test_verify_password_failure():
    """Test password verification fails with wrong password."""
    password = "CorrectPassword123!"
    hashed = hash_password(password)

    assert verify_password("WrongPassword123!", hashed) is False


def test_verify_password_handles_malformed_hash():
    """Test that malformed hash returns False instead of raising."""
    password = "TestPassword123!"

    # Invalid hash formats should return False, not crash
    assert verify_password(password, "not-a-valid-hash") is False
    assert verify_password(password, "") is False
    assert verify_password(password, "$2b$invalid") is False


def test_verify_password_handles_supabase_2a_prefix():
    """Test that $2a$ prefix hashes (from Supabase) verify correctly."""
    password = "TestPassword123!"

    # Create a $2a$ hash manually (bcrypt handles this transparently)
    hashed = hash_password(password)

    # Verify works regardless of prefix
    assert verify_password(password, hashed) is True


def test_validate_password_strength_accepts_strong_password():
    """Test that strong password passes validation."""
    # Should not raise
    validate_password_strength("StrongPass123!")
    validate_password_strength("Abc12345")
    validate_password_strength("MyPassword1")


def test_validate_password_strength_rejects_short_password():
    """Test that password < 8 characters fails."""
    with pytest.raises(WeakPasswordError) as excinfo:
        validate_password_strength("Short1!")

    assert "at least 8 characters" in str(excinfo.value)


def test_validate_password_strength_rejects_no_uppercase():
    """Test that password without uppercase fails."""
    with pytest.raises(WeakPasswordError) as excinfo:
        validate_password_strength("alllowercase123")

    assert "at least 1 uppercase letter" in str(excinfo.value)


def test_validate_password_strength_rejects_no_lowercase():
    """Test that password without lowercase fails."""
    with pytest.raises(WeakPasswordError) as excinfo:
        validate_password_strength("ALLUPPERCASE123")

    assert "at least 1 lowercase letter" in str(excinfo.value)


def test_validate_password_strength_rejects_no_digit():
    """Test that password without digit fails."""
    with pytest.raises(WeakPasswordError) as excinfo:
        validate_password_strength("NoDigitsHere!")

    assert "at least 1 digit" in str(excinfo.value)


def test_validate_password_strength_rejects_too_long_password():
    """L4: Password > 128 chars rejected to prevent bcrypt DoS."""
    long_password = "A" * 64 + "a" * 64 + "1"  # 129 chars, meets all other rules
    with pytest.raises(WeakPasswordError) as excinfo:
        validate_password_strength(long_password)

    assert "at most 128 characters" in str(excinfo.value)


def test_validate_password_strength_accepts_max_length_password():
    """Password at exactly 128 chars should pass."""
    password = "A" * 63 + "a" * 64 + "1"  # 128 chars
    validate_password_strength(password)


def test_validate_password_strength_multiple_failures():
    """Test that multiple validation failures are reported."""
    with pytest.raises(WeakPasswordError) as excinfo:
        validate_password_strength("short")  # Too short, no uppercase, no digit

    error_msg = str(excinfo.value)
    assert "at least 8 characters" in error_msg
    assert "at least 1 uppercase letter" in error_msg
    assert "at least 1 digit" in error_msg
