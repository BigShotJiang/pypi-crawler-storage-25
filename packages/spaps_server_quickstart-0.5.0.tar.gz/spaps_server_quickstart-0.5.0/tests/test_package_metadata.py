import importlib
import pathlib

import pytest


def project_root() -> pathlib.Path:
    return pathlib.Path(__file__).resolve().parents[1]


def test_runtime_version_matches_pyproject() -> None:
    pyproject_path = project_root() / "pyproject.toml"
    if not pyproject_path.exists():
        pytest.fail("pyproject.toml not found")

    try:
        import tomllib  # Python 3.11+
    except ModuleNotFoundError:  # pragma: no cover
        pytest.skip("tomllib not available")

    with pyproject_path.open("rb") as fp:
        pyproject = tomllib.load(fp)

    expected_version = pyproject["project"]["version"]
    module = importlib.import_module("spaps_server_quickstart")

    assert module.__version__ == expected_version
