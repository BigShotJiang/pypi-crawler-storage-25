"""Tests for security headers middleware.

Verifies that security headers are set correctly on all responses to protect
against common web vulnerabilities (XSS, clickjacking, MIME sniffing, etc.).

Expected security headers (per plan spec):
- Content-Security-Policy
- Strict-Transport-Security (HSTS)
- X-Frame-Options: DENY
- X-Content-Type-Options: nosniff
- X-XSS-Protection: 1; mode=block
- Referrer-Policy: strict-origin-when-cross-origin
- Permissions-Policy: geolocation=(), microphone=(), camera=()
"""

from __future__ import annotations

from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from spaps_server_quickstart.middleware.security_headers import SecurityHeadersMiddleware


# ===========================================================================
# Security Headers Implementation
# ===========================================================================


class TestSecurityHeadersMiddleware:
    """Tests for security headers middleware."""

    async def test_content_security_policy_header(self):
        """Content-Security-Policy header is set on responses."""
        app = FastAPI()
        app.add_middleware(SecurityHeadersMiddleware)

        @app.get("/test")
        async def test_endpoint():
            return {"status": "ok"}

        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.get("/test")

        assert "Content-Security-Policy" in response.headers
        csp = response.headers["Content-Security-Policy"]
        # Should include directives like default-src, script-src, etc.
        assert "default-src" in csp

    async def test_strict_transport_security_header(self):
        """Strict-Transport-Security (HSTS) header is set."""
        app = FastAPI()
        app.add_middleware(SecurityHeadersMiddleware)

        @app.get("/test")
        async def test_endpoint():
            return {"status": "ok"}

        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.get("/test")

        assert "Strict-Transport-Security" in response.headers
        hsts = response.headers["Strict-Transport-Security"]
        assert "max-age" in hsts
        # Should include includeSubDomains and preload for best security
        assert "includeSubDomains" in hsts

    async def test_x_frame_options_deny(self):
        """X-Frame-Options is set to DENY to prevent clickjacking."""
        app = FastAPI()
        app.add_middleware(SecurityHeadersMiddleware)

        @app.get("/test")
        async def test_endpoint():
            return {"status": "ok"}

        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.get("/test")

        assert "X-Frame-Options" in response.headers
        assert response.headers["X-Frame-Options"] == "DENY"

    async def test_x_content_type_options_nosniff(self):
        """X-Content-Type-Options is set to nosniff."""
        app = FastAPI()
        app.add_middleware(SecurityHeadersMiddleware)

        @app.get("/test")
        async def test_endpoint():
            return {"status": "ok"}

        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.get("/test")

        assert "X-Content-Type-Options" in response.headers
        assert response.headers["X-Content-Type-Options"] == "nosniff"

    async def test_x_xss_protection_header(self):
        """X-XSS-Protection header is set."""
        app = FastAPI()
        app.add_middleware(SecurityHeadersMiddleware)

        @app.get("/test")
        async def test_endpoint():
            return {"status": "ok"}

        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.get("/test")

        assert "X-XSS-Protection" in response.headers
        xss = response.headers["X-XSS-Protection"]
        assert xss == "1; mode=block"

    async def test_referrer_policy_header(self):
        """Referrer-Policy header is set correctly."""
        app = FastAPI()
        app.add_middleware(SecurityHeadersMiddleware)

        @app.get("/test")
        async def test_endpoint():
            return {"status": "ok"}

        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.get("/test")

        assert "Referrer-Policy" in response.headers
        assert response.headers["Referrer-Policy"] == "strict-origin-when-cross-origin"

    async def test_permissions_policy_header(self):
        """Permissions-Policy header restricts dangerous features."""
        app = FastAPI()
        app.add_middleware(SecurityHeadersMiddleware)

        @app.get("/test")
        async def test_endpoint():
            return {"status": "ok"}

        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.get("/test")

        assert "Permissions-Policy" in response.headers
        policy = response.headers["Permissions-Policy"]
        # Should deny geolocation, microphone, camera
        assert "geolocation=()" in policy
        assert "microphone=()" in policy
        assert "camera=()" in policy

    async def test_all_headers_present_on_regular_response(self):
        """All security headers are present on a regular API response."""
        app = FastAPI()
        app.add_middleware(SecurityHeadersMiddleware)

        @app.get("/api/test")
        async def test_endpoint():
            return {"status": "ok"}

        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.get("/api/test")

        expected_headers = [
            "Content-Security-Policy",
            "Strict-Transport-Security",
            "X-Frame-Options",
            "X-Content-Type-Options",
            "X-XSS-Protection",
            "Referrer-Policy",
            "Permissions-Policy",
        ]

        for header in expected_headers:
            assert header in response.headers, f"Missing security header: {header}"

    async def test_security_headers_on_error_responses(self):
        """Security headers are present even on error responses."""
        app = FastAPI()
        app.add_middleware(SecurityHeadersMiddleware)

        @app.get("/error")
        async def error_endpoint():
            raise ValueError("Test error")

        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.get("/error")

        # Even on error, security headers should be present
        assert response.status_code >= 400
        assert "X-Frame-Options" in response.headers
        assert "X-Content-Type-Options" in response.headers

    async def test_security_headers_do_not_break_cors(self):
        """Security headers work alongside CORS headers."""
        from starlette.middleware.cors import CORSMiddleware

        app = FastAPI()
        app.add_middleware(SecurityHeadersMiddleware)
        app.add_middleware(
            CORSMiddleware,
            allow_origins=["https://example.com"],
            allow_methods=["GET", "POST"],
        )

        @app.get("/test")
        async def test_endpoint():
            return {"status": "ok"}

        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.get(
                "/test",
                headers={"Origin": "https://example.com"},
            )

        # Both security and CORS headers should be present
        assert "X-Frame-Options" in response.headers
        assert "Access-Control-Allow-Origin" in response.headers


# ===========================================================================
# Current State Verification
# ===========================================================================


class TestCurrentSecurityPosture:
    """Verify that security headers ARE now implemented in the app."""

    async def test_app_has_security_headers(self):
        """Security headers are present on SPAPS app responses."""
        from spaps_server_quickstart.spaps_app import create_spaps_app
        from spaps_server_quickstart.spaps_settings import SpapsSettings

        settings = SpapsSettings(
            env="test",
            app_name="Test",
            database_url="postgresql+asyncpg://localhost/test",
            redis_url="redis://localhost/0",
            jwt_secret="test",
            refresh_token_secret="test",
            spaps_local_mode=True,
        )
        app = create_spaps_app(settings=settings)

        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.get("/health")

        security_headers = [
            "Content-Security-Policy",
            "Strict-Transport-Security",
            "X-Frame-Options",
            "X-Content-Type-Options",
            "X-XSS-Protection",
            "Referrer-Policy",
            "Permissions-Policy",
        ]

        missing_headers = [h for h in security_headers if h not in response.headers]

        assert len(missing_headers) == 0, (
            f"Security headers still missing: {missing_headers}"
        )


# ===========================================================================
# Implementation Reference
# ===========================================================================


class TestSecurityHeadersImplementationGuide:
    """Reference implementation patterns for security headers middleware.

    This class documents the expected implementation approach and validates
    that the defaults match the SPAPS backend spec.
    """

    def test_recommended_csp_policy(self):
        """Document recommended Content-Security-Policy directives."""
        recommended_csp = (
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline' https://js.stripe.com; "
            "style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data: https:; "
            "font-src 'self' data:; "
            "connect-src 'self' https://api.stripe.com; "
            "frame-src https://js.stripe.com https://hooks.stripe.com; "
            "object-src 'none'; "
            "base-uri 'self'; "
            "form-action 'self'"
        )

        assert "default-src 'self'" in recommended_csp
        assert "script-src" in recommended_csp
        assert "stripe.com" in recommended_csp  # Required for Stripe integration

    def test_recommended_hsts_settings(self):
        """Document recommended Strict-Transport-Security settings."""
        # Recommended: 2 years (63072000 seconds) with includeSubDomains and preload
        recommended_hsts = "max-age=63072000; includeSubDomains; preload"

        assert "max-age=63072000" in recommended_hsts
        assert "includeSubDomains" in recommended_hsts
        assert "preload" in recommended_hsts

    def test_recommended_permissions_policy(self):
        """Document recommended Permissions-Policy restrictions."""
        recommended_policy = "geolocation=(), microphone=(), camera=(), payment=(self)"

        assert "geolocation=()" in recommended_policy
        assert "microphone=()" in recommended_policy
        assert "camera=()" in recommended_policy
        # Allow payment API for Stripe
        assert "payment=(self)" in recommended_policy
