"""Unit tests for rate limiting middleware.

Tests the tier lookup, key extraction, exemption logic, and the
sliding window store. Also verifies tier values match the spec and
that rate limiting is correctly applied to all endpoint groups.
"""

from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from spaps_server_quickstart.middleware.rate_limiting import (
    ENDPOINT_TIERS,
    STRICT,
    TIGHT,
    MODERATE,
    STANDARD,
    RELAXED,
    GENEROUS,
    AGENT_REGISTER,
    APPROVAL_CREATE,
    APPROVAL_POLL,
    DEFAULT_TIER,
    get_tier_for_path,
    get_tier_for_request,
    get_rate_limit_key,
    is_rate_limit_exempt,
    _get_real_client_ip,
    _populate_rate_limit_context,
    _SlidingWindowStore,
    RateLimitMiddleware,
    EXEMPT_APP_IDS,
)


class _SessionContext:
    def __init__(self, session):
        self._session = session

    async def __aenter__(self):
        return self._session

    async def __aexit__(self, exc_type, exc, tb):
        return None


# ===========================================================================
# Tier Definitions Match Spec
# ===========================================================================


class TestTierDefinitionsMatchSpec:
    """Verify all tier definitions match the production spec."""

    def test_strict_tier_5_per_minute(self):
        """STRICT tier: 5 requests per minute."""
        assert STRICT.max_requests == 5
        assert STRICT.window_seconds == 60

    def test_tight_tier_10_per_minute(self):
        """TIGHT tier: 10 requests per minute."""
        assert TIGHT.max_requests == 10
        assert TIGHT.window_seconds == 60

    def test_moderate_tier_15_per_minute(self):
        """MODERATE tier: 15 requests per minute."""
        assert MODERATE.max_requests == 15
        assert MODERATE.window_seconds == 60

    def test_standard_tier_300_per_15_minutes(self):
        """STANDARD tier: 300 requests per 15 minutes."""
        assert STANDARD.max_requests == 300
        assert STANDARD.window_seconds == 900

    def test_relaxed_tier_500_per_15_minutes(self):
        """RELAXED tier: 500 requests per 15 minutes."""
        assert RELAXED.max_requests == 500
        assert RELAXED.window_seconds == 900

    def test_generous_tier_1000_per_hour(self):
        """GENEROUS tier: 1000 requests per hour."""
        assert GENEROUS.max_requests == 1000
        assert GENEROUS.window_seconds == 3600

    def test_default_tier_is_standard(self):
        """Default tier should be STANDARD."""
        assert DEFAULT_TIER == STANDARD

    def test_agent_register_tier_10_per_minute(self):
        """AGENT_REGISTER tier: 10 requests per minute."""
        assert AGENT_REGISTER.max_requests == 10
        assert AGENT_REGISTER.window_seconds == 60

    def test_approval_create_tier_30_per_minute(self):
        """APPROVAL_CREATE tier: 30 requests per minute."""
        assert APPROVAL_CREATE.max_requests == 30
        assert APPROVAL_CREATE.window_seconds == 60

    def test_approval_poll_tier_60_per_minute(self):
        """APPROVAL_POLL tier: 60 requests per minute."""
        assert APPROVAL_POLL.max_requests == 60
        assert APPROVAL_POLL.window_seconds == 60


# ===========================================================================
# Endpoint Tier Assignments Match Spec
# ===========================================================================


class TestEndpointTierAssignmentsMatchSpec:
    """Verify all endpoint groups have correct tier assignments per spec."""

    def test_auth_login_tight(self):
        """Auth login: TIGHT (10/min)."""
        assert ENDPOINT_TIERS["/api/auth/login"] == TIGHT

    def test_auth_refresh_tight(self):
        """Auth refresh: TIGHT (10/min)."""
        assert ENDPOINT_TIERS["/api/auth/refresh"] == TIGHT

    def test_auth_nonce_tight(self):
        """Auth nonce: TIGHT (10/min)."""
        assert ENDPOINT_TIERS["/api/auth/nonce"] == TIGHT

    def test_auth_wallet_sign_in_tight(self):
        """Auth wallet-sign-in: TIGHT (10/min)."""
        assert ENDPOINT_TIERS["/api/auth/wallet-sign-in"] == TIGHT

    def test_auth_register_moderate(self):
        """Auth register: MODERATE (15/min)."""
        assert ENDPOINT_TIERS["/api/auth/register"] == MODERATE

    def test_auth_magic_link_strict(self):
        """Auth magic-link: STRICT (5/min)."""
        assert ENDPOINT_TIERS["/api/auth/magic-link"] == STRICT

    def test_auth_password_reset_strict(self):
        """Auth password-reset: STRICT (5/min)."""
        assert ENDPOINT_TIERS["/api/auth/password-reset"] == STRICT

    def test_solana_endpoints_tight(self):
        """Solana auth endpoints: TIGHT (10/min)."""
        assert ENDPOINT_TIERS["/api/auth/solana/sign-in"] == TIGHT
        assert ENDPOINT_TIERS["/api/auth/solana/link-wallet"] == TIGHT
        assert ENDPOINT_TIERS["/api/auth/solana/verify-signature"] == TIGHT

    def test_ethereum_endpoints_tight(self):
        """Ethereum auth endpoints: TIGHT (10/min)."""
        assert ENDPOINT_TIERS["/api/auth/ethereum/sign-in"] == TIGHT
        assert ENDPOINT_TIERS["/api/auth/ethereum/link-wallet"] == TIGHT
        assert ENDPOINT_TIERS["/api/auth/ethereum/verify-signature"] == TIGHT

    def test_stripe_guest_checkout_strict(self):
        """Stripe guest checkout: STRICT (5/min)."""
        assert ENDPOINT_TIERS["/api/stripe/guest-checkout-sessions"] == STRICT

    def test_stripe_checkout_tight(self):
        """Stripe checkout: TIGHT (10/min)."""
        assert ENDPOINT_TIERS["/api/stripe/checkout-sessions"] == TIGHT

    def test_stripe_portal_tight(self):
        """Stripe portal: TIGHT (10/min)."""
        assert ENDPOINT_TIERS["/api/stripe/portal-session"] == TIGHT

    def test_stripe_products_relaxed(self):
        """Stripe products: RELAXED (500/15min)."""
        assert ENDPOINT_TIERS["/api/stripe/products"] == RELAXED

    def test_stripe_webhooks_generous(self):
        """Stripe webhooks: GENEROUS (1000/hr)."""
        assert ENDPOINT_TIERS["/api/stripe/webhooks"] == GENEROUS

    def test_admin_operations_standard(self):
        """Admin operations: STANDARD (300/15min)."""
        assert ENDPOINT_TIERS["/api/admin"] == STANDARD

    def test_admin_reports_tight(self):
        """Admin reports: TIGHT (10/min)."""
        assert ENDPOINT_TIERS["/api/admin/reports"] == TIGHT

    def test_health_generous(self):
        """Health endpoint: GENEROUS (1000/hr)."""
        assert ENDPOINT_TIERS["/health"] == GENEROUS

    def test_docs_relaxed(self):
        """Docs endpoint: RELAXED (500/15min)."""
        assert ENDPOINT_TIERS["/api/docs"] == RELAXED

    def test_self_service_tight(self):
        """Self-service: TIGHT (10/min)."""
        assert ENDPOINT_TIERS["/api/self-service"] == TIGHT

    def test_dayrate_book_tight(self):
        """DayRate book: TIGHT (10/min)."""
        assert ENDPOINT_TIERS["/api/dayrate/book"] == TIGHT

    def test_cfo_endpoints_correct_tiers(self):
        """CFO endpoints have correct tiers."""
        assert ENDPOINT_TIERS["/api/cfo/exchange-code"] == STRICT
        assert ENDPOINT_TIERS["/api/cfo/generate-link"] == TIGHT
        assert ENDPOINT_TIERS["/api/cfo/validate-token"] == TIGHT


# ===========================================================================
# get_tier_for_path
# ===========================================================================


class TestGetTierForPath:
    def test_exact_match(self):
        """Exact path match returns the configured tier."""
        tier = get_tier_for_path("/api/auth/login")
        assert tier == TIGHT

    def test_prefix_match(self):
        """Prefix match returns the configured tier."""
        # /api/stripe/products/123 should match /api/stripe/products -> RELAXED
        tier = get_tier_for_path("/api/stripe/products/123")
        assert tier == RELAXED

    def test_default_tier_for_unknown(self):
        """Unknown paths get the default tier."""
        tier = get_tier_for_path("/api/unknown/endpoint")
        assert tier == DEFAULT_TIER


# ===========================================================================
# get_tier_for_request
# ===========================================================================


class TestGetTierForRequest:
    def test_post_agents_uses_agent_register_tier(self):
        req = MagicMock()
        req.method = "POST"
        req.url.path = "/api/agents"
        assert get_tier_for_request(req) == AGENT_REGISTER

    def test_post_approvals_uses_approval_create_tier(self):
        req = MagicMock()
        req.method = "POST"
        req.url.path = "/api/approvals"
        assert get_tier_for_request(req) == APPROVAL_CREATE

    def test_get_approval_by_id_uses_poll_tier(self):
        req = MagicMock()
        req.method = "GET"
        req.url.path = "/api/approvals/abc-123"
        assert get_tier_for_request(req) == APPROVAL_POLL

    def test_get_approval_by_code_falls_back_to_default_mapping(self):
        req = MagicMock()
        req.method = "GET"
        req.url.path = "/api/approvals/by-code/ABCD-EFGH"
        assert get_tier_for_request(req) == DEFAULT_TIER


# ===========================================================================
# get_rate_limit_key
# ===========================================================================


class TestGetRateLimitKey:
    def test_uses_application_id_when_available(self):
        """Rate limit key uses application_id when available."""
        req = MagicMock()
        req.state.application_id = "app-123"
        req.method = "GET"
        req.url.path = "/api/unknown"
        req.client = MagicMock()
        req.client.host = "192.168.1.1"
        req.headers = {}

        key = get_rate_limit_key(req)
        assert key == "app:app-123"

    def test_falls_back_to_ip(self):
        """Rate limit key falls back to IP when no application_id."""
        req = MagicMock()
        req.state.application_id = None
        req.method = "GET"
        req.url.path = "/api/unknown"
        req.client = MagicMock()
        req.client.host = "192.168.1.1"
        req.headers = {}

        key = get_rate_limit_key(req)
        assert key == "ip:192.168.1.1"

    def test_handles_no_client(self):
        """Rate limit key handles missing client."""
        req = MagicMock()
        req.state.application_id = None
        req.method = "GET"
        req.url.path = "/api/unknown"
        req.client = None
        req.headers = {}

        key = get_rate_limit_key(req)
        assert key == "ip:unknown"

    def test_create_approval_uses_agent_id_key(self):
        """POST /api/approvals is keyed by agent_id when present."""
        req = MagicMock()
        req.state.application_id = "app-123"
        req.method = "POST"
        req.url.path = "/api/approvals"
        req.client = MagicMock()
        req.client.host = "192.168.1.1"
        req.headers = {"X-Agent-Id": "agent-789"}

        key = get_rate_limit_key(req)
        assert key == "agent:agent-789"

    def test_poll_approval_uses_approval_id_key(self):
        """GET /api/approvals/:id is keyed by approval_id."""
        req = MagicMock()
        req.state.application_id = "app-123"
        req.method = "GET"
        req.url.path = "/api/approvals/approval-456"
        req.client = MagicMock()
        req.client.host = "192.168.1.1"
        req.headers = {}

        key = get_rate_limit_key(req)
        assert key == "approval:approval-456"

    def test_auth_login_uses_ip_key_even_with_application_id(self):
        """Auth login is keyed by client IP to avoid app-wide login lockouts."""
        req = MagicMock()
        req.state.application_id = "app-123"
        req.method = "POST"
        req.url.path = "/api/auth/login"
        req.client = MagicMock()
        req.client.host = "198.51.100.10"
        req.headers = {}

        key = get_rate_limit_key(req)
        assert key == "ip:198.51.100.10"


class TestPopulateRateLimitContext:
    async def test_returns_early_when_state_is_prepopulated(self):
        request = MagicMock()
        request.state = SimpleNamespace(application_id="app-123", is_local_mode=False)

        await _populate_rate_limit_context(request)

        assert request.state.application_id == "app-123"
        assert request.state.is_local_mode is False

    async def test_sets_local_mode_from_app_settings(self):
        request = MagicMock()
        request.state = SimpleNamespace()
        request.app = MagicMock()
        request.app.state = SimpleNamespace(
            settings=SimpleNamespace(is_spaps_local_mode=True),
            db_resources=None,
        )

        await _populate_rate_limit_context(request)

        assert request.state.is_local_mode is True

    async def test_resolves_application_id_from_api_key(self):
        application = SimpleNamespace(id=uuid4())
        session = AsyncMock()
        session_factory = MagicMock(return_value=_SessionContext(session))

        request = MagicMock()
        request.state = SimpleNamespace()
        request.app = MagicMock()
        request.app.state = SimpleNamespace(
            settings=SimpleNamespace(
                is_spaps_local_mode=False,
                legacy_api_key_auth_enabled=False,
            ),
            db_resources=SimpleNamespace(
                get_session_factory=MagicMock(return_value=session_factory)
            ),
        )

        with (
            patch(
                "spaps_server_quickstart.middleware.api_key.extract_api_key",
                return_value="spaps_live_key",
            ),
            patch(
                "spaps_server_quickstart.middleware.api_key.validate_api_key",
                new=AsyncMock(return_value=(application, "secret")),
            ) as mock_validate,
        ):
            await _populate_rate_limit_context(request)

        assert request.state.is_local_mode is False
        assert request.state.application_id == str(application.id)
        mock_validate.assert_awaited_once_with(
            session,
            "spaps_live_key",
            legacy_api_key_auth_enabled=False,
        )

    async def test_missing_api_key_leaves_context_unchanged(self):
        request = MagicMock()
        request.state = SimpleNamespace()
        request.app = MagicMock()
        request.app.state = SimpleNamespace(
            settings=SimpleNamespace(
                is_spaps_local_mode=False,
                legacy_api_key_auth_enabled=True,
            ),
            db_resources=SimpleNamespace(get_session_factory=MagicMock()),
        )

        with patch(
            "spaps_server_quickstart.middleware.api_key.extract_api_key",
            return_value=None,
        ):
            await _populate_rate_limit_context(request)

        assert request.state.is_local_mode is False
        assert not hasattr(request.state, "application_id")


# ===========================================================================
# is_rate_limit_exempt
# ===========================================================================


class TestIsRateLimitExempt:
    def test_local_mode_exempt(self):
        """Local mode disables rate limiting."""
        req = MagicMock()
        req.state.is_local_mode = True
        req.state.application_id = None
        req.client = MagicMock()
        req.client.host = "192.168.1.1"
        req.headers = {}

        assert is_rate_limit_exempt(req) is True

    def test_first_party_app_exempt(self):
        """First-party app is exempt."""
        req = MagicMock()
        req.state.is_local_mode = False
        req.state.application_id = next(iter(EXEMPT_APP_IDS))
        req.client = MagicMock()
        req.client.host = "192.168.1.1"
        req.headers = {}

        assert is_rate_limit_exempt(req) is True

    def test_docker_network_not_exempt(self):
        """Docker network IPs are NOT exempt (security fix)."""
        req = MagicMock()
        req.state.is_local_mode = False
        req.state.application_id = None
        req.client = MagicMock()
        req.client.host = "172.17.0.5"
        req.headers = {}

        assert is_rate_limit_exempt(req) is False

    def test_localhost_exempt(self):
        """Localhost is exempt."""
        req = MagicMock()
        req.state.is_local_mode = False
        req.state.application_id = None
        req.client = MagicMock()
        req.client.host = "127.0.0.1"
        req.headers = {}

        assert is_rate_limit_exempt(req) is True

    def test_regular_request_not_exempt(self):
        """Regular requests are not exempt."""
        req = MagicMock()
        req.state.is_local_mode = False
        req.state.application_id = "regular-app"
        req.client = MagicMock()
        req.client.host = "192.168.1.1"
        req.headers = {}

        assert is_rate_limit_exempt(req) is False

    def test_app_settings_local_mode_exempt_before_dependencies(self):
        """Local-mode exemption works even when request.state is not pre-populated."""
        req = MagicMock()
        req.state.is_local_mode = False
        req.state.application_id = None
        req.client = MagicMock()
        req.client.host = "192.168.1.1"
        req.headers = {}
        req.app.state.settings.is_spaps_local_mode = True

        assert is_rate_limit_exempt(req) is True


# ===========================================================================
# _get_real_client_ip
# ===========================================================================


class TestGetRealClientIp:
    def test_uses_x_forwarded_for_first_ip(self):
        """X-Forwarded-For rightmost IP is used as the real client IP (TM-010)."""
        req = MagicMock()
        req.headers = {"x-forwarded-for": "203.0.113.50, 10.0.0.1, 172.17.0.5"}
        req.client = MagicMock()
        req.client.host = "172.17.0.5"

        ip = _get_real_client_ip(req)
        assert ip == "172.17.0.5"

    def test_falls_back_to_client_host(self):
        """Falls back to request.client.host when no X-Forwarded-For."""
        req = MagicMock()
        req.headers = {}
        req.client = MagicMock()
        req.client.host = "192.168.1.1"

        ip = _get_real_client_ip(req)
        assert ip == "192.168.1.1"

    def test_handles_no_client(self):
        """Returns 'unknown' when both header and client are missing."""
        req = MagicMock()
        req.headers = {}
        req.client = None

        ip = _get_real_client_ip(req)
        assert ip == "unknown"

    def test_docker_ip_via_forwarded_for_not_exempt(self):
        """Docker internal IP behind proxy uses real client IP for rate limiting."""
        req = MagicMock()
        req.state.is_local_mode = False
        req.state.application_id = None
        req.headers = {"x-forwarded-for": "203.0.113.50"}
        req.client = MagicMock()
        req.client.host = "172.17.0.5"

        # Real IP is external, should not be exempt
        assert is_rate_limit_exempt(req) is False

    def test_x_forwarded_for_used_in_rate_limit_key(self):
        """Rate limit key uses rightmost X-Forwarded-For IP (TM-010)."""
        req = MagicMock()
        req.state.application_id = None
        req.headers = {"x-forwarded-for": "203.0.113.50, 172.17.0.5"}
        req.client = MagicMock()
        req.client.host = "172.17.0.5"

        key = get_rate_limit_key(req)
        assert key == "ip:172.17.0.5"


# ===========================================================================
# _SlidingWindowStore
# ===========================================================================


class TestSlidingWindowStore:
    def test_allows_within_limit(self):
        """Requests within limit are allowed."""
        store = _SlidingWindowStore()
        allowed, remaining = store.is_allowed("test-key", STRICT)
        assert allowed is True
        assert remaining == STRICT.max_requests - 1

    def test_blocks_over_limit(self):
        """Requests over limit are blocked."""
        store = _SlidingWindowStore()
        for _ in range(STRICT.max_requests):
            store.is_allowed("test-key", STRICT)

        allowed, remaining = store.is_allowed("test-key", STRICT)
        assert allowed is False
        assert remaining == 0

    def test_clear_resets(self):
        """clear() resets all counters."""
        store = _SlidingWindowStore()
        for _ in range(STRICT.max_requests):
            store.is_allowed("test-key", STRICT)

        store.clear()
        allowed, _ = store.is_allowed("test-key", STRICT)
        assert allowed is True

    def test_different_keys_independent(self):
        """Different keys are tracked independently."""
        store = _SlidingWindowStore()

        # Exhaust key1
        for _ in range(STRICT.max_requests):
            store.is_allowed("key1", STRICT)

        # key2 should still be allowed
        allowed, _ = store.is_allowed("key2", STRICT)
        assert allowed is True


# ===========================================================================
# RateLimitMiddleware Integration
# ===========================================================================


class TestRateLimitMiddlewareIntegration:
    """Integration tests for rate limiting middleware with actual HTTP requests."""

    async def test_rate_limit_headers_included(self):
        """Rate limit headers are included in responses."""
        app = FastAPI()
        app.add_middleware(RateLimitMiddleware)

        @app.get("/test")
        async def test_endpoint():
            return {"status": "ok"}

        # Create a non-exempt request
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            # Mock the request state to make it non-exempt
            with patch("spaps_server_quickstart.middleware.rate_limiting.is_rate_limit_exempt", return_value=False):
                response = await client.get("/test")

        assert response.status_code == 200
        assert "X-RateLimit-Limit" in response.headers
        assert "X-RateLimit-Remaining" in response.headers

    async def test_rate_limit_exceeded_returns_429(self):
        """Requests over limit return 429 with appropriate error response."""
        from spaps_server_quickstart.middleware.rate_limiting import _store

        # Clear store before test
        _store.clear()

        app = FastAPI()
        app.add_middleware(RateLimitMiddleware)

        @app.get("/api/auth/magic-link")
        async def magic_link():
            return {"status": "sent"}

        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("spaps_server_quickstart.middleware.rate_limiting.is_rate_limit_exempt", return_value=False):
                with patch("spaps_server_quickstart.middleware.rate_limiting.get_rate_limit_key", return_value="test-client"):
                    # Make STRICT.max_requests (5) successful requests
                    for i in range(STRICT.max_requests):
                        response = await client.get("/api/auth/magic-link")
                        assert response.status_code == 200, f"Request {i+1} should succeed"

                    # Next request should be rate limited
                    response = await client.get("/api/auth/magic-link")

        assert response.status_code == 429
        data = response.json()
        assert data["success"] is False
        assert data["error"]["code"] == "RATE_LIMIT_EXCEEDED"
        assert "Retry-After" in response.headers
        assert response.headers["X-RateLimit-Remaining"] == "0"

        # Clean up
        _store.clear()

    async def test_exempt_requests_bypass_rate_limiting(self):
        """Exempt requests (local mode) bypass rate limiting."""
        from spaps_server_quickstart.middleware.rate_limiting import _store
        _store.clear()

        app = FastAPI()
        app.add_middleware(RateLimitMiddleware)

        @app.get("/api/auth/magic-link")
        async def magic_link():
            return {"status": "sent"}

        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("spaps_server_quickstart.middleware.rate_limiting.is_rate_limit_exempt", return_value=True):
                # Make many more requests than the limit
                for _ in range(STRICT.max_requests * 2):
                    response = await client.get("/api/auth/magic-link")
                    assert response.status_code == 200

        _store.clear()

    async def test_local_mode_setting_bypasses_rate_limiting_without_state(self):
        """App-level local mode should bypass limits before dependency execution."""
        from spaps_server_quickstart.middleware.rate_limiting import _store
        _store.clear()

        app = FastAPI()
        app.state.settings = MagicMock(is_spaps_local_mode=True)
        app.add_middleware(RateLimitMiddleware)

        @app.get("/api/auth/magic-link")
        async def magic_link():
            return {"status": "sent"}

        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            for _ in range(STRICT.max_requests * 2):
                response = await client.get("/api/auth/magic-link")
                assert response.status_code == 200

        _store.clear()
