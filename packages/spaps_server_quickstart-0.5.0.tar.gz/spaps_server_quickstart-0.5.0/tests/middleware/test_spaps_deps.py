"""Unit tests for the spaps_deps middleware module.

Tests get_application(), get_current_user(), get_optional_user(),
require_admin_user(), and require_super_admin_user() with mocked
Request objects, database sessions, and settings.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

from spaps_server_quickstart.domains.errors import (
    ForbiddenError,
    InvalidApplicationError,
    UnauthorizedError,
)
from spaps_server_quickstart.middleware.api_key import KeyType
from spaps_server_quickstart.middleware.jwt_auth import AuthenticatedUser
from spaps_server_quickstart.middleware.local_mode import (
    LOCAL_APPLICATION,
    LOCAL_USERS,
    LocalApplication,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_settings(*, local_mode: bool = False, jwt_secret: str = "test-secret"):
    """Return a mock settings object."""
    s = MagicMock()
    s.is_spaps_local_mode = local_mode
    s.jwt_secret = jwt_secret
    return s


def _make_request(
    *,
    settings=None,
    headers: dict[str, str] | None = None,
    query_params: dict[str, str] | None = None,
):
    """Return a mock FastAPI Request with app.state.settings wired."""
    req = MagicMock()
    req.app.state.settings = settings or _make_settings()
    req.headers = headers or {}
    req.query_params = query_params or {}
    req.url.path = "/api/auth/login"
    # request.state needs to support attribute assignment
    req.state = MagicMock()
    return req


def _make_application(**overrides):
    """Return a mock Application."""
    defaults = dict(
        id=uuid4(),
        name="Test App",
        slug="test-app",
        allowed_origins=["https://example.com"],
    )
    defaults.update(overrides)
    app = MagicMock()
    for k, v in defaults.items():
        setattr(app, k, v)
    return app


# ===========================================================================
# get_application
# ===========================================================================


class TestGetApplicationLocalMode:
    @pytest.mark.asyncio
    async def test_local_mode_returns_local_application(self):
        from spaps_server_quickstart.middleware.spaps_deps import get_application

        settings = _make_settings(local_mode=True)
        req = _make_request(settings=settings)
        session = AsyncMock()

        result = await get_application(req, session)

        assert result is LOCAL_APPLICATION
        assert req.state.is_local_mode is True
        assert req.state.application is LOCAL_APPLICATION
        assert req.state.key_type == KeyType.SECRET

    @pytest.mark.asyncio
    async def test_local_mode_sets_default_local_user(self):
        from spaps_server_quickstart.middleware.spaps_deps import get_application

        settings = _make_settings(local_mode=True)
        req = _make_request(settings=settings)
        session = AsyncMock()

        await get_application(req, session)

        assert req.state.local_user == LOCAL_USERS["user"]

    @pytest.mark.asyncio
    async def test_local_mode_respects_x_test_user_header(self):
        from spaps_server_quickstart.middleware.spaps_deps import get_application

        settings = _make_settings(local_mode=True)
        req = _make_request(settings=settings, headers={"X-Test-User": "admin"})
        session = AsyncMock()

        await get_application(req, session)

        assert req.state.local_user == LOCAL_USERS["admin"]

    @pytest.mark.asyncio
    async def test_local_mode_respects_user_query_param(self):
        from spaps_server_quickstart.middleware.spaps_deps import get_application

        settings = _make_settings(local_mode=True)
        req = _make_request(settings=settings, query_params={"_user": "premium"})
        session = AsyncMock()

        await get_application(req, session)

        assert req.state.local_user == LOCAL_USERS["premium"]


class TestGetApplicationApiKey:
    @pytest.mark.asyncio
    async def test_missing_api_key_raises_invalid_application(self):
        from spaps_server_quickstart.middleware.spaps_deps import get_application

        req = _make_request(headers={})
        session = AsyncMock()

        with pytest.raises(InvalidApplicationError, match="Missing API key"):
            await get_application(req, session)

    @pytest.mark.asyncio
    async def test_invalid_api_key_raises_invalid_application(self):
        from spaps_server_quickstart.middleware.spaps_deps import get_application

        req = _make_request(headers={"X-API-Key": "bad_key"})
        session = AsyncMock()

        with patch(
            "spaps_server_quickstart.middleware.api_key.validate_api_key",
            return_value=(None, KeyType.LEGACY),
        ):
            with pytest.raises(InvalidApplicationError, match="Invalid API key"):
                await get_application(req, session)

    @pytest.mark.asyncio
    async def test_valid_secret_key_sets_state(self):
        from spaps_server_quickstart.middleware.spaps_deps import get_application

        mock_app = _make_application()
        req = _make_request(headers={"X-API-Key": "spaps_sec_valid"})
        session = AsyncMock()

        with patch(
            "spaps_server_quickstart.middleware.api_key.validate_api_key",
            return_value=(mock_app, KeyType.SECRET),
        ):
            result = await get_application(req, session)

        assert result is mock_app
        assert req.state.application is mock_app
        assert req.state.key_type == KeyType.SECRET

    @pytest.mark.asyncio
    async def test_publishable_key_blocked_on_restricted_endpoint(self):
        from spaps_server_quickstart.middleware.spaps_deps import get_application

        mock_app = _make_application()
        req = _make_request(headers={"X-API-Key": "spaps_pub_test"})
        req.url.path = "/api/admin/create-app"  # Not in publishable allowlist
        session = AsyncMock()

        with patch(
            "spaps_server_quickstart.middleware.api_key.validate_api_key",
            return_value=(mock_app, KeyType.PUBLISHABLE),
        ), patch(
            "spaps_server_quickstart.middleware.key_scope.is_endpoint_allowed_for_publishable",
            return_value=False,
        ):
            with pytest.raises(
                InvalidApplicationError, match="requires a secret key"
            ):
                await get_application(req, session)

    @pytest.mark.asyncio
    async def test_publishable_key_origin_not_allowed(self):
        from spaps_server_quickstart.middleware.spaps_deps import get_application

        mock_app = _make_application(allowed_origins=["https://allowed.com"])
        req = _make_request(
            headers={
                "X-API-Key": "spaps_pub_test",
                "Origin": "https://evil.com",
            }
        )
        req.url.path = "/api/auth/login"
        session = AsyncMock()

        with patch(
            "spaps_server_quickstart.middleware.api_key.validate_api_key",
            return_value=(mock_app, KeyType.PUBLISHABLE),
        ), patch(
            "spaps_server_quickstart.middleware.key_scope.is_endpoint_allowed_for_publishable",
            return_value=True,
        ), patch(
            "spaps_server_quickstart.middleware.origin_validation.validate_origin",
            return_value=False,
        ):
            with pytest.raises(InvalidApplicationError, match="Origin not allowed"):
                await get_application(req, session)

    @pytest.mark.asyncio
    async def test_publishable_key_allowed_origin_succeeds(self):
        from spaps_server_quickstart.middleware.spaps_deps import get_application

        mock_app = _make_application(allowed_origins=["https://allowed.com"])
        req = _make_request(
            headers={
                "X-API-Key": "spaps_pub_test",
                "Origin": "https://allowed.com",
            }
        )
        req.url.path = "/api/auth/login"
        session = AsyncMock()

        with patch(
            "spaps_server_quickstart.middleware.api_key.validate_api_key",
            return_value=(mock_app, KeyType.PUBLISHABLE),
        ), patch(
            "spaps_server_quickstart.middleware.key_scope.is_endpoint_allowed_for_publishable",
            return_value=True,
        ), patch(
            "spaps_server_quickstart.middleware.origin_validation.validate_origin",
            return_value=True,
        ):
            result = await get_application(req, session)

        assert result is mock_app


# ===========================================================================
# get_current_user
# ===========================================================================


class TestGetCurrentUserLocalMode:
    @pytest.mark.asyncio
    async def test_local_mode_returns_authenticated_user(self):
        from spaps_server_quickstart.middleware.spaps_deps import get_current_user

        settings = _make_settings(local_mode=True)
        req = _make_request(settings=settings)
        req.state.is_local_mode = True
        local_user = LOCAL_USERS["admin"]
        req.state.local_user = local_user
        mock_app = LocalApplication()
        session = AsyncMock()

        result = await get_current_user(req, session, mock_app)

        assert isinstance(result, AuthenticatedUser)
        assert result.id == local_user.id
        assert result.email == local_user.email
        assert result.is_admin is True
        assert result.is_super_admin is True


class TestGetCurrentUserJwt:
    @pytest.mark.asyncio
    async def test_missing_jwt_raises_unauthorized(self):
        from spaps_server_quickstart.middleware.spaps_deps import get_current_user

        req = _make_request()
        req.state.is_local_mode = False
        mock_app = _make_application()
        session = AsyncMock()

        with patch(
            "spaps_server_quickstart.middleware.jwt_auth.extract_bearer_token",
            return_value=None,
        ):
            with pytest.raises(UnauthorizedError, match="Authentication required"):
                await get_current_user(req, session, mock_app)

    @pytest.mark.asyncio
    async def test_valid_jwt_sets_user_state(self):
        from spaps_server_quickstart.middleware.spaps_deps import get_current_user

        app_id = str(uuid4())
        req = _make_request()
        req.state.is_local_mode = False
        req.state.application_id = app_id
        mock_app = _make_application(id=app_id)
        session = AsyncMock()

        mock_user = AuthenticatedUser(
            id="user-123",
            email="test@example.com",
            application_id=app_id,
        )
        mock_payload = {"sub": "user-123", "app_id": app_id}

        with patch(
            "spaps_server_quickstart.middleware.jwt_auth.extract_bearer_token",
            return_value="valid.jwt.token",
        ), patch(
            "spaps_server_quickstart.middleware.jwt_auth.authenticate_jwt",
            return_value=(mock_payload, mock_user),
        ):
            result = await get_current_user(req, session, mock_app)

        assert result is mock_user
        assert req.state.user is mock_user
        assert req.state.jwt_payload == mock_payload

    @pytest.mark.asyncio
    async def test_tm012_app_mismatch_raises_forbidden(self):
        """TM-012: JWT app_id must match API key's application_id."""
        from spaps_server_quickstart.middleware.spaps_deps import get_current_user

        api_key_app_id = str(uuid4())
        jwt_app_id = str(uuid4())  # Different app

        req = _make_request()
        req.state.is_local_mode = False
        req.state.application_id = api_key_app_id
        mock_app = _make_application(id=api_key_app_id)
        session = AsyncMock()

        mock_user = AuthenticatedUser(
            id="user-123",
            application_id=jwt_app_id,
        )
        mock_payload = {"sub": "user-123", "app_id": jwt_app_id}

        with patch(
            "spaps_server_quickstart.middleware.jwt_auth.extract_bearer_token",
            return_value="valid.jwt.token",
        ), patch(
            "spaps_server_quickstart.middleware.jwt_auth.authenticate_jwt",
            return_value=(mock_payload, mock_user),
        ):
            with pytest.raises(ForbiddenError, match="Token application mismatch"):
                await get_current_user(req, session, mock_app)


# ===========================================================================
# get_optional_user
# ===========================================================================


class TestGetOptionalUser:
    @pytest.mark.asyncio
    async def test_no_jwt_returns_none(self):
        from spaps_server_quickstart.middleware.spaps_deps import get_optional_user

        req = _make_request()
        req.state.is_local_mode = False
        mock_app = _make_application()
        session = AsyncMock()

        with patch(
            "spaps_server_quickstart.middleware.jwt_auth.extract_bearer_token",
            return_value=None,
        ):
            result = await get_optional_user(req, session, mock_app)

        assert result is None

    @pytest.mark.asyncio
    async def test_valid_jwt_returns_user(self):
        from spaps_server_quickstart.middleware.spaps_deps import get_optional_user

        app_id = str(uuid4())
        req = _make_request()
        req.state.is_local_mode = False
        req.state.application_id = app_id
        mock_app = _make_application(id=app_id)
        session = AsyncMock()

        mock_user = AuthenticatedUser(
            id="user-123",
            application_id=app_id,
        )
        mock_payload = {"sub": "user-123", "app_id": app_id}

        with patch(
            "spaps_server_quickstart.middleware.jwt_auth.extract_bearer_token",
            return_value="valid.jwt.token",
        ), patch(
            "spaps_server_quickstart.middleware.jwt_auth.authenticate_jwt",
            return_value=(mock_payload, mock_user),
        ):
            result = await get_optional_user(req, session, mock_app)

        assert result is mock_user

    @pytest.mark.asyncio
    async def test_tm012_app_mismatch_returns_none(self):
        """TM-012: For optional user, app mismatch silently returns None."""
        from spaps_server_quickstart.middleware.spaps_deps import get_optional_user

        api_key_app_id = str(uuid4())
        jwt_app_id = str(uuid4())

        req = _make_request()
        req.state.is_local_mode = False
        req.state.application_id = api_key_app_id
        mock_app = _make_application(id=api_key_app_id)
        session = AsyncMock()

        mock_user = AuthenticatedUser(
            id="user-123",
            application_id=jwt_app_id,
        )
        mock_payload = {"sub": "user-123", "app_id": jwt_app_id}

        with patch(
            "spaps_server_quickstart.middleware.jwt_auth.extract_bearer_token",
            return_value="valid.jwt.token",
        ), patch(
            "spaps_server_quickstart.middleware.jwt_auth.authenticate_jwt",
            return_value=(mock_payload, mock_user),
        ):
            result = await get_optional_user(req, session, mock_app)

        assert result is None

    @pytest.mark.asyncio
    async def test_invalid_jwt_returns_none(self):
        """Invalid JWT should return None, not raise."""
        from spaps_server_quickstart.domains.errors import InvalidTokenError
        from spaps_server_quickstart.middleware.spaps_deps import get_optional_user

        req = _make_request()
        req.state.is_local_mode = False
        mock_app = _make_application()
        session = AsyncMock()

        with patch(
            "spaps_server_quickstart.middleware.jwt_auth.extract_bearer_token",
            return_value="bad.jwt.token",
        ), patch(
            "spaps_server_quickstart.middleware.jwt_auth.authenticate_jwt",
            side_effect=InvalidTokenError("expired"),
        ):
            result = await get_optional_user(req, session, mock_app)

        assert result is None

    @pytest.mark.asyncio
    async def test_local_mode_returns_authenticated_user(self):
        from spaps_server_quickstart.middleware.spaps_deps import get_optional_user

        settings = _make_settings(local_mode=True)
        req = _make_request(settings=settings)
        req.state.is_local_mode = True
        req.state.local_user = LOCAL_USERS["user"]
        mock_app = LocalApplication()
        session = AsyncMock()

        result = await get_optional_user(req, session, mock_app)

        assert isinstance(result, AuthenticatedUser)
        assert result.id == LOCAL_USERS["user"].id


# ===========================================================================
# require_admin_user / require_super_admin_user
# ===========================================================================


class TestRequireAdminUser:
    @pytest.mark.asyncio
    async def test_allows_admin(self):
        from spaps_server_quickstart.middleware.spaps_deps import require_admin_user

        admin_user = AuthenticatedUser(id="admin-1", is_admin=True)
        result = await require_admin_user(admin_user)
        assert result is admin_user

    @pytest.mark.asyncio
    async def test_rejects_non_admin(self):
        from spaps_server_quickstart.middleware.spaps_deps import require_admin_user

        user = AuthenticatedUser(id="user-1", is_admin=False, roles=["user"])
        with pytest.raises(ForbiddenError, match="Admin access required"):
            await require_admin_user(user)


class TestRequireSuperAdminUser:
    @pytest.mark.asyncio
    async def test_allows_super_admin(self):
        from spaps_server_quickstart.middleware.spaps_deps import (
            require_super_admin_user,
        )

        super_admin = AuthenticatedUser(id="sa-1", is_super_admin=True)
        result = await require_super_admin_user(super_admin)
        assert result is super_admin

    @pytest.mark.asyncio
    async def test_rejects_regular_admin(self):
        from spaps_server_quickstart.middleware.spaps_deps import (
            require_super_admin_user,
        )

        admin = AuthenticatedUser(
            id="admin-1", is_admin=True, is_super_admin=False, roles=["admin"]
        )
        with pytest.raises(ForbiddenError, match="Super admin access required"):
            await require_super_admin_user(admin)
