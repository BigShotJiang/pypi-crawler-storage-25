"""Unit tests for the key_scope middleware module.

Tests is_endpoint_allowed_for_publishable() with various path patterns
including exact matches, prefix matches, and blocked paths.
"""

from __future__ import annotations

from spaps_server_quickstart.middleware.key_scope import (
    is_endpoint_allowed_for_publishable,
)


# ===========================================================================
# is_endpoint_allowed_for_publishable
# ===========================================================================


class TestIsEndpointAllowedForPublishable:
    # --- Exact-match allowed paths ---

    def test_allows_auth_login(self):
        assert is_endpoint_allowed_for_publishable("/api/auth/login") is True

    def test_allows_auth_register(self):
        assert is_endpoint_allowed_for_publishable("/api/auth/register") is True

    def test_allows_auth_refresh(self):
        assert is_endpoint_allowed_for_publishable("/api/auth/refresh") is True

    def test_allows_auth_logout(self):
        assert is_endpoint_allowed_for_publishable("/api/auth/logout") is True

    def test_allows_auth_nonce(self):
        assert is_endpoint_allowed_for_publishable("/api/auth/nonce") is True

    def test_allows_sessions(self):
        assert is_endpoint_allowed_for_publishable("/api/sessions") is True

    def test_allows_sessions_validate(self):
        assert is_endpoint_allowed_for_publishable("/api/sessions/validate") is True

    def test_allows_health(self):
        assert is_endpoint_allowed_for_publishable("/health") is True

    def test_allows_stripe_checkout(self):
        assert is_endpoint_allowed_for_publishable("/api/stripe/checkout-sessions") is True

    def test_allows_entitlements(self):
        assert is_endpoint_allowed_for_publishable("/api/entitlements") is True

    def test_allows_issue_reports(self):
        assert is_endpoint_allowed_for_publishable("/api/v1/issue-reports") is True

    def test_allows_auth_user(self):
        assert is_endpoint_allowed_for_publishable("/api/auth/user") is True

    # --- Prefix-match allowed paths (trailing slash in whitelist) ---

    def test_allows_solana_sub_path(self):
        assert is_endpoint_allowed_for_publishable("/api/auth/solana/nonce") is True

    def test_allows_ethereum_sub_path(self):
        assert is_endpoint_allowed_for_publishable("/api/auth/ethereum/verify") is True

    def test_allows_usage_sub_path(self):
        assert is_endpoint_allowed_for_publishable("/api/usage/balance") is True

    def test_allows_docs_sub_path(self):
        assert is_endpoint_allowed_for_publishable("/api/docs/openapi") is True

    def test_allows_cli_device_sub_path(self):
        assert is_endpoint_allowed_for_publishable("/api/cli/device/poll") is True

    def test_allows_issue_report_sub_path(self):
        assert is_endpoint_allowed_for_publishable("/api/v1/issue-reports/status") is True

    # --- Slash-appended sub-path for exact entries ---

    def test_allows_dayrate_availability(self):
        assert is_endpoint_allowed_for_publishable("/api/dayrate/availability") is True

    def test_allows_dayrate_book(self):
        assert is_endpoint_allowed_for_publishable("/api/dayrate/book") is True

    def test_allows_dayrate_book_multi(self):
        assert is_endpoint_allowed_for_publishable("/api/dayrate/book-multi") is True

    # --- Blocked paths ---

    def test_blocks_admin_path(self):
        assert is_endpoint_allowed_for_publishable("/api/admin/users") is False

    def test_blocks_applications_path(self):
        assert is_endpoint_allowed_for_publishable("/api/applications") is False

    def test_blocks_internal_path(self):
        assert is_endpoint_allowed_for_publishable("/api/internal/metrics") is False

    def test_blocks_random_unknown_path(self):
        assert is_endpoint_allowed_for_publishable("/api/something/random") is False

    def test_blocks_empty_path(self):
        assert is_endpoint_allowed_for_publishable("") is False

    def test_blocks_root_path(self):
        assert is_endpoint_allowed_for_publishable("/") is False

    def test_blocks_whitelist_path(self):
        assert is_endpoint_allowed_for_publishable("/api/whitelist") is False
