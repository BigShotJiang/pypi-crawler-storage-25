"""Unit tests for the local_mode middleware module.

Tests get_local_user() with various user persona selections,
missing parameters, and header-based fallback.
"""

from __future__ import annotations

from spaps_server_quickstart.middleware.local_mode import (
    DEFAULT_LOCAL_USER,
    LOCAL_USERS,
    LocalTestUser,
    get_local_user,
)


# ===========================================================================
# get_local_user
# ===========================================================================


class TestGetLocalUserByParam:
    """Selecting test personas via the _user query parameter value."""

    def test_returns_admin_user_for_admin_param(self):
        user = get_local_user("admin")

        assert isinstance(user, LocalTestUser)
        assert user.email == "buildooor@gmail.com"
        assert user.is_admin is True
        assert user.is_super_admin is True
        assert user.tier == "enterprise"
        assert "admin" in user.roles
        assert "super_admin" in user.roles

    def test_returns_regular_user_for_user_param(self):
        user = get_local_user("user")

        assert isinstance(user, LocalTestUser)
        assert user.email == "user@localhost"
        assert user.is_admin is False
        assert user.tier == "free"
        assert user.roles == ["user"]

    def test_returns_premium_user_for_premium_param(self):
        user = get_local_user("premium")

        assert isinstance(user, LocalTestUser)
        assert user.email == "premium@localhost"
        assert user.tier == "premium"
        assert user.is_admin is False

    def test_falls_back_to_default_for_unknown_persona(self):
        user = get_local_user("nonexistent")

        default = LOCAL_USERS[DEFAULT_LOCAL_USER]
        assert user.id == default.id
        assert user.email == default.email

    def test_falls_back_to_default_for_none(self):
        user = get_local_user(None)

        default = LOCAL_USERS[DEFAULT_LOCAL_USER]
        assert user.id == default.id
        assert user.email == default.email

    def test_falls_back_to_default_for_empty_string(self):
        user = get_local_user("")

        default = LOCAL_USERS[DEFAULT_LOCAL_USER]
        assert user.id == default.id
        assert user.email == default.email


class TestGetLocalUserProperties:
    """Verify structural properties of returned LocalTestUser objects."""

    def test_admin_has_comprehensive_permissions(self):
        user = get_local_user("admin")

        assert "access_admin" in user.permissions
        assert "manage_users" in user.permissions
        assert "audit_logs" in user.permissions
        assert "security_settings" in user.permissions
        assert len(user.permissions) > 10

    def test_regular_user_has_basic_permissions(self):
        user = get_local_user("user")

        assert user.permissions == ["view_products"]

    def test_all_users_have_valid_uuid_ids(self):
        for name in LOCAL_USERS:
            user = get_local_user(name)
            # Should be a valid UUID string (36 chars with hyphens)
            assert len(user.id) == 36
            assert user.id.count("-") == 4

    def test_default_user_is_regular_user(self):
        assert DEFAULT_LOCAL_USER == "user"
        default = get_local_user(None)
        assert default.email == "user@localhost"
