"""Unit tests for the jwt_auth middleware module.

Tests extract_bearer_token(), authenticate_jwt(), require_admin(),
and require_super_admin() with mocked JWT verification and sessions.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from spaps_server_quickstart.middleware.jwt_auth import (
    AuthenticatedUser,
    extract_bearer_token,
    require_admin,
    require_super_admin,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_request(headers: dict[str, str] | None = None) -> MagicMock:
    """Return a mock FastAPI Request with the given headers."""
    req = MagicMock()
    _headers = headers or {}
    req.headers = _headers
    return req


def _make_jwt_payload(**overrides):
    """Return an AccessTokenPayload with sensible defaults."""
    from spaps_server_quickstart.domains.sessions.jwt_service import AccessTokenPayload
    from datetime import datetime, UTC

    defaults = dict(
        sub="user-123",
        email="user@example.com",
        app_id="app-456",
        tier="free",
        roles=["user"],
        permissions=["view_products"],
        isAdmin=False,
        isSuperAdmin=False,
        wallets=[],
        jti="token-jti-789",
        iat=int(datetime.now(UTC).timestamp()),
        exp=int(datetime.now(UTC).timestamp()) + 3600,
        iss="spaps-auth-service",
        aud="spaps-client-apps",
    )
    defaults.update(overrides)
    return AccessTokenPayload(**defaults)


# ===========================================================================
# extract_bearer_token
# ===========================================================================


class TestExtractBearerToken:
    def test_extracts_valid_jwt_from_authorization_header(self):
        jwt = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0In0.signature"
        req = _make_request({"Authorization": f"Bearer {jwt}"})
        assert extract_bearer_token(req) == jwt

    def test_returns_none_when_no_authorization_header(self):
        req = _make_request({})
        assert extract_bearer_token(req) is None

    def test_returns_none_for_non_bearer_authorization(self):
        req = _make_request({"Authorization": "Basic dXNlcjpwYXNz"})
        assert extract_bearer_token(req) is None

    def test_returns_none_for_non_jwt_bearer_token(self):
        # Not a JWT (doesn't have 3 parts separated by dots)
        req = _make_request({"Authorization": "Bearer spaps_sec_api_key"})
        assert extract_bearer_token(req) is None

    def test_returns_none_for_malformed_jwt(self):
        # Only 2 parts (missing signature)
        req = _make_request({"Authorization": "Bearer header.payload"})
        assert extract_bearer_token(req) is None

    def test_returns_none_for_empty_bearer(self):
        req = _make_request({"Authorization": "Bearer "})
        assert extract_bearer_token(req) is None


# ===========================================================================
# authenticate_jwt
# ===========================================================================


class TestAuthenticateJwt:
    @pytest.mark.asyncio
    async def test_successful_authentication_returns_payload_and_user(self):
        from spaps_server_quickstart.middleware.jwt_auth import authenticate_jwt

        jwt = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0In0.signature"
        payload = _make_jwt_payload(
            sub="user-123",
            email="test@example.com",
            app_id="app-456",
            tier="premium",
            roles=["user", "premium"],
            permissions=["view_products", "create_orders"],
            isAdmin=False,
            isSuperAdmin=False,
            wallets=["0x123"],
            jti="jti-789",
        )

        # Patch the imported function inside authenticate_jwt
        with patch("spaps_server_quickstart.domains.sessions.jwt_service.verify_access_token") as mock_verify:
            mock_verify.return_value = payload

            payload_dict, user = await authenticate_jwt(jwt, jwt_secret="secret")

            assert payload_dict["sub"] == "user-123"
            assert user.id == "user-123"
            assert user.email == "test@example.com"
            assert user.tier == "premium"
            assert user.roles == ["user", "premium"]
            assert user.permissions == ["view_products", "create_orders"]
            assert user.is_admin is False
            assert user.wallet_addresses == ["0x123"]
            assert user.jti == "jti-789"

    @pytest.mark.asyncio
    async def test_raises_invalid_token_error_on_verification_failure(self):
        from spaps_server_quickstart.domains.errors import InvalidTokenError
        from spaps_server_quickstart.middleware.jwt_auth import authenticate_jwt

        jwt = "invalid.jwt.token"

        with patch("spaps_server_quickstart.domains.sessions.jwt_service.verify_access_token") as mock_verify:
            mock_verify.side_effect = Exception("Signature verification failed")

            with pytest.raises(InvalidTokenError, match="Invalid or expired access token"):
                await authenticate_jwt(jwt, jwt_secret="secret")

    @pytest.mark.asyncio
    async def test_raises_invalid_token_error_on_blacklisted_token(self):
        from spaps_server_quickstart.domains.errors import InvalidTokenError
        from spaps_server_quickstart.middleware.jwt_auth import authenticate_jwt

        jwt = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0In0.signature"
        payload = _make_jwt_payload(jti="blacklisted-jti")
        mock_session = AsyncMock()

        with patch("spaps_server_quickstart.domains.sessions.jwt_service.verify_access_token") as mock_verify, \
             patch("spaps_server_quickstart.domains.sessions.blacklist_service.is_blacklisted") as mock_blacklist:
            mock_verify.return_value = payload
            mock_blacklist.return_value = True

            with pytest.raises(InvalidTokenError, match="Token has been revoked"):
                await authenticate_jwt(jwt, jwt_secret="secret", session=mock_session)

    @pytest.mark.asyncio
    async def test_skips_blacklist_check_when_no_session_provided(self):
        from spaps_server_quickstart.middleware.jwt_auth import authenticate_jwt

        jwt = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0In0.signature"
        payload = _make_jwt_payload(jti="some-jti")

        with patch("spaps_server_quickstart.domains.sessions.jwt_service.verify_access_token") as mock_verify:
            mock_verify.return_value = payload

            payload_dict, user = await authenticate_jwt(jwt, jwt_secret="secret", session=None)

            # Should succeed without blacklist check
            assert user.id == payload.sub

    @pytest.mark.asyncio
    async def test_builds_user_with_admin_claims(self):
        from spaps_server_quickstart.middleware.jwt_auth import authenticate_jwt

        jwt = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0In0.signature"
        payload = _make_jwt_payload(
            sub="admin-123",
            email="admin@example.com",
            roles=["admin", "super_admin"],
            permissions=["access_admin", "manage_users"],
            isAdmin=True,
            isSuperAdmin=True,
        )

        with patch("spaps_server_quickstart.domains.sessions.jwt_service.verify_access_token") as mock_verify:
            mock_verify.return_value = payload

            payload_dict, user = await authenticate_jwt(jwt, jwt_secret="secret")

            assert user.is_admin is True
            assert user.is_super_admin is True
            assert "admin" in user.roles
            assert "super_admin" in user.roles


# ===========================================================================
# require_admin
# ===========================================================================


class TestRequireAdmin:
    def test_allows_admin_user(self):
        user = AuthenticatedUser(id="admin-1", is_admin=True)
        # Should not raise
        require_admin(user)

    def test_allows_user_with_admin_role(self):
        user = AuthenticatedUser(id="admin-2", roles=["admin"])
        # Should not raise
        require_admin(user)

    def test_raises_forbidden_error_for_non_admin(self):
        from spaps_server_quickstart.domains.errors import ForbiddenError

        user = AuthenticatedUser(id="user-1", is_admin=False, roles=["user"])

        with pytest.raises(ForbiddenError, match="Admin access required"):
            require_admin(user)


# ===========================================================================
# require_super_admin
# ===========================================================================


class TestRequireSuperAdmin:
    def test_allows_super_admin_user(self):
        user = AuthenticatedUser(id="super-1", is_super_admin=True)
        # Should not raise
        require_super_admin(user)

    def test_allows_user_with_super_admin_role(self):
        user = AuthenticatedUser(id="super-2", roles=["super_admin"])
        # Should not raise
        require_super_admin(user)

    def test_raises_forbidden_error_for_non_super_admin(self):
        from spaps_server_quickstart.domains.errors import ForbiddenError

        user = AuthenticatedUser(id="user-1", is_super_admin=False, roles=["user"])

        with pytest.raises(ForbiddenError, match="Super admin access required"):
            require_super_admin(user)

    def test_raises_forbidden_error_for_regular_admin(self):
        from spaps_server_quickstart.domains.errors import ForbiddenError

        user = AuthenticatedUser(id="admin-1", is_admin=True, is_super_admin=False, roles=["admin"])

        with pytest.raises(ForbiddenError, match="Super admin access required"):
            require_super_admin(user)


# ===========================================================================
# AuthenticatedUser dataclass
# ===========================================================================


class TestAuthenticatedUser:
    def test_default_values(self):
        user = AuthenticatedUser(id="user-1")
        assert user.id == "user-1"
        assert user.email is None
        assert user.roles == ["user"]
        assert user.permissions == ["view_products"]
        assert user.is_admin is False
        assert user.is_super_admin is False
        assert user.wallet_addresses == []

    def test_custom_values(self):
        user = AuthenticatedUser(
            id="user-2",
            email="test@example.com",
            username="testuser",
            tier="premium",
            roles=["premium", "user"],
            permissions=["view_products", "create_orders"],
            wallet_addresses=["0xabc", "0xdef"],
        )
        assert user.id == "user-2"
        assert user.email == "test@example.com"
        assert user.tier == "premium"
        assert len(user.wallet_addresses) == 2
