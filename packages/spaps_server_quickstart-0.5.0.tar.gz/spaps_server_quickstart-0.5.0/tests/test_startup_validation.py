"""
Tests for startup validation functionality.

TDD: These tests were written first per docs/TDD_PLAN.md.
"""

from __future__ import annotations

from unittest.mock import patch

import pytest

from spaps_server_quickstart.settings import BaseServiceSettings


class _ValidSettings(BaseServiceSettings):
    """Test settings with valid defaults."""

    app_name: str = "Test Service"
    database_url: str = "postgresql+asyncpg://user:secret@localhost:5432/testdb"


class AuthEnabledSettings(BaseServiceSettings):
    """Test settings with SPAPS auth enabled."""

    app_name: str = "Auth Service"
    database_url: str = "postgresql+asyncpg://user:pass@localhost:5432/authdb"
    spaps_auth_enabled: bool = True
    spaps_api_key: str = "test-api-key"
    spaps_application_id: str = "test-app-id"
    spaps_api_url: str = "https://api.test.com"


class SpapsTokenSettings(BaseServiceSettings):
    """Test settings that include SPAPS token-signing fields."""

    app_name: str = "SPAPS Test"
    database_url: str = "postgresql+asyncpg://user:pass@localhost:5432/spapsdb"
    jwt_secret: str = "jwt-secret-for-tests"
    refresh_token_secret: str = "refresh-secret-for-tests"


# Alias for cleaner test code
TestSettings = _ValidSettings


# =============================================================================
# Tests for validate_settings()
# =============================================================================


def test_validate_settings_passes_valid_config() -> None:
    """Valid configuration should pass validation without errors."""
    from spaps_server_quickstart.startup import validate_settings

    settings = TestSettings()
    # Should not raise
    validate_settings(settings)


def test_validate_settings_missing_database_url() -> None:
    """Missing DATABASE_URL should fail validation."""

    class EmptyDbSettings(BaseServiceSettings):
        database_url: str = ""

    # Pydantic validator catches this first, but our validate_settings should too
    with pytest.raises(ValueError):
        EmptyDbSettings()


def test_validate_settings_invalid_database_url_prefix() -> None:
    """DATABASE_URL must start with postgresql."""
    from spaps_server_quickstart.startup import validate_settings

    class BadUrlSettings(BaseServiceSettings):
        database_url: str = "mysql://user:pass@localhost/db"

    settings = BadUrlSettings()
    with pytest.raises(RuntimeError, match="must start with 'postgresql'"):
        validate_settings(settings)


def test_validate_settings_spaps_auth_requires_api_key() -> None:
    """SPAPS auth enabled without API key should fail."""
    from spaps_server_quickstart.startup import validate_settings

    class MissingKeySettings(BaseServiceSettings):
        database_url: str = "postgresql+asyncpg://user:pass@localhost/db"
        spaps_auth_enabled: bool = True
        spaps_api_key: str | None = None
        spaps_application_id: str = "app-id"
        spaps_api_url: str = "https://api.test.com"

    settings = MissingKeySettings()
    with pytest.raises(RuntimeError, match="SPAPS_API_KEY is required"):
        validate_settings(settings)


def test_validate_settings_spaps_auth_requires_application_id() -> None:
    """SPAPS auth enabled without application ID should fail."""
    from spaps_server_quickstart.startup import validate_settings

    class MissingAppIdSettings(BaseServiceSettings):
        database_url: str = "postgresql+asyncpg://user:pass@localhost/db"
        spaps_auth_enabled: bool = True
        spaps_api_key: str = "test-key"
        spaps_application_id: str | None = None
        spaps_api_url: str = "https://api.test.com"

    settings = MissingAppIdSettings()
    with pytest.raises(RuntimeError, match="SPAPS_APPLICATION_ID is required"):
        validate_settings(settings)


def test_validate_settings_spaps_auth_requires_api_url() -> None:
    """SPAPS auth enabled without API URL should fail."""
    from spaps_server_quickstart.startup import validate_settings

    class MissingUrlSettings(BaseServiceSettings):
        database_url: str = "postgresql+asyncpg://user:pass@localhost/db"
        spaps_auth_enabled: bool = True
        spaps_api_key: str = "test-key"
        spaps_application_id: str = "app-id"
        spaps_api_url: str = ""

    settings = MissingUrlSettings()
    with pytest.raises(RuntimeError, match="SPAPS_API_URL is required"):
        validate_settings(settings)


def test_validate_settings_collects_all_errors() -> None:
    """Multiple validation errors should all be reported."""
    from spaps_server_quickstart.startup import validate_settings

    class MultiErrorSettings(BaseServiceSettings):
        database_url: str = "mysql://user:pass@localhost/db"  # Wrong prefix
        spaps_auth_enabled: bool = True
        spaps_api_key: str | None = None  # Missing
        spaps_application_id: str | None = None  # Missing
        spaps_api_url: str = ""  # Missing

    settings = MultiErrorSettings()
    with pytest.raises(RuntimeError) as exc_info:
        validate_settings(settings)

    error_msg = str(exc_info.value)
    assert "postgresql" in error_msg
    assert "SPAPS_API_KEY" in error_msg
    assert "SPAPS_APPLICATION_ID" in error_msg
    assert "SPAPS_API_URL" in error_msg


def test_validate_settings_passes_with_auth_enabled_and_all_fields() -> None:
    """SPAPS auth with all required fields should pass."""
    from spaps_server_quickstart.startup import validate_settings

    settings = AuthEnabledSettings()
    # Should not raise
    validate_settings(settings)


def test_validate_settings_requires_jwt_secret_when_field_present() -> None:
    """SPAPS settings must not allow empty JWT_SECRET."""
    from spaps_server_quickstart.startup import validate_settings

    class MissingJwtSecretSettings(SpapsTokenSettings):
        jwt_secret: str = ""

    settings = MissingJwtSecretSettings()
    with pytest.raises(RuntimeError, match="JWT_SECRET is required"):
        validate_settings(settings)


def test_validate_settings_requires_refresh_secret_when_field_present() -> None:
    """SPAPS settings must not allow empty REFRESH_TOKEN_SECRET."""
    from spaps_server_quickstart.startup import validate_settings

    class MissingRefreshSecretSettings(SpapsTokenSettings):
        refresh_token_secret: str = ""

    settings = MissingRefreshSecretSettings()
    with pytest.raises(RuntimeError, match="REFRESH_TOKEN_SECRET is required"):
        validate_settings(settings)


# =============================================================================
# Tests for log_startup_config()
# =============================================================================


def test_log_startup_config_masks_password() -> None:
    """Database password should be masked in startup logs."""
    from spaps_server_quickstart.startup import log_startup_config

    settings = TestSettings()

    with patch("spaps_server_quickstart.startup.logger") as mock_logger:
        log_startup_config(settings)

        mock_logger.info.assert_called_once()
        call_kwargs = mock_logger.info.call_args.kwargs

        # Password "secret" should NOT appear in logged database value
        assert "secret" not in call_kwargs["database"]
        # But masked version should
        assert "****" in call_kwargs["database"]
        assert "user" in call_kwargs["database"]


def test_log_startup_config_includes_app_name() -> None:
    """Startup logs should include app name."""
    from spaps_server_quickstart.startup import log_startup_config

    settings = TestSettings()

    with patch("spaps_server_quickstart.startup.logger") as mock_logger:
        log_startup_config(settings)

        call_kwargs = mock_logger.info.call_args.kwargs
        assert call_kwargs["app_name"] == "Test Service"


def test_log_startup_config_includes_environment() -> None:
    """Startup logs should include environment."""
    from spaps_server_quickstart.startup import log_startup_config

    class ProdSettings(BaseServiceSettings):
        env: str = "production"
        database_url: str = "postgresql+asyncpg://user:pass@localhost/db"

    settings = ProdSettings()

    with patch("spaps_server_quickstart.startup.logger") as mock_logger:
        log_startup_config(settings)

        call_kwargs = mock_logger.info.call_args.kwargs
        assert call_kwargs["environment"] == "production"


def test_log_startup_config_includes_version() -> None:
    """Startup logs should include version from env or settings."""
    from spaps_server_quickstart.startup import log_startup_config

    settings = TestSettings()

    with patch.dict("os.environ", {"GIT_COMMIT_SHA": "abc123"}):
        with patch("spaps_server_quickstart.startup.logger") as mock_logger:
            log_startup_config(settings)

            call_kwargs = mock_logger.info.call_args.kwargs
            assert call_kwargs["version"] == "abc123"


# =============================================================================
# Tests for startup_checks() integration
# =============================================================================


def test_startup_checks_calls_validate_then_log() -> None:
    """startup_checks should validate settings and log config."""
    from spaps_server_quickstart.startup import startup_checks

    settings = TestSettings()

    with patch("spaps_server_quickstart.startup.logger") as mock_logger:
        startup_checks(settings)

        # Should log startup_validation_begin, startup_config, startup_validation_complete
        calls = [call.args[0] for call in mock_logger.info.call_args_list]
        assert "startup_validation_begin" in calls
        assert "startup_config" in calls
        assert "startup_validation_complete" in calls


def test_startup_checks_raises_on_validation_failure() -> None:
    """startup_checks should raise if validation fails."""
    from spaps_server_quickstart.startup import startup_checks

    class BadSettings(BaseServiceSettings):
        database_url: str = "mysql://user:pass@localhost/db"

    settings = BadSettings()
    with pytest.raises(RuntimeError, match="Configuration validation failed"):
        startup_checks(settings)


# =============================================================================
# Tests for _mask_database_url() helper
# =============================================================================


def test_mask_database_url_standard_format() -> None:
    """Standard PostgreSQL URL password should be masked."""
    from spaps_server_quickstart.startup import _mask_database_url

    url = "postgresql+asyncpg://myuser:mysecretpassword@db.example.com:5432/mydb"
    masked = _mask_database_url(url)

    assert "mysecretpassword" not in masked
    assert "myuser" in masked
    assert "db.example.com" in masked
    assert "mydb" in masked
    assert "****" in masked


def test_mask_database_url_handles_none() -> None:
    """None URL should return placeholder."""
    from spaps_server_quickstart.startup import _mask_database_url

    masked = _mask_database_url(None)
    assert masked == "<not set>"


def test_mask_database_url_handles_empty() -> None:
    """Empty URL should return placeholder."""
    from spaps_server_quickstart.startup import _mask_database_url

    masked = _mask_database_url("")
    assert masked == "<not set>"


def test_mask_database_url_handles_unusual_format() -> None:
    """Non-standard URL format should be truncated safely."""
    from spaps_server_quickstart.startup import _mask_database_url

    url = "some-weird-connection-string-that-is-very-long"
    masked = _mask_database_url(url)

    # Should truncate long strings
    assert len(masked) <= 40
    assert "..." in masked


def test_mask_database_url_psycopg_driver() -> None:
    """psycopg driver URL should also be masked."""
    from spaps_server_quickstart.startup import _mask_database_url

    url = "postgresql+psycopg://user:password@localhost:5432/db"
    masked = _mask_database_url(url)

    assert "password" not in masked
    assert "user" in masked
    assert "****" in masked


# =============================================================================
# Tests for validate_environment()
# =============================================================================


def test_validate_environment_allows_production_keys_in_production() -> None:
    """Production environment can use production keys."""
    from spaps_server_quickstart.startup import validate_environment

    class ProdSettings(BaseServiceSettings):
        env: str = "production"
        stripe_secret_key: str = "sk_live_abc123"
        mailgun_api_key: str = "key-123"

    settings = ProdSettings()
    # Should not raise
    validate_environment(settings)


def test_validate_environment_rejects_local_mode_in_production() -> None:
    """Production environment cannot enable local mode."""
    from spaps_server_quickstart.startup import EnvironmentSafetyError, validate_environment

    class BadProdSettings(BaseServiceSettings):
        env: str = "production"
        spaps_local_mode: bool = True

    settings = BadProdSettings()
    with pytest.raises(EnvironmentSafetyError, match="SPAPS_LOCAL_MODE"):
        validate_environment(settings)


def test_validate_environment_rejects_non_https_spaps_api_url_in_production() -> None:
    """Production environment must use HTTPS for SPAPS internal URLs."""
    from spaps_server_quickstart.startup import EnvironmentSafetyError, validate_environment

    class BadProdSettings(BaseServiceSettings):
        env: str = "production"
        spaps_api_url: str = "http://api.sweetpotato.dev"

    settings = BadProdSettings()
    with pytest.raises(EnvironmentSafetyError, match="SPAPS_API_URL.*https"):
        validate_environment(settings)


def test_validate_environment_rejects_non_https_cfo_api_url_in_production() -> None:
    """Production environment must use HTTPS for CFO internal URLs."""
    from spaps_server_quickstart.startup import EnvironmentSafetyError, validate_environment

    class BadProdSettings(BaseServiceSettings):
        env: str = "production"
        cfo_api_url: str = "http://cfo.internal"

    settings = BadProdSettings()
    with pytest.raises(EnvironmentSafetyError, match="CFO_API_URL.*https"):
        validate_environment(settings)


def test_validate_environment_rejects_missing_cfo_public_key_with_qb_in_production() -> None:
    """Production QuickBooks OAuth requires CFO public key for token encryption."""
    from spaps_server_quickstart.startup import EnvironmentSafetyError, validate_environment

    class BadProdSettings(BaseServiceSettings):
        env: str = "production"
        quickbooks_client_id: str = "qb-client-id"
        quickbooks_client_secret: str = "qb-client-secret"
        cfo_public_key: str = ""

    settings = BadProdSettings()
    with pytest.raises(EnvironmentSafetyError, match="CFO_PUBLIC_KEY"):
        validate_environment(settings)


def test_validate_environment_rejects_mailgun_in_dev() -> None:
    """Development environment cannot use MAILGUN_API_KEY."""
    from spaps_server_quickstart.startup import EnvironmentSafetyError, validate_environment

    class MailgunDevSettings(BaseServiceSettings):
        env: str = "development"
        mailgun_api_key: str = "key-abc123"

    settings = MailgunDevSettings()
    with pytest.raises(EnvironmentSafetyError, match="MAILGUN_API_KEY"):
        validate_environment(settings)


def test_validate_environment_rejects_live_stripe_in_dev() -> None:
    """Development environment cannot use live Stripe keys."""
    from spaps_server_quickstart.startup import EnvironmentSafetyError, validate_environment

    class LiveStripeDevSettings(BaseServiceSettings):
        env: str = "development"
        stripe_secret_key: str = "sk_live_dangerouskey"

    settings = LiveStripeDevSettings()
    with pytest.raises(EnvironmentSafetyError, match="sk_live"):
        validate_environment(settings)


def test_validate_environment_allows_test_stripe_in_dev() -> None:
    """Development environment can use test Stripe keys."""
    from spaps_server_quickstart.startup import validate_environment

    class TestStripeDevSettings(BaseServiceSettings):
        env: str = "development"
        stripe_secret_key: str = "sk_test_safetestkey"

    settings = TestStripeDevSettings()
    # Should not raise
    validate_environment(settings)


def test_validate_environment_rejects_quickbooks_credentials_in_dev() -> None:
    """Development environment cannot use QuickBooks credentials."""
    from spaps_server_quickstart.startup import EnvironmentSafetyError, validate_environment

    class QBDevSettings(BaseServiceSettings):
        env: str = "development"
        quickbooks_client_id: str = "qb-client-id"
        quickbooks_client_secret: str = "qb-secret"

    settings = QBDevSettings()
    with pytest.raises(EnvironmentSafetyError, match="QUICKBOOKS"):
        validate_environment(settings)


def test_validate_environment_allows_quickbooks_with_force_flag_in_dev() -> None:
    """Development environment can allow QB credentials via explicit force flag."""
    from spaps_server_quickstart.startup import validate_environment

    class QBDevSettings(BaseServiceSettings):
        env: str = "development"
        quickbooks_client_id: str = "qb-client-id"
        quickbooks_client_secret: str = "qb-secret"

    settings = QBDevSettings()
    with patch.dict("os.environ", {"SPAPS_ALLOW_QUICKBOOKS_IN_NON_PRODUCTION": "true"}):
        validate_environment(settings)


def test_validate_environment_rejects_solana_mainnet_in_dev() -> None:
    """Development environment cannot use Solana mainnet."""
    from spaps_server_quickstart.startup import EnvironmentSafetyError, validate_environment

    class SolanaMainnetDevSettings(BaseServiceSettings):
        env: str = "development"
        solana_rpc_url: str = "https://api.mainnet-beta.solana.com"

    settings = SolanaMainnetDevSettings()
    with pytest.raises(EnvironmentSafetyError, match="SOLANA.*mainnet"):
        validate_environment(settings)


def test_validate_environment_rejects_ethereum_mainnet_in_dev() -> None:
    """Development environment cannot use Ethereum mainnet."""
    from spaps_server_quickstart.startup import EnvironmentSafetyError, validate_environment

    class EthMainnetDevSettings(BaseServiceSettings):
        env: str = "development"
        ethereum_rpc_url: str = "https://mainnet.infura.io"

    settings = EthMainnetDevSettings()
    with pytest.raises(EnvironmentSafetyError, match="ETHEREUM.*mainnet"):
        validate_environment(settings)


def test_validate_environment_rejects_lightning_remote_host_in_dev() -> None:
    """Development environment cannot use remote Lightning node."""
    from spaps_server_quickstart.startup import EnvironmentSafetyError, validate_environment

    class LightningRemoteDevSettings(BaseServiceSettings):
        env: str = "development"
        lightning_grpc_host: str = "lightning.production.com"

    settings = LightningRemoteDevSettings()
    with pytest.raises(EnvironmentSafetyError, match="LIGHTNING"):
        validate_environment(settings)


def test_validate_environment_allows_localhost_lightning_in_dev() -> None:
    """Development environment can use localhost Lightning."""
    from spaps_server_quickstart.startup import validate_environment

    class LightningLocalDevSettings(BaseServiceSettings):
        env: str = "development"
        lightning_grpc_host: str = "localhost"

    settings = LightningLocalDevSettings()
    # Should not raise
    validate_environment(settings)


def test_validate_environment_warns_pii_key_with_network_binding(caplog) -> None:
    """Development with PII key and network binding should warn."""
    from spaps_server_quickstart.startup import validate_environment

    class NetworkPIIDevSettings(BaseServiceSettings):
        env: str = "development"
        host: str = "0.0.0.0"
        spaps_pii_master_key: str = "pii-key-123"

    settings = NetworkPIIDevSettings()
    # Should not raise but should log warning
    with patch("spaps_server_quickstart.startup.logger") as mock_logger:
        validate_environment(settings)
        # Check for warning call
        assert mock_logger.warning.called


def test_validate_environment_warns_jwt_secret_with_network_binding(caplog) -> None:
    """Development with JWT secret and network binding should warn."""
    from spaps_server_quickstart.startup import validate_environment

    class NetworkJWTDevSettings(BaseServiceSettings):
        env: str = "development"
        host: str = "0.0.0.0"
        jwt_secret: str = "jwt-secret-123"

    settings = NetworkJWTDevSettings()
    # Should not raise but should log warning
    with patch("spaps_server_quickstart.startup.logger") as mock_logger:
        validate_environment(settings)
        # Check for warning call
        assert mock_logger.warning.called


def test_validate_environment_multiple_violations() -> None:
    """Multiple environment violations should all be reported."""
    from spaps_server_quickstart.startup import EnvironmentSafetyError, validate_environment

    class MultiViolationSettings(BaseServiceSettings):
        env: str = "development"
        mailgun_api_key: str = "key-123"
        stripe_secret_key: str = "sk_live_danger"
        solana_rpc_url: str = "https://api.mainnet-beta.solana.com"

    settings = MultiViolationSettings()
    with pytest.raises(EnvironmentSafetyError) as exc_info:
        validate_environment(settings)

    error_msg = str(exc_info.value)
    assert "MAILGUN_API_KEY" in error_msg
    assert "sk_live" in error_msg
    assert "SOLANA" in error_msg
    assert "3 safety violation" in error_msg
