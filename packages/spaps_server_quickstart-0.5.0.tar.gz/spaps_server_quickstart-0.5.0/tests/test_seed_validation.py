"""
Tests for seed validation framework.

Feature 8: Seed Validation Framework
"""
from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

from spaps_server_quickstart.seeds import (
    SeedSchemaBase,
    register_schema,
    get_schema_for_file,
    validate_file,
    validate_directory,
    list_registered_schemas,
    clear_registry,
)


# ============================================================================
# Test Schema Base Classes
# ============================================================================


class TestSeedSchemaBase:
    def test_seed_schema_base_validates(self):
        """SeedSchemaBase should validate valid data."""

        class TestSchema(SeedSchemaBase):
            name: str
            value: int

        schema = TestSchema(name="test", value=42)
        assert schema.name == "test"
        assert schema.value == 42

    def test_seed_schema_rejects_invalid(self):
        """SeedSchemaBase should reject invalid data."""

        class TestSchema(SeedSchemaBase):
            name: str
            value: int

        with pytest.raises(Exception):  # ValidationError
            TestSchema(name="test", value="not_an_int")

    def test_seed_schema_forbids_extra_fields(self):
        """SeedSchemaBase should reject unknown fields."""

        class TestSchema(SeedSchemaBase):
            name: str

        with pytest.raises(Exception):  # ValidationError
            TestSchema(name="test", unknown_field="bad")


# ============================================================================
# Test Validator Registry
# ============================================================================


class TestSchemaRegistry:
    def setup_method(self):
        """Clear registry before each test."""
        clear_registry()

    def teardown_method(self):
        """Clear registry after each test."""
        clear_registry()

    def test_register_schema_for_file_pattern(self):
        """Should register schema for file pattern."""

        class PersonaSchema(SeedSchemaBase):
            code: str

        register_schema(r"personas\.yaml$", PersonaSchema)
        schemas = list_registered_schemas()
        assert r"personas\.yaml$" in schemas
        assert schemas[r"personas\.yaml$"] == "PersonaSchema"

    def test_get_schema_for_filename(self):
        """Should return registered schema for matching filename."""

        class PersonaSchema(SeedSchemaBase):
            code: str

        register_schema(r"personas\.yaml$", PersonaSchema)

        schema = get_schema_for_file("personas.yaml")
        assert schema == PersonaSchema

        schema = get_schema_for_file("data/personas.yaml")
        assert schema == PersonaSchema

    def test_get_schema_returns_none_for_unmatched(self):
        """Should return None for unregistered file patterns."""
        clear_registry()
        schema = get_schema_for_file("unknown.yaml")
        assert schema is None

    def test_default_schemas_not_auto_registered(self):
        """Registry should start empty (services register their own)."""
        clear_registry()
        schemas = list_registered_schemas()
        assert len(schemas) == 0


# ============================================================================
# Test File Validation
# ============================================================================


class TestFileValidation:
    def setup_method(self):
        """Clear registry before each test."""
        clear_registry()

    def teardown_method(self):
        """Clear registry after each test."""
        clear_registry()

    def test_validate_single_file_valid(self):
        """Should validate valid YAML file."""

        class ItemSchema(SeedSchemaBase):
            name: str
            count: int

        register_schema(r"items\.yaml$", ItemSchema)

        with tempfile.NamedTemporaryFile(
            mode="w", suffix="_items.yaml", delete=False
        ) as f:
            f.write("name: test\ncount: 42\n")
            f.flush()

            # Adjust pattern to match temp filename
            clear_registry()
            register_schema(r"items\.yaml$", ItemSchema)

            success, error = validate_file(Path(f.name))
            # No schema matches temp filename, so it passes (no validation)
            assert success is True

    def test_validate_single_file_invalid(self):
        """Should reject invalid YAML file."""

        class ItemSchema(SeedSchemaBase):
            name: str
            count: int

        # Create temp file and register pattern that matches it
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".yaml", delete=False
        ) as f:
            f.write("name: test\ncount: not_a_number\n")
            temp_path = Path(f.name)
            f.flush()

            # Register pattern that matches this specific file
            pattern = temp_path.name.replace(".", r"\.")
            register_schema(pattern, ItemSchema)

            success, error = validate_file(temp_path)
            assert success is False
            assert error is not None
            assert "validation" in error.lower() or "error" in error.lower()

    def test_validate_file_with_yaml_error(self):
        """Should handle YAML parse errors gracefully."""

        class ItemSchema(SeedSchemaBase):
            name: str

        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".yaml", delete=False
        ) as f:
            f.write("invalid: yaml: content: [")  # Invalid YAML
            temp_path = Path(f.name)
            f.flush()

            pattern = temp_path.name.replace(".", r"\.")
            register_schema(pattern, ItemSchema)

            success, error = validate_file(temp_path)
            assert success is False
            assert error is not None


# ============================================================================
# Test Directory Validation
# ============================================================================


class TestDirectoryValidation:
    def setup_method(self):
        """Clear registry before each test."""
        clear_registry()

    def teardown_method(self):
        """Clear registry after each test."""
        clear_registry()

    def test_validate_directory_recursive(self):
        """Should validate all YAML files in directory recursively."""

        class ItemSchema(SeedSchemaBase):
            name: str

        with tempfile.TemporaryDirectory() as tmpdir:
            tmppath = Path(tmpdir)

            # Create valid file
            (tmppath / "valid.yaml").write_text("name: test\n")

            # Create subdirectory with file
            subdir = tmppath / "subdir"
            subdir.mkdir()
            (subdir / "also_valid.yaml").write_text("name: test2\n")

            # Register pattern
            register_schema(r"\.yaml$", ItemSchema)

            passed, failed, errors = validate_directory(tmppath)
            assert passed == 2
            assert failed == 0
            assert len(errors) == 0

    def test_validate_directory_with_failures(self):
        """Should collect failures from directory validation."""

        class ItemSchema(SeedSchemaBase):
            name: str
            required_field: int

        with tempfile.TemporaryDirectory() as tmpdir:
            tmppath = Path(tmpdir)

            # Create invalid file (missing required_field)
            (tmppath / "invalid.yaml").write_text("name: test\n")

            register_schema(r"\.yaml$", ItemSchema)

            passed, failed, errors = validate_directory(tmppath)
            assert failed == 1
            assert len(errors) == 1

    def test_skip_non_yaml_files(self):
        """Should skip non-YAML files."""

        class ItemSchema(SeedSchemaBase):
            name: str

        with tempfile.TemporaryDirectory() as tmpdir:
            tmppath = Path(tmpdir)

            # Create non-YAML files
            (tmppath / "readme.txt").write_text("not yaml\n")
            (tmppath / "data.json").write_text('{"name": "test"}\n')

            register_schema(r"\.yaml$", ItemSchema)

            passed, failed, errors = validate_directory(tmppath)
            # No YAML files found, so nothing validated
            assert passed == 0
            assert failed == 0


# ============================================================================
# Additional Coverage Tests
# ============================================================================


class TestValidatorEdgeCases:
    def setup_method(self):
        """Clear registry before each test."""
        clear_registry()

    def teardown_method(self):
        """Clear registry after each test."""
        clear_registry()

    def test_validate_empty_yaml_file(self):
        """Empty YAML files should pass validation."""

        class ItemSchema(SeedSchemaBase):
            name: str

        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".yaml", delete=False
        ) as f:
            f.write("")  # Empty file
            temp_path = Path(f.name)
            f.flush()

            pattern = temp_path.name.replace(".", r"\.")
            register_schema(pattern, ItemSchema)

            success, error = validate_file(temp_path)
            assert success is True
            assert error is None

    def test_validate_list_with_invalid_item(self):
        """List YAML with invalid item should fail."""

        class ItemSchema(SeedSchemaBase):
            name: str
            count: int

        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".yaml", delete=False
        ) as f:
            f.write("- name: item1\n  count: 1\n- name: item2\n")  # Missing count
            temp_path = Path(f.name)
            f.flush()

            pattern = temp_path.name.replace(".", r"\.")
            register_schema(pattern, ItemSchema)

            success, error = validate_file(temp_path)
            assert success is False
            assert error is not None

    def test_validate_yml_extension(self):
        """Should validate .yml files too."""

        class ItemSchema(SeedSchemaBase):
            name: str

        with tempfile.TemporaryDirectory() as tmpdir:
            tmppath = Path(tmpdir)
            (tmppath / "data.yml").write_text("name: test\n")

            register_schema(r"\.yml$", ItemSchema)

            passed, failed, errors = validate_directory(tmppath)
            assert passed == 1
            assert failed == 0


# ============================================================================
# Test CLI (basic existence check)
# ============================================================================


def test_validate_cli_importable():
    """CLI module should be importable."""
    from spaps_server_quickstart.seeds import cli

    assert hasattr(cli, "seeds")
    assert hasattr(cli, "validate")
