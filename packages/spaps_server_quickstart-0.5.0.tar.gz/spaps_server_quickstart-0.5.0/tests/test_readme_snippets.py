from fastapi import APIRouter
from starlette.testclient import TestClient

from spaps_server_quickstart import create_app
from spaps_server_quickstart.settings import BaseServiceSettings


def test_readme_quickstart_snippet_executes() -> None:
    """Keep the README quickstart app-factory snippet executable."""

    def load_settings() -> BaseServiceSettings:
        return BaseServiceSettings(env="test", app_name="README Quickstart")

    router = APIRouter()

    @router.get("/hello")
    async def hello() -> dict[str, str]:
        return {"message": "Hello from SPAPS"}

    app = create_app(settings_loader=load_settings, api_router=router)
    client = TestClient(app)
    response = client.get("/hello")

    assert response.status_code == 200
    assert response.json() == {"message": "Hello from SPAPS"}
