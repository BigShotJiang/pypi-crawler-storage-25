"""
Tests for local development auth bypass mode.

This module tests:
- LocalPersona dataclass immutability and structure
- LocalPersonaRegistry for managing personas
- LocalAuthMiddleware for intercepting local tokens
- Settings integration for is_local_development
"""

from __future__ import annotations

import pytest
from unittest.mock import AsyncMock, MagicMock


class TestLocalPersona:
    """Tests for LocalPersona dataclass."""

    def test_local_persona_immutable(self) -> None:
        """LocalPersona should be immutable (frozen dataclass)."""
        from spaps_server_quickstart.local_mode import LocalPersona

        persona = LocalPersona(
            code="admin",
            token="local-admin",
            display_name="Admin User",
            user_id="00000000-0000-0000-0000-000000000001",
            roles=("admin", "user"),
        )

        with pytest.raises(AttributeError):
            persona.code = "user"  # type: ignore

    def test_local_persona_token_format(self) -> None:
        """LocalPersona tokens should follow the local-* format."""
        from spaps_server_quickstart.local_mode import LocalPersona

        persona = LocalPersona(
            code="admin",
            token="local-admin",
            display_name="Admin User",
            user_id="00000000-0000-0000-0000-000000000001",
            roles=("admin", "user"),
        )

        assert persona.token.startswith("local-")
        assert persona.code == "admin"
        assert persona.display_name == "Admin User"
        assert "admin" in persona.roles
        assert "user" in persona.roles

    def test_local_persona_has_required_fields(self) -> None:
        """LocalPersona should have all required fields."""
        from spaps_server_quickstart.local_mode import LocalPersona

        persona = LocalPersona(
            code="test",
            token="local-test",
            display_name="Test User",
            user_id="00000000-0000-0000-0000-000000000099",
            roles=("user",),
        )

        assert hasattr(persona, "code")
        assert hasattr(persona, "token")
        assert hasattr(persona, "display_name")
        assert hasattr(persona, "user_id")
        assert hasattr(persona, "roles")


class TestLocalPersonaRegistry:
    """Tests for LocalPersonaRegistry."""

    def test_registry_get_by_token(self) -> None:
        """Registry should retrieve personas by token."""
        from spaps_server_quickstart.local_mode import LocalPersona, LocalPersonaRegistry

        registry = LocalPersonaRegistry()
        persona = LocalPersona(
            code="admin",
            token="local-admin",
            display_name="Admin User",
            user_id="00000000-0000-0000-0000-000000000001",
            roles=("admin", "user"),
        )
        registry.register(persona)

        result = registry.get_by_token("local-admin")
        assert result is not None
        assert result.code == "admin"

    def test_registry_get_by_token_not_found(self) -> None:
        """Registry should return None for unknown tokens."""
        from spaps_server_quickstart.local_mode import LocalPersonaRegistry

        registry = LocalPersonaRegistry()
        result = registry.get_by_token("nonexistent-token")
        assert result is None

    def test_registry_get_by_code(self) -> None:
        """Registry should retrieve personas by code."""
        from spaps_server_quickstart.local_mode import LocalPersona, LocalPersonaRegistry

        registry = LocalPersonaRegistry()
        persona = LocalPersona(
            code="admin",
            token="local-admin",
            display_name="Admin User",
            user_id="00000000-0000-0000-0000-000000000001",
            roles=("admin", "user"),
        )
        registry.register(persona)

        result = registry.get_by_code("admin")
        assert result is not None
        assert result.token == "local-admin"

    def test_registry_get_by_code_not_found(self) -> None:
        """Registry should return None for unknown codes."""
        from spaps_server_quickstart.local_mode import LocalPersonaRegistry

        registry = LocalPersonaRegistry()
        result = registry.get_by_code("nonexistent")
        assert result is None

    def test_registry_register_new_persona(self) -> None:
        """Registry should allow registering new personas."""
        from spaps_server_quickstart.local_mode import LocalPersona, LocalPersonaRegistry

        registry = LocalPersonaRegistry()
        custom_persona = LocalPersona(
            code="custom",
            token="local-custom",
            display_name="Custom User",
            user_id="00000000-0000-0000-0000-000000000099",
            roles=("custom_role",),
        )
        registry.register(custom_persona)

        assert registry.get_by_code("custom") is not None
        assert registry.get_by_token("local-custom") is not None

    def test_registry_default_personas(self) -> None:
        """Registry should have default admin and user personas."""
        from spaps_server_quickstart.local_mode import get_default_registry

        registry = get_default_registry()

        admin = registry.get_by_code("admin")
        assert admin is not None
        assert admin.token == "local-admin"
        assert "admin" in admin.roles

        user = registry.get_by_code("user")
        assert user is not None
        assert user.token == "local-user"
        assert "user" in user.roles

    def test_registry_list_all_personas(self) -> None:
        """Registry should list all registered personas."""
        from spaps_server_quickstart.local_mode import get_default_registry

        registry = get_default_registry()
        personas = registry.list_all()

        assert len(personas) >= 2
        codes = [p.code for p in personas]
        assert "admin" in codes
        assert "user" in codes


class TestLocalAuthMiddleware:
    """Tests for LocalAuthMiddleware."""

    @pytest.mark.asyncio
    async def test_middleware_extracts_local_token(self) -> None:
        """Middleware should extract local-* tokens from Authorization header."""
        from spaps_server_quickstart.local_mode import LocalAuthMiddleware, get_default_registry

        registry = get_default_registry()
        middleware = LocalAuthMiddleware(app=AsyncMock(), registry=registry)

        request = MagicMock()
        request.headers = {"authorization": "Bearer local-admin"}
        request.state = MagicMock()

        call_next = AsyncMock(return_value=MagicMock())
        await middleware.dispatch(request, call_next)

        # Should set authenticated_user as AuthenticatedUser on request.state
        assert hasattr(request.state, "authenticated_user")
        assert request.state.authenticated_user is not None
        assert request.state.authenticated_user.user_id is not None

    @pytest.mark.asyncio
    async def test_middleware_ignores_non_local_token(self) -> None:
        """Middleware should pass through non-local tokens."""
        from spaps_server_quickstart.local_mode import LocalAuthMiddleware, get_default_registry

        registry = get_default_registry()
        middleware = LocalAuthMiddleware(app=AsyncMock(), registry=registry)

        request = MagicMock()
        request.headers = {"authorization": "Bearer real-jwt-token"}
        request.state = MagicMock(spec=[])  # No pre-existing attributes

        call_next = AsyncMock(return_value=MagicMock())
        await middleware.dispatch(request, call_next)

        # Should not set authenticated_user
        assert not hasattr(request.state, "authenticated_user")

    @pytest.mark.asyncio
    async def test_middleware_sets_authenticated_user(self) -> None:
        """Middleware should set correct authenticated_user structure."""
        from spaps_server_quickstart.local_mode import LocalAuthMiddleware, get_default_registry

        registry = get_default_registry()
        middleware = LocalAuthMiddleware(app=AsyncMock(), registry=registry)

        request = MagicMock()
        request.headers = {"authorization": "Bearer local-admin"}
        request.state = MagicMock()

        call_next = AsyncMock(return_value=MagicMock())
        await middleware.dispatch(request, call_next)

        user = request.state.authenticated_user
        # AuthenticatedUser is a dataclass with attributes, not a dict
        assert hasattr(user, "user_id")
        assert hasattr(user, "roles")
        assert hasattr(user, "session_id")
        assert "admin" in user.roles

    @pytest.mark.asyncio
    async def test_middleware_passes_through_without_token(self) -> None:
        """Middleware should pass through requests without Authorization header."""
        from spaps_server_quickstart.local_mode import LocalAuthMiddleware, get_default_registry

        registry = get_default_registry()
        middleware = LocalAuthMiddleware(app=AsyncMock(), registry=registry)

        request = MagicMock()
        request.headers = {}
        request.state = MagicMock(spec=[])

        call_next = AsyncMock(return_value=MagicMock())
        result = await middleware.dispatch(request, call_next)

        # Should call next middleware and not set authenticated_user
        call_next.assert_called_once()
        assert not hasattr(request.state, "authenticated_user")

    @pytest.mark.asyncio
    async def test_middleware_handles_user_persona(self) -> None:
        """Middleware should correctly handle user persona."""
        from spaps_server_quickstart.local_mode import LocalAuthMiddleware, get_default_registry

        registry = get_default_registry()
        middleware = LocalAuthMiddleware(app=AsyncMock(), registry=registry)

        request = MagicMock()
        request.headers = {"authorization": "Bearer local-user"}
        request.state = MagicMock()

        call_next = AsyncMock(return_value=MagicMock())
        await middleware.dispatch(request, call_next)

        user = request.state.authenticated_user
        assert "user" in user.roles
        assert "admin" not in user.roles


class TestSettingsIntegration:
    """Tests for settings.py integration."""

    def test_is_local_development_true(self) -> None:
        """is_local_development should be True when development_environment is 'local'."""
        from spaps_server_quickstart.settings import BaseServiceSettings

        settings = BaseServiceSettings(development_environment="local")
        assert settings.is_local_development is True

    def test_is_local_development_false_when_none(self) -> None:
        """is_local_development should be False when development_environment is None."""
        from spaps_server_quickstart.settings import BaseServiceSettings

        settings = BaseServiceSettings(development_environment=None)
        assert settings.is_local_development is False

    def test_is_local_development_false_when_other(self) -> None:
        """is_local_development should be False for other values."""
        from spaps_server_quickstart.settings import BaseServiceSettings

        # The Literal type only allows "local" or None
        settings = BaseServiceSettings()
        assert settings.is_local_development is False

    def test_development_environment_defaults_to_none(self) -> None:
        """development_environment should default to None."""
        from spaps_server_quickstart.settings import BaseServiceSettings

        settings = BaseServiceSettings()
        assert settings.development_environment is None

    def test_is_local_development_raises_in_production(self) -> None:
        """is_local_development should raise RuntimeError in production."""
        from spaps_server_quickstart.settings import BaseServiceSettings

        settings = BaseServiceSettings(development_environment="local", env="production")

        with pytest.raises(RuntimeError) as exc_info:
            _ = settings.is_local_development

        assert "production" in str(exc_info.value).lower()
        assert "local auth bypass" in str(exc_info.value).lower()

    def test_is_local_development_raises_in_prod_env(self) -> None:
        """is_local_development should raise RuntimeError when env='prod'."""
        from spaps_server_quickstart.settings import BaseServiceSettings

        settings = BaseServiceSettings(development_environment="local", env="prod")

        with pytest.raises(RuntimeError):
            _ = settings.is_local_development

    def test_is_local_development_ok_in_dev_env(self) -> None:
        """is_local_development should work fine in dev environment."""
        from spaps_server_quickstart.settings import BaseServiceSettings

        settings = BaseServiceSettings(development_environment="local", env="dev")
        assert settings.is_local_development is True

    def test_is_local_development_ok_in_staging_env(self) -> None:
        """is_local_development should work in staging (though not recommended)."""
        from spaps_server_quickstart.settings import BaseServiceSettings

        settings = BaseServiceSettings(development_environment="local", env="staging")
        assert settings.is_local_development is True
