from __future__ import annotations

from types import SimpleNamespace
from typing import Any, AsyncIterator
from unittest.mock import AsyncMock, MagicMock, patch

from fastapi import FastAPI
from fastapi.testclient import TestClient
from sqlalchemy.exc import SQLAlchemyError

from spaps_server_quickstart.api.domains.health_router import health_ready
from spaps_server_quickstart.api.health import HealthRouterFactory
from spaps_server_quickstart.settings import BaseServiceSettings


class ExampleSettings(BaseServiceSettings):
    app_name: str = "Health Service"
    service_slug: str = "health-service"
    database_url: str = "postgresql+asyncpg://user:pass@localhost:5432/health"


class SuccessfulSession:
    async def execute(self, *_: Any, **__: Any) -> None:  # pragma: no cover - executed via router
        return None


class FailingSession:
    async def execute(self, *_: Any, **__: Any) -> None:  # pragma: no cover - executed via router
        raise SQLAlchemyError()


async def successful_dependency() -> AsyncIterator[SuccessfulSession]:
    yield SuccessfulSession()


async def failing_dependency() -> AsyncIterator[FailingSession]:
    yield FailingSession()


class _SessionContext:
    def __init__(self, session: Any) -> None:
        self._session = session

    async def __aenter__(self) -> Any:
        return self._session

    async def __aexit__(self, *_: Any) -> None:
        return None


def _make_db_resources(session: Any) -> Any:
    return SimpleNamespace(
        get_session_factory=lambda: (lambda: _SessionContext(session))
    )


def _make_request(*, db_resources: Any | None = None, settings: Any | None = None) -> Any:
    state = SimpleNamespace()
    if db_resources is not None:
        state.db_resources = db_resources
    if settings is not None:
        state.settings = settings
    return SimpleNamespace(app=SimpleNamespace(state=state))


def extra_metrics(settings: BaseServiceSettings, session: Any) -> dict[str, Any]:
    return {"service": settings.app_name, "session_type": type(session).__name__ if session else None}


def test_health_router_with_database_success() -> None:
    factory = HealthRouterFactory(
        settings_loader=lambda: ExampleSettings(),
        session_dependency=successful_dependency,
        extra_metrics_provider=extra_metrics,
    )
    app = FastAPI()
    app.include_router(factory.create_router())

    client = TestClient(app)
    response = client.get("/health")

    assert response.status_code == 200
    payload = response.json()
    assert payload["status"] == "ok"
    assert payload["database_ready"] is True
    assert payload["details"]["service"] == "Health Service"


def test_health_router_with_database_failure() -> None:
    factory = HealthRouterFactory(
        settings_loader=lambda: ExampleSettings(),
        session_dependency=failing_dependency,
    )
    app = FastAPI()
    app.include_router(factory.create_router())

    client = TestClient(app)
    response = client.get("/health")

    assert response.status_code == 200
    payload = response.json()
    assert payload["status"] == "degraded"
    assert payload["database_ready"] is False


def test_health_router_without_database_async_metrics() -> None:
    async def async_metrics(settings: BaseServiceSettings, session: Any) -> dict[str, Any]:
        return {"service": settings.service_slug, "session": session}

    factory = HealthRouterFactory(
        settings_loader=lambda: ExampleSettings(),
        extra_metrics_provider=async_metrics,
    )
    app = FastAPI()
    app.include_router(factory.create_router())

    client = TestClient(app)
    response = client.get("/health")

    assert response.status_code == 200
    payload = response.json()
    assert payload["database_ready"] is True
    assert payload["details"]["service"] == "health-service"


class TestDomainHealthReady:
    async def test_flags_missing_pii_master_key_when_pii_apps_exist(self) -> None:
        session = AsyncMock()
        session.execute = AsyncMock(return_value=None)
        request = _make_request(
            db_resources=_make_db_resources(session),
            settings=SimpleNamespace(
                redis_url="redis://cache.example:6379/0",
                spaps_pii_master_key="",
            ),
        )
        redis_client = MagicMock()

        with (
            patch("redis.from_url", return_value=redis_client),
            patch(
                "spaps_server_quickstart.api.domains.health_router._has_pii_enabled_app",
                new=AsyncMock(return_value=True),
            ) as mock_has_pii_apps,
        ):
            result = await health_ready(request)

        checks = result["data"]["checks"]
        assert result["data"]["status"] == "not_ready"
        assert checks["database"]["status"] == "connected"
        assert checks["redis"]["status"] == "connected"
        assert checks["pii_encryption"]["status"] == "disconnected"
        assert "SPAPS_PII_MASTER_KEY missing" in checks["pii_encryption"]["error"]
        redis_client.ping.assert_called_once_with()
        redis_client.close.assert_called_once_with()
        mock_has_pii_apps.assert_awaited_once_with(request)

    async def test_returns_ready_when_database_redis_and_pii_checks_pass(self) -> None:
        session = AsyncMock()
        session.execute = AsyncMock(return_value=None)
        request = _make_request(
            db_resources=_make_db_resources(session),
            settings=SimpleNamespace(
                redis_url="redis://cache.example:6379/0",
                spaps_pii_master_key="test-master-key",
            ),
        )
        redis_client = MagicMock()

        with (
            patch("redis.from_url", return_value=redis_client),
            patch(
                "spaps_server_quickstart.api.domains.health_router._has_pii_enabled_app",
                new=AsyncMock(return_value=True),
            ),
        ):
            result = await health_ready(request)

        assert result["data"]["status"] == "ready"
        assert result["data"]["checks"] == {
            "database": {"status": "connected"},
            "redis": {"status": "connected"},
            "pii_encryption": {"status": "connected"},
        }

    async def test_reports_database_and_redis_failures(self) -> None:
        session = AsyncMock()
        session.execute = AsyncMock(side_effect=SQLAlchemyError("db down"))
        request = _make_request(
            db_resources=_make_db_resources(session),
            settings=SimpleNamespace(
                redis_url="redis://cache.example:6379/0",
                spaps_pii_master_key="test-master-key",
            ),
        )
        redis_client = MagicMock()
        redis_client.ping.side_effect = RuntimeError("no redis")

        with (
            patch("redis.from_url", return_value=redis_client),
            patch(
                "spaps_server_quickstart.api.domains.health_router._has_pii_enabled_app",
                new=AsyncMock(),
            ) as mock_has_pii_apps,
        ):
            result = await health_ready(request)

        checks = result["data"]["checks"]
        assert result["data"]["status"] == "not_ready"
        assert checks["database"]["status"] == "disconnected"
        assert "db down" in checks["database"]["error"]
        assert checks["redis"] == {"status": "disconnected", "error": "RuntimeError"}
        assert "pii_encryption" not in checks
        mock_has_pii_apps.assert_not_awaited()

    async def test_marks_database_not_configured_without_db_resources(self) -> None:
        request = _make_request(
            settings=SimpleNamespace(
                redis_url="redis://cache.example:6379/0",
                spaps_pii_master_key="test-master-key",
            )
        )
        redis_client = MagicMock()

        with (
            patch("redis.from_url", return_value=redis_client),
            patch(
                "spaps_server_quickstart.api.domains.health_router._has_pii_enabled_app",
                new=AsyncMock(),
            ) as mock_has_pii_apps,
        ):
            result = await health_ready(request)

        checks = result["data"]["checks"]
        assert result["data"]["status"] == "not_ready"
        assert checks["database"] == {"status": "not_configured"}
        assert checks["redis"] == {"status": "connected"}
        assert "pii_encryption" not in checks
        mock_has_pii_apps.assert_not_awaited()
