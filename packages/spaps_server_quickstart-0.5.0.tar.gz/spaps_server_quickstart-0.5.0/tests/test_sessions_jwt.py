"""Tests for domains/sessions/jwt_service.py"""

from __future__ import annotations

import pytest
import jwt as pyjwt

from spaps_server_quickstart.domains.sessions.jwt_service import (
    parse_duration,
    generate_access_token,
    generate_refresh_token,
    generate_token_pair,
    verify_access_token,
    verify_refresh_token,
    AccessTokenPayload,
    RefreshTokenPayload,
    TokenPair,
)
from spaps_server_quickstart.domains.errors import InvalidTokenError, InvalidRefreshTokenError


def test_parse_duration_plain_integer():
    """Test parsing plain integer as seconds."""
    assert parse_duration("3600") == 3600
    assert parse_duration("60") == 60
    assert parse_duration("0") == 0


def test_parse_duration_with_units():
    """Test parsing duration strings with units."""
    assert parse_duration("30s") == 30
    assert parse_duration("5m") == 300
    assert parse_duration("1h") == 3600
    assert parse_duration("2h") == 7200
    assert parse_duration("1d") == 86400
    assert parse_duration("7d") == 604800


def test_parse_duration_invalid_returns_default():
    """Test that invalid format returns default 1 hour."""
    assert parse_duration("invalid") == 3600
    assert parse_duration("10x") == 3600  # Invalid unit
    assert parse_duration("abc") == 3600


def test_parse_duration_negative_returns_default():
    """Test that negative values return default."""
    # Negative values in the regex won't match, so return default
    assert parse_duration("-5m") == 3600


def test_generate_access_token_creates_valid_jwt():
    """Test access token generation."""
    secret = "test-secret-key-with-more-than-32-characters"

    token = generate_access_token(
        user_id="user-123",
        application_id="app-456",
        email="user@test.com",
        wallets=["0xabc", "solana123"],
        tier="premium",
        roles=["admin", "user"],
        permissions=["read", "write"],
        is_admin=True,
        is_super_admin=False,
        secret=secret,
        expires_in="1h",
    )

    # Decode without verification to check structure
    decoded = pyjwt.decode(token, options={"verify_signature": False})

    assert decoded["sub"] == "user-123"
    assert decoded["app_id"] == "app-456"
    assert decoded["email"] == "user@test.com"
    assert decoded["wallets"] == ["0xabc", "solana123"]
    assert decoded["tier"] == "premium"
    assert decoded["roles"] == ["admin", "user"]
    assert decoded["permissions"] == ["read", "write"]
    assert decoded["isAdmin"] is True
    assert decoded["isSuperAdmin"] is False
    assert "jti" in decoded
    assert "iat" in decoded
    assert "exp" in decoded
    assert decoded["iss"] == "spaps-auth-service"
    assert decoded["aud"] == "spaps-client-apps"


def test_generate_access_token_respects_expiry_cap():
    """Test that access token expiry is capped at 24 hours."""
    secret = "test-secret-key-with-more-than-32-characters"

    token = generate_access_token(
        user_id="user-123",
        application_id="app-456",
        secret=secret,
        expires_in="48h",  # Request 48 hours
    )

    decoded = pyjwt.decode(token, options={"verify_signature": False})

    # Should be capped at 24 hours (86400 seconds)
    exp_diff = decoded["exp"] - decoded["iat"]
    assert exp_diff <= 86400


def test_generate_refresh_token_creates_valid_jwt():
    """Test refresh token generation."""
    secret = "test-refresh-secret-with-more-than-32-characters"

    token = generate_refresh_token(
        user_id="user-123",
        application_id="app-456",
        email="user@test.com",
        roles=["user"],
        is_admin=False,
        secret=secret,
        expires_in="7d",
    )

    decoded = pyjwt.decode(token, options={"verify_signature": False})

    assert decoded["sub"] == "user-123"
    assert decoded["app_id"] == "app-456"
    assert decoded["email"] == "user@test.com"
    assert decoded["roles"] == ["user"]
    assert decoded["isAdmin"] is False
    assert "token_family" in decoded
    assert "jti" in decoded
    assert decoded["iss"] == "spaps-auth-service"


def test_generate_refresh_token_respects_expiry_cap():
    """Test that refresh token expiry is capped at 365 days."""
    secret = "test-refresh-secret-with-more-than-32-characters"

    token = generate_refresh_token(
        user_id="user-123",
        application_id="app-456",
        secret=secret,
        expires_in="500d",  # Request 500 days
    )

    decoded = pyjwt.decode(token, options={"verify_signature": False})

    # Should be capped at 365 days
    exp_diff = decoded["exp"] - decoded["iat"]
    assert exp_diff <= 365 * 86400


def test_generate_token_pair_creates_both_tokens():
    """Test generating access + refresh token pair."""
    access_secret = "access-secret-with-more-than-32-characters"
    refresh_secret = "refresh-secret-with-more-than-32-characters"

    pair = generate_token_pair(
        user_id="user-123",
        application_id="app-456",
        email="user@test.com",
        access_secret=access_secret,
        refresh_secret=refresh_secret,
    )

    assert isinstance(pair, TokenPair)
    assert pair.access_token
    assert pair.refresh_token
    assert pair.expires_in > 0
    assert pair.token_type == "Bearer"

    # Verify tokens decode correctly
    access_decoded = pyjwt.decode(pair.access_token, options={"verify_signature": False})
    refresh_decoded = pyjwt.decode(pair.refresh_token, options={"verify_signature": False})

    assert access_decoded["sub"] == "user-123"
    assert refresh_decoded["sub"] == "user-123"


def test_verify_access_token_success():
    """Test successful access token verification."""
    secret = "test-secret-key-with-more-than-32-characters"

    token = generate_access_token(
        user_id="user-123",
        application_id="app-456",
        email="user@test.com",
        secret=secret,
        expires_in="1h",
    )

    payload = verify_access_token(token, secret)

    assert isinstance(payload, AccessTokenPayload)
    assert payload.sub == "user-123"
    assert payload.app_id == "app-456"
    assert payload.email == "user@test.com"
    assert payload.tier == "basic"  # Default
    assert payload.isAdmin is False  # Default


def test_verify_access_token_expired():
    """Test that expired token raises InvalidTokenError."""
    secret = "test-secret-key-with-more-than-32-characters"

    # Create token with 0 second expiry (immediately expired)
    token = generate_access_token(
        user_id="user-123",
        application_id="app-456",
        secret=secret,
        expires_in="0s",
    )

    # Wait a tiny bit to ensure expiry
    import time
    time.sleep(0.1)

    with pytest.raises(InvalidTokenError) as excinfo:
        verify_access_token(token, secret)

    assert "expired" in str(excinfo.value).lower()


def test_verify_access_token_wrong_secret():
    """Test that wrong secret raises InvalidTokenError."""
    secret = "test-secret-key-with-more-than-32-characters"
    wrong_secret = "wrong-secret-key-with-more-than-32-characters"

    token = generate_access_token(
        user_id="user-123",
        application_id="app-456",
        secret=secret,
        expires_in="1h",
    )

    with pytest.raises(InvalidTokenError) as excinfo:
        verify_access_token(token, wrong_secret)

    assert "Invalid access token" in str(excinfo.value)


def test_verify_access_token_missing_claims():
    """Test that token missing required claims fails."""
    secret = "test-secret-key-with-more-than-32-characters"

    # Manually create token missing required claims
    payload = {
        "sub": "user-123",
        # Missing app_id and jti
        "iat": 1234567890,
        "exp": 9999999999,
        "iss": "spaps-auth-service",
        "aud": "spaps-client-apps",
    }

    token = pyjwt.encode(payload, secret, algorithm="HS256")

    with pytest.raises(InvalidTokenError) as excinfo:
        verify_access_token(token, secret)

    assert "missing required claims" in str(excinfo.value)


def test_verify_refresh_token_success():
    """Test successful refresh token verification."""
    secret = "test-refresh-secret-with-more-than-32-characters"

    token = generate_refresh_token(
        user_id="user-123",
        application_id="app-456",
        secret=secret,
        expires_in="7d",
    )

    payload = verify_refresh_token(token, secret)

    assert isinstance(payload, RefreshTokenPayload)
    assert payload.sub == "user-123"
    assert payload.app_id == "app-456"
    assert payload.token_family
    assert payload.isAdmin is False


def test_verify_refresh_token_expired():
    """Test that expired refresh token raises error."""
    secret = "test-refresh-secret-with-more-than-32-characters"

    token = generate_refresh_token(
        user_id="user-123",
        application_id="app-456",
        secret=secret,
        expires_in="0s",
    )

    import time
    time.sleep(0.1)

    with pytest.raises(InvalidRefreshTokenError) as excinfo:
        verify_refresh_token(token, secret)

    assert "expired" in str(excinfo.value).lower()


def test_verify_refresh_token_missing_claims():
    """Test that refresh token missing required claims fails."""
    secret = "test-refresh-secret-with-more-than-32-characters"

    # Manually create token missing token_family
    payload = {
        "sub": "user-123",
        "app_id": "app-456",
        "jti": "jti-123",
        # Missing token_family
        "iat": 1234567890,
        "exp": 9999999999,
        "iss": "spaps-auth-service",
        "aud": "spaps-client-apps",
    }

    token = pyjwt.encode(payload, secret, algorithm="HS256")

    with pytest.raises(InvalidRefreshTokenError) as excinfo:
        verify_refresh_token(token, secret)

    assert "missing required claims" in str(excinfo.value)
    assert "token_family" in str(excinfo.value)


def test_access_token_defaults():
    """Test access token uses sensible defaults."""
    secret = "test-secret-key-with-more-than-32-characters"

    token = generate_access_token(
        user_id="user-123",
        application_id="app-456",
        secret=secret,
    )

    payload = verify_access_token(token, secret)

    assert payload.email is None
    assert payload.wallets == []
    assert payload.tier == "basic"
    assert payload.roles == []
    assert payload.permissions == []
    assert payload.isAdmin is False
    assert payload.isSuperAdmin is False
