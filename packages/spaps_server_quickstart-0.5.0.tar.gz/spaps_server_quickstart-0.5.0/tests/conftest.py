"""
Root test conftest for spaps-server-quickstart.

pytest_plugins MUST be declared at the top-level conftest (pytest requirement).
Domain-specific TestConfig registration lives in tests/domains/conftest.py.
"""

# Register quickstart testing plugin (provides infrastructure fixtures + hooks)
pytest_plugins = ["spaps_server_quickstart.testing"]
