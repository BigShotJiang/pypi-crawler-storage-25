"""Unit tests for the secure_messages domain router (HTTP layer).

Each test creates a minimal FastAPI test app with dependency overrides for
the database session and application. The service layer is fully mocked
so tests exercise only routing, request validation, status codes, and
response shapes.
"""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from spaps_server_quickstart.domains.secure_messages.router import (
    secure_messages_router,
)
from spaps_server_quickstart.middleware.error_handler import install_error_handlers
from spaps_server_quickstart.middleware.spaps_deps import (
    get_application,
    get_current_user,
    get_db_session,
)

# ---------------------------------------------------------------------------
# Helpers / Constants
# ---------------------------------------------------------------------------

FAKE_APP_ID = str(uuid4())
FAKE_PATIENT_ID = str(uuid4())
FAKE_PRACTITIONER_ID = str(uuid4())
FAKE_MSG_ID = str(uuid4())

_SVC_MODULE = "spaps_server_quickstart.domains.secure_messages.service"


def _fake_message(content: str = "Hello doctor") -> dict:
    """Return a realistic secure message dict."""
    return {
        "id": FAKE_MSG_ID,
        "application_id": FAKE_APP_ID,
        "patient_id": FAKE_PATIENT_ID,
        "practitioner_id": FAKE_PRACTITIONER_ID,
        "content": content,
        "metadata": {},
        "created_at": datetime.now(UTC).isoformat(),
    }


def _fake_application():
    """Return a mock application with pii_enabled=False."""
    app = MagicMock()
    app.id = FAKE_APP_ID
    app.name = "Test App"
    app.settings = {"pii_enabled": False}
    return app


def _fake_user():
    """Return a mock authenticated user."""
    user = MagicMock()
    user.id = FAKE_PATIENT_ID
    user.email = "test@example.com"
    user.username = "testuser"
    user.application_id = FAKE_APP_ID
    user.tier = "free"
    user.roles = []
    user.permissions = []
    user.is_admin = False
    user.is_super_admin = False
    user.wallet_addresses = {}
    return user


def _create_test_app():
    """Create a FastAPI test app with the secure_messages router."""
    app = FastAPI()

    settings = MagicMock()
    settings.jwt_secret = "test-secret"
    settings.spaps_pii_master_key = ""
    app.state.settings = settings

    install_error_handlers(app)
    app.include_router(secure_messages_router)

    mock_db = AsyncMock()

    async def override_db_session():
        yield mock_db

    async def override_get_current_user():
        return _fake_user()

    app.dependency_overrides[get_db_session] = override_db_session
    app.dependency_overrides[get_application] = _fake_application
    app.dependency_overrides[get_current_user] = override_get_current_user

    return app


@pytest.fixture
def test_app():
    return _create_test_app()


@pytest.fixture
async def client(test_app):
    transport = ASGITransport(app=test_app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


# ===========================================================================
# POST /secure-messages
# ===========================================================================


class TestCreateMessage:
    @patch(f"{_SVC_MODULE}.create_message", new_callable=AsyncMock)
    async def test_success(self, mock_create, client: AsyncClient):
        """POST /secure-messages creates a message and returns 201."""
        mock_create.return_value = _fake_message("Hello doctor")

        resp = await client.post(
            "/secure-messages",
            json={
                "patientId": FAKE_PATIENT_ID,
                "practitionerId": FAKE_PRACTITIONER_ID,
                "content": "Hello doctor",
            },
        )

        assert resp.status_code == 201
        data = resp.json()
        assert data["id"] == FAKE_MSG_ID
        assert data["content"] == "Hello doctor"

    @patch(f"{_SVC_MODULE}.create_message", new_callable=AsyncMock)
    async def test_with_metadata(self, mock_create, client: AsyncClient):
        """POST /secure-messages with optional metadata."""
        msg = _fake_message()
        msg["metadata"] = {"priority": "high"}
        mock_create.return_value = msg

        resp = await client.post(
            "/secure-messages",
            json={
                "patientId": FAKE_PATIENT_ID,
                "practitionerId": FAKE_PRACTITIONER_ID,
                "content": "urgent",
                "metadata": {"priority": "high"},
            },
        )

        assert resp.status_code == 201
        data = resp.json()
        assert data["metadata"] == {"priority": "high"}

    async def test_missing_content_returns_400(self, client: AsyncClient):
        """POST /secure-messages without content returns 400."""
        resp = await client.post(
            "/secure-messages",
            json={
                "patientId": FAKE_PATIENT_ID,
                "practitionerId": FAKE_PRACTITIONER_ID,
            },
        )
        assert resp.status_code == 400

    async def test_missing_patient_id_returns_400(self, client: AsyncClient):
        """POST /secure-messages without patientId returns 400."""
        resp = await client.post(
            "/secure-messages",
            json={
                "practitionerId": FAKE_PRACTITIONER_ID,
                "content": "hello",
            },
        )
        assert resp.status_code == 400

    async def test_missing_practitioner_id_returns_400(self, client: AsyncClient):
        """POST /secure-messages without practitionerId returns 400."""
        resp = await client.post(
            "/secure-messages",
            json={
                "patientId": FAKE_PATIENT_ID,
                "content": "hello",
            },
        )
        assert resp.status_code == 400

    async def test_empty_body_returns_400(self, client: AsyncClient):
        """POST /secure-messages without body returns 400."""
        resp = await client.post("/secure-messages")
        assert resp.status_code == 400

    @patch(f"{_SVC_MODULE}.create_message", new_callable=AsyncMock)
    async def test_service_error_returns_500(self, mock_create, client: AsyncClient):
        """POST /secure-messages returns 500 on service error."""
        from spaps_server_quickstart.domains.secure_messages.errors import (
            SecureMessageCreateError,
        )

        mock_create.side_effect = SecureMessageCreateError()

        resp = await client.post(
            "/secure-messages",
            json={
                "patientId": FAKE_PATIENT_ID,
                "practitionerId": FAKE_PRACTITIONER_ID,
                "content": "hello",
            },
        )
        assert resp.status_code == 500


# ===========================================================================
# GET /secure-messages
# ===========================================================================


class TestListMessages:
    @patch(f"{_SVC_MODULE}.list_messages", new_callable=AsyncMock)
    async def test_success(self, mock_list, client: AsyncClient):
        """GET /secure-messages returns messages."""
        mock_list.return_value = {
            "messages": [_fake_message()],
        }

        resp = await client.get("/secure-messages")

        assert resp.status_code == 200
        data = resp.json()
        assert len(data["messages"]) == 1
        assert data["messages"][0]["id"] == FAKE_MSG_ID

    @patch(f"{_SVC_MODULE}.list_messages", new_callable=AsyncMock)
    async def test_empty_list(self, mock_list, client: AsyncClient):
        """GET /secure-messages with no messages returns empty list."""
        mock_list.return_value = {"messages": []}

        resp = await client.get("/secure-messages")

        assert resp.status_code == 200
        data = resp.json()
        assert data["messages"] == []

    @patch(f"{_SVC_MODULE}.list_messages", new_callable=AsyncMock)
    async def test_service_error_returns_500(self, mock_list, client: AsyncClient):
        """GET /secure-messages returns 500 on service error."""
        from spaps_server_quickstart.domains.secure_messages.errors import (
            SecureMessageListError,
        )

        mock_list.side_effect = SecureMessageListError()

        resp = await client.get("/secure-messages")
        assert resp.status_code == 500
