"""TM-013 Security Audit Tests: JWT Auth + Participant Scope + Encryption Enforcement.

Test coverage:
1. API key only (no JWT) → rejected with AUTHENTICATION_REQUIRED
2. API key + JWT for non-participant → rejected with SECURE_MESSAGES_FORBIDDEN_PARTICIPANT
3. API key + participant JWT → success (create and list)
4. pii_enabled=true + missing PII master key → denied with SECURE_MESSAGES_ENCRYPTION_REQUIRED
5. pii_enabled=true + key present → encrypted write succeeds and read decrypts correctly
"""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from spaps_server_quickstart.domains.secure_messages.router import (
    secure_messages_router,
)
from spaps_server_quickstart.middleware.error_handler import install_error_handlers
from spaps_server_quickstart.middleware.spaps_deps import (
    get_application,
    get_current_user,
    get_db_session,
)

# ---------------------------------------------------------------------------
# Test Fixtures and Constants
# ---------------------------------------------------------------------------

FAKE_APP_ID = str(uuid4())
FAKE_PATIENT_ID = str(uuid4())
FAKE_PRACTITIONER_ID = str(uuid4())
FAKE_OTHER_USER_ID = str(uuid4())
FAKE_MSG_ID = str(uuid4())

_SVC_MODULE = "spaps_server_quickstart.domains.secure_messages.service"


def _fake_application(pii_enabled: bool = False):
    """Return a mock application."""
    app = MagicMock()
    app.id = FAKE_APP_ID
    app.name = "Test App"
    app.settings = {"pii_enabled": pii_enabled}
    return app


def _fake_user(user_id: str = FAKE_PATIENT_ID, is_admin: bool = False):
    """Return a mock authenticated user."""
    user = MagicMock()
    user.id = user_id
    user.email = f"{user_id}@example.com"
    user.username = f"user-{user_id}"
    user.application_id = FAKE_APP_ID
    user.tier = "free"
    user.roles = ["admin"] if is_admin else []
    user.permissions = []
    user.is_admin = is_admin
    user.is_super_admin = False
    user.wallet_addresses = {}
    return user


def _fake_message(content: str = "Hello doctor") -> dict:
    """Return a realistic secure message dict."""
    return {
        "id": FAKE_MSG_ID,
        "application_id": FAKE_APP_ID,
        "patient_id": FAKE_PATIENT_ID,
        "practitioner_id": FAKE_PRACTITIONER_ID,
        "content": content,
        "metadata": {},
        "created_at": datetime.now(UTC).isoformat(),
    }


def _create_test_app(
    pii_enabled: bool = False,
    pii_master_key: str = "",
    override_get_current_user=None,
):
    """Create a FastAPI test app with the secure_messages router."""
    app = FastAPI()

    settings = MagicMock()
    settings.jwt_secret = "test-secret"
    settings.spaps_pii_master_key = pii_master_key
    app.state.settings = settings

    install_error_handlers(app)
    app.include_router(secure_messages_router)

    mock_db = AsyncMock()

    async def override_db_session():
        yield mock_db

    async def override_get_application():
        return _fake_application(pii_enabled=pii_enabled)

    app.dependency_overrides[get_db_session] = override_db_session
    app.dependency_overrides[get_application] = override_get_application

    if override_get_current_user is not None:
        app.dependency_overrides[get_current_user] = override_get_current_user

    return app


# ===========================================================================
# TM-013-1: API key only (no JWT) → rejected with AUTHENTICATION_REQUIRED
# ===========================================================================


class TestJWTRequired:
    """Test that secure messages endpoints require JWT authentication."""

    async def test_create_message_without_jwt_rejected(self):
        """POST /secure-messages without JWT returns 401 UNAUTHORIZED."""
        # No override for get_current_user means it will try to extract JWT and fail
        app = _create_test_app()

        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post(
                "/secure-messages",
                json={
                    "patientId": FAKE_PATIENT_ID,
                    "practitionerId": FAKE_PRACTITIONER_ID,
                    "content": "Hello doctor",
                },
            )

            assert resp.status_code == 401
            data = resp.json()
            assert data["error"]["code"] in ["UNAUTHORIZED", "AUTHENTICATION_REQUIRED"]

    async def test_list_messages_without_jwt_rejected(self):
        """GET /secure-messages without JWT returns 401 UNAUTHORIZED."""
        app = _create_test_app()

        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.get("/secure-messages")

            assert resp.status_code == 401
            data = resp.json()
            assert data["error"]["code"] in ["UNAUTHORIZED", "AUTHENTICATION_REQUIRED"]


# ===========================================================================
# TM-013-2: Participant Authorization
# ===========================================================================


class TestParticipantAuthorization:
    """Test that only message participants can access messages."""

    @patch(f"{_SVC_MODULE}.create_message", new_callable=AsyncMock)
    async def test_create_message_as_patient_succeeds(self, mock_create):
        """Patient can create message where they are the patient."""
        mock_create.return_value = _fake_message()

        async def override_user():
            return _fake_user(user_id=FAKE_PATIENT_ID)

        app = _create_test_app(override_get_current_user=override_user)

        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post(
                "/secure-messages",
                json={
                    "patientId": FAKE_PATIENT_ID,
                    "practitionerId": FAKE_PRACTITIONER_ID,
                    "content": "Hello doctor",
                },
            )

            assert resp.status_code == 201
            data = resp.json()
            assert data["id"] == FAKE_MSG_ID

    @patch(f"{_SVC_MODULE}.create_message", new_callable=AsyncMock)
    async def test_create_message_as_practitioner_succeeds(self, mock_create):
        """Practitioner can create message where they are the practitioner."""
        mock_create.return_value = _fake_message()

        async def override_user():
            return _fake_user(user_id=FAKE_PRACTITIONER_ID)

        app = _create_test_app(override_get_current_user=override_user)

        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post(
                "/secure-messages",
                json={
                    "patientId": FAKE_PATIENT_ID,
                    "practitionerId": FAKE_PRACTITIONER_ID,
                    "content": "Hello patient",
                },
            )

            assert resp.status_code == 201

    async def test_create_message_as_non_participant_rejected(self):
        """Non-participant cannot create message."""

        async def override_user():
            return _fake_user(user_id=FAKE_OTHER_USER_ID)

        app = _create_test_app(override_get_current_user=override_user)

        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post(
                "/secure-messages",
                json={
                    "patientId": FAKE_PATIENT_ID,
                    "practitionerId": FAKE_PRACTITIONER_ID,
                    "content": "Hello",
                },
            )

            assert resp.status_code == 403
            data = resp.json()
            assert data["error"]["code"] == "SECURE_MESSAGES_FORBIDDEN_PARTICIPANT"

    @patch(f"{_SVC_MODULE}.create_message", new_callable=AsyncMock)
    async def test_create_message_as_admin_succeeds(self, mock_create):
        """Admin can create any message."""
        mock_create.return_value = _fake_message()

        async def override_user():
            return _fake_user(user_id=FAKE_OTHER_USER_ID, is_admin=True)

        app = _create_test_app(override_get_current_user=override_user)

        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post(
                "/secure-messages",
                json={
                    "patientId": FAKE_PATIENT_ID,
                    "practitionerId": FAKE_PRACTITIONER_ID,
                    "content": "Hello from admin",
                },
            )

            assert resp.status_code == 201

    @patch(f"{_SVC_MODULE}.list_messages", new_callable=AsyncMock)
    async def test_list_messages_filters_by_participant(self, mock_list):
        """List only returns messages for the participant."""
        # Service layer should filter by participant
        mock_list.return_value = {
            "messages": [_fake_message()],
        }

        async def override_user():
            return _fake_user(user_id=FAKE_PATIENT_ID)

        app = _create_test_app(override_get_current_user=override_user)

        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.get("/secure-messages")

            assert resp.status_code == 200
            # Service was called with participant_id
            mock_list.assert_called_once()
            call_kwargs = mock_list.call_args.kwargs
            assert "participant_id" in call_kwargs
            assert call_kwargs["participant_id"] == FAKE_PATIENT_ID


# ===========================================================================
# TM-013-3: Encryption Enforcement (Fail-Closed)
# ===========================================================================


class TestEncryptionEnforcement:
    """Test that PII encryption is fail-closed when pii_enabled=true."""

    async def test_create_message_pii_enabled_no_key_rejected(self):
        """When pii_enabled=true and no key, creation is rejected."""

        async def override_user():
            return _fake_user(user_id=FAKE_PATIENT_ID)

        # pii_enabled=True but pii_master_key="" (missing)
        app = _create_test_app(
            pii_enabled=True,
            pii_master_key="",
            override_get_current_user=override_user,
        )

        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post(
                "/secure-messages",
                json={
                    "patientId": FAKE_PATIENT_ID,
                    "practitionerId": FAKE_PRACTITIONER_ID,
                    "content": "Sensitive data",
                },
            )

            assert resp.status_code == 500
            data = resp.json()
            assert data["error"]["code"] == "SECURE_MESSAGES_ENCRYPTION_REQUIRED"

    async def test_list_messages_pii_enabled_no_key_rejected(self):
        """When pii_enabled=true and no key, listing is rejected."""

        async def override_user():
            return _fake_user(user_id=FAKE_PATIENT_ID)

        app = _create_test_app(
            pii_enabled=True,
            pii_master_key="",
            override_get_current_user=override_user,
        )

        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.get("/secure-messages")

            assert resp.status_code == 500
            data = resp.json()
            assert data["error"]["code"] == "SECURE_MESSAGES_ENCRYPTION_REQUIRED"

    @patch(f"{_SVC_MODULE}.create_message", new_callable=AsyncMock)
    async def test_create_message_pii_enabled_with_key_succeeds(self, mock_create):
        """When pii_enabled=true and key present, creation succeeds."""
        mock_create.return_value = _fake_message()

        async def override_user():
            return _fake_user(user_id=FAKE_PATIENT_ID)

        app = _create_test_app(
            pii_enabled=True,
            pii_master_key="test-master-key-that-is-long-enough-for-hkdf",
            override_get_current_user=override_user,
        )

        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post(
                "/secure-messages",
                json={
                    "patientId": FAKE_PATIENT_ID,
                    "practitionerId": FAKE_PRACTITIONER_ID,
                    "content": "Sensitive data",
                },
            )

            assert resp.status_code == 201
            # Service was called with pii_enabled=True and encryption_service present
            mock_create.assert_called_once()
            call_kwargs = mock_create.call_args.kwargs
            assert call_kwargs["pii_enabled"] is True
            assert call_kwargs["encryption_service"] is not None

    @patch(f"{_SVC_MODULE}.list_messages", new_callable=AsyncMock)
    async def test_list_messages_pii_enabled_with_key_succeeds(self, mock_list):
        """When pii_enabled=true and key present, listing succeeds."""
        mock_list.return_value = {"messages": [_fake_message()]}

        async def override_user():
            return _fake_user(user_id=FAKE_PATIENT_ID)

        app = _create_test_app(
            pii_enabled=True,
            pii_master_key="test-master-key-that-is-long-enough-for-hkdf",
            override_get_current_user=override_user,
        )

        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.get("/secure-messages")

            assert resp.status_code == 200
            mock_list.assert_called_once()
            call_kwargs = mock_list.call_args.kwargs
            assert call_kwargs["pii_enabled"] is True
            assert call_kwargs["encryption_service"] is not None


# ===========================================================================
# Service Layer Tests: Participant Scope and Encryption
# ===========================================================================


class TestServiceParticipantScope:
    """Test service layer participant authorization logic."""

    @patch("spaps_server_quickstart.domains.secure_messages.service.repo")
    async def test_create_validates_participant(self, mock_repo):
        """Service validates user is a participant before creating."""
        from spaps_server_quickstart.domains.secure_messages import service
        from spaps_server_quickstart.domains.secure_messages.errors import (
            SecureMessagesForbiddenParticipantError,
        )

        db = AsyncMock()

        # User is not patient or practitioner
        with pytest.raises(SecureMessagesForbiddenParticipantError):
            await service.create_message(
                db,
                application_id=uuid4(),
                patient_id=FAKE_PATIENT_ID,
                practitioner_id=FAKE_PRACTITIONER_ID,
                content="test",
                current_user_id=FAKE_OTHER_USER_ID,
                is_admin=False,
            )

    @patch("spaps_server_quickstart.domains.secure_messages.service.repo.list_messages")
    async def test_list_filters_by_participant(self, mock_list):
        """Service filters messages by participant when listing."""
        from spaps_server_quickstart.domains.secure_messages import service
        from spaps_server_quickstart.domains.secure_messages.models import SecureMessage

        db = AsyncMock()

        # Mock repo returns 3 messages, only 1 for the participant
        msg1 = MagicMock(spec=SecureMessage)
        msg1.patient_id = FAKE_PATIENT_ID
        msg1.practitioner_id = uuid4()
        msg1.encrypted_content = "msg1"
        msg1.metadata_ = {}
        msg1.created_at = datetime.now(UTC)
        msg1.id = uuid4()
        msg1.application_id = uuid4()

        msg2 = MagicMock(spec=SecureMessage)
        msg2.patient_id = uuid4()
        msg2.practitioner_id = uuid4()
        msg2.encrypted_content = "msg2"
        msg2.metadata_ = {}
        msg2.created_at = datetime.now(UTC)
        msg2.id = uuid4()
        msg2.application_id = uuid4()

        msg3 = MagicMock(spec=SecureMessage)
        msg3.patient_id = uuid4()
        msg3.practitioner_id = FAKE_PATIENT_ID
        msg3.encrypted_content = "msg3"
        msg3.metadata_ = {}
        msg3.created_at = datetime.now(UTC)
        msg3.id = uuid4()
        msg3.application_id = uuid4()

        mock_list.return_value = [msg1, msg2, msg3]

        result = await service.list_messages(
            db,
            application_id=uuid4(),
            participant_id=FAKE_PATIENT_ID,
            is_admin=False,
        )

        # Should only return messages where user is patient or practitioner
        assert len(result["messages"]) == 2


class TestServiceEncryptionEnforcement:
    """Test service layer encryption fail-closed logic."""

    async def test_create_pii_enabled_no_service_raises(self):
        """Service raises when pii_enabled=True but no encryption_service."""
        from spaps_server_quickstart.domains.secure_messages import service
        from spaps_server_quickstart.domains.secure_messages.errors import (
            SecureMessagesEncryptionRequiredError,
        )

        db = AsyncMock()

        with pytest.raises(SecureMessagesEncryptionRequiredError):
            await service.create_message(
                db,
                application_id=uuid4(),
                patient_id=FAKE_PATIENT_ID,
                practitioner_id=FAKE_PRACTITIONER_ID,
                content="test",
                current_user_id=FAKE_PATIENT_ID,
                is_admin=False,
                pii_enabled=True,
                encryption_service=None,  # Missing!
            )

    async def test_list_pii_enabled_no_service_raises(self):
        """Service raises when pii_enabled=True but no encryption_service."""
        from spaps_server_quickstart.domains.secure_messages import service
        from spaps_server_quickstart.domains.secure_messages.errors import (
            SecureMessagesEncryptionRequiredError,
        )

        db = AsyncMock()

        with pytest.raises(SecureMessagesEncryptionRequiredError):
            await service.list_messages(
                db,
                application_id=uuid4(),
                participant_id=FAKE_PATIENT_ID,
                is_admin=False,
                pii_enabled=True,
                encryption_service=None,  # Missing!
            )
