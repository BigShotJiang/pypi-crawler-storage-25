"""Unit tests for the secure_messages domain service layer.

The repository layer is fully mocked so tests exercise only the
service orchestration, encryption integration, and error handling.
"""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import UUID, uuid4

import pytest

from spaps_server_quickstart.domains.secure_messages import service
from spaps_server_quickstart.domains.secure_messages.encryption import PiiEncryptionService
from spaps_server_quickstart.domains.secure_messages.errors import MissingIdentifiersError

_REPO = "spaps_server_quickstart.domains.secure_messages.service.repo"

MASTER_KEY = "test-master-key-that-is-long-enough-for-hkdf"
FAKE_APP_ID = uuid4()
FAKE_PATIENT_ID = str(uuid4())
FAKE_PRACTITIONER_ID = str(uuid4())
IV_ALL_7 = bytes([0x07] * 12)


def _make_message(
    *,
    application_id: UUID | None = None,
    encrypted_content: str = "plain-content",
    metadata: dict | None = None,
) -> MagicMock:
    """Build a mock SecureMessage model instance."""
    msg = MagicMock()
    msg.id = uuid4()
    msg.application_id = application_id or FAKE_APP_ID
    msg.patient_id = uuid4()
    msg.practitioner_id = uuid4()
    msg.encrypted_content = encrypted_content
    msg.metadata_ = metadata or {}
    msg.created_at = datetime.now(UTC)
    return msg


# ===========================================================================
# create_message
# ===========================================================================


class TestCreateMessage:
    @patch(f"{_REPO}.create_message", new_callable=AsyncMock)
    async def test_creates_without_encryption(self, mock_create: AsyncMock) -> None:
        """When pii_enabled=False, content is stored as-is."""
        mock_msg = _make_message(encrypted_content="Hello doctor")
        mock_create.return_value = mock_msg

        db = AsyncMock()
        result = await service.create_message(
            db,
            application_id=FAKE_APP_ID,
            patient_id=FAKE_PATIENT_ID,
            practitioner_id=FAKE_PRACTITIONER_ID,
            content="Hello doctor",
            pii_enabled=False,
            current_user_id=FAKE_PATIENT_ID,
            is_admin=False,
        )

        assert result["content"] == "Hello doctor"
        assert result["id"] == str(mock_msg.id)

        # Check stored content was plaintext
        call_kwargs = mock_create.call_args.kwargs
        assert call_kwargs["encrypted_content"] == "Hello doctor"

    @patch(f"{_REPO}.create_message", new_callable=AsyncMock)
    async def test_creates_with_encryption(self, mock_create: AsyncMock) -> None:
        """When pii_enabled=True, content is encrypted before storage."""
        mock_msg = _make_message()
        mock_create.return_value = mock_msg

        enc_svc = PiiEncryptionService(
            master_key=MASTER_KEY,
            random_bytes_fn=lambda _n: IV_ALL_7,
        )

        db = AsyncMock()
        result = await service.create_message(
            db,
            application_id=FAKE_APP_ID,
            patient_id=FAKE_PATIENT_ID,
            practitioner_id=FAKE_PRACTITIONER_ID,
            content="Secret content",
            pii_enabled=True,
            encryption_service=enc_svc,
            current_user_id=FAKE_PATIENT_ID,
            is_admin=False,
        )

        # Response returns the original unencrypted content
        assert result["content"] == "Secret content"

        # But the stored content should be encrypted
        call_kwargs = mock_create.call_args.kwargs
        stored = call_kwargs["encrypted_content"]
        assert stored != "Secret content"
        assert len(stored) > 20  # base64 wrapper is long

    @patch(f"{_REPO}.create_message", new_callable=AsyncMock)
    async def test_includes_metadata(self, mock_create: AsyncMock) -> None:
        mock_msg = _make_message(metadata={"priority": "high"})
        mock_create.return_value = mock_msg

        db = AsyncMock()
        result = await service.create_message(
            db,
            application_id=FAKE_APP_ID,
            patient_id=FAKE_PATIENT_ID,
            practitioner_id=FAKE_PRACTITIONER_ID,
            content="msg",
            metadata={"priority": "high"},
            current_user_id=FAKE_PATIENT_ID,
            is_admin=False,
        )

        assert result["metadata"] == {"priority": "high"}
        call_kwargs = mock_create.call_args.kwargs
        assert call_kwargs["metadata_"] == {"priority": "high"}

    async def test_missing_identifiers_raises(self) -> None:
        db = AsyncMock()
        with pytest.raises(MissingIdentifiersError):
            await service.create_message(
                db,
                application_id=FAKE_APP_ID,
                patient_id="",
                practitioner_id=FAKE_PRACTITIONER_ID,
                content="msg",
                current_user_id=FAKE_PATIENT_ID,
                is_admin=False,
            )


# ===========================================================================
# list_messages
# ===========================================================================


class TestListMessages:
    @patch(f"{_REPO}.list_messages", new_callable=AsyncMock)
    async def test_lists_without_decryption(self, mock_list: AsyncMock) -> None:
        """When pii_enabled=False, content is returned as-is."""
        mock_list.return_value = [
            _make_message(encrypted_content="plain text message"),
        ]

        db = AsyncMock()
        result = await service.list_messages(
            db,
            application_id=FAKE_APP_ID,
            pii_enabled=False,
            participant_id=None,
            is_admin=True,
        )

        assert len(result["messages"]) == 1
        assert result["messages"][0]["content"] == "plain text message"

    @patch(f"{_REPO}.list_messages", new_callable=AsyncMock)
    async def test_lists_with_decryption(self, mock_list: AsyncMock) -> None:
        """When pii_enabled=True, content is decrypted from the stored value."""
        enc_svc = PiiEncryptionService(
            master_key=MASTER_KEY,
            random_bytes_fn=lambda _n: IV_ALL_7,
        )
        encrypted_value = enc_svc.encrypt_field(
            application_id=str(FAKE_APP_ID),
            value="Secret patient info",
        )

        mock_list.return_value = [
            _make_message(
                application_id=FAKE_APP_ID,
                encrypted_content=encrypted_value,
            ),
        ]

        db = AsyncMock()
        result = await service.list_messages(
            db,
            application_id=FAKE_APP_ID,
            pii_enabled=True,
            encryption_service=enc_svc,
            participant_id=None,
            is_admin=True,
        )

        assert len(result["messages"]) == 1
        assert result["messages"][0]["content"] == "Secret patient info"

    @patch(f"{_REPO}.list_messages", new_callable=AsyncMock)
    async def test_empty_list(self, mock_list: AsyncMock) -> None:
        mock_list.return_value = []

        db = AsyncMock()
        result = await service.list_messages(
            db,
            application_id=FAKE_APP_ID,
            participant_id=None,
            is_admin=True,
        )

        assert result["messages"] == []

    async def test_lists_without_encryption_service_raises(self) -> None:
        """When pii_enabled=True but no encryption_service, raises error (fail-closed)."""
        from spaps_server_quickstart.domains.secure_messages.errors import (
            SecureMessagesEncryptionRequiredError,
        )

        db = AsyncMock()

        # TM-013: Should raise instead of falling back to plaintext
        with pytest.raises(SecureMessagesEncryptionRequiredError):
            await service.list_messages(
                db,
                application_id=FAKE_APP_ID,
                pii_enabled=True,
                encryption_service=None,
                participant_id=None,
                is_admin=True,
            )
