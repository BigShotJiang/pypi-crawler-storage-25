"""Unit tests for the dayrate domain routers (HTTP layer).

Each test creates a minimal FastAPI test app with dependency overrides for
the database session, application, current user, and admin user. The
dayrate service layer is fully mocked so tests exercise only routing,
request validation, status codes, and response shapes.
"""

from __future__ import annotations

import datetime as dt
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import UUID, uuid4

import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from spaps_server_quickstart.domains.dayrate.router import (
    _create_stripe_checkout,
    dayrate_admin_router,
    dayrate_router,
)
from spaps_server_quickstart.middleware.error_handler import install_error_handlers
from spaps_server_quickstart.middleware.spaps_deps import (
    get_application,
    get_current_user,
    get_db_session,
    require_admin_user,
)

# ---------------------------------------------------------------------------
# Helpers / Constants
# ---------------------------------------------------------------------------

FAKE_APP_ID = str(uuid4())
FAKE_ADMIN_ID = str(uuid4())
FAKE_CONFIG_ID = str(uuid4())
FAKE_BOOKING_ID = str(uuid4())

_DR_SERVICE = "spaps_server_quickstart.domains.dayrate.service"


def _fake_config() -> dict:
    """Return a realistic config dict."""
    return {
        "id": FAKE_CONFIG_ID,
        "application_id": FAKE_APP_ID,
        "base_rate": 10000,
        "available_days": ["monday", "tuesday", "wednesday", "thursday", "friday"],
        "slots": None,
        "fill_tiers": None,
        "time_tiers": None,
        "horizon_weeks": 4,
        "meeting_link": "https://meet.example.com",
        "min_notice_hours": 24,
        "hold_duration_minutes": 30,
        "timezone": "America/New_York",
        "slot_definitions": None,
        "currency": "usd",
        "product_name": "Day Rate Consulting",
        "created_at": dt.datetime.now(dt.UTC).isoformat(),
        "updated_at": dt.datetime.now(dt.UTC).isoformat(),
    }


def _fake_booking(
    slot_type: str = "AM",
    status: str = "pending",
) -> dict:
    """Return a realistic booking dict."""
    return {
        "id": FAKE_BOOKING_ID,
        "application_id": FAKE_APP_ID,
        "user_id": None,
        "date": "2025-06-15",
        "slot_type": slot_type,
        "client_email": "test@example.com",
        "client_name": "Test Client",
        "price_paid": 10000,
        "stripe_session_id": "cs_test_123",
        "stripe_payment_intent_id": None,
        "status": status,
        "metadata": {},
        "booking_group_id": None,
        "expires_at": None,
        "created_at": dt.datetime.now(dt.UTC).isoformat(),
        "updated_at": dt.datetime.now(dt.UTC).isoformat(),
    }


def _fake_breakdown(base_rate: int = 10000) -> dict:
    """Return a realistic price breakdown dict."""
    return {
        "baseRate": base_rate,
        "fillMultiplier": 1.0,
        "timeMultiplier": 1.0,
        "finalPrice": base_rate,
    }


def _fake_slot_info(
    date: str = "2025-06-15",
    slot: str = "AM",
    available: bool = True,
) -> dict:
    """Return a realistic slot info dict."""
    return {
        "date": date,
        "dayOfWeek": "monday",
        "slot": slot,
        "price": 10000,
        "available": available,
        "breakdown": _fake_breakdown(),
    }


def _fake_policy(policy_id: str | None = None) -> dict:
    """Return a realistic booking policy dict."""
    return {
        "id": policy_id or str(uuid4()),
        "applicationId": FAKE_APP_ID,
        "policyKey": "checkin_call",
        "entitlementKey": "htma_checkin_call",
        "freeBookingsPerPeriod": 2,
        "periodDays": 28,
        "overageRate": 5000,
        "overageCurrency": "usd",
        "overageProductName": "Additional check-in call",
        "rescheduleIsFree": True,
        "isActive": True,
        "metadata": {"tier": "standard"},
    }


def _fake_admin():
    """Return a mock admin user."""
    admin = MagicMock()
    admin.id = FAKE_ADMIN_ID
    admin.email = "admin@example.com"
    admin.username = "admin"
    admin.tier = "premium"
    admin.roles = ["admin"]
    admin.permissions = ["manage_dayrate"]
    admin.is_admin = True
    admin.is_super_admin = False
    admin.wallet_addresses = []
    return admin


def _fake_application():
    """Return a mock application."""
    app = MagicMock()
    app.id = FAKE_APP_ID
    app.name = "Test App"
    return app


def _create_test_app():
    """Create a FastAPI test app with both routers and overridden deps."""
    app = FastAPI()

    settings = MagicMock()
    settings.jwt_secret = "test-secret"
    app.state.settings = settings

    install_error_handlers(app)
    app.include_router(dayrate_router)
    app.include_router(dayrate_admin_router)

    mock_db = AsyncMock()

    async def override_db_session():
        yield mock_db

    app.dependency_overrides[get_db_session] = override_db_session
    app.dependency_overrides[get_application] = _fake_application
    app.dependency_overrides[get_current_user] = lambda: _fake_admin()
    app.dependency_overrides[require_admin_user] = _fake_admin

    return app


@pytest.fixture
def test_app():
    return _create_test_app()


@pytest.fixture
async def client(test_app):
    transport = ASGITransport(app=test_app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


# ===========================================================================
# _create_stripe_checkout helper
# ===========================================================================


class TestCreateStripeCheckoutHelper:
    @patch(
        "spaps_server_quickstart.domains.dayrate.router.stripe.checkout.Session.create"
    )
    async def test_single_item_mode_builds_expected_checkout_params(self, mock_create):
        session = MagicMock()
        session.id = "cs_test_single"
        session.url = "https://checkout.stripe.com/pay/cs_test_single"
        mock_create.return_value = session

        settings = MagicMock()
        settings.stripe_secret_key = "sk_test_123"

        result = await _create_stripe_checkout(
            settings,
            price=123,
            product_name="Day Rate Consulting",
            description="Half-day session",
            currency="usd",
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
            client_email="test@example.com",
            metadata={"booking_id": uuid4(), "attempt": 2, "is_free": False},
            branding_display_name="Acme Health",
        )

        assert result == {
            "id": "cs_test_single",
            "url": "https://checkout.stripe.com/pay/cs_test_single",
        }

        call_kwargs = mock_create.call_args.kwargs
        assert call_kwargs["mode"] == "payment"
        assert call_kwargs["customer_email"] == "test@example.com"
        assert call_kwargs["metadata"]["attempt"] == "2"
        assert call_kwargs["metadata"]["is_free"] == "False"
        assert call_kwargs["branding_settings"] == {"display_name": "Acme Health"}
        assert call_kwargs["line_items"][0]["price_data"]["unit_amount"] == 12300
        assert call_kwargs["line_items"][0]["price_data"]["product_data"]["name"] == (
            "Day Rate Consulting"
        )
        assert (
            call_kwargs["line_items"][0]["price_data"]["product_data"]["description"]
            == "Half-day session"
        )

    @patch(
        "spaps_server_quickstart.domains.dayrate.router.stripe.checkout.Session.create"
    )
    async def test_multi_item_mode_builds_expected_checkout_params(self, mock_create):
        session = MagicMock()
        session.id = "cs_test_multi"
        session.url = "https://checkout.stripe.com/pay/cs_test_multi"
        mock_create.return_value = session

        settings = MagicMock()
        settings.stripe_secret_key = "sk_test_456"

        result = await _create_stripe_checkout(
            settings,
            line_items=[
                {"price": 100, "product_name": "Morning"},
                {"price": 250, "product_name": "Afternoon", "description": "Extended"},
            ],
            currency="usd",
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
            client_email="test@example.com",
            metadata={"group_id": "g_123"},
        )

        assert result == {
            "id": "cs_test_multi",
            "url": "https://checkout.stripe.com/pay/cs_test_multi",
        }

        call_kwargs = mock_create.call_args.kwargs
        assert call_kwargs["metadata"] == {"group_id": "g_123"}
        assert "branding_settings" not in call_kwargs
        assert len(call_kwargs["line_items"]) == 2
        assert call_kwargs["line_items"][0]["price_data"]["unit_amount"] == 10000
        assert (
            call_kwargs["line_items"][0]["price_data"]["product_data"]["description"]
            == ""
        )
        assert call_kwargs["line_items"][1]["price_data"]["unit_amount"] == 25000
        assert (
            call_kwargs["line_items"][1]["price_data"]["product_data"]["description"]
            == "Extended"
        )


# ===========================================================================
# GET /dayrate/availability
# ===========================================================================


class TestGetAvailability:
    @patch(f"{_DR_SERVICE}.get_availability", new_callable=AsyncMock)
    async def test_success(self, mock_avail, client: AsyncClient):
        """GET /dayrate/availability returns slots with camelCase shape."""
        mock_avail.return_value = {
            "currentFillRate": 0.0,
            "totalSlots": 10,
            "bookedSlots": 0,
            "baseRate": 10000,
            "meetingLink": "https://meet.example.com",
            "slots": [_fake_slot_info(), _fake_slot_info(slot="PM")],
        }

        resp = await client.get("/dayrate/availability")

        assert resp.status_code == 200
        data = resp.json()
        assert data["totalSlots"] == 10
        assert data["bookedSlots"] == 0
        assert data["baseRate"] == 10000
        assert len(data["slots"]) == 2
        assert "breakdown" in data["slots"][0]

    @patch(f"{_DR_SERVICE}.get_availability", new_callable=AsyncMock)
    async def test_config_not_found_returns_404(self, mock_avail, client: AsyncClient):
        """GET /dayrate/availability returns 404 when no config exists."""
        from spaps_server_quickstart.domains.dayrate.errors import ConfigNotFoundError

        mock_avail.side_effect = ConfigNotFoundError()

        resp = await client.get("/dayrate/availability")
        assert resp.status_code == 404


# ===========================================================================
# POST /dayrate/book
# ===========================================================================


class TestBookSlot:
    @patch(f"{_DR_SERVICE}.book_slot", new_callable=AsyncMock)
    async def test_success(self, mock_book, client: AsyncClient):
        """POST /dayrate/book returns camelCase booking shape."""
        mock_book.return_value = {
            "bookingId": FAKE_BOOKING_ID,
            "checkoutUrl": "https://checkout.stripe.com/pay/cs_test",
            "price": 10000,
            "breakdown": _fake_breakdown(),
            "expiresAt": "2025-06-15T14:00:00+00:00",
            "expiresIn": 1800,
        }

        resp = await client.post(
            "/dayrate/book",
            json={
                "date": "2025-06-15",
                "slot": "AM",
                "clientEmail": "test@example.com",
                "clientName": "Test Client",
                "successUrl": "https://example.com/success",
                "cancelUrl": "https://example.com/cancel",
            },
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["bookingId"] == FAKE_BOOKING_ID
        assert data["checkoutUrl"] == "https://checkout.stripe.com/pay/cs_test"
        assert data["price"] == 10000
        assert data["breakdown"]["baseRate"] == 10000
        assert data["expiresIn"] == 1800

    async def test_missing_fields_returns_400(self, client: AsyncClient):
        """POST /dayrate/book without required fields returns 400."""
        resp = await client.post(
            "/dayrate/book",
            json={"date": "2025-06-15"},
        )
        assert resp.status_code == 400

    @patch(f"{_DR_SERVICE}.book_slot", new_callable=AsyncMock)
    async def test_slot_unavailable_returns_409(self, mock_book, client: AsyncClient):
        """POST /dayrate/book returns 409 when slot is unavailable."""
        from spaps_server_quickstart.domains.dayrate.errors import SlotUnavailableError

        mock_book.side_effect = SlotUnavailableError()

        resp = await client.post(
            "/dayrate/book",
            json={
                "date": "2025-06-15",
                "slot": "AM",
                "clientEmail": "test@example.com",
                "clientName": "Test Client",
                "successUrl": "https://example.com/success",
                "cancelUrl": "https://example.com/cancel",
            },
        )
        assert resp.status_code == 409

    @patch(f"{_DR_SERVICE}.book_slot", new_callable=AsyncMock)
    async def test_notice_period_returns_400(self, mock_book, client: AsyncClient):
        """POST /dayrate/book returns 400 for notice period violation."""
        from spaps_server_quickstart.domains.dayrate.errors import (
            NoticePeriodViolationError,
        )

        mock_book.side_effect = NoticePeriodViolationError()

        resp = await client.post(
            "/dayrate/book",
            json={
                "date": "2025-06-15",
                "slot": "AM",
                "clientEmail": "test@example.com",
                "clientName": "Test Client",
                "successUrl": "https://example.com/success",
                "cancelUrl": "https://example.com/cancel",
            },
        )
        assert resp.status_code == 400

    @patch(f"{_DR_SERVICE}.book_slot", new_callable=AsyncMock)
    async def test_passes_stripe_create_checkout(self, mock_book, client: AsyncClient):
        """POST /dayrate/book wires up the stripe_create_checkout callback."""
        mock_book.return_value = {
            "bookingId": FAKE_BOOKING_ID,
            "checkoutUrl": "https://checkout.stripe.com/pay/cs_test",
            "price": 10000,
            "breakdown": _fake_breakdown(),
            "expiresAt": "2025-06-15T14:00:00+00:00",
            "expiresIn": 1800,
        }

        await client.post(
            "/dayrate/book",
            json={
                "date": "2025-06-15",
                "slot": "AM",
                "clientEmail": "test@example.com",
                "clientName": "Test Client",
                "successUrl": "https://example.com/success",
                "cancelUrl": "https://example.com/cancel",
            },
        )

        mock_book.assert_called_once()
        call_kwargs = mock_book.call_args.kwargs
        assert call_kwargs.get("stripe_create_checkout") is not None


# ===========================================================================
# POST /dayrate/book-multi
# ===========================================================================


class TestBookMulti:
    @patch(f"{_DR_SERVICE}.book_multi", new_callable=AsyncMock)
    async def test_success(self, mock_multi, client: AsyncClient):
        """POST /dayrate/book-multi returns camelCase multi-booking shape."""
        mock_multi.return_value = {
            "bookingGroupId": "group-uuid-123",
            "bookingIds": ["id-1", "id-2"],
            "checkoutUrl": "https://checkout.stripe.com/pay/cs_multi",
            "totalPrice": 20000,
            "priceBreakdowns": [_fake_breakdown(), _fake_breakdown()],
            "expiresAt": "2025-06-15T14:00:00+00:00",
            "expiresIn": 1800,
        }

        resp = await client.post(
            "/dayrate/book-multi",
            json={
                "slots": [
                    {"date": "2025-06-15", "slot": "AM"},
                    {"date": "2025-06-16", "slot": "PM"},
                ],
                "clientEmail": "test@example.com",
                "clientName": "Test Client",
                "successUrl": "https://example.com/success",
                "cancelUrl": "https://example.com/cancel",
            },
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["totalPrice"] == 20000
        assert data["bookingGroupId"] == "group-uuid-123"
        assert len(data["bookingIds"]) == 2
        assert len(data["priceBreakdowns"]) == 2
        assert data["expiresIn"] == 1800

    async def test_empty_slots_returns_400(self, client: AsyncClient):
        """POST /dayrate/book-multi with empty slots returns 400."""
        resp = await client.post(
            "/dayrate/book-multi",
            json={
                "slots": [],
                "clientEmail": "test@example.com",
                "clientName": "Test Client",
                "successUrl": "https://example.com/success",
                "cancelUrl": "https://example.com/cancel",
            },
        )
        assert resp.status_code == 400

    async def test_missing_body_returns_400(self, client: AsyncClient):
        """POST /dayrate/book-multi without body returns 400."""
        resp = await client.post("/dayrate/book-multi")
        assert resp.status_code == 400

    @patch(f"{_DR_SERVICE}.book_multi", new_callable=AsyncMock)
    async def test_passes_stripe_create_checkout(self, mock_multi, client: AsyncClient):
        """POST /dayrate/book-multi wires up the stripe_create_checkout callback."""
        mock_multi.return_value = {
            "bookingGroupId": "group-uuid-123",
            "bookingIds": ["id-1", "id-2"],
            "checkoutUrl": "https://checkout.stripe.com/pay/cs_multi",
            "totalPrice": 20000,
            "priceBreakdowns": [_fake_breakdown(), _fake_breakdown()],
            "expiresAt": "2025-06-15T14:00:00+00:00",
            "expiresIn": 1800,
        }

        await client.post(
            "/dayrate/book-multi",
            json={
                "slots": [
                    {"date": "2025-06-15", "slot": "AM"},
                    {"date": "2025-06-16", "slot": "PM"},
                ],
                "clientEmail": "test@example.com",
                "clientName": "Test Client",
                "successUrl": "https://example.com/success",
                "cancelUrl": "https://example.com/cancel",
            },
        )

        mock_multi.assert_called_once()
        call_kwargs = mock_multi.call_args.kwargs
        assert call_kwargs.get("stripe_create_checkout") is not None


# ===========================================================================
# GET /dayrate/admin/config
# ===========================================================================


class TestGetConfig:
    @patch(f"{_DR_SERVICE}.get_config", new_callable=AsyncMock)
    async def test_success(self, mock_get, client: AsyncClient):
        """GET /dayrate/admin/config returns config."""
        mock_get.return_value = {"config": _fake_config()}

        resp = await client.get("/dayrate/admin/config")

        assert resp.status_code == 200
        data = resp.json()
        assert data["config"]["base_rate"] == 10000

    @patch(f"{_DR_SERVICE}.get_config", new_callable=AsyncMock)
    async def test_not_found_returns_404(self, mock_get, client: AsyncClient):
        """GET /dayrate/admin/config returns 404 when no config."""
        from spaps_server_quickstart.domains.dayrate.errors import ConfigNotFoundError

        mock_get.side_effect = ConfigNotFoundError()

        resp = await client.get("/dayrate/admin/config")
        assert resp.status_code == 404


# ===========================================================================
# PUT /dayrate/admin/config
# ===========================================================================


class TestUpdateConfig:
    @patch(f"{_DR_SERVICE}.update_config", new_callable=AsyncMock)
    async def test_success(self, mock_update, client: AsyncClient):
        """PUT /dayrate/admin/config updates and returns config."""
        config = _fake_config()
        config["base_rate"] = 15000
        mock_update.return_value = {
            "config": config,
            "message": "Configuration updated successfully",
        }

        resp = await client.put(
            "/dayrate/admin/config",
            json={"base_rate": 15000},
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["config"]["base_rate"] == 15000
        assert "updated" in data["message"].lower()

    @patch(f"{_DR_SERVICE}.update_config", new_callable=AsyncMock)
    async def test_partial_update(self, mock_update, client: AsyncClient):
        """PUT /dayrate/admin/config accepts partial updates."""
        mock_update.return_value = {
            "config": _fake_config(),
            "message": "Configuration updated successfully",
        }

        resp = await client.put(
            "/dayrate/admin/config",
            json={"meeting_link": "https://new-link.example.com"},
        )

        assert resp.status_code == 200

    async def test_empty_body_accepted(self, client: AsyncClient):
        """PUT /dayrate/admin/config accepts empty body (no-op update)."""
        with patch(
            f"{_DR_SERVICE}.update_config", new_callable=AsyncMock
        ) as mock_update:
            mock_update.return_value = {
                "config": _fake_config(),
                "message": "Configuration updated successfully",
            }

            resp = await client.put(
                "/dayrate/admin/config",
                json={},
            )
            assert resp.status_code == 200


# ===========================================================================
# GET /dayrate/admin/bookings
# ===========================================================================


class TestListBookings:
    @patch(f"{_DR_SERVICE}.list_bookings", new_callable=AsyncMock)
    async def test_success(self, mock_list, client: AsyncClient):
        """GET /dayrate/admin/bookings returns bookings and total."""
        mock_list.return_value = {
            "bookings": [_fake_booking()],
            "total": 1,
        }

        resp = await client.get("/dayrate/admin/bookings")

        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 1
        assert len(data["bookings"]) == 1

    @patch(f"{_DR_SERVICE}.list_bookings", new_callable=AsyncMock)
    async def test_with_filters(self, mock_list, client: AsyncClient):
        """GET /dayrate/admin/bookings with filter params."""
        mock_list.return_value = {"bookings": [], "total": 0}

        resp = await client.get(
            "/dayrate/admin/bookings",
            params={
                "status": "confirmed",
                "startDate": "2025-06-01",
                "endDate": "2025-06-30",
                "limit": 50,
                "offset": 10,
            },
        )

        assert resp.status_code == 200

    @patch(f"{_DR_SERVICE}.list_bookings", new_callable=AsyncMock)
    async def test_empty_bookings(self, mock_list, client: AsyncClient):
        """GET /dayrate/admin/bookings returns empty when none exist."""
        mock_list.return_value = {"bookings": [], "total": 0}

        resp = await client.get("/dayrate/admin/bookings")

        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 0
        assert data["bookings"] == []


# ===========================================================================
# PUT /dayrate/admin/policies/{policy_id}
# ===========================================================================


class TestUpdatePolicy:
    @patch(f"{_DR_SERVICE}.update_booking_policy", new_callable=AsyncMock)
    async def test_maps_request_fields_to_service_kwargs(self, mock_update, client: AsyncClient):
        """PUT /dayrate/admin/policies/{id} maps camelCase fields to service kwargs."""
        policy_id = str(uuid4())
        mock_update.return_value = _fake_policy(policy_id=policy_id)

        resp = await client.put(
            f"/dayrate/admin/policies/{policy_id}",
            json={
                "entitlementKey": "new_entitlement",
                "freeBookingsPerPeriod": 4,
                "periodDays": 14,
                "overageRate": 2500,
                "overageCurrency": "cad",
                "overageProductName": "Extra call",
                "rescheduleIsFree": False,
                "isActive": False,
                "metadata": {"source": "migration"},
            },
        )

        assert resp.status_code == 200
        call_kwargs = mock_update.call_args.kwargs
        assert call_kwargs["policy_id"] == UUID(policy_id)
        assert call_kwargs["application_id"] == FAKE_APP_ID
        assert {
            k: v
            for k, v in call_kwargs.items()
            if k not in {"db", "policy_id", "application_id"}
        } == {
            "entitlement_key": "new_entitlement",
            "free_bookings_per_period": 4,
            "period_days": 14,
            "overage_rate": 2500,
            "overage_currency": "cad",
            "overage_product_name": "Extra call",
            "reschedule_is_free": False,
            "is_active": False,
            "metadata": {"source": "migration"},
        }

    @patch(f"{_DR_SERVICE}.update_booking_policy", new_callable=AsyncMock)
    async def test_empty_payload_sends_no_optional_update_fields(
        self, mock_update, client: AsyncClient
    ):
        """PUT /dayrate/admin/policies/{id} with {} sends only required service args."""
        policy_id = str(uuid4())
        mock_update.return_value = _fake_policy(policy_id=policy_id)

        resp = await client.put(
            f"/dayrate/admin/policies/{policy_id}",
            json={},
        )

        assert resp.status_code == 200
        call_kwargs = mock_update.call_args.kwargs
        assert call_kwargs["policy_id"] == UUID(policy_id)
        assert call_kwargs["application_id"] == FAKE_APP_ID
        assert {
            k: v
            for k, v in call_kwargs.items()
            if k not in {"db", "policy_id", "application_id"}
        } == {}
