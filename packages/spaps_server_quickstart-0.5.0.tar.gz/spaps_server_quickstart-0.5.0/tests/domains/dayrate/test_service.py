"""Unit tests for the dayrate domain service layer.

The repository layer is fully mocked so tests exercise only the
service orchestration, business logic, and error handling.
"""

from __future__ import annotations

import datetime as dt
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from sqlalchemy.exc import IntegrityError

from spaps_server_quickstart.domains.dayrate import service
from spaps_server_quickstart.domains.dayrate.errors import (
    ConfigNotFoundError,
    NoticePeriodViolationError,
    SlotUnavailableError,
)
from spaps_server_quickstart.domains.errors import ValidationError

_REPO = "spaps_server_quickstart.domains.dayrate.service.repo"

FAKE_APP_ID = uuid4()


def _make_config(**overrides) -> MagicMock:
    """Build a mock DayRateConfig model instance."""
    config = MagicMock()
    config.id = overrides.get("id", uuid4())
    config.application_id = overrides.get("application_id", FAKE_APP_ID)
    config.base_rate = overrides.get("base_rate", 10000)
    config.available_days = overrides.get(
        "available_days", ["monday", "tuesday", "wednesday", "thursday", "friday"]
    )
    config.slots = overrides.get("slots", None)
    config.fill_tiers = overrides.get("fill_tiers", None)
    config.time_tiers = overrides.get("time_tiers", None)
    config.horizon_weeks = overrides.get("horizon_weeks", 4)
    config.meeting_link = overrides.get("meeting_link", "https://meet.example.com")
    config.min_notice_hours = overrides.get("min_notice_hours", 24)
    config.hold_duration_minutes = overrides.get("hold_duration_minutes", 30)
    config.timezone = overrides.get("timezone", "America/New_York")
    config.slot_definitions = overrides.get("slot_definitions", None)
    config.currency = overrides.get("currency", "usd")
    config.product_name = overrides.get("product_name", "Day Rate Consulting")
    config.created_at = dt.datetime.now(dt.UTC)
    config.updated_at = dt.datetime.now(dt.UTC)
    return config


def _make_booking(**overrides) -> MagicMock:
    """Build a mock DayRateBooking model instance."""
    booking = MagicMock()
    booking.id = overrides.get("id", uuid4())
    booking.application_id = overrides.get("application_id", FAKE_APP_ID)
    booking.user_id = overrides.get("user_id", None)
    booking.date = overrides.get("date", dt.date.today() + dt.timedelta(days=7))
    booking.slot_type = overrides.get("slot_type", "AM")
    booking.client_email = overrides.get("client_email", "test@example.com")
    booking.client_name = overrides.get("client_name", "Test Client")
    booking.price_paid = overrides.get("price_paid", 10000)
    booking.stripe_session_id = overrides.get("stripe_session_id", "cs_test_123")
    booking.stripe_payment_intent_id = overrides.get("stripe_payment_intent_id", None)
    booking.status = overrides.get("status", "pending")
    booking.metadata_ = overrides.get("metadata_", {})
    booking.booking_group_id = overrides.get("booking_group_id", None)
    booking.expires_at = overrides.get("expires_at", None)
    booking.created_at = dt.datetime.now(dt.UTC)
    booking.updated_at = dt.datetime.now(dt.UTC)
    return booking


# ===========================================================================
# Internal helpers
# ===========================================================================


class TestGetSlotTypes:
    def test_prefers_slot_definition_keys(self):
        """Uses slot_definitions keys before legacy slots."""
        config = _make_config(
            slot_definitions={"MORNING": {}, "EVENING": {}},
            slots=["AM", "PM"],
        )

        assert service._get_slot_types(config) == ["MORNING", "EVENING"]

    def test_uses_valid_string_slots_from_list(self):
        """Filters non-string and empty entries from slots list."""
        config = _make_config(
            slot_definitions=None,
            slots=["AM", "", None, 0, "PM"],
        )

        assert service._get_slot_types(config) == ["AM", "PM"]

    def test_uses_slots_dict_keys_when_present(self):
        """Supports legacy slots stored as a dict."""
        config = _make_config(
            slot_definitions=None,
            slots={"EARLY": {"startHour": 8}, "LATE": {"startHour": 16}},
        )

        assert service._get_slot_types(config) == ["EARLY", "LATE"]

    def test_falls_back_to_default_slot_types(self):
        """Returns built-in defaults when no valid custom slots exist."""
        config = _make_config(slot_definitions=None, slots=[None, "", 123])

        assert service._get_slot_types(config) == service.DEFAULT_SLOT_TYPES


# ===========================================================================
# get_availability
# ===========================================================================


class TestGetAvailability:
    @patch(_REPO)
    async def test_returns_slots(self, mock_repo):
        """Returns slots within horizon."""
        config = _make_config(horizon_weeks=1)
        mock_repo.get_config = AsyncMock(return_value=config)
        mock_repo.get_bookings_in_range = AsyncMock(return_value=[])

        db = AsyncMock()
        result = await service.get_availability(
            db, application_id=FAKE_APP_ID
        )

        assert "slots" in result
        assert "currentFillRate" in result
        assert "totalSlots" in result
        assert "bookedSlots" in result
        assert "baseRate" in result
        assert "meetingLink" in result
        assert isinstance(result["slots"], list)
        assert result["bookedSlots"] >= 0

    @patch(_REPO)
    async def test_config_not_found_raises(self, mock_repo):
        """Raises ConfigNotFoundError when no config exists."""
        mock_repo.get_config = AsyncMock(return_value=None)

        db = AsyncMock()
        with pytest.raises(ConfigNotFoundError):
            await service.get_availability(
                db, application_id=FAKE_APP_ID
            )

    @patch(_REPO)
    async def test_booked_slots_marked_unavailable(self, mock_repo):
        """Already-booked slots are marked as unavailable."""
        # Use a specific future date that's definitely a weekday
        future = dt.date.today() + dt.timedelta(days=7)
        while future.strftime("%A").lower() not in [
            "monday", "tuesday", "wednesday", "thursday", "friday"
        ]:
            future += dt.timedelta(days=1)

        config = _make_config(horizon_weeks=2, min_notice_hours=0)
        mock_repo.get_config = AsyncMock(return_value=config)

        booked = _make_booking(date=future, slot_type="AM")
        mock_repo.get_bookings_in_range = AsyncMock(return_value=[booked])

        db = AsyncMock()
        result = await service.get_availability(
            db, application_id=FAKE_APP_ID
        )

        # Find the slot for the booked date/slot
        booked_slot = None
        for s in result["slots"]:
            if s["date"] == future.isoformat() and s["slot"] == "AM":
                booked_slot = s
                break

        assert booked_slot is not None
        assert booked_slot["available"] is False

    @patch(_REPO)
    async def test_custom_slot_definitions(self, mock_repo):
        """Uses custom slot definitions from config."""
        config = _make_config(
            slot_definitions={"MORNING": {}, "AFTERNOON": {}, "EVENING": {}},
            horizon_weeks=1,
            min_notice_hours=0,
        )
        mock_repo.get_config = AsyncMock(return_value=config)
        mock_repo.get_bookings_in_range = AsyncMock(return_value=[])

        db = AsyncMock()
        result = await service.get_availability(
            db, application_id=FAKE_APP_ID
        )

        # All slots should use the custom slot types
        slot_types = {s["slot"] for s in result["slots"]}
        assert slot_types <= {"MORNING", "AFTERNOON", "EVENING"}


# ===========================================================================
# book_slot
# ===========================================================================


class TestBookSlot:
    @patch(_REPO)
    async def test_success(self, mock_repo):
        """Books a slot and returns checkout info."""
        config = _make_config(min_notice_hours=0)
        mock_repo.get_config = AsyncMock(return_value=config)
        mock_repo.expire_stale_pendings = AsyncMock(return_value=0)

        future_date = dt.date.today() + dt.timedelta(days=7)
        mock_repo.get_bookings_for_date = AsyncMock(return_value=[])
        mock_repo.get_bookings_in_range = AsyncMock(return_value=[])

        booking = _make_booking(date=future_date)
        mock_repo.create_booking = AsyncMock(return_value=booking)

        db = AsyncMock()
        result = await service.book_slot(
            db,
            application_id=FAKE_APP_ID,
            date_str=future_date.isoformat(),
            slot="AM",
            client_email="test@example.com",
            client_name="Test Client",
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
        )

        assert "checkoutUrl" in result
        assert "bookingId" in result
        assert "price" in result
        assert "breakdown" in result
        assert "expiresAt" in result
        assert result["expiresIn"] == 1800
        mock_repo.create_booking.assert_called_once()

    @patch(_REPO)
    async def test_config_not_found_raises(self, mock_repo):
        """Raises ConfigNotFoundError when no config exists."""
        mock_repo.get_config = AsyncMock(return_value=None)

        db = AsyncMock()
        with pytest.raises(ConfigNotFoundError):
            await service.book_slot(
                db,
                application_id=FAKE_APP_ID,
                date_str="2025-06-15",
                slot="AM",
                client_email="test@example.com",
                client_name="Test Client",
                success_url="https://example.com/success",
                cancel_url="https://example.com/cancel",
            )

    @patch(_REPO)
    async def test_invalid_date_raises(self, mock_repo):
        """Raises ValidationError for invalid date format."""
        config = _make_config()
        mock_repo.get_config = AsyncMock(return_value=config)

        db = AsyncMock()
        with pytest.raises(ValidationError):
            await service.book_slot(
                db,
                application_id=FAKE_APP_ID,
                date_str="not-a-date",
                slot="AM",
                client_email="test@example.com",
                client_name="Test Client",
                success_url="https://example.com/success",
                cancel_url="https://example.com/cancel",
            )

    @patch(_REPO)
    async def test_invalid_slot_type_raises(self, mock_repo):
        """Raises ValidationError for invalid slot type."""
        config = _make_config()
        mock_repo.get_config = AsyncMock(return_value=config)

        future_date = dt.date.today() + dt.timedelta(days=7)
        db = AsyncMock()
        with pytest.raises(ValidationError):
            await service.book_slot(
                db,
                application_id=FAKE_APP_ID,
                date_str=future_date.isoformat(),
                slot="INVALID",
                client_email="test@example.com",
                client_name="Test Client",
                success_url="https://example.com/success",
                cancel_url="https://example.com/cancel",
            )

    @patch(_REPO)
    async def test_notice_period_violation_raises(self, mock_repo):
        """Raises NoticePeriodViolationError for same-day booking."""
        config = _make_config(min_notice_hours=48)
        mock_repo.get_config = AsyncMock(return_value=config)

        # Book for tomorrow (less than 48 hours)
        tomorrow = dt.date.today() + dt.timedelta(days=1)
        db = AsyncMock()
        with pytest.raises(NoticePeriodViolationError):
            await service.book_slot(
                db,
                application_id=FAKE_APP_ID,
                date_str=tomorrow.isoformat(),
                slot="AM",
                client_email="test@example.com",
                client_name="Test Client",
                success_url="https://example.com/success",
                cancel_url="https://example.com/cancel",
            )

    @patch(_REPO)
    async def test_slot_already_booked_raises(self, mock_repo):
        """Raises SlotUnavailableError when slot is already booked."""
        config = _make_config(min_notice_hours=0)
        mock_repo.get_config = AsyncMock(return_value=config)

        future_date = dt.date.today() + dt.timedelta(days=7)
        existing = _make_booking(date=future_date, slot_type="AM")
        mock_repo.get_bookings_for_date = AsyncMock(return_value=[existing])

        db = AsyncMock()
        with pytest.raises(SlotUnavailableError):
            await service.book_slot(
                db,
                application_id=FAKE_APP_ID,
                date_str=future_date.isoformat(),
                slot="AM",
                client_email="test@example.com",
                client_name="Test Client",
                success_url="https://example.com/success",
                cancel_url="https://example.com/cancel",
            )

    @patch(_REPO)
    async def test_with_stripe_checkout(self, mock_repo):
        """Uses the stripe_create_checkout callback when provided."""
        config = _make_config(min_notice_hours=0)
        mock_repo.get_config = AsyncMock(return_value=config)
        mock_repo.expire_stale_pendings = AsyncMock(return_value=0)

        future_date = dt.date.today() + dt.timedelta(days=7)
        mock_repo.get_bookings_for_date = AsyncMock(return_value=[])
        mock_repo.get_bookings_in_range = AsyncMock(return_value=[])
        booking = _make_booking(date=future_date)
        mock_repo.create_booking = AsyncMock(return_value=booking)

        stripe_mock = AsyncMock(return_value={
            "id": "cs_real_123",
            "url": "https://checkout.stripe.com/pay/cs_real_123",
        })

        db = AsyncMock()
        result = await service.book_slot(
            db,
            application_id=FAKE_APP_ID,
            date_str=future_date.isoformat(),
            slot="AM",
            client_email="test@example.com",
            client_name="Test Client",
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
            stripe_create_checkout=stripe_mock,
        )

        assert "checkout.stripe.com" in result["checkoutUrl"]
        assert result["bookingId"] == str(booking.id)
        assert result["price"] > 0
        assert "breakdown" in result
        stripe_mock.assert_called_once()

    @patch(_REPO)
    async def test_handles_integrity_error(self, mock_repo):
        """When DB raises IntegrityError (concurrent booking), raise SlotUnavailableError."""
        config = _make_config(min_notice_hours=0)
        mock_repo.get_config = AsyncMock(return_value=config)
        mock_repo.expire_stale_pendings = AsyncMock(return_value=0)

        future_date = dt.date.today() + dt.timedelta(days=7)
        mock_repo.get_bookings_for_date = AsyncMock(return_value=[])
        mock_repo.get_bookings_in_range = AsyncMock(return_value=[])

        # Simulate a concurrent booking: create_booking raises IntegrityError
        mock_repo.create_booking = AsyncMock(
            side_effect=IntegrityError("duplicate", {}, None)
        )

        db = AsyncMock()
        with pytest.raises(SlotUnavailableError, match="just booked by another user"):
            await service.book_slot(
                db,
                application_id=FAKE_APP_ID,
                date_str=future_date.isoformat(),
                slot="AM",
                client_email="test@example.com",
                client_name="Test Client",
                success_url="https://example.com/success",
                cancel_url="https://example.com/cancel",
            )

        db.rollback.assert_called_once()


# ===========================================================================
# book_multi
# ===========================================================================


class TestBookMulti:
    @patch(_REPO)
    async def test_success(self, mock_repo):
        """Books multiple slots and returns checkout info."""
        config = _make_config(min_notice_hours=0)
        mock_repo.get_config = AsyncMock(return_value=config)
        mock_repo.expire_stale_pendings = AsyncMock(return_value=0)

        future1 = dt.date.today() + dt.timedelta(days=7)
        future2 = dt.date.today() + dt.timedelta(days=8)

        mock_repo.get_bookings_for_date = AsyncMock(return_value=[])
        mock_repo.get_bookings_in_range = AsyncMock(return_value=[])
        booking = _make_booking()
        mock_repo.create_booking = AsyncMock(return_value=booking)

        db = AsyncMock()
        result = await service.book_multi(
            db,
            application_id=FAKE_APP_ID,
            slots=[
                {"date": future1.isoformat(), "slot": "AM"},
                {"date": future2.isoformat(), "slot": "PM"},
            ],
            client_email="test@example.com",
            client_name="Test Client",
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
        )

        assert "checkoutUrl" in result
        assert "bookingGroupId" in result
        assert "bookingIds" in result
        assert "totalPrice" in result
        assert "priceBreakdowns" in result
        assert "expiresAt" in result
        assert result["expiresIn"] == 1800
        assert result["totalPrice"] > 0
        assert len(result["bookingIds"]) == 2
        assert len(result["priceBreakdowns"]) == 2
        # Two bookings should be created
        assert mock_repo.create_booking.call_count == 2

    @patch(_REPO)
    async def test_config_not_found_raises(self, mock_repo):
        """Raises ConfigNotFoundError when no config exists."""
        mock_repo.get_config = AsyncMock(return_value=None)

        db = AsyncMock()
        with pytest.raises(ConfigNotFoundError):
            await service.book_multi(
                db,
                application_id=FAKE_APP_ID,
                slots=[{"date": "2025-06-15", "slot": "AM"}],
                client_email="test@example.com",
                client_name="Test Client",
                success_url="https://example.com/success",
                cancel_url="https://example.com/cancel",
            )

    @patch(_REPO)
    async def test_empty_slots_raises(self, mock_repo):
        """Raises ValidationError for empty slots list."""
        config = _make_config()
        mock_repo.get_config = AsyncMock(return_value=config)

        db = AsyncMock()
        with pytest.raises(ValidationError):
            await service.book_multi(
                db,
                application_id=FAKE_APP_ID,
                slots=[],
                client_email="test@example.com",
                client_name="Test Client",
                success_url="https://example.com/success",
                cancel_url="https://example.com/cancel",
            )

    @patch(_REPO)
    async def test_one_unavailable_fails_all(self, mock_repo):
        """If any slot is unavailable, the entire booking fails."""
        config = _make_config(min_notice_hours=0)
        mock_repo.get_config = AsyncMock(return_value=config)

        future1 = dt.date.today() + dt.timedelta(days=7)
        future2 = dt.date.today() + dt.timedelta(days=8)

        existing = _make_booking(date=future2, slot_type="PM")
        mock_repo.get_bookings_for_date = AsyncMock(
            side_effect=[[], [existing]]
        )
        mock_repo.get_bookings_in_range = AsyncMock(return_value=[])

        db = AsyncMock()
        with pytest.raises(SlotUnavailableError):
            await service.book_multi(
                db,
                application_id=FAKE_APP_ID,
                slots=[
                    {"date": future1.isoformat(), "slot": "AM"},
                    {"date": future2.isoformat(), "slot": "PM"},
                ],
                client_email="test@example.com",
                client_name="Test Client",
                success_url="https://example.com/success",
                cancel_url="https://example.com/cancel",
            )

    @patch(_REPO)
    async def test_notice_period_violation_in_multi(self, mock_repo):
        """NoticePeriodViolationError raised for any slot within notice period."""
        config = _make_config(min_notice_hours=48)
        mock_repo.get_config = AsyncMock(return_value=config)
        mock_repo.get_bookings_in_range = AsyncMock(return_value=[])

        tomorrow = dt.date.today() + dt.timedelta(days=1)
        db = AsyncMock()
        with pytest.raises(NoticePeriodViolationError):
            await service.book_multi(
                db,
                application_id=FAKE_APP_ID,
                slots=[{"date": tomorrow.isoformat(), "slot": "AM"}],
                client_email="test@example.com",
                client_name="Test Client",
                success_url="https://example.com/success",
                cancel_url="https://example.com/cancel",
            )

    @patch(_REPO)
    async def test_handles_integrity_error(self, mock_repo):
        """When DB raises IntegrityError during multi-booking, raise SlotUnavailableError."""
        config = _make_config(min_notice_hours=0)
        mock_repo.get_config = AsyncMock(return_value=config)
        mock_repo.expire_stale_pendings = AsyncMock(return_value=0)

        future1 = dt.date.today() + dt.timedelta(days=7)
        future2 = dt.date.today() + dt.timedelta(days=8)

        mock_repo.get_bookings_for_date = AsyncMock(return_value=[])
        mock_repo.get_bookings_in_range = AsyncMock(return_value=[])

        # First create_booking succeeds, second raises IntegrityError
        booking = _make_booking()
        mock_repo.create_booking = AsyncMock(
            side_effect=[booking, IntegrityError("duplicate", {}, None)]
        )

        db = AsyncMock()
        with pytest.raises(SlotUnavailableError, match="just booked by another user"):
            await service.book_multi(
                db,
                application_id=FAKE_APP_ID,
                slots=[
                    {"date": future1.isoformat(), "slot": "AM"},
                    {"date": future2.isoformat(), "slot": "PM"},
                ],
                client_email="test@example.com",
                client_name="Test Client",
                success_url="https://example.com/success",
                cancel_url="https://example.com/cancel",
            )

        db.rollback.assert_called_once()


# ===========================================================================
# get_config (admin)
# ===========================================================================


class TestGetConfig:
    @patch(_REPO)
    async def test_returns_config(self, mock_repo):
        """Returns config dict for the application."""
        config = _make_config()
        mock_repo.get_config = AsyncMock(return_value=config)

        db = AsyncMock()
        result = await service.get_config(
            db, application_id=FAKE_APP_ID
        )

        assert "config" in result
        assert result["config"]["base_rate"] == 10000

    @patch(_REPO)
    async def test_not_found_raises(self, mock_repo):
        """Raises ConfigNotFoundError when no config exists."""
        mock_repo.get_config = AsyncMock(return_value=None)

        db = AsyncMock()
        with pytest.raises(ConfigNotFoundError):
            await service.get_config(
                db, application_id=FAKE_APP_ID
            )


# ===========================================================================
# update_config (admin)
# ===========================================================================


class TestUpdateConfig:
    @patch(_REPO)
    async def test_updates_config(self, mock_repo):
        """Updates config and returns new values."""
        config = _make_config(base_rate=15000)
        mock_repo.upsert_config = AsyncMock(return_value=config)

        db = AsyncMock()
        result = await service.update_config(
            db,
            application_id=FAKE_APP_ID,
            base_rate=15000,
        )

        assert "config" in result
        assert "message" in result
        assert result["config"]["base_rate"] == 15000

    @patch(_REPO)
    async def test_creates_config_on_upsert(self, mock_repo):
        """Creates config if none exists (upsert behavior)."""
        config = _make_config(base_rate=20000)
        mock_repo.upsert_config = AsyncMock(return_value=config)

        db = AsyncMock()
        result = await service.update_config(
            db,
            application_id=FAKE_APP_ID,
            base_rate=20000,
            horizon_weeks=6,
        )

        assert result["config"]["base_rate"] == 20000


# ===========================================================================
# list_bookings (admin)
# ===========================================================================


class TestListBookings:
    @patch(_REPO)
    async def test_returns_bookings(self, mock_repo):
        """Returns bookings list and total."""
        booking = _make_booking()
        mock_repo.list_bookings = AsyncMock(return_value=([booking], 1))

        db = AsyncMock()
        result = await service.list_bookings(
            db, application_id=FAKE_APP_ID
        )

        assert result["total"] == 1
        assert len(result["bookings"]) == 1

    @patch(_REPO)
    async def test_with_filters(self, mock_repo):
        """Passes filter parameters to repository."""
        mock_repo.list_bookings = AsyncMock(return_value=([], 0))

        db = AsyncMock()
        result = await service.list_bookings(
            db,
            application_id=FAKE_APP_ID,
            status="confirmed",
            start_date="2025-06-01",
            end_date="2025-06-30",
            limit=50,
            offset=10,
        )

        assert result["total"] == 0
        assert result["bookings"] == []

    @patch(_REPO)
    async def test_invalid_date_raises(self, mock_repo):
        """Raises ValidationError for invalid date format."""
        db = AsyncMock()
        with pytest.raises(ValidationError):
            await service.list_bookings(
                db,
                application_id=FAKE_APP_ID,
                start_date="bad-date",
            )


# ===========================================================================
# _check_notice_period timezone handling (Fix #7)
# ===========================================================================


class TestCheckNoticePeriodTimezone:
    def test_utc_timezone_uses_utc(self):
        """UTC timezone should not alter the notice period."""
        booking_date = dt.date(2026, 3, 15)
        # 23 hours before midnight UTC on 2026-03-15
        now = dt.datetime(2026, 3, 14, 1, 0, 0, tzinfo=dt.UTC)

        result = service._check_notice_period(
            booking_date, "AM", min_notice_hours=24, timezone="UTC", now=now
        )
        assert result is False  # Only 23 hours

    def test_timezone_offset_applied(self):
        """Non-UTC timezone should shift the effective booking datetime."""
        booking_date = dt.date(2026, 3, 15)

        # At midnight UTC on March 15 — in America/New_York (EST, UTC-5),
        # midnight local is 05:00 UTC, so there are 5 more hours of buffer.
        now = dt.datetime(2026, 3, 14, 1, 0, 0, tzinfo=dt.UTC)

        # With UTC timezone: booking_dt = 2026-03-15 00:00 UTC, hours_until = 23
        result_utc = service._check_notice_period(
            booking_date, "AM", min_notice_hours=24, timezone="UTC", now=now
        )
        assert result_utc is False  # 23 hours < 24

        # With America/New_York (UTC-5): booking_dt = 2026-03-15 05:00 UTC
        # hours_until = 28
        result_ny = service._check_notice_period(
            booking_date, "AM", min_notice_hours=24, timezone="America/New_York", now=now
        )
        assert result_ny is True  # 28 hours >= 24

    def test_empty_timezone_defaults_to_utc(self):
        """Empty timezone string should default to UTC behaviour."""
        booking_date = dt.date(2026, 3, 15)
        now = dt.datetime(2026, 3, 14, 1, 0, 0, tzinfo=dt.UTC)

        result = service._check_notice_period(
            booking_date, "AM", min_notice_hours=24, timezone="", now=now
        )
        assert result is False  # 23 hours < 24


# ===========================================================================
# Horizon-wide fill rate (must match Node pricing scope)
# ===========================================================================

_CALC_PRICE = "spaps_server_quickstart.domains.dayrate.service.calculate_price_with_breakdown"


class TestHorizonWideFillRate:
    """The fill_percent passed to calculate_price must be computed across the
    entire booking horizon, NOT per-day. This matches the Node legacy engine.
    """

    @patch(_CALC_PRICE, wraps=service.calculate_price_with_breakdown)
    @patch(_REPO)
    async def test_availability_uses_horizon_wide_fill(
        self, mock_repo, mock_calc_price
    ):
        """get_availability should pass fill_percent = total_booked / total_horizon_slots."""
        config = _make_config(
            horizon_weeks=1,
            min_notice_hours=0,
            # Mon-Fri, 2 slots/day → 5 days * 2 slots = 10 total slots for 1 week
            available_days=["monday", "tuesday", "wednesday", "thursday", "friday"],
        )
        mock_repo.get_config = AsyncMock(return_value=config)

        # 1 booking exists across the entire horizon
        future = dt.date.today() + dt.timedelta(days=3)
        while future.strftime("%A").lower() not in [
            "monday", "tuesday", "wednesday", "thursday", "friday"
        ]:
            future += dt.timedelta(days=1)

        booked = _make_booking(date=future, slot_type="AM")
        mock_repo.get_bookings_in_range = AsyncMock(return_value=[booked])

        db = AsyncMock()
        await service.get_availability(db, application_id=FAKE_APP_ID)

        # Verify calculate_price was called with horizon-wide fill_percent
        # 1 booking / total_slots (should be >= 10 for a week of Mon-Fri, 2 slots/day)
        for call in mock_calc_price.call_args_list:
            fill_pct = call.kwargs.get("fill_percent", call.args[1] if len(call.args) > 1 else None)
            if fill_pct is None:
                continue
            # Per-day would give 50% (1/2) for the booked day. Horizon-wide should be <=20% (1/5..10)
            assert fill_pct < 25, (
                f"fill_percent={fill_pct}% looks per-day, not horizon-wide. "
                f"Expected <= 20% for 1 booking across a week."
            )

    @patch(_CALC_PRICE, wraps=service.calculate_price_with_breakdown)
    @patch(_REPO)
    async def test_book_slot_uses_horizon_wide_fill(
        self, mock_repo, mock_calc_price
    ):
        """book_slot should calculate fill_percent across the horizon, not per-day."""
        config = _make_config(
            horizon_weeks=1,
            min_notice_hours=0,
            available_days=["monday", "tuesday", "wednesday", "thursday", "friday"],
        )
        mock_repo.get_config = AsyncMock(return_value=config)
        mock_repo.expire_stale_pendings = AsyncMock(return_value=0)

        # Target a weekday 7 days out
        future_date = dt.date.today() + dt.timedelta(days=7)
        while future_date.strftime("%A").lower() not in [
            "monday", "tuesday", "wednesday", "thursday", "friday"
        ]:
            future_date += dt.timedelta(days=1)

        # No bookings on target date, but 3 bookings exist on other dates
        mock_repo.get_bookings_for_date = AsyncMock(return_value=[])

        # 3 bookings across the horizon (for get_bookings_in_range)
        other_day = future_date - dt.timedelta(days=2)
        if other_day.strftime("%A").lower() not in [
            "monday", "tuesday", "wednesday", "thursday", "friday"
        ]:
            other_day = future_date - dt.timedelta(days=1)
        bookings_in_range = [
            _make_booking(date=other_day, slot_type="AM"),
            _make_booking(date=other_day, slot_type="PM"),
            _make_booking(date=future_date - dt.timedelta(days=3), slot_type="AM"),
        ]
        mock_repo.get_bookings_in_range = AsyncMock(return_value=bookings_in_range)

        booking = _make_booking(date=future_date)
        mock_repo.create_booking = AsyncMock(return_value=booking)

        db = AsyncMock()
        await service.book_slot(
            db,
            application_id=FAKE_APP_ID,
            date_str=future_date.isoformat(),
            slot="AM",
            client_email="test@example.com",
            client_name="Test Client",
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
        )

        # Verify fill_percent was calculated using horizon data, not per-day
        assert mock_calc_price.call_count >= 1
        fill_pct = mock_calc_price.call_args.kwargs.get("fill_percent")
        # 3 bookings across ~10 slots = ~30%. Per-day would be 0% (no bookings on target date)
        assert fill_pct > 0, (
            f"fill_percent={fill_pct}% — book_slot should use horizon-wide fill, "
            f"not per-day (which would be 0% since target date has no bookings)"
        )


# ===========================================================================
# Multi-booking price escalation (running booked count)
# ===========================================================================


class TestMultiBookingEscalation:
    """When booking multiple slots, each subsequent slot should see an
    incrementing fill count (matching Node's runningBookedCount logic).
    """

    @patch(_CALC_PRICE, wraps=service.calculate_price_with_breakdown)
    @patch(_REPO)
    async def test_book_multi_increments_fill_per_slot(
        self, mock_repo, mock_calc_price
    ):
        """Each slot in a multi-booking should see a higher fill_percent than the last."""
        config = _make_config(
            horizon_weeks=1,
            min_notice_hours=0,
            available_days=["monday", "tuesday", "wednesday", "thursday", "friday"],
        )
        mock_repo.get_config = AsyncMock(return_value=config)
        mock_repo.expire_stale_pendings = AsyncMock(return_value=0)

        # Pick two weekday dates
        future1 = dt.date.today() + dt.timedelta(days=7)
        while future1.strftime("%A").lower() not in [
            "monday", "tuesday", "wednesday", "thursday", "friday"
        ]:
            future1 += dt.timedelta(days=1)
        future2 = future1 + dt.timedelta(days=1)
        while future2.strftime("%A").lower() not in [
            "monday", "tuesday", "wednesday", "thursday", "friday"
        ]:
            future2 += dt.timedelta(days=1)

        # No existing bookings
        mock_repo.get_bookings_for_date = AsyncMock(return_value=[])
        mock_repo.get_bookings_in_range = AsyncMock(return_value=[])

        booking = _make_booking()
        mock_repo.create_booking = AsyncMock(return_value=booking)

        db = AsyncMock()
        await service.book_multi(
            db,
            application_id=FAKE_APP_ID,
            slots=[
                {"date": future1.isoformat(), "slot": "AM"},
                {"date": future2.isoformat(), "slot": "PM"},
            ],
            client_email="test@example.com",
            client_name="Test Client",
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
        )

        # calculate_price should be called twice: once per slot
        price_calls = [c for c in mock_calc_price.call_args_list if "fill_percent" in c.kwargs]
        assert len(price_calls) >= 2, f"Expected 2 price calls, got {len(price_calls)}"

        fill_pcts = [c.kwargs["fill_percent"] for c in price_calls]
        # Second slot should have higher fill_percent than first
        assert fill_pcts[1] > fill_pcts[0], (
            f"Second slot fill_percent ({fill_pcts[1]}%) should be higher than "
            f"first ({fill_pcts[0]}%) due to running booked count."
        )


# ===========================================================================
# Configurable hold duration
# ===========================================================================


class TestHoldDuration:
    @patch(_REPO)
    async def test_book_slot_uses_config_hold_duration(self, mock_repo):
        """book_slot uses hold_duration_minutes from config, not hardcoded 30."""
        config = _make_config(min_notice_hours=0, hold_duration_minutes=15)
        mock_repo.get_config = AsyncMock(return_value=config)
        mock_repo.expire_stale_pendings = AsyncMock(return_value=0)

        future_date = dt.date.today() + dt.timedelta(days=7)
        mock_repo.get_bookings_for_date = AsyncMock(return_value=[])
        mock_repo.get_bookings_in_range = AsyncMock(return_value=[])

        booking = _make_booking(date=future_date)
        mock_repo.create_booking = AsyncMock(return_value=booking)

        db = AsyncMock()
        result = await service.book_slot(
            db,
            application_id=FAKE_APP_ID,
            date_str=future_date.isoformat(),
            slot="AM",
            client_email="test@example.com",
            client_name="Test Client",
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
        )

        assert result["expiresIn"] == 900  # 15 * 60

        # Verify expires_at passed to create_booking is ~15 min from now
        call_kwargs = mock_repo.create_booking.call_args.kwargs
        assert call_kwargs["expires_at"] is not None

    @patch(_REPO)
    async def test_book_multi_uses_config_hold_duration(self, mock_repo):
        """book_multi uses hold_duration_minutes from config."""
        config = _make_config(min_notice_hours=0, hold_duration_minutes=45)
        mock_repo.get_config = AsyncMock(return_value=config)
        mock_repo.expire_stale_pendings = AsyncMock(return_value=0)

        future1 = dt.date.today() + dt.timedelta(days=7)
        mock_repo.get_bookings_for_date = AsyncMock(return_value=[])
        mock_repo.get_bookings_in_range = AsyncMock(return_value=[])

        booking = _make_booking()
        mock_repo.create_booking = AsyncMock(return_value=booking)

        db = AsyncMock()
        result = await service.book_multi(
            db,
            application_id=FAKE_APP_ID,
            slots=[{"date": future1.isoformat(), "slot": "AM"}],
            client_email="test@example.com",
            client_name="Test Client",
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
        )

        assert result["expiresIn"] == 2700  # 45 * 60

    @patch(_REPO)
    async def test_hold_duration_in_config_dict(self, mock_repo):
        """hold_duration_minutes is included in the config response."""
        config = _make_config(hold_duration_minutes=20)
        mock_repo.get_config = AsyncMock(return_value=config)

        db = AsyncMock()
        result = await service.get_config(db, application_id=FAKE_APP_ID)

        assert result["config"]["hold_duration_minutes"] == 20


# ===========================================================================
# get_upcoming_bookings_for_users
# ===========================================================================


class TestGetUpcomingBookingsForUsers:
    @patch(_REPO)
    async def test_merges_dedupes_and_sorts_bookings(self, mock_repo):
        """Merges user/email matches, skips dupes, and sorts per user."""
        user_one = str(uuid4())
        user_two = str(uuid4())
        invalid_user = "not-a-uuid"
        start_date = dt.date.today() + dt.timedelta(days=1)

        user_booking = _make_booking(
            id=uuid4(),
            user_id=user_one,
            date=start_date + dt.timedelta(days=2),
            slot_type="PM",
            status="confirmed",
        )
        user_booking.is_free = False
        user_booking.enrollment_id = None

        second_user_booking = _make_booking(
            id=uuid4(),
            user_id=user_two,
            date=start_date + dt.timedelta(days=1),
            slot_type="AM",
            status="held",
        )
        second_user_booking.is_free = True
        second_user_booking.enrollment_id = "enr-2"

        email_booking = _make_booking(
            id=uuid4(),
            user_id=None,
            client_email="user1@example.com",
            date=start_date,
            slot_type="AM",
            status="confirmed",
        )
        email_booking.is_free = True
        email_booking.enrollment_id = "enr-1"

        duplicate_email_booking = _make_booking(
            id=user_booking.id,
            user_id=None,
            client_email="user1@example.com",
            date=user_booking.date,
            slot_type=user_booking.slot_type,
            status=user_booking.status,
        )
        duplicate_email_booking.is_free = False
        duplicate_email_booking.enrollment_id = None

        unmatched_email_booking = _make_booking(
            id=uuid4(),
            user_id=None,
            client_email="other@example.com",
            date=start_date + dt.timedelta(days=3),
        )
        unmatched_email_booking.is_free = False
        unmatched_email_booking.enrollment_id = None

        missing_email_booking = _make_booking(
            id=uuid4(),
            user_id=None,
            client_email=None,
            date=start_date + dt.timedelta(days=4),
        )
        missing_email_booking.is_free = False
        missing_email_booking.enrollment_id = None

        mock_repo.get_upcoming_bookings_by_user_ids = AsyncMock(
            return_value=[user_booking, second_user_booking]
        )
        mock_repo.get_upcoming_bookings_by_emails = AsyncMock(
            return_value=[
                email_booking,
                duplicate_email_booking,
                unmatched_email_booking,
                missing_email_booking,
            ]
        )

        db = AsyncMock()
        result = await service.get_upcoming_bookings_for_users(
            db,
            application_id=FAKE_APP_ID,
            user_ids=[user_one, user_two, invalid_user],
            emails={
                user_one: "user1@example.com",
                user_two: "user2@example.com",
            },
        )

        assert [booking["bookingId"] for booking in result[user_one]] == [
            str(email_booking.id),
            str(user_booking.id),
        ]
        assert result[user_one][0]["isFree"] is True
        assert result[user_one][0]["enrollmentId"] == "enr-1"
        assert result[user_two] == [
            {
                "bookingId": str(second_user_booking.id),
                "date": second_user_booking.date.isoformat(),
                "slot": "AM",
                "status": "held",
                "isFree": True,
                "enrollmentId": "enr-2",
            }
        ]
        assert result[invalid_user] == []

        user_ids_args = mock_repo.get_upcoming_bookings_by_user_ids.await_args.args[2]
        assert [str(value) for value in user_ids_args] == [user_one, user_two]

        emails_args = mock_repo.get_upcoming_bookings_by_emails.await_args.args
        assert emails_args[2] == ["user1@example.com", "user2@example.com"]
        assert (emails_args[4] - emails_args[3]).days == 28

    @patch(_REPO)
    async def test_returns_empty_lists_when_no_bookings_found(self, mock_repo):
        """Initialises all requested users even when no bookings match."""
        user_id = str(uuid4())
        mock_repo.get_upcoming_bookings_by_user_ids = AsyncMock(return_value=[])
        mock_repo.get_upcoming_bookings_by_emails = AsyncMock(return_value=[])

        db = AsyncMock()
        result = await service.get_upcoming_bookings_for_users(
            db,
            application_id=FAKE_APP_ID,
            user_ids=[user_id],
            emails={},
        )

        assert result == {user_id: []}
        assert mock_repo.get_upcoming_bookings_by_emails.await_args.args[2] == []


# ===========================================================================
# Lazy expiry of stale pending bookings
# ===========================================================================


class TestLazyExpiry:
    @patch(_REPO)
    async def test_book_slot_calls_expire_stale_pendings(self, mock_repo):
        """book_slot expires stale pendings before creating the new booking."""
        config = _make_config(min_notice_hours=0)
        mock_repo.get_config = AsyncMock(return_value=config)
        mock_repo.expire_stale_pendings = AsyncMock(return_value=0)

        future_date = dt.date.today() + dt.timedelta(days=7)
        mock_repo.get_bookings_for_date = AsyncMock(return_value=[])
        mock_repo.get_bookings_in_range = AsyncMock(return_value=[])

        booking = _make_booking(date=future_date)
        mock_repo.create_booking = AsyncMock(return_value=booking)

        db = AsyncMock()
        await service.book_slot(
            db,
            application_id=FAKE_APP_ID,
            date_str=future_date.isoformat(),
            slot="AM",
            client_email="test@example.com",
            client_name="Test Client",
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
        )

        mock_repo.expire_stale_pendings.assert_called_once_with(
            db, FAKE_APP_ID, future_date, "AM"
        )

    @patch(_REPO)
    async def test_book_multi_calls_expire_stale_pendings_per_slot(self, mock_repo):
        """book_multi expires stale pendings for each slot before creating bookings."""
        config = _make_config(min_notice_hours=0)
        mock_repo.get_config = AsyncMock(return_value=config)
        mock_repo.expire_stale_pendings = AsyncMock(return_value=0)

        future1 = dt.date.today() + dt.timedelta(days=7)
        future2 = dt.date.today() + dt.timedelta(days=8)
        mock_repo.get_bookings_for_date = AsyncMock(return_value=[])
        mock_repo.get_bookings_in_range = AsyncMock(return_value=[])

        booking = _make_booking()
        mock_repo.create_booking = AsyncMock(return_value=booking)

        db = AsyncMock()
        await service.book_multi(
            db,
            application_id=FAKE_APP_ID,
            slots=[
                {"date": future1.isoformat(), "slot": "AM"},
                {"date": future2.isoformat(), "slot": "PM"},
            ],
            client_email="test@example.com",
            client_name="Test Client",
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
        )

        assert mock_repo.expire_stale_pendings.call_count == 2
