"""Unit tests for the dayrate pricing module.

Tests match the Node/Express legacy pricing engine behaviour:
- Fill tiers use {maxPercent, multiplier} — picks ONE matching tier (first where
  fillPercent <= maxPercent), does NOT cascade.
- Time tiers use {minDays, multiplier} — picks ONE matching tier (first where
  daysUntil >= minDays, sorted descending), does NOT cascade.
- Final price uses round() (nearest integer), not ceil().
"""

from __future__ import annotations

from spaps_server_quickstart.domains.dayrate.pricing import (
    calculate_price,
    calculate_price_with_breakdown,
)


# ===========================================================================
# No tiers
# ===========================================================================


class TestNoTiers:
    def test_base_rate_no_tiers(self):
        """Returns base rate when no tiers are configured."""
        assert calculate_price(base_rate=10000, fill_percent=0, days_until=14) == 10000

    def test_empty_tiers_list(self):
        """Empty tier lists treated same as None."""
        result = calculate_price(
            base_rate=10000,
            fill_percent=50,
            days_until=2,
            fill_tiers=[],
            time_tiers=[],
        )
        assert result == 10000


# ===========================================================================
# Fill tiers — match Node's single-pick logic using maxPercent
# ===========================================================================


class TestFillTiers:
    """Node logic: sort by maxPercent ASC, return first tier where fillPercent <= maxPercent."""

    def test_picks_first_matching_tier(self):
        """40% fill hits the 0-50 tier (multiplier 1.5), not the 50-100 tier."""
        fill_tiers = [
            {"maxPercent": 50, "multiplier": 1.5},
            {"maxPercent": 100, "multiplier": 2.0},
        ]
        result = calculate_price(
            base_rate=10000, fill_percent=40, days_until=14, fill_tiers=fill_tiers
        )
        # 10000 * 1.5 = 15000
        assert result == 15000

    def test_exact_boundary_uses_current_tier(self):
        """Exactly 50% fill uses the tier whose maxPercent == 50."""
        fill_tiers = [
            {"maxPercent": 50, "multiplier": 1.5},
            {"maxPercent": 100, "multiplier": 2.0},
        ]
        result = calculate_price(
            base_rate=10000, fill_percent=50, days_until=14, fill_tiers=fill_tiers
        )
        # 50 <= 50 matches first tier → 1.5
        assert result == 15000

    def test_above_first_tier_uses_next(self):
        """51% fill exceeds the 50 tier, picks the 100 tier."""
        fill_tiers = [
            {"maxPercent": 50, "multiplier": 1.5},
            {"maxPercent": 100, "multiplier": 2.0},
        ]
        result = calculate_price(
            base_rate=10000, fill_percent=51, days_until=14, fill_tiers=fill_tiers
        )
        # 10000 * 2.0 = 20000
        assert result == 20000

    def test_does_not_cascade_multipliers(self):
        """Multiple tiers below fill percent should NOT cascade — only one applies."""
        fill_tiers = [
            {"maxPercent": 30, "multiplier": 1.0},
            {"maxPercent": 60, "multiplier": 1.5},
            {"maxPercent": 100, "multiplier": 2.0},
        ]
        # 45% → first tier where 45 <= maxPercent is the 60 tier → 1.5x
        result = calculate_price(
            base_rate=10000, fill_percent=45, days_until=14, fill_tiers=fill_tiers
        )
        assert result == 15000  # NOT 10000 * 1.0 * 1.5 = 15000 (same number, but different logic)

    def test_high_fill_picks_highest_tier(self):
        """90% fill picks the 100% tier."""
        fill_tiers = [
            {"maxPercent": 30, "multiplier": 1.0},
            {"maxPercent": 60, "multiplier": 1.5},
            {"maxPercent": 100, "multiplier": 2.0},
        ]
        result = calculate_price(
            base_rate=10000, fill_percent=90, days_until=14, fill_tiers=fill_tiers
        )
        # 90 > 60, 90 <= 100 → 2.0x
        assert result == 20000

    def test_above_all_tiers_uses_highest(self):
        """Fill percent above all maxPercent values uses the highest tier's multiplier."""
        fill_tiers = [
            {"maxPercent": 50, "multiplier": 1.5},
            {"maxPercent": 80, "multiplier": 2.0},
        ]
        result = calculate_price(
            base_rate=10000, fill_percent=95, days_until=14, fill_tiers=fill_tiers
        )
        # Above all → use highest (2.0x)
        assert result == 20000

    def test_zero_fill_picks_lowest_tier(self):
        """0% fill matches the first (lowest) tier."""
        fill_tiers = [
            {"maxPercent": 30, "multiplier": 1.0},
            {"maxPercent": 60, "multiplier": 1.5},
            {"maxPercent": 100, "multiplier": 2.0},
        ]
        result = calculate_price(
            base_rate=10000, fill_percent=0, days_until=14, fill_tiers=fill_tiers
        )
        assert result == 10000

    def test_unsorted_tiers_still_work(self):
        """Tiers provided out of order are sorted internally."""
        fill_tiers = [
            {"maxPercent": 100, "multiplier": 2.0},
            {"maxPercent": 30, "multiplier": 1.0},
            {"maxPercent": 60, "multiplier": 1.5},
        ]
        result = calculate_price(
            base_rate=10000, fill_percent=45, days_until=14, fill_tiers=fill_tiers
        )
        # Sorted → [30, 60, 100]; 45 > 30, 45 <= 60 → 1.5x
        assert result == 15000

    def test_production_tiers(self):
        """Match the production default tiers from the Node migration."""
        fill_tiers = [
            {"maxPercent": 25, "multiplier": 1.0},
            {"maxPercent": 50, "multiplier": 1.5},
            {"maxPercent": 75, "multiplier": 2.5},
            {"maxPercent": 100, "multiplier": 5.0},
        ]
        # 0% fill → 1.0x
        assert calculate_price(base_rate=10000, fill_percent=0, days_until=28, fill_tiers=fill_tiers) == 10000
        # 30% fill → 1.5x
        assert calculate_price(base_rate=10000, fill_percent=30, days_until=28, fill_tiers=fill_tiers) == 15000
        # 60% fill → 2.5x
        assert calculate_price(base_rate=10000, fill_percent=60, days_until=28, fill_tiers=fill_tiers) == 25000
        # 80% fill → 5.0x
        assert calculate_price(base_rate=10000, fill_percent=80, days_until=28, fill_tiers=fill_tiers) == 50000


# ===========================================================================
# Time tiers — match Node's single-pick logic using minDays
# ===========================================================================


class TestTimeTiers:
    """Node logic: sort by minDays DESC, return first tier where daysUntil >= minDays."""

    def test_far_out_booking_picks_highest_minDays(self):
        """30 days out matches the 14-day tier."""
        time_tiers = [
            {"minDays": 14, "multiplier": 1.0},
            {"minDays": 7, "multiplier": 1.25},
            {"minDays": 0, "multiplier": 1.5},
        ]
        result = calculate_price(
            base_rate=10000, fill_percent=0, days_until=30, time_tiers=time_tiers
        )
        # Sorted desc: [14, 7, 0]; 30 >= 14 → 1.0x
        assert result == 10000

    def test_mid_range_booking(self):
        """10 days out matches the 7-day tier."""
        time_tiers = [
            {"minDays": 14, "multiplier": 1.0},
            {"minDays": 7, "multiplier": 1.25},
            {"minDays": 0, "multiplier": 1.5},
        ]
        result = calculate_price(
            base_rate=10000, fill_percent=0, days_until=10, time_tiers=time_tiers
        )
        # 10 >= 14? No. 10 >= 7? Yes → 1.25x
        assert result == 12500

    def test_close_booking_picks_lowest_tier(self):
        """3 days out matches the 0-day tier."""
        time_tiers = [
            {"minDays": 14, "multiplier": 1.0},
            {"minDays": 7, "multiplier": 1.25},
            {"minDays": 0, "multiplier": 1.5},
        ]
        result = calculate_price(
            base_rate=10000, fill_percent=0, days_until=3, time_tiers=time_tiers
        )
        # 3 >= 14? No. 3 >= 7? No. 3 >= 0? Yes → 1.5x
        assert result == 15000

    def test_exact_boundary(self):
        """Exactly 7 days out matches the 7-day tier."""
        time_tiers = [
            {"minDays": 14, "multiplier": 1.0},
            {"minDays": 7, "multiplier": 1.25},
            {"minDays": 0, "multiplier": 1.5},
        ]
        result = calculate_price(
            base_rate=10000, fill_percent=0, days_until=7, time_tiers=time_tiers
        )
        assert result == 12500

    def test_below_all_tiers_uses_lowest(self):
        """When minDays starts above 0 and daysUntil is below all, use lowest tier."""
        time_tiers = [
            {"minDays": 14, "multiplier": 1.0},
            {"minDays": 7, "multiplier": 1.25},
        ]
        result = calculate_price(
            base_rate=10000, fill_percent=0, days_until=3, time_tiers=time_tiers
        )
        # 3 >= 14? No. 3 >= 7? No. Below all → use lowest tier (1.25x)
        assert result == 12500

    def test_no_match_uses_lowest_tier(self):
        """No time tier matches when days_until exceeds all tier values — but Node
        falls back to the lowest tier's multiplier."""
        # Actually in Node: sorted desc by minDays, first where daysUntil >= minDays.
        # If daysUntil=30 and tiers are [14, 7], 30 >= 14 → matches first. So this
        # scenario only happens if daysUntil is below ALL minDays values.
        time_tiers = [
            {"minDays": 14, "multiplier": 1.0},
            {"minDays": 7, "multiplier": 1.25},
        ]
        # 3 < 7, 3 < 14 → below all. Node returns last sorted element (1.25x)
        result = calculate_price(
            base_rate=10000, fill_percent=0, days_until=3, time_tiers=time_tiers
        )
        assert result == 12500

    def test_production_tiers(self):
        """Match the production default tiers from the Node migration."""
        time_tiers = [
            {"minDays": 28, "multiplier": 1.0},
            {"minDays": 14, "multiplier": 1.5},
            {"minDays": 7, "multiplier": 2.0},
            {"minDays": 0, "multiplier": 3.0},
        ]
        # 30 days → 1.0x
        assert calculate_price(base_rate=10000, fill_percent=0, days_until=30, time_tiers=time_tiers) == 10000
        # 20 days → 1.5x
        assert calculate_price(base_rate=10000, fill_percent=0, days_until=20, time_tiers=time_tiers) == 15000
        # 10 days → 2.0x
        assert calculate_price(base_rate=10000, fill_percent=0, days_until=10, time_tiers=time_tiers) == 20000
        # 3 days → 3.0x
        assert calculate_price(base_rate=10000, fill_percent=0, days_until=3, time_tiers=time_tiers) == 30000


# ===========================================================================
# Combined fill + time tiers
# ===========================================================================


class TestCombined:
    def test_both_multipliers_applied(self):
        """Final price = baseRate × fillMultiplier × timeMultiplier."""
        fill_tiers = [
            {"maxPercent": 50, "multiplier": 1.5},
            {"maxPercent": 100, "multiplier": 2.0},
        ]
        time_tiers = [
            {"minDays": 14, "multiplier": 1.0},
            {"minDays": 0, "multiplier": 1.5},
        ]
        # 40% fill → 1.5x, 5 days out → 1.5x → 10000 * 1.5 * 1.5 = 22500
        result = calculate_price(
            base_rate=10000,
            fill_percent=40,
            days_until=5,
            fill_tiers=fill_tiers,
            time_tiers=time_tiers,
        )
        assert result == 22500

    def test_production_combined(self):
        """Full production scenario: 60% fill, 10 days out."""
        fill_tiers = [
            {"maxPercent": 25, "multiplier": 1.0},
            {"maxPercent": 50, "multiplier": 1.5},
            {"maxPercent": 75, "multiplier": 2.5},
            {"maxPercent": 100, "multiplier": 5.0},
        ]
        time_tiers = [
            {"minDays": 28, "multiplier": 1.0},
            {"minDays": 14, "multiplier": 1.5},
            {"minDays": 7, "multiplier": 2.0},
            {"minDays": 0, "multiplier": 3.0},
        ]
        # 60% fill → 2.5x, 10 days → 2.0x → 10000 * 2.5 * 2.0 = 50000
        result = calculate_price(
            base_rate=10000,
            fill_percent=60,
            days_until=10,
            fill_tiers=fill_tiers,
            time_tiers=time_tiers,
        )
        assert result == 50000


# ===========================================================================
# Rounding — Node uses Math.round (nearest), not ceil
# ===========================================================================


class TestRounding:
    def test_rounds_to_nearest(self):
        """Uses round() not ceil() — matches Node Math.round."""
        fill_tiers = [
            {"maxPercent": 100, "multiplier": 1.333},
        ]
        result = calculate_price(
            base_rate=10000,
            fill_percent=50,
            days_until=14,
            fill_tiers=fill_tiers,
        )
        # 10000 * 1.333 = 13330.0 — exact, no rounding diff
        assert result == 13330

    def test_rounds_down_when_below_half(self):
        """10000 * 1.3332 = 13332.0 — exact. Try fractional: 100 * 1.333 = 133.3 → 133."""
        fill_tiers = [{"maxPercent": 100, "multiplier": 1.333}]
        result = calculate_price(
            base_rate=100,
            fill_percent=50,
            days_until=14,
            fill_tiers=fill_tiers,
        )
        # 100 * 1.333 = 133.3 → round = 133
        assert result == 133

    def test_rounds_up_when_above_half(self):
        """100 * 1.337 = 133.7 → round = 134."""
        fill_tiers = [{"maxPercent": 100, "multiplier": 1.337}]
        result = calculate_price(
            base_rate=100,
            fill_percent=50,
            days_until=14,
            fill_tiers=fill_tiers,
        )
        assert result == 134


# ===========================================================================
# calculate_price_with_breakdown
# ===========================================================================


class TestBreakdown:
    def test_returns_camel_case_keys(self):
        """Breakdown dict uses camelCase keys matching the SDK contract."""
        result = calculate_price_with_breakdown(
            base_rate=10000, fill_percent=0, days_until=14
        )
        assert set(result.keys()) == {
            "baseRate", "fillMultiplier", "timeMultiplier", "finalPrice"
        }

    def test_no_tiers_returns_base_rate(self):
        """Without tiers, finalPrice equals baseRate and multipliers are 1.0."""
        result = calculate_price_with_breakdown(
            base_rate=10000, fill_percent=0, days_until=14
        )
        assert result["baseRate"] == 10000
        assert result["fillMultiplier"] == 1.0
        assert result["timeMultiplier"] == 1.0
        assert result["finalPrice"] == 10000

    def test_fill_tier_reflected(self):
        """Fill tier multiplier is captured in the breakdown."""
        fill_tiers = [
            {"maxPercent": 50, "multiplier": 1.5},
            {"maxPercent": 100, "multiplier": 2.0},
        ]
        result = calculate_price_with_breakdown(
            base_rate=10000, fill_percent=40, days_until=14,
            fill_tiers=fill_tiers,
        )
        assert result["fillMultiplier"] == 1.5
        assert result["timeMultiplier"] == 1.0
        assert result["finalPrice"] == 15000

    def test_time_tier_reflected(self):
        """Time tier multiplier is captured in the breakdown."""
        time_tiers = [
            {"minDays": 14, "multiplier": 1.0},
            {"minDays": 0, "multiplier": 1.5},
        ]
        result = calculate_price_with_breakdown(
            base_rate=10000, fill_percent=0, days_until=5,
            time_tiers=time_tiers,
        )
        assert result["fillMultiplier"] == 1.0
        assert result["timeMultiplier"] == 1.5
        assert result["finalPrice"] == 15000

    def test_combined_matches_calculate_price(self):
        """Breakdown finalPrice must equal calculate_price for the same inputs."""
        fill_tiers = [
            {"maxPercent": 50, "multiplier": 1.5},
            {"maxPercent": 100, "multiplier": 2.0},
        ]
        time_tiers = [
            {"minDays": 14, "multiplier": 1.0},
            {"minDays": 0, "multiplier": 1.5},
        ]
        kwargs = dict(
            base_rate=10000, fill_percent=40, days_until=5,
            fill_tiers=fill_tiers, time_tiers=time_tiers,
        )
        breakdown = calculate_price_with_breakdown(**kwargs)
        price = calculate_price(**kwargs)
        assert breakdown["finalPrice"] == price

    def test_production_scenario(self):
        """Full production tiers: 60% fill, 10 days out."""
        fill_tiers = [
            {"maxPercent": 25, "multiplier": 1.0},
            {"maxPercent": 50, "multiplier": 1.5},
            {"maxPercent": 75, "multiplier": 2.5},
            {"maxPercent": 100, "multiplier": 5.0},
        ]
        time_tiers = [
            {"minDays": 28, "multiplier": 1.0},
            {"minDays": 14, "multiplier": 1.5},
            {"minDays": 7, "multiplier": 2.0},
            {"minDays": 0, "multiplier": 3.0},
        ]
        result = calculate_price_with_breakdown(
            base_rate=10000, fill_percent=60, days_until=10,
            fill_tiers=fill_tiers, time_tiers=time_tiers,
        )
        assert result["baseRate"] == 10000
        assert result["fillMultiplier"] == 2.5
        assert result["timeMultiplier"] == 2.0
        assert result["finalPrice"] == 50000
