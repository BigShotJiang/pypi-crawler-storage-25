"""Unit tests for booking policy CRUD service methods.

Tests the BookingPolicy management layer: create, list, get, update, delete.
Written TDD-first -- implements shared.md US-7.
"""

from __future__ import annotations

import datetime as dt
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

from spaps_server_quickstart.domains.dayrate import service as dayrate_service
from spaps_server_quickstart.domains.dayrate.errors import (
    PolicyAlreadyExistsError,
    PolicyNotFoundError,
)

_REPO = "spaps_server_quickstart.domains.dayrate.service.repo"

FAKE_APP_ID = uuid4()


def _make_policy(**overrides) -> MagicMock:
    """Build a mock BookingPolicy model instance."""
    policy = MagicMock()
    policy.id = overrides.get("id", uuid4())
    policy.application_id = overrides.get("application_id", FAKE_APP_ID)
    policy.policy_key = overrides.get("policy_key", "checkin_call")
    policy.entitlement_key = overrides.get("entitlement_key", "htma_checkin_call")
    policy.free_bookings_per_period = overrides.get("free_bookings_per_period", 2)
    policy.period_days = overrides.get("period_days", 28)
    policy.overage_rate = overrides.get("overage_rate", 5000)
    policy.overage_currency = overrides.get("overage_currency", "usd")
    policy.overage_product_name = overrides.get(
        "overage_product_name", "Additional Check-in Call"
    )
    policy.reschedule_is_free = overrides.get("reschedule_is_free", True)
    policy.is_active = overrides.get("is_active", True)
    policy.metadata_ = overrides.get("metadata_", {})
    policy.created_at = overrides.get("created_at", dt.datetime.now(dt.UTC))
    policy.updated_at = overrides.get("updated_at", dt.datetime.now(dt.UTC))
    return policy


# ===========================================================================
# create_booking_policy
# ===========================================================================


class TestCreateBookingPolicy:
    @patch(_REPO)
    async def test_create_success(self, mock_repo):
        """Creates policy and returns dict."""
        policy = _make_policy()
        mock_repo.create_booking_policy = AsyncMock(return_value=policy)
        mock_repo.get_booking_policy_by_key = AsyncMock(return_value=None)

        db = AsyncMock()
        result = await dayrate_service.create_booking_policy(
            db,
            application_id=FAKE_APP_ID,
            policy_key="checkin_call",
            entitlement_key="htma_checkin_call",
            free_bookings_per_period=2,
            period_days=28,
            overage_rate=5000,
            overage_currency="usd",
            overage_product_name="Additional Check-in Call",
            reschedule_is_free=True,
        )

        assert result["id"] == str(policy.id)
        assert result["policyKey"] == "checkin_call"
        assert result["entitlementKey"] == "htma_checkin_call"
        assert result["freeBookingsPerPeriod"] == 2
        assert result["periodDays"] == 28
        assert result["overageRate"] == 5000
        mock_repo.create_booking_policy.assert_called_once()

    @patch(_REPO)
    async def test_create_duplicate_raises(self, mock_repo):
        """Raises PolicyAlreadyExistsError on duplicate (app_id, policy_key)."""
        existing = _make_policy()
        mock_repo.get_booking_policy_by_key = AsyncMock(return_value=existing)

        db = AsyncMock()
        with pytest.raises(PolicyAlreadyExistsError):
            await dayrate_service.create_booking_policy(
                db,
                application_id=FAKE_APP_ID,
                policy_key="checkin_call",
                entitlement_key="htma_checkin_call",
                free_bookings_per_period=2,
            )


# ===========================================================================
# list_booking_policies
# ===========================================================================


class TestListBookingPolicies:
    @patch(_REPO)
    async def test_returns_active_policies(self, mock_repo):
        """Returns list of active policies for app."""
        policies = [_make_policy(), _make_policy(policy_key="maintenance")]
        mock_repo.list_booking_policies = AsyncMock(return_value=policies)

        db = AsyncMock()
        result = await dayrate_service.list_booking_policies(
            db, application_id=FAKE_APP_ID
        )

        assert len(result) == 2

    @patch(_REPO)
    async def test_empty_returns_empty_list(self, mock_repo):
        """Returns empty list when no policies exist."""
        mock_repo.list_booking_policies = AsyncMock(return_value=[])

        db = AsyncMock()
        result = await dayrate_service.list_booking_policies(
            db, application_id=FAKE_APP_ID
        )

        assert result == []


# ===========================================================================
# update_booking_policy
# ===========================================================================


class TestUpdateBookingPolicy:
    @patch(_REPO)
    async def test_update_success(self, mock_repo):
        """Updates policy fields."""
        policy_id = uuid4()
        updated_policy = _make_policy(id=policy_id, free_bookings_per_period=4)
        mock_repo.update_booking_policy = AsyncMock(return_value=updated_policy)

        db = AsyncMock()
        result = await dayrate_service.update_booking_policy(
            db,
            policy_id=policy_id,
            application_id=FAKE_APP_ID,
            free_bookings_per_period=4,
        )

        assert result["freeBookingsPerPeriod"] == 4

    @patch(_REPO)
    async def test_update_not_found_raises(self, mock_repo):
        """Raises PolicyNotFoundError when policy doesn't exist."""
        mock_repo.update_booking_policy = AsyncMock(return_value=None)

        db = AsyncMock()
        with pytest.raises(PolicyNotFoundError):
            await dayrate_service.update_booking_policy(
                db,
                policy_id=uuid4(),
                application_id=FAKE_APP_ID,
                free_bookings_per_period=4,
            )


# ===========================================================================
# delete_booking_policy
# ===========================================================================


class TestDeleteBookingPolicy:
    @patch(_REPO)
    async def test_delete_success(self, mock_repo):
        """Deletes policy and returns success."""
        mock_repo.delete_booking_policy = AsyncMock(return_value=True)

        db = AsyncMock()
        result = await dayrate_service.delete_booking_policy(
            db, policy_id=uuid4(), application_id=FAKE_APP_ID
        )

        assert result["success"] is True

    @patch(_REPO)
    async def test_delete_not_found_raises(self, mock_repo):
        """Raises PolicyNotFoundError when policy doesn't exist."""
        mock_repo.delete_booking_policy = AsyncMock(return_value=False)

        db = AsyncMock()
        with pytest.raises(PolicyNotFoundError):
            await dayrate_service.delete_booking_policy(
                db, policy_id=uuid4(), application_id=FAKE_APP_ID
            )
