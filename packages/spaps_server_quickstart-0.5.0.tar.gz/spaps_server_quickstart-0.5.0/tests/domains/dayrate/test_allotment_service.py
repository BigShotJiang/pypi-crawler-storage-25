"""Unit tests for allotment checking service.

Tests the rolling 28-day window allotment counting, entitlement gating,
and FOR UPDATE locking semantics.
Written TDD-first -- implements shared.md US-5 and backend.md Rules 1, 5.
"""

from __future__ import annotations

import datetime as dt
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

from spaps_server_quickstart.domains.dayrate import service as dayrate_service

_REPO = "spaps_server_quickstart.domains.dayrate.service.repo"
_ENT_REPO = "spaps_server_quickstart.domains.dayrate.service.ent_repo"

FAKE_APP_ID = uuid4()
FAKE_USER_ID = uuid4()


def _make_policy(**overrides) -> MagicMock:
    """Build a mock BookingPolicy model instance."""
    policy = MagicMock()
    policy.id = overrides.get("id", uuid4())
    policy.application_id = overrides.get("application_id", FAKE_APP_ID)
    policy.policy_key = overrides.get("policy_key", "checkin_call")
    policy.entitlement_key = overrides.get("entitlement_key", "htma_checkin_call")
    policy.free_bookings_per_period = overrides.get("free_bookings_per_period", 2)
    policy.period_days = overrides.get("period_days", 28)
    policy.overage_rate = overrides.get("overage_rate", 5000)
    policy.overage_currency = overrides.get("overage_currency", "usd")
    policy.overage_product_name = overrides.get(
        "overage_product_name", "Additional Check-in Call"
    )
    policy.reschedule_is_free = overrides.get("reschedule_is_free", True)
    policy.is_active = overrides.get("is_active", True)
    policy.metadata_ = overrides.get("metadata_", {})
    policy.created_at = overrides.get("created_at", dt.datetime.now(dt.UTC))
    policy.updated_at = overrides.get("updated_at", dt.datetime.now(dt.UTC))
    return policy


def _make_entitlement(**overrides) -> MagicMock:
    """Build a mock Entitlement."""
    ent = MagicMock()
    ent.id = overrides.get("id", uuid4())
    ent.beneficiary_user_id = overrides.get("beneficiary_user_id", FAKE_USER_ID)
    ent.beneficiary_email = overrides.get("beneficiary_email", "patient@example.com")
    ent.entitlement_key = overrides.get("entitlement_key", "htma_checkin_call")
    ent.revoked_at = overrides.get("revoked_at", None)
    ent.ends_at = overrides.get("ends_at", None)
    return ent


def _make_booking(**overrides) -> MagicMock:
    """Build a mock DayRateBooking."""
    booking = MagicMock()
    booking.id = overrides.get("id", uuid4())
    booking.application_id = overrides.get("application_id", FAKE_APP_ID)
    booking.user_id = overrides.get("user_id", FAKE_USER_ID)
    booking.status = overrides.get("status", "confirmed")
    booking.replaces_booking_id = overrides.get("replaces_booking_id", None)
    booking.is_free = overrides.get("is_free", True)
    booking.policy_key = overrides.get("policy_key", "checkin_call")
    booking.created_at = overrides.get("created_at", dt.datetime.now(dt.UTC))
    return booking


# ===========================================================================
# check_allotment
# ===========================================================================


class TestCheckAllotment:
    @patch(_ENT_REPO)
    @patch(_REPO)
    async def test_has_policy_and_entitlement_with_remaining(
        self, mock_repo, mock_ent_repo
    ):
        """User with entitlement + remaining allotment -> full allotment info."""
        policy = _make_policy(free_bookings_per_period=2, period_days=28)
        mock_repo.get_booking_policy_by_key = AsyncMock(return_value=policy)
        mock_repo.lock_policy_for_allotment = AsyncMock(return_value=policy)

        # User has active entitlement
        ent = _make_entitlement()
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[ent])

        # 1 booking used in rolling window
        booking = _make_booking()
        mock_repo.count_allotment_bookings = AsyncMock(return_value=1)

        db = AsyncMock()
        result = await dayrate_service.check_allotment(
            db,
            application_id=FAKE_APP_ID,
            policy_key="checkin_call",
            user_id=FAKE_USER_ID,
        )

        assert result["policyKey"] == "checkin_call"
        assert result["entitled"] is True
        assert result["allotment"]["total"] == 2
        assert result["allotment"]["used"] == 1
        assert result["allotment"]["remaining"] == 1
        assert result["allotment"]["periodDays"] == 28
        assert result["overageRate"] == 5000
        assert result["overageCurrency"] == "usd"

    @patch(_ENT_REPO)
    @patch(_REPO)
    async def test_no_policy_returns_null_discriminator(
        self, mock_repo, mock_ent_repo
    ):
        """No policy for app -> policyKey: null (buildooor case)."""
        mock_repo.get_booking_policy_by_key = AsyncMock(return_value=None)

        db = AsyncMock()
        result = await dayrate_service.check_allotment(
            db,
            application_id=FAKE_APP_ID,
            policy_key="checkin_call",
            user_id=FAKE_USER_ID,
        )

        assert result["policyKey"] is None
        assert result["entitled"] is False
        assert result["allotment"] is None
        assert result["overageRate"] is None
        assert result["overageCurrency"] is None

    @patch(_ENT_REPO)
    @patch(_REPO)
    async def test_no_entitlement_returns_not_entitled(
        self, mock_repo, mock_ent_repo
    ):
        """Policy exists but user has no entitlement -> entitled: false."""
        policy = _make_policy()
        mock_repo.get_booking_policy_by_key = AsyncMock(return_value=policy)
        mock_repo.lock_policy_for_allotment = AsyncMock(return_value=policy)

        # No active entitlements
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[])

        db = AsyncMock()
        result = await dayrate_service.check_allotment(
            db,
            application_id=FAKE_APP_ID,
            policy_key="checkin_call",
            user_id=FAKE_USER_ID,
        )

        assert result["policyKey"] == "checkin_call"
        assert result["entitled"] is False
        assert result["allotment"] is None

    @patch(_ENT_REPO)
    @patch(_REPO)
    async def test_allotment_exhausted(self, mock_repo, mock_ent_repo):
        """All free bookings used -> remaining: 0."""
        policy = _make_policy(free_bookings_per_period=2)
        mock_repo.get_booking_policy_by_key = AsyncMock(return_value=policy)
        mock_repo.lock_policy_for_allotment = AsyncMock(return_value=policy)

        ent = _make_entitlement()
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[ent])

        mock_repo.count_allotment_bookings = AsyncMock(return_value=2)

        db = AsyncMock()
        result = await dayrate_service.check_allotment(
            db,
            application_id=FAKE_APP_ID,
            policy_key="checkin_call",
            user_id=FAKE_USER_ID,
        )

        assert result["entitled"] is True
        assert result["allotment"]["remaining"] == 0

    @patch(_ENT_REPO)
    @patch(_REPO)
    async def test_email_fallback_for_allotment(self, mock_repo, mock_ent_repo):
        """When user_id is None, email is used for allotment check."""
        policy = _make_policy()
        mock_repo.get_booking_policy_by_key = AsyncMock(return_value=policy)
        mock_repo.lock_policy_for_allotment = AsyncMock(return_value=policy)

        ent = _make_entitlement()
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[ent])

        mock_repo.count_allotment_bookings = AsyncMock(return_value=0)

        db = AsyncMock()
        result = await dayrate_service.check_allotment(
            db,
            application_id=FAKE_APP_ID,
            policy_key="checkin_call",
            email="patient@example.com",
        )

        assert result["entitled"] is True
        assert result["allotment"]["remaining"] == 2
