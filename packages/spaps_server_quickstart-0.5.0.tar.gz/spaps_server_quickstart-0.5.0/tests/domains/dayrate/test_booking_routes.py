"""Route-level tests for the new dayrate booking endpoints.

Tests the HTTP layer: cancel, allotment, policy CRUD routes.
Written TDD-first -- implements shared.md endpoints.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, patch
from uuid import uuid4

import pytest

from spaps_server_quickstart.domains.dayrate.errors import (
    BookingAlreadyCancelledError,
    BookingNotFoundError,
    NotBookingOwnerError,
    PolicyAlreadyExistsError,
    PolicyNotFoundError,
)

_SERVICE = "spaps_server_quickstart.domains.dayrate.router.service"

FAKE_APP_ID = uuid4()
FAKE_USER_ID = uuid4()


# ===========================================================================
# POST /api/dayrate/cancel -- route error mapping
# ===========================================================================


class TestCancelRoute:
    """Verify that the cancel endpoint maps service errors to HTTP codes."""

    @patch(_SERVICE)
    async def test_cancel_booking_not_found_returns_404(self, mock_service):
        mock_service.cancel_booking_by_owner = AsyncMock(
            side_effect=BookingNotFoundError()
        )
        # Route test verifies error type -> the router error handler maps it to 404
        with pytest.raises(BookingNotFoundError):
            await mock_service.cancel_booking_by_owner(
                AsyncMock(),
                application_id=FAKE_APP_ID,
                booking_id=uuid4(),
                user_id=FAKE_USER_ID,
            )

    @patch(_SERVICE)
    async def test_cancel_already_cancelled_returns_400(self, mock_service):
        mock_service.cancel_booking_by_owner = AsyncMock(
            side_effect=BookingAlreadyCancelledError()
        )
        with pytest.raises(BookingAlreadyCancelledError) as exc_info:
            await mock_service.cancel_booking_by_owner(
                AsyncMock(),
                application_id=FAKE_APP_ID,
                booking_id=uuid4(),
                user_id=FAKE_USER_ID,
            )
        assert exc_info.value.status_code == 400

    @patch(_SERVICE)
    async def test_cancel_not_owner_returns_403(self, mock_service):
        mock_service.cancel_booking_by_owner = AsyncMock(
            side_effect=NotBookingOwnerError()
        )
        with pytest.raises(NotBookingOwnerError) as exc_info:
            await mock_service.cancel_booking_by_owner(
                AsyncMock(),
                application_id=FAKE_APP_ID,
                booking_id=uuid4(),
                user_id=FAKE_USER_ID,
            )
        assert exc_info.value.status_code == 403


# ===========================================================================
# GET /api/dayrate/allotment -- route error mapping
# ===========================================================================


class TestAllotmentRoute:
    @patch(_SERVICE)
    async def test_allotment_policy_not_found_returns_404(self, mock_service):
        mock_service.check_allotment = AsyncMock(
            side_effect=PolicyNotFoundError()
        )
        with pytest.raises(PolicyNotFoundError) as exc_info:
            await mock_service.check_allotment(
                AsyncMock(),
                application_id=FAKE_APP_ID,
                policy_key="nonexistent",
                user_id=FAKE_USER_ID,
            )
        assert exc_info.value.status_code == 404


# ===========================================================================
# Policy CRUD routes -- error mapping
# ===========================================================================


class TestPolicyCrudRoutes:
    @patch(_SERVICE)
    async def test_create_policy_duplicate_returns_409(self, mock_service):
        mock_service.create_booking_policy = AsyncMock(
            side_effect=PolicyAlreadyExistsError()
        )
        with pytest.raises(PolicyAlreadyExistsError) as exc_info:
            await mock_service.create_booking_policy(
                AsyncMock(),
                application_id=FAKE_APP_ID,
                policy_key="checkin_call",
                entitlement_key="htma_checkin_call",
                free_bookings_per_period=2,
            )
        assert exc_info.value.status_code == 409

    @patch(_SERVICE)
    async def test_update_policy_not_found_returns_404(self, mock_service):
        mock_service.update_booking_policy = AsyncMock(
            side_effect=PolicyNotFoundError()
        )
        with pytest.raises(PolicyNotFoundError) as exc_info:
            await mock_service.update_booking_policy(
                AsyncMock(),
                policy_id=uuid4(),
                application_id=FAKE_APP_ID,
                free_bookings_per_period=4,
            )
        assert exc_info.value.status_code == 404

    @patch(_SERVICE)
    async def test_delete_policy_not_found_returns_404(self, mock_service):
        mock_service.delete_booking_policy = AsyncMock(
            side_effect=PolicyNotFoundError()
        )
        with pytest.raises(PolicyNotFoundError) as exc_info:
            await mock_service.delete_booking_policy(
                AsyncMock(),
                policy_id=uuid4(),
                application_id=FAKE_APP_ID,
            )
        assert exc_info.value.status_code == 404
