"""Unit tests for the CfoRoleService (cfo_roles domain).

Tests exercise service functions with mocked entitlement service calls.
No database or network calls.
"""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

from spaps_server_quickstart.domains.cfo_roles import service
from spaps_server_quickstart.domains.cfo_roles.errors import (
    AlreadyAssignedError,
    AlreadySalesError,
    InvalidEmailError,
    InvalidRoleError,
    NotProspectError,
    NotSalesError,
)

_ENT_SERVICE = "spaps_server_quickstart.domains.cfo_roles.service.ent_service"
_ENT_REPO = "spaps_server_quickstart.domains.cfo_roles.service.ent_repo"
_USER_REPO = "spaps_server_quickstart.domains.cfo_roles.service.user_repo"

FAKE_APP_ID = uuid4()
FAKE_USER_ID = uuid4()
FAKE_ADMIN_ID = uuid4()
FAKE_COMPANY_ID = uuid4()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_entitlement(
    *,
    entitlement_key: str = "cfo:role:accountant",
    beneficiary_user_id=None,
    resource_type: str = "company",
    resource_id=None,
    revoked_at=None,
    metadata_=None,
):
    ent = MagicMock()
    ent.id = uuid4()
    ent.application_id = FAKE_APP_ID
    ent.beneficiary_user_id = beneficiary_user_id or FAKE_USER_ID
    ent.beneficiary_email = None
    ent.entitlement_key = entitlement_key
    ent.source = "manual"
    ent.resource_type = resource_type
    ent.resource_id = resource_id or FAKE_COMPANY_ID
    ent.revoked_at = revoked_at
    ent.metadata_ = metadata_ or {"company_name": "Acme Corp"}
    ent.created_at = datetime.now(UTC)
    ent.updated_at = datetime.now(UTC)
    ent.starts_at = datetime.now(UTC)
    ent.ends_at = None
    ent.granted_by_user_id = FAKE_ADMIN_ID
    return ent


def _make_user(*, user_id=None, email="user@example.com", is_admin=False):
    user = MagicMock()
    user.id = user_id or FAKE_USER_ID
    user.email = email
    user.full_name = "Test User"
    user.is_admin = is_admin
    user.created_at = datetime.now(UTC)
    return user


# ===========================================================================
# assign_role
# ===========================================================================


class TestAssignRole:
    @patch(_ENT_REPO, new_callable=MagicMock)
    @patch(_ENT_SERVICE, new_callable=MagicMock)
    async def test_assign_accountant_success(self, mock_ent_svc, mock_ent_repo):
        """assign_role creates an entitlement with resource_type=company."""
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[])
        ent = _make_entitlement()
        mock_ent_svc.grant_entitlement = AsyncMock(
            return_value={"entitlement": {"id": str(ent.id)}, "created": True}
        )

        db = AsyncMock()
        result = await service.assign_role(
            db,
            application_id=FAKE_APP_ID,
            user_id=FAKE_USER_ID,
            company_id=FAKE_COMPANY_ID,
            company_name="Acme Corp",
            role="accountant",
            assigned_by=FAKE_ADMIN_ID,
        )

        assert result["created"] is True
        mock_ent_svc.grant_entitlement.assert_called_once()

    @patch(_ENT_REPO, new_callable=MagicMock)
    async def test_assign_role_already_assigned(self, mock_ent_repo):
        """assign_role raises ALREADY_ASSIGNED if user has role for company."""
        existing = _make_entitlement()
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[existing])

        db = AsyncMock()
        with pytest.raises(AlreadyAssignedError):
            await service.assign_role(
                db,
                application_id=FAKE_APP_ID,
                user_id=FAKE_USER_ID,
                company_id=FAKE_COMPANY_ID,
                company_name="Acme Corp",
                role="accountant",
                assigned_by=FAKE_ADMIN_ID,
            )

    async def test_assign_invalid_role(self):
        """assign_role raises INVALID_ROLE for unknown role."""
        db = AsyncMock()
        with pytest.raises(InvalidRoleError):
            await service.assign_role(
                db,
                application_id=FAKE_APP_ID,
                user_id=FAKE_USER_ID,
                company_id=FAKE_COMPANY_ID,
                company_name="Acme Corp",
                role="superuser",
                assigned_by=FAKE_ADMIN_ID,
            )

    async def test_assign_sales_requires_no_company(self):
        """assign_role raises INVALID_ROLE for sales (use grant_sales_role)."""
        db = AsyncMock()
        with pytest.raises(InvalidRoleError):
            await service.assign_role(
                db,
                application_id=FAKE_APP_ID,
                user_id=FAKE_USER_ID,
                company_id=FAKE_COMPANY_ID,
                company_name="Acme Corp",
                role="sales",
                assigned_by=FAKE_ADMIN_ID,
            )


# ===========================================================================
# get_user_role_for_company
# ===========================================================================


class TestGetUserRoleForCompany:
    @patch(_ENT_REPO, new_callable=MagicMock)
    async def test_returns_role(self, mock_ent_repo):
        """get_user_role_for_company returns the role string."""
        ent = _make_entitlement(entitlement_key="cfo:role:accountant")
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[ent])

        db = AsyncMock()
        role = await service.get_user_role_for_company(
            db,
            application_id=FAKE_APP_ID,
            user_id=FAKE_USER_ID,
            company_id=FAKE_COMPANY_ID,
        )

        assert role == "accountant"

    @patch(_ENT_REPO, new_callable=MagicMock)
    async def test_returns_none_for_no_role(self, mock_ent_repo):
        """get_user_role_for_company returns None if no entitlement."""
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[])

        db = AsyncMock()
        role = await service.get_user_role_for_company(
            db,
            application_id=FAKE_APP_ID,
            user_id=FAKE_USER_ID,
            company_id=FAKE_COMPANY_ID,
        )

        assert role is None


# ===========================================================================
# get_user_companies
# ===========================================================================


class TestGetUserCompanies:
    @patch(_ENT_REPO, new_callable=MagicMock)
    async def test_returns_company_list(self, mock_ent_repo):
        """get_user_companies returns list of company dicts."""
        ent1 = _make_entitlement(
            entitlement_key="cfo:role:accountant",
            resource_id=FAKE_COMPANY_ID,
            metadata_={"company_name": "Acme Corp"},
        )
        ent2 = _make_entitlement(
            entitlement_key="cfo:role:client",
            resource_id=uuid4(),
            metadata_={"company_name": "Beta Inc"},
        )
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[ent1, ent2])

        db = AsyncMock()
        companies = await service.get_user_companies(
            db,
            application_id=FAKE_APP_ID,
            user_id=FAKE_USER_ID,
        )

        assert len(companies) == 2
        assert companies[0]["company_name"] == "Acme Corp"
        assert companies[0]["role"] == "accountant"


# ===========================================================================
# has_sales_role / grant_sales_role / revoke_sales_role
# ===========================================================================


class TestSalesRole:
    @patch(_ENT_REPO, new_callable=MagicMock)
    async def test_has_sales_role_true(self, mock_ent_repo):
        """has_sales_role returns True when user has cfo:role:sales."""
        ent = _make_entitlement(
            entitlement_key="cfo:role:sales",
            resource_type="user",
            resource_id=None,
        )
        # Override resource_id since sales has no resource_id
        ent.resource_id = None
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[ent])

        db = AsyncMock()
        result = await service.has_sales_role(
            db, application_id=FAKE_APP_ID, user_id=FAKE_USER_ID
        )
        assert result is True

    @patch(_ENT_REPO, new_callable=MagicMock)
    async def test_has_sales_role_false(self, mock_ent_repo):
        """has_sales_role returns False when user lacks cfo:role:sales."""
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[])

        db = AsyncMock()
        result = await service.has_sales_role(
            db, application_id=FAKE_APP_ID, user_id=FAKE_USER_ID
        )
        assert result is False

    @patch(_ENT_REPO, new_callable=MagicMock)
    @patch(_ENT_SERVICE, new_callable=MagicMock)
    async def test_grant_sales_role_success(self, mock_ent_svc, mock_ent_repo):
        """grant_sales_role creates system-level sales entitlement."""
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[])
        mock_ent_svc.grant_entitlement = AsyncMock(
            return_value={
                "entitlement": {"id": str(uuid4())},
                "created": True,
            }
        )

        db = AsyncMock()
        result = await service.grant_sales_role(
            db,
            application_id=FAKE_APP_ID,
            user_id=FAKE_USER_ID,
            granted_by=FAKE_ADMIN_ID,
        )

        assert result is not None
        mock_ent_svc.grant_entitlement.assert_called_once()

    @patch(_ENT_REPO, new_callable=MagicMock)
    async def test_grant_sales_role_already_sales(self, mock_ent_repo):
        """grant_sales_role raises ALREADY_SALES if user has sales."""
        ent = _make_entitlement(entitlement_key="cfo:role:sales")
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[ent])

        db = AsyncMock()
        with pytest.raises(AlreadySalesError):
            await service.grant_sales_role(
                db,
                application_id=FAKE_APP_ID,
                user_id=FAKE_USER_ID,
                granted_by=FAKE_ADMIN_ID,
            )

    @patch(_ENT_REPO, new_callable=MagicMock)
    @patch(_ENT_SERVICE, new_callable=MagicMock)
    async def test_revoke_sales_role_success(self, mock_ent_svc, mock_ent_repo):
        """revoke_sales_role revokes the sales entitlement."""
        ent = _make_entitlement(entitlement_key="cfo:role:sales")
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[ent])
        mock_ent_svc.revoke_entitlement = AsyncMock(
            return_value={"entitlement": {"id": str(ent.id)}}
        )

        db = AsyncMock()
        result = await service.revoke_sales_role(
            db,
            application_id=FAKE_APP_ID,
            user_id=FAKE_USER_ID,
            revoked_by=FAKE_ADMIN_ID,
        )

        assert result is not None
        mock_ent_svc.revoke_entitlement.assert_called_once()

    @patch(_ENT_REPO, new_callable=MagicMock)
    async def test_revoke_sales_role_not_sales(self, mock_ent_repo):
        """revoke_sales_role raises NOT_SALES if user lacks sales."""
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[])

        db = AsyncMock()
        with pytest.raises(NotSalesError):
            await service.revoke_sales_role(
                db,
                application_id=FAKE_APP_ID,
                user_id=FAKE_USER_ID,
                revoked_by=FAKE_ADMIN_ID,
            )


# ===========================================================================
# revoke_all_roles
# ===========================================================================


class TestRevokeAllRoles:
    @patch(_ENT_SERVICE, new_callable=MagicMock)
    @patch(_ENT_REPO, new_callable=MagicMock)
    async def test_revokes_all_cfo_roles(self, mock_ent_repo, mock_ent_svc):
        """revoke_all_roles revokes all cfo:role:* entitlements."""
        ent1 = _make_entitlement(entitlement_key="cfo:role:accountant")
        ent2 = _make_entitlement(entitlement_key="cfo:role:sales")
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[ent1, ent2])
        mock_ent_svc.revoke_entitlement = AsyncMock(
            return_value={"entitlement": {}}
        )

        db = AsyncMock()
        count = await service.revoke_all_roles(
            db,
            application_id=FAKE_APP_ID,
            user_id=FAKE_USER_ID,
            by_user_id=FAKE_ADMIN_ID,
        )

        assert count == 2
        assert mock_ent_svc.revoke_entitlement.call_count == 2


# ===========================================================================
# get_user_status
# ===========================================================================


class TestGetUserStatus:
    @patch(_ENT_REPO, new_callable=MagicMock)
    async def test_active_status(self, mock_ent_repo):
        """get_user_status returns 'active' when user has active roles."""
        ent = _make_entitlement()
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[ent])

        db = AsyncMock()
        status = await service.get_user_status(
            db, application_id=FAKE_APP_ID, user_id=FAKE_USER_ID
        )
        assert status == "active"

    @patch(_ENT_REPO, new_callable=MagicMock)
    async def test_pending_status(self, mock_ent_repo):
        """get_user_status returns 'pending' when user has no roles."""
        # No active, no revoked
        mock_ent_repo.list_entitlements = AsyncMock(side_effect=[[], []])

        db = AsyncMock()
        status = await service.get_user_status(
            db, application_id=FAKE_APP_ID, user_id=FAKE_USER_ID
        )
        assert status == "pending"

    @patch(_ENT_REPO, new_callable=MagicMock)
    async def test_revoked_status(self, mock_ent_repo):
        """get_user_status returns 'revoked' when all roles revoked."""
        revoked_ent = _make_entitlement(revoked_at=datetime.now(UTC))
        # First call: active (empty), second call: include_revoked (has entries)
        mock_ent_repo.list_entitlements = AsyncMock(
            side_effect=[[], [revoked_ent]]
        )

        db = AsyncMock()
        status = await service.get_user_status(
            db, application_id=FAKE_APP_ID, user_id=FAKE_USER_ID
        )
        assert status == "revoked"


# ===========================================================================
# get_company_users
# ===========================================================================


class TestGetCompanyUsers:
    @patch(_ENT_REPO, new_callable=MagicMock)
    async def test_returns_users_with_roles(self, mock_ent_repo):
        """get_company_users returns users who have roles for the company."""
        user1_id = uuid4()
        user2_id = uuid4()
        ent1 = _make_entitlement(
            entitlement_key="cfo:role:accountant",
            beneficiary_user_id=user1_id,
        )
        ent2 = _make_entitlement(
            entitlement_key="cfo:role:client",
            beneficiary_user_id=user2_id,
        )
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[ent1, ent2])

        db = AsyncMock()
        users = await service.get_company_users(
            db,
            application_id=FAKE_APP_ID,
            company_id=FAKE_COMPANY_ID,
        )

        assert len(users) == 2


# ===========================================================================
# convert_prospect
# ===========================================================================


class TestConvertProspect:
    @patch(_ENT_SERVICE, new_callable=MagicMock)
    @patch(_ENT_REPO, new_callable=MagicMock)
    async def test_convert_success(self, mock_ent_repo, mock_ent_svc):
        """convert_prospect revokes prospect and assigns new role."""
        prospect_ent = _make_entitlement(entitlement_key="cfo:role:prospect")
        mock_ent_repo.get_entitlement_by_id = AsyncMock(return_value=prospect_ent)
        mock_ent_svc.revoke_entitlement = AsyncMock(
            return_value={"entitlement": {"id": str(prospect_ent.id)}}
        )
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[])
        new_ent = _make_entitlement(entitlement_key="cfo:role:client")
        mock_ent_svc.grant_entitlement = AsyncMock(
            return_value={"entitlement": {"id": str(new_ent.id)}, "created": True}
        )

        db = AsyncMock()
        result = await service.convert_prospect(
            db,
            application_id=FAKE_APP_ID,
            entitlement_id=prospect_ent.id,
            user_id=FAKE_USER_ID,
            company_id=FAKE_COMPANY_ID,
            company_name="Acme Corp",
            new_role="client",
            converted_by=FAKE_ADMIN_ID,
        )

        assert result["previous"]["role"] == "prospect"
        assert result["current"]["role"] == "client"
        mock_ent_svc.revoke_entitlement.assert_called_once()
        mock_ent_svc.grant_entitlement.assert_called_once()

    @patch(_ENT_REPO, new_callable=MagicMock)
    async def test_convert_not_prospect_raises(self, mock_ent_repo):
        """convert_prospect raises NOT_PROSPECT for non-prospect entitlement."""
        accountant_ent = _make_entitlement(entitlement_key="cfo:role:accountant")
        mock_ent_repo.get_entitlement_by_id = AsyncMock(return_value=accountant_ent)

        db = AsyncMock()
        with pytest.raises(NotProspectError):
            await service.convert_prospect(
                db,
                application_id=FAKE_APP_ID,
                entitlement_id=accountant_ent.id,
                user_id=FAKE_USER_ID,
                company_id=FAKE_COMPANY_ID,
                company_name="Acme Corp",
                new_role="client",
                converted_by=FAKE_ADMIN_ID,
            )

    async def test_convert_invalid_target_role(self):
        """convert_prospect raises INVALID_ROLE for bad target role."""
        db = AsyncMock()
        with pytest.raises(InvalidRoleError):
            await service.convert_prospect(
                db,
                application_id=FAKE_APP_ID,
                entitlement_id=uuid4(),
                user_id=FAKE_USER_ID,
                company_id=FAKE_COMPANY_ID,
                company_name="Acme Corp",
                new_role="superuser",
                converted_by=FAKE_ADMIN_ID,
            )


# ===========================================================================
# Feature toggles
# ===========================================================================


class TestFeatureToggles:
    @patch(_ENT_REPO, new_callable=MagicMock)
    async def test_get_company_features(self, mock_ent_repo):
        """get_company_features returns feature dict."""
        feat1 = _make_entitlement(
            entitlement_key="cfo:feature:reports_dashboard",
            resource_type="company",
        )
        feat1.beneficiary_user_id = None
        feat2 = _make_entitlement(
            entitlement_key="cfo:feature:document_upload",
            resource_type="company",
        )
        feat2.beneficiary_user_id = None
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[feat1, feat2])

        db = AsyncMock()
        features = await service.get_company_features(
            db, application_id=FAKE_APP_ID, company_id=FAKE_COMPANY_ID
        )

        assert features["reports_dashboard"] is True
        assert features["document_upload"] is True

    @patch(_ENT_SERVICE, new_callable=MagicMock)
    @patch(_ENT_REPO, new_callable=MagicMock)
    async def test_set_company_feature_enable(self, mock_ent_repo, mock_ent_svc):
        """set_company_feature grants feature entitlement when enabled."""
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[])
        mock_ent_svc.grant_entitlement = AsyncMock(
            return_value={"entitlement": {"id": str(uuid4())}, "created": True}
        )

        db = AsyncMock()
        await service.set_company_feature(
            db,
            application_id=FAKE_APP_ID,
            company_id=FAKE_COMPANY_ID,
            feature_name="reports_dashboard",
            enabled=True,
            set_by=FAKE_ADMIN_ID,
        )

        mock_ent_svc.grant_entitlement.assert_called_once()

    @patch(_ENT_SERVICE, new_callable=MagicMock)
    @patch(_ENT_REPO, new_callable=MagicMock)
    async def test_set_company_feature_disable(self, mock_ent_repo, mock_ent_svc):
        """set_company_feature revokes feature entitlement when disabled."""
        feat = _make_entitlement(entitlement_key="cfo:feature:reports_dashboard")
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[feat])
        mock_ent_svc.revoke_entitlement = AsyncMock(
            return_value={"entitlement": {"id": str(feat.id)}}
        )

        db = AsyncMock()
        await service.set_company_feature(
            db,
            application_id=FAKE_APP_ID,
            company_id=FAKE_COMPANY_ID,
            feature_name="reports_dashboard",
            enabled=False,
            set_by=FAKE_ADMIN_ID,
        )

        mock_ent_svc.revoke_entitlement.assert_called_once()


# ===========================================================================
# System kill switches
# ===========================================================================


class TestSystemFeatures:
    @patch(_ENT_REPO, new_callable=MagicMock)
    async def test_get_system_features(self, mock_ent_repo):
        """get_system_features returns dict with killed features as False."""
        feat = _make_entitlement(
            entitlement_key="cfo:system:write_transactions",
            resource_type="system",
        )
        feat.resource_id = None
        feat.beneficiary_user_id = None
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[feat])

        db = AsyncMock()
        features = await service.get_system_features(
            db, application_id=FAKE_APP_ID
        )

        assert features["write_transactions"] is False

    @patch(_ENT_SERVICE, new_callable=MagicMock)
    @patch(_ENT_REPO, new_callable=MagicMock)
    async def test_set_system_feature_kill(self, mock_ent_repo, mock_ent_svc):
        """set_system_feature creates entitlement when disabling (killing)."""
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[])
        mock_ent_svc.grant_entitlement = AsyncMock(
            return_value={"entitlement": {"id": str(uuid4())}, "created": True}
        )

        db = AsyncMock()
        await service.set_system_feature(
            db,
            application_id=FAKE_APP_ID,
            feature_name="write_transactions",
            enabled=False,
            set_by=FAKE_ADMIN_ID,
        )

        mock_ent_svc.grant_entitlement.assert_called_once()

    @patch(_ENT_SERVICE, new_callable=MagicMock)
    @patch(_ENT_REPO, new_callable=MagicMock)
    async def test_set_system_feature_reenable(self, mock_ent_repo, mock_ent_svc):
        """set_system_feature revokes entitlement when re-enabling."""
        feat = _make_entitlement(
            entitlement_key="cfo:system:write_transactions",
            resource_type="system",
        )
        mock_ent_repo.list_entitlements = AsyncMock(return_value=[feat])
        mock_ent_svc.revoke_entitlement = AsyncMock(
            return_value={"entitlement": {"id": str(feat.id)}}
        )

        db = AsyncMock()
        await service.set_system_feature(
            db,
            application_id=FAKE_APP_ID,
            feature_name="write_transactions",
            enabled=True,
            set_by=FAKE_ADMIN_ID,
        )

        mock_ent_svc.revoke_entitlement.assert_called_once()

    async def test_is_feature_enabled_admin_bypasses(self):
        """is_feature_enabled returns True for admin regardless of kill switch."""
        result = service.is_feature_enabled_check(
            system_features={"write_transactions": False},
            feature_name="write_transactions",
            is_admin=True,
        )
        assert result is True

    async def test_is_feature_enabled_killed(self):
        """is_feature_enabled returns False when feature is killed."""
        result = service.is_feature_enabled_check(
            system_features={"write_transactions": False},
            feature_name="write_transactions",
            is_admin=False,
        )
        assert result is False

    async def test_is_feature_enabled_absent_means_enabled(self):
        """is_feature_enabled returns True when feature is absent (not killed)."""
        result = service.is_feature_enabled_check(
            system_features={},
            feature_name="write_transactions",
            is_admin=False,
        )
        assert result is True


# ===========================================================================
# create_cfo_user / list_cfo_users
# ===========================================================================


class TestListCfoUsers:
    """Tests for list_cfo_users — the admin user-listing query."""

    async def test_returns_users_with_role_counts(self):
        """list_cfo_users returns users who have cfo:role:* entitlements."""
        user1_id = uuid4()

        # Simulate two db.execute calls: first for count, second for data rows
        count_result = MagicMock()
        count_result.scalar_one.return_value = 1

        row = MagicMock()
        row.id = user1_id
        row.email = "alice@example.com"
        row.name = "Alice"
        row.is_admin = False
        row.status = "active"
        row.role_count = 2
        row.created_at = datetime.now(UTC)

        data_result = MagicMock()
        data_result.all.return_value = [row]

        db = AsyncMock()
        db.execute = AsyncMock(side_effect=[count_result, data_result])

        result = await service.list_cfo_users(
            db,
            application_id=FAKE_APP_ID,
            limit=50,
            offset=0,
        )

        assert result["total"] == 1
        assert len(result["users"]) == 1
        assert result["users"][0]["email"] == "alice@example.com"
        assert result["users"][0]["role_count"] == 2
        assert result["users"][0]["status"] == "active"
        assert result["limit"] == 50
        assert result["offset"] == 0

    async def test_returns_empty_when_no_cfo_users(self):
        """list_cfo_users returns empty list when no cfo:role:* entitlements exist."""
        count_result = MagicMock()
        count_result.scalar_one.return_value = 0

        data_result = MagicMock()
        data_result.all.return_value = []

        db = AsyncMock()
        db.execute = AsyncMock(side_effect=[count_result, data_result])

        result = await service.list_cfo_users(
            db,
            application_id=FAKE_APP_ID,
            limit=50,
            offset=0,
        )

        assert result["total"] == 0
        assert result["users"] == []

    async def test_pagination_params_passed_through(self):
        """list_cfo_users respects custom limit and offset."""
        count_result = MagicMock()
        count_result.scalar_one.return_value = 0

        data_result = MagicMock()
        data_result.all.return_value = []

        db = AsyncMock()
        db.execute = AsyncMock(side_effect=[count_result, data_result])

        result = await service.list_cfo_users(
            db,
            application_id=FAKE_APP_ID,
            limit=10,
            offset=20,
        )

        assert result["limit"] == 10
        assert result["offset"] == 20

    async def test_status_filter_passed(self):
        """list_cfo_users passes status_filter to the query (no error)."""
        count_result = MagicMock()
        count_result.scalar_one.return_value = 0

        data_result = MagicMock()
        data_result.all.return_value = []

        db = AsyncMock()
        db.execute = AsyncMock(side_effect=[count_result, data_result])

        result = await service.list_cfo_users(
            db,
            application_id=FAKE_APP_ID,
            status_filter="active",
            limit=50,
            offset=0,
        )

        assert result["total"] == 0

    async def test_search_filter_passed(self):
        """list_cfo_users passes search filter to the query (no error)."""
        count_result = MagicMock()
        count_result.scalar_one.return_value = 0

        data_result = MagicMock()
        data_result.all.return_value = []

        db = AsyncMock()
        db.execute = AsyncMock(side_effect=[count_result, data_result])

        result = await service.list_cfo_users(
            db,
            application_id=FAKE_APP_ID,
            search="alice",
            limit=50,
            offset=0,
        )

        assert result["total"] == 0

    async def test_multiple_users_returned(self):
        """list_cfo_users returns multiple users with different statuses."""
        user1_id = uuid4()
        user2_id = uuid4()
        user3_id = uuid4()

        count_result = MagicMock()
        count_result.scalar_one.return_value = 3

        row1 = MagicMock()
        row1.id = user1_id
        row1.email = "alice@example.com"
        row1.name = "Alice"
        row1.is_admin = False
        row1.status = "active"
        row1.role_count = 2
        row1.created_at = datetime.now(UTC)

        row2 = MagicMock()
        row2.id = user2_id
        row2.email = "bob@example.com"
        row2.name = "Bob"
        row2.is_admin = True
        row2.status = "active"
        row2.role_count = 1
        row2.created_at = datetime.now(UTC)

        row3 = MagicMock()
        row3.id = user3_id
        row3.email = "carol@example.com"
        row3.name = None
        row3.is_admin = False
        row3.status = "revoked"
        row3.role_count = 0
        row3.created_at = None

        data_result = MagicMock()
        data_result.all.return_value = [row1, row2, row3]

        db = AsyncMock()
        db.execute = AsyncMock(side_effect=[count_result, data_result])

        result = await service.list_cfo_users(
            db,
            application_id=FAKE_APP_ID,
            limit=50,
            offset=0,
        )

        assert result["total"] == 3
        assert len(result["users"]) == 3
        assert result["users"][0]["email"] == "alice@example.com"
        assert result["users"][1]["is_admin"] is True
        assert result["users"][2]["status"] == "revoked"
        assert result["users"][2]["name"] is None
        # created_at fallback for None
        assert result["users"][2]["created_at"] is not None


class TestCfoUserManagement:
    @patch(_USER_REPO, new_callable=MagicMock)
    async def test_create_cfo_user_links_existing(self, mock_user_repo):
        """create_cfo_user links to existing user by email."""
        existing_user = _make_user()
        mock_user_repo.get_user_by_email = AsyncMock(return_value=existing_user)

        db = AsyncMock()
        result = await service.create_cfo_user(
            db,
            email="user@example.com",
            name="Test User",
        )

        assert result["id"] == str(existing_user.id)
        assert result["email"] == "user@example.com"

    @patch(_USER_REPO, new_callable=MagicMock)
    async def test_create_cfo_user_invalid_email(self, mock_user_repo):
        """create_cfo_user raises INVALID_EMAIL for bad email."""
        db = AsyncMock()
        with pytest.raises(InvalidEmailError):
            await service.create_cfo_user(
                db,
                email="not-an-email",
                name="Test",
            )


# ===========================================================================
# Role hierarchy
# ===========================================================================


class TestRoleHierarchy:
    def test_accountant_has_min_client(self):
        """Accountant meets minimum client requirement."""
        assert service.has_minimum_role("accountant", "client") is True

    def test_client_not_min_accountant(self):
        """Client does not meet minimum accountant requirement."""
        assert service.has_minimum_role("client", "accountant") is False

    def test_employee_exact_match(self):
        """Employee meets minimum employee requirement."""
        assert service.has_minimum_role("employee", "employee") is True

    def test_prospect_not_in_hierarchy(self):
        """Prospect does not meet any hierarchy requirement."""
        assert service.has_minimum_role("prospect", "employee") is False

    def test_admin_meets_all(self):
        """Admin meets all hierarchy requirements."""
        assert service.has_minimum_role("admin", "accountant") is True
        assert service.has_minimum_role("admin", "client") is True
        assert service.has_minimum_role("admin", "employee") is True


# ===========================================================================
# fetch_company_connection_count
# ===========================================================================


class TestFetchCompanyConnectionCount:
    """Tests for the CFO enrichment helper that fetches connection counts."""

    async def test_success_returns_connection_count(self):
        """fetch_company_connection_count returns connection_count from response."""
        import httpx
        import respx

        with respx.mock:
            respx.get(f"https://cfo.test/api/companies/{FAKE_COMPANY_ID}").mock(
                return_value=httpx.Response(
                    200,
                    json={"data": {"connection_count": 2}},
                )
            )
            result = await service.fetch_company_connection_count(
                cfo_api_url="https://cfo.test",
                cfo_admin_api_key="test-key",
                company_id=str(FAKE_COMPANY_ID),
                user_id="user-1",
            )
        assert result == 2

    async def test_empty_url_returns_zero_without_http_call(self):
        """fetch_company_connection_count returns 0 when cfo_api_url is empty."""
        result = await service.fetch_company_connection_count(
            cfo_api_url="",
            cfo_admin_api_key="test-key",
            company_id=str(FAKE_COMPANY_ID),
            user_id="user-1",
        )
        assert result == 0

    async def test_timeout_returns_zero(self):
        """fetch_company_connection_count returns 0 on timeout."""
        import httpx
        import respx

        with respx.mock:
            respx.get(f"https://cfo.test/api/companies/{FAKE_COMPANY_ID}").mock(
                side_effect=httpx.TimeoutException("connect timeout")
            )
            result = await service.fetch_company_connection_count(
                cfo_api_url="https://cfo.test",
                cfo_admin_api_key="test-key",
                company_id=str(FAKE_COMPANY_ID),
                user_id="user-1",
            )
        assert result == 0

    async def test_non_200_returns_zero(self):
        """fetch_company_connection_count returns 0 on non-200 status."""
        import httpx
        import respx

        with respx.mock:
            respx.get(f"https://cfo.test/api/companies/{FAKE_COMPANY_ID}").mock(
                return_value=httpx.Response(404, json={"error": "not found"})
            )
            result = await service.fetch_company_connection_count(
                cfo_api_url="https://cfo.test",
                cfo_admin_api_key="test-key",
                company_id=str(FAKE_COMPANY_ID),
                user_id="user-1",
            )
        assert result == 0

    async def test_fallback_to_connections_list_length(self):
        """fetch_company_connection_count falls back to len(connections)."""
        import httpx
        import respx

        with respx.mock:
            respx.get(f"https://cfo.test/api/companies/{FAKE_COMPANY_ID}").mock(
                return_value=httpx.Response(
                    200,
                    json={"data": {"connections": [1, 2]}},
                )
            )
            result = await service.fetch_company_connection_count(
                cfo_api_url="https://cfo.test",
                cfo_admin_api_key="test-key",
                company_id=str(FAKE_COMPANY_ID),
                user_id="user-1",
            )
        assert result == 2

    async def test_top_level_payload_shape_supported(self):
        """fetch_company_connection_count supports top-level CFO company responses."""
        import httpx
        import respx

        with respx.mock:
            respx.get(f"https://cfo.test/api/companies/{FAKE_COMPANY_ID}").mock(
                return_value=httpx.Response(
                    200,
                    json={"connection_count": 4},
                )
            )
            result = await service.fetch_company_connection_count(
                cfo_api_url="https://cfo.test",
                cfo_admin_api_key="test-key",
                company_id=str(FAKE_COMPANY_ID),
                user_id="user-1",
            )
        assert result == 4
