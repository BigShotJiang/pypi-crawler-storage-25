"""Unit tests for the cfo_roles admin and me routers.

Tests exercise route handlers with mocked service layer.
No database or network calls.
"""

from __future__ import annotations

import asyncio
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

from spaps_server_quickstart.domains.cfo_roles.schemas import (
    CreateUserRequest,
    AssignRoleRequest,
    ConvertProspectRequest,
    ListUsersResponse,
    UpdateCompanyFeaturesRequest,
    UpdateSystemFeaturesRequest,
)

_SERVICE = "spaps_server_quickstart.domains.cfo_roles.service"


# ===========================================================================
# Schema validation
# ===========================================================================


class TestSchemaValidation:
    def test_create_user_request_valid(self):
        req = CreateUserRequest(email="user@example.com", name="Test")
        assert req.email == "user@example.com"

    def test_create_user_request_no_name(self):
        req = CreateUserRequest(email="user@example.com")
        assert req.name is None

    def test_assign_role_request_valid(self):
        uid = str(uuid4())
        cid = str(uuid4())
        req = AssignRoleRequest(user_id=uid, company_id=cid, role="accountant")
        assert req.role == "accountant"

    def test_convert_prospect_request(self):
        req = ConvertProspectRequest(new_role="client")
        assert req.new_role == "client"

    def test_update_company_features_request(self):
        req = UpdateCompanyFeaturesRequest(
            features={"reports_dashboard": True, "document_upload": False}
        )
        assert req.features["reports_dashboard"] is True

    def test_update_system_features_request(self):
        req = UpdateSystemFeaturesRequest(
            features={"write_transactions": False}
        )
        assert req.features["write_transactions"] is False


# ===========================================================================
# Admin dependency
# ===========================================================================


class TestRequireAdmin:
    def test_require_admin_non_admin_raises(self):
        """require_admin raises 403 for non-admin user."""
        from spaps_server_quickstart.domains.cfo_roles.deps import _check_is_admin

        user = MagicMock()
        user.is_admin = False

        with pytest.raises(Exception):  # Will be ForbiddenError
            _check_is_admin(user)

    def test_require_admin_admin_passes(self):
        """require_admin passes for admin user."""
        from spaps_server_quickstart.domains.cfo_roles.deps import _check_is_admin

        user = MagicMock()
        user.is_admin = True

        # Should not raise
        _check_is_admin(user)

    def test_check_cfo_admin_key_accepts_primary_header(self):
        """X-CFO-Admin-Key should authenticate trusted service callers."""
        from spaps_server_quickstart.domains.cfo_roles.deps import _check_cfo_admin_key

        request = MagicMock()
        request.app.state.settings = SimpleNamespace(cfo_admin_api_key="test-key")
        request.headers = {"X-CFO-Admin-Key": "test-key"}

        admin = _check_cfo_admin_key(request)

        assert admin is not None
        assert admin.is_admin is True
        assert admin.id == "cfo-service"
        assert admin.email == "cfo@internal"

    def test_check_cfo_admin_key_accepts_legacy_header(self):
        """CFO_ADMIN_API_KEY fallback header should still be accepted."""
        from spaps_server_quickstart.domains.cfo_roles.deps import _check_cfo_admin_key

        request = MagicMock()
        request.app.state.settings = SimpleNamespace(cfo_admin_api_key="test-key")
        request.headers = {"CFO_ADMIN_API_KEY": "test-key"}

        admin = _check_cfo_admin_key(request)

        assert admin is not None
        assert admin.is_admin is True

    def test_check_cfo_admin_key_rejects_mismatch(self):
        """Mismatched API key should not authenticate."""
        from spaps_server_quickstart.domains.cfo_roles.deps import _check_cfo_admin_key

        request = MagicMock()
        request.app.state.settings = SimpleNamespace(cfo_admin_api_key="test-key")
        request.headers = {"X-CFO-Admin-Key": "wrong-key"}

        admin = _check_cfo_admin_key(request)

        assert admin is None


# ===========================================================================
# list_users route handler
# ===========================================================================


class TestListUsersRoute:
    """Tests for the list_users route handler logic."""

    @patch(f"{_SERVICE}.list_cfo_users", new_callable=AsyncMock)
    async def test_list_users_delegates_to_service(self, mock_list):
        """list_users calls service.list_cfo_users with the right args."""
        from spaps_server_quickstart.domains.cfo_roles.router import list_users

        user1_id = str(uuid4())
        mock_list.return_value = {
            "users": [
                {
                    "id": user1_id,
                    "email": "alice@example.com",
                    "name": "Alice",
                    "is_admin": False,
                    "status": "active",
                    "role_count": 2,
                    "created_at": "2025-01-01T00:00:00+00:00",
                },
            ],
            "total": 1,
            "limit": 50,
            "offset": 0,
        }

        db = AsyncMock()
        app = MagicMock()
        app.id = uuid4()
        admin = MagicMock()

        result = await list_users(
            db=db,
            app=app,
            admin=admin,
            status=None,
            search=None,
            limit=50,
            offset=0,
        )

        assert isinstance(result, ListUsersResponse)
        assert result.total == 1
        assert len(result.users) == 1
        assert result.users[0].email == "alice@example.com"
        assert result.users[0].role_count == 2

        mock_list.assert_called_once_with(
            db,
            application_id=app.id,
            status_filter=None,
            search=None,
            limit=50,
            offset=0,
        )

    @patch(f"{_SERVICE}.list_cfo_users", new_callable=AsyncMock)
    async def test_list_users_passes_filters(self, mock_list):
        """list_users passes status and search filters through."""
        from spaps_server_quickstart.domains.cfo_roles.router import list_users

        mock_list.return_value = {
            "users": [],
            "total": 0,
            "limit": 10,
            "offset": 5,
        }

        db = AsyncMock()
        app = MagicMock()
        app.id = uuid4()
        admin = MagicMock()

        result = await list_users(
            db=db,
            app=app,
            admin=admin,
            status="active",
            search="alice",
            limit=10,
            offset=5,
        )

        assert result.total == 0
        assert result.limit == 10
        assert result.offset == 5

        mock_list.assert_called_once_with(
            db,
            application_id=app.id,
            status_filter="active",
            search="alice",
            limit=10,
            offset=5,
        )


class TestConvertProspectRoute:
    @patch(
        "spaps_server_quickstart.domains.entitlements.repository.get_entitlement_by_id",
        new_callable=AsyncMock,
    )
    @patch(f"{_SERVICE}.convert_prospect", new_callable=AsyncMock)
    async def test_success_uses_entitlement_context(
        self,
        mock_convert,
        mock_get_entitlement,
    ):
        from spaps_server_quickstart.domains.cfo_roles.router import convert_prospect

        entitlement = MagicMock()
        entitlement.beneficiary_user_id = uuid4()
        entitlement.resource_id = uuid4()
        entitlement.metadata_ = {"company_name": "Acme"}
        mock_get_entitlement.return_value = entitlement
        mock_convert.return_value = {
            "previous": {"role": "prospect"},
            "current": {"role": "client"},
            "company_status": "active",
        }

        db = AsyncMock()
        app = MagicMock(id=uuid4())
        admin = MagicMock(id=str(uuid4()))

        result = await convert_prospect(
            assignment_id=str(uuid4()),
            body=ConvertProspectRequest(new_role="client"),
            db=db,
            app=app,
            admin=admin,
        )

        assert result.current["role"] == "client"
        assert mock_convert.await_args.kwargs["company_name"] == "Acme"

    @patch(
        "spaps_server_quickstart.domains.entitlements.repository.get_entitlement_by_id",
        new_callable=AsyncMock,
    )
    async def test_missing_entitlement_raises(self, mock_get_entitlement):
        from spaps_server_quickstart.domains.cfo_roles.router import convert_prospect
        from spaps_server_quickstart.domains.entitlements.errors import (
            EntitlementNotFoundError,
        )

        mock_get_entitlement.return_value = None

        with pytest.raises(EntitlementNotFoundError):
            await convert_prospect(
                assignment_id=str(uuid4()),
                body=ConvertProspectRequest(new_role="client"),
                db=AsyncMock(),
                app=MagicMock(id=uuid4()),
                admin=MagicMock(id=str(uuid4())),
            )

    @patch(
        "spaps_server_quickstart.domains.entitlements.repository.get_entitlement_by_id",
        new_callable=AsyncMock,
    )
    async def test_missing_beneficiary_user_raises(self, mock_get_entitlement):
        from spaps_server_quickstart.domains.cfo_roles.errors import UserNotFoundError
        from spaps_server_quickstart.domains.cfo_roles.router import convert_prospect

        entitlement = MagicMock()
        entitlement.beneficiary_user_id = None
        entitlement.resource_id = uuid4()
        entitlement.metadata_ = {}
        mock_get_entitlement.return_value = entitlement

        with pytest.raises(UserNotFoundError, match="Entitlement has no beneficiary user"):
            await convert_prospect(
                assignment_id=str(uuid4()),
                body=ConvertProspectRequest(new_role="client"),
                db=AsyncMock(),
                app=MagicMock(id=uuid4()),
                admin=MagicMock(id=str(uuid4())),
            )

    @patch(
        "spaps_server_quickstart.domains.entitlements.repository.get_entitlement_by_id",
        new_callable=AsyncMock,
    )
    async def test_missing_company_resource_raises(self, mock_get_entitlement):
        from spaps_server_quickstart.domains.cfo_roles.errors import CompanyNotFoundError
        from spaps_server_quickstart.domains.cfo_roles.router import convert_prospect

        entitlement = MagicMock()
        entitlement.beneficiary_user_id = uuid4()
        entitlement.resource_id = None
        entitlement.metadata_ = {}
        mock_get_entitlement.return_value = entitlement

        with pytest.raises(CompanyNotFoundError, match="Entitlement has no company resource"):
            await convert_prospect(
                assignment_id=str(uuid4()),
                body=ConvertProspectRequest(new_role="client"),
                db=AsyncMock(),
                app=MagicMock(id=uuid4()),
                admin=MagicMock(id=str(uuid4())),
            )

    @patch(f"{_SERVICE}.list_cfo_users", new_callable=AsyncMock)
    async def test_list_users_empty_result(self, mock_list):
        """list_users returns empty list when no CFO users exist."""
        from spaps_server_quickstart.domains.cfo_roles.router import list_users

        mock_list.return_value = {
            "users": [],
            "total": 0,
            "limit": 50,
            "offset": 0,
        }

        db = AsyncMock()
        app = MagicMock()
        app.id = uuid4()
        admin = MagicMock()

        result = await list_users(
            db=db,
            app=app,
            admin=admin,
            status=None,
            search=None,
            limit=50,
            offset=0,
        )

        assert isinstance(result, ListUsersResponse)
        assert result.total == 0
        assert result.users == []


# ===========================================================================
# get_user route handler
# ===========================================================================


class TestGetUserRoute:
    """Tests for get_user route handler app-scope behavior."""

    @patch(
        "spaps_server_quickstart.domains.cfo_roles.router.service.get_user_status",
        new_callable=AsyncMock,
    )
    @patch(
        "spaps_server_quickstart.domains.cfo_roles.router.service.get_user_companies",
        new_callable=AsyncMock,
    )
    @patch(
        "spaps_server_quickstart.domains.users.repository.get_user_by_id",
        new_callable=AsyncMock,
    )
    async def test_returns_user_detail_when_in_application_scope(
        self,
        mock_get_user_by_id,
        mock_get_companies,
        mock_get_status,
    ):
        """get_user returns details when user has CFO scope in this app."""
        from spaps_server_quickstart.domains.cfo_roles.router import get_user

        user = MagicMock()
        user.id = uuid4()
        user.email = "alice@example.com"
        user.full_name = "Alice"
        user.is_admin = False
        user.created_at = None

        mock_get_user_by_id.return_value = user
        mock_get_companies.return_value = [
            {
                "company_id": str(uuid4()),
                "company_name": "Acme Inc",
                "role": "accountant",
            }
        ]
        mock_get_status.return_value = "active"

        db = AsyncMock()
        app = MagicMock()
        app.id = uuid4()
        admin = MagicMock()

        result = await get_user(
            user_id=str(user.id),
            db=db,
            app=app,
            admin=admin,
        )

        assert result.id == str(user.id)
        assert result.status == "active"
        assert len(result.assignments) == 1

    @patch(
        "spaps_server_quickstart.domains.cfo_roles.router.service.get_user_status",
        new_callable=AsyncMock,
    )
    @patch(
        "spaps_server_quickstart.domains.cfo_roles.router.service.get_user_companies",
        new_callable=AsyncMock,
    )
    @patch(
        "spaps_server_quickstart.domains.users.repository.get_user_by_id",
        new_callable=AsyncMock,
    )
    async def test_rejects_user_outside_application_scope(
        self,
        mock_get_user_by_id,
        mock_get_companies,
        mock_get_status,
    ):
        """get_user should not reveal users with no CFO relationship to this app."""
        from spaps_server_quickstart.domains.cfo_roles.errors import UserNotFoundError
        from spaps_server_quickstart.domains.cfo_roles.router import get_user

        user = MagicMock()
        user.id = uuid4()
        user.email = "cross-app@example.com"
        user.full_name = "Cross App"
        user.is_admin = False
        user.created_at = None

        mock_get_user_by_id.return_value = user
        mock_get_companies.return_value = []
        mock_get_status.return_value = "pending"

        db = AsyncMock()
        app = MagicMock()
        app.id = uuid4()
        admin = MagicMock()

        with pytest.raises(UserNotFoundError):
            await get_user(
                user_id=str(user.id),
                db=db,
                app=app,
                admin=admin,
            )


# ===========================================================================
# /me route handler
# ===========================================================================


class TestGetMeRoute:
    """Tests for the get_me route handler /me enrichment."""

    @patch(f"{_SERVICE}.get_user_companies", new_callable=AsyncMock)
    @patch(f"{_SERVICE}.get_company_features", new_callable=AsyncMock)
    @patch(f"{_SERVICE}.get_user_role_for_company", new_callable=AsyncMock)
    @patch(f"{_SERVICE}.has_sales_role", new_callable=AsyncMock)
    async def test_rejects_unknown_company_for_non_admin(
        self,
        mock_has_sales,
        mock_role,
        mock_features,
        mock_companies,
    ):
        """get_me rejects company_id the non-admin user does not belong to."""
        from spaps_server_quickstart.domains.cfo_roles.me_router import get_me
        from spaps_server_quickstart.domains.errors import ForbiddenError

        user_id = str(uuid4())
        company_id = str(uuid4())
        other_company_id = str(uuid4())

        mock_has_sales.return_value = False
        mock_companies.return_value = [
            {"company_id": company_id, "company_name": "Acme Corp", "role": "accountant"}
        ]

        db = AsyncMock()
        app = MagicMock()
        app.id = uuid4()

        user = MagicMock()
        user.id = user_id
        user.email = "test@example.com"
        user.full_name = "Test User"
        user.is_admin = False

        settings = MagicMock()
        settings.cfo_api_url = "https://cfo.test"
        settings.cfo_admin_api_key = "test-key"

        request = MagicMock()
        request.app.state.settings = settings

        with pytest.raises(ForbiddenError, match="Company access denied"):
            await get_me(
                request=request,
                db=db,
                app=app,
                user=user,
                company_id=other_company_id,
            )

        mock_role.assert_not_called()
        mock_features.assert_not_called()

    @patch(f"{_SERVICE}.fetch_company_connection_count", new_callable=AsyncMock)
    @patch(f"{_SERVICE}.get_user_companies", new_callable=AsyncMock)
    @patch(f"{_SERVICE}.get_company_features", new_callable=AsyncMock)
    @patch(f"{_SERVICE}.get_user_role_for_company", new_callable=AsyncMock)
    @patch(f"{_SERVICE}.has_sales_role", new_callable=AsyncMock)
    async def test_connection_count_populated_when_cfo_url_set(
        self,
        mock_has_sales,
        mock_role,
        mock_features,
        mock_companies,
        mock_fetch_count,
    ):
        """get_me populates connection_count when settings.cfo_api_url is set."""
        from spaps_server_quickstart.domains.cfo_roles.me_router import get_me

        company_id = str(uuid4())
        user_id = str(uuid4())

        mock_has_sales.return_value = False
        mock_role.return_value = "accountant"
        mock_features.return_value = {}
        mock_companies.return_value = [
            {"company_id": company_id, "company_name": "Acme Corp", "role": "accountant"}
        ]
        mock_fetch_count.return_value = 5

        db = AsyncMock()
        app = MagicMock()
        app.id = uuid4()

        user = MagicMock()
        user.id = user_id
        user.email = "test@example.com"
        user.full_name = "Test User"
        user.is_admin = False

        settings = MagicMock()
        settings.cfo_api_url = "https://cfo.test"
        settings.cfo_admin_api_key = "test-key"

        request = MagicMock()
        request.app.state.settings = settings

        result = await get_me(
            request=request,
            db=db,
            app=app,
            user=user,
            company_id=company_id,
        )

        assert result.current_company is not None
        assert result.current_company.connection_count == 5
        mock_fetch_count.assert_called_once_with(
            cfo_api_url="https://cfo.test",
            cfo_admin_api_key="test-key",
            company_id=company_id,
            user_id=user_id,
        )

    @patch(f"{_SERVICE}.get_user_companies", new_callable=AsyncMock)
    @patch(f"{_SERVICE}.get_company_features", new_callable=AsyncMock)
    @patch(f"{_SERVICE}.get_user_role_for_company", new_callable=AsyncMock)
    @patch(f"{_SERVICE}.has_sales_role", new_callable=AsyncMock)
    async def test_connection_count_stays_zero_when_cfo_url_empty(
        self,
        mock_has_sales,
        mock_role,
        mock_features,
        mock_companies,
    ):
        """get_me keeps connection_count=0 when settings.cfo_api_url is empty."""
        from spaps_server_quickstart.domains.cfo_roles.me_router import get_me

        company_id = str(uuid4())
        user_id = str(uuid4())

        mock_has_sales.return_value = False
        mock_role.return_value = "client"
        mock_features.return_value = {}
        mock_companies.return_value = [
            {"company_id": company_id, "company_name": "Beta Inc", "role": "client"}
        ]

        db = AsyncMock()
        app = MagicMock()
        app.id = uuid4()

        user = MagicMock()
        user.id = user_id
        user.email = "test@example.com"
        user.full_name = "Test User"
        user.is_admin = False

        settings = MagicMock()
        settings.cfo_api_url = ""
        settings.cfo_admin_api_key = ""

        request = MagicMock()
        request.app.state.settings = settings

        result = await get_me(
            request=request,
            db=db,
            app=app,
            user=user,
            company_id=company_id,
        )

        assert result.current_company is not None
        assert result.current_company.connection_count == 0


# ===========================================================================
# /me/companies route handler
# ===========================================================================


class TestGetMyCompaniesRoute:
    """Tests for the get_my_companies route handler /me/companies enrichment."""

    @patch(f"{_SERVICE}.fetch_company_connection_count", new_callable=AsyncMock)
    @patch(f"{_SERVICE}.get_user_companies", new_callable=AsyncMock)
    async def test_connection_count_populated_when_cfo_url_set(
        self,
        mock_companies,
        mock_fetch_count,
    ):
        """get_my_companies populates connection_count when cfo_api_url is set."""
        from spaps_server_quickstart.domains.cfo_roles.me_router import get_my_companies

        cid1 = str(uuid4())
        cid2 = str(uuid4())

        mock_companies.return_value = [
            {"company_id": cid1, "company_name": "Acme Corp", "role": "accountant"},
            {"company_id": cid2, "company_name": "Beta Inc", "role": "client"},
        ]
        mock_fetch_count.side_effect = [3, 1]

        db = AsyncMock()
        app = MagicMock()
        app.id = uuid4()

        user = MagicMock()
        user.id = str(uuid4())

        settings = MagicMock()
        settings.cfo_api_url = "https://cfo.test"
        settings.cfo_admin_api_key = "test-key"

        request = MagicMock()
        request.app.state.settings = settings

        result = await get_my_companies(
            request=request,
            db=db,
            app=app,
            user=user,
        )

        assert len(result.companies) == 2
        assert result.companies[0].connection_count == 3
        assert result.companies[1].connection_count == 1
        assert mock_fetch_count.call_count == 2

    @patch(f"{_SERVICE}.get_user_companies", new_callable=AsyncMock)
    async def test_connection_count_stays_zero_when_cfo_url_empty(
        self,
        mock_companies,
    ):
        """get_my_companies keeps connection_count=0 when cfo_api_url is empty."""
        from spaps_server_quickstart.domains.cfo_roles.me_router import get_my_companies

        mock_companies.return_value = [
            {"company_id": str(uuid4()), "company_name": "Acme Corp", "role": "accountant"},
        ]

        db = AsyncMock()
        app = MagicMock()
        app.id = uuid4()

        user = MagicMock()
        user.id = str(uuid4())

        settings = MagicMock()
        settings.cfo_api_url = ""
        settings.cfo_admin_api_key = ""

        request = MagicMock()
        request.app.state.settings = settings

        result = await get_my_companies(
            request=request,
            db=db,
            app=app,
            user=user,
        )

        assert len(result.companies) == 1
        assert result.companies[0].connection_count == 0

    @patch(f"{_SERVICE}.fetch_company_connection_count", new_callable=AsyncMock)
    @patch(f"{_SERVICE}.get_user_companies", new_callable=AsyncMock)
    async def test_uses_asyncio_gather_for_parallel_enrichment(
        self,
        mock_companies,
        mock_fetch_count,
    ):
        """get_my_companies calls asyncio.gather for parallel enrichment."""
        from spaps_server_quickstart.domains.cfo_roles.me_router import get_my_companies

        cid1 = str(uuid4())
        cid2 = str(uuid4())

        mock_companies.return_value = [
            {"company_id": cid1, "company_name": "Acme Corp", "role": "accountant"},
            {"company_id": cid2, "company_name": "Beta Inc", "role": "client"},
        ]
        mock_fetch_count.side_effect = [2, 4]

        db = AsyncMock()
        app = MagicMock()
        app.id = uuid4()

        user = MagicMock()
        user.id = str(uuid4())

        settings = MagicMock()
        settings.cfo_api_url = "https://cfo.test"
        settings.cfo_admin_api_key = "test-key"

        request = MagicMock()
        request.app.state.settings = settings

        with patch("spaps_server_quickstart.domains.cfo_roles.me_router.asyncio.gather", wraps=asyncio.gather) as mock_gather:
            result = await get_my_companies(
                request=request,
                db=db,
                app=app,
                user=user,
            )
            mock_gather.assert_called_once()

        assert len(result.companies) == 2
        assert result.companies[0].connection_count == 2
        assert result.companies[1].connection_count == 4


class TestListRoleAssignmentsRoute:
    """Tests for list_role_assignments route handler pagination wiring."""

    @patch(
        "spaps_server_quickstart.domains.entitlements.repository.list_entitlements",
        new_callable=AsyncMock,
    )
    async def test_passes_offset_to_entitlements_query(self, mock_list_entitlements):
        """list_role_assignments must pass offset to list_entitlements."""
        from spaps_server_quickstart.domains.cfo_roles.router import list_role_assignments

        mock_list_entitlements.return_value = []

        db = AsyncMock()
        app = MagicMock()
        app.id = uuid4()
        admin = MagicMock()

        result = await list_role_assignments(
            db=db,
            app=app,
            admin=admin,
            user_id=None,
            company_id=None,
            limit=10,
            offset=5,
        )

        assert result.limit == 10
        assert result.offset == 5
        mock_list_entitlements.assert_called_once_with(
            db,
            app.id,
            resource_type="company",
            include_revoked=False,
            limit=10,
            offset=5,
        )
