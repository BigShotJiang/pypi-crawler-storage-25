"""Tests for the cfo_roles domain."""
