"""Unit tests for the crypto payments domain routers (HTTP layer).

Each test creates a minimal FastAPI test app with dependency overrides for
the database session and application. The crypto service layer is fully
mocked so tests exercise only routing, request validation, status codes,
and response shapes.
"""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from spaps_server_quickstart.domains.crypto.router import (
    crypto_router,
    payments_stub_router,
    usage_stub_router,
)
from spaps_server_quickstart.middleware.error_handler import install_error_handlers
from spaps_server_quickstart.middleware.spaps_deps import (
    get_application,
    get_db_session,
)

# ---------------------------------------------------------------------------
# Helpers / Constants
# ---------------------------------------------------------------------------

FAKE_APP_ID = str(uuid4())
FAKE_INVOICE_ID = str(uuid4())

_CRYPTO_SERVICE = "spaps_server_quickstart.domains.crypto.service"


def _fake_invoice(
    asset: str = "BTC",
    network: str = "bitcoin",
    status: str = "pending",
) -> dict:
    """Return a realistic crypto invoice dict."""
    return {
        "id": FAKE_INVOICE_ID,
        "application_id": FAKE_APP_ID,
        "asset": asset,
        "network": network,
        "amount": "0.001",
        "status": status,
        "underpaid": None,
        "overpaid": None,
        "beneficiary": None,
        "metadata": {},
        "destination": None,
        "settlement": None,
        "expires_at": None,
        "settled_at": None,
        "created_at": datetime.now(UTC).isoformat(),
        "updated_at": datetime.now(UTC).isoformat(),
    }


def _fake_application():
    """Return a mock application."""
    app = MagicMock()
    app.id = FAKE_APP_ID
    app.name = "Test App"
    return app


def _create_test_app(*, crypto_enabled: bool = True, webhook_secrets: str | None = None):
    """Create a FastAPI test app with crypto routers and overridden deps."""
    app = FastAPI()

    settings = MagicMock()
    settings.jwt_secret = "test-secret"
    settings.crypto_payments_enabled = crypto_enabled
    if webhook_secrets is not None:
        settings.crypto_webhook_secrets = webhook_secrets
    else:
        settings.crypto_webhook_secrets = '{"lightning":"secret1","evm":"secret2","solana":"secret3","bitcoin":"secret4"}'
    app.state.settings = settings

    install_error_handlers(app)
    app.include_router(crypto_router)
    app.include_router(payments_stub_router)
    app.include_router(usage_stub_router)

    mock_db = AsyncMock()

    async def override_db_session():
        yield mock_db

    app.dependency_overrides[get_db_session] = override_db_session
    app.dependency_overrides[get_application] = _fake_application

    return app


@pytest.fixture
def test_app():
    return _create_test_app()


@pytest.fixture
def test_app_crypto_disabled():
    return _create_test_app(crypto_enabled=False)


@pytest.fixture
def test_app_no_webhook_secrets():
    return _create_test_app(webhook_secrets="{}")


@pytest.fixture
async def client(test_app):
    transport = ASGITransport(app=test_app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


@pytest.fixture
async def client_crypto_disabled(test_app_crypto_disabled):
    transport = ASGITransport(app=test_app_crypto_disabled)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


@pytest.fixture
async def client_no_webhook_secrets(test_app_no_webhook_secrets):
    transport = ASGITransport(app=test_app_no_webhook_secrets)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


# ===========================================================================
# POST /payments/crypto/invoices
# ===========================================================================


class TestCreateInvoice:
    @patch(f"{_CRYPTO_SERVICE}.create_invoice", new_callable=AsyncMock)
    async def test_success(self, mock_create, client: AsyncClient):
        """POST /payments/crypto/invoices creates invoice and returns 201."""
        mock_create.return_value = {"invoice": _fake_invoice()}

        resp = await client.post(
            "/payments/crypto/invoices",
            json={
                "asset": "BTC",
                "network": "bitcoin",
                "amount": "0.001",
            },
        )

        assert resp.status_code == 201
        data = resp.json()
        assert data["invoice"]["asset"] == "BTC"
        assert data["invoice"]["status"] == "pending"

    @patch(f"{_CRYPTO_SERVICE}.create_invoice", new_callable=AsyncMock)
    async def test_with_optional_fields(self, mock_create, client: AsyncClient):
        """POST /payments/crypto/invoices with all optional fields."""
        mock_create.return_value = {"invoice": _fake_invoice()}

        resp = await client.post(
            "/payments/crypto/invoices",
            json={
                "asset": "ETH",
                "network": "ethereum",
                "amount": "1.5",
                "expires_in_seconds": 3600,
                "beneficiary": "user@example.com",
                "metadata": {"order_id": "123"},
            },
        )

        assert resp.status_code == 201

    async def test_missing_asset_returns_400(self, client: AsyncClient):
        """POST /payments/crypto/invoices without asset returns 400."""
        resp = await client.post(
            "/payments/crypto/invoices",
            json={"network": "bitcoin", "amount": "0.001"},
        )
        assert resp.status_code == 400

    async def test_missing_network_returns_400(self, client: AsyncClient):
        """POST /payments/crypto/invoices without network returns 400."""
        resp = await client.post(
            "/payments/crypto/invoices",
            json={"asset": "BTC", "amount": "0.001"},
        )
        assert resp.status_code == 400

    async def test_missing_amount_returns_400(self, client: AsyncClient):
        """POST /payments/crypto/invoices without amount returns 400."""
        resp = await client.post(
            "/payments/crypto/invoices",
            json={"asset": "BTC", "network": "bitcoin"},
        )
        assert resp.status_code == 400

    @patch(f"{_CRYPTO_SERVICE}.create_invoice", new_callable=AsyncMock)
    async def test_crypto_disabled_returns_503(
        self, mock_create, client_crypto_disabled: AsyncClient
    ):
        """POST /payments/crypto/invoices returns 503 when crypto disabled."""
        from spaps_server_quickstart.domains.crypto.errors import (
            CryptoPaymentsDisabledError,
        )

        mock_create.side_effect = CryptoPaymentsDisabledError()

        resp = await client_crypto_disabled.post(
            "/payments/crypto/invoices",
            json={
                "asset": "BTC",
                "network": "bitcoin",
                "amount": "0.001",
            },
        )

        assert resp.status_code == 503

    @patch(f"{_CRYPTO_SERVICE}.create_invoice", new_callable=AsyncMock)
    async def test_unsupported_asset_returns_400(self, mock_create, client: AsyncClient):
        """POST /payments/crypto/invoices with unsupported asset returns 400."""
        from spaps_server_quickstart.domains.crypto.errors import UnsupportedAssetError

        mock_create.side_effect = UnsupportedAssetError()

        resp = await client.post(
            "/payments/crypto/invoices",
            json={
                "asset": "DOGE",
                "network": "bitcoin",
                "amount": "0.001",
            },
        )

        assert resp.status_code == 400

    @patch(f"{_CRYPTO_SERVICE}.create_invoice", new_callable=AsyncMock)
    async def test_unsupported_network_returns_400(self, mock_create, client: AsyncClient):
        """POST /payments/crypto/invoices with unsupported network returns 400."""
        from spaps_server_quickstart.domains.crypto.errors import UnsupportedNetworkError

        mock_create.side_effect = UnsupportedNetworkError()

        resp = await client.post(
            "/payments/crypto/invoices",
            json={
                "asset": "BTC",
                "network": "cardano",
                "amount": "0.001",
            },
        )

        assert resp.status_code == 400


# ===========================================================================
# Crypto Webhook Handlers
# ===========================================================================


class TestWebhookHandlers:
    """Test all four crypto webhook handlers."""

    @patch(f"{_CRYPTO_SERVICE}.process_webhook", new_callable=AsyncMock)
    @patch(f"{_CRYPTO_SERVICE}.verify_webhook_hmac")
    async def test_lightning_webhook_success(
        self, mock_verify, mock_process, client: AsyncClient
    ):
        """POST /payments/crypto/webhooks/lightning processes webhook."""
        mock_process.return_value = {"received": True, "message": "Webhook processed"}

        resp = await client.post(
            "/payments/crypto/webhooks/lightning",
            json={"dedupe_key": "ln-event-123", "data": {}},
            headers={"X-SPAPS-Signature": "t=1234567890,v1=abc123"},
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["received"] is True

    @patch(f"{_CRYPTO_SERVICE}.process_webhook", new_callable=AsyncMock)
    @patch(f"{_CRYPTO_SERVICE}.verify_webhook_hmac")
    async def test_evm_webhook_success(
        self, mock_verify, mock_process, client: AsyncClient
    ):
        """POST /payments/crypto/webhooks/evm processes webhook."""
        mock_process.return_value = {"received": True, "message": "Webhook processed"}

        resp = await client.post(
            "/payments/crypto/webhooks/evm",
            json={"dedupe_key": "evm-event-123", "data": {}},
            headers={"X-SPAPS-Signature": "t=1234567890,v1=abc123"},
        )

        assert resp.status_code == 200

    @patch(f"{_CRYPTO_SERVICE}.process_webhook", new_callable=AsyncMock)
    @patch(f"{_CRYPTO_SERVICE}.verify_webhook_hmac")
    async def test_solana_webhook_success(
        self, mock_verify, mock_process, client: AsyncClient
    ):
        """POST /payments/crypto/webhooks/solana processes webhook."""
        mock_process.return_value = {"received": True, "message": "Webhook processed"}

        resp = await client.post(
            "/payments/crypto/webhooks/solana",
            json={"dedupe_key": "sol-event-123", "data": {}},
            headers={"X-SPAPS-Signature": "t=1234567890,v1=abc123"},
        )

        assert resp.status_code == 200

    @patch(f"{_CRYPTO_SERVICE}.process_webhook", new_callable=AsyncMock)
    @patch(f"{_CRYPTO_SERVICE}.verify_webhook_hmac")
    async def test_bitcoin_webhook_success(
        self, mock_verify, mock_process, client: AsyncClient
    ):
        """POST /payments/crypto/webhooks/bitcoin processes webhook."""
        mock_process.return_value = {"received": True, "message": "Webhook processed"}

        resp = await client.post(
            "/payments/crypto/webhooks/bitcoin",
            json={"dedupe_key": "btc-event-123", "data": {}},
            headers={"X-SPAPS-Signature": "t=1234567890,v1=abc123"},
        )

        assert resp.status_code == 200

    @patch(f"{_CRYPTO_SERVICE}.verify_webhook_hmac")
    async def test_webhook_invalid_signature_returns_401(
        self, mock_verify, client: AsyncClient
    ):
        """Webhook with invalid signature returns 401."""
        from spaps_server_quickstart.domains.crypto.errors import WebhookSignatureError

        mock_verify.side_effect = WebhookSignatureError()

        resp = await client.post(
            "/payments/crypto/webhooks/lightning",
            json={"dedupe_key": "test", "data": {}},
            headers={"X-SPAPS-Signature": "t=1234567890,v1=bad"},
        )

        assert resp.status_code == 401

    @patch(f"{_CRYPTO_SERVICE}.verify_webhook_hmac")
    async def test_webhook_missing_dedupe_key_returns_400(
        self, mock_verify, client: AsyncClient
    ):
        """Webhook without dedupe_key returns 400."""
        resp = await client.post(
            "/payments/crypto/webhooks/lightning",
            json={"data": {}},
            headers={"X-SPAPS-Signature": "t=1234567890,v1=abc123"},
        )

        assert resp.status_code == 400

    @patch(f"{_CRYPTO_SERVICE}.process_webhook", new_callable=AsyncMock)
    @patch(f"{_CRYPTO_SERVICE}.verify_webhook_hmac")
    async def test_duplicate_webhook_returns_200(
        self, mock_verify, mock_process, client: AsyncClient
    ):
        """Duplicate webhook returns 200 (idempotent)."""
        from spaps_server_quickstart.domains.crypto.errors import DuplicateWebhookError

        mock_process.side_effect = DuplicateWebhookError()

        resp = await client.post(
            "/payments/crypto/webhooks/lightning",
            json={"dedupe_key": "dup-event-123", "data": {}},
            headers={"X-SPAPS-Signature": "t=1234567890,v1=abc123"},
        )

        assert resp.status_code == 200

    async def test_webhook_rejects_when_secret_missing(
        self, client_no_webhook_secrets: AsyncClient
    ):
        """When no secret configured for provider, return 400 validation error."""
        resp = await client_no_webhook_secrets.post(
            "/payments/crypto/webhooks/lightning",
            json={"dedupe_key": "test-event", "data": {}},
            headers={"X-SPAPS-Signature": "t=1234567890,v1=abc123"},
        )

        assert resp.status_code == 400
        data = resp.json()
        assert data["success"] is False
        assert data["error"]["code"] == "VALIDATION_ERROR"
        assert "not configured" in data["error"]["message"].lower()


# ===========================================================================
# NOT_IMPLEMENTED Stubs -- Wallet Payments
# ===========================================================================


class TestPaymentStubs:
    """Test all 6 wallet payment 501 stubs."""

    async def test_wallet_deposit_returns_501(self, client: AsyncClient):
        """POST /payments/wallet-deposit returns 501."""
        resp = await client.post("/payments/wallet-deposit")
        assert resp.status_code == 501

    async def test_wallet_transaction_returns_501(self, client: AsyncClient):
        """GET /payments/wallet-transaction/:txId returns 501."""
        resp = await client.get("/payments/wallet-transaction/tx_123")
        assert resp.status_code == 501

    async def test_create_checkout_session_returns_501(self, client: AsyncClient):
        """POST /payments/create-checkout-session returns 501."""
        resp = await client.post("/payments/create-checkout-session")
        assert resp.status_code == 501

    async def test_get_subscription_returns_501(self, client: AsyncClient):
        """GET /payments/subscription/:id returns 501."""
        resp = await client.get("/payments/subscription/sub_123")
        assert resp.status_code == 501

    async def test_cancel_subscription_returns_501(self, client: AsyncClient):
        """POST /payments/cancel-subscription returns 501."""
        resp = await client.post("/payments/cancel-subscription")
        assert resp.status_code == 501

    async def test_get_balance_returns_501(self, client: AsyncClient):
        """GET /payments/balance returns 501."""
        resp = await client.get("/payments/balance")
        assert resp.status_code == 501


# ===========================================================================
# NOT_IMPLEMENTED Stubs -- Usage Tracking
# ===========================================================================


class TestUsageStubs:
    """Test all 3 usage tracking 501 stubs."""

    async def test_get_features_returns_501(self, client: AsyncClient):
        """GET /usage/features returns 501."""
        resp = await client.get("/usage/features")
        assert resp.status_code == 501

    async def test_record_usage_returns_501(self, client: AsyncClient):
        """POST /usage/record returns 501."""
        resp = await client.post("/usage/record")
        assert resp.status_code == 501

    async def test_get_usage_history_returns_501(self, client: AsyncClient):
        """GET /usage/history returns 501."""
        resp = await client.get("/usage/history")
        assert resp.status_code == 501
