"""Unit tests for the crypto payments service layer.

Tests business logic, validation, HMAC verification, and deduplication
with fully mocked repository.
"""

from __future__ import annotations

import hashlib
import hmac
import time
from datetime import UTC, datetime
from decimal import Decimal
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

from spaps_server_quickstart.domains.crypto import service
from spaps_server_quickstart.domains.crypto.errors import (
    CryptoPaymentsDisabledError,
    DuplicateWebhookError,
    UnsupportedAssetError,
    UnsupportedNetworkError,
    WebhookSignatureError,
    WebhookSignatureExpiredError,
)

FAKE_APP_ID = uuid4()
FAKE_INVOICE_ID = uuid4()

_REPO = "spaps_server_quickstart.domains.crypto.repository"


def _mock_invoice(**overrides):
    """Create a mock CryptoInvoice."""
    invoice = MagicMock()
    invoice.id = overrides.get("id", FAKE_INVOICE_ID)
    invoice.application_id = overrides.get("application_id", FAKE_APP_ID)
    invoice.asset = overrides.get("asset", "BTC")
    invoice.network = overrides.get("network", "bitcoin")
    invoice.amount = overrides.get("amount", Decimal("0.001"))
    invoice.status = overrides.get("status", "pending")
    invoice.underpaid = overrides.get("underpaid", None)
    invoice.overpaid = overrides.get("overpaid", None)
    invoice.beneficiary = overrides.get("beneficiary", None)
    invoice.metadata_ = overrides.get("metadata_", {})
    invoice.destination = overrides.get("destination", None)
    invoice.settlement = overrides.get("settlement", None)
    invoice.expires_at = overrides.get("expires_at", None)
    invoice.settled_at = overrides.get("settled_at", None)
    invoice.created_at = overrides.get("created_at", datetime.now(UTC))
    invoice.updated_at = overrides.get("updated_at", datetime.now(UTC))
    return invoice


# ===========================================================================
# Invoice creation
# ===========================================================================


class TestCreateInvoice:
    @patch(f"{_REPO}.get_receiving_address", new_callable=AsyncMock)
    @patch(f"{_REPO}.create_invoice", new_callable=AsyncMock)
    async def test_creates_invoice(self, mock_create, mock_addr):
        """create_invoice creates invoice with correct params."""
        mock_addr.return_value = None
        mock_create.return_value = _mock_invoice()

        result = await service.create_invoice(
            AsyncMock(),
            application_id=FAKE_APP_ID,
            asset="BTC",
            network="bitcoin",
            amount="0.001",
            crypto_enabled=True,
        )

        assert "invoice" in result
        assert result["invoice"]["asset"] == "BTC"
        mock_create.assert_called_once()

    async def test_disabled_raises_error(self):
        """create_invoice raises when crypto disabled."""
        with pytest.raises(CryptoPaymentsDisabledError):
            await service.create_invoice(
                AsyncMock(),
                application_id=FAKE_APP_ID,
                asset="BTC",
                network="bitcoin",
                amount="0.001",
                crypto_enabled=False,
            )

    async def test_unsupported_asset_raises(self):
        """create_invoice raises for unsupported asset."""
        with pytest.raises(UnsupportedAssetError):
            await service.create_invoice(
                AsyncMock(),
                application_id=FAKE_APP_ID,
                asset="DOGE",
                network="bitcoin",
                amount="0.001",
                crypto_enabled=True,
            )

    async def test_unsupported_network_raises(self):
        """create_invoice raises for unsupported network."""
        with pytest.raises(UnsupportedNetworkError):
            await service.create_invoice(
                AsyncMock(),
                application_id=FAKE_APP_ID,
                asset="BTC",
                network="cardano",
                amount="0.001",
                crypto_enabled=True,
            )

    async def test_invalid_amount_raises(self):
        """create_invoice raises for invalid amount."""
        from spaps_server_quickstart.domains.errors import ValidationError

        with pytest.raises(ValidationError):
            await service.create_invoice(
                AsyncMock(),
                application_id=FAKE_APP_ID,
                asset="BTC",
                network="bitcoin",
                amount="not-a-number",
                crypto_enabled=True,
            )

    async def test_zero_amount_raises(self):
        """create_invoice raises for zero amount."""
        from spaps_server_quickstart.domains.errors import ValidationError

        with pytest.raises(ValidationError):
            await service.create_invoice(
                AsyncMock(),
                application_id=FAKE_APP_ID,
                asset="BTC",
                network="bitcoin",
                amount="0",
                crypto_enabled=True,
            )

    async def test_negative_amount_raises(self):
        """create_invoice raises for negative amount."""
        from spaps_server_quickstart.domains.errors import ValidationError

        with pytest.raises(ValidationError):
            await service.create_invoice(
                AsyncMock(),
                application_id=FAKE_APP_ID,
                asset="BTC",
                network="bitcoin",
                amount="-1",
                crypto_enabled=True,
            )

    @patch(f"{_REPO}.get_receiving_address", new_callable=AsyncMock)
    @patch(f"{_REPO}.create_invoice", new_callable=AsyncMock)
    async def test_with_expiration(self, mock_create, mock_addr):
        """create_invoice sets expires_at from expires_in_seconds."""
        mock_addr.return_value = None
        mock_create.return_value = _mock_invoice()

        result = await service.create_invoice(
            AsyncMock(),
            application_id=FAKE_APP_ID,
            asset="BTC",
            network="bitcoin",
            amount="0.001",
            expires_in_seconds=3600,
            crypto_enabled=True,
        )

        assert "invoice" in result
        # Verify create_invoice was called with expires_at
        call_kwargs = mock_create.call_args.kwargs
        assert call_kwargs["expires_at"] is not None

    @patch(f"{_REPO}.get_receiving_address", new_callable=AsyncMock)
    @patch(f"{_REPO}.create_invoice", new_callable=AsyncMock)
    async def test_with_receiving_address(self, mock_create, mock_addr):
        """create_invoice includes destination from receiving address."""
        addr = MagicMock()
        addr.destination_type = "address"
        addr.destination_address = "bc1q..."
        addr.destination_details = {"memo": "test"}
        mock_addr.return_value = addr
        mock_create.return_value = _mock_invoice()

        await service.create_invoice(
            AsyncMock(),
            application_id=FAKE_APP_ID,
            asset="BTC",
            network="bitcoin",
            amount="0.001",
            crypto_enabled=True,
        )

        call_kwargs = mock_create.call_args.kwargs
        assert call_kwargs["destination"] is not None
        assert call_kwargs["destination"]["address"] == "bc1q..."

    @patch(f"{_REPO}.get_receiving_address", new_callable=AsyncMock)
    @patch(f"{_REPO}.create_invoice", new_callable=AsyncMock)
    async def test_asset_normalised_uppercase(self, mock_create, mock_addr):
        """create_invoice normalises asset to uppercase."""
        mock_addr.return_value = None
        mock_create.return_value = _mock_invoice()

        await service.create_invoice(
            AsyncMock(),
            application_id=FAKE_APP_ID,
            asset="btc",
            network="bitcoin",
            amount="0.001",
            crypto_enabled=True,
        )

        call_kwargs = mock_create.call_args.kwargs
        assert call_kwargs["asset"] == "BTC"

    @patch(f"{_REPO}.get_receiving_address", new_callable=AsyncMock)
    @patch(f"{_REPO}.create_invoice", new_callable=AsyncMock)
    async def test_network_normalised_lowercase(self, mock_create, mock_addr):
        """create_invoice normalises network to lowercase."""
        mock_addr.return_value = None
        mock_create.return_value = _mock_invoice()

        await service.create_invoice(
            AsyncMock(),
            application_id=FAKE_APP_ID,
            asset="ETH",
            network="ETHEREUM",
            amount="1.0",
            crypto_enabled=True,
        )

        call_kwargs = mock_create.call_args.kwargs
        assert call_kwargs["network"] == "ethereum"


# ===========================================================================
# HMAC verification
# ===========================================================================


class TestVerifyWebhookHmac:
    def test_valid_signature(self):
        """verify_webhook_hmac passes for valid signature."""
        secret = "test-secret"
        body = b'{"event":"test"}'
        ts = str(int(time.time()))
        signed_payload = f"{ts}.".encode() + body
        sig = hmac.new(secret.encode(), signed_payload, hashlib.sha256).hexdigest()
        header = f"t={ts},v1={sig}"

        # Should not raise
        service.verify_webhook_hmac(
            payload_body=body,
            signature_header=header,
            secret=secret,
        )

    def test_invalid_signature_raises(self):
        """verify_webhook_hmac raises for wrong signature."""
        ts = str(int(time.time()))
        header = f"t={ts},v1=bad_sig"

        with pytest.raises(WebhookSignatureError):
            service.verify_webhook_hmac(
                payload_body=b"body",
                signature_header=header,
                secret="secret",
            )

    def test_missing_header_raises(self):
        """verify_webhook_hmac raises for empty header."""
        with pytest.raises(WebhookSignatureError):
            service.verify_webhook_hmac(
                payload_body=b"body",
                signature_header="",
                secret="secret",
            )

    def test_expired_timestamp_raises(self):
        """verify_webhook_hmac raises for expired timestamp."""
        secret = "test-secret"
        body = b"body"
        old_ts = str(int(time.time()) - 600)  # 10 minutes ago
        signed_payload = f"{old_ts}.".encode() + body
        sig = hmac.new(secret.encode(), signed_payload, hashlib.sha256).hexdigest()
        header = f"t={old_ts},v1={sig}"

        with pytest.raises(WebhookSignatureExpiredError):
            service.verify_webhook_hmac(
                payload_body=body,
                signature_header=header,
                secret=secret,
                tolerance_seconds=300,
            )

    def test_malformed_header_raises(self):
        """verify_webhook_hmac raises for malformed header."""
        with pytest.raises(WebhookSignatureError):
            service.verify_webhook_hmac(
                payload_body=b"body",
                signature_header="garbage",
                secret="secret",
            )

    def test_non_numeric_timestamp_raises(self):
        """verify_webhook_hmac raises for non-numeric timestamp."""
        with pytest.raises(WebhookSignatureError):
            service.verify_webhook_hmac(
                payload_body=b"body",
                signature_header="t=abc,v1=def",
                secret="secret",
            )


# ===========================================================================
# Webhook processing
# ===========================================================================


class TestProcessWebhook:
    @patch(f"{_REPO}.record_dedupe", new_callable=AsyncMock)
    @patch(f"{_REPO}.check_dedupe", new_callable=AsyncMock)
    async def test_processes_new_webhook(self, mock_check, mock_record):
        """process_webhook records non-duplicate webhook."""
        mock_check.return_value = False
        mock_record.return_value = MagicMock()

        result = await service.process_webhook(
            AsyncMock(),
            provider="lightning",
            dedupe_key="lightning:event-123",
            payload={"event": "confirmed"},
        )

        assert result["received"] is True
        mock_record.assert_called_once()

    @patch(f"{_REPO}.check_dedupe", new_callable=AsyncMock)
    async def test_duplicate_raises(self, mock_check):
        """process_webhook raises DuplicateWebhookError for duplicates."""
        mock_check.return_value = True

        with pytest.raises(DuplicateWebhookError):
            await service.process_webhook(
                AsyncMock(),
                provider="lightning",
                dedupe_key="lightning:event-123",
                payload={"event": "confirmed"},
            )
