"""Unit tests for the crypto domain repository layer.

Tests repository functions with mocked AsyncSession.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

from spaps_server_quickstart.domains.crypto import repository as repo
from spaps_server_quickstart.domains.crypto.models import (
    AppReceivingAddress,
    ChainSyncState,
    CryptoInvoice,
    CryptoWebhookDedupe,
    LedgerTransaction,
)


FAKE_APP_ID = uuid4()
FAKE_INVOICE_ID = uuid4()


def _mock_db():
    """Create a mocked AsyncSession."""
    db = AsyncMock()
    db.add = MagicMock()  # add() is synchronous in SQLAlchemy
    db.flush = AsyncMock()
    db.refresh = AsyncMock()
    return db


# ===========================================================================
# Invoice Operations
# ===========================================================================


class TestCreateInvoice:
    async def test_creates_and_returns(self):
        """create_invoice adds invoice to session and returns it."""
        db = _mock_db()

        result = await repo.create_invoice(
            db,
            application_id=FAKE_APP_ID,
            asset="SOL",
            network="solana-mainnet",
            amount="1.5",
            status="pending",
        )

        assert result is not None
        assert isinstance(result, CryptoInvoice)
        db.add.assert_called_once()
        db.flush.assert_called_once()
        db.refresh.assert_called_once()


class TestGetInvoiceById:
    async def test_found(self):
        """get_invoice_by_id returns invoice when found."""
        invoice = MagicMock(spec=CryptoInvoice)
        invoice.id = FAKE_INVOICE_ID
        invoice.application_id = FAKE_APP_ID

        db = _mock_db()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = invoice
        db.execute = AsyncMock(return_value=result_mock)

        result = await repo.get_invoice_by_id(db, FAKE_INVOICE_ID)

        assert result is invoice
        db.execute.assert_called_once()

    async def test_not_found(self):
        """get_invoice_by_id returns None when not found."""
        db = _mock_db()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute = AsyncMock(return_value=result_mock)

        result = await repo.get_invoice_by_id(db, uuid4())

        assert result is None

    async def test_scoped_to_application(self):
        """get_invoice_by_id can filter by application_id."""
        invoice = MagicMock(spec=CryptoInvoice)
        invoice.id = FAKE_INVOICE_ID
        invoice.application_id = FAKE_APP_ID

        db = _mock_db()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = invoice
        db.execute = AsyncMock(return_value=result_mock)

        result = await repo.get_invoice_by_id(
            db, FAKE_INVOICE_ID, application_id=FAKE_APP_ID
        )

        assert result is invoice

    async def test_wrong_application_returns_none(self):
        """get_invoice_by_id returns None when application doesn't match."""
        db = _mock_db()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute = AsyncMock(return_value=result_mock)

        # Invoice exists but belongs to different app
        result = await repo.get_invoice_by_id(
            db, FAKE_INVOICE_ID, application_id=uuid4()
        )

        assert result is None


class TestUpdateInvoice:
    async def test_updates_existing(self):
        """update_invoice modifies existing invoice."""
        invoice = MagicMock(spec=CryptoInvoice)
        invoice.id = FAKE_INVOICE_ID
        invoice.status = "pending"

        db = _mock_db()
        with patch.object(
            repo, "get_invoice_by_id", new_callable=AsyncMock
        ) as mock_get:
            mock_get.return_value = invoice
            result = await repo.update_invoice(
                db,
                FAKE_INVOICE_ID,
                status="confirmed",
                tx_hash="0xabcdef",
            )

            assert result is invoice
            db.flush.assert_called_once()
            db.refresh.assert_called_once()

    async def test_returns_none_if_not_found(self):
        """update_invoice returns None if invoice doesn't exist."""
        db = _mock_db()
        with patch.object(
            repo, "get_invoice_by_id", new_callable=AsyncMock
        ) as mock_get:
            mock_get.return_value = None
            result = await repo.update_invoice(db, uuid4(), status="confirmed")

            assert result is None

    async def test_updates_metadata(self):
        """update_invoice can update metadata_ field."""
        invoice = MagicMock(spec=CryptoInvoice)
        invoice.id = FAKE_INVOICE_ID
        invoice.metadata_ = {}

        db = _mock_db()
        with patch.object(
            repo, "get_invoice_by_id", new_callable=AsyncMock
        ) as mock_get:
            mock_get.return_value = invoice
            await repo.update_invoice(
                db,
                FAKE_INVOICE_ID,
                metadata={"custom": "value"},
            )

            # Verify metadata_ was set
            assert hasattr(invoice, "metadata_")


# ===========================================================================
# Ledger Operations
# ===========================================================================


class TestLedgerTransactions:
    async def test_create_ledger_transaction(self):
        """create_ledger_transaction inserts transaction."""
        db = _mock_db()

        result = await repo.create_ledger_transaction(
            db,
            application_id=FAKE_APP_ID,
            invoice_id=uuid4(),
            asset="SOL",
            network="solana-mainnet",
            amount="1.5",
            dedupe_key=f"txn_{uuid4()}",
        )

        assert result is not None
        assert isinstance(result, LedgerTransaction)
        db.add.assert_called_once()
        db.flush.assert_called_once()
        db.refresh.assert_called_once()


# ===========================================================================
# Webhook Deduplication
# ===========================================================================


class TestWebhookDeduplication:
    async def test_check_dedupe_not_exists(self):
        """check_dedupe returns False for new key."""
        db = _mock_db()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute = AsyncMock(return_value=result_mock)

        result = await repo.check_dedupe(db, "unique_key_123")

        assert result is False

    async def test_check_dedupe_exists(self):
        """check_dedupe returns True for existing key."""
        dedupe = MagicMock(spec=CryptoWebhookDedupe)
        dedupe.dedupe_key = "existing_key"

        db = _mock_db()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = dedupe
        db.execute = AsyncMock(return_value=result_mock)

        result = await repo.check_dedupe(db, "existing_key")

        assert result is True

    async def test_record_dedupe(self):
        """record_dedupe inserts new dedupe record."""
        db = _mock_db()

        result = await repo.record_dedupe(
            db,
            dedupe_key="new_dedupe_123",
            payload={"webhook_id": "wh_123"},
        )

        assert result is not None
        assert isinstance(result, CryptoWebhookDedupe)
        db.add.assert_called_once()
        db.flush.assert_called_once()

    async def test_record_dedupe_without_payload(self):
        """record_dedupe works without payload."""
        db = _mock_db()

        result = await repo.record_dedupe(db, dedupe_key="key_no_payload")

        assert result is not None
        db.add.assert_called_once()


# ===========================================================================
# Receiving Addresses
# ===========================================================================


class TestReceivingAddresses:
    async def test_get_receiving_address_found(self):
        """get_receiving_address returns address when found."""
        address = MagicMock(spec=AppReceivingAddress)
        address.application_id = FAKE_APP_ID
        address.asset = "SOL"
        address.network = "solana-mainnet"

        db = _mock_db()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = address
        db.execute = AsyncMock(return_value=result_mock)

        result = await repo.get_receiving_address(
            db, FAKE_APP_ID, "SOL", "solana-mainnet"
        )

        assert result is address

    async def test_get_receiving_address_not_found(self):
        """get_receiving_address returns None when not found."""
        db = _mock_db()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute = AsyncMock(return_value=result_mock)

        result = await repo.get_receiving_address(
            db, FAKE_APP_ID, "ETH", "ethereum-mainnet"
        )

        assert result is None

    async def test_get_receiving_address_filters_by_all_params(self):
        """get_receiving_address filters by app, asset, and network."""
        db = _mock_db()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute = AsyncMock(return_value=result_mock)

        # Verify all three filters are applied
        await repo.get_receiving_address(
            db, FAKE_APP_ID, "USDC", "polygon-mainnet"
        )

        db.execute.assert_called_once()


# ===========================================================================
# Chain Sync State
# ===========================================================================


class TestChainSyncState:
    async def test_get_sync_state_found(self):
        """get_sync_state returns state when found."""
        state = MagicMock(spec=ChainSyncState)
        state.provider = "helius"
        state.cursor = "cursor_12345"

        db = _mock_db()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = state
        db.execute = AsyncMock(return_value=result_mock)

        result = await repo.get_sync_state(db, "helius")

        assert result is state

    async def test_get_sync_state_not_found(self):
        """get_sync_state returns None when not found."""
        db = _mock_db()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute = AsyncMock(return_value=result_mock)

        result = await repo.get_sync_state(db, "unknown_provider")

        assert result is None

    async def test_upsert_sync_state_creates_new(self):
        """upsert_sync_state creates new state if doesn't exist."""
        db = _mock_db()
        with patch.object(repo, "get_sync_state", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = None
            result = await repo.upsert_sync_state(
                db, provider="helius", cursor="new_cursor"
            )

            assert result is not None
            assert isinstance(result, ChainSyncState)
            db.add.assert_called_once()
            db.flush.assert_called_once()

    async def test_upsert_sync_state_updates_existing(self):
        """upsert_sync_state updates existing state."""
        state = MagicMock(spec=ChainSyncState)
        state.provider = "helius"
        state.cursor = "old_cursor"

        db = _mock_db()
        with patch.object(repo, "get_sync_state", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = state
            result = await repo.upsert_sync_state(
                db, provider="helius", cursor="updated_cursor"
            )

            assert result is state
            db.flush.assert_called_once()
            db.refresh.assert_called_once()
            # Verify add was NOT called (update, not insert)
            db.add.assert_not_called()
