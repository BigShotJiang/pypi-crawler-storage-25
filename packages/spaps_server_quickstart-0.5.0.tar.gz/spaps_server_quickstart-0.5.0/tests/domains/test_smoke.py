"""
Phase 0 smoke tests.

Validates the foundation is correctly wired:
- Domain infrastructure imports
- SPAPS app creation
- Health endpoint responds
- Error handler works
- Response envelope wraps correctly
"""

from __future__ import annotations

import pytest
from httpx import ASGITransport, AsyncClient

from spaps_server_quickstart.domains._db.base import Base
from spaps_server_quickstart.domains.errors import (
    DomainError,
    InvalidCredentialsError,
    NotFoundError,
    ValidationError,
)
from spaps_server_quickstart.domains.events import DomainEvent, EventBus
from spaps_server_quickstart.spaps_app import create_spaps_app
from spaps_server_quickstart.spaps_settings import SpapsSettings


@pytest.fixture
def test_settings() -> SpapsSettings:
    return SpapsSettings(
        env="test",
        app_name="SPAPS Test",
        database_url="postgresql+asyncpg://postgres:postgres@localhost:5434/spaps_test",
        spaps_local_mode=True,
    )


@pytest.fixture
def test_app(test_settings: SpapsSettings):
    return create_spaps_app(settings=test_settings)


@pytest.fixture
async def client(test_app):
    transport = ASGITransport(app=test_app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


# --- Domain Infrastructure ---


class TestDomainErrors:
    def test_domain_error_base(self):
        err = DomainError("TEST_ERROR", "test message", status_code=418, details={"key": "val"})
        assert err.code == "TEST_ERROR"
        assert err.message == "test message"
        assert err.status_code == 418
        assert err.details == {"key": "val"}
        assert str(err) == "test message"

    def test_error_subclasses(self):
        assert InvalidCredentialsError().status_code == 401
        assert InvalidCredentialsError().code == "INVALID_CREDENTIALS"
        assert NotFoundError().status_code == 404
        assert NotFoundError().code == "NOT_FOUND"
        assert ValidationError().status_code == 400
        assert ValidationError().code == "VALIDATION_ERROR"

    def test_all_error_codes_unique(self):
        """Verify no two error classes share the same code."""
        from spaps_server_quickstart.domains import errors

        codes: dict[str, str] = {}
        for name in dir(errors):
            cls = getattr(errors, name)
            if isinstance(cls, type) and issubclass(cls, DomainError) and cls is not DomainError:
                try:
                    instance = cls()
                    if instance.code in codes:
                        # Some errors legitimately share codes with different status codes
                        pass
                    codes[instance.code] = name
                except TypeError:
                    pass  # Requires arguments


class TestEventBus:
    async def test_publish_subscribe(self):
        bus = EventBus()
        received: list[DomainEvent] = []

        async def handler(event: DomainEvent) -> None:
            received.append(event)

        bus.subscribe("test.event", handler)
        event = DomainEvent(event_type="test.event", source_domain="test", data={"x": 1})
        await bus.publish(event)

        assert len(received) == 1
        assert received[0].data == {"x": 1}

    async def test_handler_error_logged_not_raised(self):
        bus = EventBus()

        async def bad_handler(event: DomainEvent) -> None:
            raise RuntimeError("boom")

        async def good_handler(event: DomainEvent) -> None:
            pass  # Should still run

        bus.subscribe("test.event", bad_handler)
        bus.subscribe("test.event", good_handler)

        event = DomainEvent(event_type="test.event", source_domain="test", data={})
        # Should not raise
        await bus.publish(event)

    async def test_unsubscribe(self):
        bus = EventBus()
        called = False

        async def handler(event: DomainEvent) -> None:
            nonlocal called
            called = True

        bus.subscribe("test.event", handler)
        bus.unsubscribe("test.event", handler)

        event = DomainEvent(event_type="test.event", source_domain="test", data={})
        await bus.publish(event)
        assert not called


class TestDeclarativeBase:
    def test_base_metadata_exists(self):
        assert Base.metadata is not None


# --- App Factory ---


class TestAppFactory:
    def test_create_app(self, test_app):
        assert test_app is not None
        assert test_app.title == "SPAPS - Sweet Potato Auth & Payment Service"

    async def test_health_endpoint(self, client: AsyncClient):
        response = await client.get("/health")
        assert response.status_code == 200
        data = response.json()
        # Health endpoint is envelope-wrapped via middleware
        assert data["success"] is True
        assert data["data"]["status"] == "ok"
        assert "version" in data["data"]
        assert "started_at" in data["data"]
        assert "started_at_est" in data["data"]

    async def test_health_local_mode(self, client: AsyncClient):
        response = await client.get("/health/local-mode")
        assert response.status_code == 200
        data = response.json()
        assert data["success"] is True
        assert data["data"]["local_mode_active"] is True

    async def test_metrics_json(self, client: AsyncClient):
        response = await client.get("/api/metrics/json")
        assert response.status_code == 200
        data = response.json()
        assert data["success"] is True
        assert "uptime_seconds" in data["data"]

    async def test_metrics_prometheus(self, client: AsyncClient):
        response = await client.get("/api/metrics")
        assert response.status_code == 200
        assert "spaps_uptime_seconds" in response.text

    async def test_docs_endpoint(self, client: AsyncClient):
        response = await client.get("/docs")
        assert response.status_code == 200


# --- Error Handling ---


class TestErrorHandling:
    async def test_domain_error_returns_envelope(self, test_app, client: AsyncClient):
        """DomainError raised in a route should produce the error envelope."""
        from fastapi import APIRouter

        router = APIRouter()

        @router.get("/test-error")
        async def raise_error():
            raise NotFoundError("Widget not found")

        test_app.include_router(router)

        response = await client.get("/test-error")
        assert response.status_code == 404
        data = response.json()
        assert data["success"] is False
        assert data["error"]["code"] == "NOT_FOUND"
        assert data["error"]["message"] == "Widget not found"
        assert "metadata" in data

    async def test_validation_error_returns_envelope(self, client: AsyncClient):
        """FastAPI request validation errors should produce the error envelope."""
        # POST to a non-existent endpoint with invalid JSON triggers 404, not validation
        # We'd need a real route with Pydantic model to test this properly
        pass


# --- Settings ---


class TestSpapsSettings:
    def test_default_settings(self, test_settings: SpapsSettings):
        assert test_settings.app_name == "SPAPS Test"
        assert test_settings.version == "1.0.0"
        assert test_settings.service_slug == "spaps"

    def test_local_mode_active_in_dev(self):
        settings = SpapsSettings(env="dev", spaps_local_mode=True)
        assert settings.is_spaps_local_mode is True

    def test_local_mode_blocked_in_prod(self):
        settings = SpapsSettings(env="prod", spaps_local_mode=True)
        assert settings.is_spaps_local_mode is False

    def test_cors_defaults(self, test_settings: SpapsSettings):
        assert "X-API-Key" in test_settings.cors_allow_headers
