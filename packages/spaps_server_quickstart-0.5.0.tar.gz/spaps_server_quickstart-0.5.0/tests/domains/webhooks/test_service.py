"""Unit tests for the webhooks domain service layer.

Tests business logic with mocked repository. No database required.
"""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import UUID, uuid4

import pytest

from spaps_server_quickstart.domains.webhooks.errors import (
    InvalidEventTypeError,
    InvalidWebhookSignatureError,
    InvalidWebhookUrlError,
    WebhookNotConfiguredError,
    WebhookNotFoundError,
)
from spaps_server_quickstart.domains.webhooks.schemas import VALID_EVENT_TYPE_KEYS
from spaps_server_quickstart.domains.webhooks.service import (
    create_webhook,
    delete_webhook,
    list_deliveries,
    list_event_types,
    list_webhooks,
    process_mailgun_event,
    trigger_event,
    update_webhook,
)

_REPO = "spaps_server_quickstart.domains.webhooks.repository"

FAKE_APP_ID = uuid4()
FAKE_WEBHOOK_ID = uuid4()


def _make_webhook(
    webhook_id: UUID | None = None,
    url: str = "https://example.com/hook",
    events: list[str] | None = None,
    is_active: bool = True,
) -> MagicMock:
    """Create a mock Webhook model instance."""
    wh = MagicMock()
    wh.id = webhook_id or uuid4()
    wh.application_id = FAKE_APP_ID
    wh.url = url
    wh.secret = "a" * 64
    wh.events = events or ["user.registered"]
    wh.is_active = is_active
    wh.headers = {}
    wh.retry_config = {"max_attempts": 3, "initial_delay_ms": 1000, "max_delay_ms": 10000}
    wh.created_at = datetime.now(UTC)
    wh.updated_at = datetime.now(UTC)
    return wh


def _make_delivery(
    event_type: str = "user.registered",
    status: int | None = 200,
) -> MagicMock:
    """Create a mock WebhookDelivery model instance."""
    d = MagicMock()
    d.id = uuid4()
    d.webhook_id = FAKE_WEBHOOK_ID
    d.event_type = event_type
    d.payload = {"type": event_type}
    d.response_status = status
    d.response_body = "OK" if status == 200 else None
    d.delivered_at = datetime.now(UTC) if status == 200 else None
    d.retry_count = 0
    d.attempt = 1
    d.error_message = None if status == 200 else "Failed"
    return d


def _make_event(event_type: str = "user.registered") -> MagicMock:
    """Create a mock WebhookEvent model instance."""
    e = MagicMock()
    e.id = uuid4()
    e.type = event_type
    e.application_id = FAKE_APP_ID
    e.user_id = None
    e.data = {"user_id": str(uuid4())}
    e.created_at = datetime.now(UTC)
    e.schema_version = 1
    return e


class TestListWebhooks:
    @patch(f"{_REPO}.list_webhooks", new_callable=AsyncMock)
    async def test_returns_webhooks(self, mock_list):
        """list_webhooks returns list and count."""
        mock_list.return_value = [_make_webhook(), _make_webhook()]
        db = AsyncMock()

        result = await list_webhooks(db, application_id=FAKE_APP_ID)

        assert result["total"] == 2
        assert len(result["webhooks"]) == 2

    @patch(f"{_REPO}.list_webhooks", new_callable=AsyncMock)
    async def test_empty_list(self, mock_list):
        """list_webhooks returns empty list when no webhooks."""
        mock_list.return_value = []
        db = AsyncMock()

        result = await list_webhooks(db, application_id=FAKE_APP_ID)

        assert result["total"] == 0
        assert result["webhooks"] == []


class TestCreateWebhook:
    @patch("socket.getaddrinfo", return_value=[(2, 1, 6, "", ("93.184.216.34", 443))])
    @patch(f"{_REPO}.create_webhook", new_callable=AsyncMock)
    async def test_creates_with_secret(self, mock_create, _mock_dns):
        """create_webhook generates a secret and creates webhook."""
        mock_create.return_value = _make_webhook()
        db = AsyncMock()

        result = await create_webhook(
            db,
            application_id=FAKE_APP_ID,
            url="https://example.com/hook",
            events=["user.registered"],
        )

        assert "webhook" in result
        assert result["message"] == "Webhook registered successfully"
        # Verify secret was passed to create
        call_kwargs = mock_create.call_args.kwargs
        assert "secret" in call_kwargs
        assert len(call_kwargs["secret"]) == 64  # token_hex(32) = 64 chars

    async def test_invalid_url_raises(self):
        """create_webhook raises for invalid URL scheme."""
        db = AsyncMock()

        with pytest.raises(InvalidWebhookUrlError):
            await create_webhook(
                db,
                application_id=FAKE_APP_ID,
                url="ftp://bad-scheme.com",
                events=["user.registered"],
            )

    @patch("socket.getaddrinfo", return_value=[(2, 1, 6, "", ("93.184.216.34", 443))])
    async def test_invalid_event_type_raises(self, _mock_dns):
        """create_webhook raises for unknown event types."""
        db = AsyncMock()

        with pytest.raises(InvalidEventTypeError):
            await create_webhook(
                db,
                application_id=FAKE_APP_ID,
                url="https://example.com/hook",
                events=["nonexistent.event"],
            )

    @patch("socket.getaddrinfo", return_value=[(2, 1, 6, "", ("93.184.216.34", 3000))])
    @patch(f"{_REPO}.create_webhook", new_callable=AsyncMock)
    async def test_http_url_accepted(self, mock_create, _mock_dns):
        """create_webhook accepts http:// URLs."""
        mock_create.return_value = _make_webhook(url="http://example.com:3000/hook")
        db = AsyncMock()

        result = await create_webhook(
            db,
            application_id=FAKE_APP_ID,
            url="http://example.com:3000/hook",
            events=["user.login"],
            environment="test",
        )

        assert "webhook" in result

    async def test_http_url_rejected_in_production(self):
        """create_webhook rejects http:// URLs in production (PII/auth data over plaintext)."""
        db = AsyncMock()

        with pytest.raises(InvalidWebhookUrlError):
            await create_webhook(
                db,
                application_id=FAKE_APP_ID,
                url="http://example.com/hook",
                events=["user.registered"],
                environment="production",
            )

    @patch("socket.getaddrinfo", return_value=[(2, 1, 6, "", ("127.0.0.1", 443))])
    @patch(f"{_REPO}.create_webhook", new_callable=AsyncMock)
    async def test_blocks_private_ip_targets(self, mock_create, _mock_dns):
        """create_webhook blocks URLs that resolve to private/loopback IPs (SSRF)."""
        db = AsyncMock()

        with pytest.raises(InvalidWebhookUrlError):
            await create_webhook(
                db,
                application_id=FAKE_APP_ID,
                url="https://evil.example/webhook",
                events=["user.registered"],
            )

        mock_create.assert_not_called()


class TestUpdateWebhook:
    @patch(f"{_REPO}.update_webhook", new_callable=AsyncMock)
    async def test_updates_fields(self, mock_update):
        """update_webhook passes fields to repository."""
        mock_update.return_value = _make_webhook(url="https://new.com/hook")
        db = AsyncMock()

        result = await update_webhook(
            db,
            webhook_id=FAKE_WEBHOOK_ID,
            application_id=FAKE_APP_ID,
            url="https://new.com/hook",
        )

        assert result["webhook"]["url"] == "https://new.com/hook"

    @patch(f"{_REPO}.update_webhook", new_callable=AsyncMock)
    async def test_not_found_raises(self, mock_update):
        """update_webhook raises when webhook not found."""
        mock_update.return_value = None
        db = AsyncMock()

        with pytest.raises(WebhookNotFoundError):
            await update_webhook(
                db,
                webhook_id=uuid4(),
                application_id=FAKE_APP_ID,
                url="https://new.com/hook",
            )

    async def test_invalid_url_raises(self):
        """update_webhook validates URL scheme."""
        db = AsyncMock()

        with pytest.raises(InvalidWebhookUrlError):
            await update_webhook(
                db,
                webhook_id=FAKE_WEBHOOK_ID,
                application_id=FAKE_APP_ID,
                url="ftp://bad.com",
            )

    async def test_invalid_events_raises(self):
        """update_webhook validates event types."""
        db = AsyncMock()

        with pytest.raises(InvalidEventTypeError):
            await update_webhook(
                db,
                webhook_id=FAKE_WEBHOOK_ID,
                application_id=FAKE_APP_ID,
                events=["bad.event"],
            )


class TestDeleteWebhook:
    @patch(f"{_REPO}.delete_webhook", new_callable=AsyncMock)
    async def test_deletes_successfully(self, mock_delete):
        """delete_webhook returns success."""
        mock_delete.return_value = True
        db = AsyncMock()

        result = await delete_webhook(
            db,
            webhook_id=FAKE_WEBHOOK_ID,
            application_id=FAKE_APP_ID,
        )

        assert result["message"] == "Webhook deleted successfully"
        assert result["webhook_id"] == str(FAKE_WEBHOOK_ID)

    @patch(f"{_REPO}.delete_webhook", new_callable=AsyncMock)
    async def test_not_found_raises(self, mock_delete):
        """delete_webhook raises when webhook not found."""
        mock_delete.return_value = False
        db = AsyncMock()

        with pytest.raises(WebhookNotFoundError):
            await delete_webhook(
                db,
                webhook_id=uuid4(),
                application_id=FAKE_APP_ID,
            )


class TestListDeliveries:
    @patch(f"{_REPO}.list_deliveries", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_webhook_by_id", new_callable=AsyncMock)
    async def test_returns_deliveries(self, mock_get, mock_list):
        """list_deliveries returns delivery list and total."""
        mock_get.return_value = _make_webhook(webhook_id=FAKE_WEBHOOK_ID)
        mock_list.return_value = [_make_delivery(), _make_delivery()]
        db = AsyncMock()

        result = await list_deliveries(
            db,
            webhook_id=FAKE_WEBHOOK_ID,
            application_id=FAKE_APP_ID,
        )

        assert result["total"] == 2
        assert len(result["deliveries"]) == 2

    @patch(f"{_REPO}.get_webhook_by_id", new_callable=AsyncMock)
    async def test_webhook_not_found_raises(self, mock_get):
        """list_deliveries raises when webhook not found."""
        mock_get.return_value = None
        db = AsyncMock()

        with pytest.raises(WebhookNotFoundError):
            await list_deliveries(
                db,
                webhook_id=uuid4(),
                application_id=FAKE_APP_ID,
            )


class TestListEventTypes:
    async def test_returns_all_event_types(self):
        """list_event_types returns the hardcoded event type list."""
        result = await list_event_types()

        assert result["total"] == len(VALID_EVENT_TYPE_KEYS)
        keys = {e["key"] for e in result["events"]}
        assert keys == VALID_EVENT_TYPE_KEYS

    async def test_event_structure(self):
        """Each event type has key, value, and description."""
        result = await list_event_types()

        for event in result["events"]:
            assert "key" in event
            assert "value" in event
            assert "description" in event


class TestTriggerEvent:
    @patch(f"{_REPO}.find_active_webhooks_for_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.create_webhook_event", new_callable=AsyncMock)
    async def test_creates_event_record(self, mock_create_event, mock_find):
        """trigger_event creates a webhook event record."""
        mock_event = _make_event()
        mock_create_event.return_value = mock_event
        mock_find.return_value = []
        db = AsyncMock()

        result = await trigger_event(
            db,
            event_type="user.registered",
            application_id=FAKE_APP_ID,
            data={"user_id": "u-1"},
        )

        assert result is not None
        mock_create_event.assert_called_once()

    @patch(f"{_REPO}.find_active_webhooks_for_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.create_webhook_event", new_callable=AsyncMock)
    async def test_unknown_event_returns_none(self, mock_create, mock_find):
        """trigger_event returns None for unknown event types."""
        db = AsyncMock()

        result = await trigger_event(
            db,
            event_type="nonexistent.event",
            application_id=FAKE_APP_ID,
            data={},
        )

        assert result is None
        mock_create.assert_not_called()

    @patch("spaps_server_quickstart.domains.webhooks.service.asyncio.create_task")
    @patch(f"{_REPO}.find_active_webhooks_for_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.create_webhook_event", new_callable=AsyncMock)
    async def test_fires_delivery_tasks(
        self, mock_create_event, mock_find, mock_create_task
    ):
        """trigger_event fires an async delivery task per matching webhook."""
        mock_event = _make_event()
        mock_create_event.return_value = mock_event
        mock_find.return_value = [_make_webhook(), _make_webhook()]
        db = AsyncMock()

        await trigger_event(
            db,
            event_type="user.registered",
            application_id=FAKE_APP_ID,
            data={"user_id": "u-1"},
        )

        assert mock_create_task.call_count == 2

        # Close unawaited coroutines passed to mocked create_task to prevent
        # "coroutine '_deliver_and_record' was never awaited" warnings.
        for call in mock_create_task.call_args_list:
            coro = call[0][0]
            if hasattr(coro, "close"):
                coro.close()

    @patch("spaps_server_quickstart.domains.webhooks.service.asyncio.create_task")
    @patch(f"{_REPO}.find_active_webhooks_for_event", new_callable=AsyncMock)
    @patch(f"{_REPO}.create_webhook_event", new_callable=AsyncMock)
    async def test_no_tasks_when_no_webhooks(
        self, mock_create_event, mock_find, mock_create_task
    ):
        """trigger_event does not fire tasks when no matching webhooks."""
        mock_create_event.return_value = _make_event()
        mock_find.return_value = []
        db = AsyncMock()

        await trigger_event(
            db,
            event_type="user.registered",
            application_id=FAKE_APP_ID,
            data={},
        )

        mock_create_task.assert_not_called()


# ===========================================================================
# process_mailgun_event()
# ===========================================================================


class TestProcessMailgunEvent:
    """Tests for Mailgun webhook event processing."""

    async def test_raises_when_signing_key_missing(self):
        """process_mailgun_event raises WebhookNotConfiguredError when signing key is empty."""
        db = AsyncMock()
        body = {
            "signature": {"timestamp": "123", "token": "tok", "signature": "sig"},
            "event-data": {"event": "delivered"},
        }

        with pytest.raises(WebhookNotConfiguredError) as exc:
            await process_mailgun_event(db, body=body, mailgun_webhook_signing_key="")

        assert "signing key is not configured" in str(exc.value).lower()

    @patch("spaps_server_quickstart.domains.webhooks.signing.verify_mailgun_signature")
    async def test_raises_when_signature_invalid(self, mock_verify):
        """process_mailgun_event raises InvalidWebhookSignatureError on bad signature."""
        mock_verify.return_value = False
        db = AsyncMock()
        body = {
            "signature": {"timestamp": "123", "token": "tok", "signature": "bad"},
            "event-data": {"event": "delivered"},
        }

        with pytest.raises(InvalidWebhookSignatureError) as exc:
            await process_mailgun_event(db, body=body, mailgun_webhook_signing_key="test-key")

        assert "invalid" in str(exc.value).lower()
        mock_verify.assert_called_once_with(
            signing_key="test-key",
            timestamp="123",
            token="tok",
            signature="bad",
        )

    @patch("spaps_server_quickstart.domains.webhooks.signing.verify_mailgun_signature")
    async def test_success_without_message_id(self, mock_verify):
        """process_mailgun_event succeeds when signature is valid but no message ID."""
        mock_verify.return_value = True
        db = AsyncMock()
        body = {
            "signature": {"timestamp": "123", "token": "tok", "signature": "sig"},
            "event-data": {
                "event": "delivered",
                "message": {"headers": {}},
            },
        }

        result = await process_mailgun_event(db, body=body, mailgun_webhook_signing_key="test-key")

        assert result["event"] == "delivered"
        assert result["status"] == "delivered"
        assert result["email_log_updated"] is False

    @patch("spaps_server_quickstart.domains.email.repository.get_log_by_mailgun_message_id")
    @patch("spaps_server_quickstart.domains.email.repository.update_email_log")
    @patch("spaps_server_quickstart.domains.webhooks.signing.verify_mailgun_signature")
    async def test_updates_email_log_on_delivered(self, mock_verify, mock_update, mock_get_log):
        """process_mailgun_event updates email_log with delivered timestamp."""
        mock_verify.return_value = True
        db = AsyncMock()

        # Mock email log entry
        mock_log = MagicMock()
        mock_log.id = uuid4()
        mock_log.delivered_at = None
        mock_log.opened_at = None
        mock_log.clicked_at = None

        mock_get_log.return_value = mock_log
        mock_update.return_value = AsyncMock()

        body = {
            "signature": {"timestamp": "123", "token": "tok", "signature": "sig"},
            "event-data": {
                "event": "delivered",
                "message": {"headers": {"message-id": "msg-123"}},
            },
        }

        result = await process_mailgun_event(db, body=body, mailgun_webhook_signing_key="test-key")

        assert result["email_log_updated"] is True
        mock_get_log.assert_called_once_with(db, "msg-123")

        # Verify update was called with status and delivered_at
        call_args = mock_update.call_args
        assert call_args[0][0] == db
        assert call_args[0][1] == mock_log.id
        assert call_args[1]["status"] == "delivered"
        assert "delivered_at" in call_args[1]

    @patch("spaps_server_quickstart.domains.email.repository.get_log_by_mailgun_message_id")
    @patch("spaps_server_quickstart.domains.email.repository.update_email_log")
    @patch("spaps_server_quickstart.domains.webhooks.signing.verify_mailgun_signature")
    async def test_updates_email_log_on_opened(self, mock_verify, mock_update, mock_get_log):
        """process_mailgun_event updates email_log with opened timestamp."""
        mock_verify.return_value = True
        db = AsyncMock()

        mock_log = MagicMock()
        mock_log.id = uuid4()
        mock_log.delivered_at = datetime.now(UTC)
        mock_log.opened_at = None
        mock_log.clicked_at = None

        mock_get_log.return_value = mock_log
        mock_update.return_value = AsyncMock()

        body = {
            "signature": {"timestamp": "123", "token": "tok", "signature": "sig"},
            "event-data": {
                "event": "opened",
                "message": {"headers": {"message-id": "msg-123"}},
            },
        }

        result = await process_mailgun_event(db, body=body, mailgun_webhook_signing_key="test-key")

        assert result["email_log_updated"] is True

        call_args = mock_update.call_args
        assert call_args[1]["status"] == "opened"
        assert "opened_at" in call_args[1]

    @patch("spaps_server_quickstart.domains.email.repository.get_log_by_mailgun_message_id")
    @patch("spaps_server_quickstart.domains.email.repository.update_email_log")
    @patch("spaps_server_quickstart.domains.webhooks.signing.verify_mailgun_signature")
    async def test_updates_email_log_on_clicked(self, mock_verify, mock_update, mock_get_log):
        """process_mailgun_event updates email_log with clicked timestamp."""
        mock_verify.return_value = True
        db = AsyncMock()

        mock_log = MagicMock()
        mock_log.id = uuid4()
        mock_log.delivered_at = datetime.now(UTC)
        mock_log.opened_at = datetime.now(UTC)
        mock_log.clicked_at = None

        mock_get_log.return_value = mock_log
        mock_update.return_value = AsyncMock()

        body = {
            "signature": {"timestamp": "123", "token": "tok", "signature": "sig"},
            "event-data": {
                "event": "clicked",
                "message": {"headers": {"message-id": "msg-123"}},
            },
        }

        result = await process_mailgun_event(db, body=body, mailgun_webhook_signing_key="test-key")

        assert result["email_log_updated"] is True

        call_args = mock_update.call_args
        assert call_args[1]["status"] == "clicked"
        assert "clicked_at" in call_args[1]

    @patch("spaps_server_quickstart.domains.email.repository.get_log_by_mailgun_message_id")
    @patch("spaps_server_quickstart.domains.email.repository.update_email_log")
    @patch("spaps_server_quickstart.domains.webhooks.signing.verify_mailgun_signature")
    async def test_does_not_update_already_set_timestamps(
        self, mock_verify, mock_update, mock_get_log
    ):
        """process_mailgun_event does not overwrite existing timestamps."""
        mock_verify.return_value = True
        db = AsyncMock()

        existing_time = datetime.now(UTC)
        mock_log = MagicMock()
        mock_log.id = uuid4()
        mock_log.delivered_at = existing_time
        mock_log.opened_at = None
        mock_log.clicked_at = None

        mock_get_log.return_value = mock_log
        mock_update.return_value = AsyncMock()

        body = {
            "signature": {"timestamp": "123", "token": "tok", "signature": "sig"},
            "event-data": {
                "event": "delivered",
                "message": {"headers": {"message-id": "msg-123"}},
            },
        }

        await process_mailgun_event(db, body=body, mailgun_webhook_signing_key="test-key")

        call_args = mock_update.call_args
        # delivered_at should NOT be in the update since it's already set
        assert "delivered_at" not in call_args[1]
        assert call_args[1]["status"] == "delivered"

    @patch("spaps_server_quickstart.domains.email.repository.get_log_by_mailgun_message_id")
    @patch("spaps_server_quickstart.domains.webhooks.signing.verify_mailgun_signature")
    async def test_handles_email_log_not_found(self, mock_verify, mock_get_log):
        """process_mailgun_event succeeds when email log entry is not found."""
        mock_verify.return_value = True
        db = AsyncMock()

        mock_get_log.return_value = None

        body = {
            "signature": {"timestamp": "123", "token": "tok", "signature": "sig"},
            "event-data": {
                "event": "delivered",
                "message": {"headers": {"message-id": "msg-unknown"}},
            },
        }

        result = await process_mailgun_event(db, body=body, mailgun_webhook_signing_key="test-key")

        assert result["email_log_updated"] is False
        mock_get_log.assert_called_once()

    @patch("spaps_server_quickstart.domains.email.repository.get_log_by_mailgun_message_id")
    @patch("spaps_server_quickstart.domains.webhooks.signing.verify_mailgun_signature")
    async def test_handles_db_error_gracefully(self, mock_verify, mock_get_log):
        """process_mailgun_event logs but does not raise when DB update fails."""
        from sqlalchemy.exc import SQLAlchemyError

        mock_verify.return_value = True
        db = AsyncMock()

        mock_get_log.side_effect = SQLAlchemyError("DB error")

        body = {
            "signature": {"timestamp": "123", "token": "tok", "signature": "sig"},
            "event-data": {
                "event": "delivered",
                "message": {"headers": {"message-id": "msg-123"}},
            },
        }

        # Should not raise, should return success
        result = await process_mailgun_event(db, body=body, mailgun_webhook_signing_key="test-key")

        assert result["email_log_updated"] is False
        assert result["event"] == "delivered"

    @patch("spaps_server_quickstart.domains.webhooks.signing.verify_mailgun_signature")
    async def test_maps_event_types_correctly(self, mock_verify):
        """process_mailgun_event maps all supported Mailgun event types."""
        mock_verify.return_value = True
        db = AsyncMock()

        event_mappings = [
            ("delivered", "delivered"),
            ("opened", "opened"),
            ("clicked", "clicked"),
            ("complained", "complained"),
            ("failed", "failed"),
            ("bounced", "bounced"),
            ("unknown_event", "unknown_event"),  # Unmapped events pass through
        ]

        for mailgun_event, expected_status in event_mappings:
            body = {
                "signature": {"timestamp": "123", "token": "tok", "signature": "sig"},
                "event-data": {
                    "event": mailgun_event,
                    "message": {"headers": {}},
                },
            }

            result = await process_mailgun_event(
                db, body=body, mailgun_webhook_signing_key="test-key"
            )

            assert result["status"] == expected_status
            assert result["event"] == mailgun_event


# ===========================================================================
# TM-007: Webhook Destination Governance
# ===========================================================================


class TestWebhookDestinationGovernance:
    """TM-007: Destination governance policy enforcement."""

    @patch("socket.getaddrinfo", return_value=[(2, 1, 6, "", ("93.184.216.34", 443))])
    @patch(f"{_REPO}.create_webhook", new_callable=AsyncMock)
    async def test_policy_off_allows_any_domain(self, mock_create, _mock_dns):
        """When policy_mode='off', any domain is allowed (existing behavior)."""
        mock_create.return_value = _make_webhook(url="https://random-domain.com/hook")
        db = AsyncMock()

        result = await create_webhook(
            db,
            application_id=FAKE_APP_ID,
            url="https://random-domain.com/hook",
            events=["user.registered"],
            policy_mode="off",
            allowed_domains=(),
        )

        assert "webhook" in result
        mock_create.assert_called_once()

    @patch("socket.getaddrinfo", return_value=[(2, 1, 6, "", ("93.184.216.34", 443))])
    @patch(f"{_REPO}.create_webhook", new_callable=AsyncMock)
    async def test_allowlist_mode_allows_exact_domain(self, mock_create, _mock_dns):
        """When policy_mode='allowlist' and domain matches, webhook is created."""
        mock_create.return_value = _make_webhook(url="https://example.com/hook")
        db = AsyncMock()

        result = await create_webhook(
            db,
            application_id=FAKE_APP_ID,
            url="https://example.com/hook",
            events=["user.registered"],
            policy_mode="allowlist",
            allowed_domains=("example.com", "partner.com"),
        )

        assert "webhook" in result
        mock_create.assert_called_once()

    @patch("socket.getaddrinfo", return_value=[(2, 1, 6, "", ("93.184.216.34", 443))])
    @patch(f"{_REPO}.create_webhook", new_callable=AsyncMock)
    async def test_allowlist_mode_allows_subdomain(self, mock_create, _mock_dns):
        """When policy_mode='allowlist', subdomains of allowed domains are permitted."""
        mock_create.return_value = _make_webhook(url="https://api.example.com/hook")
        db = AsyncMock()

        result = await create_webhook(
            db,
            application_id=FAKE_APP_ID,
            url="https://api.example.com/hook",
            events=["user.registered"],
            policy_mode="allowlist",
            allowed_domains=("example.com",),
        )

        assert "webhook" in result
        mock_create.assert_called_once()

    @patch("socket.getaddrinfo", return_value=[(2, 1, 6, "", ("93.184.216.34", 443))])
    async def test_allowlist_mode_denies_non_allowed_domain(self, _mock_dns):
        """When policy_mode='allowlist' and domain not in list, creation is denied."""
        from spaps_server_quickstart.domains.webhooks.errors import WebhookDestinationNotAllowedError

        db = AsyncMock()

        with pytest.raises(WebhookDestinationNotAllowedError) as exc:
            await create_webhook(
                db,
                application_id=FAKE_APP_ID,
                url="https://evil.com/hook",
                events=["user.registered"],
                policy_mode="allowlist",
                allowed_domains=("example.com", "partner.com"),
            )

        assert "not in allowed domains" in str(exc.value).lower()

    @patch("socket.getaddrinfo", return_value=[(2, 1, 6, "", ("93.184.216.34", 443))])
    async def test_allowlist_mode_with_empty_allowlist_denies_all(self, _mock_dns):
        """When policy_mode='allowlist' but allowed_domains is empty, all domains are denied."""
        from spaps_server_quickstart.domains.webhooks.errors import WebhookDestinationNotAllowedError

        db = AsyncMock()

        with pytest.raises(WebhookDestinationNotAllowedError):
            await create_webhook(
                db,
                application_id=FAKE_APP_ID,
                url="https://example.com/hook",
                events=["user.registered"],
                policy_mode="allowlist",
                allowed_domains=(),
            )

    @patch("socket.getaddrinfo", return_value=[(2, 1, 6, "", ("93.184.216.34", 443))])
    @patch(f"{_REPO}.update_webhook", new_callable=AsyncMock)
    async def test_update_webhook_enforces_governance(self, mock_update, _mock_dns):
        """update_webhook also enforces destination governance when URL is updated."""
        from spaps_server_quickstart.domains.webhooks.errors import WebhookDestinationNotAllowedError

        db = AsyncMock()

        # Governance should be checked on update
        with pytest.raises(WebhookDestinationNotAllowedError):
            await update_webhook(
                db,
                webhook_id=FAKE_WEBHOOK_ID,
                application_id=FAKE_APP_ID,
                url="https://evil.com/new-hook",
                policy_mode="allowlist",
                allowed_domains=("example.com",),
            )

        mock_update.assert_not_called()

    @patch("socket.getaddrinfo", return_value=[(2, 1, 6, "", ("93.184.216.34", 443))])
    @patch(f"{_REPO}.update_webhook", new_callable=AsyncMock)
    async def test_update_webhook_skips_governance_when_url_not_changed(
        self, mock_update, _mock_dns
    ):
        """update_webhook skips governance check when URL is not being updated."""
        mock_update.return_value = _make_webhook()
        db = AsyncMock()

        # No URL in update, so governance is skipped
        result = await update_webhook(
            db,
            webhook_id=FAKE_WEBHOOK_ID,
            application_id=FAKE_APP_ID,
            is_active=False,
            policy_mode="allowlist",
            allowed_domains=("example.com",),
        )

        assert result["webhook"] is not None
        mock_update.assert_called_once()
