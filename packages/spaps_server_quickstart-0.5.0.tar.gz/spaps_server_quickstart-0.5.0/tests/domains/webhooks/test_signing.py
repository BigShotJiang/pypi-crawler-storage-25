"""Unit tests for webhook HMAC-SHA256 signing and verification."""

from __future__ import annotations

import hashlib
import hmac
import time


from spaps_server_quickstart.domains.webhooks.signing import (
    MAX_TIMESTAMP_AGE_SECONDS,
    build_signature_header,
    compute_signature,
    verify_mailgun_signature,
    verify_signature,
)


class TestComputeSignature:
    def test_deterministic(self):
        """Same inputs produce the same signature."""
        sig1 = compute_signature(timestamp=1000, body='{"a":1}', secret="sec")
        sig2 = compute_signature(timestamp=1000, body='{"a":1}', secret="sec")
        assert sig1 == sig2

    def test_different_body_different_sig(self):
        """Different bodies produce different signatures."""
        sig1 = compute_signature(timestamp=1000, body='{"a":1}', secret="sec")
        sig2 = compute_signature(timestamp=1000, body='{"b":2}', secret="sec")
        assert sig1 != sig2

    def test_different_secret_different_sig(self):
        """Different secrets produce different signatures."""
        sig1 = compute_signature(timestamp=1000, body='{"a":1}', secret="sec1")
        sig2 = compute_signature(timestamp=1000, body='{"a":1}', secret="sec2")
        assert sig1 != sig2

    def test_different_timestamp_different_sig(self):
        """Different timestamps produce different signatures."""
        sig1 = compute_signature(timestamp=1000, body='{"a":1}', secret="sec")
        sig2 = compute_signature(timestamp=2000, body='{"a":1}', secret="sec")
        assert sig1 != sig2

    def test_format_is_hex(self):
        """Signature is a 64-char hex string."""
        sig = compute_signature(timestamp=1000, body='{"a":1}', secret="sec")
        assert len(sig) == 64
        assert all(c in "0123456789abcdef" for c in sig)

    def test_matches_manual_hmac(self):
        """Signature matches manually computed HMAC-SHA256."""
        ts = 1234567890
        body = '{"hello":"world"}'
        secret = "test-secret"
        message = f"{ts}.{body}"
        expected = hmac.new(
            secret.encode("utf-8"),
            message.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()
        assert compute_signature(timestamp=ts, body=body, secret=secret) == expected


class TestBuildSignatureHeader:
    def test_format(self):
        """Header value has correct t=...,v1=... format."""
        header = build_signature_header(
            timestamp=1000, body='{"a":1}', secret="sec"
        )
        assert header.startswith("t=1000,v1=")
        parts = header.split(",")
        assert len(parts) == 2
        assert parts[0] == "t=1000"
        assert parts[1].startswith("v1=")
        assert len(parts[1]) == 3 + 64  # "v1=" + 64 hex chars


class TestVerifySignature:
    def test_valid_signature(self):
        """A freshly generated signature verifies successfully."""
        ts = int(time.time())
        body = '{"event":"test"}'
        secret = "my-secret"

        header = build_signature_header(timestamp=ts, body=body, secret=secret)
        assert verify_signature(header=header, body=body, secret=secret) is True

    def test_wrong_secret_fails(self):
        """Verification fails with wrong secret."""
        ts = int(time.time())
        body = '{"event":"test"}'

        header = build_signature_header(
            timestamp=ts, body=body, secret="correct-secret"
        )
        assert (
            verify_signature(
                header=header, body=body, secret="wrong-secret"
            )
            is False
        )

    def test_tampered_body_fails(self):
        """Verification fails when body has been modified."""
        ts = int(time.time())
        original_body = '{"event":"test"}'
        secret = "my-secret"

        header = build_signature_header(
            timestamp=ts, body=original_body, secret=secret
        )
        tampered_body = '{"event":"hacked"}'
        assert (
            verify_signature(header=header, body=tampered_body, secret=secret)
            is False
        )

    def test_expired_timestamp_fails(self):
        """Verification fails when timestamp is too old."""
        old_ts = int(time.time()) - MAX_TIMESTAMP_AGE_SECONDS - 10
        body = '{"event":"test"}'
        secret = "my-secret"

        header = build_signature_header(
            timestamp=old_ts, body=body, secret=secret
        )
        assert (
            verify_signature(header=header, body=body, secret=secret) is False
        )

    def test_future_timestamp_fails(self):
        """Verification fails when timestamp is too far in the future."""
        future_ts = int(time.time()) + MAX_TIMESTAMP_AGE_SECONDS + 10
        body = '{"event":"test"}'
        secret = "my-secret"

        header = build_signature_header(
            timestamp=future_ts, body=body, secret=secret
        )
        assert (
            verify_signature(header=header, body=body, secret=secret) is False
        )

    def test_malformed_header_fails(self):
        """Verification fails with malformed header."""
        assert (
            verify_signature(
                header="bad-header", body="{}", secret="sec"
            )
            is False
        )

    def test_empty_header_fails(self):
        """Verification fails with empty header."""
        assert (
            verify_signature(header="", body="{}", secret="sec") is False
        )

    def test_missing_v1_fails(self):
        """Verification fails with header missing v1 component."""
        assert (
            verify_signature(header="t=1000", body="{}", secret="sec")
            is False
        )

    def test_with_override_current_time(self):
        """Verification works with overridden current time."""
        ts = 1000
        body = '{"a":1}'
        secret = "sec"

        header = build_signature_header(timestamp=ts, body=body, secret=secret)

        # Within window
        assert (
            verify_signature(
                header=header, body=body, secret=secret, current_time=1100
            )
            is True
        )

        # Outside window
        assert (
            verify_signature(
                header=header, body=body, secret=secret, current_time=2000
            )
            is False
        )

    def test_boundary_timestamp_accepted(self):
        """Timestamp exactly at MAX_TIMESTAMP_AGE_SECONDS is accepted."""
        body = '{"a":1}'
        secret = "sec"
        ts = 1000
        boundary_time = ts + MAX_TIMESTAMP_AGE_SECONDS

        header = build_signature_header(timestamp=ts, body=body, secret=secret)
        assert (
            verify_signature(
                header=header,
                body=body,
                secret=secret,
                current_time=boundary_time,
            )
            is True
        )

    def test_boundary_plus_one_rejected(self):
        """Timestamp one second past MAX_TIMESTAMP_AGE_SECONDS is rejected."""
        body = '{"a":1}'
        secret = "sec"
        ts = 1000
        past_boundary = ts + MAX_TIMESTAMP_AGE_SECONDS + 1

        header = build_signature_header(timestamp=ts, body=body, secret=secret)
        assert (
            verify_signature(
                header=header,
                body=body,
                secret=secret,
                current_time=past_boundary,
            )
            is False
        )


class TestVerifyMailgunSignature:
    def test_valid_signature(self):
        """Valid Mailgun signature verifies."""
        signing_key = "mailgun-key"
        timestamp = "1234567890"
        token = "abc123token"
        message = f"{timestamp}{token}"
        signature = hmac.new(
            signing_key.encode("utf-8"),
            message.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()

        assert (
            verify_mailgun_signature(
                signing_key=signing_key,
                timestamp=timestamp,
                token=token,
                signature=signature,
            )
            is True
        )

    def test_wrong_key_fails(self):
        """Mailgun verification fails with wrong key."""
        signing_key = "correct-key"
        timestamp = "1234567890"
        token = "abc123token"
        message = f"{timestamp}{token}"
        signature = hmac.new(
            signing_key.encode("utf-8"),
            message.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()

        assert (
            verify_mailgun_signature(
                signing_key="wrong-key",
                timestamp=timestamp,
                token=token,
                signature=signature,
            )
            is False
        )

    def test_tampered_signature_fails(self):
        """Mailgun verification fails with tampered signature."""
        assert (
            verify_mailgun_signature(
                signing_key="key",
                timestamp="123",
                token="tok",
                signature="0" * 64,
            )
            is False
        )
