"""Unit tests for the webhooks domain repository layer.

Tests repository functions with mocked AsyncSession.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

from spaps_server_quickstart.domains.webhooks import repository as repo
from spaps_server_quickstart.domains.webhooks.models import (
    Webhook,
    WebhookDelivery,
    WebhookEvent,
)


FAKE_APP_ID = uuid4()
FAKE_WEBHOOK_ID = uuid4()


def _mock_db():
    """Create a mocked AsyncSession."""
    db = AsyncMock()
    db.add = MagicMock()  # add() is synchronous in SQLAlchemy
    db.flush = AsyncMock()
    db.refresh = AsyncMock()
    db.delete = AsyncMock()
    return db


# ===========================================================================
# Webhook Lookups
# ===========================================================================


class TestGetWebhookById:
    async def test_found(self):
        """get_webhook_by_id returns webhook when found."""
        webhook = MagicMock(spec=Webhook)
        webhook.id = FAKE_WEBHOOK_ID
        webhook.application_id = FAKE_APP_ID

        db = _mock_db()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = webhook
        db.execute = AsyncMock(return_value=result_mock)

        result = await repo.get_webhook_by_id(db, FAKE_WEBHOOK_ID, FAKE_APP_ID)

        assert result is webhook
        db.execute.assert_called_once()

    async def test_not_found(self):
        """get_webhook_by_id returns None when not found."""
        db = _mock_db()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute = AsyncMock(return_value=result_mock)

        result = await repo.get_webhook_by_id(db, uuid4(), FAKE_APP_ID)

        assert result is None

    async def test_scoped_to_application(self):
        """get_webhook_by_id filters by application_id."""
        db = _mock_db()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute = AsyncMock(return_value=result_mock)

        # Webhook exists but belongs to different app
        result = await repo.get_webhook_by_id(db, FAKE_WEBHOOK_ID, uuid4())

        assert result is None


class TestListWebhooks:
    async def test_returns_all_for_application(self):
        """list_webhooks returns all webhooks for an application."""
        webhook1 = MagicMock(spec=Webhook)
        webhook2 = MagicMock(spec=Webhook)

        db = _mock_db()
        scalars_mock = MagicMock()
        scalars_mock.all.return_value = [webhook1, webhook2]
        result_mock = MagicMock()
        result_mock.scalars.return_value = scalars_mock
        db.execute = AsyncMock(return_value=result_mock)

        result = await repo.list_webhooks(db, FAKE_APP_ID)

        assert len(result) == 2
        db.execute.assert_called_once()

    async def test_empty_list(self):
        """list_webhooks returns empty list when no webhooks."""
        db = _mock_db()
        scalars_mock = MagicMock()
        scalars_mock.all.return_value = []
        result_mock = MagicMock()
        result_mock.scalars.return_value = scalars_mock
        db.execute = AsyncMock(return_value=result_mock)

        result = await repo.list_webhooks(db, FAKE_APP_ID)

        assert result == []


class TestFindActiveWebhooksForEvent:
    async def test_finds_matching_webhooks(self):
        """find_active_webhooks_for_event finds webhooks subscribed to event."""
        webhook = MagicMock(spec=Webhook)
        webhook.events = ["user.registered", "user.updated"]
        webhook.is_active = True

        db = _mock_db()
        scalars_mock = MagicMock()
        scalars_mock.all.return_value = [webhook]
        result_mock = MagicMock()
        result_mock.scalars.return_value = scalars_mock
        db.execute = AsyncMock(return_value=result_mock)

        result = await repo.find_active_webhooks_for_event(
            db, FAKE_APP_ID, "user.registered"
        )

        assert len(result) == 1
        assert result[0] is webhook

    async def test_filters_inactive_webhooks(self):
        """find_active_webhooks_for_event excludes inactive webhooks."""
        db = _mock_db()
        scalars_mock = MagicMock()
        scalars_mock.all.return_value = []
        result_mock = MagicMock()
        result_mock.scalars.return_value = scalars_mock
        db.execute = AsyncMock(return_value=result_mock)

        result = await repo.find_active_webhooks_for_event(
            db, FAKE_APP_ID, "user.registered"
        )

        assert result == []

    async def test_no_match_for_event(self):
        """find_active_webhooks_for_event returns empty for unsubscribed event."""
        db = _mock_db()
        scalars_mock = MagicMock()
        scalars_mock.all.return_value = []
        result_mock = MagicMock()
        result_mock.scalars.return_value = scalars_mock
        db.execute = AsyncMock(return_value=result_mock)

        result = await repo.find_active_webhooks_for_event(
            db, FAKE_APP_ID, "unsubscribed.event"
        )

        assert result == []


# ===========================================================================
# Webhook Mutations
# ===========================================================================


class TestCreateWebhook:
    async def test_creates_and_returns(self):
        """create_webhook adds webhook to session and returns it."""
        db = _mock_db()

        result = await repo.create_webhook(
            db,
            application_id=FAKE_APP_ID,
            url="https://example.com/webhook",
            secret="a" * 64,
            events=["user.registered"],
        )

        assert result is not None
        assert isinstance(result, Webhook)
        db.add.assert_called_once()
        db.flush.assert_called_once()
        db.refresh.assert_called_once()


class TestUpdateWebhook:
    async def test_updates_existing(self):
        """update_webhook modifies existing webhook."""
        webhook = MagicMock(spec=Webhook)
        webhook.id = FAKE_WEBHOOK_ID
        webhook.url = "https://old.com/hook"

        db = _mock_db()
        with patch.object(repo, "get_webhook_by_id", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = webhook
            result = await repo.update_webhook(
                db,
                FAKE_WEBHOOK_ID,
                FAKE_APP_ID,
                url="https://new.com/hook",
                is_active=False,
            )

            assert result is webhook
            db.flush.assert_called_once()
            db.refresh.assert_called_once()

    async def test_returns_none_if_not_found(self):
        """update_webhook returns None if webhook doesn't exist."""
        db = _mock_db()
        with patch.object(repo, "get_webhook_by_id", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = None
            result = await repo.update_webhook(
                db, uuid4(), FAKE_APP_ID, url="https://new.com"
            )

            assert result is None


class TestDeleteWebhook:
    async def test_deletes_existing(self):
        """delete_webhook removes webhook from database."""
        webhook = MagicMock(spec=Webhook)
        webhook.id = FAKE_WEBHOOK_ID

        db = _mock_db()
        with patch.object(repo, "get_webhook_by_id", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = webhook
            result = await repo.delete_webhook(db, FAKE_WEBHOOK_ID, FAKE_APP_ID)

            assert result is True
            db.delete.assert_called_once_with(webhook)
            db.flush.assert_called_once()

    async def test_returns_false_if_not_found(self):
        """delete_webhook returns False if webhook doesn't exist."""
        db = _mock_db()
        with patch.object(repo, "get_webhook_by_id", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = None
            result = await repo.delete_webhook(db, uuid4(), FAKE_APP_ID)

            assert result is False
            db.delete.assert_not_called()


# ===========================================================================
# Webhook Events
# ===========================================================================


class TestWebhookEvents:
    async def test_create_event(self):
        """create_webhook_event inserts event and returns it."""
        db = _mock_db()

        result = await repo.create_webhook_event(
            db,
            application_id=FAKE_APP_ID,
            type="user.registered",
            data={"user_id": str(uuid4())},
        )

        assert result is not None
        assert isinstance(result, WebhookEvent)
        db.add.assert_called_once()
        db.flush.assert_called_once()
        db.refresh.assert_called_once()


# ===========================================================================
# Webhook Deliveries
# ===========================================================================


class TestWebhookDeliveries:
    async def test_create_delivery(self):
        """create_delivery inserts delivery record."""
        db = _mock_db()

        result = await repo.create_delivery(
            db,
            webhook_id=FAKE_WEBHOOK_ID,
            event_type="user.registered",
            payload={"user_id": str(uuid4())},
            response_status=200,
        )

        assert result is not None
        assert isinstance(result, WebhookDelivery)
        db.add.assert_called_once()
        db.flush.assert_called_once()

    async def test_update_delivery(self):
        """update_delivery modifies delivery record."""
        delivery = MagicMock(spec=WebhookDelivery)
        delivery.id = uuid4()
        delivery.response_status = None

        db = _mock_db()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = delivery
        db.execute = AsyncMock(return_value=result_mock)

        result = await repo.update_delivery(
            db,
            delivery.id,
            response_status=200,
            response_body="OK",
        )

        assert result is delivery
        db.flush.assert_called_once()
        db.refresh.assert_called_once()

    async def test_update_delivery_not_found(self):
        """update_delivery returns None if delivery doesn't exist."""
        db = _mock_db()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute = AsyncMock(return_value=result_mock)

        result = await repo.update_delivery(db, uuid4(), response_status=500)

        assert result is None

    async def test_list_deliveries(self):
        """list_deliveries returns deliveries for a webhook."""
        delivery1 = MagicMock(spec=WebhookDelivery)
        delivery2 = MagicMock(spec=WebhookDelivery)

        db = _mock_db()
        scalars_mock = MagicMock()
        scalars_mock.all.return_value = [delivery1, delivery2]
        result_mock = MagicMock()
        result_mock.scalars.return_value = scalars_mock
        db.execute = AsyncMock(return_value=result_mock)

        result = await repo.list_deliveries(db, FAKE_WEBHOOK_ID, limit=100)

        assert len(result) == 2
        db.execute.assert_called_once()

    async def test_list_deliveries_empty(self):
        """list_deliveries returns empty list when no deliveries."""
        db = _mock_db()
        scalars_mock = MagicMock()
        scalars_mock.all.return_value = []
        result_mock = MagicMock()
        result_mock.scalars.return_value = scalars_mock
        db.execute = AsyncMock(return_value=result_mock)

        result = await repo.list_deliveries(db, FAKE_WEBHOOK_ID)

        assert result == []

    async def test_list_deliveries_respects_limit(self):
        """list_deliveries respects the limit parameter."""
        deliveries = [MagicMock(spec=WebhookDelivery) for _ in range(50)]

        db = _mock_db()
        scalars_mock = MagicMock()
        scalars_mock.all.return_value = deliveries
        result_mock = MagicMock()
        result_mock.scalars.return_value = scalars_mock
        db.execute = AsyncMock(return_value=result_mock)

        result = await repo.list_deliveries(db, FAKE_WEBHOOK_ID, limit=50)

        assert len(result) == 50
