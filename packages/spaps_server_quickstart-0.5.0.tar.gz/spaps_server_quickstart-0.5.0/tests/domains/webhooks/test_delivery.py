"""Unit tests for async webhook delivery with exponential backoff retry."""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest

from spaps_server_quickstart.domains.webhooks.delivery import (
    DEFAULT_INITIAL_DELAY_MS,
    DEFAULT_MAX_DELAY_MS,
    _build_delivery_envelope,
    _build_delivery_headers,
    _calculate_delay_ms,
    _should_retry,
    deliver_webhook,
)


@pytest.fixture
def mock_public_dns():
    with patch(
        "socket.getaddrinfo",
        return_value=[(2, 1, 6, "", ("93.184.216.34", 443))],
    ):
        yield


class TestBuildDeliveryEnvelope:
    def test_envelope_structure(self):
        """Envelope has all required fields."""
        envelope = _build_delivery_envelope(
            event_id="evt-1",
            event_type="user.registered",
            schema_version=1,
            application_id="app-1",
            created_at="2024-01-01T00:00:00Z",
            data={"user_id": "u-1"},
        )

        assert envelope["id"] == "evt-1"
        assert envelope["type"] == "user.registered"
        assert envelope["schema_version"] == 1
        assert envelope["application_id"] == "app-1"
        assert envelope["created_at"] == "2024-01-01T00:00:00Z"
        assert envelope["data"] == {"user_id": "u-1"}

    def test_envelope_has_exactly_six_keys(self):
        """Envelope contains exactly the specified keys."""
        envelope = _build_delivery_envelope(
            event_id="e",
            event_type="t",
            schema_version=1,
            application_id="a",
            created_at="c",
            data={},
        )
        assert set(envelope.keys()) == {
            "id",
            "type",
            "schema_version",
            "application_id",
            "created_at",
            "data",
        }


class TestBuildDeliveryHeaders:
    def test_standard_headers(self):
        """Standard headers are present."""
        headers = _build_delivery_headers(
            event_id="evt-1",
            signature_header="t=123,v1=abc",
            timestamp_iso="2024-01-01T00:00:00Z",
        )

        assert headers["Content-Type"] == "application/json"
        assert headers["X-Webhook-Id"] == "evt-1"
        assert headers["X-SPAPS-Signature"] == "t=123,v1=abc"
        assert headers["X-Webhook-Timestamp"] == "2024-01-01T00:00:00Z"

    def test_custom_headers_merged(self):
        """Custom headers from webhook config are included."""
        headers = _build_delivery_headers(
            event_id="evt-1",
            signature_header="t=123,v1=abc",
            timestamp_iso="2024-01-01T00:00:00Z",
            custom_headers={"X-Custom": "value"},
        )

        assert headers["X-Custom"] == "value"
        assert headers["Content-Type"] == "application/json"

    def test_no_custom_headers(self):
        """Works correctly without custom headers."""
        headers = _build_delivery_headers(
            event_id="evt-1",
            signature_header="sig",
            timestamp_iso="ts",
            custom_headers=None,
        )

        assert "X-Custom" not in headers
        assert len(headers) == 4


class TestCalculateDelayMs:
    def test_first_retry(self):
        """First retry uses initial delay."""
        assert _calculate_delay_ms(1) == DEFAULT_INITIAL_DELAY_MS

    def test_second_retry(self):
        """Second retry doubles the initial delay."""
        assert _calculate_delay_ms(2) == DEFAULT_INITIAL_DELAY_MS * 2

    def test_capped_at_max(self):
        """Delay is capped at max_delay_ms."""
        # With default initial=1000 and max=10000:
        # attempt 4: 1000 * 2^3 = 8000
        # attempt 5: 1000 * 2^4 = 16000 -> capped to 10000
        assert _calculate_delay_ms(5) == DEFAULT_MAX_DELAY_MS

    def test_custom_delays(self):
        """Custom initial and max delays work correctly."""
        assert _calculate_delay_ms(1, initial_delay_ms=500, max_delay_ms=2000) == 500
        assert _calculate_delay_ms(2, initial_delay_ms=500, max_delay_ms=2000) == 1000
        assert _calculate_delay_ms(3, initial_delay_ms=500, max_delay_ms=2000) == 2000
        assert _calculate_delay_ms(4, initial_delay_ms=500, max_delay_ms=2000) == 2000


class TestShouldRetry:
    def test_network_error_retries(self):
        """Network errors (None status) should retry."""
        assert _should_retry(None) is True

    def test_5xx_retries(self):
        """5xx status codes should retry."""
        assert _should_retry(500) is True
        assert _should_retry(502) is True
        assert _should_retry(503) is True

    def test_4xx_does_not_retry(self):
        """4xx status codes should NOT retry."""
        assert _should_retry(400) is False
        assert _should_retry(401) is False
        assert _should_retry(403) is False
        assert _should_retry(404) is False
        assert _should_retry(422) is False

    def test_2xx_does_not_retry(self):
        """2xx status codes should NOT retry (already success)."""
        assert _should_retry(200) is False
        assert _should_retry(201) is False

    def test_3xx_does_not_retry(self):
        """3xx status codes should NOT retry."""
        assert _should_retry(301) is False
        assert _should_retry(302) is False


class TestDeliverWebhook:
    """Tests for the deliver_webhook async function."""

    @pytest.fixture
    def base_kwargs(self):
        return {
            "webhook_url": "https://example.com/webhook",
            "webhook_secret": "test-secret",
            "event_id": "evt-1",
            "event_type": "user.registered",
            "schema_version": 1,
            "application_id": "app-1",
            "created_at": "2024-01-01T00:00:00Z",
            "data": {"user_id": "u-1"},
        }

    @patch("spaps_server_quickstart.domains.webhooks.delivery.httpx.AsyncClient")
    async def test_success_on_first_attempt(self, mock_client_cls, base_kwargs, mock_public_dns):
        """Successful delivery returns after first attempt."""
        mock_response = AsyncMock()
        mock_response.status_code = 200
        mock_response.text = "OK"

        mock_client = AsyncMock()
        mock_client.post.return_value = mock_response
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client_cls.return_value = mock_client

        attempts = await deliver_webhook(**base_kwargs, max_attempts=3)

        assert len(attempts) == 1
        assert attempts[0]["attempt"] == 1
        assert attempts[0]["response_status"] == 200
        assert attempts[0]["error_message"] is None

    @patch("spaps_server_quickstart.domains.webhooks.delivery.httpx.AsyncClient")
    async def test_blocks_http_scheme_in_production(self, mock_client_cls, base_kwargs):
        """Production delivery blocks http:// URLs (plaintext transport)."""
        kwargs = dict(base_kwargs)
        kwargs["webhook_url"] = "http://example.com/webhook"

        attempts = await deliver_webhook(**kwargs, environment="production")

        assert len(attempts) == 1
        assert attempts[0]["response_status"] is None
        assert "https" in (attempts[0]["error_message"] or "").lower()
        mock_client_cls.assert_not_called()

    @patch("socket.getaddrinfo", return_value=[(2, 1, 6, "", ("127.0.0.1", 443))])
    @patch("spaps_server_quickstart.domains.webhooks.delivery.httpx.AsyncClient")
    async def test_blocks_private_ip_ssrf(self, mock_client_cls, _mock_dns, base_kwargs):
        """Delivery blocks DNS destinations that resolve to private/loopback IPs (SSRF)."""
        kwargs = dict(base_kwargs)
        kwargs["webhook_url"] = "https://evil.example/webhook"
        attempts = await deliver_webhook(**kwargs, max_attempts=3)

        assert len(attempts) == 1
        assert attempts[0]["response_status"] is None
        assert attempts[0]["delivered_at"] is None
        assert "Blocked" in (attempts[0]["error_message"] or "")

        # Should fail before attempting any outbound HTTP.
        mock_client_cls.assert_not_called()

    @patch("spaps_server_quickstart.domains.webhooks.delivery.httpx.AsyncClient")
    async def test_4xx_no_retry(self, mock_client_cls, base_kwargs, mock_public_dns):
        """4xx responses are not retried."""
        mock_response = AsyncMock()
        mock_response.status_code = 400
        mock_response.text = "Bad Request"

        mock_client = AsyncMock()
        mock_client.post.return_value = mock_response
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client_cls.return_value = mock_client

        attempts = await deliver_webhook(**base_kwargs, max_attempts=3)

        assert len(attempts) == 1
        assert attempts[0]["response_status"] == 400
        assert "Client error" in attempts[0]["error_message"]

    @patch("spaps_server_quickstart.domains.webhooks.delivery.asyncio.sleep", new_callable=AsyncMock)
    @patch("spaps_server_quickstart.domains.webhooks.delivery.httpx.AsyncClient")
    async def test_5xx_retries_and_succeeds(
        self, mock_client_cls, mock_sleep, base_kwargs, mock_public_dns
    ):
        """5xx on first attempt, success on second attempt."""
        fail_response = AsyncMock()
        fail_response.status_code = 500
        fail_response.text = "Internal Server Error"

        ok_response = AsyncMock()
        ok_response.status_code = 200
        ok_response.text = "OK"

        mock_client = AsyncMock()
        mock_client.post.side_effect = [fail_response, ok_response]
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client_cls.return_value = mock_client

        attempts = await deliver_webhook(**base_kwargs, max_attempts=3)

        assert len(attempts) == 2
        assert attempts[0]["response_status"] == 500
        assert attempts[1]["response_status"] == 200
        mock_sleep.assert_called_once()

    @patch("spaps_server_quickstart.domains.webhooks.delivery.asyncio.sleep", new_callable=AsyncMock)
    @patch("spaps_server_quickstart.domains.webhooks.delivery.httpx.AsyncClient")
    async def test_all_attempts_fail(
        self, mock_client_cls, mock_sleep, base_kwargs, mock_public_dns
    ):
        """All attempts fail with 5xx."""
        fail_response = AsyncMock()
        fail_response.status_code = 502
        fail_response.text = "Bad Gateway"

        mock_client = AsyncMock()
        mock_client.post.return_value = fail_response
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client_cls.return_value = mock_client

        attempts = await deliver_webhook(**base_kwargs, max_attempts=3)

        assert len(attempts) == 3
        assert all(a["response_status"] == 502 for a in attempts)
        # 2 sleep calls (between attempt 1-2 and 2-3)
        assert mock_sleep.call_count == 2

    @patch("spaps_server_quickstart.domains.webhooks.delivery.asyncio.sleep", new_callable=AsyncMock)
    @patch("spaps_server_quickstart.domains.webhooks.delivery.httpx.AsyncClient")
    async def test_network_error_retries(
        self, mock_client_cls, mock_sleep, base_kwargs, mock_public_dns
    ):
        """Network errors trigger retries."""
        ok_response = AsyncMock()
        ok_response.status_code = 200
        ok_response.text = "OK"

        mock_client = AsyncMock()
        mock_client.post.side_effect = [
            ConnectionError("Connection refused"),
            ok_response,
        ]
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client_cls.return_value = mock_client

        attempts = await deliver_webhook(**base_kwargs, max_attempts=3)

        assert len(attempts) == 2
        assert attempts[0]["response_status"] is None
        assert "Network error" in attempts[0]["error_message"]
        assert attempts[1]["response_status"] == 200

    @patch("spaps_server_quickstart.domains.webhooks.delivery.httpx.AsyncClient")
    async def test_response_body_truncated(self, mock_client_cls, base_kwargs, mock_public_dns):
        """Response body is truncated to 2000 chars."""
        mock_response = AsyncMock()
        mock_response.status_code = 200
        mock_response.text = "x" * 5000

        mock_client = AsyncMock()
        mock_client.post.return_value = mock_response
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client_cls.return_value = mock_client

        attempts = await deliver_webhook(**base_kwargs)

        assert len(attempts[0]["response_body"]) == 2000

    @patch("spaps_server_quickstart.domains.webhooks.delivery.httpx.AsyncClient")
    async def test_payload_is_signed(self, mock_client_cls, base_kwargs, mock_public_dns):
        """The POST request includes X-SPAPS-Signature header."""
        mock_response = AsyncMock()
        mock_response.status_code = 200
        mock_response.text = "OK"

        mock_client = AsyncMock()
        mock_client.post.return_value = mock_response
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client_cls.return_value = mock_client

        await deliver_webhook(**base_kwargs)

        call_kwargs = mock_client.post.call_args
        headers = call_kwargs.kwargs.get("headers", {})
        assert "X-SPAPS-Signature" in headers
        sig = headers["X-SPAPS-Signature"]
        assert sig.startswith("t=")
        assert ",v1=" in sig

    @patch("spaps_server_quickstart.domains.webhooks.delivery.httpx.AsyncClient")
    async def test_custom_headers_included(self, mock_client_cls, base_kwargs, mock_public_dns):
        """Custom headers from webhook config are sent."""
        mock_response = AsyncMock()
        mock_response.status_code = 200
        mock_response.text = "OK"

        mock_client = AsyncMock()
        mock_client.post.return_value = mock_response
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client_cls.return_value = mock_client

        await deliver_webhook(
            **base_kwargs, custom_headers={"X-App": "myapp"}
        )

        call_kwargs = mock_client.post.call_args
        headers = call_kwargs.kwargs.get("headers", {})
        assert headers.get("X-App") == "myapp"


class TestDeliverWebhookEnvironmentGuard:
    """Tests for the environment guard on webhook delivery."""

    @pytest.fixture
    def base_kwargs(self):
        return {
            "webhook_url": "https://example.com/webhook",
            "webhook_secret": "test-secret",
            "event_id": "evt-1",
            "event_type": "user.registered",
            "schema_version": 1,
            "application_id": "app-1",
            "created_at": "2024-01-01T00:00:00Z",
            "data": {"user_id": "u-1"},
        }

    async def test_dev_environment_skips_delivery(self, base_kwargs):
        """Dev environment skips actual HTTP delivery."""
        attempts = await deliver_webhook(**base_kwargs, environment="development")

        assert len(attempts) == 1
        assert attempts[0]["response_status"] == 202
        assert attempts[0]["skipped"] is True
        assert attempts[0]["error_message"] is None

    async def test_test_environment_skips_delivery(self, base_kwargs):
        """Test environment skips actual HTTP delivery."""
        attempts = await deliver_webhook(**base_kwargs, environment="test")

        assert len(attempts) == 1
        assert attempts[0]["skipped"] is True

    async def test_dev_short_alias_skips_delivery(self, base_kwargs):
        """'dev' alias also skips delivery."""
        attempts = await deliver_webhook(**base_kwargs, environment="dev")

        assert len(attempts) == 1
        assert attempts[0]["skipped"] is True

    @patch("spaps_server_quickstart.domains.webhooks.delivery.httpx.AsyncClient")
    async def test_production_delivers_normally(self, mock_client_cls, base_kwargs, mock_public_dns):
        """Production environment delivers normally."""
        mock_response = AsyncMock()
        mock_response.status_code = 200
        mock_response.text = "OK"

        mock_client = AsyncMock()
        mock_client.post.return_value = mock_response
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client_cls.return_value = mock_client

        attempts = await deliver_webhook(**base_kwargs, environment="production")

        assert len(attempts) == 1
        assert attempts[0]["response_status"] == 200
        assert "skipped" not in attempts[0]
