"""API route tests for the affiliate_referrals domain.

These tests verify route wiring, error code to HTTP status mapping,
and auth requirement enforcement. Service logic is tested in test_service.py.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

from fastapi import FastAPI
from fastapi.testclient import TestClient

from spaps_server_quickstart.domains.affiliate_referrals.router import (
    affiliates_router,
    referrals_router,
    affiliate_admin_router,
    affiliate_config_router,
    internal_commissions_router,
)
from spaps_server_quickstart.domains.affiliate_referrals.errors import (
    AffiliateNotFoundError,
    SlugAlreadyExistsError,
    AffiliateAlreadyExistsError,
    ClickRateLimitedError,
    PayoutNotFoundError,
    InsufficientBalanceError,
    NotApplicationOwnerError,
)
from spaps_server_quickstart.middleware.error_handler import install_error_handlers

_SVC = "spaps_server_quickstart.domains.affiliate_referrals.router.service"

FAKE_APP_ID = str(uuid4())
FAKE_USER_ID = str(uuid4())
FAKE_AFFILIATE_ID = str(uuid4())


# ---------------------------------------------------------------------------
# Test app setup
# ---------------------------------------------------------------------------


def _make_test_app() -> FastAPI:
    app = FastAPI()
    install_error_handlers(app)

    settings = MagicMock()
    settings.jwt_secret = "test-secret"
    settings.internal_service_secret = "test-internal-secret"
    app.state.settings = settings

    app.include_router(affiliates_router, prefix="/api")
    app.include_router(referrals_router, prefix="/api")
    app.include_router(affiliate_admin_router, prefix="/api")
    app.include_router(affiliate_config_router, prefix="/api")
    app.include_router(internal_commissions_router, prefix="/api")
    return app


def _make_user(
    user_id: str = FAKE_USER_ID,
    is_admin: bool = False,
) -> MagicMock:
    user = MagicMock()
    user.id = user_id
    user.is_admin = is_admin
    user.is_super_admin = False
    return user


def _make_application(app_id: str = FAKE_APP_ID) -> MagicMock:
    app = MagicMock()
    app.id = app_id
    return app


# ---------------------------------------------------------------------------
# Dependency overrides
# ---------------------------------------------------------------------------

_DEPS_BASE = "spaps_server_quickstart.domains.affiliate_referrals.router"


def _override_deps(app: FastAPI, user=None, application=None):
    from spaps_server_quickstart.middleware.spaps_deps import (
        get_current_user,
        get_application,
        get_db_session,
        require_admin_user,
    )

    async def mock_db():
        yield AsyncMock()

    app.dependency_overrides[get_db_session] = mock_db
    app.dependency_overrides[get_application] = lambda: application or _make_application()
    app.dependency_overrides[get_current_user] = lambda: user or _make_user()
    app.dependency_overrides[require_admin_user] = lambda: user or _make_user(is_admin=True)


# ===========================================================================
# Affiliate registration
# ===========================================================================


class TestRegisterAffiliate:
    @patch(_SVC)
    def test_register_success(self, mock_svc):
        app = _make_test_app()
        _override_deps(app)
        mock_svc.register_affiliate = AsyncMock(return_value={
            "id": FAKE_AFFILIATE_ID,
            "slug": "test-bot",
            "affiliate_type": "user",
        })

        client = TestClient(app)
        resp = client.post("/api/affiliates", json={
            "slug": "test-bot",
            "affiliate_type": "user",
        })

        assert resp.status_code == 201

    @patch(_SVC)
    def test_register_slug_conflict(self, mock_svc):
        app = _make_test_app()
        _override_deps(app)
        mock_svc.register_affiliate = AsyncMock(side_effect=SlugAlreadyExistsError())

        client = TestClient(app)
        resp = client.post("/api/affiliates", json={
            "slug": "taken",
            "affiliate_type": "user",
        })

        assert resp.status_code == 409

    @patch(_SVC)
    def test_register_already_exists(self, mock_svc):
        app = _make_test_app()
        _override_deps(app)
        mock_svc.register_affiliate = AsyncMock(side_effect=AffiliateAlreadyExistsError())

        client = TestClient(app)
        resp = client.post("/api/affiliates", json={
            "slug": "new-slug",
            "affiliate_type": "user",
        })

        assert resp.status_code == 409

    @patch(_SVC)
    def test_register_invalid_wallet_address_fails_validation(self, mock_svc):
        app = _make_test_app()
        _override_deps(app)

        client = TestClient(app)
        resp = client.post("/api/affiliates", json={
            "slug": "test-bot",
            "affiliate_type": "user",
            "payout_wallet_address": "not-a-wallet",
            "payout_chain": "eip155:8453",
        })

        assert resp.status_code == 400
        assert resp.json()["error"]["code"] == "VALIDATION_ERROR"
        mock_svc.register_affiliate.assert_not_called()


# ===========================================================================
# Affiliate profile
# ===========================================================================


class TestAffiliateProfile:
    @patch(_SVC)
    def test_get_me(self, mock_svc):
        app = _make_test_app()
        _override_deps(app)
        mock_svc.get_my_affiliate = AsyncMock(return_value={
            "id": FAKE_AFFILIATE_ID,
            "slug": "test-bot",
        })

        client = TestClient(app)
        resp = client.get("/api/affiliates/me")

        assert resp.status_code == 200

    @patch(_SVC)
    def test_get_me_not_found(self, mock_svc):
        app = _make_test_app()
        _override_deps(app)
        mock_svc.get_my_affiliate = AsyncMock(side_effect=AffiliateNotFoundError())

        client = TestClient(app)
        resp = client.get("/api/affiliates/me")

        assert resp.status_code == 404

    @patch(_SVC)
    def test_update_me(self, mock_svc):
        app = _make_test_app()
        _override_deps(app)
        mock_svc.update_my_affiliate = AsyncMock(return_value={
            "id": FAKE_AFFILIATE_ID,
            "slug": "new-slug",
        })

        client = TestClient(app)
        resp = client.put("/api/affiliates/me", json={"slug": "new-slug"})

        assert resp.status_code == 200


# ===========================================================================
# Referral click
# ===========================================================================


class TestReferralClick:
    @patch(_SVC)
    def test_record_click(self, mock_svc):
        app = _make_test_app()
        _override_deps(app)
        mock_svc.record_click = AsyncMock(return_value={
            "click_id": str(uuid4()),
            "affiliate_slug": "test-bot",
            "expires_at": "2026-03-13T00:00:00+00:00",
        })

        client = TestClient(app)
        resp = client.post("/api/referrals/click", json={
            "slug": "test-bot",
            "application_id": FAKE_APP_ID,
        })

        assert resp.status_code == 201

    @patch(_SVC)
    def test_record_click_rate_limited(self, mock_svc):
        app = _make_test_app()
        _override_deps(app)
        mock_svc.record_click = AsyncMock(side_effect=ClickRateLimitedError())

        client = TestClient(app)
        resp = client.post("/api/referrals/click", json={
            "slug": "test-bot",
            "application_id": FAKE_APP_ID,
        })

        assert resp.status_code == 429

    @patch(_SVC)
    def test_record_click_application_mismatch_returns_400(self, mock_svc):
        app = _make_test_app()
        _override_deps(app, application=_make_application())

        client = TestClient(app)
        resp = client.post("/api/referrals/click", json={
            "slug": "test-bot",
            "application_id": str(uuid4()),
        })

        assert resp.status_code == 400
        body = resp.json()
        assert body["error"]["code"] == "VALIDATION_ERROR"
        mock_svc.record_click.assert_not_called()


# ===========================================================================
# Commissions / referrals / tree
# ===========================================================================


class TestEarnings:
    @patch(_SVC)
    def test_get_commissions(self, mock_svc):
        app = _make_test_app()
        _override_deps(app)
        mock_svc.get_commissions = AsyncMock(return_value={
            "commissions": [],
            "total": 0,
            "summary": {"total_earned_cents": 0, "by_level": {}},
        })

        client = TestClient(app)
        resp = client.get("/api/affiliates/me/commissions")

        assert resp.status_code == 200

    @patch(_SVC)
    def test_get_referrals(self, mock_svc):
        app = _make_test_app()
        _override_deps(app)
        mock_svc.get_my_referrals = AsyncMock(return_value={
            "referrals": [],
            "total": 0,
        })

        client = TestClient(app)
        resp = client.get("/api/affiliates/me/referrals")

        assert resp.status_code == 200

    @patch(_SVC)
    def test_get_tree(self, mock_svc):
        app = _make_test_app()
        _override_deps(app)
        mock_svc.get_referral_tree = AsyncMock(return_value={
            "levels": [],
            "totals": {"referral_count": 0, "total_earned_cents": 0},
        })

        client = TestClient(app)
        resp = client.get("/api/affiliates/me/tree")

        assert resp.status_code == 200


# ===========================================================================
# Payouts
# ===========================================================================


class TestPayouts:
    @patch(_SVC)
    def test_request_payout(self, mock_svc):
        app = _make_test_app()
        _override_deps(app)
        mock_svc.request_payout = AsyncMock(return_value={
            "id": str(uuid4()),
            "status": "requested",
        })

        client = TestClient(app)
        resp = client.post("/api/affiliates/me/payouts", json={
            "amount_cents": 5000,
        })

        assert resp.status_code == 201

    @patch(_SVC)
    def test_request_payout_insufficient_balance(self, mock_svc):
        app = _make_test_app()
        _override_deps(app)
        mock_svc.request_payout = AsyncMock(side_effect=InsufficientBalanceError())

        client = TestClient(app)
        resp = client.post("/api/affiliates/me/payouts", json={
            "amount_cents": 99999,
        })

        assert resp.status_code == 400

    @patch(_SVC)
    def test_get_payouts(self, mock_svc):
        app = _make_test_app()
        _override_deps(app)
        mock_svc.get_my_payouts = AsyncMock(return_value={
            "payouts": [],
            "total": 0,
        })

        client = TestClient(app)
        resp = client.get("/api/affiliates/me/payouts")

        assert resp.status_code == 200


# ===========================================================================
# Admin payout management
# ===========================================================================


class TestAdminPayouts:
    @patch(_SVC)
    def test_list_admin_payouts(self, mock_svc):
        app = _make_test_app()
        _override_deps(app, user=_make_user(is_admin=True))
        mock_svc.list_admin_payouts = AsyncMock(return_value={
            "payouts": [],
            "total": 0,
        })

        client = TestClient(app)
        resp = client.get("/api/admin/payouts")

        assert resp.status_code == 200

    @patch(_SVC)
    def test_approve_payout(self, mock_svc):
        app = _make_test_app()
        _override_deps(app, user=_make_user(is_admin=True))
        mock_svc.approve_payout = AsyncMock(return_value={
            "id": str(uuid4()),
            "status": "approved",
        })

        client = TestClient(app)
        resp = client.post(f"/api/admin/payouts/{uuid4()}/approve")

        assert resp.status_code == 200

    @patch(_SVC)
    def test_complete_payout(self, mock_svc):
        app = _make_test_app()
        _override_deps(app, user=_make_user(is_admin=True))
        mock_svc.complete_payout = AsyncMock(return_value={
            "id": str(uuid4()),
            "status": "completed",
            "tx_hash": "0xabc",
        })

        client = TestClient(app)
        resp = client.post(
            f"/api/admin/payouts/{uuid4()}/complete",
            json={"tx_hash": "0xabc"},
        )

        assert resp.status_code == 200

    @patch(_SVC)
    def test_deny_payout(self, mock_svc):
        app = _make_test_app()
        _override_deps(app, user=_make_user(is_admin=True))
        mock_svc.deny_payout = AsyncMock(return_value={
            "id": str(uuid4()),
            "status": "denied",
        })

        client = TestClient(app)
        resp = client.post(
            f"/api/admin/payouts/{uuid4()}/deny",
            json={"reason": "Suspicious"},
        )

        assert resp.status_code == 200

    @patch(_SVC)
    def test_fail_payout(self, mock_svc):
        app = _make_test_app()
        _override_deps(app, user=_make_user(is_admin=True))
        mock_svc.fail_payout = AsyncMock(return_value={
            "id": str(uuid4()),
            "status": "failed",
        })

        client = TestClient(app)
        resp = client.post(
            f"/api/admin/payouts/{uuid4()}/fail",
            json={"reason": "TX failed"},
        )

        assert resp.status_code == 200

    @patch(_SVC)
    def test_payout_not_found(self, mock_svc):
        app = _make_test_app()
        _override_deps(app, user=_make_user(is_admin=True))
        mock_svc.approve_payout = AsyncMock(side_effect=PayoutNotFoundError())

        client = TestClient(app)
        resp = client.post(f"/api/admin/payouts/{uuid4()}/approve")

        assert resp.status_code == 404


# ===========================================================================
# App affiliate config
# ===========================================================================


class TestAffiliateConfig:
    @patch(_SVC)
    def test_get_config(self, mock_svc):
        app = _make_test_app()
        _override_deps(app)
        mock_svc.get_affiliate_config = AsyncMock(return_value={
            "application_id": FAKE_APP_ID,
            "enabled": True,
            "l1_rate_bps": 1000,
        })

        client = TestClient(app)
        resp = client.get(f"/api/applications/{uuid4()}/affiliate-config")

        assert resp.status_code == 200

    @patch(_SVC)
    def test_update_config(self, mock_svc):
        app = _make_test_app()
        _override_deps(app)
        mock_svc.update_affiliate_config = AsyncMock(return_value={
            "application_id": FAKE_APP_ID,
            "enabled": True,
            "l1_rate_bps": 1200,
        })

        client = TestClient(app)
        resp = client.put(
            f"/api/applications/{uuid4()}/affiliate-config",
            json={
                "enabled": True,
                "l1_rate_bps": 1200,
                "l2_rate_bps": 600,
                "l3_rate_bps": 300,
            },
        )

        assert resp.status_code == 200

    @patch(_SVC)
    def test_update_config_not_owner(self, mock_svc):
        app = _make_test_app()
        _override_deps(app)
        mock_svc.update_affiliate_config = AsyncMock(
            side_effect=NotApplicationOwnerError()
        )

        client = TestClient(app)
        resp = client.put(
            f"/api/applications/{uuid4()}/affiliate-config",
            json={
                "enabled": True,
                "l1_rate_bps": 1000,
                "l2_rate_bps": 500,
                "l3_rate_bps": 200,
            },
        )

        assert resp.status_code == 403


# ===========================================================================
# Internal commission processing
# ===========================================================================


class TestInternalCommissions:
    @patch(_SVC)
    def test_process_commissions_valid_secret(self, mock_svc):
        app = _make_test_app()
        # Don't override deps for internal endpoint — it uses X-Service-Secret
        from spaps_server_quickstart.middleware.spaps_deps import get_db_session

        async def mock_db():
            yield AsyncMock()

        app.dependency_overrides[get_db_session] = mock_db

        mock_svc.process_commissions = AsyncMock(return_value={
            "commissions": [],
        })

        client = TestClient(app)
        resp = client.post(
            "/api/internal/commissions/process",
            json={
                "payer_entity_type": "agent",
                "payer_entity_id": str(uuid4()),
                "payment_amount_cents": 500,
                "payment_event_type": "x402_topup",
                "payment_reference": "0xabc",
                "application_id": FAKE_APP_ID,
            },
            headers={"X-Service-Secret": "test-internal-secret"},
        )

        assert resp.status_code == 200

    @patch(_SVC)
    def test_process_commissions_invalid_secret(self, mock_svc):
        app = _make_test_app()
        from spaps_server_quickstart.middleware.spaps_deps import get_db_session

        async def mock_db():
            yield AsyncMock()

        app.dependency_overrides[get_db_session] = mock_db

        client = TestClient(app)
        resp = client.post(
            "/api/internal/commissions/process",
            json={
                "payer_entity_type": "agent",
                "payer_entity_id": str(uuid4()),
                "payment_amount_cents": 500,
                "payment_event_type": "x402_topup",
                "payment_reference": "0xabc",
                "application_id": FAKE_APP_ID,
            },
            headers={"X-Service-Secret": "wrong-secret"},
        )

        assert resp.status_code == 403
