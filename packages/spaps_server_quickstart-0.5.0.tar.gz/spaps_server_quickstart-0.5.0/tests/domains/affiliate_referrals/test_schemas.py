"""Schema validation tests for affiliate_referrals payloads."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from spaps_server_quickstart.domains.affiliate_referrals.schemas import (
    RegisterAffiliateRequest,
    UpdateAffiliateRequest,
)


class TestRegisterAffiliateRequest:
    def test_wallet_requires_chain(self):
        with pytest.raises(
            ValidationError,
            match="payout_wallet_address requires payout_chain",
        ):
            RegisterAffiliateRequest(
                slug="test-bot",
                affiliate_type="user",
                payout_wallet_address="0x" + "a" * 40,
            )

    def test_chain_requires_wallet(self):
        with pytest.raises(
            ValidationError,
            match="payout_chain requires payout_wallet_address",
        ):
            RegisterAffiliateRequest(
                slug="test-bot",
                affiliate_type="user",
                payout_chain="eip155:8453",
            )

    def test_accepts_valid_wallet_and_chain_pair(self):
        body = RegisterAffiliateRequest(
            slug="test-bot",
            affiliate_type="user",
            payout_wallet_address="0x" + "a" * 40,
            payout_chain="eip155:8453",
        )

        assert body.payout_wallet_address == "0x" + "a" * 40
        assert body.payout_chain == "eip155:8453"


class TestUpdateAffiliateRequest:
    def test_wallet_requires_chain(self):
        with pytest.raises(
            ValidationError,
            match="payout_wallet_address requires payout_chain",
        ):
            UpdateAffiliateRequest(
                payout_wallet_address="0x" + "a" * 40,
            )

    def test_chain_requires_wallet(self):
        with pytest.raises(
            ValidationError,
            match="payout_chain requires payout_wallet_address",
        ):
            UpdateAffiliateRequest(
                payout_chain="eip155:8453",
            )

    def test_accepts_empty_patch(self):
        body = UpdateAffiliateRequest()

        assert body.model_dump() == {
            "slug": None,
            "payout_wallet_address": None,
            "payout_chain": None,
            "is_active": None,
        }
