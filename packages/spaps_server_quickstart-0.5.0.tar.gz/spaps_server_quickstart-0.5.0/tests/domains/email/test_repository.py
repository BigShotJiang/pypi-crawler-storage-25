"""Unit tests for the email domain repository layer.

The database session is fully mocked so tests exercise only the
repository query construction and result handling.
"""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4


from spaps_server_quickstart.domains.email import repository as repo

FAKE_APP_ID = uuid4()
FAKE_USER_ID = uuid4()
FAKE_OWNER_ID = uuid4()
FAKE_TEMPLATE_ID = uuid4()


def _mock_template(**overrides):
    """Create a mock EmailTemplate object."""
    tpl = MagicMock()
    tpl.id = overrides.get("id", uuid4())
    tpl.application_id = overrides.get("application_id", FAKE_APP_ID)
    tpl.template_key = overrides.get("template_key", "auth_magic_link")
    tpl.name = overrides.get("name", "Magic Link")
    tpl.description = overrides.get("description", "Magic link email")
    tpl.subject = overrides.get("subject", "Your magic link")
    tpl.html_body = overrides.get("html_body", "<p>Click {{ link }}</p>")
    tpl.text_body = overrides.get("text_body", "Click {{ link }}")
    tpl.from_email = overrides.get("from_email", "noreply@example.com")
    tpl.from_name = overrides.get("from_name", "SPAPS")
    tpl.reply_to = overrides.get("reply_to", None)
    tpl.variables = overrides.get("variables", {"link": "string"})
    tpl.sample_context = overrides.get("sample_context", {"link": "https://example.com"})
    tpl.is_active = overrides.get("is_active", True)
    tpl.category = overrides.get("category", "auth")
    tpl.created_at = datetime.now(UTC)
    tpl.updated_at = datetime.now(UTC)
    return tpl


def _mock_email_log(**overrides):
    """Create a mock EmailLog object."""
    log = MagicMock()
    log.id = overrides.get("id", uuid4())
    log.application_id = overrides.get("application_id", FAKE_APP_ID)
    log.template_id = overrides.get("template_id", FAKE_TEMPLATE_ID)
    log.user_id = overrides.get("user_id", FAKE_USER_ID)
    log.owner_id = overrides.get("owner_id", FAKE_OWNER_ID)
    log.to_email = overrides.get("to_email", "user@example.com")
    log.template_key = overrides.get("template_key", "auth_magic_link")
    log.subject = overrides.get("subject", "Your magic link")
    log.status = overrides.get("status", "sent")
    log.mailgun_message_id = overrides.get("mailgun_message_id", "msg-123")
    log.error_message = overrides.get("error_message", None)
    log.sent_at = overrides.get("sent_at", datetime.now(UTC))
    log.delivered_at = overrides.get("delivered_at", None)
    log.opened_at = overrides.get("opened_at", None)
    log.clicked_at = overrides.get("clicked_at", None)
    log.created_at = datetime.now(UTC)
    return log


def _mock_db_result(items):
    """Create a mock DB result that supports scalar_one_or_none and scalars."""
    result = MagicMock()
    result.scalar_one_or_none.return_value = items[0] if items else None

    scalars_mock = MagicMock()
    scalars_mock.all.return_value = items
    scalars_mock.first.return_value = items[0] if items else None
    result.scalars.return_value = scalars_mock

    # For count queries
    result.scalar.return_value = len(items)

    return result


# ===========================================================================
# get_template_by_key
# ===========================================================================


class TestGetTemplateByKey:
    async def test_found(self):
        """Returns template when found."""
        tpl = _mock_template()
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([tpl])

        result = await repo.get_template_by_key(db, FAKE_APP_ID, "auth_magic_link")
        assert result == tpl

    async def test_not_found(self):
        """Returns None when not found."""
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([])

        result = await repo.get_template_by_key(db, FAKE_APP_ID, "nonexistent")
        assert result is None


# ===========================================================================
# get_template_by_id
# ===========================================================================


class TestGetTemplateById:
    async def test_found(self):
        """Returns template when found by ID."""
        tpl = _mock_template()
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([tpl])

        result = await repo.get_template_by_id(db, tpl.id)
        assert result == tpl

    async def test_not_found(self):
        """Returns None when not found."""
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([])

        result = await repo.get_template_by_id(db, uuid4())
        assert result is None


# ===========================================================================
# list_templates
# ===========================================================================


class TestListTemplates:
    async def test_returns_list(self):
        """Returns list of templates."""
        templates = [_mock_template(), _mock_template(template_key="auth_welcome")]
        db = AsyncMock()
        db.execute.return_value = _mock_db_result(templates)

        result = await repo.list_templates(db, FAKE_APP_ID)
        assert len(result) == 2

    async def test_empty_list(self):
        """Returns empty list when no templates."""
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([])

        result = await repo.list_templates(db, FAKE_APP_ID)
        assert len(result) == 0


# ===========================================================================
# create_template
# ===========================================================================


class TestCreateTemplate:
    async def test_creates_and_returns(self):
        """Creates template and returns it."""
        db = AsyncMock()
        db.add = MagicMock()

        result = await repo.create_template(
            db,
            application_id=FAKE_APP_ID,
            template_key="test_template",
            name="Test Template",
            subject="Test Subject",
            html_body="<p>Hello</p>",
        )

        db.add.assert_called_once()
        db.flush.assert_called_once()
        db.refresh.assert_called_once()
        assert result is not None


# ===========================================================================
# update_template
# ===========================================================================


class TestUpdateTemplate:
    async def test_updates_and_returns(self):
        """Updates template and returns it."""
        tpl = _mock_template()
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([tpl])

        result = await repo.update_template(
            db, FAKE_APP_ID, "auth_magic_link", name="Updated Name"
        )

        assert result is not None
        db.flush.assert_called_once()
        db.refresh.assert_called_once()

    async def test_not_found_returns_none(self):
        """Returns None when template not found."""
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([])

        result = await repo.update_template(
            db, FAKE_APP_ID, "nonexistent", name="Updated"
        )
        assert result is None


# ===========================================================================
# create_email_log
# ===========================================================================


class TestCreateEmailLog:
    async def test_creates_and_returns(self):
        """Creates email log entry and returns it."""
        db = AsyncMock()
        db.add = MagicMock()

        result = await repo.create_email_log(
            db,
            application_id=FAKE_APP_ID,
            to_email="user@example.com",
            template_key="auth_magic_link",
            subject="Your magic link",
            status="pending",
        )

        db.add.assert_called_once()
        db.flush.assert_called_once()
        db.refresh.assert_called_once()
        assert result is not None


# ===========================================================================
# update_email_log
# ===========================================================================


class TestUpdateEmailLog:
    async def test_updates_and_returns(self):
        """Updates email log entry and returns it."""
        log = _mock_email_log()
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([log])

        result = await repo.update_email_log(
            db, log.id, status="delivered"
        )

        assert result is not None
        db.flush.assert_called_once()
        db.refresh.assert_called_once()

    async def test_not_found_returns_none(self):
        """Returns None when log entry not found."""
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([])

        result = await repo.update_email_log(
            db, uuid4(), status="delivered"
        )
        assert result is None


# ===========================================================================
# list_logs
# ===========================================================================


class TestListLogs:
    async def test_returns_logs_and_count(self):
        """Returns list of logs and total count."""
        logs = [_mock_email_log(), _mock_email_log(to_email="other@example.com")]

        db = AsyncMock()
        # First execute call returns count, second returns logs
        count_result = MagicMock()
        count_result.scalar.return_value = 2

        logs_result = MagicMock()
        scalars_mock = MagicMock()
        scalars_mock.all.return_value = logs
        logs_result.scalars.return_value = scalars_mock

        db.execute.side_effect = [count_result, logs_result]

        result_logs, total = await repo.list_logs(db, FAKE_APP_ID)
        assert len(result_logs) == 2
        assert total == 2

    async def test_empty_logs(self):
        """Returns empty list when no logs."""
        db = AsyncMock()

        count_result = MagicMock()
        count_result.scalar.return_value = 0

        logs_result = MagicMock()
        scalars_mock = MagicMock()
        scalars_mock.all.return_value = []
        logs_result.scalars.return_value = scalars_mock

        db.execute.side_effect = [count_result, logs_result]

        result_logs, total = await repo.list_logs(db, FAKE_APP_ID)
        assert len(result_logs) == 0
        assert total == 0

    async def test_with_owner_id_filter(self):
        """Applies owner_id filter."""
        logs = [_mock_email_log()]

        db = AsyncMock()
        count_result = MagicMock()
        count_result.scalar.return_value = 1

        logs_result = MagicMock()
        scalars_mock = MagicMock()
        scalars_mock.all.return_value = logs
        logs_result.scalars.return_value = scalars_mock

        db.execute.side_effect = [count_result, logs_result]

        result_logs, total = await repo.list_logs(
            db, FAKE_APP_ID, owner_id=FAKE_OWNER_ID
        )
        assert len(result_logs) == 1
        assert total == 1


# ===========================================================================
# Multi-tenant template_key uniqueness (Fix #2)
# ===========================================================================


class TestMultiTenantTemplateKey:
    async def test_same_key_different_apps_both_succeed(self):
        """Two apps can create a template with the same template_key."""
        app_id_1 = uuid4()
        app_id_2 = uuid4()

        db = AsyncMock()
        db.add = MagicMock()

        # First app creates template
        result1 = await repo.create_template(
            db,
            application_id=app_id_1,
            template_key="auth_magic_link",
            name="Magic Link",
            subject="Your link",
            html_body="<p>Link</p>",
        )

        db.add.assert_called_once()
        db.flush.assert_called_once()
        assert result1 is not None

        # Reset mock counters
        db.add.reset_mock()
        db.flush.reset_mock()
        db.refresh.reset_mock()

        # Second app creates template with same key — should succeed
        result2 = await repo.create_template(
            db,
            application_id=app_id_2,
            template_key="auth_magic_link",
            name="Magic Link",
            subject="Your link",
            html_body="<p>Link</p>",
        )

        db.add.assert_called_once()
        db.flush.assert_called_once()
        assert result2 is not None
