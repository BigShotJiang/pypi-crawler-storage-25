"""Unit tests for per-application email configuration resolution."""

from __future__ import annotations

import pytest

from spaps_server_quickstart.domains.email.config import resolve_email_config
from spaps_server_quickstart.domains.email.errors import EmailConfigurationError


def test_global_fallback_when_no_app_settings():
    resolved = resolve_email_config(
        app_settings=None,
        global_mailgun_domain="mail.global.example.com",
    )

    assert resolved.mailgun_domain == "mail.global.example.com"
    assert resolved.from_email == "noreply@mail.global.example.com"
    assert resolved.from_name is None
    assert resolved.reply_to is None


def test_app_domain_overrides_global():
    resolved = resolve_email_config(
        app_settings={"email": {"mailgun_domain": "mail.app.example.com"}},
        global_mailgun_domain="mail.global.example.com",
    )

    assert resolved.mailgun_domain == "mail.app.example.com"


def test_template_from_overrides_app_default():
    resolved = resolve_email_config(
        app_settings={"email": {"default_from_email": "app-default@example.com"}},
        template_from_email="template@example.com",
        global_mailgun_domain="mail.global.example.com",
    )

    assert resolved.from_email == "template@example.com"


def test_app_default_from_overrides_noreply():
    resolved = resolve_email_config(
        app_settings={"email": {"default_from_email": "app-default@example.com"}},
        global_mailgun_domain="mail.global.example.com",
    )

    assert resolved.from_email == "app-default@example.com"


def test_raises_when_no_domain_anywhere():
    with pytest.raises(EmailConfigurationError):
        resolve_email_config(app_settings=None, global_mailgun_domain=None)


def test_reply_to_precedence():
    app_settings = {"email": {"default_reply_to": "support@app.example.com"}}

    from_template = resolve_email_config(
        app_settings=app_settings,
        template_reply_to="template-reply@app.example.com",
        global_mailgun_domain="mail.app.example.com",
    )
    from_app = resolve_email_config(
        app_settings=app_settings,
        template_reply_to=None,
        global_mailgun_domain="mail.app.example.com",
    )

    assert from_template.reply_to == "template-reply@app.example.com"
    assert from_app.reply_to == "support@app.example.com"


def test_from_name_precedence():
    app_settings = {"email": {"default_from_name": "App Name"}}

    from_template = resolve_email_config(
        app_settings=app_settings,
        template_from_name="Template Name",
        global_mailgun_domain="mail.app.example.com",
    )
    from_app = resolve_email_config(
        app_settings=app_settings,
        template_from_name=None,
        global_mailgun_domain="mail.app.example.com",
    )

    assert from_template.from_name == "Template Name"
    assert from_app.from_name == "App Name"


def test_empty_email_settings_treated_as_absent():
    resolved = resolve_email_config(
        app_settings={"email": {}},
        global_mailgun_domain="mail.global.example.com",
    )

    assert resolved.mailgun_domain == "mail.global.example.com"
    assert resolved.from_email == "noreply@mail.global.example.com"
    assert resolved.from_name is None
    assert resolved.reply_to is None


def test_no_email_key_in_settings():
    resolved = resolve_email_config(
        app_settings={"stripe_enabled": True},
        global_mailgun_domain="mail.global.example.com",
    )

    assert resolved.mailgun_domain == "mail.global.example.com"
    assert resolved.from_email == "noreply@mail.global.example.com"

