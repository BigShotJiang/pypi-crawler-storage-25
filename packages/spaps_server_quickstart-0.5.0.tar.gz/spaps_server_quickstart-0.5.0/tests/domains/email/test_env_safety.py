"""Test environment safety gates for email sending.

TM-ENV-001: Environment Safety for Email
----------------------------------------
Tests that email service respects settings.env as canonical source of truth
and never sends real emails in test/dev environments, even with force_send=True.
"""

from __future__ import annotations

import os
from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

from spaps_server_quickstart.domains.email import service

_REPO = "spaps_server_quickstart.domains.email.service.repo"
_MAILGUN = "spaps_server_quickstart.domains.email.service._get_mailgun_client"

FAKE_APP_ID = uuid4()


def _make_template() -> MagicMock:
    """Build a mock EmailTemplate model instance."""
    tpl = MagicMock()
    tpl.id = uuid4()
    tpl.application_id = FAKE_APP_ID
    tpl.template_key = "test_template"
    tpl.subject = "Test {{ name }}"
    tpl.html_body = "<p>Hello {{ name }}</p>"
    tpl.text_body = "Hello {{ name }}"
    tpl.from_email = "test@example.com"
    tpl.from_name = "Test"
    tpl.reply_to = None
    tpl.is_active = True
    tpl.created_at = datetime.now(UTC)
    tpl.updated_at = datetime.now(UTC)
    return tpl


def _make_email_log() -> MagicMock:
    """Build a mock EmailLog model instance."""
    log = MagicMock()
    log.id = uuid4()
    log.application_id = FAKE_APP_ID
    log.status = "pending"
    log.to_email = "test@example.com"
    return log


# ===========================================================================
# Environment helper function tests
# ===========================================================================


class TestEnvironmentHelpers:
    """Test the internal environment checking functions."""

    def test_is_production_canonical_true(self):
        """Returns True when settings.env is production."""
        assert service._is_production("production") is True
        assert service._is_production("prod") is True

    def test_is_production_canonical_false(self):
        """Returns False when settings.env is not production."""
        assert service._is_production("dev") is False
        assert service._is_production("development") is False
        assert service._is_production("test") is False
        assert service._is_production("staging") is False

    def test_is_production_warns_on_mismatch(self, caplog):
        """Logs warning when ENV var disagrees with settings."""
        with patch.dict(os.environ, {"ENV": "production"}):
            result = service._is_production("dev")
            assert result is False  # settings.env wins
            assert "ENV variable mismatch" in caplog.text

    def test_is_local_mode_canonical_true(self):
        """Returns True when settings.is_spaps_local_mode is True."""
        assert service._is_local_mode(True) is True

    def test_is_local_mode_canonical_false(self):
        """Returns False when settings.is_spaps_local_mode is False."""
        assert service._is_local_mode(False) is False

    def test_is_local_mode_warns_on_mismatch(self, caplog):
        """Logs warning when SPAPS_LOCAL_MODE var disagrees with settings."""
        with patch.dict(os.environ, {"SPAPS_LOCAL_MODE": "true"}):
            result = service._is_local_mode(False)
            assert result is False  # settings wins
            assert "SPAPS_LOCAL_MODE variable mismatch" in caplog.text

    def test_should_short_circuit_local_mode(self):
        """Short-circuits when local mode is active."""
        assert service._should_short_circuit("dev", True) is True
        assert service._should_short_circuit("production", True) is True

    def test_should_short_circuit_non_production(self):
        """Short-circuits when environment is not production."""
        assert service._should_short_circuit("dev", False) is True
        assert service._should_short_circuit("test", False) is True
        assert service._should_short_circuit("staging", False) is True

    def test_should_short_circuit_production_only(self):
        """Does NOT short-circuit in production with local mode off."""
        assert service._should_short_circuit("production", False) is False
        assert service._should_short_circuit("prod", False) is False


# ===========================================================================
# send_email safety gate tests
# ===========================================================================


class TestSendEmailSafetyGates:
    """Test that send_email respects environment safety gates."""

    @pytest.mark.asyncio
    async def test_dev_environment_short_circuits(self):
        """Email is logged but never sent in dev environment."""
        db = AsyncMock()
        template = _make_template()
        log_entry = _make_email_log()

        with patch(f"{_REPO}.get_template_by_key", return_value=template):
            with patch(f"{_REPO}.create_email_log", return_value=log_entry):
                with patch(f"{_REPO}.update_email_log") as mock_update:
                    with patch(_MAILGUN) as mock_mailgun:
                        result = await service.send_email(
                            db,
                            application_id=FAKE_APP_ID,
                            template_key="test_template",
                            to="test@example.com",
                            settings_env="dev",
                            settings_local_mode=False,
                        )

                        # Verify short-circuit
                        assert result["message_id"].startswith("local-")
                        mock_update.assert_called_once()
                        args = mock_update.call_args
                        assert args[1]["status"] == "short_circuited"

                        # Verify Mailgun was NEVER called
                        mock_mailgun.assert_not_called()

    @pytest.mark.asyncio
    async def test_test_environment_short_circuits(self):
        """Email is logged but never sent in test environment."""
        db = AsyncMock()
        template = _make_template()
        log_entry = _make_email_log()

        with patch(f"{_REPO}.get_template_by_key", return_value=template):
            with patch(f"{_REPO}.create_email_log", return_value=log_entry):
                with patch(f"{_REPO}.update_email_log") as mock_update:
                    with patch(_MAILGUN) as mock_mailgun:
                        result = await service.send_email(
                            db,
                            application_id=FAKE_APP_ID,
                            template_key="test_template",
                            to="test@example.com",
                            settings_env="test",
                            settings_local_mode=False,
                        )

                        assert result["message_id"].startswith("local-")
                        mock_update.assert_called_once()
                        mock_mailgun.assert_not_called()

    @pytest.mark.asyncio
    async def test_local_mode_short_circuits_even_in_production(self):
        """Local mode short-circuits even if settings.env is production."""
        db = AsyncMock()
        template = _make_template()
        log_entry = _make_email_log()

        with patch(f"{_REPO}.get_template_by_key", return_value=template):
            with patch(f"{_REPO}.create_email_log", return_value=log_entry):
                with patch(f"{_REPO}.update_email_log") as mock_update:
                    with patch(_MAILGUN) as mock_mailgun:
                        result = await service.send_email(
                            db,
                            application_id=FAKE_APP_ID,
                            template_key="test_template",
                            to="test@example.com",
                            settings_env="production",
                            settings_local_mode=True,  # local mode ON
                        )

                        assert result["message_id"].startswith("local-")
                        mock_update.assert_called_once()
                        mock_mailgun.assert_not_called()

    @pytest.mark.asyncio
    async def test_force_send_ignored_in_dev(self):
        """force_send=True is ignored in dev environment (safety gate)."""
        db = AsyncMock()
        template = _make_template()
        log_entry = _make_email_log()

        with patch(f"{_REPO}.get_template_by_key", return_value=template):
            with patch(f"{_REPO}.create_email_log", return_value=log_entry):
                with patch(f"{_REPO}.update_email_log") as mock_update:
                    with patch(_MAILGUN) as mock_mailgun:
                        result = await service.send_email(
                            db,
                            application_id=FAKE_APP_ID,
                            template_key="test_template",
                            to="test@example.com",
                            settings_env="dev",
                            settings_local_mode=False,
                            force_send=True,  # This should NOT bypass safety gate
                        )

                        # Verify short-circuit happened despite force_send=True
                        assert result["message_id"].startswith("local-")
                        mock_mailgun.assert_not_called()

    @pytest.mark.asyncio
    async def test_force_send_ignored_in_test(self):
        """force_send=True is ignored in test environment (safety gate)."""
        db = AsyncMock()
        template = _make_template()
        log_entry = _make_email_log()

        with patch(f"{_REPO}.get_template_by_key", return_value=template):
            with patch(f"{_REPO}.create_email_log", return_value=log_entry):
                with patch(f"{_REPO}.update_email_log"):
                    with patch(_MAILGUN) as mock_mailgun:
                        await service.send_email(
                            db,
                            application_id=FAKE_APP_ID,
                            template_key="test_template",
                            to="test@example.com",
                            settings_env="test",
                            settings_local_mode=False,
                            force_send=True,
                        )

                        mock_mailgun.assert_not_called()

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"MAILGUN_DOMAIN": "mail.global.example.com"}, clear=False)
    async def test_production_allows_send(self):
        """Production environment with valid config allows email send."""
        db = AsyncMock()
        template = _make_template()
        log_entry = _make_email_log()

        mock_mailgun_client = MagicMock()
        mock_mailgun_client.send_email = AsyncMock(
            return_value=MagicMock(success=True, message_id="mg-123")
        )

        with patch(f"{_REPO}.get_template_by_key", return_value=template):
            with patch(f"{_REPO}.create_email_log", return_value=log_entry):
                with patch(f"{_REPO}.update_email_log") as mock_update:
                    with patch(_MAILGUN, return_value=mock_mailgun_client):
                        result = await service.send_email(
                            db,
                            application_id=FAKE_APP_ID,
                            template_key="test_template",
                            to="test@example.com",
                            settings_env="production",
                            settings_local_mode=False,
                        )

                        # Verify email was actually sent
                        assert result["message_id"] == "mg-123"
                        mock_mailgun_client.send_email.assert_called_once()
                        mock_update.assert_called_once()
                        args = mock_update.call_args
                        assert args[1]["status"] == "sent"

    @pytest.mark.asyncio
    async def test_env_var_mismatch_uses_settings_as_canonical(self, caplog):
        """When ENV var says production but settings say dev, settings win."""
        db = AsyncMock()
        template = _make_template()
        log_entry = _make_email_log()

        # Set ENV=production in environment
        with patch.dict(os.environ, {"ENV": "production"}):
            with patch(f"{_REPO}.get_template_by_key", return_value=template):
                with patch(f"{_REPO}.create_email_log", return_value=log_entry):
                    with patch(f"{_REPO}.update_email_log"):
                        with patch(_MAILGUN) as mock_mailgun:
                            result = await service.send_email(
                                db,
                                application_id=FAKE_APP_ID,
                                template_key="test_template",
                                to="test@example.com",
                                settings_env="dev",  # settings say dev
                                settings_local_mode=False,
                            )

                            # Verify short-circuit happened (settings.env wins)
                            assert result["message_id"].startswith("local-")
                            mock_mailgun.assert_not_called()

                            # Verify warning was logged
                            assert "ENV variable mismatch" in caplog.text
