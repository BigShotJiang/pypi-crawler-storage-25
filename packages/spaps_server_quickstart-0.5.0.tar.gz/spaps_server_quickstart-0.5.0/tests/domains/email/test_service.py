"""Unit tests for the email domain service layer.

The repository layer is fully mocked so tests exercise only the
service orchestration, business logic, and error handling.
"""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

from spaps_server_quickstart.domains.email import service
from spaps_server_quickstart.domains.errors import ValidationError
from spaps_server_quickstart.domains.email.errors import (
    EmailConfigurationError,
    EmailSendFailedError,
    TemplateAlreadyExistsError,
    TemplateNotFoundError,
    TemplateOverrideNotFoundError,
)

_REPO = "spaps_server_quickstart.domains.email.service.repo"

FAKE_APP_ID = uuid4()
FAKE_USER_ID = uuid4()
FAKE_OWNER_ID = uuid4()


def _make_template(
    template_key: str = "auth_magic_link",
    is_active: bool = True,
    html_body: str = "<p>Hello {{ name }}, click {{ link }}</p>",
    text_body: str | None = "Hello {{ name }}, click {{ link }}",
    subject: str = "Your {{ action }}",
    sample_context: dict | None = None,
) -> MagicMock:
    """Build a mock EmailTemplate model instance."""
    tpl = MagicMock()
    tpl.id = uuid4()
    tpl.application_id = FAKE_APP_ID
    tpl.template_key = template_key
    tpl.name = "Magic Link"
    tpl.description = "Magic link email"
    tpl.subject = subject
    tpl.html_body = html_body
    tpl.text_body = text_body
    tpl.from_email = "noreply@example.com"
    tpl.from_name = "SPAPS"
    tpl.reply_to = None
    tpl.variables = {"name": "string", "link": "string"}
    tpl.sample_context = sample_context or {"name": "User", "link": "https://example.com"}
    tpl.is_active = is_active
    tpl.category = "auth"
    tpl.created_at = datetime.now(UTC)
    tpl.updated_at = datetime.now(UTC)
    return tpl


def _make_email_log(
    status: str = "sent",
    template_key: str = "auth_magic_link",
) -> MagicMock:
    """Build a mock EmailLog model instance."""
    log = MagicMock()
    log.id = uuid4()
    log.application_id = FAKE_APP_ID
    log.template_id = uuid4()
    log.user_id = FAKE_USER_ID
    log.owner_id = FAKE_OWNER_ID
    log.to_email = "user@example.com"
    log.template_key = template_key
    log.subject = "Your magic link"
    log.status = status
    log.mailgun_message_id = "msg-123" if status == "sent" else None
    log.error_message = None
    log.sent_at = datetime.now(UTC) if status == "sent" else None
    log.delivered_at = None
    log.opened_at = None
    log.clicked_at = None
    log.created_at = datetime.now(UTC)
    return log


# ===========================================================================
# render_template
# ===========================================================================


class TestRenderTemplate:
    def test_basic_substitution(self):
        """Substitutes {{ variable }} placeholders."""
        result = service.render_template(
            "Hello {{ name }}, welcome to {{ app }}",
            {"name": "Alice", "app": "SPAPS"},
        )
        assert result == "Hello Alice, welcome to SPAPS"

    def test_no_spaces_in_braces(self):
        """Handles {{variable}} without spaces."""
        result = service.render_template(
            "Hello {{name}}",
            {"name": "Bob"},
        )
        assert result == "Hello Bob"

    def test_missing_variable_unchanged(self):
        """Leaves {{ missing }} unchanged when not in context."""
        result = service.render_template(
            "Hello {{ name }}, {{ greeting }}",
            {"name": "Carol"},
        )
        assert "Carol" in result
        assert "{{ greeting }}" in result

    def test_empty_context(self):
        """Leaves all placeholders unchanged with empty context."""
        template = "Hello {{ name }}"
        result = service.render_template(template, {})
        assert result == template

    def test_numeric_value(self):
        """Converts non-string values to string."""
        result = service.render_template(
            "Expires in {{ hours }} hours",
            {"hours": 24},
        )
        assert result == "Expires in 24 hours"


# ===========================================================================
# send_email
# ===========================================================================


class TestSendEmail:
    @patch(f"{_REPO}.update_email_log", new_callable=AsyncMock)
    @patch(f"{_REPO}.create_email_log", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_template_by_key", new_callable=AsyncMock)
    @patch("spaps_server_quickstart.domains.email.service._should_short_circuit")
    async def test_short_circuits_in_non_production(
        self, mock_short_circuit, mock_get_tpl, mock_create_log, mock_update_log
    ):
        """In non-production mode, logs email but does not call Mailgun."""
        mock_short_circuit.return_value = True
        mock_get_tpl.return_value = _make_template()
        log = _make_email_log(status="pending")
        mock_create_log.return_value = log

        db = AsyncMock()
        result = await service.send_email(
            db,
            application_id=FAKE_APP_ID,
            template_key="auth_magic_link",
            to="user@example.com",
            context={"name": "Test", "link": "https://example.com"},
        )

        assert "message_id" in result
        assert result["message_id"].startswith("local-")
        mock_update_log.assert_called_once()

    @patch(f"{_REPO}.get_template_by_key", new_callable=AsyncMock)
    async def test_template_not_found_raises(self, mock_get_tpl):
        """Raises TemplateNotFoundError when template does not exist."""
        mock_get_tpl.return_value = None

        db = AsyncMock()
        with pytest.raises(TemplateNotFoundError):
            await service.send_email(
                db,
                application_id=FAKE_APP_ID,
                template_key="nonexistent",
                to="user@example.com",
            )

    @patch(f"{_REPO}.get_template_by_key", new_callable=AsyncMock)
    async def test_inactive_template_raises(self, mock_get_tpl):
        """Raises TemplateNotFoundError when template is inactive."""
        mock_get_tpl.return_value = _make_template(is_active=False)

        db = AsyncMock()
        with pytest.raises(TemplateNotFoundError):
            await service.send_email(
                db,
                application_id=FAKE_APP_ID,
                template_key="auth_magic_link",
                to="user@example.com",
            )

    @patch(f"{_REPO}.update_email_log", new_callable=AsyncMock)
    @patch(f"{_REPO}.create_email_log", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_template_by_key", new_callable=AsyncMock)
    @patch("spaps_server_quickstart.domains.email.service._should_short_circuit")
    @patch("spaps_server_quickstart.domains.email.service._get_mailgun_client")
    async def test_mailgun_not_configured_raises(
        self, mock_get_mg, mock_short_circuit, mock_get_tpl,
        mock_create_log, mock_update_log
    ):
        """Raises EmailConfigurationError when Mailgun is not configured."""
        mock_short_circuit.return_value = False
        mock_get_mg.return_value = None
        mock_get_tpl.return_value = _make_template()
        log = _make_email_log(status="pending")
        mock_create_log.return_value = log

        db = AsyncMock()
        with pytest.raises(EmailConfigurationError):
            await service.send_email(
                db,
                application_id=FAKE_APP_ID,
                template_key="auth_magic_link",
                to="user@example.com",
            )

    @patch(f"{_REPO}.update_email_log", new_callable=AsyncMock)
    @patch(f"{_REPO}.create_email_log", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_template_by_key", new_callable=AsyncMock)
    @patch("spaps_server_quickstart.domains.email.service._should_short_circuit")
    @patch("spaps_server_quickstart.domains.email.service._get_mailgun_client")
    @patch.dict("os.environ", {"MAILGUN_DOMAIN": "mail.global.example.com"}, clear=False)
    async def test_mailgun_success(
        self, mock_get_mg, mock_short_circuit, mock_get_tpl,
        mock_create_log, mock_update_log
    ):
        """Sends email via Mailgun and returns message_id."""
        mock_short_circuit.return_value = False
        mock_mg_client = AsyncMock()
        mock_mg_client.send_email.return_value = MagicMock(
            success=True, message_id="<msg-abc@mailgun.org>"
        )
        mock_get_mg.return_value = mock_mg_client
        mock_get_tpl.return_value = _make_template()
        log = _make_email_log(status="pending")
        mock_create_log.return_value = log

        db = AsyncMock()
        result = await service.send_email(
            db,
            application_id=FAKE_APP_ID,
            template_key="auth_magic_link",
            to="user@example.com",
            context={"name": "Test", "link": "https://example.com"},
        )

        assert result["message_id"] == "<msg-abc@mailgun.org>"
        mock_mg_client.send_email.assert_called_once()

    @patch(f"{_REPO}.update_email_log", new_callable=AsyncMock)
    @patch(f"{_REPO}.create_email_log", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_template_by_key", new_callable=AsyncMock)
    @patch("spaps_server_quickstart.domains.email.service._should_short_circuit")
    @patch("spaps_server_quickstart.domains.email.service._get_mailgun_client")
    async def test_send_email_uses_app_recipient_override(
        self, mock_get_mg, mock_short_circuit, mock_get_tpl,
        mock_create_log, mock_update_log
    ):
        """Routes delivery to app.settings.email.override_to when configured."""
        mock_short_circuit.return_value = False
        mock_get_tpl.return_value = _make_template()
        mock_create_log.return_value = _make_email_log(status="pending")

        mock_mg_client = AsyncMock()
        mock_mg_client.send_email.return_value = MagicMock(
            success=True, message_id="<msg@app.example.com>"
        )
        mock_get_mg.return_value = mock_mg_client

        db = AsyncMock()
        await service.send_email(
            db,
            application_id=FAKE_APP_ID,
            app_settings={
                "email": {
                    "mailgun_domain": "mail.app.example.com",
                    "override_to": "buildooor@gmail.com",
                }
            },
            template_key="auth_magic_link",
            to="user@example.com",
            context={"name": "Test", "link": "https://example.com"},
        )

        assert mock_create_log.call_args is not None
        assert mock_create_log.call_args.kwargs["to_email"] == "buildooor@gmail.com"
        assert mock_mg_client.send_email.await_args is not None
        assert mock_mg_client.send_email.await_args.kwargs["to"] == "buildooor@gmail.com"

    @patch.dict(
        "os.environ",
        {
            "MAILGUN_DOMAIN": "mail.global.example.com",
            "DEV_EMAIL_OVERRIDE_TO": "buildooor@gmail.com",
        },
        clear=False,
    )
    @patch(f"{_REPO}.update_email_log", new_callable=AsyncMock)
    @patch(f"{_REPO}.create_email_log", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_template_by_key", new_callable=AsyncMock)
    @patch("spaps_server_quickstart.domains.email.service._should_short_circuit")
    @patch("spaps_server_quickstart.domains.email.service._get_mailgun_client")
    async def test_send_email_uses_env_recipient_override(
        self, mock_get_mg, mock_short_circuit, mock_get_tpl,
        mock_create_log, mock_update_log
    ):
        """Routes delivery to DEV_EMAIL_OVERRIDE_TO when configured."""
        mock_short_circuit.return_value = False
        mock_get_tpl.return_value = _make_template()
        mock_create_log.return_value = _make_email_log(status="pending")

        mock_mg_client = AsyncMock()
        mock_mg_client.send_email.return_value = MagicMock(
            success=True, message_id="<msg@global.example.com>"
        )
        mock_get_mg.return_value = mock_mg_client

        db = AsyncMock()
        await service.send_email(
            db,
            application_id=FAKE_APP_ID,
            template_key="auth_magic_link",
            to="user@example.com",
            context={"name": "Test", "link": "https://example.com"},
        )

        assert mock_create_log.call_args is not None
        assert mock_create_log.call_args.kwargs["to_email"] == "buildooor@gmail.com"
        assert mock_mg_client.send_email.await_args is not None
        assert mock_mg_client.send_email.await_args.kwargs["to"] == "buildooor@gmail.com"

    @patch(f"{_REPO}.update_email_log", new_callable=AsyncMock)
    @patch(f"{_REPO}.create_email_log", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_template_by_key", new_callable=AsyncMock)
    @patch("spaps_server_quickstart.domains.email.service._should_short_circuit")
    @patch("spaps_server_quickstart.domains.email.service._get_mailgun_client")
    @patch.dict("os.environ", {"MAILGUN_DOMAIN": "mail.global.example.com"}, clear=False)
    async def test_mailgun_failure_raises(
        self, mock_get_mg, mock_short_circuit, mock_get_tpl,
        mock_create_log, mock_update_log
    ):
        """Raises EmailSendFailedError when Mailgun returns failure."""
        mock_short_circuit.return_value = False
        mock_mg_client = AsyncMock()
        mock_mg_client.send_email.return_value = MagicMock(
            success=False, error="Mailgun 403: forbidden"
        )
        mock_get_mg.return_value = mock_mg_client
        mock_get_tpl.return_value = _make_template()
        log = _make_email_log(status="pending")
        mock_create_log.return_value = log

        db = AsyncMock()
        with pytest.raises(EmailSendFailedError):
            await service.send_email(
                db,
                application_id=FAKE_APP_ID,
                template_key="auth_magic_link",
                to="user@example.com",
            )

    @patch(f"{_REPO}.update_email_log", new_callable=AsyncMock)
    @patch(f"{_REPO}.create_email_log", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_template_by_key", new_callable=AsyncMock)
    @patch("spaps_server_quickstart.domains.email.service._should_short_circuit")
    async def test_subject_override(
        self, mock_short_circuit, mock_get_tpl, mock_create_log, mock_update_log
    ):
        """Allows subject override."""
        mock_short_circuit.return_value = True
        mock_get_tpl.return_value = _make_template()
        log = _make_email_log(status="pending")
        mock_create_log.return_value = log

        db = AsyncMock()
        result = await service.send_email(
            db,
            application_id=FAKE_APP_ID,
            template_key="auth_magic_link",
            to="user@example.com",
            subject_override="Custom Subject",
        )

        # The log should have been created with the custom subject
        call_kwargs = mock_create_log.call_args
        assert call_kwargs.kwargs.get("subject") == "Custom Subject" or \
               (call_kwargs[1].get("subject") == "Custom Subject" if call_kwargs[1] else False)

    @patch(f"{_REPO}.update_email_log", new_callable=AsyncMock)
    @patch(f"{_REPO}.create_email_log", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_template_by_key", new_callable=AsyncMock)
    @patch("spaps_server_quickstart.domains.email.service._should_short_circuit")
    @patch(
        "spaps_server_quickstart.domains.applications.repository.get_application_by_id",
        new_callable=AsyncMock,
    )
    async def test_context_enrichment(
        self, mock_get_app, mock_short_circuit, mock_get_tpl,
        mock_create_log, mock_update_log
    ):
        """Auto-enriches context with app_name, current_year, and expires_in alias."""
        mock_short_circuit.return_value = True
        tpl = _make_template(
            html_body="<p>{{ app_name }} - {{ current_year }} - {{ expires_in }}</p>",
            text_body="{{ app_name }} - {{ current_year }} - {{ expires_in }}",
            subject="{{ app_name }}",
        )
        mock_get_tpl.return_value = tpl
        mock_create_log.return_value = _make_email_log(status="pending")

        mock_app = MagicMock()
        mock_app.name = "HTMA Labs"
        mock_get_app.return_value = mock_app

        db = AsyncMock()
        result = await service.send_email(
            db,
            application_id=FAKE_APP_ID,
            template_key="auth_magic_link",
            to="user@example.com",
            context={"expires_in_minutes": 60},
        )

        assert "message_id" in result
        # Verify the subject was rendered with enriched context
        call_kwargs = mock_create_log.call_args
        subject = call_kwargs.kwargs.get("subject", "")
        assert subject == "HTMA Labs"

    @patch(f"{_REPO}.update_email_log", new_callable=AsyncMock)
    @patch(f"{_REPO}.create_email_log", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_template_by_key", new_callable=AsyncMock)
    @patch("spaps_server_quickstart.domains.email.service._should_short_circuit")
    @patch("spaps_server_quickstart.domains.email.service._get_mailgun_client")
    async def test_send_email_uses_app_mailgun_domain(
        self, mock_get_mg, mock_short_circuit, mock_get_tpl,
        mock_create_log, mock_update_log
    ):
        """Uses app.settings.email.mailgun_domain when provided."""
        mock_short_circuit.return_value = False
        mock_get_tpl.return_value = _make_template()
        mock_create_log.return_value = _make_email_log(status="pending")

        mock_mg_client = AsyncMock()
        mock_mg_client.send_email.return_value = MagicMock(
            success=True, message_id="<msg@app.example.com>"
        )
        mock_get_mg.return_value = mock_mg_client

        db = AsyncMock()
        await service.send_email(
            db,
            application_id=FAKE_APP_ID,
            app_settings={"email": {"mailgun_domain": "mail.app.example.com"}},
            template_key="auth_magic_link",
            to="user@example.com",
            context={"app_name": "Test App", "app_logo_url": "https://example.com/logo.png"},
        )

        mock_get_mg.assert_called_once_with(domain_override="mail.app.example.com")

    @patch(f"{_REPO}.update_email_log", new_callable=AsyncMock)
    @patch(f"{_REPO}.create_email_log", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_template_by_key", new_callable=AsyncMock)
    @patch("spaps_server_quickstart.domains.email.service._should_short_circuit")
    @patch("spaps_server_quickstart.domains.email.service._get_mailgun_client")
    async def test_send_email_uses_app_default_from(
        self, mock_get_mg, mock_short_circuit, mock_get_tpl,
        mock_create_log, mock_update_log
    ):
        """Uses app default sender when template has no from_email."""
        mock_short_circuit.return_value = False
        template = _make_template()
        template.from_email = None
        mock_get_tpl.return_value = template
        mock_create_log.return_value = _make_email_log(status="pending")

        mock_mg_client = AsyncMock()
        mock_mg_client.send_email.return_value = MagicMock(
            success=True, message_id="<msg@app.example.com>"
        )
        mock_get_mg.return_value = mock_mg_client

        db = AsyncMock()
        await service.send_email(
            db,
            application_id=FAKE_APP_ID,
            app_settings={
                "email": {
                    "mailgun_domain": "mail.app.example.com",
                    "default_from_email": "hello@app.example.com",
                }
            },
            template_key="auth_magic_link",
            to="user@example.com",
            context={"app_name": "Test App", "app_logo_url": "https://example.com/logo.png"},
        )

        assert mock_mg_client.send_email.await_args is not None
        call_kwargs = mock_mg_client.send_email.await_args.kwargs
        assert call_kwargs["from_email"] == "hello@app.example.com"

    @patch(f"{_REPO}.update_email_log", new_callable=AsyncMock)
    @patch(f"{_REPO}.create_email_log", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_template_by_key", new_callable=AsyncMock)
    @patch("spaps_server_quickstart.domains.email.service._should_short_circuit")
    @patch("spaps_server_quickstart.domains.email.service._get_mailgun_client")
    async def test_send_email_template_from_beats_app_default(
        self, mock_get_mg, mock_short_circuit, mock_get_tpl,
        mock_create_log, mock_update_log
    ):
        """Template from_email takes precedence over app default."""
        mock_short_circuit.return_value = False
        template = _make_template()
        template.from_email = "template@example.com"
        mock_get_tpl.return_value = template
        mock_create_log.return_value = _make_email_log(status="pending")

        mock_mg_client = AsyncMock()
        mock_mg_client.send_email.return_value = MagicMock(
            success=True, message_id="<msg@app.example.com>"
        )
        mock_get_mg.return_value = mock_mg_client

        db = AsyncMock()
        await service.send_email(
            db,
            application_id=FAKE_APP_ID,
            app_settings={
                "email": {
                    "mailgun_domain": "mail.app.example.com",
                    "default_from_email": "hello@app.example.com",
                }
            },
            template_key="auth_magic_link",
            to="user@example.com",
            context={"app_name": "Test App", "app_logo_url": "https://example.com/logo.png"},
        )

        assert mock_mg_client.send_email.await_args is not None
        call_kwargs = mock_mg_client.send_email.await_args.kwargs
        assert call_kwargs["from_email"] == "template@example.com"

    @patch.dict("os.environ", {"MAILGUN_DOMAIN": "mail.global.example.com"}, clear=False)
    @patch(f"{_REPO}.update_email_log", new_callable=AsyncMock)
    @patch(f"{_REPO}.create_email_log", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_template_by_key", new_callable=AsyncMock)
    @patch("spaps_server_quickstart.domains.email.service._should_short_circuit")
    @patch("spaps_server_quickstart.domains.email.service._get_mailgun_client")
    async def test_send_email_falls_back_to_global_domain(
        self, mock_get_mg, mock_short_circuit, mock_get_tpl,
        mock_create_log, mock_update_log
    ):
        """Falls back to global MAILGUN_DOMAIN when app settings are absent."""
        mock_short_circuit.return_value = False
        mock_get_tpl.return_value = _make_template()
        mock_create_log.return_value = _make_email_log(status="pending")

        mock_mg_client = AsyncMock()
        mock_mg_client.send_email.return_value = MagicMock(
            success=True, message_id="<msg@global.example.com>"
        )
        mock_get_mg.return_value = mock_mg_client

        db = AsyncMock()
        await service.send_email(
            db,
            application_id=FAKE_APP_ID,
            template_key="auth_magic_link",
            to="user@example.com",
            context={"app_name": "Test App", "app_logo_url": "https://example.com/logo.png"},
        )

        mock_get_mg.assert_called_once_with(domain_override="mail.global.example.com")


# ===========================================================================
# list_templates
# ===========================================================================


class TestListTemplates:
    @patch(_REPO)
    async def test_returns_templates(self, mock_repo):
        """Returns templates list."""
        templates = [_make_template(), _make_template(template_key="auth_welcome")]
        mock_repo.list_templates = AsyncMock(return_value=templates)

        db = AsyncMock()
        result = await service.list_templates(db, application_id=FAKE_APP_ID)

        assert len(result["templates"]) == 2

    @patch(_REPO)
    async def test_empty_list(self, mock_repo):
        """Returns empty list when no templates."""
        mock_repo.list_templates = AsyncMock(return_value=[])

        db = AsyncMock()
        result = await service.list_templates(db, application_id=FAKE_APP_ID)

        assert len(result["templates"]) == 0


# ===========================================================================
# get_template
# ===========================================================================


class TestGetTemplate:
    @patch(_REPO)
    async def test_found(self, mock_repo):
        """Returns template dict when found."""
        tpl = _make_template()
        mock_repo.get_template_by_key = AsyncMock(return_value=tpl)

        db = AsyncMock()
        result = await service.get_template(
            db, application_id=FAKE_APP_ID, template_key="auth_magic_link"
        )

        assert result["template_key"] == "auth_magic_link"
        assert result["name"] == "Magic Link"

    @patch(_REPO)
    async def test_not_found_raises(self, mock_repo):
        """Raises TemplateNotFoundError when template does not exist."""
        mock_repo.get_template_by_key = AsyncMock(return_value=None)

        db = AsyncMock()
        with pytest.raises(TemplateNotFoundError):
            await service.get_template(
                db, application_id=FAKE_APP_ID, template_key="nonexistent"
            )


# ===========================================================================
# preview_template
# ===========================================================================


class TestPreviewTemplate:
    @patch(_REPO)
    async def test_renders_with_custom_context(self, mock_repo):
        """Renders template with custom context."""
        tpl = _make_template()
        mock_repo.get_template_by_key = AsyncMock(return_value=tpl)

        db = AsyncMock()
        result = await service.preview_template(
            db,
            application_id=FAKE_APP_ID,
            template_key="auth_magic_link",
            context={"name": "Alice", "link": "https://test.com"},
        )

        assert "Alice" in result
        assert "https://test.com" in result

    @patch(_REPO)
    async def test_renders_with_sample_context(self, mock_repo):
        """Uses sample_context when no custom context provided."""
        tpl = _make_template(
            sample_context={"name": "SampleUser", "link": "https://sample.com"}
        )
        mock_repo.get_template_by_key = AsyncMock(return_value=tpl)

        db = AsyncMock()
        result = await service.preview_template(
            db,
            application_id=FAKE_APP_ID,
            template_key="auth_magic_link",
        )

        assert "SampleUser" in result
        assert "https://sample.com" in result

    @patch(_REPO)
    async def test_not_found_raises(self, mock_repo):
        """Raises TemplateNotFoundError when template does not exist."""
        mock_repo.get_template_by_key = AsyncMock(return_value=None)

        db = AsyncMock()
        with pytest.raises(TemplateNotFoundError):
            await service.preview_template(
                db, application_id=FAKE_APP_ID, template_key="nonexistent"
            )


# ===========================================================================
# create_template
# ===========================================================================


class TestCreateTemplate:
    @patch(_REPO)
    async def test_success(self, mock_repo):
        """Creates template and returns it."""
        mock_repo.get_template_by_key = AsyncMock(return_value=None)
        tpl = _make_template(template_key="new_template")
        mock_repo.create_template = AsyncMock(return_value=tpl)

        db = AsyncMock()
        result = await service.create_template(
            db,
            application_id=FAKE_APP_ID,
            template_key="new_template",
            name="New Template",
            subject="Hello",
            html_body="<p>Hello</p>",
        )

        assert result["template"]["template_key"] == "new_template"

    @patch(_REPO)
    async def test_duplicate_raises(self, mock_repo):
        """Raises TemplateAlreadyExistsError for duplicate key."""
        mock_repo.get_template_by_key = AsyncMock(return_value=_make_template())

        db = AsyncMock()
        with pytest.raises(TemplateAlreadyExistsError):
            await service.create_template(
                db,
                application_id=FAKE_APP_ID,
                template_key="auth_magic_link",
                name="Duplicate",
                subject="Dup",
                html_body="<p>Dup</p>",
            )


# ===========================================================================
# update_template
# ===========================================================================


class TestUpdateTemplate:
    @patch(_REPO)
    async def test_success(self, mock_repo):
        """Updates template and returns it."""
        tpl = _make_template()
        tpl.name = "Updated Name"
        mock_repo.update_template = AsyncMock(return_value=tpl)

        db = AsyncMock()
        result = await service.update_template(
            db,
            application_id=FAKE_APP_ID,
            template_key="auth_magic_link",
            name="Updated Name",
        )

        assert result["template"]["name"] == "Updated Name"

    @patch(_REPO)
    async def test_not_found_raises(self, mock_repo):
        """Raises TemplateNotFoundError for unknown template."""
        mock_repo.update_template = AsyncMock(return_value=None)

        db = AsyncMock()
        with pytest.raises(TemplateNotFoundError):
            await service.update_template(
                db,
                application_id=FAKE_APP_ID,
                template_key="nonexistent",
                name="Updated",
            )


# ===========================================================================
# template overrides
# ===========================================================================


class TestTemplateOverrides:
    @patch(_REPO)
    async def test_get_override_success(self, mock_repo):
        """Returns template override when present."""
        tpl = _make_template(
            sample_context={
                "name": "User",
                "__spaps_template_override__": {
                    "subject_override": "Custom subject",
                    "body_override": "<p>Custom body</p>",
                },
            }
        )
        mock_repo.get_template_by_key = AsyncMock(return_value=tpl)

        db = AsyncMock()
        result = await service.get_template_override(
            db,
            application_id=FAKE_APP_ID,
            template_key="auth_magic_link",
        )

        assert result["subject_override"] == "Custom subject"
        assert result["body_override"] == "<p>Custom body</p>"

    @patch(_REPO)
    async def test_get_override_missing_raises(self, mock_repo):
        """Raises TemplateOverrideNotFoundError when missing."""
        tpl = _make_template(sample_context={"name": "User"})
        mock_repo.get_template_by_key = AsyncMock(return_value=tpl)

        db = AsyncMock()
        with pytest.raises(TemplateOverrideNotFoundError):
            await service.get_template_override(
                db,
                application_id=FAKE_APP_ID,
                template_key="auth_magic_link",
            )

    @patch(_REPO)
    async def test_put_override_upserts_and_returns_value(self, mock_repo):
        """Creates/updates override and returns updated payload."""
        existing = _make_template(sample_context={"name": "User"})
        updated = _make_template(
            sample_context={
                "name": "User",
                "__spaps_template_override__": {
                    "subject_override": "Updated subject",
                    "body_override": "<p>Updated body</p>",
                },
            }
        )
        mock_repo.get_template_by_key = AsyncMock(return_value=existing)
        mock_repo.update_template = AsyncMock(return_value=updated)

        db = AsyncMock()
        result = await service.create_or_update_template_override(
            db,
            application_id=FAKE_APP_ID,
            template_key="auth_magic_link",
            subject_override="Updated subject",
            body_override="<p>Updated body</p>",
        )

        assert result["subject_override"] == "Updated subject"
        assert result["body_override"] == "<p>Updated body</p>"
        mock_repo.update_template.assert_called_once()

    @patch(_REPO)
    async def test_put_override_requires_field(self, mock_repo):
        """Requires at least one override field."""
        db = AsyncMock()
        with pytest.raises(ValidationError):
            await service.create_or_update_template_override(
                db,
                application_id=FAKE_APP_ID,
                template_key="auth_magic_link",
            )

    @patch(_REPO)
    async def test_delete_override_success(self, mock_repo):
        """Deletes template override when present."""
        existing = _make_template(
            sample_context={
                "name": "User",
                "__spaps_template_override__": {
                    "subject_override": "Custom subject",
                },
            }
        )
        updated = _make_template(sample_context={"name": "User"})
        mock_repo.get_template_by_key = AsyncMock(return_value=existing)
        mock_repo.update_template = AsyncMock(return_value=updated)

        db = AsyncMock()
        result = await service.delete_template_override(
            db,
            application_id=FAKE_APP_ID,
            template_key="auth_magic_link",
        )

        assert result["deleted"] is True
        mock_repo.update_template.assert_called_once()

    @patch(_REPO)
    async def test_delete_override_missing_raises(self, mock_repo):
        """Raises TemplateOverrideNotFoundError when override is missing."""
        tpl = _make_template(sample_context={"name": "User"})
        mock_repo.get_template_by_key = AsyncMock(return_value=tpl)

        db = AsyncMock()
        with pytest.raises(TemplateOverrideNotFoundError):
            await service.delete_template_override(
                db,
                application_id=FAKE_APP_ID,
                template_key="auth_magic_link",
            )


# ===========================================================================
# get_logs
# ===========================================================================


class TestGetLogs:
    @patch(_REPO)
    async def test_returns_logs_and_total(self, mock_repo):
        """Returns logs list and total count."""
        logs = [_make_email_log(), _make_email_log()]
        mock_repo.list_logs = AsyncMock(return_value=(logs, 2))

        db = AsyncMock()
        result = await service.get_logs(
            db, application_id=FAKE_APP_ID
        )

        assert len(result["logs"]) == 2
        assert result["total"] == 2

    @patch(_REPO)
    async def test_empty_logs(self, mock_repo):
        """Returns empty when no logs."""
        mock_repo.list_logs = AsyncMock(return_value=([], 0))

        db = AsyncMock()
        result = await service.get_logs(
            db, application_id=FAKE_APP_ID
        )

        assert len(result["logs"]) == 0
        assert result["total"] == 0

    @patch(_REPO)
    async def test_with_owner_id(self, mock_repo):
        """Passes owner_id filter to repository."""
        logs = [_make_email_log()]
        mock_repo.list_logs = AsyncMock(return_value=(logs, 1))

        db = AsyncMock()
        result = await service.get_logs(
            db,
            application_id=FAKE_APP_ID,
            owner_id=FAKE_OWNER_ID,
        )

        mock_repo.list_logs.assert_called_once_with(
            db,
            FAKE_APP_ID,
            owner_id=FAKE_OWNER_ID,
            user_id=None,
            limit=50,
            offset=0,
        )
        assert result["total"] == 1


# ===========================================================================
# Mailgun 2xx handling (Fix #4)
# ===========================================================================


class TestMailgun2xxHandling:
    async def test_202_accepted_returns_success(self):
        """Mailgun returning 202 (queued) should be treated as success."""
        from spaps_server_quickstart.domains.email.mailgun import (
            MailgunClient,
            MailgunConfig,
        )

        config = MailgunConfig(api_key="key-123", domain="mg.example.com")
        client = MailgunClient(config)

        mock_response = MagicMock()
        mock_response.status_code = 202
        mock_response.json.return_value = {"id": "<msg-queued@mg.example.com>"}

        with patch("httpx.AsyncClient") as mock_httpx:
            mock_ctx = AsyncMock()
            mock_ctx.__aenter__.return_value = mock_ctx
            mock_ctx.__aexit__.return_value = False
            mock_ctx.post.return_value = mock_response
            mock_httpx.return_value = mock_ctx

            result = await client.send_email(
                to="test@example.com",
                subject="Test",
                html="<p>Test</p>",
            )

        assert result.success is True
        assert result.message_id == "<msg-queued@mg.example.com>"

    async def test_201_created_returns_success(self):
        """Mailgun returning 201 should be treated as success."""
        from spaps_server_quickstart.domains.email.mailgun import (
            MailgunClient,
            MailgunConfig,
        )

        config = MailgunConfig(api_key="key-123", domain="mg.example.com")
        client = MailgunClient(config)

        mock_response = MagicMock()
        mock_response.status_code = 201
        mock_response.json.return_value = {"id": "<msg-201@mg.example.com>"}

        with patch("httpx.AsyncClient") as mock_httpx:
            mock_ctx = AsyncMock()
            mock_ctx.__aenter__.return_value = mock_ctx
            mock_ctx.__aexit__.return_value = False
            mock_ctx.post.return_value = mock_response
            mock_httpx.return_value = mock_ctx

            result = await client.send_email(
                to="test@example.com",
                subject="Test",
                html="<p>Test</p>",
            )

        assert result.success is True

    async def test_base_url_without_v3_is_normalized(self):
        """MAILGUN_BASE_URL without /v3 should still hit the v3 endpoint."""
        from spaps_server_quickstart.domains.email.mailgun import (
            MailgunClient,
            MailgunConfig,
        )

        config = MailgunConfig(
            api_key="key-123",
            domain="mg.example.com",
            base_url="https://api.mailgun.net",
        )
        client = MailgunClient(config)

        mock_response = MagicMock()
        mock_response.status_code = 202
        mock_response.json.return_value = {"id": "<msg-queued@mg.example.com>"}

        with patch("httpx.AsyncClient") as mock_httpx:
            mock_ctx = AsyncMock()
            mock_ctx.__aenter__.return_value = mock_ctx
            mock_ctx.__aexit__.return_value = False
            mock_ctx.post.return_value = mock_response
            mock_httpx.return_value = mock_ctx

            await client.send_email(
                to="test@example.com",
                subject="Test",
                html="<p>Test</p>",
            )

        call_args = mock_ctx.post.call_args
        posted_url = call_args.args[0] if call_args.args else call_args.kwargs.get("url")
        assert posted_url == "https://api.mailgun.net/v3/mg.example.com/messages"

    async def test_base_url_with_v3_is_not_duplicated(self):
        """MAILGUN_BASE_URL already ending in /v3 should not become /v3/v3."""
        from spaps_server_quickstart.domains.email.mailgun import (
            MailgunClient,
            MailgunConfig,
        )

        config = MailgunConfig(
            api_key="key-123",
            domain="mg.example.com",
            base_url="https://api.mailgun.net/v3",
        )
        client = MailgunClient(config)

        mock_response = MagicMock()
        mock_response.status_code = 202
        mock_response.json.return_value = {"id": "<msg-queued@mg.example.com>"}

        with patch("httpx.AsyncClient") as mock_httpx:
            mock_ctx = AsyncMock()
            mock_ctx.__aenter__.return_value = mock_ctx
            mock_ctx.__aexit__.return_value = False
            mock_ctx.post.return_value = mock_response
            mock_httpx.return_value = mock_ctx

            await client.send_email(
                to="test@example.com",
                subject="Test",
                html="<p>Test</p>",
            )

        call_args = mock_ctx.post.call_args
        posted_url = call_args.args[0] if call_args.args else call_args.kwargs.get("url")
        assert posted_url == "https://api.mailgun.net/v3/mg.example.com/messages"


# ===========================================================================
# ensure_auth_templates (Fix #10)
# ===========================================================================


class TestEnsureAuthTemplates:
    @patch(f"{_REPO}.create_template", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_template_by_key", new_callable=AsyncMock)
    async def test_seeds_all_4_templates_on_first_call(
        self, mock_get, mock_create
    ):
        """Seeds all 4 auth templates when none exist."""
        mock_get.return_value = None  # No existing templates
        mock_create.return_value = _make_template()

        db = AsyncMock()
        result = await service.ensure_auth_templates(
            db, application_id=FAKE_APP_ID
        )

        assert len(result) == 4
        assert mock_create.call_count == 4
        assert "auth_magic_link" in result
        assert "auth_password_reset" in result
        assert "auth_email_confirmation" in result
        assert "auth_welcome" in result

    @patch(f"{_REPO}.create_template", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_template_by_key", new_callable=AsyncMock)
    async def test_skips_existing_templates(self, mock_get, mock_create):
        """Skips templates that already exist (idempotent)."""
        # All templates already exist
        mock_get.return_value = _make_template()

        db = AsyncMock()
        result = await service.ensure_auth_templates(
            db, application_id=FAKE_APP_ID
        )

        assert result == []
        mock_create.assert_not_called()

    @patch(f"{_REPO}.create_template", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_template_by_key", new_callable=AsyncMock)
    async def test_returns_created_keys(self, mock_get, mock_create):
        """Returns list of template_keys that were created."""
        mock_get.return_value = None
        mock_create.return_value = _make_template()

        db = AsyncMock()
        result = await service.ensure_auth_templates(
            db, application_id=FAKE_APP_ID
        )

        assert isinstance(result, list)
        assert all(isinstance(k, str) for k in result)

    @patch(f"{_REPO}.create_template", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_template_by_key", new_callable=AsyncMock)
    async def test_mixed_existing_and_new(self, mock_get, mock_create):
        """Creates only missing templates when some already exist."""
        # First two exist, last two don't
        existing = _make_template()
        mock_get.side_effect = [existing, existing, None, None]
        mock_create.return_value = _make_template()

        db = AsyncMock()
        result = await service.ensure_auth_templates(
            db, application_id=FAKE_APP_ID
        )

        assert len(result) == 2
        assert mock_create.call_count == 2
