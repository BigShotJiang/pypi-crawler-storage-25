"""Unit tests for the whitelist domain service layer.

The repository layer is fully mocked so tests exercise only the
service orchestration, business logic, and error handling.
"""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

from spaps_server_quickstart.domains.errors import DomainError, NotFoundError
from spaps_server_quickstart.domains.whitelist import service

_REPO = "spaps_server_quickstart.domains.whitelist.service.repo"

FAKE_APP_ID = uuid4()
FAKE_USER_ID = uuid4()


def _make_entry(
    email: str = "test@example.com",
    tier: str = "premium",
    bypass_payment: bool = True,
) -> MagicMock:
    """Build a mock EmailWhitelist model instance."""
    entry = MagicMock()
    entry.id = uuid4()
    entry.application_id = FAKE_APP_ID
    entry.email = email.lower()
    entry.tier = tier
    entry.bypass_payment = bypass_payment
    entry.metadata_ = {}
    entry.created_by = FAKE_USER_ID
    entry.created_at = datetime.now(UTC)
    entry.updated_at = datetime.now(UTC)
    return entry


# ===========================================================================
# check_whitelist
# ===========================================================================


class TestCheckWhitelist:
    @patch(_REPO)
    async def test_found(self, mock_repo):
        """Returns entry dict when email is whitelisted."""
        entry = _make_entry()
        mock_repo.get_by_email = AsyncMock(return_value=entry)

        db = AsyncMock()
        result = await service.check_whitelist(
            db, application_id=FAKE_APP_ID, email="test@example.com"
        )

        assert result["entry"] is not None
        assert result["entry"]["email"] == "test@example.com"
        assert "whitelisted" in result["message"]

    @patch(_REPO)
    async def test_not_found(self, mock_repo):
        """Returns no entry when email is not whitelisted."""
        mock_repo.get_by_email = AsyncMock(return_value=None)

        db = AsyncMock()
        result = await service.check_whitelist(
            db, application_id=FAKE_APP_ID, email="unknown@example.com"
        )

        assert "entry" not in result
        assert "not whitelisted" in result["message"]


# ===========================================================================
# add_to_whitelist
# ===========================================================================


class TestAddToWhitelist:
    @patch(_REPO)
    async def test_success(self, mock_repo):
        """Creates entry and returns success dict."""
        mock_repo.get_by_email = AsyncMock(return_value=None)
        entry = _make_entry()
        mock_repo.create = AsyncMock(return_value=entry)

        db = AsyncMock()
        result = await service.add_to_whitelist(
            db,
            application_id=FAKE_APP_ID,
            email="test@example.com",
            tier="premium",
            created_by=FAKE_USER_ID,
        )

        assert result["entry"]["email"] == "test@example.com"
        assert "successfully added" in result["message"]

    @patch(_REPO)
    async def test_duplicate_raises_409(self, mock_repo):
        """Raises DomainError with DUPLICATE_ENTRY for existing email."""
        mock_repo.get_by_email = AsyncMock(return_value=_make_entry())

        db = AsyncMock()
        with pytest.raises(DomainError) as exc_info:
            await service.add_to_whitelist(
                db,
                application_id=FAKE_APP_ID,
                email="test@example.com",
            )

        assert exc_info.value.code == "DUPLICATE_ENTRY"
        assert exc_info.value.status_code == 409

    @patch(_REPO)
    async def test_lowercases_email(self, mock_repo):
        """Email is lowercased before storage."""
        mock_repo.get_by_email = AsyncMock(return_value=None)
        entry = _make_entry(email="test@example.com")
        mock_repo.create = AsyncMock(return_value=entry)

        db = AsyncMock()
        await service.add_to_whitelist(
            db,
            application_id=FAKE_APP_ID,
            email="Test@Example.COM",
        )

        # Verify repo.get_by_email was called with lowercased email
        call_args = mock_repo.get_by_email.call_args
        assert call_args[0][1] == FAKE_APP_ID
        assert call_args[0][2] == "test@example.com"


# ===========================================================================
# bulk_add
# ===========================================================================


class TestBulkAdd:
    @patch(_REPO)
    async def test_all_succeed(self, mock_repo):
        """Returns all successful when no duplicates."""
        entries = [
            _make_entry("a@example.com"),
            _make_entry("b@example.com"),
        ]
        mock_repo.bulk_create = AsyncMock(return_value=(entries, []))

        db = AsyncMock()
        result = await service.bulk_add(
            db,
            application_id=FAKE_APP_ID,
            entries=[
                {"email": "a@example.com"},
                {"email": "b@example.com"},
            ],
            created_by=FAKE_USER_ID,
        )

        assert result["total"] == 2
        assert len(result["successful"]) == 2
        assert len(result["failed"]) == 0
        assert "Added 2 of 2" in result["message"]

    @patch(_REPO)
    async def test_partial_failure(self, mock_repo):
        """Returns mixed results when some entries fail."""
        entries = [_make_entry("a@example.com")]
        failed = [{"email": "b@example.com", "error": "Email already whitelisted"}]
        mock_repo.bulk_create = AsyncMock(return_value=(entries, failed))

        db = AsyncMock()
        result = await service.bulk_add(
            db,
            application_id=FAKE_APP_ID,
            entries=[
                {"email": "a@example.com"},
                {"email": "b@example.com"},
            ],
        )

        assert result["total"] == 2
        assert len(result["successful"]) == 1
        assert len(result["failed"]) == 1
        assert "Added 1 of 2" in result["message"]


# ===========================================================================
# list_whitelist
# ===========================================================================


class TestListWhitelist:
    @patch(_REPO)
    async def test_returns_entries_and_total(self, mock_repo):
        """Returns entries list and total count."""
        entries = [_make_entry("a@example.com"), _make_entry("b@example.com")]
        mock_repo.list_entries = AsyncMock(return_value=entries)
        mock_repo.count = AsyncMock(return_value=2)

        db = AsyncMock()
        result = await service.list_whitelist(
            db, application_id=FAKE_APP_ID, limit=10, offset=0
        )

        assert len(result["entries"]) == 2
        assert result["total"] == 2

    @patch(_REPO)
    async def test_passes_filter_params(self, mock_repo):
        """Passes tier filter to repository."""
        mock_repo.list_entries = AsyncMock(return_value=[])
        mock_repo.count = AsyncMock(return_value=0)

        db = AsyncMock()
        await service.list_whitelist(
            db,
            application_id=FAKE_APP_ID,
            limit=5,
            offset=10,
            tier="enterprise",
        )

        mock_repo.list_entries.assert_called_once_with(
            db, FAKE_APP_ID, limit=5, offset=10, tier="enterprise"
        )
        mock_repo.count.assert_called_once_with(
            db, FAKE_APP_ID, tier="enterprise"
        )


# ===========================================================================
# update_entry
# ===========================================================================


class TestUpdateEntry:
    @patch(_REPO)
    async def test_success(self, mock_repo):
        """Updates entry and returns it."""
        entry = _make_entry(tier="enterprise")
        mock_repo.update_entry = AsyncMock(return_value=entry)

        db = AsyncMock()
        result = await service.update_entry(
            db,
            application_id=FAKE_APP_ID,
            email="test@example.com",
            tier="enterprise",
        )

        assert result["entry"]["tier"] == "enterprise"
        assert "updated successfully" in result["message"]

    @patch(_REPO)
    async def test_not_found_raises_404(self, mock_repo):
        """Raises NotFoundError for unknown email."""
        mock_repo.update_entry = AsyncMock(return_value=None)

        db = AsyncMock()
        with pytest.raises(NotFoundError):
            await service.update_entry(
                db,
                application_id=FAKE_APP_ID,
                email="unknown@example.com",
                tier="basic",
            )

    @patch(_REPO)
    async def test_only_passes_non_none_kwargs(self, mock_repo):
        """Only non-None fields are passed to repo.update_entry."""
        entry = _make_entry()
        mock_repo.update_entry = AsyncMock(return_value=entry)

        db = AsyncMock()
        await service.update_entry(
            db,
            application_id=FAKE_APP_ID,
            email="test@example.com",
            tier="basic",
            bypass_payment=None,
            metadata=None,
        )

        call_kwargs = mock_repo.update_entry.call_args.kwargs
        assert "tier" in call_kwargs
        assert "bypass_payment" not in call_kwargs
        assert "metadata" not in call_kwargs


# ===========================================================================
# get_stats
# ===========================================================================


class TestGetStats:
    @patch(_REPO)
    async def test_returns_formatted_stats(self, mock_repo):
        """Returns stats with enabled, total, and tierBreakdown."""
        mock_repo.get_stats = AsyncMock(
            return_value={
                "enabled": True,
                "total": 42,
                "tier_breakdown": [
                    {"tier": "premium", "count": 30},
                    {"tier": "enterprise", "count": 12},
                ],
            }
        )

        db = AsyncMock()
        result = await service.get_stats(
            db, application_id=FAKE_APP_ID, whitelist_enabled=True
        )

        stats = result["stats"]
        assert stats["enabled"] is True
        assert stats["total"] == 42
        assert len(stats["tierBreakdown"]) == 2
        assert stats["tierBreakdown"][0]["tier"] == "premium"
        assert stats["tierBreakdown"][0]["count"] == 30


# ===========================================================================
# clear_whitelist
# ===========================================================================


class TestClearWhitelist:
    @patch(_REPO)
    async def test_returns_count(self, mock_repo):
        """Returns message with deleted count."""
        mock_repo.clear_all = AsyncMock(return_value=5)

        db = AsyncMock()
        result = await service.clear_whitelist(db, application_id=FAKE_APP_ID)

        assert "Cleared 5" in result["message"]

    @patch(_REPO)
    async def test_empty_whitelist(self, mock_repo):
        """Returns 0 count for empty whitelist."""
        mock_repo.clear_all = AsyncMock(return_value=0)

        db = AsyncMock()
        result = await service.clear_whitelist(db, application_id=FAKE_APP_ID)

        assert "Cleared 0" in result["message"]


# ===========================================================================
# remove_from_whitelist
# ===========================================================================


class TestRemoveFromWhitelist:
    @patch(_REPO)
    async def test_success(self, mock_repo):
        """Removes entry and returns success message."""
        mock_repo.delete_by_email = AsyncMock(return_value=True)

        db = AsyncMock()
        result = await service.remove_from_whitelist(
            db, application_id=FAKE_APP_ID, email="test@example.com"
        )

        assert "removed from whitelist" in result["message"]

    @patch(_REPO)
    async def test_not_found_raises_404(self, mock_repo):
        """Raises NotFoundError when email not found."""
        mock_repo.delete_by_email = AsyncMock(return_value=False)

        db = AsyncMock()
        with pytest.raises(NotFoundError):
            await service.remove_from_whitelist(
                db, application_id=FAKE_APP_ID, email="unknown@example.com"
            )

    @patch(_REPO)
    async def test_lowercases_email(self, mock_repo):
        """Email is lowercased for deletion."""
        mock_repo.delete_by_email = AsyncMock(return_value=True)

        db = AsyncMock()
        await service.remove_from_whitelist(
            db, application_id=FAKE_APP_ID, email="Test@EXAMPLE.com"
        )

        call_args = mock_repo.delete_by_email.call_args
        assert call_args[0][2] == "test@example.com"
