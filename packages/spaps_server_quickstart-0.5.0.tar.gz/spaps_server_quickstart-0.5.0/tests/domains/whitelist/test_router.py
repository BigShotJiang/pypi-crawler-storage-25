"""Unit tests for the whitelist domain router (HTTP layer).

Each test creates a minimal FastAPI test app with dependency overrides for
the database session, application, and current user.  The whitelist service
layer is fully mocked so tests exercise only routing, request validation,
status codes, and response shapes.
"""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from spaps_server_quickstart.domains.whitelist.router import router
from spaps_server_quickstart.middleware.error_handler import install_error_handlers
from spaps_server_quickstart.middleware.spaps_deps import (
    get_application,
    get_current_user,
    get_db_session,
)


# ---------------------------------------------------------------------------
# Helpers / Constants
# ---------------------------------------------------------------------------

FAKE_USER_ID = str(uuid4())
FAKE_APP_ID = str(uuid4())
FAKE_ENTRY_ID = str(uuid4())

_SERVICE = "spaps_server_quickstart.domains.whitelist.service"


def _fake_entry(
    email: str = "test@example.com",
    tier: str = "premium",
) -> dict:
    """Return a realistic whitelist entry dict."""
    return {
        "id": FAKE_ENTRY_ID,
        "application_id": FAKE_APP_ID,
        "email": email,
        "tier": tier,
        "bypass_payment": True,
        "metadata": {},
        "created_by": FAKE_USER_ID,
        "created_at": datetime.now(UTC).isoformat(),
        "updated_at": datetime.now(UTC).isoformat(),
    }


def _fake_user():
    """Return a mock authenticated user."""
    user = MagicMock()
    user.id = FAKE_USER_ID
    user.email = "admin@example.com"
    user.username = "admin"
    user.tier = "premium"
    user.roles = ["admin"]
    user.permissions = ["manage_whitelist"]
    user.is_admin = True
    user.is_super_admin = False
    user.wallet_addresses = []
    return user


def _fake_application():
    """Return a mock application."""
    app = MagicMock()
    app.id = FAKE_APP_ID
    app.name = "Test App"
    app.whitelist_enabled = True
    return app


def _create_test_app(*, include_user: bool = True):
    """Create a FastAPI test app with overridden dependencies."""
    app = FastAPI()

    # Store mock settings on app.state
    settings = MagicMock()
    settings.jwt_secret = "test-secret"
    app.state.settings = settings

    install_error_handlers(app)
    app.include_router(router)

    # Override dependencies
    mock_db = AsyncMock()

    async def override_db_session():
        yield mock_db

    app.dependency_overrides[get_db_session] = override_db_session
    app.dependency_overrides[get_application] = _fake_application

    if include_user:
        app.dependency_overrides[get_current_user] = _fake_user

    return app


@pytest.fixture
def test_app():
    return _create_test_app()


@pytest.fixture
def test_app_no_auth():
    return _create_test_app(include_user=False)


@pytest.fixture
async def client(test_app):
    transport = ASGITransport(app=test_app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


@pytest.fixture
async def client_no_auth(test_app_no_auth):
    transport = ASGITransport(app=test_app_no_auth)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


# ===========================================================================
# GET /v1/whitelist/check
# ===========================================================================


class TestCheckWhitelist:
    @patch(f"{_SERVICE}.check_whitelist", new_callable=AsyncMock)
    async def test_found(self, mock_check, client: AsyncClient):
        """GET /v1/whitelist/check returns entry when whitelisted."""
        mock_check.return_value = {
            "entry": _fake_entry(),
            "message": "Email test@example.com is whitelisted",
        }

        resp = await client.get(
            "/v1/whitelist/check", params={"email": "test@example.com"}
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["entry"]["email"] == "test@example.com"
        assert "whitelisted" in data["message"]

    @patch(f"{_SERVICE}.check_whitelist", new_callable=AsyncMock)
    async def test_not_found(self, mock_check, client: AsyncClient):
        """GET /v1/whitelist/check returns no entry when not whitelisted."""
        mock_check.return_value = {
            "message": "Email unknown@example.com is not whitelisted",
        }

        resp = await client.get(
            "/v1/whitelist/check", params={"email": "unknown@example.com"}
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["entry"] is None
        assert "not whitelisted" in data["message"]

    async def test_missing_email_returns_400(self, client: AsyncClient):
        """GET /v1/whitelist/check without email param returns 400."""
        resp = await client.get("/v1/whitelist/check")

        assert resp.status_code == 400

    async def test_invalid_email_returns_400(self, client: AsyncClient):
        """GET /v1/whitelist/check with invalid email returns 400."""
        resp = await client.get(
            "/v1/whitelist/check", params={"email": "not-an-email"}
        )

        assert resp.status_code == 400


# ===========================================================================
# POST /v1/whitelist
# ===========================================================================


class TestAddToWhitelist:
    @patch(f"{_SERVICE}.add_to_whitelist", new_callable=AsyncMock)
    async def test_success(self, mock_add, client: AsyncClient):
        """POST /v1/whitelist creates entry and returns 201."""
        mock_add.return_value = {
            "entry": _fake_entry(),
            "message": "Email test@example.com successfully added to whitelist",
        }

        resp = await client.post(
            "/v1/whitelist",
            json={"email": "test@example.com", "tier": "premium"},
        )

        assert resp.status_code == 201
        data = resp.json()
        assert data["entry"]["email"] == "test@example.com"
        assert "successfully added" in data["message"]

    @patch(f"{_SERVICE}.add_to_whitelist", new_callable=AsyncMock)
    async def test_default_tier(self, mock_add, client: AsyncClient):
        """POST /v1/whitelist defaults to premium tier."""
        mock_add.return_value = {
            "entry": _fake_entry(tier="premium"),
            "message": "Email test@example.com successfully added to whitelist",
        }

        resp = await client.post(
            "/v1/whitelist",
            json={"email": "test@example.com"},
        )

        assert resp.status_code == 201
        # Verify the service was called with default tier
        call_kwargs = mock_add.call_args
        assert call_kwargs.kwargs.get("tier", "premium") == "premium"

    @patch(f"{_SERVICE}.add_to_whitelist", new_callable=AsyncMock)
    async def test_duplicate_returns_409(self, mock_add, client: AsyncClient):
        """POST /v1/whitelist returns 409 for duplicate email."""
        from spaps_server_quickstart.domains.errors import DomainError

        mock_add.side_effect = DomainError(
            code="DUPLICATE_ENTRY",
            message="Email test@example.com is already whitelisted",
            status_code=409,
        )

        resp = await client.post(
            "/v1/whitelist",
            json={"email": "test@example.com"},
        )

        assert resp.status_code == 409
        data = resp.json()
        assert data["error"]["code"] == "DUPLICATE_ENTRY"

    async def test_invalid_email_returns_400(self, client: AsyncClient):
        """POST /v1/whitelist with invalid email returns 400."""
        resp = await client.post(
            "/v1/whitelist",
            json={"email": "not-an-email"},
        )

        assert resp.status_code == 400

    async def test_invalid_tier_returns_422(self, client: AsyncClient):
        """POST /v1/whitelist with invalid tier returns validation error."""
        resp = await client.post(
            "/v1/whitelist",
            json={"email": "test@example.com", "tier": "invalid-tier"},
        )

        # FastAPI returns 400 via our error handler for validation errors
        assert resp.status_code == 400


# ===========================================================================
# POST /v1/whitelist/bulk
# ===========================================================================


class TestBulkAddToWhitelist:
    @patch(f"{_SERVICE}.bulk_add", new_callable=AsyncMock)
    async def test_all_succeed(self, mock_bulk, client: AsyncClient):
        """POST /v1/whitelist/bulk returns 201 when all succeed."""
        mock_bulk.return_value = {
            "message": "Added 2 of 2 emails",
            "successful": [
                _fake_entry("a@example.com"),
                _fake_entry("b@example.com"),
            ],
            "failed": [],
            "total": 2,
        }

        resp = await client.post(
            "/v1/whitelist/bulk",
            json={
                "emails": [
                    {"email": "a@example.com"},
                    {"email": "b@example.com"},
                ]
            },
        )

        assert resp.status_code == 201
        data = resp.json()
        assert len(data["successful"]) == 2
        assert len(data["failed"]) == 0
        assert data["total"] == 2

    @patch(f"{_SERVICE}.bulk_add", new_callable=AsyncMock)
    async def test_partial_failure_returns_207(self, mock_bulk, client: AsyncClient):
        """POST /v1/whitelist/bulk returns 207 when some fail."""
        mock_bulk.return_value = {
            "message": "Added 1 of 2 emails",
            "successful": [_fake_entry("a@example.com")],
            "failed": [
                {"email": "b@example.com", "error": "Email already whitelisted"}
            ],
            "total": 2,
        }

        resp = await client.post(
            "/v1/whitelist/bulk",
            json={
                "emails": [
                    {"email": "a@example.com"},
                    {"email": "b@example.com"},
                ]
            },
        )

        assert resp.status_code == 207
        data = resp.json()
        assert len(data["successful"]) == 1
        assert len(data["failed"]) == 1
        assert data["failed"][0]["email"] == "b@example.com"

    async def test_empty_emails_returns_400(self, client: AsyncClient):
        """POST /v1/whitelist/bulk with empty emails returns 400."""
        resp = await client.post(
            "/v1/whitelist/bulk",
            json={"emails": []},
        )

        assert resp.status_code == 400

    async def test_too_many_emails_returns_400(self, client: AsyncClient):
        """POST /v1/whitelist/bulk with >100 emails returns 400."""
        emails = [{"email": f"user{i}@example.com"} for i in range(101)]
        resp = await client.post(
            "/v1/whitelist/bulk",
            json={"emails": emails},
        )

        assert resp.status_code == 400


# ===========================================================================
# GET /v1/whitelist
# ===========================================================================


class TestListWhitelist:
    @patch(f"{_SERVICE}.list_whitelist", new_callable=AsyncMock)
    async def test_success(self, mock_list, client: AsyncClient):
        """GET /v1/whitelist returns entries and total."""
        mock_list.return_value = {
            "entries": [_fake_entry()],
            "total": 1,
        }

        resp = await client.get("/v1/whitelist")

        assert resp.status_code == 200
        data = resp.json()
        assert len(data["entries"]) == 1
        assert data["total"] == 1

    @patch(f"{_SERVICE}.list_whitelist", new_callable=AsyncMock)
    async def test_with_pagination(self, mock_list, client: AsyncClient):
        """GET /v1/whitelist respects limit and offset."""
        mock_list.return_value = {
            "entries": [_fake_entry()],
            "total": 50,
        }

        resp = await client.get(
            "/v1/whitelist", params={"limit": 5, "offset": 10}
        )

        assert resp.status_code == 200
        mock_list.assert_called_once()
        call_kwargs = mock_list.call_args.kwargs
        assert call_kwargs["limit"] == 5
        assert call_kwargs["offset"] == 10

    @patch(f"{_SERVICE}.list_whitelist", new_callable=AsyncMock)
    async def test_filter_by_tier(self, mock_list, client: AsyncClient):
        """GET /v1/whitelist filters by tier parameter."""
        mock_list.return_value = {
            "entries": [_fake_entry(tier="enterprise")],
            "total": 1,
        }

        resp = await client.get(
            "/v1/whitelist", params={"tier": "enterprise"}
        )

        assert resp.status_code == 200
        call_kwargs = mock_list.call_args.kwargs
        assert call_kwargs["tier"] == "enterprise"

    async def test_invalid_limit_returns_400(self, client: AsyncClient):
        """GET /v1/whitelist with limit > 100 returns 400."""
        resp = await client.get(
            "/v1/whitelist", params={"limit": 200}
        )

        assert resp.status_code == 400


# ===========================================================================
# PUT /v1/whitelist/{email}
# ===========================================================================


class TestUpdateWhitelistEntry:
    @patch(f"{_SERVICE}.update_entry", new_callable=AsyncMock)
    async def test_success(self, mock_update, client: AsyncClient):
        """PUT /v1/whitelist/{email} updates and returns entry."""
        mock_update.return_value = {
            "entry": _fake_entry(tier="enterprise"),
            "message": "Whitelist entry for test@example.com updated successfully",
        }

        resp = await client.put(
            "/v1/whitelist/test@example.com",
            json={"tier": "enterprise"},
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["entry"]["tier"] == "enterprise"
        assert "updated successfully" in data["message"]

    @patch(f"{_SERVICE}.update_entry", new_callable=AsyncMock)
    async def test_not_found_returns_404(self, mock_update, client: AsyncClient):
        """PUT /v1/whitelist/{email} returns 404 for unknown email."""
        from spaps_server_quickstart.domains.errors import NotFoundError

        mock_update.side_effect = NotFoundError(
            "Whitelist entry for unknown@example.com not found"
        )

        resp = await client.put(
            "/v1/whitelist/unknown@example.com",
            json={"tier": "basic"},
        )

        assert resp.status_code == 404
        data = resp.json()
        assert data["error"]["code"] == "NOT_FOUND"

    @patch(f"{_SERVICE}.update_entry", new_callable=AsyncMock)
    async def test_update_bypass_payment(self, mock_update, client: AsyncClient):
        """PUT /v1/whitelist/{email} can update bypass_payment."""
        entry = _fake_entry()
        entry["bypass_payment"] = False
        mock_update.return_value = {
            "entry": entry,
            "message": "Whitelist entry for test@example.com updated successfully",
        }

        resp = await client.put(
            "/v1/whitelist/test@example.com",
            json={"bypass_payment": False},
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["entry"]["bypass_payment"] is False


# ===========================================================================
# GET /v1/whitelist/stats
# ===========================================================================


class TestWhitelistStats:
    @patch(f"{_SERVICE}.get_stats", new_callable=AsyncMock)
    async def test_success(self, mock_stats, client: AsyncClient):
        """GET /v1/whitelist/stats returns statistics."""
        mock_stats.return_value = {
            "stats": {
                "enabled": True,
                "total": 42,
                "tierBreakdown": [
                    {"tier": "premium", "count": 30},
                    {"tier": "enterprise", "count": 12},
                ],
            },
        }

        resp = await client.get("/v1/whitelist/stats")

        assert resp.status_code == 200
        data = resp.json()
        assert data["stats"]["enabled"] is True
        assert data["stats"]["total"] == 42
        assert len(data["stats"]["tierBreakdown"]) == 2

    @patch(f"{_SERVICE}.get_stats", new_callable=AsyncMock)
    async def test_empty_whitelist(self, mock_stats, client: AsyncClient):
        """GET /v1/whitelist/stats with no entries."""
        mock_stats.return_value = {
            "stats": {
                "enabled": False,
                "total": 0,
                "tierBreakdown": [],
            },
        }

        resp = await client.get("/v1/whitelist/stats")

        assert resp.status_code == 200
        data = resp.json()
        assert data["stats"]["total"] == 0
        assert data["stats"]["tierBreakdown"] == []


# ===========================================================================
# DELETE /v1/whitelist/all
# ===========================================================================


class TestClearWhitelist:
    @patch(f"{_SERVICE}.clear_whitelist", new_callable=AsyncMock)
    async def test_success(self, mock_clear, client: AsyncClient):
        """DELETE /v1/whitelist/all clears all entries."""
        mock_clear.return_value = {
            "message": "Cleared 5 entries from whitelist",
        }

        resp = await client.delete("/v1/whitelist/all")

        assert resp.status_code == 200
        data = resp.json()
        assert "Cleared 5" in data["message"]

    @patch(f"{_SERVICE}.clear_whitelist", new_callable=AsyncMock)
    async def test_already_empty(self, mock_clear, client: AsyncClient):
        """DELETE /v1/whitelist/all on empty whitelist returns 0 count."""
        mock_clear.return_value = {
            "message": "Cleared 0 entries from whitelist",
        }

        resp = await client.delete("/v1/whitelist/all")

        assert resp.status_code == 200
        data = resp.json()
        assert "Cleared 0" in data["message"]


# ===========================================================================
# DELETE /v1/whitelist/{email}
# ===========================================================================


class TestRemoveFromWhitelist:
    @patch(f"{_SERVICE}.remove_from_whitelist", new_callable=AsyncMock)
    async def test_success(self, mock_remove, client: AsyncClient):
        """DELETE /v1/whitelist/{email} removes entry."""
        mock_remove.return_value = {
            "message": "Email test@example.com removed from whitelist",
        }

        resp = await client.delete("/v1/whitelist/test@example.com")

        assert resp.status_code == 200
        data = resp.json()
        assert "removed from whitelist" in data["message"]

    @patch(f"{_SERVICE}.remove_from_whitelist", new_callable=AsyncMock)
    async def test_not_found_returns_404(self, mock_remove, client: AsyncClient):
        """DELETE /v1/whitelist/{email} returns 404 for unknown email."""
        from spaps_server_quickstart.domains.errors import NotFoundError

        mock_remove.side_effect = NotFoundError(
            "Whitelist entry for unknown@example.com not found"
        )

        resp = await client.delete("/v1/whitelist/unknown@example.com")

        assert resp.status_code == 404
        data = resp.json()
        assert data["error"]["code"] == "NOT_FOUND"
