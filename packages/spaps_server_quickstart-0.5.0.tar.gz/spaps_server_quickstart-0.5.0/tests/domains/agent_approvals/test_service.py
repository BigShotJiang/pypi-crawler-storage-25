"""Unit tests for the agent_approvals domain service layer.

The repository layer is fully mocked so tests exercise only the
service orchestration, business logic, and error handling.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import UUID, uuid4

import pytest

from spaps_server_quickstart.domains.agent_approvals import service
from spaps_server_quickstart.domains.agent_approvals.errors import (
    AgentAlreadyInactiveError,
    AgentInactiveError,
    AgentNameExistsError,
    AgentNotFoundError,
    ApprovalTokenConfigurationError,
    ApprovalAlreadyResolvedError,
    ApprovalExpiredError,
    ApprovalNotFoundError,
    ApproverAlreadyExistsError,
    ApproverNotFoundError,
    InvalidAgentCredentialsError,
    MaxApproversExceededError,
    NotAgentOwnerError,
    NotAuthorizedApproverError,
    ScopeViolationError,
)
from spaps_server_quickstart.domains.affiliate_referrals.errors import ClickNotFoundError

_REPO = "spaps_server_quickstart.domains.agent_approvals.service.repo"

FAKE_APP_ID = uuid4()
FAKE_USER_ID = uuid4()
FAKE_OWNER_ID = uuid4()
FAKE_AGENT_ID = uuid4()


# ---------------------------------------------------------------------------
# Mock factories
# ---------------------------------------------------------------------------


def _make_agent(
    agent_id: UUID | None = None,
    application_id: UUID | None = None,
    owner_user_id: UUID | None = None,
    name: str = "research-bot",
    description: str = "A test agent",
    scopes: list[str] | None = None,
    is_active: bool = True,
    agent_secret_hash: str = "$2b$12$fakehash",
    agent_secret_prefix: str = "spaps_ag",
) -> MagicMock:
    """Build a mock Agent model instance."""
    agent = MagicMock()
    agent.id = agent_id or FAKE_AGENT_ID
    agent.application_id = application_id or FAKE_APP_ID
    agent.owner_user_id = owner_user_id or FAKE_OWNER_ID
    agent.name = name
    agent.description = description
    agent.agent_secret_hash = agent_secret_hash
    agent.agent_secret_prefix = agent_secret_prefix
    agent.scopes = scopes or []
    agent.metadata_ = {}
    agent.is_active = is_active
    agent.created_at = datetime.now(UTC)
    agent.updated_at = datetime.now(UTC)
    return agent


def _make_approver(
    agent_id: UUID | None = None,
    approver_type: str = "user",
    approver_user_id: UUID | None = None,
    approver_agent_id: UUID | None = None,
) -> MagicMock:
    """Build a mock AgentApprover model instance."""
    approver = MagicMock()
    approver.id = uuid4()
    approver.agent_id = agent_id or FAKE_AGENT_ID
    approver.approver_type = approver_type
    approver.approver_user_id = approver_user_id or (uuid4() if approver_type == "user" else None)
    approver.approver_agent_id = approver_agent_id or (uuid4() if approver_type == "agent" else None)
    approver.created_at = datetime.now(UTC)
    return approver


def _make_approval(
    agent_id: UUID | None = None,
    application_id: UUID | None = None,
    status: str = "pending",
    action: str = "secret:read",
    expires_at: datetime | None = None,
    code: str = "ABCD-EFGH",
    transaction_intent: dict | None = None,
    signed_transaction: str | None = None,
    signer_address: str | None = None,
    edited_intent: dict | None = None,
) -> MagicMock:
    """Build a mock AgentApproval model instance."""
    approval = MagicMock()
    approval.id = uuid4()
    approval.application_id = application_id or FAKE_APP_ID
    approval.agent_id = agent_id or FAKE_AGENT_ID
    approval.code = code
    approval.action = action
    approval.resource_type = "env_var"
    approval.resource_id = "OPENAI_API_KEY"
    approval.reason = "Need API key access"
    approval.metadata_ = {}
    approval.status = status
    approval.callback_url = None
    approval.note = None
    approval.responded_by_user_id = None
    approval.responded_by_agent_id = None
    approval.responder_type = None
    approval.responded_at = None
    approval.approval_token = None
    approval.token_expires_at = None
    approval.expires_at = expires_at or (datetime.now(UTC) + timedelta(minutes=15))
    approval.created_at = datetime.now(UTC)
    # Transaction signing fields (tx_signing)
    approval.transaction_intent = transaction_intent
    approval.signed_transaction = signed_transaction
    approval.signer_address = signer_address
    approval.edited_intent = edited_intent
    return approval


# ===========================================================================
# register_agent
# ===========================================================================


class TestRegisterAgent:
    @patch(_REPO)
    async def test_creates_agent_and_returns_secret(self, mock_repo):
        """Registers agent, returns the raw secret once."""
        mock_repo.get_agent_by_name = AsyncMock(return_value=None)
        agent = _make_agent()
        mock_repo.create_agent = AsyncMock(return_value=agent)

        db = AsyncMock()
        result = await service.register_agent(
            db,
            application_id=FAKE_APP_ID,
            owner_user_id=FAKE_OWNER_ID,
            name="research-bot",
            description="A test agent",
            scopes=["secret:read"],
            metadata={},
        )

        assert result["id"] is not None
        assert result["agent_secret"] is not None
        assert result["agent_secret"].startswith("spaps_agent_")
        assert result["name"] == "research-bot"
        mock_repo.create_agent.assert_called_once()

    @patch(_REPO)
    async def test_duplicate_name_raises(self, mock_repo):
        """Raises AgentNameExistsError when name is taken in application."""
        existing = _make_agent(name="research-bot")
        mock_repo.get_agent_by_name = AsyncMock(return_value=existing)

        db = AsyncMock()
        with pytest.raises(AgentNameExistsError):
            await service.register_agent(
                db,
                application_id=FAKE_APP_ID,
                owner_user_id=FAKE_OWNER_ID,
                name="research-bot",
            )

    @patch("spaps_server_quickstart.domains.agent_approvals.service._attribute_agent_referral", new_callable=AsyncMock)
    @patch(_REPO)
    async def test_register_agent_attempts_referral_attribution(
        self, mock_repo, mock_attribute_referral
    ):
        mock_repo.get_agent_by_name = AsyncMock(return_value=None)
        agent = _make_agent()
        mock_repo.create_agent = AsyncMock(return_value=agent)
        mock_attribute_referral.return_value = None

        db = AsyncMock()
        referral_click_id = str(uuid4())
        await service.register_agent(
            db,
            application_id=FAKE_APP_ID,
            owner_user_id=FAKE_OWNER_ID,
            name="research-bot",
            referral_click_id=referral_click_id,
            referral_slug="partner-bot",
        )

        mock_attribute_referral.assert_called_once()
        assert mock_attribute_referral.await_args.kwargs["agent_id"] == agent.id
        assert (
            mock_attribute_referral.await_args.kwargs["referral_click_id"]
            == referral_click_id
        )


class TestAttributeAgentReferral:
    async def test_returns_early_without_referral_identifiers(self):
        db = AsyncMock()

        with patch(
            "spaps_server_quickstart.domains.affiliate_referrals.service.attribute_referral",
            new=AsyncMock(),
        ) as mock_attribute:
            await service._attribute_agent_referral(
                db,
                agent_id=FAKE_AGENT_ID,
                application_id=FAKE_APP_ID,
            )

        mock_attribute.assert_not_awaited()

    async def test_invalid_click_uuid_logs_warning_and_skips(self):
        db = AsyncMock()

        with patch(
            "spaps_server_quickstart.domains.agent_approvals.service.logger"
        ) as mock_logger:
            await service._attribute_agent_referral(
                db,
                agent_id=FAKE_AGENT_ID,
                application_id=FAKE_APP_ID,
                referral_click_id="not-a-uuid",
            )

        mock_logger.warning.assert_called_once()

    async def test_known_referral_errors_are_logged_as_info(self):
        db = AsyncMock()

        with (
            patch(
                "spaps_server_quickstart.domains.agent_approvals.service.logger"
            ) as mock_logger,
            patch(
                "spaps_server_quickstart.domains.affiliate_referrals.service.attribute_referral",
                new=AsyncMock(side_effect=ClickNotFoundError()),
            ),
        ):
            await service._attribute_agent_referral(
                db,
                agent_id=FAKE_AGENT_ID,
                application_id=FAKE_APP_ID,
                referral_click_id=str(uuid4()),
            )

        mock_logger.info.assert_called_once()

    async def test_unexpected_referral_errors_are_logged(self):
        db = AsyncMock()

        with (
            patch(
                "spaps_server_quickstart.domains.agent_approvals.service.logger"
            ) as mock_logger,
            patch(
                "spaps_server_quickstart.domains.affiliate_referrals.service.attribute_referral",
                new=AsyncMock(side_effect=RuntimeError("boom")),
            ),
        ):
            await service._attribute_agent_referral(
                db,
                agent_id=FAKE_AGENT_ID,
                application_id=FAKE_APP_ID,
                referral_slug="partner-bot",
            )

        mock_logger.exception.assert_called_once()


# ===========================================================================
# get_agent
# ===========================================================================


class TestGetAgent:
    @patch(_REPO)
    async def test_returns_agent(self, mock_repo):
        """Returns agent details for owner."""
        agent = _make_agent()
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)

        db = AsyncMock()
        result = await service.get_agent(
            db,
            agent_id=agent.id,
            application_id=FAKE_APP_ID,
            user_id=FAKE_OWNER_ID,
            is_admin=False,
        )

        assert result["id"] == str(agent.id)
        assert "agent_secret" not in result

    @patch(_REPO)
    async def test_not_found_raises(self, mock_repo):
        """Raises AgentNotFoundError for unknown agent."""
        mock_repo.get_agent_by_id = AsyncMock(return_value=None)

        db = AsyncMock()
        with pytest.raises(AgentNotFoundError):
            await service.get_agent(
                db,
                agent_id=uuid4(),
                application_id=FAKE_APP_ID,
                user_id=FAKE_OWNER_ID,
                is_admin=False,
            )

    @patch(_REPO)
    async def test_non_owner_non_admin_raises(self, mock_repo):
        """Raises NotAgentOwnerError when user is not owner and not admin."""
        agent = _make_agent(owner_user_id=uuid4())
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)

        db = AsyncMock()
        with pytest.raises(NotAgentOwnerError):
            await service.get_agent(
                db,
                agent_id=agent.id,
                application_id=FAKE_APP_ID,
                user_id=FAKE_OWNER_ID,
                is_admin=False,
            )

    @patch(_REPO)
    async def test_admin_can_access_any_agent(self, mock_repo):
        """Admin user can view any agent in the application."""
        agent = _make_agent(owner_user_id=uuid4())
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)

        db = AsyncMock()
        result = await service.get_agent(
            db,
            agent_id=agent.id,
            application_id=FAKE_APP_ID,
            user_id=FAKE_OWNER_ID,
            is_admin=True,
        )

        assert result["id"] == str(agent.id)


# ===========================================================================
# list_agents
# ===========================================================================


class TestListAgents:
    @patch(_REPO)
    async def test_returns_owned_agents(self, mock_repo):
        """Returns agents owned by the JWT user."""
        agents = [_make_agent(name="bot-1"), _make_agent(name="bot-2")]
        mock_repo.list_agents = AsyncMock(return_value=agents)
        mock_repo.count_agents = AsyncMock(return_value=2)
        mock_repo.count_pending_approvals_for_agents = AsyncMock(return_value={})

        db = AsyncMock()
        result = await service.list_agents(
            db,
            application_id=FAKE_APP_ID,
            user_id=FAKE_OWNER_ID,
            is_admin=False,
        )

        assert result["total"] == 2
        assert len(result["agents"]) == 2

    @patch(_REPO)
    async def test_admin_sees_all_agents(self, mock_repo):
        """Admin user sees all agents in the application."""
        agents = [_make_agent(name="bot-1")]
        mock_repo.list_agents = AsyncMock(return_value=agents)
        mock_repo.count_agents = AsyncMock(return_value=1)
        mock_repo.count_pending_approvals_for_agents = AsyncMock(return_value={})

        db = AsyncMock()
        result = await service.list_agents(
            db,
            application_id=FAKE_APP_ID,
            user_id=FAKE_OWNER_ID,
            is_admin=True,
        )

        assert result["total"] == 1
        # Admin call passes owner_user_id=None to list all
        call_kwargs = mock_repo.list_agents.call_args.kwargs
        assert call_kwargs.get("owner_user_id") is None


# ===========================================================================
# update_agent
# ===========================================================================


class TestUpdateAgent:
    @patch(_REPO)
    async def test_updates_successfully(self, mock_repo):
        """Updates agent fields and returns updated agent."""
        agent = _make_agent()
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        mock_repo.get_agent_by_name = AsyncMock(return_value=None)
        updated = _make_agent(name="updated-bot")
        mock_repo.update_agent = AsyncMock(return_value=updated)

        db = AsyncMock()
        result = await service.update_agent(
            db,
            agent_id=agent.id,
            application_id=FAKE_APP_ID,
            user_id=FAKE_OWNER_ID,
            is_admin=False,
            name="updated-bot",
        )

        assert result["name"] == "updated-bot"
        assert "agent_secret" not in result

    @patch(_REPO)
    async def test_name_conflict_raises(self, mock_repo):
        """Raises AgentNameExistsError when new name conflicts."""
        agent = _make_agent(name="original")
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        # Another agent with the target name already exists
        other = _make_agent(agent_id=uuid4(), name="taken")
        mock_repo.get_agent_by_name = AsyncMock(return_value=other)

        db = AsyncMock()
        with pytest.raises(AgentNameExistsError):
            await service.update_agent(
                db,
                agent_id=agent.id,
                application_id=FAKE_APP_ID,
                user_id=FAKE_OWNER_ID,
                is_admin=False,
                name="taken",
            )

    @patch(_REPO)
    async def test_non_owner_raises(self, mock_repo):
        """Raises NotAgentOwnerError when user is not owner."""
        agent = _make_agent(owner_user_id=uuid4())
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)

        db = AsyncMock()
        with pytest.raises(NotAgentOwnerError):
            await service.update_agent(
                db,
                agent_id=agent.id,
                application_id=FAKE_APP_ID,
                user_id=FAKE_OWNER_ID,
                is_admin=False,
                name="new-name",
            )


# ===========================================================================
# deactivate_agent
# ===========================================================================


class TestDeactivateAgent:
    @patch(_REPO)
    async def test_deactivates_and_expires_pending(self, mock_repo):
        """Deactivates agent and expires all pending approvals."""
        agent = _make_agent(is_active=True)
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        mock_repo.deactivate_agent = AsyncMock()
        mock_repo.expire_pending_approvals_for_agent = AsyncMock(return_value=0)

        db = AsyncMock()
        result = await service.deactivate_agent(
            db,
            agent_id=agent.id,
            application_id=FAKE_APP_ID,
            user_id=FAKE_OWNER_ID,
            is_admin=False,
        )

        assert result["is_active"] is False
        mock_repo.deactivate_agent.assert_called_once()
        mock_repo.expire_pending_approvals_for_agent.assert_called_once()

    @patch(_REPO)
    async def test_already_inactive_raises(self, mock_repo):
        """Raises AgentAlreadyInactiveError for already-inactive agent."""
        agent = _make_agent(is_active=False)
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)

        db = AsyncMock()
        with pytest.raises(AgentAlreadyInactiveError):
            await service.deactivate_agent(
                db,
                agent_id=agent.id,
                application_id=FAKE_APP_ID,
                user_id=FAKE_OWNER_ID,
                is_admin=False,
            )


# ===========================================================================
# rotate_agent_secret
# ===========================================================================


class TestRotateAgentSecret:
    @patch(_REPO)
    async def test_rotates_and_returns_new_secret(self, mock_repo):
        """Rotates secret and returns the new raw secret."""
        agent = _make_agent()
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        mock_repo.update_agent_secret = AsyncMock()

        db = AsyncMock()
        result = await service.rotate_agent_secret(
            db,
            agent_id=agent.id,
            application_id=FAKE_APP_ID,
            user_id=FAKE_OWNER_ID,
        )

        assert result["agent_secret"].startswith("spaps_agent_")
        assert "rotated" in result["message"].lower()

    @patch(_REPO)
    async def test_non_owner_raises(self, mock_repo):
        """Raises NotAgentOwnerError when user is not owner."""
        agent = _make_agent(owner_user_id=uuid4())
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)

        db = AsyncMock()
        with pytest.raises(NotAgentOwnerError):
            await service.rotate_agent_secret(
                db,
                agent_id=agent.id,
                application_id=FAKE_APP_ID,
                user_id=FAKE_OWNER_ID,
            )


# ===========================================================================
# add_approver
# ===========================================================================


class TestAddApprover:
    @patch(_REPO)
    async def test_adds_user_approver(self, mock_repo):
        """Adds a user as approver."""
        agent = _make_agent()
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        mock_repo.count_approvers = AsyncMock(return_value=0)
        mock_repo.get_approver = AsyncMock(return_value=None)
        mock_repo.user_exists_in_app = AsyncMock(return_value=True)
        approver = _make_approver()
        mock_repo.create_approver = AsyncMock(return_value=approver)

        db = AsyncMock()
        result = await service.add_approver(
            db,
            agent_id=agent.id,
            application_id=FAKE_APP_ID,
            user_id=FAKE_OWNER_ID,
            approver_type="user",
            approver_user_id=uuid4(),
        )

        assert result["approver_type"] == "user"

    @patch(_REPO)
    async def test_adds_agent_approver(self, mock_repo):
        """Adds an agent as approver (supervisor)."""
        agent = _make_agent()
        supervisor = _make_agent(agent_id=uuid4(), name="supervisor-bot")
        mock_repo.get_agent_by_id = AsyncMock(side_effect=[agent, supervisor])
        mock_repo.count_approvers = AsyncMock(return_value=0)
        mock_repo.get_approver = AsyncMock(return_value=None)
        approver = _make_approver(approver_type="agent")
        mock_repo.create_approver = AsyncMock(return_value=approver)

        db = AsyncMock()
        result = await service.add_approver(
            db,
            agent_id=agent.id,
            application_id=FAKE_APP_ID,
            user_id=FAKE_OWNER_ID,
            approver_type="agent",
            approver_agent_id=supervisor.id,
        )

        assert result["approver_type"] == "agent"

    @patch(_REPO)
    async def test_max_approvers_exceeded_raises(self, mock_repo):
        """Raises MaxApproversExceededError when over 20."""
        agent = _make_agent()
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        mock_repo.count_approvers = AsyncMock(return_value=20)

        db = AsyncMock()
        with pytest.raises(MaxApproversExceededError):
            await service.add_approver(
                db,
                agent_id=agent.id,
                application_id=FAKE_APP_ID,
                user_id=FAKE_OWNER_ID,
                approver_type="user",
                approver_user_id=uuid4(),
            )

    @patch(_REPO)
    async def test_already_exists_raises(self, mock_repo):
        """Raises ApproverAlreadyExistsError for duplicate."""
        agent = _make_agent()
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        mock_repo.count_approvers = AsyncMock(return_value=1)
        existing = _make_approver()
        mock_repo.get_approver = AsyncMock(return_value=existing)

        db = AsyncMock()
        with pytest.raises(ApproverAlreadyExistsError):
            await service.add_approver(
                db,
                agent_id=agent.id,
                application_id=FAKE_APP_ID,
                user_id=FAKE_OWNER_ID,
                approver_type="user",
                approver_user_id=existing.approver_user_id,
            )

    @patch(_REPO)
    async def test_approver_user_not_found_raises(self, mock_repo):
        """Raises ApproverNotFoundError when user does not exist in app."""
        agent = _make_agent()
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        mock_repo.count_approvers = AsyncMock(return_value=0)
        mock_repo.get_approver = AsyncMock(return_value=None)
        mock_repo.user_exists_in_app = AsyncMock(return_value=False)

        db = AsyncMock()
        with pytest.raises(ApproverNotFoundError):
            await service.add_approver(
                db,
                agent_id=agent.id,
                application_id=FAKE_APP_ID,
                user_id=FAKE_OWNER_ID,
                approver_type="user",
                approver_user_id=uuid4(),
            )


# ===========================================================================
# list_approvers
# ===========================================================================


class TestListApprovers:
    @patch(_REPO)
    async def test_returns_enriched_approvers_and_implicit_owner(self, mock_repo):
        """Lists approvers with user and agent enrichment plus implicit owner."""
        owner_id = uuid4()
        user_approver_id = uuid4()
        supervisor_id = uuid4()
        agent = _make_agent(owner_user_id=owner_id)
        user_approver = _make_approver(
            agent_id=agent.id,
            approver_type="user",
            approver_user_id=user_approver_id,
        )
        agent_approver = _make_approver(
            agent_id=agent.id,
            approver_type="agent",
            approver_agent_id=supervisor_id,
        )
        supervisor = _make_agent(agent_id=supervisor_id, name="supervisor-bot")

        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        mock_repo.list_approvers = AsyncMock(return_value=[user_approver, agent_approver])
        mock_repo.get_user_emails_by_ids = AsyncMock(
            return_value={
                user_approver_id: "approver@example.com",
                owner_id: "owner@example.com",
            }
        )
        mock_repo.get_agents_by_ids = AsyncMock(return_value={supervisor_id: supervisor})

        db = AsyncMock()
        result = await service.list_approvers(
            db,
            agent_id=agent.id,
            application_id=FAKE_APP_ID,
            user_id=owner_id,
            is_admin=False,
        )

        assert result["total"] == 3
        assert result["owner"] == {
            "user_id": str(owner_id),
            "email": "owner@example.com",
            "implicit": True,
        }
        assert result["approvers"][0]["approver_email"] == "approver@example.com"
        assert result["approvers"][1]["approver_agent_name"] == "supervisor-bot"
        assert mock_repo.get_user_emails_by_ids.await_args.args[1] == [
            user_approver_id,
            owner_id,
        ]
        assert mock_repo.get_agents_by_ids.await_args.args[1] == [supervisor_id]

    @patch(_REPO)
    async def test_admin_can_list_non_owned_agent(self, mock_repo):
        """Admins can list approvers even when they do not own the agent."""
        owner_id = uuid4()
        agent = _make_agent(owner_user_id=owner_id)

        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        mock_repo.list_approvers = AsyncMock(return_value=[])
        mock_repo.get_user_emails_by_ids = AsyncMock(
            return_value={owner_id: "owner@example.com"}
        )

        db = AsyncMock()
        result = await service.list_approvers(
            db,
            agent_id=agent.id,
            application_id=FAKE_APP_ID,
            user_id=uuid4(),
            is_admin=True,
        )

        assert result["total"] == 1
        assert result["approvers"] == []
        mock_repo.get_agents_by_ids.assert_not_called()

    @patch(_REPO)
    async def test_non_owner_non_admin_raises(self, mock_repo):
        """Non-owners cannot list approvers unless they are admins."""
        agent = _make_agent(owner_user_id=uuid4())
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)

        db = AsyncMock()
        with pytest.raises(NotAgentOwnerError):
            await service.list_approvers(
                db,
                agent_id=agent.id,
                application_id=FAKE_APP_ID,
                user_id=FAKE_OWNER_ID,
                is_admin=False,
            )

        mock_repo.list_approvers.assert_not_called()


# ===========================================================================
# remove_approver
# ===========================================================================


class TestRemoveApprover:
    @patch(_REPO)
    async def test_removes_approver(self, mock_repo):
        """Removes an approver successfully."""
        agent = _make_agent()
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        approver = _make_approver()
        mock_repo.get_approver_by_id = AsyncMock(return_value=approver)
        mock_repo.delete_approver = AsyncMock()

        db = AsyncMock()
        result = await service.remove_approver(
            db,
            agent_id=agent.id,
            approver_id=approver.id,
            application_id=FAKE_APP_ID,
            user_id=FAKE_OWNER_ID,
        )

        assert "removed" in result["message"].lower()
        mock_repo.delete_approver.assert_called_once()

    @patch(_REPO)
    async def test_approver_not_found_raises(self, mock_repo):
        """Raises ApproverNotFoundError when approver does not exist."""
        agent = _make_agent()
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        mock_repo.get_approver_by_id = AsyncMock(return_value=None)

        db = AsyncMock()
        with pytest.raises(ApproverNotFoundError):
            await service.remove_approver(
                db,
                agent_id=agent.id,
                approver_id=uuid4(),
                application_id=FAKE_APP_ID,
                user_id=FAKE_OWNER_ID,
            )


# ===========================================================================
# create_approval
# ===========================================================================


class TestCreateApproval:
    @patch(_REPO)
    async def test_creates_pending_approval(self, mock_repo):
        """Creates a pending approval for a valid agent."""
        agent = _make_agent(scopes=["secret:read"])
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        approval = _make_approval()
        mock_repo.create_approval = AsyncMock(return_value=approval)
        # Mock the application for verification_url_base
        mock_app = MagicMock()
        mock_app.settings = {}
        mock_repo.get_application = AsyncMock(return_value=mock_app)

        db = AsyncMock()
        result = await service.create_approval(
            db,
            agent_id=agent.id,
            application_id=FAKE_APP_ID,
            action="secret:read",
            resource_type="env_var",
            resource_id="OPENAI_API_KEY",
            reason="Need access",
            expires_in=900,
        )

        assert result["status"] == "pending"
        assert result["code"] is not None
        assert "verification_url" in result

    @patch(_REPO)
    async def test_agent_not_found_raises(self, mock_repo):
        """Raises AgentNotFoundError for unknown agent."""
        mock_repo.get_agent_by_id = AsyncMock(return_value=None)

        db = AsyncMock()
        with pytest.raises(AgentNotFoundError):
            await service.create_approval(
                db,
                agent_id=uuid4(),
                application_id=FAKE_APP_ID,
                action="secret:read",
            )

    @patch(_REPO)
    async def test_inactive_agent_raises(self, mock_repo):
        """Raises AgentInactiveError for deactivated agent."""
        agent = _make_agent(is_active=False)
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)

        db = AsyncMock()
        with pytest.raises(AgentInactiveError):
            await service.create_approval(
                db,
                agent_id=agent.id,
                application_id=FAKE_APP_ID,
                action="secret:read",
            )

    @patch(_REPO)
    async def test_scope_violation_raises(self, mock_repo):
        """Raises ScopeViolationError when action is outside agent's scopes."""
        agent = _make_agent(scopes=["secret:read", "deploy:staging"])
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)

        db = AsyncMock()
        with pytest.raises(ScopeViolationError):
            await service.create_approval(
                db,
                agent_id=agent.id,
                application_id=FAKE_APP_ID,
                action="deploy:prod",  # Not matching any scope
            )

    @patch(_REPO)
    async def test_empty_scopes_allows_any_action(self, mock_repo):
        """Agent with empty scopes allows any action."""
        agent = _make_agent(scopes=[])
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        approval = _make_approval(action="anything")
        mock_repo.create_approval = AsyncMock(return_value=approval)
        mock_app = MagicMock()
        mock_app.settings = {}
        mock_repo.get_application = AsyncMock(return_value=mock_app)

        db = AsyncMock()
        result = await service.create_approval(
            db,
            agent_id=agent.id,
            application_id=FAKE_APP_ID,
            action="anything",
        )

        assert result["status"] == "pending"

    @patch(_REPO)
    async def test_scope_prefix_match(self, mock_repo):
        """Action matching a scope prefix is allowed."""
        agent = _make_agent(scopes=["secret:read"])
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        approval = _make_approval(action="secret:read:openai")
        mock_repo.create_approval = AsyncMock(return_value=approval)
        mock_app = MagicMock()
        mock_app.settings = {}
        mock_repo.get_application = AsyncMock(return_value=mock_app)

        db = AsyncMock()
        result = await service.create_approval(
            db,
            agent_id=agent.id,
            application_id=FAKE_APP_ID,
            action="secret:read:openai",
        )

        assert result["status"] == "pending"


# ===========================================================================
# get_approval
# ===========================================================================


class TestGetApproval:
    @patch(_REPO)
    async def test_returns_pending_approval(self, mock_repo):
        """Returns pending approval with expires_at."""
        approval = _make_approval(status="pending")
        agent = _make_agent()
        mock_repo.get_approval_by_id = AsyncMock(return_value=approval)
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)

        db = AsyncMock()
        result = await service.get_approval(
            db,
            approval_id=approval.id,
            application_id=FAKE_APP_ID,
        )

        assert result["status"] == "pending"

    @patch(_REPO)
    async def test_returns_approved_with_token(self, mock_repo):
        """Returns approved approval with approval_token."""
        approval = _make_approval(status="approved")
        approval.approval_token = "eyJhbGciOiJIUzI1NiIs..."
        approval.token_expires_at = datetime.now(UTC) + timedelta(hours=1)
        approval.responded_at = datetime.now(UTC)
        approval.responded_by_user_id = FAKE_OWNER_ID
        agent = _make_agent()
        mock_repo.get_approval_by_id = AsyncMock(return_value=approval)
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)

        db = AsyncMock()
        result = await service.get_approval(
            db,
            approval_id=approval.id,
            application_id=FAKE_APP_ID,
        )

        assert result["status"] == "approved"
        assert result["approval_token"] is not None

    @patch(_REPO)
    async def test_lazy_expiration(self, mock_repo):
        """Pending approval past expires_at returns as expired."""
        approval = _make_approval(
            status="pending",
            expires_at=datetime.now(UTC) - timedelta(minutes=1),
        )
        agent = _make_agent()
        mock_repo.get_approval_by_id = AsyncMock(return_value=approval)
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)

        db = AsyncMock()
        result = await service.get_approval(
            db,
            approval_id=approval.id,
            application_id=FAKE_APP_ID,
        )

        assert result["status"] == "expired"

    @patch(_REPO)
    async def test_not_found_raises(self, mock_repo):
        """Raises ApprovalNotFoundError for unknown approval."""
        mock_repo.get_approval_by_id = AsyncMock(return_value=None)

        db = AsyncMock()
        with pytest.raises(ApprovalNotFoundError):
            await service.get_approval(
                db,
                approval_id=uuid4(),
                application_id=FAKE_APP_ID,
            )


# ===========================================================================
# get_approval_by_code
# ===========================================================================


class TestGetApprovalByCode:
    @patch(_REPO)
    async def test_returns_approval(self, mock_repo):
        """Returns approval by verification code for authorized approver."""
        approval = _make_approval()
        agent = _make_agent(owner_user_id=FAKE_OWNER_ID)
        mock_repo.get_approval_by_code = AsyncMock(return_value=approval)
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        mock_repo.is_authorized_approver = AsyncMock(return_value=True)

        db = AsyncMock()
        result = await service.get_approval_by_code(
            db,
            code="ABCD-EFGH",
            application_id=FAKE_APP_ID,
            user_id=FAKE_OWNER_ID,
        )

        assert result["code"] == "ABCD-EFGH"

    @patch(_REPO)
    async def test_not_found_raises(self, mock_repo):
        """Raises ApprovalNotFoundError for unknown code."""
        mock_repo.get_approval_by_code = AsyncMock(return_value=None)

        db = AsyncMock()
        with pytest.raises(ApprovalNotFoundError):
            await service.get_approval_by_code(
                db,
                code="XXXX-YYYY",
                application_id=FAKE_APP_ID,
                user_id=FAKE_OWNER_ID,
            )

    @patch(_REPO)
    async def test_non_approver_raises(self, mock_repo):
        """Raises NotAuthorizedApproverError for non-approver user."""
        approval = _make_approval()
        agent = _make_agent(owner_user_id=uuid4())  # Different owner
        mock_repo.get_approval_by_code = AsyncMock(return_value=approval)
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        mock_repo.is_authorized_approver = AsyncMock(return_value=False)

        db = AsyncMock()
        with pytest.raises(NotAuthorizedApproverError):
            await service.get_approval_by_code(
                db,
                code="ABCD-EFGH",
                application_id=FAKE_APP_ID,
                user_id=FAKE_OWNER_ID,
            )


# ===========================================================================
# respond_to_approval (approve / deny)
# ===========================================================================


class TestRespondToApproval:
    @patch(_REPO)
    async def test_approve_by_owner(self, mock_repo):
        """Owner approves a pending approval."""
        approval = _make_approval(status="pending")
        agent = _make_agent(owner_user_id=FAKE_OWNER_ID)
        mock_repo.get_approval_by_id_for_update = AsyncMock(return_value=approval)
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        mock_repo.is_authorized_approver = AsyncMock(return_value=True)
        mock_repo.update_approval_status = AsyncMock()

        db = AsyncMock()
        settings = MagicMock()
        settings.jwt_secret = "test-secret"

        result = await service.respond_to_approval(
            db,
            approval_id=approval.id,
            application_id=FAKE_APP_ID,
            action="approve",
            responder_type="user",
            responder_user_id=FAKE_OWNER_ID,
            settings=settings,
        )

        assert result["status"] == "approved"
        mock_repo.update_approval_status.assert_called_once()
        mock_repo.get_approval_by_id_for_update.assert_awaited_once_with(
            db,
            approval.id,
            application_id=FAKE_APP_ID,
        )

    @patch(_REPO)
    async def test_approve_uses_locked_lookup(self, mock_repo):
        """Uses FOR UPDATE lookup to prevent concurrent double-resolution races."""
        approval = _make_approval(status="pending")
        agent = _make_agent(owner_user_id=FAKE_OWNER_ID)
        mock_repo.get_approval_by_id_for_update = AsyncMock(return_value=approval)
        mock_repo.get_approval_by_id = AsyncMock(side_effect=AssertionError("unlocked lookup should not be used"))
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        mock_repo.is_authorized_approver = AsyncMock(return_value=True)
        mock_repo.update_approval_status = AsyncMock()

        db = AsyncMock()
        settings = MagicMock()
        settings.jwt_secret = "test-secret"

        result = await service.respond_to_approval(
            db,
            approval_id=approval.id,
            application_id=FAKE_APP_ID,
            action="approve",
            responder_type="user",
            responder_user_id=FAKE_OWNER_ID,
            settings=settings,
        )

        assert result["status"] == "approved"
        mock_repo.get_approval_by_id_for_update.assert_awaited_once()

    @patch(_REPO)
    async def test_approve_without_jwt_secret_fails_closed(self, mock_repo):
        """Approvals must not mint tokens if jwt_secret is missing."""
        approval = _make_approval(status="pending")
        agent = _make_agent(owner_user_id=FAKE_OWNER_ID)
        mock_repo.get_approval_by_id_for_update = AsyncMock(return_value=approval)
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        mock_repo.is_authorized_approver = AsyncMock(return_value=True)
        mock_repo.update_approval_status = AsyncMock()

        db = AsyncMock()
        settings = MagicMock()
        settings.jwt_secret = ""

        with pytest.raises(
            ApprovalTokenConfigurationError,
            match="Approval token signing key is not configured",
        ):
            await service.respond_to_approval(
                db,
                approval_id=approval.id,
                application_id=FAKE_APP_ID,
                action="approve",
                responder_type="user",
                responder_user_id=FAKE_OWNER_ID,
                settings=settings,
            )

        mock_repo.update_approval_status.assert_not_called()

    @patch(_REPO)
    async def test_deny_by_owner(self, mock_repo):
        """Owner denies a pending approval."""
        approval = _make_approval(status="pending")
        agent = _make_agent(owner_user_id=FAKE_OWNER_ID)
        mock_repo.get_approval_by_id_for_update = AsyncMock(return_value=approval)
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        mock_repo.is_authorized_approver = AsyncMock(return_value=True)
        mock_repo.update_approval_status = AsyncMock()

        db = AsyncMock()
        settings = MagicMock()
        settings.jwt_secret = "test-secret"

        result = await service.respond_to_approval(
            db,
            approval_id=approval.id,
            application_id=FAKE_APP_ID,
            action="deny",
            responder_type="user",
            responder_user_id=FAKE_OWNER_ID,
            note="Not authorized",
            settings=settings,
        )

        assert result["status"] == "denied"

    @patch(_REPO)
    async def test_already_resolved_raises(self, mock_repo):
        """Raises ApprovalAlreadyResolvedError for non-pending approval."""
        approval = _make_approval(status="approved")
        agent = _make_agent(owner_user_id=FAKE_OWNER_ID)
        mock_repo.get_approval_by_id_for_update = AsyncMock(return_value=approval)
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)

        db = AsyncMock()
        settings = MagicMock()

        with pytest.raises(ApprovalAlreadyResolvedError):
            await service.respond_to_approval(
                db,
                approval_id=approval.id,
                application_id=FAKE_APP_ID,
                action="approve",
                responder_type="user",
                responder_user_id=FAKE_OWNER_ID,
                settings=settings,
            )

    @patch(_REPO)
    async def test_expired_approval_raises(self, mock_repo):
        """Raises ApprovalExpiredError when TTL exceeded."""
        approval = _make_approval(
            status="pending",
            expires_at=datetime.now(UTC) - timedelta(minutes=1),
        )
        agent = _make_agent(owner_user_id=FAKE_OWNER_ID)
        mock_repo.get_approval_by_id_for_update = AsyncMock(return_value=approval)
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)

        db = AsyncMock()
        settings = MagicMock()

        with pytest.raises(ApprovalExpiredError):
            await service.respond_to_approval(
                db,
                approval_id=approval.id,
                application_id=FAKE_APP_ID,
                action="approve",
                responder_type="user",
                responder_user_id=FAKE_OWNER_ID,
                settings=settings,
            )

    @patch(_REPO)
    async def test_non_approver_raises(self, mock_repo):
        """Raises NotAuthorizedApproverError for unauthorized user."""
        approval = _make_approval(status="pending")
        agent = _make_agent(owner_user_id=uuid4())  # Different owner
        mock_repo.get_approval_by_id_for_update = AsyncMock(return_value=approval)
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        mock_repo.is_authorized_approver = AsyncMock(return_value=False)

        db = AsyncMock()
        settings = MagicMock()

        with pytest.raises(NotAuthorizedApproverError):
            await service.respond_to_approval(
                db,
                approval_id=approval.id,
                application_id=FAKE_APP_ID,
                action="approve",
                responder_type="user",
                responder_user_id=FAKE_OWNER_ID,
                settings=settings,
            )

    @patch(_REPO)
    async def test_agent_as_approver(self, mock_repo):
        """Supervisor agent approves a request."""
        approval = _make_approval(status="pending")
        agent = _make_agent()
        supervisor = _make_agent(agent_id=uuid4(), name="supervisor-bot")
        mock_repo.get_approval_by_id_for_update = AsyncMock(return_value=approval)
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        mock_repo.is_authorized_approver = AsyncMock(return_value=True)
        mock_repo.update_approval_status = AsyncMock()

        db = AsyncMock()
        settings = MagicMock()
        settings.jwt_secret = "test-secret"

        result = await service.respond_to_approval(
            db,
            approval_id=approval.id,
            application_id=FAKE_APP_ID,
            action="approve",
            responder_type="agent",
            responder_agent_id=supervisor.id,
            settings=settings,
        )

        assert result["status"] == "approved"


# ===========================================================================
# list_approvals (history)
# ===========================================================================


class TestListApprovals:
    @patch(_REPO)
    async def test_returns_approvals_for_owned_agents(self, mock_repo):
        """Returns approvals for agents owned by user."""
        approvals = [_make_approval(), _make_approval()]
        mock_repo.list_approvals = AsyncMock(return_value=approvals)
        mock_repo.count_approvals = AsyncMock(return_value=2)
        # Mock agent lookups for enrichment
        agent = _make_agent()
        mock_repo.get_agents_by_ids = AsyncMock(return_value={FAKE_AGENT_ID: agent})

        db = AsyncMock()
        result = await service.list_approvals(
            db,
            application_id=FAKE_APP_ID,
            user_id=FAKE_OWNER_ID,
            is_admin=False,
        )

        assert result["total"] == 2
        assert len(result["approvals"]) == 2

    @patch(_REPO)
    async def test_list_includes_reason_and_metadata(self, mock_repo):
        """List approvals exposes reason and metadata payload fields."""
        approval = _make_approval()
        approval.reason = "Need transfer approval"
        approval.metadata_ = {"chain": "solana", "priority": "high"}

        mock_repo.list_approvals = AsyncMock(return_value=[approval])
        mock_repo.count_approvals = AsyncMock(return_value=1)
        agent = _make_agent()
        mock_repo.get_agents_by_ids = AsyncMock(return_value={FAKE_AGENT_ID: agent})

        db = AsyncMock()
        result = await service.list_approvals(
            db,
            application_id=FAKE_APP_ID,
            user_id=FAKE_OWNER_ID,
            is_admin=False,
        )

        item = result["approvals"][0]
        assert item["reason"] == "Need transfer approval"
        assert item["metadata"] == {"chain": "solana", "priority": "high"}

    @patch(_REPO)
    async def test_filter_by_status(self, mock_repo):
        """Passes status filter to repository."""
        mock_repo.list_approvals = AsyncMock(return_value=[])
        mock_repo.count_approvals = AsyncMock(return_value=0)
        mock_repo.get_agents_by_ids = AsyncMock(return_value={})

        db = AsyncMock()
        await service.list_approvals(
            db,
            application_id=FAKE_APP_ID,
            user_id=FAKE_OWNER_ID,
            is_admin=False,
            status="approved",
        )

        call_kwargs = mock_repo.list_approvals.call_args.kwargs
        assert call_kwargs.get("status") == "approved"


# ===========================================================================
# authenticate_agent
# ===========================================================================


class TestAuthenticateAgent:
    @patch(_REPO)
    async def test_valid_credentials(self, mock_repo):
        """Returns agent for valid credentials."""
        import bcrypt

        raw_secret = "spaps_agent_testsecretvalue"
        hashed = bcrypt.hashpw(raw_secret.encode(), bcrypt.gensalt()).decode()
        agent = _make_agent(agent_secret_hash=hashed)
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)

        db = AsyncMock()
        result = await service.authenticate_agent(
            db,
            agent_id=agent.id,
            agent_secret=raw_secret,
            application_id=FAKE_APP_ID,
        )

        assert result.id == agent.id

    @patch(_REPO)
    async def test_invalid_secret_raises(self, mock_repo):
        """Raises InvalidAgentCredentialsError for wrong secret."""
        import bcrypt

        real_secret = "spaps_agent_realsecret"
        hashed = bcrypt.hashpw(real_secret.encode(), bcrypt.gensalt()).decode()
        agent = _make_agent(agent_secret_hash=hashed)
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)

        db = AsyncMock()
        with pytest.raises(InvalidAgentCredentialsError):
            await service.authenticate_agent(
                db,
                agent_id=agent.id,
                agent_secret="spaps_agent_wrongsecret",
                application_id=FAKE_APP_ID,
            )

    @patch(_REPO)
    async def test_agent_not_found_raises(self, mock_repo):
        """Raises InvalidAgentCredentialsError for unknown agent."""
        mock_repo.get_agent_by_id = AsyncMock(return_value=None)

        db = AsyncMock()
        with pytest.raises(InvalidAgentCredentialsError):
            await service.authenticate_agent(
                db,
                agent_id=uuid4(),
                agent_secret="spaps_agent_anything",
                application_id=FAKE_APP_ID,
            )

    @patch(_REPO)
    async def test_agent_not_found_can_raise_404_when_requested(self, mock_repo):
        """Raises AgentNotFoundError when reveal_not_found is enabled."""
        mock_repo.get_agent_by_id = AsyncMock(return_value=None)

        db = AsyncMock()
        with pytest.raises(AgentNotFoundError):
            await service.authenticate_agent(
                db,
                agent_id=uuid4(),
                agent_secret="spaps_agent_anything",
                application_id=FAKE_APP_ID,
                reveal_not_found=True,
            )

    @patch(_REPO)
    async def test_inactive_agent_raises(self, mock_repo):
        """Raises AgentInactiveError for deactivated agents."""
        import bcrypt

        raw_secret = "spaps_agent_testsecretvalue"
        hashed = bcrypt.hashpw(raw_secret.encode(), bcrypt.gensalt()).decode()
        agent = _make_agent(agent_secret_hash=hashed, is_active=False)
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)

        db = AsyncMock()
        with pytest.raises(AgentInactiveError):
            await service.authenticate_agent(
                db,
                agent_id=agent.id,
                agent_secret=raw_secret,
                application_id=FAKE_APP_ID,
            )


# ===========================================================================
# Scope enforcement helper
# ===========================================================================


class TestCheckScopeMatch:
    def test_empty_scopes_allows_any(self):
        """Empty scopes list allows any action."""
        assert service._check_scope_match([], "anything") is True

    def test_none_scopes_allows_any(self):
        """None scopes allows any action."""
        assert service._check_scope_match(None, "anything") is True

    def test_exact_match(self):
        """Exact scope match."""
        assert service._check_scope_match(["secret:read"], "secret:read") is True

    def test_prefix_match(self):
        """Prefix scope match."""
        assert service._check_scope_match(["secret:read"], "secret:read:openai") is True

    def test_no_match(self):
        """No matching scope."""
        assert service._check_scope_match(["secret:read"], "deploy:prod") is False

    def test_multiple_scopes_one_matches(self):
        """Multiple scopes, one matches."""
        assert service._check_scope_match(
            ["secret:read", "deploy:staging"],
            "deploy:staging:v2",
        ) is True

    def test_partial_string_not_prefix(self):
        """Partial string match that is NOT a prefix match (no colon boundary)."""
        # "secret:re" should NOT match "secret:read" -- it depends on implementation
        # Per spec: prefix match. "secret:re" is a valid prefix of "secret:read"
        # because the spec says "starts with one of the agent's scopes"
        assert service._check_scope_match(["secret:re"], "secret:read") is True


# ===========================================================================
# Transaction signing (tx_signing) — create_approval with intent
# ===========================================================================


EVM_INTENT = {
    "chain": "evm",
    "chain_id": 8453,
    "to": "0x1234567890abcdef1234567890abcdef12345678",
    "value": "1000000000000000000",
    "data": "0x",
}

SOLANA_INTENT = {
    "chain": "solana",
    "instructions": [
        {
            "program_id": "11111111111111111111111111111111",
            "accounts": [],
            "data": "AQAAAA==",
        }
    ],
    "fee_payer": "9xQeWvG816bUx9EPjHmaT23yvVM2ZWbrrpZb9PusVFin",
}


class TestCreateApprovalWithTransactionIntent:
    @patch(_REPO)
    async def test_create_with_evm_intent(self, mock_repo):
        """Creates approval with EVM transaction_intent, stored and returned in detail."""
        agent = _make_agent(scopes=[])
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        approval = _make_approval(transaction_intent=EVM_INTENT)
        mock_repo.create_approval = AsyncMock(return_value=approval)
        mock_app = MagicMock()
        mock_app.settings = {}
        mock_repo.get_application = AsyncMock(return_value=mock_app)

        db = AsyncMock()
        result = await service.create_approval(
            db,
            agent_id=agent.id,
            application_id=FAKE_APP_ID,
            action="tx:send",
            transaction_intent=EVM_INTENT,
        )

        assert result["status"] == "pending"
        # Verify that transaction_intent was passed to repo
        call_kwargs = mock_repo.create_approval.call_args.kwargs
        assert call_kwargs["transaction_intent"] == EVM_INTENT

    @patch(_REPO)
    async def test_create_with_solana_intent(self, mock_repo):
        """Creates approval with Solana transaction_intent, stored correctly."""
        agent = _make_agent(scopes=[])
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        approval = _make_approval(transaction_intent=SOLANA_INTENT)
        mock_repo.create_approval = AsyncMock(return_value=approval)
        mock_app = MagicMock()
        mock_app.settings = {}
        mock_repo.get_application = AsyncMock(return_value=mock_app)

        db = AsyncMock()
        result = await service.create_approval(
            db,
            agent_id=agent.id,
            application_id=FAKE_APP_ID,
            action="tx:send",
            transaction_intent=SOLANA_INTENT,
        )

        assert result["status"] == "pending"
        call_kwargs = mock_repo.create_approval.call_args.kwargs
        assert call_kwargs["transaction_intent"] == SOLANA_INTENT

    @patch(_REPO)
    async def test_create_without_intent_backward_compatible(self, mock_repo):
        """Creates approval without transaction_intent (backward compatible, 201)."""
        agent = _make_agent(scopes=[])
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        approval = _make_approval()
        mock_repo.create_approval = AsyncMock(return_value=approval)
        mock_app = MagicMock()
        mock_app.settings = {}
        mock_repo.get_application = AsyncMock(return_value=mock_app)

        db = AsyncMock()
        result = await service.create_approval(
            db,
            agent_id=agent.id,
            application_id=FAKE_APP_ID,
            action="secret:read",
        )

        assert result["status"] == "pending"
        # transaction_intent defaults to None in service signature
        call_kwargs = mock_repo.create_approval.call_args.kwargs
        assert call_kwargs["transaction_intent"] is None


# ===========================================================================
# Transaction signing (tx_signing) — get_approval returns intent
# ===========================================================================


class TestGetApprovalWithTransactionIntent:
    @patch(_REPO)
    async def test_get_approval_returns_transaction_intent(self, mock_repo):
        """GET approval with transaction_intent includes it in detail response."""
        approval = _make_approval(
            status="pending",
            transaction_intent=EVM_INTENT,
        )
        agent = _make_agent()
        mock_repo.get_approval_by_id = AsyncMock(return_value=approval)
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)

        db = AsyncMock()
        result = await service.get_approval(
            db,
            approval_id=approval.id,
            application_id=FAKE_APP_ID,
        )

        assert result["status"] == "pending"
        assert result["transaction_intent"] == EVM_INTENT

    @patch(_REPO)
    async def test_get_approval_without_intent_omits_field(self, mock_repo):
        """GET approval without transaction_intent does not include it."""
        approval = _make_approval(status="pending")
        agent = _make_agent()
        mock_repo.get_approval_by_id = AsyncMock(return_value=approval)
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)

        db = AsyncMock()
        result = await service.get_approval(
            db,
            approval_id=approval.id,
            application_id=FAKE_APP_ID,
        )

        assert result["status"] == "pending"
        assert "transaction_intent" not in result

    @patch(_REPO)
    async def test_approved_with_signed_transaction(self, mock_repo):
        """Approved approval with signed_transaction includes it in poll response."""
        approval = _make_approval(
            status="approved",
            transaction_intent=EVM_INTENT,
            signed_transaction="0xf86c808504a817c80082520894...signed",
            signer_address="0xabcdef1234567890abcdef1234567890abcdef12",
        )
        approval.responded_at = datetime.now(UTC)
        approval.responded_by_user_id = FAKE_OWNER_ID
        approval.approval_token = "eyJhbGciOiJIUzI1NiIs..."
        approval.token_expires_at = datetime.now(UTC) + timedelta(hours=1)
        agent = _make_agent()
        mock_repo.get_approval_by_id = AsyncMock(return_value=approval)
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)

        db = AsyncMock()
        result = await service.get_approval(
            db,
            approval_id=approval.id,
            application_id=FAKE_APP_ID,
        )

        assert result["status"] == "approved"
        assert result["transaction_intent"] == EVM_INTENT
        assert result["signed_transaction"] == "0xf86c808504a817c80082520894...signed"
        assert result["signer_address"] == "0xabcdef1234567890abcdef1234567890abcdef12"

    @patch(_REPO)
    async def test_approved_with_edited_intent(self, mock_repo):
        """Approved approval with edited_intent includes both original and edited."""
        edited = {
            "chain": "evm",
            "chain_id": 8453,
            "to": "0x1234567890abcdef1234567890abcdef12345678",
            "value": "500000000000000000",  # Reduced from 1 ETH to 0.5 ETH
            "data": "0x",
        }
        approval = _make_approval(
            status="approved",
            transaction_intent=EVM_INTENT,
            signed_transaction="0xf86c...edited",
            signer_address="0xabcdef1234567890abcdef1234567890abcdef12",
            edited_intent=edited,
        )
        approval.responded_at = datetime.now(UTC)
        approval.responded_by_user_id = FAKE_OWNER_ID
        approval.approval_token = "eyJhbGciOiJIUzI1NiIs..."
        approval.token_expires_at = datetime.now(UTC) + timedelta(hours=1)
        agent = _make_agent()
        mock_repo.get_approval_by_id = AsyncMock(return_value=approval)
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)

        db = AsyncMock()
        result = await service.get_approval(
            db,
            approval_id=approval.id,
            application_id=FAKE_APP_ID,
        )

        assert result["status"] == "approved"
        assert result["transaction_intent"] == EVM_INTENT
        assert result["edited_intent"] == edited
        assert result["edited_intent"]["value"] == "500000000000000000"


# ===========================================================================
# Transaction signing (tx_signing) — respond_to_approval with signing
# ===========================================================================


class TestRespondToApprovalWithSigning:
    @patch(_REPO)
    async def test_approve_with_signed_transaction(self, mock_repo):
        """Respond with signed_transaction stores it on approval."""
        approval = _make_approval(
            status="pending",
            transaction_intent=EVM_INTENT,
        )
        agent = _make_agent(owner_user_id=FAKE_OWNER_ID)
        mock_repo.get_approval_by_id_for_update = AsyncMock(return_value=approval)
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        mock_repo.is_authorized_approver = AsyncMock(return_value=True)
        mock_repo.update_approval_status = AsyncMock()

        db = AsyncMock()
        settings = MagicMock()
        settings.jwt_secret = "test-secret"

        signed_tx = "0xf86c808504a817c80082520894...signedtx"
        signer_addr = "0xabcdef1234567890abcdef1234567890abcdef12"

        result = await service.respond_to_approval(
            db,
            approval_id=approval.id,
            application_id=FAKE_APP_ID,
            action="approve",
            responder_type="user",
            responder_user_id=FAKE_OWNER_ID,
            signed_transaction=signed_tx,
            signer_address=signer_addr,
            settings=settings,
        )

        assert result["status"] == "approved"
        # Verify signed_transaction and signer_address were passed to repo
        call_kwargs = mock_repo.update_approval_status.call_args.kwargs
        assert call_kwargs["signed_transaction"] == signed_tx
        assert call_kwargs["signer_address"] == signer_addr

    @patch(_REPO)
    async def test_approve_without_signed_transaction_still_works(self, mock_repo):
        """Respond without signed_transaction (intent present) still approves."""
        approval = _make_approval(
            status="pending",
            transaction_intent=EVM_INTENT,
        )
        agent = _make_agent(owner_user_id=FAKE_OWNER_ID)
        mock_repo.get_approval_by_id_for_update = AsyncMock(return_value=approval)
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        mock_repo.is_authorized_approver = AsyncMock(return_value=True)
        mock_repo.update_approval_status = AsyncMock()

        db = AsyncMock()
        settings = MagicMock()
        settings.jwt_secret = "test-secret"

        result = await service.respond_to_approval(
            db,
            approval_id=approval.id,
            application_id=FAKE_APP_ID,
            action="approve",
            responder_type="user",
            responder_user_id=FAKE_OWNER_ID,
            settings=settings,
        )

        assert result["status"] == "approved"
        # signed_transaction should be None
        call_kwargs = mock_repo.update_approval_status.call_args.kwargs
        assert call_kwargs["signed_transaction"] is None

    @patch(_REPO)
    async def test_approve_with_edited_intent(self, mock_repo):
        """Respond with edited_intent stores it alongside signed_transaction."""
        approval = _make_approval(
            status="pending",
            transaction_intent=EVM_INTENT,
        )
        agent = _make_agent(owner_user_id=FAKE_OWNER_ID)
        mock_repo.get_approval_by_id_for_update = AsyncMock(return_value=approval)
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        mock_repo.is_authorized_approver = AsyncMock(return_value=True)
        mock_repo.update_approval_status = AsyncMock()

        db = AsyncMock()
        settings = MagicMock()
        settings.jwt_secret = "test-secret"

        edited = {
            "chain": "evm",
            "chain_id": 8453,
            "to": "0x1234567890abcdef1234567890abcdef12345678",
            "value": "500000000000000000",
            "data": "0x",
        }

        result = await service.respond_to_approval(
            db,
            approval_id=approval.id,
            application_id=FAKE_APP_ID,
            action="approve",
            responder_type="user",
            responder_user_id=FAKE_OWNER_ID,
            signed_transaction="0xf86c...edited",
            signer_address="0xabcdef1234567890abcdef1234567890abcdef12",
            edited_intent=edited,
            settings=settings,
        )

        assert result["status"] == "approved"
        call_kwargs = mock_repo.update_approval_status.call_args.kwargs
        assert call_kwargs["edited_intent"] == edited
        assert call_kwargs["signed_transaction"] == "0xf86c...edited"

    @patch(_REPO)
    async def test_deny_with_intent_present_no_signing_needed(self, mock_repo):
        """Deny an approval with transaction_intent — no signing required."""
        approval = _make_approval(
            status="pending",
            transaction_intent=EVM_INTENT,
        )
        agent = _make_agent(owner_user_id=FAKE_OWNER_ID)
        mock_repo.get_approval_by_id_for_update = AsyncMock(return_value=approval)
        mock_repo.get_agent_by_id = AsyncMock(return_value=agent)
        mock_repo.is_authorized_approver = AsyncMock(return_value=True)
        mock_repo.update_approval_status = AsyncMock()

        db = AsyncMock()
        settings = MagicMock()
        settings.jwt_secret = "test-secret"

        result = await service.respond_to_approval(
            db,
            approval_id=approval.id,
            application_id=FAKE_APP_ID,
            action="deny",
            responder_type="user",
            responder_user_id=FAKE_OWNER_ID,
            note="Transaction not approved",
            settings=settings,
        )

        assert result["status"] == "denied"
        call_kwargs = mock_repo.update_approval_status.call_args.kwargs
        assert call_kwargs["signed_transaction"] is None


# ===========================================================================
# Transaction signing (tx_signing) — list_approvals includes tx fields
# ===========================================================================


class TestListApprovalsWithTransactionIntent:
    @patch(_REPO)
    async def test_list_includes_transaction_intent(self, mock_repo):
        """List approvals includes transaction_intent when present."""
        approval_with_intent = _make_approval(transaction_intent=EVM_INTENT)
        approval_with_intent.responded_at = None
        approval_without = _make_approval()
        approval_without.responded_at = None

        mock_repo.list_approvals = AsyncMock(
            return_value=[approval_with_intent, approval_without]
        )
        mock_repo.count_approvals = AsyncMock(return_value=2)
        agent = _make_agent()
        mock_repo.get_agents_by_ids = AsyncMock(return_value={FAKE_AGENT_ID: agent})

        db = AsyncMock()
        result = await service.list_approvals(
            db,
            application_id=FAKE_APP_ID,
            user_id=FAKE_OWNER_ID,
            is_admin=False,
        )

        assert result["total"] == 2
        # First approval should have transaction_intent
        assert result["approvals"][0]["transaction_intent"] == EVM_INTENT
        # Second should have None
        assert result["approvals"][1]["transaction_intent"] is None

    @patch(_REPO)
    async def test_list_includes_signed_transaction(self, mock_repo):
        """List approvals includes signed_transaction when present."""
        approval = _make_approval(
            status="approved",
            transaction_intent=EVM_INTENT,
            signed_transaction="0xf86c...signed",
        )
        approval.responded_at = datetime.now(UTC)

        mock_repo.list_approvals = AsyncMock(return_value=[approval])
        mock_repo.count_approvals = AsyncMock(return_value=1)
        agent = _make_agent()
        mock_repo.get_agents_by_ids = AsyncMock(return_value={FAKE_AGENT_ID: agent})

        db = AsyncMock()
        result = await service.list_approvals(
            db,
            application_id=FAKE_APP_ID,
            user_id=FAKE_OWNER_ID,
            is_admin=False,
        )

        assert result["approvals"][0]["signed_transaction"] == "0xf86c...signed"


# ===========================================================================
# Transaction signing (tx_signing) — schema validation
# ===========================================================================


class TestTransactionIntentSchemaValidation:
    """Pydantic schema validation for transaction intent types."""

    def test_valid_evm_intent(self):
        """Valid EVM intent passes validation."""
        from spaps_server_quickstart.domains.agent_approvals.schemas import (
            TransactionIntentEVM,
        )

        intent = TransactionIntentEVM(
            chain="evm",
            chain_id=8453,
            to="0x1234567890abcdef1234567890abcdef12345678",
            value="1000000000000000000",
            data="0x",
        )
        assert intent.chain == "evm"
        assert intent.chain_id == 8453
        assert intent.to == "0x1234567890abcdef1234567890abcdef12345678"

    def test_evm_intent_missing_to_raises(self):
        """EVM intent without 'to' raises ValidationError."""
        from pydantic import ValidationError as PydanticValidationError

        from spaps_server_quickstart.domains.agent_approvals.schemas import (
            TransactionIntentEVM,
        )

        with pytest.raises(PydanticValidationError):
            TransactionIntentEVM(
                chain="evm",
                chain_id=8453,
                value="1000000000000000000",
            )

    def test_evm_intent_invalid_to_pattern_raises(self):
        """EVM intent with invalid 'to' pattern raises ValidationError."""
        from pydantic import ValidationError as PydanticValidationError

        from spaps_server_quickstart.domains.agent_approvals.schemas import (
            TransactionIntentEVM,
        )

        with pytest.raises(PydanticValidationError):
            TransactionIntentEVM(
                chain="evm",
                chain_id=8453,
                to="not-a-hex-address",
                value="1000000000000000000",
            )

    def test_evm_intent_invalid_value_pattern_raises(self):
        """EVM intent with non-decimal 'value' raises ValidationError."""
        from pydantic import ValidationError as PydanticValidationError

        from spaps_server_quickstart.domains.agent_approvals.schemas import (
            TransactionIntentEVM,
        )

        with pytest.raises(PydanticValidationError):
            TransactionIntentEVM(
                chain="evm",
                chain_id=8453,
                to="0x1234567890abcdef1234567890abcdef12345678",
                value="not-a-number",
            )

    def test_evm_intent_invalid_chain_id_raises(self):
        """EVM intent with chain_id <= 0 raises ValidationError."""
        from pydantic import ValidationError as PydanticValidationError

        from spaps_server_quickstart.domains.agent_approvals.schemas import (
            TransactionIntentEVM,
        )

        with pytest.raises(PydanticValidationError):
            TransactionIntentEVM(
                chain="evm",
                chain_id=0,
                to="0x1234567890abcdef1234567890abcdef12345678",
                value="1000",
            )

    def test_valid_solana_intent(self):
        """Valid Solana intent passes validation."""
        from spaps_server_quickstart.domains.agent_approvals.schemas import (
            TransactionIntentSolana,
        )

        intent = TransactionIntentSolana(
            chain="solana",
            instructions=[{
                "program_id": "11111111111111111111111111111111",
                "accounts": [],
                "data": "AQAAAA==",
            }],
        )
        assert intent.chain == "solana"
        assert len(intent.instructions) == 1

    def test_solana_intent_empty_instructions_raises(self):
        """Solana intent with empty instructions list raises ValidationError."""
        from pydantic import ValidationError as PydanticValidationError

        from spaps_server_quickstart.domains.agent_approvals.schemas import (
            TransactionIntentSolana,
        )

        with pytest.raises(PydanticValidationError):
            TransactionIntentSolana(
                chain="solana",
                instructions=[],
            )

    def test_create_approval_request_with_evm_intent(self):
        """CreateApprovalRequest parses EVM intent via discriminator."""
        from spaps_server_quickstart.domains.agent_approvals.schemas import (
            CreateApprovalRequest,
        )

        req = CreateApprovalRequest(
            action="tx:send",
            transaction_intent={
                "chain": "evm",
                "chain_id": 1,
                "to": "0x1234567890abcdef1234567890abcdef12345678",
                "value": "0",
                "data": "0xabcdef",
            },
        )
        assert req.transaction_intent is not None
        assert req.transaction_intent.chain == "evm"

    def test_create_approval_request_with_solana_intent(self):
        """CreateApprovalRequest parses Solana intent via discriminator."""
        from spaps_server_quickstart.domains.agent_approvals.schemas import (
            CreateApprovalRequest,
        )

        req = CreateApprovalRequest(
            action="tx:send",
            transaction_intent={
                "chain": "solana",
                "instructions": [{"program_id": "x", "accounts": [], "data": "AA=="}],
            },
        )
        assert req.transaction_intent is not None
        assert req.transaction_intent.chain == "solana"

    def test_create_approval_request_without_intent(self):
        """CreateApprovalRequest works without transaction_intent (backward compat)."""
        from spaps_server_quickstart.domains.agent_approvals.schemas import (
            CreateApprovalRequest,
        )

        req = CreateApprovalRequest(action="secret:read")
        assert req.transaction_intent is None

    def test_respond_request_with_signing_fields(self):
        """RespondToApprovalRequest accepts signing fields."""
        from spaps_server_quickstart.domains.agent_approvals.schemas import (
            RespondToApprovalRequest,
        )

        req = RespondToApprovalRequest(
            action="approve",
            note="LGTM",
            signed_transaction="0xf86c...",
            signer_address="0xabcdef1234567890abcdef1234567890abcdef12",
            edited_intent={
                "chain": "evm",
                "chain_id": 8453,
                "to": "0x1234567890abcdef1234567890abcdef12345678",
                "value": "500000000000000000",
                "data": "0x",
            },
        )
        assert req.signed_transaction == "0xf86c..."
        assert req.signer_address == "0xabcdef1234567890abcdef1234567890abcdef12"
        assert req.edited_intent is not None
        assert req.edited_intent.chain == "evm"

    def test_respond_request_without_signing_fields(self):
        """RespondToApprovalRequest works without signing fields (backward compat)."""
        from spaps_server_quickstart.domains.agent_approvals.schemas import (
            RespondToApprovalRequest,
        )

        req = RespondToApprovalRequest(
            action="approve",
            note="Looks good",
        )
        assert req.signed_transaction is None
        assert req.signer_address is None
        assert req.edited_intent is None
