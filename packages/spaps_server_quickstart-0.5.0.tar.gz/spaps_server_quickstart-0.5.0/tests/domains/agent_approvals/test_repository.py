"""Unit tests for the agent approvals repository layer."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

from spaps_server_quickstart.domains.agent_approvals import repository as repo

FAKE_APP_ID = uuid4()


def _mock_db_result(items):
    result = MagicMock()
    scalars_mock = MagicMock()
    scalars_mock.all.return_value = items
    result.scalars.return_value = scalars_mock
    return result


class TestListApprovals:
    async def test_applies_owner_and_filter_clauses(self):
        approvals = [MagicMock()]
        db = AsyncMock()
        db.execute.return_value = _mock_db_result(approvals)

        result = await repo.list_approvals(
            db,
            FAKE_APP_ID,
            owner_user_id=uuid4(),
            agent_id=uuid4(),
            status="pending",
            since="2026-01-01T00:00:00+00:00",
            limit=5,
            offset=10,
        )

        assert result == approvals
        sql = str(db.execute.await_args.args[0])
        assert "agent_approvals.application_id" in sql
        assert "agents.owner_user_id" in sql
        assert "agent_approvals.agent_id" in sql
        assert "agent_approvals.status" in sql
        assert "agent_approvals.created_at" in sql


class TestCountApprovals:
    async def test_counts_approvals_with_filters(self):
        db = AsyncMock()
        count_result = MagicMock()
        count_result.scalar.return_value = 4
        db.execute.return_value = count_result

        count = await repo.count_approvals(
            db,
            FAKE_APP_ID,
            owner_user_id=uuid4(),
            agent_id=uuid4(),
            status="approved",
            since="2026-01-01T00:00:00+00:00",
        )

        assert count == 4
        sql = str(db.execute.await_args.args[0])
        assert "count(*)" in sql.lower()
        assert "agents.owner_user_id" in sql
        assert "agent_approvals.status" in sql

    async def test_returns_zero_when_scalar_is_none(self):
        db = AsyncMock()
        count_result = MagicMock()
        count_result.scalar.return_value = None
        db.execute.return_value = count_result

        count = await repo.count_approvals(db, FAKE_APP_ID)

        assert count == 0
