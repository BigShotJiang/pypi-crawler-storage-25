"""API route tests for the agent_approvals domain.

These tests verify route wiring, error code to HTTP status mapping,
and auth requirement enforcement. Service logic is tested in test_service.py.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from spaps_server_quickstart.domains.agent_approvals.router import (
    agents_router,
    approvals_router,
)
from spaps_server_quickstart.domains.agent_approvals.errors import (
    AgentInactiveError,
    AgentAlreadyInactiveError,
    AgentNameExistsError,
    AgentNotFoundError,
    ApprovalExpiredError,
    ApprovalNotFoundError,
    InvalidAgentCredentialsError,
    NotAgentOwnerError,
)
from spaps_server_quickstart.middleware.error_handler import install_error_handlers

_SVC = "spaps_server_quickstart.domains.agent_approvals.router.service"

FAKE_APP_ID = str(uuid4())
FAKE_USER_ID = str(uuid4())
FAKE_AGENT_ID = str(uuid4())
FAKE_APPROVAL_ID = str(uuid4())


# ---------------------------------------------------------------------------
# Test app setup
# ---------------------------------------------------------------------------


def _make_test_app() -> FastAPI:
    """Create a minimal FastAPI app for testing routes."""
    app = FastAPI()
    install_error_handlers(app)

    # Simulated settings on app.state
    settings = MagicMock()
    settings.jwt_secret = "test-secret"
    app.state.settings = settings

    app.include_router(agents_router, prefix="/api")
    app.include_router(approvals_router, prefix="/api")
    return app


def _make_user(
    user_id: str = FAKE_USER_ID,
    is_admin: bool = False,
    application_id: str = FAKE_APP_ID,
    permissions: list[str] | None = None,
) -> MagicMock:
    """Create a mock authenticated user."""
    user = MagicMock()
    user.id = user_id
    user.application_id = application_id
    user.is_admin = is_admin
    user.is_super_admin = False
    user.permissions = permissions or [
        "approval_request.read",
        "approval_request.review",
    ]
    return user


def _make_application(app_id: str = FAKE_APP_ID) -> MagicMock:
    """Create a mock application."""
    app = MagicMock()
    app.id = app_id
    app.settings = {}
    return app


@pytest.fixture
def app():
    return _make_test_app()


@pytest.fixture
def client(app):
    return TestClient(app, raise_server_exceptions=False)


# ===========================================================================
# POST /api/agents -- Register agent
# ===========================================================================


class TestRegisterAgentRoute:
    @patch(_SVC)
    def test_register_success(self, mock_svc, client, app):
        """POST /api/agents returns 201 with agent data."""
        mock_svc.register_agent = AsyncMock(return_value={
            "id": FAKE_AGENT_ID,
            "name": "research-bot",
            "description": "Test",
            "application_id": FAKE_APP_ID,
            "owner_user_id": FAKE_USER_ID,
            "agent_secret": "spaps_agent_xxxx",
            "scopes": [],
            "is_active": True,
            "metadata": {},
            "created_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
        })

        # Override dependencies
        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_current_user,
            get_db_session,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_current_user] = lambda: _make_user()

        response = client.post("/api/agents", json={
            "name": "research-bot",
            "description": "Test",
            "scopes": [],
        })

        assert response.status_code == 201

    @patch(_SVC)
    def test_register_name_conflict_returns_409(self, mock_svc, client, app):
        """POST /api/agents with duplicate name returns 409."""
        mock_svc.register_agent = AsyncMock(side_effect=AgentNameExistsError())

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_current_user,
            get_db_session,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_current_user] = lambda: _make_user()

        response = client.post("/api/agents", json={
            "name": "research-bot",
        })

        assert response.status_code == 409
        assert response.json()["error"]["code"] == "AGENT_NAME_EXISTS"

    @patch(_SVC)
    def test_register_passes_referral_fields(self, mock_svc, client, app):
        mock_svc.register_agent = AsyncMock(return_value={
            "id": FAKE_AGENT_ID,
            "name": "research-bot",
            "description": "Test",
            "application_id": FAKE_APP_ID,
            "owner_user_id": FAKE_USER_ID,
            "agent_secret": "spaps_agent_xxxx",
            "scopes": [],
            "is_active": True,
            "metadata": {},
            "created_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
        })

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_current_user,
            get_db_session,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_current_user] = lambda: _make_user()

        referral_click_id = str(uuid4())
        response = client.post("/api/agents", json={
            "name": "research-bot",
            "referral_click_id": referral_click_id,
            "ref": "partner-bot",
        })

        assert response.status_code == 201
        kwargs = mock_svc.register_agent.await_args.kwargs
        assert kwargs["referral_click_id"] == referral_click_id
        assert kwargs["referral_slug"] == "partner-bot"


# ===========================================================================
# GET /api/agents -- List agents
# ===========================================================================


class TestListAgentsRoute:
    @patch(_SVC)
    def test_list_success(self, mock_svc, client, app):
        """GET /api/agents returns 200 with agent list."""
        mock_svc.list_agents = AsyncMock(return_value={
            "agents": [{"id": FAKE_AGENT_ID, "name": "bot-1"}],
            "total": 1,
        })

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_current_user,
            get_db_session,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_current_user] = lambda: _make_user()

        response = client.get("/api/agents")

        assert response.status_code == 200


# ===========================================================================
# GET /api/agents/:id -- Agent detail
# ===========================================================================


class TestGetAgentRoute:
    @patch(_SVC)
    def test_get_success(self, mock_svc, client, app):
        """GET /api/agents/:id returns 200."""
        mock_svc.get_agent = AsyncMock(return_value={
            "id": FAKE_AGENT_ID,
            "name": "research-bot",
        })

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_current_user,
            get_db_session,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_current_user] = lambda: _make_user()

        response = client.get(f"/api/agents/{FAKE_AGENT_ID}")

        assert response.status_code == 200

    @patch(_SVC)
    def test_get_not_found_returns_404(self, mock_svc, client, app):
        """GET /api/agents/:id for unknown agent returns 404."""
        mock_svc.get_agent = AsyncMock(side_effect=AgentNotFoundError())

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_current_user,
            get_db_session,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_current_user] = lambda: _make_user()

        response = client.get(f"/api/agents/{uuid4()}")

        assert response.status_code == 404
        assert response.json()["error"]["code"] == "AGENT_NOT_FOUND"

    @patch(_SVC)
    def test_get_non_owner_returns_403(self, mock_svc, client, app):
        """GET /api/agents/:id by non-owner returns 403."""
        mock_svc.get_agent = AsyncMock(side_effect=NotAgentOwnerError())

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_current_user,
            get_db_session,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_current_user] = lambda: _make_user()

        response = client.get(f"/api/agents/{FAKE_AGENT_ID}")

        assert response.status_code == 403


# ===========================================================================
# PUT /api/agents/:id -- Update agent
# ===========================================================================


class TestUpdateAgentRoute:
    @patch(_SVC)
    def test_update_success(self, mock_svc, client, app):
        """PUT /api/agents/:id returns 200 with updated agent."""
        mock_svc.update_agent = AsyncMock(return_value={
            "id": FAKE_AGENT_ID,
            "name": "updated-bot",
        })

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_current_user,
            get_db_session,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_current_user] = lambda: _make_user()

        response = client.put(
            f"/api/agents/{FAKE_AGENT_ID}",
            json={"name": "updated-bot"},
        )

        assert response.status_code == 200


# ===========================================================================
# DELETE /api/agents/:id -- Deactivate agent
# ===========================================================================


class TestDeactivateAgentRoute:
    @patch(_SVC)
    def test_deactivate_success(self, mock_svc, client, app):
        """DELETE /api/agents/:id returns 200."""
        mock_svc.deactivate_agent = AsyncMock(return_value={
            "id": FAKE_AGENT_ID,
            "is_active": False,
            "message": "Agent deactivated",
        })

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_current_user,
            get_db_session,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_current_user] = lambda: _make_user()

        response = client.delete(f"/api/agents/{FAKE_AGENT_ID}")

        assert response.status_code == 200

    @patch(_SVC)
    def test_deactivate_already_inactive_returns_400(self, mock_svc, client, app):
        """DELETE /api/agents/:id for inactive agent returns 400."""
        mock_svc.deactivate_agent = AsyncMock(side_effect=AgentAlreadyInactiveError())

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_current_user,
            get_db_session,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_current_user] = lambda: _make_user()

        response = client.delete(f"/api/agents/{FAKE_AGENT_ID}")

        assert response.status_code == 400
        assert response.json()["error"]["code"] == "AGENT_ALREADY_INACTIVE"


# ===========================================================================
# POST /api/approvals -- Create approval request
# ===========================================================================


class TestCreateApprovalRoute:
    @patch(_SVC)
    def test_create_success(self, mock_svc, client, app):
        """POST /api/approvals returns 201 with approval data."""
        mock_svc.authenticate_agent = AsyncMock(return_value=MagicMock(
            id=FAKE_AGENT_ID,
            application_id=FAKE_APP_ID,
        ))
        mock_svc.create_approval = AsyncMock(return_value={
            "id": FAKE_APPROVAL_ID,
            "status": "pending",
            "verification_url": "https://openclawth.com/approve?code=ABCD-EFGH",
            "code": "ABCD-EFGH",
            "expires_at": "2026-01-01T00:15:00Z",
            "expires_in": 900,
        })

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()

        response = client.post(
            "/api/approvals",
            json={
                "action": "secret:read",
                "resource_type": "env_var",
                "resource_id": "OPENAI_API_KEY",
                "reason": "Need access",
            },
            headers={
                "X-Agent-Id": FAKE_AGENT_ID,
                "X-Agent-Secret": "spaps_agent_xxxx",
            },
        )

        assert response.status_code == 201

    @patch(_SVC)
    def test_create_invalid_credentials_returns_401(self, mock_svc, client, app):
        """POST /api/approvals with bad credentials returns 401."""
        mock_svc.authenticate_agent = AsyncMock(
            side_effect=InvalidAgentCredentialsError()
        )

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()

        response = client.post(
            "/api/approvals",
            json={"action": "secret:read"},
            headers={
                "X-Agent-Id": FAKE_AGENT_ID,
                "X-Agent-Secret": "wrong",
            },
        )

        assert response.status_code == 401

    @patch(_SVC)
    def test_create_unknown_agent_returns_404(self, mock_svc, client, app):
        """POST /api/approvals for unknown agent returns 404."""
        mock_svc.authenticate_agent = AsyncMock(
            side_effect=AgentNotFoundError()
        )

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()

        response = client.post(
            "/api/approvals",
            json={"action": "secret:read"},
            headers={
                "X-Agent-Id": FAKE_AGENT_ID,
                "X-Agent-Secret": "spaps_agent_anything",
            },
        )

        assert response.status_code == 404
        assert response.json()["error"]["code"] == "AGENT_NOT_FOUND"

    @patch(_SVC)
    def test_create_invalid_agent_id_returns_400(self, mock_svc, client, app):
        """POST /api/approvals with invalid X-Agent-Id returns 400."""
        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()

        response = client.post(
            "/api/approvals",
            json={"action": "secret:read"},
            headers={
                "X-Agent-Id": "not-a-uuid",
                "X-Agent-Secret": "spaps_agent_xxxx",
            },
        )

        assert response.status_code == 400
        assert response.json()["error"]["code"] == "VALIDATION_ERROR"
        mock_svc.authenticate_agent.assert_not_called()


# ===========================================================================
# GET /api/approvals/:id -- Poll approval
# ===========================================================================


class TestGetApprovalRoute:
    @patch(_SVC)
    def test_get_success(self, mock_svc, client, app):
        """GET /api/approvals/:id returns 200."""
        mock_svc.get_approval = AsyncMock(return_value={
            "id": FAKE_APPROVAL_ID,
            "status": "pending",
            "agent_id": FAKE_AGENT_ID,
            "agent_name": "research-bot",
        })

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()

        response = client.get(f"/api/approvals/{FAKE_APPROVAL_ID}")

        assert response.status_code == 200

    @patch(_SVC)
    def test_get_not_found_returns_404(self, mock_svc, client, app):
        """GET /api/approvals/:id for unknown returns 404."""
        mock_svc.get_approval = AsyncMock(side_effect=ApprovalNotFoundError())

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()

        response = client.get(f"/api/approvals/{uuid4()}")

        assert response.status_code == 404


# ===========================================================================
# POST /api/approvals/:id/respond -- Approve/Deny
# ===========================================================================


class TestRespondToApprovalRoute:
    @patch(_SVC)
    def test_approve_success(self, mock_svc, client, app):
        """POST /api/approvals/:id/respond with approve returns 200."""
        mock_svc.respond_to_approval = AsyncMock(return_value={
            "id": FAKE_APPROVAL_ID,
            "status": "approved",
            "approved_at": "2026-01-01T00:05:00Z",
            "message": "Approval granted",
        })

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
            get_optional_user,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_optional_user] = lambda: _make_user()

        response = client.post(
            f"/api/approvals/{FAKE_APPROVAL_ID}/respond",
            json={"action": "approve", "note": "Looks good"},
        )

        assert response.status_code == 200

    @patch(_SVC)
    def test_respond_expired_returns_400(self, mock_svc, client, app):
        """POST /api/approvals/:id/respond for expired returns 400."""
        mock_svc.respond_to_approval = AsyncMock(
            side_effect=ApprovalExpiredError()
        )

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
            get_optional_user,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_optional_user] = lambda: _make_user()

        response = client.post(
            f"/api/approvals/{FAKE_APPROVAL_ID}/respond",
            json={"action": "approve"},
        )

        assert response.status_code == 400
        assert response.json()["error"]["code"] == "APPROVAL_EXPIRED"

    @patch(_SVC)
    def test_respond_invalid_approval_id_returns_400(self, mock_svc, client, app):
        """POST /api/approvals/:id/respond with invalid UUID returns 400."""
        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
            get_optional_user,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_optional_user] = lambda: _make_user()

        response = client.post(
            "/api/approvals/not-a-uuid/respond",
            json={"action": "approve"},
        )

        assert response.status_code == 400
        assert response.json()["error"]["code"] == "VALIDATION_ERROR"
        mock_svc.respond_to_approval.assert_not_called()

    @patch(_SVC)
    def test_respond_agent_approver_inactive_returns_403(self, mock_svc, client, app):
        """POST /api/approvals/:id/respond rejects inactive agent approver."""
        mock_svc.authenticate_agent = AsyncMock(side_effect=AgentInactiveError())
        mock_svc.respond_to_approval = AsyncMock()

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
            get_optional_user,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_optional_user] = lambda: None

        response = client.post(
            f"/api/approvals/{FAKE_APPROVAL_ID}/respond",
            json={"action": "approve"},
            headers={
                "X-Agent-Id": FAKE_AGENT_ID,
                "X-Agent-Secret": "spaps_agent_xxxx",
            },
        )

        assert response.status_code == 403
        assert response.json()["error"]["code"] == "AGENT_INACTIVE"
        mock_svc.respond_to_approval.assert_not_called()


# ===========================================================================
# Transaction signing (tx_signing) — route tests
# ===========================================================================


class TestCreateApprovalWithIntentRoute:
    @patch(_SVC)
    def test_create_with_evm_intent_returns_201(self, mock_svc, client, app):
        """POST /api/approvals with EVM transaction_intent returns 201."""
        mock_svc.authenticate_agent = AsyncMock(return_value=MagicMock(
            id=FAKE_AGENT_ID,
            application_id=FAKE_APP_ID,
        ))
        mock_svc.create_approval = AsyncMock(return_value={
            "id": FAKE_APPROVAL_ID,
            "status": "pending",
            "verification_url": "https://openclawth.com/approve?code=ABCD-EFGH",
            "code": "ABCD-EFGH",
            "expires_at": "2026-01-01T00:15:00Z",
            "expires_in": 900,
        })

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()

        response = client.post(
            "/api/approvals",
            json={
                "action": "tx:send",
                "transaction_intent": {
                    "chain": "evm",
                    "chain_id": 8453,
                    "to": "0x1234567890abcdef1234567890abcdef12345678",
                    "value": "1000000000000000000",
                    "data": "0x",
                },
            },
            headers={
                "X-Agent-Id": FAKE_AGENT_ID,
                "X-Agent-Secret": "spaps_agent_xxxx",
            },
        )

        assert response.status_code == 201
        # Verify service was called with serialized intent (model_dump includes defaults)
        call_kwargs = mock_svc.create_approval.call_args.kwargs
        intent = call_kwargs["transaction_intent"]
        assert intent["chain"] == "evm"
        assert intent["chain_id"] == 8453
        assert intent["to"] == "0x1234567890abcdef1234567890abcdef12345678"
        assert intent["value"] == "1000000000000000000"
        assert intent["data"] == "0x"

    @patch(_SVC)
    def test_create_with_invalid_evm_intent_returns_422(self, mock_svc, client, app):
        """POST /api/approvals with invalid EVM intent (bad to address) returns 422."""
        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()

        response = client.post(
            "/api/approvals",
            json={
                "action": "tx:send",
                "transaction_intent": {
                    "chain": "evm",
                    "chain_id": 8453,
                    "to": "not-a-valid-address",
                    "value": "1000",
                },
            },
            headers={
                "X-Agent-Id": FAKE_AGENT_ID,
                "X-Agent-Secret": "spaps_agent_xxxx",
            },
        )

        # Pydantic validation errors are caught by error_handler and returned as 400
        assert response.status_code == 400
        assert response.json()["error"]["code"] == "VALIDATION_ERROR"

    @patch(_SVC)
    def test_create_with_solana_intent_returns_201(self, mock_svc, client, app):
        """POST /api/approvals with Solana transaction_intent returns 201."""
        mock_svc.authenticate_agent = AsyncMock(return_value=MagicMock(
            id=FAKE_AGENT_ID,
            application_id=FAKE_APP_ID,
        ))
        mock_svc.create_approval = AsyncMock(return_value={
            "id": FAKE_APPROVAL_ID,
            "status": "pending",
            "verification_url": "https://openclawth.com/approve?code=ABCD-EFGH",
            "code": "ABCD-EFGH",
            "expires_at": "2026-01-01T00:15:00Z",
            "expires_in": 900,
        })

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()

        response = client.post(
            "/api/approvals",
            json={
                "action": "tx:send",
                "transaction_intent": {
                    "chain": "solana",
                    "instructions": [
                        {
                            "program_id": "11111111111111111111111111111111",
                            "accounts": [],
                            "data": "AQAAAA==",
                        }
                    ],
                },
            },
            headers={
                "X-Agent-Id": FAKE_AGENT_ID,
                "X-Agent-Secret": "spaps_agent_xxxx",
            },
        )

        assert response.status_code == 201


class TestRespondWithSigningRoute:
    @patch(_SVC)
    def test_respond_with_signed_transaction(self, mock_svc, client, app):
        """POST /api/approvals/:id/respond with signing fields returns 200."""
        mock_svc.respond_to_approval = AsyncMock(return_value={
            "id": FAKE_APPROVAL_ID,
            "status": "approved",
            "approved_at": "2026-01-01T00:05:00Z",
            "message": "Approval granted",
        })

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
            get_optional_user,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_optional_user] = lambda: _make_user()

        response = client.post(
            f"/api/approvals/{FAKE_APPROVAL_ID}/respond",
            json={
                "action": "approve",
                "note": "Signed and approved",
                "signed_transaction": "0xf86c808504a817c80082520894...signed",
                "signer_address": "0xabcdef1234567890abcdef1234567890abcdef12",
            },
        )

        assert response.status_code == 200
        # Verify signing fields were passed to service
        call_kwargs = mock_svc.respond_to_approval.call_args.kwargs
        assert call_kwargs["signed_transaction"] == "0xf86c808504a817c80082520894...signed"
        assert call_kwargs["signer_address"] == "0xabcdef1234567890abcdef1234567890abcdef12"

    @patch(_SVC)
    def test_respond_with_edited_intent(self, mock_svc, client, app):
        """POST /api/approvals/:id/respond with edited_intent returns 200."""
        mock_svc.respond_to_approval = AsyncMock(return_value={
            "id": FAKE_APPROVAL_ID,
            "status": "approved",
            "approved_at": "2026-01-01T00:05:00Z",
            "message": "Approval granted",
        })

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
            get_optional_user,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_optional_user] = lambda: _make_user()

        response = client.post(
            f"/api/approvals/{FAKE_APPROVAL_ID}/respond",
            json={
                "action": "approve",
                "signed_transaction": "0xf86c...edited",
                "signer_address": "0xabcdef1234567890abcdef1234567890abcdef12",
                "edited_intent": {
                    "chain": "evm",
                    "chain_id": 8453,
                    "to": "0x1234567890abcdef1234567890abcdef12345678",
                    "value": "500000000000000000",
                    "data": "0x",
                },
            },
        )

        assert response.status_code == 200
        call_kwargs = mock_svc.respond_to_approval.call_args.kwargs
        edited = call_kwargs["edited_intent"]
        # model_dump includes all fields with defaults (gas_limit: None)
        assert edited["chain"] == "evm"
        assert edited["chain_id"] == 8453
        assert edited["to"] == "0x1234567890abcdef1234567890abcdef12345678"
        assert edited["value"] == "500000000000000000"
        assert edited["data"] == "0x"

    @patch(_SVC)
    def test_get_approval_includes_tx_fields(self, mock_svc, client, app):
        """GET /api/approvals/:id returns tx_signing fields when present."""
        mock_svc.get_approval = AsyncMock(return_value={
            "id": FAKE_APPROVAL_ID,
            "status": "approved",
            "agent_id": FAKE_AGENT_ID,
            "agent_name": "research-bot",
            "action": "tx:send",
            "transaction_intent": {
                "chain": "evm",
                "chain_id": 8453,
                "to": "0x1234567890abcdef1234567890abcdef12345678",
                "value": "1000000000000000000",
                "data": "0x",
            },
            "signed_transaction": "0xf86c...signed",
            "signer_address": "0xabcdef1234567890abcdef1234567890abcdef12",
        })

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()

        response = client.get(f"/api/approvals/{FAKE_APPROVAL_ID}")

        assert response.status_code == 200
        data = response.json()
        assert data["transaction_intent"]["chain"] == "evm"
        assert data["signed_transaction"] == "0xf86c...signed"
        assert data["signer_address"] == "0xabcdef1234567890abcdef1234567890abcdef12"
