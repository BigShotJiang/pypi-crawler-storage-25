"""Unit tests for the support telemetry platform repository layer."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

from sqlalchemy import select

from spaps_server_quickstart.domains.support_telemetry_platform import repository as repo
from spaps_server_quickstart.domains.support_telemetry_platform.models import SupportCase


class TestApplyCaseFilters:
    def test_applies_all_supported_filters(self):
        stmt = repo._apply_case_filters(
            select(SupportCase),
            application_id=uuid4(),
            status="open",
            priority="high",
            severity_gte="error",
            assigned_to_user_id=uuid4(),
        )

        sql = str(stmt)
        assert "support_cases.application_id" in sql
        assert "support_cases.status" in sql
        assert "support_cases.priority" in sql
        assert "support_cases.assigned_to_user_id" in sql
        assert "support_cases.highest_severity" in sql

    def test_returns_base_statement_when_filters_are_absent(self):
        stmt = repo._apply_case_filters(
            select(SupportCase),
            application_id=None,
            status=None,
            priority=None,
            severity_gte=None,
            assigned_to_user_id=None,
        )

        assert str(stmt) == str(select(SupportCase))


class TestUpdateCaseSummary:
    async def test_updates_summary_fields_when_new_event_expands_scope(self):
        db = AsyncMock()
        case = MagicMock()
        case.first_event_at = datetime.now(UTC)
        case.last_event_at = datetime.now(UTC)
        case.highest_severity = "warning"
        case.title = None

        earlier = case.first_event_at - timedelta(hours=1)
        updated = await repo.update_case_summary(
            db,
            case=case,
            occurred_at=earlier,
            severity="critical",
            title="Escalated issue",
        )

        assert updated is case
        assert case.first_event_at == earlier
        assert case.highest_severity == "critical"
        assert case.title == "Escalated issue"
        db.flush.assert_awaited_once()
        db.refresh.assert_awaited_once_with(case)

    async def test_preserves_existing_title_and_lower_severity(self):
        db = AsyncMock()
        now = datetime.now(UTC)
        case = MagicMock()
        case.first_event_at = now
        case.last_event_at = now
        case.highest_severity = "error"
        case.title = "Existing"

        await repo.update_case_summary(
            db,
            case=case,
            occurred_at=now + timedelta(minutes=5),
            severity="warning",
            title="Ignored",
        )

        assert case.highest_severity == "error"
        assert case.title == "Existing"


class TestUpdateCase:
    async def test_updates_requested_fields(self):
        db = AsyncMock()
        case = MagicMock()
        assignee = uuid4()
        resolved_at = datetime.now(UTC)

        updated = await repo.update_case(
            db,
            case=case,
            status="resolved",
            priority="high",
            assigned_to_user_id=assignee,
            set_assigned_to_user_id=True,
            resolved_at=resolved_at,
            set_resolved_at=True,
        )

        assert updated is case
        assert case.status == "resolved"
        assert case.priority == "high"
        assert case.assigned_to_user_id == assignee
        assert case.resolved_at == resolved_at
        db.flush.assert_awaited_once()
        db.refresh.assert_awaited_once_with(case)
