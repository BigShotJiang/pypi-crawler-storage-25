"""Tests for support_telemetry_platform domain."""

