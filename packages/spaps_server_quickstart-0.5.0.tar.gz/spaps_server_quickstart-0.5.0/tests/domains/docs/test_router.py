"""Unit tests for the documentation domain routers (HTTP layer).

Each test creates a minimal FastAPI test app with dependency overrides for
the database session and application. The docs service layer is fully
mocked so tests exercise only routing, request validation, status codes,
and response shapes.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from spaps_server_quickstart.domains.docs.router import (
    docs_router,
    openapi_router,
)
from spaps_server_quickstart.middleware.error_handler import install_error_handlers
from spaps_server_quickstart.middleware.spaps_deps import (
    get_application,
    get_db_session,
)

# ---------------------------------------------------------------------------
# Helpers / Constants
# ---------------------------------------------------------------------------

FAKE_APP_ID = str(uuid4())
FAKE_DOC_ID = str(uuid4())

_DOC_SERVICE = "spaps_server_quickstart.domains.docs.service"


def _fake_doc_result(
    title: str = "Getting Started",
    slug: str = "getting-started",
) -> dict:
    """Return a realistic document search result dict."""
    return {
        "id": FAKE_DOC_ID,
        "slug": slug,
        "title": title,
        "content": "Welcome to SPAPS documentation.",
        "category": "guides",
        "tags": ["intro"],
        "score": None,
    }


def _fake_example(language: str = "typescript") -> dict:
    """Return a realistic code example dict."""
    return {
        "id": str(uuid4()),
        "title": "Login Example",
        "description": "How to login",
        "language": language,
        "code": "const res = await fetch(...)",
        "dependencies": None,
        "output": None,
    }


def _fake_endpoint_doc() -> dict:
    """Return a realistic endpoint doc dict."""
    return {
        "id": str(uuid4()),
        "method": "POST",
        "path": "/api/auth/login",
        "description": "Login to the application",
        "authentication": {"type": "api_key"},
        "request_body": {"email": "string", "password": "string"},
        "response_body": {"access_token": "string"},
        "error_codes": {"401": "INVALID_CREDENTIALS"},
        "rate_limit": None,
        "deprecated": False,
    }


def _fake_error_doc() -> dict:
    """Return a realistic error doc dict."""
    return {
        "id": str(uuid4()),
        "code": "INVALID_CREDENTIALS",
        "http_status": 401,
        "message": "Invalid credentials",
        "description": "The provided credentials are invalid.",
        "possible_causes": ["Wrong password"],
        "solutions": ["Reset password"],
        "related_errors": ["UNAUTHORIZED"],
    }


def _fake_category(name: str = "Guides", slug: str = "guides") -> dict:
    """Return a realistic category dict."""
    return {
        "id": str(uuid4()),
        "name": name,
        "slug": slug,
        "description": f"{name} section",
        "order_index": 0,
    }


def _fake_application():
    """Return a mock application."""
    app = MagicMock()
    app.id = FAKE_APP_ID
    app.name = "Test App"
    return app


def _create_test_app():
    """Create a FastAPI test app with docs + openapi routers and overridden deps."""
    app = FastAPI()

    settings = MagicMock()
    settings.jwt_secret = "test-secret"
    app.state.settings = settings

    install_error_handlers(app)
    app.include_router(docs_router)
    app.include_router(openapi_router)

    mock_db = AsyncMock()

    async def override_db_session():
        yield mock_db

    app.dependency_overrides[get_db_session] = override_db_session
    app.dependency_overrides[get_application] = _fake_application

    return app


@pytest.fixture
def test_app():
    return _create_test_app()


@pytest.fixture
async def client(test_app):
    transport = ASGITransport(app=test_app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


# ===========================================================================
# POST /docs/search
# ===========================================================================


class TestSearchDocs:
    @patch(f"{_DOC_SERVICE}.search", new_callable=AsyncMock)
    async def test_success(self, mock_search, client: AsyncClient):
        """POST /docs/search returns search results."""
        mock_search.return_value = {
            "query": "getting started",
            "results": [_fake_doc_result()],
            "total": 1,
            "searchId": str(uuid4()),
        }

        resp = await client.post(
            "/docs/search",
            json={"query": "getting started"},
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 1
        assert len(data["results"]) == 1
        assert data["query"] == "getting started"
        assert data["searchId"] is not None

    @patch(f"{_DOC_SERVICE}.search", new_callable=AsyncMock)
    async def test_with_all_params(self, mock_search, client: AsyncClient):
        """POST /docs/search with all optional params."""
        mock_search.return_value = {
            "query": "auth",
            "results": [],
            "total": 0,
            "searchId": str(uuid4()),
        }

        resp = await client.post(
            "/docs/search",
            json={
                "query": "auth",
                "context": "api-reference",
                "limit": 5,
                "includeExamples": True,
                "language": "python",
            },
        )

        assert resp.status_code == 200

    async def test_query_too_short_returns_400(self, client: AsyncClient):
        """POST /docs/search with query < 3 chars returns 400."""
        resp = await client.post(
            "/docs/search",
            json={"query": "ab"},
        )
        assert resp.status_code == 400

    async def test_missing_query_returns_400(self, client: AsyncClient):
        """POST /docs/search without query returns 400."""
        resp = await client.post(
            "/docs/search",
            json={},
        )
        assert resp.status_code == 400

    async def test_missing_body_returns_400(self, client: AsyncClient):
        """POST /docs/search without body returns 400."""
        resp = await client.post("/docs/search")
        assert resp.status_code == 400

    @patch(f"{_DOC_SERVICE}.search", new_callable=AsyncMock)
    async def test_empty_results(self, mock_search, client: AsyncClient):
        """POST /docs/search returns empty results."""
        mock_search.return_value = {
            "query": "nonexistent",
            "results": [],
            "total": 0,
            "searchId": str(uuid4()),
        }

        resp = await client.post(
            "/docs/search",
            json={"query": "nonexistent"},
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 0

    @patch(f"{_DOC_SERVICE}.search", new_callable=AsyncMock)
    async def test_search_error_returns_500(self, mock_search, client: AsyncClient):
        """POST /docs/search returns 500 on DocSearchError."""
        from spaps_server_quickstart.domains.docs.errors import DocSearchError

        mock_search.side_effect = DocSearchError()

        resp = await client.post(
            "/docs/search",
            json={"query": "test query"},
        )

        assert resp.status_code == 500


# ===========================================================================
# GET /docs/endpoints/:method/:path
# ===========================================================================


class TestGetEndpointDoc:
    @patch(f"{_DOC_SERVICE}.get_endpoint_doc", new_callable=AsyncMock)
    async def test_success(self, mock_get, client: AsyncClient):
        """GET /docs/endpoints/POST/api/auth/login returns endpoint doc."""
        mock_get.return_value = {"endpoint": _fake_endpoint_doc()}

        resp = await client.get("/docs/endpoints/POST/api/auth/login")

        assert resp.status_code == 200
        data = resp.json()
        assert data["endpoint"]["method"] == "POST"
        assert data["endpoint"]["path"] == "/api/auth/login"

    @patch(f"{_DOC_SERVICE}.get_endpoint_doc", new_callable=AsyncMock)
    async def test_not_found_returns_404(self, mock_get, client: AsyncClient):
        """GET /docs/endpoints/GET/nonexistent returns 404."""
        from spaps_server_quickstart.domains.docs.errors import EndpointNotFoundError

        mock_get.side_effect = EndpointNotFoundError()

        resp = await client.get("/docs/endpoints/GET/nonexistent")

        assert resp.status_code == 404


# ===========================================================================
# GET /docs/errors/:code
# ===========================================================================


class TestGetErrorDoc:
    @patch(f"{_DOC_SERVICE}.get_error_doc", new_callable=AsyncMock)
    async def test_success(self, mock_get, client: AsyncClient):
        """GET /docs/errors/INVALID_CREDENTIALS returns error doc."""
        mock_get.return_value = {"error": _fake_error_doc()}

        resp = await client.get("/docs/errors/INVALID_CREDENTIALS")

        assert resp.status_code == 200
        data = resp.json()
        assert data["error"]["code"] == "INVALID_CREDENTIALS"
        assert data["error"]["http_status"] == 401

    @patch(f"{_DOC_SERVICE}.get_error_doc", new_callable=AsyncMock)
    async def test_with_include_examples(self, mock_get, client: AsyncClient):
        """GET /docs/errors/INVALID_CREDENTIALS?includeExamples=true."""
        error_with_examples = _fake_error_doc()
        error_with_examples["examples"] = [_fake_example()]
        mock_get.return_value = {"error": error_with_examples}

        resp = await client.get(
            "/docs/errors/INVALID_CREDENTIALS",
            params={"includeExamples": "true"},
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["error"]["examples"] is not None

    @patch(f"{_DOC_SERVICE}.get_error_doc", new_callable=AsyncMock)
    async def test_not_found_returns_404(self, mock_get, client: AsyncClient):
        """GET /docs/errors/NONEXISTENT returns 404."""
        from spaps_server_quickstart.domains.docs.errors import ErrorDocNotFoundError

        mock_get.side_effect = ErrorDocNotFoundError()

        resp = await client.get("/docs/errors/NONEXISTENT")

        assert resp.status_code == 404


# ===========================================================================
# GET /docs/examples/:feature
# ===========================================================================


class TestGetExamples:
    @patch(f"{_DOC_SERVICE}.get_examples", new_callable=AsyncMock)
    async def test_success(self, mock_get, client: AsyncClient):
        """GET /docs/examples/authentication returns examples."""
        mock_get.return_value = {
            "feature": "authentication",
            "examples": [_fake_example("typescript"), _fake_example("python")],
            "languages": ["python", "typescript"],
        }

        resp = await client.get("/docs/examples/authentication")

        assert resp.status_code == 200
        data = resp.json()
        assert data["feature"] == "authentication"
        assert len(data["examples"]) == 2
        assert "typescript" in data["languages"]

    @patch(f"{_DOC_SERVICE}.get_examples", new_callable=AsyncMock)
    async def test_with_language_filter(self, mock_get, client: AsyncClient):
        """GET /docs/examples/authentication?language=python."""
        mock_get.return_value = {
            "feature": "authentication",
            "examples": [_fake_example("python")],
            "languages": ["python"],
        }

        resp = await client.get(
            "/docs/examples/authentication",
            params={"language": "python"},
        )

        assert resp.status_code == 200
        data = resp.json()
        assert len(data["examples"]) == 1

    @patch(f"{_DOC_SERVICE}.get_examples", new_callable=AsyncMock)
    async def test_not_found_returns_404(self, mock_get, client: AsyncClient):
        """GET /docs/examples/nonexistent returns 404."""
        from spaps_server_quickstart.domains.docs.errors import ExamplesNotFoundError

        mock_get.side_effect = ExamplesNotFoundError()

        resp = await client.get("/docs/examples/nonexistent")

        assert resp.status_code == 404


# ===========================================================================
# GET /docs/categories
# ===========================================================================


class TestGetCategories:
    @patch(f"{_DOC_SERVICE}.get_categories", new_callable=AsyncMock)
    async def test_success(self, mock_get, client: AsyncClient):
        """GET /docs/categories returns category list."""
        mock_get.return_value = {
            "categories": [
                _fake_category("Getting Started", "getting-started"),
                _fake_category("API Reference", "api-reference"),
            ],
        }

        resp = await client.get("/docs/categories")

        assert resp.status_code == 200
        data = resp.json()
        assert len(data["categories"]) == 2

    @patch(f"{_DOC_SERVICE}.get_categories", new_callable=AsyncMock)
    async def test_empty_categories(self, mock_get, client: AsyncClient):
        """GET /docs/categories returns empty list."""
        mock_get.return_value = {"categories": []}

        resp = await client.get("/docs/categories")

        assert resp.status_code == 200
        data = resp.json()
        assert len(data["categories"]) == 0


# ===========================================================================
# POST /docs/feedback
# ===========================================================================


class TestSubmitFeedback:
    @patch(f"{_DOC_SERVICE}.submit_feedback", new_callable=AsyncMock)
    async def test_success(self, mock_submit, client: AsyncClient):
        """POST /docs/feedback returns success message."""
        mock_submit.return_value = {"message": "Feedback submitted successfully"}

        resp = await client.post(
            "/docs/feedback",
            json={
                "documentId": FAKE_DOC_ID,
                "helpful": True,
                "suggestion": "Great doc!",
            },
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["message"] == "Feedback submitted successfully"

    @patch(f"{_DOC_SERVICE}.submit_feedback", new_callable=AsyncMock)
    async def test_negative_feedback(self, mock_submit, client: AsyncClient):
        """POST /docs/feedback with helpful=false."""
        mock_submit.return_value = {"message": "Feedback submitted successfully"}

        resp = await client.post(
            "/docs/feedback",
            json={
                "documentId": FAKE_DOC_ID,
                "helpful": False,
            },
        )

        assert resp.status_code == 200

    async def test_missing_document_id_returns_400(self, client: AsyncClient):
        """POST /docs/feedback without documentId returns 400."""
        resp = await client.post(
            "/docs/feedback",
            json={"helpful": True},
        )
        assert resp.status_code == 400

    async def test_missing_helpful_returns_400(self, client: AsyncClient):
        """POST /docs/feedback without helpful returns 400."""
        resp = await client.post(
            "/docs/feedback",
            json={"documentId": FAKE_DOC_ID},
        )
        assert resp.status_code == 400

    async def test_missing_body_returns_400(self, client: AsyncClient):
        """POST /docs/feedback without body returns 400."""
        resp = await client.post("/docs/feedback")
        assert resp.status_code == 400


# ===========================================================================
# GET /api-docs (OpenAPI JSON)
# ===========================================================================


class TestOpenAPIJSON:
    async def test_returns_json(self, client: AsyncClient):
        """GET /api-docs returns OpenAPI JSON spec."""
        resp = await client.get("/api-docs")

        assert resp.status_code == 200
        assert "application/json" in resp.headers.get("content-type", "")
        data = resp.json()
        assert "openapi" in data
        assert "info" in data
        assert "paths" in data


# ===========================================================================
# GET /api-docs.yaml (OpenAPI YAML)
# ===========================================================================


class TestOpenAPIYAML:
    async def test_returns_yaml(self, client: AsyncClient):
        """GET /api-docs.yaml returns OpenAPI YAML spec."""
        resp = await client.get("/api-docs.yaml")

        assert resp.status_code == 200
        assert "application/x-yaml" in resp.headers.get("content-type", "")
        content = resp.text
        assert "openapi" in content
        assert "info" in content
        assert "paths" in content
