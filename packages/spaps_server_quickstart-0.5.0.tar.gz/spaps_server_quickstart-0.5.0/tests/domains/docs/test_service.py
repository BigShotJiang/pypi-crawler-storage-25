"""Unit tests for the documentation domain service layer.

The repository layer is fully mocked so tests exercise only the
service orchestration, business logic, and error handling.
"""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

from spaps_server_quickstart.domains.docs import service
from spaps_server_quickstart.domains.docs.errors import (
    DocSearchError,
    EndpointNotFoundError,
    ErrorDocNotFoundError,
    ExamplesNotFoundError,
)

_REPO = "spaps_server_quickstart.domains.docs.service.repo"

FAKE_DOC_ID = uuid4()


def _make_doc(
    title: str = "Getting Started",
    slug: str = "getting-started",
    category: str | None = "guides",
) -> MagicMock:
    """Build a mock Documentation model instance."""
    doc = MagicMock()
    doc.id = uuid4()
    doc.slug = slug
    doc.title = title
    doc.content = "Welcome to SPAPS documentation."
    doc.category = category
    doc.tags = ["intro", "guide"]
    doc.metadata_ = {}
    doc.is_published = True
    doc.created_at = datetime.now(UTC)
    return doc


def _make_example(
    title: str = "Login Example",
    language: str = "typescript",
    feature: str = "authentication",
) -> MagicMock:
    """Build a mock CodeExample model instance."""
    example = MagicMock()
    example.id = uuid4()
    example.title = title
    example.description = "How to use this feature"
    example.language = language
    example.code = "const res = await fetch(...)"
    example.dependencies = None
    example.output = None
    example.doc_id = None
    example.endpoint = None
    example.error_code = None
    example.feature = feature
    example.created_at = datetime.now(UTC)
    return example


def _make_error_doc(
    code: str = "INVALID_CREDENTIALS",
    http_status: int = 401,
) -> MagicMock:
    """Build a mock ErrorDoc model instance."""
    error = MagicMock()
    error.id = uuid4()
    error.code = code
    error.http_status = http_status
    error.message = "Invalid credentials"
    error.description = "The provided credentials are invalid."
    error.possible_causes = ["Wrong password", "Wrong email"]
    error.solutions = ["Reset password", "Check email"]
    error.related_errors = ["UNAUTHORIZED"]
    error.created_at = datetime.now(UTC)
    return error


def _make_endpoint_doc(
    method: str = "POST",
    path: str = "/api/auth/login",
) -> MagicMock:
    """Build a mock EndpointDocumentation model instance."""
    endpoint = MagicMock()
    endpoint.id = uuid4()
    endpoint.method = method
    endpoint.path = path
    endpoint.description = "Login to the application"
    endpoint.authentication = {"type": "api_key"}
    endpoint.request_body = {"email": "string", "password": "string"}
    endpoint.response_body = {"access_token": "string"}
    endpoint.error_codes = {"401": "INVALID_CREDENTIALS"}
    endpoint.rate_limit = None
    endpoint.deprecated = False
    endpoint.created_at = datetime.now(UTC)
    return endpoint


def _make_category(
    name: str = "Guides",
    slug: str = "guides",
    order_index: int = 0,
) -> MagicMock:
    """Build a mock DocumentationCategory model instance."""
    cat = MagicMock()
    cat.id = uuid4()
    cat.name = name
    cat.slug = slug
    cat.description = f"{name} section"
    cat.order_index = order_index
    cat.created_at = datetime.now(UTC)
    return cat


# ===========================================================================
# search
# ===========================================================================


class TestSearch:
    @patch(_REPO)
    async def test_returns_search_results(self, mock_repo):
        """Returns matching documents with searchId."""
        docs = [_make_doc(), _make_doc(title="API Reference", slug="api-ref")]
        mock_repo.search_docs_keyword = AsyncMock(return_value=docs)

        db = AsyncMock()
        result = await service.search(db, query="getting started")

        assert result["query"] == "getting started"
        assert result["total"] == 2
        assert len(result["results"]) == 2
        assert result["searchId"] is not None

    @patch(_REPO)
    async def test_empty_results(self, mock_repo):
        """Returns empty results for no matches."""
        mock_repo.search_docs_keyword = AsyncMock(return_value=[])

        db = AsyncMock()
        result = await service.search(db, query="nonexistent")

        assert result["total"] == 0
        assert len(result["results"]) == 0

    @patch(_REPO)
    async def test_with_context_filter(self, mock_repo):
        """Passes context to repository."""
        mock_repo.search_docs_keyword = AsyncMock(return_value=[])

        db = AsyncMock()
        await service.search(db, query="test", context="guides")

        mock_repo.search_docs_keyword.assert_called_once_with(
            db,
            query="test",
            context="guides",
            limit=10,
        )

    @patch(_REPO)
    async def test_with_include_examples(self, mock_repo):
        """Fetches examples when includeExamples is True."""
        doc = _make_doc()
        mock_repo.search_docs_keyword = AsyncMock(return_value=[doc])
        mock_repo.get_examples_by_doc_id = AsyncMock(
            return_value=[_make_example()]
        )

        db = AsyncMock()
        result = await service.search(
            db, query="test", include_examples=True
        )

        assert result["total"] == 1
        assert result["results"][0]["examples"] is not None
        assert len(result["results"][0]["examples"]) == 1
        mock_repo.get_examples_by_doc_id.assert_called_once()

    @patch(_REPO)
    async def test_search_error_raises_doc_search_error(self, mock_repo):
        """Raises DocSearchError when search fails."""
        mock_repo.search_docs_keyword = AsyncMock(
            side_effect=RuntimeError("DB connection failed")
        )

        db = AsyncMock()
        with pytest.raises(DocSearchError):
            await service.search(db, query="test")

    @patch(_REPO)
    async def test_with_limit(self, mock_repo):
        """Passes limit to repository."""
        mock_repo.search_docs_keyword = AsyncMock(return_value=[])

        db = AsyncMock()
        await service.search(db, query="test", limit=5)

        mock_repo.search_docs_keyword.assert_called_once_with(
            db,
            query="test",
            context=None,
            limit=5,
        )


# ===========================================================================
# get_endpoint_doc
# ===========================================================================


class TestGetEndpointDoc:
    @patch(_REPO)
    async def test_returns_endpoint_doc(self, mock_repo):
        """Returns endpoint documentation."""
        endpoint = _make_endpoint_doc()
        mock_repo.get_endpoint_doc = AsyncMock(return_value=endpoint)

        db = AsyncMock()
        result = await service.get_endpoint_doc(
            db, method="POST", path="/api/auth/login"
        )

        assert result["endpoint"]["method"] == "POST"
        assert result["endpoint"]["path"] == "/api/auth/login"

    @patch(_REPO)
    async def test_not_found_raises(self, mock_repo):
        """Raises EndpointNotFoundError when not found."""
        mock_repo.get_endpoint_doc = AsyncMock(return_value=None)

        db = AsyncMock()
        with pytest.raises(EndpointNotFoundError):
            await service.get_endpoint_doc(
                db, method="GET", path="/nonexistent"
            )


# ===========================================================================
# get_error_doc
# ===========================================================================


class TestGetErrorDoc:
    @patch(_REPO)
    async def test_returns_error_doc(self, mock_repo):
        """Returns error documentation."""
        error = _make_error_doc()
        mock_repo.get_error_doc = AsyncMock(return_value=error)

        db = AsyncMock()
        result = await service.get_error_doc(db, code="INVALID_CREDENTIALS")

        assert result["error"]["code"] == "INVALID_CREDENTIALS"
        assert result["error"]["http_status"] == 401

    @patch(_REPO)
    async def test_not_found_raises(self, mock_repo):
        """Raises ErrorDocNotFoundError when not found."""
        mock_repo.get_error_doc = AsyncMock(return_value=None)

        db = AsyncMock()
        with pytest.raises(ErrorDocNotFoundError):
            await service.get_error_doc(db, code="NONEXISTENT")

    @patch(_REPO)
    async def test_with_include_examples(self, mock_repo):
        """Includes examples when requested."""
        error = _make_error_doc()
        mock_repo.get_error_doc = AsyncMock(return_value=error)
        mock_repo.get_examples_by_error_code = AsyncMock(
            return_value=[_make_example()]
        )

        db = AsyncMock()
        result = await service.get_error_doc(
            db, code="INVALID_CREDENTIALS", include_examples=True
        )

        assert result["error"]["examples"] is not None
        assert len(result["error"]["examples"]) == 1
        mock_repo.get_examples_by_error_code.assert_called_once()

    @patch(_REPO)
    async def test_without_examples(self, mock_repo):
        """Does not include examples by default."""
        error = _make_error_doc()
        mock_repo.get_error_doc = AsyncMock(return_value=error)

        db = AsyncMock()
        result = await service.get_error_doc(db, code="INVALID_CREDENTIALS")

        assert "examples" not in result["error"]


# ===========================================================================
# get_examples
# ===========================================================================


class TestGetExamples:
    @patch(_REPO)
    async def test_returns_examples(self, mock_repo):
        """Returns examples with language list."""
        examples = [
            _make_example(language="typescript"),
            _make_example(language="python"),
        ]
        mock_repo.get_examples_by_feature = AsyncMock(return_value=examples)

        db = AsyncMock()
        result = await service.get_examples(db, feature="authentication")

        assert result["feature"] == "authentication"
        assert len(result["examples"]) == 2
        assert "typescript" in result["languages"]
        assert "python" in result["languages"]

    @patch(_REPO)
    async def test_not_found_raises(self, mock_repo):
        """Raises ExamplesNotFoundError when no examples."""
        mock_repo.get_examples_by_feature = AsyncMock(return_value=[])

        db = AsyncMock()
        with pytest.raises(ExamplesNotFoundError):
            await service.get_examples(db, feature="nonexistent")

    @patch(_REPO)
    async def test_with_language_filter(self, mock_repo):
        """Passes language filter to repository."""
        examples = [_make_example(language="python")]
        mock_repo.get_examples_by_feature = AsyncMock(return_value=examples)

        db = AsyncMock()
        result = await service.get_examples(
            db, feature="authentication", language="python"
        )

        assert len(result["examples"]) == 1
        mock_repo.get_examples_by_feature.assert_called_once_with(
            db, "authentication", language="python"
        )


# ===========================================================================
# get_categories
# ===========================================================================


class TestGetCategories:
    @patch(_REPO)
    async def test_returns_categories(self, mock_repo):
        """Returns all categories."""
        cats = [
            _make_category("Getting Started", "getting-started", 0),
            _make_category("API Reference", "api-reference", 1),
        ]
        mock_repo.list_categories = AsyncMock(return_value=cats)

        db = AsyncMock()
        result = await service.get_categories(db)

        assert len(result["categories"]) == 2
        assert result["categories"][0]["name"] == "Getting Started"

    @patch(_REPO)
    async def test_empty_categories(self, mock_repo):
        """Returns empty list when no categories."""
        mock_repo.list_categories = AsyncMock(return_value=[])

        db = AsyncMock()
        result = await service.get_categories(db)

        assert len(result["categories"]) == 0


# ===========================================================================
# submit_feedback
# ===========================================================================


class TestSubmitFeedback:
    @patch(_REPO)
    async def test_submits_feedback(self, mock_repo):
        """Submits feedback and returns success message."""
        feedback = MagicMock()
        mock_repo.create_feedback = AsyncMock(return_value=feedback)

        db = AsyncMock()
        result = await service.submit_feedback(
            db,
            document_id="doc-123",
            helpful=True,
            suggestion="Good doc",
        )

        assert result["message"] == "Feedback submitted successfully"
        mock_repo.create_feedback.assert_called_once_with(
            db,
            document_id="doc-123",
            helpful=True,
            suggestion="Good doc",
        )

    @patch(_REPO)
    async def test_submits_negative_feedback(self, mock_repo):
        """Submits negative feedback without suggestion."""
        feedback = MagicMock()
        mock_repo.create_feedback = AsyncMock(return_value=feedback)

        db = AsyncMock()
        result = await service.submit_feedback(
            db,
            document_id="doc-456",
            helpful=False,
        )

        assert result["message"] == "Feedback submitted successfully"


# ===========================================================================
# index_document
# ===========================================================================


class TestIndexDocument:
    @patch(_REPO)
    async def test_indexes_document(self, mock_repo):
        """Creates a new documentation article."""
        doc = _make_doc()
        mock_repo.create_documentation = AsyncMock(return_value=doc)

        db = AsyncMock()
        result = await service.index_document(
            db,
            slug="new-doc",
            title="New Doc",
            content="New content",
            category="guides",
            tags=["new"],
        )

        assert result["document"]["title"] == "Getting Started"
        mock_repo.create_documentation.assert_called_once()
