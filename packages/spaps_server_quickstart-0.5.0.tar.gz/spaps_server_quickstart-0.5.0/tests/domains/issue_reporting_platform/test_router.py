"""Route tests for issue_reporting_platform endpoints."""

from __future__ import annotations

from datetime import UTC, datetime
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch
from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from spaps_server_quickstart.domains.issue_reporting_platform.errors import IssueReportNotFoundError
from spaps_server_quickstart.domains.issue_reporting_platform.router import router
from spaps_server_quickstart.middleware.error_handler import install_error_handlers

_SVC = "spaps_server_quickstart.domains.issue_reporting_platform.router.service"
_USER_APPLICATION_LOOKUP = (
    "spaps_server_quickstart.domains.issue_reporting_platform.router.user_repo.get_user_application"
)

FAKE_APP_ID = str(uuid4())
FAKE_USER_ID = str(uuid4())
FAKE_ISSUE_REPORT_ID = str(uuid4())


def _make_app() -> FastAPI:
    app = FastAPI()
    install_error_handlers(app)
    app.include_router(router, prefix="/api")
    return app


def _make_application(*, app_id: str = FAKE_APP_ID, issue_reporting_enabled: bool = True) -> SimpleNamespace:
    return SimpleNamespace(id=app_id, settings={"issue_reporting_enabled": issue_reporting_enabled})


def _make_user(
    *,
    user_id: str = FAKE_USER_ID,
    application_id: str = FAKE_APP_ID,
    roles: list[str] | None = None,
    permissions: list[str] | None = None,
) -> SimpleNamespace:
    return SimpleNamespace(
        id=user_id,
        application_id=application_id,
        roles=roles if roles is not None else ["practitioner"],
        permissions=permissions if permissions is not None else ["issue_reporting"],
        is_admin=False,
        is_super_admin=False,
    )


def _issue_report_payload() -> dict[str, object]:
    now = datetime.now(UTC).isoformat()
    return {
        "id": FAKE_ISSUE_REPORT_ID,
        "application_id": FAKE_APP_ID,
        "reporter_user_id": FAKE_USER_ID,
        "reporter_role_hint": "practitioner",
        "target": {
            "component_key": "patient_protocol_widget",
            "component_label": "Patient Protocol Widget",
            "page_url": "/patients/123/protocol",
            "surface_ref": "daily-log",
            "metadata": {"section": "daily log"},
        },
        "note": "The save action silently fails after I edit today's protocol note.",
        "status": "open",
        "parent_issue_report_id": None,
        "linked_case": {
            "case_id": str(uuid4()),
            "status": "open",
            "priority": "normal",
            "resolved_at": None,
        },
        "created_at": now,
        "updated_at": now,
    }


@pytest.fixture
def app() -> FastAPI:
    return _make_app()


@pytest.fixture
def client(app: FastAPI) -> TestClient:
    return TestClient(app, raise_server_exceptions=False)


class TestCreateRoute:
    @patch(_SVC)
    def test_create_requires_authenticated_user(self, mock_svc, app: FastAPI, client: TestClient):
        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
            get_optional_user,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_optional_user] = lambda: None

        response = client.post(
            "/api/v1/issue-reports",
            json={
                "target": {
                    "component_key": "patient_protocol_widget",
                    "component_label": "Patient Protocol Widget",
                    "page_url": "/patients/123/protocol",
                    "metadata": {},
                },
                "note": "The save action silently fails after I edit today's protocol note.",
            },
        )

        assert response.status_code == 401
        assert response.json()["error"]["code"] == "NOT_AUTHENTICATED"
        mock_svc.create_issue_report.assert_not_called()

    @patch(_SVC)
    @patch(_USER_APPLICATION_LOOKUP, new_callable=AsyncMock)
    def test_create_rejects_without_issue_reporting_capability(
        self,
        mock_user_application_lookup,
        mock_svc,
        app: FastAPI,
        client: TestClient,
    ):
        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
            get_optional_user,
        )

        mock_user_application_lookup.return_value = SimpleNamespace(permissions={"issue_reporting": False})

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_optional_user] = lambda: _make_user(permissions=[])

        response = client.post(
            "/api/v1/issue-reports",
            json={
                "target": {
                    "component_key": "patient_protocol_widget",
                    "component_label": "Patient Protocol Widget",
                    "page_url": "/patients/123/protocol",
                    "metadata": {},
                },
                "note": "The save action silently fails after I edit today's protocol note.",
            },
        )

        assert response.status_code == 403
        assert response.json()["error"]["code"] == "NOT_AUTHORIZED"
        mock_svc.create_issue_report.assert_not_called()
        mock_user_application_lookup.assert_awaited_once()

    @patch(_SVC)
    def test_create_rejects_when_issue_reporting_disabled(self, mock_svc, app: FastAPI, client: TestClient):
        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
            get_optional_user,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application(issue_reporting_enabled=False)
        app.dependency_overrides[get_optional_user] = lambda: _make_user()

        response = client.post(
            "/api/v1/issue-reports",
            json={
                "target": {
                    "component_key": "patient_protocol_widget",
                    "component_label": "Patient Protocol Widget",
                    "page_url": "/patients/123/protocol",
                    "metadata": {},
                },
                "note": "The save action silently fails after I edit today's protocol note.",
            },
        )

        assert response.status_code == 403
        assert response.json()["error"]["code"] == "NOT_AUTHORIZED"
        mock_svc.create_issue_report.assert_not_called()

    @patch(_SVC)
    def test_create_returns_201(self, mock_svc, app: FastAPI, client: TestClient):
        mock_svc.create_issue_report = AsyncMock(return_value=_issue_report_payload())

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
            get_optional_user,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_optional_user] = lambda: _make_user()

        response = client.post(
            "/api/v1/issue-reports",
            json={
                "target": {
                    "component_key": "patient_protocol_widget",
                    "component_label": "Patient Protocol Widget",
                    "page_url": "/patients/123/protocol",
                    "surface_ref": "daily-log",
                    "metadata": {"section": "daily log"},
                },
                "note": "The save action silently fails after I edit today's protocol note.",
                "reporter_role_hint": "practitioner",
            },
        )

        assert response.status_code == 201
        assert mock_svc.create_issue_report.await_args.kwargs["application_id"] is not None
        assert mock_svc.create_issue_report.await_args.kwargs["reporter_user_id"] is not None


class TestReadRoutes:
    @patch(_SVC)
    def test_list_forwards_status_filter(self, mock_svc, app: FastAPI, client: TestClient):
        mock_svc.list_issue_reports = AsyncMock(return_value={"items": [_issue_report_payload()], "total": 1})

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
            get_optional_user,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_optional_user] = lambda: _make_user()

        response = client.get("/api/v1/issue-reports?status=open&limit=10&offset=0")

        assert response.status_code == 200
        assert response.json()["total"] == 1
        assert mock_svc.list_issue_reports.await_args.kwargs["status"] == "open"

    @patch(_SVC)
    @patch(_USER_APPLICATION_LOOKUP, new_callable=AsyncMock)
    def test_list_rejects_without_issue_reporting_capability(
        self,
        mock_user_application_lookup,
        mock_svc,
        app: FastAPI,
        client: TestClient,
    ):
        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
            get_optional_user,
        )

        mock_user_application_lookup.return_value = SimpleNamespace(permissions={"issue_reporting": False})

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_optional_user] = lambda: _make_user(permissions=[])

        response = client.get("/api/v1/issue-reports")

        assert response.status_code == 403
        assert response.json()["error"]["code"] == "NOT_AUTHORIZED"
        mock_svc.list_issue_reports.assert_not_called()
        mock_user_application_lookup.assert_awaited_once()

    @patch(_SVC)
    def test_list_rejects_cross_app_user_scope_mismatch(self, mock_svc, app: FastAPI, client: TestClient):
        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
            get_optional_user,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_optional_user] = lambda: _make_user(application_id=str(uuid4()))

        response = client.get("/api/v1/issue-reports")

        assert response.status_code == 403
        assert response.json()["error"]["code"] == "NOT_AUTHORIZED"
        mock_svc.list_issue_reports.assert_not_called()

    @patch(_SVC)
    def test_status_returns_summary(self, mock_svc, app: FastAPI, client: TestClient):
        mock_svc.get_issue_report_status = AsyncMock(
            return_value={
                "has_open": True,
                "has_recent_resolved": False,
                "open_count": 2,
                "recent_resolved_count": 0,
            }
        )

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
            get_optional_user,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_optional_user] = lambda: _make_user()

        response = client.get("/api/v1/issue-reports/status")

        assert response.status_code == 200
        assert response.json()["has_open"] is True

    @patch(_SVC)
    def test_get_detail_returns_issue_report(self, mock_svc, app: FastAPI, client: TestClient):
        mock_svc.get_issue_report_detail = AsyncMock(return_value=_issue_report_payload())

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
            get_optional_user,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_optional_user] = lambda: _make_user()

        response = client.get(f"/api/v1/issue-reports/{FAKE_ISSUE_REPORT_ID}")

        assert response.status_code == 200
        assert mock_svc.get_issue_report_detail.await_args.kwargs["issue_report_id"] is not None

    @patch(_SVC)
    def test_get_detail_returns_404_for_foreign_issue_report(self, mock_svc, app: FastAPI, client: TestClient):
        mock_svc.get_issue_report_detail = AsyncMock(side_effect=IssueReportNotFoundError())

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
            get_optional_user,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_optional_user] = lambda: _make_user()

        response = client.get(f"/api/v1/issue-reports/{FAKE_ISSUE_REPORT_ID}")

        assert response.status_code == 404
        assert response.json()["error"]["code"] == "ISSUE_REPORT_NOT_FOUND"


class TestMutationRoutes:
    @patch(_SVC)
    def test_patch_updates_note(self, mock_svc, app: FastAPI, client: TestClient):
        updated_payload = _issue_report_payload()
        updated_payload["note"] = "Updated detail with clearer reproduction steps."
        mock_svc.update_issue_report_note = AsyncMock(return_value=updated_payload)

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
            get_optional_user,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_optional_user] = lambda: _make_user()

        response = client.patch(
            f"/api/v1/issue-reports/{FAKE_ISSUE_REPORT_ID}",
            json={"note": "Updated detail with clearer reproduction steps."},
        )

        assert response.status_code == 200
        assert response.json()["note"] == "Updated detail with clearer reproduction steps."

    @patch(_SVC)
    def test_reply_returns_201(self, mock_svc, app: FastAPI, client: TestClient):
        reply_payload = _issue_report_payload()
        reply_payload["parent_issue_report_id"] = FAKE_ISSUE_REPORT_ID
        mock_svc.reply_to_issue_report = AsyncMock(return_value=reply_payload)

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
            get_optional_user,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_optional_user] = lambda: _make_user()

        response = client.post(
            f"/api/v1/issue-reports/{FAKE_ISSUE_REPORT_ID}/replies",
            json={"note": "This still fails after the reported fix."},
        )

        assert response.status_code == 201
        assert response.json()["parent_issue_report_id"] == FAKE_ISSUE_REPORT_ID
