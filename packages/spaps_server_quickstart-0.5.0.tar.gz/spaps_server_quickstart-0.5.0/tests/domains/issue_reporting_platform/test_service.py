"""Unit tests for issue_reporting_platform service logic."""

from __future__ import annotations

from datetime import UTC, datetime
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch
from uuid import uuid4

import pytest

from spaps_server_quickstart.domains.issue_reporting_platform.errors import (
    IssueReportCannotEditClosedError,
    IssueReportCannotReplyOpenError,
    IssueReportCaseLinkBrokenError,
    IssueReportNotFoundError,
)
from spaps_server_quickstart.domains.issue_reporting_platform.service import (
    create_issue_report,
    get_issue_report_detail,
    get_issue_report_status,
    list_issue_reports,
    reply_to_issue_report,
    update_issue_report_note,
)

_REPO = "spaps_server_quickstart.domains.issue_reporting_platform.service.repo"
_SUPPORT_REPO = "spaps_server_quickstart.domains.issue_reporting_platform.service.support_repo"


def _make_issue_report(**overrides) -> SimpleNamespace:
    now = datetime.now(UTC)
    return SimpleNamespace(
        id=overrides.get("id", uuid4()),
        application_id=overrides.get("application_id", uuid4()),
        reporter_user_id=overrides.get("reporter_user_id", uuid4()),
        reporter_role_hint=overrides.get("reporter_role_hint", "practitioner"),
        component_key=overrides.get("component_key", "patient_protocol_widget"),
        component_label=overrides.get("component_label", "Patient Protocol Widget"),
        page_url=overrides.get("page_url", "/patients/123/protocol"),
        surface_ref=overrides.get("surface_ref"),
        target_metadata=overrides.get("target_metadata", {"section": "daily log"}),
        note=overrides.get("note", "Detailed issue note."),
        parent_issue_report_id=overrides.get("parent_issue_report_id"),
        support_case_id=overrides.get("support_case_id", uuid4()),
        created_at=overrides.get("created_at", now),
        updated_at=overrides.get("updated_at", now),
    )


def _make_case(**overrides) -> SimpleNamespace:
    now = datetime.now(UTC)
    return SimpleNamespace(
        id=overrides.get("id", uuid4()),
        application_id=overrides.get("application_id", uuid4()),
        external_case_ref=overrides.get("external_case_ref"),
        title=overrides.get("title", "Patient Protocol Widget"),
        status=overrides.get("status", "open"),
        priority=overrides.get("priority", "normal"),
        highest_severity=overrides.get("highest_severity", "warning"),
        assigned_to_user_id=overrides.get("assigned_to_user_id"),
        first_event_at=overrides.get("first_event_at", now),
        last_event_at=overrides.get("last_event_at", now),
        resolved_at=overrides.get("resolved_at"),
        created_at=overrides.get("created_at", now),
        updated_at=overrides.get("updated_at", now),
    )


def _make_event(**overrides) -> SimpleNamespace:
    now = datetime.now(UTC)
    return SimpleNamespace(
        id=overrides.get("id", uuid4()),
        case_id=overrides.get("case_id", uuid4()),
        application_id=overrides.get("application_id", uuid4()),
        event_key=overrides.get("event_key", "evt_1"),
        source_channel=overrides.get("source_channel", "frontend"),
        event_type=overrides.get("event_type", "issue_reported"),
        severity=overrides.get("severity", "warning"),
        actor_type=overrides.get("actor_type", "practitioner"),
        actor_external_id=overrides.get("actor_external_id"),
        correlation_id=overrides.get("correlation_id"),
        payload=overrides.get("payload", {}),
        redacted_keys=overrides.get("redacted_keys", []),
        occurred_at=overrides.get("occurred_at", now),
        ingested_by_user_id=overrides.get("ingested_by_user_id"),
    )


class TestCreateIssueReport:
    @patch(_SUPPORT_REPO)
    @patch(_REPO)
    async def test_creates_issue_report_and_linked_case(self, mock_repo, mock_support_repo):
        application_id = uuid4()
        reporter_user_id = uuid4()
        created_case = _make_case(id=uuid4(), application_id=application_id, status="open")
        created_issue_report = _make_issue_report(
            id=uuid4(),
            application_id=application_id,
            reporter_user_id=reporter_user_id,
            support_case_id=created_case.id,
        )
        created_event = _make_event(case_id=created_case.id, application_id=application_id)

        mock_support_repo.create_case = AsyncMock(return_value=created_case)
        mock_repo.create_issue_report = AsyncMock(return_value=created_issue_report)
        mock_support_repo.create_event = AsyncMock(return_value=created_event)
        mock_support_repo.update_case_summary = AsyncMock(return_value=created_case)

        result = await create_issue_report(
            AsyncMock(),
            application_id=application_id,
            reporter_user_id=reporter_user_id,
            reporter_role_hint=None,
            user_roles=["practitioner"],
            target={
                "component_key": "patient_protocol_widget",
                "component_label": "Patient Protocol Widget",
                "page_url": "/patients/123/protocol",
                "surface_ref": "daily-log",
                "metadata": {"section": "daily log"},
            },
            note="The save action silently fails after I edit today's protocol note.",
        )

        assert result["id"] == str(created_issue_report.id)
        assert result["status"] == "open"
        assert result["linked_case"]["case_id"] == str(created_case.id)
        assert mock_repo.create_issue_report.await_args.kwargs["parent_issue_report_id"] is None
        assert mock_support_repo.create_event.await_args.kwargs["event_type"] == "issue_reported"


class TestListIssueReports:
    @patch(_REPO)
    async def test_list_raises_when_case_link_is_broken(self, mock_repo):
        issue_report = _make_issue_report()
        mock_repo.list_issue_report_rows = AsyncMock(return_value=([(issue_report, None)], 1))

        with pytest.raises(IssueReportCaseLinkBrokenError):
            await list_issue_reports(
                AsyncMock(),
                application_id=uuid4(),
                reporter_user_id=uuid4(),
                status=None,
                limit=50,
                offset=0,
            )

    @patch(_REPO)
    async def test_list_projects_current_linked_case_status(self, mock_repo):
        application_id = uuid4()
        reporter_user_id = uuid4()
        issue_report = _make_issue_report(
            application_id=application_id,
            reporter_user_id=reporter_user_id,
        )
        resolved_case = _make_case(
            id=issue_report.support_case_id,
            application_id=application_id,
            status="resolved",
            resolved_at=datetime.now(UTC),
        )
        mock_repo.list_issue_report_rows = AsyncMock(return_value=([(issue_report, resolved_case)], 1))

        result = await list_issue_reports(
            AsyncMock(),
            application_id=application_id,
            reporter_user_id=reporter_user_id,
            status=None,
            limit=50,
            offset=0,
        )

        assert result["items"][0]["status"] == "resolved"
        assert result["items"][0]["linked_case"]["status"] == "resolved"


class TestGetIssueReportDetail:
    @patch(_REPO)
    async def test_detail_raises_when_issue_report_is_not_owned(self, mock_repo):
        mock_repo.get_issue_report_row = AsyncMock(return_value=None)

        with pytest.raises(IssueReportNotFoundError):
            await get_issue_report_detail(
                AsyncMock(),
                application_id=uuid4(),
                reporter_user_id=uuid4(),
                issue_report_id=uuid4(),
            )

    @patch(_REPO)
    async def test_detail_reflects_current_linked_case_status(self, mock_repo):
        application_id = uuid4()
        reporter_user_id = uuid4()
        issue_report = _make_issue_report(
            application_id=application_id,
            reporter_user_id=reporter_user_id,
        )
        reopened_case = _make_case(
            id=issue_report.support_case_id,
            application_id=application_id,
            status="open",
            resolved_at=None,
        )
        mock_repo.get_issue_report_row = AsyncMock(return_value=(issue_report, reopened_case))

        result = await get_issue_report_detail(
            AsyncMock(),
            application_id=application_id,
            reporter_user_id=reporter_user_id,
            issue_report_id=issue_report.id,
        )

        assert result["status"] == "open"
        assert result["linked_case"]["status"] == "open"


class TestUpdateIssueReportNote:
    @patch(_SUPPORT_REPO)
    @patch(_REPO)
    async def test_edit_rejects_closed_issue_report(self, mock_repo, mock_support_repo):
        issue_report = _make_issue_report()
        closed_case = _make_case(id=issue_report.support_case_id, status="resolved")
        mock_repo.get_issue_report_row = AsyncMock(return_value=(issue_report, closed_case))

        with pytest.raises(IssueReportCannotEditClosedError):
            await update_issue_report_note(
                AsyncMock(),
                application_id=uuid4(),
                reporter_user_id=uuid4(),
                issue_report_id=uuid4(),
                note="This should still be enough text.",
                reporter_role_hint=None,
                user_roles=["practitioner"],
            )

        mock_support_repo.create_event.assert_not_called()

    @patch(_SUPPORT_REPO)
    @patch(_REPO)
    async def test_edit_rejects_unowned_issue_report(self, mock_repo, mock_support_repo):
        mock_repo.get_issue_report_row = AsyncMock(return_value=None)

        with pytest.raises(IssueReportNotFoundError):
            await update_issue_report_note(
                AsyncMock(),
                application_id=uuid4(),
                reporter_user_id=uuid4(),
                issue_report_id=uuid4(),
                note="This should still be enough text.",
                reporter_role_hint=None,
                user_roles=["practitioner"],
            )

        mock_support_repo.create_event.assert_not_called()


class TestReplyToIssueReport:
    @patch(_SUPPORT_REPO)
    @patch(_REPO)
    async def test_reply_rejects_open_issue_report(self, mock_repo, mock_support_repo):
        issue_report = _make_issue_report()
        open_case = _make_case(id=issue_report.support_case_id, status="open")
        mock_repo.get_issue_report_row = AsyncMock(return_value=(issue_report, open_case))

        with pytest.raises(IssueReportCannotReplyOpenError):
            await reply_to_issue_report(
                AsyncMock(),
                application_id=uuid4(),
                reporter_user_id=uuid4(),
                issue_report_id=uuid4(),
                note="This is still happening after the fix landed.",
                reporter_role_hint=None,
                user_roles=["practitioner"],
            )

        mock_repo.create_issue_report.assert_not_called()
        mock_support_repo.update_case.assert_not_called()

    @patch(_SUPPORT_REPO)
    @patch(_REPO)
    async def test_reply_rejects_unowned_issue_report(self, mock_repo, mock_support_repo):
        mock_repo.get_issue_report_row = AsyncMock(return_value=None)

        with pytest.raises(IssueReportNotFoundError):
            await reply_to_issue_report(
                AsyncMock(),
                application_id=uuid4(),
                reporter_user_id=uuid4(),
                issue_report_id=uuid4(),
                note="This is still happening after the fix landed.",
                reporter_role_hint=None,
                user_roles=["practitioner"],
            )

        mock_repo.create_issue_report.assert_not_called()
        mock_support_repo.update_case.assert_not_called()

    @patch(_SUPPORT_REPO)
    @patch(_REPO)
    async def test_reply_creates_child_and_reopens_case(self, mock_repo, mock_support_repo):
        application_id = uuid4()
        reporter_user_id = uuid4()
        parent_issue_report = _make_issue_report(
            application_id=application_id,
            reporter_user_id=reporter_user_id,
        )
        closed_case = _make_case(
            id=parent_issue_report.support_case_id,
            application_id=application_id,
            status="resolved",
            resolved_at=datetime.now(UTC),
        )
        child_issue_report = _make_issue_report(
            id=uuid4(),
            application_id=application_id,
            reporter_user_id=reporter_user_id,
            parent_issue_report_id=parent_issue_report.id,
            support_case_id=closed_case.id,
            note="This still fails after the reported fix.",
        )
        reopened_case = _make_case(
            id=closed_case.id,
            application_id=application_id,
            status="open",
            resolved_at=None,
        )
        created_event = _make_event(case_id=reopened_case.id, application_id=application_id)

        mock_repo.get_issue_report_row = AsyncMock(return_value=(parent_issue_report, closed_case))
        mock_repo.create_issue_report = AsyncMock(return_value=child_issue_report)
        mock_support_repo.update_case = AsyncMock(return_value=reopened_case)
        mock_support_repo.create_event = AsyncMock(return_value=created_event)
        mock_support_repo.update_case_summary = AsyncMock(return_value=reopened_case)

        result = await reply_to_issue_report(
            AsyncMock(),
            application_id=application_id,
            reporter_user_id=reporter_user_id,
            issue_report_id=parent_issue_report.id,
            note="This still fails after the reported fix.",
            reporter_role_hint=None,
            user_roles=["practitioner"],
        )

        assert result["parent_issue_report_id"] == str(parent_issue_report.id)
        assert result["linked_case"]["status"] == "open"
        assert mock_support_repo.update_case.await_args.kwargs["status"] == "open"
        assert mock_support_repo.create_event.await_args.kwargs["event_type"] == "issue_report_replied"


class TestIssueReportStatus:
    @patch(_REPO)
    async def test_status_uses_open_and_recent_resolved_counts(self, mock_repo):
        mock_repo.count_open_issue_reports = AsyncMock(return_value=2)
        mock_repo.count_recent_resolved_issue_reports = AsyncMock(return_value=1)

        result = await get_issue_report_status(
            AsyncMock(),
            application_id=uuid4(),
            reporter_user_id=uuid4(),
        )

        assert result == {
            "has_open": True,
            "has_recent_resolved": True,
            "open_count": 2,
            "recent_resolved_count": 1,
        }
