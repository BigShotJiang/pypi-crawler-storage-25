"""Unit tests for the entitlements domain router (HTTP layer).

Tests resource-scoped entitlements (Phase A1) covering:
- Resource type/id query params on GET endpoints
- Key-scope enforcement (publishable vs secret keys)
- Manual grant with resource scoping
- Cross-application isolation
- Backward compatibility with existing queries

Each test creates a minimal FastAPI test app with dependency overrides for
the database session, application, and optional user/admin.  The
entitlements service layer is fully mocked so tests exercise only routing,
request validation, status codes, and response shapes.
"""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from fastapi import FastAPI, Request
from httpx import ASGITransport, AsyncClient

from spaps_server_quickstart.domains.entitlements.router import (
    entitlements_router,
    mappings_router,
)
from spaps_server_quickstart.middleware.api_key import KeyType
from spaps_server_quickstart.middleware.error_handler import install_error_handlers
from spaps_server_quickstart.middleware.spaps_deps import (
    get_application,
    get_current_user,
    get_db_session,
    get_optional_user,
    require_admin_user,
)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

FAKE_USER_ID = str(uuid4())
FAKE_OTHER_USER_ID = str(uuid4())
FAKE_APP_ID = str(uuid4())
FAKE_OTHER_APP_ID = str(uuid4())
FAKE_COMPANY_ID = str(uuid4())
FAKE_ADMIN_ID = str(uuid4())

_SERVICE = "spaps_server_quickstart.domains.entitlements.service"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _fake_entitlement(
    *,
    resource_type: str = "user",
    resource_id: str | None = None,
    entitlement_key: str = "pro_access",
    application_id: str | None = None,
) -> dict:
    """Return a realistic entitlement dict."""
    return {
        "id": str(uuid4()),
        "application_id": application_id or FAKE_APP_ID,
        "beneficiary_user_id": FAKE_USER_ID if resource_type == "user" else None,
        "beneficiary_email": None,
        "entitlement_type": "access",
        "entitlement_key": entitlement_key,
        "source": "manual",
        "resource_type": resource_type,
        "resource_id": resource_id,
        "starts_at": datetime.now(UTC).isoformat(),
        "ends_at": None,
        "revoked_at": None,
        "crypto_invoice_id": None,
        "stripe_product_id": None,
        "stripe_price_id": None,
        "stripe_subscription_id": None,
        "stripe_session_id": None,
        "stripe_invoice_id": None,
        "manual_grant_id": str(uuid4()),
        "manual_grant_reason": "test",
        "granted_by_user_id": FAKE_ADMIN_ID,
        "revoked_by_user_id": None,
        "revoked_reason": None,
        "metadata": {},
        "created_at": datetime.now(UTC).isoformat(),
        "updated_at": datetime.now(UTC).isoformat(),
    }


def _fake_admin():
    """Return a mock admin user."""
    admin = MagicMock()
    admin.id = FAKE_ADMIN_ID
    admin.email = "admin@example.com"
    admin.username = "admin"
    admin.tier = "enterprise"
    admin.roles = ["admin"]
    admin.permissions = ["manage_entitlements"]
    admin.is_admin = True
    admin.is_super_admin = False
    admin.wallet_addresses = []
    return admin


def _fake_user(user_id: str | None = None, email: str = "user@example.com"):
    """Return a mock authenticated user."""
    user = MagicMock()
    user.id = user_id or FAKE_USER_ID
    user.email = email
    user.username = "testuser"
    user.tier = "free"
    user.roles = ["user"]
    user.permissions = ["view_products"]
    user.is_admin = False
    user.is_super_admin = False
    user.wallet_addresses = []
    return user


def _fake_application(app_id: str | None = None):
    """Return a mock application."""
    app = MagicMock()
    app.id = app_id or FAKE_APP_ID
    app.name = "Test App"
    return app


def _create_test_app(
    *,
    key_type: str = KeyType.SECRET,
    include_user: bool = False,
    include_admin: bool = False,
    user_id: str | None = None,
    user_email: str = "user@example.com",
    app_id: str | None = None,
):
    """Create a FastAPI test app with dependency overrides.

    key_type controls whether the simulated API key is publishable or secret.
    """
    fastapi_app = FastAPI()

    settings = MagicMock()
    settings.jwt_secret = "test-secret"
    fastapi_app.state.settings = settings

    install_error_handlers(fastapi_app)
    fastapi_app.include_router(entitlements_router, prefix="/api")
    fastapi_app.include_router(mappings_router, prefix="/api")

    mock_db = AsyncMock()

    async def override_db_session():
        yield mock_db

    def override_get_application():
        return _fake_application(app_id)

    user_obj = _fake_user(user_id=user_id, email=user_email)
    admin_obj = _fake_admin()

    fastapi_app.dependency_overrides[get_db_session] = override_db_session
    fastapi_app.dependency_overrides[get_application] = override_get_application

    if include_user or include_admin:
        fastapi_app.dependency_overrides[get_current_user] = lambda: user_obj
        fastapi_app.dependency_overrides[get_optional_user] = lambda: user_obj
    else:
        fastapi_app.dependency_overrides[get_optional_user] = lambda: None

    if include_admin:
        fastapi_app.dependency_overrides[require_admin_user] = lambda: admin_obj

    # Middleware to set key_type on request.state
    @fastapi_app.middleware("http")
    async def set_key_type(request: Request, call_next):
        request.state.key_type = key_type
        response = await call_next(request)
        return response

    return fastapi_app


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def secret_key_app():
    """App with secret key, no user auth."""
    return _create_test_app(key_type=KeyType.SECRET)


@pytest.fixture
def secret_key_admin_app():
    """App with secret key and admin auth."""
    return _create_test_app(key_type=KeyType.SECRET, include_admin=True)


@pytest.fixture
def pub_key_user_app():
    """App with publishable key and JWT user."""
    return _create_test_app(
        key_type=KeyType.PUBLISHABLE,
        include_user=True,
        user_id=FAKE_USER_ID,
    )


@pytest.fixture
def pub_key_no_jwt_app():
    """App with publishable key, no JWT."""
    return _create_test_app(key_type=KeyType.PUBLISHABLE, include_user=False)


@pytest.fixture
async def secret_client(secret_key_app):
    transport = ASGITransport(app=secret_key_app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


@pytest.fixture
async def secret_admin_client(secret_key_admin_app):
    transport = ASGITransport(app=secret_key_admin_app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


@pytest.fixture
async def pub_user_client(pub_key_user_app):
    transport = ASGITransport(app=pub_key_user_app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


@pytest.fixture
async def pub_no_jwt_client(pub_key_no_jwt_app):
    transport = ASGITransport(app=pub_key_no_jwt_app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


# ===========================================================================
# GET /api/entitlements — Resource-scoped queries (secret key)
# ===========================================================================


class TestListEntitlementsResourceScoped:
    """Tests for resource_type and resource_id query params with secret keys."""

    @patch(f"{_SERVICE}.get_entitlements", new_callable=AsyncMock)
    async def test_company_scoped_query(
        self, mock_get, secret_client: AsyncClient
    ):
        """GET with resource_type=company&resource_id=<uuid> returns company entitlements."""
        ent = _fake_entitlement(
            resource_type="company", resource_id=FAKE_COMPANY_ID
        )
        mock_get.return_value = {"entitlements": [ent], "count": 1}

        resp = await secret_client.get(
            "/api/entitlements",
            params={
                "resource_type": "company",
                "resource_id": FAKE_COMPANY_ID,
            },
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["count"] == 1
        assert data["entitlements"][0]["resource_type"] == "company"
        assert data["entitlements"][0]["resource_id"] == FAKE_COMPANY_ID

    @patch(f"{_SERVICE}.get_entitlements", new_callable=AsyncMock)
    async def test_system_scoped_no_user_id(
        self, mock_get, secret_client: AsyncClient
    ):
        """GET with resource_type=system (no user_id) returns system kill switches."""
        ent = _fake_entitlement(resource_type="system", entitlement_key="kill_switch")
        mock_get.return_value = {"entitlements": [ent], "count": 1}

        resp = await secret_client.get(
            "/api/entitlements",
            params={"resource_type": "system"},
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["count"] == 1
        assert data["entitlements"][0]["resource_type"] == "system"

    @patch(f"{_SERVICE}.get_entitlements", new_callable=AsyncMock)
    async def test_no_resource_params_unchanged(
        self, mock_get, secret_client: AsyncClient
    ):
        """Existing queries without resource params work unchanged."""
        ent = _fake_entitlement()
        mock_get.return_value = {"entitlements": [ent], "count": 1}

        resp = await secret_client.get(
            "/api/entitlements",
            params={"user_id": FAKE_USER_ID},
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["count"] == 1
        assert data["entitlements"][0]["resource_type"] == "user"

    async def test_missing_resource_id_company_400(
        self, secret_client: AsyncClient
    ):
        """Missing resource_id when resource_type=company returns 400."""
        resp = await secret_client.get(
            "/api/entitlements",
            params={"resource_type": "company"},
        )

        assert resp.status_code == 400
        data = resp.json()
        assert data["error"]["code"] == "VALIDATION_FAILED"

    @patch(f"{_SERVICE}.get_entitlements", new_callable=AsyncMock)
    async def test_system_without_resource_id_succeeds(
        self, mock_get, secret_client: AsyncClient
    ):
        """resource_type=system without resource_id succeeds."""
        mock_get.return_value = {"entitlements": [], "count": 0}

        resp = await secret_client.get(
            "/api/entitlements",
            params={"resource_type": "system"},
        )

        assert resp.status_code == 200

    async def test_missing_org_resource_id_400(
        self, secret_client: AsyncClient
    ):
        """Missing resource_id when resource_type=org returns 400."""
        resp = await secret_client.get(
            "/api/entitlements",
            params={"resource_type": "org"},
        )

        assert resp.status_code == 400


# ===========================================================================
# POST /api/entitlements/manual — Resource-scoped grants
# ===========================================================================


class TestManualGrantResourceScoped:
    @patch(f"{_SERVICE}.grant_manual_entitlement", new_callable=AsyncMock)
    async def test_company_grant(
        self, mock_grant, secret_admin_client: AsyncClient
    ):
        """POST manual with resource_type=company creates scoped entitlement."""
        ent = _fake_entitlement(
            resource_type="company", resource_id=FAKE_COMPANY_ID
        )
        mock_grant.return_value = {"entitlement": ent}

        resp = await secret_admin_client.post(
            "/api/entitlements/manual",
            json={
                "entitlement_key": "company_feature",
                "resource_type": "company",
                "resource_id": FAKE_COMPANY_ID,
                "reason": "test company grant",
            },
        )

        assert resp.status_code == 201
        data = resp.json()
        assert data["entitlement"]["resource_type"] == "company"
        assert data["entitlement"]["resource_id"] == FAKE_COMPANY_ID

    @patch(f"{_SERVICE}.grant_manual_entitlement", new_callable=AsyncMock)
    async def test_company_grant_no_beneficiary(
        self, mock_grant, secret_admin_client: AsyncClient
    ):
        """POST manual with resource_type=company, no beneficiary succeeds."""
        ent = _fake_entitlement(
            resource_type="company", resource_id=FAKE_COMPANY_ID
        )
        mock_grant.return_value = {"entitlement": ent}

        resp = await secret_admin_client.post(
            "/api/entitlements/manual",
            json={
                "entitlement_key": "company_feature",
                "resource_type": "company",
                "resource_id": FAKE_COMPANY_ID,
            },
        )

        assert resp.status_code == 201

    async def test_company_grant_missing_resource_id_400(
        self, secret_admin_client: AsyncClient
    ):
        """POST manual with resource_type=company without resource_id returns 400."""
        resp = await secret_admin_client.post(
            "/api/entitlements/manual",
            json={
                "entitlement_key": "company_feature",
                "resource_type": "company",
            },
        )

        assert resp.status_code == 400

    @patch(f"{_SERVICE}.grant_manual_entitlement", new_callable=AsyncMock)
    async def test_system_grant(
        self, mock_grant, secret_admin_client: AsyncClient
    ):
        """POST manual with resource_type=system succeeds."""
        ent = _fake_entitlement(
            resource_type="system", entitlement_key="kill_switch"
        )
        mock_grant.return_value = {"entitlement": ent}

        resp = await secret_admin_client.post(
            "/api/entitlements/manual",
            json={
                "entitlement_key": "kill_switch",
                "resource_type": "system",
            },
        )

        assert resp.status_code == 201


# ===========================================================================
# Key-scope enforcement — Publishable key + JWT
# ===========================================================================


class TestPublishableKeyScope:
    """Publishable key scenarios for the entitlements endpoints."""

    @patch(f"{_SERVICE}.get_entitlements", new_callable=AsyncMock)
    async def test_pub_key_jwt_default_user(
        self, mock_get, pub_user_client: AsyncClient
    ):
        """Publishable key + JWT without user_id/email returns JWT user's entitlements."""
        ent = _fake_entitlement()
        mock_get.return_value = {"entitlements": [ent], "count": 1}

        resp = await pub_user_client.get("/api/entitlements")

        assert resp.status_code == 200
        # Verify the service was called with the JWT user's ID
        mock_get.assert_called_once()
        call_kwargs = mock_get.call_args.kwargs
        assert str(call_kwargs["user_id"]) == FAKE_USER_ID

    async def test_pub_key_jwt_other_user_403(
        self, pub_user_client: AsyncClient
    ):
        """Publishable key + JWT with user_id=OTHER_USER returns 403."""
        resp = await pub_user_client.get(
            "/api/entitlements",
            params={"user_id": FAKE_OTHER_USER_ID},
        )

        assert resp.status_code == 403
        data = resp.json()
        assert data["error"]["code"] == "NOT_AUTHORIZED"

    async def test_pub_key_system_scope_403(
        self, pub_user_client: AsyncClient
    ):
        """Publishable key + JWT with resource_type=system returns 403."""
        resp = await pub_user_client.get(
            "/api/entitlements",
            params={"resource_type": "system"},
        )

        assert resp.status_code == 403
        data = resp.json()
        assert data["error"]["code"] == "SECRET_KEY_REQUIRED"

    async def test_pub_key_company_scope_403(
        self, pub_user_client: AsyncClient
    ):
        """Publishable key + JWT with resource_type=company returns 403."""
        resp = await pub_user_client.get(
            "/api/entitlements",
            params={
                "resource_type": "company",
                "resource_id": FAKE_COMPANY_ID,
            },
        )

        assert resp.status_code == 403
        data = resp.json()
        assert data["error"]["code"] == "SECRET_KEY_REQUIRED"

    async def test_pub_key_no_jwt_401(
        self, pub_no_jwt_client: AsyncClient
    ):
        """Publishable key without JWT returns 401."""
        resp = await pub_no_jwt_client.get("/api/entitlements")

        assert resp.status_code == 401
        data = resp.json()
        assert data["error"]["code"] == "MISSING_AUTH_TOKEN"

    @patch(f"{_SERVICE}.get_entitlements", new_callable=AsyncMock)
    async def test_pub_key_own_user_id_succeeds(
        self, mock_get, pub_user_client: AsyncClient
    ):
        """Publishable key + JWT with own user_id succeeds."""
        mock_get.return_value = {"entitlements": [], "count": 0}

        resp = await pub_user_client.get(
            "/api/entitlements",
            params={"user_id": FAKE_USER_ID},
        )

        assert resp.status_code == 200


# ===========================================================================
# GET /api/entitlements/check — Key scope
# ===========================================================================


class TestCheckEntitlementKeyScope:
    @patch(f"{_SERVICE}.check_entitlement", new_callable=AsyncMock)
    async def test_pub_key_check_own_user(
        self, mock_check, pub_user_client: AsyncClient
    ):
        """Publishable key check with own user_id succeeds."""
        mock_check.return_value = {"has_entitlement": True, "entitlements": []}

        resp = await pub_user_client.get(
            "/api/entitlements/check",
            params={
                "user_id": FAKE_USER_ID,
                "entitlement_key": "pro_access",
            },
        )

        assert resp.status_code == 200

    async def test_pub_key_check_other_user_403(
        self, pub_user_client: AsyncClient
    ):
        """Publishable key check with different user_id returns 403."""
        resp = await pub_user_client.get(
            "/api/entitlements/check",
            params={
                "user_id": FAKE_OTHER_USER_ID,
                "entitlement_key": "pro_access",
            },
        )

        assert resp.status_code == 403

    @patch(f"{_SERVICE}.check_entitlement", new_callable=AsyncMock)
    async def test_pub_key_check_defaults_to_jwt_user(
        self, mock_check, pub_user_client: AsyncClient
    ):
        """Publishable key check without user_id defaults to JWT user."""
        mock_check.return_value = {"has_entitlement": False, "entitlements": []}

        resp = await pub_user_client.get(
            "/api/entitlements/check",
            params={"entitlement_key": "pro_access"},
        )

        assert resp.status_code == 200
        mock_check.assert_called_once()
        call_kwargs = mock_check.call_args.kwargs
        assert str(call_kwargs["user_id"]) == FAKE_USER_ID


# ===========================================================================
# GET /api/entitlements/changes — Secret only
# ===========================================================================


class TestChangesKeyScope:
    @patch(f"{_SERVICE}.get_changes", new_callable=AsyncMock)
    async def test_secret_key_changes(
        self, mock_changes, secret_client: AsyncClient
    ):
        """Secret key can access changes endpoint."""
        mock_changes.return_value = {
            "events": [],
            "cursor": None,
            "has_more": False,
        }

        resp = await secret_client.get("/api/entitlements/changes")

        assert resp.status_code == 200

    async def test_pub_key_changes_403(
        self, pub_user_client: AsyncClient
    ):
        """Publishable key rejected on changes endpoint."""
        resp = await pub_user_client.get("/api/entitlements/changes")

        assert resp.status_code == 403
        data = resp.json()
        assert data["error"]["code"] == "SECRET_KEY_REQUIRED"


# ===========================================================================
# GET /api/entitlements/history — Key scope
# ===========================================================================


class TestHistoryKeyScope:
    @patch(f"{_SERVICE}.get_history", new_callable=AsyncMock)
    async def test_pub_key_own_history(
        self, mock_history, pub_user_client: AsyncClient
    ):
        """Publishable key can access own history."""
        mock_history.return_value = {"history": [], "count": 0}

        resp = await pub_user_client.get(
            "/api/entitlements/history",
            params={"user_id": FAKE_USER_ID},
        )

        assert resp.status_code == 200

    async def test_pub_key_other_user_history_403(
        self, pub_user_client: AsyncClient
    ):
        """Publishable key accessing other user's history returns 403."""
        resp = await pub_user_client.get(
            "/api/entitlements/history",
            params={"user_id": FAKE_OTHER_USER_ID},
        )

        assert resp.status_code == 403


# ===========================================================================
# Cross-application scoping (App A vs App B)
# ===========================================================================


class TestCrossApplicationScoping:
    @patch(f"{_SERVICE}.get_entitlements", new_callable=AsyncMock)
    async def test_app_b_queries_app_a_company_entitlement(self, mock_get):
        """App A grants company entitlement -> App B queries -> empty (application_id scoping)."""
        # App B queries for company entitlements -- gets empty
        app_b = _create_test_app(
            key_type=KeyType.SECRET,
            app_id=FAKE_OTHER_APP_ID,
        )
        mock_get.return_value = {"entitlements": [], "count": 0}

        transport = ASGITransport(app=app_b)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.get(
                "/api/entitlements",
                params={
                    "resource_type": "company",
                    "resource_id": FAKE_COMPANY_ID,
                },
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["count"] == 0

        # Verify the service was called with App B's ID
        mock_get.assert_called_once()
        call_kwargs = mock_get.call_args.kwargs
        assert str(call_kwargs["application_id"]) == FAKE_OTHER_APP_ID


# ===========================================================================
# Admin permission enforcement for non-user types
# ===========================================================================


class TestAdminPermissionsResourceScoped:
    async def test_non_admin_system_grant_rejected(self):
        """Non-admin POST manual with resource_type=system is rejected (no admin dep)."""
        # App with user (not admin) auth -- require_admin_user not overridden
        app = _create_test_app(
            key_type=KeyType.SECRET,
            include_user=True,
        )
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post(
                "/api/entitlements/manual",
                json={
                    "entitlement_key": "kill_switch",
                    "resource_type": "system",
                },
            )

        # The require_admin_user dependency will not be overridden,
        # so it falls through to the real one which checks is_admin.
        # Our mock user has is_admin=False, so this should fail.
        assert resp.status_code in (401, 403)
