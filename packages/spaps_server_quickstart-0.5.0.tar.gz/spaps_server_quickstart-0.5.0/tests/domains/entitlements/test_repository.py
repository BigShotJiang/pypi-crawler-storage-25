"""Unit tests for the entitlements domain repository layer.

The database session is fully mocked so tests exercise only the
repository query construction and result handling.
"""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4


from spaps_server_quickstart.domains.entitlements import repository as repo

FAKE_APP_ID = uuid4()
FAKE_USER_ID = uuid4()


def _mock_entitlement(**overrides):
    """Create a mock entitlement object."""
    ent = MagicMock()
    ent.id = overrides.get("id", uuid4())
    ent.application_id = overrides.get("application_id", FAKE_APP_ID)
    ent.beneficiary_user_id = overrides.get("beneficiary_user_id", FAKE_USER_ID)
    ent.beneficiary_email = overrides.get("beneficiary_email", None)
    ent.entitlement_key = overrides.get("entitlement_key", "pro_access")
    ent.source = overrides.get("source", "manual")
    ent.resource_type = overrides.get("resource_type", "user")
    ent.resource_id = overrides.get("resource_id", None)
    ent.revoked_at = overrides.get("revoked_at", None)
    ent.ends_at = overrides.get("ends_at", None)
    ent.starts_at = overrides.get("starts_at", datetime.now(UTC))
    ent.stripe_subscription_id = overrides.get("stripe_subscription_id", None)
    ent.created_at = datetime.now(UTC)
    ent.updated_at = datetime.now(UTC)
    return ent


def _mock_db_result(items):
    """Create a mock DB result that supports scalar_one_or_none and scalars."""
    result = MagicMock()
    result.scalar_one_or_none.return_value = items[0] if items else None

    scalars_mock = MagicMock()
    scalars_mock.all.return_value = items
    scalars_mock.first.return_value = items[0] if items else None
    result.scalars.return_value = scalars_mock

    return result


# ===========================================================================
# get_entitlement_by_id
# ===========================================================================


class TestGetEntitlementById:
    async def test_found(self):
        """Returns entitlement when found."""
        ent = _mock_entitlement()
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([ent])

        result = await repo.get_entitlement_by_id(db, ent.id)
        assert result == ent

    async def test_not_found(self):
        """Returns None when not found."""
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([])

        result = await repo.get_entitlement_by_id(db, uuid4())
        assert result is None


# ===========================================================================
# find_existing_entitlement
# ===========================================================================


class TestFindExistingEntitlement:
    async def test_finds_by_user_id(self):
        """Finds existing entitlement by user_id."""
        ent = _mock_entitlement()
        db = AsyncMock()
        result_mock = _mock_db_result([ent])
        db.execute.return_value = result_mock

        result = await repo.find_existing_entitlement(
            db,
            application_id=FAKE_APP_ID,
            entitlement_key="pro_access",
            source="manual",
            beneficiary_user_id=FAKE_USER_ID,
        )
        assert result == ent

    async def test_finds_by_email(self):
        """Finds existing entitlement by email."""
        ent = _mock_entitlement(beneficiary_email="user@example.com")
        db = AsyncMock()
        result_mock = _mock_db_result([ent])
        db.execute.return_value = result_mock

        result = await repo.find_existing_entitlement(
            db,
            application_id=FAKE_APP_ID,
            entitlement_key="pro_access",
            source="manual",
            beneficiary_email="User@Example.com",
        )
        assert result == ent

    async def test_not_found(self):
        """Returns None when no match."""
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([])

        result = await repo.find_existing_entitlement(
            db,
            application_id=FAKE_APP_ID,
            entitlement_key="pro_access",
            source="manual",
            beneficiary_user_id=FAKE_USER_ID,
        )
        assert result is None


# ===========================================================================
# list_entitlements
# ===========================================================================


class TestListEntitlements:
    async def test_returns_list(self):
        """Returns list of entitlements."""
        ents = [_mock_entitlement(), _mock_entitlement(entitlement_key="api_access")]
        db = AsyncMock()
        db.execute.return_value = _mock_db_result(ents)

        result = await repo.list_entitlements(db, FAKE_APP_ID)
        assert len(result) == 2

    async def test_empty_list(self):
        """Returns empty list when no entitlements."""
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([])

        result = await repo.list_entitlements(db, FAKE_APP_ID)
        assert len(result) == 0


# ===========================================================================
# create_entitlement
# ===========================================================================


class TestCreateEntitlement:
    async def test_creates_and_returns(self):
        """Creates entitlement and returns it."""
        db = AsyncMock()
        db.add = MagicMock()  # add() is sync in SQLAlchemy

        result = await repo.create_entitlement(
            db,
            application_id=FAKE_APP_ID,
            beneficiary_user_id=FAKE_USER_ID,
            entitlement_type="access",
            entitlement_key="pro_access",
            source="manual",
        )

        db.add.assert_called_once()
        db.flush.assert_called_once()
        db.refresh.assert_called_once()
        assert result is not None


# ===========================================================================
# claim_entitlements_by_email
# ===========================================================================


class TestClaimEntitlementsByEmail:
    async def test_claims_pending(self):
        """Claims pending entitlements."""
        ent = _mock_entitlement(beneficiary_email="user@example.com")
        ent.beneficiary_user_id = None
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([ent])

        result = await repo.claim_entitlements_by_email(
            db, FAKE_APP_ID, "user@example.com", FAKE_USER_ID
        )

        assert len(result) == 1
        assert ent.beneficiary_user_id == FAKE_USER_ID

    async def test_no_pending(self):
        """Returns empty when no pending entitlements."""
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([])

        result = await repo.claim_entitlements_by_email(
            db, FAKE_APP_ID, "user@example.com", FAKE_USER_ID
        )

        assert len(result) == 0


# ===========================================================================
# Entitlement events
# ===========================================================================


class TestCreateEvent:
    async def test_creates_and_returns(self):
        """Creates event and returns it."""
        db = AsyncMock()
        db.add = MagicMock()  # add() is sync in SQLAlchemy

        result = await repo.create_event(
            db,
            entitlement_id=uuid4(),
            event_type="granted",
            application_id=FAKE_APP_ID,
        )

        db.add.assert_called_once()
        db.flush.assert_called_once()


class TestListEvents:
    async def test_returns_events(self):
        """Returns list of events."""
        event = MagicMock()
        event.created_at = datetime.now(UTC)
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([event])

        result = await repo.list_events(db, FAKE_APP_ID)
        assert len(result) == 1


# ===========================================================================
# Mappings
# ===========================================================================


class TestMappingOperations:
    async def test_get_mapping_by_id(self):
        """Fetches mapping by id and application_id."""
        mapping = MagicMock()
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([mapping])

        result = await repo.get_mapping_by_id(db, uuid4(), FAKE_APP_ID)
        assert result == mapping

    async def test_list_mappings(self):
        """Returns list of mappings."""
        mapping = MagicMock()
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([mapping])

        result = await repo.list_mappings(db, FAKE_APP_ID)
        assert len(result) == 1

    async def test_get_mappings_for_price(self):
        """Returns active mappings for a price."""
        mapping = MagicMock()
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([mapping])

        result = await repo.get_mappings_for_price(
            db, FAKE_APP_ID, "price_123"
        )
        assert len(result) == 1

    async def test_create_mapping(self):
        """Creates mapping and returns it."""
        db = AsyncMock()
        db.add = MagicMock()  # add() is sync in SQLAlchemy

        result = await repo.create_mapping(
            db,
            application_id=FAKE_APP_ID,
            stripe_price_id="price_123",
            entitlement_key="pro_access",
            entitlement_type="one_time",
        )

        db.add.assert_called_once()
        db.flush.assert_called_once()

    async def test_deactivate_mapping(self):
        """Deactivates mapping by setting is_active=False."""
        mapping = MagicMock()
        mapping.is_active = True
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([mapping])

        result = await repo.deactivate_mapping(db, uuid4(), FAKE_APP_ID)
        assert result is not None
        assert mapping.is_active is False

    async def test_deactivate_mapping_not_found(self):
        """Returns None for unknown mapping."""
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([])

        result = await repo.deactivate_mapping(db, uuid4(), FAKE_APP_ID)
        assert result is None


# ===========================================================================
# find_entitlements_by_subscription
# ===========================================================================


class TestFindEntitlementsBySubscription:
    async def test_finds_entitlements(self):
        """Returns entitlements for a subscription ID."""
        ent1 = _mock_entitlement(stripe_subscription_id="sub_123")
        ent2 = _mock_entitlement(
            entitlement_key="api_access", stripe_subscription_id="sub_123"
        )
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([ent1, ent2])

        result = await repo.find_entitlements_by_subscription(db, "sub_123")
        assert len(result) == 2

    async def test_no_entitlements(self):
        """Returns empty list when no subscription entitlements."""
        db = AsyncMock()
        db.execute.return_value = _mock_db_result([])

        result = await repo.find_entitlements_by_subscription(db, "sub_missing")
        assert len(result) == 0
