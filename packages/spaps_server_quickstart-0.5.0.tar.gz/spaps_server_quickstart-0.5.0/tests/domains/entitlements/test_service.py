"""Unit tests for the entitlements domain service layer.

The repository layer is fully mocked so tests exercise only the
service orchestration, business logic, and error handling.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import UUID, uuid4

import pytest

from spaps_server_quickstart.domains.entitlements import service
from spaps_server_quickstart.domains.entitlements.errors import (
    EntitlementAlreadyRevokedError,
    EntitlementNotFoundError,
    MappingAlreadyExistsError,
    MappingNotFoundError,
    NoBeneficiaryError,
)
from spaps_server_quickstart.domains.errors import ValidationError

_REPO = "spaps_server_quickstart.domains.entitlements.service.repo"

FAKE_APP_ID = uuid4()
FAKE_USER_ID = uuid4()
FAKE_ADMIN_ID = uuid4()


def _make_entitlement(
    entitlement_key: str = "pro_access",
    source: str = "manual",
    beneficiary_user_id: UUID | None = None,
    beneficiary_email: str | None = None,
    revoked_at: datetime | None = None,
    ends_at: datetime | None = None,
    resource_type: str = "user",
    resource_id: UUID | None = None,
) -> MagicMock:
    """Build a mock Entitlement model instance."""
    ent = MagicMock()
    ent.id = uuid4()
    ent.application_id = FAKE_APP_ID
    ent.beneficiary_user_id = beneficiary_user_id or FAKE_USER_ID
    ent.beneficiary_email = beneficiary_email
    ent.entitlement_type = "access"
    ent.entitlement_key = entitlement_key
    ent.source = source
    ent.resource_type = resource_type
    ent.resource_id = resource_id
    ent.starts_at = datetime.now(UTC)
    ent.ends_at = ends_at
    ent.revoked_at = revoked_at
    ent.crypto_invoice_id = None
    ent.stripe_product_id = None
    ent.stripe_price_id = None
    ent.stripe_subscription_id = None
    ent.stripe_session_id = None
    ent.stripe_invoice_id = None
    ent.manual_grant_id = "manual-123"
    ent.manual_grant_reason = "test"
    ent.granted_by_user_id = FAKE_ADMIN_ID
    ent.revoked_by_user_id = None
    ent.revoked_reason = None
    ent.metadata_ = {}
    ent.created_at = datetime.now(UTC)
    ent.updated_at = datetime.now(UTC)
    return ent


def _make_event(event_type: str = "granted") -> MagicMock:
    """Build a mock EntitlementEvent model instance."""
    event = MagicMock()
    event.id = uuid4()
    event.entitlement_id = uuid4()
    event.event_type = event_type
    event.application_id = FAKE_APP_ID
    event.user_id = FAKE_USER_ID
    event.email = None
    event.entitlement_key = "pro_access"
    event.source = "manual"
    event.previous_state = None
    event.new_state = {"starts_at": datetime.now(UTC).isoformat(), "ends_at": None, "revoked_at": None}
    event.triggered_by = "api"
    event.metadata_ = {}
    event.created_at = datetime.now(UTC)
    return event


def _make_mapping(
    entitlement_key: str = "pro_access",
    stripe_price_id: str = "price_123",
    is_active: bool = True,
) -> MagicMock:
    """Build a mock EntitlementMapping model instance."""
    mapping = MagicMock()
    mapping.id = uuid4()
    mapping.application_id = FAKE_APP_ID
    mapping.stripe_price_id = stripe_price_id
    mapping.entitlement_key = entitlement_key
    mapping.entitlement_type = "one_time"
    mapping.duration_days = None
    mapping.metadata_ = {}
    mapping.is_active = is_active
    mapping.created_at = datetime.now(UTC)
    mapping.updated_at = datetime.now(UTC)
    return mapping


# ===========================================================================
# grant_entitlement
# ===========================================================================


class TestGrantEntitlement:
    @patch(_REPO)
    async def test_creates_new_entitlement(self, mock_repo):
        """Grants new entitlement when none exists."""
        mock_repo.find_existing_entitlement = AsyncMock(return_value=None)
        ent = _make_entitlement()
        mock_repo.create_entitlement = AsyncMock(return_value=ent)
        mock_repo.create_event = AsyncMock(return_value=_make_event())

        db = AsyncMock()
        result = await service.grant_entitlement(
            db,
            application_id=FAKE_APP_ID,
            entitlement_key="pro_access",
            source="manual",
            beneficiary_user_id=FAKE_USER_ID,
        )

        assert result["created"] is True
        assert result["entitlement"]["entitlement_key"] == "pro_access"

    @patch(_REPO)
    async def test_idempotent_returns_existing(self, mock_repo):
        """Returns existing entitlement without creating duplicate."""
        existing = _make_entitlement()
        mock_repo.find_existing_entitlement = AsyncMock(return_value=existing)

        db = AsyncMock()
        result = await service.grant_entitlement(
            db,
            application_id=FAKE_APP_ID,
            entitlement_key="pro_access",
            source="manual",
            beneficiary_user_id=FAKE_USER_ID,
        )

        assert result["created"] is False
        mock_repo.create_entitlement.assert_not_called()

    @patch(_REPO)
    async def test_no_beneficiary_raises(self, mock_repo):
        """Raises NoBeneficiaryError when neither user_id nor email provided."""
        db = AsyncMock()
        with pytest.raises(NoBeneficiaryError):
            await service.grant_entitlement(
                db,
                application_id=FAKE_APP_ID,
                entitlement_key="pro_access",
                source="manual",
            )

    @patch(_REPO)
    async def test_grant_with_email(self, mock_repo):
        """Grants entitlement using email as beneficiary."""
        mock_repo.find_existing_entitlement = AsyncMock(return_value=None)
        ent = _make_entitlement(beneficiary_email="user@example.com")
        mock_repo.create_entitlement = AsyncMock(return_value=ent)
        mock_repo.create_event = AsyncMock(return_value=_make_event())

        db = AsyncMock()
        result = await service.grant_entitlement(
            db,
            application_id=FAKE_APP_ID,
            entitlement_key="pro_access",
            source="manual",
            beneficiary_email="user@example.com",
        )

        assert result["created"] is True


# ===========================================================================
# get_entitlements
# ===========================================================================


class TestGetEntitlements:
    @patch(_REPO)
    async def test_returns_entitlements_and_count(self, mock_repo):
        """Returns entitlements list and count."""
        entries = [_make_entitlement(), _make_entitlement(entitlement_key="api_access")]
        mock_repo.list_entitlements = AsyncMock(return_value=entries)

        db = AsyncMock()
        result = await service.get_entitlements(
            db, application_id=FAKE_APP_ID, user_id=FAKE_USER_ID
        )

        assert result["count"] == 2
        assert len(result["entitlements"]) == 2

    @patch(_REPO)
    async def test_passes_filter_params(self, mock_repo):
        """Passes filter parameters to repository."""
        mock_repo.list_entitlements = AsyncMock(return_value=[])

        db = AsyncMock()
        await service.get_entitlements(
            db,
            application_id=FAKE_APP_ID,
            user_id=FAKE_USER_ID,
            entitlement_key="pro_access",
            include_expired=True,
            include_revoked=True,
            limit=5,
        )

        mock_repo.list_entitlements.assert_called_once_with(
            db,
            FAKE_APP_ID,
            user_id=FAKE_USER_ID,
            email=None,
            entitlement_key="pro_access",
            resource_type=None,
            resource_id=None,
            include_expired=True,
            include_revoked=True,
            limit=5,
        )

    @patch(_REPO)
    async def test_passes_resource_type_and_id(self, mock_repo):
        """Passes resource_type and resource_id to repository."""
        mock_repo.list_entitlements = AsyncMock(return_value=[])
        company_id = uuid4()

        db = AsyncMock()
        await service.get_entitlements(
            db,
            application_id=FAKE_APP_ID,
            resource_type="company",
            resource_id=company_id,
        )

        mock_repo.list_entitlements.assert_called_once()
        call_kwargs = mock_repo.list_entitlements.call_args.kwargs
        assert call_kwargs["resource_type"] == "company"
        assert call_kwargs["resource_id"] == company_id


# ===========================================================================
# check_entitlement
# ===========================================================================


class TestCheckEntitlement:
    @patch(_REPO)
    async def test_has_entitlement(self, mock_repo):
        """Returns has_entitlement=True when active entitlements exist."""
        mock_repo.list_entitlements = AsyncMock(return_value=[_make_entitlement()])

        db = AsyncMock()
        result = await service.check_entitlement(
            db,
            application_id=FAKE_APP_ID,
            user_id=FAKE_USER_ID,
            entitlement_key="pro_access",
        )

        assert result["has_entitlement"] is True
        assert len(result["entitlements"]) == 1

    @patch(_REPO)
    async def test_no_access(self, mock_repo):
        """Returns has_entitlement=False when no active entitlements."""
        mock_repo.list_entitlements = AsyncMock(return_value=[])

        db = AsyncMock()
        result = await service.check_entitlement(
            db,
            application_id=FAKE_APP_ID,
            user_id=FAKE_USER_ID,
            entitlement_key="pro_access",
        )

        assert result["has_entitlement"] is False
        assert len(result["entitlements"]) == 0

    @patch(_REPO)
    async def test_requires_identifier(self, mock_repo):
        """Raises ValidationError when neither user_id nor email provided."""
        db = AsyncMock()
        with pytest.raises(ValidationError):
            await service.check_entitlement(
                db,
                application_id=FAKE_APP_ID,
            )


# ===========================================================================
# get_changes
# ===========================================================================


class TestGetChanges:
    @patch(_REPO)
    async def test_returns_events(self, mock_repo):
        """Returns event list with cursor."""
        events = [_make_event(), _make_event("renewed")]
        mock_repo.list_events = AsyncMock(return_value=events)

        db = AsyncMock()
        result = await service.get_changes(
            db, application_id=FAKE_APP_ID
        )

        assert len(result["events"]) == 2
        assert result["has_more"] is False
        assert result["cursor"] is not None

    @patch(_REPO)
    async def test_has_more_when_exceeds_limit(self, mock_repo):
        """Sets has_more=True when events exceed limit."""
        events = [_make_event() for _ in range(4)]
        mock_repo.list_events = AsyncMock(return_value=events)

        db = AsyncMock()
        result = await service.get_changes(
            db, application_id=FAKE_APP_ID, limit=3
        )

        assert result["has_more"] is True
        assert len(result["events"]) == 3

    @patch(_REPO)
    async def test_empty_events(self, mock_repo):
        """Returns empty list when no events."""
        mock_repo.list_events = AsyncMock(return_value=[])

        db = AsyncMock()
        result = await service.get_changes(
            db, application_id=FAKE_APP_ID
        )

        assert len(result["events"]) == 0
        assert result["cursor"] is None
        assert result["has_more"] is False


# ===========================================================================
# get_history
# ===========================================================================


class TestGetHistory:
    @patch(_REPO)
    async def test_returns_active_history(self, mock_repo):
        """Returns active entitlements in history."""
        ent = _make_entitlement()
        mock_repo.list_entitlements = AsyncMock(return_value=[ent])

        db = AsyncMock()
        result = await service.get_history(
            db, application_id=FAKE_APP_ID, user_id=FAKE_USER_ID
        )

        assert result["count"] == 1
        assert result["history"][0]["status"] == "active"

    @patch(_REPO)
    async def test_revoked_status(self, mock_repo):
        """Sets status to revoked for revoked entitlements."""
        ent = _make_entitlement(revoked_at=datetime.now(UTC))
        mock_repo.list_entitlements = AsyncMock(return_value=[ent])

        db = AsyncMock()
        result = await service.get_history(
            db, application_id=FAKE_APP_ID, user_id=FAKE_USER_ID
        )

        assert result["history"][0]["status"] == "revoked"

    @patch(_REPO)
    async def test_expired_status(self, mock_repo):
        """Sets status to expired for expired entitlements."""
        past = datetime.now(UTC) - timedelta(days=1)
        ent = _make_entitlement(ends_at=past)
        mock_repo.list_entitlements = AsyncMock(return_value=[ent])

        db = AsyncMock()
        result = await service.get_history(
            db, application_id=FAKE_APP_ID, user_id=FAKE_USER_ID
        )

        assert result["history"][0]["status"] == "expired"


# ===========================================================================
# claim_pending_entitlements
# ===========================================================================


class TestClaimPendingEntitlements:
    @patch(_REPO)
    async def test_claims_pending(self, mock_repo):
        """Claims pending entitlements and returns them."""
        ent = _make_entitlement(beneficiary_email="user@example.com")
        mock_repo.claim_entitlements_by_email = AsyncMock(return_value=[ent])
        mock_repo.create_event = AsyncMock(return_value=_make_event("claimed"))

        db = AsyncMock()
        result = await service.claim_pending_entitlements(
            db,
            application_id=FAKE_APP_ID,
            user_id=FAKE_USER_ID,
            email="user@example.com",
        )

        assert result["count"] == 1
        assert len(result["claimed"]) == 1

    @patch(_REPO)
    async def test_no_pending(self, mock_repo):
        """Returns empty when no pending entitlements."""
        mock_repo.claim_entitlements_by_email = AsyncMock(return_value=[])

        db = AsyncMock()
        result = await service.claim_pending_entitlements(
            db,
            application_id=FAKE_APP_ID,
            user_id=FAKE_USER_ID,
            email="user@example.com",
        )

        assert result["count"] == 0
        assert len(result["claimed"]) == 0


# ===========================================================================
# grant_manual_entitlement
# ===========================================================================


class TestGrantManualEntitlement:
    @patch(_REPO)
    async def test_success(self, mock_repo):
        """Creates manual entitlement with correct source."""
        mock_repo.find_existing_entitlement = AsyncMock(return_value=None)
        ent = _make_entitlement(source="manual")
        mock_repo.create_entitlement = AsyncMock(return_value=ent)
        mock_repo.create_event = AsyncMock(return_value=_make_event())

        db = AsyncMock()
        result = await service.grant_manual_entitlement(
            db,
            application_id=FAKE_APP_ID,
            beneficiary_user_id=FAKE_USER_ID,
            entitlement_key="pro_access",
            granted_by_user_id=FAKE_ADMIN_ID,
        )

        assert result["entitlement"]["source"] == "manual"

    @patch(_REPO)
    async def test_no_beneficiary_raises_for_user_type(self, mock_repo):
        """Raises NoBeneficiaryError when user-scoped and no user_id/email."""
        db = AsyncMock()
        with pytest.raises(NoBeneficiaryError):
            await service.grant_manual_entitlement(
                db,
                application_id=FAKE_APP_ID,
                entitlement_key="pro_access",
                granted_by_user_id=FAKE_ADMIN_ID,
            )

    @patch(_REPO)
    async def test_company_grant_no_beneficiary_succeeds(self, mock_repo):
        """Company-scoped grant without beneficiary succeeds."""
        mock_repo.find_existing_entitlement = AsyncMock(return_value=None)
        ent = _make_entitlement(source="manual")
        mock_repo.create_entitlement = AsyncMock(return_value=ent)
        mock_repo.create_event = AsyncMock(return_value=_make_event())

        db = AsyncMock()
        result = await service.grant_manual_entitlement(
            db,
            application_id=FAKE_APP_ID,
            entitlement_key="company_feature",
            resource_type="company",
            resource_id=uuid4(),
            granted_by_user_id=FAKE_ADMIN_ID,
        )

        assert result["entitlement"] is not None

    @patch(_REPO)
    async def test_system_grant_no_beneficiary_succeeds(self, mock_repo):
        """System-scoped grant without beneficiary succeeds."""
        mock_repo.find_existing_entitlement = AsyncMock(return_value=None)
        ent = _make_entitlement(source="manual")
        mock_repo.create_entitlement = AsyncMock(return_value=ent)
        mock_repo.create_event = AsyncMock(return_value=_make_event())

        db = AsyncMock()
        result = await service.grant_manual_entitlement(
            db,
            application_id=FAKE_APP_ID,
            entitlement_key="kill_switch",
            resource_type="system",
            granted_by_user_id=FAKE_ADMIN_ID,
        )

        assert result["entitlement"] is not None

    @patch(_REPO)
    async def test_resource_type_passed_to_grant(self, mock_repo):
        """Resource type and ID are passed through to grant_entitlement."""
        mock_repo.find_existing_entitlement = AsyncMock(return_value=None)
        ent = _make_entitlement(source="manual")
        mock_repo.create_entitlement = AsyncMock(return_value=ent)
        mock_repo.create_event = AsyncMock(return_value=_make_event())

        company_id = uuid4()
        db = AsyncMock()
        await service.grant_manual_entitlement(
            db,
            application_id=FAKE_APP_ID,
            entitlement_key="company_feature",
            resource_type="company",
            resource_id=company_id,
            granted_by_user_id=FAKE_ADMIN_ID,
        )

        # Verify create_entitlement was called with resource fields
        call_kwargs = mock_repo.create_entitlement.call_args.kwargs
        assert call_kwargs["resource_type"] == "company"
        assert call_kwargs["resource_id"] == company_id


# ===========================================================================
# revoke_entitlement
# ===========================================================================


class TestRevokeEntitlement:
    @patch(_REPO)
    async def test_success(self, mock_repo):
        """Revokes entitlement and returns it."""
        ent = _make_entitlement()
        mock_repo.get_entitlement_by_id = AsyncMock(return_value=ent)
        revoked = _make_entitlement(revoked_at=datetime.now(UTC))
        mock_repo.update_entitlement = AsyncMock(return_value=revoked)
        mock_repo.create_event = AsyncMock(return_value=_make_event("revoked"))

        db = AsyncMock()
        result = await service.revoke_entitlement(
            db,
            entitlement_id=ent.id,
            revoked_by_user_id=FAKE_ADMIN_ID,
            reason="Testing",
        )

        assert result["entitlement"] is not None

    @patch(_REPO)
    async def test_not_found_raises(self, mock_repo):
        """Raises EntitlementNotFoundError for unknown ID."""
        mock_repo.get_entitlement_by_id = AsyncMock(return_value=None)

        db = AsyncMock()
        with pytest.raises(EntitlementNotFoundError):
            await service.revoke_entitlement(
                db,
                entitlement_id=uuid4(),
                revoked_by_user_id=FAKE_ADMIN_ID,
            )

    @patch(_REPO)
    async def test_already_revoked_raises(self, mock_repo):
        """Raises EntitlementAlreadyRevokedError for already revoked."""
        ent = _make_entitlement(revoked_at=datetime.now(UTC))
        mock_repo.get_entitlement_by_id = AsyncMock(return_value=ent)

        db = AsyncMock()
        with pytest.raises(EntitlementAlreadyRevokedError):
            await service.revoke_entitlement(
                db,
                entitlement_id=ent.id,
                revoked_by_user_id=FAKE_ADMIN_ID,
            )


# ===========================================================================
# renew_subscription_entitlements
# ===========================================================================


class TestRenewSubscriptionEntitlements:
    @patch(_REPO)
    async def test_renews_all(self, mock_repo):
        """Renews all entitlements for a subscription."""
        ent1 = _make_entitlement(entitlement_key="pro_access")
        ent1.stripe_subscription_id = "sub_123"
        ent2 = _make_entitlement(entitlement_key="api_access")
        ent2.stripe_subscription_id = "sub_123"

        mock_repo.find_entitlements_by_subscription = AsyncMock(return_value=[ent1, ent2])
        mock_repo.update_entitlement = AsyncMock(side_effect=[ent1, ent2])
        mock_repo.create_event = AsyncMock(return_value=_make_event("renewed"))

        db = AsyncMock()
        new_end = datetime.now(UTC) + timedelta(days=30)
        result = await service.renew_subscription_entitlements(
            db, "sub_123", new_end
        )

        assert len(result) == 2

    @patch(_REPO)
    async def test_no_entitlements_returns_empty(self, mock_repo):
        """Returns empty list when no subscription entitlements found."""
        mock_repo.find_entitlements_by_subscription = AsyncMock(return_value=[])

        db = AsyncMock()
        new_end = datetime.now(UTC) + timedelta(days=30)
        result = await service.renew_subscription_entitlements(
            db, "sub_missing", new_end
        )

        assert len(result) == 0


# ===========================================================================
# Stripe integration stubs
# ===========================================================================


class TestStripeIntegrationSignatures:
    async def test_process_stripe_checkout_returns_empty_no_user(self):
        """process_stripe_checkout returns empty when no user_id or email."""
        db = AsyncMock()
        result = await service.process_stripe_checkout(db, {"id": "cs_1"}, [], uuid4())
        assert result == []

    async def test_process_stripe_checkout_returns_empty_no_line_items(self):
        """process_stripe_checkout returns empty when no line items."""
        db = AsyncMock()
        session = {"id": "cs_1", "metadata": {"user_id": str(uuid4())}}
        result = await service.process_stripe_checkout(db, session, None, uuid4())
        assert result == []

    async def test_process_stripe_subscription_returns_empty_no_user(self):
        """process_stripe_subscription returns empty when no user_id in metadata."""
        db = AsyncMock()
        result = await service.process_stripe_subscription(db, {"id": "sub_1"}, "created", uuid4())
        assert result == []

    async def test_process_stripe_invoice_returns_empty_no_subscription(self):
        """process_stripe_invoice returns empty for non-subscription invoices."""
        db = AsyncMock()
        result = await service.process_stripe_invoice(db, {"id": "inv_1"}, uuid4())
        assert result == []

    async def test_process_stripe_invoice_returns_empty_no_line_items(self):
        """process_stripe_invoice returns empty when no subscription line items."""
        db = AsyncMock()
        invoice = {"id": "inv_1", "subscription": "sub_1", "lines": {"data": []}}
        result = await service.process_stripe_invoice(db, invoice, uuid4())
        assert result == []


# ===========================================================================
# Stripe integration processing
# ===========================================================================


class TestProcessStripeCheckout:
    async def test_grants_mapped_checkout_entitlements(self):
        """Checkout fulfillment passes mapped Stripe metadata through grant."""
        db = AsyncMock()
        starts_at = datetime(2026, 1, 10, tzinfo=UTC)
        ends_at = datetime(2026, 2, 10, tzinfo=UTC)
        session = {
            "id": "cs_123",
            "mode": "subscription",
            "subscription": {"id": "sub_123"},
            "amount_total": 5000,
            "currency": "usd",
            "customer_email": "customer@example.com",
            "metadata": {
                "user_id": str(FAKE_USER_ID),
                "entitlement_starts_at": starts_at.isoformat(),
                "entitlement_ends_at": ends_at.isoformat(),
            },
        }
        line_items = [
            {
                "price": {"id": "price_123", "product": "prod_123"},
                "description": "Fallback product name",
            }
        ]
        mapping = {
            "entitlement_key": "pro_access",
            "duration_days": None,
            "metadata": {"product_name": "Mapped product"},
        }
        created_entitlement = {"id": "ent_123", "entitlement_key": "pro_access"}

        with (
            patch(
                "spaps_server_quickstart.domains.entitlements.service.get_mappings_for_price",
                new=AsyncMock(return_value=[mapping]),
            ) as mock_get_mappings,
            patch(
                "spaps_server_quickstart.domains.entitlements.service.grant_entitlement",
                new=AsyncMock(
                    return_value={
                        "created": True,
                        "entitlement": created_entitlement,
                    }
                ),
            ) as mock_grant,
        ):
            result = await service.process_stripe_checkout(
                db,
                session,
                line_items,
                FAKE_APP_ID,
            )

        assert result == [created_entitlement]
        mock_get_mappings.assert_awaited_once_with(db, FAKE_APP_ID, "price_123")
        kwargs = mock_grant.await_args.kwargs
        assert kwargs["beneficiary_user_id"] == FAKE_USER_ID
        assert kwargs["beneficiary_email"] == "customer@example.com"
        assert kwargs["starts_at"] == starts_at
        assert kwargs["ends_at"] == ends_at
        assert kwargs["stripe_subscription_id"] == "sub_123"
        assert kwargs["stripe_product_id"] == "prod_123"
        assert kwargs["metadata"]["product_name"] == "Mapped product"

    async def test_skips_idempotent_checkout_results_and_uses_duration_fallback(self):
        """Mapped items still grant with derived dates, but idempotent rows are not returned."""
        db = AsyncMock()
        session = {
            "id": "cs_456",
            "amount_total": 2000,
            "currency": "usd",
            "metadata": {"user_id": str(FAKE_USER_ID)},
        }
        line_items = [{"price": "price_456", "description": "Starter plan"}]
        mapping = {
            "entitlement_key": "starter_access",
            "duration_days": 7,
            "metadata": {},
        }
        before = datetime.now(UTC)

        with (
            patch(
                "spaps_server_quickstart.domains.entitlements.service.get_mappings_for_price",
                new=AsyncMock(return_value=[mapping]),
            ),
            patch(
                "spaps_server_quickstart.domains.entitlements.service.grant_entitlement",
                new=AsyncMock(
                    return_value={
                        "created": False,
                        "entitlement": {"id": "existing"},
                    }
                ),
            ) as mock_grant,
        ):
            result = await service.process_stripe_checkout(
                db,
                session,
                line_items,
                FAKE_APP_ID,
            )
        after = datetime.now(UTC)

        assert result == []
        kwargs = mock_grant.await_args.kwargs
        assert kwargs["starts_at"] is None
        assert before + timedelta(days=7) <= kwargs["ends_at"] <= after + timedelta(days=7)
        assert kwargs["metadata"]["product_name"] == "Starter plan"

    async def test_continues_after_checkout_grant_failure(self):
        """A failed mapping does not prevent later checkout grants from succeeding."""
        db = AsyncMock()
        session = {
            "id": "cs_789",
            "metadata": {"user_id": str(FAKE_USER_ID)},
        }
        line_items = [{"price": {"id": "price_789"}, "description": "Pro"}]
        mappings = [
            {"entitlement_key": "broken_access", "metadata": {}},
            {"entitlement_key": "working_access", "metadata": {}},
        ]

        with (
            patch(
                "spaps_server_quickstart.domains.entitlements.service.get_mappings_for_price",
                new=AsyncMock(return_value=mappings),
            ),
            patch(
                "spaps_server_quickstart.domains.entitlements.service.grant_entitlement",
                new=AsyncMock(
                    side_effect=[
                        RuntimeError("boom"),
                        {
                            "created": True,
                            "entitlement": {"id": "ent_2", "entitlement_key": "working_access"},
                        },
                    ]
                ),
            ),
        ):
            result = await service.process_stripe_checkout(
                db,
                session,
                line_items,
                FAKE_APP_ID,
            )

        assert result == [{"id": "ent_2", "entitlement_key": "working_access"}]


class TestProcessStripeSubscription:
    @patch(_REPO)
    async def test_created_skips_checkout_created_entitlements(self, mock_repo):
        """subscription.created does not duplicate entitlements already created by checkout."""
        db = AsyncMock()
        subscription = {
            "id": "sub_123",
            "status": "active",
            "metadata": {"user_id": str(FAKE_USER_ID)},
            "items": {"data": [{"price": "price_123"}]},
        }
        mapping = {"entitlement_key": "pro_access"}
        mock_repo.find_existing_entitlement = AsyncMock(return_value=_make_entitlement())

        with (
            patch(
                "spaps_server_quickstart.domains.entitlements.service.get_mappings_for_price",
                new=AsyncMock(return_value=[mapping]),
            ),
            patch(
                "spaps_server_quickstart.domains.entitlements.service.grant_entitlement",
                new=AsyncMock(),
            ) as mock_grant,
        ):
            result = await service.process_stripe_subscription(
                db,
                subscription,
                "created",
                FAKE_APP_ID,
            )

        assert result == []
        mock_grant.assert_not_awaited()

    @patch(_REPO)
    async def test_updated_renews_when_period_extends(self, mock_repo):
        """subscription.updated extends existing entitlements when Stripe period grows."""
        db = AsyncMock()
        current_period_end = datetime.now(UTC) + timedelta(days=30)
        expected_period_end = datetime.fromtimestamp(
            int(current_period_end.timestamp()),
            tz=UTC,
        )
        previous_period_end = current_period_end - timedelta(days=7)
        subscription = {
            "id": "sub_456",
            "status": "active",
            "current_period_end": int(current_period_end.timestamp()),
            "metadata": {"user_id": str(FAKE_USER_ID)},
            "items": {"data": [{"price": {"id": "price_456", "product": "prod_456"}}]},
        }
        mapping = {"entitlement_key": "team_access"}
        granted = {
            "created": False,
            "entitlement": {
                "id": "ent_existing",
                "ends_at": previous_period_end.isoformat(),
            },
        }

        with (
            patch(
                "spaps_server_quickstart.domains.entitlements.service.get_mappings_for_price",
                new=AsyncMock(return_value=[mapping]),
            ),
            patch(
                "spaps_server_quickstart.domains.entitlements.service.grant_entitlement",
                new=AsyncMock(return_value=granted),
            ) as mock_grant,
            patch(
                "spaps_server_quickstart.domains.entitlements.service.renew_subscription_entitlements",
                new=AsyncMock(return_value=[]),
            ) as mock_renew,
        ):
            result = await service.process_stripe_subscription(
                db,
                subscription,
                "updated",
                FAKE_APP_ID,
            )

        assert result == [granted["entitlement"]]
        kwargs = mock_grant.await_args.kwargs
        assert kwargs["stripe_subscription_id"] == "sub_456"
        assert kwargs["stripe_product_id"] == "prod_456"
        assert kwargs["ends_at"] == expected_period_end
        mock_renew.assert_awaited_once_with(db, "sub_456", expected_period_end)

    @patch(_REPO)
    async def test_deleted_updates_matching_active_entitlements(self, mock_repo):
        """subscription.deleted updates matching active entitlements and records an event."""
        db = AsyncMock()
        current_period_end = datetime.now(UTC) + timedelta(days=14)
        expected_period_end = datetime.fromtimestamp(
            int(current_period_end.timestamp()),
            tz=UTC,
        )
        subscription = {
            "id": "sub_789",
            "current_period_end": int(current_period_end.timestamp()),
            "metadata": {"user_id": str(FAKE_USER_ID)},
            "items": {"data": [{"price": {"id": "price_789"}}]},
        }
        active = _make_entitlement(entitlement_key="pro_access")
        revoked = _make_entitlement(
            entitlement_key="pro_access",
            revoked_at=datetime.now(UTC),
        )
        other = _make_entitlement(entitlement_key="other_access")
        updated = _make_entitlement(
            entitlement_key="pro_access",
            ends_at=current_period_end,
        )
        mock_repo.find_entitlements_by_subscription = AsyncMock(
            return_value=[active, revoked, other]
        )
        mock_repo.update_entitlement = AsyncMock(return_value=updated)

        with (
            patch(
                "spaps_server_quickstart.domains.entitlements.service.get_mappings_for_price",
                new=AsyncMock(return_value=[{"entitlement_key": "pro_access"}]),
            ),
            patch(
                "spaps_server_quickstart.domains.entitlements.service._create_event_for_entitlement",
                new=AsyncMock(),
            ) as mock_create_event,
        ):
            result = await service.process_stripe_subscription(
                db,
                subscription,
                "deleted",
                FAKE_APP_ID,
            )

        assert len(result) == 1
        assert result[0]["id"] == str(updated.id)
        mock_repo.update_entitlement.assert_awaited_once_with(
            db,
            active.id,
            ends_at=expected_period_end,
        )
        mock_create_event.assert_awaited_once()


class TestProcessStripeInvoice:
    async def test_returns_empty_when_subscription_line_has_no_period_end(self):
        db = AsyncMock()
        invoice = {
            "id": "inv_2",
            "subscription": "sub_2",
            "lines": {"data": [{"subscription_item": "si_1", "period": {}}]},
        }

        result = await service.process_stripe_invoice(db, invoice, FAKE_APP_ID)

        assert result == []

    async def test_renews_matching_subscription_entitlements(self):
        db = AsyncMock()
        period_end = int((datetime.now(UTC) + timedelta(days=30)).timestamp())
        renewed = [{"id": "ent_renewed"}]
        invoice = {
            "id": "inv_3",
            "subscription": "sub_renew",
            "lines": {
                "data": [
                    {
                        "subscription": "sub_renew",
                        "period": {"end": period_end},
                    }
                ]
            },
        }

        with patch(
            "spaps_server_quickstart.domains.entitlements.service.renew_subscription_entitlements",
            new=AsyncMock(return_value=renewed),
        ) as mock_renew:
            result = await service.process_stripe_invoice(db, invoice, FAKE_APP_ID)

        assert result == renewed
        mock_renew.assert_awaited_once_with(
            db,
            "sub_renew",
            datetime.fromtimestamp(period_end, tz=UTC),
        )


# ===========================================================================
# Mappings
# ===========================================================================


class TestListMappings:
    @patch(_REPO)
    async def test_returns_mappings_and_count(self, mock_repo):
        """Returns mappings list and count."""
        mappings = [_make_mapping(), _make_mapping(entitlement_key="api_access")]
        mock_repo.list_mappings = AsyncMock(return_value=mappings)

        db = AsyncMock()
        result = await service.list_mappings(
            db, application_id=FAKE_APP_ID
        )

        assert result["count"] == 2
        assert len(result["mappings"]) == 2

    @patch(_REPO)
    async def test_active_only_filter(self, mock_repo):
        """Passes active_only to repository."""
        mock_repo.list_mappings = AsyncMock(return_value=[])

        db = AsyncMock()
        await service.list_mappings(
            db, application_id=FAKE_APP_ID, active_only=True
        )

        mock_repo.list_mappings.assert_called_once_with(
            db, FAKE_APP_ID, active_only=True
        )


class TestCreateMapping:
    @patch(_REPO)
    async def test_success(self, mock_repo):
        """Creates mapping and returns it."""
        mock_repo.get_mappings_for_price = AsyncMock(return_value=[])
        mapping = _make_mapping()
        mock_repo.create_mapping = AsyncMock(return_value=mapping)

        db = AsyncMock()
        result = await service.create_mapping(
            db,
            application_id=FAKE_APP_ID,
            stripe_price_id="price_123",
            entitlement_key="pro_access",
        )

        assert result["mapping"]["stripe_price_id"] == "price_123"

    @patch(_REPO)
    async def test_duplicate_raises_409(self, mock_repo):
        """Raises MappingAlreadyExistsError for duplicate."""
        existing = _make_mapping()
        mock_repo.get_mappings_for_price = AsyncMock(return_value=[existing])

        db = AsyncMock()
        with pytest.raises(MappingAlreadyExistsError):
            await service.create_mapping(
                db,
                application_id=FAKE_APP_ID,
                stripe_price_id="price_123",
                entitlement_key="pro_access",
            )

    @patch(_REPO)
    async def test_time_limited_requires_duration(self, mock_repo):
        """Raises ValidationError for time_limited without duration_days."""
        db = AsyncMock()
        with pytest.raises(ValidationError):
            await service.create_mapping(
                db,
                application_id=FAKE_APP_ID,
                stripe_price_id="price_123",
                entitlement_key="pro_access",
                entitlement_type="time_limited",
            )


class TestUpdateMapping:
    @patch(_REPO)
    async def test_success(self, mock_repo):
        """Updates mapping and returns it."""
        mapping = _make_mapping(entitlement_key="updated_key")
        mock_repo.update_mapping = AsyncMock(return_value=mapping)

        db = AsyncMock()
        result = await service.update_mapping(
            db,
            mapping_id=mapping.id,
            application_id=FAKE_APP_ID,
            entitlement_key="updated_key",
        )

        assert result["mapping"]["entitlement_key"] == "updated_key"

    @patch(_REPO)
    async def test_not_found_raises(self, mock_repo):
        """Raises MappingNotFoundError for unknown mapping."""
        mock_repo.update_mapping = AsyncMock(return_value=None)

        db = AsyncMock()
        with pytest.raises(MappingNotFoundError):
            await service.update_mapping(
                db,
                mapping_id=uuid4(),
                application_id=FAKE_APP_ID,
                entitlement_key="updated_key",
            )


class TestDeactivateMapping:
    @patch(_REPO)
    async def test_success(self, mock_repo):
        """Deactivates mapping and returns it with message."""
        mapping = _make_mapping(is_active=False)
        mock_repo.deactivate_mapping = AsyncMock(return_value=mapping)

        db = AsyncMock()
        result = await service.deactivate_mapping(
            db,
            mapping_id=mapping.id,
            application_id=FAKE_APP_ID,
        )

        assert result["mapping"]["is_active"] is False
        assert "deactivated" in result["message"].lower()

    @patch(_REPO)
    async def test_not_found_raises(self, mock_repo):
        """Raises MappingNotFoundError for unknown mapping."""
        mock_repo.deactivate_mapping = AsyncMock(return_value=None)

        db = AsyncMock()
        with pytest.raises(MappingNotFoundError):
            await service.deactivate_mapping(
                db,
                mapping_id=uuid4(),
                application_id=FAKE_APP_ID,
            )
