"""Unit tests for the device flow in-memory store.

Tests entry creation, lookup, expiration, authorization, denial,
consumption, and secondary index (user_code).
"""

from __future__ import annotations

import time


from spaps_server_quickstart.domains.device_flow.store import (
    DeviceFlowEntry,
    DeviceFlowStore,
)


class TestDeviceFlowStore:
    def test_create_entry(self):
        """Store creates entry with device_code and user_code."""
        store = DeviceFlowStore(ttl_seconds=900)
        entry = store.create("buildooor")

        assert entry.device_code
        assert entry.user_code
        assert entry.client_id == "buildooor"
        assert entry.status == "pending"
        assert store.size == 1

    def test_user_code_format(self):
        """User code is 8 uppercase chars formatted as XXXX-XXXX."""
        store = DeviceFlowStore()
        entry = store.create("test-app")

        assert len(entry.user_code) == 9  # 4 + 1 (dash) + 4
        assert entry.user_code[4] == "-"
        # All chars except dash should be uppercase letters
        raw = entry.user_code.replace("-", "")
        assert raw.isalpha()
        assert raw.isupper()

    def test_get_by_device_code(self):
        """Lookup by device_code returns the entry."""
        store = DeviceFlowStore()
        entry = store.create("test-app")

        found = store.get_by_device_code(entry.device_code)
        assert found is not None
        assert found.device_code == entry.device_code

    def test_get_by_device_code_not_found(self):
        """Lookup with unknown device_code returns None."""
        store = DeviceFlowStore()
        assert store.get_by_device_code("nonexistent") is None

    def test_get_by_user_code(self):
        """Lookup by user_code (secondary index) returns the entry."""
        store = DeviceFlowStore()
        entry = store.create("test-app")

        found = store.get_by_user_code(entry.user_code)
        assert found is not None
        assert found.user_code == entry.user_code
        assert found.device_code == entry.device_code

    def test_get_by_user_code_not_found(self):
        """Lookup with unknown user_code returns None."""
        store = DeviceFlowStore()
        assert store.get_by_user_code("XXXX-YYYY") is None

    def test_authorize_transitions_state(self):
        """Authorize transitions entry from pending to authorized."""
        store = DeviceFlowStore()
        entry = store.create("test-app")

        result = store.authorize(
            entry.device_code,
            access_token="at_123",
            refresh_token="rt_456",
            user_id="user-1",
        )

        assert result is not None
        assert result.status == "authorized"
        assert result.access_token == "at_123"
        assert result.refresh_token == "rt_456"
        assert result.user_id == "user-1"

    def test_authorize_only_from_pending(self):
        """Authorize returns None if entry is not pending."""
        store = DeviceFlowStore()
        entry = store.create("test-app")
        store.deny(entry.device_code)

        result = store.authorize(
            entry.device_code,
            access_token="at",
            refresh_token="rt",
            user_id="user",
        )
        assert result is None

    def test_deny_transitions_state(self):
        """Deny transitions entry from pending to denied."""
        store = DeviceFlowStore()
        entry = store.create("test-app")

        result = store.deny(entry.device_code)
        assert result is not None
        assert result.status == "denied"

    def test_deny_only_from_pending(self):
        """Deny returns None if entry is not pending."""
        store = DeviceFlowStore()
        entry = store.create("test-app")
        store.authorize(
            entry.device_code,
            access_token="at",
            refresh_token="rt",
            user_id="user",
        )

        result = store.deny(entry.device_code)
        assert result is None

    def test_consume_authorized_removes_entry(self):
        """Consume removes authorized entry from store."""
        store = DeviceFlowStore()
        entry = store.create("test-app")
        store.authorize(
            entry.device_code,
            access_token="at",
            refresh_token="rt",
            user_id="user",
        )

        consumed = store.consume(entry.device_code)
        assert consumed is not None
        assert consumed.status == "authorized"
        assert consumed.access_token == "at"
        assert store.size == 0

    def test_consume_denied_removes_entry(self):
        """Consume removes denied entry from store."""
        store = DeviceFlowStore()
        entry = store.create("test-app")
        store.deny(entry.device_code)

        consumed = store.consume(entry.device_code)
        assert consumed is not None
        assert consumed.status == "denied"
        assert store.size == 0

    def test_consume_pending_does_not_remove(self):
        """Consume returns pending entry but does NOT remove it."""
        store = DeviceFlowStore()
        entry = store.create("test-app")

        consumed = store.consume(entry.device_code)
        assert consumed is not None
        assert consumed.status == "pending"
        assert store.size == 1  # Still in store

    def test_consume_not_found(self):
        """Consume returns None for unknown device_code."""
        store = DeviceFlowStore()
        assert store.consume("nonexistent") is None

    def test_expiration(self):
        """Expired entries are cleaned up and not returned."""
        store = DeviceFlowStore(ttl_seconds=1)
        entry = store.create("test-app")

        # Manually expire by setting expires_at to the past
        entry.expires_at = time.time() - 10

        found = store.get_by_device_code(entry.device_code)
        assert found is None
        assert store.size == 0

    def test_expired_user_code_not_found(self):
        """Expired entries are also cleaned from user_code index."""
        store = DeviceFlowStore(ttl_seconds=1)
        entry = store.create("test-app")
        user_code = entry.user_code

        # Manually expire
        entry.expires_at = time.time() - 10

        found = store.get_by_user_code(user_code)
        assert found is None

    def test_multiple_entries(self):
        """Store handles multiple concurrent entries."""
        store = DeviceFlowStore()
        e1 = store.create("app-1")
        e2 = store.create("app-2")
        e3 = store.create("app-3")

        assert store.size == 3
        assert store.get_by_device_code(e1.device_code) is not None
        assert store.get_by_device_code(e2.device_code) is not None
        assert store.get_by_device_code(e3.device_code) is not None

    def test_unique_user_codes(self):
        """Each entry gets a unique user code."""
        store = DeviceFlowStore()
        codes = set()
        for _ in range(50):
            entry = store.create("test-app")
            codes.add(entry.user_code)

        assert len(codes) == 50

    def test_is_expired_method(self):
        """DeviceFlowEntry.is_expired returns correct value."""
        entry = DeviceFlowEntry(
            device_code="dc",
            user_code="UC-OD",
            client_id="app",
            expires_at=time.time() + 100,
        )
        assert entry.is_expired() is False

        entry.expires_at = time.time() - 1
        assert entry.is_expired() is True

    def test_cleanup_throttled_skips_when_called_rapidly(self):
        """Cleanup is skipped when called within the throttle interval."""
        store = DeviceFlowStore(ttl_seconds=1)
        store._cleanup_interval = 60.0  # 60 second interval

        # Create an entry and expire it
        entry = store.create("test-app")
        entry.expires_at = time.time() - 10

        # Force a cleanup to set _last_cleanup
        store._last_cleanup = 0.0  # Reset so first cleanup runs
        store._cleanup_expired()
        assert len(store._entries) == 0  # Entry was cleaned

        # Add another expired entry
        entry2 = store.create("test-app-2")
        entry2.expires_at = time.time() - 10

        # Cleanup should be skipped (within throttle interval)
        store._cleanup_expired()
        # Entry2 should still be in the store (cleanup was throttled)
        assert entry2.device_code in store._entries

    def test_cleanup_runs_after_interval(self):
        """Cleanup runs after the throttle interval has passed."""
        store = DeviceFlowStore(ttl_seconds=1)
        store._cleanup_interval = 0.0  # No throttle for this test

        # Create and expire an entry
        entry = store.create("test-app")
        entry.expires_at = time.time() - 10

        # Cleanup should run (interval is 0)
        store._cleanup_expired()
        assert len(store._entries) == 0
