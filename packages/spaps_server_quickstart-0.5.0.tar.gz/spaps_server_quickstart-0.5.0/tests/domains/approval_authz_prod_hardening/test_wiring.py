"""Tests for approval_authz_prod_hardening wiring into existing endpoints.

Verifies that capability gates, durable state checks, and audit event
emission are actually called from existing approval and governance routers.

These tests validate the WIRING -- the service-level logic is tested
separately in test_service.py.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from spaps_server_quickstart.domains.agent_approvals.router import (
    agents_router,
    approvals_router,
)
from spaps_server_quickstart.domains.approval_authz_prod_hardening.router import (
    governance_health_router,
)
from spaps_server_quickstart.middleware.error_handler import install_error_handlers

_AGENT_SVC = "spaps_server_quickstart.domains.agent_approvals.router.service"
_AUTHZ_SVC = "spaps_server_quickstart.domains.agent_approvals.router.authz_hardening_service"

FAKE_APP_ID = str(uuid4())
FAKE_USER_ID = str(uuid4())
FAKE_AGENT_ID = str(uuid4())
FAKE_APPROVAL_ID = str(uuid4())


# ---------------------------------------------------------------------------
# Test app helpers
# ---------------------------------------------------------------------------


def _make_test_app() -> FastAPI:
    """Create a minimal FastAPI app for testing wired routes."""
    app = FastAPI()
    install_error_handlers(app)

    settings = MagicMock()
    settings.jwt_secret = "test-secret"
    app.state.settings = settings

    app.include_router(agents_router, prefix="/api")
    app.include_router(approvals_router, prefix="/api")
    app.include_router(governance_health_router, prefix="/api")
    return app


def _make_user(
    user_id: str = FAKE_USER_ID,
    is_admin: bool = False,
    application_id: str = FAKE_APP_ID,
    permissions: list[str] | None = None,
) -> MagicMock:
    """Create a mock authenticated user with configurable permissions."""
    user = MagicMock()
    user.id = user_id
    user.application_id = application_id
    user.is_admin = is_admin
    user.is_super_admin = False
    user.permissions = permissions or [
        "approval_request.read",
        "approval_request.review",
    ]
    return user


def _make_user_no_capabilities(
    user_id: str = FAKE_USER_ID,
    application_id: str = FAKE_APP_ID,
) -> MagicMock:
    """Create a mock user WITHOUT approval capabilities."""
    user = MagicMock()
    user.id = user_id
    user.application_id = application_id
    user.is_admin = False
    user.is_super_admin = False
    user.permissions = []
    return user


def _make_user_read_only(
    user_id: str = FAKE_USER_ID,
    application_id: str = FAKE_APP_ID,
) -> MagicMock:
    """Create a mock user with only read capability."""
    user = MagicMock()
    user.id = user_id
    user.application_id = application_id
    user.is_admin = False
    user.is_super_admin = False
    user.permissions = ["approval_request.read"]
    return user


def _make_application(app_id: str = FAKE_APP_ID) -> MagicMock:
    app = MagicMock()
    app.id = app_id
    app.settings = {}
    return app


@pytest.fixture
def app():
    return _make_test_app()


@pytest.fixture
def client(app):
    return TestClient(app, raise_server_exceptions=False)


# ===========================================================================
# Issue 1: Capability gates on approval read endpoints
# ===========================================================================


class TestCapabilityGateOnApprovalList:
    """GET /api/approvals requires approval_request.read capability."""

    @patch(_AGENT_SVC)
    def test_list_approvals_with_read_capability_succeeds(self, mock_svc, client, app):
        """US-2: User with approval_request.read accesses list endpoint."""
        mock_svc.list_approvals = AsyncMock(return_value={
            "approvals": [],
            "total": 0,
        })

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_current_user,
            get_db_session,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_current_user] = lambda: _make_user()

        response = client.get("/api/approvals")
        assert response.status_code == 200

    @patch(_AGENT_SVC)
    def test_list_approvals_without_read_capability_returns_403(self, mock_svc, client, app):
        """US-2: User without approval_request.read gets 403 APPROVAL_CAPABILITY_REQUIRED."""
        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_current_user,
            get_db_session,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_current_user] = lambda: _make_user_no_capabilities()

        response = client.get("/api/approvals")
        assert response.status_code == 403
        assert response.json()["error"]["code"] == "APPROVAL_CAPABILITY_REQUIRED"
        assert response.json()["error"]["details"]["required_capability"] == "approval_request.read"
        # Service should NOT be called -- capability gate stops the request
        mock_svc.list_approvals.assert_not_called()


class TestCapabilityGateOnApprovalByCode:
    """GET /api/approvals/by-code/{code} requires approval_request.read capability."""

    @patch(_AGENT_SVC)
    def test_by_code_with_read_capability_succeeds(self, mock_svc, client, app):
        """US-2: User with approval_request.read accesses by-code endpoint."""
        mock_svc.get_approval_by_code = AsyncMock(return_value={
            "id": FAKE_APPROVAL_ID,
            "status": "pending",
        })

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_current_user,
            get_db_session,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_current_user] = lambda: _make_user()

        response = client.get("/api/approvals/by-code/ABCD-EFGH")
        assert response.status_code == 200

    @patch(_AGENT_SVC)
    def test_by_code_without_read_capability_returns_403(self, mock_svc, client, app):
        """US-2: User without approval_request.read gets 403 on by-code."""
        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_current_user,
            get_db_session,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_current_user] = lambda: _make_user_no_capabilities()

        response = client.get("/api/approvals/by-code/ABCD-EFGH")
        assert response.status_code == 403
        assert response.json()["error"]["code"] == "APPROVAL_CAPABILITY_REQUIRED"
        mock_svc.get_approval_by_code.assert_not_called()


# ===========================================================================
# Issue 1: Capability gates on approval review endpoints
# ===========================================================================


class TestCapabilityGateOnApprovalRespond:
    """POST /api/approvals/{id}/respond requires approval_request.review capability."""

    @patch(_AGENT_SVC)
    def test_respond_with_review_capability_succeeds(self, mock_svc, client, app):
        """US-2: Reviewer with approval_request.review accesses decision endpoint."""
        mock_svc.respond_to_approval = AsyncMock(return_value={
            "id": FAKE_APPROVAL_ID,
            "status": "approved",
            "approved_at": "2026-01-01T00:05:00Z",
            "message": "Approval granted",
        })

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
            get_optional_user,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_optional_user] = lambda: _make_user()

        response = client.post(
            f"/api/approvals/{FAKE_APPROVAL_ID}/respond",
            json={"action": "approve"},
        )
        assert response.status_code == 200

    @patch(_AGENT_SVC)
    def test_respond_without_review_capability_returns_403(self, mock_svc, client, app):
        """US-2: User without approval_request.review gets 403."""
        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
            get_optional_user,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_optional_user] = lambda: _make_user_read_only()

        response = client.post(
            f"/api/approvals/{FAKE_APPROVAL_ID}/respond",
            json={"action": "approve"},
        )
        assert response.status_code == 403
        assert response.json()["error"]["code"] == "APPROVAL_CAPABILITY_REQUIRED"
        assert response.json()["error"]["details"]["required_capability"] == "approval_request.review"
        mock_svc.respond_to_approval.assert_not_called()

    @patch(_AGENT_SVC)
    def test_respond_with_no_capabilities_returns_403(self, mock_svc, client, app):
        """US-2: User with no capabilities at all gets 403 on respond."""
        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
            get_optional_user,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_optional_user] = lambda: _make_user_no_capabilities()

        response = client.post(
            f"/api/approvals/{FAKE_APPROVAL_ID}/respond",
            json={"action": "approve"},
        )
        assert response.status_code == 403
        assert response.json()["error"]["code"] == "APPROVAL_CAPABILITY_REQUIRED"

    @patch(_AGENT_SVC)
    def test_respond_with_agent_credentials_skips_capability_check(self, mock_svc, client, app):
        """Agent-as-approver path: capability check only applies to human users."""
        mock_svc.authenticate_agent = AsyncMock(return_value=MagicMock(
            id=FAKE_AGENT_ID,
            application_id=FAKE_APP_ID,
        ))
        mock_svc.respond_to_approval = AsyncMock(return_value={
            "id": FAKE_APPROVAL_ID,
            "status": "approved",
            "approved_at": "2026-01-01T00:05:00Z",
            "message": "Approval granted",
        })

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
            get_optional_user,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_optional_user] = lambda: None

        response = client.post(
            f"/api/approvals/{FAKE_APPROVAL_ID}/respond",
            json={"action": "approve"},
            headers={
                "X-Agent-Id": FAKE_AGENT_ID,
                "X-Agent-Secret": "spaps_agent_xxxx",
            },
        )
        assert response.status_code == 200


# ===========================================================================
# Issue 1: Capability gate ordering (before participant checks)
# ===========================================================================


class TestCapabilityGateOrdering:
    """Capability gate runs BEFORE participant/service-level checks."""

    @patch(_AGENT_SVC)
    def test_capability_denied_before_service_call(self, mock_svc, client, app):
        """US-2: Capability check runs before service call, so service is never invoked."""
        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_current_user,
            get_db_session,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_current_user] = lambda: _make_user_no_capabilities()

        response = client.get("/api/approvals")
        assert response.status_code == 403
        # list_approvals should never be called
        mock_svc.list_approvals.assert_not_called()


# ===========================================================================
# Issue 3: Audit event emission on capability deny
# ===========================================================================


class TestAuditEventEmissionOnCapabilityDeny:
    """Audit events are emitted when capability gates deny access."""

    @patch(
        "spaps_server_quickstart.domains.agent_approvals.router.authz_hardening_service.emit_authz_audit_event",
        new_callable=AsyncMock,
    )
    @patch(_AGENT_SVC)
    def test_list_deny_emits_audit_event(self, mock_svc, mock_audit, client, app):
        """US-5: Capability deny on list emits audit event."""
        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_current_user,
            get_db_session,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_current_user] = lambda: _make_user_no_capabilities()

        response = client.get("/api/approvals")
        assert response.status_code == 403
        mock_audit.assert_called_once()
        call_kwargs = mock_audit.call_args[1]
        assert call_kwargs["decision"] == "deny"
        assert call_kwargs["reason_code"] == "APPROVAL_CAPABILITY_REQUIRED"

    @patch(
        "spaps_server_quickstart.domains.agent_approvals.router.authz_hardening_service.emit_authz_audit_event",
        new_callable=AsyncMock,
    )
    @patch(_AGENT_SVC)
    def test_respond_deny_emits_audit_event(self, mock_svc, mock_audit, client, app):
        """US-5: Capability deny on respond emits audit event."""
        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_db_session,
            get_optional_user,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_optional_user] = lambda: _make_user_read_only()

        response = client.post(
            f"/api/approvals/{FAKE_APPROVAL_ID}/respond",
            json={"action": "approve"},
        )
        assert response.status_code == 403
        mock_audit.assert_called_once()
        call_kwargs = mock_audit.call_args[1]
        assert call_kwargs["decision"] == "deny"
        assert call_kwargs["reason_code"] == "APPROVAL_CAPABILITY_REQUIRED"
        assert call_kwargs["capability"] == "approval_request.review"

    @patch(
        "spaps_server_quickstart.domains.agent_approvals.router.authz_hardening_service.emit_authz_audit_event",
        new_callable=AsyncMock,
    )
    @patch(_AGENT_SVC)
    def test_list_allow_emits_audit_event(self, mock_svc, mock_audit, client, app):
        """US-5: Successful capability check emits allow audit event."""
        mock_svc.list_approvals = AsyncMock(return_value={
            "approvals": [],
            "total": 0,
        })

        from spaps_server_quickstart.middleware.spaps_deps import (
            get_application,
            get_current_user,
            get_db_session,
        )

        app.dependency_overrides[get_db_session] = lambda: AsyncMock()
        app.dependency_overrides[get_application] = lambda: _make_application()
        app.dependency_overrides[get_current_user] = lambda: _make_user()

        response = client.get("/api/approvals")
        assert response.status_code == 200
        mock_audit.assert_called_once()
        call_kwargs = mock_audit.call_args[1]
        assert call_kwargs["decision"] == "allow"
        assert call_kwargs["reason_code"] == "AUTHORIZED"
