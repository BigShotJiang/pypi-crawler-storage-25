"""Unit tests for the approval_authz_prod_hardening service layer.

Tests cover:
- Governance health evaluation (healthy / degraded)
- Capability gate enforcement (read / review)
- Fail-closed degraded behavior
- Authz audit event emission (allow / deny / fail_closed)
- Durable governance state checks

The repository layer is fully mocked so tests exercise only the
service orchestration, business logic, and error handling.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

from spaps_server_quickstart.domains.approval_authz_prod_hardening import service
from spaps_server_quickstart.domains.approval_authz_prod_hardening.errors import (
    ApprovalCapabilityRequiredError,
    GovernancePersistenceUnavailableError,
    MachineScopeDeniedError,
    NotAuthorizedError,
)

_REPO = "spaps_server_quickstart.domains.approval_authz_prod_hardening.service.repo"

FAKE_TENANT_ID = str(uuid4())
FAKE_APP_ID = str(uuid4())
FAKE_USER_ID = str(uuid4())
FAKE_KEY_ID = str(uuid4())


# ---------------------------------------------------------------------------
# Governance Health Tests
# ---------------------------------------------------------------------------


class TestGovernanceHealth:
    """Tests for governance health evaluation."""

    @pytest.mark.asyncio
    async def test_health_returns_healthy_when_persistence_available(self):
        """US-4: Healthy -> status=healthy, storage_mode=durable, empty blockers."""
        db = AsyncMock()
        with patch(f"{_REPO}.check_persistence_available", new_callable=AsyncMock, return_value=True):
            result = await service.evaluate_governance_health(db)

        assert result["status"] == "healthy"
        assert result["storage_mode"] == "durable"
        assert result["blockers"] == []
        assert "checked_at" in result

    @pytest.mark.asyncio
    async def test_health_returns_degraded_when_persistence_unavailable(self):
        """US-4: Degraded -> status=degraded, blockers include persistence code."""
        db = AsyncMock()
        with patch(f"{_REPO}.check_persistence_available", new_callable=AsyncMock, return_value=False):
            result = await service.evaluate_governance_health(db)

        assert result["status"] == "degraded"
        assert result["storage_mode"] == "degraded"
        assert "GOVERNANCE_PERSISTENCE_UNAVAILABLE" in result["blockers"]
        assert "checked_at" in result

    @pytest.mark.asyncio
    async def test_health_returns_degraded_on_persistence_exception(self):
        """Edge: persistence check throws -> degraded."""
        db = AsyncMock()
        with patch(f"{_REPO}.check_persistence_available", new_callable=AsyncMock, side_effect=Exception("db down")):
            result = await service.evaluate_governance_health(db)

        assert result["status"] == "degraded"
        assert "GOVERNANCE_PERSISTENCE_UNAVAILABLE" in result["blockers"]


# ---------------------------------------------------------------------------
# Capability Gate Tests
# ---------------------------------------------------------------------------


class TestCapabilityGate:
    """Tests for explicit capability enforcement before participant checks."""

    @pytest.mark.asyncio
    async def test_check_capability_read_passes(self):
        """US-2: User with approval_request.read passes read gate."""
        capabilities = ["approval_request.read"]
        # Should not raise
        service.check_capability(capabilities, "approval_request.read")

    @pytest.mark.asyncio
    async def test_check_capability_review_passes(self):
        """US-2: Reviewer with approval_request.review passes review gate."""
        capabilities = ["approval_request.review", "approval_request.read"]
        service.check_capability(capabilities, "approval_request.review")

    @pytest.mark.asyncio
    async def test_check_capability_read_missing_raises(self):
        """US-2: Missing read capability -> APPROVAL_CAPABILITY_REQUIRED."""
        capabilities = []
        with pytest.raises(ApprovalCapabilityRequiredError) as exc_info:
            service.check_capability(capabilities, "approval_request.read")
        assert exc_info.value.required_capability == "approval_request.read"
        assert exc_info.value.status_code == 403

    @pytest.mark.asyncio
    async def test_check_capability_review_missing_raises(self):
        """US-2: Missing review capability -> APPROVAL_CAPABILITY_REQUIRED."""
        capabilities = ["approval_request.read"]
        with pytest.raises(ApprovalCapabilityRequiredError) as exc_info:
            service.check_capability(capabilities, "approval_request.review")
        assert exc_info.value.required_capability == "approval_request.review"

    @pytest.mark.asyncio
    async def test_capability_check_before_participant_check(self):
        """US-2: Capability deny occurs BEFORE participant role check."""
        capabilities = []
        # Even if participant role is valid, capability must be checked first
        with pytest.raises(ApprovalCapabilityRequiredError):
            service.check_capability(capabilities, "approval_request.review")

    @pytest.mark.asyncio
    async def test_capability_present_but_not_participant_raises_not_authorized(self):
        """US-2: Capability pass + participant miss -> NOT_AUTHORIZED."""
        # This tests the layering: capability passes, participant fails
        capabilities = ["approval_request.review"]
        service.check_capability(capabilities, "approval_request.review")  # passes

        # Participant check is separate and should raise NOT_AUTHORIZED
        with pytest.raises(NotAuthorizedError):
            service.check_participant_authorization(
                is_participant=False,
            )


# ---------------------------------------------------------------------------
# Fail-Closed Degraded Behavior Tests
# ---------------------------------------------------------------------------


class TestFailClosedDegraded:
    """Tests for fail-closed behavior when persistence is degraded."""

    @pytest.mark.asyncio
    async def test_protected_mutation_fails_closed_when_degraded(self):
        """US-3: Protected mutation during degraded -> 503 GOVERNANCE_PERSISTENCE_UNAVAILABLE."""
        db = AsyncMock()
        with patch(f"{_REPO}.check_persistence_available", new_callable=AsyncMock, return_value=False):
            with pytest.raises(GovernancePersistenceUnavailableError) as exc_info:
                await service.ensure_durable_governance_state(db)
            assert exc_info.value.status_code == 503
            assert exc_info.value.code == "GOVERNANCE_PERSISTENCE_UNAVAILABLE"

    @pytest.mark.asyncio
    async def test_protected_mutation_succeeds_when_healthy(self):
        """US-3: Protected mutation when healthy -> no error."""
        db = AsyncMock()
        with patch(f"{_REPO}.check_persistence_available", new_callable=AsyncMock, return_value=True):
            # Should not raise
            await service.ensure_durable_governance_state(db)

    @pytest.mark.asyncio
    async def test_machine_ingest_fails_closed_when_degraded(self):
        """US-3: Machine social-reply ingest during degraded -> 503."""
        db = AsyncMock()
        with patch(f"{_REPO}.check_persistence_available", new_callable=AsyncMock, return_value=False):
            with pytest.raises(GovernancePersistenceUnavailableError):
                await service.ensure_durable_governance_state(db)

    @pytest.mark.asyncio
    async def test_persistence_exception_is_treated_as_degraded(self):
        """Edge: persistence check exception -> fail closed."""
        db = AsyncMock()
        with patch(f"{_REPO}.check_persistence_available", new_callable=AsyncMock, side_effect=Exception("timeout")):
            with pytest.raises(GovernancePersistenceUnavailableError):
                await service.ensure_durable_governance_state(db)


# ---------------------------------------------------------------------------
# Authz Audit Event Tests
# ---------------------------------------------------------------------------


class TestAuthzAuditEvents:
    """Tests for auditable authorization decision trail."""

    @pytest.mark.asyncio
    async def test_emit_allow_audit_event(self):
        """US-5: Allow decision emits audit event with decision=allow."""
        db = AsyncMock()
        with patch(f"{_REPO}.create_authz_audit_event", new_callable=AsyncMock) as mock_create:
            mock_create.return_value = MagicMock(
                id=str(uuid4()),
                seq=1,
                decision="allow",
                reason_code="AUTHORIZED",
            )

            await service.emit_authz_audit_event(
                db,
                principal_type="human",
                principal_id=FAKE_USER_ID,
                tenant_id=FAKE_TENANT_ID,
                app_id=FAKE_APP_ID,
                capability="approval_request.review",
                decision="allow",
                reason_code="AUTHORIZED",
            )

            mock_create.assert_called_once()
            call_kwargs = mock_create.call_args[1]
            assert call_kwargs["decision"] == "allow"
            assert call_kwargs["reason_code"] == "AUTHORIZED"
            assert call_kwargs["principal_type"] == "human"

    @pytest.mark.asyncio
    async def test_emit_deny_audit_event_for_capability(self):
        """US-5: Capability denied -> audit event with decision=deny and capability code."""
        db = AsyncMock()
        with patch(f"{_REPO}.create_authz_audit_event", new_callable=AsyncMock) as mock_create:
            mock_create.return_value = MagicMock(
                id=str(uuid4()),
                seq=2,
                decision="deny",
                reason_code="APPROVAL_CAPABILITY_REQUIRED",
            )

            await service.emit_authz_audit_event(
                db,
                principal_type="human",
                principal_id=FAKE_USER_ID,
                tenant_id=FAKE_TENANT_ID,
                app_id=FAKE_APP_ID,
                capability="approval_request.review",
                decision="deny",
                reason_code="APPROVAL_CAPABILITY_REQUIRED",
            )

            call_kwargs = mock_create.call_args[1]
            assert call_kwargs["decision"] == "deny"
            assert call_kwargs["reason_code"] == "APPROVAL_CAPABILITY_REQUIRED"

    @pytest.mark.asyncio
    async def test_emit_deny_audit_event_for_machine_scope(self):
        """US-5: Machine scope denied -> audit event with MACHINE_SCOPE_DENIED."""
        db = AsyncMock()
        with patch(f"{_REPO}.create_authz_audit_event", new_callable=AsyncMock) as mock_create:
            mock_create.return_value = MagicMock(
                id=str(uuid4()),
                seq=3,
                decision="deny",
                reason_code="MACHINE_SCOPE_DENIED",
            )

            await service.emit_authz_audit_event(
                db,
                principal_type="machine",
                principal_id=FAKE_KEY_ID,
                tenant_id=FAKE_TENANT_ID,
                app_id=FAKE_APP_ID,
                capability="social_reply.create",
                decision="deny",
                reason_code="MACHINE_SCOPE_DENIED",
                machine_key_id=FAKE_KEY_ID,
            )

            call_kwargs = mock_create.call_args[1]
            assert call_kwargs["principal_type"] == "machine"
            assert call_kwargs["machine_key_id"] == FAKE_KEY_ID

    @pytest.mark.asyncio
    async def test_emit_fail_closed_audit_event(self):
        """US-5: Degraded persistence -> audit event with decision=fail_closed."""
        db = AsyncMock()
        with patch(f"{_REPO}.create_authz_audit_event", new_callable=AsyncMock) as mock_create:
            mock_create.return_value = MagicMock(
                id=str(uuid4()),
                seq=4,
                decision="fail_closed",
                reason_code="GOVERNANCE_PERSISTENCE_UNAVAILABLE",
            )

            await service.emit_authz_audit_event(
                db,
                principal_type="machine",
                principal_id=FAKE_KEY_ID,
                tenant_id=FAKE_TENANT_ID,
                app_id=FAKE_APP_ID,
                decision="fail_closed",
                reason_code="GOVERNANCE_PERSISTENCE_UNAVAILABLE",
            )

            call_kwargs = mock_create.call_args[1]
            assert call_kwargs["decision"] == "fail_closed"
            assert call_kwargs["reason_code"] == "GOVERNANCE_PERSISTENCE_UNAVAILABLE"

    @pytest.mark.asyncio
    async def test_audit_event_write_failure_does_not_crash(self):
        """Edge: Audit event write failure is logged but does not raise."""
        db = AsyncMock()
        with patch(f"{_REPO}.create_authz_audit_event", new_callable=AsyncMock, side_effect=Exception("write failed")):
            # Should not raise -- audit writes must not break the request path
            await service.emit_authz_audit_event(
                db,
                principal_type="human",
                principal_id=FAKE_USER_ID,
                tenant_id=FAKE_TENANT_ID,
                app_id=FAKE_APP_ID,
                decision="allow",
                reason_code="AUTHORIZED",
            )


# ---------------------------------------------------------------------------
# Durable Governance State Tests
# ---------------------------------------------------------------------------


class TestDurableGovernanceState:
    """Tests for durable state correctness."""

    @pytest.mark.asyncio
    async def test_persistence_check_returns_true_when_db_reachable(self):
        """US-1: Durable state dependency available -> True."""
        db = AsyncMock()
        with patch(f"{_REPO}.check_persistence_available", new_callable=AsyncMock, return_value=True):
            result = await service.is_persistence_available(db)
        assert result is True

    @pytest.mark.asyncio
    async def test_persistence_check_returns_false_on_failure(self):
        """US-1: Durable state dependency unavailable -> False."""
        db = AsyncMock()
        with patch(f"{_REPO}.check_persistence_available", new_callable=AsyncMock, return_value=False):
            result = await service.is_persistence_available(db)
        assert result is False

    @pytest.mark.asyncio
    async def test_persistence_check_returns_false_on_exception(self):
        """Edge: Persistence check exception -> False (safe default)."""
        db = AsyncMock()
        with patch(f"{_REPO}.check_persistence_available", new_callable=AsyncMock, side_effect=Exception("conn refused")):
            result = await service.is_persistence_available(db)
        assert result is False


# ---------------------------------------------------------------------------
# Machine Scope Validation Tests
# ---------------------------------------------------------------------------


class TestMachineScopeValidation:
    """Tests for machine key scope checks."""

    def test_valid_scope_passes(self):
        """Machine key with required scope passes."""
        key_scopes = ["social_reply.create", "approval_request.read"]
        service.check_machine_scope(key_scopes, "social_reply.create")

    def test_missing_scope_raises(self):
        """Machine key without required scope -> MACHINE_SCOPE_DENIED."""
        key_scopes = ["approval_request.read"]
        with pytest.raises(MachineScopeDeniedError) as exc_info:
            service.check_machine_scope(key_scopes, "social_reply.create")
        assert exc_info.value.required_scope == "social_reply.create"

    def test_empty_scopes_raises(self):
        """Machine key with empty scopes -> MACHINE_SCOPE_DENIED."""
        key_scopes: list[str] = []
        with pytest.raises(MachineScopeDeniedError):
            service.check_machine_scope(key_scopes, "social_reply.create")

    def test_none_scopes_raises(self):
        """Machine key with None scopes -> MACHINE_SCOPE_DENIED."""
        with pytest.raises(MachineScopeDeniedError):
            service.check_machine_scope(None, "social_reply.create")
