"""API route tests for the approval_authz_prod_hardening domain.

Tests cover:
- GET /api/v2/claw-governance/health (healthy, degraded, auth missing, auth denied)
- Capability gate on approval read endpoints (403 APPROVAL_CAPABILITY_REQUIRED)
- Capability gate on approval review endpoints (403 APPROVAL_CAPABILITY_REQUIRED)
- Fail-closed 503 on protected governance mutations
- Audit event emission for deny decisions
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest


_SERVICE = "spaps_server_quickstart.domains.approval_authz_prod_hardening.router.service"
_ROUTER_MODULE = "spaps_server_quickstart.domains.approval_authz_prod_hardening.router"


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def mock_db():
    return AsyncMock()


@pytest.fixture
def fake_user():
    """Fake authenticated user with capabilities."""
    user = MagicMock()
    user.id = uuid4()
    user.email = "reviewer@test.com"
    user.application_id = str(uuid4())
    user.is_admin = False
    user.capabilities = ["approval_request.read", "approval_request.review"]
    user.roles = ["reviewer"]
    return user


@pytest.fixture
def fake_user_no_capabilities():
    """Fake authenticated user without approval capabilities."""
    user = MagicMock()
    user.id = uuid4()
    user.email = "operator@test.com"
    user.application_id = str(uuid4())
    user.is_admin = False
    user.capabilities = []
    user.roles = ["operator"]
    return user


@pytest.fixture
def fake_user_read_only():
    """Fake authenticated user with only read capability."""
    user = MagicMock()
    user.id = uuid4()
    user.email = "viewer@test.com"
    user.application_id = str(uuid4())
    user.is_admin = False
    user.capabilities = ["approval_request.read"]
    user.roles = ["viewer"]
    return user


@pytest.fixture
def fake_application():
    app = MagicMock()
    app.id = uuid4()
    return app


# ---------------------------------------------------------------------------
# Governance Health Endpoint Tests
# ---------------------------------------------------------------------------


class TestGovernanceHealthRoute:
    """Tests for GET /api/v2/claw-governance/health."""

    @pytest.mark.asyncio
    async def test_health_healthy_returns_200(self):
        """US-4: Healthy status returns 200 with status=healthy."""
        from spaps_server_quickstart.domains.approval_authz_prod_hardening import service

        db = AsyncMock()
        with patch(
            "spaps_server_quickstart.domains.approval_authz_prod_hardening.service.repo.check_persistence_available",
            new_callable=AsyncMock,
            return_value=True,
        ):
            result = await service.evaluate_governance_health(db)

        assert result["status"] == "healthy"
        assert result["storage_mode"] == "durable"
        assert result["blockers"] == []

    @pytest.mark.asyncio
    async def test_health_degraded_returns_200_with_blockers(self):
        """US-4: Degraded status returns 200 with blockers."""
        from spaps_server_quickstart.domains.approval_authz_prod_hardening import service

        db = AsyncMock()
        with patch(
            "spaps_server_quickstart.domains.approval_authz_prod_hardening.service.repo.check_persistence_available",
            new_callable=AsyncMock,
            return_value=False,
        ):
            result = await service.evaluate_governance_health(db)

        assert result["status"] == "degraded"
        assert "GOVERNANCE_PERSISTENCE_UNAVAILABLE" in result["blockers"]


# ---------------------------------------------------------------------------
# Capability Gate Tests (Route Level)
# ---------------------------------------------------------------------------


class TestCapabilityGateRoutes:
    """Tests verifying capability gates on approval endpoints."""

    @pytest.mark.asyncio
    async def test_read_endpoint_passes_with_read_capability(self, fake_user):
        """US-2: User with approval_request.read accesses read endpoints."""
        from spaps_server_quickstart.domains.approval_authz_prod_hardening import service

        # Should not raise
        service.check_capability(
            fake_user.capabilities,
            "approval_request.read",
        )

    @pytest.mark.asyncio
    async def test_read_endpoint_denied_without_read_capability(self, fake_user_no_capabilities):
        """US-2: User without approval_request.read gets 403."""
        from spaps_server_quickstart.domains.approval_authz_prod_hardening import service
        from spaps_server_quickstart.domains.approval_authz_prod_hardening.errors import (
            ApprovalCapabilityRequiredError,
        )

        with pytest.raises(ApprovalCapabilityRequiredError) as exc_info:
            service.check_capability(
                fake_user_no_capabilities.capabilities,
                "approval_request.read",
            )
        assert exc_info.value.status_code == 403
        assert exc_info.value.code == "APPROVAL_CAPABILITY_REQUIRED"
        assert exc_info.value.required_capability == "approval_request.read"

    @pytest.mark.asyncio
    async def test_review_endpoint_passes_with_review_capability(self, fake_user):
        """US-2: Reviewer with approval_request.review accesses decision endpoints."""
        from spaps_server_quickstart.domains.approval_authz_prod_hardening import service

        service.check_capability(
            fake_user.capabilities,
            "approval_request.review",
        )

    @pytest.mark.asyncio
    async def test_review_endpoint_denied_without_review_capability(self, fake_user_read_only):
        """US-2: User with only read capability gets 403 on decision endpoint."""
        from spaps_server_quickstart.domains.approval_authz_prod_hardening import service
        from spaps_server_quickstart.domains.approval_authz_prod_hardening.errors import (
            ApprovalCapabilityRequiredError,
        )

        with pytest.raises(ApprovalCapabilityRequiredError) as exc_info:
            service.check_capability(
                fake_user_read_only.capabilities,
                "approval_request.review",
            )
        assert exc_info.value.required_capability == "approval_request.review"

    @pytest.mark.asyncio
    async def test_capability_denied_includes_required_capability_field(self, fake_user_no_capabilities):
        """US-2: Capability denied response includes required_capability detail."""
        from spaps_server_quickstart.domains.approval_authz_prod_hardening import service
        from spaps_server_quickstart.domains.approval_authz_prod_hardening.errors import (
            ApprovalCapabilityRequiredError,
        )

        with pytest.raises(ApprovalCapabilityRequiredError) as exc_info:
            service.check_capability(
                fake_user_no_capabilities.capabilities,
                "approval_request.review",
            )
        assert exc_info.value.details["required_capability"] == "approval_request.review"


# ---------------------------------------------------------------------------
# Fail-Closed Route Tests
# ---------------------------------------------------------------------------


class TestFailClosedRoutes:
    """Tests for fail-closed behavior on protected mutation routes."""

    @pytest.mark.asyncio
    async def test_machine_key_create_returns_503_when_degraded(self):
        """US-3: POST machine-keys returns 503 when persistence unavailable."""
        from spaps_server_quickstart.domains.approval_authz_prod_hardening import service
        from spaps_server_quickstart.domains.approval_authz_prod_hardening.errors import (
            GovernancePersistenceUnavailableError,
        )

        db = AsyncMock()
        with patch(
            "spaps_server_quickstart.domains.approval_authz_prod_hardening.service.repo.check_persistence_available",
            new_callable=AsyncMock,
            return_value=False,
        ):
            with pytest.raises(GovernancePersistenceUnavailableError) as exc_info:
                await service.ensure_durable_governance_state(db)
            assert exc_info.value.status_code == 503

    @pytest.mark.asyncio
    async def test_social_reply_ingest_returns_503_when_degraded(self):
        """US-3: POST social-reply returns 503 when persistence unavailable."""
        from spaps_server_quickstart.domains.approval_authz_prod_hardening import service
        from spaps_server_quickstart.domains.approval_authz_prod_hardening.errors import (
            GovernancePersistenceUnavailableError,
        )

        db = AsyncMock()
        with patch(
            "spaps_server_quickstart.domains.approval_authz_prod_hardening.service.repo.check_persistence_available",
            new_callable=AsyncMock,
            return_value=False,
        ):
            with pytest.raises(GovernancePersistenceUnavailableError):
                await service.ensure_durable_governance_state(db)

    @pytest.mark.asyncio
    async def test_recovery_after_degraded(self):
        """US-3: After recovery, protected mutations succeed."""
        from spaps_server_quickstart.domains.approval_authz_prod_hardening import service

        db = AsyncMock()
        with patch(
            "spaps_server_quickstart.domains.approval_authz_prod_hardening.service.repo.check_persistence_available",
            new_callable=AsyncMock,
            return_value=True,
        ):
            # Should not raise
            await service.ensure_durable_governance_state(db)


# ---------------------------------------------------------------------------
# Audit Route Integration Tests
# ---------------------------------------------------------------------------


class TestAuditRouteIntegration:
    """Tests verifying audit events are emitted for deny decisions."""

    @pytest.mark.asyncio
    async def test_capability_deny_emits_audit_event(self):
        """US-5: Capability deny appends audit event with decision=deny."""
        from spaps_server_quickstart.domains.approval_authz_prod_hardening import service

        db = AsyncMock()
        with patch(
            "spaps_server_quickstart.domains.approval_authz_prod_hardening.service.repo.create_authz_audit_event",
            new_callable=AsyncMock,
        ) as mock_audit:
            mock_audit.return_value = MagicMock(
                id=str(uuid4()),
                seq=1,
                decision="deny",
                reason_code="APPROVAL_CAPABILITY_REQUIRED",
            )

            await service.emit_authz_audit_event(
                db,
                principal_type="human",
                principal_id=str(uuid4()),
                tenant_id=str(uuid4()),
                app_id=str(uuid4()),
                capability="approval_request.review",
                decision="deny",
                reason_code="APPROVAL_CAPABILITY_REQUIRED",
            )

            mock_audit.assert_called_once()

    @pytest.mark.asyncio
    async def test_fail_closed_deny_emits_audit_event(self):
        """US-5: Fail-closed deny appends audit event with decision=fail_closed."""
        from spaps_server_quickstart.domains.approval_authz_prod_hardening import service

        db = AsyncMock()
        with patch(
            "spaps_server_quickstart.domains.approval_authz_prod_hardening.service.repo.create_authz_audit_event",
            new_callable=AsyncMock,
        ) as mock_audit:
            mock_audit.return_value = MagicMock(
                id=str(uuid4()),
                seq=2,
                decision="fail_closed",
                reason_code="GOVERNANCE_PERSISTENCE_UNAVAILABLE",
            )

            await service.emit_authz_audit_event(
                db,
                principal_type="machine",
                principal_id=str(uuid4()),
                tenant_id=str(uuid4()),
                app_id=str(uuid4()),
                decision="fail_closed",
                reason_code="GOVERNANCE_PERSISTENCE_UNAVAILABLE",
            )

            call_kwargs = mock_audit.call_args[1]
            assert call_kwargs["decision"] == "fail_closed"
