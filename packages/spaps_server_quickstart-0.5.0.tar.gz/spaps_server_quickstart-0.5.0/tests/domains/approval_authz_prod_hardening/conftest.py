"""Fixtures for approval_authz_prod_hardening domain tests."""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import pytest


@pytest.fixture
def fake_tenant_id() -> str:
    return str(uuid4())


@pytest.fixture
def fake_app_id() -> str:
    return str(uuid4())


@pytest.fixture
def fake_user_id() -> str:
    return str(uuid4())


@pytest.fixture
def fake_key_id() -> str:
    return str(uuid4())


@pytest.fixture
def db_session() -> AsyncMock:
    """Mock async database session."""
    return AsyncMock()


@pytest.fixture
def mock_audit_event() -> MagicMock:
    """Mock authz audit event model instance."""
    event = MagicMock()
    event.id = str(uuid4())
    event.seq = 1
    event.principal_type = "human"
    event.principal_id = str(uuid4())
    event.tenant_id = str(uuid4())
    event.app_id = str(uuid4())
    event.approval_id = None
    event.machine_key_id = None
    event.capability = "approval_request.read"
    event.decision = "allow"
    event.reason_code = "AUTHORIZED"
    event.created_at = datetime.now(UTC)
    return event
