"""Unit tests for the users domain service layer.

Mocks the repository module to test business logic in isolation.
"""

from __future__ import annotations

from datetime import datetime, UTC
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import UUID, uuid4

import pytest

from spaps_server_quickstart.domains.errors import NotFoundError
from spaps_server_quickstart.domains.users import service
from spaps_server_quickstart.domains.users.models import User
from spaps_server_quickstart.domains.users.schemas import (
    BatchEmailsResponse,
    BatchUsersResponse,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

REPO_MODULE = "spaps_server_quickstart.domains.users.service.repo"


def _make_user(
    user_id: str | None = None,
    email: str = "alice@example.com",
    username: str | None = None,
) -> MagicMock:
    """Return a mock User with sensible defaults."""
    user = MagicMock(spec=User)
    user.id = UUID(user_id) if user_id else uuid4()
    user.email = email
    user.username = username
    user.created_at = datetime.now(UTC)
    user.updated_at = datetime.now(UTC)
    return user


def _mock_db() -> AsyncMock:
    return AsyncMock()


# ---------------------------------------------------------------------------
# get_user_profile
# ---------------------------------------------------------------------------


class TestGetUserProfile:
    async def test_returns_user_when_found(self):
        user = _make_user()
        db = _mock_db()

        with patch(f"{REPO_MODULE}.get_user_by_id", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = user
            result = await service.get_user_profile(db, str(user.id))

        assert result is user
        mock_get.assert_awaited_once_with(db, str(user.id))

    async def test_raises_not_found_when_missing(self):
        db = _mock_db()
        uid = str(uuid4())

        with patch(f"{REPO_MODULE}.get_user_by_id", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = None

            with pytest.raises(NotFoundError, match=uid):
                await service.get_user_profile(db, uid)


# ---------------------------------------------------------------------------
# batch_get_emails
# ---------------------------------------------------------------------------


class TestBatchGetEmails:
    async def test_returns_email_mapping_with_counts(self):
        uid1 = str(uuid4())
        uid2 = str(uuid4())
        db = _mock_db()

        with patch(f"{REPO_MODULE}.get_user_emails_by_ids", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = {uid1: "a@example.com", uid2: "b@example.com"}
            result = await service.batch_get_emails(db, [uid1, uid2])

        assert isinstance(result, BatchEmailsResponse)
        assert result.emails[uid1] == "a@example.com"
        assert result.emails[uid2] == "b@example.com"
        assert result.total == 2
        assert result.with_email == 2

    async def test_missing_ids_have_none_email(self):
        uid_exists = str(uuid4())
        uid_missing = str(uuid4())
        db = _mock_db()

        with patch(f"{REPO_MODULE}.get_user_emails_by_ids", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = {uid_exists: "found@example.com"}
            result = await service.batch_get_emails(db, [uid_exists, uid_missing])

        assert result.emails[uid_exists] == "found@example.com"
        assert result.emails[uid_missing] is None
        assert result.total == 2
        assert result.with_email == 1

    async def test_empty_list_returns_zero_counts(self):
        db = _mock_db()

        with patch(f"{REPO_MODULE}.get_user_emails_by_ids", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = {}
            result = await service.batch_get_emails(db, [])

        assert result.total == 0
        assert result.with_email == 0
        assert result.emails == {}


# ---------------------------------------------------------------------------
# batch_get_users
# ---------------------------------------------------------------------------


class TestBatchGetUsers:
    async def test_returns_user_info_mapping(self):
        user1 = _make_user(email="a@example.com")
        user2 = _make_user(email="b@example.com")
        db = _mock_db()

        with patch(f"{REPO_MODULE}.get_users_by_ids", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = [user1, user2]
            result = await service.batch_get_users(
                db, [str(user1.id), str(user2.id)]
            )

        assert isinstance(result, BatchUsersResponse)
        assert str(user1.id) in result.users
        assert result.users[str(user1.id)].email == "a@example.com"
        assert result.users[str(user2.id)].email == "b@example.com"

    async def test_unknown_ids_omitted(self):
        """Users not found in the DB should not appear in the result."""
        user = _make_user(email="only@example.com")
        unknown_id = str(uuid4())
        db = _mock_db()

        with patch(f"{REPO_MODULE}.get_users_by_ids", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = [user]
            result = await service.batch_get_users(db, [str(user.id), unknown_id])

        assert str(user.id) in result.users
        assert unknown_id not in result.users

    async def test_active_entitlements_is_none(self):
        """In Phase 1, active_entitlements should always be None."""
        user = _make_user()
        db = _mock_db()

        with patch(f"{REPO_MODULE}.get_users_by_ids", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = [user]
            result = await service.batch_get_users(db, [str(user.id)])

        info = result.users[str(user.id)]
        assert info.active_entitlements is None


# ---------------------------------------------------------------------------
# find_or_create_user
# ---------------------------------------------------------------------------


class TestFindOrCreateUser:
    async def test_returns_existing_user(self):
        existing = _make_user(email="exists@example.com")
        db = _mock_db()

        with patch(f"{REPO_MODULE}.get_user_by_email", new_callable=AsyncMock) as mock_find:
            mock_find.return_value = existing
            user, is_new = await service.find_or_create_user(
                db, "exists@example.com"
            )

        assert user is existing
        assert is_new is False

    async def test_creates_new_user_when_not_found(self):
        new_user = _make_user(email="fresh@example.com")
        db = _mock_db()

        with (
            patch(f"{REPO_MODULE}.get_user_by_email", new_callable=AsyncMock) as mock_find,
            patch(f"{REPO_MODULE}.create_user", new_callable=AsyncMock) as mock_create,
        ):
            mock_find.return_value = None
            mock_create.return_value = new_user

            user, is_new = await service.find_or_create_user(
                db, "fresh@example.com", password_hash="hash123"
            )

        assert user is new_user
        assert is_new is True
        mock_create.assert_awaited_once_with(
            db,
            email="fresh@example.com",
            password_hash="hash123",
            username=None,
            phone_number=None,
        )

    async def test_passes_optional_kwargs(self):
        new_user = _make_user(email="kw@example.com", username="kwuser")
        db = _mock_db()

        with (
            patch(f"{REPO_MODULE}.get_user_by_email", new_callable=AsyncMock) as mock_find,
            patch(f"{REPO_MODULE}.create_user", new_callable=AsyncMock) as mock_create,
        ):
            mock_find.return_value = None
            mock_create.return_value = new_user

            user, is_new = await service.find_or_create_user(
                db,
                "kw@example.com",
                username="kwuser",
                phone_number="+15551234567",
            )

        assert is_new is True
        mock_create.assert_awaited_once_with(
            db,
            email="kw@example.com",
            password_hash=None,
            username="kwuser",
            phone_number="+15551234567",
        )


# ---------------------------------------------------------------------------
# set_password
# ---------------------------------------------------------------------------


class TestSetPassword:
    async def test_returns_true_on_success(self):
        db = _mock_db()
        uid = str(uuid4())

        with patch(f"{REPO_MODULE}.update_password", new_callable=AsyncMock) as mock_update:
            mock_update.return_value = True
            result = await service.set_password(db, uid, "new_hash")

        assert result is True
        mock_update.assert_awaited_once_with(db, uid, "new_hash")

    async def test_raises_not_found_when_user_missing(self):
        db = _mock_db()
        uid = str(uuid4())

        with patch(f"{REPO_MODULE}.update_password", new_callable=AsyncMock) as mock_update:
            mock_update.return_value = False

            with pytest.raises(NotFoundError, match=uid):
                await service.set_password(db, uid, "new_hash")
