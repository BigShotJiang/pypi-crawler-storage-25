"""Unit tests for the users domain router (HTTP layer).

Uses httpx.AsyncClient with ASGITransport to test the FastAPI router.
Mocks the service layer and overrides FastAPI dependencies (get_application,
get_db_session) so no real database or API key is required.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from spaps_server_quickstart.domains.users.router import router
from spaps_server_quickstart.domains.users.schemas import (
    BatchEmailsResponse,
    BatchUsersResponse,
    UserBatchInfo,
)
from spaps_server_quickstart.middleware.spaps_deps import (
    get_application,
    get_db_session,
)


# ---------------------------------------------------------------------------
# Test fixtures
# ---------------------------------------------------------------------------

SERVICE_MODULE = "spaps_server_quickstart.domains.users.router.service"


def _create_test_app() -> FastAPI:
    """Create a minimal FastAPI app with the users router and overridden deps."""
    app = FastAPI()

    # Override get_db_session with a no-op async generator
    async def _fake_db():
        yield AsyncMock()

    # Override get_application to return a fake application object
    async def _fake_app():
        fake = MagicMock()
        fake.id = uuid4()
        fake.name = "Test App"
        return fake

    app.dependency_overrides[get_db_session] = _fake_db
    app.dependency_overrides[get_application] = _fake_app
    app.include_router(router)
    return app


@pytest.fixture
def test_app() -> FastAPI:
    return _create_test_app()


@pytest.fixture
async def client(test_app: FastAPI):
    transport = ASGITransport(app=test_app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


# ---------------------------------------------------------------------------
# POST /users/batch/emails
# ---------------------------------------------------------------------------


class TestBatchGetEmails:
    async def test_returns_email_mapping(self, client: AsyncClient):
        uid1 = str(uuid4())
        uid2 = str(uuid4())
        response_data = BatchEmailsResponse(
            emails={uid1: "a@example.com", uid2: None},
            total=2,
            with_email=1,
        )

        with patch(
            f"{SERVICE_MODULE}.batch_get_emails",
            new_callable=AsyncMock,
            return_value=response_data,
        ) as mock_svc:
            resp = await client.post(
                "/users/batch/emails",
                json={"user_ids": [uid1, uid2]},
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["emails"][uid1] == "a@example.com"
        assert data["emails"][uid2] is None
        assert data["total"] == 2
        assert data["with_email"] == 1

    async def test_empty_user_ids(self, client: AsyncClient):
        response_data = BatchEmailsResponse(
            emails={}, total=0, with_email=0
        )

        with patch(
            f"{SERVICE_MODULE}.batch_get_emails",
            new_callable=AsyncMock,
            return_value=response_data,
        ):
            resp = await client.post(
                "/users/batch/emails",
                json={"user_ids": []},
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 0

    async def test_missing_body_returns_422(self, client: AsyncClient):
        resp = await client.post("/users/batch/emails")
        assert resp.status_code == 422


# ---------------------------------------------------------------------------
# POST /users/batch
# ---------------------------------------------------------------------------


class TestBatchGetUsers:
    async def test_returns_user_info_mapping(self, client: AsyncClient):
        uid1 = str(uuid4())
        uid2 = str(uuid4())
        response_data = BatchUsersResponse(
            users={
                uid1: UserBatchInfo(email="a@example.com", active_entitlements=None),
                uid2: UserBatchInfo(email="b@example.com", active_entitlements=None),
            }
        )

        with patch(
            f"{SERVICE_MODULE}.batch_get_users",
            new_callable=AsyncMock,
            return_value=response_data,
        ):
            resp = await client.post(
                "/users/batch",
                json={"user_ids": [uid1, uid2]},
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["users"][uid1]["email"] == "a@example.com"
        assert data["users"][uid2]["email"] == "b@example.com"

    async def test_empty_user_ids(self, client: AsyncClient):
        response_data = BatchUsersResponse(users={})

        with patch(
            f"{SERVICE_MODULE}.batch_get_users",
            new_callable=AsyncMock,
            return_value=response_data,
        ):
            resp = await client.post(
                "/users/batch",
                json={"user_ids": []},
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["users"] == {}

    async def test_missing_body_returns_422(self, client: AsyncClient):
        resp = await client.post("/users/batch")
        assert resp.status_code == 422
