"""Unit tests for the users domain repository layer.

Mocks the AsyncSession to test each repository function in isolation
without hitting a real database.
"""

from __future__ import annotations

from datetime import datetime, UTC
from unittest.mock import AsyncMock, MagicMock
from uuid import UUID, uuid4


from spaps_server_quickstart.domains.users import repository as repo
from spaps_server_quickstart.domains.users.models import User, UserApplication


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_user(
    user_id: str | None = None,
    email: str = "alice@example.com",
    password_hash: str | None = None,
    username: str | None = None,
) -> MagicMock:
    """Return a mock User with sensible defaults."""
    user = MagicMock(spec=User)
    user.id = UUID(user_id) if user_id else uuid4()
    user.email = email
    user.password_hash = password_hash
    user.username = username
    user.phone_number = None
    user.created_at = datetime.now(UTC)
    user.updated_at = datetime.now(UTC)
    return user


def _make_user_application(
    user_id: str | None = None,
    app_id: str | None = None,
    permissions: dict | None = None,
) -> MagicMock:
    """Return a mock UserApplication with sensible defaults."""
    ua = MagicMock(spec=UserApplication)
    ua.id = uuid4()
    ua.user_id = UUID(user_id) if user_id else uuid4()
    ua.application_id = UUID(app_id) if app_id else uuid4()
    ua.permissions = permissions
    ua.created_at = datetime.now(UTC)
    ua.updated_at = datetime.now(UTC)
    return ua


def _mock_session() -> AsyncMock:
    """Create a mock AsyncSession with the common interface."""
    session = AsyncMock()
    session.add = MagicMock()
    session.flush = AsyncMock()
    session.refresh = AsyncMock()
    session.execute = AsyncMock()
    return session


# ---------------------------------------------------------------------------
# get_user_by_id
# ---------------------------------------------------------------------------


class TestGetUserById:
    async def test_returns_user_when_found(self):
        user = _make_user()
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = user
        db.execute.return_value = result_mock

        result = await repo.get_user_by_id(db, str(user.id))

        assert result is user
        db.execute.assert_awaited_once()

    async def test_returns_none_when_not_found(self):
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute.return_value = result_mock

        result = await repo.get_user_by_id(db, str(uuid4()))

        assert result is None


# ---------------------------------------------------------------------------
# get_user_by_email
# ---------------------------------------------------------------------------


class TestGetUserByEmail:
    async def test_returns_user_when_found(self):
        user = _make_user(email="bob@example.com")
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = user
        db.execute.return_value = result_mock

        result = await repo.get_user_by_email(db, "bob@example.com")

        assert result is user
        assert result.email == "bob@example.com"

    async def test_returns_none_when_not_found(self):
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute.return_value = result_mock

        result = await repo.get_user_by_email(db, "unknown@example.com")

        assert result is None


# ---------------------------------------------------------------------------
# create_user
# ---------------------------------------------------------------------------


class TestCreateUser:
    async def test_creates_and_flushes(self):
        db = _mock_session()

        # refresh will set up the returned user
        async def _fake_refresh(obj):
            obj.id = uuid4()
            obj.created_at = datetime.now(UTC)
            obj.updated_at = datetime.now(UTC)

        db.refresh.side_effect = _fake_refresh

        result = await repo.create_user(
            db,
            email="new@example.com",
            password_hash="hashed123",
            username="newuser",
        )

        assert result.email == "new@example.com"
        assert result.password_hash == "hashed123"
        assert result.username == "newuser"
        db.add.assert_called_once()
        db.flush.assert_awaited_once()
        db.refresh.assert_awaited_once()

    async def test_creates_with_minimal_args(self):
        db = _mock_session()

        result = await repo.create_user(db, email="minimal@example.com")

        assert result.email == "minimal@example.com"
        assert result.password_hash is None
        assert result.username is None
        db.add.assert_called_once()


# ---------------------------------------------------------------------------
# update_user
# ---------------------------------------------------------------------------


class TestUpdateUser:
    async def test_updates_existing_user(self):
        user = _make_user(email="old@example.com", username="oldname")
        db = _mock_session()

        # Mock get_user_by_id to return the existing user
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = user
        db.execute.return_value = result_mock

        result = await repo.update_user(
            db, str(user.id), username="newname", email="new@example.com"
        )

        assert result is user
        assert result.username == "newname"
        assert result.email == "new@example.com"
        db.flush.assert_awaited()
        db.refresh.assert_awaited()

    async def test_returns_none_when_user_not_found(self):
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute.return_value = result_mock

        result = await repo.update_user(db, str(uuid4()), username="ignored")

        assert result is None

    async def test_ignores_unknown_attributes(self):
        user = _make_user()
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = user
        db.execute.return_value = result_mock

        result = await repo.update_user(
            db, str(user.id), nonexistent_field="value"
        )

        assert result is user
        assert not hasattr(result, "nonexistent_field") or getattr(result, "nonexistent_field", None) != "value"


# ---------------------------------------------------------------------------
# update_password
# ---------------------------------------------------------------------------


class TestUpdatePassword:
    async def test_returns_true_on_success(self):
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.rowcount = 1
        db.execute.return_value = result_mock

        result = await repo.update_password(db, str(uuid4()), "new_hash")

        assert result is True
        db.flush.assert_awaited_once()

    async def test_returns_false_when_user_not_found(self):
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.rowcount = 0
        db.execute.return_value = result_mock

        result = await repo.update_password(db, str(uuid4()), "new_hash")

        assert result is False


# ---------------------------------------------------------------------------
# get_users_by_ids
# ---------------------------------------------------------------------------


class TestGetUsersByIds:
    async def test_returns_matching_users(self):
        user1 = _make_user(email="a@example.com")
        user2 = _make_user(email="b@example.com")
        db = _mock_session()

        result_mock = MagicMock()
        scalars_mock = MagicMock()
        scalars_mock.all.return_value = [user1, user2]
        result_mock.scalars.return_value = scalars_mock
        db.execute.return_value = result_mock

        result = await repo.get_users_by_ids(db, [str(user1.id), str(user2.id)])

        assert len(result) == 2
        assert user1 in result
        assert user2 in result

    async def test_returns_empty_list_for_empty_input(self):
        db = _mock_session()

        result = await repo.get_users_by_ids(db, [])

        assert result == []
        db.execute.assert_not_awaited()


# ---------------------------------------------------------------------------
# get_user_emails_by_ids
# ---------------------------------------------------------------------------


class TestGetUserEmailsByIds:
    async def test_returns_dict_mapping(self):
        uid1 = str(uuid4())
        uid2 = str(uuid4())
        db = _mock_session()

        row1 = MagicMock()
        row1.id = uid1
        row1.email = "a@example.com"
        row2 = MagicMock()
        row2.id = uid2
        row2.email = "b@example.com"

        result_mock = MagicMock()
        result_mock.all.return_value = [row1, row2]
        db.execute.return_value = result_mock

        result = await repo.get_user_emails_by_ids(db, [uid1, uid2])

        assert result == {uid1: "a@example.com", uid2: "b@example.com"}

    async def test_returns_empty_dict_for_empty_input(self):
        db = _mock_session()

        result = await repo.get_user_emails_by_ids(db, [])

        assert result == {}
        db.execute.assert_not_awaited()


# ---------------------------------------------------------------------------
# get_user_application
# ---------------------------------------------------------------------------


class TestGetUserApplication:
    async def test_returns_user_application_when_found(self):
        ua = _make_user_application()
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = ua
        db.execute.return_value = result_mock

        result = await repo.get_user_application(
            db, str(ua.user_id), str(ua.application_id)
        )

        assert result is ua

    async def test_returns_none_when_not_found(self):
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute.return_value = result_mock

        result = await repo.get_user_application(
            db, str(uuid4()), str(uuid4())
        )

        assert result is None


# ---------------------------------------------------------------------------
# create_user_application
# ---------------------------------------------------------------------------


class TestCreateUserApplication:
    async def test_creates_and_flushes(self):
        db = _mock_session()
        uid = str(uuid4())
        aid = str(uuid4())

        result = await repo.create_user_application(
            db, uid, aid, permissions={"read": True}
        )

        assert result.user_id == UUID(uid)
        assert result.application_id == UUID(aid)
        assert result.permissions == {"read": True}
        db.add.assert_called_once()
        db.flush.assert_awaited_once()
        db.refresh.assert_awaited_once()


# ---------------------------------------------------------------------------
# update_user_application
# ---------------------------------------------------------------------------


class TestUpdateUserApplication:
    async def test_updates_existing_association(self):
        ua = _make_user_application(permissions={"read": True})
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = ua
        db.execute.return_value = result_mock

        result = await repo.update_user_application(
            db,
            str(ua.user_id),
            str(ua.application_id),
            permissions={"read": True, "write": True},
        )

        assert result is ua
        assert result.permissions == {"read": True, "write": True}
        db.flush.assert_awaited()
        db.refresh.assert_awaited()

    async def test_returns_none_when_not_found(self):
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute.return_value = result_mock

        result = await repo.update_user_application(
            db, str(uuid4()), str(uuid4()), permissions={"admin": True}
        )

        assert result is None
