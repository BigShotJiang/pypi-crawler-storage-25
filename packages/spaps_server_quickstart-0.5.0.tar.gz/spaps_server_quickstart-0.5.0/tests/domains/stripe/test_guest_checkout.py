"""Unit tests for the Stripe guest checkout service.

Tests guest checkout flows including creation, retrieval, listing,
and conversion to registered users. All Stripe API calls are mocked.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

from spaps_server_quickstart.domains.stripe import guest_checkout
from spaps_server_quickstart.domains.stripe.errors import (
    EmailMismatchError,
    GuestCheckoutError,
    SessionIncompleteError,
    SessionNotFoundError,
)


FAKE_APP_ID = uuid4()
FAKE_SESSION_ID = "cs_test_guest_123"

_REPO = "spaps_server_quickstart.domains.stripe.repository"


def _mock_guest_session(status="open", customer_email="guest@example.com"):
    """Create a mock guest checkout session."""
    s = MagicMock()
    s.session_id = FAKE_SESSION_ID
    s.application_id = FAKE_APP_ID
    s.user_id = None
    s.status = status
    s.payment_status = "unpaid" if status == "open" else "paid"
    s.customer_email = customer_email
    s.amount_total = 1999
    s.currency = "usd"
    s.success_url = "https://example.com/success"
    s.cancel_url = "https://example.com/cancel"
    s.metadata_ = {"app_id": str(FAKE_APP_ID), "is_guest": "true"}
    s.is_guest = True
    s.expires_at = datetime.now(UTC) + timedelta(minutes=60)
    s.created_at = datetime.now(UTC)
    return s


# ===========================================================================
# create_guest_checkout_session
# ===========================================================================


class TestCreateGuestCheckoutSession:
    @patch(f"{_REPO}.create_checkout_session", new_callable=AsyncMock)
    @patch("stripe.checkout.Session.create")
    async def test_success(self, mock_stripe, mock_repo):
        """Creates guest checkout session with expiry."""
        mock_stripe.return_value = MagicMock(
            id=FAKE_SESSION_ID,
            status="open",
            url="https://checkout.stripe.com/guest",
            amount_total=1999,
            currency="usd",
        )
        mock_stripe.return_value.get = lambda k, d=None: getattr(
            mock_stripe.return_value, k, d
        )
        mock_repo.return_value = _mock_guest_session()

        db = AsyncMock()
        result = await guest_checkout.create_guest_checkout_session(
            db,
            application_id=FAKE_APP_ID,
            customer_email="guest@example.com",
            mode="payment",
            line_items=[{"price_id": "price_test123", "quantity": 1}],
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
        )

        assert result["id"] == FAKE_SESSION_ID
        assert result["customer_email"] == "guest@example.com"
        assert "expires_at" in result
        mock_stripe.assert_called_once()
        call_args = mock_stripe.call_args[1]
        assert call_args["customer_email"] == "guest@example.com"
        assert call_args["metadata"]["is_guest"] == "true"
        assert "expires_at" in call_args

    @patch(f"{_REPO}.create_checkout_session", new_callable=AsyncMock)
    @patch("stripe.checkout.Session.create")
    async def test_with_price_data(self, mock_stripe, mock_repo):
        """Supports price_data for ad-hoc pricing."""
        mock_stripe.return_value = MagicMock(
            id=FAKE_SESSION_ID,
            status="open",
            url="https://checkout.stripe.com/guest",
        )
        mock_stripe.return_value.get = lambda k, d=None: getattr(
            mock_stripe.return_value, k, d
        )
        mock_repo.return_value = _mock_guest_session()

        db = AsyncMock()
        result = await guest_checkout.create_guest_checkout_session(
            db,
            application_id=FAKE_APP_ID,
            customer_email="guest@example.com",
            mode="payment",
            line_items=[
                {
                    "price_data": {
                        "currency": "usd",
                        "unit_amount": 1999,
                        "product_data": {"name": "Ad-hoc Item"},
                    },
                    "quantity": 1,
                }
            ],
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
        )

        assert result["id"] == FAKE_SESSION_ID

    @patch(f"{_REPO}.create_checkout_session", new_callable=AsyncMock)
    @patch("stripe.checkout.Session.create")
    async def test_with_client_reference_id(self, mock_stripe, mock_repo):
        """Supports client_reference_id for tracking."""
        mock_stripe.return_value = MagicMock(
            id=FAKE_SESSION_ID, status="open", url="https://checkout.stripe.com/guest"
        )
        mock_stripe.return_value.get = lambda k, d=None: getattr(
            mock_stripe.return_value, k, d
        )
        mock_repo.return_value = _mock_guest_session()

        db = AsyncMock()
        result = await guest_checkout.create_guest_checkout_session(
            db,
            application_id=FAKE_APP_ID,
            customer_email="guest@example.com",
            mode="payment",
            line_items=[{"price_id": "price_test123", "quantity": 1}],
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
            client_reference_id="order_12345",
        )

        assert result["id"] == FAKE_SESSION_ID
        call_args = mock_stripe.call_args[1]
        assert call_args["client_reference_id"] == "order_12345"

    @patch(f"{_REPO}.create_checkout_session", new_callable=AsyncMock)
    @patch("stripe.checkout.Session.create")
    async def test_with_promotion_codes(self, mock_stripe, mock_repo):
        """Supports allow_promotion_codes flag."""
        mock_stripe.return_value = MagicMock(
            id=FAKE_SESSION_ID, status="open", url="https://checkout.stripe.com/guest"
        )
        mock_stripe.return_value.get = lambda k, d=None: getattr(
            mock_stripe.return_value, k, d
        )
        mock_repo.return_value = _mock_guest_session()

        db = AsyncMock()
        result = await guest_checkout.create_guest_checkout_session(
            db,
            application_id=FAKE_APP_ID,
            customer_email="guest@example.com",
            mode="payment",
            line_items=[{"price_id": "price_test123", "quantity": 1}],
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
            allow_promotion_codes=True,
        )

        assert result["id"] == FAKE_SESSION_ID
        call_args = mock_stripe.call_args[1]
        assert call_args.get("allow_promotion_codes") is True

    @patch("stripe.checkout.Session.create")
    async def test_stripe_error(self, mock_stripe):
        """Raises GuestCheckoutError on Stripe API failure."""
        import stripe as stripe_mod

        mock_stripe.side_effect = stripe_mod.StripeError("Card declined")
        db = AsyncMock()

        with pytest.raises(GuestCheckoutError):
            await guest_checkout.create_guest_checkout_session(
                db,
                application_id=FAKE_APP_ID,
                customer_email="guest@example.com",
                mode="payment",
                line_items=[{"price_id": "price_test123", "quantity": 1}],
                success_url="https://example.com/success",
                cancel_url="https://example.com/cancel",
            )

    @patch(f"{_REPO}.create_checkout_session", new_callable=AsyncMock)
    @patch("stripe.checkout.Session.create")
    async def test_sets_stripe_api_key_from_settings(
        self, mock_stripe, mock_repo, monkeypatch: pytest.MonkeyPatch
    ):
        import stripe as stripe_mod

        mock_stripe.return_value = MagicMock(
            id=FAKE_SESSION_ID,
            status="open",
            url="https://checkout.stripe.com/guest",
            amount_total=1999,
            currency="usd",
        )
        mock_stripe.return_value.get = lambda k, d=None: getattr(
            mock_stripe.return_value, k, d
        )
        mock_repo.return_value = _mock_guest_session()
        monkeypatch.setattr(
            guest_checkout,
            "get_spaps_settings",
            lambda: SimpleNamespace(stripe_secret_key="sk_test_guest_checkout_123"),
            raising=False,
        )
        original_key = stripe_mod.api_key
        stripe_mod.api_key = None

        db = AsyncMock()
        try:
            await guest_checkout.create_guest_checkout_session(
                db,
                application_id=FAKE_APP_ID,
                customer_email="guest@example.com",
                mode="payment",
                line_items=[{"price_id": "price_test123", "quantity": 1}],
                success_url="https://example.com/success",
                cancel_url="https://example.com/cancel",
            )
            assert stripe_mod.api_key == "sk_test_guest_checkout_123"
        finally:
            stripe_mod.api_key = original_key


# ===========================================================================
# get_guest_checkout_session
# ===========================================================================


class TestGetGuestCheckoutSession:
    @patch(f"{_REPO}.get_checkout_session", new_callable=AsyncMock)
    async def test_success(self, mock_get):
        """Retrieves guest checkout session."""
        mock_get.return_value = _mock_guest_session(status="complete")
        db = AsyncMock()

        result = await guest_checkout.get_guest_checkout_session(
            db, session_id=FAKE_SESSION_ID, application_id=FAKE_APP_ID
        )

        assert result["id"] == FAKE_SESSION_ID
        assert result["is_guest"] is True
        assert result["application_id"] == str(FAKE_APP_ID)

    @patch(f"{_REPO}.get_checkout_session", new_callable=AsyncMock)
    async def test_not_found(self, mock_get):
        """Raises SessionNotFoundError when session doesn't exist."""
        mock_get.return_value = None
        db = AsyncMock()

        with pytest.raises(SessionNotFoundError):
            await guest_checkout.get_guest_checkout_session(
                db, session_id="cs_nonexistent"
            )

    @patch(f"{_REPO}.get_checkout_session", new_callable=AsyncMock)
    async def test_not_guest_session(self, mock_get):
        """Raises GuestCheckoutError if session is not guest."""
        session = _mock_guest_session()
        session.is_guest = False
        mock_get.return_value = session
        db = AsyncMock()

        with pytest.raises(GuestCheckoutError, match="not a guest checkout"):
            await guest_checkout.get_guest_checkout_session(
                db, session_id=FAKE_SESSION_ID
            )

    @patch(f"{_REPO}.get_checkout_session", new_callable=AsyncMock)
    async def test_wrong_application(self, mock_get):
        """Raises SessionNotFoundError if application_id doesn't match."""
        session = _mock_guest_session()
        session.application_id = uuid4()  # Different app
        mock_get.return_value = session
        db = AsyncMock()

        with pytest.raises(SessionNotFoundError):
            await guest_checkout.get_guest_checkout_session(
                db, session_id=FAKE_SESSION_ID, application_id=FAKE_APP_ID
            )


# ===========================================================================
# list_guest_checkout_sessions
# ===========================================================================


class TestListGuestCheckoutSessions:
    @patch(f"{_REPO}.list_checkout_sessions", new_callable=AsyncMock)
    async def test_success(self, mock_list):
        """Lists guest checkout sessions for an application."""
        guest1 = _mock_guest_session()
        guest2 = _mock_guest_session()
        guest2.session_id = "cs_test_guest_456"

        # Include non-guest session to verify filtering
        non_guest = _mock_guest_session()
        non_guest.is_guest = False

        mock_list.return_value = [guest1, guest2, non_guest]
        db = AsyncMock()

        result = await guest_checkout.list_guest_checkout_sessions(
            db, application_id=FAKE_APP_ID, limit=10
        )

        assert len(result["sessions"]) == 2
        assert all(s["id"] in [FAKE_SESSION_ID, "cs_test_guest_456"] for s in result["sessions"])

    @patch(f"{_REPO}.list_checkout_sessions", new_callable=AsyncMock)
    async def test_empty(self, mock_list):
        """Returns empty list when no guest sessions."""
        mock_list.return_value = []
        db = AsyncMock()

        result = await guest_checkout.list_guest_checkout_sessions(
            db, application_id=FAKE_APP_ID
        )

        assert result["sessions"] == []
        assert result["has_more"] is False

    @patch(f"{_REPO}.list_checkout_sessions", new_callable=AsyncMock)
    async def test_pagination(self, mock_list):
        """Supports pagination via limit."""
        sessions = [_mock_guest_session() for _ in range(10)]
        mock_list.return_value = sessions
        db = AsyncMock()

        result = await guest_checkout.list_guest_checkout_sessions(
            db, application_id=FAKE_APP_ID, limit=10
        )

        assert result["has_more"] is True
        assert len(result["sessions"]) == 10


# ===========================================================================
# convert_guest_to_user
# ===========================================================================


class TestConvertGuestToUser:
    @patch(f"{_REPO}.create_guest_conversion", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_checkout_session", new_callable=AsyncMock)
    async def test_success(self, mock_get, mock_create_conversion):
        """Converts completed guest checkout to user."""
        session = _mock_guest_session(status="complete")
        mock_get.return_value = session

        conversion = MagicMock()
        conversion.converted_user_id = uuid4()
        mock_create_conversion.return_value = conversion

        db = AsyncMock()
        db.add = MagicMock()  # session.add() is synchronous
        result = await guest_checkout.convert_guest_to_user(
            db,
            session_id=FAKE_SESSION_ID,
            email="guest@example.com",
            application_id=FAKE_APP_ID,
            password="SecurePass123",
        )

        assert "user_id" in result
        assert result["email"] == "guest@example.com"
        assert result["session_id"] == FAKE_SESSION_ID
        mock_create_conversion.assert_called_once()

    @patch(f"{_REPO}.get_checkout_session", new_callable=AsyncMock)
    async def test_session_not_found(self, mock_get):
        """Raises SessionNotFoundError if session doesn't exist."""
        mock_get.return_value = None
        db = AsyncMock()

        with pytest.raises(SessionNotFoundError):
            await guest_checkout.convert_guest_to_user(
                db,
                session_id="cs_nonexistent",
                email="guest@example.com",
                application_id=FAKE_APP_ID,
            )

    @patch(f"{_REPO}.get_checkout_session", new_callable=AsyncMock)
    async def test_not_guest_session(self, mock_get):
        """Raises GuestCheckoutError if session is not guest."""
        session = _mock_guest_session(status="complete")
        session.is_guest = False
        mock_get.return_value = session
        db = AsyncMock()

        with pytest.raises(GuestCheckoutError, match="not a guest checkout"):
            await guest_checkout.convert_guest_to_user(
                db,
                session_id=FAKE_SESSION_ID,
                email="guest@example.com",
                application_id=FAKE_APP_ID,
            )

    @patch(f"{_REPO}.get_checkout_session", new_callable=AsyncMock)
    async def test_session_incomplete(self, mock_get):
        """Raises SessionIncompleteError if payment not complete."""
        session = _mock_guest_session(status="open")
        mock_get.return_value = session
        db = AsyncMock()

        with pytest.raises(SessionIncompleteError):
            await guest_checkout.convert_guest_to_user(
                db,
                session_id=FAKE_SESSION_ID,
                email="guest@example.com",
                application_id=FAKE_APP_ID,
            )

    @patch(f"{_REPO}.get_checkout_session", new_callable=AsyncMock)
    async def test_email_mismatch(self, mock_get):
        """Raises EmailMismatchError if email doesn't match."""
        session = _mock_guest_session(status="complete", customer_email="guest@example.com")
        mock_get.return_value = session
        db = AsyncMock()

        with pytest.raises(EmailMismatchError):
            await guest_checkout.convert_guest_to_user(
                db,
                session_id=FAKE_SESSION_ID,
                email="different@example.com",  # Mismatched email
                application_id=FAKE_APP_ID,
            )

    @patch(f"{_REPO}.create_guest_conversion", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_checkout_session", new_callable=AsyncMock)
    async def test_case_insensitive_email(self, mock_get, mock_create_conversion):
        """Email comparison is case-insensitive."""
        session = _mock_guest_session(status="complete", customer_email="Guest@Example.com")
        mock_get.return_value = session

        conversion = MagicMock()
        conversion.converted_user_id = uuid4()
        mock_create_conversion.return_value = conversion

        db = AsyncMock()
        db.add = MagicMock()  # session.add() is synchronous
        result = await guest_checkout.convert_guest_to_user(
            db,
            session_id=FAKE_SESSION_ID,
            email="guest@example.com",  # Different case
            application_id=FAKE_APP_ID,
        )

        assert result["email"] == "guest@example.com"

    @patch(f"{_REPO}.create_guest_conversion", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_checkout_session", new_callable=AsyncMock)
    async def test_with_magic_link(self, mock_get, mock_create_conversion):
        """Supports send_magic_link flag."""
        session = _mock_guest_session(status="complete")
        mock_get.return_value = session

        conversion = MagicMock()
        conversion.converted_user_id = uuid4()
        mock_create_conversion.return_value = conversion

        db = AsyncMock()
        db.add = MagicMock()  # session.add() is synchronous
        result = await guest_checkout.convert_guest_to_user(
            db,
            session_id=FAKE_SESSION_ID,
            email="guest@example.com",
            application_id=FAKE_APP_ID,
            send_magic_link=True,
        )

        assert "user_id" in result
