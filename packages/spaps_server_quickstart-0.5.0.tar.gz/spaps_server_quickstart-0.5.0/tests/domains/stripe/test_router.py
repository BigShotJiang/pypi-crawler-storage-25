"""Unit tests for the Stripe domain routers (HTTP layer).

Each test creates a minimal FastAPI test app with dependency overrides.
The stripe service layer is fully mocked so tests exercise only routing,
request validation, status codes, and response shapes.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from spaps_server_quickstart.domains.stripe.router import (
    admin_webhooks_router,
    checkout_router,
    guest_checkout_router,
    history_router,
    portal_router,
    products_router,
    subscriptions_router,
    webhooks_router,
)
from spaps_server_quickstart.middleware.error_handler import install_error_handlers
from spaps_server_quickstart.middleware.spaps_deps import (
    get_application,
    get_current_user,
    get_db_session,
    require_admin_user,
    require_super_admin_user,
)


# ---------------------------------------------------------------------------
# Helpers / Constants
# ---------------------------------------------------------------------------

FAKE_USER_ID = str(uuid4())
FAKE_APP_ID = str(uuid4())
FAKE_PRODUCT_ID = "prod_test123"
FAKE_PRICE_ID = "price_test123"
FAKE_SESSION_ID = "cs_test_abc123"

_SERVICE = "spaps_server_quickstart.domains.stripe.service"
_GUEST = "spaps_server_quickstart.domains.stripe.guest_checkout"
_WEBHOOK = "spaps_server_quickstart.domains.stripe.webhook_handler"


def _fake_user():
    user = MagicMock()
    user.id = FAKE_USER_ID
    user.email = "admin@example.com"
    user.username = "admin"
    user.tier = "premium"
    user.roles = ["admin"]
    user.permissions = ["manage_stripe"]
    user.is_admin = True
    user.is_super_admin = False
    user.wallet_addresses = []
    return user


def _fake_super_admin():
    user = _fake_user()
    user.is_super_admin = True
    user.roles = ["admin", "super_admin"]
    return user


def _fake_application():
    app = MagicMock()
    app.id = FAKE_APP_ID
    app.name = "Test App"
    app.slug = "test-app"
    return app


def _create_test_app(*, include_user: bool = True, super_admin: bool = False):
    app = FastAPI()
    settings = MagicMock()
    settings.jwt_secret = "test-secret"
    settings.stripe_webhook_secret = "whsec_test"
    app.state.settings = settings

    install_error_handlers(app)
    app.include_router(products_router)
    app.include_router(checkout_router)
    app.include_router(guest_checkout_router)
    app.include_router(subscriptions_router)
    app.include_router(history_router)
    app.include_router(portal_router)
    app.include_router(webhooks_router)
    app.include_router(admin_webhooks_router)

    mock_db = AsyncMock()

    async def override_db_session():
        yield mock_db

    app.dependency_overrides[get_db_session] = override_db_session
    app.dependency_overrides[get_application] = _fake_application

    if include_user:
        user_fn = _fake_super_admin if super_admin else _fake_user
        app.dependency_overrides[get_current_user] = user_fn
        app.dependency_overrides[require_admin_user] = user_fn
        app.dependency_overrides[require_super_admin_user] = user_fn

    return app


@pytest.fixture
def test_app():
    return _create_test_app()


@pytest.fixture
def test_app_super_admin():
    return _create_test_app(super_admin=True)


@pytest.fixture
async def client(test_app):
    transport = ASGITransport(app=test_app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


@pytest.fixture
async def super_client(test_app_super_admin):
    transport = ASGITransport(app=test_app_super_admin)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


# ===========================================================================
# Products
# ===========================================================================


class TestListProducts:
    @patch(f"{_SERVICE}.list_products", new_callable=AsyncMock)
    async def test_success(self, mock_list, client: AsyncClient):
        mock_list.return_value = {
            "products": [{"id": FAKE_PRODUCT_ID, "name": "Test", "active": True}],
            "total": 1,
        }
        resp = await client.get("/stripe/products")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 1
        assert data["products"][0]["id"] == FAKE_PRODUCT_ID

    @patch(f"{_SERVICE}.list_products", new_callable=AsyncMock)
    async def test_empty(self, mock_list, client: AsyncClient):
        mock_list.return_value = {"products": [], "total": 0}
        resp = await client.get("/stripe/products")
        assert resp.status_code == 200
        assert resp.json()["total"] == 0

    @patch(f"{_SERVICE}.list_products", new_callable=AsyncMock)
    async def test_with_category_filter(self, mock_list, client: AsyncClient):
        mock_list.return_value = {"products": [], "total": 0}
        resp = await client.get("/stripe/products", params={"category": "subscription"})
        assert resp.status_code == 200
        mock_list.assert_called_once()
        assert mock_list.call_args.kwargs.get("category") == "subscription"


class TestGetProduct:
    @patch(f"{_SERVICE}.get_product", new_callable=AsyncMock)
    async def test_success(self, mock_get, client: AsyncClient):
        mock_get.return_value = {
            "id": FAKE_PRODUCT_ID,
            "name": "Test Product",
            "active": True,
            "application_id": FAKE_APP_ID,
            "prices": [],
        }
        resp = await client.get(f"/stripe/products/{FAKE_PRODUCT_ID}")
        assert resp.status_code == 200
        assert resp.json()["id"] == FAKE_PRODUCT_ID

    @patch(f"{_SERVICE}.get_product", new_callable=AsyncMock)
    async def test_not_found(self, mock_get, client: AsyncClient):
        from spaps_server_quickstart.domains.stripe.errors import ProductNotFoundError
        mock_get.side_effect = ProductNotFoundError()
        resp = await client.get("/stripe/products/prod_nonexistent")
        assert resp.status_code == 404


class TestCreateProduct:
    @patch(f"{_SERVICE}.create_product", new_callable=AsyncMock)
    async def test_success(self, mock_create, client: AsyncClient):
        mock_create.return_value = {
            "id": FAKE_PRODUCT_ID,
            "name": "New Product",
            "active": True,
        }
        resp = await client.post(
            "/stripe/products",
            json={"name": "New Product", "category": "general"},
        )
        assert resp.status_code == 201
        assert resp.json()["id"] == FAKE_PRODUCT_ID

    async def test_missing_name_returns_400(self, client: AsyncClient):
        resp = await client.post(
            "/stripe/products",
            json={"category": "general"},
        )
        assert resp.status_code == 400

    async def test_missing_category_returns_400(self, client: AsyncClient):
        resp = await client.post(
            "/stripe/products",
            json={"name": "Test"},
        )
        assert resp.status_code == 400


class TestUpdateProduct:
    @patch(f"{_SERVICE}.update_product", new_callable=AsyncMock)
    async def test_success(self, mock_update, client: AsyncClient):
        mock_update.return_value = {
            "id": FAKE_PRODUCT_ID,
            "name": "Updated Name",
            "active": True,
        }
        resp = await client.put(
            f"/stripe/products/{FAKE_PRODUCT_ID}",
            json={"name": "Updated Name"},
        )
        assert resp.status_code == 200
        assert resp.json()["name"] == "Updated Name"


class TestArchiveProduct:
    @patch(f"{_SERVICE}.archive_product", new_callable=AsyncMock)
    async def test_success(self, mock_archive, client: AsyncClient):
        mock_archive.return_value = {"id": FAKE_PRODUCT_ID, "archived": True, "active": False}
        resp = await client.delete(f"/stripe/products/{FAKE_PRODUCT_ID}")
        assert resp.status_code == 200
        assert resp.json()["archived"] is True


class TestSyncProducts:
    @patch(f"{_SERVICE}.sync_products", new_callable=AsyncMock)
    async def test_success(self, mock_sync, client: AsyncClient):
        mock_sync.return_value = {"synced_count": 5, "message": "Successfully synced 5 products from Stripe"}
        resp = await client.post("/stripe/products/sync")
        assert resp.status_code == 200
        assert resp.json()["synced_count"] == 5


class TestCreateProductWithPrice:
    @patch(f"{_SERVICE}.create_product_with_price", new_callable=AsyncMock)
    async def test_success(self, mock_create, client: AsyncClient):
        mock_create.return_value = {
            "product": {"id": FAKE_PRODUCT_ID, "name": "Bundled"},
            "price": {"id": FAKE_PRICE_ID, "unit_amount": 1999},
        }
        resp = await client.post(
            "/stripe/products/with-price",
            json={
                "product": {"name": "Bundled", "category": "subscription"},
                "price": {"type": "subscription", "amount": 1999, "currency": "usd"},
            },
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["product"]["id"] == FAKE_PRODUCT_ID
        assert data["price"]["id"] == FAKE_PRICE_ID


# ===========================================================================
# Super Admin Products
# ===========================================================================


class TestSuperAdminProducts:
    @patch(f"{_SERVICE}.list_all_products", new_callable=AsyncMock)
    async def test_list_all(self, mock_list, super_client: AsyncClient):
        mock_list.return_value = {"products": [], "total": 0}
        resp = await super_client.get("/stripe/products/super-admin/all")
        assert resp.status_code == 200

    @patch(f"{_SERVICE}.create_product", new_callable=AsyncMock)
    async def test_create_for_app(self, mock_create, super_client: AsyncClient):
        mock_create.return_value = {"id": FAKE_PRODUCT_ID, "name": "SA Product"}
        app_id = str(uuid4())
        resp = await super_client.post(
            f"/stripe/products/super-admin/{app_id}",
            json={"name": "SA Product", "category": "general"},
        )
        assert resp.status_code == 201

    @patch(f"{_SERVICE}.update_product", new_callable=AsyncMock)
    async def test_update(self, mock_update, super_client: AsyncClient):
        mock_update.return_value = {"id": FAKE_PRODUCT_ID, "name": "Updated"}
        resp = await super_client.put(
            f"/stripe/products/super-admin/{FAKE_PRODUCT_ID}",
            json={"name": "Updated"},
        )
        assert resp.status_code == 200

    @patch(f"{_SERVICE}.archive_product", new_callable=AsyncMock)
    async def test_archive(self, mock_archive, super_client: AsyncClient):
        mock_archive.return_value = {"id": FAKE_PRODUCT_ID, "archived": True, "active": False}
        resp = await super_client.delete(
            f"/stripe/products/super-admin/{FAKE_PRODUCT_ID}"
        )
        assert resp.status_code == 200


# ===========================================================================
# Prices
# ===========================================================================


class TestCreatePrice:
    @patch(f"{_SERVICE}.create_price", new_callable=AsyncMock)
    async def test_success(self, mock_create, client: AsyncClient):
        mock_create.return_value = {
            "id": FAKE_PRICE_ID,
            "product_id": FAKE_PRODUCT_ID,
            "unit_amount": 999,
            "currency": "usd",
        }
        resp = await client.post(
            "/stripe/prices",
            json={"product_id": FAKE_PRODUCT_ID, "unit_amount": 999, "currency": "usd"},
        )
        assert resp.status_code == 201
        assert resp.json()["id"] == FAKE_PRICE_ID


class TestDeactivatePrice:
    @patch(f"{_SERVICE}.deactivate_price", new_callable=AsyncMock)
    async def test_success(self, mock_deactivate, client: AsyncClient):
        mock_deactivate.return_value = {"id": FAKE_PRICE_ID, "archived": True, "active": False}
        resp = await client.delete(f"/stripe/prices/{FAKE_PRICE_ID}")
        assert resp.status_code == 200
        assert resp.json()["active"] is False


class TestSetDefaultPrice:
    @patch(f"{_SERVICE}.set_default_price", new_callable=AsyncMock)
    async def test_post(self, mock_set, client: AsyncClient):
        mock_set.return_value = {"id": FAKE_PRODUCT_ID, "name": "Test"}
        resp = await client.post(
            f"/stripe/products/{FAKE_PRODUCT_ID}/default-price",
            json={"price_id": FAKE_PRICE_ID},
        )
        assert resp.status_code == 200

    @patch(f"{_SERVICE}.set_default_price", new_callable=AsyncMock)
    async def test_put(self, mock_set, client: AsyncClient):
        mock_set.return_value = {"id": FAKE_PRODUCT_ID, "name": "Test"}
        resp = await client.put(
            f"/stripe/products/{FAKE_PRODUCT_ID}/default-price",
            json={"price_id": FAKE_PRICE_ID},
        )
        assert resp.status_code == 200


class TestCreateAndSetDefaultPrice:
    @patch(f"{_SERVICE}.create_price_and_set_default", new_callable=AsyncMock)
    async def test_success(self, mock_create_set, client: AsyncClient):
        mock_create_set.return_value = {
            "price": {"id": FAKE_PRICE_ID, "unit_amount": 1999},
            "product_id": FAKE_PRODUCT_ID,
        }
        resp = await client.post(
            f"/stripe/products/{FAKE_PRODUCT_ID}/prices/default-new",
            json={"unit_amount": 1999, "currency": "usd"},
        )
        assert resp.status_code == 201


# ===========================================================================
# Checkout
# ===========================================================================


class TestCreateCheckoutSession:
    @patch(f"{_SERVICE}.create_checkout_session", new_callable=AsyncMock)
    async def test_success(self, mock_create, client: AsyncClient):
        mock_create.return_value = {
            "id": FAKE_SESSION_ID,
            "status": "open",
            "url": "https://checkout.stripe.com/test",
        }
        resp = await client.post(
            "/stripe/checkout-sessions",
            json={
                "mode": "payment",
                "line_items": [{"price_id": FAKE_PRICE_ID, "quantity": 1}],
                "success_url": "https://example.com/success",
                "cancel_url": "https://example.com/cancel",
            },
        )
        assert resp.status_code == 200
        assert resp.json()["id"] == FAKE_SESSION_ID

    async def test_missing_fields_returns_400(self, client: AsyncClient):
        resp = await client.post(
            "/stripe/checkout-sessions",
            json={"mode": "payment"},
        )
        assert resp.status_code == 400


class TestListCheckoutSessions:
    @patch(f"{_SERVICE}.list_checkout_sessions", new_callable=AsyncMock)
    async def test_success(self, mock_list, client: AsyncClient):
        mock_list.return_value = {
            "sessions": [{"id": FAKE_SESSION_ID, "status": "open"}],
            "has_more": False,
        }
        resp = await client.get("/stripe/checkout-sessions")
        assert resp.status_code == 200
        assert len(resp.json()["sessions"]) == 1


class TestGetCheckoutSession:
    @patch(f"{_SERVICE}.get_checkout_session", new_callable=AsyncMock)
    async def test_success(self, mock_get, client: AsyncClient):
        mock_get.return_value = {"id": FAKE_SESSION_ID, "status": "open"}
        resp = await client.get(f"/stripe/checkout-sessions/{FAKE_SESSION_ID}")
        assert resp.status_code == 200
        assert resp.json()["id"] == FAKE_SESSION_ID


class TestExpireCheckoutSession:
    @patch(f"{_SERVICE}.expire_checkout_session", new_callable=AsyncMock)
    async def test_success(self, mock_expire, client: AsyncClient):
        mock_expire.return_value = {"id": FAKE_SESSION_ID, "status": "expired", "expired": True}
        resp = await client.post(f"/stripe/checkout-sessions/{FAKE_SESSION_ID}/expire")
        assert resp.status_code == 200
        assert resp.json()["expired"] is True


# ===========================================================================
# Guest Checkout
# ===========================================================================


class TestCreateGuestCheckoutSession:
    @patch(f"{_GUEST}.create_guest_checkout_session", new_callable=AsyncMock)
    async def test_success(self, mock_create, client: AsyncClient):
        mock_create.return_value = {
            "id": FAKE_SESSION_ID,
            "status": "open",
            "customer_email": "guest@example.com",
        }
        resp = await client.post(
            "/stripe/guest-checkout-sessions",
            json={
                "customer_email": "guest@example.com",
                "mode": "payment",
                "line_items": [{"price_id": FAKE_PRICE_ID, "quantity": 1}],
                "success_url": "https://example.com/success",
                "cancel_url": "https://example.com/cancel",
            },
        )
        assert resp.status_code == 200
        assert resp.json()["customer_email"] == "guest@example.com"

    async def test_invalid_email_returns_400(self, client: AsyncClient):
        resp = await client.post(
            "/stripe/guest-checkout-sessions",
            json={
                "customer_email": "not-an-email",
                "mode": "payment",
                "line_items": [{"price_id": "price_test", "quantity": 1}],
                "success_url": "https://example.com/success",
                "cancel_url": "https://example.com/cancel",
            },
        )
        assert resp.status_code == 400


class TestListGuestCheckoutSessions:
    @patch(f"{_GUEST}.list_guest_checkout_sessions", new_callable=AsyncMock)
    async def test_success(self, mock_list, client: AsyncClient):
        mock_list.return_value = {"sessions": [], "has_more": False}
        resp = await client.get("/stripe/guest-checkout-sessions")
        assert resp.status_code == 200


class TestGetGuestCheckoutSession:
    @patch(f"{_GUEST}.get_guest_checkout_session", new_callable=AsyncMock)
    async def test_success(self, mock_get, client: AsyncClient):
        mock_get.return_value = {
            "id": FAKE_SESSION_ID,
            "status": "open",
            "is_guest": True,
        }
        resp = await client.get(f"/stripe/guest-checkout-sessions/{FAKE_SESSION_ID}")
        assert resp.status_code == 200
        assert resp.json()["is_guest"] is True

    @patch(f"{_GUEST}.get_guest_checkout_session", new_callable=AsyncMock)
    async def test_not_found(self, mock_get, client: AsyncClient):
        from spaps_server_quickstart.domains.stripe.errors import SessionNotFoundError
        mock_get.side_effect = SessionNotFoundError()
        resp = await client.get("/stripe/guest-checkout-sessions/cs_nonexistent")
        assert resp.status_code == 404


class TestConvertGuestCheckout:
    @patch(f"{_GUEST}.convert_guest_to_user", new_callable=AsyncMock)
    async def test_success(self, mock_convert, client: AsyncClient):
        mock_convert.return_value = {
            "user_id": str(uuid4()),
            "email": "guest@example.com",
            "session_id": FAKE_SESSION_ID,
            "message": "Guest checkout converted to user account",
        }
        resp = await client.post(
            "/stripe/guest-checkout-sessions/convert",
            json={"session_id": FAKE_SESSION_ID, "email": "guest@example.com"},
        )
        assert resp.status_code == 200
        assert "converted" in resp.json()["message"].lower()

    @patch(f"{_GUEST}.convert_guest_to_user", new_callable=AsyncMock)
    async def test_session_incomplete(self, mock_convert, client: AsyncClient):
        from spaps_server_quickstart.domains.stripe.errors import SessionIncompleteError
        mock_convert.side_effect = SessionIncompleteError()
        resp = await client.post(
            "/stripe/guest-checkout-sessions/convert",
            json={"session_id": FAKE_SESSION_ID, "email": "guest@example.com"},
        )
        assert resp.status_code == 400

    @patch(f"{_GUEST}.convert_guest_to_user", new_callable=AsyncMock)
    async def test_email_mismatch(self, mock_convert, client: AsyncClient):
        from spaps_server_quickstart.domains.stripe.errors import EmailMismatchError
        mock_convert.side_effect = EmailMismatchError()
        resp = await client.post(
            "/stripe/guest-checkout-sessions/convert",
            json={"session_id": FAKE_SESSION_ID, "email": "wrong@example.com"},
        )
        assert resp.status_code == 400


# ===========================================================================
# Subscriptions
# ===========================================================================


class TestCreateSubscription:
    @patch(f"{_SERVICE}.create_subscription", new_callable=AsyncMock)
    async def test_success(self, mock_create, client: AsyncClient):
        mock_create.return_value = {
            "id": "sub_test123",
            "status": "active",
            "price_id": FAKE_PRICE_ID,
        }
        resp = await client.post(
            "/stripe/subscriptions",
            json={"customer_id": "cus_test123", "price_id": FAKE_PRICE_ID},
        )
        assert resp.status_code == 200
        assert resp.json()["status"] == "active"


class TestListSubscriptions:
    @patch(f"{_SERVICE}.list_subscriptions", new_callable=AsyncMock)
    async def test_success(self, mock_list, client: AsyncClient):
        mock_list.return_value = []
        resp = await client.get("/stripe/subscriptions")
        assert resp.status_code == 200

    @patch(f"{_SERVICE}.list_subscriptions", new_callable=AsyncMock)
    async def test_filter_by_status(self, mock_list, client: AsyncClient):
        mock_list.return_value = []
        resp = await client.get("/stripe/subscriptions", params={"status": "active"})
        assert resp.status_code == 200
        assert mock_list.call_args.kwargs.get("status") == "active"


class TestGetSubscription:
    @patch(f"{_SERVICE}.get_subscription", new_callable=AsyncMock)
    async def test_success(self, mock_get, client: AsyncClient):
        mock_get.return_value = {
            "id": "sub_test123",
            "status": "active",
            "cancel_at_period_end": False,
        }
        resp = await client.get("/stripe/subscription/sub_test123")
        assert resp.status_code == 200
        assert resp.json()["id"] == "sub_test123"


class TestCancelSubscription:
    @patch(f"{_SERVICE}.cancel_subscription", new_callable=AsyncMock)
    async def test_cancel_at_period_end(self, mock_cancel, client: AsyncClient):
        mock_cancel.return_value = {
            "id": "sub_test123",
            "status": "active",
            "cancel_at_period_end": True,
        }
        resp = await client.post("/stripe/subscription/sub_test123/cancel")
        assert resp.status_code == 200
        assert resp.json()["cancel_at_period_end"] is True

    @patch(f"{_SERVICE}.cancel_subscription", new_callable=AsyncMock)
    async def test_cancel_immediately(self, mock_cancel, client: AsyncClient):
        mock_cancel.return_value = {
            "id": "sub_test123",
            "status": "canceled",
            "cancel_at_period_end": False,
        }
        resp = await client.post(
            "/stripe/subscription/sub_test123/cancel",
            json={"immediately": True},
        )
        assert resp.status_code == 200
        assert resp.json()["status"] == "canceled"


class TestUpdateSubscription:
    @patch(f"{_SERVICE}.update_subscription_plan", new_callable=AsyncMock)
    async def test_success(self, mock_update, client: AsyncClient):
        mock_update.return_value = {
            "id": "sub_test123",
            "status": "active",
        }
        resp = await client.post(
            "/stripe/subscription/sub_test123/update",
            json={"price_id": "price_new_123"},
        )
        assert resp.status_code == 200


# ===========================================================================
# Payment History
# ===========================================================================


class TestListPaymentHistory:
    @patch(f"{_SERVICE}.list_payment_history", new_callable=AsyncMock)
    async def test_success(self, mock_list, client: AsyncClient):
        mock_list.return_value = {
            "payments": [
                {
                    "id": str(uuid4()),
                    "amount": 2999,
                    "currency": "usd",
                    "status": "succeeded",
                }
            ],
            "has_more": False,
            "total_count": 1,
        }
        resp = await client.get("/stripe/history")
        assert resp.status_code == 200
        assert len(resp.json()["payments"]) == 1

    @patch(f"{_SERVICE}.list_payment_history", new_callable=AsyncMock)
    async def test_empty(self, mock_list, client: AsyncClient):
        mock_list.return_value = {"payments": [], "has_more": False, "total_count": 0}
        resp = await client.get("/stripe/history")
        assert resp.status_code == 200
        assert resp.json()["total_count"] == 0


class TestGetPaymentDetail:
    @patch(f"{_SERVICE}.get_payment_detail", new_callable=AsyncMock)
    async def test_success(self, mock_get, client: AsyncClient):
        payment_id = str(uuid4())
        mock_get.return_value = {
            "payment": {
                "id": payment_id,
                "amount": 999,
                "currency": "usd",
                "status": "succeeded",
            }
        }
        resp = await client.get(f"/stripe/payment/{payment_id}")
        assert resp.status_code == 200
        assert resp.json()["payment"]["status"] == "succeeded"

    @patch(f"{_SERVICE}.get_payment_detail", new_callable=AsyncMock)
    async def test_not_found(self, mock_get, client: AsyncClient):
        from spaps_server_quickstart.domains.stripe.errors import PaymentNotFoundError
        mock_get.side_effect = PaymentNotFoundError()
        payment_id = str(uuid4())
        resp = await client.get(f"/stripe/payment/{payment_id}")
        assert resp.status_code == 404


# ===========================================================================
# Portal
# ===========================================================================


class TestCreatePortalSession:
    @patch(f"{_SERVICE}.create_portal_session", new_callable=AsyncMock)
    async def test_success(self, mock_portal, client: AsyncClient):
        mock_portal.return_value = {
            "url": "https://billing.stripe.com/test",
            "session_id": "bps_test123",
        }
        resp = await client.post(
            "/stripe/portal-session",
            json={"return_url": "https://example.com/billing"},
        )
        assert resp.status_code == 200
        assert "url" in resp.json()
        mock_portal.assert_called_once()
        # Verify the service is called with the correct parameters (db, user_id, application_id, return_url)
        call_kwargs = mock_portal.call_args.kwargs
        assert call_kwargs.get("application_id") == FAKE_APP_ID
        assert call_kwargs.get("return_url") == "https://example.com/billing"
        assert "user_id" in call_kwargs
        # db is passed as the first positional argument
        assert len(mock_portal.call_args.args) > 0

    @patch(f"{_SERVICE}.create_portal_session", new_callable=AsyncMock)
    async def test_no_customer_returns_404(self, mock_portal, client: AsyncClient):
        from spaps_server_quickstart.domains.stripe.errors import SessionNotFoundError
        mock_portal.side_effect = SessionNotFoundError("No Stripe customer found for this user")
        resp = await client.post(
            "/stripe/portal-session",
            json={"return_url": "https://example.com/billing"},
        )
        assert resp.status_code == 404


# ===========================================================================
# Webhooks
# ===========================================================================


class TestStripeWebhook:
    @patch(f"{_WEBHOOK}.handle_webhook_event", new_callable=AsyncMock)
    @patch(f"{_WEBHOOK}.verify_webhook_signature")
    async def test_success(self, mock_verify, mock_handle, client: AsyncClient):
        mock_verify.return_value = {
            "id": "evt_test123",
            "type": "checkout.session.completed",
            "data": {"object": {}},
        }
        mock_handle.return_value = {"received": True}
        resp = await client.post(
            "/stripe/webhooks",
            content=b'{"id":"evt_test123"}',
            headers={"stripe-signature": "t=123,v1=abc123"},
        )
        assert resp.status_code == 200
        assert resp.json()["received"] is True

    async def test_missing_signature_returns_400(self, client: AsyncClient):
        resp = await client.post(
            "/stripe/webhooks",
            content=b'{"id":"evt_test123"}',
        )
        assert resp.status_code == 400

    @patch(f"{_WEBHOOK}.verify_webhook_signature")
    async def test_invalid_signature_returns_400(self, mock_verify, client: AsyncClient):
        from spaps_server_quickstart.domains.stripe.errors import WebhookSignatureError
        mock_verify.side_effect = WebhookSignatureError()
        resp = await client.post(
            "/stripe/webhooks",
            content=b'{"id":"evt_test123"}',
            headers={"stripe-signature": "t=123,v1=invalid"},
        )
        assert resp.status_code == 400


# ===========================================================================
# Admin Webhook Endpoints
# ===========================================================================


class TestAdminWebhooks:
    async def test_validate_config(self, client: AsyncClient):
        resp = await client.get("/admin/stripe/webhooks/validate")
        assert resp.status_code == 200
        assert resp.json()["valid"] is True

    async def test_list_endpoints(self, client: AsyncClient):
        resp = await client.get("/admin/stripe/webhooks")
        assert resp.status_code == 200


# ===========================================================================
# Applications (super admin)
# ===========================================================================


class TestListApplicationsWithStats:
    async def test_success(self, super_client: AsyncClient):
        resp = await super_client.get("/stripe/applications")
        assert resp.status_code == 200
        assert "applications" in resp.json()
