"""Unit tests for the Stripe domain service layer.

All Stripe API calls are mocked. Tests exercise business logic,
error handling, and repository coordination.
"""

from __future__ import annotations

from datetime import UTC, datetime
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

from spaps_server_quickstart.domains.stripe import service
from spaps_server_quickstart.domains.stripe.errors import (
    PaymentNotFoundError,
    PortalSessionError,
    PriceNotFoundError,
    ProductNotFoundError,
    SessionNotFoundError,
    StripeApiError,
)


FAKE_APP_ID = uuid4()
FAKE_USER_ID = uuid4()
FAKE_PRODUCT_ID = "prod_test_abc123"
FAKE_PRICE_ID = "price_test_abc123"
FAKE_SESSION_ID = "cs_test_abc123"
FAKE_SUB_ID = "sub_test_abc123"

_REPO = "spaps_server_quickstart.domains.stripe.repository"


def _mock_product():
    p = MagicMock()
    p.stripe_product_id = FAKE_PRODUCT_ID
    p.application_id = FAKE_APP_ID
    p.name = "Test Product"
    p.description = "A test product"
    p.active = True
    p.images = []
    p.metadata_ = {"app_id": str(FAKE_APP_ID), "category": "general"}
    p.created_at = datetime.now(UTC)
    p.archived_at = None
    return p


def _mock_price():
    p = MagicMock()
    p.stripe_price_id = FAKE_PRICE_ID
    p.stripe_product_id = FAKE_PRODUCT_ID
    p.unit_amount = 999
    p.currency = "usd"
    p.type = "one_time"
    p.recurring = None
    p.nickname = None
    p.active = True
    return p


def _mock_session():
    s = MagicMock()
    s.session_id = FAKE_SESSION_ID
    s.status = "open"
    s.payment_status = "unpaid"
    s.customer_email = "user@example.com"
    s.amount_total = 2999
    s.currency = "usd"
    s.success_url = "https://example.com/success"
    s.cancel_url = "https://example.com/cancel"
    s.metadata_ = {"app_id": str(FAKE_APP_ID)}
    s.is_guest = False
    s.expires_at = None
    s.created_at = datetime.now(UTC)
    s.application_id = FAKE_APP_ID
    return s


def _mock_payment_record():
    r = MagicMock()
    r.id = uuid4()
    r.amount = 2999
    r.currency = "usd"
    r.status = "succeeded"
    r.description = "Test payment"
    r.stripe_payment_intent_id = "pi_test123"
    r.created_at = datetime.now(UTC)
    r.metadata_ = {}
    return r


# ===========================================================================
# Products
# ===========================================================================


class TestListProducts:
    @patch(f"{_REPO}.list_products", new_callable=AsyncMock)
    async def test_success(self, mock_list):
        mock_list.return_value = [_mock_product()]
        db = AsyncMock()
        result = await service.list_products(db, application_id=FAKE_APP_ID)
        assert result["total"] == 1
        assert result["products"][0]["id"] == FAKE_PRODUCT_ID

    @patch(f"{_REPO}.list_products", new_callable=AsyncMock)
    async def test_empty(self, mock_list):
        mock_list.return_value = []
        db = AsyncMock()
        result = await service.list_products(db, application_id=FAKE_APP_ID)
        assert result["total"] == 0


class TestGetProduct:
    @patch(f"{_REPO}.list_prices_for_product", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_product", new_callable=AsyncMock)
    async def test_success(self, mock_get, mock_prices):
        mock_get.return_value = _mock_product()
        mock_prices.return_value = [_mock_price()]
        db = AsyncMock()
        result = await service.get_product(db, stripe_product_id=FAKE_PRODUCT_ID)
        assert result["id"] == FAKE_PRODUCT_ID
        assert len(result["prices"]) == 1

    @patch(f"{_REPO}.get_product", new_callable=AsyncMock)
    async def test_not_found(self, mock_get):
        mock_get.return_value = None
        db = AsyncMock()
        with pytest.raises(ProductNotFoundError):
            await service.get_product(db, stripe_product_id="prod_nonexistent")


class TestCreateProduct:
    @patch(f"{_REPO}.create_product", new_callable=AsyncMock)
    @patch("stripe.Product.create")
    async def test_success(self, mock_stripe, mock_repo):
        mock_stripe.return_value = MagicMock(id=FAKE_PRODUCT_ID)
        mock_repo.return_value = _mock_product()
        db = AsyncMock()
        result = await service.create_product(
            db,
            application_id=FAKE_APP_ID,
            application_slug="test-app",
            name="Test Product",
            category="general",
        )
        assert result["id"] == FAKE_PRODUCT_ID
        mock_stripe.assert_called_once()

    @patch("stripe.Product.create")
    async def test_stripe_error(self, mock_stripe):
        import stripe as stripe_mod
        mock_stripe.side_effect = stripe_mod.StripeError("API error")
        db = AsyncMock()
        with pytest.raises(StripeApiError):
            await service.create_product(
                db,
                application_id=FAKE_APP_ID,
                application_slug="test-app",
                name="Test",
                category="general",
            )


class TestUpdateProduct:
    @patch(f"{_REPO}.update_product", new_callable=AsyncMock)
    @patch("stripe.Product.modify")
    async def test_success(self, mock_stripe, mock_repo):
        mock_stripe.return_value = MagicMock()
        mock_repo.return_value = _mock_product()
        db = AsyncMock()
        result = await service.update_product(
            db, stripe_product_id=FAKE_PRODUCT_ID, name="Updated"
        )
        assert result["id"] == FAKE_PRODUCT_ID


class TestArchiveProduct:
    @patch(f"{_REPO}.archive_product", new_callable=AsyncMock)
    @patch("stripe.Product.modify")
    async def test_success(self, mock_stripe, mock_repo):
        product = _mock_product()
        product.active = False
        mock_repo.return_value = product
        mock_stripe.return_value = MagicMock()
        db = AsyncMock()
        result = await service.archive_product(db, stripe_product_id=FAKE_PRODUCT_ID)
        assert result["archived"] is True
        assert result["active"] is False


class TestSyncProducts:
    @patch(f"{_REPO}.create_product", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_product", new_callable=AsyncMock)
    @patch("stripe.Product.list")
    async def test_success(self, mock_stripe_list, mock_get, mock_create):
        mock_stripe_list.return_value = {
            "data": [
                {"id": "prod_1", "name": "P1", "description": "D1", "active": True, "metadata": {}},
                {"id": "prod_2", "name": "P2", "description": "D2", "active": True, "metadata": {}},
            ]
        }
        mock_get.return_value = None
        mock_create.return_value = _mock_product()
        db = AsyncMock()
        result = await service.sync_products(db, application_id=FAKE_APP_ID)
        assert result["synced_count"] == 2


# ===========================================================================
# Prices
# ===========================================================================


class TestCreatePrice:
    @patch(f"{_REPO}.create_price", new_callable=AsyncMock)
    @patch("stripe.Price.create")
    async def test_success(self, mock_stripe, mock_repo):
        mock_stripe.return_value = MagicMock(id=FAKE_PRICE_ID)
        mock_repo.return_value = _mock_price()
        db = AsyncMock()
        result = await service.create_price(
            db,
            stripe_product_id=FAKE_PRODUCT_ID,
            unit_amount=999,
            currency="usd",
        )
        assert result["id"] == FAKE_PRICE_ID

    @patch("stripe.Price.create")
    async def test_stripe_error(self, mock_stripe):
        import stripe as stripe_mod
        mock_stripe.side_effect = stripe_mod.StripeError("Invalid price")
        db = AsyncMock()
        with pytest.raises(StripeApiError):
            await service.create_price(
                db,
                stripe_product_id=FAKE_PRODUCT_ID,
                unit_amount=999,
                currency="usd",
            )


class TestDeactivatePrice:
    @patch(f"{_REPO}.deactivate_price", new_callable=AsyncMock)
    @patch("stripe.Price.modify")
    async def test_success(self, mock_stripe, mock_repo):
        price = _mock_price()
        price.active = False
        mock_repo.return_value = price
        mock_stripe.return_value = MagicMock()
        db = AsyncMock()
        result = await service.deactivate_price(db, stripe_price_id=FAKE_PRICE_ID)
        assert result["active"] is False

    @patch(f"{_REPO}.deactivate_price", new_callable=AsyncMock)
    @patch("stripe.Price.modify")
    async def test_not_found(self, mock_stripe, mock_repo):
        mock_stripe.return_value = MagicMock()
        mock_repo.return_value = None
        db = AsyncMock()
        with pytest.raises(PriceNotFoundError):
            await service.deactivate_price(db, stripe_price_id="price_nonexistent")


# ===========================================================================
# Checkout Sessions
# ===========================================================================


class TestCreateCheckoutSession:
    @patch(f"{_REPO}.create_checkout_session", new_callable=AsyncMock)
    @patch("stripe.checkout.Session.create")
    async def test_success(self, mock_stripe, mock_repo):
        mock_stripe.return_value = MagicMock(
            id=FAKE_SESSION_ID,
            status="open",
            url="https://checkout.stripe.com/test",
            amount_total=2999,
            currency="usd",
        )
        mock_stripe.return_value.get = lambda k, d=None: getattr(mock_stripe.return_value, k, d)
        mock_repo.return_value = _mock_session()
        db = AsyncMock()
        result = await service.create_checkout_session(
            db,
            application_id=FAKE_APP_ID,
            user_id=FAKE_USER_ID,
            mode="payment",
            line_items=[{"price_id": FAKE_PRICE_ID, "quantity": 1}],
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
        )
        assert result["id"] == FAKE_SESSION_ID

    @patch(f"{_REPO}.create_checkout_session", new_callable=AsyncMock)
    @patch("stripe.checkout.Session.create")
    async def test_sets_stripe_api_key_from_settings(
        self, mock_stripe, mock_repo, monkeypatch: pytest.MonkeyPatch
    ):
        import stripe as stripe_mod

        mock_stripe.return_value = MagicMock(
            id=FAKE_SESSION_ID,
            status="open",
            url="https://checkout.stripe.com/test",
            amount_total=2999,
            currency="usd",
        )
        mock_stripe.return_value.get = lambda k, d=None: getattr(mock_stripe.return_value, k, d)
        mock_repo.return_value = _mock_session()
        monkeypatch.setattr(
            service,
            "get_spaps_settings",
            lambda: SimpleNamespace(stripe_secret_key="sk_test_checkout_123"),
            raising=False,
        )
        original_key = stripe_mod.api_key
        stripe_mod.api_key = None

        db = AsyncMock()
        try:
            await service.create_checkout_session(
                db,
                application_id=FAKE_APP_ID,
                user_id=FAKE_USER_ID,
                mode="payment",
                line_items=[{"price_id": FAKE_PRICE_ID, "quantity": 1}],
                success_url="https://example.com/success",
                cancel_url="https://example.com/cancel",
            )
            assert stripe_mod.api_key == "sk_test_checkout_123"
        finally:
            stripe_mod.api_key = original_key


class TestGetCheckoutSession:
    @patch(f"{_REPO}.get_checkout_session", new_callable=AsyncMock)
    async def test_success(self, mock_get):
        mock_get.return_value = _mock_session()
        db = AsyncMock()
        result = await service.get_checkout_session(db, session_id=FAKE_SESSION_ID)
        assert result["id"] == FAKE_SESSION_ID

    @patch(f"{_REPO}.get_checkout_session", new_callable=AsyncMock)
    async def test_not_found(self, mock_get):
        mock_get.return_value = None
        db = AsyncMock()
        from spaps_server_quickstart.domains.stripe.errors import SessionNotFoundError
        with pytest.raises(SessionNotFoundError):
            await service.get_checkout_session(db, session_id="cs_nonexistent")


class TestExpireCheckoutSession:
    @patch(f"{_REPO}.update_checkout_session_status", new_callable=AsyncMock)
    @patch("stripe.checkout.Session.expire")
    @patch(f"{_REPO}.get_checkout_session", new_callable=AsyncMock)
    async def test_success(self, mock_get, mock_stripe, mock_repo):
        mock_stripe.return_value = MagicMock()
        session = _mock_session()
        mock_get.return_value = session
        expired_session = _mock_session()
        expired_session.status = "expired"
        mock_repo.return_value = expired_session
        db = AsyncMock()
        result = await service.expire_checkout_session(db, session_id=FAKE_SESSION_ID)
        assert result["expired"] is True


class TestListCheckoutSessions:
    @patch(f"{_REPO}.list_checkout_sessions", new_callable=AsyncMock)
    async def test_success(self, mock_list):
        mock_list.return_value = [_mock_session()]
        db = AsyncMock()
        result = await service.list_checkout_sessions(
            db, user_id=FAKE_USER_ID, application_id=FAKE_APP_ID
        )
        assert len(result["sessions"]) == 1


# ===========================================================================
# Subscriptions
# ===========================================================================


class TestCreateSubscription:
    @patch(f"{_REPO}.create_subscription", new_callable=AsyncMock)
    @patch("stripe.Subscription.create")
    async def test_success(self, mock_stripe, mock_repo):
        mock_stripe.return_value = MagicMock(
            id=FAKE_SUB_ID, status="active",
        )
        mock_stripe.return_value.get = lambda k, d=None: getattr(mock_stripe.return_value, k, d)
        sub_mock = MagicMock()
        sub_mock.stripe_subscription_id = FAKE_SUB_ID
        sub_mock.id = uuid4()
        sub_mock.status = "active"
        sub_mock.price_id = FAKE_PRICE_ID
        mock_repo.return_value = sub_mock
        db = AsyncMock()
        result = await service.create_subscription(
            db,
            user_id=FAKE_USER_ID,
            customer_id="cus_test123",
            price_id=FAKE_PRICE_ID,
        )
        assert result["id"] == FAKE_SUB_ID


class TestGetSubscription:
    @patch(f"{_REPO}.get_subscription_by_stripe_id", new_callable=AsyncMock)
    @patch("stripe.Subscription.retrieve")
    async def test_success(self, mock_stripe, mock_get_local):
        # TM-002: Local record must exist
        local_sub = MagicMock()
        local_sub.user_id = FAKE_USER_ID
        mock_get_local.return_value = local_sub

        mock_stripe.return_value = MagicMock(
            id=FAKE_SUB_ID,
            status="active",
            cancel_at_period_end=False,
            canceled_at=None,
        )
        mock_stripe.return_value.get = lambda k, d=None: getattr(mock_stripe.return_value, k, d)
        db = AsyncMock()
        result = await service.get_subscription(db, subscription_id=FAKE_SUB_ID, user_id=FAKE_USER_ID)
        assert result["id"] == FAKE_SUB_ID

    @patch(f"{_REPO}.get_subscription_by_stripe_id", new_callable=AsyncMock)
    async def test_no_local_record_rejected(self, mock_get_local):
        # TM-002: Test that get_subscription rejects when no local DB record exists
        mock_get_local.return_value = None
        db = AsyncMock()
        from spaps_server_quickstart.domains.stripe.errors import SubscriptionNotFoundError
        with pytest.raises(SubscriptionNotFoundError, match="not found in local database"):
            await service.get_subscription(db, subscription_id="sub_fake123", user_id=FAKE_USER_ID)

    @patch(f"{_REPO}.get_subscription_by_stripe_id", new_callable=AsyncMock)
    async def test_different_user_rejected(self, mock_get_local):
        # TM-002: Test that get_subscription rejects when subscription belongs to different user
        other_user_id = uuid4()
        local_sub = MagicMock()
        local_sub.user_id = other_user_id
        mock_get_local.return_value = local_sub

        db = AsyncMock()
        from spaps_server_quickstart.domains.stripe.errors import SubscriptionNotFoundError
        with pytest.raises(SubscriptionNotFoundError, match="not found"):
            await service.get_subscription(db, subscription_id=FAKE_SUB_ID, user_id=FAKE_USER_ID)


class TestCancelSubscription:
    @patch(f"{_REPO}.get_subscription_by_stripe_id", new_callable=AsyncMock)
    @patch(f"{_REPO}.update_subscription", new_callable=AsyncMock)
    @patch("stripe.Subscription.modify")
    async def test_cancel_at_period_end(self, mock_stripe, mock_update, mock_get_local):
        # TM-002: Local record must exist
        local_sub = MagicMock()
        local_sub.user_id = FAKE_USER_ID
        mock_get_local.return_value = local_sub

        mock_stripe.return_value = MagicMock(
            id=FAKE_SUB_ID,
            status="active",
            cancel_at_period_end=True,
        )
        mock_stripe.return_value.get = lambda k, d=None: getattr(mock_stripe.return_value, k, d)
        mock_update.return_value = MagicMock()
        db = AsyncMock()
        result = await service.cancel_subscription(
            db, subscription_id=FAKE_SUB_ID, immediately=False, user_id=FAKE_USER_ID
        )
        assert result["cancel_at_period_end"] is True

    @patch(f"{_REPO}.get_subscription_by_stripe_id", new_callable=AsyncMock)
    @patch(f"{_REPO}.update_subscription", new_callable=AsyncMock)
    @patch("stripe.Subscription.cancel")
    async def test_cancel_immediately(self, mock_stripe, mock_update, mock_get_local):
        # TM-002: Local record must exist
        local_sub = MagicMock()
        local_sub.user_id = FAKE_USER_ID
        mock_get_local.return_value = local_sub

        mock_stripe.return_value = MagicMock(
            id=FAKE_SUB_ID,
            status="canceled",
            cancel_at_period_end=False,
        )
        mock_stripe.return_value.get = lambda k, d=None: getattr(mock_stripe.return_value, k, d)
        mock_update.return_value = MagicMock()
        db = AsyncMock()
        result = await service.cancel_subscription(
            db, subscription_id=FAKE_SUB_ID, immediately=True, user_id=FAKE_USER_ID
        )
        assert result["status"] == "canceled"

    @patch(f"{_REPO}.get_subscription_by_stripe_id", new_callable=AsyncMock)
    async def test_no_local_record_rejected(self, mock_get_local):
        # TM-002: Test that cancel_subscription rejects when no local DB record exists
        mock_get_local.return_value = None
        db = AsyncMock()
        from spaps_server_quickstart.domains.stripe.errors import SubscriptionNotFoundError
        with pytest.raises(SubscriptionNotFoundError, match="not found in local database"):
            await service.cancel_subscription(db, subscription_id="sub_fake123", user_id=FAKE_USER_ID)

    @patch(f"{_REPO}.get_subscription_by_stripe_id", new_callable=AsyncMock)
    async def test_different_user_rejected(self, mock_get_local):
        # TM-002: Test that cancel_subscription rejects when subscription belongs to different user
        other_user_id = uuid4()
        local_sub = MagicMock()
        local_sub.user_id = other_user_id
        mock_get_local.return_value = local_sub

        db = AsyncMock()
        from spaps_server_quickstart.domains.stripe.errors import SubscriptionNotFoundError
        with pytest.raises(SubscriptionNotFoundError, match="not found"):
            await service.cancel_subscription(db, subscription_id=FAKE_SUB_ID, user_id=FAKE_USER_ID)


class TestUpdateSubscriptionPlan:
    @patch(f"{_REPO}.get_subscription_by_stripe_id", new_callable=AsyncMock)
    @patch(f"{_REPO}.update_subscription", new_callable=AsyncMock)
    @patch("stripe.Subscription.modify")
    @patch("stripe.Subscription.retrieve")
    async def test_success(self, mock_retrieve, mock_modify, mock_update, mock_get_local):
        # TM-002: Local record must exist
        local_sub = MagicMock()
        local_sub.user_id = FAKE_USER_ID
        mock_get_local.return_value = local_sub

        mock_retrieve.return_value = MagicMock()
        mock_retrieve.return_value.get = lambda k, d=None: {
            "items": {"data": [{"id": "si_test123"}]},
        }.get(k, d)
        mock_modify.return_value = MagicMock(id=FAKE_SUB_ID, status="active")
        mock_modify.return_value.get = lambda k, d=None: getattr(mock_modify.return_value, k, d)
        mock_update.return_value = MagicMock()
        db = AsyncMock()
        result = await service.update_subscription_plan(
            db, subscription_id=FAKE_SUB_ID, price_id="price_new_123", user_id=FAKE_USER_ID
        )
        assert result["id"] == FAKE_SUB_ID

    @patch(f"{_REPO}.get_subscription_by_stripe_id", new_callable=AsyncMock)
    async def test_no_local_record_rejected(self, mock_get_local):
        # TM-002: Test that update_subscription_plan rejects when no local DB record exists
        mock_get_local.return_value = None
        db = AsyncMock()
        from spaps_server_quickstart.domains.stripe.errors import SubscriptionNotFoundError
        with pytest.raises(SubscriptionNotFoundError, match="not found in local database"):
            await service.update_subscription_plan(
                db, subscription_id="sub_fake123", price_id="price_new_123", user_id=FAKE_USER_ID
            )

    @patch(f"{_REPO}.get_subscription_by_stripe_id", new_callable=AsyncMock)
    async def test_different_user_rejected(self, mock_get_local):
        # TM-002: Test that update_subscription_plan rejects when subscription belongs to different user
        other_user_id = uuid4()
        local_sub = MagicMock()
        local_sub.user_id = other_user_id
        mock_get_local.return_value = local_sub

        db = AsyncMock()
        from spaps_server_quickstart.domains.stripe.errors import SubscriptionNotFoundError
        with pytest.raises(SubscriptionNotFoundError, match="not found"):
            await service.update_subscription_plan(
                db, subscription_id=FAKE_SUB_ID, price_id="price_new_123", user_id=FAKE_USER_ID
            )


class TestListSubscriptions:
    @patch(f"{_REPO}.list_subscriptions", new_callable=AsyncMock)
    async def test_success(self, mock_list):
        sub = MagicMock()
        sub.stripe_subscription_id = FAKE_SUB_ID
        sub.id = uuid4()
        sub.status = "active"
        sub.price_id = FAKE_PRICE_ID
        sub.current_period_start = datetime.now(UTC)
        sub.current_period_end = datetime.now(UTC)
        sub.cancel_at = None
        sub.canceled_at = None
        mock_list.return_value = [sub]
        db = AsyncMock()
        result = await service.list_subscriptions(db, user_id=FAKE_USER_ID)
        assert len(result) == 1

    @patch(f"{_REPO}.list_subscriptions", new_callable=AsyncMock)
    async def test_only_returns_user_subscriptions(self, mock_list):
        # TM-002: Test that list_subscriptions only queries local DB and is scoped to user_id
        # This verifies it doesn't query Stripe and can't expose other users' subscriptions
        user_sub = MagicMock()
        user_sub.stripe_subscription_id = FAKE_SUB_ID
        user_sub.id = uuid4()
        user_sub.status = "active"
        user_sub.price_id = FAKE_PRICE_ID
        user_sub.current_period_start = datetime.now(UTC)
        user_sub.current_period_end = datetime.now(UTC)
        user_sub.cancel_at = None
        user_sub.canceled_at = None
        mock_list.return_value = [user_sub]

        db = AsyncMock()
        result = await service.list_subscriptions(db, user_id=FAKE_USER_ID)

        # Verify it called the repo with the correct user_id filter
        mock_list.assert_called_once()
        call_kwargs = mock_list.call_args[1]
        assert call_kwargs["user_id"] == FAKE_USER_ID
        assert len(result) == 1


# ===========================================================================
# Payment History
# ===========================================================================


class TestListPaymentHistory:
    @patch(f"{_REPO}.list_payment_history", new_callable=AsyncMock)
    async def test_success(self, mock_list):
        mock_list.return_value = [_mock_payment_record()]
        db = AsyncMock()
        result = await service.list_payment_history(db, user_id=FAKE_USER_ID)
        assert len(result["payments"]) == 1

    @patch(f"{_REPO}.list_payment_history", new_callable=AsyncMock)
    async def test_empty(self, mock_list):
        mock_list.return_value = []
        db = AsyncMock()
        result = await service.list_payment_history(db, user_id=FAKE_USER_ID)
        assert result["payments"] == []


class TestGetPaymentDetail:
    @patch(f"{_REPO}.get_payment_record", new_callable=AsyncMock)
    async def test_success(self, mock_get):
        mock_get.return_value = _mock_payment_record()
        db = AsyncMock()
        result = await service.get_payment_detail(
            db, payment_id=uuid4(), user_id=FAKE_USER_ID
        )
        assert result["payment"]["status"] == "succeeded"

    @patch(f"{_REPO}.get_payment_record", new_callable=AsyncMock)
    async def test_not_found(self, mock_get):
        mock_get.return_value = None
        db = AsyncMock()
        with pytest.raises(PaymentNotFoundError):
            await service.get_payment_detail(
                db, payment_id=uuid4(), user_id=FAKE_USER_ID
            )


# ===========================================================================
# Portal
# ===========================================================================


class TestCreatePortalSession:
    @patch("spaps_server_quickstart.domains.stripe.repository.get_latest_checkout_customer_id", new_callable=AsyncMock)
    @patch("stripe.billing_portal.Session.create")
    async def test_success(self, mock_stripe, mock_get_customer):
        db = AsyncMock()
        mock_get_customer.return_value = "cus_test123"
        mock_stripe.return_value = MagicMock(
            url="https://billing.stripe.com/test",
            id="bps_test123",
        )
        user_id = uuid4()
        app_id = uuid4()
        result = await service.create_portal_session(
            db,
            user_id=user_id,
            application_id=app_id,
            return_url="https://example.com/billing",
        )
        assert result["url"] == "https://billing.stripe.com/test"
        mock_get_customer.assert_called_once_with(db, user_id=user_id, application_id=app_id)

    @patch("spaps_server_quickstart.domains.stripe.repository.get_latest_checkout_customer_id", new_callable=AsyncMock)
    async def test_no_customer_found(self, mock_get_customer):
        db = AsyncMock()
        mock_get_customer.return_value = None
        with pytest.raises(SessionNotFoundError, match="No Stripe customer found"):
            await service.create_portal_session(
                db,
                user_id=uuid4(),
                application_id=uuid4(),
                return_url="https://example.com/billing",
            )

    @patch("spaps_server_quickstart.domains.stripe.repository.get_latest_checkout_customer_id", new_callable=AsyncMock)
    @patch("stripe.billing_portal.Session.create")
    async def test_stripe_error(self, mock_stripe, mock_get_customer):
        db = AsyncMock()
        mock_get_customer.return_value = "cus_test123"
        import stripe as stripe_mod
        mock_stripe.side_effect = stripe_mod.StripeError("Portal error")
        with pytest.raises(PortalSessionError):
            await service.create_portal_session(
                db,
                user_id=uuid4(),
                application_id=uuid4(),
                return_url="https://example.com/billing",
            )
