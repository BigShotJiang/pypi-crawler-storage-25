"""TDD tests for TM-002: Subscription application scoping.

Tests the requirement that subscription operations require local record match
on subscription_id + application_id + user_id. No direct Stripe fetch/cancel/update
without scoped local record.
"""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

from spaps_server_quickstart.domains.stripe import service
from spaps_server_quickstart.domains.stripe.errors import SubscriptionNotFoundError


# Test fixture UUIDs
APP_A_ID = uuid4()
APP_B_ID = uuid4()
USER_1_ID = uuid4()
USER_2_ID = uuid4()
STRIPE_SUB_ID = "sub_test123"


def _mock_subscription(
    *,
    user_id=USER_1_ID,
    application_id=APP_A_ID,
    stripe_subscription_id=STRIPE_SUB_ID,
    status="active",
):
    """Helper to create a mock Subscription model."""
    sub = MagicMock()
    sub.id = uuid4()
    sub.user_id = user_id
    sub.application_id = application_id
    sub.stripe_subscription_id = stripe_subscription_id
    sub.stripe_customer_id = "cus_test123"
    sub.price_id = "price_test123"
    sub.status = status
    sub.current_period_start = datetime.now(UTC)
    sub.current_period_end = datetime.now(UTC)
    sub.cancel_at = None
    sub.canceled_at = None
    sub.metadata_ = {}
    sub.created_at = datetime.now(UTC)
    sub.updated_at = datetime.now(UTC)
    return sub


def _mock_stripe_subscription():
    """Helper to create a mock Stripe subscription response."""
    sub = MagicMock()
    sub.id = STRIPE_SUB_ID
    sub.status = "active"
    sub.current_period_start = int(datetime.now(UTC).timestamp())
    sub.current_period_end = int(datetime.now(UTC).timestamp())
    sub.cancel_at_period_end = False
    sub.canceled_at = None
    sub.get = lambda k, d=None: getattr(sub, k, d)
    sub.__getitem__ = lambda self, k: getattr(sub, k)
    return sub


# ===========================================================================
# Service Tests (TM-002 enforcement)
# ===========================================================================


class TestServiceApplicationScoping:
    """Test service-layer application_id enforcement."""

    @pytest.mark.asyncio
    @patch("spaps_server_quickstart.domains.stripe.service.stripe")
    @patch("spaps_server_quickstart.domains.stripe.repository.get_subscription_by_stripe_id_and_app")
    async def test_get_subscription_same_user_different_app_denied(
        self, mock_repo_get, mock_stripe
    ):
        """Same user, different app → subscription not found."""
        db = AsyncMock()
        mock_repo_get.return_value = None  # Not found for APP_B

        with pytest.raises(SubscriptionNotFoundError):
            await service.get_subscription(
                db,
                subscription_id=STRIPE_SUB_ID,
                user_id=USER_1_ID,
                application_id=APP_B_ID,  # wrong app
            )

        mock_stripe.Subscription.retrieve.assert_not_called()

    @pytest.mark.asyncio
    @patch("spaps_server_quickstart.domains.stripe.service.stripe")
    @patch("spaps_server_quickstart.domains.stripe.repository.get_subscription_by_stripe_id_and_app")
    async def test_get_subscription_correct_user_and_app_succeeds(
        self, mock_repo_get, mock_stripe
    ):
        """Correct user + correct app → subscription operations succeed."""
        db = AsyncMock()
        local_sub = _mock_subscription(
            user_id=USER_1_ID,
            application_id=APP_A_ID,
            stripe_subscription_id=STRIPE_SUB_ID,
        )
        mock_repo_get.return_value = local_sub

        stripe_sub = _mock_stripe_subscription()
        mock_stripe.Subscription.retrieve.return_value = stripe_sub

        result = await service.get_subscription(
            db,
            subscription_id=STRIPE_SUB_ID,
            user_id=USER_1_ID,
            application_id=APP_A_ID,
        )

        assert result["id"] == STRIPE_SUB_ID
        mock_stripe.Subscription.retrieve.assert_called_once()

    @pytest.mark.asyncio
    @patch("spaps_server_quickstart.domains.stripe.service.stripe")
    @patch("spaps_server_quickstart.domains.stripe.repository.get_subscription_by_stripe_id_and_app")
    @patch("spaps_server_quickstart.domains.stripe.repository.update_subscription")
    async def test_cancel_subscription_wrong_app_denied(
        self, mock_repo_update, mock_repo_get, mock_stripe
    ):
        """Cancel subscription with wrong application_id → denied."""
        db = AsyncMock()
        mock_repo_get.return_value = None

        with pytest.raises(SubscriptionNotFoundError):
            await service.cancel_subscription(
                db,
                subscription_id=STRIPE_SUB_ID,
                user_id=USER_1_ID,
                application_id=APP_B_ID,
            )

        mock_stripe.Subscription.cancel.assert_not_called()
        mock_stripe.Subscription.modify.assert_not_called()

    @pytest.mark.asyncio
    @patch("spaps_server_quickstart.domains.stripe.service.stripe")
    @patch("spaps_server_quickstart.domains.stripe.repository.get_subscription_by_stripe_id_and_app")
    @patch("spaps_server_quickstart.domains.stripe.repository.update_subscription")
    async def test_update_subscription_plan_wrong_app_denied(
        self, mock_repo_update, mock_repo_get, mock_stripe
    ):
        """Update subscription plan with wrong application_id → denied."""
        db = AsyncMock()
        mock_repo_get.return_value = None

        with pytest.raises(SubscriptionNotFoundError):
            await service.update_subscription_plan(
                db,
                subscription_id=STRIPE_SUB_ID,
                price_id="price_new123",
                user_id=USER_1_ID,
                application_id=APP_B_ID,
            )

        mock_stripe.Subscription.retrieve.assert_not_called()
        mock_stripe.Subscription.modify.assert_not_called()

    @pytest.mark.asyncio
    @patch("spaps_server_quickstart.domains.stripe.service.stripe")
    @patch("spaps_server_quickstart.domains.stripe.repository.create_subscription")
    async def test_create_subscription_stores_application_id(
        self, mock_repo_create, mock_stripe
    ):
        """Create subscription should store application_id in local record."""
        db = AsyncMock()
        local_sub = _mock_subscription(
            user_id=USER_1_ID,
            application_id=APP_A_ID,
            stripe_subscription_id=STRIPE_SUB_ID,
        )
        mock_repo_create.return_value = local_sub

        stripe_sub = MagicMock()
        stripe_sub.id = STRIPE_SUB_ID
        stripe_sub.get = MagicMock(return_value="active")
        mock_stripe.Subscription.create.return_value = stripe_sub

        result = await service.create_subscription(
            db,
            user_id=USER_1_ID,
            customer_id="cus_test123",
            price_id="price_test123",
            application_id=APP_A_ID,
        )

        mock_repo_create.assert_called_once()
        call_kwargs = mock_repo_create.call_args[1]
        assert call_kwargs["application_id"] == APP_A_ID
        assert call_kwargs["user_id"] == USER_1_ID

    @pytest.mark.asyncio
    @patch("spaps_server_quickstart.domains.stripe.repository.list_subscriptions")
    async def test_list_subscriptions_filters_by_app(self, mock_repo_list):
        """List subscriptions should filter by application_id."""
        db = AsyncMock()
        sub1 = _mock_subscription(user_id=USER_1_ID, application_id=APP_A_ID)
        mock_repo_list.return_value = [sub1]

        result = await service.list_subscriptions(
            db,
            user_id=USER_1_ID,
            application_id=APP_A_ID,
        )

        mock_repo_list.assert_called_once()
        call_kwargs = mock_repo_list.call_args[1]
        assert call_kwargs["application_id"] == APP_A_ID
        assert len(result) == 1
