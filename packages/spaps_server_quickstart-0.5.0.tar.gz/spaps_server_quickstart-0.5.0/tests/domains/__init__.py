"""SPAPS domain tests."""
