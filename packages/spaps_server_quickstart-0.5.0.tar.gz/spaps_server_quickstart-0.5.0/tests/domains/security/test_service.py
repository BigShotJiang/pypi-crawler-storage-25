"""Unit tests for the security domain service layer.

The repository layer is mocked so tests exercise only business logic,
error handling, and data transformation.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

_SECURITY_REPO = "spaps_server_quickstart.domains.security.repository"


def _mock_alert(**overrides):
    """Create a mock SecurityAlert model instance."""
    alert = MagicMock()
    alert.id = overrides.get("id", uuid4())
    alert.alert_type = overrides.get("alert_type", "privilege_escalation")
    alert.user_id = overrides.get("user_id", uuid4())
    alert.elevated_by = overrides.get("elevated_by", "wallet")
    alert.severity = overrides.get("severity", "high")
    alert.details = overrides.get("details", {"info": "test"})
    alert.timestamp = overrides.get("timestamp", datetime.now(UTC))
    alert.ip_address = overrides.get("ip_address", "127.0.0.1")
    alert.user_agent = overrides.get("user_agent", "TestAgent/1.0")
    return alert


# ===========================================================================
# create_alert
# ===========================================================================


class TestCreateAlert:
    @patch(f"{_SECURITY_REPO}.create_alert", new_callable=AsyncMock)
    async def test_creates_alert(self, mock_create):
        """create_alert creates a security alert."""
        from spaps_server_quickstart.domains.security.service import create_alert

        mock_alert = _mock_alert(alert_type="suspicious_login")
        mock_create.return_value = mock_alert

        db = AsyncMock()
        result = await create_alert(
            db,
            alert_type="suspicious_login",
            severity="medium",
            user_id=mock_alert.user_id,
            ip_address="10.0.0.1",
        )

        mock_create.assert_called_once()
        assert result["alert_type"] == "suspicious_login"
        assert isinstance(result["id"], str)

    @patch(f"{_SECURITY_REPO}.create_alert", new_callable=AsyncMock)
    async def test_default_severity(self, mock_create):
        """create_alert defaults to medium severity."""
        from spaps_server_quickstart.domains.security.service import create_alert

        mock_alert = _mock_alert(severity="medium")
        mock_create.return_value = mock_alert

        db = AsyncMock()
        await create_alert(db, alert_type="test")

        call_kwargs = mock_create.call_args.kwargs
        assert call_kwargs.get("severity") == "medium"

    @patch(f"{_SECURITY_REPO}.create_alert", new_callable=AsyncMock)
    async def test_with_details(self, mock_create):
        """create_alert passes details through."""
        from spaps_server_quickstart.domains.security.service import create_alert

        details = {"failed_attempts": 5, "source": "api"}
        mock_alert = _mock_alert(details=details)
        mock_create.return_value = mock_alert

        db = AsyncMock()
        result = await create_alert(
            db,
            alert_type="brute_force",
            details=details,
        )

        assert result["details"] == details


# ===========================================================================
# check_privilege_escalation
# ===========================================================================


class TestCheckPrivilegeEscalation:
    @patch(f"{_SECURITY_REPO}.create_alert", new_callable=AsyncMock)
    async def test_detects_escalation(self, mock_create):
        """check_privilege_escalation detects and records escalation."""
        from spaps_server_quickstart.domains.security.service import (
            check_privilege_escalation,
        )

        mock_alert = _mock_alert(
            alert_type="privilege_escalation",
            severity="high",
            details={
                "current_roles": ["user"],
                "requested_roles": ["admin"],
                "escalated_roles": ["admin"],
            },
        )
        mock_create.return_value = mock_alert

        db = AsyncMock()
        user_id = uuid4()
        result = await check_privilege_escalation(
            db,
            user_id=user_id,
            requested_roles=["admin"],
            current_roles=["user"],
            elevated_by="wallet",
        )

        assert result is not None
        assert result["alert_type"] == "privilege_escalation"
        assert result["severity"] == "high"
        mock_create.assert_called_once()

    async def test_no_escalation_returns_none(self):
        """check_privilege_escalation returns None when no escalation."""
        from spaps_server_quickstart.domains.security.service import (
            check_privilege_escalation,
        )

        db = AsyncMock()
        result = await check_privilege_escalation(
            db,
            user_id=uuid4(),
            requested_roles=["user"],
            current_roles=["user", "admin"],
        )

        assert result is None

    @patch(f"{_SECURITY_REPO}.create_alert", new_callable=AsyncMock)
    async def test_multiple_escalated_roles(self, mock_create):
        """check_privilege_escalation detects multiple escalated roles."""
        from spaps_server_quickstart.domains.security.service import (
            check_privilege_escalation,
        )

        mock_alert = _mock_alert()
        mock_create.return_value = mock_alert

        db = AsyncMock()
        result = await check_privilege_escalation(
            db,
            user_id=uuid4(),
            requested_roles=["admin", "super_admin"],
            current_roles=["user"],
        )

        assert result is not None
        # Verify the details contain escalated roles
        call_kwargs = mock_create.call_args.kwargs
        assert "admin" in call_kwargs["details"]["escalated_roles"]
        assert "super_admin" in call_kwargs["details"]["escalated_roles"]

    @patch(f"{_SECURITY_REPO}.create_alert", new_callable=AsyncMock)
    async def test_passes_ip_and_user_agent(self, mock_create):
        """check_privilege_escalation passes forensic info."""
        from spaps_server_quickstart.domains.security.service import (
            check_privilege_escalation,
        )

        mock_alert = _mock_alert()
        mock_create.return_value = mock_alert

        db = AsyncMock()
        await check_privilege_escalation(
            db,
            user_id=uuid4(),
            requested_roles=["admin"],
            current_roles=["user"],
            ip_address="10.0.0.1",
            user_agent="BadBot/1.0",
        )

        call_kwargs = mock_create.call_args.kwargs
        assert call_kwargs["ip_address"] == "10.0.0.1"
        assert call_kwargs["user_agent"] == "BadBot/1.0"


# ===========================================================================
# get_alerts
# ===========================================================================


class TestGetAlerts:
    @patch(f"{_SECURITY_REPO}.list_alerts", new_callable=AsyncMock)
    async def test_returns_alerts_and_total(self, mock_list):
        """get_alerts returns alerts and total count."""
        from spaps_server_quickstart.domains.security.service import get_alerts

        mock_alerts = [_mock_alert(), _mock_alert()]
        mock_list.return_value = (mock_alerts, 2)

        db = AsyncMock()
        result = await get_alerts(db)

        assert result["total"] == 2
        assert len(result["alerts"]) == 2

    @patch(f"{_SECURITY_REPO}.list_alerts", new_callable=AsyncMock)
    async def test_empty_result(self, mock_list):
        """get_alerts returns empty list when no alerts."""
        from spaps_server_quickstart.domains.security.service import get_alerts

        mock_list.return_value = ([], 0)

        db = AsyncMock()
        result = await get_alerts(db)

        assert result["total"] == 0
        assert result["alerts"] == []

    @patch(f"{_SECURITY_REPO}.list_alerts", new_callable=AsyncMock)
    async def test_passes_filters(self, mock_list):
        """get_alerts passes filters to repository."""
        from spaps_server_quickstart.domains.security.service import get_alerts

        mock_list.return_value = ([], 0)

        db = AsyncMock()
        await get_alerts(
            db,
            alert_type="suspicious_login",
            severity="high",
            limit=25,
        )

        mock_list.assert_called_once_with(
            db,
            alert_type="suspicious_login",
            severity="high",
            limit=25,
        )


# ===========================================================================
# get_summary
# ===========================================================================


class TestGetSummary:
    @patch(f"{_SECURITY_REPO}.get_summary", new_callable=AsyncMock)
    async def test_returns_summary(self, mock_summary):
        """get_summary returns counts by type and severity."""
        from spaps_server_quickstart.domains.security.service import get_summary

        mock_summary.return_value = {
            "total": 10,
            "by_type": [
                {"alert_type": "privilege_escalation", "count": 6},
                {"alert_type": "suspicious_login", "count": 4},
            ],
            "by_severity": [
                {"severity": "high", "count": 6},
                {"severity": "medium", "count": 4},
            ],
        }

        db = AsyncMock()
        result = await get_summary(db, hours=24)

        assert result["total"] == 10
        assert result["window_hours"] == 24
        assert len(result["by_type"]) == 2
        assert len(result["by_severity"]) == 2

    @patch(f"{_SECURITY_REPO}.get_summary", new_callable=AsyncMock)
    async def test_empty_summary(self, mock_summary):
        """get_summary returns zeros when no alerts in window."""
        from spaps_server_quickstart.domains.security.service import get_summary

        mock_summary.return_value = {
            "total": 0,
            "by_type": [],
            "by_severity": [],
        }

        db = AsyncMock()
        result = await get_summary(db, hours=1)

        assert result["total"] == 0
        assert result["window_hours"] == 1

    @patch(f"{_SECURITY_REPO}.get_summary", new_callable=AsyncMock)
    async def test_custom_hours(self, mock_summary):
        """get_summary calculates since datetime from hours."""
        from spaps_server_quickstart.domains.security.service import get_summary

        mock_summary.return_value = {
            "total": 0,
            "by_type": [],
            "by_severity": [],
        }

        db = AsyncMock()
        await get_summary(db, hours=72)

        # Verify the since parameter was calculated correctly
        call_kwargs = mock_summary.call_args.kwargs
        since = call_kwargs["since"]
        now = datetime.now(UTC)
        expected_delta = timedelta(hours=72)
        assert abs((now - since) - expected_delta) < timedelta(seconds=2)

    @patch(f"{_SECURITY_REPO}.get_summary", new_callable=AsyncMock)
    async def test_default_hours(self, mock_summary):
        """get_summary defaults to 24 hours."""
        from spaps_server_quickstart.domains.security.service import get_summary

        mock_summary.return_value = {
            "total": 0,
            "by_type": [],
            "by_severity": [],
        }

        db = AsyncMock()
        result = await get_summary(db)

        assert result["window_hours"] == 24
