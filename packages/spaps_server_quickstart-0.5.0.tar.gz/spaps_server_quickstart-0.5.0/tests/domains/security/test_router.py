"""Unit tests for the security domain router (HTTP layer).

Each test creates a minimal FastAPI test app with dependency overrides for
the database session, application, current user, and admin user. The
security service layer is fully mocked so tests exercise only routing,
request validation, status codes, and response shapes.
"""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from spaps_server_quickstart.domains.security.router import security_router
from spaps_server_quickstart.middleware.error_handler import install_error_handlers
from spaps_server_quickstart.middleware.spaps_deps import (
    get_application,
    get_current_user,
    get_db_session,
    require_admin_user,
)

# ---------------------------------------------------------------------------
# Helpers / Constants
# ---------------------------------------------------------------------------

FAKE_ADMIN_ID = str(uuid4())
FAKE_APP_ID = str(uuid4())
FAKE_USER_ID = str(uuid4())

_SECURITY_SERVICE = "spaps_server_quickstart.domains.security.service"


def _fake_alert(
    alert_type: str = "privilege_escalation",
    severity: str = "high",
) -> dict:
    """Return a realistic security alert dict."""
    return {
        "id": str(uuid4()),
        "alert_type": alert_type,
        "user_id": FAKE_USER_ID,
        "elevated_by": "wallet",
        "severity": severity,
        "details": {"current_roles": ["user"], "requested_roles": ["admin"]},
        "timestamp": datetime.now(UTC).isoformat(),
        "ip_address": "127.0.0.1",
        "user_agent": "TestAgent/1.0",
    }


def _fake_admin():
    """Return a mock admin user."""
    admin = MagicMock()
    admin.id = FAKE_ADMIN_ID
    admin.email = "admin@example.com"
    admin.username = "admin"
    admin.tier = "enterprise"
    admin.roles = ["admin"]
    admin.permissions = ["manage_security"]
    admin.is_admin = True
    admin.is_super_admin = False
    admin.wallet_addresses = []
    return admin


def _fake_application():
    """Return a mock application."""
    app = MagicMock()
    app.id = FAKE_APP_ID
    app.name = "Test App"
    return app


def _create_test_app():
    """Create a FastAPI test app with security router and overridden deps."""
    app = FastAPI()

    settings = MagicMock()
    settings.jwt_secret = "test-secret"
    app.state.settings = settings

    install_error_handlers(app)
    app.include_router(security_router)

    mock_db = AsyncMock()

    async def override_db_session():
        yield mock_db

    app.dependency_overrides[get_db_session] = override_db_session
    app.dependency_overrides[get_application] = _fake_application
    app.dependency_overrides[get_current_user] = _fake_admin
    app.dependency_overrides[require_admin_user] = _fake_admin

    return app


@pytest.fixture
def test_app():
    return _create_test_app()


@pytest.fixture
async def client(test_app):
    transport = ASGITransport(app=test_app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


# ===========================================================================
# GET /security/alerts
# ===========================================================================


class TestGetAlerts:
    @patch(f"{_SECURITY_SERVICE}.get_alerts", new_callable=AsyncMock)
    async def test_success(self, mock_get, client: AsyncClient):
        """GET /security/alerts returns alerts and total count."""
        mock_get.return_value = {
            "alerts": [_fake_alert()],
            "total": 1,
        }

        resp = await client.get("/security/alerts")

        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 1
        assert len(data["alerts"]) == 1
        assert data["alerts"][0]["alert_type"] == "privilege_escalation"

    @patch(f"{_SECURITY_SERVICE}.get_alerts", new_callable=AsyncMock)
    async def test_empty_result(self, mock_get, client: AsyncClient):
        """GET /security/alerts returns empty list when no alerts."""
        mock_get.return_value = {"alerts": [], "total": 0}

        resp = await client.get("/security/alerts")

        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 0
        assert data["alerts"] == []

    @patch(f"{_SECURITY_SERVICE}.get_alerts", new_callable=AsyncMock)
    async def test_with_alert_type_filter(self, mock_get, client: AsyncClient):
        """GET /security/alerts with alert_type filter."""
        mock_get.return_value = {
            "alerts": [_fake_alert(alert_type="suspicious_login")],
            "total": 1,
        }

        resp = await client.get(
            "/security/alerts", params={"alert_type": "suspicious_login"}
        )

        assert resp.status_code == 200
        mock_get.assert_called_once()

    @patch(f"{_SECURITY_SERVICE}.get_alerts", new_callable=AsyncMock)
    async def test_with_severity_filter(self, mock_get, client: AsyncClient):
        """GET /security/alerts with severity filter."""
        mock_get.return_value = {
            "alerts": [_fake_alert(severity="critical")],
            "total": 1,
        }

        resp = await client.get(
            "/security/alerts", params={"severity": "critical"}
        )

        assert resp.status_code == 200

    @patch(f"{_SECURITY_SERVICE}.get_alerts", new_callable=AsyncMock)
    async def test_with_limit(self, mock_get, client: AsyncClient):
        """GET /security/alerts with custom limit."""
        mock_get.return_value = {"alerts": [], "total": 0}

        resp = await client.get(
            "/security/alerts", params={"limit": 10}
        )

        assert resp.status_code == 200

    async def test_invalid_limit_returns_400(self, client: AsyncClient):
        """GET /security/alerts with invalid limit returns 400."""
        resp = await client.get("/security/alerts", params={"limit": 0})
        assert resp.status_code == 400

    @patch(f"{_SECURITY_SERVICE}.get_alerts", new_callable=AsyncMock)
    async def test_with_all_filters(self, mock_get, client: AsyncClient):
        """GET /security/alerts with all filter params."""
        mock_get.return_value = {"alerts": [], "total": 0}

        resp = await client.get(
            "/security/alerts",
            params={
                "alert_type": "privilege_escalation",
                "severity": "high",
                "limit": 100,
            },
        )

        assert resp.status_code == 200


# ===========================================================================
# GET /security/summary
# ===========================================================================


class TestGetSummary:
    @patch(f"{_SECURITY_SERVICE}.get_summary", new_callable=AsyncMock)
    async def test_success(self, mock_summary, client: AsyncClient):
        """GET /security/summary returns counts by type and severity."""
        mock_summary.return_value = {
            "total": 5,
            "by_type": [
                {"alert_type": "privilege_escalation", "count": 3},
                {"alert_type": "suspicious_login", "count": 2},
            ],
            "by_severity": [
                {"severity": "high", "count": 3},
                {"severity": "medium", "count": 2},
            ],
            "window_hours": 24,
        }

        resp = await client.get("/security/summary")

        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 5
        assert len(data["by_type"]) == 2
        assert len(data["by_severity"]) == 2
        assert data["window_hours"] == 24

    @patch(f"{_SECURITY_SERVICE}.get_summary", new_callable=AsyncMock)
    async def test_empty_summary(self, mock_summary, client: AsyncClient):
        """GET /security/summary returns zeros when no alerts."""
        mock_summary.return_value = {
            "total": 0,
            "by_type": [],
            "by_severity": [],
            "window_hours": 24,
        }

        resp = await client.get("/security/summary")

        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 0

    @patch(f"{_SECURITY_SERVICE}.get_summary", new_callable=AsyncMock)
    async def test_custom_hours(self, mock_summary, client: AsyncClient):
        """GET /security/summary with custom hours window."""
        mock_summary.return_value = {
            "total": 10,
            "by_type": [],
            "by_severity": [],
            "window_hours": 72,
        }

        resp = await client.get("/security/summary", params={"hours": 72})

        assert resp.status_code == 200
        data = resp.json()
        assert data["window_hours"] == 72

    async def test_invalid_hours_returns_400(self, client: AsyncClient):
        """GET /security/summary with hours=0 returns 400."""
        resp = await client.get("/security/summary", params={"hours": 0})
        assert resp.status_code == 400

    async def test_hours_too_large_returns_400(self, client: AsyncClient):
        """GET /security/summary with hours > 720 returns 400."""
        resp = await client.get("/security/summary", params={"hours": 721})
        assert resp.status_code == 400
