"""Unit tests for the CFO domain repository (data access layer).

Tests exercise repository functions with mocked AsyncSession. These
tests validate correct SQLAlchemy query construction and model handling
without requiring a real database.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

from spaps_server_quickstart.domains.cfo import repository as repo
from spaps_server_quickstart.domains.cfo.models import (
    CfoAuthCode,
    CfoConnection,
    CfoMagicLink,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _mock_scalar_result(value):
    """Create a mock result that returns value from scalar_one_or_none."""
    result = MagicMock()
    result.scalar_one_or_none.return_value = value
    result.scalar.return_value = value
    return result


def _mock_scalars_result(values):
    """Create a mock result that returns values from scalars().all()."""
    result = MagicMock()
    scalars = MagicMock()
    scalars.all.return_value = values
    scalars.first.return_value = values[0] if values else None
    result.scalars.return_value = scalars
    return result


# ===========================================================================
# get_connection_by_id
# ===========================================================================


class TestGetConnectionById:
    async def test_found(self):
        """get_connection_by_id returns connection when found."""
        conn = MagicMock(spec=CfoConnection)
        conn.id = uuid4()

        db = AsyncMock()
        db.execute.return_value = _mock_scalar_result(conn)

        result = await repo.get_connection_by_id(db, conn.id)

        assert result is conn
        db.execute.assert_called_once()

    async def test_not_found(self):
        """get_connection_by_id returns None when not found."""
        db = AsyncMock()
        db.execute.return_value = _mock_scalar_result(None)

        result = await repo.get_connection_by_id(db, uuid4())

        assert result is None


# ===========================================================================
# list_connections
# ===========================================================================


class TestListConnections:
    async def test_all_connections(self):
        """list_connections returns all connections when no filter."""
        conn1 = MagicMock(spec=CfoConnection)
        conn2 = MagicMock(spec=CfoConnection)

        db = AsyncMock()
        db.execute.return_value = _mock_scalars_result([conn1, conn2])

        result = await repo.list_connections(db)

        assert len(result) == 2
        db.execute.assert_called_once()

    async def test_filtered_by_user_id(self):
        """list_connections filters by user_id when provided."""
        conn = MagicMock(spec=CfoConnection)

        db = AsyncMock()
        db.execute.return_value = _mock_scalars_result([conn])

        user_id = uuid4()
        result = await repo.list_connections(db, user_id=user_id)

        assert len(result) == 1
        db.execute.assert_called_once()


# ===========================================================================
# create_connection
# ===========================================================================


class TestCreateConnection:
    async def test_creates_and_returns(self):
        """create_connection adds model to session, flushes, and returns."""
        db = AsyncMock()
        db.add = MagicMock()  # add() is synchronous in SQLAlchemy

        # Make refresh set the id on the model
        async def fake_refresh(obj):
            if not hasattr(obj, "id") or obj.id is None:
                obj.id = uuid4()

        db.refresh = fake_refresh

        result = await repo.create_connection(
            db,
            client_name="Test Client",
            status="pending",
        )

        assert result is not None
        assert isinstance(result, CfoConnection)
        db.add.assert_called_once()
        db.flush.assert_called_once()


# ===========================================================================
# update_connection
# ===========================================================================


class TestUpdateConnection:
    async def test_updates_existing(self):
        """update_connection updates attributes on existing connection."""
        conn = MagicMock(spec=CfoConnection)
        conn.id = uuid4()
        conn.status = "pending"

        db = AsyncMock()
        db.execute.return_value = _mock_scalar_result(conn)

        result = await repo.update_connection(
            db,
            conn.id,
            status="connected",
            company_name="New Name",
        )

        assert result is conn
        db.flush.assert_called_once()
        db.refresh.assert_called_once()

    async def test_returns_none_for_missing(self):
        """update_connection returns None if connection not found."""
        db = AsyncMock()
        db.execute.return_value = _mock_scalar_result(None)

        result = await repo.update_connection(
            db,
            uuid4(),
            status="connected",
        )

        assert result is None


# ===========================================================================
# find_user_primary_connection
# ===========================================================================


class TestFindUserPrimaryConnection:
    async def test_found(self):
        """find_user_primary_connection returns the most recent active."""
        conn = MagicMock(spec=CfoConnection)

        db = AsyncMock()
        db.execute.return_value = _mock_scalar_result(conn)

        user_id = uuid4()
        result = await repo.find_user_primary_connection(db, user_id)

        assert result is conn

    async def test_not_found(self):
        """find_user_primary_connection returns None for no connections."""
        db = AsyncMock()
        db.execute.return_value = _mock_scalar_result(None)

        result = await repo.find_user_primary_connection(db, uuid4())

        assert result is None


# ===========================================================================
# count_user_connections
# ===========================================================================


class TestCountUserConnections:
    async def test_count(self):
        """count_user_connections returns correct count."""
        db = AsyncMock()
        db.execute.return_value = _mock_scalar_result(2)

        result = await repo.count_user_connections(db, uuid4())

        assert result == 2

    async def test_zero(self):
        """count_user_connections returns 0 for no connections."""
        db = AsyncMock()
        db.execute.return_value = _mock_scalar_result(0)

        result = await repo.count_user_connections(db, uuid4())

        assert result == 0


# ===========================================================================
# Magic link operations
# ===========================================================================


class TestMagicLinkOperations:
    async def test_create_magic_link(self):
        """create_magic_link adds and returns a CfoMagicLink."""
        db = AsyncMock()
        db.add = MagicMock()  # add() is synchronous in SQLAlchemy

        async def fake_refresh(obj):
            if not hasattr(obj, "id") or obj.id is None:
                obj.id = uuid4()

        db.refresh = fake_refresh

        result = await repo.create_magic_link(
            db,
            token="test-token",
            client_name="Test Client",
            connection_id=uuid4(),
            expires_at=datetime.now(UTC) + timedelta(hours=24),
        )

        assert result is not None
        assert isinstance(result, CfoMagicLink)
        db.add.assert_called_once()
        db.flush.assert_called_once()

    async def test_get_magic_link_by_token_found(self):
        """get_magic_link_by_token returns link when found."""
        link = MagicMock(spec=CfoMagicLink)
        link.token = "test-token"

        db = AsyncMock()
        db.execute.return_value = _mock_scalar_result(link)

        result = await repo.get_magic_link_by_token(db, "test-token")

        assert result is link

    async def test_get_magic_link_by_token_not_found(self):
        """get_magic_link_by_token returns None when not found."""
        db = AsyncMock()
        db.execute.return_value = _mock_scalar_result(None)

        result = await repo.get_magic_link_by_token(db, "unknown")

        assert result is None

    async def test_mark_magic_link_used(self):
        """mark_magic_link_used executes update statement."""
        db = AsyncMock()

        await repo.mark_magic_link_used(db, uuid4())

        db.execute.assert_called_once()
        db.flush.assert_called_once()


# ===========================================================================
# Auth code operations
# ===========================================================================


class TestAuthCodeOperations:
    async def test_create_auth_code(self):
        """create_auth_code adds and returns a CfoAuthCode."""
        db = AsyncMock()
        db.add = MagicMock()  # add() is synchronous in SQLAlchemy

        async def fake_refresh(obj):
            if not hasattr(obj, "id") or obj.id is None:
                obj.id = uuid4()

        db.refresh = fake_refresh

        result = await repo.create_auth_code(
            db,
            code="a" * 64,
            user_id=uuid4(),
            company_name="Acme",
            realm_id="123",
            expires_at=datetime.now(UTC) + timedelta(minutes=5),
        )

        assert result is not None
        assert isinstance(result, CfoAuthCode)
        db.add.assert_called_once()
        db.flush.assert_called_once()

    async def test_get_auth_code_by_code_found(self):
        """get_auth_code_by_code returns code when found."""
        code = MagicMock(spec=CfoAuthCode)
        code.code = "a" * 64

        db = AsyncMock()
        db.execute.return_value = _mock_scalar_result(code)

        result = await repo.get_auth_code_by_code(db, "a" * 64)

        assert result is code

    async def test_get_auth_code_by_code_not_found(self):
        """get_auth_code_by_code returns None when not found."""
        db = AsyncMock()
        db.execute.return_value = _mock_scalar_result(None)

        result = await repo.get_auth_code_by_code(db, "b" * 64)

        assert result is None

    async def test_mark_auth_code_used(self):
        """mark_auth_code_used executes update statement."""
        db = AsyncMock()

        await repo.mark_auth_code_used(db, uuid4())

        db.execute.assert_called_once()
        db.flush.assert_called_once()
