"""Unit tests for the wallets domain routers (Solana + Ethereum).

Creates a test FastAPI app with both routers mounted and exercises all
endpoints, overriding ``get_application``, ``get_current_user``,
``get_db_session``, and ``get_settings`` dependencies.

Covers happy paths and error cases for all Solana (6) and Ethereum (9) endpoints.
"""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from spaps_server_quickstart.domains.wallets.router import (
    ethereum_router,
    solana_router,
)
from spaps_server_quickstart.middleware.error_handler import install_error_handlers
from spaps_server_quickstart.middleware.spaps_deps import (
    get_application,
    get_current_user,
    get_db_session,
    get_settings,
)


# ---------------------------------------------------------------------------
# Helpers / Constants
# ---------------------------------------------------------------------------

FAKE_USER_ID = str(uuid4())
FAKE_WALLET_ADDRESS = "HVEbdiYU3Rr34NHBSgKs7q8cvdTeZLqNL77Z1FB2vjLy"
FAKE_ETH_ADDRESS = "0xa72bb7CeF1e4B2Cc144373d8dE0Add7CCc8DF4Ba"
FAKE_CONTRACT_ADDRESS = "0x1234567890abcdef1234567890abcdef12345678"
FAKE_SIGNATURE = "fakesig123"
FAKE_MESSAGE = "SPAPS wants you to sign in"

_ROUTER = "spaps_server_quickstart.domains.wallets.router.service"


def _fake_user():
    """Return a mock authenticated user."""
    user = MagicMock()
    user.id = FAKE_USER_ID
    user.email = "test@example.com"
    user.username = None
    user.tier = "basic"
    user.roles = ["user"]
    user.permissions = ["view_products"]
    user.is_admin = False
    user.is_super_admin = False
    user.wallet_addresses = [FAKE_WALLET_ADDRESS]
    return user


def _fake_application():
    """Return a mock application."""
    app = MagicMock()
    app.id = uuid4()
    app.name = "Test App"
    return app


def _fake_settings():
    """Return a mock SPAPS settings object."""
    settings = MagicMock()
    settings.jwt_secret = "test-jwt-secret-at-least-32-chars"
    settings.refresh_token_secret = "test-refresh-secret-at-least-32-chars"
    settings.jwt_expires_in = "1h"
    settings.jwt_refresh_expires_in = "365d"
    settings.ethereum_rpc_url = "https://fake-rpc.example.com"
    settings.is_spaps_local_mode = True
    return settings


def _sign_in_result() -> dict:
    """Return a realistic sign-in service result."""
    return {
        "user": {
            "id": FAKE_USER_ID,
            "email": None,
            "username": None,
            "tier": "basic",
            "roles": ["user"],
            "is_admin": False,
            "is_super_admin": False,
        },
        "wallet": {
            "id": str(uuid4()),
            "wallet_address": FAKE_WALLET_ADDRESS,
            "chain_type": "solana",
            "is_primary": True,
            "verified_at": datetime.now(UTC).isoformat(),
            "created_at": datetime.now(UTC).isoformat(),
        },
        "session": {
            "access_token": "fake.access.token",
            "refresh_token": "fake.refresh.token",
            "expires_in": 3600,
            "token_type": "Bearer",
        },
    }


def _link_wallet_result() -> dict:
    """Return a realistic link-wallet service result."""
    return {
        "user": {
            "id": FAKE_USER_ID,
            "email": "test@example.com",
            "username": None,
            "tier": "basic",
            "roles": ["user"],
            "is_admin": False,
            "is_super_admin": False,
        },
        "wallet": {
            "id": str(uuid4()),
            "wallet_address": FAKE_WALLET_ADDRESS,
            "chain_type": "solana",
            "is_primary": False,
            "verified_at": datetime.now(UTC).isoformat(),
            "created_at": datetime.now(UTC).isoformat(),
        },
    }


def _verify_sig_result() -> dict:
    return {
        "valid": True,
        "wallet_address": FAKE_WALLET_ADDRESS,
        "timestamp": datetime.now(UTC).isoformat(),
    }


def _wallets_list_result() -> dict:
    return {
        "wallets": [
            {
                "id": str(uuid4()),
                "wallet_address": FAKE_WALLET_ADDRESS,
                "chain_type": "solana",
                "is_primary": True,
                "verified_at": datetime.now(UTC).isoformat(),
                "created_at": datetime.now(UTC).isoformat(),
            }
        ],
        "count": 1,
    }


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def test_app():
    """Create a FastAPI app with wallet routers and dependency overrides."""
    app = FastAPI()
    install_error_handlers(app)
    app.include_router(solana_router)
    app.include_router(ethereum_router)

    # Override dependencies
    mock_session = AsyncMock()

    async def override_db_session():
        yield mock_session

    app.dependency_overrides[get_db_session] = override_db_session
    app.dependency_overrides[get_application] = _fake_application
    app.dependency_overrides[get_current_user] = _fake_user
    app.dependency_overrides[get_settings] = _fake_settings

    return app


@pytest.fixture
async def client(test_app):
    """Async HTTP client for the test app."""
    transport = ASGITransport(app=test_app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


# ===========================================================================
# Solana router tests
# ===========================================================================


class TestSolanaSignIn:
    @patch(_ROUTER)
    async def test_success(self, mock_svc, client: AsyncClient):
        """POST /solana/sign-in returns 200 with user, wallet, session."""
        mock_svc.verify_and_sign_in = AsyncMock(return_value=_sign_in_result())

        response = await client.post(
            "/auth/solana/sign-in",
            json={
                "wallet_address": FAKE_WALLET_ADDRESS,
                "signature": FAKE_SIGNATURE,
                "message": FAKE_MESSAGE,
            },
        )

        assert response.status_code == 200
        data = response.json()
        assert "user" in data
        assert "wallet" in data
        assert "session" in data
        assert data["session"]["access_token"] == "fake.access.token"

    @patch(_ROUTER)
    async def test_invalid_signature_returns_401(
        self, mock_svc, client: AsyncClient
    ):
        """POST /solana/sign-in returns 401 for invalid signature."""
        from spaps_server_quickstart.domains.errors import InvalidSignatureError

        mock_svc.verify_and_sign_in = AsyncMock(
            side_effect=InvalidSignatureError("Bad sig")
        )

        response = await client.post(
            "/auth/solana/sign-in",
            json={
                "wallet_address": FAKE_WALLET_ADDRESS,
                "signature": "bad",
                "message": FAKE_MESSAGE,
            },
        )

        # Domain errors are typically caught by error handler middleware
        assert response.status_code == 401

    async def test_missing_fields_returns_422(self, client: AsyncClient):
        """POST /solana/sign-in returns 422 for missing fields."""
        response = await client.post("/auth/solana/sign-in", json={})

        assert response.status_code == 400


class TestSolanaLinkWallet:
    @patch(_ROUTER)
    async def test_success(self, mock_svc, client: AsyncClient):
        """POST /solana/link-wallet returns 200 with user+wallet."""
        mock_svc.link_wallet_to_user = AsyncMock(
            return_value=_link_wallet_result()
        )

        response = await client.post(
            "/auth/solana/link-wallet",
            json={
                "wallet_address": FAKE_WALLET_ADDRESS,
                "signature": FAKE_SIGNATURE,
                "message": FAKE_MESSAGE,
            },
        )

        assert response.status_code == 200
        data = response.json()
        assert "user" in data
        assert "wallet" in data

    async def test_missing_fields_returns_422(self, client: AsyncClient):
        """POST /solana/link-wallet returns 422 for missing fields."""
        response = await client.post("/auth/solana/link-wallet", json={})

        assert response.status_code == 400


class TestSolanaVerifySignature:
    @patch(_ROUTER)
    async def test_success(self, mock_svc, client: AsyncClient):
        """POST /solana/verify-signature returns 200 with valid=True."""
        mock_svc.verify_signature = MagicMock(return_value=_verify_sig_result())

        response = await client.post(
            "/auth/solana/verify-signature",
            json={
                "wallet_address": FAKE_WALLET_ADDRESS,
                "signature": FAKE_SIGNATURE,
                "message": FAKE_MESSAGE,
            },
        )

        assert response.status_code == 200
        data = response.json()
        assert data["valid"] is True
        assert data["wallet_address"] == FAKE_WALLET_ADDRESS

    @patch(_ROUTER)
    async def test_invalid_signature(self, mock_svc, client: AsyncClient):
        """POST /solana/verify-signature returns valid=False."""
        mock_svc.verify_signature = MagicMock(
            return_value={
                "valid": False,
                "wallet_address": FAKE_WALLET_ADDRESS,
                "timestamp": datetime.now(UTC).isoformat(),
            }
        )

        response = await client.post(
            "/auth/solana/verify-signature",
            json={
                "wallet_address": FAKE_WALLET_ADDRESS,
                "signature": "bad",
                "message": FAKE_MESSAGE,
            },
        )

        assert response.status_code == 200
        assert response.json()["valid"] is False


class TestSolanaVerifyOwnership:
    @patch(_ROUTER)
    async def test_success(self, mock_svc, client: AsyncClient):
        """POST /solana/verify-ownership returns 200 with verified=True."""
        mock_svc.verify_wallet_ownership = AsyncMock(
            return_value={
                "verified": True,
                "wallet_address": FAKE_WALLET_ADDRESS,
                "verification_timestamp": datetime.now(UTC).isoformat(),
            }
        )

        response = await client.post(
            "/auth/solana/verify-ownership",
            json={
                "wallet_address": FAKE_WALLET_ADDRESS,
                "signature": FAKE_SIGNATURE,
                "message": FAKE_MESSAGE,
            },
        )

        assert response.status_code == 200
        data = response.json()
        assert data["verified"] is True

    @patch(_ROUTER)
    async def test_not_linked_returns_404(self, mock_svc, client: AsyncClient):
        """POST /solana/verify-ownership returns 404 when not linked."""
        from spaps_server_quickstart.domains.errors import NotFoundError

        mock_svc.verify_wallet_ownership = AsyncMock(
            side_effect=NotFoundError("Wallet is not linked")
        )

        response = await client.post(
            "/auth/solana/verify-ownership",
            json={
                "wallet_address": FAKE_WALLET_ADDRESS,
                "signature": FAKE_SIGNATURE,
                "message": FAKE_MESSAGE,
            },
        )

        assert response.status_code == 404


class TestSolanaGenerateMessage:
    @patch(_ROUTER)
    async def test_success(self, mock_svc, client: AsyncClient):
        """GET /solana/generate-message returns 200 with message."""
        mock_svc.generate_auth_message_for_wallet = AsyncMock(
            return_value={
                "message": "Sign this nonce: abc123",
                "wallet_address": FAKE_WALLET_ADDRESS,
                "timestamp": datetime.now(UTC).isoformat(),
            }
        )

        response = await client.get(
            f"/auth/solana/generate-message/{FAKE_WALLET_ADDRESS}",
            params={"nonce": "abc123"},
        )

        assert response.status_code == 200
        data = response.json()
        assert "message" in data
        assert data["wallet_address"] == FAKE_WALLET_ADDRESS

    async def test_missing_wallet_address_returns_422(
        self, client: AsyncClient
    ):
        """GET /solana/generate-message/{wallet_address} returns 422 without nonce."""
        response = await client.get(f"/auth/solana/generate-message/{FAKE_WALLET_ADDRESS}")

        assert response.status_code == 400


class TestSolanaListWallets:
    @patch(_ROUTER)
    async def test_success(self, mock_svc, client: AsyncClient):
        """GET /solana/wallets returns 200 with wallet list."""
        mock_svc.get_user_wallets = AsyncMock(
            return_value=_wallets_list_result()
        )

        response = await client.get("/auth/solana/wallets")

        assert response.status_code == 200
        data = response.json()
        assert data["count"] == 1
        assert len(data["wallets"]) == 1

    @patch(_ROUTER)
    async def test_empty_wallets(self, mock_svc, client: AsyncClient):
        """GET /solana/wallets returns empty list."""
        mock_svc.get_user_wallets = AsyncMock(
            return_value={"wallets": [], "count": 0}
        )

        response = await client.get("/auth/solana/wallets")

        assert response.status_code == 200
        assert response.json()["count"] == 0


# ===========================================================================
# Ethereum router tests
# ===========================================================================


class TestEthereumSignIn:
    @patch(_ROUTER)
    async def test_success(self, mock_svc, client: AsyncClient):
        """POST /ethereum/sign-in returns 200 with user, wallet, session."""
        result = _sign_in_result()
        result["wallet"]["chain_type"] = "ethereum"
        result["wallet"]["wallet_address"] = FAKE_ETH_ADDRESS
        mock_svc.verify_and_sign_in = AsyncMock(return_value=result)

        response = await client.post(
            "/auth/ethereum/sign-in",
            json={
                "wallet_address": FAKE_ETH_ADDRESS,
                "signature": FAKE_SIGNATURE,
                "message": FAKE_MESSAGE,
            },
        )

        assert response.status_code == 200
        data = response.json()
        assert "user" in data
        assert "session" in data

    async def test_missing_fields_returns_422(self, client: AsyncClient):
        """POST /ethereum/sign-in returns 422 for missing fields."""
        response = await client.post("/auth/ethereum/sign-in", json={})

        assert response.status_code == 400


class TestEthereumLinkWallet:
    @patch(_ROUTER)
    async def test_success(self, mock_svc, client: AsyncClient):
        """POST /ethereum/link-wallet returns 200."""
        result = _link_wallet_result()
        result["wallet"]["chain_type"] = "ethereum"
        mock_svc.link_wallet_to_user = AsyncMock(return_value=result)

        response = await client.post(
            "/auth/ethereum/link-wallet",
            json={
                "wallet_address": FAKE_ETH_ADDRESS,
                "signature": FAKE_SIGNATURE,
                "message": FAKE_MESSAGE,
            },
        )

        assert response.status_code == 200
        data = response.json()
        assert "wallet" in data


class TestEthereumVerifySignature:
    @patch(_ROUTER)
    async def test_success(self, mock_svc, client: AsyncClient):
        """POST /ethereum/verify-signature returns 200 with signature_type."""
        mock_svc.verify_signature = MagicMock(
            return_value={
                "valid": True,
                "wallet_address": FAKE_ETH_ADDRESS,
                "timestamp": datetime.now(UTC).isoformat(),
            }
        )

        response = await client.post(
            "/auth/ethereum/verify-signature",
            json={
                "wallet_address": FAKE_ETH_ADDRESS,
                "signature": FAKE_SIGNATURE,
                "message": FAKE_MESSAGE,
            },
        )

        assert response.status_code == 200
        data = response.json()
        assert data["valid"] is True
        assert data["signature_type"] == "EIP-191"

    @patch(_ROUTER)
    async def test_invalid_signature(self, mock_svc, client: AsyncClient):
        """POST /ethereum/verify-signature returns valid=False."""
        mock_svc.verify_signature = MagicMock(
            return_value={
                "valid": False,
                "wallet_address": FAKE_ETH_ADDRESS,
                "timestamp": datetime.now(UTC).isoformat(),
            }
        )

        response = await client.post(
            "/auth/ethereum/verify-signature",
            json={
                "wallet_address": FAKE_ETH_ADDRESS,
                "signature": "bad",
                "message": FAKE_MESSAGE,
            },
        )

        assert response.status_code == 200
        assert response.json()["valid"] is False


class TestEthereumVerifyTypedData:
    @patch(_ROUTER)
    async def test_success(self, mock_svc, client: AsyncClient):
        """POST /ethereum/verify-typed-data returns 200 with EIP-712 metadata."""
        domain = {"name": "SPAPS", "version": "1", "chainId": 1}
        mock_svc.verify_typed_data = MagicMock(
            return_value={
                "valid": True,
                "wallet_address": FAKE_ETH_ADDRESS,
                "signature_type": "EIP-712",
                "domain": domain,
                "timestamp": datetime.now(UTC).isoformat(),
            }
        )

        response = await client.post(
            "/auth/ethereum/verify-typed-data",
            json={
                "wallet_address": FAKE_ETH_ADDRESS,
                "signature": FAKE_SIGNATURE,
                "domain": domain,
                "types": {"Auth": [{"name": "wallet", "type": "address"}]},
                "value": {"wallet": FAKE_ETH_ADDRESS},
            },
        )

        assert response.status_code == 200
        data = response.json()
        assert data["valid"] is True
        assert data["signature_type"] == "EIP-712"

    async def test_missing_fields_returns_422(self, client: AsyncClient):
        """POST /ethereum/verify-typed-data returns 422 for missing fields."""
        response = await client.post(
            "/auth/ethereum/verify-typed-data",
            json={"wallet_address": FAKE_ETH_ADDRESS},
        )

        assert response.status_code == 400


class TestEthereumGenerateMessage:
    @patch(_ROUTER)
    async def test_success(self, mock_svc, client: AsyncClient):
        """GET /ethereum/generate-message returns 200 with EIP-191 message."""
        mock_svc.generate_auth_message_for_wallet = AsyncMock(
            return_value={
                "message": "Sign this: nonce123",
                "wallet_address": FAKE_ETH_ADDRESS,
                "timestamp": datetime.now(UTC).isoformat(),
            }
        )

        response = await client.get(
            f"/auth/ethereum/generate-message/{FAKE_ETH_ADDRESS}",
            params={"nonce": "nonce123"},
        )

        assert response.status_code == 200
        data = response.json()
        assert data["signature_type"] == "EIP-191"
        assert data["wallet_address"] == FAKE_ETH_ADDRESS

    async def test_missing_wallet_returns_422(self, client: AsyncClient):
        """GET /ethereum/generate-message/{wallet_address} returns 422 without nonce."""
        response = await client.get(f"/auth/ethereum/generate-message/{FAKE_ETH_ADDRESS}")

        assert response.status_code == 400


class TestEthereumGenerateTypedData:
    @patch(_ROUTER)
    async def test_success(self, mock_svc, client: AsyncClient):
        """GET /ethereum/generate-typed-data returns 200 with EIP-712 data."""
        mock_svc.generate_typed_data_message = AsyncMock(
            return_value={
                "domain": {"name": "SPAPS", "version": "1", "chainId": 1},
                "types": {
                    "Authentication": [
                        {"name": "wallet", "type": "address"},
                        {"name": "nonce", "type": "string"},
                    ]
                },
                "primaryType": "Authentication",
                "message": {
                    "wallet": FAKE_ETH_ADDRESS,
                    "nonce": "abc123",
                    "timestamp": datetime.now(UTC).isoformat(),
                },
                "wallet_address": FAKE_ETH_ADDRESS,
                "signature_type": "EIP-712",
                "timestamp": datetime.now(UTC).isoformat(),
            }
        )

        response = await client.get(
            f"/auth/ethereum/generate-typed-data/{FAKE_ETH_ADDRESS}",
        )

        assert response.status_code == 200
        data = response.json()
        assert data["primaryType"] == "Authentication"
        assert data["domain"]["name"] == "SPAPS"
        assert data["wallet_address"] == FAKE_ETH_ADDRESS


class TestEthereumBalance:
    @patch(_ROUTER)
    async def test_success(self, mock_svc, client: AsyncClient):
        """GET /ethereum/balance returns 200 with balance info."""
        mock_svc.get_ethereum_balance = AsyncMock(
            return_value={
                "balance": "1.5",
                "wallet_address": FAKE_ETH_ADDRESS,
                "currency": "ETH",
            }
        )

        response = await client.get(
            f"/auth/ethereum/balance/{FAKE_ETH_ADDRESS}",
        )

        assert response.status_code == 200
        data = response.json()
        assert data["balance"] == "1.5"
        assert data["currency"] == "ETH"

    @patch(_ROUTER)
    async def test_rpc_error_returns_400(self, mock_svc, client: AsyncClient):
        """GET /ethereum/balance returns 400 when RPC fails."""
        from spaps_server_quickstart.domains.errors import ValidationError

        mock_svc.get_ethereum_balance = AsyncMock(
            side_effect=ValidationError("Ethereum RPC URL not configured")
        )

        response = await client.get(
            f"/auth/ethereum/balance/{FAKE_ETH_ADDRESS}",
        )

        assert response.status_code == 400


class TestEthereumContractCheck:
    @patch(_ROUTER)
    async def test_success(self, mock_svc, client: AsyncClient):
        """GET /ethereum/contract-check returns 200 with can_interact flag."""
        mock_svc.check_contract_interaction = AsyncMock(
            return_value={
                "can_interact": True,
                "wallet_address": FAKE_ETH_ADDRESS,
                "contract_address": FAKE_CONTRACT_ADDRESS,
            }
        )

        response = await client.get(
            f"/auth/ethereum/contract-check/{FAKE_ETH_ADDRESS}/{FAKE_CONTRACT_ADDRESS}",
        )

        assert response.status_code == 200
        data = response.json()
        assert data["can_interact"] is True
        assert data["contract_address"] == FAKE_CONTRACT_ADDRESS

    async def test_missing_params_returns_422(self, client: AsyncClient):
        """GET /ethereum/contract-check returns 404 without required path params."""
        response = await client.get("/auth/ethereum/contract-check")

        assert response.status_code == 404

    @patch(_ROUTER)
    async def test_cannot_interact(self, mock_svc, client: AsyncClient):
        """GET /ethereum/contract-check returns can_interact=False."""
        mock_svc.check_contract_interaction = AsyncMock(
            return_value={
                "can_interact": False,
                "wallet_address": FAKE_ETH_ADDRESS,
                "contract_address": FAKE_CONTRACT_ADDRESS,
            }
        )

        response = await client.get(
            f"/auth/ethereum/contract-check/{FAKE_ETH_ADDRESS}/{FAKE_CONTRACT_ADDRESS}",
        )

        assert response.status_code == 200
        assert response.json()["can_interact"] is False


class TestEthereumListWallets:
    @patch(_ROUTER)
    async def test_success(self, mock_svc, client: AsyncClient):
        """GET /ethereum/wallets returns 200 with wallet list."""
        mock_svc.get_user_wallets = AsyncMock(
            return_value={
                "wallets": [
                    {
                        "id": str(uuid4()),
                        "wallet_address": FAKE_ETH_ADDRESS,
                        "chain_type": "ethereum",
                        "is_primary": True,
                        "verified_at": datetime.now(UTC).isoformat(),
                        "created_at": datetime.now(UTC).isoformat(),
                    }
                ],
                "count": 1,
            }
        )

        response = await client.get("/auth/ethereum/wallets")

        assert response.status_code == 200
        data = response.json()
        assert data["count"] == 1
        assert len(data["wallets"]) == 1

    @patch(_ROUTER)
    async def test_empty_wallets(self, mock_svc, client: AsyncClient):
        """GET /ethereum/wallets returns empty list."""
        mock_svc.get_user_wallets = AsyncMock(
            return_value={"wallets": [], "count": 0}
        )

        response = await client.get("/auth/ethereum/wallets")

        assert response.status_code == 200
        assert response.json()["count"] == 0
