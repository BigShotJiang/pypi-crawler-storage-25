"""Unit tests for the wallets domain service layer.

Covers:
- verify_and_sign_in (full flow: sig verification, find-or-create, tokens)
- link_wallet_to_user (verify sig, check no dup, create wallet)
- verify_signature (pure verification, valid + invalid)
- verify_typed_data (EIP-712 verification)
- generate_auth_message_for_wallet (nonce generation + message creation)
- get_user_wallets (list response)
- verify_wallet_ownership (sig + ownership check)
"""

from __future__ import annotations

import sys
from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import UUID, uuid4

import pytest

from spaps_server_quickstart.domains.errors import (
    InvalidSignatureError,
    NotFoundError,
    ValidationError,
)
from spaps_server_quickstart.domains.wallets import service


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

FAKE_USER_ID = str(uuid4())
FAKE_WALLET_ID = str(uuid4())
FAKE_WALLET_ADDRESS = "HVEbdiYU3Rr34NHBSgKs7q8cvdTeZLqNL77Z1FB2vjLy"
FAKE_ETH_ADDRESS = "0xa72bb7CeF1e4B2Cc144373d8dE0Add7CCc8DF4Ba"
FAKE_SIGNATURE = "fakesignature123"
FAKE_NONCE = "a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2"
FAKE_MESSAGE = (
    "SPAPS wants you to sign in with your wallet:\n"
    f"{FAKE_WALLET_ADDRESS}\n"
    "\n"
    f"Nonce: {FAKE_NONCE}\n"
    "Timestamp: 2025-01-01T00:00:00+00:00\n"
    "Domain: sweetpotato.dev\n"
    "\n"
    "This request will not trigger a blockchain transaction "
    "or cost any gas fees."
)
ACCESS_SECRET = "test-access-secret-at-least-32-chars-long"
REFRESH_SECRET = "test-refresh-secret-at-least-32-chars"

_SVC = "spaps_server_quickstart.domains.wallets.service"


def _make_mock_wallet(
    wallet_id: str | None = None,
    user_id: str | None = None,
    wallet_address: str = FAKE_WALLET_ADDRESS,
    chain_type: str = "solana",
    is_primary: bool = False,
) -> MagicMock:
    """Create a mock wallet object."""
    wallet = MagicMock()
    wallet.id = UUID(wallet_id or FAKE_WALLET_ID)
    wallet.user_id = UUID(user_id or FAKE_USER_ID)
    wallet.wallet_address = wallet_address
    wallet.chain_type = chain_type
    wallet.is_primary = is_primary
    wallet.verified_at = datetime.now(UTC)
    wallet.created_at = datetime.now(UTC)
    wallet.updated_at = datetime.now(UTC)
    return wallet


def _make_mock_user(
    user_id: str | None = None,
    email: str | None = None,
    tier: str = "basic",
) -> MagicMock:
    """Create a mock user object."""
    user = MagicMock()
    user.id = UUID(user_id or FAKE_USER_ID)
    user.email = email
    user.username = None
    user.tier = tier
    user.last_sign_in_at = None
    return user


def _make_mock_token_pair() -> MagicMock:
    """Create a mock TokenPair."""
    tp = MagicMock()
    tp.access_token = "fake.access.token"
    tp.refresh_token = "fake.refresh.token"
    tp.expires_in = 3600
    tp.token_type = "Bearer"
    return tp


def _mock_session() -> AsyncMock:
    """Create a mock AsyncSession."""
    session = AsyncMock()
    session.add = MagicMock()
    session.flush = AsyncMock()
    session.refresh = AsyncMock()
    session.execute = AsyncMock()
    session.commit = AsyncMock()
    return session


# ---------------------------------------------------------------------------
# Tests: verify_and_sign_in
# ---------------------------------------------------------------------------


class TestVerifyAndSignIn:
    @patch(f"{_SVC}.validate_nonce", new_callable=AsyncMock)
    @patch(f"{_SVC}.generate_token_pair")
    @patch(f"{_SVC}.get_admin_permissions")
    @patch(f"{_SVC}.get_user_roles")
    @patch(f"{_SVC}.repository")
    @patch(f"{_SVC}.verify_wallet_signature")
    async def test_existing_user_sign_in(
        self,
        mock_verify,
        mock_repo,
        mock_get_roles,
        mock_get_perms,
        mock_gen_tokens,
        mock_validate_nonce,
    ):
        """Existing user signs in: finds wallet+user, generates tokens."""
        session = _mock_session()
        wallet = _make_mock_wallet()
        user = _make_mock_user()

        mock_verify.return_value = {"valid": True, "wallet_address": FAKE_WALLET_ADDRESS}
        mock_validate_nonce.return_value = True
        mock_repo.get_wallet_with_user = AsyncMock(return_value=(wallet, user))
        mock_get_roles.return_value = ["user"]
        mock_get_perms.return_value = ["view_products"]
        mock_gen_tokens.return_value = _make_mock_token_pair()

        result = await service.verify_and_sign_in(
            session,
            wallet_address=FAKE_WALLET_ADDRESS,
            signature=FAKE_SIGNATURE,
            message=FAKE_MESSAGE,
            chain_type="solana",
            access_secret=ACCESS_SECRET,
            refresh_secret=REFRESH_SECRET,
        )

        assert "user" in result
        assert "wallet" in result
        assert "session" in result
        assert result["session"]["access_token"] == "fake.access.token"
        assert result["session"]["refresh_token"] == "fake.refresh.token"
        assert result["session"]["token_type"] == "Bearer"

        mock_verify.assert_called_once_with(
            FAKE_WALLET_ADDRESS, FAKE_SIGNATURE, FAKE_MESSAGE, "solana"
        )
        mock_validate_nonce.assert_awaited_once_with(
            session, FAKE_WALLET_ADDRESS, FAKE_NONCE,
        )
        mock_repo.get_wallet_with_user.assert_awaited_once()
        session.flush.assert_awaited()

    @patch(f"{_SVC}.validate_nonce", new_callable=AsyncMock)
    @patch(f"{_SVC}.generate_token_pair")
    @patch(f"{_SVC}.get_admin_permissions")
    @patch(f"{_SVC}.get_user_roles")
    @patch(f"{_SVC}.repository")
    @patch(f"{_SVC}.verify_wallet_signature")
    async def test_new_user_sign_in(
        self,
        mock_verify,
        mock_repo,
        mock_get_roles,
        mock_get_perms,
        mock_gen_tokens,
        mock_validate_nonce,
    ):
        """New user signs in: creates user + wallet, generates tokens."""
        session = _mock_session()
        new_user = _make_mock_user()
        new_wallet = _make_mock_wallet()

        mock_verify.return_value = {"valid": True}
        mock_validate_nonce.return_value = True
        mock_repo.get_wallet_with_user = AsyncMock(return_value=(None, None))
        mock_repo.create_wallet = AsyncMock(return_value=new_wallet)
        mock_get_roles.return_value = ["user"]
        mock_get_perms.return_value = ["view_products"]
        mock_gen_tokens.return_value = _make_mock_token_pair()

        # When session.refresh is called on the new User, set its attributes
        async def fake_refresh(obj):
            if not hasattr(obj, "wallet_address"):
                # It is the User object
                obj.id = new_user.id
                obj.email = None
                obj.tier = "basic"

        session.refresh = AsyncMock(side_effect=fake_refresh)

        result = await service.verify_and_sign_in(
            session,
            wallet_address=FAKE_WALLET_ADDRESS,
            signature=FAKE_SIGNATURE,
            message=FAKE_MESSAGE,
            chain_type="solana",
            access_secret=ACCESS_SECRET,
            refresh_secret=REFRESH_SECRET,
        )

        assert "user" in result
        assert "wallet" in result
        assert "session" in result

        # User was created (session.add called with User)
        session.add.assert_called_once()
        mock_repo.create_wallet.assert_awaited_once()
        mock_validate_nonce.assert_awaited_once()

    @patch(f"{_SVC}.verify_wallet_signature")
    async def test_invalid_signature_raises(self, mock_verify):
        """Raises InvalidSignatureError when signature is invalid."""
        session = _mock_session()

        mock_verify.return_value = {
            "valid": False,
            "error": "Bad signature",
        }

        with pytest.raises(InvalidSignatureError, match="Bad signature"):
            await service.verify_and_sign_in(
                session,
                wallet_address=FAKE_WALLET_ADDRESS,
                signature="bad",
                message=FAKE_MESSAGE,
                chain_type="solana",
                access_secret=ACCESS_SECRET,
                refresh_secret=REFRESH_SECRET,
            )

    @patch(f"{_SVC}.validate_nonce", new_callable=AsyncMock)
    @patch(f"{_SVC}.generate_token_pair")
    @patch(f"{_SVC}.get_admin_permissions")
    @patch(f"{_SVC}.get_user_roles")
    @patch(f"{_SVC}.repository")
    @patch(f"{_SVC}.verify_wallet_signature")
    async def test_admin_user_detected(
        self,
        mock_verify,
        mock_repo,
        mock_get_roles,
        mock_get_perms,
        mock_gen_tokens,
        mock_validate_nonce,
    ):
        """Admin roles and permissions are passed to token generation."""
        session = _mock_session()
        wallet = _make_mock_wallet()
        user = _make_mock_user()

        mock_verify.return_value = {"valid": True}
        mock_validate_nonce.return_value = True
        mock_repo.get_wallet_with_user = AsyncMock(return_value=(wallet, user))
        mock_get_roles.return_value = ["admin", "super_admin"]
        mock_get_perms.return_value = ["access_admin", "access_super_admin"]
        mock_gen_tokens.return_value = _make_mock_token_pair()

        result = await service.verify_and_sign_in(
            session,
            wallet_address=FAKE_WALLET_ADDRESS,
            signature=FAKE_SIGNATURE,
            message=FAKE_MESSAGE,
            chain_type="solana",
            access_secret=ACCESS_SECRET,
            refresh_secret=REFRESH_SECRET,
        )

        # Verify roles/permissions were passed to generate_token_pair
        call_kwargs = mock_gen_tokens.call_args[1]
        assert call_kwargs["roles"] == ["admin", "super_admin"]
        assert call_kwargs["is_admin"] is True
        assert call_kwargs["is_super_admin"] is True

        # Verify user dict reflects admin status
        assert result["user"]["is_admin"] is True
        assert result["user"]["is_super_admin"] is True


# ---------------------------------------------------------------------------
# Tests: link_wallet_to_user
# ---------------------------------------------------------------------------


class TestLinkWalletToUser:
    @patch(f"{_SVC}.repository")
    @patch(f"{_SVC}.verify_wallet_signature")
    async def test_link_wallet_success(self, mock_verify, mock_repo):
        """Links a wallet after verifying the signature."""
        session = _mock_session()
        wallet = _make_mock_wallet()
        user = _make_mock_user()

        mock_verify.return_value = {"valid": True}
        mock_repo.get_wallet_by_address = AsyncMock(return_value=None)
        mock_repo.create_wallet = AsyncMock(return_value=wallet)

        # Mock the user lookup
        mock_user_result = MagicMock()
        mock_user_result.scalar_one_or_none.return_value = user
        session.execute.return_value = mock_user_result

        result = await service.link_wallet_to_user(
            session,
            user_id=FAKE_USER_ID,
            wallet_address=FAKE_WALLET_ADDRESS,
            signature=FAKE_SIGNATURE,
            message=FAKE_MESSAGE,
            chain_type="solana",
        )

        assert "user" in result
        assert "wallet" in result
        mock_repo.create_wallet.assert_awaited_once()
        session.flush.assert_awaited()

    @patch(f"{_SVC}.verify_wallet_signature")
    async def test_link_wallet_invalid_signature(self, mock_verify):
        """Raises InvalidSignatureError when sig is invalid."""
        session = _mock_session()

        mock_verify.return_value = {"valid": False, "error": "Bad sig"}

        with pytest.raises(InvalidSignatureError):
            await service.link_wallet_to_user(
                session,
                user_id=FAKE_USER_ID,
                wallet_address=FAKE_WALLET_ADDRESS,
                signature="bad",
                message=FAKE_MESSAGE,
                chain_type="solana",
            )

    @patch(f"{_SVC}.repository")
    @patch(f"{_SVC}.verify_wallet_signature")
    async def test_link_wallet_already_linked_same_user(
        self, mock_verify, mock_repo
    ):
        """Raises ValidationError when wallet is already linked to the same user."""
        session = _mock_session()
        existing = _make_mock_wallet(user_id=FAKE_USER_ID)

        mock_verify.return_value = {"valid": True}
        mock_repo.get_wallet_by_address = AsyncMock(return_value=existing)

        with pytest.raises(
            ValidationError, match="already linked to your account"
        ):
            await service.link_wallet_to_user(
                session,
                user_id=FAKE_USER_ID,
                wallet_address=FAKE_WALLET_ADDRESS,
                signature=FAKE_SIGNATURE,
                message=FAKE_MESSAGE,
                chain_type="solana",
            )

    @patch(f"{_SVC}.repository")
    @patch(f"{_SVC}.verify_wallet_signature")
    async def test_link_wallet_already_linked_other_user(
        self, mock_verify, mock_repo
    ):
        """Raises ValidationError when wallet belongs to another user."""
        session = _mock_session()
        other_user_id = str(uuid4())
        existing = _make_mock_wallet(user_id=other_user_id)

        mock_verify.return_value = {"valid": True}
        mock_repo.get_wallet_by_address = AsyncMock(return_value=existing)

        with pytest.raises(
            ValidationError, match="already linked to another user"
        ):
            await service.link_wallet_to_user(
                session,
                user_id=FAKE_USER_ID,
                wallet_address=FAKE_WALLET_ADDRESS,
                signature=FAKE_SIGNATURE,
                message=FAKE_MESSAGE,
                chain_type="solana",
            )


# ---------------------------------------------------------------------------
# Tests: verify_signature (pure, no DB)
# ---------------------------------------------------------------------------


class TestVerifySignature:
    @patch(f"{_SVC}.verify_wallet_signature")
    def test_valid_signature(self, mock_verify):
        """Returns valid=True with wallet_address and timestamp."""
        mock_verify.return_value = {"valid": True}

        result = service.verify_signature(
            FAKE_WALLET_ADDRESS, FAKE_SIGNATURE, FAKE_MESSAGE, "solana"
        )

        assert result["valid"] is True
        assert result["wallet_address"] == FAKE_WALLET_ADDRESS
        assert "timestamp" in result

    @patch(f"{_SVC}.verify_wallet_signature")
    def test_invalid_signature(self, mock_verify):
        """Returns valid=False when verification fails."""
        mock_verify.return_value = {"valid": False, "error": "Bad sig"}

        result = service.verify_signature(
            FAKE_WALLET_ADDRESS, "bad", FAKE_MESSAGE, "solana"
        )

        assert result["valid"] is False
        assert result["wallet_address"] == FAKE_WALLET_ADDRESS


# ---------------------------------------------------------------------------
# Tests: verify_typed_data
# ---------------------------------------------------------------------------


class TestVerifyTypedData:
    @patch(f"{_SVC}._verify_typed_data")
    def test_valid_typed_data(self, mock_verify):
        """Returns valid=True with EIP-712 metadata."""
        domain = {"name": "SPAPS", "version": "1", "chainId": 1}
        types = {"Auth": [{"name": "wallet", "type": "address"}]}
        value = {"wallet": FAKE_ETH_ADDRESS}

        mock_verify.return_value = {
            "valid": True,
            "wallet_address": FAKE_ETH_ADDRESS,
            "signature_type": "EIP-712",
            "timestamp": datetime.now(UTC).isoformat(),
        }

        result = service.verify_typed_data(
            FAKE_ETH_ADDRESS, FAKE_SIGNATURE, domain, types, value
        )

        assert result["valid"] is True
        assert result["wallet_address"] == FAKE_ETH_ADDRESS
        assert result["signature_type"] == "EIP-712"
        assert result["domain"] == domain
        assert "timestamp" in result

    @patch(f"{_SVC}._verify_typed_data")
    def test_invalid_typed_data(self, mock_verify):
        """Returns valid=False when EIP-712 verification fails."""
        domain = {"name": "SPAPS"}
        types = {"Auth": []}
        value = {}

        mock_verify.return_value = {"valid": False, "error": "Bad sig"}

        result = service.verify_typed_data(
            FAKE_ETH_ADDRESS, "bad", domain, types, value
        )

        assert result["valid"] is False


# ---------------------------------------------------------------------------
# Tests: generate_auth_message_for_wallet
# ---------------------------------------------------------------------------


class TestGenerateAuthMessageForWallet:
    @patch(f"{_SVC}.store_nonce", new_callable=AsyncMock)
    @patch(f"{_SVC}.create_auth_message")
    @patch(f"{_SVC}.generate_nonce")
    async def test_generates_message(
        self, mock_gen_nonce, mock_create_msg, mock_store_nonce
    ):
        """Generates nonce, creates message, stores nonce, returns result."""
        session = _mock_session()

        mock_gen_nonce.return_value = "abc123nonce"
        mock_create_msg.return_value = "Sign this message: abc123nonce"

        result = await service.generate_auth_message_for_wallet(
            session, FAKE_WALLET_ADDRESS, "solana"
        )

        assert result["message"] == "Sign this message: abc123nonce"
        assert result["wallet_address"] == FAKE_WALLET_ADDRESS
        assert "timestamp" in result

        mock_gen_nonce.assert_called_once()
        mock_create_msg.assert_called_once_with(FAKE_WALLET_ADDRESS, "abc123nonce")
        mock_store_nonce.assert_awaited_once_with(
            session, FAKE_WALLET_ADDRESS, "abc123nonce"
        )
        session.flush.assert_awaited()

    @patch(f"{_SVC}.store_nonce", new_callable=AsyncMock)
    @patch(f"{_SVC}.create_auth_message")
    @patch(f"{_SVC}.generate_nonce")
    async def test_uses_caller_provided_nonce(
        self, mock_gen_nonce, mock_create_msg, mock_store_nonce
    ):
        """Uses the caller-provided nonce instead of generating a new one."""
        session = _mock_session()
        mock_create_msg.return_value = "Sign this message: caller-nonce"

        result = await service.generate_auth_message_for_wallet(
            session, FAKE_WALLET_ADDRESS, "solana", nonce="caller-nonce"
        )

        assert result["message"] == "Sign this message: caller-nonce"
        mock_gen_nonce.assert_not_called()
        mock_create_msg.assert_called_once_with(FAKE_WALLET_ADDRESS, "caller-nonce")
        mock_store_nonce.assert_awaited_once_with(
            session, FAKE_WALLET_ADDRESS, "caller-nonce"
        )


# ---------------------------------------------------------------------------
# Tests: generate_typed_data_message
# ---------------------------------------------------------------------------


class TestGenerateTypedDataMessage:
    @patch(f"{_SVC}.store_nonce", new_callable=AsyncMock)
    @patch(f"{_SVC}.generate_nonce")
    async def test_generates_typed_data(self, mock_gen_nonce, mock_store_nonce):
        """Generates EIP-712 typed data with nonce."""
        session = _mock_session()
        mock_gen_nonce.return_value = "typed-nonce-abc"

        result = await service.generate_typed_data_message(
            session, FAKE_ETH_ADDRESS
        )

        assert result["domain"]["name"] == "SPAPS"
        assert result["domain"]["version"] == "1"
        assert result["domain"]["chainId"] == 1
        assert "Authentication" in result["types"]
        assert result["primaryType"] == "Authentication"
        assert result["message"]["wallet"] == FAKE_ETH_ADDRESS
        assert result["message"]["nonce"] == "typed-nonce-abc"
        assert result["signature_type"] == "EIP-712"
        assert result["wallet_address"] == FAKE_ETH_ADDRESS
        assert "timestamp" in result

        mock_store_nonce.assert_awaited_once()
        session.flush.assert_awaited()


# ---------------------------------------------------------------------------
# Tests: get_user_wallets
# ---------------------------------------------------------------------------


class TestGetUserWallets:
    @patch(f"{_SVC}.repository")
    async def test_returns_wallets_list(self, mock_repo):
        """Returns a list of serialized wallets with count."""
        session = _mock_session()
        w1 = _make_mock_wallet(wallet_id=str(uuid4()))
        w2 = _make_mock_wallet(wallet_id=str(uuid4()))

        mock_repo.get_wallets_for_user = AsyncMock(return_value=[w1, w2])

        result = await service.get_user_wallets(session, FAKE_USER_ID)

        assert result["count"] == 2
        assert len(result["wallets"]) == 2
        assert result["wallets"][0]["wallet_address"] == FAKE_WALLET_ADDRESS

    @patch(f"{_SVC}.repository")
    async def test_returns_empty_list(self, mock_repo):
        """Returns empty list when user has no wallets."""
        session = _mock_session()

        mock_repo.get_wallets_for_user = AsyncMock(return_value=[])

        result = await service.get_user_wallets(session, FAKE_USER_ID)

        assert result["count"] == 0
        assert result["wallets"] == []

    @patch(f"{_SVC}.repository")
    async def test_filters_by_chain_type(self, mock_repo):
        """Passes chain_type to repository."""
        session = _mock_session()
        w1 = _make_mock_wallet(chain_type="ethereum")

        mock_repo.get_wallets_for_user = AsyncMock(return_value=[w1])

        result = await service.get_user_wallets(
            session, FAKE_USER_ID, chain_type="ethereum"
        )

        mock_repo.get_wallets_for_user.assert_awaited_once_with(
            session, FAKE_USER_ID, "ethereum"
        )
        assert result["count"] == 1


# ---------------------------------------------------------------------------
# Tests: verify_wallet_ownership
# ---------------------------------------------------------------------------


class TestVerifyWalletOwnership:
    @patch(f"{_SVC}.repository")
    @patch(f"{_SVC}.verify_wallet_signature")
    async def test_valid_ownership(self, mock_verify, mock_repo):
        """Returns verified=True when sig is valid and wallet belongs to user."""
        session = _mock_session()
        wallet = _make_mock_wallet(user_id=FAKE_USER_ID)

        mock_verify.return_value = {"valid": True}
        mock_repo.get_wallet_by_address = AsyncMock(return_value=wallet)

        result = await service.verify_wallet_ownership(
            session,
            user_id=FAKE_USER_ID,
            wallet_address=FAKE_WALLET_ADDRESS,
            signature=FAKE_SIGNATURE,
            message=FAKE_MESSAGE,
            chain_type="solana",
        )

        assert result["verified"] is True
        assert result["wallet_address"] == FAKE_WALLET_ADDRESS
        assert "verification_timestamp" in result

    @patch(f"{_SVC}.verify_wallet_signature")
    async def test_invalid_signature_raises(self, mock_verify):
        """Raises InvalidSignatureError when signature is invalid."""
        session = _mock_session()

        mock_verify.return_value = {"valid": False, "error": "Bad sig"}

        with pytest.raises(InvalidSignatureError):
            await service.verify_wallet_ownership(
                session,
                user_id=FAKE_USER_ID,
                wallet_address=FAKE_WALLET_ADDRESS,
                signature="bad",
                message=FAKE_MESSAGE,
                chain_type="solana",
            )

    @patch(f"{_SVC}.repository")
    @patch(f"{_SVC}.verify_wallet_signature")
    async def test_wallet_not_linked_raises(self, mock_verify, mock_repo):
        """Raises NotFoundError when wallet is not linked to user."""
        session = _mock_session()

        mock_verify.return_value = {"valid": True}
        mock_repo.get_wallet_by_address = AsyncMock(return_value=None)

        with pytest.raises(NotFoundError, match="not linked"):
            await service.verify_wallet_ownership(
                session,
                user_id=FAKE_USER_ID,
                wallet_address=FAKE_WALLET_ADDRESS,
                signature=FAKE_SIGNATURE,
                message=FAKE_MESSAGE,
                chain_type="solana",
            )


class TestCheckContractInteraction:
    async def test_requires_rpc_url(self):
        with pytest.raises(ValidationError, match="Ethereum RPC URL not configured"):
            await service.check_contract_interaction(
                wallet_address=FAKE_ETH_ADDRESS,
                contract_address=FAKE_ETH_ADDRESS,
                rpc_url="",
            )

    async def test_returns_true_when_contract_has_code_and_wallet_has_balance(self):
        fake_eth = MagicMock()
        fake_eth.get_code.return_value = b"\x01"
        fake_eth.get_balance.return_value = 10

        fake_web3_cls = MagicMock()
        fake_web3_cls.HTTPProvider.return_value = object()
        fake_web3_cls.to_checksum_address.side_effect = lambda value: f"checksum:{value}"
        fake_web3_cls.return_value = MagicMock(eth=fake_eth)

        with patch.dict(sys.modules, {"web3": MagicMock(Web3=fake_web3_cls)}):
            result = await service.check_contract_interaction(
                wallet_address=FAKE_ETH_ADDRESS,
                contract_address="0x1111111111111111111111111111111111111111",
                rpc_url="https://rpc.example.com",
            )

        assert result == {
            "can_interact": True,
            "wallet_address": FAKE_ETH_ADDRESS,
            "contract_address": "0x1111111111111111111111111111111111111111",
        }

    async def test_returns_false_when_wallet_cannot_interact(self):
        fake_eth = MagicMock()
        fake_eth.get_code.return_value = b""
        fake_eth.get_balance.return_value = 0

        fake_web3_cls = MagicMock()
        fake_web3_cls.HTTPProvider.return_value = object()
        fake_web3_cls.to_checksum_address.side_effect = lambda value: value
        fake_web3_cls.return_value = MagicMock(eth=fake_eth)

        with patch.dict(sys.modules, {"web3": MagicMock(Web3=fake_web3_cls)}):
            result = await service.check_contract_interaction(
                wallet_address=FAKE_ETH_ADDRESS,
                contract_address="0x2222222222222222222222222222222222222222",
                rpc_url="https://rpc.example.com",
            )

        assert result["can_interact"] is False

    async def test_wraps_unexpected_errors(self):
        fake_eth = MagicMock()
        fake_eth.get_code.side_effect = RuntimeError("rpc boom")

        fake_web3_cls = MagicMock()
        fake_web3_cls.HTTPProvider.return_value = object()
        fake_web3_cls.to_checksum_address.side_effect = lambda value: value
        fake_web3_cls.return_value = MagicMock(eth=fake_eth)

        with patch.dict(sys.modules, {"web3": MagicMock(Web3=fake_web3_cls)}):
            with pytest.raises(
                ValidationError,
                match="Failed to check contract interaction: rpc boom",
            ):
                await service.check_contract_interaction(
                    wallet_address=FAKE_ETH_ADDRESS,
                    contract_address="0x3333333333333333333333333333333333333333",
                    rpc_url="https://rpc.example.com",
                )

    @patch(f"{_SVC}.repository")
    @patch(f"{_SVC}.verify_wallet_signature")
    async def test_wallet_belongs_to_other_user_raises(
        self, mock_verify, mock_repo
    ):
        """Raises NotFoundError when wallet belongs to a different user."""
        session = _mock_session()
        other_user = str(uuid4())
        wallet = _make_mock_wallet(user_id=other_user)

        mock_verify.return_value = {"valid": True}
        mock_repo.get_wallet_by_address = AsyncMock(return_value=wallet)

        with pytest.raises(NotFoundError, match="not linked"):
            await service.verify_wallet_ownership(
                session,
                user_id=FAKE_USER_ID,
                wallet_address=FAKE_WALLET_ADDRESS,
                signature=FAKE_SIGNATURE,
                message=FAKE_MESSAGE,
                chain_type="solana",
            )
