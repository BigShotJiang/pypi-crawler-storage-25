"""Unit tests for the wallets domain repository layer.

Covers:
- get_wallet_by_address (happy path + not found, with/without chain_type)
- get_wallets_for_user (returns list, with/without chain_type)
- create_wallet (verifies model creation)
- update_wallet (verifies partial update with kwargs)
- set_primary_wallet (verifies unset-all-then-set pattern)
- delete_wallet (happy path + not found)
- wallet_exists (true/false cases)
- get_wallet_with_user (returns (wallet, user) tuple)
"""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock
from uuid import UUID, uuid4


from spaps_server_quickstart.domains.wallets.models import UserWallet
from spaps_server_quickstart.domains.wallets import repository


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

FAKE_USER_ID = str(uuid4())
FAKE_WALLET_ID = str(uuid4())
FAKE_WALLET_ADDRESS = "HVEbdiYU3Rr34NHBSgKs7q8cvdTeZLqNL77Z1FB2vjLy"
FAKE_ETH_ADDRESS = "0xa72bb7CeF1e4B2Cc144373d8dE0Add7CCc8DF4Ba"


def _make_wallet(
    wallet_id: str | None = None,
    user_id: str | None = None,
    wallet_address: str = FAKE_WALLET_ADDRESS,
    chain_type: str = "solana",
    is_primary: bool = False,
) -> MagicMock:
    """Create a mock UserWallet with realistic attributes."""
    wallet = MagicMock(spec=UserWallet)
    wallet.id = UUID(wallet_id or FAKE_WALLET_ID)
    wallet.user_id = UUID(user_id or FAKE_USER_ID)
    wallet.wallet_address = wallet_address
    wallet.chain_type = chain_type
    wallet.is_primary = is_primary
    wallet.verified_at = datetime.now(UTC)
    wallet.created_at = datetime.now(UTC)
    wallet.updated_at = datetime.now(UTC)
    return wallet


def _mock_session() -> AsyncMock:
    """Create a mock AsyncSession with common methods."""
    session = AsyncMock()
    session.add = MagicMock()
    session.flush = AsyncMock()
    session.refresh = AsyncMock()
    session.execute = AsyncMock()
    session.commit = AsyncMock()
    return session


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestGetWalletByAddress:
    async def test_happy_path(self):
        """Returns a wallet when found by address."""
        session = _mock_session()
        wallet = _make_wallet()

        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = wallet
        session.execute.return_value = mock_result

        got = await repository.get_wallet_by_address(session, FAKE_WALLET_ADDRESS)

        assert got is wallet
        session.execute.assert_awaited_once()
        mock_result.scalar_one_or_none.assert_called_once()

    async def test_not_found(self):
        """Returns None when wallet does not exist."""
        session = _mock_session()

        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = None
        session.execute.return_value = mock_result

        got = await repository.get_wallet_by_address(session, "nonexistent")

        assert got is None

    async def test_with_chain_type_filter(self):
        """Passes chain_type as an additional filter when provided."""
        session = _mock_session()
        wallet = _make_wallet()

        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = wallet
        session.execute.return_value = mock_result

        got = await repository.get_wallet_by_address(
            session, FAKE_WALLET_ADDRESS, chain_type="solana"
        )

        assert got is wallet
        session.execute.assert_awaited_once()

    async def test_without_chain_type_filter(self):
        """Works when chain_type is None (matches any chain)."""
        session = _mock_session()
        wallet = _make_wallet(chain_type="ethereum", wallet_address=FAKE_ETH_ADDRESS)

        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = wallet
        session.execute.return_value = mock_result

        got = await repository.get_wallet_by_address(
            session, FAKE_ETH_ADDRESS, chain_type=None
        )

        assert got is wallet
        assert got.chain_type == "ethereum"


class TestGetWalletsForUser:
    async def test_returns_list(self):
        """Returns a list of wallets for the user."""
        session = _mock_session()
        w1 = _make_wallet(wallet_id=str(uuid4()))
        w2 = _make_wallet(wallet_id=str(uuid4()))

        mock_scalars = MagicMock()
        mock_scalars.all.return_value = [w1, w2]
        mock_result = MagicMock()
        mock_result.scalars.return_value = mock_scalars
        session.execute.return_value = mock_result

        wallets = await repository.get_wallets_for_user(session, FAKE_USER_ID)

        assert len(wallets) == 2
        assert wallets[0] is w1
        assert wallets[1] is w2

    async def test_returns_empty_list(self):
        """Returns an empty list when user has no wallets."""
        session = _mock_session()

        mock_scalars = MagicMock()
        mock_scalars.all.return_value = []
        mock_result = MagicMock()
        mock_result.scalars.return_value = mock_scalars
        session.execute.return_value = mock_result

        wallets = await repository.get_wallets_for_user(session, FAKE_USER_ID)

        assert wallets == []

    async def test_with_chain_type_filter(self):
        """Filters wallets by chain_type when provided."""
        session = _mock_session()
        w1 = _make_wallet(chain_type="solana")

        mock_scalars = MagicMock()
        mock_scalars.all.return_value = [w1]
        mock_result = MagicMock()
        mock_result.scalars.return_value = mock_scalars
        session.execute.return_value = mock_result

        wallets = await repository.get_wallets_for_user(
            session, FAKE_USER_ID, chain_type="solana"
        )

        assert len(wallets) == 1
        assert wallets[0].chain_type == "solana"


class TestCreateWallet:
    async def test_creates_wallet(self):
        """Creates a wallet record, flushes, and refreshes."""
        session = _mock_session()

        wallet = await repository.create_wallet(
            session,
            user_id=FAKE_USER_ID,
            wallet_address=FAKE_WALLET_ADDRESS,
            chain_type="solana",
            is_primary=True,
        )

        # session.add was called with a UserWallet instance
        session.add.assert_called_once()
        added_obj = session.add.call_args[0][0]
        assert isinstance(added_obj, UserWallet)
        assert added_obj.wallet_address == FAKE_WALLET_ADDRESS
        assert added_obj.chain_type == "solana"
        assert added_obj.is_primary is True
        assert added_obj.user_id == UUID(FAKE_USER_ID)
        assert added_obj.verified_at is not None

        session.flush.assert_awaited_once()
        session.refresh.assert_awaited_once()

    async def test_creates_non_primary_wallet(self):
        """Default is_primary is False."""
        session = _mock_session()

        await repository.create_wallet(
            session,
            user_id=FAKE_USER_ID,
            wallet_address=FAKE_ETH_ADDRESS,
            chain_type="ethereum",
        )

        added_obj = session.add.call_args[0][0]
        assert added_obj.is_primary is False


class TestUpdateWallet:
    async def test_updates_fields(self):
        """Applies arbitrary kwargs to the wallet record."""
        session = _mock_session()
        wallet = _make_wallet()

        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = wallet
        session.execute.return_value = mock_result

        updated = await repository.update_wallet(
            session,
            FAKE_WALLET_ID,
            is_primary=True,
            chain_type="base",
        )

        assert updated is wallet
        # The mock should have setattr called
        assert wallet.is_primary is True  # set via setattr in the function
        session.flush.assert_awaited_once()
        session.refresh.assert_awaited_once()

    async def test_returns_none_when_not_found(self):
        """Returns None if the wallet ID does not exist."""
        session = _mock_session()

        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = None
        session.execute.return_value = mock_result

        updated = await repository.update_wallet(
            session, str(uuid4()), is_primary=True
        )

        assert updated is None
        session.flush.assert_not_awaited()


class TestSetPrimaryWallet:
    async def test_sets_primary_wallet(self):
        """Unsets all, then sets the target wallet as primary."""
        session = _mock_session()
        wallet = _make_wallet(is_primary=False)

        # First call: verify wallet belongs to user (SELECT)
        # Second call: unset all primaries (UPDATE)
        mock_result_select = MagicMock()
        mock_result_select.scalar_one_or_none.return_value = wallet
        mock_result_update = MagicMock()

        session.execute = AsyncMock(
            side_effect=[mock_result_select, mock_result_update]
        )

        result = await repository.set_primary_wallet(
            session, FAKE_USER_ID, FAKE_WALLET_ID
        )

        assert result is True
        assert wallet.is_primary is True
        # 2 execute calls: SELECT for wallet, UPDATE to unset primaries
        assert session.execute.await_count == 2
        session.flush.assert_awaited_once()

    async def test_returns_false_when_wallet_not_found(self):
        """Returns False when wallet does not exist or does not belong to user."""
        session = _mock_session()

        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = None
        session.execute.return_value = mock_result

        result = await repository.set_primary_wallet(
            session, FAKE_USER_ID, str(uuid4())
        )

        assert result is False
        session.flush.assert_not_awaited()


class TestDeleteWallet:
    async def test_happy_path(self):
        """Returns True when a wallet is successfully deleted."""
        session = _mock_session()

        mock_result = MagicMock()
        mock_result.rowcount = 1
        session.execute.return_value = mock_result

        result = await repository.delete_wallet(session, FAKE_WALLET_ID)

        assert result is True

    async def test_not_found(self):
        """Returns False when no row is deleted."""
        session = _mock_session()

        mock_result = MagicMock()
        mock_result.rowcount = 0
        session.execute.return_value = mock_result

        result = await repository.delete_wallet(session, str(uuid4()))

        assert result is False


class TestWalletExists:
    async def test_returns_true(self):
        """Returns True when wallet exists."""
        session = _mock_session()

        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = uuid4()
        session.execute.return_value = mock_result

        exists = await repository.wallet_exists(
            session, FAKE_WALLET_ADDRESS, "solana"
        )

        assert exists is True

    async def test_returns_false(self):
        """Returns False when wallet does not exist."""
        session = _mock_session()

        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = None
        session.execute.return_value = mock_result

        exists = await repository.wallet_exists(
            session, "nonexistent", "solana"
        )

        assert exists is False


class TestGetWalletWithUser:
    async def test_returns_wallet_and_user(self):
        """Returns (wallet, user) tuple when found."""
        session = _mock_session()
        wallet = _make_wallet()

        mock_user = MagicMock()
        mock_user.id = UUID(FAKE_USER_ID)
        mock_user.email = "test@example.com"

        # First execute: get_wallet_by_address
        mock_result_wallet = MagicMock()
        mock_result_wallet.scalar_one_or_none.return_value = wallet
        # Second execute: get user by ID
        mock_result_user = MagicMock()
        mock_result_user.scalar_one_or_none.return_value = mock_user

        session.execute = AsyncMock(
            side_effect=[mock_result_wallet, mock_result_user]
        )

        got_wallet, got_user = await repository.get_wallet_with_user(
            session, FAKE_WALLET_ADDRESS, "solana"
        )

        assert got_wallet is wallet
        assert got_user is mock_user

    async def test_returns_none_none_when_wallet_not_found(self):
        """Returns (None, None) when wallet does not exist."""
        session = _mock_session()

        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = None
        session.execute.return_value = mock_result

        got_wallet, got_user = await repository.get_wallet_with_user(
            session, "nonexistent", "solana"
        )

        assert got_wallet is None
        assert got_user is None
