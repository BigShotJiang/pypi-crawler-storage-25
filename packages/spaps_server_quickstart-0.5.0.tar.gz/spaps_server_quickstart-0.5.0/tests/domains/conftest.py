"""
SPAPS domain test configuration.

Uses spaps_server_quickstart.testing for pgvector-enabled testcontainers,
database provisioning, and per-test state reset.

pytest_plugins is declared in tests/conftest.py (pytest requires top-level).
This file handles domain-specific TestConfig registration.

Run with: pytest tests/domains/
"""

from __future__ import annotations

import os
from pathlib import Path

from spaps_server_quickstart.testing import TestConfig, register_test_config
from spaps_server_quickstart.spaps_app import create_spaps_app
from spaps_server_quickstart.spaps_settings import SpapsSettings, get_spaps_settings
from spaps_server_quickstart.db.session import DatabaseResources

PROJECT_ROOT = Path(__file__).resolve().parents[4]  # sweet-potato/


def _create_test_app():
    """Create a SPAPS app configured for testing."""
    settings = SpapsSettings(
        env="test",
        app_name="SPAPS Test",
        database_url=os.environ.get(
            "DATABASE_URL",
            "postgresql+asyncpg://postgres:postgres@localhost:5434/spaps_test",
        ),
        redis_url=os.environ.get("REDIS_URL", "redis://localhost:6380/0"),
        jwt_secret="test-jwt-secret",
        refresh_token_secret="test-refresh-secret",
        spaps_local_mode=True,
        debug=True,
    )
    return create_spaps_app(settings=settings)


def _get_db_session():
    """Dependency for getting a test DB session."""
    settings = get_spaps_settings()
    resources = DatabaseResources(settings)
    return resources.session_dependency


async def _dispose_engine():
    """Dispose the test database engine."""
    settings = get_spaps_settings()
    resources = DatabaseResources(settings)
    await resources.dispose()


register_test_config(
    TestConfig(
        template_db_name="spaps_template",
        worker_db_prefix="spaps_test",
        app_db_user="spaps_app",
        app_db_password="spaps_app",
        alembic_ini_path=PROJECT_ROOT / "alembic.ini",
        seed_sql=[],
        settings_overrides={},
        create_app=_create_test_app,
        get_db_session=_get_db_session,
        settings_cache_clear=get_spaps_settings.cache_clear,
        dispose_engine=_dispose_engine,
    )
)
