"""Integration tests for the sessions domain router.

Uses ``httpx.AsyncClient`` with ``ASGITransport`` against a minimal
FastAPI app that includes only the sessions router, with all dependencies
(auth, database) replaced by mocks.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from fastapi.responses import JSONResponse

from spaps_server_quickstart.domains.errors import DomainError, NotFoundError
from spaps_server_quickstart.domains.sessions.router import router
from spaps_server_quickstart.domains.sessions.schemas import (
    CurrentSessionResponse,
    ListSessionsResponse,
    RevokeAllSessionsResponse,
    RevokeSessionResponse,
    SessionInfo,
    TouchSessionResponse,
    ValidateSessionResponse,
)
from spaps_server_quickstart.middleware.spaps_deps import (
    get_current_user,
    get_db_session,
)


# ---------------------------------------------------------------------------
# Fake dependencies
# ---------------------------------------------------------------------------

TEST_USER_ID = str(uuid4())
TEST_JTI = str(uuid4())
TEST_APP_ID = str(uuid4())


def _make_fake_user():
    user = MagicMock()
    user.id = TEST_USER_ID
    user.jti = TEST_JTI
    user.application_id = TEST_APP_ID
    user.tier = "basic"
    user.wallet_addresses = ["0xabc", "0xdef"]
    return user


async def _mock_get_current_user():
    return _make_fake_user()


async def _mock_get_db_session():
    yield AsyncMock()


def _make_session_info(**overrides) -> SessionInfo:
    now_iso = datetime.now(UTC).isoformat()
    defaults = dict(
        id=str(uuid4()),
        user_id=TEST_USER_ID,
        application_id=TEST_APP_ID,
        tier="basic",
        created_at=now_iso,
        expires_at=(datetime.now(UTC) + timedelta(days=30)).isoformat(),
        last_activity=now_iso,
        last_used=now_iso,
        wallets_count=2,
        duration_minutes=10.0,
        idle_minutes=None,
    )
    defaults.update(overrides)
    return SessionInfo(**defaults)


# ---------------------------------------------------------------------------
# Test app + client fixture
# ---------------------------------------------------------------------------


@pytest.fixture
def test_app() -> FastAPI:
    app = FastAPI()

    # Register a minimal DomainError handler so error tests get proper
    # HTTP responses instead of unhandled exceptions through the transport.
    @app.exception_handler(DomainError)
    async def _domain_error_handler(request, exc: DomainError):
        return JSONResponse(
            status_code=exc.status_code,
            content={"error": {"code": exc.code, "message": exc.message}},
        )

    app.include_router(router)
    app.dependency_overrides[get_current_user] = _mock_get_current_user
    app.dependency_overrides[get_db_session] = _mock_get_db_session
    return app


@pytest.fixture
async def client(test_app: FastAPI):
    transport = ASGITransport(app=test_app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


# Patch target for the service module as imported by the router
_SVC = "spaps_server_quickstart.domains.sessions.router.service"


# ===================================================================
# GET /sessions/current
# ===================================================================


class TestGetCurrentSession:
    @patch(f"{_SVC}.get_current_session", new_callable=AsyncMock)
    async def test_returns_current_session(self, mock_svc, client: AsyncClient):
        session_info = _make_session_info()
        mock_svc.return_value = CurrentSessionResponse(session=session_info)

        response = await client.get("/sessions/current")

        assert response.status_code == 200
        data = response.json()
        assert data["session"]["user_id"] == TEST_USER_ID
        assert data["session"]["tier"] == "basic"

    @patch(f"{_SVC}.get_current_session", new_callable=AsyncMock)
    async def test_passes_user_context(self, mock_svc, client: AsyncClient):
        mock_svc.return_value = CurrentSessionResponse(
            session=_make_session_info(),
        )

        await client.get("/sessions/current")

        mock_svc.assert_awaited_once()
        call_kwargs = mock_svc.call_args.kwargs
        assert call_kwargs["user_id"] == TEST_USER_ID
        assert call_kwargs["jti"] == TEST_JTI
        assert call_kwargs["application_id"] == TEST_APP_ID
        assert call_kwargs["tier"] == "basic"
        assert call_kwargs["wallets_count"] == 2


# ===================================================================
# GET /sessions/
# ===================================================================


class TestListSessions:
    @patch(f"{_SVC}.list_user_sessions", new_callable=AsyncMock)
    async def test_returns_session_list(self, mock_svc, client: AsyncClient):
        sessions = [_make_session_info() for _ in range(3)]
        mock_svc.return_value = ListSessionsResponse(
            sessions=sessions, total=3,
        )

        response = await client.get("/sessions/")

        assert response.status_code == 200
        data = response.json()
        assert data["total"] == 3
        assert len(data["sessions"]) == 3

    @patch(f"{_SVC}.list_user_sessions", new_callable=AsyncMock)
    async def test_empty_list(self, mock_svc, client: AsyncClient):
        mock_svc.return_value = ListSessionsResponse(sessions=[], total=0)

        response = await client.get("/sessions/")

        assert response.status_code == 200
        data = response.json()
        assert data["total"] == 0
        assert data["sessions"] == []

    @patch(f"{_SVC}.list_user_sessions", new_callable=AsyncMock)
    async def test_passes_user_id(self, mock_svc, client: AsyncClient):
        mock_svc.return_value = ListSessionsResponse(sessions=[], total=0)

        await client.get("/sessions/")

        call_kwargs = mock_svc.call_args.kwargs
        assert call_kwargs["user_id"] == TEST_USER_ID


# ===================================================================
# POST /sessions/validate
# ===================================================================


class TestValidateSession:
    @patch(f"{_SVC}.validate_session", new_callable=AsyncMock)
    async def test_valid_session(self, mock_svc, client: AsyncClient):
        mock_svc.return_value = ValidateSessionResponse(
            valid=True, session=_make_session_info(),
        )

        response = await client.post("/sessions/validate")

        assert response.status_code == 200
        data = response.json()
        assert data["valid"] is True
        assert data["session"] is not None

    @patch(f"{_SVC}.validate_session", new_callable=AsyncMock)
    async def test_invalid_session(self, mock_svc, client: AsyncClient):
        mock_svc.return_value = ValidateSessionResponse(
            valid=False, reason="Token has been revoked",
        )

        response = await client.post("/sessions/validate")

        assert response.status_code == 200
        data = response.json()
        assert data["valid"] is False
        assert data["reason"] == "Token has been revoked"

    @patch(f"{_SVC}.validate_session", new_callable=AsyncMock)
    async def test_passes_full_user_context(self, mock_svc, client: AsyncClient):
        mock_svc.return_value = ValidateSessionResponse(valid=True)

        await client.post("/sessions/validate")

        call_kwargs = mock_svc.call_args.kwargs
        assert call_kwargs["user_id"] == TEST_USER_ID
        assert call_kwargs["jti"] == TEST_JTI
        assert call_kwargs["application_id"] == TEST_APP_ID
        assert call_kwargs["tier"] == "basic"
        assert call_kwargs["wallets_count"] == 2


# ===================================================================
# DELETE /sessions/{session_id}
# ===================================================================


class TestRevokeSession:
    @patch(f"{_SVC}.revoke_session", new_callable=AsyncMock)
    async def test_revokes_session(self, mock_svc, client: AsyncClient):
        session_id = str(uuid4())
        mock_svc.return_value = RevokeSessionResponse(
            message="Session revoked successfully",
            session_id=session_id,
        )

        response = await client.delete(f"/sessions/{session_id}")

        assert response.status_code == 200
        data = response.json()
        assert data["session_id"] == session_id
        assert "revoked" in data["message"].lower()

    @patch(f"{_SVC}.revoke_session", new_callable=AsyncMock)
    async def test_passes_session_id_and_user(self, mock_svc, client: AsyncClient):
        session_id = str(uuid4())
        mock_svc.return_value = RevokeSessionResponse(
            message="ok", session_id=session_id,
        )

        await client.delete(f"/sessions/{session_id}")

        call_kwargs = mock_svc.call_args.kwargs
        assert call_kwargs["user_id"] == TEST_USER_ID
        assert call_kwargs["session_id"] == session_id

    @patch(f"{_SVC}.revoke_session", new_callable=AsyncMock)
    async def test_not_found(self, mock_svc, client: AsyncClient):
        mock_svc.side_effect = NotFoundError("Session not found")

        response = await client.delete(f"/sessions/{uuid4()}")

        assert response.status_code == 404
        data = response.json()
        assert data["error"]["code"] == "NOT_FOUND"


# ===================================================================
# DELETE /sessions/
# ===================================================================


class TestRevokeAllSessions:
    @patch(f"{_SVC}.revoke_all_sessions", new_callable=AsyncMock)
    async def test_revokes_all(self, mock_svc, client: AsyncClient):
        revoked_ids = [str(uuid4()) for _ in range(3)]
        mock_svc.return_value = RevokeAllSessionsResponse(
            message="Revoked 3 sessions",
            revoked_count=3,
            revoked_sessions=revoked_ids,
        )

        response = await client.delete("/sessions/all")

        assert response.status_code == 200
        data = response.json()
        assert data["revoked_count"] == 3
        assert len(data["revoked_sessions"]) == 3

    @patch(f"{_SVC}.revoke_all_sessions", new_callable=AsyncMock)
    async def test_passes_current_jti(self, mock_svc, client: AsyncClient):
        mock_svc.return_value = RevokeAllSessionsResponse(
            message="ok", revoked_count=0, revoked_sessions=[],
        )

        await client.delete("/sessions/all")

        call_kwargs = mock_svc.call_args.kwargs
        assert call_kwargs["user_id"] == TEST_USER_ID
        assert call_kwargs["current_token_jti"] == TEST_JTI


# ===================================================================
# POST /sessions/{session_id}/touch
# ===================================================================


class TestTouchSession:
    @patch(f"{_SVC}.touch_session", new_callable=AsyncMock)
    async def test_updates_activity(self, mock_svc, client: AsyncClient):
        now_iso = datetime.now(UTC).isoformat()
        mock_svc.return_value = TouchSessionResponse(
            message="Session activity updated",
            session_id=TEST_JTI,
            last_activity=now_iso,
        )

        response = await client.post("/sessions/touch")

        assert response.status_code == 200
        data = response.json()
        assert data["session_id"] == TEST_JTI
        assert data["last_activity"] == now_iso

    @patch(f"{_SVC}.touch_session", new_callable=AsyncMock)
    async def test_passes_jti_and_user(self, mock_svc, client: AsyncClient):
        mock_svc.return_value = TouchSessionResponse(
            message="ok", session_id=TEST_JTI, last_activity="",
        )

        await client.post("/sessions/touch")

        call_kwargs = mock_svc.call_args.kwargs
        assert call_kwargs["session_id"] == TEST_JTI
        assert call_kwargs["user_id"] == TEST_USER_ID

    @patch(f"{_SVC}.touch_session", new_callable=AsyncMock)
    async def test_not_found(self, mock_svc, client: AsyncClient):
        mock_svc.side_effect = NotFoundError("Session not found")

        response = await client.post("/sessions/touch")

        assert response.status_code == 404
        data = response.json()
        assert data["error"]["code"] == "NOT_FOUND"
