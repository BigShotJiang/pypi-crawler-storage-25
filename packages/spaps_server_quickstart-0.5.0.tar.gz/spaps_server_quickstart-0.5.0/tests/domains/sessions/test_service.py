"""Unit tests for the sessions domain service layer.

Mocks the repository module, ``jwt_service``, and ``blacklist_service``
to verify business logic orchestration in isolation.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import UUID, uuid4

import pytest

from spaps_server_quickstart.domains.errors import (
    InvalidRefreshTokenError,
    NotFoundError,
)
from spaps_server_quickstart.domains.sessions.jwt_service import (
    RefreshTokenPayload,
    TokenPair,
)
from spaps_server_quickstart.domains.sessions.schemas import (
    CurrentSessionResponse,
    ListSessionsResponse,
    RevokeAllSessionsResponse,
    RevokeSessionResponse,
    TouchSessionResponse,
    ValidateSessionResponse,
)
from spaps_server_quickstart.domains.sessions.service import (
    _hash_token,
    _token_to_session_info,
    create_session,
    get_current_session,
    list_user_sessions,
    logout,
    refresh_session,
    revoke_all_sessions,
    revoke_session,
    touch_session,
    validate_session,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

USER_ID = str(uuid4())
APP_ID = str(uuid4())
JTI = str(uuid4())
JWT_SECRET = "test-jwt-secret-at-least-32-chars!!"
REFRESH_SECRET = "test-refresh-secret-at-least-32!!"


def _make_db() -> AsyncMock:
    return AsyncMock()


def _make_refresh_token_row(**overrides):
    """Create a mock RefreshToken model instance."""
    defaults = dict(
        id=uuid4(),
        user_id=UUID(USER_ID),
        application_id=UUID(APP_ID),
        token="hashed-refresh-token",
        expires_at=datetime.now(UTC) + timedelta(days=30),
        used_at=None,
        created_at=datetime.now(UTC) - timedelta(hours=1),
    )
    defaults.update(overrides)
    row = MagicMock()
    for k, v in defaults.items():
        setattr(row, k, v)
    return row


def _make_token_pair() -> TokenPair:
    return TokenPair(
        access_token="access.jwt.token",
        refresh_token="refresh.jwt.token",
        expires_in=3600,
    )


def _make_refresh_payload(**overrides) -> RefreshTokenPayload:
    defaults = dict(
        sub=USER_ID,
        app_id=APP_ID,
        token_family=str(uuid4()),
        email="test@example.com",
        roles=[],
        isAdmin=False,
        jti=JTI,
        iat=int(datetime.now(UTC).timestamp()),
        exp=int((datetime.now(UTC) + timedelta(days=30)).timestamp()),
        iss="spaps-auth-service",
        aud="spaps-client-apps",
    )
    defaults.update(overrides)
    return RefreshTokenPayload(**defaults)


# Patch targets (the module where the names are looked up at runtime)
_REPO = "spaps_server_quickstart.domains.sessions.service.repository"
_JWT = "spaps_server_quickstart.domains.sessions.service"
_BL = "spaps_server_quickstart.domains.sessions.service"


# ===================================================================
# Internal helpers
# ===================================================================


class TestHashToken:
    def test_deterministic(self):
        assert _hash_token("hello") == _hash_token("hello")

    def test_different_inputs_differ(self):
        assert _hash_token("a") != _hash_token("b")


class TestTokenToSessionInfo:
    def test_converts_token_to_session_info(self):
        row = _make_refresh_token_row()
        info = _token_to_session_info(row, tier="premium", wallets_count=2)

        assert info.id == str(row.id)
        assert info.user_id == str(row.user_id)
        assert info.tier == "premium"
        assert info.wallets_count == 2

    def test_handles_none_used_at(self):
        """When used_at is None, last_activity falls back to created_at."""
        row = _make_refresh_token_row(used_at=None)
        info = _token_to_session_info(row)

        # last_activity falls back to created_at when used_at is None
        assert info.last_activity is not None
        assert info.idle_minutes is not None

    def test_computes_duration_and_idle(self):
        now = datetime.now(UTC)
        row = _make_refresh_token_row(
            created_at=now - timedelta(minutes=30),
            used_at=now - timedelta(minutes=5),
        )
        info = _token_to_session_info(row)

        assert info.duration_minutes is not None
        assert info.duration_minutes >= 29.0
        assert info.idle_minutes is not None
        assert info.idle_minutes >= 4.0


# ===================================================================
# create_session
# ===================================================================


class TestCreateSession:
    @patch(f"{_JWT}.generate_token_pair")
    @patch(f"{_REPO}.create_refresh_token", new_callable=AsyncMock)
    async def test_happy_path(self, mock_create_rt, mock_gen_pair):
        db = _make_db()
        mock_gen_pair.return_value = _make_token_pair()
        mock_create_rt.return_value = _make_refresh_token_row()

        result = await create_session(
            db,
            user_id=USER_ID,
            application_id=APP_ID,
            jwt_secret=JWT_SECRET,
            refresh_secret=REFRESH_SECRET,
        )

        mock_gen_pair.assert_called_once()
        mock_create_rt.assert_awaited_once()
        assert result["access_token"] == "access.jwt.token"
        assert result["refresh_token"] == "refresh.jwt.token"
        assert result["expires_in"] == 3600
        assert result["token_type"] == "Bearer"

    @patch(f"{_JWT}.generate_token_pair")
    @patch(f"{_REPO}.create_refresh_token", new_callable=AsyncMock)
    async def test_stores_hash_not_raw_token(self, mock_create_rt, mock_gen_pair):
        db = _make_db()
        pair = _make_token_pair()
        mock_gen_pair.return_value = pair
        mock_create_rt.return_value = _make_refresh_token_row()

        await create_session(
            db,
            user_id=USER_ID,
            jwt_secret=JWT_SECRET,
            refresh_secret=REFRESH_SECRET,
        )

        call_kwargs = mock_create_rt.call_args.kwargs
        stored_hash = call_kwargs["token"]
        # The stored value must be a SHA-256 hash, not the raw JWT
        assert stored_hash != pair.refresh_token
        assert stored_hash == _hash_token(pair.refresh_token)

    @patch(f"{_JWT}.generate_token_pair")
    @patch(f"{_REPO}.create_refresh_token", new_callable=AsyncMock)
    async def test_passes_claims_to_generate(self, mock_create_rt, mock_gen_pair):
        db = _make_db()
        mock_gen_pair.return_value = _make_token_pair()
        mock_create_rt.return_value = _make_refresh_token_row()

        await create_session(
            db,
            user_id=USER_ID,
            application_id=APP_ID,
            email="admin@example.com",
            tier="premium",
            roles=["admin"],
            is_admin=True,
            jwt_secret=JWT_SECRET,
            refresh_secret=REFRESH_SECRET,
        )

        call_kwargs = mock_gen_pair.call_args.kwargs
        assert call_kwargs["email"] == "admin@example.com"
        assert call_kwargs["tier"] == "premium"
        assert call_kwargs["roles"] == ["admin"]
        assert call_kwargs["is_admin"] is True


# ===================================================================
# refresh_session
# ===================================================================


class TestRefreshSession:
    @patch(f"{_JWT}.generate_token_pair")
    @patch(f"{_REPO}.create_refresh_token", new_callable=AsyncMock)
    @patch(f"{_REPO}.revoke_token", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_refresh_token_by_hash", new_callable=AsyncMock)
    @patch(f"{_BL}.blacklist_token", new_callable=AsyncMock)
    @patch(f"{_BL}.is_blacklisted", new_callable=AsyncMock)
    @patch(f"{_JWT}.verify_refresh_token")
    async def test_happy_path(
        self,
        mock_verify,
        mock_is_bl,
        mock_bl_token,
        mock_get_hash,
        mock_revoke,
        mock_create_rt,
        mock_gen_pair,
    ):
        db = _make_db()
        payload = _make_refresh_payload()
        mock_verify.return_value = payload
        mock_is_bl.return_value = False
        stored_row = _make_refresh_token_row()
        mock_get_hash.return_value = stored_row
        mock_revoke.return_value = True
        mock_gen_pair.return_value = _make_token_pair()
        mock_create_rt.return_value = _make_refresh_token_row()

        result = await refresh_session(
            db,
            refresh_token_str="old.refresh.jwt",
            jwt_secret=JWT_SECRET,
            refresh_secret=REFRESH_SECRET,
        )

        mock_verify.assert_called_once_with("old.refresh.jwt", REFRESH_SECRET)
        mock_is_bl.assert_awaited_once()
        mock_get_hash.assert_awaited_once()
        mock_bl_token.assert_awaited_once()
        mock_revoke.assert_awaited_once_with(db, stored_row.id)
        mock_gen_pair.assert_called_once()
        mock_create_rt.assert_awaited_once()
        assert result["access_token"] == "access.jwt.token"
        assert result["refresh_token"] == "refresh.jwt.token"

    @patch(f"{_BL}.is_blacklisted", new_callable=AsyncMock)
    @patch(f"{_JWT}.verify_refresh_token")
    async def test_raises_when_blacklisted(self, mock_verify, mock_is_bl):
        db = _make_db()
        mock_verify.return_value = _make_refresh_payload()
        mock_is_bl.return_value = True

        with pytest.raises(InvalidRefreshTokenError, match="revoked"):
            await refresh_session(
                db,
                refresh_token_str="blacklisted.jwt",
                jwt_secret=JWT_SECRET,
                refresh_secret=REFRESH_SECRET,
            )

    @patch(f"{_REPO}.get_refresh_token_by_hash", new_callable=AsyncMock)
    @patch(f"{_BL}.is_blacklisted", new_callable=AsyncMock)
    @patch(f"{_JWT}.verify_refresh_token")
    async def test_raises_when_hash_not_found(
        self, mock_verify, mock_is_bl, mock_get_hash,
    ):
        db = _make_db()
        mock_verify.return_value = _make_refresh_payload()
        mock_is_bl.return_value = False
        mock_get_hash.return_value = None

        with pytest.raises(InvalidRefreshTokenError, match="not found"):
            await refresh_session(
                db,
                refresh_token_str="unknown.jwt",
                jwt_secret=JWT_SECRET,
                refresh_secret=REFRESH_SECRET,
            )


# ===================================================================
# get_current_session
# ===================================================================


class TestGetCurrentSession:
    @patch(f"{_REPO}.get_active_tokens_for_user", new_callable=AsyncMock)
    async def test_with_active_tokens(self, mock_get_tokens):
        db = _make_db()
        token = _make_refresh_token_row()
        mock_get_tokens.return_value = [token]

        result = await get_current_session(
            db, user_id=USER_ID, jti=JTI, tier="basic", wallets_count=1,
        )

        assert isinstance(result, CurrentSessionResponse)
        assert result.session.user_id == str(token.user_id)
        assert result.session.tier == "basic"
        assert result.session.wallets_count == 1

    @patch(f"{_REPO}.get_active_tokens_for_user", new_callable=AsyncMock)
    async def test_no_active_tokens_returns_fallback(self, mock_get_tokens):
        db = _make_db()
        mock_get_tokens.return_value = []

        result = await get_current_session(
            db, user_id=USER_ID, jti=JTI, tier="basic",
        )

        assert isinstance(result, CurrentSessionResponse)
        assert result.session.id == JTI
        assert result.session.user_id == USER_ID


# ===================================================================
# list_user_sessions
# ===================================================================


class TestListUserSessions:
    @patch(f"{_REPO}.get_active_tokens_for_user", new_callable=AsyncMock)
    async def test_returns_all_sessions(self, mock_get_tokens):
        db = _make_db()
        tokens = [_make_refresh_token_row() for _ in range(3)]
        mock_get_tokens.return_value = tokens

        result = await list_user_sessions(db, user_id=USER_ID)

        assert isinstance(result, ListSessionsResponse)
        assert result.total == 3
        assert len(result.sessions) == 3

    @patch(f"{_REPO}.get_active_tokens_for_user", new_callable=AsyncMock)
    async def test_empty_list(self, mock_get_tokens):
        db = _make_db()
        mock_get_tokens.return_value = []

        result = await list_user_sessions(db, user_id=USER_ID)

        assert result.total == 0
        assert result.sessions == []


# ===================================================================
# validate_session
# ===================================================================


class TestValidateSession:
    @patch(f"{_REPO}.get_active_tokens_for_user", new_callable=AsyncMock)
    @patch(f"{_BL}.is_blacklisted", new_callable=AsyncMock)
    async def test_valid_session(self, mock_is_bl, mock_get_tokens):
        db = _make_db()
        mock_is_bl.return_value = False
        token = _make_refresh_token_row()
        mock_get_tokens.return_value = [token]

        result = await validate_session(
            db, user_id=USER_ID, jti=JTI, tier="basic",
        )

        assert isinstance(result, ValidateSessionResponse)
        assert result.valid is True
        assert result.session is not None

    @patch(f"{_BL}.is_blacklisted", new_callable=AsyncMock)
    async def test_blacklisted_jti_returns_invalid(self, mock_is_bl):
        db = _make_db()
        mock_is_bl.return_value = True

        result = await validate_session(
            db, user_id=USER_ID, jti=JTI,
        )

        assert result.valid is False
        assert result.reason == "Token has been revoked"

    @patch(f"{_REPO}.get_active_tokens_for_user", new_callable=AsyncMock)
    @patch(f"{_BL}.is_blacklisted", new_callable=AsyncMock)
    async def test_no_refresh_tokens_still_valid(self, mock_is_bl, mock_get_tokens):
        db = _make_db()
        mock_is_bl.return_value = False
        mock_get_tokens.return_value = []

        result = await validate_session(
            db, user_id=USER_ID, jti=JTI,
        )

        assert result.valid is True
        assert "no active refresh" in result.reason.lower()

    @patch(f"{_REPO}.get_active_tokens_for_user", new_callable=AsyncMock)
    @patch(f"{_BL}.is_blacklisted", new_callable=AsyncMock)
    async def test_no_jti_skips_blacklist_check(self, mock_is_bl, mock_get_tokens):
        db = _make_db()
        mock_get_tokens.return_value = [_make_refresh_token_row()]

        result = await validate_session(
            db, user_id=USER_ID, jti=None,
        )

        mock_is_bl.assert_not_awaited()
        assert result.valid is True


# ===================================================================
# revoke_session
# ===================================================================


class TestRevokeSession:
    @patch(f"{_REPO}.revoke_token", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_active_tokens_for_user", new_callable=AsyncMock)
    async def test_happy_path(self, mock_get_tokens, mock_revoke):
        db = _make_db()
        session_id = uuid4()
        token = _make_refresh_token_row(id=session_id)
        mock_get_tokens.return_value = [token]
        mock_revoke.return_value = True

        result = await revoke_session(
            db, user_id=USER_ID, session_id=str(session_id),
        )

        assert isinstance(result, RevokeSessionResponse)
        assert result.session_id == str(session_id)
        assert "revoked" in result.message.lower()
        mock_revoke.assert_awaited_once_with(db, session_id)

    @patch(f"{_REPO}.get_active_tokens_for_user", new_callable=AsyncMock)
    async def test_not_found_raises(self, mock_get_tokens):
        db = _make_db()
        mock_get_tokens.return_value = []

        with pytest.raises(NotFoundError):
            await revoke_session(
                db, user_id=USER_ID, session_id=str(uuid4()),
            )

    @patch(f"{_REPO}.get_active_tokens_for_user", new_callable=AsyncMock)
    async def test_ownership_check(self, mock_get_tokens):
        """Cannot revoke a session belonging to another user."""
        db = _make_db()
        other_session_id = str(uuid4())
        # Return tokens that do NOT contain the requested session_id
        mock_get_tokens.return_value = [_make_refresh_token_row()]

        with pytest.raises(NotFoundError):
            await revoke_session(
                db, user_id=USER_ID, session_id=other_session_id,
            )


# ===================================================================
# revoke_all_sessions
# ===================================================================


class TestRevokeAllSessions:
    @patch(f"{_REPO}.revoke_all_user_tokens", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_active_tokens_for_user", new_callable=AsyncMock)
    async def test_revokes_all(self, mock_get_tokens, mock_revoke_all):
        db = _make_db()
        tokens = [_make_refresh_token_row() for _ in range(3)]
        mock_get_tokens.return_value = tokens
        mock_revoke_all.return_value = 3

        result = await revoke_all_sessions(db, user_id=USER_ID)

        assert isinstance(result, RevokeAllSessionsResponse)
        assert result.revoked_count == 3
        assert len(result.revoked_sessions) == 3

    @patch(f"{_REPO}.revoke_all_user_tokens", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_active_tokens_for_user", new_callable=AsyncMock)
    async def test_preserves_current_session(self, mock_get_tokens, mock_revoke_all):
        db = _make_db()
        current_id = uuid4()
        other_id = uuid4()
        tokens = [
            _make_refresh_token_row(id=current_id),  # most recent
            _make_refresh_token_row(id=other_id),
        ]
        mock_get_tokens.return_value = tokens
        mock_revoke_all.return_value = 1

        result = await revoke_all_sessions(
            db, user_id=USER_ID, current_token_jti=JTI,
        )

        # The most recent token (tokens[0]) should be preserved
        call_kwargs = mock_revoke_all.call_args.kwargs
        assert call_kwargs["except_token_id"] == current_id
        # revoked_sessions should NOT include the preserved token
        assert str(current_id) not in result.revoked_sessions
        assert str(other_id) in result.revoked_sessions

    @patch(f"{_REPO}.revoke_all_user_tokens", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_active_tokens_for_user", new_callable=AsyncMock)
    async def test_no_sessions_to_revoke(self, mock_get_tokens, mock_revoke_all):
        db = _make_db()
        mock_get_tokens.return_value = []
        mock_revoke_all.return_value = 0

        result = await revoke_all_sessions(db, user_id=USER_ID)

        assert result.revoked_count == 0
        assert result.revoked_sessions == []


# ===================================================================
# touch_session
# ===================================================================


class TestTouchSession:
    @patch(f"{_REPO}.touch_token", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_active_tokens_for_user", new_callable=AsyncMock)
    async def test_happy_path(self, mock_get_tokens, mock_touch):
        db = _make_db()
        session_id = uuid4()
        now = datetime.now(UTC)
        token = _make_refresh_token_row(id=session_id)
        mock_get_tokens.return_value = [token]
        updated = _make_refresh_token_row(id=session_id, used_at=now)
        mock_touch.return_value = updated

        result = await touch_session(
            db, session_id=str(session_id), user_id=USER_ID,
        )

        assert isinstance(result, TouchSessionResponse)
        assert result.session_id == str(session_id)
        assert result.last_activity == now.isoformat()

    @patch(f"{_REPO}.get_active_tokens_for_user", new_callable=AsyncMock)
    async def test_not_found_raises(self, mock_get_tokens):
        db = _make_db()
        mock_get_tokens.return_value = []

        with pytest.raises(NotFoundError):
            await touch_session(
                db, session_id=str(uuid4()), user_id=USER_ID,
            )

    @patch(f"{_REPO}.touch_token", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_active_tokens_for_user", new_callable=AsyncMock)
    async def test_touch_returns_none_raises(self, mock_get_tokens, mock_touch):
        """Edge case: ownership check passes but touch_token returns None."""
        db = _make_db()
        session_id = uuid4()
        token = _make_refresh_token_row(id=session_id)
        mock_get_tokens.return_value = [token]
        mock_touch.return_value = None

        with pytest.raises(NotFoundError):
            await touch_session(
                db, session_id=str(session_id), user_id=USER_ID,
            )


# ===================================================================
# logout
# ===================================================================


class TestLogout:
    @patch(f"{_REPO}.revoke_token", new_callable=AsyncMock)
    @patch(f"{_REPO}.get_refresh_token_by_hash", new_callable=AsyncMock)
    @patch(f"{_BL}.blacklist_token", new_callable=AsyncMock)
    async def test_blacklists_and_revokes_refresh(
        self, mock_bl, mock_get_hash, mock_revoke,
    ):
        db = _make_db()
        stored = _make_refresh_token_row()
        mock_get_hash.return_value = stored
        mock_revoke.return_value = True
        exp = int((datetime.now(UTC) + timedelta(hours=1)).timestamp())

        result = await logout(
            db,
            access_token_jti=JTI,
            user_id=USER_ID,
            token_exp=exp,
            refresh_token_str="refresh.jwt.value",
        )

        mock_bl.assert_awaited_once()
        bl_kwargs = mock_bl.call_args.kwargs
        assert bl_kwargs["jti"] == JTI
        assert bl_kwargs["reason"] == "logout"
        mock_get_hash.assert_awaited_once()
        mock_revoke.assert_awaited_once_with(db, stored.id)
        assert result["message"] == "Logged out successfully"

    @patch(f"{_BL}.blacklist_token", new_callable=AsyncMock)
    async def test_without_refresh_token(self, mock_bl):
        db = _make_db()
        exp = int((datetime.now(UTC) + timedelta(hours=1)).timestamp())

        result = await logout(
            db,
            access_token_jti=JTI,
            user_id=USER_ID,
            token_exp=exp,
            refresh_token_str=None,
        )

        mock_bl.assert_awaited_once()
        assert result["message"] == "Logged out successfully"

    @patch(f"{_REPO}.get_refresh_token_by_hash", new_callable=AsyncMock)
    @patch(f"{_BL}.blacklist_token", new_callable=AsyncMock)
    async def test_refresh_token_not_found_still_succeeds(
        self, mock_bl, mock_get_hash,
    ):
        """If the refresh token is not in DB, logout still succeeds."""
        db = _make_db()
        mock_get_hash.return_value = None
        exp = int((datetime.now(UTC) + timedelta(hours=1)).timestamp())

        result = await logout(
            db,
            access_token_jti=JTI,
            user_id=USER_ID,
            token_exp=exp,
            refresh_token_str="unknown.refresh",
        )

        assert result["message"] == "Logged out successfully"
