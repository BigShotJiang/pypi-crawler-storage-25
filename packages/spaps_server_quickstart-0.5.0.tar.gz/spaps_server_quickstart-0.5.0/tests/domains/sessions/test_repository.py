"""Unit tests for the sessions domain repository layer.

Validates each repository function by mocking ``AsyncSession`` and
verifying that the correct SQLAlchemy statements are built and executed.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4


from spaps_server_quickstart.domains.sessions import repository
from spaps_server_quickstart.domains.sessions.models import (
    AuthMagicLinkState,
    AuthNonce,
    AuthToken,
    RefreshToken,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_session() -> AsyncMock:
    """Create a mock ``AsyncSession`` with common helpers pre-configured."""
    session = AsyncMock()
    session.add = MagicMock()
    return session


def _make_refresh_token(**overrides) -> RefreshToken:
    """Build a fake ``RefreshToken`` with sensible defaults."""
    defaults = dict(
        id=uuid4(),
        user_id=uuid4(),
        application_id=None,
        token="sha256hashvalue",
        expires_at=datetime.now(UTC) + timedelta(days=30),
        used_at=None,
        created_at=datetime.now(UTC),
    )
    defaults.update(overrides)
    token = MagicMock(spec=RefreshToken)
    for k, v in defaults.items():
        setattr(token, k, v)
    return token


def _make_nonce(**overrides) -> AuthNonce:
    defaults = dict(
        id=uuid4(),
        wallet_address="0xabc123",
        nonce="random-nonce",
        expires_at=datetime.now(UTC) + timedelta(minutes=10),
        used=False,
        created_at=datetime.now(UTC),
    )
    defaults.update(overrides)
    nonce = MagicMock(spec=AuthNonce)
    for k, v in defaults.items():
        setattr(nonce, k, v)
    return nonce


def _make_auth_token(**overrides) -> AuthToken:
    defaults = dict(
        id=uuid4(),
        user_id=uuid4(),
        token_hash="sha256hash",
        type="email_verification",
        email="test@example.com",
        application_id=None,
        expires_at=datetime.now(UTC) + timedelta(hours=1),
        used_at=None,
        created_at=datetime.now(UTC),
    )
    defaults.update(overrides)
    token = MagicMock(spec=AuthToken)
    for k, v in defaults.items():
        setattr(token, k, v)
    return token


def _make_magic_link_state(**overrides) -> AuthMagicLinkState:
    defaults = dict(
        id=uuid4(),
        email="test@example.com",
        state="opaque-state-string",
        application_id=None,
        metadata_=None,
        expires_at=datetime.now(UTC) + timedelta(minutes=15),
        created_at=datetime.now(UTC),
    )
    defaults.update(overrides)
    state = MagicMock(spec=AuthMagicLinkState)
    for k, v in defaults.items():
        setattr(state, k, v)
    return state


# ===================================================================
# RefreshToken operations
# ===================================================================


class TestCreateRefreshToken:
    async def test_happy_path_adds_and_flushes(self):
        session = _make_session()
        user_id = uuid4()
        expires_at = datetime.now(UTC) + timedelta(days=30)

        result = await repository.create_refresh_token(
            session,
            user_id=user_id,
            token="abc123hash",
            expires_at=expires_at,
        )

        session.add.assert_called_once()
        session.flush.assert_awaited_once()
        added_row = session.add.call_args[0][0]
        assert isinstance(added_row, RefreshToken)
        assert added_row.user_id == user_id
        assert added_row.token == "abc123hash"
        assert added_row.expires_at == expires_at
        assert result is added_row

    async def test_with_application_id(self):
        session = _make_session()
        app_id = uuid4()

        result = await repository.create_refresh_token(
            session,
            user_id=uuid4(),
            token="hash",
            expires_at=datetime.now(UTC) + timedelta(days=1),
            application_id=app_id,
        )

        added_row = session.add.call_args[0][0]
        assert added_row.application_id == app_id


class TestGetRefreshTokenByHash:
    async def test_found(self):
        session = _make_session()
        expected_token = _make_refresh_token()

        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = expected_token
        session.execute.return_value = mock_result

        result = await repository.get_refresh_token_by_hash(session, "sha256hashvalue")

        session.execute.assert_awaited_once()
        assert result is expected_token

    async def test_not_found_returns_none(self):
        session = _make_session()

        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = None
        session.execute.return_value = mock_result

        result = await repository.get_refresh_token_by_hash(session, "nonexistent")

        assert result is None


class TestGetActiveTokensForUser:
    async def test_returns_non_expired_tokens(self):
        session = _make_session()
        user_id = uuid4()
        tokens = [_make_refresh_token(user_id=user_id) for _ in range(3)]

        mock_scalars = MagicMock()
        mock_scalars.all.return_value = tokens
        mock_result = MagicMock()
        mock_result.scalars.return_value = mock_scalars
        session.execute.return_value = mock_result

        result = await repository.get_active_tokens_for_user(session, user_id)

        session.execute.assert_awaited_once()
        assert result == tokens
        assert len(result) == 3

    async def test_returns_empty_list_when_none(self):
        session = _make_session()

        mock_scalars = MagicMock()
        mock_scalars.all.return_value = []
        mock_result = MagicMock()
        mock_result.scalars.return_value = mock_scalars
        session.execute.return_value = mock_result

        result = await repository.get_active_tokens_for_user(session, uuid4())

        assert result == []


class TestRevokeToken:
    async def test_deletes_existing_token(self):
        session = _make_session()
        token_id = uuid4()

        mock_result = MagicMock()
        mock_result.rowcount = 1
        session.execute.return_value = mock_result

        result = await repository.revoke_token(session, token_id)

        session.execute.assert_awaited_once()
        assert result is True

    async def test_returns_false_when_not_found(self):
        session = _make_session()

        mock_result = MagicMock()
        mock_result.rowcount = 0
        session.execute.return_value = mock_result

        result = await repository.revoke_token(session, uuid4())

        assert result is False


class TestRevokeAllUserTokens:
    async def test_bulk_delete(self):
        session = _make_session()
        user_id = uuid4()

        mock_result = MagicMock()
        mock_result.rowcount = 5
        session.execute.return_value = mock_result

        count = await repository.revoke_all_user_tokens(session, user_id)

        session.execute.assert_awaited_once()
        assert count == 5

    async def test_with_except_token_id(self):
        session = _make_session()
        user_id = uuid4()
        except_id = uuid4()

        mock_result = MagicMock()
        mock_result.rowcount = 4
        session.execute.return_value = mock_result

        count = await repository.revoke_all_user_tokens(
            session, user_id, except_token_id=except_id,
        )

        session.execute.assert_awaited_once()
        assert count == 4

    async def test_returns_zero_when_none_found(self):
        session = _make_session()

        mock_result = MagicMock()
        mock_result.rowcount = 0
        session.execute.return_value = mock_result

        count = await repository.revoke_all_user_tokens(session, uuid4())

        assert count == 0


class TestTouchToken:
    async def test_updates_used_at(self):
        session = _make_session()
        token_id = uuid4()
        updated_token = _make_refresh_token(id=token_id, used_at=datetime.now(UTC))

        # First execute: the UPDATE ... RETURNING
        update_result = MagicMock()
        update_result.first.return_value = MagicMock()  # non-None = found

        # Second execute: the SELECT to re-fetch
        select_result = MagicMock()
        select_result.scalar_one_or_none.return_value = updated_token

        session.execute.side_effect = [update_result, select_result]

        result = await repository.touch_token(session, token_id)

        assert session.execute.await_count == 2
        assert result is updated_token

    async def test_returns_none_when_not_found(self):
        session = _make_session()

        mock_result = MagicMock()
        mock_result.first.return_value = None
        session.execute.return_value = mock_result

        result = await repository.touch_token(session, uuid4())

        assert result is None


class TestCleanupExpiredTokens:
    async def test_deletes_expired(self):
        session = _make_session()

        mock_result = MagicMock()
        mock_result.rowcount = 10
        session.execute.return_value = mock_result

        count = await repository.cleanup_expired_tokens(session)

        session.execute.assert_awaited_once()
        assert count == 10

    async def test_returns_zero_when_none_expired(self):
        session = _make_session()

        mock_result = MagicMock()
        mock_result.rowcount = 0
        session.execute.return_value = mock_result

        count = await repository.cleanup_expired_tokens(session)

        assert count == 0


# ===================================================================
# AuthNonce operations
# ===================================================================


class TestCreateNonce:
    async def test_happy_path(self):
        session = _make_session()
        expires_at = datetime.now(UTC) + timedelta(minutes=10)

        result = await repository.create_nonce(
            session,
            wallet_address="0xabc123",
            nonce="random-nonce-value",
            expires_at=expires_at,
        )

        session.add.assert_called_once()
        session.flush.assert_awaited_once()
        added_row = session.add.call_args[0][0]
        assert isinstance(added_row, AuthNonce)
        assert added_row.wallet_address == "0xabc123"
        assert added_row.nonce == "random-nonce-value"
        assert added_row.used is False
        assert result is added_row


class TestGetValidNonce:
    async def test_found(self):
        session = _make_session()
        expected = _make_nonce()

        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = expected
        session.execute.return_value = mock_result

        result = await repository.get_valid_nonce(session, "0xabc123", "random-nonce")

        session.execute.assert_awaited_once()
        assert result is expected

    async def test_not_found_returns_none(self):
        session = _make_session()

        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = None
        session.execute.return_value = mock_result

        result = await repository.get_valid_nonce(session, "0xnone", "bad-nonce")

        assert result is None


class TestConsumeNonce:
    async def test_consumes_unused_nonce(self):
        session = _make_session()
        nonce_id = uuid4()

        mock_result = MagicMock()
        mock_result.first.return_value = MagicMock()  # non-None = consumed
        session.execute.return_value = mock_result

        result = await repository.consume_nonce(session, nonce_id)

        session.execute.assert_awaited_once()
        assert result is True

    async def test_returns_false_when_already_used(self):
        session = _make_session()

        mock_result = MagicMock()
        mock_result.first.return_value = None
        session.execute.return_value = mock_result

        result = await repository.consume_nonce(session, uuid4())

        assert result is False


class TestCleanupExpiredNonces:
    async def test_deletes_expired_and_used(self):
        session = _make_session()

        mock_result = MagicMock()
        mock_result.rowcount = 7
        session.execute.return_value = mock_result

        count = await repository.cleanup_expired_nonces(session)

        session.execute.assert_awaited_once()
        assert count == 7

    async def test_returns_zero_when_none(self):
        session = _make_session()

        mock_result = MagicMock()
        mock_result.rowcount = 0
        session.execute.return_value = mock_result

        count = await repository.cleanup_expired_nonces(session)

        assert count == 0


# ===================================================================
# AuthToken operations
# ===================================================================


class TestCreateAuthToken:
    async def test_happy_path(self):
        session = _make_session()
        user_id = uuid4()
        expires_at = datetime.now(UTC) + timedelta(hours=1)

        result = await repository.create_auth_token(
            session,
            user_id=user_id,
            token_hash="sha256-hash-here",
            token_type="email_verification",
            expires_at=expires_at,
            email="test@example.com",
        )

        session.add.assert_called_once()
        session.flush.assert_awaited_once()
        added_row = session.add.call_args[0][0]
        assert isinstance(added_row, AuthToken)
        assert added_row.user_id == user_id
        assert added_row.token_hash == "sha256-hash-here"
        assert added_row.type == "email_verification"
        assert added_row.email == "test@example.com"
        assert result is added_row

    async def test_nullable_user_id(self):
        session = _make_session()
        expires_at = datetime.now(UTC) + timedelta(hours=1)

        result = await repository.create_auth_token(
            session,
            user_id=None,
            token_hash="hash",
            token_type="email_verification",
            expires_at=expires_at,
        )

        added_row = session.add.call_args[0][0]
        assert added_row.user_id is None


class TestGetValidAuthToken:
    async def test_found(self):
        session = _make_session()
        expected = _make_auth_token()

        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = expected
        session.execute.return_value = mock_result

        result = await repository.get_valid_auth_token(
            session, "sha256hash", "email_verification",
        )

        session.execute.assert_awaited_once()
        assert result is expected

    async def test_not_found_returns_none(self):
        session = _make_session()

        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = None
        session.execute.return_value = mock_result

        result = await repository.get_valid_auth_token(
            session, "nonexistent", "password_reset",
        )

        assert result is None

    async def test_already_used_returns_none(self):
        """An auth token with ``used_at`` set should not be returned."""
        session = _make_session()

        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = None
        session.execute.return_value = mock_result

        result = await repository.get_valid_auth_token(
            session, "used-token-hash", "email_verification",
        )

        assert result is None


class TestConsumeAuthToken:
    async def test_consumes_unused_token(self):
        session = _make_session()
        token_id = uuid4()

        mock_result = MagicMock()
        mock_result.first.return_value = MagicMock()
        session.execute.return_value = mock_result

        result = await repository.consume_auth_token(session, token_id)

        session.execute.assert_awaited_once()
        assert result is True

    async def test_returns_false_when_already_consumed(self):
        session = _make_session()

        mock_result = MagicMock()
        mock_result.first.return_value = None
        session.execute.return_value = mock_result

        result = await repository.consume_auth_token(session, uuid4())

        assert result is False


# ===================================================================
# AuthMagicLinkState operations
# ===================================================================


class TestCreateMagicLinkState:
    async def test_happy_path(self):
        session = _make_session()
        expires_at = datetime.now(UTC) + timedelta(minutes=15)

        result = await repository.create_magic_link_state(
            session,
            email="user@example.com",
            state="opaque-state",
            expires_at=expires_at,
        )

        session.add.assert_called_once()
        session.flush.assert_awaited_once()
        added_row = session.add.call_args[0][0]
        assert isinstance(added_row, AuthMagicLinkState)
        assert added_row.email == "user@example.com"
        assert added_row.state == "opaque-state"
        assert result is added_row

    async def test_with_application_and_metadata(self):
        session = _make_session()
        app_id = uuid4()
        meta = {"token_hash": "abc"}

        await repository.create_magic_link_state(
            session,
            email="user@example.com",
            state="state-with-meta",
            expires_at=datetime.now(UTC) + timedelta(minutes=15),
            application_id=app_id,
            metadata=meta,
        )

        added_row = session.add.call_args[0][0]
        assert added_row.application_id == app_id
        assert added_row.metadata_ == meta


class TestGetValidMagicLinkState:
    async def test_found(self):
        session = _make_session()
        expected = _make_magic_link_state()

        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = expected
        session.execute.return_value = mock_result

        result = await repository.get_valid_magic_link_state(session, "opaque-state-string")

        session.execute.assert_awaited_once()
        assert result is expected

    async def test_not_found_returns_none(self):
        session = _make_session()

        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = None
        session.execute.return_value = mock_result

        result = await repository.get_valid_magic_link_state(session, "nonexistent")

        assert result is None


class TestConsumeMagicLinkState:
    async def test_consumes_existing_state(self):
        session = _make_session()
        state_id = uuid4()

        mock_result = MagicMock()
        mock_result.rowcount = 1
        session.execute.return_value = mock_result

        result = await repository.consume_magic_link_state(session, state_id)

        session.execute.assert_awaited_once()
        assert result is True

    async def test_returns_false_when_not_found(self):
        session = _make_session()

        mock_result = MagicMock()
        mock_result.rowcount = 0
        session.execute.return_value = mock_result

        result = await repository.consume_magic_link_state(session, uuid4())

        assert result is False
