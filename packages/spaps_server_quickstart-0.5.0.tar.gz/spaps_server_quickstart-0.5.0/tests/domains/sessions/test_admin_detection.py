"""Unit tests for static admin/super-admin detection helpers."""

from __future__ import annotations

from spaps_server_quickstart.domains.sessions import admin_detection


class TestIsSuperAdmin:
    def test_super_admin_by_user_id(self):
        """Known SUPER_ADMIN_IDS should resolve as super-admin."""
        user_id = admin_detection.SUPER_ADMIN_IDS[0]
        assert admin_detection.is_super_admin(user_id=user_id) is True

    def test_admin_email_is_not_super_admin(self):
        """Admin email alone must not automatically grant super-admin."""
        email = admin_detection.ADMIN_EMAILS[0]
        assert admin_detection.is_super_admin(email=email) is False


class TestGetUserRoles:
    def test_admin_email_gets_admin_only_role(self):
        """Known admin email should grant admin, but not super-admin."""
        email = admin_detection.ADMIN_EMAILS[0]
        assert admin_detection.get_user_roles(email=email) == ["admin"]

    def test_colleen_email_is_not_admin(self):
        """Colleen should no longer be treated as a static admin email."""
        assert admin_detection.get_user_roles(
            email="colleen.campbell@campbellcoaccounting.com"
        ) == ["user"]

    def test_super_admin_id_gets_both_roles(self):
        """Known super-admin id should grant admin + super-admin roles."""
        user_id = admin_detection.SUPER_ADMIN_IDS[0]
        assert admin_detection.get_user_roles(user_id=user_id) == [
            "admin",
            "super_admin",
        ]
