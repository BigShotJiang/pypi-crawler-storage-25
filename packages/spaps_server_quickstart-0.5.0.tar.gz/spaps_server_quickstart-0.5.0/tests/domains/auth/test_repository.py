"""Unit tests for the auth domain repository layer.

Validates database operations for user lookup, refresh token management,
auth token lifecycle, and magic-link state persistence.  All database
interactions are mocked via AsyncMock sessions.
"""

from __future__ import annotations

import hashlib
from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock
from uuid import UUID, uuid4


from spaps_server_quickstart.domains.auth import repository as repo


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_mock_result(scalar_value=None, scalars_list=None):
    """Build a mock SQLAlchemy result object."""
    result = MagicMock()
    result.scalar_one_or_none.return_value = scalar_value
    if scalars_list is not None:
        scalars_mock = MagicMock()
        scalars_mock.all.return_value = scalars_list
        result.scalars.return_value = scalars_mock
    result.rowcount = 1
    return result


def _make_user(**overrides):
    """Build a mock User object with sensible defaults."""
    user = MagicMock()
    user.id = overrides.get("id", uuid4())
    user.email = overrides.get("email", "test@example.com")
    user.username = overrides.get("username", "testuser")
    user.password_hash = overrides.get("password_hash", "$2b$12$hashedvalue")
    user.tier = overrides.get("tier", "basic")
    user.metadata_ = overrides.get("metadata_", None)
    user.phone_number = overrides.get("phone_number", None)
    user.last_sign_in_at = overrides.get("last_sign_in_at", None)
    user.email_confirmed_at = overrides.get("email_confirmed_at", None)
    user.confirmed_at = overrides.get("confirmed_at", None)
    return user


def _make_wallet(**overrides):
    """Build a mock UserWallet object with sensible defaults."""
    wallet = MagicMock()
    wallet.id = overrides.get("id", uuid4())
    wallet.user_id = overrides.get("user_id", uuid4())
    wallet.wallet_address = overrides.get("wallet_address", "HVEbdiYU3Rr34NHBSgKs7q8cvdTeZLqNL77Z1FB2vjLy")
    wallet.chain_type = overrides.get("chain_type", "solana")
    wallet.is_primary = overrides.get("is_primary", True)
    return wallet


def _make_db():
    """Build a mock AsyncSession."""
    db = AsyncMock()
    db.add = MagicMock()
    db.flush = AsyncMock()
    return db


# ---------------------------------------------------------------------------
# Tests: User lookup helpers
# ---------------------------------------------------------------------------


class TestFindUserForLogin:
    async def test_happy_path_returns_user(self):
        user = _make_user(email="alice@example.com")
        db = _make_db()
        db.execute.return_value = _make_mock_result(scalar_value=user)

        result = await repo.find_user_for_login(db, "alice@example.com")

        assert result is user
        db.execute.assert_called_once()

    async def test_not_found_returns_none(self):
        db = _make_db()
        db.execute.return_value = _make_mock_result(scalar_value=None)

        result = await repo.find_user_for_login(db, "nobody@example.com")

        assert result is None


class TestFindUserWithWallets:
    async def test_returns_user_and_wallets(self):
        user = _make_user()
        wallets = [_make_wallet(user_id=user.id), _make_wallet(user_id=user.id)]
        db = _make_db()

        # First execute returns user, second returns wallets
        db.execute.side_effect = [
            _make_mock_result(scalar_value=user),
            _make_mock_result(scalars_list=wallets),
        ]

        result_user, result_wallets = await repo.find_user_with_wallets(db, str(user.id))

        assert result_user is user
        assert len(result_wallets) == 2
        assert result_wallets[0] is wallets[0]

    async def test_user_not_found_returns_none_and_empty_list(self):
        db = _make_db()
        db.execute.return_value = _make_mock_result(scalar_value=None)

        result_user, result_wallets = await repo.find_user_with_wallets(db, "nonexistent-id")

        assert result_user is None
        assert result_wallets == []


class TestFindUserByWallet:
    async def test_returns_user_and_wallet(self):
        user = _make_user()
        wallet = _make_wallet(user_id=user.id)
        db = _make_db()

        db.execute.side_effect = [
            _make_mock_result(scalar_value=wallet),
            _make_mock_result(scalar_value=user),
        ]

        result_user, result_wallet = await repo.find_user_by_wallet(
            db, wallet.wallet_address, "solana"
        )

        assert result_user is user
        assert result_wallet is wallet

    async def test_not_found_returns_none_none(self):
        db = _make_db()
        db.execute.return_value = _make_mock_result(scalar_value=None)

        result_user, result_wallet = await repo.find_user_by_wallet(
            db, "unknown-address", "solana"
        )

        assert result_user is None
        assert result_wallet is None


class TestCreateUserWithWallet:
    async def test_atomic_creation(self):
        db = _make_db()

        user, wallet = await repo.create_user_with_wallet(
            db, "HVEbdiYU3Rr34NHBSgKs7q8cvdTeZLqNL77Z1FB2vjLy", "solana", username="alice"
        )

        # Two db.add calls (user + wallet), two flush calls
        assert db.add.call_count == 2
        assert db.flush.call_count == 2

        # Verify user attributes
        assert user.username == "alice"
        assert isinstance(user.id, UUID)

        # Verify wallet attributes
        assert wallet.wallet_address == "HVEbdiYU3Rr34NHBSgKs7q8cvdTeZLqNL77Z1FB2vjLy"
        assert wallet.chain_type == "solana"
        assert wallet.is_primary is True
        assert wallet.user_id == user.id


# ---------------------------------------------------------------------------
# Tests: Refresh token persistence
# ---------------------------------------------------------------------------


class TestStoreRefreshToken:
    async def test_stores_token_with_correct_fields(self):
        db = _make_db()
        user_id = str(uuid4())
        app_id = str(uuid4())
        token = "eyJ.refresh.token"
        expires_at = datetime.now(UTC) + timedelta(days=365)

        result = await repo.store_refresh_token(
            db, user_id, app_id, token, expires_at
        )

        db.add.assert_called_once()
        db.flush.assert_called_once()
        expected_hash = hashlib.sha256(token.encode("utf-8")).hexdigest()
        assert result.token == expected_hash
        assert result.user_id == user_id
        assert result.application_id == app_id
        assert result.expires_at == expires_at


class TestFindRefreshToken:
    async def test_happy_path(self):
        token_row = MagicMock()
        token_row.token = "eyJ.refresh.token"
        db = _make_db()
        db.execute.return_value = _make_mock_result(scalar_value=token_row)

        result = await repo.find_refresh_token(db, "eyJ.refresh.token")

        assert result is token_row

    async def test_not_found_returns_none(self):
        db = _make_db()
        db.execute.return_value = _make_mock_result(scalar_value=None)

        result = await repo.find_refresh_token(db, "nonexistent-token")

        assert result is None


class TestFindRefreshTokenForUpdate:
    async def test_happy_path(self):
        token_row = MagicMock()
        token_row.token = "eyJ.refresh.token"
        db = _make_db()
        db.execute.return_value = _make_mock_result(scalar_value=token_row)

        result = await repo.find_refresh_token_for_update(db, "eyJ.refresh.token")

        assert result is token_row

    async def test_not_found_returns_none(self):
        db = _make_db()
        db.execute.return_value = _make_mock_result(scalar_value=None)

        result = await repo.find_refresh_token_for_update(db, "nonexistent-token")

        assert result is None


class TestRevokeRefreshToken:
    async def test_revokes_existing_token(self):
        db = _make_db()
        mock_result = MagicMock()
        mock_result.rowcount = 1
        db.execute.return_value = mock_result

        result = await repo.revoke_refresh_token(db, "eyJ.refresh.token")

        assert result is True

    async def test_returns_false_when_not_found(self):
        db = _make_db()
        mock_result = MagicMock()
        mock_result.rowcount = 0
        db.execute.return_value = mock_result

        result = await repo.revoke_refresh_token(db, "nonexistent-token")

        assert result is False


class TestRevokeAllUserRefreshTokens:
    async def test_bulk_revoke(self):
        db = _make_db()
        mock_result = MagicMock()
        mock_result.rowcount = 3
        db.execute.return_value = mock_result

        count = await repo.revoke_all_user_refresh_tokens(db, str(uuid4()))

        assert count == 3

    async def test_no_tokens_to_revoke(self):
        db = _make_db()
        mock_result = MagicMock()
        mock_result.rowcount = 0
        db.execute.return_value = mock_result

        count = await repo.revoke_all_user_refresh_tokens(db, str(uuid4()))

        assert count == 0


# ---------------------------------------------------------------------------
# Tests: Auth token (password reset, magic link)
# ---------------------------------------------------------------------------


class TestCreateAuthToken:
    async def test_returns_plaintext_and_stores_hash(self):
        db = _make_db()
        user_id = str(uuid4())

        plaintext = await repo.create_auth_token(
            db,
            user_id=user_id,
            email="alice@example.com",
            token_type="password_reset",
            expires_in=3600,
        )

        # Must return a string (the plaintext token)
        assert isinstance(plaintext, str)
        assert len(plaintext) > 20

        # The DB must have received an add + flush
        db.add.assert_called_once()
        db.flush.assert_called_once()

        # Verify the row that was added has the hash, not the plaintext
        added_row = db.add.call_args[0][0]
        expected_hash = hashlib.sha256(plaintext.encode("utf-8")).hexdigest()
        assert added_row.token_hash == expected_hash
        assert added_row.type == "password_reset"
        assert added_row.email == "alice@example.com"


class TestValidateAndConsumeAuthToken:
    async def test_happy_path_consumes_token(self):
        token_row = MagicMock()
        token_row.used_at = None
        db = _make_db()
        db.execute.return_value = _make_mock_result(scalar_value=token_row)

        result = await repo.validate_and_consume_auth_token(
            db, "some-plaintext-token", "password_reset"
        )

        assert result is token_row
        # used_at should be set
        assert token_row.used_at is not None
        db.flush.assert_called_once()

    async def test_expired_or_consumed_returns_none(self):
        db = _make_db()
        db.execute.return_value = _make_mock_result(scalar_value=None)

        result = await repo.validate_and_consume_auth_token(
            db, "expired-token", "password_reset"
        )

        assert result is None

    async def test_already_consumed_returns_none(self):
        db = _make_db()
        db.execute.return_value = _make_mock_result(scalar_value=None)

        result = await repo.validate_and_consume_auth_token(
            db, "used-token", "magic_link"
        )

        assert result is None


# ---------------------------------------------------------------------------
# Tests: Magic-link state
# ---------------------------------------------------------------------------


class TestStoreMagicLinkState:
    async def test_stores_state(self):
        db = _make_db()

        result = await repo.store_magic_link_state(
            db,
            state="random-state-string",
            email="alice@example.com",
            application_id=str(uuid4()),
            expires_in=3600,
        )

        db.add.assert_called_once()
        db.flush.assert_called_once()
        assert result.state == "random-state-string"
        assert result.email == "alice@example.com"


class TestFindMagicLinkState:
    async def test_happy_path(self):
        state_row = MagicMock()
        state_row.state = "valid-state"
        state_row.email = "alice@example.com"
        db = _make_db()
        db.execute.return_value = _make_mock_result(scalar_value=state_row)

        result = await repo.find_magic_link_state(db, "valid-state")

        assert result is state_row

    async def test_expired_returns_none(self):
        db = _make_db()
        db.execute.return_value = _make_mock_result(scalar_value=None)

        result = await repo.find_magic_link_state(db, "expired-state")

        assert result is None
