"""Unit tests for TM-011: Refresh token anomaly detection.

Tests the refresh token rotation flow with network context tracking
(IP address, user agent) and anomaly detection to prevent token replay
attacks.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

from spaps_server_quickstart.domains.auth import service
from spaps_server_quickstart.domains.errors import InvalidRefreshTokenError


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_SERVICE_MODULE = "spaps_server_quickstart.domains.auth.service"
_REPO_MODULE = f"{_SERVICE_MODULE}.repo"
_USER_REPO = "spaps_server_quickstart.domains.users.repository"


def _make_settings(**overrides):
    """Build a mock SpapsSettings."""
    settings = MagicMock()
    settings.jwt_secret = overrides.get("jwt_secret", "test-jwt-secret")
    settings.refresh_token_secret = overrides.get("refresh_token_secret", "test-refresh-secret")
    settings.jwt_expires_in = overrides.get("jwt_expires_in", "1h")
    settings.jwt_refresh_expires_in = overrides.get("jwt_refresh_expires_in", "365d")
    settings.env = overrides.get("env", "test")
    return settings


def _make_user(**overrides):
    """Build a mock User object."""
    user = MagicMock()
    user.id = overrides.get("id", uuid4())
    user.email = overrides.get("email", "alice@example.com")
    user.username = overrides.get("username", "alice")
    user.tier = overrides.get("tier", "basic")
    user.metadata_ = None
    user.phone_number = None
    return user


def _make_token_pair():
    """Build a mock TokenPair."""
    tp = MagicMock()
    tp.access_token = "eyJ.new.access.token"
    tp.refresh_token = "eyJ.new.refresh.token"
    tp.expires_in = 3600
    return tp


def _make_refresh_payload(**overrides):
    """Build a mock RefreshTokenPayload."""
    payload = MagicMock()
    payload.sub = overrides.get("sub", str(uuid4()))
    payload.app_id = overrides.get("app_id", "test-app-id")
    payload.jti = overrides.get("jti", str(uuid4()))
    payload.email = overrides.get("email", "alice@example.com")
    payload.roles = overrides.get("roles", ["user"])
    payload.isAdmin = overrides.get("isAdmin", False)
    payload.exp = overrides.get("exp", int((datetime.now(UTC) + timedelta(days=1)).timestamp()))
    return payload


def _make_refresh_token(**overrides):
    """Build a mock RefreshToken model."""
    token = MagicMock()
    token.id = overrides.get("id", uuid4())
    token.user_id = overrides.get("user_id", uuid4())
    token.application_id = overrides.get("application_id", None)
    token.token = overrides.get("token", "hashed_token_value")
    token.expires_at = overrides.get("expires_at", datetime.now(UTC) + timedelta(days=1))
    token.used_at = overrides.get("used_at", None)
    token.created_at = overrides.get("created_at", datetime.now(UTC) - timedelta(hours=1))
    # Network context fields (TM-011)
    token.issued_ip = overrides.get("issued_ip", "192.168.1.100")
    token.issued_user_agent = overrides.get("issued_user_agent", "Mozilla/5.0 (Windows)")
    token.last_seen_ip = overrides.get("last_seen_ip", "192.168.1.100")
    token.last_seen_user_agent = overrides.get("last_seen_user_agent", "Mozilla/5.0 (Windows)")
    token.anomaly_state = overrides.get("anomaly_state", None)
    return token


def _make_db():
    """Build a mock AsyncSession."""
    db = AsyncMock()
    db.flush = AsyncMock()
    db.add = MagicMock()
    return db


# ---------------------------------------------------------------------------
# Test: Same-device refresh (stable IP/UA) → rotates successfully, no anomaly
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_refresh_tokens_same_device_no_anomaly():
    """When IP and UA match the stored values, refresh succeeds with no anomaly."""
    db = _make_db()
    settings = _make_settings()
    user = _make_user()
    payload = _make_refresh_payload(sub=str(user.id))
    db_token = _make_refresh_token(
        user_id=user.id,
        issued_ip="192.168.1.100",
        issued_user_agent="Mozilla/5.0 (Windows)",
        last_seen_ip="192.168.1.100",
        last_seen_user_agent="Mozilla/5.0 (Windows)",
        anomaly_state=None,
    )
    token_pair = _make_token_pair()

    with (
        patch(f"{_SERVICE_MODULE}.verify_refresh_token", return_value=payload),
        patch(f"{_SERVICE_MODULE}.blacklist_service.is_blacklisted", return_value=False),
        patch(f"{_REPO_MODULE}.find_refresh_token_for_update", return_value=db_token),
        patch(f"{_REPO_MODULE}.revoke_refresh_token", return_value=True),
        patch(f"{_USER_REPO}.get_user_by_id", new_callable=AsyncMock, return_value=user),
        patch(f"{_SERVICE_MODULE}._resolve_roles_and_permissions", return_value=(["user"], ["view_products"], False, False)),
        patch(f"{_SERVICE_MODULE}._generate_and_store_tokens", return_value=token_pair),
    ):
        result = await service.refresh_tokens(
            db,
            settings,
            refresh_token_str="old.refresh.token",
            client_ip="192.168.1.100",
            user_agent="Mozilla/5.0 (Windows)",
        )

    # Assert: Token pair returned
    assert result["access_token"] == token_pair.access_token
    assert result["refresh_token"] == token_pair.refresh_token
    assert result["token_type"] == "Bearer"

    # Assert: No anomaly state set (db_token.anomaly_state should remain None)
    assert db_token.anomaly_state is None


# ---------------------------------------------------------------------------
# Test: Changed IP/UA in alert-only mode → rotates successfully BUT emits anomaly event
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_refresh_tokens_changed_ip_alert_mode():
    """When IP/UA change and enforcement is disabled, refresh succeeds but logs anomaly."""
    db = _make_db()
    settings = _make_settings()
    user = _make_user()
    payload = _make_refresh_payload(sub=str(user.id))
    db_token = _make_refresh_token(
        user_id=user.id,
        issued_ip="192.168.1.100",
        issued_user_agent="Mozilla/5.0 (Windows)",
        last_seen_ip="192.168.1.100",
        last_seen_user_agent="Mozilla/5.0 (Windows)",
        anomaly_state=None,
    )
    token_pair = _make_token_pair()

    # Mock enforcement disabled (alert-only mode)
    settings.refresh_anomaly_enforcement_enabled = False
    with (
        patch(f"{_SERVICE_MODULE}.verify_refresh_token", return_value=payload),
        patch(f"{_SERVICE_MODULE}.blacklist_service.is_blacklisted", return_value=False),
        patch(f"{_REPO_MODULE}.find_refresh_token_for_update", return_value=db_token),
        patch(f"{_REPO_MODULE}.revoke_refresh_token", return_value=True),
        patch(f"{_USER_REPO}.get_user_by_id", new_callable=AsyncMock, return_value=user),
        patch(f"{_SERVICE_MODULE}._resolve_roles_and_permissions", return_value=(["user"], ["view_products"], False, False)),
        patch(f"{_SERVICE_MODULE}._generate_and_store_tokens", return_value=token_pair),
        patch(f"{_SERVICE_MODULE}.logger") as mock_logger,
    ):
        result = await service.refresh_tokens(
            db,
            settings,
            refresh_token_str="old.refresh.token",
            client_ip="10.0.0.50",  # Different IP
            user_agent="Mozilla/5.0 (Macintosh)",  # Different UA
        )

    # Assert: Token pair returned (refresh succeeded despite anomaly)
    assert result["access_token"] == token_pair.access_token
    assert result["refresh_token"] == token_pair.refresh_token

    # Assert: Anomaly logged with structured event
    mock_logger.warning.assert_called_once()
    call_args = mock_logger.warning.call_args
    assert "Refresh token anomaly detected" in call_args[0][0]
    assert call_args[1]["extra"]["threat_id"] == "TM-011"
    assert call_args[1]["extra"]["decision"] == "alert"

    # Assert: Anomaly state updated to "alert"
    assert db_token.anomaly_state == "alert"


# ---------------------------------------------------------------------------
# Test: Changed IP/UA in enforcement mode → denied with REFRESH_TOKEN_ANOMALOUS
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_refresh_tokens_changed_ip_enforcement_mode():
    """When IP/UA change and enforcement is enabled, refresh is denied."""
    db = _make_db()
    settings = _make_settings()
    user = _make_user()
    payload = _make_refresh_payload(sub=str(user.id))
    db_token = _make_refresh_token(
        user_id=user.id,
        issued_ip="192.168.1.100",
        issued_user_agent="Mozilla/5.0 (Windows)",
        last_seen_ip="192.168.1.100",
        last_seen_user_agent="Mozilla/5.0 (Windows)",
        anomaly_state=None,
    )

    # Mock enforcement enabled
    settings.refresh_anomaly_enforcement_enabled = True
    with (
        patch(f"{_SERVICE_MODULE}.verify_refresh_token", return_value=payload),
        patch(f"{_SERVICE_MODULE}.blacklist_service.is_blacklisted", return_value=False),
        patch(f"{_REPO_MODULE}.find_refresh_token_for_update", return_value=db_token),
        patch(f"{_REPO_MODULE}.revoke_refresh_token", return_value=True),
        patch(f"{_SERVICE_MODULE}.logger") as mock_logger,
    ):
        with pytest.raises(InvalidRefreshTokenError) as exc_info:
            await service.refresh_tokens(
                db,
                settings,
                refresh_token_str="old.refresh.token",
                client_ip="10.0.0.50",  # Different IP
                user_agent="Mozilla/5.0 (Macintosh)",  # Different UA
            )

    # Assert: Error code is REFRESH_TOKEN_ANOMALOUS
    assert exc_info.value.code == "REFRESH_TOKEN_ANOMALOUS"
    assert "Network context anomaly detected" in str(exc_info.value)

    # Assert: Anomaly logged with structured event
    mock_logger.error.assert_called_once()
    call_args = mock_logger.error.call_args
    assert "Refresh token anomaly detected" in call_args[0][0]
    assert call_args[1]["extra"]["threat_id"] == "TM-011"
    assert call_args[1]["extra"]["decision"] == "blocked"

    # Assert: Anomaly state updated to "blocked"
    assert db_token.anomaly_state == "blocked"

    # Assert: Old token was revoked
    # Note: This is important for security - even though we deny the refresh,
    # we must revoke the token to prevent further attempts


# ---------------------------------------------------------------------------
# Test: IP-only change in enforcement mode → alert-only (no hard block)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_refresh_tokens_ip_only_change_enforcement_mode_alerts():
    """When only IP changes, enforcement mode should alert but still rotate."""
    db = _make_db()
    settings = _make_settings()
    user = _make_user()
    payload = _make_refresh_payload(sub=str(user.id))
    db_token = _make_refresh_token(
        user_id=user.id,
        issued_ip="192.168.1.100",
        issued_user_agent="Mozilla/5.0 (Windows)",
        last_seen_ip="192.168.1.100",
        last_seen_user_agent="Mozilla/5.0 (Windows)",
        anomaly_state=None,
    )
    token_pair = _make_token_pair()

    settings.refresh_anomaly_enforcement_enabled = True
    with (
        patch(f"{_SERVICE_MODULE}.verify_refresh_token", return_value=payload),
        patch(f"{_SERVICE_MODULE}.blacklist_service.is_blacklisted", return_value=False),
        patch(f"{_REPO_MODULE}.find_refresh_token_for_update", return_value=db_token),
        patch(f"{_REPO_MODULE}.revoke_refresh_token", return_value=True),
        patch(f"{_USER_REPO}.get_user_by_id", new_callable=AsyncMock, return_value=user),
        patch(f"{_SERVICE_MODULE}._resolve_roles_and_permissions", return_value=(["user"], ["view_products"], False, False)),
        patch(f"{_SERVICE_MODULE}._generate_and_store_tokens", return_value=token_pair),
        patch(f"{_SERVICE_MODULE}.logger") as mock_logger,
    ):
        result = await service.refresh_tokens(
            db,
            settings,
            refresh_token_str="old.refresh.token",
            client_ip="10.0.0.50",  # Different IP
            user_agent="Mozilla/5.0 (Windows)",  # Same UA
        )

    assert result["access_token"] == token_pair.access_token
    assert result["refresh_token"] == token_pair.refresh_token
    assert db_token.anomaly_state == "alert"

    mock_logger.warning.assert_called_once()
    warning_args = mock_logger.warning.call_args
    assert warning_args[1]["extra"]["decision"] == "alert"
    assert warning_args[1]["extra"]["reason"] == "ip_changed=True, ua_changed=False"


# ---------------------------------------------------------------------------
# Test: Missing network context (backwards compatibility)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_refresh_tokens_missing_network_context():
    """When no IP/UA is provided, refresh still works (backwards compatibility)."""
    db = _make_db()
    settings = _make_settings()
    user = _make_user()
    payload = _make_refresh_payload(sub=str(user.id))
    db_token = _make_refresh_token(
        user_id=user.id,
        issued_ip=None,  # No network context stored
        issued_user_agent=None,
        last_seen_ip=None,
        last_seen_user_agent=None,
        anomaly_state=None,
    )
    token_pair = _make_token_pair()

    with (
        patch(f"{_SERVICE_MODULE}.verify_refresh_token", return_value=payload),
        patch(f"{_SERVICE_MODULE}.blacklist_service.is_blacklisted", return_value=False),
        patch(f"{_REPO_MODULE}.find_refresh_token_for_update", return_value=db_token),
        patch(f"{_REPO_MODULE}.revoke_refresh_token", return_value=True),
        patch(f"{_USER_REPO}.get_user_by_id", new_callable=AsyncMock, return_value=user),
        patch(f"{_SERVICE_MODULE}._resolve_roles_and_permissions", return_value=(["user"], ["view_products"], False, False)),
        patch(f"{_SERVICE_MODULE}._generate_and_store_tokens", return_value=token_pair),
    ):
        result = await service.refresh_tokens(
            db,
            settings,
            refresh_token_str="old.refresh.token",
            client_ip=None,  # No IP provided
            user_agent=None,  # No UA provided
        )

    # Assert: Token pair returned (refresh succeeded)
    assert result["access_token"] == token_pair.access_token
    assert result["refresh_token"] == token_pair.refresh_token

    # Assert: No anomaly state (cannot detect anomaly without baseline)
    assert db_token.anomaly_state is None
