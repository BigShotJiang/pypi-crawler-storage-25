"""Unit tests for the auth domain router (HTTP layer).

Each test creates a minimal FastAPI test app with dependency overrides for
the database session, application, and current user.  The auth service
layer is fully mocked so tests exercise only routing, request validation,
status codes, and response shapes.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from spaps_server_quickstart.domains.auth.router import router
from spaps_server_quickstart.domains.errors import (
    EmailAlreadyExistsError,
    InvalidCredentialsError,
    InvalidRefreshTokenError,
    InvalidSignatureError,
    InvalidTokenError,
    WeakPasswordError,
)
from spaps_server_quickstart.middleware.spaps_deps import (
    get_application,
    get_current_user,
    get_db_session,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_SERVICE_MODULE = "spaps_server_quickstart.domains.auth.service"


def _mock_current_user():
    """Build a mock authenticated user for JWT-protected endpoints."""
    user = MagicMock()
    user.id = str(uuid4())
    user.jti = "test-jti"
    user.application_id = "test-app"
    user.tier = "basic"
    user.wallet_addresses = []
    user.exp = 9999999999
    return user


def _create_test_app(current_user=None):
    """Create a FastAPI test app with overridden dependencies."""
    app = FastAPI()

    # Store mock settings on app.state
    settings = MagicMock()
    settings.jwt_secret = "test-secret"
    settings.refresh_token_secret = "test-refresh-secret"
    settings.jwt_expires_in = "1h"
    settings.jwt_refresh_expires_in = "365d"
    settings.env = "test"
    app.state.settings = settings

    # Register the domain error handler so DomainErrors produce correct status codes
    from spaps_server_quickstart.domains.errors import DomainError

    @app.exception_handler(DomainError)
    async def _domain_error_handler(request, exc):
        from fastapi.responses import JSONResponse

        return JSONResponse(
            status_code=exc.status_code,
            content={
                "success": False,
                "error": {"code": exc.code, "message": exc.message},
            },
        )

    app.include_router(router)

    # Override dependencies
    mock_db = AsyncMock()
    mock_app_obj = MagicMock(id="test-app-id")

    app.dependency_overrides[get_db_session] = lambda: mock_db
    app.dependency_overrides[get_application] = lambda: mock_app_obj

    if current_user is not None:
        app.dependency_overrides[get_current_user] = lambda: current_user

    return app


async def _client(app: FastAPI):
    """Create an httpx async client for the given app."""
    transport = ASGITransport(app=app)
    return AsyncClient(transport=transport, base_url="http://test")


# ---------------------------------------------------------------------------
# Tests: POST /auth/login
# ---------------------------------------------------------------------------


class TestLoginRouter:
    @patch(f"{_SERVICE_MODULE}.login", new_callable=AsyncMock)
    async def test_success(self, mock_login):
        mock_login.return_value = {
            "access_token": "at",
            "refresh_token": "rt",
            "expires_in": 3600,
            "user": {
                "id": "uid-1",
                "username": "alice",
                "email": "alice@example.com",
                "phone_number": None,
                "wallets": None,
                "tier": "basic",
                "roles": ["user"],
                "permissions": ["view_products"],
                "isAdmin": False,
                "metadata": None,
            },
        }

        app = _create_test_app()
        async with await _client(app) as c:
            resp = await c.post(
                "/auth/login",
                json={"email": "alice@example.com", "password": "Passw0rd!"},
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["access_token"] == "at"
        assert data["user"]["email"] == "alice@example.com"

    @patch(f"{_SERVICE_MODULE}.login", new_callable=AsyncMock)
    async def test_invalid_credentials_returns_401(self, mock_login):
        mock_login.side_effect = InvalidCredentialsError("Invalid email or password")

        app = _create_test_app()
        async with await _client(app) as c:
            resp = await c.post(
                "/auth/login",
                json={"email": "alice@example.com", "password": "wrong"},
            )

        assert resp.status_code == 401
        data = resp.json()
        assert data["success"] is False
        assert data["error"]["code"] == "INVALID_CREDENTIALS"


# ---------------------------------------------------------------------------
# Tests: POST /auth/register
# ---------------------------------------------------------------------------


class TestRegisterRouter:
    @patch(f"{_SERVICE_MODULE}.register", new_callable=AsyncMock)
    async def test_success(self, mock_register):
        mock_register.return_value = {
            "tokens": {
                "access_token": "at",
                "refresh_token": "rt",
                "expires_in": 3600,
            },
            "token_type": "Bearer",
            "user": {
                "id": "uid-1",
                "username": "alice",
                "email": "alice@example.com",
                "phone_number": None,
                "wallets": None,
                "tier": "basic",
                "roles": ["user"],
                "permissions": ["view_products"],
                "isAdmin": False,
                "metadata": None,
            },
            "email_confirmed": True,
        }

        app = _create_test_app()
        async with await _client(app) as c:
            resp = await c.post(
                "/auth/register",
                json={
                    "email": "alice@example.com",
                    "password": "Passw0rd!",
                    "username": "alice",
                },
            )

        assert resp.status_code == 201
        data = resp.json()
        assert data["tokens"]["access_token"] == "at"
        assert data["email_confirmed"] is True

    @patch(f"{_SERVICE_MODULE}.register", new_callable=AsyncMock)
    async def test_passes_referral_fields_to_service(self, mock_register):
        mock_register.return_value = {
            "tokens": {
                "access_token": "at",
                "refresh_token": "rt",
                "expires_in": 3600,
            },
            "token_type": "Bearer",
            "user": {
                "id": "uid-1",
                "username": "alice",
                "email": "alice@example.com",
                "phone_number": None,
                "wallets": None,
                "tier": "basic",
                "roles": ["user"],
                "permissions": ["view_products"],
                "isAdmin": False,
                "metadata": None,
            },
            "email_confirmed": True,
        }

        referral_click_id = str(uuid4())
        app = _create_test_app()
        async with await _client(app) as c:
            resp = await c.post(
                "/auth/register",
                json={
                    "email": "alice@example.com",
                    "password": "Passw0rd!",
                    "referral_click_id": referral_click_id,
                    "ref": "partner-bot",
                },
            )

        assert resp.status_code == 201
        kwargs = mock_register.await_args.kwargs
        assert kwargs["referral_click_id"] == referral_click_id
        assert kwargs["referral_slug"] == "partner-bot"

    @patch(f"{_SERVICE_MODULE}.register", new_callable=AsyncMock)
    async def test_duplicate_email_returns_400(self, mock_register):
        mock_register.side_effect = EmailAlreadyExistsError("Email already registered")

        app = _create_test_app()
        async with await _client(app) as c:
            resp = await c.post(
                "/auth/register",
                json={"email": "alice@example.com", "password": "Passw0rd!"},
            )

        assert resp.status_code == 400
        data = resp.json()
        assert data["error"]["code"] == "EMAIL_ALREADY_EXISTS"

    @patch(f"{_SERVICE_MODULE}.register", new_callable=AsyncMock)
    async def test_weak_password_returns_400(self, mock_register):
        mock_register.side_effect = WeakPasswordError(
            "Password must contain: at least 8 characters"
        )

        app = _create_test_app()
        async with await _client(app) as c:
            resp = await c.post(
                "/auth/register",
                json={"email": "alice@example.com", "password": "weak"},
            )

        assert resp.status_code == 400
        data = resp.json()
        assert data["error"]["code"] == "WEAK_PASSWORD"


# ---------------------------------------------------------------------------
# Tests: POST /auth/refresh
# ---------------------------------------------------------------------------


class TestRefreshRouter:
    @patch(f"{_SERVICE_MODULE}.refresh_tokens", new_callable=AsyncMock)
    async def test_success(self, mock_refresh):
        mock_refresh.return_value = {
            "access_token": "new-at",
            "refresh_token": "new-rt",
            "expires_in": 3600,
        }

        app = _create_test_app()
        async with await _client(app) as c:
            resp = await c.post(
                "/auth/refresh",
                json={"refresh_token": "old-rt"},
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["access_token"] == "new-at"

    @patch(f"{_SERVICE_MODULE}.refresh_tokens", new_callable=AsyncMock)
    async def test_invalid_token_returns_401(self, mock_refresh):
        mock_refresh.side_effect = InvalidRefreshTokenError("Refresh token expired")

        app = _create_test_app()
        async with await _client(app) as c:
            resp = await c.post(
                "/auth/refresh",
                json={"refresh_token": "expired-rt"},
            )

        assert resp.status_code == 401
        data = resp.json()
        assert data["error"]["code"] == "INVALID_REFRESH_TOKEN"


# ---------------------------------------------------------------------------
# Tests: POST /auth/nonce
# ---------------------------------------------------------------------------


class TestNonceRouter:
    @patch(f"{_SERVICE_MODULE}.request_nonce", new_callable=AsyncMock)
    async def test_success(self, mock_nonce):
        mock_nonce.return_value = {
            "nonce": "abc123",
            "message": "Sign this message",
            "wallet_address": "HVEbdiYU3Rr34NHBSgKs7q8cvdTeZLqNL77Z1FB2vjLy",
            "expires_at": "2025-01-01T00:05:00+00:00",
        }

        app = _create_test_app()
        async with await _client(app) as c:
            resp = await c.post(
                "/auth/nonce",
                json={"wallet_address": "HVEbdiYU3Rr34NHBSgKs7q8cvdTeZLqNL77Z1FB2vjLy"},
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["nonce"] == "abc123"
        assert data["wallet_address"] == "HVEbdiYU3Rr34NHBSgKs7q8cvdTeZLqNL77Z1FB2vjLy"


# ---------------------------------------------------------------------------
# Tests: POST /auth/wallet-sign-in
# ---------------------------------------------------------------------------


class TestWalletSignInRouter:
    @patch(f"{_SERVICE_MODULE}.wallet_sign_in", new_callable=AsyncMock)
    async def test_success(self, mock_wallet_sign_in):
        mock_wallet_sign_in.return_value = {
            "access_token": "at",
            "refresh_token": "rt",
            "expires_in": 3600,
            "user": {
                "id": "uid-1",
                "username": None,
                "email": None,
                "phone_number": None,
                "wallets": [
                    {"address": "HVEbdi...", "chain_type": "solana", "is_primary": True}
                ],
                "tier": "basic",
                "roles": ["user"],
                "permissions": ["view_products"],
                "isAdmin": False,
                "metadata": None,
            },
            "is_new_user": True,
        }

        app = _create_test_app()
        async with await _client(app) as c:
            resp = await c.post(
                "/auth/wallet-sign-in",
                json={
                    "wallet_address": "HVEbdiYU3Rr34NHBSgKs7q8cvdTeZLqNL77Z1FB2vjLy",
                    "signature": "valid-sig",
                    "message": "Sign this\nNonce: abc123",
                },
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["is_new_user"] is True

    @patch(f"{_SERVICE_MODULE}.wallet_sign_in", new_callable=AsyncMock)
    async def test_invalid_signature_returns_401(self, mock_wallet_sign_in):
        mock_wallet_sign_in.side_effect = InvalidSignatureError(
            "Wallet signature verification failed"
        )

        app = _create_test_app()
        async with await _client(app) as c:
            resp = await c.post(
                "/auth/wallet-sign-in",
                json={
                    "wallet_address": "HVEbdiYU3Rr34NHBSgKs7q8cvdTeZLqNL77Z1FB2vjLy",
                    "signature": "bad-sig",
                    "message": "Sign this\nNonce: abc123",
                },
            )

        assert resp.status_code == 401
        data = resp.json()
        assert data["error"]["code"] == "INVALID_SIGNATURE"


# ---------------------------------------------------------------------------
# Tests: POST /auth/magic-link
# ---------------------------------------------------------------------------


class TestMagicLinkRouter:
    @patch(f"{_SERVICE_MODULE}.request_magic_link", new_callable=AsyncMock)
    async def test_success(self, mock_magic_link):
        mock_magic_link.return_value = {
            "message": "Magic link sent successfully",
            "email": "alice@example.com",
            "sent_at": "2025-01-01T00:00:00+00:00",
            "state": None,
        }

        app = _create_test_app()
        async with await _client(app) as c:
            resp = await c.post(
                "/auth/magic-link",
                json={
                    "email": "alice@example.com",
                    "redirect_url": "https://unclawg.com/auth/cli-callback",
                },
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["email"] == "alice@example.com"
        assert mock_magic_link.await_count == 1
        assert mock_magic_link.await_args.kwargs["email"] == "alice@example.com"
        assert (
            mock_magic_link.await_args.kwargs["redirect_url"]
            == "https://unclawg.com/auth/cli-callback"
        )


# ---------------------------------------------------------------------------
# Tests: POST /auth/verify-magic-link
# ---------------------------------------------------------------------------


class TestVerifyMagicLinkRouter:
    @patch(f"{_SERVICE_MODULE}.verify_magic_link", new_callable=AsyncMock)
    async def test_success(self, mock_verify):
        mock_verify.return_value = {
            "tokens": {
                "access_token": "at",
                "refresh_token": "rt",
                "expires_in": 3600,
            },
            "token_type": "Bearer",
            "user": {
                "id": "uid-1",
                "username": None,
                "email": "alice@example.com",
                "phone_number": None,
                "wallets": None,
                "tier": "basic",
                "roles": ["user"],
                "permissions": ["view_products"],
                "isAdmin": False,
                "metadata": None,
            },
        }

        app = _create_test_app()
        async with await _client(app) as c:
            resp = await c.post(
                "/auth/verify-magic-link",
                json={"token": "valid-token", "type": "magic_link"},
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["tokens"]["access_token"] == "at"

    @patch(f"{_SERVICE_MODULE}.verify_magic_link", new_callable=AsyncMock)
    async def test_invalid_token_returns_401(self, mock_verify):
        mock_verify.side_effect = InvalidTokenError(
            "Invalid, expired, or already-used magic link"
        )

        app = _create_test_app()
        async with await _client(app) as c:
            resp = await c.post(
                "/auth/verify-magic-link",
                json={"token": "bad-token", "type": "magic_link"},
            )

        assert resp.status_code == 401
        data = resp.json()
        assert data["error"]["code"] == "INVALID_TOKEN"


# ---------------------------------------------------------------------------
# Tests: POST /auth/password-reset
# ---------------------------------------------------------------------------


class TestPasswordResetRouter:
    @patch(f"{_SERVICE_MODULE}.request_password_reset", new_callable=AsyncMock)
    async def test_always_returns_200(self, mock_reset):
        mock_reset.return_value = {
            "email": "unknown@example.com",
            "sent_at": "2025-01-01T00:00:00+00:00",
        }

        app = _create_test_app()
        async with await _client(app) as c:
            resp = await c.post(
                "/auth/password-reset",
                json={
                    "email": "unknown@example.com",
                    "redirect_url": "https://unclawg.com/reset-password",
                },
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["email"] == "unknown@example.com"
        assert mock_reset.await_count == 1
        assert mock_reset.await_args.kwargs["email"] == "unknown@example.com"
        assert (
            mock_reset.await_args.kwargs["redirect_url"]
            == "https://unclawg.com/reset-password"
        )


# ---------------------------------------------------------------------------
# Tests: POST /auth/reset-password-confirm
# ---------------------------------------------------------------------------


class TestPasswordResetConfirmRouter:
    @patch(f"{_SERVICE_MODULE}.confirm_password_reset", new_callable=AsyncMock)
    async def test_success(self, mock_confirm):
        mock_confirm.return_value = {
            "message": "Password has been reset successfully",
        }

        app = _create_test_app()
        async with await _client(app) as c:
            resp = await c.post(
                "/auth/reset-password-confirm",
                json={"token": "valid-token", "new_password": "NewPassw0rd!"},
            )

        assert resp.status_code == 200
        data = resp.json()
        assert "reset successfully" in data["message"].lower()

    @patch(f"{_SERVICE_MODULE}.confirm_password_reset", new_callable=AsyncMock)
    async def test_invalid_token_returns_401(self, mock_confirm):
        mock_confirm.side_effect = InvalidTokenError(
            "Invalid, expired, or already-used reset token"
        )

        app = _create_test_app()
        async with await _client(app) as c:
            resp = await c.post(
                "/auth/reset-password-confirm",
                json={"token": "bad-token", "new_password": "NewPassw0rd!"},
            )

        assert resp.status_code == 401
        data = resp.json()
        assert data["error"]["code"] == "INVALID_TOKEN"


# ---------------------------------------------------------------------------
# Tests: POST /auth/set-password (JWT required)
# ---------------------------------------------------------------------------


class TestSetPasswordRouter:
    @patch(f"{_SERVICE_MODULE}.set_password", new_callable=AsyncMock)
    async def test_success(self, mock_set_pw):
        mock_set_pw.return_value = {
            "message": "Password updated successfully",
        }

        user = _mock_current_user()
        app = _create_test_app(current_user=user)
        async with await _client(app) as c:
            resp = await c.post(
                "/auth/set-password",
                json={
                    "current_password": "OldPassw0rd!",
                    "new_password": "NewPassw0rd!",
                },
            )

        assert resp.status_code == 200
        data = resp.json()
        assert "updated" in data["message"].lower()


# ---------------------------------------------------------------------------
# Tests: GET /auth/user (JWT required)
# ---------------------------------------------------------------------------


class TestGetMeRouter:
    @patch(f"{_SERVICE_MODULE}.get_me", new_callable=AsyncMock)
    async def test_success(self, mock_get_me):
        mock_get_me.return_value = {
            "user": {
                "id": "uid-1",
                "username": "alice",
                "email": "alice@example.com",
                "phone_number": None,
                "wallets": [
                    {"address": "HVEbdi...", "chain_type": "solana", "is_primary": True}
                ],
                "tier": "basic",
                "roles": ["user"],
                "permissions": ["view_products"],
                "isAdmin": False,
                "metadata": None,
            },
        }

        user = _mock_current_user()
        app = _create_test_app(current_user=user)
        async with await _client(app) as c:
            resp = await c.get("/auth/user")

        assert resp.status_code == 200
        data = resp.json()
        assert data["user"]["email"] == "alice@example.com"
        assert data["user"]["wallets"] is not None


# ---------------------------------------------------------------------------
# Tests: POST /auth/logout (JWT required)
# ---------------------------------------------------------------------------


class TestLogoutRouter:
    @patch(f"{_SERVICE_MODULE}.logout", new_callable=AsyncMock)
    async def test_success(self, mock_logout):
        mock_logout.return_value = {
            "message": "Successfully logged out",
        }

        user = _mock_current_user()
        app = _create_test_app(current_user=user)

        # Add jwt_payload to request state via middleware
        @app.middleware("http")
        async def add_jwt_payload(request, call_next):
            request.state.jwt_payload = {"jti": "test-jti", "exp": 9999999999}
            return await call_next(request)

        async with await _client(app) as c:
            resp = await c.post("/auth/logout")

        assert resp.status_code == 200
        data = resp.json()
        assert "logged out" in data["message"].lower()
