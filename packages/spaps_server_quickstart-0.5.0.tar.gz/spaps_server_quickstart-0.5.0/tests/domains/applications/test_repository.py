"""Unit tests for the applications domain repository layer.

Mocks the AsyncSession to test each repository function in isolation
without hitting a real database.
"""

from __future__ import annotations

from datetime import datetime, UTC
from unittest.mock import AsyncMock, MagicMock
from uuid import UUID, uuid4


from spaps_server_quickstart.domains.applications import repository as repo
from spaps_server_quickstart.domains.applications.models import Application


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_application(
    app_id: str | None = None,
    name: str = "Test App",
    slug: str = "test-app",
    api_key: str = "sk_test_key_123",
    publishable_key_hash: str | None = None,
    secret_key_hash: str | None = None,
    settings: dict | None = None,
) -> MagicMock:
    """Return a mock Application with sensible defaults."""
    app = MagicMock(spec=Application)
    app.id = UUID(app_id) if app_id else uuid4()
    app.name = name
    app.slug = slug
    app.api_key = api_key
    app.description = None
    app.allowed_origins = None
    app.webhook_url = None
    app.settings = settings
    app.whitelist_enabled = False
    app.whitelist_count = 0
    app.publishable_key_hash = publishable_key_hash
    app.secret_key_hash = secret_key_hash
    app.created_at = datetime.now(UTC)
    app.updated_at = datetime.now(UTC)
    return app


def _mock_session() -> AsyncMock:
    """Create a mock AsyncSession with the common interface."""
    session = AsyncMock()
    session.add = MagicMock()
    session.flush = AsyncMock()
    session.refresh = AsyncMock()
    session.execute = AsyncMock()
    return session


# ---------------------------------------------------------------------------
# get_application_by_id
# ---------------------------------------------------------------------------


class TestGetApplicationById:
    async def test_returns_app_when_found(self):
        app = _make_application()
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = app
        db.execute.return_value = result_mock

        result = await repo.get_application_by_id(db, str(app.id))

        assert result is app
        db.execute.assert_awaited_once()

    async def test_returns_none_when_not_found(self):
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute.return_value = result_mock

        result = await repo.get_application_by_id(db, str(uuid4()))

        assert result is None


# ---------------------------------------------------------------------------
# get_application_by_api_key
# ---------------------------------------------------------------------------


class TestGetApplicationByApiKey:
    async def test_returns_app_when_found(self):
        app = _make_application(api_key="sk_live_abc123")
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = app
        db.execute.return_value = result_mock

        result = await repo.get_application_by_api_key(db, "sk_live_abc123")

        assert result is app
        assert result.api_key == "sk_live_abc123"

    async def test_returns_none_when_not_found(self):
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute.return_value = result_mock

        result = await repo.get_application_by_api_key(db, "invalid_key")

        assert result is None


# ---------------------------------------------------------------------------
# get_application_by_publishable_key_hash
# ---------------------------------------------------------------------------


class TestGetApplicationByPublishableKeyHash:
    async def test_returns_app_when_found(self):
        app = _make_application(publishable_key_hash="pub_hash_123")
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = app
        db.execute.return_value = result_mock

        result = await repo.get_application_by_publishable_key_hash(
            db, "pub_hash_123"
        )

        assert result is app
        assert result.publishable_key_hash == "pub_hash_123"

    async def test_returns_none_when_not_found(self):
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute.return_value = result_mock

        result = await repo.get_application_by_publishable_key_hash(
            db, "nonexistent_hash"
        )

        assert result is None


# ---------------------------------------------------------------------------
# get_application_by_secret_key_hash
# ---------------------------------------------------------------------------


class TestGetApplicationBySecretKeyHash:
    async def test_returns_app_when_found(self):
        app = _make_application(secret_key_hash="sec_hash_456")
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = app
        db.execute.return_value = result_mock

        result = await repo.get_application_by_secret_key_hash(
            db, "sec_hash_456"
        )

        assert result is app
        assert result.secret_key_hash == "sec_hash_456"

    async def test_returns_none_when_not_found(self):
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute.return_value = result_mock

        result = await repo.get_application_by_secret_key_hash(
            db, "nonexistent_hash"
        )

        assert result is None


# ---------------------------------------------------------------------------
# create_application
# ---------------------------------------------------------------------------


class TestCreateApplication:
    async def test_creates_and_flushes(self):
        db = _mock_session()

        async def _fake_refresh(obj):
            obj.id = uuid4()
            obj.created_at = datetime.now(UTC)
            obj.updated_at = datetime.now(UTC)

        db.refresh.side_effect = _fake_refresh

        result = await repo.create_application(
            db,
            name="My App",
            api_key="sk_new_key",
            slug="my-app",
            description="A test app",
        )

        assert result.name == "My App"
        assert result.api_key == "sk_new_key"
        assert result.slug == "my-app"
        assert result.description == "A test app"
        db.add.assert_called_once()
        db.flush.assert_awaited_once()
        db.refresh.assert_awaited_once()

    async def test_creates_with_minimal_args(self):
        db = _mock_session()

        result = await repo.create_application(
            db, name="Minimal", api_key="sk_min"
        )

        assert result.name == "Minimal"
        assert result.api_key == "sk_min"
        db.add.assert_called_once()

    async def test_extra_kwargs_applied_if_valid(self):
        db = _mock_session()

        result = await repo.create_application(
            db,
            name="Extra",
            api_key="sk_extra",
            webhook_url="https://hook.example.com",
            publishable_key_hash="pub_hash",
            secret_key_hash="sec_hash",
        )

        assert result.webhook_url == "https://hook.example.com"
        assert result.publishable_key_hash == "pub_hash"
        assert result.secret_key_hash == "sec_hash"

    async def test_unknown_kwargs_ignored(self):
        db = _mock_session()

        result = await repo.create_application(
            db,
            name="Ignored",
            api_key="sk_ignored",
            totally_fake_field="should_be_ignored",
        )

        assert not hasattr(result, "totally_fake_field") or getattr(result, "totally_fake_field", None) != "should_be_ignored"


# ---------------------------------------------------------------------------
# update_application
# ---------------------------------------------------------------------------


class TestUpdateApplication:
    async def test_updates_existing_application(self):
        app = _make_application(name="Old Name")
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = app
        db.execute.return_value = result_mock

        result = await repo.update_application(
            db, str(app.id), name="New Name", description="Updated"
        )

        assert result is app
        assert result.name == "New Name"
        assert result.description == "Updated"
        db.flush.assert_awaited()
        db.refresh.assert_awaited()

    async def test_returns_none_when_not_found(self):
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = None
        db.execute.return_value = result_mock

        result = await repo.update_application(
            db, str(uuid4()), name="Ignored"
        )

        assert result is None

    async def test_sets_updated_at(self):
        app = _make_application()
        original_updated = app.updated_at
        db = _mock_session()
        result_mock = MagicMock()
        result_mock.scalar_one_or_none.return_value = app
        db.execute.return_value = result_mock

        await repo.update_application(db, str(app.id), name="Changed")

        assert app.updated_at >= original_updated


# ---------------------------------------------------------------------------
# increment_request_count
# ---------------------------------------------------------------------------


class TestIncrementRequestCount:
    async def test_executes_raw_sql_and_flushes(self):
        db = _mock_session()
        app_id = str(uuid4())

        await repo.increment_request_count(db, app_id)

        db.execute.assert_awaited_once()
        db.flush.assert_awaited_once()

        # Verify the raw SQL was called with the correct app_id parameter
        call_args = db.execute.call_args
        params = call_args[0][1]  # second positional arg is the params dict
        assert params["app_id"] == app_id


# ---------------------------------------------------------------------------
# list_applications
# ---------------------------------------------------------------------------


class TestListApplications:
    async def test_returns_all_applications(self):
        app1 = _make_application(name="App 1", slug="app-1")
        app2 = _make_application(name="App 2", slug="app-2")
        db = _mock_session()

        result_mock = MagicMock()
        scalars_mock = MagicMock()
        scalars_mock.all.return_value = [app1, app2]
        result_mock.scalars.return_value = scalars_mock
        db.execute.return_value = result_mock

        result = await repo.list_applications(db)

        assert len(result) == 2
        assert app1 in result
        assert app2 in result

    async def test_returns_empty_list_when_none(self):
        db = _mock_session()

        result_mock = MagicMock()
        scalars_mock = MagicMock()
        scalars_mock.all.return_value = []
        result_mock.scalars.return_value = scalars_mock
        db.execute.return_value = result_mock

        result = await repo.list_applications(db)

        assert result == []

    async def test_owner_id_accepted_without_error(self):
        """owner_id is accepted as a parameter even if not yet used for filtering."""
        db = _mock_session()

        result_mock = MagicMock()
        scalars_mock = MagicMock()
        scalars_mock.all.return_value = []
        result_mock.scalars.return_value = scalars_mock
        db.execute.return_value = result_mock

        # Should not raise
        result = await repo.list_applications(db, owner_id=str(uuid4()))

        assert result == []
        db.execute.assert_awaited_once()
