"""Unit tests for the applications domain service layer.

Mocks the repository module to test business logic in isolation.
"""

from __future__ import annotations

from datetime import datetime, UTC
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import UUID, uuid4

import pytest

from spaps_server_quickstart.domains.applications import service
from spaps_server_quickstart.domains.applications.models import Application
from spaps_server_quickstart.domains.errors import (
    InvalidApplicationError,
    NotFoundError,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

REPO_MODULE = "spaps_server_quickstart.domains.applications.service.repo"


def _make_application(
    app_id: str | None = None,
    name: str = "Test App",
    slug: str = "test-app",
    api_key: str = "sk_test_key_123",
    publishable_key_hash: str | None = None,
    secret_key_hash: str | None = None,
) -> MagicMock:
    """Return a mock Application with sensible defaults."""
    app = MagicMock(spec=Application)
    app.id = UUID(app_id) if app_id else uuid4()
    app.name = name
    app.slug = slug
    app.api_key = api_key
    app.publishable_key_hash = publishable_key_hash
    app.secret_key_hash = secret_key_hash
    app.created_at = datetime.now(UTC)
    app.updated_at = datetime.now(UTC)
    return app


def _mock_db() -> AsyncMock:
    return AsyncMock()


# ---------------------------------------------------------------------------
# get_application
# ---------------------------------------------------------------------------


class TestGetApplication:
    async def test_returns_app_when_found(self):
        app = _make_application()
        db = _mock_db()

        with patch(f"{REPO_MODULE}.get_application_by_id", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = app
            result = await service.get_application(db, str(app.id))

        assert result is app
        mock_get.assert_awaited_once_with(db, str(app.id))

    async def test_raises_not_found_when_missing(self):
        db = _mock_db()
        aid = str(uuid4())

        with patch(f"{REPO_MODULE}.get_application_by_id", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = None

            with pytest.raises(NotFoundError, match=aid):
                await service.get_application(db, aid)


# ---------------------------------------------------------------------------
# validate_api_key
# ---------------------------------------------------------------------------


class TestValidateApiKey:
    async def test_returns_app_on_valid_key(self):
        app = _make_application(api_key="sk_valid_key")
        db = _mock_db()

        with patch(f"{REPO_MODULE}.get_application_by_api_key", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = app
            result = await service.validate_api_key(db, "sk_valid_key")

        assert result is app
        mock_get.assert_awaited_once_with(db, "sk_valid_key")

    async def test_raises_invalid_application_on_bad_key(self):
        db = _mock_db()

        with patch(f"{REPO_MODULE}.get_application_by_api_key", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = None

            with pytest.raises(InvalidApplicationError, match="Invalid API key"):
                await service.validate_api_key(db, "sk_bogus")


# ---------------------------------------------------------------------------
# validate_publishable_key
# ---------------------------------------------------------------------------


class TestValidatePublishableKey:
    async def test_returns_app_on_valid_hash(self):
        app = _make_application(publishable_key_hash="pub_hash_abc")
        db = _mock_db()

        with patch(
            f"{REPO_MODULE}.get_application_by_publishable_key_hash",
            new_callable=AsyncMock,
        ) as mock_get:
            mock_get.return_value = app
            result = await service.validate_publishable_key(db, "pub_hash_abc")

        assert result is app
        mock_get.assert_awaited_once_with(db, "pub_hash_abc")

    async def test_raises_invalid_application_on_bad_hash(self):
        db = _mock_db()

        with patch(
            f"{REPO_MODULE}.get_application_by_publishable_key_hash",
            new_callable=AsyncMock,
        ) as mock_get:
            mock_get.return_value = None

            with pytest.raises(
                InvalidApplicationError, match="Invalid publishable key"
            ):
                await service.validate_publishable_key(db, "bad_hash")


# ---------------------------------------------------------------------------
# validate_secret_key
# ---------------------------------------------------------------------------


class TestValidateSecretKey:
    async def test_returns_app_on_valid_hash(self):
        app = _make_application(secret_key_hash="sec_hash_xyz")
        db = _mock_db()

        with patch(
            f"{REPO_MODULE}.get_application_by_secret_key_hash",
            new_callable=AsyncMock,
        ) as mock_get:
            mock_get.return_value = app
            result = await service.validate_secret_key(db, "sec_hash_xyz")

        assert result is app
        mock_get.assert_awaited_once_with(db, "sec_hash_xyz")

    async def test_raises_invalid_application_on_bad_hash(self):
        db = _mock_db()

        with patch(
            f"{REPO_MODULE}.get_application_by_secret_key_hash",
            new_callable=AsyncMock,
        ) as mock_get:
            mock_get.return_value = None

            with pytest.raises(
                InvalidApplicationError, match="Invalid secret key"
            ):
                await service.validate_secret_key(db, "bad_hash")
