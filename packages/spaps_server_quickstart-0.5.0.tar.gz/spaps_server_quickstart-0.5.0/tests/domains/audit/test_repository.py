"""Unit tests for the audit domain repository layer.

Tests repository functions with mocked AsyncSession.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

from spaps_server_quickstart.domains.audit import repository as repo
from spaps_server_quickstart.domains.audit.models import AuditLog


FAKE_ADMIN_ID = uuid4()


def _mock_db():
    """Create a mocked AsyncSession."""
    db = AsyncMock()
    db.add = MagicMock()  # add() is synchronous in SQLAlchemy
    db.flush = AsyncMock()
    db.refresh = AsyncMock()
    return db


def _mock_audit_log():
    """Create a mock audit log."""
    log = MagicMock(spec=AuditLog)
    log.id = uuid4()
    log.admin_user_id = FAKE_ADMIN_ID
    log.action = "user.created"
    log.resource_type = "user"
    log.timestamp = datetime.now(UTC)
    return log


# ===========================================================================
# Audit Log Creation
# ===========================================================================


class TestCreateAuditLog:
    async def test_creates_and_returns(self):
        """create_audit_log adds log to session and returns it."""
        db = _mock_db()

        result = await repo.create_audit_log(
            db,
            admin_user_id=FAKE_ADMIN_ID,
            admin_email="admin@example.com",
            action="user.created",
            resource_type="user",
            resource_id=str(uuid4()),
        )

        assert result is not None
        assert isinstance(result, AuditLog)
        db.add.assert_called_once()
        db.flush.assert_called_once()
        db.refresh.assert_called_once()


# ===========================================================================
# Audit Log Queries
# ===========================================================================


class TestListLogsByAdmin:
    async def test_returns_logs_and_count(self):
        """list_logs_by_admin returns paginated logs and total count."""
        logs = [_mock_audit_log(), _mock_audit_log()]

        db = _mock_db()

        # Mock count query
        count_result = MagicMock()
        count_result.scalar_one.return_value = 2

        # Mock data query
        scalars_mock = MagicMock()
        scalars_mock.all.return_value = logs
        data_result = MagicMock()
        data_result.scalars.return_value = scalars_mock

        # Return count first, then data
        db.execute = AsyncMock(side_effect=[count_result, data_result])

        result_logs, total = await repo.list_logs_by_admin(db, FAKE_ADMIN_ID)

        assert len(result_logs) == 2
        assert total == 2

    async def test_filters_by_action(self):
        """list_logs_by_admin filters by action."""
        db = _mock_db()

        count_result = MagicMock()
        count_result.scalar_one.return_value = 1

        scalars_mock = MagicMock()
        scalars_mock.all.return_value = [_mock_audit_log()]
        data_result = MagicMock()
        data_result.scalars.return_value = scalars_mock

        db.execute = AsyncMock(side_effect=[count_result, data_result])

        result_logs, total = await repo.list_logs_by_admin(
            db, FAKE_ADMIN_ID, action="user.created"
        )

        assert total == 1

    async def test_filters_by_resource_type(self):
        """list_logs_by_admin filters by resource_type."""
        db = _mock_db()

        count_result = MagicMock()
        count_result.scalar_one.return_value = 1

        scalars_mock = MagicMock()
        scalars_mock.all.return_value = [_mock_audit_log()]
        data_result = MagicMock()
        data_result.scalars.return_value = scalars_mock

        db.execute = AsyncMock(side_effect=[count_result, data_result])

        result_logs, total = await repo.list_logs_by_admin(
            db, FAKE_ADMIN_ID, resource_type="user"
        )

        assert total == 1

    async def test_pagination(self):
        """list_logs_by_admin supports offset and limit."""
        db = _mock_db()

        count_result = MagicMock()
        count_result.scalar_one.return_value = 100

        scalars_mock = MagicMock()
        scalars_mock.all.return_value = [_mock_audit_log() for _ in range(20)]
        data_result = MagicMock()
        data_result.scalars.return_value = scalars_mock

        db.execute = AsyncMock(side_effect=[count_result, data_result])

        result_logs, total = await repo.list_logs_by_admin(
            db, FAKE_ADMIN_ID, limit=20, offset=40
        )

        assert len(result_logs) == 20
        assert total == 100


class TestListAllLogs:
    async def test_returns_all_logs(self):
        """list_all_logs returns all logs for super admin."""
        logs = [_mock_audit_log(), _mock_audit_log()]

        db = _mock_db()

        count_result = MagicMock()
        count_result.scalar_one.return_value = 2

        scalars_mock = MagicMock()
        scalars_mock.all.return_value = logs
        data_result = MagicMock()
        data_result.scalars.return_value = scalars_mock

        db.execute = AsyncMock(side_effect=[count_result, data_result])

        result_logs, total = await repo.list_all_logs(db)

        assert len(result_logs) == 2
        assert total == 2

    async def test_filters_by_admin_user_id(self):
        """list_all_logs can filter by admin_user_id."""
        db = _mock_db()

        count_result = MagicMock()
        count_result.scalar_one.return_value = 1

        scalars_mock = MagicMock()
        scalars_mock.all.return_value = [_mock_audit_log()]
        data_result = MagicMock()
        data_result.scalars.return_value = scalars_mock

        db.execute = AsyncMock(side_effect=[count_result, data_result])

        result_logs, total = await repo.list_all_logs(db, admin_user_id=FAKE_ADMIN_ID)

        assert total == 1

    async def test_filters_by_action_and_resource_type(self):
        """list_all_logs supports multiple filters."""
        db = _mock_db()

        count_result = MagicMock()
        count_result.scalar_one.return_value = 1

        scalars_mock = MagicMock()
        scalars_mock.all.return_value = [_mock_audit_log()]
        data_result = MagicMock()
        data_result.scalars.return_value = scalars_mock

        db.execute = AsyncMock(side_effect=[count_result, data_result])

        result_logs, total = await repo.list_all_logs(
            db, action="user.created", resource_type="user"
        )

        assert total == 1


# ===========================================================================
# Retention: Archive & Purge
# ===========================================================================


class TestArchiveOldLogs:
    async def test_archives_old_logs(self):
        """archive_old_logs moves old logs to archive table."""
        cutoff = datetime.now(UTC) - timedelta(days=90)

        db = _mock_db()

        # Mock count query
        count_result = MagicMock()
        count_result.scalar.return_value = 50

        # Mock insert and delete queries
        insert_result = MagicMock()
        delete_result = MagicMock()

        db.execute = AsyncMock(side_effect=[count_result, insert_result, delete_result])

        count = await repo.archive_old_logs(db, cutoff)

        assert count == 50
        db.flush.assert_called_once()

    async def test_returns_zero_if_no_logs_to_archive(self):
        """archive_old_logs returns 0 if no logs match."""
        cutoff = datetime.now(UTC) - timedelta(days=90)

        db = _mock_db()

        count_result = MagicMock()
        count_result.scalar.return_value = 0

        db.execute = AsyncMock(return_value=count_result)

        count = await repo.archive_old_logs(db, cutoff)

        assert count == 0
        db.flush.assert_not_called()


class TestPurgeOldArchives:
    async def test_purges_old_archives(self):
        """purge_old_archives deletes old archived logs."""
        cutoff = datetime.now(UTC) - timedelta(days=365)

        db = _mock_db()

        # Mock count query
        count_result = MagicMock()
        count_result.scalar_one.return_value = 100

        # Mock delete query
        delete_result = MagicMock()

        db.execute = AsyncMock(side_effect=[count_result, delete_result])

        count = await repo.purge_old_archives(db, cutoff)

        assert count == 100
        db.flush.assert_called_once()

    async def test_returns_zero_if_no_archives_to_purge(self):
        """purge_old_archives returns 0 if no archives match."""
        cutoff = datetime.now(UTC) - timedelta(days=365)

        db = _mock_db()

        count_result = MagicMock()
        count_result.scalar_one.return_value = 0

        db.execute = AsyncMock(return_value=count_result)

        count = await repo.purge_old_archives(db, cutoff)

        assert count == 0
        db.flush.assert_not_called()
