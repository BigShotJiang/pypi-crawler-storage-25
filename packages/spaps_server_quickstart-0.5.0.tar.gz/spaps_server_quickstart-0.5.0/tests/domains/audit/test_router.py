"""Unit tests for the audit domain router (HTTP layer).

Each test creates a minimal FastAPI test app with dependency overrides for
the database session, application, current user, and admin user. The
audit service layer is fully mocked so tests exercise only routing,
request validation, status codes, and response shapes.
"""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from spaps_server_quickstart.domains.audit.router import audit_router
from spaps_server_quickstart.middleware.error_handler import install_error_handlers
from spaps_server_quickstart.middleware.spaps_deps import (
    get_application,
    get_current_user,
    get_db_session,
    require_admin_user,
    require_super_admin_user,
)

# ---------------------------------------------------------------------------
# Helpers / Constants
# ---------------------------------------------------------------------------

FAKE_ADMIN_ID = str(uuid4())
FAKE_APP_ID = str(uuid4())

_AUDIT_SERVICE = "spaps_server_quickstart.domains.audit.service"


def _fake_audit_log(
    action: str = "create_product",
    severity: str = "info",
) -> dict:
    """Return a realistic audit log dict."""
    return {
        "id": str(uuid4()),
        "admin_user_id": FAKE_ADMIN_ID,
        "admin_email": "admin@example.com",
        "action": action,
        "resource_type": "product",
        "resource_id": "prod_123",
        "resource_data": {"name": "Test Product"},
        "error_details": None,
        "ip_address": "127.0.0.1",
        "user_agent": "TestAgent/1.0",
        "application_id": FAKE_APP_ID,
        "severity": severity,
        "timestamp": datetime.now(UTC).isoformat(),
    }


def _fake_admin():
    """Return a mock admin user."""
    admin = MagicMock()
    admin.id = FAKE_ADMIN_ID
    admin.email = "admin@example.com"
    admin.username = "admin"
    admin.tier = "enterprise"
    admin.roles = ["admin"]
    admin.permissions = ["manage_audit"]
    admin.is_admin = True
    admin.is_super_admin = False
    admin.wallet_addresses = []
    return admin


def _fake_super_admin():
    """Return a mock super admin user."""
    admin = MagicMock()
    admin.id = FAKE_ADMIN_ID
    admin.email = "superadmin@example.com"
    admin.username = "superadmin"
    admin.tier = "enterprise"
    admin.roles = ["admin", "super_admin"]
    admin.permissions = ["manage_audit"]
    admin.is_admin = True
    admin.is_super_admin = True
    admin.wallet_addresses = []
    return admin


def _fake_application():
    """Return a mock application."""
    app = MagicMock()
    app.id = FAKE_APP_ID
    app.name = "Test App"
    return app


def _create_test_app():
    """Create a FastAPI test app with audit router and overridden deps."""
    app = FastAPI()

    settings = MagicMock()
    settings.jwt_secret = "test-secret"
    app.state.settings = settings

    install_error_handlers(app)
    app.include_router(audit_router)

    mock_db = AsyncMock()

    async def override_db_session():
        yield mock_db

    app.dependency_overrides[get_db_session] = override_db_session
    app.dependency_overrides[get_application] = _fake_application
    app.dependency_overrides[get_current_user] = _fake_admin
    app.dependency_overrides[require_admin_user] = _fake_admin
    app.dependency_overrides[require_super_admin_user] = _fake_super_admin

    return app


@pytest.fixture
def test_app():
    return _create_test_app()


@pytest.fixture
async def client(test_app):
    transport = ASGITransport(app=test_app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


# ===========================================================================
# GET /audit/logs
# ===========================================================================


class TestGetAdminLogs:
    @patch(f"{_AUDIT_SERVICE}.get_admin_logs", new_callable=AsyncMock)
    async def test_success(self, mock_get, client: AsyncClient):
        """GET /audit/logs returns audit logs and total count."""
        mock_get.return_value = {
            "logs": [_fake_audit_log()],
            "total": 1,
        }

        resp = await client.get("/audit/logs")

        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 1
        assert len(data["logs"]) == 1
        assert data["logs"][0]["action"] == "create_product"

    @patch(f"{_AUDIT_SERVICE}.get_admin_logs", new_callable=AsyncMock)
    async def test_empty_result(self, mock_get, client: AsyncClient):
        """GET /audit/logs returns empty list when no logs exist."""
        mock_get.return_value = {"logs": [], "total": 0}

        resp = await client.get("/audit/logs")

        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 0
        assert len(data["logs"]) == 0

    @patch(f"{_AUDIT_SERVICE}.get_admin_logs", new_callable=AsyncMock)
    async def test_with_action_filter(self, mock_get, client: AsyncClient):
        """GET /audit/logs with action filter."""
        mock_get.return_value = {
            "logs": [_fake_audit_log(action="delete_product")],
            "total": 1,
        }

        resp = await client.get("/audit/logs", params={"action": "delete_product"})

        assert resp.status_code == 200
        mock_get.assert_called_once()

    @patch(f"{_AUDIT_SERVICE}.get_admin_logs", new_callable=AsyncMock)
    async def test_with_resource_type_filter(self, mock_get, client: AsyncClient):
        """GET /audit/logs with resource_type filter."""
        mock_get.return_value = {"logs": [], "total": 0}

        resp = await client.get(
            "/audit/logs", params={"resource_type": "subscription"}
        )

        assert resp.status_code == 200

    @patch(f"{_AUDIT_SERVICE}.get_admin_logs", new_callable=AsyncMock)
    async def test_with_admin_user_id_filter(self, mock_get, client: AsyncClient):
        """GET /audit/logs with explicit admin_user_id."""
        other_admin_id = str(uuid4())
        mock_get.return_value = {"logs": [], "total": 0}

        resp = await client.get(
            "/audit/logs", params={"admin_user_id": other_admin_id}
        )

        assert resp.status_code == 200

    @patch(f"{_AUDIT_SERVICE}.get_admin_logs", new_callable=AsyncMock)
    async def test_pagination(self, mock_get, client: AsyncClient):
        """GET /audit/logs with limit and offset."""
        mock_get.return_value = {"logs": [], "total": 100}

        resp = await client.get(
            "/audit/logs", params={"limit": 10, "offset": 20}
        )

        assert resp.status_code == 200

    async def test_invalid_limit_returns_400(self, client: AsyncClient):
        """GET /audit/logs with invalid limit returns 400."""
        resp = await client.get("/audit/logs", params={"limit": 0})
        assert resp.status_code == 400

    async def test_negative_offset_returns_400(self, client: AsyncClient):
        """GET /audit/logs with negative offset returns 400."""
        resp = await client.get("/audit/logs", params={"offset": -1})
        assert resp.status_code == 400


# ===========================================================================
# GET /audit/all-logs
# ===========================================================================


class TestGetAllLogs:
    @patch(f"{_AUDIT_SERVICE}.get_all_logs", new_callable=AsyncMock)
    async def test_success(self, mock_get, client: AsyncClient):
        """GET /audit/all-logs returns all audit logs and total count."""
        mock_get.return_value = {
            "logs": [_fake_audit_log(), _fake_audit_log(action="update_config")],
            "total": 2,
        }

        resp = await client.get("/audit/all-logs")

        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 2
        assert len(data["logs"]) == 2

    @patch(f"{_AUDIT_SERVICE}.get_all_logs", new_callable=AsyncMock)
    async def test_empty_result(self, mock_get, client: AsyncClient):
        """GET /audit/all-logs returns empty list when no logs exist."""
        mock_get.return_value = {"logs": [], "total": 0}

        resp = await client.get("/audit/all-logs")

        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 0

    @patch(f"{_AUDIT_SERVICE}.get_all_logs", new_callable=AsyncMock)
    async def test_with_filters(self, mock_get, client: AsyncClient):
        """GET /audit/all-logs with all filters."""
        mock_get.return_value = {"logs": [], "total": 0}

        resp = await client.get(
            "/audit/all-logs",
            params={
                "admin_user_id": str(uuid4()),
                "action": "create_product",
                "resource_type": "product",
                "limit": 25,
                "offset": 10,
            },
        )

        assert resp.status_code == 200

    @patch(f"{_AUDIT_SERVICE}.get_all_logs", new_callable=AsyncMock)
    async def test_pagination(self, mock_get, client: AsyncClient):
        """GET /audit/all-logs with pagination."""
        mock_get.return_value = {"logs": [], "total": 500}

        resp = await client.get(
            "/audit/all-logs", params={"limit": 100, "offset": 200}
        )

        assert resp.status_code == 200
