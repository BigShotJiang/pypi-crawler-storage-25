"""Unit tests for the audit retention periodic task."""

from __future__ import annotations

import asyncio
import os
from unittest.mock import AsyncMock, MagicMock, patch

_RETENTION_MODULE = "spaps_server_quickstart.domains.audit.retention"
_AUDIT_SERVICE = "spaps_server_quickstart.domains.audit.service"


class TestGetRetentionConfig:
    def test_defaults(self):
        """_get_retention_config returns defaults when env vars not set."""
        from spaps_server_quickstart.domains.audit.retention import _get_retention_config

        # Clear any env vars
        env_vars = [
            "AUDIT_RETENTION_DAYS",
            "AUDIT_ARCHIVE_RETENTION_DAYS",
            "AUDIT_CLEANUP_INTERVAL_HOURS",
        ]
        saved = {}
        for var in env_vars:
            saved[var] = os.environ.pop(var, None)

        try:
            retention, archive, interval = _get_retention_config()
            assert retention == 90
            assert archive == 365
            assert interval == 24
        finally:
            for var, val in saved.items():
                if val is not None:
                    os.environ[var] = val

    def test_custom_values(self):
        """_get_retention_config reads custom values from env."""
        from spaps_server_quickstart.domains.audit.retention import _get_retention_config

        saved = {}
        env_vars = {
            "AUDIT_RETENTION_DAYS": "30",
            "AUDIT_ARCHIVE_RETENTION_DAYS": "180",
            "AUDIT_CLEANUP_INTERVAL_HOURS": "12",
        }
        for var, val in env_vars.items():
            saved[var] = os.environ.get(var)
            os.environ[var] = val

        try:
            retention, archive, interval = _get_retention_config()
            assert retention == 30
            assert archive == 180
            assert interval == 12
        finally:
            for var, val in saved.items():
                if val is not None:
                    os.environ[var] = val
                else:
                    os.environ.pop(var, None)


class TestRunRetentionLoop:
    @patch(f"{_AUDIT_SERVICE}.retention_cleanup", new_callable=AsyncMock)
    async def test_loop_runs_and_cancels(self, mock_cleanup):
        """run_retention_loop executes cleanup and can be cancelled."""
        from spaps_server_quickstart.domains.audit.retention import run_retention_loop

        mock_cleanup.return_value = {"archived": 2, "purged": 1}

        # Create a mock session factory
        mock_session = AsyncMock()
        mock_session.__aenter__ = AsyncMock(return_value=mock_session)
        mock_session.__aexit__ = AsyncMock(return_value=False)
        mock_session.begin = MagicMock(return_value=AsyncMock(
            __aenter__=AsyncMock(return_value=None),
            __aexit__=AsyncMock(return_value=False),
        ))

        mock_factory = MagicMock(return_value=mock_session)

        # Use very short interval for testing (will be overridden by sleep mock)
        with patch("asyncio.sleep", new_callable=AsyncMock) as mock_sleep:
            # After the first sleep, cancel the task
            call_count = 0

            async def side_effect(seconds):
                nonlocal call_count
                call_count += 1
                if call_count >= 2:
                    raise asyncio.CancelledError()

            mock_sleep.side_effect = side_effect

            await run_retention_loop(
                mock_factory,
                retention_days=90,
                archive_retention_days=365,
                interval_hours=1,
            )

            # Verify cleanup was called at least once
            assert mock_cleanup.called

    @patch(f"{_AUDIT_SERVICE}.retention_cleanup", new_callable=AsyncMock)
    async def test_loop_handles_errors_gracefully(self, mock_cleanup):
        """run_retention_loop continues after transient errors."""
        from spaps_server_quickstart.domains.audit.retention import run_retention_loop

        mock_cleanup.side_effect = Exception("Database connection failed")

        mock_session = AsyncMock()
        mock_session.__aenter__ = AsyncMock(return_value=mock_session)
        mock_session.__aexit__ = AsyncMock(return_value=False)
        mock_session.begin = MagicMock(return_value=AsyncMock(
            __aenter__=AsyncMock(return_value=None),
            __aexit__=AsyncMock(return_value=False),
        ))
        mock_factory = MagicMock(return_value=mock_session)

        with patch("asyncio.sleep", new_callable=AsyncMock) as mock_sleep:
            call_count = 0

            async def side_effect(seconds):
                nonlocal call_count
                call_count += 1
                if call_count >= 3:
                    raise asyncio.CancelledError()

            mock_sleep.side_effect = side_effect

            # Should not raise -- errors are caught and loop continues
            await run_retention_loop(
                mock_factory,
                interval_hours=1,
            )
