"""
Tests for the SDK consolidation module (Phase B2).

Covers:
- AdminTokenCache: cache hit, expired refresh, concurrent refresh, auth failure backoff,
  missing credentials error
- Server clients: list with caching, grant bypasses cache, batch chunking, email send
- RoleHierarchy: admin >= accountant, client < accountant, unknown role, require_minimum_role
- TrustedServiceMiddleware: valid key + user, invalid key, missing user, role passthrough
- FeatureEvaluator: kill switch blocks, admin bypass, resource block, role minimum,
  unconfigured feature -> enabled
"""

from __future__ import annotations

import asyncio
import hashlib
import hmac
import time
from types import SimpleNamespace
from typing import Any
from unittest.mock import AsyncMock, patch

import pytest
from fastapi import Depends, FastAPI, status
from fastapi.testclient import TestClient
from starlette.requests import Request

from spaps_server_quickstart.auth import AuthenticatedUser
from spaps_server_quickstart.sdk.admin_token_cache import (
    AdminTokenCache,
    AdminTokenCacheError,
)
from spaps_server_quickstart.sdk.server_clients import (
    ServerDayrateClient,
    ServerEmailClient,
    ServerEntitlementsClient,
    ServerPaymentsClient,
    ServerUsersClient,
)
from spaps_server_quickstart.sdk.role_hierarchy import (
    RoleHierarchy,
    require_minimum_role,
)
from spaps_server_quickstart.sdk.trusted_service_middleware import (
    TrustedServiceMiddleware,
    build_trusted_service_headers,
)
from spaps_server_quickstart.sdk.feature_evaluator import (
    FeatureContext,
    FeatureDefinition,
    FeatureEvaluator,
)
from spaps_server_quickstart.sdk._ttl_cache import TTLCache


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_settings(**overrides: Any) -> SimpleNamespace:
    """Create a minimal settings-like object for testing."""
    defaults = {
        "spaps_api_url": "https://api.sweetpotato.dev",
        "spaps_api_key": "test-api-key",
        "spaps_admin_email": None,
        "spaps_admin_password": None,
    }
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


# ---------------------------------------------------------------------------
# TTLCache tests
# ---------------------------------------------------------------------------


class TestTTLCache:
    def test_set_and_get(self) -> None:
        cache = TTLCache(ttl_seconds=60.0)
        cache.set("key1", "value1")
        assert cache.get("key1") == "value1"

    def test_get_miss(self) -> None:
        cache = TTLCache(ttl_seconds=60.0)
        assert cache.get("missing") is None

    def test_expired_entry_returns_none(self) -> None:
        cache = TTLCache(ttl_seconds=0.01)  # 10ms TTL
        cache.set("key1", "value1")
        time.sleep(0.02)
        assert cache.get("key1") is None

    def test_invalidate(self) -> None:
        cache = TTLCache(ttl_seconds=60.0)
        cache.set("key1", "value1")
        cache.invalidate("key1")
        assert cache.get("key1") is None

    def test_invalidate_prefix(self) -> None:
        cache = TTLCache(ttl_seconds=60.0)
        cache.set("prefix:a", 1)
        cache.set("prefix:b", 2)
        cache.set("other:c", 3)
        cache.invalidate_prefix("prefix:")
        assert cache.get("prefix:a") is None
        assert cache.get("prefix:b") is None
        assert cache.get("other:c") == 3

    def test_clear(self) -> None:
        cache = TTLCache(ttl_seconds=60.0)
        cache.set("a", 1)
        cache.set("b", 2)
        cache.clear()
        assert len(cache) == 0

    def test_max_size_enforcement(self) -> None:
        cache = TTLCache(ttl_seconds=60.0, max_size=5)
        for i in range(10):
            cache.set(f"key{i}", i)
        assert len(cache) <= 5


# ---------------------------------------------------------------------------
# AdminTokenCache tests
# ---------------------------------------------------------------------------


class TestAdminTokenCache:
    def test_auto_strategy_selects_password(self) -> None:
        settings = _make_settings(
            spaps_admin_email="admin@test.com",
            spaps_admin_password="pass123",
        )
        cache = AdminTokenCache(settings, strategy="auto")
        assert cache._strategy == "password"

    def test_auto_strategy_selects_api_key(self) -> None:
        settings = _make_settings()  # no email/password, but has api_key
        cache = AdminTokenCache(settings, strategy="auto")
        assert cache._strategy == "api_key"

    def test_auto_strategy_raises_when_nothing_configured(self) -> None:
        settings = _make_settings(spaps_api_key=None)
        with pytest.raises(AdminTokenCacheError, match="auto strategy requires"):
            AdminTokenCache(settings, strategy="auto")

    def test_password_strategy_raises_without_credentials(self) -> None:
        settings = _make_settings()  # no email/password
        with pytest.raises(AdminTokenCacheError, match="password strategy requires"):
            AdminTokenCache(settings, strategy="password")

    def test_api_key_strategy_raises_without_key(self) -> None:
        settings = _make_settings(spaps_api_key=None)
        with pytest.raises(AdminTokenCacheError, match="api_key strategy requires"):
            AdminTokenCache(settings, strategy="api_key")

    def test_unknown_strategy_raises(self) -> None:
        settings = _make_settings()
        with pytest.raises(AdminTokenCacheError, match="Unknown strategy"):
            AdminTokenCache(settings, strategy="magic")

    @pytest.mark.asyncio
    async def test_api_key_strategy_returns_key_as_token(self) -> None:
        settings = _make_settings()
        cache = AdminTokenCache(settings, strategy="api_key")
        token = await cache.get_token()
        assert token == "test-api-key"

    @pytest.mark.asyncio
    async def test_cache_hit_returns_same_token(self) -> None:
        settings = _make_settings()
        cache = AdminTokenCache(settings, strategy="api_key")
        token1 = await cache.get_token()
        token2 = await cache.get_token()
        assert token1 == token2

    @pytest.mark.asyncio
    async def test_password_strategy_uses_auth_client(self) -> None:
        settings = _make_settings(
            spaps_admin_email="admin@test.com",
            spaps_admin_password="pass123",
        )
        mock_token_pair = SimpleNamespace(
            access_token="jwt-token-123",
            refresh_token="refresh-456",
            expires_in=3600,
        )
        mock_auth = AsyncMock()
        mock_auth.sign_in_with_password = AsyncMock(return_value=mock_token_pair)
        mock_auth.aclose = AsyncMock()

        cache = AdminTokenCache(
            settings,
            strategy="password",
            auth_client_factory=lambda: mock_auth,
        )
        token = await cache.get_token()
        assert token == "jwt-token-123"
        mock_auth.sign_in_with_password.assert_called_once_with(
            email="admin@test.com",
            password="pass123",
        )

    @pytest.mark.asyncio
    async def test_concurrent_refresh_only_one_call(self) -> None:
        """Multiple concurrent get_token() calls should only trigger one refresh."""
        settings = _make_settings(
            spaps_admin_email="admin@test.com",
            spaps_admin_password="pass123",
        )

        call_count = 0

        async def slow_sign_in(**kwargs: Any) -> SimpleNamespace:
            nonlocal call_count
            call_count += 1
            await asyncio.sleep(0.05)
            return SimpleNamespace(
                access_token="jwt-concurrent",
                refresh_token="r",
                expires_in=3600,
            )

        mock_auth = AsyncMock()
        mock_auth.sign_in_with_password = slow_sign_in
        mock_auth.aclose = AsyncMock()

        cache = AdminTokenCache(
            settings,
            strategy="password",
            auth_client_factory=lambda: mock_auth,
        )

        tokens = await asyncio.gather(
            cache.get_token(),
            cache.get_token(),
            cache.get_token(),
        )

        assert all(t == "jwt-concurrent" for t in tokens)
        assert call_count == 1

    @pytest.mark.asyncio
    async def test_auth_failure_triggers_backoff(self) -> None:
        settings = _make_settings(
            spaps_admin_email="admin@test.com",
            spaps_admin_password="badpass",
        )
        mock_auth = AsyncMock()
        mock_auth.sign_in_with_password = AsyncMock(
            side_effect=RuntimeError("Invalid credentials")
        )
        mock_auth.aclose = AsyncMock()

        cache = AdminTokenCache(
            settings,
            strategy="password",
            auth_client_factory=lambda: mock_auth,
        )

        # First call fails
        with pytest.raises(AdminTokenCacheError, match="Failed to refresh"):
            await cache.get_token()

        # Second call should hit backoff
        with pytest.raises(AdminTokenCacheError, match="backoff period"):
            await cache.get_token()

    def test_clear_resets_state(self) -> None:
        settings = _make_settings()
        cache = AdminTokenCache(settings, strategy="api_key")
        cache._token = "cached"
        cache._token_expires_at = time.monotonic() + 3600
        cache._consecutive_failures = 3
        cache._backoff_until = time.monotonic() + 300

        cache.clear()

        assert cache._token is None
        assert cache._token_expires_at == 0.0
        assert cache._consecutive_failures == 0
        assert cache._backoff_until == 0.0


# ---------------------------------------------------------------------------
# Server Clients tests
# ---------------------------------------------------------------------------


class TestServerEntitlementsClient:
    @pytest.mark.asyncio
    async def test_list_with_caching(self) -> None:
        mock_cache = AsyncMock(spec=AdminTokenCache)
        mock_cache.get_token = AsyncMock(return_value="admin-token")

        client = ServerEntitlementsClient(
            mock_cache,
            base_url="https://api.test",
            api_key="key",
        )

        mock_entitlements = [
            SimpleNamespace(id="e1", key="feature_a"),
            SimpleNamespace(id="e2", key="feature_b"),
        ]

        with patch("spaps_server_quickstart.sdk.server_clients.ServerEntitlementsClient._get_client") as mock_get:
            mock_inner = AsyncMock()
            mock_inner.get_user_entitlements = AsyncMock(return_value=mock_entitlements)
            mock_inner.aclose = AsyncMock()
            mock_get.return_value = mock_inner

            # First call: hits the API
            result1 = await client.list(user_id="user-1")
            assert len(result1) == 2
            assert mock_inner.get_user_entitlements.call_count == 1

            # Second call: should be cached
            result2 = await client.list(user_id="user-1")
            assert result2 == result1
            # Still only 1 call because cache hit
            assert mock_inner.get_user_entitlements.call_count == 1

    @pytest.mark.asyncio
    async def test_grant_bypasses_and_invalidates_cache(self) -> None:
        mock_cache = AsyncMock(spec=AdminTokenCache)
        mock_cache.get_token = AsyncMock(return_value="admin-token")

        client = ServerEntitlementsClient(
            mock_cache,
            base_url="https://api.test",
            api_key="key",
        )

        # Pre-populate cache
        client._cache.set("entitlements:list:user-1:None:None:False", ["cached"])

        mock_entitlement = SimpleNamespace(id="new-e1", key="premium")

        with patch("spaps_server_quickstart.sdk.server_clients.ServerEntitlementsClient._get_client") as mock_get:
            mock_inner = AsyncMock()
            mock_inner.grant_manual = AsyncMock(return_value=mock_entitlement)
            mock_inner.aclose = AsyncMock()
            mock_get.return_value = mock_inner

            result = await client.grant(
                entitlement_key="premium",
                beneficiary_user_id="user-1",
            )
            assert result.key == "premium"

        # Cache should be invalidated
        assert client._cache.get("entitlements:list:user-1:None:None:False") is None


class TestServerUsersClient:
    @pytest.mark.asyncio
    async def test_get_emails_batch_auto_chunks(self) -> None:
        mock_cache = AsyncMock(spec=AdminTokenCache)
        mock_cache.get_token = AsyncMock(return_value="admin-token")

        client = ServerUsersClient(
            mock_cache,
            base_url="https://api.test",
            api_key="key",
        )

        call_args_list: list[list[str]] = []

        def build_mock_inner() -> AsyncMock:
            mock_inner = AsyncMock()

            async def mock_get_emails_batch(user_ids: list[str]) -> SimpleNamespace:
                call_args_list.append(user_ids)
                return SimpleNamespace(
                    emails={uid: f"{uid}@test.com" for uid in user_ids}
                )

            mock_inner.get_emails_batch = mock_get_emails_batch
            mock_inner.aclose = AsyncMock()
            return mock_inner

        with patch(
            "spaps_server_quickstart.sdk.server_clients.ServerUsersClient._get_client",
            side_effect=lambda: build_mock_inner(),
        ):
            # Create 250 user IDs (should be split into 3 chunks of 100, 100, 50)
            user_ids = [f"user-{i}" for i in range(250)]
            result = await client.get_emails_batch(user_ids, chunk_size=100)

        assert len(result) == 250
        assert len(call_args_list) == 3
        assert len(call_args_list[0]) == 100
        assert len(call_args_list[1]) == 100
        assert len(call_args_list[2]) == 50


class TestServerEmailClient:
    @pytest.mark.asyncio
    async def test_send_passthrough(self) -> None:
        mock_cache = AsyncMock(spec=AdminTokenCache)
        mock_cache.get_token = AsyncMock(return_value="admin-token")

        client = ServerEmailClient(
            mock_cache,
            base_url="https://api.test",
            api_key="key",
        )

        mock_result = SimpleNamespace(message_id="msg-123", status="sent")

        with patch("spaps_server_quickstart.sdk.server_clients.ServerEmailClient._get_client") as mock_get:
            mock_inner = AsyncMock()
            mock_inner.send = AsyncMock(return_value=mock_result)
            mock_inner.aclose = AsyncMock()
            mock_get.return_value = mock_inner

            result = await client.send(
                "welcome",
                "user@test.com",
                context={"name": "Alice"},
            )
            assert result.message_id == "msg-123"
            mock_inner.send.assert_called_once()

    @pytest.mark.asyncio
    async def test_list_email_logs_passthrough(self) -> None:
        mock_cache = AsyncMock(spec=AdminTokenCache)
        mock_cache.get_token = AsyncMock(return_value="admin-token")

        client = ServerEmailClient(
            mock_cache,
            base_url="https://api.test",
            api_key="key",
        )

        with patch("spaps_server_quickstart.sdk.server_clients.ServerEmailClient._get_client") as mock_get:
            mock_inner = AsyncMock()
            mock_inner.list_email_logs = AsyncMock(return_value={"logs": [{"id": "l1"}], "total": 1})
            mock_inner.aclose = AsyncMock()
            mock_get.return_value = mock_inner

            result = await client.list_email_logs(owner_id="owner-1", limit=25, offset=5)
            assert result["total"] == 1
            mock_inner.list_email_logs.assert_called_once_with(
                owner_id="owner-1",
                user_id=None,
                limit=25,
                offset=5,
            )

    @pytest.mark.asyncio
    async def test_update_template_passthrough(self) -> None:
        mock_cache = AsyncMock(spec=AdminTokenCache)
        mock_cache.get_token = AsyncMock(return_value="admin-token")

        client = ServerEmailClient(
            mock_cache,
            base_url="https://api.test",
            api_key="key",
        )

        mock_template = SimpleNamespace(id="tmpl_1", template_key="welcome", subject="Updated")

        with patch("spaps_server_quickstart.sdk.server_clients.ServerEmailClient._get_client") as mock_get:
            mock_inner = AsyncMock()
            mock_inner.update_template = AsyncMock(return_value=mock_template)
            mock_inner.aclose = AsyncMock()
            mock_get.return_value = mock_inner

            result = await client.update_template("welcome", subject="Updated")
            assert result.subject == "Updated"
            mock_inner.update_template.assert_called_once()

    @pytest.mark.asyncio
    async def test_get_override_passthrough(self) -> None:
        mock_cache = AsyncMock(spec=AdminTokenCache)
        mock_cache.get_token = AsyncMock(return_value="admin-token")

        client = ServerEmailClient(
            mock_cache,
            base_url="https://api.test",
            api_key="key",
        )

        with patch("spaps_server_quickstart.sdk.server_clients.ServerEmailClient._get_client") as mock_get:
            mock_inner = AsyncMock()
            mock_inner.get_override = AsyncMock(return_value={"subject_override": "Custom"})
            mock_inner.aclose = AsyncMock()
            mock_get.return_value = mock_inner

            result = await client.get_override("welcome")
            assert result["subject_override"] == "Custom"
            mock_inner.get_override.assert_called_once_with("welcome")

    @pytest.mark.asyncio
    async def test_create_or_update_override_passthrough(self) -> None:
        mock_cache = AsyncMock(spec=AdminTokenCache)
        mock_cache.get_token = AsyncMock(return_value="admin-token")

        client = ServerEmailClient(
            mock_cache,
            base_url="https://api.test",
            api_key="key",
        )

        with patch("spaps_server_quickstart.sdk.server_clients.ServerEmailClient._get_client") as mock_get:
            mock_inner = AsyncMock()
            mock_inner.create_or_update_override = AsyncMock(return_value={"subject_override": "New"})
            mock_inner.aclose = AsyncMock()
            mock_get.return_value = mock_inner

            result = await client.create_or_update_override("welcome", subject_override="New")
            assert result["subject_override"] == "New"
            mock_inner.create_or_update_override.assert_called_once()

    @pytest.mark.asyncio
    async def test_delete_override_passthrough(self) -> None:
        mock_cache = AsyncMock(spec=AdminTokenCache)
        mock_cache.get_token = AsyncMock(return_value="admin-token")

        client = ServerEmailClient(
            mock_cache,
            base_url="https://api.test",
            api_key="key",
        )

        with patch("spaps_server_quickstart.sdk.server_clients.ServerEmailClient._get_client") as mock_get:
            mock_inner = AsyncMock()
            mock_inner.delete_override = AsyncMock(return_value={"deleted": True})
            mock_inner.aclose = AsyncMock()
            mock_get.return_value = mock_inner

            result = await client.delete_override("welcome")
            assert result["deleted"] is True
            mock_inner.delete_override.assert_called_once_with("welcome")

    @pytest.mark.asyncio
    async def test_create_template_passthrough(self) -> None:
        mock_cache = AsyncMock(spec=AdminTokenCache)
        mock_cache.get_token = AsyncMock(return_value="admin-token")

        client = ServerEmailClient(
            mock_cache,
            base_url="https://api.test",
            api_key="key",
        )

        mock_template = SimpleNamespace(id="tmpl_new", template_key="new", name="New")

        with patch("spaps_server_quickstart.sdk.server_clients.ServerEmailClient._get_client") as mock_get:
            mock_inner = AsyncMock()
            mock_inner.create_template = AsyncMock(return_value=mock_template)
            mock_inner.aclose = AsyncMock()
            mock_get.return_value = mock_inner

            result = await client.create_template(
                template_key="new",
                name="New",
                subject="Welcome",
                html_body="<p>Hello</p>",
            )
            assert result.template_key == "new"
            mock_inner.create_template.assert_called_once()

    @pytest.mark.asyncio
    async def test_list_templates_passthrough(self) -> None:
        mock_cache = AsyncMock(spec=AdminTokenCache)
        mock_cache.get_token = AsyncMock(return_value="admin-token")

        client = ServerEmailClient(
            mock_cache,
            base_url="https://api.test",
            api_key="key",
        )

        mock_templates = [
            SimpleNamespace(id="tmpl_1", template_key="welcome"),
            SimpleNamespace(id="tmpl_2", template_key="reset"),
        ]

        with patch("spaps_server_quickstart.sdk.server_clients.ServerEmailClient._get_client") as mock_get:
            mock_inner = AsyncMock()
            mock_inner.list_templates = AsyncMock(return_value=mock_templates)
            mock_inner.aclose = AsyncMock()
            mock_get.return_value = mock_inner

            result = await client.list_templates()
            assert len(result) == 2
            mock_inner.list_templates.assert_called_once()

    @pytest.mark.asyncio
    async def test_get_template_passthrough(self) -> None:
        mock_cache = AsyncMock(spec=AdminTokenCache)
        mock_cache.get_token = AsyncMock(return_value="admin-token")

        client = ServerEmailClient(
            mock_cache,
            base_url="https://api.test",
            api_key="key",
        )

        mock_template = SimpleNamespace(id="tmpl_1", template_key="welcome")

        with patch("spaps_server_quickstart.sdk.server_clients.ServerEmailClient._get_client") as mock_get:
            mock_inner = AsyncMock()
            mock_inner.get_template = AsyncMock(return_value=mock_template)
            mock_inner.aclose = AsyncMock()
            mock_get.return_value = mock_inner

            result = await client.get_template("welcome")
            assert result.template_key == "welcome"
            mock_inner.get_template.assert_called_once_with("welcome")

    @pytest.mark.asyncio
    async def test_preview_passthrough(self) -> None:
        mock_cache = AsyncMock(spec=AdminTokenCache)
        mock_cache.get_token = AsyncMock(return_value="admin-token")

        client = ServerEmailClient(
            mock_cache,
            base_url="https://api.test",
            api_key="key",
        )

        mock_preview = SimpleNamespace(subject="Test", html_body="<p>Hello</p>")

        with patch("spaps_server_quickstart.sdk.server_clients.ServerEmailClient._get_client") as mock_get:
            mock_inner = AsyncMock()
            mock_inner.preview_template = AsyncMock(return_value=mock_preview)
            mock_inner.aclose = AsyncMock()
            mock_get.return_value = mock_inner

            result = await client.preview("welcome", {"name": "Alice"})
            assert result.subject == "Test"
            mock_inner.preview_template.assert_called_once_with("welcome", context={"name": "Alice"})


# ---------------------------------------------------------------------------
# ServerPaymentsClient tests
# ---------------------------------------------------------------------------


class TestServerPaymentsClient:
    @pytest.mark.asyncio
    async def test_create_checkout_session_passthrough(self) -> None:
        mock_cache = AsyncMock(spec=AdminTokenCache)
        mock_cache.get_token = AsyncMock(return_value="admin-token")

        client = ServerPaymentsClient(
            mock_cache,
            base_url="https://api.test",
            api_key="key",
        )

        mock_result = SimpleNamespace(url="https://checkout.stripe.com/session-123")

        with patch("spaps_server_quickstart.sdk.server_clients.ServerPaymentsClient._get_client") as mock_get:
            mock_inner = AsyncMock()
            mock_inner.create_checkout_session = AsyncMock(return_value=mock_result)
            mock_inner.aclose = AsyncMock()
            mock_get.return_value = mock_inner

            result = await client.create_checkout_session(
                price_id="price_123",
                mode="payment",
                success_url="https://example.com/success",
                cancel_url="https://example.com/cancel",
            )
            assert result.url == "https://checkout.stripe.com/session-123"
            mock_inner.create_checkout_session.assert_called_once()

    @pytest.mark.asyncio
    async def test_create_authenticated_checkout_session_passthrough(self) -> None:
        mock_cache = AsyncMock(spec=AdminTokenCache)
        mock_cache.get_token = AsyncMock(return_value="admin-token")

        client = ServerPaymentsClient(
            mock_cache,
            base_url="https://api.test",
            api_key="key",
        )

        with patch("spaps_server_quickstart.sdk.server_clients.ServerPaymentsClient._get_client") as mock_get:
            mock_inner = AsyncMock()
            mock_inner.create_authenticated_checkout_session = AsyncMock(
                return_value={"id": "cs_1", "url": "https://checkout.stripe.com/cs_1"}
            )
            mock_inner.aclose = AsyncMock()
            mock_get.return_value = mock_inner

            result = await client.create_authenticated_checkout_session(
                line_items=[{"price_id": "price_1", "quantity": 1}],
                success_url="https://example.com/success",
                cancel_url="https://example.com/cancel",
            )
            assert result["id"] == "cs_1"
            mock_inner.create_authenticated_checkout_session.assert_called_once()

    @pytest.mark.asyncio
    async def test_create_guest_checkout_session_passthrough(self) -> None:
        mock_cache = AsyncMock(spec=AdminTokenCache)
        mock_cache.get_token = AsyncMock(return_value="admin-token")

        client = ServerPaymentsClient(
            mock_cache,
            base_url="https://api.test",
            api_key="key",
        )

        with patch("spaps_server_quickstart.sdk.server_clients.ServerPaymentsClient._get_client") as mock_get:
            mock_inner = AsyncMock()
            mock_inner.create_guest_checkout_session = AsyncMock(
                return_value=SimpleNamespace(id="cs_guest_1", url="https://checkout.stripe.com/cs_guest_1")
            )
            mock_inner.aclose = AsyncMock()
            mock_get.return_value = mock_inner

            result = await client.create_guest_checkout_session(
                customer_email="guest@example.com",
                mode="payment",
                line_items=[{"price_id": "price_1", "quantity": 1}],
                success_url="https://example.com/success",
                cancel_url="https://example.com/cancel",
            )
            assert result.id == "cs_guest_1"
            mock_inner.create_guest_checkout_session.assert_called_once()

    @pytest.mark.asyncio
    async def test_list_all_products_passthrough(self) -> None:
        mock_cache = AsyncMock(spec=AdminTokenCache)
        mock_cache.get_token = AsyncMock(return_value="admin-token")

        client = ServerPaymentsClient(
            mock_cache,
            base_url="https://api.test",
            api_key="key",
        )

        with patch("spaps_server_quickstart.sdk.server_clients.ServerPaymentsClient._get_client") as mock_get:
            mock_inner = AsyncMock()
            mock_inner.list_all_products = AsyncMock(
                return_value=SimpleNamespace(products=[SimpleNamespace(id="p1"), SimpleNamespace(id="p2")])
            )
            mock_inner.aclose = AsyncMock()
            mock_get.return_value = mock_inner

            result = await client.list_all_products()
            assert len(result.products) == 2
            mock_inner.list_all_products.assert_called_once()

    @pytest.mark.asyncio
    async def test_create_product_passthrough(self) -> None:
        mock_cache = AsyncMock(spec=AdminTokenCache)
        mock_cache.get_token = AsyncMock(return_value="admin-token")

        client = ServerPaymentsClient(
            mock_cache,
            base_url="https://api.test",
            api_key="key",
        )

        with patch("spaps_server_quickstart.sdk.server_clients.ServerPaymentsClient._get_client") as mock_get:
            mock_inner = AsyncMock()
            mock_inner.create_product = AsyncMock(return_value=SimpleNamespace(id="prod_new", name="New"))
            mock_inner.aclose = AsyncMock()
            mock_get.return_value = mock_inner

            result = await client.create_product(name="New", description="Product")
            assert result.id == "prod_new"
            mock_inner.create_product.assert_called_once()

    @pytest.mark.asyncio
    async def test_update_product_passthrough(self) -> None:
        mock_cache = AsyncMock(spec=AdminTokenCache)
        mock_cache.get_token = AsyncMock(return_value="admin-token")

        client = ServerPaymentsClient(
            mock_cache,
            base_url="https://api.test",
            api_key="key",
        )

        with patch("spaps_server_quickstart.sdk.server_clients.ServerPaymentsClient._get_client") as mock_get:
            mock_inner = AsyncMock()
            mock_inner.update_product = AsyncMock(return_value=SimpleNamespace(id="prod_123", name="Updated"))
            mock_inner.aclose = AsyncMock()
            mock_get.return_value = mock_inner

            result = await client.update_product(product_id="prod_123", name="Updated")
            assert result.name == "Updated"
            mock_inner.update_product.assert_called_once()

    @pytest.mark.asyncio
    async def test_archive_product_passthrough(self) -> None:
        mock_cache = AsyncMock(spec=AdminTokenCache)
        mock_cache.get_token = AsyncMock(return_value="admin-token")

        client = ServerPaymentsClient(
            mock_cache,
            base_url="https://api.test",
            api_key="key",
        )

        with patch("spaps_server_quickstart.sdk.server_clients.ServerPaymentsClient._get_client") as mock_get:
            mock_inner = AsyncMock()
            mock_inner.archive_product = AsyncMock(return_value={"archived": True})
            mock_inner.aclose = AsyncMock()
            mock_get.return_value = mock_inner

            result = await client.archive_product(product_id="prod_123")
            assert result["archived"] is True
            mock_inner.archive_product.assert_called_once_with(product_id="prod_123")

    @pytest.mark.asyncio
    async def test_create_price_passthrough(self) -> None:
        mock_cache = AsyncMock(spec=AdminTokenCache)
        mock_cache.get_token = AsyncMock(return_value="admin-token")

        client = ServerPaymentsClient(
            mock_cache,
            base_url="https://api.test",
            api_key="key",
        )

        with patch("spaps_server_quickstart.sdk.server_clients.ServerPaymentsClient._get_client") as mock_get:
            mock_inner = AsyncMock()
            mock_inner.create_price = AsyncMock(
                return_value=SimpleNamespace(id="price_new", unit_amount=1000)
            )
            mock_inner.aclose = AsyncMock()
            mock_get.return_value = mock_inner

            result = await client.create_price(product_id="prod_123", unit_amount=1000, currency="usd")
            assert result.id == "price_new"
            mock_inner.create_price.assert_called_once()

    @pytest.mark.asyncio
    async def test_archive_price_passthrough(self) -> None:
        mock_cache = AsyncMock(spec=AdminTokenCache)
        mock_cache.get_token = AsyncMock(return_value="admin-token")

        client = ServerPaymentsClient(
            mock_cache,
            base_url="https://api.test",
            api_key="key",
        )

        with patch("spaps_server_quickstart.sdk.server_clients.ServerPaymentsClient._get_client") as mock_get:
            mock_inner = AsyncMock()
            mock_inner.archive_price = AsyncMock(return_value={"archived": True})
            mock_inner.aclose = AsyncMock()
            mock_get.return_value = mock_inner

            result = await client.archive_price(price_id="price_123")
            assert result["archived"] is True
            mock_inner.archive_price.assert_called_once_with(price_id="price_123")

    @pytest.mark.asyncio
    async def test_set_default_price_passthrough(self) -> None:
        mock_cache = AsyncMock(spec=AdminTokenCache)
        mock_cache.get_token = AsyncMock(return_value="admin-token")

        client = ServerPaymentsClient(
            mock_cache,
            base_url="https://api.test",
            api_key="key",
        )

        with patch("spaps_server_quickstart.sdk.server_clients.ServerPaymentsClient._get_client") as mock_get:
            mock_inner = AsyncMock()
            mock_inner.set_default_price = AsyncMock(
                return_value=SimpleNamespace(id="prod_123", default_price_id="price_456")
            )
            mock_inner.aclose = AsyncMock()
            mock_get.return_value = mock_inner

            result = await client.set_default_price(product_id="prod_123", price_id="price_456")
            assert result.default_price_id == "price_456"
            mock_inner.set_default_price.assert_called_once_with(
                product_id="prod_123",
                price_id="price_456",
            )

    @pytest.mark.asyncio
    async def test_create_price_and_set_default_passthrough(self) -> None:
        mock_cache = AsyncMock(spec=AdminTokenCache)
        mock_cache.get_token = AsyncMock(return_value="admin-token")

        client = ServerPaymentsClient(
            mock_cache,
            base_url="https://api.test",
            api_key="key",
        )

        with patch("spaps_server_quickstart.sdk.server_clients.ServerPaymentsClient._get_client") as mock_get:
            mock_inner = AsyncMock()
            mock_inner.create_price_and_set_default = AsyncMock(
                return_value={"price": {"id": "price_new"}, "product_id": "prod_123"}
            )
            mock_inner.aclose = AsyncMock()
            mock_get.return_value = mock_inner

            result = await client.create_price_and_set_default(
                product_id="prod_123",
                unit_amount=1500,
                currency="usd",
            )
            assert result["price"]["id"] == "price_new"
            mock_inner.create_price_and_set_default.assert_called_once()


class TestServerDayrateClient:
    @pytest.mark.asyncio
    async def test_get_allotment_passthrough(self) -> None:
        mock_cache = AsyncMock(spec=AdminTokenCache)
        mock_cache.get_token = AsyncMock(return_value="admin-token")

        client = ServerDayrateClient(
            mock_cache,
            base_url="https://api.test",
            api_key="key",
        )

        with patch("spaps_server_quickstart.sdk.server_clients.ServerDayrateClient._get_client") as mock_get:
            mock_inner = AsyncMock()
            mock_inner.get_allotment = AsyncMock(return_value={"entitled": True})
            mock_inner.aclose = AsyncMock()
            mock_get.return_value = mock_inner

            result = await client.get_allotment(policy_key="checkin_policy", user_id="user-1")
            assert result["entitled"] is True
            mock_inner.get_allotment.assert_called_once_with(
                policy_key="checkin_policy",
                user_id="user-1",
                email=None,
            )

    @pytest.mark.asyncio
    async def test_get_admin_bookings_passthrough(self) -> None:
        mock_cache = AsyncMock(spec=AdminTokenCache)
        mock_cache.get_token = AsyncMock(return_value="admin-token")

        client = ServerDayrateClient(
            mock_cache,
            base_url="https://api.test",
            api_key="key",
        )

        with patch("spaps_server_quickstart.sdk.server_clients.ServerDayrateClient._get_client") as mock_get:
            mock_inner = AsyncMock()
            mock_inner.get_admin_bookings = AsyncMock(return_value={"bookings": [], "total": 0})
            mock_inner.aclose = AsyncMock()
            mock_get.return_value = mock_inner

            result = await client.get_admin_bookings(status="confirmed", limit=10, offset=0)
            assert result["total"] == 0
            mock_inner.get_admin_bookings.assert_called_once_with(
                status="confirmed",
                start_date=None,
                end_date=None,
                client_email=None,
                enrollment_id=None,
                user_id=None,
                is_free=None,
                limit=10,
                offset=0,
            )

    @pytest.mark.asyncio
    async def test_get_availability_passthrough(self) -> None:
        mock_cache = AsyncMock(spec=AdminTokenCache)
        mock_cache.get_token = AsyncMock(return_value="admin-token")

        client = ServerDayrateClient(
            mock_cache,
            base_url="https://api.test",
            api_key="key",
        )

        with patch("spaps_server_quickstart.sdk.server_clients.ServerDayrateClient._get_client") as mock_get:
            mock_inner = AsyncMock()
            mock_inner.get_availability = AsyncMock(return_value={"slots": [{"date": "2024-01-15"}]})
            mock_inner.aclose = AsyncMock()
            mock_get.return_value = mock_inner

            result = await client.get_availability()
            assert "slots" in result
            mock_inner.get_availability.assert_called_once()

    @pytest.mark.asyncio
    async def test_create_booking_passthrough(self) -> None:
        mock_cache = AsyncMock(spec=AdminTokenCache)
        mock_cache.get_token = AsyncMock(return_value="admin-token")

        client = ServerDayrateClient(
            mock_cache,
            base_url="https://api.test",
            api_key="key",
        )

        with patch("spaps_server_quickstart.sdk.server_clients.ServerDayrateClient._get_client") as mock_get:
            mock_inner = AsyncMock()
            mock_inner.create_booking = AsyncMock(return_value={"booking_id": "bk_123", "status": "confirmed"})
            mock_inner.aclose = AsyncMock()
            mock_get.return_value = mock_inner

            result = await client.create_booking(
                date="2024-01-15",
                slot="morning",
                client_email="test@example.com",
                client_name="Test User",
                success_url="https://example.com/success",
                cancel_url="https://example.com/cancel",
            )
            assert result["booking_id"] == "bk_123"
            mock_inner.create_booking.assert_called_once()

    @pytest.mark.asyncio
    async def test_cancel_booking_passthrough(self) -> None:
        mock_cache = AsyncMock(spec=AdminTokenCache)
        mock_cache.get_token = AsyncMock(return_value="admin-token")

        client = ServerDayrateClient(
            mock_cache,
            base_url="https://api.test",
            api_key="key",
        )

        with patch("spaps_server_quickstart.sdk.server_clients.ServerDayrateClient._get_client") as mock_get:
            mock_inner = AsyncMock()
            mock_inner.cancel_booking = AsyncMock(return_value={"booking_id": "bk_123", "status": "cancelled"})
            mock_inner.aclose = AsyncMock()
            mock_get.return_value = mock_inner

            result = await client.cancel_booking(booking_id="bk_123", user_id="user-1", email="test@example.com")
            assert result["status"] == "cancelled"
            mock_inner.cancel_booking.assert_called_once_with(
                booking_id="bk_123",
                user_id="user-1",
                email="test@example.com",
            )


# ---------------------------------------------------------------------------
# RoleHierarchy tests
# ---------------------------------------------------------------------------


class TestRoleHierarchy:
    def setup_method(self) -> None:
        self.hierarchy = RoleHierarchy({
            "admin": 4,
            "accountant": 3,
            "client": 2,
            "viewer": 1,
        })

    def test_admin_gte_accountant(self) -> None:
        assert self.hierarchy.has_minimum_role("admin", "accountant") is True

    def test_admin_gte_admin(self) -> None:
        assert self.hierarchy.has_minimum_role("admin", "admin") is True

    def test_client_lt_accountant(self) -> None:
        assert self.hierarchy.has_minimum_role("client", "accountant") is False

    def test_unknown_user_role(self) -> None:
        assert self.hierarchy.has_minimum_role("unknown", "viewer") is False

    def test_unknown_required_role(self) -> None:
        assert self.hierarchy.has_minimum_role("admin", "unknown") is False

    def test_case_insensitive(self) -> None:
        assert self.hierarchy.has_minimum_role("ADMIN", "accountant") is True
        assert self.hierarchy.has_minimum_role("Admin", "Accountant") is True

    def test_get_level(self) -> None:
        assert self.hierarchy.get_level("admin") == 4
        assert self.hierarchy.get_level("viewer") == 1
        assert self.hierarchy.get_level("nonexistent") is None


class TestRequireMinimumRole:
    @pytest.mark.asyncio
    async def test_returns_user_when_role_sufficient(self) -> None:
        hierarchy = RoleHierarchy({"admin": 4, "client": 2, "viewer": 1})
        dependency = require_minimum_role(hierarchy, "client")

        scope = {"type": "http", "state": {}}
        request = Request(scope)
        user = AuthenticatedUser(
            user_id="u1", session_id="s1", application_id="a1",
            roles={"admin"},
        )
        request.state.authenticated_user = user

        result = await dependency(request)
        assert result is user

    @pytest.mark.asyncio
    async def test_raises_forbidden_when_role_insufficient(self) -> None:
        hierarchy = RoleHierarchy({"admin": 4, "client": 2, "viewer": 1})
        dependency = require_minimum_role(hierarchy, "admin")

        scope = {"type": "http", "state": {}}
        request = Request(scope)
        user = AuthenticatedUser(
            user_id="u1", session_id="s1", application_id="a1",
            roles={"viewer"},
        )
        request.state.authenticated_user = user

        with pytest.raises(Exception) as exc:
            await dependency(request)
        assert getattr(exc.value, "status_code", None) == status.HTTP_403_FORBIDDEN

    @pytest.mark.asyncio
    async def test_raises_unauthorized_when_no_user(self) -> None:
        hierarchy = RoleHierarchy({"admin": 4})
        dependency = require_minimum_role(hierarchy, "admin")

        scope = {"type": "http", "state": {}}
        request = Request(scope)

        with pytest.raises(Exception) as exc:
            await dependency(request)
        assert getattr(exc.value, "status_code", None) == status.HTTP_401_UNAUTHORIZED

    def test_fastapi_integration(self) -> None:
        hierarchy = RoleHierarchy({"admin": 4, "viewer": 1})
        app = FastAPI()

        @app.get("/admin")
        async def admin_endpoint(
            user: AuthenticatedUser = Depends(require_minimum_role(hierarchy, "admin"))
        ):
            return {"user_id": user.user_id}

        @app.middleware("http")
        async def inject_user(request: Request, call_next: Any) -> Any:
            request.state.authenticated_user = AuthenticatedUser(
                user_id="u1", session_id="s1", application_id="a1",
                roles={"admin"},
            )
            return await call_next(request)

        client = TestClient(app)
        response = client.get("/admin")
        assert response.status_code == 200
        assert response.json() == {"user_id": "u1"}


# ---------------------------------------------------------------------------
# TrustedServiceMiddleware tests
# ---------------------------------------------------------------------------


class TestBuildTrustedServiceHeaders:
    @staticmethod
    def _expected_signature(
        *,
        key: str,
        method: str,
        path: str,
        timestamp: str,
        nonce: str,
        subject: str,
        body: bytes,
    ) -> str:
        body_hash = hashlib.sha256(body).hexdigest()
        canonical = f"{method.upper()}\n{path}\n{timestamp}\n{nonce}\n{subject}\n{body_hash}"
        return hmac.new(key.encode("utf-8"), canonical.encode("utf-8"), hashlib.sha256).hexdigest()

    def test_builds_signed_headers_with_normalized_roles(self) -> None:
        headers = build_trusted_service_headers(
            key="trusted-secret",
            user_id="user-42",
            method="get",
            path="/resource",
            body=b'{"ok":true}',
            roles=[" Admin ", "", "editor", "  "],
            nonce="nonce-123",
            timestamp=1700000000,
        )

        assert headers["X-API-Key"] == "trusted-secret"
        assert headers["X-Trusted-Subject"] == "user-42"
        assert headers["X-Trusted-Timestamp"] == "1700000000"
        assert headers["X-Trusted-Nonce"] == "nonce-123"
        assert headers["X-Trusted-Roles"] == "admin, editor"
        assert headers["X-Trusted-Signature"] == self._expected_signature(
            key="trusted-secret",
            method="get",
            path="/resource",
            timestamp="1700000000",
            nonce="nonce-123",
            subject="user-42",
            body=b'{"ok":true}',
        )

    def test_omits_roles_header_when_roles_are_blank(self) -> None:
        headers = build_trusted_service_headers(
            key="trusted-secret",
            user_id="user-42",
            method="GET",
            path="/resource",
            roles=["", " ", "\t"],
            nonce="nonce-roles",
            timestamp=1700000001,
        )

        assert "X-Trusted-Roles" not in headers


class TestTrustedServiceMiddleware:
    def _make_app(self, trusted_key: str = "trusted-secret") -> FastAPI:
        app = FastAPI()

        app.add_middleware(
            TrustedServiceMiddleware,
            trusted_service_key=trusted_key,
        )

        @app.get("/resource")
        async def resource_endpoint(request: Request) -> dict:
            user = getattr(request.state, "authenticated_user", None)
            if user:
                return {
                    "user_id": user.user_id,
                    "roles": sorted(user.roles),
                    "authenticated": True,
                }
            return {"authenticated": False}

        return app

    @staticmethod
    def _build_signature(
        *,
        key: str,
        method: str,
        path: str,
        timestamp: str,
        nonce: str,
        subject: str,
        body: bytes = b"",
    ) -> str:
        body_hash = hashlib.sha256(body).hexdigest()
        canonical = f"{method}\n{path}\n{timestamp}\n{nonce}\n{subject}\n{body_hash}"
        return hmac.new(key.encode("utf-8"), canonical.encode("utf-8"), hashlib.sha256).hexdigest()

    def _signed_headers(
        self,
        *,
        trusted_key: str = "trusted-secret",
        method: str = "GET",
        path: str = "/resource",
        subject: str = "user-42",
        timestamp: str | None = None,
        nonce: str = "nonce-123",
        roles: str | None = None,
        body: bytes = b"",
        signature: str | None = None,
    ) -> dict[str, str]:
        ts = timestamp or str(int(time.time()))
        sig = signature or self._build_signature(
            key=trusted_key,
            method=method,
            path=path,
            timestamp=ts,
            nonce=nonce,
            subject=subject,
            body=body,
        )
        headers: dict[str, str] = {
            "X-API-Key": trusted_key,
            "X-Trusted-Subject": subject,
            "X-Trusted-Timestamp": ts,
            "X-Trusted-Nonce": nonce,
            "X-Trusted-Signature": sig,
        }
        if roles is not None:
            headers["X-Trusted-Roles"] = roles
        return headers

    def test_valid_signed_request_authenticates(self) -> None:
        app = self._make_app()
        client = TestClient(app)
        response = client.get(
            "/resource",
            headers=self._signed_headers(),
        )
        assert response.status_code == 200
        data = response.json()
        assert data["authenticated"] is True
        assert data["user_id"] == "user-42"

    def test_invalid_key_passes_through(self) -> None:
        """Non-matching key lets request through to downstream (no auth set)."""
        app = self._make_app()
        client = TestClient(app)
        response = client.get(
            "/resource",
            headers={
                "X-API-Key": "wrong-key",
                "X-Trusted-Subject": "user-42",
            },
        )
        assert response.status_code == 200
        data = response.json()
        assert data["authenticated"] is False

    def test_missing_required_assertion_headers_returns_401(self) -> None:
        app = self._make_app()
        client = TestClient(app)
        response = client.get(
            "/resource",
            headers={
                "X-API-Key": "trusted-secret",
            },
        )
        assert response.status_code == 401

    def test_invalid_signature_returns_401(self) -> None:
        app = self._make_app()
        client = TestClient(app)
        headers = self._signed_headers(signature="deadbeef")
        response = client.get("/resource", headers=headers)
        assert response.status_code == 401

    def test_stale_timestamp_returns_401(self) -> None:
        app = self._make_app()
        client = TestClient(app)
        headers = self._signed_headers(timestamp=str(int(time.time()) - 600))
        response = client.get("/resource", headers=headers)
        assert response.status_code == 401

    def test_replayed_nonce_returns_401(self) -> None:
        app = self._make_app()
        client = TestClient(app)
        headers = self._signed_headers(nonce="nonce-replay")
        first = client.get("/resource", headers=headers)
        second = client.get("/resource", headers=headers)
        assert first.status_code == 200
        assert second.status_code == 401

    def test_signed_role_passthrough(self) -> None:
        app = self._make_app()
        client = TestClient(app)
        response = client.get(
            "/resource",
            headers=self._signed_headers(
                subject="user-99",
                nonce="nonce-role",
                roles="admin, editor",
            ),
        )
        assert response.status_code == 200
        data = response.json()
        assert data["roles"] == ["admin", "editor"]

    def test_no_api_key_passes_through(self) -> None:
        """Requests without X-API-Key pass through to downstream."""
        app = self._make_app()
        client = TestClient(app)
        response = client.get("/resource")
        assert response.status_code == 200
        data = response.json()
        assert data["authenticated"] is False


# ---------------------------------------------------------------------------
# FeatureEvaluator tests
# ---------------------------------------------------------------------------


class TestFeatureEvaluator:
    def _make_evaluator(
        self,
        entitlements_list_results: dict[str, list[Any]] | None = None,
    ) -> tuple[FeatureEvaluator, AsyncMock]:
        mock_entitlements = AsyncMock(spec=ServerEntitlementsClient)

        if entitlements_list_results is not None:
            async def list_side_effect(
                *,
                resource_type: str | None = None,
                resource_id: str | None = None,
                entitlement_key: str | None = None,
                **kwargs: Any,
            ) -> list[Any]:
                # Build a lookup key from the query parameters
                parts = [p for p in [resource_type, resource_id, entitlement_key] if p is not None]
                lookup_key = ":".join(parts)
                return entitlements_list_results.get(lookup_key, [])

            mock_entitlements.list = AsyncMock(side_effect=list_side_effect)
        else:
            mock_entitlements.list = AsyncMock(return_value=[])

        hierarchy = RoleHierarchy({
            "admin": 4,
            "accountant": 3,
            "client": 2,
            "viewer": 1,
        })

        evaluator = FeatureEvaluator(mock_entitlements, hierarchy)
        return evaluator, mock_entitlements

    @pytest.mark.asyncio
    async def test_unconfigured_feature_enabled_by_default(self) -> None:
        evaluator, _ = self._make_evaluator()
        context = FeatureContext(user_id="user-1", user_roles={"viewer"})
        result = await evaluator.is_enabled("nonexistent_feature", context)
        assert result is True

    @pytest.mark.asyncio
    async def test_kill_switch_blocks_feature(self) -> None:
        evaluator, _ = self._make_evaluator(
            entitlements_list_results={
                "system:feature_x_disabled": [SimpleNamespace(id="e1", key="feature_x_disabled")],
            }
        )
        evaluator.register_feature(
            "feature_x",
            FeatureDefinition(kill_switch_key="feature_x_disabled"),
        )
        context = FeatureContext(user_id="user-1", user_roles={"admin"})
        result = await evaluator.is_enabled("feature_x", context)
        assert result is False

    @pytest.mark.asyncio
    async def test_admin_bypass_overrides_kill_switch(self) -> None:
        evaluator, _ = self._make_evaluator(
            entitlements_list_results={
                "system:feature_x_disabled": [SimpleNamespace(id="e1", key="feature_x_disabled")],
            }
        )
        evaluator.register_feature(
            "feature_x",
            FeatureDefinition(kill_switch_key="feature_x_disabled"),
        )
        context = FeatureContext(
            user_id="user-1",
            user_roles={"admin"},
            is_super_admin=True,
        )
        result = await evaluator.is_enabled("feature_x", context)
        assert result is True

    @pytest.mark.asyncio
    async def test_resource_block(self) -> None:
        evaluator, _ = self._make_evaluator(
            entitlements_list_results={
                "company:comp-123:comp_blocked": [SimpleNamespace(id="e2", key="comp_blocked")],
            }
        )
        evaluator.register_feature(
            "billing",
            FeatureDefinition(resource_block_key="comp_blocked"),
        )
        context = FeatureContext(
            user_id="user-1",
            user_roles={"admin"},
            resource_type="company",
            resource_id="comp-123",
        )
        result = await evaluator.is_enabled("billing", context)
        assert result is False

    @pytest.mark.asyncio
    async def test_role_minimum_blocks(self) -> None:
        evaluator, _ = self._make_evaluator()
        evaluator.register_feature(
            "admin_panel",
            FeatureDefinition(minimum_role="admin"),
        )
        context = FeatureContext(user_id="user-1", user_roles={"viewer"})
        result = await evaluator.is_enabled("admin_panel", context)
        assert result is False

    @pytest.mark.asyncio
    async def test_role_minimum_allows(self) -> None:
        evaluator, _ = self._make_evaluator()
        evaluator.register_feature(
            "admin_panel",
            FeatureDefinition(minimum_role="accountant"),
        )
        context = FeatureContext(user_id="user-1", user_roles={"admin"})
        result = await evaluator.is_enabled("admin_panel", context)
        assert result is True

    @pytest.mark.asyncio
    async def test_all_layers_pass(self) -> None:
        evaluator, _ = self._make_evaluator(
            entitlements_list_results={
                "system:feature_y_disabled": [],
                "company:comp-1:comp_blocked": [],
            }
        )
        evaluator.register_feature(
            "feature_y",
            FeatureDefinition(
                kill_switch_key="feature_y_disabled",
                resource_block_key="comp_blocked",
                minimum_role="client",
            ),
        )
        context = FeatureContext(
            user_id="user-1",
            user_roles={"accountant"},
            resource_type="company",
            resource_id="comp-1",
        )
        result = await evaluator.is_enabled("feature_y", context)
        assert result is True

    @pytest.mark.asyncio
    async def test_kill_switch_error_fails_open(self) -> None:
        """If the entitlements list call fails, the kill switch should fail open."""
        evaluator, mock_ent = self._make_evaluator()
        mock_ent.list = AsyncMock(side_effect=RuntimeError("network error"))
        evaluator.register_feature(
            "feature_z",
            FeatureDefinition(kill_switch_key="feature_z_disabled"),
        )
        context = FeatureContext(user_id="user-1", user_roles={"admin"})
        result = await evaluator.is_enabled("feature_z", context)
        assert result is True


# ---------------------------------------------------------------------------
# Import smoke tests
# ---------------------------------------------------------------------------


def test_sdk_importable() -> None:
    """Verify all SDK classes are importable from the package root."""
    from spaps_server_quickstart import (
        AdminTokenCache,
        FeatureEvaluator,
        RoleHierarchy,
        TrustedServiceMiddleware,
    )

    # Basic sanity
    assert AdminTokenCache is not None
    assert RoleHierarchy is not None
    assert TrustedServiceMiddleware is not None
    assert FeatureEvaluator is not None
