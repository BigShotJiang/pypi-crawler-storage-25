from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest

from spaps_server_quickstart.seeds import cli as seeds_cli


def _validate_entrypoint():
    validate_obj = seeds_cli.validate
    return getattr(validate_obj, "callback", validate_obj)


@pytest.mark.skipif(not seeds_cli.CLICK_AVAILABLE, reason="click is not installed")
def test_validate_file_success_prints_valid_message(tmp_path: Path) -> None:
    path = tmp_path / "users.yaml"
    path.write_text("users: []\n")

    with (
        patch.object(seeds_cli, "validate_file", return_value=(True, None)) as mock_validate,
        patch.object(seeds_cli.click, "echo") as mock_echo,
    ):
        _validate_entrypoint()(path=path, verbose=True)

    mock_validate.assert_called_once_with(path, True)
    rendered = mock_echo.call_args.args[0]
    assert "users.yaml" in rendered
    assert "Valid" in rendered


@pytest.mark.skipif(not seeds_cli.CLICK_AVAILABLE, reason="click is not installed")
def test_validate_file_failure_exits_with_code_1(tmp_path: Path) -> None:
    path = tmp_path / "users.yaml"
    path.write_text("users: [broken]\n")

    with (
        patch.object(seeds_cli, "validate_file", return_value=(False, "schema mismatch")),
        patch.object(seeds_cli.click, "echo") as mock_echo,
        pytest.raises(SystemExit) as exc_info,
    ):
        _validate_entrypoint()(path=path, verbose=False)

    assert exc_info.value.code == 1
    assert mock_echo.call_args.kwargs.get("err") is True
    assert "schema mismatch" in mock_echo.call_args.args[0]


@pytest.mark.skipif(not seeds_cli.CLICK_AVAILABLE, reason="click is not installed")
def test_validate_directory_errors_exit_with_code_1(tmp_path: Path) -> None:
    with (
        patch.object(
            seeds_cli,
            "validate_directory",
            return_value=(1, 2, [("a.yaml", "bad row"), ("b.yaml", "bad type")]),
        ),
        patch.object(seeds_cli.click, "echo") as mock_echo,
        pytest.raises(SystemExit) as exc_info,
    ):
        _validate_entrypoint()(path=tmp_path, verbose=False)

    assert exc_info.value.code == 1
    assert mock_echo.call_args_list[0].args[0] == "\nResults: 1 passed, 2 failed"
    rendered_lines = [call.args[0] for call in mock_echo.call_args_list]
    assert "  a.yaml: bad row" in rendered_lines
    assert "  b.yaml: bad type" in rendered_lines


@pytest.mark.skipif(not seeds_cli.CLICK_AVAILABLE, reason="click is not installed")
def test_validate_directory_verbose_success_prints_summary(tmp_path: Path) -> None:
    with (
        patch.object(seeds_cli, "validate_directory", return_value=(2, 0, [])),
        patch.object(seeds_cli.click, "echo") as mock_echo,
    ):
        _validate_entrypoint()(path=tmp_path, verbose=True)

    rendered_lines = [call.args[0] for call in mock_echo.call_args_list]
    assert "\nResults: 2 passed, 0 failed" in rendered_lines
    assert any("All seed files valid" in line for line in rendered_lines)


@pytest.mark.skipif(seeds_cli.CLICK_AVAILABLE, reason="click is installed")
def test_validate_fallback_exits_when_click_is_missing(capsys: pytest.CaptureFixture[str]) -> None:
    with pytest.raises(SystemExit) as exc_info:
        _validate_entrypoint()(path=None, verbose=False)

    assert exc_info.value.code == 1
    assert "Click is not installed" in capsys.readouterr().out
