from __future__ import annotations

import pathlib


def _repo_makefile_contents() -> str:
    makefile_path = pathlib.Path(__file__).resolve().parents[3] / "Makefile"
    return makefile_path.read_text()


def test_load_dev_db_restore_step_fails_fast() -> None:
    """load-dev-db restore step should fail on pipeline restore errors."""
    content = _repo_makefile_contents()
    step2_marker = '@echo "Step 2: Restoring production database dump..."'
    step3_marker = '@echo "Step 3: Seeding test fixtures'

    step2_index = content.index(step2_marker)
    step3_index = content.index(step3_marker, step2_index)
    restore_block = content[step2_index:step3_index]

    assert "set -o pipefail" in restore_block
    assert "gunzip -c" in restore_block
    assert "||" not in restore_block
