# TM-ENV-001: Pre-Deployment Checklist

## Overview

This checklist ensures the email environment safety implementation is complete and safe to deploy.

## Code Changes

### ✅ Core Implementation

- [x] Updated `domains/email/service.py`
  - [x] `_is_production()` accepts `settings_env` parameter
  - [x] `_is_local_mode()` accepts `settings_local_mode` parameter
  - [x] `_should_short_circuit()` uses settings as canonical source
  - [x] `send_email()` signature updated with `settings_env` and `settings_local_mode`
  - [x] Safety gate checks settings before `force_send` logic
  - [x] Mismatch warnings added for defense-in-depth

- [x] Updated `domains/auth/service.py`
  - [x] `request_magic_link()` passes settings to `send_email()`
  - [x] `request_password_reset()` passes settings to `send_email()`
  - [x] Added `TM-ENV-001` comments

- [x] Updated `domains/email/router.py`
  - [x] `POST /email/send` endpoint passes settings to service
  - [x] Imported `get_spaps_settings()`

- [x] Fixed pre-existing bug in `ensure_auth_templates()`
  - [x] Changed `extra={"created": ...}` to `extra={"template_keys": ...}`

### ✅ Test Coverage

- [x] Created `tests/domains/email/test_env_safety.py` (16 tests)
  - [x] Test environment helper functions
  - [x] Test dev environment short-circuits
  - [x] Test test environment short-circuits
  - [x] Test local mode short-circuits in production
  - [x] Test `force_send=True` ignored in dev/test
  - [x] Test production allows sends
  - [x] Test environment variable mismatch handling

- [x] All existing tests still pass
  - [x] `tests/domains/email/test_service.py` (32 tests)
  - [x] `tests/domains/email/test_router.py` (26 tests)
  - [x] `tests/domains/auth/test_repository.py` (20 tests)
  - [x] `tests/domains/auth/test_router.py` (20 tests)
  - [x] `tests/domains/auth/test_service.py` (40 tests)

### ✅ Documentation

- [x] Created `docs/TM-ENV-001-email-environment-safety.md` (comprehensive threat model doc)
- [x] Created `docs/TM-ENV-001-summary.md` (implementation summary)
- [x] Created `docs/TM-ENV-001-checklist.md` (this file)

### ✅ Code Search

- [x] Verified all `send_email()` callers are updated
  - [x] `domains/auth/service.py:request_magic_link()` ✅
  - [x] `domains/auth/service.py:request_password_reset()` ✅
  - [x] `domains/email/router.py:send_email()` ✅
  - [x] No other callers found ✅

## Pre-Deployment Testing

### Local Testing

```bash
cd <repo-root>/packages/python-server-quickstart

# Run all email and auth tests
python -m pytest tests/domains/email/ tests/domains/auth/ -v

# Run only new safety tests
python -m pytest tests/domains/email/test_env_safety.py -v

# Run full test suite
make pytest

# Or with coverage
python -m pytest tests/ --cov=spaps_server_quickstart --cov-report=term-missing
```

### Expected Results

```
✅ 16 tests in test_env_safety.py pass
✅ 32 tests in test_service.py pass
✅ 26 tests in test_router.py pass
✅ 80 tests in auth domain pass
✅ No test failures
✅ No deprecation warnings
```

### Manual Verification

- [ ] **Dev Environment Test**
  ```bash
  # Set ENV to simulate developer mistake
  export ENV=production

  # Run tests - should still short-circuit emails
  python -m pytest tests/domains/auth/test_service.py::TestRequestMagicLink -v -s

  # Verify logs show "Email short-circuited (TM-ENV-001 safety gate)"
  # Verify logs show "ENV variable mismatch" warning
  ```

- [ ] **Check No Real Emails Sent**
  - Run test suite with Mailgun API keys configured
  - Verify Mailgun dashboard shows no test emails sent
  - Check test logs for `status="short_circuited"`

## Deployment Steps

### 1. Code Review

- [ ] Review all changes in `domains/email/service.py`
- [ ] Review all changes in `domains/auth/service.py`
- [ ] Review all changes in `domains/email/router.py`
- [ ] Review new test file `tests/domains/email/test_env_safety.py`
- [ ] Review documentation files

### 2. Merge to Main

```bash
cd <repo-root>/packages/python-server-quickstart

# Ensure tests pass
make pytest

# Stage changes
git add src/spaps_server_quickstart/domains/email/service.py
git add src/spaps_server_quickstart/domains/auth/service.py
git add src/spaps_server_quickstart/domains/email/router.py
git add tests/domains/email/test_env_safety.py
git add docs/TM-ENV-001-*.md

# Commit
git commit -m "feat(security): implement TM-ENV-001 email environment safety gates

- Establish settings.env as single source of truth for environment
- Add defense-in-depth validation with mismatch warnings
- Update auth flows (magic link, password reset) to pass settings
- Add comprehensive test coverage (16 new tests)
- Fix pre-existing logging bug in ensure_auth_templates()

Threat Model: TM-ENV-001
Impact: Prevents accidental email sends in test/dev environments
Test Coverage: 154 tests pass (no regressions)"
```

### 3. CI/CD Pipeline

- [ ] Verify CI tests pass
- [ ] Review CI logs for any warnings
- [ ] Check code coverage metrics

### 4. Staging Deployment

- [ ] Deploy to staging environment
- [ ] Verify staging uses `ENV=staging` or `ENV=dev`
- [ ] Trigger auth flows (magic link, password reset)
- [ ] Verify emails are short-circuited (check logs)
- [ ] Verify no real emails sent to Mailgun

### 5. Production Deployment

- [ ] Verify production environment has `ENV=production`
- [ ] Deploy to production
- [ ] Monitor logs for first 30 minutes
  - [ ] Check for "ENV variable mismatch" warnings (should be none)
  - [ ] Check for "Email short-circuited" in production (should be none)
  - [ ] Check for successful email sends
- [ ] Test auth flows in production
  - [ ] Request magic link (should send real email)
  - [ ] Request password reset (should send real email)
  - [ ] Verify emails arrive at recipient
- [ ] Check Mailgun dashboard for successful deliveries

## Post-Deployment Monitoring

### Day 1: Immediate Monitoring (first 24 hours)

- [ ] Monitor application logs for:
  - `"ENV variable mismatch"` warnings (investigate if found)
  - `"SPAPS_LOCAL_MODE variable mismatch"` warnings (investigate if found)
  - `"Email short-circuited (TM-ENV-001 safety gate)"` in production (should not happen)
  - Successful email sends in production

- [ ] Monitor Mailgun:
  - [ ] Email delivery rates (should be unchanged)
  - [ ] Bounce rates (should be unchanged)
  - [ ] No test emails to real users

- [ ] Monitor error tracking:
  - [ ] No new exceptions related to email sending
  - [ ] No `EmailConfigurationError` in production

### Week 1: Ongoing Monitoring

- [ ] Review weekly email metrics
- [ ] Check for any user reports of missing emails
- [ ] Verify auth flow success rates unchanged

### Search Queries for Logs

```bash
# Production: Check for mismatches (should be 0)
grep "ENV variable mismatch" /var/log/spaps-production.log

# Production: Check for accidental short-circuits (should be 0)
grep "Email short-circuited" /var/log/spaps-production.log

# Dev/Staging: Verify short-circuits happening (should be many)
grep "Email short-circuited" /var/log/spaps-dev.log | wc -l
```

## Rollback Plan

If any of the following occur:

- ❌ Emails not being sent in production
- ❌ Test emails being sent to real users
- ❌ Auth flows failing
- ❌ Unexpected errors in logs

### Immediate Rollback Steps

1. **Revert deployment**
   ```bash
   git revert <commit-hash>
   git push origin main
   ```

2. **Verify rollback**
   - Check that emails are sending in production
   - Check that auth flows work
   - Check that tests still pass

3. **Investigation**
   - Review error logs
   - Review mismatch warnings
   - Check environment variable configuration

4. **Fix and redeploy**
   - Address root cause
   - Re-run all tests
   - Follow deployment steps again

## Success Criteria

✅ **Implementation Complete When:**

- All tests pass (170 total)
- No regressions in existing functionality
- Auth flows updated with settings parameters
- Email router updated with settings parameters
- Comprehensive documentation created
- All code review feedback addressed

✅ **Deployment Successful When:**

- CI/CD pipeline passes
- Staging emails short-circuit as expected
- Production emails send successfully
- No mismatch warnings in production
- No user reports of missing emails
- Mailgun metrics unchanged

✅ **Security Goal Achieved When:**

- Test suite NEVER sends real emails (even with ENV=production in shell)
- Dev environments NEVER send real emails
- Production correctly sends real emails
- Environment mismatches are logged and visible

## Notes

- **Safe by Default**: New parameters default to `"dev"` and `False`, ensuring safe behavior if accidentally omitted
- **Backward Compatible**: Existing code will still work but should be updated for explicit safety
- **Defense in Depth**: Multiple layers of validation ensure safety even if one layer fails
- **Comprehensive Testing**: 16 new tests cover all scenarios including edge cases

## Sign-off

- [ ] Developer: Changes implemented and tested locally
- [ ] Code Review: All changes reviewed and approved
- [ ] QA: Tested in staging environment
- [ ] Security: TM-ENV-001 threat model addressed
- [ ] DevOps: Ready for production deployment
