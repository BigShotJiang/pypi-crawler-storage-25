# TM-ENV-001: Email Environment Safety

**Status**: Implemented
**Date**: 2026-02-11
**Author**: Claude (Sweet Potato Security Audit)

## Threat Model

### Threat

Auth flows (magic links, password resets) trigger outbound emails. If environment checks are inconsistent between `settings.env` (Pydantic settings) and the `ENV` environment variable, tests or dev environments could accidentally send real emails to users.

### Attack Scenario

1. Developer has `ENV=production` in their shell (leftover from debugging prod)
2. Test suite runs with test fixtures that override Pydantic settings to `env="test"`
3. Email service reads `os.environ.get("ENV")` directly instead of using `settings.env`
4. Result: Email service thinks it's in production → sends real emails during tests
5. Impact: Test emails sent to real users, PII exposure, reputation damage

### Root Cause

The email service (`domains/email/service.py`) was implemented with "defense-in-depth" by reading environment variables directly using `os.environ.get("ENV")`. This created a **split-brain scenario** where:

- **Pydantic settings** (`settings.env`) could say "test"
- **Environment variable** (`ENV`) could say "production"
- **Email service** used environment variable as source of truth, bypassing settings

## Solution

### Single Source of Truth

All environment-sensitive code now uses `settings.env` from Pydantic as the **canonical source of truth**, with environment variables providing defense-in-depth validation only.

### Changes Made

#### 1. Email Service (`domains/email/service.py`)

**Before:**
```python
def _is_production() -> bool:
    env = os.environ.get("ENV", "").lower()
    return env == "production"

def _should_short_circuit() -> bool:
    if _is_local_mode():
        return True
    if not _is_production():
        return True
    return False
```

**After:**
```python
def _is_production(settings_env: str) -> bool:
    """Uses settings.env as canonical source, with ENV var for defense-in-depth."""
    canonical = settings_env.lower() in ("production", "prod")
    env_var = os.environ.get("ENV", "").lower()

    # Warn if environment variable disagrees with settings
    if env_var and env_var in ("production", "prod") and not canonical:
        logger.warning(
            "ENV variable mismatch: ENV=%s but settings.env=%s. "
            "Using settings.env as canonical to prevent accidental email sends.",
            env_var, settings_env
        )

    return canonical

def _should_short_circuit(settings_env: str, settings_local_mode: bool) -> bool:
    """Primary safety gate - uses settings.env as canonical source."""
    if _is_local_mode(settings_local_mode):
        return True
    if not _is_production(settings_env):
        return True
    return False
```

**Updated `send_email()` signature:**
```python
async def send_email(
    db: AsyncSession,
    *,
    application_id: UUID,
    template_key: str,
    to: str,
    settings_env: str = "dev",                    # NEW: canonical environment
    settings_local_mode: bool = False,             # NEW: canonical local mode flag
    context: dict[str, Any] | None = None,
    # ... other params
    force_send: bool = False,
) -> dict[str, Any]:
```

**Safety gate logic:**
```python
# TM-ENV-001: Safety invariant — short-circuit in non-production / local mode
# This check ALWAYS runs first, even with force_send=True
should_skip = _should_short_circuit(settings_env, settings_local_mode)

if should_skip:
    logger.info(
        "Email short-circuited (TM-ENV-001 safety gate)",
        extra={
            "to": to,
            "template_key": template_key,
            "settings_env": settings_env,
            "force_send": force_send,
        },
    )
    # Log but never send
    return {"message_id": f"local-{log_entry.id}"}
```

#### 2. Auth Service (`domains/auth/service.py`)

Updated both `request_magic_link()` and `request_password_reset()` to pass settings:

```python
await email_service.send_email(
    db,
    application_id=app_uuid,
    template_key="auth_magic_link",
    to=email,
    settings_env=settings.env,                    # NEW
    settings_local_mode=settings.is_spaps_local_mode,  # NEW
    context={"link": link, "expires_in_minutes": 60},
    force_send=True,
)
```

#### 3. Email Router (`domains/email/router.py`)

Updated `/email/send` endpoint to pass settings:

```python
@email_router.post("/send", response_model=SendEmailResponse)
async def send_email(body: SendEmailRequest, db: DbSession, app: Application):
    settings = get_spaps_settings()
    result = await service.send_email(
        db,
        application_id=app.id,
        template_key=body.template_key,
        to=body.to,
        settings_env=settings.env,                    # NEW
        settings_local_mode=settings.is_spaps_local_mode,  # NEW
        # ... other params
    )
    return SendEmailResponse(**result)
```

### Defense-in-Depth Features

1. **Primary Gate**: `settings.env` must be `"production"` or `"prod"` for emails to send
2. **Local Mode Gate**: `settings.is_spaps_local_mode` short-circuits even in production
3. **Mismatch Warning**: Logs warning if `ENV` environment variable disagrees with `settings.env`
4. **force_send Clarification**: `force_send=True` only bypasses application throttling in production; it never bypasses environment safety gates

### Test Coverage

Created comprehensive test suite (`tests/domains/email/test_env_safety.py`) covering:

- Environment helper functions validate against settings
- Dev/test environments always short-circuit
- Local mode short-circuits even in production
- `force_send=True` is ignored in non-production environments
- Production with valid config allows sends
- Environment variable mismatches use settings as canonical and log warnings

All 16 tests pass ✅

## Verification

### Test Fixtures

The pytest testing infrastructure (`src/spaps_server_quickstart/testing.py`) already sets `ENV=test` in the environment:

```python
@pytest.fixture(scope="function")
def configure_test_settings(database_urls: DatabaseURLs) -> Iterator[None]:
    env_overrides = {"DATABASE_URL": database_urls.app_async_url, "ENV": "test"}
    # ... sets os.environ["ENV"] = "test"
```

### Runtime Behavior

| Scenario | `settings.env` | `ENV` var | `settings.is_spaps_local_mode` | Result |
|----------|----------------|-----------|-------------------------------|--------|
| Tests | `"test"` | `"test"` | `False` | Short-circuit ✅ |
| Dev | `"dev"` | `"dev"` | `False` | Short-circuit ✅ |
| Dev (local mode) | `"dev"` | `"dev"` | `True` | Short-circuit ✅ |
| Production | `"production"` | `"production"` | `False` | Send email 📧 |
| Production (local mode) | `"production"` | `"production"` | `True` | Short-circuit ✅ |
| **Mismatch** | `"test"` | `"production"` | `False` | Short-circuit + warn ⚠️ |

## Migration Notes

### For Callers of `send_email()`

**Before:**
```python
await send_email(
    db,
    application_id=app_id,
    template_key="welcome",
    to="user@example.com",
    context={"name": "Alice"},
)
```

**After (required changes):**
```python
from spaps_settings import get_spaps_settings

settings = get_spaps_settings()
await send_email(
    db,
    application_id=app_id,
    template_key="welcome",
    to="user@example.com",
    settings_env=settings.env,                        # NEW (required)
    settings_local_mode=settings.is_spaps_local_mode, # NEW (required)
    context={"name": "Alice"},
)
```

### Backward Compatibility

The new parameters have defaults:
- `settings_env: str = "dev"` — defaults to dev (safe)
- `settings_local_mode: bool = False` — defaults to False

However, **all production code should explicitly pass these parameters** to ensure the correct environment is used.

## Related Changes

### Fixed Pre-existing Bug

Fixed logging bug in `ensure_auth_templates()` where `"created"` was used as an `extra` key, conflicting with Python's `LogRecord.created` field:

```python
# Before (crashed)
logger.info("Auth email templates seeded", extra={"created": created, ...})

# After (works)
logger.info("Auth email templates seeded", extra={"template_keys": created, ...})
```

## Future Enhancements

1. **Type-safe settings injection**: Consider using FastAPI dependency injection to pass settings to service functions
2. **Environment enum**: Replace string literals with `Enum` for environment names
3. **Audit logging**: Log all email send attempts (both short-circuited and successful) to audit trail
4. **Monitoring**: Alert on environment variable mismatches in production

## References

- Original threat model: User request for "email environment safety audit"
- Implementation: `<repo-root>/packages/python-server-quickstart/src/spaps_server_quickstart/domains/email/service.py`
- Tests: `<repo-root>/packages/python-server-quickstart/tests/domains/email/test_env_safety.py`
- Auth flows: `<repo-root>/packages/python-server-quickstart/src/spaps_server_quickstart/domains/auth/service.py`
