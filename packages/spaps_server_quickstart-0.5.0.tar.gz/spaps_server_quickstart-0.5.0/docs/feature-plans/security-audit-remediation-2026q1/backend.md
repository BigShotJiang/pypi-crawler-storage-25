# Backend Spec: `security_audit_remediation_2026q1`

## Implementation Principles

- Python/FastAPI only (`packages/python-server-quickstart/`)
- TDD first: tests before behavior/migration changes
- No network calls in tests; external providers mocked
- Canonical validation commands:
  - `make pytest`
  - `make lint`
  - `make typecheck`
  - `make test`

## Domains In Scope

- `domains/secure_messages/` (`TM-013`)
- `domains/stripe/` (`TM-002`)
- `middleware/api_key.py` and related deps (`TM-009`)
- `domains/auth/` + `domains/sessions/` (`TM-011`)
- `middleware/rate_limiting.py` + proxy assumptions (`TM-010`)
- `domains/self_service/` (`TM-008`)
- `domains/webhooks/` (`TM-007`)
- startup/config safety checks (`TM-008`, `TM-013`)

## Workstream A: PHI/PII Fail-Closed + Participant AuthZ (`TM-013`)

### Rules

- If any request is for a `pii_enabled` application and encryption prerequisites are missing, deny.
- Secure messages require API key + JWT identity.
- Message visibility is participant-scoped (patient/practitioner/admin policy), not app-wide list by default.

### Backend Tasks

- Add startup/readiness invariant checks for encryption prerequisites.
- Add participant authorization gate in secure message service layer.
- Remove/disable plaintext fallback path when `pii_enabled=true`.
- Emit structured security logs for denied access and encryption misconfiguration.

### TDD Matrix

- Route tests:
  - API key only -> rejected
  - API key + non-participant JWT -> rejected
  - API key + participant JWT -> success
- Service tests:
  - `pii_enabled=true` + missing key -> deterministic error
  - `pii_enabled=true` + key present -> encrypted write/decrypt read path
- Readiness tests:
  - fail when misconfigured

## Workstream B: Subscription Application Scoping Completion (`TM-002`)

### Rules

- Subscription operations require local record match on `subscription_id + application_id + user_id`.
- No direct Stripe fetch/cancel/update without scoped local record.

### Backend Tasks

- Add `application_id` to subscription persistence model and repository filters.
- Backfill existing records to maintain continuity.
- Remove temporary warning path that accepted missing `application_id` enforcement.

### TDD Matrix

- Repository tests for scoped lookups.
- Service tests for same-user cross-app denial.
- Router tests for app-bound request contexts.
- Migration test/verification for backfilled rows and not-null enforcement stage.

## Workstream C: Legacy Plaintext API Key Shutdown (`TM-009`)

### Rules

- Production path must not accept plaintext legacy API keys after cutover.
- Cutover is telemetry-gated and reversible for emergency only.

### Backend Tasks

- Maintain usage telemetry until legacy callers reach zero.
- Flip default runtime policy to disable legacy fallback in production.
- Keep temporary emergency override with explicit expiry and alerting.

### TDD Matrix

- Middleware tests for accepted hashed keys.
- Middleware tests for rejected plaintext legacy keys when disabled.
- Integration tests around flag behavior by environment.

## Workstream D: Refresh Token Anomaly Persistence + Policy (`TM-011`)

### Rules

- Persist enough refresh-context metadata for anomaly detection.
- Policy mode supports alert-only and enforce-block.

### Backend Tasks

- Extend refresh token persistence model for network/user-agent context.
- Add anomaly decision service with feature-flagged enforcement.
- Add security event emission and redacted operational logging.

### TDD Matrix

- Service tests: stable context refresh succeeds.
- Service tests: changed context emits anomaly.
- Service tests: changed context rejected when enforcement enabled.
- Router tests: metadata passed through correctly.

## Workstream E: Rate Limit + Self-Service Boundary Hardening (`TM-010`, `TM-008`)

### Rules

- Rate-limit identity must be based on trusted proxy headers.
- Self-service routes restricted by production network boundary.

### Backend Tasks

- Add explicit proxy-trust documentation + startup warning if trust config is unsafe.
- Implement production-ready shared limiter backend option for multi-replica deployments.
- Add self-service network policy gate before token auth.

### TDD Matrix

- Middleware tests for header normalization assumptions.
- Self-service route tests for allowlisted and denied sources.
- Rate-limit tests with spoofed headers and shared backend mode.

## Workstream F: Webhook Destination Governance (`TM-007`)

### Rules

- Destination policy decision is explicit (allowlist and/or verification).
- Existing SSRF and DNS re-validation protections remain mandatory.

### Backend Tasks

- Add destination policy module configurable per environment/tenant policy.
- Integrate policy checks into webhook create/update path.
- Emit policy denial events with non-sensitive context.

### TDD Matrix

- Service tests for allowed/denied destination registration.
- Delivery tests for blocked re-resolution events.
- Regression tests preserving existing SSRF protections.

## Migration Plan (Conceptual Order)

1. Add schema support for subscription application scoping.
2. Backfill subscription `application_id` from existing ownership metadata.
3. Add refresh token context persistence fields and indexes needed for lookup/alerts.
4. Stage enforcement toggles behind feature flags.
5. Enforce stricter constraints after backfill and observation window.

## Feature Flags / Runtime Controls

- `LEGACY_API_KEY_AUTH_ENABLED` (existing; migration to `false` in production)
- `SECURE_MESSAGES_REQUIRE_JWT` (new; staged rollout)
- `REFRESH_ANOMALY_ENFORCEMENT_ENABLED` (new; alert-first then enforce)
- `WEBHOOK_DESTINATION_POLICY_MODE` (new; off/allowlist/verify)
- `RATE_LIMIT_BACKEND` (new or existing extension; in-memory/shared)

## Verification And Release Gates

- Code/test gates:
  - `make pytest`
  - `make lint`
  - `make typecheck`
  - `make test`
- Security gates:
  - No unresolved high-priority findings in this slice
  - Alerts/dashboards wired for deny/anomaly events
- Documentation gates:
  - Threat status updates
  - `docs/manifest.json` updates for behavior-affecting endpoints
  - `packages/python-client` parity updates where applicable
