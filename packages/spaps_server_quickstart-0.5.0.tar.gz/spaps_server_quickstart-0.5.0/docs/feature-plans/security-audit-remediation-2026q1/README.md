# Security Audit Remediation Plan (2026Q1)

This folder contains a domain-planner style remediation slice for unresolved and partial findings in:

- `<repo-root>/sweet-potato-threat-model.md` (validated 2026-02-13)

## Scope

- Active stack only: `packages/python-server-quickstart/` (FastAPI/Python)
- Explicitly out of scope: deprecated Node/Express runtime under `src/`

## Plan Artifacts

- `plan.md`: strategy, priorities, user stories, and tradeoffs
- `shared.md`: API contract changes and error contract updates
- `backend.md`: backend business rules, migration plan, and TDD matrix
- `frontend.md`: API-only impact guidance for downstream consumers
- `flows.md`: critical security and rollout flows
- `schema.mmd`: conceptual data model for migration-backed controls

## Execution Order

1. TM-013 fail-closed PHI/PII protections
2. TM-002 completion (subscription `application_id` scoping)
3. TM-009 completion (legacy plaintext API key shutdown)
4. TM-011 completion (refresh token anomaly persistence/enforcement)
5. TM-010/TM-008 infrastructure hardening (rate limits + self-service boundary)
6. TM-007 governance hardening (outbound webhook destination policy)
