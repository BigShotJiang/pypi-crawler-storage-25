# Frontend/Consumer Spec: `security_audit_remediation_2026q1`

## Phase 4 Status

SPAPS is API-only. No first-party frontend routes/components are planned in this slice.

## Consumer Surfaces Affected

- `packages/python-client` (contract client parity)
- External tenant backends integrating SPAPS APIs
- Internal operator workflows that call `/api/self-service/*`
- API docs consumers using OpenAPI/reference docs

## Consumer-Facing Behavior Changes

### Secure Messages (`TM-013`)

- Clients must provide both:
  - secret API key
  - JWT for actor identity
- Existing API-key-only integrations must migrate.
- Consumers should handle:
  - `SECURE_MESSAGES_ENCRYPTION_REQUIRED`
  - `SECURE_MESSAGES_FORBIDDEN_PARTICIPANT`

### Stripe Subscriptions (`TM-002`)

- No shape changes expected.
- Integrators may observe stricter `SUBSCRIPTION_NOT_FOUND` outcomes for cross-app requests that previously passed.

### Auth Refresh (`TM-011`)

- Refresh responses remain backward compatible by default.
- Optional anomaly metadata may be additive.
- Clients should handle `REFRESH_TOKEN_ANOMALOUS` when enforcement is enabled.

### Self-Service (`TM-008`)

- Operator scripts may need network path changes (VPN/mTLS/bastion) to reach `/api/self-service/*`.
- Clients should handle `SELF_SERVICE_NETWORK_RESTRICTED`.

### Webhooks (`TM-007`)

- Webhook registration/update may return governance policy denials depending on destination.

## Consumer Acceptance Checklist

- Python client error models include new error codes.
- Python client docs and tests include secure-messages JWT requirement.
- `docs/manifest.json` and API references reflect updated auth requirements and error codes.
- Downstream runbooks updated for:
  - legacy API key retirement timeline
  - self-service network restrictions
  - refresh anomaly policy modes
