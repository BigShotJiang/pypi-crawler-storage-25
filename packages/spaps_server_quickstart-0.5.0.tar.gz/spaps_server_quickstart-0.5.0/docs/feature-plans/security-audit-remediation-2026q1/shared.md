# Shared Contract: `security_audit_remediation_2026q1`

## Contract Status

`CONTRACT LOCKED` (planning baseline, 2026-02-13)

Changes below are contract-level behavior updates for existing endpoints unless explicitly marked as optional new admin surface.

## Response Envelope

All endpoints continue using existing envelope style:

```json
{
  "success": true,
  "data": {},
  "error": null,
  "metadata": {}
}
```

Error responses continue returning:

```json
{
  "success": false,
  "data": null,
  "error": {
    "code": "ERROR_CODE",
    "message": "Human readable message"
  },
  "metadata": {}
}
```

## Endpoint Behavior Deltas

### 1) Secure Messages (`TM-013`)

| Endpoint | Auth Contract | Behavior Contract | New/Confirmed Errors |
| --- | --- | --- | --- |
| `POST /api/secure-messages` | Secret API key + JWT required | Write allowed only when JWT subject is a valid participant for payload context and encryption prerequisites are satisfied | `SECURE_MESSAGES_ENCRYPTION_REQUIRED`, `SECURE_MESSAGES_FORBIDDEN_PARTICIPANT`, `AUTHENTICATION_REQUIRED` |
| `GET /api/secure-messages` | Secret API key + JWT required | List returns only messages visible to JWT subject participation scope | `SECURE_MESSAGES_ENCRYPTION_REQUIRED`, `SECURE_MESSAGES_FORBIDDEN_PARTICIPANT`, `AUTHENTICATION_REQUIRED` |

Notes:

- For `pii_enabled=true`, missing encryption key is fail-closed (no plaintext fallback).
- Existing request/response field shapes remain stable unless participant context requires an additive field.

### 2) Stripe Subscription Access (`TM-002`)

| Endpoint | Auth Contract | Behavior Contract | New/Confirmed Errors |
| --- | --- | --- | --- |
| `GET /api/stripe/subscription/{id}` | Existing API key + user binding | Must match local record by `subscription_id`, `application_id`, and `user_id` before Stripe API read | `SUBSCRIPTION_NOT_FOUND` |
| `POST /api/stripe/subscription/{id}/cancel` | Existing API key + user binding | Same multi-key scope check before cancel | `SUBSCRIPTION_NOT_FOUND` |
| `POST /api/stripe/subscription/{id}/update` | Existing API key + user binding | Same multi-key scope check before update | `SUBSCRIPTION_NOT_FOUND` |
| `GET /api/stripe/subscriptions` | Existing API key + user binding | List remains local DB-scoped by `application_id` and `user_id` | `NONE` (existing behavior) |

Notes:

- No fallback-to-Stripe when local scoped record is missing.

### 3) Refresh Token Rotation (`TM-011`)

| Endpoint | Auth Contract | Behavior Contract | New/Confirmed Errors |
| --- | --- | --- | --- |
| `POST /api/auth/refresh` | Existing refresh-token flow | Emits anomaly decision for IP/UA divergence; mode is alert-only or block via feature flag | `REFRESH_TOKEN_ANOMALOUS` (only when enforcement enabled) |

Notes:

- Response shape remains backward compatible in alert-only mode.
- Optional additive metadata field may expose anomaly severity for observability-safe clients.

### 4) Legacy API Key Shutdown (`TM-009`)

| Surface | Contract | New/Confirmed Errors |
| --- | --- | --- |
| API key authentication middleware | Plaintext legacy `applications.api_key` fallback disabled in production after migration window | `INVALID_API_KEY` for legacy-only callers when flag is off |

### 5) Self-Service Boundary (`TM-008`)

| Endpoint Group | Auth Contract | Behavior Contract | New/Confirmed Errors |
| --- | --- | --- | --- |
| `/api/self-service/*` | Existing self-service bearer model | Access restricted to approved network boundary in production | `SELF_SERVICE_NETWORK_RESTRICTED`, `UNAUTHORIZED` |

### 6) Webhook Destination Governance (`TM-007`)

| Endpoint | Contract | New/Confirmed Errors |
| --- | --- | --- |
| `POST /api/webhooks` and `PUT /api/webhooks/{webhook_id}` | Existing SSRF/HTTPS checks plus destination governance policy (allowlist and/or ownership verification mode) | `WEBHOOK_DESTINATION_NOT_ALLOWED`, `WEBHOOK_DESTINATION_UNVERIFIED` |

## Error Code Additions

- `SECURE_MESSAGES_ENCRYPTION_REQUIRED`
- `SECURE_MESSAGES_FORBIDDEN_PARTICIPANT`
- `REFRESH_TOKEN_ANOMALOUS` (policy-driven)
- `SELF_SERVICE_NETWORK_RESTRICTED`
- `WEBHOOK_DESTINATION_NOT_ALLOWED`
- `WEBHOOK_DESTINATION_UNVERIFIED`

## Security Event Contract

Each blocked decision above emits structured security events including:

- `threat_id` (for example `TM-013`)
- `application_id` when available
- actor identifiers (`user_id`, key prefix, source IP)
- decision (`allow`, `deny`, `alert`)
- reason code

Event payloads must omit secrets and full token/key values.

## Compatibility Rules

- Additive changes preferred; no response shape removals during this slice.
- Contract-impacting changes require synchronized updates to:
  - `docs/manifest.json`
  - API reference docs under `/docs/api-reference*`
  - `packages/python-client` contract tests/docs when shared endpoints are touched
