# Security Flows: `security_audit_remediation_2026q1`

## Flow 1: Secure Message Create/List (`TM-013`)

1. Client sends request with secret API key and JWT.
2. API key resolves `application_id`.
3. JWT resolves `user_id` and app binding.
4. Service validates participant access for requested conversation context.
5. Service validates encryption prerequisites when app has `pii_enabled=true`.
6. If checks pass, write/read encrypted message path executes.
7. If checks fail, deny with explicit error and emit security event.

Failure branches:

- Missing JWT -> `AUTHENTICATION_REQUIRED`
- Non-participant JWT -> `SECURE_MESSAGES_FORBIDDEN_PARTICIPANT`
- Missing encryption key for pii-enabled app -> `SECURE_MESSAGES_ENCRYPTION_REQUIRED`

## Flow 2: Subscription Read/Mutate (`TM-002`)

1. Request enters with app context and user context.
2. Service queries local subscription by `stripe_subscription_id + application_id + user_id`.
3. If local scoped row exists, action proceeds to Stripe API.
4. If missing or mismatched, return `SUBSCRIPTION_NOT_FOUND` without external object fetch.

## Flow 3: Refresh Token Rotation (`TM-011`)

1. Request submits refresh token.
2. Service validates token family and revocation state.
3. Service compares stored context vs current IP/UA context.
4. Policy branch:
   - alert-only: rotate tokens and emit anomaly event
   - enforce: deny with `REFRESH_TOKEN_ANOMALOUS`
5. Record rotation metadata and decision.

## Flow 4: Legacy API Key Retirement (`TM-009`)

1. Observe legacy key usage while fallback flag remains enabled.
2. Reach zero-usage target over defined observation window.
3. Disable legacy fallback in production.
4. Monitor invalid-key and error spikes.
5. Roll back temporarily only via time-bound emergency procedure.

## Flow 5: Self-Service Boundary Control (`TM-008`)

1. Request reaches `/api/self-service/*`.
2. Network boundary policy check runs first (allowlisted source).
3. If allowed, token/password auth flow proceeds.
4. If denied, return `SELF_SERVICE_NETWORK_RESTRICTED` and audit.

## Flow 6: Webhook Destination Governance (`TM-007`)

1. Client submits webhook destination at create/update time.
2. Existing URL safety checks run (scheme, SSRF, DNS/IP checks).
3. Governance policy check runs (allowlist and/or ownership verification).
4. Destination is accepted or denied with explicit reason code.
5. Delivery flow re-validates destination resolution before each send.

## Rollout Flow

```mermaid
flowchart TD
    A["Wave 1: TM-013 + TM-002"] --> B["Wave 2: TM-009 + TM-011"]
    B --> C["Wave 3: TM-010 + TM-008"]
    C --> D["Wave 4: TM-007"]
    D --> E["Re-audit against threat model IDs"]
    E --> F{"All high-priority closed?"}
    F -->|Yes| G["Mark remediation slice complete"]
    F -->|No| H["Open follow-up hardening slice"]
```
