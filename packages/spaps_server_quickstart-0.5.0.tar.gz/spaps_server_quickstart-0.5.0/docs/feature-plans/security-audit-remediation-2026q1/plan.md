# Slice: `security_audit_remediation_2026q1`

## Business Value

Reduce unresolved high-risk security findings in the active SPAPS Python runtime to a deployable, auditable baseline while preserving tenant isolation, billing integrity, and PHI/PII confidentiality.

## Scope

- Threat IDs: `TM-002`, `TM-007`, `TM-008`, `TM-009`, `TM-010`, `TM-011`, `TM-013`
- Codebase: `packages/python-server-quickstart/` only
- Includes: API contracts, backend rules, migration planning, infra handoffs, monitoring gates

## Out Of Scope

- Deprecated Node/Express runtime under `/src`
- New product features unrelated to threat remediation
- UI builds (SPAPS mode is API-only)

## Phase 0 Landscape

**Domain cluster:** `[security] [sweet-potato] [python-server]`

**Nearby slices and artifacts:**

- `<repo-root>/packages/python-server-quickstart/TM-002-IMPLEMENTATION.md` (subscription hardening, partial multi-tenant gap still open)
- `<repo-root>/packages/python-server-quickstart/docs/TM-ENV-001-*.md` (email safety controls already closed)
- `<repo-root>/sweet-potato-threat-model.md` (source of unresolved/partial tasks)

**Primary entities touched:**

- `applications`
- `subscriptions`
- `refresh_tokens`
- `secure_messages`
- `webhooks` and delivery logs
- security/audit event streams

**Dependencies and conflicts:**

- Downstream SDK/docs parity for shared endpoint behavior updates (`packages/python-client`, API docs, `docs/manifest.json`)
- Infra dependencies for network restrictions, reverse proxy header normalization, and centralized rate limiting
- Domain-planner SPAPS mode currently references Node conventions; this slice follows repo `AGENTS.md` (Python/FastAPI) as source of truth

## Phase 1 Discovery (Stories + Test Scenarios)

### Role Set

- Tenant backend integrator
- SPAPS operator (security/admin)
- Security/on-call engineer
- Compliance reviewer

### User Story 1 (`TM-013`)

As a compliance-sensitive tenant, I need secure-message writes and reads to fail closed when encryption prerequisites are missing, so PHI/PII is never stored plaintext when `pii_enabled=true`.

Acceptance criteria:

- Startup/readiness blocks production traffic if any `pii_enabled` app is active and `SPAPS_PII_MASTER_KEY` is missing.
- `/secure-messages` cannot operate in plaintext mode for `pii_enabled` applications.
- Misconfiguration returns deterministic error code and produces a high-priority security event.

Test scenarios:

- Happy path: `pii_enabled=true` with key configured -> create/list succeeds and payload decrypts correctly.
- Error path: `pii_enabled=true` and key missing -> create/list denied with `SECURE_MESSAGES_ENCRYPTION_REQUIRED`.
- Error path: readiness endpoint fails when misconfiguration exists.

### User Story 2 (`TM-013`)

As an application owner, I need participant-level authorization for secure messages (not application key alone), so compromised tenant secret keys do not expose all app messages.

Acceptance criteria:

- `/secure-messages` requires both valid API key and JWT user identity.
- Message list/read returns only rows where JWT subject participates as patient/practitioner (or explicit admin role policy).
- Cross-participant access attempts are denied and audited.

Test scenarios:

- Happy path: participant can read/write own conversation.
- Error path: user with same app key but not participant receives forbidden.
- Error path: API key only without JWT is rejected.

### User Story 3 (`TM-002`)

As a multi-tenant operator, I need subscription records scoped by `application_id`, so same-user cross-application access to Stripe subscriptions is impossible.

Acceptance criteria:

- Subscription repository/service queries enforce `application_id` and `user_id` checks.
- Missing local subscription record still fails closed.
- Existing records are backfilled before enforcement flag flips.

Test scenarios:

- Happy path: correct app + user can read/update/cancel.
- Error path: same user but different app is denied.
- Error path: subscription exists in Stripe but not local DB is denied.

### User Story 4 (`TM-009`)

As a platform operator, I need to fully retire plaintext legacy API key auth, so DB disclosure cannot yield immediately usable credentials.

Acceptance criteria:

- `LEGACY_API_KEY_AUTH_ENABLED=false` in production after migration window.
- Legacy key usage is observable and reaches zero before final cutover.
- Runbook exists for emergency rollback with explicit expiry.

Test scenarios:

- Happy path: hashed publishable/secret keys continue to authenticate.
- Error path: plaintext legacy key rejected when flag is off.
- Rollback path: temporary flag re-enable restores old behavior without code changes.

### User Story 5 (`TM-011`)

As a security engineer, I need refresh token anomaly persistence and policy enforcement, so replay behavior can be detected and optionally blocked.

Acceptance criteria:

- Refresh token records include originating/requesting network metadata needed for anomaly detection.
- Refresh flow emits structured anomaly events on suspicious IP/UA changes.
- Enforcement mode (alert-only vs block) is feature-flagged and documented.

Test scenarios:

- Happy path: same-device refresh rotates successfully.
- Alert path: changed IP/UA logs anomaly and still rotates in alert-only mode.
- Block path: changed IP/UA rejected when enforcement flag is enabled.

### User Story 6 (`TM-010`, `TM-008`)

As an operations lead, I need deterministic rate-limiting behavior behind reverse proxies and hardened self-service boundaries, so brute force and provisioning abuse are constrained.

Acceptance criteria:

- Production reverse proxy normalizes `X-Forwarded-For`; app docs and checks assert this requirement.
- Optional Redis-backed rate limiter is enabled for multi-replica production.
- `/self-service/*` is restricted to approved network boundary (VPN/mTLS/IP allowlist).

Test scenarios:

- Happy path: valid clients rate-limit consistently across replicas.
- Error path: spoofed forwarding headers do not bypass limits.
- Error path: non-allowlisted source cannot reach self-service routes.

### User Story 7 (`TM-007`)

As a platform operator, I need explicit outbound webhook destination governance, so tenant-managed webhooks cannot be abused for untrusted exfiltration patterns.

Acceptance criteria:

- Registration policy supports operator allowlist and/or endpoint ownership verification mode.
- Policy decision and blocked attempts are logged with reason code.
- Existing SSRF/DNS re-validation controls remain intact.

Test scenarios:

- Happy path: approved destination registers and receives deliveries.
- Error path: destination outside policy denied at create/update time.
- Error path: DNS rebind to blocked range denied at delivery time.

## Phase 5 Strategy (Execution)

## Priority Waves

### Wave 1 (Immediate: high-risk closure)

- `TM-013` fail-closed encryption + participant authZ
- `TM-002` application scoping migration and enforcement

Exit gate:

- No plaintext writes for `pii_enabled` apps
- Subscription cross-app access tests all passing

### Wave 2 (Credential/session hardening)

- `TM-009` legacy key shutdown plan to production off-state
- `TM-011` refresh anomaly persistence + alerting

Exit gate:

- Legacy-key usage metric at zero in production for defined observation window
- Refresh anomaly events visible in monitoring

### Wave 3 (Perimeter and operator controls)

- `TM-010` proxy/rate-limit hardening
- `TM-008` self-service network restrictions + audit trail strengthening
- Runtime cutover verification (single active auth runtime, no stale policy drift)

Exit gate:

- Documented and validated network boundary controls
- On-call dashboards include 429, auth failure, and admin action anomaly signals

### Wave 4 (Governance tightening)

- `TM-007` webhook destination governance policy

Exit gate:

- Policy mode enabled (allowlist or ownership verification)
- False-positive/false-negative review completed

## Tradeoffs

| Decision | Chosen Option | Why | Tradeoff |
| --- | --- | --- | --- |
| Secure messages auth model | Require API key + JWT participant checks | Reduces blast radius of leaked tenant secret keys | Integrator change for existing API-key-only clients |
| Encryption misconfig behavior | Fail closed | Prevents regulated-data plaintext drift | Potential availability impact on misconfigured tenants |
| Legacy API key cutoff | Progressive shutdown with telemetry gate | Safer migration for existing tenants | Longer transition period |
| Refresh anomaly policy | Alert-first, then enforce | Avoids accidental lockouts during baseline learning | Replay blocking delayed until confidence is high |
| Webhook governance | Policy mode configurable per environment | Supports current customers while tightening controls | Additional operational complexity |

## Global Definition Of Done

- All high-priority unresolved items (`TM-013`, residual `TM-002`, residual `TM-009`, residual `TM-011`) moved to closed with passing tests and deployment checklist.
- Partial infra items (`TM-010`, `TM-008`, `TM-007`) have implemented controls plus written runbooks and monitoring.
- `docs/manifest.json`, API docs, and Python client docs/tests updated for any contract-impacting behavior changes.
- Final audit rerun (`domain-reviewer` style) reports compliant status for all in-scope threat IDs.

## Handoff

- Implementation: `domain-scaffolder-backend`
- Audit/closure: `domain-reviewer`
