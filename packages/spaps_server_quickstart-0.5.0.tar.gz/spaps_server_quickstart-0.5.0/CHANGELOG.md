# Changelog

All notable changes to this project are documented in this file.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

- No changes yet.

## [0.4.0] - 2026-02-11

### Added

- Full domain rewrite covering auth, sessions, users, wallets, payments, entitlements, dayrate, agent approvals, affiliate referrals, email templates, and related operational domains.
- Approval capability gates and governance health endpoint.

### Changed

- Production cutover to Python SPAPS stack (CI/CD, Docker Compose, deploy scripts).
- Consolidated SPAPS integration patterns into published packages.

### Security

- Rate limiting by client IP.
- PII encryption startup checks.
- Webhook authentication hardening.
- Row-level locking on refresh tokens.
- Fail-closed settings defaults.

## [0.3.0] - 2026-02-08

### Added

- Contract tests and shared testing module.
- Health endpoint enhancements.

### Changed

- Expanded coverage across settings, middleware, database, Celery, and auth helpers.

## [0.2.3] - 2026-01-12

### Fixed

- `SpapsAuthMiddleware` now skips execution when `authenticated_user` is already populated.

## [0.2.2] - 2026-01-11

### Added

- `fnmatch` glob support for `spaps_auth_exempt_paths`.
- Set-password endpoint support for authenticated users.
- Stripe webhook admin tooling for entitlement workflows.
- Tier 3 templates: seeds, tests, domain examples, docs.
- Startup validation, Alembic templates, and CI/CD workflow scaffolding.

## [0.2.1] - 2025-12-01

### Added

- Shared pgvector dev scripts: `start-db.sh`, `stop-db.sh`, `await_db.py`.
- Dynamic DNS resolver support for Docker reverse-proxy setups.

### Fixed

- nginx DNS caching behavior.
- HTMA rate-limiting exemption handling.

## [0.2.0] - 2025-10-15

### Added

- Local auth bypass mode with pre-configured admin/user personas.
- Deployment check scripts (`pre-deploy`, `post-deploy`).
- Database caching workflow for local debug loops.
- Operational templates (Makefile, GHCR deploy, compose/reverse-proxy stubs).

### Security

- Production guardrails for local-auth bypass mode.

## [0.1.2] - 2025-10-15

### Fixed

- CI pipeline trigger scoping and quickstart build stability.

## [0.1.1] - 2025-10-14

### Changed

- Maintenance release to unblock automated PyPI publishing workflow.

## [0.1.0] - 2025-10-14

### Added

- FastAPI lifespan handling for SPAPS auth cleanup.
- Migration and upgrading guidance for downstream services.
- Shared refresh-cookie configuration and browser helper exports.
- Expanded package exports for auth helpers and operational templates.
- RBAC role helpers and sample domain routers.
- Comprehensive unit tests across settings, middleware, DB, Celery, and auth helpers.

## [0.0.2] - 2025-10-12

### Added

- Declared the `spaps` Python client dependency for downstream installs and CI runs.

## [0.0.1] - 2025-10-14

### Added

- Initial `spaps-server-quickstart` scaffold with shared FastAPI/Celery/database utilities.
