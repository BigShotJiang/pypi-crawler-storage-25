# TM-002 Implementation: Subscription Security Hardening

## Threat Summary
**TM-002**: If a local DB record is missing for a Stripe subscription, the service may still query Stripe directly — allowing cross-user/cross-tenant billing data exposure or unauthorized cancellation/updates.

## Solution Implemented

### Changes to `/src/spaps_server_quickstart/domains/stripe/service.py`

All subscription-related functions now **REQUIRE** a local database record before interacting with the Stripe API. This prevents:
- Cross-user billing data exposure
- Unauthorized subscription cancellation
- Unauthorized subscription modification

### Modified Functions

#### 1. `get_subscription()`
**Before**: Conditionally checked local DB only if `user_id` was provided, falling through to Stripe otherwise.

**After**:
- **ALWAYS** queries local DB first for the subscription record
- **REJECTS** request if no local record exists (404)
- Verifies `user_id` ownership if provided
- Only then queries Stripe API

**New behavior**:
```python
# TM-002: REQUIRE local DB record
local_sub = await repo.get_subscription_by_stripe_id(db, subscription_id)
if local_sub is None:
    raise SubscriptionNotFoundError("Subscription not found in local database")

# Verify ownership
if user_id is not None and local_sub.user_id != user_id:
    raise SubscriptionNotFoundError("Subscription not found")
```

#### 2. `cancel_subscription()`
**Before**: Conditionally checked local DB only if `user_id` was provided.

**After**:
- **ALWAYS** queries local DB first
- **REJECTS** if no local record exists
- Verifies `user_id` ownership if provided
- Only then calls Stripe cancellation API

#### 3. `update_subscription_plan()`
**Before**: Conditionally checked local DB only if `user_id` was provided.

**After**:
- **ALWAYS** queries local DB first
- **REJECTS** if no local record exists
- Verifies `user_id` ownership if provided
- Only then calls Stripe update API

#### 4. `list_subscriptions()`
**Already secure**: Only queries local DB, never hits Stripe directly.
- Added documentation comments referencing TM-002
- Added `application_id` parameter for future use

#### 5. `create_subscription()`
**Already secure**: Creates local record with `user_id` scoping.
- Added `application_id` parameter
- Stores `application_id` in metadata until schema update

## Test Coverage

Added comprehensive negative tests in `/tests/domains/stripe/test_service.py`:

### For each function (`get`, `cancel`, `update`):
1. ✅ **test_no_local_record_rejected**: Verifies rejection when subscription ID exists in Stripe but not in local DB
2. ✅ **test_different_user_rejected**: Verifies rejection when subscription belongs to a different user
3. ✅ Updated existing success tests to mock local DB lookups

### For `list_subscriptions`:
- ✅ **test_only_returns_user_subscriptions**: Verifies it only queries local DB with proper user scoping

### Test Results
All 38 tests in `test_service.py` pass, including 7 new TM-002 security tests.

## Known Limitations

### Missing `application_id` Column
The `subscriptions` table currently does **NOT** have an `application_id` column. This means:

**Current state**:
- ✅ User-level isolation (prevents user A from accessing user B's subscriptions)
- ❌ Application-level isolation (doesn't prevent cross-application access for same user)

**Impact**:
- Single-tenant deployments: **SECURE** (user-level isolation sufficient)
- Multi-tenant deployments: **PARTIAL RISK** (user can access their subscriptions across different applications)

**Mitigation implemented**:
- Added `application_id` parameter to all functions
- Log warning when `application_id` is provided but not enforced
- Store `application_id` in metadata for tracking
- Clear documentation in code comments

**Recommended follow-up**:
```sql
-- Add application_id column to subscriptions table
ALTER TABLE subscriptions
ADD COLUMN application_id UUID REFERENCES applications(id);

-- Add composite unique constraint
CREATE UNIQUE INDEX idx_subscriptions_app_stripe
ON subscriptions(application_id, stripe_subscription_id);
```

## Security Guarantees (Post-Implementation)

### ✅ Protected Against:
1. **Direct Stripe ID manipulation**: Attacker cannot access subscriptions by guessing Stripe IDs
2. **Cross-user access**: User A cannot access User B's subscriptions
3. **Missing local records**: System rejects operations on subscriptions not in local DB
4. **Unauthorized cancellation**: Cannot cancel another user's subscription
5. **Unauthorized updates**: Cannot modify another user's subscription plan

### ⚠️ Partial Protection:
1. **Cross-application access** (same user): Currently not enforced due to missing schema support
   - Logged for audit purposes
   - Stored in metadata for future migration

## API Impact

### Breaking Changes: None
All functions maintain backward compatibility. The `application_id` parameter is optional.

### Recommended Usage
```python
# GET subscription
await get_subscription(
    db,
    subscription_id="sub_123",
    user_id=user.id,           # Required for security
    application_id=app.id       # Recommended but not enforced yet
)

# CANCEL subscription
await cancel_subscription(
    db,
    subscription_id="sub_123",
    user_id=user.id,           # Required for security
    application_id=app.id,     # Recommended but not enforced yet
    immediately=False
)

# UPDATE subscription
await update_subscription_plan(
    db,
    subscription_id="sub_123",
    price_id="price_456",
    user_id=user.id,           # Required for security
    application_id=app.id      # Recommended but not enforced yet
)
```

## Audit Trail

All functions now log warnings when `application_id` is provided but not enforced:
```python
logger.warning(
    "TM-002: application_id scoping requested but not yet implemented",
    extra={"subscription_id": sub_id, "application_id": app_id}
)
```

This creates an audit trail for future schema migration.

## Next Steps

1. **Schema Migration** (High Priority):
   - Add `application_id` column to `subscriptions` table
   - Update repository layer to filter by `application_id`
   - Remove warning logs once enforced

2. **Integration Testing**:
   - Test with real Stripe sandbox environment
   - Verify webhook handling preserves security

3. **API Gateway/Routes**:
   - Ensure all route handlers pass `user_id` to service layer
   - Add `application_id` from JWT claims to service calls

4. **Documentation**:
   - Update API documentation with security recommendations
   - Document multi-tenant isolation limitations

## References
- Threat Model Item: TM-002
- Modified Files:
  - `/src/spaps_server_quickstart/domains/stripe/service.py`
  - `/tests/domains/stripe/test_service.py`
- Related Security Items:
  - TM-003: Checkout session ownership (already implemented)
  - TM-005: Product/Price ownership (already implemented)
