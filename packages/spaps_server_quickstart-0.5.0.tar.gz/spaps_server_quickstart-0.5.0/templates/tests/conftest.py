"""
Test configuration and fixtures - Generated from spaps-server-quickstart

This conftest provides battle-tested patterns for:
- Testcontainers integration with pgvector
- Template database cloning for parallel pytest-xdist workers
- App role with limited permissions for RLS testing
- Auto-dispose async engine after each test (event loop safety)
- Database truncation between tests with seed data restoration

Replace {{SERVICE_NAME}}, {{APP_NAME}}, and customize TRUNCATE_TABLES_SQL
for your service.
"""

from __future__ import annotations

import asyncio
import os
import tempfile
import time
import warnings
import xml.etree.ElementTree as ET
from collections.abc import AsyncIterator, Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace

import pytest
import pytest_asyncio
from filelock import FileLock, Timeout
from sqlalchemy import create_engine
from sqlalchemy import text as sa_text
from sqlalchemy.engine import URL, make_url

try:
    from alembic import command
    from alembic.config import Config
except ImportError:
    command = None
    Config = None

from httpx import ASGITransport, AsyncClient

try:
    from testcontainers.core.container import DockerContainer
    from testcontainers.core.wait_strategies import (
        CompositeWaitStrategy,
        LogMessageWaitStrategy,
        PortWaitStrategy,
    )
except ImportError:
    DockerContainer = None
    CompositeWaitStrategy = None
    LogMessageWaitStrategy = None
    PortWaitStrategy = None

try:
    import docker
    from docker.errors import DockerException
except ImportError:
    docker = None

    class DockerException(Exception):
        pass


# Import your app factory and settings - customize these imports
# from {{SERVICE_NAME}}.app import create_app
# from {{SERVICE_NAME}}.core.settings import Settings, get_settings
# from {{SERVICE_NAME}}.db.session import dispose_engine, get_db_session, get_session_factory

PROJECT_ROOT = Path(__file__).resolve().parents[1]
ALEMBIC_INI = PROJECT_ROOT / "alembic.ini"

# Use pgvector-enabled image so extension creation works in CI/local testcontainers
POSTGRES_IMAGE = "ankane/pgvector:latest"
SHARED_POSTGRES_URL_ENV = "PYTEST_SHARED_POSTGRES_URL"
TEMPLATE_DB_NAME = "{{DB_NAME}}_template"
WORKER_DB_PREFIX = "{{DB_NAME}}_test"
APP_DB_USER = "{{DB_NAME}}_app"
APP_DB_PASSWORD = "{{DB_NAME}}_app"
DEFAULT_LOCAL_APP_DSN = (
    f"postgresql+asyncpg://{APP_DB_USER}:{APP_DB_PASSWORD}@localhost:5433/{{DB_NAME}}"
)
DEFAULT_LOCAL_APP_SYNC_DSN = (
    f"postgresql+psycopg://{APP_DB_USER}:{APP_DB_PASSWORD}@localhost:5433/{{DB_NAME}}"
)
DEFAULT_LOCAL_ADMIN_SYNC_DSN = "postgresql+psycopg://postgres:postgres@localhost:5433/{{DB_NAME}}"
LOCK_DIR = Path(tempfile.gettempdir()) / "{{SERVICE_NAME}}-pytest"
TEMPLATE_LOCK_FILE = LOCK_DIR / "template-db.lock"
COVERAGE_XML = PROJECT_ROOT / "coverage.xml"
COVERAGE_REQUIRED = 0.80

# Customize this SQL for your schema's required seed data
_TRUNCATE_TABLES_SQL = """
DO $$
DECLARE
    rec record;
BEGIN
    FOR rec IN (
        SELECT tablename
        FROM pg_tables
        WHERE schemaname = 'public'
          AND tablename <> 'alembic_version'
    ) LOOP
        EXECUTE format('TRUNCATE TABLE %I RESTART IDENTITY CASCADE', rec.tablename);
    END LOOP;
END $$;
"""

# Add your seed SQL for lookup tables here
_SEED_DATA_SQL = """
-- INSERT INTO status_types (code, description) VALUES ...
"""


def _docker_available() -> bool:
    if docker is None:
        return False
    try:
        client = docker.from_env()
        client.ping()
    except DockerException:
        return False
    else:
        client.close()
        return True


DOCKER_AVAILABLE = _docker_available()
TESTCONTAINERS_AVAILABLE = DockerContainer is not None


def _async_database_url(sync_url: str) -> str:
    parsed = make_url(sync_url)
    base_driver = _base_driver_name(parsed)
    async_driver = None
    if base_driver.startswith("postgresql"):
        async_driver = "asyncpg"
    elif base_driver.startswith("sqlite"):
        async_driver = "aiosqlite"
    if async_driver is None:
        return sync_url
    drivername = f"{base_driver}+{async_driver}"
    return parsed.set(drivername=drivername).render_as_string(hide_password=False)


def _sync_database_url(url: str) -> str:
    parsed = make_url(url)
    base_driver = _base_driver_name(parsed)
    sync_driver = base_driver
    if base_driver.startswith("postgresql"):
        sync_driver = f"{base_driver}+psycopg"
    elif base_driver.startswith("sqlite"):
        sync_driver = f"{base_driver}+pysqlite"
    return parsed.set(drivername=sync_driver).render_as_string(hide_password=False)


@contextmanager
def _temporary_env(overrides: dict[str, str]) -> Iterator[None]:
    if not overrides:
        yield
        return

    previous_values = {key: os.environ.get(key) for key in overrides}
    for key, value in overrides.items():
        os.environ[key] = value
    get_settings.cache_clear()
    try:
        yield
    finally:
        get_settings.cache_clear()
        for key, prior in previous_values.items():
            if prior is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = prior


def _base_driver_name(url: URL) -> str:
    return url.drivername.split("+", 1)[0]


def _build_database_url(
    shared_url: str,
    database: str,
    driver_suffix: str,
    *,
    username: str | None = None,
    password: str | None = None,
) -> str:
    parsed = make_url(shared_url)
    base_driver = _base_driver_name(parsed)
    updated = parsed.set(drivername=f"{base_driver}+{driver_suffix}", database=database)
    if username is not None:
        updated = updated.set(username=username)
    if password is not None:
        updated = updated.set(password=password)
    return updated.render_as_string(hide_password=False)


@dataclass(slots=True)
class DatabaseURLs:
    app_async_url: str
    app_sync_url: str
    admin_sync_url: str


def _has_distinct_admin_connection(database_urls: DatabaseURLs) -> bool:
    """True when an admin connection is available that differs from the app user."""
    return database_urls.admin_sync_url != database_urls.app_sync_url


MIGRATIONS_APPLIED = False
WORKER_DATABASE_CLONED = False
_SHARED_POSTGRES_CONTAINER = None


warnings.filterwarnings(
    "ignore",
    message=r".*@wait_container_is_ready decorator is deprecated.*",
    category=DeprecationWarning,
)


if DockerContainer is not None:

    class ManagedPostgresContainer(DockerContainer):
        def __init__(self, image: str = POSTGRES_IMAGE) -> None:
            super().__init__(image)
            self.username = "postgres"
            self.password = "postgres"
            self.database = "postgres"
            self.port = 5432

            self.with_env("POSTGRES_USER", self.username)
            self.with_env("POSTGRES_PASSWORD", self.password)
            self.with_env("POSTGRES_DB", self.database)
            self.with_env("POSTGRES_HOST_AUTH_METHOD", "trust")
            self.with_exposed_ports(str(self.port))

            wait_strategy = CompositeWaitStrategy(
                PortWaitStrategy(self.port),
                LogMessageWaitStrategy("database system is ready to accept connections"),
            ).with_startup_timeout(60)
            self.waiting_for(wait_strategy)

        def get_connection_url(self) -> str:
            host = self.get_container_host_ip()
            port = self.get_exposed_port(self.port)
            return f"postgresql://{self.username}:{self.password}@{host}:{port}/{self.database}"

else:

    class ManagedPostgresContainer:
        def __init__(self, *args, **kwargs) -> None:
            raise RuntimeError("testcontainers is not installed")

        def start(self) -> None:
            raise RuntimeError("testcontainers is not installed")

        def stop(self) -> None:
            raise RuntimeError("testcontainers is not installed")

        def get_connection_url(self) -> str:
            raise RuntimeError("testcontainers is not installed")


def _ensure_shared_container_started() -> None:
    global _SHARED_POSTGRES_CONTAINER
    if os.getenv("PYTEST_DATABASE_URL"):
        return
    if _SHARED_POSTGRES_CONTAINER is not None:
        return
    if os.environ.get(SHARED_POSTGRES_URL_ENV):
        return
    if not DOCKER_AVAILABLE or not TESTCONTAINERS_AVAILABLE:
        return
    container = ManagedPostgresContainer(POSTGRES_IMAGE)
    container.start()
    _SHARED_POSTGRES_CONTAINER = container
    os.environ[SHARED_POSTGRES_URL_ENV] = container.get_connection_url()


def pytest_configure(config: pytest.Config) -> None:
    if hasattr(config, "workerinput"):
        worker_id = config.workerinput.get("workerid")
        if worker_id:
            os.environ.setdefault("PYTEST_XDIST_WORKER", worker_id)
        shared_url = config.workerinput.get("shared_postgres_url")
        if shared_url:
            os.environ[SHARED_POSTGRES_URL_ENV] = shared_url
        return
    _ensure_shared_container_started()


def pytest_configure_node(node) -> None:
    _ensure_shared_container_started()
    shared_url = os.environ.get(SHARED_POSTGRES_URL_ENV)
    if shared_url:
        node.workerinput["shared_postgres_url"] = shared_url
    worker_id = getattr(node, "workerid", None)
    if worker_id is not None:
        node.workerinput["workerid"] = worker_id


def pytest_unconfigure(config: pytest.Config) -> None:
    if hasattr(config, "workerinput"):
        return
    global _SHARED_POSTGRES_CONTAINER
    container = _SHARED_POSTGRES_CONTAINER
    if container is not None:
        container.stop()
        _SHARED_POSTGRES_CONTAINER = None
        os.environ.pop(SHARED_POSTGRES_URL_ENV, None)


def pytest_sessionfinish(session: pytest.Session, exitstatus: int) -> None:
    _maybe_warn_on_coverage_gap(session)


def _worker_identifier() -> str:
    return os.getenv("PYTEST_XDIST_WORKER", "local")


def _worker_database_name() -> str:
    suffix = "".join(ch if ch.isalnum() else "_" for ch in _worker_identifier().lower())
    if not suffix:
        suffix = "local"
    return f"{WORKER_DB_PREFIX}_{suffix[:40]}"


def _drop_database(admin_sync_url: str, database: str) -> None:
    engine = create_engine(admin_sync_url, isolation_level="AUTOCOMMIT")
    try:
        with engine.connect() as connection:
            connection.execute(
                sa_text(
                    "SELECT pg_terminate_backend(pid) "
                    "FROM pg_stat_activity "
                    "WHERE datname = :db_name AND pid <> pg_backend_pid()"
                ),
                {"db_name": database},
            )
            connection.execute(sa_text(f'DROP DATABASE IF EXISTS "{database}"'))
    finally:
        engine.dispose()


def _create_database(admin_sync_url: str, database: str, template: str | None = None) -> None:
    engine = create_engine(admin_sync_url, isolation_level="AUTOCOMMIT")
    try:
        with engine.connect() as connection:
            if template:
                connection.execute(
                    sa_text(f'CREATE DATABASE "{database}" WITH TEMPLATE "{template}"'),
                )
            else:
                connection.execute(sa_text(f'CREATE DATABASE "{database}"'))
    finally:
        engine.dispose()


def _ensure_app_role_and_grants(admin_sync_url: str, database: str) -> None:
    """Ensure the application role exists and has privileges on the target database."""
    sanitized_password = APP_DB_PASSWORD.replace("'", "''")
    admin_engine = create_engine(admin_sync_url, isolation_level="AUTOCOMMIT")
    try:
        with admin_engine.connect() as connection:
            connection.execute(
                sa_text(
                    f"""
                    DO $$
                    BEGIN
                        IF NOT EXISTS (
                            SELECT FROM pg_roles WHERE rolname = '{APP_DB_USER}'
                        ) THEN
                            CREATE ROLE {APP_DB_USER}
                                LOGIN
                                PASSWORD '{sanitized_password}'
                                NOSUPERUSER;
                        END IF;
                    END
                    $$;
                    """
                )
            )
            connection.execute(
                sa_text(f'GRANT CONNECT ON DATABASE "{database}" TO {APP_DB_USER}')
            )
    finally:
        admin_engine.dispose()

    target_admin_url = (
        make_url(admin_sync_url).set(database=database).render_as_string(hide_password=False)
    )
    target_engine = create_engine(target_admin_url, isolation_level="AUTOCOMMIT")
    try:
        with target_engine.connect() as connection:
            connection.execute(sa_text(f"GRANT USAGE ON SCHEMA public TO {APP_DB_USER}"))
            connection.execute(
                sa_text(
                    f"GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO {APP_DB_USER}"
                )
            )
            connection.execute(
                sa_text(
                    f"GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO {APP_DB_USER}"
                )
            )
            connection.execute(
                sa_text(
                    f"ALTER DEFAULT PRIVILEGES FOR ROLE CURRENT_USER IN SCHEMA public "
                    f"GRANT ALL PRIVILEGES ON TABLES TO {APP_DB_USER}"
                )
            )
            connection.execute(
                sa_text(
                    f"ALTER DEFAULT PRIVILEGES FOR ROLE CURRENT_USER IN SCHEMA public "
                    f"GRANT ALL PRIVILEGES ON SEQUENCES TO {APP_DB_USER}"
                )
            )
    finally:
        target_engine.dispose()


def _maybe_warn_on_coverage_gap(session: pytest.Session) -> None:
    if not COVERAGE_XML.exists():
        return
    try:
        tree = ET.parse(COVERAGE_XML)
    except ET.ParseError:
        return
    root = tree.getroot()
    try:
        line_rate = float(root.attrib.get("line-rate", "0"))
    except (TypeError, ValueError):
        return
    if line_rate < COVERAGE_REQUIRED:
        writer = session.config.get_terminal_writer()
        message = (
            f"Coverage {line_rate * 100:.2f}% is below the required "
            f"{COVERAGE_REQUIRED * 100:.0f}%. Add tests before re-running."
        )
        writer.line()
        writer.write(f"==== {message}\n", cyan=True)
        writer.line()


@pytest.fixture(scope="session")
def database_urls() -> DatabaseURLs:
    app_override = os.getenv("PYTEST_DATABASE_URL")
    admin_override = os.getenv("PYTEST_DATABASE_ADMIN_URL")
    if app_override:
        app_async_url = app_override
        app_sync_url = _sync_database_url(app_override)
        admin_source = admin_override or app_override
        admin_sync_url = _sync_database_url(admin_source)
        return DatabaseURLs(
            app_async_url=app_async_url,
            app_sync_url=app_sync_url,
            admin_sync_url=admin_sync_url,
        )

    shared_url = os.getenv(SHARED_POSTGRES_URL_ENV)
    if shared_url:
        worker_db = _worker_database_name()
        # Template database setup would go here
        global WORKER_DATABASE_CLONED
        WORKER_DATABASE_CLONED = True
        app_async_url = _build_database_url(
            shared_url,
            worker_db,
            "asyncpg",
            username=APP_DB_USER,
            password=APP_DB_PASSWORD,
        )
        app_sync_url = _build_database_url(
            shared_url,
            worker_db,
            "psycopg",
            username=APP_DB_USER,
            password=APP_DB_PASSWORD,
        )
        admin_sync_url = _build_database_url(shared_url, worker_db, "psycopg")
        return DatabaseURLs(
            app_async_url=app_async_url,
            app_sync_url=app_sync_url,
            admin_sync_url=admin_sync_url,
        )

    return DatabaseURLs(
        app_async_url=DEFAULT_LOCAL_APP_DSN,
        app_sync_url=DEFAULT_LOCAL_APP_SYNC_DSN,
        admin_sync_url=DEFAULT_LOCAL_ADMIN_SYNC_DSN,
    )


@pytest.fixture(scope="session")
def database_url(database_urls: DatabaseURLs) -> str:
    return database_urls.app_async_url


@pytest.fixture(scope="session", autouse=True)
def configure_settings(database_urls: DatabaseURLs) -> AsyncIterator[None]:
    get_settings.cache_clear()
    env_overrides = {
        "DATABASE_URL": database_urls.app_async_url,
        "ENV": "test",
        "LOG_LEVEL": "INFO",
        "APP_NAME": "{{APP_NAME}} Test Server",
    }

    previous_values: dict[str, str | None] = {}
    for key, value in env_overrides.items():
        previous_values[key] = os.environ.get(key)
        os.environ[key] = value
    asyncio.run(dispose_engine())

    yield
    get_settings.cache_clear()
    for key, prior in previous_values.items():
        if prior is None:
            os.environ.pop(key, None)
        else:
            os.environ[key] = prior
    asyncio.run(dispose_engine())


@pytest.fixture(scope="session")
def settings(configure_settings: None) -> Settings:
    return get_settings()


@pytest_asyncio.fixture(autouse=True)
async def dispose_async_engine() -> AsyncIterator[None]:
    """
    Dispose the async engine after each test to prevent event loop mismatch.

    pytest-asyncio closes the event loop after each test, but SQLAlchemy's
    connection pool retains connections from the previous loop. This fixture
    ensures the engine is disposed and recreated with fresh event loop bindings.
    """
    yield
    await dispose_engine()


@pytest_asyncio.fixture(autouse=True)
async def reset_database_state(settings: Settings) -> AsyncIterator[None]:
    if not MIGRATIONS_APPLIED:
        yield
        return

    sync_url = _sync_database_url(settings.database_url)
    engine = create_engine(sync_url)
    try:
        with engine.begin() as connection:
            connection.execute(sa_text(_TRUNCATE_TABLES_SQL))
            connection.execute(sa_text(_SEED_DATA_SQL))
    finally:
        engine.dispose()
    yield


@pytest_asyncio.fixture
async def db_session() -> AsyncIterator:
    """Application session using app role (RLS enforced if configured)."""
    session_factory = get_session_factory()
    async with session_factory() as session:
        yield session
        await session.rollback()


@pytest_asyncio.fixture
async def admin_session(database_urls: DatabaseURLs) -> AsyncIterator:
    """Admin session using postgres superuser for test fixture setup (bypasses RLS)."""
    from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
    from sqlalchemy.orm import sessionmaker

    admin_async_url = _async_database_url(database_urls.admin_sync_url)
    engine = create_async_engine(admin_async_url, echo=False)
    async_session_maker = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

    async with async_session_maker() as session:
        yield session
        await session.rollback()

    await engine.dispose()


@pytest.fixture(scope="session", autouse=True)
def configure_celery_eager_mode():
    """Configure Celery to run tasks synchronously in tests."""
    try:
        from {{SERVICE_NAME}}.celery_app import celery_app

        celery_app.conf.update(
            task_always_eager=True,
            task_eager_propagates=True,
        )
    except ImportError:
        pass
    yield


@pytest_asyncio.fixture
async def async_client(settings: Settings) -> AsyncIterator[AsyncClient]:
    app = create_app()

    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://testserver") as client:
        client.app = app
        yield client
