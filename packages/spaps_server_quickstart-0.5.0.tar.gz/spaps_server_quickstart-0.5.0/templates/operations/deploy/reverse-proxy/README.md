This directory mirrors the shared reverse-proxy stack used in production. Copy it into `/opt/sweet-potato/deploy/reverse-proxy` (or equivalent) and customise `nginx.conf` / `sites-available/*` for your domains. Certbot tooling or `deploy/renew-certs.sh` can manage certificates.

When adding upstreams, include `resolver 127.0.0.11 ipv6=off valid=30s;` and mark each `server` entry with the `resolve`
flag so nginx re-resolves Docker service names after a container restart. The deployment scripts will attempt a
`docker exec shared-reverse-proxy nginx -s reload` after each rollout; if the shared proxy container is unavailable
they fall back to the legacy `./up.sh` helper.
