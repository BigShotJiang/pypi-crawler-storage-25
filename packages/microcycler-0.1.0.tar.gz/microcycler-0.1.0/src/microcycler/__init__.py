"""
Microcycler Python SDK
======================

Python SDK for the Microcycler battery testing platform.

Basic usage::

    import asyncio
    from microcycler import Cycler

    async def main():
        async with Cycler("192.168.1.100") as cycler:
            telemetry = await cycler.get_telemetry()
            print(f"Voltage: {telemetry.voltage:.3f} V")
            print(f"Current: {telemetry.current:.3f} A")

    asyncio.run(main())

Recipe usage::

    from microcycler import Cycler
    from microcycler.recipes import Recipe, CC, CV, Rest, Loop

    recipe = (
        Recipe()
        .add(CC(current=1.0, cutoff_voltage=4.2))
        .add(CV(voltage=4.2, cutoff_current=0.05))
        .add(Rest(duration=300))
        .add(Loop(cycles=100))
    )

    async with Cycler("192.168.1.100") as cycler:
        await cycler.load_recipe(recipe)
        await cycler.start()
"""

from .client import Cycler
from .types import CyclerTelemetry, CyclerHealth, CyclerLimits, CyclerState

__version__ = "0.1.0"
__all__ = [
    "Cycler",
    "CyclerTelemetry",
    "CyclerHealth",
    "CyclerLimits",
    "CyclerState",
]
