"""
TCP client for communicating with a Microcycler device.

The cycler exposes a SCPI-like command interface over TCP (port 5025) and
broadcasts UDP telemetry packets for discovery and streaming (port 5026).
"""

from __future__ import annotations

import asyncio
import json
from types import TracebackType
from typing import Optional, Type

from .recipes import Recipe
from .types import CyclerHealth, CyclerTelemetry

_TCP_PORT = 5025
_CONNECT_TIMEOUT = 5.0
_COMMAND_TIMEOUT = 10.0


class CyclerError(Exception):
    """Raised when the cycler returns an error response."""


class Cycler:
    """
    Async TCP client for a single Microcycler unit.

    Usage as an async context manager is recommended::

        async with Cycler("192.168.1.100") as cycler:
            telemetry = await cycler.get_telemetry()

    You may also manage the connection manually::

        cycler = Cycler("192.168.1.100")
        await cycler.connect()
        try:
            await cycler.start()
        finally:
            await cycler.disconnect()
    """

    def __init__(
        self,
        host: str,
        port: int = _TCP_PORT,
        connect_timeout: float = _CONNECT_TIMEOUT,
        command_timeout: float = _COMMAND_TIMEOUT,
    ) -> None:
        self.host = host
        self.port = port
        self._connect_timeout = connect_timeout
        self._command_timeout = command_timeout
        self._reader: Optional[asyncio.StreamReader] = None
        self._writer: Optional[asyncio.StreamWriter] = None
        self._lock = asyncio.Lock()

    # ------------------------------------------------------------------
    # Connection management
    # ------------------------------------------------------------------

    async def connect(self) -> None:
        """Open the TCP connection to the cycler."""
        self._reader, self._writer = await asyncio.wait_for(
            asyncio.open_connection(self.host, self.port),
            timeout=self._connect_timeout,
        )

    async def disconnect(self) -> None:
        """Close the TCP connection."""
        if self._writer is not None:
            self._writer.close()
            try:
                await self._writer.wait_closed()
            except Exception:
                pass
            self._writer = None
            self._reader = None

    async def __aenter__(self) -> "Cycler":
        await self.connect()
        return self

    async def __aexit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_val: Optional[BaseException],
        exc_tb: Optional[TracebackType],
    ) -> None:
        await self.disconnect()

    # ------------------------------------------------------------------
    # Low-level transport
    # ------------------------------------------------------------------

    async def _send(self, command: str) -> str:
        """Send a SCPI command and return the response line."""
        if self._writer is None or self._reader is None:
            raise CyclerError("Not connected. Call connect() or use as async context manager.")

        async with self._lock:
            self._writer.write((command.strip() + "\n").encode())
            await self._writer.drain()
            response = await asyncio.wait_for(
                self._reader.readline(),
                timeout=self._command_timeout,
            )
            line = response.decode().strip()
            if line.startswith("ERR"):
                raise CyclerError(line)
            return line

    async def _query_json(self, command: str) -> dict:
        raw = await self._send(command)
        return json.loads(raw)

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    async def get_telemetry(self) -> CyclerTelemetry:
        """Return the current cell telemetry snapshot."""
        data = await self._query_json("MEAS:TEL?")
        return CyclerTelemetry.from_dict(data)

    async def get_health(self) -> CyclerHealth:
        """Return the cycler hardware health snapshot."""
        data = await self._query_json("MEAS:HEALTH?")
        return CyclerHealth.from_dict(data)

    async def identify(self) -> str:
        """Return the cycler identification string (*IDN?)."""
        return await self._send("*IDN?")

    # ------------------------------------------------------------------
    # Control
    # ------------------------------------------------------------------

    async def load_recipe(self, recipe: Recipe) -> None:
        """Upload a recipe to the cycler's RAM."""
        payload = json.dumps(recipe.to_dict())
        await self._send(f"REC:LOAD {payload}")

    async def start(self) -> None:
        """Start the loaded recipe."""
        await self._send("REC:START")

    async def pause(self) -> None:
        """Pause the running recipe."""
        await self._send("REC:PAUSE")

    async def resume(self) -> None:
        """Resume a paused recipe."""
        await self._send("REC:RESUME")

    async def stop(self) -> None:
        """Abort the running recipe and return to IDLE."""
        await self._send("REC:STOP")

    async def set_output(self, *, voltage: float, current: float) -> None:
        """
        Raw output override (host must remain connected).
        Intended for direct/manual control outside of a recipe.
        """
        await self._send(f"OUT:VOLT {voltage:.4f};OUT:CURR {current:.4f}")

    async def set_limits(
        self,
        *,
        voltage_upper: float,
        voltage_lower: float,
        current_upper: float,
        temperature_upper: float,
    ) -> None:
        """Update the safety limits on the cycler."""
        payload = json.dumps(
            {
                "voltage_upper": voltage_upper,
                "voltage_lower": voltage_lower,
                "current_upper": current_upper,
                "temperature_upper": temperature_upper,
            }
        )
        await self._send(f"LIM:SET {payload}")
