"""
Recipe DSL for building cycler test sequences.

A Recipe is an ordered list of steps. Steps are serialized to JSON and
uploaded to the cycler via the TCP client (REC:LOAD command).

Example::

    from microcycler.recipes import Recipe, CC, CV, Rest, Loop

    recipe = (
        Recipe(name="Formation C/10")
        .add(CC(current=0.1, cutoff_voltage=4.2, cutoff_time=36000))
        .add(CV(voltage=4.2, cutoff_current=0.02))
        .add(Rest(duration=1800))
        .add(CC(current=-0.1, cutoff_voltage=2.8))  # discharge
        .add(Rest(duration=1800))
        .add(Loop(cycles=3))
    )
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, List, Optional


# ------------------------------------------------------------------
# Step base
# ------------------------------------------------------------------


@dataclass
class _Step:
    def to_dict(self) -> dict:
        d = asdict(self)
        d["type"] = self.__class__.__name__.upper()
        return {k: v for k, v in d.items() if v is not None}


# ------------------------------------------------------------------
# Concrete step types
# ------------------------------------------------------------------


@dataclass
class CC(_Step):
    """Constant-current step."""
    current: float
    cutoff_voltage: Optional[float] = None
    cutoff_time: Optional[float] = None   # seconds
    cutoff_capacity: Optional[float] = None  # mAh


@dataclass
class CV(_Step):
    """Constant-voltage step."""
    voltage: float
    cutoff_current: Optional[float] = None
    cutoff_time: Optional[float] = None


@dataclass
class CP(_Step):
    """Constant-power step."""
    power: float                          # watts; positive = charge
    cutoff_voltage: Optional[float] = None
    cutoff_time: Optional[float] = None


@dataclass
class CR(_Step):
    """Constant-resistance step."""
    resistance: float                     # ohms
    cutoff_voltage: Optional[float] = None
    cutoff_time: Optional[float] = None


@dataclass
class Rest(_Step):
    """Open-circuit rest step."""
    duration: float                       # seconds
    cutoff_voltage: Optional[float] = None


@dataclass
class Loop(_Step):
    """Repeat all preceding steps N times."""
    cycles: int


@dataclass
class EIS(_Step):
    """Electrochemical Impedance Spectroscopy sweep."""
    freq_start: float = 100_000.0         # Hz
    freq_end: float = 0.01                # Hz
    amplitude: float = 0.01              # A (perturbation amplitude)
    points_per_decade: int = 10


# ------------------------------------------------------------------
# Recipe container
# ------------------------------------------------------------------


class Recipe:
    """
    An ordered sequence of cycler steps.

    Methods are chainable::

        recipe = Recipe().add(CC(...)).add(CV(...)).add(Rest(...))
    """

    def __init__(self, name: str = "Untitled Recipe") -> None:
        self.name = name
        self._steps: List[_Step] = []

    def add(self, step: _Step) -> "Recipe":
        self._steps.append(step)
        return self

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "steps": [s.to_dict() for s in self._steps],
        }

    def __repr__(self) -> str:
        return f"Recipe(name={self.name!r}, steps={len(self._steps)})"
