"""
Async UDP telemetry streaming.

The cycler broadcasts telemetry as UDP JSON packets on port 5026.
Use CyclerStream to consume these packets as an async iterator, or
use discover() to find cyclers on the local network.
"""

from __future__ import annotations

import asyncio
import json
import socket
from typing import AsyncIterator, List

from .types import CyclerTelemetry

_UDP_PORT = 5026
_BROADCAST_ADDR = "255.255.255.255"
_DISCOVERY_TIMEOUT = 3.0
_MAX_PACKET = 4096


class _UDPProtocol(asyncio.DatagramProtocol):
    def __init__(self, queue: asyncio.Queue) -> None:
        self._queue = queue

    def datagram_received(self, data: bytes, addr: tuple) -> None:
        self._queue.put_nowait((data, addr))

    def error_received(self, exc: Exception) -> None:
        pass


class CyclerStream:
    """
    Async iterator that yields CyclerTelemetry from UDP broadcast packets.

    Usage::

        async for telemetry in CyclerStream():
            print(telemetry.voltage, telemetry.current)
    """

    def __init__(self, host: str = "", port: int = _UDP_PORT) -> None:
        self._host = host
        self._port = port
        self._transport: asyncio.BaseTransport | None = None
        self._queue: asyncio.Queue = asyncio.Queue()

    async def __aenter__(self) -> "CyclerStream":
        loop = asyncio.get_running_loop()
        self._transport, _ = await loop.create_datagram_endpoint(
            lambda: _UDPProtocol(self._queue),
            local_addr=(self._host, self._port),
            allow_broadcast=True,
        )
        return self

    async def __aexit__(self, *_) -> None:
        if self._transport:
            self._transport.close()

    def __aiter__(self) -> AsyncIterator[CyclerTelemetry]:
        return self

    async def __anext__(self) -> CyclerTelemetry:
        data, _ = await self._queue.get()
        return CyclerTelemetry.from_dict(json.loads(data))


async def discover(
    timeout: float = _DISCOVERY_TIMEOUT,
    port: int = _UDP_PORT,
) -> List[str]:
    """
    Send a broadcast discovery ping and collect responding cycler IPs.

    Returns a list of IP address strings.

    Usage::

        hosts = await discover()
        # ['192.168.1.100', '192.168.1.101']
    """
    found: dict[str, bool] = {}
    queue: asyncio.Queue = asyncio.Queue()

    loop = asyncio.get_running_loop()

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    sock.setblocking(False)

    transport, _ = await loop.create_datagram_endpoint(
        lambda: _UDPProtocol(queue),
        sock=sock,
    )

    try:
        transport.sendto(b"DISC?\n", (_BROADCAST_ADDR, port))
        deadline = loop.time() + timeout
        while True:
            remaining = deadline - loop.time()
            if remaining <= 0:
                break
            try:
                _, addr = await asyncio.wait_for(queue.get(), timeout=remaining)
                found[addr[0]] = True
            except asyncio.TimeoutError:
                break
    finally:
        transport.close()

    return list(found.keys())
