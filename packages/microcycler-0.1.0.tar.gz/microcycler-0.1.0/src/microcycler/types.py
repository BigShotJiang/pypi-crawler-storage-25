"""
Shared data types mirroring the dashboard's TypeScript definitions in
dashboard/app/lib/types.ts.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Tuple


class CyclerState(str, Enum):
    IDLE = "IDLE"
    CHARGING = "CHARGING"
    DISCHARGING = "DISCHARGING"
    REST = "REST"
    COMPLETE = "COMPLETE"
    ERROR = "ERROR"


@dataclass
class CyclerLimits:
    voltage_upper: float
    voltage_lower: float
    current_upper: float
    temperature_upper: float


@dataclass
class CyclerTelemetry:
    device_id: str
    firmware: str
    hardware: str
    state: CyclerState
    voltage: float
    current: float
    temperature: float
    step: int
    cycle: int
    elapsed: float
    capacity_mah: float
    energy_mwh: float
    limits: CyclerLimits

    @classmethod
    def from_dict(cls, data: dict) -> "CyclerTelemetry":
        limits = CyclerLimits(**data.pop("limits"))
        return cls(**data, limits=limits)


@dataclass
class CyclerHealth:
    device_id: str
    board_temp: float
    cpu_load_core1: float
    cpu_load_core2: float
    heatsink_temps: Tuple[float, float, float, float]
    main_current_draw: float
    fan_current_draw: float
    die_temp: float

    @classmethod
    def from_dict(cls, data: dict) -> "CyclerHealth":
        data["heatsink_temps"] = tuple(data["heatsink_temps"])
        return cls(**data)
