# upvertex-models

Namespace reservation for UpVertex Inc. (www.upvertex.com)