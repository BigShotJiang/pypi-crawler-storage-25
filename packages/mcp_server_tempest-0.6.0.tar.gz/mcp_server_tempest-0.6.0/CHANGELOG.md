# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.6.0] - 2026-05-09

### Added

- Structured truncation fields on `ForecastResponse`: `truncated`,
  `requested_hours`, `requested_days`, `returned_hours`, `returned_days`,
  `truncation_hint`. Agents detect clipping without parsing prose; honest
  under both summary-cap and upstream-shortfall paths.
- Each tool docstring lists its structured `code` values, with per-tool
  subsets matching the call paths in `rest.py` (`get_stations` correctly
  excludes `station_not_found`).
- `SERVER SURFACE: mcp-server-tempest@<version>` line in the
  `instructions` block — a lightweight capability fingerprint per §9 of
  the agent-friendliness checklist. Read from package metadata at import
  time so it stays in sync with `pyproject.toml`.

### Changed

- Server `name` tightened from `"WeatherFlow Tempest API Server"` to
  `"WeatherFlow Tempest"` (drops the generic suffix).
- All published tool `outputSchema` definitions set
  `additionalProperties: false` recursively. Runtime ingest models stay
  permissive (`extra="ignore"`), so upstream WeatherFlow additions are
  silently dropped on parse rather than raising. Strict-mode clients
  should treat this as a tightening of the already-stable contract.
- Compressed agent-facing context for token efficiency: `instructions`
  block (NOTES, AMBIENT STATE, SERVER SURFACE), `get_stations` /
  `get_station_details` / `get_forecast` docstrings, and `hours` /
  `days` / `detailed` field descriptions. All required content
  (env-var names, cache path, transport, fingerprint format, error
  codes) preserved.
- Auth-code remediations in tool docstrings split per code
  (`auth_missing` / `auth_invalid` / `auth_forbidden`) instead of one
  inaccurate shared hint. `internal_error` bullets carry the actual
  issues URL.

## [0.5.0] - 2026-05-03

### Breaking

- All tool errors now return a structured JSON payload as the `ToolError`
  message (i.e. in `content[0].text` on the wire). The payload is a flat
  top-level object with stable fields:
  - `code` (string enum): one of `auth_missing`, `auth_invalid`,
    `auth_forbidden`, `station_not_found`, `rate_limited`,
    `upstream_unavailable`, `upstream_invalid_response`, `internal_error`.
  - `message` (string): human-readable summary; may change between versions.
  - `temporary` (bool): `true` for `rate_limited` and `upstream_unavailable`.
  - `request_id` (string): 16-hex-char per-call correlation id.
  - Optional: `hint`, `field`, `value`, `next` (e.g. `{"tool": "get_stations"}`),
    `retry_after_ms`, `details`.

  Clients parsing the previous prose `"Request failed: ..."` form must update
  to `JSON.parse(error.text)`. Clients MUST treat unknown top-level keys and
  unknown `code` values as opaque to remain forward-compatible.
- Removed the `mask_error_details=True` server config option (was a no-op
  because every tool already wrapped exceptions into a `FastMCPError`
  subclass, which the framework's masking explicitly skips).

### Added

- Distinct credential failure modes: `auth_missing` (env var unset),
  `auth_invalid` (upstream 401), `auth_forbidden` (upstream 403). Previously
  collapsed into one prose message.
- `request_id` is logged with every error and echoed in `internal_error`'s
  `hint` so users can correlate failures with server logs.

### Changed

- Server `instructions` now declares the ambient-state surface (cache env
  vars, disk cache path) and names the transport (stdio). Adds AMBIENT
  STATE, SETUP, and TRANSPORT sections; the previous trailing "Setup:"
  line is replaced by the new SETUP section. Closes audit F4 and F7.
- README: documented `WEATHERFLOW_DISK_CACHE_TTL` and the disk cache
  directory; added Caching & data freshness and Transport subsections.

## [0.4.0] - 2026-05-02

### Breaking

- Renamed tool `get_station_id` to `get_station_details`. Update any client
  code or prompts that called the old name.
- Removed `use_cache` parameter from `get_stations`, `get_station_details`,
  `get_observation`, and `get_forecast`. Caching follows
  `WEATHERFLOW_CACHE_TTL` only.
- Removed `clear_cache` tool. Restart the server or wait for the TTL to
  evict entries.
- Removed `weather://tempest/...` resources. Use the equivalent tools
  (`get_stations`, `get_station_details`, `get_observation`,
  `get_forecast`).

### Changed

- Rewrote the server `instructions` block and per-tool descriptions for
  clearer agent discovery and tool selection. Behavior is unchanged.

## [0.3.1] - 2026-03-28

### Added

- Station cache pre-warming: on startup, the server loads station data from
  disk cache into the in-memory TTL cache, eliminating cold-start latency for
  the first tool call.
- `detailed` parameter on `get_forecast` and `get_observation` tools
  (default: `false`). Summary mode returns condensed responses to reduce LLM
  context usage; detailed mode returns the full response.
- `hours` and `days` parameters on `get_forecast` to control forecast depth
  (defaults: 12 hourly, 5 daily). In summary mode, these are capped at 6 and
  2 respectively.
- Typed `output_schema` on all tools via `_relaxed_schema()`, which generates
  JSON schemas from Pydantic models with only excluded fields marked optional.
  Clients see full field names, types, and descriptions while filtered
  responses pass FastMCP output validation.

### Changed

- Tools now return filtered dicts (via `model_dump(exclude=...)`) instead of
  full Pydantic model instances. Low-value fields are excluded to reduce
  response size:
  - **All tools**: icon identifiers (`icon`, `precip_icon`)
  - **Station tools**: internal IDs (`station_item_id`, `location_id`,
    `location_item_id`), share flags (`share_with_wf`, `share_with_wu`),
    capability metadata (`device_id`, `agl`, `show_precip_final`), timestamps
    (`created_epoch`, `last_modified_epoch`)
  - **Observation tools**: `outdoor_keys` always excluded; summary mode also
    drops derived fields (`heat_index`, `wind_chill`, `wet_bulb_temperature`,
    `delta_t`, `air_density`, `brightness`, and others)
  - **Forecast tools**: summary mode drops `latitude`, `longitude`,
    `timezone_offset_minutes`
- Resource functions remain unchanged (return full Pydantic models).
- Tool docstrings shortened for conciseness.
- `use_cache` parameter now has a Python-level default value on all tools.

## [0.3.0] - 2026-03-28

### Added

- Persistent disk cache for station metadata using JSON files, surviving server
  restarts. Station lookups now use a 3-tier strategy: in-memory TTL cache, disk
  cache (24h default TTL), then API. Forecasts and observations remain
  in-memory only.
- Disk cache is scoped per API token (via SHA-256 hash) to isolate data between
  accounts.
- `WEATHERFLOW_DISK_CACHE_TTL` environment variable to configure disk cache TTL
  (default: 86400 seconds / 24 hours).
- `platformdirs` dependency for OS-appropriate cache directory resolution.
- `AIR` and `SKY` variants to the `DeviceType` enum, matching the full set of
  WeatherFlow device types.
- Disk cache key sanitization to prevent path traversal.
- Validation for `WEATHERFLOW_CACHE_TTL` and `WEATHERFLOW_CACHE_SIZE` environment
  variables with warning and fallback to defaults on invalid values.
- Tests for disk cache, disk cache integration, exception passthrough, env var
  validation, and empty API response handling.

### Changed

- `clear_cache` tool now clears both in-memory and disk caches.
- `_get_api_token` is now synchronous (was unnecessarily async).
- Tools now re-raise `ToolError` directly instead of re-wrapping it, preserving
  the original error message.
- Exception chaining (`from e`) added throughout for better tracebacks.
- Disk cache serialization uses `model_dump(mode="json")` for safe handling of
  non-JSON-native types.
- Type annotations modernized to use `list[]` and `X | None` syntax (Python
  3.13+).

### Fixed

- `api_get_station_id` no longer crashes with `IndexError` on empty API
  responses; raises `ValueError` with a descriptive message instead.
- Module docstring referenced incorrect entry point (`python -m weatherflow_mcp`).

## [0.2.0] - 2026-03-28

### Added

- `__version__` attribute via `importlib.metadata`.
- Tool tags, progress reporting, lifespan hook, and health check endpoint
  using FastMCP 3.x features.
- `mask_error_details` and `on_duplicate="error"` server configuration.
- Dev dependencies: pytest, pytest-asyncio, pytest-cov, ruff.
- 61 tests across models, REST client, and server.
- GitHub Actions CI workflow (lint + test).
- Claude Code GitHub Actions workflows.

### Changed

- Upgraded `fastmcp` from 2.x to 3.1+.
- Fixed `idempotentHint` on read-only tools (was `False`, now `True`).
- Fixed resource return types and docstring errors.

### Fixed

- `TTLCache` `TypeError` when cache environment variables are set as strings
  (#1).
- README placeholder URL (`yourusername` -> `briandconnelly`).
- Removed unused imports and non-existent resource URI from instructions.

## [0.1.0] - 2025-07-22

### Added

- Initial release.
- MCP server for WeatherFlow Tempest weather station data.
- Tools: `get_stations`, `get_station_id`, `get_forecast`, `get_observation`,
  `clear_cache`.
- Resources for stations, forecasts, and observations.
- In-memory TTL cache with configurable size and TTL.
- Pydantic models for all API responses.
- Tool annotations and resource URIs.
- README and LICENSE.
