# Getting Started with cybervisor

This guide takes you from installation to your first autonomous pipeline run in five minutes.

---

## 1. Install cybervisor

You need Python 3.11+ and `uv`:

```bash
uv tool install cybervisor
cybervisor --version
```

If you prefer a local editable install for development:

```bash
uv tool install -e . --force
cybervisor --version
```

---

## 2. Choose Your Agent

Set the default agent tool. Options are `claude`, `gemini`, `codex`, or `mock`:

```bash
cybervisor use claude
```

For CI or local testing without API keys, use `mock`:

```bash
cybervisor use mock
```

---

## 3. Configure Verifier Credentials (Non-Mock)

Mock mode needs no credentials. For real agents, create `~/.cybervisor/config.yaml`:

```bash
mkdir -p ~/.cybervisor
cat > ~/.cybervisor/config.yaml <<'EOF'
agent_tool: claude
llm:
  api_key: your-api-key
  # Optional:
  # base_url: https://api.openai.com/v1
  # model: gpt-4o
EOF
chmod 600 ~/.cybervisor/config.yaml
```

Verify connectivity:

```bash
cybervisor doctor
```

---

## 4. Initialize a Project

Inside your project repository:

```bash
cybervisor init
```

`cybervisor init` detects your environment:

- If `.specify/` exists, it installs the **speckit** scaffold (integrated with speckit workflows).
- Otherwise, it installs the **simple** scaffold (standalone artifacts in `.cybervisor/artifacts/`).

Both create a `cybervisor.yaml` with the full pipeline configuration.

---

## 5. Run Your First Pipeline

Pass a prompt describing what you want built:

```bash
cybervisor "Create a 360 feedback system"
```

Or pipe from stdin:

```bash
printf "Create a 360 feedback system" | cybervisor run
```

Watch the pipeline execute stage by stage. Output streams to stderr; full logs are written to `.cybervisor/logs/`.

---

## 6. Inspect Results

After the run finishes:

```bash
# Structured JSONL logs
cat .cybervisor/logs/cybervisor.log.jsonl

# Per-stage transcripts
ls .cybervisor/logs/stages/

# Contract artifacts (if any stage emitted routing decisions)
ls .cybervisor/contracts/artifacts/
```

---

## 7. Resume or Cancel

If you interrupt a run with Ctrl-C, cybervisor cleans up settings and skills automatically. To resume from a specific stage later:

```bash
cybervisor run "Create a 360 feedback system" --start-stage "Implement"
```

To stop after a specific stage:

```bash
cybervisor run "Create a 360 feedback system" --end-after "Review Code"
```

---

## Next Steps

- Learn the full config surface: [Configuration Reference](configuration.md)
- Design custom pipelines with contracts: [Pipeline Authoring Guide](pipeline-authoring.md)
- Run in daemon mode for headless/remote execution: [Runtime Behavior](runtime-and-daemon.md) and [WebSocket Protocol](websocket-protocol.md)
- Troubleshoot common issues: [Troubleshooting](troubleshooting.md)
