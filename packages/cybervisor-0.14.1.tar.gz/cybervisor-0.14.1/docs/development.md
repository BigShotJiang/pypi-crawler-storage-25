# Development

If you are contributing to `cybervisor`:

User-facing workflow or specification changes should be documented in tracked files under `docs/` and, when relevant, the README. Do not leave those changes only in local working directories such as `specs/` or `.cybervisor/artifacts/`, because they are not part of the committed project history.

```bash
uv sync
uv run mypy --strict src
uv run pytest
```

For self-hosted E2E or verify-stage smoke tests, do not run from the repository root when the goal is to simulate a generated project. Create an isolated demo workspace first, typically with:

```bash
./scripts/e2e-demo-simple-project.sh
```

For a fast smoke test that exercises the full pipeline through `Verify` using a minimal feature prompt and mock LLM API:

```bash
./scripts/e2e-verify-smoke.sh
./scripts/e2e-verify-smoke.sh --agent claude   # use Claude Code adapter instead of mock
```

Both modes route all LLM calls (hook verifier and stage-agent) through the bundled mock API server, so no real API keys are needed.

Release helper:

```bash
./scripts/publish.sh patch  # or minor, major
```

The script requires a clean git working tree, bumps the package version, refreshes `uv.lock`, builds and publishes the package, then creates a release commit and annotated git tag like `v0.7.1`.

## Repository Layout

```text
src/cybervisor/        Core CLI package (split into focused subpackages)
  cli/                 CLI entry point (commands, parser, instance, docs)
  client/              Daemon WebSocket client (commands, connection, rendering)
  pipeline/            Pipeline execution (runner, artifacts, contract)
  server/              Daemon WebSocket server (daemon, handlers, tasks, cleanup)
  core_hooks/          Hook runtime (contracts, streaming, verifier, runner)
  adapters/            Agent adapter registry and tool-specific adapters
  config.py              YAML config loading (PipelineConfig, stage contracts)
  cli.py, client.py,   Thin backward-compatible re-exports
  pipeline.py, server.py
  hooks.py             Hook installer and runtime config
  agent_hook.py        Packaged cybervisor-agent-hook entry point
  preflight.py         Dependency pre-check
  signals.py           Signal handler
  logging.py           Structured logging
  init.py              Scaffold installer (`cybervisor init`)
  doctor.py            Verifier readiness check (`cybervisor doctor`)
  global_config.py     ~/.cybervisor/config.yaml loader
  skills.py            Project-local skill disable/restore
  upgrade.py           Background version-check
assets/hooks/          Hook prompt assets and fixtures
scripts/               Demo and utility scripts
templates/demo/        Demo project scaffold
tests/                 Unit and integration coverage
.specify/              Constitution and repo-specific scripts
AGENTS.md              Symlink to constitution
GEMINI.md              Symlink to AGENTS.md
CLAUDE.md              Symlink to AGENTS.md
.cybervisor/           Runtime state (instance.lock, daemon.lock, hooks/, logs/)
```
