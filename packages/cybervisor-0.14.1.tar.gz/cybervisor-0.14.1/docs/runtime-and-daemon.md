# Runtime and Daemon

For `gemini` and `claude` runs, `cybervisor` performs the following lifecycle:

1. Performs preflight checks.
2. Restores any skills left in `.cybervisor/backups/skills/` from a previous unclean shutdown (see [Skill Disable/Restore](#skill-disablerestore) below).
3. Moves skills listed in `disabled_skills` from the project-local skills directory to `.cybervisor/backups/skills/<adapter>/`.
4. Writes shared hook runtime metadata into `.cybervisor/hooks/`.
5. Persists an exact settings snapshot in `.cybervisor/hooks/`.
6. Patches the active tool settings file so the selected agent invokes the packaged `cybervisor-agent-hook` entry point.
7. Starts the agent in a dedicated process group when supported. For Claude and Gemini adapters, the prompt is written to the agent subprocess's stdin rather than passed as a CLI argument (avoiding shell argument length limits). For Codex, the prompt is delivered through the app-server JSON-RPC protocol, which requires continuous stdin access.
8. Uses the runtime hook to classify autonomy decisions as `approve` or `block`, then adapts those into the selected tool's native hook output so the agent continues autonomously.
9. If the active stage declares a contract, uses the same hook runtime to block completion until the required artifact exists and is structurally valid.
10. Streams agent output into stderr and the stage log file.
11. Re-validates contract artifacts after agent exit, then routes by contract status or explicit `next_stage` when configured.
12. Restores moved skills from `.cybervisor/backups/skills/` to their original project-local directories.
13. Restores settings and removes runtime files on success, failure, or interrupt.

**Adapter compatibility notes:**
- **Gemini**: Prompt delivery via stdin is best-effort. If the Gemini CLI does not consume stdin, the prompt may be silently lost. There is no `--prompt` CLI fallback. If you encounter empty prompt behavior with Gemini, verify that the version of Gemini CLI you are running supports reading from stdin in `--output-format stream-json` mode with `--yolo`.
- **Codex**: The Codex app-server transport requires continuous stdin access for JSON-RPC messages. The Codex adapter does not use the stdin-prompt-write path and instead communicates through the app-server protocol.

## Daemon Mode

`cybervisor serve` starts a long-running WebSocket daemon that accepts pipeline runs over a WebSocket connection. The daemon is primarily controlled via the [WebSocket Protocol](websocket-protocol.md).

### Instance Lock

The daemon acquires an exclusive lock via `.cybervisor/daemon.lock` at startup. The lock file is created with `0o600` permissions (owner read/write only) and stores the PID, working directory, start time, and version. If the lock is held by a live process in the same directory, a new `cybervisor serve` invocation exits with an error. Stale locks (crashed processes) are detected and automatically replaced.

### Run-Daemon Coordination

When `cybervisor run` is invoked (both bare-prompt and explicit `run` subcommand), it checks whether the daemon is reachable before acquiring the local `.cybervisor/instance.lock`. If the daemon is reachable and has any active task (status: `"running"`), `run` exits `1` with a message showing the running task ID and stage, directing the user to `attach` or `cancel`. This prevents `run` instances from executing concurrently with daemon-submitted tasks in the same directory. When the daemon is unreachable, `run` falls back to the standard `.cybervisor/instance.lock` mechanism.

**CWD normalization:** Task matching uses `os.path.realpath()` to resolve symlinks and normalize paths. This means `/workspace`, `/workspace/`, and symlinked paths to the same directory all resolve to the same canonical path, ensuring nested task detection is not bypassed by symlinks or trailing slashes.

### Client Disconnect Behavior

When a WebSocket client disconnects mid-task, the daemon continues executing the pipeline. The task remains in the registry and all events continue to be buffered in the per-task ring buffer.

### Reconnect and Resume

A disconnected client can reconnect and send a `resume` message with the original `task_id`. The daemon replies with an `event_replay` of all buffered history and, if the task is still running, re-registers the socket as the live event target. Reconnect is gated by the `reconnect_ttl_seconds` setting — after that window closes, the task is cleaned up as abandoned.

### Background Daemonization

`cybervisor serve --background` uses double-fork to fully detach from the terminal, redirects stdin/stdout/stderr to `/dev/null`, and releases the controlling terminal. The daemon runs until it receives `SIGINT` or `SIGTERM`, or until the process is otherwise terminated.

### WebSocket Keepalive

The daemon sends WebSocket pings every 30 seconds and expects a pong within 10 seconds. The client can also send `ping` messages at any time and receive `pong` responses.

### Abandoned Task Cleanup

A background task runs a cleanup loop every `reconnect_ttl_seconds / 2` seconds. Tasks with no activity for longer than the TTL are removed from the registry and logged as abandoned. **Running tasks whose subprocess is still alive are never removed** — the cleanup only targets tasks that are already completed or cancelled, regardless of how long they have been idle. Running tasks whose subprocess has exited (e.g., the process crashed) are detected and marked as cancelled with reason `subprocess_dead`, then cleaned up on the next cycle. This ensures that long-running pipeline stages are never prematurely lost from the registry while orphaned tasks are recovered automatically.

`last_activity` is updated both on WebSocket events (client connect, disconnect, reconnect) and on every pipeline stage event (`stage_start`, `stage_complete`, `stage_retry`, `stage_failed`, `artifact_validated`, `routing_decision`). This means long-running stages (which may execute for 5+ minutes) do not trigger abandoned cleanup — the activity timestamp refreshes each time the stage emits an event, keeping the task alive until it completes or genuinely stalls.

## Generated Artifacts

- `.cybervisor/logs/cybervisor.log.jsonl`: structured run log
- `.cybervisor/logs/stages/<stage_name>.jsonl`: captured transcript per stage
- `.cybervisor/backups/<stage_name>/<timestamp>/`: versioned backups of stage artifacts after successful completion; each timestamped directory preserves one run's artifacts; never wiped by `reset_run_artifacts()`
- `.cybervisor/contracts/artifacts/*.yaml`: optional stage-result artifacts for contract-enabled stages; before each stage execution, all top-level files in this directory (except the current stage's own artifact) are removed so agents are not confused by stale artifacts from prior stages — nested subdirectories are preserved
- generated contract guidance is derived from each stage's `contract.routes` and contract field definitions in `cybervisor.yaml`

## Client Interaction

The daemon is controlled by client subcommands over the WebSocket connection:

- **`cybervisor status`** — sends a `ping` message; exits `0` if the daemon is reachable, `1` otherwise. When the daemon is reachable, it also reads the extended `pong` response containing active task snapshots (protocol v2) and prints running task IDs and stages. Tasks with status `"completed"` or `"cancelled"` are excluded from the display. For tasks registered but not yet started (active_stage is `null`), the output renders `"initializing"`. Example output when a task is active: `Running task: {task_id} (stage: {stage})`; when no tasks are active: `No active tasks.`; when the daemon is down: `Daemon not reachable at ws://{host}:{port}`. This command is strictly read-only — it never creates or modifies any task.
- **`cybervisor submit`** — sends a `run` message; streams all pipeline events and returns the pipeline exit code on `run_complete`. Accepts a positional prompt argument or reads the task description from stdin when no argument is given (e.g., `printf "task" | cybervisor submit`). If both a positional argument and piped stdin are present, the positional argument takes precedence. Empty or whitespace-only stdin with no positional argument produces a non-zero exit with the message "No prompt provided via argument or stdin."
- **`cybervisor attach`** — sends a `resume` message; when `task_id` is omitted, pings the daemon to find running tasks in the current directory and auto-resolves to the sole one (errors with "No active task to attach to." if zero tasks; errors with "Multiple tasks are running in this directory." if more than one); replays buffered events (handling chunked payloads automatically), then subscribes to live events until the task reaches a terminal state.
- **`cybervisor cancel`** — sends a `cancel` message; when `task_id` is omitted, the daemon uses the client-provided `cwd` to find and cancel the running task in the current directory (same disambiguation rules as `attach`); the daemon responds with `pipeline_abort` followed by `run_complete` on the canceler's own connection. The client exits `0` on `pipeline_abort`, `1` on error.
- **`cybervisor logs`** — sends a `resume` message; drains all buffered events and outputs each as a JSON line to stdout.
- **`cybervisor stop-stage`** — sends a `set_stop_stage` message; when `task_id` is omitted, the daemon uses the client-provided `cwd` to find the running task in the current directory (same disambiguation rules as `attach` and `cancel`); exits `0` immediately upon receiving `stop_stage_updated` (the daemon does not send `run_complete` after this event).

All client commands accept `--host` and `--port` to override the daemon address. Defaults come from `~/.cybervisor/config.yaml` (`server.host`, `server.port`). The connection timeout is 5 seconds; commands exit `1` with a "daemon not reachable" message on timeout or connection failure.

The full protocol is documented in [WebSocket Protocol](websocket-protocol.md).

## Skill Disable/Restore

When `disabled_skills` is configured in `cybervisor.yaml`, the pipeline temporarily moves the named project-local skills to a backup directory before the agent starts and restores them after the pipeline finishes.

**Lifecycle:**
1. At pipeline start, `restore_all_skills()` runs first to recover from any previous unclean shutdown (e.g., SIGKILL). It iterates all adapter directories under `.cybervisor/backups/skills/` and moves their contents back to the corresponding project-local directories (`.claude/skills/`, `.gemini/skills/`, `.agents/skills/`).
2. `move_disabled_skills()` then moves each listed skill from the project-local directory to `.cybervisor/backups/skills/<adapter>/`.
3. After the pipeline finishes (success, failure, or interrupt), `restore_skills()` moves all disabled skills back to their original locations.
4. Empty backup directories are cleaned up automatically.

**Adapter directory mapping:**

| Adapter | Project-local skills directory | Backup directory |
|---------|-------------------------------|-----------------|
| `claude` | `.claude/skills/` | `.cybervisor/backups/skills/claude/` |
| `gemini` | `.gemini/skills/` | `.cybervisor/backups/skills/gemini/` |
| `codex` | `.agents/skills/` | `.cybervisor/backups/skills/codex/` |

Global skills directories (`~/.claude/skills/`, etc.) are never modified.

**Validation:** Entries in `disabled_skills` must not contain `/` or `\` and must not be `.` or `..`. Invalid entries raise `ValueError` at config load time. Entries must match exact skill directory names, not skill set names.

See [Configuration Reference](configuration.md) for the `disabled_skills` field syntax and the default scaffold contents.

## Signals And Cleanup

- `cybervisor` exits with status code `130` on `SIGINT` or `SIGTERM`; cleanup (settings restoration, hook removal) runs before exit and is capped at 5 seconds — if cleanup exceeds the timeout, a hard exit occurs
- Non-mock runs restore the exact pre-run `.gemini/settings.json` or `.claude/settings.json` content during cleanup
- Hook runtime metadata under `.cybervisor/hooks/` is non-secret; verifier credentials remain in `~/.cybervisor/config.yaml`
