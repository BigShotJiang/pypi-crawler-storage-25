# Troubleshooting cybervisor

## Installation and Setup

### `cybervisor: command not found`

`uv` did not install the tool onto your PATH, or your shell has not reloaded.

```bash
# Confirm uv's tool bin directory is on PATH
echo $PATH | grep -q "\.local/bin" || echo 'Add export PATH="$HOME/.local/bin:$PATH" to your shell profile'

# Reinstall and verify
uv tool install cybervisor
cybervisor --version
```

---

## Verifier and Credentials

### `Doctor: verifier blocked`

`~/.cybervisor/config.yaml` is missing or the `llm.api_key` field is absent.

```bash
mkdir -p ~/.cybervisor
cat > ~/.cybervisor/config.yaml <<'EOF'
agent_tool: claude
llm:
  api_key: sk-your-key-here
EOF
chmod 600 ~/.cybervisor/config.yaml
```

### `Doctor: verifier needs attention`

The API key is present but the remote endpoint rejected it (401 Unauthorized).

- Check that `llm.api_key` is valid and has not expired.
- If using a custom `base_url`, confirm the endpoint is reachable: `curl -I "$BASE_URL/models" -H "Authorization: Bearer $API_KEY"`.

---

## Pipeline Execution

### `A task is already running in this directory`

Another pipeline is active in the same working directory.

**Option A — Attach to the running task:**

```bash
cybervisor attach
```

**Option B — Cancel it:**

```bash
cybervisor cancel
```

**Option C — If you are sure nothing is running, remove stale locks:**

```bash
rm .cybervisor/instance.lock
```

If the daemon is running, also check:

```bash
cybervisor status
```

### Agent exits immediately with no output

- Confirm the selected agent is installed: `claude --version`, `gemini --version`, or `codex --version`.
- Check preflight output at the top of the run for missing prerequisites.
- For Gemini specifically, verify stdin consumption works in your CLI version; some versions require the prompt to be passed differently.

### Hook verifier returns `block` on every invocation

The verifier LLM is rejecting the hook decisions. Common causes:

- The verifier model is too restrictive. Try a different model in `~/.cybervisor/config.yaml`.
- The stage contract artifact is malformed. Inspect the artifact under `.cybervisor/contracts/artifacts/` and compare it to the expected schema.
- The hook verifier endpoint is unreachable. Check `cybervisor doctor`.

For testing with deterministic approvals, use the mock LLM API:

```bash
python3 scripts/.e2e_mock_llm_api.py --hook-mode allow &
# Then point llm.base_url at the printed URL
```

---

## Daemon Mode

### `Daemon not reachable at ws://127.0.0.1:8765`

The daemon is not running, or it is bound to a different host/port.

```bash
# Check if the daemon process exists
ps aux | grep "cybervisor serve"

# Start it explicitly
cybervisor serve

# Or with custom binding
cybervisor serve --host 0.0.0.0 --port 9000
```

When using custom ports, pass `--host` and `--port` to every client command:

```bash
cybervisor status --host 127.0.0.1 --port 9000
```

### `nested_task_rejected` when submitting

You submitted a new task from a directory that already has a running daemon task. Submit from a different directory, or cancel the existing task first.

---

## Skills and Settings

### Skills were not restored after a crash

If cybervisor was killed with SIGKILL or the machine powered off, the restore step may not have run.

```bash
# Automatic recovery happens at the start of the next run, but you can force it:
python3 -c "from cybervisor.skills import restore_all_skills; restore_all_skills()"
```

Check `.cybervisor/backups/skills/` for orphaned skill directories and move them back to `.claude/skills/`, `.gemini/skills/`, or `.agents/skills/` manually if needed.

### Settings snapshot was not restored

If `.gemini/settings.json` or `.claude/settings.json` still contains cybervisor hook entries after a crash:

1. Look in `.cybervisor/hooks/` for the snapshot file (e.g., `settings_snapshot.json`).
2. Manually restore it to the tool's settings path, or remove the cybervisor hook entry.

---

## Configuration Validation

### `cybervisor validate` fails with route errors

Common issues:

- A contract stage defines a top-level `next_stage` — contract stages must use `contract.routes` only.
- An `injections` field is not declared in `contract.fields`.
- A route key does not match any `Status` value guidance in the prompt template.

Run with `--show-guidance` to preview the exact instructions generated for the agent:

```bash
cybervisor validate --show-guidance
```

---

## Still stuck?

Open an issue at https://github.com/crzidea/cybervisor/issues with:

- `cybervisor --version`
- The output of `cybervisor doctor`
- The relevant stage log from `.cybervisor/logs/stages/`
- The contents of `cybervisor.yaml` (redact any sensitive prompts)
