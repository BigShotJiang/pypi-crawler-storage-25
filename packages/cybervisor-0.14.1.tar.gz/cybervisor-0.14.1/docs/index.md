# cybervisor Documentation

This directory contains all user-facing and contributor-facing documentation for `cybervisor`.

## New Users — Start Here

1. Read the [project README](../README.md) for a high-level overview, installation, and quick start.
2. Follow the [Getting Started](getting-started.md) tutorial for a guided first run.
3. If something goes wrong, check [Troubleshooting](troubleshooting.md).

## Architecture Overview

For the repository layout and package structure, see [Development](development.md). For component-specific runtime details:

- CLI commands, hook lifecycle, signals, and skill management: [Runtime and Daemon](runtime-and-daemon.md)
- Daemon WebSocket protocol and message schema: [WebSocket Protocol](websocket-protocol.md)
- Pipeline stages, contracts, and routing design: [Pipeline Authoring Guide](pipeline-authoring.md)
- Demo environments and Docker sandbox: [Testing and Sandbox](testing-and-sandbox.md)

## User Guides

| Document | What it covers |
|----------|---------------|
| [Getting Started](getting-started.md) | Step-by-step tutorial from install to first pipeline run |
| [Configuration Reference](configuration.md) | `cybervisor.yaml`, `~/.cybervisor/config.yaml`, stage fields, CLI commands |
| [Pipeline Authoring Guide](pipeline-authoring.md) | Designing stages, contracts, routing, and agent prompts |
| [Updating](updating.md) | Install, upgrade, and release workflows |
| [Troubleshooting](troubleshooting.md) | Common issues and resolutions |

## Operator Guides

| Document | What it covers |
|----------|---------------|
| [Runtime and Daemon](runtime-and-daemon.md) | Hook lifecycle, daemon mode, skill disable/restore, signals, logs |
| [WebSocket Protocol](websocket-protocol.md) | Daemon message schema, connection lifecycle, chunking |
| [Testing and Sandbox](testing-and-sandbox.md) | Smoke tests, mock API, Docker sandbox serve |

## Contributor Guides

| Document | What it covers |
|----------|---------------|
| [Development](development.md) | Repository layout, local setup, tests, and release workflow |
| [Adding an Adapter](contributing/adding-an-adapter.md) | Maintainer contract for new coding-agent adapters |
