# Updating `cybervisor`

Use the update path that matches how `cybervisor` was installed.

## Automatic Background Upgrades

When you run `cybervisor run`, `cybervisor serve`, or `cybervisor serve-sandbox`, cybervisor automatically checks PyPI for a newer version in a background thread. If a newer version is found, it logs an info-level notice suggesting the manual upgrade command. No pip subprocess is spawned — the upgrade takes effect on the **next** run.

Example log output when an upgrade is available:
```
Newer version available: X.Y.Z (current: A.B.C). Run `uv tool upgrade cybervisor` or `pip install --upgrade cybervisor` to update.
```

Key behavior:
- The check runs entirely in a daemon thread and never blocks the main process. Network timeouts (10 seconds) are swallowed silently.
- The hook runner (`cybervisor-agent-hook`) never triggers an upgrade check, so hook invocations are never delayed.
- For `serve-sandbox`, the upgrade check runs on the host before the Docker container starts; the container inherits the installed version.
- The current version is printed to stderr at startup for `run`, `serve`, and `serve-sandbox`.
- To upgrade, run `uv tool upgrade cybervisor` (or `pip install --upgrade cybervisor`).

## Update A Released Install

If you installed `cybervisor` from PyPI with `uv tool install cybervisor`, upgrade it in place:

```bash
uv tool upgrade cybervisor
cybervisor --version
```

This keeps your existing global configuration in `~/.cybervisor/config.yaml`.

If `cybervisor` is not installed yet, use:

```bash
uv tool install cybervisor
```

## Update An Editable Local Install

If you installed from a local checkout for development, reinstall the tool from the repo root so the executable points at the current source tree:

```bash
uv tool install -e . --force
cybervisor --version
```

Then refresh the project environment if dependencies changed:

```bash
uv sync
```

## Update The Repo During Development

If you are contributing to `cybervisor`, update your checkout and then run the standard verification commands:

```bash
uv sync
uv run mypy --strict src/
uv run pytest
```

## Publish A New `cybervisor` Release

If you are preparing a new package release, use the repo helper from the repository root:

```bash
./scripts/publish.sh patch
```

Replace `patch` with `minor` or `major` when appropriate. The script requires a clean git working tree, bumps the version, refreshes `uv.lock`, builds and publishes the package, then creates a release commit and annotated git tag like `v0.7.1`.
