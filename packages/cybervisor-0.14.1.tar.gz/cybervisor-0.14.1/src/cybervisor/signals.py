from __future__ import annotations

import asyncio
import os
import signal
import sys
import threading
import time
from types import FrameType
from typing import Callable, Iterable

from cybervisor.logging import CybervisorLogger


class SignalHandler:
    def __init__(self, logger: CybervisorLogger, log_file: str = ".cybervisor/logs/cybervisor.log.jsonl") -> None:
        self.logger = logger
        self.log_file = log_file
        self.pid: int | None = None
        self.process_group_id: int | None = None
        self.interrupted = False
        self.signal_number: int | None = None
        self._cleanup_callback: Callable[[], str] | None = None
        self._child_pids: list[int] = []
        self._child_pids_lock = threading.Lock()

    def _process_exists(self) -> bool:
        if self.process_group_id is not None and hasattr(os, "killpg"):
            try:
                os.killpg(self.process_group_id, 0)
            except ProcessLookupError:
                return False
            except PermissionError:
                return True
            return True

        if self.pid is None:
            return False
        try:
            os.kill(self.pid, 0)
        except ProcessLookupError:
            return False
        except PermissionError:
            return True
        return True

    def _terminate_active_process(self, signum: int, cancel_event: asyncio.Event | None = None) -> None:
        if self.pid is None:
            # No subprocess to signal - mark as interrupted so pipeline can check.
            # This handles the mock case where no actual subprocess exists.
            self.interrupted = True
            if cancel_event is not None:
                cancel_event.set()
            return

        target = self.process_group_id if self.process_group_id is not None and hasattr(os, "killpg") else self.pid
        send_signal = os.killpg if self.process_group_id is not None and hasattr(os, "killpg") else os.kill
        target_kind = "subprocess group" if self.process_group_id is not None and hasattr(os, "killpg") else "subprocess"
        target_value = self.process_group_id if self.process_group_id is not None and hasattr(os, "killpg") else self.pid

        try:
            send_signal(target, signum)
            self.logger.log_to_stderr(
                f"Sent {signal.Signals(signum).name} to active {target_kind} "
                f"{'pgid' if target_kind == 'subprocess group' else 'pid'}={target_value}",
                level="warning",
            )
        except ProcessLookupError:
            self.logger.log_to_stderr(f"Subprocess pid={self.pid} already exited", level="warning")
            return

        if signum != signal.SIGKILL:
            deadline = time.monotonic() + 2.0
            while time.monotonic() < deadline:
                if not self._process_exists():
                    return
                time.sleep(0.05)
            if self._process_exists():
                self._terminate_active_process(signal.SIGTERM if signum == signal.SIGINT else signal.SIGKILL)

    def register(self) -> None:
        signal.signal(signal.SIGINT, self._handle_signal)
        signal.signal(signal.SIGTERM, self._handle_signal)

    def set_pid(self, pid: int | None, process_group_id: int | None = None) -> None:
        self.pid = pid
        self.process_group_id = process_group_id

    def set_cleanup_callback(self, callback: Callable[[], str] | None) -> None:
        self._cleanup_callback = callback

    def register_child_pid(self, pid: int) -> None:
        with self._child_pids_lock:
            if pid not in self._child_pids:
                self._child_pids.append(pid)

    def register_child_pids(self, pids: Iterable[int]) -> None:
        with self._child_pids_lock:
            for pid in pids:
                if pid not in self._child_pids:
                    self._child_pids.append(pid)

    def clear_child_pids(self) -> None:
        with self._child_pids_lock:
            self._child_pids.clear()

    def _terminate_child_pids(self) -> None:
        with self._child_pids_lock:
            pids_snapshot = list(self._child_pids)

        for child_pid in pids_snapshot:
            try:
                os.kill(child_pid, signal.SIGTERM)
                self.logger.log_to_stderr(
                    f"Sent SIGTERM to child pid={child_pid}",
                    level="warning",
                )
            except ProcessLookupError:
                self.logger.log_to_stderr(f"Child pid={child_pid} already exited", level="warning")
            except PermissionError:
                self.logger.log_to_stderr(f"Permission denied when sending SIGTERM to child pid={child_pid}", level="warning")

        if pids_snapshot:
            deadline = time.monotonic() + 2.0
            remaining = set(pids_snapshot)
            while time.monotonic() < deadline and remaining:
                time.sleep(0.05)
                for pid in list(remaining):
                    try:
                        os.kill(pid, 0)
                    except (ProcessLookupError, PermissionError):
                        remaining.discard(pid)
            with self._child_pids_lock:
                self._child_pids = list(remaining)

            for child_pid in remaining:
                try:
                    os.kill(child_pid, signal.SIGKILL)
                    self.logger.log_to_stderr(
                        f"Sent SIGKILL to child pid={child_pid}",
                        level="warning",
                    )
                except (ProcessLookupError, PermissionError):
                    pass

    def _handle_signal(self, signum: int, _frame: FrameType | None) -> None:
        self.interrupted = True
        self.signal_number = signum
        cleanup_result = "skipped"
        with self._child_pids_lock:
            has_children = bool(self._child_pids)
        if has_children:
            self._terminate_child_pids()
        if self.pid is not None:
            self._terminate_active_process(signum)
        if self._cleanup_callback is not None:
            try:
                cleanup_result = self._cleanup_callback()
            except Exception as exc:
                cleanup_result = f"failed:{exc}"
                self.logger.log_to_stderr(f"Cleanup during interrupt failed: {exc}", level="error")
        self.logger.log_to_stderr(f"Received signal {signum}; shutting down", level="error")
        self.logger.log_to_json(
            self.logger.make_entry(
                "system",
                "Interrupted",
                f"Received signal {signum}; shutting down",
                cleanup_result=cleanup_result,
            ),
            self.log_file,
        )
        # Cap cleanup at 5s: if sys.exit handlers take too long, force exit.
        _cleanup_timeout = threading.Timer(5.0, os._exit, args=[130])
        _cleanup_timeout.daemon = True
        _cleanup_timeout.start()
        sys.exit(130)
