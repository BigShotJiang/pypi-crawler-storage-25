"""Project-local skills disable/restore for coding agents."""

from __future__ import annotations

import logging
import shutil
from pathlib import Path
from typing import Any

_logger = logging.getLogger(__name__)

_BACKUPS_DIR = ".cybervisor/backups/skills"

# Adapter name -> project-local skills directory.
# Codex uses .agents/skills (not .codex/skills).
_ADAPTER_SKILLS_DIRS: dict[str, str] = {
    "claude": ".claude/skills",
    "gemini": ".gemini/skills",
    "codex": ".agents/skills",
}


def _skills_dir_for_adapter(adapter_name: str, root: Path) -> Path:
    """Return the project-local skills directory for the given adapter name."""
    return root / _ADAPTER_SKILLS_DIRS.get(adapter_name, f".{adapter_name}/skills")


def _backup_dir_for_adapter(adapter_name: str, root: Path) -> Path:
    return root / _BACKUPS_DIR / adapter_name


def _move_skill(skill_path: Path, backup_path: Path) -> bool:
    """Move a single skill file/dir to backup. Returns True if moved."""
    try:
        backup_path.parent.mkdir(parents=True, exist_ok=True)
        if backup_path.exists():
            _logger.warning("Backup path already exists, removing: %s", backup_path)
            if backup_path.is_dir():
                shutil.rmtree(backup_path)
            else:
                backup_path.unlink()
        shutil.move(str(skill_path), str(backup_path))
        return True
    except OSError as exc:
        _logger.warning("Failed to move skill %s to %s: %s", skill_path, backup_path, exc)
        return False


def _restore_skill(backup_path: Path, original_path: Path) -> bool:
    """Restore a single skill from backup. Returns True if restored."""
    try:
        if not backup_path.exists():
            return False
        if original_path.exists():
            _logger.warning("Original path exists during restore, removing: %s", original_path)
            if original_path.is_dir():
                shutil.rmtree(original_path)
            else:
                original_path.unlink()
        original_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(backup_path), str(original_path))
        return True
    except OSError as exc:
        _logger.warning("Failed to restore skill %s to %s: %s", backup_path, original_path, exc)
        return False


def move_disabled_skills(
    adapter_name: str,
    skills_dir: Path | None,
    disabled_skills: list[str],
    *,
    root: Path = Path("."),
) -> list[tuple[Path, Path]]:
    """Move disabled skills from the project-local skills dir to backup.

    Returns a list of (original_path, backup_path) tuples for items that were moved.
    """
    moved: list[tuple[Path, Path]] = []
    if not disabled_skills or skills_dir is None:
        return moved

    if not skills_dir.exists():
        return moved

    backup_dir = _backup_dir_for_adapter(adapter_name, root)
    for skill_name in disabled_skills:
        if "/" in skill_name or "\\" in skill_name or skill_name in (".", ".."):
            _logger.warning("Skipping invalid disabled_skills entry '%s': must not contain path separators or be a directory traversal", skill_name)
            continue
        skill_path = skills_dir / skill_name
        if not skill_path.exists():
            # Also check with common extensions/suffixes
            for ext in (".md", ".py", ""):
                candidate = skills_dir / f"{skill_name}{ext}"
                if candidate.exists():
                    skill_path = candidate
                    break
            else:
                continue

        backup_path = backup_dir / skill_path.name
        if _move_skill(skill_path, backup_path):
            moved.append((skill_path, backup_path))
            _logger.info("Disabled skill '%s' for %s (moved to %s)", skill_name, adapter_name, backup_path)

    return moved


def restore_skills(moved: list[tuple[Path, Path]]) -> None:
    """Restore all moved skills from backup to their original locations."""
    for original_path, backup_path in moved:
        if _restore_skill(backup_path, original_path):
            _logger.info("Restored skill '%s' to %s", backup_path.name, original_path)


def restore_all_skills(*, root: Path = Path(".")) -> None:
    """Emergency restore: move every backed-up skill back to its project-local dir.

    Called at the start of a run to recover from an unclean shutdown.
    """
    backups_dir = root / _BACKUPS_DIR
    if not backups_dir.exists():
        return

    for adapter_dir in backups_dir.iterdir():
        if not adapter_dir.is_dir():
            continue
        adapter_name = adapter_dir.name
        skills_dir = _skills_dir_for_adapter(adapter_name, root)
        if not skills_dir.exists():
            skills_dir.mkdir(parents=True, exist_ok=True)
        for backup_item in adapter_dir.iterdir():
            original_path = skills_dir / backup_item.name
            _restore_skill(backup_item, original_path)

        # Remove empty adapter backup dir
        try:
            if not any(adapter_dir.iterdir()):
                adapter_dir.rmdir()
        except OSError:
            pass

    # Remove empty backups dir
    try:
        if backups_dir.exists() and not any(backups_dir.iterdir()):
            backups_dir.rmdir()
    except OSError:
        pass
