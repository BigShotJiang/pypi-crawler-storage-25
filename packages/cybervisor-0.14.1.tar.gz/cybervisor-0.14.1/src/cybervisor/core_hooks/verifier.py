"""Verifier HTTP client, response parsing, and structured output recovery."""

from __future__ import annotations

import importlib.resources
import json
from pathlib import Path
from typing import Any, Callable, TypeVar
from urllib.parse import urlsplit, urlunsplit

import httpx

from cybervisor._constants import DEFAULT_ENDPOINT, DEFAULT_MODEL

__all__ = [
    "DEFAULT_ENDPOINT",
    "DEFAULT_MODEL",
    "HOOK_USER_AGENT",
    "HOOK_HTTP_TIMEOUT_SECONDS",
    "STRUCTURED_RETRY_ATTEMPTS",
    "VERIFIER_REQUEST_RETRY_ATTEMPTS",
    "VerifierRequestError",
    "VerifierResponseShapeError",
    "chat_completions_url",
    "get_stop_verifier_prompt",
    "post",
    "recover_structured_output",
    "request_verifier_text",
]

_TStructured = TypeVar("_TStructured")

HOOK_USER_AGENT = "cybervisor-hook/1"
HOOK_HTTP_TIMEOUT_SECONDS = 120.0
STRUCTURED_RETRY_ATTEMPTS = 5
VERIFIER_REQUEST_RETRY_ATTEMPTS = 3


class VerifierRequestError(Exception):
    pass


class VerifierResponseShapeError(VerifierRequestError):
    pass


def chat_completions_url(base_url: str) -> str:
    stripped = base_url.strip()
    if not stripped:
        raise ValueError("Verifier API endpoint must not be empty")

    parsed = urlsplit(stripped)
    path = parsed.path.rstrip("/")
    if path.endswith("/chat/completions"):
        normalized_path = path
    else:
        normalized_path = f"{path}/chat/completions" if path else "/chat/completions"
    return urlunsplit((parsed.scheme, parsed.netloc, normalized_path, parsed.query, parsed.fragment))


def post(api_endpoint: str, api_key: str, model: str, messages: list[dict[str, str]]) -> str:
    headers = {
        "Content-Type": "application/json",
        "User-Agent": HOOK_USER_AGENT,
    }
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    try:
        with httpx.Client(timeout=HOOK_HTTP_TIMEOUT_SECONDS) as client:
            response = client.post(
                chat_completions_url(api_endpoint),
                headers=headers,
                json={"model": model, "messages": messages},
            )
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code >= 500:
            raise VerifierRequestError(f"verifier server error ({exc.response.status_code})") from exc
        raise
    except httpx.TimeoutException as exc:
        raise VerifierRequestError("verifier request timed out") from exc
    except httpx.NetworkError as exc:
        raise VerifierRequestError(f"verifier network error: {exc}") from exc

    try:
        payload = response.json()
    except json.JSONDecodeError as exc:
        raise VerifierResponseShapeError("invalid JSON in LLM response") from exc
    choices = payload.get("choices", [])
    if not choices:
        raise VerifierResponseShapeError("missing choices in LLM response")
    message = choices[0].get("message", {})
    content = message.get("content", "")
    if not isinstance(content, str) or not content.strip():
        raise VerifierResponseShapeError("missing content in LLM response")
    return content


def get_stop_verifier_prompt(config_path: Path) -> str:
    del config_path
    # Use importlib.resources for package-relative path resolution
    try:
        prompt_text = importlib.resources.files("cybervisor.assets.hooks").joinpath("stop-hook-verifier.md").read_text(encoding="utf-8")
        if prompt_text.strip():
            return prompt_text.strip()
    except (FileNotFoundError, TypeError, AttributeError, OSError, ModuleNotFoundError):
        pass
    # Fallback to __file__-based resolution for editable installs
    prompt_path = Path(__file__).resolve().parent.parent.parent.parent / "assets" / "hooks" / "stop-hook-verifier.md"
    if prompt_path.exists():
        return prompt_path.read_text(encoding="utf-8").strip()
    return "Decide if the agent can stop. Respond in valid JSON only with 'decision' and 'reason'."


def recover_structured_output(
    *,
    api_endpoint: str,
    api_key: str,
    model: str,
    initial_messages: list[dict[str, str]],
    parser: Callable[[str], _TStructured],
    regeneration_system_prompt: str,
    log_path: Path,
    agent_tool: str | None,
    config_path: Path,
    hook_input: str,
    notify_listener: bool = True,
    post_fn: Callable[[str, str, str, list[dict[str, str]]], str] = post,
) -> tuple[_TStructured, str]:
    from cybervisor.core_hooks.streaming import log_hook_event

    text = request_verifier_text(
        api_endpoint=api_endpoint,
        api_key=api_key,
        model=model,
        messages=initial_messages,
        log_path=log_path,
        agent_tool=agent_tool,
        config_path=config_path,
        hook_input=hook_input,
        event_name="verifier_request_retry",
        notify_listener=notify_listener,
        post_fn=post_fn,
    )

    last_error: Exception | None = None
    for attempt in range(1, STRUCTURED_RETRY_ATTEMPTS + 1):
        try:
            return parser(text), text
        except Exception as exc:
            last_error = exc
            if attempt >= STRUCTURED_RETRY_ATTEMPTS:
                break
            log_hook_event(
                log_path,
                "verifier_regeneration_requested",
                "Verifier response was invalid; requesting JSON regeneration.",
                agent_tool=agent_tool,
                config_path=config_path,
                hook_input=hook_input,
                verifier_output=text,
                error=f"attempt={attempt + 1}/{STRUCTURED_RETRY_ATTEMPTS}: {exc}",
                notify_listener=notify_listener,
            )
            text = request_verifier_text(
                api_endpoint=api_endpoint,
                api_key=api_key,
                model=model,
                messages=[
                    {"role": "system", "content": regeneration_system_prompt},
                    {
                        "role": "user",
                        "content": (
                            f"Previous invalid output:\n{text}\n\n"
                            f"Error:\n{exc}\n\n"
                            f"Attempt: {attempt + 1}/{STRUCTURED_RETRY_ATTEMPTS}"
                        ),
                    },
                ],
                log_path=log_path,
                agent_tool=agent_tool,
                config_path=config_path,
                hook_input=hook_input,
                event_name="verifier_request_retry",
                notify_listener=notify_listener,
                post_fn=post_fn,
            )

    raise ValueError(
        "Verifier returned invalid structured output after "
        f"{STRUCTURED_RETRY_ATTEMPTS} attempts: {last_error}"
    )


def request_verifier_text(
    *,
    api_endpoint: str,
    api_key: str,
    model: str,
    messages: list[dict[str, str]],
    log_path: Path,
    agent_tool: str | None,
    config_path: Path,
    hook_input: str,
    event_name: str,
    notify_listener: bool = True,
    post_fn: Callable[[str, str, str, list[dict[str, str]]], str] = post,
) -> str:
    from cybervisor.core_hooks.streaming import log_hook_event

    last_error: Exception | None = None
    for attempt in range(1, VERIFIER_REQUEST_RETRY_ATTEMPTS + 1):
        try:
            text = post_fn(api_endpoint, api_key, model, messages)
        except VerifierRequestError as exc:
            last_error = exc
            if attempt >= VERIFIER_REQUEST_RETRY_ATTEMPTS:
                break
            log_hook_event(
                log_path,
                event_name,
                "Verifier request failed; retrying.",
                agent_tool=agent_tool,
                config_path=config_path,
                hook_input=hook_input,
                error=f"attempt={attempt + 1}/{VERIFIER_REQUEST_RETRY_ATTEMPTS}: {exc}",
                notify_listener=notify_listener,
            )
            continue

        log_hook_event(
            log_path,
            "verifier_response_received",
            "Received verifier response.",
            agent_tool=agent_tool,
            config_path=config_path,
            hook_input=hook_input,
            verifier_output=text,
            notify_listener=notify_listener,
        )
        return text

    if last_error is None:
        raise VerifierRequestError("verifier request failed")
    raise VerifierRequestError(
        "Verifier request failed after "
        f"{VERIFIER_REQUEST_RETRY_ATTEMPTS} attempts: {last_error}"
    ) from last_error
