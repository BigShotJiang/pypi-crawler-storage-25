"""Hook event logging, decision parsing, and verifier input formatting."""

from __future__ import annotations

import json
import logging
import os
import re
import socket
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from cybervisor.core_hooks.verifier import DEFAULT_ENDPOINT, DEFAULT_MODEL

_logger = logging.getLogger(__name__)

AUTONOMY_DENY_MESSAGE = "Do not ask the user for input. Continue autonomously with the next concrete step."


class HookDecision:
    __slots__ = ("action", "reason", "system_message")

    def __init__(self, action: str, reason: str, system_message: str | None = None) -> None:
        self.action = action
        self.reason = reason
        self.system_message = system_message

    def as_payload(self) -> dict[str, Any]:
        return {
            "decision": self.action,
            "reason": self.reason,
        }

    def as_hook_output(self, agent_tool: str | None) -> dict[str, Any]:
        if agent_tool != "claude":
            if self.action == "approve":
                return {
                    "decision": "allow",
                    "reason": self.reason,
                }
            payload = {
                "decision": "deny",
                "reason": self.reason,
            }
            payload["systemMessage"] = self.system_message or self.reason or AUTONOMY_DENY_MESSAGE
            return payload
        if self.action == "block":
            stop_reason = self.system_message or self.reason or AUTONOMY_DENY_MESSAGE
            return {
                "decision": "block",
                "reason": stop_reason,
            }
        return {}

    @property
    def is_blocking(self) -> bool:
        return self.action == "block"


def continuation_message_for_decision(decision: HookDecision) -> str:
    if decision.system_message and decision.system_message.strip():
        return decision.system_message.strip()
    if decision.reason and decision.reason.strip():
        return decision.reason.strip()
    return AUTONOMY_DENY_MESSAGE


def contract_blocking_decision(agent_tool: str | None, message: str) -> HookDecision:
    if agent_tool == "claude":
        return HookDecision(action="block", reason=message)
    return HookDecision(action="block", reason="stage_contract_invalid", system_message=message)


def blocking_decision(agent_tool: str | None, reason: str) -> HookDecision:
    if agent_tool == "claude":
        return HookDecision(action="block", reason=AUTONOMY_DENY_MESSAGE)
    return HookDecision(action="block", reason=reason, system_message=AUTONOMY_DENY_MESSAGE)


def utc_now() -> str:
    return datetime.now(tz=timezone.utc).isoformat()


def load_hook_runtime_config(config_path: Path) -> dict[str, Any]:
    if not config_path.exists():
        raise FileNotFoundError(f"Configuration file not found: {config_path}")

    content = config_path.read_text(encoding="utf-8").strip()
    if not content:
        return {}

    raw = json.loads(content)
    if not isinstance(raw, dict):
        raise ValueError("Configuration file root must be a JSON object")
    return raw


def json_default(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    raise TypeError(f"Object of type {type(value).__name__} is not JSON serializable")


def append_hook_event(log_path: Path, payload: dict[str, Any]) -> None:
    try:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with log_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(payload, default=json_default) + "\n")
    except OSError as exc:
        _logger.warning("Failed to append hook event to %s: %s", log_path, exc)


def send_hook_event(socket_path: str | None, payload: dict[str, Any]) -> bool:
    if not socket_path:
        return True
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
            client.settimeout(0.2)
            client.connect(socket_path)
            client.sendall((json.dumps(payload, default=json_default) + "\n").encode("utf-8"))
    except Exception as exc:
        _logger.warning("Hook event send failed on %s: %s", socket_path, exc)
        return False
    return True


def socket_path_from_config(config_path: Path) -> str | None:
    try:
        raw_socket_path = load_hook_runtime_config(config_path).get("socket_path")
    except (FileNotFoundError, ValueError):
        return None
    return raw_socket_path if isinstance(raw_socket_path, str) and raw_socket_path else None


def log_hook_event(
    log_path: Path,
    event: str,
    message: str,
    *,
    agent_tool: str | None,
    config_path: Path,
    hook_input: str | None = None,
    verifier_output: str | None = None,
    decision: dict[str, Any] | None = None,
    error: str | None = None,
    session_id: str | None = None,
    notify_listener: bool = True,
    missing_artifacts: list[str] | None = None,
) -> None:
    payload: dict[str, Any] = {
        "timestamp": utc_now(),
        "event": event,
        "message": message,
        "agent_tool": agent_tool,
        "pid": os.getpid(),
        "config_path": str(config_path.resolve()),
    }
    if hook_input is not None:
        payload["hook_input"] = hook_input
    if verifier_output is not None:
        payload["verifier_output"] = verifier_output
    if decision is not None:
        payload["decision"] = decision
    if error is not None:
        payload["error"] = error
    if session_id is not None:
        payload["session_id"] = session_id
    if missing_artifacts is not None:
        payload["missing_artifacts"] = missing_artifacts
    append_hook_event(log_path, payload)
    if notify_listener:
        from cybervisor.core_hooks import runner as _runner

        _runner._send_hook_event(socket_path_from_config(config_path), payload)


def hook_log_path(config_path: Path) -> Path:
    resolved_config = config_path.resolve()
    if resolved_config.parent.name == "hooks" and resolved_config.parent.parent.name == ".cybervisor":
        return resolved_config.parent.parent / "logs" / "hook-events.jsonl"
    return resolved_config.parent / "logs" / "hook-events.jsonl"


def resolve_verifier_settings() -> tuple[str, str, str]:
    from cybervisor.global_config import GlobalConfigError, _resolve_verifier_model, load_global_config

    try:
        global_config = load_global_config()
    except GlobalConfigError:
        return DEFAULT_ENDPOINT, "", DEFAULT_MODEL
    model = _resolve_verifier_model(global_config)
    return global_config.llm.base_url, global_config.llm.api_key, model


def active_stage_prompt(config_path: Path) -> str | None:
    try:
        raw_prompt = load_hook_runtime_config(config_path).get("active_stage_prompt")
    except (FileNotFoundError, ValueError):
        return None
    return raw_prompt.strip() if isinstance(raw_prompt, str) and raw_prompt.strip() else None


def strip_fences(text: str) -> str:
    stripped = text.strip()
    if stripped.startswith("```") and stripped.endswith("```"):
        lines = stripped.splitlines()
        if len(lines) >= 3:
            return "\n".join(lines[1:-1]).strip()
    return stripped


def parse_decision(text: str) -> HookDecision:
    payload = json.loads(strip_fences(text))
    if not isinstance(payload, dict):
        raise ValueError("decision output must be a JSON object")
    raw_decision = payload.get("decision")
    reason = payload.get("reason", payload.get("explanation"))
    if not isinstance(raw_decision, str):
        raise ValueError("decision must be a string")
    normalized_decision = raw_decision.strip().lower()
    action_aliases = {
        "approve": "approve",
        "allow": "approve",
        "block": "block",
        "deny": "block",
    }
    action = action_aliases.get(normalized_decision)
    if action is None:
        raise ValueError("decision must be 'approve' or 'block'")
    if not isinstance(reason, str) or not reason.strip():
        raise ValueError("reason must be a non-empty string")
    return HookDecision(action=action, reason=reason.strip())


def parse_hook_payload(output: str) -> dict[str, Any] | None:
    try:
        payload = json.loads(output)
    except json.JSONDecodeError:
        return None
    return payload if isinstance(payload, dict) else None


def collapse_whitespace(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def extract_json_string_field(output: str, key: str) -> str | None:
    match = re.search(rf'"{re.escape(key)}"\s*:\s*', output)
    if match is None:
        return None
    suffix = output[match.end():].lstrip()
    if not suffix.startswith('"'):
        return None
    try:
        decoded, _ = json.JSONDecoder().raw_decode(suffix)
    except json.JSONDecodeError:
        return None
    return decoded if isinstance(decoded, str) and decoded.strip() else None


def dedupe_subsumed_segments(segments: list[str]) -> list[str]:
    unique: list[str] = []
    normalized_seen: list[str] = []
    for segment in segments:
        normalized = collapse_whitespace(segment)
        if not normalized:
            continue
        if any(
            normalized == seen
            or (len(normalized) >= 24 and normalized in seen)
            or (len(seen) >= 24 and seen in normalized)
            for seen in normalized_seen
        ):
            continue
        unique.append(segment)
        normalized_seen.append(normalized)
    return unique


def strip_prompt_prefix(text: str, stage_prompt: str | None) -> str:
    stripped = text.strip()
    if not stage_prompt:
        return stripped
    prompt = stage_prompt.strip()
    if prompt and stripped.startswith(prompt):
        stripped = stripped[len(prompt):].lstrip()
    return stripped


def clean_gemini_final_response(text: str, stage_prompt: str | None) -> str:
    stripped = strip_prompt_prefix(text, stage_prompt)
    if not stripped:
        return ""

    raw_segments = [
        collapse_whitespace(segment)
        for segment in re.split(r"\n\s*\n+", stripped)
        if collapse_whitespace(segment)
    ]
    cleaned_segments = [segment for segment in dedupe_subsumed_segments(raw_segments)]
    if cleaned_segments:
        return "\n\n".join(cleaned_segments)
    return collapse_whitespace(stripped)


def format_verifier_payload(*, agent_tool: str | None, stage_prompt: str | None, final_response: str) -> str:
    lines = [f"Agent tool: {agent_tool or 'unknown'}"]
    if stage_prompt and stage_prompt.strip():
        lines.extend(["Stage prompt:", stage_prompt.strip()])
    lines.extend(["", "", "Final assistant response:", final_response.strip()])
    return "\n".join(lines)


def format_contract_verifier_payload(
    *,
    agent_tool: str | None,
    stage_prompt: str | None,
    artifact_path: Path,
    artifact_payload: dict[str, Any],
    tool_context: str | None,
) -> str:
    import yaml

    lines = [f"Agent tool: {agent_tool or 'unknown'}"]
    if stage_prompt and stage_prompt.strip():
        lines.extend(["Stage prompt:", stage_prompt.strip()])
    lines.extend(
        [
            "Contract artifact path:",
            str(artifact_path),
            "Contract artifact payload:",
            yaml.safe_dump(artifact_payload, sort_keys=False).rstrip(),
        ]
    )
    if tool_context:
        lines.extend(["Relevant tool activity:", tool_context])
    return "\n".join(lines)


def normalize_hook_verifier_input(output: str, *, agent_tool: str | None, config_path: Path) -> str:
    stage_prompt = active_stage_prompt(config_path)
    payload = parse_hook_payload(output)

    from cybervisor.core_hooks.contracts import validate_stage_contract_artifact as _validate_stage_contract_artifact

    contract = None
    try:
        from cybervisor.core_hooks.contracts import active_stage_contract

        contract = active_stage_contract(config_path)
    except Exception:
        logging.exception("Failed to read active stage contract")
        contract = None

    if contract is not None:
        artifact_payload, artifact_error = _validate_stage_contract_artifact(config_path)
        if artifact_error is None and artifact_payload is not None:
            from cybervisor.adapters.gemini.hook_context import extract_tool_activity_from_transcript_path
            from cybervisor.core_hooks.contracts import resolve_artifact_path

            tool_context = extract_tool_activity_from_transcript_path(
                payload.get("transcript_path") if payload is not None else None
            )
            return format_contract_verifier_payload(
                agent_tool=agent_tool,
                stage_prompt=stage_prompt,
                artifact_path=resolve_artifact_path(contract),
                artifact_payload=artifact_payload,
                tool_context=tool_context,
            )

    if agent_tool == "claude":
        final_response = None
        if payload is not None:
            response = payload.get("last_assistant_message")
            if isinstance(response, str) and response.strip():
                final_response = response.strip()
        if final_response is None:
            final_response = collapse_whitespace(output)
        return format_verifier_payload(
            agent_tool=agent_tool,
            stage_prompt=stage_prompt,
            final_response=final_response,
        )

    final_candidates: list[str] = []
    if payload is not None:
        for key in ("prompt_response", "response", "final_response", "assistant_response"):
            value = payload.get(key)
            if isinstance(value, str) and value.strip():
                final_candidates.append(value)
    else:
        for key in ("prompt_response", "response", "final_response", "assistant_response", "last_assistant_message"):
            value = extract_json_string_field(output, key)
            if value is not None:
                final_candidates.append(value)
    if not final_candidates:
        final_candidates.append(output)

    cleaned_candidates = [clean_gemini_final_response(candidate, stage_prompt) for candidate in final_candidates]
    final_response = next((candidate for candidate in cleaned_candidates if candidate.strip()), collapse_whitespace(output))
    return format_verifier_payload(
        agent_tool=agent_tool,
        stage_prompt=stage_prompt,
        final_response=final_response,
    )
