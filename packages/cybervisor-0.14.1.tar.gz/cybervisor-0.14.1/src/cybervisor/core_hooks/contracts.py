"""Stage contract validation and resolution helpers."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from cybervisor.core_hooks.streaming import load_hook_runtime_config


def resolve_artifact_path(contract: dict[str, Any]) -> Path:
    raw_path = contract.get("artifact_path")
    if not isinstance(raw_path, str) or not raw_path.strip():
        raise ValueError("contract artifact_path is missing")
    candidate = Path(raw_path)
    if candidate.is_absolute():
        raise ValueError("contract artifact_path must be relative to the working directory")
    workspace_root = contract.get("workspace_root")
    if isinstance(workspace_root, str) and workspace_root.strip():
        cwd = Path(workspace_root).resolve()
    else:
        cwd = Path.cwd().resolve()
    resolved = (cwd / candidate).resolve()
    try:
        resolved.relative_to(cwd)
    except ValueError as exc:
        raise ValueError("contract artifact_path must stay within the working directory") from exc
    return resolved


def contract_prompt_guidance(contract: dict[str, Any]) -> str:
    guidance = contract.get("guidance")
    if isinstance(guidance, str) and guidance.strip():
        return guidance.strip()
    prompt_path = contract.get("prompt_path")
    if isinstance(prompt_path, str) and prompt_path.strip():
        return f"Read {prompt_path.strip()} for more information."
    prompt_contents = contract.get("prompt_contents")
    if isinstance(prompt_contents, str) and prompt_contents.strip():
        return "Follow the contract prompt guidance and write the required YAML artifact."
    return "Write the required contract artifact as YAML using the expected top-level structure."


def contract_repair_message(contract: dict[str, Any], validation_message: str) -> str:
    artifact_path = resolve_artifact_path(contract)
    allowed_statuses = contract.get("allowed_statuses", [])
    guidance = contract_prompt_guidance(contract)
    allowed = ", ".join(allowed_statuses) if isinstance(allowed_statuses, list) else ""
    lowered_validation = validation_message.lower()
    include_status_hint = "status" in lowered_validation and bool(allowed)

    parts = [f"Before stopping, repair {artifact_path}.", validation_message.rstrip(".") + "."]
    if include_status_hint:
        parts.append(f"Allowed statuses: {allowed}.")
    prefix = " ".join(parts)
    return f"{prefix}\n\n{guidance.rstrip('.')}."


def validate_stage_contract_artifact(config_path: Path) -> tuple[dict[str, Any] | None, str | None]:
    try:
        contract_raw = load_hook_runtime_config(config_path).get("active_stage_contract")
    except (FileNotFoundError, ValueError):
        return None, None

    if contract_raw is None or not isinstance(contract_raw, dict):
        return None, None

    try:
        artifact_path = resolve_artifact_path(contract_raw)
    except ValueError as exc:
        return None, str(exc)

    if not artifact_path.exists():
        return None, "write the required stage artifact"

    try:
        payload = yaml.safe_load(artifact_path.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        return None, f"rewrite {artifact_path} as valid YAML ({exc})"

    if not isinstance(payload, dict):
        return None, f"rewrite {artifact_path} so the top-level value is a YAML mapping"

    allowed_statuses = contract_raw.get("allowed_statuses")
    if not isinstance(allowed_statuses, list) or not all(isinstance(item, str) for item in allowed_statuses):
        return None, "stage contract allowed_statuses is invalid"

    status = payload.get("Status")
    if not isinstance(status, str) or status not in allowed_statuses:
        return None, f"set {artifact_path} Status to one of: {', '.join(allowed_statuses)}"
    routes = contract_raw.get("routes", {})
    route = routes.get(status) if isinstance(routes, dict) else None
    if not isinstance(route, dict):
        return None, f"set {artifact_path} Status to match a configured contract route"
    injections = route.get("injections", [])
    if not isinstance(injections, list) or not all(isinstance(item, str) for item in injections):
        return None, "stage contract route injections are invalid"
    for field_name in injections:
        field_value = payload.get(field_name)
        if not isinstance(field_value, str) or not field_value.strip():
            return None, f"set {artifact_path} {field_name} to a non-empty string"
    allowed_fields = {"Status", *injections}
    unexpected_fields = [
        field_name
        for field_name, field_value in payload.items()
        if field_name not in allowed_fields and isinstance(field_value, str) and field_value.strip()
    ]
    if unexpected_fields:
        rendered_fields = ", ".join(unexpected_fields)
        return None, f"remove unexpected fields from {artifact_path} for Status {status}: {rendered_fields}"

    return payload, None


def active_stage_contract(config_path: Path) -> dict[str, Any] | None:
    try:
        raw = load_hook_runtime_config(config_path).get("active_stage_contract")
    except (FileNotFoundError, ValueError):
        return None
    return raw if isinstance(raw, dict) else None


def is_final_stage_attempt(config_path: Path) -> bool:
    try:
        raw = load_hook_runtime_config(config_path)
    except (FileNotFoundError, ValueError):
        return False
    attempt = raw.get("active_stage_attempt")
    max_retries = raw.get("active_stage_max_retries")
    return isinstance(attempt, int) and isinstance(max_retries, int) and attempt >= max_retries
