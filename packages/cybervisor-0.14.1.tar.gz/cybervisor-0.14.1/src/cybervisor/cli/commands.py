"""CLI command implementations."""

from __future__ import annotations

__all__ = [
    "StartupValidationError",
    "_run_attach_command",
    "_run_cancel_command",
    "_run_docs_command_impl",
    "_run_doctor_command",
    "_run_logs_command",
    "_run_pipeline",
    "_run_serve_command",
    "_run_serve_sandbox_command",
    "_run_stop_stage_command",
    "_run_submit_command",
    "_run_use_command",
    "_run_validate_command",
    "_select_agent",
    "_set_process_title",
    "main",
    "validate_stage_name_arg",
    "validate_start_stage",
]

import asyncio
import argparse
import sys
from typing import TYPE_CHECKING

from cybervisor import __version__
from cybervisor.upgrade import check_for_updates
from cybervisor.client import (
    _find_running_task_in_cwd,
    _resolve_config,
    ping_daemon,
    run_attach_command,
    run_cancel_command,
    run_logs_command,
    run_status_command,
    run_stop_stage_command,
    run_submit_command,
)
from cybervisor.cli.docs import DocsDocument
from cybervisor.cli.instance import (
    _check_single_instance,
    _remove_instance_lock,
    _remove_runtime_files,
    _write_runtime_files,
)
from cybervisor.cli.parser import (
    _resolve_prompt,
    build_parser,
    parse_args,
)
from cybervisor.config import PipelineConfig, StageConfig, StrictValidationError
from cybervisor.global_config import GlobalConfigError
from cybervisor.hooks import hook_socket_path
from cybervisor.init import run_init
from cybervisor.logging import CybervisorLogger, HookEventListener
from cybervisor.pipeline import PipelineInterrupted
from cybervisor.server import serve as run_serve
from cybervisor.signals import SignalHandler
from cybervisor.skills import move_disabled_skills, restore_all_skills, restore_skills

if TYPE_CHECKING:
    from cybervisor.adapters.types import AgentAdapter

RUN_LOG_PATH = ".cybervisor/logs/cybervisor.log.jsonl"


class StartupValidationError(Exception):
    def __init__(self, requested_stage_name: str, reason: str, valid_stage_names: list[str]) -> None:
        super().__init__(reason)
        self.requested_stage_name = requested_stage_name
        self.reason = reason
        self.valid_stage_names = valid_stage_names


def validate_stage_name_arg(requested: str | None, stages: list[StageConfig], flag_name: str) -> str | None:
    valid_names = [stage.name for stage in stages]

    seen = set()
    duplicates = set()
    for name in valid_names:
        if name in seen:
            duplicates.add(name)
        seen.add(name)

    if duplicates:
        raise StartupValidationError(
            requested or "",
            f"Duplicate stage name(s) found in config: {', '.join(sorted(duplicates))}. Cannot safely resolve starting stage. "
            "Remediation: Ensure each stage name is unique in cybervisor.yaml.",
            valid_names,
        )

    if requested is None:
        return None
    normalized = requested.strip()
    if not normalized:
        raise StartupValidationError(
            requested,
            f"{flag_name} must not be empty. Remediation: Provide a valid stage name from the configured stages.",
            valid_names,
        )
    if normalized not in valid_names:
        raise StartupValidationError(
            normalized,
            f"Unknown stage '{normalized}'. Remediation: Use a stage name that exists in your cybervisor.yaml, such as: {valid_names[0] if valid_names else '(none)'}.",
            valid_names,
        )
    return normalized


def validate_start_stage(requested: str | None, stages: list[StageConfig]) -> str | None:
    return validate_stage_name_arg(requested, stages, "--start-stage")


def _resolve_agent_tool() -> str:
    from cybervisor.cli import load_global_config

    try:
        return load_global_config().agent_tool
    except GlobalConfigError as exc:
        raise ValueError(str(exc)) from exc


def _select_agent(agent_tool: str) -> AgentAdapter:
    from cybervisor.adapters.registry import get_adapter

    return get_adapter(agent_tool)


def _set_process_title() -> None:
    if sys.platform.startswith("win"):
        return
    try:
        from setproctitle import setproctitle
    except ImportError:
        return
    setproctitle("cybervisor")


def _format_prompt_source_message(
    prompt_source: str | None,
    prompt_from_config: bool,
    start_stage_name: str | None,
) -> list[str]:
    """Build a consolidated list of informational messages about prompt source and stage selection."""
    messages: list[str] = []

    # Prompt source message
    if prompt_source == "stdin":
        messages.append("Objective source: stdin.")
    elif prompt_from_config:
        messages.append(
            "No prompt provided; task context will come from the configured stage prompt_template values."
        )
    elif prompt_source == "positional prompt":
        messages.append("Objective source: positional prompt.")

    # Start-stage interaction
    if start_stage_name is not None and prompt_from_config:
        messages.append(
            f"Promptless startup validated against the effective stage slice beginning at '{start_stage_name}'."
        )
    if start_stage_name is not None and prompt_source == "stdin":
        messages.append(f"Using --start-stage '{start_stage_name}' with stdin-supplied task context.")
    if start_stage_name is not None and prompt_source == "positional prompt":
        messages.append(f"Using --start-stage '{start_stage_name}' with positional prompt context.")

    # Template usage context
    if prompt_source == "positional prompt":
        messages.append(
            "Configured stage prompt_template values remain active; the positional prompt only supplies the objective context."
        )
    if prompt_from_config:
        messages.append(
            "Startup did not infer task context from repository state; only configured stage prompt_template values were used."
        )
    if prompt_source == "stdin":
        messages.append(
            "Configured stage prompt_template values remain active; stdin only supplies the objective context."
        )

    return messages


def _effective_stage_slice(stages: list[StageConfig], start_stage_name: str | None) -> list[StageConfig]:
    if start_stage_name is None:
        return stages
    start_index = next(index for index, stage in enumerate(stages) if stage.name == start_stage_name)
    return stages[start_index:]


def _stages_requiring_objective(stages: list[StageConfig], start_stage_name: str | None) -> list[str]:
    from cybervisor.cli import validate_prompt_templates

    return validate_prompt_templates(PipelineConfig(stages=_effective_stage_slice(stages, start_stage_name)))


def _run_pipeline(args: argparse.Namespace) -> int:
    from cybervisor.cli import (
        HookEventListener,
        PipelineRunner,
        _find_running_task_in_cwd,
        _remove_instance_lock,
        _remove_runtime_files,
        _resolve_config,
        _select_agent,
        _write_runtime_files,
        inject_hooks,
        load_config,
        remove_hooks,
        run_preflight,
        validate_prompt_templates,
    )

    logger = CybervisorLogger(quiet=args.quiet)
    logger.log_to_stderr(f"cybervisor {__version__}", "info")

    # Check daemon for active tasks before acquiring instance lock.
    daemon_config = _resolve_config(None, None)
    reachable, running_in_cwd = asyncio.run(_find_running_task_in_cwd(daemon_config))
    if reachable and running_in_cwd:
        if len(running_in_cwd) > 1:
            logger.log_to_stderr(
                "Multiple tasks are running in this directory. Use 'cybervisor cancel <task-id>' to target a specific task.",
                "error",
            )
            return 1
        task = running_in_cwd[0]
        active_stage = task.get("active_stage")
        stage_label = active_stage if active_stage is not None else "initializing"
        task_id = task.get("task_id") or ""
        logger.log_to_stderr(
            f"A task is already running in this directory (id: {task_id}, stage: {stage_label}). "
            f"Use 'cybervisor attach {task_id}' to view it, or 'cybervisor cancel {task_id}' to stop it.",
            "error",
        )
        return 1

    if not _check_single_instance():
        return 1

    resolved_prompt, prompt_source = _resolve_prompt(args)

    try:
        config = load_config(args.config)
    except FileNotFoundError as exc:
        logger.log_to_stderr(
            (
                f"Failed to load config: {exc}. "
                "Provide --config with a valid path or create cybervisor.yaml in the working directory."
            ),
            "error",
        )
        return 1
    except Exception as exc:  # pragma: no cover
        logger.log_to_stderr(f"Failed to load config: {exc}", "error")
        return 1

    try:
        start_stage_name = validate_stage_name_arg(args.start_stage, config.stages, "--start-stage")
        end_after_name = validate_stage_name_arg(args.end_after, config.stages, "--end-after")
        end_before_stage_name = validate_stage_name_arg(args.end_before, config.stages, "--end-before")
    except StartupValidationError as exc:
        logger.log_to_stderr(
            f"Invalid stage selection: {exc.reason}\nValid stages are: {', '.join(exc.valid_stage_names)}",
            "error",
        )
        return 1
    try:
        agent_tool = _resolve_agent_tool()
    except ValueError as exc:
        logger.log_to_stderr(f"Failed to resolve runtime agent: {exc}", "error")
        return 1

    if end_after_name is not None and end_before_stage_name is not None:
        logger.log_to_stderr(
            "Invalid stage selection: --end-after and --end-before cannot be used together.",
            "error",
        )
        return 1

    prompt_from_config = False
    if not resolved_prompt:
        missing_objective_stages = _stages_requiring_objective(config.stages, start_stage_name)
        if missing_objective_stages:
            logger.log_to_stderr(
                "No prompt was provided, and the following stages still require one because they rely on the default objective-driven prompt_template: "
                + ", ".join(missing_objective_stages),
                "error",
            )
            return 1
        prompt_from_config = True
        prompt_source = "config"

    for message in _format_prompt_source_message(prompt_source, prompt_from_config, start_stage_name):
        logger.log_to_stderr(message, "info")
    if prompt_from_config:
        resolved_prompt = ""

    errors = run_preflight(agent_tool, config)
    if errors:
        for error in errors:
            logger.log_to_stderr(error, "error")
        return 1

    logger.log_to_stderr(f"Using runtime agent '{agent_tool}'.", "info")

    # Recover skills from any previous unclean shutdown.
    restore_all_skills()

    agent = _select_agent(agent_tool)

    # Move disabled project-local skills before the pipeline starts.
    moved_skills = move_disabled_skills(
        agent.descriptor.name,
        agent.project_skills_dir(),
        config.disabled_skills,
    )

    hook_listener: HookEventListener | None = None
    if agent.descriptor.capabilities.supports_hooks:
        hook_listener = HookEventListener(logger, socket_path=hook_socket_path(), quiet=args.quiet)
        hook_listener.start()

    hooks_installed = False
    if agent.descriptor.capabilities.supports_hooks:
        try:
            inject_hooks(agent_tool, config.hook)
            hooks_installed = True
        except Exception as exc:
            if hook_listener is not None:
                hook_listener.stop()
            logger.log_to_stderr(f"Failed to install runtime hooks: {exc}", "error")
            restore_skills(moved_skills)
            return 1

    signal_handler = SignalHandler(logger, log_file=RUN_LOG_PATH)
    if hooks_installed:
        signal_handler.set_cleanup_callback(lambda: remove_hooks(agent_tool))
    signal_handler.register()
    _write_runtime_files()

    try:
        runner = PipelineRunner()
        from cybervisor.global_config import load_global_config as _load_global_config

        try:
            _global_config = _load_global_config()
            _stage_models = _global_config.stage_models if _global_config.stage_models else None
        except GlobalConfigError:
            _stage_models = None
        try:
            ok = runner.run(
                resolved_prompt,
                config.stages,
                agent,
                logger,
                signal_handler=signal_handler,
                hook_listener=hook_listener,
                start_stage_name=start_stage_name,
                end_after_name=end_after_name,
                end_before_stage_name=end_before_stage_name,
                stage_models=_stage_models,
            )
        except PipelineInterrupted:
            return 130
        return 0 if ok else 1
    finally:
        if hook_listener is not None:
            hook_listener.stop()
        if hooks_installed:
            try:
                restore_result = remove_hooks(agent_tool)
                logger.log_to_json(
                    logger.make_entry(
                        "system",
                        "Cleanup",
                        "Removed runtime hooks",
                        cleanup_result=restore_result,
                    ),
                    RUN_LOG_PATH,
                )
            except Exception as exc:
                logger.log_to_stderr(f"Failed to remove runtime hooks: {exc}", "warning")
        restore_skills(moved_skills)
        _remove_runtime_files()
        _remove_instance_lock()


async def _run_status_command(args: argparse.Namespace) -> int:
    return await run_status_command(host=args.host, port=args.port, task_id=args.task_id or None)


async def _run_submit_command(args: argparse.Namespace) -> int:
    from cybervisor.cli import _find_running_task_in_cwd, _resolve_config

    logger = CybervisorLogger(quiet=args.quiet)
    if args.end_after is not None and args.end_before is not None:
        logger.log_to_stderr(
            "Invalid stage selection: --end-after and --end-before cannot be used together.",
            "error",
        )
        return 1
    daemon_config = _resolve_config(args.host, args.port)
    reachable, running_in_cwd = await _find_running_task_in_cwd(daemon_config)
    if reachable and running_in_cwd:
        if len(running_in_cwd) > 1:
            logger.log_to_stderr(
                "Multiple tasks are running in this directory. Use 'cybervisor cancel <task-id>' to target a specific task.",
                "error",
            )
            return 1
        task = running_in_cwd[0]
        task_id = task.get("task_id") or ""
        logger.log_to_stderr(
            f"A task is already running in this directory (id: {task_id}). "
            f"Use 'cybervisor attach {task_id}' to view it, or 'cybervisor cancel {task_id}' to stop it.",
            "error",
        )
        return 1
    return await run_submit_command(
        prompt=args.prompt,
        host=args.host,
        port=args.port,
        task_id=args.task_id,
        config_path=args.config,
        start_stage=args.start_stage,
        end_after=args.end_after,
        end_before=args.end_before,
    )


async def _run_attach_command(args: argparse.Namespace) -> int:
    from cybervisor.cli import _find_running_task_in_cwd, _resolve_config

    logger = CybervisorLogger(quiet=args.quiet)
    task_id = args.task_id
    if task_id is None:
        daemon_config = _resolve_config(args.host, args.port)
        reachable, running_in_cwd = await _find_running_task_in_cwd(daemon_config)
        if not reachable:
            logger.log_to_stderr(f"Daemon not reachable at ws://{daemon_config.host}:{daemon_config.port}", "error")
            return 1
        if not running_in_cwd:
            logger.log_to_stderr("No active task to attach to.", "error")
            return 1
        if len(running_in_cwd) > 1:
            logger.log_to_stderr(
                "Multiple tasks are running in this directory. Use 'cybervisor attach <task-id>' to target a specific task.",
                "error",
            )
            return 1
        task_id = running_in_cwd[0].get("task_id")
        if task_id is None:
            logger.log_to_stderr("No active task to attach to.", "error")
            return 1
    return await run_attach_command(task_id=task_id, host=args.host, port=args.port)


async def _run_cancel_command(args: argparse.Namespace) -> int:
    from cybervisor.cli import _find_running_task_in_cwd, _resolve_config

    logger = CybervisorLogger(quiet=args.quiet)
    task_id = args.task_id
    if task_id is None:
        daemon_config = _resolve_config(args.host, args.port)
        reachable, running_in_cwd = await _find_running_task_in_cwd(daemon_config)
        if not reachable:
            logger.log_to_stderr(f"Daemon not reachable at ws://{daemon_config.host}:{daemon_config.port}", "error")
            return 1
        if not running_in_cwd:
            logger.log_to_stderr("No active task to cancel.", "error")
            return 1
        if len(running_in_cwd) > 1:
            logger.log_to_stderr(
                "Multiple tasks are running in this directory. Use 'cybervisor cancel <task-id>' to target a specific task.",
                "error",
            )
            return 1
        task_id = running_in_cwd[0].get("task_id")
        if task_id is None:
            logger.log_to_stderr("No active task to cancel.", "error")
            return 1
    return await run_cancel_command(task_id=task_id, host=args.host, port=args.port)


async def _run_logs_command(args: argparse.Namespace) -> int:
    return await run_logs_command(task_id=args.task_id, host=args.host, port=args.port)


async def _run_stop_stage_command(args: argparse.Namespace) -> int:
    from cybervisor.cli import _find_running_task_in_cwd, _resolve_config

    logger = CybervisorLogger(quiet=args.quiet)
    task_id = args.task_id
    if task_id is None:
        daemon_config = _resolve_config(args.host, args.port)
        reachable, running_in_cwd = await _find_running_task_in_cwd(daemon_config)
        if not reachable:
            logger.log_to_stderr(f"Daemon not reachable at ws://{daemon_config.host}:{daemon_config.port}", "error")
            return 1
        if not running_in_cwd:
            logger.log_to_stderr("No active task to set stop stage for.", "error")
            return 1
        if len(running_in_cwd) > 1:
            logger.log_to_stderr(
                "Multiple tasks are running in this directory. Use 'cybervisor stop-stage <task-id> --stage <stage>' to target a specific task.",
                "error",
            )
            return 1
        task_id = running_in_cwd[0].get("task_id")
        if task_id is None:
            logger.log_to_stderr("No active task to set stop stage for.", "error")
            return 1
    return await run_stop_stage_command(
        task_id=task_id,
        stage=args.stage,
        host=args.host,
        port=args.port,
    )


async def _run_serve_command(args: argparse.Namespace) -> int:
    logger = CybervisorLogger(quiet=args.quiet)
    try:
        await run_serve(
            host=args.host,
            port=args.port,
            background=args.background,
            logger=logger,
        )
        return 0
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        logger.log_to_stderr(f"Server error: {exc}", "error")
        return 1


def _run_serve_sandbox_command(args: argparse.Namespace) -> int:
    from cybervisor.cli.serve_sandbox import run_serve_sandbox

    logger = CybervisorLogger(quiet=args.quiet)
    try:
        return run_serve_sandbox(args, logger)
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        logger.log_to_stderr(f"Sandbox error: {exc}", "error")
        return 1


def _run_doctor_command(args: argparse.Namespace) -> int:
    from cybervisor.cli import diagnose_global_llm_readiness

    logger = CybervisorLogger(quiet=args.quiet)
    result = diagnose_global_llm_readiness(timeout=15.0)
    if result.is_ready:
        logger.log_to_stderr(f"Doctor: verifier ready — {result.summary}", "info")
        logger.log_to_stderr("Doctor: scope — verifier readiness only; this does not validate the full Cybervisor runtime.", "info")
        if result.status == "rate_limited":
            logger.log_to_stderr(f"Doctor: next step — {result.remediation}", "info")
        return result.exit_code

    state = "needs attention" if result.failure_category == "remote_probe" else "blocked"
    logger.log_to_stderr(f"Doctor: verifier {state} — {result.summary}", "error")
    logger.log_to_stderr("Doctor: scope — verifier readiness only; this does not validate the full Cybervisor runtime.", "error")
    logger.log_to_stderr(f"Doctor: next step — {result.remediation}", "error")
    return result.exit_code


def _run_use_command(args: argparse.Namespace) -> int:
    from cybervisor.cli import update_global_agent_tool
    from cybervisor.global_config import GlobalConfigError

    logger = CybervisorLogger(quiet=args.quiet)
    try:
        agent_tool, config_path = update_global_agent_tool(args.agent_tool)
    except GlobalConfigError as exc:
        logger.log_to_stderr(f"Failed to save runtime agent: {exc}", "error")
        return 1
    logger.log_to_stderr(f"Saved global runtime agent '{agent_tool}' to {config_path}.", "info")
    return 0


async def _run_docs_command_impl(args: argparse.Namespace) -> int:
    from cybervisor.cli import _resolve_docs_source_path
    from cybervisor.cli.docs import _resolve_docs_document, _render_docs_usage, _read_docs_source

    logger = CybervisorLogger(quiet=args.quiet)
    if not args.document:
        logger.log_to_stderr(_render_docs_usage(), "error")
        return 1
    document, error_message = _resolve_docs_document(args.document)
    if document is None:
        logger.log_to_stderr(error_message or _render_docs_usage(), "error")
        return 1
    try:
        source_path = _resolve_docs_source_path(document)
        contents = _read_docs_source(document)
    except FileNotFoundError as exc:
        logger.log_to_stderr(str(exc), "error")
        return 1
    print(f"SOURCE: {source_path}")
    print()
    print(contents, end="")
    return 0


def _run_validate_command(args: argparse.Namespace) -> int:
    from cybervisor.cli import validate_config_file
    from cybervisor.config import format_validation_issue, render_contract_guidance

    logger = CybervisorLogger(quiet=args.quiet)
    paths: list[str] = list(args.paths) if args.paths else ["cybervisor.yaml"]
    failures = 0
    for raw_path in paths:
        display_path = __import__("pathlib").Path(raw_path).resolve()
        try:
            resolved_path, config = validate_config_file(raw_path)
        except FileNotFoundError as exc:
            logger.log_to_stderr(f"INVALID {display_path}\n  - {exc}", "error")
            failures += 1
            continue
        except StrictValidationError as exc:
            issue_lines = "\n".join(f"  - {format_validation_issue(issue)}" for issue in exc.issues)
            logger.log_to_stderr(f"INVALID {exc.path.resolve()}\n{issue_lines}", "error")
            failures += 1
            continue
        except Exception as exc:
            logger.log_to_stderr(f"INVALID {display_path}\n  - {exc}", "error")
            failures += 1
            continue
        logger.log_to_stderr(f"VALID {resolved_path.resolve()}", "info")
        if args.show_guidance:
            for stage in config.stages:
                if stage.contract is None:
                    continue
                guidance = render_contract_guidance(stage.name, stage.contract).rstrip()
                logger.log_to_stderr(f"GUIDANCE {stage.name}:\n\n{guidance}\n", "info")
    return 0 if failures == 0 else 1


def main(argv: list[str] | None = None) -> int:
    from cybervisor.cli import _set_process_title as _spt

    _spt()
    try:
        args = parse_args(argv)
    except SystemExit as exc:
        return int(exc.code) if exc.code else 0

    if args.version:
        print(__version__)
        return 0

    # Trigger background upgrade check for long-running commands.
    if args.command in {"run", "serve", "serve-sandbox"}:
        check_for_updates()

    if args.command == "serve":
        from cybervisor.cli import _run_serve_command as _rsc

        return asyncio.run(_rsc(args))
    if args.command == "serve-sandbox":
        from cybervisor.cli import _run_serve_sandbox_command as _rssbc

        return _rssbc(args)
    if args.command == "status":
        return asyncio.run(_run_status_command(args))
    if args.command == "submit":
        from cybervisor.cli import _run_submit_command as _rsc

        logger = CybervisorLogger(quiet=args.quiet)
        args.prompt, prompt_source = _resolve_prompt(args)
        if prompt_source is None:
            logger.log_to_stderr("No prompt provided via argument or stdin.", "error")
            return 1
        if prompt_source == "stdin":
            logger.log_to_stderr("Objective source: stdin.", "info")
        else:
            logger.log_to_stderr("Objective source: positional prompt.", "info")
        return asyncio.run(_rsc(args))
    if args.command == "attach":
        from cybervisor.cli import _run_attach_command as _rac

        return asyncio.run(_rac(args))
    if args.command == "cancel":
        from cybervisor.cli import _run_cancel_command as _rcc

        return asyncio.run(_rcc(args))
    if args.command == "logs":
        from cybervisor.cli import _run_logs_command as _rlc

        return asyncio.run(_rlc(args))
    if args.command == "stop-stage":
        from cybervisor.cli import _run_stop_stage_command as _rssc

        return asyncio.run(_rssc(args))
    if args.command == "init":
        return run_init(template=args.template, force=args.force)
    if args.command == "doctor":
        return _run_doctor_command(args)
    if args.command == "validate":
        return _run_validate_command(args)
    if args.command == "docs":
        from cybervisor.cli import _run_docs_command_impl as _rdci

        return asyncio.run(_rdci(args))
    if args.command == "use":
        return _run_use_command(args)

    if args.command == "run":
        args.prompt, _ = _resolve_prompt(args)
        return _run_pipeline(args)

    return _run_pipeline(args)


if __name__ == "__main__":
    raise SystemExit(main())
