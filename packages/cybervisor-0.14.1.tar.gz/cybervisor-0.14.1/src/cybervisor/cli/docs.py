"""Docs document definitions and docs command implementation."""

from __future__ import annotations

import sys
from dataclasses import dataclass, field
from importlib.metadata import PackageNotFoundError, distribution
from pathlib import Path

__all__ = ["DocsDocument", "_resolve_docs_source_path", "_resolve_workspace_docs_source_path"]


@dataclass(frozen=True, slots=True)
class DocsDocument:
    identifier: str
    source_path: Path
    aliases: tuple[str, ...] = field(default_factory=lambda: ())
    replacement_for: tuple[str, ...] = field(default_factory=lambda: ())


_DOCS_DOCUMENTS: tuple[DocsDocument, ...] = (
    DocsDocument(identifier="config", source_path=Path("docs/configuration.md")),
    DocsDocument(
        identifier="updating",
        source_path=Path("docs/updating.md"),
        aliases=("update", "upgrade"),
    ),
    DocsDocument(
        identifier="pipeline-authoring",
        source_path=Path("docs/pipeline-authoring.md"),
        aliases=("pipeline", "cybervisor.yaml"),
        replacement_for=("config-authoring",),
    ),
)


def _docs_lookup() -> dict[str, DocsDocument]:
    lookup: dict[str, DocsDocument] = {}
    for document in _DOCS_DOCUMENTS:
        lookup[document.identifier] = document
        for alias in document.aliases:
            lookup[alias] = document
    return lookup


_DOCS_LOOKUP = _docs_lookup()


def _valid_docs_identifiers() -> str:
    return ", ".join(document.identifier for document in _DOCS_DOCUMENTS)


def _render_docs_usage() -> str:
    return f"Usage: cybervisor docs <document>\nValid documents: {_valid_docs_identifiers()}"


def _read_docs_source(document: DocsDocument) -> str:
    return _resolve_docs_source_path(document).read_text(encoding="utf-8")


def _resolve_workspace_docs_source_path(document: DocsDocument) -> Path | None:
    repo_root = Path(__file__).resolve().parents[3]
    workspace_path = repo_root / document.source_path
    if workspace_path.is_file():
        return workspace_path.resolve()
    return None


def _resolve_docs_source_path(document: DocsDocument) -> Path:
    # Look up from cybervisor.cli to support test monkeypatching of the
    # _resolve_workspace_docs_source_path re-export.
    from cybervisor.cli import _resolve_workspace_docs_source_path as _rwdssp

    workspace_path = _rwdssp(document)
    if workspace_path is not None:
        return workspace_path

    installed_data_path = Path(sys.prefix) / "share" / "cybervisor" / document.source_path
    if installed_data_path.is_file():
        return installed_data_path.resolve()

    installed_relative_path = Path("share/cybervisor") / document.source_path
    try:
        installed_distribution = distribution("cybervisor")
    except PackageNotFoundError as exc:
        raise FileNotFoundError(f"Unable to locate {document.source_path.as_posix()}.") from exc

    for package_file in installed_distribution.files or ():
        if Path(str(package_file)) != installed_relative_path:
            continue
        installed_path = Path(str(installed_distribution.locate_file(package_file)))
        if installed_path.is_file():
            return installed_path.resolve()

    raise FileNotFoundError(f"Unable to locate {document.source_path.as_posix()}.")


def _resolve_docs_document(requested: str) -> tuple[DocsDocument | None, str | None]:
    normalized = requested.strip().lower()
    document = _DOCS_LOOKUP.get(normalized)
    if document is not None:
        return document, None
    for candidate in _DOCS_DOCUMENTS:
        if normalized in candidate.replacement_for:
            return None, (
                f"Unknown document '{requested}'.\n"
                f"Use '{candidate.identifier}' instead.\n"
                f"{_render_docs_usage()}"
            )
    return None, f"Unknown document '{requested}'.\n{_render_docs_usage()}"


async def _run_docs_command(args: object, quiet: bool = False) -> int:
    from cybervisor.logging import CybervisorLogger

    logger = CybervisorLogger(quiet=quiet)
    args_ns = args

    if not getattr(args_ns, "document", None):
        logger.log_to_stderr(_render_docs_usage(), "error")
        return 1
    document, error_message = _resolve_docs_document(getattr(args_ns, "document"))
    if document is None:
        logger.log_to_stderr(error_message or _render_docs_usage(), "error")
        return 1
    try:
        source_path = _resolve_docs_source_path(document)
        contents = _read_docs_source(document)
    except FileNotFoundError as exc:
        logger.log_to_stderr(str(exc), "error")
        return 1
    print(f"SOURCE: {source_path}")
    print()
    print(contents, end="")
    return 0
