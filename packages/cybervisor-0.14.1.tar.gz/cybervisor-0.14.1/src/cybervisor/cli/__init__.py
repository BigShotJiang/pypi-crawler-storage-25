"""cybervisor.cli — CLI entry point and command implementations."""

from __future__ import annotations

import sys
from cybervisor.cli.commands import (
    StartupValidationError,
    _run_attach_command,
    _run_cancel_command,
    _run_docs_command_impl,
    _run_doctor_command,
    _run_logs_command,
    _run_pipeline,
    _run_serve_command,
    _run_serve_sandbox_command,
    _run_stop_stage_command,
    _run_submit_command,
    _run_use_command,
    _run_validate_command,
    _select_agent,
    _set_process_title,
    main,
    validate_stage_name_arg,
    validate_start_stage,
)
from cybervisor.cli.docs import (
    DocsDocument,
    _resolve_workspace_docs_source_path,
    _resolve_docs_source_path,
)
from cybervisor.cli.instance import (
    _check_single_instance,
    _instance_lock_path,
    _is_instance_alive,
    _process_group_file,
    _process_group_id,
    _process_id_file,
    _read_instance_lock,
    _remove_instance_lock,
    _remove_runtime_files,
    _runtime_dir,
    _write_instance_lock,
    _write_runtime_files,
)
from cybervisor.cli.parser import (
    _add_run_arguments,
    _prepare_argv,
    _resolve_prompt,
    build_parser,
    parse_args,
)
from cybervisor.client import _find_running_task_in_cwd, _resolve_config
from cybervisor.doctor import diagnose_global_llm_readiness
from cybervisor.hooks import inject_hooks, remove_hooks
from cybervisor.logging import HookEventListener
from cybervisor.pipeline import PipelineInterrupted, PipelineRunner
from cybervisor.preflight import run_preflight
from cybervisor.config import (
    load_config,
    validate_config_file,
    validate_prompt_templates,
)
from cybervisor.global_config import (
    load_global_config,
    update_global_agent_tool,
)

__all__ = [
    "DocsDocument",
    "HookEventListener",
    "PipelineInterrupted",
    "PipelineRunner",
    "StartupValidationError",
    "_add_run_arguments",
    "validate_stage_name_arg",
    "validate_start_stage",
    "_check_single_instance",
    "_find_running_task_in_cwd",
    "_instance_lock_path",
    "_is_instance_alive",
    "_prepare_argv",
    "_process_group_file",
    "_process_group_id",
    "_process_id_file",
    "_read_instance_lock",
    "_remove_instance_lock",
    "_remove_runtime_files",
    "_resolve_config",
    "_resolve_prompt",
    "_resolve_workspace_docs_source_path",
    "_resolve_docs_source_path",
    "_run_attach_command",
    "_run_cancel_command",
    "_run_docs_command_impl",
    "_run_doctor_command",
    "_run_logs_command",
    "_run_pipeline",
    "_run_serve_command",
    "_run_serve_sandbox_command",
    "_run_stop_stage_command",
    "_run_submit_command",
    "_run_use_command",
    "_run_validate_command",
    "_runtime_dir",
    "_select_agent",
    "_set_process_title",
    "_write_instance_lock",
    "_write_runtime_files",
    "build_parser",
    "diagnose_global_llm_readiness",
    "docs",
    "inject_hooks",
    "load_config",
    "load_global_config",
    "main",
    "parse_args",
    "remove_hooks",
    "run_preflight",
    "update_global_agent_tool",
    "validate_config_file",
    "validate_prompt_templates",
]


def __getattr__(name: str) -> object:
    if name == "docs":
        from cybervisor.cli import docs as _docs
        return _docs
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
