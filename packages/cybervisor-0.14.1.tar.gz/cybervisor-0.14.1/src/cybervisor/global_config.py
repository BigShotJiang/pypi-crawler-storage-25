from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from cybervisor._constants import DEFAULT_ENDPOINT, DEFAULT_MODEL, AgentToolType
from cybervisor.adapters.registry import supported_agent_names

__all__ = [
    "DEFAULT_AGENT_TOOL",
    "DEFAULT_ENDPOINT",
    "DEFAULT_MODEL",
    "AgentToolType",
    "CONFIG_DIR_NAME",
    "CONFIG_FILE_NAME",
    "GlobalConfigError",
    "GlobalConfig",
    "GlobalLLMConfig",
    "GlobalServerConfig",
    "_resolve_verifier_model",
    "_validate_agent_tool",
    "global_config_path",
    "_load_raw_config",
    "_load_stage_models",
    "load_global_config",
    "write_global_config",
    "update_global_agent_tool",
]

CONFIG_DIR_NAME = ".cybervisor"
CONFIG_FILE_NAME = "config.yaml"
DEFAULT_AGENT_TOOL: AgentToolType = "claude"


class GlobalConfigError(ValueError):
    """Raised when the global cybervisor config is invalid."""


@dataclass(slots=True)
class GlobalLLMConfig:
    api_key: str = ""
    base_url: str = DEFAULT_ENDPOINT
    model: str = DEFAULT_MODEL


@dataclass(slots=True)
class GlobalServerConfig:
    host: str = "127.0.0.1"
    port: int = 8765
    reconnect_ttl_seconds: float = 300.0
    max_event_buffer: int = 1000


@dataclass(slots=True)
class GlobalConfig:
    agent_tool: AgentToolType = DEFAULT_AGENT_TOOL
    llm: GlobalLLMConfig = field(default_factory=GlobalLLMConfig)
    server: GlobalServerConfig = field(default_factory=GlobalServerConfig)
    stage_models: dict[str, str] = field(default_factory=dict)


def _resolve_verifier_model(global_config: GlobalConfig) -> str:
    """Return the global verifier model (per-stage verifier models are no longer supported)."""
    return global_config.llm.model


def global_config_path(*, cwd: Path | None = None) -> Path:
    # Check for a workspace-local config first (`.cybervisor/config.yaml` in CWD).
    # This allows the smoke test and other automated runners to use an isolated
    # config without touching ~/.cybervisor/config.yaml.
    effective_cwd = cwd if cwd is not None else Path.cwd()
    cwd_config = effective_cwd / CONFIG_DIR_NAME / CONFIG_FILE_NAME
    if cwd_config.exists():
        return cwd_config
    return Path.home() / CONFIG_DIR_NAME / CONFIG_FILE_NAME


def _validate_agent_tool(value: object) -> AgentToolType:
    normalized = str(value).strip().lower()
    supported = supported_agent_names()
    if normalized not in supported:
        raise GlobalConfigError(
            f"Unsupported agent_tool: {value}. Supported values: {', '.join(sorted(supported))}"
        )
    return normalized  # type: ignore[return-value]


def _load_raw_config(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    loaded = yaml.safe_load(path.read_text(encoding="utf-8"))
    if loaded is None:
        return {}
    if not isinstance(loaded, dict):
        raise GlobalConfigError(f"Global config at {path} must be a YAML mapping")
    if not all(isinstance(key, str) for key in loaded):
        raise GlobalConfigError(f"Global config at {path} must use string keys")
    return dict(loaded)


def _load_stage_models(raw: object) -> dict[str, str]:
    """Parse stage_models from global config top-level section."""
    if raw is None:
        return {}
    if not isinstance(raw, dict):
        raise GlobalConfigError("stage_models must be a mapping")
    result: dict[str, str] = {}
    for key, value in raw.items():
        key_str = str(key).strip()
        if not key_str:
            raise GlobalConfigError("stage_models keys must be non-empty strings")
        value_str = str(value).strip() if value is not None else ""
        if not value_str:
            raise GlobalConfigError(f"stage_models['{key_str}'] must be a non-empty string")
        result[key_str] = value_str
    return result


def load_global_config(path: Path | None = None, *, cwd: Path | None = None) -> GlobalConfig:
    config_path = path or global_config_path(cwd=cwd)
    raw = _load_raw_config(config_path)
    llm_raw = raw.get("llm", {})
    if llm_raw is None:
        llm_raw = {}
    if not isinstance(llm_raw, dict):
        raise GlobalConfigError(f"Global config at {config_path} field 'llm' must be a mapping")

    server_raw = raw.get("server", {})
    if server_raw is None:
        server_raw = {}
    if not isinstance(server_raw, dict):
        raise GlobalConfigError(f"Global config at {config_path} field 'server' must be a mapping")

    # Emit deprecation warning if llm.stage_models is present
    if isinstance(llm_raw, dict) and "stage_models" in llm_raw:
        import sys

        deprecation_msg = (
            "llm.stage_models is deprecated; move stage_models to the top level. "
            "The llm.stage_models key is ignored."
        )
        logger = logging.getLogger(__name__)
        logger.warning(deprecation_msg)
        print(f"WARNING: {deprecation_msg}", file=sys.stderr)

    agent_tool_raw = raw.get("agent_tool", raw.get("agent", DEFAULT_AGENT_TOOL))
    def _safe_int(value: object, field_name: str) -> int:
        try:
            return int(value)  # type: ignore[call-overload, no-any-return]
        except (TypeError, ValueError):
            raise GlobalConfigError(f"Global config field '{field_name}' must be an integer, got {value!r}") from None

    def _safe_float(value: object, field_name: str) -> float:
        try:
            return float(value)  # type: ignore[arg-type]
        except (TypeError, ValueError):
            raise GlobalConfigError(f"Global config field '{field_name}' must be a number, got {value!r}") from None

    return GlobalConfig(
        agent_tool=_validate_agent_tool(agent_tool_raw),
        llm=GlobalLLMConfig(
            api_key=str(llm_raw.get("api_key") or ""),
            base_url=str(llm_raw.get("base_url") or DEFAULT_ENDPOINT),
            model=str(llm_raw.get("model") or DEFAULT_MODEL),
        ),
        server=GlobalServerConfig(
            host=str(server_raw.get("host", "127.0.0.1")),
            port=_safe_int(server_raw.get("port", 8765), "server.port"),
            reconnect_ttl_seconds=_safe_float(server_raw.get("reconnect_ttl_seconds", 300.0), "server.reconnect_ttl_seconds"),
            max_event_buffer=_safe_int(server_raw.get("max_event_buffer", 1000), "server.max_event_buffer"),
        ),
        stage_models=_load_stage_models(raw.get("stage_models")),
    )


def write_global_config(config: GlobalConfig, path: Path | None = None) -> Path:
    config_path = path or global_config_path()
    config_path.parent.mkdir(parents=True, exist_ok=True)
    data: dict[str, Any] = {
        "agent_tool": config.agent_tool,
        "llm": {
            "api_key": config.llm.api_key,
            "base_url": config.llm.base_url,
            "model": config.llm.model,
        },
        "server": {
            "host": config.server.host,
            "port": config.server.port,
            "reconnect_ttl_seconds": config.server.reconnect_ttl_seconds,
            "max_event_buffer": config.server.max_event_buffer,
        },
    }
    if config.stage_models:
        data["stage_models"] = config.stage_models
    content = yaml.safe_dump(data, sort_keys=False)
    fd = os.open(config_path, os.O_CREAT | os.O_WRONLY | os.O_TRUNC, 0o600)
    try:
        os.write(fd, content.encode("utf-8"))
    finally:
        os.close(fd)
    return config_path


def update_global_agent_tool(agent_tool: str, path: Path | None = None) -> tuple[AgentToolType, Path]:
    config_path = path or global_config_path()
    current = load_global_config(config_path)
    updated = GlobalConfig(agent_tool=_validate_agent_tool(agent_tool), llm=current.llm, server=current.server, stage_models=current.stage_models)
    written_path = write_global_config(updated, config_path)
    return updated.agent_tool, written_path
