"""Message handlers and task execution for the daemon server."""

from __future__ import annotations

import asyncio
import json
import logging
import os
import signal
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from websockets.asyncio.server import ServerConnection

from cybervisor.adapters.base import AgentAdapter
from cybervisor.adapters.registry import get_adapter
from cybervisor.config import load_config
from cybervisor.global_config import GlobalConfig
from cybervisor.hooks import hook_socket_path, inject_hooks, remove_hooks
from cybervisor.logging import CybervisorLogger, HookEventListener
from cybervisor.pipeline import EndStageRef, PipelineInterrupted, PipelineRunner
from cybervisor.server_events import (
    EventType,
    ServerEvent,
    artifact_validated,
    chunk_payload,
    error,
    event_replay,
    pipeline_abort,
    pong,
    routing_decision,
    run_complete,
    run_accepted,
    stage_complete,
    stage_failed,
    stage_retry,
    stage_start,
    stop_stage_updated,
)
from cybervisor.server.daemon import DEFAULT_CONFIG_PATH, DaemonConfig, DaemonServer
from cybervisor.server._path import _normalize_workspace_config_path
from cybervisor.server.tasks import DeliverySuppressedError, StaleExecutionError, TaskState, TaskRegistry
from cybervisor.server._cleanup import _cleanup_abandoned_tasks
from cybervisor.server_signals import ServerSignalHandler
from cybervisor.signals import SignalHandler
from cybervisor.skills import move_disabled_skills, restore_all_skills, restore_skills

_logger = logging.getLogger(__name__)

__all__ = [
    "_cleanup_abandoned_tasks",
    "_clear_live_connection",
    "_execute_task",
    "_handle_cancel",
    "_handle_pong",
    "_handle_resume",
    "_handle_run",
    "_handle_set_stop_stage",
    "_normalize_workspace_config_path",
    "_run_pipeline_sync",
    "_send_error",
]



async def _send_error(websocket: Any, task_id: str, code: str, message: str) -> None:
    """Send an error event to the WebSocket."""
    await websocket.send(error(task_id, code, message).to_json())


async def _handle_pong(websocket: Any, task_snapshots: list[dict[str, Any]]) -> None:
    """Handle a pong response with task snapshots."""
    await websocket.send(pong(tasks=task_snapshots).to_json())


async def _clear_live_connection(server: DaemonServer, websocket: ServerConnection, task_id: str | None) -> None:
    """Clear the live websocket reference when a client disconnects."""
    if task_id is None:
        return
    task_state = await server._registry.get_task(task_id)
    if task_state is None:
        return
    async with task_state._connection_lock:
        if task_state.live_websocket is websocket:
            task_state.live_websocket = None
            task_state.connection_generation += 1
    await server._registry.update_last_activity(task_id)


async def _handle_run(
    server: DaemonServer,
    websocket: Any,
    message: dict[str, Any],
) -> None:
    """Handle a run request."""
    # Check if a task is already in progress
    if await server._registry.has_active_task():
        await _send_error(websocket, "", "task_in_progress", "A task is already in progress")
        return

    task_id = message.get("task_id")
    if not isinstance(task_id, str) or not task_id.strip():
        await _send_error(websocket, "", "invalid_message", "Missing required string field: task_id")
        return
    task_id = task_id.strip()

    prompt = message.get("prompt")
    if not isinstance(prompt, str) or not prompt.strip():
        await _send_error(websocket, task_id, "invalid_message", "Missing required string field: prompt")
        return
    prompt = prompt.strip()

    config_path = message.get("config", DEFAULT_CONFIG_PATH)
    if not isinstance(config_path, str) or not config_path.strip():
        await _send_error(websocket, task_id, "invalid_message", "config must be a non-empty string when provided")
        return
    normalized_config_path = _normalize_workspace_config_path(config_path)
    if normalized_config_path is None:
        await _send_error(websocket, task_id, "invalid_message", "config must stay within the workspace using a relative path")
        return
    config_path = normalized_config_path

    start_stage = message.get("start_stage")
    if start_stage is not None:
        if not isinstance(start_stage, str) or not start_stage.strip():
            await _send_error(websocket, task_id, "invalid_message", "start_stage must be a non-empty string when provided")
            return
        start_stage = start_stage.strip()

    end_stage = message.get("end_stage")
    if end_stage is not None:
        if not isinstance(end_stage, str) or not end_stage.strip():
            await _send_error(websocket, task_id, "invalid_message", "end_stage must be a non-empty string when provided")
            return
        end_stage = end_stage.strip()

    end_before = message.get("end_before")
    if end_before is not None:
        if not isinstance(end_before, str) or not end_before.strip():
            await _send_error(websocket, task_id, "invalid_message", "end_before must be a non-empty string when provided")
            return
        end_before = end_before.strip()

    # Validate mutual exclusivity of end_stage and end_before
    if end_stage is not None and end_before is not None:
        await _send_error(websocket, task_id, "mutually_exclusive_end_stage", "end_stage and end_before cannot be used together")
        return

    # Read cwd from message (sent by submitting CLI, not daemon's cwd)
    cwd = message.get("cwd", "")

    # Check for nested task in same CWD
    if cwd and await server._registry.has_active_task_in_cwd(cwd):
        await _send_error(websocket, task_id, "nested_task_rejected", "A task is already running in this directory")
        return

    try:
        task_config = load_config(config_path)
        valid_stage_names = frozenset(stage.name for stage in task_config.stages)
    except Exception:
        logging.error("Failed to load config from %s", config_path, exc_info=True)
        await _send_error(websocket, task_id, "invalid_message", f"Failed to load config from {config_path}")
        return

    if start_stage is not None and start_stage not in valid_stage_names:
        await _send_error(websocket, task_id, "invalid_message", f"Unknown start_stage: '{start_stage}'")
        return
    if end_stage is not None and end_stage not in valid_stage_names:
        await _send_error(websocket, task_id, "invalid_message", f"Unknown end_stage: '{end_stage}'")
        return
    if end_before is not None and end_before not in valid_stage_names:
        await _send_error(websocket, task_id, "invalid_message", f"Unknown end_before: '{end_before}'")
        return

    try:
        task_state = await server._registry.create_task(task_id, config_path, prompt, start_stage)
        task_state.cwd = os.path.realpath(cwd) if cwd else os.getcwd()
        task_state.end_stage = end_stage
        task_state.end_before = end_before
        task_state.valid_stage_names = valid_stage_names
    except ValueError:
        await _send_error(websocket, task_id, "task_in_progress", "Task already exists")
        return

    task_state.live_websocket = websocket

    # Send run_accepted
    await server._deliver_task_event(task_state, run_accepted(task_id))

    # Execute the task in background
    run_task = asyncio.create_task(_execute_task(server, server.global_config, server.logger, task_state))
    task_state.run_task = run_task
    server._background_tasks.add(run_task)
    run_task.add_done_callback(server._background_tasks.discard)


async def _handle_set_stop_stage(
    server: DaemonServer,
    websocket: Any,
    message: dict[str, Any],
) -> None:
    """Handle a set_stop_stage request."""
    task_id = message.get("task_id")

    # If no task_id provided, find running task(s) in the current CWD (from message)
    current_cwd = message.get("cwd", "")
    if task_id is None or task_id == "":
        if current_cwd:
            running_in_cwd: list[TaskState] = []
            all_task_ids = await server._registry.get_task_ids()
            for tid in all_task_ids:
                ts = await server._registry.get_task(tid)
                if ts is not None and not ts.completed and not ts.cancelled and os.path.realpath(ts.cwd) == os.path.realpath(current_cwd):
                    running_in_cwd.append(ts)
            if len(running_in_cwd) == 0:
                await _send_error(websocket, "", "unknown_task", "No active task to set stop stage for.")
                return
            if len(running_in_cwd) > 1:
                await _send_error(
                    websocket, "", "multiple_tasks",
                    "Multiple tasks are running in this directory. Use 'cybervisor stop-stage <task-id> --stage <stage>' to target a specific task."
                )
                return
            task_id = running_in_cwd[0].task_id
        else:
            await _send_error(websocket, "", "invalid_message", "Missing task_id")
            return
    elif isinstance(task_id, str):
        task_id = task_id.strip()
        if not task_id:
            await _send_error(websocket, "", "invalid_message", "Missing required string field: task_id")
            return
    else:
        await _send_error(websocket, "", "invalid_message", "Invalid task_id field: must be a string or omitted")
        return

    stage = message.get("stage")
    if not isinstance(stage, str) or not stage.strip():
        await _send_error(websocket, task_id, "invalid_message", "Missing required string field: stage")
        return
    stage = stage.strip()

    task_state = await server._registry.get_task(task_id)
    if task_state is None:
        await _send_error(websocket, task_id, "unknown_task", "Task not found")
        return

    if task_state.completed:
        await _send_error(websocket, task_id, "invalid_message", "Task already completed")
        return

    if stage not in task_state.valid_stage_names:
        await _send_error(websocket, task_id, "invalid_message", f"Unknown stage: {stage}")
        return

    # Update the end stage ref for dynamic mid-pipeline stop stage changes
    if task_state.end_stage_ref is not None:
        task_state.end_stage_ref.set(stage)
    await server._registry.update_last_activity(task_id)
    await server._deliver_task_event(task_state, stop_stage_updated(task_id, stage))


async def _handle_cancel(
    server: DaemonServer,
    websocket: Any,
    message: dict[str, Any],
) -> None:
    """Handle a cancel request."""
    task_id = message.get("task_id")

    # If no task_id provided, find running task(s) in the current CWD (from message)
    current_cwd = message.get("cwd", "")
    if task_id is None or task_id == "":
        if current_cwd:
            # Find running tasks in same CWD
            running_in_cwd: list[TaskState] = []
            all_task_ids = await server._registry.get_task_ids()
            for tid in all_task_ids:
                ts = await server._registry.get_task(tid)
                if ts is not None and not ts.completed and not ts.cancelled and os.path.realpath(ts.cwd) == os.path.realpath(current_cwd):
                    running_in_cwd.append(ts)
            if len(running_in_cwd) == 0:
                await _send_error(websocket, "", "unknown_task", "No active task to cancel.")
                return
            if len(running_in_cwd) > 1:
                await _send_error(
                    websocket, "", "multiple_tasks",
                    "Multiple tasks are running in this directory. Use 'cybervisor cancel <task-id>' to target a specific task."
                )
                return
            task_id = running_in_cwd[0].task_id
        else:
            await _send_error(websocket, "", "invalid_message", "Missing task_id")
            return

    if not isinstance(task_id, str):
        await _send_error(websocket, "", "invalid_message", "Invalid task_id field: must be a string or omitted")
        return

    task_state = await server._registry.get_task(task_id)
    if task_state is None:
        await _send_error(websocket, task_id or "", "unknown_task", "Task not found")
        return

    # Check if task is in a cancellable state
    if task_state.completed or task_state.cancelled:
        await _send_error(websocket, task_id, "not_cancellable", "Task is not in a cancellable state")
        return

    # Deliver SIGINT to interrupt the active subprocess
    task_state.cancel_event.set()
    with task_state._state_lock:
        task_state.cancelled = True
        task_state.abort_sent = True
    if task_state.server_signal_handler is not None:
        task_state.server_signal_handler._signal_handler.interrupted = True
        await task_state.server_signal_handler.deliver_signal(signal.SIGINT)

    evt = pipeline_abort(task_id, "cancelled_by_client", task_state.active_stage)
    await task_state.events.append_async(evt)
    await server._send_to_websocket(websocket, evt)


async def _handle_resume(
    server: DaemonServer,
    websocket: Any,
    message: dict[str, Any],
) -> None:
    """Handle a resume request (reconnect and replay events)."""
    task_id = message.get("task_id")
    if not isinstance(task_id, str):
        await _send_error(websocket, "", "invalid_message", "Missing or invalid task_id")
        return

    if not task_id:
        await _send_error(websocket, "", "invalid_message", "Missing task_id")
        return

    task_state = await server._registry.get_task(task_id)
    if task_state is None:
        await _send_error(websocket, task_id, "unknown_task", "Task not found or TTL expired")
        return

    await server._switch_live_connection(task_state, websocket)


async def _execute_task(
    server: DaemonServer,
    global_config: GlobalConfig,
    logger: CybervisorLogger,
    task_state: TaskState,
) -> None:
    """Execute a task using the PipelineRunner."""
    from cybervisor.preflight import run_preflight

    task_id = task_state.task_id
    execution_generation = task_state.execution_generation
    await server._registry.update_last_activity(task_id)
    hook_listener: HookEventListener | None = None
    hooks_installed = False
    moved_skills: list[tuple[Path, Path]] = []

    try:
        try:
            config = load_config(task_state.config_path)
        except FileNotFoundError as exc:
            await server._finalize_task_failure(task_state, "server_error", f"Config not found: {exc}")
            return

        try:
            agent_tool = global_config.agent_tool
        except AttributeError as exc:
            logging.error("Failed to resolve agent: %s", exc, exc_info=True)
            await server._finalize_task_failure(task_state, "server_error", f"Failed to resolve agent: {exc}")
            return

        # Recover skills from any previous unclean shutdown.
        restore_all_skills()

        agent: AgentAdapter = get_adapter(agent_tool)

        # Move disabled project-local skills before the pipeline starts.
        moved_skills = move_disabled_skills(
            agent.descriptor.name,
            agent.project_skills_dir(),
            config.disabled_skills,
        )

        preflight_errors = run_preflight(agent_tool, config)
        if preflight_errors:
            restore_skills(moved_skills)
            await server._finalize_task_failure(task_state, "server_error", f"Preflight failed: {preflight_errors[0]}")
            return

        task_logger = CybervisorLogger()
        signal_handler = SignalHandler(task_logger, log_file=".cybervisor/logs/cybervisor.log.jsonl")
        server_signal_handler = ServerSignalHandler(signal_handler)
        server_signal_handler.set_cancel_event(task_state.cancel_event)
        task_state.server_signal_handler = server_signal_handler
        if agent.descriptor.capabilities.supports_hooks:
            try:
                hook_listener = HookEventListener(task_logger, socket_path=hook_socket_path())
                hook_listener.start()
                inject_hooks(agent_tool, config.hook)
                hooks_installed = True
            except Exception:
                logging.error("Hook installation failed", exc_info=True)
                if hook_listener is not None:
                    hook_listener.stop()
                restore_skills(moved_skills)
                raise

        _loop = asyncio.get_running_loop()

        stage_models = global_config.stage_models if global_config.stage_models else None

        def stage_event_callback(event: dict[str, Any]) -> None:
            with task_state._state_lock:
                if task_state.abort_sent:
                    return
            event_type = event.get("event_type")
            if event_type == "stage_start":
                task_state.active_stage = event["stage_name"]
                evt = stage_start(
                    task_id,
                    event["stage_name"],
                    event["attempt"],
                    event["max_retries"],
                    iteration_count=event.get("iteration_count"),
                    max_iterations=event.get("max_iterations"),
                )
            elif event_type == "stage_complete":
                evt = stage_complete(task_id, event["stage_name"], event["success"], event["attempt"])
            elif event_type == "stage_retry":
                evt = stage_retry(task_id, event["stage_name"], event["attempt"], event["max_retries"], event["error"])
            elif event_type == "stage_failed":
                evt = stage_failed(task_id, event["stage_name"], event["attempt"], event["error"])
            elif event_type == "artifact_validated":
                evt = artifact_validated(task_id, event["stage_name"], event["artifact_status"])
            elif event_type == "routing_decision":
                evt = routing_decision(task_id, event["stage_name"], event["next_stage"], event["decision_source"])
            else:
                return
            future = asyncio.run_coroutine_threadsafe(
                server._deliver_task_event(
                    task_state,
                    evt,
                    suppress_if_aborted=True,
                    expected_generation=execution_generation,
                ),
                _loop,
            )

            def _consume_result(done_future: Any) -> None:
                try:
                    done_future.result()
                except (DeliverySuppressedError, StaleExecutionError):
                    pass

            future.add_done_callback(_consume_result)

            # Update last activity to prevent abandoned task cleanup during stage execution
            asyncio.run_coroutine_threadsafe(
                server._registry.update_last_activity(task_id),
                _loop,
            )

        loop = asyncio.get_running_loop()
        success = await loop.run_in_executor(
            None,
            _run_pipeline_sync,
            task_state,
            task_state.prompt,
            config.stages,
            agent,
            task_logger,
            signal_handler,
            task_state.start_stage,
            task_state.end_stage_ref,
            stage_event_callback,
            hook_listener,
            task_state.end_before,
            stage_models,
        )

        if execution_generation != task_state.execution_generation:
            return

        if task_state.cancel_event.is_set():
            task_state.completed = True
            task_state.success = False
            with task_state._state_lock:
                should_send_abort = not task_state.abort_sent
            if should_send_abort:
                abort_evt = pipeline_abort(task_id, "cancelled_by_client", task_state.active_stage)
                await server._deliver_task_event(task_state, abort_evt)
            await asyncio.sleep(0)
            complete_evt = run_complete(task_id, False)
            await server._deliver_task_event(task_state, complete_evt)
            task_state.live_websocket = None
            await server._registry.remove_task(task_id)
            return

        task_state.completed = True
        task_state.success = success
        evt = run_complete(task_id, success)
        await server._deliver_task_event(task_state, evt)
        task_state.live_websocket = None
        await server._registry.remove_task(task_id)

    except PipelineInterrupted:
        if execution_generation != task_state.execution_generation:
            return
        task_state.completed = True
        task_state.success = False
        with task_state._state_lock:
            should_send_abort = not task_state.abort_sent
        if should_send_abort:
            abort_evt = pipeline_abort(task_id, "interrupted", task_state.active_stage)
            await server._deliver_task_event(task_state, abort_evt)
        complete_evt = run_complete(task_id, False)
        await server._deliver_task_event(task_state, complete_evt)
        task_state.live_websocket = None
        await server._registry.remove_task(task_id)
    except Exception as exc:
        logging.error("Task execution failed", exc_info=True)
        if execution_generation != task_state.execution_generation:
            return
        await server._finalize_task_failure(task_state, "server_error", str(exc))
    finally:
        if hook_listener is not None:
            hook_listener.stop()
        if hooks_installed:
            try:
                restore_result = remove_hooks(agent_tool)
                logger.log_to_json(
                    task_logger.make_entry(
                        "system",
                        "Cleanup",
                        "Removed runtime hooks",
                        cleanup_result=restore_result,
                    ),
                    ".cybervisor/logs/cybervisor.log.jsonl",
                )
            except Exception as exc:
                logging.error("Failed to remove runtime hooks: %s", exc, exc_info=True)
        restore_skills(moved_skills)
        await server._detach_execution(task_state, execution_generation)


def _run_pipeline_sync(
    task_state: Any,
    prompt: str,
    stages: list[Any],  # StageConfig list
    agent: AgentAdapter,
    task_logger: CybervisorLogger,
    signal_handler: SignalHandler,
    start_stage_name: str | None,
    end_stage_ref: EndStageRef | None = None,
    stage_event_callback: Any = None,
    hook_listener: HookEventListener | None = None,
    end_before_stage_name: str | None = None,
    stage_models: dict[str, str] | None = None,
) -> bool:
    """Synchronous wrapper to run PipelineRunner in executor."""
    if task_state.cancel_event.is_set():
        raise PipelineInterrupted("", 0)
    runner = PipelineRunner()
    try:
        result = runner.run(
            prompt,
            stages,
            agent,
            task_logger,
            signal_handler=signal_handler,
            start_stage_name=start_stage_name,
            end_stage_ref=end_stage_ref,
            stage_event_callback=stage_event_callback,
            hook_listener=hook_listener,
            end_before_stage_name=end_before_stage_name,
            stage_models=stage_models,
        )
    except PipelineInterrupted:
        return False
    if task_state.cancel_event.is_set():
        raise PipelineInterrupted("", 0)
    return result

