"""Task state, registry, and ring buffer for the daemon server."""

from __future__ import annotations

import asyncio
import os
import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from websockets.asyncio.server import ServerConnection

from cybervisor.pipeline import EndStageRef
from cybervisor.server_events import ServerEvent
from cybervisor.server_signals import ServerSignalHandler


class EventRingBuffer:
    """Thread-safe fixed-size ring buffer for server events."""

    def __init__(self, capacity: int, *, _initial_events: list[ServerEvent] | None = None) -> None:
        self._capacity = capacity
        self._buffer: list[ServerEvent] = list(_initial_events) if _initial_events is not None else []
        self._lock = asyncio.Lock()

    @classmethod
    def from_events(cls, capacity: int, events: list[ServerEvent]) -> EventRingBuffer:
        """Construct a buffer pre-loaded with events, respecting capacity."""
        initial = events[-capacity:] if len(events) > capacity else list(events)
        return cls(capacity, _initial_events=initial)

    async def append_async(self, event: ServerEvent) -> None:
        """Async append for use from async context."""
        async with self._lock:
            if len(self._buffer) >= self._capacity:
                self._buffer.pop(0)
            self._buffer.append(event)

    async def get_all_async(self) -> list[ServerEvent]:
        """Async get_all for use from async context."""
        async with self._lock:
            return list(self._buffer)

    def __len__(self) -> int:
        return len(self._buffer)


@dataclass(slots=True)
class TaskState:
    """Holds the state of an active task."""

    task_id: str
    config_path: str
    prompt: str
    start_stage: str | None
    cancel_event: asyncio.Event
    valid_stage_names: frozenset[str] = field(default_factory=frozenset)
    end_stage_ref: EndStageRef | None = None
    cancelled: bool = False
    completed: bool = False
    success: bool = False
    events: EventRingBuffer = field(default_factory=lambda: EventRingBuffer(1000))
    last_activity: datetime = field(default_factory=lambda: datetime.now(tz=timezone.utc))
    active_stage: str | None = None
    attempt: int = 0
    server_signal_handler: ServerSignalHandler | None = None
    abort_sent: bool = False  # Tracks if pipeline_abort was already sent by _handle_cancel
    _state_lock: threading.Lock = field(default_factory=threading.Lock)
    live_websocket: ServerConnection | None = None
    connection_generation: int = 0
    execution_generation: int = 0
    run_task: asyncio.Task[None] | None = None
    cwd: str = ""  # Working directory of the task (from RUN message, not daemon's cwd)
    end_stage: str | None = None
    end_before: str | None = None
    # Set by _switch_live_connection after _run_resume_replay completes; signals
    # to _handle_connection's idle loop that no more live events will arrive so
    # the loop exits promptly (deadlock fix for completed-task RESUME with chunks).
    _no_more_live_events: bool = False
    _connection_lock: asyncio.Lock = field(default_factory=asyncio.Lock)


class StaleExecutionError(RuntimeError):
    """Raised when a superseded task execution attempts to emit live events."""


class DeliverySuppressedError(RuntimeError):
    """Raised when a task event should be buffered but not delivered live."""


class TaskRegistry:
    """Manages active tasks by task_id."""

    def __init__(self, max_event_buffer: int = 1000) -> None:
        self._tasks: dict[str, TaskState] = {}
        self._lock = asyncio.Lock()
        self._max_event_buffer = max_event_buffer

    async def create_task(
        self,
        task_id: str,
        config_path: str,
        prompt: str,
        start_stage: str | None = None,
    ) -> TaskState:
        async with self._lock:
            if task_id in self._tasks:
                raise ValueError(f"Task {task_id} already exists")
            cancel_event = asyncio.Event()
            end_stage_ref = EndStageRef()
            task_state = TaskState(
                task_id=task_id,
                config_path=config_path,
                prompt=prompt,
                start_stage=start_stage,
                cancel_event=cancel_event,
                end_stage_ref=end_stage_ref,
                events=EventRingBuffer(self._max_event_buffer),
            )
            task_state.execution_generation = 1
            self._tasks[task_id] = task_state
            return task_state

    async def get_task(self, task_id: str) -> TaskState | None:
        async with self._lock:
            return self._tasks.get(task_id)

    async def remove_task(self, task_id: str) -> None:
        async with self._lock:
            self._tasks.pop(task_id, None)

    async def get_task_ids(self) -> list[str]:
        async with self._lock:
            return list(self._tasks.keys())

    async def has_active_task(self) -> bool:
        async with self._lock:
            return any(not task.completed for task in self._tasks.values())

    async def has_active_task_in_cwd(self, cwd: str) -> bool:
        async with self._lock:
            def _resolve(p: str) -> str:
                try:
                    return os.path.realpath(p)
                except OSError:
                    return p

            return any(
                not task.completed and not task.cancelled
                and _resolve(task.cwd) == _resolve(cwd)
                for task in self._tasks.values()
            )

    async def update_last_activity(self, task_id: str) -> None:
        async with self._lock:
            if task_id in self._tasks:
                self._tasks[task_id].last_activity = datetime.now(tz=timezone.utc)

    async def cleanup_abandoned(self, ttl_seconds: float) -> list[str]:
        """Remove tasks abandoned for longer than ttl_seconds. Returns removed task_ids.

        Removes tasks that are completed or cancelled. Also detects running tasks
        whose backing asyncio task (or subprocess) has terminated unexpectedly and
        cancels them so they become eligible for TTL-based removal on the next cycle.
        """
        from cybervisor.server.daemon import _is_pid_running

        removed: list[str] = []
        now = datetime.now(tz=timezone.utc)
        async with self._lock:
            for task_id, task in list(self._tasks.items()):
                if not task.completed and not task.cancelled:
                    # Detect running tasks whose asyncio task has finished without
                    # updating the task state, or whose subprocess PID is dead.
                    is_dead = False
                    if task.run_task is not None and task.run_task.done():
                        is_dead = True
                    task_pid = None
                    if task.server_signal_handler is not None:
                        task_pid = task.server_signal_handler.pid
                    if task_pid is not None and not _is_pid_running(task_pid):
                        is_dead = True
                    if is_dead:
                        task.cancelled = True
                        task.last_activity = now
                    continue
                elapsed = (now - task.last_activity).total_seconds()
                if elapsed > ttl_seconds:
                    removed.append(task_id)
            for task_id in removed:
                del self._tasks[task_id]
        return removed

    async def to_dict(self) -> dict[str, Any]:
        """Serialize the registry to a dict for persistence. Returns all task state."""
        async with self._lock:
            result: dict[str, Any] = {"tasks": {}, "max_event_buffer": self._max_event_buffer}
            for task_id, task in self._tasks.items():
                events = await task.events.get_all_async()
                events_data: list[dict[str, Any]] = [event.to_dict() for event in events]
                result["tasks"][task_id] = {
                    "task_id": task.task_id,
                    "config_path": task.config_path,
                    "prompt": task.prompt,
                    "start_stage": task.start_stage,
                    "cancelled": task.cancelled,
                    "completed": task.completed,
                    "success": task.success,
                    "active_stage": task.active_stage,
                    "attempt": task.attempt,
                    "valid_stage_names": list(task.valid_stage_names),
                    "events": events_data,
                }
            return result

    @classmethod
    async def from_dict(cls, data: dict[str, Any], max_event_buffer: int | None = None) -> TaskRegistry:
        """Reconstruct a TaskRegistry from a serialized dict."""
        buf_size = max_event_buffer if max_event_buffer is not None else data.get("max_event_buffer", 1000)
        registry = cls(max_event_buffer=buf_size)
        tasks_data: dict[str, Any] = data.get("tasks", {})

        for task_id, task_data in tasks_data.items():
            # Re-create asyncio primitives for runtime state
            cancel_event = asyncio.Event()
            if task_data.get("cancelled", False):
                cancel_event.set()
            end_stage_ref = EndStageRef()
            # Restore events from serialized data
            events_list: list[dict[str, Any]] = task_data.get("events", [])
            restored_events = [ServerEvent.from_dict(e) for e in events_list]
            event_ring = EventRingBuffer.from_events(buf_size, restored_events)

            task_state = TaskState(
                task_id=task_data["task_id"],
                config_path=task_data["config_path"],
                prompt=task_data["prompt"],
                start_stage=task_data.get("start_stage"),
                cancel_event=cancel_event,
                valid_stage_names=frozenset(task_data.get("valid_stage_names", [])),
                end_stage_ref=end_stage_ref,
                cancelled=task_data.get("cancelled", False),
                completed=task_data.get("completed", False),
                success=task_data.get("success", False),
                events=event_ring,
                active_stage=task_data.get("active_stage"),
                attempt=task_data.get("attempt", 0),
            )
            registry._tasks[task_id] = task_state
        return registry
