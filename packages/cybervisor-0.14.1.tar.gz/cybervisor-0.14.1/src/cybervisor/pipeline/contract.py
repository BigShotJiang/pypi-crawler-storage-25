"""Stage contract validation, artifact processing, and prompt rendering helpers."""

from __future__ import annotations

import re
import string
from pathlib import Path
from typing import Any, Mapping

import yaml

from cybervisor.config import (
    StageConfig,
    StageContractConfig,
    StageRouteConfig,
    _display_field_name,
    contract_artifact_path,
)


def _render_prompt(template: str, context: Mapping[str, str]) -> tuple[str, set[str]]:
    formatter = string.Formatter()
    missing_keys: set[str] = set()
    for _literal_text, field_name, _format_spec, _conversion in formatter.parse(template):
        if field_name and field_name not in context:
            missing_keys.add(field_name)

    safe_context: dict[str, str] = dict(context)
    for key in missing_keys:
        safe_context[key] = ""
    return template.format_map(safe_context), missing_keys


def _normalized_artifact_payload(payload: dict[str, object]) -> dict[str, object]:
    normalized = dict(payload)
    if "Status" in normalized and "status" not in normalized:
        normalized["status"] = normalized["Status"]
        del normalized["Status"]
    return normalized


def _artifact_status_value(payload: dict[str, object]) -> str | None:
    normalized = _normalized_artifact_payload(payload)
    status = normalized.get("status")
    return status if isinstance(status, str) else None


def _resolve_contract_status(contract: StageContractConfig, payload_status: str) -> str | None:
    if payload_status in contract.routes:
        return payload_status

    normalized_status = payload_status.strip().casefold()
    for allowed_status in contract.allowed_statuses:
        if allowed_status.strip().casefold() == normalized_status:
            return allowed_status
    return None


def _validate_stage_artifact(stage_name: str, contract: StageContractConfig) -> tuple[dict[str, object] | None, str | None]:
    from cybervisor.pipeline.artifacts import _artifact_file_path as _afp

    artifact_path = _afp(stage_name)
    try:
        artifact_path.relative_to(Path.cwd().resolve())  # type: ignore[unused-ignore]
    except ValueError:
        return None, "artifact_path must stay within the working directory"

    if not artifact_path.exists():
        return None, f"required artifact missing at {artifact_path}"

    try:
        payload = yaml.safe_load(artifact_path.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        return None, f"artifact at {artifact_path} is not valid YAML ({exc})"

    if not isinstance(payload, dict):
        return None, f"artifact at {artifact_path} must contain a YAML mapping"

    status = _artifact_status_value(payload)
    if not isinstance(status, str):
        return None, f"artifact Status must be one of {', '.join(contract.allowed_statuses)}"
    resolved_status = _resolve_contract_status(contract, status)
    if resolved_status is None:
        return None, f"artifact Status must be one of {', '.join(contract.allowed_statuses)}"
    route = contract.routes.get(resolved_status)
    if route is not None:
        for field_name in route.injections:
            field_value = payload.get(field_name)
            if not isinstance(field_value, str) or not field_value.strip():
                return None, f"artifact field '{field_name}' must be a non-empty string"
        allowed_fields = {"Status", "status", *route.injections}
        unexpected_fields = [
            field_name
            for field_name, field_value in payload.items()
            if field_name not in allowed_fields and isinstance(field_value, str) and field_value.strip()
        ]
        if unexpected_fields:
            rendered_fields = ", ".join(unexpected_fields)
            return None, f"artifact has unexpected fields for status '{resolved_status}': {rendered_fields}"

    return payload, None


def _stringify_context_value(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    return yaml.safe_dump(value, sort_keys=False).rstrip()


def _stage_context_key(stage_name: str) -> str:
    return stage_name.lower().replace(" ", "_")


def _artifact_field_context_key(field_name: str) -> str:
    normalized = re.sub(r"[^a-z0-9]+", "_", field_name.strip().lower()).strip("_")
    return normalized or "field"


def _format_injected_contract_value(field_name: str, value: str) -> str:
    stripped = value.strip()
    if not stripped:
        return ""
    heading = f"**{_display_field_name(field_name)}**"
    if stripped.startswith(heading):
        return stripped
    return f"{heading}\n{stripped}"


def _stage_log_path(stage_name: str) -> str:
    return f".cybervisor/logs/stages/{stage_name}.jsonl"


def _artifact_output_sections(
    artifact_payload: dict[str, object],
    route: StageRouteConfig | None,
) -> list[tuple[str, str]]:
    seen: set[str] = {"status", "Status"}
    ordered_fields: list[str] = []
    if route is not None:
        for field_name in route.injections:
            if field_name in artifact_payload and field_name not in seen:
                ordered_fields.append(field_name)
                seen.add(field_name)

    for field_name in sorted(artifact_payload):
        if field_name in seen:
            continue
        value = artifact_payload[field_name]
        if isinstance(value, str) and value.strip():
            ordered_fields.append(field_name)
            seen.add(field_name)

    rendered: list[tuple[str, str]] = []
    for field_name in ordered_fields:
        value = artifact_payload.get(field_name)
        if not isinstance(value, str) or not value.strip():
            continue
        rendered.append((field_name, value.strip()))
    return rendered


def _format_contract_artifact_output(
    stage_name: str,
    artifact_payload: dict[str, object],
    route: StageRouteConfig | None = None,
) -> str:
    def _append_indented(lines: list[str], value: str) -> None:
        for line in value.splitlines():
            lines.append(f"  {line}")

    lines = [f"[{stage_name}] Contract artifact output: {contract_artifact_path(stage_name)}", ""]
    status = artifact_payload.get("Status")
    if not isinstance(status, str) or not status.strip():
        status = artifact_payload.get("status")
    if isinstance(status, str) and status.strip():
        lines.append(f"  Status: {status.strip()}")
        lines.append("")

    for field_name, value in _artifact_output_sections(artifact_payload, route):
        _append_indented(lines, _format_injected_contract_value(field_name, value))
        lines.append("")

    while lines and lines[-1] == "":
        lines.pop()
    return "\n".join(lines) + "\n"
