"""Artifact path, backup, cleanup, and reset helpers."""

from __future__ import annotations

import shutil
import time
from datetime import datetime, timezone
from pathlib import Path

from cybervisor.config import CONTRACT_ARTIFACTS_DIR, contract_artifact_path
from cybervisor.logging import CybervisorLogger


def _artifact_file_path(stage_name: str) -> Path:
    return (Path.cwd() / contract_artifact_path(stage_name)).resolve()


def _artifact_runtime_root() -> Path:
    return (Path.cwd() / ".cybervisor/artifacts").resolve()


def _backup_stage_artifacts(
    stage_name: str,
    backup_artifacts: list[str],
    logger: CybervisorLogger,
    log_file: str,
    cwd: Path | None = None,
    timestamp: str | None = None,
) -> None:
    """Backup stage artifacts to .cybervisor/backups/<stage_name>/<timestamp>/.

    Args:
        stage_name: Name of the stage being backed up.
        backup_artifacts: List of artifact paths to backup.
        logger: Logger instance for structured logging.
        log_file: Path to the JSON log file.
        cwd: Working directory for resolving relative paths. Defaults to Path.cwd().
        timestamp: Timestamp string for versioned backup subdirectory.
                   Format: YYYY-MM-DDTHH-MM-SS (ISO-inspired, filesystem-safe).
    """
    if not backup_artifacts:
        return

    work_dir = cwd if cwd is not None else Path.cwd()
    backup_root = (work_dir / ".cybervisor/backups" / stage_name / (timestamp or "")).resolve()

    for artifact_path in backup_artifacts:
        source = Path(artifact_path)
        # Absolute paths are used as-is; relative paths resolved against work_dir
        if not source.is_absolute():
            source = (work_dir / source).resolve()

        dest = backup_root / source.name

        if not source.exists():
            logger.log_to_stderr(f"[{stage_name}] Backup: source not found, skipping: {artifact_path}", "warning")
            continue

        try:
            backup_root.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            logger.log_to_stderr(f"[{stage_name}] Backup: failed to create directory {backup_root}: {exc}", "error")
            continue

        try:
            shutil.copy2(source, dest)
            logger.log_to_json(
                {
                    "timestamp": logger.make_entry(stage_name, "Backup", "Artifact backed up").timestamp,
                    "stage_name": stage_name,
                    "backup_source": str(source),
                    "backup_dest": str(dest),
                    "backup_timestamp": timestamp,
                },
                log_file,
            )
        except OSError as exc:
            logger.log_to_stderr(f"[{stage_name}] Backup: failed to copy {artifact_path} to {dest}: {exc}", "error")


def _clean_contract_artifacts_dir(*, pipeline_start_time: float | None = None, current_stage_name: str | None = None) -> None:
    """Remove stale contract artifact files before each stage execution.

    This removes leftover artifact files from previous stages or previous
    pipeline runs. The current stage's artifact is always cleaned so the
    hook enforces a fresh artifact. Artifacts from OTHER stages that were
    created during this pipeline run are preserved to allow retry without
    losing upstream artifacts.

    Args:
        pipeline_start_time: Unix timestamp from when the current pipeline started.
            If provided, files newer than this timestamp are preserved UNLESS they
            belong to the current stage.
        current_stage_name: Name of the current stage. Its artifact is always cleaned.
    """
    artifacts_dir = (Path.cwd() / CONTRACT_ARTIFACTS_DIR).resolve()
    if not artifacts_dir.exists():
        return
    for path in artifacts_dir.iterdir():
        try:
            if path.is_file() or path.is_symlink():
                # Always clean the current stage's artifact
                if current_stage_name is not None:
                    from cybervisor.config import contract_artifact_path
                    if path.name == contract_artifact_path(current_stage_name).name:
                        path.unlink(missing_ok=True)
                        continue
                # For other stages, preserve files created during this pipeline run
                if pipeline_start_time is not None and path.stat().st_mtime > pipeline_start_time:
                    continue
                path.unlink(missing_ok=True)
            # Subdirectories are not touched — they may contain seeded test data.
        except OSError:
            pass


def _cleanup_artifact_dir(
    root: Path, *, skip_if_files_present: bool = False, pipeline_start_time: float | None = None
) -> None:
    if not root.exists():
        return
    if skip_if_files_present:
        existing_files = [p for p in root.rglob("*") if p.is_file() or p.is_symlink()]
        if not existing_files:
            return
        # If a pipeline_start_time is given, only skip cleanup if files are
        # strictly NEWER than the marker (i.e., created during this pipeline
        # run). Files older than the marker are stale and must be removed.
        if pipeline_start_time is not None:
            stale = [p for p in existing_files if p.stat().st_mtime <= pipeline_start_time]
            if not stale:
                # All files are fresh — preserve the directory.
                return
            # Some files are stale — remove only the stale ones, then remove
            # any directories left empty by the file deletions.
            for path in sorted(stale, reverse=True):
                try:
                    if path.is_file() or path.is_symlink():
                        path.unlink(missing_ok=True)
                    elif path.is_dir():
                        path.rmdir()
                except OSError:
                    pass
            # Prune empty directories up to (but not including) root.
            for path in sorted(root.rglob("*"), reverse=True):
                try:
                    if path.is_dir():
                        path.rmdir()
                except OSError:
                    pass
            # Remove root if it is now empty.
            try:
                root.rmdir()
            except OSError:
                pass
            return
        # No pipeline_start_time: preserve all files.
        return
    for path in sorted(root.rglob("*"), reverse=True):
        try:
            if path.is_file() or path.is_symlink():
                path.unlink(missing_ok=True)
            elif path.is_dir():
                path.rmdir()
        except OSError as exc:
            # Best-effort cleanup: warn and continue with remaining items
            print(f"Warning: failed to remove {path}: {exc}", file=__import__("sys").stderr)
    try:
        root.rmdir()
    except OSError as exc:
        print(f"Warning: failed to remove directory {root}: {exc}", file=__import__("sys").stderr)


def reset_run_artifacts(
    *, skip_if_files_present: bool = False, pipeline_start_time: float | None = None
) -> None:
    _cleanup_artifact_dir(_artifact_runtime_root(), skip_if_files_present=skip_if_files_present, pipeline_start_time=pipeline_start_time)
    _cleanup_artifact_dir(_artifact_file_path("").parent, skip_if_files_present=skip_if_files_present, pipeline_start_time=pipeline_start_time)
