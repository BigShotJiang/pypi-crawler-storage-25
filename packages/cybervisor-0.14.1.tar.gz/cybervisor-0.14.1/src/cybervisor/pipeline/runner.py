"""Pipeline runner: stage loop, retry logic, and end-stage references."""

from __future__ import annotations

import logging
import shutil
import signal
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

import psutil

from cybervisor.adapters.base import AgentAdapter
from cybervisor.adapters.types import LaunchRequest
from cybervisor.config import StageConfig
from cybervisor.logging import CybervisorLogger, HookEventListener
from cybervisor.signals import SignalHandler


# Type alias for stage event callback
StageEventCallback = Callable[[dict[str, Any]], None]


class EndStageRef:
    """Thread-safe mutable reference for dynamic end stage updates.

    Allows the daemon to update the end stage mid-pipeline via set_stop_stage,
    which the PipelineRunner checks at each stage boundary.
    """

    def __init__(self, initial_value: str | None = None) -> None:
        self._value = initial_value
        self._lock = threading.Lock()

    def get(self) -> str | None:
        with self._lock:
            return self._value

    def set(self, value: str | None) -> None:
        with self._lock:
            self._value = value


class PipelineInterrupted(Exception):
    def __init__(self, stage_name: str, attempt: int, exit_code: int | None = None) -> None:
        self.stage_name = stage_name
        self.attempt = attempt
        self.exit_code = exit_code
        detail = f" during attempt {attempt}" if attempt > 0 else ""
        status = f" (exit_code={exit_code})" if exit_code is not None else ""
        super().__init__(f"Pipeline interrupted in stage '{stage_name}'{detail}{status}")


def _is_interrupt_exit_code(exit_code: int | None) -> bool:
    if exit_code is None:
        return False
    if exit_code == 130:
        return True
    return exit_code in (-signal.SIGINT, -signal.SIGTERM)


def _cleanup_stage(stage: StageConfig, workspace_root: Path) -> None:
    """Remove files at declared cleanup paths before a stage's agent starts.

    For directories: removes all contents (files, symlinks, and subdirectories)
    recursively, preserving only the directory itself. For regular files or
    symlinks: removes them directly. Missing paths are skipped. Deletion
    errors are caught and logged as warnings — the pipeline must not crash.
    """
    if not stage.cleanup:
        return
    logger = logging.getLogger(__name__)
    resolved_root = workspace_root.resolve()
    for raw_path in stage.cleanup:
        target = resolved_root / raw_path
        resolved = target.resolve()
        # Validate traversal safety (should have been caught at config time,
        # but double-check at runtime)
        if not resolved.is_relative_to(resolved_root):
            logger.warning(
                "cleanup entry '%s' resolves outside workspace root; skipping",
                raw_path,
            )
            continue
        if not target.exists() and not target.is_symlink():
            logger.debug("cleanup entry '%s' does not exist; skipping", raw_path)
            continue
        if target.is_dir() and not target.is_symlink():
            for entry in target.iterdir():
                try:
                    if entry.is_dir() and not entry.is_symlink():
                        shutil.rmtree(entry)
                        logger.debug("cleanup removed directory tree: %s", entry)
                    else:
                        entry.unlink()
                        logger.debug("cleanup removed file: %s", entry)
                except OSError as exc:
                    logger.warning(
                        "cleanup failed to remove '%s': %s", entry, exc
                    )
        elif target.is_file() or target.is_symlink():
            try:
                target.unlink()
                logger.debug("cleanup removed file: %s", target)
            except OSError as exc:
                logger.warning(
                    "cleanup failed to remove '%s': %s", target, exc
                )


def _get_child_pids(parent_pid: int) -> list[int]:
    try:
        parent = psutil.Process(parent_pid)
        return [child.pid for child in parent.children(recursive=True)]
    except (ProcessLookupError, psutil.NoSuchProcess, psutil.AccessDenied):
        return []


class PipelineRunner:
    def __init__(self, log_file: str = ".cybervisor/logs/cybervisor.log.jsonl") -> None:
        self.log_file = log_file

    def _emit_stage_event(self, callback: StageEventCallback | None, event: dict[str, Any]) -> None:
        """Invoke the stage event callback if it's set."""
        if callback is not None:
            callback(event)

    def _pop_hook_block(
        self,
        hook_listener: HookEventListener | None,
        agent_tool: str | None,
        *,
        wait_for_pending: bool = False,
    ) -> dict[str, object] | None:
        if hook_listener is None:
            return None

        hook_block = hook_listener.pop_blocking_decision(agent_tool)
        if hook_block is not None or not wait_for_pending:
            return hook_block

        deadline = time.monotonic() + 0.25
        while time.monotonic() < deadline:
            time.sleep(0.01)
            hook_block = hook_listener.pop_blocking_decision(agent_tool)
            if hook_block is not None:
                return hook_block
        return None

    def _build_prompt_context(
        self,
        prompt: str | None,
        stage_name: str,
        stage_context: dict[str, str],
    ) -> dict[str, str]:
        context = {
            "objective": prompt if prompt is not None else "",
            "stage_name": stage_name,
        }
        context.update(stage_context)
        return context

    def _build_injection_appendix(
        self,
        artifact_payload: dict[str, object],
        inject_sections: list[str],
    ) -> str:
        from cybervisor.pipeline.contract import (
            _format_injected_contract_value,
            _stringify_context_value,
        )

        if not inject_sections:
            return ""

        parts: list[str] = []
        for section in inject_sections:
            value = _stringify_context_value(artifact_payload.get(section))
            if not value:
                continue
            formatted = _format_injected_contract_value(section, value)
            if formatted:
                parts.append(formatted)

        if not parts:
            return ""

        return "Latest routed contract context:\n\n" + "\n\n".join(parts)

    def _update_stage_context_from_artifact(
        self,
        stage: StageConfig,
        artifact_payload: dict[str, object],
        stage_context: dict[str, str],
        inject_sections: list[str],
    ) -> None:
        from cybervisor.pipeline.contract import (
            _artifact_field_context_key,
            _normalized_artifact_payload,
            _stage_context_key,
            _stringify_context_value,
        )

        stage_key = _stage_context_key(stage.name)
        normalized_payload = _normalized_artifact_payload(artifact_payload)

        for section, raw_value in normalized_payload.items():
            if section in {"status", "Status"}:
                continue
            context_key = _artifact_field_context_key(section)
            rendered_value = _stringify_context_value(raw_value)
            stage_context[f"{stage_key}_contract_{context_key}"] = rendered_value
            if section in inject_sections:
                stage_context[f"latest_contract_{context_key}"] = rendered_value

    def _next_stage_index(
        self,
        stages: list[StageConfig],
        stage_lookup: dict[str, int],
        current_index: int,
        artifact_payload: dict[str, object] | None,
    ) -> tuple[int | None, str | None, str, list[str]]:
        from cybervisor.pipeline.contract import (
            _artifact_status_value,
            _resolve_contract_status,
        )

        stage = stages[current_index]
        status: str | None = None
        decision_source = "linear_fallback"

        if artifact_payload is not None:
            status = _artifact_status_value(artifact_payload)
            if status is None:
                return None, None, "contract_missing_status", []
            if stage.contract is not None:
                resolved_status = _resolve_contract_status(stage.contract, status)
                route = stage.contract.routes.get(resolved_status) if resolved_status is not None else None
                if route is None:
                    return None, status, "contract_missing_route", []
                if route.next_stage is None:
                    return None, resolved_status, "contract_terminal", list(route.injections)
                return stage_lookup[route.next_stage], resolved_status, "contract_route", list(route.injections)

        if stage.next_stage is not None:
            return stage_lookup[stage.next_stage], status, "success_route", []

        return current_index + 1, status, decision_source, []

    def execute_stage(
        self,
        stage: StageConfig,
        stage_prompt: str,
        attempt: int,
        agent: AgentAdapter,
        logger: CybervisorLogger,
        signal_handler: SignalHandler | None,
        hook_listener: HookEventListener | None,
        pipeline_start_time: float,
        stage_event_callback: StageEventCallback | None,
        stage_models: dict[str, str] | None,
    ) -> tuple[bool, str | None, dict[str, object] | None, int | None, dict[str, object] | None, bool]:
        """Execute a single pipeline stage attempt.

        Returns (passed, failure_error, artifact_payload, exit_code, hook_block, uses_hook_listener).
        """
        from cybervisor.pipeline.artifacts import (
            _clean_contract_artifacts_dir,
        )
        from cybervisor.pipeline.contract import (
            _artifact_status_value,
            _format_contract_artifact_output,
            _stage_log_path,
            _validate_stage_artifact,
        )
        from cybervisor.config import contract_artifact_path

        stage_output_log = _stage_log_path(stage.name)
        passed = False
        failure_error: str | None = None
        artifact_payload: dict[str, object] | None = None
        exit_code: int | None = None
        hook_block: dict[str, object] | None = None
        default_hook_listener_usage = bool(agent.descriptor.capabilities.supports_hooks)
        uses_hook_listener = bool(
            getattr(agent, "uses_hook_listener", lambda: default_hook_listener_usage)()
        )
        output = ""
        try:
            if hook_listener is not None and uses_hook_listener:
                hook_listener.clear_pending_blocks(agent.descriptor.name)
            _clean_contract_artifacts_dir(pipeline_start_time=pipeline_start_time, current_stage_name=stage.name)
            _cleanup_stage(stage, Path.cwd())
            if agent.descriptor.capabilities.supports_hooks:
                from cybervisor.pipeline import set_active_stage_contract as _set_active_stage_contract

                _set_active_stage_contract(
                    agent.descriptor.name,
                    stage.name,
                    stage_prompt,
                    stage.contract,
                    attempt=attempt,
                    max_retries=stage.max_retries,
                    keep_artifacts=stage.keep_artifacts,
                )
            running_process = agent.start(
                LaunchRequest(
                    prompt=stage_prompt,
                    stage_name=stage.name,
                    log_file=stage_output_log,
                    logger=logger,
                    model=(stage_models or {}).get(stage.name),
                )
            )
            if signal_handler is not None:
                signal_handler.set_pid(running_process.pid, running_process.process_group_id)
                if running_process.pid is not None:
                    child_pids = _get_child_pids(running_process.pid)
                    if child_pids:
                        signal_handler.register_child_pids(child_pids)
            exit_code, output = running_process.wait()
            if signal_handler is not None and signal_handler.interrupted:
                raise PipelineInterrupted(stage.name, attempt, exit_code)
            if _is_interrupt_exit_code(exit_code):
                raise PipelineInterrupted(stage.name, attempt, exit_code)
        except PipelineInterrupted:
            logger.log_to_stderr(f"[{stage.name}] Interrupted during attempt {attempt}", "warning")
            logger.log_to_json(
                logger.make_entry(
                    stage.name,
                    "Interrupted",
                    "Stage interrupted by user",
                    agent_tool=agent.descriptor.name,
                    attempt=attempt,
                    exit_status=exit_code,
                    log_path=stage_output_log,
                ),
                self.log_file,
            )
            raise
        except Exception as exc:
            if signal_handler is not None and signal_handler.interrupted:
                raise PipelineInterrupted(stage.name, attempt, exit_code) from exc
            failure_error = f"Stage execution failed: {exc}"
        else:
            execution_result = agent.run_result(exit_code, output)
            passed = execution_result.lifecycle == agent.completed_status()
            agent.log_execution_result(logger, stage.name, execution_result)
            hook_block = (
                self._pop_hook_block(
                    hook_listener,
                    agent.descriptor.name,
                    wait_for_pending=passed or stage.contract is not None,
                )
                if uses_hook_listener
                else None
            )
            if hook_block is not None:
                passed = False
                reason = hook_block.get("reason")
                details = "Hook blocked agent completion"
                if isinstance(reason, str) and reason:
                    details = f"{details}: {reason}"
                failure_error = details
            elif stage.contract is not None:
                artifact_payload, artifact_error = _validate_stage_artifact(stage.name, stage.contract)
                if artifact_error is not None:
                    passed = False
                    failure_error = f"Stage artifact validation failed: {artifact_error}"
                elif artifact_payload is not None:
                    passed = True
                    failure_error = None
                    artifact_status = _artifact_status_value(artifact_payload)
                    route = stage.contract.routes.get(artifact_status) if artifact_status is not None else None
                    logger.log_to_stderr(_format_contract_artifact_output(stage.name, artifact_payload, route))
                    logger.log_to_json(
                        {
                            "timestamp": logger.make_entry(stage.name, "Execution", "").timestamp,
                            "stage_name": stage.name,
                            "status": "ArtifactValidated",
                            "message": "Validated stage artifact",
                            "artifact_path": str(contract_artifact_path(stage.name)),
                            "artifact_status": artifact_status,
                            "artifact_payload": artifact_payload,
                        },
                        self.log_file,
                    )
                    self._emit_stage_event(
                        stage_event_callback,
                        {
                            "event_type": "artifact_validated",
                            "stage_name": stage.name,
                            "artifact_status": artifact_status or "",
                        },
                    )
            elif not passed and failure_error is None and exit_code != 0:
                failure_error = f"Agent exited with code {exit_code}"
        finally:
            if signal_handler is not None:
                signal_handler.set_pid(None)
                signal_handler.clear_child_pids()
            if agent.descriptor.capabilities.supports_hooks:
                from cybervisor.pipeline import set_active_stage_contract as _set_active_stage_contract

                _set_active_stage_contract(agent.descriptor.name, None, None, None, keep_artifacts=[])

        return passed, failure_error, artifact_payload, exit_code, hook_block, uses_hook_listener

    def drain_hook_block(
        self,
        stage: StageConfig,
        agent: AgentAdapter,
        logger: CybervisorLogger,
        hook_listener: HookEventListener | None,
        stage_event_callback: StageEventCallback | None,
        passed: bool,
        failure_error: str | None,
        artifact_payload: dict[str, object] | None,
        hook_block: dict[str, object] | None,
        uses_hook_listener: bool,
    ) -> tuple[bool, str | None, dict[str, object] | None, dict[str, object] | None]:
        """Drain remaining hook blocks after stage execution.

        Returns (passed, failure_error, artifact_payload, hook_block).
        """
        from cybervisor.pipeline.contract import (
            _artifact_status_value,
            _format_contract_artifact_output,
            _validate_stage_artifact,
        )
        from cybervisor.config import contract_artifact_path

        if not uses_hook_listener:
            return passed, failure_error, artifact_payload, hook_block

        queue_drained = True
        drain_limit = 10
        for _ in range(drain_limit):
            next_block = self._pop_hook_block(
                hook_listener,
                agent.descriptor.name,
                wait_for_pending=False,
            )
            if next_block is None:
                break
            hook_block = next_block
        else:
            queue_drained = False

        if hook_block is not None:
            if stage.contract is not None:
                artifact_payload, artifact_error = _validate_stage_artifact(stage.name, stage.contract)
                if artifact_error is not None:
                    passed = False
                    failure_error = f"Stage artifact validation failed: {artifact_error}"
                else:
                    hook_block = None
                    passed = True
                    failure_error = None
                    assert artifact_payload is not None
                    artifact_status = _artifact_status_value(artifact_payload)
                    route = stage.contract.routes.get(artifact_status) if artifact_status is not None else None
                    logger.log_to_stderr(_format_contract_artifact_output(stage.name, artifact_payload, route))
                    logger.log_to_json(
                        {
                            "timestamp": logger.make_entry(stage.name, "Execution", "").timestamp,
                            "stage_name": stage.name,
                            "status": "ArtifactValidated",
                            "message": "Validated stage artifact (drain re-check)",
                            "artifact_path": str(contract_artifact_path(stage.name)),
                            "artifact_status": artifact_status,
                            "artifact_payload": artifact_payload,
                        },
                        self.log_file,
                    )
                    self._emit_stage_event(
                        stage_event_callback,
                        {
                            "event_type": "artifact_validated",
                            "stage_name": stage.name,
                            "artifact_status": artifact_status or "",
                        },
                    )
            elif queue_drained:
                hook_block = None
                passed = True
                failure_error = None

        return passed, failure_error, artifact_payload, hook_block

    def run(
        self,
        prompt: str | None,
        stages: list[StageConfig],
        agent: AgentAdapter,
        logger: CybervisorLogger,
        signal_handler: SignalHandler | None = None,
        hook_listener: HookEventListener | None = None,
        start_stage_name: str | None = None,
        end_after_name: str | None = None,
        end_before_stage_name: str | None = None,
        end_stage_ref: EndStageRef | None = None,
        stage_event_callback: StageEventCallback | None = None,
        stage_models: dict[str, str] | None = None,
    ) -> bool:
        from cybervisor.pipeline.artifacts import (
            _artifact_file_path,
            _artifact_runtime_root,
            _cleanup_artifact_dir,
        )
        from cybervisor.pipeline.contract import (
            _render_prompt,
            _stage_log_path,
        )

        stage_lookup = {stage.name: index for index, stage in enumerate(stages)}

        if end_after_name is not None and end_after_name not in stage_lookup:
            raise ValueError(f"Unknown end_after_name '{end_after_name}'. Valid stages are: {', '.join(stage_lookup.keys())}")
        if end_before_stage_name is not None and end_before_stage_name not in stage_lookup:
            raise ValueError(
                f"Unknown end_before_stage_name '{end_before_stage_name}'. Valid stages are: {', '.join(stage_lookup.keys())}"
            )
        if start_stage_name is not None and start_stage_name not in stage_lookup:
            raise ValueError(f"Unknown start_stage_name '{start_stage_name}'. Valid stages are: {', '.join(stage_lookup.keys())}")
        if end_after_name is not None and end_before_stage_name is not None:
            raise ValueError("--end-after and --end-before cannot be used together.")

        retry_counts = [0 for _ in stages]
        iteration_counts = [0 for _ in stages]
        current_index = 0

        if start_stage_name is not None:
            current_index = stage_lookup[start_stage_name]
        did_reset = current_index == 0
        pipeline_start_time = time.time()
        if did_reset:
            workspace_path = Path.cwd()
            cybervisor_dir = workspace_path / ".cybervisor"
            cybervisor_dir.mkdir(exist_ok=True)
            pipeline_marker = cybervisor_dir / ".pipeline_start"
            pipeline_marker.write_text(f"{pipeline_start_time}\n", encoding="utf-8")

            _cleanup_artifact_dir(
                _artifact_runtime_root(),
                skip_if_files_present=True,
                pipeline_start_time=None,
            )
            _cleanup_artifact_dir(
                _artifact_file_path("").parent,
                skip_if_files_present=True,
                pipeline_start_time=None,
            )

        if end_after_name is not None:
            end_index = stage_lookup[end_after_name]
            if current_index > end_index:
                raise ValueError(f"Invalid sequence: start stage '{start_stage_name}' occurs after end stage '{end_after_name}', so pipeline cannot realistically reach the end stage.")
            logger.log_to_json(
                {
                    "timestamp": logger.make_entry("Startup", "TargetedStart", "").timestamp,
                    "stage_name": "Startup",
                    "status": "TargetedStart",
                    "message": "Starting pipeline at requested stage",
                    "requested_stage_name": start_stage_name,
                    "effective_stage_name": stages[current_index].name,
                    "total_stage_count": len(stages),
                },
                self.log_file,
            )
        elif end_before_stage_name is not None:
            end_before_index = stage_lookup[end_before_stage_name]
            if current_index > end_before_index:
                raise ValueError(
                    f"Invalid sequence: start stage '{start_stage_name}' occurs after exclusive end stage '{end_before_stage_name}', so pipeline cannot stop before that stage."
                )
            if current_index == end_before_index:
                logger.log_to_json(
                    {
                        "timestamp": logger.make_entry("Startup", "TargetedEndBefore", "").timestamp,
                        "stage_name": "Startup",
                        "status": "TargetedEndBefore",
                        "message": "Skipping pipeline execution because start stage matches exclusive end boundary",
                        "requested_stage_name": end_before_stage_name,
                        "effective_stage_name": stages[current_index].name,
                        "total_stage_count": len(stages),
                    },
                    self.log_file,
                )
                return True

        stage_context: dict[str, str] = {}
        stage_appendices: dict[str, str] = {}

        while current_index < len(stages):
            if end_before_stage_name is not None and stages[current_index].name == end_before_stage_name:
                break
            current_end_stage = end_stage_ref.get() if end_stage_ref is not None else end_after_name
            if current_end_stage is not None and current_end_stage == stages[current_index].name:
                logger.log_to_stderr(f"[{stages[current_index].name}] Reached requested end_after, stopping pipeline.")
                logger.log_to_json(
                    logger.make_entry(stages[current_index].name, "Execution", "Reached requested end_after, stopping pipeline."),
                    self.log_file,
                )
                break
            stage = stages[current_index]
            attempt = retry_counts[current_index] + 1
            if retry_counts[current_index] == 0:
                iteration_counts[current_index] += 1
            if signal_handler is not None and signal_handler.interrupted:
                raise PipelineInterrupted(stage.name, attempt - 1)
            if stage.max_iterations > 0 and iteration_counts[current_index] > stage.max_iterations:
                next_stage_name = stage.max_iterations_next_stage
                next_index: int | None = None
                if next_stage_name is not None and next_stage_name in stage_lookup:
                    next_index = stage_lookup[next_stage_name]
                else:
                    next_index = current_index + 1
                logger.log_to_stderr(
                    f"[{stage.name}] Max iterations exceeded "
                    f"({iteration_counts[current_index]}/{stage.max_iterations}), "
                    f"routing to {stages[next_index].name if next_index < len(stages) else 'end'}",
                    "warning",
                )
                logger.log_to_json(
                    {
                        "timestamp": logger.make_entry(stage.name, "MaxIterationsExceeded", "").timestamp,
                        "stage_name": stage.name,
                        "status": "MaxIterationsExceeded",
                        "message": "Stage iteration count exceeded max_iterations; forcing route",
                        "decision_source": "max_iterations_exceeded",
                        "max_iterations": stage.max_iterations,
                        "iteration_count": iteration_counts[current_index],
                        "next_stage": stages[next_index].name if next_index < len(stages) else None,
                    },
                    self.log_file,
                )
                self._emit_stage_event(
                    stage_event_callback,
                    {
                        "event_type": "max_iterations_exceeded",
                        "stage_name": stage.name,
                        "max_iterations": stage.max_iterations,
                        "iteration_count": iteration_counts[current_index],
                        "next_stage": stages[next_index].name if next_index < len(stages) else None,
                    },
                )
                current_end_stage = end_stage_ref.get() if end_stage_ref is not None else end_after_name
                if current_end_stage is not None and next_index > stage_lookup[current_end_stage]:
                    break
                if next_index >= len(stages):
                    return True
                current_index = next_index
                continue
            if attempt > stage.max_retries:
                logger.log_to_stderr(f"[{stage.name}] Exhausted retries", "error")
                logger.log_to_json(
                    logger.make_entry(stage.name, "Failed", "Retries exhausted"),
                    self.log_file,
                )
                self._emit_stage_event(
                    stage_event_callback,
                    {
                        "event_type": "stage_failed",
                        "stage_name": stage.name,
                        "attempt": attempt,
                        "error": "Retries exhausted",
                    },
                )
                return False

            if stage.max_iterations > 0:
                logger.log_to_stderr(f"[{stage.name}] Running attempt {attempt} (iteration {iteration_counts[current_index]}/{stage.max_iterations})")
            else:
                logger.log_to_stderr(f"[{stage.name}] Running attempt {attempt}")
            prepared_result = agent.prepare()
            running_result = agent.running()
            json_entry: dict[str, Any] = {
                    "timestamp": logger.make_entry(stage.name, "Running", "").timestamp,
                    "stage_name": stage.name,
                    "status": "Running",
                    "message": f"attempt={attempt}",
                    "adapter_lifecycle": prepared_result.lifecycle.value,
                    "adapter_outcome": prepared_result.outcome.value,
                }
            if stage.max_iterations > 0:
                json_entry["iteration_count"] = iteration_counts[current_index]
                json_entry["max_iterations"] = stage.max_iterations
            logger.log_to_json(json_entry, self.log_file)
            stage_start_event: dict[str, Any] = {
                    "event_type": "stage_start",
                    "stage_name": stage.name,
                    "attempt": attempt,
                    "max_retries": stage.max_retries,
                }
            if stage.max_iterations > 0:
                stage_start_event["iteration_count"] = iteration_counts[current_index]
                stage_start_event["max_iterations"] = stage.max_iterations
            self._emit_stage_event(
                stage_event_callback,
                stage_start_event,
            )
            agent.log_execution_result(logger, stage.name, prepared_result)
            agent.log_execution_result(logger, stage.name, running_result)

            context = self._build_prompt_context(prompt, stage.name, stage_context)
            stage_prompt, missing_keys = _render_prompt(stage.prompt_template, context)
            appended_context = stage_appendices.get(stage.name, "")
            if appended_context:
                stage_prompt = f"{stage_prompt.rstrip()}\n\n{appended_context}"
            if missing_keys:
                missing = ", ".join(sorted(missing_keys))
                logger.log_to_stderr(
                    f"[{stage.name}] Missing template placeholders defaulted to empty: {missing}",
                    "warning",
                )

            passed, failure_error, artifact_payload, exit_code, hook_block, uses_hook_listener = self.execute_stage(
                stage, stage_prompt, attempt, agent, logger, signal_handler,
                hook_listener, pipeline_start_time, stage_event_callback, stage_models,
            )

            passed, failure_error, artifact_payload, hook_block = self.drain_hook_block(
                stage, agent, logger, hook_listener, stage_event_callback,
                passed, failure_error, artifact_payload, hook_block, uses_hook_listener,
            )

            if signal_handler is not None and signal_handler.interrupted:
                raise PipelineInterrupted(stage.name, attempt, exit_code)

            if not passed:
                retry_counts[current_index] += 1
                logger.log_to_stderr(f"[{stage.name}] Failed on attempt {attempt}", "warning")
                logger.log_to_json(
                    logger.make_entry(
                        stage.name,
                        "Failed",
                        "Stage failed, retrying",
                        error=failure_error,
                        agent_tool=agent.descriptor.name,
                        attempt=attempt,
                        exit_status=exit_code,
                        log_path=_stage_log_path(stage.name),
                    ),
                    self.log_file,
                )
                logger.log_to_json(
                    logger.make_entry(
                        stage.name,
                        "Execution",
                        "Stage attempt finished",
                        error=failure_error,
                        agent_tool=agent.descriptor.name,
                        attempt=attempt,
                        exit_status=exit_code,
                        log_path=_stage_log_path(stage.name),
                    ),
                    self.log_file,
                )
                self._emit_stage_event(
                    stage_event_callback,
                    {
                        "event_type": "stage_retry",
                        "stage_name": stage.name,
                        "attempt": attempt,
                        "max_retries": stage.max_retries,
                        "error": failure_error or "Stage failed",
                    },
                )
                continue

            from cybervisor.pipeline.artifacts import _backup_stage_artifacts

            _backup_stage_artifacts(
                stage_name=stage.name,
                backup_artifacts=stage.backup_artifacts,
                logger=logger,
                log_file=self.log_file,
                timestamp=datetime.now(tz=timezone.utc).strftime("%Y-%m-%dT%H-%M-%S"),
            )

            next_index, status, decision_source, inject_sections = self._next_stage_index(
                stages,
                stage_lookup,
                current_index,
                artifact_payload,
            )
            if decision_source == "contract_missing_route":
                logger.log_to_stderr(
                    f"[{stage.name}] Artifact status '{status}' has no matching contract route. Add an explicit route such as contract.routes.approved.",
                    "error",
                )
                logger.log_to_json(
                    {
                        "timestamp": logger.make_entry(stage.name, "Failed", "").timestamp,
                        "stage_name": stage.name,
                        "status": "Failed",
                        "message": "Contract artifact status has no matching route",
                        "artifact_status": status,
                    },
                    self.log_file,
                )
                return False
            if artifact_payload is not None:
                self._update_stage_context_from_artifact(stage, artifact_payload, stage_context, inject_sections)
            stage_appendices.pop(stage.name, None)

            if decision_source == "contract_route" and artifact_payload is not None and next_index is not None:
                stage_appendices[stages[next_index].name] = self._build_injection_appendix(
                    artifact_payload,
                    inject_sections,
                )
            elif next_index is not None and next_index < len(stages):
                stage_appendices.pop(stages[next_index].name, None)

            retry_counts[current_index] = 0

            logger.log_to_stderr(f"[{stage.name}] Success")
            logger.log_to_json(
                logger.make_entry(
                    stage.name,
                    "Success",
                    "Stage completed",
                    agent_tool=agent.descriptor.name,
                ),
                self.log_file,
            )
            logger.log_to_json(
                logger.make_entry(
                    stage.name,
                    "Execution",
                    "Stage attempt finished",
                    agent_tool=agent.descriptor.name,
                    attempt=attempt,
                    exit_status=exit_code,
                    log_path=_stage_log_path(stage.name),
                ),
                self.log_file,
            )
            self._emit_stage_event(
                stage_event_callback,
                {
                    "event_type": "stage_complete",
                    "stage_name": stage.name,
                    "success": True,
                    "attempt": attempt,
                },
            )
            if artifact_payload is not None and status is not None:
                logger.log_to_json(
                    {
                        "timestamp": logger.make_entry(stage.name, "Routing", "").timestamp,
                        "stage_name": stage.name,
                        "status": "Routing",
                        "message": "Resolved next stage from contract status",
                        "artifact_status": status,
                        "next_stage": stages[next_index].name if next_index is not None and next_index < len(stages) else None,
                        "decision_source": decision_source,
                    },
                    self.log_file,
                )
                self._emit_stage_event(
                    stage_event_callback,
                    {
                        "event_type": "routing_decision",
                        "stage_name": stage.name,
                        "next_stage": stages[next_index].name if next_index is not None and next_index < len(stages) else None,
                        "decision_source": decision_source,
                    },
                )
            if decision_source == "contract_terminal":
                return True

            if next_index is None:
                return True
            current_index = next_index

        return True
