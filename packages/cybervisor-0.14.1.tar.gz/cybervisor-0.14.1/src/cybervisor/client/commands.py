"""Daemon client command implementations."""

from __future__ import annotations

import asyncio
import json
import os
import sys
import uuid
from typing import Any, cast

from websockets.asyncio.client import ClientConnection

from cybervisor.client.connection import ClientConfig
from cybervisor.client.rendering import render_event
from cybervisor.logging import CybervisorLogger
from cybervisor.server_events import EventType, ServerEvent


def _resolve_config(host: str | None, port: int | None) -> ClientConfig:
    """Resolve host/port from CLI args or global config defaults."""
    from cybervisor.client import _default_config as __default_config
    default = __default_config()
    return ClientConfig(
        host=host if host is not None else default.host,
        port=port if port is not None else default.port,
        connect_timeout_seconds=default.connect_timeout_seconds,
    )


# ---------------------------------------------------------------------------
# ping
# ---------------------------------------------------------------------------


async def ping_daemon(config: ClientConfig, task_id: str | None = None) -> tuple[bool, list[dict[str, Any]]]:
    """Ping the daemon and retrieve active task snapshots.

    Args:
        task_id: If provided, retrieve only the snapshot for this specific task.
                 If None, retrieve all running task snapshots.
    Returns (reachable, tasks) where:
    - reachable: True if daemon responded with PONG, False otherwise
    - tasks: list of active task snapshot dicts from the pong, or [] if unreachable
              or if the daemon predates this feature (pong has no tasks field)
    """
    uri = f"ws://{config.host}:{config.port}"
    from cybervisor.client import _connect as __connect, _receive_events as __receive_events
    try:
        ws = await __connect(uri, config.connect_timeout_seconds)
    except ConnectionError:
        return False, []

    try:
        await ws.send(json.dumps({"type": EventType.PING.value, "task_id": task_id or ""}))
        async for event in __receive_events(ws):
            if event.type == EventType.PONG.value:
                return True, event.tasks if event.tasks is not None else []
            return False, []
        return False, []
    except Exception:  # pragma: no cover
        return False, []
    finally:
        await ws.close()


# ---------------------------------------------------------------------------
# status
# ---------------------------------------------------------------------------


async def run_status_command(host: str | None, port: int | None, task_id: str | None = None) -> int:
    """Run the status command."""
    from cybervisor.client import _resolve_config as _cli_resolve_config, ping_daemon

    config = _cli_resolve_config(host, port)
    reachable, tasks = await ping_daemon(config, task_id=task_id)
    if not reachable:
        print(f"Daemon not reachable at ws://{config.host}:{config.port}")
        return 1

    running_tasks = [t for t in tasks if t.get("status") == "running"]

    if task_id is not None:
        matched = [t for t in running_tasks if t.get("task_id") == task_id]
        if not matched:
            print(f"Task not found.")
            return 1
        task = matched[0]
        active_stage = task.get("active_stage")
        stage_label = active_stage if active_stage is not None else "initializing"
        cwd = task.get("cwd", "unknown")
        end_stage = task.get("end_stage")
        end_before = task.get("end_before")
        bounds = []
        if end_stage:
            bounds.append(f"end_stage={end_stage}")
        if end_before:
            bounds.append(f"end_before={end_before}")
        bounds_str = f", bounds: {', '.join(bounds)}" if bounds else ""
        print(f"Task: {task.get('task_id')} (stage: {stage_label}, cwd: {cwd}{bounds_str})")
    else:
        MAX_STATUS_TASKS = 20
        displayed = running_tasks[:MAX_STATUS_TASKS]
        if displayed:
            for task in displayed:
                active_stage = task.get("active_stage")
                stage_label = active_stage if active_stage is not None else "initializing"
                cwd = task.get("cwd", "unknown")
                end_stage = task.get("end_stage")
                end_before = task.get("end_before")
                bounds = []
                if end_stage:
                    bounds.append(f"end_stage={end_stage}")
                if end_before:
                    bounds.append(f"end_before={end_before}")
                bounds_str = f", bounds: {', '.join(bounds)}" if bounds else ""
                print(f"Running task: {task.get('task_id')} (stage: {stage_label}, cwd: {cwd}{bounds_str})")
        if len(running_tasks) > MAX_STATUS_TASKS:
            print("...")
        if not running_tasks:
            print("No active tasks.")

    print(f"Daemon reachable at ws://{config.host}:{config.port}")
    return 0


# ---------------------------------------------------------------------------
# _find_running_task_in_cwd
# ---------------------------------------------------------------------------


async def _find_running_task_in_cwd(
    config: ClientConfig,
) -> tuple[bool, list[dict[str, Any]] | None]:
    """Ping daemon and return running tasks in current CWD."""
    from cybervisor.client import ping_daemon

    reachable, all_tasks = await ping_daemon(config)
    if not reachable:
        return False, None
    current_cwd = os.path.realpath(os.getcwd())
    running_in_cwd = [
        t
        for t in all_tasks
        if t.get("status") == "running" and os.path.realpath(t.get("cwd", "")) == current_cwd
    ]
    return True, running_in_cwd


# ---------------------------------------------------------------------------
# find_active_task
# ---------------------------------------------------------------------------


async def find_active_task(config: ClientConfig) -> str | None:
    """Ping daemon and return the task_id of the single running task in current CWD."""
    from cybervisor.client import ping_daemon

    reachable, tasks = await ping_daemon(config)
    if not reachable:
        return None
    current_cwd = os.path.realpath(os.getcwd())
    running_in_cwd = [t for t in tasks if t.get("status") == "running"
                      and os.path.realpath(t.get("cwd", "")) == current_cwd]
    if len(running_in_cwd) == 0:
        return None
    if len(running_in_cwd) > 1:
        raise ValueError("Multiple tasks are running in this directory. Use 'cybervisor cancel <task-id>' to target a specific task.")
    return running_in_cwd[0].get("task_id")


# ---------------------------------------------------------------------------
# submit
# ---------------------------------------------------------------------------


def _reassemble_events(event: ServerEvent) -> list[ServerEvent]:
    """Reassemble an event_replay ServerEvent into its child ServerEvents."""
    if event.type != EventType.EVENT_REPLAY.value:
        return [event]

    events = event.events
    if not events:
        return []

    return [ServerEvent.from_dict(e) for e in events]


async def submit_and_stream(
    prompt: str,
    config: ClientConfig,
    task_id: str | None = None,
    config_path: str | None = None,
    start_stage: str | None = None,
    end_after: str | None = None,
    end_before: str | None = None,
) -> int:
    """Submit a task and stream events until completion."""
    from cybervisor.client import _connect as __connect, _receive_events as __receive_events

    uri = f"ws://{config.host}:{config.port}"
    resolved_task_id = task_id or uuid.uuid4().hex[:12]
    print(f"Task created: {resolved_task_id}", file=sys.stderr)

    task_logger = CybervisorLogger()
    task_logger.log_to_json(
        task_logger.make_entry(
            stage_name="Task",
            status="TaskCreated",
            message=f"Task created: {resolved_task_id}",
            task_id=resolved_task_id,
        ),
        ".cybervisor/logs/cybervisor.log.jsonl",
    )

    msg: dict[str, Any] = {
        "type": EventType.RUN.value,
        "task_id": resolved_task_id,
        "prompt": prompt,
        "cwd": os.getcwd(),
    }
    if config_path:
        msg["config_path"] = config_path
    if start_stage:
        msg["start_stage"] = start_stage
    if end_after:
        msg["end_stage"] = end_after
    if end_before:
        msg["end_before"] = end_before

    async def send_and_listen(ws: ClientConnection) -> int:
        await ws.send(json.dumps(msg))
        exit_code = 1
        chunk_buffer: dict[str, dict[int, dict[str, Any]]] = {}

        async for event in __receive_events(ws):
            if event.type == EventType.EVENT_REPLAY_CHUNK.value:
                chunk_id = event.chunk_id or ""
                if not chunk_id:
                    continue
                if chunk_id not in chunk_buffer:
                    chunk_buffer[chunk_id] = {}
                chunk_data: dict[str, Any] = event.to_dict()
                chunk_buffer[chunk_id][chunk_data.get("chunk_index", 0)] = chunk_data
                chunk_count = chunk_data.get("chunk_count", 1)
                if len(chunk_buffer[chunk_id]) == chunk_count:
                    sorted_chunks = sorted(chunk_buffer[chunk_id].items(), key=lambda x: x[0])
                    for _, chunk in sorted_chunks:
                        for e in chunk.get("events", []):
                            se = ServerEvent.from_dict(e)
                            level, line = render_event(se)
                            if level == "stdout" and line is not None:
                                print(line)
                            elif level == "stderr" and line is not None:
                                print(line, file=__import__("sys").stderr)
                            if se.type == EventType.RUN_COMPLETE.value:
                                exit_code = 0 if se.success else 1
                    del chunk_buffer[chunk_id]
                continue

            if event.type == EventType.EVENT_REPLAY.value:
                reassembled = _reassemble_events(event)
                for e in reassembled:
                    level, line = render_event(e)
                    if level == "stdout" and line is not None:
                        print(line)
                    elif level == "stderr" and line is not None:
                        print(line, file=__import__("sys").stderr)
                    if e.type == EventType.RUN_COMPLETE.value:
                        exit_code = 0 if e.success else 1
                continue

            level, line = render_event(event)
            if level == "stdout" and line is not None:
                print(line)
            elif level == "stderr" and line is not None:
                print(line, file=__import__("sys").stderr)

            if event.type == EventType.RUN_COMPLETE.value:
                return 0 if event.success else 1
            if event.type == EventType.PIPELINE_ABORT.value:
                return 1

        return exit_code

    try:
        ws = await __connect(uri, config.connect_timeout_seconds)
    except ConnectionError:
        print(f"daemon not reachable at ws://{config.host}:{config.port}", file=__import__("sys").stderr)
        return 1

    try:
        exit_code = await send_and_listen(ws)
        return exit_code
    except StopAsyncIteration:
        return exit_code
    except Exception as exc:
        print(f"Connection error: {exc}", file=__import__("sys").stderr)
        return 1
    finally:
        await ws.close()


async def run_submit_command(
    prompt: str,
    host: str | None,
    port: int | None,
    task_id: str | None = None,
    config_path: str | None = None,
    start_stage: str | None = None,
    end_after: str | None = None,
    end_before: str | None = None,
) -> int:
    """Run the submit command."""
    from cybervisor.client import _resolve_config as _cli_resolve_config, submit_and_stream

    config = _cli_resolve_config(host, port)
    try:
        return await submit_and_stream(
            prompt=prompt,
            config=config,
            task_id=task_id,
            config_path=config_path,
            start_stage=start_stage,
            end_after=end_after,
            end_before=end_before,
        )
    except asyncio.CancelledError:
        return 130


# ---------------------------------------------------------------------------
# attach
# ---------------------------------------------------------------------------


async def attach_and_stream(task_id: str, config: ClientConfig) -> int:
    """Reconnect to a task and stream events until completion."""
    from cybervisor.client import _connect as __connect, _receive_events as __receive_events

    uri = f"ws://{config.host}:{config.port}"

    msg: dict[str, Any] = {
        "type": EventType.RESUME.value,
        "task_id": task_id,
    }

    async def send_and_listen(ws: ClientConnection) -> int:
        await ws.send(json.dumps(msg))
        _exit_code = [1]
        _run_complete_seen = [False]
        chunk_buffer: dict[str, dict[int, dict[str, Any]]] = {}

        async def handle_chunk(received_events: list[dict[str, Any]]) -> None:
            for e in received_events:
                se = ServerEvent.from_dict(e)
                level, line = render_event(se)
                if level == "stdout" and line is not None:
                    print(line)
                elif level == "stderr" and line is not None:
                    print(line, file=__import__("sys").stderr)
                if se.type == EventType.RUN_COMPLETE.value:
                    _exit_code[0] = 0 if se.success else 1
                    _run_complete_seen[0] = True

        try:
            async for event in __receive_events(ws):
                if event.type == EventType.EVENT_REPLAY_CHUNK.value:
                    chunk_id = event.chunk_id or ""
                    if not chunk_id:
                        continue
                    if chunk_id not in chunk_buffer:
                        chunk_buffer[chunk_id] = {}
                    chunk_data: dict[str, Any] = event.to_dict()
                    idx = chunk_data.get("chunk_index", 0)
                    chunk_buffer[chunk_id][idx] = chunk_data
                    chunk_count = chunk_data.get("chunk_count", 1)
                    if len(chunk_buffer[chunk_id]) == chunk_count:
                        sorted_chunks = sorted(chunk_buffer[chunk_id].items(), key=lambda x: x[0])
                        received = [evt for _, chunk in sorted_chunks for evt in chunk.get("events", [])]
                        await handle_chunk(received)
                        del chunk_buffer[chunk_id]
                        if _run_complete_seen[0]:
                            return _exit_code[0]
                    continue

                if event.type == EventType.EVENT_REPLAY.value:
                    reassembled = _reassemble_events(event)
                    received = [e.to_dict() for e in reassembled]
                    await handle_chunk(received)
                    if _run_complete_seen[0]:
                        return _exit_code[0]
                    continue

                level, line = render_event(event)
                if level == "stdout" and line is not None:
                    print(line)
                elif level == "stderr" and line is not None:
                    print(line, file=__import__("sys").stderr)
                if event.type == EventType.RUN_COMPLETE.value:
                    return 0 if event.success else 1
            return _exit_code[0]
        except StopAsyncIteration:
            return _exit_code[0]

    try:
        ws = await __connect(uri, config.connect_timeout_seconds)
    except ConnectionError:
        print(f"daemon not reachable at ws://{config.host}:{config.port}", file=__import__("sys").stderr)
        return 1

    try:
        return await send_and_listen(ws)
    except Exception as exc:  # pragma: no cover
        print(f"Connection error: {exc}", file=__import__("sys").stderr)
        return 1
    finally:
        await ws.close()


async def run_attach_command(task_id: str | None, host: str | None, port: int | None) -> int:
    """Run the attach command."""
    from cybervisor.client import _resolve_config as _cli_resolve_config, _find_running_task_in_cwd as __find_running_task_in_cwd, attach_and_stream as __attach_and_stream

    config = _cli_resolve_config(host, port)
    resolved_task_id = task_id
    if resolved_task_id is None:
        reachable, running_in_cwd = await __find_running_task_in_cwd(config)
        if not reachable:
            print(f"Daemon not reachable at ws://{config.host}:{config.port}", file=__import__("sys").stderr)
            return 1
        if not running_in_cwd:
            print("No active task to attach to.", file=__import__("sys").stderr)
            return 1
        if len(running_in_cwd) > 1:
            print("Multiple tasks are running in this directory. Use 'cybervisor attach <task-id>' to target a specific task.", file=__import__("sys").stderr)
            return 1
        resolved_task_id = cast(str | None, running_in_cwd[0].get("task_id"))
        if resolved_task_id is None:
            print("No active task to attach to.", file=__import__("sys").stderr)
            return 1
    try:
        return await __attach_and_stream(task_id=resolved_task_id, config=config)
    except asyncio.CancelledError:
        return 130


# ---------------------------------------------------------------------------
# cancel
# ---------------------------------------------------------------------------


async def _cancel_task_impl(task_id: str, config: ClientConfig) -> tuple[bool, str]:
    """Cancel an active task."""
    from cybervisor.client import _connect as __connect, _receive_events as __receive_events

    uri = f"ws://{config.host}:{config.port}"

    msg: dict[str, Any] = {
        "type": EventType.CANCEL.value,
        "cwd": os.getcwd(),
    }
    if task_id:
        msg["task_id"] = task_id

    try:
        ws = await __connect(uri, config.connect_timeout_seconds)
    except ConnectionError:
        return False, f"daemon not reachable at ws://{config.host}:{config.port}"

    try:
        await ws.send(json.dumps(msg))
        async for event in __receive_events(ws):
            if event.type == EventType.PIPELINE_ABORT.value:
                return True, "Task cancelled"
            if event.type == EventType.ERROR.value:
                code = event.code or "?"
                message = event.message or "unknown error"
                return False, f"[{code}] {message}"
        return False, "No response from daemon"
    except Exception as exc:  # pragma: no cover
        return False, f"Connection error: {exc}"
    finally:
        await ws.close()


async def run_cancel_command(task_id: str | None, host: str | None, port: int | None) -> int:
    """Run the cancel command."""
    from cybervisor.client import _resolve_config as _cli_resolve_config, _find_running_task_in_cwd as __find_running_task_in_cwd

    config = _cli_resolve_config(host, port)
    resolved_task_id = task_id
    if resolved_task_id is None:
        reachable, running_in_cwd = await __find_running_task_in_cwd(config)
        if not reachable:
            print(f"Daemon not reachable at ws://{config.host}:{config.port}", file=__import__("sys").stderr)
            return 1
        if not running_in_cwd:
            print("No active task to cancel.", file=__import__("sys").stderr)
            return 1
        if len(running_in_cwd) > 1:
            print("Multiple tasks are running in this directory. Use 'cybervisor cancel <task-id>' to target a specific task.", file=__import__("sys").stderr)
            return 1
        resolved_task_id = cast(str | None, running_in_cwd[0].get("task_id"))
        if resolved_task_id is None:
            print("No active task to cancel.", file=__import__("sys").stderr)
            return 1
    import cybervisor.client as _client_module

    success, message = await _client_module.cancel_task(resolved_task_id, config)
    if success:
        print(message)
        return 0
    print(message, file=__import__("sys").stderr)
    return 1


# ---------------------------------------------------------------------------
# logs
# ---------------------------------------------------------------------------


async def dump_task_logs(task_id: str, config: ClientConfig) -> int:
    """Dump all buffered events for a task as JSON Lines."""
    from cybervisor.client import _connect as __connect, _receive_events as __receive_events

    uri = f"ws://{config.host}:{config.port}"

    msg: dict[str, Any] = {
        "type": EventType.RESUME.value,
        "task_id": task_id,
    }

    try:
        ws = await __connect(uri, config.connect_timeout_seconds)
    except ConnectionError:
        print(f"daemon not reachable at ws://{config.host}:{config.port}", file=__import__("sys").stderr)
        return 1

    try:
        await ws.send(json.dumps(msg))
        chunk_buffer: dict[str, dict[int, dict[str, Any]]] = {}
        async for event in __receive_events(ws):
            if event.type == EventType.EVENT_REPLAY_CHUNK.value:
                chunk_id = event.chunk_id or ""
                if not chunk_id:
                    continue
                if chunk_id not in chunk_buffer:
                    chunk_buffer[chunk_id] = {}
                chunk_data = event.to_dict()
                chunk_buffer[chunk_id][chunk_data.get("chunk_index", 0)] = chunk_data
                chunk_count = chunk_data.get("chunk_count", 1)
                if len(chunk_buffer[chunk_id]) == chunk_count:
                    sorted_chunks = sorted(chunk_buffer[chunk_id].items(), key=lambda x: x[0])
                    for _, chunk in sorted_chunks:
                        for e in chunk.get("events", []):
                            print(json.dumps(e))
                    del chunk_buffer[chunk_id]
                continue
            if event.type == EventType.EVENT_REPLAY.value and event.events:
                for e in event.events:
                    print(json.dumps(e))
        return 0
    except Exception as exc:  # pragma: no cover
        print(f"Connection error: {exc}", file=__import__("sys").stderr)
        return 1
    finally:
        await ws.close()


async def run_logs_command(task_id: str, host: str | None, port: int | None) -> int:
    """Run the logs command."""
    from cybervisor.client import _resolve_config as _cli_resolve_config

    config = _cli_resolve_config(host, port)
    return await dump_task_logs(task_id, config)


# ---------------------------------------------------------------------------
# stop-stage
# ---------------------------------------------------------------------------


async def update_stop_stage(task_id: str | None, stage: str, config: ClientConfig) -> tuple[bool, str]:
    """Update the stop stage of a running task."""
    from cybervisor.client import _connect as __connect, _receive_events as __receive_events

    uri = f"ws://{config.host}:{config.port}"

    msg: dict[str, Any] = {
        "type": EventType.SET_STOP_STAGE.value,
        "stage": stage,
        "cwd": os.getcwd(),
    }
    if task_id:
        msg["task_id"] = task_id

    try:
        ws = await __connect(uri, config.connect_timeout_seconds)
    except ConnectionError:
        return False, f"daemon not reachable at ws://{config.host}:{config.port}"

    try:
        await ws.send(json.dumps(msg))
        async for event in __receive_events(ws):
            if event.type == EventType.STOP_STAGE_UPDATED.value:
                return True, f"Updated stop stage to: {event.stage}"
            if event.type == EventType.ERROR.value:
                code = event.code or "?"
                message = event.message or "unknown error"
                return False, f"[{code}] {message}"
        return False, "No response from daemon"
    except Exception as exc:  # pragma: no cover
        return False, f"Connection error: {exc}"
    finally:
        await ws.close()


async def run_stop_stage_command(
    task_id: str | None,
    stage: str,
    host: str | None,
    port: int | None,
) -> int:
    """Run the stop-stage command."""
    from cybervisor.client import _resolve_config as _cli_resolve_config, _find_running_task_in_cwd as __find_running_task_in_cwd

    config = _cli_resolve_config(host, port)
    resolved_task_id = task_id
    if resolved_task_id is None:
        reachable, running_in_cwd = await __find_running_task_in_cwd(config)
        if not reachable:
            print(f"Daemon not reachable at ws://{config.host}:{config.port}", file=sys.stderr)
            return 1
        if not running_in_cwd:
            print("No active task to set stop stage for.", file=sys.stderr)
            return 1
        if len(running_in_cwd) > 1:
            print("Multiple tasks are running in this directory. Use 'cybervisor stop-stage <task-id> --stage <stage>' to target a specific task.", file=sys.stderr)
            return 1
        resolved_task_id = cast(str | None, running_in_cwd[0].get("task_id"))
        if resolved_task_id is None:
            print("No active task to set stop stage for.", file=sys.stderr)
            return 1
    success, message = await update_stop_stage(resolved_task_id, stage, config)
    if success:
        print(message)
        return 0
    print(message, file=sys.stderr)
    return 1
