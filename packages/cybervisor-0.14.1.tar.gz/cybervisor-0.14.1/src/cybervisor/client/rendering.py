"""Server event rendering for CLI output."""

from __future__ import annotations

from typing import Any

from cybervisor.server_events import EventType, ServerEvent


def render_event(event: ServerEvent) -> tuple[str, str | None]:
    """
    Render a ServerEvent to a human-readable line.

    Returns:
        A tuple of (level, line) where level is "stdout" or "stderr".
        Returns ("skip", None) for events that should not be rendered.
    """
    evt_type = event.type
    if evt_type == EventType.STAGE_START.value:
        stage = event.stage_name or "?"
        attempt = event.attempt or 1
        max_retries = event.max_retries or 3
        iteration_count = event.iteration_count
        max_iterations = event.max_iterations
        if iteration_count is not None and max_iterations is not None and max_iterations > 0:
            line = f"[STAGE_START]    {stage} — attempt {attempt}/{max_retries} (iteration {iteration_count}/{max_iterations})"
        else:
            line = f"[STAGE_START]    {stage} — attempt {attempt}/{max_retries}"
        return "stdout", line

    if evt_type == EventType.STAGE_COMPLETE.value:
        stage = event.stage_name or "?"
        success = event.success
        attempt = event.attempt or 1
        status = "success" if success else "failed"
        line = f"[STAGE_COMPLETE] {stage} — {status} (attempt {attempt})"
        return "stdout", line

    if evt_type == EventType.STAGE_RETRY.value:
        stage = event.stage_name or "?"
        attempt = event.attempt or 1
        max_retries = event.max_retries or 3
        error = event.error or "unknown error"
        line = f"[ERROR] {stage} retry {attempt}/{max_retries}: {error}"
        return "stderr", line

    if evt_type == EventType.STAGE_FAILED.value:
        stage = event.stage_name or "?"
        error = event.error or "unknown error"
        line = f"[ERROR] {stage} failed: {error}"
        return "stderr", line

    if evt_type == EventType.ARTIFACT_VALIDATED.value:
        stage = event.stage_name or "?"
        status = event.artifact_status or "?"
        line = f"[ARTIFACT_VALIDATED] {stage} — status: {status}"
        return "stdout", line

    if evt_type == EventType.ROUTING_DECISION.value:
        stage = event.stage_name or "?"
        next_stage = event.next_stage or "?"
        source = event.decision_source or "?"
        line = f"[ROUTING_DECISION] {stage} → {next_stage} ({source})"
        return "stdout", line

    if evt_type == EventType.PIPELINE_ABORT.value:
        reason = event.reason or "unknown reason"
        line = f"[ERROR] Pipeline aborted: {reason}"
        return "stderr", line

    if evt_type == EventType.RUN_COMPLETE.value:
        success = event.success
        line = f"[RUN_COMPLETE] success={str(success).lower()}"
        return "stdout", line

    if evt_type == EventType.RUN_ACCEPTED.value:
        task_id = event.task_id or "?"
        line = f"[RUN_ACCEPTED]   task-id: {task_id}"
        return "stdout", line

    if evt_type == EventType.ERROR.value:
        code = event.code or "?"
        message = event.message or "unknown error"
        line = f"[ERROR] Server error [{code}]: {message}"
        return "stderr", line

    if evt_type == EventType.PONG.value:
        return "skip", None

    if evt_type == EventType.EVENT_REPLAY.value:
        # Internal event — not rendered directly
        return "skip", None

    if evt_type == EventType.EVENT_REPLAY_CHUNK.value:
        # Internal chunk frame — not rendered directly; reassembled by caller
        return "skip", None

    if evt_type == EventType.STOP_STAGE_UPDATED.value:
        stage = event.stage or "?"
        line = f"[STOP_STAGE]    updated stop stage to: {stage}"
        return "stdout", line

    # Default: skip unknown event types
    return "skip", None
