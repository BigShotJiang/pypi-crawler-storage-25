# cybervisor

`cybervisor` is an autonomous CLI supervisor for development runs. It executes a customizable multi-stage pipeline with Gemini CLI, Claude Code, or Codex, installs runtime hooks for non-interactive execution, and enforces structured stage-result contracts.

## What it does

- Runs a customizable multi-stage pipeline defined in `cybervisor.yaml`
- Enforces structured stage-result contracts with artifact-driven routing
- Installs runtime hooks for fully non-interactive agent execution
- Streams live agent output and persists per-stage logs
- Snapshots and restores agent settings automatically
- Enforces single-instance execution with a daemon-aware lock
- **Daemon mode**: Long-running WebSocket server for headless execution
- **Daemon client commands**: `status`, `submit`, `attach`, `cancel`, `logs`, `stop-stage`

## Requirements

- Python 3.11+
- [`uv`](https://docs.astral.sh/uv/)
- One of:
  - `gemini` on `PATH`
  - `claude` on `PATH`
  - `codex` on `PATH`
- `~/.cybervisor/config.yaml` with verifier settings

## Installation

Install the CLI onto your `PATH`:

```bash
uv tool install cybervisor
```

After installation, verify:

```bash
cybervisor --version
```

To update an existing installation later:

```bash
uv tool upgrade cybervisor
cybervisor --version
```

For the full update guide, run:

```bash
cybervisor docs updating
```

## Quick Start

Initialize the `cybervisor` scaffold in your project:

```bash
cybervisor init
```

Set your global default agent:

```bash
cybervisor use claude
```

Configure your verifier settings in `~/.cybervisor/config.yaml` (created with `0o600` permissions):

```yaml
agent_tool: claude
llm:
  api_key: your-api-key
  # Optional overrides
  # base_url: https://api.openai.com/v1
  # model: gpt-4o

# Per-stage agent tool model overrides (top-level, not under llm)
# stage_models:
#   Spec: claude-sonnet-4-6
#   "Review Code": claude-opus-4-6
```

Verify everything is ready:

```bash
cybervisor doctor
```

Run the supervisor:

```bash
cybervisor "Create a 360 feedback system"
printf "Create a 360 feedback system" | cybervisor run
```

## Usage

```bash
# Run with a prompt
cybervisor "Your task description"
cybervisor run "Your task description"
printf "Your task description" | cybervisor run

# Specify a custom config
cybervisor run "Your task" --config custom.yaml

# Control execution flow
cybervisor run "Your task" --start-stage "Implement"
cybervisor run "Your task" --end-after "Review Code"    # Run up to and including this stage, then stop
cybervisor run "Your task" --end-before "Verify"        # Stop before executing this stage

# Set default agent
cybervisor use gemini

# Validate your configuration
cybervisor validate
cybervisor validate --show-guidance
```

Treat `cybervisor validate` as the local readiness gate before merge or execution. A passing result means the config is not only parseable, but also satisfies the stricter contract-authoring checks for route safety, complete routed examples, and authored prompt/guidance synchronization.

For advanced stage configuration including cleanup paths, max iterations, per-stage model overrides, and contract authoring, see the [Pipeline Authoring Guide](docs/pipeline-authoring.md) and [Configuration Reference](docs/configuration.md).

### Daemon Mode

`cybervisor serve` starts a long-running WebSocket daemon. Once running, use the client subcommands to submit tasks, monitor progress, and manage the pipeline remotely.

```bash
# Start the daemon server (WebSocket on ws://127.0.0.1:8765)
cybervisor serve
cybervisor serve --host 0.0.0.0 --port 9000
cybervisor serve --background   # Run in background via double-fork

# Check daemon connectivity and active tasks (exits 0 when reachable, 1 when not)
cybervisor status
cybervisor status --host 127.0.0.1 --port 8765
# Example output when a task is running:
#   Running task: abc123def456 (stage: Spec, cwd: /workspace/project, bounds: end_stage=Verify)
#   Daemon reachable at ws://127.0.0.1:8765
# Example output when no task is running:
#   No active tasks.
#   Daemon reachable at ws://127.0.0.1:8765
# Example output when daemon is down:
#   Daemon not reachable at ws://127.0.0.1:8765

# Check status of a specific task by ID (matches across all directories)
cybervisor status abc123def456

# Submit a task and stream events until completion
cybervisor submit "Your task description" --config cybervisor.yaml --start-stage Implement
cybervisor submit "Your task" --end-after "Review Code"
cybervisor submit "Your task" --end-before Verify
printf "Your task description" | cybervisor submit          # read prompt from stdin
cat task_prompt.txt | cybervisor submit                     # multi-line prompts preserved
cybervisor submit "Your task" --task-id my-task-123   # explicit task ID
# On submit, the task ID is printed to stderr (e.g. "Task created: abc123def456")
# Use this ID with attach, cancel, logs, or stop-stage

# Reconnect to a running or completed task (auto-detects task in current directory)
cybervisor attach

# Reconnect to a specific task by ID to replay buffered events
cybervisor attach my-task-123

# Cancel an active task (auto-detects task in current directory; errors if zero tasks)
cybervisor cancel

# Cancel a specific task by ID (works from any directory)
cybervisor cancel my-task-123

# Dump all buffered events (non-blocking)
cybervisor logs my-task-123

# Update the stop stage of a running task
cybervisor stop-stage --stage Verify                   # auto-detect task in current directory
cybervisor stop-stage my-task-123 --stage Verify       # explicit task ID

# Override daemon address for any client command
cybervisor submit "task" --host 0.0.0.0 --port 9000
```

**Exit codes for client commands:**
- `0` — success
- `1` — failure (daemon unreachable, task not found, invalid state, etc.)
- `130` — interrupted (SIGINT during `submit` or `attach`)

## Documentation

- [Getting Started](docs/getting-started.md) — Step-by-step tutorial from install to first pipeline run
- [Configuration Reference](docs/configuration.md) — `cybervisor.yaml`, `~/.cybervisor/config.yaml`, stage fields, CLI commands
- [Pipeline Authoring Guide](docs/pipeline-authoring.md) — Designing stages, contracts, routing, and agent prompts
- [Runtime and Daemon](docs/runtime-and-daemon.md) — Hook lifecycle, daemon mode, skill disable/restore, signals, logs
- [WebSocket Protocol](docs/websocket-protocol.md) — Daemon message schema, connection lifecycle, chunking
- [Updating](docs/updating.md) — Install, upgrade, and release workflows
- [Troubleshooting](docs/troubleshooting.md) — Common issues and resolutions

For development and contributing documentation, see [docs/development.md](docs/development.md).
