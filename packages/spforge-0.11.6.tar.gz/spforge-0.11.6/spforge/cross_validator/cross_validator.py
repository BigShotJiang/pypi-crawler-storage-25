import copy
import datetime as _dt
import tempfile
from pathlib import Path

import narwhals.stable.v2 as nw
from narwhals.stable.v1.typing import IntoFrameT

_DISK_SPILL_THRESHOLD = 1_000_000


def _coerce_to_datetime(value, col_dtype):
    """Coerce a min_validation_date value to a type comparable with the column."""
    if not isinstance(value, str):
        return value
    if col_dtype in (nw.Datetime, nw.Date):
        parsed = _dt.datetime.fromisoformat(value)
        if col_dtype == nw.Date:
            return parsed.date()
        return parsed
    return value


def _spill_to_parquet(df_nw, path: Path) -> None:
    """Write a narwhals DataFrame to parquet via its native backend."""
    native = nw.to_native(df_nw)
    try:
        import polars as pl

        if isinstance(native, pl.DataFrame):
            native.write_parquet(path)
            return
    except ImportError:
        pass
    native.to_parquet(path)


def _read_spilled_parquets(paths: list[Path]) -> nw.DataFrame:
    """Read and concat spilled parquet files back into a narwhals DataFrame."""
    import polars as pl

    lazy_frames = [pl.scan_parquet(p) for p in paths]
    combined = pl.concat(lazy_frames).collect(engine="streaming")
    return nw.from_native(combined, eager_only=True)


class MatchKFoldCrossValidator:
    def __init__(
        self,
        match_id_column_name: str,
        date_column_name: str,
        target_column: str,
        estimator,
        prediction_column_name: str,
        n_splits: int = 3,
        min_validation_date: str | None = None,
        features: list[str] | None = None,
        binomial_probabilities_to_index1: bool = True,
    ):
        self.match_id_column_name = match_id_column_name
        self.date_column_name = date_column_name
        self.target_column = target_column
        self.estimator = estimator
        self.prediction_column_name = prediction_column_name
        self.n_splits = n_splits
        self.min_validation_date = min_validation_date
        self.features = features  # Optional: if None, will infer from DataFrame
        self.binomial_probabilities_to_index1 = binomial_probabilities_to_index1

    def _get_features(self, df):
        if self.features is not None:
            return self.features

        # Auto-detect if estimator is AutoPipeline with required_features
        if hasattr(self.estimator, "required_features"):
            return self.estimator.required_features

        # Fallback to current inference logic
        exclude_cols = {
            self.target_column,
            "__match_num",
            self.prediction_column_name,
            self.date_column_name,
            self.match_id_column_name,
        }

        return [c for c in df.columns if c not in exclude_cols]

    def _fit_estimator(self, est, train_df: IntoFrameT):
        features = self._get_features(train_df)
        X = train_df.select(features)
        y = train_df[self.target_column].to_list()
        est.fit(X, y)

    def _predict_smart(self, est, df: IntoFrameT) -> IntoFrameT:
        features = self._get_features(df)
        X = df.select(features)

        if hasattr(est, "predict_proba"):
            try:
                proba = est.predict_proba(X)

                if self.binomial_probabilities_to_index1:
                    if getattr(proba, "ndim", None) == 2:
                        n_cols = proba.shape[1]
                        values = proba[:, 1] if n_cols == 2 else proba.tolist()
                    else:
                        values = proba
                else:
                    values = proba.tolist() if getattr(proba, "ndim", None) == 2 else proba

            except AttributeError:
                values = est.predict(X)
        else:
            values = est.predict(X)

        out = df.with_columns(
            nw.new_series(
                name=self.prediction_column_name,
                values=values,
                backend=nw.get_native_namespace(df),
            )
        )

        if hasattr(est, "sklearn_pipeline"):
            Xt = X
            ok = True
            for name, step in est.sklearn_pipeline.steps:
                if name == "est":
                    break
                if not hasattr(step, "transform"):
                    ok = False
                    break
                Xt = step.transform(Xt)

            if ok and Xt is not None:
                feat_df = Xt if isinstance(Xt, nw.DataFrame) else nw.from_native(Xt)

                pred_col = self.prediction_column_name
                keep = [c for c in feat_df.columns if c != pred_col]

                if keep:
                    existing_cols = set(out.columns)
                    for c in keep:
                        if c in existing_cols:
                            continue
                        out = out.with_columns(
                            nw.new_series(
                                name=c,
                                values=feat_df[c].to_numpy(),
                                backend=nw.get_native_namespace(out),
                            )
                        )
                        existing_cols.add(c)

        return out

    @nw.narwhalify
    def generate_validation_df(
        self, df: IntoFrameT, add_training_predictions: bool = False
    ) -> IntoFrameT:
        df = df.sort([self.date_column_name, self.match_id_column_name])

        df = df.with_columns(
            (nw.col(self.match_id_column_name) != nw.col(self.match_id_column_name).shift(1))
            .cum_sum()
            .fill_null(0)
            .alias("__match_num")
        )

        if not self.min_validation_date:
            unique_dates = df[self.date_column_name].unique(maintain_order=True)
            median_number = len(unique_dates) // 2
            self.min_validation_date = unique_dates[median_number]

        min_val_date = _coerce_to_datetime(
            self.min_validation_date, df[self.date_column_name].dtype
        )

        max_m = df["__match_num"].max()
        global_min_m = df["__match_num"].min()
        min_m = df.filter(nw.col(self.date_column_name) >= min_val_date)["__match_num"].min()

        # If min_validation_date is before (or at) the start of the dataset,
        # all data qualifies as validation and the first fold would have no
        # training data.  Fall back to the median-date heuristic so there is
        # always a training portion.
        if min_m <= global_min_m:
            unique_dates = df[self.date_column_name].unique(maintain_order=True)
            median_number = len(unique_dates) // 2
            fallback_date = unique_dates[median_number]
            min_m = df.filter(nw.col(self.date_column_name) >= fallback_date)["__match_num"].min()

        step = (max_m - min_m) // self.n_splits
        if step <= 0:
            step = 1

        use_disk_spill = len(df) >= _DISK_SPILL_THRESHOLD

        if use_disk_spill:
            return self._generate_with_disk_spill(df, min_m, step, add_training_predictions)
        return self._generate_in_memory(df, min_m, step, add_training_predictions)

    def _generate_in_memory(self, df, min_m, step, add_training_predictions: bool):
        results = []
        curr_cut = min_m
        added_train_preds = False

        for i in range(self.n_splits):
            train_df = df.filter(nw.col("__match_num") < curr_cut)
            if len(train_df) == 0:
                raise ValueError("Training data is empty")

            val_df = df.filter(
                (nw.col("__match_num") >= curr_cut) & (nw.col("__match_num") < curr_cut + step)
            )
            if len(val_df) == 0:
                raise ValueError("Val data is empty")

            if i == self.n_splits - 1:
                val_df = df.filter(nw.col("__match_num") >= curr_cut)

            est = copy.deepcopy(self.estimator)
            self._fit_estimator(est, train_df)

            if add_training_predictions and not added_train_preds:
                train_pred_df = self._predict_smart(est, train_df).with_columns(
                    nw.lit(False).alias("is_validation")
                )
                results.append(train_pred_df)
                added_train_preds = True

            pred_df = self._predict_smart(est, val_df).with_columns(
                nw.lit(True).alias("is_validation")
            )
            results.append(pred_df)

            curr_cut += step

        return nw.concat(results).drop("__match_num")

    def _generate_with_disk_spill(self, df, min_m, step, add_training_predictions: bool):
        tmp_dir = tempfile.mkdtemp(prefix="spforge_cv_")
        spilled_paths: list[Path] = []
        curr_cut = min_m
        added_train_preds = False

        try:
            for i in range(self.n_splits):
                train_df = df.filter(nw.col("__match_num") < curr_cut)
                if len(train_df) == 0:
                    raise ValueError("Training data is empty")

                val_df = df.filter(
                    (nw.col("__match_num") >= curr_cut) & (nw.col("__match_num") < curr_cut + step)
                )
                if len(val_df) == 0:
                    raise ValueError("Val data is empty")

                if i == self.n_splits - 1:
                    val_df = df.filter(nw.col("__match_num") >= curr_cut)

                est = copy.deepcopy(self.estimator)
                self._fit_estimator(est, train_df)

                if add_training_predictions and not added_train_preds:
                    train_pred_df = self._predict_smart(est, train_df).with_columns(
                        nw.lit(False).alias("is_validation")
                    )
                    path = Path(tmp_dir) / f"train_fold_{i}.parquet"
                    _spill_to_parquet(train_pred_df, path)
                    spilled_paths.append(path)
                    del train_pred_df
                    added_train_preds = True

                pred_df = self._predict_smart(est, val_df).with_columns(
                    nw.lit(True).alias("is_validation")
                )
                path = Path(tmp_dir) / f"val_fold_{i}.parquet"
                _spill_to_parquet(pred_df, path)
                spilled_paths.append(path)
                del pred_df, est, train_df, val_df

                curr_cut += step

            result = _read_spilled_parquets(spilled_paths)
            result = result.drop("__match_num")

            # Convert back to original backend if needed
            native_result = nw.to_native(result)
            try:
                import pandas as pd

                if isinstance(nw.to_native(df), pd.DataFrame):
                    import polars as pl

                    if isinstance(native_result, pl.DataFrame):
                        native_result = native_result.to_pandas()
                    return nw.from_native(native_result, eager_only=True)
            except ImportError:
                pass

            return result
        finally:
            import shutil

            shutil.rmtree(tmp_dir, ignore_errors=True)
