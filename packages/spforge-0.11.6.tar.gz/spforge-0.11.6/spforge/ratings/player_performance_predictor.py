import math
from abc import ABC, abstractmethod

from spforge.data_structures import (
    MatchPerformance,
    PreMatchPlayerRating,
    PreMatchTeamRating,
)

MATCH_CONTRIBUTION_TO_SUM_VALUE = 1
MODIFIED_RATING_CHANGE_CONSTANT = 1
CERTAIN_SUM = "certain_sum"


def sigmoid_subtract_half_and_multiply2(value: float, x: float) -> float:
    return (1 / (1 + math.exp(-value / x)) - 0.5) * 2


class PlayerPerformancePredictor(ABC):
    requires_centered_target_mean = True

    @abstractmethod
    def reset(self):
        pass

    @abstractmethod
    def predict_performance(
        self,
        player_rating: PreMatchPlayerRating,
        opponent_team_rating: PreMatchTeamRating,
        team_rating: PreMatchTeamRating,
    ) -> float:
        pass

    def predict_performance_value(
        self,
        player_rating_value: float,
        opponent_team_rating_value: float,
        team_rating_value: float,
        match_performance: MatchPerformance | None = None,
        opponent_team_rating: PreMatchTeamRating | None = None,
        team_rating: PreMatchTeamRating | None = None,
    ) -> float:
        if match_performance is None:
            match_performance = MatchPerformance(
                performance_value=None,
                participation_weight=1.0,
                projected_participation_weight=1.0,
            )
        return self.predict_performance(
            player_rating=PreMatchPlayerRating(
                id="",
                rating_value=player_rating_value,
                games_played=0,
                league=None,
                position=None,
                match_performance=match_performance,
            ),
            opponent_team_rating=opponent_team_rating
            or PreMatchTeamRating(id="", players=[], rating_value=opponent_team_rating_value),
            team_rating=team_rating
            or PreMatchTeamRating(id="", players=[], rating_value=team_rating_value),
        )


class PlayerRatingNonOpponentPerformancePredictor(PlayerPerformancePredictor):
    def __init__(
        self,
        coef: float = 0.0015,
        last_sample_count: int = 1500,
        min_count_for_historical_average: int = 200,
    ):
        self.coef = coef
        self.last_sample_count = last_sample_count
        self.min_count_for_historical_average = min_count_for_historical_average
        if self.min_count_for_historical_average < 1:
            raise ValueError("min_count_for_historical_average must be positive")
        self._reference_rating: float | None = None

    def reset(self):
        pass

    def _get_reference_rating(self) -> float:
        """Get reference rating from rating generator, or default to 1000."""
        if self._reference_rating is not None:
            return self._reference_rating
        return 1000

    def predict_performance(
        self,
        player_rating: PreMatchPlayerRating,
        opponent_team_rating: PreMatchTeamRating,
        team_rating: PreMatchTeamRating,
    ) -> float:
        historical_average_rating = self._get_reference_rating()

        net_mean_rating_over_historical_average = (
            player_rating.rating_value - historical_average_rating
        )

        value = self.coef * net_mean_rating_over_historical_average
        prediction = (math.exp(value)) / (1 + math.exp(value))

        return prediction

    def predict_performance_value(
        self,
        player_rating_value: float,
        opponent_team_rating_value: float,
        team_rating_value: float,
        match_performance: MatchPerformance | None = None,
        opponent_team_rating: PreMatchTeamRating | None = None,
        team_rating: PreMatchTeamRating | None = None,
    ) -> float:
        historical_average_rating = self._get_reference_rating()
        net_mean_rating_over_historical_average = player_rating_value - historical_average_rating
        value = self.coef * net_mean_rating_over_historical_average
        return math.exp(value) / (1 + math.exp(value))


class RatingPlayerDifferencePerformancePredictor(PlayerPerformancePredictor):
    # TODO: Performance prediction based on team-players sharing time with.
    def __init__(
        self,
        rating_diff_coef: float = 0.005757,
        rating_diff_team_from_entity_coef: float = 0.0,
        team_rating_diff_coef: float = 0.0,
        max_predict_value: float = 1,
        participation_weight_coef: float | None = None,
    ):
        self.rating_diff_coef = rating_diff_coef
        self.rating_diff_team_from_entity_coef = rating_diff_team_from_entity_coef
        self.team_rating_diff_coef = team_rating_diff_coef
        self.max_predict_value = max_predict_value
        self.participation_weight_coef = participation_weight_coef

    def reset(self):
        pass

    def predict_performance(
        self,
        player_rating: PreMatchPlayerRating,
        opponent_team_rating: PreMatchTeamRating,
        team_rating: PreMatchTeamRating,
    ) -> float:
        if player_rating.match_performance.team_players_playing_time and isinstance(
            player_rating.match_performance.team_players_playing_time, dict
        ):
            weight_team_rating = 0
            sum_playing_time = 0
            for team_player in team_rating.players:
                if (
                    str(team_player.id) in player_rating.match_performance.team_players_playing_time
                    or str(team_player.id)
                    in player_rating.match_performance.team_players_playing_time
                ):
                    weight_team_rating += (
                        team_player.rating_value
                        * player_rating.match_performance.team_players_playing_time[
                            str(team_player.id)
                        ]
                    )
                    sum_playing_time += player_rating.match_performance.team_players_playing_time[
                        str(team_player.id)
                    ]

            if sum_playing_time > 0:
                team_rating_value = weight_team_rating / sum_playing_time
            else:
                team_rating_value = team_rating.rating_value

        else:
            team_rating_value = team_rating.rating_value

        if player_rating.match_performance.opponent_players_playing_time and isinstance(
            player_rating.match_performance.opponent_players_playing_time, dict
        ):
            weight_opp_rating = 0
            sum_playing_time = 0
            for opp_player in opponent_team_rating.players:
                if (
                    str(opp_player.id)
                    in player_rating.match_performance.opponent_players_playing_time
                ):
                    weight_opp_rating += (
                        opp_player.rating_value
                        * player_rating.match_performance.opponent_players_playing_time[
                            str(opp_player.id)
                        ]
                    )
                    sum_playing_time += (
                        player_rating.match_performance.opponent_players_playing_time[
                            str(opp_player.id)
                        ]
                    )
            if sum_playing_time > 0:
                opp_rating_value = weight_opp_rating / sum_playing_time
            else:
                opp_rating_value = opponent_team_rating.rating_value

        else:
            opp_rating_value = opponent_team_rating.rating_value

        rating_difference = player_rating.rating_value - opp_rating_value

        rating_diff_team_from_entity = team_rating_value - player_rating.rating_value
        team_rating_diff = team_rating_value - opp_rating_value

        value = (
            self.rating_diff_coef * rating_difference
            + self.rating_diff_team_from_entity_coef * rating_diff_team_from_entity
            + team_rating_diff * self.team_rating_diff_coef
        )

        prediction = (math.exp(value)) / (1 + math.exp(value))

        if prediction > self.max_predict_value:
            return self.max_predict_value
        elif prediction < (1 - self.max_predict_value):
            return 1 - self.max_predict_value

        return prediction

    def predict_performance_value(
        self,
        player_rating_value: float,
        opponent_team_rating_value: float,
        team_rating_value: float,
        match_performance: MatchPerformance | None = None,
        opponent_team_rating: PreMatchTeamRating | None = None,
        team_rating: PreMatchTeamRating | None = None,
    ) -> float:
        if (
            match_performance is not None
            and (
                match_performance.team_players_playing_time
                or match_performance.opponent_players_playing_time
            )
            and opponent_team_rating is not None
            and team_rating is not None
        ):
            return self.predict_performance(
                player_rating=PreMatchPlayerRating(
                    id="",
                    rating_value=player_rating_value,
                    games_played=0,
                    league=None,
                    position=None,
                    match_performance=match_performance,
                ),
                opponent_team_rating=opponent_team_rating,
                team_rating=team_rating,
            )

        rating_difference = player_rating_value - opponent_team_rating_value
        rating_diff_team_from_entity = team_rating_value - player_rating_value
        team_rating_diff = team_rating_value - opponent_team_rating_value

        value = (
            self.rating_diff_coef * rating_difference
            + self.rating_diff_team_from_entity_coef * rating_diff_team_from_entity
            + team_rating_diff * self.team_rating_diff_coef
        )

        prediction = math.exp(value) / (1 + math.exp(value))
        if prediction > self.max_predict_value:
            return self.max_predict_value
        if prediction < (1 - self.max_predict_value):
            return 1 - self.max_predict_value
        return prediction


class LinearRatingDifferencePerformancePredictor(PlayerPerformancePredictor):
    requires_centered_target_mean = False

    def __init__(
        self,
        rating_diff_coef: float = 0.001,
        rating_diff_team_from_entity_coef: float = 0.0,
        team_rating_diff_coef: float = 0.0,
        intercept: float = 0.5,
        min_predict_value: float = 0.0,
        max_predict_value: float = 1.0,
    ):
        self.rating_diff_coef = rating_diff_coef
        self.rating_diff_team_from_entity_coef = rating_diff_team_from_entity_coef
        self.team_rating_diff_coef = team_rating_diff_coef
        self.intercept = intercept
        self.min_predict_value = min_predict_value
        self.max_predict_value = max_predict_value

    def reset(self):
        pass

    def _predict_from_values(
        self,
        *,
        player_rating_value: float,
        opponent_team_rating_value: float,
        team_rating_value: float,
    ) -> float:
        rating_difference = player_rating_value - opponent_team_rating_value
        rating_diff_team_from_entity = team_rating_value - player_rating_value
        team_rating_diff = team_rating_value - opponent_team_rating_value
        prediction = (
            self.intercept
            + self.rating_diff_coef * rating_difference
            + self.rating_diff_team_from_entity_coef * rating_diff_team_from_entity
            + self.team_rating_diff_coef * team_rating_diff
        )
        return float(min(max(prediction, self.min_predict_value), self.max_predict_value))

    def predict_performance(
        self,
        player_rating: PreMatchPlayerRating,
        opponent_team_rating: PreMatchTeamRating,
        team_rating: PreMatchTeamRating,
    ) -> float:
        return self._predict_from_values(
            player_rating_value=player_rating.rating_value,
            opponent_team_rating_value=opponent_team_rating.rating_value,
            team_rating_value=team_rating.rating_value,
        )

    def predict_performance_value(
        self,
        player_rating_value: float,
        opponent_team_rating_value: float,
        team_rating_value: float,
        match_performance: MatchPerformance | None = None,
        opponent_team_rating: PreMatchTeamRating | None = None,
        team_rating: PreMatchTeamRating | None = None,
    ) -> float:
        _ = match_performance, opponent_team_rating, team_rating
        return self._predict_from_values(
            player_rating_value=player_rating_value,
            opponent_team_rating_value=opponent_team_rating_value,
            team_rating_value=team_rating_value,
        )


class RatingMeanPerformancePredictor(PlayerPerformancePredictor):
    def __init__(
        self,
        coef: float = 0.005757,
        max_predict_value: float = 1,
        last_sample_count: int = 1500,
    ):
        self.coef = coef
        self.max_predict_value = max_predict_value
        self.last_sample_count = last_sample_count
        self.sum_ratings: list[float] = []

    def reset(self):
        self.sum_ratings = []

    def predict_performance(
        self,
        player_rating: PreMatchPlayerRating,
        opponent_team_rating: PreMatchTeamRating,
        team_rating: PreMatchTeamRating,
    ) -> float:
        self.sum_ratings.append(player_rating.rating_value)
        start_index = max(0, len(self.sum_ratings) - self.last_sample_count)
        self.sum_ratings = self.sum_ratings[start_index:]
        historical_average_rating = sum(self.sum_ratings) / len(self.sum_ratings)
        net_mean_rating_over_historical_average = (
            player_rating.rating_value * 0.5
            + opponent_team_rating.rating_value * 0.5
            - historical_average_rating
        )

        value = self.coef * net_mean_rating_over_historical_average
        prediction = (math.exp(value)) / (1 + math.exp(value))
        if prediction > self.max_predict_value:
            return self.max_predict_value
        elif prediction < (1 - self.max_predict_value):
            return 1 - self.max_predict_value
        return prediction

    def predict_performance_value(
        self,
        player_rating_value: float,
        opponent_team_rating_value: float,
        team_rating_value: float,
        match_performance: MatchPerformance | None = None,
        opponent_team_rating: PreMatchTeamRating | None = None,
        team_rating: PreMatchTeamRating | None = None,
    ) -> float:
        self.sum_ratings.append(player_rating_value)
        start_index = max(0, len(self.sum_ratings) - self.last_sample_count)
        self.sum_ratings = self.sum_ratings[start_index:]
        historical_average_rating = sum(self.sum_ratings) / len(self.sum_ratings)
        net_mean_rating_over_historical_average = (
            player_rating_value * 0.5 + opponent_team_rating_value * 0.5 - historical_average_rating
        )

        value = self.coef * net_mean_rating_over_historical_average
        prediction = math.exp(value) / (1 + math.exp(value))
        if prediction > self.max_predict_value:
            return self.max_predict_value
        if prediction < (1 - self.max_predict_value):
            return 1 - self.max_predict_value
        return prediction
