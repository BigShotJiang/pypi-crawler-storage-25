# player_rating_generator.py
from __future__ import annotations

import json
import logging
import math
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Literal

import narwhals.stable.v2 as nw
import polars as pl
from narwhals.stable.v2 import DataFrame
from narwhals.stable.v2.typing import IntoFrameT

from spforge.data_structures import (
    ColumnNames,
    MatchPlayer,
    PlayerRating,
    PlayerRatingsResult,
    PreMatchPlayersCollection,
)
from spforge.feature_generator._utils import to_polars
from spforge.performance_transformers._performance_manager import ColumnWeight, PerformanceManager
from spforge.ratings._base import RatingGenerator, RatingKnownFeatures, RatingUnknownFeatures
from spforge.ratings.start_rating_generator import StartRatingGenerator
from spforge.ratings.utils import (
    add_opp_team_rating,
    add_player_opponent_mean_projected,
    add_rating_difference_projected,
    add_rating_mean_projected,
    add_team_rating,
    add_team_rating_projected,
)

PLAYER_STATS = "__PLAYER_STATS"
_SCALED_PW = "__scaled_participation_weight__"
_SCALED_PPW = "__scaled_projected_participation_weight__"
_SCALED_DPW = "__scaled_defense_participation_weight__"
_SCALED_PDPW = "__scaled_projected_defense_participation_weight__"

_MIN_CALIBRATION_SAMPLES = 100


@dataclass(slots=True)
class _MatchPerformanceView:
    performance_value: float | None
    participation_weight: float | None
    projected_participation_weight: float
    defense_participation_weight: float | None = None
    projected_defense_participation_weight: float | None = None
    defense_performance_value: float | None = None
    team_players_playing_time: dict[str, float] | None = None
    opponent_players_playing_time: dict[str, float] | None = None


@dataclass(slots=True)
class _PreMatchPlayerView:
    id: str
    rating_value: float
    games_played: int
    league: str | None
    position: str | None
    match_performance: _MatchPerformanceView
    other: dict[str, Any] | None = None


@dataclass(slots=True)
class _PreMatchTeamView:
    id: str
    players: list[_PreMatchPlayerView]
    rating_value: float


class PlayerRatingGenerator(RatingGenerator):
    """
    Offense/Defense version:

    Player OFF rating is updated from the player's own performance_column.
    Player DEF rating is updated from a derived defensive performance:
        def_perf(team) = 1 - off_perf(opponent_team)
    which is then applied to all players on that team in that match.

    Predictions:
      - player offense vs opponent TEAM defense
      - player defense vs opponent TEAM offense
    """

    def __init__(
        self,
        performance_column: str,
        performance_weights: list[ColumnWeight | dict[str, float]] | None = None,
        performance_manager: PerformanceManager | None = None,
        auto_scale_performance: bool = False,
        performance_predictor: Literal[
            "difference", "mean", "ignore_opponent", "linear_difference"
        ] = "difference",
        use_off_def_split: bool = True,
        rating_change_multiplier_offense: float = 50,
        rating_change_multiplier_defense: float = 50,
        confidence_days_ago_multiplier: float = 0.06,
        confidence_max_days: int = 90,
        confidence_value_denom: float = 140,
        confidence_max_sum: float = 150,
        confidence_weight: float = 0.9,
        features_out: list[RatingKnownFeatures] | None = None,
        non_predictor_features_out: list[RatingKnownFeatures | RatingUnknownFeatures] | None = None,
        min_rating_change_multiplier_ratio: float = 0.1,
        league_rating_change_update_threshold: float = 100,
        league_rating_adjustor_multiplier: float = 0.05,
        team_id_change_confidence_sum_decrease: float = 3,
        start_league_ratings: dict[str, float] | None = None,
        start_league_quantile: float = 0.2,
        start_min_count_for_percentiles: int = 50,
        start_team_rating_subtract: float = 80,
        start_team_weight: float = 0,
        start_max_days_ago_league_entities: int = 600,
        start_min_match_count_team_rating: int = 2,
        start_harcoded_start_rating: float | None = None,
        column_names: ColumnNames | None = None,
        output_suffix: str | None = None,
        scale_participation_weights: bool = False,
        auto_scale_participation_weights: bool = True,
        rating_mean_adjustment_enabled: bool | None = None,
        rating_mean_adjustment_target: float | None = None,
        rating_mean_adjustment_check_frequency: int = 50,
        rating_mean_adjustment_active_days: int = 250,
        defense_performance_column: str | None = None,
        auto_scale_defense_performance: bool = False,
        defense_performance_weights: list[ColumnWeight] | None = None,
        defense_performance_manager: PerformanceManager | None = None,
        defense_lower_is_better: bool = False,
        extra_granularity: list[str] | None = None,
        **kwargs: Any,
    ):
        super().__init__(
            performance_column=performance_column,
            column_names=column_names,
            output_suffix=output_suffix,
            rating_change_multiplier_offense=rating_change_multiplier_offense,
            rating_change_multiplier_defense=rating_change_multiplier_defense,
            confidence_days_ago_multiplier=confidence_days_ago_multiplier,
            confidence_max_days=confidence_max_days,
            confidence_value_denom=confidence_value_denom,
            confidence_max_sum=confidence_max_sum,
            confidence_weight=confidence_weight,
            min_rating_change_multiplier_ratio=min_rating_change_multiplier_ratio,
            team_id_change_confidence_sum_decrease=team_id_change_confidence_sum_decrease,
            features_out=features_out,  # unsuffixed (enums)
            performance_manager=performance_manager,
            auto_scale_performance=auto_scale_performance,
            performance_predictor=performance_predictor,
            performance_weights=performance_weights,
            non_predictor_features_out=non_predictor_features_out,  # unsuffixed (enums)
            league_rating_adjustor_multiplier=league_rating_adjustor_multiplier,
            league_rating_change_update_threshold=league_rating_change_update_threshold,
            **kwargs,
        )

        self.PLAYER_OFF_RATING_COL = self._suffix(str(RatingKnownFeatures.PLAYER_OFF_RATING))
        self.PLAYER_DEF_RATING_COL = self._suffix(str(RatingKnownFeatures.PLAYER_DEF_RATING))

        self.PLAYER_PRED_OFF_PERF_COL = self._suffix(
            str(RatingUnknownFeatures.PLAYER_PREDICTED_OFF_PERFORMANCE)
        )
        self.PLAYER_PRED_DEF_PERF_COL = self._suffix(
            str(RatingUnknownFeatures.PLAYER_PREDICTED_DEF_PERFORMANCE)
        )

        self.PLAYER_RATING_COL = self._suffix(str(RatingKnownFeatures.PLAYER_RATING))
        self.PLAYER_PRED_PERF_COL = self._suffix(
            str(RatingUnknownFeatures.PLAYER_PREDICTED_PERFORMANCE)
        )

        self.TEAM_RATING_PROJ_COL = self._suffix(str(RatingKnownFeatures.TEAM_RATING_PROJECTED))
        self.OPP_RATING_PROJ_COL = self._suffix(str(RatingKnownFeatures.OPPONENT_RATING_PROJECTED))
        self.DIFF_PROJ_COL = self._suffix(str(RatingKnownFeatures.TEAM_RATING_DIFFERENCE_PROJECTED))
        self.PLAYER_DIFF_PROJ_COL = self._suffix(
            str(RatingKnownFeatures.PLAYER_RATING_DIFFERENCE_PROJECTED)
        )
        self.MEAN_PROJ_COL = self._suffix(str(RatingKnownFeatures.RATING_MEAN_PROJECTED))
        self.PLAYER_DIFF_FROM_TEAM_PROJ_COL = self._suffix(
            str(RatingKnownFeatures.PLAYER_RATING_DIFFERENCE_FROM_TEAM_PROJECTED)
        )
        self.PLAYER_OPP_MEAN_PROJ_COL = self._suffix(
            str(RatingKnownFeatures.PLAYER_OPPONENT_MEAN_PROJECTED)
        )

        self.TEAM_OFF_RATING_PROJ_COL = self._suffix(
            str(RatingKnownFeatures.TEAM_OFF_RATING_PROJECTED)
        )
        self.TEAM_DEF_RATING_PROJ_COL = self._suffix(
            str(RatingKnownFeatures.TEAM_DEF_RATING_PROJECTED)
        )
        self.OPP_OFF_RATING_PROJ_COL = self._suffix(
            str(RatingKnownFeatures.OPPONENT_OFF_RATING_PROJECTED)
        )
        self.OPP_DEF_RATING_PROJ_COL = self._suffix(
            str(RatingKnownFeatures.OPPONENT_DEF_RATING_PROJECTED)
        )

        self.TEAM_RATING_COL = self._suffix(str(RatingUnknownFeatures.TEAM_RATING))
        self.OPP_RATING_COL = self._suffix(str(RatingUnknownFeatures.OPPONENT_RATING))
        self.DIFF_COL = self._suffix(str(RatingUnknownFeatures.TEAM_RATING_DIFFERENCE))

        self.start_league_ratings = start_league_ratings
        self.start_league_quantile = start_league_quantile
        self.start_min_count_for_percentiles = start_min_count_for_percentiles
        self.start_team_rating_subtract = start_team_rating_subtract
        self.start_team_weight = start_team_weight
        self.start_max_days_ago_league_entities = start_max_days_ago_league_entities
        self.start_min_match_count_team_rating = start_min_match_count_team_rating
        self.start_hardcoded_start_rating = start_harcoded_start_rating

        if hasattr(self._performance_predictor, "_reference_rating"):
            effective_start = self.start_hardcoded_start_rating

            if effective_start is None and self.start_league_ratings:
                league_ratings = list(self.start_league_ratings.values())
                effective_start = sum(league_ratings) / len(league_ratings)

            if effective_start is None:
                effective_start = 1000

            self._performance_predictor._reference_rating = effective_start

        self.team_id_change_confidence_sum_decrease = team_id_change_confidence_sum_decrease
        self.column_names = column_names
        self.extra_granularity: list[str] = list(extra_granularity) if extra_granularity else []

        self.use_off_def_split = bool(use_off_def_split)
        self.scale_participation_weights = bool(scale_participation_weights)
        self.auto_scale_participation_weights = bool(auto_scale_participation_weights)
        self._participation_weight_max: float | None = None
        self._projected_participation_weight_max: float | None = None
        self._defense_participation_weight_max: float | None = None
        self._projected_defense_participation_weight_max: float | None = None

        self._player_off_ratings: dict[str, PlayerRating] = {}
        self._player_def_ratings: dict[str, PlayerRating] = {}

        if rating_mean_adjustment_enabled is not None:
            self._rating_mean_adjustment_enabled = bool(rating_mean_adjustment_enabled)
        else:
            # Disable by default for ignore_opponent predictor
            self._rating_mean_adjustment_enabled = performance_predictor != "ignore_opponent"
        self._rating_mean_adjustment_check_frequency = int(rating_mean_adjustment_check_frequency)
        self._rating_mean_adjustment_active_days = int(rating_mean_adjustment_active_days)
        self._matches_since_last_adjustment_check: int = 0

        if rating_mean_adjustment_target is not None:
            self._rating_mean_adjustment_target = float(rating_mean_adjustment_target)
        elif self.start_hardcoded_start_rating is not None:
            self._rating_mean_adjustment_target = float(self.start_hardcoded_start_rating)
        elif self.start_league_ratings:
            league_vals = list(self.start_league_ratings.values())
            self._rating_mean_adjustment_target = sum(league_vals) / len(league_vals)
        else:
            self._rating_mean_adjustment_target = 1000.0

        self.defense_performance_column = defense_performance_column
        self.auto_scale_defense_performance = bool(auto_scale_defense_performance)
        self.defense_performance_weights = defense_performance_weights
        self.defense_lower_is_better = bool(defense_lower_is_better)
        self._defense_performance_manager = self._create_defense_performance_manager(
            defense_performance_manager
        )
        if self._defense_performance_manager:
            self.defense_performance_column = self._defense_performance_manager.performance_column

        self.start_rating_generator = StartRatingGenerator(
            league_ratings=self.start_league_ratings,
            league_quantile=self.start_league_quantile,
            min_match_count_team_rating=self.start_min_match_count_team_rating,
            team_weight=self.start_team_weight,
            team_rating_subtract=self.start_team_rating_subtract,
            max_days_ago_league_entities=self.start_max_days_ago_league_entities,
            min_count_for_percentiles=self.start_min_count_for_percentiles,
            harcoded_start_rating=self.start_hardcoded_start_rating,
        )

    def _create_defense_performance_manager(
        self, defense_performance_manager: PerformanceManager | None
    ) -> PerformanceManager | None:
        if defense_performance_manager:
            if (
                self.defense_performance_column
                and self.defense_performance_column
                != defense_performance_manager.performance_column
            ):
                defense_performance_manager.performance_column = self.defense_performance_column
            elif not self.defense_performance_column:
                self.defense_performance_column = defense_performance_manager.performance_column
            return defense_performance_manager

        if not self.defense_performance_column:
            return None

        if self.defense_performance_weights:
            weights = self.defense_performance_weights
            if isinstance(weights[0], dict):
                converted = []
                for w in weights:
                    wd = dict(w)
                    if "col" in wd and "name" not in wd:
                        wd["name"] = wd.pop("col")
                    converted.append(ColumnWeight(**wd))
                weights = converted
            from spforge.performance_transformers._performance_manager import (
                PerformanceWeightsManager,
            )

            return PerformanceWeightsManager(
                weights=weights,
                performance_column=self.defense_performance_column,
            )

        if self.auto_scale_defense_performance:
            return PerformanceManager(
                features=[self.defense_performance_column],
                performance_column=self.defense_performance_column,
            )

        return None

    @to_polars
    @nw.narwhalify
    def fit_transform(
        self,
        df: IntoFrameT,
        column_names: ColumnNames | None = None,
    ) -> DataFrame | IntoFrameT:
        pl_df, was_lazy = self._to_polars_eager(df)
        df = nw.from_native(pl_df)

        self.column_names = column_names if column_names else self.column_names
        self._maybe_enable_participation_weight_scaling(df)
        self._set_participation_weight_max(df)

        if self._defense_performance_manager:
            df = nw.from_native(self._defense_performance_manager.fit_transform(df))
            if self.defense_lower_is_better:
                df = df.with_columns(
                    (1.0 - nw.col(self.defense_performance_column)).alias(
                        self.defense_performance_column
                    )
                )

        # Calibration pass for ignore_opponent predictor
        if self.performance_predictor == "ignore_opponent":
            self._calibrate_reference_rating(df)

        # super().fit_transform already handles was_lazy via _to_polars_eager,
        # but df is guaranteed eager here so it won't double-collect
        result = super().fit_transform(df, column_names)
        native_result = (
            result if isinstance(result, (pl.DataFrame, pl.LazyFrame)) else nw.to_native(result)
        )
        if was_lazy and isinstance(native_result, pl.DataFrame):
            return native_result.lazy()
        return result

    def _reset_rating_state(self) -> None:
        """Clear all accumulated rating state for re-processing."""
        self._player_off_ratings = {}
        self._player_def_ratings = {}
        self._matches_since_last_adjustment_check = 0
        self.start_rating_generator.reset()
        self._performance_predictor.reset()

    def _apply_rating_mean_adjustment(self, current_day_number: int) -> None:
        """Adjust active player ratings to maintain target mean."""
        if not self._rating_mean_adjustment_enabled:
            return

        active_ids: list[str] = []
        total_rating = 0.0

        for player_id, off_state in self._player_off_ratings.items():
            if off_state.last_match_day_number is None:
                continue
            days_since = current_day_number - off_state.last_match_day_number
            if days_since <= self._rating_mean_adjustment_active_days:
                active_ids.append(player_id)
                def_state = self._player_def_ratings[player_id]
                total_rating += (off_state.rating_value + def_state.rating_value) / 2

        if not active_ids:
            return

        current_mean = total_rating / len(active_ids)
        adjustment = self._rating_mean_adjustment_target - current_mean

        for player_id in active_ids:
            self._player_off_ratings[player_id].rating_value += adjustment
            self._player_def_ratings[player_id].rating_value += adjustment

    def _run_ratings_pass(self, df: pl.DataFrame) -> None:
        """Run rating computation pass without assembling output DataFrame.

        After this method completes, self._player_off_ratings and
        self._player_def_ratings contain the final computed ratings.
        """
        self._validate_playing_time_columns(df)
        scaled_df = self._scale_participation_weight_columns(df)
        match_df = self._create_match_df(scaled_df)
        self._calculate_ratings(match_df)  # Side effect: populates rating dicts

    def _calibrate_reference_rating(self, df: DataFrame) -> None:
        """Run calibration pass and set reference rating for ignore_opponent predictor."""
        from spforge.ratings.calibration import calibrate_reference_rating

        # Convert to polars for internal processing
        pl_df = df.to_native() if df.implementation.is_polars() else df.to_polars().to_native()

        # First pass: compute ratings
        self._run_ratings_pass(pl_df)

        # Extract ratings for calibration
        ratings = [r.rating_value for r in self._player_off_ratings.values()]

        # Skip calibration on small datasets
        if len(ratings) < _MIN_CALIBRATION_SAMPLES:
            self._reset_rating_state()
            return

        coef = self._performance_predictor.coef

        # Compute bounds from actual rating distribution
        min_r, max_r = min(ratings), max(ratings)
        margin = (max_r - min_r) * 0.5 or 200.0

        try:
            anchor = calibrate_reference_rating(
                ratings=ratings,
                coef=coef,
                target_mean=0.5,
                lo=min_r - margin,
                hi=max_r + margin,
            )
            self._performance_predictor._reference_rating = anchor
        except ValueError:
            pass  # Keep existing reference if calibration fails

        # Reset state for second pass
        self._reset_rating_state()

    def _maybe_enable_participation_weight_scaling(self, df: DataFrame) -> None:
        if self.scale_participation_weights or not self.auto_scale_participation_weights:
            return
        cn = self.column_names
        if not cn:
            return

        pl_df = df.to_native() if df.implementation.is_polars() else df.to_polars().to_native()

        def _out_of_bounds(col_name: str | None) -> bool:
            if not col_name or col_name not in df.columns:
                return False
            col = pl_df[col_name]
            min_val = col.min()
            max_val = col.max()
            if min_val is None or max_val is None:
                return False
            eps = 1e-6
            return min_val < -eps or max_val > (1.0 + eps)

        if (
            _out_of_bounds(cn.participation_weight)
            or _out_of_bounds(cn.projected_participation_weight)
            or _out_of_bounds(cn.defense_participation_weight)
            or _out_of_bounds(cn.projected_defense_participation_weight)
        ):
            self.scale_participation_weights = True
            logging.warning(
                "Auto-scaling participation weights because values exceed [0, 1]. "
                "Set scale_participation_weights=True explicitly to silence this warning."
            )

    def _ensure_player_off(self, player_id: str) -> PlayerRating:
        if player_id not in self._player_off_ratings:
            # create with start generator later; initialize to 0 now; overwritten when needed
            self._player_off_ratings[player_id] = PlayerRating(id=player_id, rating_value=0.0)
        return self._player_off_ratings[player_id]

    def _ensure_player_def(self, player_id: str) -> PlayerRating:
        if player_id not in self._player_def_ratings:
            self._player_def_ratings[player_id] = PlayerRating(id=player_id, rating_value=0.0)
        return self._player_def_ratings[player_id]

    def _applied_multiplier_off(self, state: PlayerRating) -> float:
        return self._applied_multiplier(state, self.rating_change_multiplier_offense)

    def _applied_multiplier_def(self, state: PlayerRating) -> float:
        return self._applied_multiplier(state, self.rating_change_multiplier_defense)

    def _calculate_post_match_confidence_sum(
        self, entity_rating: PlayerRating, day_number: int, particpation_weight: float
    ) -> float:
        return self._post_match_confidence_sum(
            state=entity_rating,
            day_number=day_number,
            participation_weight=particpation_weight,
        )

    def _set_participation_weight_max(self, df: DataFrame) -> None:
        if not self.scale_participation_weights:
            return
        cn = self.column_names
        if not cn:
            return

        pl_df = df.to_native() if df.implementation.is_polars() else df.to_polars().to_native()

        if cn.participation_weight and cn.participation_weight in df.columns:
            q_val = pl_df[cn.participation_weight].quantile(0.99, "linear")
            if q_val is not None:
                self._participation_weight_max = float(q_val)

        if cn.projected_participation_weight and cn.projected_participation_weight in df.columns:
            q_val = pl_df[cn.projected_participation_weight].quantile(0.99, "linear")
            if q_val is not None:
                self._projected_participation_weight_max = float(q_val)
        elif self._participation_weight_max is not None:
            self._projected_participation_weight_max = self._participation_weight_max

        if cn.defense_participation_weight and cn.defense_participation_weight in df.columns:
            q_val = pl_df[cn.defense_participation_weight].quantile(0.99, "linear")
            if q_val is not None:
                self._defense_participation_weight_max = float(q_val)
        elif self._participation_weight_max is not None:
            self._defense_participation_weight_max = self._participation_weight_max

        if (
            cn.projected_defense_participation_weight
            and cn.projected_defense_participation_weight in df.columns
        ):
            q_val = pl_df[cn.projected_defense_participation_weight].quantile(0.99, "linear")
            if q_val is not None:
                self._projected_defense_participation_weight_max = float(q_val)
        elif self._defense_participation_weight_max is not None:
            self._projected_defense_participation_weight_max = (
                self._defense_participation_weight_max
            )
        elif self._projected_participation_weight_max is not None:
            self._projected_defense_participation_weight_max = (
                self._projected_participation_weight_max
            )

    def _scale_participation_weight_columns(self, df: pl.DataFrame) -> pl.DataFrame:
        """Create internal scaled participation weight columns without mutating originals."""
        if not self.scale_participation_weights:
            return df
        if self._participation_weight_max is None or self._participation_weight_max <= 0:
            return df

        cn = self.column_names
        if not cn:
            return df

        if cn.participation_weight and cn.participation_weight in df.columns:
            denom = float(self._participation_weight_max)
            df = df.with_columns(
                (pl.col(cn.participation_weight) / denom).clip(0.0, 1.0).alias(_SCALED_PW)
            )

        if (
            cn.projected_participation_weight
            and cn.projected_participation_weight in df.columns
            and self._projected_participation_weight_max is not None
            and self._projected_participation_weight_max > 0
        ):
            denom = float(self._projected_participation_weight_max)
            df = df.with_columns(
                (pl.col(cn.projected_participation_weight) / denom)
                .clip(0.0, 1.0)
                .alias(_SCALED_PPW)
            )

        if (
            cn.defense_participation_weight
            and cn.defense_participation_weight in df.columns
            and self._defense_participation_weight_max is not None
            and self._defense_participation_weight_max > 0
        ):
            denom = float(self._defense_participation_weight_max)
            df = df.with_columns(
                (pl.col(cn.defense_participation_weight) / denom).clip(0.0, 1.0).alias(_SCALED_DPW)
            )

        if (
            cn.projected_defense_participation_weight
            and cn.projected_defense_participation_weight in df.columns
            and self._projected_defense_participation_weight_max is not None
            and self._projected_defense_participation_weight_max > 0
        ):
            denom = float(self._projected_defense_participation_weight_max)
            df = df.with_columns(
                (pl.col(cn.projected_defense_participation_weight) / denom)
                .clip(0.0, 1.0)
                .alias(_SCALED_PDPW)
            )

        return df

    def _get_participation_weight_col(self) -> str:
        """Get the column name to use for participation weight (scaled if available)."""
        cn = self.column_names
        if self.scale_participation_weights and cn and cn.participation_weight:
            return _SCALED_PW
        return cn.participation_weight if cn else ""

    def _get_projected_participation_weight_col(self) -> str:
        """Get the column name to use for projected participation weight (scaled if available)."""
        cn = self.column_names
        if self.scale_participation_weights and cn and cn.projected_participation_weight:
            return _SCALED_PPW
        return cn.projected_participation_weight if cn else ""

    def _remove_internal_scaled_columns(self, df: pl.DataFrame) -> pl.DataFrame:
        """Remove internal scaled columns before returning."""
        cols_to_drop = [
            c for c in [_SCALED_PW, _SCALED_PPW, _SCALED_DPW, _SCALED_PDPW] if c in df.columns
        ]
        if cols_to_drop:
            df = df.drop(cols_to_drop)
        return df

    def _validate_playing_time_columns(self, df: pl.DataFrame) -> None:
        cn = self.column_names
        if cn.team_players_playing_time and cn.team_players_playing_time not in df.columns:
            raise ValueError(
                f"team_players_playing_time column '{cn.team_players_playing_time}' "
                f"not found in DataFrame. Available columns: {list(df.columns)}"
            )
        if cn.opponent_players_playing_time and cn.opponent_players_playing_time not in df.columns:
            raise ValueError(
                f"opponent_players_playing_time column '{cn.opponent_players_playing_time}' "
                f"not found in DataFrame. Available columns: {list(df.columns)}"
            )

    def _historical_transform(self, df: pl.DataFrame) -> pl.DataFrame:
        self._validate_playing_time_columns(df)
        df = self._scale_participation_weight_columns(df)
        match_df = self._create_match_df(df)
        ratings = self._calculate_ratings(match_df)

        # Keep scaled columns for now - they're needed by _add_rating_features
        cols = [
            c
            for c in df.columns
            if c
            not in (
                self.PLAYER_OFF_RATING_COL,
                self.PLAYER_DEF_RATING_COL,
                self.PLAYER_PRED_OFF_PERF_COL,
                self.PLAYER_PRED_DEF_PERF_COL,
                self.PLAYER_RATING_COL,
                self.PLAYER_PRED_PERF_COL,
            )
        ]

        join_on = [
            self.column_names.player_id,
            self.column_names.match_id,
            self.column_names.team_id,
        ]
        for col in getattr(self, "extra_granularity", []):
            if col in df.columns and col in ratings.columns:
                join_on.append(col)

        df = df.select(cols).join(ratings, on=join_on)

        result = self._add_rating_features(df)
        return self._remove_internal_scaled_columns(result)

    def _future_transform(self, df: pl.DataFrame) -> pl.DataFrame:
        df = self._scale_participation_weight_columns(df)
        match_df = self._create_match_df(df)
        ratings = self._calculate_future_ratings(match_df)

        # Keep scaled columns for now - they're needed by _add_rating_features
        cols = [
            c
            for c in df.columns
            if c
            not in (
                self.PLAYER_OFF_RATING_COL,
                self.PLAYER_DEF_RATING_COL,
                self.PLAYER_PRED_OFF_PERF_COL,
                self.PLAYER_PRED_DEF_PERF_COL,
                self.PLAYER_RATING_COL,
                self.PLAYER_PRED_PERF_COL,
            )
        ]

        join_on = [
            self.column_names.player_id,
            self.column_names.match_id,
            self.column_names.team_id,
        ]
        for col in getattr(self, "extra_granularity", []):
            if col in df.columns and col in ratings.columns:
                join_on.append(col)

        df_with_ratings = df.select(cols).join(ratings, on=join_on, how="left")

        result = self._add_rating_features(df_with_ratings)
        return self._remove_internal_scaled_columns(result)

    def _team_individual_def_mean(self, collection: PreMatchPlayersCollection) -> float | None:
        """Weighted mean of individual defense stats for players in a team."""
        wsum = 0.0
        psum = 0.0
        for p in collection.pre_match_player_ratings:
            val = p.match_performance.defense_performance_value
            if val is not None and math.isfinite(val):
                w = p.match_performance.defense_participation_weight or 1.0
                psum += val * w
                wsum += w
        return psum / wsum if wsum > 0 else None

    def _calculate_ratings(self, match_df: pl.DataFrame) -> pl.DataFrame:
        cn = self.column_names

        pending_team_updates: list[tuple[str, str, float, float, int]] = []

        last_update_id = None

        out = {
            cn.player_id: [],
            cn.match_id: [],
            cn.team_id: [],
            self.PLAYER_OFF_RATING_COL: [],
            self.PLAYER_DEF_RATING_COL: [],
            self.PLAYER_PRED_OFF_PERF_COL: [],
            self.PLAYER_PRED_DEF_PERF_COL: [],
            self.PLAYER_RATING_COL: [],
            self.PLAYER_PRED_PERF_COL: [],
        }
        extra_out_cols = [
            col for col in getattr(self, "extra_granularity", []) if col in match_df.columns
        ]
        for col in extra_out_cols:
            out[col] = []

        for r in match_df.iter_rows(named=True):
            update_id = r[cn.update_match_id]

            if last_update_id is not None and update_id != last_update_id:
                if pending_team_updates:
                    self._apply_player_updates(pending_team_updates)
                    pending_team_updates = []
                last_update_id = update_id
            day_number = int(r["__day_number"])

            team1 = r[cn.team_id]
            team2 = r[f"{cn.team_id}_opponent"]

            c1 = self._create_pre_match_players_collection(
                r=r, stats_col=PLAYER_STATS, day_number=day_number, team_id=team1
            )
            c2 = self._create_pre_match_players_collection(
                r=r, stats_col=f"{PLAYER_STATS}_opponent", day_number=day_number, team_id=team2
            )

            team1_off_perf = self._team_off_perf_from_collection(c1)
            team2_off_perf = self._team_off_perf_from_collection(c2)

            team1_def_perf: float | None = None
            team2_def_perf: float | None = None

            if self.use_off_def_split:
                team1_def_perf = 1.0 - team2_off_perf if team2_off_perf is not None else None
                team2_def_perf = 1.0 - team1_off_perf if team1_off_perf is not None else None
            else:
                team1_def_perf = team1_off_perf
                team2_def_perf = team2_off_perf

            team1_off_rating, team1_def_rating = self._team_off_def_rating_from_collection(c1)
            team2_off_rating, team2_def_rating = self._team_off_def_rating_from_collection(c2)

            team1_mean_def = self._team_individual_def_mean(c1) if self.use_off_def_split else None
            team2_mean_def = self._team_individual_def_mean(c2) if self.use_off_def_split else None

            team1_off_team = _PreMatchTeamView(
                id=team1,
                players=c1.pre_match_player_ratings,
                rating_value=team1_off_rating,
            )
            team2_off_team = _PreMatchTeamView(
                id=team2,
                players=c2.pre_match_player_ratings,
                rating_value=team2_off_rating,
            )
            team1_def_team = _PreMatchTeamView(
                id=team1,
                players=c1.pre_match_def_player_ratings or c1.pre_match_player_ratings,
                rating_value=team1_def_rating,
            )
            team2_def_team = _PreMatchTeamView(
                id=team2,
                players=c2.pre_match_def_player_ratings or c2.pre_match_player_ratings,
                rating_value=team2_def_rating,
            )

            player_updates: list[
                tuple[str, str, float, float, float, float, float, float, int, str | None]
            ] = []

            for pre_player in c1.pre_match_player_ratings:
                pid = pre_player.id

                off_state = self._player_off_ratings[pid]
                def_state = self._player_def_ratings[pid]

                off_pre = float(off_state.rating_value)
                def_pre = float(def_state.rating_value)

                pred_off = self._predict_performance_for_view(
                    player=pre_player,
                    player_rating_value=off_pre,
                    opponent_team=team2_def_team,
                    team=team1_off_team,
                )

                pred_def = self._predict_performance_for_view(
                    player=pre_player,
                    player_rating_value=def_pre,
                    opponent_team=team2_off_team,
                    team=team1_def_team,
                )

                perf_value = pre_player.match_performance.performance_value
                perf_is_valid = perf_value is not None and math.isfinite(float(perf_value))

                if not perf_is_valid:
                    off_change = 0.0
                else:
                    off_perf = float(perf_value)
                    mult_off = self._applied_multiplier_off(off_state)
                    off_change = (
                        (off_perf - float(pred_off))
                        * mult_off
                        * float(pre_player.match_performance.participation_weight)
                    )

                if team1_def_perf is None or (not self.use_off_def_split and not perf_is_valid):
                    def_change = 0.0
                else:
                    def_weight = pre_player.match_performance.defense_participation_weight
                    def_weight_is_valid = def_weight is not None and math.isfinite(
                        float(def_weight)
                    )
                    if not def_weight_is_valid:
                        def_change = 0.0
                    else:
                        individual_def = pre_player.match_performance.defense_performance_value
                        if (
                            individual_def is not None
                            and math.isfinite(individual_def)
                            and team1_mean_def is not None
                        ):
                            deviation = individual_def - team1_mean_def
                            def_perf = max(0.0, min(1.0, float(team1_def_perf) + deviation))
                        else:
                            def_perf = float(team1_def_perf)

                        if not self.use_off_def_split:
                            pred_def = pred_off
                            def_perf = float(perf_value)

                        mult_def = self._applied_multiplier_def(def_state)
                        def_change = (def_perf - float(pred_def)) * mult_def * float(def_weight)

                if math.isnan(off_change) or math.isnan(def_change):
                    raise ValueError(
                        f"NaN player rating change for player_id={pid}, match_id={r[cn.match_id]}"
                    )

                player_updates.append(
                    (
                        pid,
                        team1,
                        off_pre,
                        def_pre,
                        float(pred_off),
                        float(pred_def),
                        float(off_change),
                        float(def_change),
                        day_number,
                        pre_player.league,
                    )
                )

            for pre_player in c2.pre_match_player_ratings:
                pid = pre_player.id

                off_state = self._player_off_ratings[pid]
                def_state = self._player_def_ratings[pid]

                off_pre = float(off_state.rating_value)
                def_pre = float(def_state.rating_value)

                pred_off = self._predict_performance_for_view(
                    player=pre_player,
                    player_rating_value=off_pre,
                    opponent_team=team1_def_team,
                    team=team2_off_team,
                )

                pred_def = self._predict_performance_for_view(
                    player=pre_player,
                    player_rating_value=def_pre,
                    opponent_team=team1_off_team,
                    team=team2_def_team,
                )

                perf_value = pre_player.match_performance.performance_value
                perf_is_valid = perf_value is not None and math.isfinite(float(perf_value))

                if not perf_is_valid:
                    off_change = 0.0
                else:
                    off_perf = float(perf_value)
                    mult_off = self._applied_multiplier_off(off_state)
                    off_change = (
                        (off_perf - float(pred_off))
                        * mult_off
                        * float(pre_player.match_performance.participation_weight)
                    )

                if team2_def_perf is None or (not self.use_off_def_split and not perf_is_valid):
                    def_change = 0.0
                else:
                    def_weight = pre_player.match_performance.defense_participation_weight
                    def_weight_is_valid = def_weight is not None and math.isfinite(
                        float(def_weight)
                    )
                    if not def_weight_is_valid:
                        def_change = 0.0
                    else:
                        individual_def = pre_player.match_performance.defense_performance_value
                        if (
                            individual_def is not None
                            and math.isfinite(individual_def)
                            and team2_mean_def is not None
                        ):
                            deviation = individual_def - team2_mean_def
                            def_perf = max(0.0, min(1.0, float(team2_def_perf) + deviation))
                        else:
                            def_perf = float(team2_def_perf)

                        if not self.use_off_def_split:
                            pred_def = pred_off
                            def_perf = float(perf_value)

                        mult_def = self._applied_multiplier_def(def_state)
                        def_change = (def_perf - float(pred_def)) * mult_def * float(def_weight)

                if math.isnan(off_change) or math.isnan(def_change):
                    raise ValueError(
                        f"NaN player rating change for player_id={pid}, match_id={r[cn.match_id]}"
                    )

                player_updates.append(
                    (
                        pid,
                        team2,
                        off_pre,
                        def_pre,
                        float(pred_off),
                        float(pred_def),
                        float(off_change),
                        float(def_change),
                        day_number,
                        pre_player.league,
                    )
                )

            match_id = r[cn.match_id]
            for (
                pid,
                team_id,
                off_pre,
                def_pre,
                pred_off,
                pred_def,
                _off_change,
                _def_change,
                _dn,
                _league,
            ) in player_updates:
                out[cn.player_id].append(pid)
                out[cn.match_id].append(match_id)
                out[cn.team_id].append(team_id)
                for col in extra_out_cols:
                    out[col].append(r[col])

                out[self.PLAYER_OFF_RATING_COL].append(off_pre)
                out[self.PLAYER_DEF_RATING_COL].append(def_pre)
                out[self.PLAYER_PRED_OFF_PERF_COL].append(pred_off)
                out[self.PLAYER_PRED_DEF_PERF_COL].append(pred_def)

                out[self.PLAYER_RATING_COL].append(off_pre)
                out[self.PLAYER_PRED_PERF_COL].append(pred_off)

            for (
                pid,
                team_id,
                off_pre,
                _def_pre,
                _pred_off,
                _pred_def,
                off_change,
                def_change,
                dn,
                league,
            ) in player_updates:
                pending_team_updates.append(
                    (pid, team_id, off_pre, off_change, def_change, dn, league)
                )

            if last_update_id is None:
                last_update_id = update_id

        if pending_team_updates:
            self._apply_player_updates(pending_team_updates)

        return pl.DataFrame(out, strict=False)

    def _apply_player_updates(
        self, updates: list[tuple[str, str, float, float, float, int, str | None]]
    ) -> None:
        max_days = self.confidence_max_days
        days_multiplier = self.confidence_days_ago_multiplier
        confidence_max_sum = self.confidence_max_sum
        start_rating_generator = self.start_rating_generator

        for player_id, team_id, pre_rating, off_change, def_change, day_number, league in updates:
            off_state = self._player_off_ratings[player_id]
            if off_state.last_match_day_number is None:
                off_days_ago = 0.0
            else:
                off_days_ago = float(day_number - off_state.last_match_day_number)
            off_confidence = (
                -min(off_days_ago, max_days) * days_multiplier + off_state.confidence_sum + 1.0
            )
            off_state.confidence_sum = max(0.0, min(float(off_confidence), confidence_max_sum))
            off_state.rating_value += float(off_change)
            off_state.games_played += 1.0
            off_state.last_match_day_number = int(day_number)
            off_state.most_recent_team_id = team_id

            def_state = self._player_def_ratings[player_id]
            if def_state.last_match_day_number is None:
                def_days_ago = 0.0
            else:
                def_days_ago = float(day_number - def_state.last_match_day_number)
            def_confidence = (
                -min(def_days_ago, max_days) * days_multiplier + def_state.confidence_sum + 1.0
            )
            def_state.confidence_sum = max(0.0, min(float(def_confidence), confidence_max_sum))
            def_state.rating_value += float(def_change)
            def_state.games_played += 1.0
            def_state.last_match_day_number = int(day_number)
            def_state.most_recent_team_id = team_id

            start_rating_generator.update_player_rating(
                player_id=player_id,
                day_number=day_number,
                league=league,
                pre_match_rating_value=pre_rating,
                rating_change_value=off_change,
            )

        self._matches_since_last_adjustment_check += 1
        if (
            self._rating_mean_adjustment_enabled
            and self._matches_since_last_adjustment_check
            >= self._rating_mean_adjustment_check_frequency
        ):
            last_day_number = updates[-1][5] if updates else 0
            self._apply_rating_mean_adjustment(last_day_number)
            self._matches_since_last_adjustment_check = 0

    def _predict_performance_for_view(
        self,
        player: _PreMatchPlayerView,
        player_rating_value: float,
        opponent_team: _PreMatchTeamView,
        team: _PreMatchTeamView,
    ) -> float:
        return self._performance_predictor.predict_performance_value(
            player_rating_value=player_rating_value,
            opponent_team_rating_value=opponent_team.rating_value,
            team_rating_value=team.rating_value,
            match_performance=player.match_performance,
            opponent_team_rating=opponent_team,
            team_rating=team,
        )

    def _add_rating_features(self, df: pl.DataFrame) -> pl.DataFrame:
        cols_to_add = set((self._features_out or []) + (self.non_predictor_features_out or []))

        cn = self.column_names
        extra_granularity = [
            col for col in getattr(self, "extra_granularity", []) if col in df.columns
        ]

        if (
            self.TEAM_OFF_RATING_PROJ_COL in cols_to_add
            or self.TEAM_RATING_PROJ_COL in cols_to_add
            or self.OPP_OFF_RATING_PROJ_COL in cols_to_add
            or self.OPP_RATING_PROJ_COL in cols_to_add
            or self.DIFF_PROJ_COL in cols_to_add
            or self.MEAN_PROJ_COL in cols_to_add
            or self.PLAYER_DIFF_FROM_TEAM_PROJ_COL in cols_to_add
        ):
            df = add_team_rating_projected(
                df=df,
                column_names=cn,
                player_rating_col=self.PLAYER_OFF_RATING_COL,
                team_rating_out=self.TEAM_OFF_RATING_PROJ_COL,
                extra_granularity=extra_granularity,
            )

        if (
            self.TEAM_DEF_RATING_PROJ_COL in cols_to_add
            or self.OPP_DEF_RATING_PROJ_COL in cols_to_add
            or self.OPP_RATING_PROJ_COL in cols_to_add
            or self.DIFF_PROJ_COL in cols_to_add
            or self.PLAYER_DIFF_PROJ_COL in cols_to_add
            or self.PLAYER_OPP_MEAN_PROJ_COL in cols_to_add
        ):
            df = add_team_rating_projected(
                df=df,
                column_names=cn,
                player_rating_col=self.PLAYER_DEF_RATING_COL,
                team_rating_out=self.TEAM_DEF_RATING_PROJ_COL,
                extra_granularity=extra_granularity,
            )

        if self.OPP_OFF_RATING_PROJ_COL in cols_to_add:
            df = add_opp_team_rating(
                df=df,
                column_names=cn,
                team_rating_col=self.TEAM_OFF_RATING_PROJ_COL,
                opp_team_rating_out=self.OPP_OFF_RATING_PROJ_COL,
                extra_granularity=extra_granularity,
            )

        if (
            self.OPP_DEF_RATING_PROJ_COL in cols_to_add
            or self.OPP_RATING_PROJ_COL in cols_to_add
            or self.DIFF_PROJ_COL in cols_to_add
            or self.PLAYER_DIFF_PROJ_COL in cols_to_add
            or self.PLAYER_OPP_MEAN_PROJ_COL in cols_to_add
        ):
            df = add_opp_team_rating(
                df=df,
                column_names=cn,
                team_rating_col=self.TEAM_DEF_RATING_PROJ_COL,
                opp_team_rating_out=self.OPP_DEF_RATING_PROJ_COL,
                extra_granularity=extra_granularity,
            )

        # Batch independent alias/arithmetic expressions to reduce DataFrame materializations
        batch_exprs = []
        # Always alias TEAM_OFF_RATING_PROJ_COL → TEAM_RATING_PROJ_COL when available,
        # since downstream steps (DIFF_PROJ_COL, MEAN_PROJ_COL) use it as an intermediate.
        if self.TEAM_OFF_RATING_PROJ_COL in df.columns:
            batch_exprs.append(
                pl.col(self.TEAM_OFF_RATING_PROJ_COL).alias(self.TEAM_RATING_PROJ_COL)
            )
        # Always alias OPP_DEF_RATING_PROJ_COL → OPP_RATING_PROJ_COL when available,
        # since downstream steps (DIFF_PROJ_COL, PLAYER_OPP_MEAN_PROJ_COL) use it as an intermediate.
        if self.OPP_DEF_RATING_PROJ_COL in df.columns:
            batch_exprs.append(pl.col(self.OPP_DEF_RATING_PROJ_COL).alias(self.OPP_RATING_PROJ_COL))
        if self.PLAYER_DIFF_PROJ_COL in cols_to_add and self.OPP_DEF_RATING_PROJ_COL in df.columns:
            batch_exprs.append(
                (pl.col(self.PLAYER_RATING_COL) - pl.col(self.OPP_DEF_RATING_PROJ_COL)).alias(
                    self.PLAYER_DIFF_PROJ_COL
                )
            )
        if (
            self.PLAYER_DIFF_FROM_TEAM_PROJ_COL in cols_to_add
            and self.TEAM_OFF_RATING_PROJ_COL in df.columns
        ):
            batch_exprs.append(
                (pl.col(self.PLAYER_OFF_RATING_COL) - pl.col(self.TEAM_OFF_RATING_PROJ_COL)).alias(
                    self.PLAYER_DIFF_FROM_TEAM_PROJ_COL
                )
            )
        if batch_exprs:
            df = df.with_columns(*batch_exprs)

        if (
            self.TEAM_RATING_COL in cols_to_add
            or self.OPP_RATING_COL in cols_to_add
            or self.DIFF_COL in cols_to_add
        ):
            df = add_team_rating(
                df=df,
                column_names=cn,
                player_rating_col=self.PLAYER_OFF_RATING_COL,
                team_rating_out=self.TEAM_RATING_COL,
                extra_granularity=extra_granularity,
            )

        if self.OPP_RATING_COL in cols_to_add or self.DIFF_COL in cols_to_add:
            df = add_opp_team_rating(
                df=df,
                column_names=cn,
                team_rating_col=self.TEAM_RATING_COL,
                opp_team_rating_out=self.OPP_RATING_COL,
                extra_granularity=extra_granularity,
            )

        if self.DIFF_PROJ_COL in cols_to_add:
            df = add_rating_difference_projected(
                df=df,
                team_rating_col=self.TEAM_RATING_PROJ_COL,  # OFF
                opp_team_rating_col=self.OPP_RATING_PROJ_COL,  # DEF
                rating_diff_out=self.DIFF_PROJ_COL,
            )

        if self.MEAN_PROJ_COL in cols_to_add:
            df = add_rating_mean_projected(
                df=df,
                column_names=cn,
                player_rating_col=self.PLAYER_OFF_RATING_COL,
                rating_mean_out=self.MEAN_PROJ_COL,
                extra_granularity=extra_granularity,
            )

        if self.PLAYER_OPP_MEAN_PROJ_COL in cols_to_add:
            df = add_player_opponent_mean_projected(
                df=df,
                column_names=cn,
                player_rating_col=self.PLAYER_RATING_COL,
                opp_team_rating_col=self.OPP_RATING_PROJ_COL,
                out_col=self.PLAYER_OPP_MEAN_PROJ_COL,
            )

        if self.DIFF_COL in cols_to_add and self.DIFF_COL not in df.columns:
            if self.TEAM_RATING_COL not in df.columns:
                df = add_team_rating(
                    df=df,
                    column_names=cn,
                    player_rating_col=self.PLAYER_OFF_RATING_COL,
                    team_rating_out=self.TEAM_RATING_COL,
                    extra_granularity=extra_granularity,
                )
            if self.OPP_RATING_COL not in df.columns:
                df = add_opp_team_rating(
                    df=df,
                    column_names=cn,
                    team_rating_col=self.TEAM_RATING_COL,
                    opp_team_rating_out=self.OPP_RATING_COL,
                    extra_granularity=extra_granularity,
                )
            if self.TEAM_RATING_COL in df.columns and self.OPP_RATING_COL in df.columns:
                df = df.with_columns(
                    (pl.col(self.TEAM_RATING_COL) - pl.col(self.OPP_RATING_COL)).alias(
                        self.DIFF_COL
                    )
                )

        base_known = [f.value for f in RatingKnownFeatures]
        base_unknown = [f.value for f in RatingUnknownFeatures]
        cols_to_eval = [self._suffix(c) for c in (base_known + base_unknown)]

        cols_to_drop = [c for c in cols_to_eval if (c in df.columns and c not in cols_to_add)]
        return df.drop(cols_to_drop)

    def _create_match_df(self, df: pl.DataFrame) -> pl.DataFrame:
        if len(df[self.column_names.team_id].unique()) < 2:
            raise ValueError("df needs at least two different team ids")
        if self.league_identifier:
            df = self.league_identifier.add_leagues(df)

        cn = self.column_names

        player_stat_cols = [cn.player_id]
        if self.performance_column in df.columns:
            player_stat_cols.append(self.performance_column)

        if cn.participation_weight and cn.participation_weight in df.columns:
            player_stat_cols.append(cn.participation_weight)
        if _SCALED_PW in df.columns:
            player_stat_cols.append(_SCALED_PW)

        if cn.projected_participation_weight and cn.projected_participation_weight in df.columns:
            player_stat_cols.append(cn.projected_participation_weight)
        if _SCALED_PPW in df.columns:
            player_stat_cols.append(_SCALED_PPW)

        if cn.defense_participation_weight and cn.defense_participation_weight in df.columns:
            player_stat_cols.append(cn.defense_participation_weight)
        if _SCALED_DPW in df.columns:
            player_stat_cols.append(_SCALED_DPW)

        if (
            cn.projected_defense_participation_weight
            and cn.projected_defense_participation_weight in df.columns
        ):
            player_stat_cols.append(cn.projected_defense_participation_weight)
        if _SCALED_PDPW in df.columns:
            player_stat_cols.append(_SCALED_PDPW)

        if cn.position and cn.position in df.columns:
            player_stat_cols.append(cn.position)

        if cn.league and cn.league in df.columns:
            player_stat_cols.append(cn.league)

        if cn.team_players_playing_time and cn.team_players_playing_time in df.columns:
            player_stat_cols.append(cn.team_players_playing_time)

        if cn.opponent_players_playing_time and cn.opponent_players_playing_time in df.columns:
            player_stat_cols.append(cn.opponent_players_playing_time)

        if self.defense_performance_column and self.defense_performance_column in df.columns:
            player_stat_cols.append(self.defense_performance_column)

        df = df.with_columns(pl.struct(player_stat_cols).alias(PLAYER_STATS))

        group_cols = [cn.match_id, cn.team_id, cn.start_date]
        if cn.update_match_id != cn.match_id:
            group_cols.append(cn.update_match_id)
        for col in getattr(self, "extra_granularity", []):
            if col in df.columns:
                group_cols.append(col)

        agg_df = df.group_by(group_cols).agg(pl.col(PLAYER_STATS).alias(PLAYER_STATS))

        team_id_col = cn.team_id

        match_key_cols = [cn.match_id]
        if cn.update_match_id != cn.match_id and cn.update_match_id in agg_df.columns:
            match_key_cols.append(cn.update_match_id)
        for col in getattr(self, "extra_granularity", []):
            if col in agg_df.columns and col not in match_key_cols:
                match_key_cols.append(col)

        right_cols = [c for c in agg_df.columns if c not in [*match_key_cols, cn.start_date]]
        right_df = agg_df.select(
            match_key_cols + [pl.col(c).alias(f"{c}_opponent") for c in right_cols]
        )
        match_df = (
            agg_df.join(right_df, on=match_key_cols, how="inner")
            .filter(pl.col(team_id_col) != pl.col(f"{team_id_col}_opponent"))
            .unique(match_key_cols)
        )

        sort_cols = [cn.start_date] + match_key_cols
        match_df = match_df.sort(sort_cols)

        match_df = self._add_day_number(match_df, cn.start_date, "__day_number")
        return match_df

    def _get_players_playing_time(
        self, source: Mapping[str, Any], column_name: str | None
    ) -> dict[str, float] | None:
        if not column_name:
            return None
        return self._normalize_players_playing_time(source.get(column_name))

    @staticmethod
    def _normalize_players_playing_time(raw_value: Any) -> dict[str, float] | None:
        if raw_value is None:
            return None

        if isinstance(raw_value, str):
            raw_text = raw_value
            raw_value = raw_value.strip()
            if not raw_value:
                return None
            try:
                raw_value = json.loads(raw_value)
            except json.JSONDecodeError as exc:
                raise ValueError(f"unable to parse playing time JSON {raw_text!r}: {exc}") from exc

        if isinstance(raw_value, Mapping):
            normalized: dict[str, float] = {}
            for key, value in raw_value.items():
                if value is None:
                    continue
                normalized[str(key)] = float(value)
            return normalized or None

        return None

    def _create_pre_match_players_collection(
        self, r: dict, stats_col: str, day_number: int, team_id: str
    ) -> PreMatchPlayersCollection:
        cn = self.column_names

        pre_match_player_ratings: list[_PreMatchPlayerView] = []
        pre_match_def_player_ratings: list[_PreMatchPlayerView] = []
        new_players: list[MatchPlayer] = []
        player_ids: list[str] = []
        player_off_rating_values: list[float] = []
        projected_participation_weights: list[float] = []

        for team_player in r[stats_col]:
            player_id = team_player[cn.player_id]
            player_ids.append(player_id)

            position = team_player.get(cn.position)
            player_league = team_player.get(cn.league, None)

            # Use scaled participation weight if available, otherwise use original
            if _SCALED_PW in team_player:
                participation_weight = team_player.get(_SCALED_PW, 1.0)
            elif cn.participation_weight:
                participation_weight = team_player.get(cn.participation_weight, 1.0)
            else:
                participation_weight = 1.0

            # Use scaled projected participation weight if available, otherwise use original
            if _SCALED_PPW in team_player:
                projected_participation_weight = team_player.get(_SCALED_PPW, participation_weight)
            elif cn.projected_participation_weight:
                projected_participation_weight = team_player.get(
                    cn.projected_participation_weight, participation_weight
                )
            else:
                projected_participation_weight = participation_weight
            projected_participation_weights.append(projected_participation_weight)

            # Use scaled defense participation weight if available, otherwise default to participation_weight
            if _SCALED_DPW in team_player:
                defense_participation_weight = team_player.get(_SCALED_DPW, participation_weight)
            elif cn.defense_participation_weight:
                defense_participation_weight = team_player.get(
                    cn.defense_participation_weight, participation_weight
                )
            else:
                defense_participation_weight = participation_weight

            # Use scaled projected defense participation weight if available
            if _SCALED_PDPW in team_player:
                projected_defense_participation_weight = team_player.get(
                    _SCALED_PDPW, defense_participation_weight
                )
            elif cn.projected_defense_participation_weight:
                projected_defense_participation_weight = team_player.get(
                    cn.projected_defense_participation_weight, defense_participation_weight
                )
            else:
                projected_defense_participation_weight = defense_participation_weight

            perf_val = (
                float(team_player[self.performance_column])
                if (
                    self.performance_column in team_player
                    and team_player[self.performance_column] is not None
                )
                else None
            )

            def_perf_val = (
                float(team_player[self.defense_performance_column])
                if (
                    self.defense_performance_column
                    and self.defense_performance_column in team_player
                    and team_player[self.defense_performance_column] is not None
                )
                else None
            )

            team_playing_time = self._get_players_playing_time(
                team_player, cn.team_players_playing_time
            )
            opponent_playing_time = self._get_players_playing_time(
                team_player, cn.opponent_players_playing_time
            )

            mp = _MatchPerformanceView(
                performance_value=perf_val,
                projected_participation_weight=projected_participation_weight,
                participation_weight=participation_weight,
                defense_participation_weight=defense_participation_weight,
                projected_defense_participation_weight=projected_defense_participation_weight,
                defense_performance_value=def_perf_val,
                team_players_playing_time=team_playing_time,
                opponent_players_playing_time=opponent_playing_time,
            )

            if player_id in self._player_off_ratings and player_id in self._player_def_ratings:
                off_state = self._player_off_ratings[player_id]
                def_state = self._player_def_ratings[player_id]
                pre = _PreMatchPlayerView(
                    id=player_id,
                    rating_value=off_state.rating_value,
                    match_performance=mp,
                    games_played=off_state.games_played,
                    league=player_league,
                    position=position,
                )
                pre_match_player_ratings.append(pre)
                player_off_rating_values.append(float(off_state.rating_value))

                # Also create DEF player rating for use in opponent predictions
                pre_def = _PreMatchPlayerView(
                    id=player_id,
                    rating_value=def_state.rating_value,
                    match_performance=mp,
                    games_played=def_state.games_played,
                    league=player_league,
                    position=position,
                )
                pre_match_def_player_ratings.append(pre_def)
            else:
                # unseen player -> create start rating (OFF + DEF)
                new_players.append(
                    MatchPlayer(
                        id=player_id,
                        performance=mp,
                        league=player_league,
                        position=position,
                    )
                )

        if new_players:
            new_pre, new_def_pre, new_vals = self._generate_new_player_pre_match_ratings(
                day_number=day_number,
                new_players=new_players,
                team_pre_match_player_ratings=pre_match_player_ratings,
            )
            pre_match_player_ratings.extend(new_pre)
            pre_match_def_player_ratings.extend(new_def_pre)
            player_off_rating_values.extend(new_vals)

        return PreMatchPlayersCollection(
            pre_match_player_ratings=pre_match_player_ratings,
            new_players=[],  # already handled
            player_ids=player_ids,
            player_rating_values=player_off_rating_values,  # OFF values
            projected_particiation_weights=projected_participation_weights,
            pre_match_def_player_ratings=pre_match_def_player_ratings,
        )

    def _generate_new_player_pre_match_ratings(
        self,
        day_number: int,
        new_players: list[MatchPlayer],
        team_pre_match_player_ratings: list[_PreMatchPlayerView],
    ) -> tuple[list[_PreMatchPlayerView], list[_PreMatchPlayerView], list[float]]:
        """
        Creates BOTH off+def states for new players using the same start rating.
        Returns (off_ratings, def_ratings, off_values).
        """
        pre_match_player_ratings: list[_PreMatchPlayerView] = []
        pre_match_def_player_ratings: list[_PreMatchPlayerView] = []
        pre_match_player_off_values: list[float] = []

        for match_player in new_players:
            pid = match_player.id

            start_val = self.start_rating_generator.generate_rating_value(
                day_number=day_number,
                match_player=match_player,
                team_pre_match_player_ratings=team_pre_match_player_ratings,
            )

            self._player_off_ratings[pid] = PlayerRating(id=pid, rating_value=start_val)
            self._player_def_ratings[pid] = PlayerRating(id=pid, rating_value=start_val)

            pre_match_player_off_values.append(float(start_val))

            pre = _PreMatchPlayerView(
                id=pid,
                rating_value=float(start_val),  # OFF rating value for predictor
                match_performance=match_player.performance,
                games_played=self._player_off_ratings[pid].games_played,
                league=match_player.league,
                position=match_player.position,
                other=match_player.others,
            )
            pre_match_player_ratings.append(pre)

            # For new players, DEF rating starts same as OFF rating
            pre_def = _PreMatchPlayerView(
                id=pid,
                rating_value=float(start_val),  # DEF rating (same as OFF for new players)
                match_performance=match_player.performance,
                games_played=self._player_def_ratings[pid].games_played,
                league=match_player.league,
                position=match_player.position,
                other=match_player.others,
            )
            pre_match_def_player_ratings.append(pre_def)

        return pre_match_player_ratings, pre_match_def_player_ratings, pre_match_player_off_values

    def _team_off_perf_from_collection(self, c: PreMatchPlayersCollection) -> float | None:
        # observed offense perf = weighted mean of player performance_value using participation_weight if present
        # skip players with null/non-finite performance
        cn = self.column_names
        if not c.pre_match_player_ratings:
            return None
        wsum = 0.0
        psum = 0.0
        for pre in c.pre_match_player_ratings:
            perf_val = pre.match_performance.performance_value
            if perf_val is None:
                continue
            perf_float = float(perf_val)
            if not math.isfinite(perf_float):
                continue
            w = (
                float(pre.match_performance.participation_weight)
                if cn.participation_weight
                else 1.0
            )
            psum += perf_float * w
            wsum += w
        return psum / wsum if wsum else None

    def _team_off_def_rating_from_collection(
        self, c: PreMatchPlayersCollection
    ) -> tuple[float, float]:
        cn = self.column_names
        if not c.player_ids:
            return 0.0, 0.0

        off_vals = [
            float(self._player_off_ratings[pid].rating_value)
            for pid in c.player_ids
            if pid in self._player_off_ratings
        ]
        def_vals = (
            off_vals
            if not self.use_off_def_split
            else [
                float(self._player_def_ratings[pid].rating_value)
                for pid in c.player_ids
                if pid in self._player_def_ratings
            ]
        )
        if not off_vals or not def_vals:
            return 0.0, 0.0

        if cn.projected_participation_weight and c.projected_particiation_weights:
            w = [float(x) for x in c.projected_particiation_weights]
            wsum = sum(w) if w else 0.0
            off = (
                (sum(v * ww for v, ww in zip(off_vals, w, strict=False)) / wsum)
                if wsum
                else (sum(off_vals) / len(off_vals))
            )
            dff = (
                (sum(v * ww for v, ww in zip(def_vals, w, strict=False)) / wsum)
                if wsum
                else (sum(def_vals) / len(def_vals))
            )
            return float(off), float(dff)

        return float(sum(off_vals) / len(off_vals)), float(sum(def_vals) / len(def_vals))

    def _calculate_future_ratings(self, match_df: pl.DataFrame) -> pl.DataFrame:
        """
        Same as historical, but:
        - do NOT mutate self._player_*_ratings
        - create local-only start ratings for unseen players
        """
        cn = self.column_names

        base_off = self._player_off_ratings
        base_def = self._player_def_ratings
        # Shallow dict copy is sufficient: existing PlayerRating objects are only
        # read here, never mutated. New entries are added for unseen players, so
        # we still need a new dict to avoid polluting the persistent state.
        local_off: dict[str, PlayerRating] = dict(base_off)
        local_def: dict[str, PlayerRating] = dict(base_def)

        out = {
            cn.player_id: [],
            cn.match_id: [],
            cn.team_id: [],
            self.PLAYER_OFF_RATING_COL: [],
            self.PLAYER_DEF_RATING_COL: [],
            self.PLAYER_PRED_OFF_PERF_COL: [],
            self.PLAYER_PRED_DEF_PERF_COL: [],
            # back-compat
            self.PLAYER_RATING_COL: [],
            self.PLAYER_PRED_PERF_COL: [],
        }
        extra_out_cols = [
            col for col in getattr(self, "extra_granularity", []) if col in match_df.columns
        ]
        for col in extra_out_cols:
            out[col] = []

        def get_perf_value(team_player: dict) -> float | None:
            if (
                self.performance_column in team_player
                and team_player[self.performance_column] is not None
            ):
                val = float(team_player[self.performance_column])
                if math.isfinite(val):
                    return val
            return None

        def ensure_new_player(
            pid: str,
            day_number: int,
            mp: _MatchPerformanceView,
            league,
            position,
            team_pre: list[_PreMatchPlayerView],
        ) -> None:
            if pid in local_off and pid in local_def:
                return
            start_val = self.start_rating_generator.generate_rating_value(
                day_number=day_number,
                match_player=MatchPlayer(id=pid, performance=mp, league=league, position=position),
                team_pre_match_player_ratings=team_pre,
            )
            local_off[pid] = PlayerRating(id=pid, rating_value=start_val)
            local_def[pid] = PlayerRating(id=pid, rating_value=start_val)

        for r in match_df.iter_rows(named=True):
            match_id = r[cn.match_id]
            day_number = int(r["__day_number"])

            team1 = r[cn.team_id]
            team2 = r[f"{cn.team_id}_opponent"]

            def build_local_team(
                stats_col: str,
            ) -> tuple[
                list[_PreMatchPlayerView],
                list[_PreMatchPlayerView],
                list[str],
                list[float],
                list[float],
                float,
            ]:
                pre_list: list[_PreMatchPlayerView] = []
                def_pre_list: list[_PreMatchPlayerView] = []
                player_ids: list[str] = []
                proj_w: list[float] = []
                off_vals: list[float] = []
                psum, wsum = 0.0, 0.0

                for tp in r[stats_col]:  # noqa: B023
                    pid = tp[cn.player_id]
                    player_ids.append(pid)

                    position = tp.get(cn.position)
                    league = tp.get(cn.league, None)

                    # Use scaled participation weight if available, otherwise use original
                    if _SCALED_PW in tp:
                        pw = tp.get(_SCALED_PW, 1.0)
                    elif cn.participation_weight:
                        pw = tp.get(cn.participation_weight, 1.0)
                    else:
                        pw = 1.0

                    # Use scaled projected participation weight if available, otherwise use original
                    if _SCALED_PPW in tp:
                        ppw = tp.get(_SCALED_PPW, pw)
                    elif cn.projected_participation_weight:
                        ppw = tp.get(cn.projected_participation_weight, pw)
                    else:
                        ppw = pw
                    proj_w.append(float(ppw))

                    # Use scaled defense participation weight if available
                    if _SCALED_DPW in tp:
                        dpw = tp.get(_SCALED_DPW, pw)
                    elif cn.defense_participation_weight:
                        dpw = tp.get(cn.defense_participation_weight, pw)
                    else:
                        dpw = pw

                    # Use scaled projected defense participation weight if available
                    if _SCALED_PDPW in tp:
                        pdpw = tp.get(_SCALED_PDPW, dpw)
                    elif cn.projected_defense_participation_weight:
                        pdpw = tp.get(cn.projected_defense_participation_weight, dpw)
                    else:
                        pdpw = dpw

                    def_perf_val = (
                        float(tp[self.defense_performance_column])  # noqa: B023
                        if (
                            self.defense_performance_column  # noqa: B023
                            and self.defense_performance_column in tp  # noqa: B023
                            and tp[self.defense_performance_column] is not None  # noqa: B023
                        )
                        else None
                    )

                    team_playing_time = self._get_players_playing_time(
                        tp, cn.team_players_playing_time
                    )
                    opponent_playing_time = self._get_players_playing_time(
                        tp, cn.opponent_players_playing_time
                    )

                    mp = _MatchPerformanceView(
                        performance_value=get_perf_value(tp),
                        projected_participation_weight=ppw,
                        participation_weight=pw,
                        defense_participation_weight=dpw,
                        projected_defense_participation_weight=pdpw,
                        defense_performance_value=def_perf_val,
                        team_players_playing_time=team_playing_time,
                        opponent_players_playing_time=opponent_playing_time,
                    )

                    ensure_new_player(pid, day_number, mp, league, position, pre_list)  # noqa: B023

                    pre_list.append(
                        _PreMatchPlayerView(
                            id=pid,
                            rating_value=float(local_off[pid].rating_value),
                            match_performance=mp,
                            games_played=float(local_off[pid].games_played),
                            league=league,
                            position=position,
                        )
                    )
                    # Also build DEF player ratings for opponent weighting
                    def_pre_list.append(
                        _PreMatchPlayerView(
                            id=pid,
                            rating_value=float(local_def[pid].rating_value),
                            match_performance=mp,
                            games_played=float(local_def[pid].games_played),
                            league=league,
                            position=position,
                        )
                    )
                    off_vals.append(float(local_off[pid].rating_value))

                    if mp.performance_value is not None:
                        psum += float(mp.performance_value) * float(pw)
                        wsum += float(pw)

                team_off_perf = psum / wsum if wsum else 0.0
                return pre_list, def_pre_list, player_ids, off_vals, proj_w, team_off_perf

            t1_pre, t1_def_pre, t1_ids, t1_off_vals, t1_proj_w, t1_off_perf = build_local_team(
                PLAYER_STATS
            )
            t2_pre, t2_def_pre, t2_ids, t2_off_vals, t2_proj_w, t2_off_perf = build_local_team(
                f"{PLAYER_STATS}_opponent"
            )

            def team_off_def_rating(ids: list[str], w: list[float]) -> tuple[float, float]:
                if not ids:
                    return 0.0, 0.0
                off = [float(local_off[pid].rating_value) for pid in ids]
                dff = [float(local_def[pid].rating_value) for pid in ids]
                if cn.projected_participation_weight and w and sum(w):
                    ws = sum(w)
                    return (
                        sum(v * ww for v, ww in zip(off, w, strict=False)) / ws,
                        sum(v * ww for v, ww in zip(dff, w, strict=False)) / ws,
                    )
                return sum(off) / len(off), sum(dff) / len(dff)

            t1_off_rating, t1_def_rating = team_off_def_rating(t1_ids, t1_proj_w)
            t2_off_rating, t2_def_rating = team_off_def_rating(t2_ids, t2_proj_w)

            t1_off_team = _PreMatchTeamView(id=team1, players=t1_pre, rating_value=t1_off_rating)
            t2_off_team = _PreMatchTeamView(id=team2, players=t2_pre, rating_value=t2_off_rating)
            t1_def_team = _PreMatchTeamView(
                id=team1, players=t1_def_pre, rating_value=t1_def_rating
            )
            t2_def_team = _PreMatchTeamView(
                id=team2, players=t2_def_pre, rating_value=t2_def_rating
            )

            for pre in t1_pre:
                pid = pre.id
                off_pre = float(local_off[pid].rating_value)
                def_pre = (
                    off_pre if not self.use_off_def_split else float(local_def[pid].rating_value)
                )

                pred_off = self._predict_performance_for_view(
                    player=pre,
                    player_rating_value=off_pre,
                    opponent_team=t2_def_team,
                    team=t1_off_team,
                )

                pred_def = self._predict_performance_for_view(
                    player=pre,
                    player_rating_value=def_pre,
                    opponent_team=t2_off_team,
                    team=t1_def_team,
                )

                if not self.use_off_def_split:
                    pred_def = pred_off

                out[cn.player_id].append(pid)
                out[cn.match_id].append(match_id)
                out[cn.team_id].append(team1)
                for col in extra_out_cols:
                    out[col].append(r[col])
                out[self.PLAYER_OFF_RATING_COL].append(off_pre)
                out[self.PLAYER_DEF_RATING_COL].append(def_pre)
                out[self.PLAYER_PRED_OFF_PERF_COL].append(float(pred_off))
                out[self.PLAYER_PRED_DEF_PERF_COL].append(float(pred_def))
                out[self.PLAYER_RATING_COL].append(off_pre)
                out[self.PLAYER_PRED_PERF_COL].append(float(pred_off))

            for pre in t2_pre:
                pid = pre.id
                off_pre = float(local_off[pid].rating_value)
                def_pre = (
                    off_pre if not self.use_off_def_split else float(local_def[pid].rating_value)
                )

                pred_off = self._predict_performance_for_view(
                    player=pre,
                    player_rating_value=off_pre,
                    opponent_team=t1_def_team,
                    team=t2_off_team,
                )

                pred_def = self._predict_performance_for_view(
                    player=pre,
                    player_rating_value=def_pre,
                    opponent_team=t1_off_team,
                    team=t2_def_team,
                )

                if not self.use_off_def_split:
                    pred_def = pred_off

                out[cn.player_id].append(pid)
                out[cn.match_id].append(match_id)
                out[cn.team_id].append(team2)
                for col in extra_out_cols:
                    out[col].append(r[col])
                out[self.PLAYER_OFF_RATING_COL].append(off_pre)
                out[self.PLAYER_DEF_RATING_COL].append(def_pre)
                out[self.PLAYER_PRED_OFF_PERF_COL].append(float(pred_off))
                out[self.PLAYER_PRED_DEF_PERF_COL].append(float(pred_def))
                out[self.PLAYER_RATING_COL].append(off_pre)
                out[self.PLAYER_PRED_PERF_COL].append(float(pred_off))

        if not out[cn.player_id]:
            return pl.DataFrame(
                {
                    cn.player_id: pl.Series([], dtype=pl.Utf8),
                    cn.match_id: pl.Series([], dtype=pl.Utf8),
                    cn.team_id: pl.Series([], dtype=pl.Utf8),
                    self.PLAYER_OFF_RATING_COL: pl.Series([], dtype=pl.Float64),
                    self.PLAYER_DEF_RATING_COL: pl.Series([], dtype=pl.Float64),
                    self.PLAYER_PRED_OFF_PERF_COL: pl.Series([], dtype=pl.Float64),
                    self.PLAYER_PRED_DEF_PERF_COL: pl.Series([], dtype=pl.Float64),
                    self.PLAYER_RATING_COL: pl.Series([], dtype=pl.Float64),
                    self.PLAYER_PRED_PERF_COL: pl.Series([], dtype=pl.Float64),
                }
            )

        return pl.DataFrame(out, strict=False)

    @property
    def player_ratings(self) -> dict[str, PlayerRatingsResult]:
        """Return combined offense and defense ratings for all players."""
        result: dict[str, PlayerRatingsResult] = {}
        all_player_ids = set(self._player_off_ratings.keys()) | set(self._player_def_ratings.keys())

        for player_id in all_player_ids:
            off_state = self._player_off_ratings.get(player_id)
            def_state = self._player_def_ratings.get(player_id)

            result[player_id] = PlayerRatingsResult(
                id=player_id,
                offense_rating=off_state.rating_value if off_state else 0.0,
                defense_rating=def_state.rating_value if def_state else 0.0,
                offense_games_played=off_state.games_played if off_state else 0.0,
                defense_games_played=def_state.games_played if def_state else 0.0,
                offense_confidence_sum=off_state.confidence_sum if off_state else 0.0,
                defense_confidence_sum=def_state.confidence_sum if def_state else 0.0,
                most_recent_team_id=off_state.most_recent_team_id if off_state else None,
            )

        return result
