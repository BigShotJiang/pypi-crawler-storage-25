import pandas as pd
import polars as pl
import pytest

from spforge.data_structures import ColumnNames
from spforge.feature_generator._lag import LagTransformer
from spforge.feature_generator._rolling_against_opponent import (
    RollingAgainstOpponentTransformer,
)
from spforge.feature_generator._rolling_mean_binary import (
    BinaryOutcomeRollingMeanTransformer,
)
from spforge.feature_generator._rolling_window import RollingWindowTransformer


@pytest.fixture(params=["pd", "pl"])
def frame(request):
    return request.param


@pytest.fixture
def lol_like_rows():
    return pd.DataFrame(
        {
            "game": ["g1"] * 6 + ["g2"] * 6,
            "team": ["A", "A", "A", "B", "B", "B"] * 2,
            "player": ["A", "A", "A", "B", "B", "B"] * 2,
            "opponent": ["B", "B", "B", "A", "A", "A"] * 2,
            "champion": ["X", "Y", "Z", "P", "Q", "R", "X", "Q", "Z", "Y", "P", "R"],
            "start_date": [pd.to_datetime("2023-01-01")] * 6 + [pd.to_datetime("2023-01-02")] * 6,
            "value": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0],
            "won": [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0],
        }
    )


@pytest.fixture
def column_names():
    return ColumnNames(
        match_id="game",
        team_id="team",
        player_id="player",
        start_date="start_date",
    )


@pytest.mark.parametrize(
    "factory",
    [
        lambda: RollingWindowTransformer(
            features=["value"],
            window=2,
            granularity=["champion"],
        ),
        lambda: LagTransformer(
            features=["value"],
            lag_length=1,
            granularity=["champion"],
        ),
        lambda: BinaryOutcomeRollingMeanTransformer(
            features=["value"],
            window=2,
            binary_column="won",
            granularity=["champion"],
        ),
    ],
)
def test_group_to_granularity_join_preserves_row_count(frame, lol_like_rows, column_names, factory):
    data = lol_like_rows if frame == "pd" else pl.from_pandas(lol_like_rows)
    transformer = factory()

    result = transformer.fit_transform(data, column_names=column_names)

    assert result.shape[0] == data.shape[0]


def test_rolling_against_opponent_join_preserves_row_count(frame, lol_like_rows, column_names):
    data = lol_like_rows if frame == "pd" else pl.from_pandas(lol_like_rows)
    transformer = RollingAgainstOpponentTransformer(
        features=["value"],
        window=2,
        granularity=["champion"],
        opponent_column="opponent",
    )

    result = transformer.fit_transform(data, column_names=column_names)

    assert result.shape[0] == data.shape[0]
