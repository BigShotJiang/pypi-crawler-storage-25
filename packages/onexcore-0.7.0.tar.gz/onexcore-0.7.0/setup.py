from setuptools import setup, find_packages

setup(
    name="onexcore",
    version="0.7.0",
    author="OneXEOS Platform Team",
    description="Structured logging, context propagation, error enrichment, and real-time messaging for OneXEOS services",
    packages=find_packages(),
    install_requires=[
        "structlog>=24.1.0",
        "nats-py>=2.6.0",
        "httpx>=0.27.1",
        "pymongo>=4.6.0",
    ],
    python_requires=">=3.12",
)
