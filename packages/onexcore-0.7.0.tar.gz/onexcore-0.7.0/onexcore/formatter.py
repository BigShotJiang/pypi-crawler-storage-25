"""
ProcessorFormatter bridge: makes ALL Python logging output structured JSON.

Calling setup_logging() configures the root logger so that:
- logging.getLogger(__name__).info("msg")  →  JSON with trace_id
- structlog.get_logger().info("msg")       →  JSON with trace_id
- onexcore.log.info("msg")                →  JSON with trace_id

This is the single place where log output format is defined.
"""
import logging
import sys

import structlog

from .context import get_context


def _inject_context(logger, method_name, event_dict):
    """Structlog processor: inject trace_id / user_id / company_id / service from ContextVars."""
    ctx = get_context()
    for key, value in ctx.items():
        event_dict.setdefault(key, value)
    return event_dict


def _rename_event_to_message(logger, method_name, event_dict):
    """Rename structlog's 'event' key to 'message' for Promtail compatibility."""
    if 'event' in event_dict:
        event_dict['message'] = event_dict.pop('event')
    return event_dict


def _add_service_from_logger(logger, method_name, event_dict):
    """Extract service name from logger name if not already set.

    e.g. logger name 'auth.src.apis.login' → service='auth'
    """
    if 'service' not in event_dict:
        logger_name = event_dict.get('logger', '')
        if logger_name and '.' in logger_name:
            event_dict['service'] = logger_name.split('.')[0]
    return event_dict


def setup_logging(log_level: str = "INFO"):
    """Configure structlog + stdlib root logger for JSON output.

    Must be called once at process startup, BEFORE loading any service code.
    """
    # Shared processors used by both structlog loggers and stdlib loggers
    shared_processors = [
        structlog.contextvars.merge_contextvars,
        _inject_context,
        structlog.stdlib.add_log_level,
        structlog.stdlib.add_logger_name,
        _add_service_from_logger,  # Must run AFTER add_logger_name (needs 'logger' key)
        structlog.processors.TimeStamper(fmt="iso", utc=True),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        _rename_event_to_message,
    ]

    # Configure structlog
    structlog.configure(
        processors=shared_processors + [
            structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
        ],
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )

    # Create formatter that renders JSON
    formatter = structlog.stdlib.ProcessorFormatter(
        processor=structlog.dev.ConsoleRenderer()
        if _is_dev_mode()
        else structlog.processors.JSONRenderer(),
        foreign_pre_chain=shared_processors,
    )

    # Replace root handler
    root = logging.getLogger()
    root.handlers.clear()
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(formatter)
    root.addHandler(handler)
    root.setLevel(getattr(logging, log_level.upper(), logging.INFO))

    # Quiet noisy loggers
    for name in ('uvicorn.access', 'watchdog', 'httpx', 'httpcore'):
        logging.getLogger(name).setLevel(logging.WARNING)


def _is_dev_mode() -> bool:
    """Check if running in development mode (human-readable output)."""
    import os
    return os.getenv('ONEXCORE_DEV', '').lower() in ('1', 'true', 'yes')
