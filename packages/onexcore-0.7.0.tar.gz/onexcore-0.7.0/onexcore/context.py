"""
Context variable management for request-scoped data.

Uses Python contextvars for async-safe propagation across
coroutines and thread executors (when using contextvars.copy_context()).
"""
from contextvars import ContextVar

trace_id_var: ContextVar[str | None] = ContextVar('trace_id', default=None)
user_id_var: ContextVar[str | None] = ContextVar('user_id', default=None)
company_id_var: ContextVar[str | None] = ContextVar('company_id', default=None)
service_var: ContextVar[str | None] = ContextVar('service', default=None)


def bind_context(**kwargs):
    """Set one or more context variables.

    Example:
        bind_context(trace_id="abc-123", user_id="u1", service="auth")
    """
    _setters = {
        'trace_id': trace_id_var,
        'user_id': user_id_var,
        'company_id': company_id_var,
        'service': service_var,
    }
    for key, value in kwargs.items():
        var = _setters.get(key)
        if var is not None:
            var.set(value)


def get_context() -> dict:
    """Return all current context values (non-None only)."""
    ctx = {}
    for name, var in [
        ('trace_id', trace_id_var),
        ('user_id', user_id_var),
        ('company_id', company_id_var),
        ('service', service_var),
    ]:
        val = var.get()
        if val is not None:
            ctx[name] = val
    return ctx


def clear_context():
    """Reset all context variables to None."""
    for var in (trace_id_var, user_id_var, company_id_var, service_var):
        var.set(None)
