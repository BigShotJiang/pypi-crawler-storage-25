"""
Structured logger for OneXEOS services.

Provides `log.info()`, `log.error()`, etc. that output JSON with
automatic context injection (trace_id, user_id, company_id, service).

Usage:
    from onexcore import log

    log.info("Order created", order_id="123")
    log.error("DB failed", error=exc, payload=request_data)

Performance tracing:
    with log.perf("fetch_roles"):
        roles = db.find(...)

    # Shows in `onex trace` as:
    # ├─ 11:18:00 ⏱ fetch_roles (45.2ms)
"""
import time as _time
from contextlib import contextmanager

import structlog

from .context import get_context
from .errors import enrich_error


def _create_logger():
    """Create the module-level logger.

    Actual structlog configuration is done by setup_logging() in formatter.py.
    This just returns a proxy logger that will use whatever processors are
    configured at call time.
    """
    return structlog.get_logger("onexcore")


class _OnexLogger:
    """Thin wrapper that auto-injects context and enriches errors."""

    def __init__(self):
        self._logger = _create_logger()

    def _merge(self, kwargs: dict) -> dict:
        """Merge context vars into log kwargs (context < explicit)."""
        merged = get_context()
        merged.update(kwargs)
        return merged

    def info(self, message: str, **kwargs):
        self._logger.info(message, **self._merge(kwargs))

    def warning(self, message: str, **kwargs):
        self._logger.warning(message, **self._merge(kwargs))

    def debug(self, message: str, **kwargs):
        self._logger.debug(message, **self._merge(kwargs))

    def error(self, message: str, error: BaseException | None = None,
              payload=None, **kwargs):
        """Log an error with optional traceback enrichment.

        Args:
            message: Human-readable error description
            error: Exception instance — auto-extracts traceback + fingerprint
            payload: Request payload — auto-redacted for PII
            **kwargs: Additional structured fields
        """
        merged = self._merge(kwargs)
        if error is not None:
            if isinstance(error, BaseException):
                merged.update(enrich_error(error, payload))
            else:
                # Caller passed a string or non-exception — log it as error_message
                merged['error_message'] = str(error)
        elif payload is not None:
            from .errors import redact_pii
            merged['payload'] = redact_pii(payload)
        self._logger.error(message, **merged)

    @contextmanager
    def perf(self, step: str, **kwargs):
        """Time a block of code and log it for `onex trace` visibility.

        Usage:
            with log.perf("fetch_roles"):
                roles = db.find(...)

            with log.perf("build_query", collection="orders"):
                query = build_complex_query()

        Shows in `onex trace` timeline as:
            ├─ 11:18:00 ⏱ fetch_roles (45.2ms)
        """
        start = _time.time()
        try:
            yield
        finally:
            elapsed_ms = round((_time.time() - start) * 1000, 2)
            self._logger.info(step, **self._merge({
                "duration_ms": elapsed_ms,
                "log_event": "perf",
                **kwargs,
            }))


log = _OnexLogger()
