"""
Elasticsearch client helper for OneXEOS services.

Usage:
    from onexcore.es import get_es

    es = get_es()
    es.index(index="locations", id="123", document={"name": "HQ"})
    es.search(index="locations", query={"match": {"name": "HQ"}})

Environment variables:
    ELASTICSEARCH_URL: ES connection URL (default: http://elasticsearch:9200)
"""

import os

_client = None


def get_es():
    """Return a lazy singleton Elasticsearch client."""
    global _client
    if _client is None:
        try:
            from elasticsearch import Elasticsearch
        except ImportError:
            raise ImportError(
                "elasticsearch package required. Add 'elasticsearch>=8.0.0,<9.0.0' to requirements.txt"
            )
        url = os.environ.get("ELASTICSEARCH_URL", "http://elasticsearch:9200")
        _client = Elasticsearch([url])
    return _client
