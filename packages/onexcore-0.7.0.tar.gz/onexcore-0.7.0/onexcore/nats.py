"""
NATS publish helper for OneXEOS services.

Fire-and-forget publishing to NATS subjects. Use this for event-driven
communication between services (e.g., property.contract.activated,
biometric.device.connected).

Usage from @as_api() / @invoke() handlers (sync):
    from onexcore.nats import publish_sync

    publish_sync("property.contract.activated", {
        "contract_id": "c-123",
        "unit_id": "u-456",
    })

Usage from async code:
    from onexcore.nats import publish

    await publish("biometric.device.connected", {
        "serial_number": "ABC123",
    })

For real-time WebSocket push, use onexcore.realtime instead.
"""

import os
import json
import asyncio
import logging
import concurrent.futures
from typing import Any

logger = logging.getLogger(__name__)

# NATS connection (lazy initialized)
_nats_client = None
_nats_loop_id = None  # Track which event loop owns the NATS client


async def _get_nats():
    """Get or create NATS connection for the current event loop."""
    global _nats_client, _nats_loop_id
    current_loop_id = id(asyncio.get_running_loop())

    needs_reconnect = False
    if _nats_client is None:
        needs_reconnect = True
    elif _nats_loop_id != current_loop_id:
        needs_reconnect = True
    elif not _nats_client.is_connected:
        needs_reconnect = True

    if needs_reconnect:
        _nats_client = None
        _nats_loop_id = None
        try:
            import nats
            nats_url = os.getenv("NATS_URL", "nats://nats:4222")
            _nats_client = await nats.connect(nats_url)
            _nats_loop_id = current_loop_id
            logger.debug(f"[NATS] Connected to {nats_url}")
        except Exception as e:
            logger.warning(f"[NATS] Connection failed: {e}")
            _nats_client = None

    return _nats_client


def _invalidate_nats():
    """Reset the NATS client so the next call reconnects."""
    global _nats_client, _nats_loop_id
    _nats_client = None
    _nats_loop_id = None


async def publish(subject: str, data: Any) -> bool:
    """
    Publish a message to a NATS subject (async, fire-and-forget).

    Args:
        subject: NATS subject (e.g., "property.contract.activated")
        data: Payload dict (auto JSON-serialized with default=str for
              datetime, ObjectId, Decimal, etc.)

    Returns:
        True if published successfully, False on any failure.
    """
    nc = await _get_nats()
    if not nc:
        logger.warning(f"[NATS] No connection, dropping message on {subject}")
        return False

    try:
        payload = json.dumps(data, default=str).encode()
        await nc.publish(subject, payload)
        await nc.flush()
        logger.debug(f"[NATS] Published to {subject}")
        return True
    except Exception as e:
        logger.warning(f"[NATS] Publish to {subject} failed: {e}")
        _invalidate_nats()
        return False


def publish_sync(subject: str, data: Any) -> bool:
    """
    Publish a message to a NATS subject (sync wrapper).

    Safe to call from @as_api() and @invoke() handlers that run
    synchronously inside the async shared-runtime.

    Args:
        subject: NATS subject (e.g., "property.contract.activated")
        data: Payload dict (auto JSON-serialized)

    Returns:
        True if published successfully, False on any failure.
    """
    return _run_async(publish(subject, data))


def _run_async(coro) -> bool:
    """Run an async coroutine from sync context."""
    try:
        asyncio.get_running_loop()
        # Inside async context — offload to a thread with its own event loop
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(asyncio.run, coro)
            return future.result(timeout=10)
    except RuntimeError:
        # No running loop — safe to use asyncio.run directly
        return asyncio.run(coro)
    except Exception as e:
        logger.error(f"[NATS] Sync wrapper failed: {e}")
        return False
