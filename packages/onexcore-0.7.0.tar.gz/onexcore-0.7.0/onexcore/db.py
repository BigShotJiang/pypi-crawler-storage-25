"""
MongoDB access for OneXEOS services.

Usage:
    from onexcore.db import get_db

    db = get_db()
    users = db.auth_users.find({"active": True})

Database resolution order:
    1. MONGODB_DATABASE env var (same as nolicore adapter)
    2. Database name extracted from MONGODB_URI path
"""

import os
from urllib.parse import urlparse

from pymongo import MongoClient

_client = None


def get_db():
    """Return the service pymongo Database. Reuses a single MongoClient."""
    global _client

    uri = os.environ["MONGODB_URI"]

    if _client is None:
        _client = MongoClient(uri)

    db_name = os.environ.get("MONGODB_DATABASE") or urlparse(uri).path.lstrip("/").split("?")[0]
    return _client[db_name]
