"""
Invoke Registry - Core handler registration and routing for OneXEOS.

Provides the InvokeRegistry class for registering and invoking @invoke()
decorated handlers. This core module is pip-installed via onexcore and
always available in shared-runtime regardless of sys.path or service bundle.

Usage:
    from onexcore.invoke import get_invoke_registry

    registry = get_invoke_registry()
    result = registry.invoke_sync('product:importProductHandle', payload)
"""

import os
import importlib
import json
import time
import uuid as _uuid
from contextvars import ContextVar
from datetime import datetime
from typing import Callable, Dict, Any, Optional, List

from onexcore import log

# Thread-local call stack for recursion detection
# Each request maintains its own call stack via context variables
invoke_call_stack: ContextVar[List[str]] = ContextVar('invoke_call_stack', default=[])

# Recursion protection configuration (from environment variables)
MAX_CALL_DEPTH = int(os.getenv('MAX_INVOKE_CALL_DEPTH', '10'))
MAX_SAME_FUNCTION_CALLS = int(os.getenv('MAX_SAME_FUNCTION_CALLS', '3'))


class InvokeRegistry:
    """
    Registry for @invoke() decorated handlers.

    Provides local function invocation for VPS mode,
    replacing AWS Lambda with direct function calls.
    """

    def __init__(self, services_dir: str = "services", redis_client=None):
        """
        Initialize invoke registry.

        Args:
            services_dir: Directory containing service folders
            redis_client: Optional Redis client for shared registry
        """
        self.services_dir = services_dir
        self._handlers: Dict[str, Callable] = {}
        self._handler_metadata: Dict[str, Dict[str, Any]] = {}
        self.redis = redis_client

    def register_handler(
        self,
        function_name: str,
        handler: Callable,
        service_name: str = None,
        module_path: str = None
    ):
        """
        Register an @invoke() handler with service-qualified naming.

        Args:
            function_name: Function name (e.g., 'preSaveApprovalHook')
            handler: Handler function
            service_name: Service name (e.g., 'automation')
            module_path: Full module path
        """
        if service_name:
            qualified_name = f"{service_name}:{function_name}"

            self._handlers[qualified_name] = handler
            self._handler_metadata[qualified_name] = {
                'service': service_name,
                'module': module_path,
                'function': handler.__name__,
                'simple_name': function_name,
                'is_qualified': True
            }

            if self.redis:
                try:
                    redis_key = f"invoke_registry:{qualified_name}"
                    metadata = {
                        'service': service_name,
                        'module_path': module_path,
                        'handler_name': handler.__name__,
                        'function_name': function_name,
                        'registered_at': datetime.utcnow().isoformat()
                    }
                    self.redis.set(redis_key, json.dumps(metadata), ex=86400)
                    log.debug("invoke_handler_stored_in_redis", function_name=qualified_name)
                except Exception as e:
                    log.warning("redis_store_failed", function_name=qualified_name, error=str(e))

            log.debug(
                "invoke_handler_registered",
                function_name=qualified_name,
                service=service_name,
                module=module_path,
                type="service_qualified"
            )
            return

        log.warning(
            "invoke_handler_missing_service",
            function_name=function_name,
            module=module_path,
            message="Registering invoke handler without service qualification."
        )
        self._handlers[function_name] = handler
        self._handler_metadata[function_name] = {
            'service': service_name,
            'module': module_path,
            'function': handler.__name__,
            'simple_name': function_name,
            'is_qualified': False
        }

        log.debug(
            "invoke_handler_registered",
            function_name=function_name,
            service=service_name,
            module=module_path,
            type="simple_name_unqualified"
        )

    def _load_handler_from_redis(self, function_name: str) -> Optional[Callable]:
        """
        Load handler dynamically from Redis metadata.

        Enables cross-process handler discovery: handlers registered
        in gateway can be invoked from async_worker or E2E tests.

        Args:
            function_name: Service-qualified function name

        Returns:
            Handler callable if found and loaded, None otherwise
        """
        if not self.redis:
            return None

        try:
            redis_key = f"invoke_registry:{function_name}"
            metadata_json = self.redis.get(redis_key)

            if not metadata_json:
                log.debug("handler_not_in_redis", function_name=function_name)
                return None

            metadata = json.loads(metadata_json)
            module_path = metadata['module_path']
            handler_name = metadata['handler_name']

            log.info("loading_handler_dynamically",
                     function_name=function_name,
                     module_path=module_path,
                     handler_name=handler_name)

            module = importlib.import_module(module_path)
            handler = getattr(module, handler_name)

            self._handlers[function_name] = handler
            self._handler_metadata[function_name] = metadata

            log.info("handler_loaded_from_redis",
                     function_name=function_name,
                     module_path=module_path,
                     message="Handler cached in memory for subsequent calls")

            return handler

        except Exception as e:
            log.error("dynamic_handler_load_failed",
                      function_name=function_name,
                      error=e)
            return None

    def invoke_sync(
        self,
        function_name: str,
        payload: Dict[str, Any],
        fail_on_error: bool = False
    ) -> Optional[Dict[str, Any]]:
        """
        Invoke handler synchronously with trace context inheritance and recursion protection.

        Args:
            function_name: Function name to invoke
            payload: Event payload (dict)
            fail_on_error: Raise exception on error

        Returns:
            Handler response dict, or None if error and fail_on_error=False

        Raises:
            ValueError: If handler not found
            RecursionError: If max call depth or recursion detected
            Exception: If handler fails and fail_on_error=True
        """
        start_time = time.time()

        # Get current call stack
        call_stack = invoke_call_stack.get([])
        call_depth = len(call_stack)

        # Check 1: Max call depth exceeded
        if call_depth >= MAX_CALL_DEPTH:
            error_msg = (
                f"Max call depth {MAX_CALL_DEPTH} exceeded. "
                f"Call stack: {' → '.join(call_stack + [function_name])}"
            )

            log.error(
                "max_call_depth_exceeded",
                function_name=function_name,
                call_stack=call_stack,
                call_depth=call_depth,
                max_depth=MAX_CALL_DEPTH,
                status="max_depth_exceeded"
            )

            if fail_on_error:
                raise RecursionError(error_msg)
            return None

        # Check 2: Direct recursion (same function called too many times)
        same_function_count = call_stack.count(function_name)
        if same_function_count >= MAX_SAME_FUNCTION_CALLS:
            error_msg = (
                f"Recursive call detected: '{function_name}' called "
                f"{same_function_count} times. "
                f"Call stack: {' → '.join(call_stack + [function_name])}"
            )

            log.error(
                "recursive_call_detected",
                function_name=function_name,
                call_stack=call_stack,
                call_depth=call_depth,
                same_function_count=same_function_count,
                max_same_calls=MAX_SAME_FUNCTION_CALLS,
                status="recursion_detected"
            )

            if fail_on_error:
                raise RecursionError(error_msg)
            return None

        # Get handler (priority: exact match first)
        handler = self._handlers.get(function_name)

        # Try Redis discovery for dynamic loading (cross-process support)
        if not handler and self.redis:
            handler = self._load_handler_from_redis(function_name)

        if not handler:
            duration = time.time() - start_time

            # Build helpful error message with suggestions
            suggestions = []

            if ':' in function_name:
                service, simple_name = function_name.split(':', 1)
                suggestions.append(f"Check if service '{service}' has handler '{simple_name}'")
                suggestions.append(f"Try simple name: '{simple_name}'")
            else:
                matching_qualified = [
                    name for name in self._handlers.keys()
                    if name.endswith(f':{function_name}')
                ]
                if matching_qualified:
                    suggestions.append(f"Found service-qualified matches: {matching_qualified}")
                    suggestions.append(f"Use one of: {', '.join(matching_qualified)}")

            available_handlers = list(self._handlers.keys())[:20]

            log.error(
                "invoke_handler_not_found",
                function_name=function_name,
                call_depth=call_depth + 1,
                call_stack=call_stack,
                duration_seconds=duration,
                duration_ms=duration * 1000,
                status="not_found",
                suggestions=suggestions,
                available_handlers_sample=available_handlers,
                total_handlers=len(self._handlers)
            )

            error_msg = f"Handler '{function_name}' not found in registry."
            if suggestions:
                error_msg += f" {' '.join(suggestions)}"

            if fail_on_error:
                raise ValueError(error_msg)
            return None

        # Add to call stack
        new_call_stack = call_stack + [function_name]
        invoke_call_stack.set(new_call_stack)

        # Log invocation start
        log.info(
            "invoke_started",
            function_name=function_name,
            call_depth=call_depth + 1,
            call_stack=new_call_stack,
            payload_size=len(str(payload)),
            fail_on_error=fail_on_error
        )

        try:
            # Wrap payload in Lambda-compatible event structure
            # The @as_api() decorator expects event['requestContext']['requestId']
            _request_id = str(_uuid.uuid4())
            event = {
                'body': payload,
                'httpMethod': 'POST',
                'path': f'/invoke/{function_name}',
                'headers': {},
                'queryStringParameters': None,
                'pathParameters': None,
                'requestContext': {
                    'requestId': _request_id,
                    'trace_id': _request_id,
                    'authorizer': {
                        'claims': {
                            'sub': 'system',
                            'custom:invoke_type': 'sync'
                        },
                        'jwt': {
                            'claims': {
                                'sub': 'system',
                                'custom:invoke_type': 'sync'
                            }
                        }
                    }
                }
            }
            result = handler(event, None)

            # Unwrap Lambda response envelope from @as_api() decorated handlers.
            # @as_api() returns: {"statusCode": 200, "body": "<json string>", "headers": {...}}
            # Callers expect the parsed body content, not the envelope.
            if isinstance(result, dict) and 'statusCode' in result and 'body' in result:
                status_code = result.get('statusCode', 500)
                body = result.get('body')

                if status_code >= 400:
                    error_body = body
                    if isinstance(body, str):
                        try:
                            error_body = json.loads(body)
                        except Exception:
                            pass
                    error_msg = error_body.get('message', str(error_body)) if isinstance(error_body, dict) else str(error_body)
                    log.error(
                        "invoke_handler_error",
                        function_name=function_name,
                        status_code=status_code,
                        error=error_msg
                    )
                    if fail_on_error:
                        raise RuntimeError(f"Invoke {function_name} returned {status_code}: {error_msg}")
                    return None

                if isinstance(body, str):
                    try:
                        result = json.loads(body)
                    except Exception:
                        pass  # Keep original result if body isn't valid JSON
                elif isinstance(body, dict):
                    result = body

            duration = time.time() - start_time

            log.info(
                "invoke_completed",
                function_name=function_name,
                call_depth=call_depth + 1,
                duration_seconds=duration,
                duration_ms=duration * 1000,
                status="success",
                result_present=result is not None
            )

            return result

        except Exception as e:
            duration = time.time() - start_time

            log.error(
                "invoke_failed",
                function_name=function_name,
                call_depth=call_depth + 1,
                duration_seconds=duration,
                duration_ms=duration * 1000,
                error=e,
                status="error"
            )

            if fail_on_error:
                raise

            return None

        finally:
            # Restore previous call stack
            invoke_call_stack.set(call_stack)

    def get_handler(self, function_name: str) -> Optional[Callable]:
        """Get handler by function name."""
        return self._handlers.get(function_name)

    def has_handler(self, function_name: str) -> bool:
        """Check if handler is registered."""
        return function_name in self._handlers

    def get_all_handlers(self) -> Dict[str, Callable]:
        """Get all registered handlers."""
        return self._handlers.copy()

    def get_handler_metadata(self, function_name: str) -> Optional[Dict[str, Any]]:
        """Get handler metadata."""
        return self._handler_metadata.get(function_name)

    def is_empty(self) -> bool:
        """Check if registry has no handlers registered."""
        return len(self._handlers) == 0

    def get_statistics(self) -> Dict[str, Any]:
        """Get registry statistics."""
        services = set()
        handlers_by_service = {}

        for function_name, metadata in self._handler_metadata.items():
            service = metadata.get('service')
            if service:
                services.add(service)
                if service not in handlers_by_service:
                    handlers_by_service[service] = []
                handlers_by_service[service].append(function_name)

        return {
            'total_handlers': len(self._handlers),
            'total_services': len(services),
            'services': sorted(services),
            'handlers': list(self._handlers.keys()),
            'handlers_by_service': handlers_by_service
        }


# =============================================================================
# NATS Invoke Publishing (async worker delivery)
# =============================================================================

_invoke_nats_client = None
_invoke_nats_loop_id = None
_invoke_nats_url = os.getenv("NATS_URL", "nats://nats:4222")


async def _get_invoke_nats():
    """Get or create NATS JetStream connection for invoke publishing."""
    global _invoke_nats_client, _invoke_nats_loop_id
    import asyncio
    current_loop_id = id(asyncio.get_running_loop())

    needs_reconnect = False
    if _invoke_nats_client is None:
        needs_reconnect = True
    elif _invoke_nats_loop_id != current_loop_id:
        needs_reconnect = True
    elif not _invoke_nats_client.is_connected:
        needs_reconnect = True

    if needs_reconnect:
        _invoke_nats_client = None
        _invoke_nats_loop_id = None
        try:
            import nats
            _invoke_nats_client = await nats.connect(_invoke_nats_url)
            _invoke_nats_loop_id = current_loop_id
            log.debug("invoke_nats_connected", url=_invoke_nats_url)
        except Exception as e:
            log.warning("invoke_nats_connect_failed", error=str(e))
            _invoke_nats_client = None
    return _invoke_nats_client


async def publish_invoke(function_name: str, payload: Dict[str, Any]) -> bool:
    """
    Publish an async invoke message to the NATS INVOKE JetStream.

    The async worker subscribes to invoke.> and routes to the registered handler.

    Args:
        function_name: Service-qualified name (e.g., 'imports:batchSplitter')
                       or simple name (e.g., 'batchSplitter')
        payload: Event payload dict (must be JSON-serializable)

    Returns:
        True if published successfully, False otherwise
    """
    import asyncio
    nc = await _get_invoke_nats()
    if not nc:
        log.error("invoke_publish_no_connection", function_name=function_name)
        return False

    try:
        # Build subject: invoke.{service}.{function} or invoke.{function}
        if ':' in function_name:
            service, func = function_name.split(':', 1)
            subject = f"invoke.{service}.{func}"
        else:
            subject = f"invoke.{function_name}"

        message = json.dumps({
            'function_name': function_name,
            'payload': payload,
        }, default=str).encode()

        js = nc.jetstream()
        ack = await js.publish(subject, message)

        log.info("invoke_published",
            function_name=function_name,
            subject=subject,
            stream=ack.stream,
            seq=ack.seq
        )
        return True

    except Exception as e:
        log.error("invoke_publish_failed",
            function_name=function_name,
            error=e
        )
        return False


def publish_invoke_sync(function_name: str, payload: Dict[str, Any]) -> bool:
    """
    Synchronous wrapper for publish_invoke.

    Safe to call from @as_api() or @invoke() handlers (sync context).
    """
    import asyncio
    import concurrent.futures

    try:
        loop = asyncio.get_running_loop()
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(asyncio.run, publish_invoke(function_name, payload))
            return future.result(timeout=10)
    except RuntimeError:
        return asyncio.run(publish_invoke(function_name, payload))
    except Exception as e:
        log.error("invoke_publish_sync_failed", function_name=function_name, error=e)
        return False


# Singleton instance
_registry: Optional[InvokeRegistry] = None


def get_invoke_registry() -> Optional[InvokeRegistry]:
    """
    Get the singleton InvokeRegistry instance.

    Returns the registry set by set_invoke_registry(), or None if not yet initialized.
    In shared-runtime, the shim (platform_services.shared.invoke_registry) creates
    PlatformInvokeRegistry and calls set_invoke_registry() to sync it here.
    """
    return _registry


def set_invoke_registry(registry: InvokeRegistry):
    """
    Set the singleton InvokeRegistry instance.

    Called by the platform shim (platform_services.shared.invoke_registry)
    to sync the PlatformInvokeRegistry subclass into onexcore so that
    both import paths return the same instance.

    Args:
        registry: InvokeRegistry (or subclass) instance
    """
    global _registry
    _registry = registry
    log.debug("invoke_registry_set", registry_type=type(registry).__name__)
