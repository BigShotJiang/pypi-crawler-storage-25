"""
Error enrichment: traceback extraction, fingerprinting, PII redaction.

Provides rich error context for structured logging — tracebacks with source code,
stable fingerprints for grouping, and automatic PII masking.
"""
import hashlib
import os
import re
import traceback as tb_module
from typing import Any

# Directories considered "service code" (not framework/library)
_SERVICE_DIRS = ('/app/services/',)

# PII patterns
_PII_PATTERNS = [
    (re.compile(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'), '[EMAIL]'),
    (re.compile(r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b'), '[PHONE]'),
    (re.compile(r'\b\d{13,19}\b'), '[CARD]'),
    (re.compile(r'(?i)(password|secret|token|api[_-]?key|authorization)\s*[:=]\s*\S+'), r'\1=[REDACTED]'),
    (re.compile(r'eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}'), '[JWT]'),
]


def extract_traceback(error: BaseException) -> list[dict]:
    """Extract traceback frames, prioritising service code.

    Returns list of frames like:
        [{"file": "src/apis/order.py", "function": "create", "line": 42, "code": "db.insert(doc)"}]
    """
    frames = []
    for frame_info in tb_module.extract_tb(error.__traceback__):
        filename = frame_info.filename
        # Make paths relative to /app/services/ for readability
        rel = filename
        for prefix in _SERVICE_DIRS:
            if prefix in filename:
                idx = filename.index(prefix) + len(prefix)
                # e.g. "auth/src/apis/login.py"
                rel = filename[idx:]
                break

        frames.append({
            'file': rel,
            'function': frame_info.name,
            'line': frame_info.lineno,
            'code': frame_info.line or '',
        })
    return frames


def _is_service_frame(frame: dict) -> bool:
    """Check if a frame is from service code (not stdlib/libs)."""
    f = frame.get('file', '')
    return not f.startswith('/usr/') and not f.startswith('/app/platform_services/')


def service_frames(frames: list[dict]) -> list[dict]:
    """Filter to only service-relevant frames."""
    svc = [f for f in frames if _is_service_frame(f)]
    return svc if svc else frames  # fallback to all if no service frames


def generate_fingerprint(error_type: str, file: str, function: str, message: str) -> str:
    """Generate a stable SHA-256 fingerprint for grouping identical errors.

    Normalizes the message (strips numbers, UUIDs) so that different
    instances of the same bug produce the same hash.
    """
    # Normalize: strip UUIDs, ObjectIds, numbers, timestamps
    normalized = re.sub(r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}', '<ID>', message)
    normalized = re.sub(r'[0-9a-f]{24}', '<OID>', normalized)
    normalized = re.sub(r'\b\d+\b', '<N>', normalized)

    raw = f"{error_type}:{file}:{function}:{normalized}"
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


def redact_pii(data: Any) -> Any:
    """Recursively redact PII from data structures (dicts, lists, strings)."""
    if isinstance(data, str):
        result = data
        for pattern, replacement in _PII_PATTERNS:
            result = pattern.sub(replacement, result)
        return result
    elif isinstance(data, dict):
        return {k: redact_pii(v) for k, v in data.items()}
    elif isinstance(data, (list, tuple)):
        return type(data)(redact_pii(item) for item in data)
    return data


def enrich_error(error: BaseException, payload: Any = None) -> dict:
    """Build a rich error dict suitable for structured log fields.

    Returns:
        {
            "error_type": "MongoTimeoutError",
            "error_message": "Connection timed out",
            "traceback": [...frames...],
            "error_fingerprint": "a1b2c3d4e5f6g7h8",
            "payload": {...redacted...}   # only if provided
        }
    """
    frames = extract_traceback(error)
    svc = service_frames(frames)
    top = svc[-1] if svc else (frames[-1] if frames else {})

    result = {
        'error_type': type(error).__name__,
        'error_message': str(error),
        'traceback': svc if svc else frames,
        'error_fingerprint': generate_fingerprint(
            type(error).__name__,
            top.get('file', ''),
            top.get('function', ''),
            str(error),
        ),
    }
    if payload is not None:
        result['payload'] = redact_pii(payload)
    return result
