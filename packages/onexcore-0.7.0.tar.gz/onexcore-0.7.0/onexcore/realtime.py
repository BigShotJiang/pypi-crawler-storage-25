"""
Real-time messaging client for OneXEOS services.

Publishes messages to the WebSocket Gateway via NATS for delivery
to connected WebSocket clients.

Usage:
    from onexcore.realtime import push_to_room_sync

    @as_api()
    def create_order(request):
        order = OrderService.create(request.body)
        push_to_room_sync(f"pos_{order.store_id}", {
            "type": "CREATE_ORDER",
            "order": order.to_dict()
        }, trace_id=request.trace_id)
        return order

Async usage:
    from onexcore.realtime import push_to_room

    async def handler():
        await push_to_room("user_123", {"type": "notification", "text": "Hello"})
"""

import os
import json
import asyncio
import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)

# NATS connection (lazy initialized)
_nats_client = None
_nats_url = os.getenv("NATS_URL", "nats://nats:4222")

# HTTP fallback
_ws_gateway_url = os.getenv("WEBSOCKET_GATEWAY_URL", "http://websocket-gateway:8010")


_nats_loop_id = None  # Track which event loop owns the NATS client


async def _get_nats():
    """Get or create NATS connection for the current event loop."""
    global _nats_client, _nats_loop_id
    current_loop_id = id(asyncio.get_running_loop())

    # Always reconnect if the event loop changed (_run_async creates new loops)
    needs_reconnect = False
    if _nats_client is None:
        needs_reconnect = True
    elif _nats_loop_id != current_loop_id:
        needs_reconnect = True
    elif not _nats_client.is_connected:
        needs_reconnect = True

    if needs_reconnect:
        # Don't try to close stale client from a different loop — just discard
        _nats_client = None
        _nats_loop_id = None
        try:
            import nats
            _nats_client = await nats.connect(_nats_url)
            _nats_loop_id = current_loop_id
            logger.debug(f"[REALTIME] Connected to NATS: {_nats_url}")
        except Exception as e:
            logger.warning(f"[REALTIME] NATS connection failed: {e}")
            _nats_client = None
    return _nats_client


async def push_to_room(room_id: str, data: Any, trace_id: str = None) -> bool:
    """
    Push a message to all WebSocket clients in a room.

    Args:
        room_id: Room identifier (e.g., "pos_store1", "user_123")
        data: Message payload (will be JSON serialized)
        trace_id: Optional trace ID for debugging

    Returns:
        True if message was published successfully
    """
    nc = await _get_nats()
    if not nc:
        return await _http_fallback_room(room_id, data, trace_id)

    try:
        payload = {"data": data}
        if trace_id:
            payload["trace_id"] = trace_id

        await nc.publish(f"ws.room.{room_id}", json.dumps(payload).encode())
        await nc.flush()
        logger.debug(f"[REALTIME] Published to ws.room.{room_id}")
        return True
    except Exception as e:
        logger.warning(f"[REALTIME] NATS publish failed: {e}")
        _invalidate_nats()
        return await _http_fallback_room(room_id, data, trace_id)


async def push_to_user(user_id: str, data: Any, trace_id: str = None) -> bool:
    """
    Push a message to all WebSocket connections of a user.

    Args:
        user_id: User identifier
        data: Message payload
        trace_id: Optional trace ID for debugging

    Returns:
        True if message was published successfully
    """
    nc = await _get_nats()
    if not nc:
        return await _http_fallback_user(user_id, data, trace_id)

    try:
        payload = {"data": data}
        if trace_id:
            payload["trace_id"] = trace_id

        await nc.publish(f"ws.user.{user_id}", json.dumps(payload).encode())
        await nc.flush()
        logger.debug(f"[REALTIME] Published to ws.user.{user_id}")
        return True
    except Exception as e:
        logger.warning(f"[REALTIME] NATS publish failed: {e}")
        _invalidate_nats()
        return await _http_fallback_user(user_id, data, trace_id)


async def push_to_company(company_id: str, data: Any, trace_id: str = None) -> bool:
    """
    Broadcast a message to all WebSocket connections of a company.

    Args:
        company_id: Company/tenant identifier
        data: Message payload
        trace_id: Optional trace ID for debugging

    Returns:
        True if message was published successfully
    """
    nc = await _get_nats()
    if not nc:
        return await _http_fallback_company(company_id, data, trace_id)

    try:
        payload = {"data": data}
        if trace_id:
            payload["trace_id"] = trace_id

        await nc.publish(f"ws.broadcast.{company_id}", json.dumps(payload).encode())
        await nc.flush()
        logger.debug(f"[REALTIME] Published to ws.broadcast.{company_id}")
        return True
    except Exception as e:
        logger.warning(f"[REALTIME] NATS publish failed: {e}")
        _invalidate_nats()
        return await _http_fallback_company(company_id, data, trace_id)


# =============================================================================
# Sync wrappers for @as_api() handlers
# =============================================================================

def push_to_room_sync(room_id: str, data: Any, trace_id: str = None) -> bool:
    """Synchronous wrapper for push_to_room. Safe to call from @as_api() handlers."""
    return _run_async(push_to_room(room_id, data, trace_id))


def push_to_user_sync(user_id: str, data: Any, trace_id: str = None) -> bool:
    """Synchronous wrapper for push_to_user. Safe to call from @as_api() handlers."""
    return _run_async(push_to_user(user_id, data, trace_id))


def push_to_company_sync(company_id: str, data: Any, trace_id: str = None) -> bool:
    """Synchronous wrapper for push_to_company. Safe to call from @as_api() handlers."""
    return _run_async(push_to_company(company_id, data, trace_id))


# =============================================================================
# HTTP fallback (when NATS is unavailable)
# =============================================================================

async def _http_fallback_room(room_id: str, data: Any, trace_id: str = None) -> bool:
    try:
        import httpx
        async with httpx.AsyncClient(timeout=5.0) as client:
            payload = {"room_id": room_id, "data": data}
            if trace_id:
                payload["trace_id"] = trace_id
            resp = await client.post(f"{_ws_gateway_url}/_internal/ws/publish", json=payload)
            return resp.status_code == 200
    except Exception as e:
        logger.error(f"[REALTIME] HTTP fallback failed: {e}")
        return False


async def _http_fallback_user(user_id: str, data: Any, trace_id: str = None) -> bool:
    try:
        import httpx
        async with httpx.AsyncClient(timeout=5.0) as client:
            payload = {"user_id": user_id, "data": data}
            if trace_id:
                payload["trace_id"] = trace_id
            resp = await client.post(f"{_ws_gateway_url}/_internal/ws/publish/user", json=payload)
            return resp.status_code == 200
    except Exception as e:
        logger.error(f"[REALTIME] HTTP fallback failed: {e}")
        return False


async def _http_fallback_company(company_id: str, data: Any, trace_id: str = None) -> bool:
    try:
        import httpx
        async with httpx.AsyncClient(timeout=5.0) as client:
            payload = {"company_id": company_id, "data": data}
            if trace_id:
                payload["trace_id"] = trace_id
            resp = await client.post(f"{_ws_gateway_url}/_internal/ws/publish/company", json=payload)
            return resp.status_code == 200
    except Exception as e:
        logger.error(f"[REALTIME] HTTP fallback failed: {e}")
        return False


# =============================================================================
# Helpers
# =============================================================================

def _invalidate_nats():
    """Reset the NATS client so the next call reconnects."""
    global _nats_client
    _nats_client = None


def _run_async(coro) -> bool:
    """Run an async coroutine from sync context."""
    try:
        loop = asyncio.get_running_loop()
        # We're inside an async context — schedule as a task
        # Use run_in_executor pattern for sync-in-async safety
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(asyncio.run, coro)
            return future.result(timeout=10)
    except RuntimeError:
        # No running loop — safe to use asyncio.run
        return asyncio.run(coro)
    except Exception as e:
        logger.error(f"[REALTIME] Sync wrapper failed: {e}")
        return False
