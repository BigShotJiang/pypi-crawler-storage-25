"""
onexcore - Structured logging, context propagation, error enrichment, NATS publishing,
and real-time messaging for OneXEOS.

Usage:
    from onexcore import log, bind_context, setup_logging

    setup_logging()                                    # Once at startup
    bind_context(trace_id="abc-123", service="auth")   # Per-request
    log.info("Order created", order_id="123")          # Auto-injects context
    log.error("DB failed", error=exc, payload=data)    # Traceback + fingerprint

NATS publishing:
    from onexcore.nats import publish_sync

    publish_sync("property.contract.activated", {"contract_id": "c-123"})

Real-time messaging:
    from onexcore.realtime import push_to_room_sync

    push_to_room_sync("pos_store1", {"type": "ORDER_CREATED", "order": order})
"""

__version__ = "0.7.0"

from .logger import log
from .context import bind_context, get_context, clear_context
from .formatter import setup_logging
from .db import get_db
from .es import get_es
from .invoke import get_invoke_registry, set_invoke_registry, InvokeRegistry
from .nats import publish, publish_sync

__all__ = [
    "log",
    "bind_context",
    "get_context",
    "clear_context",
    "setup_logging",
    "get_db",
    "get_es",
    "get_invoke_registry",
    "set_invoke_registry",
    "InvokeRegistry",
    "publish",
    "publish_sync",
]
