"""Tests for ``connector.py`` — scope mapping + admin consent detection.

Phase 1 doesn't store tokens yet, so these tests focus on the pure
helpers that the OAuth flow (Phase 2) will rely on:

  - ``required_scopes_for`` deduplicates and orders scopes correctly.
  - ``admin_consent_required`` flags the right subset.
  - ``is_configured`` reads the right env vars.
"""

from __future__ import annotations

import os
from unittest.mock import patch

from piilot_pack_microsoft_365 import connector as c


class TestScopeMapping:
    def test_outlook_read_only_maps_to_mail_read(self):
        scopes = c.required_scopes_for(["outlook.read"])
        assert scopes == ["Mail.Read"]

    def test_outlook_read_and_write_includes_send(self):
        scopes = c.required_scopes_for(["outlook.read", "outlook.write"])
        assert "Mail.Read" in scopes
        assert "Mail.Send" in scopes
        assert "Mail.ReadWrite" in scopes

    def test_unknown_permission_silently_dropped(self):
        scopes = c.required_scopes_for(["outlook.read", "future.feature"])
        assert scopes == ["Mail.Read"]

    def test_duplicates_collapsed(self):
        scopes = c.required_scopes_for(["outlook.read", "outlook.read"])
        assert scopes == ["Mail.Read"]

    def test_full_v01_set_maps_to_expected_scopes(self):
        all_perms = list(c.SCOPE_GROUPS.keys())
        scopes = c.required_scopes_for(all_perms)
        # Sanity checks for each service
        assert "Mail.Read" in scopes
        assert "Files.Read" in scopes
        assert "Sites.Read.All" in scopes
        assert "Chat.Read" in scopes
        # No duplicates
        assert len(scopes) == len(set(scopes))


class TestAdminConsent:
    def test_outlook_user_only_no_admin_consent_required(self):
        scopes = c.required_scopes_for(["outlook.read", "outlook.write"])
        assert c.admin_consent_required(scopes) == []

    def test_sharepoint_triggers_admin_consent(self):
        scopes = c.required_scopes_for(["sharepoint.read"])
        consent = c.admin_consent_required(scopes)
        assert consent == ["Sites.Read.All"]

    def test_teams_read_triggers_admin_consent_for_channel_messages(self):
        scopes = c.required_scopes_for(["teams.read"])
        consent = c.admin_consent_required(scopes)
        assert "ChannelMessage.Read.All" in consent

    def test_mixed_set_returns_only_the_admin_subset(self):
        scopes = c.required_scopes_for(
            [
                "outlook.read",
                "sharepoint.read",
                "onedrive.read",
            ]
        )
        consent = c.admin_consent_required(scopes)
        # SharePoint scopes need admin; Outlook + OneDrive don't.
        assert "Sites.Read.All" in consent
        assert "Mail.Read" not in consent
        assert "Files.Read" not in consent


class TestIsConfigured:
    def test_returns_false_when_env_unset(self):
        with patch.dict(os.environ, {}, clear=True):
            assert c.is_configured() is False

    def test_returns_false_when_only_client_id_set(self):
        with patch.dict(os.environ, {c.ENV_CLIENT_ID: "x"}, clear=True):
            assert c.is_configured() is False

    def test_returns_true_when_both_set(self):
        with patch.dict(
            os.environ,
            {c.ENV_CLIENT_ID: "abc", c.ENV_TENANT_ID: "common"},
            clear=True,
        ):
            assert c.is_configured() is True
