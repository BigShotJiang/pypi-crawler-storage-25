"""Tests for the SharePoint tools — Phase 6.

Same coverage matrix as OneDrive (validation + happy paths + 2-step
intent lifecycle), plus list_sites which is SharePoint-specific.
The intent bucket is **distinct** from OneDrive's so we also pin
the no-cross-collision contract.
"""

from __future__ import annotations

import time
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from piilot_pack_microsoft_365.client import (
    GraphNotFoundError,
    GraphPermissionError,
)
from piilot_pack_microsoft_365.tools import sharepoint as sp

_MODULE = "piilot_pack_microsoft_365.tools.sharepoint"
_VALID_SITE_ID = "contoso.sharepoint.com,abc-1234,def-5678"


def _state_with_company(company_id: str = "c-1"):
    state = MagicMock()
    state.user_infos = {"_organization_id": company_id}
    return state


@pytest.fixture
def stubbed_runtime():
    state = _state_with_company()
    fake_client = MagicMock()
    fake_client.get = AsyncMock()
    fake_client.request = AsyncMock()
    fake_client._base_url = "https://graph.microsoft.com/v1.0"
    fake_client._http = MagicMock()
    fake_client._http.put = AsyncMock()

    with (
        patch(f"{_MODULE}._get_session_state", return_value=state),
        patch(f"{_MODULE}.ensure_permission", AsyncMock(return_value=True)),
        patch(f"{_MODULE}.resolve_access_token", AsyncMock(return_value="tok")),
        patch(f"{_MODULE}._get_client", return_value=fake_client),
    ):
        yield {"state": state, "client": fake_client}


# ---------------------------------------------------------------------------
# Permission gate
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestPermissionGate:
    @pytest.mark.parametrize(
        "tool_call,expected_perm",
        [
            (
                lambda sid: sp.list_sites_fn(
                    config={"configurable": {"session_id": sid}}
                ),
                "sharepoint.read",
            ),
            (
                lambda sid: sp.list_site_files_fn(
                    site_id=_VALID_SITE_ID, config={"configurable": {"session_id": sid}}
                ),
                "sharepoint.read",
            ),
            (
                lambda sid: sp.download_site_file_fn(
                    site_id=_VALID_SITE_ID,
                    file_id="f",
                    config={"configurable": {"session_id": sid}},
                ),
                "sharepoint.read",
            ),
            (
                lambda sid: sp.prepare_site_upload_fn(
                    site_id=_VALID_SITE_ID,
                    file_name="x.md",
                    content="y",
                    config={"configurable": {"session_id": sid}},
                ),
                "sharepoint.write",
            ),
            (
                lambda sid: sp.confirm_site_upload_fn(
                    upload_intent_id="i", config={"configurable": {"session_id": sid}}
                ),
                "sharepoint.write",
            ),
        ],
    )
    async def test_each_tool_blocked_when_permission_off(
        self, tool_call, expected_perm
    ):
        state = _state_with_company()
        with (
            patch(f"{_MODULE}._get_session_state", return_value=state),
            patch(f"{_MODULE}.ensure_permission", AsyncMock(return_value=False)),
        ):
            out = await tool_call("s")
        assert out["error_code"] == "M365_PERMISSION_DISABLED"
        assert out["permission"] == expected_perm


# ---------------------------------------------------------------------------
# list_sites
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestListSites:
    async def test_default_query_uses_wildcard(self, stubbed_runtime):
        stubbed_runtime["client"].get.return_value = {"value": []}
        await sp.list_sites_fn(config={"configurable": {"session_id": "s"}})
        params = stubbed_runtime["client"].get.call_args.kwargs["params"]
        assert params["search"] == "*"

    async def test_specific_query_passed_through(self, stubbed_runtime):
        stubbed_runtime["client"].get.return_value = {"value": []}
        await sp.list_sites_fn(
            query="Marketing",
            config={"configurable": {"session_id": "s"}},
        )
        params = stubbed_runtime["client"].get.call_args.kwargs["params"]
        assert params["search"] == "Marketing"

    async def test_returns_summarised_sites(self, stubbed_runtime):
        stubbed_runtime["client"].get.return_value = {
            "value": [
                {
                    "id": _VALID_SITE_ID,
                    "displayName": "Marketing Team",
                    "description": "Site Marketing",
                    "webUrl": "https://contoso.sharepoint.com/marketing",
                    "createdDateTime": "2024-01-01T00:00:00Z",
                },
            ],
        }
        out = await sp.list_sites_fn(
            query="marketing",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["count"] == 1
        assert out["items"][0]["name"] == "Marketing Team"
        assert out["items"][0]["id"] == _VALID_SITE_ID

    async def test_limit_capped_at_max(self, stubbed_runtime):
        stubbed_runtime["client"].get.return_value = {"value": []}
        await sp.list_sites_fn(
            limit=999,
            config={"configurable": {"session_id": "s"}},
        )
        assert stubbed_runtime["client"].get.call_args.kwargs["params"]["$top"] == 25


# ---------------------------------------------------------------------------
# list_site_files
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestListSiteFiles:
    async def test_root_when_no_folder_id(self, stubbed_runtime):
        stubbed_runtime["client"].get.return_value = {"value": []}
        await sp.list_site_files_fn(
            site_id=_VALID_SITE_ID,
            config={"configurable": {"session_id": "s"}},
        )
        path = stubbed_runtime["client"].get.call_args.args[0]
        assert path == f"sites/{_VALID_SITE_ID}/drive/root/children"

    async def test_specific_folder(self, stubbed_runtime):
        stubbed_runtime["client"].get.return_value = {"value": []}
        await sp.list_site_files_fn(
            site_id=_VALID_SITE_ID,
            folder_id="folder-99",
            config={"configurable": {"session_id": "s"}},
        )
        path = stubbed_runtime["client"].get.call_args.args[0]
        assert path == f"sites/{_VALID_SITE_ID}/drive/items/folder-99/children"

    async def test_invalid_site_id_rejected(self, stubbed_runtime):
        # Site IDs are validated against a strict regex — anything with
        # spaces or HTML-ish characters fails before hitting Graph.
        out = await sp.list_site_files_fn(
            site_id="bad site id with spaces",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "INVALID_SITE_ID"
        stubbed_runtime["client"].get.assert_not_called()

    async def test_empty_site_id_rejected(self, stubbed_runtime):
        out = await sp.list_site_files_fn(
            site_id="",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "INVALID_SITE_ID"


# ---------------------------------------------------------------------------
# download_site_file
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestDownloadSiteFile:
    async def test_returns_metadata_plus_signed_url(self, stubbed_runtime):
        stubbed_runtime["client"].get.return_value = {
            "id": "f-1",
            "name": "Spec.docx",
            "size": 50000,
            "file": {"mimeType": "application/vnd.openxmlformats..."},
            "lastModifiedDateTime": "2026-04-30T10:00:00Z",
            "parentReference": {"path": "/sites/marketing/Documents"},
            "webUrl": "https://contoso.sharepoint.com/marketing/Spec.docx",
            "@microsoft.graph.downloadUrl": "https://signed-url.example/spec",
        }
        out = await sp.download_site_file_fn(
            site_id=_VALID_SITE_ID,
            file_id="f-1",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["file"]["name"] == "Spec.docx"
        assert out["download_url"] == "https://signed-url.example/spec"

    async def test_folder_returns_is_folder(self, stubbed_runtime):
        stubbed_runtime["client"].get.return_value = {
            "id": "fld",
            "name": "Reports",
            "folder": {"childCount": 2},
            "lastModifiedDateTime": "2026-04-30T10:00:00Z",
            "parentReference": {},
        }
        out = await sp.download_site_file_fn(
            site_id=_VALID_SITE_ID,
            file_id="fld",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "IS_FOLDER"

    async def test_404_mapped(self, stubbed_runtime):
        stubbed_runtime["client"].get.side_effect = GraphNotFoundError("404")
        out = await sp.download_site_file_fn(
            site_id=_VALID_SITE_ID,
            file_id="missing",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "M365_NOT_FOUND"

    async def test_403_carries_admin_consent_hint(self, stubbed_runtime):
        stubbed_runtime["client"].get.side_effect = GraphPermissionError(
            "403",
            response_body={"error": {"code": "Authorization_RequestDenied"}},
        )
        out = await sp.download_site_file_fn(
            site_id=_VALID_SITE_ID,
            file_id="f",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "M365_GRAPH_PERMISSION"
        assert "admin tenant" in out["error"]


# ---------------------------------------------------------------------------
# prepare_site_upload + confirm_site_upload
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestPrepareSiteUpload:
    async def test_happy_path_stores_intent_with_site_id(self, stubbed_runtime):
        out = await sp.prepare_site_upload_fn(
            site_id=_VALID_SITE_ID,
            file_name="rapport.md",
            content="Body",
            parent_folder_id="folder-1",
            config={"configurable": {"session_id": "s"}},
        )
        assert "upload_intent_id" in out
        assert out["preview"]["site_id"] == _VALID_SITE_ID
        intents = stubbed_runtime["state"].user_infos["_m365_sharepoint_upload_intents"]
        assert intents[out["upload_intent_id"]]["site_id"] == _VALID_SITE_ID

    async def test_invalid_site_id_rejected(self, stubbed_runtime):
        out = await sp.prepare_site_upload_fn(
            site_id="bad spaces",
            file_name="ok.md",
            content="x",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "INVALID_SITE_ID"

    async def test_invalid_filename_rejected(self, stubbed_runtime):
        out = await sp.prepare_site_upload_fn(
            site_id=_VALID_SITE_ID,
            file_name="bad/path.md",
            content="x",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "INVALID_FILENAME"

    async def test_intent_bucket_distinct_from_onedrive(self, stubbed_runtime):
        """A SharePoint intent must NOT land in OneDrive's bucket and
        vice versa — otherwise an admin running both flows could
        accidentally cross-confirm.
        """
        await sp.prepare_site_upload_fn(
            site_id=_VALID_SITE_ID,
            file_name="x.md",
            content="y",
            config={"configurable": {"session_id": "s"}},
        )
        infos = stubbed_runtime["state"].user_infos
        assert "_m365_sharepoint_upload_intents" in infos
        # OneDrive's key must NOT be created by this call
        assert "_m365_upload_intents" not in infos


@pytest.mark.asyncio
class TestConfirmSiteUpload:
    async def _seed_intent(
        self,
        state,
        *,
        file_name: str = "r.md",
        site_id: str = _VALID_SITE_ID,
        parent_folder_id: str = "",
    ):
        intents = state.user_infos.setdefault("_m365_sharepoint_upload_intents", {})
        intent_id = "intent-test"
        intents[intent_id] = {
            "site_id": site_id,
            "file_name": file_name,
            "parent_folder_id": parent_folder_id,
            "content": b"hello",
            "size_bytes": 5,
            "created_at": time.monotonic(),
        }
        return intent_id

    def _ok_resp(self, body: dict | None = None):
        resp = MagicMock()
        resp.status_code = 201
        resp.json.return_value = body or {
            "id": "f-uploaded",
            "name": "r.md",
            "size": 5,
            "file": {"mimeType": "text/markdown"},
            "lastModifiedDateTime": "2026-04-30T10:00:00Z",
            "parentReference": {"path": "/sites/marketing"},
        }
        return resp

    def _err_resp(self, status: int):
        resp = MagicMock()
        resp.status_code = status
        return resp

    async def test_uploads_to_root_when_no_parent(self, stubbed_runtime):
        intent_id = await self._seed_intent(stubbed_runtime["state"])
        stubbed_runtime["client"]._http.put.return_value = self._ok_resp()
        await sp.confirm_site_upload_fn(
            upload_intent_id=intent_id,
            config={"configurable": {"session_id": "s"}},
        )
        url = stubbed_runtime["client"]._http.put.call_args.args[0]
        assert url.endswith(f"/sites/{_VALID_SITE_ID}/drive/root:/r.md:/content")

    async def test_uploads_to_specific_folder(self, stubbed_runtime):
        intent_id = await self._seed_intent(
            stubbed_runtime["state"],
            parent_folder_id="folder-99",
        )
        stubbed_runtime["client"]._http.put.return_value = self._ok_resp()
        await sp.confirm_site_upload_fn(
            upload_intent_id=intent_id,
            config={"configurable": {"session_id": "s"}},
        )
        url = stubbed_runtime["client"]._http.put.call_args.args[0]
        assert url.endswith(
            f"/sites/{_VALID_SITE_ID}/drive/items/folder-99:/r.md:/content"
        )

    async def test_intent_consumed_on_success(self, stubbed_runtime):
        intent_id = await self._seed_intent(stubbed_runtime["state"])
        stubbed_runtime["client"]._http.put.return_value = self._ok_resp()
        await sp.confirm_site_upload_fn(
            upload_intent_id=intent_id,
            config={"configurable": {"session_id": "s"}},
        )
        assert (
            intent_id
            not in stubbed_runtime["state"].user_infos[
                "_m365_sharepoint_upload_intents"
            ]
        )

    async def test_unknown_intent_no_network_call(self, stubbed_runtime):
        out = await sp.confirm_site_upload_fn(
            upload_intent_id="never-prepared",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "INTENT_NOT_FOUND"
        stubbed_runtime["client"]._http.put.assert_not_called()

    async def test_expired_intent_treated_as_not_found(self, stubbed_runtime):
        state = stubbed_runtime["state"]
        intents = state.user_infos.setdefault("_m365_sharepoint_upload_intents", {})
        intents["stale"] = {
            "site_id": _VALID_SITE_ID,
            "file_name": "old.md",
            "parent_folder_id": "",
            "content": b"old",
            "size_bytes": 3,
            "created_at": time.monotonic() - sp._INTENT_TTL_SECONDS - 1,
        }
        out = await sp.confirm_site_upload_fn(
            upload_intent_id="stale",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "INTENT_NOT_FOUND"

    async def test_403_mapped_with_admin_consent_hint(self, stubbed_runtime):
        intent_id = await self._seed_intent(stubbed_runtime["state"])
        stubbed_runtime["client"]._http.put.return_value = self._err_resp(403)
        out = await sp.confirm_site_upload_fn(
            upload_intent_id=intent_id,
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "M365_GRAPH_PERMISSION"
        assert "admin consent SharePoint" in out["error"]
