"""Tests for the Phase 1 ``whoami`` tool.

Two surfaces:

  - ``whoami_fn`` is the LLM-facing entry point. Phase 1 returns a
    deterministic "not connected yet" payload — we pin that contract
    so a regression that accidentally exposes a real Graph call here
    fails the test.
  - ``whoami_with_token`` is the helper Phase 2 will route through.
    We exercise it with a mocked Graph client to validate the response
    shaping (display_name / email / tenant fallback) and the typed
    error mapping (auth / permission / generic).
"""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest

from piilot_pack_microsoft_365.client import (
    GraphAuthError,
    GraphError,
    GraphPermissionError,
)
from piilot_pack_microsoft_365.tools.whoami import (
    whoami_fn,
    whoami_with_token,
)


@pytest.mark.asyncio
class TestPhase1Stub:
    async def test_whoami_fn_returns_not_connected_yet(self):
        # ``@bind_session`` is the canonical pattern (SDK 0.6) for
        # pulling ``session_id`` from the LangGraph RunnableConfig
        # without exposing it to the LLM. Tests must mimic the runtime
        # by passing ``config={"configurable": {"session_id": ...}}``.
        out = await whoami_fn(config={"configurable": {"session_id": "sess-1"}})
        assert "error" in out
        assert "Microsoft 365" in out["error"]
        # Phase tag — when this disappears, Phase 2 has shipped and the
        # test must be updated to assert the real flow.
        assert out["phase"] == "scaffolding-only"
        # session_id round-tripped via bind_session — proves the
        # @bind_session decorator is correctly applied.
        assert out["session_id"] == "sess-1"


@pytest.mark.asyncio
class TestWhoamiWithToken:
    async def test_happy_path_extracts_identity(self):
        graph_body = {
            "id": "u-aad-id",
            "displayName": "Alice Martin",
            "mail": "alice@acme.com",
            "userPrincipalName": "alice@acme.com",
        }
        with patch(
            "piilot_pack_microsoft_365.tools.whoami._get_client",
        ) as mock_get_client:
            mock_client = mock_get_client.return_value
            mock_client.get = AsyncMock(return_value=graph_body)
            out = await whoami_with_token("a-valid-token")
        assert out["display_name"] == "Alice Martin"
        assert out["email"] == "alice@acme.com"
        assert out["user_principal_name"] == "alice@acme.com"

    async def test_falls_back_to_upn_when_mail_missing(self):
        # Some accounts (e.g. resource accounts) have no ``mail`` set —
        # we fall back to ``userPrincipalName`` so the agent still has
        # an identifier to work with.
        graph_body = {
            "id": "u-2",
            "displayName": "Service Bot",
            "userPrincipalName": "bot@acme.com",
        }
        with patch(
            "piilot_pack_microsoft_365.tools.whoami._get_client",
        ) as mock_get_client:
            mock_client = mock_get_client.return_value
            mock_client.get = AsyncMock(return_value=graph_body)
            out = await whoami_with_token("tok")
        assert out["email"] == "bot@acme.com"

    async def test_auth_error_returns_friendly_message(self):
        with patch(
            "piilot_pack_microsoft_365.tools.whoami._get_client",
        ) as mock_get_client:
            mock_client = mock_get_client.return_value
            mock_client.get = AsyncMock(side_effect=GraphAuthError("bad token"))
            out = await whoami_with_token("expired")
        # No ``display_name`` / ``email`` keys — clients branch on the
        # presence of ``error`` instead.
        assert "error" in out
        assert "expir" in out["error"].lower() or "révoqué" in out["error"].lower()

    async def test_permission_error_carries_graph_error_code(self):
        body = {"error": {"code": "Authorization_RequestDenied"}}
        with patch(
            "piilot_pack_microsoft_365.tools.whoami._get_client",
        ) as mock_get_client:
            mock_client = mock_get_client.return_value
            mock_client.get = AsyncMock(
                side_effect=GraphPermissionError(
                    "denied",
                    response_body=body,
                )
            )
            out = await whoami_with_token("tok")
        assert "error" in out
        assert out["graph_error"] == "Authorization_RequestDenied"

    async def test_generic_error_does_not_raise(self):
        with patch(
            "piilot_pack_microsoft_365.tools.whoami._get_client",
        ) as mock_get_client:
            mock_client = mock_get_client.return_value
            mock_client.get = AsyncMock(
                side_effect=GraphError("graph 503", status_code=503),
            )
            out = await whoami_with_token("tok")
        # Always returns a dict (never raises) — so the agent loop keeps
        # running and the LLM can decide how to react.
        assert "error" in out
