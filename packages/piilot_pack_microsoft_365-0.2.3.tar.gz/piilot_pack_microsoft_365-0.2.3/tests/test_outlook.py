"""Tests for the Outlook tools — Phase 4.

Coverage strategy
-----------------

Each tool has 4 behaviours we want pinned:

  1. **Permission gate** : returns ``M365_PERMISSION_DISABLED`` when the
     scope toggle is off (Phase 3 will populate this; Phase 4 stub
     returns False so the gate is hit unconditionally).
  2. **Not connected** : returns ``M365_NOT_CONNECTED`` when no token
     resolves (Phase 2 will populate; stub always returns None).
  3. **Validation** : empty / malformed inputs caught before Graph.
  4. **Happy path** : with permissions granted + token resolved
     (mocked), the right Graph endpoint is called and the response
     shape is what the LLM expects.

We mock ``ensure_permission`` and ``resolve_access_token`` to bypass
the Phase 4 stubs and exercise the happy paths.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from piilot_pack_microsoft_365.client import (
    GraphAuthError,
    GraphNotFoundError,
    GraphPermissionError,
    GraphRateLimitedError,
)
from piilot_pack_microsoft_365.tools.outlook import (
    create_draft_fn,
    list_inbox_fn,
    read_mail_fn,
    search_mail_fn,
    send_draft_fn,
)

_MODULE = "piilot_pack_microsoft_365.tools.outlook"


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _state_with_company(company_id: str = "c-1"):
    """Mock SessionState exposing ``user_infos['_organization_id']``."""
    state = MagicMock()
    state.user_infos = {"_organization_id": company_id}
    return state


@pytest.fixture
def stubbed_runtime():
    """Patch the per-tool helpers so happy-path tests can run.

    Yields a dict of mock objects the test can configure:
      - ``client``: the Graph client whose ``get`` / ``request`` are AsyncMocks
      - ``state``: the resolved SessionState
    """
    state = _state_with_company()
    fake_client = MagicMock()
    fake_client.get = AsyncMock()
    fake_client.request = AsyncMock()

    with (
        patch(f"{_MODULE}._get_session_state", return_value=state),
        patch(f"{_MODULE}.ensure_permission", AsyncMock(return_value=True)),
        patch(f"{_MODULE}.resolve_access_token", AsyncMock(return_value="tok")),
        patch(f"{_MODULE}._get_client", return_value=fake_client),
    ):
        yield {"state": state, "client": fake_client}


# ---------------------------------------------------------------------------
# Permission gate (default Phase 4 stub: False)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestPermissionGate:
    @pytest.mark.parametrize(
        "tool_call",
        [
            lambda sid: search_mail_fn(
                query="hi", config={"configurable": {"session_id": sid}}
            ),
            lambda sid: read_mail_fn(
                message_id="m-1", config={"configurable": {"session_id": sid}}
            ),
            lambda sid: list_inbox_fn(config={"configurable": {"session_id": sid}}),
            lambda sid: create_draft_fn(
                to=["a@b.com"],
                subject="x",
                body="y",
                config={"configurable": {"session_id": sid}},
            ),
            lambda sid: send_draft_fn(
                draft_id="d-1", config={"configurable": {"session_id": sid}}
            ),
        ],
    )
    async def test_each_tool_blocked_when_permission_off(self, tool_call):
        state = _state_with_company()
        with (
            patch(f"{_MODULE}._get_session_state", return_value=state),
            patch(f"{_MODULE}.ensure_permission", AsyncMock(return_value=False)),
        ):
            out = await tool_call("sess-1")
        assert out["error_code"] == "M365_PERMISSION_DISABLED"
        # Read tools cite outlook.read; writes cite outlook.write.
        assert out["permission"] in ("outlook.read", "outlook.write")


# ---------------------------------------------------------------------------
# Not connected (Phase 2 will wire token storage; stub returns None)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestNotConnected:
    async def test_search_mail_not_connected(self):
        state = _state_with_company()
        with (
            patch(f"{_MODULE}._get_session_state", return_value=state),
            patch(f"{_MODULE}.ensure_permission", AsyncMock(return_value=True)),
            patch(f"{_MODULE}.resolve_access_token", AsyncMock(return_value=None)),
        ):
            out = await search_mail_fn(
                query="hi",
                config={"configurable": {"session_id": "s"}},
            )
        assert out["error_code"] == "M365_NOT_CONNECTED"

    async def test_send_draft_not_connected(self):
        state = _state_with_company()
        with (
            patch(f"{_MODULE}._get_session_state", return_value=state),
            patch(f"{_MODULE}.ensure_permission", AsyncMock(return_value=True)),
            patch(f"{_MODULE}.resolve_access_token", AsyncMock(return_value=None)),
        ):
            out = await send_draft_fn(
                draft_id="d",
                config={"configurable": {"session_id": "s"}},
            )
        assert out["error_code"] == "M365_NOT_CONNECTED"


# ---------------------------------------------------------------------------
# Session resolution
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestSessionResolution:
    async def test_missing_session_returns_error(self):
        with patch(f"{_MODULE}._get_session_state", return_value=None):
            out = await search_mail_fn(
                query="x",
                config={"configurable": {"session_id": "ghost"}},
            )
        assert out["error_code"] == "SESSION_NOT_FOUND"

    async def test_session_without_company_returns_error(self):
        state = MagicMock()
        state.user_infos = {}
        with patch(f"{_MODULE}._get_session_state", return_value=state):
            out = await search_mail_fn(
                query="x",
                config={"configurable": {"session_id": "s"}},
            )
        assert out["error_code"] == "NO_COMPANY"


# ---------------------------------------------------------------------------
# search_mail
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestSearchMail:
    async def test_happy_path_summarises_messages(self, stubbed_runtime):
        stubbed_runtime["client"].get.return_value = {
            "value": [
                {
                    "id": "m-1",
                    "subject": "Facture 2025",
                    "from": {
                        "emailAddress": {"name": "Alice", "address": "alice@acme.com"}
                    },
                    "toRecipients": [{"emailAddress": {"address": "me@piilot.ai"}}],
                    "receivedDateTime": "2026-04-30T10:00:00Z",
                    "isRead": False,
                    "hasAttachments": True,
                    "bodyPreview": "Bonjour, voici la facture en pièce jointe...",
                },
            ],
        }

        out = await search_mail_fn(
            query="facture",
            config={"configurable": {"session_id": "s"}},
        )

        assert out["count"] == 1
        item = out["items"][0]
        assert item["subject"] == "Facture 2025"
        assert item["from_email"] == "alice@acme.com"
        assert item["has_attachments"] is True
        assert item["preview"].startswith("Bonjour")

        # Graph called with $search + $top
        kwargs = stubbed_runtime["client"].get.call_args.kwargs
        assert kwargs["params"]["$search"] == '"facture"'
        assert kwargs["params"]["$top"] == 10  # default

    async def test_empty_query_rejected(self, stubbed_runtime):
        out = await search_mail_fn(
            query="   ",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "EMPTY_QUERY"
        stubbed_runtime["client"].get.assert_not_called()

    async def test_limit_capped_at_max(self, stubbed_runtime):
        stubbed_runtime["client"].get.return_value = {"value": []}
        await search_mail_fn(
            query="x",
            limit=999,
            config={"configurable": {"session_id": "s"}},
        )
        kwargs = stubbed_runtime["client"].get.call_args.kwargs
        assert kwargs["params"]["$top"] == 25  # _MAX_LIMIT

    async def test_graph_auth_error_mapped_to_token_expired(self, stubbed_runtime):
        stubbed_runtime["client"].get.side_effect = GraphAuthError("expired")
        out = await search_mail_fn(
            query="x",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "M365_TOKEN_EXPIRED"

    async def test_rate_limit_carries_retry_after(self, stubbed_runtime):
        stubbed_runtime["client"].get.side_effect = GraphRateLimitedError(
            "429",
            retry_after=12,
        )
        out = await search_mail_fn(
            query="x",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "M365_RATE_LIMITED"
        assert out["retry_after"] == 12


# ---------------------------------------------------------------------------
# read_mail
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestReadMail:
    async def test_returns_full_message(self, stubbed_runtime):
        stubbed_runtime["client"].get.return_value = {
            "id": "m-1",
            "subject": "Hello",
            "from": {"emailAddress": {"name": "X", "address": "x@y.com"}},
            "toRecipients": [{"emailAddress": {"address": "me@piilot.ai"}}],
            "ccRecipients": [{"emailAddress": {"address": "cc@y.com"}}],
            "receivedDateTime": "2026-04-30T10:00:00Z",
            "body": {"contentType": "html", "content": "<p>full body</p>"},
            "bodyPreview": "full body",
        }

        out = await read_mail_fn(
            message_id="m-1",
            config={"configurable": {"session_id": "s"}},
        )

        assert out["subject"] == "Hello"
        assert out["body_content"] == "<p>full body</p>"
        assert out["body_content_type"] == "html"
        assert out["cc_emails"] == ["cc@y.com"]

    async def test_empty_id_rejected(self, stubbed_runtime):
        out = await read_mail_fn(
            message_id="",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "EMPTY_ID"

    async def test_404_mapped_to_not_found(self, stubbed_runtime):
        stubbed_runtime["client"].get.side_effect = GraphNotFoundError("404")
        out = await read_mail_fn(
            message_id="missing",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "M365_NOT_FOUND"


# ---------------------------------------------------------------------------
# list_inbox
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestListInbox:
    async def test_orders_by_received_desc(self, stubbed_runtime):
        stubbed_runtime["client"].get.return_value = {"value": []}
        await list_inbox_fn(
            limit=5,
            skip=2,
            config={"configurable": {"session_id": "s"}},
        )
        params = stubbed_runtime["client"].get.call_args.kwargs["params"]
        assert params["$top"] == 5
        assert params["$skip"] == 2
        assert params["$orderby"] == "receivedDateTime desc"

    async def test_negative_skip_clamped_to_zero(self, stubbed_runtime):
        stubbed_runtime["client"].get.return_value = {"value": []}
        out = await list_inbox_fn(
            limit=5,
            skip=-10,
            config={"configurable": {"session_id": "s"}},
        )
        assert out["skip"] == 0


# ---------------------------------------------------------------------------
# create_draft
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestCreateDraft:
    async def test_happy_path_builds_correct_payload(self, stubbed_runtime):
        stubbed_runtime["client"].request.return_value = {
            "id": "d-42",
            "subject": "Hi",
            "from": {"emailAddress": {"address": "me@piilot.ai"}},
            "toRecipients": [{"emailAddress": {"address": "alice@x.com"}}],
            "receivedDateTime": "2026-04-30T10:00:00Z",
            "bodyPreview": "Body preview",
        }

        out = await create_draft_fn(
            to=["alice@x.com"],
            subject="Hi",
            body="Body content",
            cc=["bob@x.com"],
            config={"configurable": {"session_id": "s"}},
        )

        assert out["draft_id"] == "d-42"
        assert "preview" in out
        # Graph payload includes structured to/cc + Text body
        kwargs = stubbed_runtime["client"].request.call_args
        assert kwargs.args[0] == "POST"
        assert kwargs.args[1] == "me/messages"
        sent = kwargs.kwargs["json"]
        assert sent["subject"] == "Hi"
        assert sent["body"]["contentType"] == "Text"
        assert sent["toRecipients"][0]["emailAddress"]["address"] == "alice@x.com"
        assert sent["ccRecipients"][0]["emailAddress"]["address"] == "bob@x.com"

    async def test_missing_recipients_rejected(self, stubbed_runtime):
        out = await create_draft_fn(
            to=[],
            subject="Hi",
            body="Body",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "MISSING_RECIPIENT"
        stubbed_runtime["client"].request.assert_not_called()

    async def test_missing_subject_rejected(self, stubbed_runtime):
        out = await create_draft_fn(
            to=["a@b.com"],
            subject="   ",
            body="Body",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "MISSING_SUBJECT"

    async def test_missing_body_rejected(self, stubbed_runtime):
        out = await create_draft_fn(
            to=["a@b.com"],
            subject="Subject",
            body="",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "MISSING_BODY"

    async def test_invalid_email_rejected_before_graph(self, stubbed_runtime):
        out = await create_draft_fn(
            to=["not-an-email"],
            subject="x",
            body="y",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "INVALID_RECIPIENT"
        stubbed_runtime["client"].request.assert_not_called()


# ---------------------------------------------------------------------------
# send_draft
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestSendDraft:
    async def test_happy_path_calls_send_endpoint(self, stubbed_runtime):
        stubbed_runtime["client"].request.return_value = {}
        out = await send_draft_fn(
            draft_id="d-42",
            config={"configurable": {"session_id": "s"}},
        )
        assert out == {"sent": True, "draft_id": "d-42"}
        kwargs = stubbed_runtime["client"].request.call_args
        assert kwargs.args[0] == "POST"
        assert kwargs.args[1] == "me/messages/d-42/send"

    async def test_empty_draft_id_rejected(self, stubbed_runtime):
        out = await send_draft_fn(
            draft_id="",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "EMPTY_DRAFT_ID"
        stubbed_runtime["client"].request.assert_not_called()

    async def test_permission_error_mapped(self, stubbed_runtime):
        stubbed_runtime["client"].request.side_effect = GraphPermissionError(
            "403",
            response_body={"error": {"code": "ErrorAccessDenied"}},
        )
        out = await send_draft_fn(
            draft_id="d",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "M365_GRAPH_PERMISSION"
        assert out["graph_error_code"] == "ErrorAccessDenied"
