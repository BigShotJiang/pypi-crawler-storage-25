"""Tests for the OAuth helpers (Phase 2).

Pure-Python helpers — URL construction, state token, scope merging,
admin-consent detection. The httpx-based ``exchange_code`` /
``refresh_tokens`` are exercised against a mocked AsyncClient so we
never reach Microsoft's endpoints.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest

from piilot_pack_microsoft_365 import oauth


@pytest.fixture
def configured(monkeypatch):
    """Ensure MICROSOFT_CLIENT_ID + MICROSOFT_CLIENT_SECRET are set."""
    monkeypatch.setenv("MICROSOFT_CLIENT_ID", "test-client-id")
    monkeypatch.setenv("MICROSOFT_CLIENT_SECRET", "test-client-secret")
    monkeypatch.setenv("MICROSOFT_TENANT_ID", "common")


# ---------------------------------------------------------------------------
# Configuration guard
# ---------------------------------------------------------------------------


class TestConfigGuard:
    def test_unconfigured_raises_explicit_error(self, monkeypatch):
        monkeypatch.delenv("MICROSOFT_CLIENT_ID", raising=False)
        monkeypatch.delenv("MICROSOFT_CLIENT_SECRET", raising=False)
        with pytest.raises(oauth.OAuthConfigError) as exc:
            oauth._ensure_configured()
        assert exc.value.code == "missing_client_id"

    def test_missing_secret_only(self, monkeypatch):
        monkeypatch.setenv("MICROSOFT_CLIENT_ID", "x")
        monkeypatch.delenv("MICROSOFT_CLIENT_SECRET", raising=False)
        with pytest.raises(oauth.OAuthConfigError) as exc:
            oauth._ensure_configured()
        assert exc.value.code == "missing_client_secret"


# ---------------------------------------------------------------------------
# State token
# ---------------------------------------------------------------------------


class TestStateToken:
    def test_round_trip(self):
        state = oauth.generate_state("c-1")
        company_id, nonce = oauth.parse_state(state)
        assert company_id == "c-1"
        assert nonce  # not empty

    def test_state_is_unique_per_call(self):
        a = oauth.generate_state("c-1")
        b = oauth.generate_state("c-1")
        assert a != b  # nonce randomised

    def test_invalid_state_raises(self):
        with pytest.raises(oauth.OAuthError):
            oauth.parse_state("")
        with pytest.raises(oauth.OAuthError):
            oauth.parse_state("no-colon")
        with pytest.raises(oauth.OAuthError):
            oauth.parse_state(":no-company")
        with pytest.raises(oauth.OAuthError):
            oauth.parse_state("c-1:")


# ---------------------------------------------------------------------------
# Authorize URL
# ---------------------------------------------------------------------------


class TestAuthorizeUrl:
    def test_includes_required_params(self, configured):
        url = oauth.build_authorize_url(
            scopes=["Mail.Read"],
            redirect_uri="https://app.piilot.ai/cb",
            state="c-1:abc",
        )
        assert "client_id=test-client-id" in url
        assert "response_type=code" in url
        assert "redirect_uri=https" in url
        assert "state=c-1" in url
        assert "prompt=select_account" in url

    def test_scopes_always_include_offline_access_and_openid(self, configured):
        url = oauth.build_authorize_url(
            scopes=["Mail.Read"],
            redirect_uri="https://app.piilot.ai/cb",
            state="c-1:abc",
        )
        # URL-encoded space is + or %20
        assert "openid" in url
        assert "email" in url
        assert "offline_access" in url
        assert "Mail.Read" in url

    def test_duplicate_scopes_collapsed(self, configured):
        url = oauth.build_authorize_url(
            scopes=["Mail.Read", "Mail.Read", "openid"],
            redirect_uri="https://x",
            state="c-1:abc",
        )
        # 'openid' should appear only once even though we passed it
        # explicitly + via the base set.
        assert url.count("openid") == 1

    def test_unconfigured_refuses(self, monkeypatch):
        monkeypatch.delenv("MICROSOFT_CLIENT_ID", raising=False)
        with pytest.raises(oauth.OAuthConfigError):
            oauth.build_authorize_url(
                scopes=["Mail.Read"],
                redirect_uri="https://x",
                state="s",
            )


class TestAdminConsentUrl:
    def test_builds_tenant_consent_url(self, configured):
        url = oauth.build_admin_consent_url(
            redirect_uri="https://app.piilot.ai/cb",
            state="c-1:abc",
        )
        assert "/common/adminconsent" in url
        assert "client_id=test-client-id" in url
        assert "redirect_uri=https" in url


# ---------------------------------------------------------------------------
# Token exchange
# ---------------------------------------------------------------------------


def _mock_token_response(body: dict, status: int = 200) -> MagicMock:
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status
    resp.json.return_value = body
    resp.text = ""
    return resp


@pytest.mark.asyncio
class TestExchangeCode:
    async def test_happy_path_returns_decoded_tokens(self, configured):
        mock_client = AsyncMock()
        mock_client.post.return_value = _mock_token_response(
            {
                "access_token": "ACCESS",
                "refresh_token": "REFRESH",
                "expires_in": 3600,
                "scope": "Mail.Read offline_access openid",
                "token_type": "Bearer",
            }
        )

        result = await oauth.exchange_code(
            code="auth-code-1",
            redirect_uri="https://x/cb",
            client=mock_client,
        )

        assert result["access_token"] == "ACCESS"
        assert result["refresh_token"] == "REFRESH"
        assert result["scopes_granted"] == ["Mail.Read", "offline_access", "openid"]
        # Body shape: form-urlencoded
        kwargs = mock_client.post.call_args.kwargs
        assert kwargs["data"]["grant_type"] == "authorization_code"
        assert kwargs["data"]["code"] == "auth-code-1"

    async def test_microsoft_refusal_raises(self, configured):
        mock_client = AsyncMock()
        mock_client.post.return_value = _mock_token_response(
            {
                "error": "invalid_grant",
                "error_description": "AADSTS54005: code already redeemed",
            },
            status=400,
        )

        with pytest.raises(oauth.OAuthExchangeError) as exc:
            await oauth.exchange_code(
                code="reused",
                redirect_uri="https://x",
                client=mock_client,
            )
        assert exc.value.code == "invalid_grant"
        assert exc.value.status == 400

    async def test_missing_code_raises_before_network(self, configured):
        mock_client = AsyncMock()
        with pytest.raises(oauth.OAuthExchangeError) as exc:
            await oauth.exchange_code(
                code="",
                redirect_uri="https://x",
                client=mock_client,
            )
        assert exc.value.code == "missing_code"
        mock_client.post.assert_not_called()


@pytest.mark.asyncio
class TestRefreshTokens:
    async def test_happy_path_returns_new_access_and_refresh(self, configured):
        mock_client = AsyncMock()
        mock_client.post.return_value = _mock_token_response(
            {
                "access_token": "NEW-ACCESS",
                "refresh_token": "NEW-REFRESH",  # MS rotated it
                "expires_in": 3600,
                "scope": "Mail.Read",
                "token_type": "Bearer",
            }
        )

        result = await oauth.refresh_tokens(
            refresh_token="OLD",
            client=mock_client,
        )

        assert result["access_token"] == "NEW-ACCESS"
        assert result["refresh_token"] == "NEW-REFRESH"

    async def test_refresh_response_without_new_refresh(self, configured):
        # Microsoft sometimes only returns a new access token, keeping
        # the same refresh token. Our refresh layer should signal this
        # by returning ``refresh_token=None`` so the storage layer
        # preserves the existing value.
        mock_client = AsyncMock()
        mock_client.post.return_value = _mock_token_response(
            {
                "access_token": "NEW-ACCESS",
                "expires_in": 3600,
                "scope": "Mail.Read",
                "token_type": "Bearer",
            }
        )

        result = await oauth.refresh_tokens(
            refresh_token="OLD",
            client=mock_client,
        )
        assert result["refresh_token"] is None

    async def test_revoked_refresh_raises(self, configured):
        mock_client = AsyncMock()
        mock_client.post.return_value = _mock_token_response(
            {"error": "invalid_grant", "error_description": "Refresh token revoked"},
            status=400,
        )
        with pytest.raises(oauth.OAuthRefreshError) as exc:
            await oauth.refresh_tokens(
                refresh_token="revoked",
                client=mock_client,
            )
        assert exc.value.code == "invalid_grant"


# ---------------------------------------------------------------------------
# Admin consent satisfaction
# ---------------------------------------------------------------------------


class TestAdminConsentSatisfies:
    def test_no_all_scopes_trivially_satisfied(self):
        assert (
            oauth.admin_consent_satisfies(
                requested_scopes=["Mail.Read", "Files.Read"],
                granted_scopes=["Mail.Read"],
            )
            is True
        )

    def test_all_scope_must_be_granted(self):
        assert (
            oauth.admin_consent_satisfies(
                requested_scopes=["Sites.Read.All"],
                granted_scopes=["Sites.Read.All", "Mail.Read"],
            )
            is True
        )

    def test_all_scope_missing_not_satisfied(self):
        assert (
            oauth.admin_consent_satisfies(
                requested_scopes=["Sites.Read.All"],
                granted_scopes=["Mail.Read"],
            )
            is False
        )

    def test_partial_all_grant_not_satisfied(self):
        assert (
            oauth.admin_consent_satisfies(
                requested_scopes=["Sites.Read.All", "ChannelMessage.Read.All"],
                granted_scopes=["Sites.Read.All"],  # missing Channel
            )
            is False
        )
