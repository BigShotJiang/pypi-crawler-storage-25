"""Tests for ``_db.py`` — DB helpers for connections + scope_grants.

We mock the ``cursor()`` context manager so the tests never reach
Postgres. The mocked cursor records calls (sql, params) so we can
assert the shape of the queries without depending on a real DB.

Tokens go through the test ``encrypt`` / ``decrypt`` stubs from
``conftest.py`` (reversible base64 prefixed by ``test-enc:``) — that
lets us round-trip the connection record and assert that what comes
back out of ``get_connection`` is **decrypted**, never the raw cipher.
"""

from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock, patch


from piilot_pack_microsoft_365 import _db

# ---------------------------------------------------------------------------
# Cursor-mocking helpers
# ---------------------------------------------------------------------------


@contextmanager
def _mock_cursor(returning: list | None = None, fetchone: dict | None = None):
    """Patch ``_db.cursor`` to yield a MagicMock cursor.

    ``returning`` — values to be served by ``fetchall()`` (in order
    if multiple calls).
    ``fetchone`` — value (or callable) served by ``fetchone()``.
    """
    cur = MagicMock()
    cur.fetchall.return_value = returning or []
    cur.fetchone.return_value = fetchone

    @contextmanager
    def _fake_cursor():
        yield cur

    with patch.object(_db, "cursor", _fake_cursor):
        yield cur


# ---------------------------------------------------------------------------
# Connection helpers
# ---------------------------------------------------------------------------


class TestGetConnection:
    def test_returns_decrypted_record(self):
        # The ``access_token_encrypted`` and ``refresh_token_encrypted``
        # come out of the DB encrypted — the helper must decrypt them.
        encrypted_access = "test-enc:" + _b64("ACCESS-FOO")
        encrypted_refresh = "test-enc:" + _b64("REFRESH-BAR")

        row = {
            "id": "conn-1",
            "company_id": "c-1",
            "user_principal_name": "user@tenant.com",
            "display_name": "User One",
            "tenant_id": "tenant-uuid",
            "access_token_encrypted": encrypted_access,
            "refresh_token_encrypted": encrypted_refresh,
            "expires_at": datetime.now(timezone.utc) + timedelta(hours=1),
            "scopes_granted": ["Mail.Read"],
            "admin_consent_granted": False,
            "connected_by": "u-1",
            "connected_at": None,
            "last_refreshed_at": None,
            "last_used_at": None,
            "created_at": None,
            "updated_at": None,
        }

        with _mock_cursor(fetchone=row):
            out = _db.get_connection("c-1")

        assert out is not None
        assert out["access_token"] == "ACCESS-FOO"
        assert out["refresh_token"] == "REFRESH-BAR"
        # Encrypted columns must not leak into the application dict.
        assert "access_token_encrypted" not in out
        assert "refresh_token_encrypted" not in out

    def test_returns_none_when_no_row(self):
        with _mock_cursor(fetchone=None):
            assert _db.get_connection("c-missing") is None

    def test_handles_null_refresh(self):
        row = {
            "id": "conn-1",
            "company_id": "c-1",
            "user_principal_name": "u@x.com",
            "display_name": None,
            "tenant_id": None,
            "access_token_encrypted": "test-enc:" + _b64("A"),
            "refresh_token_encrypted": None,
            "expires_at": datetime.now(timezone.utc),
            "scopes_granted": [],
            "admin_consent_granted": False,
            "connected_by": None,
            "connected_at": None,
            "last_refreshed_at": None,
            "last_used_at": None,
            "created_at": None,
            "updated_at": None,
        }
        with _mock_cursor(fetchone=row):
            out = _db.get_connection("c-1")
        assert out is not None
        assert out["access_token"] == "A"
        assert out["refresh_token"] is None


class TestUpsertConnection:
    def test_encrypts_tokens_before_insert(self):
        captured_params = {}

        def _capture_execute(sql, params):
            captured_params["sql"] = sql
            captured_params["params"] = params

        with _mock_cursor(fetchone={"id": "conn-1"}) as cur:
            cur.execute.side_effect = _capture_execute
            _db.upsert_connection(
                company_id="c-1",
                user_principal_name="u@x.com",
                display_name="User",
                tenant_id="t-1",
                access_token="raw-access",
                refresh_token="raw-refresh",
                expires_at=datetime.now(timezone.utc),
                scopes_granted=["Mail.Read"],
                admin_consent_granted=False,
                connected_by="u-1",
            )

        params = captured_params["params"]
        # Position 4 + 5 are the encrypted tokens — they must NEVER
        # equal the raw values.
        assert "raw-access" not in params
        assert "raw-refresh" not in params
        # And they must round-trip back through decrypt.
        from piilot.sdk.crypto import decrypt

        assert decrypt(params[4]) == "raw-access"
        assert decrypt(params[5]) == "raw-refresh"

    def test_returns_id_from_returning_clause(self):
        with _mock_cursor(fetchone={"id": "conn-99"}):
            new_id = _db.upsert_connection(
                company_id="c-1",
                user_principal_name="u@x.com",
                display_name=None,
                tenant_id=None,
                access_token="A",
                refresh_token=None,
                expires_at=datetime.now(timezone.utc),
                scopes_granted=[],
                admin_consent_granted=False,
                connected_by=None,
            )
        assert new_id == "conn-99"


class TestUpdateTokensAfterRefresh:
    def test_encrypts_new_tokens(self):
        captured = {}

        def _capture(sql, params):
            captured["sql"] = sql
            captured["params"] = params

        with _mock_cursor() as cur:
            cur.execute.side_effect = _capture
            _db.update_tokens_after_refresh(
                company_id="c-1",
                access_token="new-access",
                refresh_token="new-refresh",
                expires_at=datetime.now(timezone.utc),
            )

        from piilot.sdk.crypto import decrypt

        # First param is the encrypted access token.
        assert decrypt(captured["params"][0]) == "new-access"
        # Second is the encrypted refresh — COALESCE keeps the old
        # one if this is None, but here we passed a new value.
        assert decrypt(captured["params"][1]) == "new-refresh"

    def test_passes_none_when_no_new_refresh(self):
        captured = {}

        def _capture(sql, params):
            captured["params"] = params

        with _mock_cursor() as cur:
            cur.execute.side_effect = _capture
            _db.update_tokens_after_refresh(
                company_id="c-1",
                access_token="new-access",
                refresh_token=None,
                expires_at=datetime.now(timezone.utc),
            )
        # COALESCE fallback handled in SQL — params[1] is None.
        assert captured["params"][1] is None


class TestTouchLastUsed:
    def test_swallows_db_errors(self):
        # touch_last_used is a best-effort hot-path helper — must not
        # propagate exceptions to the caller.
        @contextmanager
        def _broken_cursor():
            raise RuntimeError("db down")
            yield  # pragma: no cover

        with patch.object(_db, "cursor", _broken_cursor):
            # Must NOT raise.
            _db.touch_last_used("c-1")


class TestIsTokenNearExpiry:
    def test_true_when_expires_within_threshold(self):
        conn = {"expires_at": datetime.now(timezone.utc) + timedelta(seconds=30)}
        assert _db.is_token_near_expiry(conn, threshold_seconds=120) is True

    def test_false_when_far_from_expiry(self):
        conn = {"expires_at": datetime.now(timezone.utc) + timedelta(hours=1)}
        assert _db.is_token_near_expiry(conn, threshold_seconds=120) is False

    def test_true_when_already_expired(self):
        conn = {"expires_at": datetime.now(timezone.utc) - timedelta(minutes=1)}
        assert _db.is_token_near_expiry(conn) is True

    def test_handles_naive_datetime_as_utc(self):
        # A timezone-naive expires_at is interpreted as UTC.
        naive = (datetime.now(timezone.utc) + timedelta(hours=1)).replace(tzinfo=None)
        conn = {"expires_at": naive}
        assert _db.is_token_near_expiry(conn) is False

    def test_missing_expires_at_returns_true_defensively(self):
        # No expires_at → treat as needing refresh (fail-closed-ish).
        assert _db.is_token_near_expiry({}) is True


# ---------------------------------------------------------------------------
# Scope grants
# ---------------------------------------------------------------------------


class TestListScopeGrants:
    def test_returns_rows_as_is(self):
        rows = [
            {"permission_id": "outlook.read", "enabled": True},
            {"permission_id": "outlook.write", "enabled": False},
        ]
        with _mock_cursor(returning=rows):
            out = _db.list_scope_grants("c-1")
        assert out == rows

    def test_empty_when_no_grants(self):
        with _mock_cursor(returning=[]):
            assert _db.list_scope_grants("c-1") == []


class TestIsScopeEnabled:
    def test_true_when_row_present_and_enabled(self):
        with _mock_cursor(fetchone={"?column?": 1}):
            assert _db.is_scope_enabled("c-1", "outlook.read") is True

    def test_false_when_no_matching_row(self):
        # The query filters on enabled=true, so a missing toggle and
        # an explicitly-disabled toggle both produce ``fetchone=None``.
        with _mock_cursor(fetchone=None):
            assert _db.is_scope_enabled("c-1", "outlook.write") is False


class TestUpsertScopeGrant:
    def test_passes_enabled_flag_through(self):
        captured = {}

        def _capture(sql, params):
            captured["params"] = params

        with _mock_cursor() as cur:
            cur.execute.side_effect = _capture
            _db.upsert_scope_grant(
                company_id="c-1",
                permission_id="outlook.read",
                enabled=True,
                granted_by="u-1",
            )
        # The query has 5 params: company_id, permission_id, enabled,
        # granted_by, and a duplicate enabled used in the CASE clause.
        assert captured["params"][2] is True  # enabled
        assert captured["params"][4] is True  # CASE-WHEN flag

    def test_disable_path_passes_false(self):
        captured = {}

        def _capture(sql, params):
            captured["params"] = params

        with _mock_cursor() as cur:
            cur.execute.side_effect = _capture
            _db.upsert_scope_grant(
                company_id="c-1",
                permission_id="outlook.write",
                enabled=False,
                granted_by="u-1",
            )
        assert captured["params"][2] is False
        assert captured["params"][4] is False


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _b64(value: str) -> str:
    """Match the conftest fake encrypt: base64-urlsafe."""
    import base64

    return base64.urlsafe_b64encode(value.encode("utf-8")).decode()
