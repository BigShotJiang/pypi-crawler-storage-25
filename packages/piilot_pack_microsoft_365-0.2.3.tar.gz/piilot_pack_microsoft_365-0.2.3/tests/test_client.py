"""Tests for the Microsoft Graph API client.

Mocks ``httpx.AsyncClient.request`` so we never hit the real Graph.
Covers the contract the upper layers rely on:

  - 200 → parsed JSON returned
  - 401 → ``GraphAuthError`` (caller refresh & retry)
  - 403 → ``GraphPermissionError`` (carries response body for code lookup)
  - 404 → ``GraphNotFoundError``
  - 429 → ``GraphRateLimitedError`` with ``Retry-After`` honored
  - 5xx → retried once then surfaced as ``GraphError``
  - Empty access_token → ``GraphAuthError`` upfront (no network call)
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from piilot_pack_microsoft_365.client import (
    GraphAPIClient,
    GraphAuthError,
    GraphError,
    GraphNotFoundError,
    GraphPermissionError,
    GraphRateLimitedError,
)


def _mock_response(
    status: int, body: dict | None = None, headers: dict | None = None
) -> MagicMock:
    """Build a fake httpx.Response."""
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status
    resp.headers = headers or {}
    resp.content = b"" if body is None else b"x"  # truthy when there's a body
    resp.json.return_value = body or {}
    resp.text = ""
    return resp


@pytest.fixture
def client():
    """Fresh client per test — avoids cross-test connection-pool reuse."""
    c = GraphAPIClient()
    yield c


@pytest.mark.asyncio
class TestHappyPath:
    async def test_get_returns_parsed_json(self, client):
        with patch.object(
            client._http,
            "request",
            new=AsyncMock(
                return_value=_mock_response(
                    200,
                    body={"id": "u-1", "displayName": "Alice"},
                )
            ),
        ):
            body = await client.get("me", access_token="tok")
        assert body == {"id": "u-1", "displayName": "Alice"}

    async def test_204_returns_empty_dict(self, client):
        resp = _mock_response(204)
        resp.content = b""
        with patch.object(client._http, "request", new=AsyncMock(return_value=resp)):
            body = await client.get("messages/abc", access_token="tok")
        assert body == {}

    async def test_path_normalisation(self, client):
        captured: dict = {}

        async def _fake(method, url, **kwargs):  # noqa: ANN001
            captured["url"] = url
            return _mock_response(200, body={})

        with patch.object(client._http, "request", new=_fake):
            await client.get("/me", access_token="tok")
        assert captured["url"].endswith("/v1.0/me")


@pytest.mark.asyncio
class TestAuthAndPermissions:
    async def test_empty_token_raises_auth_error_no_network_call(self, client):
        with patch.object(client._http, "request") as mock_req:
            with pytest.raises(GraphAuthError, match="missing access_token"):
                await client.get("me", access_token="")
        mock_req.assert_not_called()

    async def test_401_raises_auth_error(self, client):
        with patch.object(
            client._http,
            "request",
            new=AsyncMock(
                return_value=_mock_response(
                    401,
                    body={"error": {"code": "InvalidAuthenticationToken"}},
                )
            ),
        ):
            with pytest.raises(GraphAuthError) as exc:
                await client.get("me", access_token="bad")
        assert exc.value.status_code == 401
        assert exc.value.response_body["error"]["code"] == "InvalidAuthenticationToken"

    async def test_403_raises_permission_error(self, client):
        with patch.object(
            client._http,
            "request",
            new=AsyncMock(
                return_value=_mock_response(
                    403,
                    body={"error": {"code": "Authorization_RequestDenied"}},
                )
            ),
        ):
            with pytest.raises(GraphPermissionError) as exc:
                await client.get("sites", access_token="tok")
        assert exc.value.response_body["error"]["code"] == "Authorization_RequestDenied"

    async def test_404_raises_not_found(self, client):
        with patch.object(
            client._http,
            "request",
            new=AsyncMock(return_value=_mock_response(404)),
        ):
            with pytest.raises(GraphNotFoundError):
                await client.get("messages/missing", access_token="tok")


@pytest.mark.asyncio
class TestRateLimitingAndRetries:
    async def test_429_with_retry_after_retries_then_succeeds(self, client):
        responses = [
            _mock_response(429, headers={"Retry-After": "0"}),
            _mock_response(200, body={"id": "ok"}),
        ]

        async def _stub(*_args, **_kwargs):
            return responses.pop(0)

        with patch.object(client._http, "request", new=_stub):
            body = await client.get("me", access_token="tok")
        assert body == {"id": "ok"}

    async def test_429_without_retry_after_raises_immediately(self, client):
        with patch.object(
            client._http,
            "request",
            new=AsyncMock(return_value=_mock_response(429)),
        ):
            with pytest.raises(GraphRateLimitedError) as exc:
                await client.get("me", access_token="tok")
        assert exc.value.retry_after is None

    async def test_5xx_retried_then_surfaced(self, client):
        responses = [
            _mock_response(503),
            _mock_response(503),
        ]

        async def _stub(*_args, **_kwargs):
            return responses.pop(0)

        with patch.object(client._http, "request", new=_stub):
            with pytest.raises(GraphError) as exc:
                # Disable retries to keep the test fast — the default
                # 1-retry path is covered by the 429 test above.
                await client.request("GET", "me", access_token="tok", max_retries=1)
        assert exc.value.status_code == 503
