"""Tests for tools/_auth.py (Phase 2 wiring).

After Phase 2, ``resolve_access_token`` and ``ensure_permission`` are
real DB lookups. We mock ``_db.*`` and ``oauth.refresh_tokens`` to
exercise:

  - happy paths (token in DB, fresh, returned as-is)
  - proactive refresh (token near expiry → call refresh, persist, return)
  - refresh failure (revoked refresh token) → returns None
  - missing connection → returns None
  - DB error swallowed → returns None / False (fail-closed)
  - permission gate respects the per-scope toggle table

The two error envelopes (``not_connected_error``, ``permission_denied_error``)
remain pinned — the LLM branches on those exact codes.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from unittest.mock import AsyncMock, patch

import pytest

from piilot_pack_microsoft_365 import oauth as oauth_module
from piilot_pack_microsoft_365.tools._auth import (
    ensure_permission,
    not_connected_error,
    permission_denied_error,
    resolve_access_token,
)

_MODULE = "piilot_pack_microsoft_365.tools._auth"


def _connection(
    *, expires_in_seconds: int = 3600, refresh_token: str | None = "rt-1"
) -> dict:
    return {
        "id": "conn-1",
        "company_id": "c-1",
        "access_token": "valid-access-token",
        "refresh_token": refresh_token,
        "expires_at": datetime.now(timezone.utc)
        + timedelta(seconds=expires_in_seconds),
    }


# ---------------------------------------------------------------------------
# resolve_access_token
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestResolveAccessToken:
    async def test_returns_token_when_fresh(self):
        with (
            patch(f"{_MODULE}._db.get_connection", return_value=_connection()),
            patch(f"{_MODULE}._db.touch_last_used", return_value=None),
        ):
            out = await resolve_access_token("c-1")
        assert out == "valid-access-token"

    async def test_returns_none_when_no_connection(self):
        with patch(f"{_MODULE}._db.get_connection", return_value=None):
            out = await resolve_access_token("c-1")
        assert out is None

    async def test_db_failure_returns_none_fail_closed(self):
        with patch(
            f"{_MODULE}._db.get_connection", side_effect=RuntimeError("db down")
        ):
            out = await resolve_access_token("c-1")
        assert out is None

    async def test_refreshes_when_near_expiry(self):
        # Token expiring in 30 s — under the 120 s threshold → refresh.
        near_expiry = _connection(expires_in_seconds=30)
        new_tokens = {
            "access_token": "new-access-token",
            "refresh_token": "new-refresh-token",
            "expires_at": datetime.now(timezone.utc) + timedelta(hours=1),
            "scopes_granted": ["Mail.Read"],
        }
        with (
            patch(f"{_MODULE}._db.get_connection", return_value=near_expiry),
            patch(
                f"{_MODULE}._db.update_tokens_after_refresh", return_value=None
            ) as mock_save,
            patch(
                f"{_MODULE}.oauth.refresh_tokens",
                new=AsyncMock(return_value=new_tokens),
            ),
        ):
            out = await resolve_access_token("c-1")
        assert out == "new-access-token"
        # Persisted with the new tokens
        kwargs = mock_save.call_args.kwargs
        assert kwargs["access_token"] == "new-access-token"
        assert kwargs["refresh_token"] == "new-refresh-token"

    async def test_refresh_failure_returns_none(self):
        near_expiry = _connection(expires_in_seconds=10)
        with (
            patch(f"{_MODULE}._db.get_connection", return_value=near_expiry),
            patch(
                f"{_MODULE}.oauth.refresh_tokens",
                new=AsyncMock(side_effect=oauth_module.OAuthRefreshError("revoked")),
            ),
        ):
            out = await resolve_access_token("c-1")
        # Caller treats None as "ask user to re-connect"
        assert out is None

    async def test_no_refresh_token_returns_none_when_near_expiry(self):
        # An access-token-only connection (rare but possible) can't be
        # refreshed → return None to force re-connect.
        near_expiry_no_refresh = _connection(
            expires_in_seconds=10,
            refresh_token=None,
        )
        with patch(
            f"{_MODULE}._db.get_connection", return_value=near_expiry_no_refresh
        ):
            out = await resolve_access_token("c-1")
        assert out is None

    async def test_persist_failure_still_returns_new_token(self):
        # The Microsoft refresh succeeded but our DB write failed —
        # we still got a fresh access token from MS, return it so
        # the immediate call works. A subsequent call will retry.
        near_expiry = _connection(expires_in_seconds=10)
        new_tokens = {
            "access_token": "fresh",
            "refresh_token": "rt-2",
            "expires_at": datetime.now(timezone.utc) + timedelta(hours=1),
            "scopes_granted": [],
        }
        with (
            patch(f"{_MODULE}._db.get_connection", return_value=near_expiry),
            patch(
                f"{_MODULE}._db.update_tokens_after_refresh",
                side_effect=RuntimeError("db down"),
            ),
            patch(
                f"{_MODULE}.oauth.refresh_tokens",
                new=AsyncMock(return_value=new_tokens),
            ),
        ):
            out = await resolve_access_token("c-1")
        assert out == "fresh"


# ---------------------------------------------------------------------------
# ensure_permission
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestEnsurePermission:
    async def test_returns_true_when_toggle_enabled(self):
        with patch(f"{_MODULE}._db.is_scope_enabled", return_value=True):
            assert await ensure_permission("c-1", "outlook.read") is True

    async def test_returns_false_when_toggle_disabled(self):
        with patch(f"{_MODULE}._db.is_scope_enabled", return_value=False):
            assert await ensure_permission("c-1", "outlook.write") is False

    async def test_db_failure_fail_closed(self):
        with patch(
            f"{_MODULE}._db.is_scope_enabled", side_effect=RuntimeError("db down")
        ):
            assert await ensure_permission("c-1", "outlook.read") is False


# ---------------------------------------------------------------------------
# Error envelopes — pinned so the LLM contract stays stable
# ---------------------------------------------------------------------------


class TestErrorEnvelopes:
    def test_not_connected_carries_stable_code(self):
        out = not_connected_error()
        assert out["error_code"] == "M365_NOT_CONNECTED"
        assert "Microsoft 365" in out["error"]

    def test_permission_denied_includes_permission_id(self):
        out = permission_denied_error("sharepoint.read")
        assert out["error_code"] == "M365_PERMISSION_DISABLED"
        assert out["permission"] == "sharepoint.read"
