"""Tests for the OneDrive tools — Phase 5.

Same coverage matrix as Outlook: permission gate, not-connected,
session-resolution, validation, happy paths, plus the **2-step intent
pattern** for uploads :

  - ``prepare_upload`` validates content, stores intent in session,
    returns ``upload_intent_id`` + preview.
  - ``confirm_upload`` looks up the intent, performs Graph PUT, drops
    the intent.
  - Without a valid intent_id, no upload is possible (architectural
    safety, not just LLM-prompt convention).
"""

from __future__ import annotations

import time
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from piilot_pack_microsoft_365.client import (
    GraphNotFoundError,
)
from piilot_pack_microsoft_365.tools import onedrive as od

_MODULE = "piilot_pack_microsoft_365.tools.onedrive"


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _state_with_company(company_id: str = "c-1"):
    state = MagicMock()
    # Real dict so the intent storage helpers can mutate it.
    state.user_infos = {"_organization_id": company_id}
    return state


@pytest.fixture
def stubbed_runtime():
    state = _state_with_company()
    fake_client = MagicMock()
    fake_client.get = AsyncMock()
    fake_client.request = AsyncMock()
    # ``confirm_upload`` uses ``client._http.put`` directly. Build a
    # MagicMock with a ``_base_url`` attribute that mimics the real shape.
    fake_client._base_url = "https://graph.microsoft.com/v1.0"
    fake_client._http = MagicMock()
    fake_client._http.put = AsyncMock()

    with (
        patch(f"{_MODULE}._get_session_state", return_value=state),
        patch(f"{_MODULE}.ensure_permission", AsyncMock(return_value=True)),
        patch(f"{_MODULE}.resolve_access_token", AsyncMock(return_value="tok")),
        patch(f"{_MODULE}._get_client", return_value=fake_client),
    ):
        yield {"state": state, "client": fake_client}


# ---------------------------------------------------------------------------
# Permission + auth gates
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestPermissionGate:
    @pytest.mark.parametrize(
        "tool_call,expected_perm",
        [
            (
                lambda sid: od.search_files_fn(
                    query="x", config={"configurable": {"session_id": sid}}
                ),
                "onedrive.read",
            ),
            (
                lambda sid: od.download_file_fn(
                    file_id="f-1", config={"configurable": {"session_id": sid}}
                ),
                "onedrive.read",
            ),
            (
                lambda sid: od.list_folder_fn(
                    config={"configurable": {"session_id": sid}}
                ),
                "onedrive.read",
            ),
            (
                lambda sid: od.prepare_upload_fn(
                    file_name="x.md",
                    content="y",
                    config={"configurable": {"session_id": sid}},
                ),
                "onedrive.write",
            ),
            (
                lambda sid: od.confirm_upload_fn(
                    upload_intent_id="i", config={"configurable": {"session_id": sid}}
                ),
                "onedrive.write",
            ),
        ],
    )
    async def test_each_tool_blocked_when_permission_off(
        self, tool_call, expected_perm
    ):
        state = _state_with_company()
        with (
            patch(f"{_MODULE}._get_session_state", return_value=state),
            patch(f"{_MODULE}.ensure_permission", AsyncMock(return_value=False)),
        ):
            out = await tool_call("s")
        assert out["error_code"] == "M365_PERMISSION_DISABLED"
        assert out["permission"] == expected_perm


@pytest.mark.asyncio
class TestNotConnected:
    async def test_search_files_not_connected(self):
        state = _state_with_company()
        with (
            patch(f"{_MODULE}._get_session_state", return_value=state),
            patch(f"{_MODULE}.ensure_permission", AsyncMock(return_value=True)),
            patch(f"{_MODULE}.resolve_access_token", AsyncMock(return_value=None)),
        ):
            out = await od.search_files_fn(
                query="x", config={"configurable": {"session_id": "s"}}
            )
        assert out["error_code"] == "M365_NOT_CONNECTED"


# ---------------------------------------------------------------------------
# search_files
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestSearchFiles:
    async def test_happy_path_summarises(self, stubbed_runtime):
        stubbed_runtime["client"].get.return_value = {
            "value": [
                {
                    "id": "f-1",
                    "name": "Rapport.md",
                    "size": 1024,
                    "file": {"mimeType": "text/markdown"},
                    "lastModifiedDateTime": "2026-04-30T10:00:00Z",
                    "parentReference": {"path": "/drive/root:"},
                    "webUrl": "https://onedrive/abc",
                },
                {
                    "id": "f-2",
                    "name": "Dossier1",
                    "folder": {"childCount": 5},
                    "lastModifiedDateTime": "2026-04-29T10:00:00Z",
                    "parentReference": {"path": "/drive/root:"},
                },
            ],
        }
        out = await od.search_files_fn(
            query="rapport",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["count"] == 2
        assert out["items"][0]["kind"] == "file"
        assert out["items"][0]["mime_type"] == "text/markdown"
        assert out["items"][1]["kind"] == "folder"
        # Verify the search syntax used
        path = stubbed_runtime["client"].get.call_args.args[0]
        assert "search(q='rapport')" in path

    async def test_empty_query_rejected(self, stubbed_runtime):
        out = await od.search_files_fn(
            query="   ",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "EMPTY_QUERY"
        stubbed_runtime["client"].get.assert_not_called()

    async def test_limit_capped_at_max(self, stubbed_runtime):
        stubbed_runtime["client"].get.return_value = {"value": []}
        await od.search_files_fn(
            query="x",
            limit=999,
            config={"configurable": {"session_id": "s"}},
        )
        params = stubbed_runtime["client"].get.call_args.kwargs["params"]
        assert params["$top"] == 25


# ---------------------------------------------------------------------------
# download_file
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestDownloadFile:
    async def test_returns_metadata_plus_signed_url(self, stubbed_runtime):
        stubbed_runtime["client"].get.return_value = {
            "id": "f-1",
            "name": "Rapport.md",
            "size": 2048,
            "file": {"mimeType": "text/markdown"},
            "lastModifiedDateTime": "2026-04-30T10:00:00Z",
            "parentReference": {"path": "/drive/root:"},
            "webUrl": "https://onedrive/abc",
            "@microsoft.graph.downloadUrl": "https://signed-url.example/abc",
        }
        out = await od.download_file_fn(
            file_id="f-1",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["file"]["name"] == "Rapport.md"
        assert out["download_url"] == "https://signed-url.example/abc"

    async def test_empty_id_rejected(self, stubbed_runtime):
        out = await od.download_file_fn(
            file_id="",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "EMPTY_FILE_ID"

    async def test_folder_returns_is_folder_error(self, stubbed_runtime):
        stubbed_runtime["client"].get.return_value = {
            "id": "f-folder",
            "name": "Mon dossier",
            "folder": {"childCount": 5},
            "lastModifiedDateTime": "2026-04-30T10:00:00Z",
            "parentReference": {"path": "/drive/root:"},
        }
        out = await od.download_file_fn(
            file_id="f-folder",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "IS_FOLDER"

    async def test_404_mapped_to_not_found(self, stubbed_runtime):
        stubbed_runtime["client"].get.side_effect = GraphNotFoundError("404")
        out = await od.download_file_fn(
            file_id="missing",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "M365_NOT_FOUND"


# ---------------------------------------------------------------------------
# list_folder
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestListFolder:
    async def test_root_when_no_folder_id(self, stubbed_runtime):
        stubbed_runtime["client"].get.return_value = {"value": []}
        await od.list_folder_fn(
            config={"configurable": {"session_id": "s"}},
        )
        path = stubbed_runtime["client"].get.call_args.args[0]
        assert path == "me/drive/root/children"

    async def test_specific_folder(self, stubbed_runtime):
        stubbed_runtime["client"].get.return_value = {"value": []}
        await od.list_folder_fn(
            folder_id="f-42",
            config={"configurable": {"session_id": "s"}},
        )
        path = stubbed_runtime["client"].get.call_args.args[0]
        assert path == "me/drive/items/f-42/children"

    async def test_pagination_params(self, stubbed_runtime):
        stubbed_runtime["client"].get.return_value = {"value": []}
        out = await od.list_folder_fn(
            limit=15,
            skip=5,
            config={"configurable": {"session_id": "s"}},
        )
        assert out["skip"] == 5
        params = stubbed_runtime["client"].get.call_args.kwargs["params"]
        assert params["$top"] == 15


# ---------------------------------------------------------------------------
# prepare_upload — validation + intent storage
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestPrepareUpload:
    async def test_happy_path_stores_intent_and_returns_id(self, stubbed_runtime):
        out = await od.prepare_upload_fn(
            file_name="rapport.md",
            content="Hello world",
            parent_folder_id="parent-1",
            config={"configurable": {"session_id": "s"}},
        )
        assert "upload_intent_id" in out
        assert out["preview"]["file_name"] == "rapport.md"
        assert out["preview"]["size_bytes"] == len("Hello world".encode("utf-8"))
        # Intent stashed in session state
        intents = stubbed_runtime["state"].user_infos["_m365_upload_intents"]
        assert out["upload_intent_id"] in intents
        assert intents[out["upload_intent_id"]]["content"] == b"Hello world"

    async def test_invalid_filename_rejected(self, stubbed_runtime):
        out = await od.prepare_upload_fn(
            file_name="bad/path.md",  # contains forbidden /
            content="x",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "INVALID_FILENAME"

    async def test_filename_starting_with_dot_rejected(self, stubbed_runtime):
        out = await od.prepare_upload_fn(
            file_name=".hidden",
            content="x",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "INVALID_FILENAME"

    async def test_filename_too_long_rejected(self, stubbed_runtime):
        out = await od.prepare_upload_fn(
            file_name="a" * 300,
            content="x",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "INVALID_FILENAME"

    async def test_empty_content_rejected(self, stubbed_runtime):
        out = await od.prepare_upload_fn(
            file_name="ok.md",
            content="",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "EMPTY_CONTENT"

    async def test_non_string_content_rejected(self, stubbed_runtime):
        out = await od.prepare_upload_fn(
            file_name="ok.md",
            content=b"binary not allowed v0.1",  # type: ignore[arg-type]
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "INVALID_CONTENT"

    async def test_oversized_content_rejected_with_size_info(self, stubbed_runtime):
        # 5 MB, above the 4 MB cap
        big = "x" * (5 * 1024 * 1024)
        out = await od.prepare_upload_fn(
            file_name="big.txt",
            content=big,
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "FILE_TOO_LARGE"
        assert out["size_bytes"] == len(big)


# ---------------------------------------------------------------------------
# confirm_upload — intent lookup + Graph PUT
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestConfirmUpload:
    async def _seed_intent(self, state, *, file_name="r.md", parent_folder_id=""):
        # Reuse prepare_upload through direct dict so we don't double-mock.
        intents = state.user_infos.setdefault("_m365_upload_intents", {})
        intent_id = "intent-test"
        intents[intent_id] = {
            "file_name": file_name,
            "parent_folder_id": parent_folder_id,
            "content": b"hello",
            "size_bytes": 5,
            "created_at": time.monotonic(),
        }
        return intent_id

    def _ok_resp(self, body: dict | None = None):
        resp = MagicMock()
        resp.status_code = 201
        resp.json.return_value = body or {
            "id": "f-uploaded",
            "name": "r.md",
            "size": 5,
            "file": {"mimeType": "text/markdown"},
            "lastModifiedDateTime": "2026-04-30T10:00:00Z",
            "parentReference": {"path": "/drive/root:"},
            "webUrl": "https://onedrive/r",
        }
        return resp

    def _err_resp(self, status: int):
        resp = MagicMock()
        resp.status_code = status
        return resp

    async def test_happy_path_uploads_to_root(self, stubbed_runtime):
        intent_id = await self._seed_intent(stubbed_runtime["state"])
        stubbed_runtime["client"]._http.put.return_value = self._ok_resp()

        out = await od.confirm_upload_fn(
            upload_intent_id=intent_id,
            config={"configurable": {"session_id": "s"}},
        )

        assert out["uploaded"] is True
        assert out["file"]["name"] == "r.md"
        # PUT URL targets root path
        url = stubbed_runtime["client"]._http.put.call_args.args[0]
        assert url.endswith("/me/drive/root:/r.md:/content")
        # Body is the raw bytes
        kwargs = stubbed_runtime["client"]._http.put.call_args.kwargs
        assert kwargs["content"] == b"hello"
        assert kwargs["headers"]["Content-Type"] == "application/octet-stream"

    async def test_happy_path_uploads_to_specific_folder(self, stubbed_runtime):
        intent_id = await self._seed_intent(
            stubbed_runtime["state"],
            parent_folder_id="folder-99",
        )
        stubbed_runtime["client"]._http.put.return_value = self._ok_resp()

        await od.confirm_upload_fn(
            upload_intent_id=intent_id,
            config={"configurable": {"session_id": "s"}},
        )
        url = stubbed_runtime["client"]._http.put.call_args.args[0]
        assert url.endswith("/me/drive/items/folder-99:/r.md:/content")

    async def test_intent_consumed_on_success(self, stubbed_runtime):
        intent_id = await self._seed_intent(stubbed_runtime["state"])
        stubbed_runtime["client"]._http.put.return_value = self._ok_resp()
        await od.confirm_upload_fn(
            upload_intent_id=intent_id,
            config={"configurable": {"session_id": "s"}},
        )
        assert (
            intent_id not in stubbed_runtime["state"].user_infos["_m365_upload_intents"]
        )

    async def test_intent_consumed_on_graph_error(self, stubbed_runtime):
        """The intent is dropped before the network call so a flaky
        upload doesn't leave a stale intent that the LLM keeps retrying.
        The user must explicitly call prepare_upload again."""
        intent_id = await self._seed_intent(stubbed_runtime["state"])
        stubbed_runtime["client"]._http.put.return_value = self._err_resp(500)

        out = await od.confirm_upload_fn(
            upload_intent_id=intent_id,
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "M365_GRAPH_ERROR"
        assert (
            intent_id not in stubbed_runtime["state"].user_infos["_m365_upload_intents"]
        )

    async def test_unknown_intent_id_returns_error_no_network_call(
        self, stubbed_runtime
    ):
        out = await od.confirm_upload_fn(
            upload_intent_id="never-prepared",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "INTENT_NOT_FOUND"
        stubbed_runtime["client"]._http.put.assert_not_called()

    async def test_expired_intent_treated_as_not_found(self, stubbed_runtime):
        state = stubbed_runtime["state"]
        intents = state.user_infos.setdefault("_m365_upload_intents", {})
        intents["stale"] = {
            "file_name": "old.md",
            "parent_folder_id": "",
            "content": b"old",
            "size_bytes": 3,
            "created_at": time.monotonic() - od._INTENT_TTL_SECONDS - 1,
        }
        out = await od.confirm_upload_fn(
            upload_intent_id="stale",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "INTENT_NOT_FOUND"

    async def test_empty_intent_id_rejected(self, stubbed_runtime):
        out = await od.confirm_upload_fn(
            upload_intent_id="",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "EMPTY_INTENT_ID"

    async def test_401_mapped_to_token_expired(self, stubbed_runtime):
        intent_id = await self._seed_intent(stubbed_runtime["state"])
        stubbed_runtime["client"]._http.put.return_value = self._err_resp(401)
        out = await od.confirm_upload_fn(
            upload_intent_id=intent_id,
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "M365_TOKEN_EXPIRED"

    async def test_403_mapped_to_graph_permission(self, stubbed_runtime):
        intent_id = await self._seed_intent(stubbed_runtime["state"])
        stubbed_runtime["client"]._http.put.return_value = self._err_resp(403)
        out = await od.confirm_upload_fn(
            upload_intent_id=intent_id,
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "M365_GRAPH_PERMISSION"

    async def test_404_mapped_to_not_found_when_parent_invalid(self, stubbed_runtime):
        intent_id = await self._seed_intent(
            stubbed_runtime["state"],
            parent_folder_id="bogus",
        )
        stubbed_runtime["client"]._http.put.return_value = self._err_resp(404)
        out = await od.confirm_upload_fn(
            upload_intent_id=intent_id,
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "M365_NOT_FOUND"
