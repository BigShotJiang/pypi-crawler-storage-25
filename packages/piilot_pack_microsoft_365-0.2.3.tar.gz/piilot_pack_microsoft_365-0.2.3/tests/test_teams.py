"""Tests for the Teams tools — Phase 7.

7 tools, mostly read. The single 2-step write path is the channel
message send. Pattern matches OneDrive/SharePoint with the intent
bucket scoped to ``_m365_teams_send_intents``.
"""

from __future__ import annotations

import time
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from piilot_pack_microsoft_365.client import (
    GraphError,
    GraphPermissionError,
)
from piilot_pack_microsoft_365.tools import teams as tm

_MODULE = "piilot_pack_microsoft_365.tools.teams"
_TEAM_ID = "team-guid-abc-123"
_CHANNEL_ID = "channel-guid-xyz-789"
_CHAT_ID = "19:abc@thread.v2"


def _state_with_company(company_id: str = "c-1"):
    state = MagicMock()
    state.user_infos = {"_organization_id": company_id}
    return state


@pytest.fixture
def stubbed_runtime():
    state = _state_with_company()
    fake_client = MagicMock()
    fake_client.get = AsyncMock()
    fake_client.request = AsyncMock()

    with (
        patch(f"{_MODULE}._get_session_state", return_value=state),
        patch(f"{_MODULE}.ensure_permission", AsyncMock(return_value=True)),
        patch(f"{_MODULE}.resolve_access_token", AsyncMock(return_value="tok")),
        patch(f"{_MODULE}._get_client", return_value=fake_client),
    ):
        yield {"state": state, "client": fake_client}


# ---------------------------------------------------------------------------
# Permission gate
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestPermissionGate:
    @pytest.mark.parametrize(
        "tool_call,expected_perm",
        [
            (
                lambda sid: tm.list_teams_fn(
                    config={"configurable": {"session_id": sid}}
                ),
                "teams.read",
            ),
            (
                lambda sid: tm.list_chats_fn(
                    config={"configurable": {"session_id": sid}}
                ),
                "teams.read",
            ),
            (
                lambda sid: tm.read_chat_messages_fn(
                    chat_id=_CHAT_ID, config={"configurable": {"session_id": sid}}
                ),
                "teams.read",
            ),
            (
                lambda sid: tm.list_channels_fn(
                    team_id=_TEAM_ID, config={"configurable": {"session_id": sid}}
                ),
                "teams.read",
            ),
            (
                lambda sid: tm.read_channel_messages_fn(
                    team_id=_TEAM_ID,
                    channel_id=_CHANNEL_ID,
                    config={"configurable": {"session_id": sid}},
                ),
                "teams.read",
            ),
            (
                lambda sid: tm.prepare_channel_message_fn(
                    team_id=_TEAM_ID,
                    channel_id=_CHANNEL_ID,
                    content="hi",
                    config={"configurable": {"session_id": sid}},
                ),
                "teams.write",
            ),
            (
                lambda sid: tm.confirm_channel_message_fn(
                    send_intent_id="i", config={"configurable": {"session_id": sid}}
                ),
                "teams.write",
            ),
        ],
    )
    async def test_each_tool_blocked_when_permission_off(
        self, tool_call, expected_perm
    ):
        state = _state_with_company()
        with (
            patch(f"{_MODULE}._get_session_state", return_value=state),
            patch(f"{_MODULE}.ensure_permission", AsyncMock(return_value=False)),
        ):
            out = await tool_call("s")
        assert out["error_code"] == "M365_PERMISSION_DISABLED"
        assert out["permission"] == expected_perm


# ---------------------------------------------------------------------------
# READ paths
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestListTeams:
    async def test_returns_summarised_teams(self, stubbed_runtime):
        stubbed_runtime["client"].get.return_value = {
            "value": [
                {
                    "id": _TEAM_ID,
                    "displayName": "Marketing",
                    "description": "Marketing team",
                    "webUrl": "https://teams/m",
                    "visibility": "private",
                }
            ],
        }
        out = await tm.list_teams_fn(config={"configurable": {"session_id": "s"}})
        assert out["count"] == 1
        assert out["items"][0]["name"] == "Marketing"
        assert out["items"][0]["visibility"] == "private"

    async def test_limit_capped_at_max(self, stubbed_runtime):
        stubbed_runtime["client"].get.return_value = {"value": []}
        await tm.list_teams_fn(
            limit=999,
            config={"configurable": {"session_id": "s"}},
        )
        params = stubbed_runtime["client"].get.call_args.kwargs["params"]
        assert params["$top"] == 50  # _MAX_LIMIT for Teams


@pytest.mark.asyncio
class TestListChats:
    async def test_returns_chats_ordered_recent_first(self, stubbed_runtime):
        stubbed_runtime["client"].get.return_value = {
            "value": [
                {
                    "id": _CHAT_ID,
                    "topic": "Projet X",
                    "chatType": "group",
                    "lastUpdatedDateTime": "2026-04-30T10:00:00Z",
                    "webUrl": "https://teams/chat",
                }
            ],
        }
        out = await tm.list_chats_fn(config={"configurable": {"session_id": "s"}})
        assert out["count"] == 1
        assert out["items"][0]["chat_type"] == "group"
        params = stubbed_runtime["client"].get.call_args.kwargs["params"]
        assert params["$orderby"] == "lastUpdatedDateTime desc"


@pytest.mark.asyncio
class TestReadChatMessages:
    async def test_invalid_chat_id_rejected(self, stubbed_runtime):
        out = await tm.read_chat_messages_fn(
            chat_id="bad chat with spaces",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "INVALID_CHAT_ID"
        stubbed_runtime["client"].get.assert_not_called()

    async def test_summarises_messages(self, stubbed_runtime):
        stubbed_runtime["client"].get.return_value = {
            "value": [
                {
                    "id": "msg-1",
                    "from": {"user": {"displayName": "Alice", "id": "u-alice"}},
                    "createdDateTime": "2026-04-30T10:00:00Z",
                    "body": {"contentType": "html", "content": "<p>Hello there</p>"},
                    "webUrl": "https://teams/msg/1",
                }
            ],
        }
        out = await tm.read_chat_messages_fn(
            chat_id=_CHAT_ID,
            config={"configurable": {"session_id": "s"}},
        )
        msg = out["items"][0]
        assert msg["from_name"] == "Alice"
        assert msg["from_id"] == "u-alice"
        assert "<p>Hello" in msg["content"]


@pytest.mark.asyncio
class TestListChannels:
    async def test_invalid_team_id_rejected(self, stubbed_runtime):
        out = await tm.list_channels_fn(
            team_id="bad spaces",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "INVALID_TEAM_ID"
        stubbed_runtime["client"].get.assert_not_called()

    async def test_returns_channels(self, stubbed_runtime):
        stubbed_runtime["client"].get.return_value = {
            "value": [
                {
                    "id": _CHANNEL_ID,
                    "displayName": "General",
                    "membershipType": "standard",
                    "webUrl": "https://teams/general",
                }
            ],
        }
        out = await tm.list_channels_fn(
            team_id=_TEAM_ID,
            config={"configurable": {"session_id": "s"}},
        )
        assert out["items"][0]["name"] == "General"
        assert out["items"][0]["membership"] == "standard"


@pytest.mark.asyncio
class TestReadChannelMessages:
    async def test_path_includes_team_and_channel(self, stubbed_runtime):
        stubbed_runtime["client"].get.return_value = {"value": []}
        await tm.read_channel_messages_fn(
            team_id=_TEAM_ID,
            channel_id=_CHANNEL_ID,
            config={"configurable": {"session_id": "s"}},
        )
        path = stubbed_runtime["client"].get.call_args.args[0]
        assert path == f"teams/{_TEAM_ID}/channels/{_CHANNEL_ID}/messages"

    async def test_invalid_channel_id_rejected(self, stubbed_runtime):
        out = await tm.read_channel_messages_fn(
            team_id=_TEAM_ID,
            channel_id="bad spaces",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "INVALID_CHANNEL_ID"

    async def test_403_carries_admin_consent_hint(self, stubbed_runtime):
        stubbed_runtime["client"].get.side_effect = GraphPermissionError(
            "403",
            response_body={"error": {"code": "Authorization_RequestDenied"}},
        )
        out = await tm.read_channel_messages_fn(
            team_id=_TEAM_ID,
            channel_id=_CHANNEL_ID,
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "M365_GRAPH_PERMISSION"
        assert "admin tenant" in out["error"]


# ---------------------------------------------------------------------------
# 2-step send
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestPrepareChannelMessage:
    async def test_happy_path_stores_intent(self, stubbed_runtime):
        out = await tm.prepare_channel_message_fn(
            team_id=_TEAM_ID,
            channel_id=_CHANNEL_ID,
            content="Hello team !",
            config={"configurable": {"session_id": "s"}},
        )
        assert "send_intent_id" in out
        assert out["preview"]["content_excerpt"].startswith("Hello team")
        intents = stubbed_runtime["state"].user_infos["_m365_teams_send_intents"]
        assert intents[out["send_intent_id"]]["team_id"] == _TEAM_ID
        assert intents[out["send_intent_id"]]["kind"] == "channel_message"

    async def test_intent_bucket_distinct_from_other_services(self, stubbed_runtime):
        await tm.prepare_channel_message_fn(
            team_id=_TEAM_ID,
            channel_id=_CHANNEL_ID,
            content="hi",
            config={"configurable": {"session_id": "s"}},
        )
        infos = stubbed_runtime["state"].user_infos
        assert "_m365_teams_send_intents" in infos
        # Must not have created OneDrive's or SharePoint's bucket
        assert "_m365_upload_intents" not in infos
        assert "_m365_sharepoint_upload_intents" not in infos

    async def test_invalid_team_id_rejected(self, stubbed_runtime):
        out = await tm.prepare_channel_message_fn(
            team_id="bad spaces",
            channel_id=_CHANNEL_ID,
            content="hi",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "INVALID_TEAM_ID"

    async def test_empty_content_rejected(self, stubbed_runtime):
        out = await tm.prepare_channel_message_fn(
            team_id=_TEAM_ID,
            channel_id=_CHANNEL_ID,
            content="   ",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "EMPTY_CONTENT"

    async def test_oversized_content_rejected_with_length(self, stubbed_runtime):
        big = "a" * 11_000
        out = await tm.prepare_channel_message_fn(
            team_id=_TEAM_ID,
            channel_id=_CHANNEL_ID,
            content=big,
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "MESSAGE_TOO_LONG"
        assert out["length"] == 11_000


@pytest.mark.asyncio
class TestConfirmChannelMessage:
    async def _seed_intent(self, state):
        intents = state.user_infos.setdefault("_m365_teams_send_intents", {})
        intent_id = "intent-test"
        intents[intent_id] = {
            "kind": "channel_message",
            "team_id": _TEAM_ID,
            "channel_id": _CHANNEL_ID,
            "content": "hello",
            "created_at": time.monotonic(),
        }
        return intent_id

    async def test_happy_path_posts_to_correct_endpoint(self, stubbed_runtime):
        intent_id = await self._seed_intent(stubbed_runtime["state"])
        stubbed_runtime["client"].request.return_value = {
            "id": "posted-msg-1",
            "from": {"user": {"displayName": "Me"}},
            "createdDateTime": "2026-04-30T10:00:00Z",
            "body": {"contentType": "text", "content": "hello"},
        }
        out = await tm.confirm_channel_message_fn(
            send_intent_id=intent_id,
            config={"configurable": {"session_id": "s"}},
        )
        assert out["sent"] is True
        assert out["message"]["id"] == "posted-msg-1"
        # POST to teams/{}/channels/{}/messages
        call = stubbed_runtime["client"].request.call_args
        assert call.args[0] == "POST"
        assert call.args[1] == f"teams/{_TEAM_ID}/channels/{_CHANNEL_ID}/messages"
        # Body shape : {body: {contentType: 'text', content: '...'}}
        sent_body = call.kwargs["json"]
        assert sent_body["body"]["content"] == "hello"
        assert sent_body["body"]["contentType"] == "text"

    async def test_intent_consumed_on_success(self, stubbed_runtime):
        intent_id = await self._seed_intent(stubbed_runtime["state"])
        stubbed_runtime["client"].request.return_value = {"id": "m"}
        await tm.confirm_channel_message_fn(
            send_intent_id=intent_id,
            config={"configurable": {"session_id": "s"}},
        )
        assert (
            intent_id
            not in stubbed_runtime["state"].user_infos["_m365_teams_send_intents"]
        )

    async def test_intent_consumed_on_graph_error(self, stubbed_runtime):
        intent_id = await self._seed_intent(stubbed_runtime["state"])
        stubbed_runtime["client"].request.side_effect = GraphError(
            "500", status_code=500
        )
        out = await tm.confirm_channel_message_fn(
            send_intent_id=intent_id,
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "M365_GRAPH_ERROR"
        assert (
            intent_id
            not in stubbed_runtime["state"].user_infos["_m365_teams_send_intents"]
        )

    async def test_unknown_intent_no_network_call(self, stubbed_runtime):
        out = await tm.confirm_channel_message_fn(
            send_intent_id="never-prepared",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "INTENT_NOT_FOUND"
        stubbed_runtime["client"].request.assert_not_called()

    async def test_expired_intent_treated_as_not_found(self, stubbed_runtime):
        state = stubbed_runtime["state"]
        intents = state.user_infos.setdefault("_m365_teams_send_intents", {})
        intents["stale"] = {
            "kind": "channel_message",
            "team_id": _TEAM_ID,
            "channel_id": _CHANNEL_ID,
            "content": "old",
            "created_at": time.monotonic() - tm._INTENT_TTL_SECONDS - 1,
        }
        out = await tm.confirm_channel_message_fn(
            send_intent_id="stale",
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "INTENT_NOT_FOUND"

    async def test_403_carries_admin_consent_hint(self, stubbed_runtime):
        intent_id = await self._seed_intent(stubbed_runtime["state"])
        stubbed_runtime["client"].request.side_effect = GraphPermissionError(
            "403",
            response_body={"error": {"code": "Authorization_RequestDenied"}},
        )
        out = await tm.confirm_channel_message_fn(
            send_intent_id=intent_id,
            config={"configurable": {"session_id": "s"}},
        )
        assert out["error_code"] == "M365_GRAPH_PERMISSION"
        assert "admin tenant" in out["error"]
