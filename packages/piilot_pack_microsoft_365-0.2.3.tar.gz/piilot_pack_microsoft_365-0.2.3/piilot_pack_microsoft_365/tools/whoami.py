"""Agent tool ``microsoft_365.whoami`` — Phase 1 sanity check.

Queries Microsoft Graph ``/me`` with the connection's access token and
returns a small dict ``{display_name, email, tenant_id}``. The single
purpose is to prove the OAuth → token storage → Graph call chain works
end-to-end before we write the real tools (Outlook, OneDrive…) on top.

Once Phase 2 wires the OAuth flow, an admin can:
  1. Click "Connect Microsoft 365" in Settings.
  2. Run an agent equipped with this tool.
  3. Ask the agent: « qui suis-je sur M365 ? » → the tool returns
     the connected user's email/display name.

If that works, all subsequent tools (search_mail, list_files, …) are
incremental — they reuse the same token + client.
"""

from __future__ import annotations

import logging
from typing import Any

from piilot.sdk import Context
from langchain_core.tools import StructuredTool

from piilot.sdk.tools import bind_session, register_tool

from ..client import (
    GraphAPIClient,
    GraphAuthError,
    GraphError,
    GraphPermissionError,
)

logger = logging.getLogger(__name__)


# A single client instance is reused across calls inside this process.
# httpx.AsyncClient holds a connection pool; recreating per-call would
# negate the keep-alive and double the latency on subsequent tool runs.
_client: GraphAPIClient | None = None


def _get_client() -> GraphAPIClient:
    global _client
    if _client is None:
        _client = GraphAPIClient()
    return _client


@bind_session
async def whoami_fn(*, session_id: str) -> dict[str, Any]:
    """Return the identity of the M365 user this connection belongs to.

    Args (LLM-facing):
        (none — session_id is auto-injected by the LangGraph runtime
        via ``bind_session`` and is **not** part of the LLM tool schema)

    Returns:
        ``{"display_name": str, "email": str, "tenant_id": str}`` on
        success, or a single-key ``{"error": "..."}`` dict the LLM can
        relay verbatim. Errors are returned as data — never raised —
        so the agent loop keeps making progress.

    Phase 1 stub: until Phase 2 wires the connection storage, this
    function returns an explanatory error pointing the user at the
    Settings page.
    """
    # Phase 1: no connection storage yet. Phase 2 will replace this
    # branch with a lookup of the active company's M365 connection.
    return {
        "error": (
            "Microsoft 365 n'est pas encore connecté pour cette company. "
            "Allez dans Paramètres → Microsoft 365, cliquez sur "
            "« Connecter Microsoft 365 », puis cochez les permissions "
            "souhaitées. (Phase 2 du chantier C11 — bientôt disponible.)"
        ),
        "phase": "scaffolding-only",
        "session_id": session_id,
    }


async def whoami_with_token(access_token: str) -> dict[str, Any]:
    """Internal helper exercised by Phase 1 tests. Calls Graph /me with
    the supplied token and shapes the response.

    Public ``whoami_fn`` will route through this once Phase 2 has the
    token storage wired. Keeping the two split makes Phase 1 testable
    without mocking the entire connection layer.
    """
    client = _get_client()
    try:
        body = await client.get("me", access_token=access_token)
    except GraphAuthError:
        return {"error": "Token Microsoft expiré ou révoqué — reconnectez la company."}
    except GraphPermissionError as exc:
        return {
            "error": "Permission refusée par Microsoft Graph.",
            "graph_error": exc.response_body.get("error", {}).get("code"),
        }
    except GraphError as exc:
        logger.warning("whoami: graph error %s — %s", exc.status_code, exc)
        return {"error": "Erreur Microsoft Graph — réessayez plus tard."}

    return {
        "display_name": body.get("displayName") or "",
        "email": body.get("mail") or body.get("userPrincipalName") or "",
        # Tenant id is exposed via /me on Entra accounts; it lets the
        # agent correlate replies with the right Azure tenant when a
        # company has multiple connections (multi-tenant scenarios v2).
        "tenant_id": (
            body.get("id", "").split("@")[-1] if "@" in body.get("id", "") else ""
        ),
        # Echo a small subset useful for downstream tools (e.g. the user
        # principal name is the input format Graph wants for /users/{upn}).
        "user_principal_name": body.get("userPrincipalName") or "",
    }


def register_tools(ctx: Context) -> None:
    """Register the Phase 1 tool with the SDK.

    The SDK's ``register_tool`` takes a spec dict with at minimum
    ``id`` (namespaced) and ``tool`` (a LangChain ``StructuredTool``).
    Per-scope permission gating is enforced inside each tool fn via
    ``ensure_permission`` — not declared at registration time.
    """
    register_tool(
        {
            "id": "microsoft_365.whoami",
            "tool": StructuredTool.from_function(
                whoami_fn,
                name="microsoft_365_whoami",
                description=(
                    "Renvoie l'identité du compte Microsoft 365 connecté pour "
                    "cette company (nom d'affichage, email, tenant). À utiliser "
                    "comme test de la connexion M365 avant les autres tools."
                ),
            ),
        }
    )
