"""Agent tools for OneDrive — search/list/download (read) + prepare/confirm upload (write).

Design notes
------------

**HITL pattern via 2-step intent** : OneDrive has no "drafts" folder
visible to the user (unlike Outlook), so we can't materialise a
preview in Microsoft. We replicate the architectural safety of the
Outlook pattern with **in-session intents**:

  1. ``prepare_upload`` validates inputs, computes the staged content
     size, and stores an *intent* in the agent session. Returns an
     ``upload_intent_id`` + a preview the LLM can show.
  2. ``confirm_upload`` looks up the intent, calls Graph to do the
     real upload, and deletes the intent. Without a valid intent_id,
     no upload is possible.

The intent is bound to a single agent session — when the session
ends, the intent disappears. TTL of 5 minutes prevents stale intents
from lingering across long agent thinking pauses.

**Download returns a temporary signed URL**, not the raw bytes —
agents can't usefully consume binary payloads, and base64 in tool
responses would explode the LLM's context. The agent presents the
URL to the user (Graph TTL ~1h) and the user clicks it.

**Text-only upload v0.1**. Binary upload (PDFs, images) requires
Graph's ``uploadSession`` flow with chunking, deferred to v0.2.

Graph endpoints used (v1.0)
---------------------------

  - ``GET /me/drive/root/search(q='...')``    search files
  - ``GET /me/drive/items/{id}``              file metadata
  - ``GET /me/drive/root/children``           list root folder
  - ``GET /me/drive/items/{id}/children``     list a folder
  - ``PUT /me/drive/root:/{path}:/content``   simple upload (<4MB)
  - ``PUT /me/drive/items/{id}:/{name}:/content``  upload to folder
"""

from __future__ import annotations

import logging
import re
import time
import uuid
from typing import Any

from piilot.sdk import Context
from langchain_core.tools import StructuredTool

from piilot.sdk.tools import bind_session, register_tool

from ..client import (
    GraphAPIClient,
    GraphAuthError,
    GraphError,
    GraphNotFoundError,
    GraphPermissionError,
    GraphRateLimitedError,
)
from ._auth import (
    ensure_permission,
    not_connected_error,
    permission_denied_error,
    resolve_access_token,
)

logger = logging.getLogger(__name__)


_client: GraphAPIClient | None = None


def _get_client() -> GraphAPIClient:
    global _client
    if _client is None:
        _client = GraphAPIClient()
    return _client


# Caps. The simple-upload Graph endpoint (PUT /content) is documented
# safe up to 4 MB. Anything larger requires uploadSession + chunking
# which is v0.2.
_MAX_UPLOAD_BYTES = 4 * 1024 * 1024
_MAX_LIMIT = 25
_DEFAULT_LIMIT = 10

# Intent TTL — give the agent a window to converse with the user
# before the intent expires. 5 minutes is a balance between UX
# (the user has time to read + reply) and safety (no hours-long
# stale intent).
_INTENT_TTL_SECONDS = 300

# OneDrive file name validation. Microsoft refuses some characters
# (https://learn.microsoft.com/en-us/onedrive/developer/rest-api/concepts/addressing-driveitems).
# We validate upfront for a clearer error than a 400 from Graph.
_FORBIDDEN_NAME_CHARS = re.compile(r'[\\/:*?"<>|]')
_MAX_FILENAME_LEN = 255


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _summarise_drive_item(item: dict) -> dict:
    """Compact a DriveItem into the fields the LLM needs."""
    parent = item.get("parentReference") or {}
    return {
        "id": item.get("id"),
        "name": item.get("name") or "",
        "kind": "folder" if item.get("folder") else "file",
        "size_bytes": item.get("size", 0),
        "modified_at": item.get("lastModifiedDateTime"),
        "mime_type": (item.get("file") or {}).get("mimeType"),
        "parent_path": parent.get("path") or "",
        "web_url": item.get("webUrl"),  # opens in browser; safe to share with user
    }


def _company_id_from_state(state) -> str | None:
    try:
        infos = getattr(state, "user_infos", None) or {}
        return infos.get("_organization_id") or infos.get("company_id")
    except Exception:  # noqa: BLE001
        return None


def _get_session_state(session_id: str):
    try:
        from piilot.sdk.session import get as _session_get

        return _session_get(session_id)
    except Exception:  # noqa: BLE001
        return None


def _map_graph_error(exc: GraphError, action: str) -> dict:
    """Standard Graph-error → errors-as-data envelope (mirrors Outlook)."""
    if isinstance(exc, GraphAuthError):
        return {
            "error_code": "M365_TOKEN_EXPIRED",
            "error": "Le token Microsoft a expiré ou été révoqué. La company doit reconnecter Microsoft 365.",
        }
    if isinstance(exc, GraphPermissionError):
        return {
            "error_code": "M365_GRAPH_PERMISSION",
            "error": (
                f"Microsoft refuse l'accès pour cette action ({action}). "
                "Vérifiez que l'admin tenant a validé l'app Piilot et "
                "que l'utilisateur a les droits requis."
            ),
            "graph_error_code": (exc.response_body or {}).get("error", {}).get("code"),
        }
    if isinstance(exc, GraphNotFoundError):
        return {
            "error_code": "M365_NOT_FOUND",
            "error": f"Ressource introuvable ({action}).",
        }
    if isinstance(exc, GraphRateLimitedError):
        return {
            "error_code": "M365_RATE_LIMITED",
            "error": "Microsoft Graph limite les requêtes — réessayez dans quelques secondes.",
            "retry_after": exc.retry_after,
        }
    return {
        "error_code": "M365_GRAPH_ERROR",
        "error": f"Erreur Microsoft Graph ({action}).",
        "status_code": exc.status_code,
    }


# ---------------------------------------------------------------------------
# Intent storage — bound to the agent session, TTL-cleaned on read
# ---------------------------------------------------------------------------


_INTENT_KEY = "_m365_upload_intents"


def _get_intents_dict(state) -> dict[str, dict]:
    """Return the intent dict on the session state, creating it if needed.

    Stored under ``state.user_infos`` so the session lifecycle owns
    cleanup — when the session ends, the intents go with it.
    """
    infos = getattr(state, "user_infos", None)
    if infos is None:
        # Defensive — session state is supposed to have user_infos.
        return {}
    intents = infos.get(_INTENT_KEY)
    if intents is None:
        intents = {}
        infos[_INTENT_KEY] = intents
    return intents


def _purge_expired_intents(intents: dict[str, dict]) -> None:
    """Drop intents older than the TTL. Mutates in place."""
    now = time.monotonic()
    expired = [
        intent_id
        for intent_id, payload in intents.items()
        if now - payload.get("created_at", 0) > _INTENT_TTL_SECONDS
    ]
    for intent_id in expired:
        intents.pop(intent_id, None)


def _validate_filename(name: str) -> tuple[bool, str | None]:
    if not name:
        return False, "Le nom du fichier est requis."
    if len(name) > _MAX_FILENAME_LEN:
        return False, f"Nom de fichier trop long (>{_MAX_FILENAME_LEN} caractères)."
    if name.startswith(".") or name.startswith(" ") or name.endswith(" "):
        return (
            False,
            "Le nom ne peut pas commencer par un point ou un espace, ni se terminer par un espace.",
        )
    if _FORBIDDEN_NAME_CHARS.search(name):
        return (
            False,
            'Le nom contient un caractère interdit par OneDrive : \\ / : * ? " < > |',
        )
    return True, None


# ---------------------------------------------------------------------------
# READ tools
# ---------------------------------------------------------------------------


@bind_session
async def search_files_fn(
    query: str,
    limit: int = _DEFAULT_LIMIT,
    *,
    session_id: str,
) -> dict[str, Any]:
    """Recherche dans le OneDrive de l'utilisateur connecté.

    Args (LLM-facing):
        query: Termes recherchés (nom de fichier, contenu indexé).
        limit: Nombre max de résultats (cap à 25).

    Returns:
        ``{"items": [{summary}, ...], "count": N}`` ou ``{"error": ...}``.
    """
    state = _get_session_state(session_id)
    if not state:
        return {"error_code": "SESSION_NOT_FOUND", "error": "Session introuvable."}
    company_id = _company_id_from_state(state)
    if not company_id:
        return {
            "error_code": "NO_COMPANY",
            "error": "Pas de company sur cette session.",
        }

    if not await ensure_permission(company_id, "onedrive.read"):
        return permission_denied_error("onedrive.read")
    token = await resolve_access_token(company_id)
    if not token:
        return not_connected_error()

    cleaned = (query or "").strip()
    if not cleaned:
        return {
            "error_code": "EMPTY_QUERY",
            "error": "Le paramètre 'query' est requis.",
        }
    capped = max(1, min(limit, _MAX_LIMIT))

    client = _get_client()
    try:
        # Microsoft Graph search syntax for drives uses the function
        # form ``search(q='...')``, with the query embedded via a
        # parameter; quoting handled at the URL level for safety.
        body = await client.get(
            f"me/drive/root/search(q='{cleaned}')",
            access_token=token,
            params={"$top": capped},
        )
    except GraphError as exc:
        return _map_graph_error(exc, action="search_files")

    items = [_summarise_drive_item(it) for it in (body.get("value") or [])]
    return {"items": items, "count": len(items)}


@bind_session
async def download_file_fn(file_id: str, *, session_id: str) -> dict[str, Any]:
    """Renvoie les métadonnées d'un fichier + une URL signée temporaire pour
    le télécharger.

    L'URL est valable ~1h. À présenter à l'utilisateur ; ne pas
    récupérer le contenu côté agent — le LLM ne consomme pas de binaire.

    Args (LLM-facing):
        file_id: Identifiant DriveItem (renvoyé par search/list).

    Returns:
        ``{"file": {summary}, "download_url": "https://..."}`` ou ``{"error": ...}``.
    """
    state = _get_session_state(session_id)
    if not state:
        return {"error_code": "SESSION_NOT_FOUND", "error": "Session introuvable."}
    company_id = _company_id_from_state(state)
    if not company_id:
        return {
            "error_code": "NO_COMPANY",
            "error": "Pas de company sur cette session.",
        }

    if not await ensure_permission(company_id, "onedrive.read"):
        return permission_denied_error("onedrive.read")
    token = await resolve_access_token(company_id)
    if not token:
        return not_connected_error()

    if not (file_id or "").strip():
        return {"error_code": "EMPTY_FILE_ID", "error": "Le 'file_id' est requis."}

    client = _get_client()
    try:
        # ``$select`` keeps the payload small + asks Graph to include
        # the temporary download URL via the documented OData parameter.
        body = await client.get(
            f"me/drive/items/{file_id}",
            access_token=token,
            params={
                "$select": (
                    "id,name,size,file,folder,parentReference,"
                    "lastModifiedDateTime,webUrl,@microsoft.graph.downloadUrl"
                ),
            },
        )
    except GraphError as exc:
        return _map_graph_error(exc, action="download_file")

    if body.get("folder"):
        return {
            "error_code": "IS_FOLDER",
            "error": "L'identifiant pointe vers un dossier, pas un fichier.",
        }

    return {
        "file": _summarise_drive_item(body),
        "download_url": body.get("@microsoft.graph.downloadUrl"),
    }


@bind_session
async def list_folder_fn(
    folder_id: str | None = None,
    limit: int = _DEFAULT_LIMIT,
    skip: int = 0,
    *,
    session_id: str,
) -> dict[str, Any]:
    """Liste le contenu d'un dossier OneDrive.

    Args (LLM-facing):
        folder_id: Identifiant du dossier à lister. Omettre ou passer
                   None liste la racine du drive.
        limit: Nombre max d'éléments (cap à 25).
        skip: Pagination (offset, >=0).
    """
    state = _get_session_state(session_id)
    if not state:
        return {"error_code": "SESSION_NOT_FOUND", "error": "Session introuvable."}
    company_id = _company_id_from_state(state)
    if not company_id:
        return {
            "error_code": "NO_COMPANY",
            "error": "Pas de company sur cette session.",
        }

    if not await ensure_permission(company_id, "onedrive.read"):
        return permission_denied_error("onedrive.read")
    token = await resolve_access_token(company_id)
    if not token:
        return not_connected_error()

    capped = max(1, min(limit, _MAX_LIMIT))
    skip_safe = max(0, int(skip))

    path = (
        "me/drive/root/children"
        if not (folder_id or "").strip()
        else f"me/drive/items/{folder_id}/children"
    )

    client = _get_client()
    try:
        body = await client.get(
            path,
            access_token=token,
            params={"$top": capped, "$skip": skip_safe},
        )
    except GraphError as exc:
        return _map_graph_error(exc, action="list_folder")

    items = [_summarise_drive_item(it) for it in (body.get("value") or [])]
    return {"items": items, "count": len(items), "skip": skip_safe}


# ---------------------------------------------------------------------------
# WRITE tools — 2-step intent pattern
# ---------------------------------------------------------------------------


@bind_session
async def prepare_upload_fn(
    file_name: str,
    content: str,
    parent_folder_id: str | None = None,
    *,
    session_id: str,
) -> dict[str, Any]:
    """Stage un upload OneDrive **sans le réaliser**.

    Crée une "intention d'upload" stockée dans la session de l'agent.
    L'upload réel n'a lieu que sur appel ultérieur à ``confirm_upload``
    avec l'``upload_intent_id`` retourné. Pas de fichier envoyé tant que
    l'utilisateur n'a pas explicitement confirmé.

    Args (LLM-facing):
        file_name: Nom du fichier (extension incluse, ex. "rapport.md").
        content: Contenu textuel du fichier (UTF-8). v0.1 ne supporte
                 que le texte ; le binaire arrivera en v0.2.
        parent_folder_id: Identifiant du dossier parent. Omettre pour
                          uploader à la racine du drive.

    Returns:
        ``{"upload_intent_id": "...", "preview": {name, size_bytes, parent_folder_id, expires_in_seconds}}``
        ou ``{"error": ...}``.
    """
    state = _get_session_state(session_id)
    if not state:
        return {"error_code": "SESSION_NOT_FOUND", "error": "Session introuvable."}
    company_id = _company_id_from_state(state)
    if not company_id:
        return {
            "error_code": "NO_COMPANY",
            "error": "Pas de company sur cette session.",
        }

    if not await ensure_permission(company_id, "onedrive.write"):
        return permission_denied_error("onedrive.write")
    token = await resolve_access_token(company_id)
    if not token:
        return not_connected_error()

    name_ok, err = _validate_filename(file_name or "")
    if not name_ok:
        return {"error_code": "INVALID_FILENAME", "error": err}

    if not isinstance(content, str):
        return {
            "error_code": "INVALID_CONTENT",
            "error": "Le contenu doit être du texte (str). v0.2 ajoutera le binaire.",
        }
    payload_bytes = content.encode("utf-8")
    size = len(payload_bytes)
    if size == 0:
        return {"error_code": "EMPTY_CONTENT", "error": "Le contenu est vide."}
    if size > _MAX_UPLOAD_BYTES:
        return {
            "error_code": "FILE_TOO_LARGE",
            "error": f"Fichier trop volumineux pour un upload simple (>{_MAX_UPLOAD_BYTES} octets). v0.2 supportera les uploads chunkés.",
            "size_bytes": size,
            "max_bytes": _MAX_UPLOAD_BYTES,
        }

    intents = _get_intents_dict(state)
    _purge_expired_intents(intents)
    intent_id = uuid.uuid4().hex
    intents[intent_id] = {
        "file_name": file_name,
        "parent_folder_id": parent_folder_id or "",
        "content": payload_bytes,  # bytes — never sent to LLM
        "size_bytes": size,
        "created_at": time.monotonic(),
    }

    return {
        "upload_intent_id": intent_id,
        "preview": {
            "file_name": file_name,
            "size_bytes": size,
            "parent_folder_id": parent_folder_id or "(racine du drive)",
            "expires_in_seconds": _INTENT_TTL_SECONDS,
        },
        "next_step": (
            "Présentez ce résumé à l'utilisateur. Demandez explicitement "
            "la confirmation, puis appelez confirm_upload(upload_intent_id) "
            "pour effectuer l'upload."
        ),
    }


@bind_session
async def confirm_upload_fn(
    upload_intent_id: str,
    *,
    session_id: str,
) -> dict[str, Any]:
    """Effectue l'upload OneDrive sur la base d'une intention créée
    par ``prepare_upload``. À appeler **uniquement après confirmation
    explicite de l'utilisateur**.

    Args (LLM-facing):
        upload_intent_id: Identifiant retourné par ``prepare_upload``.

    Returns:
        ``{"file": {summary}, "uploaded": True}`` ou ``{"error": ...}``.
    """
    state = _get_session_state(session_id)
    if not state:
        return {"error_code": "SESSION_NOT_FOUND", "error": "Session introuvable."}
    company_id = _company_id_from_state(state)
    if not company_id:
        return {
            "error_code": "NO_COMPANY",
            "error": "Pas de company sur cette session.",
        }

    if not await ensure_permission(company_id, "onedrive.write"):
        return permission_denied_error("onedrive.write")
    token = await resolve_access_token(company_id)
    if not token:
        return not_connected_error()

    if not (upload_intent_id or "").strip():
        return {
            "error_code": "EMPTY_INTENT_ID",
            "error": "Le 'upload_intent_id' est requis.",
        }

    intents = _get_intents_dict(state)
    _purge_expired_intents(intents)
    intent = intents.get(upload_intent_id)
    if not intent:
        # Either the id is bogus, or the intent expired — same UX.
        return {
            "error_code": "INTENT_NOT_FOUND",
            "error": (
                "L'intention d'upload est introuvable ou a expiré. "
                f"Les intentions expirent au bout de {_INTENT_TTL_SECONDS}s. "
                "Recommencez avec prepare_upload."
            ),
        }

    file_name = intent["file_name"]
    parent_id = intent["parent_folder_id"]
    payload = intent["content"]

    # Drop the intent BEFORE the network call. If the upload fails the
    # LLM must call prepare_upload again — that prevents accidental
    # re-confirms looping forever on a flaky network.
    intents.pop(upload_intent_id, None)

    path = (
        f"me/drive/root:/{file_name}:/content"
        if not parent_id
        else f"me/drive/items/{parent_id}:/{file_name}:/content"
    )

    client = _get_client()
    try:
        # We bypass the JSON helper because Graph upload expects a raw
        # binary body. Use the underlying httpx client directly.
        url = f"{client._base_url}/{path}"
        resp = await client._http.put(
            url,
            content=payload,
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/octet-stream",
            },
        )
    except Exception as exc:  # noqa: BLE001
        logger.warning("confirm_upload: transport error %s", exc)
        return {
            "error_code": "M365_GRAPH_ERROR",
            "error": "Erreur de transport vers Microsoft Graph.",
        }

    if resp.status_code in (200, 201):
        try:
            body = resp.json()
        except ValueError:
            return {
                "error_code": "M365_GRAPH_ERROR",
                "error": "Réponse Graph invalide.",
            }
        return {"uploaded": True, "file": _summarise_drive_item(body)}

    # Map error codes — same envelope shape as the read paths.
    if resp.status_code == 401:
        return {
            "error_code": "M365_TOKEN_EXPIRED",
            "error": "Le token Microsoft a expiré ou été révoqué.",
        }
    if resp.status_code == 403:
        return {
            "error_code": "M365_GRAPH_PERMISSION",
            "error": "Microsoft refuse l'upload (admin consent ou droits).",
        }
    if resp.status_code == 404:
        return {"error_code": "M365_NOT_FOUND", "error": "Dossier parent introuvable."}
    if resp.status_code == 429:
        return {
            "error_code": "M365_RATE_LIMITED",
            "error": "Microsoft Graph limite les requêtes.",
        }
    return {
        "error_code": "M365_GRAPH_ERROR",
        "error": "Upload Graph en échec.",
        "status_code": resp.status_code,
    }


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


def register_tools(ctx: Context) -> None:
    """Register the 5 OneDrive tools with the SDK."""
    register_tool(
        {
            "id": "microsoft_365.onedrive.search_files",
            "tool": StructuredTool.from_function(
                search_files_fn,
                name="microsoft_365_onedrive_search_files",
                description="Recherche dans le OneDrive de l'utilisateur (nom + contenu indexé). Cap 25 résultats.",
            ),
        }
    )
    register_tool(
        {
            "id": "microsoft_365.onedrive.download_file",
            "tool": StructuredTool.from_function(
                download_file_fn,
                name="microsoft_365_onedrive_download_file",
                description=(
                    "Renvoie les métadonnées d'un fichier OneDrive + une URL "
                    "de téléchargement signée temporaire à présenter à l'utilisateur. "
                    "Le contenu binaire n'est PAS chargé côté agent."
                ),
            ),
        }
    )
    register_tool(
        {
            "id": "microsoft_365.onedrive.list_folder",
            "tool": StructuredTool.from_function(
                list_folder_fn,
                name="microsoft_365_onedrive_list_folder",
                description="Liste les éléments d'un dossier OneDrive (racine si folder_id omis).",
            ),
        }
    )
    register_tool(
        {
            "id": "microsoft_365.onedrive.prepare_upload",
            "tool": StructuredTool.from_function(
                prepare_upload_fn,
                name="microsoft_365_onedrive_prepare_upload",
                description=(
                    "Stage un upload OneDrive — ne l'envoie PAS. Retourne un "
                    "upload_intent_id à confirmer via confirm_upload après "
                    "validation utilisateur. v0.1 supporte uniquement le texte "
                    "(<4 MB)."
                ),
            ),
        }
    )
    register_tool(
        {
            "id": "microsoft_365.onedrive.confirm_upload",
            "tool": StructuredTool.from_function(
                confirm_upload_fn,
                name="microsoft_365_onedrive_confirm_upload",
                description=(
                    "Effectue l'upload OneDrive associé à un upload_intent_id "
                    "précédemment créé. À appeler UNIQUEMENT après confirmation "
                    "explicite de l'utilisateur."
                ),
            ),
        }
    )
