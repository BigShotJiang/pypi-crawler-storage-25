"""Agent tools for Outlook — search/read/list (read) + create_draft/send_draft (write).

Design notes
------------

**HITL pattern via 2-step write** : sending a mail requires the LLM to
call ``create_draft`` first (returns a draft id) and then ``send_draft``
to actually send it. The natural pause between the two — the agent
showing the preview to the user and waiting for « OK envoie » — is the
human-in-the-loop. No special chat infrastructure is needed; the LLM
prompt makes the convention explicit (see ``send_draft`` docstring).

This is **safer than a single ``send_mail``** : even if the LLM
decided on its own to write, it would still need a separate tool call
with an explicit draft_id, and the user can see the draft preview
in their inbox (Microsoft saves drafts to the user's Drafts folder)
**before** the send happens.

**Errors-as-data** : every tool returns a dict. Failures populate
``error_code`` + ``error`` so the LLM can branch and respond
gracefully without the agent loop crashing.

**Permission gating** : every tool checks the per-scope toggle on
entry. Read tools require ``outlook.read``, writes require
``outlook.write``. Phase 3 wires the toggle storage; until then
``ensure_permission`` always returns False and the tool returns
``M365_PERMISSION_DISABLED``.

Graph endpoints used (v1.0)
---------------------------

  - ``GET /me/messages``                       search + filter
  - ``GET /me/messages/{id}``                  read one
  - ``GET /me/mailFolders/inbox/messages``     list inbox
  - ``POST /me/messages``                      create a draft
  - ``POST /me/messages/{id}/send``            send a draft
"""

from __future__ import annotations

import logging
import re
from typing import Any

from piilot.sdk import Context
from langchain_core.tools import StructuredTool

from piilot.sdk.tools import bind_session, register_tool

from ..client import (
    GraphAPIClient,
    GraphAuthError,
    GraphError,
    GraphNotFoundError,
    GraphPermissionError,
    GraphRateLimitedError,
)
from ._auth import (
    ensure_permission,
    not_connected_error,
    permission_denied_error,
    resolve_access_token,
)

logger = logging.getLogger(__name__)


# Single client instance — reuses the keep-alive connection across calls.
_client: GraphAPIClient | None = None


def _get_client() -> GraphAPIClient:
    global _client
    if _client is None:
        _client = GraphAPIClient()
    return _client


# How many messages to return at most. Caps prevent the LLM from
# triggering a 50-message dump that wouldn't fit in its context window.
_MAX_LIMIT = 25
_DEFAULT_LIMIT = 10

# Email regex used to validate ``to`` / ``cc`` recipients before we
# build the Graph payload. Defensive — the Graph API would reject bad
# values too, but we get a clearer error message by validating early.
_EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")


# ---------------------------------------------------------------------------
# Helpers — shape Graph payloads into LLM-friendly dicts
# ---------------------------------------------------------------------------


def _summarise_message(msg: dict) -> dict:
    """Compact a Graph ``Message`` object into the fields the LLM cares about.

    Trims ``bodyPreview`` to 500 chars and drops the full ``body`` field
    in summary views — the LLM uses ``read_mail(id)`` when it needs the
    full body. This keeps the search/list responses small.
    """
    sender = (msg.get("from") or {}).get("emailAddress") or {}
    to_recipients = msg.get("toRecipients") or []
    return {
        "id": msg.get("id"),
        "subject": msg.get("subject") or "",
        "from_name": sender.get("name", ""),
        "from_email": sender.get("address", ""),
        "to_emails": [
            (r.get("emailAddress") or {}).get("address", "") for r in to_recipients
        ],
        "received_at": msg.get("receivedDateTime"),
        "is_read": bool(msg.get("isRead", True)),
        "has_attachments": bool(msg.get("hasAttachments", False)),
        "preview": (msg.get("bodyPreview") or "")[:500],
    }


def _full_message(msg: dict) -> dict:
    """Expand a Graph ``Message`` into the full payload — used by ``read_mail``."""
    base = _summarise_message(msg)
    body = msg.get("body") or {}
    base["body_content"] = body.get("content", "")
    base["body_content_type"] = body.get("contentType", "html")  # html | text
    base["cc_emails"] = [
        (r.get("emailAddress") or {}).get("address", "")
        for r in (msg.get("ccRecipients") or [])
    ]
    return base


def _validate_recipients(emails: list[str], field: str) -> tuple[bool, str | None]:
    """Refuse obviously-malformed addresses upfront. Returns ``(ok, error)``."""
    for addr in emails:
        if not _EMAIL_RE.match(addr or ""):
            return False, f"{field}: adresse invalide '{addr}'"
    return True, None


def _company_id_from_state(state) -> str | None:
    """Best-effort extraction of company_id from the agent session state."""
    try:
        infos = getattr(state, "user_infos", None) or {}
        return infos.get("_organization_id") or infos.get("company_id")
    except Exception:  # noqa: BLE001 — defensive
        return None


def _get_session_state(session_id: str):
    """Resolve the active agent session, or return ``None`` quietly."""
    try:
        from piilot.sdk.session import get as _session_get

        return _session_get(session_id)
    except Exception:  # noqa: BLE001
        return None


def _map_graph_error(exc: GraphError, action: str) -> dict:
    """Turn a typed Graph exception into the errors-as-data envelope."""
    if isinstance(exc, GraphAuthError):
        return {
            "error_code": "M365_TOKEN_EXPIRED",
            "error": "Le token Microsoft a expiré ou été révoqué. La company doit reconnecter Microsoft 365.",
        }
    if isinstance(exc, GraphPermissionError):
        return {
            "error_code": "M365_GRAPH_PERMISSION",
            "error": (
                f"Microsoft refuse l'accès pour cette action ({action}). "
                "Vérifiez que l'admin tenant a validé l'app Piilot et "
                "que l'utilisateur a les droits requis."
            ),
            "graph_error_code": (exc.response_body or {}).get("error", {}).get("code"),
        }
    if isinstance(exc, GraphNotFoundError):
        return {
            "error_code": "M365_NOT_FOUND",
            "error": f"Ressource introuvable ({action}).",
        }
    if isinstance(exc, GraphRateLimitedError):
        return {
            "error_code": "M365_RATE_LIMITED",
            "error": "Microsoft Graph limite les requêtes — réessayez dans quelques secondes.",
            "retry_after": exc.retry_after,
        }
    return {
        "error_code": "M365_GRAPH_ERROR",
        "error": f"Erreur Microsoft Graph ({action}).",
        "status_code": exc.status_code,
    }


# ---------------------------------------------------------------------------
# READ tools
# ---------------------------------------------------------------------------


@bind_session
async def search_mail_fn(
    query: str,
    limit: int = _DEFAULT_LIMIT,
    *,
    session_id: str,
) -> dict[str, Any]:
    """Recherche dans la messagerie Outlook de l'utilisateur connecté.

    Args (LLM-facing):
        query: Termes recherchés (ex: 'facture acme', 'urgent').
        limit: Nombre max de résultats (cap à 25).

    Returns:
        ``{"items": [{summary}, ...], "count": N}`` ou ``{"error": ...}``.

    Le ``$search`` Graph utilise du KQL : 'subject:Acme', 'from:alice@x.com',
    'received>=2024-01-01' sont supportés. Pour de la recherche libre,
    passer juste les mots-clés.
    """
    state = _get_session_state(session_id)
    if not state:
        return {"error_code": "SESSION_NOT_FOUND", "error": "Session introuvable."}
    company_id = _company_id_from_state(state)
    if not company_id:
        return {
            "error_code": "NO_COMPANY",
            "error": "Pas de company sur cette session.",
        }

    if not await ensure_permission(company_id, "outlook.read"):
        return permission_denied_error("outlook.read")

    token = await resolve_access_token(company_id)
    if not token:
        return not_connected_error()

    cleaned_query = (query or "").strip()
    if not cleaned_query:
        return {
            "error_code": "EMPTY_QUERY",
            "error": "Le paramètre 'query' est requis.",
        }

    capped = max(1, min(limit, _MAX_LIMIT))
    client = _get_client()
    try:
        body = await client.get(
            "me/messages",
            access_token=token,
            params={"$search": f'"{cleaned_query}"', "$top": capped},
        )
    except GraphError as exc:
        logger.info("search_mail: graph error %s", exc)
        return _map_graph_error(exc, action="search_mail")

    items = [_summarise_message(m) for m in (body.get("value") or [])]
    return {"items": items, "count": len(items)}


@bind_session
async def read_mail_fn(message_id: str, *, session_id: str) -> dict[str, Any]:
    """Lit l'intégralité d'un email à partir de son ``id`` (renvoyé par
    ``search_mail`` ou ``list_inbox``)."""
    state = _get_session_state(session_id)
    if not state:
        return {"error_code": "SESSION_NOT_FOUND", "error": "Session introuvable."}
    company_id = _company_id_from_state(state)
    if not company_id:
        return {
            "error_code": "NO_COMPANY",
            "error": "Pas de company sur cette session.",
        }

    if not await ensure_permission(company_id, "outlook.read"):
        return permission_denied_error("outlook.read")

    token = await resolve_access_token(company_id)
    if not token:
        return not_connected_error()

    if not (message_id or "").strip():
        return {
            "error_code": "EMPTY_ID",
            "error": "Le paramètre 'message_id' est requis.",
        }

    client = _get_client()
    try:
        msg = await client.get(
            f"me/messages/{message_id}",
            access_token=token,
        )
    except GraphError as exc:
        return _map_graph_error(exc, action="read_mail")

    return _full_message(msg)


@bind_session
async def list_inbox_fn(
    limit: int = _DEFAULT_LIMIT,
    skip: int = 0,
    *,
    session_id: str,
) -> dict[str, Any]:
    """Liste les emails reçus dans la boîte de réception, plus récents
    en premier."""
    state = _get_session_state(session_id)
    if not state:
        return {"error_code": "SESSION_NOT_FOUND", "error": "Session introuvable."}
    company_id = _company_id_from_state(state)
    if not company_id:
        return {
            "error_code": "NO_COMPANY",
            "error": "Pas de company sur cette session.",
        }

    if not await ensure_permission(company_id, "outlook.read"):
        return permission_denied_error("outlook.read")

    token = await resolve_access_token(company_id)
    if not token:
        return not_connected_error()

    capped = max(1, min(limit, _MAX_LIMIT))
    skip_safe = max(0, int(skip))

    client = _get_client()
    try:
        body = await client.get(
            "me/mailFolders/inbox/messages",
            access_token=token,
            params={
                "$top": capped,
                "$skip": skip_safe,
                "$orderby": "receivedDateTime desc",
            },
        )
    except GraphError as exc:
        return _map_graph_error(exc, action="list_inbox")

    items = [_summarise_message(m) for m in (body.get("value") or [])]
    return {"items": items, "count": len(items), "skip": skip_safe}


# ---------------------------------------------------------------------------
# WRITE tools — 2-step pattern (create_draft → send_draft)
# ---------------------------------------------------------------------------


@bind_session
async def create_draft_fn(
    to: list[str],
    subject: str,
    body: str,
    cc: list[str] | None = None,
    *,
    session_id: str,
) -> dict[str, Any]:
    """Crée un brouillon Outlook (Drafts folder) **sans l'envoyer**.

    L'envoi nécessite un appel séparé à ``send_draft(draft_id)`` après
    confirmation explicite de l'utilisateur. C'est l'étape de validation
    Human-in-the-loop : le brouillon apparaît dans le dossier Brouillons
    de l'utilisateur immédiatement, l'agent montre un aperçu, et seul
    un OK utilisateur déclenche l'envoi.

    Args (LLM-facing):
        to: Liste d'adresses destinataires.
        subject: Sujet de l'email.
        body: Corps de l'email (texte ou HTML).
        cc: Liste d'adresses en copie (optionnel).

    Returns:
        ``{"draft_id": "...", "preview": {...}}`` ou ``{"error": ...}``.
    """
    state = _get_session_state(session_id)
    if not state:
        return {"error_code": "SESSION_NOT_FOUND", "error": "Session introuvable."}
    company_id = _company_id_from_state(state)
    if not company_id:
        return {
            "error_code": "NO_COMPANY",
            "error": "Pas de company sur cette session.",
        }

    if not await ensure_permission(company_id, "outlook.write"):
        return permission_denied_error("outlook.write")

    token = await resolve_access_token(company_id)
    if not token:
        return not_connected_error()

    # Validation stricte côté plugin avant d'appeler Graph — on évite
    # qu'un LLM hallucinant déclenche un 400 obscur côté Microsoft.
    to_list = [a for a in (to or []) if a]
    cc_list = [a for a in (cc or []) if a]
    if not to_list:
        return {
            "error_code": "MISSING_RECIPIENT",
            "error": "Au moins un destinataire est requis.",
        }
    if not (subject or "").strip():
        return {"error_code": "MISSING_SUBJECT", "error": "Le sujet est requis."}
    if not (body or "").strip():
        return {
            "error_code": "MISSING_BODY",
            "error": "Le corps de l'email est requis.",
        }

    ok, err = _validate_recipients(to_list, "to")
    if not ok:
        return {"error_code": "INVALID_RECIPIENT", "error": err}
    if cc_list:
        ok, err = _validate_recipients(cc_list, "cc")
        if not ok:
            return {"error_code": "INVALID_RECIPIENT", "error": err}

    payload = {
        "subject": subject,
        "body": {"contentType": "Text", "content": body},
        "toRecipients": [{"emailAddress": {"address": addr}} for addr in to_list],
    }
    if cc_list:
        payload["ccRecipients"] = [
            {"emailAddress": {"address": addr}} for addr in cc_list
        ]

    client = _get_client()
    try:
        draft = await client.request(
            "POST",
            "me/messages",
            access_token=token,
            json=payload,
        )
    except GraphError as exc:
        return _map_graph_error(exc, action="create_draft")

    return {
        "draft_id": draft.get("id"),
        "preview": _summarise_message(draft),
        "next_step": (
            "Le brouillon est dans le dossier Brouillons de l'utilisateur. "
            "Demandez explicitement la confirmation, puis appelez "
            "send_draft(draft_id) pour envoyer."
        ),
    }


@bind_session
async def send_draft_fn(draft_id: str, *, session_id: str) -> dict[str, Any]:
    """Envoie un brouillon précédemment créé via ``create_draft``.

    À appeler **uniquement après confirmation explicite de l'utilisateur**.
    L'agent doit présenter le ``preview`` retourné par ``create_draft``
    et attendre un « OK envoie » ou équivalent avant ce call.

    Args (LLM-facing):
        draft_id: Identifiant du brouillon créé par ``create_draft``.

    Returns:
        ``{"sent": True, "draft_id": "..."}`` ou ``{"error": ...}``.
    """
    state = _get_session_state(session_id)
    if not state:
        return {"error_code": "SESSION_NOT_FOUND", "error": "Session introuvable."}
    company_id = _company_id_from_state(state)
    if not company_id:
        return {
            "error_code": "NO_COMPANY",
            "error": "Pas de company sur cette session.",
        }

    if not await ensure_permission(company_id, "outlook.write"):
        return permission_denied_error("outlook.write")

    token = await resolve_access_token(company_id)
    if not token:
        return not_connected_error()

    if not (draft_id or "").strip():
        return {"error_code": "EMPTY_DRAFT_ID", "error": "Le 'draft_id' est requis."}

    client = _get_client()
    try:
        await client.request(
            "POST",
            f"me/messages/{draft_id}/send",
            access_token=token,
        )
    except GraphError as exc:
        return _map_graph_error(exc, action="send_draft")

    return {"sent": True, "draft_id": draft_id}


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


def register_tools(ctx: Context) -> None:
    """Register the 5 Outlook tools with the SDK."""
    register_tool(
        {
            "id": "microsoft_365.outlook.search_mail",
            "tool": StructuredTool.from_function(
                search_mail_fn,
                name="microsoft_365_outlook_search_mail",
                description="Recherche dans la messagerie Outlook (KQL — sujet, expéditeur, mots-clés). Cap 25 résultats.",
            ),
        }
    )
    register_tool(
        {
            "id": "microsoft_365.outlook.read_mail",
            "tool": StructuredTool.from_function(
                read_mail_fn,
                name="microsoft_365_outlook_read_mail",
                description="Lit l'intégralité d'un email Outlook à partir de son id.",
            ),
        }
    )
    register_tool(
        {
            "id": "microsoft_365.outlook.list_inbox",
            "tool": StructuredTool.from_function(
                list_inbox_fn,
                name="microsoft_365_outlook_list_inbox",
                description="Liste les emails de la boîte de réception, plus récents en premier.",
            ),
        }
    )
    register_tool(
        {
            "id": "microsoft_365.outlook.create_draft",
            "tool": StructuredTool.from_function(
                create_draft_fn,
                name="microsoft_365_outlook_create_draft",
                description=(
                    "Crée un brouillon dans le dossier Brouillons d'Outlook — "
                    "ne l'envoie PAS. Pour envoyer, appeler send_draft(draft_id) "
                    "après confirmation utilisateur."
                ),
            ),
        }
    )
    register_tool(
        {
            "id": "microsoft_365.outlook.send_draft",
            "tool": StructuredTool.from_function(
                send_draft_fn,
                name="microsoft_365_outlook_send_draft",
                description=(
                    "Envoie un brouillon précédemment créé. À appeler UNIQUEMENT "
                    "après confirmation explicite de l'utilisateur. Aucune écriture "
                    "silencieuse — l'agent doit demander 'envoyer ?' avant."
                ),
            ),
        }
    )
