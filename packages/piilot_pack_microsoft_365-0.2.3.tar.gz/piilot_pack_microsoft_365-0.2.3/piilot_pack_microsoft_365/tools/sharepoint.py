"""Agent tools for SharePoint — list sites + browse/download/upload site files.

Design notes
------------

SharePoint sits on top of OneDrive's underlying drive engine, so the
endpoint shape is very close to ``onedrive.py`` — the difference is
that every operation is rooted at ``/sites/{site-id}/drive/...`` rather
than ``/me/drive/...``.

The 2-step intent pattern from OneDrive is reused for uploads. Intents
are stored in a **separate session bucket** (``_m365_sharepoint_upload_intents``)
so an admin who does both a OneDrive upload and a SharePoint upload in
the same session won't see them collide. Same TTL (5 min), same
fail-closed behaviour, same consume-on-success-or-failure.

**Admin consent required**. The Graph scopes
``Sites.Read.All`` / ``Sites.ReadWrite.All`` always need admin
consent — there is no user-only delegated alternative for cross-site
listing. The plugin's Phase 2 OAuth flow surfaces this requirement;
without admin consent these tools return ``M365_GRAPH_PERMISSION``
with a hint to ask the tenant admin.

Graph endpoints used (v1.0)
---------------------------

  - ``GET  /sites?search={q}``                                  search sites
  - ``GET  /sites/{site-id}/drive/root/children``               list root
  - ``GET  /sites/{site-id}/drive/items/{folder}/children``     list folder
  - ``GET  /sites/{site-id}/drive/items/{file-id}``             file metadata
  - ``PUT  /sites/{site-id}/drive/root:/{name}:/content``       upload root
  - ``PUT  /sites/{site-id}/drive/items/{folder}:/{name}:/content`` upload folder
"""

from __future__ import annotations

import logging
import re
import time
import uuid
from typing import Any

from piilot.sdk import Context
from langchain_core.tools import StructuredTool

from piilot.sdk.tools import bind_session, register_tool

from ..client import (
    GraphAPIClient,
    GraphAuthError,
    GraphError,
    GraphNotFoundError,
    GraphPermissionError,
    GraphRateLimitedError,
)
from ._auth import (
    ensure_permission,
    not_connected_error,
    permission_denied_error,
    resolve_access_token,
)

logger = logging.getLogger(__name__)


_client: GraphAPIClient | None = None


def _get_client() -> GraphAPIClient:
    global _client
    if _client is None:
        _client = GraphAPIClient()
    return _client


_MAX_UPLOAD_BYTES = 4 * 1024 * 1024
_MAX_LIMIT = 25
_DEFAULT_LIMIT = 10
_INTENT_TTL_SECONDS = 300

_FORBIDDEN_NAME_CHARS = re.compile(r'[\\/:*?"<>|]')
_MAX_FILENAME_LEN = 255

# Distinct from OneDrive's bucket so an admin running both flows in
# the same agent session doesn't accidentally cross-confirm.
_INTENT_KEY = "_m365_sharepoint_upload_intents"

# SharePoint site IDs are tuples ``hostname,site-collection-guid,site-guid``.
# Cap their length to avoid path injection if the LLM somehow forges
# a malformed value — Graph would reject it but a clear error is nicer.
_VALID_SITE_ID_RE = re.compile(r"^[A-Za-z0-9_,\.\-]{1,200}$")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _summarise_site(site: dict) -> dict:
    return {
        "id": site.get("id"),
        "name": site.get("displayName") or site.get("name") or "",
        "description": (site.get("description") or "")[:200],
        "web_url": site.get("webUrl"),
        "created_at": site.get("createdDateTime"),
    }


def _summarise_drive_item(item: dict) -> dict:
    parent = item.get("parentReference") or {}
    return {
        "id": item.get("id"),
        "name": item.get("name") or "",
        "kind": "folder" if item.get("folder") else "file",
        "size_bytes": item.get("size", 0),
        "modified_at": item.get("lastModifiedDateTime"),
        "mime_type": (item.get("file") or {}).get("mimeType"),
        "parent_path": parent.get("path") or "",
        "web_url": item.get("webUrl"),
    }


def _company_id_from_state(state) -> str | None:
    try:
        infos = getattr(state, "user_infos", None) or {}
        return infos.get("_organization_id") or infos.get("company_id")
    except Exception:  # noqa: BLE001
        return None


def _get_session_state(session_id: str):
    try:
        from piilot.sdk.session import get as _session_get

        return _session_get(session_id)
    except Exception:  # noqa: BLE001
        return None


def _map_graph_error(exc: GraphError, action: str) -> dict:
    if isinstance(exc, GraphAuthError):
        return {
            "error_code": "M365_TOKEN_EXPIRED",
            "error": "Le token Microsoft a expiré ou été révoqué. La company doit reconnecter Microsoft 365.",
        }
    if isinstance(exc, GraphPermissionError):
        return {
            "error_code": "M365_GRAPH_PERMISSION",
            "error": (
                f"Microsoft refuse l'accès SharePoint pour cette action ({action}). "
                "Vérifiez que l'admin tenant a validé l'app Piilot avec les "
                "scopes Sites.Read.All / Sites.ReadWrite.All."
            ),
            "graph_error_code": (exc.response_body or {}).get("error", {}).get("code"),
        }
    if isinstance(exc, GraphNotFoundError):
        return {
            "error_code": "M365_NOT_FOUND",
            "error": f"Ressource introuvable ({action}).",
        }
    if isinstance(exc, GraphRateLimitedError):
        return {
            "error_code": "M365_RATE_LIMITED",
            "error": "Microsoft Graph limite les requêtes — réessayez dans quelques secondes.",
            "retry_after": exc.retry_after,
        }
    return {
        "error_code": "M365_GRAPH_ERROR",
        "error": f"Erreur Microsoft Graph ({action}).",
        "status_code": exc.status_code,
    }


def _validate_site_id(site_id: str) -> tuple[bool, str | None]:
    if not (site_id or "").strip():
        return False, "Le 'site_id' est requis."
    if not _VALID_SITE_ID_RE.match(site_id):
        return False, "Format de 'site_id' invalide."
    return True, None


def _validate_filename(name: str) -> tuple[bool, str | None]:
    if not name:
        return False, "Le nom du fichier est requis."
    if len(name) > _MAX_FILENAME_LEN:
        return False, f"Nom de fichier trop long (>{_MAX_FILENAME_LEN} caractères)."
    if name.startswith(".") or name.startswith(" ") or name.endswith(" "):
        return (
            False,
            "Le nom ne peut pas commencer par un point ou un espace, ni se terminer par un espace.",
        )
    if _FORBIDDEN_NAME_CHARS.search(name):
        return (
            False,
            'Le nom contient un caractère interdit par SharePoint : \\ / : * ? " < > |',
        )
    return True, None


# ---------------------------------------------------------------------------
# Intent storage (parallel to OneDrive's, distinct bucket)
# ---------------------------------------------------------------------------


def _get_intents_dict(state) -> dict[str, dict]:
    infos = getattr(state, "user_infos", None)
    if infos is None:
        return {}
    intents = infos.get(_INTENT_KEY)
    if intents is None:
        intents = {}
        infos[_INTENT_KEY] = intents
    return intents


def _purge_expired_intents(intents: dict[str, dict]) -> None:
    now = time.monotonic()
    expired = [
        i
        for i, p in intents.items()
        if now - p.get("created_at", 0) > _INTENT_TTL_SECONDS
    ]
    for i in expired:
        intents.pop(i, None)


# ---------------------------------------------------------------------------
# READ tools
# ---------------------------------------------------------------------------


@bind_session
async def list_sites_fn(
    query: str = "",
    limit: int = _DEFAULT_LIMIT,
    *,
    session_id: str,
) -> dict[str, Any]:
    """Liste les sites SharePoint accessibles à l'utilisateur connecté.

    Args (LLM-facing):
        query: Filtre optionnel sur le nom du site (laissez vide pour
               obtenir les sites par défaut).
        limit: Nombre max de résultats (cap à 25).
    """
    state = _get_session_state(session_id)
    if not state:
        return {"error_code": "SESSION_NOT_FOUND", "error": "Session introuvable."}
    company_id = _company_id_from_state(state)
    if not company_id:
        return {
            "error_code": "NO_COMPANY",
            "error": "Pas de company sur cette session.",
        }

    if not await ensure_permission(company_id, "sharepoint.read"):
        return permission_denied_error("sharepoint.read")
    token = await resolve_access_token(company_id)
    if not token:
        return not_connected_error()

    capped = max(1, min(limit, _MAX_LIMIT))
    cleaned = (query or "").strip()
    # ``search`` is required by Graph for /sites; '*' returns the
    # sites the user follows or explicitly has access to.
    search_q = cleaned or "*"

    client = _get_client()
    try:
        body = await client.get(
            "sites",
            access_token=token,
            params={"search": search_q, "$top": capped},
        )
    except GraphError as exc:
        return _map_graph_error(exc, action="list_sites")

    items = [_summarise_site(s) for s in (body.get("value") or [])]
    return {"items": items, "count": len(items)}


@bind_session
async def list_site_files_fn(
    site_id: str,
    folder_id: str | None = None,
    limit: int = _DEFAULT_LIMIT,
    skip: int = 0,
    *,
    session_id: str,
) -> dict[str, Any]:
    """Liste les fichiers et dossiers d'un site SharePoint.

    Args (LLM-facing):
        site_id: Identifiant du site (renvoyé par list_sites).
        folder_id: Identifiant du dossier (omettre pour la racine).
        limit: Nombre max d'éléments (cap à 25).
        skip: Pagination (offset, >=0).
    """
    state = _get_session_state(session_id)
    if not state:
        return {"error_code": "SESSION_NOT_FOUND", "error": "Session introuvable."}
    company_id = _company_id_from_state(state)
    if not company_id:
        return {
            "error_code": "NO_COMPANY",
            "error": "Pas de company sur cette session.",
        }

    if not await ensure_permission(company_id, "sharepoint.read"):
        return permission_denied_error("sharepoint.read")
    token = await resolve_access_token(company_id)
    if not token:
        return not_connected_error()

    site_ok, err = _validate_site_id(site_id)
    if not site_ok:
        return {"error_code": "INVALID_SITE_ID", "error": err}

    capped = max(1, min(limit, _MAX_LIMIT))
    skip_safe = max(0, int(skip))

    path = (
        f"sites/{site_id}/drive/root/children"
        if not (folder_id or "").strip()
        else f"sites/{site_id}/drive/items/{folder_id}/children"
    )

    client = _get_client()
    try:
        body = await client.get(
            path,
            access_token=token,
            params={"$top": capped, "$skip": skip_safe},
        )
    except GraphError as exc:
        return _map_graph_error(exc, action="list_site_files")

    items = [_summarise_drive_item(it) for it in (body.get("value") or [])]
    return {"items": items, "count": len(items), "skip": skip_safe}


@bind_session
async def download_site_file_fn(
    site_id: str,
    file_id: str,
    *,
    session_id: str,
) -> dict[str, Any]:
    """Renvoie les métadonnées d'un fichier SharePoint + une URL signée
    temporaire à présenter à l'utilisateur."""
    state = _get_session_state(session_id)
    if not state:
        return {"error_code": "SESSION_NOT_FOUND", "error": "Session introuvable."}
    company_id = _company_id_from_state(state)
    if not company_id:
        return {
            "error_code": "NO_COMPANY",
            "error": "Pas de company sur cette session.",
        }

    if not await ensure_permission(company_id, "sharepoint.read"):
        return permission_denied_error("sharepoint.read")
    token = await resolve_access_token(company_id)
    if not token:
        return not_connected_error()

    site_ok, err = _validate_site_id(site_id)
    if not site_ok:
        return {"error_code": "INVALID_SITE_ID", "error": err}
    if not (file_id or "").strip():
        return {"error_code": "EMPTY_FILE_ID", "error": "Le 'file_id' est requis."}

    client = _get_client()
    try:
        body = await client.get(
            f"sites/{site_id}/drive/items/{file_id}",
            access_token=token,
            params={
                "$select": (
                    "id,name,size,file,folder,parentReference,"
                    "lastModifiedDateTime,webUrl,@microsoft.graph.downloadUrl"
                ),
            },
        )
    except GraphError as exc:
        return _map_graph_error(exc, action="download_site_file")

    if body.get("folder"):
        return {
            "error_code": "IS_FOLDER",
            "error": "L'identifiant pointe vers un dossier, pas un fichier.",
        }

    return {
        "file": _summarise_drive_item(body),
        "download_url": body.get("@microsoft.graph.downloadUrl"),
    }


# ---------------------------------------------------------------------------
# WRITE tools — same 2-step intent pattern as OneDrive
# ---------------------------------------------------------------------------


@bind_session
async def prepare_site_upload_fn(
    site_id: str,
    file_name: str,
    content: str,
    parent_folder_id: str | None = None,
    *,
    session_id: str,
) -> dict[str, Any]:
    """Stage un upload SharePoint **sans le réaliser**.

    Crée une intention d'upload bornée à la session de l'agent (TTL
    5 minutes). L'upload réel n'a lieu qu'après ``confirm_site_upload``
    avec l'``upload_intent_id`` retourné.

    Args (LLM-facing):
        site_id: Identifiant du site SharePoint cible.
        file_name: Nom du fichier (extension incluse).
        content: Contenu textuel UTF-8 (binaire en v0.2).
        parent_folder_id: Dossier parent (omettre pour la racine).
    """
    state = _get_session_state(session_id)
    if not state:
        return {"error_code": "SESSION_NOT_FOUND", "error": "Session introuvable."}
    company_id = _company_id_from_state(state)
    if not company_id:
        return {
            "error_code": "NO_COMPANY",
            "error": "Pas de company sur cette session.",
        }

    if not await ensure_permission(company_id, "sharepoint.write"):
        return permission_denied_error("sharepoint.write")
    token = await resolve_access_token(company_id)
    if not token:
        return not_connected_error()

    site_ok, err = _validate_site_id(site_id)
    if not site_ok:
        return {"error_code": "INVALID_SITE_ID", "error": err}

    name_ok, err = _validate_filename(file_name or "")
    if not name_ok:
        return {"error_code": "INVALID_FILENAME", "error": err}

    if not isinstance(content, str):
        return {
            "error_code": "INVALID_CONTENT",
            "error": "Le contenu doit être du texte (str). v0.2 ajoutera le binaire.",
        }
    payload_bytes = content.encode("utf-8")
    size = len(payload_bytes)
    if size == 0:
        return {"error_code": "EMPTY_CONTENT", "error": "Le contenu est vide."}
    if size > _MAX_UPLOAD_BYTES:
        return {
            "error_code": "FILE_TOO_LARGE",
            "error": f"Fichier trop volumineux pour un upload simple (>{_MAX_UPLOAD_BYTES} octets).",
            "size_bytes": size,
            "max_bytes": _MAX_UPLOAD_BYTES,
        }

    intents = _get_intents_dict(state)
    _purge_expired_intents(intents)
    intent_id = uuid.uuid4().hex
    intents[intent_id] = {
        "site_id": site_id,
        "file_name": file_name,
        "parent_folder_id": parent_folder_id or "",
        "content": payload_bytes,
        "size_bytes": size,
        "created_at": time.monotonic(),
    }

    return {
        "upload_intent_id": intent_id,
        "preview": {
            "site_id": site_id,
            "file_name": file_name,
            "size_bytes": size,
            "parent_folder_id": parent_folder_id or "(racine du site)",
            "expires_in_seconds": _INTENT_TTL_SECONDS,
        },
        "next_step": (
            "Présentez ce résumé à l'utilisateur. Demandez explicitement "
            "la confirmation, puis appelez confirm_site_upload(upload_intent_id) "
            "pour effectuer l'upload."
        ),
    }


@bind_session
async def confirm_site_upload_fn(
    upload_intent_id: str,
    *,
    session_id: str,
) -> dict[str, Any]:
    """Effectue l'upload SharePoint sur la base d'une intention créée
    par ``prepare_site_upload``. À appeler **uniquement après
    confirmation explicite de l'utilisateur**."""
    state = _get_session_state(session_id)
    if not state:
        return {"error_code": "SESSION_NOT_FOUND", "error": "Session introuvable."}
    company_id = _company_id_from_state(state)
    if not company_id:
        return {
            "error_code": "NO_COMPANY",
            "error": "Pas de company sur cette session.",
        }

    if not await ensure_permission(company_id, "sharepoint.write"):
        return permission_denied_error("sharepoint.write")
    token = await resolve_access_token(company_id)
    if not token:
        return not_connected_error()

    if not (upload_intent_id or "").strip():
        return {
            "error_code": "EMPTY_INTENT_ID",
            "error": "Le 'upload_intent_id' est requis.",
        }

    intents = _get_intents_dict(state)
    _purge_expired_intents(intents)
    intent = intents.get(upload_intent_id)
    if not intent:
        return {
            "error_code": "INTENT_NOT_FOUND",
            "error": (
                "L'intention d'upload est introuvable ou a expiré. "
                f"Les intentions expirent au bout de {_INTENT_TTL_SECONDS}s. "
                "Recommencez avec prepare_site_upload."
            ),
        }

    site_id = intent["site_id"]
    file_name = intent["file_name"]
    parent_id = intent["parent_folder_id"]
    payload = intent["content"]

    intents.pop(upload_intent_id, None)

    path = (
        f"sites/{site_id}/drive/root:/{file_name}:/content"
        if not parent_id
        else f"sites/{site_id}/drive/items/{parent_id}:/{file_name}:/content"
    )

    client = _get_client()
    try:
        url = f"{client._base_url}/{path}"
        resp = await client._http.put(
            url,
            content=payload,
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/octet-stream",
            },
        )
    except Exception as exc:  # noqa: BLE001
        logger.warning("confirm_site_upload: transport error %s", exc)
        return {
            "error_code": "M365_GRAPH_ERROR",
            "error": "Erreur de transport vers Microsoft Graph.",
        }

    if resp.status_code in (200, 201):
        try:
            body = resp.json()
        except ValueError:
            return {
                "error_code": "M365_GRAPH_ERROR",
                "error": "Réponse Graph invalide.",
            }
        return {"uploaded": True, "file": _summarise_drive_item(body)}

    if resp.status_code == 401:
        return {
            "error_code": "M365_TOKEN_EXPIRED",
            "error": "Le token Microsoft a expiré ou été révoqué.",
        }
    if resp.status_code == 403:
        return {
            "error_code": "M365_GRAPH_PERMISSION",
            "error": "Microsoft refuse l'upload (admin consent SharePoint requis).",
        }
    if resp.status_code == 404:
        return {
            "error_code": "M365_NOT_FOUND",
            "error": "Site ou dossier parent introuvable.",
        }
    if resp.status_code == 429:
        return {
            "error_code": "M365_RATE_LIMITED",
            "error": "Microsoft Graph limite les requêtes.",
        }
    return {
        "error_code": "M365_GRAPH_ERROR",
        "error": "Upload SharePoint en échec.",
        "status_code": resp.status_code,
    }


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


def register_tools(ctx: Context) -> None:
    register_tool(
        {
            "id": "microsoft_365.sharepoint.list_sites",
            "tool": StructuredTool.from_function(
                list_sites_fn,
                name="microsoft_365_sharepoint_list_sites",
                description="Liste les sites SharePoint accessibles, avec un filtre optionnel sur le nom.",
            ),
        }
    )
    register_tool(
        {
            "id": "microsoft_365.sharepoint.list_site_files",
            "tool": StructuredTool.from_function(
                list_site_files_fn,
                name="microsoft_365_sharepoint_list_site_files",
                description="Liste les fichiers et dossiers d'un site SharePoint (racine si folder_id omis).",
            ),
        }
    )
    register_tool(
        {
            "id": "microsoft_365.sharepoint.download_site_file",
            "tool": StructuredTool.from_function(
                download_site_file_fn,
                name="microsoft_365_sharepoint_download_site_file",
                description=(
                    "Renvoie les métadonnées d'un fichier SharePoint + une URL "
                    "signée temporaire à présenter à l'utilisateur."
                ),
            ),
        }
    )
    register_tool(
        {
            "id": "microsoft_365.sharepoint.prepare_site_upload",
            "tool": StructuredTool.from_function(
                prepare_site_upload_fn,
                name="microsoft_365_sharepoint_prepare_site_upload",
                description=(
                    "Stage un upload SharePoint — ne l'envoie PAS. Retourne un "
                    "upload_intent_id à confirmer via confirm_site_upload après "
                    "validation utilisateur. v0.1 supporte uniquement le texte (<4 MB)."
                ),
            ),
        }
    )
    register_tool(
        {
            "id": "microsoft_365.sharepoint.confirm_site_upload",
            "tool": StructuredTool.from_function(
                confirm_site_upload_fn,
                name="microsoft_365_sharepoint_confirm_site_upload",
                description=(
                    "Effectue l'upload SharePoint associé à un upload_intent_id. "
                    "À appeler UNIQUEMENT après confirmation explicite de l'utilisateur."
                ),
            ),
        }
    )
