"""Per-company access-token resolution + permission gate for M365 tools.

This module is the bridge between the agent tools (which want a clean
``str | None`` for the token + a boolean for the permission) and the
storage layer in ``_db.py`` (which holds encrypted tokens + per-scope
toggles).

Phase 2 wired the real implementations:

  - ``resolve_access_token`` looks up the company's connection,
    refreshes the access token when it's near expiry (proactive
    refresh ~120 s before the documented TTL ends), and returns the
    decrypted token. Returns ``None`` when no connection exists or
    when refresh fails.
  - ``ensure_permission`` checks the per-scope toggle table —
    fail-closed: a missing row is treated as disabled.

Both helpers run on the hot path of every tool call. We use
``run_in_thread`` because the underlying SDK's ``cursor()`` is sync
and we don't want to block the event loop on a Postgres round-trip.
"""

from __future__ import annotations

import logging
from typing import Literal

from piilot.sdk.db import run_in_thread

from .. import _db
from .. import oauth

logger = logging.getLogger(__name__)


PermissionId = Literal[
    "outlook.read",
    "outlook.write",
    "onedrive.read",
    "onedrive.write",
    "sharepoint.read",
    "sharepoint.write",
    "teams.read",
    "teams.write",
]


# ---------------------------------------------------------------------------
# Hot-path resolvers (Phase 2 — real implementations)
# ---------------------------------------------------------------------------


async def resolve_access_token(company_id: str) -> str | None:
    """Return a valid Graph access token for ``company_id`` or ``None``.

    Refreshes proactively when the cached token is within 120 s of
    expiry. A refresh failure (revoked token, network error) returns
    ``None`` rather than raising — the tool layer surfaces this as
    ``M365_NOT_CONNECTED`` and the LLM can ask the user to re-connect.
    """
    try:
        connection = await run_in_thread(_db.get_connection, company_id)
    except Exception:
        logger.exception(
            "resolve_access_token: get_connection failed for %s", company_id
        )
        return None
    if not connection:
        return None

    if not _db.is_token_near_expiry(connection):
        # Best-effort touch — never blocks the call.
        try:
            await run_in_thread(_db.touch_last_used, company_id)
        except Exception:  # noqa: BLE001
            pass
        return connection.get("access_token")

    # Token is near expiry → refresh.
    refresh_token = connection.get("refresh_token")
    if not refresh_token:
        # Connection without a refresh token is unusable past the access
        # token's TTL — return None so the user is asked to re-connect.
        logger.info(
            "resolve_access_token: connection for %s has no refresh token, asking re-connect",
            company_id,
        )
        return None

    try:
        new_tokens = await oauth.refresh_tokens(refresh_token=refresh_token)
    except oauth.OAuthError as exc:
        logger.warning(
            "resolve_access_token: refresh failed for %s: %s",
            company_id,
            exc,
        )
        return None

    try:
        await run_in_thread(
            _db.update_tokens_after_refresh,
            company_id=company_id,
            access_token=new_tokens["access_token"],
            refresh_token=new_tokens.get("refresh_token"),
            expires_at=new_tokens["expires_at"],
        )
    except Exception:
        logger.exception(
            "resolve_access_token: persisting refreshed tokens failed for %s",
            company_id,
        )
        # The rotation succeeded with Microsoft though, so the new
        # access token is usable for at least one call. Return it
        # rather than failing the call.
    return new_tokens["access_token"]


async def ensure_permission(company_id: str, permission: PermissionId) -> bool:
    """True iff the company admin has enabled ``permission`` in Settings."""
    try:
        return await run_in_thread(_db.is_scope_enabled, company_id, permission)
    except Exception:
        logger.exception(
            "ensure_permission: lookup failed for %s/%s — fail-closed",
            company_id,
            permission,
        )
        return False


# ---------------------------------------------------------------------------
# Errors-as-data envelope used by every tool
# ---------------------------------------------------------------------------


def not_connected_error() -> dict:
    """Returned by tools when no M365 connection exists for the company.

    Shape kept stable so the LLM can branch on the ``error_code`` key.
    """
    return {
        "error_code": "M365_NOT_CONNECTED",
        "error": (
            "Microsoft 365 n'est pas connecté pour cette company. "
            "Allez dans Paramètres → Microsoft 365, cliquez sur "
            "« Connecter Microsoft 365 », puis cochez les permissions "
            "souhaitées."
        ),
    }


def permission_denied_error(permission: PermissionId) -> dict:
    """Returned when the toggle for this permission is OFF for the company."""
    return {
        "error_code": "M365_PERMISSION_DISABLED",
        "permission": permission,
        "error": (
            f"L'admin de cette company n'a pas active la permission '{permission}'. "
            "Demandez-lui de l'activer dans Paramètres → Microsoft 365."
        ),
    }
