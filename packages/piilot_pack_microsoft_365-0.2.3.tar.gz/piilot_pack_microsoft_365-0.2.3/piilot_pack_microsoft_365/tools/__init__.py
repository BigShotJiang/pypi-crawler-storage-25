"""Agent tools exposed by the M365 plugin.

Phase 1 ships a single ``whoami`` tool that validates the OAuth →
Graph round-trip. Phases 4-7 add the per-service tools (Outlook,
OneDrive, SharePoint, Teams) — 4 tools per service, the writes flowing
through HITL (PLT-28 pattern).
"""
