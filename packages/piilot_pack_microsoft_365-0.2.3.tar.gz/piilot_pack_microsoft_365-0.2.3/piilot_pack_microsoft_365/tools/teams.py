"""Agent tools for Microsoft Teams — chats, channels, send-with-confirmation.

Scope of v0.1
-------------

Teams in Graph has two distinct messaging surfaces :

  - **Chats** : 1:1 + group chats (DM equivalent). Reads only in v0.1
    — sending requires the more sensitive ``Chat.ReadWrite`` scope which
    we keep behind admin tenant consent before exposing as a write tool.
  - **Channels** : conversation threads inside a Team. Reads and writes
    both supported in v0.1, with the standard 2-step intent pattern
    for sends (``ChannelMessage.Send`` requires admin tenant consent).

This is **distinct from C14** (Teams Bot Framework) — that's a separate
chantier where Piilot becomes an installable Teams app via the bot
SDK. Here we only consume Microsoft Graph in delegated mode (the user
authenticated via OAuth acts as themselves).

Tools shipped (6) :

  read (gate ``teams.read``)
    - list_chats(limit)
    - read_chat_messages(chat_id, limit)
    - list_channels(team_id)
    - read_channel_messages(team_id, channel_id, limit)

  write (gate ``teams.write``)
    - prepare_channel_message(team_id, channel_id, content)
    - confirm_channel_message(send_intent_id)

A ``list_teams`` helper isn't strictly needed for v0.1 — the LLM
picks up team ids from prior turns or the user provides them
explicitly — but we ship it as a convenience read alongside
``list_channels`` so an agent without prior context can bootstrap.
That makes the read surface 5 tools, write surface 2 tools, total 7.

Graph endpoints used (v1.0)
---------------------------

  - ``GET  /me/joinedTeams``                                       (list_teams)
  - ``GET  /me/chats``                                             (list_chats)
  - ``GET  /chats/{chat-id}/messages``                             (read_chat_messages)
  - ``GET  /teams/{team-id}/channels``                             (list_channels)
  - ``GET  /teams/{team-id}/channels/{channel-id}/messages``        (read_channel_messages)
  - ``POST /teams/{team-id}/channels/{channel-id}/messages``        (confirm send)
"""

from __future__ import annotations

import logging
import re
import time
import uuid
from typing import Any

from piilot.sdk import Context
from langchain_core.tools import StructuredTool

from piilot.sdk.tools import bind_session, register_tool

from ..client import (
    GraphAPIClient,
    GraphAuthError,
    GraphError,
    GraphNotFoundError,
    GraphPermissionError,
    GraphRateLimitedError,
)
from ._auth import (
    ensure_permission,
    not_connected_error,
    permission_denied_error,
    resolve_access_token,
)

logger = logging.getLogger(__name__)


_client: GraphAPIClient | None = None


def _get_client() -> GraphAPIClient:
    global _client
    if _client is None:
        _client = GraphAPIClient()
    return _client


_MAX_LIMIT = 50  # Channel messages can come in long, allow up to 50
_DEFAULT_LIMIT = 20
_INTENT_TTL_SECONDS = 300

_INTENT_KEY = "_m365_teams_send_intents"

# Microsoft Graph IDs for teams/channels are GUIDs; chat ids contain
# extra characters. Use a permissive but bounded regex per resource type.
_VALID_GUID_LIKE_RE = re.compile(r"^[A-Za-z0-9_\-:.@=]{1,200}$")

# Cap message body length. Teams supports up to ~28 KB but anything
# more than ~10 KB is unusual for conversational use and is more
# likely an LLM mistake than legitimate content.
_MAX_MESSAGE_CHARS = 10_000


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _summarise_team(team: dict) -> dict:
    return {
        "id": team.get("id"),
        "name": team.get("displayName") or "",
        "description": (team.get("description") or "")[:200],
        "web_url": team.get("webUrl"),
        "visibility": team.get("visibility"),
    }


def _summarise_chat(chat: dict) -> dict:
    return {
        "id": chat.get("id"),
        "topic": chat.get("topic") or "",
        "chat_type": chat.get("chatType"),  # "oneOnOne" | "group" | "meeting"
        "last_updated": chat.get("lastUpdatedDateTime"),
        "web_url": chat.get("webUrl"),
    }


def _summarise_channel(ch: dict) -> dict:
    return {
        "id": ch.get("id"),
        "name": ch.get("displayName") or "",
        "description": (ch.get("description") or "")[:200],
        "membership": ch.get("membershipType"),  # "standard" | "private" | "shared"
        "web_url": ch.get("webUrl"),
    }


def _summarise_message(msg: dict) -> dict:
    sender = msg.get("from") or {}
    user = sender.get("user") or {}
    body = msg.get("body") or {}
    return {
        "id": msg.get("id"),
        "from_name": user.get("displayName", ""),
        "from_id": user.get("id"),
        "created_at": msg.get("createdDateTime"),
        "content_type": body.get("contentType", "html"),
        "content": (body.get("content") or "")[:2000],  # cap for LLM
        "web_url": msg.get("webUrl"),
        "reply_to_id": msg.get("replyToId"),
        "is_deleted": bool(msg.get("deletedDateTime")),
    }


def _company_id_from_state(state) -> str | None:
    try:
        infos = getattr(state, "user_infos", None) or {}
        return infos.get("_organization_id") or infos.get("company_id")
    except Exception:  # noqa: BLE001
        return None


def _get_session_state(session_id: str):
    try:
        from piilot.sdk.session import get as _session_get

        return _session_get(session_id)
    except Exception:  # noqa: BLE001
        return None


def _map_graph_error(exc: GraphError, action: str) -> dict:
    if isinstance(exc, GraphAuthError):
        return {
            "error_code": "M365_TOKEN_EXPIRED",
            "error": "Le token Microsoft a expiré ou été révoqué.",
        }
    if isinstance(exc, GraphPermissionError):
        return {
            "error_code": "M365_GRAPH_PERMISSION",
            "error": (
                f"Microsoft refuse l'accès Teams pour cette action ({action}). "
                "Vérifiez que l'admin tenant a validé l'app Piilot avec les "
                "scopes Chat.Read / ChannelMessage.* requis."
            ),
            "graph_error_code": (exc.response_body or {}).get("error", {}).get("code"),
        }
    if isinstance(exc, GraphNotFoundError):
        return {
            "error_code": "M365_NOT_FOUND",
            "error": f"Ressource introuvable ({action}).",
        }
    if isinstance(exc, GraphRateLimitedError):
        return {
            "error_code": "M365_RATE_LIMITED",
            "error": "Microsoft Graph limite les requêtes — réessayez dans quelques secondes.",
            "retry_after": exc.retry_after,
        }
    return {
        "error_code": "M365_GRAPH_ERROR",
        "error": f"Erreur Microsoft Graph ({action}).",
        "status_code": exc.status_code,
    }


def _validate_id(value: str, field_name: str) -> tuple[bool, str | None]:
    if not (value or "").strip():
        return False, f"Le '{field_name}' est requis."
    if not _VALID_GUID_LIKE_RE.match(value):
        return False, f"Format de '{field_name}' invalide."
    return True, None


# ---------------------------------------------------------------------------
# Intent storage (Teams-specific bucket)
# ---------------------------------------------------------------------------


def _get_intents_dict(state) -> dict[str, dict]:
    infos = getattr(state, "user_infos", None)
    if infos is None:
        return {}
    intents = infos.get(_INTENT_KEY)
    if intents is None:
        intents = {}
        infos[_INTENT_KEY] = intents
    return intents


def _purge_expired_intents(intents: dict[str, dict]) -> None:
    now = time.monotonic()
    expired = [
        i
        for i, p in intents.items()
        if now - p.get("created_at", 0) > _INTENT_TTL_SECONDS
    ]
    for i in expired:
        intents.pop(i, None)


# ---------------------------------------------------------------------------
# READ tools
# ---------------------------------------------------------------------------


@bind_session
async def list_teams_fn(
    limit: int = _DEFAULT_LIMIT,
    *,
    session_id: str,
) -> dict[str, Any]:
    """Liste les Teams auxquelles l'utilisateur connecté appartient."""
    state = _get_session_state(session_id)
    if not state:
        return {"error_code": "SESSION_NOT_FOUND", "error": "Session introuvable."}
    company_id = _company_id_from_state(state)
    if not company_id:
        return {
            "error_code": "NO_COMPANY",
            "error": "Pas de company sur cette session.",
        }

    if not await ensure_permission(company_id, "teams.read"):
        return permission_denied_error("teams.read")
    token = await resolve_access_token(company_id)
    if not token:
        return not_connected_error()

    capped = max(1, min(limit, _MAX_LIMIT))
    client = _get_client()
    try:
        body = await client.get(
            "me/joinedTeams",
            access_token=token,
            params={"$top": capped},
        )
    except GraphError as exc:
        return _map_graph_error(exc, action="list_teams")

    items = [_summarise_team(t) for t in (body.get("value") or [])]
    return {"items": items, "count": len(items)}


@bind_session
async def list_chats_fn(
    limit: int = _DEFAULT_LIMIT,
    *,
    session_id: str,
) -> dict[str, Any]:
    """Liste les conversations Teams (1:1 et de groupe) de l'utilisateur."""
    state = _get_session_state(session_id)
    if not state:
        return {"error_code": "SESSION_NOT_FOUND", "error": "Session introuvable."}
    company_id = _company_id_from_state(state)
    if not company_id:
        return {
            "error_code": "NO_COMPANY",
            "error": "Pas de company sur cette session.",
        }

    if not await ensure_permission(company_id, "teams.read"):
        return permission_denied_error("teams.read")
    token = await resolve_access_token(company_id)
    if not token:
        return not_connected_error()

    capped = max(1, min(limit, _MAX_LIMIT))
    client = _get_client()
    try:
        body = await client.get(
            "me/chats",
            access_token=token,
            params={"$top": capped, "$orderby": "lastUpdatedDateTime desc"},
        )
    except GraphError as exc:
        return _map_graph_error(exc, action="list_chats")

    items = [_summarise_chat(c) for c in (body.get("value") or [])]
    return {"items": items, "count": len(items)}


@bind_session
async def read_chat_messages_fn(
    chat_id: str,
    limit: int = _DEFAULT_LIMIT,
    *,
    session_id: str,
) -> dict[str, Any]:
    """Lit les messages récents d'une conversation Teams (chat 1:1 ou groupe)."""
    state = _get_session_state(session_id)
    if not state:
        return {"error_code": "SESSION_NOT_FOUND", "error": "Session introuvable."}
    company_id = _company_id_from_state(state)
    if not company_id:
        return {
            "error_code": "NO_COMPANY",
            "error": "Pas de company sur cette session.",
        }

    if not await ensure_permission(company_id, "teams.read"):
        return permission_denied_error("teams.read")
    token = await resolve_access_token(company_id)
    if not token:
        return not_connected_error()

    ok, err = _validate_id(chat_id, "chat_id")
    if not ok:
        return {"error_code": "INVALID_CHAT_ID", "error": err}

    capped = max(1, min(limit, _MAX_LIMIT))
    client = _get_client()
    try:
        body = await client.get(
            f"chats/{chat_id}/messages",
            access_token=token,
            params={"$top": capped},
        )
    except GraphError as exc:
        return _map_graph_error(exc, action="read_chat_messages")

    items = [_summarise_message(m) for m in (body.get("value") or [])]
    return {"items": items, "count": len(items)}


@bind_session
async def list_channels_fn(
    team_id: str,
    *,
    session_id: str,
) -> dict[str, Any]:
    """Liste les channels d'une Team."""
    state = _get_session_state(session_id)
    if not state:
        return {"error_code": "SESSION_NOT_FOUND", "error": "Session introuvable."}
    company_id = _company_id_from_state(state)
    if not company_id:
        return {
            "error_code": "NO_COMPANY",
            "error": "Pas de company sur cette session.",
        }

    if not await ensure_permission(company_id, "teams.read"):
        return permission_denied_error("teams.read")
    token = await resolve_access_token(company_id)
    if not token:
        return not_connected_error()

    ok, err = _validate_id(team_id, "team_id")
    if not ok:
        return {"error_code": "INVALID_TEAM_ID", "error": err}

    client = _get_client()
    try:
        body = await client.get(
            f"teams/{team_id}/channels",
            access_token=token,
        )
    except GraphError as exc:
        return _map_graph_error(exc, action="list_channels")

    items = [_summarise_channel(c) for c in (body.get("value") or [])]
    return {"items": items, "count": len(items)}


@bind_session
async def read_channel_messages_fn(
    team_id: str,
    channel_id: str,
    limit: int = _DEFAULT_LIMIT,
    *,
    session_id: str,
) -> dict[str, Any]:
    """Lit les messages récents d'un channel d'une Team."""
    state = _get_session_state(session_id)
    if not state:
        return {"error_code": "SESSION_NOT_FOUND", "error": "Session introuvable."}
    company_id = _company_id_from_state(state)
    if not company_id:
        return {
            "error_code": "NO_COMPANY",
            "error": "Pas de company sur cette session.",
        }

    if not await ensure_permission(company_id, "teams.read"):
        return permission_denied_error("teams.read")
    token = await resolve_access_token(company_id)
    if not token:
        return not_connected_error()

    ok, err = _validate_id(team_id, "team_id")
    if not ok:
        return {"error_code": "INVALID_TEAM_ID", "error": err}
    ok, err = _validate_id(channel_id, "channel_id")
    if not ok:
        return {"error_code": "INVALID_CHANNEL_ID", "error": err}

    capped = max(1, min(limit, _MAX_LIMIT))
    client = _get_client()
    try:
        body = await client.get(
            f"teams/{team_id}/channels/{channel_id}/messages",
            access_token=token,
            params={"$top": capped},
        )
    except GraphError as exc:
        return _map_graph_error(exc, action="read_channel_messages")

    items = [_summarise_message(m) for m in (body.get("value") or [])]
    return {"items": items, "count": len(items)}


# ---------------------------------------------------------------------------
# WRITE tools — 2-step intent for channel send
# ---------------------------------------------------------------------------


@bind_session
async def prepare_channel_message_fn(
    team_id: str,
    channel_id: str,
    content: str,
    *,
    session_id: str,
) -> dict[str, Any]:
    """Stage l'envoi d'un message dans un channel Teams **sans l'envoyer**.

    L'envoi réel n'a lieu qu'après ``confirm_channel_message`` avec
    le ``send_intent_id`` retourné. Sans confirmation utilisateur,
    rien n'est posté dans le channel.

    Args (LLM-facing):
        team_id: Identifiant de la Team.
        channel_id: Identifiant du channel cible.
        content: Texte du message à envoyer (UTF-8, max 10 000 chars).
    """
    state = _get_session_state(session_id)
    if not state:
        return {"error_code": "SESSION_NOT_FOUND", "error": "Session introuvable."}
    company_id = _company_id_from_state(state)
    if not company_id:
        return {
            "error_code": "NO_COMPANY",
            "error": "Pas de company sur cette session.",
        }

    if not await ensure_permission(company_id, "teams.write"):
        return permission_denied_error("teams.write")
    token = await resolve_access_token(company_id)
    if not token:
        return not_connected_error()

    ok, err = _validate_id(team_id, "team_id")
    if not ok:
        return {"error_code": "INVALID_TEAM_ID", "error": err}
    ok, err = _validate_id(channel_id, "channel_id")
    if not ok:
        return {"error_code": "INVALID_CHANNEL_ID", "error": err}

    if not isinstance(content, str):
        return {
            "error_code": "INVALID_CONTENT",
            "error": "Le contenu doit être du texte (str).",
        }
    cleaned = content.strip()
    if not cleaned:
        return {"error_code": "EMPTY_CONTENT", "error": "Le message est vide."}
    if len(cleaned) > _MAX_MESSAGE_CHARS:
        return {
            "error_code": "MESSAGE_TOO_LONG",
            "error": f"Message trop long (>{_MAX_MESSAGE_CHARS} caractères).",
            "length": len(cleaned),
            "max_length": _MAX_MESSAGE_CHARS,
        }

    intents = _get_intents_dict(state)
    _purge_expired_intents(intents)
    intent_id = uuid.uuid4().hex
    intents[intent_id] = {
        "kind": "channel_message",
        "team_id": team_id,
        "channel_id": channel_id,
        "content": cleaned,
        "created_at": time.monotonic(),
    }

    return {
        "send_intent_id": intent_id,
        "preview": {
            "team_id": team_id,
            "channel_id": channel_id,
            "content_excerpt": cleaned[:300],
            "content_length": len(cleaned),
            "expires_in_seconds": _INTENT_TTL_SECONDS,
        },
        "next_step": (
            "Présentez ce résumé à l'utilisateur. Demandez explicitement "
            "la confirmation, puis appelez confirm_channel_message"
            "(send_intent_id) pour poster le message."
        ),
    }


@bind_session
async def confirm_channel_message_fn(
    send_intent_id: str,
    *,
    session_id: str,
) -> dict[str, Any]:
    """Poste le message Teams associé à un ``send_intent_id``. À appeler
    **uniquement après confirmation explicite de l'utilisateur**."""
    state = _get_session_state(session_id)
    if not state:
        return {"error_code": "SESSION_NOT_FOUND", "error": "Session introuvable."}
    company_id = _company_id_from_state(state)
    if not company_id:
        return {
            "error_code": "NO_COMPANY",
            "error": "Pas de company sur cette session.",
        }

    if not await ensure_permission(company_id, "teams.write"):
        return permission_denied_error("teams.write")
    token = await resolve_access_token(company_id)
    if not token:
        return not_connected_error()

    if not (send_intent_id or "").strip():
        return {
            "error_code": "EMPTY_INTENT_ID",
            "error": "Le 'send_intent_id' est requis.",
        }

    intents = _get_intents_dict(state)
    _purge_expired_intents(intents)
    intent = intents.get(send_intent_id)
    if not intent or intent.get("kind") != "channel_message":
        return {
            "error_code": "INTENT_NOT_FOUND",
            "error": (
                "L'intention d'envoi est introuvable ou a expiré. "
                f"Les intentions expirent au bout de {_INTENT_TTL_SECONDS}s. "
                "Recommencez avec prepare_channel_message."
            ),
        }

    team_id = intent["team_id"]
    channel_id = intent["channel_id"]
    content = intent["content"]

    intents.pop(send_intent_id, None)

    client = _get_client()
    try:
        body = await client.request(
            "POST",
            f"teams/{team_id}/channels/{channel_id}/messages",
            access_token=token,
            json={"body": {"contentType": "text", "content": content}},
        )
    except GraphError as exc:
        return _map_graph_error(exc, action="confirm_channel_message")

    return {
        "sent": True,
        "message": _summarise_message(body),
    }


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


def register_tools(ctx: Context) -> None:
    register_tool(
        {
            "id": "microsoft_365.teams.list_teams",
            "tool": StructuredTool.from_function(
                list_teams_fn,
                name="microsoft_365_teams_list_teams",
                description="Liste les Teams auxquelles l'utilisateur connecté appartient.",
            ),
        }
    )
    register_tool(
        {
            "id": "microsoft_365.teams.list_chats",
            "tool": StructuredTool.from_function(
                list_chats_fn,
                name="microsoft_365_teams_list_chats",
                description="Liste les conversations Teams (1:1 + groupe) de l'utilisateur, plus récentes en premier.",
            ),
        }
    )
    register_tool(
        {
            "id": "microsoft_365.teams.read_chat_messages",
            "tool": StructuredTool.from_function(
                read_chat_messages_fn,
                name="microsoft_365_teams_read_chat_messages",
                description="Lit les messages récents d'une conversation Teams.",
            ),
        }
    )
    register_tool(
        {
            "id": "microsoft_365.teams.list_channels",
            "tool": StructuredTool.from_function(
                list_channels_fn,
                name="microsoft_365_teams_list_channels",
                description="Liste les channels d'une Team.",
            ),
        }
    )
    register_tool(
        {
            "id": "microsoft_365.teams.read_channel_messages",
            "tool": StructuredTool.from_function(
                read_channel_messages_fn,
                name="microsoft_365_teams_read_channel_messages",
                description="Lit les messages récents d'un channel Teams.",
            ),
        }
    )
    register_tool(
        {
            "id": "microsoft_365.teams.prepare_channel_message",
            "tool": StructuredTool.from_function(
                prepare_channel_message_fn,
                name="microsoft_365_teams_prepare_channel_message",
                description=(
                    "Stage l'envoi d'un message dans un channel Teams — "
                    "ne l'envoie PAS. Retourne un send_intent_id à confirmer "
                    "via confirm_channel_message après validation utilisateur."
                ),
            ),
        }
    )
    register_tool(
        {
            "id": "microsoft_365.teams.confirm_channel_message",
            "tool": StructuredTool.from_function(
                confirm_channel_message_fn,
                name="microsoft_365_teams_confirm_channel_message",
                description=(
                    "Poste un message Teams associé à un send_intent_id. "
                    "À appeler UNIQUEMENT après confirmation explicite de "
                    "l'utilisateur."
                ),
            ),
        }
    )
