-- ============================================================================
-- 001_microsoft_365_integrations.sql
-- ============================================================================
--
-- Plugin-owned schema for piilot-pack-microsoft-365 — provisions the
-- per-company storage backing the M365 OAuth connection and the
-- per-scope admin toggles. Both tables live under the dedicated
-- ``integrations_microsoft_365`` schema (same convention as
-- ``integrations_supabase`` and ``integrations_pennylane``) so
-- ownership is unambiguous.
--
-- ``integrations_microsoft_365.connections`` stores the access +
-- refresh tokens encrypted at rest (Fernet AES via
-- ``piilot.sdk.crypto.encrypt``). The application decrypts just-in-time
-- when calling Microsoft Graph; the DB never sees clear tokens.
--
-- ``integrations_microsoft_365.scope_grants`` is the granular toggle
-- table populated by the admin company in Settings → Microsoft 365.
-- Pattern fail-closed (admin must explicitly enable each scope) — the
-- plugin's tools refuse silently when the toggle is OFF.
--
-- Both tables are RLS FORCEd. Reads + writes are admin-only because
-- the encrypted secrets + scope toggles are sensitive enough that we
-- don't want plain members poking at them. The plugin runtime uses
-- the bypass role ``piilot`` for token resolution on the hot path.
--
-- Idempotency contract (cf. plugin loader's static heuristic check):
-- every CREATE statement uses IF NOT EXISTS, every DROP POLICY uses
-- IF EXISTS. Safe to re-run on a partially-migrated DB.
--
-- Compatibility note: this migration creates the same end-state as
-- the legacy ``backend/migrations/110_microsoft_365_integrations.sql``
-- shipped by AICockpit core for plugin versions 0.1.x → 0.2.2. From
-- 0.2.3 onwards the plugin owns its schema directly. On environments
-- that already applied the core mig 110, the IF NOT EXISTS guards
-- make this a no-op. On fresh installs without the legacy core mig,
-- this is the canonical creator.
-- ============================================================================

BEGIN;

-- ============================================================
-- Schema
-- ============================================================

CREATE SCHEMA IF NOT EXISTS integrations_microsoft_365;

GRANT USAGE ON SCHEMA integrations_microsoft_365 TO piilot, piilot_app;


-- ============================================================
-- Table: connections
-- ============================================================
-- One row max per company (UNIQUE constraint). Each connection
-- represents the M365 user account that authorised the app — typically
-- an admin or a dedicated service account.
--
-- ``access_token_encrypted`` is short-lived (~1h) — decrypted, used,
-- discarded. ``refresh_token_encrypted`` lives for ~90 days; the
-- plugin rotates it when refreshing.
--
-- ``scopes_granted`` is the snapshot of scopes Microsoft actually
-- granted at the last consent (vs the scopes the company admin
-- toggled — those live in scope_grants). Mismatch = the user
-- consented to a smaller subset than the toggles imply.

CREATE TABLE IF NOT EXISTS integrations_microsoft_365.connections (
    id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id               UUID NOT NULL UNIQUE
                                  REFERENCES public.companies(id) ON DELETE CASCADE,

    -- Connected M365 user identity (read from /me at connect time, kept
    -- for display in Settings + for audit trail).
    user_principal_name      TEXT NOT NULL,
    display_name             TEXT,
    tenant_id                TEXT,

    -- OAuth tokens — Fernet-encrypted via piilot.sdk.crypto.
    access_token_encrypted   TEXT NOT NULL,
    refresh_token_encrypted  TEXT,
    expires_at               TIMESTAMPTZ NOT NULL,

    -- Scopes the user actually consented to (snapshot from the token
    -- exchange response). Differs from scope_grants when the user
    -- consented to less than the admin toggled.
    scopes_granted           TEXT[] NOT NULL DEFAULT '{}',

    -- True iff the tenant admin has granted the app at the tenant
    -- level (covers .All scopes — Sites.*, ChannelMessage.Read.All,
    -- etc.). Detected by the plugin via Graph; surfaced in Settings.
    admin_consent_granted    BOOLEAN NOT NULL DEFAULT false,

    connected_by             UUID REFERENCES public.users(id) ON DELETE SET NULL,
    connected_at             TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_refreshed_at        TIMESTAMPTZ,
    last_used_at             TIMESTAMPTZ,

    created_at               TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at               TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_m365_connections_company
    ON integrations_microsoft_365.connections (company_id);

CREATE INDEX IF NOT EXISTS idx_m365_connections_expires_at
    ON integrations_microsoft_365.connections (expires_at)
    WHERE refresh_token_encrypted IS NOT NULL;

DROP TRIGGER IF EXISTS trg_m365_connections_updated_at
    ON integrations_microsoft_365.connections;
CREATE TRIGGER trg_m365_connections_updated_at
    BEFORE UPDATE ON integrations_microsoft_365.connections
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

GRANT SELECT, INSERT, UPDATE, DELETE
    ON integrations_microsoft_365.connections
    TO piilot_app;

ALTER TABLE integrations_microsoft_365.connections ENABLE ROW LEVEL SECURITY;
ALTER TABLE integrations_microsoft_365.connections FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS m365_connections_bypass ON integrations_microsoft_365.connections;
CREATE POLICY m365_connections_bypass ON integrations_microsoft_365.connections
    TO piilot USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS m365_connections_admin ON integrations_microsoft_365.connections;
CREATE POLICY m365_connections_admin ON integrations_microsoft_365.connections
    FOR ALL TO piilot_app
    USING      (public.is_company_admin(company_id))
    WITH CHECK (public.is_company_admin(company_id));

COMMENT ON TABLE  integrations_microsoft_365.connections IS
    'C11 — Per-company OAuth connection to Microsoft 365 (one row max). '
    'Tokens stored Fernet-encrypted; the application decrypts JIT.';
COMMENT ON COLUMN integrations_microsoft_365.connections.access_token_encrypted IS
    'Fernet AES-encrypted via piilot.sdk.crypto.encrypt — never stored in clear. ~1h TTL.';
COMMENT ON COLUMN integrations_microsoft_365.connections.refresh_token_encrypted IS
    'Fernet AES-encrypted refresh token. ~90 day TTL. Rotated by the plugin on refresh.';
COMMENT ON COLUMN integrations_microsoft_365.connections.admin_consent_granted IS
    'True iff the tenant admin has granted the app at the tenant level (covers .All scopes).';


-- ============================================================
-- Table: scope_grants
-- ============================================================
-- Up to 8 rows per company — one per granular permission. Pattern
-- fail-closed: a missing row is treated as ``enabled=false``. The
-- admin company explicitly opts in to each scope via Settings.

CREATE TABLE IF NOT EXISTS integrations_microsoft_365.scope_grants (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id          UUID NOT NULL
                            REFERENCES public.companies(id) ON DELETE CASCADE,

    -- Permission identifier matching connector.SCOPE_GROUPS in the
    -- plugin code. Constrained so an LLM-typo in the toggles API
    -- payload doesn't insert garbage.
    permission_id       TEXT NOT NULL CHECK (permission_id IN (
        'outlook.read',
        'outlook.write',
        'onedrive.read',
        'onedrive.write',
        'sharepoint.read',
        'sharepoint.write',
        'teams.read',
        'teams.write'
    )),

    enabled             BOOLEAN NOT NULL DEFAULT false,
    granted_by          UUID REFERENCES public.users(id) ON DELETE SET NULL,
    granted_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    revoked_at          TIMESTAMPTZ,

    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),

    UNIQUE (company_id, permission_id)
);

CREATE INDEX IF NOT EXISTS idx_m365_scope_grants_company
    ON integrations_microsoft_365.scope_grants (company_id);

CREATE INDEX IF NOT EXISTS idx_m365_scope_grants_enabled_lookup
    ON integrations_microsoft_365.scope_grants (company_id, permission_id)
    WHERE enabled = true;

DROP TRIGGER IF EXISTS trg_m365_scope_grants_updated_at
    ON integrations_microsoft_365.scope_grants;
CREATE TRIGGER trg_m365_scope_grants_updated_at
    BEFORE UPDATE ON integrations_microsoft_365.scope_grants
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

GRANT SELECT, INSERT, UPDATE, DELETE
    ON integrations_microsoft_365.scope_grants
    TO piilot_app;

ALTER TABLE integrations_microsoft_365.scope_grants ENABLE ROW LEVEL SECURITY;
ALTER TABLE integrations_microsoft_365.scope_grants FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS m365_scope_grants_bypass ON integrations_microsoft_365.scope_grants;
CREATE POLICY m365_scope_grants_bypass ON integrations_microsoft_365.scope_grants
    TO piilot USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS m365_scope_grants_admin ON integrations_microsoft_365.scope_grants;
CREATE POLICY m365_scope_grants_admin ON integrations_microsoft_365.scope_grants
    FOR ALL TO piilot_app
    USING      (public.is_company_admin(company_id))
    WITH CHECK (public.is_company_admin(company_id));

COMMENT ON TABLE  integrations_microsoft_365.scope_grants IS
    'C11 — Per-company × per-scope toggle for the Microsoft 365 plugin. '
    'Fail-closed: missing row = disabled. 8 permissions max per company.';
COMMENT ON COLUMN integrations_microsoft_365.scope_grants.enabled IS
    'When true, the plugin tool guarded by this permission_id is exposed to agents.';

COMMIT;
