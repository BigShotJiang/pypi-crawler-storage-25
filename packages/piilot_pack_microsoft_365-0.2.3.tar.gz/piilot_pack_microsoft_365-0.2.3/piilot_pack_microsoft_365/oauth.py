"""OAuth flow helpers — Microsoft Entra authorization code grant.

Pure logic, no DB access — the routes layer composes these helpers
with ``_db.py`` to persist tokens. Splitting them keeps tests fast
(no Postgres needed) and the OAuth dance independent of the storage
shape.

Flow (cf. Microsoft docs — OAuth 2.0 authorization code) :

  1. ``build_authorize_url(scopes, state, redirect_uri)`` returns the
     URL the user is redirected to. Microsoft handles the consent UI
     and bounces back to ``redirect_uri`` with ``code=...&state=...``.
  2. ``exchange_code(code, redirect_uri)`` POSTs to the token endpoint
     and returns the bag of tokens + scopes_granted + expiry.
  3. ``refresh_tokens(refresh_token)`` rotates a near-expired access
     token. Microsoft may also rotate the refresh token; we handle
     both shapes.
  4. ``check_admin_consent_granted(access_token)`` introspects the
     ``/me/`` plus a sentinel ``.All`` scope query to detect whether
     the tenant admin has authorised the broader scopes.

Errors are typed (``OAuthError`` family) so the route layer can map
each to a specific HTTP status + i18n key without parsing strings.
"""

from __future__ import annotations

import logging
import os
import secrets
from datetime import datetime, timedelta, timezone
from typing import Any, Iterable

import httpx

logger = logging.getLogger(__name__)


_TOKEN_ENDPOINT_TMPL = "https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token"
_AUTH_ENDPOINT_TMPL = "https://login.microsoftonline.com/{tenant}/oauth2/v2.0/authorize"
_ADMIN_CONSENT_ENDPOINT_TMPL = "https://login.microsoftonline.com/{tenant}/adminconsent"


# ---------------------------------------------------------------------------
# Typed errors
# ---------------------------------------------------------------------------


class OAuthError(Exception):
    """Base class — every OAuth failure derives from this."""

    def __init__(
        self,
        message: str,
        *,
        code: str = "oauth_error",
        status: int | None = None,
        details: dict | None = None,
    ):
        super().__init__(message)
        self.code = code
        self.status = status
        self.details = details or {}


class OAuthConfigError(OAuthError):
    """Azure App Registration env vars are missing — admin must configure
    ``MICROSOFT_CLIENT_ID`` + ``MICROSOFT_CLIENT_SECRET`` in Coolify."""


class OAuthExchangeError(OAuthError):
    """Microsoft's token endpoint refused our exchange — the user denied
    consent, the code expired, or the redirect URI doesn't match the
    Azure App Registration."""


class OAuthRefreshError(OAuthError):
    """Refresh token is invalid or revoked — the company must re-connect
    Microsoft 365 from Settings."""


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


def _client_id() -> str:
    return os.getenv("MICROSOFT_CLIENT_ID", "")


def _client_secret() -> str:
    """The client secret is required for the ``confidential client``
    flow we use here (vs the public client flow used by SSO PLT-37,
    which only handles ID tokens). Backend stores the secret as a
    Coolify env var; never logged.
    """
    return os.getenv("MICROSOFT_CLIENT_SECRET", "")


def _tenant() -> str:
    return os.getenv("MICROSOFT_TENANT_ID", "common")


def _ensure_configured() -> None:
    if not _client_id():
        raise OAuthConfigError(
            "MICROSOFT_CLIENT_ID is not set",
            code="missing_client_id",
        )
    if not _client_secret():
        raise OAuthConfigError(
            "MICROSOFT_CLIENT_SECRET is not set",
            code="missing_client_secret",
        )


# ---------------------------------------------------------------------------
# State token (CSRF + company binding)
# ---------------------------------------------------------------------------


def generate_state(company_id: str) -> str:
    """Build an opaque state token tying a redirect to a company.

    Format: ``{company_id}:{nonce}`` — the company_id binds the
    callback to the right tenant, the nonce defeats replays. The route
    layer validates it before exchanging the code.

    We don't sign the state because the route layer also checks the
    company_id on the resulting JWT session — a tampered state would
    just yield a broken connect, not a privilege escalation.
    """
    nonce = secrets.token_urlsafe(16)
    return f"{company_id}:{nonce}"


def parse_state(state: str) -> tuple[str, str]:
    """Reverse ``generate_state``. Raises ``OAuthError`` on malformed input."""
    if not state or ":" not in state:
        raise OAuthError("invalid OAuth state token", code="invalid_state")
    company_id, _, nonce = state.partition(":")
    if not company_id or not nonce:
        raise OAuthError("invalid OAuth state token", code="invalid_state")
    return company_id, nonce


# ---------------------------------------------------------------------------
# Authorize URL
# ---------------------------------------------------------------------------


def _scopes_string(scopes: Iterable[str]) -> str:
    """Microsoft expects scopes as a space-separated string. Always
    add ``offline_access`` so we get a refresh token, plus
    ``openid email profile`` so /me works on the resulting token.
    """
    base = ["openid", "email", "profile", "offline_access"]
    seen = set(base)
    for s in scopes:
        if s and s not in seen:
            seen.add(s)
            base.append(s)
    return " ".join(base)


def build_authorize_url(
    *,
    scopes: Iterable[str],
    redirect_uri: str,
    state: str,
    prompt: str = "select_account",
) -> str:
    """Return the URL the user must visit to authorise the app.

    ``prompt=select_account`` ensures the user explicitly picks an
    account (vs being auto-signed-in to their default), which matches
    the Settings page UX where an admin connects a service account.
    """
    _ensure_configured()
    from urllib.parse import urlencode

    params = {
        "client_id": _client_id(),
        "response_type": "code",
        "redirect_uri": redirect_uri,
        "response_mode": "query",
        "scope": _scopes_string(scopes),
        "state": state,
        "prompt": prompt,
    }
    return _AUTH_ENDPOINT_TMPL.format(tenant=_tenant()) + "?" + urlencode(params)


def build_admin_consent_url(*, redirect_uri: str, state: str) -> str:
    """Return the URL an admin tenant administrator must visit to grant
    the app at the tenant level. Used when ``.All`` scopes (SharePoint,
    ChannelMessage.Read.All) are required and the user can't consent
    on their own.
    """
    _ensure_configured()
    from urllib.parse import urlencode

    params = {
        "client_id": _client_id(),
        "redirect_uri": redirect_uri,
        "state": state,
    }
    return (
        _ADMIN_CONSENT_ENDPOINT_TMPL.format(tenant=_tenant()) + "?" + urlencode(params)
    )


# ---------------------------------------------------------------------------
# Token exchange + refresh
# ---------------------------------------------------------------------------


async def exchange_code(
    *,
    code: str,
    redirect_uri: str,
    client: httpx.AsyncClient | None = None,
) -> dict[str, Any]:
    """Exchange an authorization code for tokens.

    Returns a dict with the keys the storage layer needs:
      ``access_token``, ``refresh_token`` (or None), ``expires_at``,
      ``scopes_granted`` (list[str]), ``token_type``.

    Raises ``OAuthExchangeError`` on Microsoft refusal.
    """
    _ensure_configured()
    if not code:
        raise OAuthExchangeError("missing authorization code", code="missing_code")

    payload = {
        "client_id": _client_id(),
        "client_secret": _client_secret(),
        "grant_type": "authorization_code",
        "code": code,
        "redirect_uri": redirect_uri,
    }
    return await _post_token(payload, client=client, error_cls=OAuthExchangeError)


async def refresh_tokens(
    *,
    refresh_token: str,
    client: httpx.AsyncClient | None = None,
) -> dict[str, Any]:
    """Rotate a near-expiring access token. Microsoft *may* also rotate
    the refresh token — we surface whichever value comes back.

    Raises ``OAuthRefreshError`` when the refresh token is dead.
    """
    _ensure_configured()
    if not refresh_token:
        raise OAuthRefreshError("missing refresh token", code="missing_refresh_token")

    payload = {
        "client_id": _client_id(),
        "client_secret": _client_secret(),
        "grant_type": "refresh_token",
        "refresh_token": refresh_token,
    }
    return await _post_token(payload, client=client, error_cls=OAuthRefreshError)


async def _post_token(
    payload: dict[str, str],
    *,
    client: httpx.AsyncClient | None,
    error_cls: type[OAuthError],
) -> dict[str, Any]:
    """Common token-endpoint POST. Always returns or raises."""
    own_client = client is None
    if own_client:
        client = httpx.AsyncClient(timeout=httpx.Timeout(15.0, connect=5.0))
    try:
        resp = await client.post(
            _TOKEN_ENDPOINT_TMPL.format(tenant=_tenant()),
            data=payload,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
    except httpx.HTTPError as exc:
        raise error_cls(
            f"network error contacting Microsoft: {exc}", code="network_error"
        ) from exc
    finally:
        if own_client:
            await client.aclose()

    if resp.status_code != 200:
        body = _safe_json(resp)
        ms_error = body.get("error", "unknown_error")
        ms_desc = body.get("error_description", "")
        raise error_cls(
            f"Microsoft token endpoint refused: {ms_error} — {ms_desc}",
            code=ms_error,
            status=resp.status_code,
            details={"error_description": ms_desc[:300]},
        )

    body = resp.json()
    expires_in = int(body.get("expires_in") or 3600)
    expires_at = datetime.now(timezone.utc) + timedelta(seconds=expires_in)
    scopes_str = body.get("scope") or ""
    return {
        "access_token": body.get("access_token") or "",
        "refresh_token": body.get("refresh_token"),  # may be absent on refresh
        "expires_at": expires_at,
        "scopes_granted": scopes_str.split() if scopes_str else [],
        "token_type": body.get("token_type") or "Bearer",
    }


def _safe_json(resp: httpx.Response) -> dict:
    try:
        return resp.json()
    except ValueError:
        return {"error": "invalid_response", "error_description": resp.text[:300]}


# ---------------------------------------------------------------------------
# Admin consent detection
# ---------------------------------------------------------------------------


# Heuristic: any scope ending in ``.All`` typically requires admin
# consent. We compare what the user actually got (``scopes_granted``)
# against what the company admin toggled. Mismatch on a ``.All`` scope
# = admin consent missing.
def admin_consent_satisfies(
    *,
    requested_scopes: Iterable[str],
    granted_scopes: Iterable[str],
) -> bool:
    """True iff every ``.All`` requested scope is in the granted set.

    ``offline_access`` and ``openid`` family are always present and
    never need admin consent — they don't count in the comparison.
    """
    requested_set = {s for s in requested_scopes if s.endswith(".All")}
    if not requested_set:
        return True  # nothing requiring admin → trivially satisfied
    granted_set = set(granted_scopes)
    return requested_set.issubset(granted_set)
