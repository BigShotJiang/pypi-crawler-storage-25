"""Microsoft Graph API client — thin async wrapper around ``httpx``.

Single responsibility: take an access token + a Graph endpoint, return
a parsed JSON. Token refresh, scope-gating, and HITL flows all live in
upper layers (``connector.py``, route handlers, agent tool wrappers).

Resilience:
  * 1 retry on 5xx + 429 with ``Retry-After`` honored (Graph throttling
    is the most common failure mode in real fleets).
  * Connect/read timeouts default to 10s — Graph rarely needs more
    and we'd rather fail fast than block an agent turn for 30s.
  * Errors are mapped to typed exceptions so the upper layers can
    branch (``GraphAuthError`` for 401, ``GraphPermissionError`` for
    403/admin consent missing, ``GraphRateLimitedError`` for 429).
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Literal

import httpx

logger = logging.getLogger(__name__)


GRAPH_BASE_URL = "https://graph.microsoft.com/v1.0"

# Default timeout (connect + read). Graph p99 stays under 5s for the
# endpoints we use (search/list/get); 10s gives margin without blocking
# an agent turn forever.
_DEFAULT_TIMEOUT = httpx.Timeout(10.0, connect=5.0)


# ---------------------------------------------------------------------------
# Typed exceptions
# ---------------------------------------------------------------------------


class GraphError(Exception):
    """Base class — every Graph API failure derives from this."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        response_body: dict | None = None,
    ):
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body or {}


class GraphAuthError(GraphError):
    """401 — token invalid/expired. Caller must refresh and retry."""


class GraphPermissionError(GraphError):
    """403 — scope not granted, or admin consent required.

    Distinguishable via ``response_body['error']['code']``:
      - 'AccessDenied' / 'Authorization_RequestDenied' → admin consent
        likely missing for the requested scope.
      - 'Forbidden' → the user has no permission on the target resource.
    """


class GraphRateLimitedError(GraphError):
    """429 — Graph throttling. Caller should backoff or retry later."""

    def __init__(
        self,
        message: str,
        *,
        retry_after: int | None = None,
        status_code: int | None = None,
        response_body: dict | None = None,
    ):
        super().__init__(message, status_code=status_code, response_body=response_body)
        self.retry_after = retry_after


class GraphNotFoundError(GraphError):
    """404 — resource not found. Often legitimate, e.g. lookup of a
    deleted email."""


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------


HttpMethod = Literal["GET", "POST", "PATCH", "PUT", "DELETE"]


class GraphAPIClient:
    """Stateless Graph API caller. Reusable across requests.

    Designed for short-lived requests (one tool call). Reuses an
    underlying ``httpx.AsyncClient`` per instance — instantiate once
    per plugin runtime, not per call.

    The token is passed at call time (not at construction) because the
    plugin handles many companies' connections; binding a single token
    would require one client instance per company.
    """

    def __init__(self, base_url: str = GRAPH_BASE_URL):
        self._base_url = base_url.rstrip("/")
        self._http = httpx.AsyncClient(
            timeout=_DEFAULT_TIMEOUT,
            follow_redirects=True,
        )

    async def aclose(self) -> None:
        await self._http.aclose()

    async def __aenter__(self) -> "GraphAPIClient":
        return self

    async def __aexit__(self, *_exc) -> None:
        await self.aclose()

    async def request(
        self,
        method: HttpMethod,
        path: str,
        *,
        access_token: str,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        max_retries: int = 1,
    ) -> dict[str, Any]:
        """Execute a Graph request and return the parsed JSON body.

        Empty bodies (HTTP 204) return an empty dict. Errors raise the
        typed exceptions defined above. The caller is responsible for
        checking the response shape — we don't do schema validation here
        because Graph endpoints differ wildly.

        ``path`` may be absolute (``/me/messages``) or relative to base
        (``me/messages``); we normalise.
        """
        if not access_token:
            raise GraphAuthError("missing access_token")

        url = (
            path if path.startswith("http") else f"{self._base_url}/{path.lstrip('/')}"
        )
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
        }

        attempt = 0
        while True:
            try:
                resp = await self._http.request(
                    method,
                    url,
                    params=params,
                    json=json,
                    headers=headers,
                )
            except (httpx.ConnectTimeout, httpx.ReadTimeout) as exc:
                # Treat as transient — retry once.
                if attempt >= max_retries:
                    raise GraphError(
                        f"timeout calling {method} {url}: {exc}",
                    ) from exc
                attempt += 1
                logger.warning(
                    "graph: %s %s timed out, retrying (attempt %d)",
                    method,
                    url,
                    attempt,
                )
                continue

            if resp.status_code in (200, 201, 202):
                # Graph occasionally returns 204 with no body for DELETEs.
                if not resp.content:
                    return {}
                try:
                    return resp.json()
                except ValueError as exc:
                    raise GraphError(
                        f"invalid JSON from {method} {url}: {exc}",
                        status_code=resp.status_code,
                    ) from exc

            if resp.status_code == 204:
                return {}

            body = _safe_json(resp)

            if resp.status_code == 401:
                raise GraphAuthError(
                    f"graph 401 on {method} {url}: token rejected",
                    status_code=resp.status_code,
                    response_body=body,
                )

            if resp.status_code == 403:
                raise GraphPermissionError(
                    f"graph 403 on {method} {url}: scope/permission missing",
                    status_code=resp.status_code,
                    response_body=body,
                )

            if resp.status_code == 404:
                raise GraphNotFoundError(
                    f"graph 404 on {method} {url}",
                    status_code=resp.status_code,
                    response_body=body,
                )

            if resp.status_code == 429:
                # Throttling. Honor Retry-After header when present.
                retry_after = _parse_retry_after(resp.headers.get("Retry-After"))
                if attempt < max_retries and retry_after is not None:
                    attempt += 1
                    logger.warning(
                        "graph: %s %s rate-limited, sleeping %ds (attempt %d)",
                        method,
                        url,
                        retry_after,
                        attempt,
                    )
                    await asyncio.sleep(retry_after)
                    continue
                raise GraphRateLimitedError(
                    f"graph 429 on {method} {url}: rate limit exceeded",
                    retry_after=retry_after,
                    status_code=resp.status_code,
                    response_body=body,
                )

            if 500 <= resp.status_code < 600 and attempt < max_retries:
                attempt += 1
                # Tiny jitter to avoid thundering herd on retries.
                await asyncio.sleep(0.5 * attempt)
                logger.warning(
                    "graph: %s %s returned %d, retrying (attempt %d)",
                    method,
                    url,
                    resp.status_code,
                    attempt,
                )
                continue

            # Anything else — let the upper layer decide. We carry the
            # body so the caller can introspect ``error.code`` / ``message``.
            raise GraphError(
                f"graph error on {method} {url}: status={resp.status_code}",
                status_code=resp.status_code,
                response_body=body,
            )

    # ── Convenience GET ─────────────────────────────────────────────────

    async def get(
        self,
        path: str,
        *,
        access_token: str,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return await self.request("GET", path, access_token=access_token, params=params)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _safe_json(resp: httpx.Response) -> dict:
    try:
        return resp.json()
    except ValueError:
        return {"_raw": resp.text[:500]}


def _parse_retry_after(value: str | None) -> int | None:
    """Honor Retry-After headers — integer seconds is the only form Graph
    uses in practice. Drop HTTP-date forms (RFC 7231 allows them but we
    don't bother for v0.1)."""
    if not value:
        return None
    try:
        return max(0, int(value))
    except ValueError:
        return None
