"""Database helpers for the M365 plugin.

Wraps the two tables provisioned by migration 110 :

  - ``integrations_microsoft_365.connections``
  - ``integrations_microsoft_365.scope_grants``

All token columns go through ``piilot.sdk.crypto.encrypt`` /
``decrypt`` — clear text never reaches the DB. The plugin uses
``piilot.sdk.db.cursor()`` for raw SQL and ``run_in_thread`` to wrap
sync calls into the async event loop.

Pattern: small, focused helpers — each does one well-defined thing
so that tests can mock them in isolation without standing up Postgres.
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone

from piilot.sdk.crypto import decrypt, encrypt
from piilot.sdk.db import cursor

logger = logging.getLogger(__name__)


_CONN_COLS = (
    "id, company_id, user_principal_name, display_name, tenant_id, "
    "access_token_encrypted, refresh_token_encrypted, expires_at, "
    "scopes_granted, admin_consent_granted, "
    "connected_by, connected_at, last_refreshed_at, last_used_at, "
    "created_at, updated_at"
)


# ---------------------------------------------------------------------------
# Connection record helpers (decrypted shape)
# ---------------------------------------------------------------------------


def _row_to_connection(row: dict) -> dict:
    """Convert a raw DB row to the decrypted dict the application uses.

    Tokens come out of the DB encrypted; we decrypt them here so the
    caller sees a plain string. Callers must never log this dict
    verbatim — they should pull the specific fields they need.
    """
    if not row:
        return {}
    out = dict(row)
    enc_access = out.pop("access_token_encrypted", None)
    enc_refresh = out.pop("refresh_token_encrypted", None)
    out["access_token"] = decrypt(enc_access) if enc_access else None
    out["refresh_token"] = decrypt(enc_refresh) if enc_refresh else None
    return out


def get_connection(company_id: str) -> dict | None:
    """Return the M365 connection for ``company_id`` (decrypted) or None."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_CONN_COLS} "
            "FROM integrations_microsoft_365.connections "
            "WHERE company_id = %s::uuid",
            (company_id,),
        )
        row = cur.fetchone()
    return _row_to_connection(row) if row else None


def upsert_connection(
    *,
    company_id: str,
    user_principal_name: str,
    display_name: str | None,
    tenant_id: str | None,
    access_token: str,
    refresh_token: str | None,
    expires_at: datetime,
    scopes_granted: list[str],
    admin_consent_granted: bool,
    connected_by: str | None,
) -> str:
    """Upsert the company's M365 connection. Returns the row ``id``.

    Tokens are encrypted before insert. Existing row is replaced
    wholesale — re-connecting always supersedes the previous tokens
    (Microsoft invalidates the prior refresh token at re-consent).
    """
    enc_access = encrypt(access_token)
    enc_refresh = encrypt(refresh_token) if refresh_token else None

    with cursor() as cur:
        cur.execute(
            """
            INSERT INTO integrations_microsoft_365.connections
                (company_id, user_principal_name, display_name, tenant_id,
                 access_token_encrypted, refresh_token_encrypted, expires_at,
                 scopes_granted, admin_consent_granted, connected_by,
                 connected_at, last_refreshed_at)
            VALUES (%s::uuid, %s, %s, %s,
                    %s, %s, %s,
                    %s, %s, %s::uuid,
                    now(), now())
            ON CONFLICT (company_id) DO UPDATE SET
                user_principal_name     = EXCLUDED.user_principal_name,
                display_name            = EXCLUDED.display_name,
                tenant_id               = EXCLUDED.tenant_id,
                access_token_encrypted  = EXCLUDED.access_token_encrypted,
                refresh_token_encrypted = EXCLUDED.refresh_token_encrypted,
                expires_at              = EXCLUDED.expires_at,
                scopes_granted          = EXCLUDED.scopes_granted,
                admin_consent_granted   = EXCLUDED.admin_consent_granted,
                connected_by            = EXCLUDED.connected_by,
                last_refreshed_at       = EXCLUDED.last_refreshed_at,
                updated_at              = now()
            RETURNING id
            """,
            (
                company_id,
                user_principal_name,
                display_name,
                tenant_id,
                enc_access,
                enc_refresh,
                expires_at,
                scopes_granted,
                admin_consent_granted,
                connected_by,
            ),
        )
        row = cur.fetchone()
    return str(row["id"]) if row else ""


def update_tokens_after_refresh(
    *,
    company_id: str,
    access_token: str,
    refresh_token: str | None,
    expires_at: datetime,
) -> None:
    """Replace tokens after a refresh round-trip without touching the
    other connection metadata (display_name, scopes, etc.)."""
    enc_access = encrypt(access_token)
    enc_refresh = encrypt(refresh_token) if refresh_token else None

    with cursor() as cur:
        cur.execute(
            """
            UPDATE integrations_microsoft_365.connections
            SET access_token_encrypted = %s,
                refresh_token_encrypted = COALESCE(%s, refresh_token_encrypted),
                expires_at              = %s,
                last_refreshed_at       = now(),
                updated_at              = now()
            WHERE company_id = %s::uuid
            """,
            (enc_access, enc_refresh, expires_at, company_id),
        )


def touch_last_used(company_id: str) -> None:
    """Update ``last_used_at`` to now. Best-effort; never raises.

    Called from the hot path on every successful Graph call so the
    Settings UI can show "last used 5 minutes ago" without a separate
    query path.
    """
    try:
        with cursor() as cur:
            cur.execute(
                "UPDATE integrations_microsoft_365.connections "
                "SET last_used_at = now() WHERE company_id = %s::uuid",
                (company_id,),
            )
    except Exception:  # noqa: BLE001
        logger.exception("touch_last_used failed for %s", company_id)


def delete_connection(company_id: str) -> None:
    """Hard-delete the M365 connection row.

    Phase 2 keeps it simple — disconnecting drops the row entirely.
    A future v0.2 might keep an audit row with ``revoked_at`` instead.
    """
    with cursor() as cur:
        cur.execute(
            "DELETE FROM integrations_microsoft_365.connections "
            "WHERE company_id = %s::uuid",
            (company_id,),
        )


def is_token_near_expiry(connection: dict, *, threshold_seconds: int = 120) -> bool:
    """True when the connection's access token expires within
    ``threshold_seconds`` from now. Caller refreshes proactively.
    """
    expires_at = connection.get("expires_at")
    if not isinstance(expires_at, datetime):
        return True  # Defensive — refresh if we can't parse the value
    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=timezone.utc)
    return expires_at - datetime.now(timezone.utc) < timedelta(
        seconds=threshold_seconds
    )


# ---------------------------------------------------------------------------
# Scope grants helpers
# ---------------------------------------------------------------------------


_SCOPE_COLS = (
    "id, company_id, permission_id, enabled, granted_by, granted_at, "
    "revoked_at, created_at, updated_at"
)


def list_scope_grants(company_id: str) -> list[dict]:
    """Return all scope_grants rows for a company (enabled OR disabled).

    Missing toggles aren't represented — the caller derives "disabled"
    by intersecting against the canonical 8-permission list. The
    Settings UI typically presents 8 toggles, fills in the state from
    this list, and shows the remainder as ``enabled=false``.
    """
    with cursor() as cur:
        cur.execute(
            f"SELECT {_SCOPE_COLS} "
            "FROM integrations_microsoft_365.scope_grants "
            "WHERE company_id = %s::uuid "
            "ORDER BY permission_id",
            (company_id,),
        )
        return list(cur.fetchall() or [])


def is_scope_enabled(company_id: str, permission_id: str) -> bool:
    """True iff the company admin has explicitly enabled this scope.

    Hot-path check called on every tool invocation. We hit a small
    indexed table here — sub-ms in practice. A future v0.2 may add
    Redis caching with a 60s TTL similar to ``companies_plugins``.
    """
    with cursor() as cur:
        cur.execute(
            "SELECT 1 FROM integrations_microsoft_365.scope_grants "
            "WHERE company_id = %s::uuid "
            "  AND permission_id = %s "
            "  AND enabled = true",
            (company_id, permission_id),
        )
        return cur.fetchone() is not None


def upsert_scope_grant(
    *,
    company_id: str,
    permission_id: str,
    enabled: bool,
    granted_by: str | None,
) -> None:
    """Toggle a scope ON or OFF for a company.

    On disable, ``revoked_at`` is set so the audit trail can show
    when an admin pulled a permission. The revoked row stays for
    history rather than being deleted.
    """
    with cursor() as cur:
        cur.execute(
            """
            INSERT INTO integrations_microsoft_365.scope_grants
                (company_id, permission_id, enabled, granted_by,
                 granted_at, revoked_at)
            VALUES (%s::uuid, %s, %s, %s::uuid,
                    now(), CASE WHEN %s THEN NULL ELSE now() END)
            ON CONFLICT (company_id, permission_id) DO UPDATE SET
                enabled    = EXCLUDED.enabled,
                granted_by = EXCLUDED.granted_by,
                granted_at = CASE WHEN EXCLUDED.enabled THEN now()
                                  ELSE scope_grants.granted_at END,
                revoked_at = CASE WHEN EXCLUDED.enabled THEN NULL
                                  ELSE now() END,
                updated_at = now()
            """,
            (company_id, permission_id, enabled, granted_by, enabled),
        )
