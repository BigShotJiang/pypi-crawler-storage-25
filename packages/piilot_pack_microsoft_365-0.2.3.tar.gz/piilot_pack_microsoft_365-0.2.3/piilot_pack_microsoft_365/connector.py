"""Microsoft 365 connector — registers the connector type with the SDK.

A "connector" in Piilot is a per-company configuration that holds the
credentials needed to talk to an external system. For M365, the
credentials are an OAuth2 access token + refresh token tied to a
specific user account in a specific tenant. Phase 2 wires the OAuth
flow that populates these tokens.

In Phase 1 we register the connector *type* so the loader knows about
it (visible in the admin UI as "Microsoft 365") but no token is
stored yet — the ``whoami`` tool is the one route a developer can
exercise locally with a hand-issued token to validate the wiring.
"""

from __future__ import annotations

import os

from piilot.sdk import Context

# Env vars carrying the Azure App Registration. PLT-37 introduced these
# for the SSO login flow; we reuse the same client id (same Azure app)
# to avoid asking customers to register two apps. The plugin scopes
# (Mail.*, Files.*, Sites.*, Chat.*) are added on top of the SSO scopes
# (openid, email, profile) at consent time — Microsoft Entra merges
# them into a single user grant.
ENV_CLIENT_ID = "MICROSOFT_CLIENT_ID"
ENV_TENANT_ID = "MICROSOFT_TENANT_ID"


# v0.1 scope set — fine-grained delegated permissions. The company
# admin chooses which subset to actually enable in Settings → M365
# (Phase 3). The OAuth flow only requests the enabled scopes, so a
# company that only ticks "Outlook read" never leaks broader access.
SCOPE_GROUPS: dict[str, list[str]] = {
    "outlook.read": ["Mail.Read"],
    "outlook.write": ["Mail.Send", "Mail.ReadWrite"],
    "onedrive.read": ["Files.Read"],
    "onedrive.write": ["Files.ReadWrite"],
    "sharepoint.read": ["Sites.Read.All"],
    "sharepoint.write": ["Sites.ReadWrite.All"],
    "teams.read": ["Chat.Read", "ChannelMessage.Read.All"],
    "teams.write": ["Chat.ReadWrite", "ChannelMessage.Send"],
}

# Scopes that *require* admin consent in Microsoft Entra. The plugin
# detects this list at OAuth time and surfaces a "Ask your admin to
# authorise the app" message when the user can't consent on their own.
SCOPES_REQUIRING_ADMIN_CONSENT: frozenset[str] = frozenset(
    {
        "Sites.Read.All",
        "Sites.ReadWrite.All",
        "ChannelMessage.Read.All",
        # Files.ReadWrite is OK as user-delegated but Files.ReadWrite.All
        # would need admin consent — we only request Files.ReadWrite v0.1.
    }
)


def is_configured() -> bool:
    """True when the Azure App Registration env vars are populated.

    The plugin can load without these (in dev), but ``whoami`` and the
    OAuth flow can't run. The Settings page shows an actionable error
    when this is false, pointing to the Coolify env vars.
    """
    return bool(os.getenv(ENV_CLIENT_ID)) and bool(os.getenv(ENV_TENANT_ID))


def required_scopes_for(enabled_permissions: list[str]) -> list[str]:
    """Map admin-toggled permission ids to the actual Graph scope strings.

    Unknown permission ids are silently dropped — they may belong to
    a future plugin version that ships a wider permission set.
    """
    out: list[str] = []
    seen: set[str] = set()
    for perm_id in enabled_permissions:
        for scope in SCOPE_GROUPS.get(perm_id, ()):
            if scope not in seen:
                seen.add(scope)
                out.append(scope)
    return out


def admin_consent_required(scopes: list[str]) -> list[str]:
    """Return the subset of ``scopes`` that need admin consent."""
    return [s for s in scopes if s in SCOPES_REQUIRING_ADMIN_CONSENT]


def register_connector(ctx: Context) -> None:
    """Register the connector type with the SDK.

    Phase 1 is informational: the connector is visible in the admin UI
    but has no stored credentials yet. Phase 2 will provide the OAuth
    flow + token persistence.
    """
    # The SDK exposes register_connector(spec) — a dict-based API. The
    # actual per-company tokens are persisted by this plugin's own
    # _db.py (Fernet-encrypted via piilot.sdk.crypto) rather than via
    # ctx.connectors.save_connection — but declaring the credentials
    # schema here is still required so the host's UI knows the
    # connector type exists.
    ctx.connectors.register_connector(
        {
            "id": "microsoft_365.graph",
            "auth_type": "oauth2",
            "credentials_schema": [
                {"name": "access_token", "type": "secret", "required": True},
                {"name": "refresh_token", "type": "secret", "required": True},
                {"name": "token_expires_at", "type": "datetime"},
                {"name": "scopes", "type": "array"},
            ],
        }
    )
