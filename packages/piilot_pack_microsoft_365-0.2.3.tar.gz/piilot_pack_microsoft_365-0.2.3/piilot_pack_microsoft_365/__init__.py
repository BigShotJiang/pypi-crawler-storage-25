"""piilot-pack-microsoft-365 — Microsoft 365 connector for Piilot.

Plugin namespace: ``microsoft_365``.

Surface v0.1 (cf C11):
  - Outlook (mail) — read/write, writes via 2-step draft pattern
  - OneDrive (files) — read/write
  - SharePoint (sites/files) — read/write (admin consent required)
  - Teams (chats/channels) — read/write (admin consent required)

All scopes are gated by an admin-company-level toggle (8 toggles total,
cf ``permissions`` in pyproject.toml). Writes use the **2-step draft
pattern** rather than session-event HITL: the LLM calls
``create_draft`` first, the user reviews the draft in their inbox /
draft folder, the LLM only triggers ``send_draft`` after explicit
user confirmation. Microsoft's drafts folder is the visible audit
trail.

v0.1 surface (all 8 phases shipped):
  - Scaffolding + GraphAPIClient + whoami
  - OAuth flow E2E (token storage, proactive refresh)
  - Granular per-company toggles (8 permissions, fail-closed)
  - Outlook tools (search/read/list + create_draft/send_draft)
  - OneDrive tools (search/list/download + prepare_upload/confirm_upload)
  - SharePoint tools + admin consent flow
  - Teams tools (chats, channels, send via 2-step intent)
"""

from __future__ import annotations

from piilot.sdk import Plugin as _BasePlugin
from piilot.sdk import Context
from piilot.sdk.modules import register_module

from ._version import __version__
from .connector import register_connector
from .tools.whoami import register_tools as _register_whoami
from .tools.outlook import register_tools as _register_outlook
from .tools.onedrive import register_tools as _register_onedrive
from .tools.sharepoint import register_tools as _register_sharepoint
from .tools.teams import register_tools as _register_teams
from .routes import register_routes as _register_routes

NAMESPACE = "microsoft_365"


# The frontend plugin registers its settings view under this slug —
# it must match the ``module_slug`` we seed below. Mismatch silently
# disables the UI (the host falls back to the generic step runner).
SETTINGS_MODULE_SLUG = "microsoft-365-settings"


class Plugin(_BasePlugin):
    """Entry point invoked by ``backend.services.plugins`` at boot.

    The loader discovers this class via the ``[project.entry-points."piilot.plugins"]``
    metadata in ``pyproject.toml`` and calls :meth:`register` once per
    process. ``register()`` is the only place where the plugin can
    interact with core systems — everything else is on-demand at
    request time.
    """

    namespace = NAMESPACE
    version = __version__

    def register(self, ctx: Context) -> None:
        """Wire the plugin into the core."""
        # Plugin-owned schema migrations under ``piilot_pack_microsoft_365/
        # migrations/``. The plugin runtime applies pending .sql files at
        # boot (idempotent — IF NOT EXISTS / DROP POLICY IF EXISTS
        # everywhere). Replaces the legacy core mig
        # ``backend/migrations/110_microsoft_365_integrations.sql`` shipped
        # for plugin versions 0.1.x → 0.2.2.
        ctx.migrations.register_schema(
            "microsoft_365",
            __file__,
            "migrations",
        )

        register_connector(ctx)
        _register_whoami(ctx)
        _register_outlook(ctx)
        _register_onedrive(ctx)
        _register_sharepoint(ctx)
        _register_teams(ctx)
        _register_routes(ctx)

        # Seed a virtual "Microsoft 365" module so the host's
        # ``/modules/<slug>`` route resolves to the plugin's
        # ``MicrosoftSettingsView`` (registered frontend-side).
        # ``status='published'`` makes it visible in the Modules
        # section; ``category='integration'`` slots it into the right
        # group on the dashboard.
        register_module(
            {
                "slug": SETTINGS_MODULE_SLUG,
                "module_name": "Microsoft 365",
                "description": (
                    "Connect Microsoft 365 (Outlook, OneDrive, "
                    "SharePoint, Teams) and toggle which scopes the "
                    "agents may use."
                ),
                "icon": "microsoft",
                "category": "integration",
                "status": "published",
                "company_id": None,  # global — visible to every company
            },
        )
