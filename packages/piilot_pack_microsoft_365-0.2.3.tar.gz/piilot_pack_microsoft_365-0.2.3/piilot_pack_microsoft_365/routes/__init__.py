"""HTTP routes shipped by the M365 plugin.

Mounted under ``/plugins/microsoft_365/...`` by the core loader. The
sub-modules each expose ``router`` (a ``FastAPI.APIRouter``) plus a
``mount_path`` indicating the suffix used by ``register_router``.
"""

from piilot.sdk.http import register_router

from .oauth import router as oauth_router
from .scopes import router as scopes_router


def register_routes(
    ctx,
) -> None:  # noqa: ANN001 — Context not used, kept for API parity
    """Register all M365 plugin routers via the SDK.

    Mount paths (after loader prefixing):

      - /plugins/microsoft_365/oauth/{authorize-url,callback,status,disconnect}
      - /plugins/microsoft_365/scopes

    ``register_router`` is the standalone module-level function from
    ``piilot.sdk.http`` — there is no ``ctx.http`` registry; the Context
    dataclass exposes ``handlers/tools/templates/migrations/i18n/connectors/
    scheduler/events`` only. Routes/tools/templates use module-level
    primitives that read the ``current_plugin`` contextvar set by the
    loader around ``Plugin.register()``.
    """
    register_router(oauth_router, prefix="/oauth")
    register_router(scopes_router, prefix="/scopes")
