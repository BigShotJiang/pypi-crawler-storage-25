"""OAuth routes for the M365 plugin.

  - GET  /authorize-url        admin-only — returns the Microsoft consent URL
  - GET  /callback             public (no auth needed) — Microsoft redirects here
  - GET  /admin-consent-url    admin-only — for tenants needing tenant grant
  - GET  /status               admin-only — connection status snapshot
  - POST /disconnect           admin-only — drop tokens

The callback is the only public route — Microsoft's redirect doesn't
carry our session cookie / JWT. We bind the company via the ``state``
parameter (``{company_id}:{nonce}``) generated when the admin clicks
"Connect Microsoft 365" in Settings. The route validates the state's
shape but the deeper validation (does the company exist, is the user
an admin) happened at authorize-url generation time — by the time
the callback fires the consent has already been granted on Microsoft's
side, so denying here would just leave a granted-but-unused consent.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, HTTPException, Request, status
from fastapi.responses import JSONResponse, RedirectResponse
from pydantic import BaseModel, Field

from piilot.sdk.db import run_in_thread
from piilot.sdk.http import require_admin

from .. import _db, oauth
from ..client import GraphAPIClient, GraphError

logger = logging.getLogger(__name__)


router = APIRouter()


class AuthorizeUrlResponse(BaseModel):
    authorize_url: str
    state: str
    requested_scopes: list[str]
    requires_admin_consent: list[str]


class StatusResponse(BaseModel):
    connected: bool
    user_principal_name: str | None = None
    display_name: str | None = None
    tenant_id: str | None = None
    scopes_granted: list[str] = Field(default_factory=list)
    admin_consent_granted: bool = False
    expires_at: str | None = None
    last_used_at: str | None = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _redirect_uri(request: Request) -> str:
    """Build the absolute callback URL the auth flow uses.

    Microsoft's Azure App Registration whitelist must include this
    exact URI. Using ``request.url_for`` keeps the host/port aligned
    with what FastAPI is actually serving, so dev (localhost) and
    prod (api.piilot.ai) both work without env-var juggling.
    """
    return str(request.url_for("microsoft_365_oauth_callback"))


def _scopes_for_company(company_id: str) -> list[str]:
    """Read the per-scope toggles, map enabled ones to Graph scopes."""
    from ..connector import required_scopes_for

    enabled_perms: list[str] = []
    rows = _db.list_scope_grants(company_id)
    for row in rows:
        if row.get("enabled"):
            enabled_perms.append(row["permission_id"])
    return required_scopes_for(enabled_perms)


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@router.get("/authorize-url", response_model=AuthorizeUrlResponse)
async def get_authorize_url(request: Request) -> AuthorizeUrlResponse:
    """Build the Microsoft consent URL for the caller's company.

    The URL contains the scopes derived from the company's enabled
    toggles. Toggling a permission OFF after a connection exists does
    NOT revoke the token — admin must explicitly disconnect.
    """
    _user_id, _role, company_id = require_admin(request)
    if not company_id:
        raise HTTPException(status_code=400, detail="No company context")

    try:
        oauth._ensure_configured()
    except oauth.OAuthConfigError as exc:
        raise HTTPException(
            status_code=503,
            detail={"code": exc.code, "error": str(exc)},
        )

    scopes = await run_in_thread(_scopes_for_company, str(company_id))
    if not scopes:
        # Fail-closed: no toggle ON means there's no scope to ask for.
        raise HTTPException(
            status_code=400,
            detail={
                "code": "no_scopes_enabled",
                "error": (
                    "Aucune permission Microsoft 365 n'est activée pour cette "
                    "company. Activez au moins une permission dans Paramètres "
                    "→ Microsoft 365 avant de connecter."
                ),
            },
        )

    state = oauth.generate_state(str(company_id))
    authorize_url = oauth.build_authorize_url(
        scopes=scopes,
        redirect_uri=_redirect_uri(request),
        state=state,
    )

    from ..connector import admin_consent_required

    needs_admin = admin_consent_required(scopes)
    return AuthorizeUrlResponse(
        authorize_url=authorize_url,
        state=state,
        requested_scopes=scopes,
        requires_admin_consent=needs_admin,
    )


@router.get("/admin-consent-url")
async def get_admin_consent_url(request: Request):
    """Build the admin-consent URL the company admin can forward to
    their Microsoft tenant administrator. Only useful when the toggles
    require ``.All`` scopes.
    """
    _user_id, _role, company_id = require_admin(request)
    if not company_id:
        raise HTTPException(status_code=400, detail="No company context")

    try:
        oauth._ensure_configured()
    except oauth.OAuthConfigError as exc:
        raise HTTPException(
            status_code=503,
            detail={"code": exc.code, "error": str(exc)},
        )

    state = oauth.generate_state(str(company_id))
    return JSONResponse(
        {
            "admin_consent_url": oauth.build_admin_consent_url(
                redirect_uri=_redirect_uri(request),
                state=state,
            ),
            "state": state,
        }
    )


@router.get("/callback", name="microsoft_365_oauth_callback")
async def oauth_callback(request: Request):
    """Microsoft's redirect target after the user grants consent.

    Public route (no admin gate) — Microsoft doesn't propagate our
    session. The ``state`` token binds the redirect to a company.
    """
    code = request.query_params.get("code")
    state = request.query_params.get("state") or ""
    error = request.query_params.get("error")

    if error:
        # User denied consent or Microsoft rejected the request.
        return RedirectResponse(
            url=_settings_redirect(request, status_param=f"error:{error}"),
        )

    if not code:
        return RedirectResponse(
            url=_settings_redirect(request, status_param="error:missing_code"),
        )

    try:
        company_id, _nonce = oauth.parse_state(state)
    except oauth.OAuthError:
        return RedirectResponse(
            url=_settings_redirect(request, status_param="error:invalid_state"),
        )

    try:
        tokens = await oauth.exchange_code(
            code=code,
            redirect_uri=_redirect_uri(request),
        )
    except oauth.OAuthError as exc:
        logger.warning("oauth_callback: token exchange failed: %s", exc)
        return RedirectResponse(
            url=_settings_redirect(request, status_param=f"error:{exc.code}"),
        )

    # Probe /me to enrich the connection record with the user identity.
    profile = await _fetch_me(tokens["access_token"])

    # Compare requested vs granted scopes to detect missing admin
    # consent. Requested = the scopes the company toggles imply.
    try:
        requested = await run_in_thread(_scopes_for_company, company_id)
    except Exception:
        requested = []
    admin_consent_ok = oauth.admin_consent_satisfies(
        requested_scopes=requested,
        granted_scopes=tokens["scopes_granted"],
    )

    try:
        await run_in_thread(
            _db.upsert_connection,
            company_id=company_id,
            user_principal_name=profile.get("upn") or "(unknown)",
            display_name=profile.get("display_name"),
            tenant_id=profile.get("tenant_id"),
            access_token=tokens["access_token"],
            refresh_token=tokens.get("refresh_token"),
            expires_at=tokens["expires_at"],
            scopes_granted=tokens["scopes_granted"],
            admin_consent_granted=admin_consent_ok,
            connected_by=None,  # callback has no JWT, can't trace
        )
    except Exception:
        logger.exception("oauth_callback: persisting connection failed")
        return RedirectResponse(
            url=_settings_redirect(request, status_param="error:storage_failed"),
        )

    return RedirectResponse(
        url=_settings_redirect(request, status_param="connected"),
    )


@router.get("/status", response_model=StatusResponse)
async def connection_status(request: Request) -> StatusResponse:
    """Return the current M365 connection state for the caller's company."""
    _user_id, _role, company_id = require_admin(request)
    if not company_id:
        raise HTTPException(status_code=400, detail="No company context")

    connection = await run_in_thread(_db.get_connection, str(company_id))
    if not connection:
        return StatusResponse(connected=False)

    return StatusResponse(
        connected=True,
        user_principal_name=connection.get("user_principal_name"),
        display_name=connection.get("display_name"),
        tenant_id=connection.get("tenant_id"),
        scopes_granted=list(connection.get("scopes_granted") or []),
        admin_consent_granted=bool(connection.get("admin_consent_granted")),
        expires_at=_serialise_dt(connection.get("expires_at")),
        last_used_at=_serialise_dt(connection.get("last_used_at")),
    )


@router.post("/disconnect", status_code=status.HTTP_204_NO_CONTENT)
async def disconnect(request: Request):
    """Drop the M365 connection. Future calls return ``M365_NOT_CONNECTED``
    until the admin re-connects."""
    _user_id, _role, company_id = require_admin(request)
    if not company_id:
        raise HTTPException(status_code=400, detail="No company context")

    await run_in_thread(_db.delete_connection, str(company_id))
    return None


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _settings_redirect(request: Request, *, status_param: str) -> str:
    """Build a redirect back to the frontend Settings page with a
    status query parameter the UI uses to render a banner.
    """
    # The frontend lives at the same origin in dev (Vite + FastAPI
    # proxy) and at FRONTEND_URL in prod. We use FRONTEND_URL when
    # set, falling back to the request's origin.
    import os

    base = os.getenv("FRONTEND_URL") or str(request.base_url).rstrip("/")
    return f"{base}/settings/microsoft-365?status={status_param}"


def _serialise_dt(value: Any) -> str | None:
    if value is None:
        return None
    try:
        return value.isoformat()
    except AttributeError:
        return str(value)


_graph_client: GraphAPIClient | None = None


def _get_graph_client() -> GraphAPIClient:
    global _graph_client
    if _graph_client is None:
        _graph_client = GraphAPIClient()
    return _graph_client


async def _fetch_me(access_token: str) -> dict[str, Any]:
    """Light /me probe — best-effort, never raises."""
    try:
        body = await _get_graph_client().get("me", access_token=access_token)
    except GraphError:
        return {"upn": None, "display_name": None, "tenant_id": None}
    return {
        "upn": body.get("userPrincipalName") or body.get("mail"),
        "display_name": body.get("displayName"),
        # The tenant id isn't returned directly by /me; we infer it
        # from the user's id when it has the AAD shape "guid@tenantguid".
        "tenant_id": (
            (body.get("id") or "").split("@")[-1]
            if "@" in (body.get("id") or "")
            else None
        ),
    }
