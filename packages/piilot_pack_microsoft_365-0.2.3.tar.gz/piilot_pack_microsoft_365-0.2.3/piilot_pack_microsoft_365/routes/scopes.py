"""Scope-toggle routes for the M365 plugin.

  - GET /        admin-only — return all 8 toggles + their state
  - PUT /        admin-only — update one or more toggles

The UI in Settings → Microsoft 365 calls these to render and persist
the per-scope checkboxes. Toggling a scope OFF after a connection
exists does NOT revoke the Microsoft tokens — disconnect is a
separate explicit action. The plugin's tools however immediately
stop accepting calls for the OFF permission (next ``ensure_permission``
read returns False).
"""

from __future__ import annotations

import logging
from typing import Literal

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, ConfigDict, Field

from piilot.sdk.db import run_in_thread
from piilot.sdk.http import require_admin

from .. import _db
from ..connector import SCOPE_GROUPS

logger = logging.getLogger(__name__)


router = APIRouter()


PermissionId = Literal[
    "outlook.read",
    "outlook.write",
    "onedrive.read",
    "onedrive.write",
    "sharepoint.read",
    "sharepoint.write",
    "teams.read",
    "teams.write",
]


# All 8 permissions surface in the UI even when the company has never
# touched them — frontend wants a stable list of toggles.
_CANONICAL_PERMISSIONS: tuple[PermissionId, ...] = (
    "outlook.read",
    "outlook.write",
    "onedrive.read",
    "onedrive.write",
    "sharepoint.read",
    "sharepoint.write",
    "teams.read",
    "teams.write",
)


class ScopeToggle(BaseModel):
    permission_id: PermissionId
    enabled: bool
    granted_at: str | None = None
    revoked_at: str | None = None


class ScopesListResponse(BaseModel):
    toggles: list[ScopeToggle]


class ScopeUpdateItem(BaseModel):
    model_config = ConfigDict(extra="forbid")

    permission_id: PermissionId
    enabled: bool


class ScopesUpdateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    toggles: list[ScopeUpdateItem] = Field(..., min_length=1, max_length=8)


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@router.get("/", response_model=ScopesListResponse)
async def list_scopes(request: Request) -> ScopesListResponse:
    """Return the 8 toggles + their current state for the caller's company.

    Permissions never toggled appear with ``enabled=false`` and null
    timestamps. The frontend uses this to render the Settings page
    without a separate "exists?" check per row.
    """
    _user_id, _role, company_id = require_admin(request)
    if not company_id:
        raise HTTPException(status_code=400, detail="No company context")

    rows = await run_in_thread(_db.list_scope_grants, str(company_id))
    by_permission: dict[str, dict] = {r["permission_id"]: r for r in rows}

    out: list[ScopeToggle] = []
    for perm in _CANONICAL_PERMISSIONS:
        row = by_permission.get(perm)
        out.append(
            ScopeToggle(
                permission_id=perm,
                enabled=bool(row and row.get("enabled")),
                granted_at=_serialise_dt(row.get("granted_at")) if row else None,
                revoked_at=_serialise_dt(row.get("revoked_at")) if row else None,
            )
        )
    return ScopesListResponse(toggles=out)


@router.put("/", response_model=ScopesListResponse)
async def update_scopes(
    request: Request, body: ScopesUpdateRequest
) -> ScopesListResponse:
    """Update one or more scope toggles.

    The body lists exactly the toggles that change — omitted toggles
    keep their current state. Each entry's ``permission_id`` is bound
    to the canonical 8-value enum (extra fields refused, unknown ids
    rejected by the Pydantic ``Literal`` validation).
    """
    user_id, _role, company_id = require_admin(request)
    if not company_id:
        raise HTTPException(status_code=400, detail="No company context")

    # Defensive — Pydantic already enforces uniqueness through the
    # Literal type but we double-check at the service boundary so a
    # repeated permission_id doesn't generate two UPSERTs in series.
    seen: set[str] = set()
    for item in body.toggles:
        if item.permission_id in seen:
            raise HTTPException(
                status_code=422,
                detail={
                    "code": "duplicate_permission",
                    "permission_id": item.permission_id,
                },
            )
        seen.add(item.permission_id)

    # Validate that every requested perm is in the SCOPE_GROUPS table —
    # otherwise the connector layer would crash later when building the
    # scope set. Belt + braces with the Literal validation above.
    for item in body.toggles:
        if item.permission_id not in SCOPE_GROUPS:
            raise HTTPException(
                status_code=422,
                detail={
                    "code": "unknown_permission",
                    "permission_id": item.permission_id,
                },
            )

    def _apply():
        for item in body.toggles:
            _db.upsert_scope_grant(
                company_id=str(company_id),
                permission_id=item.permission_id,
                enabled=item.enabled,
                granted_by=str(user_id) if user_id else None,
            )

    await run_in_thread(_apply)

    # Round-trip the new state — the frontend uses it directly to
    # update its store without a follow-up GET.
    return await list_scopes(request)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _serialise_dt(value) -> str | None:  # noqa: ANN001
    if value is None:
        return None
    try:
        return value.isoformat()
    except AttributeError:
        return str(value)
