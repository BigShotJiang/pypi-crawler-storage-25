"""Single source of truth for the plugin version.

Bumped manually on each release. Mirrored in ``pyproject.toml`` —
keeping both in sync is enforced by CI in the extracted repo (Phase 8).
"""

__version__ = "0.2.3"
