# Copyright (C) Microsoft Corporation. All rights reserved.
"""Low-level ctypes bindings for the WinML EP Catalog and Model Catalog C APIs."""

import ctypes
import ctypes.wintypes as wintypes
import os
import sys
from enum import IntEnum

if sys.platform != "win32":
    raise ImportError("winml is only supported on Windows")

# ---------------------------------------------------------------------------
# DLL Loading
# ---------------------------------------------------------------------------

_DLL_NAME = "Microsoft.Windows.AI.MachineLearning.dll"

_lib_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "lib")
_bundled_path = os.path.join(_lib_dir, _DLL_NAME)

if not os.path.isfile(_bundled_path):
    raise FileNotFoundError(
        f"{_DLL_NAME} not found in {_lib_dir}. "
    )

_dll = ctypes.WinDLL(_bundled_path)

# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class EpReadyState(IntEnum):
    """Execution provider readiness state."""
    Ready = 0
    NotReady = 1
    NotPresent = 2


class EpCertification(IntEnum):
    """Execution provider certification status."""
    Unknown = 0
    Certified = 1
    Uncertified = 2


class CatalogModelInstanceStatus(IntEnum):
    """Model instance availability status."""
    Available = 0
    InProgress = 1
    Unavailable = 2


class CatalogModelStatus(IntEnum):
    """Model readiness status."""
    Ready = 0
    NotReady = 1


# ---------------------------------------------------------------------------
# Opaque Handle Types
# ---------------------------------------------------------------------------

class _EpCatalogOpaque(ctypes.Structure):
    pass


class _EpOpaque(ctypes.Structure):
    pass


EpCatalogHandle = ctypes.POINTER(_EpCatalogOpaque)
EpHandle = ctypes.POINTER(_EpOpaque)


class _ModelCatalogSourceOpaque(ctypes.Structure):
    pass


class _ModelCatalogOpaque(ctypes.Structure):
    pass


class _CatalogModelInfoOpaque(ctypes.Structure):
    pass


class _CatalogModelInstanceOpaque(ctypes.Structure):
    pass


ModelCatalogSourceHandle = ctypes.POINTER(_ModelCatalogSourceOpaque)
ModelCatalogHandle = ctypes.POINTER(_ModelCatalogOpaque)
CatalogModelInfoHandle = ctypes.POINTER(_CatalogModelInfoOpaque)
CatalogModelInstanceHandle = ctypes.POINTER(_CatalogModelInstanceOpaque)

# ---------------------------------------------------------------------------
# Structs
# ---------------------------------------------------------------------------


class EpInfo(ctypes.Structure):
    """Mirrors the native WinMLEpInfo structure."""
    _fields_ = [
        ("name", ctypes.c_char_p),
        ("version", ctypes.c_char_p),
        ("packageFamilyName", ctypes.c_char_p),
        ("libraryPath", ctypes.c_char_p),
        ("packageRootPath", ctypes.c_char_p),
        ("readyState", ctypes.c_int),
        ("certification", ctypes.c_int),
    ]


class CatalogModelInstanceResult(ctypes.Structure):
    """Mirrors the native WinMLCatalogModelInstanceResult structure."""
    _fields_ = [
        ("status", ctypes.c_int),
        ("extendedError", ctypes.HRESULT),
        ("instance", CatalogModelInstanceHandle),
    ]


class AsyncBlock(ctypes.Structure):
    """Mirrors the native WinMLAsyncBlock structure."""
    pass


AsyncCompletionCallback = ctypes.WINFUNCTYPE(
    None,
    ctypes.POINTER(AsyncBlock),
)

AsyncProgressCallback = ctypes.WINFUNCTYPE(
    None,
    ctypes.POINTER(AsyncBlock),
    ctypes.c_double,
)

AsyncBlock._fields_ = [
    ("context", ctypes.c_void_p),
    ("callback", AsyncCompletionCallback),
    ("progress", AsyncProgressCallback),
]

# ---------------------------------------------------------------------------
# Callback Types
# ---------------------------------------------------------------------------

EpEnumCallback = ctypes.WINFUNCTYPE(
    wintypes.BOOL,
    EpHandle,
    ctypes.POINTER(EpInfo),
    ctypes.c_void_p,
)

StringEnumCallback = ctypes.WINFUNCTYPE(
    wintypes.BOOL,
    ctypes.c_char_p,
    ctypes.c_void_p,
)

CatalogModelInfoEnumCallback = ctypes.WINFUNCTYPE(
    wintypes.BOOL,
    CatalogModelInfoHandle,
    ctypes.c_void_p,
)

# ---------------------------------------------------------------------------
# Function Signatures
# ---------------------------------------------------------------------------

# Catalog lifetime
WinMLEpCatalogCreate = _dll.WinMLEpCatalogCreate
WinMLEpCatalogCreate.argtypes = [ctypes.POINTER(EpCatalogHandle)]
WinMLEpCatalogCreate.restype = ctypes.HRESULT

WinMLEpCatalogRelease = _dll.WinMLEpCatalogRelease
WinMLEpCatalogRelease.argtypes = [EpCatalogHandle]
WinMLEpCatalogRelease.restype = None

# Catalog enumeration / lookup
WinMLEpCatalogEnumProviders = _dll.WinMLEpCatalogEnumProviders
WinMLEpCatalogEnumProviders.argtypes = [EpCatalogHandle, EpEnumCallback, ctypes.c_void_p]
WinMLEpCatalogEnumProviders.restype = ctypes.HRESULT

WinMLEpCatalogFindProvider = _dll.WinMLEpCatalogFindProvider
WinMLEpCatalogFindProvider.argtypes = [
    EpCatalogHandle,
    ctypes.c_char_p,
    ctypes.c_char_p,
    ctypes.POINTER(EpHandle),
]
WinMLEpCatalogFindProvider.restype = ctypes.HRESULT

# EP property getters — name
WinMLEpGetNameSize = _dll.WinMLEpGetNameSize
WinMLEpGetNameSize.argtypes = [EpHandle, ctypes.POINTER(ctypes.c_size_t)]
WinMLEpGetNameSize.restype = ctypes.HRESULT

WinMLEpGetName = _dll.WinMLEpGetName
WinMLEpGetName.argtypes = [EpHandle, ctypes.c_size_t, ctypes.POINTER(ctypes.c_char), ctypes.POINTER(ctypes.c_size_t)]
WinMLEpGetName.restype = ctypes.HRESULT

# EP property getters — version
WinMLEpGetVersionSize = _dll.WinMLEpGetVersionSize
WinMLEpGetVersionSize.argtypes = [EpHandle, ctypes.POINTER(ctypes.c_size_t)]
WinMLEpGetVersionSize.restype = ctypes.HRESULT

WinMLEpGetVersion = _dll.WinMLEpGetVersion
WinMLEpGetVersion.argtypes = [EpHandle, ctypes.c_size_t, ctypes.POINTER(ctypes.c_char), ctypes.POINTER(ctypes.c_size_t)]
WinMLEpGetVersion.restype = ctypes.HRESULT

# EP property getters — package family name
WinMLEpGetPackageFamilyNameSize = _dll.WinMLEpGetPackageFamilyNameSize
WinMLEpGetPackageFamilyNameSize.argtypes = [EpHandle, ctypes.POINTER(ctypes.c_size_t)]
WinMLEpGetPackageFamilyNameSize.restype = ctypes.HRESULT

WinMLEpGetPackageFamilyName = _dll.WinMLEpGetPackageFamilyName
WinMLEpGetPackageFamilyName.argtypes = [EpHandle, ctypes.c_size_t, ctypes.POINTER(ctypes.c_char), ctypes.POINTER(ctypes.c_size_t)]
WinMLEpGetPackageFamilyName.restype = ctypes.HRESULT

# EP property getters — library path
WinMLEpGetLibraryPathSize = _dll.WinMLEpGetLibraryPathSize
WinMLEpGetLibraryPathSize.argtypes = [EpHandle, ctypes.POINTER(ctypes.c_size_t)]
WinMLEpGetLibraryPathSize.restype = ctypes.HRESULT

WinMLEpGetLibraryPath = _dll.WinMLEpGetLibraryPath
WinMLEpGetLibraryPath.argtypes = [EpHandle, ctypes.c_size_t, ctypes.POINTER(ctypes.c_char), ctypes.POINTER(ctypes.c_size_t)]
WinMLEpGetLibraryPath.restype = ctypes.HRESULT

# EP property getters — package root path
WinMLEpGetPackageRootPathSize = _dll.WinMLEpGetPackageRootPathSize
WinMLEpGetPackageRootPathSize.argtypes = [EpHandle, ctypes.POINTER(ctypes.c_size_t)]
WinMLEpGetPackageRootPathSize.restype = ctypes.HRESULT

WinMLEpGetPackageRootPath = _dll.WinMLEpGetPackageRootPath
WinMLEpGetPackageRootPath.argtypes = [EpHandle, ctypes.c_size_t, ctypes.POINTER(ctypes.c_char), ctypes.POINTER(ctypes.c_size_t)]
WinMLEpGetPackageRootPath.restype = ctypes.HRESULT

# EP state
WinMLEpGetReadyState = _dll.WinMLEpGetReadyState
WinMLEpGetReadyState.argtypes = [EpHandle, ctypes.POINTER(ctypes.c_int)]
WinMLEpGetReadyState.restype = ctypes.HRESULT

WinMLEpGetCertification = _dll.WinMLEpGetCertification
WinMLEpGetCertification.argtypes = [EpHandle, ctypes.POINTER(ctypes.c_int)]
WinMLEpGetCertification.restype = ctypes.HRESULT

WinMLEpEnsureReady = _dll.WinMLEpEnsureReady
WinMLEpEnsureReady.argtypes = [EpHandle]
WinMLEpEnsureReady.restype = ctypes.HRESULT

# Async operations
WinMLEpEnsureReadyAsync = _dll.WinMLEpEnsureReadyAsync
WinMLEpEnsureReadyAsync.argtypes = [EpHandle, ctypes.POINTER(AsyncBlock)]
WinMLEpEnsureReadyAsync.restype = ctypes.HRESULT

WinMLAsyncGetStatus = _dll.WinMLAsyncGetStatus
WinMLAsyncGetStatus.argtypes = [ctypes.POINTER(AsyncBlock), wintypes.BOOL]
WinMLAsyncGetStatus.restype = ctypes.HRESULT

WinMLAsyncCancel = _dll.WinMLAsyncCancel
WinMLAsyncCancel.argtypes = [ctypes.POINTER(AsyncBlock)]
WinMLAsyncCancel.restype = ctypes.HRESULT

WinMLAsyncClose = _dll.WinMLAsyncClose
WinMLAsyncClose.argtypes = [ctypes.POINTER(AsyncBlock)]
WinMLAsyncClose.restype = None

# ---------------------------------------------------------------------------
# Model Catalog Source
# ---------------------------------------------------------------------------

WinMLModelCatalogSourceCreateFromUri = _dll.WinMLModelCatalogSourceCreateFromUri
WinMLModelCatalogSourceCreateFromUri.argtypes = [ctypes.c_char_p, ctypes.POINTER(ModelCatalogSourceHandle)]
WinMLModelCatalogSourceCreateFromUri.restype = ctypes.HRESULT

WinMLModelCatalogSourceCreateFromUriAsync = _dll.WinMLModelCatalogSourceCreateFromUriAsync
WinMLModelCatalogSourceCreateFromUriAsync.argtypes = [ctypes.c_char_p, ctypes.POINTER(AsyncBlock)]
WinMLModelCatalogSourceCreateFromUriAsync.restype = ctypes.HRESULT

WinMLModelCatalogSourceCreateFromUriWithHeaders = _dll.WinMLModelCatalogSourceCreateFromUriWithHeaders
WinMLModelCatalogSourceCreateFromUriWithHeaders.argtypes = [
    ctypes.c_char_p, ctypes.c_size_t,
    ctypes.POINTER(ctypes.c_char_p), ctypes.POINTER(ctypes.c_char_p),
    ctypes.POINTER(ModelCatalogSourceHandle),
]
WinMLModelCatalogSourceCreateFromUriWithHeaders.restype = ctypes.HRESULT

WinMLModelCatalogSourceCreateFromUriWithHeadersAsync = _dll.WinMLModelCatalogSourceCreateFromUriWithHeadersAsync
WinMLModelCatalogSourceCreateFromUriWithHeadersAsync.argtypes = [
    ctypes.c_char_p, ctypes.c_size_t,
    ctypes.POINTER(ctypes.c_char_p), ctypes.POINTER(ctypes.c_char_p),
    ctypes.POINTER(AsyncBlock),
]
WinMLModelCatalogSourceCreateFromUriWithHeadersAsync.restype = ctypes.HRESULT

WinMLModelCatalogSourceGetResult = _dll.WinMLModelCatalogSourceGetResult
WinMLModelCatalogSourceGetResult.argtypes = [ctypes.POINTER(AsyncBlock), ctypes.POINTER(ModelCatalogSourceHandle)]
WinMLModelCatalogSourceGetResult.restype = ctypes.HRESULT

WinMLModelCatalogSourceRelease = _dll.WinMLModelCatalogSourceRelease
WinMLModelCatalogSourceRelease.argtypes = [ModelCatalogSourceHandle]
WinMLModelCatalogSourceRelease.restype = None

WinMLModelCatalogSourceGetIdSize = _dll.WinMLModelCatalogSourceGetIdSize
WinMLModelCatalogSourceGetIdSize.argtypes = [ModelCatalogSourceHandle, ctypes.POINTER(ctypes.c_size_t)]
WinMLModelCatalogSourceGetIdSize.restype = ctypes.HRESULT

WinMLModelCatalogSourceGetId = _dll.WinMLModelCatalogSourceGetId
WinMLModelCatalogSourceGetId.argtypes = [ModelCatalogSourceHandle, ctypes.c_size_t, ctypes.POINTER(ctypes.c_char), ctypes.POINTER(ctypes.c_size_t)]
WinMLModelCatalogSourceGetId.restype = ctypes.HRESULT

WinMLModelCatalogSourceGetUriSize = _dll.WinMLModelCatalogSourceGetUriSize
WinMLModelCatalogSourceGetUriSize.argtypes = [ModelCatalogSourceHandle, ctypes.POINTER(ctypes.c_size_t)]
WinMLModelCatalogSourceGetUriSize.restype = ctypes.HRESULT

WinMLModelCatalogSourceGetUri = _dll.WinMLModelCatalogSourceGetUri
WinMLModelCatalogSourceGetUri.argtypes = [ModelCatalogSourceHandle, ctypes.c_size_t, ctypes.POINTER(ctypes.c_char), ctypes.POINTER(ctypes.c_size_t)]
WinMLModelCatalogSourceGetUri.restype = ctypes.HRESULT

# ---------------------------------------------------------------------------
# Model Catalog
# ---------------------------------------------------------------------------

WinMLModelCatalogCreate = _dll.WinMLModelCatalogCreate
WinMLModelCatalogCreate.argtypes = [ctypes.c_size_t, ctypes.POINTER(ModelCatalogSourceHandle), ctypes.POINTER(ModelCatalogHandle)]
WinMLModelCatalogCreate.restype = ctypes.HRESULT

WinMLModelCatalogRelease = _dll.WinMLModelCatalogRelease
WinMLModelCatalogRelease.argtypes = [ModelCatalogHandle]
WinMLModelCatalogRelease.restype = None

WinMLModelCatalogEnumExecutionProviders = _dll.WinMLModelCatalogEnumExecutionProviders
WinMLModelCatalogEnumExecutionProviders.argtypes = [ModelCatalogHandle, StringEnumCallback, ctypes.c_void_p]
WinMLModelCatalogEnumExecutionProviders.restype = ctypes.HRESULT

WinMLModelCatalogSetExecutionProviders = _dll.WinMLModelCatalogSetExecutionProviders
WinMLModelCatalogSetExecutionProviders.argtypes = [ModelCatalogHandle, ctypes.c_size_t, ctypes.POINTER(ctypes.c_char_p)]
WinMLModelCatalogSetExecutionProviders.restype = ctypes.HRESULT

WinMLModelCatalogGetAvailableModel = _dll.WinMLModelCatalogGetAvailableModel
WinMLModelCatalogGetAvailableModel.argtypes = [ModelCatalogHandle, ctypes.c_char_p, ctypes.POINTER(CatalogModelInfoHandle)]
WinMLModelCatalogGetAvailableModel.restype = ctypes.HRESULT

WinMLModelCatalogGetAvailableModels = _dll.WinMLModelCatalogGetAvailableModels
WinMLModelCatalogGetAvailableModels.argtypes = [ModelCatalogHandle, CatalogModelInfoEnumCallback, ctypes.c_void_p]
WinMLModelCatalogGetAvailableModels.restype = ctypes.HRESULT

WinMLModelCatalogFindModel = _dll.WinMLModelCatalogFindModel
WinMLModelCatalogFindModel.argtypes = [ModelCatalogHandle, ctypes.c_char_p, ctypes.POINTER(CatalogModelInfoHandle)]
WinMLModelCatalogFindModel.restype = ctypes.HRESULT

WinMLModelCatalogFindModelAsync = _dll.WinMLModelCatalogFindModelAsync
WinMLModelCatalogFindModelAsync.argtypes = [ModelCatalogHandle, ctypes.c_char_p, ctypes.POINTER(AsyncBlock)]
WinMLModelCatalogFindModelAsync.restype = ctypes.HRESULT

WinMLModelCatalogFindAllModels = _dll.WinMLModelCatalogFindAllModels
WinMLModelCatalogFindAllModels.argtypes = [ModelCatalogHandle, CatalogModelInfoEnumCallback, ctypes.c_void_p]
WinMLModelCatalogFindAllModels.restype = ctypes.HRESULT

WinMLModelCatalogFindAllModelsAsync = _dll.WinMLModelCatalogFindAllModelsAsync
WinMLModelCatalogFindAllModelsAsync.argtypes = [ModelCatalogHandle, ctypes.POINTER(AsyncBlock)]
WinMLModelCatalogFindAllModelsAsync.restype = ctypes.HRESULT

WinMLModelCatalogFindModelGetResult = _dll.WinMLModelCatalogFindModelGetResult
WinMLModelCatalogFindModelGetResult.argtypes = [ctypes.POINTER(AsyncBlock), ctypes.POINTER(CatalogModelInfoHandle)]
WinMLModelCatalogFindModelGetResult.restype = ctypes.HRESULT

WinMLModelCatalogFindAllModelsGetResult = _dll.WinMLModelCatalogFindAllModelsGetResult
WinMLModelCatalogFindAllModelsGetResult.argtypes = [ctypes.POINTER(AsyncBlock), CatalogModelInfoEnumCallback, ctypes.c_void_p]
WinMLModelCatalogFindAllModelsGetResult.restype = ctypes.HRESULT

# ---------------------------------------------------------------------------
# Catalog Model Info
# ---------------------------------------------------------------------------

WinMLCatalogModelInfoRelease = _dll.WinMLCatalogModelInfoRelease
WinMLCatalogModelInfoRelease.argtypes = [CatalogModelInfoHandle]
WinMLCatalogModelInfoRelease.restype = None

WinMLCatalogModelInfoGetIdSize = _dll.WinMLCatalogModelInfoGetIdSize
WinMLCatalogModelInfoGetIdSize.argtypes = [CatalogModelInfoHandle, ctypes.POINTER(ctypes.c_size_t)]
WinMLCatalogModelInfoGetIdSize.restype = ctypes.HRESULT

WinMLCatalogModelInfoGetId = _dll.WinMLCatalogModelInfoGetId
WinMLCatalogModelInfoGetId.argtypes = [CatalogModelInfoHandle, ctypes.c_size_t, ctypes.POINTER(ctypes.c_char), ctypes.POINTER(ctypes.c_size_t)]
WinMLCatalogModelInfoGetId.restype = ctypes.HRESULT

WinMLCatalogModelInfoGetNameSize = _dll.WinMLCatalogModelInfoGetNameSize
WinMLCatalogModelInfoGetNameSize.argtypes = [CatalogModelInfoHandle, ctypes.POINTER(ctypes.c_size_t)]
WinMLCatalogModelInfoGetNameSize.restype = ctypes.HRESULT

WinMLCatalogModelInfoGetName = _dll.WinMLCatalogModelInfoGetName
WinMLCatalogModelInfoGetName.argtypes = [CatalogModelInfoHandle, ctypes.c_size_t, ctypes.POINTER(ctypes.c_char), ctypes.POINTER(ctypes.c_size_t)]
WinMLCatalogModelInfoGetName.restype = ctypes.HRESULT

WinMLCatalogModelInfoGetPublisherSize = _dll.WinMLCatalogModelInfoGetPublisherSize
WinMLCatalogModelInfoGetPublisherSize.argtypes = [CatalogModelInfoHandle, ctypes.POINTER(ctypes.c_size_t)]
WinMLCatalogModelInfoGetPublisherSize.restype = ctypes.HRESULT

WinMLCatalogModelInfoGetPublisher = _dll.WinMLCatalogModelInfoGetPublisher
WinMLCatalogModelInfoGetPublisher.argtypes = [CatalogModelInfoHandle, ctypes.c_size_t, ctypes.POINTER(ctypes.c_char), ctypes.POINTER(ctypes.c_size_t)]
WinMLCatalogModelInfoGetPublisher.restype = ctypes.HRESULT

WinMLCatalogModelInfoGetSourceIdSize = _dll.WinMLCatalogModelInfoGetSourceIdSize
WinMLCatalogModelInfoGetSourceIdSize.argtypes = [CatalogModelInfoHandle, ctypes.POINTER(ctypes.c_size_t)]
WinMLCatalogModelInfoGetSourceIdSize.restype = ctypes.HRESULT

WinMLCatalogModelInfoGetSourceId = _dll.WinMLCatalogModelInfoGetSourceId
WinMLCatalogModelInfoGetSourceId.argtypes = [CatalogModelInfoHandle, ctypes.c_size_t, ctypes.POINTER(ctypes.c_char), ctypes.POINTER(ctypes.c_size_t)]
WinMLCatalogModelInfoGetSourceId.restype = ctypes.HRESULT

WinMLCatalogModelInfoGetVersionSize = _dll.WinMLCatalogModelInfoGetVersionSize
WinMLCatalogModelInfoGetVersionSize.argtypes = [CatalogModelInfoHandle, ctypes.POINTER(ctypes.c_size_t)]
WinMLCatalogModelInfoGetVersionSize.restype = ctypes.HRESULT

WinMLCatalogModelInfoGetVersion = _dll.WinMLCatalogModelInfoGetVersion
WinMLCatalogModelInfoGetVersion.argtypes = [CatalogModelInfoHandle, ctypes.c_size_t, ctypes.POINTER(ctypes.c_char), ctypes.POINTER(ctypes.c_size_t)]
WinMLCatalogModelInfoGetVersion.restype = ctypes.HRESULT

WinMLCatalogModelInfoGetLicenseSize = _dll.WinMLCatalogModelInfoGetLicenseSize
WinMLCatalogModelInfoGetLicenseSize.argtypes = [CatalogModelInfoHandle, ctypes.POINTER(ctypes.c_size_t)]
WinMLCatalogModelInfoGetLicenseSize.restype = ctypes.HRESULT

WinMLCatalogModelInfoGetLicense = _dll.WinMLCatalogModelInfoGetLicense
WinMLCatalogModelInfoGetLicense.argtypes = [CatalogModelInfoHandle, ctypes.c_size_t, ctypes.POINTER(ctypes.c_char), ctypes.POINTER(ctypes.c_size_t)]
WinMLCatalogModelInfoGetLicense.restype = ctypes.HRESULT

WinMLCatalogModelInfoGetLicenseUriSize = _dll.WinMLCatalogModelInfoGetLicenseUriSize
WinMLCatalogModelInfoGetLicenseUriSize.argtypes = [CatalogModelInfoHandle, ctypes.POINTER(ctypes.c_size_t)]
WinMLCatalogModelInfoGetLicenseUriSize.restype = ctypes.HRESULT

WinMLCatalogModelInfoGetLicenseUri = _dll.WinMLCatalogModelInfoGetLicenseUri
WinMLCatalogModelInfoGetLicenseUri.argtypes = [CatalogModelInfoHandle, ctypes.c_size_t, ctypes.POINTER(ctypes.c_char), ctypes.POINTER(ctypes.c_size_t)]
WinMLCatalogModelInfoGetLicenseUri.restype = ctypes.HRESULT

WinMLCatalogModelInfoGetLicenseTextSize = _dll.WinMLCatalogModelInfoGetLicenseTextSize
WinMLCatalogModelInfoGetLicenseTextSize.argtypes = [CatalogModelInfoHandle, ctypes.POINTER(ctypes.c_size_t)]
WinMLCatalogModelInfoGetLicenseTextSize.restype = ctypes.HRESULT

WinMLCatalogModelInfoGetLicenseText = _dll.WinMLCatalogModelInfoGetLicenseText
WinMLCatalogModelInfoGetLicenseText.argtypes = [CatalogModelInfoHandle, ctypes.c_size_t, ctypes.POINTER(ctypes.c_char), ctypes.POINTER(ctypes.c_size_t)]
WinMLCatalogModelInfoGetLicenseText.restype = ctypes.HRESULT

WinMLCatalogModelInfoGetUriSize = _dll.WinMLCatalogModelInfoGetUriSize
WinMLCatalogModelInfoGetUriSize.argtypes = [CatalogModelInfoHandle, ctypes.POINTER(ctypes.c_size_t)]
WinMLCatalogModelInfoGetUriSize.restype = ctypes.HRESULT

WinMLCatalogModelInfoGetUri = _dll.WinMLCatalogModelInfoGetUri
WinMLCatalogModelInfoGetUri.argtypes = [CatalogModelInfoHandle, ctypes.c_size_t, ctypes.POINTER(ctypes.c_char), ctypes.POINTER(ctypes.c_size_t)]
WinMLCatalogModelInfoGetUri.restype = ctypes.HRESULT

WinMLCatalogModelInfoGetModelSizeInBytes = _dll.WinMLCatalogModelInfoGetModelSizeInBytes
WinMLCatalogModelInfoGetModelSizeInBytes.argtypes = [CatalogModelInfoHandle, ctypes.POINTER(ctypes.c_uint64)]
WinMLCatalogModelInfoGetModelSizeInBytes.restype = ctypes.HRESULT

WinMLCatalogModelInfoEnumExecutionProviders = _dll.WinMLCatalogModelInfoEnumExecutionProviders
WinMLCatalogModelInfoEnumExecutionProviders.argtypes = [CatalogModelInfoHandle, StringEnumCallback, ctypes.c_void_p]
WinMLCatalogModelInfoEnumExecutionProviders.restype = ctypes.HRESULT

WinMLCatalogModelInfoGetStatus = _dll.WinMLCatalogModelInfoGetStatus
WinMLCatalogModelInfoGetStatus.argtypes = [CatalogModelInfoHandle, ctypes.POINTER(ctypes.c_int)]
WinMLCatalogModelInfoGetStatus.restype = ctypes.HRESULT

WinMLCatalogModelInfoGetInstanceAsync = _dll.WinMLCatalogModelInfoGetInstanceAsync
WinMLCatalogModelInfoGetInstanceAsync.argtypes = [CatalogModelInfoHandle, ctypes.POINTER(AsyncBlock)]
WinMLCatalogModelInfoGetInstanceAsync.restype = ctypes.HRESULT

WinMLCatalogModelInfoGetInstanceWithHeadersAsync = _dll.WinMLCatalogModelInfoGetInstanceWithHeadersAsync
WinMLCatalogModelInfoGetInstanceWithHeadersAsync.argtypes = [
    CatalogModelInfoHandle, ctypes.c_size_t,
    ctypes.POINTER(ctypes.c_char_p), ctypes.POINTER(ctypes.c_char_p),
    ctypes.POINTER(AsyncBlock),
]
WinMLCatalogModelInfoGetInstanceWithHeadersAsync.restype = ctypes.HRESULT

WinMLCatalogModelInfoGetInstanceResult = _dll.WinMLCatalogModelInfoGetInstanceResult
WinMLCatalogModelInfoGetInstanceResult.argtypes = [ctypes.POINTER(AsyncBlock), ctypes.POINTER(CatalogModelInstanceResult)]
WinMLCatalogModelInfoGetInstanceResult.restype = ctypes.HRESULT

# ---------------------------------------------------------------------------
# Catalog Model Instance
# ---------------------------------------------------------------------------

WinMLCatalogModelInstanceRelease = _dll.WinMLCatalogModelInstanceRelease
WinMLCatalogModelInstanceRelease.argtypes = [CatalogModelInstanceHandle]
WinMLCatalogModelInstanceRelease.restype = None

WinMLCatalogModelInstanceEnumModelPaths = _dll.WinMLCatalogModelInstanceEnumModelPaths
WinMLCatalogModelInstanceEnumModelPaths.argtypes = [CatalogModelInstanceHandle, StringEnumCallback, ctypes.c_void_p]
WinMLCatalogModelInstanceEnumModelPaths.restype = ctypes.HRESULT

WinMLCatalogModelInstanceGetModelInfo = _dll.WinMLCatalogModelInstanceGetModelInfo
WinMLCatalogModelInstanceGetModelInfo.argtypes = [CatalogModelInstanceHandle, ctypes.POINTER(CatalogModelInfoHandle)]
WinMLCatalogModelInstanceGetModelInfo.restype = ctypes.HRESULT

WinMLCatalogModelInstanceClose = _dll.WinMLCatalogModelInstanceClose
WinMLCatalogModelInstanceClose.argtypes = [CatalogModelInstanceHandle]
WinMLCatalogModelInstanceClose.restype = ctypes.HRESULT
