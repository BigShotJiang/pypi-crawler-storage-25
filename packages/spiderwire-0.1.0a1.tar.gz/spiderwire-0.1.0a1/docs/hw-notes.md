# Hardware Notes

Raw observations of the OEM SpiderFarmer GSS hub, kept separate from
the protocol reference.

## OEM hub board

- MCU: **ESP32-S3-WROOM-1**
- Ethernet PHY: likely [Davicom DM9051](https://www.davicom.com.tw/production-item.php?lang_id=en)
  (SPI MAC+PHY; S3 has no internal EMAC, and the pin-compatible DM9051
  is what fits the 25 MHz crystal next to U6)
- RS-485 transceiver: TBD (on-board, DE-driven)
- LCD: parallel TFT (driver chip not yet identified — candidates
  include ILI9341, ST7789V, ST7796, ILI9488)

See [`firmware/sf-gss.yaml`](../firmware/sf-gss.yaml) for a draft
ESPHome firmware that can flash this hardware as a drop-in replacement
for the OEM firmware — bring-up still needs the LCD pin mapping and
driver chip verified.

## RJ12 pinout (peripheral-side)

| Pin colour | Signal |
|------------|--------|
| green      | GND |
| blue       | +12 V |
| white      | +12 V |
| black      | RS-485 |
| yellow     | RS-485 |
| red        | (unused / TBD) |

## Saleae Logic probe wiring (reference)

| Logic signal | Wire colour path |
|--------------|------------------|
| RS-485 A | yellow → grey → blue at Saleae |
| RS-485 B | green → purple → brown at Saleae |
