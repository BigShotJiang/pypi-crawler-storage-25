# logset

[![Documentation](https://img.shields.io/badge/Documentation-Click%20Here!-blue)](https://logset.readthedocs.io)
[![Python](https://img.shields.io/badge/Python-3.11+-blue)](https://www.python.org/downloads)
[![PyPI](https://img.shields.io/pypi/v/logset.svg?color=green)](https://pypi.org/project/logset/)
[![Build Status](https://github.com/JonKing93/logset/actions/workflows/build.yml/badge.svg?branch=main)](https://github.com/JonKing93/logset/actions/workflows/build.yml?query=branch%3Amain)
[![Coverage](https://coveralls.io/repos/github/JonKing93/logset/badge.svg?branch=main)](https://coveralls.io/github/JonKing93/logset?branch=main)
[![License](https://img.shields.io/badge/License-MIT-blue)](https://opensource.org/license/mit)

Convenience functions for setting up console and file loggers with a single call.


## About

Python's [logging](https://docs.python.org/3/library/logging.html) library is powerful, but comes with a steep learning curve and several common "gotchas". The logset library helps address this by providing convenience functions for setting up basic console ([sys.stderr](https://docs.python.org/3/library/sys.html#sys.stderr)) and file logs. Each function lets you configure a log at a given logging level using a single function call.

Critically, logset requires minimal familiarity with the logging library, so developers can simply focus on what their logs should do, without needing to manage complex logging objects. The commands also help prevent issues wherein (1) messages are not logged as expected, and (2) messages are duplicated in a logging target.


## Examples

Log messages to the console (`sys.stderr`) at a given level:

```python
import logset

logset.console.debug("my-logger")  # Logs at the DEBUG level
logset.console.info("my-logger")   # Logs at the INFO level
# Also includes functions for the "warning", "error", and "critical" levels
```

Log messages to file at a given level:

```python
logset.file.debug("my-logger", "my-file.log")
logset.file.info("my-logger", "my-file.log")
# Also includes functions for the "warning", "error", and "critical" levels
```

Control when log files are opened/created:

```python
logset.file.debug("my-logger", "path/to/some/my-file.log", make_parents=True)
logset.file.debug("my-logger", "my-file.log", delay=True)
```

Customize the format of different logs:

```python
logset.console.info("my-logger", "%(message)s")
logset.file.debug("my-logger", "my-file.log", "%(asctime)s - %(name)s - %(message)s)
```

Log to a file that rotates after reaching a maximum allowed size:

```python
# Rotates after reaching 1MB, saving backups of the 2 most recent rotated logs
logset.file.info("my-logger", "my-file.log", rotate_bytes=1000000, backup_count=2)
```

Log to a file that rotates on a [fixed time interval](https://docs.python.org/3/library/logging.handlers.html#timedrotatingfilehandler):

```python
# Rotates after 7 days, saving backups of the 2 previous logs
logset.file.info(
    "my-logger", "my-file.log", rotate_when="D", rotate_interval=7, backup_count=2
)
```


## Documentation

You can find more detailed examples, a user guide, and a comprehensive reference API at the [project documentation](https://logset.readthedocs.io).


## Installation

**Requires**: Python 3.11+

**Dependencies**: None

```
pip install logset
```

## Contributing / Feedback

We welcome contributions and feedback! To ask a question, suggest a feature, or report a bug, please open a new thread on our [Issues tracker](https://github.com/JonKing93/logset/issues). If you plan to contribute code, please read the [contribution guide](https://logset.readthedocs.io/en/latest/project/contributing.html) in the docs.


## License

This project is licensed under the MIT license. Refer to the [license file](https://github.com/JonKing93/logset/blob/main/LICENSE
) for more details.
