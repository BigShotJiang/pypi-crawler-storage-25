"""
Functions that set up a file logger at the indicated level
----------
Functions:
    debug       - Sets up a logger to write to a file at the DEBUG level
    info        - Sets up a logger to write to a file at the INFO level
    warning     - Sets up a logger to write to a file at the WARNING level
    error       - Sets up a logger to write to a file at the ERROR level
    critical    - Sets up a logger to write to a file at the CRITICAL level
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from logset._core import file as _file

if TYPE_CHECKING:
    from logging import FileHandler, Formatter, Logger
    from logging.handlers import RotatingFileHandler, TimedRotatingFileHandler
    from pathlib import Path
    from typing import Any


def debug(
    logger: str | Logger,
    path: str | Path,
    format: str | Formatter | None = None,
    *,
    fallback_format: str | Formatter = "%(message)s",
    rotate_bytes: int | None = None,
    rotate_when: str | None = None,
    rotate_interval: int = 1,
    backup_count: int = 1,
    make_parents: bool = False,
    delay: bool = False,
    clear_existing: bool = True,
    propagate: bool = False,
    **handler_kwargs: Any,
) -> FileHandler | RotatingFileHandler | TimedRotatingFileHandler:
    """
    Sets up a logger to write to file at the DEBUG level

    debug(logger, path)
    Sets up the indicated logger to write to the indicated file at the DEBUG level.
    Specifically, adds a DEBUG-level FileHandler to the logger, and ensures that the
    logger's level is at the DEBUG level or lower.

    The logger may either be a logger name (as a string) or a logging.Logger object. If
    the logger has any pre-existing handlers targeting the same file, then those
    handlers are removed to prevent doubling log messages. Returns the new FileHandler.
    Refer to the syntaxes below for option to implement a RotatingFileHandler (which
    rotates the log file after reaching a maximum size), or a TimedRotatingFileHandler
    (which rotates after a fixed time interval).

    debug(..., format)
    debug(..., format=None, *, fallback_format)
    Use `format` to specify the format used for log messages. The format may be a
    %-style logging format string, a logging.Formatter object. Logging strings are
    sufficient for most cases, but we note that advanced users can achieve more
    fine-grained control by using a logging.Formatter object.

    If `format=None` (the default), and the logger has pre-existing handlers that target
    the same file, then the format will default to the format of the first such handler
    that has a formatter. If no such handler is found, the format will be set to the
    value specified by `fallback_format`. By default, `fallback_format` is set to
    the logged message, equivalent to the formatting string "%(message)s".

    debug(..., *, rotate_bytes)
    debug(..., *, rotate_when, rotate_interval)
    debug(..., *, backup_count)
    Options for implementing rotating file logs. Setting `rotate_bytes` will add a
    RotatingFileHandler to the logger (as opposed to a basic FileHandler). The log file
    will rotate after the file size reaches the indicated number of bytes.
    Alternatively, use `rotate_when` and `rotate_interval` to use a
    TimedRotatingFileHandler, which will rotate the log file on the specified interval.
    (Refer to the TimedRotatingFileHandler docs for supported options). For either type
    of rotating file log, use `backup_count` to specify the number of backup file logs
    that should be saved after rotation.

    debug(..., *, make_parents=True)
    debug(..., *, delay=True)
    Options for creating the log file. By default, raises a FileNotFoundError if the
    log file parent folder does not exist. Set `make_parents=True` to create the parent
    folder as needed.

    Use `delay` to control when the log file is created. By default, creates the log
    file immediately. Set `delay = True` to defer log file creation until the first
    message is emitted.

    debug(..., *, clear_existing=False)
    debug(..., *, propagate=True)
    Advanced options that can lead to "double-logging" bugs. Set `clear_existing=False`
    to disable the removal of pre-existing handlers that target the same file.

    By default, this command sets `logger.propagate=False`, which stops this logger's
    events from being propagated to ancestor loggers. Set `propagate=True` to allow
    event propagation.

    debug(..., **handler_kwargs)
    Specifies additional options that should be passed to the FileHandler,
    RotatingFileHandler, or TimedRotatingFileHandler constructor, as appropriate.

    Args:
        logger: The name of a logger or logging.Logger object that should write messages
            to file at the DEBUG level
        path: The path to the file where messages should be written
        format: An optional %-style logging format string, or logging.Formatter object
            used to set the format of logged messages. Defaults to the format of the
            first pre-existing handler that targets the same file and has a formatter,
            or to fallback_format if no such handler exists.
        fallback_format: The log format to use when `format` is not specified, and there
            is no pre-existing handler that targets the same file and has a formatter
        rotate_bytes: A maximum file size (in bytes) for rotating log files
        rotate_when: The type of interval to use for timed rotation
        rotate_interval: The length of the interval for timed rotation. Defaults to 1
        backup_count: The number of backup log files that should be preserved.
            Defaults to 1
        make_parents: True to create any parent folders needed to hold the log file.
            False (default) to not create parent folders.
        delay: True to delay creating the log file until the first message is emitted.
            False (default) to create the log file immediately.
        clear_existing: True (default) to remove any pre-existing handlers that target
            the same file. False to disable this behavior.
        propagate: True to allow this logger's events to propagate to ancestor loggers.
            False (default) to prevent propagation.
        **handler_kwargs: Additional parameters passed to the constructor of the new
            FileHandler, RotatingFileHandler, or TimedRotatingFileHandler object.

    Returns:
        FileHandler | RotatingFileHandler | TimedRotatingFileHandler: The logger's new
            DEBUG-level file handler
    """
    return _file.setup(
        logging.DEBUG,
        logger,
        path,
        format,
        fallback_format,
        rotate_bytes,
        rotate_when,
        rotate_interval,
        backup_count,
        make_parents,
        delay,
        clear_existing,
        propagate,
        **handler_kwargs,
    )


def info(
    logger: str | Logger,
    path: str | Path,
    format: str | Formatter | None = None,
    *,
    fallback_format: str | Formatter = "%(message)s",
    rotate_bytes: int | None = None,
    rotate_when: str | None = None,
    rotate_interval: int = 1,
    backup_count: int = 1,
    make_parents: bool = False,
    delay: bool = False,
    clear_existing: bool = True,
    propagate: bool = False,
    **handler_kwargs: Any,
) -> FileHandler | RotatingFileHandler | TimedRotatingFileHandler:
    """
    Sets up a logger to write to file at the INFO level

    info(logger, path)
    Sets up the indicated logger to write to the indicated file at the INFO level.
    Specifically, adds a INFO-level FileHandler to the logger, and ensures that the
    logger's level is at the INFO level or lower.

    The logger may either be a logger name (as a string) or a logging.Logger object. If
    the logger has any pre-existing handlers targeting the same file, then those
    handlers are removed to prevent doubling log messages. Returns the new FileHandler.
    Refer to the syntaxes below for option to implement a RotatingFileHandler (which
    rotates the log file after reaching a maximum size), or a TimedRotatingFileHandler
    (which rotates after a fixed time interval).

    info(..., format)
    info(..., format=None, *, fallback_format)
    Use `format` to specify the format used for log messages. The format may be a
    %-style logging format string, a logging.Formatter object. Logging strings are
    sufficient for most cases, but we note that advanced users can achieve more
    fine-grained control by using a logging.Formatter object.

    If `format=None` (the default), and the logger has pre-existing handlers that target
    the same file, then the format will default to the format of the first such handler
    that has a formatter. If no such handler is found, the format will be set to the
    value specified by `fallback_format`. By default, `fallback_format` is set to
    the logged message, equivalent to the formatting string "%(message)s".

    info(..., *, rotate_bytes)
    info(..., *, rotate_when, rotate_interval)
    info(..., *, backup_count)
    Options for implementing rotating file logs. Setting `rotate_bytes` will add a
    RotatingFileHandler to the logger (as opposed to a basic FileHandler). The log file
    will rotate after the file size reaches the indicated number of bytes.
    Alternatively, use `rotate_when` and `rotate_interval` to use a
    TimedRotatingFileHandler, which will rotate the log file on the specified interval.
    (Refer to the TimedRotatingFileHandler docs for supported options). For either type
    of rotating file log, use `backup_count` to specify the number of backup file logs
    that should be saved after rotation.

    info(..., *, make_parents=True)
    info(..., *, delay=True)
    Options for creating the log file. By default, raises a FileNotFoundError if the
    log file parent folder does not exist. Set `make_parents=True` to create the parent
    folder as needed.

    Use `delay` to control when the log file is created. By default, creates the log
    file immediately. Set `delay = True` to defer log file creation until the first
    message is emitted.

    info(..., *, clear_existing=False)
    info(..., *, propagate=True)
    Advanced options that can lead to "double-logging" bugs. Set `clear_existing=False`
    to disable the removal of pre-existing handlers that target the same file.

    By default, this command sets `logger.propagate=False`, which stops this logger's
    events from being propagated to ancestor loggers. Set `propagate=True` to allow
    event propagation.

    info(..., **handler_kwargs)
    Specifies additional options that should be passed to the FileHandler,
    RotatingFileHandler, or TimedRotatingFileHandler constructor, as appropriate.

    Args:
        logger: The name of a logger or logging.Logger object that should write messages
            to file at the INFO level
        path: The path to the file where messages should be written
        format: An optional %-style logging format string, or logging.Formatter object
            used to set the format of logged messages. Defaults to the format of the
            first pre-existing handler that targets the same file and has a formatter,
            or to fallback_format if no such handler exists.
        fallback_format: The log format to use when `format` is not specified, and there
            is no pre-existing handler that targets the same file and has a formatter
        rotate_bytes: A maximum file size (in bytes) for rotating log files
        rotate_when: The type of interval to use for timed rotation
        rotate_interval: The length of the interval for timed rotation. Defaults to 1
        backup_count: The number of backup log files that should be preserved.
            Defaults to 1
        make_parents: True to create any parent folders needed to hold the log file.
            False (default) to not create parent folders.
        delay: True to delay creating the log file until the first message is emitted.
            False (default) to create the log file immediately.
        clear_existing: True (default) to remove any pre-existing handlers that target
            the same file. False to disable this behavior.
        propagate: True to allow this logger's events to propagate to ancestor loggers.
            False (default) to prevent propagation.
        **handler_kwargs: Additional parameters passed to the constructor of the new
            FileHandler, RotatingFileHandler, or TimedRotatingFileHandler object.

    Returns:
        FileHandler | RotatingFileHandler | TimedRotatingFileHandler: The logger's new
            INFO-level file handler
    """
    return _file.setup(
        logging.INFO,
        logger,
        path,
        format,
        fallback_format,
        rotate_bytes,
        rotate_when,
        rotate_interval,
        backup_count,
        make_parents,
        delay,
        clear_existing,
        propagate,
        **handler_kwargs,
    )


def warning(
    logger: str | Logger,
    path: str | Path,
    format: str | Formatter | None = None,
    *,
    fallback_format: str | Formatter = "%(message)s",
    rotate_bytes: int | None = None,
    rotate_when: str | None = None,
    rotate_interval: int = 1,
    backup_count: int = 1,
    make_parents: bool = False,
    delay: bool = False,
    clear_existing: bool = True,
    propagate: bool = False,
    **handler_kwargs: Any,
) -> FileHandler | RotatingFileHandler | TimedRotatingFileHandler:
    """
    Sets up a logger to write to file at the WARNING level

    warning(logger, path)
    Sets up the indicated logger to write to the indicated file at the WARNING level.
    Specifically, adds a WARNING-level FileHandler to the logger, and ensures that the
    logger's level is at the WARNING level or lower.

    The logger may either be a logger name (as a string) or a logging.Logger object. If
    the logger has any pre-existing handlers targeting the same file, then those
    handlers are removed to prevent doubling log messages. Returns the new FileHandler.
    Refer to the syntaxes below for option to implement a RotatingFileHandler (which
    rotates the log file after reaching a maximum size), or a TimedRotatingFileHandler
    (which rotates after a fixed time interval).

    warning(..., format)
    warning(..., format=None, *, fallback_format)
    Use `format` to specify the format used for log messages. The format may be a
    %-style logging format string, a logging.Formatter object. Logging strings are
    sufficient for most cases, but we note that advanced users can achieve more
    fine-grained control by using a logging.Formatter object.

    If `format=None` (the default), and the logger has pre-existing handlers that target
    the same file, then the format will default to the format of the first such handler
    that has a formatter. If no such handler is found, the format will be set to the
    value specified by `fallback_format`. By default, `fallback_format` is set to
    the logged message, equivalent to the formatting string "%(message)s".

    warning(..., *, rotate_bytes)
    warning(..., *, rotate_when, rotate_interval)
    warning(..., *, backup_count)
    Options for implementing rotating file logs. Setting `rotate_bytes` will add a
    RotatingFileHandler to the logger (as opposed to a basic FileHandler). The log file
    will rotate after the file size reaches the indicated number of bytes.
    Alternatively, use `rotate_when` and `rotate_interval` to use a
    TimedRotatingFileHandler, which will rotate the log file on the specified interval.
    (Refer to the TimedRotatingFileHandler docs for supported options). For either type
    of rotating file log, use `backup_count` to specify the number of backup file logs
    that should be saved after rotation.

    warning(..., *, make_parents=True)
    warning(..., *, delay=True)
    Options for creating the log file. By default, raises a FileNotFoundError if the
    log file parent folder does not exist. Set `make_parents=True` to create the parent
    folder as needed.

    Use `delay` to control when the log file is created. By default, creates the log
    file immediately. Set `delay = True` to defer log file creation until the first
    message is emitted.

    warning(..., *, clear_existing=False)
    warning(..., *, propagate=True)
    Advanced options that can lead to "double-logging" bugs. Set `clear_existing=False`
    to disable the removal of pre-existing handlers that target the same file.

    By default, this command sets `logger.propagate=False`, which stops this logger's
    events from being propagated to ancestor loggers. Set `propagate=True` to allow
    event propagation.

    warning(..., **handler_kwargs)
    Specifies additional options that should be passed to the FileHandler,
    RotatingFileHandler, or TimedRotatingFileHandler constructor, as appropriate.

    Args:
        logger: The name of a logger or logging.Logger object that should write messages
            to file at the WARNING level
        path: The path to the file where messages should be written
        format: An optional %-style logging format string, or logging.Formatter object
            used to set the format of logged messages. Defaults to the format of the
            first pre-existing handler that targets the same file and has a formatter,
            or to fallback_format if no such handler exists.
        fallback_format: The log format to use when `format` is not specified, and there
            is no pre-existing handler that targets the same file and has a formatter
        rotate_bytes: A maximum file size (in bytes) for rotating log files
        rotate_when: The type of interval to use for timed rotation
        rotate_interval: The length of the interval for timed rotation. Defaults to 1
        backup_count: The number of backup log files that should be preserved.
            Defaults to 1
        make_parents: True to create any parent folders needed to hold the log file.
            False (default) to not create parent folders.
        delay: True to delay creating the log file until the first message is emitted.
            False (default) to create the log file immediately.
        clear_existing: True (default) to remove any pre-existing handlers that target
            the same file. False to disable this behavior.
        propagate: True to allow this logger's events to propagate to ancestor loggers.
            False (default) to prevent propagation.
        **handler_kwargs: Additional parameters passed to the constructor of the new
            FileHandler, RotatingFileHandler, or TimedRotatingFileHandler object.

    Returns:
        FileHandler | RotatingFileHandler | TimedRotatingFileHandler: The logger's new
            WARNING-level file handler
    """
    return _file.setup(
        logging.WARNING,
        logger,
        path,
        format,
        fallback_format,
        rotate_bytes,
        rotate_when,
        rotate_interval,
        backup_count,
        make_parents,
        delay,
        clear_existing,
        propagate,
        **handler_kwargs,
    )


def error(
    logger: str | Logger,
    path: str | Path,
    format: str | Formatter | None = None,
    *,
    fallback_format: str | Formatter = "%(message)s",
    rotate_bytes: int | None = None,
    rotate_when: str | None = None,
    rotate_interval: int = 1,
    backup_count: int = 1,
    make_parents: bool = False,
    delay: bool = False,
    clear_existing: bool = True,
    propagate: bool = False,
    **handler_kwargs: Any,
) -> FileHandler | RotatingFileHandler | TimedRotatingFileHandler:
    """
    Sets up a logger to write to file at the ERROR level

    error(logger, path)
    Sets up the indicated logger to write to the indicated file at the ERROR level.
    Specifically, adds a ERROR-level FileHandler to the logger, and ensures that the
    logger's level is at the ERROR level or lower.

    The logger may either be a logger name (as a string) or a logging.Logger object. If
    the logger has any pre-existing handlers targeting the same file, then those
    handlers are removed to prevent doubling log messages. Returns the new FileHandler.
    Refer to the syntaxes below for option to implement a RotatingFileHandler (which
    rotates the log file after reaching a maximum size), or a TimedRotatingFileHandler
    (which rotates after a fixed time interval).

    error(..., format)
    error(..., format=None, *, fallback_format)
    Use `format` to specify the format used for log messages. The format may be a
    %-style logging format string, a logging.Formatter object. Logging strings are
    sufficient for most cases, but we note that advanced users can achieve more
    fine-grained control by using a logging.Formatter object.

    If `format=None` (the default), and the logger has pre-existing handlers that target
    the same file, then the format will default to the format of the first such handler
    that has a formatter. If no such handler is found, the format will be set to the
    value specified by `fallback_format`. By default, `fallback_format` is set to
    the logged message, equivalent to the formatting string "%(message)s".

    error(..., *, rotate_bytes)
    error(..., *, rotate_when, rotate_interval)
    error(..., *, backup_count)
    Options for implementing rotating file logs. Setting `rotate_bytes` will add a
    RotatingFileHandler to the logger (as opposed to a basic FileHandler). The log file
    will rotate after the file size reaches the indicated number of bytes.
    Alternatively, use `rotate_when` and `rotate_interval` to use a
    TimedRotatingFileHandler, which will rotate the log file on the specified interval.
    (Refer to the TimedRotatingFileHandler docs for supported options). For either type
    of rotating file log, use `backup_count` to specify the number of backup file logs
    that should be saved after rotation.

    error(..., *, make_parents=True)
    error(..., *, delay=True)
    Options for creating the log file. By default, raises a FileNotFoundError if the
    log file parent folder does not exist. Set `make_parents=True` to create the parent
    folder as needed.

    Use `delay` to control when the log file is created. By default, creates the log
    file immediately. Set `delay = True` to defer log file creation until the first
    message is emitted.

    error(..., *, clear_existing=False)
    error(..., *, propagate=True)
    Advanced options that can lead to "double-logging" bugs. Set `clear_existing=False`
    to disable the removal of pre-existing handlers that target the same file.

    By default, this command sets `logger.propagate=False`, which stops this logger's
    events from being propagated to ancestor loggers. Set `propagate=True` to allow
    event propagation.

    error(..., **handler_kwargs)
    Specifies additional options that should be passed to the FileHandler,
    RotatingFileHandler, or TimedRotatingFileHandler constructor, as appropriate.

    Args:
        logger: The name of a logger or logging.Logger object that should write messages
            to file at the ERROR level
        path: The path to the file where messages should be written
        format: An optional %-style logging format string, or logging.Formatter object
            used to set the format of logged messages. Defaults to the format of the
            first pre-existing handler that targets the same file and has a formatter,
            or to fallback_format if no such handler exists.
        fallback_format: The log format to use when `format` is not specified, and there
            is no pre-existing handler that targets the same file and has a formatter
        rotate_bytes: A maximum file size (in bytes) for rotating log files
        rotate_when: The type of interval to use for timed rotation
        rotate_interval: The length of the interval for timed rotation. Defaults to 1
        backup_count: The number of backup log files that should be preserved.
            Defaults to 1
        make_parents: True to create any parent folders needed to hold the log file.
            False (default) to not create parent folders.
        delay: True to delay creating the log file until the first message is emitted.
            False (default) to create the log file immediately.
        clear_existing: True (default) to remove any pre-existing handlers that target
            the same file. False to disable this behavior.
        propagate: True to allow this logger's events to propagate to ancestor loggers.
            False (default) to prevent propagation.
        **handler_kwargs: Additional parameters passed to the constructor of the new
            FileHandler, RotatingFileHandler, or TimedRotatingFileHandler object.

    Returns:
        FileHandler | RotatingFileHandler | TimedRotatingFileHandler: The logger's new
            ERROR-level file handler
    """
    return _file.setup(
        logging.ERROR,
        logger,
        path,
        format,
        fallback_format,
        rotate_bytes,
        rotate_when,
        rotate_interval,
        backup_count,
        make_parents,
        delay,
        clear_existing,
        propagate,
        **handler_kwargs,
    )


def critical(
    logger: str | Logger,
    path: str | Path,
    format: str | Formatter | None = None,
    *,
    fallback_format: str | Formatter = "%(message)s",
    rotate_bytes: int | None = None,
    rotate_when: str | None = None,
    rotate_interval: int = 1,
    backup_count: int = 1,
    make_parents: bool = False,
    delay: bool = False,
    clear_existing: bool = True,
    propagate: bool = False,
    **handler_kwargs: Any,
) -> FileHandler | RotatingFileHandler | TimedRotatingFileHandler:
    """
    Sets up a logger to write to file at the CRITICAL level

    critical(logger, path)
    Sets up the indicated logger to write to the indicated file at the CRITICAL level.
    Specifically, adds a CRITICAL-level FileHandler to the logger, and ensures that the
    logger's level is at the CRITICAL level or lower.

    The logger may either be a logger name (as a string) or a logging.Logger object. If
    the logger has any pre-existing handlers targeting the same file, then those
    handlers are removed to prevent doubling log messages. Returns the new FileHandler.
    Refer to the syntaxes below for option to implement a RotatingFileHandler (which
    rotates the log file after reaching a maximum size), or a TimedRotatingFileHandler
    (which rotates after a fixed time interval).

    critical(..., format)
    critical(..., format=None, *, fallback_format)
    Use `format` to specify the format used for log messages. The format may be a
    %-style logging format string, a logging.Formatter object. Logging strings are
    sufficient for most cases, but we note that advanced users can achieve more
    fine-grained control by using a logging.Formatter object.

    If `format=None` (the default), and the logger has pre-existing handlers that target
    the same file, then the format will default to the format of the first such handler
    that has a formatter. If no such handler is found, the format will be set to the
    value specified by `fallback_format`. By default, `fallback_format` is set to
    the logged message, equivalent to the formatting string "%(message)s".

    critical(..., *, rotate_bytes)
    critical(..., *, rotate_when, rotate_interval)
    critical(..., *, backup_count)
    Options for implementing rotating file logs. Setting `rotate_bytes` will add a
    RotatingFileHandler to the logger (as opposed to a basic FileHandler). The log file
    will rotate after the file size reaches the indicated number of bytes.
    Alternatively, use `rotate_when` and `rotate_interval` to use a
    TimedRotatingFileHandler, which will rotate the log file on the specified interval.
    (Refer to the TimedRotatingFileHandler docs for supported options). For either type
    of rotating file log, use `backup_count` to specify the number of backup file logs
    that should be saved after rotation.

    critical(..., *, make_parents=True)
    critical(..., *, delay=True)
    Options for creating the log file. By default, raises a FileNotFoundError if the
    log file parent folder does not exist. Set `make_parents=True` to create the parent
    folder as needed.

    Use `delay` to control when the log file is created. By default, creates the log
    file immediately. Set `delay = True` to defer log file creation until the first
    message is emitted.

    critical(..., *, clear_existing=False)
    critical(..., *, propagate=True)
    Advanced options that can lead to "double-logging" bugs. Set `clear_existing=False`
    to disable the removal of pre-existing handlers that target the same file.

    By default, this command sets `logger.propagate=False`, which stops this logger's
    events from being propagated to ancestor loggers. Set `propagate=True` to allow
    event propagation.

    critical(..., **handler_kwargs)
    Specifies additional options that should be passed to the FileHandler,
    RotatingFileHandler, or TimedRotatingFileHandler constructor, as appropriate.

    Args:
        logger: The name of a logger or logging.Logger object that should write messages
            to file at the CRITICAL level
        path: The path to the file where messages should be written
        format: An optional %-style logging format string, or logging.Formatter object
            used to set the format of logged messages. Defaults to the format of the
            first pre-existing handler that targets the same file and has a formatter,
            or to fallback_format if no such handler exists.
        fallback_format: The log format to use when `format` is not specified, and there
            is no pre-existing handler that targets the same file and has a formatter
        rotate_bytes: A maximum file size (in bytes) for rotating log files
        rotate_when: The type of interval to use for timed rotation
        rotate_interval: The length of the interval for timed rotation. Defaults to 1
        backup_count: The number of backup log files that should be preserved.
            Defaults to 1
        make_parents: True to create any parent folders needed to hold the log file.
            False (default) to not create parent folders.
        delay: True to delay creating the log file until the first message is emitted.
            False (default) to create the log file immediately.
        clear_existing: True (default) to remove any pre-existing handlers that target
            the same file. False to disable this behavior.
        propagate: True to allow this logger's events to propagate to ancestor loggers.
            False (default) to prevent propagation.
        **handler_kwargs: Additional parameters passed to the constructor of the new
            FileHandler, RotatingFileHandler, or TimedRotatingFileHandler object.

    Returns:
        FileHandler | RotatingFileHandler | TimedRotatingFileHandler: The logger's new
            CRITICAL-level file handler
    """
    return _file.setup(
        logging.CRITICAL,
        logger,
        path,
        format,
        fallback_format,
        rotate_bytes,
        rotate_when,
        rotate_interval,
        backup_count,
        make_parents,
        delay,
        clear_existing,
        propagate,
        **handler_kwargs,
    )
