"""
Modules that stage the final API. The main purpose of these modules are to separate
long docstrings from the core logic of the codebase.
"""
