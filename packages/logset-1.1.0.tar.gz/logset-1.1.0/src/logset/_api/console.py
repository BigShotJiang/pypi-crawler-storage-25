"""
Functions that set up a sys.stderr console logger at the indicated level
----------
Functions:
    debug       - Sets up a logger to write to the console at the DEBUG level
    info        - Sets up a logger to write to the console at the INFO level
    warning     - Sets up a logger to write to the console at the WARNING level
    error       - Sets up a logger to write to the console at the ERROR level
    critical    - Sets up a logger to write to the console at the CRITICAL level
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from logset._core import console as _console

if TYPE_CHECKING:
    from logging import Formatter, Logger, StreamHandler

__all__ = ["debug", "info", "warning", "error", "critical"]


def debug(
    logger: str | Logger,
    format: str | Formatter | None = None,
    *,
    fallback_format: str | Formatter = "%(message)s",
    clear_existing: bool = True,
    propagate: bool = False,
) -> StreamHandler:
    """
    Sets up a logger to write to the console at the DEBUG level

    debug(logger)
    Sets up the indicated logger to write to the console (sys.stderr) at the DEBUG
    level. Specifically, the command adds a DEBUG-level sys.stderr StreamHandler to
    the logger, and ensures the logger's level is at the DEBUG level or lower.

    The logger may either be a logger name (as a string), or a logging.Logger object.
    If the logger has any pre-existing StreamHandlers that write to sys.stderr, then
    those handlers are removed to prevent doubling log messages. Returns the new
    sys.stderr StreamHandler.

    debug(..., format)
    debug(..., format=None, *, fallback_format)
    Use `format` to specify the format used for log messages. The format may be a
    %-style logging format string, a logging.Formatter object. Logging strings are
    sufficient for most cases, but we note that advanced users can achieve more
    fine-grained control by using a logging.Formatter object.

    If `format=None` (the default), and the logger has pre-existing sys.stderr
    StreamHandlers, then the format will default to the format of the first such handler
    that has a formatter. If no such handler is found, the format will be set to the
    value specified by `fallback_format`. By default, `fallback_format` is set to
    the logged message, equivalent to the formatting string "%(message)s".

    debug(..., *, clear_existing=False)
    debug(..., *, propagate=True)
    Advanced options that can lead to "double-logging" bugs. Set `clear_existing=False`
    to disable the removal of pre-existing sys.stderr StreamHandlers.

    By default, this command sets `logger.propagate=False`, which stops this logger's
    events from being propagated to ancestor loggers. Set `propagate=True` to allow
    event propagation.

    Args:
        logger: The name of a logger or logging.Logger object that should emit messages
            to the console at the DEBUG level.
        format: An optional %-style logging format string, or logging.Formatter object
            used to set the format of logged messages. Defaults to the format of the
            first pre-existing sys.stderr StreamHandler with a formatter, or to
            fallback_format if no such handler exists.
        fallback_format: The log format to use when `format` is not specified, and there
            is no pre-existing sys.stderr StreamHandler with a formatter
        clear_existing: True (default) to remove any pre-existing sys.stderr
            StreamHandlers. False to disable this behavior.
        propagate: True to allow this logger's events to propagate to ancestor loggers.
            False (default) to prevent propagation.

    Returns:
        StreamHandler: The logger's new DEBUG-level sys.stderr StreamHandler
    """
    return _console.setup(
        logging.DEBUG, logger, format, fallback_format, clear_existing, propagate
    )


def info(
    logger: str | Logger,
    format: str | Formatter | None = None,
    *,
    fallback_format: str | Formatter = "%(message)s",
    clear_existing: bool = True,
    propagate: bool = False,
) -> StreamHandler:
    """
    Sets up a logger to write to the console at the INFO level

    info(logger)
    Sets up the indicated logger to write to the console (sys.stderr) at the INFO
    level. Specifically, the command adds a INFO-level sys.stderr StreamHandler to
    the logger, and ensures the logger's level is at the INFO level or lower.

    The logger may either be a logger name (as a string), or a logging.Logger object.
    If the logger has any pre-existing StreamHandlers that write to sys.stderr, then
    those handlers are removed to prevent doubling log messages. Returns the new
    sys.stderr StreamHandler.

    info(..., format)
    info(..., format=None, *, fallback_format)
    Use `format` to specify the format used for log messages. The format may be a
    %-style logging format string, a logging.Formatter object. Logging strings are
    sufficient for most cases, but we note that advanced users can achieve more
    fine-grained control by using a logging.Formatter object.

    If `format=None` (the default), and the logger has pre-existing sys.stderr
    StreamHandlers, then the format will default to the format of the first such handler
    that has a formatter. If no such handler is found, the format will be set to the
    value specified by `fallback_format`. By default, `fallback_format` is set to
    the logged message, equivalent to the formatting string "%(message)s".

    info(..., *, clear_existing=False)
    info(..., *, propagate=True)
    Advanced options that can lead to "double-logging" bugs. Set `clear_existing=False`
    to disable the removal of pre-existing sys.stderr StreamHandlers.

    By default, this command sets `logger.propagate=False`, which stops this logger's
    events from being propagated to ancestor loggers. Set `propagate=True` to allow
    event propagation.

    Args:
        logger: The name of a logger or logging.Logger object that should emit messages
            to the console at the INFO level.
        format: An optional %-style logging format string, or logging.Formatter object
            used to set the format of logged messages. Defaults to the format of the
            first pre-existing sys.stderr StreamHandler with a formatter, or to
            fallback_format if no such handler exists.
        fallback_format: The log format to use when `format` is not specified, and there
            is no pre-existing sys.stderr StreamHandler with a formatter
        clear_existing: True (default) to remove any pre-existing sys.stderr
            StreamHandlers. False to disable this behavior.
        propagate: True to allow this logger's events to propagate to ancestor loggers.
            False (default) to prevent propagation.

    Returns:
        StreamHandler: The logger's new INFO-level sys.stderr StreamHandler
    """
    return _console.setup(
        logging.INFO, logger, format, fallback_format, clear_existing, propagate
    )


def warning(
    logger: str | Logger,
    format: str | Formatter | None = None,
    *,
    fallback_format: str | Formatter = "%(message)s",
    clear_existing: bool = True,
    propagate: bool = False,
) -> StreamHandler:
    """
    Sets up a logger to write to the console at the WARNING level

    warning(logger)
    Sets up the indicated logger to write to the console (sys.stderr) at the WARNING
    level. Specifically, the command adds a WARNING-level sys.stderr StreamHandler to
    the logger, and ensures the logger's level is at the WARNING level or lower.

    The logger may either be a logger name (as a string), or a logging.Logger object.
    If the logger has any pre-existing StreamHandlers that write to sys.stderr, then
    those handlers are removed to prevent doubling log messages. Returns the new
    sys.stderr StreamHandler.

    warning(..., format)
    warning(..., format=None, *, fallback_format)
    Use `format` to specify the format used for log messages. The format may be a
    %-style logging format string, a logging.Formatter object. Logging strings are
    sufficient for most cases, but we note that advanced users can achieve more
    fine-grained control by using a logging.Formatter object.

    If `format=None` (the default), and the logger has pre-existing sys.stderr
    StreamHandlers, then the format will default to the format of the first such handler
    that has a formatter. If no such handler is found, the format will be set to the
    value specified by `fallback_format`. By default, `fallback_format` is set to
    the logged message, equivalent to the formatting string "%(message)s".

    warning(..., *, clear_existing=False)
    warning(..., *, propagate=True)
    Advanced options that can lead to "double-logging" bugs. Set `clear_existing=False`
    to disable the removal of pre-existing sys.stderr StreamHandlers.

    By default, this command sets `logger.propagate=False`, which stops this logger's
    events from being propagated to ancestor loggers. Set `propagate=True` to allow
    event propagation.

    Args:
        logger: The name of a logger or logging.Logger object that should emit messages
            to the console at the WARNING level.
        format: An optional %-style logging format string, or logging.Formatter object
            used to set the format of logged messages. Defaults to the format of the
            first pre-existing sys.stderr StreamHandler with a formatter, or to
            fallback_format if no such handler exists.
        fallback_format: The log format to use when `format` is not specified, and there
            is no pre-existing sys.stderr StreamHandler with a formatter
        clear_existing: True (default) to remove any pre-existing sys.stderr
            StreamHandlers. False to disable this behavior.
        propagate: True to allow this logger's events to propagate to ancestor loggers.
            False (default) to prevent propagation.

    Returns:
        StreamHandler: The logger's new WARNING-level sys.stderr StreamHandler
    """
    return _console.setup(
        logging.WARNING, logger, format, fallback_format, clear_existing, propagate
    )


def error(
    logger: str | Logger,
    format: str | Formatter | None = None,
    *,
    fallback_format: str | Formatter = "%(message)s",
    clear_existing: bool = True,
    propagate: bool = False,
) -> StreamHandler:
    """
    Sets up a logger to write to the console at the ERROR level

    error(logger)
    Sets up the indicated logger to write to the console (sys.stderr) at the ERROR
    level. Specifically, the command adds a ERROR-level sys.stderr StreamHandler to
    the logger, and ensures the logger's level is at the ERROR level or lower.

    The logger may either be a logger name (as a string), or a logging.Logger object.
    If the logger has any pre-existing StreamHandlers that write to sys.stderr, then
    those handlers are removed to prevent doubling log messages. Returns the new
    sys.stderr StreamHandler.

    error(..., format)
    error(..., format=None, *, fallback_format)
    Use `format` to specify the format used for log messages. The format may be a
    %-style logging format string, a logging.Formatter object. Logging strings are
    sufficient for most cases, but we note that advanced users can achieve more
    fine-grained control by using a logging.Formatter object.

    If `format=None` (the default), and the logger has pre-existing sys.stderr
    StreamHandlers, then the format will default to the format of the first such handler
    that has a formatter. If no such handler is found, the format will be set to the
    value specified by `fallback_format`. By default, `fallback_format` is set to
    the logged message, equivalent to the formatting string "%(message)s".

    error(..., *, clear_existing=False)
    error(..., *, propagate=True)
    Advanced options that can lead to "double-logging" bugs. Set `clear_existing=False`
    to disable the removal of pre-existing sys.stderr StreamHandlers.

    By default, this command sets `logger.propagate=False`, which stops this logger's
    events from being propagated to ancestor loggers. Set `propagate=True` to allow
    event propagation.

    Args:
        logger: The name of a logger or logging.Logger object that should emit messages
            to the console at the ERROR level.
        format: An optional %-style logging format string, or logging.Formatter object
            used to set the format of logged messages. Defaults to the format of the
            first pre-existing sys.stderr StreamHandler with a formatter, or to
            fallback_format if no such handler exists.
        fallback_format: The log format to use when `format` is not specified, and there
            is no pre-existing sys.stderr StreamHandler with a formatter
        clear_existing: True (default) to remove any pre-existing sys.stderr
            StreamHandlers. False to disable this behavior.
        propagate: True to allow this logger's events to propagate to ancestor loggers.
            False (default) to prevent propagation.

    Returns:
        StreamHandler: The logger's new ERROR-level sys.stderr StreamHandler
    """
    return _console.setup(
        logging.ERROR, logger, format, fallback_format, clear_existing, propagate
    )


def critical(
    logger: str | Logger,
    format: str | Formatter | None = None,
    *,
    fallback_format: str | Formatter = "%(message)s",
    clear_existing: bool = True,
    propagate: bool = False,
) -> StreamHandler:
    """
    Sets up a logger to write to the console at the CRITICAL level

    critical(logger)
    Sets up the indicated logger to write to the console (sys.stderr) at the CRITICAL
    level. Specifically, the command adds a CRITICAL-level sys.stderr StreamHandler to
    the logger, and ensures the logger's level is at the CRITICAL level or lower.

    The logger may either be a logger name (as a string), or a logging.Logger object.
    If the logger has any pre-existing StreamHandlers that write to sys.stderr, then
    those handlers are removed to prevent doubling log messages. Returns the new
    sys.stderr StreamHandler.

    critical(..., format)
    critical(..., format=None, *, fallback_format)
    Use `format` to specify the format used for log messages. The format may be a
    %-style logging format string, a logging.Formatter object. Logging strings are
    sufficient for most cases, but we note that advanced users can achieve more
    fine-grained control by using a logging.Formatter object.

    If `format=None` (the default), and the logger has pre-existing sys.stderr
    StreamHandlers, then the format will default to the format of the first such handler
    that has a formatter. If no such handler is found, the format will be set to the
    value specified by `fallback_format`. By default, `fallback_format` is set to
    the logged message, equivalent to the formatting string "%(message)s".

    critical(..., *, clear_existing=False)
    critical(..., *, propagate=True)
    Advanced options that can lead to "double-logging" bugs. Set `clear_existing=False`
    to disable the removal of pre-existing sys.stderr StreamHandlers.

    By default, this command sets `logger.propagate=False`, which stops this logger's
    events from being propagated to ancestor loggers. Set `propagate=True` to allow
    event propagation.

    Args:
        logger: The name of a logger or logging.Logger object that should emit messages
            to the console at the CRITICAL level.
        format: An optional %-style logging format string, or logging.Formatter object
            used to set the format of logged messages. Defaults to the format of the
            first pre-existing sys.stderr StreamHandler with a formatter, or to
            fallback_format if no such handler exists.
        fallback_format: The log format to use when `format` is not specified, and there
            is no pre-existing sys.stderr StreamHandler with a formatter
        clear_existing: True (default) to remove any pre-existing sys.stderr
            StreamHandlers. False to disable this behavior.
        propagate: True to allow this logger's events to propagate to ancestor loggers.
            False (default) to prevent propagation.

    Returns:
        StreamHandler: The logger's new CRITICAL-level sys.stderr StreamHandler
    """
    return _console.setup(
        logging.CRITICAL, logger, format, fallback_format, clear_existing, propagate
    )
