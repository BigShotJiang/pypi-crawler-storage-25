"""
Function to finalize a logger for a new handler
----------
Function:
    logger  - Finalizes a logger for a new handler
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from logging import Formatter, Handler, Logger


def logger(
    logger: Logger,
    level: int,
    handler: Handler,
    format: Formatter | None,
    propagate: bool,
) -> None:
    """Finalizes a logger by for a new handler. Sets (1) log levels to ensure messages
    are emitted, (2) the handler formatter, and (3) propagation behavior"""

    # Set handler level and formatter
    handler.setLevel(level)
    if format is not None:
        handler.setFormatter(format)

    # Finalize logger
    logger.addHandler(handler)
    if logger.level > level or logger.level == 0:
        logger.setLevel(level)
    logger.propagate = propagate
