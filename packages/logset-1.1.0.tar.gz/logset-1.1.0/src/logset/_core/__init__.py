"""
Modules that implement the core logic for setting up loggers
----------
Modules:
    console - Module with functions for setting up console loggers
    file    - Module with functions for setting up file loggers
"""
