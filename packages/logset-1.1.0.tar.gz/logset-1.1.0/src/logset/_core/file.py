"""
Core logic for setting up a file logger
----------
Functions:
    setup               - Sets up a file log
    _prepare_handler    - Creates an appropriate handler for the log
    _isexisting         - True if a handler if a file handler with the same target
    _parse_format       - Determines the format to use for the handler
    _existing_format    - Returns a pre-existing logging format, if any
    _remove_existing    - Removes pre-existing file handlers with the same target
    _finalize_kwargs    - Finalizes the handler constructor kwargs
"""

from __future__ import annotations

from logging import FileHandler
from logging.handlers import RotatingFileHandler, TimedRotatingFileHandler
from typing import TYPE_CHECKING

import logset._validate.groups as _validate
from logset._core import _finalize

if TYPE_CHECKING:
    from logging import Formatter, Handler, Logger
    from pathlib import Path
    from typing import Any


def setup(
    level: int,
    logger: str | Logger | Any,
    path: str | Path | Any,
    format: str | Formatter | None | Any,
    fallback_format: str | Formatter | Any,
    rotate_bytes: int | None | Any,
    rotate_when: str | None | Any,
    rotate_interval: int | Any,
    backup_count: int | Any,
    make_parents: bool | Any,
    delay: bool | Any,
    clear_existing: bool | Any,
    propagate: bool | Any,
    **handler_kwargs: Any,
) -> FileHandler | RotatingFileHandler | TimedRotatingFileHandler:
    "Sets up a file logger"

    # Validate
    (
        logger,
        path,
        format,
        fallback_format,
        make_parents,
        delay,
        clear_existing,
        propagate,
    ) = _validate.file_base(
        logger,
        path,
        format,
        fallback_format,
        make_parents,
        delay,
        clear_existing,
        propagate,
    )
    rotate_bytes, rotate_when, rotate_interval, backup_count = _validate.rotation(
        rotate_bytes, rotate_when, rotate_interval, backup_count
    )

    # Validate parent folder existence
    if path.parent.exists() and not path.parent.is_dir():
        raise ValueError("The log file parent exists, but is not a directory")
    elif not path.parent.exists() and not make_parents:
        raise FileNotFoundError("The log file parent directory does not exist")

    # Prepare the appropriate handler
    handler = _prepare_handler(
        path,
        rotate_bytes,
        rotate_when,
        rotate_interval,
        backup_count,
        delay,
        handler_kwargs,
    )

    # Parse the format. Optionally remove pre-existing handlers with the same target
    format = _parse_format(logger, path, format, fallback_format)
    if clear_existing:
        _remove_existing(logger, path)

    # Finalize logger with the new handler
    _finalize.logger(logger, level, handler, format, propagate)
    return handler


#####
# Utilities
#####


def _prepare_handler(
    path: Path,
    rotate_bytes: int | None,
    rotate_when: str | None,
    rotate_interval: int,
    backup_count: int,
    delay: bool,
    handler_kwargs: dict,
) -> FileHandler | RotatingFileHandler | TimedRotatingFileHandler:
    "Creates the appropriate handler for the log file"

    # Prepare the handler type and constructor kwargs
    if rotate_bytes is not None:
        Handler = RotatingFileHandler
        _finalize_kwargs(
            handler_kwargs, maxBytes=rotate_bytes, backupCount=backup_count
        )
        handler_kwargs["maxBytes"] = rotate_bytes
        handler_kwargs["backupCount"] = backup_count
    elif rotate_when is not None:
        Handler = TimedRotatingFileHandler
        _finalize_kwargs(
            handler_kwargs,
            when=rotate_when,
            interval=rotate_interval,
            backupCount=backup_count,
        )
    else:
        Handler = FileHandler

    # Ensure the parent folder exists
    path.parent.mkdir(parents=True, exist_ok=True)

    # Attempt to create the handler, informative error if failed
    try:
        return Handler(path, delay=delay, **handler_kwargs)
    except Exception as error:
        raise ValueError(
            f"Failed to create a {Handler.__name__} using the given kwargs. "
            "Check that the **handler_kwargs are all valid"
        ) from error


def _isexisting(handler: Handler, path: Path) -> bool:
    "True if a handler is a file handler with the same target"

    types = (FileHandler, RotatingFileHandler, TimedRotatingFileHandler)
    return isinstance(handler, types) and handler.baseFilename == str(path)


def _parse_format(
    logger: Logger, path: Path, format: Formatter | None, fallback_format: Formatter
) -> Formatter:
    "Determines the format for the handler"

    # Explicit format has highest priority
    if format is not None:
        return format

    # Otherwise, check for pre-existing format. Use the fallback format if there is
    # no pre-existing handler
    format = _existing_format(logger, path)
    if format is None:
        format = fallback_format
    return format


def _existing_format(logger: Logger, path: Path) -> Formatter | None:
    "Returns the format of a pre-existing handler, if any"

    for handler in logger.handlers:
        if _isexisting(handler, path) and handler.formatter is not None:
            return handler.formatter


def _remove_existing(logger: Logger, path: Path) -> None:
    "Removes any pre-existing file handlers with the same target"

    remove = [handler for handler in logger.handlers if _isexisting(handler, path)]
    for handler in remove:
        logger.removeHandler(handler)


def _finalize_kwargs(handler_kwargs: dict, **overrides: Any) -> None:
    "Finalizes the handler constructor kwargs"

    for key, value in overrides.items():
        if key in handler_kwargs:
            raise ValueError(
                f'You cannot use the "{key}" handler kwarg because logset already '
                "sets this value."
            )
        handler_kwargs[key] = value
