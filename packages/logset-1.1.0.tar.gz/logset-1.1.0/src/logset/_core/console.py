"""
Core logic for setting up a console logger
----------
Functions:
    setup               - Sets up a console log
    _isconsole          - True if a handler is a sys.stderr StreamHandler
    _parse_format       - Determines the format to use for the handler
    _existing_format    - Returns a pre-existing logging format, if any
    _remove_existing    - Removes pre-existing sys.stderr StreamHandlers
"""

from __future__ import annotations

import sys
from logging import StreamHandler
from typing import TYPE_CHECKING

import logset._validate.groups as _validate
from logset._core import _finalize

if TYPE_CHECKING:
    from logging import Formatter, Handler, Logger
    from typing import Any


def setup(
    level: int,
    logger: str | Logger | Any,
    format: str | Formatter | None | Any,
    fallback_format: str | Formatter | Any,
    clear_existing: bool | Any,
    propagate: bool | Any,
):
    "Sets up a console logger"

    # Validate inputs
    logger, format, fallback_format, clear_existing, propagate = _validate.base(
        logger, format, fallback_format, clear_existing, propagate
    )

    # Parse the format. Optionally remove pre-existing sys.stderr handlers
    format = _parse_format(logger, format, fallback_format)
    if clear_existing:
        _remove_existing(logger)

    # Create new handler. Finalize logger and return the handler
    handler = StreamHandler(stream=sys.stderr)
    _finalize.logger(logger, level, handler, format, propagate)
    return handler


#####
# Utilities
#####


def _isconsole(handler: Handler) -> bool:
    "True if a handler is a StreamHandler to sys.stderr"

    return isinstance(handler, StreamHandler) and handler.stream is sys.stderr


def _parse_format(
    logger: Logger, format: Formatter | None, fallback_format: Formatter
) -> Formatter:
    "Determines the format for the handler"

    # Explicit format has highest priority
    if format is not None:
        return format

    # Otherwise, check for pre-existing format, using the fallback format if there
    # are no pre-existing handlers
    format = _existing_format(logger)
    if format is None:
        format = fallback_format
    return format


def _existing_format(logger: Logger) -> Formatter | None:
    "Returns the format of a pre-existing handler, if any"

    for handler in logger.handlers:
        if _isconsole(handler) and handler.formatter is not None:
            return handler.formatter


def _remove_existing(logger: Logger) -> None:
    "Removes any pre-existing sys.stderr StreamHandlers"

    remove = [handler for handler in logger.handlers if _isconsole(handler)]
    for handler in remove:
        logger.removeHandler(handler)
