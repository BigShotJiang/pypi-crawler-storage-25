"""
Modules with convenience functions for easily setting up logs
----------
Python's built-in logging library is powerful, but has a steep learning curve and
several common "gotchas". The `logset` library helps address this by providing
convenience functions that quickly set up simple console (sys.stderr) and file logs for
applications.

Each function allows a user to set up a log with a single function call, without needing
to manage loggers, handlers, formatters, and other logging objects. The functions are
also designed to avoid common issues, such as "double logging" bugs, or logs that fail
to emit messages due to issues with log level configurations.

The `logset` library consists of two modules: `console`, and `file`. The `console`
module provides functions that set up a console log to sys.stderr at a given log level.
The `file` module provide functions that log messages to file - this module supports
basic file logging, as well as log files that rotate either (1) after reaching a
maximum allowed file size, or (2) after a fixed time interval. The functions in each
module are named after the built-in log levels, and include: `debug`, `info`, `warning`,
`error`, and `critical`.
-----
Modules:
    console - Functions that set up console logs to sys.stderr at a given level
    file    - Functions that set up file logs at a given level
"""

from logset._api import console, file

__all__ = ["console", "file"]
