"""
Functions that validate groups of related inputs
----------
Functions:
    base        - Validates base inputs for logger setup
    file_base   - Validates base inputs for setting up a file logger
    rotation    - Ensures rotating file handler options are valid
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import logset._validate.inputs as _validate

if TYPE_CHECKING:
    from logging import Formatter, Logger
    from pathlib import Path
    from typing import Any


def base(
    logger: str | Logger | Any,
    format: str | Formatter | None | Any,
    fallback_format: str | Formatter | Any,
    clear_existing: bool | Any,
    propagate: bool | Any,
) -> tuple[Logger, Formatter | None, Formatter, bool, bool]:
    "Validates base inputs for logger setup"

    logger = _validate.logger(logger)
    if format is not None:
        format = _validate.format(format, "format")
    fallback_format = _validate.format(fallback_format, "fallback_format")
    clear_existing = _validate.clear_existing(clear_existing)
    propagate = _validate.propagate(propagate)
    return logger, format, fallback_format, clear_existing, propagate


def file_base(
    logger: str | Logger | Any,
    path: str | Path | Any,
    format: str | Formatter | None | Any,
    fallback_format: str | Formatter | Any,
    make_parents: bool | Any,
    delay: bool | Any,
    clear_existing: bool | Any,
    propagate: bool | Any,
) -> tuple[Logger, Path, Formatter | None, Formatter, bool, bool, bool, bool]:
    "validates base inputs for a file logging setup"

    path = _validate.path(path)
    logger, format, fallback_format, clear_existing, propagate = base(
        logger, format, fallback_format, clear_existing, propagate
    )
    make_parents = _validate.make_parents(make_parents)
    delay = _validate.delay(delay)
    return (
        logger,
        path,
        format,
        fallback_format,
        make_parents,
        delay,
        clear_existing,
        propagate,
    )


def rotation(
    rotate_bytes: int | None | Any,
    rotate_when: str | None | Any,
    rotate_interval: int | Any,
    backup_count: int | Any,
) -> tuple[int | None, str | None, int | None, int | None]:
    "Ensures rotating handler options are valid"

    # Just exit if no rotation is needed
    if rotate_bytes is None and rotate_when is None:
        return None, None, None, None

    # Only one type of rotation is permitted
    elif rotate_bytes is not None and rotate_when is not None:
        raise ValueError(
            "You cannot set both `rotate_bytes` and `rotate_when` at the same time"
        )

    # Size rotation
    elif rotate_bytes is not None:
        rotate_bytes = _validate.rotate_bytes(rotate_bytes)
        rotate_when = None
        rotate_interval = None

    # Timed rotation
    else:
        rotate_bytes = None
        rotate_when = _validate.rotate_when(rotate_when)
        rotate_interval = _validate.rotate_interval(rotate_interval)

    # All rotation requires a backup count
    backup_count = _validate.backup_count(backup_count)
    return rotate_bytes, rotate_when, rotate_interval, backup_count
