"""
Functions that validate individual inputs. Sorted alphabetically
"""

from __future__ import annotations

from logging import Formatter, Logger, getLogger
from pathlib import Path
from typing import TYPE_CHECKING

import logset._validate.low as _validate

if TYPE_CHECKING:
    from typing import Any


def backup_count(backup_count: int | Any) -> int:
    return _validate.positive_integer(backup_count, "backup_count")


def clear_existing(clear_existing: bool | Any) -> bool:
    return _validate.boolean(clear_existing, "clear_existing")


def delay(delay: bool | Any) -> bool:
    return _validate.boolean(delay, "delay")


def format(format: str | Formatter | Any, name: str) -> Formatter:
    "Checks an input represents a formatter"

    # Formatter objects are valid
    if isinstance(format, Formatter):
        return format

    # Attempt to convert string to Formatter
    elif isinstance(format, str):
        try:
            return Formatter(format, style="%", validate=True)
        except ValueError as error:
            raise ValueError(
                f"Could not convert `{name}` string to logging.Formatter"
            ) from error

    # Anything else is invalid
    else:
        raise TypeError(f"`{name}` must be a string or logging.Formatter object")


def logger(logger: str | Logger | Any) -> Logger:
    "Ensures an input represents a logger"

    if isinstance(logger, Logger):
        return logger
    elif isinstance(logger, str):
        return getLogger(logger)
    else:
        raise TypeError("`logger` must be a string or logging.Logger object")


def make_parents(make_parents: bool | Any) -> bool:
    return _validate.boolean(make_parents, "make_parents")


def path(path: str | Path | Any) -> Path:
    "Ensures an input is a resolvable file path"

    # Convert to path object
    try:
        path = Path(path).resolve()
    except Exception as error:
        raise TypeError(
            "Could not convert `path` to a resolved pathlib.Path object"
        ) from error

    # If the path already exists, then it must be a file
    if path.exists() and not path.is_file():
        raise ValueError(
            "`path` must be the path to a file (rather than a folder or other type)"
        )
    return path


def propagate(propagate: bool | Any) -> bool:
    return _validate.boolean(propagate, "propagate")


def rotate_bytes(rotate_bytes: int | Any) -> int:
    return _validate.positive_integer(rotate_bytes, "rotate_bytes")


def rotate_interval(rotate_interval: int | Any) -> int:
    return _validate.positive_integer(rotate_interval, "rotate_interval")


def rotate_when(rotate_when: str | Any) -> str:
    supported = [
        "S",
        "M",
        "H",
        "D",
        "W0",
        "W1",
        "W2",
        "W3",
        "W4",
        "W5",
        "W6",
        "midnight",
    ]
    if not isinstance(rotate_when, str):
        raise TypeError("`rotate_when` must be a string")
    if rotate_when not in supported:
        supported = ", ".join(supported)
        raise ValueError(
            f"`rotate_when` is not a supported value. "
            f"Supported values include: {supported}"
        )
    return rotate_when
