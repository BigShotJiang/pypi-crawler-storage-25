"""
Functions that check inputs match built-in Python types
----------
Functions:
    boolean             - Checks an input has a boolean representation
    positive_integer    - Checks an input is a positive integer
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from typing import Any


def boolean(input: Any, name: str) -> bool:
    "Ensures an input has a boolean representation"

    try:
        return bool(input)
    except Exception as error:
        raise TypeError(f"Could not convert `{name}` to bool") from error


def positive_integer(input: int | Any, name: str) -> int:
    "Checks an input is a positive integer"

    if not isinstance(input, int):
        raise TypeError(f"`{name}` must be an int")
    if input <= 0:
        raise ValueError(f"`{name}` must be >= 0")
    return input
