"""
Modules that validate user inputs
----------
Modules:
    low     - Functions that validate inputs are built-in Python types
    inputs  - Functions that validate specific inputs
    groups  - Functions that validate groups of related inputs
"""
