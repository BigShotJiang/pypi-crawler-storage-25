"""Thin client for the Microsoft Fabric REST API."""
from datetime import datetime, timezone
from functools import lru_cache
import json
import os
import requests

FABRIC_BASE = os.getenv("FABRIC_BASE_URL", "https://api.fabric.microsoft.com/v1")
FABRIC_RESOURCE = os.getenv("FABRIC_RESOURCE_URI", "https://api.fabric.microsoft.com")


def _get_headers() -> dict:
    # notebookutils is only available inside Fabric notebooks; import lazily so
    # the package is importable in other contexts (tests, packaging, etc.).
    import notebookutils  # noqa: PLC0415
    token = notebookutils.credentials.getToken(FABRIC_RESOURCE)
    return {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }


@lru_cache(maxsize=128)
def get_workspace_id_by_name(workspace_name: str) -> str:
    """Resolve a workspace display name to its ID. Cached per process.

    Args:
        workspace_name: The display name of the Fabric workspace (e.g. "My Workspace").

    Returns:
        The workspace GUID string.

    Raises:
        ValueError: If no workspace with that name is found.
    """
    response = requests.get(f"{FABRIC_BASE}/workspaces", headers=_get_headers())
    response.raise_for_status()
    workspace = next(
        (w for w in response.json().get("value", []) if w["displayName"] == workspace_name),
        None,
    )
    if not workspace:
        raise ValueError(f"Workspace '{workspace_name}' not found.")
    return workspace["id"]


@lru_cache(maxsize=512)
def get_pipeline_id(workspace_id: str, pipeline_name: str) -> str:
    """Resolve a pipeline display name to its ID within a workspace. Cached.

    Args:
        workspace_id: The GUID of the workspace (from get_workspace_id_by_name).
        pipeline_name: The display name of the pipeline (e.g. "Load Sales Data").

    Returns:
        The pipeline GUID string.

    Raises:
        ValueError: If no pipeline with that name is found in the workspace.
    """
    url = f"{FABRIC_BASE}/workspaces/{workspace_id}/dataPipelines"
    response = requests.get(url, headers=_get_headers())
    response.raise_for_status()
    pipeline = next(
        (p for p in response.json().get("value", []) if p["displayName"] == pipeline_name),
        None,
    )
    if not pipeline:
        raise ValueError(f"Pipeline '{pipeline_name}' not found.")
    return pipeline["id"]


def trigger_pipeline(
    process: str,
    workspace_name: str,
    pipeline_name: str,
    parameters: dict | None = None,
) -> tuple[bool, str | None]:
    """Trigger a pipeline run.

    Args:
        process: A label for this run used in log output (e.g. "Load Sales Data").
        workspace_name: The display name of the Fabric workspace.
        pipeline_name: The display name of the pipeline to trigger.
        parameters: Optional dict of pipeline parameters to pass at runtime.

    Returns:
        A tuple of (success, job_instance_id). job_instance_id is None on failure.
    """
    workspace_id = get_workspace_id_by_name(workspace_name)
    pipeline_id = get_pipeline_id(workspace_id, pipeline_name)
    url = (
        f"{FABRIC_BASE}/workspaces/{workspace_id}/items/{pipeline_id}"
        "/jobs/instances?jobType=Pipeline"
    )
    payload = {"executionData": {"parameters": parameters}} if parameters else {}
    response = requests.post(url, headers=_get_headers(), json=payload)
    if response.status_code == 202:
        run_id = response.headers.get("x-ms-job-id")
        print(f"Triggered '{process}' → job ID: {run_id}", flush=True)
        return True, run_id
    print(f"Failed to trigger '{process}': {response.status_code} - {response.text}", flush=True)
    return False, None


def check_pipeline_status(
    workspace_id: str,
    pipeline_id: str,
    run_id: str,
) -> tuple[str | None, str | None, str | None]:
    """Return the current status of a pipeline job instance.

    Args:
        workspace_id: The GUID of the workspace.
        pipeline_id: The GUID of the pipeline.
        run_id: The job instance ID returned by trigger_pipeline.

    Returns:
        A tuple of (status, start_time_utc, failure_message).
        status is a string such as "Running", "Succeeded", or "Failed".
        failure_message is only populated when status is "Failed".
    """
    url = (
        f"{FABRIC_BASE}/workspaces/{workspace_id}/items/{pipeline_id}"
        f"/jobs/instances/{run_id}"
    )
    response = requests.get(url, headers=_get_headers())
    job = response.json()
    status = job.get("status")
    failure_message = job.get("failureReason", {}).get("message") if status == "Failed" else None
    return status, job.get("startTimeUtc"), failure_message


def get_pipeline_activity_run_details(workspace_id: str, run_id: str) -> str | None:
    """Return a one-line summary of rows and data read/written for a pipeline run.

    Args:
        workspace_id: The GUID of the workspace.
        run_id: The job instance ID returned by trigger_pipeline.

    Returns:
        A string summarising rows read, rows copied, data read, and data written.
        Returns None if the details are unavailable or the request fails.
    """
    url = (
        f"{FABRIC_BASE}/workspaces/{workspace_id}/datapipelines/pipelineruns"
        f"/{run_id}/queryactivityruns"
    )
    body = {"lastUpdatedBefore": datetime.now(timezone.utc).isoformat()}
    try:
        response = requests.post(url, headers=_get_headers(), data=json.dumps(body))
        response.raise_for_status()
        data = response.json()
        if not (data and isinstance(data.get("value"), list) and data["value"]):
            return None
        output = data["value"][0].get("output", {})
        return (
            f"Rows Read: {output.get('rowsRead')}, "
            f"Rows Copied: {output.get('rowsCopied')}, "
            f"Data Read: {output.get('dataRead')} bytes, "
            f"Data Written: {output.get('dataWritten')} bytes"
        )
    except Exception as e:
        print(f"Activity run details unavailable: {e}", flush=True)
        return None
