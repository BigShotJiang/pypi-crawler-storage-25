"""
msfabric_utils — Utility functions for Microsoft Fabric notebooks.

Available functions
-------------------
API (msfabric_utils.api)
    get_workspace_id_by_name(workspace_name)
        Resolve a workspace display name to its ID.

    get_pipeline_id(workspace_id, pipeline_name)
        Resolve a pipeline display name to its ID within a workspace.

    trigger_pipeline(process, workspace_name, pipeline_name, parameters=None)
        Trigger a pipeline run. Returns (success, job_instance_id).

    check_pipeline_status(workspace_id, pipeline_id, run_id)
        Returns (status, start_time_utc, failure_message) for a job instance.

    get_pipeline_activity_run_details(workspace_id, run_id)
        Returns a one-line summary of rows/data read and written, or None.

Logging (msfabric_utils.events)
    log_event(table_name, process, status, message, run_id=None)
        Append a structured log row to a Spark table.

DAG (msfabric_utils.dag)
    break_cycles(df, process_col="Process", dependency_col="Dependency")
        Detect and remove cycles in a dependency DataFrame.
        Returns (cleaned_df, removed_edges).

Usage
-----
    from msfabric_utils import (
        get_workspace_id_by_name, get_pipeline_id, trigger_pipeline,
        check_pipeline_status, get_pipeline_activity_run_details,
        log_event, break_cycles,
    )
"""

from msfabric_utils.api import (
    check_pipeline_status,
    get_pipeline_activity_run_details,
    get_pipeline_id,
    get_workspace_id_by_name,
    trigger_pipeline,
)
from msfabric_utils.dag import break_cycles
from msfabric_utils.events import log_event

__version__ = "0.1.2"

__all__ = [
    "get_workspace_id_by_name",
    "get_pipeline_id",
    "trigger_pipeline",
    "check_pipeline_status",
    "get_pipeline_activity_run_details",
    "log_event",
    "break_cycles",
]
