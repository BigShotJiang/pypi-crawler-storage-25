"""Generic dependency-graph utilities for Spark DataFrames."""
from collections import defaultdict


def break_cycles(df, process_col: str = "Process", dependency_col: str = "Dependency"):
    """Detect and remove cycles in a (dependency -> process) edge list.

    Args:
        df: A Spark DataFrame with one row per dependency edge.
        process_col: Name of the column containing the dependent process (default "Process").
        dependency_col: Name of the column containing the upstream dependency (default "Dependency").

    Returns:
        A tuple of (cleaned_df, removed_edges) where cleaned_df has the cyclic edges
        removed, and removed_edges is a list of (dependency, process) tuples that were dropped.
    """
    graph = defaultdict(list)
    edges = set()

    for row in df.collect():
        dep = row[dependency_col]
        proc = row[process_col]
        if dep:
            graph[dep].append(proc)
            edges.add((dep, proc))

    visited = set()
    removed_edges = []

    def visit(node, path):
        if node in path:
            cycle_start = path.index(node)
            cycle_path = path[cycle_start:] + [node]
            u, v = cycle_path[-2], cycle_path[-1]
            if (u, v) in edges:
                removed_edges.append((u, v))
                graph[u].remove(v)
                edges.remove((u, v))
            return
        if node in visited:
            return
        path.append(node)
        for neighbor in list(graph[node]):
            visit(neighbor, path)
        path.pop()
        visited.add(node)

    for node in list(graph):
        visit(node, [])

    if not removed_edges:
        return df, []

    cleaned_df = df.filter(
        ~(
            df[dependency_col].isin([u for u, _ in removed_edges])
            & df[process_col].isin([v for _, v in removed_edges])
        )
    )
    return cleaned_df, removed_edges
