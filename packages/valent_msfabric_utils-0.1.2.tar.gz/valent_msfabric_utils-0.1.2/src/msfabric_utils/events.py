"""Append-only logger that writes structured rows to a Spark table."""
from datetime import datetime


def log_event(
    table_name: str,
    process: str,
    status: str,
    message: str,
    run_id: str | None = None,
) -> None:
    """Append one structured log row to a Spark table. Requires an active SparkSession.

    Args:
        table_name: The fully qualified Spark table to write to (e.g. "mydb.pipeline_logs").
        process: A label identifying the process being logged (e.g. "Load Sales Data").
        status: The status to record (e.g. "Started", "Succeeded", "Failed").
        message: A human-readable description of the event.
        run_id: Optional job instance ID from trigger_pipeline to correlate log rows with runs.
    """
    from pyspark.sql import Row, SparkSession  # noqa: PLC0415

    spark = SparkSession.getActiveSession()
    if spark is None:
        raise RuntimeError("No active SparkSession; log_event requires Spark.")

    log_data = {
        "timestamp": datetime.utcnow().isoformat(),
        "process": process,
        "status": status,
        "message": message,
    }
    if run_id is not None:
        log_data["run_id"] = run_id

    spark.createDataFrame([Row(**log_data)]).write.mode("append").saveAsTable(table_name)
