HEROS Tools Documentation
=========================

Herostools is a collection of useful services and scripts for your HEROS environment.


Services
********

The services can readily be launched by BOSS or instantiated from your python environment of choice.

Find a list of existing tools below.

* :doc:`aggregator`
* :doc:`diskarchiver`

.. toctree::
   :maxdepth: 1
   :caption: Services
   :hidden:

   aggregator
   diskarchiver


Scripts
*******

A collection of useful scripts and utilities to be run via CLI.

* :doc:`scripts/zenoh-tools`

.. toctree::
   :maxdepth: 1
   :caption: Scripts
   :hidden:

   scripts/zenoh-tools

