Zenoh Tools
===========

Scout
*****

.. argparse::
   :module: herostools.scripts.zenoh_scout
   :func: get_parser
   :prog: heros_zenoh_scout


.. admonition:: Example

  .. code-block:: text

    > uv run heros_zenoh_scout --subnet 172.16.50.0/24 192.168.51.0/24

    Scouting for hellos for 9/10 seconds...
    Received 52 unique hellos

    === Zenoh peers in subnet: 172.16.50.0/24 ===

    IP: 172.16.50.2
      Count: 29

    IP: 172.16.50.3
      Count: 12

    IP: 172.16.50.50
      Count: 4


    === Zenoh peers in subnet: 192.168.51.0/24 ===

    IP: 192.168.51.9
      Count: 4

    === Zenoh peers NOT in subnet(s) ===
      ['tcp/[fe80::63a4:19ff:163d:d61b]:43659', 'tcp/[fe80::70fd:d2ff:fecd:7cff]:43659', 'tcp/[fe80::8c80:a6ff:fe78:a274]:43659', 'tcp/[fe80::d46c:d3ff:fe8b:7388]:43659', 'tcp/172.16.5.2:43659', 'tcp/172.17.0.1:43659']
      ['tcp/[fe80::5517:b1b9:14b4:dd3a]:58026', 'tcp/172.16.111.25:58026']
      ['tcp/[fe80::63a4:19ff:163d:d61b]:36429', 'tcp/[fe80::70fd:d2ff:fecd:7cff]:36429', 'tcp/[fe80::8c80:a6ff:fe78:a274]:36429', 'tcp/[fe80::d46c:d3ff:fe8b:7388]:36429', 'tcp/172.16.5.2:36429', 'tcp/172.17.0.1:36429']
      ['tcp/[fe80::5517:b1b9:14b4:dd3a]:59879', 'tcp/172.16.111.25:59879']
      ['tcp/[fe80::63a4:19ff:163d:d61b]:39337', 'tcp/[fe80::70fd:d2ff:fecd:7cff]:39337', 'tcp/[fe80::8c80:a6ff:fe78:a274]:39337', 'tcp/[fe80::d46c:d3ff:fe8b:7388]:39337', 'tcp/172.16.5.2:39337', 'tcp/172.17.0.1:39337']
      ['tcp/[fe80::63a4:19ff:163d:d61b]:7447', 'tcp/[fe80::70fd:d2ff:fecd:7cff]:7447', 'tcp/[fe80::8c80:a6ff:fe78:a274]:7447', 'tcp/[fe80::d46c:d3ff:fe8b:7388]:7447', 'tcp/172.16.5.2:7447', 'tcp/172.17.0.1:7447']
      ['tcp/[fe80::63a4:19ff:163d:d61b]:38265', 'tcp/[fe80::70fd:d2ff:fecd:7cff]:38265', 'tcp/[fe80::8c80:a6ff:fe78:a274]:38265', 'tcp/[fe80::d46c:d3ff:fe8b:7388]:38265', 'tcp/172.16.5.2:38265', 'tcp/172.17.0.1:38265']
