import io
import os
import base64
from PIL import Image
import fitz  # PyMuPDF
import cv2   # 追加: 動画フレームのオンメモリ抽出用

#----------------------------------------------------------------------
# メディア入力（パスのリストや単一パス）を受け取り、
# LLMに渡せるBase64文字列のリストを返すメイン関数
#----------------------------------------------------------------------
def process_media_to_base64(media_paths, max_size=2048, max_frames=24, save_frames=False, save_dir="output/frames"):
    encoded_images = []
    if isinstance(media_paths, str):
        media_paths = [media_paths]
    if not media_paths:
        return []
    
    for entry in media_paths:
        if is_image_file(entry):
            try:
                b64 = encode_image_to_base64(entry, max_size=max_size)
                encoded_images.append(b64)
            except Exception as e:
                print(f"Warning: Failed to process image {entry}: {e}")
        elif entry.lower().endswith(".pdf") and os.path.exists(entry):
            try:
                pdf_b64_list = pdf_to_base64_images(entry, max_size=max_size)
                encoded_images.extend(pdf_b64_list)
            except Exception as e:
                print(f"Warning: Failed to process PDF {entry}: {e}")
        elif is_video_file(entry):
            try:
                # save_frames と save_dir を動画処理関数に引き継ぐ
                video_b64_list = video_to_base64_frames(entry, max_frames=max_frames, save_frames=save_frames, save_dir=save_dir)
                encoded_images.extend(video_b64_list)
            except Exception as e:
                print(f"Warning: Failed to process Video {entry}: {e}")
        else:
            print(f"Warning: Skipped invalid file path: {entry}")
    return encoded_images

#----------------------------------------------------------------------
# 動画を読み込み、指定した最大フレーム数で等間隔に画像を抽出（オンメモリ）
#----------------------------------------------------------------------
def video_to_base64_frames(video_path, max_frames=24, save_frames=False, save_dir="output/frames"):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise RuntimeError("動画を開けません")

    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    step = max(total_frames // max_frames, 1)

    images = []
    frame_index = 0
    saved_count = 0

    # 保存ディレクトリの作成
    if save_frames:
        os.makedirs(save_dir, exist_ok=True)
        print(f"Debug: Extracting frames and saving to '{save_dir}'...")

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        if frame_index % step == 0:
            # JPEGにエンコード
            success, buffer = cv2.imencode(".jpg", frame)

            if success:
                encoded = base64.b64encode(buffer).decode()
                images.append(encoded)

                # フラグがTrueならフレームを保存
                if save_frames:
                    save_path = os.path.join(save_dir, f"frame_{saved_count:04d}.jpg")
                    cv2.imwrite(save_path, frame)
                    saved_count += 1

            if len(images) >= max_frames:
                break

        frame_index += 1

    cap.release()
    return images

#----------------------------------------------------------------------
# 画像ファイルかどうかの判定
#----------------------------------------------------------------------
def is_image_file(file_path):
    if not file_path or not isinstance(file_path, str):
        return False
    image_extensions = ['.png', '.jpg', '.jpeg', '.bmp', '.gif', '.webp']
    _, ext = os.path.splitext(file_path.lower())
    return ext in image_extensions and os.path.exists(file_path)

#----------------------------------------------------------------------
# 動画ファイルかどうかの判定
#----------------------------------------------------------------------
def is_video_file(file_path):
    if not file_path or not isinstance(file_path, str):
        return False
    video_extensions = ['.mp4', '.avi', '.mov', '.mkv', '.webm']
    _, ext = os.path.splitext(file_path.lower())
    return ext in video_extensions and os.path.exists(file_path)

#----------------------------------------------------------------------
# 画像パスを受け取り、リサイズしてBase64文字列を返す
#----------------------------------------------------------------------
def encode_image_to_base64(image_path, max_size=2048):
    try:
        with Image.open(image_path) as img:
            if img.mode in ('RGBA', 'P'):
                img = img.convert("RGBA")
                background = Image.new("RGB", img.size, (255, 255, 255))
                background.paste(img, mask=img.split()[3]) 
                img = background
            elif img.mode != 'RGB':
                img = img.convert('RGB')
            img.thumbnail((max_size, max_size), Image.LANCZOS)
            buffered = io.BytesIO()
            img.save(buffered, format="PNG")
            img_str = base64.b64encode(buffered.getvalue()).decode("utf-8")
            return img_str
    except Exception as e:
        raise RuntimeError(f"Error encoding image {image_path}: {e}")

#----------------------------------------------------------------------
# PDFを読み込み、各ページを画像化してBase64リストで返す（ファイル保存なし）
#----------------------------------------------------------------------
def pdf_to_base64_images(pdf_path, max_size=2048):
    if not os.path.exists(pdf_path):
        raise FileNotFoundError(f"PDF not found: {pdf_path}")
    doc = fitz.open(pdf_path)
    b64_list = []
    print(f"Converting PDF '{os.path.basename(pdf_path)}' for high-precision reading...")
    for page in doc:
        pix = page.get_pixmap(dpi=200) 
        img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
        img.thumbnail((max_size, max_size), Image.LANCZOS)
        buffered = io.BytesIO()
        img.save(buffered, format="PNG")
        img_str = base64.b64encode(buffered.getvalue()).decode("utf-8")
        b64_list.append(img_str)
    doc.close()
    return b64_list