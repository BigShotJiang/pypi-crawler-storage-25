import os
import gc
import time
import subprocess
import requests
import atexit
from typing import Optional, List, Generator
from huggingface_hub import hf_hub_download, list_repo_files
from openai import OpenAI

class LlamaCppUnifiedLLM:
    def __init__(
            self, 
            model_path_or_repo: str,
            filename: Optional[str] = None,
            mmproj_path_or_repo: Optional[str] = None,
            mmproj_filename: str = "mmproj-model-f16.gguf",
            temp: float = 0.6,
            n_ctx: int = 4096,
            n_gpu_layers: int = -1,
            port: int = 8001,
            enable_thinking: Optional[bool] = None
    ):
        self.server_process = None
        self.port = port
        self.temp = temp
        self.model_alias = "local-model"
        
        # 1. Visionハンドラ（mmproj）の準備
        mmproj_path = None
        if mmproj_path_or_repo:
            mmproj_path = self._prepare_file(mmproj_path_or_repo, mmproj_filename)

        # 2. 本体モデルの準備 (ローカルフォルダ対応版)
        if os.path.exists(model_path_or_repo):
            if os.path.isdir(model_path_or_repo):
                # フォルダが指定された場合：中からキーワードに合うファイルを探す
                search_keyword = filename or ".gguf"
                clean_keyword = search_keyword.replace("*", "").lower()
                found_file = None
                for f in os.listdir(model_path_or_repo):
                    if f.endswith(".gguf") and clean_keyword in f.lower():
                        found_file = os.path.join(model_path_or_repo, f)
                        break
                if not found_file:
                    raise ValueError(f"フォルダ '{model_path_or_repo}' 内に '{search_keyword}' に一致するファイルが見つかりません。")
                self.model_path = found_file
                print(f"ローカルフォルダからモデルを発見: {self.model_path}")
            else:
                # ファイルが直接指定された場合
                self.model_path = model_path_or_repo
                print(f"ローカルモデルを指定: {self.model_path}")
        else:
            # Hugging Faceからのダウンロード
            print(f"Hugging Faceリポジトリ '{model_path_or_repo}' を確認中...")
            search_keyword = filename or "Q4_K_M"
            exact_filename = self._find_gguf_filename(model_path_or_repo, search_keyword)
            print(f"対象ファイルを発見: {exact_filename} (ダウンロード開始/キャッシュ確認)")
            self.model_path = hf_hub_download(repo_id=model_path_or_repo, filename=exact_filename)
            print(f"モデルパス: {self.model_path}")

        # 3. 起動コマンドのベースを保存しておく
        self.cmd_base = [
            "python", "-m", "llama_cpp.server",
            "--model", self.model_path,
            "--host", "127.0.0.1",
            "--port", str(self.port),
            "--n_ctx", str(n_ctx),
            "--n_gpu_layers", str(n_gpu_layers)
        ]
        
        if mmproj_path:
            self.cmd_base.extend(["--chat_format", "llava-1-5", "--clip_model_path", mmproj_path])
        
        if enable_thinking is not None:
            thinking_str = "true" if enable_thinking else "false"
            self.cmd_base.extend(["--chat-template-kwargs", f'{{"enable_thinking":{thinking_str}}}'])

        # ※この段階ではまだサーバーを起動しない！
        atexit.register(self.free_model)

    def _start_server(self):
        """推論の直前にサーバーを起動する"""
        if self.server_process is not None:
            return # 既に起動中なら何もしない

        print(f"\n🚀 モデルをVRAMにロード中 (Port: {self.port})...")
        self.server_process = subprocess.Popen(
            self.cmd_base, 
            stdout=subprocess.DEVNULL, 
            stderr=subprocess.DEVNULL
        )
        self._wait_for_server()
        
        # クライアントの初期化
        self.client = OpenAI(
            base_url=f"http://127.0.0.1:{self.port}/v1",
            api_key="sk-no-key-required"
        )
        try:
            models = self.client.models.list()
            self.model_alias = models.data[0].id
        except Exception:
            pass

    def _wait_for_server(self, timeout: int = 120):
        start_time = time.time()
        health_url = f"http://127.0.0.1:{self.port}/v1/models"
        while True:
            # 🌟 追加：サーバープロセスが既に死んでいないかチェック
            if self.server_process.poll() is not None:
                self.free_model()
                raise RuntimeError("サーバーが起動直後に予期せず終了しました。モデルの未対応構造やメモリ不足(OOM)の可能性があります。")

            try:
                response = requests.get(health_url)
                if response.status_code == 200:
                    return
            except requests.ConnectionError:
                pass
            
            if time.time() - start_time > timeout:
                self.free_model()
                raise TimeoutError("サーバー起動（モデルロード）がタイムアウトしました。")
            time.sleep(1)

    def _find_gguf_filename(self, repo_id: str, keyword: str) -> str:
        if keyword.endswith(".gguf") and "*" not in keyword:
            return keyword
        clean_keyword = keyword.replace("*", "").lower()
        files = list_repo_files(repo_id=repo_id)
        for f in files:
            if f.endswith(".gguf") and clean_keyword in f.lower():
                return f
        raise ValueError(f"'{keyword}' を含む .gguf ファイルが見つかりませんでした。")

    def _prepare_file(self, path_or_repo: str, filename: str) -> str:
        if os.path.exists(path_or_repo):
            return path_or_repo
        return hf_hub_download(repo_id=path_or_repo, filename=filename)

    def respond(
        self, 
        user_text: str, 
        user_images: Optional[List[str]] = None, 
        system_prompt: str = "あなたは優秀なアシスタントです。", 
        stream: bool = False
    ) -> Generator[str, None, None]:
        
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        
        if not user_images:
            messages.append({"role": "user", "content": user_text})
        else:
            content = [{"type": "text", "text": user_text}]
            for b64 in user_images:
                img_url = b64 if b64.startswith("data:") else f"data:image/jpeg;base64,{b64}"
                content.append({"type": "image_url", "image_url": {"url": img_url}})
            messages.append({"role": "user", "content": content})

        try:
            # サーバー起動処理も try の中に入れることで、エラー時にチャット画面にエラーを返すようにする
            self._start_server()

            response = self.client.chat.completions.create(
                model=self.model_alias,
                messages=messages,
                temperature=self.temp,
                stream=stream
            )
            
            if stream:
                for chunk in response:
                    if chunk.choices and chunk.choices[0].delta.content:
                        yield chunk.choices[0].delta.content
            else:
                yield response.choices[0].message.content
                
        except Exception as e:
            yield f"\n[Error] {str(e)}\n"
            
        finally:
            # 2. 生成が終わったら（またはエラーが起きたら）必ずサーバーを終了してVRAM解放
            self.free_model()

    def free_model(self):
        if self.server_process:
            print("\n🛑 推論終了: サーバーを停止し、VRAMを解放します...")
            self.server_process.terminate()
            try:
                self.server_process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.server_process.kill()
            self.server_process = None
        gc.collect()