import time
from types import SimpleNamespace

def mlx_like_stream(generator, delay=0.01):
    for chunk in generator:
        text = chunk.text if hasattr(chunk, "text") else str(chunk)

        # 1文字ずつスムーズに出す
        for ch in text:
            yield SimpleNamespace(text=ch)
            time.sleep(delay)