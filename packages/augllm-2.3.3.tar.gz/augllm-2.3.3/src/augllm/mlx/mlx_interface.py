import mlx.core as mx
import mlx_lm
from mlx_lm.sample_utils import make_sampler
#
import mlx_vlm
from mlx_vlm.prompt_utils import apply_chat_template
from mlx_vlm.utils import load_config
from .mlx_like_stream import mlx_like_stream
#
import gc
from types import SimpleNamespace
from .toggle_hf_progress_bar import toggle_hf_progress_bar

#-------------------------------------------------------------------
# モデルのロード・解放・生成を管理するインターフェースクラス
#-------------------------------------------------------------------
class MlxLLMInterface:
    def __init__(
        self, 
        model_path: str, 
        use_vision: bool = False, 
        temp: float = 0.0,
        top_k: int = -1, 
        top_p: float = 1.0, 
        min_p: float = 0.0, 
        max_tokens: int = 8192,
        enable_thinking: bool = False,
        keep_alive: bool = False  # モデルをメモリに保持するか
    ):
        self.model_path = model_path
        self.use_vision = use_vision
        self.enable_thinking = enable_thinking
        self.keep_alive = keep_alive
        
        # サンプリングパラメータの保持
        self.temp = temp
        self.top_k = top_k
        self.top_p = top_p
        self.min_p = min_p
        self.max_tokens = max_tokens
            
        self.model = None
        self.tokenizer = None
        self.processor = None
        self.sampler = None
        
        # ロード前にチェックを実行
        toggle_hf_progress_bar(model_path=model_path)

    #---------------------------------------------------------
    def _load_model(self):

        # モデルが既にロードされている場合はスキップ
        if self.model is not None:
            return
        
        # 指定されたパラメータでサンプラーを固定
        self.sampler = make_sampler(
            temp=self.temp,
            top_k=self.top_k, 
            top_p=self.top_p, 
            min_p=self.min_p
        )
        
        if self.use_vision:
            # VLM（画像＋テキスト）アーキテクチャモデルのロード
            self.model, self.processor = mlx_vlm.load(self.model_path, trust_remote_code=True)
        else:
            # LLM（テキスト専用）アーキテクチャモデルのロード
            self.model, self.tokenizer = mlx_lm.load(self.model_path)
    
    #---------------------------------------------------------
    def _free_model(self):
        # メモリの明示的な解放
        self.model = None
        self.tokenizer = None
        self.processor = None
        self.sampler = None
        gc.collect()
        mx.clear_cache()

    #---------------------------------------------------------
    def generate(self, messages, images=None, stream=False):
        """
        インスタンス化時に設定された sampler と max_tokens を使用して生成。
        """
        # 1. モデルのロード
        self._load_model()

        try:
            #---------------------------------------------------------
            # VLM (Vision-Language Model) を使用するルート
            #---------------------------------------------------------
            if self.use_vision:
                
                config = load_config(self.model_path)

                prompt = apply_chat_template(
                    self.processor,
                    config,
                    messages,
                    num_images=len(images) if images else 0,
                    enable_thinking=self.enable_thinking
                )

                if stream:
                    raw_stream = mlx_vlm.stream_generate(
                        self.model, 
                        self.processor, 
                        prompt=prompt, 
                        image=images, 
                        sampler=self.sampler, 
                        max_tokens=self.max_tokens
                    )
                    yield from mlx_like_stream(raw_stream)
                else:
                    full_text = mlx_vlm.generate(
                        self.model, 
                        self.processor, 
                        prompt=prompt, 
                        image=images, 
                        sampler=self.sampler, 
                        max_tokens=self.max_tokens
                    )
                    yield SimpleNamespace(text=full_text)

            #---------------------------------------------------------
            # LLM (テキスト専用モデル) を使用するルート
            #---------------------------------------------------------
            else:
                prompt = self.tokenizer.apply_chat_template(
                    messages,
                    add_generation_prompt=True,
                    enable_thinking=self.enable_thinking
                )

                if stream:
                    yield from mlx_lm.stream_generate(
                        self.model, 
                        self.tokenizer, 
                        prompt=prompt, 
                        sampler=self.sampler, 
                        max_tokens=self.max_tokens
                    )
                else:
                    full_text = mlx_lm.generate(
                        self.model, 
                        self.tokenizer, 
                        prompt=prompt, 
                        sampler=self.sampler, 
                        max_tokens=self.max_tokens
                    )
                    yield SimpleNamespace(text=full_text)
        
        finally:
            # 2. keep_alive が False の場合のみ、推論終了後に解放
            if not self.keep_alive:
                self._free_model()