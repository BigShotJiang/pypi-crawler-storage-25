
import os
from PIL import Image
import fitz  # PyMuPDF
import cv2

#----------------------------------------------------------------------
# メディア入力（パスのリストや単一パス）を受け取り、
# MLX(VLM)に渡せる PIL.Image オブジェクトのリストを返すメイン関数
#----------------------------------------------------------------------
def process_media_to_pil(
        media_paths, 
        max_size=2048, 
        max_frames=24, 
        save_frames=False, 
        save_dir="output/frames"
):
    pil_images = []
    
    # 単一のパス文字列ならリストに変換
    if isinstance(media_paths, str):
        media_paths = [media_paths]
        
    if not media_paths:
        return []
    
    for entry in media_paths:
        # 画像ファイルの場合
        if is_image_file(entry):
            try:
                img = process_image_to_pil(entry, max_size=max_size)
                pil_images.append(img)
            except Exception as e:
                print(f"Warning: Failed to process image {entry}: {e}")
        
        # PDFファイルの場合
        elif entry.lower().endswith(".pdf") and os.path.exists(entry):
            try:
                pdf_pil_list = pdf_to_pil_images(entry, max_size=max_size)
                pil_images.extend(pdf_pil_list)
            except Exception as e:
                print(f"Warning: Failed to process PDF {entry}: {e}")

        # 動画ファイルの場合
        elif is_video_file(entry):
            try:
                video_pil_list = video_to_pil_frames(entry, max_frames=max_frames, save_frames=save_frames, save_dir=save_dir)
                pil_images.extend(video_pil_list)
            except Exception as e:
                print(f"Warning: Failed to process Video {entry}: {e}")
        
        else:
            print(f"Warning: Skipped invalid or unsupported file path: {entry}")

    return pil_images

#----------------------------------------------------------------------
# 画像パスを受け取り、リサイズして PIL Image を返す
#----------------------------------------------------------------------
def process_image_to_pil(image_path, max_size=2048):
    try:
        # 画像を開く (with句を抜けても使えるように安全に処理)
        with Image.open(image_path) as img:
            # RGBAやパレットモードをRGBに変換 (透過背景を白で塗りつぶす)
            if img.mode in ('RGBA', 'P'):
                img = img.convert("RGBA")
                background = Image.new("RGB", img.size, (255, 255, 255))
                background.paste(img, mask=img.split()[3]) 
                img = background
            elif img.mode != 'RGB':
                img = img.convert('RGB')
            else:
                img = img.copy() # 元画像がRGBの場合もコピーを作成して安全に返す
            
            # リサイズ（アスペクト比維持）
            img.thumbnail((max_size, max_size), Image.LANCZOS)
            
            return img
            
    except Exception as e:
        raise RuntimeError(f"Error processing image {image_path}: {e}")

#----------------------------------------------------------------------
# PDFを読み込み、各ページを PIL Image のリストで返す
#----------------------------------------------------------------------
def pdf_to_pil_images(pdf_path, max_size=2048):
    if not os.path.exists(pdf_path):
        raise FileNotFoundError(f"PDF not found: {pdf_path}")
    
    doc = fitz.open(pdf_path)
    pil_list = []
    
    print(f"Converting PDF '{os.path.basename(pdf_path)}' to PIL Images...")
    
    for page in doc:
        pix = page.get_pixmap(dpi=200) 
        img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
        img.thumbnail((max_size, max_size), Image.LANCZOS)
        
        pil_list.append(img)
        
    doc.close()
    return pil_list

#----------------------------------------------------------------------
# 動画を読み込み、画像を抽出して PIL Image のリストで返す
#----------------------------------------------------------------------
def video_to_pil_frames(video_path, max_frames=24, save_frames=False, save_dir="output/frames"):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open video: {video_path}")

    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    step = max(total_frames // max_frames, 1)

    pil_list = []
    frame_index = 0
    saved_count = 0

    # 保存ディレクトリの作成
    if save_frames:
        os.makedirs(save_dir, exist_ok=True)
        print(f"Debug: Extracting frames and saving to '{save_dir}'...")

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        if frame_index % step == 0:
            # フラグがTrueならフレームを保存 (cv2のBGR形式のまま保存)
            if save_frames:
                save_path = os.path.join(save_dir, f"frame_{saved_count:04d}.jpg")
                cv2.imwrite(save_path, frame)
                saved_count += 1

            # OpenCVのBGR配列をRGB配列に変換
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            
            # numpy配列からPIL Imageに変換
            pil_img = Image.fromarray(rgb_frame)
            pil_list.append(pil_img)

            if len(pil_list) >= max_frames:
                break

        frame_index += 1

    cap.release()
    return pil_list

#----------------------------------------------------------------------
# 画像ファイルかどうかの判定
#----------------------------------------------------------------------
def is_image_file(file_path):
    if not file_path or not isinstance(file_path, str):
        return False
    image_extensions = ['.png', '.jpg', '.jpeg', '.bmp', '.gif', '.webp']
    _, ext = os.path.splitext(file_path.lower())
    return ext in image_extensions and os.path.exists(file_path)

#----------------------------------------------------------------------
# 動画ファイルかどうかの判定
#----------------------------------------------------------------------
def is_video_file(file_path):
    if not file_path or not isinstance(file_path, str):
        return False
    video_extensions = ['.mp4', '.avi', '.mov', '.mkv', '.webm']
    _, ext = os.path.splitext(file_path.lower())
    return ext in video_extensions and os.path.exists(file_path)