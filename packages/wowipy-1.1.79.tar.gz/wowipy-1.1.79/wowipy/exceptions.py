class WowiPyException(Exception):
    pass
