"""Display label mappings for MCP tool outputs.

Pure constants module with no I/O. Provides human-readable labels for
raw technical identifiers (Form.io component types, Java role class names,
determinant types, transition types). Consumed by service_ai_map,
analyze_service, and service_to_yaml.

Labels use noun-phrase voice ("Single-line text input"), not instructions
("Type your answer"), since the target audience is AI agents consuming
tool output — not end users reading a citizen-facing manual.
"""

from __future__ import annotations

from typing import Any

__all__ = [
    "COMPONENT_TYPE_LABELS",
    "DETERMINANT_TYPE_LABELS",
    "ROLE_TYPE_LABELS",
    "TRANSITION_TYPE_LABELS",
    "enrich_role_type",
    "enrich_transition_type",
    "enrich_determinant_type",
    "build_ui_labels",
]

_UNKNOWN = "Unknown"


# Form.io component types used by BPA services.
# Verified against live BPA instance (Jamaica) on 2026-04-09.
COMPONENT_TYPE_LABELS: dict[str, str] = {
    # Standard Form.io input components
    "textfield": "Single-line text input",
    "textarea": "Multi-line text input",
    "number": "Numeric input",
    "password": "Password input",
    "checkbox": "Checkbox",
    "select": "Dropdown selection",
    "selectboxes": "Multiple checkboxes",
    "radio": "Radio button group",
    "datetime": "Date/time picker",
    "day": "Date picker (day only)",
    "time": "Time picker",
    "currency": "Currency amount input",
    "email": "Email address input",
    "url": "URL input",
    "phoneNumber": "Phone number input",
    "address": "Address input",
    "file": "File upload",
    "button": "Button",
    "hidden": "Hidden field",
    "resource": "Resource reference",
    "signature": "Signature input",
    "survey": "Survey question",
    # Standard Form.io layout / container components
    "panel": "Section container",
    "columns": "Column layout",
    "tabs": "Tabbed layout",
    "tab": "Tab page",
    "fieldset": "Field group",
    "well": "Highlighted container",
    "container": "Generic container",
    "editgrid": "Repeating table (add/remove rows)",
    "datagrid": "Inline repeating grid",
    "table": "Static table layout",
    # Standard Form.io presentation
    "htmlelement": "HTML element",
    "content": "Static content block",
    "form": "Embedded form",
    # BPA-specific custom components
    "qrcode": "QR code renderer",
    "barcode": "Barcode renderer",
    "leafletmap": "Map location picker",
    "dropdown": "Custom dropdown",
    "alert": "Alert banner",
    "receipt": "Receipt number field",
    "iSwear": "Oath/affidavit checkbox",
    "myList": "List widget",
    "mycontent": "Rich content block",
    "nestedHtmlElement": "HTML with embedded components",
    "digitalSignature": "Digital signature",
    # Sentinels observed in real API output
    "unknown": "Unrecognized component",
    "string": "Raw string field",
}


# Determinant types (API serialized lowercase form).
# Backend uses CamelCase @DiscriminatorValue ("Text", "Boolean") but
# Jackson/MCP serializes lowercase. Verified against live API on 2026-04-09.
DETERMINANT_TYPE_LABELS: dict[str, str] = {
    "text": "Text condition",
    "boolean": "Yes/No condition",
    "date": "Date condition",
    "numeric": "Numeric condition",
    "money": "Money amount condition",
    "radio": "Radio selection condition",
    "select": "Dropdown selection condition",
    "selectboxes": "Multiple checkboxes condition",
    "classification": "Catalog-backed condition",
    "grid": "Grid row condition",
    "gridcomponent": "Grid component condition",
    "file": "File presence condition",
    "fileupload": "File upload condition",
    "subcatalog": "Sub-catalog condition",
    "button": "Button action condition",
}


# Java Role class discriminator values from @DiscriminatorValue annotations.
# Verified in BPA-backend Role.java, UserRole.java, BotRole.java.
ROLE_TYPE_LABELS: dict[str, str] = {
    "UserRole": "Human operator",
    "BotRole": "Automated bot",
}


# MCP-computed transition types (from _STATUS_TYPE_TO_EDGE in service_insights.py).
# Verified against live BPA API on 2026-04-09.
TRANSITION_TYPE_LABELS: dict[str, str] = {
    "forward": "Approve & forward",
    "corrections": "Return for corrections",
    "reject": "Reject application",
    "user_defined": "Custom transition",
    "unknown": "Unknown transition",
}


def enrich_role_type(
    role: dict[str, Any],
    key: str = "role_type",
) -> dict[str, Any]:
    """Add a role-type display label to a role dict.

    Args:
        role: Role dict to mutate in place.
        key: Source field name. Default "role_type" (service_map format).
            Pass "type" for yaml_transformer format.

    Returns:
        The same dict, with `{key}_display` added.
    """
    display_key = f"{key}_display"
    value = role.get(key)
    if value is None:
        role[display_key] = _UNKNOWN
    else:
        role[display_key] = ROLE_TYPE_LABELS.get(value, value)
    return role


def enrich_transition_type(
    obj: dict[str, Any],
    key: str = "transition_type",
) -> dict[str, Any]:
    """Add a transition-type display label to an edge or status dict.

    Args:
        obj: Edge or status dict to mutate in place.
        key: Source field name. Default "transition_type" for edges;
            pass "type" for statuses.

    Returns:
        The same dict, with `{key}_display` added.
    """
    display_key = f"{key}_display"
    value = obj.get(key)
    if value is None:
        obj[display_key] = _UNKNOWN
    else:
        obj[display_key] = TRANSITION_TYPE_LABELS.get(value, value)
    return obj


def enrich_determinant_type(
    det: dict[str, Any],
    key: str = "type",
) -> dict[str, Any]:
    """Add a determinant-type display label to a determinant dict.

    Skips enrichment silently if the source field is missing or None.
    This handles yaml_transformer's form_field_based determinants which
    drop the `type` field entirely.

    Args:
        det: Determinant dict to mutate in place.
        key: Source field name. Default "type".

    Returns:
        The same dict, with `{key}_display` added (or unchanged if skipped).
    """
    value = det.get(key)
    if value is None:
        return det
    display_key = f"{key}_display"
    # Defensive lowercase lookup (API returns lowercase but backend enum is CamelCase)
    lookup = value.lower() if isinstance(value, str) else value
    det[display_key] = DETERMINANT_TYPE_LABELS.get(lookup, value)
    return det


def build_ui_labels() -> dict[str, dict[str, str]]:
    """Return the top-level ui_labels lookup section for tool outputs.

    Returns shallow copies of each constant dict so caller mutations do
    not corrupt module-level state.
    """
    return {
        "component_types": dict(COMPONENT_TYPE_LABELS),
        "determinant_types": dict(DETERMINANT_TYPE_LABELS),
        "role_types": dict(ROLE_TYPE_LABELS),
        "transition_types": dict(TRANSITION_TYPE_LABELS),
    }
