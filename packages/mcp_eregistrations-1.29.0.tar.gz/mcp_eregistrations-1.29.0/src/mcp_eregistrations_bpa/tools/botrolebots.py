"""MCP tools for BPA BotRoleBots (bot-to-role assignments).

Issue #94: BotRole bot attachment was unreadable, uncreatable, and
unupdatable via MCP. This module adds a dedicated tool family backed
by the backend's `/role/{id}/botrolebots` and `/botrolebots/{id}`
endpoints — a separate JPA entity from Role, with its own table.

Key verified facts (see issue #94):
- `GET /role/{id}` does NOT populate this data (both with and without
  includeDetails=true). Must call `/role/{id}/botrolebots` directly.
- POST creates (unique constraint on bot_role_id — one record per role).
- PUT replaces all actions wholesale; PUT with actions=[] DELETES.
- Backend has no DELETE endpoint; frontend code that references one is
  dead.
- Bot references in write payload: `bots:[{id:<bot_id>}]` only.
  Echoing full Bot objects from GET breaks Jackson deserialization.
- Invalid bot_ids are silently dropped by backend — pre-flight validation
  AND post-write verification are both required.
- role_update (PUT /bot_role) does NOT touch the bot_role_bots table
  — bot assignments are preserved across role renames/updates.
"""

from __future__ import annotations

from typing import Any

from fastmcp.exceptions import ToolError
from mcp.types import ToolAnnotations

from mcp_eregistrations_bpa.audit.context import (
    NotAuthenticatedError,
    get_current_user_email,
)
from mcp_eregistrations_bpa.audit.logger import AuditLogger
from mcp_eregistrations_bpa.bpa_client import BPAClient
from mcp_eregistrations_bpa.bpa_client.errors import (
    BPAClientError,
    BPANotFoundError,
    BPAValidationError,
    translate_error,
)
from mcp_eregistrations_bpa.config import resolve_db_path

__all__ = [
    "botrolebots_get",
    "botrolebots_save",
    "botrolebots_delete",
    "register_botrolebots_tools",
]


# ---------------------------------------------------------------------------
# Transform helpers
# ---------------------------------------------------------------------------

_ALLOWED_ACTION_KEYS: frozenset[str] = frozenset(
    {
        "bot_ids",
        "json_determinants",
        "sort_order_number",
        "parallel",
        "mandatory",
        "multiple_bot",
        "multiple_field_key",
        "target_tab_component_key",
    }
)


def _transform_bot_ref(bot: dict[str, Any]) -> dict[str, Any]:
    """Reduce a full Bot object to a stable reference {id, name}.

    The backend returns heavy Bot objects (tutorials, mappings) in GET responses,
    but only accepts {"id": ...} on writes. Echoing the full object back breaks
    Jackson deserialization.
    """
    return {"id": bot.get("id"), "name": bot.get("name")}


def _transform_botrolebots_response(
    data: dict[str, Any] | None,
) -> dict[str, Any]:
    """Transform the backend BotRoleBots shape to snake_case MCP output.

    Empty/null input yields {botrolebots_id: None, actions: []} — the canonical
    "no record" shape, used by both the fresh-role case and probe misses.
    """
    if not data or not data.get("id"):
        return {"botrolebots_id": None, "actions": []}

    actions_out: list[dict[str, Any]] = []
    for action in data.get("actions") or []:
        if not isinstance(action, dict):
            continue
        actions_out.append(
            {
                "action_id": action.get("id"),
                "json_determinants": action.get("jsonDeterminants", ""),
                "bots": [
                    _transform_bot_ref(b)
                    for b in (action.get("bots") or [])
                    if isinstance(b, dict)
                ],
                "sort_order_number": action.get("sortOrderNumber"),
                "parallel": bool(action.get("parallel", False)),
                "mandatory": bool(action.get("mandatory", False)),
                "multiple_bot": bool(action.get("multipleBot", False)),
                "multiple_field_key": action.get("multipleFieldKey"),
                "target_tab_component_key": action.get("targetTabComponentKey"),
            }
        )
    return {"botrolebots_id": data.get("id"), "actions": actions_out}


def _transform_action_row_for_api(row: dict[str, Any], *, index: int) -> dict[str, Any]:
    """Transform a user-supplied snake_case action row into the camelCase payload.

    Enforces:
    - Only known keys (unknown keys rejected to prevent silent typo drops).
    - `bot_ids` is required and must be a list.
    - `sort_order_number` >= 0 when supplied; defaults to index+1 otherwise.
    - `bots` payload uses the minimal `{id: <bot_id>}` shape.
    """
    if not isinstance(row, dict):
        raise ToolError(
            f"Action row {index}: must be a dict, got {type(row).__name__}."
        )

    unknown = set(row.keys()) - _ALLOWED_ACTION_KEYS
    if unknown:
        raise ToolError(
            f"Action row {index}: unknown keys {sorted(unknown)}. "
            f"Allowed keys: {sorted(_ALLOWED_ACTION_KEYS)}."
        )

    bot_ids = row.get("bot_ids")
    if bot_ids is None or not isinstance(bot_ids, list):
        raise ToolError(
            f"Action row {index}: 'bot_ids' is required and must be a list "
            "of bot UUIDs."
        )

    sort_order = row.get("sort_order_number", index + 1)
    if not isinstance(sort_order, int) or sort_order < 0:
        raise ToolError(
            f"Action row {index}: 'sort_order_number' must be a "
            f"non-negative integer, got {sort_order!r}."
        )

    return {
        "jsonDeterminants": row.get("json_determinants") or "",
        # Padding `name` with the bot_id itself avoids a Jackson/Hibernate
        # LinkedHashSet<Bot> deserialization collision that 400s when two
        # Bot entries in one action row share otherwise-null identity fields.
        # Backend discards `name` (controller only reads bot.getId()), so
        # using the bot_id as the unique padding value is safe. Issue #94
        # v1.20.2: single-bot PUT worked but multi-bot PUT failed with
        # "Failed to read request" until we added this padding.
        "bots": [{"id": bot_id, "name": bot_id} for bot_id in bot_ids],
        "sortOrderNumber": sort_order,
        "parallel": bool(row.get("parallel", False)),
        "mandatory": bool(row.get("mandatory", False)),
        "multipleBot": bool(row.get("multiple_bot", False)),
        **(
            {"multipleFieldKey": row["multiple_field_key"]}
            if row.get("multiple_field_key") is not None
            else {}
        ),
        **(
            {"targetTabComponentKey": row["target_tab_component_key"]}
            if row.get("target_tab_component_key") is not None
            else {}
        ),
    }


async def _probe_botrolebots_exists(
    client: BPAClient, role_id: str | int
) -> tuple[bool, dict[str, Any] | None]:
    """Probe whether a BotRoleBots record exists for a role.

    Backend shape quirk: a BotRole without assignments may return either an
    empty-shape dict ({"id": None, "actions": []}) OR HTTP 404 depending on
    whether anything ever existed. Both map to (False, None).

    Returns:
        (exists, record) — record is the raw camelCase response or None.
    """
    try:
        record = await client.get(
            "/role/{role_id}/botrolebots",
            path_params={"role_id": role_id},
            resource_type="role",
            resource_id=role_id,
        )
    except BPANotFoundError:
        return (False, None)

    if not record or not record.get("id"):
        return (False, None)
    return (True, record)


async def _fetch_role_type(client: BPAClient, role_id: str | int) -> dict[str, Any]:
    """Fetch the role and require it to be a BotRole.

    Raises ToolError if not found or not a BotRole (bots cannot attach to UserRole).
    """
    try:
        role = await client.get(
            "/role/{role_id}",
            path_params={"role_id": role_id},
            resource_type="role",
            resource_id=role_id,
        )
    except BPANotFoundError:
        raise ToolError(
            f"Role '{role_id}' not found. "
            "Use 'role_list' with service_id to see available roles."
        ) from None

    if role.get("type") != "BotRole":
        raise ToolError(
            f"Cannot operate on bot assignments: role '{role_id}' is a "
            f"{role.get('type')!r}, not a BotRole. Bot assignments only "
            "apply to BotRoles."
        )
    return role


def _is_unique_constraint_error(err: Exception) -> bool:
    """Detect the 400 'already exists' message from a concurrent POST race."""
    text = str(err).lower()
    return "already exists" in text or "unique constraint" in text


# ---------------------------------------------------------------------------
# T2: botrolebots_get
# ---------------------------------------------------------------------------


async def botrolebots_get(
    role_id: str,
    instance: str | None = None,
) -> dict[str, Any]:
    """Get bot assignments for a BotRole. Requires authentication.

    Returns the canonical BotRoleBots structure — N action rows, each with M
    bots and execution flags. Empty {botrolebots_id: None, actions: []} when
    no assignments exist. Raises if role is not a BotRole.

    Args:
        role_id: BotRole ID.
        instance: Instance profile name (from instance_list).

    Returns:
        dict with role_id, botrolebots_id, actions (each with action_id,
        json_determinants, bots [{id, name}], sort_order_number, parallel,
        mandatory, multiple_bot, multiple_field_key, target_tab_component_key).
    """
    if not role_id:
        raise ToolError(
            "Cannot get bot assignments: 'role_id' is required. "
            "Use 'role_list' with service_id to find valid role IDs."
        )

    try:
        async with BPAClient.for_instance(instance) as client:
            await _fetch_role_type(client, role_id)
            _, record = await _probe_botrolebots_exists(client, role_id)
    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(e, resource_type="role", resource_id=role_id) from e

    transformed = _transform_botrolebots_response(record)
    return {
        "role_id": role_id,
        **transformed,
    }


# ---------------------------------------------------------------------------
# T3: botrolebots_save
# ---------------------------------------------------------------------------


def _validate_actions_input(actions: list[Any]) -> list[dict[str, Any]]:
    """Normalize + validate user input, returning camelCase API payload rows.

    Raises ToolError on any problem before any network/audit calls.
    """
    if not isinstance(actions, list):
        raise ToolError(f"'actions' must be a list, got {type(actions).__name__}.")
    if not actions:
        raise ToolError(
            "'actions' must contain at least one row. To remove all "
            "assignments, call botrolebots_delete."
        )
    return [
        _transform_action_row_for_api(row, index=i) for i, row in enumerate(actions)
    ]


async def _validate_bot_ids_exist(
    client: BPAClient,
    service_id: str | int,
    action_rows: list[dict[str, Any]],
) -> None:
    """Pre-flight: every bot_id must exist in the service's bot list.

    Closes the silent-drop trap where the backend accepts invalid bot_ids
    and produces an empty bots array.
    """
    try:
        bots = await client.get_list(
            "/service/{service_id}/bot",
            path_params={"service_id": service_id},
            resource_type="bot",
        )
    except BPANotFoundError:
        raise ToolError(
            f"Cannot validate bot_ids: service '{service_id}' not found."
        ) from None

    known = {b.get("id") for b in bots if isinstance(b, dict) and b.get("id")}
    requested: set[str] = set()
    for row in action_rows:
        for bot_ref in row.get("bots", []):
            bid = bot_ref.get("id") if isinstance(bot_ref, dict) else None
            if bid:
                requested.add(bid)

    missing = sorted(requested - known)
    if missing:
        raise ToolError(
            f"Cannot save bot assignments: unknown bot_id(s) {missing} "
            f"for service '{service_id}'. Use 'bot_list' to find valid IDs."
        )


def _collect_verify_bot_ids(record: dict[str, Any] | None) -> set[str]:
    """Collect every bot.id present in a BotRoleBots GET response."""
    if not record:
        return set()
    found: set[str] = set()
    for action in record.get("actions") or []:
        for bot in action.get("bots") or []:
            if isinstance(bot, dict) and bot.get("id"):
                found.add(bot["id"])
    return found


def _collect_requested_bot_ids(action_rows: list[dict[str, Any]]) -> set[str]:
    """Collect every bot.id across all requested action rows."""
    requested: set[str] = set()
    for row in action_rows:
        for bot in row.get("bots", []):
            if isinstance(bot, dict) and bot.get("id"):
                requested.add(bot["id"])
    return requested


async def botrolebots_save(
    role_id: str,
    actions: list[dict[str, Any]],
    service_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Create or replace bot assignments on a BotRole. Audited write operation.

    Each action row runs one or more bots in parallel or sequence. The save
    replaces the entire BotRoleBots record (no merge). When service_id is
    provided, bot_ids are pre-flight-validated against the service's bot
    list (closes the silent-drop trap earlier). Post-write verification
    always runs.

    Action row keys (snake_case):
        bot_ids (list[str], required): UUIDs of bots to run in this row.
        json_determinants (str): JSONLogic gating expression.
        sort_order_number (int): row position (default: 1-indexed by position).
        parallel (bool): run bots concurrently within the row (default False).
        mandatory (bool): fail the workflow if any bot fails (default False).
        multiple_bot (bool): iterate over a grid/tab field (default False).
        multiple_field_key (str): component key driving iteration.
        target_tab_component_key (str): tab component key for iteration.

    Args:
        role_id: BotRole ID.
        actions: List of action-row dicts.
        service_id: Parent service ID (optional but recommended — enables
            pre-flight bot_id validation. The single-role endpoint does not
            expose serviceId, so the tool cannot derive it automatically.).
        instance: Instance profile name.

    Returns:
        dict with role_id, botrolebots_id, actions, audit_id, warnings.
    """
    if not role_id:
        raise ToolError("Cannot save bot assignments: 'role_id' is required.")

    api_actions = _validate_actions_input(actions)

    try:
        user_email = get_current_user_email(instance=instance)
    except NotAuthenticatedError as e:
        raise ToolError(str(e)) from e

    warnings: list[str] = []

    try:
        async with BPAClient.for_instance(instance) as client:
            await _fetch_role_type(client, role_id)
            if service_id:
                await _validate_bot_ids_exist(client, service_id, api_actions)
            else:
                warnings.append("preflight-skipped-no-service-id")

            exists, existing_record = await _probe_botrolebots_exists(client, role_id)
            was_create = not exists
            existing_id = existing_record.get("id") if existing_record else None

            audit_logger = AuditLogger(db_path=resolve_db_path(instance))
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="create" if was_create else "update",
                object_type="botrolebots",
                object_id=str(existing_id) if existing_id else None,
                params={
                    "role_id": str(role_id),
                    "actions": api_actions,
                },
            )

            payload = {"actions": api_actions}

            try:
                if was_create:
                    try:
                        await client.post(
                            "/role/{role_id}/botrolebots",
                            path_params={"role_id": role_id},
                            json=payload,
                            resource_type="role",
                        )
                    except BPAValidationError as e:
                        if not _is_unique_constraint_error(e):
                            raise
                        # Race: another writer inserted between our probe
                        # and our POST. Re-fetch to get the new id, then PUT.
                        _, raced_record = await _probe_botrolebots_exists(
                            client, role_id
                        )
                        if not raced_record or not raced_record.get("id"):
                            raise ToolError(
                                "Race recovery failed: POST rejected as "
                                "duplicate, but GET shows no record. "
                                "Retry the operation."
                            ) from e
                        existing_id = raced_record["id"]
                        await client.put(
                            "/botrolebots/{botrolebots_id}",
                            path_params={"botrolebots_id": existing_id},
                            json=payload,
                            resource_type="role",
                            resource_id=role_id,
                        )
                        warnings.append("race-recovered")
                else:
                    await client.put(
                        "/botrolebots/{botrolebots_id}",
                        path_params={"botrolebots_id": existing_id},
                        json=payload,
                        resource_type="role",
                        resource_id=role_id,
                    )

                # Post-write verification
                _, verified = await _probe_botrolebots_exists(client, role_id)
                present_bot_ids = _collect_verify_bot_ids(verified)
                requested_bot_ids = _collect_requested_bot_ids(api_actions)
                missing_after = sorted(requested_bot_ids - present_bot_ids)
                if missing_after:
                    raise ToolError(
                        f"Backend silently dropped bot_id(s) {missing_after} "
                        "during save. Verify the bots exist and are associated "
                        "with this service."
                    )

                # Now that the write succeeded, capture rollback state with
                # the committed botrolebots_id (needed to route rollback's PUT).
                verified_id = verified.get("id") if verified else None
                rollback_object_id = (
                    str(existing_id)
                    if existing_id
                    else (str(verified_id) if verified_id else str(role_id))
                )
                await audit_logger.save_rollback_state(
                    audit_id=audit_id,
                    object_type="botrolebots",
                    object_id=rollback_object_id,
                    previous_state={
                        "role_id": str(role_id),
                        "service_id": str(service_id) if service_id else None,
                        "record": existing_record,
                        "_was_create": was_create,
                    },
                )

                await audit_logger.mark_success(
                    audit_id,
                    result={
                        "role_id": str(role_id),
                        "botrolebots_id": verified_id,
                        "actions_count": len(api_actions),
                    },
                )

                transformed = _transform_botrolebots_response(verified)
                return {
                    "role_id": role_id,
                    "audit_id": audit_id,
                    "warnings": warnings,
                    **transformed,
                }

            except ToolError:
                # Already-raised audit-wrapped error (e.g. silent-drop)
                await audit_logger.mark_failed(
                    audit_id, "post-write verification failed"
                )
                raise
            except BPAClientError as e:
                await audit_logger.mark_failed(audit_id, str(e))
                raise translate_error(
                    e, resource_type="role", resource_id=role_id
                ) from e

    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(e, resource_type="role", resource_id=role_id) from e


# ---------------------------------------------------------------------------
# T4: botrolebots_delete
# ---------------------------------------------------------------------------


async def botrolebots_delete(
    role_id: str,
    instance: str | None = None,
) -> dict[str, Any]:
    """Delete all bot assignments from a BotRole. Audited write operation.

    Backend has no DELETE endpoint — this is implemented as PUT
    /botrolebots/{id} with actions=[] (live-verified deletion semantics).
    No-op (returns deleted=False) if no assignments exist.

    Args:
        role_id: BotRole ID.
        instance: Instance profile name.

    Returns:
        dict with role_id, deleted (bool), audit_id, previous_state.
    """
    if not role_id:
        raise ToolError("Cannot delete bot assignments: 'role_id' is required.")

    try:
        user_email = get_current_user_email(instance=instance)
    except NotAuthenticatedError as e:
        raise ToolError(str(e)) from e

    try:
        async with BPAClient.for_instance(instance) as client:
            await _fetch_role_type(client, role_id)
            exists, existing_record = await _probe_botrolebots_exists(client, role_id)

            audit_logger = AuditLogger(db_path=resolve_db_path(instance))
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="delete",
                object_type="botrolebots",
                object_id=(str(existing_record["id"]) if existing_record else None),
                params={"role_id": str(role_id)},
            )

            if not exists or not existing_record:
                await audit_logger.mark_success(
                    audit_id,
                    result={
                        "role_id": str(role_id),
                        "deleted": False,
                        "reason": "no assignments to delete",
                    },
                )
                return {
                    "role_id": role_id,
                    "deleted": False,
                    "audit_id": audit_id,
                    "previous_state": None,
                }

            botrolebots_id = existing_record["id"]
            await audit_logger.save_rollback_state(
                audit_id=audit_id,
                object_type="botrolebots",
                object_id=str(botrolebots_id),
                previous_state={
                    "role_id": str(role_id),
                    "record": existing_record,
                    "_was_create": False,
                },
            )

            try:
                await client.put(
                    "/botrolebots/{botrolebots_id}",
                    path_params={"botrolebots_id": botrolebots_id},
                    json={"actions": []},
                    resource_type="role",
                    resource_id=role_id,
                )
            except BPAClientError as e:
                await audit_logger.mark_failed(audit_id, str(e))
                raise translate_error(
                    e, resource_type="role", resource_id=role_id
                ) from e

            await audit_logger.mark_success(
                audit_id,
                result={
                    "role_id": str(role_id),
                    "deleted": True,
                    "botrolebots_id": str(botrolebots_id),
                },
            )
            return {
                "role_id": role_id,
                "deleted": True,
                "audit_id": audit_id,
                "previous_state": _transform_botrolebots_response(existing_record),
            }

    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(e, resource_type="role", resource_id=role_id) from e


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


READ = ToolAnnotations(readOnlyHint=True, destructiveHint=False)
WRITE = ToolAnnotations(readOnlyHint=False, destructiveHint=True)


def register_botrolebots_tools(mcp: Any) -> None:
    """Register BotRoleBots tools with the MCP server."""
    mcp.tool(annotations=READ)(botrolebots_get)
    mcp.tool(annotations=WRITE)(botrolebots_save)
    mcp.tool(annotations=WRITE)(botrolebots_delete)
