"""Shared helpers for Form.io schema parsing and component simplification.

These helpers are used by both regular forms (forms.py) and print documents
(print_documents.py). They handle the common patterns of parsing formSchema
from BPA API responses and simplifying component trees for display.
"""

from __future__ import annotations

import json
from typing import Any

from mcp_eregistrations_bpa.tools.formio_helpers import CONTAINER_TYPES

__all__ = [
    "parse_form_schema",
    "simplify_components",
    "build_registration_name_map",
    "resolve_registration_uuids",
]


def parse_form_schema(form_data: dict[str, Any]) -> dict[str, Any]:
    """Parse formSchema from form data, handling string JSON.

    BPA stores formSchema as a JSON string in a TEXT column. This function
    handles both string and dict formats.

    Args:
        form_data: Form data from BPA API containing 'formSchema' key.

    Returns:
        Parsed form schema dict.
    """
    form_schema = form_data.get("formSchema", {})
    if isinstance(form_schema, str):
        try:
            parsed = json.loads(form_schema)
            return parsed if isinstance(parsed, dict) else {}
        except json.JSONDecodeError:
            return {}
    return form_schema if isinstance(form_schema, dict) else {}


def build_registration_name_map(
    registrations: list[dict[str, Any]] | None,
) -> dict[str, str | None]:
    """Build UUID to name mapping from registrations list.

    Args:
        registrations: List of registration objects with 'id' and 'name' fields.

    Returns:
        Dict mapping registration UUIDs to their names.
    """
    if not registrations or not isinstance(registrations, list):
        return {}
    return {
        str(reg.get("id")): reg.get("name") for reg in registrations if reg.get("id")
    }


def resolve_registration_uuids(
    registrations: dict[str, Any] | None,
    name_map: dict[str, str | None],
) -> dict[str, str | None] | None:
    """Resolve registration UUIDs to names.

    Transforms registrations from {uuid: true} format to {uuid: "name"} format.
    If a UUID cannot be resolved, the value is set to null.

    Args:
        registrations: Component registrations dict ({uuid: true, ...}).
        name_map: UUID to name mapping.

    Returns:
        Dict with UUIDs as keys and registration names as values.
        Returns None if registrations is None or empty.
    """
    if not registrations or not isinstance(registrations, dict):
        return None

    resolved: dict[str, str | None] = {}
    for uuid in registrations:
        resolved[uuid] = name_map.get(uuid)
    return resolved


def simplify_components(
    components: list[dict[str, Any]],
    path: list[str] | None = None,
    registration_name_map: dict[str, str | None] | None = None,
    *,
    visible_only: bool = False,
    _ancestor_hidden: bool = False,
) -> list[dict[str, Any]]:
    """Simplify components for display.

    Recursively traverses the component tree, extracting key properties and
    flattening the hierarchy into a list with path information.

    Args:
        components: Raw Form.io components.
        path: Current nesting path.
        registration_name_map: Optional UUID-to-name map for registration resolution.

    Returns:
        Simplified component list.
    """
    # Handle non-list components (BPA API may return int or other types)
    if not isinstance(components, list):
        return []
    if path is None:
        path = []
    if registration_name_map is None:
        registration_name_map = {}

    result = []
    for comp in components:
        if not isinstance(comp, dict):
            continue

        key = comp.get("key")
        if not key:
            continue

        comp_type = comp.get("type", "unknown")
        simplified: dict[str, Any] = {
            "key": key,
            "type": comp_type,
        }

        if comp.get("label"):
            simplified["label"] = comp["label"]

        if path:
            simplified["path"] = path

        # Add validation info
        validate = comp.get("validate", {})
        if isinstance(validate, dict) and validate.get("required"):
            simplified["required"] = True

        # Add is_container flag for container types
        if comp_type in CONTAINER_TYPES:
            simplified["is_container"] = True

        # Surface hidden/disabled state (own or inherited from ancestor)
        is_hidden = bool(comp.get("hidden")) or _ancestor_hidden
        if is_hidden:
            simplified["hidden"] = True
        if comp.get("disabled"):
            simplified["disabled"] = True

        # Extract determinant_ids from Form.io component (always include, empty if none)
        determinant_ids = comp.get("determinantIds", [])
        if determinant_ids is None:
            determinant_ids = []
        elif not isinstance(determinant_ids, list):
            determinant_ids = [determinant_ids] if determinant_ids else []
        simplified["determinant_ids"] = determinant_ids

        # Resolve registration UUIDs to names
        raw_registrations = comp.get("registrations")
        if raw_registrations:
            resolved = resolve_registration_uuids(
                raw_registrations, registration_name_map
            )
            if resolved:
                simplified["registrations"] = resolved

        # Include component_action_id if present
        if comp.get("componentActionId"):
            simplified["component_action_id"] = comp["componentActionId"]

        # Expose catalog reference for select/resource components
        # Priority: comp.catalog (BPA live) > data.catalog (legacy) > catalogIds[0]
        data = comp.get("data", {})
        catalog_ref = None
        if isinstance(data, dict):
            if data.get("dataSrc"):
                simplified["data_source"] = data["dataSrc"]
            catalog_ref = data.get("catalog")

        top_catalog = comp.get("catalog")
        if top_catalog and isinstance(top_catalog, str) and top_catalog.strip():
            catalog_ref = top_catalog
        elif not (catalog_ref and isinstance(catalog_ref, str) and catalog_ref.strip()):
            # Neither top-level nor data.catalog — try catalogIds
            catalog_ids = comp.get("catalogIds")
            if isinstance(catalog_ids, list) and catalog_ids:
                first_id = catalog_ids[0]
                if isinstance(first_id, str) and first_id.strip():
                    catalog_ref = first_id

        if catalog_ref and isinstance(catalog_ref, str) and catalog_ref.strip():
            simplified["catalog"] = catalog_ref

        # Extract selectable values and compute value_source
        if comp_type in ("radio", "selectboxes"):
            raw_values = comp.get("values")
            if isinstance(raw_values, list) and raw_values:
                simplified["values"] = [
                    {"label": v.get("label", ""), "value": v.get("value", "")}
                    for v in raw_values
                    if isinstance(v, dict)
                ]
                simplified["value_source"] = "static"
            else:
                simplified["value_source"] = "none"
        elif comp_type == "select":
            # Static values take priority (inline data.values list)
            data_values = data.get("values") if isinstance(data, dict) else None
            if isinstance(data_values, list) and data_values:
                simplified["values"] = [
                    {"label": v.get("label", ""), "value": v.get("value", "")}
                    for v in data_values
                    if isinstance(v, dict)
                ]
                simplified["value_source"] = "static"
            elif simplified.get("catalog"):
                # Classification-backed: catalog ref found
                simplified["value_source"] = "classification"
            elif isinstance(data, dict) and data.get("dataSrc") == "url":
                # Legacy URL-based classification detection
                simplified["value_source"] = "classification"
            else:
                simplified["value_source"] = "unresolved"

        # Handle nested components (panels, fieldsets, editgrids, datagrids, etc.)
        children_count = 0
        nested = comp.get("components", [])
        if nested and isinstance(nested, list):
            children_count += len(nested)
            result.extend(
                simplify_components(
                    nested,
                    path + [key],
                    registration_name_map,
                    visible_only=visible_only,
                    _ancestor_hidden=is_hidden,
                )
            )

        # Handle columns (2-level: columns > cells > components)
        columns = comp.get("columns", [])
        if columns and isinstance(columns, list):
            for col in columns:
                if isinstance(col, dict):
                    col_comps = col.get("components", [])
                    if isinstance(col_comps, list):
                        children_count += len(col_comps)
                        result.extend(
                            simplify_components(
                                col_comps,
                                path + [key],
                                registration_name_map,
                                visible_only=visible_only,
                                _ancestor_hidden=is_hidden,
                            )
                        )

        # Handle table rows (rows[][] structure)
        rows = comp.get("rows", [])
        if rows and isinstance(rows, list):
            for row in rows:
                if isinstance(row, list):
                    for cell in row:
                        if isinstance(cell, dict):
                            cell_comps = cell.get("components", [])
                            if isinstance(cell_comps, list):
                                children_count += len(cell_comps)
                                result.extend(
                                    simplify_components(
                                        cell_comps,
                                        path + [key],
                                        registration_name_map,
                                        visible_only=visible_only,
                                        _ancestor_hidden=is_hidden,
                                    )
                                )

        # Add children_count for containers
        if children_count > 0:
            simplified["children_count"] = children_count

        # Filter out hidden components when visible_only is set
        if visible_only and is_hidden:
            continue

        result.append(simplified)

    return result
