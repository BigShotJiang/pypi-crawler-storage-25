"""BPA audit logger — thin wrapper around the common AuditLogger.

Automatically injects BPA's ``get_connection`` so callers don't need to
provide it. All logic lives in ``mcp_eregistrations_common.audit.logger``.
"""

from __future__ import annotations

from pathlib import Path

from mcp_eregistrations_bpa.db import get_connection
from mcp_eregistrations_common.audit.logger import (  # noqa: F401
    AuditEntryImmutableError,
    AuditEntryNotFoundError,
)
from mcp_eregistrations_common.audit.logger import (
    AuditLogger as _CommonAuditLogger,
)

__all__ = [
    "AuditEntryImmutableError",
    "AuditEntryNotFoundError",
    "AuditLogger",
]


class AuditLogger(_CommonAuditLogger):
    """BPA-specific AuditLogger that auto-injects BPA's get_connection."""

    def __init__(self, db_path: Path | None = None):
        super().__init__(db_path=db_path, get_connection=get_connection)
