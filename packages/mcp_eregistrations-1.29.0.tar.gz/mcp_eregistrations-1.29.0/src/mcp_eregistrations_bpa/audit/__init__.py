"""Audit logging module for tracking BPA operations.

Generic audit infrastructure (AuditLogger, models, enums) lives in
``mcp_eregistrations_common.audit``. This package re-exports everything
so existing ``from mcp_eregistrations_bpa.audit import ...`` imports
continue to work unchanged.

BPA-specific helpers (context.py) remain here.
"""

from mcp_eregistrations_bpa.audit.context import (
    NotAuthenticatedError,
    get_current_user_email,
)
from mcp_eregistrations_bpa.audit.logger import (
    AuditEntryImmutableError,
    AuditEntryNotFoundError,
    AuditLogger,
)
from mcp_eregistrations_bpa.audit.models import (
    AuditEntry,
    AuditStatus,
    ObjectType,
    OperationType,
)

__all__ = [
    "AuditEntry",
    "AuditEntryImmutableError",
    "AuditEntryNotFoundError",
    "AuditLogger",
    "AuditStatus",
    "NotAuthenticatedError",
    "ObjectType",
    "OperationType",
    "get_current_user_email",
]
