"""Shim re-exporting CallbackServer from the shared common module.

The callback server was moved to ``mcp_eregistrations_common.callback_server``
so every MCP can use the same OIDC browser flow. This module remains so that
existing ``from mcp_eregistrations_bpa.auth.callback import CallbackServer``
imports keep working without churn.
"""

from mcp_eregistrations_common.callback_server import (
    CALLBACK_TIMEOUT,
    CallbackHandler,
    CallbackServer,
)

__all__ = ["CALLBACK_TIMEOUT", "CallbackHandler", "CallbackServer"]
