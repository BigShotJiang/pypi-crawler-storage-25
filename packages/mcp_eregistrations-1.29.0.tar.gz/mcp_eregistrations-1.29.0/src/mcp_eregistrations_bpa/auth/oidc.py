"""OIDC discovery and token handling for BPA.

BPA-specific glue around the shared Keycloak browser flow in
``mcp_eregistrations_common.browser_auth``. Also provides the password
grant (ROPC) used by ``auth_login(username, password)``.

PKCE helpers, ``is_browser_available``, and ``build_authorization_url``
have been centralized in ``mcp_eregistrations_common.browser_auth``;
they are re-exported here so existing ``from ... import`` paths still
resolve without churn.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING
from urllib.parse import urlparse

import httpx
from pydantic import BaseModel

from mcp_eregistrations_bpa.exceptions import AuthenticationError

# Re-exports for backwards compatibility
from mcp_eregistrations_common.browser_auth import (
    PKCE_VERIFIER_LENGTH,
    build_authorization_url,
    generate_pkce_pair,
    generate_state,
    is_browser_available,
)

if TYPE_CHECKING:
    from mcp_eregistrations_bpa.config import Config

logger = logging.getLogger(__name__)

__all__ = [
    "PKCE_VERIFIER_LENGTH",
    "AuthenticationError",
    "OIDCConfig",
    "build_authorization_url",
    "discover_oidc_config",
    "generate_pkce_pair",
    "generate_state",
    "is_browser_available",
    "perform_browser_login",
    "perform_password_login",
]


class OIDCConfig(BaseModel):
    """OIDC configuration discovered from well-known endpoint."""

    issuer: str
    authorization_endpoint: str
    token_endpoint: str
    userinfo_endpoint: str | None = None


async def discover_oidc_config(base_url: str) -> OIDCConfig:
    """Discover OIDC configuration from well-known endpoint.

    Args:
        base_url: The base URL for OIDC discovery. This is typically:
            - For Keycloak: https://login.example.org/realms/my-realm
            - Falls back to BPA URL if Keycloak URL not configured

    Returns:
        OIDCConfig with discovered endpoints.

    Raises:
        AuthenticationError: If discovery fails.
    """
    discovery_url = f"{base_url.rstrip('/')}/.well-known/openid-configuration"

    # Keycloak discovery requires /realms/<REALM> in the path. A bare host
    # produces a misleading 404; fail fast with discovery instructions.
    if "/realms/" not in urlparse(base_url).path:
        trimmed = base_url.rstrip("/")
        raise AuthenticationError(
            f"Keycloak host {base_url} was resolved, but the realm is missing. "
            f"OIDC discovery requires the realm-scoped URL "
            f"(e.g. {trimmed}/realms/<REALM>/.well-known/openid-configuration). "
            "To find <REALM>: open the BPA URL in a browser (unauthenticated)"
            f" — it redirects to "
            f"{trimmed}/realms/<REALM>/protocol/openid-connect/auth?... "
            "and <REALM> appears right after '/realms/'. "
            "Then set it via instance_add(name=..., keycloak_realm=<REALM>)."
        )

    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(discovery_url, timeout=10.0)
            response.raise_for_status()
        except httpx.HTTPStatusError as e:
            raise AuthenticationError(
                f"Cannot discover Keycloak at {discovery_url}: "
                f"HTTP {e.response.status_code}. "
                "Verify KEYCLOAK_URL and KEYCLOAK_REALM are correct."
            ) from e
        except httpx.RequestError as e:
            raise AuthenticationError(
                f"Cannot connect to Keycloak at {discovery_url}: {e}. "
                "Verify network connectivity and that Keycloak is accessible."
            ) from e

        try:
            data = response.json()
            return OIDCConfig(
                issuer=data["issuer"],
                authorization_endpoint=data["authorization_endpoint"],
                token_endpoint=data["token_endpoint"],
                userinfo_endpoint=data.get("userinfo_endpoint"),
            )
        except (KeyError, ValueError) as e:
            raise AuthenticationError(
                f"Invalid OIDC configuration response: {e}. "
                "The URL may not be a valid Keycloak realm endpoint."
            ) from e


async def perform_browser_login(
    config: Config | None = None,
) -> dict[str, object]:
    """Perform browser-based OIDC login flow for BPA.

    Delegates to the shared flow in ``mcp_eregistrations_common.browser_auth``
    and populates BPA's in-process ``TokenManager`` via the ``on_tokens``
    hook so permission checks (``ensure_write_permission``) still see the
    user's roles.

    Args:
        config: Pre-resolved Config object. Falls back to load_config().

    Returns:
        dict: Authentication result with user email and session duration.

    Raises:
        AuthenticationError: If authentication fails.
    """
    from mcp_eregistrations_bpa import __version__
    from mcp_eregistrations_common.auth import AuthenticationError as CommonAuthError
    from mcp_eregistrations_common.browser_auth import perform_keycloak_browser_login

    if config is None:
        from mcp_eregistrations_bpa.config import load_config

        config = load_config()

    # Resolve profile name for the auth-store key (match the one used by
    # auth_login / GDB / DS). Falls back to the instance slug if unknown.
    try:
        from mcp_eregistrations_bpa.auth.credentials import _slug_to_name

        instance_key = _slug_to_name(config.instance_id) or config.instance_id
    except Exception:
        instance_key = config.instance_id

    logger.info("Starting BPA browser login for instance=%s", instance_key)

    from mcp_eregistrations_bpa.server import get_token_manager

    token_manager = get_token_manager(config.instance_id, instance_name=instance_key)

    def _populate_token_manager(tokens: dict[str, object]) -> None:
        # store_shared_tokens already persisted in the shared flow; pass
        # share=False to skip the redundant auth-store write.
        token_manager.store_tokens(
            access_token=str(tokens["access_token"]),
            refresh_token=(
                str(tokens["refresh_token"]) if tokens.get("refresh_token") else None
            ),
            expires_in=int(tokens["expires_in"]),  # type: ignore[call-overload]
            token_endpoint=str(tokens["token_endpoint"]),
            client_id=config.keycloak_client_id,
            share=False,
        )

    try:
        browser_result = await perform_keycloak_browser_login(
            keycloak_url=config.keycloak_url,  # type: ignore[arg-type]
            realm=config.keycloak_realm,  # type: ignore[arg-type]
            client_id=config.keycloak_client_id,
            instance=instance_key,
            instance_info={
                "name": config.keycloak_realm or "BPA",
                "url": config.bpa_instance_url,
                "product_name": f"BPA MCP v{__version__}",
            },
            on_tokens=_populate_token_manager,
        )
    except CommonAuthError as e:
        raise AuthenticationError(str(e)) from e

    logger.info("Tokens stored for user: %s", token_manager.user_email)

    return {
        "success": True,
        "message": (
            f"Authenticated as {token_manager.user_email}. "
            f"Session valid for {token_manager.expires_in_minutes} minutes."
        ),
        "user_email": token_manager.user_email,
        "session_expires_in_minutes": token_manager.expires_in_minutes,
        "silent_reauth_note": browser_result.get("silent_reauth_note"),
    }


async def perform_password_login(
    username: str,
    password: str,
    config: Config | None = None,
) -> dict[str, object]:
    """Authenticate via Keycloak Resource Owner Password Credentials grant.

    Args:
        username: BPA username (email).
        password: BPA password.
        config: Pre-resolved Config object. Falls back to load_config().

    Returns:
        dict with success, message, user_email, session_expires_in_minutes,
        auth_method.

    Raises:
        AuthenticationError: On invalid credentials or server errors.
    """
    logger.info("Attempting password grant for user: %s", username)

    if config is None:
        from mcp_eregistrations_bpa.config import load_config

        config = load_config()

    # Discover OIDC endpoints
    oidc_config = await discover_oidc_config(config.oidc_discovery_url)

    async with httpx.AsyncClient() as client:
        try:
            response = await client.post(
                oidc_config.token_endpoint,
                data={
                    "grant_type": "password",
                    "client_id": config.keycloak_client_id,
                    "username": username,
                    "password": password,
                    "scope": "openid email profile",
                },
                headers={
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                timeout=10.0,
            )
        except httpx.RequestError as e:
            raise AuthenticationError(
                f"Cannot reach authentication server: {e}. Check connectivity."
            ) from e

        if response.status_code == 401 or (
            response.status_code == 400 and "invalid_grant" in response.text
        ):
            raise AuthenticationError(
                "Invalid credentials. Verify your username and password. "
                "Do not retry automatically -- repeated failures may lock "
                "the account."
            )

        if response.status_code == 403:
            raise AuthenticationError(
                "Account disabled or not authorized for this client."
            )

        if response.status_code >= 400:
            detail = ""
            try:
                err = response.json()
                detail = err.get("error_description", err.get("error", ""))
            except Exception:  # noqa: S110 — best-effort error-body parse; non-JSON responses are possible.
                pass
            raise AuthenticationError(
                f"Authentication failed (HTTP {response.status_code}): "
                f"{detail or 'Unknown error'}. Please try again later."
            )

        data = response.json()

    if "access_token" not in data:
        raise AuthenticationError(
            "Unexpected response from authentication server. Missing access_token."
        )

    # Store tokens via TokenManager
    from mcp_eregistrations_bpa.server import get_token_manager

    token_manager = get_token_manager(config.instance_id)
    token_manager.store_tokens(
        access_token=data["access_token"],
        refresh_token=data.get("refresh_token"),
        expires_in=data.get("expires_in", 300),
        token_endpoint=oidc_config.token_endpoint,
        client_id=config.keycloak_client_id,
    )

    logger.info("Password grant successful for user: %s", token_manager.user_email)

    return {
        "success": True,
        "message": (
            f"Authenticated as {token_manager.user_email}. "
            f"Session valid for {token_manager.expires_in_minutes} minutes."
        ),
        "user_email": token_manager.user_email,
        "session_expires_in_minutes": token_manager.expires_in_minutes,
        "auth_method": "password_grant",
    }
