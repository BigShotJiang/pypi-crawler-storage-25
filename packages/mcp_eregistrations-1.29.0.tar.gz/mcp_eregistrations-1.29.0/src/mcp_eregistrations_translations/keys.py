"""Composite key helpers and category mapping for translation tools."""

from __future__ import annotations

CATEGORY_MAP: dict[str, list[str]] = {
    "service": ["SERVICE_NAME", "SERVICE_DESCRIPTION"],
    "registrations": ["SERVICE_REGISTRATION", "SERVICE_REGISTRATION_SHORTNAME"],
    "roles": ["SERVICE_ROLE", "SERVICE_ROLE_SHORTNAME"],
    "form_fields": [
        "FORM_FIELD",
        "FORM_FIELD_DESCRIPTION",
        "FORM_FIELD_SELECTION",
        "FORM_FIELD_VALIDATION",
        "FORM_FIELD_FORMULA_TEXT_TRANSLATION",
    ],
    "form_structure": [
        "FORM_BLOCK",
        "FORM_BLOCK_TITLE",
        "FORM_PANEL",
        "FORM_PANEL_DESCRIPTION",
        "FORM_TABLE_FIELD",
        "FORM_TABLE_FIELD_DESCRIPTION",
    ],
    "tabs": ["GUIDE_TAB", "TAB"],
    "determinants": ["SERVICE_REGISTRATION_DETERMINANT"],
    "costs": ["SERVICE_REGISTRATION_COST"],
    "requirements": ["SERVICE_REGISTRATION_REQUIREMENT"],
    "messages": [
        "SERVICE_ROLE_STATUS_MESSAGE_CONTENT",
        "SERVICE_ROLE_STATUS_MESSAGE_SUBJECT",
    ],
    "templates": ["SERVICE_TEMPLATE"],
    "other": [
        "BTN_CONCLUSION",
        "DETERMINANT_BOOLEAN_YES",
        "DETERMINANT_BOOLEAN_NO",
        "DOCUMENT_REJECTION_REASON",
        "FILE_STATUS",
        "DS",
    ],
}

# User-friendly aliases: "forms" maps to both form_fields + form_structure
CATEGORY_ALIASES: dict[str, list[str]] = {
    "forms": ["form_fields", "form_structure"],
    "service": ["service"],
    "registrations": ["registrations"],
    "roles": ["roles"],
    "determinants": ["determinants"],
    "costs": ["costs"],
    "requirements": ["requirements"],
    "messages": ["messages"],
    "tabs": ["tabs"],
    "templates": ["templates"],
}

_LOCATION_TO_CATEGORY: dict[str, str] = {}
for _cat, _locations in CATEGORY_MAP.items():
    for _loc in _locations:
        _LOCATION_TO_CATEGORY[_loc] = _cat


def make_composite_key(field_id: str, type_str: str, location: str | None) -> str:
    """Build composite key: 'fieldId|type|location'."""
    return f"{field_id}|{type_str}|{location or ''}"


def parse_composite_key(key: str) -> tuple[str, str, str]:
    """Parse composite key into (fieldId, type, location)."""
    parts = key.split("|", 2)
    return parts[0], parts[1], parts[2] if len(parts) > 2 else ""


def location_to_category(location: str) -> str:
    """Map a TranslationLocation to its category name."""
    return _LOCATION_TO_CATEGORY.get(location, "other")


def resolve_category_filter(category: str) -> list[str]:
    """Resolve a user-friendly category name to CATEGORY_MAP keys."""
    if category in CATEGORY_ALIASES:
        return CATEGORY_ALIASES[category]
    if category in CATEGORY_MAP:
        return [category]
    return []


def get_locations_for_category(category: str) -> set[str]:
    """Get all TranslationLocation values for a category (resolves aliases)."""
    keys = resolve_category_filter(category)
    locations: set[str] = set()
    for key in keys:
        locations.update(CATEGORY_MAP.get(key, []))
    return locations


def extract_row_key(row: dict[str, dict[str, str]]) -> str:
    """Extract composite key from a matrix row (Map<langCode, GeneralTranslation>)."""
    sample = next(iter(row.values()))
    return make_composite_key(
        sample.get("fieldId", ""),
        sample.get("type", ""),
        sample.get("location"),
    )


def count_coverage(
    rows: list[dict[str, dict[str, str | None]]],
) -> dict[str, dict[str, int]]:
    """Count translated/missing per language across matrix rows."""
    coverage: dict[str, dict[str, int]] = {}
    for row in rows:
        for lang, gt in row.items():
            if lang not in coverage:
                coverage[lang] = {"translated": 0, "missing": 0}
            if gt.get("localName"):
                coverage[lang]["translated"] += 1
            else:
                coverage[lang]["missing"] += 1
    return coverage
