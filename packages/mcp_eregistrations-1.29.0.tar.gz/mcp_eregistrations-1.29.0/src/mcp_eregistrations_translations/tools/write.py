"""Translation write tool — batch update with dry_run, snapshot, and audit."""

from __future__ import annotations

import asyncio
from typing import Any

from fastmcp.exceptions import ToolError

from mcp_eregistrations_translations.audit_helpers import (
    get_audit_logger,
    get_current_user_email,
)
from mcp_eregistrations_translations.bpa_extensions import (
    TranslationBPAClient,
    TranslationBPAClientError,
)
from mcp_eregistrations_translations.keys import extract_row_key, parse_composite_key
from mcp_eregistrations_translations.server import mcp

# -- Constants ----------------------------------------------------------------

_MAX_CONCURRENT_WRITES = 20


# -- Tool ---------------------------------------------------------------------


@mcp.tool()
async def translate_batch(
    service_id: str,
    target_lang: str,
    translations: list[dict[str, str]],
    dry_run: bool = False,
    propagate: bool = False,
    max_concurrent_writes: int = 10,
    instance: str | None = None,
) -> dict[str, Any]:
    """Write translations to BPA. Audited write operation.

    Args:
        service_id: BPA service UUID.
        target_lang: Language code (e.g., "fr").
        translations: {key, value} dicts. Key = "fieldId|type|location".
        dry_run: Validate keys without writing (default: False).
        propagate: After saving, push keys to GTS (default: False).
        max_concurrent_writes: Concurrent PUT limit (default: 10, max: 20).
        instance: Instance profile name.

    Returns:
        dict with saved, failed, snapshot, propagated, audit_id.
    """
    # Clamp concurrency
    concurrency = min(max(max_concurrent_writes, 1), _MAX_CONCURRENT_WRITES)

    # Early return for empty input
    if not translations:
        return {
            "saved": 0,
            "failed": 0,
            "errors": [],
            "snapshot": [],
            "propagated": False,
            "dry_run": dry_run,
        }

    # -- Phase 1: Fetch matrix and build index --------------------------------
    try:
        async with TranslationBPAClient.for_instance(instance) as client:
            rows = await client.get_all_translations(service_id)

            # Build lookup: composite_key -> {lang -> GT entry}
            index: dict[str, dict[str, dict[str, Any]]] = {}
            for row in rows:
                key = extract_row_key(row)
                index[key] = row

            # -- Phase 2: Validate + Snapshot ---------------------------------
            valid_entries: list[dict[str, Any]] = []
            errors: list[dict[str, str]] = []
            snapshot: list[dict[str, Any]] = []

            for entry in translations:
                key = entry.get("key", "")
                value = entry.get("value", "")

                # Look up in index
                matched_row = index.get(key)
                if matched_row is None:
                    errors.append(
                        {
                            "key": key,
                            "reason": (f"Key not found in translation matrix: {key}"),
                        }
                    )
                    continue

                # Check target language entry exists in the row
                gt = matched_row.get(target_lang)
                if gt is None:
                    errors.append(
                        {
                            "key": key,
                            "reason": (
                                f"Language '{target_lang}' not found for key {key}"
                            ),
                        }
                    )
                    continue

                # Capture snapshot
                previous_value = gt.get("localName")
                snapshot.append(
                    {
                        "key": key,
                        "previous_value": previous_value,
                        "new_value": value,
                    }
                )

                # Build PUT body
                field_id, type_str, location = parse_composite_key(key)
                body = {
                    "id": gt.get("id"),
                    "languageCode": target_lang,
                    "fieldId": gt["fieldId"],
                    "fieldName": gt["fieldName"],
                    "location": gt["location"],
                    "type": gt["type"],
                    "localName": value,
                    "serviceId": service_id,
                }

                valid_entries.append(
                    {
                        "key": key,
                        "value": value,
                        "body": body,
                        "field_id": field_id,
                        "type_str": type_str,
                    }
                )

            # -- Dry run: return validation results ---------------------------
            if dry_run:
                return {
                    "dry_run": True,
                    "would_save": len(valid_entries),
                    "would_fail": len(errors),
                    "errors": errors,
                    "snapshot": snapshot,
                    "propagated": False,
                }

            # -- Phase 3: Write with bounded concurrency ----------------------
            if not valid_entries:
                return {
                    "saved": 0,
                    "failed": len(errors),
                    "errors": errors,
                    "snapshot": [],
                    "propagated": False,
                    "dry_run": False,
                }

            # Audit before write
            user_email = await get_current_user_email(instance)
            audit_logger = await get_audit_logger(instance)
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="TRANSLATE_BATCH",
                object_type="TRANSLATION",
                params={
                    "service_id": service_id,
                    "target_lang": target_lang,
                    "count": len(valid_entries),
                },
            )

            semaphore = asyncio.Semaphore(concurrency)
            results: list[tuple[str, bool, str | None]] = []

            async def _write_one(entry: dict[str, Any]) -> tuple[str, bool, str | None]:
                async with semaphore:
                    try:
                        await client.update_local_translation(service_id, entry["body"])
                        return (entry["key"], True, None)
                    except Exception as exc:
                        return (entry["key"], False, str(exc))

            tasks = [_write_one(e) for e in valid_entries]
            results = await asyncio.gather(*tasks)

            # Tally results
            saved = sum(1 for _, ok, _ in results if ok)
            write_errors = [
                {"key": key, "reason": err} for key, ok, err in results if not ok
            ]
            all_errors = errors + write_errors
            failed = len(all_errors)

            # Filter snapshot to only successfully saved entries
            saved_keys = {key for key, ok, _ in results if ok}
            final_snapshot = [s for s in snapshot if s["key"] in saved_keys]

            # -- Propagation --------------------------------------------------
            propagated = False
            propagation_error: str | None = None

            if propagate:
                by_domain: dict[str, list[str]] = {}
                for key, ok, _ in results:
                    if ok:
                        field_id, type_str, _ = parse_composite_key(key)
                        by_domain.setdefault(type_str, []).append(field_id)

                try:
                    for domain, field_ids in by_domain.items():
                        await client.sync_translation_keys(domain, field_ids)
                    propagated = True
                except Exception as exc:
                    propagation_error = str(exc)

            # Mark audit success
            await audit_logger.mark_success(
                audit_id,
                result={
                    "saved": saved,
                    "failed": failed,
                    "propagated": propagated,
                },
            )

            # Persist snapshot so rollback can restore it later.
            # Each entry also carries the GT id when present — needed for
            # deleting newly-created translations during rollback.
            enriched_snapshot = []
            for snap in final_snapshot:
                # Invariant: final_snapshot contains only keys that were validated
                # to have a non-None index[key][target_lang] entry (see Phase 2
                # validation) and successfully saved. Bracket access surfaces any
                # future invariant break immediately instead of silently persisting
                # a rollback state with gt_id=None.
                gt = index[snap["key"]][target_lang]
                enriched_snapshot.append(
                    {
                        "key": snap["key"],
                        "previous_value": snap["previous_value"],
                        "new_value": snap["new_value"],
                        "gt_id": gt.get("id"),
                        "field_name": gt.get("fieldName"),
                        "service_id": service_id,
                        "target_lang": target_lang,
                    }
                )
            await audit_logger.save_rollback_state(
                audit_id=audit_id,
                object_type="TRANSLATION",
                object_id=service_id,
                previous_state={"entries": enriched_snapshot},
            )

            result: dict[str, Any] = {
                "saved": saved,
                "failed": failed,
                "errors": all_errors,
                "snapshot": final_snapshot,
                "propagated": propagated,
                "audit_id": audit_id,
                "dry_run": False,
            }
            if propagation_error:
                result["propagation_error"] = propagation_error

            return result

    except TranslationBPAClientError as e:
        raise ToolError(f"BPA API error for service '{service_id}': {e}") from e
