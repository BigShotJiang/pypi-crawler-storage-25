"""audit_detail — inspect a prior translation write."""

from __future__ import annotations

from typing import Any

from fastmcp.exceptions import ToolError

from mcp_eregistrations_translations.audit_helpers import get_audit_logger
from mcp_eregistrations_translations.server import mcp


@mcp.tool()
async def audit_detail(
    audit_id: str,
    instance: str | None = None,
) -> dict[str, Any]:
    """Fetch a translation audit entry with its rollback snapshot. Read-only.

    Args:
        audit_id: Audit entry ID from a prior write.
        instance: Instance profile name.

    Returns:
        dict with audit_id, timestamp, user_email, operation_type,
        object_type, object_id, params, status, result, rollback_state
        (rollback_state is None if no snapshot was persisted).
    """
    logger = await get_audit_logger(instance)
    entry = await logger.get_entry(audit_id)
    if entry is None:
        raise ToolError(
            f"Audit entry not found: {audit_id} "
            f"(instance: {instance or 'default'}). "
            f"Check the audit_id or the instance profile."
        )

    rollback_state = await logger.get_rollback_state(audit_id)

    return {
        "audit_id": entry.id,
        "timestamp": entry.timestamp,
        "user_email": entry.user_email,
        "operation_type": entry.operation_type,
        "object_type": entry.object_type,
        "object_id": entry.object_id,
        "params": entry.params,
        "status": entry.status,
        "result": entry.result,
        "rollback_state": rollback_state,
    }
