"""instance_status — instance-wide coverage aggregation."""

from __future__ import annotations

import asyncio
from typing import Any

from fastmcp.exceptions import ToolError

from mcp_eregistrations_translations.bpa_extensions import (
    TranslationBPAClient,
    TranslationBPAClientError,
)
from mcp_eregistrations_translations.keys import count_coverage
from mcp_eregistrations_translations.server import mcp

_INSTANCE_FANOUT_CONCURRENCY = 10


@mcp.tool()
async def instance_status(
    instance: str | None = None,
    target_lang: str | None = None,
    services: list[str] | None = None,
    limit: int | None = None,
    max_concurrent: int = _INSTANCE_FANOUT_CONCURRENCY,
) -> dict[str, Any]:
    """Instance-wide translation coverage across all active services.

    Args:
        instance: Instance profile name.
        target_lang: Focus language. If None, each service entry's
            missing_in_target reports the average missing count across all
            non-English languages (truncated to int), and coverage_pct is
            None.
        services: Optional shortlist of service IDs to include (bypasses the
            active filter — explicit means include).
        limit: Optional cap on number of services to fetch (default: all).
            Useful for quick probes on large countries; applied after the
            services shortlist and active filters.
        max_concurrent: Parallel BPA reads (default: 10, clamped to [1, 20]).

    Returns:
        dict with instance, target_lang, service_count, total_strings,
        by_language, services, focus_by_absolute_missing,
        focus_by_lowest_coverage.
    """
    concurrency = max(1, min(max_concurrent, 20))

    try:
        async with TranslationBPAClient.for_instance(instance) as client:
            all_services = await client.list_services()
            if services:
                # Explicit shortlist bypasses the active filter — if the caller
                # named a service, show it regardless of active state.
                ids = set(services)
                all_services = [s for s in all_services if s.get("id") in ids]
            else:
                all_services = [s for s in all_services if s.get("active", True)]

            if limit is not None:
                all_services = all_services[:limit]

            sem = asyncio.Semaphore(concurrency)

            async def _fetch(
                svc: dict[str, Any],
            ) -> tuple[dict[str, Any], list[dict[str, Any]]]:
                async with sem:
                    rows = await client.get_all_translations(svc["id"])
                    return svc, rows

            pairs = await asyncio.gather(*[_fetch(s) for s in all_services])
    except TranslationBPAClientError as e:
        raise ToolError(f"BPA API error while aggregating: {e}") from e

    by_lang_totals: dict[str, dict[str, int]] = {}
    services_report: list[dict[str, Any]] = []
    total_strings = 0

    for svc, rows in pairs:
        total_strings += len(rows)
        coverage = count_coverage(rows)
        for lang, c in coverage.items():
            acc = by_lang_totals.setdefault(lang, {"translated": 0, "missing": 0})
            acc["translated"] += c["translated"]
            acc["missing"] += c["missing"]

        if target_lang is not None:
            lc = coverage.get(target_lang, {"translated": 0, "missing": 0})
            total_svc = lc["translated"] + lc["missing"]
            pct = round(lc["translated"] / total_svc * 100, 1) if total_svc else 0.0
            services_report.append(
                {
                    "service_id": svc["id"],
                    "service_name": svc.get("name", ""),
                    "total": total_svc,
                    "missing_in_target": lc["missing"],
                    "coverage_pct": pct,
                }
            )
        else:
            non_en_langs = [lg for lg in coverage if lg != "en"]
            avg_missing = sum(coverage[lg]["missing"] for lg in non_en_langs) / max(
                1, len(non_en_langs)
            )
            services_report.append(
                {
                    "service_id": svc["id"],
                    "service_name": svc.get("name", ""),
                    "total": len(rows),
                    "missing_in_target": int(avg_missing),
                    "coverage_pct": None,
                }
            )

    by_language: dict[str, dict[str, float]] = {}
    for lang, c in by_lang_totals.items():
        total = c["translated"] + c["missing"]
        by_language[lang] = {
            "translated": c["translated"],
            "missing": c["missing"],
            "coverage_pct": round(c["translated"] / total * 100, 1) if total else 0.0,
        }

    by_abs = sorted(services_report, key=lambda s: -s["missing_in_target"])

    def _cov_key(s: dict[str, Any]) -> float:
        pct = s.get("coverage_pct")
        return pct if pct is not None else 100.0

    by_cov = sorted(services_report, key=_cov_key)

    return {
        "instance": instance or "default",
        "target_lang": target_lang,
        "service_count": len(services_report),
        "total_strings": total_strings,
        "by_language": by_language,
        "services": services_report,
        "focus_by_absolute_missing": [s["service_id"] for s in by_abs[:10]],
        "focus_by_lowest_coverage": [s["service_id"] for s in by_cov[:10]],
    }
