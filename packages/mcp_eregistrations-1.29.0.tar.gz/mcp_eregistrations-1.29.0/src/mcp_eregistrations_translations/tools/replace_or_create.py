"""replace_or_create — rename a fieldId across translations."""

from __future__ import annotations

from typing import Any

from fastmcp.exceptions import ToolError

from mcp_eregistrations_translations.audit_helpers import (
    get_audit_logger,
    get_current_user_email,
)
from mcp_eregistrations_translations.bpa_extensions import (
    TranslationBPAClient,
    TranslationBPAClientError,
)
from mcp_eregistrations_translations.server import mcp


@mcp.tool()
async def replace_or_create(
    service_id: str,
    new_field_id: str,
    field_name: str,
    location: str,
    type: str,  # noqa: A002
    old_field_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Rename a fieldId's translations, or create fresh rows. Audited write.

    When old_field_id is set, BPA moves existing translations from that
    fieldId to new_field_id and preserves the default-language localName.
    When old_field_id is None, fresh rows are created for each active
    language.

    Args:
        service_id: BPA service UUID.
        new_field_id: Target fieldId (new value).
        field_name: Display name for the field.
        location: TranslationLocation (e.g. FORM_FIELD, SERVICE_NAME).
        type: TranslationType (e.g. DS, BPA).
        old_field_id: Source fieldId being renamed (optional).
        instance: Instance profile name.

    Returns:
        dict with audit_id, service_id, new_field_id, old_field_id.
    """
    old_field_id = old_field_id or None
    dto: dict[str, Any] = {
        "fieldId": new_field_id,
        "fieldName": field_name,
        "location": location,
        "type": type,
    }
    if old_field_id:
        dto["oldFieldId"] = old_field_id

    user_email = await get_current_user_email(instance)
    logger = await get_audit_logger(instance)
    audit_id = await logger.record_pending(
        user_email=user_email,
        operation_type="TRANSLATION_REPLACE_OR_CREATE",
        object_type="TRANSLATION",
        object_id=service_id,
        params=dto,
    )

    try:
        async with TranslationBPAClient.for_instance(instance) as client:
            await client.replace_or_create_translation(service_id, dto)
    except TranslationBPAClientError as e:
        await logger.mark_failed(audit_id, error_message=str(e))
        raise ToolError(f"BPA API error during replace_or_create: {e}") from e

    await logger.mark_success(audit_id, result={"ok": True})

    return {
        "audit_id": audit_id,
        "service_id": service_id,
        "new_field_id": new_field_id,
        "old_field_id": old_field_id,
    }
