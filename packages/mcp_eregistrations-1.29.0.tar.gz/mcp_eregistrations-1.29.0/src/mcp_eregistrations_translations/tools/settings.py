"""settings_get / settings_set — instance-wide flag panel."""

from __future__ import annotations

import re
from typing import Any

from fastmcp.exceptions import ToolError

from mcp_eregistrations_translations.audit_helpers import (
    get_audit_logger,
    get_current_user_email,
)
from mcp_eregistrations_translations.bpa_extensions import (
    TranslationBPAClient,
    TranslationBPAClientError,
)
from mcp_eregistrations_translations.server import mcp

_UPDATED_RE = re.compile(
    r"Updated\s+(\d+)\s+general\s+translations?\s+settings?",
    re.IGNORECASE,
)


def _interpret(flag_key: str, has_true: bool, has_false: bool) -> str:
    if has_true and has_false:
        return f"{flag_key} is in a mixed state (some entries true, some false)."
    if has_true:
        return f"{flag_key} is uniformly true across all general translations."
    if has_false:
        return f"{flag_key} is uniformly false across all general translations."
    return f"{flag_key} has no applicable entries."


@mcp.tool()
async def settings_get(instance: str | None = None) -> dict[str, Any]:
    """Read instance-wide translation flag state.

    Args:
        instance: Instance profile name.

    Returns:
        dict with flags (raw booleans) and interpretation (plain English).
    """
    try:
        async with TranslationBPAClient.for_instance(instance) as client:
            flags = await client.get_translation_settings()
    except TranslationBPAClientError as e:
        raise ToolError(f"BPA API error reading translation settings: {e}") from e

    return {
        "instance": instance or "default",
        "flags": flags,
        "interpretation": {
            "localAuthorized": _interpret(
                "localAuthorized",
                flags.get("localAuthorizedTrue", False),
                flags.get("localAuthorizedFalse", False),
            ),
            "localSupersedesGlobal": _interpret(
                "localSupersedesGlobal",
                flags.get("localSupersedesGlobalTrue", False),
                flags.get("localSupersedesGlobalFalse", False),
            ),
        },
    }


@mcp.tool()
async def settings_set(
    local_authorized: bool | None = None,
    local_supersedes_global: bool | None = None,
    confirm_affects_display: bool = False,
    instance: str | None = None,
) -> dict[str, Any]:
    """Update instance-wide translation flags. Audited write.

    localSupersedesGlobal=True affects what users see in the admin UI across
    every service in this instance — requires confirm_affects_display=True.

    Args:
        local_authorized: New value for localAuthorized flag (or None to skip).
        local_supersedes_global: New value for localSupersedesGlobal (or None).
        confirm_affects_display: Required when setting supersedes_global=True.
        instance: Instance profile name.

    Returns:
        dict with instance, local_authorized, local_supersedes_global,
        updated (None if backend summary could not be parsed), message,
        audit_id.
    """
    if local_authorized is None and local_supersedes_global is None:
        raise ToolError(
            "Must supply at least one of local_authorized or local_supersedes_global."
        )
    if local_supersedes_global is True and not confirm_affects_display:
        raise ToolError(
            "local_supersedes_global=True overrides Global values across "
            "every service in this instance. Re-run with "
            "confirm_affects_display=True to proceed."
        )

    user_email = await get_current_user_email(instance)
    logger = await get_audit_logger(instance)
    audit_id = await logger.record_pending(
        user_email=user_email,
        operation_type="TRANSLATION_SETTINGS_SET",
        object_type="TRANSLATION_SETTINGS",
        params={
            "local_authorized": local_authorized,
            "local_supersedes_global": local_supersedes_global,
            "confirm_affects_display": confirm_affects_display,
        },
    )

    try:
        async with TranslationBPAClient.for_instance(instance) as client:
            resp = await client.set_translation_settings(
                local_authorized,
                local_supersedes_global,
            )
    except TranslationBPAClientError as e:
        await logger.mark_failed(audit_id, error_message=str(e))
        raise ToolError(f"BPA API error writing settings: {e}") from e

    message = resp.get("message", "") if isinstance(resp, dict) else str(resp)
    match = _UPDATED_RE.search(message)
    updated: int | None = int(match.group(1)) if match else None

    await logger.mark_success(
        audit_id,
        result={"updated": updated, "message": message},
    )

    return {
        "instance": instance or "default",
        "local_authorized": local_authorized,
        "local_supersedes_global": local_supersedes_global,
        "updated": updated,
        "message": message,
        "audit_id": audit_id,
    }
