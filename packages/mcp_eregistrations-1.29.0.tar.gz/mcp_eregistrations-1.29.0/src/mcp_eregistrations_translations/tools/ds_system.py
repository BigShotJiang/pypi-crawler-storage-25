"""DS system string translation tools (read + sync)."""

from __future__ import annotations

from typing import Any

from fastmcp.exceptions import ToolError

from mcp_eregistrations_translations.bpa_extensions import (
    TranslationBPAClient,
    TranslationBPAClientError,
)
from mcp_eregistrations_translations.keys import extract_row_key
from mcp_eregistrations_translations.server import mcp


def _resolve_active_value(gt: dict[str, Any]) -> str | None:
    """Resolve active translation value for a general translation entry.

    For general (serviceId=null) translations, the active value depends on
    override flags. If localAuthorized AND localSupersedesGlobal are both
    true AND localName is non-empty, use localName. Otherwise use globalName.
    """
    local_authorized = gt.get("localAuthorized", False)
    local_supersedes = gt.get("localSupersedesGlobal", False)
    local_name = gt.get("localName")

    if local_authorized and local_supersedes and local_name:
        return str(local_name)
    global_name = gt.get("globalName")
    return str(global_name) if global_name else None


@mcp.tool()
async def ds_translations(
    instance: str,
    target_lang: str,
    status: str | None = None,
    page: int = 1,
    page_size: int = 25,
) -> dict[str, Any]:
    """DS system string translation status. Read-only.

    Args:
        instance: Instance profile name (required).
        target_lang: Language to check.
        status: "missing"|"translated"|None (default: all).
        page: Page number.
        page_size: Results per page.

    Returns:
        dict with strings, coverage, pagination.
    """
    try:
        async with TranslationBPAClient.for_instance(instance) as client:
            page_data = await client.get_translations_page(
                "general",
                types=["DS"],
                page_no=page,
                page_size=page_size,
            )
    except TranslationBPAClientError as e:
        raise ToolError(f"BPA API error fetching DS system translations: {e}") from e

    items = page_data.get("items", [])
    total = page_data.get("totalResults", 0)

    # Process rows: extract target_lang info and active values
    strings: list[dict[str, Any]] = []
    translated_count = 0
    missing_count = 0

    for row in items:
        key = extract_row_key(row)
        target_gt = row.get(target_lang, {})
        en_gt = row.get("en", {})

        active_value = _resolve_active_value(target_gt)
        en_value = _resolve_active_value(en_gt)
        has_translation = active_value is not None

        if has_translation:
            translated_count += 1
        else:
            missing_count += 1

        # Apply status filter
        if status == "missing" and has_translation:
            continue
        if status == "translated" and not has_translation:
            continue

        field_name = target_gt.get("fieldName") or en_gt.get("fieldName", "")
        english = en_value or en_gt.get("fieldName", "")
        row_status = "translated" if has_translation else "missing"

        strings.append(
            {
                "key": key,
                "field_name": field_name,
                "english": english,
                "active_value": active_value,
                "status": row_status,
            }
        )

    return {
        "strings": strings,
        "coverage": {
            "translated": translated_count,
            "missing": missing_count,
        },
        "total": total,
        "page": page,
        "page_size": page_size,
    }


@mcp.tool()
async def ds_sync(
    instance: str,
) -> dict[str, Any]:
    """Trigger DS key sync -- ensures DS strings are in BPA.

    Args:
        instance: Instance profile name (required).

    Returns:
        dict with sync status.
    """
    try:
        async with TranslationBPAClient.for_instance(instance) as client:
            result = await client.sync_translation_keys("DS", [])
    except TranslationBPAClientError as e:
        raise ToolError(f"BPA API error during DS key sync: {e}") from e

    synced = 0
    if isinstance(result, dict):
        synced = result.get("synced", 0)
    return {
        "status": "ok",
        "message": "DS translation key sync triggered.",
        "synced": synced,
    }
