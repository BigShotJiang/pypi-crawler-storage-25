"""diff — compare translated keys across two services."""

from __future__ import annotations

import asyncio
from typing import Any

from fastmcp.exceptions import ToolError

from mcp_eregistrations_translations.bpa_extensions import (
    TranslationBPAClient,
    TranslationBPAClientError,
)
from mcp_eregistrations_translations.keys import extract_row_key
from mcp_eregistrations_translations.server import mcp

# MCP response token budget — full counts still returned in `counts`.
_MAX_PER_BUCKET = 100


def _index(rows: list[dict[str, Any]], lang: str) -> dict[str, str | None]:
    out: dict[str, str | None] = {}
    for row in rows:
        key = extract_row_key(row)
        gt = row.get(lang, {})
        value = gt.get("localName")
        # Empty string and None collapse — both represent "no usable translation"
        out[key] = value if value else None
    return out


@mcp.tool()
async def diff(
    service_id_a: str,
    service_id_b: str,
    language: str,
    instance: str | None = None,
) -> dict[str, Any]:
    """Compare translated keys between two services in a given language.

    Args:
        service_id_a: First service UUID.
        service_id_b: Second service UUID.
        language: Language to compare (e.g. "fr").
        instance: Instance profile name.

    Returns:
        dict with service_id_a, service_id_b, language, only_in_a,
        only_in_b (each entry carries a reason: absent_in_a, a_untranslated,
        both_untranslated, or a_untranslated_b_absent), different
        (each capped at 100), counts (untruncated totals).
    """
    try:
        async with TranslationBPAClient.for_instance(instance) as client:
            rows_a, rows_b = await asyncio.gather(
                client.get_all_translations(service_id_a),
                client.get_all_translations(service_id_b),
            )
    except TranslationBPAClientError as e:
        raise ToolError(f"BPA API error during diff: {e}") from e

    idx_a = _index(rows_a, language)
    idx_b = _index(rows_b, language)

    only_in_a: list[dict[str, Any]] = []
    only_in_b: list[dict[str, Any]] = []
    different: list[dict[str, Any]] = []

    for key in set(idx_a) | set(idx_b):
        value_a = idx_a.get(key)
        value_b = idx_b.get(key)
        a_in, b_in = key in idx_a, key in idx_b

        if value_a and not value_b:
            only_in_a.append({"key": key, "value_a": value_a})
        elif value_b and not a_in:
            only_in_b.append({"key": key, "value_b": value_b, "reason": "absent_in_a"})
        elif value_b and a_in and value_a is None:
            only_in_b.append(
                {"key": key, "value_b": value_b, "reason": "a_untranslated"}
            )
        elif a_in and b_in and value_a is None and value_b is None:
            only_in_b.append(
                {"key": key, "value_b": value_b, "reason": "both_untranslated"}
            )
        elif a_in and not b_in and value_a is None:
            only_in_b.append(
                {"key": key, "value_b": None, "reason": "a_untranslated_b_absent"}
            )
        elif value_a and value_b and value_a != value_b:
            different.append({"key": key, "value_a": value_a, "value_b": value_b})

    return {
        "service_id_a": service_id_a,
        "service_id_b": service_id_b,
        "language": language,
        "only_in_a": only_in_a[:_MAX_PER_BUCKET],
        "only_in_b": only_in_b[:_MAX_PER_BUCKET],
        "different": different[:_MAX_PER_BUCKET],
        "counts": {
            "only_in_a": len(only_in_a),
            "only_in_b": len(only_in_b),
            "different": len(different),
        },
    }
