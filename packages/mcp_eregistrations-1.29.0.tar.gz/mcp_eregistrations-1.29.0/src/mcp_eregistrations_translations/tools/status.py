"""Translation status and language tools."""

from __future__ import annotations

from typing import Any

from fastmcp.exceptions import ToolError

from mcp_eregistrations_translations.bpa_extensions import (
    TranslationBPAClient,
    TranslationBPAClientError,
)
from mcp_eregistrations_translations.keys import count_coverage, location_to_category
from mcp_eregistrations_translations.server import mcp


@mcp.tool()
async def status(service_id: str, instance: str | None = None) -> dict[str, Any]:
    """Per-language translation coverage for a service.

    Args:
        service_id: Service UUID.
        instance: Instance profile name (default: active profile).

    Returns:
        dict with service_id, service_name, total_strings, languages,
        by_category, most_complete_lang, second_most_complete_lang.
    """
    try:
        async with TranslationBPAClient.for_instance(instance) as client:
            # Fetch service metadata
            service = await client.get(f"service/{service_id}")
            service_name: str = service.get("name", "")

            # Fetch full translation matrix
            rows = await client.get_all_translations(service_id)
    except TranslationBPAClientError as e:
        raise ToolError(f"BPA API error for service '{service_id}': {e}") from e

    # --- Per-language totals ---
    coverage = count_coverage(rows)
    total_strings = len(rows)

    languages: dict[str, dict[str, Any]] = {}
    for lang, counts in coverage.items():
        translated = counts["translated"]
        missing = counts["missing"]
        pct = round(translated / total_strings * 100, 1) if total_strings else 0.0
        languages[lang] = {
            "translated": translated,
            "missing": missing,
            "coverage_pct": pct,
        }

    # --- Per-language per-category breakdown ---
    by_category: dict[str, dict[str, dict[str, int]]] = {}
    for row in rows:
        # Determine category from first entry's location
        sample = next(iter(row.values()))
        cat = location_to_category(sample.get("location", ""))

        for lang, gt in row.items():
            if lang not in by_category:
                by_category[lang] = {}
            if cat not in by_category[lang]:
                by_category[lang][cat] = {"total": 0, "translated": 0, "missing": 0}

            by_category[lang][cat]["total"] += 1
            if gt.get("localName"):
                by_category[lang][cat]["translated"] += 1
            else:
                by_category[lang][cat]["missing"] += 1

    # --- Most complete languages (excluding "en") ---
    non_en = {
        lang: counts["translated"] for lang, counts in coverage.items() if lang != "en"
    }
    ranked = sorted(non_en.items(), key=lambda x: x[1], reverse=True)
    most_complete_lang = ranked[0][0] if len(ranked) >= 1 else None
    second_most_complete_lang = ranked[1][0] if len(ranked) >= 2 else None

    return {
        "service_id": service_id,
        "service_name": service_name,
        "total_strings": total_strings,
        "languages": languages,
        "by_category": by_category,
        "most_complete_lang": most_complete_lang,
        "second_most_complete_lang": second_most_complete_lang,
    }


@mcp.tool()
async def language_list(instance: str | None = None) -> dict[str, Any]:
    """List active languages for the instance.

    Args:
        instance: Instance profile name (default: active profile).

    Returns:
        dict with languages list (code, active, rtl).
    """
    try:
        async with TranslationBPAClient.for_instance(instance) as client:
            langs = await client.get_languages()
    except TranslationBPAClientError as e:
        raise ToolError(f"BPA API error fetching languages: {e}") from e

    return {
        "languages": [
            {
                "code": lang.get("code", ""),
                "active": lang.get("active", False),
                "rtl": lang.get("rtl", False),
            }
            for lang in langs
        ]
    }
