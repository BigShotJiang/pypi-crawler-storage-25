"""DS system string write tool (translate_batch for DS/global)."""

from __future__ import annotations

from typing import Any

from fastmcp.exceptions import ToolError

from mcp_eregistrations_translations.audit_helpers import (
    get_audit_logger,
    get_current_user_email,
)
from mcp_eregistrations_translations.bpa_extensions import (
    TranslationBPAClient,
    TranslationBPAClientError,
)
from mcp_eregistrations_translations.keys import extract_row_key
from mcp_eregistrations_translations.server import mcp


@mcp.tool()
async def ds_translate_batch(
    instance: str,
    target_lang: str,
    translations: list[dict[str, str]],
    dry_run: bool = True,
    confirm_affects_global_catalog: bool = False,
) -> dict[str, Any]:
    """Batch-write DS system strings. Audited write. GLOBAL SCOPE.

    Writes to /translation/general/global_translation which pushes to the
    Global Translation Service and affects ALL eRegistrations instances.
    Requires confirm_affects_global_catalog=True unless dry_run=True.

    Args:
        instance: Instance profile name (required).
        target_lang: Language code.
        translations: List of {key, value} dicts.
        dry_run: Validate without writing (default: True).
        confirm_affects_global_catalog: Required for real writes (default: False).

    Returns:
        dict with saved, failed, audit_id, dry_run, realm_preamble.
    """
    # --- Phase 0: Safety gate ---
    if not dry_run and not confirm_affects_global_catalog:
        raise ToolError(
            "ds_translate_batch writes to the Global Translation "
            "Service (PUT /translation/general/global_translation). "
            "Changes persist across ALL eRegistrations instances, not just "
            "this one. If intentional, re-run with "
            "confirm_affects_global_catalog=True."
        )

    # --- Phase 1: Pre-flight validation ---
    if not translations:
        raise ToolError("translations list cannot be empty")

    # --- Phase 2: Build lookup index ---
    try:
        async with TranslationBPAClient.for_instance(instance) as client:
            all_rows = await client.get_all_translations("general", types=["DS"])

            # Build key -> row mapping for validation
            key_to_row: dict[str, dict[str, Any]] = {}
            for matrix_row in all_rows:
                rk = extract_row_key(matrix_row)
                key_to_row[rk] = matrix_row

            # Validate keys
            valid: list[dict[str, Any]] = []
            invalid: list[dict[str, Any]] = []

            for entry in translations:
                key = entry.get("key", "")
                value = entry.get("value", "")
                matched = key_to_row.get(key)
                if matched is None:
                    invalid.append({"key": key, "reason": f"Key not found: {key}"})
                else:
                    valid.append({"key": key, "value": value, "row": matched})

            # --- Dry run ---
            if dry_run:
                return {
                    "dry_run": True,
                    "would_save": len(valid),
                    "invalid": [
                        {"key": e["key"], "reason": e["reason"]} for e in invalid
                    ],
                    "realm_preamble": (
                        "Would write to Global Translation Service via "
                        "PUT /translation/general/global_translation. "
                        "Affects all eRegistrations instances."
                    ),
                }

            # --- Phase 3: Audit + Write ---
            user_email = await get_current_user_email(instance)
            audit_logger = await get_audit_logger(instance)
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="DS_SYSTEM_TRANSLATE_BATCH",
                object_type="TRANSLATION",
                params={
                    "target_lang": target_lang,
                    "count": len(translations),
                    "keys": [e["key"] for e in valid],
                    "confirm_affects_global_catalog": confirm_affects_global_catalog,
                },
            )

            saved = 0
            failed: list[dict[str, Any]] = list(invalid)

            try:
                for ve in valid:
                    ve_row: dict[str, Any] = ve["row"]
                    tgt = ve_row.get(target_lang, ve_row.get("en", {}))
                    body = {
                        "languageCode": target_lang,
                        "fieldId": tgt.get("fieldId", ""),
                        "fieldName": tgt.get("fieldName", ""),
                        "location": tgt.get("location", ""),
                        "type": "DS",
                        "globalName": ve["value"],
                    }
                    try:
                        await client.update_global_translation(body)
                        saved += 1
                    except TranslationBPAClientError as exc:
                        failed.append({"key": ve["key"], "reason": str(exc)})

                await audit_logger.mark_success(
                    audit_id,
                    {"saved": saved, "failed_count": len(failed)},
                )
            except Exception as exc:
                await audit_logger.mark_failed(audit_id, str(exc))
                raise

    except TranslationBPAClientError as e:
        raise ToolError(f"BPA API error writing DS translations: {e}") from e

    return {
        "saved": saved,
        "failed": failed,
        "audit_id": audit_id,
        "dry_run": False,
        "realm_preamble": (
            "Written to Global Translation Service via "
            "PUT /translation/general/global_translation. Affects all instances."
        ),
    }
