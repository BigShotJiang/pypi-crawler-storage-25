"""history — browse prior translation writes."""

from __future__ import annotations

from typing import Any

from fastmcp.exceptions import ToolError

from mcp_eregistrations_translations.audit_helpers import get_audit_logger
from mcp_eregistrations_translations.server import mcp

_KNOWN_OPERATION_TYPES = frozenset(
    {
        "TRANSLATE_BATCH",
        "TRANSLATION_GLOBAL_RELOAD",
        "TRANSLATION_ROLLBACK",
        "TRANSLATION_DELETE",
        "TRANSLATION_SETTINGS_SET",
        "TRANSLATION_REPLACE_OR_CREATE",
        "DS_SYSTEM_TRANSLATE_BATCH",
    }
)


@mcp.tool()
async def history(
    instance: str | None = None,
    operation_type: str | None = None,
    user_email: str | None = None,
    since: str | None = None,
    limit: int = 50,
) -> dict[str, Any]:
    """List recent translation audit entries. Read-only.

    Args:
        instance: Instance profile name.
        operation_type: Filter (TRANSLATE_BATCH, TRANSLATION_GLOBAL_RELOAD,
            TRANSLATION_ROLLBACK, TRANSLATION_DELETE, TRANSLATION_SETTINGS_SET,
            DS_SYSTEM_TRANSLATE_BATCH).
        user_email: Filter by operator.
        since: ISO date (e.g. "2026-04-01").
        limit: Maximum entries to return (default: 50).

    Returns:
        dict with entries (newest first).
    """
    if operation_type is not None and operation_type not in _KNOWN_OPERATION_TYPES:
        raise ToolError(
            f"Unknown operation_type '{operation_type}'. "
            f"Valid values: {', '.join(sorted(_KNOWN_OPERATION_TYPES))}."
        )
    logger = await get_audit_logger(instance)
    entries = await logger.list_entries(
        operation_type=operation_type,
        user_email=user_email,
        since_iso=since,
        limit=limit,
    )

    rows = []
    for e in entries:
        params = e.params if isinstance(e.params, dict) else {}
        row = {
            "audit_id": e.id,
            "timestamp": e.timestamp,
            "user_email": e.user_email,
            "operation_type": e.operation_type,
            "status": e.status,
            "service_id": params.get("service_id"),
            "count": params.get("count"),
            "params": params,
            "result": e.result,
        }
        rows.append(row)

    return {"instance": instance or "default", "entries": rows, "count": len(rows)}
