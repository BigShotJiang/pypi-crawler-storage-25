from mcp_eregistrations_translations.server import mcp


def main() -> None:
    mcp.run()
