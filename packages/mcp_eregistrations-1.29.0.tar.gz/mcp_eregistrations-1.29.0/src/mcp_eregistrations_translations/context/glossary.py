"""Instance-wide term frequency extraction."""

from __future__ import annotations

from collections import Counter
from typing import Any


def extract_glossary(
    rows: list[dict[str, Any]], target_lang: str, limit: int = 50
) -> list[dict[str, Any]]:
    """Extract most-frequent terms with their target language translations.

    Args:
        rows: Matrix rows from get_all_translations("general").
              Each row is Map<langCode, GeneralTranslation>.
        target_lang: Language code to extract translations for.
        limit: Max terms to return.

    Returns:
        List of {english, translation, frequency} sorted by frequency desc.
    """
    term_counts: Counter[str] = Counter()
    term_translations: dict[str, str | None] = {}

    for row in rows:
        en_gt = row.get("en")
        if not en_gt:
            continue
        english = en_gt.get("localName") or en_gt.get("fieldName") or ""
        if not english:
            continue

        term_counts[english] += 1

        # Capture the target language translation (first non-empty wins)
        if english not in term_translations or term_translations[english] is None:
            target_gt = row.get(target_lang)
            if target_gt:
                term_translations[english] = target_gt.get(
                    "localName"
                ) or target_gt.get("globalName")

    # Sort by frequency, take top N
    result = []
    for english, freq in term_counts.most_common(limit):
        result.append(
            {
                "english": english,
                "translation": term_translations.get(english),
                "frequency": freq,
            }
        )
    return result
