"""Context compiler: assembles translation briefs from matrix + form structure."""

from __future__ import annotations

import math
from typing import Any

from mcp_eregistrations_translations.context.glossary import extract_glossary
from mcp_eregistrations_translations.keys import (
    extract_row_key,
    get_locations_for_category,
    location_to_category,
)

# Category ordering for sort stability: service metadata first, then forms, etc.
_CATEGORY_ORDER: list[str] = [
    "service",
    "registrations",
    "roles",
    "determinants",
    "form_structure",
    "form_fields",
    "tabs",
    "costs",
    "requirements",
    "messages",
    "templates",
    "other",
]
_CATEGORY_RANK: dict[str, int] = {cat: idx for idx, cat in enumerate(_CATEGORY_ORDER)}


def _build_field_paths(
    components: list[dict[str, Any]], prefix: str = ""
) -> dict[str, str]:
    """Walk Formio component tree, build fieldKey -> structural path.

    Args:
        components: List of Formio component dicts.
        prefix: Parent path prefix for nested components.

    Returns:
        Dict mapping component key -> human-readable path string.
    """
    paths: dict[str, str] = {}
    for comp in components:
        label = comp.get("label", comp.get("key", ""))
        comp_type = comp.get("type", "")

        if comp_type in ("panel", "fieldset", "well", "tabs"):
            new_prefix = f"{prefix} \u2192 {label}" if prefix else label
            if "components" in comp:
                paths.update(_build_field_paths(comp["components"], new_prefix))
        elif comp_type in ("columns",):
            for col in comp.get("columns", []):
                if "components" in col:
                    paths.update(_build_field_paths(col["components"], prefix))
        elif comp_type in ("table", "editgrid", "datagrid"):
            new_prefix = f"{prefix} \u2192 {label}" if prefix else label
            if "components" in comp:
                paths.update(_build_field_paths(comp["components"], new_prefix))
        else:
            path = f"{prefix} \u2192 {label}" if prefix else label
            paths[comp.get("key", "")] = path

    return paths


def compile_translation_brief(
    rows: list[dict[str, Any]],
    target_lang: str,
    reference_lang: str | None = None,
    form_structure: list[dict[str, Any]] | None = None,
    category: str | None = None,
    include_translated: bool = True,
    page: int = 1,
    page_size: int = 50,
) -> dict[str, Any]:
    """Compile a translation brief from matrix rows.

    Args:
        rows: Matrix rows (Map<langCode, GeneralTranslation>).
        target_lang: Language code to translate into.
        reference_lang: Language for reference translations (or None).
        form_structure: Optional Formio component tree for path building.
        category: Optional category filter string.
        include_translated: Whether to include already-translated entries.
        page: Page number (1-based).
        page_size: Entries per page.

    Returns:
        dict with strings, pagination, glossary.
    """
    # Build field path lookup if form_structure provided
    field_paths: dict[str, str] = {}
    if form_structure:
        field_paths = _build_field_paths(form_structure)

    # Resolve category filter locations
    allowed_locations: set[str] | None = None
    if category:
        allowed_locations = get_locations_for_category(category)

    # Process rows into entries
    entries: list[dict[str, Any]] = []
    for row in rows:
        # Extract info from first available language entry
        sample = next(iter(row.values()))
        location = sample.get("location", "")

        # Category filter
        if allowed_locations is not None and location not in allowed_locations:
            continue

        # Get target language GT
        target_gt = row.get(target_lang)
        current_value = None
        if target_gt:
            current_value = target_gt.get("localName") or None

        # include_translated filter
        if not include_translated and current_value is not None:
            continue

        # Get English GT
        en_gt = row.get("en")
        english = ""
        field_name = ""
        if en_gt:
            english = en_gt.get("localName") or en_gt.get("fieldName") or ""
            field_name = en_gt.get("fieldName") or ""

        # Get reference language GT
        ref_value = None
        if reference_lang:
            ref_gt = row.get(reference_lang)
            if ref_gt:
                ref_value = ref_gt.get("localName") or ref_gt.get("globalName") or None

        # Build entry
        key = extract_row_key(row)
        entry: dict[str, Any] = {
            "key": key,
            "english": english,
            "current": current_value,
            "location": location,
            "category": location_to_category(location),
            "reference": ref_value,
            "reference_lang": reference_lang if reference_lang else None,
            "form_path": field_paths.get(field_name) if field_paths else None,
        }
        entries.append(entry)

    # Sort: by category order, then by english text within category
    entries.sort(
        key=lambda e: (
            _CATEGORY_RANK.get(e["category"], len(_CATEGORY_ORDER)),
            e["english"].lower() if e["english"] else "",
        )
    )

    # Build glossary from ALL processed entries (before pagination)
    # We reuse the matrix rows but only from the filtered set
    filtered_row_indices: set[int] = set()
    entry_keys = {e["key"] for e in entries}
    for idx, row in enumerate(rows):
        rk = extract_row_key(row)
        if rk in entry_keys:
            filtered_row_indices.add(idx)

    glossary_rows = [rows[i] for i in sorted(filtered_row_indices)]
    glossary = extract_glossary(glossary_rows, target_lang, limit=30)

    # Pagination
    total_strings = len(entries)
    total_pages = math.ceil(total_strings / page_size) if total_strings > 0 else 0
    start = (page - 1) * page_size
    end = start + page_size
    paginated = entries[start:end]

    return {
        "strings": paginated,
        "pagination": {
            "page": page,
            "page_size": page_size,
            "total_strings": total_strings,
            "total_pages": total_pages,
        },
        "glossary": glossary,
    }
