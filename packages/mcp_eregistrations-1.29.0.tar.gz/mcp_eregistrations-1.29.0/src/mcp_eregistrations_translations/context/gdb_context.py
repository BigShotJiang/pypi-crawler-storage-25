"""Optional GDB schema enrichment for catalog-backed form fields."""

from __future__ import annotations

from typing import Any

try:
    from mcp_eregistrations_gdb.gdb_client import GDBClient  # noqa: F401

    GDB_AVAILABLE = True
except ImportError:
    GDB_AVAILABLE = False


async def enrich_with_gdb_context(
    entries: list[dict[str, Any]],
    form_components: list[dict[str, Any]] | None = None,
    instance: str | None = None,
) -> list[dict[str, Any]]:
    """Add GDB schema info to catalog-backed form fields.

    No-op if GDB client is not installed or no form components provided.

    For each entry whose field_type is "select" and the corresponding form
    component has dataSrc="url" with a GDB API URL pattern, adds gdb_source
    info like "GDB catalog: companies".

    Args:
        entries: List of TranslationEntry dicts (from compiler).
        form_components: Flat list of form components with key, type, data properties.
        instance: Instance profile name.

    Returns:
        entries with gdb_source field populated where applicable.
    """
    if not GDB_AVAILABLE or not form_components:
        return entries

    # Build lookup: componentKey -> component for GDB-backed selects
    gdb_fields: dict[str, dict[str, Any]] = {}
    for comp in form_components:
        if comp.get("type") == "select" and _is_gdb_backed(comp):
            gdb_fields[comp.get("key", "")] = comp

    if not gdb_fields:
        return entries

    # Enrich entries whose field key matches a GDB-backed component
    for entry in entries:
        if entry.get("field_type") == "select":
            # Try to match by component key in the context path
            for comp_key, comp in gdb_fields.items():
                if comp_key in (entry.get("context", "") or ""):
                    db_code = _extract_gdb_database_code(comp)
                    if db_code:
                        entry["gdb_source"] = f"GDB catalog: {db_code}"
                    break

    return entries


def _is_gdb_backed(component: dict[str, Any]) -> bool:
    """Check if a select component fetches from GDB API."""
    data = component.get("data", {})
    url = data.get("url", "")
    # GDB-backed selects have URLs like /data/<database_code>/...
    return "/data/" in url and component.get("dataSrc") == "url"


def _extract_gdb_database_code(component: dict[str, Any]) -> str | None:
    """Extract database code from GDB URL pattern."""
    data = component.get("data", {})
    url = data.get("url", "")
    # URL pattern: .../data/<database_code>/...
    parts = url.split("/data/")
    if len(parts) > 1:
        code_part = parts[1].split("/")[0].split("?")[0]
        return code_part if code_part else None
    return None
