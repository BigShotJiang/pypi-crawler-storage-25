"""Audit helpers for translation write operations."""

from __future__ import annotations

from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from pathlib import Path

import aiosqlite
import jwt
from fastmcp.exceptions import ToolError

from mcp_eregistrations_common.audit import AuditLogger

CONFIG_DIR = Path.home() / ".config" / "mcp-eregistrations-translations"


def resolve_db_path(instance: str | None) -> str:
    instance_key = instance or "default"
    db_dir = CONFIG_DIR / instance_key
    db_dir.mkdir(parents=True, exist_ok=True)
    return str(db_dir / "audit.db")


@asynccontextmanager
async def _get_connection(
    db_path: Path | None = None,
) -> AsyncGenerator[aiosqlite.Connection, None]:
    """Lightweight connection factory for translation audit DB."""
    if db_path is None:
        db_path = Path(resolve_db_path(None))
    async with aiosqlite.connect(db_path) as conn:
        await conn.execute("PRAGMA journal_mode=WAL")
        await conn.execute("PRAGMA foreign_keys=ON")
        conn.row_factory = aiosqlite.Row
        yield conn


async def _ensure_schema(db_path: str) -> None:
    """Create audit tables if they don't exist."""
    async with aiosqlite.connect(db_path) as conn:
        await conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS schema_version (
                version INTEGER PRIMARY KEY,
                applied_at TEXT NOT NULL DEFAULT (datetime('now'))
            );
            CREATE TABLE IF NOT EXISTS audit_logs (
                id TEXT PRIMARY KEY,
                timestamp TEXT NOT NULL,
                user_email TEXT NOT NULL,
                operation_type TEXT NOT NULL,
                object_type TEXT NOT NULL,
                object_id TEXT,
                params TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                result TEXT,
                rollback_state_id TEXT
            );
            CREATE TABLE IF NOT EXISTS rollback_states (
                id TEXT PRIMARY KEY,
                audit_log_id TEXT NOT NULL REFERENCES audit_logs(id),
                object_type TEXT NOT NULL,
                object_id TEXT NOT NULL,
                previous_state TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT (datetime('now'))
            );
            """
        )
        await conn.commit()


async def get_audit_logger(instance: str | None) -> AuditLogger:
    """Create an AuditLogger for the translation package.

    Resolves the DB path, ensures schema exists, and returns a configured logger.
    """
    db_path_str = resolve_db_path(instance)
    await _ensure_schema(db_path_str)
    return AuditLogger(db_path=Path(db_path_str), get_connection=_get_connection)


async def get_current_user_email(instance: str | None) -> str:
    from mcp_eregistrations_common.auth import get_or_refresh_token

    token = await get_or_refresh_token(instance or "default")
    if not token:
        raise ToolError("Not authenticated. Run auth_login first.")
    try:
        payload = jwt.decode(token, options={"verify_signature": False})
        email: str = payload.get("email", payload.get("preferred_username", "unknown"))
        return email
    except jwt.DecodeError:
        raise ToolError("Invalid access token. Run auth_login to refresh.") from None
