"""DS REST API client."""

from mcp_eregistrations_ds.ds_client.client import (
    DSClient,
    clear_ds_token,
    get_ds_token,
    store_ds_token,
)
from mcp_eregistrations_ds.ds_client.errors import (
    DSAuthenticationError,
    DSClientError,
    DSConnectionError,
    DSEndpointUnavailableError,
    DSNotFoundError,
    DSPermissionError,
    DSServerError,
    DSTimeoutError,
    DSValidationError,
    translate_error,
)

__all__ = [
    "DSClient",
    "DSAuthenticationError",
    "DSClientError",
    "DSConnectionError",
    "DSEndpointUnavailableError",
    "DSNotFoundError",
    "DSPermissionError",
    "DSServerError",
    "DSTimeoutError",
    "DSValidationError",
    "clear_ds_token",
    "get_ds_token",
    "store_ds_token",
    "translate_error",
]
