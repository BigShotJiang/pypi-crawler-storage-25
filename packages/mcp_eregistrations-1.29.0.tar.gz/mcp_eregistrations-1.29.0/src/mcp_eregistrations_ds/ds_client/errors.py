"""DS-specific error classes. Mirrors BPA error patterns for consistency."""

import json

from fastmcp.exceptions import ToolError


class DSClientError(Exception):
    """Base error for DS API calls."""

    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code


class DSConnectionError(DSClientError):
    """Cannot reach the DS instance."""


class DSTimeoutError(DSClientError):
    """DS request timed out."""


class DSAuthenticationError(DSClientError):
    """Not authenticated (401)."""


class DSPermissionError(DSClientError):
    """Not authorized (403). Admin access required."""


class DSNotFoundError(DSClientError):
    """Resource not found (404)."""


class DSEndpointUnavailableError(DSNotFoundError):
    """404 served as HTML by Django's SPA catch-all — the URL itself is not
    registered on this DS deployment (typically an older build missing the
    `/api/v1/` route group). Distinct from DSNotFoundError, which means the
    resource was looked up and genuinely not found.

    Subclasses DSNotFoundError for backward compatibility: existing
    `except DSNotFoundError:` handlers still catch this.
    """


class DSValidationError(DSClientError):
    """HTTP 400 — request validation failed.

    Typically surfaced when django-filter or a serializer rejects a query
    param or payload value (e.g., unknown `?state=<value>`, malformed UUID,
    invalid `?is_seen=<value>` on a BooleanFilter).
    """


class DSServerError(DSClientError):
    """DS server error (5xx)."""


def _format_drf_validation_errors(detail: str) -> str:
    """Convert a DRF field-error JSON body into a readable one-liner.

    DRF returns validation errors as ``{"field": ["message", ...], ...}`` or
    occasionally ``{"non_field_errors": [...]}``. We flatten that into
    ``field: message1; message2`` joined with "; ". If the body is not a
    recognizable DRF error shape, return the original string so callers
    still see the raw response.
    """
    try:
        parsed = json.loads(detail)
    except (json.JSONDecodeError, TypeError):
        return detail

    if isinstance(parsed, dict):
        parts: list[str] = []
        for field, messages in parsed.items():
            if isinstance(messages, list):
                joined = "; ".join(str(m) for m in messages)
            else:
                joined = str(messages)
            parts.append(f"{field}: {joined}")
        if parts:
            return " | ".join(parts)
    return detail


def translate_error(
    error: Exception,
    *,
    resource_type: str | None = None,
    resource_id: str | int | None = None,
) -> ToolError:
    """Translate DS errors to AI-friendly ToolError messages."""
    if resource_type and resource_id:
        resource_desc = f" {resource_type} '{resource_id}'"
    elif resource_type:
        resource_desc = f" {resource_type}"
    else:
        resource_desc = ""

    if isinstance(error, DSConnectionError):
        return ToolError(
            "Cannot reach DS instance. Check instance "
            "configuration and run ds_health to verify."
        )
    if isinstance(error, DSTimeoutError):
        msg = "DS request timed out"
        if resource_desc:
            msg += f" for{resource_desc}"
        return ToolError(f"{msg}. Try again.")
    if isinstance(error, DSAuthenticationError):
        return ToolError("Not authenticated. Run ds_auth_login first.")
    if isinstance(error, DSPermissionError):
        msg = "Access denied"
        if resource_desc:
            msg += f" for{resource_desc}"
        return ToolError(
            f"{msg}. Common causes: (1) token expired — run ds_auth_login to refresh, "
            f"(2) user lacks is_staff/is_superuser flag."
        )
    if isinstance(error, DSEndpointUnavailableError):
        msg = "DS endpoint not available on this deployment"
        if resource_desc:
            msg += f" (requested{resource_desc})"
        return ToolError(
            f"{msg}. The instance may be running an older DS build. "
            "Run ds_health to check the version."
        )
    if isinstance(error, DSNotFoundError):
        msg = "Not found"
        if resource_desc:
            msg += f":{resource_desc}"
        return ToolError(f"{msg}. Verify the ID exists.")
    if isinstance(error, DSServerError):
        msg = "DS server error"
        if resource_desc:
            msg += f" for{resource_desc}"
        return ToolError(f"{msg}. Run ds_health to check system status.")
    if isinstance(error, DSValidationError):
        msg = "Invalid request"
        if resource_desc:
            msg += f" for{resource_desc}"
        pretty = _format_drf_validation_errors(str(error))
        return ToolError(f"{msg}. {pretty}")
    msg = "DS error"
    if resource_desc:
        msg += f" ({resource_desc.strip()})"
    return ToolError(f"{msg}: {error}")
