"""Admin tools for FormIO inspection, certificate regeneration, and token auth."""

from __future__ import annotations

from typing import Any

from fastmcp.exceptions import ToolError
from mcp.types import ToolAnnotations

from mcp_eregistrations_ds.ds_client import (
    DSClient,
    DSClientError,
    DSNotFoundError,
    store_ds_token,
    translate_error,
)
from mcp_eregistrations_ds.server import mcp


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def formio_form_get(
    form_path: str,
    keys_only: bool = False,
    instance: str | None = None,
) -> dict[str, Any]:
    """Retrieve a FormIO form/template schema by path name.

    Args:
        form_path: FormIO form path
            (e.g. "print-investorRegistrationCertificate").
        keys_only: Return only component keys and types
            instead of the full schema.
        instance: Instance profile name.

    Returns:
        Full form schema or component key listing.
    """
    params: dict[str, Any] = {}
    if keys_only:
        params["keys_only"] = "true"

    try:
        async with DSClient.for_instance(instance) as client:
            try:
                data: dict[str, Any] = await client.get(
                    f"/backend/admin/formio-form/{form_path}",
                    params=params,
                )
            except DSNotFoundError:
                raise ToolError(
                    f"No form found for path '{form_path}'. "
                    "Check the path name matches a form "
                    "in RestHeart."
                ) from None
    except DSClientError as e:
        raise translate_error(
            e,
            resource_type="formio_form",
            resource_id=form_path,
        ) from e

    return data


@mcp.tool(
    annotations=ToolAnnotations(
        readOnlyHint=False,
        destructiveHint=True,
    )
)
async def certificate_regenerate(
    file_id: str,
    mappings: dict[str, str] | None = None,
    inject: dict[str, str] | None = None,
    form_id: str | None = None,
    certificate_id: int | list[int] | None = None,
    dry_run: bool = True,
    instance: str | None = None,
) -> dict[str, Any]:
    """Regenerate certificate PDFs for a file.

    Optionally inject missing field data. Handles cases where
    receipt templates have blank fields because process variables
    hold data under different keys than the template expects.

    Args:
        file_id: File UUID to regenerate certificates for.
        mappings: Source-key to target-key mappings from
            applicant form data to template keys. Values from
            FormIO select objects are auto-extracted.
        inject: Direct key-value pairs to inject.
        form_id: Explicit FormIO print form path. Bypasses
            auto-detection when the file has many license-url
            keys that can't be matched automatically.
        certificate_id: Target specific certificate(s) by DB
            ID instead of regenerating all. Single int or list.
        dry_run: Preview changes without writing (default: true).
            Set to false to apply.
        instance: Instance profile name.

    Returns:
        dict with file_id and results for each certificate.
    """
    body: dict[str, Any] = {
        "file_id": file_id,
        "dry_run": dry_run,
    }
    if mappings:
        body["mappings"] = mappings
    if inject:
        body["inject"] = inject
    if form_id:
        body["form_id"] = form_id
    if certificate_id is not None:
        body["certificate_id"] = certificate_id

    try:
        async with DSClient.for_instance(instance) as client:
            try:
                data: dict[str, Any] = await client.post(
                    "/backend/admin/regenerate-certificates",
                    json=body,
                )
            except DSNotFoundError:
                raise ToolError(
                    f"File '{file_id}' not found or has "
                    "no certificates. Verify the file_id."
                ) from None
    except DSClientError as e:
        raise translate_error(
            e,
            resource_type="certificate",
            resource_id=file_id,
        ) from e

    return data


@mcp.tool(
    annotations=ToolAnnotations(
        readOnlyHint=False,
        destructiveHint=False,
    )
)
async def ds_auth_token(
    token: str,
    instance: str | None = None,
) -> dict[str, Any]:
    """Authenticate with a DS instance using a JWT token.

    Use this instead of ds_auth_login when you already have a
    valid JWT token (e.g. from the browser or Keycloak directly).
    The token is stored in memory for subsequent DS API calls.

    Args:
        token: JWT access token (Bearer token value).
        instance: Instance profile name.

    Returns:
        dict confirming the token was stored and a health check.
    """
    from mcp_eregistrations_common.config import (
        get_instance_config,
    )

    if instance is None:
        raise ToolError(
            "No instance specified. Pass instance='<name>'. "
            "Use instance_list to see available instances."
        )

    # Validate the instance exists
    get_instance_config(instance)

    # Store the token
    store_ds_token(instance, token)

    # Verify it works with a health check
    try:
        async with DSClient.for_instance(instance) as client:
            health = await client.get("/backend/status")
    except DSClientError:
        health = {"status": "token stored, health check failed"}

    return {
        "instance": instance,
        "authenticated": True,
        "health": health,
    }
