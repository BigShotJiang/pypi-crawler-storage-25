from typing import Any

from fastmcp.exceptions import ToolError
from mcp.types import ToolAnnotations

from mcp_eregistrations_common.auth import (
    AuthenticationError,
    keycloak_password_grant,
    store_shared_tokens,
)
from mcp_eregistrations_common.auth_store import store_credentials
from mcp_eregistrations_common.config import get_instance_config
from mcp_eregistrations_smartlink.audit.logger import SlAuditLogger
from mcp_eregistrations_smartlink.rollback.manager import execute_rollback
from mcp_eregistrations_smartlink.server import mcp
from mcp_eregistrations_smartlink.smartlink_client import (
    SmartLinkClient,
    SmartLinkClientError,
    translate_error,
)


@mcp.tool()
async def smartlink_auth_login(
    username: str | None = None,
    password: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Authenticate to SmartLink via Keycloak.

    Called with no username/password, opens the user's default browser to the
    Keycloak login page (OIDC + PKCE). Called with credentials, uses the
    password grant. Uses the same realm/client as BPA — tokens are shared
    across every eRegistrations MCP via the unified auth store.

    The authenticated user must have the ``sysadmin`` role for audit access;
    the browser flow carries whatever roles Keycloak issues.

    Browser login stores only tokens (silent refresh works until the refresh
    token expires). Password-grant login also stores credentials for
    indefinite silent re-auth.

    Args:
        username: Keycloak username. Omit for browser login.
        password: Keycloak password. Omit for browser login.
        instance: Instance name (required).

    Returns:
        dict with status, instance, token_type, expires_in, auth_method.
    """
    if instance is None:
        raise ToolError("instance is required.")
    if (username is None) != (password is None):
        raise ToolError("Provide both username and password, or neither.")

    config = get_instance_config(instance)
    keycloak_url = config.get("keycloak_url")
    if not keycloak_url:
        raise ToolError(f"Instance '{instance}' has no Keycloak configuration.")

    realm = config.get("keycloak_realm")
    if not realm:
        raise ToolError(
            f"keycloak_realm is not set for instance '{instance}'. "
            "Auth cannot proceed. "
            f"To find the realm: open the main site URL in a browser "
            f"(while logged out) — it redirects to {keycloak_url.rstrip('/')}"
            "/realms/<REALM>/protocol/openid-connect/auth?... "
            "and <REALM> appears right after '/realms/'. "
            f"Then set it via: instance_add(name='{instance}', "
            "keycloak_realm='<REALM>')."
        )
    client_id = config.get("keycloak_client_id", "mcp-eregistrations-bpa")

    # --- Browser login path ---
    if username is None:
        from mcp_eregistrations_common.browser_auth import (
            is_browser_available,
            perform_keycloak_browser_login,
        )

        if not is_browser_available():
            raise ToolError(
                "Browser-based login is unavailable in this environment "
                "(headless / SSH / Docker). Pass username and password to use "
                "the password-grant path instead."
            )
        try:
            result = await perform_keycloak_browser_login(
                keycloak_url=keycloak_url,
                realm=realm,
                client_id=client_id,
                instance=instance,
                instance_info={
                    "name": realm,
                    "url": config.get("smartlink_url", config.get("ds_url", "")),
                    "product_name": "SmartLink MCP",
                },
            )
        except AuthenticationError as e:
            raise ToolError(str(e)) from e

        return {
            "status": "authenticated",
            "instance": instance,
            "token_type": "Bearer",
            "expires_in": int(result.get("expires_in") or 0),
            "user_email": result.get("user_email"),
            "auth_method": "browser",
            "silent_reauth_note": result.get("silent_reauth_note"),
        }

    # --- Password grant path ---
    # Defensive check — XOR validation above plus the browser branch make
    # this unreachable today, but it keeps the invariant enforced under
    # future refactors and narrows the types for mypy.
    if username is None or password is None:
        raise ToolError("username and password are required for password-grant login.")
    try:
        result = await keycloak_password_grant(
            keycloak_url=keycloak_url,
            realm=realm,
            client_id=client_id,
            username=username,
            password=password,
        )
    except AuthenticationError as e:
        raise ToolError(str(e)) from e

    access_token = result.get("access_token")
    if not access_token:
        raise ToolError("No access_token in Keycloak response.")

    store_shared_tokens(
        instance,
        access_token=result["access_token"],
        refresh_token=result.get("refresh_token"),
        token_endpoint=result["token_endpoint"],
        client_id=client_id,
    )

    store_credentials(
        instance,
        username,
        password,
        keycloak_url=keycloak_url,
        keycloak_realm=realm,
        client_id=client_id,
    )

    return {
        "status": "authenticated",
        "instance": instance,
        "token_type": result.get("token_type", "Bearer"),
        "expires_in": result.get("expires_in"),
        "auth_method": "password_grant",
    }


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=False, destructiveHint=False))
async def smartlink_auth_clear(
    instance: str,
    clear_refresh_token: bool = False,
) -> dict[str, Any]:
    """Clear cached SmartLink auth state. Idempotent.

    Evicts the in-memory access token so the next call re-authenticates.
    Set clear_refresh_token=True to also drop the stored refresh token
    (forces a full re-login via credentials or BPA MCP on next call).

    Args:
        instance: Instance name (required).
        clear_refresh_token: Also drop stored refresh token (default: False).

    Returns:
        dict with success, instance, cleared_access_token,
        cleared_refresh_token, next_action.
    """
    from mcp_eregistrations_common.auth import clear_cached_token
    from mcp_eregistrations_common.auth_store import (
        clear_refresh_context,
        get_credentials,
        get_refresh_context,
    )

    config = get_instance_config(instance)
    is_cas = bool(config.get("cas_url"))

    cleared_access = clear_cached_token(instance)
    cleared_refresh = clear_refresh_context(instance) if clear_refresh_token else False

    has_refresh = not clear_refresh_token and get_refresh_context(instance) is not None
    has_creds = get_credentials(instance) is not None

    if is_cas:
        next_action = {
            "code": "call_bpa_auth_login",
            "message": (
                "CAS instance: SmartLink shares the CAS session; run BPA "
                "MCP `auth_login` to re-establish the session. SmartLink "
                "will pick up the new token on the next call."
            ),
        }
    elif has_refresh:
        next_action = {
            "code": "retry_any_call",
            "message": (
                "Cache cleared. The next SmartLink call will silently "
                "re-auth via the stored refresh token."
            ),
        }
    elif has_creds:
        next_action = {
            "code": "call_smartlink_auth_login",
            "message": (
                "No refresh token on file. Run `smartlink_auth_login` "
                "(or BPA `auth_login`) to mint a fresh token."
            ),
        }
    else:
        next_action = {
            "code": "ask_credentials",
            "message": (
                "No auth material available. Run `smartlink_auth_login` "
                "with username and password to establish a session."
            ),
        }

    return {
        "success": True,
        "instance": instance,
        "cleared_access_token": cleared_access,
        "cleared_refresh_token": cleared_refresh,
        "next_action": next_action,
    }


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def smartlink_auth_diagnose(
    instance: str,
    trace_id: str | None = None,
) -> dict[str, Any]:
    """Diagnose the current SmartLink auth state without mutating it.

    Reads the cached bearer token, decodes JWT claims, and reports refresh
    context state. SmartLink has no dedicated health endpoint, so the live
    backend probe is skipped — call any SmartLink read tool to verify the
    token end-to-end. Safe, read-only, no re-authentication.

    Args:
        instance: Instance name (required).
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).

    Returns:
        dict with instance, auth_type, token_present, token_format,
        token_claims, refresh_context, refresh_failure, probe, hints, trace_id.
    """
    from mcp_eregistrations_common.auth_diagnose import diagnose_auth

    # SmartLink has no dedicated health endpoint at /smartlink/api/flows/health;
    # skip the probe rather than making up an endpoint.
    return await diagnose_auth(
        instance=instance,
        trace_id=trace_id,
        server_label="SmartLink",
        login_tool_name="smartlink_auth_login",
        probe_url=None,
    )


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def smartlink_audit_log(
    limit: int = 20,
    offset: int = 0,
    object_type: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """List SmartLink MCP audit log entries (local).

    Args:
        limit: Max entries to return (default: 20).
        offset: Pagination offset (default: 0).
        object_type: Filter by object type (flow, action).
        instance: Instance name.

    Returns:
        dict with entries, count.
    """
    if limit < 1:
        raise ToolError("limit must be >= 1")
    if offset < 0:
        raise ToolError("offset must be >= 0")
    limit = min(limit, 100)
    logger = SlAuditLogger.for_instance(instance)
    entries = await logger.list_entries(
        limit=limit, offset=offset, object_type=object_type
    )
    return {"entries": entries, "count": len(entries)}


@mcp.tool()
async def smartlink_rollback(
    audit_id: str,
    instance: str | None = None,
) -> dict[str, Any]:
    """Rollback a SmartLink operation by MCP audit ID. Audited write operation.

    Reverses a previous flow/action update by restoring the captured state.

    Args:
        audit_id: MCP audit entry ID to rollback.
        instance: Instance name.

    Returns:
        dict with audit_id, object_type, status.
    """
    logger = SlAuditLogger.for_instance(instance)
    try:
        async with SmartLinkClient.for_instance(instance) as client:
            return await execute_rollback(client, logger, audit_id)
    except SmartLinkClientError as e:
        raise translate_error(e, resource_type="rollback", resource_id=audit_id) from e
