"""Graylog MCP Server — log search and monitoring for eRegistrations."""

from fastmcp import FastMCP

mcp = FastMCP(
    "mcp-eregistrations-graylog",
    instructions=(
        "Graylog tools for searching and monitoring logs across eRegistrations "
        "instances. Use graylog_auth_login to authenticate with Graylog "
        "credentials (NOT Keycloak — Graylog has its own auth). "
        "Use graylog_search_logs for log queries with Elasticsearch syntax."
    ),
)

import mcp_eregistrations_graylog.tools.search  # noqa: F401, E402
import mcp_eregistrations_graylog.tools.streams  # noqa: F401, E402
import mcp_eregistrations_graylog.tools.system  # noqa: F401, E402
from mcp_eregistrations_common.tools.instances import (  # noqa: E402
    register_instance_tools,
)

register_instance_tools(mcp)


def main() -> None:
    """Entry point for mcp-eregistrations-graylog."""
    mcp.run()
