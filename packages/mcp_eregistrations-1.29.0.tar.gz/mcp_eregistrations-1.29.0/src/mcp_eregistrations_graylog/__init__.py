"""Graylog MCP Server — log search and monitoring for eRegistrations."""
