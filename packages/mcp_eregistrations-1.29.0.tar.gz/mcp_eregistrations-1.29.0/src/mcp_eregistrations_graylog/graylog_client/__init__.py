"""Graylog REST API client."""

from mcp_eregistrations_graylog.graylog_client.client import (
    GraylogClient,
    clear_graylog_credentials,
)
from mcp_eregistrations_graylog.graylog_client.errors import (
    GraylogAuthError,
    GraylogClientError,
    GraylogConnectionError,
    GraylogNotFoundError,
    GraylogServerError,
    GraylogTimeoutError,
    translate_error,
)

__all__ = [
    "GraylogClient",
    "GraylogAuthError",
    "GraylogClientError",
    "GraylogConnectionError",
    "GraylogNotFoundError",
    "GraylogServerError",
    "GraylogTimeoutError",
    "clear_graylog_credentials",
    "translate_error",
]
