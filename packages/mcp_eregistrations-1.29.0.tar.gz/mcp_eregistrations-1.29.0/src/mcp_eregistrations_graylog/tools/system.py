"""Graylog system tools — auth, connectivity, system info."""

from __future__ import annotations

from typing import Any

from fastmcp.exceptions import ToolError
from mcp.types import ToolAnnotations

from mcp_eregistrations_graylog.graylog_client import (
    GraylogClient,
    GraylogClientError,
    clear_graylog_credentials,
    translate_error,
)
from mcp_eregistrations_graylog.graylog_client.client import (
    get_graylog_credentials,
    store_graylog_credentials,
)
from mcp_eregistrations_graylog.server import mcp


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def graylog_connection_status(
    instance: str | None = None,
) -> dict[str, Any]:
    """Test Graylog connectivity and show version.

    Args:
        instance: Instance name.

    Returns:
        dict with connected, version, error.
    """
    try:
        async with GraylogClient.for_instance(instance) as client:
            info = await client.get("/api/system")
            return {
                "connected": True,
                "version": info.get("version"),
                "cluster_id": info.get("cluster_id"),
                "instance": instance,
            }
    except GraylogClientError as e:
        return {
            "connected": False,
            "error": str(e),
            "instance": instance,
        }
    except ToolError:
        raise
    except Exception as e:
        return {
            "connected": False,
            "error": str(e),
            "instance": instance,
        }


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def graylog_system_info(
    instance: str | None = None,
) -> dict[str, Any]:
    """Get Graylog system info (version, status, cluster). Requires auth.

    Args:
        instance: Instance name.

    Returns:
        dict with version, hostname, lifecycle, lb_status, cluster_id, timezone.
    """
    try:
        async with GraylogClient.for_instance(instance) as client:
            result: dict[str, Any] = await client.get("/api/system")
            return result
    except GraylogClientError as e:
        raise translate_error(e, resource_type="system") from e


@mcp.tool()
async def graylog_auth_login(
    username: str | None = None,
    password: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Authenticate with Graylog (Basic Auth, NOT Keycloak).

    Validates credentials by calling GET /api/system, then persists
    them for future tool calls. Use an API token as username with
    literal "token" as password, or regular admin credentials.

    Args:
        username: Graylog username or API token.
        password: Graylog password or literal "token".
        instance: Instance name.

    Returns:
        dict with success, instance, graylog_version.
    """
    from mcp_eregistrations_common.config import get_instance_config

    config = get_instance_config(instance)
    graylog_url = config.get("graylog_url")
    if not graylog_url:
        raise ToolError(
            f"No graylog_url configured for instance '{instance}'. "
            f"Use instance_add to register an instance with a graylog_url."
        )

    # At this point instance is resolved (get_instance_config raises if None)
    assert instance is not None

    # Try stored credentials if none provided
    if not username or not password:
        stored = get_graylog_credentials(instance)
        if stored:
            username, password = stored

    if not username or not password:
        return {
            "action_required": "ask_credentials",
            "message": (
                f"No Graylog credentials for '{instance}'. "
                "Provide username and password. "
                "For token auth: use the API token as username, 'token' as password."
            ),
            "instance": instance,
        }

    # Validate by hitting /api/system
    try:
        async with GraylogClient(
            base_url=graylog_url,
            username=username,
            password=password,
            verify_ssl=config.get("verify_ssl", True),
        ) as client:
            info = await client.get("/api/system")
    except GraylogClientError as e:
        raise ToolError(
            f"Authentication failed for Graylog on '{instance}': {e}"
        ) from e

    # Store in-process
    store_graylog_credentials(instance, username, password)

    # Persist to auth_store for future sessions
    try:
        from mcp_eregistrations_common.auth_store import _set_instance

        _set_instance(
            instance,
            {"graylog_username": username, "graylog_password": password},
        )
    except Exception:  # noqa: S110 — Non-fatal: in-process credential store still works for this session.
        pass

    return {
        "success": True,
        "message": f"Authenticated with Graylog on '{instance}'.",
        "instance": instance,
        "graylog_version": info.get("version"),
    }


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=False, destructiveHint=False))
async def graylog_auth_clear(
    instance: str | None = None,
    clear_stored_credentials: bool = False,
) -> dict[str, Any]:
    """Clear cached Graylog auth state for an instance. Idempotent.

    Evicts the in-process Basic Auth credentials cache so the next call
    re-resolves from the persisted auth_store. Set clear_stored_credentials
    =True to also strip graylog_username/graylog_password from auth.json
    (forces a full graylog_auth_login with explicit credentials).

    Args:
        instance: Instance name (required).
        clear_stored_credentials: Also drop persisted credentials (default: False).

    Returns:
        dict with success, instance, cleared_cached_credentials,
        cleared_stored_credentials, next_action.
    """
    from mcp_eregistrations_common.auth_store import _get_instance

    if instance is None:
        raise ToolError(
            "No instance specified. Pass instance='<name>'. "
            "Use instance_list to see available instances."
        )

    cleared_cached = clear_graylog_credentials(instance)

    cleared_stored = False
    if clear_stored_credentials:
        try:
            entry = _get_instance(instance)
            if entry.get("graylog_username") or entry.get("graylog_password"):
                # _set_instance only updates; it can't remove. We need to
                # load, pop, and write the whole auth.json.
                from mcp_eregistrations_common.auth_store import _load, _save

                data = _load()
                inst_entry = data.get("instances", {}).get(instance, {})
                had_user = inst_entry.pop("graylog_username", None) is not None
                had_pass = inst_entry.pop("graylog_password", None) is not None
                if had_user or had_pass:
                    _save(data)
                    cleared_stored = True
        except Exception:  # noqa: S110 — Persisted-store failures are non-fatal; in-process cache eviction above guarantees re-auth.
            pass

    # Check what's left so we can suggest the right next step.
    still_stored = False
    try:
        entry = _get_instance(instance)
        still_stored = bool(
            entry.get("graylog_username") and entry.get("graylog_password")
        )
    except Exception:  # noqa: S110 — best-effort check used to pick next-action hint; failure means "treat as not-stored".
        pass

    if still_stored:
        next_action = {
            "code": "retry_any_call",
            "message": (
                "Cache cleared. The next Graylog call will silently re-auth "
                "via the stored Basic Auth credentials."
            ),
        }
    else:
        next_action = {
            "code": "call_graylog_auth_login",
            "message": (
                "No Graylog credentials on file. Run `graylog_auth_login` "
                "with username and password (or an API token) to re-establish."
            ),
        }

    return {
        "success": True,
        "instance": instance,
        "cleared_cached_credentials": cleared_cached,
        "cleared_stored_credentials": cleared_stored,
        "next_action": next_action,
    }
