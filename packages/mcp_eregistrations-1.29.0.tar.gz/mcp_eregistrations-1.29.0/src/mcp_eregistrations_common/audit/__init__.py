"""Shared audit infrastructure for MCP eRegistrations servers.

Provides:
- AuditLogger: Generic audit logger (requires a get_connection callable)
- AuditEntry: Dataclass representing a single audit log entry
- AuditStatus, ObjectType, OperationType: Enums for audit fields

Usage:
    from mcp_eregistrations_common.audit import AuditLogger, AuditStatus

    logger = AuditLogger(db_path=path, get_connection=my_get_connection)
    audit_id = await logger.record_pending(...)
"""

from mcp_eregistrations_common.audit.logger import (
    AuditEntryImmutableError,
    AuditEntryNotFoundError,
    AuditLogger,
)
from mcp_eregistrations_common.audit.models import (
    AuditEntry,
    AuditStatus,
    ObjectType,
    OperationType,
)

__all__ = [
    "AuditEntry",
    "AuditEntryImmutableError",
    "AuditEntryNotFoundError",
    "AuditLogger",
    "AuditStatus",
    "ObjectType",
    "OperationType",
]
