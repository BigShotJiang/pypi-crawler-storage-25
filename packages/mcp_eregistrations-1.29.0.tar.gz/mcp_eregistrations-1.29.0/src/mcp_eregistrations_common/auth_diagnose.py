"""Shared auth-diagnose helper — used by `{bpa,ds,gdb,kc,smartlink}_auth_diagnose`.

Extracted from GDB's `gdb_auth_diagnose` (v1.19.3). Goal: give every MCP a
uniform read-only diagnostic surface that answers:

- Is a token cached for this instance?
- What claims does it carry (if JWT-decodable)?
- Is there a refresh context on disk?
- Did the last refresh attempt fail (and why)?
- Does the backend currently accept the token on a live probe?

The function is intentionally non-mutating — never calls `get_or_refresh_token`
and never clears cached state.
"""

from __future__ import annotations

import logging
import time
import uuid
from typing import Any

import httpx

logger = logging.getLogger(__name__)


def _infer_auth_type(config: dict[str, Any]) -> str:
    """Derive auth_type from an instance config dict.

    Precedence: cas_url wins over keycloak (matches the auth path the MCP
    would actually take — if cas_url is set, CAS is used regardless of any
    keycloak_url also present).
    """
    if config.get("cas_url"):
        return "cas"
    if config.get("keycloak_url") and config.get("keycloak_realm"):
        return "keycloak"
    return "unknown"


async def _probe_status(
    *,
    probe_url: str,
    token: str,
    trace_id: str,
) -> dict[str, Any]:
    """Probe a backend URL with the given token, bypassing MCP clients.

    Uses a direct httpx call so a client's retry-on-401 cannot mask the
    diagnostic signal. Always returns a dict — on failure, ``error`` is set
    to ``"timeout"`` or ``"network"`` and ``status_code`` is None. Never raises.

    Args:
        probe_url: Fully qualified URL to GET (e.g. `{base}/api/v1/status`).
        token: Bearer token to send on the probe.
        trace_id: Trace ID propagated to the probe for log correlation.

    Returns:
        dict with status_code, ok, backend_version, trace_id, error.
    """
    headers = {
        "Accept": "application/json",
        "Authorization": f"Bearer {token}",
        "X-Trace-Id": trace_id,
    }
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.get(probe_url, headers=headers)
    except httpx.TimeoutException:
        logger.debug("auth_diagnose probe timeout")
        return {
            "status_code": None,
            "ok": False,
            "backend_version": None,
            "trace_id": trace_id,
            "error": "timeout",
        }
    except httpx.RequestError as exc:
        logger.debug("auth_diagnose probe network error: %s", type(exc).__name__)
        return {
            "status_code": None,
            "ok": False,
            "backend_version": None,
            "trace_id": trace_id,
            "error": "network",
        }

    backend_version: str | None = None
    if resp.status_code == 200:
        try:
            body = resp.json()
            if isinstance(body, dict):
                # Keycloak's userinfo returns sub, not version; BPA/DS/GDB
                # status returns version. Best-effort either way.
                backend_version = body.get("version")
        except ValueError:
            pass

    return {
        "status_code": resp.status_code,
        "ok": resp.status_code == 200,
        "backend_version": backend_version,
        "trace_id": trace_id,
        "error": None,
    }


async def diagnose_auth(
    *,
    instance: str | None,
    trace_id: str | None,
    server_label: str,
    login_tool_name: str,
    probe_url: str | None,
) -> dict[str, Any]:
    """Diagnose cached auth state for an MCP server. Read-only, non-mutating.

    Args:
        instance: Instance name (None → auto-select via resolve_auth_key).
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).
        server_label: Human-readable server name for hints (e.g. "GDB", "BPA").
        login_tool_name: Name of this server's login tool (e.g. "bpa_auth_login").
            Referenced in hints so agents know which tool to call next.
        probe_url: Fully qualified URL to probe. None disables the live probe
            (e.g. for SmartLink with no dedicated health endpoint).

    Returns:
        dict with instance, auth_type, token_present, token_format,
        token_claims, refresh_context, refresh_failure, probe, hints, trace_id.
    """
    from mcp_eregistrations_common.auth import (
        _PASSWORD_GRANT_FALLBACK_PREFIX,
        decode_jwt_claims,
        get_cached_token,
        get_last_refresh_failure,
    )
    from mcp_eregistrations_common.auth_store import (
        get_credentials,
        get_refresh_context,
    )
    from mcp_eregistrations_common.config import (
        get_instance_config,
        resolve_auth_key,
    )

    inst = resolve_auth_key(instance)
    tid = trace_id or uuid.uuid4().hex[:24]
    config = get_instance_config(inst)
    auth_type = _infer_auth_type(config)
    has_stored_credentials = get_credentials(inst) is not None

    # Read cached token directly — no get_or_refresh_token, no mutations.
    token = get_cached_token(inst)
    token_present = bool(token)

    token_format: str | None = None
    token_claims_out: dict[str, Any] | None = None
    if token_present:
        raw_claims = decode_jwt_claims(token)  # type: ignore[arg-type]
        if raw_claims is None:
            token_format = "opaque"
        else:
            token_format = "jwt"
            exp_unix = (
                raw_claims.get("exp")
                if isinstance(raw_claims.get("exp"), int)
                else None
            )
            exp_remaining: int | None = None
            expired: bool | None = None
            if exp_unix is not None:
                exp_remaining = int(exp_unix - time.time())
                expired = exp_remaining < 0
            token_claims_out = {
                "iss": raw_claims.get("iss"),
                "sub": str(raw_claims.get("sub"))
                if raw_claims.get("sub") is not None
                else None,
                "email": raw_claims.get("email"),
                "roles": raw_claims.get("roles"),
                "exp_unix": exp_unix,
                "exp_seconds_remaining": exp_remaining,
                "expired": expired,
                "jti": raw_claims.get("jti"),
            }

    refresh_ctx = get_refresh_context(inst)
    refresh_out: dict[str, Any] | None = None
    if refresh_ctx is not None:
        refresh_out = {
            "token_endpoint": refresh_ctx.get("token_endpoint", ""),
            "client_id": refresh_ctx.get("client_id", ""),
            "has_refresh_token": bool(refresh_ctx.get("refresh_token")),
        }

    probe_out: dict[str, Any] | None = None
    probe_error_kind: str | None = None  # "timeout" | "network" | None
    if token_present and probe_url and token is not None:
        raw_probe = await _probe_status(
            probe_url=probe_url,
            token=token,
            trace_id=tid,
        )
        probe_error_kind = raw_probe.get("error")
        if probe_error_kind is None:
            probe_out = {
                "status_code": raw_probe["status_code"],
                "ok": raw_probe["ok"],
                "backend_version": raw_probe["backend_version"],
                "trace_id": raw_probe["trace_id"],
            }

    refresh_failure = get_last_refresh_failure(inst)
    fallback_failed = refresh_failure is not None and refresh_failure.startswith(
        _PASSWORD_GRANT_FALLBACK_PREFIX
    )
    # User-facing failure string strips the internal fallback marker so the
    # hint reads naturally regardless of which sub-state produced it.
    refresh_failure_display = (
        refresh_failure[len(_PASSWORD_GRANT_FALLBACK_PREFIX) :]
        if fallback_failed and refresh_failure is not None
        else refresh_failure
    )

    hints: list[str] = []
    if refresh_failure is not None:
        if auth_type == "cas":
            hints.append(
                f"Refresh failed: {refresh_failure_display}. CAS does not support "
                "unattended password re-authentication — re-run `auth_login` "
                "with browser flow via BPA MCP to obtain a fresh session."
            )
        elif fallback_failed:
            # Refresh failed AND the password-grant fallback also failed — the
            # most actionable state to surface, because re-running with the
            # same stored credentials will not help.
            hints.append(
                f"Stored credentials were rejected by Keycloak: "
                f"{refresh_failure_display}. The password may have changed, "
                "the account may be locked, or MFA may have been enrolled. "
                f"Re-run `{login_tool_name}` with current `username=` and "
                "`password=` to refresh stored credentials."
            )
        elif not has_stored_credentials:
            # Browser-only login past refresh expiry: silent re-auth has no
            # fallback path because no credentials were ever captured.
            hints.append(
                f"Refresh failed: {refresh_failure_display}. Browser-only "
                "login leaves no credentials for indefinite silent re-auth. "
                f"Re-run `{login_tool_name}` with `username=` and `password=` "
                "to enable silent re-auth past the next refresh expiry."
            )
        else:
            hints.append(
                f"Refresh failed: {refresh_failure_display}. Run "
                f"`{login_tool_name}` with credentials to re-authenticate."
            )
    if not token_present:
        if refresh_failure is None:
            hints.append(
                f"No auth token cached. Run `{login_tool_name}` (Keycloak) or "
                "`auth_login` via BPA MCP (CAS) to acquire one."
            )
    elif token_format == "opaque":
        hints.append(
            "Token is present but not JWT-decodable. MCP will still send it as Bearer."
        )

    expired_flag = (
        token_claims_out.get("expired") if token_claims_out is not None else None
    )
    probe_ok = probe_out is not None and probe_out.get("ok") is True
    probe_status = probe_out.get("status_code") if probe_out is not None else None

    if expired_flag is True and probe_ok:
        hints.append(
            "Token claim says expired, but backend accepted it. Possible "
            "clock drift on this machine."
        )
    elif expired_flag is True and not probe_ok and probe_error_kind is None:
        remaining = token_claims_out["exp_seconds_remaining"]  # type: ignore[index]
        hints.append(
            f"Token expired {-remaining}s ago. Run `{login_tool_name}` to refresh."
        )

    if probe_status == 401 and expired_flag is not True:
        hints.append(
            "Token decodes OK and is not expired per claims, but "
            f"`{server_label}` rejected it. Likely: revoked session, profile "
            "drift (run `instance_list`), or backend issuer/audience mismatch."
        )

    if probe_status == 404:
        hints.append(
            f"Backend health endpoint missing at this {server_label} version. "
            "Cannot live-probe auth."
        )

    if probe_ok and expired_flag is not True and token_format != "opaque":
        hints.append("Authentication is working.")

    if probe_error_kind == "timeout":
        hints.append(
            f"Probe timed out after 5s. Network slow or {server_label} "
            "unreachable — retry in a moment or check the instance URL."
        )
    elif probe_error_kind == "network":
        hints.append(
            f"Could not reach {server_label} health endpoint (network "
            "error). Check connectivity and instance URL."
        )

    if probe_url is None and token_present:
        hints.append(
            f"{server_label} has no dedicated health endpoint — live probe "
            "skipped. Call any read tool to verify the token end-to-end."
        )

    return {
        "instance": inst,
        "auth_type": auth_type,
        "token_present": token_present,
        "token_format": token_format,
        "token_claims": token_claims_out,
        "refresh_context": refresh_out,
        "refresh_failure": refresh_failure_display,
        "has_stored_credentials": has_stored_credentials,
        "probe": probe_out,
        "hints": hints,
        "trace_id": tid,
    }
