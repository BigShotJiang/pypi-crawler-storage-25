"""Shared Keycloak OIDC browser login flow.

Opens the user's default browser to the Keycloak authorization endpoint,
completes the PKCE handshake, and stores the resulting tokens in the
unified auth store so every MCP (BPA, DS, GDB, SmartLink, ...) can use
them transparently.

Unlike the password-grant flow, browser login never sees the user's
password, so credentials are NOT persisted. Silent refresh works while
the refresh token is valid; once it expires the user has to sign in
again. Callers that need indefinite silent re-auth should use the
password-grant path.
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import logging
import os
import secrets
import sys
import webbrowser
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Any
from urllib.parse import urlencode

import httpx

from mcp_eregistrations_common.auth import (
    AuthenticationError,
    discover_oidc_endpoints,
    store_shared_tokens,
)
from mcp_eregistrations_common.callback_server import CallbackServer

logger = logging.getLogger(__name__)

# Callback invoked once tokens are received, before the flow returns.
# Used by BPA's TokenManager to populate in-process role state without
# having the raw tokens appear in the function's public return value.
_SyncTokenHook = Callable[[dict[str, Any]], None]
_AsyncTokenHook = Callable[[dict[str, Any]], Awaitable[None]]
TokenHook = _SyncTokenHook | _AsyncTokenHook

# PKCE verifier length: 32 bytes → 43-char base64url string (within spec 43–128)
PKCE_VERIFIER_LENGTH = 32


# ---------------------------------------------------------------------------
# PKCE / state helpers
# ---------------------------------------------------------------------------


def generate_pkce_pair() -> tuple[str, str]:
    """Generate a PKCE code_verifier and its S256 code_challenge.

    Returns:
        Tuple of (code_verifier, code_challenge).
    """
    code_verifier = secrets.token_urlsafe(PKCE_VERIFIER_LENGTH)
    digest = hashlib.sha256(code_verifier.encode()).digest()
    code_challenge = base64.urlsafe_b64encode(digest).decode().rstrip("=")
    return code_verifier, code_challenge


def generate_state() -> str:
    """Generate a CSRF-protection state token."""
    return secrets.token_urlsafe(16)


def build_authorization_url(
    *,
    authorization_endpoint: str,
    client_id: str,
    redirect_uri: str,
    code_challenge: str,
    state: str,
    scope: str = "openid email profile",
) -> str:
    """Build a Keycloak authorization URL with PKCE."""
    params = {
        "response_type": "code",
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "scope": scope,
        "code_challenge": code_challenge,
        "code_challenge_method": "S256",
        "state": state,
    }
    return f"{authorization_endpoint}?{urlencode(params)}"


# ---------------------------------------------------------------------------
# Environment detection
# ---------------------------------------------------------------------------


def is_browser_available() -> bool:
    """Detect whether a browser can be opened in the current environment.

    Returns:
        True if browser-based login is likely to work.
    """
    # 1. Explicit headless flag (highest priority)
    if os.environ.get("MCP_HEADLESS", "").strip() == "1":
        return False

    # 2. SSH session detection
    if os.environ.get("SSH_CONNECTION") or os.environ.get("SSH_TTY"):
        return False

    # 3. Docker container detection
    if Path("/.dockerenv").exists():
        return False

    # 4. Dumb terminal
    if os.environ.get("TERM") == "dumb":
        return False

    # 5. macOS always has a browser (even via Terminal)
    if sys.platform == "darwin":
        return True

    # 6. Windows always has a browser
    if sys.platform == "win32":
        return True

    # 7. Linux: need a display server
    if os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"):
        return True

    # 8. Default: no browser
    return False


# ---------------------------------------------------------------------------
# Token exchange
# ---------------------------------------------------------------------------


async def _exchange_code_for_tokens(
    *,
    token_endpoint: str,
    code: str,
    code_verifier: str,
    redirect_uri: str,
    client_id: str,
    verify_ssl: bool = True,
) -> dict[str, Any]:
    """Exchange an authorization code for tokens via PKCE.

    Raises:
        AuthenticationError: If the token endpoint rejects the exchange.
    """
    async with httpx.AsyncClient(verify=verify_ssl) as client:
        try:
            response = await client.post(
                token_endpoint,
                data={
                    "grant_type": "authorization_code",
                    "code": code,
                    "redirect_uri": redirect_uri,
                    "client_id": client_id,
                    "code_verifier": code_verifier,
                },
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                timeout=10.0,
            )
        except httpx.RequestError as e:
            raise AuthenticationError(
                f"Cannot reach Keycloak token endpoint: {e}. Check connectivity."
            ) from e

    if response.status_code != 200:
        detail = ""
        try:
            err = response.json()
            detail = err.get("error_description", err.get("error", ""))
        except Exception:
            detail = response.text
        raise AuthenticationError(
            f"Token exchange failed (HTTP {response.status_code}): "
            f"{detail or 'Unknown error'}. "
            "Verify the Keycloak client allows authorization_code with PKCE "
            "and accepts http://127.0.0.1/*/callback as a redirect URI."
        )

    data: dict[str, Any] = response.json()
    if "access_token" not in data:
        raise AuthenticationError(
            "Token exchange response missing access_token. "
            "Verify Keycloak client configuration."
        )
    return data


# ---------------------------------------------------------------------------
# User metadata extraction
# ---------------------------------------------------------------------------


def _extract_email_from_token(access_token: str) -> str | None:
    """Extract the user email / preferred_username from a JWT access token."""
    try:
        parts = access_token.split(".")
        if len(parts) < 2:
            return None
        payload_b64 = parts[1]
        # Add padding for base64 decoding
        padded = payload_b64 + "=" * (-len(payload_b64) % 4)
        import json as _json

        payload = _json.loads(base64.urlsafe_b64decode(padded).decode())
        email = payload.get("email") or payload.get("preferred_username")
        return str(email) if email else None
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Public: browser login
# ---------------------------------------------------------------------------


async def perform_keycloak_browser_login(
    *,
    keycloak_url: str,
    realm: str,
    client_id: str,
    instance: str,
    verify_ssl: bool = True,
    instance_info: dict[str, str] | None = None,
    on_tokens: TokenHook | None = None,
) -> dict[str, Any]:
    """Run the OIDC + PKCE browser login flow against Keycloak.

    Opens the user's default browser to the Keycloak login page, waits for
    the redirect back to a local callback server, exchanges the code for
    tokens, and stores them in the shared auth store keyed by ``instance``.

    Args:
        keycloak_url: Keycloak base URL.
        realm: Keycloak realm name.
        client_id: Public OIDC client ID (must allow PKCE and
            ``http://127.0.0.1/*/callback`` as a valid redirect URI).
        instance: Profile name used as the auth-store key (same value read
            by other MCPs via ``get_or_refresh_token``).
        verify_ssl: Whether to verify TLS certificates.
        instance_info: Optional dict displayed on the success page. Supported
            keys: ``name`` (instance label), ``url`` (instance URL),
            ``product_name`` (product label in the title/footer).
        on_tokens: Optional callback invoked with the raw token response
            (``access_token``, ``refresh_token``, ``expires_in``,
            ``token_endpoint``) before this function returns. Lets in-process
            caches (BPA's ``TokenManager``) populate themselves without
            surfacing the tokens in the return value.

    Returns:
        dict with success=True, user_email, session_expires_in_minutes,
        instance, auth_method="browser". Raw tokens are deliberately
        NOT included — callers that need them should pass ``on_tokens``.

    Raises:
        AuthenticationError: On any step failing (OIDC discovery, callback
            timeout, state mismatch, token exchange rejection, browser
            unavailable).
    """
    logger.info("Starting Keycloak browser login for instance=%s", instance)

    endpoints = await discover_oidc_endpoints(
        keycloak_url=keycloak_url, realm=realm, verify_ssl=verify_ssl
    )
    authorization_endpoint = endpoints["authorization_endpoint"]
    token_endpoint = endpoints["token_endpoint"]

    code_verifier, code_challenge = generate_pkce_pair()
    state = generate_state()

    callback_server = CallbackServer(port=0, instance_info=instance_info)
    callback_server.start()
    logger.info("Callback server listening on port %d", callback_server.port)

    try:
        auth_url = build_authorization_url(
            authorization_endpoint=authorization_endpoint,
            client_id=client_id,
            redirect_uri=callback_server.redirect_uri,
            code_challenge=code_challenge,
            state=state,
        )
        if not webbrowser.open(auth_url):
            raise AuthenticationError(
                "Cannot open browser for authentication. "
                f"Please open this URL manually: {auth_url}"
            )

        code = await callback_server.wait_for_callback(expected_state=state)

        tokens = await _exchange_code_for_tokens(
            token_endpoint=token_endpoint,
            code=code,
            code_verifier=code_verifier,
            redirect_uri=callback_server.redirect_uri,
            client_id=client_id,
            verify_ssl=verify_ssl,
        )

        access_token = tokens["access_token"]
        refresh_token = tokens.get("refresh_token")
        expires_in = int(tokens.get("expires_in", 300))

        store_shared_tokens(
            instance,
            access_token=access_token,
            refresh_token=refresh_token,
            token_endpoint=token_endpoint,
            client_id=client_id,
        )

        if on_tokens is not None:
            # A hook failure must not invalidate the login — shared state
            # has already been persisted. Log and continue so the caller
            # still sees success and can reconcile in-process state lazily.
            try:
                result = on_tokens(
                    {
                        "access_token": access_token,
                        "refresh_token": refresh_token,
                        "expires_in": expires_in,
                        "token_endpoint": token_endpoint,
                    }
                )
                if asyncio.iscoroutine(result):
                    await result
            except Exception:
                logger.exception("on_tokens hook raised; continuing")

        user_email = _extract_email_from_token(access_token)

        # Briefly hold the callback server open so the success page's JS
        # can fetch /userinfo and display the user email. Kept short to
        # minimize the window during which the guarded endpoint is live.
        if user_email:
            callback_server.set_user_info(user_email)
        await asyncio.sleep(0.8)

        logger.debug("Browser login succeeded for %s", user_email or "<unknown user>")
        # Surface the silent-re-auth lifetime to the caller. Browser login
        # never sees the user's password, so silent re-auth is bounded by the
        # refresh-token lifetime (~30 days on Keycloak by default). To enable
        # indefinite silent re-auth, the user has to re-run with credentials
        # so the password-grant fallback in get_or_refresh_token can recover.
        silent_reauth_note = (
            "Browser-only login: silent re-auth via the refresh token works "
            "until refresh expiry (typically ~30 days on Keycloak). To enable "
            "indefinite silent re-auth past expiry, re-run the login tool "
            "with `username=` and `password=` so credentials are persisted."
        )
        logger.warning(
            "Browser-only login for instance=%s — silent re-auth bounded by "
            "refresh-token lifetime. Re-run with username/password to enable "
            "indefinite silent re-auth.",
            instance,
        )
        return {
            "success": True,
            "user_email": user_email,
            "session_expires_in_minutes": max(0, expires_in // 60),
            "instance": instance,
            "auth_method": "browser",
            "silent_reauth_note": silent_reauth_note,
        }
    finally:
        callback_server.stop()
