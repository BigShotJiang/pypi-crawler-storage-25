"""Local HTTP server for OAuth callback.

Generic callback listener used by any MCP performing OIDC browser-based
authentication. Binds to a dynamic localhost port, receives the Keycloak
redirect with the authorization code, validates state, and exposes a
/userinfo JSON endpoint for the success page to poll.
"""
# ruff: noqa: E501, N802  # E501: HTML templates contain long lines, N802: do_GET required by BaseHTTPRequestHandler

import asyncio
import html
import json
import logging
import secrets
from http.server import BaseHTTPRequestHandler
from socketserver import TCPServer
from threading import Thread
from urllib.parse import parse_qs, urlparse

from mcp_eregistrations_common.auth import AuthenticationError

logger = logging.getLogger(__name__)

# Default timeout for waiting for callback
CALLBACK_TIMEOUT = 60.0  # seconds


class CallbackHandler(BaseHTTPRequestHandler):
    """HTTP handler for OAuth callback and user info polling."""

    def log_message(self, format: str, *args: object) -> None:
        """Suppress default HTTP logging."""
        pass

    def log_error(self, format: str, *args: object) -> None:
        """Suppress default error logging.

        BaseHTTPRequestHandler's ``log_error`` otherwise prints the full
        requestline (which includes query params with auth code + /userinfo
        secret) on any handler exception.
        """
        pass

    def do_GET(self) -> None:
        """Handle GET request from OAuth redirect or user info poll."""
        # Guard against DNS-rebinding attacks: a malicious site whose DNS
        # resolves to 127.0.0.1 could trick the browser into POSTing here
        # and read /userinfo. Reject anything that doesn't present our
        # loopback Host header. Host is case-insensitive per RFC 7230.
        host = self.headers.get("Host", "").lower()
        port = (
            self.server.server_address[1]
            if isinstance(self.server.server_address, tuple)
            else 0
        )
        if host not in (f"127.0.0.1:{port}", f"localhost:{port}"):
            logger.warning("Rejecting request with unexpected Host header: %s", host)
            self.send_response(400)
            self.end_headers()
            return

        parsed = urlparse(self.path)
        # Log only the path — query string carries the auth code and the
        # /userinfo secret and must never be logged.
        logger.debug("Received callback request path: %s", parsed.path)

        if parsed.path == "/userinfo":
            self._handle_userinfo()
            return

        if parsed.path != "/callback":
            logger.warning("Invalid callback path: %s", parsed.path)
            self.send_response(404)
            self.end_headers()
            return

        # Parse query parameters
        params = parse_qs(parsed.query)
        code = params.get("code", [None])[0]
        state = params.get("state", [None])[0]
        error = params.get("error", [None])[0]
        error_description = params.get("error_description", [None])[0]

        logger.debug(
            "Callback params: code=%s, state=%s, error=%s",
            "present" if code else "missing",
            "present" if state else "missing",
            error,
        )

        # Store results on server instance
        server = self.server
        if hasattr(server, "_callback_result"):
            if error:
                logger.error("OAuth error: %s - %s", error, error_description)
                server._callback_result = {
                    "error": error,
                    "error_description": error_description,
                }
            else:
                logger.info("OAuth callback successful, code received")
                server._callback_result = {
                    "code": code,
                    "state": state,
                }

        addr = self.server.server_address
        port_num = addr[1] if isinstance(addr, tuple) else 0
        # Per-response nonce so the CSP can require a nonce for any inline
        # script instead of falling back to 'unsafe-inline'. Belt-and-suspenders:
        # all untrusted fields are already HTML-escaped, but this means a
        # future escape regression can't immediately become script execution.
        script_nonce = secrets.token_urlsafe(16)

        # Hardening headers:
        #  - charset declares UTF-8 explicitly
        #  - nosniff blocks MIME-sniffing into executable types
        #  - no-store prevents browsers/proxies from caching the success
        #    page (which embeds the /userinfo secret in inline JS)
        #  - no-referrer stops the /userinfo secret leaking via Referer if
        #    the user ever clicks an outbound link
        #  - CSP: default-src 'none' denies everything by default; only the
        #    exact host:port we're listening on is allowed for fetch(), and
        #    inline scripts need the per-response nonce
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cache-Control", "no-store")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'none'; "
            f"script-src 'nonce-{script_nonce}'; "
            "style-src 'unsafe-inline'; "
            f"connect-src http://127.0.0.1:{port_num}",
        )
        self.end_headers()

        instance_info = getattr(self.server, "_instance_info", None) or {}
        product_name = instance_info.get("product_name", "eRegistrations MCP")

        if error:
            body = self._render_error_page(product_name, error, error_description)
        else:
            userinfo_secret = getattr(self.server, "_userinfo_secret", "")
            body = self._render_success_page(
                product_name, instance_info, port_num, userinfo_secret, script_nonce
            )

        self.wfile.write(body.encode())

    def _render_error_page(
        self,
        product_name: str,
        error: str | None,
        error_description: str | None,
    ) -> str:
        """Render the access-denied HTML page.

        All untrusted fields (error, error_description, product_name) are
        HTML-escaped — Keycloak echoes `error_description` verbatim from
        the redirect URL, so a crafted login URL could otherwise inject
        script into this page.
        """
        safe_product = html.escape(product_name, quote=True)
        safe_error = html.escape(error, quote=True) if error else ""
        safe_desc = html.escape(error_description or "Unknown Error", quote=True)
        return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="referrer" content="no-referrer">
    <title>Access Denied - {safe_product}</title>
    <style>
        :root {{
            --bg-color: #ffffff;
            --text-primary: #1a1a1a;
            --text-secondary: #5e5e5e;
            --brand-red: #e60000;
            --border-color: #dcdcdc;
        }}
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #f4f4f4;
            color: var(--text-primary);
            padding: 24px;
        }}
        .container {{
            background: var(--bg-color);
            width: 100%;
            max-width: 480px;
            padding: 48px;
            box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
            border-top: 4px solid var(--brand-red);
        }}
        .header {{
            margin-bottom: 32px;
        }}
        h1 {{
            font-size: 32px;
            font-weight: 700;
            letter-spacing: -0.02em;
            line-height: 1.1;
            margin-bottom: 16px;
        }}
        .status-line {{
            display: inline-block;
            font-size: 14px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: var(--text-secondary);
            margin-bottom: 8px;
        }}
        p {{
            font-size: 18px;
            line-height: 1.5;
            color: var(--text-secondary);
            margin-bottom: 32px;
        }}
        .error-code {{
            font-family: monospace;
            background: #f0f0f0;
            padding: 8px 12px;
            font-size: 14px;
            color: var(--text-primary);
            display: inline-block;
            margin-top: 16px;
        }}
        .footer {{
            margin-top: 48px;
            border-top: 1px solid var(--border-color);
            padding-top: 24px;
            font-size: 12px;
            color: #999;
            display: flex;
            justify-content: space-between;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <span class="status-line">Authorization Status</span>
            <h1>Access Denied</h1>
        </div>
        <p>The system could not verify your credentials. Ensure your security token is valid and try again.</p>

        <div class="error-details">
            <div class="status-line" style="font-size: 12px;">System Response</div>
            <div style="font-weight: 600;">{safe_desc}</div>
            {f'<div class="error-code">{safe_error}</div>' if safe_error else ""}
        </div>

        <div class="footer">
            <span>AI-Native Digital Government System</span>
            <span><b>{safe_product}</b></span>
        </div>
    </div>
</body>
</html>"""

    def _render_success_page(
        self,
        product_name: str,
        instance_info: dict[str, str],
        port: int,
        userinfo_secret: str,
        script_nonce: str,
    ) -> str:
        """Render the access-authorized HTML page.

        Instance-supplied strings are HTML-escaped — while they currently
        come from trusted config, defense-in-depth avoids regressions if
        a future caller forwards untrusted input.
        """
        instance_name = instance_info.get("name", "eRegistrations")
        instance_url = instance_info.get("url", "")
        instance_host = (
            instance_url.replace("https://", "").replace("http://", "").rstrip("/")
        )
        safe_product = html.escape(product_name, quote=True)
        safe_name = html.escape(instance_name, quote=True)
        safe_host = html.escape(instance_host, quote=True)
        safe_secret = html.escape(userinfo_secret, quote=True)
        safe_nonce = html.escape(script_nonce, quote=True)

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="referrer" content="no-referrer">
    <title>Access Authorized - {safe_product}</title>
    <style>
        :root {{
            --bg-color: #ffffff;
            --text-primary: #1a1a1a;
            --text-secondary: #5e5e5e;
            --brand-green: #107c10;
            --border-color: #dcdcdc;
        }}
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #f4f4f4;
            color: var(--text-primary);
            padding: 24px;
        }}
        .container {{
            background: var(--bg-color);
            width: 100%;
            max-width: 480px;
            padding: 48px;
            box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
            border-top: 4px solid var(--brand-green);
        }}
        .header {{ margin-bottom: 32px; }}
        h1 {{
            font-size: 32px;
            font-weight: 700;
            letter-spacing: -0.02em;
            line-height: 1.1;
            margin-bottom: 16px;
        }}
        .status-line {{
            display: inline-block;
            font-size: 14px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: var(--text-secondary);
            margin-bottom: 8px;
        }}
        p {{
            font-size: 18px;
            line-height: 1.5;
            color: var(--text-secondary);
            margin-bottom: 32px;
        }}
        .session-info {{
            font-size: 14px;
            color: var(--text-secondary);
            margin-bottom: 24px;
        }}
        .session-info .row {{
            display: flex;
            align-items: center;
            padding: 8px 0;
        }}
        .session-info .row + .row {{
            border-top: 1px solid #f0f0f0;
        }}
        .session-info .label {{
            font-weight: 600;
            color: var(--text-primary);
            min-width: 80px;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.03em;
        }}
        .session-info .value {{
            font-family: 'SF Mono', 'Fira Code', monospace;
            font-size: 13px;
        }}
        .close-hint {{
            font-size: 15px;
            color: var(--text-secondary);
            display: flex;
            align-items: center;
        }}
        .check-icon {{
            display: inline-block;
            width: 16px;
            height: 16px;
            background-color: var(--brand-green);
            color: white;
            border-radius: 50%;
            text-align: center;
            line-height: 16px;
            font-size: 10px;
            margin-right: 8px;
        }}
        .footer {{
            margin-top: 48px;
            border-top: 1px solid var(--border-color);
            padding-top: 24px;
            font-size: 12px;
            color: #999;
            display: flex;
            justify-content: space-between;
        }}
        @keyframes pulse {{ 0%, 100% {{ opacity: 1; }} 50% {{ opacity: 0.4; }} }}
        .loading {{ animation: pulse 1.5s ease-in-out infinite; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <span class="status-line">Authorization Status</span>
            <h1>Access Authorized</h1>
        </div>
        <p>Your AI agent now has secure access to <b>{safe_name}</b> backend functions.</p>

        <div class="session-info">
            <div class="row">
                <span class="label">Instance</span>
                <span class="value">{safe_host}</span>
            </div>
            <div class="row" id="user-row">
                <span class="label">User</span>
                <span class="value loading" id="user-email">verifying...</span>
            </div>
        </div>

        <div class="close-hint">
            <span class="check-icon">&#10003;</span> You can close this window.
        </div>

        <div class="footer">
            <span>AI-Native Digital Government System</span>
            <span><b>{safe_product}</b></span>
        </div>
    </div>
    <script nonce="{safe_nonce}">
    (function() {{
        var el = document.getElementById('user-email');
        var attempts = 0;
        var maxAttempts = 20;
        function poll() {{
            fetch('http://127.0.0.1:{port}/userinfo?s={safe_secret}')
                .then(function(r) {{ return r.json(); }})
                .then(function(d) {{
                    if (d.status === 'ready') {{
                        el.textContent = d.email;
                        el.classList.remove('loading');
                        return;
                    }}
                    if (++attempts < maxAttempts) setTimeout(poll, 500);
                    else {{ el.textContent = 'authenticated'; el.classList.remove('loading'); }}
                }})
                .catch(function() {{
                    el.textContent = 'authenticated';
                    el.classList.remove('loading');
                }});
        }}
        setTimeout(poll, 800);
    }})();
    </script>
</body>
</html>"""

    def _handle_userinfo(self) -> None:
        """Return user info as JSON for client-side polling.

        Gated by a per-server random secret embedded into the success
        page's JS. A stray /userinfo hit from another local process or
        a DNS-rebound browser without the secret gets a 404.
        """
        parsed = urlparse(self.path)
        params = parse_qs(parsed.query)
        provided = params.get("s", [""])[0] or ""
        expected = getattr(self.server, "_userinfo_secret", "") or ""
        # Compare unconditionally — short-circuiting on missing secret
        # would create a timing side-channel on init-bug edge cases.
        if not secrets.compare_digest(provided, expected) or not expected:
            self.send_response(404)
            self.end_headers()
            return

        server = self.server
        user_info = getattr(server, "_user_info", None)

        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()

        if user_info:
            payload = {"status": "ready", "email": user_info}
        else:
            payload = {"status": "pending"}

        self.wfile.write(json.dumps(payload).encode())


class _ReusableTCPServer(TCPServer):
    """TCPServer subclass with SO_REUSEADDR enabled.

    Without allow_reuse_address, the kernel holds the port in TIME_WAIT
    for ~60-120s after a close, causing the next auth_login on the same
    fixed port to fail with [Errno 48] Address already in use (issue #89).
    On POSIX, SO_REUSEADDR permits rebinding after close without allowing
    hijacking of an active listener.
    """

    allow_reuse_address = True


class CallbackServer:
    """Local HTTP server to receive OAuth callback.

    Listens on a dynamic localhost port (port=0 by default) and waits for
    the OAuth redirect containing the authorization code.
    """

    def __init__(
        self,
        port: int = 0,
        instance_info: dict[str, str] | None = None,
    ) -> None:
        """Initialize callback server.

        Args:
            port: Port to listen on. Use 0 for dynamic port assignment.
            instance_info: Dict shown on the success page. Supported keys:
                - ``name``: instance display name (default: "eRegistrations")
                - ``url``: instance base URL for hostname display
                - ``product_name``: product label in title/footer
                  (default: "eRegistrations MCP")
        """
        self._requested_port = port
        self._instance_info = instance_info
        self._server: _ReusableTCPServer | None = None
        self._thread: Thread | None = None

    @property
    def port(self) -> int:
        """Get the actual port the server is listening on."""
        if self._server is None:
            raise RuntimeError("Server not started")
        return self._server.server_address[1]

    @property
    def redirect_uri(self) -> str:
        """Get the redirect URI for OAuth configuration."""
        return f"http://127.0.0.1:{self.port}/callback"

    @property
    def userinfo_secret(self) -> str:
        """Get the per-server /userinfo secret (exposed for tests)."""
        if self._server is None:
            raise RuntimeError("Server not started")
        return getattr(self._server, "_userinfo_secret", "")

    def start(self) -> None:
        """Start the callback server in a background thread."""
        self._server = _ReusableTCPServer(
            ("127.0.0.1", self._requested_port), CallbackHandler
        )
        self._server._callback_result = None  # type: ignore[attr-defined]
        self._server._instance_info = self._instance_info  # type: ignore[attr-defined]
        self._server._user_info = None  # type: ignore[attr-defined]
        # Per-server secret guards /userinfo against untrusted local requests
        # (other processes on the host, DNS-rebound pages in the browser).
        self._server._userinfo_secret = secrets.token_urlsafe(16)  # type: ignore[attr-defined]
        self._thread = Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        """Stop the callback server."""
        if self._server:
            self._server.shutdown()
            self._server.server_close()
            self._server = None
        if self._thread:
            self._thread.join(timeout=2.0)
            self._thread = None

    def set_user_info(self, email: str) -> None:
        """Store user email for the success page to display via JS polling."""
        if self._server:
            self._server._user_info = email  # type: ignore[attr-defined]

    async def wait_for_callback(
        self, expected_state: str, timeout: float = CALLBACK_TIMEOUT
    ) -> str:
        """Wait for OAuth callback and return authorization code.

        Args:
            expected_state: The state parameter to validate against.
            timeout: Maximum time to wait for callback in seconds.

        Returns:
            The authorization code from the callback.

        Raises:
            AuthenticationError: If callback fails or times out.
        """
        start_time = asyncio.get_event_loop().time()

        while True:
            # Check if we have a result
            if self._server and self._server._callback_result:  # type: ignore[attr-defined]
                result = self._server._callback_result  # type: ignore[attr-defined]

                # Handle error response from Keycloak
                if "error" in result:
                    error = result.get("error", "unknown")
                    description = result.get("error_description")
                    detail = f"{error}: {description}" if description else error
                    raise AuthenticationError(
                        f"Authentication failed: {detail}. "
                        "Please try again. If the problem persists, "
                        "check the configured instances via "
                        "instance_list — you may need a custom profile "
                        "or a realm-specific Keycloak client."
                    )

                # Validate state to prevent CSRF. Constant-time compare to
                # avoid leaking match progress through response timing.
                received_state = result.get("state") or ""
                if not secrets.compare_digest(received_state, expected_state):
                    raise AuthenticationError(
                        "Authentication failed: Security validation failed "
                        "(state mismatch). Please try auth_login again."
                    )

                code = result.get("code")
                if not code:
                    raise AuthenticationError(
                        "Authentication failed: No authorization code received. "
                        "Please try again."
                    )

                return str(code)

            # Check timeout
            elapsed = asyncio.get_event_loop().time() - start_time
            if elapsed >= timeout:
                raise AuthenticationError(
                    f"Authentication timed out: No response received within "
                    f"{int(timeout)} seconds. Please try auth_login again."
                )

            # Wait a bit before checking again
            await asyncio.sleep(0.1)
