"""GDB HTTP escape hatch — raw request tool for untyped endpoints."""

from __future__ import annotations

from typing import Any

from fastmcp.exceptions import ToolError

from mcp_eregistrations_gdb.gdb_client import GDBClient, GDBClientError, translate_error
from mcp_eregistrations_gdb.server import mcp

_ALLOWED_METHODS = {"GET", "POST", "PUT", "DELETE", "PATCH"}


@mcp.tool()
async def gdb_http_request(
    method: str,
    path: str,
    body: dict[str, Any] | None = None,
    params: dict[str, Any] | None = None,
    trace_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Escape hatch: call any GDB endpoint. Prefer typed tools when available.

    Uses the authenticated GDB client with automatic token refresh.
    Returns the raw HTTP status, JSON body (if parseable), and text.

    Args:
        method: HTTP method (GET, POST, PUT, DELETE, PATCH).
        path: Endpoint path (e.g. "/api/v1/database/modify").
        body: JSON request body (default: None).
        params: Query parameters (default: None).
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).
        instance: Instance name (default: auto-select).

    Returns:
        dict with status, json, text, trace_id.
    """
    method_upper = method.upper()
    if method_upper not in _ALLOWED_METHODS:
        allowed = ", ".join(sorted(_ALLOWED_METHODS))
        raise ToolError(f"Invalid method '{method}'. Use one of: {allowed}.")

    if "://" in path or not path.startswith("/"):
        raise ToolError(
            "path must be a relative path starting with '/' "
            "(e.g. '/api/v1/database/modify'). Absolute URLs are not allowed."
        )

    try:
        async with GDBClient.for_instance(instance, trace_id=trace_id) as client:
            http_client = client._ensure_client()
            resp = await http_client.request(
                method_upper, path, json=body, params=params
            )

            # Retry once on 401 (token refresh)
            if resp.status_code == 401 and client._instance:
                refreshed = await client._refresh_and_update_header()
                if refreshed:
                    resp = await http_client.request(
                        method_upper, path, json=body, params=params
                    )

            result: dict[str, Any] = {"status": resp.status_code}
            if resp.content:
                try:
                    result["json"] = resp.json()
                    result["text"] = None
                except Exception:
                    result["json"] = None
                    result["text"] = resp.text
            else:
                result["json"] = None
                result["text"] = None
            result["trace_id"] = client.trace_id

            return result
    except GDBClientError as e:
        raise translate_error(e, resource_type="http_request") from e
