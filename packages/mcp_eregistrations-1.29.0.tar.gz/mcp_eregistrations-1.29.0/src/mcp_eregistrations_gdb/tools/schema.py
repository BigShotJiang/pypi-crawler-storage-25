"""GDB schema builder and validator for the GDB JSON Schema dialect."""

from __future__ import annotations

import copy
import hashlib
import json
from typing import Any

from fastmcp.exceptions import ToolError
from mcp.types import ToolAnnotations

from mcp_eregistrations_gdb.server import mcp

# Field type → GDB JSON Schema type mapping
_TYPE_MAP: dict[str, dict[str, Any]] = {
    "text": {"type": "string"},
    "string": {"type": "string"},
    "number": {"type": "number"},
    "boolean": {"type": "boolean"},
    "date": {"type": "string", "format": "date"},
    "datetime": {"type": "string", "format": "date-time"},
}


def _build_field_property(field: dict[str, Any], field_id: int) -> dict[str, Any]:
    """Convert a single flat field dict to a GDB JSON Schema property."""
    field_type = field.get("type", "text")
    prop: dict[str, Any] = {"$id": field_id}

    if field_type in _TYPE_MAP:
        prop.update(_TYPE_MAP[field_type])
    elif field_type == "catalog":
        prop["type"] = "catalog"
        if "catalog_code" in field:
            prop["catalogCode"] = field["catalog_code"]
    elif field_type == "file":
        items: dict[str, Any] = {"type": "file", "antivirus": True}
        if "consumes" in field:
            items["consumes"] = field["consumes"]
        prop["type"] = "array"
        prop["items"] = items
    else:
        # Pass through unknown types as-is
        prop["type"] = field_type

    if field.get("primary_key"):
        prop["primaryKey"] = True
    if field.get("read_only"):
        prop["readOnly"] = True
    if field.get("group"):
        prop["group"] = field["group"]

    return prop


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def gdb_schema_build(
    fields: list[dict[str, Any]],
) -> dict[str, Any]:
    """Build a valid GDB JSON Schema from a flat field list.

    Pure utility — no API call. Handles $id counters, $incrementIndex,
    primaryKey, readOnly, format, catalog and file type shapes.

    Args:
        fields: List of field dicts with keys: name (required), type
            (text|number|boolean|date|datetime|catalog|file, default: text),
            primary_key, read_only, required, group, consumes, catalog_code.

    Returns:
        dict — valid GDB JSON Schema with type, $incrementIndex, properties,
        required.
    """
    if not fields:
        raise ToolError("fields list must not be empty.")

    seen_names: set[str] = set()
    properties: dict[str, Any] = {}
    required: list[str] = []

    for i, field in enumerate(fields, start=1):
        name = field.get("name")
        if not name:
            raise ToolError(f"Field at index {i - 1} is missing required 'name' key.")
        if name in seen_names:
            raise ToolError(f"Duplicate field name: '{name}'.")
        seen_names.add(name)

        properties[name] = _build_field_property(field, field_id=i)
        if field.get("required"):
            required.append(name)

    schema: dict[str, Any] = {
        "type": "object",
        "$incrementIndex": len(fields),
        "properties": properties,
    }
    if required:
        schema["required"] = required

    return schema


def _err(code: str, message: str, path: str = "") -> dict[str, Any]:
    return {"code": code, "message": message, "path": path}


def _validate_schema_dialect(schema: dict[str, Any]) -> list[dict[str, Any]]:
    """Run the GDB JSON Schema dialect checks.

    Checks: object shape, $id uniqueness/sequencing, $incrementIndex,
    required[] references, at-most-one primaryKey.
    """
    errors: list[dict[str, Any]] = []

    if not isinstance(schema, dict):
        return [_err("INVALID_TYPE", "schema must be an object.", "/")]

    if schema.get("type") != "object":
        errors.append(
            _err("INVALID_TYPE", "root schema 'type' must be 'object'.", "/type")
        )

    properties = schema.get("properties")
    if not isinstance(properties, dict):
        errors.append(
            _err(
                "MISSING_PROPERTIES",
                "schema must have a 'properties' object.",
                "/properties",
            )
        )
        return errors

    if not properties:
        errors.append(
            _err(
                "EMPTY_PROPERTIES",
                "schema 'properties' must not be empty.",
                "/properties",
            )
        )

    # $id checks
    seen_ids: dict[int, str] = {}
    max_id = 0
    primary_keys: list[str] = []
    for name, prop in properties.items():
        path = f"/properties/{name}"
        if not isinstance(prop, dict):
            errors.append(
                _err("INVALID_PROPERTY", f"property '{name}' must be an object.", path)
            )
            continue

        pid = prop.get("$id")
        if pid is None:
            errors.append(
                _err("MISSING_ID", f"property '{name}' is missing '$id'.", path)
            )
        elif not isinstance(pid, int):
            errors.append(
                _err(
                    "INVALID_ID",
                    f"property '{name}' has non-integer '$id': {pid!r}.",
                    path,
                )
            )
        else:
            if pid < 1:
                errors.append(
                    _err(
                        "INVALID_ID",
                        f"property '{name}' '$id' must be >= 1 (got {pid}).",
                        path,
                    )
                )
            if pid in seen_ids:
                errors.append(
                    _err(
                        "DUPLICATE_ID",
                        f"property '{name}' shares '$id' {pid} with '{seen_ids[pid]}'.",
                        path,
                    )
                )
            else:
                seen_ids[pid] = name
            if pid > max_id:
                max_id = pid

        if prop.get("primaryKey") is True:
            primary_keys.append(name)

    # $incrementIndex check
    incr = schema.get("$incrementIndex")
    if incr is None:
        errors.append(
            _err(
                "MISSING_INCREMENT_INDEX",
                "schema is missing '$incrementIndex'.",
                "/$incrementIndex",
            )
        )
    elif not isinstance(incr, int):
        errors.append(
            _err(
                "INVALID_INCREMENT_INDEX",
                f"'$incrementIndex' must be an integer (got {incr!r}).",
                "/$incrementIndex",
            )
        )
    elif incr < max_id:
        errors.append(
            _err(
                "STALE_INCREMENT_INDEX",
                f"'$incrementIndex' ({incr}) is less than max $id ({max_id}).",
                "/$incrementIndex",
            )
        )

    # required[] references
    required = schema.get("required")
    if required is not None:
        if not isinstance(required, list):
            errors.append(
                _err(
                    "INVALID_REQUIRED",
                    "'required' must be a list.",
                    "/required",
                )
            )
        else:
            for i, name in enumerate(required):
                if not isinstance(name, str):
                    errors.append(
                        _err(
                            "INVALID_REQUIRED_ENTRY",
                            f"'required[{i}]' must be a string (got {name!r}).",
                            f"/required/{i}",
                        )
                    )
                elif name not in properties:
                    errors.append(
                        _err(
                            "UNKNOWN_REQUIRED",
                            f"'required[{i}]' references unknown property '{name}'.",
                            f"/required/{i}",
                        )
                    )

    # primaryKey: at most one
    if len(primary_keys) > 1:
        errors.append(
            _err(
                "MULTIPLE_PRIMARY_KEYS",
                f"at most one property may set primaryKey=True; found: "
                f"{', '.join(primary_keys)}.",
                "/properties",
            )
        )

    return errors


def _canonicalize_schema(schema: dict[str, Any]) -> dict[str, Any]:
    """Produce a canonical form: sort required[], fix $incrementIndex."""
    canonical = copy.deepcopy(schema)

    properties = canonical.get("properties") or {}
    max_id = 0
    if isinstance(properties, dict):
        for prop in properties.values():
            if isinstance(prop, dict):
                pid = prop.get("$id")
                if isinstance(pid, int) and pid > max_id:
                    max_id = pid

    # Normalize $incrementIndex to max observed $id when missing or lower
    if max_id > 0:
        current = canonical.get("$incrementIndex")
        if not isinstance(current, int) or current < max_id:
            canonical["$incrementIndex"] = max_id

    required = canonical.get("required")
    if isinstance(required, list):
        canonical["required"] = sorted(r for r in required if isinstance(r, str))

    return canonical


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def gdb_schema_validate(
    schema: dict[str, Any],
) -> dict[str, Any]:
    """Validate a GDB JSON Schema offline (no API call).

    Checks $id uniqueness, $incrementIndex consistency, required[]
    references, and primaryKey conventions. Returns structured errors
    and a canonical form.

    When invalid (errors != []), canonical_form is None and schema_hash
    is computed from the raw input schema (for caller identity, not
    canonical identity).

    Args:
        schema: GDB JSON Schema to validate.

    Returns:
        dict with valid, canonical_form, schema_hash, errors.
    """
    if not isinstance(schema, dict):
        raise ToolError("schema must be a dict.")

    errors = _validate_schema_dialect(schema)
    canonical = _canonicalize_schema(schema) if errors == [] else None
    hash_source = canonical if canonical is not None else schema
    schema_hash = (
        "sha256:"
        + hashlib.sha256(json.dumps(hash_source, sort_keys=True).encode()).hexdigest()[
            :16
        ]
    )

    return {
        "valid": not errors,
        "canonical_form": canonical,
        "schema_hash": schema_hash,
        "errors": errors,
    }
