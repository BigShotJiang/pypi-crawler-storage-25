"""GDB database tools — CRUD, versions, compare, duplicate."""

from __future__ import annotations

import hashlib
import json
from typing import Any

from fastmcp.exceptions import ToolError
from mcp.types import ToolAnnotations

from mcp_eregistrations_gdb.gdb_client import (
    GDBClient,
    GDBClientError,
    GDBNotFoundError,
    translate_error,
)
from mcp_eregistrations_gdb.server import mcp
from mcp_eregistrations_gdb.tools import _add_optional

_MAX_BATCH_CODES = 200
_VALID_INCLUDE_FIELDS = {
    "version",
    "last_modified",
    "row_count",
    "schema_hash",
    "modified_by",
}


def _build_audit_info(db: dict[str, Any]) -> dict[str, Any]:
    """Extract audit fields from a raw database dict.

    GDB serializes last-modifier identity as ``by_user_name`` +
    ``by_user_auth_id`` and ``modified_at`` — there is no distinct
    creator/created_at on /database responses. We surface these under
    ``modified_by`` (nested) and ``modified_at`` (flat).
    """
    info: dict[str, Any] = {}
    by_name = db.get("by_user_name")
    by_auth_id = db.get("by_user_auth_id")
    if by_name is not None or by_auth_id is not None:
        modified_by: dict[str, Any] = {
            "name": by_name,
            "auth_id": by_auth_id,
        }
        on_behalf_name = db.get("by_on_behalf_of_user_name")
        on_behalf_auth_id = db.get("by_on_behalf_of_user_auth_id")
        if on_behalf_name is not None or on_behalf_auth_id is not None:
            modified_by["on_behalf_of"] = {
                "name": on_behalf_name,
                "auth_id": on_behalf_auth_id,
            }
        info["modified_by"] = modified_by
    if db.get("modified_at") is not None:
        info["modified_at"] = db["modified_at"]
    return info


def _compute_schema_hash(schema: dict[str, Any] | None) -> str | None:
    """Compute canonical sha256 hash of a schema (matches list_status)."""
    if not schema:
        return None
    canonical = json.dumps(schema, sort_keys=True).encode()
    return "sha256:" + hashlib.sha256(canonical).hexdigest()[:16]


def _schemas_match(
    incoming: dict[str, Any] | None, existing: dict[str, Any] | None
) -> bool:
    """True iff both schemas hash to the same canonical sha256.

    Returns False for any None on either side. Used by the dedup guard
    in gdb_database_upsert / gdb_database_update to avoid creating a
    no-op new version when the incoming schema is byte-equivalent to
    the current published version.
    """
    if incoming is None or existing is None:
        return False
    lhs = _compute_schema_hash(incoming)
    rhs = _compute_schema_hash(existing)
    if lhs is None or rhs is None:
        return False
    return lhs == rhs


def _compute_schema_diff(
    old_schema: dict[str, Any] | None,
    new_schema: dict[str, Any] | None,
) -> dict[str, Any]:
    """Diff two GDB JSON Schemas by top-level properties.

    Returns {added, removed, changed}. Type-level only — 'changed'
    fires when a property's 'type' differs; flag changes to
    primaryKey, readOnly, format, group, or items are NOT detected.
    """
    old_props: dict[str, Any] = (old_schema or {}).get("properties") or {}
    new_props: dict[str, Any] = (new_schema or {}).get("properties") or {}

    added = sorted(set(new_props) - set(old_props))
    removed = sorted(set(old_props) - set(new_props))
    changed: list[dict[str, Any]] = []
    for name in sorted(set(old_props) & set(new_props)):
        old_type = old_props[name].get("type")
        new_type = new_props[name].get("type")
        if old_type != new_type:
            changed.append({"name": name, "from": old_type, "to": new_type})
    return {"added": added, "removed": removed, "changed": changed}


def _predict_next_version(current_version: Any) -> str | None:
    """Predict next GDB version string (1 → 1.1, 1.1 → 1.2, ...).

    GDB bumps minor by 0.1 on republish. Returns None if version
    is non-numeric or missing.
    """
    try:
        return f"{round(float(current_version) + 0.1, 1)}"
    except (TypeError, ValueError):
        return None


async def _find_database_for_code(
    client: GDBClient, code: str
) -> dict[str, Any] | None:
    """Locate the highest-version database for a given code.

    Returns the flattened db entry (with catalog context) or None if
    no database with this code exists.
    """
    catalogs = await client.get("/databases")
    if not isinstance(catalogs, list):
        catalogs = catalogs.get("catalogs", [])

    # code lives on the catalog, not on individual databases
    matches: list[dict[str, Any]] = []
    for catalog in catalogs:
        if catalog.get("code") != code:
            continue
        for db in catalog.get("databases", []):
            matches.append({**db, "catalog_code": catalog.get("code")})
    if not matches:
        return None

    def _version_key(db: dict[str, Any]) -> float:
        try:
            return float(db.get("version") or 0)
        except (TypeError, ValueError):
            return 0.0

    return max(matches, key=_version_key)


async def _resolve_latest_published_for_code(
    client: GDBClient, code: str
) -> dict[str, Any] | None:
    """Return the latest *published* (non-draft) database for a code.

    Differs from _find_database_for_code: this filters out drafts and
    fetches the full schema via /database/{id} so callers have a ready
    comparison target. Returns None if no published version exists.
    """
    catalogs = await client.get("/databases")
    if not isinstance(catalogs, list):
        catalogs = catalogs.get("catalogs", [])

    matches: list[dict[str, Any]] = []
    for catalog in catalogs:
        if catalog.get("code") != code:
            continue
        for db in catalog.get("databases", []):
            if db.get("is_draft"):
                continue
            matches.append({**db, "catalog_code": catalog.get("code")})
    if not matches:
        return None

    def _version_key(db: dict[str, Any]) -> float:
        try:
            return float(db.get("version") or 0)
        except (TypeError, ValueError):
            return 0.0

    latest = max(matches, key=_version_key)
    db_id = latest.get("id")
    if db_id is None:
        return latest
    try:
        full = await client.get(f"/database/{db_id}")
    except GDBNotFoundError:
        return None
    # Merge: keep catalog_code from list view, pull schema + audit from single view
    merged = {**latest, **full}
    return merged


def _tags_for_modify_payload(
    tags: list[dict[str, Any]] | None,
) -> list[dict[str, Any]]:
    """Strip ``id`` from schema_tags / schema_flags so /modify creates fresh rows.

    The upstream backend's /api/v1/database/{id}/edit endpoint does not
    re-parent schema_tags or schema_flags to the new draft row. When we
    restore them via a post-edit /modify call, any stale source-version
    ``id`` would either no-op (filter returns None -> create) or risk an
    FK error on future backend versions. Safest: drop ids so every entry
    is created fresh on the draft.
    """
    if not tags:
        return []
    return [{k: v for k, v in tag.items() if k != "id"} for tag in tags]


async def _ensure_modify_required_fields(
    client: GDBClient,
    *,
    database_id: int,
    catalog_name: str | None,
    code: str | None,
    schema: dict[str, Any] | None,
    allow_missing: bool = False,
) -> tuple[str | None, str | None, dict[str, Any] | None, dict[str, Any] | None]:
    """Pre-fetch the DB when the caller omitted any required /modify field.

    GDB's POST /api/v1/database/modify requires catalog_name + code +
    schema on every call. Partial updates fail with 400 ("This field is
    required"). This helper fetches the current state once and fills in
    only the fields the caller did not supply, so ``gdb_database_update``
    behaves like a true PATCH from the caller's perspective.

    Returns (resolved_catalog_name, resolved_code, resolved_schema,
    prefetched_db). Caller-supplied values always win over fetched.

    When ``allow_missing`` is True and the database is not found, returns
    the caller values unchanged with ``prefetched_db=None`` so dry-run
    simulations can still answer "would_create=True" for a non-existent
    id. When ``allow_missing`` is False, GDBNotFoundError propagates so
    the caller gets a clear "database not found" error instead of a
    downstream "field required" from the backend.
    """
    need_fetch = catalog_name is None or code is None or schema is None
    if not need_fetch:
        return (catalog_name, code, schema, None)

    try:
        prefetched = await client.get(f"/database/{database_id}")
    except GDBNotFoundError:
        if allow_missing:
            return (catalog_name, code, schema, None)
        raise

    if not isinstance(prefetched, dict):
        # Defensive: un-mocked test clients can return non-dicts. Skip
        # the fill-in rather than crash — the caller-supplied values
        # will propagate as-is and the backend will reject if invalid.
        return (catalog_name, code, schema, None)

    # GET /database/{id} returns the parent catalog's name under top-level
    # ``name``; `_normalize_get_response` rewrites to ``catalog_name``, but
    # this helper runs before normalization, so accept both keys.
    fetched_catalog = prefetched.get("catalog_name") or prefetched.get("name")
    fetched_code = prefetched.get("code")
    fetched_schema = prefetched.get("schema")

    return (
        catalog_name if catalog_name is not None else fetched_catalog,
        code if code is not None else fetched_code,
        schema if schema is not None else fetched_schema,
        prefetched,
    )


def _verify_catalog_exists(
    catalogs: list[dict[str, Any]],
    catalog_name: str,
) -> None:
    """Raise ToolError if no catalog exactly matches ``catalog_name``.

    GDB's /api/v1/database/modify endpoint has silent find-or-create
    semantics on catalog_name: a typo (or case mismatch) creates a new
    catalog next to the one the caller intended, with no warning. This
    helper does a client-side exact-match check before the POST so the
    silent-duplicate case surfaces as a clear error. Opt-out via the
    ``create_catalog_if_missing`` flag on the caller tool.

    The error body lists close matches (case-insensitive substring) so
    the caller can correct a typo without a separate lookup.

    Skips the check when ``catalogs`` is not a non-empty list of dicts:
    a real, reachable GDB always returns a populated list, so any other
    shape (empty list, non-list, non-dict entries) usually means a mocked
    test client or a backend failure that will surface elsewhere —
    neither case should block a write.
    """
    if not isinstance(catalogs, list) or not catalogs:
        return

    existing_names: list[str] = []
    for c in catalogs:
        if not isinstance(c, dict):
            continue
        name = c.get("name")
        if isinstance(name, str) and name:
            existing_names.append(name)
    if not existing_names:
        return
    if catalog_name in existing_names:
        return

    needle = catalog_name.lower()
    close = sorted(
        {n for n in existing_names if needle in n.lower() or n.lower() in needle}
    )[:10]
    hint = (
        f" Close matches: {close}."
        if close
        else " No close matches found — use gdb_catalog_list to discover catalogs."
    )
    raise ToolError(
        f"No catalog named {catalog_name!r} exists on this instance.{hint} "
        "To create a new catalog along with the database, call this tool "
        "again with create_catalog_if_missing=True."
    )


async def _simulate_modify(
    client: GDBClient,
    *,
    database_id: int | None,
    code: str | None,
    schema: dict[str, Any] | None,
    payload: dict[str, Any],
    prefetched_db: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build the dry-run response for a would-be /database/modify call.

    Queries existing state (never writes) to compute would_create,
    would_new_version, new_version, diff, schema_hash.

    ``prefetched_db`` lets callers that already fetched the target (e.g.
    ``gdb_database_update`` via ``_ensure_modify_required_fields``) avoid
    a second GET for the same record. When None and ``database_id`` is
    set, this function does its own fetch and handles NotFound internally.
    """
    schema_hash = _compute_schema_hash(schema)

    existing_schema: dict[str, Any] | None = None
    current_version: Any = None
    would_create = True
    would_new_version = False
    new_version: str | None = None

    if database_id is not None:
        existing: dict[str, Any] | None
        if prefetched_db is not None:
            existing = prefetched_db
            would_create = False
        else:
            try:
                existing = await client.get(f"/database/{database_id}")
                would_create = False
            except GDBNotFoundError:
                existing = None
                would_create = True
        if existing is not None:
            existing_schema = existing.get("schema")
            current_version = existing.get("version")
    elif code is not None:
        match = await _find_database_for_code(client, code)
        if match is not None:
            would_create = False
            would_new_version = not match.get("is_draft", False)
            current_version = match.get("version")
            if would_new_version:
                new_version = _predict_next_version(current_version)
            # Fetch full schema for diff
            db_id = match.get("id")
            if db_id is not None:
                try:
                    full = await client.get(f"/database/{db_id}")
                    existing_schema = full.get("schema")
                except GDBNotFoundError:
                    existing_schema = None

    diff = _compute_schema_diff(existing_schema, schema)
    # would_skip_if_unchanged: would a skip_if_unchanged=True caller dedup?
    # True iff this would be a new version AND schemas hash-match.
    would_skip_if_unchanged = would_new_version and _schemas_match(
        schema, existing_schema
    )

    return {
        "dry_run": True,
        "would_create": would_create,
        "would_new_version": would_new_version,
        "would_skip_if_unchanged": would_skip_if_unchanged,
        "current_version": current_version,
        "new_version": new_version,
        "diff": diff,
        "schema_hash": schema_hash,
        "payload": payload,
        "validation_errors": [],
    }


def _build_unchanged_response(
    match: dict[str, Any],
    *,
    incoming_schema: dict[str, Any] | None,
    trace_id: str,
    draft_preserved: bool = False,
    draft_id: int | None = None,
) -> dict[str, Any]:
    """Build the response body when skip_if_unchanged dedup fires.

    Shape is deliberately aligned with the non-dedup response: same
    keys for id/catalog_id/catalog_code, plus unchanged=True and
    compared_against (id, version, modified_at). schema_hash is always
    included for observability. draft_preserved is True when the caller
    is update-to-publish and their draft was left intact.
    """
    response: dict[str, Any] = {
        "unchanged": True,
        "is_new_version": False,
        "id": match.get("id"),
        "version": match.get("version"),
        "catalog_id": match.get("catalog_id"),
        "catalog_code": match.get("catalog_code") or match.get("code"),
        "schema_hash": _compute_schema_hash(incoming_schema),
        "compared_against": {
            "id": match.get("id"),
            "version": match.get("version"),
            "modified_at": match.get("modified_at"),
        },
        "trace_id": trace_id,
    }
    if draft_preserved:
        response["draft_preserved"] = True
        response["draft_id"] = draft_id
    return response


def _normalize_get_response(raw: dict[str, Any]) -> dict[str, Any]:
    """Normalize /database/{id} response to unambiguous field names.

    The endpoint returns a bare ``name`` at the top level which is
    actually the parent catalog's name (not the database's own name —
    the database-level name in the batch response is usually null or
    differs). Rename to ``catalog_name`` so agents don't confuse it
    with a database-level identifier.
    """
    if "name" not in raw:
        return dict(raw)
    result = dict(raw)
    result["catalog_name"] = result.pop("name")
    return result


def _normalize_modify_response(raw: dict[str, Any]) -> dict[str, Any]:
    """Normalize /api/v1/database/modify response to unambiguous field names.

    The API returns 'catalog_code' which is actually the database code,
    and omits the database name entirely. This renames fields to avoid
    confusion between catalog-level and database-level identifiers.
    """
    result: dict[str, Any] = {"id": raw.get("id")}
    # catalog_code from API is actually the database/catalog shared code
    code = raw.get("catalog_code") or raw.get("code")
    if code is not None:
        result["database_code"] = code
    if raw.get("catalog_id") is not None:
        result["catalog_id"] = raw["catalog_id"]
    if raw.get("catalog_data_index_increment") is not None:
        result["catalog_data_index_increment"] = raw["catalog_data_index_increment"]
    if raw.get("group_id") is not None:
        result["group_id"] = raw["group_id"]
    return result


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def gdb_database_list(
    name_contains: str | None = None,
    code_contains: str | None = None,
    page: int = 1,
    page_size: int = 50,
    trace_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """List databases across all catalogs (flattened) with filtering.

    Each database includes its parent catalog_code, catalog_name, catalog_id.

    Args:
        name_contains: Filter by database name (case-insensitive substring).
        code_contains: Filter by database code (case-insensitive substring).
        page: Page number (default: 1).
        page_size: Results per page (default: 50, max: 200).
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).
        instance: Instance name (default: auto-select).

    Returns:
        dict with total_count, page, page_size, has_next, databases, trace_id.
    """
    page_size = min(page_size, 200)
    try:
        async with GDBClient.for_instance(instance, trace_id=trace_id) as client:
            catalogs = await client.get("/databases")
            if not isinstance(catalogs, list):
                catalogs = catalogs.get("catalogs", [])
            databases: list[dict[str, Any]] = []
            for catalog in catalogs:
                for db in catalog.get("databases", []):
                    databases.append(
                        {
                            "id": db.get("id"),
                            "uuid": db.get("uuid"),
                            "version": db.get("version"),
                            "name": db.get("name"),
                            "code": db.get("code"),
                            "is_draft": db.get("is_draft"),
                            "catalog_code": catalog.get("code"),
                            "catalog_name": catalog.get("name"),
                            "catalog_id": catalog.get("id"),
                        }
                    )

            # Client-side filtering
            if name_contains:
                needle = name_contains.lower()
                databases = [
                    d for d in databases if needle in (d.get("name") or "").lower()
                ]
            if code_contains:
                needle = code_contains.lower()
                databases = [
                    d for d in databases if needle in (d.get("code") or "").lower()
                ]

            total_count = len(databases)

            # Client-side pagination
            start = (page - 1) * page_size
            page_items = databases[start : start + page_size]
            has_next = (start + page_size) < total_count

            return {
                "total_count": total_count,
                "page": page,
                "page_size": page_size,
                "has_next": has_next,
                "databases": page_items,
                "trace_id": client.trace_id,
            }
    except GDBClientError as e:
        raise translate_error(e, resource_type="database") from e


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def gdb_database_list_status(
    codes: list[str],
    include: list[str] | None = None,
    trace_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Batch status for multiple databases by code. One API call.

    Args:
        codes: Database codes to look up (max 200).
        include: Optional fields: "version", "last_modified", "row_count",
            "schema_hash", "modified_by" (default:
            ["version", "last_modified", "modified_by"]).
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).
        instance: Instance name (default: auto-select).

    Returns:
        dict keyed by code, each with id, latest_version, is_draft,
        and requested includes (last_modified, modified_by, ...),
        or {error: "not_found"}. Also includes a "_trace_id" key (underscore
        prefix avoids collision with database codes).

    Note:
        `last_modified` and `modified_by` are best-effort: the GDB
        `/databases` batch response serializes them on most instances
        (verified: cuba-dev populates `modified_at` on 100% of entries)
        but may return null on older backends or for rows with no audit
        history. For guaranteed audit data, fetch the single database
        via gdb_database_get (costs N requests).

        These fields reflect the most recent save, not creation. GDB's
        `DatabaseSerializer` does not expose `created_at` / `created_by`
        (tracked upstream: UNCTAD-eRegistrations/GDB#5). Approximating
        creation time from version 1's `last_modified` is unreliable
        because `Database.save()._publishing` re-saves the existing row
        to swap versions, overwriting the earliest timestamp.
    """
    if not codes:
        raise ToolError("codes list must not be empty.")
    if len(codes) > _MAX_BATCH_CODES:
        raise ToolError(f"Maximum {_MAX_BATCH_CODES} codes per call, got {len(codes)}.")

    include_set = (
        set(include) if include else {"version", "last_modified", "modified_by"}
    )
    invalid = include_set - _VALID_INCLUDE_FIELDS
    if invalid:
        raise ToolError(
            f"Invalid include fields: {sorted(invalid)}. "
            f"Valid: {sorted(_VALID_INCLUDE_FIELDS)}."
        )

    try:
        async with GDBClient.for_instance(instance, trace_id=trace_id) as client:
            catalogs = await client.get("/databases")
            if not isinstance(catalogs, list):
                catalogs = catalogs.get("catalogs", [])

            # code lives on the catalog, not on individual databases
            code_map: dict[str, dict[str, Any]] = {}
            for catalog in catalogs:
                cat_code = catalog.get("code", "")
                if cat_code not in codes:
                    continue
                for db in catalog.get("databases", []):
                    existing = code_map.get(cat_code)
                    db_version = db.get("version", 0)
                    if existing is None or db_version > existing.get(
                        "latest_version", 0
                    ):
                        entry: dict[str, Any] = {
                            "id": db.get("id"),
                            "latest_version": db_version,
                            "is_draft": db.get("is_draft"),
                        }
                        if "last_modified" in include_set:
                            entry["last_modified"] = db.get(
                                "modified_at",
                                db.get("last_modified", db.get("modified")),
                            )
                        if "modified_by" in include_set:
                            audit = _build_audit_info(db)
                            if "modified_by" in audit:
                                entry["modified_by"] = audit["modified_by"]
                        if "schema_hash" in include_set:
                            schema = db.get("schema")
                            if schema:
                                entry["schema_hash"] = (
                                    "sha256:"
                                    + hashlib.sha256(
                                        json.dumps(schema, sort_keys=True).encode()
                                    ).hexdigest()[:16]
                                )
                            else:
                                entry["schema_hash"] = None
                        code_map[cat_code] = entry

            # Fetch row_count if requested (requires per-database API call)
            if "row_count" in include_set:
                for code, entry in code_map.items():
                    try:
                        page = await client.get_page(
                            f"/api/v1/data/{code.lower()}/any",
                            page=1,
                            page_size=1,
                        )
                        entry["row_count"] = page.get("count", 0)
                    except GDBClientError:
                        entry["row_count"] = None

            # Build response: requested codes in order, missing → error
            result: dict[str, Any] = {}
            for code in codes:
                if code in code_map:
                    result[code] = code_map[code]
                else:
                    result[code] = {"error": "not_found"}
            # Underscore prefix to avoid collision with caller-provided database codes
            result["_trace_id"] = client.trace_id

            return result
    except GDBClientError as e:
        raise translate_error(e, resource_type="database batch status") from e


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def gdb_database_get_by_code(
    code: str,
    version: str = "latest",
    trace_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Look up a database by code, returning full schema.

    Avoids paginating gdb_catalog_list (50KB+). version='latest' returns
    the highest published version.

    Args:
        code: Database code (e.g. "proc_proc_1").
        version: Version to retrieve (default: "latest").
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).
        instance: Instance name (default: auto-select).

    Returns:
        dict with id, code, version, schema, catalog info, trace_id.

        No creation audit: GDB's `DatabaseSerializer` does not expose
        `created_at` / `created_by` (tracked upstream:
        UNCTAD-eRegistrations/GDB#5). `modified_at` and `by_user_name`
        reflect the most recent save only.
    """
    try:
        async with GDBClient.for_instance(instance, trace_id=trace_id) as client:
            catalogs = await client.get("/databases")
            if not isinstance(catalogs, list):
                catalogs = catalogs.get("catalogs", [])

            # code lives on the catalog, not on individual databases
            matches: list[dict[str, Any]] = []
            for catalog in catalogs:
                if catalog.get("code") == code:
                    matches.extend(catalog.get("databases", []))

            if not matches:
                raise ToolError(
                    f"No database with code '{code}'. "
                    "Use gdb_catalog_list to discover available databases."
                )

            if version == "latest":
                # Pick the highest published version; fall back to highest draft
                published = [m for m in matches if not m.get("is_draft")]
                pool = published if published else matches
                target = max(pool, key=lambda d: float(d.get("version", 0)))
            else:
                # Find exact version match
                target_matches = [
                    m for m in matches if str(m.get("version")) == version
                ]
                if not target_matches:
                    available = ", ".join(str(m.get("version")) for m in matches)
                    raise ToolError(
                        f"Database '{code}' has no version '{version}'. "
                        f"Available versions: {available}."
                    )
                target = target_matches[0]

            # Fetch full database with schema
            raw: dict[str, Any] = await client.get(f"/database/{target['id']}")
            result = _normalize_get_response(raw)
            result["trace_id"] = client.trace_id
            return result
    except GDBClientError as e:
        raise translate_error(e, resource_type="database", resource_id=code) from e


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def gdb_database_get(
    database_id: int,
    trace_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Get a single database with full JSON Schema.

    Top-level `name` from the API is the parent catalog's name; it is
    surfaced as `catalog_name` for clarity.

    Args:
        database_id: Database ID (integer).
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).
        instance: Instance name (default: auto-select).

    Returns:
        dict with id, code, version, schema, catalog_name, modified_at,
        by_user_name, by_user_auth_id (audit fields from GDB), trace_id.

        No creation audit: GDB's `DatabaseSerializer` does not expose
        `created_at` / `created_by` (tracked upstream:
        UNCTAD-eRegistrations/GDB#5). `modified_at` and `by_user_name`
        reflect the most recent save only.
    """
    try:
        async with GDBClient.for_instance(instance, trace_id=trace_id) as client:
            raw: dict[str, Any] = await client.get(f"/database/{database_id}")
            result = _normalize_get_response(raw)
            result["trace_id"] = client.trace_id
            return result
    except GDBClientError as e:
        raise translate_error(
            e, resource_type="database", resource_id=database_id
        ) from e


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def gdb_database_versions(
    code: str,
    include_schema: bool = False,
    trace_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """List all versions of a database code, ordered by version ASC.

    Returns lightweight version entries by default. Set include_schema=True
    to embed the full JSON Schema per version (costs one extra API call
    per version).

    Args:
        code: Database code to look up.
        include_schema: Embed full schema per version (default: False).
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).
        instance: Instance name (default: auto-select).

    Returns:
        dict with code, count, versions, trace_id. Each version includes audit
        fields (modified_at, modified_by) when GDB returns them.

        The earliest version's `modified_at` is NOT a reliable proxy for
        database creation time. `Database.save()._publishing` re-saves
        the same row to swap versions between drafts, overwriting
        `modified_at`. GDB's `DatabaseSerializer` does not expose
        `created_at` / `created_by` directly (tracked upstream:
        UNCTAD-eRegistrations/GDB#5).
    """
    try:
        async with GDBClient.for_instance(instance, trace_id=trace_id) as client:
            catalogs = await client.get("/databases")
            if not isinstance(catalogs, list):
                catalogs = catalogs.get("catalogs", [])

            # code lives on the catalog, not on individual databases
            versions: list[dict[str, Any]] = []
            for catalog in catalogs:
                if catalog.get("code") != code:
                    continue
                cat_name = catalog.get("name")
                for db in catalog.get("databases", []):
                    entry: dict[str, Any] = {
                        "id": db.get("id"),
                        "uuid": db.get("uuid"),
                        "version": db.get("version"),
                        "is_draft": db.get("is_draft"),
                        "name": db.get("name"),
                        "catalog_name": cat_name,
                    }
                    entry.update(_build_audit_info(db))
                    versions.append(entry)

            if not versions:
                raise ToolError(
                    f"No database found with code '{code}'. "
                    "Use gdb_database_list to discover codes."
                )

            versions.sort(
                key=lambda v: float(v["version"]) if v["version"] is not None else 0.0
            )

            if include_schema:
                for v in versions:
                    detail = await client.get(f"/database/{v['id']}")
                    v["schema"] = detail.get("schema")

            return {
                "code": code,
                "count": len(versions),
                "versions": versions,
                "trace_id": client.trace_id,
            }
    except GDBClientError as e:
        raise translate_error(e, resource_type="database") from e


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def gdb_database_compare(
    first_database_id: int | None = None,
    first_database_code: str | None = None,
    first_database_version: float | None = None,
    second_database_id: int | None = None,
    second_database_code: str | None = None,
    second_database_version: float | None = None,
    trace_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Compare two databases to find field differences.

    Identify by ID or by code+version for each database.

    Args:
        first_database_id: First database ID (use OR code+version).
        first_database_code: First database code (requires version).
        first_database_version: First database version (requires code).
        second_database_id: Second database ID (use OR code+version).
        second_database_code: Second database code (requires version).
        second_database_version: Second database version (requires code).
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).
        instance: Instance name (default: auto-select).

    Returns:
        dict with is_equals, first_database_missing_fields,
        second_database_missing_fields, trace_id.
    """
    # Validate first database params
    has_first_id = first_database_id is not None
    has_first_code = (
        first_database_code is not None and first_database_version is not None
    )
    if not has_first_id and not has_first_code:
        raise ToolError(
            "Provide first_database_id OR "
            "(first_database_code + first_database_version)."
        )

    # Validate second database params
    has_second_id = second_database_id is not None
    has_second_code = (
        second_database_code is not None and second_database_version is not None
    )
    if not has_second_id and not has_second_code:
        raise ToolError(
            "Provide second_database_id OR "
            "(second_database_code + second_database_version)."
        )

    # Build request body
    body: dict[str, Any] = {}
    if has_first_id:
        body["first_database_id"] = first_database_id
    else:
        body["first_database_code"] = first_database_code
        body["first_database_version"] = first_database_version

    if has_second_id:
        body["second_database_id"] = second_database_id
    else:
        body["second_database_code"] = second_database_code
        body["second_database_version"] = second_database_version

    try:
        async with GDBClient.for_instance(instance, trace_id=trace_id) as client:
            result: dict[str, Any] = await client.post(
                "/api/v1/database/compare", data=body
            )
            result["trace_id"] = client.trace_id
            return result
    except GDBClientError as e:
        raise translate_error(e, resource_type="database comparison") from e


def _build_modify_payload(
    *,
    database_id: int | None = None,
    catalog_name: str | None = None,
    code: str | None = None,
    schema: dict[str, Any] | None = None,
    is_draft: bool | None = None,
    number_format: str | None = None,
    name: str | None = None,
    description: str | None = None,
    institution: str | None = None,
    group_id: int | None = None,
    group_name: str | None = None,
    color_hex: str | None = None,
    schema_tags: list[dict[str, Any]] | None = None,
    schema_flags: list[dict[str, Any]] | None = None,
    fields_uniques: list[list[int]] | None = None,
    order_fields: list[str] | None = None,
    indexes: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build the POST /api/v1/database/modify payload.

    Only includes optional fields when they are not None.
    GDB API uses a MIX of snake_case and camelCase (matches frontend Formik form):
    - snake_case: catalog_name, code, name, description, institution, color_hex
    - camelCase: isDraft, numberFormat, schemaTags, schemaFlags
    - snake_case: group_id, group_name, schema, fields_uniques, order_fields
    """
    payload: dict[str, Any] = {}
    _add_optional(payload, "id", database_id)
    _add_optional(payload, "catalog_name", catalog_name)
    _add_optional(payload, "code", code)
    _add_optional(payload, "schema", schema)
    _add_optional(payload, "isDraft", is_draft)
    _add_optional(payload, "numberFormat", number_format)
    _add_optional(payload, "name", name)
    _add_optional(payload, "description", description)
    _add_optional(payload, "institution", institution)
    _add_optional(payload, "group_id", group_id)
    _add_optional(payload, "group_name", group_name)
    _add_optional(payload, "color_hex", color_hex)
    _add_optional(payload, "schemaTags", schema_tags)
    _add_optional(payload, "schemaFlags", schema_flags)
    _add_optional(payload, "fields_uniques", fields_uniques)
    _add_optional(payload, "order_fields", order_fields)
    _add_optional(payload, "indexes", indexes)
    return payload


@mcp.tool()
async def gdb_database_create(
    catalog_name: str,
    code: str,
    schema: dict[str, Any],
    is_draft: bool = True,
    number_format: str = "{code}{indexNoByCode}",
    name: str | None = None,
    description: str | None = None,
    institution: str | None = None,
    group_id: int | None = None,
    group_name: str | None = None,
    color_hex: str | None = None,
    schema_tags: list[dict[str, Any]] | None = None,
    schema_flags: list[dict[str, Any]] | None = None,
    fields_uniques: list[list[int]] | None = None,
    order_fields: list[str] | None = None,
    indexes: dict[str, Any] | None = None,
    dry_run: bool = False,
    create_catalog_if_missing: bool = False,
    trace_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Create a new GDB database (or auto-version an existing code).

    If a database with the given code already exists, GDB creates a new
    incremental version (1 → 1.1 → 1.2); old versions and data are
    preserved. Use gdb_database_upsert for explicit version tracking.
    group_id and group_name are mutually exclusive.

    catalog_name must exactly match an existing catalog by default — a
    typo or case mismatch raises ToolError with close matches. Set
    create_catalog_if_missing=True to restore the historical find-or-create
    behavior (backend silently creates a new catalog for unknown names).

    Args:
        catalog_name: Catalog name for the database (must exist unless
            create_catalog_if_missing is True).
        code: Database code (new version created if code exists)
        schema: JSON Schema defining the database fields.
        is_draft: Create as draft (default: True).
        number_format: Number format pattern (default: "{code}{indexNoByCode}").
        name: Human-readable name.
        description: Database description.
        institution: Institution name.
        group_id: Existing group ID (mutually exclusive with group_name).
        group_name: New group name (mutually exclusive with group_id).
        color_hex: Color hex code.
        schema_tags: Tag definitions for database fields.
        schema_flags: Flag definitions for database fields.
        fields_uniques: Unique constraint groups (list of field index lists).
        order_fields: Field names used for default ordering.
        indexes: Index definitions for the database.
        dry_run: If True, simulate without persisting (default: False).
        create_catalog_if_missing: If True, allow the backend to silently
            create a new catalog when catalog_name has no exact match.
            Default False — unknown names fail fast to prevent typo-driven
            duplicate catalogs.
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).
        instance: Instance name (default: auto-select).

    Returns:
        dict with id, database_code, catalog_id, group_id, trace_id. When dry_run,
        returns dry_run, would_create, would_new_version, new_version,
        diff, schema_hash, payload, validation_errors, trace_id.
    """
    if group_id is not None and group_name is not None:
        raise ToolError(
            "group_id and group_name are mutually exclusive. "
            "Use group_id to assign to an existing group, "
            "or group_name to create a new group."
        )

    payload = _build_modify_payload(
        catalog_name=catalog_name,
        code=code,
        schema=schema,
        is_draft=is_draft,
        number_format=number_format,
        name=name,
        description=description,
        institution=institution,
        group_id=group_id,
        group_name=group_name,
        color_hex=color_hex,
        schema_tags=schema_tags,
        schema_flags=schema_flags,
        fields_uniques=fields_uniques,
        order_fields=order_fields,
        indexes=indexes,
    )

    try:
        async with GDBClient.for_instance(instance, trace_id=trace_id) as client:
            # Dry-run is a pure simulation — skip the pre-write catalog
            # check to avoid an extra GET and to avoid blocking callers
            # who use dry_run precisely to discover what would happen.
            if not create_catalog_if_missing and not dry_run:
                raw_catalogs = await client.get("/databases")
                if isinstance(raw_catalogs, list):
                    catalogs = raw_catalogs
                elif isinstance(raw_catalogs, dict) and isinstance(
                    raw_catalogs.get("catalogs"), list
                ):
                    catalogs = raw_catalogs["catalogs"]
                else:
                    catalogs = []
                _verify_catalog_exists(catalogs, catalog_name)

            if dry_run:
                sim = await _simulate_modify(
                    client,
                    database_id=None,
                    code=code,
                    schema=schema,
                    payload=payload,
                )
                sim["trace_id"] = client.trace_id
                return sim
            raw: dict[str, Any] = await client.post(
                "/api/v1/database/modify", data=payload
            )
            normalized = _normalize_modify_response(raw)
            normalized["trace_id"] = client.trace_id
            return normalized
    except GDBClientError as e:
        raise translate_error(e, resource_type="database") from e


@mcp.tool()
async def gdb_database_update(
    database_id: int,
    schema: dict[str, Any] | None = None,
    catalog_name: str | None = None,
    code: str | None = None,
    is_draft: bool | None = None,
    number_format: str | None = None,
    name: str | None = None,
    description: str | None = None,
    institution: str | None = None,
    group_id: int | None = None,
    group_name: str | None = None,
    color_hex: str | None = None,
    schema_tags: list[dict[str, Any]] | None = None,
    schema_flags: list[dict[str, Any]] | None = None,
    fields_uniques: list[list[int]] | None = None,
    order_fields: list[str] | None = None,
    indexes: dict[str, Any] | None = None,
    dry_run: bool = False,
    skip_if_unchanged: bool = False,
    trace_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Update an existing draft GDB database (in-place, no new version).

    Only draft databases can be updated in place. Uses the same
    POST /api/v1/database/modify endpoint but with the database ID set.
    group_id and group_name are mutually exclusive.

    Partial updates are supported: GDB's /modify endpoint requires
    catalog_name + code + schema on every call, but if you omit any of
    them this tool pre-fetches the database once and fills them in with
    the current values. Fields you DO pass always win.

    Args:
        database_id: Database ID to update.
        schema: Updated JSON Schema (omit to keep current schema).
        catalog_name: Catalog name (omit to keep current catalog).
        code: Database code (omit to keep current code).
        is_draft: Draft status.
        number_format: Number format pattern.
        name: Human-readable name.
        description: Database description.
        institution: Institution name.
        group_id: Existing group ID (mutually exclusive with group_name).
        group_name: New group name (mutually exclusive with group_id).
        color_hex: Color hex code.
        schema_tags: Tag definitions for database fields.
        schema_flags: Flag definitions for database fields.
        fields_uniques: Unique constraint groups (list of field index lists).
        order_fields: Field names used for default ordering.
        indexes: Index definitions for the database.
        dry_run: If True, simulate without persisting (default: False).
        skip_if_unchanged: If True and this call promotes a draft to
            published (is_draft=False) and schema matches the currently
            published version for the same code, skip the POST and
            return unchanged=True. The draft is preserved (draft_preserved=True
            in response) — caller can delete it if desired (default: False).
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).
        instance: Instance name (default: auto-select).

    Returns:
        dict with id, database_code, catalog_id, group_id, trace_id.
        When skip_if_unchanged triggers on draft→publish, returns
        unchanged=True with draft_preserved=True and draft_id.
        When dry_run, returns dry_run, would_create, would_new_version,
        would_skip_if_unchanged, current_version, diff, schema_hash,
        payload, validation_errors, trace_id.
    """
    if group_id is not None and group_name is not None:
        raise ToolError(
            "group_id and group_name are mutually exclusive. "
            "Use group_id to assign to an existing group, "
            "or group_name to create a new group."
        )

    try:
        async with GDBClient.for_instance(instance, trace_id=trace_id) as client:
            # GDB /modify demands catalog_name+code+schema on every call. If
            # the caller omitted any, pre-fetch the DB once and fill in the
            # gaps. Caller-supplied values always win. The prefetched dict
            # is reused below by skip_if_unchanged (and by _simulate_modify
            # in dry_run) to avoid a second GET on the same record.
            #
            # allow_missing=dry_run: for dry-runs against a non-existent id
            # we want the simulator to report would_create=True instead of
            # a hard "database not found" error.
            (
                resolved_catalog,
                resolved_code,
                resolved_schema,
                prefetched,
            ) = await _ensure_modify_required_fields(
                client,
                database_id=database_id,
                catalog_name=catalog_name,
                code=code,
                schema=schema,
                allow_missing=dry_run,
            )

            payload = _build_modify_payload(
                database_id=database_id,
                catalog_name=resolved_catalog,
                code=resolved_code,
                schema=resolved_schema,
                is_draft=is_draft,
                number_format=number_format,
                name=name,
                description=description,
                institution=institution,
                group_id=group_id,
                group_name=group_name,
                color_hex=color_hex,
                schema_tags=schema_tags,
                schema_flags=schema_flags,
                fields_uniques=fields_uniques,
                order_fields=order_fields,
                indexes=indexes,
            )

            if dry_run:
                sim = await _simulate_modify(
                    client,
                    database_id=database_id,
                    code=resolved_code,
                    schema=resolved_schema,
                    payload=payload,
                    prefetched_db=prefetched,
                )
                sim["trace_id"] = client.trace_id
                return sim

            # Dedup guard: only fires on draft→publish transition (is_draft=False)
            # when schema matches the currently-published version for the same code.
            # Draft is preserved on skip; caller handles cleanup. Reuses `resolved_code`
            # (may have come from the pre-fetch above, so no extra GET here).
            if skip_if_unchanged and is_draft is False and resolved_schema:
                if resolved_code:
                    match = await _resolve_latest_published_for_code(
                        client, resolved_code
                    )
                    if (
                        match is not None
                        and match.get("id") != database_id
                        and (_schemas_match(resolved_schema, match.get("schema")))
                    ):
                        return _build_unchanged_response(
                            match,
                            incoming_schema=resolved_schema,
                            trace_id=client.trace_id,
                            draft_preserved=True,
                            draft_id=database_id,
                        )

            raw: dict[str, Any] = await client.post(
                "/api/v1/database/modify", data=payload
            )
            normalized = _normalize_modify_response(raw)
            normalized["trace_id"] = client.trace_id
            if skip_if_unchanged:
                normalized["unchanged"] = False
                normalized["schema_hash"] = _compute_schema_hash(resolved_schema)
            return normalized
    except GDBClientError as e:
        raise translate_error(
            e, resource_type="database", resource_id=database_id
        ) from e


_GENERIC_SERVICES_LIMITATION = (
    "Backend /edit does not copy generic_services to the draft; "
    "empty on draft until publish. Tracked upstream in GDB repo."
)


@mcp.tool()
async def gdb_database_edit(
    database_id: int,
    trace_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Create an editable draft from a published database.

    The upstream backend /edit endpoint does not re-parent schema_tags
    or schema_flags to the new draft. This tool works around that by
    fetching the source and posting /modify with schemaTags and
    schemaFlags after /edit returns.

    generic_services CANNOT be restored from MCP (no /modify payload
    field for generic_services on existing drafts). Drafts will have
    empty generic_services until the draft is published. Tracked
    upstream.

    Args:
        database_id: Source (published) database ID to create a draft from.
        trace_id: Optional trace ID for log correlation.
        instance: Instance name (default: auto-select).

    Returns:
        dict with id (new draft), trace_id, schema_tags_restored,
        schema_flags_restored, metadata_restoration, and
        generic_services_limitation. Call gdb_database_get(id) for
        full draft state.
    """
    try:
        async with GDBClient.for_instance(instance, trace_id=trace_id) as client:
            # 1. Pre-fetch source to capture metadata before /edit runs.
            source: dict[str, Any] = await client.get(f"/database/{database_id}")

            # 2. Create the draft via the backend /edit endpoint.
            edit_resp: dict[str, Any] = await client.post(
                f"/api/v1/database/{database_id}/edit", data={}
            )
            new_id = edit_resp.get("id")

            source_tags = source.get("schema_tags") or []
            source_flags = source.get("schema_flags") or []

            result: dict[str, Any] = {
                "id": new_id,
                "trace_id": client.trace_id,
                "schema_tags_restored": 0,
                "schema_flags_restored": 0,
                "metadata_restoration": "skipped_no_metadata",
                "generic_services_limitation": _GENERIC_SERVICES_LIMITATION,
            }

            # Guard: if /edit response lacks an id, we cannot target /modify.
            # Return what we have rather than fail the whole tool.
            if new_id is None:
                result["metadata_restoration"] = "skipped_no_draft_id"
                return result

            # 3. If there's metadata to restore, call /modify on the new draft.
            if not source_tags and not source_flags:
                return result

            modify_payload: dict[str, Any] = {
                "id": new_id,
                "code": source.get("code"),
                "catalog_name": source.get("catalog_name") or source.get("name"),
                "schema": source.get("schema") or {},
            }
            if source_tags:
                modify_payload["schemaTags"] = _tags_for_modify_payload(source_tags)
            if source_flags:
                modify_payload["schemaFlags"] = _tags_for_modify_payload(source_flags)

            try:
                await client.post("/api/v1/database/modify", data=modify_payload)
                result["schema_tags_restored"] = len(source_tags)
                result["schema_flags_restored"] = len(source_flags)
                result["metadata_restoration"] = "ok"
            except GDBClientError as e:
                # Draft exists and is usable; surface failure via response key
                # rather than masking the successful /edit.
                result["metadata_restoration"] = f"partial_failure: {e}"

            return result
    except GDBClientError as e:
        raise translate_error(
            e, resource_type="database", resource_id=database_id
        ) from e


@mcp.tool()
async def gdb_database_publish(
    database_id: int,
    trace_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Publish a draft database (makes it immutable and usable by services).

    Only draft databases can be published. Once published, the schema is
    locked and data views/services can reference it. Fetches current state
    first since /modify requires catalog_name, code, and schema.

    Args:
        database_id: Draft database ID to publish.
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).
        instance: Instance name (default: auto-select).

    Returns:
        dict with id, database_code, catalog_id, trace_id.
    """
    try:
        async with GDBClient.for_instance(instance, trace_id=trace_id) as client:
            # /modify requires catalog_name, code, schema on every call.
            # GET /database/{id} returns name + code at top level (= catalog fields).
            db: dict[str, Any] = await client.get(f"/database/{database_id}")
            if not db.get("is_draft"):
                raise ToolError(f"Database {database_id} is already published.")
            payload = _build_modify_payload(
                database_id=database_id,
                catalog_name=db["name"],
                code=db["code"],
                schema=db["schema"],
                is_draft=False,
            )
            raw: dict[str, Any] = await client.post(
                "/api/v1/database/modify", data=payload
            )
            normalized = _normalize_modify_response(raw)
            normalized["trace_id"] = client.trace_id
            return normalized
    except GDBClientError as e:
        raise translate_error(
            e, resource_type="database", resource_id=database_id
        ) from e


@mcp.tool()
async def gdb_database_unpublish(
    database_id: int,
    trace_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Revert a published database to draft (unpublish).

    Data and schema are preserved. Use when a database is orphaned
    (e.g. upstream procedure deleted) and should no longer be live.

    Args:
        database_id: Published database ID to unpublish.
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).
        instance: Instance name (default: auto-select).

    Returns:
        dict with id, catalog_id, catalog_code, trace_id.
    """
    try:
        async with GDBClient.for_instance(instance, trace_id=trace_id) as client:
            db: dict[str, Any] = await client.get(f"/database/{database_id}")
            if db.get("is_draft"):
                raise ToolError(f"Database {database_id} is already a draft.")
            payload = _build_modify_payload(
                database_id=database_id,
                catalog_name=db["name"],
                code=db["code"],
                schema=db["schema"],
                is_draft=True,
            )
            result: dict[str, Any] = await client.post(
                "/api/v1/database/modify", data=payload
            )
            result["trace_id"] = client.trace_id
            return result
    except GDBClientError as e:
        raise translate_error(
            e, resource_type="database", resource_id=database_id
        ) from e


@mcp.tool()
async def gdb_database_delete(
    database_id: int | None = None,
    database_uuid: str | None = None,
    trace_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Delete a GDB database by ID or UUID.

    Provide database_id (int) or database_uuid (str) — at least one required.
    When only database_id is given, resolves the UUID via GET first.

    Args:
        database_id: Database ID (resolves UUID automatically).
        database_uuid: Database UUID (used directly).
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).
        instance: Instance name (default: auto-select).

    Returns:
        dict with deleted, database_id, database_uuid, trace_id.
    """
    if database_id is None and database_uuid is None:
        raise ToolError(
            "Provide database_id (int) or database_uuid (str). "
            "At least one is required."
        )

    try:
        async with GDBClient.for_instance(instance, trace_id=trace_id) as client:
            # Resolve UUID from ID if needed
            if database_uuid is None:
                db: dict[str, Any] = await client.get(f"/database/{database_id}")
                database_uuid = db.get("uuid")
                if not database_uuid:
                    raise ToolError(
                        f"Database {database_id} has no UUID. "
                        "Cannot delete without a UUID."
                    )

            await client.delete(f"/api/v1/database/{database_uuid}")
            result: dict[str, Any] = {
                "deleted": True,
                "database_uuid": database_uuid,
                "trace_id": client.trace_id,
            }
            if database_id is not None:
                result["database_id"] = database_id
            return result
    except GDBClientError as e:
        resource_id = database_id if database_id is not None else database_uuid
        raise translate_error(
            e, resource_type="database", resource_id=resource_id
        ) from e


@mcp.tool()
async def gdb_database_duplicate(
    database_id: int,
    copy_data: bool = False,
    trace_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Duplicate a GDB database.

    Args:
        database_id: Database ID to duplicate.
        copy_data: Whether to copy data rows (default: False).
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).
        instance: Instance name (default: auto-select).

    Returns:
        dict with id, database_code, catalog_id,
        catalog_data_index_increment, group_id, trace_id.
    """
    try:
        async with GDBClient.for_instance(instance, trace_id=trace_id) as client:
            raw: dict[str, Any] = await client.post(
                f"/api/v1/database/{database_id}/duplicate",
                data={"copyData": copy_data},
            )
            normalized = _normalize_modify_response(raw)
            normalized["trace_id"] = client.trace_id
            return normalized
    except GDBClientError as e:
        raise translate_error(
            e, resource_type="database", resource_id=database_id
        ) from e


_RENAME_BATCH_SIZE = 500


@mcp.tool()
async def gdb_database_rename_column(
    database_id: int,
    old_name: str,
    new_name: str,
    trace_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Rename a column in a draft schema and migrate data records.

    Updates the JSON Schema property name on the draft, then migrates
    the key in data records attached to the parent catalog's latest
    published version. If the catalog has no published version, the
    schema rename still applies and rows_migrated is 0.

    Idempotent on retry: records already renamed are skipped by the
    "old_name in content" filter.

    If any record contains BOTH old_name and new_name, the tool stops
    with an error rather than overwrite existing data.

    Args:
        database_id: Draft database ID.
        old_name: Current column/property name.
        new_name: New column/property name.
        trace_id: Optional trace ID for log correlation.
        instance: Instance name (default: auto-select).

    Returns:
        dict with renamed, old_name, new_name, rows_migrated,
        published_version (str or None), trace_id.
    """
    if old_name == new_name:
        raise ToolError("old_name and new_name must be different.")

    try:
        async with GDBClient.for_instance(instance, trace_id=trace_id) as client:
            # 1. Fetch draft and validate
            db: dict[str, Any] = await client.get(f"/database/{database_id}")
            if not db.get("is_draft"):
                raise ToolError(
                    f"Database {database_id} is published. "
                    "Call gdb_database_edit first to create a draft."
                )

            schema = db.get("schema", {})
            properties = schema.get("properties", {})
            if old_name not in properties:
                available = ", ".join(sorted(properties.keys()))
                raise ToolError(
                    f"Column '{old_name}' not found in schema. Available: {available}."
                )
            if new_name in properties:
                raise ToolError(f"Column '{new_name}' already exists in schema.")

            # 2. Rename property in schema
            new_properties: dict[str, Any] = {}
            for key, value in properties.items():
                new_properties[new_name if key == old_name else key] = value
            schema["properties"] = new_properties

            required = schema.get("required", [])
            if old_name in required:
                schema["required"] = [
                    new_name if r == old_name else r for r in required
                ]

            # 3. Update draft schema on the backend
            payload = _build_modify_payload(
                database_id=database_id,
                catalog_name=db["name"],
                code=db["code"],
                schema=schema,
            )
            await client.post("/api/v1/database/modify", data=payload)

            # 4. Resolve latest published version in the parent catalog.
            # Data rows FK to a specific Database version and the /data/{code}/{version}
            # endpoint only resolves to published rows (is_draft=False). Migrating under
            # the draft's own version would always 404 -> 0 rows, which is exactly the
            # bug fixed here (issue #78).
            code = db["code"]
            published = await _resolve_latest_published_for_code(client, code)
            if published is None:
                return {
                    "renamed": True,
                    "old_name": old_name,
                    "new_name": new_name,
                    "rows_migrated": 0,
                    "published_version": None,
                    "trace_id": client.trace_id,
                }

            raw_version = published.get("version")
            if raw_version is None:
                raise ToolError(
                    "Parent catalog's latest published version has no "
                    "version value; cannot migrate data. This suggests a "
                    "malformed GDB state — contact support."
                )
            published_version = str(raw_version)
            rows_migrated = 0
            page = 1
            while True:
                page_data = await client.get_page(
                    f"/api/v1/data/{code.lower()}/{published_version}",
                    page=page,
                    page_size=_RENAME_BATCH_SIZE,
                )
                results = page_data.get("results", [])
                if not results:
                    break

                # Collision detection: refuse if any record has BOTH keys.
                collisions = [
                    r["id"]
                    for r in results
                    if old_name in r.get("content", {})
                    and new_name in r.get("content", {})
                ]
                if collisions:
                    raise ToolError(
                        f"Data migration aborted: {len(collisions)} record(s) "
                        f"contain both '{old_name}' and '{new_name}' — renaming "
                        "would overwrite existing values. Affected record ids: "
                        f"{collisions}. Schema rename has been applied; resolve "
                        "collisions manually, then re-run this tool."
                    )

                # Build update batch
                to_update_queries: list[dict[str, Any]] = []
                to_update_records: list[dict[str, Any]] = []
                for record in results:
                    content = record.get("content", {})
                    if old_name in content:
                        new_content = {}
                        for k, v in content.items():
                            new_content[new_name if k == old_name else k] = v
                        to_update_queries.append({"id": record["id"]})
                        to_update_records.append(new_content)

                if to_update_queries:
                    await client.put(
                        f"/data/{code.lower()}/{published_version}/update-entries",
                        data={
                            "query": to_update_queries,
                            "write": [{"content": rec} for rec in to_update_records],
                        },
                    )
                    rows_migrated += len(to_update_queries)

                if not page_data.get("has_next"):
                    break
                page += 1

            return {
                "renamed": True,
                "old_name": old_name,
                "new_name": new_name,
                "rows_migrated": rows_migrated,
                "published_version": published_version,
                "trace_id": client.trace_id,
            }
    except GDBClientError as e:
        raise translate_error(
            e, resource_type="database", resource_id=database_id
        ) from e


@mcp.tool()
async def gdb_database_upsert(
    catalog_name: str,
    code: str,
    schema: dict[str, Any],
    is_draft: bool = True,
    number_format: str = "{code}{indexNoByCode}",
    name: str | None = None,
    description: str | None = None,
    institution: str | None = None,
    group_id: int | None = None,
    group_name: str | None = None,
    color_hex: str | None = None,
    schema_tags: list[dict[str, Any]] | None = None,
    schema_flags: list[dict[str, Any]] | None = None,
    fields_uniques: list[list[int]] | None = None,
    order_fields: list[str] | None = None,
    indexes: dict[str, Any] | None = None,
    dry_run: bool = False,
    skip_if_unchanged: bool = False,
    create_catalog_if_missing: bool = False,
    trace_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Create or auto-version a GDB database.

    If code exists, GDB creates a new version (1 → 1.1 → 1.2);
    old versions and data are preserved. Returns is_new_version flag.

    catalog_name must exactly match an existing catalog by default — a
    typo or case mismatch raises ToolError with close matches. Set
    create_catalog_if_missing=True to allow the backend to silently
    create a new catalog for unknown names.

    Args:
        catalog_name: Catalog name for the database (must exist unless
            create_catalog_if_missing is True).
        code: Database code (auto-versions if already exists).
        schema: JSON Schema defining the database fields.
        is_draft: Create as draft (default: True).
        number_format: Number format (default: "{code}{indexNoByCode}").
        name: Human-readable name.
        description: Database description.
        institution: Institution name.
        group_id: Existing group ID (mutually exclusive with group_name).
        group_name: New group name (mutually exclusive with group_id).
        color_hex: Color hex code.
        schema_tags: Tag definitions.
        schema_flags: Flag definitions.
        fields_uniques: Unique constraint groups.
        order_fields: Default ordering fields.
        indexes: Index definitions.
        dry_run: If True, simulate without persisting (default: False).
        skip_if_unchanged: If True and is_draft=False and schema hashes
            match the latest published version for this code, skip the
            POST and return unchanged=True. Schema-only comparison;
            best-effort under concurrent writes (default: False).
        create_catalog_if_missing: If True, allow the backend to silently
            create a new catalog when catalog_name has no exact match.
            Default False — unknown names fail fast to prevent typo-driven
            duplicate catalogs.
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).
        instance: Instance name (default: auto-select).

    Returns:
        dict with id, version, is_new_version, trace_id, plus API fields.
        When skip_if_unchanged triggers, returns unchanged=True with
        id, version, catalog_id, catalog_code, schema_hash, compared_against.
        When dry_run, returns dry_run, would_create, would_new_version,
        would_skip_if_unchanged, new_version, diff, schema_hash, payload,
        validation_errors, trace_id.
    """
    if group_id is not None and group_name is not None:
        raise ToolError(
            "group_id and group_name are mutually exclusive. "
            "Use group_id to assign to an existing group, "
            "or group_name to create a new group."
        )

    try:
        async with GDBClient.for_instance(instance, trace_id=trace_id) as client:
            # Check if code already exists to determine is_new_version.
            # Reuses the same /databases fetch for the catalog-name check
            # below so we only pay one GET.
            catalogs = await client.get("/databases")
            if not isinstance(catalogs, list):
                catalogs = catalogs.get("catalogs", [])

            # Dry-run is a pure simulation — skip the catalog check so it
            # doesn't block callers using dry_run to discover what would
            # happen with a new catalog name.
            if not create_catalog_if_missing and not dry_run:
                _verify_catalog_exists(catalogs, catalog_name)

            # code lives on the catalog, not on individual databases
            code_exists = any(catalog.get("code") == code for catalog in catalogs)

            payload = _build_modify_payload(
                catalog_name=catalog_name,
                code=code,
                schema=schema,
                is_draft=is_draft,
                number_format=number_format,
                name=name,
                description=description,
                institution=institution,
                group_id=group_id,
                group_name=group_name,
                color_hex=color_hex,
                schema_tags=schema_tags,
                schema_flags=schema_flags,
                fields_uniques=fields_uniques,
                order_fields=order_fields,
                indexes=indexes,
            )

            if dry_run:
                simulated = await _simulate_modify(
                    client,
                    database_id=None,
                    code=code,
                    schema=schema,
                    payload=payload,
                )
                simulated["is_new_version"] = code_exists
                simulated["trace_id"] = client.trace_id
                return simulated

            # Dedup guard: only fires when explicitly requested AND we'd
            # be creating a new published version (is_draft=False, code
            # exists, schema non-empty). Drafts bypass — they don't
            # create version rows in the same way.
            if skip_if_unchanged and not is_draft and schema and code_exists:
                match = await _resolve_latest_published_for_code(client, code)
                if match is not None and _schemas_match(schema, match.get("schema")):
                    return _build_unchanged_response(
                        match,
                        incoming_schema=schema,
                        trace_id=client.trace_id,
                    )

            result: dict[str, Any] = await client.post(
                "/api/v1/database/modify", data=payload
            )
            result["is_new_version"] = code_exists
            result["trace_id"] = client.trace_id
            if skip_if_unchanged:
                result["unchanged"] = False
                result["schema_hash"] = _compute_schema_hash(schema)
            return result
    except GDBClientError as e:
        raise translate_error(e, resource_type="database") from e
