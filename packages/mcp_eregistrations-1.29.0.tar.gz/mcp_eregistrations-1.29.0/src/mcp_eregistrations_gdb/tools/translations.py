"""GDB translation tools — config, list, modify, add/delete language, publish."""

from __future__ import annotations

from typing import Any

from fastmcp.exceptions import ToolError
from mcp.types import ToolAnnotations

from mcp_eregistrations_gdb.gdb_client import GDBClient, GDBClientError, translate_error
from mcp_eregistrations_gdb.server import mcp
from mcp_eregistrations_gdb.tools import _add_optional


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def gdb_translation_config(
    trace_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Get translation service configuration.

    Args:
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).
        instance: Instance name (default: auto-select).

    Returns:
        dict with translation_service_enabled, trace_id.
    """
    try:
        async with GDBClient.for_instance(instance, trace_id=trace_id) as client:
            result: dict[str, Any] = await client.get("/api/v1/translations/config")
            result["trace_id"] = client.trace_id
            return result
    except GDBClientError as e:
        raise translate_error(e, resource_type="translation config") from e


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def gdb_translation_list(
    trace_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """List all translations (languages and messages).

    Args:
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).
        instance: Instance name (default: auto-select).

    Returns:
        dict with languages (list of code, name), message_count, trace_id.
    """
    try:
        async with GDBClient.for_instance(instance, trace_id=trace_id) as client:
            result: dict[str, Any] = await client.get("/api/v1/translations")
            effective_trace_id = client.trace_id
    except GDBClientError as e:
        raise translate_error(e, resource_type="translation") from e

    raw_languages = result.get("languages", {})
    messages = result.get("messages", {})
    # Languages may be a dict keyed by code or a list of objects
    if isinstance(raw_languages, dict):
        languages = [
            {"code": code, "name": info.get("name") if isinstance(info, dict) else info}
            for code, info in raw_languages.items()
        ]
    else:
        languages = [
            {"code": lang.get("code"), "name": lang.get("name")}
            for lang in raw_languages
        ]
    return {
        "languages": languages,
        "message_count": len(messages) if isinstance(messages, dict) else 0,
        "trace_id": effective_trace_id,
    }


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=False))
async def gdb_translation_modify(
    language_code: str,
    key: str,
    value: str,
    database_catalog_id: int | None = None,
    database_catalog_group_id: int | None = None,
    data_view_catalog_id: int | None = None,
    catalog_field_id: int | None = None,
    trace_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Modify a translation entry. Audited write operation.

    Args:
        language_code: Language code (e.g., "es", "fr").
        key: Translation key.
        value: Translation value.
        database_catalog_id: Scope to catalog (exclusive with other scope params).
        database_catalog_group_id: Scope to group (exclusive with other scope params).
        data_view_catalog_id: Scope to data view (exclusive with other scope params).
        catalog_field_id: Further scope to a field within a catalog.
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).
        instance: Instance name (default: auto-select).

    Returns:
        dict with result and trace_id.
    """
    # Validate mutual exclusivity of scope params
    scope_params = [
        database_catalog_id,
        database_catalog_group_id,
        data_view_catalog_id,
    ]
    if sum(p is not None for p in scope_params) > 1:
        raise ToolError(
            "Only one scope parameter allowed: database_catalog_id, "
            "database_catalog_group_id, or data_view_catalog_id"
        )

    try:
        async with GDBClient.for_instance(instance, trace_id=trace_id) as client:
            body: dict[str, Any] = {"key": key, "value": value}
            _add_optional(body, "databaseCatalogId", database_catalog_id)
            _add_optional(body, "databaseCatalogGroupId", database_catalog_group_id)
            _add_optional(body, "dataViewCatalogId", data_view_catalog_id)
            _add_optional(body, "catalogFieldId", catalog_field_id)
            result: dict[str, Any] = await client.post(
                f"/api/v1/translation/{language_code}/modify",
                data=body,
            )
            result["trace_id"] = client.trace_id
            return result
    except GDBClientError as e:
        raise translate_error(e, resource_type="translation") from e


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=False))
async def gdb_translation_add_language(
    language_code: str,
    trace_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Add a new language for translations. Audited write operation.

    Args:
        language_code: Language code to add (e.g., "fr", "de").
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).
        instance: Instance name (default: auto-select).

    Returns:
        dict with added language details and trace_id.
    """
    try:
        async with GDBClient.for_instance(instance, trace_id=trace_id) as client:
            result: dict[str, Any] = await client.post(
                f"/api/v1/translation/{language_code}/add-language",
                data={},
            )
            result["trace_id"] = client.trace_id
            return result
    except GDBClientError as e:
        raise translate_error(e, resource_type="translation") from e


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=False))
async def gdb_translation_publish(
    language_code: str,
    trace_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Publish translations for a single language. Audited write operation.

    Args:
        language_code: Language code to publish (e.g., "es").
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).
        instance: Instance name (default: auto-select).

    Returns:
        dict with publish result and trace_id.
    """
    try:
        async with GDBClient.for_instance(instance, trace_id=trace_id) as client:
            result: dict[str, Any] = await client.post(
                f"/api/v1/translation/{language_code}/publish",
                data={},
            )
            result["trace_id"] = client.trace_id
            return result
    except GDBClientError as e:
        raise translate_error(e, resource_type="translation") from e


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=False))
async def gdb_translation_publish_all(
    trace_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Publish translations for all languages. Audited write operation.

    Args:
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).
        instance: Instance name (default: auto-select).

    Returns:
        dict with publish result and trace_id.
    """
    try:
        async with GDBClient.for_instance(instance, trace_id=trace_id) as client:
            result: dict[str, Any] = await client.post(
                "/api/v1/translations/publish",
                data={},
            )
            result["trace_id"] = client.trace_id
            return result
    except GDBClientError as e:
        raise translate_error(e, resource_type="translation") from e


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=False))
async def gdb_translation_delete(
    language_code: str,
    trace_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Delete a language from translations. Audited write operation.

    Args:
        language_code: Language code to delete.
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).
        instance: Instance name (default: auto-select).

    Returns:
        dict with deleted (bool), language_code, trace_id.
    """
    try:
        async with GDBClient.for_instance(instance, trace_id=trace_id) as client:
            await client.delete(f"/api/v1/translation/{language_code}")
            return {
                "deleted": True,
                "language_code": language_code,
                "trace_id": client.trace_id,
            }
    except GDBClientError as e:
        raise translate_error(e, resource_type="translation") from e
