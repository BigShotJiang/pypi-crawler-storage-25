"""GDB catalog tools — list, delete, move."""

from __future__ import annotations

from typing import Any

from mcp.types import ToolAnnotations

from mcp_eregistrations_gdb.gdb_client import GDBClient, GDBClientError, translate_error
from mcp_eregistrations_gdb.server import mcp


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def gdb_catalog_list(
    name_contains: str | None = None,
    code_contains: str | None = None,
    page: int = 1,
    page_size: int = 50,
    include_databases: bool = True,
    trace_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """List database catalogs with optional filtering and pagination.

    Args:
        name_contains: Filter catalogs whose name contains this (case-insensitive).
        code_contains: Filter catalogs whose code contains this (case-insensitive).
        page: Page number (default: 1).
        page_size: Results per page (default: 50, max: 200).
        include_databases: Include nested databases array (default: True).
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).
        instance: Instance name (default: auto-select).

    Returns:
        dict with total_count, page, page_size, has_next, catalogs, trace_id.

        Embedded `catalogs[].databases[]` entries carry `modified_at` /
        `by_user_name` (last-save audit) but NOT `created_at` /
        `created_by` — GDB's `DatabaseSerializer` does not expose those
        (tracked upstream: UNCTAD-eRegistrations/GDB#5).
    """
    page_size = min(page_size, 200)
    try:
        async with GDBClient.for_instance(instance, trace_id=trace_id) as client:
            data = await client.get("/databases")
            if not isinstance(data, list):
                data = data.get("catalogs", [])

            # Client-side filtering
            filtered = data
            if name_contains:
                needle = name_contains.lower()
                filtered = [
                    c for c in filtered if needle in (c.get("name") or "").lower()
                ]
            if code_contains:
                needle = code_contains.lower()
                filtered = [
                    c for c in filtered if needle in (c.get("code") or "").lower()
                ]

            total_count = len(filtered)

            # Client-side pagination
            start = (page - 1) * page_size
            page_items = filtered[start : start + page_size]
            has_next = (start + page_size) < total_count

            catalogs = []
            for cat in page_items:
                entry: dict[str, Any] = {
                    "id": cat.get("id"),
                    "code": cat.get("code"),
                    "name": cat.get("name"),
                    "order": cat.get("order"),
                    "group_id": cat.get("group_id"),
                    "database_count": len(cat.get("databases", [])),
                }
                if include_databases:
                    entry["databases"] = [
                        {
                            "id": db.get("id"),
                            "version": db.get("version"),
                            "is_draft": db.get("is_draft"),
                        }
                        for db in cat.get("databases", [])
                    ]
                catalogs.append(entry)
            return {
                "total_count": total_count,
                "page": page,
                "page_size": page_size,
                "has_next": has_next,
                "catalogs": catalogs,
                "trace_id": client.trace_id,
            }
    except GDBClientError as e:
        raise translate_error(e, resource_type="catalog") from e


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=False))
async def gdb_catalog_delete(
    catalog_id: int,
    trace_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Delete a database catalog by ID.

    Args:
        catalog_id: Integer ID of the catalog to delete.
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).
        instance: Instance name (default: auto-select).

    Returns:
        dict with deleted (bool), catalog_id, trace_id.
    """
    try:
        async with GDBClient.for_instance(instance, trace_id=trace_id) as client:
            await client.delete(f"/api/v1/database-catalog/{catalog_id}")
            return {
                "deleted": True,
                "catalog_id": catalog_id,
                "trace_id": client.trace_id,
            }
    except GDBClientError as e:
        raise translate_error(e, resource_type="catalog", resource_id=catalog_id) from e


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=False))
async def gdb_catalog_move(
    catalog_id: int,
    index: int,
    group_id: int | None = None,
    trace_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Move a catalog to a new position (and optionally into a group).

    Args:
        catalog_id: Integer ID of the catalog to move.
        index: Target position index.
        group_id: Target group ID, or null for ungrouped (default: None).
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).
        instance: Instance name (default: auto-select).

    Returns:
        dict with moved (bool), catalog_id, index, group_id, trace_id.
    """
    try:
        async with GDBClient.for_instance(instance, trace_id=trace_id) as client:
            body: dict[str, Any] = {"index": index, "group_id": group_id}
            await client.post(f"/api/v1/database-catalog/{catalog_id}/move", data=body)
            return {
                "moved": True,
                "catalog_id": catalog_id,
                "index": index,
                "group_id": group_id,
                "trace_id": client.trace_id,
            }
    except GDBClientError as e:
        raise translate_error(e, resource_type="catalog", resource_id=catalog_id) from e
