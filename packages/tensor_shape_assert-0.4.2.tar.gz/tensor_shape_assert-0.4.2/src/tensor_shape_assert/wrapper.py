import types
import inspect
from typing import Any, Callable, Iterable, Literal, get_args, NamedTuple
import warnings

from array_api._2024_12 import Array as ArrayProtocol

from .utils import (
    TensorShapeAssertError,
    ArrayIdentityMap
)
from .descriptor import (
    descriptor_to_variables,
    split_to_descriptor_items,
    clean_up_descriptor
)

from .types import ShapeDescriptor, OptionalShapeDescriptor, VariablesType
from .errors import (
    AnnotationMatchingError,
    LabelAnnotationError,
    LabelConstraintError,
    VariableConstraintError,
    CheckDisabledWarning,
    NoVariableContextExistsError
)

from .trace import (
    add_function_trace,
    add_assignment_trace,
    finalize_function_trace,
)

def unroll_iterable_annotation(annotation, obj, disable_union_warning: bool):
    if isinstance(annotation, (ShapeDescriptor, OptionalShapeDescriptor)):
        yield annotation, obj

    elif isinstance(annotation, types.GenericAlias):
        # try to infer how annotation maps to iterable 
        sub_annotations: list[Any] | tuple[Any] | None = None

        if annotation.__origin__ == tuple:
            sub_annotations = annotation.__args__

            # check if its a arbitrary length annotation
            if len(sub_annotations) == 2 and sub_annotations[1] == Ellipsis:
                sub_annotations = [sub_annotations[0]] * len(obj)

        elif annotation.__origin__ == list:
            if len(annotation.__args__) != 1:
                raise AnnotationMatchingError(
                    f"Expected a single argument for list annotation, but got "
                    f"{annotation.__args__}."
                )
            sub_annotations = [annotation.__args__[0]] * len(obj)

        if sub_annotations is not None:  # it's either tuple or list

            if not hasattr(obj, "__len__"):
                raise TensorShapeAssertError(
                    f"Expected parameter of type {type(obj)} with annotation "
                    f"{annotation} to have a length."
                )

            if len(sub_annotations) != len(obj):
                raise AnnotationMatchingError(
                    f"Number of expected annotated elements in iterable "
                    f"type does not match actual length. Expected "
                    f"{len(sub_annotations)} items, but got {len(obj)}."
                )
            
            for sub_ann, sub_obj in zip(sub_annotations, obj):
                yield from unroll_iterable_annotation(sub_ann, sub_obj, disable_union_warning)

    elif isinstance(annotation, types.UnionType):
        for arg in annotation.__args__:
            if isinstance(arg, types.GenericAlias) and not disable_union_warning:
                warnings.warn(RuntimeWarning(
                    "You used a union type in a function to be checked by "
                    "tensor_shape_assert. check_tensor_shapes currently does "
                    "not check iterables of tensors in union types. For "
                    "example, the output of \n\n"
                    "    def test() -> tuple[ShapedTensor['1']] | None:\n\n"
                    "will be ignored, except for the case where a single "
                    "ShapedTensor is found in a union. For example\n\n"
                    "    def test() -> ShapedTensor['1'] | None:\n\n"
                    "is allowed and will be checked as expected."
                ))

# define module level tensor -> label registry
_global_tensor_label_registry: ArrayIdentityMap[frozenset[str]] = ArrayIdentityMap()

def label_tensor(
        tensor: ArrayProtocol,
        label: str | Iterable[str],
        overwrite: bool = False
) -> ArrayProtocol:
    """
    Labels a tensor with the given label(s). The label(s) are then considered 
    in the checks of the shape descriptors.
    Parameters
    ----------
    tensor : ArrayProtocol
        The tensor to be labeled.
    label : str | Iterable[str]
        The label(s) to be assigned to the tensor.
    overwrite : bool, optional
        If ``True``, existing labels of the tensor will be overwritten.
        If ``False`` (default), an error will be raised if the tensor already
        has labels.

    Returns
    -------
    ArrayProtocol
        The same tensor that was passed in, but with the label(s) assigned to it.
    
    Raises
    ------
    LabelAnnotationError
        If the given label is not registered or if the tensor already has labels.
    """
    if isinstance(label, str):
        label = [label]

    # check if labels exist and do not have constraint fns
    try:
        for l in ShapeDescriptor.filter_for_constrained_labels(label):
            raise LabelAnnotationError(
                f"Label '{l}' has a constraint function and cannot be assigned "
                f"manually using label_tensor."
            )
    except KeyError as e:
        raise LabelAnnotationError(
            f"Label '{e.args[0]}' is not registered and cannot be assigned "
            f"manually using label_tensor."
        )

    # check if object already has labels
    existing_labels = _global_tensor_label_registry.get(tensor, None)
    if existing_labels is not None:
        if not overwrite:
            raise LabelAnnotationError(
                f"Tensor already has labels {existing_labels}. Cannot assign "
                f"new labels {label} to the same tensor."
            )
        else:
            _global_tensor_label_registry[tensor] = frozenset(label)
            return tensor

    _global_tensor_label_registry[tensor] = frozenset(label)
    return tensor


def check_iterable(
        annotation: Any,
        obj: Any,
        variables: VariablesType,
        name: str,
        disable_union_warning: bool,
        must_have_labels: bool
) -> VariablesType:
    for descriptor, obj in unroll_iterable_annotation(annotation, obj, disable_union_warning):

        # skip if its optional and obj is None
        if isinstance(descriptor, OptionalShapeDescriptor) and obj is None:
            continue

        try:
            constrained_label_annotations = ShapeDescriptor.filter_for_constrained_labels(descriptor.labels)
            unconstrained_label_annotations = ShapeDescriptor.filter_for_unconstrained_labels(descriptor.labels)
        except KeyError as e:
            raise LabelAnnotationError(
                f"Label '{e.args[0]}' is not registered. Only registered "
                f"labels can be used in shape descriptors. "
            )

        # check labels with constraint fns
        for label in constrained_label_annotations:
            constraint_fn = ShapeDescriptor.get_label_constraint_fn(label)
            if constraint_fn is not None:
                if not constraint_fn(obj):
                    raise LabelConstraintError(
                        f"Tensor with does not fulfill the constraint for "
                        f"label '{label}'."
                    )

        labels_registered_for_tensor = _global_tensor_label_registry.get(obj, frozenset())

        if must_have_labels and labels_registered_for_tensor:
            # check labels annotations for unconstrained labels
            if not unconstrained_label_annotations.issubset(labels_registered_for_tensor):
                raise LabelAnnotationError(
                    f"Tensor with labels {labels_registered_for_tensor} does not match "
                    f"annotation with labels {unconstrained_label_annotations}."
                )
        elif labels_registered_for_tensor and not unconstrained_label_annotations.issubset(labels_registered_for_tensor):
            raise LabelAnnotationError(
                f"Tensor with labels {labels_registered_for_tensor} must at least have "
                f"annotation with labels {unconstrained_label_annotations}."
            )
        elif not labels_registered_for_tensor and unconstrained_label_annotations:
            # add to registry if not in registry and annotation has labels
            label_tensor(obj, unconstrained_label_annotations)

        # check shape
        variables = descriptor_to_variables(
            shape_descriptor=str(descriptor),
            shape=obj.shape,
            variables=variables
        )

        add_assignment_trace(
            name=name,
            annotation=str(descriptor),
            shape=tuple(obj.shape),
            assignments=variables
        )
    
    return variables

# define a module level stack for currently declared variables
_current_variables_stack: list[VariablesType] = []


# module level check mode
CheckMode = Literal["always", "once", "never"]
_global_check_mode: CheckMode = "always"
_checked_functions: set = set()


def assert_valid_check_mode(mode: CheckMode):
    if mode is not None and mode not in get_args(CheckMode):
        raise TensorShapeAssertError(f"Invalid check mode: '{mode}'")

def set_global_check_mode(mode: CheckMode):
    """
    Set the global check mode for all functions decorated with
    ``check_tensor_shapes``.

    The per-function ``check_mode`` argument takes precedence over this
    setting when it is explicitly specified.

    Parameters
    ----------
    mode : {"always", "once", "never"}
        * ``"always"`` — check every call (default).
        * ``"once"`` — check each decorated function only on its first call.
        * ``"never"`` — disable all shape checks globally.

    Raises
    ------
    TensorShapeAssertError
        If ``mode`` is not one of the accepted values.
    """
    global _global_check_mode
    assert_valid_check_mode(mode)

    _global_check_mode = mode


def run_expression_constraint(
        expression: str,
        variables: dict[str, tuple[int] | int]
) -> bool:
    if "=" not in expression:
        assert False
    if "==" not in expression:
        expression = expression.replace("=", "==")

    exec_globals: dict[str, Any] = {'__builtins__': {}, **variables}
    return eval(expression, exec_globals)

def check_constraints(
        constraints: list[Callable[[VariablesType], bool] | str],
        variables: VariablesType,
        skip_on_error: bool
):
    for i, constraint_fn in enumerate(constraints):

        name = "<unknown>"

        try:
            if isinstance(constraint_fn, str):
                passed = run_expression_constraint(constraint_fn, variables)
                name = f"{i} [{constraint_fn}]"
            else:
                passed = constraint_fn(variables)
                name = f"{i}"
        except Exception:
            if skip_on_error:
                passed = True
            else:
                raise

        if not passed:
            raise VariableConstraintError(
                f"Constraint {name} was not fulfilled for variable "
                f"assignments {variables}."
            )


def check_tensor_shapes(
        fn_or_cls = None,
        *,
        constraints: list[str | Callable[[VariablesType], bool]] | None = None,
        ints_to_variables: bool = True,
        experimental_enable_autogen_constraints: bool = False,
        check_mode: CheckMode | None = None,
        include_outer_variables: bool | None = None,
        disable_union_warning: bool = False
):
    """
    Decorator that enables runtime shape (and dtype) checking for a function,
    class ``__init__``, or ``NamedTuple`` class.

    Annotate parameters and/or return values with ``ShapedTensor["<desc>"]``
    and this decorator will validate shapes on every call (subject to
    ``check_mode``).

    Parameters
    ----------
    constraints : list[str | Callable], optional
        Additional constraints on shape variables.  String expressions are
        evaluated as equality checks (e.g. ``"a == 2 * b"``).  Callables
        receive the variable dict ``{name: value}`` and must return ``True``
        if the constraint is satisfied.  Constraints are checked *before* and
        *after* the wrapped call; errors before the call are suppressed until
        after the call when all variables are fully resolved.
    ints_to_variables : bool, optional
        If ``True`` (default), all ``int``-typed parameters are promoted to
        shape variables and can be referenced in shape descriptors.
    experimental_enable_autogen_constraints : bool, optional
        If ``True``, each shape variable is automatically constrained to equal
        its value from the outer scope.  Requires variables to be valid Python
        identifiers without whitespace.  Experimental — interface may change.
    check_mode : {"always", "once", "never"} | None, optional
        Per-function check mode.  Overrides the global setting set by
        ``set_global_check_mode``.  If ``None`` (default), the global mode
        is used.
    include_outer_variables : bool | None, optional
        If ``True``, shape variables already resolved in the enclosing
        ``check_tensor_shapes`` scope are inherited.  Defaults to ``False``
        for plain functions and ``True`` for ``NamedTuple`` instances.
    disable_union_warning : bool, optional
        If ``True``, suppress the ``RuntimeWarning`` that is raised when a
        union type contains a tuple or list (which cannot be fully checked).
    """
    
    if constraints is None:
        constraints = []

    if check_mode is not None:
        assert_valid_check_mode(check_mode)
    
    def _dispatch_tensor_shapes_wrapper(fn_or_cls):
        def _make_check_tensor_shapes_wrapper(fn):

            # get function signature
            signature = inspect.signature(fn)

            def _check_tensor_shapes_wrapper(*args, **kwargs):

                add_function_trace(fn)

                # get check mode

                _check_mode = _global_check_mode if check_mode is None else check_mode

                # check if torch.compile is used

                _torch_is_compiling = False
                try:
                    import torch
                    if (
                        torch.compiler.is_compiling()
                        or torch._dynamo.external_utils.is_compiling()
                    ):
                        _torch_is_compiling = True
                except ImportError:
                    pass

                # shortcut function if check mode is different to 'always'

                if  (
                        (_check_mode == 'once'
                        and signature in _checked_functions)
                        or _check_mode == 'never'
                    ):
                    return fn(*args, **kwargs)
                
                elif _torch_is_compiling:
                    # skip and warn if is inside torch compile
                    warnings.warn(CheckDisabledWarning(
                        "TorchScript compilation is enabled. Tensor "
                        "shape checks will be skipped inside of the "
                        "compile context."
                    ))
                    return fn(*args, **kwargs)

                _checked_functions.add(signature)

                # bind parameters
                
                bindings = signature.bind(*args, **kwargs)
                bindings.apply_defaults()
                bound_arguments = dict(bindings.arguments)

                # get variables...

                variables: VariablesType = dict()

                # ...from outer function

                if include_outer_variables and len(_current_variables_stack) > 0:
                    # include variables from outer function
                    variables.update(_current_variables_stack[-1])

                    add_assignment_trace(
                        name="<outer variables>",
                        annotation="",
                        shape=(),
                        assignments=variables
                    )

                # ...from ints

                if ints_to_variables:
                    int_variables: VariablesType = {
                        k: v for k, v in bound_arguments.items()
                        if type(v) is int
                    }

                    # check for collisions with outer variables

                    for k in int_variables.keys():
                        if k in variables and variables[k] != int_variables[k]:
                            raise VariableConstraintError(
                                f"Cannot assign integer parameter '{k}' to "
                                f"shape variable as it is already defined "
                                f"in the outer function with a different "
                                f"value ({variables[k]} != "
                                f"{int_variables[k]})."
                            )

                    # add to variables

                    variables.update(int_variables)

                    if len(int_variables) > 0:
                        add_assignment_trace(
                            name="<int variables>",
                            annotation="",
                            shape=(),
                            assignments=int_variables
                        )           

                # run checks for inputs         

                for key, parameter in signature.parameters.items():
                    try:
                        variables = check_iterable(
                            annotation=parameter.annotation,
                            obj=bound_arguments[key],
                            variables=variables,
                            name=key,
                            disable_union_warning=disable_union_warning,
                            must_have_labels=True,
                        )
                        
                    except TensorShapeAssertError as e:
                        # wrap exception to provide location info (input)
                        raise TensorShapeAssertError(
                            f"Shape assertion failed during check of input "
                            f"parameter '{key}' of '{fn.__name__}': {e}"
                        ) from e
                    
                # check input variable constraints (allow errors for now)
                check_constraints(constraints, variables, skip_on_error=True)

                if experimental_enable_autogen_constraints:
                    for i, (k, v) in enumerate(variables.items()):
                        temp_variables = dict(variables)
                        temp_replace_name = f"__temp_var_{i}"
                        temp_replace_val = temp_variables[k]
                        del temp_variables[k]
                        temp_variables[temp_replace_name] = temp_replace_val
                        temp_constraint = f"{temp_replace_name} == {k}"
                        check_constraints([temp_constraint], temp_variables, skip_on_error=True)

                # store variables in global stack
                _current_variables_stack.append(variables)

                # call function
                # protect function call to gracefully handle variables stack

                try:
                    return_value = fn(*args, **kwargs)
                except Exception:
                    _current_variables_stack.pop()
                    raise  # reraise
                
                # check outputs

                try:
                    # TODO check if its wrong that we update variables here again
                    variables = check_iterable(
                        annotation=signature.return_annotation, 
                        obj=return_value,
                        variables=variables,
                        name="<return>",
                        disable_union_warning=disable_union_warning,
                        must_have_labels=False,
                    )
                except TensorShapeAssertError as e:
                    # wrap exception to provide location info (output)
                    raise TensorShapeAssertError(
                        f"Shape assertion failed during check output of "
                        f"'{fn.__name__}': {e}"
                    )
                finally:
                    # check output variable constraints (this time strictly)
                    check_constraints(constraints, variables, skip_on_error=False)

                    if experimental_enable_autogen_constraints:
                        for i, (k, v) in enumerate(variables.items()):
                            temp_variables = dict(variables)
                            temp_replace_name = f"__temp_var_{i}"
                            temp_replace_val = temp_variables[k]
                            # del temp_variables[k]
                            temp_variables[temp_replace_name] = temp_replace_val
                            temp_constraint = f"{temp_replace_name} == {k}"
                            check_constraints([temp_constraint], temp_variables, skip_on_error=False)
                    
                    # remove vars from stack
                    _current_variables_stack.pop()
                    finalize_function_trace()
                
                # return

                return return_value
            return _check_tensor_shapes_wrapper

        # dispatch wrt parameter type (function, class, immutable classes)
        # to ensure pickling of decorated classes works properly, we should replace
        # the __init__ function instead and return the original class. For classes
        # without meaningful __init__ (e.g. NamedTuple), we wrap __new__ instead.

        if isinstance(fn_or_cls, type):
            # If __init__ is the default object.__init__, this is likely a tuple-like
            # (e.g., typing.NamedTuple). Wrap __new__ instead.
            if getattr(fn_or_cls, "__init__") is object.__init__:
                orig_new = fn_or_cls.__new__
                # Bind as a function; Python treats __new__ as a static method by convention.
                new_wrapper = _make_check_tensor_shapes_wrapper(orig_new)
                if isinstance(getattr(fn_or_cls, "__new__", None), staticmethod):
                    fn_or_cls.__new__ = staticmethod(new_wrapper)
                else:
                    fn_or_cls.__new__ = new_wrapper
                return fn_or_cls
            else:
                # Regular class: wrap __init__
                orig_init = fn_or_cls.__init__
                fn_or_cls.__init__ = _make_check_tensor_shapes_wrapper(orig_init)
                return fn_or_cls
        else:
            return _make_check_tensor_shapes_wrapper(fn_or_cls)

    if fn_or_cls is None:
        return _dispatch_tensor_shapes_wrapper    
    else: # its a function
        return _dispatch_tensor_shapes_wrapper(fn_or_cls)

def check_if_context_is_available():
    if len(_current_variables_stack) == 0:
        raise NoVariableContextExistsError(
            "get_shape_variables was called without any check_tensor_shapes "
            "wrapped function in the call stack. No variables can be retrieved "
            "here."
        )

def get_shape_variables(names: str) -> tuple[tuple[int] | int | None, ...]:
    """
    Return the current inferred values of shape variables.

    Must be called from inside a ``@check_tensor_shapes``-wrapped function.
    The variables are those inferred from the annotated parameters that have
    already been checked by the time this is called.

    Parameters
    ----------
    names : str
        A space-separated list of variable names to retrieve.  The syntax
        follows the same rules as a shape descriptor (see ``ShapedTensor``).

    Returns
    -------
    tuple[int | tuple[int, ...] | None, ...]
        One entry per name in ``names``:

        * An ``int`` for a regular dimension variable.
        * A ``tuple[int, ...]`` for a named batch-dimension variable.
        * ``None`` if the variable has not yet been resolved.

    Raises
    ------
    NoVariableContextExistsError
        If called outside of a ``check_tensor_shapes``-wrapped function.
    """
    check_if_context_is_available()
    
    names = clean_up_descriptor(names)
    front, back, mdd = split_to_descriptor_items(names)
    if mdd is None:
        var_names = front
    else:
        var_names = (*front, mdd, *back)

    return tuple(
        _current_variables_stack[-1].get(str(name), None)
        for name in var_names
    )

def assert_shape_here(obj_or_shape: Any, descriptor: str) -> None:
    """
    Validate a tensor or shape against a descriptor from inside a wrapped function.

    Any variables in ``descriptor`` that have not yet been resolved are
    set to the values implied by ``obj_or_shape``.  These values are then
    available to subsequent calls to ``get_shape_variables`` and to the
    check of the function's return annotation.

    Must be called from inside a ``@check_tensor_shapes``-wrapped function.

    Parameters
    ----------
    obj_or_shape : array or tuple[int, ...]
        Either an array-like object with a ``.shape`` property, or a plain
        shape tuple.
    descriptor : str
        A shape descriptor string.  See ``ShapedTensor`` for the full syntax.

    Raises
    ------
    TensorShapeAssertError
        If the shape does not match ``descriptor``.
    NoVariableContextExistsError
        If called outside of a ``check_tensor_shapes``-wrapped function.
    CheckDisabledWarning
        Emitted (as a warning, not an error) when the global check mode is
        ``"once"`` or ``"never"`` and the call is therefore skipped.
    """

    # skip if check is disabled
    if _global_check_mode in ('once', 'never'):
        warnings.warn(CheckDisabledWarning(
            "Global check mode is set to 'once' or 'never'. Calls to "
            "``assert_shape_here`` will be skipped."
        ))
        return

    check_if_context_is_available()

    try:
        shape = obj_or_shape.shape
    except Exception:
        shape = obj_or_shape

    _current_variables_stack[-1] = descriptor_to_variables(
        shape_descriptor=descriptor,
        shape=shape,
        variables=_current_variables_stack[-1]
    )
