"""Exceptions for the TBK VMC API."""


class TbkError(Exception):
    """Base exception for pytbk-api."""


class TbkAuthError(TbkError):
    """Exception raised for authentication errors."""


class TbkConnectionError(TbkError):
    """Exception raised for connection errors."""


class TbkResponseError(TbkError):
    """Exception raised for invalid or error responses from the device."""


class TbkCommandError(TbkError):
    """Exception raised when a command fails."""
