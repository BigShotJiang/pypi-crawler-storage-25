"""Python API library client for the TBK VMC machine."""

import logging
from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("pytbk-api")
except PackageNotFoundError:
    # Package is not installed
    __version__ = "0.0.0"

_LOGGER = logging.getLogger(__name__)
_LOGGER.info("Loading pytbk-api version %s", __version__)
