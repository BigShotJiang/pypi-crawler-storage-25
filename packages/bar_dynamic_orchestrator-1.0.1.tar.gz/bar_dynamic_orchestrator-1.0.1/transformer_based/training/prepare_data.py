#!/usr/bin/env python3
"""
=============================================================================
DATA PREPARATION SCRIPT FOR DEBERTA TRAINING
=============================================================================

PURPOSE:
    This script prepares your raw JSONL data for training a DeBERTa classifier.
    It handles splitting, tokenization, and creates datasets ready for training.

WHY WE NEED THIS:
    1. Machine learning models need data split into train/validation/test sets
    2. Text needs to be converted to numbers (tokens) that the model understands
    3. Labels (categories) need to be converted to numeric IDs
    4. Data needs to be in a specific format that the Trainer API expects

WHAT THIS SCRIPT DOES:
    1. Loads your JSONL file with queries and categories
    2. Creates a label mapping (category name → number)
    3. Splits data into train (80%), validation (10%), test (10%)
    4. Tokenizes text using DeBERTa's tokenizer
    5. Saves processed datasets to disk for training

INPUT FORMAT (your JSONL):
    {"query": "How do I reset my password?", "category": "INSTRUCTION_FOLLOWING", ...}
    {"query": "Explain quantum physics", "category": "FACTUAL_KNOWLEDGE", ...}

OUTPUT FORMAT:
    - transformer_based/data/train/ (80% of data)
    - transformer_based/data/val/ (10% of data)
    - transformer_based/data/test/ (10% of data)
    - transformer_based/data/label_map.json (category → ID mapping)
=============================================================================
"""

import json
import random
from pathlib import Path
from collections import Counter
import argparse

# =============================================================================
# LIBRARY IMPORTS
# =============================================================================

# datasets: Hugging Face library for handling datasets efficiently
# - Provides Dataset and DatasetDict classes
# - Handles batched operations and disk caching
# - Integrates seamlessly with the Trainer API
from datasets import Dataset, DatasetDict

# transformers: Hugging Face library for transformer models
# - DebertaV2Tokenizer: Specific tokenizer for DeBERTa v2/v3 models
# - Tokenizers convert text to token IDs that models can process
from transformers import AutoTokenizer


def load_jsonl(file_path: str) -> list:
    """
    Load records from a JSONL file.

    WHY JSONL FORMAT:
        - Each line is a complete JSON object
        - Memory efficient (can process line by line)
        - Easy to append new records
        - Common format for ML datasets

    Args:
        file_path: Path to the JSONL file

    Returns:
        List of dictionaries, each containing a record
    """
    records = []
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                records.append(json.loads(line.strip()))
    return records


def create_label_mapping(records: list) -> dict:
    """
    Create a mapping from category names to numeric IDs.

    WHY WE NEED THIS:
        - Neural networks work with numbers, not strings
        - Each category needs a unique integer ID (0, 1, 2, ...)
        - This mapping is used during training AND inference
        - Must be saved and used consistently

    Example:
        {"REASONING": 0, "CODE": 1, "CREATIVE_WRITING": 2, ...}

    Args:
        records: List of records with 'category' field

    Returns:
        Dictionary mapping category names to integer IDs
    """
    # Get all unique categories and sort them for consistency
    categories = sorted(set(r['category'] for r in records))

    # Create mapping: category name → integer ID
    label_map = {category: idx for idx, category in enumerate(categories)}

    return label_map


def split_data(records: list, train_ratio: float = 0.8, val_ratio: float = 0.1):
    """
    Split data into train, validation, and test sets.

    WHY THREE SPLITS:
        1. TRAIN (80%): Model learns from this data
           - Weights are updated based on these examples

        2. VALIDATION (10%): Used during training to monitor progress
           - Helps detect overfitting (model memorizing instead of learning)
           - Used to tune hyperparameters
           - Model never learns from this data

        3. TEST (10%): Final evaluation after training is complete
           - Gives unbiased estimate of model performance
           - Never seen during training or hyperparameter tuning
           - Only used ONCE at the very end

    WHY RANDOM SHUFFLE:
        - Ensures each split has similar distribution of categories
        - Prevents bias from data ordering
        - Makes results reproducible with seed

    Args:
        records: All data records
        train_ratio: Fraction for training (default 80%)
        val_ratio: Fraction for validation (default 10%)

    Returns:
        Tuple of (train_records, val_records, test_records)
    """
    # Shuffle randomly but reproducibly (seed=42 is ML convention)
    random.seed(42)
    shuffled = records.copy()
    random.shuffle(shuffled)

    # Calculate split indices
    n = len(shuffled)
    train_end = int(n * train_ratio)
    val_end = int(n * (train_ratio + val_ratio))

    # Split the data
    train_data = shuffled[:train_end]
    val_data = shuffled[train_end:val_end]
    test_data = shuffled[val_end:]

    return train_data, val_data, test_data


def tokenize_data(records: list, tokenizer, label_map: dict, max_length: int = 256):
    """
    Convert text data to tokenized format for the model.

    WHY TOKENIZATION:
        - Models don't understand text, only numbers
        - Tokenizer breaks text into subwords (pieces)
        - Each subword has a unique ID in the vocabulary

        Example:
            "unhappiness" → ["un", "happiness"] → [1234, 5678]

    WHY MAX_LENGTH:
        - Transformers have a maximum sequence length (512 for most)
        - Longer sequences use more memory and compute
        - 256 is usually enough for queries while being efficient
        - Sequences shorter than max_length are padded
        - Sequences longer than max_length are truncated

    TOKENIZER OUTPUT:
        - input_ids: The token IDs [101, 2054, 2003, 1037, 102]
        - attention_mask: Which tokens are real (1) vs padding (0)

    Args:
        records: Data records with 'query' and 'category' fields
        tokenizer: The DeBERTa tokenizer
        label_map: Category to ID mapping
        max_length: Maximum sequence length

    Returns:
        Hugging Face Dataset object ready for training
    """
    # Extract texts and labels from records
    texts = [r['query'] for r in records]
    labels = [label_map[r['category']] for r in records]

    # Tokenize all texts at once (batch processing is faster)
    # - padding='max_length': Pad short sequences to max_length
    # - truncation=True: Cut sequences longer than max_length
    # - return_tensors=None: Return Python lists (converted later)
    encodings = tokenizer(
        texts,
        padding='max_length',
        truncation=True,
        max_length=max_length,
        return_tensors=None
    )

    # Create a dictionary with all the data
    data_dict = {
        'input_ids': encodings['input_ids'],
        'attention_mask': encodings['attention_mask'],
        'labels': labels
    }

    # Convert to Hugging Face Dataset
    # This provides efficient batching, shuffling, and disk caching
    dataset = Dataset.from_dict(data_dict)

    return dataset


def print_dataset_stats(train_data, val_data, test_data, label_map):
    """Print statistics about the datasets."""
    print("\n" + "=" * 80)
    print("DATASET STATISTICS")
    print("=" * 80)

    print(f"\n📊 Split Sizes:")
    print(f"   Train:      {len(train_data):,} samples ({len(train_data)/(len(train_data)+len(val_data)+len(test_data))*100:.1f}%)")
    print(f"   Validation: {len(val_data):,} samples ({len(val_data)/(len(train_data)+len(val_data)+len(test_data))*100:.1f}%)")
    print(f"   Test:       {len(test_data):,} samples ({len(test_data)/(len(train_data)+len(val_data)+len(test_data))*100:.1f}%)")
    print(f"   Total:      {len(train_data)+len(val_data)+len(test_data):,} samples")

    print(f"\n📁 Number of Categories: {len(label_map)}")

    print("\n📈 Category Distribution (Training Set):")
    print("-" * 80)
    train_categories = Counter([r['category'] for r in train_data])
    for category, count in sorted(train_categories.items(), key=lambda x: -x[1]):
        pct = count / len(train_data) * 100
        bar = "█" * int(pct / 2)
        print(f"   {category:<25} {count:>5} ({pct:>5.1f}%) {bar}")


def main():
    """Main data preparation function."""

    # =========================================================================
    # ARGUMENT PARSING
    # =========================================================================
    parser = argparse.ArgumentParser(
        description="Prepare data for DeBERTa training",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python prepare_data.py --input data/final/balanced_20260117_181347.jsonl
  python prepare_data.py --input data/final/balanced_20260117_181347.jsonl --max-length 128
        """
    )
    parser.add_argument(
        '--input', '-i',
        type=str,
        required=True,
        help='Path to input JSONL file with queries and categories'
    )
    parser.add_argument(
        '--output-dir', '-o',
        type=str,
        default='transformer_based/data',
        help='Output directory for processed datasets'
    )
    parser.add_argument(
        '--model-name',
        type=str,
        default='microsoft/deberta-v3-base',
        help='Model name for tokenizer (default: microsoft/deberta-v3-base)'
    )
    parser.add_argument(
        '--max-length',
        type=int,
        default=256,
        help='Maximum sequence length for tokenization (default: 256)'
    )
    parser.add_argument(
        '--train-ratio',
        type=float,
        default=0.8,
        help='Fraction of data for training (default: 0.8)'
    )
    parser.add_argument(
        '--val-ratio',
        type=float,
        default=0.1,
        help='Fraction of data for validation (default: 0.1)'
    )

    args = parser.parse_args()

    # =========================================================================
    # STEP 1: LOAD RAW DATA
    # =========================================================================
    print("\n" + "=" * 80)
    print("STEP 1: LOADING RAW DATA")
    print("=" * 80)
    print(f"\n📂 Loading data from: {args.input}")

    records = load_jsonl(args.input)
    print(f"✅ Loaded {len(records):,} records")

    # =========================================================================
    # STEP 2: CREATE LABEL MAPPING
    # =========================================================================
    print("\n" + "=" * 80)
    print("STEP 2: CREATING LABEL MAPPING")
    print("=" * 80)

    label_map = create_label_mapping(records)
    print(f"\n📋 Label Mapping (Category → ID):")
    for category, idx in sorted(label_map.items(), key=lambda x: x[1]):
        print(f"   {idx:>2}: {category}")

    # Also create reverse mapping (ID → Category) for inference
    id_to_label = {v: k for k, v in label_map.items()}

    # =========================================================================
    # STEP 3: SPLIT DATA
    # =========================================================================
    print("\n" + "=" * 80)
    print("STEP 3: SPLITTING DATA")
    print("=" * 80)
    print(f"\n📊 Split Ratios: Train={args.train_ratio}, Val={args.val_ratio}, Test={1-args.train_ratio-args.val_ratio}")

    train_data, val_data, test_data = split_data(
        records,
        train_ratio=args.train_ratio,
        val_ratio=args.val_ratio
    )

    print_dataset_stats(train_data, val_data, test_data, label_map)

    # =========================================================================
    # STEP 4: LOAD TOKENIZER
    # =========================================================================
    print("\n" + "=" * 80)
    print("STEP 4: LOADING TOKENIZER")
    print("=" * 80)
    print(f"\n🔤 Loading tokenizer: {args.model_name}")

    # Use DebertaV2Tokenizer directly to avoid fast tokenizer compatibility issues
    # This is the slow (Python) tokenizer that works reliably with DeBERTa v3
    tokenizer = AutoTokenizer.from_pretrained(args.model_name)
    print(f"✅ Tokenizer loaded")
    print(f"   Vocabulary size: {tokenizer.vocab_size:,}")
    print(f"   Max length: {args.max_length}")

    # =========================================================================
    # STEP 5: TOKENIZE DATA
    # =========================================================================
    print("\n" + "=" * 80)
    print("STEP 5: TOKENIZING DATA")
    print("=" * 80)

    print("\n🔄 Tokenizing training data...")
    train_dataset = tokenize_data(train_data, tokenizer, label_map, args.max_length)
    print(f"   ✅ Train: {len(train_dataset):,} samples")

    print("🔄 Tokenizing validation data...")
    val_dataset = tokenize_data(val_data, tokenizer, label_map, args.max_length)
    print(f"   ✅ Val: {len(val_dataset):,} samples")

    print("🔄 Tokenizing test data...")
    test_dataset = tokenize_data(test_data, tokenizer, label_map, args.max_length)
    print(f"   ✅ Test: {len(test_dataset):,} samples")

    # Combine into DatasetDict
    dataset_dict = DatasetDict({
        'train': train_dataset,
        'validation': val_dataset,
        'test': test_dataset
    })

    # =========================================================================
    # STEP 6: SAVE PROCESSED DATA
    # =========================================================================
    print("\n" + "=" * 80)
    print("STEP 6: SAVING PROCESSED DATA")
    print("=" * 80)

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Save datasets (Hugging Face format - efficient for training)
    dataset_path = output_dir / 'processed_dataset'
    print(f"\n💾 Saving datasets to: {dataset_path}")
    dataset_dict.save_to_disk(str(dataset_path))
    print("   ✅ Datasets saved")

    # Save label mapping (needed for training and inference)
    label_map_path = output_dir / 'label_map.json'
    print(f"💾 Saving label map to: {label_map_path}")
    with open(label_map_path, 'w') as f:
        json.dump({
            'label_to_id': label_map,
            'id_to_label': id_to_label,
            'num_labels': len(label_map)
        }, f, indent=2)
    print("   ✅ Label map saved")

    # Save tokenizer info
    tokenizer_info_path = output_dir / 'tokenizer_info.json'
    with open(tokenizer_info_path, 'w') as f:
        json.dump({
            'model_name': args.model_name,
            'max_length': args.max_length,
            'vocab_size': tokenizer.vocab_size
        }, f, indent=2)
    print(f"💾 Saving tokenizer info to: {tokenizer_info_path}")
    print("   ✅ Tokenizer info saved")

    # =========================================================================
    # DONE
    # =========================================================================
    print("\n" + "=" * 80)
    print("✅ DATA PREPARATION COMPLETE!")
    print("=" * 80)
    print(f"""
Next Steps:
  1. Review the processed data in: {output_dir}
  2. Run training with: python transformer_based/training/train.py

Files Created:
  - {dataset_path}/ (processed datasets)
  - {label_map_path} (category → ID mapping)
  - {tokenizer_info_path} (tokenizer configuration)
    """)


if __name__ == "__main__":
    main()
