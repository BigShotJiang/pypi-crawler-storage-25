"""
Configuration for the 8-model architecture comparison experiment.

All models use identical hyperparameters for a fair comparison.
"""

# The 8 architecturally distinct transformer models to compare
MODELS = [
    {
        "name": "microsoft/deberta-v3-base",
        "short_name": "deberta-v3",
        "description": "Disentangled attention (content + position separated)",
    },
    {
        "name": "bert-base-uncased",
        "short_name": "bert",
        "description": "Original transformer with MLM + NSP pretraining",
    },
    {
        "name": "roberta-base",
        "short_name": "roberta",
        "description": "Better pretraining (no NSP, more data, dynamic masking)",
    },
    {
        "name": "albert-base-v2",
        "short_name": "albert",
        "description": "Cross-layer parameter sharing (12M params)",
    },
    {
        "name": "google/electra-base-discriminator",
        "short_name": "electra",
        "description": "Replaced token detection (discriminative pretraining)",
    },
    {
        "name": "xlnet-base-cased",
        "short_name": "xlnet",
        "description": "Permutation language modeling",
    },
    {
        "name": "distilbert-base-uncased",
        "short_name": "distilbert",
        "description": "Knowledge distillation (6 layers from BERT's 12)",
    },
    {
        "name": "microsoft/MiniLM-L12-H384-uncased",
        "short_name": "minilm",
        "description": "Deep self-attention distillation",
    },
]

# Shared hyperparameters — identical across all models for fair comparison
HYPERPARAMETERS = {
    "epochs": 5,
    "batch_size": 16,
    "learning_rate": 2e-5,
    "warmup_ratio": 0.1,
    "weight_decay": 0.01,
    "gradient_accumulation": 2,
    "early_stopping": 3,
    "max_length": 256,
    "seed": 42,
}

# Dataset path (relative to project root)
DATASET_PATH = "data/final/corrected_20260211_002413.jsonl"

# Output directories (relative to project root)
EXPERIMENT_BASE_DIR = "transformer_based/experiment"
DATA_BASE_DIR = "transformer_based/experiment/data"
MODELS_BASE_DIR = "transformer_based/experiment/models"
RESULTS_DIR = "transformer_based/experiment/results"

# ─── Phase 2: Hyperparameter Sensitivity Analysis (OFAT) ───────

# Top 3 models from Phase 1 architecture comparison
HP_TUNING_MODELS = [
    {
        "name": "microsoft/deberta-v3-base",
        "short_name": "deberta-v3",
        "description": "Disentangled attention (content + position separated)",
    },
    {
        "name": "roberta-base",
        "short_name": "roberta",
        "description": "Better pretraining (no NSP, more data, dynamic masking)",
    },
    {
        "name": "google/electra-base-discriminator",
        "short_name": "electra",
        "description": "Replaced token detection (discriminative pretraining)",
    },
]

# OFAT grid: vary one parameter at a time, keep others at HYPERPARAMETERS baseline.
# Each value is backed by research papers (see plan for full citations).
HP_TUNING_GRID = {
    "lr_low": {
        "parameter_changed": "learning_rate",
        "parameter_value": 1e-5,
        "overrides": {"learning_rate": 1e-5},
    },
    "lr_high": {
        "parameter_changed": "learning_rate",
        "parameter_value": 5e-5,
        "overrides": {"learning_rate": 5e-5},
    },
    "len_short": {
        "parameter_changed": "max_length",
        "parameter_value": 128,
        "overrides": {"max_length": 128},
    },
    "len_long": {
        "parameter_changed": "max_length",
        "parameter_value": 512,
        "overrides": {"max_length": 512},
    },
    "epoch_low": {
        "parameter_changed": "epochs",
        "parameter_value": 3,
        "overrides": {"epochs": 3},
    },
    "epoch_high": {
        "parameter_changed": "epochs",
        "parameter_value": 10,
        "overrides": {"epochs": 10},
    },
    "batch_low": {
        "parameter_changed": "batch_size",
        "parameter_value": 8,
        "overrides": {"batch_size": 8},
    },
    "batch_high": {
        "parameter_changed": "batch_size",
        "parameter_value": 32,
        "overrides": {"batch_size": 32},
    },
}

# Phase 2 output directories
HP_TUNING_BASE_DIR = "transformer_based/experiment/hp_tuning"
HP_TUNING_DATA_DIR = "transformer_based/experiment/hp_tuning/data"
HP_TUNING_MODELS_DIR = "transformer_based/experiment/hp_tuning/models"
