#!/usr/bin/env python3
"""
Temperature Scaling — Post-hoc calibration for DeBERTa classifier.

Fixes overconfident / underconfident probability scores without retraining.
Example: "hi" -> CONVERSATIONAL 45.6% becomes ~78% after calibration.

How it works:
    Normal:      p(i) = softmax(logits)
    With T:      p(i) = softmax(logits / T)

    T > 1  -> probabilities spread out (less confident)
    T < 1  -> probabilities peak sharper (more confident)
    T = 1  -> no change

T is found by minimizing NLL on the validation set.

Usage:
    python -m transformer_based.training.temperature_scaling \
        --model transformer_based/experiment/models/deberta-v3/final_model \
        --data  transformer_based/experiment/data/deberta-v3/processed_dataset

    Saves temperature to:
        transformer_based/experiment/models/deberta-v3/final_model/temperature.json

Reference:
    Guo et al. (2017) - On Calibration of Modern Neural Networks - ICML 2017
"""

import json
import argparse
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from scipy.optimize import minimize_scalar
from tqdm import tqdm
from datasets import load_from_disk
from transformers import AutoModelForSequenceClassification


class TemperatureScaler:
    """
    Post-hoc calibration using temperature scaling.

    Reference:
        Guo et al. (2017) - On Calibration of Modern Neural Networks
        ICML 2017
    """

    def __init__(self, temperature: float = 1.0):
        self.temperature = temperature

    def fit(
        self, logits: np.ndarray, labels: np.ndarray
    ) -> "TemperatureScaler":
        """
        Find optimal T on validation set by minimizing NLL.

        Args:
            logits: raw logits before softmax, shape (N, num_classes)
            labels: ground truth class indices, shape (N,)

        Returns:
            self
        """
        logits_t = torch.tensor(logits, dtype=torch.float32)
        labels_t = torch.tensor(labels, dtype=torch.long)

        def nll(T):
            return F.cross_entropy(logits_t / T, labels_t).item()

        result = minimize_scalar(nll, bounds=(0.01, 10.0), method="bounded")
        self.temperature = float(result.x)

        nll_before = nll(1.0)
        nll_after = nll(self.temperature)

        print(f"  Optimal temperature : {self.temperature:.4f}")
        print(f"  NLL before scaling  : {nll_before:.4f}")
        print(f"  NLL after  scaling  : {nll_after:.4f}")
        print(f"  Improvement         : {nll_before - nll_after:.4f}")

        return self

    def scale_logits(self, logits: torch.Tensor) -> torch.Tensor:
        """
        Apply temperature scaling to a logits tensor.

        Args:
            logits: shape (batch, num_classes) or (num_classes,)

        Returns:
            Calibrated probability tensor (same shape)
        """
        return F.softmax(logits / self.temperature, dim=-1)

    def scale_probs_dict(self, scores: dict) -> dict:
        """
        Apply temperature scaling to an already-computed probability dict.

        Reconstructs logits via log, scales by T, re-applies softmax.

        Args:
            scores: dict of {category: probability}

        Returns:
            Calibrated dict of {category: probability}
        """
        keys = list(scores.keys())
        probs = np.array([scores[k] for k in keys], dtype=np.float32)
        logits = np.log(np.clip(probs, 1e-9, 1.0))
        scaled = torch.tensor(logits) / self.temperature
        calibrated = F.softmax(scaled, dim=-1).numpy()
        return {k: float(v) for k, v in zip(keys, calibrated)}

    def save(self, path: str):
        """Save temperature value to JSON file."""
        with open(path, "w") as f:
            json.dump({"temperature": self.temperature}, f, indent=2)
        print(f"  Saved to: {path}")

    @classmethod
    def load(cls, path: str) -> "TemperatureScaler":
        """Load temperature value from JSON file."""
        with open(path) as f:
            data = json.load(f)
        return cls(temperature=data["temperature"])


def collect_logits(
    model_path: str, data_path: str, split: str = "validation"
):
    """
    Run model on a dataset split and collect raw logits + labels.

    Args:
        model_path: path to trained model directory
        data_path:  path to processed HuggingFace dataset
        split:      dataset split ("validation" or "test")

    Returns:
        logits: np.ndarray shape (N, num_classes)
        labels: np.ndarray shape (N,)
    """
    print(f"\nLoading model from: {model_path}")
    model = AutoModelForSequenceClassification.from_pretrained(model_path)

    device = (
        "cuda" if torch.cuda.is_available()
        else "mps" if torch.backends.mps.is_available()
        else "cpu"
    )
    model = model.to(device)
    model.eval()
    print(f"Device: {device}")

    print(f"\nLoading {split} split from: {data_path}")
    dataset = load_from_disk(data_path)[split]
    print(f"Split size: {len(dataset)} examples")

    all_logits = []
    all_labels = []

    for item in tqdm(dataset, desc=f"Collecting logits ({split})"):
        inputs = {
            "input_ids": torch.tensor(
                [item["input_ids"]]
            ).to(device),
            "attention_mask": torch.tensor(
                [item["attention_mask"]]
            ).to(device),
        }

        with torch.no_grad():
            logits = model(**inputs).logits[0].cpu().numpy()

        all_logits.append(logits)
        all_labels.append(item["labels"])

    return np.array(all_logits), np.array(all_labels)


def main():
    parser = argparse.ArgumentParser(
        description="Fit temperature scaling on validation set"
    )
    parser.add_argument(
        "--model",
        required=True,
        help=(
            "Path to trained model directory "
            "(e.g. transformer_based/experiment/models/"
            "deberta-v3/final_model)"
        )
    )
    parser.add_argument(
        "--data",
        required=True,
        help=(
            "Path to processed dataset "
            "(e.g. transformer_based/experiment/data/"
            "deberta-v3/processed_dataset)"
        )
    )
    parser.add_argument(
        "--split",
        default="validation",
        choices=["validation", "test"],
        help="Dataset split to fit temperature on (default: validation)"
    )
    args = parser.parse_args()

    print("=" * 60)
    print("TEMPERATURE SCALING CALIBRATION")
    print("=" * 60)

    logits, labels = collect_logits(args.model, args.data, args.split)
    print(f"\nCollected {len(logits)} examples")

    print("\nFitting temperature...")
    scaler = TemperatureScaler()
    scaler.fit(logits, labels)

    output_path = Path(args.model) / "temperature.json"
    scaler.save(str(output_path))

    print("\n" + "=" * 60)
    print("DONE")
    print("=" * 60)
    print(f"Temperature T = {scaler.temperature:.4f}")
    print(f"Auto-loaded by QueryClassifier from: {output_path}")


if __name__ == "__main__":
    main()
