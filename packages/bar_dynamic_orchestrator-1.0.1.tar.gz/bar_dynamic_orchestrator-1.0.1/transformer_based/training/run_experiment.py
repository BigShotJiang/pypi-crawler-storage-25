#!/usr/bin/env python3
"""
8-Model Transformer Architecture Comparison Experiment.

Trains and evaluates 8 architecturally distinct transformer models
on the same dataset with identical hyperparameters for a fair comparison.

Usage:
    python transformer_based/training/run_experiment.py
    python transformer_based/training/run_experiment.py --models bert roberta
    python transformer_based/training/run_experiment.py --skip-prepare
"""

import gc
import json
import os
import sys
import time
import argparse
import logging
from pathlib import Path
from datetime import datetime

# MPS fallback: allow unsupported MPS ops to fall back to CPU automatically
# Must be set BEFORE importing torch
os.environ["PYTORCH_ENABLE_MPS_FALLBACK"] = "1"

import numpy as np
import torch
from datasets import Dataset, DatasetDict, load_from_disk
from transformers import (
    AutoTokenizer,
    AutoModelForSequenceClassification,
    TrainingArguments,
    Trainer,
    EarlyStoppingCallback,
    set_seed,
)
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    precision_score,
    recall_score,
)

# Add project root to path so we can import from experiment_config
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from transformer_based.training.experiment_config import (
    MODELS,
    HYPERPARAMETERS,
    DATASET_PATH,
    DATA_BASE_DIR,
    MODELS_BASE_DIR,
    RESULTS_DIR,
)

logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)


# ─── Data Loading ───────────────────────────────────────────────


def load_jsonl(file_path: str) -> list:
    """Load records from a JSONL file."""
    records = []
    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                records.append(json.loads(line.strip()))
    return records


def create_label_mapping(records: list) -> dict:
    """Create category name → numeric ID mapping."""
    categories = sorted(set(r["category"] for r in records))
    label_to_id = {cat: idx for idx, cat in enumerate(categories)}
    id_to_label = {idx: cat for cat, idx in label_to_id.items()}
    return {
        "label_to_id": label_to_id,
        "id_to_label": id_to_label,
        "num_labels": len(categories),
    }


def split_data(records: list, train_ratio=0.8, val_ratio=0.1):
    """Split data into train/val/test with fixed seed for reproducibility."""
    import random

    random.seed(42)
    shuffled = records.copy()
    random.shuffle(shuffled)

    n = len(shuffled)
    train_end = int(n * train_ratio)
    val_end = int(n * (train_ratio + val_ratio))

    return shuffled[:train_end], shuffled[train_end:val_end], shuffled[val_end:]


def tokenize_split(records, tokenizer, label_map, max_length):
    """Tokenize a data split and return a HuggingFace Dataset."""
    texts = [r["query"] for r in records]
    labels = [label_map["label_to_id"][r["category"]] for r in records]

    encodings = tokenizer(
        texts,
        padding="max_length",
        truncation=True,
        max_length=max_length,
        return_tensors=None,
    )

    return Dataset.from_dict(
        {
            "input_ids": encodings["input_ids"],
            "attention_mask": encodings["attention_mask"],
            "labels": labels,
        }
    )


# ─── Training ───────────────────────────────────────────────────


def compute_metrics(eval_pred):
    """Compute evaluation metrics for HF Trainer."""
    logits, labels = eval_pred
    predictions = np.argmax(logits, axis=-1)
    return {
        "accuracy": accuracy_score(labels, predictions),
        "f1_macro": f1_score(labels, predictions, average="macro"),
        "f1_weighted": f1_score(labels, predictions, average="weighted"),
        "precision": precision_score(labels, predictions, average="macro"),
        "recall": recall_score(labels, predictions, average="macro"),
    }


def prepare_data_for_model(
    model_name, short_name, train_data, val_data, test_data, label_map, hp
):
    """Tokenize data for a specific model's tokenizer."""
    data_dir = PROJECT_ROOT / DATA_BASE_DIR / short_name
    dataset_path = data_dir / "processed_dataset"

    # Resume: skip if already tokenized
    if (dataset_path / "dataset_dict.json").exists():
        print(f"   ⏭️  Data already prepared for {short_name}, skipping...")
        return data_dir

    print(f"   🔤 Loading tokenizer for {model_name}...")
    tokenizer = AutoTokenizer.from_pretrained(model_name)

    print(f"   🔄 Tokenizing {len(train_data)} train samples...")
    train_dataset = tokenize_split(train_data, tokenizer, label_map, hp["max_length"])

    print(f"   🔄 Tokenizing {len(val_data)} val samples...")
    val_dataset = tokenize_split(val_data, tokenizer, label_map, hp["max_length"])

    print(f"   🔄 Tokenizing {len(test_data)} test samples...")
    test_dataset = tokenize_split(test_data, tokenizer, label_map, hp["max_length"])

    dataset_dict = DatasetDict(
        {"train": train_dataset, "validation": val_dataset, "test": test_dataset}
    )

    data_dir.mkdir(parents=True, exist_ok=True)
    dataset_dict.save_to_disk(str(dataset_path))

    # Save label map alongside
    with open(data_dir / "label_map.json", "w") as f:
        json.dump(label_map, f, indent=2)

    print(f"   ✅ Data saved to {data_dir}")
    return data_dir


def train_model(model_name, short_name, data_dir, label_map, hp):
    """Train a model and return training metrics."""
    model_dir = PROJECT_ROOT / MODELS_BASE_DIR / short_name
    final_model_dir = model_dir / "final_model"

    # Resume: skip if already trained
    if (final_model_dir / "config.json").exists():
        print(f"   ⏭️  Model already trained for {short_name}, skipping...")
        metrics_path = model_dir / "training_metrics.json"
        if metrics_path.exists():
            with open(metrics_path) as f:
                return json.load(f), 0
        return {}, 0

    print(f"   📂 Loading tokenized data...")
    datasets = load_from_disk(str(data_dir / "processed_dataset"))

    print(f"   🤖 Loading model: {model_name}...")
    tokenizer = AutoTokenizer.from_pretrained(model_name)

    model = AutoModelForSequenceClassification.from_pretrained(
        model_name,
        num_labels=label_map["num_labels"],
        id2label={str(k): v for k, v in label_map["id_to_label"].items()},
        label2id=label_map["label_to_id"],
    )

    # Test if gradient checkpointing works (some models/devices don't support it)
    use_gradient_checkpointing = False
    if hasattr(model, "gradient_checkpointing_enable"):
        try:
            model.gradient_checkpointing_enable()
            model.gradient_checkpointing_disable()
            use_gradient_checkpointing = True
        except Exception:
            print(f"   ⚠️  Gradient checkpointing not supported for {short_name}, disabling")
            use_gradient_checkpointing = False

    param_count = sum(p.numel() for p in model.parameters())
    print(f"   ✅ Model loaded ({param_count:,} parameters)")

    model_dir.mkdir(parents=True, exist_ok=True)

    training_args = TrainingArguments(
        output_dir=str(model_dir),
        num_train_epochs=hp["epochs"],
        per_device_train_batch_size=hp["batch_size"],
        per_device_eval_batch_size=hp["batch_size"] * 2,
        gradient_accumulation_steps=hp["gradient_accumulation"],
        learning_rate=hp["learning_rate"],
        weight_decay=hp["weight_decay"],
        warmup_ratio=hp["warmup_ratio"],
        lr_scheduler_type="cosine",
        fp16=False,  # MPS does not support FP16
        logging_dir=str(model_dir / "logs"),
        logging_steps=50,
        logging_first_step=True,
        report_to="none",
        eval_strategy="steps",
        eval_steps=200,
        save_strategy="steps",
        save_steps=200,
        save_total_limit=2,
        load_best_model_at_end=True,
        metric_for_best_model="f1_macro",
        greater_is_better=True,
        seed=hp["seed"],
        data_seed=hp["seed"],
        gradient_checkpointing=use_gradient_checkpointing,
        remove_unused_columns=True,
        label_names=["labels"],
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=datasets["train"],
        eval_dataset=datasets["validation"],
        compute_metrics=compute_metrics,
        callbacks=[
            EarlyStoppingCallback(early_stopping_patience=hp["early_stopping"])
        ],
    )

    print(f"   🚀 Training {short_name}...")
    start_time = time.time()
    try:
        train_result = trainer.train()
    except RuntimeError as e:
        # If MPS runs into an unsupported op even with fallback, retry on CPU
        if "MPS" in str(e) or "mps" in str(e):
            print(f"   ⚠️  MPS error encountered, retrying with CPU...")
            os.environ["PYTORCH_MPS_ENABLED"] = "0"
            model = model.to("cpu")
            training_args.no_cuda = True
            trainer = Trainer(
                model=model,
                args=training_args,
                train_dataset=datasets["train"],
                eval_dataset=datasets["validation"],
                compute_metrics=compute_metrics,
                callbacks=[
                    EarlyStoppingCallback(early_stopping_patience=hp["early_stopping"])
                ],
            )
            train_result = trainer.train()
        else:
            raise
    training_time = time.time() - start_time

    # Save model
    trainer.save_model(str(final_model_dir))
    tokenizer.save_pretrained(str(final_model_dir))

    # Copy label map to model dir
    import shutil

    shutil.copy(data_dir / "label_map.json", final_model_dir / "label_map.json")

    # Save training metrics
    metrics = train_result.metrics
    metrics["training_time_seconds"] = training_time
    with open(model_dir / "training_metrics.json", "w") as f:
        json.dump(metrics, f, indent=2)

    print(f"   ✅ Training complete in {training_time/60:.1f} minutes")

    # Clean up to free memory
    del model, trainer, train_result
    gc.collect()
    if torch.backends.mps.is_available():
        torch.mps.empty_cache()

    return metrics, training_time


# ─── Evaluation ─────────────────────────────────────────────────


def evaluate_model(short_name, data_dir, label_map):
    """Evaluate a trained model and return metrics with latency."""
    model_dir = PROJECT_ROOT / MODELS_BASE_DIR / short_name / "final_model"

    print(f"   📊 Evaluating {short_name}...")

    tokenizer = AutoTokenizer.from_pretrained(str(model_dir))
    model = AutoModelForSequenceClassification.from_pretrained(str(model_dir))

    device = (
        "cuda"
        if torch.cuda.is_available()
        else "mps" if torch.backends.mps.is_available() else "cpu"
    )
    model = model.to(device)
    model.eval()

    # Load test data
    datasets = load_from_disk(str(data_dir / "processed_dataset"))
    test_dataset = datasets["test"]

    # Decode texts for re-tokenization (to measure real inference latency)
    texts = tokenizer.batch_decode(test_dataset["input_ids"], skip_special_tokens=True)
    true_labels = np.array(test_dataset["labels"])

    # Measure inference latency
    all_preds = []
    batch_size = 32

    # Warmup run (first MPS inference is slow due to kernel compilation)
    if device == "mps":
        warmup_inputs = tokenizer(
            texts[:1], padding=True, truncation=True,
            max_length=HYPERPARAMETERS["max_length"], return_tensors="pt",
        ).to(device)
        with torch.no_grad():
            model(**warmup_inputs)
        torch.mps.synchronize()

    start_time = time.time()

    for i in range(0, len(texts), batch_size):
        batch_texts = texts[i : i + batch_size]
        inputs = tokenizer(
            batch_texts,
            padding=True,
            truncation=True,
            max_length=HYPERPARAMETERS["max_length"],
            return_tensors="pt",
        ).to(device)

        with torch.no_grad():
            outputs = model(**inputs)
            preds = torch.argmax(outputs.logits, dim=-1)
            all_preds.extend(preds.cpu().numpy())

    # Synchronize MPS to get accurate timing
    if device == "mps":
        torch.mps.synchronize()

    inference_time = time.time() - start_time
    pred_labels = np.array(all_preds)

    # Compute metrics
    accuracy = accuracy_score(true_labels, pred_labels)
    f1_macro = f1_score(true_labels, pred_labels, average="macro")
    f1_weighted = f1_score(true_labels, pred_labels, average="weighted")
    precision = precision_score(true_labels, pred_labels, average="macro")
    recall = recall_score(true_labels, pred_labels, average="macro")

    # Model size on disk
    model_size_mb = sum(
        f.stat().st_size for f in model_dir.rglob("*") if f.is_file()
    ) / (1024 * 1024)

    param_count = sum(p.numel() for p in model.parameters())

    results = {
        "accuracy": round(accuracy, 4),
        "f1_macro": round(f1_macro, 4),
        "f1_weighted": round(f1_weighted, 4),
        "precision_macro": round(precision, 4),
        "recall_macro": round(recall, 4),
        "avg_inference_latency_ms": round(
            (inference_time / len(texts)) * 1000, 2
        ),
        "total_inference_time_s": round(inference_time, 2),
        "model_size_mb": round(model_size_mb, 1),
        "num_parameters": param_count,
    }

    print(
        f"   ✅ {short_name}: Acc={accuracy:.4f}, "
        f"F1={f1_macro:.4f}, Latency={results['avg_inference_latency_ms']:.1f}ms"
    )

    # Clean up
    del model, tokenizer
    gc.collect()
    if torch.backends.mps.is_available():
        torch.mps.empty_cache()

    return results


# ─── Summary ────────────────────────────────────────────────────


def print_summary_table(all_results):
    """Print a formatted comparison table."""
    # Sort by F1 macro descending
    sorted_results = sorted(all_results, key=lambda x: x["f1_macro"], reverse=True)

    print("\n" + "=" * 120)
    print("ARCHITECTURE COMPARISON RESULTS (sorted by F1 Macro)")
    print("=" * 120)

    header = (
        f"{'Rank':<5} {'Model':<15} {'Acc':>7} {'F1-Mac':>7} {'F1-Wgt':>7} "
        f"{'Prec':>7} {'Rec':>7} {'Train(m)':>9} {'Lat(ms)':>8} "
        f"{'Size(MB)':>9} {'Params(M)':>10}"
    )
    print(header)
    print("-" * 120)

    for rank, r in enumerate(sorted_results, 1):
        train_min = r.get("training_time_seconds", 0) / 60
        params_m = r["num_parameters"] / 1_000_000
        print(
            f"{rank:<5} {r['short_name']:<15} {r['accuracy']:>7.4f} "
            f"{r['f1_macro']:>7.4f} {r['f1_weighted']:>7.4f} "
            f"{r['precision_macro']:>7.4f} {r['recall_macro']:>7.4f} "
            f"{train_min:>8.1f} {r['avg_inference_latency_ms']:>8.1f} "
            f"{r['model_size_mb']:>9.1f} {params_m:>10.1f}"
        )

    print("=" * 120)

    best = sorted_results[0]
    print(f"\n🏆 Best model: {best['short_name']} (F1 Macro: {best['f1_macro']:.4f})")


# ─── Main ───────────────────────────────────────────────────────


def main():
    parser = argparse.ArgumentParser(
        description="Run 8-model transformer architecture comparison"
    )
    parser.add_argument(
        "--models",
        nargs="+",
        default=None,
        help="Short names of models to run (default: all 8)",
    )
    parser.add_argument(
        "--skip-prepare",
        action="store_true",
        help="Skip data preparation (use existing tokenized data)",
    )
    args = parser.parse_args()

    print("\n" + "=" * 80)
    print("8-MODEL TRANSFORMER ARCHITECTURE COMPARISON")
    print("=" * 80)

    hp = HYPERPARAMETERS
    set_seed(hp["seed"])

    # Filter models if specified
    models_to_run = MODELS
    if args.models:
        models_to_run = [m for m in MODELS if m["short_name"] in args.models]
        if not models_to_run:
            print(f"❌ No matching models found for: {args.models}")
            print(f"   Available: {[m['short_name'] for m in MODELS]}")
            return

    # Detect device
    if torch.cuda.is_available():
        device = "cuda"
    elif torch.backends.mps.is_available():
        device = "mps"
    else:
        device = "cpu"

    print(f"\n💻 Device: {device}")
    if device == "mps":
        print("   MPS fallback enabled (unsupported ops will use CPU)")
    print(f"📋 Models to run: {[m['short_name'] for m in models_to_run]}")
    print(f"📊 Hyperparameters: {hp}")

    # ── Load and split data once ──
    print("\n" + "-" * 80)
    print("STEP 1: Loading and splitting data")
    print("-" * 80)

    dataset_path = PROJECT_ROOT / DATASET_PATH
    print(f"📂 Loading: {dataset_path}")
    records = load_jsonl(str(dataset_path))
    print(f"✅ Loaded {len(records):,} records")

    label_map = create_label_mapping(records)
    print(f"📋 Categories: {label_map['num_labels']}")

    train_data, val_data, test_data = split_data(records)
    print(f"📊 Split: {len(train_data)} train / {len(val_data)} val / {len(test_data)} test")

    # ── Run experiments ──
    all_results = []
    total_models = len(models_to_run)

    for idx, model_info in enumerate(models_to_run, 1):
        model_name = model_info["name"]
        short_name = model_info["short_name"]

        print(f"\n{'=' * 80}")
        print(f"MODEL {idx}/{total_models}: {short_name} ({model_name})")
        print(f"{'=' * 80}")

        try:
            # Prepare data
            if not args.skip_prepare:
                data_dir = prepare_data_for_model(
                    model_name, short_name,
                    train_data, val_data, test_data,
                    label_map, hp,
                )
            else:
                data_dir = PROJECT_ROOT / DATA_BASE_DIR / short_name

            # Train
            train_metrics, training_time = train_model(
                model_name, short_name, data_dir, label_map, hp
            )

            # Evaluate
            eval_results = evaluate_model(short_name, data_dir, label_map)

            # Combine results
            result = {
                "model_name": model_name,
                "short_name": short_name,
                "description": model_info["description"],
                **eval_results,
                "training_time_seconds": train_metrics.get(
                    "training_time_seconds", training_time
                ),
            }
            all_results.append(result)

        except Exception as e:
            print(f"   ❌ FAILED: {e}")
            logger.exception(f"Error with model {short_name}")
            all_results.append(
                {
                    "model_name": model_name,
                    "short_name": short_name,
                    "description": model_info["description"],
                    "error": str(e),
                    "accuracy": 0,
                    "f1_macro": 0,
                    "f1_weighted": 0,
                    "precision_macro": 0,
                    "recall_macro": 0,
                    "avg_inference_latency_ms": 0,
                    "model_size_mb": 0,
                    "num_parameters": 0,
                    "training_time_seconds": 0,
                }
            )

        # Force garbage collection between models
        gc.collect()
        if torch.backends.mps.is_available():
            torch.mps.empty_cache()

    # ── Save results ──
    results_dir = PROJECT_ROOT / RESULTS_DIR
    results_dir.mkdir(parents=True, exist_ok=True)

    comparison = {
        "experiment_timestamp": datetime.now().strftime("%Y%m%d_%H%M%S"),
        "dataset": DATASET_PATH,
        "num_samples": len(records),
        "num_train": len(train_data),
        "num_val": len(val_data),
        "num_test": len(test_data),
        "hyperparameters": hp,
        "results": all_results,
    }

    comparison_path = results_dir / "comparison.json"
    with open(comparison_path, "w") as f:
        json.dump(comparison, f, indent=2)

    print(f"\n💾 Results saved to: {comparison_path}")

    # Print summary
    # Filter out failed models for the table
    successful = [r for r in all_results if r.get("accuracy", 0) > 0]
    if successful:
        print_summary_table(successful)

    print("\n✅ Experiment complete!")


if __name__ == "__main__":
    main()
