#!/usr/bin/env python3
"""
=============================================================================
DETAILED EVALUATION SCRIPT FOR TRAINED MODEL
=============================================================================

PURPOSE:
    This script provides comprehensive evaluation of your trained model,
    including per-class metrics, confusion matrix, and error analysis.

WHY DETAILED EVALUATION:
    - Overall accuracy can hide poor performance on rare classes
    - Per-class metrics show where the model struggles
    - Confusion matrix reveals which categories are confused
    - Error analysis helps improve data quality

OUTPUT:
    1. Per-class precision, recall, F1 scores
    2. Confusion matrix visualization
    3. Most common misclassifications
    4. Sample of incorrect predictions for manual review

=============================================================================
"""

import json
import argparse
from pathlib import Path
from collections import defaultdict

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    accuracy_score,
    f1_score
)
from tqdm import tqdm

import torch
from datasets import load_from_disk
from transformers import (
    AutoModelForSequenceClassification,
    AutoTokenizer
)


def load_model_and_tokenizer(model_path: str):
    """Load the trained model and tokenizer."""
    print(f"📂 Loading model from: {model_path}")

    tokenizer = AutoTokenizer.from_pretrained(model_path)
    model = AutoModelForSequenceClassification.from_pretrained(model_path)

    # Move to GPU if available
    device = "cuda" if torch.cuda.is_available() else "mps" if torch.backends.mps.is_available() else "cpu"
    model = model.to(device)
    model.eval()  # Set to evaluation mode

    print(f"   ✅ Model loaded on {device}")
    return model, tokenizer, device


def predict_batch(model, tokenizer, texts: list, device: str, batch_size: int = 32):
    """
    Make predictions for a batch of texts.

    WHY BATCH PREDICTION:
        - Processing texts one by one is slow
        - Batching allows parallel processing on GPU
        - Much faster for large datasets
    """
    all_predictions = []
    all_probabilities = []

    # Process in batches
    for i in range(0, len(texts), batch_size):
        batch_texts = texts[i:i + batch_size]

        # Tokenize
        inputs = tokenizer(
            batch_texts,
            padding=True,
            truncation=True,
            max_length=256,
            return_tensors="pt"
        ).to(device)

        # Predict
        with torch.no_grad():  # No gradient computation needed for inference
            outputs = model(**inputs)
            logits = outputs.logits

            # Get probabilities with softmax
            probs = torch.nn.functional.softmax(logits, dim=-1)

            # Get predictions
            preds = torch.argmax(logits, dim=-1)

            all_predictions.extend(preds.cpu().numpy())
            all_probabilities.extend(probs.cpu().numpy())

    return np.array(all_predictions), np.array(all_probabilities)


def create_confusion_matrix_plot(cm, labels, output_path):
    """
    Create and save confusion matrix visualization.

    HOW TO READ CONFUSION MATRIX:
        - Rows = True labels (what the category actually is)
        - Columns = Predicted labels (what the model predicted)
        - Diagonal = Correct predictions
        - Off-diagonal = Mistakes

    Example:
        If row "CODE" has high values in column "REASONING",
        it means many CODE queries were misclassified as REASONING.
    """
    plt.figure(figsize=(14, 12))

    # Normalize confusion matrix to percentages (easier to read)
    cm_normalized = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]

    # Create heatmap
    sns.heatmap(
        cm_normalized,
        annot=True,
        fmt='.1%',
        cmap='Blues',
        xticklabels=labels,
        yticklabels=labels,
        square=True,
        cbar_kws={'label': 'Percentage'}
    )

    plt.title('Confusion Matrix (Normalized)', fontsize=14, fontweight='bold')
    plt.xlabel('Predicted Category', fontsize=12)
    plt.ylabel('True Category', fontsize=12)
    plt.xticks(rotation=45, ha='right')
    plt.yticks(rotation=0)
    plt.tight_layout()

    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    print(f"   💾 Saved confusion matrix to: {output_path}")
    plt.close()


def analyze_errors(texts, true_labels, pred_labels, label_names, output_dir):
    """
    Analyze prediction errors.

    WHY ERROR ANALYSIS:
        - Understand why the model makes mistakes
        - Identify patterns in errors
        - Improve training data or model
    """
    errors = []

    for i, (text, true_id, pred_id) in enumerate(zip(texts, true_labels, pred_labels)):
        if true_id != pred_id:
            errors.append({
                'text': text,
                'true_label': label_names[true_id],
                'pred_label': label_names[pred_id],
                'true_id': int(true_id),
                'pred_id': int(pred_id)
            })

    # Count error patterns
    error_patterns = defaultdict(int)
    for e in errors:
        pattern = f"{e['true_label']} → {e['pred_label']}"
        error_patterns[pattern] += 1

    # Save error analysis
    error_report = {
        'total_errors': len(errors),
        'error_patterns': dict(sorted(error_patterns.items(), key=lambda x: -x[1])[:20]),
        'sample_errors': errors[:50]  # First 50 errors for manual review
    }

    error_path = output_dir / 'error_analysis.json'
    with open(error_path, 'w') as f:
        json.dump(error_report, f, indent=2)
    print(f"   💾 Saved error analysis to: {error_path}")

    return error_patterns


def main():
    """Main evaluation function."""

    # =========================================================================
    # ARGUMENT PARSING
    # =========================================================================
    parser = argparse.ArgumentParser(description="Evaluate trained DeBERTa model")

    parser.add_argument(
        '--model',
        type=str,
        required=True,
        help='Path to trained model directory'
    )
    parser.add_argument(
        '--data-dir',
        type=str,
        default='transformer_based/data',
        help='Directory with processed datasets'
    )
    parser.add_argument(
        '--output-dir',
        type=str,
        default=None,
        help='Output directory for evaluation results (default: model_dir/evaluation)'
    )
    parser.add_argument(
        '--batch-size',
        type=int,
        default=32,
        help='Batch size for inference'
    )

    args = parser.parse_args()

    # =========================================================================
    # SETUP
    # =========================================================================
    print("\n" + "=" * 80)
    print("DETAILED MODEL EVALUATION")
    print("=" * 80)

    model_path = Path(args.model)
    output_dir = Path(args.output_dir) if args.output_dir else model_path / 'evaluation'
    output_dir.mkdir(parents=True, exist_ok=True)

    # =========================================================================
    # LOAD MODEL
    # =========================================================================
    print("\n" + "=" * 80)
    print("STEP 1: LOADING MODEL")
    print("=" * 80)

    model, tokenizer, device = load_model_and_tokenizer(str(model_path))

    # Load label mapping
    label_map_path = model_path / 'label_map.json'
    with open(label_map_path, 'r') as f:
        label_info = json.load(f)

    id_to_label = {int(k): v for k, v in label_info['id_to_label'].items()}
    label_names = [id_to_label[i] for i in range(len(id_to_label))]

    # =========================================================================
    # LOAD TEST DATA
    # =========================================================================
    print("\n" + "=" * 80)
    print("STEP 2: LOADING TEST DATA")
    print("=" * 80)

    data_dir = Path(args.data_dir)
    datasets = load_from_disk(str(data_dir / 'processed_dataset'))
    test_dataset = datasets['test']

    print(f"   ✅ Loaded {len(test_dataset)} test samples")

    # Decode texts (we need original text for error analysis)
    texts = tokenizer.batch_decode(test_dataset['input_ids'], skip_special_tokens=True)
    true_labels = np.array(test_dataset['labels'])

    # =========================================================================
    # MAKE PREDICTIONS
    # =========================================================================
    print("\n" + "=" * 80)
    print("STEP 3: MAKING PREDICTIONS")
    print("=" * 80)

    print(f"\n🔮 Predicting on {len(texts)} samples...")
    pred_labels, probabilities = predict_batch(
        model, tokenizer, texts, device, args.batch_size
    )
    print("   ✅ Predictions complete")

    # =========================================================================
    # COMPUTE METRICS
    # =========================================================================
    print("\n" + "=" * 80)
    print("STEP 4: COMPUTING METRICS")
    print("=" * 80)

    # Overall metrics
    accuracy = accuracy_score(true_labels, pred_labels)
    f1_macro = f1_score(true_labels, pred_labels, average='macro')
    f1_weighted = f1_score(true_labels, pred_labels, average='weighted')

    print(f"\n🎯 Overall Metrics:")
    print(f"   Accuracy:     {accuracy:.4f} ({accuracy*100:.2f}%)")
    print(f"   F1 (Macro):   {f1_macro:.4f}")
    print(f"   F1 (Weighted): {f1_weighted:.4f}")

    # Per-class metrics
    print(f"\n📊 Per-Class Metrics:")
    print("-" * 80)
    report = classification_report(
        true_labels, pred_labels,
        target_names=label_names,
        digits=4
    )
    print(report)

    # Save detailed report
    report_dict = classification_report(
        true_labels, pred_labels,
        target_names=label_names,
        output_dict=True
    )

    results = {
        'overall': {
            'accuracy': accuracy,
            'f1_macro': f1_macro,
            'f1_weighted': f1_weighted
        },
        'per_class': report_dict
    }

    results_path = output_dir / 'evaluation_results.json'
    with open(results_path, 'w') as f:
        json.dump(results, f, indent=2)
    print(f"\n💾 Saved evaluation results to: {results_path}")

    # =========================================================================
    # CONFUSION MATRIX
    # =========================================================================
    print("\n" + "=" * 80)
    print("STEP 5: CREATING CONFUSION MATRIX")
    print("=" * 80)

    cm = confusion_matrix(true_labels, pred_labels)
    cm_path = output_dir / 'confusion_matrix.png'
    create_confusion_matrix_plot(cm, label_names, cm_path)

    # =========================================================================
    # ERROR ANALYSIS
    # =========================================================================
    print("\n" + "=" * 80)
    print("STEP 6: ANALYZING ERRORS")
    print("=" * 80)

    error_patterns = analyze_errors(
        texts, true_labels, pred_labels, label_names, output_dir
    )

    print(f"\n❌ Top Misclassification Patterns:")
    print("-" * 80)
    for pattern, count in list(error_patterns.items())[:10]:
        print(f"   {pattern:<50} {count:>5} times")

    # =========================================================================
    # DONE
    # =========================================================================
    print("\n" + "=" * 80)
    print("✅ EVALUATION COMPLETE!")
    print("=" * 80)
    print(f"""
Summary:
  - Test Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)
  - F1 Macro: {f1_macro:.4f}
  - Total Errors: {len(true_labels) - sum(true_labels == pred_labels)}

Files Created:
  - {results_path}
  - {cm_path}
  - {output_dir / 'error_analysis.json'}
    """)


if __name__ == "__main__":
    main()
