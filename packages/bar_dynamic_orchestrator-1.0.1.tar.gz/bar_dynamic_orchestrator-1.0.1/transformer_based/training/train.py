#!/usr/bin/env python3
"""
=============================================================================
DEBERTA TRAINING SCRIPT FOR TEXT CLASSIFICATION
=============================================================================

PURPOSE:
    This script trains a DeBERTa model to classify queries into categories
    for LLM routing. It uses the Hugging Face Trainer API for robust training.

WHY DEBERTA:
    DeBERTa (Decoding-enhanced BERT with disentangled attention) improves on
    BERT in two key ways:
    1. DISENTANGLED ATTENTION: Separates content and position embeddings,
       allowing the model to better understand where words are AND what they mean
    2. ENHANCED MASK DECODER: Better prediction during pre-training

    Result: State-of-the-art accuracy on many NLP benchmarks

TRAINING PROCESS OVERVIEW:
    1. Load pre-trained DeBERTa model (already knows language)
    2. Add a classification head (new layer for your categories)
    3. Fine-tune on your data (adapt to your specific task)
    4. Save the trained model for inference

KEY CONCEPTS:
    - FINE-TUNING: Taking a pre-trained model and adapting it to your task
    - EPOCHS: Number of times the model sees the entire training data
    - BATCH SIZE: Number of samples processed before updating weights
    - LEARNING RATE: How big the weight updates are (smaller = more stable)
    - GRADIENT ACCUMULATION: Simulates larger batch sizes on limited memory

=============================================================================
"""

import json
import os
import logging
from pathlib import Path
from datetime import datetime
import argparse

# =============================================================================
# LIBRARY IMPORTS
# =============================================================================

import numpy as np

# datasets: For loading our preprocessed data
from datasets import load_from_disk

# transformers: The main library for transformer models
# - AutoModelForSequenceClassification: Loads model with classification head
# - DebertaV2Tokenizer: Specific tokenizer for DeBERTa v2/v3 models
# - TrainingArguments: Configures the training process
# - Trainer: Handles the training loop
# - EarlyStoppingCallback: Stops training when model stops improving
from transformers import (
    AutoModelForSequenceClassification,
    AutoTokenizer,
    TrainingArguments,
    Trainer,
    EarlyStoppingCallback,
    set_seed
)

# sklearn: For computing metrics (more reliable than HF evaluate library)
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score

# Set up logging
logging.basicConfig(
    format='%(asctime)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)


def load_label_map(label_map_path: str) -> dict:
    """
    Load the label mapping created during data preparation.

    This mapping tells the model:
    - How many categories exist (num_labels)
    - What each category ID means (id_to_label)

    Args:
        label_map_path: Path to label_map.json

    Returns:
        Dictionary with label_to_id, id_to_label, num_labels
    """
    with open(label_map_path, 'r') as f:
        return json.load(f)


def compute_metrics(eval_pred):
    """
    Compute evaluation metrics during training.

    WHY MULTIPLE METRICS:
        - ACCURACY: Overall correct predictions (can be misleading for imbalanced data)
        - F1 (Macro): Average F1 across all classes (treats all classes equally)
        - F1 (Weighted): F1 weighted by class frequency (accounts for imbalance)
        - PRECISION: Of predicted positives, how many were correct
        - RECALL: Of actual positives, how many were predicted

    This function is called by the Trainer after each evaluation.

    Args:
        eval_pred: Tuple of (predictions, labels) from the model

    Returns:
        Dictionary of metric names and values
    """
    # Unpack predictions and labels
    logits, labels = eval_pred

    # Convert logits to predictions (take argmax)
    # Logits are raw model outputs before softmax
    # Shape: [batch_size, num_classes] → [batch_size]
    predictions = np.argmax(logits, axis=-1)

    # Compute all metrics using sklearn
    results = {
        # Accuracy: (correct predictions) / (total predictions)
        'accuracy': accuracy_score(labels, predictions),

        # F1 Macro: Compute F1 for each class, then average
        # Good for imbalanced datasets - gives equal weight to all classes
        'f1_macro': f1_score(labels, predictions, average='macro'),

        # F1 Weighted: F1 weighted by number of samples in each class
        'f1_weighted': f1_score(labels, predictions, average='weighted'),

        # Precision Macro: Of all positive predictions, what fraction were correct
        'precision': precision_score(labels, predictions, average='macro'),

        # Recall Macro: Of all actual positives, what fraction did we predict
        'recall': recall_score(labels, predictions, average='macro'),
    }

    return results


def create_training_arguments(
    output_dir: str,
    num_epochs: int = 5,
    batch_size: int = 16,
    learning_rate: float = 2e-5,
    weight_decay: float = 0.01,
    warmup_ratio: float = 0.1,
    gradient_accumulation_steps: int = 2,
    fp16: bool = True,
    logging_steps: int = 50,
    eval_steps: int = 200,
    save_steps: int = 200,
    early_stopping_patience: int = 3
):
    """
    Create training arguments with explanations for each parameter.

    KEY HYPERPARAMETERS EXPLAINED:

    LEARNING RATE (2e-5 = 0.00002):
        - Controls how much to update weights after each batch
        - Too high: Training unstable, loss jumps around
        - Too low: Training too slow, might not converge
        - 2e-5 is the "sweet spot" for fine-tuning transformers

    BATCH SIZE (16):
        - Number of samples processed before one weight update
        - Larger = more stable gradients, but needs more memory
        - Smaller = noisier gradients, but fits in memory
        - With gradient_accumulation=2, effective batch size = 32

    EPOCHS (5):
        - Number of complete passes through training data
        - More epochs = more learning, but risk of overfitting
        - Early stopping will halt if model stops improving

    WEIGHT DECAY (0.01):
        - Regularization to prevent overfitting
        - Penalizes large weights, encouraging simpler solutions
        - 0.01 is standard for fine-tuning

    WARMUP RATIO (0.1):
        - Start with smaller learning rate, gradually increase
        - Prevents early training instability
        - 0.1 = 10% of training steps used for warmup

    GRADIENT ACCUMULATION (2):
        - Accumulate gradients over N batches before updating
        - Simulates larger batch size without more memory
        - Effective batch size = batch_size × gradient_accumulation

    FP16 (Mixed Precision):
        - Use 16-bit floats instead of 32-bit where possible
        - 2x faster training, half the memory
        - Minimal accuracy loss (if any)

    Args:
        Various hyperparameters (see descriptions above)

    Returns:
        TrainingArguments object for the Trainer
    """
    return TrainingArguments(
        # ==== OUTPUT ====
        output_dir=output_dir,  # Where to save checkpoints

        # ==== TRAINING DURATION ====
        num_train_epochs=num_epochs,  # Total epochs to train

        # ==== BATCH SIZE ====
        per_device_train_batch_size=batch_size,  # Samples per GPU for training
        per_device_eval_batch_size=batch_size * 2,  # Can use larger for eval (no gradients)
        gradient_accumulation_steps=gradient_accumulation_steps,  # Accumulate before update

        # ==== OPTIMIZER ====
        learning_rate=learning_rate,  # Initial learning rate
        weight_decay=weight_decay,  # L2 regularization
        warmup_ratio=warmup_ratio,  # Fraction of steps for warmup

        # ==== LEARNING RATE SCHEDULE ====
        lr_scheduler_type="cosine",  # Cosine decay (smooth decrease)

        # ==== PRECISION ====
        fp16=fp16,  # Mixed precision training

        # ==== LOGGING ====
        logging_dir=f"{output_dir}/logs",  # TensorBoard logs
        logging_steps=logging_steps,  # Log every N steps
        logging_first_step=True,  # Log the first step
        report_to="tensorboard",  # Where to report metrics

        # ==== EVALUATION ====
        eval_strategy="steps",  # Evaluate every N steps
        eval_steps=eval_steps,  # Evaluate every N steps

        # ==== CHECKPOINTING ====
        save_strategy="steps",  # Save every N steps
        save_steps=save_steps,  # Save checkpoint every N steps
        save_total_limit=3,  # Only keep last 3 checkpoints
        load_best_model_at_end=True,  # Load best model when done
        metric_for_best_model="f1_macro",  # Use F1 to determine "best"
        greater_is_better=True,  # Higher F1 is better

        # ==== REPRODUCIBILITY ====
        seed=42,  # Random seed for reproducibility
        data_seed=42,  # Seed for data shuffling

        # ==== MEMORY OPTIMIZATION ====
        gradient_checkpointing=True,  # Trade compute for memory

        # ==== OTHER ====
        remove_unused_columns=True,  # Remove columns not used by model
        label_names=["labels"],  # Name of the label column
    )


def main():
    """Main training function."""

    # =========================================================================
    # ARGUMENT PARSING
    # =========================================================================
    parser = argparse.ArgumentParser(
        description="Train DeBERTa for text classification",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    # Data arguments
    parser.add_argument(
        '--data-dir',
        type=str,
        default='transformer_based/data',
        help='Directory with processed datasets'
    )

    # Model arguments
    parser.add_argument(
        '--model-name',
        type=str,
        default='microsoft/deberta-v3-base',
        help='Pre-trained model to fine-tune'
    )

    # Training arguments
    parser.add_argument('--epochs', type=int, default=5, help='Number of training epochs')
    parser.add_argument('--batch-size', type=int, default=16, help='Batch size per device')
    parser.add_argument('--learning-rate', type=float, default=2e-5, help='Learning rate')
    parser.add_argument('--warmup-ratio', type=float, default=0.1, help='Warmup ratio')
    parser.add_argument('--weight-decay', type=float, default=0.01, help='Weight decay')
    parser.add_argument('--gradient-accumulation', type=int, default=2, help='Gradient accumulation steps')
    parser.add_argument('--early-stopping', type=int, default=3, help='Early stopping patience')

    # Output arguments
    parser.add_argument(
        '--output-dir',
        type=str,
        default='transformer_based/models',
        help='Output directory for model'
    )

    # Hardware arguments
    parser.add_argument('--no-fp16', action='store_true', help='Disable FP16 training')

    args = parser.parse_args()

    # =========================================================================
    # SETUP
    # =========================================================================
    print("\n" + "=" * 80)
    print("DEBERTA TRAINING FOR LLM ROUTING CLASSIFIER")
    print("=" * 80)

    # Set random seed for reproducibility
    set_seed(42)

    # Create timestamp for this training run
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = Path(args.output_dir) / f"run_{timestamp}"
    run_dir.mkdir(parents=True, exist_ok=True)

    print(f"\n📁 Output directory: {run_dir}")

    # =========================================================================
    # STEP 1: LOAD DATA
    # =========================================================================
    print("\n" + "=" * 80)
    print("STEP 1: LOADING DATA")
    print("=" * 80)

    data_dir = Path(args.data_dir)

    # Load processed datasets
    print(f"\n📂 Loading datasets from: {data_dir / 'processed_dataset'}")
    datasets = load_from_disk(str(data_dir / 'processed_dataset'))
    print(f"   ✅ Train: {len(datasets['train']):,} samples")
    print(f"   ✅ Validation: {len(datasets['validation']):,} samples")
    print(f"   ✅ Test: {len(datasets['test']):,} samples")

    # Load label mapping
    print(f"\n📋 Loading label map from: {data_dir / 'label_map.json'}")
    label_map = load_label_map(str(data_dir / 'label_map.json'))
    num_labels = label_map['num_labels']
    print(f"   ✅ Number of categories: {num_labels}")

    # =========================================================================
    # STEP 2: LOAD MODEL AND TOKENIZER
    # =========================================================================
    print("\n" + "=" * 80)
    print("STEP 2: LOADING MODEL AND TOKENIZER")
    print("=" * 80)

    print(f"\n🤖 Loading model: {args.model_name}")
    print("   This may take a moment on first run (downloading weights)...")

    # Load tokenizer (needed for inference later)
    # Use DebertaV2Tokenizer directly to avoid fast tokenizer issues
    tokenizer = AutoTokenizer.from_pretrained(args.model_name)

    # Load pre-trained model with classification head
    # - num_labels: Number of output classes
    # - id2label/label2id: Mappings for interpretable outputs
    model = AutoModelForSequenceClassification.from_pretrained(
        args.model_name,
        num_labels=num_labels,
        id2label=label_map['id_to_label'],
        label2id=label_map['label_to_id']
    )

    print(f"   ✅ Model loaded successfully")
    print(f"   Parameters: {model.num_parameters():,}")
    print(f"   Trainable parameters: {sum(p.numel() for p in model.parameters() if p.requires_grad):,}")

    # =========================================================================
    # STEP 3: CONFIGURE TRAINING
    # =========================================================================
    print("\n" + "=" * 80)
    print("STEP 3: CONFIGURING TRAINING")
    print("=" * 80)

    # Check if CUDA is available
    import torch
    device = "cuda" if torch.cuda.is_available() else "mps" if torch.backends.mps.is_available() else "cpu"
    print(f"\n💻 Device: {device}")

    # Disable FP16 on MPS (Apple Silicon) - not fully supported
    use_fp16 = not args.no_fp16 and device == "cuda"

    print(f"\n📊 Training Configuration:")
    print(f"   Epochs: {args.epochs}")
    print(f"   Batch size: {args.batch_size}")
    print(f"   Gradient accumulation: {args.gradient_accumulation}")
    print(f"   Effective batch size: {args.batch_size * args.gradient_accumulation}")
    print(f"   Learning rate: {args.learning_rate}")
    print(f"   Warmup ratio: {args.warmup_ratio}")
    print(f"   Weight decay: {args.weight_decay}")
    print(f"   FP16: {use_fp16}")
    print(f"   Early stopping patience: {args.early_stopping}")

    # Create training arguments
    training_args = create_training_arguments(
        output_dir=str(run_dir),
        num_epochs=args.epochs,
        batch_size=args.batch_size,
        learning_rate=args.learning_rate,
        weight_decay=args.weight_decay,
        warmup_ratio=args.warmup_ratio,
        gradient_accumulation_steps=args.gradient_accumulation,
        fp16=use_fp16,
        early_stopping_patience=args.early_stopping
    )

    # =========================================================================
    # STEP 4: CREATE TRAINER
    # =========================================================================
    print("\n" + "=" * 80)
    print("STEP 4: INITIALIZING TRAINER")
    print("=" * 80)

    # Create Trainer instance
    # The Trainer handles:
    # - Training loop
    # - Gradient computation and optimization
    # - Checkpointing
    # - Evaluation
    # - Logging
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=datasets['train'],
        eval_dataset=datasets['validation'],
        compute_metrics=compute_metrics,
        callbacks=[
            EarlyStoppingCallback(early_stopping_patience=args.early_stopping)
        ]
    )

    print("   ✅ Trainer initialized")

    # =========================================================================
    # STEP 5: TRAIN
    # =========================================================================
    print("\n" + "=" * 80)
    print("STEP 5: TRAINING")
    print("=" * 80)
    print("\n🚀 Starting training...")
    print("   Watch for F1 macro score on validation set")
    print("   Training will stop early if no improvement for", args.early_stopping, "evaluations")
    print("-" * 80)

    # Train the model
    train_result = trainer.train()

    # =========================================================================
    # STEP 6: SAVE FINAL MODEL
    # =========================================================================
    print("\n" + "=" * 80)
    print("STEP 6: SAVING FINAL MODEL")
    print("=" * 80)

    # Save the final model
    final_model_dir = run_dir / "final_model"
    trainer.save_model(str(final_model_dir))
    tokenizer.save_pretrained(str(final_model_dir))

    print(f"\n💾 Model saved to: {final_model_dir}")

    # Save training metrics
    metrics_path = run_dir / "training_metrics.json"
    with open(metrics_path, 'w') as f:
        json.dump(train_result.metrics, f, indent=2)
    print(f"💾 Training metrics saved to: {metrics_path}")

    # Copy label map to model directory (needed for inference)
    import shutil
    shutil.copy(
        data_dir / 'label_map.json',
        final_model_dir / 'label_map.json'
    )
    print(f"💾 Label map copied to model directory")

    # =========================================================================
    # STEP 7: EVALUATE ON TEST SET
    # =========================================================================
    print("\n" + "=" * 80)
    print("STEP 7: FINAL EVALUATION ON TEST SET")
    print("=" * 80)

    print("\n📊 Evaluating on test set (never seen during training)...")
    test_results = trainer.evaluate(datasets['test'])

    print("\n🎯 Test Set Results:")
    print("-" * 80)
    for metric, value in sorted(test_results.items()):
        if isinstance(value, float):
            print(f"   {metric}: {value:.4f}")
        else:
            print(f"   {metric}: {value}")

    # Save test results
    test_results_path = run_dir / "test_results.json"
    with open(test_results_path, 'w') as f:
        json.dump(test_results, f, indent=2)
    print(f"\n💾 Test results saved to: {test_results_path}")

    # =========================================================================
    # DONE
    # =========================================================================
    print("\n" + "=" * 80)
    print("✅ TRAINING COMPLETE!")
    print("=" * 80)
    print(f"""
Summary:
  - Model: {args.model_name}
  - Categories: {num_labels}
  - Test Accuracy: {test_results.get('eval_accuracy', 'N/A'):.4f}
  - Test F1 (Macro): {test_results.get('eval_f1_macro', 'N/A'):.4f}

Files Created:
  - {final_model_dir}/ (trained model)
  - {metrics_path} (training metrics)
  - {test_results_path} (test evaluation)

Next Steps:
  1. Run detailed evaluation: python transformer_based/training/evaluate.py --model {final_model_dir}
  2. Use for inference: python transformer_based/training/predict.py --model {final_model_dir}
    """)


if __name__ == "__main__":
    main()
