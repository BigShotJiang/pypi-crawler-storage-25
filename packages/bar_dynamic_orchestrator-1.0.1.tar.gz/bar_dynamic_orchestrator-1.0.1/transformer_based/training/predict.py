#!/usr/bin/env python3
"""
=============================================================================
INFERENCE SCRIPT FOR TRAINED MODEL
=============================================================================

PURPOSE:
    Use your trained model to classify new queries.
    This is what you'll use in production for LLM routing.

USAGE MODES:
    1. Single query: --query "Your query here"
    2. Batch from file: --input queries.txt
    3. Interactive mode: --interactive

WHAT HAPPENS DURING INFERENCE:
    1. Load trained model and tokenizer
    2. Tokenize input query
    3. Run through model to get logits
    4. Apply softmax to get probabilities
    5. Return category with highest probability

=============================================================================
"""

import json
import argparse
from pathlib import Path
import sys

import torch
from transformers import (
    AutoModelForSequenceClassification,
    AutoTokenizer
)

# Temperature scaling — loaded if temperature.json exists next to model
try:
    from transformer_based.training.temperature_scaling import TemperatureScaler
    _TEMPERATURE_SCALER_AVAILABLE = True
except ImportError:
    _TEMPERATURE_SCALER_AVAILABLE = False


class QueryClassifier:
    """
    A simple classifier for LLM routing.

    WHY A CLASS:
        - Encapsulates model loading and inference
        - Model loaded once, used many times (efficient)
        - Easy to integrate into other applications

    USAGE:
        classifier = QueryClassifier("path/to/model")
        result = classifier.classify("How do I reset my password?")
        print(result['category'])  # INSTRUCTION_FOLLOWING
        print(result['confidence'])  # 0.95
    """

    def __init__(self, model_path: str):
        """
        Initialize the classifier.

        Args:
            model_path: Path to directory containing trained model
        """
        self.model_path = Path(model_path)

        # Load tokenizer
        self.tokenizer = AutoTokenizer.from_pretrained(str(model_path))

        # Load model
        self.model = AutoModelForSequenceClassification.from_pretrained(str(model_path))

        # Move to best available device
        self.device = self._get_device()
        self.model = self.model.to(self.device)
        self.model.eval()  # Set to evaluation mode

        # Load label mapping
        label_map_path = self.model_path / 'label_map.json'
        with open(label_map_path, 'r') as f:
            label_info = json.load(f)

        self.id_to_label = {int(k): v for k, v in label_info['id_to_label'].items()}
        self.label_to_id = label_info['label_to_id']
        self.num_labels = label_info['num_labels']

        # Load temperature scaling if available
        self.temperature_scaler = None
        temperature_path = self.model_path / 'temperature.json'
        if _TEMPERATURE_SCALER_AVAILABLE and temperature_path.exists():
            self.temperature_scaler = TemperatureScaler.load(str(temperature_path))
            print(f"   Temperature scaling loaded: T={self.temperature_scaler.temperature:.4f}")

    def _get_device(self):
        """Determine the best available device."""
        if torch.cuda.is_available():
            return "cuda"
        elif torch.backends.mps.is_available():
            return "mps"
        else:
            return "cpu"

    def classify(self, query: str, return_all_scores: bool = False) -> dict:
        """
        Classify a single query.

        Args:
            query: The text query to classify
            return_all_scores: If True, return scores for all categories

        Returns:
            Dictionary with:
                - category: Predicted category name
                - confidence: Confidence score (0-1)
                - category_id: Numeric category ID
                - all_scores: (optional) Scores for all categories
        """
        # Tokenize
        inputs = self.tokenizer(
            query,
            padding=True,
            truncation=True,
            max_length=256,
            return_tensors="pt"
        ).to(self.device)

        # Predict
        with torch.no_grad():
            outputs = self.model(**inputs)
            logits = outputs.logits

            # Apply temperature scaling if available, else standard softmax
            if self.temperature_scaler is not None:
                probs = self.temperature_scaler.scale_logits(logits)[0]
            else:
                probs = torch.nn.functional.softmax(logits, dim=-1)[0]

            # Get top prediction
            pred_id = torch.argmax(probs).item()
            confidence = probs[pred_id].item()

        result = {
            'category': self.id_to_label[pred_id],
            'confidence': confidence,
            'category_id': pred_id,
            'temperature_applied': self.temperature_scaler is not None,
        }

        if return_all_scores:
            result['all_scores'] = {
                self.id_to_label[i]: probs[i].item()
                for i in range(self.num_labels)
            }

        return result

    def classify_batch(self, queries: list, batch_size: int = 32) -> list:
        """
        Classify multiple queries efficiently.

        Args:
            queries: List of query strings
            batch_size: Number of queries to process at once

        Returns:
            List of result dictionaries
        """
        all_results = []

        for i in range(0, len(queries), batch_size):
            batch = queries[i:i + batch_size]

            # Tokenize batch
            inputs = self.tokenizer(
                batch,
                padding=True,
                truncation=True,
                max_length=256,
                return_tensors="pt"
            ).to(self.device)

            # Predict
            with torch.no_grad():
                outputs = self.model(**inputs)
                if self.temperature_scaler is not None:
                    probs = self.temperature_scaler.scale_logits(outputs.logits)
                else:
                    probs = torch.nn.functional.softmax(outputs.logits, dim=-1)
                pred_ids = torch.argmax(probs, dim=-1)

                for j, (pred_id, prob) in enumerate(zip(pred_ids, probs)):
                    pred_id = pred_id.item()
                    all_results.append({
                        'query': batch[j],
                        'category': self.id_to_label[pred_id],
                        'confidence': prob[pred_id].item(),
                        'category_id': pred_id
                    })

        return all_results


def interactive_mode(classifier):
    """
    Run classifier in interactive mode.

    Allows continuous querying until user exits.
    """
    print("\n" + "=" * 80)
    print("INTERACTIVE MODE")
    print("=" * 80)
    print("Enter queries to classify. Type 'quit' or 'exit' to stop.")
    print("Type 'verbose' to toggle detailed output.")
    print("-" * 80)

    verbose = False

    while True:
        try:
            query = input("\n📝 Query: ").strip()

            if not query:
                continue

            if query.lower() in ['quit', 'exit', 'q']:
                print("\n👋 Goodbye!")
                break

            if query.lower() == 'verbose':
                verbose = not verbose
                print(f"   Verbose mode: {'ON' if verbose else 'OFF'}")
                continue

            # Classify
            result = classifier.classify(query, return_all_scores=verbose)

            # Display result
            print(f"\n   🏷️  Category: {result['category']}")
            print(f"   📊 Confidence: {result['confidence']:.1%}")

            if verbose and 'all_scores' in result:
                print("\n   All Scores:")
                sorted_scores = sorted(
                    result['all_scores'].items(),
                    key=lambda x: -x[1]
                )
                for cat, score in sorted_scores:
                    bar = "█" * int(score * 30)
                    print(f"      {cat:<25} {score:.1%} {bar}")

        except KeyboardInterrupt:
            print("\n\n👋 Goodbye!")
            break


def main():
    """Main prediction function."""

    # =========================================================================
    # ARGUMENT PARSING
    # =========================================================================
    parser = argparse.ArgumentParser(
        description="Classify queries using trained DeBERTa model",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Classify single query
  python predict.py --model transformer_based/models/run_xxx/final_model --query "How do I reset my password?"

  # Classify from file
  python predict.py --model transformer_based/models/run_xxx/final_model --input queries.txt --output predictions.json

  # Interactive mode
  python predict.py --model transformer_based/models/run_xxx/final_model --interactive
        """
    )

    parser.add_argument(
        '--model',
        type=str,
        required=True,
        help='Path to trained model directory'
    )
    parser.add_argument(
        '--query',
        type=str,
        help='Single query to classify'
    )
    parser.add_argument(
        '--input',
        type=str,
        help='Input file with queries (one per line)'
    )
    parser.add_argument(
        '--output',
        type=str,
        help='Output file for predictions (JSON)'
    )
    parser.add_argument(
        '--interactive',
        action='store_true',
        help='Run in interactive mode'
    )
    parser.add_argument(
        '--verbose',
        action='store_true',
        help='Show scores for all categories'
    )

    args = parser.parse_args()

    # Validate arguments
    if not any([args.query, args.input, args.interactive]):
        parser.error("Must specify --query, --input, or --interactive")

    # =========================================================================
    # LOAD MODEL
    # =========================================================================
    print("\n" + "=" * 80)
    print("LOADING MODEL")
    print("=" * 80)

    classifier = QueryClassifier(args.model)
    print(f"   ✅ Model loaded successfully")
    print(f"   📁 Categories: {classifier.num_labels}")
    print(f"   💻 Device: {classifier.device}")

    # =========================================================================
    # RUN INFERENCE
    # =========================================================================

    if args.interactive:
        # Interactive mode
        interactive_mode(classifier)

    elif args.query:
        # Single query mode
        print("\n" + "=" * 80)
        print("CLASSIFICATION RESULT")
        print("=" * 80)

        result = classifier.classify(args.query, return_all_scores=args.verbose)

        print(f"\n📝 Query: {args.query}")
        print(f"\n🏷️  Category: {result['category']}")
        print(f"📊 Confidence: {result['confidence']:.1%}")

        if args.verbose and 'all_scores' in result:
            print("\n📈 All Scores:")
            sorted_scores = sorted(
                result['all_scores'].items(),
                key=lambda x: -x[1]
            )
            for cat, score in sorted_scores:
                bar = "█" * int(score * 30)
                print(f"   {cat:<25} {score:.1%} {bar}")

    elif args.input:
        # Batch mode
        print("\n" + "=" * 80)
        print("BATCH CLASSIFICATION")
        print("=" * 80)

        # Load queries
        with open(args.input, 'r') as f:
            queries = [line.strip() for line in f if line.strip()]

        print(f"\n📂 Loaded {len(queries)} queries from {args.input}")

        # Classify
        print("🔮 Classifying...")
        results = classifier.classify_batch(queries)

        # Display summary
        from collections import Counter
        category_counts = Counter(r['category'] for r in results)

        print(f"\n📊 Results Summary:")
        print("-" * 80)
        for category, count in sorted(category_counts.items(), key=lambda x: -x[1]):
            pct = count / len(results) * 100
            print(f"   {category:<25} {count:>5} ({pct:.1f}%)")

        # Save results
        if args.output:
            with open(args.output, 'w') as f:
                json.dump(results, f, indent=2)
            print(f"\n💾 Results saved to: {args.output}")
        else:
            # Print first few results
            print(f"\n📋 Sample Results (first 5):")
            for r in results[:5]:
                print(f"   {r['category']:<20} ({r['confidence']:.1%}) | {r['query'][:50]}...")


if __name__ == "__main__":
    main()
