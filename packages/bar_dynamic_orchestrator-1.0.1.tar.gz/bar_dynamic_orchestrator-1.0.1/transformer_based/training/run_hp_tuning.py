#!/usr/bin/env python3
"""
Phase 2: Hyperparameter Sensitivity Analysis (OFAT) for Top 3 Models.

Varies one hyperparameter at a time while keeping others at baseline,
to measure each parameter's impact on model performance.

Usage:
    python transformer_based/training/run_hp_tuning.py
    python transformer_based/training/run_hp_tuning.py --models deberta-v3
    python transformer_based/training/run_hp_tuning.py --models deberta-v3 roberta
"""

import gc
import json
import os
import sys
import time
import argparse
import logging
from pathlib import Path
from datetime import datetime

# MPS fallback: allow unsupported MPS ops to fall back to CPU automatically
os.environ["PYTORCH_ENABLE_MPS_FALLBACK"] = "1"

import numpy as np
import torch
from datasets import load_from_disk
import math
from transformers import (
    AutoTokenizer,
    AutoModelForSequenceClassification,
    TrainingArguments,
    Trainer,
    EarlyStoppingCallback,
    TrainerCallback,
    set_seed,
)


class NaNDetectorCallback(TrainerCallback):
    """Detects NaN loss during training and raises an error to trigger CPU fallback."""

    def __init__(self, nan_threshold: int = 3):
        self.consecutive_nan = 0
        self.nan_threshold = nan_threshold

    def on_log(self, args, state, control, logs=None, **kwargs):
        if logs is not None:
            loss = logs.get("loss", None)
            if loss is not None and (math.isnan(loss) or loss == 0.0):
                self.consecutive_nan += 1
                if self.consecutive_nan >= self.nan_threshold:
                    print(f"      NaN/zero loss detected {self.consecutive_nan} times — triggering CPU fallback")
                    raise RuntimeError("MPS NaN detected — falling back to CPU")
            else:
                self.consecutive_nan = 0

# Add project root to path
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from transformer_based.training.experiment_config import (
    HYPERPARAMETERS,
    DATASET_PATH,
    DATA_BASE_DIR,
    RESULTS_DIR,
    HP_TUNING_MODELS,
    HP_TUNING_GRID,
    HP_TUNING_BASE_DIR,
    HP_TUNING_DATA_DIR,
    HP_TUNING_MODELS_DIR,
)
from transformer_based.training.run_experiment import (
    load_jsonl,
    create_label_mapping,
    split_data,
    tokenize_split,
    compute_metrics,
)

logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)


def get_experiment_hp(experiment_id: str) -> dict:
    """Build full hyperparameter dict for a given experiment."""
    hp = HYPERPARAMETERS.copy()
    if experiment_id == "baseline":
        return hp
    overrides = HP_TUNING_GRID[experiment_id]["overrides"]
    hp.update(overrides)
    return hp


def get_results_path() -> Path:
    """Path to the consolidated HP tuning results JSON."""
    return PROJECT_ROOT / RESULTS_DIR / "hp_tuning.json"


def load_existing_results() -> dict:
    """Load existing results for resume support."""
    results_path = get_results_path()
    if results_path.exists():
        with open(results_path) as f:
            return json.load(f)
    return None


def is_experiment_done(existing_results: dict, short_name: str, experiment_id: str) -> bool:
    """Check if a specific model × experiment combination is already completed."""
    if not existing_results:
        return False
    for exp in existing_results.get("experiments", []):
        if exp["short_name"] == short_name and exp["experiment_id"] == experiment_id:
            return True
    return False


def get_baseline_result(short_name: str) -> dict:
    """Load Phase 1 baseline result for a model from comparison.json."""
    comparison_path = PROJECT_ROOT / RESULTS_DIR / "comparison.json"
    if not comparison_path.exists():
        raise FileNotFoundError(
            f"Phase 1 results not found at {comparison_path}. "
            "Run Phase 1 experiment first."
        )
    with open(comparison_path) as f:
        comparison = json.load(f)

    for result in comparison["results"]:
        if result["short_name"] == short_name:
            return result

    raise ValueError(f"Model {short_name} not found in Phase 1 results")


def prepare_data(model_name, short_name, train_data, val_data, test_data, label_map, max_length):
    """Tokenize data for a specific model and max_length combination."""
    data_dir = PROJECT_ROOT / HP_TUNING_DATA_DIR / short_name / f"len_{max_length}"
    dataset_path = data_dir / "processed_dataset"

    # Resume: skip if already tokenized
    if (dataset_path / "dataset_dict.json").exists():
        print(f"      Data already prepared for {short_name}/len_{max_length}, skipping...")
        return data_dir

    # Check if Phase 1 data can be reused (same max_length=256)
    if max_length == HYPERPARAMETERS["max_length"]:
        phase1_data = PROJECT_ROOT / DATA_BASE_DIR / short_name / "processed_dataset"
        if (phase1_data / "dataset_dict.json").exists():
            print(f"      Reusing Phase 1 tokenized data for {short_name} (max_length={max_length})")
            # Symlink to avoid duplication
            data_dir.mkdir(parents=True, exist_ok=True)
            if not dataset_path.exists():
                dataset_path.symlink_to(phase1_data.resolve())
            # Copy label map
            label_map_src = PROJECT_ROOT / DATA_BASE_DIR / short_name / "label_map.json"
            if label_map_src.exists():
                import shutil
                shutil.copy(label_map_src, data_dir / "label_map.json")
            return data_dir

    print(f"      Loading tokenizer for {model_name}...")
    tokenizer = AutoTokenizer.from_pretrained(model_name)

    print(f"      Tokenizing with max_length={max_length}...")
    train_dataset = tokenize_split(train_data, tokenizer, label_map, max_length)
    val_dataset = tokenize_split(val_data, tokenizer, label_map, max_length)
    test_dataset = tokenize_split(test_data, tokenizer, label_map, max_length)

    from datasets import DatasetDict
    dataset_dict = DatasetDict(
        {"train": train_dataset, "validation": val_dataset, "test": test_dataset}
    )

    data_dir.mkdir(parents=True, exist_ok=True)
    dataset_dict.save_to_disk(str(dataset_path))

    with open(data_dir / "label_map.json", "w") as f:
        json.dump(label_map, f, indent=2)

    print(f"      Data saved to {data_dir}")
    return data_dir


def train_and_evaluate(model_name, short_name, experiment_id, data_dir, label_map, hp):
    """Train a model with specific hyperparameters and evaluate on test set."""
    model_dir = PROJECT_ROOT / HP_TUNING_MODELS_DIR / short_name / experiment_id
    final_model_dir = model_dir / "final_model"

    print(f"      Loading tokenized data...")
    datasets = load_from_disk(str(data_dir / "processed_dataset"))

    print(f"      Loading model: {model_name}...")
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForSequenceClassification.from_pretrained(
        model_name,
        num_labels=label_map["num_labels"],
        id2label={str(k): v for k, v in label_map["id_to_label"].items()},
        label2id=label_map["label_to_id"],
    )

    # Test gradient checkpointing support
    use_gradient_checkpointing = False
    if hasattr(model, "gradient_checkpointing_enable"):
        try:
            model.gradient_checkpointing_enable()
            model.gradient_checkpointing_disable()
            use_gradient_checkpointing = True
        except Exception:
            print(f"      Gradient checkpointing not supported, disabling")

    param_count = sum(p.numel() for p in model.parameters())
    print(f"      Model loaded ({param_count:,} parameters)")

    model_dir.mkdir(parents=True, exist_ok=True)

    training_args = TrainingArguments(
        output_dir=str(model_dir),
        num_train_epochs=hp["epochs"],
        per_device_train_batch_size=hp["batch_size"],
        per_device_eval_batch_size=hp["batch_size"] * 2,
        gradient_accumulation_steps=hp["gradient_accumulation"],
        learning_rate=hp["learning_rate"],
        weight_decay=hp["weight_decay"],
        warmup_ratio=hp["warmup_ratio"],
        lr_scheduler_type="cosine",
        fp16=False,
        max_grad_norm=1.0,
        logging_dir=str(model_dir / "logs"),
        logging_steps=50,
        logging_first_step=True,
        report_to="none",
        eval_strategy="steps",
        eval_steps=200,
        save_strategy="steps",
        save_steps=200,
        save_total_limit=2,
        load_best_model_at_end=True,
        metric_for_best_model="f1_macro",
        greater_is_better=True,
        seed=hp["seed"],
        data_seed=hp["seed"],
        gradient_checkpointing=use_gradient_checkpointing,
        remove_unused_columns=True,
        label_names=["labels"],
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=datasets["train"],
        eval_dataset=datasets["validation"],
        compute_metrics=compute_metrics,
        callbacks=[
            EarlyStoppingCallback(early_stopping_patience=hp["early_stopping"]),
            NaNDetectorCallback(nan_threshold=3),
        ],
    )

    print(f"      Training {short_name} [{experiment_id}]...")
    start_time = time.time()
    try:
        train_result = trainer.train()
    except RuntimeError as e:
        if "MPS" in str(e) or "mps" in str(e) or "NaN" in str(e):
            print(f"      MPS/NaN error, restarting training on CPU...")
            del model, trainer
            gc.collect()
            if torch.backends.mps.is_available():
                torch.mps.empty_cache()

            # Reload fresh model on CPU
            model = AutoModelForSequenceClassification.from_pretrained(
                model_name, num_labels=num_labels
            ).to("cpu")

            training_args_cpu = TrainingArguments(
                output_dir=str(model_dir),
                num_train_epochs=hp["epochs"],
                per_device_train_batch_size=hp["batch_size"],
                per_device_eval_batch_size=hp["batch_size"] * 2,
                gradient_accumulation_steps=hp["gradient_accumulation"],
                learning_rate=hp["learning_rate"],
                weight_decay=hp["weight_decay"],
                warmup_ratio=hp["warmup_ratio"],
                lr_scheduler_type="cosine",
                fp16=False,
                max_grad_norm=1.0,
                logging_dir=str(model_dir / "logs"),
                logging_steps=50,
                logging_first_step=True,
                report_to="none",
                eval_strategy="steps",
                eval_steps=200,
                save_strategy="steps",
                save_steps=200,
                save_total_limit=2,
                load_best_model_at_end=True,
                metric_for_best_model="f1_macro",
                greater_is_better=True,
                seed=hp["seed"],
                data_seed=hp["seed"],
                gradient_checkpointing=False,
                remove_unused_columns=True,
                label_names=["labels"],
                no_cuda=True,
                use_mps_device=False,
            )

            trainer = Trainer(
                model=model,
                args=training_args_cpu,
                train_dataset=datasets["train"],
                eval_dataset=datasets["validation"],
                compute_metrics=compute_metrics,
                callbacks=[
                    EarlyStoppingCallback(early_stopping_patience=hp["early_stopping"])
                ],
            )
            train_result = trainer.train()
        else:
            raise
    training_time = time.time() - start_time

    # Determine actual epochs trained
    epochs_set = hp["epochs"]
    # train_result.metrics contains 'epoch' which is the actual epoch reached
    epochs_actual = train_result.metrics.get("epoch", epochs_set)
    early_stopped = epochs_actual < epochs_set

    # Save model
    trainer.save_model(str(final_model_dir))
    tokenizer.save_pretrained(str(final_model_dir))

    print(f"      Training complete in {training_time/60:.1f} min "
          f"(epochs: {epochs_actual}/{epochs_set}"
          f"{', early stopped' if early_stopped else ''})")

    # ── Evaluate on test set ──
    print(f"      Evaluating on test set...")
    device = (
        "cuda" if torch.cuda.is_available()
        else "mps" if torch.backends.mps.is_available() else "cpu"
    )

    # Reload best model for evaluation
    del model, trainer
    gc.collect()
    if torch.backends.mps.is_available():
        torch.mps.empty_cache()

    model = AutoModelForSequenceClassification.from_pretrained(str(final_model_dir))
    model = model.to(device)
    model.eval()

    test_dataset = datasets["test"]
    texts = tokenizer.batch_decode(test_dataset["input_ids"], skip_special_tokens=True)
    true_labels = np.array(test_dataset["labels"])

    all_preds = []
    batch_size = 32

    # Warmup for MPS
    if device == "mps":
        warmup_inputs = tokenizer(
            texts[:1], padding=True, truncation=True,
            max_length=hp["max_length"], return_tensors="pt",
        ).to(device)
        with torch.no_grad():
            model(**warmup_inputs)
        torch.mps.synchronize()

    inf_start = time.time()
    for i in range(0, len(texts), batch_size):
        batch_texts = texts[i:i + batch_size]
        inputs = tokenizer(
            batch_texts, padding=True, truncation=True,
            max_length=hp["max_length"], return_tensors="pt",
        ).to(device)

        with torch.no_grad():
            outputs = model(**inputs)
            preds = torch.argmax(outputs.logits, dim=-1)
            all_preds.extend(preds.cpu().numpy())

    if device == "mps":
        torch.mps.synchronize()

    inference_time = time.time() - inf_start
    pred_labels = np.array(all_preds)

    from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
    accuracy = accuracy_score(true_labels, pred_labels)
    f1_macro = f1_score(true_labels, pred_labels, average="macro")
    f1_weighted = f1_score(true_labels, pred_labels, average="weighted")
    precision = precision_score(true_labels, pred_labels, average="macro")
    recall = recall_score(true_labels, pred_labels, average="macro")

    model_size_mb = sum(
        f.stat().st_size for f in final_model_dir.rglob("*") if f.is_file()
    ) / (1024 * 1024)

    result = {
        "accuracy": round(accuracy, 4),
        "f1_macro": round(f1_macro, 4),
        "f1_weighted": round(f1_weighted, 4),
        "precision_macro": round(precision, 4),
        "recall_macro": round(recall, 4),
        "avg_inference_latency_ms": round((inference_time / len(texts)) * 1000, 2),
        "training_time_seconds": round(training_time, 1),
        "model_size_mb": round(model_size_mb, 1),
        "num_parameters": param_count,
        "epochs_set": epochs_set,
        "epochs_actual": round(epochs_actual, 1),
        "early_stopped": early_stopped,
    }

    print(f"      Acc={accuracy:.4f}, F1={f1_macro:.4f}, "
          f"Latency={result['avg_inference_latency_ms']:.1f}ms")

    # Cleanup model from memory
    del model, tokenizer
    gc.collect()
    if torch.backends.mps.is_available():
        torch.mps.empty_cache()

    # Delete checkpoint dirs to save disk space (keep only final_model)
    import shutil
    for p in model_dir.iterdir():
        if p.is_dir() and p.name.startswith("checkpoint-"):
            shutil.rmtree(p)
    print(f"      Cleaned up checkpoints (kept final_model only)")

    return result


def save_results(all_experiments, num_samples, train_data, val_data, test_data):
    """Save all experiment results to JSON."""
    results_dir = PROJECT_ROOT / RESULTS_DIR
    results_dir.mkdir(parents=True, exist_ok=True)

    output = {
        "experiment_timestamp": datetime.now().strftime("%Y%m%d_%H%M%S"),
        "dataset": DATASET_PATH,
        "num_samples": num_samples,
        "num_train": len(train_data),
        "num_val": len(val_data),
        "num_test": len(test_data),
        "baseline_hyperparameters": HYPERPARAMETERS,
        "hp_tuning_grid": {
            eid: {
                "parameter_changed": v["parameter_changed"],
                "parameter_value": v["parameter_value"],
            }
            for eid, v in HP_TUNING_GRID.items()
        },
        "experiments": all_experiments,
    }

    results_path = get_results_path()
    with open(results_path, "w") as f:
        json.dump(output, f, indent=2)

    print(f"\nResults saved to: {results_path}")
    return results_path


def main():
    parser = argparse.ArgumentParser(
        description="Phase 2: HP Sensitivity Analysis (OFAT) for top 3 models"
    )
    parser.add_argument(
        "--models",
        nargs="+",
        default=None,
        help="Short names of models to run (default: all 3 top models)",
    )
    args = parser.parse_args()

    print("\n" + "=" * 80)
    print("PHASE 2: HYPERPARAMETER SENSITIVITY ANALYSIS (OFAT)")
    print("=" * 80)

    set_seed(HYPERPARAMETERS["seed"])

    # Filter models
    models_to_run = HP_TUNING_MODELS
    if args.models:
        models_to_run = [m for m in HP_TUNING_MODELS if m["short_name"] in args.models]
        if not models_to_run:
            print(f"No matching models for: {args.models}")
            print(f"Available: {[m['short_name'] for m in HP_TUNING_MODELS]}")
            return

    # Detect device
    if torch.cuda.is_available():
        device = "cuda"
    elif torch.backends.mps.is_available():
        device = "mps"
    else:
        device = "cpu"

    print(f"\nDevice: {device}")
    if device == "mps":
        print("MPS fallback enabled")
    print(f"Models: {[m['short_name'] for m in models_to_run]}")
    print(f"Experiments per model: baseline + {len(HP_TUNING_GRID)} variants = {1 + len(HP_TUNING_GRID)}")
    print(f"Total runs: {len(models_to_run)} models x {len(HP_TUNING_GRID)} new = {len(models_to_run) * len(HP_TUNING_GRID)} (baselines reused from Phase 1)")

    # ── Load and split data ──
    print("\n" + "-" * 80)
    print("Loading and splitting data (same split as Phase 1)")
    print("-" * 80)

    dataset_path = PROJECT_ROOT / DATASET_PATH
    records = load_jsonl(str(dataset_path))
    print(f"Loaded {len(records):,} records")

    label_map = create_label_mapping(records)
    print(f"Categories: {label_map['num_labels']}")

    train_data, val_data, test_data = split_data(records)
    print(f"Split: {len(train_data)} train / {len(val_data)} val / {len(test_data)} test")

    # ── Load existing results for resume ──
    existing_results = load_existing_results()
    all_experiments = []
    if existing_results:
        all_experiments = existing_results.get("experiments", [])
        print(f"\nResuming: {len(all_experiments)} experiments already completed")

    # ── Experiment IDs ──
    experiment_ids = ["baseline"] + list(HP_TUNING_GRID.keys())
    total_experiments = len(models_to_run) * len(experiment_ids)
    completed_count = len(all_experiments)

    # ── Run experiments ──
    for model_info in models_to_run:
        model_name = model_info["name"]
        short_name = model_info["short_name"]

        print(f"\n{'=' * 80}")
        print(f"MODEL: {short_name} ({model_name})")
        print(f"{'=' * 80}")

        for exp_id in experiment_ids:
            # Skip if already done
            if is_experiment_done(existing_results, short_name, exp_id):
                print(f"\n   [{exp_id}] Already completed, skipping...")
                continue

            hp = get_experiment_hp(exp_id)

            if exp_id == "baseline":
                print(f"\n   [{exp_id}] Loading Phase 1 baseline result...")
                try:
                    baseline = get_baseline_result(short_name)
                    experiment_result = {
                        "model_name": model_name,
                        "short_name": short_name,
                        "experiment_id": "baseline",
                        "parameter_changed": "none",
                        "parameter_value": "baseline",
                        "hyperparameters": hp,
                        "accuracy": baseline["accuracy"],
                        "f1_macro": baseline["f1_macro"],
                        "f1_weighted": baseline["f1_weighted"],
                        "precision_macro": baseline["precision_macro"],
                        "recall_macro": baseline["recall_macro"],
                        "avg_inference_latency_ms": baseline["avg_inference_latency_ms"],
                        "training_time_seconds": baseline["training_time_seconds"],
                        "model_size_mb": baseline["model_size_mb"],
                        "num_parameters": baseline["num_parameters"],
                        "epochs_set": hp["epochs"],
                        "epochs_actual": hp["epochs"],
                        "early_stopped": False,
                    }
                    all_experiments.append(experiment_result)
                    completed_count += 1
                    print(f"      Baseline F1={baseline['f1_macro']:.4f}")
                except Exception as e:
                    print(f"      ERROR loading baseline: {e}")
                    continue
            else:
                grid_info = HP_TUNING_GRID[exp_id]
                print(f"\n   [{exp_id}] {grid_info['parameter_changed']}={grid_info['parameter_value']}")
                print(f"   Progress: {completed_count}/{total_experiments}")

                try:
                    # Prepare data (reuse Phase 1 data if max_length unchanged)
                    data_dir = prepare_data(
                        model_name, short_name,
                        train_data, val_data, test_data,
                        label_map, hp["max_length"],
                    )

                    # Train and evaluate
                    result = train_and_evaluate(
                        model_name, short_name, exp_id,
                        data_dir, label_map, hp,
                    )

                    experiment_result = {
                        "model_name": model_name,
                        "short_name": short_name,
                        "experiment_id": exp_id,
                        "parameter_changed": grid_info["parameter_changed"],
                        "parameter_value": grid_info["parameter_value"],
                        "hyperparameters": hp,
                        **result,
                    }
                    all_experiments.append(experiment_result)
                    completed_count += 1

                except Exception as e:
                    print(f"      FAILED: {e}")
                    logger.exception(f"Error: {short_name}/{exp_id}")
                    continue

            # Save after each experiment for resume support
            save_results(all_experiments, len(records), train_data, val_data, test_data)

        # Cleanup between models
        gc.collect()
        if torch.backends.mps.is_available():
            torch.mps.empty_cache()

    # ── Final summary ──
    print("\n" + "=" * 80)
    print("EXPERIMENT COMPLETE — SUMMARY")
    print("=" * 80)

    for model_info in models_to_run:
        sn = model_info["short_name"]
        model_exps = [e for e in all_experiments if e["short_name"] == sn]
        if not model_exps:
            continue

        baseline = next((e for e in model_exps if e["experiment_id"] == "baseline"), None)
        if not baseline:
            continue

        print(f"\n{sn} (baseline F1={baseline['f1_macro']:.4f}):")
        for exp in sorted(model_exps, key=lambda x: x["f1_macro"], reverse=True):
            delta = exp["f1_macro"] - baseline["f1_macro"]
            marker = "***" if exp["experiment_id"] != "baseline" and delta > 0 else "   "
            early = " [early stopped]" if exp.get("early_stopped") else ""
            print(f"  {marker} {exp['experiment_id']:<12} F1={exp['f1_macro']:.4f} "
                  f"(delta={delta:+.4f}){early}")

    print(f"\nTotal experiments: {len(all_experiments)}")
    print("Done!")


if __name__ == "__main__":
    main()
