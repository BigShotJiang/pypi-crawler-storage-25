"""Query classification module for DeBERTa inference."""

from transformer_based.training.predict import QueryClassifier

__all__ = ['QueryClassifier']
