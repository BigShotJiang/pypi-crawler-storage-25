#!/usr/bin/env python3
"""
Test DeBERTa classifier with full conversations instead of single queries.
See how the model handles multi-turn dialogue input.
"""

import json
import time
from pathlib import Path
import torch
import torch.nn.functional as F
from transformers import AutoModelForSequenceClassification, AutoTokenizer

# Model path
MODEL_PATH = Path(__file__).parent.parent / "models" / "deberta" / "final_model"

# Load model and tokenizer
print("Loading DeBERTa model...")
tokenizer = AutoTokenizer.from_pretrained(str(MODEL_PATH))
model = AutoModelForSequenceClassification.from_pretrained(str(MODEL_PATH))
model.eval()

# Load label map
with open(MODEL_PATH / "label_map.json") as f:
    label_map = json.load(f)

id_to_label = label_map["id_to_label"]
print(f"Model loaded! Categories: {list(label_map['label_to_id'].keys())}\n")


def classify_text(text: str) -> dict:
    """Classify any text input and return results."""
    start = time.time()

    # Tokenize
    inputs = tokenizer(
        text,
        return_tensors="pt",
        truncation=True,
        max_length=512,  # DeBERTa max length
        padding=True
    )

    # Get token count
    token_count = len(inputs["input_ids"][0])
    truncated = token_count >= 512

    # Run inference
    with torch.no_grad():
        outputs = model(**inputs)
        logits = outputs.logits
        probabilities = F.softmax(logits, dim=-1)[0]

        predicted_class = torch.argmax(probabilities).item()
        confidence = probabilities[predicted_class].item()

    latency = time.time() - start

    # Get all scores
    all_scores = {}
    sorted_indices = torch.argsort(probabilities, descending=True)
    for idx in sorted_indices:
        idx_int = idx.item()
        label = id_to_label[str(idx_int)]
        score = probabilities[idx_int].item()
        all_scores[label] = score

    return {
        "category": id_to_label[str(predicted_class)],
        "confidence": confidence,
        "all_scores": all_scores,
        "tokens": token_count,
        "truncated": truncated,
        "latency_ms": latency * 1000
    }


def print_result(title: str, text: str, result: dict):
    """Pretty print classification result."""
    print(f"\n{'='*70}")
    print(f"TEST: {title}")
    print(f"{'='*70}")
    print(f"INPUT ({result['tokens']} tokens, truncated: {result['truncated']}):")
    print(f"{text[:200]}{'...' if len(text) > 200 else ''}")
    print(f"\nRESULT:")
    print(f"  Category: {result['category']}")
    print(f"  Confidence: {result['confidence']*100:.1f}%")
    print(f"  Latency: {result['latency_ms']:.1f}ms")
    print(f"\nTOP 5 SCORES:")
    for i, (cat, score) in enumerate(list(result['all_scores'].items())[:5]):
        bar = "█" * int(score * 20) + "░" * (20 - int(score * 20))
        print(f"  {cat:25} {bar} {score*100:.1f}%")


# =============================================================================
# TEST CASES
# =============================================================================

print("\n" + "="*70)
print("TESTING DEBERTA WITH CONVERSATIONS")
print("="*70)

# Test 1: Single query (baseline)
test1 = "What are the side effects of metformin?"
result1 = classify_text(test1)
print_result("Single Query (Medical)", test1, result1)

# Test 2: Simple 2-turn conversation
test2 = """User: I have a headache and fever.
Assistant: I'm sorry to hear that. Have you taken any medication?
User: No, should I take ibuprofen?"""
result2 = classify_text(test2)
print_result("2-Turn Medical Conversation", test2, result2)

# Test 3: Multi-turn coding conversation
test3 = """User: How do I sort a list in Python?
Assistant: You can use the sorted() function or the .sort() method.
User: What's the difference between them?
Assistant: sorted() returns a new list, .sort() modifies in place.
User: Can you show me an example with custom sorting?"""
result3 = classify_text(test3)
print_result("Multi-turn Coding Conversation", test3, result3)

# Test 4: Mixed conversation (starts casual, becomes technical)
test4 = """User: Hey, how's it going?
Assistant: I'm doing well, thanks for asking! How can I help you today?
User: I need help with my Python code.
Assistant: Sure! What's the issue?
User: I'm getting a TypeError when I try to concatenate a string and integer."""
result4 = classify_text(test4)
print_result("Mixed Conversation (Casual → Code)", test4, result4)

# Test 5: Legal consultation conversation
test5 = """User: I signed a contract with a non-compete clause.
Assistant: Non-compete clauses can vary in enforceability. What state are you in?
User: California.
Assistant: California generally doesn't enforce non-compete agreements for employees.
User: So I can take a job with a competitor?"""
result5 = classify_text(test5)
print_result("Legal Consultation Conversation", test5, result5)

# Test 6: Finance conversation
test6 = """User: Should I invest in index funds or individual stocks?
Assistant: It depends on your risk tolerance and investment goals.
User: I'm 30 and saving for retirement.
Assistant: At your age, a diversified portfolio with some growth stocks could work.
User: What about tax-advantaged accounts like 401k?"""
result6 = classify_text(test6)
print_result("Finance Conversation", test6, result6)

# Test 7: Long conversation (test truncation)
test7 = """User: I need to build a REST API.
Assistant: What language and framework are you planning to use?
User: Python with FastAPI.
Assistant: Great choice! FastAPI is fast and has automatic documentation.
User: How do I handle authentication?
Assistant: You can use OAuth2 with JWT tokens. FastAPI has built-in support.
User: Can you show me how to implement JWT authentication?
Assistant: Sure! First, install python-jose and passlib.
User: What about database integration?
Assistant: You can use SQLAlchemy with async support.
User: How do I handle database migrations?
Assistant: Alembic is the standard tool for SQLAlchemy migrations.
User: What about testing the API?
Assistant: Use pytest with httpx for async API testing.
User: How do I deploy it?
Assistant: Docker with Kubernetes or a platform like Railway/Render.
User: What about monitoring and logging?"""
result7 = classify_text(test7)
print_result("Long Code Conversation (14 turns)", test7, result7)

# Test 8: Conversation with system prompt
test8 = """System: You are a medical assistant. Always recommend consulting a doctor.
User: I've been having chest pain for 2 days.
Assistant: Chest pain can be serious. Please describe the pain - is it sharp or dull?
User: It's a dull ache that gets worse when I breathe deeply.
Assistant: This could be pleurisy or a rib injury. Please see a doctor immediately."""
result8 = classify_text(test8)
print_result("Conversation with System Prompt (Medical)", test8, result8)

# Test 9: Just the last user message from conversation
test9_full = """User: Hey, how's it going?
Assistant: I'm doing well! How can I help?
User: I need to calculate compound interest for my savings."""
test9_last = "I need to calculate compound interest for my savings."
result9_full = classify_text(test9_full)
result9_last = classify_text(test9_last)
print_result("Full Conversation", test9_full, result9_full)
print_result("Last Message Only", test9_last, result9_last)

# Summary
print("\n" + "="*70)
print("SUMMARY")
print("="*70)
print("""
Key Observations:
1. Single queries: Model trained on these - works as expected
2. Short conversations: Model picks up on the dominant topic
3. Long conversations: May get truncated at 512 tokens
4. Mixed topics: Classifies based on overall content weight
5. Last message vs full: May give different results

Recommendations for your use case:
- If routing based on latest user intent: Extract last user message
- If routing based on conversation topic: Use full conversation
- For very long conversations: Consider summarizing or using last N turns
""")
