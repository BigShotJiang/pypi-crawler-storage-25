#!/usr/bin/env python3
"""
Test script for DeBERTa query classification.
Tests single query and batch classification.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.training.predict import QueryClassifier

# Test queries
TEST_QUERIES = [
    ("How do I implement a binary search in Python?", "CODE"),
    ("What are the side effects of metformin?", "MEDICAL"),
    ("Is this non-compete clause enforceable?", "LEGAL"),
    ("What's the best investment strategy for retirement?", "FINANCE"),
    ("If A > B and B > C, what can we conclude?", "REASONING"),
    ("Write a poem about the ocean", "CREATIVE_WRITING"),
    ("What is the capital of France?", "FACTUAL_KNOWLEDGE"),
    ("Hi there! How are you doing today?", "CONVERSATIONAL"),
    ("Pouvez-vous m'aider en français?", "MULTILINGUAL"),
    ("Summarize this article in bullet points", "SUMMARIZATION"),
]


def test_single_classification(classifier):
    """Test single query classification."""
    print("=" * 60)
    print("TEST 1: Single Query Classification")
    print("=" * 60)

    correct = 0
    total = len(TEST_QUERIES)

    for query, expected in TEST_QUERIES:
        result = classifier.classify(query)
        predicted = result['category']
        confidence = result['confidence']

        match = "✓" if predicted == expected else "✗"
        if predicted == expected:
            correct += 1

        print(f"\n  {match} Query: {query[:45]}...")
        print(f"    Expected: {expected}")
        print(f"    Got: {predicted} ({confidence*100:.1f}%)")

    accuracy = correct / total * 100
    print(f"\n  Accuracy: {correct}/{total} ({accuracy:.1f}%)")
    return accuracy >= 70  # Pass if >= 70% correct


def test_batch_classification(classifier):
    """Test batch classification."""
    print("\n" + "=" * 60)
    print("TEST 2: Batch Classification")
    print("=" * 60)

    queries = [q[0] for q in TEST_QUERIES[:5]]

    print(f"\n  Classifying {len(queries)} queries in batch...")
    results = classifier.classify_batch(queries)

    print(f"\n  Results:")
    for r in results:
        print(f"    - {r['category']}: {r['query'][:40]}... ({r['confidence']*100:.0f}%)")

    return len(results) == len(queries)


def test_all_scores(classifier):
    """Test getting all category scores."""
    print("\n" + "=" * 60)
    print("TEST 3: All Category Scores")
    print("=" * 60)

    query = "How do I implement authentication in FastAPI?"
    result = classifier.classify(query, return_all_scores=True)

    print(f"\n  Query: {query}")
    print(f"  Primary: {result['category']} ({result['confidence']*100:.1f}%)")
    print(f"\n  All Scores:")

    sorted_scores = sorted(result['all_scores'].items(), key=lambda x: x[1], reverse=True)
    for cat, score in sorted_scores[:5]:
        bar = "█" * int(score * 30)
        print(f"    {cat:<25} {score*100:5.1f}% {bar}")

    return 'all_scores' in result and len(result['all_scores']) > 0


def main():
    print("\n" + "#" * 60)
    print("# DeBERTa Query Classification Test")
    print("#" * 60)

    # Load model
    model_path = Path(__file__).parent.parent / "models" / "deberta" / "final_model"
    print(f"\nLoading model from: {model_path}")

    if not model_path.exists():
        print(f"ERROR: Model not found at {model_path}")
        return

    classifier = QueryClassifier(str(model_path))
    print(f"Model loaded! Device: {classifier.device}")
    print(f"Categories: {classifier.num_labels}")

    # Run tests
    tests = [
        ("Single Classification", lambda: test_single_classification(classifier)),
        ("Batch Classification", lambda: test_batch_classification(classifier)),
        ("All Scores", lambda: test_all_scores(classifier)),
    ]

    results = []
    for name, test_fn in tests:
        try:
            success = test_fn()
            results.append((name, "PASS" if success else "FAIL"))
        except Exception as e:
            print(f"  Error: {e}")
            results.append((name, "ERROR"))

    # Summary
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print("=" * 60)
    for name, status in results:
        emoji = "✓" if status == "PASS" else "✗"
        print(f"  {emoji} {name}: {status}")

    print("\n" + "#" * 60)
    print("# Tests Complete")
    print("#" * 60 + "\n")


if __name__ == "__main__":
    main()
