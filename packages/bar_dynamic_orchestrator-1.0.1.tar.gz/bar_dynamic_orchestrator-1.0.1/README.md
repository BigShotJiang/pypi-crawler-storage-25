# Synthetic Data Generator and RAG Router

This repository contains a dataset generation pipeline and a retrieval-based query router. The root project started as a synthetic data generator for 11 query categories, and the RAG router was added as a separate approach for classifying new queries by retrieving similar past examples.

The important point is that this RAG implementation is not a generic chat RAG system. It does not retrieve documents and feed them into an LLM to generate an answer. It retrieves labeled queries from a persistent vector store, optionally enriches retrieval with BM25, optionally reranks the candidates, and then predicts the final category by weighted voting.

## Picture First

Think of the system like this:

```mermaid
flowchart TD
	A["A new user query"] --> B["Turn the query into numbers"]
	B --> C["Search old labeled queries"]
	C --> D{"Use BM25 too?"}
	D -- "No" --> E["Use dense vector matches"]
	D -- "Yes" --> F["Mix dense + keyword matches"]
	E --> G{"Use reranker too?"}
	F --> G
	G -- "No" --> H["Vote by similarity"]
	G -- "Yes" --> I["Rerank the candidates"]
	I --> H
	H --> J["Return category + confidence"]
```

Very simply:

- the query becomes a vector
- the vector finds similar old queries
- the old queries already have labels
- the labels vote for the answer
- the winner becomes the final category

## Tiny Example

Imagine the store has just two labeled queries:

- Query A: "How do I sort a list in Python?" -> category = `CODE`
- Query B: "Summarize this paragraph in 3 bullets" -> category = `SUMMARIZATION`

When a new query comes in, like "How can I order a Python list?", the router does not try to invent a new answer from scratch. It first turns that text into a vector, then looks for the closest stored queries.

```mermaid
flowchart TD
	N["New query: How can I order a Python list?"] --> E["Turn text into embedding numbers"]
	E --> D["Dense search in ChromaDB"]
	E --> K["BM25 keyword search"]
	D --> R["Nearest stored query example"]
	K --> R
	R --> V["Vote using the stored category"]
	V --> F["Final category: CODE"]
```

What is stored for each example:

- the query text itself, as the `document`
- the category, inside `metadata`
- the embedding vector, as the dense representation
- the ID, so the record can be tracked and excluded from evaluation if needed

So in simple words:

- Chroma stores the query meaning as numbers
- metadata stores the label like `CODE`
- dense retrieval finds similar meaning
- BM25 finds similar words
- the final label comes from the retrieved neighbors

## What This Repository Does

The repository supports three related workflows:

1. Generate, label, and filter synthetic training data.
2. Ingest labeled queries into a RAG similarity index.
3. Evaluate several routing approaches against the same label space.

The RAG router is the most relevant part if you want to understand the retrieval system itself. The core files are:

- [rag_router/router.py](rag_router/router.py)
- [rag_router/store/chroma_store.py](rag_router/store/chroma_store.py)
- [rag_router/store/bm25_store.py](rag_router/store/bm25_store.py)
- [rag_router/store/hybrid_store.py](rag_router/store/hybrid_store.py)
- [rag_router/reranker/cross_encoder.py](rag_router/reranker/cross_encoder.py)
- [rag_router/scripts/ingest.py](rag_router/scripts/ingest.py)
- [rag_router/evaluation/evaluator.py](rag_router/evaluation/evaluator.py)
- [rag_router/config/settings.py](rag_router/config/settings.py)

## Quick Start

### 1. Install Dependencies

```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 2. Set Environment Variables

The router uses OpenAI embeddings at ingestion and query time.

```bash
export OPENAI_API_KEY="your-api-key-here"
```

Or create a `.env` file in the project root:

```bash
OPENAI_API_KEY=your-api-key-here
```

### 3. Ingest Labeled Data

```bash
python -m rag_router.scripts.ingest
```

This samples the labeled JSONL dataset, creates embeddings, and stores them in ChromaDB.

### 4. Run the Router

```bash
python -m rag_router.scripts.run_router --query "How do I reset my password?"
```

Interactive mode:

```bash
python -m rag_router.scripts.run_router --interactive
```

### 5. Run Experiments

```bash
python -m rag_router.scripts.run_experiments
```

This evaluates k, threshold, reranking, hybrid search, embedding model, and seed size.

## RAG Router Overview

Your router is a retrieval-based classifier. The full path is:

1. Embed the incoming query.
2. Search the persistent vector store for the nearest labeled examples.
3. Optionally blend dense retrieval with BM25.
4. Optionally rerank the candidates with a cross-encoder.
5. Convert the retrieved examples into category votes.
6. Return the final category, confidence, and neighbor explanations.

The logic is implemented in [rag_router/router.py](rag_router/router.py).

### Why This Design Makes Sense

The design is practical because it gives you:

- explainability, since every prediction comes with nearest neighbors
- low training overhead, since you do not fine-tune a classifier
- modularity, since dense retrieval, BM25, and reranking can be switched on separately
- reproducibility, since the same store can be evaluated across many configurations

This is especially useful for a thesis or research comparison where you want to study tradeoffs instead of hiding them behind a single black-box model.

## How Data Is Stored

### 1. Raw dataset

The source data is a labeled JSONL file such as `data/final/corrected_20260211_002413.jsonl`. Each record contains a query, an ID, and a category.

### 2. Ingested subset

The ingest script samples a stratified subset by category so the index stays balanced. That is done in [rag_router/scripts/ingest.py](rag_router/scripts/ingest.py).

### 3. Vector store

Queries are embedded and stored in ChromaDB with metadata:

- `id` as the document identifier
- `documents` as the original query text
- `embeddings` as the dense vector representation
- `metadatas` containing the category

The store is persistent and uses cosine distance:

- persistent directory: `rag_router/data/chromadb`
- collection name: `query_categories_v1`

That behavior is defined in [rag_router/store/chroma_store.py](rag_router/store/chroma_store.py).

```mermaid
flowchart LR
	A["JSONL dataset"] --> B["Sample by category"]
	B --> C["Create embeddings"]
	C --> D["Save to ChromaDB"]
	D --> E["Store text + vector + category"]
	D --> F["Save ingested_ids.json"]
```

### 4. Leakage control

The ingest step saves the IDs of the examples that were inserted into the store in `rag_router/data/ingested_ids.json`. The evaluator uses that file to exclude those IDs from evaluation, which prevents the same records from being both in the retrieval index and in the test set.

This exclusion logic is one of the most important pieces in the whole project because without it your evaluation would be inflated by leakage.

### 5. BM25 index

BM25 is not stored separately on disk. It is built from the documents already inside ChromaDB when hybrid search is enabled. That means the sparse index is derived from the dense store rather than being a separate primary source of truth.

```mermaid
flowchart LR
	A["ChromaDB documents"] --> B["Lowercase + split"]
	B --> C["BM25 index"]
	D["New query text"] --> E["BM25 scoring"]
	C --> E
```

## How Ingestion Works

The ingestion pipeline is in [rag_router/scripts/ingest.py](rag_router/scripts/ingest.py).

### Step-by-step

1. Load the JSONL dataset.
2. Keep only valid categories from the configured label set.
3. Sample a fixed number of examples per category.
4. Embed all sampled queries in batches.
5. Add the records to ChromaDB.
6. Save the ingested IDs to disk.

### Why it is done this way

This approach gives you a balanced retrieval corpus. If one category dominates the store, the router can over-predict that class. Stratified sampling helps the neighbor vote remain fair across categories.

### Current ingestion settings

The key settings are defined in [rag_router/config/settings.py](rag_router/config/settings.py):

- default embedding model: `text-embedding-3-small`
- default k: `5`
- minimum similarity threshold: `0.5`
- seed per category: `180`

## How Retrieval Works

The main routing path is in [rag_router/router.py](rag_router/router.py).

### 1. Embed the input query

The query is sent to the embedding client, which returns the vector and the token count. The token count is only used for cost tracking.

### 2. Decide how many candidates to fetch

If reranking is off, the router fetches `k` neighbors.

If reranking is on, it fetches `reranker_top_n` first, then reranks down to the final `k`.

### 3. Search the store

There are two retrieval paths:

- vector-only dense retrieval from ChromaDB
- hybrid retrieval from ChromaDB plus BM25

Dense retrieval returns the most semantically similar queries by cosine distance. Hybrid retrieval fuses dense similarity and BM25 relevance scores.

### 4. Optional reranking

If enabled, the router converts retrieval results into candidate objects and sends query-document pairs to a cross-encoder. The cross-encoder scores the pair jointly, which is more accurate than cosine similarity but much slower.

```mermaid
flowchart TD
	A["Top candidates from retrieval"] --> B["Pair each one with the query"]
	B --> C["Cross-encoder scores every pair"]
	C --> D["Sort by reranker score"]
	D --> E["Keep the best K"]
```

### 5. Weighted vote

The final category is chosen by weighted majority vote. For every retrieved neighbor above the similarity threshold, the similarity score is added to that category’s weight. The category with the highest accumulated weight wins.

If no neighbor is above the threshold, the router falls back to the best neighbor and gives a lower-confidence prediction.

```mermaid
flowchart TD
	A["Neighbor 1"] --> D["Add similarity to its category"]
	B["Neighbor 2"] --> D
	C["Neighbor 3"] --> D
	D --> E{"Which category has the biggest total?"}
	E --> F["That category wins"]
```

### 6. Return explainability data

The response includes:

- final category
- confidence
- retrieval method description
- reasoning string
- token count
- estimated embedding cost
- retrieved neighbors
- latency

This makes the router easy to inspect during evaluation and in the CLI.

## Dense Retrieval

Dense retrieval is the default retrieval mode.

It works well because semantically similar queries often do not share the exact same words. For example, these can still be close in embedding space:

- “How do I reset my password?”
- “I forgot my login credentials”

The embedding model used here is [rag_router/store/embeddings.py](rag_router/store/embeddings.py), which wraps OpenAI embeddings and tracks token usage plus estimated cost.

### Strengths

- good semantic matching
- simple storage model
- fast enough for interactive routing
- easy to explain with nearest neighbors

### Weaknesses

- can miss exact keyword constraints
- does not understand lexical mismatches perfectly
- quality depends on the embedding model and index composition

## BM25 Sparse Retrieval

BM25 is added for lexical matching.

BM25 is useful when the query contains exact terminology that dense embeddings may underweight. Examples include acronyms, product names, legal phrases, or rare domain vocabulary.

The implementation is in [rag_router/store/bm25_store.py](rag_router/store/bm25_store.py).

### Current implementation choice

The current code tokenizes with `lower().split()`. That is simple, but not ideal for production because it ignores punctuation handling, stopwords, stemming, and subword normalization.

### Why BM25 helps

Dense and sparse retrieval cover different failure modes:

- dense retrieval captures meaning
- BM25 captures exact term overlap

Hybrid search combines both so the router is more robust than either one alone.

## Hybrid Retrieval

Hybrid retrieval lives in [rag_router/store/hybrid_store.py](rag_router/store/hybrid_store.py).

```mermaid
flowchart LR
	A["Dense retrieval score"] --> D["Normalize to 0..1"]
	B["BM25 score"] --> D
	D --> E["alpha * dense + (1-alpha) * BM25"]
	E --> F["Final fused ranking"]
```

### How it works

1. Run dense retrieval in ChromaDB.
2. Run BM25 over the same document set.
3. Normalize both score sets to the same 0 to 1 range.
4. Fuse them using:

```text
score = alpha * dense + (1 - alpha) * sparse
```

5. Sort by the fused score and return the top k.

### Why this is useful

Hybrid search is usually better than pure dense search when:

- the corpus contains many repeated domain terms
- the query is short and keyword-heavy
- exact phrasing matters
- you want a more stable retrieval layer

### Current tradeoff

In your experiments, hybrid search improved over vector-only retrieval. The strongest saved result in this repo is a hybrid configuration with `alpha=0.9` and `text-embedding-3-small`, which reached macro F1 `0.8609`.

## Cross-Encoder Reranking

The reranker is in [rag_router/reranker/cross_encoder.py](rag_router/reranker/cross_encoder.py).

### What it does

The reranker takes a query and a list of candidate documents and scores each pair jointly. This is more precise than cosine similarity because the model evaluates the interaction between the query and each candidate.

### Why it is slower

Reranking is expensive because the model must score many query-document pairs individually. In your saved experiment results, the `bge-reranker` run was much slower than the non-reranked variants and did not produce the best accuracy for this workload.

### When to use reranking

Use reranking when:

- the top candidates are close and ambiguity matters
- you can afford the latency cost
- the query is high value and needs a more careful decision

Do not use it on every query if latency matters.

## Why These Techniques Were Chosen

Your current stack is a pragmatic compromise:

- embeddings give semantic retrieval
- ChromaDB gives persistent, scalable vector storage
- BM25 adds exact-match recall
- reranking improves precision when necessary
- voting turns retrieval into a category decision with transparent reasoning

This is a sensible research design because each layer answers a different question:

- “What is semantically close?”
- “What matches the exact words?”
- “Which of these candidates is actually the best?”
- “Which category do the retrieved examples vote for?”

## What Other Techniques Exist

If you want to compare against other common approaches, here are the main alternatives:

### 1. Pure classifier

Train a transformer classifier directly on labeled queries.

Good when:

- you want the best category accuracy
- you do not need retrieval explanations
- you have enough labeled data

### 2. Generative RAG

Retrieve documents and send them to an LLM to generate a natural-language answer.

Good when:

- the output must be generated text
- explanations matter more than strict classification

This is not what your current router does.

### 3. Vector search only

Fast and simple, but weaker on lexical cases.

### 4. Hybrid dense + sparse retrieval

Usually stronger than vector-only for mixed query styles.

### 5. Reranked retrieval

Higher precision, but more latency and compute.

### 6. Learned routing classifier over retrieval features

Use retrieval features as input to a small classifier.

This can sometimes beat voting, but it loses the direct transparency of a neighbor-based explanation.

## What Your Experiments Show

The experiment harness is in [rag_router/evaluation/evaluator.py](rag_router/evaluation/evaluator.py) and [rag_router/scripts/run_experiments.py](rag_router/scripts/run_experiments.py).

### Measured results from saved runs

| Configuration | Macro F1 | Accuracy | Notes |
|---|---:|---:|---|
| Baseline vector-only | 0.8310 | 0.8360 | Simple Chroma search + vote |
| Vector-only sample run | 0.8368 | 0.8380 | Slightly better same setup |
| Hybrid alpha 0.7 | 0.8431 | 0.8440 | Better than vector-only |
| BM25 reranker run | 0.8235 | 0.8240 | Very slow, not competitive here |
| Embedding small | 0.8360 | 0.8380 | Better than large in your sample |
| Embedding large | 0.8232 | 0.8260 | Higher cost, lower performance here |
| Best combination | 0.8609 | 0.8640 | Best saved RAG result in this repo |

### Practical interpretation

For your dataset, the best measured RAG setup is not reranking-first. It is a hybrid retrieval configuration with the small embedding model and a high alpha value favoring dense retrieval.

```mermaid
flowchart TD
	A["Try many settings"] --> B["Change k"]
	A --> C["Change threshold"]
	A --> D["Change reranker"]
	A --> E["Change hybrid alpha"]
	A --> F["Change embedding model"]
	B --> G["Measure macro F1"]
	C --> G
	D --> G
	E --> G
	F --> G
	G --> H["Keep the best one"]
```

## Best Way To Run This System

If the goal is the best practical routing system inside this repo, the recommendation is:

1. Keep the transformer classifier as the primary production candidate if your priority is classification accuracy.
2. Use the RAG router when you want explanation, retrieval evidence, or low-training-cost routing.
3. For the RAG router, default to `text-embedding-3-small` plus hybrid search.
4. Use reranking only on hard or borderline queries.
5. Tune k, threshold, and alpha on a dedicated validation set.

If you only care about this RAG pipeline, the strongest current configuration is:

- embedding model: `text-embedding-3-small`
- retrieval: hybrid dense + BM25
- alpha: around `0.9`
- k: `5`
- similarity threshold: `0.5`
- reranking: optional, not default

## How To Optimize It

### Retrieval quality

- Replace `lower().split()` BM25 tokenization with a real tokenizer.
- Add stopword removal and normalization.
- Store richer metadata such as language, domain, source type, and scenario type.
- Deduplicate near-identical training examples before ingest.

### Storage and indexing

- Persist the BM25 index or rebuild it only when the store changes.
- Keep separate collections if you compare different embedding models.
- Consider versioning the collection name by dataset and embedding model.

### Latency

- Avoid reranking every query.
- Fetch more candidates only when confidence is low.
- Reduce candidate count for obvious queries.
- Cache repeated queries if your workload has repetition.

### Decision quality

- Tune the threshold on validation data, not by intuition alone.
- Consider reciprocal rank fusion if you want a more robust hybrid merge.
- Use category-specific thresholds if some classes are systematically harder.

### Evaluation quality

- Keep ingested IDs excluded from evaluation.
- Evaluate on held-out queries with balanced category sampling.
- Report accuracy, macro F1, latency, and cost together so the tradeoff is visible.

## Repository Map

### RAG router

- [rag_router/router.py](rag_router/router.py) - main routing logic
- [rag_router/store/chroma_store.py](rag_router/store/chroma_store.py) - persistent vector store wrapper
- [rag_router/store/bm25_store.py](rag_router/store/bm25_store.py) - sparse retrieval index
- [rag_router/store/hybrid_store.py](rag_router/store/hybrid_store.py) - dense + sparse score fusion
- [rag_router/reranker/cross_encoder.py](rag_router/reranker/cross_encoder.py) - cross-encoder reranker
- [rag_router/store/embeddings.py](rag_router/store/embeddings.py) - embedding client and cost tracking
- [rag_router/scripts/ingest.py](rag_router/scripts/ingest.py) - ingest labeled data into ChromaDB
- [rag_router/scripts/run_router.py](rag_router/scripts/run_router.py) - CLI for inference
- [rag_router/scripts/run_experiments.py](rag_router/scripts/run_experiments.py) - experiment sweeps
- [rag_router/evaluation/evaluator.py](rag_router/evaluation/evaluator.py) - evaluation harness
- [rag_router/evaluation/metrics.py](rag_router/evaluation/metrics.py) - RAG-specific metrics
- [rag_router/config/settings.py](rag_router/config/settings.py) - constants and experiment settings

### Data directories

- `data/final/` - labeled datasets used for experiments
- `rag_router/data/chromadb/` - persistent ChromaDB files
- `rag_router/data/ingested_ids.json` - ingested ID list for leakage prevention
- `rag_router/results/` - evaluation outputs and metrics

## Running The RAG Router

### Single query

```bash
python -m rag_router.scripts.run_router --query "What are the side effects of metformin?"
```

### Interactive mode

```bash
python -m rag_router.scripts.run_router --interactive
```

### Re-ingest the store

```bash
python -m rag_router.scripts.ingest --reset
```

### Run the experiment pipeline

```bash
python -m rag_router.scripts.run_experiments
```

### Run only one phase

```bash
python -m rag_router.scripts.run_experiments --phase A
python -m rag_router.scripts.run_experiments --phase B
python -m rag_router.scripts.run_experiments --phase C
```

## Important Caveats

- This router depends on the quality and balance of the ingested examples.
- BM25 is currently simplified and would benefit from better preprocessing.
- Cross-encoder reranking is powerful but expensive.
- The best RAG result in this repo is good, but it still trails the strongest transformer classifier reported in the broader project documentation.

## If You Want The Short Version

Your RAG system works like this: embed the query, retrieve similar labeled queries from a persistent ChromaDB store, optionally combine dense retrieval with BM25, optionally rerank with a cross-encoder, then vote on the category using similarity-weighted neighbors. The current best practical setup is hybrid retrieval with the small embedding model and no default reranker.

## License

MIT License
