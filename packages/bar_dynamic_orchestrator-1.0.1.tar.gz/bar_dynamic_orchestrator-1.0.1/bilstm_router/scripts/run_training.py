"""
CLI entrypoint for BiLSTM training pipeline.

Usage:
    python -m bilstm_router.scripts.run_training
"""

from bilstm_router.training.train import train


def main():
    print("=" * 50)
    print("BiLSTM Router — Training Pipeline")
    print("=" * 50)
    train()


if __name__ == "__main__":
    main()
