"""
Architecture comparison script for Approach 2 deep neural models.

Loads evaluation results for all five architectures, measures
single-query inference latency (batch_size=1, 500 runs), and
prints a comparison table for the thesis.

Usage:
    python -m bilstm_router.scripts.compare_architectures

Prerequisites: All five models must be trained and evaluated:
    BiLSTM          -> bilstm_router/models/best_run/
    TextCNN         -> bilstm_router/models/textcnn/
    C-LSTM          -> bilstm_router/models/clstm/
    BiGRU+Attention -> bilstm_router/models/bigru_attention/
    DPCNN           -> bilstm_router/models/dpcnn/

Output:
    Prints comparison table to terminal.
    Saves bilstm_router/models/comparison_results.json
"""

import json
import os
import time

import torch

from bilstm_router.config.settings import (
    DATASET_PATH,
    EMBEDDING_DIM,
    HIDDEN_SIZE,
    NUM_CLASSES,
    NUM_LSTM_LAYERS,
)
from bilstm_router.model import BiLSTMClassifier
from bilstm_router.models.bigru_attention import BiGRUAttentionClassifier
from bilstm_router.models.clstm import CLSTMClassifier
from bilstm_router.models.dpcnn import DPCNNClassifier
from bilstm_router.models.textcnn import TextCNNClassifier
from bilstm_router.tokenizer import WordTokenizer
from bilstm_router.training.prepare_data import load_jsonl, split_data
from bilstm_router.training.train import get_device

# Number of queries used for latency measurement
LATENCY_WARMUP_RUNS = 50
LATENCY_MEASURE_RUNS = 500


def load_bilstm(save_dir, device):
    """Load BiLSTM from the original best_run directory."""
    vocab_path = os.path.join(save_dir, "vocab.json")
    tokenizer = WordTokenizer.load(vocab_path)

    config_path = os.path.join(save_dir, "training_config.json")
    with open(config_path) as f:
        config = json.load(f)

    model = BiLSTMClassifier(
        vocab_size=config["vocab_size"],
        embedding_dim=config.get("embedding_dim", EMBEDDING_DIM),
        hidden_size=config.get("hidden_size", HIDDEN_SIZE),
        num_classes=config.get("num_classes", NUM_CLASSES),
        num_layers=config.get("num_layers", NUM_LSTM_LAYERS),
        dropout=0.0,
    )
    model.load_state_dict(
        torch.load(
            os.path.join(save_dir, "best_model.pt"),
            map_location=device,
        )
    )
    model.to(device)
    model.eval()
    return model, tokenizer


def load_textcnn(save_dir, device):
    """Load TextCNN from its checkpoint directory."""
    vocab_path = os.path.join(save_dir, "vocab.json")
    tokenizer = WordTokenizer.load(vocab_path)

    config_path = os.path.join(save_dir, "training_config.json")
    with open(config_path) as f:
        config = json.load(f)

    model = TextCNNClassifier(
        vocab_size=config["vocab_size"],
        embedding_dim=config["embedding_dim"],
        num_filters=config["num_filters"],
        filter_sizes=tuple(config["filter_sizes"]),
        num_classes=config["num_classes"],
        dropout=0.0,
    )
    model.load_state_dict(
        torch.load(
            os.path.join(save_dir, "best_model.pt"),
            map_location=device,
        )
    )
    model.to(device)
    model.eval()
    return model, tokenizer


def load_clstm(save_dir, device):
    """Load C-LSTM from its checkpoint directory."""
    vocab_path = os.path.join(save_dir, "vocab.json")
    tokenizer = WordTokenizer.load(vocab_path)

    config_path = os.path.join(save_dir, "training_config.json")
    with open(config_path) as f:
        config = json.load(f)

    model = CLSTMClassifier(
        vocab_size=config["vocab_size"],
        embedding_dim=config["embedding_dim"],
        num_filters=config["num_filters"],
        cnn_kernel_size=config["cnn_kernel_size"],
        hidden_size=config["hidden_size"],
        num_lstm_layers=config["num_lstm_layers"],
        num_classes=config["num_classes"],
        dropout=0.0,
    )
    model.load_state_dict(
        torch.load(
            os.path.join(save_dir, "best_model.pt"),
            map_location=device,
        )
    )
    model.to(device)
    model.eval()
    return model, tokenizer


def load_bigru_attention(save_dir, device):
    """Load BiGRU+Attention from its checkpoint directory."""
    vocab_path = os.path.join(save_dir, "vocab.json")
    tokenizer = WordTokenizer.load(vocab_path)

    config_path = os.path.join(save_dir, "training_config.json")
    with open(config_path) as f:
        config = json.load(f)

    model = BiGRUAttentionClassifier(
        vocab_size=config["vocab_size"],
        embedding_dim=config["embedding_dim"],
        hidden_size=config["hidden_size"],
        num_classes=config["num_classes"],
        num_layers=config["num_layers"],
        dropout=0.0,
    )
    model.load_state_dict(
        torch.load(
            os.path.join(save_dir, "best_model.pt"),
            map_location=device,
        )
    )
    model.to(device)
    model.eval()
    return model, tokenizer


def load_dpcnn(save_dir, device):
    """Load DPCNN from its checkpoint directory."""
    vocab_path = os.path.join(save_dir, "vocab.json")
    tokenizer = WordTokenizer.load(vocab_path)

    config_path = os.path.join(save_dir, "training_config.json")
    with open(config_path) as f:
        config = json.load(f)

    model = DPCNNClassifier(
        vocab_size=config["vocab_size"],
        embedding_dim=config["embedding_dim"],
        num_filters=config["num_filters"],
        num_blocks=config["num_blocks"],
        num_classes=config["num_classes"],
        dropout=0.0,
    )
    model.load_state_dict(
        torch.load(
            os.path.join(save_dir, "best_model.pt"),
            map_location=device,
        )
    )
    model.to(device)
    model.eval()
    return model, tokenizer


def measure_latency(model, tokenizer, queries, device):
    """
    Measure single-query inference latency (batch_size=1).

    Returns dict with mean_ms, p50_ms, p95_ms, p99_ms.
    """
    model.eval()

    def run_one(query):
        ids = tokenizer.encode(query)
        input_ids = torch.tensor([ids], dtype=torch.long).to(device)
        length = torch.tensor([tokenizer.get_length(query)])
        with torch.no_grad():
            _ = model(input_ids, length)

    # Warm up — fills any caches
    for q in queries[:LATENCY_WARMUP_RUNS]:
        run_one(q)

    # Measure
    latencies = []
    for q in queries[:LATENCY_MEASURE_RUNS]:
        start = time.perf_counter()
        run_one(q)
        end = time.perf_counter()
        latencies.append((end - start) * 1000)  # ms

    latencies.sort()
    n = len(latencies)
    return {
        "mean_ms": round(sum(latencies) / n, 2),
        "p50_ms": round(latencies[int(n * 0.50)], 2),
        "p95_ms": round(latencies[int(n * 0.95)], 2),
        "p99_ms": round(latencies[int(n * 0.99)], 2),
    }


def load_eval_results(results_path):
    """Load saved evaluation_results.json, return None if missing."""
    if not os.path.exists(results_path):
        return None
    with open(results_path) as f:
        return json.load(f)


def count_params(model):
    return sum(p.numel() for p in model.parameters())


def main():
    device = get_device()
    project_root = os.path.dirname(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    )
    models_dir = os.path.join(project_root, "bilstm_router", "models")

    bilstm_dir = os.path.join(models_dir, "best_run")
    textcnn_dir = os.path.join(models_dir, "textcnn")
    clstm_dir = os.path.join(models_dir, "clstm")
    bigru_attn_dir = os.path.join(models_dir, "bigru_attention")
    dpcnn_dir = os.path.join(models_dir, "dpcnn")

    print("=" * 85)
    print("  Approach 2 Architecture Comparison")
    print("  BiLSTM  vs  TextCNN  vs  C-LSTM  vs  BiGRU+Attention  vs  DPCNN")
    print("=" * 85)

    # ── Load test queries for latency measurement ────────────────────────────
    records = load_jsonl(DATASET_PATH)
    _, _, test_data = split_data(records)
    test_queries = [r["query"] for r in test_data]
    print(f"\nTest set: {len(test_queries)} queries")
    print(f"Latency measured over {LATENCY_MEASURE_RUNS} single-query runs\n")

    # ── Collect results per architecture ─────────────────────────────────────
    archs = [
        ("BiLSTM", bilstm_dir, load_bilstm),
        ("TextCNN", textcnn_dir, load_textcnn),
        ("C-LSTM", clstm_dir, load_clstm),
        ("BiGRU+Attn", bigru_attn_dir, load_bigru_attention),
        ("DPCNN", dpcnn_dir, load_dpcnn),
    ]

    rows = []
    for name, save_dir, loader_fn in archs:
        results_path = os.path.join(save_dir, "evaluation_results.json")
        eval_results = load_eval_results(results_path)

        if not os.path.exists(save_dir) or eval_results is None:
            print(
                f"  [{name}] NOT FOUND — skipping. "
                "Train and evaluate first."
            )
            rows.append({"arch": name, "status": "missing"})
            continue

        print(f"  [{name}] Loading model for latency measurement...")
        model, tokenizer = loader_fn(save_dir, device)
        params = count_params(model)
        latency = measure_latency(model, tokenizer, test_queries, device)
        print(f"    Params: {params:,} | Latency mean: {latency['mean_ms']}ms")

        rows.append({
            "arch": name,
            "status": "ok",
            "params": params,
            "accuracy": eval_results.get("accuracy"),
            "f1_macro": eval_results.get("f1_macro"),
            "f1_weighted": eval_results.get("f1_weighted"),
            "precision_macro": eval_results.get("precision_macro"),
            "recall_macro": eval_results.get("recall_macro"),
            "latency": latency,
            "per_category_f1": {
                cat: v["f1"]
                for cat, v in eval_results.get("per_category", {}).items()
            },
        })

    # ── Print comparison table ───────────────────────────────────────────────
    available = [r for r in rows if r["status"] == "ok"]

    if not available:
        print("\nNo results available. Train all models first.")
        return

    W = 85
    COL = 13  # column width per arch

    print(f"\n{'='*W}")
    print("COMPARISON TABLE")
    print(f"{'='*W}")

    arch_names = [
        "BiLSTM", "TextCNN", "C-LSTM", "BiGRU+Attn", "DPCNN"
    ]
    header = (
        f"{'Metric':<22}"
        + "".join(f"{n:>{COL}}" for n in arch_names)
    )
    print(header)
    print("-" * W)

    def val(rows_list, arch_name, key, nested=None):
        for r in rows_list:
            if r["arch"] == arch_name and r["status"] == "ok":
                if nested:
                    return str(r.get(key, {}).get(nested, "N/A"))
                v = r.get(key, "N/A")
                return str(v) if v is not None else "N/A"
        return "N/A"

    metrics = [
        ("Parameters",        "params",          None),
        ("Accuracy",          "accuracy",        None),
        ("F1 Macro",          "f1_macro",        None),
        ("F1 Weighted",       "f1_weighted",     None),
        ("Precision Macro",   "precision_macro", None),
        ("Recall Macro",      "recall_macro",    None),
        ("Latency mean (ms)", "latency",         "mean_ms"),
        ("Latency p50 (ms)",  "latency",         "p50_ms"),
        ("Latency p95 (ms)",  "latency",         "p95_ms"),
        ("Latency p99 (ms)",  "latency",         "p99_ms"),
    ]

    for label, key, nested in metrics:
        row_vals = [val(rows, n, key, nested) for n in arch_names]
        print(
            f"{label:<22}"
            + "".join(f"{v:>{COL}}" for v in row_vals)
        )

    print(f"\n{'─'*W}")
    print("PER-CATEGORY F1")
    print(f"{'─'*W}")

    categories = [
        "CODE", "CONVERSATIONAL", "CREATIVE_WRITING",
        "FACTUAL_KNOWLEDGE", "FINANCE", "INSTRUCTION_FOLLOWING",
        "LEGAL", "MEDICAL", "MULTILINGUAL", "REASONING",
        "SUMMARIZATION",
    ]
    cat_header = (
        f"{'Category':<24}"
        + "".join(f"{n:>{COL}}" for n in arch_names)
    )
    print(cat_header)
    print("-" * W)
    for cat in categories:
        cat_vals = [
            val(rows, n, "per_category_f1", cat) for n in arch_names
        ]
        print(
            f"{cat:<24}"
            + "".join(f"{v:>{COL}}" for v in cat_vals)
        )

    # ── Save to JSON ─────────────────────────────────────────────────────────
    output_path = os.path.join(models_dir, "comparison_results.json")
    with open(output_path, "w") as f:
        json.dump(rows, f, indent=2)

    print(f"\nFull results saved to: {output_path}")
    print("=" * W)


if __name__ == "__main__":
    main()
