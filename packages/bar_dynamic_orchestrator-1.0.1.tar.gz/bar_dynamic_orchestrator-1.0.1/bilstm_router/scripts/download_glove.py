"""
Download GloVe 6B 300d embeddings.

Usage:
    python -m bilstm_router.scripts.download_glove
"""

import os
import zipfile
import urllib.request
from pathlib import Path

from bilstm_router.config.settings import DATA_DIR

GLOVE_URL = "https://nlp.stanford.edu/data/glove.6B.zip"
GLOVE_ZIP = os.path.join(DATA_DIR, "glove.6B.zip")
GLOVE_FILE = os.path.join(DATA_DIR, "glove.6B.300d.txt")


def download():
    os.makedirs(DATA_DIR, exist_ok=True)

    if os.path.exists(GLOVE_FILE):
        size_mb = os.path.getsize(GLOVE_FILE) / 1e6
        print(
            f"GloVe already exists: {GLOVE_FILE} "
            f"({size_mb:.0f} MB)"
        )
        return

    print(f"Downloading GloVe from {GLOVE_URL}...")
    print("This is ~862 MB, may take a few minutes.")

    def progress(count, block_size, total_size):
        pct = count * block_size * 100 / total_size
        mb = count * block_size / 1e6
        print(
            f"\r  {mb:.0f}/{total_size/1e6:.0f} MB "
            f"({pct:.1f}%)",
            end="", flush=True,
        )

    urllib.request.urlretrieve(
        GLOVE_URL, GLOVE_ZIP, reporthook=progress
    )
    print("\nDownload complete.")

    print("Extracting glove.6B.300d.txt...")
    with zipfile.ZipFile(GLOVE_ZIP, "r") as z:
        z.extract("glove.6B.300d.txt", DATA_DIR)

    os.remove(GLOVE_ZIP)
    size_mb = os.path.getsize(GLOVE_FILE) / 1e6
    print(f"Done: {GLOVE_FILE} ({size_mb:.0f} MB)")


if __name__ == "__main__":
    download()
