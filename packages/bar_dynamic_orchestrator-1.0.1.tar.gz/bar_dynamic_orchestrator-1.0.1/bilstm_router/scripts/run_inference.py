"""
CLI for testing BiLSTM inference on single queries.

Usage:
    python -m bilstm_router.scripts.run_inference
"""

import json

from bilstm_router.router import BiLSTMRouter


def main():
    print("Loading BiLSTM Router...")
    router = BiLSTMRouter()
    print("Ready!\n")

    test_queries = [
        "Write a Python function to sort a list",
        "What is the capital of France?",
        "Translate hello to Spanish",
        "Summarize the following article about AI",
        "Hi, how are you?",
        "What are the side effects of ibuprofen?",
    ]

    for query in test_queries:
        result = router.route(query)
        print(f"Query: {query}")
        print(f"  Category: {result['final_category']}")
        print(f"  Confidence: {result['category_confidence']}")
        print(f"  Reasoning: {result['category_reasoning']}")
        print()

    # Interactive mode
    print("=" * 40)
    print("Interactive mode (type 'quit' to exit)")
    print("=" * 40)
    while True:
        query = input("\nQuery: ").strip()
        if query.lower() in ("quit", "exit", "q"):
            break
        result = router.route(query)
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
