"""
Unified training script for BiLSTM, TextCNN, C-LSTM, BiGRU+Attention, and DPCNN.

Usage:
    # GloVe (default) — saves to models/{arch}/
    python -m bilstm_router.scripts.train_deep_model --arch bilstm
    python -m bilstm_router.scripts.train_deep_model --arch textcnn
    python -m bilstm_router.scripts.train_deep_model --arch clstm
    python -m bilstm_router.scripts.train_deep_model --arch bigru_attention
    python -m bilstm_router.scripts.train_deep_model --arch dpcnn

    # FastText — saves to models/{arch}_fasttext/  (GloVe runs untouched)
    python -m bilstm_router.scripts.train_deep_model --arch bilstm          --embedding fasttext
    python -m bilstm_router.scripts.train_deep_model --arch textcnn         --embedding fasttext
    python -m bilstm_router.scripts.train_deep_model --arch clstm           --embedding fasttext
    python -m bilstm_router.scripts.train_deep_model --arch bigru_attention --embedding fasttext
    python -m bilstm_router.scripts.train_deep_model --arch dpcnn           --embedding fasttext
"""

import argparse
import json
import os
import time

import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from sklearn.metrics import f1_score

from bilstm_router.config.settings import (
    BATCH_SIZE,
    DATASET_PATH,
    DROPOUT,
    EARLY_STOPPING_PATIENCE,
    EMBEDDING_DIM,
    FREEZE_EMBEDDINGS,
    GLOVE_PATH,
    HIDDEN_SIZE,
    LEARNING_RATE,
    LR_SCHEDULER_FACTOR,
    LR_SCHEDULER_PATIENCE,
    NUM_CLASSES,
    NUM_EPOCHS,
    NUM_LSTM_LAYERS,
    WEIGHT_DECAY,
)
from bilstm_router.model import BiLSTMClassifier
from bilstm_router.models.textcnn import TextCNNClassifier
from bilstm_router.models.clstm import CLSTMClassifier
from bilstm_router.models.bigru_attention import BiGRUAttentionClassifier
from bilstm_router.models.dpcnn import DPCNNClassifier
from bilstm_router.tokenizer import WordTokenizer
from bilstm_router.training.prepare_data import (
    QueryDataset,
    create_label_mapping,
    load_glove_embeddings,
    load_jsonl,
    split_data,
)
from bilstm_router.training.train import collate_fn, get_device

# ── Architecture-specific hyperparameters ────────────────────────────────────
TEXTCNN_NUM_FILTERS = 128
TEXTCNN_FILTER_SIZES = (2, 3, 4, 5)

CLSTM_NUM_FILTERS = 128
CLSTM_CNN_KERNEL_SIZE = 3

BIGRU_ATTN_HIDDEN_SIZE = 256   # same as HIDDEN_SIZE for fair comparison
BIGRU_ATTN_NUM_LAYERS = 1

DPCNN_NUM_FILTERS = 128        # same channel count as TextCNN / C-LSTM
DPCNN_NUM_BLOCKS = 4           # 4 residual+pool rounds: seq 128->64->32->16->8
# ─────────────────────────────────────────────────────────────────────────────


def get_embedding_path(embedding: str, project_root: str) -> str:
    """Return path to the embedding file."""
    data_dir = os.path.join(project_root, "bilstm_router", "data")
    if embedding == "fasttext":
        return os.path.join(data_dir, "crawl-300d-2M.vec")
    return GLOVE_PATH  # glove.6B.300d.txt


def get_save_dir(arch: str, embedding: str, project_root: str) -> str:
    """
    Return save directory for the run.
    GloVe runs → models/{arch}/        (existing folders, untouched)
    FastText runs → models/{arch}_fasttext/  (new folders)
    """
    folder = arch if embedding == "glove" else f"{arch}_fasttext"
    return os.path.join(project_root, "bilstm_router", "models", folder)


def build_model(arch, vocab_size, embed_matrix, device):
    """Instantiate the requested model architecture."""
    if arch == "bilstm":
        model = BiLSTMClassifier(
            vocab_size=vocab_size,
            embedding_dim=EMBEDDING_DIM,
            hidden_size=HIDDEN_SIZE,
            num_classes=NUM_CLASSES,
            num_layers=NUM_LSTM_LAYERS,
            dropout=DROPOUT,
            pretrained_embeddings=embed_matrix,
            freeze_embeddings=FREEZE_EMBEDDINGS,
        )
    elif arch == "textcnn":
        model = TextCNNClassifier(
            vocab_size=vocab_size,
            embedding_dim=EMBEDDING_DIM,
            num_filters=TEXTCNN_NUM_FILTERS,
            filter_sizes=TEXTCNN_FILTER_SIZES,
            num_classes=NUM_CLASSES,
            dropout=DROPOUT,
            pretrained_embeddings=embed_matrix,
            freeze_embeddings=FREEZE_EMBEDDINGS,
        )
    elif arch == "clstm":
        model = CLSTMClassifier(
            vocab_size=vocab_size,
            embedding_dim=EMBEDDING_DIM,
            num_filters=CLSTM_NUM_FILTERS,
            cnn_kernel_size=CLSTM_CNN_KERNEL_SIZE,
            hidden_size=HIDDEN_SIZE,
            num_lstm_layers=NUM_LSTM_LAYERS,
            num_classes=NUM_CLASSES,
            dropout=DROPOUT,
            pretrained_embeddings=embed_matrix,
            freeze_embeddings=FREEZE_EMBEDDINGS,
        )
    elif arch == "bigru_attention":
        model = BiGRUAttentionClassifier(
            vocab_size=vocab_size,
            embedding_dim=EMBEDDING_DIM,
            hidden_size=BIGRU_ATTN_HIDDEN_SIZE,
            num_classes=NUM_CLASSES,
            num_layers=BIGRU_ATTN_NUM_LAYERS,
            dropout=DROPOUT,
            pretrained_embeddings=embed_matrix,
            freeze_embeddings=FREEZE_EMBEDDINGS,
        )
    elif arch == "dpcnn":
        model = DPCNNClassifier(
            vocab_size=vocab_size,
            embedding_dim=EMBEDDING_DIM,
            num_filters=DPCNN_NUM_FILTERS,
            num_blocks=DPCNN_NUM_BLOCKS,
            num_classes=NUM_CLASSES,
            dropout=DROPOUT,
            pretrained_embeddings=embed_matrix,
            freeze_embeddings=FREEZE_EMBEDDINGS,
        )
    else:
        raise ValueError(f"Unknown arch: {arch}")

    return model.to(device)


def evaluate_model(model, dataloader, criterion, device):
    """Return (avg_loss, accuracy, f1_macro)."""
    model.eval()
    total_loss, all_preds, all_labels = 0, [], []

    with torch.no_grad():
        for input_ids, lengths, labels in dataloader:
            input_ids = input_ids.to(device)
            labels = labels.to(device)
            logits = model(input_ids, lengths)
            loss = criterion(logits, labels)
            total_loss += loss.item() * len(labels)
            preds = torch.argmax(logits, dim=1)
            all_preds.extend(preds.cpu().tolist())
            all_labels.extend(labels.cpu().tolist())

    avg_loss = total_loss / len(all_labels)
    f1 = f1_score(all_labels, all_preds, average="macro")
    accuracy = sum(
        p == l for p, l in zip(all_preds, all_labels)
    ) / len(all_labels)
    return avg_loss, accuracy, f1


def save_model(arch, embedding, model, tokenizer, label_info,
               metrics_history, best_f1, save_dir):
    """Save weights, vocab, label map, config, and training metrics."""
    os.makedirs(save_dir, exist_ok=True)

    torch.save(
        model.state_dict(),
        os.path.join(save_dir, "best_model.pt"),
    )
    tokenizer.save(os.path.join(save_dir, "vocab.json"))

    label_map_data = {
        "label_to_id": label_info["label_to_id"],
        "id_to_label": {
            str(k): v for k, v in label_info["id_to_label"].items()
        },
        "num_labels": label_info["num_labels"],
    }
    with open(os.path.join(save_dir, "label_map.json"), "w") as f:
        json.dump(label_map_data, f, indent=2)

    # Config stores arch + embedding so evaluate script can reconstruct
    if arch == "bilstm":
        config = {
            "arch": "bilstm",
            "embedding": embedding,
            "vocab_size": tokenizer.vocab_size,
            "embedding_dim": EMBEDDING_DIM,
            "hidden_size": HIDDEN_SIZE,
            "num_layers": NUM_LSTM_LAYERS,
            "num_classes": NUM_CLASSES,
            "dropout": DROPOUT,
            "best_val_f1": round(best_f1, 4),
        }
    elif arch == "textcnn":
        config = {
            "arch": "textcnn",
            "embedding": embedding,
            "vocab_size": tokenizer.vocab_size,
            "embedding_dim": EMBEDDING_DIM,
            "num_filters": TEXTCNN_NUM_FILTERS,
            "filter_sizes": list(TEXTCNN_FILTER_SIZES),
            "num_classes": NUM_CLASSES,
            "dropout": DROPOUT,
            "best_val_f1": round(best_f1, 4),
        }
    elif arch == "clstm":
        config = {
            "arch": "clstm",
            "embedding": embedding,
            "vocab_size": tokenizer.vocab_size,
            "embedding_dim": EMBEDDING_DIM,
            "num_filters": CLSTM_NUM_FILTERS,
            "cnn_kernel_size": CLSTM_CNN_KERNEL_SIZE,
            "hidden_size": HIDDEN_SIZE,
            "num_lstm_layers": NUM_LSTM_LAYERS,
            "num_classes": NUM_CLASSES,
            "dropout": DROPOUT,
            "best_val_f1": round(best_f1, 4),
        }
    elif arch == "bigru_attention":
        config = {
            "arch": "bigru_attention",
            "embedding": embedding,
            "vocab_size": tokenizer.vocab_size,
            "embedding_dim": EMBEDDING_DIM,
            "hidden_size": BIGRU_ATTN_HIDDEN_SIZE,
            "num_layers": BIGRU_ATTN_NUM_LAYERS,
            "num_classes": NUM_CLASSES,
            "dropout": DROPOUT,
            "best_val_f1": round(best_f1, 4),
        }
    else:  # dpcnn
        config = {
            "arch": "dpcnn",
            "embedding": embedding,
            "vocab_size": tokenizer.vocab_size,
            "embedding_dim": EMBEDDING_DIM,
            "num_filters": DPCNN_NUM_FILTERS,
            "num_blocks": DPCNN_NUM_BLOCKS,
            "num_classes": NUM_CLASSES,
            "dropout": DROPOUT,
            "best_val_f1": round(best_f1, 4),
        }

    with open(os.path.join(save_dir, "training_config.json"), "w") as f:
        json.dump(config, f, indent=2)

    with open(os.path.join(save_dir, "training_metrics.json"), "w") as f:
        json.dump(metrics_history, f, indent=2)


def train(arch, embedding):
    device = get_device()
    project_root = os.path.dirname(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    )
    save_dir = get_save_dir(arch, embedding, project_root)
    embed_path = get_embedding_path(embedding, project_root)

    print("=" * 60)
    print(f"  Architecture : {arch.upper()}")
    print(f"  Embedding    : {embedding} ({embed_path})")
    print(f"  Save dir     : {save_dir}")
    print("=" * 60)

    # ── 1. Check embedding file exists ───────────────────────────────────────
    if not os.path.exists(embed_path):
        print(f"\nERROR: Embedding file not found: {embed_path}")
        if embedding == "fasttext":
            print("\nDownload FastText vectors first:")
            print("  cd bilstm_router/data/")
            print("  wget https://dl.fbaipublicfiles.com/fasttext/vectors-english/crawl-300d-2M.vec.zip")
            print("  unzip crawl-300d-2M.vec.zip")
        else:
            print("  Run: python -m bilstm_router.scripts.download_glove")
        return

    # ── 2. Load and split data ────────────────────────────────────────────────
    print(f"\nLoading data from {DATASET_PATH}...")
    records = load_jsonl(DATASET_PATH)
    print(f"Loaded {len(records)} records")

    label_info = create_label_mapping(records)
    label_to_id = label_info["label_to_id"]
    print(f"Categories: {list(label_to_id.keys())}")

    train_data, val_data, _ = split_data(records)
    print(f"Split: {len(train_data)} train, {len(val_data)} val")

    # ── 3. Build vocabulary ───────────────────────────────────────────────────
    tokenizer = WordTokenizer()
    tokenizer.build_vocab([r["query"] for r in train_data])

    # ── 4. Load embeddings ────────────────────────────────────────────────────
    print(f"\nLoading {embedding} embeddings from {embed_path}...")
    embed_matrix = load_glove_embeddings(
        embed_path, tokenizer.word2idx, EMBEDDING_DIM
    )

    # ── 5. Dataloaders ────────────────────────────────────────────────────────
    train_loader = DataLoader(
        QueryDataset(train_data, tokenizer, label_to_id),
        batch_size=BATCH_SIZE, shuffle=True, collate_fn=collate_fn,
    )
    val_loader = DataLoader(
        QueryDataset(val_data, tokenizer, label_to_id),
        batch_size=BATCH_SIZE, shuffle=False, collate_fn=collate_fn,
    )

    # ── 6. Model ──────────────────────────────────────────────────────────────
    model = build_model(arch, tokenizer.vocab_size, embed_matrix, device)
    total_params = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"\nModel: {total_params:,} total params ({trainable:,} trainable)")

    # ── 7. Optimizer / scheduler / loss ───────────────────────────────────────
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=LEARNING_RATE, weight_decay=WEIGHT_DECAY
    )
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="max",
        factor=LR_SCHEDULER_FACTOR, patience=LR_SCHEDULER_PATIENCE,
    )
    criterion = nn.CrossEntropyLoss()

    # ── 8. Training loop ──────────────────────────────────────────────────────
    best_val_f1 = 0
    patience_counter = 0
    metrics_history = []

    print(f"\nTraining for up to {NUM_EPOCHS} epochs...\n")
    start_time = time.time()

    for epoch in range(NUM_EPOCHS):
        model.train()
        total_loss, num_batches = 0, 0

        for input_ids, lengths, labels in train_loader:
            input_ids = input_ids.to(device)
            labels = labels.to(device)
            optimizer.zero_grad()
            logits = model(input_ids, lengths)
            loss = criterion(logits, labels)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()
            total_loss += loss.item()
            num_batches += 1

        avg_train_loss = total_loss / num_batches
        val_loss, val_acc, val_f1 = evaluate_model(
            model, val_loader, criterion, device
        )
        scheduler.step(val_f1)

        lr = optimizer.param_groups[0]["lr"]
        print(
            f"  Epoch {epoch+1:2d}/{NUM_EPOCHS} | "
            f"Train Loss: {avg_train_loss:.4f} | "
            f"Val Loss: {val_loss:.4f} | "
            f"Val Acc: {val_acc:.4f} | "
            f"Val F1: {val_f1:.4f} | "
            f"LR: {lr:.6f}"
        )

        metrics_history.append({
            "epoch": epoch + 1,
            "train_loss": round(avg_train_loss, 4),
            "val_loss": round(val_loss, 4),
            "val_accuracy": round(val_acc, 4),
            "val_f1_macro": round(val_f1, 4),
            "learning_rate": lr,
        })

        if val_f1 > best_val_f1:
            best_val_f1 = val_f1
            patience_counter = 0
            save_model(
                arch, embedding, model, tokenizer, label_info,
                metrics_history, best_val_f1, save_dir,
            )
            print(f"    -> New best! F1={val_f1:.4f} — model saved")
        else:
            patience_counter += 1
            if patience_counter >= EARLY_STOPPING_PATIENCE:
                print(
                    f"\nEarly stopping at epoch {epoch+1} "
                    f"(no improvement for {EARLY_STOPPING_PATIENCE} epochs)"
                )
                break

    elapsed = time.time() - start_time
    print(f"\nTraining complete in {elapsed:.1f}s")
    print(f"Best validation F1: {best_val_f1:.4f}")
    print(f"Artifacts saved to: {save_dir}")


def main():
    parser = argparse.ArgumentParser(
        description="Train BiLSTM, TextCNN, or C-LSTM classifier"
    )
    parser.add_argument(
        "--arch",
        choices=["bilstm", "textcnn", "clstm", "bigru_attention", "dpcnn"],
        required=True,
        help="Architecture to train",
    )
    parser.add_argument(
        "--embedding",
        choices=["glove", "fasttext"],
        default="glove",
        help="Word embeddings to use (default: glove)",
    )
    args = parser.parse_args()
    train(args.arch, args.embedding)


if __name__ == "__main__":
    main()
