"""
Test-set evaluation for BiLSTM, TextCNN, C-LSTM, BiGRU+Attention, and DPCNN.

Usage:
    # GloVe runs (existing)
    python -m bilstm_router.scripts.evaluate_deep_model --arch bilstm
    python -m bilstm_router.scripts.evaluate_deep_model --arch textcnn
    python -m bilstm_router.scripts.evaluate_deep_model --arch clstm
    python -m bilstm_router.scripts.evaluate_deep_model --arch bigru_attention
    python -m bilstm_router.scripts.evaluate_deep_model --arch dpcnn

    # FastText runs
    python -m bilstm_router.scripts.evaluate_deep_model --arch bigru_attention --embedding fasttext
    python -m bilstm_router.scripts.evaluate_deep_model --arch dpcnn           --embedding fasttext
"""

import argparse
import json
import os

import torch
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    f1_score,
    precision_score,
    recall_score,
)
from torch.utils.data import DataLoader

from bilstm_router.config.settings import (
    BATCH_SIZE,
    DATASET_PATH,
)
from bilstm_router.model import BiLSTMClassifier
from bilstm_router.models.textcnn import TextCNNClassifier
from bilstm_router.models.clstm import CLSTMClassifier
from bilstm_router.models.bigru_attention import BiGRUAttentionClassifier
from bilstm_router.models.dpcnn import DPCNNClassifier
from bilstm_router.tokenizer import WordTokenizer
from bilstm_router.training.prepare_data import (
    QueryDataset,
    create_label_mapping,
    load_jsonl,
    split_data,
)
from bilstm_router.training.train import collate_fn, get_device


def get_save_dir(arch: str, embedding: str, project_root: str) -> str:
    """Return the save directory matching what train_deep_model.py used."""
    folder = arch if embedding == "glove" else f"{arch}_fasttext"
    return os.path.join(project_root, "bilstm_router", "models", folder)


def load_model_from_checkpoint(save_dir, device):
    """Reconstruct model from saved training_config.json and load weights."""
    config_path = os.path.join(save_dir, "training_config.json")
    with open(config_path) as f:
        config = json.load(f)

    arch = config["arch"]

    if arch == "bilstm":
        model = BiLSTMClassifier(
            vocab_size=config["vocab_size"],
            embedding_dim=config["embedding_dim"],
            hidden_size=config["hidden_size"],
            num_classes=config["num_classes"],
            num_layers=config["num_layers"],
            dropout=0.0,
        )
    elif arch == "textcnn":
        model = TextCNNClassifier(
            vocab_size=config["vocab_size"],
            embedding_dim=config["embedding_dim"],
            num_filters=config["num_filters"],
            filter_sizes=tuple(config["filter_sizes"]),
            num_classes=config["num_classes"],
            dropout=0.0,
        )
    elif arch == "clstm":
        model = CLSTMClassifier(
            vocab_size=config["vocab_size"],
            embedding_dim=config["embedding_dim"],
            num_filters=config["num_filters"],
            cnn_kernel_size=config["cnn_kernel_size"],
            hidden_size=config["hidden_size"],
            num_lstm_layers=config["num_lstm_layers"],
            num_classes=config["num_classes"],
            dropout=0.0,
        )
    elif arch == "bigru_attention":
        model = BiGRUAttentionClassifier(
            vocab_size=config["vocab_size"],
            embedding_dim=config["embedding_dim"],
            hidden_size=config["hidden_size"],
            num_classes=config["num_classes"],
            num_layers=config["num_layers"],
            dropout=0.0,
        )
    elif arch == "dpcnn":
        model = DPCNNClassifier(
            vocab_size=config["vocab_size"],
            embedding_dim=config["embedding_dim"],
            num_filters=config["num_filters"],
            num_blocks=config["num_blocks"],
            num_classes=config["num_classes"],
            dropout=0.0,
        )
    else:
        raise ValueError(f"Unknown arch in config: {arch}")

    weights_path = os.path.join(save_dir, "best_model.pt")
    model.load_state_dict(
        torch.load(weights_path, map_location=device)
    )
    model.to(device)
    model.eval()
    return model


def evaluate(arch, embedding):
    device = get_device()
    project_root = os.path.dirname(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    )
    save_dir = get_save_dir(arch, embedding, project_root)

    print("=" * 60)
    print(f"  Evaluating   : {arch.upper()} + {embedding}")
    print(f"  Checkpoint   : {save_dir}")
    print("=" * 60)

    if not os.path.exists(save_dir):
        print(f"\nERROR: No saved model found at {save_dir}")
        print("Train first:")
        print(
            "  python -m bilstm_router.scripts.train_deep_model"
            f" --arch {arch} --embedding {embedding}"
        )
        return

    # ── 1. Load data — same split as training ────────────────────────────────
    print(f"\nLoading data from {DATASET_PATH}...")
    records = load_jsonl(DATASET_PATH)
    label_info = create_label_mapping(records)
    id_to_label = label_info["id_to_label"]
    _, _, test_data = split_data(records)
    print(f"Test set: {len(test_data)} samples")

    # ── 2. Load tokenizer ────────────────────────────────────────────────────
    vocab_path = os.path.join(save_dir, "vocab.json")
    tokenizer = WordTokenizer.load(vocab_path)
    print(f"Vocabulary: {tokenizer.vocab_size} words")

    # ── 3. Load model ────────────────────────────────────────────────────────
    model = load_model_from_checkpoint(save_dir, device)
    total_params = sum(p.numel() for p in model.parameters())
    print(f"Model loaded: {total_params:,} parameters")

    # ── 4. Dataloader ────────────────────────────────────────────────────────
    test_loader = DataLoader(
        QueryDataset(test_data, tokenizer, label_info["label_to_id"]),
        batch_size=BATCH_SIZE, shuffle=False, collate_fn=collate_fn,
    )

    # ── 5. Run predictions ───────────────────────────────────────────────────
    all_preds, all_labels = [], []
    with torch.no_grad():
        for input_ids, lengths, labels in test_loader:
            input_ids = input_ids.to(device)
            logits = model(input_ids, lengths)
            preds = torch.argmax(logits, dim=1)
            all_preds.extend(preds.cpu().tolist())
            all_labels.extend(labels.tolist())

    # ── 6. Compute metrics ───────────────────────────────────────────────────
    accuracy = accuracy_score(all_labels, all_preds)
    f1_macro = f1_score(all_labels, all_preds, average="macro")
    f1_weighted = f1_score(all_labels, all_preds, average="weighted")
    precision_macro = precision_score(all_labels, all_preds, average="macro")
    recall_macro = recall_score(all_labels, all_preds, average="macro")

    label_names = [id_to_label[i] for i in range(len(id_to_label))]
    report = classification_report(
        all_labels, all_preds,
        target_names=label_names, output_dict=True,
    )

    print(f"\n{'='*60}")
    print(f"TEST SET RESULTS — {arch.upper()} + {embedding}")
    print(f"{'='*60}")
    print(f"Accuracy:          {accuracy:.4f}")
    print(f"F1 (macro):        {f1_macro:.4f}")
    print(f"F1 (weighted):     {f1_weighted:.4f}")
    print(f"Precision (macro): {precision_macro:.4f}")
    print(f"Recall (macro):    {recall_macro:.4f}")
    report_str = classification_report(
        all_labels, all_preds, target_names=label_names
    )
    print(f"\n{report_str}")

    # ── 7. Save results ──────────────────────────────────────────────────────
    results = {
        "arch": arch,
        "embedding": embedding,
        "test_samples": len(test_data),
        "total_params": total_params,
        "accuracy": round(accuracy, 4),
        "f1_macro": round(f1_macro, 4),
        "f1_weighted": round(f1_weighted, 4),
        "precision_macro": round(precision_macro, 4),
        "recall_macro": round(recall_macro, 4),
        "per_category": {
            name: {
                "precision": round(report[name]["precision"], 4),
                "recall": round(report[name]["recall"], 4),
                "f1": round(report[name]["f1-score"], 4),
                "support": report[name]["support"],
            }
            for name in label_names
        },
    }

    results_path = os.path.join(save_dir, "evaluation_results.json")
    with open(results_path, "w") as f:
        json.dump(results, f, indent=2)
    print(f"Results saved to: {results_path}")
    return results


def main():
    parser = argparse.ArgumentParser(
        description="Evaluate BiLSTM, TextCNN, or C-LSTM on the test set"
    )
    parser.add_argument(
        "--arch",
        choices=["bilstm", "textcnn", "clstm", "bigru_attention", "dpcnn"],
        required=True,
        help="Architecture to evaluate",
    )
    parser.add_argument(
        "--embedding",
        choices=["glove", "fasttext"],
        default="glove",
        help="Embedding used during training (default: glove)",
    )
    args = parser.parse_args()
    evaluate(args.arch, args.embedding)


if __name__ == "__main__":
    main()
