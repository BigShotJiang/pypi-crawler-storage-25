"""
Training loop for the BiLSTM classifier.
"""

import json
import os
import time

import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from sklearn.metrics import f1_score

from bilstm_router.config.settings import (
    BATCH_SIZE,
    DATASET_PATH,
    DROPOUT,
    EARLY_STOPPING_PATIENCE,
    EMBEDDING_DIM,
    FREEZE_EMBEDDINGS,
    GLOVE_PATH,
    HIDDEN_SIZE,
    LEARNING_RATE,
    LR_SCHEDULER_FACTOR,
    LR_SCHEDULER_PATIENCE,
    MODEL_SAVE_DIR,
    NUM_CLASSES,
    NUM_EPOCHS,
    NUM_LSTM_LAYERS,
    WEIGHT_DECAY,
)
from bilstm_router.model import BiLSTMClassifier
from bilstm_router.tokenizer import WordTokenizer
from bilstm_router.training.prepare_data import (
    QueryDataset,
    create_label_mapping,
    load_glove_embeddings,
    load_jsonl,
    split_data,
)


def get_device():
    if torch.cuda.is_available():
        return torch.device("cuda")
    elif torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


def collate_fn(batch):
    input_ids = torch.stack([b["input_ids"] for b in batch])
    lengths = torch.tensor([b["length"] for b in batch])
    labels = torch.tensor([b["label"] for b in batch])
    return input_ids, lengths, labels


def evaluate_model(model, dataloader, criterion, device):
    """Evaluate model on a dataset, return loss and F1."""
    model.eval()
    total_loss = 0
    all_preds = []
    all_labels = []

    with torch.no_grad():
        for input_ids, lengths, labels in dataloader:
            input_ids = input_ids.to(device)
            labels = labels.to(device)

            logits = model(input_ids, lengths)
            loss = criterion(logits, labels)
            total_loss += loss.item() * len(labels)

            preds = torch.argmax(logits, dim=1)
            all_preds.extend(preds.cpu().tolist())
            all_labels.extend(labels.cpu().tolist())

    avg_loss = total_loss / len(all_labels)
    f1 = f1_score(all_labels, all_preds, average="macro")
    accuracy = sum(
        p == l for p, l in zip(all_preds, all_labels)
    ) / len(all_labels)

    return avg_loss, accuracy, f1


def train():
    device = get_device()
    print(f"Using device: {device}")

    # 1. Load and split data
    print(f"\nLoading data from {DATASET_PATH}...")
    records = load_jsonl(DATASET_PATH)
    print(f"Loaded {len(records)} records")

    label_info = create_label_mapping(records)
    label_to_id = label_info["label_to_id"]
    print(f"Categories: {list(label_to_id.keys())}")

    train_data, val_data, test_data = split_data(records)
    print(
        f"Split: {len(train_data)} train, "
        f"{len(val_data)} val, {len(test_data)} test"
    )

    # 2. Build vocabulary from training data
    tokenizer = WordTokenizer()
    tokenizer.build_vocab([r["query"] for r in train_data])

    # 3. Load GloVe embeddings
    print(f"\nLoading GloVe from {GLOVE_PATH}...")
    glove_matrix = load_glove_embeddings(
        GLOVE_PATH, tokenizer.word2idx, EMBEDDING_DIM
    )

    # 4. Create datasets and dataloaders
    train_dataset = QueryDataset(
        train_data, tokenizer, label_to_id
    )
    val_dataset = QueryDataset(
        val_data, tokenizer, label_to_id
    )

    train_loader = DataLoader(
        train_dataset,
        batch_size=BATCH_SIZE,
        shuffle=True,
        collate_fn=collate_fn,
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=BATCH_SIZE,
        shuffle=False,
        collate_fn=collate_fn,
    )

    # 5. Initialize model
    model = BiLSTMClassifier(
        vocab_size=tokenizer.vocab_size,
        embedding_dim=EMBEDDING_DIM,
        hidden_size=HIDDEN_SIZE,
        num_classes=NUM_CLASSES,
        num_layers=NUM_LSTM_LAYERS,
        dropout=DROPOUT,
        pretrained_embeddings=glove_matrix,
        freeze_embeddings=FREEZE_EMBEDDINGS,
    )
    model.to(device)

    total_params = sum(
        p.numel() for p in model.parameters()
    )
    trainable = sum(
        p.numel() for p in model.parameters()
        if p.requires_grad
    )
    print(
        f"\nModel: {total_params:,} params "
        f"({trainable:,} trainable)"
    )

    # 6. Training setup
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=LEARNING_RATE,
        weight_decay=WEIGHT_DECAY,
    )
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer,
        mode="max",
        factor=LR_SCHEDULER_FACTOR,
        patience=LR_SCHEDULER_PATIENCE,
    )
    criterion = nn.CrossEntropyLoss()

    # 7. Training loop
    best_val_f1 = 0
    patience_counter = 0
    metrics_history = []

    print(f"\nTraining for up to {NUM_EPOCHS} epochs...")
    start_time = time.time()

    for epoch in range(NUM_EPOCHS):
        model.train()
        total_loss = 0
        num_batches = 0

        for input_ids, lengths, labels in train_loader:
            input_ids = input_ids.to(device)
            labels = labels.to(device)

            optimizer.zero_grad()
            logits = model(input_ids, lengths)
            loss = criterion(logits, labels)
            loss.backward()
            nn.utils.clip_grad_norm_(
                model.parameters(), max_norm=1.0
            )
            optimizer.step()

            total_loss += loss.item()
            num_batches += 1

        avg_train_loss = total_loss / num_batches

        # Validate
        val_loss, val_acc, val_f1 = evaluate_model(
            model, val_loader, criterion, device
        )
        scheduler.step(val_f1)

        lr = optimizer.param_groups[0]["lr"]
        print(
            f"  Epoch {epoch+1:2d}/{NUM_EPOCHS} | "
            f"Train Loss: {avg_train_loss:.4f} | "
            f"Val Loss: {val_loss:.4f} | "
            f"Val Acc: {val_acc:.4f} | "
            f"Val F1: {val_f1:.4f} | "
            f"LR: {lr:.6f}"
        )

        metrics_history.append({
            "epoch": epoch + 1,
            "train_loss": round(avg_train_loss, 4),
            "val_loss": round(val_loss, 4),
            "val_accuracy": round(val_acc, 4),
            "val_f1_macro": round(val_f1, 4),
            "learning_rate": lr,
        })

        # Early stopping
        if val_f1 > best_val_f1:
            best_val_f1 = val_f1
            patience_counter = 0
            # Save best model
            _save_model(
                model, tokenizer, label_info,
                metrics_history, best_val_f1,
            )
            print(f"    -> New best! F1={val_f1:.4f}")
        else:
            patience_counter += 1
            if patience_counter >= EARLY_STOPPING_PATIENCE:
                print(
                    f"\nEarly stopping at epoch {epoch+1} "
                    f"(no improvement for "
                    f"{EARLY_STOPPING_PATIENCE} epochs)"
                )
                break

    elapsed = time.time() - start_time
    print(f"\nTraining complete in {elapsed:.1f}s")
    print(f"Best validation F1: {best_val_f1:.4f}")
    print(f"Model saved to: {MODEL_SAVE_DIR}")


def _save_model(model, tokenizer, label_info,
                metrics_history, best_f1):
    """Save model and all artifacts."""
    os.makedirs(MODEL_SAVE_DIR, exist_ok=True)

    # Model weights
    torch.save(
        model.state_dict(),
        os.path.join(MODEL_SAVE_DIR, "best_model.pt"),
    )

    # Tokenizer vocabulary
    tokenizer.save(
        os.path.join(MODEL_SAVE_DIR, "vocab.json")
    )

    # Label map
    label_map_data = {
        "label_to_id": label_info["label_to_id"],
        "id_to_label": {
            str(k): v
            for k, v in label_info["id_to_label"].items()
        },
        "num_labels": label_info["num_labels"],
    }
    with open(
        os.path.join(MODEL_SAVE_DIR, "label_map.json"), "w"
    ) as f:
        json.dump(label_map_data, f, indent=2)

    # Training config (needed to reconstruct model)
    config = {
        "vocab_size": tokenizer.vocab_size,
        "embedding_dim": EMBEDDING_DIM,
        "hidden_size": HIDDEN_SIZE,
        "num_classes": NUM_CLASSES,
        "num_layers": NUM_LSTM_LAYERS,
        "dropout": DROPOUT,
        "best_val_f1": round(best_f1, 4),
    }
    with open(
        os.path.join(MODEL_SAVE_DIR, "training_config.json"),
        "w",
    ) as f:
        json.dump(config, f, indent=2)

    # Metrics history
    with open(
        os.path.join(MODEL_SAVE_DIR, "training_metrics.json"),
        "w",
    ) as f:
        json.dump(metrics_history, f, indent=2)
