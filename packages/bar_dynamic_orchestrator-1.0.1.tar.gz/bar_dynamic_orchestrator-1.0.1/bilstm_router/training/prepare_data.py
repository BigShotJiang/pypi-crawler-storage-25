"""
Data preparation for BiLSTM training.

Uses the EXACT same split logic as DeBERTa (transformer_based/training/prepare_data.py)
for fair comparison: random.seed(42), 80/10/10 split.
"""

import json
import random

import torch
from torch.utils.data import Dataset

from bilstm_router.config.settings import (
    DATASET_PATH,
    GLOVE_PATH,
    RANDOM_SEED,
    TRAIN_RATIO,
    VAL_RATIO,
)


def load_jsonl(file_path):
    """Load records from JSONL file."""
    records = []
    with open(file_path, "r") as f:
        for line in f:
            records.append(json.loads(line))
    return records


def create_label_mapping(records):
    """
    Create label mapping identical to DeBERTa's.
    Categories sorted alphabetically -> numeric IDs.
    """
    categories = sorted(set(r["category"] for r in records))
    label_to_id = {cat: idx for idx, cat in enumerate(categories)}
    id_to_label = {idx: cat for cat, idx in label_to_id.items()}
    return {
        "label_to_id": label_to_id,
        "id_to_label": id_to_label,
        "num_labels": len(categories),
    }


def split_data(records, train_ratio=TRAIN_RATIO,
               val_ratio=VAL_RATIO):
    """
    Split data into train/val/test.

    MUST be identical to DeBERTa's split_data()
    in transformer_based/training/prepare_data.py for fair comparison.
    """
    random.seed(RANDOM_SEED)
    shuffled = records.copy()
    random.shuffle(shuffled)

    n = len(shuffled)
    train_end = int(n * train_ratio)
    val_end = int(n * (train_ratio + val_ratio))

    train_data = shuffled[:train_end]
    val_data = shuffled[train_end:val_end]
    test_data = shuffled[val_end:]

    return train_data, val_data, test_data


def load_glove_embeddings(glove_path, word2idx,
                          embedding_dim=300):
    """
    Build embedding matrix from GloVe file.
    Words not in GloVe get Xavier uniform initialization.
    """
    vocab_size = len(word2idx)
    embedding_matrix = torch.zeros(vocab_size, embedding_dim)
    torch.nn.init.xavier_uniform_(embedding_matrix)
    # PAD stays zero
    embedding_matrix[0] = torch.zeros(embedding_dim)

    found = 0
    with open(glove_path, "r", encoding="utf-8") as f:
        for line in f:
            parts = line.rstrip().split(" ")
            word = parts[0]
            if word in word2idx:
                vector = torch.tensor(
                    [float(x) for x in parts[1:]]
                )
                embedding_matrix[word2idx[word]] = vector
                found += 1

    total = vocab_size - 2  # exclude PAD, UNK
    pct = found / total * 100 if total > 0 else 0
    print(
        f"GloVe coverage: {found}/{total} words ({pct:.1f}%)"
    )
    return embedding_matrix


class QueryDataset(Dataset):
    """PyTorch Dataset for query classification."""

    def __init__(self, records, tokenizer, label_map):
        self.queries = [r["query"] for r in records]
        self.labels = [
            label_map[r["category"]] for r in records
        ]
        self.tokenizer = tokenizer

    def __getitem__(self, idx):
        token_ids = self.tokenizer.encode(self.queries[idx])
        length = self.tokenizer.get_length(self.queries[idx])
        return {
            "input_ids": torch.tensor(
                token_ids, dtype=torch.long
            ),
            "length": length,
            "label": self.labels[idx],
        }

    def __len__(self):
        return len(self.queries)
