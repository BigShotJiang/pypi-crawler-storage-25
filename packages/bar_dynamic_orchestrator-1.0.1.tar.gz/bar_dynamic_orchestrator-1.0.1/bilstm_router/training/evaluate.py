"""
Test set evaluation for the BiLSTM classifier.
"""

import json
import os

import torch
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    f1_score,
    precision_score,
    recall_score,
)
from torch.utils.data import DataLoader

from bilstm_router.config.settings import (
    BATCH_SIZE,
    DATASET_PATH,
    EMBEDDING_DIM,
    HIDDEN_SIZE,
    MODEL_SAVE_DIR,
    NUM_CLASSES,
    NUM_LSTM_LAYERS,
)
from bilstm_router.model import BiLSTMClassifier
from bilstm_router.tokenizer import WordTokenizer
from bilstm_router.training.prepare_data import (
    QueryDataset,
    create_label_mapping,
    load_jsonl,
    split_data,
)
from bilstm_router.training.train import collate_fn, get_device


def evaluate():
    device = get_device()
    print(f"Using device: {device}")

    # 1. Load data and get test split
    print(f"\nLoading data from {DATASET_PATH}...")
    records = load_jsonl(DATASET_PATH)

    label_info = create_label_mapping(records)
    label_to_id = label_info["label_to_id"]
    id_to_label = label_info["id_to_label"]

    _, _, test_data = split_data(records)
    print(f"Test set: {len(test_data)} samples")

    # 2. Load tokenizer
    vocab_path = os.path.join(MODEL_SAVE_DIR, "vocab.json")
    tokenizer = WordTokenizer.load(vocab_path)
    print(f"Loaded vocabulary: {tokenizer.vocab_size} words")

    # 3. Load model
    model = BiLSTMClassifier(
        vocab_size=tokenizer.vocab_size,
        embedding_dim=EMBEDDING_DIM,
        hidden_size=HIDDEN_SIZE,
        num_classes=NUM_CLASSES,
        num_layers=NUM_LSTM_LAYERS,
        dropout=0.0,  # No dropout at inference
    )
    model_path = os.path.join(MODEL_SAVE_DIR, "best_model.pt")
    model.load_state_dict(
        torch.load(model_path, map_location=device)
    )
    model.to(device)
    model.eval()
    print("Model loaded successfully")

    # 4. Create test dataloader
    test_dataset = QueryDataset(
        test_data, tokenizer, label_to_id
    )
    test_loader = DataLoader(
        test_dataset,
        batch_size=BATCH_SIZE,
        shuffle=False,
        collate_fn=collate_fn,
    )

    # 5. Run predictions
    all_preds = []
    all_labels = []

    with torch.no_grad():
        for input_ids, lengths, labels in test_loader:
            input_ids = input_ids.to(device)
            logits = model(input_ids, lengths)
            preds = torch.argmax(logits, dim=1)
            all_preds.extend(preds.cpu().tolist())
            all_labels.extend(labels.tolist())

    # 6. Compute metrics
    accuracy = accuracy_score(all_labels, all_preds)
    f1_macro = f1_score(
        all_labels, all_preds, average="macro"
    )
    f1_weighted = f1_score(
        all_labels, all_preds, average="weighted"
    )
    precision_macro = precision_score(
        all_labels, all_preds, average="macro"
    )
    recall_macro = recall_score(
        all_labels, all_preds, average="macro"
    )

    label_names = [
        id_to_label[i] for i in range(len(id_to_label))
    ]
    report = classification_report(
        all_labels,
        all_preds,
        target_names=label_names,
        output_dict=True,
    )

    print(f"\n{'='*50}")
    print("TEST SET RESULTS")
    print(f"{'='*50}")
    print(f"Accuracy:         {accuracy:.4f}")
    print(f"F1 (macro):       {f1_macro:.4f}")
    print(f"F1 (weighted):    {f1_weighted:.4f}")
    print(f"Precision (macro):{precision_macro:.4f}")
    print(f"Recall (macro):   {recall_macro:.4f}")
    print(f"\n{classification_report(all_labels, all_preds, target_names=label_names)}")

    # 7. Save results
    results = {
        "test_samples": len(test_data),
        "accuracy": round(accuracy, 4),
        "f1_macro": round(f1_macro, 4),
        "f1_weighted": round(f1_weighted, 4),
        "precision_macro": round(precision_macro, 4),
        "recall_macro": round(recall_macro, 4),
        "per_category": {
            name: {
                "precision": round(report[name]["precision"], 4),
                "recall": round(report[name]["recall"], 4),
                "f1": round(report[name]["f1-score"], 4),
                "support": report[name]["support"],
            }
            for name in label_names
        },
    }

    results_path = os.path.join(
        MODEL_SAVE_DIR, "evaluation_results.json"
    )
    with open(results_path, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nResults saved to: {results_path}")

    return results


if __name__ == "__main__":
    evaluate()
