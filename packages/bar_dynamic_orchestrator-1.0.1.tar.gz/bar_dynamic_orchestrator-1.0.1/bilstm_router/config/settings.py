"""
Configuration for the BiLSTM Router (Approach 2).
"""

from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent.parent

VALID_CATEGORIES = [
    "CODE", "CONVERSATIONAL", "CREATIVE_WRITING",
    "FACTUAL_KNOWLEDGE", "FINANCE", "INSTRUCTION_FOLLOWING",
    "LEGAL", "MEDICAL", "MULTILINGUAL", "REASONING",
    "SUMMARIZATION",
]

# Data
DATASET_PATH = str(
    PROJECT_ROOT / "data" / "final"
    / "corrected_20260211_002413.jsonl"
)
RANDOM_SEED = 42
TRAIN_RATIO = 0.8
VAL_RATIO = 0.1

# Vocabulary
MAX_VOCAB_SIZE = 30000
MIN_WORD_FREQ = 2
MAX_SEQ_LENGTH = 128
PAD_TOKEN = "<PAD>"
UNK_TOKEN = "<UNK>"
PAD_IDX = 0
UNK_IDX = 1

# Embeddings
GLOVE_PATH = str(
    PROJECT_ROOT / "bilstm_router" / "data"
    / "glove.6B.300d.txt"
)
EMBEDDING_DIM = 300
FREEZE_EMBEDDINGS = False

# Model
HIDDEN_SIZE = 256
NUM_LSTM_LAYERS = 1
DROPOUT = 0.3
NUM_CLASSES = 11

# Training
BATCH_SIZE = 64
LEARNING_RATE = 1e-3
WEIGHT_DECAY = 1e-4
NUM_EPOCHS = 30
EARLY_STOPPING_PATIENCE = 5
LR_SCHEDULER_FACTOR = 0.5
LR_SCHEDULER_PATIENCE = 2

# Paths
MODEL_SAVE_DIR = str(
    PROJECT_ROOT / "bilstm_router" / "models" / "best_run"
)
DATA_DIR = str(PROJECT_ROOT / "bilstm_router" / "data")
