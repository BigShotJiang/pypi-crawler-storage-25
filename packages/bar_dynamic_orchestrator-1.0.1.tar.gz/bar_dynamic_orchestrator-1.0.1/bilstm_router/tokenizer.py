"""
Word-level tokenizer for the BiLSTM Router.
"""

import json
import re
from collections import Counter

from bilstm_router.config.settings import (
    MAX_SEQ_LENGTH,
    MAX_VOCAB_SIZE,
    MIN_WORD_FREQ,
    PAD_IDX,
    UNK_IDX,
)


class WordTokenizer:
    def __init__(
        self,
        max_vocab_size=MAX_VOCAB_SIZE,
        min_freq=MIN_WORD_FREQ,
        max_length=MAX_SEQ_LENGTH,
    ):
        self.word2idx = {"<PAD>": PAD_IDX, "<UNK>": UNK_IDX}
        self.idx2word = {PAD_IDX: "<PAD>", UNK_IDX: "<UNK>"}
        self.max_vocab_size = max_vocab_size
        self.min_freq = min_freq
        self.max_length = max_length
        self.vocab_size = 2

    def _tokenize(self, text):
        """Split text into lowercase words."""
        return re.findall(r"\b\w+\b", text.lower())

    def build_vocab(self, texts):
        """Build vocabulary from training texts only."""
        counter = Counter()
        for text in texts:
            counter.update(self._tokenize(text))

        # Sort by frequency, take top words
        sorted_words = sorted(
            counter.items(), key=lambda x: x[1], reverse=True
        )

        idx = 2  # 0=PAD, 1=UNK
        for word, freq in sorted_words:
            if freq < self.min_freq:
                break
            if idx >= self.max_vocab_size:
                break
            self.word2idx[word] = idx
            self.idx2word[idx] = word
            idx += 1

        self.vocab_size = idx
        print(
            f"Vocabulary built: {self.vocab_size} words "
            f"(from {len(counter)} unique)"
        )

    def encode(self, text):
        """Convert text to padded list of token IDs."""
        words = self._tokenize(text)
        ids = [
            self.word2idx.get(w, UNK_IDX)
            for w in words[: self.max_length]
        ]
        # Pad to max_length
        ids += [PAD_IDX] * (self.max_length - len(ids))
        return ids

    def get_length(self, text):
        """Get actual token count (before padding)."""
        words = self._tokenize(text)
        return min(len(words), self.max_length)

    def save(self, path):
        """Save vocabulary to JSON."""
        data = {
            "word2idx": self.word2idx,
            "max_vocab_size": self.max_vocab_size,
            "min_freq": self.min_freq,
            "max_length": self.max_length,
            "vocab_size": self.vocab_size,
        }
        with open(path, "w") as f:
            json.dump(data, f)

    @classmethod
    def load(cls, path):
        """Load vocabulary from JSON."""
        with open(path, "r") as f:
            data = json.load(f)
        tok = cls(
            max_vocab_size=data["max_vocab_size"],
            min_freq=data["min_freq"],
            max_length=data["max_length"],
        )
        tok.word2idx = data["word2idx"]
        tok.idx2word = {
            int(k): v
            for k, v in {
                v: k for k, v in data["word2idx"].items()
            }.items()
        }
        tok.vocab_size = data["vocab_size"]
        return tok
