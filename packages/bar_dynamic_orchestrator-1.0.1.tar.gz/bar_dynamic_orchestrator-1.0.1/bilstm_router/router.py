"""
BiLSTM Router — loads trained model and classifies queries.
"""

import json
import os
import time

import torch

from bilstm_router.config.settings import (
    EMBEDDING_DIM,
    HIDDEN_SIZE,
    MODEL_SAVE_DIR,
    NUM_CLASSES,
    NUM_LSTM_LAYERS,
)
from bilstm_router.model import BiLSTMClassifier
from bilstm_router.tokenizer import WordTokenizer
from bilstm_router.training.train import get_device


class BiLSTMRouter:
    """Classifies queries using the trained BiLSTM model."""

    def __init__(self, model_dir=MODEL_SAVE_DIR):
        self.device = get_device()

        # Load tokenizer
        vocab_path = os.path.join(model_dir, "vocab.json")
        self.tokenizer = WordTokenizer.load(vocab_path)

        # Load label map
        label_path = os.path.join(model_dir, "label_map.json")
        with open(label_path, "r") as f:
            label_data = json.load(f)
        self.id_to_label = {
            int(k): v
            for k, v in label_data["id_to_label"].items()
        }

        # Load model
        self.model = BiLSTMClassifier(
            vocab_size=self.tokenizer.vocab_size,
            embedding_dim=EMBEDDING_DIM,
            hidden_size=HIDDEN_SIZE,
            num_classes=NUM_CLASSES,
            num_layers=NUM_LSTM_LAYERS,
            dropout=0.0,
        )
        model_path = os.path.join(model_dir, "best_model.pt")
        self.model.load_state_dict(
            torch.load(model_path, map_location=self.device)
        )
        self.model.to(self.device)
        self.model.eval()

    def route(self, query):
        """
        Classify a query and return result dict.

        Returns dict with:
            final_category, category_confidence,
            is_valid, category_reasoning,
            total_tokens (None — local model),
            estimated_cost_usd (0.0 — local model)
        """
        start = time.time()

        # Tokenize
        token_ids = self.tokenizer.encode(query)
        length = self.tokenizer.get_length(query)

        input_tensor = torch.tensor(
            [token_ids], dtype=torch.long
        ).to(self.device)
        length_tensor = torch.tensor([length])

        # Predict
        with torch.no_grad():
            logits = self.model(input_tensor, length_tensor)
            probs = torch.softmax(logits, dim=1)
            confidence, pred_idx = torch.max(probs, dim=1)

        category = self.id_to_label[pred_idx.item()]
        conf = confidence.item()

        # Get top-3 for reasoning
        top_probs, top_indices = torch.topk(probs[0], k=3)
        top_cats = [
            f"{self.id_to_label[idx.item()]} "
            f"({prob.item():.1%})"
            for prob, idx in zip(top_probs, top_indices)
        ]

        elapsed_ms = (time.time() - start) * 1000

        all_scores = {
            self.id_to_label[i]: round(probs[0][i].item(), 4)
            for i in range(len(self.id_to_label))
        }

        return {
            "final_category": category,
            "category_confidence": round(conf, 4),
            "is_valid": conf >= 0.3,
            "category_reasoning": (
                f"BiLSTM prediction: {' > '.join(top_cats)}. "
                f"Inference: {elapsed_ms:.1f}ms"
            ),
            "all_scores": all_scores,
            "total_tokens": None,
            "estimated_cost_usd": 0.0,
        }
