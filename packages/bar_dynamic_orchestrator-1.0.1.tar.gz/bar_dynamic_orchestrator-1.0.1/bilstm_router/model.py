"""
BiLSTM Classifier model (Approach 2).
"""

import torch
import torch.nn as nn


class BiLSTMClassifier(nn.Module):
    def __init__(
        self,
        vocab_size,
        embedding_dim=300,
        hidden_size=256,
        num_classes=11,
        num_layers=1,
        dropout=0.3,
        pretrained_embeddings=None,
        freeze_embeddings=False,
    ):
        super().__init__()

        self.embedding = nn.Embedding(
            vocab_size, embedding_dim, padding_idx=0
        )
        if pretrained_embeddings is not None:
            self.embedding.weight.data.copy_(
                pretrained_embeddings
            )
        if freeze_embeddings:
            self.embedding.weight.requires_grad = False

        self.lstm = nn.LSTM(
            input_size=embedding_dim,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=True,
            dropout=dropout if num_layers > 1 else 0,
        )

        self.dropout = nn.Dropout(dropout)
        # *2 for bidirectional
        self.fc = nn.Linear(hidden_size * 2, num_classes)

    def forward(self, input_ids, lengths=None):
        # (batch, seq_len) -> (batch, seq_len, embed_dim)
        embedded = self.dropout(self.embedding(input_ids))

        if lengths is not None:
            packed = nn.utils.rnn.pack_padded_sequence(
                embedded,
                lengths.cpu().clamp(min=1),
                batch_first=True,
                enforce_sorted=False,
            )
            _, (h_n, _) = self.lstm(packed)
        else:
            _, (h_n, _) = self.lstm(embedded)

        # h_n: (num_layers*2, batch, hidden)
        # Take last layer forward and backward
        h_forward = h_n[-2]
        h_backward = h_n[-1]
        hidden = torch.cat([h_forward, h_backward], dim=1)

        hidden = self.dropout(hidden)
        logits = self.fc(hidden)
        return logits
