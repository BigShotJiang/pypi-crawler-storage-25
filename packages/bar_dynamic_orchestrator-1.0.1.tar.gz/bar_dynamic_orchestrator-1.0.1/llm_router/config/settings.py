"""
Configuration and settings for the LLM-as-Router approach.

Loads category definitions from the project's shared config files,
but keeps all router-specific settings here.
"""

import json
from pathlib import Path
from typing import Dict, List, Any

# Project root (two levels up from this file)
PROJECT_ROOT = Path(__file__).parent.parent.parent

# Shared config paths
CATEGORIES_PATH = PROJECT_ROOT / "config" / "categories.json"

# Valid categories
VALID_CATEGORIES = [
    "REASONING", "CODE", "CREATIVE_WRITING", "FACTUAL_KNOWLEDGE",
    "INSTRUCTION_FOLLOWING", "CONVERSATIONAL", "MULTILINGUAL",
    "SUMMARIZATION", "MEDICAL", "LEGAL", "FINANCE",
]

# Domain-specific categories that take precedence
DOMAIN_CATEGORIES = ["MEDICAL", "LEGAL", "FINANCE"]

# Prompt strategy identifiers
PROMPT_STRATEGIES = [
    "zero_shot", "few_shot", "chain_of_thought",
    "structured_analysis",
    "dspy_copro", "dspy_bootstrap", "dspy_mipro",
]

# Default router settings
DEFAULT_ROUTER_MODEL = "gpt-4o-mini"
DEFAULT_TEMPERATURE = 0.1
MAX_VALIDATION_RETRIES = 1
MIN_CONFIDENCE_THRESHOLD = 0.6

# ── Evaluation Phase Constants ─────────────────────────────

# Phase 2: OpenAI models to compare
EVAL_OPENAI_MODELS = [
    "gpt-4o-mini", "gpt-4.1-nano",
    "gpt-5-nano", "gpt-5.4-nano",
]

# Phase 3: Cross-provider models (comparable tier)
EVAL_PROVIDERS = {
    "openai": "gpt-4o-mini",
    "anthropic": "claude-haiku-4-5-20251001",
    "google": "gemini-2.5-flash",
    "deepseek": "deepseek-chat",
}

# Phase 8: strategies to run (4 core hand-crafted only)
EVAL_LLMAPI_STRATEGIES = [
    "zero_shot",
    "few_shot",
    "chain_of_thought",
    "structured_analysis",
]

# Phase 8: llmapi.ai — new model families not in Phase 3
# Each entry: (model_id, family_label)
EVAL_LLMAPI_MODELS = [
    # Meta — best open-source instruction follower
    ("llama-3.3-70b-instruct", "meta"),
    # Mistral — European open-source, strong at structured output
    ("mistral-small-2506", "mistral"),
    # xAI — Grok, fast and good at instruction following
    ("grok-3", "xai"),
    # Alibaba — cheapest JSON-capable model ($0.05/1M)
    ("qwen-flash", "alibaba"),
    # DeepSeek v3 — only DeepSeek model with json_output=True on llmapi
    ("deepseek-v3.2", "deepseek"),
    # Google — cheapest Gemini with json_output=True on llmapi
    ("gemini-2.5-flash-lite", "google"),
    # Anthropic — Claude Haiku via llmapi (prompt-based JSON)
    ("claude-haiku-4-5", "anthropic"),
]

# Local models via Ollama (free, runs on laptop)
EVAL_LOCAL_MODELS = [
    "qwen2.5:7b",
    "llama3.2:latest",
    "mistral:latest",
    "phi3:latest",
]

# Phase 5: Temperature values
EVAL_TEMPERATURES = [0.0, 0.1, 0.3, 0.5]

# Phase 6: Confidence thresholds
EVAL_CONFIDENCE_THRESHOLDS = [0.3, 0.6, 0.8]


def load_categories() -> Dict[str, Any]:
    """Load category definitions from config/categories.json."""
    with open(CATEGORIES_PATH, "r") as f:
        data = json.load(f)
    return data["categories"]


def get_category_descriptions() -> Dict[str, str]:
    """Get category name -> description mapping."""
    categories = load_categories()
    return {
        name: info["description"]
        for name, info in categories.items()
    }


def get_category_indicators() -> Dict[str, List[str]]:
    """Get category name -> indicators list mapping."""
    categories = load_categories()
    return {
        name: info["indicators"]
        for name, info in categories.items()
    }


def get_category_keywords() -> Dict[str, List[str]]:
    """Get category name -> keywords list mapping."""
    categories = load_categories()
    return {
        name: info.get("keywords", [])
        for name, info in categories.items()
    }


def format_categories_for_prompt() -> str:
    """
    Format all categories with descriptions and indicators for use in prompts.
    """
    categories = load_categories()
    lines = []
    for name in VALID_CATEGORIES:
        if name not in categories:
            continue
        info = categories[name]
        indicators = ", ".join(info.get("indicators", []))
        keywords = ", ".join(info.get("keywords", []))
        lines.append(
            f"**{name}** — {info['description']}\n"
            f"  Indicators: {indicators}\n"
            f"  Keywords: {keywords}"
        )
    return "\n\n".join(lines)
