"""
Strategy 5: DSPy/COPRO-Optimized Prompting (Single-Call)

Uses a prompt where the INSTRUCTION was automatically
optimized by DSPy's COPRO optimizer. No few-shot examples.
Comparable to zero-shot but with auto-generated instructions.

Optimization run offline via:
    python -m llm_router.scripts.optimize_dspy_prompt \
        --optimizer copro
"""

import json
from pathlib import Path

_PROMPT_FILE = (
    Path(__file__).parent / "dspy_copro_optimized.json"
)
_cached_prompt = None


def _load_optimized_prompt() -> dict:
    """Load the optimized prompt from JSON."""
    global _cached_prompt
    if _cached_prompt is not None:
        return _cached_prompt

    if not _PROMPT_FILE.exists():
        raise FileNotFoundError(
            f"DSPy/COPRO optimized prompt not found at "
            f"{_PROMPT_FILE}.\n"
            f"Run optimization first:\n"
            f"  python -m llm_router.scripts"
            f".optimize_dspy_prompt --optimizer copro"
        )

    with open(_PROMPT_FILE, "r", encoding="utf-8") as f:
        _cached_prompt = json.load(f)
    return _cached_prompt


def get_system_prompt() -> str:
    """Return the COPRO-optimized system prompt."""
    data = _load_optimized_prompt()
    return data["system_prompt"]


def get_user_prompt(query: str) -> str:
    """Format user prompt (same as other strategies)."""
    return f'Query: "{query}"\n\nClassify this query.'
