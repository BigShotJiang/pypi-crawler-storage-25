"""
Strategy 4: Structured Analysis Prompting (Single-Call)

Forces the LLM to fill in a structured analysis template
before making a classification decision.
"""

from llm_router.config.settings import format_categories_for_prompt


def get_system_prompt() -> str:
    categories = format_categories_for_prompt()
    return (
        "You are an LLM routing system. Given a user query, "
        "classify it into exactly ONE category by completing "
        "a structured analysis template.\n\n"
        f"## Categories\n\n{categories}\n\n"
        "## Structured Analysis Template\n\n"
        "You MUST fill in ALL analysis dimensions. Each "
        "dimension helps narrow down the correct category.\n\n"
        "Respond with a JSON object:\n"
        "{\n"
        '  "analysis": {\n'
        '    "domain_check": "MEDICAL | LEGAL | FINANCE '
        '| NONE",\n'
        '    "domain_confidence": "high | medium | low",\n'
        '    "language": "English | other (specify)",\n'
        '    "is_translation_request": true | false,\n'
        '    "requires_code": true | false,\n'
        '    "requires_creative_content": true | false,\n'
        '    "requires_reasoning": true | false,\n'
        '    "requires_summarization": true | false,\n'
        '    "requires_specific_format": true | false,\n'
        '    "is_greeting_or_smalltalk": true | false,\n'
        '    "is_factual_lookup": true | false,\n'
        '    "primary_intent": "informational | '
        "transactional | support | complaint | creative | "
        'technical | conversational"\n'
        "  },\n"
        '  "category": "CATEGORY_NAME",\n'
        '  "confidence": 0.0 to 1.0,\n'
        '  "category_reasoning": "Brief explanation"\n'
        "}\n\n"
        "## Decision Rules (apply in order — STOP at first "
        "match)\n"
        "1. If domain_check != NONE and domain_confidence is "
        "high or medium → use that domain category (MEDICAL, "
        "LEGAL, or FINANCE). Currency conversion, exchange "
        "rates, financial calculations, investments, banking, "
        "payments → FINANCE. Health/medical → MEDICAL. "
        "Legal → LEGAL. Domain categories ALWAYS override "
        "is_factual_lookup.\n"
        "2. If language != English or is_translation_request "
        "→ MULTILINGUAL\n"
        "3. If is_greeting_or_smalltalk → CONVERSATIONAL\n"
        "4. If requires_code → CODE\n"
        "5. If requires_creative_content → CREATIVE_WRITING\n"
        "6. If requires_summarization → SUMMARIZATION\n"
        "7. If requires_specific_format → "
        "INSTRUCTION_FOLLOWING\n"
        "8. If requires_reasoning → REASONING\n"
        "9. If is_factual_lookup AND domain_check is NONE → "
        "FACTUAL_KNOWLEDGE\n"
        "10. Default → FACTUAL_KNOWLEDGE"
    )


def get_user_prompt(query: str) -> str:
    from llm_router.config.prompts.zero_shot import get_user_prompt
    return get_user_prompt(query)
