"""
Strategy 6: DSPy/BootstrapFewShot-Optimized Prompting

Uses a prompt where the FEW-SHOT EXAMPLES were automatically
selected by DSPy's BootstrapFewShot optimizer. Instructions
remain as defined in the signature.
Comparable to few-shot but with auto-selected examples.

Optimization run offline via:
    python -m llm_router.scripts.optimize_dspy_prompt \
        --optimizer bootstrap
"""

import json
from pathlib import Path

_PROMPT_FILE = (
    Path(__file__).parent
    / "dspy_bootstrap_optimized.json"
)
_cached_prompt = None


def _load_optimized_prompt() -> dict:
    """Load the optimized prompt from JSON."""
    global _cached_prompt
    if _cached_prompt is not None:
        return _cached_prompt

    if not _PROMPT_FILE.exists():
        raise FileNotFoundError(
            f"DSPy/Bootstrap optimized prompt not found "
            f"at {_PROMPT_FILE}.\n"
            f"Run optimization first:\n"
            f"  python -m llm_router.scripts"
            f".optimize_dspy_prompt --optimizer bootstrap"
        )

    with open(_PROMPT_FILE, "r", encoding="utf-8") as f:
        _cached_prompt = json.load(f)
    return _cached_prompt


def get_system_prompt() -> str:
    """Return the Bootstrap-optimized system prompt."""
    data = _load_optimized_prompt()
    return data["system_prompt"]


def get_user_prompt(query: str) -> str:
    """Format user prompt (same as other strategies)."""
    return f'Query: "{query}"\n\nClassify this query.'
