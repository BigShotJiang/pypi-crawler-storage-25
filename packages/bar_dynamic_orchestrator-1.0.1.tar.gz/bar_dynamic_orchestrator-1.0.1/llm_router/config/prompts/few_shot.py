"""
Strategy 2: Few-Shot Prompting (Single-Call)

Extends zero-shot with 2-3 example queries per category.
Examples chosen to cover diverse styles: short, long, ambiguous.
"""

from llm_router.config.settings import format_categories_for_prompt


FEW_SHOT_EXAMPLES = {
    "REASONING": [
        "If I cancel my subscription mid-month, how much would my prorated refund be?",
        "Compare the pros and cons of upgrading to the enterprise plan versus keeping the current plan with add-ons.",
        "Why did my bill go up?",
    ],
    "CODE": [
        "How do I integrate your payment API with my React app?",
        "Getting a 403 error when calling the /auth endpoint with my API key.",
        "Show me the webhook payload format.",
    ],
    "CREATIVE_WRITING": [
        "Write a birthday message for my colleague who just got promoted.",
        "I need a catchy tagline for our new product launch.",
        "Draft a thank you email for a customer who provided great feedback.",
    ],
    "FACTUAL_KNOWLEDGE": [
        "What are your store hours?",
        "What payment methods do you accept?",
        "Where is my order?",
    ],
    "INSTRUCTION_FOLLOWING": [
        "List all my transactions from last month in a table format.",
        "Give me step-by-step instructions to set up two-factor authentication.",
        "Summarize my account activity in exactly 5 bullet points.",
    ],
    "CONVERSATIONAL": [
        "Hi there!",
        "Thanks, that's all I needed.",
        "How are you doing today?",
    ],
    "MULTILINGUAL": [
        "Bonjour, pouvez-vous m'aider avec ma commande?",
        "Can you translate this error message to Japanese?",
        "Donde esta mi pedido?",
    ],
    "SUMMARIZATION": [
        "Can you summarize my account activity for the past year?",
        "Give me the key highlights of the new policy changes.",
        "TL;DR on the latest product updates.",
    ],
    "MEDICAL": [
        "What are the side effects of metformin when taken with blood pressure medication?",
        "Should I be worried about persistent headaches after my procedure?",
        "I've been experiencing chest tightness and shortness of breath.",
    ],
    "LEGAL": [
        "Is this non-compete clause legally enforceable in California?",
        "What are my rights if the service was not delivered as described in the contract?",
        "Can they change the terms of service without notifying me?",
    ],
    "FINANCE": [
        "What's the best investment strategy for moderate risk tolerance?",
        "How much is 1 USD in euros right now?",
        "Should I consolidate my credit card debts into a single loan?",
    ],
}


def _format_examples() -> str:
    lines = []
    for category, examples in FEW_SHOT_EXAMPLES.items():
        lines.append(f"\n**{category} examples:**")
        for i, ex in enumerate(examples, 1):
            lines.append(f'  {i}. "{ex}"')
    return "\n".join(lines)


def get_system_prompt() -> str:
    categories = format_categories_for_prompt()
    examples = _format_examples()
    return (
        "You are an LLM routing system. Given a user query, "
        "classify it into exactly ONE category.\n\n"
        f"## Categories\n\n{categories}\n\n"
        f"## Examples\n\nHere are example queries for each category:\n{examples}\n\n"
        "## Classification Rules\n"
        "1. Domain-specific categories (MEDICAL, LEGAL, FINANCE) take HIGHEST PRECEDENCE. "
        "If the query involves ANY financial concept (currency conversion, exchange rates, "
        "investments, loans, banking, payments, stocks, taxes), classify as FINANCE. "
        "If it involves health/medical topics, classify as MEDICAL. "
        "If it involves legal topics, classify as LEGAL.\n"
        "2. If the query contains non-English text or requests translation, classify as "
        "MULTILINGUAL — unless the domain content is clearly MEDICAL, LEGAL, or FINANCE.\n"
        "3. FACTUAL_KNOWLEDGE is ONLY for general knowledge questions with NO domain-specific signals.\n"
        "4. CONVERSATIONAL is only for greetings, small talk, and simple acknowledgments.\n"
        "5. Use examples as guidance, but classify based on actual content — not surface similarity.\n\n"
        "## Response Format\n"
        "Respond with a JSON object:\n"
        "{\n"
        '  "category": "CATEGORY_NAME",\n'
        '  "confidence": 0.0 to 1.0,\n'
        '  "category_reasoning": "Why this category"\n'
        "}"
    )


def get_user_prompt(query: str) -> str:
    from llm_router.config.prompts.zero_shot import get_user_prompt
    return get_user_prompt(query)
