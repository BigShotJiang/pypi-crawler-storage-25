"""
Strategy 1: Zero-Shot Prompting (Single-Call)

Category definitions + rules in one prompt.
No examples provided — baseline approach.
"""

from llm_router.config.settings import format_categories_for_prompt


def get_system_prompt() -> str:
    categories = format_categories_for_prompt()
    return (
        "You are an LLM routing system. Given a user query, "
        "classify it into exactly ONE category.\n\n"
        f"## Categories\n\n{categories}\n\n"
        "## Classification Rules\n"
        "1. Domain-specific categories (MEDICAL, LEGAL, FINANCE) take HIGHEST PRECEDENCE. "
        "If the query involves ANY financial concept (currency conversion, exchange rates, "
        "investments, loans, banking, payments, stocks, taxes), classify as FINANCE. "
        "If it involves health/medical topics, classify as MEDICAL. "
        "If it involves legal topics, classify as LEGAL. "
        "Domain categories OVERRIDE all other categories.\n"
        "2. If the query contains non-English text or requests translation, classify as "
        "MULTILINGUAL — unless the domain content is clearly MEDICAL, LEGAL, or FINANCE.\n"
        "3. FACTUAL_KNOWLEDGE is ONLY for general knowledge questions with NO domain-specific "
        "signals.\n"
        "4. CONVERSATIONAL is only for greetings, small talk, and simple acknowledgments.\n\n"
        "## Response Format\n"
        "Respond with a JSON object:\n"
        "{\n"
        '  "category": "CATEGORY_NAME",\n'
        '  "confidence": 0.0 to 1.0,\n'
        '  "category_reasoning": "Why this category"\n'
        "}"
    )


def get_user_prompt(query: str) -> str:
    return f'Query: "{query}"\n\nClassify this query.'
