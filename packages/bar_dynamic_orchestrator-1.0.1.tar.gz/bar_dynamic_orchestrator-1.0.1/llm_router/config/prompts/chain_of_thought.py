"""
Strategy 3: Chain-of-Thought Prompting (Single-Call)

Asks the LLM to reason step-by-step before making a
classification decision.
"""

from llm_router.config.settings import format_categories_for_prompt


def get_system_prompt() -> str:
    categories = format_categories_for_prompt()
    return (
        "You are an LLM routing system. Given a user query, "
        "classify it into exactly ONE category by following a "
        "step-by-step reasoning process.\n\n"
        f"## Categories\n\n{categories}\n\n"
        "## Step-by-Step Reasoning Process\n\n"
        "You MUST follow these steps in order:\n\n"
        "**Step 1 — Domain Check:** Check if the query is "
        "about a specialized domain.\n"
        "- FINANCE: currency names/codes (USD, EUR, LKR, "
        "GBP), exchange rates, currency conversion, "
        "investments, interest rates, loans, budgets, stocks, "
        "trading, tax, banking, payments, financial "
        "calculations\n"
        "- MEDICAL: symptoms, medications, diagnoses, "
        "treatments, health conditions\n"
        "- LEGAL: contracts, rights, regulations, clauses, "
        "legal procedures\n"
        "If ANY domain signal is present, the category MUST "
        "be that domain. Domain categories take ABSOLUTE "
        "PRECEDENCE.\n\n"
        "**Step 2 — Language Check:** Is the query in a "
        "non-English language or does it request translation? "
        "If yes and NOT a domain query → MULTILINGUAL.\n\n"
        "**Step 3 — Intent Analysis:** What is the user "
        "trying to accomplish?\n"
        "- Greeting/chatting → CONVERSATIONAL\n"
        "- Fact/status/policy → FACTUAL_KNOWLEDGE\n"
        "- Content creation → CREATIVE_WRITING\n"
        "- Code/API/debugging → CODE\n"
        "- Structured output → INSTRUCTION_FOLLOWING\n"
        "- Condensing info → SUMMARIZATION\n"
        "- Analysis/comparison → REASONING\n\n"
        "## Response Format\n"
        "Respond with a JSON object showing your reasoning:\n"
        "{\n"
        '  "step_1_domain_check": "your analysis",\n'
        '  "step_2_language_check": "your analysis",\n'
        '  "step_3_intent_analysis": "your analysis",\n'
        '  "category": "CATEGORY_NAME",\n'
        '  "confidence": 0.0 to 1.0,\n'
        '  "category_reasoning": "One-sentence justification"\n'
        "}"
    )


def get_user_prompt(query: str) -> str:
    from llm_router.config.prompts.zero_shot import get_user_prompt
    return get_user_prompt(query)
