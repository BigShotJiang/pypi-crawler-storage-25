"""
Approach 4: LLM-as-Router

Uses a single LLM call to route queries to optimal models.
A small LLM reasons about the query, business context, and model
capabilities to make routing decisions — no training required,
just prompt engineering.
"""

from llm_router.router import LLMRouter

__all__ = ["LLMRouter"]
