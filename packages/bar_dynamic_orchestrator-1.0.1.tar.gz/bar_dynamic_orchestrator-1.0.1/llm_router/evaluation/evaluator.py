"""
Evaluator for the LLM-as-Router approach.

Runs the router against a labeled dataset and computes
metrics. Supports multi-provider, temperature, and
confidence threshold configuration.
"""

import json
import time
import random
from typing import List, Dict, Any, Optional
from pathlib import Path
from datetime import datetime

from llm_router.router import LLMRouter
from llm_router.evaluation.metrics import (
    compute_metrics,
    save_metrics,
)


class RouterEvaluator:
    """
    Evaluate the LLM router against a labeled dataset.

    Supports configurable provider, model, temperature,
    and confidence threshold for multi-phase evaluation.
    """

    def __init__(
        self,
        model: str = "gpt-4o-mini",
        provider: str = "openai",
    ):
        self.model = model
        self.provider = provider
        self.router = LLMRouter(
            model=model, provider=provider,
        )
        self._multi_step_router = None

    def _get_multi_step_router(self):
        """Lazy-init multi-step router."""
        if self._multi_step_router is None:
            from llm_router.multi_step_router import (
                MultiStepRouter,
            )
            self._multi_step_router = MultiStepRouter(
                model=self.model,
                provider=self.provider,
            )
        return self._multi_step_router

    def load_dataset(
        self,
        dataset_path: str,
        sample_size: Optional[int] = None,
        seed: int = 42,
    ) -> List[Dict]:
        """Load labeled dataset, optionally sampling."""
        records = []
        with open(
            dataset_path, "r", encoding="utf-8"
        ) as f:
            for line in f:
                try:
                    record = json.loads(line.strip())
                    if (
                        "query" in record
                        and "category" in record
                    ):
                        records.append(record)
                except json.JSONDecodeError:
                    continue

        if sample_size and sample_size < len(records):
            random.seed(seed)
            records = random.sample(
                records, sample_size
            )

        print(
            f"Loaded {len(records)} queries "
            f"from {dataset_path}"
        )
        return records

    def evaluate(
        self,
        records: List[Dict],
        prompt_strategy: str = "zero_shot",
        temperature: Optional[float] = None,
        confidence_threshold: Optional[float] = None,
        routing_approach: str = "single_call",
        verbose: bool = False,
    ) -> Dict[str, Any]:
        """
        Run evaluation on a list of labeled records.

        Args:
            records: List with 'query', 'category'
            prompt_strategy: Prompt strategy to evaluate
            temperature: Override default temperature
            confidence_threshold: Override min confidence
            routing_approach: 'single_call' or
                'multi_step'
            verbose: Print per-query results

        Returns:
            Dict with results list and computed metrics
        """
        print(f"\nEvaluating {len(records)} queries")
        print(
            f"Strategy: {prompt_strategy} | "
            f"Model: {self.provider}/{self.model} | "
            f"Approach: {routing_approach}"
        )
        if temperature is not None:
            print(f"Temperature: {temperature}")
        if confidence_threshold is not None:
            print(
                f"Confidence threshold: "
                f"{confidence_threshold}"
            )
        print("=" * 70)

        results = []
        start_time = time.time()

        for i, record in enumerate(records):
            query = record["query"]
            ground_truth = record["category"]
            try:
                if routing_approach == "multi_step":
                    router = (
                        self._get_multi_step_router()
                    )
                    result = router.route(
                        query=query,
                        prompt_strategy=(
                            prompt_strategy
                        ),
                        temperature=temperature,
                        confidence_threshold=(
                            confidence_threshold
                        ),
                    )
                else:
                    result = self.router.route(
                        query=query,
                        prompt_strategy=(
                            prompt_strategy
                        ),
                        temperature=temperature,
                        confidence_threshold=(
                            confidence_threshold
                        ),
                    )

                result["ground_truth_category"] = (
                    ground_truth
                )

                if verbose:
                    pred = result["final_category"]
                    conf = result[
                        "category_confidence"
                    ]
                    ok = (
                        "OK"
                        if pred == ground_truth
                        else "MISS"
                    )
                    print(
                        f"  [{i+1}] {ok} | "
                        f"pred={pred:<25} "
                        f"truth={ground_truth:<25} "
                        f"conf={conf:.2f}"
                    )

            except Exception as e:
                result = {
                    "query": query,
                    "final_category": "ERROR",
                    "ground_truth_category": (
                        ground_truth
                    ),
                    "error": str(e),
                    "category_confidence": 0.0,
                }
                if verbose:
                    print(f"  [{i+1}] ERROR: {e}")

            results.append(result)

            if (i + 1) % 25 == 0 and not verbose:
                elapsed = time.time() - start_time
                correct = sum(
                    1 for r in results
                    if r.get("final_category")
                    == r.get("ground_truth_category")
                )
                rate = (i + 1) / elapsed
                acc = correct / len(results) * 100
                print(
                    f"  [{i+1}/{len(records)}] "
                    f"Acc: {acc:.1f}% | "
                    f"Rate: {rate:.1f} q/s | "
                    f"Elapsed: {elapsed:.0f}s"
                )

        total_time = time.time() - start_time

        metrics = compute_metrics(results)
        qps = (
            round(len(records) / total_time, 2)
            if total_time > 0 else 0
        )

        # Compute cost/latency aggregates
        total_cost = sum(
            r.get("estimated_cost_usd", 0) or 0
            for r in results
        )
        total_tokens = sum(
            r.get("total_tokens", 0) or 0
            for r in results
        )
        avg_confidence = 0.0
        conf_values = [
            r.get("category_confidence", 0)
            for r in results
            if r.get("final_category") != "ERROR"
        ]
        if conf_values:
            avg_confidence = (
                sum(conf_values) / len(conf_values)
            )

        metrics["evaluation_metadata"] = {
            "model": self.model,
            "provider": self.provider,
            "prompt_strategy": prompt_strategy,
            "routing_approach": routing_approach,
            "temperature": temperature,
            "confidence_threshold": (
                confidence_threshold
            ),
            "total_queries": len(records),
            "total_time_seconds": round(
                total_time, 1
            ),
            "queries_per_second": qps,
            "total_cost_usd": round(total_cost, 6),
            "total_tokens": total_tokens,
            "avg_confidence": round(
                avg_confidence, 4
            ),
            "avg_latency_ms": round(
                (total_time / len(records)) * 1000, 1
            ) if records else 0,
            "timestamp": datetime.now().isoformat(),
        }

        return {
            "results": results,
            "metrics": metrics,
        }

    def save_evaluation(
        self,
        evaluation: Dict[str, Any],
        output_dir: str = "llm_router/results",
        strategy: str = "zero_shot",
    ) -> str:
        """Save evaluation results and metrics."""
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        results_file = (
            output_path
            / f"eval_{strategy}_{ts}.jsonl"
        )
        with open(
            results_file, "w", encoding="utf-8"
        ) as f:
            for r in evaluation["results"]:
                f.write(
                    json.dumps(r, ensure_ascii=False)
                    + "\n"
                )

        metrics_file = (
            output_path
            / f"metrics_{strategy}_{ts}.json"
        )
        save_metrics(
            evaluation["metrics"], str(metrics_file)
        )

        print(f"\nResults saved to: {results_file}")
        print(f"Metrics saved to: {metrics_file}")

        return str(results_file)
