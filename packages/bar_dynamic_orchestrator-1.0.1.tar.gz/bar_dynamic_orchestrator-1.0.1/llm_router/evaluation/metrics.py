"""
Evaluation metrics for the LLM-as-Router approach.

Computes accuracy, F1, confusion matrix, cost, and latency metrics.
"""

import json
from typing import Dict, List, Any
from collections import Counter, defaultdict
from pathlib import Path

from llm_router.config.settings import VALID_CATEGORIES


def compute_metrics(results: List[Dict]) -> Dict[str, Any]:
    """
    Compute comprehensive evaluation metrics from routing results.

    Args:
        results: List of dicts with 'final_category' and 'ground_truth_category'

    Returns:
        Dict with accuracy, per-category metrics, confusion matrix, etc.
    """
    # Filter out error results
    valid_results = [
        r for r in results
        if r.get("final_category") and r.get("ground_truth_category")
        and r.get("final_category") != "ERROR"
    ]

    if not valid_results:
        return {"error": "No valid results to evaluate"}

    predictions = [r["final_category"] for r in valid_results]
    ground_truths = [r["ground_truth_category"] for r in valid_results]

    # Overall accuracy
    correct = sum(1 for p, g in zip(predictions, ground_truths) if p == g)
    accuracy = correct / len(valid_results)

    # Per-category metrics
    per_category = _compute_per_category_metrics(predictions, ground_truths)

    # Macro and weighted F1
    f1_scores = [m["f1"] for m in per_category.values() if m["support"] > 0]
    macro_f1 = sum(f1_scores) / len(f1_scores) if f1_scores else 0.0

    total_support = sum(m["support"] for m in per_category.values())
    weighted_f1 = sum(
        m["f1"] * m["support"] / total_support
        for m in per_category.values()
        if m["support"] > 0
    ) if total_support > 0 else 0.0

    # Confusion matrix
    confusion = _build_confusion_matrix(predictions, ground_truths)

    # Confidence analysis
    confidence_stats = _analyze_confidence(valid_results)

    return {
        "total_queries": len(valid_results),
        "accuracy": round(accuracy, 4),
        "correct": correct,
        "incorrect": len(valid_results) - correct,
        "macro_f1": round(macro_f1, 4),
        "weighted_f1": round(weighted_f1, 4),
        "per_category": per_category,
        "confusion_matrix": confusion,
        "confidence_stats": confidence_stats,
    }


def _compute_per_category_metrics(
    predictions: List[str], ground_truths: List[str]
) -> Dict[str, Dict]:
    """Compute precision, recall, F1 per category."""
    metrics = {}

    for category in VALID_CATEGORIES:
        tp = sum(1 for p, g in zip(predictions, ground_truths) if p == category and g == category)
        fp = sum(1 for p, g in zip(predictions, ground_truths) if p == category and g != category)
        fn = sum(1 for p, g in zip(predictions, ground_truths) if p != category and g == category)
        support = sum(1 for g in ground_truths if g == category)

        precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        f1 = (
            2 * precision * recall / (precision + recall)
            if (precision + recall) > 0 else 0.0
        )

        metrics[category] = {
            "precision": round(precision, 4),
            "recall": round(recall, 4),
            "f1": round(f1, 4),
            "support": support,
            "tp": tp,
            "fp": fp,
            "fn": fn,
        }

    return metrics


def _build_confusion_matrix(
    predictions: List[str], ground_truths: List[str]
) -> Dict[str, Dict[str, int]]:
    """Build confusion matrix: ground_truth -> predicted -> count."""
    matrix = defaultdict(lambda: defaultdict(int))
    for pred, truth in zip(predictions, ground_truths):
        matrix[truth][pred] += 1
    return {k: dict(v) for k, v in matrix.items()}


def _analyze_confidence(results: List[Dict]) -> Dict[str, Any]:
    """Analyze confidence scores for correct vs incorrect predictions."""
    correct_confidences = []
    incorrect_confidences = []

    for r in results:
        conf = r.get("category_confidence", 0.0)
        if r["final_category"] == r["ground_truth_category"]:
            correct_confidences.append(conf)
        else:
            incorrect_confidences.append(conf)

    return {
        "correct_avg_confidence": (
            round(sum(correct_confidences) / len(correct_confidences), 4)
            if correct_confidences else 0.0
        ),
        "incorrect_avg_confidence": (
            round(sum(incorrect_confidences) / len(incorrect_confidences), 4)
            if incorrect_confidences else 0.0
        ),
        "correct_count": len(correct_confidences),
        "incorrect_count": len(incorrect_confidences),
    }


def print_metrics_report(metrics: Dict[str, Any]):
    """Print a formatted metrics report."""
    print("\n" + "=" * 80)
    print("EVALUATION METRICS REPORT")
    print("=" * 80)

    if "error" in metrics:
        print(f"\nERROR: {metrics['error']}")
        print("=" * 80)
        return

    print(f"\nOverall Accuracy:  {metrics['accuracy']:.1%} "
          f"({metrics['correct']}/{metrics['total_queries']})")
    print(f"Macro F1:          {metrics['macro_f1']:.4f}")
    print(f"Weighted F1:       {metrics['weighted_f1']:.4f}")

    # Per-category table
    print(f"\n{'Category':<25} {'Precision':>10} {'Recall':>10} {'F1':>10} {'Support':>10}")
    print("-" * 70)

    for category in VALID_CATEGORIES:
        m = metrics["per_category"].get(category, {})
        if m.get("support", 0) > 0:
            print(f"{category:<25} {m['precision']:>10.4f} {m['recall']:>10.4f} "
                  f"{m['f1']:>10.4f} {m['support']:>10}")

    # Confidence analysis
    conf = metrics.get("confidence_stats", {})
    print(f"\nConfidence Analysis:")
    print(f"  Correct predictions avg confidence:   {conf.get('correct_avg_confidence', 0):.4f}")
    print(f"  Incorrect predictions avg confidence:  {conf.get('incorrect_avg_confidence', 0):.4f}")

    # Top misclassifications from confusion matrix
    print(f"\nTop Misclassifications:")
    misclass = []
    for truth, preds in metrics.get("confusion_matrix", {}).items():
        for pred, count in preds.items():
            if truth != pred:
                misclass.append((truth, pred, count))
    misclass.sort(key=lambda x: -x[2])
    for truth, pred, count in misclass[:10]:
        print(f"  {truth} -> {pred}: {count} errors")

    print("=" * 80)


def save_metrics(metrics: Dict[str, Any], filepath: str):
    """Save metrics to JSON file."""
    Path(filepath).parent.mkdir(parents=True, exist_ok=True)
    with open(filepath, "w") as f:
        json.dump(metrics, f, indent=2)
    print(f"Metrics saved to: {filepath}")
