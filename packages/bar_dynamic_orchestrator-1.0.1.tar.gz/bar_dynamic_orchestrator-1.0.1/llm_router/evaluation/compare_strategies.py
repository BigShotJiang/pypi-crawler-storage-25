"""
Compare all 4 prompt strategies on the same dataset.

Runs each strategy, collects metrics, and produces a
comparison report.
"""

import json
from typing import Dict, List, Any, Optional
from pathlib import Path
from datetime import datetime

from llm_router.evaluation.evaluator import RouterEvaluator
from llm_router.evaluation.metrics import print_metrics_report
from llm_router.config.settings import PROMPT_STRATEGIES


class StrategyComparator:
    """
    Compare multiple prompt strategies on the same dataset.

    Runs each strategy sequentially and produces a
    side-by-side comparison.
    """

    def __init__(self, model: str = "gpt-4o-mini"):
        self.model = model

    def compare(
        self,
        dataset_path: str,
        strategies: List[str] = None,
        sample_size: Optional[int] = None,
        output_dir: str = "llm_router/results/comparison",
        verbose: bool = False,
    ) -> Dict[str, Any]:
        """
        Run all strategies on the same dataset and compare.
        """
        strategies = strategies or PROMPT_STRATEGIES

        print("\n" + "=" * 80)
        print("STRATEGY COMPARISON")
        print("=" * 80)
        print(f"Model:      {self.model}")
        print(f"Strategies: {strategies}")
        print(f"Sample:     {sample_size or 'full dataset'}")
        print("=" * 80)

        comparison_metrics = {}

        for strategy in strategies:
            print(f"\n{'─' * 80}")
            print(f"Running strategy: {strategy}")
            print(f"{'─' * 80}")

            evaluator = RouterEvaluator(
                model=self.model,
            )

            records = evaluator.load_dataset(
                dataset_path,
                sample_size=sample_size,
                seed=42,
            )

            evaluation = evaluator.evaluate(
                records,
                prompt_strategy=strategy,
                verbose=verbose,
            )

            evaluator.save_evaluation(
                evaluation,
                output_dir=output_dir,
                strategy=strategy,
            )

            comparison_metrics[strategy] = (
                evaluation["metrics"]
            )

            print_metrics_report(evaluation["metrics"])

        report = self._generate_comparison_report(
            comparison_metrics
        )
        self._save_comparison_report(report, output_dir)

        return report

    def _generate_comparison_report(
        self, metrics_by_strategy: Dict[str, Dict]
    ) -> Dict[str, Any]:
        """Generate a side-by-side comparison report."""
        report = {
            "model": self.model,
            "timestamp": datetime.now().isoformat(),
            "strategies": {},
            "comparison_table": [],
            "best_strategy": None,
        }

        best_accuracy = 0
        best_strategy = None

        for strategy, metrics in metrics_by_strategy.items():
            accuracy = metrics.get("accuracy", 0)
            eval_meta = metrics.get(
                "evaluation_metadata", {}
            )

            report["strategies"][strategy] = {
                "accuracy": accuracy,
                "macro_f1": metrics.get("macro_f1", 0),
                "weighted_f1": metrics.get("weighted_f1", 0),
                "total_time_seconds": eval_meta.get(
                    "total_time_seconds", 0
                ),
                "queries_per_second": eval_meta.get(
                    "queries_per_second", 0
                ),
            }

            report["comparison_table"].append({
                "strategy": strategy,
                "accuracy": accuracy,
                "macro_f1": metrics.get("macro_f1", 0),
                "weighted_f1": metrics.get("weighted_f1", 0),
                "time_s": eval_meta.get(
                    "total_time_seconds", 0
                ),
            })

            if accuracy > best_accuracy:
                best_accuracy = accuracy
                best_strategy = strategy

        report["best_strategy"] = {
            "name": best_strategy,
            "accuracy": best_accuracy,
        }

        return report

    def _save_comparison_report(
        self, report: Dict, output_dir: str
    ):
        """Save and print the comparison report."""
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = output_path / f"comparison_{ts}.json"

        with open(report_file, "w") as f:
            json.dump(report, f, indent=2)

        print("\n" + "=" * 90)
        print("STRATEGY COMPARISON RESULTS")
        print("=" * 90)

        header = (
            f"{'Strategy':<25} {'Accuracy':>10} "
            f"{'Macro F1':>10} {'Weighted F1':>12} "
            f"{'Time (s)':>10}"
        )
        print(header)
        print("-" * 80)

        for row in report["comparison_table"]:
            print(
                f"{row['strategy']:<25} "
                f"{row['accuracy']:>10.1%} "
                f"{row['macro_f1']:>10.4f} "
                f"{row['weighted_f1']:>12.4f} "
                f"{row['time_s']:>10.1f}"
            )

        best = report["best_strategy"]
        print(
            f"\nBest strategy: {best['name']} "
            f"(accuracy: {best['accuracy']:.1%})"
        )
        print(f"Report saved to: {report_file}")
        print("=" * 90)
