"""
LLM client for the LLM-as-Router approach.

Supports multiple providers: OpenAI, Anthropic, Google.
All calls are traced through Langfuse when installed.
Independent from src/utils/llm_client.py.
"""

import os
import json
from typing import Dict, Any

from tenacity import (
    retry, wait_exponential, stop_after_attempt,
)

# ── Langfuse integration ────────────────────────────────
# OpenAI: langfuse.openai drop-in replacement (auto-trace)
# Anthropic: AnthropicInstrumentor (OTEL-based auto-trace)
# Google: @observe() decorator (manual trace)

try:
    from langfuse.openai import OpenAI
    _HAS_LANGFUSE = True
except ImportError:
    from openai import OpenAI
    _HAS_LANGFUSE = False

# Auto-instrument Anthropic if Langfuse OTEL available
try:
    from opentelemetry.instrumentation.anthropic import (
        AnthropicInstrumentor,
    )
    AnthropicInstrumentor().instrument()
    _HAS_ANTHROPIC_OTEL = True
except ImportError:
    _HAS_ANTHROPIC_OTEL = False

# Langfuse @observe() decorator for Google calls
try:
    from langfuse.decorators import observe
    _observe = observe
except ImportError:
    def _observe(**kwargs):
        """No-op decorator when Langfuse not installed."""
        def decorator(func):
            return func
        return decorator


class RouterLLMClient:
    """
    Multi-provider LLM client for the LLM-as-Router.

    Supported providers:
    - openai: gpt-4o-mini, gpt-4o, gpt-4.1-*, etc.
      Traced via langfuse.openai drop-in replacement.
    - anthropic: claude-3-5-haiku, claude-3-5-sonnet, etc.
      Traced via AnthropicInstrumentor (OTEL).
    - google: gemini-2.0-flash, gemini-1.5-pro, etc.
      Traced via @observe() decorator.
    """

    def __init__(
        self,
        model: str = None,
        provider: str = "openai",
    ):
        self.provider = provider
        self.model = model or self._default_model()
        self._client = self._init_client()

    def _default_model(self) -> str:
        defaults = {
            "openai": os.getenv(
                "ROUTER_MODEL", "gpt-4o-mini"
            ),
            "anthropic": "claude-haiku-4-5-20251001",
            "google": "gemini-2.5-flash",
            "deepseek": "deepseek-chat",
            "ollama": "qwen2.5:7b",
            "llmapi": "gpt-4o-mini",
        }
        return defaults.get(
            self.provider, "gpt-4o-mini"
        )

    def _init_client(self):
        if self.provider == "openai":
            return OpenAI()
        elif self.provider == "deepseek":
            # DeepSeek exposes OpenAI-compatible API
            from openai import OpenAI as RawOpenAI
            return RawOpenAI(
                base_url="https://api.deepseek.com",
                api_key=os.getenv("DEEPSEEK_API_KEY"),
            )
        elif self.provider == "ollama":
            # Ollama exposes OpenAI-compatible API
            from openai import OpenAI as RawOpenAI
            return RawOpenAI(
                base_url="http://localhost:11434/v1",
                api_key="ollama",
            )
        elif self.provider == "llmapi":
            # llmapi.ai — OpenAI-compatible multi-model API
            from openai import OpenAI as RawOpenAI
            return RawOpenAI(
                base_url="https://api.llmapi.ai/v1",
                api_key=os.getenv("LLM_API_KEY"),
            )
        elif self.provider == "anthropic":
            import anthropic
            return anthropic.Anthropic()
        elif self.provider == "google":
            from google import genai
            return genai.Client(
                api_key=os.getenv("GOOGLE_API_KEY")
            )
        else:
            raise ValueError(
                f"Unknown provider: {self.provider}"
            )

    @retry(
        wait=wait_exponential(min=2, max=30),
        stop=stop_after_attempt(3),
        reraise=True,
    )
    def call(
        self,
        system_prompt: str,
        user_prompt: str,
        temperature: float = 0.1,
        json_mode: bool = True,
    ) -> Dict[str, Any]:
        """
        Make a single LLM call and return parsed JSON.

        All calls are traced through Langfuse:
        - OpenAI: auto via langfuse.openai
        - Anthropic: auto via AnthropicInstrumentor
        - Google: via @observe() decorator
        """
        if self.provider == "openai":
            return self._call_openai(
                system_prompt, user_prompt,
                temperature, json_mode,
            )
        elif self.provider == "deepseek":
            return self._call_openai(
                system_prompt, user_prompt,
                temperature, json_mode,
            )
        elif self.provider == "llmapi":
            # Claude models on llmapi don't support
            # response_format json_object — use prompt
            # instructions only (like Ollama)
            _no_json_mode = self.model.startswith(
                "claude-"
            )
            return self._call_openai(
                system_prompt, user_prompt,
                temperature,
                json_mode=(
                    False if _no_json_mode else json_mode
                ),
            )
        elif self.provider == "ollama":
            return self._call_openai(
                system_prompt, user_prompt,
                temperature, json_mode=False,
            )
        elif self.provider == "anthropic":
            return self._call_anthropic(
                system_prompt, user_prompt,
                temperature, json_mode,
            )
        elif self.provider == "google":
            return self._call_google(
                system_prompt, user_prompt,
                temperature, json_mode,
            )

    def _call_openai(
        self,
        system_prompt: str,
        user_prompt: str,
        temperature: float,
        json_mode: bool,
    ) -> Dict[str, Any]:
        """OpenAI call — auto-traced via langfuse.openai."""
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

        request_params = {
            "model": self.model,
            "messages": messages,
        }
        # Some models (e.g. gpt-5-nano) only support
        # default temperature — skip if not supported
        _NO_TEMP_MODELS = {"gpt-5-nano"}
        if self.model not in _NO_TEMP_MODELS:
            request_params["temperature"] = temperature
        if json_mode:
            request_params["response_format"] = {
                "type": "json_object"
            }

        response = (
            self._client.chat.completions.create(
                **request_params
            )
        )
        content = (
            response.choices[0].message.content.strip()
        )

        usage = {}
        if response.usage:
            usage = {
                "prompt_tokens": (
                    response.usage.prompt_tokens
                ),
                "completion_tokens": (
                    response.usage.completion_tokens
                ),
                "total_tokens": (
                    response.usage.total_tokens
                ),
            }

        return self._parse_content(content, usage)

    def _call_anthropic(
        self,
        system_prompt: str,
        user_prompt: str,
        temperature: float,
        json_mode: bool,
    ) -> Dict[str, Any]:
        """
        Anthropic call — auto-traced via
        AnthropicInstrumentor (OTEL) when installed.
        """
        sys_prompt = system_prompt
        if json_mode:
            sys_prompt += (
                "\n\nIMPORTANT: You MUST respond with "
                "valid JSON only. No markdown, no code "
                "fences, no extra text."
            )

        response = self._client.messages.create(
            model=self.model,
            max_tokens=1024,
            temperature=temperature,
            system=sys_prompt,
            messages=[
                {
                    "role": "user",
                    "content": user_prompt,
                },
            ],
        )

        content = response.content[0].text.strip()

        usage = {
            "prompt_tokens": (
                response.usage.input_tokens
            ),
            "completion_tokens": (
                response.usage.output_tokens
            ),
            "total_tokens": (
                response.usage.input_tokens
                + response.usage.output_tokens
            ),
        }

        return self._parse_content(content, usage)

    @_observe(name="google_genai_call")
    def _call_google(
        self,
        system_prompt: str,
        user_prompt: str,
        temperature: float,
        json_mode: bool,
    ) -> Dict[str, Any]:
        """
        Google call — traced via Langfuse @observe()
        decorator when installed.
        Uses new google.genai SDK (google-genai package).
        """
        from google.genai import types

        config = types.GenerateContentConfig(
            system_instruction=system_prompt,
            temperature=temperature,
        )
        if json_mode:
            config.response_mime_type = (
                "application/json"
            )

        response = self._client.models.generate_content(
            model=self.model,
            contents=user_prompt,
            config=config,
        )
        content = response.text.strip()

        # Google usage metadata
        usage_meta = response.usage_metadata
        usage = {
            "prompt_tokens": (
                usage_meta.prompt_token_count
                if usage_meta else 0
            ),
            "completion_tokens": (
                usage_meta.candidates_token_count
                if usage_meta else 0
            ),
            "total_tokens": (
                usage_meta.total_token_count
                if usage_meta else 0
            ),
        }

        return self._parse_content(content, usage)

    def _parse_content(
        self, content: str, usage: Dict
    ) -> Dict[str, Any]:
        """Parse JSON content, attach usage."""
        # Strip markdown code fences if present
        if content.startswith("```"):
            lines = content.split("\n")
            lines = [
                line for line in lines
                if not line.startswith("```")
            ]
            content = "\n".join(lines)

        try:
            parsed = json.loads(content)
        except json.JSONDecodeError:
            parsed = {
                "raw_response": content,
                "parse_error": True,
            }

        parsed["_usage"] = usage
        return parsed
