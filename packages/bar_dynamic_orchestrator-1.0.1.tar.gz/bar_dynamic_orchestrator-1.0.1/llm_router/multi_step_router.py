"""
Multi-step LLM Router (2-call approach).

Call 1: Domain detection — broad domain classification.
Call 2: Detailed category classification given the domain.

Used for Phase 4 comparison: single-call vs multi-step.
"""

import time
from typing import Dict, Any, Optional

from llm_router.utils.llm_client import RouterLLMClient
from llm_router.config.settings import (
    VALID_CATEGORIES,
    DEFAULT_ROUTER_MODEL,
    MIN_CONFIDENCE_THRESHOLD,
    format_categories_for_prompt,
)

# Load .env at module level
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass


# Domain groupings for step 1
_DOMAIN_GROUPS = {
    "technical": ["CODE", "REASONING"],
    "professional": ["MEDICAL", "LEGAL", "FINANCE"],
    "communication": [
        "CONVERSATIONAL", "CREATIVE_WRITING",
        "MULTILINGUAL",
    ],
    "information": [
        "FACTUAL_KNOWLEDGE", "SUMMARIZATION",
        "INSTRUCTION_FOLLOWING",
    ],
}

_DOMAIN_LIST = list(_DOMAIN_GROUPS.keys())

# Reverse: category -> domain
_CATEGORY_TO_DOMAIN = {}
for domain, cats in _DOMAIN_GROUPS.items():
    for cat in cats:
        _CATEGORY_TO_DOMAIN[cat] = domain


_STEP1_SYSTEM = """You are a query domain classifier.
Classify the user's query into one of these broad domains:

- **technical**: Programming, algorithms, debugging, \
logic puzzles, math proofs
- **professional**: Medical/health, legal, financial \
topics
- **communication**: Casual chat, creative writing, \
translation, multilingual
- **information**: Facts, summaries, instructions, \
how-to guides

Respond with JSON: {"domain": "<domain>", \
"reasoning": "<brief reason>"}"""

_STEP2_SYSTEM_TEMPLATE = """You are a query classifier.
The query belongs to the "{domain}" domain.
Classify it into ONE specific category from the list \
below.

{categories}

Respond with JSON:
{{"category": "<CATEGORY>", "confidence": <0.0-1.0>, \
"category_reasoning": "<brief reason>"}}"""


class MultiStepRouter:
    """
    Two-call LLM router.

    Step 1: Detect broad domain (technical, professional,
            communication, information).
    Step 2: Classify into specific category within that
            domain context.
    """

    def __init__(
        self,
        model: str = None,
        provider: str = "openai",
    ):
        self.client = RouterLLMClient(
            model=model or DEFAULT_ROUTER_MODEL,
            provider=provider,
        )

    def route(
        self,
        query: str,
        prompt_strategy: str = "zero_shot",
        temperature: Optional[float] = None,
        confidence_threshold: Optional[float] = None,
    ) -> Dict[str, Any]:
        """
        Route a query with two LLM calls.

        Step 1: Domain detection
        Step 2: Category classification within domain
        """
        temp = (
            temperature if temperature is not None
            else 0.1
        )
        threshold = (
            confidence_threshold
            if confidence_threshold is not None
            else MIN_CONFIDENCE_THRESHOLD
        )

        total_prompt = 0
        total_completion = 0

        # ── Step 1: Domain detection ─────────────
        t0 = time.time()
        step1_result = self.client.call(
            system_prompt=_STEP1_SYSTEM,
            user_prompt=f"Query: {query}",
            temperature=temp,
            json_mode=True,
        )
        t1 = time.time()
        print(
            f"[TIMING] Step 1 (domain): "
            f"{(t1-t0)*1000:.0f}ms"
        )

        usage1 = step1_result.pop("_usage", {})
        total_prompt += usage1.get("prompt_tokens", 0)
        total_completion += usage1.get(
            "completion_tokens", 0
        )

        domain = step1_result.get(
            "domain", "information"
        ).lower()
        if domain not in _DOMAIN_LIST:
            domain = "information"

        # ── Step 2: Category classification ──────
        categories_text = format_categories_for_prompt()
        step2_system = _STEP2_SYSTEM_TEMPLATE.format(
            domain=domain,
            categories=categories_text,
        )

        t2 = time.time()
        step2_result = self.client.call(
            system_prompt=step2_system,
            user_prompt=f"Query: {query}",
            temperature=temp,
            json_mode=True,
        )
        t3 = time.time()
        print(
            f"[TIMING] Step 2 (category): "
            f"{(t3-t2)*1000:.0f}ms"
        )

        usage2 = step2_result.pop("_usage", {})
        total_prompt += usage2.get("prompt_tokens", 0)
        total_completion += usage2.get(
            "completion_tokens", 0
        )

        # Parse category
        category = step2_result.get(
            "category", "FACTUAL_KNOWLEDGE"
        ).upper().strip()
        confidence = float(
            step2_result.get("confidence", 0.5)
        )
        reasoning = step2_result.get(
            "category_reasoning",
            step2_result.get("reasoning", ""),
        )

        if category not in VALID_CATEGORIES:
            category = "FACTUAL_KNOWLEDGE"
            confidence = min(confidence, 0.5)

        is_valid = (
            category in VALID_CATEGORIES
            and confidence >= threshold
        )

        total_tok = total_prompt + total_completion
        cost = self._estimate_cost(
            total_prompt, total_completion
        )

        return {
            "query": query,
            "final_category": category,
            "category_confidence": confidence,
            "is_valid": is_valid,
            "prompt_strategy": prompt_strategy,
            "routing_approach": "multi_step",
            "detected_domain": domain,
            "domain_reasoning": step1_result.get(
                "reasoning", ""
            ),
            "category_reasoning": reasoning,
            "raw_llm_response": step2_result,
            "total_tokens": total_tok,
            "estimated_cost_usd": cost,
        }

    def _estimate_cost(
        self, prompt_tokens: int, completion_tokens: int
    ) -> float:
        from llm_router.router import _COST_PER_1K
        model = self.client.model
        rates = _COST_PER_1K.get(model, {})
        if not rates:
            return 0.0
        cost = (
            prompt_tokens * rates["input"] / 1000
            + completion_tokens * rates["output"] / 1000
        )
        return round(cost, 6)
