"""
Generate thesis-quality charts from LLM Router evaluation results.

Reads from llm_router_evaluation.json (Phase 1 + Phase 2 + Phase 7).
All 8 models: 4 cloud (OpenAI) + 4 local (Ollama).

Charts produced:
 1. Heatmap — Strategy × Model F1
 2. Grouped bar — F1 by Strategy per Model
 3. Best config per model (horizontal bar)
 4. Cost vs Accuracy scatter (cloud only)
 5. Latency vs Accuracy scatter (all)
 6. Strategy robustness box plot
 7. Model robustness box plot
 8. Per-category F1 for top 3 configs
 9. Cloud vs Local tier comparison
10. Radar chart — model capability profile
"""

import json
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import seaborn as sns
import numpy as np
import pandas as pd
from pathlib import Path
from math import pi

# ── Config ────────────────────────────────────────────────
RESULTS_DIR = (
    Path(__file__).resolve().parent.parent / "results"
)
JSON_PATH = RESULTS_DIR / "llm_router_evaluation.json"

STRATEGY_ORDER = [
    "zero_shot", "few_shot", "chain_of_thought",
    "structured_analysis",
    "dspy_copro", "dspy_bootstrap", "dspy_mipro",
]
STRATEGY_LABELS = {
    "zero_shot": "Zero-Shot",
    "few_shot": "Few-Shot",
    "chain_of_thought": "Chain-of-Thought",
    "structured_analysis": "Structured Analysis",
    "dspy_copro": "DSPy COPRO",
    "dspy_bootstrap": "DSPy Bootstrap",
    "dspy_mipro": "DSPy MIPRO",
}

# Cloud models first, then local — sorted by expected perf
CLOUD_MODELS = [
    "gpt-4o-mini", "gpt-5.4-nano",
    "gpt-4.1-nano", "gpt-5-nano",
]
LOCAL_MODELS = [
    "mistral:latest", "qwen2.5:7b",
    "phi3:latest", "llama3.2:latest",
]
ALL_MODELS = CLOUD_MODELS + LOCAL_MODELS

MODEL_LABELS = {
    "gpt-4o-mini": "GPT-4o-mini",
    "gpt-5.4-nano": "GPT-5.4-nano",
    "gpt-4.1-nano": "GPT-4.1-nano",
    "gpt-5-nano": "GPT-5-nano",
    "mistral:latest": "Mistral 7B",
    "qwen2.5:7b": "Qwen 2.5 7B",
    "phi3:latest": "Phi-3 3.8B",
    "llama3.2:latest": "Llama 3.2 3B",
}

# Color palette — blues for cloud, greens/oranges for local
MODEL_COLORS = {
    "gpt-4o-mini": "#1E40AF",
    "gpt-5.4-nano": "#3B82F6",
    "gpt-4.1-nano": "#60A5FA",
    "gpt-5-nano": "#93C5FD",
    "mistral:latest": "#D97706",
    "qwen2.5:7b": "#F59E0B",
    "phi3:latest": "#10B981",
    "llama3.2:latest": "#6EE7B7",
}

PROVIDER_COLORS = {
    "cloud": "#3B82F6",
    "local": "#F59E0B",
}


# ── Load data ─────────────────────────────────────────────
with open(JSON_PATH) as f:
    data = json.load(f)

# Build unified lookup: (model, strategy) -> experiment
experiments = {}

# Phase 1 — gpt-4o-mini × 7 strategies
for exp in data["phases"]["strategy_comparison"][
    "experiments"
]:
    experiments[("gpt-4o-mini", exp["name"])] = exp

# Phase 2 — cloud models × 7 strategies
p2 = data["phases"].get("model_comparison", {})
for exp in p2.get("experiments", []):
    name = exp["name"]
    if "/" in name:
        model, strategy = name.split("/", 1)
        experiments[(model, strategy)] = exp

# Phase 7 — local models × 7 strategies
p7 = data["phases"].get("local_model_comparison", {})
for exp in p7.get("experiments", []):
    model = exp.get("model", "")
    strategy = exp.get("strategy", "")
    if model and strategy:
        experiments[(model, strategy)] = exp

# Filter to models that actually have data
ALL_MODELS = [
    m for m in ALL_MODELS
    if any(
        (m, s) in experiments for s in STRATEGY_ORDER
    )
]
CLOUD_MODELS = [
    m for m in CLOUD_MODELS if m in ALL_MODELS
]
LOCAL_MODELS = [
    m for m in LOCAL_MODELS if m in ALL_MODELS
]

print(f"Models with data: {len(ALL_MODELS)}")
print(f"  Cloud: {CLOUD_MODELS}")
print(f"  Local: {LOCAL_MODELS}")
print(f"Total experiments: {len(experiments)}")


# ── Global style ──────────────────────────────────────────
sns.set_theme(style="white", font_scale=1.05)
plt.rcParams.update({
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "savefig.facecolor": "white",
    "font.family": "sans-serif",
    "axes.spines.top": False,
    "axes.spines.right": False,
})


def _f1(model, strategy):
    """Get F1 macro % for a model/strategy combo."""
    exp = experiments.get((model, strategy))
    return exp["macro_f1"] * 100 if exp else 0


def _get(model, strategy, key, default=0):
    """Get any metric value."""
    exp = experiments.get((model, strategy))
    if exp:
        return exp.get(key, default)
    return default


# ══════════════════════════════════════════════════════════
# Chart 1: Heatmap — Strategy × Model F1
# ══════════════════════════════════════════════════════════
print("\n[1/10] Heatmap...")
matrix = []
for strat in STRATEGY_ORDER:
    row = [_f1(m, strat) for m in ALL_MODELS]
    matrix.append(row)

df_heat = pd.DataFrame(
    matrix,
    index=[STRATEGY_LABELS[s] for s in STRATEGY_ORDER],
    columns=[MODEL_LABELS[m] for m in ALL_MODELS],
)

fig, ax = plt.subplots(figsize=(14, 6))
sns.heatmap(
    df_heat, annot=True, fmt=".1f", cmap="YlOrRd",
    linewidths=0.5, linecolor="white",
    cbar_kws={"label": "F1 Macro (%)"},
    ax=ax, vmin=0, vmax=100,
)
ax.set_title(
    "Strategy × Model Performance Heatmap (F1 Macro %)",
    fontsize=14, fontweight="bold", pad=15,
)
# Separator between cloud and local
if CLOUD_MODELS and LOCAL_MODELS:
    sep_x = len(CLOUD_MODELS)
    ax.axvline(x=sep_x, color="black", linewidth=2)
    ax.text(
        sep_x / 2, -0.6, "Cloud Models",
        ha="center", fontsize=10, fontweight="bold",
        color="#1E40AF",
    )
    ax.text(
        sep_x + len(LOCAL_MODELS) / 2, -0.6,
        "Local Models",
        ha="center", fontsize=10, fontweight="bold",
        color="#D97706",
    )
plt.tight_layout()
fig.savefig(
    RESULTS_DIR / "chart_01_heatmap.png",
    dpi=300, bbox_inches="tight",
)
plt.close(fig)
print("  Saved chart_01_heatmap.png")


# ══════════════════════════════════════════════════════════
# Chart 2: Grouped bar — F1 by Strategy per Model
# ══════════════════════════════════════════════════════════
print("[2/10] Grouped bar chart...")
fig, ax = plt.subplots(figsize=(16, 7))

n_strat = len(STRATEGY_ORDER)
n_models = len(ALL_MODELS)
bar_w = 0.8 / n_models
x = np.arange(n_strat)

for i, model in enumerate(ALL_MODELS):
    vals = [_f1(model, s) for s in STRATEGY_ORDER]
    offset = (i - (n_models - 1) / 2) * bar_w
    bars = ax.bar(
        x + offset, vals, bar_w,
        label=MODEL_LABELS[model],
        color=MODEL_COLORS[model],
        edgecolor="white", linewidth=0.5, zorder=3,
    )

ax.set_xlabel("Prompt Strategy", fontsize=12, labelpad=10)
ax.set_ylabel("F1 Macro (%)", fontsize=12, labelpad=10)
ax.set_title(
    "F1 Macro by Prompt Strategy across All Models",
    fontsize=14, fontweight="bold", pad=15,
)
ax.set_xticks(x)
ax.set_xticklabels(
    [STRATEGY_LABELS[s] for s in STRATEGY_ORDER],
    rotation=25, ha="right",
)
ax.set_ylim(0, 100)
ax.yaxis.set_major_locator(mticker.MultipleLocator(10))
ax.grid(axis="y", alpha=0.3, linestyle="--", zorder=0)
ax.legend(
    loc="upper right", ncol=2, frameon=True,
    fancybox=False, edgecolor="#ccc", fontsize=9,
)
plt.tight_layout()
fig.savefig(
    RESULTS_DIR / "chart_02_grouped_bar.png",
    dpi=300, bbox_inches="tight",
)
plt.close(fig)
print("  Saved chart_02_grouped_bar.png")


# ══════════════════════════════════════════════════════════
# Chart 3: Best config per model (horizontal bar)
# ══════════════════════════════════════════════════════════
print("[3/10] Best config per model...")
fig, ax = plt.subplots(figsize=(11, 6))

best_data = []
for model in ALL_MODELS:
    best_f1, best_strat = 0, "zero_shot"
    for s in STRATEGY_ORDER:
        f1 = _f1(model, s)
        if f1 > best_f1:
            best_f1 = f1
            best_strat = s
    best_data.append((model, best_strat, best_f1))

best_data.sort(key=lambda t: t[2])

y_pos = np.arange(len(best_data))
labels = [
    f"{MODEL_LABELS[m]}\n({STRATEGY_LABELS[s]})"
    for m, s, _ in best_data
]
vals = [f1 for _, _, f1 in best_data]
colors = [MODEL_COLORS[m] for m, _, _ in best_data]

bars = ax.barh(
    y_pos, vals, height=0.6, color=colors,
    edgecolor="white", zorder=3,
)
for bar, val in zip(bars, vals):
    ax.text(
        val + 0.8,
        bar.get_y() + bar.get_height() / 2,
        f"{val:.1f}%", ha="left", va="center",
        fontsize=11, fontweight="bold",
    )

ax.set_yticks(y_pos)
ax.set_yticklabels(labels, fontsize=10)
ax.set_xlabel("F1 Macro (%)", fontsize=12, labelpad=10)
ax.set_title(
    "Best Configuration per Model",
    fontsize=14, fontweight="bold", pad=15,
)
ax.set_xlim(0, 105)
ax.grid(axis="x", alpha=0.3, linestyle="--", zorder=0)
plt.tight_layout()
fig.savefig(
    RESULTS_DIR / "chart_03_best_per_model.png",
    dpi=300, bbox_inches="tight",
)
plt.close(fig)
print("  Saved chart_03_best_per_model.png")


# ══════════════════════════════════════════════════════════
# Chart 4: Cost vs Accuracy scatter (cloud only)
# ══════════════════════════════════════════════════════════
print("[4/10] Cost vs Accuracy scatter...")
fig, ax = plt.subplots(figsize=(12, 7))

for model in CLOUD_MODELS:
    xs, ys, lbls = [], [], []
    for s in STRATEGY_ORDER:
        exp = experiments.get((model, s))
        if exp:
            cost = exp.get("total_cost_usd", 0)
            xs.append(cost)
            ys.append(exp["macro_f1"] * 100)
            lbls.append(STRATEGY_LABELS[s])

    ax.scatter(
        xs, ys, s=120, c=MODEL_COLORS[model],
        label=MODEL_LABELS[model],
        edgecolors="white", linewidths=0.8,
        zorder=4, alpha=0.9,
    )
    for xi, yi, lab in zip(xs, ys, lbls):
        ax.annotate(
            lab, (xi, yi),
            textcoords="offset points", xytext=(6, 6),
            fontsize=7, color="#444",
        )

ax.set_xlabel(
    "Total Cost (USD) for 200 queries",
    fontsize=12, labelpad=10,
)
ax.set_ylabel("F1 Macro (%)", fontsize=12, labelpad=10)
ax.set_title(
    "Cost vs. Accuracy — Cloud Models",
    fontsize=14, fontweight="bold", pad=15,
)
ax.grid(alpha=0.25, linestyle="--", zorder=0)
ax.legend(
    loc="lower right", frameon=True, fancybox=False,
    edgecolor="#ccc",
)
plt.tight_layout()
fig.savefig(
    RESULTS_DIR / "chart_04_cost_vs_accuracy.png",
    dpi=300, bbox_inches="tight",
)
plt.close(fig)
print("  Saved chart_04_cost_vs_accuracy.png")


# ══════════════════════════════════════════════════════════
# Chart 5: Latency vs Accuracy scatter (all models)
# ══════════════════════════════════════════════════════════
print("[5/10] Latency vs Accuracy scatter...")
fig, ax = plt.subplots(figsize=(14, 8))

for model in ALL_MODELS:
    xs, ys, lbls = [], [], []
    for s in STRATEGY_ORDER:
        exp = experiments.get((model, s))
        if exp and exp.get("avg_latency_ms", 0) > 0:
            xs.append(exp["avg_latency_ms"])
            ys.append(exp["macro_f1"] * 100)
            lbls.append(STRATEGY_LABELS[s])

    marker = "o" if model in CLOUD_MODELS else "s"
    ax.scatter(
        xs, ys, s=100, c=MODEL_COLORS[model],
        label=MODEL_LABELS[model], marker=marker,
        edgecolors="white", linewidths=0.8,
        zorder=4, alpha=0.85,
    )
    for xi, yi, lab in zip(xs, ys, lbls):
        ax.annotate(
            lab, (xi, yi),
            textcoords="offset points", xytext=(5, 5),
            fontsize=6.5, color="#555",
        )

ax.set_xlabel(
    "Average Latency (ms)", fontsize=12, labelpad=10,
)
ax.set_ylabel("F1 Macro (%)", fontsize=12, labelpad=10)
ax.set_title(
    "Latency vs. Accuracy — All Models\n"
    "(circles = cloud, squares = local)",
    fontsize=14, fontweight="bold", pad=15,
)
ax.grid(alpha=0.25, linestyle="--", zorder=0)
ax.legend(
    loc="lower right", ncol=2, frameon=True,
    fancybox=False, edgecolor="#ccc", fontsize=9,
)
plt.tight_layout()
fig.savefig(
    RESULTS_DIR / "chart_05_latency_vs_accuracy.png",
    dpi=300, bbox_inches="tight",
)
plt.close(fig)
print("  Saved chart_05_latency_vs_accuracy.png")


# ══════════════════════════════════════════════════════════
# Chart 6: Strategy robustness box plot
# ══════════════════════════════════════════════════════════
print("[6/10] Strategy robustness box plot...")
fig, ax = plt.subplots(figsize=(12, 6))

strat_data = []
for s in STRATEGY_ORDER:
    vals = [
        _f1(m, s) for m in ALL_MODELS
        if _f1(m, s) > 0
    ]
    strat_data.append(vals)

bp = ax.boxplot(
    strat_data, patch_artist=True, widths=0.5,
    medianprops=dict(color="black", linewidth=2),
)
colors_box = sns.color_palette("Set2", n_colors=7)
for patch, color in zip(bp["boxes"], colors_box):
    patch.set_facecolor(color)
    patch.set_alpha(0.8)

ax.set_xticklabels(
    [STRATEGY_LABELS[s] for s in STRATEGY_ORDER],
    rotation=25, ha="right",
)
ax.set_ylabel("F1 Macro (%)", fontsize=12, labelpad=10)
ax.set_title(
    "Strategy Robustness across Models\n"
    "(distribution of F1 across 8 models)",
    fontsize=14, fontweight="bold", pad=15,
)
ax.grid(axis="y", alpha=0.3, linestyle="--", zorder=0)
plt.tight_layout()
fig.savefig(
    RESULTS_DIR / "chart_06_strategy_robustness.png",
    dpi=300, bbox_inches="tight",
)
plt.close(fig)
print("  Saved chart_06_strategy_robustness.png")


# ══════════════════════════════════════════════════════════
# Chart 7: Model robustness box plot
# ══════════════════════════════════════════════════════════
print("[7/10] Model robustness box plot...")
fig, ax = plt.subplots(figsize=(12, 6))

model_data = []
for m in ALL_MODELS:
    vals = [
        _f1(m, s) for s in STRATEGY_ORDER
        if _f1(m, s) > 0
    ]
    model_data.append(vals)

bp = ax.boxplot(
    model_data, patch_artist=True, widths=0.5,
    medianprops=dict(color="black", linewidth=2),
)
for patch, m in zip(bp["boxes"], ALL_MODELS):
    patch.set_facecolor(MODEL_COLORS[m])
    patch.set_alpha(0.8)

ax.set_xticklabels(
    [MODEL_LABELS[m] for m in ALL_MODELS],
    rotation=30, ha="right",
)
ax.set_ylabel("F1 Macro (%)", fontsize=12, labelpad=10)
ax.set_title(
    "Model Robustness across Strategies\n"
    "(distribution of F1 across 7 strategies)",
    fontsize=14, fontweight="bold", pad=15,
)
ax.grid(axis="y", alpha=0.3, linestyle="--", zorder=0)
plt.tight_layout()
fig.savefig(
    RESULTS_DIR / "chart_07_model_robustness.png",
    dpi=300, bbox_inches="tight",
)
plt.close(fig)
print("  Saved chart_07_model_robustness.png")


# ══════════════════════════════════════════════════════════
# Chart 8: Per-category F1 for top 3 configs
# ══════════════════════════════════════════════════════════
print("[8/10] Per-category F1 for top 3...")

# Find top 3 configs by macro_f1
all_configs = []
for (m, s), exp in experiments.items():
    all_configs.append(
        (m, s, exp["macro_f1"] * 100, exp)
    )
all_configs.sort(key=lambda t: t[2], reverse=True)
top3 = all_configs[:3]

# Get categories from the first config that has them
categories = []
for _, _, _, exp in top3:
    pc = exp.get("per_category", {})
    if pc:
        categories = sorted(pc.keys())
        break

if categories:
    fig, ax = plt.subplots(figsize=(16, 7))
    x = np.arange(len(categories))
    bar_w = 0.25

    for i, (m, s, f1, exp) in enumerate(top3):
        pc = exp.get("per_category", {})
        vals = [
            pc.get(c, {}).get("f1", 0) * 100
            for c in categories
        ]
        offset = (i - 1) * bar_w
        label = (
            f"{MODEL_LABELS.get(m, m)} / "
            f"{STRATEGY_LABELS.get(s, s)} "
            f"({f1:.1f}%)"
        )
        ax.bar(
            x + offset, vals, bar_w, label=label,
            edgecolor="white", linewidth=0.5, zorder=3,
        )

    ax.set_xlabel("Category", fontsize=12, labelpad=10)
    ax.set_ylabel("F1 Score (%)", fontsize=12, labelpad=10)
    ax.set_title(
        "Per-Category F1 — Top 3 Configurations",
        fontsize=14, fontweight="bold", pad=15,
    )
    ax.set_xticks(x)
    ax.set_xticklabels(categories, rotation=35, ha="right")
    ax.set_ylim(0, 110)
    ax.grid(axis="y", alpha=0.3, linestyle="--", zorder=0)
    ax.legend(
        loc="upper right", frameon=True, fancybox=False,
        edgecolor="#ccc", fontsize=9,
    )
    plt.tight_layout()
    fig.savefig(
        RESULTS_DIR / "chart_08_per_category.png",
        dpi=300, bbox_inches="tight",
    )
    plt.close(fig)
    print("  Saved chart_08_per_category.png")
else:
    print("  SKIP — no per_category data found")


# ══════════════════════════════════════════════════════════
# Chart 9: Cloud vs Local tier comparison
# ══════════════════════════════════════════════════════════
print("[9/10] Cloud vs Local tier comparison...")
fig, ax = plt.subplots(figsize=(10, 6))

# Best F1 per model
cloud_best = []
local_best = []
for m in CLOUD_MODELS:
    best = max(_f1(m, s) for s in STRATEGY_ORDER)
    cloud_best.append((MODEL_LABELS[m], best))
for m in LOCAL_MODELS:
    best = max(_f1(m, s) for s in STRATEGY_ORDER)
    local_best.append((MODEL_LABELS[m], best))

all_bars = cloud_best + local_best
all_bars.sort(key=lambda t: t[1])

y_pos = np.arange(len(all_bars))
labels = [b[0] for b in all_bars]
vals = [b[1] for b in all_bars]
colors = [
    PROVIDER_COLORS["cloud"]
    if any(
        b[0] == MODEL_LABELS[m] for m in CLOUD_MODELS
    )
    else PROVIDER_COLORS["local"]
    for b in all_bars
]

bars = ax.barh(
    y_pos, vals, height=0.6, color=colors,
    edgecolor="white", zorder=3,
)
for bar, val in zip(bars, vals):
    ax.text(
        val + 0.5,
        bar.get_y() + bar.get_height() / 2,
        f"{val:.1f}%", ha="left", va="center",
        fontsize=11, fontweight="bold",
    )

# Legend
from matplotlib.patches import Patch
legend_elements = [
    Patch(
        facecolor=PROVIDER_COLORS["cloud"],
        label="Cloud (OpenAI)",
    ),
    Patch(
        facecolor=PROVIDER_COLORS["local"],
        label="Local (Ollama)",
    ),
]
ax.legend(
    handles=legend_elements, loc="lower right",
    frameon=True, fancybox=False, edgecolor="#ccc",
)

ax.set_yticks(y_pos)
ax.set_yticklabels(labels, fontsize=10)
ax.set_xlabel(
    "Best F1 Macro (%)", fontsize=12, labelpad=10,
)
ax.set_title(
    "Cloud vs. Local Models — Best F1 per Model",
    fontsize=14, fontweight="bold", pad=15,
)
ax.set_xlim(0, 105)
ax.grid(axis="x", alpha=0.3, linestyle="--", zorder=0)
plt.tight_layout()
fig.savefig(
    RESULTS_DIR / "chart_09_cloud_vs_local.png",
    dpi=300, bbox_inches="tight",
)
plt.close(fig)
print("  Saved chart_09_cloud_vs_local.png")


# ══════════════════════════════════════════════════════════
# Chart 10: Radar chart — model capability profile
# ══════════════════════════════════════════════════════════
print("[10/10] Radar chart...")

# Pick top 4 models for readability
radar_models = []
for m in ALL_MODELS:
    best = max(_f1(m, s) for s in STRATEGY_ORDER)
    radar_models.append((m, best))
radar_models.sort(key=lambda t: t[1], reverse=True)
radar_models = [m for m, _ in radar_models[:4]]

angles = [
    n / float(len(STRATEGY_ORDER)) * 2 * pi
    for n in range(len(STRATEGY_ORDER))
]
angles += angles[:1]  # close the polygon

fig, ax = plt.subplots(
    figsize=(9, 9), subplot_kw=dict(polar=True),
)

for model in radar_models:
    vals = [_f1(model, s) for s in STRATEGY_ORDER]
    vals += vals[:1]  # close
    ax.plot(
        angles, vals, linewidth=2,
        label=MODEL_LABELS[model],
        color=MODEL_COLORS[model],
    )
    ax.fill(angles, vals, alpha=0.1,
            color=MODEL_COLORS[model])

ax.set_xticks(angles[:-1])
ax.set_xticklabels(
    [STRATEGY_LABELS[s] for s in STRATEGY_ORDER],
    fontsize=9,
)
ax.set_ylim(0, 100)
ax.set_title(
    "Model Capability Profile (Top 4 Models)",
    fontsize=14, fontweight="bold", pad=25,
)
ax.legend(
    loc="upper right",
    bbox_to_anchor=(1.3, 1.1),
    frameon=True, fancybox=False, edgecolor="#ccc",
)
plt.tight_layout()
fig.savefig(
    RESULTS_DIR / "chart_10_radar.png",
    dpi=300, bbox_inches="tight",
)
plt.close(fig)
print("  Saved chart_10_radar.png")


print("\n" + "=" * 50)
print("All 10 charts generated in:")
print(f"  {RESULTS_DIR}/")
print("=" * 50)
