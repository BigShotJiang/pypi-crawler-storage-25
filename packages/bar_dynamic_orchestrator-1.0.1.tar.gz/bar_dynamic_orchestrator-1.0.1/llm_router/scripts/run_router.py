"""
CLI script to run the LLM-as-Router.

Usage:
    # Single query
    python -m llm_router.scripts.run_router \
        --query "How do I integrate your payment API?" \
        --strategy zero_shot

    # Interactive mode
    python -m llm_router.scripts.run_router --interactive

    # Batch from dataset
    python -m llm_router.scripts.run_router \
        --input data/final/corrected_20260211_002413.jsonl \
        --output results/routing_results.jsonl \
        --strategy chain_of_thought --sample 50
"""

import json
import argparse
from pathlib import Path
from datetime import datetime

from llm_router.router import LLMRouter
from llm_router.config.settings import PROMPT_STRATEGIES


def run_single_query(args):
    """Route a single query."""
    router = LLMRouter(model=args.model)

    print("\n" + "=" * 70)
    print("LLM-AS-ROUTER")
    print("=" * 70)
    print(f"Model:    {router.client.model}")
    print(f"Strategy: {args.strategy}")
    print(f"Query:    {args.query}")
    print("=" * 70)

    result = router.route(
        query=args.query,
        prompt_strategy=args.strategy,
    )

    print(f"\nCategory:   {result['final_category']}")
    print(f"Confidence: {result['category_confidence']:.1%}")
    print(f"Valid:      {result['is_valid']}")
    print(f"\nReasoning:  {result['category_reasoning']}")

    if args.verbose and result.get("raw_llm_response"):
        print(f"\nRaw LLM Response:")
        for k, v in result["raw_llm_response"].items():
            print(f"  {k}: {v}")


def run_interactive(args):
    """Interactive routing mode."""
    router = LLMRouter(model=args.model)

    print("\n" + "=" * 70)
    print("LLM-AS-ROUTER — INTERACTIVE MODE")
    print("=" * 70)
    print(f"Model:    {router.client.model}")
    print(f"Strategy: {args.strategy}")
    print("Type 'quit' to exit, 'strategy <name>' to change.")
    print("-" * 70)

    strategy = args.strategy

    while True:
        try:
            query = input("\nQuery: ").strip()
            if not query:
                continue
            if query.lower() in ("quit", "exit", "q"):
                break
            if query.lower().startswith("strategy "):
                new_strategy = query.split(" ", 1)[1].strip()
                if new_strategy in PROMPT_STRATEGIES:
                    strategy = new_strategy
                    print(f"  Strategy: {strategy}")
                else:
                    print(
                        f"  Invalid. Choose: {PROMPT_STRATEGIES}"
                    )
                continue

            result = router.route(
                query=query,
                prompt_strategy=strategy,
            )

            cat_reason = result.get(
                "category_reasoning", ""
            )[:100]
            print(f"  Category:   {result['final_category']}")
            print(
                f"  Confidence: "
                f"{result['category_confidence']:.1%}"
            )
            print(f"  Reasoning:  {cat_reason}")

        except KeyboardInterrupt:
            break

    print("Goodbye!")


def run_batch(args):
    """Route queries from a dataset file."""
    router = LLMRouter(model=args.model)

    records = []
    with open(args.input, "r", encoding="utf-8") as f:
        for line in f:
            try:
                records.append(json.loads(line.strip()))
            except json.JSONDecodeError:
                continue

    if args.sample and args.sample < len(records):
        import random
        random.seed(42)
        records = random.sample(records, args.sample)

    print(
        f"\nRouting {len(records)} queries "
        f"with strategy: {args.strategy}"
    )
    print(f"Model: {router.client.model}")
    print("=" * 70)

    results = []
    for i, record in enumerate(records):
        query = record.get("query", "")

        try:
            result = router.route(
                query=query,
                prompt_strategy=args.strategy,
            )
            gt = record.get("category", "")
            result["ground_truth_category"] = gt
            results.append(result)

            if (i + 1) % 10 == 0:
                correct = sum(
                    1 for r in results
                    if r["final_category"]
                    == r["ground_truth_category"]
                )
                acc = correct / len(results) * 100
                print(
                    f"  [{i+1}/{len(records)}] "
                    f"Accuracy: {correct}/{len(results)} "
                    f"({acc:.1f}%)"
                )

        except Exception as e:
            print(f"  Error on query {i+1}: {e}")
            results.append({
                "query": query,
                "final_category": "ERROR",
                "ground_truth_category": record.get(
                    "category", ""
                ),
                "error": str(e),
            })

    # Save results
    if args.output:
        output_path = Path(args.output)
    else:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_path = Path(
            f"llm_router/results/"
            f"batch_{args.strategy}_{ts}.jsonl"
        )

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        for r in results:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

    correct = sum(
        1 for r in results
        if r.get("final_category")
        == r.get("ground_truth_category")
    )
    total = len(
        [r for r in results if r.get("ground_truth_category")]
    )

    print("\n" + "=" * 70)
    print("BATCH RESULTS")
    print("=" * 70)
    print(f"Total queries:  {len(results)}")
    if total > 0:
        acc = correct / total * 100
        print(f"Accuracy:       {correct}/{total} ({acc:.1f}%)")
    print(f"Results saved:  {output_path}")


def main():
    parser = argparse.ArgumentParser(
        description="LLM-as-Router: Route queries"
    )

    parser.add_argument(
        "--query", type=str, help="Single query to route"
    )
    parser.add_argument(
        "--interactive", action="store_true",
        help="Interactive mode",
    )
    parser.add_argument(
        "--input", type=str,
        help="Input JSONL file for batch routing",
    )
    parser.add_argument(
        "--output", type=str,
        help="Output file for batch results",
    )
    parser.add_argument(
        "--sample", type=int,
        help="Sample N queries from input",
    )
    parser.add_argument(
        "--model", type=str, default="gpt-4o-mini",
        help="Router LLM model (default: gpt-4o-mini)",
    )
    parser.add_argument(
        "--strategy", type=str, default="zero_shot",
        choices=PROMPT_STRATEGIES,
        help="Prompt strategy (default: zero_shot)",
    )
    parser.add_argument(
        "--verbose", action="store_true",
        help="Show detailed output",
    )
    args = parser.parse_args()

    if args.interactive:
        run_interactive(args)
    elif args.query:
        run_single_query(args)
    elif args.input:
        run_batch(args)
    else:
        parser.error("Specify --query, --interactive, or --input")


if __name__ == "__main__":
    main()
