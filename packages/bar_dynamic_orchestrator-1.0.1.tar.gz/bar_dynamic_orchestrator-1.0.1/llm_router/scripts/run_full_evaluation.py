"""
Full 6-phase evaluation pipeline for LLM-as-Router.

Phase 1: Prompt strategy comparison (4 strategies)
Phase 2: OpenAI model comparison (5 models)
Phase 3: Provider comparison (OpenAI vs Anthropic vs Google)
Phase 4: Single-call vs multi-step routing
Phase 5: Temperature sensitivity (4 values)
Phase 6: Confidence threshold analysis (3 values)

Usage:
    python -m llm_router.scripts.run_full_evaluation
    python -m llm_router.scripts.run_full_evaluation --phase 1
    python -m llm_router.scripts.run_full_evaluation --sample 50
"""

import argparse
import json
import sys
from pathlib import Path
from datetime import datetime

from llm_router.evaluation.evaluator import (
    RouterEvaluator,
)
from llm_router.evaluation.metrics import (
    print_metrics_report,
)
from llm_router.config.settings import (
    PROMPT_STRATEGIES,
    EVAL_OPENAI_MODELS,
    EVAL_PROVIDERS,
    EVAL_LOCAL_MODELS,
    EVAL_TEMPERATURES,
    EVAL_CONFIDENCE_THRESHOLDS,
    EVAL_LLMAPI_MODELS,
    EVAL_LLMAPI_STRATEGIES,
)

# Default dataset path
PROJECT_ROOT = Path(__file__).parent.parent.parent
DEFAULT_DATASET = str(
    PROJECT_ROOT / "data" / "training_data"
    / "test.jsonl"
)
OUTPUT_DIR = str(
    PROJECT_ROOT / "llm_router" / "results"
)
OUTPUT_FILE = str(
    PROJECT_ROOT / "llm_router" / "results"
    / "llm_router_evaluation.json"
)


def _extract_experiment(
    evaluation: dict, name: str
) -> dict:
    """Extract experiment summary from evaluation."""
    metrics = evaluation["metrics"]
    meta = metrics.get("evaluation_metadata", {})

    return {
        "name": name,
        "accuracy": metrics.get("accuracy", 0),
        "macro_f1": metrics.get("macro_f1", 0),
        "weighted_f1": metrics.get("weighted_f1", 0),
        "per_category": metrics.get(
            "per_category", {}
        ),
        "confusion_matrix": metrics.get(
            "confusion_matrix", {}
        ),
        "avg_latency_ms": meta.get(
            "avg_latency_ms", 0
        ),
        "total_cost_usd": meta.get(
            "total_cost_usd", 0
        ),
        "total_tokens": meta.get("total_tokens", 0),
        "avg_confidence": meta.get(
            "avg_confidence", 0
        ),
    }


def run_phase1(
    dataset_path: str, sample_size: int = None
) -> dict:
    """Phase 1: Compare 4 prompt strategies."""
    print("\n" + "=" * 80)
    print("PHASE 1: Prompt Strategy Comparison")
    print("=" * 80)

    experiments = []
    for strategy in PROMPT_STRATEGIES:
        print(f"\n--- Strategy: {strategy} ---")
        evaluator = RouterEvaluator(
            model="gpt-4o-mini", provider="openai",
        )
        records = evaluator.load_dataset(
            dataset_path, sample_size=sample_size,
        )
        evaluation = evaluator.evaluate(
            records, prompt_strategy=strategy,
        )
        print_metrics_report(evaluation["metrics"])
        experiments.append(
            _extract_experiment(evaluation, strategy)
        )

    return {
        "phase": 1,
        "description": (
            "4 prompt strategies with gpt-4o-mini"
        ),
        "fixed": {
            "model": "gpt-4o-mini",
            "temperature": 0.1,
        },
        "experiments": experiments,
    }


def _best_strategy(phase1: dict) -> str:
    """Get best strategy from Phase 1 results."""
    best = max(
        phase1["experiments"],
        key=lambda e: e["macro_f1"],
    )
    print(
        f"\nBest strategy from Phase 1: {best['name']} "
        f"(F1: {best['macro_f1']:.4f})"
    )
    return best["name"]


def _make_phase2_result(experiments):
    """Build Phase 2 result dict."""
    return {
        "phase": 2,
        "description": (
            "OpenAI models × all strategies"
        ),
        "fixed": {
            "temperature": 0.1,
            "provider": "openai",
        },
        "experiments": experiments,
    }


def run_phase2(
    dataset_path: str,
    best_strat: str,
    sample_size: int = None,
    existing_experiments: list = None,
    save_fn=None,
) -> dict:
    """Phase 2: OpenAI models × all strategies.
    Skips model/strategy combos that already have results.
    Saves after each experiment via save_fn to avoid
    data loss on crash.
    """
    print("\n" + "=" * 80)
    print("PHASE 2: OpenAI Model Comparison")
    print("All strategies × all OpenAI models")
    print("=" * 80)

    experiments = list(existing_experiments or [])
    done = {e["name"] for e in experiments}

    for model in EVAL_OPENAI_MODELS:
        for strategy in PROMPT_STRATEGIES:
            name = f"{model}/{strategy}"
            if name in done:
                print(
                    f"\n--- {name} --- SKIP (exists)"
                )
                continue
            print(f"\n--- {name} ---")
            evaluator = RouterEvaluator(
                model=model, provider="openai",
            )
            records = evaluator.load_dataset(
                dataset_path, sample_size=sample_size,
            )
            evaluation = evaluator.evaluate(
                records, prompt_strategy=strategy,
            )
            print_metrics_report(evaluation["metrics"])
            exp = _extract_experiment(
                evaluation, name,
            )
            exp["model"] = model
            exp["strategy"] = strategy
            experiments.append(exp)
            # Save after each experiment
            if save_fn:
                save_fn(
                    _make_phase2_result(experiments)
                )

    return _make_phase2_result(experiments)


def _best_model(phase2: dict) -> str:
    """Get best model from Phase 2 results."""
    best = max(
        phase2["experiments"],
        key=lambda e: e["macro_f1"],
    )
    print(
        f"\nBest model from Phase 2: {best['name']} "
        f"(F1: {best['macro_f1']:.4f})"
    )
    return best["name"]


def run_phase3(
    dataset_path: str,
    best_strat: str,
    sample_size: int = None,
    existing_experiments: list = None,
) -> dict:
    """Phase 3: Compare providers.
    Skips providers that already have results.
    Pre-seeds openai result from Phase 1 if available.
    """
    print("\n" + "=" * 80)
    print("PHASE 3: Provider Comparison")
    print("=" * 80)

    experiments = list(existing_experiments or [])
    done = {e["name"] for e in experiments}

    for provider, model in EVAL_PROVIDERS.items():
        name = f"{provider}/{model}"
        if name in done:
            print(f"\n--- {name} --- SKIP (exists)")
            continue
        print(f"\n--- Provider: {name} ---")
        evaluator = RouterEvaluator(
            model=model, provider=provider,
        )
        records = evaluator.load_dataset(
            dataset_path, sample_size=sample_size,
        )
        evaluation = evaluator.evaluate(
            records, prompt_strategy=best_strat,
        )
        print_metrics_report(evaluation["metrics"])
        experiments.append(
            _extract_experiment(evaluation, name)
        )

    return {
        "phase": 3,
        "description": (
            "OpenAI vs Anthropic vs Google vs DeepSeek"
        ),
        "fixed": {
            "strategy": best_strat,
            "temperature": 0.1,
        },
        "experiments": experiments,
    }


def run_phase4(
    dataset_path: str,
    best_strat: str,
    best_model: str,
    sample_size: int = None,
) -> dict:
    """Phase 4: Single-call vs multi-step."""
    print("\n" + "=" * 80)
    print("PHASE 4: Single-call vs Multi-step")
    print("=" * 80)

    experiments = []

    # Single-call
    print("\n--- Approach: single_call ---")
    evaluator = RouterEvaluator(
        model=best_model, provider="openai",
    )
    records = evaluator.load_dataset(
        dataset_path, sample_size=sample_size,
    )
    evaluation = evaluator.evaluate(
        records,
        prompt_strategy=best_strat,
        routing_approach="single_call",
    )
    print_metrics_report(evaluation["metrics"])
    experiments.append(
        _extract_experiment(
            evaluation, "single_call"
        )
    )

    # Multi-step
    print("\n--- Approach: multi_step ---")
    evaluator2 = RouterEvaluator(
        model=best_model, provider="openai",
    )
    records2 = evaluator2.load_dataset(
        dataset_path, sample_size=sample_size,
    )
    evaluation2 = evaluator2.evaluate(
        records2,
        prompt_strategy=best_strat,
        routing_approach="multi_step",
    )
    print_metrics_report(evaluation2["metrics"])
    experiments.append(
        _extract_experiment(
            evaluation2, "multi_step"
        )
    )

    return {
        "phase": 4,
        "description": (
            "Single-call vs multi-step routing"
        ),
        "fixed": {
            "model": best_model,
            "strategy": best_strat,
            "temperature": 0.1,
        },
        "experiments": experiments,
    }


def run_phase5(
    dataset_path: str,
    best_strat: str,
    best_model: str,
    sample_size: int = None,
) -> dict:
    """Phase 5: Temperature sensitivity."""
    print("\n" + "=" * 80)
    print("PHASE 5: Temperature Sensitivity")
    print("=" * 80)

    experiments = []
    for temp in EVAL_TEMPERATURES:
        name = f"temp_{temp}"
        print(f"\n--- Temperature: {temp} ---")
        evaluator = RouterEvaluator(
            model=best_model, provider="openai",
        )
        records = evaluator.load_dataset(
            dataset_path, sample_size=sample_size,
        )
        evaluation = evaluator.evaluate(
            records,
            prompt_strategy=best_strat,
            temperature=temp,
        )
        print_metrics_report(evaluation["metrics"])
        experiments.append(
            _extract_experiment(evaluation, name)
        )

    return {
        "phase": 5,
        "description": "Temperature sweep",
        "fixed": {
            "model": best_model,
            "strategy": best_strat,
        },
        "experiments": experiments,
    }


def run_phase6(
    dataset_path: str,
    best_strat: str,
    best_model: str,
    sample_size: int = None,
) -> dict:
    """Phase 6: Confidence threshold analysis."""
    print("\n" + "=" * 80)
    print("PHASE 6: Confidence Threshold")
    print("=" * 80)

    experiments = []
    for threshold in EVAL_CONFIDENCE_THRESHOLDS:
        name = f"threshold_{threshold}"
        print(
            f"\n--- Confidence threshold: "
            f"{threshold} ---"
        )
        evaluator = RouterEvaluator(
            model=best_model, provider="openai",
        )
        records = evaluator.load_dataset(
            dataset_path, sample_size=sample_size,
        )
        evaluation = evaluator.evaluate(
            records,
            prompt_strategy=best_strat,
            confidence_threshold=threshold,
        )
        print_metrics_report(evaluation["metrics"])

        # Count low-confidence rejections
        low_conf_count = sum(
            1 for r in evaluation["results"]
            if not r.get("is_valid", True)
        )
        exp = _extract_experiment(evaluation, name)
        exp["low_confidence_rejections"] = (
            low_conf_count
        )
        exp["rejection_rate"] = round(
            low_conf_count / len(evaluation["results"]),
            4,
        ) if evaluation["results"] else 0
        experiments.append(exp)

    return {
        "phase": 6,
        "description": (
            "Confidence threshold analysis"
        ),
        "fixed": {
            "model": best_model,
            "strategy": best_strat,
            "temperature": 0.1,
        },
        "experiments": experiments,
    }


def run_phase7(
    dataset_path: str,
    best_strat: str,
    sample_size: int = None,
    existing_experiments: list = None,
) -> dict:
    """Phase 7: Local models × all strategies via Ollama.
    Skips model/strategy combos that already have results.
    """
    print("\n" + "=" * 80)
    print("PHASE 7: Local Model Comparison (Ollama)")
    print("All strategies × all local models")
    print("=" * 80)

    # Keep existing experiments, skip already-done combos
    experiments = list(existing_experiments or [])
    done = {e["name"] for e in experiments}

    for model in EVAL_LOCAL_MODELS:
        for strategy in PROMPT_STRATEGIES:
            name = f"{model}/{strategy}"
            if name in done:
                print(f"\n--- {name} --- SKIP (exists)")
                continue
            print(f"\n--- {name} ---")
            evaluator = RouterEvaluator(
                model=model, provider="ollama",
            )
            records = evaluator.load_dataset(
                dataset_path, sample_size=sample_size,
            )
            evaluation = evaluator.evaluate(
                records, prompt_strategy=strategy,
            )
            print_metrics_report(evaluation["metrics"])
            exp = _extract_experiment(
                evaluation, name,
            )
            exp["model"] = model
            exp["strategy"] = strategy
            experiments.append(exp)

    return {
        "phase": 7,
        "description": (
            "Local models × all strategies via Ollama "
            "(free, on-device)"
        ),
        "fixed": {
            "temperature": 0.1,
            "provider": "ollama",
        },
        "experiments": experiments,
    }


def run_phase8(
    dataset_path: str,
    best_strat: str,
    sample_size: int = None,
    existing_experiments: list = None,
    save_fn=None,
) -> dict:
    """Phase 8: llmapi.ai — new model families not in Phase 3.
    EVAL_LLMAPI_MODELS is a list of (model_id, family) tuples.
    Saves after each experiment via save_fn to avoid data loss
    on crash. Skips already-done combos.
    """
    print("\n" + "=" * 80)
    print("PHASE 8: llmapi.ai — New Model Families")
    print("Meta / Mistral / xAI / Alibaba / DeepSeek / Google")
    print("=" * 80)

    experiments = list(existing_experiments or [])
    done = {e["name"] for e in experiments}

    def _result():
        return {
            "phase": 8,
            "description": (
                "llmapi.ai — new model families: "
                "Meta, Mistral, xAI, Alibaba, "
                "DeepSeek-v3.2, Gemini-2.5-Flash-Lite"
            ),
            "fixed": {
                "temperature": 0.1,
                "provider": "llmapi",
            },
            "experiments": experiments,
        }

    for model_id, family in EVAL_LLMAPI_MODELS:
        for strategy in EVAL_LLMAPI_STRATEGIES:
            name = f"llmapi/{family}/{model_id}/{strategy}"
            if name in done:
                print(
                    f"\n--- {name} --- SKIP (exists)"
                )
                continue
            print(f"\n--- {name} ---")
            evaluator = RouterEvaluator(
                model=model_id, provider="llmapi",
            )
            records = evaluator.load_dataset(
                dataset_path, sample_size=sample_size,
            )
            evaluation = evaluator.evaluate(
                records, prompt_strategy=strategy,
            )
            print_metrics_report(evaluation["metrics"])
            exp = _extract_experiment(evaluation, name)
            exp["model"] = model_id
            exp["family"] = family
            exp["strategy"] = strategy
            exp["provider"] = "llmapi"
            experiments.append(exp)
            # Save after each experiment — safe to interrupt
            if save_fn:
                save_fn(_result())

    return _result()


def load_existing_results() -> dict:
    """Load existing results if available."""
    if Path(OUTPUT_FILE).exists():
        with open(OUTPUT_FILE) as f:
            return json.load(f)
    return None


def save_consolidated(results: dict):
    """Save consolidated results.

    Writes atomically: new data goes to a .tmp file first,
    then replaces the original — so a crash mid-write never
    corrupts existing results.
    """
    Path(OUTPUT_DIR).mkdir(parents=True, exist_ok=True)
    tmp_file = OUTPUT_FILE + ".tmp"
    with open(tmp_file, "w") as f:
        json.dump(results, f, indent=2)
    # Atomic replace — existing file untouched until
    # the new one is fully written
    Path(tmp_file).replace(OUTPUT_FILE)
    print(f"\nConsolidated results: {OUTPUT_FILE}")


def main():
    parser = argparse.ArgumentParser(
        description=(
            "Run LLM-as-Router 6-phase evaluation"
        ),
    )
    parser.add_argument(
        "--dataset", default=DEFAULT_DATASET,
        help="Path to labeled JSONL dataset",
    )
    parser.add_argument(
        "--phase", type=int, default=None,
        help="Run specific phase (1-6)",
    )
    parser.add_argument(
        "--sample", type=int, default=None,
        help="Sample size for testing",
    )
    parser.add_argument(
        "--resume", action="store_true",
        help=(
            "Resume from existing results "
            "(skip completed phases)"
        ),
    )
    args = parser.parse_args()

    # Check dataset exists
    if not Path(args.dataset).exists():
        print(
            f"ERROR: Dataset not found: {args.dataset}"
        )
        sys.exit(1)

    # Load existing results when resuming or running
    # a specific phase (needs prior phase data)
    existing = None
    if args.resume or args.phase:
        existing = load_existing_results()

    consolidated = existing or {
        "timestamp": datetime.now().isoformat(),
        "dataset_path": args.dataset,
        "dataset_size": args.sample or "full",
        "phases": {},
    }

    phases_to_run = (
        [args.phase] if args.phase
        else [1, 2, 3, 4, 5, 6, 7, 8]
    )

    # Phase 1
    if 1 in phases_to_run:
        if (
            args.resume
            and "strategy_comparison"
            in consolidated.get("phases", {})
        ):
            print("Phase 1 already done, skipping.")
        else:
            p1 = run_phase1(
                args.dataset, args.sample,
            )
            consolidated["phases"][
                "strategy_comparison"
            ] = p1
            save_consolidated(consolidated)

    # Determine best strategy
    p1_data = consolidated["phases"].get(
        "strategy_comparison"
    )
    if not p1_data:
        print(
            "ERROR: Phase 1 results needed. "
            "Run phase 1 first."
        )
        sys.exit(1)
    best_strat = _best_strategy(p1_data)

    # Phase 2
    if 2 in phases_to_run:
        existing_p2 = consolidated.get(
            "phases", {}
        ).get("model_comparison", {})
        existing_exps2 = list(
            existing_p2.get("experiments", [])
        )
        # Seed Phase 2 with Phase 1 gpt-4o-mini results
        # (avoid re-running gpt-4o-mini experiments)
        done_names = {e["name"] for e in existing_exps2}
        if p1_data:
            for exp in p1_data.get("experiments", []):
                p2_name = f"gpt-4o-mini/{exp['name']}"
                if p2_name not in done_names:
                    seeded = dict(exp)
                    seeded["name"] = p2_name
                    seeded["model"] = "gpt-4o-mini"
                    seeded["strategy"] = exp["name"]
                    existing_exps2.append(seeded)

        def _save_p2(result):
            consolidated["phases"][
                "model_comparison"
            ] = result
            save_consolidated(consolidated)

        p2 = run_phase2(
            args.dataset, best_strat, args.sample,
            existing_experiments=existing_exps2,
            save_fn=_save_p2,
        )
        consolidated["phases"][
            "model_comparison"
        ] = p2
        save_consolidated(consolidated)

    # Determine best model
    p2_data = consolidated["phases"].get(
        "model_comparison"
    )
    best_mdl = "gpt-4o-mini"
    if p2_data:
        best_mdl = _best_model(p2_data)

    # Phase 3
    if 3 in phases_to_run:
        if (
            args.resume
            and "provider_comparison"
            in consolidated.get("phases", {})
        ):
            print("Phase 3 already done, skipping.")
        else:
            # Seed openai/gpt-4o-mini from Phase 1 to
            # avoid re-running it
            existing_p3 = list(
                consolidated.get("phases", {})
                .get("provider_comparison", {})
                .get("experiments", [])
            )
            done_p3 = {e["name"] for e in existing_p3}
            openai_model = EVAL_PROVIDERS.get(
                "openai", "gpt-4o-mini"
            )
            openai_key = f"openai/{openai_model}"
            if (
                openai_key not in done_p3
                and p1_data
            ):
                # Find best_strat result from Phase 1
                for exp in p1_data.get(
                    "experiments", []
                ):
                    if exp["name"] == best_strat:
                        seeded = dict(exp)
                        seeded["name"] = openai_key
                        existing_p3.append(seeded)
                        break
            p3 = run_phase3(
                args.dataset, best_strat, args.sample,
                existing_experiments=existing_p3,
            )
            consolidated["phases"][
                "provider_comparison"
            ] = p3
            save_consolidated(consolidated)

    # Phase 4
    if 4 in phases_to_run:
        if (
            args.resume
            and "routing_approach"
            in consolidated.get("phases", {})
        ):
            print("Phase 4 already done, skipping.")
        else:
            p4 = run_phase4(
                args.dataset, best_strat,
                best_mdl, args.sample,
            )
            consolidated["phases"][
                "routing_approach"
            ] = p4
            save_consolidated(consolidated)

    # Phase 5
    if 5 in phases_to_run:
        if (
            args.resume
            and "temperature_sensitivity"
            in consolidated.get("phases", {})
        ):
            print("Phase 5 already done, skipping.")
        else:
            p5 = run_phase5(
                args.dataset, best_strat,
                best_mdl, args.sample,
            )
            consolidated["phases"][
                "temperature_sensitivity"
            ] = p5
            save_consolidated(consolidated)

    # Phase 6
    if 6 in phases_to_run:
        if (
            args.resume
            and "confidence_threshold"
            in consolidated.get("phases", {})
        ):
            print("Phase 6 already done, skipping.")
        else:
            p6 = run_phase6(
                args.dataset, best_strat,
                best_mdl, args.sample,
            )
            consolidated["phases"][
                "confidence_threshold"
            ] = p6
            save_consolidated(consolidated)

    # Phase 7
    if 7 in phases_to_run:
        existing_p7 = consolidated.get(
            "phases", {}
        ).get("local_model_comparison", {})
        existing_exps = existing_p7.get(
            "experiments", []
        )
        p7 = run_phase7(
            args.dataset, best_strat, args.sample,
            existing_experiments=existing_exps,
        )
        consolidated["phases"][
            "local_model_comparison"
        ] = p7
        save_consolidated(consolidated)

    # Phase 8
    if 8 in phases_to_run:
        existing_p8 = consolidated.get(
            "phases", {}
        ).get("llmapi_comparison", {})
        existing_exps8 = existing_p8.get(
            "experiments", []
        )

        def _save_p8(result):
            consolidated["phases"][
                "llmapi_comparison"
            ] = result
            save_consolidated(consolidated)

        p8 = run_phase8(
            args.dataset, best_strat, args.sample,
            existing_experiments=existing_exps8,
            save_fn=_save_p8,
        )
        consolidated["phases"][
            "llmapi_comparison"
        ] = p8
        save_consolidated(consolidated)

    # Final save
    consolidated["timestamp"] = (
        datetime.now().isoformat()
    )
    save_consolidated(consolidated)

    print("\n" + "=" * 80)
    print("ALL PHASES COMPLETE")
    print(f"Results: {OUTPUT_FILE}")
    print("=" * 80)


if __name__ == "__main__":
    main()
