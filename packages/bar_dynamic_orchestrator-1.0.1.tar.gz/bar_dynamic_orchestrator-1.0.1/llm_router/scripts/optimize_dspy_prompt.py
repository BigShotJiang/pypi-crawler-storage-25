"""
DSPy prompt optimization for query classification.

Supports 3 optimizers:
- COPRO: instruction optimization only
- BootstrapFewShot: example selection only
- MIPROv2: instruction + example optimization (joint)

Usage:
    # Run all 3 optimizers
    python -m llm_router.scripts.optimize_dspy_prompt

    # Run a specific optimizer
    python -m llm_router.scripts.optimize_dspy_prompt \
        --optimizer mipro

    # Custom settings
    python -m llm_router.scripts.optimize_dspy_prompt \
        --optimizer mipro --num-candidates 15
"""

import argparse
import json
import random
import time
from pathlib import Path
from datetime import datetime

import dspy

# Load .env at module level
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

# ── Langfuse tracing ──────────────────────────────
# Auto-instrument DSPy calls for cost tracking
try:
    from langfuse import get_client
    from openinference.instrumentation.dspy import (
        DSPyInstrumentor,
    )
    _langfuse = get_client()
    if _langfuse.auth_check():
        DSPyInstrumentor().instrument()
        print("[Langfuse] Tracing enabled for DSPy")
    else:
        print("[Langfuse] Auth failed — no tracing")
except ImportError:
    print("[Langfuse] Not installed — no tracing")

# Paths
PROJECT_ROOT = Path(__file__).parent.parent.parent
DEFAULT_TRAIN = str(
    PROJECT_ROOT / "data" / "training_data"
    / "train.jsonl"
)
DEFAULT_VAL = str(
    PROJECT_ROOT / "data" / "training_data"
    / "val.jsonl"
)
PROMPTS_DIR = (
    PROJECT_ROOT / "llm_router" / "config" / "prompts"
)

# Output file per optimizer
OUTPUT_FILES = {
    "copro": str(
        PROMPTS_DIR / "dspy_copro_optimized.json"
    ),
    "bootstrap": str(
        PROMPTS_DIR / "dspy_bootstrap_optimized.json"
    ),
    "mipro": str(
        PROMPTS_DIR / "dspy_mipro_optimized.json"
    ),
}

# Valid categories
VALID_CATEGORIES = [
    "REASONING", "CODE", "CREATIVE_WRITING",
    "FACTUAL_KNOWLEDGE", "INSTRUCTION_FOLLOWING",
    "CONVERSATIONAL", "MULTILINGUAL",
    "SUMMARIZATION", "MEDICAL", "LEGAL", "FINANCE",
]

CATEGORIES_STR = ", ".join(VALID_CATEGORIES)


# ── DSPy Signature ─────────────────────────────────

class ClassifyQuery(dspy.Signature):
    """Classify a user query into exactly one routing
    category. Categories: REASONING, CODE,
    CREATIVE_WRITING, FACTUAL_KNOWLEDGE,
    INSTRUCTION_FOLLOWING, CONVERSATIONAL,
    MULTILINGUAL, SUMMARIZATION, MEDICAL, LEGAL,
    FINANCE. Domain categories (MEDICAL, LEGAL,
    FINANCE) take precedence over general categories.
    """

    query: str = dspy.InputField(
        desc="The user query to classify"
    )
    category: str = dspy.OutputField(
        desc=f"Exactly one of: {CATEGORIES_STR}"
    )
    confidence: float = dspy.OutputField(
        desc="Classification confidence from 0.0 to 1.0"
    )
    category_reasoning: str = dspy.OutputField(
        desc="Brief explanation for the classification"
    )


# ── DSPy Module ────────────────────────────────────

class QueryRouter(dspy.Module):
    """Single-call query classification module."""

    def __init__(self):
        self.classify = dspy.ChainOfThought(
            ClassifyQuery
        )

    def forward(self, query: str):
        return self.classify(query=query)


# ── Data Loading ───────────────────────────────────

def load_jsonl_as_examples(
    path: str, sample_size: int = None, seed: int = 42
):
    """Load JSONL records as dspy.Example objects."""
    records = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            try:
                r = json.loads(line.strip())
                if "query" in r and "category" in r:
                    records.append(r)
            except json.JSONDecodeError:
                continue

    if sample_size and sample_size < len(records):
        random.seed(seed)
        records = random.sample(records, sample_size)

    examples = []
    for r in records:
        ex = dspy.Example(
            query=r["query"],
            category=r["category"],
            confidence=str(r.get("confidence", 0.9)),
            category_reasoning=r.get(
                "label_reasoning", ""
            ),
        ).with_inputs("query")
        examples.append(ex)

    print(f"Loaded {len(examples)} examples from {path}")
    return examples


# ── Metric ─────────────────────────────────────────

def category_match(example, prediction, trace=None):
    """Exact match on category (case-insensitive)."""
    pred = prediction.category.strip().upper()
    truth = example.category.strip().upper()
    return pred == truth


# ── Prompt Extraction ──────────────────────────────

def extract_optimized_prompt(optimized_module):
    """
    Extract the optimized instruction and demos from
    the compiled DSPy module into a system prompt string.
    """
    predictor = optimized_module.classify

    # Get the inner Predict module (ChainOfThought wraps it)
    inner = getattr(predictor, "predict", predictor)

    # Get instruction from signature
    instruction = inner.signature.instructions

    # Get demos (few-shot examples)
    demos = getattr(inner, "demos", []) or []

    # Build system prompt
    parts = [instruction]

    if demos:
        parts.append("\n\n## Examples\n")
        for i, demo in enumerate(demos, 1):
            query = getattr(demo, "query", "")
            category = getattr(demo, "category", "")
            confidence = getattr(
                demo, "confidence", "0.9"
            )
            reasoning = getattr(
                demo, "category_reasoning", ""
            )
            parts.append(
                f"Example {i}:\n"
                f'  Query: "{query}"\n'
                f"  Category: {category}\n"
                f"  Confidence: {confidence}\n"
                f"  Reasoning: {reasoning}\n"
            )

    # Add response format (same as other strategies)
    parts.append(
        "\n## Response Format\n"
        "Respond with a JSON object:\n"
        "{\n"
        '  "category": "CATEGORY_NAME",\n'
        '  "confidence": 0.0 to 1.0,\n'
        '  "category_reasoning": "Why this category"\n'
        "}"
    )

    system_prompt = "\n".join(parts)

    # Extract demos as dicts for saving
    demos_list = []
    for demo in demos:
        demos_list.append({
            "query": getattr(demo, "query", ""),
            "category": getattr(demo, "category", ""),
            "confidence": str(
                getattr(demo, "confidence", "0.9")
            ),
            "category_reasoning": getattr(
                demo, "category_reasoning", ""
            ),
        })

    return system_prompt, demos_list, instruction


# ── Evaluation ─────────────────────────────────────

def evaluate_on_valset(optimized, valset):
    """Evaluate optimized module on validation set."""
    correct = 0
    total = len(valset)
    for ex in valset:
        try:
            pred = optimized(query=ex.query)
            if category_match(ex, pred):
                correct += 1
        except Exception:
            pass
    accuracy = correct / total if total > 0 else 0
    print(
        f"Validation accuracy: {accuracy:.4f} "
        f"({correct}/{total})"
    )
    return accuracy


# ── Save Results ───────────────────────────────────

def save_result(
    output_path, optimizer_name, model,
    system_prompt, instruction, demos, val_accuracy,
    elapsed, args,
):
    """Save optimized prompt to JSON."""
    output_data = {
        "optimization_metadata": {
            "optimizer": optimizer_name,
            "timestamp": datetime.now().isoformat(),
            "train_data": args.train_data,
            "val_data": args.val_data,
            "model": model,
            "train_sample_size": args.train_sample,
            "val_sample_size": args.val_sample,
            "val_accuracy": round(val_accuracy, 4),
            "optimization_time_seconds": round(
                elapsed, 1
            ),
        },
        "system_prompt": system_prompt,
        "instruction": instruction,
        "demos": demos,
    }

    Path(output_path).parent.mkdir(
        parents=True, exist_ok=True
    )
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(
            output_data, f, indent=2,
            ensure_ascii=False,
        )

    print(f"Saved to: {output_path}")


# ── Optimizer Runners ──────────────────────────────

def run_copro(router, trainset, valset, args):
    """
    COPRO: Instruction optimization only.
    Generates candidate instructions and picks the best.
    No example selection.
    """
    print("\n" + "=" * 60)
    print("COPRO — Instruction Optimization Only")
    print("=" * 60)

    t0 = time.time()

    optimizer = dspy.COPRO(
        metric=category_match,
        breadth=args.num_candidates,
        depth=2,
    )

    optimized = optimizer.compile(
        router,
        trainset=trainset,
        eval_kwargs={"num_threads": 4},
    )

    elapsed = time.time() - t0
    print(f"COPRO completed in {elapsed:.0f}s")

    # Evaluate
    print("\nEvaluating COPRO on validation set...")
    val_accuracy = evaluate_on_valset(optimized, valset)

    # Extract and save
    system_prompt, demos, instruction = (
        extract_optimized_prompt(optimized)
    )
    print(f"Instruction length: {len(instruction)} chars")
    print(f"Demos: {len(demos)} (should be 0 for COPRO)")

    save_result(
        OUTPUT_FILES["copro"], "copro", args.model,
        system_prompt, instruction, demos,
        val_accuracy, elapsed, args,
    )

    return val_accuracy


def run_bootstrap(router, trainset, valset, args):
    """
    BootstrapFewShot: Example selection only.
    Selects the best few-shot examples from training data.
    Does not modify instructions.
    """
    print("\n" + "=" * 60)
    print("BootstrapFewShot — Example Selection Only")
    print("=" * 60)

    t0 = time.time()

    optimizer = dspy.BootstrapFewShot(
        metric=category_match,
        max_bootstrapped_demos=args.max_demos,
        max_labeled_demos=args.max_demos,
        max_rounds=2,
    )

    optimized = optimizer.compile(
        router,
        trainset=trainset,
    )

    elapsed = time.time() - t0
    print(f"BootstrapFewShot completed in {elapsed:.0f}s")

    # Evaluate
    print("\nEvaluating BootstrapFewShot on val set...")
    val_accuracy = evaluate_on_valset(optimized, valset)

    # Extract and save
    system_prompt, demos, instruction = (
        extract_optimized_prompt(optimized)
    )
    print(f"Instruction length: {len(instruction)} chars")
    print(f"Demos: {len(demos)}")

    save_result(
        OUTPUT_FILES["bootstrap"], "bootstrap",
        args.model, system_prompt, instruction, demos,
        val_accuracy, elapsed, args,
    )

    return val_accuracy


def run_mipro(router, trainset, valset, args):
    """
    MIPROv2: Joint instruction + example optimization.
    Generates instructions AND selects examples, then
    finds the best combination via Bayesian optimization.
    """
    print("\n" + "=" * 60)
    print("MIPROv2 — Joint Instruction + Example Optimization")
    print("=" * 60)

    t0 = time.time()

    optimizer = dspy.MIPROv2(
        metric=category_match,
        max_bootstrapped_demos=args.max_demos,
        max_labeled_demos=args.max_demos,
        auto="medium",
    )

    optimized = optimizer.compile(
        router,
        trainset=trainset,
        valset=valset,
    )

    elapsed = time.time() - t0
    print(f"MIPROv2 completed in {elapsed:.0f}s")

    # Evaluate
    print("\nEvaluating MIPROv2 on validation set...")
    val_accuracy = evaluate_on_valset(optimized, valset)

    # Extract and save
    system_prompt, demos, instruction = (
        extract_optimized_prompt(optimized)
    )
    print(f"Instruction length: {len(instruction)} chars")
    print(f"Demos: {len(demos)}")

    save_result(
        OUTPUT_FILES["mipro"], "mipro", args.model,
        system_prompt, instruction, demos,
        val_accuracy, elapsed, args,
    )

    return val_accuracy


# ── Main ───────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description=(
            "Optimize routing prompt with DSPy optimizers"
        ),
    )
    parser.add_argument(
        "--optimizer",
        choices=["copro", "bootstrap", "mipro", "all"],
        default="all",
        help="Which optimizer to run (default: all)",
    )
    parser.add_argument(
        "--train-data", default=DEFAULT_TRAIN,
        help="Path to training JSONL",
    )
    parser.add_argument(
        "--val-data", default=DEFAULT_VAL,
        help="Path to validation JSONL",
    )
    parser.add_argument(
        "--model", default="gpt-4o-mini",
        help="LLM model for optimization",
    )
    parser.add_argument(
        "--num-candidates", type=int, default=10,
        help="Number of candidate programs (COPRO/MIPRO)",
    )
    parser.add_argument(
        "--max-demos", type=int, default=3,
        help="Max few-shot demos (Bootstrap/MIPRO)",
    )
    parser.add_argument(
        "--train-sample", type=int, default=300,
        help="Sample N from training data",
    )
    parser.add_argument(
        "--val-sample", type=int, default=200,
        help="Sample N from validation data",
    )
    args = parser.parse_args()

    print("=" * 60)
    print("DSPy Prompt Optimization")
    print("=" * 60)
    print(f"Optimizer: {args.optimizer}")
    print(f"Model: {args.model}")
    print(f"Candidates: {args.num_candidates}")
    print(f"Max demos: {args.max_demos}")
    print(f"Train sample: {args.train_sample}")
    print(f"Val sample: {args.val_sample}")
    print("=" * 60)

    # 1. Configure DSPy
    lm = dspy.LM(
        f"openai/{args.model}",
        temperature=0.1,
    )
    dspy.configure(lm=lm)
    print(f"\nConfigured DSPy with {args.model}")

    # 2. Load data
    trainset = load_jsonl_as_examples(
        args.train_data, args.train_sample,
    )
    valset = load_jsonl_as_examples(
        args.val_data, args.val_sample,
    )

    # 3. Run optimizer(s)
    results = {}

    if args.optimizer in ("copro", "all"):
        router = QueryRouter()
        results["copro"] = run_copro(
            router, trainset, valset, args,
        )

    if args.optimizer in ("bootstrap", "all"):
        router = QueryRouter()
        results["bootstrap"] = run_bootstrap(
            router, trainset, valset, args,
        )

    if args.optimizer in ("mipro", "all"):
        router = QueryRouter()
        results["mipro"] = run_mipro(
            router, trainset, valset, args,
        )

    # 4. Summary
    print("\n" + "=" * 60)
    print("OPTIMIZATION SUMMARY")
    print("=" * 60)
    for name, acc in results.items():
        print(f"  {name:<15} val_accuracy: {acc:.4f}")
    print("=" * 60)
    print(
        "\nNext: run evaluation with all strategies:\n"
        "  python -m llm_router.scripts"
        ".run_full_evaluation --sample 200 --phase 1"
    )


if __name__ == "__main__":
    main()
