"""
CLI script to evaluate the LLM-as-Router against a labeled dataset.

Usage:
    # Evaluate a single strategy
    python -m llm_router.scripts.run_evaluation \
        --input data/final/corrected_20260211_002413.jsonl \
        --strategy chain_of_thought --sample 100

    # Compare all 4 strategies
    python -m llm_router.scripts.run_evaluation \
        --input data/final/corrected_20260211_002413.jsonl \
        --all-strategies --sample 100

    # Compare specific strategies
    python -m llm_router.scripts.run_evaluation \
        --input data/final/corrected_20260211_002413.jsonl \
        --strategies zero_shot few_shot --sample 50
"""

import argparse

from llm_router.evaluation.evaluator import RouterEvaluator
from llm_router.evaluation.compare_strategies import (
    StrategyComparator,
)
from llm_router.evaluation.metrics import print_metrics_report
from llm_router.config.settings import PROMPT_STRATEGIES


def run_single_strategy(args):
    """Evaluate a single prompt strategy."""
    evaluator = RouterEvaluator(model=args.model)

    records = evaluator.load_dataset(
        args.input, sample_size=args.sample
    )

    evaluation = evaluator.evaluate(
        records,
        prompt_strategy=args.strategy,
        verbose=args.verbose,
    )

    print_metrics_report(evaluation["metrics"])
    evaluator.save_evaluation(
        evaluation,
        output_dir=args.output_dir,
        strategy=args.strategy,
    )


def run_comparison(args):
    """Compare multiple strategies."""
    strategies = (
        args.strategies if args.strategies
        else PROMPT_STRATEGIES
    )

    comparator = StrategyComparator(model=args.model)

    comparator.compare(
        dataset_path=args.input,
        strategies=strategies,
        sample_size=args.sample,
        output_dir=args.output_dir,
        verbose=args.verbose,
    )


def main():
    parser = argparse.ArgumentParser(
        description=(
            "Evaluate LLM-as-Router against labeled dataset"
        )
    )

    parser.add_argument(
        "--input", type=str, required=True,
        help="Path to labeled JSONL dataset",
    )
    parser.add_argument(
        "--sample", type=int, default=None,
        help="Sample N queries (for cost management)",
    )
    parser.add_argument(
        "--model", type=str, default="gpt-4o-mini",
        help="Router LLM model (default: gpt-4o-mini)",
    )

    strategy_group = parser.add_mutually_exclusive_group()
    strategy_group.add_argument(
        "--strategy", type=str, choices=PROMPT_STRATEGIES,
        help="Evaluate a single strategy",
    )
    strategy_group.add_argument(
        "--all-strategies", action="store_true",
        help="Compare all 4 strategies",
    )
    strategy_group.add_argument(
        "--strategies", nargs="+",
        choices=PROMPT_STRATEGIES,
        help="Compare specific strategies",
    )

    parser.add_argument(
        "--output-dir", type=str,
        default="llm_router/results",
        help="Output directory for results",
    )
    parser.add_argument(
        "--verbose", action="store_true",
        help="Show per-query results",
    )
    args = parser.parse_args()

    if args.all_strategies or args.strategies:
        run_comparison(args)
    elif args.strategy:
        run_single_strategy(args)
    else:
        args.strategy = "zero_shot"
        run_single_strategy(args)


if __name__ == "__main__":
    main()
