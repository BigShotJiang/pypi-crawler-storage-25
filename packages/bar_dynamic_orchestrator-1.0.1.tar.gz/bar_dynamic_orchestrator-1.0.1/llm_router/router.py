"""
Single-call LLM Router.

Makes a single LLM call to classify a query into one of 11 categories.
Validation is done in pure Python after the call.
"""

import importlib
import time
from typing import Dict, Any, Optional

from llm_router.utils.llm_client import RouterLLMClient
from llm_router.config.settings import (
    VALID_CATEGORIES,
    DEFAULT_ROUTER_MODEL,
    MIN_CONFIDENCE_THRESHOLD,
)

# Load .env at module level
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass


# Fuzzy matching for malformed category names
_CATEGORY_ALIASES = {
    "HEALTHCARE": "MEDICAL",
    "HEALTH": "MEDICAL",
    "LAW": "LEGAL",
    "FINANCIAL": "FINANCE",
    "MONEY": "FINANCE",
    "CHAT": "CONVERSATIONAL",
    "GREETING": "CONVERSATIONAL",
    "PROGRAMMING": "CODE",
    "CODING": "CODE",
    "TRANSLATION": "MULTILINGUAL",
    "WRITING": "CREATIVE_WRITING",
    "CREATIVE": "CREATIVE_WRITING",
    "SUMMARY": "SUMMARIZATION",
    "FACTUAL": "FACTUAL_KNOWLEDGE",
    "KNOWLEDGE": "FACTUAL_KNOWLEDGE",
    "LOGIC": "REASONING",
    "INSTRUCTION": "INSTRUCTION_FOLLOWING",
}


def _fuzzy_match_category(raw: str) -> str:
    return _CATEGORY_ALIASES.get(raw, "FACTUAL_KNOWLEDGE")


# Cost per 1K tokens (input/output) for supported models
_COST_PER_1K = {
    # OpenAI
    "gpt-4o-mini": {
        "input": 0.00015, "output": 0.0006,
    },
    "gpt-4o": {
        "input": 0.0025, "output": 0.01,
    },
    "gpt-4.1-nano": {
        "input": 0.0001, "output": 0.0004,
    },
    "gpt-4.1-mini": {
        "input": 0.0004, "output": 0.0016,
    },
    "gpt-4.1": {
        "input": 0.002, "output": 0.008,
    },
    # Anthropic
    "claude-3-5-haiku-20241022": {
        "input": 0.0008, "output": 0.004,
    },
    "claude-3-5-sonnet-20241022": {
        "input": 0.003, "output": 0.015,
    },
    # Google
    "gemini-2.0-flash": {
        "input": 0.0001, "output": 0.0004,
    },
    "gemini-2.5-flash": {
        "input": 0.0003, "output": 0.0025,
    },
    "gemini-1.5-pro": {
        "input": 0.00125, "output": 0.005,
    },
    # DeepSeek
    "deepseek-chat": {
        "input": 0.00014, "output": 0.00028,
    },
    "deepseek-reasoner": {
        "input": 0.00055, "output": 0.00219,
    },
    # llmapi.ai Phase 8 — new model families
    "llama-3.3-70b-instruct": {
        "input": 0.00027, "output": 0.00027,
    },
    "mistral-small-2506": {
        "input": 0.0001, "output": 0.0003,
    },
    "grok-3": {
        "input": 0.0003, "output": 0.0005,
    },
    "qwen-flash": {
        "input": 0.00005, "output": 0.0004,
    },
    "deepseek-v3.2": {
        "input": 0.00014, "output": 0.00028,
    },
    "gemini-2.5-flash-lite": {
        "input": 0.00005, "output": 0.0002,
    },
    "claude-haiku-4-5": {
        "input": 0.0008, "output": 0.004,
    },
}


class LLMRouter:
    """
    Single-call LLM router.

    Makes one LLM call to classify the query into a category,
    then validates the response in pure Python.
    """

    def __init__(
        self,
        model: str = None,
        provider: str = "openai",
    ):
        self.client = RouterLLMClient(
            model=model or DEFAULT_ROUTER_MODEL,
            provider=provider,
        )

    def route(
        self,
        query: str,
        prompt_strategy: str = "zero_shot",
        temperature: Optional[float] = None,
        confidence_threshold: Optional[float] = None,
    ) -> Dict[str, Any]:
        """
        Route a query with a single LLM call.

        Args:
            query: User query text
            prompt_strategy: One of zero_shot, few_shot,
                chain_of_thought, structured_analysis
            temperature: Override default temperature
            confidence_threshold: Override min confidence

        Returns:
            Dict with final_category, category_confidence,
            is_valid, reasoning, and raw LLM response.
        """
        temp = (
            temperature if temperature is not None
            else 0.1
        )
        threshold = (
            confidence_threshold
            if confidence_threshold is not None
            else MIN_CONFIDENCE_THRESHOLD
        )

        # Load prompt strategy module
        prompt_module = importlib.import_module(
            f"llm_router.config.prompts.{prompt_strategy}"
        )

        system_prompt = prompt_module.get_system_prompt()
        user_prompt = prompt_module.get_user_prompt(query)

        # Token tracking
        total_prompt = 0
        total_completion = 0

        # Single LLM call
        t0 = time.time()
        raw_result = self.client.call(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            temperature=temp,
            json_mode=True,
        )
        t1 = time.time()
        print(
            f"[TIMING] LLM call #1: "
            f"{(t1-t0)*1000:.0f}ms"
        )

        # Accumulate tokens
        usage = raw_result.pop("_usage", {})
        total_prompt += usage.get("prompt_tokens", 0)
        total_completion += usage.get(
            "completion_tokens", 0
        )

        # Parse response
        parsed = self._parse_response(raw_result)

        # Validate
        issues = self._validate(parsed, threshold)

        if issues:
            print(
                f"[TIMING] Validation failed: "
                f"{issues} — retrying..."
            )
            retry_prompt = (
                user_prompt
                + "\n\nPREVIOUS ATTEMPT FAILED "
                + "VALIDATION: "
                + " | ".join(issues)
                + "\nPlease fix and try again."
            )
            t2 = time.time()
            raw_result = self.client.call(
                system_prompt=system_prompt,
                user_prompt=retry_prompt,
                temperature=temp,
                json_mode=True,
            )
            t3 = time.time()
            print(
                f"[TIMING] LLM call #2 (retry): "
                f"{(t3-t2)*1000:.0f}ms"
            )

            # Accumulate retry tokens
            usage2 = raw_result.pop("_usage", {})
            total_prompt += usage2.get(
                "prompt_tokens", 0
            )
            total_completion += usage2.get(
                "completion_tokens", 0
            )

            parsed = self._parse_response(raw_result)
            issues = self._validate(parsed, threshold)

        # If still invalid after retry, apply fallbacks
        if issues:
            parsed = self._apply_fallbacks(parsed)

        # Compute cost
        total_tok = total_prompt + total_completion
        cost = self._estimate_cost(
            total_prompt, total_completion
        )

        # Build output
        return {
            "query": query,
            "final_category": parsed["category"],
            "category_confidence": parsed["confidence"],
            "is_valid": len(issues) == 0,
            "prompt_strategy": prompt_strategy,
            "category_reasoning": parsed[
                "category_reasoning"
            ],
            "raw_llm_response": raw_result,
            "total_tokens": total_tok,
            "estimated_cost_usd": cost,
        }

    def _parse_response(self, result: Dict) -> Dict:
        """Extract category, confidence, reasoning."""
        if result.get("parse_error"):
            return {
                "category": "FACTUAL_KNOWLEDGE",
                "confidence": 0.0,
                "category_reasoning": (
                    "Parse error — defaulting"
                ),
            }

        # Handle nested structures
        if "category_decision" in result:
            decision = result["category_decision"]
            category = decision.get(
                "category",
                result.get("category", "FACTUAL_KNOWLEDGE"),
            )
            confidence = decision.get(
                "confidence",
                result.get("confidence", 0.5),
            )
            category_reasoning = decision.get(
                "reasoning",
                result.get("category_reasoning", ""),
            )
        else:
            category = result.get(
                "category", "FACTUAL_KNOWLEDGE"
            )
            confidence = result.get("confidence", 0.5)
            category_reasoning = result.get(
                "category_reasoning",
                result.get("reasoning", ""),
            )

        # Normalize category
        category = category.upper().strip()
        if category not in VALID_CATEGORIES:
            category = _fuzzy_match_category(category)
            confidence = min(confidence, 0.5)

        return {
            "category": category,
            "confidence": float(confidence),
            "category_reasoning": category_reasoning,
        }

    def _validate(
        self,
        parsed: Dict,
        threshold: float = MIN_CONFIDENCE_THRESHOLD,
    ) -> list:
        """Validate the parsed response."""
        issues = []
        category = parsed["category"]
        confidence = parsed["confidence"]

        if category not in VALID_CATEGORIES:
            issues.append(
                f"Invalid category '{category}'. "
                f"Must be one of: {VALID_CATEGORIES}"
            )

        if confidence < threshold:
            issues.append(
                f"Confidence {confidence:.2f} below "
                f"threshold {threshold}."
            )

        return issues

    def _estimate_cost(
        self, prompt_tokens: int, completion_tokens: int
    ) -> float:
        """Estimate USD cost from token counts."""
        model = self.client.model
        rates = _COST_PER_1K.get(model, {})
        if not rates:
            return 0.0
        cost = (
            prompt_tokens * rates["input"] / 1000
            + completion_tokens * rates["output"] / 1000
        )
        return round(cost, 6)

    def _apply_fallbacks(self, parsed: Dict) -> Dict:
        """Apply fallback corrections."""
        category = parsed["category"]
        if category not in VALID_CATEGORIES:
            parsed["category"] = "FACTUAL_KNOWLEDGE"
        return parsed
