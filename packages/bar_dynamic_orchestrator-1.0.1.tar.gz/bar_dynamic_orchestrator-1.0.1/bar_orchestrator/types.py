from dataclasses import dataclass, field


@dataclass
class RouteResult:
    query: str
    is_complex: bool
    sub_queries: list[str]
    routing: list[str]          # ["$1 → MEDICAL", "$2 → CODE"]
    answer: str
    latency_ms: float
    cost_usd: float
    stages: list[list[str]] = field(default_factory=list)


@dataclass
class DetectResult:
    query: str
    is_complex: bool
    confidence: float
    latency_ms: float


@dataclass
class DecomposeResult:
    query: str
    sub_queries: list[str]
    method: str
    latency_ms: float


@dataclass
class PlanResult:
    sub_queries: list[str]
    stages: list[list[str]]     # [["$1","$3"], ["$2"]]
    execution_tags: dict[str, str]  # {"$1": "PARALLEL", "$2": "SEQUENTIAL"}
