"""
Auto-train detector models on first use.
Trains and saves .pkl files so subsequent runs load instantly.
"""

import json
from pathlib import Path

MODELS_DIR = Path(__file__).parent.parent / "query_decomposition_pipeline" / "models"
DATASET    = Path(__file__).parent.parent / "query_decomposition_pipeline" / "data" / "golden_thesis_dataset_1000.jsonl"

TFIDF_PKL  = MODELS_DIR / "tfidf_svm_detector.pkl"
MINILM_PKL = MODELS_DIR / "minilm_svm_detector.pkl"


def _load_training_data():
    samples = [json.loads(l) for l in DATASET.open()]
    return (
        [s["query"] for s in samples],
        [int(s["is_complex"]) for s in samples],
    )


def ensure_models(detector: str) -> None:
    """Train and save detector model if not already trained."""
    MODELS_DIR.mkdir(parents=True, exist_ok=True)

    if detector == "tfidf_svm" and not TFIDF_PKL.exists():
        print("⚙️  [BAR] Training tfidf_svm detector (first use only, ~5s)...")
        import sys; sys.path.insert(0, str(Path(__file__).parent.parent))
        from query_decomposition_pipeline.complexity_detector.tfidf_svm_detector import TFIDFSVMDetector
        queries, labels = _load_training_data()
        d = TFIDFSVMDetector()
        d.train(queries, labels)
        d.save(str(TFIDF_PKL))
        print(f"✅ [BAR] tfidf_svm saved → {TFIDF_PKL}")

    if detector == "minilm_svm" and not MINILM_PKL.exists():
        print("⚙️  [BAR] Training minilm_svm detector (first use only, ~30s)...")
        import sys; sys.path.insert(0, str(Path(__file__).parent.parent))
        from query_decomposition_pipeline.complexity_detector.minilm_svm_detector import MiniLMSVMDetector
        queries, labels = _load_training_data()
        d = MiniLMSVMDetector()
        d.train(queries, labels)
        d.save(str(MINILM_PKL))
        print(f"✅ [BAR] minilm_svm saved → {MINILM_PKL}")
