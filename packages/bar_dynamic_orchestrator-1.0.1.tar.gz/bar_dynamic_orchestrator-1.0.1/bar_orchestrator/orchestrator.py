"""
BAROrchestrator — main entry point for the BAR pip library.
Wraps UnifiedPipeline with a clean, simple API.
"""

import os
import sys
import time
from pathlib import Path
from typing import Literal, Optional

# Ensure the project root is on sys.path
_ROOT = Path(__file__).parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from .types import RouteResult, DetectResult, DecomposeResult, PlanResult
from .models import ensure_models

RouterApproach  = Literal["transformer", "rag", "llm", "rnn"]
DetectorName    = Literal["rule_based", "tfidf_svm", "minilm_svm"]
DecomposerName  = Literal["rule_based", "llmcompiler", "tor_lite", "amr", "unsupervised"]
AggregationMode = Literal["simple", "llm"]


# Default category → model mapping
DEFAULT_CATEGORY_MODEL_MAP = {
    "REASONING":             "gpt-4o",
    "CODE":                  "gpt-4o",
    "MEDICAL":               "gpt-4o",
    "LEGAL":                 "gpt-4o",
    "FINANCE":               "gpt-4o",
    "CREATIVE_WRITING":      "gpt-4o-mini",
    "FACTUAL_KNOWLEDGE":     "gpt-4o-mini",
    "INSTRUCTION_FOLLOWING": "gpt-4o-mini",
    "CONVERSATIONAL":        "gpt-4o-mini",
    "MULTILINGUAL":          "gpt-4o-mini",
    "SUMMARIZATION":         "gpt-4o-mini",
}


class BAROrchestrator:
    """
    Business-Aware LLM Routing Orchestrator.

    Detects query complexity → decomposes complex queries →
    plans parallel/sequential execution → routes each sub-query
    to the best LLM category → aggregates into one unified answer.

    Args:
        openai_key:           OpenAI API key (or set OPENAI_API_KEY env var)
        router:               Router approach — transformer | rag | llm | rnn
        detector:             Complexity detector — rule_based | tfidf_svm | minilm_svm
        decomposer:           Decomposer — rule_based | llmcompiler | tor_lite | amr | unsupervised
        aggregation:          Aggregation mode — simple | llm
        category_model_map:   Override category → model mapping

    Example:
        from bar_orchestrator import BAROrchestrator

        bar = BAROrchestrator(openai_key="sk-...", router="transformer")
        result = bar.route("Compare Python and JavaScript for backend ML")
        print(result.answer)
    """

    def __init__(
        self,
        openai_key:          Optional[str]         = None,
        router:              RouterApproach         = "llm",
        detector:            DetectorName           = "rule_based",
        decomposer:          DecomposerName         = "rule_based",
        aggregation:         AggregationMode        = "simple",
        category_model_map:  Optional[dict]         = None,
    ):
        if openai_key:
            os.environ["OPENAI_API_KEY"] = openai_key

        self._router      = router
        self._detector    = detector
        self._decomposer  = decomposer
        self._aggregation = aggregation
        self._cat_map     = category_model_map or DEFAULT_CATEGORY_MODEL_MAP

        # Auto-train detector models if needed
        ensure_models(detector)

        # Lazy-load the pipeline on first use
        self._pipeline = None

    def _get_pipeline(self):
        if self._pipeline is None:
            from query_decomposition_pipeline.pipeline.unified_pipeline import UnifiedPipeline
            self._pipeline = UnifiedPipeline(
                router_approach=self._router,
                decomposer=self._decomposer,
                detector=self._detector,
                aggregation_mode=self._aggregation,
                category_model_map=self._cat_map,
            )
        return self._pipeline

    # ── Public API ────────────────────────────────────────────────────────────

    def route(self, query: str) -> RouteResult:
        """
        Full pipeline: detect → decompose → plan → route → answer.

        Args:
            query: Natural language question or instruction.

        Returns:
            RouteResult with answer, sub_queries, routing, latency, cost.
        """
        pipeline = self._get_pipeline()
        result = pipeline.run(query)

        # sub_responses and execution_plan are dicts inside PipelineResult
        sub_queries = [r["text"] for r in result.sub_responses] if result.sub_responses else [query]

        routing = [
            f"{r['id']} → {r['category']}"
            for r in (result.sub_responses or [])
        ]

        stages = []
        if result.execution_plan and isinstance(result.execution_plan, dict):
            stages = result.execution_plan.get("stages", [])
        elif result.execution_plan and hasattr(result.execution_plan, "stages"):
            stages = [[sq.id for sq in stage] for stage in result.execution_plan.stages]

        return RouteResult(
            query=query,
            is_complex=result.is_complex,
            sub_queries=sub_queries,
            routing=routing,
            answer=result.final_answer,
            latency_ms=result.total_latency_ms,
            cost_usd=result.total_cost_usd,
            stages=stages,
        )

    def detect(self, query: str) -> DetectResult:
        """
        Complexity detection only — is the query simple or complex?

        Returns:
            DetectResult with is_complex bool and confidence score.
        """
        ensure_models(self._detector)
        t0 = time.perf_counter()

        from query_decomposition_pipeline.pipeline.unified_pipeline import _build_detector
        detector = _build_detector(self._detector)
        detection = detector.detect(query)

        return DetectResult(
            query=query,
            is_complex=detection.is_complex,
            confidence=getattr(detection, "confidence", 1.0),
            latency_ms=(time.perf_counter() - t0) * 1000,
        )

    def decompose(self, query: str) -> DecomposeResult:
        """
        Query decomposition only — breaks query into sub-queries.

        Returns:
            DecomposeResult with list of sub-query strings.
        """
        t0 = time.perf_counter()

        from query_decomposition_pipeline.pipeline.unified_pipeline import _build_decomposer
        decomposer = _build_decomposer(self._decomposer)
        result = decomposer.decompose(query)

        return DecomposeResult(
            query=query,
            sub_queries=[sq.text for sq in result.sub_queries],
            method=result.method,
            latency_ms=(time.perf_counter() - t0) * 1000,
        )

    def plan(self, sub_queries: list[dict]) -> PlanResult:
        """
        DAG execution planning — assigns PARALLEL/SEQUENTIAL tags.

        Args:
            sub_queries: list of {"id": "$1", "text": "...", "depends_on": []}

        Returns:
            PlanResult with stages and execution tags.
        """
        from query_decomposition_pipeline.pipeline.dag_planner import DAGPlanner
        from query_decomposition_pipeline.decomposer.base import SubQuery

        sqs = [SubQuery(id=s["id"], text=s["text"], depends_on=s.get("depends_on", [])) for s in sub_queries]
        planner = DAGPlanner()
        plan = planner.plan(sqs)

        stages = [[sq.id for sq in stage] for stage in plan.stages]
        tags = {sq.id: sq.exec_tag for stage in plan.stages for sq in stage}

        return PlanResult(
            sub_queries=[s["text"] for s in sub_queries],
            stages=stages,
            execution_tags=tags,
        )
