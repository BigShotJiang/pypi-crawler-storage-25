"""
CrewAI integration for BAR Orchestrator.

Usage:
    from bar_orchestrator.integrations.crewai import BARCrewTool
    from crewai import Agent, Task, Crew

    tool  = BARCrewTool(openai_key="sk-...", router="transformer")
    agent = Agent(role="Researcher", goal="Answer complex questions",
                  tools=[tool], llm="gpt-4o-mini")
    task  = Task(description="Compare the legal and financial aspects of GDPR compliance",
                 agent=agent)
    Crew(agents=[agent], tasks=[task]).kickoff()
"""

from typing import Optional
from bar_orchestrator import BAROrchestrator


def _check_crewai():
    try:
        from crewai.tools import BaseTool
        from pydantic import BaseModel, Field
        return BaseTool, BaseModel, Field
    except ImportError:
        raise ImportError("crewai is required. Install it with: pip install crewai")


def BARCrewTool(
    openai_key:  Optional[str] = None,
    router:      str = "llm",
    detector:    str = "rule_based",
    decomposer:  str = "rule_based",
    aggregation: str = "simple",
):
    """
    Returns a CrewAI BaseTool wrapping BAROrchestrator.
    """
    BaseTool, BaseModel, Field = _check_crewai()

    orchestrator = BAROrchestrator(
        openai_key=openai_key,
        router=router,
        detector=detector,
        decomposer=decomposer,
        aggregation=aggregation,
    )

    class _BARInput(BaseModel):
        query: str = Field(description="The query to route and answer")

    class _BARCrewAITool(BaseTool):
        name: str = "BAR Multi-Model Orchestrator"
        description: str = (
            "Routes queries to the best LLM based on content type. "
            "Handles complex multi-part questions by decomposing them "
            "and routing each part to the appropriate specialist model "
            "(MEDICAL, LEGAL, CODE, FINANCE, REASONING, etc.)."
        )
        args_schema: type[BaseModel] = _BARInput

        def _run(self, query: str) -> str:
            return orchestrator.route(query).answer

    return _BARCrewAITool()
