"""
Agent framework integrations for BAR Orchestrator.

Available integrations:
    from bar_orchestrator.integrations.langchain  import BARTool
    from bar_orchestrator.integrations.llamaindex import BARQueryTool
    from bar_orchestrator.integrations.autogen    import bar_autogen_tool
    from bar_orchestrator.integrations.crewai     import BARCrewTool
"""
