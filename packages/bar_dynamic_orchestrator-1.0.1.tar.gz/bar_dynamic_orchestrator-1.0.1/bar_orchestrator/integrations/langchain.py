"""
LangChain integration for BAR Orchestrator.

Usage:
    from bar_orchestrator.integrations.langchain import BARTool
    from langchain.agents import initialize_agent, AgentType
    from langchain_openai import ChatOpenAI

    tool = BARTool(openai_key="sk-...", router="transformer")
    llm  = ChatOpenAI(model="gpt-4o-mini")
    agent = initialize_agent([tool], llm, agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION)
    agent.run("What are the symptoms of diabetes and how is it treated?")
"""

from typing import Optional, Type
from bar_orchestrator import BAROrchestrator


def _check_langchain():
    try:
        from langchain.tools import BaseTool
        from pydantic import BaseModel, Field
        return BaseTool, BaseModel, Field
    except ImportError:
        raise ImportError("langchain is required. Install it with: pip install langchain")


class BARTool:
    """
    LangChain-compatible tool that wraps BAROrchestrator.
    Automatically detects complexity, decomposes, routes, and aggregates.
    """

    def __new__(cls, openai_key: Optional[str] = None, router: str = "llm",
                detector: str = "rule_based", decomposer: str = "rule_based",
                aggregation: str = "simple", **kwargs):

        BaseTool, BaseModel, Field = _check_langchain()

        orchestrator = BAROrchestrator(
            openai_key=openai_key,
            router=router,
            detector=detector,
            decomposer=decomposer,
            aggregation=aggregation,
        )

        class _BARInput(BaseModel):
            query: str = Field(description="The user query to route and answer")

        class _BARLangChainTool(BaseTool):
            name: str = "bar_orchestrator"
            description: str = (
                "Business-Aware LLM Router. Routes queries to the best LLM based on content type. "
                "Automatically decomposes complex multi-part questions and aggregates answers. "
                "Use for any question that may involve multiple topics (medical, legal, code, finance, etc.)"
            )
            args_schema: Type[BaseModel] = _BARInput

            def _run(self, query: str) -> str:
                result = orchestrator.route(query)
                return result.answer

            async def _arun(self, query: str) -> str:
                return self._run(query)

        return _BARLangChainTool()
