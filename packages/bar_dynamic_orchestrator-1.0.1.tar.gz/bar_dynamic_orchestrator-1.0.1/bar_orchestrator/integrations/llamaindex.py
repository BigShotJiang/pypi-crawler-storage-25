"""
LlamaIndex integration for BAR Orchestrator.

Usage:
    from bar_orchestrator.integrations.llamaindex import BARQueryTool
    from llama_index.core.agent import ReActAgent

    tool  = BARQueryTool(openai_key="sk-...", router="transformer")
    agent = ReActAgent.from_tools([tool])
    response = agent.chat("Compare the legal and financial risks of a startup acquisition")
"""

from typing import Optional
from bar_orchestrator import BAROrchestrator


def _check_llamaindex():
    try:
        from llama_index.core.tools import FunctionTool
        return FunctionTool
    except ImportError:
        raise ImportError("llama-index is required. Install it with: pip install llama-index")


def BARQueryTool(
    openai_key:  Optional[str] = None,
    router:      str = "llm",
    detector:    str = "rule_based",
    decomposer:  str = "rule_based",
    aggregation: str = "simple",
):
    """
    Returns a LlamaIndex FunctionTool wrapping BAROrchestrator.
    """
    FunctionTool = _check_llamaindex()

    orchestrator = BAROrchestrator(
        openai_key=openai_key,
        router=router,
        detector=detector,
        decomposer=decomposer,
        aggregation=aggregation,
    )

    def bar_route(query: str) -> str:
        """
        Route a query through the BAR multi-model orchestrator.
        Detects complexity, decomposes multi-part questions, routes each
        sub-query to the best LLM (MEDICAL, CODE, LEGAL, FINANCE, etc.),
        and returns a unified answer.

        Args:
            query: The user's natural language question.

        Returns:
            A unified answer string.
        """
        result = orchestrator.route(query)
        return result.answer

    return FunctionTool.from_defaults(fn=bar_route)
