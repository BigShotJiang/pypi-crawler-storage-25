"""
AutoGen integration for BAR Orchestrator.

Usage:
    from bar_orchestrator.integrations.autogen import bar_autogen_tool, register_bar_tool
    import autogen

    llm_config = {"config_list": [{"model": "gpt-4o-mini", "api_key": "sk-..."}]}
    assistant = autogen.AssistantAgent("assistant", llm_config=llm_config)
    user      = autogen.UserProxyAgent("user", human_input_mode="NEVER")

    register_bar_tool(assistant, user, openai_key="sk-...", router="transformer")
    user.initiate_chat(assistant, message="Compare diabetes and hypertension treatments")
"""

from typing import Optional
from bar_orchestrator import BAROrchestrator


def bar_autogen_tool(
    openai_key:  Optional[str] = None,
    router:      str = "llm",
    detector:    str = "rule_based",
    decomposer:  str = "rule_based",
    aggregation: str = "simple",
):
    """
    Returns a callable function compatible with AutoGen's function_map.

    Example:
        tool_fn = bar_autogen_tool(openai_key="sk-...")
        user.register_function(function_map={"bar_route": tool_fn})
    """
    orchestrator = BAROrchestrator(
        openai_key=openai_key,
        router=router,
        detector=detector,
        decomposer=decomposer,
        aggregation=aggregation,
    )

    def bar_route(query: str) -> str:
        """Route a query through the BAR multi-model orchestrator and return the answer."""
        result = orchestrator.route(query)
        return result.answer

    return bar_route


def register_bar_tool(assistant, user_proxy, **kwargs):
    """
    Convenience function — registers BAR as a tool on both AutoGen agents.

    Args:
        assistant:   autogen.AssistantAgent
        user_proxy:  autogen.UserProxyAgent
        **kwargs:    Passed to BAROrchestrator (openai_key, router, etc.)
    """
    try:
        from autogen import register_function
    except ImportError:
        raise ImportError("pyautogen is required. Install it with: pip install pyautogen")

    orchestrator = BAROrchestrator(**kwargs)

    def bar_route(query: str) -> str:
        """Route a query through BAR and return the unified answer."""
        return orchestrator.route(query).answer

    register_function(
        bar_route,
        caller=assistant,
        executor=user_proxy,
        name="bar_route",
        description=(
            "Routes a query through the BAR multi-model orchestrator. "
            "Automatically decomposes complex questions and routes each part "
            "to the best LLM (MEDICAL, CODE, LEGAL, FINANCE, REASONING, etc.)."
        ),
    )
