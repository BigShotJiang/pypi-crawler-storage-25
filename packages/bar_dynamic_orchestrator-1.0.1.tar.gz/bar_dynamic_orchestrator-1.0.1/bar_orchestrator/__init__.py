"""
BAR — Business-Aware LLM Routing
=================================
A plug-and-play Python library for intelligent multi-model LLM orchestration.

Quick start:
    from bar_orchestrator import BAROrchestrator

    bar = BAROrchestrator(openai_key="sk-...")
    result = bar.route("Compare Python and JavaScript for backend development")
    print(result.answer)
"""

from .orchestrator import BAROrchestrator
from .types import RouteResult, DetectResult, DecomposeResult, PlanResult

__version__ = "1.0.1"
__all__ = ["BAROrchestrator", "RouteResult", "DetectResult", "DecomposeResult", "PlanResult"]
