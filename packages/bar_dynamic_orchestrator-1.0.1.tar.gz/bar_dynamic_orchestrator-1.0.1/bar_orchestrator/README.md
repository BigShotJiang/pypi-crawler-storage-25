# BAR — Business-Aware LLM Routing

Plug-and-play Python library for intelligent multi-model LLM orchestration.

![Pipeline](https://imgur.com/mZz5qtt.png)

## Install

```bash
pip install bar-dynamic-orchestrator
```

## Quick Start

```python
from bar_orchestrator import BAROrchestrator

bar = BAROrchestrator(
    openai_key="sk-...",
    router="transformer",     # transformer | rnn | rag | llm
    detector="rule_based",    # rule_based | tfidf_svm | minilm_svm
    decomposer="rule_based",  # rule_based | llmcompiler
    aggregation="llm",        # simple | llm
)

result = bar.route("Compare the symptoms of diabetes and hypertension")
print(result.answer)
print(result.sub_queries)   # decomposed sub-questions
print(result.routing)       # ["$1 → MEDICAL", "$2 → MEDICAL"]
print(result.latency_ms)
print(result.cost_usd)
```

## All Methods

```python
# Full pipeline
result = bar.route("Your query")

# Complexity detection only
detection = bar.detect("Is this query complex?")
print(detection.is_complex, detection.confidence)

# Decomposition only
decomp = bar.decompose("Compare X and Y then summarize")
print(decomp.sub_queries)

# DAG planning only
plan = bar.plan([
    {"id": "$1", "text": "Find X", "depends_on": []},
    {"id": "$2", "text": "Summarize X", "depends_on": ["$1"]},
])
print(plan.stages)           # [["$1"], ["$2"]]
print(plan.execution_tags)   # {"$1": "PARALLEL", "$2": "SEQUENTIAL"}
```

## Agent Framework Integrations

### LangChain
```python
from bar_orchestrator.integrations.langchain import BARTool
from langchain.agents import initialize_agent, AgentType
from langchain_openai import ChatOpenAI

tool  = BARTool(openai_key="sk-...", router="transformer")
llm   = ChatOpenAI(model="gpt-4o-mini")
agent = initialize_agent([tool], llm, agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION)
agent.run("What are the legal and financial risks of a data breach?")
```

### LlamaIndex
```python
from bar_orchestrator.integrations.llamaindex import BARQueryTool
from llama_index.core.agent import ReActAgent

tool  = BARQueryTool(openai_key="sk-...", router="rag")
agent = ReActAgent.from_tools([tool])
agent.chat("Compare Python and JavaScript for ML development")
```

### AutoGen
```python
from bar_orchestrator.integrations.autogen import register_bar_tool
import autogen

llm_config = {"config_list": [{"model": "gpt-4o-mini", "api_key": "sk-..."}]}
assistant  = autogen.AssistantAgent("assistant", llm_config=llm_config)
user       = autogen.UserProxyAgent("user", human_input_mode="NEVER")

register_bar_tool(assistant, user, openai_key="sk-...", router="llm")
user.initiate_chat(assistant, message="Explain GDPR legal and technical implications")
```

### CrewAI
```python
from bar_orchestrator.integrations.crewai import BARCrewTool
from crewai import Agent, Task, Crew

tool  = BARCrewTool(openai_key="sk-...", router="rnn")
agent = Agent(role="Researcher", goal="Answer complex questions",
              tools=[tool], llm="gpt-4o-mini")
task  = Task(description="Compare the legal and financial aspects of GDPR compliance",
             agent=agent)
Crew(agents=[agent], tasks=[task]).kickoff()
```

## Router Approaches

| Router | Model | Accuracy | Latency | Cost |
|---|---|---|---|---|
| `transformer` | DeBERTa-v3 | 92.0% F1 | ~50ms | $0 |
| `rnn` | TextCNN + FastText | 89.9% F1 | 2.5ms | $0 |
| `rag` | ChromaDB hybrid | 86.1% F1 | ~100ms | $0 |
| `llm` | GPT-4o-mini | 86.5% acc | ~1s | ~$0.0003/query |

## Config Presets

| Preset | detector | decomposer | aggregation | router | Best For |
|---|---|---|---|---|---|
| A | rule_based | rule_based | simple | rnn | Lowest latency |
| B | tfidf_svm | rule_based | simple | rag | Minimum cost |
| C | minilm_svm | llmcompiler | simple | llm | Balanced |
| D | tfidf_svm | llmcompiler | llm | transformer | Best accuracy |

## License

MIT
