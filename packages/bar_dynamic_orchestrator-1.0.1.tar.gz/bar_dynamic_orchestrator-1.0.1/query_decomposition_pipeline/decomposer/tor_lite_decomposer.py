"""
ToR-Lite: Lightweight Semantic Query Decomposer (LLM-Free)
===========================================================
Implements the Word-Window Splitting algorithm from ToR-Lite.

Academic basis:
    Yoo, H.-K., Kim, W., & Moon, N. (2026). "ToR-Lite: A Lightweight Semantic
    Query Decomposition for Multi-Hop Retrieval-Augmented Generation in
    Cloud-Based AI Systems." Applied Sciences, 16(8), 3966.
    DOI: 10.3390/app16083966

Core innovation:
    Replaces LLM-based decomposition entirely with embedding-space geometric
    segmentation. Detects semantic breakpoints via sliding window cosine
    similarity using BGE-base-en-v1.5 embeddings. No LLM inference during
    decomposition — single call reserved for final answer generation only.

Algorithm (Word-Window Splitting):
    1. Tokenize query Q into word sequence [w_1, ..., w_L]
    2. Sliding window size W = 7 if L < 40 else 9
    3. For each position t: embed window S_t = [w_{t-W/2}, ..., w_{t+W/2}]
    4. Compute cosine similarity: Sim(S_t, S_{t+1})
    5. Adaptive threshold: τ = μ − s·σ  (s=2 per paper)
    6. Positions where Sim < τ → semantic breakpoints
    7. Split query at breakpoints → sub-queries (max N=3)

Embedding model: BAAI/bge-base-en-v1.5 (768-dim, 109M params)

Used in: Config D (Latency-First) as decomposer — zero LLM cost
Latency: ~5–15ms | Cost: $0 | LLM calls: 0
"""

import time
from .base import BaseDecomposer, DecompositionResult, SubQuery


class ToRLiteDecomposer(BaseDecomposer):
    """
    LLM-free semantic query decomposer using Word-Window Splitting.
    Detects semantic breakpoints via sliding window embedding similarity.
    """

    EMBEDDING_MODEL = "BAAI/bge-base-en-v1.5"
    MAX_SUBQUERIES   = 3
    THRESHOLD_SIGMA  = 1.5          # τ = μ − 1.5σ  (tuned: splits more aggressively)
    SHORT_QUERY_THRESHOLD = 40      # words — determines window size
    WINDOW_SHORT = 7                # W for queries < 40 words
    WINDOW_LONG  = 9                # W for queries ≥ 40 words

    def __init__(self):
        self._encoder = None

    def _get_encoder(self):
        if self._encoder is None:
            from sentence_transformers import SentenceTransformer
            self._encoder = SentenceTransformer(self.EMBEDDING_MODEL)
        return self._encoder

    def _embed(self, texts: list[str]):
        import numpy as np
        encoder = self._get_encoder()
        vecs = encoder.encode(texts, batch_size=64,
                              show_progress_bar=False,
                              normalize_embeddings=True)
        return vecs

    def _cosine_sim(self, a, b) -> float:
        import numpy as np
        # Vectors already L2-normalised by SentenceTransformer
        return float(a @ b)

    def _word_window_split(self, query: str) -> list[str]:
        """
        Core Word-Window Splitting algorithm (Algorithm 1 in paper).
        Returns list of sub-query strings (1 ≤ N ≤ MAX_SUBQUERIES).
        """
        import numpy as np

        words = query.split()
        L = len(words)

        if L <= 3:
            # Too short to decompose
            return [query]

        W = self.WINDOW_SHORT if L < self.SHORT_QUERY_THRESHOLD else self.WINDOW_LONG
        half = W // 2

        # Step 2-3: Build window text for each position t
        window_texts = []
        for t in range(L):
            start = max(0, t - half)
            end   = min(L, t + half + 1)
            window_texts.append(" ".join(words[start:end]))

        # Step 3: Embed all windows in one batch
        embeddings = self._embed(window_texts)   # shape (L, 768)

        # Step 4: Cosine similarity between adjacent windows
        sims = []
        for t in range(L - 1):
            sims.append(self._cosine_sim(embeddings[t], embeddings[t + 1]))

        if not sims:
            return [query]

        # Step 5: Adaptive threshold τ = μ − s·σ
        mu    = float(np.mean(sims))
        sigma = float(np.std(sims))
        tau   = mu - self.THRESHOLD_SIGMA * sigma

        # Step 6: Find breakpoints — positions where sim drops below τ
        breakpoints = [t + 1 for t, s in enumerate(sims) if s < tau]

        if not breakpoints:
            return [query]

        # Step 7: Split at breakpoints, limit to MAX_SUBQUERIES segments
        # If too many breakpoints, keep only the (MAX_SUBQUERIES-1) strongest
        # valleys (lowest similarity = strongest semantic boundary)
        if len(breakpoints) > self.MAX_SUBQUERIES - 1:
            breakpoints = sorted(
                breakpoints,
                key=lambda bp: sims[bp - 1]          # lowest sim = deepest valley
            )[:self.MAX_SUBQUERIES - 1]
            breakpoints = sorted(breakpoints)

        # Build sub-query strings from word slices
        boundaries = [0] + breakpoints + [L]
        sub_queries = []
        for i in range(len(boundaries) - 1):
            chunk = " ".join(words[boundaries[i]:boundaries[i + 1]]).strip()
            if chunk:
                sub_queries.append(chunk)

        return sub_queries if sub_queries else [query]

    def decompose(self, query: str) -> DecompositionResult:
        t0 = time.perf_counter()

        sub_texts = self._word_window_split(query)
        elapsed = (time.perf_counter() - t0) * 1000

        if len(sub_texts) == 1:
            # No breakpoint found — query is atomic
            return DecompositionResult(
                original_query=query,
                sub_queries=[SubQuery(id="$1", text=query, depends_on=[])],
                method="tor_lite",
                latency_ms=elapsed,
                llm_cost_usd=0.0,
                raw_plan="no_breakpoint",
            )

        sub_queries = [
            SubQuery(id=f"${i+1}", text=text, depends_on=[])
            for i, text in enumerate(sub_texts)
        ]

        # Post-process: infer sequential dependencies from anaphoric signals
        from .dependency_inferrer import infer_dependencies
        sub_queries = infer_dependencies(sub_queries, query)

        return DecompositionResult(
            original_query=query,
            sub_queries=sub_queries,
            method="tor_lite",
            latency_ms=elapsed,
            llm_cost_usd=0.0,
            raw_plan=" | ".join(sub_texts),
        )

    def name(self) -> str:
        return "tor_lite"
