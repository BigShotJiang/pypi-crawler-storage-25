"""
LLMCompiler-Style DAG Decomposer
===================================
Decomposes complex queries into a DAG of sub-queries using GPT-4o-mini.
Each sub-query carries explicit dependency variables ($1, $2 ...) so the
execution planner can determine true parallel vs sequential structure.

Academic basis:
    Kim et al. (2024). "An LLM Compiler for Parallel Function Calling."
    ICML 2024. arXiv:2312.04511.

    Results vs ReAct baseline:
      - Accuracy  : +8.53 pp on Movie Recommendation benchmark
      - Latency   : 3.7× speedup
      - Cost      : 6.73× reduction
      GitHub: github.com/SqueezeAILab/LLMCompiler

    Orion (2025): Dependency-aware decomposition achieves 4.25× speedup
    vs 2.69× for blind parallelism (Skeleton-of-Thought).
    arXiv:2510.24390

Model: GPT-4o-mini
    Pricing: $0.15/1M input, $0.60/1M output
    Estimated cost per decomposition: ~$0.00012/query (200in + 150out tokens)
    Source: OpenAI pricing, verified May 2026

Used in: Config A (Accuracy-First), Config B (Balanced)
"""

import json
import re
import time
from openai import OpenAI

from .base import BaseDecomposer, SubQuery, DecompositionResult

# Pricing constants — GPT-4o-mini (OpenAI, May 2026)
_COST_PER_INPUT_TOKEN = 0.15 / 1_000_000
_COST_PER_OUTPUT_TOKEN = 0.60 / 1_000_000

_SYSTEM_PROMPT = """You are a query decomposition planner. Your job is to split a complex user query into atomic sub-queries with explicit execution dependencies.

RULES:
1. Each sub-query gets an ID: $1, $2, $3, ...
2. If a sub-query NEEDS the output of a previous one, set depends_on to that ID.
3. Sub-queries with NO depends_on run in PARALLEL.
4. Keep sub-queries atomic — one clear question or action each.
5. Maximum 5 sub-queries. If the query is already simple, return just $1.

CRITICAL DEPENDENCY RULE:
- Comma-separated action sequences ("do X, then Y, then Z") are SEQUENTIAL by default.
  Each step produces output that the next step consumes. Always chain their depends_on.
  Example: "Parse, clean, and save" → $2 depends on $1, $3 depends on $2.
- Comparison queries ("compare X and Y") have PARALLEL sub-queries because X and Y
  are independent — they do not need each other's output.
- Cross-domain queries ("how should it do A and B") have PARALLEL sub-queries
  when A and B are independent aspects of the same problem.

OUTPUT FORMAT (strict JSON):
{
  "sub_queries": [
    {"id": "$1", "text": "...", "depends_on": []},
    {"id": "$2", "text": "...", "depends_on": ["$1"]},
    {"id": "$3", "text": "...", "depends_on": []}
  ]
}

EXAMPLE 1 — Sequential action list:
Query: "Parse the CSV file, clean the missing values, and save the result to a database."
{
  "sub_queries": [
    {"id": "$1", "text": "Parse the CSV file.", "depends_on": []},
    {"id": "$2", "text": "Clean the missing values.", "depends_on": ["$1"]},
    {"id": "$3", "text": "Save the result to a database.", "depends_on": ["$2"]}
  ]
}

EXAMPLE 2 — Parallel comparison:
Query: "Compare the symptoms of diabetes and hypertension, then suggest a diet plan for both."
{
  "sub_queries": [
    {"id": "$1", "text": "What are the main symptoms of diabetes?", "depends_on": []},
    {"id": "$2", "text": "What are the main symptoms of hypertension?", "depends_on": []},
    {"id": "$3", "text": "What diet plan suits a patient with both conditions?", "depends_on": ["$1", "$2"]}
  ]
}
"""


class LLMCompilerDecomposer(BaseDecomposer):
    """
    Sends the query to GPT-4o-mini with LLMCompiler-style prompting.
    Returns a DecompositionResult with SubQuery objects carrying
    dependency information for the DAG execution planner.
    """

    def __init__(self, model: str = "gpt-4o-mini", max_subqueries: int = 5):
        self.model = model
        self.max_subqueries = max_subqueries
        import os
        self._has_key = bool(os.environ.get("OPENAI_API_KEY"))
        self._client = OpenAI() if self._has_key else None

    def name(self) -> str:
        return f"llmcompiler_{self.model}"

    def decompose(self, query: str) -> DecompositionResult:
        t0 = time.perf_counter()

        if not self._has_key:
            raise RuntimeError(
                "LLMCompiler requires OPENAI_API_KEY. "
                "Set it with: export OPENAI_API_KEY='sk-...'"
            )

        user_prompt = f'Decompose this query:\n"{query}"'

        try:
            response = self._client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": _SYSTEM_PROMPT},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=0.0,
                response_format={"type": "json_object"},
                max_tokens=600,
                timeout=30,
            )

            raw = response.choices[0].message.content
            cost = self._compute_cost(response.usage)
            sub_queries = self._parse_response(raw, query)

        except Exception as e:
            # Graceful fallback — return original query as single sub-query
            print(f"[LLMCompilerDecomposer] Error: {e}. Returning original query.")
            raw = ""
            cost = 0.0
            sub_queries = [SubQuery(id="$1", text=query, depends_on=[])]

        latency_ms = (time.perf_counter() - t0) * 1000

        return DecompositionResult(
            original_query=query,
            sub_queries=sub_queries[: self.max_subqueries],
            method=self.name(),
            latency_ms=latency_ms,
            llm_cost_usd=cost,
            raw_plan=raw,
        )

    # ── Internal ──────────────────────────────────────────────────────────

    def _parse_response(self, raw: str, original_query: str) -> list[SubQuery]:
        try:
            data = json.loads(raw)
            items = data.get("sub_queries", [])
            if not items:
                raise ValueError("Empty sub_queries list")

            result = []
            for item in items:
                result.append(SubQuery(
                    id=item.get("id", f"${len(result)+1}"),
                    text=item.get("text", "").strip(),
                    depends_on=item.get("depends_on", []),
                ))
            return result

        except (json.JSONDecodeError, ValueError, KeyError):
            # Fallback: return original as single sub-query
            return [SubQuery(id="$1", text=original_query, depends_on=[])]

    def _compute_cost(self, usage) -> float:
        if usage is None:
            return 0.0
        return (usage.prompt_tokens * _COST_PER_INPUT_TOKEN +
                usage.completion_tokens * _COST_PER_OUTPUT_TOKEN)
