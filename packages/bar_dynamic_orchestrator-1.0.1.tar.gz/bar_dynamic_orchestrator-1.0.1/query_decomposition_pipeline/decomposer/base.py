"""Base types for decomposition results."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field


@dataclass
class SubQuery:
    id: str                          # e.g. "$1", "$2"
    text: str                        # the sub-question text
    depends_on: list[str] = field(default_factory=list)   # ids this depends on
    estimated_category: str = ""     # optional pre-hint for router

    def __repr__(self):
        deps = f" depends_on={self.depends_on}" if self.depends_on else ""
        return f"SubQuery({self.id}: '{self.text[:60]}'{deps})"


@dataclass
class DecompositionResult:
    original_query: str
    sub_queries: list[SubQuery]
    method: str                      # "llmcompiler" | "rule_based"
    latency_ms: float = 0.0
    llm_cost_usd: float = 0.0
    raw_plan: str = ""               # raw LLM output for debugging

    @property
    def is_atomic(self) -> bool:
        """True if decomposition returned only one sub-query (query was simple)."""
        return len(self.sub_queries) <= 1

    def __repr__(self):
        return (f"DecompositionResult({len(self.sub_queries)} sub-queries, "
                f"method={self.method}, latency={self.latency_ms:.1f}ms, "
                f"cost=${self.llm_cost_usd:.6f})")


class BaseDecomposer(ABC):
    @abstractmethod
    def decompose(self, query: str) -> DecompositionResult:
        """Split query into sub-queries with dependency metadata."""

    @abstractmethod
    def name(self) -> str:
        """Return decomposer name."""
