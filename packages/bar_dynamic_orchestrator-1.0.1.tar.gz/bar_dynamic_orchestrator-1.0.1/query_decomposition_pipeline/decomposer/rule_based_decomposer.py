"""
Rule-Based Decomposer
=======================
Splits compound queries using linguistic connectives and syntactic patterns.
Zero LLM calls, sub-millisecond latency, zero cost.

Academic basis:
    Carmona et al. (2020). "Intent Segmentation of User Queries Via
    Discourse Parsing." IWDP @ ACL 2020. ACL Anthology: 2020.iwdp-1.7.
    [RST discourse parsing for multi-intent query segmentation, >80% F1.]

    RAGRouter-Bench structural features (Bansal & Agarwal, 2026,
    arXiv:2604.03455): structural/rule-based features achieve 77.8–80.3%
    F1 — lower bound for this decomposer.

Approach:
    1. Split on coordinating conjunctions + punctuation (AND, THEN, ALSO…)
    2. Split on sentence boundaries (period, semicolon, question mark)
    3. Detect dependency using discourse markers (THEN, AFTER, BASED ON…)
    4. Assign $1, $2, $3 IDs with explicit depends_on for dependent splits

Used in: Config C (Latency-First) — <1ms, $0/query
"""

import re
import time
from .base import BaseDecomposer, SubQuery, DecompositionResult

# Connectives that signal parallel independent sub-queries
_PARALLEL_CONNECTIVES = re.compile(
    r'\b(and also|also|additionally|furthermore|as well as|plus|moreover|'
    r'in addition|on the other hand|meanwhile|at the same time)\b',
    re.IGNORECASE
)

# Connectives that signal sequential dependent sub-queries
_SEQUENTIAL_CONNECTIVES = re.compile(
    r'\b(then|after that|after which|based on (that|this|the above)|'
    r'using (that|this|the result)|given (that|this)|subsequently|therefore|'
    r'as a result|once you have|next|following that|having done that|'
    r'once identified|once found|once determined)\b',
    re.IGNORECASE
)

# Comparison signals — two parallel sub-queries
_COMPARISON_PATTERN = re.compile(
    r'\bcompare\b|\bdifference between\b|\bversus\b|\bvs\.?\b|\bcontrast\b|'
    r'\bbetter than\b|\bmore .{1,20} than\b|\bwhich (?:is|has|provides|gives|offers) '
    r'(?:more|better|higher|lower|fewer|greater|less)\b',
    re.IGNORECASE
)

# Action verbs that indicate an imperative sub-task
_ACTION_VERB = (
    r'(?:list|find|get|fetch|retrieve|calculate|compute|determine|identify|'
    r'analyze|analyse|evaluate|examine|compare|create|generate|extract|collect|'
    r'gather|aggregate|classify|sort|rank|summarize|summarise|count|measure|'
    r'check|verify|locate|detect|describe|explain|show|display|return|produce|'
    r'build|construct|estimate|assess|review|translate|convert|transform|apply|'
    r'use|combine|merge|filter|select|search|process|parse|clean|save|load|'
    r'read|write|update|delete|add|include|map|group|segment|explore|investigate|'
    r'acquire|obtain|derive|inspect|monitor|track|record|report|'
    r'interpret|define|establish|validate|test|run|execute|perform|conduct|'
    r'solve|answer|address|handle|manage|organize|categorize|label|annotate|'
    r'evaluate|format|install|start|alert|publish|deploy|send|notify|merge|'
    r'clone|connect|train|export|import|prepare|review|approve|gather|generate|'
    r'visualize|visualise|plot|render|display|print|log|store|upload|download|'
    r'schedule|trigger|configure|setup|initialize|initialise|launch|stop|restart|'
    r'backup|restore|migrate|replicate|sync|synchronize|encrypt|decrypt|sign|'
    r'authenticate|authorize|register|unregister|enable|disable|activate|deactivate)'
)

# Verb + AND + Verb: "Aggregate X and classify Y", "List routes and calculate average"
_VERB_AND_VERB = re.compile(
    rf'\b({_ACTION_VERB})\b(.{{3,100}}?)\s+and\s+({_ACTION_VERB})\b(.{{3,200}}?)(?:\?|$)',
    re.IGNORECASE
)

# Multi-hop WHERE: "What is X in/of [entity] where/who/which Y?"
_MULTIHOP_WHERE = re.compile(
    r'^(?:what|which|who|where|when)\s+(?:is|are|was|were|does|do|did|has|have|had|'
    r'(?:is|are)\s+the\s+\w+\s+of)\s+(.+?)\s+(?:in|of|for|at|from|belonging\s+to)\s+'
    r'(?:the\s+)?(\w+(?:\s+\w+){0,4})\s+(?:where|who|which|that)\s+(.+)',
    re.IGNORECASE
)

# Comma-separated verb list: "Parse X, clean Y, and save Z"
_COMMA_VERB_SPLIT = re.compile(
    rf',\s+(?:and\s+)?(?={_ACTION_VERB}\b)',
    re.IGNORECASE
)

# Conditional multi-aspect: "If X, how should Y do [A] and [B]?"
_CONDITIONAL_AND = re.compile(
    r'(?:if [^,]+,\s*)?how (?:should|can|could|would|might) \S+(?: \S+){0,5} '
    r'(.+?)\s+and\s+(.+?)(?:\?|$)',
    re.IGNORECASE
)

# Sentence splitter
_SENTENCE_SPLIT = re.compile(r'(?<=[.?!;])\s+(?=[A-Z])')

# Bare "and" between two noun phrases / clauses (last resort)
_BARE_AND = re.compile(r'\s+and\s+', re.IGNORECASE)


class RuleBasedDecomposer(BaseDecomposer):
    """
    Zero-cost, <1ms decomposer using linguistic pattern matching.
    Returns dependency-annotated SubQuery objects compatible with
    the DAG execution planner.
    """

    def name(self) -> str:
        return "rule_based"

    def decompose(self, query: str) -> DecompositionResult:
        t0 = time.perf_counter()
        sub_queries = self._split(query)
        latency_ms = (time.perf_counter() - t0) * 1000

        return DecompositionResult(
            original_query=query,
            sub_queries=sub_queries,
            method=self.name(),
            latency_ms=latency_ms,
            llm_cost_usd=0.0,
            raw_plan="rule_based_split",
        )

    # ── Internal ──────────────────────────────────────────────────────────

    def _split(self, query: str) -> list[SubQuery]:
        q = query.strip()

        # Step 1: Sentence boundary split (highest confidence — explicit sentences)
        sent_parts = _SENTENCE_SPLIT.split(q)
        sent_parts = [p.strip() for p in sent_parts if p.strip() and len(p.strip()) > 10]
        if len(sent_parts) >= 2:
            mode = self._infer_mode(sent_parts)
            return self._assign_ids(sent_parts, mode=mode)

        # Step 2: Sequential connective split ("then", "after that", "once identified")
        seq_parts = _SEQUENTIAL_CONNECTIVES.split(q)
        seq_parts = [p.strip() for p in seq_parts if p.strip() and len(p.strip()) > 10]
        if len(seq_parts) >= 2:
            return self._assign_ids(seq_parts, mode="sequential")

        # Step 3: Comparison pattern — two parallel sub-queries
        if _COMPARISON_PATTERN.search(q):
            parts = self._split_comparison(q)
            if len(parts) >= 2:
                return self._assign_ids(parts, mode="parallel")

        # Step 4: Multi-hop WHERE pattern
        # "What is X in [entity] where Y?" → ["Find entity where Y", "Find X in that entity"]
        mh = _MULTIHOP_WHERE.match(q)
        if mh:
            target   = mh.group(1).strip().rstrip('?,.')
            entity   = mh.group(2).strip()
            cond     = mh.group(3).strip().rstrip('?,.')
            parts = [
                f"Find the {entity} where {cond}.",
                f"Find the {target} in that {entity}.",
            ]
            return self._assign_ids(parts, mode="sequential")

        # Step 5: Comma-separated verb list ("Parse X, clean Y, and save Z")
        # Must run BEFORE verb+and+verb to correctly count 3+ actions
        comma_parts = _COMMA_VERB_SPLIT.split(q)
        comma_parts = [p.strip() for p in comma_parts if p.strip() and len(p.strip()) > 5]
        if len(comma_parts) >= 2:
            return self._assign_ids(comma_parts, mode="sequential")

        # Step 6: Verb + AND + Verb ("Aggregate X and classify Y", "List X and calculate Y")
        vm = _VERB_AND_VERB.search(q)
        if vm:
            part_a = (vm.group(1) + vm.group(2)).strip().rstrip(',')
            part_b = (vm.group(3) + vm.group(4)).strip().rstrip('?.')
            if len(part_a) >= 5 and len(part_b) >= 5:
                return self._assign_ids([part_a, part_b], mode="sequential")

        # Step 7: Parallel connective ("and also", "additionally", "as well as")
        par_parts = _PARALLEL_CONNECTIVES.split(q)
        par_parts = [p.strip() for p in par_parts if p.strip() and len(p.strip()) > 10]
        if len(par_parts) >= 2:
            return self._assign_ids(par_parts, mode="parallel")

        # Step 8: Conditional multi-aspect ("If X, how should Y do [A] and [B]?")
        cond_match = _CONDITIONAL_AND.search(q)
        if cond_match:
            aspect_a = cond_match.group(1).strip()
            aspect_b = cond_match.group(2).strip()
            if len(aspect_a) > 5 and len(aspect_b) > 5:
                subject = re.search(r'how (?:should|can|could|would|might) (\S+(?: \S+){0,3})', q, re.I)
                subj = subject.group(1) if subject else "it"
                parts = [f"How should {subj} {aspect_a}?", f"How should {subj} {aspect_b}?"]
                return self._assign_ids(parts, mode="parallel")

        # Step 9: Bare "and" split — only when query is short enough and both halves are meaningful
        bare_parts = _BARE_AND.split(q, maxsplit=1)
        bare_parts = [p.strip() for p in bare_parts if p.strip() and len(p.strip()) > 8]
        if len(bare_parts) == 2 and len(q.split()) <= 25:
            return self._assign_ids(bare_parts, mode="sequential")

        # Step 10: Cannot split — return as single sub-query
        return [SubQuery(id="$1", text=q, depends_on=[])]

    def _split_comparison(self, query: str) -> list[str]:
        """Extract two entities being compared."""
        # "Compare X and Y" / "difference between X and Y"
        between_match = re.search(
            r'(?:difference between|compare)\s+(.+?)\s+(?:and|vs\.?|versus)\s+(.+)',
            query, re.IGNORECASE
        )
        if between_match:
            entity_a = between_match.group(1).strip()
            entity_b = between_match.group(2).strip()
            return [
                f"What are the characteristics of {entity_a}?",
                f"What are the characteristics of {entity_b}?",
            ]
        return []

    def _infer_mode(self, parts: list[str]) -> str:
        """Check if any part starts with a sequential marker."""
        for part in parts[1:]:
            if _SEQUENTIAL_CONNECTIVES.match(part.strip()):
                return "sequential"
        return "parallel"

    def _assign_ids(self, parts: list[str], mode: str) -> list[SubQuery]:
        """
        Assign $1, $2, ... IDs.
        - parallel  : all depends_on = []
        - sequential: $2 depends on $1, $3 depends on $2, etc.
        """
        result = []
        for i, text in enumerate(parts[:5]):   # max 5 sub-queries
            sid = f"${i + 1}"
            if mode == "sequential" and i > 0:
                depends_on = [f"${i}"]
            else:
                depends_on = []
            result.append(SubQuery(id=sid, text=text, depends_on=depends_on))
        return result
