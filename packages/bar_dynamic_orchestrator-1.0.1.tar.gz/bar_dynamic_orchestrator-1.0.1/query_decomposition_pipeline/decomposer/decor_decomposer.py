"""
DeCoR: Decompose and Compress for Retrieval — Query Decomposer
==============================================================
Implements the query decomposition stage of the DeCoR framework.

Academic basis:
    Yun, J. & Kim, Y. (2025). "Query, Decompose, Compress: Structured Query
    Expansion for Efficient Multi-Hop Retrieval." arXiv:2603.21024.

DeCoR pipeline (4 stages):
    1. Query Decomposition  — LLM breaks complex query into m independent sub-queries
    2. Candidate Retrieval  — BM25 retrieval per sub-query  (RAG layer, not here)
    3. Document Compression — query-focused summarisation    (RAG layer, not here)
    4. Query Expansion      — expanded embedding for retrieval (RAG layer, not here)

This module implements Stage 1 only — decomposition into independent sub-queries.
Stages 2-4 belong to the retrieval/RAG layer, not the decomposition component.

Key design principle (from paper):
    Each sub-query "should reflect a single reasoning step and be answerable
    on its own." Sub-queries are INDEPENDENT (no cross-dependencies) — suited
    for parallel execution.

Decomposition prompt follows the paper's instruction-tuned prompting approach
using a lightweight model (default: gpt-4o-mini, matching paper's Qwen2.5-7B
intent — small instruction-tuned LLM, not a frontier model).

Used in: Config C (Cost-First) as structured decomposer
Latency: ~1–2s | Cost: ~$0.000015/query | LLM calls: 1
"""

import os
import re
import time
from .base import BaseDecomposer, DecompositionResult, SubQuery
from .rule_based_decomposer import RuleBasedDecomposer

_SYSTEM_PROMPT = """You are a query decomposition engine. Your task is to break a complex multi-hop query into independent sub-queries.

Rules:
1. Each sub-query must address ONE reasoning step and be answerable on its own.
2. Sub-queries must be INDEPENDENT — no sub-query should depend on the answer of another.
3. Generate between 2 and 4 sub-queries. Never return just 1.
4. Output ONLY a numbered list. No explanation. No extra text.

Example:
Query: "Analyze the impact of 2023 tech layoffs on the AI industry and examine the ethical concerns surrounding AI development."
Output:
1. What was the impact of the 2023 tech layoffs on the AI industry?
2. What are the main ethical concerns surrounding AI development?"""


class DeCoRDecomposer(BaseDecomposer):
    """
    DeCoR Stage 1: LLM-based decomposition into independent sub-queries.
    Yun & Kim (2025). arXiv:2603.21024.
    Falls back to rule-based decomposer if no API key is available.
    """

    def __init__(self, model: str = "gpt-4o-mini", max_subqueries: int = 4):
        self._model = model
        self._max_subqueries = max_subqueries
        self._client = None
        self._fallback = None

        api_key = os.environ.get("OPENAI_API_KEY")
        if api_key:
            from openai import OpenAI
            self._client = OpenAI(api_key=api_key)
        else:
            self._fallback = RuleBasedDecomposer()

    def _parse_numbered_list(self, text: str) -> list[str]:
        lines = text.strip().split("\n")
        sub_queries = []
        for line in lines:
            line = line.strip()
            # Match "1. text", "1) text", "- text"
            match = re.match(r'^(?:\d+[\.\)]\s*|[-•]\s*)(.+)', line)
            if match:
                sq = match.group(1).strip()
                if len(sq) > 5:
                    sub_queries.append(sq)
        return sub_queries[:self._max_subqueries]

    def decompose(self, query: str) -> DecompositionResult:
        if self._client is None:
            raise RuntimeError(
                "DeCoR requires OPENAI_API_KEY. "
                "Set it with: export OPENAI_API_KEY='sk-...'"
            )

        t0 = time.perf_counter()
        cost = 0.0
        raw = ""

        try:
            response = self._client.chat.completions.create(
                model=self._model,
                messages=[
                    {"role": "system", "content": _SYSTEM_PROMPT},
                    {"role": "user", "content": f'Query: "{query}"'},
                ],
                temperature=0.0,
                max_tokens=300,
                timeout=30,
            )
            raw = response.choices[0].message.content.strip()
            usage = response.usage
            cost = (usage.prompt_tokens * 0.15 + usage.completion_tokens * 0.60) / 1_000_000

            sub_texts = self._parse_numbered_list(raw)

        except Exception as e:
            sub_texts = []
            raw = f"ERROR: {e}"

        elapsed = (time.perf_counter() - t0) * 1000

        # Fallback to rule-based if LLM returned unusable output
        if len(sub_texts) < 2:
            fallback_result = RuleBasedDecomposer().decompose(query)
            return DecompositionResult(
                original_query=query,
                sub_queries=fallback_result.sub_queries,
                method="decor_fallback",
                latency_ms=elapsed,
                llm_cost_usd=cost,
                raw_plan=raw,
            )

        sub_queries = [
            SubQuery(id=f"${i+1}", text=text, depends_on=[])
            for i, text in enumerate(sub_texts)
        ]

        # Post-process: infer sequential dependencies from anaphoric signals
        from .dependency_inferrer import infer_dependencies
        sub_queries = infer_dependencies(sub_queries, query)

        return DecompositionResult(
            original_query=query,
            sub_queries=sub_queries,
            method="decor",
            latency_ms=elapsed,
            llm_cost_usd=cost,
            raw_plan=raw,
        )

    def name(self) -> str:
        return "decor"
