"""
Unsupervised Question Decomposer
=================================
Implements the unsupervised decomposition paradigm from Perez et al. (2020).

Academic basis:
    Perez et al. (2020). "Unsupervised Question Decomposition for Question
    Answering." EMNLP 2020. arXiv:2002.09758.
    → Decomposes complex questions without labeled decomposition pairs.
      Uses a noisy channel model: P(sub-questions | complex question) via
      span extraction + gap-filling with a pre-trained seq2seq model.

    Wolfson et al. (2020). "Break It Down: A Question Understanding Benchmark."
    TACL 2020. → BREAK dataset used for self-supervised training signal.

Implementation:
    Stage 1 — Span Extraction (unsupervised):
        Use sentence embedding similarity to identify semantically distinct
        spans within the query (similar spirit to Perez et al. span model).
        Segments are found where embedding similarity drops — no labels needed.

    Stage 2 — Gap Filling (pre-trained seq2seq):
        Convert each span into a well-formed sub-question using
        google/flan-t5-small (instruction-tuned, zero-shot capable).
        Prompt: "Convert this query fragment into a complete question: {span}"

    Why unsupervised:
        Stage 1 uses NO labeled decomposition pairs — only pre-trained
        embeddings (self-supervised). Stage 2 uses a pre-trained instruction-
        tuned model with no task-specific fine-tuning on decomposition data.

Used in: Component 2 evaluation (self-supervised paradigm)
Latency: ~100–500ms | Cost: $0 | LLM calls: 0 (local model only)
"""

import re
import time
from .base import BaseDecomposer, DecompositionResult, SubQuery


_GAP_FILL_PROMPT = "Convert this query fragment into a complete standalone question: {span}"


class UnsupervisedDecomposer(BaseDecomposer):
    """
    Unsupervised query decomposer.
    Span extraction via embedding similarity + gap-filling via flan-t5-small.
    Perez et al. (2020). EMNLP 2020. arXiv:2002.09758.
    """

    EMBEDDING_MODEL = "all-MiniLM-L6-v2"
    SEQ2SEQ_MODEL   = "google/flan-t5-small"
    MAX_SUBQUERIES  = 3
    MIN_SPAN_WORDS  = 4          # minimum words per span to be a valid sub-query
    SIM_THRESHOLD   = 0.65       # cosine sim below this → segment boundary (tuned: splits more aggressively)

    def __init__(self):
        self._encoder   = None
        self._generator = None
        self._tokenizer = None

    def _get_encoder(self):
        if self._encoder is None:
            from sentence_transformers import SentenceTransformer
            self._encoder = SentenceTransformer(self.EMBEDDING_MODEL)
        return self._encoder

    def _get_generator(self):
        if self._generator is None:
            from transformers import T5ForConditionalGeneration, T5Tokenizer
            self._tokenizer  = T5Tokenizer.from_pretrained(
                self.SEQ2SEQ_MODEL, legacy=False)
            self._generator  = T5ForConditionalGeneration.from_pretrained(
                self.SEQ2SEQ_MODEL)
            self._generator.eval()
        return self._generator, self._tokenizer

    # ── Stage 1: Span extraction via embedding similarity ─────────────────

    def _extract_spans(self, query: str) -> list[str]:
        """
        Segment query into semantically distinct spans.
        Uses sliding word-pair embeddings — no labels needed.
        Boundary = cosine sim drops below SIM_THRESHOLD between
        consecutive clause-level chunks (split at conjunctions first).
        """
        import numpy as np

        # Primary split: clause-level chunks at logical connectives
        clause_pattern = re.compile(
            r'(?<=[,;])\s+(?:and|but|while|whereas|however)\s+|'
            r'\s+(?:and\s+(?:also|further|additionally)|as\s+well\s+as|'
            r'while\s+also|in\s+addition\s+to)\s+',
            re.IGNORECASE
        )
        chunks = [c.strip() for c in clause_pattern.split(query) if c.strip()]

        if len(chunks) >= 2:
            # Filter out too-short chunks
            valid = [c for c in chunks if len(c.split()) >= self.MIN_SPAN_WORDS]
            if len(valid) >= 2:
                return valid[:self.MAX_SUBQUERIES]

        # Secondary split: embedding-based segmentation on words
        words = query.split()
        if len(words) < 6:
            return [query]

        encoder = self._get_encoder()
        # Embed overlapping bigram windows
        window_texts = [" ".join(words[max(0,i-2):i+3]) for i in range(len(words))]
        embeddings = encoder.encode(window_texts, show_progress_bar=False,
                                    normalize_embeddings=True)

        # Find positions where similarity drops below threshold
        sims = [float(embeddings[i] @ embeddings[i+1])
                for i in range(len(embeddings)-1)]

        mu    = float(np.mean(sims))
        sigma = float(np.std(sims))
        tau   = mu - 1.5 * sigma   # softer than ToR-Lite (1.5σ vs 2σ)

        breakpoints = [i+1 for i, s in enumerate(sims) if s < tau]

        if not breakpoints:
            return [query]

        # Keep strongest breakpoints only
        if len(breakpoints) > self.MAX_SUBQUERIES - 1:
            breakpoints = sorted(
                breakpoints, key=lambda bp: sims[bp-1]
            )[:self.MAX_SUBQUERIES - 1]
            breakpoints = sorted(breakpoints)

        boundaries = [0] + breakpoints + [len(words)]
        spans = []
        for i in range(len(boundaries)-1):
            span = " ".join(words[boundaries[i]:boundaries[i+1]]).strip()
            if len(span.split()) >= self.MIN_SPAN_WORDS:
                spans.append(span)

        return spans if len(spans) >= 2 else [query]

    # ── Stage 2: Gap filling → well-formed sub-questions ──────────────────

    def _gap_fill(self, span: str, original_query: str) -> str:
        """
        Convert a span into a complete standalone question.
        Uses flan-t5-small in zero-shot mode — no task-specific fine-tuning.
        """
        try:
            import torch
            generator, tokenizer = self._get_generator()
            prompt = _GAP_FILL_PROMPT.format(span=span)
            inputs = tokenizer(
                prompt, return_tensors="pt",
                max_length=128, truncation=True
            )
            with torch.no_grad():
                outputs = generator.generate(
                    **inputs,
                    max_new_tokens=64,
                    num_beams=4,
                    early_stopping=True,
                )
            result = tokenizer.decode(outputs[0], skip_special_tokens=True).strip()
            # Ensure it ends with a question mark
            if result and not result.endswith("?"):
                result += "?"
            return result if len(result.split()) >= 4 else span
        except Exception:
            return span

    # ── Main interface ────────────────────────────────────────────────────

    def decompose(self, query: str) -> DecompositionResult:
        t0 = time.perf_counter()

        # Stage 1: extract spans (unsupervised)
        spans = self._extract_spans(query)

        # Stage 2: gap-fill each span into a complete question
        sub_texts = []
        for span in spans:
            filled = self._gap_fill(span, query)
            sub_texts.append(filled)

        elapsed = (time.perf_counter() - t0) * 1000

        if len(sub_texts) <= 1:
            sub_texts = [query]

        sub_queries = [
            SubQuery(id=f"${i+1}", text=t, depends_on=[])
            for i, t in enumerate(sub_texts)
            if t.strip()
        ]

        # Post-process: infer sequential dependencies from anaphoric signals
        from .dependency_inferrer import infer_dependencies
        sub_queries = infer_dependencies(sub_queries, query)

        return DecompositionResult(
            original_query=query,
            sub_queries=sub_queries,
            method="unsupervised",
            latency_ms=elapsed,
            llm_cost_usd=0.0,
            raw_plan=" | ".join(sub_texts),
        )

    def name(self) -> str:
        return "unsupervised"
