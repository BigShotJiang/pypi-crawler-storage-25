"""
FrugalGPT Cascade Decomposer (Cost-First Config C)
====================================================
Implements the FrugalGPT cascade principle: try the cheapest method first
(rule-based decomposer), and only escalate to LLM when the cheaper method
fails to produce a meaningful decomposition.

Academic basis:
    Chen et al. (2023). "FrugalGPT: How to Use Large Language Models While
    Reducing Cost and Improving Performance." arXiv:2305.05176.
    → Cascade principle: try weaker/cheaper models first, escalate only on
      low-confidence or failure. Applied here to decomposer selection rather
      than LLM model selection.

    Kim et al. (2024). "An LLM Compiler for Parallel Function Calling."
    ICML 2024. arXiv:2312.04511.
    → LLMCompiler DAG-aware decomposition used as the fallback oracle.

Cascade logic:
    1. Try RuleBasedDecomposer (0 cost, <0.1ms)
    2. If result has ≥ 2 sub-queries → accept (rule-based succeeded)
    3. Else → escalate to LLMCompilerDecomposer (cost ~$0.000027, ~2s)

This achieves ~60-70% cost reduction vs always using LLM, since most
syntactically explicit queries (comma-verb sequences, comparison phrases)
are handled by rules without an API call.

Used in: Config C (Cost-First)
Latency: ~0.1ms (rule-based hit) or ~2s (LLM fallback)
Cost   : $0 on rule hit | ~$0.000027 on LLM fallback
"""

import time
from .base import BaseDecomposer, DecompositionResult
from .rule_based_decomposer import RuleBasedDecomposer
from .llmcompiler_decomposer import LLMCompilerDecomposer


class FrugalGPTDecomposer(BaseDecomposer):
    """
    Cascade decomposer: rule-based first, LLMCompiler fallback.
    Implements FrugalGPT cascade principle for cost minimisation.
    """

    def __init__(self, model: str = "gpt-4o-mini", max_subqueries: int = 5):
        self._rule_based = RuleBasedDecomposer()
        self._llm = LLMCompilerDecomposer(model=model, max_subqueries=max_subqueries)
        self._model = model

    def decompose(self, query: str) -> DecompositionResult:
        t0 = time.perf_counter()

        # Stage 1: attempt rule-based decomposition (free)
        rule_result = self._rule_based.decompose(query)

        if len(rule_result.sub_queries) >= 2:
            # Rule-based succeeded — return with cascade metadata
            elapsed = (time.perf_counter() - t0) * 1000
            return DecompositionResult(
                original_query=query,
                sub_queries=rule_result.sub_queries,
                method="frugalgpt_rule",
                latency_ms=elapsed,
                llm_cost_usd=0.0,
                raw_plan=rule_result.raw_plan,
            )

        # Stage 2: rule-based returned 0-1 sub-queries → escalate to LLM
        llm_result = self._llm.decompose(query)
        elapsed = (time.perf_counter() - t0) * 1000

        return DecompositionResult(
            original_query=query,
            sub_queries=llm_result.sub_queries,
            method="frugalgpt_llm",
            latency_ms=elapsed,
            llm_cost_usd=llm_result.llm_cost_usd,
            raw_plan=llm_result.raw_plan,
        )

    def name(self) -> str:
        return "frugalgpt"
