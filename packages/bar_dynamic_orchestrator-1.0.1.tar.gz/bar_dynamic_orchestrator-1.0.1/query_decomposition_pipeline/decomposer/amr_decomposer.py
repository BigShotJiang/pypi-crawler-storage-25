"""
AMR-Based Graph Decomposer
==========================
Parses query into Abstract Meaning Representation (AMR) graph, then
extracts root predicates and their argument clusters as sub-queries.

Academic basis:
    Banarescu et al. (2013). "Abstract Meaning Representation for
    Sembanking." ACL LAW Workshop 2013.
    → AMR encodes "who did what to whom" as a rooted directed graph.

    Bevilacqua et al. (2021). "One SPRING to Rule Them Both: Symmetric
    AMR Semantic Parsing and Generation." AAAI 2021.
    → SPRING parser: state-of-the-art seq2seq AMR parser.

    Shi & Lin (2019). "Simple BERT Models for Relation Extraction and
    Semantic Role Labeling." arXiv:1904.05255.
    → SRL-based predicate-argument extraction (fallback).

Algorithm:
    1. Parse query → AMR graph using amrlib (SPRING model)
    2. Identify top-level predicate nodes (reentrancy depth ≤ 1)
    3. For each predicate: collect its :ARG0/:ARG1 argument spans
    4. Reconstruct sub-query strings from predicate + argument text
    5. Return list of SubQuery objects (parallel — graph nodes are independent)

Fallback (no amrlib): spaCy dependency parse → extract ROOT verb +
    conjunct verbs as predicate anchors → span-based sub-queries.

Used in: Component 2 evaluation (graph-based paradigm)
Latency: ~50–200ms | Cost: $0 | LLM calls: 0
"""

import re
import time
from .base import BaseDecomposer, DecompositionResult, SubQuery


class AMRDecomposer(BaseDecomposer):
    """
    AMR graph-based query decomposer.
    Uses amrlib (SPRING) if available, spaCy dependency parse as fallback.
    """

    def __init__(self):
        self._amr_parser = None
        self._spacy_nlp  = None
        self._backend    = None   # "amr" | "spacy"

    def _init_backend(self):
        if self._backend is not None:
            return

        # Always initialise spaCy — used as fallback even when amrlib is primary
        try:
            import spacy
            try:
                self._spacy_nlp = spacy.load("en_core_web_sm")
            except OSError:
                from spacy.cli import download
                download("en_core_web_sm")
                self._spacy_nlp = spacy.load("en_core_web_sm")
        except Exception:
            self._spacy_nlp = None

        # Try amrlib as primary backend
        try:
            import amrlib
            stog = amrlib.load_stog_model()
            self._amr_parser = stog
            self._backend = "amr"
            return
        except Exception:
            pass

        # Fall back to spaCy only
        if self._spacy_nlp is not None:
            self._backend = "spacy"
        else:
            raise RuntimeError(
                "AMRDecomposer requires either amrlib or spaCy. "
                "Install: pip install spacy && python -m spacy download en_core_web_sm"
            )

    # ── AMR backend ───────────────────────────────────────────────────────

    def _decompose_amr(self, query: str) -> list[str]:
        """Parse AMR and extract top-level predicate spans."""
        try:
            graphs = self._amr_parser.parse_sents([query])
            graph_str = graphs[0] if graphs else ""
            return self._extract_from_amr_string(query, graph_str)
        except Exception:
            return self._decompose_spacy(query)

    def _extract_from_amr_string(self, query: str, amr_str: str) -> list[str]:
        """
        Extract sub-queries from AMR Penman notation.
        Maps AMR predicate frames back to original query word spans,
        producing text fragments instead of template strings.
        """
        if not amr_str:
            return [query]

        # Find all predicate frames (var / concept-NN)
        predicates = re.findall(r'\((\w+)\s*/\s*(\w+-\d+)', amr_str)
        if len(predicates) < 2:
            return [query]

        # Find coordinate structures (:op1, :op2, :conj, :ARG1/2)
        coord_spans = re.findall(
            r':(?:op\d+|conj|ARG[12])\s*\(([^()]+(?:\([^()]*\)[^()]*)*)\)',
            amr_str
        )

        if len(coord_spans) >= 2:
            words = query.split()
            sub_queries = []
            for span in coord_spans[:3]:
                # Extract all concept words from this span
                concepts = re.findall(r'/\s*(\S+)', span)
                if not concepts:
                    continue
                # Clean concept names: remove sense suffix, replace hyphens
                clean_concepts = []
                for c in concepts:
                    c = re.sub(r'-\d+$', '', c)   # remove -01, -02, etc.
                    c = c.replace('-', ' ')
                    clean_concepts.extend(c.split())

                # Find best matching window in original query
                best_start, best_score = 0, -1
                for i in range(len(words)):
                    window = " ".join(words[i:i+6]).lower()
                    score = sum(1 for w in clean_concepts if w.lower() in window)
                    if score > best_score:
                        best_score, best_start = score, i

                # Extract a meaningful span around the best anchor
                end = min(best_start + 8, len(words))
                fragment = " ".join(words[best_start:end]).strip().rstrip('?,.')
                if len(fragment.split()) >= 3:
                    sub_queries.append(fragment)

            # De-duplicate and ensure at least 2 distinct fragments
            seen = set()
            unique = []
            for sq in sub_queries:
                key = sq[:30].lower()
                if key not in seen:
                    seen.add(key)
                    unique.append(sq)

            if len(unique) >= 2:
                return unique

        return self._decompose_spacy(query)

    # ── spaCy fallback backend ────────────────────────────────────────────

    def _decompose_spacy(self, query: str) -> list[str]:
        """
        Dependency parse → extract ROOT verb + conjunct verbs as sub-queries.
        Each verb cluster (verb + its arguments) = one sub-query.
        """
        doc = self._spacy_nlp(query)

        # Find ROOT and conjunct verbs
        root  = [t for t in doc if t.dep_ == "ROOT"]
        conjs = [t for t in doc if t.dep_ == "conj" and t.pos_ in ("VERB", "AUX")]
        anchors = root + conjs

        if len(anchors) < 2:
            # Try splitting on coordinator conjunctions (and, as well as)
            return self._split_on_connectives(query)

        sub_queries = []
        for anchor in anchors[:3]:
            # Collect the subtree of this verb
            span_tokens = sorted(set(anchor.subtree), key=lambda t: t.i)
            # Remove tokens that belong to other anchors' subtrees
            other_anchors = [a for a in anchors if a != anchor]
            other_subtrees = set()
            for oa in other_anchors:
                other_subtrees.update(t.i for t in oa.subtree)
            span_tokens = [t for t in span_tokens if t.i not in other_subtrees]
            text = " ".join(t.text for t in span_tokens).strip()
            if len(text.split()) >= 3:
                sub_queries.append(text)

        return sub_queries if len(sub_queries) >= 2 else self._split_on_connectives(query)

    def _split_on_connectives(self, query: str) -> list[str]:
        """Last-resort: split on action-verb connectives or bare 'and'."""
        _ACTION = (
            r'(?:list|find|get|retrieve|calculate|compute|determine|identify|'
            r'analyze|analyse|evaluate|examine|compare|create|generate|extract|'
            r'collect|gather|aggregate|classify|sort|rank|summarize|count|measure|'
            r'check|verify|locate|detect|describe|explain|show|produce|build|'
            r'estimate|assess|review|translate|convert|apply|combine|filter|'
            r'select|search|process|parse|clean|save|explore|investigate|'
            r'acquire|obtain|derive|inspect|monitor|track|record|report|'
            r'solve|address|manage|categorize|label|define|establish|validate)'
        )
        patterns = [
            # "X and also Y"
            r'\s+and\s+also\s+',
            # "X as well as Y"
            r'\s+as\s+well\s+as\s+',
            # "X while also Y"
            r'\s+while\s+also\s+',
            # ", and Y" where Y starts with action verb
            rf',\s+and\s+(?={_ACTION}\b)',
            # " and Y" where Y starts with action verb
            rf'\s+and\s+(?={_ACTION}\b)',
            # bare " and " on short queries
            r'\s+and\s+',
        ]
        for pat in patterns:
            parts = re.split(pat, query, maxsplit=1, flags=re.IGNORECASE)
            if len(parts) == 2 and all(len(p.split()) >= 3 for p in parts):
                return [p.strip() for p in parts]
        return [query]

    # ── Main interface ────────────────────────────────────────────────────

    def decompose(self, query: str) -> DecompositionResult:
        self._init_backend()
        t0 = time.perf_counter()

        if self._backend == "amr":
            sub_texts = self._decompose_amr(query)
        else:
            sub_texts = self._decompose_spacy(query)

        elapsed = (time.perf_counter() - t0) * 1000

        if len(sub_texts) <= 1:
            sub_texts = [query]

        sub_queries = [
            SubQuery(id=f"${i+1}", text=t.strip(), depends_on=[])
            for i, t in enumerate(sub_texts)
            if t.strip()
        ]

        # Post-process: infer sequential dependencies from anaphoric signals
        from .dependency_inferrer import infer_dependencies
        sub_queries = infer_dependencies(sub_queries, query)

        return DecompositionResult(
            original_query=query,
            sub_queries=sub_queries,
            method=f"amr_{self._backend}",
            latency_ms=elapsed,
            llm_cost_usd=0.0,
            raw_plan=" | ".join(sub_texts),
        )

    def name(self) -> str:
        return "amr"
