"""
Dependency Inferrer — Post-processing for decomposers that produce no deps.
============================================================================
Detects whether sub-query N semantically references the result of sub-query
N-1 (anaphoric coreference), and marks it as sequential if so.

Used by: ToRLiteDecomposer, UnsupervisedDecomposer, AMRDecomposer, DeCoRDecomposer
Not needed by: LLMCompilerDecomposer (produces deps natively via DAG)

Detection signals (anaphoric reference indicators):
    - Demonstrative pronouns: "that", "this", "those", "these", "it", "its",
      "they", "their", "them"
    - Definite reference phrases: "that country", "that monarch", "the same X",
      "the identified X", "the result", "based on that", "of that", "from that"
    - Shared noun overlap: if sub-query 2 contains nouns that only appear
      in sub-query 1 (not in the original query prefix) → dependency likely

Academic basis:
    Jurafsky & Martin (2023). "Speech and Language Processing." Chapter 21
    (Coreference Resolution) — anaphoric reference as dependency signal.
"""

import re


_ANAPHORIC_PRONOUNS = re.compile(
    r'\b(it|its|they|them|their|this|that|these|those|'
    r'the\s+same|the\s+result|the\s+above|based\s+on\s+that|'
    r'of\s+that|from\s+that|the\s+identified|the\s+found|'
    r'the\s+aforementioned|said\s+\w+)\b',
    re.IGNORECASE
)

_SEQUENTIAL_CONNECTIVES = re.compile(
    r'\b(then|next|subsequently|after\s+that|following\s+that|'
    r'once\s+(?:you\s+)?(?:have\s+)?(?:identified|found|determined)|'
    r'using\s+(?:the|this|that)|with\s+(?:the|this|that)\s+\w+)\b',
    re.IGNORECASE
)


def infer_dependencies(sub_queries, original_query: str) -> list:
    """
    Post-process sub-queries to infer sequential dependencies.
    Returns updated sub_queries with depends_on filled where detected.

    Args:
        sub_queries : list of SubQuery objects
        original_query : the original complex query

    Returns:
        same list with depends_on updated in-place
    """
    from .base import SubQuery

    if len(sub_queries) <= 1:
        return sub_queries

    # Extract nouns from each sub-query for overlap analysis
    def extract_content_words(text: str) -> set:
        stop = {'what', 'who', 'where', 'when', 'how', 'which', 'is', 'are',
                'was', 'were', 'the', 'a', 'an', 'of', 'in', 'on', 'at', 'to',
                'for', 'and', 'or', 'but', 'with', 'by', 'from', 'into', 'as'}
        return {w.lower() for w in re.findall(r'\b[a-zA-Z]{3,}\b', text)
                if w.lower() not in stop}

    original_words = extract_content_words(original_query)

    updated = list(sub_queries)

    for i in range(1, len(updated)):
        sq_text = updated[i].text

        # Signal 1: anaphoric pronouns / demonstratives
        # e.g. "that country", "the same monarch", "it", "they"
        has_anaphora = bool(_ANAPHORIC_PRONOUNS.search(sq_text))

        # Signal 2: sequential connectives
        # e.g. "then find", "next identify", "using the result"
        has_connective = bool(_SEQUENTIAL_CONNECTIVES.search(sq_text))

        # Declare dependency only on clear linguistic signals
        # (Shared word overlap NOT used — too many false positives on
        #  comparison queries where both sub-queries use the same template)
        if has_anaphora or has_connective:
            updated[i] = SubQuery(
                id=updated[i].id,
                text=updated[i].text,
                depends_on=[updated[i-1].id],
                estimated_category=updated[i].estimated_category,
            )

    return updated
