"""
Pipeline Configuration
=======================
Defines 4 business-driven configurations:

  Config A — Accuracy-First : TF-IDF+SVM detector + LLMCompiler decomposer + DAG planner
  Config B — Balanced       : MiniLM+SVM detector + LLMCompiler decomposer + DAG planner
  Config C — Cost-First     : TF-IDF+SVM detector + FrugalGPT cascade decomposer + DAG planner
  Config D — Latency-First  : Rule-based detector  + Rule-based decomposer + Rule-based planner

Academic basis:
    Config A/B detectors: Bansal & Agarwal (2026). RAGRouter-Bench. arXiv:2604.03455.
    Config C cascade: Chen et al. (2023). FrugalGPT. arXiv:2305.05176.
    Config D rule-based: Wolfson et al. (2020). BREAK. TACL 2020.

Component choices per config:
  Component 1: Complexity Detector  — tfidf_svm | minilm_svm | rule_based
  Component 2: Decomposer           — llmcompiler | frugalgpt | rule_based
  Component 3: Execution Planner    — dag | rule_based
"""

from dataclasses import dataclass
from enum import Enum


class ConfigName(str, Enum):
    A = "accuracy_first"
    B = "balanced"
    C = "cost_first"
    D = "latency_first"


@dataclass
class PipelineConfig:
    name: ConfigName

    # Component 1: complexity detector
    detector: str                         # "tfidf_svm" | "minilm_svm" | "rule_based"
    detector_model_path: str = None       # path to saved detector model (for trained detectors)

    # Component 2: decomposer
    decomposer: str = "llmcompiler"       # "llmcompiler" | "frugalgpt" | "rule_based"
    llm_model: str = "gpt-4o-mini"
    max_subqueries: int = 5

    # Component 3: execution planner
    planner: str = "dag"                  # "dag" | "rule_based"

    def describe(self) -> str:
        lines = [
            f"Config: {self.name.value}",
            f"  Detector  : {self.detector}",
            f"  Decomposer: {self.decomposer}",
            f"  Planner   : {self.planner}",
            f"  LLM model : {self.llm_model if self.decomposer in ('llmcompiler', 'frugalgpt') else 'none'}",
        ]
        return "\n".join(lines)


# ── Pre-built configurations ───────────────────────────────────────────────

CONFIG_A = PipelineConfig(
    name=ConfigName.A,
    detector="tfidf_svm",
    decomposer="llmcompiler",
    planner="dag",
    llm_model="gpt-4o-mini",
)

CONFIG_B = PipelineConfig(
    name=ConfigName.B,
    detector="minilm_svm",
    decomposer="llmcompiler",
    planner="dag",
    llm_model="gpt-4o-mini",
)

CONFIG_C = PipelineConfig(
    name=ConfigName.C,
    detector="tfidf_svm",
    decomposer="frugalgpt",          # rule-based first, LLM only if rule-based fails
    planner="dag",
    llm_model="gpt-4o-mini",
)

CONFIG_D = PipelineConfig(
    name=ConfigName.D,
    detector="rule_based",
    decomposer="rule_based",
    planner="rule_based",
    llm_model="",
)

CONFIGS = {
    ConfigName.A: CONFIG_A,
    ConfigName.B: CONFIG_B,
    ConfigName.C: CONFIG_C,
    ConfigName.D: CONFIG_D,
}
