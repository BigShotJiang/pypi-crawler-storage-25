"""
Query Decomposition Pipeline
==============================
Three-component pipeline:
  Component 1: Complexity Detector  — simple or complex?
  Component 2: Decomposer           — split complex query into sub-queries
  Component 3: Execution Planner    — parallel / sequential

Four business-driven configurations:
  Config A — Accuracy-First : TF-IDF+SVM + LLMCompiler + DAG
  Config B — Balanced       : MiniLM+SVM + LLMCompiler + DAG
  Config C — Cost-First     : TF-IDF+SVM + FrugalGPT cascade + DAG
  Config D — Latency-First  : Rule-based + Rule-based + Rule-based
"""

import time
from dataclasses import dataclass, field

from ..config import PipelineConfig, ConfigName, CONFIGS
from ..complexity_detector.tfidf_svm_detector import TFIDFSVMDetector
from ..complexity_detector.minilm_svm_detector import MiniLMSVMDetector
from ..complexity_detector.rule_based_detector import RuleBasedDetector
from ..complexity_detector.base import ComplexityResult
from ..decomposer.llmcompiler_decomposer import LLMCompilerDecomposer
from ..decomposer.frugalgpt_decomposer import FrugalGPTDecomposer
from ..decomposer.rule_based_decomposer import RuleBasedDecomposer
from ..decomposer.base import DecompositionResult
from ..execution_planner.dag_planner import DAGPlanner
from ..execution_planner.rule_based_planner import RuleBasedPlanner
from ..execution_planner.base import ExecutionPlan


@dataclass
class PipelineOutput:
    original_query: str
    config_name: str

    # Component 1
    complexity: ComplexityResult

    # Component 2 — None if query is simple
    decomposition: DecompositionResult = None

    # Component 3 — None if query is simple
    execution_plan: ExecutionPlan = None

    # Totals
    total_latency_ms: float = 0.0
    total_cost_usd: float = 0.0

    def execution_type(self) -> str:
        """Returns 'simple', 'parallel', or 'sequential'.
        If any execution group has > 1 sub-query → parallel.
        If all groups are singletons forming a chain → sequential.
        """
        if not self.execution_plan:
            return "simple"
        groups = self.execution_plan.groups
        has_parallel = any(len(g.sub_query_ids) > 1 for g in groups)
        if has_parallel:
            return "parallel"
        return "sequential"

    def summary(self) -> str:
        lines = [
            f"Query     : {self.original_query[:100]}",
            f"Config    : {self.config_name}",
            f"Complexity: {'COMPLEX' if self.complexity.is_complex else 'SIMPLE'} "
            f"(conf={self.complexity.confidence:.2f}, method={self.complexity.method})",
        ]
        if self.decomposition:
            lines.append(f"Sub-queries ({len(self.decomposition.sub_queries)}):")
            for sq in self.decomposition.sub_queries:
                dep = f" depends_on={sq.depends_on}" if sq.depends_on else ""
                lines.append(f"  {sq.id}: {sq.text[:80]}{dep}")
        if self.execution_plan:
            lines.append(f"Exec type : {self.execution_type().upper()}")
            for g in sorted(self.execution_plan.groups, key=lambda g: g.step):
                lines.append(f"  Step {g.step} [{g.mode.value}]: {g.sub_query_ids}")
        lines += [
            f"Latency   : {self.total_latency_ms:.2f}ms",
            f"Cost      : ${self.total_cost_usd:.6f}",
        ]
        return "\n".join(lines)


class QueryPipeline:
    """
    Main pipeline. Initialise with a config, call .run(query).

    For Config A and C (TF-IDF+SVM detector) or Config B (MiniLM+SVM),
    the detector must be trained before the pipeline is usable. Pass a
    pre-trained detector instance via the `detector` keyword argument, or
    use a saved model path in the config.

    Usage (untrained — Config D only, fully rule-based):
        pipeline = QueryPipeline(ConfigName.D)
        output = pipeline.run("Compare symptoms of diabetes and hypertension")

    Usage (pre-trained detector for Config A/B/C):
        detector = TFIDFSVMDetector()
        detector.train(queries, labels)
        pipeline = QueryPipeline(ConfigName.A, detector=detector)
        output = pipeline.run("...")
        print(output.summary())
    """

    def __init__(
        self,
        config: "ConfigName | PipelineConfig" = ConfigName.B,
        detector=None,
    ):
        if isinstance(config, ConfigName):
            self.config = CONFIGS[config]
        else:
            self.config = config

        self._detector = detector if detector is not None else self._build_detector()
        self._decomposer = self._build_decomposer()
        self._planner = self._build_planner()

        print(f"[Pipeline] Initialised.\n{self.config.describe()}")

    def run(self, query: str) -> PipelineOutput:
        t_start = time.perf_counter()
        total_cost = 0.0

        # ── Component 1: Complexity Detection ─────────────────────────────
        complexity = self._detector.detect(query)

        if not complexity.is_complex:
            return PipelineOutput(
                original_query=query,
                config_name=self.config.name.value,
                complexity=complexity,
                total_latency_ms=(time.perf_counter() - t_start) * 1000,
                total_cost_usd=0.0,
            )

        # ── Component 2: Decomposition ────────────────────────────────────
        decomposition = self._decomposer.decompose(query)
        total_cost += decomposition.llm_cost_usd

        # ── Component 3: Execution Planning ──────────────────────────────
        plan = self._planner.plan(decomposition.sub_queries)

        return PipelineOutput(
            original_query=query,
            config_name=self.config.name.value,
            complexity=complexity,
            decomposition=decomposition,
            execution_plan=plan,
            total_latency_ms=(time.perf_counter() - t_start) * 1000,
            total_cost_usd=total_cost,
        )

    # ── Internal ──────────────────────────────────────────────────────────

    def _build_detector(self):
        d = self.config.detector
        model_path = self.config.detector_model_path

        if d == "tfidf_svm":
            return TFIDFSVMDetector(model_path=model_path)
        if d == "minilm_svm":
            return MiniLMSVMDetector(model_path=model_path)
        return RuleBasedDetector()

    def _build_decomposer(self):
        d = self.config.decomposer
        if d == "llmcompiler":
            return LLMCompilerDecomposer(
                model=self.config.llm_model,
                max_subqueries=self.config.max_subqueries,
            )
        if d == "frugalgpt":
            return FrugalGPTDecomposer(
                model=self.config.llm_model,
                max_subqueries=self.config.max_subqueries,
            )
        return RuleBasedDecomposer()

    def _build_planner(self):
        if self.config.planner == "dag":
            return DAGPlanner()
        return RuleBasedPlanner()


# Backward-compatible alias
RouterPipeline = QueryPipeline
