"""
Category LLM Pool
==================
Maps each of the 11 query categories to an OpenAI model and calls it.
The mapping is fully customizable — users can override any category → model.

Default mapping (all OpenAI, cost-tiered by task sensitivity):
    High-stakes / complex  → gpt-4o
    General purpose        → gpt-4o-mini

11 categories:
    REASONING, CODE, CREATIVE_WRITING, FACTUAL_KNOWLEDGE,
    INSTRUCTION_FOLLOWING, CONVERSATIONAL, MULTILINGUAL,
    SUMMARIZATION, MEDICAL, LEGAL, FINANCE
"""

import os
import time
from dataclasses import dataclass
from typing import Optional
from dotenv import load_dotenv

load_dotenv()  # Load environment variables from .env file

# Default category → model mapping (fully overridable by user)
DEFAULT_CATEGORY_MODEL_MAP: dict[str, str] = {
    # High-stakes: need accuracy and deep reasoning → gpt-4o
    "REASONING":             "gpt-4o",
    "CODE":                  "gpt-4o",
    "MEDICAL":               "gpt-4o",
    "LEGAL":                 "gpt-4o",
    "FINANCE":               "gpt-4o",
    # General purpose → gpt-4o-mini (cheaper, fast enough)
    "CREATIVE_WRITING":      "gpt-4o-mini",
    "FACTUAL_KNOWLEDGE":     "gpt-4o-mini",
    "INSTRUCTION_FOLLOWING": "gpt-4o-mini",
    "CONVERSATIONAL":        "gpt-4o-mini",
    "MULTILINGUAL":          "gpt-4o-mini",
    "SUMMARIZATION":         "gpt-4o-mini",
}

# Cost per 1M tokens (OpenAI pricing, May 2026)
_COST_PER_1M: dict[str, dict] = {
    "gpt-4o":      {"input": 2.50,  "output": 10.00},
    "gpt-4o-mini": {"input": 0.15,  "output": 0.60},
}

_SYSTEM_PROMPT = (
    "You are a helpful, accurate, and concise assistant. "
    "Answer the question directly and thoroughly."
)


@dataclass
class CategoryResponse:
    sub_query_id: str
    sub_query_text: str
    category: str
    model_used: str
    answer: str
    latency_ms: float
    cost_usd: float
    error: Optional[str] = None


class CategoryLLMPool:
    """
    Sends each sub-query (with its category label) to the appropriate
    OpenAI model and returns the answer.

    Args:
        category_model_map: override the default category → model mapping
        system_prompt: override the default system prompt
        max_tokens: max tokens for each LLM response
        temperature: generation temperature (0 = deterministic)
    """

    def __init__(
        self,
        category_model_map: Optional[dict[str, str]] = None,
        system_prompt: str = _SYSTEM_PROMPT,
        max_tokens: int = 1024,
        temperature: float = 0.0,
    ):
        self._map = {**DEFAULT_CATEGORY_MODEL_MAP, **(category_model_map or {})}
        self._system_prompt = system_prompt
        self._max_tokens = max_tokens
        self._temperature = temperature
        self._client = None

    def _get_client(self):
        if self._client is None:
            from openai import OpenAI
            api_key = os.environ.get("OPENAI_API_KEY")
            if not api_key:
                raise RuntimeError(
                    "CategoryLLMPool requires OPENAI_API_KEY. "
                    "Set it with: export OPENAI_API_KEY='sk-...'"
                )
            self._client = OpenAI(api_key=api_key)
        return self._client

    def call(self, sub_query_id: str, sub_query_text: str, category: str) -> CategoryResponse:
        """Send one sub-query to its category LLM and return the answer."""
        model = self._map.get(category, "gpt-4o-mini")
        t0 = time.perf_counter()
        cost = 0.0
        error = None
        answer = ""

        try:
            client = self._get_client()
            resp = client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": self._system_prompt},
                    {"role": "user",   "content": sub_query_text},
                ],
                max_tokens=self._max_tokens,
                temperature=self._temperature,
                timeout=60,
            )
            answer = resp.choices[0].message.content.strip()
            usage = resp.usage
            rates = _COST_PER_1M.get(model, {"input": 0.0, "output": 0.0})
            cost = (
                usage.prompt_tokens     * rates["input"]  / 1_000_000 +
                usage.completion_tokens * rates["output"] / 1_000_000
            )
        except Exception as e:
            error = str(e)
            answer = f"[Error calling {model}: {e}]"

        latency_ms = (time.perf_counter() - t0) * 1000

        return CategoryResponse(
            sub_query_id=sub_query_id,
            sub_query_text=sub_query_text,
            category=category,
            model_used=model,
            answer=answer,
            latency_ms=latency_ms,
            cost_usd=cost,
            error=error,
        )

    def call_batch(
        self,
        sub_queries: list[tuple[str, str, str]],  # [(id, text, category)]
        parallel: bool = False,
    ) -> list[CategoryResponse]:
        """
        Call multiple sub-queries.
        If parallel=True, uses ThreadPoolExecutor for concurrent calls.
        """
        if parallel and len(sub_queries) > 1:
            from concurrent.futures import ThreadPoolExecutor, as_completed
            results = {}
            with ThreadPoolExecutor(max_workers=min(len(sub_queries), 5)) as executor:
                futures = {
                    executor.submit(self.call, sid, text, cat): sid
                    for sid, text, cat in sub_queries
                }
                for future in as_completed(futures):
                    resp = future.result()
                    results[resp.sub_query_id] = resp
            # Return in original order
            return [results[sid] for sid, _, _ in sub_queries if sid in results]
        else:
            return [self.call(sid, text, cat) for sid, text, cat in sub_queries]

    @property
    def model_map(self) -> dict[str, str]:
        """Return the current category → model mapping."""
        return dict(self._map)
