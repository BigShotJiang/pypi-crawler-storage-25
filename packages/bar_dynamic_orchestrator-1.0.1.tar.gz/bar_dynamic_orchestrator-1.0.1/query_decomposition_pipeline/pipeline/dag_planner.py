"""
Component 3: DAG Execution Planner
===================================
Reads sub-queries produced by Component 2 (each with depends_on),
builds a directed acyclic graph, and assigns each sub-query an
execution tag: PARALLEL or SEQUENTIAL.

A sub-query is PARALLEL  if it has no depends_on (can run immediately).
A sub-query is SEQUENTIAL if it depends on at least one other sub-query
(must wait for that result before executing).

Output: ExecutionPlan — an ordered list of ExecutionStages, where each
stage is a group of sub-queries that can run at the same time.

Example:
    Sub-queries: [$1(deps=[]), $2(deps=[$1]), $3(deps=[])]
    Stage 0 (PARALLEL): $1, $3   ← no dependencies, run together
    Stage 1 (SEQUENTIAL): $2     ← waits for $1
"""

from dataclasses import dataclass, field
from typing import Literal


ExecTag = Literal["PARALLEL", "SEQUENTIAL"]


@dataclass
class PlannedSubQuery:
    id: str
    text: str
    depends_on: list[str]
    exec_tag: ExecTag       # PARALLEL = no deps, SEQUENTIAL = has deps
    stage: int              # execution stage index (0 = first wave)


@dataclass
class ExecutionPlan:
    stages: list[list[PlannedSubQuery]]   # stages[i] = list of subs to run together
    original_query: str = ""

    @property
    def all_sub_queries(self) -> list[PlannedSubQuery]:
        return [sq for stage in self.stages for sq in stage]

    @property
    def n_stages(self) -> int:
        return len(self.stages)

    @property
    def n_parallel(self) -> int:
        return sum(1 for sq in self.all_sub_queries if sq.exec_tag == "PARALLEL")

    @property
    def n_sequential(self) -> int:
        return sum(1 for sq in self.all_sub_queries if sq.exec_tag == "SEQUENTIAL")


class DAGPlanner:
    """
    Builds an execution plan from a list of SubQuery objects.
    Uses topological sort (Kahn's algorithm) to determine stage ordering.
    """

    def plan(self, sub_queries, original_query: str = "") -> ExecutionPlan:
        """
        Args:
            sub_queries: list of SubQuery (from Component 2 decomposer)
            original_query: the original user query (for context)
        Returns:
            ExecutionPlan with ordered stages
        """
        if not sub_queries:
            return ExecutionPlan(stages=[], original_query=original_query)

        # If only one sub-query — treat as PARALLEL (no dependencies)
        if len(sub_queries) == 1:
            sq = sub_queries[0]
            planned = PlannedSubQuery(
                id=sq.id, text=sq.text, depends_on=[],
                exec_tag="PARALLEL", stage=0,
            )
            return ExecutionPlan(stages=[[planned]], original_query=original_query)

        # Build id → SubQuery map
        id_map = {sq.id: sq for sq in sub_queries}

        # Compute in-degree for Kahn's topological sort
        in_degree = {sq.id: 0 for sq in sub_queries}
        for sq in sub_queries:
            for dep in sq.depends_on:
                if dep in in_degree:
                    in_degree[sq.id] += 1

        # Kahn's algorithm — group nodes by stage
        stages: list[list[PlannedSubQuery]] = []
        remaining = set(sq.id for sq in sub_queries)
        stage_idx = 0

        while remaining:
            # Nodes with in-degree 0 in current remaining set → next stage
            ready = [sid for sid in remaining if in_degree[sid] == 0]
            if not ready:
                # Cycle detected (shouldn't happen with valid decomposers) — break
                # Put all remaining as a single parallel stage
                ready = list(remaining)

            planned_stage = []
            for sid in sorted(ready):   # sorted for determinism
                sq = id_map[sid]
                has_deps = bool(sq.depends_on)
                planned_stage.append(PlannedSubQuery(
                    id=sq.id,
                    text=sq.text,
                    depends_on=list(sq.depends_on),
                    exec_tag="SEQUENTIAL" if has_deps else "PARALLEL",
                    stage=stage_idx,
                ))
                remaining.discard(sid)

            # Reduce in-degree of dependents
            for sid in ready:
                for sq in sub_queries:
                    if sid in sq.depends_on and sq.id in remaining:
                        in_degree[sq.id] -= 1

            stages.append(planned_stage)
            stage_idx += 1

        return ExecutionPlan(stages=stages, original_query=original_query)


class RuleBasedPlanner(DAGPlanner):
    """Alias — same as DAGPlanner. Used by Config D (latency-first)."""
    pass
