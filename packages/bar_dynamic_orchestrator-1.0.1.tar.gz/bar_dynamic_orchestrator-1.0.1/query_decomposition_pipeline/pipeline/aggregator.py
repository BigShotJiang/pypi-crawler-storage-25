"""
Response Aggregator
====================
Combines answers from all sub-queries into one coherent final response.

Two modes:
    simple   — concatenate answers with section headers (no LLM call)
    llm      — use an LLM to synthesize answers into a unified response

Simple mode is the default (zero extra cost, instant).
LLM mode produces a more natural flowing answer at the cost of one extra call.
"""

import os
import time
from dataclasses import dataclass
from typing import Literal, Optional

from .category_pool import CategoryResponse


AggregationMode = Literal["simple", "llm"]


@dataclass
class AggregatedResponse:
    original_query: str
    final_answer: str
    sub_responses: list[CategoryResponse]
    mode: AggregationMode
    latency_ms: float
    cost_usd: float


class Aggregator:
    """
    Combines sub-query answers into a single final response.

    Args:
        mode: "simple" (concat) or "llm" (LLM synthesis)
        model: OpenAI model to use when mode="llm"
        max_tokens: max tokens for synthesis call
    """

    def __init__(
        self,
        mode: AggregationMode = "simple",
        model: str = "gpt-4o-mini",
        max_tokens: int = 1024,
    ):
        self._mode = mode
        self._model = model
        self._max_tokens = max_tokens
        self._client = None

    def aggregate(
        self,
        original_query: str,
        sub_responses: list[CategoryResponse],
    ) -> AggregatedResponse:
        t0 = time.perf_counter()

        if self._mode == "llm":
            answer, cost = self._llm_synthesize(original_query, sub_responses)
        else:
            answer = self._simple_concat(sub_responses)
            cost = 0.0

        latency_ms = (time.perf_counter() - t0) * 1000
        return AggregatedResponse(
            original_query=original_query,
            final_answer=answer,
            sub_responses=sub_responses,
            mode=self._mode,
            latency_ms=latency_ms,
            cost_usd=cost,
        )

    # ── Simple concat ─────────────────────────────────────────────────────

    def _simple_concat(self, sub_responses: list[CategoryResponse]) -> str:
        if not sub_responses:
            return ""
        if len(sub_responses) == 1:
            return sub_responses[0].answer

        parts = []
        for i, resp in enumerate(sub_responses, 1):
            parts.append(f"**Part {i}** ({resp.category}):\n{resp.answer}")
        return "\n\n".join(parts)

    # ── LLM synthesis ─────────────────────────────────────────────────────

    def _llm_synthesize(
        self,
        original_query: str,
        sub_responses: list[CategoryResponse],
    ) -> tuple[str, float]:
        if not sub_responses:
            return "", 0.0
        if len(sub_responses) == 1:
            return sub_responses[0].answer, 0.0

        # Build the synthesis prompt
        sub_answers_text = "\n\n".join(
            f"Sub-question {i+1}: {r.sub_query_text}\n"
            f"Answer {i+1}: {r.answer}"
            for i, r in enumerate(sub_responses)
        )

        system = (
            "You are a synthesis assistant. You are given a complex user question "
            "that was broken into sub-questions, each answered separately. "
            "Your task is to combine all answers into one coherent, complete, "
            "and well-structured response to the original question. "
            "Do not repeat information. Do not add new information."
        )
        user = (
            f"Original question: {original_query}\n\n"
            f"Sub-questions and answers:\n{sub_answers_text}\n\n"
            f"Please synthesize a unified answer to the original question."
        )

        try:
            client = self._get_client()
            resp = client.chat.completions.create(
                model=self._model,
                messages=[
                    {"role": "system", "content": system},
                    {"role": "user",   "content": user},
                ],
                max_tokens=self._max_tokens,
                temperature=0.0,
                timeout=60,
            )
            answer = resp.choices[0].message.content.strip()
            usage = resp.usage
            # gpt-4o-mini pricing
            cost = (
                usage.prompt_tokens     * 0.15  / 1_000_000 +
                usage.completion_tokens * 0.60  / 1_000_000
            )
            return answer, cost
        except Exception as e:
            # Fallback to simple concat if LLM fails
            return self._simple_concat(sub_responses), 0.0

    def _get_client(self):
        if self._client is None:
            from openai import OpenAI
            self._client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
        return self._client
