"""
Unified Business-Aware LLM Routing Pipeline
=============================================
Wires all three components + LLM router + category pool + aggregator
into a single callable pipeline.

Full flow:
    1. Component 1 — Complexity Detector  → is_complex bool
    2. Component 2 — Query Decomposer     → sub_queries (if complex)
    3. Component 3 — DAG Execution Planner→ execution plan with stages
    4. LLM Router  — per sub-query        → category label
    5. Category Pool — per sub-query      → LLM answer
    6. Aggregator  — all answers          → final unified response

Usage:
    pipeline = UnifiedPipeline(
        router_approach="transformer",   # transformer | rag | llm | rnn
        decomposer="llmcompiler",        # llmcompiler | rule_based | tor_lite | ...
        detector="tfidf_svm",            # tfidf_svm | minilm_svm | rule_based | distilbert
        aggregation_mode="simple",       # simple | llm
        category_model_map={             # optional: override defaults
            "CODE": "gpt-4o",
            "CONVERSATIONAL": "gpt-4o-mini",
        }
    )
    result = pipeline.run("Your complex query here")
"""

import os
import time
from dataclasses import dataclass, field
from typing import Optional, Literal

from .dag_planner import DAGPlanner, ExecutionPlan, PlannedSubQuery
from .category_pool import CategoryLLMPool, CategoryResponse
from .aggregator import Aggregator, AggregatedResponse


RouterApproach  = Literal["transformer", "rag", "llm", "rnn"]
DecomposerName  = Literal["llmcompiler", "decor", "rule_based", "tor_lite", "amr", "unsupervised"]
DetectorName    = Literal["tfidf_svm", "minilm_svm", "rule_based", "distilbert"]
AggregationMode = Literal["simple", "llm"]


@dataclass
class PipelineResult:
    original_query: str
    is_complex: bool

    # Component 2 output (None if simple query)
    sub_queries: list[dict] = field(default_factory=list)

    # Component 3 output
    execution_plan: Optional[dict] = None

    # Router output per sub-query
    routing: list[dict] = field(default_factory=list)

    # LLM responses per sub-query
    sub_responses: list[dict] = field(default_factory=list)

    # Final aggregated answer
    final_answer: str = ""

    # Timing and cost
    total_latency_ms: float = 0.0
    total_cost_usd: float = 0.0
    component_latency: dict = field(default_factory=dict)


class UnifiedPipeline:
    """
    End-to-end Business-Aware LLM Routing Pipeline.

    Args:
        router_approach : which LLM router to use for category classification
        decomposer      : which decomposer to use for complex queries
        detector        : which complexity detector to use
        aggregation_mode: "simple" (concat) or "llm" (synthesis)
        category_model_map: override default category → OpenAI model mapping
        aggregator_model: OpenAI model to use for LLM aggregation (if mode="llm")
    """

    def __init__(
        self,
        router_approach: RouterApproach = "llm",
        decomposer: DecomposerName = "llmcompiler",
        detector: DetectorName = "tfidf_svm",
        aggregation_mode: AggregationMode = "simple",
        category_model_map: Optional[dict[str, str]] = None,
        aggregator_model: str = "gpt-4o-mini",
    ):
        self._router_approach  = router_approach
        self._decomposer_name  = decomposer
        self._detector_name    = detector
        self._aggregation_mode = aggregation_mode

        # Lazy-init heavy components
        self._detector   = None
        self._decomposer = None
        self._router     = None

        self._planner    = DAGPlanner()
        self._pool       = CategoryLLMPool(category_model_map=category_model_map)
        self._aggregator = Aggregator(mode=aggregation_mode, model=aggregator_model)

    # ── Public API ────────────────────────────────────────────────────────

    def run(self, query: str) -> PipelineResult:
        """
        Run the full pipeline on a user query.
        Returns a PipelineResult with all intermediate outputs + final answer.
        """
        t_total = time.perf_counter()
        result = PipelineResult(original_query=query, is_complex=False)
        latency = {}

        # ── Step 1: Complexity Detection ──────────────────────────────────
        t0 = time.perf_counter()
        is_complex = self._detect_complexity(query)
        latency["detector_ms"] = (time.perf_counter() - t0) * 1000
        result.is_complex = is_complex

        # ── Step 2: Decomposition (only if complex) ────────────────────────
        if is_complex:
            t0 = time.perf_counter()
            decomp_result = self._decompose(query)
            latency["decomposer_ms"] = (time.perf_counter() - t0) * 1000

            result.sub_queries = [
                {"id": sq.id, "text": sq.text, "depends_on": sq.depends_on}
                for sq in decomp_result.sub_queries
            ]

            # ── Step 3: Execution Planning ─────────────────────────────────
            t0 = time.perf_counter()
            plan = self._planner.plan(decomp_result.sub_queries, query)
            latency["planner_ms"] = (time.perf_counter() - t0) * 1000

            result.execution_plan = {
                "n_stages":    plan.n_stages,
                "n_parallel":  plan.n_parallel,
                "n_sequential": plan.n_sequential,
                "stages": [
                    [{"id": sq.id, "text": sq.text, "exec_tag": sq.exec_tag}
                     for sq in stage]
                    for stage in plan.stages
                ],
            }

            # ── Steps 4+5: Route + Execute each stage ─────────────────────
            all_responses: list[CategoryResponse] = []
            prev_answers: dict[str, str] = {}   # id → answer (for sequential context)

            t_route = 0.0
            t_pool  = 0.0

            for stage in plan.stages:
                # Route all sub-queries in this stage
                t0 = time.perf_counter()
                routed = []
                for sq in stage:
                    text = self._inject_context(sq, prev_answers)
                    category = self._route(text)
                    routed.append((sq.id, text, category))
                    result.routing.append({
                        "id": sq.id,
                        "text": text,
                        "category": category,
                        "exec_tag": sq.exec_tag,
                    })
                t_route += (time.perf_counter() - t0) * 1000

                # Execute all in this stage (parallel if stage has multiple)
                t0 = time.perf_counter()
                is_parallel_stage = len(stage) > 1
                responses = self._pool.call_batch(routed, parallel=is_parallel_stage)
                t_pool += (time.perf_counter() - t0) * 1000

                for resp in responses:
                    all_responses.append(resp)
                    prev_answers[resp.sub_query_id] = resp.answer
                    result.sub_responses.append({
                        "id":       resp.sub_query_id,
                        "text":     resp.sub_query_text,
                        "category": resp.category,
                        "model":    resp.model_used,
                        "answer":   resp.answer,
                        "exec_tag": next(
                            (sq.exec_tag for sq in stage if sq.id == resp.sub_query_id),
                            "PARALLEL"
                        ),
                        "latency_ms": resp.latency_ms,
                        "cost_usd":   resp.cost_usd,
                    })

            latency["router_ms"] = t_route
            latency["pool_ms"]   = t_pool

            # ── Step 6: Aggregate ──────────────────────────────────────────
            t0 = time.perf_counter()
            aggregated = self._aggregator.aggregate(query, all_responses)
            latency["aggregator_ms"] = (time.perf_counter() - t0) * 1000

            result.final_answer  = aggregated.final_answer
            result.total_cost_usd = sum(r["cost_usd"] for r in result.sub_responses) + aggregated.cost_usd

        else:
            # Simple query — skip decomposition, route directly, single LLM call
            t0 = time.perf_counter()
            category = self._route(query)
            latency["router_ms"] = (time.perf_counter() - t0) * 1000

            t0 = time.perf_counter()
            response = self._pool.call("$1", query, category)
            latency["pool_ms"] = (time.perf_counter() - t0) * 1000

            result.routing = [{"id": "$1", "text": query, "category": category, "exec_tag": "PARALLEL"}]
            result.sub_responses = [{
                "id": "$1", "text": query, "category": category,
                "model": response.model_used, "answer": response.answer,
                "exec_tag": "PARALLEL",
                "latency_ms": response.latency_ms, "cost_usd": response.cost_usd,
            }]
            result.final_answer   = response.answer
            result.total_cost_usd = response.cost_usd

        result.total_latency_ms  = (time.perf_counter() - t_total) * 1000
        result.component_latency = latency
        return result

    # ── Internal helpers ──────────────────────────────────────────────────

    def _detect_complexity(self, query: str) -> bool:
        detector = self._get_detector()
        try:
            result = detector.detect(query)
            return bool(result.is_complex)
        except Exception:
            # Fallback: assume complex
            return True

    def _decompose(self, query: str):
        decomposer = self._get_decomposer()
        return decomposer.decompose(query)

    def _route(self, query: str) -> str:
        router = self._get_router()
        try:
            # All routers expose either .route() returning {"category": ...}
            # or .predict() returning a string label directly
            if hasattr(router, "route"):
                result = router.route(query)
                if isinstance(result, dict):
                    return result.get("category", "FACTUAL_KNOWLEDGE")
                return str(result)
            elif hasattr(router, "predict"):
                return str(router.predict(query))
            return "FACTUAL_KNOWLEDGE"
        except Exception:
            return "FACTUAL_KNOWLEDGE"

    def _inject_context(self, sq: PlannedSubQuery, prev_answers: dict[str, str]) -> str:
        """
        For sequential sub-queries, inject the previous answer as context
        so the LLM can use it when answering this sub-query.
        """
        if not sq.depends_on:
            return sq.text
        context_parts = []
        for dep_id in sq.depends_on:
            if dep_id in prev_answers:
                context_parts.append(f"[Context from {dep_id}: {prev_answers[dep_id][:300]}]")
        if context_parts:
            return "\n".join(context_parts) + "\n\n" + sq.text
        return sq.text

    # ── Lazy component initializers ────────────────────────────────────────

    def _get_detector(self):
        if self._detector is None:
            self._detector = _build_detector(self._detector_name)
        return self._detector

    def _get_decomposer(self):
        if self._decomposer is None:
            self._decomposer = _build_decomposer(self._decomposer_name)
        return self._decomposer

    def _get_router(self):
        if self._router is None:
            self._router = _build_router(self._router_approach)
        return self._router


# ── Component builder functions ───────────────────────────────────────────────

def _build_detector(name: str):
    if name == "tfidf_svm":
        from query_decomposition_pipeline.complexity_detector.tfidf_svm_detector import TFIDFSVMDetector
        d = TFIDFSVMDetector()
        d.load("query_decomposition_pipeline/models/tfidf_svm_detector.pkl")
        return d
    elif name == "minilm_svm":
        from query_decomposition_pipeline.complexity_detector.minilm_svm_detector import MiniLMSVMDetector
        d = MiniLMSVMDetector()
        d.load("query_decomposition_pipeline/models/minilm_svm_detector.pkl")
        return d
    elif name == "distilbert":
        from query_decomposition_pipeline.complexity_detector.distilbert_detector import DistilBERTDetector
        d = DistilBERTDetector()
        d.load("query_decomposition_pipeline/models/distilbert_detector")
        return d
    else:
        from query_decomposition_pipeline.complexity_detector.rule_based_detector import RuleBasedDetector
        return RuleBasedDetector()


def _build_decomposer(name: str):
    if name == "llmcompiler":
        from query_decomposition_pipeline.decomposer.llmcompiler_decomposer import LLMCompilerDecomposer
        return LLMCompilerDecomposer()
    elif name == "decor":
        from query_decomposition_pipeline.decomposer.decor_decomposer import DeCoRDecomposer
        return DeCoRDecomposer()
    elif name == "tor_lite":
        from query_decomposition_pipeline.decomposer.tor_lite_decomposer import ToRLiteDecomposer
        return ToRLiteDecomposer()
    elif name == "amr":
        from query_decomposition_pipeline.decomposer.amr_decomposer import AMRDecomposer
        return AMRDecomposer()
    elif name == "unsupervised":
        from query_decomposition_pipeline.decomposer.unsupervised_decomposer import UnsupervisedDecomposer
        return UnsupervisedDecomposer()
    else:
        from query_decomposition_pipeline.decomposer.rule_based_decomposer import RuleBasedDecomposer
        return RuleBasedDecomposer()


def _build_router(approach: str):
    """
    Build the best-performing router for each approach, based on experiments:

    transformer : DeBERTa-v3 fine-tuned — 92.0% F1  (run_20260308_143151)
    rnn         : TextCNN + FastText    — 89.9% F1, 2.5ms latency
    rag         : Hybrid α=0.9, k=5, text-embedding-3-small — 86.1% F1
    llm         : gpt-4o-mini + zero_shot strategy — 86.5% acc, 1535ms
    """
    if approach == "llm":
        # Best: gpt-4o-mini + zero_shot (86.5% acc, 1535ms) — from phase 2 experiments
        from llm_router.router import LLMRouter
        return LLMRouter(model="gpt-4o-mini")
    elif approach == "transformer":
        # Best: DeBERTa-v3, run_20260308_143151/final_model (92.0% F1)
        return _TransformerRouterWrapper()
    elif approach == "rag":
        # Best: hybrid α=0.9, k=5, threshold=0.5, text-embedding-3-small (86.1% F1)
        from rag_router.router import RAGRouter
        return RAGRouter()
    elif approach == "rnn":
        # Best: TextCNN + FastText (89.9% F1, 2.5ms) — faster and more accurate than BiLSTM
        return _TextCNNRouterWrapper()
    else:
        raise ValueError(f"Unknown router approach: {approach}")


class _TransformerRouterWrapper:
    """Wraps the trained DeBERTa-v3 model — best transformer approach (92.0% F1)."""

    def __init__(self):
        self._model = None
        self._tokenizer = None
        self._label_map = None

    def _load(self):
        import os, json, torch
        from pathlib import Path
        from transformers import AutoModelForSequenceClassification, AutoTokenizer

        # Find best available final_model directory (sorted by run date, newest first)
        root = Path("transformer_based/models")
        model_dir = None
        if root.exists():
            # Prefer run_YYYYMMDD_*/final_model — newest run first
            run_finals = sorted(root.glob("run_*/final_model"), reverse=True)
            if run_finals:
                model_dir = str(run_finals[0])
            else:
                # Fall back to any dir containing model.safetensors or pytorch_model.bin
                for d in sorted(root.rglob("final_model"), reverse=True):
                    if (d / "model.safetensors").exists() or (d / "pytorch_model.bin").exists():
                        model_dir = str(d)
                        break

        if not model_dir:
            raise FileNotFoundError("No trained transformer model found in transformer_based/models/")

        self._tokenizer = AutoTokenizer.from_pretrained(model_dir)
        self._model = AutoModelForSequenceClassification.from_pretrained(model_dir)
        self._model.eval()

        # Load label map — supports nested {"id_to_label": {...}} or flat {"0": "CODE"...}
        label_file = Path(model_dir) / "label_map.json"
        if label_file.exists():
            with open(label_file) as f:
                data = json.load(f)
            # Handle nested format: {"id_to_label": {"0": "CODE", ...}, ...}
            if "id_to_label" in data:
                self._label_map = {int(k): v for k, v in data["id_to_label"].items()}
            elif all(isinstance(k, str) and k.isdigit() for k in data):
                self._label_map = {int(k): v for k, v in data.items()}
            else:
                # label → id format, invert it
                self._label_map = {int(v): k for k, v in data.items()}
        else:
            from llm_router.config.settings import VALID_CATEGORIES
            self._label_map = {i: c for i, c in enumerate(VALID_CATEGORIES)}

    def route(self, query: str) -> dict:
        return {"category": self.predict(query)}

    def predict(self, query: str) -> str:
        import torch
        if self._model is None:
            self._load()
        inputs = self._tokenizer(
            query, return_tensors="pt", truncation=True, max_length=256
        )
        with torch.no_grad():
            logits = self._model(**inputs).logits
        idx = int(torch.argmax(logits, dim=-1).item())
        return self._label_map.get(idx, "FACTUAL_KNOWLEDGE")


class _TextCNNRouterWrapper:
    """Wraps the trained TextCNN (FastText embeddings) model — best RNN/CNN approach (89.9% F1, 2.5ms)."""

    def __init__(self):
        self._model = None
        self._vocab: dict = {}
        self._label_map: dict = {}
        self._cfg: dict = {}
        self._load()

    def _load(self):
        import json, torch
        from pathlib import Path

        model_dir = Path("bilstm_router/models/textcnn_fasttext")
        if not model_dir.exists():
            raise FileNotFoundError(
                "TextCNN model not found at bilstm_router/models/textcnn_fasttext/. "
                "Run bilstm_router/scripts/train_deep_model.py --arch textcnn first."
            )

        import sys
        sys.path.insert(0, str(Path("bilstm_router").resolve()))
        from models.textcnn import TextCNNClassifier

        with open(model_dir / "training_config.json") as f:
            self._cfg = json.load(f)

        with open(model_dir / "vocab.json") as f:
            raw_vocab = json.load(f)
        # vocab.json may be {"word2idx": {...}} or a flat {word: idx} dict
        self._vocab = raw_vocab.get("word2idx", raw_vocab)

        with open(model_dir / "label_map.json") as f:
            raw = json.load(f)
        if "id_to_label" in raw:
            self._label_map = {int(k): v for k, v in raw["id_to_label"].items()}
        elif all(str(k).isdigit() for k in raw):
            self._label_map = {int(k): v for k, v in raw.items()}
        else:
            self._label_map = {int(v): k for k, v in raw.items()}

        self._model = TextCNNClassifier(
            vocab_size=self._cfg["vocab_size"],
            embedding_dim=self._cfg["embedding_dim"],
            num_filters=self._cfg["num_filters"],
            filter_sizes=tuple(self._cfg["filter_sizes"]),
            num_classes=self._cfg["num_classes"],
            dropout=self._cfg.get("dropout", 0.3),
        )
        checkpoint = torch.load(model_dir / "best_model.pt", map_location="cpu", weights_only=False)
        state = checkpoint.get("model_state_dict", checkpoint)
        self._model.load_state_dict(state)
        self._model.eval()

    def _encode(self, query: str, max_len: int = 64) -> "torch.Tensor":
        import torch
        tokens = query.lower().split()
        unk_id = self._vocab.get("<UNK>", self._vocab.get("<unk>", 1))
        ids = [self._vocab.get(t, unk_id) for t in tokens[:max_len]]
        if len(ids) < max_len:
            ids += [0] * (max_len - len(ids))
        return torch.tensor([ids], dtype=torch.long)

    def route(self, query: str) -> dict:
        return {"category": self.predict(query)}

    def predict(self, query: str) -> str:
        import torch
        input_ids = self._encode(query)
        with torch.no_grad():
            logits = self._model(input_ids)
        idx = int(torch.argmax(logits, dim=-1).item())
        return self._label_map.get(idx, "FACTUAL_KNOWLEDGE")
