"""
Fine-Tuned DistilBERT Binary Complexity Detector
=================================================
Fine-tunes DistilBERT-base-uncased as a binary sequence classifier
(0=simple, 1=complex) on the training split of the dataset.

Academic basis:
    Sanh et al. (2019). "DistilBERT, a distilled version of BERT: smaller,
    faster, cheaper and lighter." NeurIPS EMC² Workshop 2019.
    arXiv:1910.01108.
    → DistilBERT retains 97% of BERT's language understanding at 40% fewer
      parameters and 60% faster inference.

    Devlin et al. (2019). "BERT: Pre-training of Deep Bidirectional
    Transformers for Language Understanding." NAACL 2019. arXiv:1810.04805.
    → Original BERT architecture; DistilBERT is a distilled variant.

    Sun et al. (2019). "How to Fine-Tune BERT for Text Classification?"
    CCL 2019. arXiv:1905.05583.
    → Best practices for BERT fine-tuning: 2-4 epochs, lr=2e-5, max_len=128.

Model: distilbert-base-uncased (66M params, 6 layers, 768 hidden dim)
Task : Binary sequence classification (simple=0, complex=1)
Used in: Experiment 1 only (reference upper-bound for fine-tuned transformers)
Latency: ~20–35ms | Cost: $0 after training | Requires: GPU recommended
"""

import pickle
import time
from pathlib import Path

import numpy as np
from .base import ComplexityResult


class DistilBERTDetector:
    """
    Fine-tuned DistilBERT binary complexity classifier.
    Must be trained via .train(queries, labels) before use.

    Follows Sun et al. (2019) fine-tuning recipe:
      - lr=2e-5, epochs=3, max_length=128, batch_size=16
    """

    MODEL_NAME = "distilbert-base-uncased"
    MAX_LENGTH = 128
    BATCH_SIZE = 16
    LEARNING_RATE = 2e-5
    NUM_EPOCHS = 3

    def __init__(self, model_path: str = None, device: str = None):
        self._model = None
        self._tokenizer = None
        self._trained = False
        self._device = device  # None = auto-detect

        if model_path and Path(model_path).exists():
            self.load(model_path)

    def _get_device(self):
        import torch
        if self._device:
            return torch.device(self._device)
        if torch.cuda.is_available():
            return torch.device("cuda")
        if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
            return torch.device("mps")
        return torch.device("cpu")

    def train(self, queries: list[str], labels: list[int]):
        """
        Fine-tune DistilBERT on binary complexity classification.

        Args:
            queries : list of raw query strings
            labels  : binary list — 0=simple, 1=complex
        """
        import torch
        from torch.utils.data import Dataset, DataLoader
        from transformers import (
            DistilBertTokenizerFast,
            DistilBertForSequenceClassification,
            get_linear_schedule_with_warmup,
        )
        from torch.optim import AdamW

        device = self._get_device()
        print(f"[DistilBERT] Device: {device}")
        print(f"[DistilBERT] Loading {self.MODEL_NAME}...")

        self._tokenizer = DistilBertTokenizerFast.from_pretrained(self.MODEL_NAME)
        self._model = DistilBertForSequenceClassification.from_pretrained(
            self.MODEL_NAME, num_labels=2
        ).to(device)

        class QueryDataset(Dataset):
            def __init__(self, queries, labels, tokenizer, max_length):
                enc = tokenizer(
                    queries,
                    padding=True,
                    truncation=True,
                    max_length=max_length,
                    return_tensors="pt",
                )
                self.input_ids = enc["input_ids"]
                self.attention_mask = enc["attention_mask"]
                self.labels = torch.tensor(labels, dtype=torch.long)

            def __len__(self):
                return len(self.labels)

            def __getitem__(self, idx):
                return {
                    "input_ids": self.input_ids[idx],
                    "attention_mask": self.attention_mask[idx],
                    "labels": self.labels[idx],
                }

        dataset = QueryDataset(queries, labels, self._tokenizer, self.MAX_LENGTH)
        loader = DataLoader(dataset, batch_size=self.BATCH_SIZE, shuffle=True)

        optimizer = AdamW(self._model.parameters(), lr=self.LEARNING_RATE, weight_decay=0.01)
        total_steps = len(loader) * self.NUM_EPOCHS
        scheduler = get_linear_schedule_with_warmup(
            optimizer,
            num_warmup_steps=int(0.1 * total_steps),
            num_training_steps=total_steps,
        )

        print(f"[DistilBERT] Training {len(queries)} samples for {self.NUM_EPOCHS} epochs...")
        self._model.train()
        for epoch in range(self.NUM_EPOCHS):
            total_loss = 0.0
            for batch in loader:
                batch = {k: v.to(device) for k, v in batch.items()}
                outputs = self._model(**batch)
                loss = outputs.loss
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self._model.parameters(), 1.0)
                optimizer.step()
                scheduler.step()
                optimizer.zero_grad()
                total_loss += loss.item()
            avg_loss = total_loss / len(loader)
            print(f"[DistilBERT] Epoch {epoch+1}/{self.NUM_EPOCHS}  loss={avg_loss:.4f}")

        self._model.eval()
        self._trained = True
        self._device_obj = device
        print("[DistilBERT] Training complete.")

    def _encode_batch(self, queries: list[str]):
        import torch
        enc = self._tokenizer(
            queries,
            padding=True,
            truncation=True,
            max_length=self.MAX_LENGTH,
            return_tensors="pt",
        )
        return {k: v.to(self._device_obj) for k, v in enc.items()}

    def detect(self, query: str) -> ComplexityResult:
        if not self._trained:
            raise RuntimeError("DistilBERTDetector must be trained before use.")
        import torch
        t0 = time.perf_counter()
        self._model.eval()
        with torch.no_grad():
            enc = self._encode_batch([query])
            logits = self._model(**enc).logits
            proba = torch.softmax(logits, dim=-1).cpu().numpy()[0]
            pred = int(np.argmax(proba))

        return ComplexityResult(
            is_complex=bool(pred == 1),
            confidence=float(max(proba)),
            method="distilbert",
            latency_ms=(time.perf_counter() - t0) * 1000,
            details={
                "prob_simple": round(float(proba[0]), 4),
                "prob_complex": round(float(proba[1]), 4),
            },
        )

    def predict_batch(self, queries: list[str]) -> list[int]:
        import torch
        self._model.eval()
        all_preds = []
        for i in range(0, len(queries), self.BATCH_SIZE * 4):
            batch_q = queries[i: i + self.BATCH_SIZE * 4]
            with torch.no_grad():
                enc = self._encode_batch(batch_q)
                logits = self._model(**enc).logits
                preds = torch.argmax(logits, dim=-1).cpu().numpy().tolist()
            all_preds.extend(preds)
        return all_preds

    def predict_proba_batch(self, queries: list[str]) -> np.ndarray:
        import torch
        self._model.eval()
        all_probas = []
        for i in range(0, len(queries), self.BATCH_SIZE * 4):
            batch_q = queries[i: i + self.BATCH_SIZE * 4]
            with torch.no_grad():
                enc = self._encode_batch(batch_q)
                logits = self._model(**enc).logits
                probas = torch.softmax(logits, dim=-1).cpu().numpy()
            all_probas.append(probas)
        return np.vstack(all_probas)

    def save(self, path: str):
        """Save model and tokenizer to directory."""
        import torch
        save_dir = Path(path)
        save_dir.mkdir(parents=True, exist_ok=True)
        self._model.save_pretrained(save_dir)
        self._tokenizer.save_pretrained(save_dir)
        print(f"[DistilBERT] Saved to {save_dir}")

    def load(self, path: str):
        """Load fine-tuned model from directory."""
        import torch
        from transformers import DistilBertTokenizerFast, DistilBertForSequenceClassification
        save_dir = Path(path)
        self._tokenizer = DistilBertTokenizerFast.from_pretrained(str(save_dir))
        self._model = DistilBertForSequenceClassification.from_pretrained(str(save_dir))
        device = self._get_device()
        self._model = self._model.to(device)
        self._model.eval()
        self._device_obj = device
        self._trained = True
        print(f"[DistilBERT] Loaded from {save_dir}  (device={device})")

    def name(self) -> str:
        return "distilbert"
