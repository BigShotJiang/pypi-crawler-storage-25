"""
MiniLM Sentence Embeddings + LinearSVC Complexity Detector
===========================================================
Encodes queries into dense semantic vectors using MiniLM, then
classifies simple vs complex with a calibrated LinearSVC.

Academic basis:
    Wang et al. (2020). "MiniLM: Deep Self-Attention Distillation for
    Task-Agnostic Compression of Pre-Trained Transformers."
    NeurIPS 2020. arXiv:2002.10957.
    → MiniLM-L6 achieves 99.1% of BERT performance at 15% of the size.

    Reimers & Gurevych (2019). "Sentence-BERT: Sentence Embeddings using
    Siamese BERT-Networks." EMNLP 2019. arXiv:1908.10084.
    → Establishes sentence-level embeddings for classification tasks.

    Bansal & Agarwal (2026). RAGRouter-Bench. arXiv:2604.03455.
    → MiniLM+SVM achieves 90.3% accuracy at ~10ms — second-best lightweight.

Model: all-MiniLM-L6-v2 (22M params, 384-dim embeddings)
Used in: Config B (Balanced)
Latency: ~10ms | Cost: $0 | Requires: labeled training data
"""

import pickle
import time
from pathlib import Path

import numpy as np
from sklearn.svm import LinearSVC
from sklearn.calibration import CalibratedClassifierCV

from .base import ComplexityResult


class MiniLMSVMDetector:
    """
    MiniLM sentence embeddings + calibrated LinearSVC.
    Must be trained via .train(queries, labels) before use.
    """

    MODEL_NAME = "all-MiniLM-L6-v2"

    def __init__(self, model_path: str = None):
        self._encoder = None
        self._svm = None
        self._trained = False

        if model_path and Path(model_path).exists():
            self.load(model_path)

    def _get_encoder(self):
        if self._encoder is None:
            from sentence_transformers import SentenceTransformer
            self._encoder = SentenceTransformer(self.MODEL_NAME)
        return self._encoder

    def _encode(self, queries: list[str]) -> np.ndarray:
        encoder = self._get_encoder()
        return encoder.encode(queries, batch_size=64,
                              show_progress_bar=False, normalize_embeddings=True)

    def train(self, queries: list[str], labels: list[int]):
        """
        Encode queries with MiniLM then fit calibrated LinearSVC.

        Args:
            queries : list of raw query strings
            labels  : binary list — 0=simple, 1=complex
        """
        print(f"[MiniLMSVM] Encoding {len(queries)} queries with {self.MODEL_NAME}...")
        X = self._encode(queries)

        base_svm = LinearSVC(C=1.0, max_iter=5000, dual=True)
        self._svm = CalibratedClassifierCV(base_svm, cv=3, method="sigmoid")
        self._svm.fit(X, labels)
        self._trained = True
        print(f"[MiniLMSVM] Training complete.")

    def detect(self, query: str) -> ComplexityResult:
        if not self._trained:
            raise RuntimeError("MiniLMSVMDetector must be trained before use.")
        t0 = time.perf_counter()
        X = self._encode([query])
        pred = self._svm.predict(X)[0]
        proba = self._svm.predict_proba(X)[0]

        return ComplexityResult(
            is_complex=bool(pred == 1),
            confidence=float(max(proba)),
            method="minilm_svm",
            latency_ms=(time.perf_counter() - t0) * 1000,
            details={"prob_simple": round(float(proba[0]), 4),
                     "prob_complex": round(float(proba[1]), 4)},
        )

    def predict_batch(self, queries: list[str]) -> list[int]:
        X = self._encode(queries)
        return list(self._svm.predict(X))

    def predict_proba_batch(self, queries: list[str]) -> np.ndarray:
        X = self._encode(queries)
        return self._svm.predict_proba(X)

    def save(self, path: str):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with open(path, "wb") as f:
            pickle.dump({"svm": self._svm, "model_name": self.MODEL_NAME}, f)

    def load(self, path: str):
        with open(path, "rb") as f:
            obj = pickle.load(f)
        self._svm = obj["svm"]
        self.MODEL_NAME = obj.get("model_name", self.MODEL_NAME)
        self._trained = True

    def name(self) -> str:
        return "minilm_svm"
