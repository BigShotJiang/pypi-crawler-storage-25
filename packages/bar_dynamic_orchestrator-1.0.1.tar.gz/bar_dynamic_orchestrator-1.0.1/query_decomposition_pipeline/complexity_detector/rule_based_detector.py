"""
Rule-Based Structural Complexity Detector
==========================================
Detects query complexity using hand-crafted linguistic signal patterns.
Zero training data required, sub-millisecond inference, zero cost.

Academic basis:
    Wolfson et al. (2020). "Break It Down: A Question Understanding Benchmark."
    TACL 2020. https://doi.org/10.1162/tacl_a_00306
    → Structural/syntactic features identify decomposable queries (>80% F1).

    Carmona et al. (2020). "Intent Segmentation of User Queries via
    Discourse Parsing." IWDP @ ACL 2020. ACL Anthology: 2020.iwdp-1.7.
    → Connective-based segmentation for multi-intent detection.

Used in: Config D (Latency-First)
Latency: <0.1ms | Cost: $0 | Training data: none required
"""

import re
import time
from .base import ComplexityResult

# ── Signal definitions ────────────────────────────────────────────────────────

_COMPLEXITY_SIGNALS = [
    # Sequential connectives
    (r'\b(then|after that|after which|subsequently|next step|finally)\b',       3),
    # Comparison signals
    (r'\b(compare|versus|vs\.?|difference between|contrast|which is better)\b', 3),
    # Conditional multi-aspect
    (r'\b(if .{5,40}(how|what|should|would|could))\b',                          2),
    # Multi-predicate (comma-verb list)
    (r'[^,]{5,},\s+[^,]{5,},\s+(and\s+)?\S',                                   2),
    # Parallel connectives
    (r'\b(and also|as well as|simultaneously|in parallel|both .{3,30} and)\b',  2),
    # Multi-step instruction
    (r'\b(step by step|step \d|first .{3,30} then|how do i .{3,30} and)\b',    2),
    # Aggregation
    (r'\b(summarize and|list all|for each|find all .{3,30} and)\b',             2),
]

_SIMPLE_SIGNALS = [
    # Direct factual questions
    (r'^(what is|who is|when is|where is|how much|how many|define )\b',         3),
    (r'^(what does|what are|is there|can you tell me|what was|who was)\b',       2),
    # Single-topic balanced-view (tricky negatives — NOT decomposable)
    (r'\b(pros and cons|advantages and disadvantages|benefits and (risks|drawbacks))\b', 4),
    (r'\b(strengths and weaknesses|positive and negative effects?)\b',           4),
    # Conversational
    (r'^(hello|hi |hey |thanks|thank you|good morning)',                         3),
]

_THRESHOLD = 2   # score >= threshold → COMPLEX


class RuleBasedDetector:
    """
    Structural signal counting detector.
    Scores each query by summing weighted complexity and simplicity signals.
    """

    def detect(self, query: str) -> ComplexityResult:
        t0 = time.perf_counter()
        q = query.lower().strip()

        complexity_score = 0
        simple_score = 0
        fired_complexity = []
        fired_simple = []

        for pattern, weight in _COMPLEXITY_SIGNALS:
            if re.search(pattern, q, re.IGNORECASE):
                complexity_score += weight
                fired_complexity.append(pattern[:30])

        for pattern, weight in _SIMPLE_SIGNALS:
            if re.search(pattern, q, re.IGNORECASE):
                simple_score += weight
                fired_simple.append(pattern[:30])

        # Length boost: queries >20 words are likely compound
        word_count = len(query.split())
        if word_count > 20:
            complexity_score += 1

        net_score = complexity_score - simple_score
        is_complex = net_score >= _THRESHOLD

        # Confidence: distance from threshold normalised to [0.5, 1.0]
        distance = abs(net_score - _THRESHOLD)
        confidence = min(0.5 + distance * 0.1, 1.0)

        return ComplexityResult(
            is_complex=is_complex,
            confidence=confidence,
            method="rule_based",
            latency_ms=(time.perf_counter() - t0) * 1000,
            details={
                "net_score": net_score,
                "complexity_score": complexity_score,
                "simple_score": simple_score,
                "word_count": word_count,
                "fired_complexity": fired_complexity,
                "fired_simple": fired_simple,
            },
        )

    def name(self) -> str:
        return "rule_based"
