"""
LLM-Based Complexity Detector (GPT-4o-mini)
============================================
Uses a single GPT-4o-mini call with a structured prompt to classify
queries as simple or complex. Serves as the upper-bound reference.

Academic basis:
    Bansal & Agarwal (2026). RAGRouter-Bench. arXiv:2604.03455.
    → GPT-4o-mini achieves ~79% accuracy at 2,510ms and $0.000027/query —
      worse than TF-IDF+SVM on this task.

    OpenAI (2024). GPT-4o-mini technical report.
    → Used as the reference LLM baseline.

Note: This detector exists as an academic reference point to demonstrate
the counter-intuitive finding that lightweight statistical methods
outperform large LLMs on binary complexity classification.

Used in: Evaluation only (not assigned to any config)
Latency: ~2–3s | Cost: ~$0.000027/query
"""

import os
import time
from .base import ComplexityResult

_PROMPT = """You are a query complexity classifier. Your task is to decide if a user query is SIMPLE or COMPLEX.

SIMPLE: A query that asks one clear question or requests one piece of information.
Examples:
  - "What is the capital of France?"
  - "What are the pros and cons of remote work?"
  - "Define machine learning."

COMPLEX: A query that contains multiple independent sub-questions or requires multiple sequential steps.
Examples:
  - "Compare PostgreSQL and MongoDB for high-traffic apps."
  - "Parse the CSV, clean the data, and save to a database."
  - "If a startup adopts microservices, how should it plan migration and manage risks?"

Reply with ONLY one word: SIMPLE or COMPLEX."""


class LLMDetector:
    """
    GPT-4o-mini zero-shot complexity classifier.
    Academic reference baseline — not used in production configs.
    """

    def __init__(self, model: str = "gpt-4o-mini"):
        self.model = model
        api_key = os.environ.get("OPENAI_API_KEY")
        if not api_key:
            raise RuntimeError("OPENAI_API_KEY not set.")
        from openai import OpenAI
        self._client = OpenAI(api_key=api_key)

    def detect(self, query: str) -> ComplexityResult:
        t0 = time.perf_counter()
        try:
            response = self._client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": _PROMPT},
                    {"role": "user", "content": f'Query: "{query}"'},
                ],
                temperature=0.0,
                max_tokens=5,
            )
            answer = response.choices[0].message.content.strip().upper()
            is_complex = "COMPLEX" in answer

            # Estimate cost
            usage = response.usage
            cost = (usage.prompt_tokens * 0.15 + usage.completion_tokens * 0.60) / 1_000_000

        except Exception as e:
            is_complex = False
            cost = 0.0
            answer = f"ERROR: {e}"

        return ComplexityResult(
            is_complex=is_complex,
            confidence=0.85 if is_complex else 0.85,
            method=f"llm_{self.model}",
            latency_ms=(time.perf_counter() - t0) * 1000,
            details={"response": answer, "cost_usd": cost},
        )

    def predict_batch(self, queries: list[str]) -> list[int]:
        return [int(self.detect(q).is_complex) for q in queries]

    def name(self) -> str:
        return f"llm_{self.model}"
