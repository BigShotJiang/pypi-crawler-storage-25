"""
TF-IDF + LinearSVC Complexity Detector
=======================================
Trains a LinearSVC on TF-IDF features extracted from labeled queries.
State-of-the-art lightweight complexity detector per RAGRouter-Bench.

Academic basis:
    Joachims, T. (1998). "Text Categorization with Support Vector Machines:
    Learning with Many Relevant Features." ECML 1998.
    → Foundational paper establishing TF-IDF+SVM for binary text classification.

    Bansal & Agarwal (2026). "Lightweight Query Routing for Adaptive RAG:
    A Baseline Study on RAGRouter-Bench." arXiv:2604.03455.
    → TF-IDF+SVM achieves 93.2% accuracy, F1=0.928 at <1ms inference,
      outperforming all LLMs including DeepSeek-V3 (671B) at 83.0%.

Used in: Config A (Accuracy-First)
Latency: <1ms | Cost: $0 | Requires: labeled training data
"""

import pickle
import time
from pathlib import Path

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import LinearSVC
from sklearn.calibration import CalibratedClassifierCV

from .base import ComplexityResult


class TFIDFSVMDetector:
    """
    TF-IDF + LinearSVC detector.
    Must be trained before use via .train(queries, labels).
    """

    def __init__(self, model_path: str = None):
        self._vectorizer: TfidfVectorizer = None
        self._svm = None
        self._trained = False

        if model_path and Path(model_path).exists():
            self.load(model_path)

    def train(self, queries: list[str], labels: list[int]):
        """
        Fit TF-IDF vectoriser and calibrated LinearSVC.

        Args:
            queries : list of raw query strings
            labels  : binary list — 0=simple, 1=complex
        """
        self._vectorizer = TfidfVectorizer(
            ngram_range=(1, 3),      # unigrams, bigrams, trigrams
            max_features=30000,
            sublinear_tf=True,       # log(1 + tf) normalisation
            strip_accents="unicode",
            analyzer="word",
            min_df=1,
        )
        X = self._vectorizer.fit_transform(queries)

        # CalibratedClassifierCV wraps LinearSVC to produce probabilities
        base_svm = LinearSVC(C=1.0, max_iter=5000, dual=True)
        self._svm = CalibratedClassifierCV(base_svm, cv=3, method="sigmoid")
        self._svm.fit(X, labels)
        self._trained = True

    def detect(self, query: str) -> ComplexityResult:
        if not self._trained:
            raise RuntimeError("TFIDFSVMDetector must be trained before calling detect(). "
                               "Call .train(queries, labels) first.")
        t0 = time.perf_counter()
        X = self._vectorizer.transform([query])
        pred = self._svm.predict(X)[0]
        proba = self._svm.predict_proba(X)[0]
        confidence = float(max(proba))

        return ComplexityResult(
            is_complex=bool(pred == 1),
            confidence=confidence,
            method="tfidf_svm",
            latency_ms=(time.perf_counter() - t0) * 1000,
            details={"prob_simple": round(float(proba[0]), 4),
                     "prob_complex": round(float(proba[1]), 4)},
        )

    def predict_batch(self, queries: list[str]) -> list[int]:
        X = self._vectorizer.transform(queries)
        return list(self._svm.predict(X))

    def predict_proba_batch(self, queries: list[str]) -> np.ndarray:
        X = self._vectorizer.transform(queries)
        return self._svm.predict_proba(X)

    def save(self, path: str):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with open(path, "wb") as f:
            pickle.dump({"vectorizer": self._vectorizer, "svm": self._svm}, f)

    def load(self, path: str):
        with open(path, "rb") as f:
            obj = pickle.load(f)
        self._vectorizer = obj["vectorizer"]
        self._svm = obj["svm"]
        self._trained = True

    def name(self) -> str:
        return "tfidf_svm"
