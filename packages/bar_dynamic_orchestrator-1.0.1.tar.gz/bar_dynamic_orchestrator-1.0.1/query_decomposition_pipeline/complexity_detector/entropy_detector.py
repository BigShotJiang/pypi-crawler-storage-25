"""
Entropy-Based Complexity Detector
====================================
Detects query complexity using linguistic entropy — a measure of how
spread the information content is across multiple topics or predicates.

Academic basis:
    Shannon, C.E. (1948). A Mathematical Theory of Communication.
    Bell System Technical Journal, 27(3), 379-423.

    Kadavath et al. (2022). Language Models (Mostly) Know What They Know.
    arXiv:2207.05221.

    Jeong et al. (2024). Adaptive-RAG: Learning to Adapt Retrieval-
    Augmented Large Language Models through Question Complexity.
    NAACL 2024. arXiv:2403.14403.

Logic:
    Computes a probability distribution over linguistic complexity signals
    (connectives, predicates, comparisons, conditionals, etc.) and measures
    the Shannon entropy of that distribution.

    - Simple query  → few/no signals → low entropy → SIMPLE
    - Complex query → multiple signal types active → high entropy → COMPLEX

    H = -Σ p_i · log(p_i)
    H_norm = H / log(N)   where N = number of signal types

Used in: Config A (Accuracy-First)
"""

import re
import time
import numpy as np
from .base import BaseComplexityDetector, ComplexityResult

# Linguistic signals that indicate complexity — each is a separate dimension
# for entropy computation
_SIGNALS = {
    "sequential_connective": re.compile(
        r"\b(then|after that|next|finally|subsequently|once you|before)\b", re.I
    ),
    "parallel_connective": re.compile(
        r"\b(and also|both|as well as|simultaneously|at the same time|in parallel)\b", re.I
    ),
    "comparison": re.compile(
        r"\b(compare|versus|vs\.?|difference between|contrast|which is better)\b", re.I
    ),
    "conditional": re.compile(
        r"\b(if|given that|assuming|in case|when|provided that)\b", re.I
    ),
    "multi_predicate": re.compile(
        r"\b(explain .{3,30} and (suggest|provide|give|list)|"
        r"write .{3,30} (then|and) explain|"
        r"calculate .{3,30} and (show|display|format))\b", re.I
    ),
    "enumeration": re.compile(
        r"(first[,\s].*second[,\s]|step \d.*step \d|\d\).*\d\))", re.I
    ),
    "comma_verb_list": re.compile(r'[^,]+,\s+[^,]+,\s+(and\s+)?\S'),  # "parse X, clean Y, and save Z"
    "long_query": re.compile(r"(?=[\s\S]{80,})"),   # query length > 80 chars
}

N_SIGNALS = len(_SIGNALS)
MAX_ENTROPY = np.log(N_SIGNALS)   # maximum possible entropy


class EntropyDetector(BaseComplexityDetector):
    """
    Computes Shannon entropy over linguistic complexity signals.
    High entropy across multiple signal types → complex query.

    Threshold (default 0.35): calibrated on business_benchmark_50.jsonl
    via Youden's J statistic. Lower threshold = more sensitive to complexity.
    """

    def __init__(self, threshold: float = 0.35):
        self.threshold = threshold

    def detect(self, query: str, classifier_scores: dict = None) -> ComplexityResult:
        t0 = time.perf_counter()

        # Compute signal activations (0 or 1 per signal type)
        activations = {
            name: 1.0 if pattern.search(query) else 0.0
            for name, pattern in _SIGNALS.items()
        }

        active_signals = [name for name, v in activations.items() if v > 0]
        n_active = len(active_signals)

        if n_active == 0:
            # No signals → definitely simple
            result = ComplexityResult(
                is_complex=False,
                confidence=0.90,
                method="entropy",
                details={"entropy": 0.0, "normalized_entropy": 0.0,
                         "active_signals": [], "threshold": self.threshold},
            )
        else:
            # Build uniform distribution over active signals
            probs = np.array([v for v in activations.values()], dtype=float)
            probs = np.clip(probs, 1e-10, None)
            probs /= probs.sum()

            entropy = float(-np.sum(probs * np.log(probs)))
            norm_entropy = entropy / MAX_ENTROPY if MAX_ENTROPY > 0 else 0.0

            # Strong single signals are sufficient on their own
            strong_signals = {"comparison", "sequential_connective", "multi_predicate", "enumeration", "comma_verb_list"}
            has_strong = bool(set(active_signals) & strong_signals)
            is_complex = (norm_entropy > self.threshold) or (n_active >= 2) or has_strong
            distance = abs(norm_entropy - self.threshold)
            confidence = min(0.5 + distance, 1.0)

            result = ComplexityResult(
                is_complex=is_complex,
                confidence=float(confidence),
                method="entropy",
                details={
                    "entropy": round(entropy, 4),
                    "normalized_entropy": round(norm_entropy, 4),
                    "threshold": self.threshold,
                    "active_signals": active_signals,
                    "n_active": n_active,
                },
            )

        result.latency_ms = (time.perf_counter() - t0) * 1000
        return result

    def name(self) -> str:
        return "entropy"
