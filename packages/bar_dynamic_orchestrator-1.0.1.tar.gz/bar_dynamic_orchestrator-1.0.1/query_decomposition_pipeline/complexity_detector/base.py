"""Base classes for complexity detectors."""

from dataclasses import dataclass, field


@dataclass
class ComplexityResult:
    is_complex: bool
    confidence: float
    method: str
    latency_ms: float = 0.0
    details: dict = field(default_factory=dict)

    def __repr__(self):
        label = "COMPLEX" if self.is_complex else "SIMPLE"
        return (f"ComplexityResult({label}, conf={self.confidence:.3f}, "
                f"method={self.method}, latency={self.latency_ms:.2f}ms)")
