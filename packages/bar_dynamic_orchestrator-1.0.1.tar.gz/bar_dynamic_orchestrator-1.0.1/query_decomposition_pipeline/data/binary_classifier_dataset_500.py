import json
import time
import os
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
OUTPUT_FILE = "binary_dataset_1000.jsonl"

# Full 11 categories for maximum domain diversity
CATEGORIES = [
    "FACTUAL_KNOWLEDGE",
    "REASONING",
    "MEDICAL",
    "LEGAL",
    "FINANCE",
    "CODE",
    "CREATIVE_WRITING",
    "INSTRUCTION_FOLLOWING",
    "CONVERSATIONAL",
    "MULTILINGUAL",
    "SUMMARIZATION",
]


def generate_batch(is_complex, category, count):
    label_text = (
        "COMPLEX (multi-step logic)" if is_complex else "SIMPLE (direct lookup)"
    )

    prompt = f"""
    Generate {count} unique user queries for an AI benchmark.
    CATEGORY: {category}
    TARGET LABEL: {int(is_complex)} ({label_text})

    CRITERIA:
    - If COMPLEX (1): Must require at least 2 distinct steps (e.g., "Who is the president of the country where the Eiffel Tower is?").
    - If SIMPLE (0): Must be a single direct question (e.g., "What is the capital of France?").
    - Do NOT use the same examples repeatedly. Ensure professional and diverse phrasing.

    OUTPUT JSON FORMAT:
    {{
        "data": [
            {{ "query": "string", "is_complex": {int(is_complex)}, "category": "{category}" }}
        ]
    }}
    """

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",  # Cost-efficient and precise for structured data
            messages=[{"role": "user", "content": prompt}],
            response_format={"type": "json_object"},
            temperature=0.8,  # Higher temperature for better diversity
        )
        return json.loads(response.choices[0].message.content).get("data", [])
    except Exception as e:
        print(f"Error: {e}")
        return []


def main():
    total_needed = 1000
    queries_per_class = 500
    batch_size = 25  # Optimal for gpt-4o-mini structured output

    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        for is_complex in [True, False]:
            count_generated = 0
            while count_generated < queries_per_class:
                # Rotate through categories to ensure balance
                category = CATEGORIES[count_generated % len(CATEGORIES)]
                print(
                    f"Baking {category} | Complex: {is_complex} ({count_generated}/{queries_per_class})"
                )

                batch = generate_batch(is_complex, category, batch_size)
                for item in batch:
                    f.write(json.dumps(item) + "\n")
                    count_generated += 1

                time.sleep(0.5)  # Slight delay for API stability

    print(f"Dataset complete: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
