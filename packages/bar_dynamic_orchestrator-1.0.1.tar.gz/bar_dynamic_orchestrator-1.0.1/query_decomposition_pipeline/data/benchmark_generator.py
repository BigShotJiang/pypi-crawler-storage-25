import json
import time
import os
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()  # Load environment variables from .env file

# 1. Configuration
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
OUTPUT_FILE = "golden_thesis_dataset_1000.jsonl"

# 2. Strict Category Definitions (From image_793cf8.png)
# This prevents the AI from mislabeling "Simple Facts" as "Reasoning"
CATEGORY_RULES = {
    "FACTUAL_KNOWLEDGE": "Direct 'what/who/when' facts. No logical steps required.",
    "REASONING": "Requires a logical leap, math, or if-then deduction. NEVER for simple facts.",
    "MEDICAL": "Queries about anatomy, symptoms, and clinical interactions.",
    "LEGAL": "Queries about statutes, contracts, and regulatory compliance.",
    "FINANCE": "Financial math, market data, and investment analysis.",
    "CODE": "Programming logic, debugging, and API integration.",
    "CREATIVE_WRITING": "Content generation, marketing copy, and storytelling.",
    "INSTRUCTION_FOLLOWING": "Formatting requests and procedural step-by-step guidance.",
    "CONVERSATIONAL": "Social chat, greetings, and simple acknowledgments.",
    "MULTILINGUAL": "Translation or non-English retrieval tasks.",
    "SUMMARIZATION": "Information condensation and overview generation.",
}

# 3. Structural Benchmarks (Logic Patterns)
LOGIC_TYPES = {
    "Type 1: Simple": {"desc": "Zero dependencies. Single fact lookup.", "deps": [[]]},
    "Type 2: Sequential": {
        "desc": "Multi-hop. Step B needs Step A's output.",
        "deps": [[], [0]],
    },
    "Type 3: Comparison": {
        "desc": "Parallel. Get Fact X and Fact Y, then compare.",
        "deps": [[], [], [0, 1]],
    },
    "Type 4: Aggregation": {
        "desc": "Set-based. List items then count/sum them.",
        "deps": [[], [0]],
    },
}


def generate_golden_batch(category, complexity_name, count):
    rule = CATEGORY_RULES[category]
    logic = LOGIC_TYPES[complexity_name]

    prompt = f"""
    Act as a Senior Research Lead. Generate {count} queries for a Golden Benchmark.
    
    CATEGORY: {category}
    STRICT RULE: {rule}
    LOGIC TYPE: {complexity_name}
    LOGIC PATTERN: {logic['desc']}

    INSTRUCTIONS:
    1. If the category is REASONING, the query MUST be a puzzle or logic problem.
    2. If the category is FACTUAL_KNOWLEDGE, it must be a single direct question.
    3. The 'decomposition' MUST be atomic steps.
    4. The 'dependencies' MUST be: {logic['deps']}

    OUTPUT JSON FORMAT:
    {{
        "queries": [
            {{
                "query": "The professional user query",
                "is_complex": {1 if "Simple" not in complexity_name else 0},
                "category": "{category}",
                "complexity_type": "{complexity_name}",
                "decomposition": ["step 1", "step 2"],
                "dependencies": {logic['deps']}
            }}
        ]
    }}
    """

    try:
        response = client.chat.completions.create(
            model="gpt-4o",  # GPT-4o is required for structural adherence
            messages=[
                {"role": "system", "content": "You are a precise data architect."},
                {"role": "user", "content": prompt},
            ],
            response_format={"type": "json_object"},
        )
        return json.loads(response.choices[0].message.content).get("queries", [])
    except Exception as e:
        print(f"Error in {category}: {e}")
        return []


# 4. Main Execution
def build_dataset():
    total_queries = 0
    # 11 categories * 4 logic types = 44 segments.
    # 1000 / 44 = ~23 queries per segment.
    QUERIES_PER_SEGMENT = 23

    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        for cat in CATEGORY_RULES:
            for comp_name in LOGIC_TYPES.keys():
                print(f"Baking {cat} - {comp_name}...")
                batch = generate_golden_batch(cat, comp_name, QUERIES_PER_SEGMENT)

                for item in batch:
                    f.write(json.dumps(item) + "\n")
                    total_queries += 1

                time.sleep(1)  # API Safety

    print(f"Finished! Generated {total_queries} golden queries in {OUTPUT_FILE}")


if __name__ == "__main__":
    build_dataset()
