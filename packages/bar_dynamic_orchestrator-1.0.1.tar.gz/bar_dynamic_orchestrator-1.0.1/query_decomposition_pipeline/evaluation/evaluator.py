"""
Pipeline Evaluator
====================
Evaluates and compares Config A / B / C on a labeled test set.
Produces the comparison table needed for the thesis.

Metrics collected per config:
  - Routing Accuracy     : % of queries routed to correct category
  - Macro F1             : balanced across all 11 categories
  - Complexity Detection : precision, recall, F1 (simple vs complex)
  - Avg Total Latency    : ms per query (end-to-end)
  - Avg Decomp Latency   : ms for Component 2 only
  - Avg Plan Latency     : ms for Component 3 only
  - Avg Cost per Query   : USD
  - Parallel Rate        : % of complex queries that got parallel execution
  - Decomposition Rate   : % of queries flagged as complex
"""

import json
import time
from pathlib import Path
from dataclasses import dataclass, field

from sklearn.metrics import accuracy_score, f1_score, classification_report

from ..config import ConfigName, CONFIGS
from ..pipeline.router_pipeline import RouterPipeline, PipelineOutput


@dataclass
class ConfigMetrics:
    config_name: str
    n_queries: int = 0

    # Routing quality
    routing_accuracy: float = 0.0
    routing_f1_macro: float = 0.0

    # Complexity detection quality (requires complexity ground truth)
    complexity_accuracy: float = 0.0
    complexity_f1: float = 0.0

    # Latency (ms)
    avg_total_latency_ms: float = 0.0
    avg_decomp_latency_ms: float = 0.0
    avg_plan_latency_ms: float = 0.0
    p95_latency_ms: float = 0.0

    # Cost
    avg_cost_usd: float = 0.0
    total_cost_usd: float = 0.0

    # Decomposition stats
    decomposition_rate: float = 0.0   # % flagged complex
    parallel_rate: float = 0.0        # % with any parallel execution
    avg_subqueries: float = 0.0

    def to_dict(self) -> dict:
        return {k: round(v, 6) if isinstance(v, float) else v
                for k, v in self.__dict__.items()}


class PipelineEvaluator:
    """
    Run evaluation across all three configs on a labeled dataset.

    Dataset format (JSONL):
        {"query": "...", "category": "MEDICAL", "is_complex": true}
        {"query": "...", "category": "CODE", "is_complex": false}

    is_complex is optional — if missing, complexity metrics are skipped.
    """

    def __init__(self, router_fn=None, results_dir: str = "results"):
        self.router_fn = router_fn
        self.results_dir = Path(results_dir)
        self.results_dir.mkdir(parents=True, exist_ok=True)

    def evaluate_all(self, dataset_path: str) -> dict[str, ConfigMetrics]:
        """Evaluate Config A, B, C on the dataset. Returns metrics per config."""
        samples = self._load_dataset(dataset_path)
        print(f"[Evaluator] Loaded {len(samples)} samples from {dataset_path}")

        all_metrics = {}
        for config_name in [ConfigName.A, ConfigName.B, ConfigName.C]:
            print(f"\n[Evaluator] ── Evaluating {config_name.value} ──")
            pipeline = RouterPipeline(config_name, router_fn=self.router_fn)
            metrics = self._evaluate_config(pipeline, samples, config_name.value)
            all_metrics[config_name.value] = metrics
            self._save_metrics(metrics)

        self._print_comparison_table(all_metrics)
        return all_metrics

    def evaluate_single(self, config: ConfigName, dataset_path: str) -> ConfigMetrics:
        samples = self._load_dataset(dataset_path)
        pipeline = RouterPipeline(config, router_fn=self.router_fn)
        metrics = self._evaluate_config(pipeline, samples, config.value)
        self._save_metrics(metrics)
        return metrics

    # ── Internal ──────────────────────────────────────────────────────────

    def _evaluate_config(self, pipeline: RouterPipeline,
                         samples: list[dict], config_name: str) -> ConfigMetrics:
        metrics = ConfigMetrics(config_name=config_name, n_queries=len(samples))

        true_categories = []
        pred_categories = []
        true_complex = []
        pred_complex = []
        total_latencies = []
        decomp_latencies = []
        plan_latencies = []
        costs = []
        decomp_rates = []
        parallel_rates = []
        n_subqueries = []

        for i, sample in enumerate(samples):
            query = sample["query"]
            true_cat = sample.get("category", "")
            true_is_complex = sample.get("is_complex", None)

            output: PipelineOutput = pipeline.route(query)

            # Routing quality
            if true_cat:
                true_categories.append(true_cat)
                pred_categories.append(output.final_category)

            # Complexity detection quality
            if true_is_complex is not None:
                true_complex.append(int(true_is_complex))
                pred_complex.append(int(output.complexity.is_complex))

            # Latency
            total_latencies.append(output.total_latency_ms)
            if output.decomposition:
                decomp_latencies.append(output.decomposition.latency_ms)
                plan_latencies.append(
                    output.execution_plan.latency_ms if output.execution_plan else 0.0
                )
                n_subqueries.append(len(output.decomposition.sub_queries))
                decomp_rates.append(1)
            else:
                decomp_rates.append(0)

            # Parallelism
            if output.execution_plan:
                has_parallel = any(
                    len(g.sub_query_ids) > 1
                    for g in output.execution_plan.groups
                )
                parallel_rates.append(int(has_parallel))

            # Cost
            costs.append(output.total_cost_usd)

            if (i + 1) % 10 == 0:
                print(f"  [{config_name}] {i+1}/{len(samples)} done...")

        # Compute metrics
        if true_categories:
            metrics.routing_accuracy = accuracy_score(true_categories, pred_categories)
            metrics.routing_f1_macro = f1_score(
                true_categories, pred_categories, average="macro", zero_division=0
            )

        if true_complex:
            metrics.complexity_accuracy = accuracy_score(true_complex, pred_complex)
            metrics.complexity_f1 = f1_score(
                true_complex, pred_complex, average="macro", zero_division=0
            )

        import numpy as np
        metrics.avg_total_latency_ms = float(np.mean(total_latencies))
        metrics.p95_latency_ms = float(np.percentile(total_latencies, 95))
        metrics.avg_decomp_latency_ms = float(np.mean(decomp_latencies)) if decomp_latencies else 0.0
        metrics.avg_plan_latency_ms = float(np.mean(plan_latencies)) if plan_latencies else 0.0
        metrics.avg_cost_usd = float(np.mean(costs))
        metrics.total_cost_usd = float(np.sum(costs))
        metrics.decomposition_rate = float(np.mean(decomp_rates))
        metrics.parallel_rate = float(np.mean(parallel_rates)) if parallel_rates else 0.0
        metrics.avg_subqueries = float(np.mean(n_subqueries)) if n_subqueries else 0.0

        return metrics

    def _load_dataset(self, path: str) -> list[dict]:
        samples = []
        with open(path) as f:
            for line in f:
                line = line.strip()
                if line:
                    samples.append(json.loads(line))
        return samples

    def _save_metrics(self, metrics: ConfigMetrics):
        path = self.results_dir / f"metrics_{metrics.config_name}.json"
        with open(path, "w") as f:
            json.dump(metrics.to_dict(), f, indent=2)
        print(f"[Evaluator] Saved metrics to {path}")

    def _print_comparison_table(self, all_metrics: dict[str, ConfigMetrics]):
        print("\n" + "=" * 80)
        print("CONFIGURATION COMPARISON TABLE")
        print("=" * 80)
        header = f"{'Metric':<30} {'Config A':>12} {'Config B':>12} {'Config C':>12}"
        print(header)
        print("-" * 80)

        rows = [
            ("Routing Accuracy",      "routing_accuracy",      "{:.1%}"),
            ("Routing F1 (Macro)",    "routing_f1_macro",      "{:.3f}"),
            ("Complexity Accuracy",   "complexity_accuracy",   "{:.1%}"),
            ("Avg Total Latency (ms)","avg_total_latency_ms",  "{:.1f}"),
            ("P95 Latency (ms)",      "p95_latency_ms",        "{:.1f}"),
            ("Avg Decomp Latency (ms)","avg_decomp_latency_ms","{:.1f}"),
            ("Avg Cost/Query ($)",    "avg_cost_usd",          "{:.6f}"),
            ("Decomposition Rate",    "decomposition_rate",    "{:.1%}"),
            ("Parallel Rate",         "parallel_rate",         "{:.1%}"),
            ("Avg Sub-queries",       "avg_subqueries",        "{:.2f}"),
        ]

        configs = ["accuracy_first", "balanced", "latency_first"]
        for label, attr, fmt in rows:
            vals = []
            for cfg in configs:
                m = all_metrics.get(cfg)
                val = getattr(m, attr, 0.0) if m else 0.0
                vals.append(fmt.format(val))
            print(f"{label:<30} {vals[0]:>12} {vals[1]:>12} {vals[2]:>12}")

        print("=" * 80)
        print("\nLegend:")
        print("  Config A = Accuracy-First  (Entropy detector  + LLMCompiler + DAG planner)")
        print("  Config B = Balanced        (TF-IDF+SVM        + LLMCompiler + DAG planner)")
        print("  Config C = Latency-First   (TF-IDF+SVM        + Rule-based  + Rule-based )")
