"""
Query Decomposition Pipeline
=============================
A three-component pipeline for intelligent LLM routing:

  Component 1 — Complexity Detection
      Determines if a query is simple (route directly) or complex (decompose first).
      Two implementations:
        - TF-IDF + SVM  : 93.2% accuracy, <1ms  (Config B, C)
                          Source: Bansal & Agarwal, arXiv:2604.03455, 2026
        - Entropy-based : uses classifier output distribution  (Config A)
                          Source: Shannon (1948); Kadavath et al. (2022)

  Component 2 — Sub-Query Decomposition
      Splits complex queries into atomic sub-queries with dependency metadata.
      Two implementations:
        - LLMCompiler DAG : GPT-4o-mini, DAG with dependency vars (Config A, B)
                            Source: Kim et al., ICML 2024, arXiv:2312.04511
        - Rule-based      : regex + spaCy connective splitting  (Config C)

  Component 3 — Execution Planner
      Determines parallel / sequential / mixed execution order from dependency graph.
      Two implementations:
        - DAG Planner     : topological sort, true parallelism detection (Config A, B)
                            Source: Orion, arXiv:2510.24390, 2025
        - Rule-based      : keyword heuristics, O(1) (Config C)

Configuration Matrix
---------------------
  Config A — Accuracy-First  : Entropy  + LLMCompiler + DAG Planner  (~$0.00012/q, ~1-2s)
  Config B — Balanced        : TF-IDF   + LLMCompiler + DAG Planner  (~$0.00012/q, ~500ms)
  Config C — Latency-First   : TF-IDF   + Rule-based  + Rule-based   (~$0/q,       <10ms)
"""
