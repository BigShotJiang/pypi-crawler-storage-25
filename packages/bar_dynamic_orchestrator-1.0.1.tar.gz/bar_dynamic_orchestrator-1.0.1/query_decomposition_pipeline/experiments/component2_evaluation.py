"""
Component 2: Query Decomposer — Full Academic Evaluation
=========================================================
Evaluates all decomposition methods on the complex queries in
golden_thesis_dataset_1000.jsonl (673 complex samples).

Methods evaluated (6 paradigms):
    1. Rule-Based        — Wolfson et al. TACL 2020         (syntactic)
    2. ToR-Lite          — Yoo et al. Appl.Sci. 2026        (geometric/LLM-free)
    3. AMR               — Banarescu et al. ACL 2013        (graph-based)
    4. Unsupervised      — Perez et al. EMNLP 2020          (self-supervised)
    5. LLMCompiler       — Kim et al. ICML 2024             (LLM DAG)
    6. DeCoR             — Yun & Kim arXiv 2025             (LLM structured)

Ground truth fields (from dataset):
    decomposition : list[str]   — reference sub-queries
    dependencies  : list[list]  — dependency graph ([] = no deps = parallel)
    complexity_type: str        — Sequential | Comparison | Aggregation

Metrics:
    1. Sub-query Count Match   — exact count match vs ground truth
    2. BERTScore               — semantic similarity (cosine, all-MiniLM-L6-v2)
    3. Execution Type Accuracy — parallel / sequential prediction accuracy
    4. Avg Sub-queries         — mean number of sub-queries generated
    5. Avg Latency (ms)        — per-query inference time
    6. Total LLM Cost (USD)    — accumulated API cost

Dataset split:
    All 673 complex samples used for evaluation.
    Simple queries (253) are skipped — decomposition not applicable.

Usage:
    cd /path/to/synthetic_data_generator
    python -m query_decomposition_pipeline.experiments.component2_evaluation
    python -m query_decomposition_pipeline.experiments.component2_evaluation --skip-llm
    python -m query_decomposition_pipeline.experiments.component2_evaluation --methods rule_based,tor_lite,amr
"""

import argparse
import json
import sys
import time
import warnings
from collections import defaultdict
from pathlib import Path

import numpy as np

warnings.filterwarnings("ignore")
sys.path.insert(0, str(Path(__file__).resolve().parents[3]))

from query_decomposition_pipeline.decomposer.rule_based_decomposer import RuleBasedDecomposer
from query_decomposition_pipeline.decomposer.tor_lite_decomposer import ToRLiteDecomposer
from query_decomposition_pipeline.decomposer.amr_decomposer import AMRDecomposer
from query_decomposition_pipeline.decomposer.unsupervised_decomposer import UnsupervisedDecomposer
from query_decomposition_pipeline.decomposer.llmcompiler_decomposer import LLMCompilerDecomposer
from query_decomposition_pipeline.decomposer.decor_decomposer import DeCoRDecomposer

DATASET_PATH = "query_decomposition_pipeline/data/golden_thesis_dataset_1000.jsonl"
RESULTS_DIR  = Path("query_decomposition_pipeline/results/component2")
RESULTS_PATH = RESULTS_DIR / "experiment1_decomposer_comparison.json"

ALL_METHODS = ["rule_based", "tor_lite", "amr", "unsupervised", "llmcompiler", "decor"]
LLM_METHODS = {"llmcompiler", "decor"}


# ── Data loading ──────────────────────────────────────────────────────────────

def load_dataset(path: str, limit: int = None):
    samples = [json.loads(l) for l in open(path) if l.strip()]
    complex_samples = [s for s in samples if int(s["is_complex"]) == 1]

    if limit is None:
        return complex_samples

    # Stratified sampling — equal samples per complexity type
    from collections import defaultdict
    import random
    groups = defaultdict(list)
    for s in complex_samples:
        groups[s.get("complexity_type", "Unknown")].append(s)

    n_types = len(groups)
    per_type = limit // n_types
    remainder = limit % n_types

    rng = random.Random(42)
    selected = []
    for i, (ct, items) in enumerate(sorted(groups.items())):
        n = per_type + (1 if i < remainder else 0)
        selected.extend(rng.sample(items, min(n, len(items))))

    rng.shuffle(selected)
    print(f"  [Stratified] {limit} samples: "
          + ", ".join(f"{k.split(':')[-1].strip()}={len([s for s in selected if s.get('complexity_type','') == k])}"
                      for k in sorted(groups)))
    return selected


def get_exec_type_from_deps(dependencies: list) -> str:
    """
    Infer execution type from dependency list.
    [[], []] → all independent → parallel
    [[], [0]] → second depends on first → sequential
    """
    for deps in dependencies:
        if deps:
            return "sequential"
    return "parallel"


def get_exec_type_from_subqueries(sub_queries) -> str:
    for sq in sub_queries:
        if sq.depends_on:
            return "sequential"
    return "parallel"


# ── Metrics ───────────────────────────────────────────────────────────────────

_bert_encoder = None

def _get_bert_encoder():
    global _bert_encoder
    if _bert_encoder is None:
        from sentence_transformers import SentenceTransformer
        _bert_encoder = SentenceTransformer("all-MiniLM-L6-v2")
    return _bert_encoder


def compute_bert_score(generated: list[str], reference: list[str]) -> float:
    """
    Best-match semantic similarity (BERTScore-style):
    For each reference sub-query, find the best-matching generated sub-query
    by cosine similarity of sentence embeddings. Average across all references.

    Uses all-MiniLM-L6-v2 (fast, 80MB) — captures semantic equivalence
    even when wording differs (e.g. fragment vs reformulated question).

    Academic basis:
        Zhang et al. (2020). "BERTScore: Evaluating Text Generation with BERT."
        ICLR 2020. arXiv:1904.09675.
    """
    if not generated or not reference:
        return 0.0
    encoder = _get_bert_encoder()
    all_texts = generated + reference
    vecs = encoder.encode(all_texts, batch_size=64,
                          show_progress_bar=False,
                          normalize_embeddings=True)
    gen_vecs = vecs[:len(generated)]
    ref_vecs = vecs[len(generated):]

    scores = []
    for rv in ref_vecs:
        best = float(max(rv @ gv for gv in gen_vecs))
        scores.append(best)
    return float(np.mean(scores))


def section(title: str):
    print(f"\n{'═'*72}")
    print(f"  {title}")
    print(f"{'═'*72}")


def divider():
    print("─" * 72)


# ── Decomposer factory ────────────────────────────────────────────────────────

def build_decomposers(methods: list[str]) -> dict:
    import os
    has_api_key = bool(os.environ.get("OPENAI_API_KEY"))

    decomposers = {}
    skipped = []

    for name in methods:
        if name in LLM_METHODS and not has_api_key:
            skipped.append(name)
            continue
        if name == "rule_based":
            decomposers[name] = RuleBasedDecomposer()
        elif name == "tor_lite":
            decomposers[name] = ToRLiteDecomposer()
        elif name == "amr":
            decomposers[name] = AMRDecomposer()
        elif name == "unsupervised":
            decomposers[name] = UnsupervisedDecomposer()
        elif name == "llmcompiler":
            decomposers[name] = LLMCompilerDecomposer()
        elif name == "decor":
            decomposers[name] = DeCoRDecomposer()

    if skipped:
        print(f"\n  ⚠  SKIPPED (no OPENAI_API_KEY): {skipped}")
        print(f"     Set key with: export OPENAI_API_KEY='sk-...'")
        print(f"     Then re-run to include LLM methods.\n")

    return decomposers


# ── Dataset check ─────────────────────────────────────────────────────────────

def check_dataset(samples: list):
    section("DATASET CHECK — golden_thesis_dataset_1000.jsonl (complex only)")

    from collections import Counter
    ct_counts = Counter(s.get("complexity_type", "Unknown") for s in samples)
    dep_counts = Counter(
        get_exec_type_from_deps(s.get("dependencies", []))
        for s in samples
    )
    sq_counts = Counter(
        len(s.get("decomposition", []))
        for s in samples
    )

    print(f"\n  Total complex samples : {len(samples)}")
    print(f"\n  Complexity types:")
    for ct, n in sorted(ct_counts.items()):
        print(f"    {ct:<40} {n:>4}")

    print(f"\n  Ground truth execution type:")
    for et, n in sorted(dep_counts.items()):
        print(f"    {et:<20} {n:>4}")

    print(f"\n  Ground truth sub-query count:")
    for cnt, n in sorted(sq_counts.items()):
        print(f"    {cnt} sub-queries : {n:>4} samples")

    print(f"\n  Sample complex queries:")
    divider()
    for s in samples[:3]:
        print(f"  Query     : {s['query'][:80]}")
        print(f"  Type      : {s.get('complexity_type','')}")
        print(f"  Sub-queries: {s.get('decomposition',[])}")
        print(f"  Deps      : {s.get('dependencies',[])}")
        print(f"  Exec type : {get_exec_type_from_deps(s.get('dependencies',[]))}")
        divider()


# ── Run one decomposer ────────────────────────────────────────────────────────

def run_decomposer(name: str, decomposer, samples: list) -> dict:
    """Run decomposer on all complex samples. Return per-sample results."""
    results = []
    total_cost = 0.0

    print(f"\n  [{name}] Running on {len(samples)} samples...", end=" ", flush=True)
    t_start = time.perf_counter()

    for s in samples:
        query      = s["query"]
        ref_subs   = s.get("decomposition", [])
        ref_deps   = s.get("dependencies", [])
        ctype      = s.get("complexity_type", "Unknown")

        try:
            result = decomposer.decompose(query)
            # Small delay for LLM methods to avoid rate limit hangs
            if name in LLM_METHODS:
                import time as _t; _t.sleep(0.3)
        except Exception as e:
            result = None

        if result is None or not result.sub_queries:
            results.append({
                "query": query, "ctype": ctype,
                "ref_subs": ref_subs, "ref_deps": ref_deps,
                "gen_subs": [query], "exec_type_pred": "sequential",
                "exec_type_gt": get_exec_type_from_deps(ref_deps),
                "count_match": int(1 == len(ref_subs)),
                "bert_score": 0.0,
                "latency_ms": 0.0, "cost": 0.0,
            })
            continue

        gen_texts     = [sq.text for sq in result.sub_queries]
        exec_type_pred = get_exec_type_from_subqueries(result.sub_queries)
        exec_type_gt   = get_exec_type_from_deps(ref_deps)
        bert_score     = compute_bert_score(gen_texts, ref_subs)
        count_match    = int(len(gen_texts) == len(ref_subs))
        total_cost    += result.llm_cost_usd

        results.append({
            "query": query, "ctype": ctype,
            "ref_subs": ref_subs, "ref_deps": ref_deps,
            "gen_subs": gen_texts,
            "exec_type_pred": exec_type_pred,
            "exec_type_gt": exec_type_gt,
            "count_match": count_match,
            "bert_score": bert_score,
            "latency_ms": result.latency_ms,
            "cost": result.llm_cost_usd,
        })

    total_ms = (time.perf_counter() - t_start) * 1000
    print(f"done  ({total_ms/len(samples):.1f}ms/query)")

    return {
        "results": results,
        "total_cost": total_cost,
        "avg_latency_ms": total_ms / len(samples),
    }


# ── Experiment 1: Overall comparison ─────────────────────────────────────────

def experiment_1_comparison(all_results: dict):
    section("EXPERIMENT 1 — Decomposer Comparison (all complex queries)")

    labels = {
        "rule_based":   "Rule-Based",
        "tor_lite":     "ToR-Lite",
        "amr":          "AMR Graph",
        "unsupervised": "Unsupervised",
        "llmcompiler":  "LLMCompiler",
        "decor":        "DeCoR",
    }

    header = (f"  {'Method':<16} {'Count-Match':>12} {'BERTScore':>10} "
              f"{'ExecType-Acc':>13} {'Avg-SQs':>8} {'Lat(ms)':>8} {'Cost($)':>10}")
    print(header)
    divider()

    summary = {}
    for name, data in all_results.items():
        rs = data["results"]
        count_match   = np.mean([r["count_match"] for r in rs])
        bert_score    = np.mean([r["bert_score"] for r in rs])
        exec_acc      = np.mean([
            int(r["exec_type_pred"] == r["exec_type_gt"]) for r in rs
        ])
        avg_sqs       = np.mean([len(r["gen_subs"]) for r in rs])
        avg_lat       = data["avg_latency_ms"]
        total_cost    = data["total_cost"]

        label = labels.get(name, name)
        print(f"  {label:<16} {count_match:>11.1%} {bert_score:>10.4f} "
              f"{exec_acc:>12.1%} {avg_sqs:>8.2f} {avg_lat:>8.1f} "
              f"{total_cost:>10.6f}")

        summary[name] = {
            "count_match_acc": round(float(count_match), 4),
            "bert_score":      round(float(bert_score), 4),
            "exec_type_acc":   round(float(exec_acc), 4),
            "avg_subqueries":  round(float(avg_sqs), 2),
            "avg_latency_ms":  round(avg_lat, 2),
            "total_cost_usd":  round(total_cost, 6),
        }

    return summary


# ── Experiment 2: Per complexity-type breakdown ───────────────────────────────

def experiment_2_per_type(all_results: dict):
    section("EXPERIMENT 2 — Per Complexity Type Breakdown (BERTScore)")

    types = ["Type 2: Sequential", "Type 3: Comparison", "Type 4: Aggregation"]
    method_names = list(all_results.keys())

    header = f"  {'Complexity Type':<30} {'N':>4}"
    for n in method_names:
        header += f"  {n[:8]:>8}"
    print(header)
    divider()

    for ct in types:
        row = f"  {ct:<30}"
        n = 0
        for name, data in all_results.items():
            subset = [r for r in data["results"] if r["ctype"] == ct]
            if n == 0:
                n = len(subset)
                row += f" {n:>4}"
            score = np.mean([r["bert_score"] for r in subset]) if subset else 0.0
            row += f"  {score:>8.4f}"
        print(row)


# ── Experiment 3: Sub-query count distribution ────────────────────────────────

def experiment_3_count_distribution(all_results: dict):
    section("EXPERIMENT 3 — Sub-query Count Distribution")

    method_names = list(all_results.keys())
    print(f"\n  {'Count':<8}", end="")
    for n in method_names:
        print(f"  {n[:10]:>10}", end="")
    print(f"  {'GT':>6}")
    divider()

    first_results = list(all_results.values())[0]["results"]
    gt_counts = defaultdict(int)
    for r in first_results:
        gt_counts[len(r["ref_subs"])] += 1

    all_counts = set(gt_counts.keys())
    for data in all_results.values():
        for r in data["results"]:
            all_counts.add(len(r["gen_subs"]))

    for count in sorted(all_counts):
        row = f"  {count:<8}"
        for name, data in all_results.items():
            n_with_count = sum(
                1 for r in data["results"] if len(r["gen_subs"]) == count
            )
            pct = n_with_count / len(data["results"])
            row += f"  {pct:>9.1%}"
        row += f"  {gt_counts.get(count,0)/len(first_results):>5.1%}"
        print(row)


# ── Experiment 4: Error analysis ─────────────────────────────────────────────

def experiment_4_error_analysis(all_results: dict):
    section("EXPERIMENT 4 — Error Analysis (worst BERTScore samples per method)")

    for name, data in all_results.items():
        rs = sorted(data["results"], key=lambda r: r["bert_score"])
        worst = rs[:3]
        print(f"\n  [{name}] — 3 worst decompositions:")
        for r in worst:
            print(f"    Query    : {r['query'][:70]}")
            print(f"    GT       : {r['ref_subs']}")
            print(f"    Generated: {r['gen_subs']}")
            print(f"    BERTScore: {r['bert_score']:.4f}  ExecType: "
                  f"{r['exec_type_pred']} (GT: {r['exec_type_gt']})")
            print()


# ── Experiment 5: Execution type accuracy per complexity type ─────────────────

def experiment_5_exec_type(all_results: dict):
    section("EXPERIMENT 5 — Execution Type Accuracy per Complexity Type")

    types = ["Type 2: Sequential", "Type 3: Comparison", "Type 4: Aggregation"]
    method_names = list(all_results.keys())

    header = f"  {'Complexity Type':<30} {'N':>4}"
    for n in method_names:
        header += f"  {n[:8]:>8}"
    print(header)
    divider()

    for ct in types:
        row = f"  {ct:<30}"
        n = 0
        for name, data in all_results.items():
            subset = [r for r in data["results"] if r["ctype"] == ct]
            if n == 0:
                n = len(subset)
                row += f" {n:>4}"
            acc = np.mean([
                int(r["exec_type_pred"] == r["exec_type_gt"])
                for r in subset
            ]) if subset else 0.0
            row += f"  {acc:>7.1%}"
        print(row)


# ── Save results ──────────────────────────────────────────────────────────────

def save_results(summary: dict):
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    # Merge with existing results so LLM and non-LLM runs can be combined
    existing = {}
    if RESULTS_PATH.exists():
        with open(RESULTS_PATH) as f:
            existing = json.load(f)
    existing.update(summary)
    with open(RESULTS_PATH, "w") as f:
        json.dump(existing, f, indent=2)
    print(f"\n  Results saved → {RESULTS_PATH}")
    print(f"  All methods in file: {list(existing.keys())}")


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", default=DATASET_PATH)
    parser.add_argument("--methods", default="all",
                        help="Comma-separated: rule_based,tor_lite,amr,unsupervised,llmcompiler,decor")
    parser.add_argument("--skip-llm", action="store_true",
                        help="Skip LLM-based methods (llmcompiler, decor)")
    parser.add_argument("--limit", type=int, default=None,
                        help="Limit number of samples (for quick testing)")
    parser.add_argument("--experiments", default="all",
                        help="Comma-separated: 1,2,3,4,5 or 'all'")
    args = parser.parse_args()

    methods = (
        [m for m in ALL_METHODS if m not in LLM_METHODS]
        if args.skip_llm
        else (
            ALL_METHODS if args.methods == "all"
            else args.methods.split(",")
        )
    )

    run_all = args.experiments == "all"
    run = set(args.experiments.split(",")) if not run_all else set("12345")

    print("\n" + "═"*72)
    print("  COMPONENT 2: QUERY DECOMPOSER — FULL ACADEMIC EVALUATION")
    print("═"*72)
    print(f"  Methods : {methods}")
    print(f"  Dataset : {args.dataset}")

    # Load data
    print(f"\n[Data] Loading {args.dataset}...")
    samples = load_dataset(args.dataset, limit=args.limit)
    print(f"[Data] {len(samples)} complex samples loaded")

    # Dataset check
    check_dataset(samples)

    # Build decomposers
    print("\n[Init] Building decomposers...")
    decomposers = build_decomposers(methods)

    # Run all decomposers
    print("\n[Evaluation] Running decomposers...")
    all_results = {}
    for name, decomposer in decomposers.items():
        all_results[name] = run_decomposer(name, decomposer, samples)

    # Run experiments
    summary = {}
    if "1" in run:
        summary = experiment_1_comparison(all_results)

    if "2" in run:
        experiment_2_per_type(all_results)

    if "3" in run:
        experiment_3_count_distribution(all_results)

    if "4" in run:
        experiment_4_error_analysis(all_results)

    if "5" in run:
        experiment_5_exec_type(all_results)

    if summary:
        save_results(summary)

    print("\n" + "═"*72)
    print("  EVALUATION COMPLETE")
    print("═"*72)


if __name__ == "__main__":
    main()
