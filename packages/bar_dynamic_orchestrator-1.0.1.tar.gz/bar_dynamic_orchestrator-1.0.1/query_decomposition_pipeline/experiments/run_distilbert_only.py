"""
DistilBERT Binary Complexity Detector — Standalone Training & Evaluation
=========================================================================

Train   : binary_dataset_1000.jsonl  — ALL 1009 samples (509 simple / 500 complex)
Test    : golden_thesis_dataset_1000.jsonl — ALL 926 samples (independent, never trained on)
Model   : distilbert-base-uncased fine-tuned for binary classification

Academic basis:
    Sanh et al. (2019). "DistilBERT, a distilled version of BERT: smaller,
    faster, cheaper and lighter." NeurIPS EMC² Workshop. arXiv:1910.01108.

    Sun et al. (2019). "How to Fine-Tune BERT for Text Classification?"
    CCL 2019. arXiv:1905.05583.
    → Fine-tuning recipe: lr=2e-5, epochs=3, max_length=128.

Usage:
    cd /path/to/synthetic_data_generator
    python -m query_decomposition_pipeline.experiments.run_distilbert_only
"""

import json
import sys
import time
import warnings
from pathlib import Path

import numpy as np
from sklearn.metrics import (
    accuracy_score, f1_score, precision_score, recall_score, roc_auc_score,
    confusion_matrix,
)

warnings.filterwarnings("ignore")
sys.path.insert(0, str(Path(__file__).resolve().parents[3]))

from query_decomposition_pipeline.complexity_detector.distilbert_detector import DistilBERTDetector

TRAIN_PATH   = "query_decomposition_pipeline/data/binary_dataset_1000.jsonl"
TEST_PATH    = "query_decomposition_pipeline/data/golden_thesis_dataset_1000.jsonl"
RESULTS_PATH = Path("query_decomposition_pipeline/results/component1/experiment1_method_comparison.json")


def load_dataset(path: str):
    samples = [json.loads(l) for l in open(path) if l.strip()]
    queries = [s["query"] for s in samples]
    labels  = [int(s["is_complex"]) for s in samples]
    return queries, labels


def main():
    print("\n" + "═"*65)
    print("  DistilBERT Binary Complexity Detector")
    print("  Sanh et al. (2019). DistilBERT. arXiv:1910.01108.")
    print("═"*65)

    # ── Load training data (all 1009 samples) ─────────────────────────────
    print(f"\n[Train] Loading {TRAIN_PATH}...")
    X_train, y_train = load_dataset(TRAIN_PATH)
    print(f"[Train] {len(X_train)} samples  |  "
          f"simple={y_train.count(0)}  complex={y_train.count(1)}")

    # ── Load test data (golden_thesis — never used for training) ──────────
    print(f"\n[Test]  Loading {TEST_PATH}...")
    X_test, y_test = load_dataset(TEST_PATH)
    print(f"[Test]  {len(X_test)} samples  |  "
          f"simple={y_test.count(0)}  complex={y_test.count(1)}")

    # ── Train on all 1009 samples ─────────────────────────────────────────
    detector = DistilBERTDetector()
    detector.train(X_train, y_train)

    # ── Inference ─────────────────────────────────────────────────────────
    print("\n[Inference] Running on test set...")
    t0 = time.perf_counter()
    preds  = detector.predict_batch(X_test)
    elapsed_ms = (time.perf_counter() - t0) * 1000
    probas = detector.predict_proba_batch(X_test)

    # ── Metrics ───────────────────────────────────────────────────────────
    acc     = round(accuracy_score(y_test, preds), 4)
    f1_mac  = round(f1_score(y_test, preds, average="macro",  zero_division=0), 4)
    f1_bin  = round(f1_score(y_test, preds, average="binary", zero_division=0), 4)
    prec    = round(precision_score(y_test, preds, zero_division=0), 4)
    rec     = round(recall_score(y_test, preds, zero_division=0), 4)
    roc_auc = round(roc_auc_score(y_test, probas[:, 1]), 4)
    avg_lat = round(elapsed_ms / len(X_test), 3)

    tn, fp, fn, tp = confusion_matrix(y_test, preds).ravel()

    result = {
        "accuracy":       acc,
        "f1_macro":       f1_mac,
        "f1_binary":      f1_bin,
        "precision":      prec,
        "recall":         rec,
        "roc_auc":        roc_auc,
        "avg_latency_ms": avg_lat,
    }

    # ── Print results ─────────────────────────────────────────────────────
    print("\n" + "─"*50)
    print(f"  {'Metric':<20} {'Value':>10}")
    print("─"*50)
    for k, v in result.items():
        print(f"  {k:<20} {v:>10}")
    print("─"*50)
    print(f"  TP={tp}  TN={tn}  FP={fp}  FN={fn}")

    # ── Merge into existing results JSON ──────────────────────────────────
    existing = {}
    if RESULTS_PATH.exists():
        with open(RESULTS_PATH) as f:
            existing = json.load(f)
        print(f"\n[Results] Existing methods: {list(existing.keys())}")

    existing["distilbert"] = result

    RESULTS_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(RESULTS_PATH, "w") as f:
        json.dump(existing, f, indent=2)
    print(f"[Results] Saved → {RESULTS_PATH}")

    # ── Full comparison table ─────────────────────────────────────────────
    labels_map = {
        "rule_based":    "Rule-Based Structural",
        "tfidf_svm":     "TF-IDF + SVM",
        "minilm_svm":    "MiniLM + SVM",
        "distilbert":    "DistilBERT (fine-tuned)",
        "llm_gpt4o_mini":"LLM GPT-4o-mini",
    }
    print("\n" + "═"*75)
    print("  EXPERIMENT 1 — Method Comparison")
    print("═"*75)
    print(f"  {'Method':<26} {'Acc':>7} {'F1-Mac':>7} {'F1-Bin':>7} "
          f"{'Prec':>7} {'Recall':>7} {'ROC-AUC':>8} {'Lat(ms)':>8}")
    print("  " + "─"*70)
    for name, m in existing.items():
        label = labels_map.get(name, name)
        roc   = f"{m['roc_auc']:.4f}" if m.get("roc_auc") else "   —   "
        print(f"  {label:<26} {m['accuracy']:>7.4f} {m['f1_macro']:>7.4f} "
              f"{m['f1_binary']:>7.4f} {m['precision']:>7.4f} {m['recall']:>7.4f} "
              f"{roc:>8} {m.get('avg_latency_ms', 0):>7.3f}")
    print("═"*75)
    print("  Train : binary_dataset_1000.jsonl (all 1009 samples)")
    print("  Test  : golden_thesis_dataset_1000.jsonl (all 926 samples, independent)")
    print("═"*75)


if __name__ == "__main__":
    main()
