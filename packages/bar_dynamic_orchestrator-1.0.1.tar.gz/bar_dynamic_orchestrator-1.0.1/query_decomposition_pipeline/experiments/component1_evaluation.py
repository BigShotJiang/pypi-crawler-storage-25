"""
Component 1: Complexity Detector — Full Academic Evaluation
============================================================
Implements all 7 experiments for the complexity detection component.

Methods evaluated:
    1. Rule-Based Structural          (Wolfson et al. TACL 2020)
    2. TF-IDF + LinearSVC             (Joachims 1998; RAGRouter-Bench 2026)
    3. MiniLM + SVM                   (Wang et al. NeurIPS 2020)
    4. DistilBERT fine-tuned (binary) (Sanh et al. 2019)
    5. LLM GPT-4o-mini (zero-shot)    (reference baseline; --include-llm)

Experiments:
    1. Method Comparison       — all detectors, same 80/20 split
    2. Per-Type Breakdown      — accuracy per complexity_type
    3. Learning Curve          — accuracy vs training size
    4. Ablation Study          — which rule-based signals matter most
    5. Threshold Sensitivity   — accuracy vs decision threshold
    6. Statistical Significance— McNemar's test between methods
    7. Error Analysis          — false positive / false negative patterns

Dataset: golden_thesis_dataset_1000.jsonl (926 samples)
    Fields: query, is_complex (0/1), complexity_type

Usage:
    cd /path/to/synthetic_data_generator
    python -m query_decomposition_pipeline.experiments.component1_evaluation
    python -m query_decomposition_pipeline.experiments.component1_evaluation --include-llm
    python -m query_decomposition_pipeline.experiments.component1_evaluation --skip-distilbert
"""

import argparse
import json
import sys
import time
import warnings
from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy.stats import chi2_contingency
from sklearn.metrics import (
    accuracy_score, f1_score, precision_score, recall_score,
    roc_auc_score, classification_report, confusion_matrix,
)
from sklearn.model_selection import StratifiedKFold, train_test_split

warnings.filterwarnings("ignore")
sys.path.insert(0, str(Path(__file__).resolve().parents[3]))

from query_decomposition_pipeline.complexity_detector.rule_based_detector import RuleBasedDetector
from query_decomposition_pipeline.complexity_detector.tfidf_svm_detector import TFIDFSVMDetector
from query_decomposition_pipeline.complexity_detector.minilm_svm_detector import MiniLMSVMDetector
from query_decomposition_pipeline.complexity_detector.distilbert_detector import DistilBERTDetector

DATASET_PATH = "query_decomposition_pipeline/data/golden_thesis_dataset_1000.jsonl"
RESULTS_DIR  = Path("query_decomposition_pipeline/results/component1")
RANDOM_STATE = 42


# ── Data loading ──────────────────────────────────────────────────────────────

def load_dataset(path: str = DATASET_PATH):
    samples = [json.loads(l) for l in open(path) if l.strip()]
    queries      = [s["query"] for s in samples]
    labels       = [int(s["is_complex"]) for s in samples]
    complexity_types = [s.get("complexity_type", "Unknown") for s in samples]
    return queries, labels, complexity_types


# ── Helpers ───────────────────────────────────────────────────────────────────

def metrics(y_true, y_pred, y_proba=None):
    m = {
        "accuracy":  round(accuracy_score(y_true, y_pred), 4),
        "f1_macro":  round(f1_score(y_true, y_pred, average="macro",   zero_division=0), 4),
        "f1_binary": round(f1_score(y_true, y_pred, average="binary",  zero_division=0), 4),
        "precision": round(precision_score(y_true, y_pred, zero_division=0), 4),
        "recall":    round(recall_score(y_true, y_pred, zero_division=0), 4),
    }
    if y_proba is not None:
        try:
            m["roc_auc"] = round(roc_auc_score(y_true, y_proba[:, 1]), 4)
        except Exception:
            m["roc_auc"] = 0.0
    return m


def section(title: str):
    print(f"\n{'═'*70}")
    print(f"  {title}")
    print(f"{'═'*70}")


def divider():
    print("─" * 70)


# ── Detector factory ──────────────────────────────────────────────────────────

def build_and_train_detectors(X_train, y_train, skip_llm=True, skip_distilbert=False):
    """Train all detectors on training split. Returns dict of detectors."""

    detectors = {}

    # 1. Rule-based (no training needed)
    detectors["rule_based"] = RuleBasedDetector()

    # 2. TF-IDF + SVM
    print("  Training TF-IDF+SVM...", end=" ", flush=True)
    t = TFIDFSVMDetector()
    t.train(X_train, y_train)
    detectors["tfidf_svm"] = t
    print("done")

    # 3. MiniLM + SVM
    print("  Training MiniLM+SVM...", end=" ", flush=True)
    m = MiniLMSVMDetector()
    m.train(X_train, y_train)
    detectors["minilm_svm"] = m
    print("done")

    # 4. DistilBERT fine-tuned (optional — requires torch + transformers)
    if not skip_distilbert:
        try:
            print("  Fine-tuning DistilBERT...")
            db = DistilBERTDetector()
            db.train(X_train, y_train)
            detectors["distilbert"] = db
        except Exception as e:
            print(f"  DistilBERT skipped: {e}")

    # 5. LLM (optional — expensive, API calls)
    if not skip_llm:
        try:
            from query_decomposition_pipeline.complexity_detector.llm_detector import LLMDetector
            detectors["llm_gpt4o_mini"] = LLMDetector()
            print("  LLM detector ready")
        except Exception as e:
            print(f"  LLM detector skipped: {e}")

    return detectors


def predict_all(detectors, X_test):
    """Run all detectors on test set. Returns predictions and latencies."""
    results = {}
    for name, det in detectors.items():
        t0 = time.perf_counter()
        if hasattr(det, "predict_batch"):
            preds = det.predict_batch(X_test)
        else:
            preds = [int(det.detect(q).is_complex) for q in X_test]
        elapsed = (time.perf_counter() - t0) * 1000

        probas = None
        if hasattr(det, "predict_proba_batch"):
            try:
                probas = det.predict_proba_batch(X_test)
            except Exception:
                pass

        results[name] = {
            "preds": preds,
            "probas": probas,
            "total_latency_ms": elapsed,
            "avg_latency_ms": elapsed / len(X_test),
        }
    return results


# ── Experiment 1: Method Comparison ──────────────────────────────────────────

def experiment_1_method_comparison(detectors, X_test, y_test, pred_results):
    section("EXPERIMENT 1 — Method Comparison (80/20 stratified split)")

    labels_map = {
        "rule_based":    "Rule-Based Structural",
        "tfidf_svm":     "TF-IDF + SVM",
        "minilm_svm":    "MiniLM + SVM",
        "distilbert":    "DistilBERT (fine-tuned)",
        "llm_gpt4o_mini":"LLM GPT-4o-mini",
    }

    header = f"{'Method':<25} {'Acc':>7} {'F1-Mac':>7} {'F1-Bin':>7} {'Prec':>7} {'Recall':>7} {'ROC-AUC':>8} {'Lat(ms)':>8}"
    print(header)
    divider()

    all_metrics = {}
    for name, res in pred_results.items():
        m = metrics(y_test, res["preds"], res["probas"])
        m["avg_latency_ms"] = res["avg_latency_ms"]
        all_metrics[name] = m
        label = labels_map.get(name, name)
        roc = f"{m.get('roc_auc', 0):.4f}"
        print(f"{label:<25} {m['accuracy']:>7.4f} {m['f1_macro']:>7.4f} "
              f"{m['f1_binary']:>7.4f} {m['precision']:>7.4f} {m['recall']:>7.4f} "
              f"{roc:>8} {m['avg_latency_ms']:>7.3f}")

    divider()
    print(f"\n  Test set: {len(y_test)} samples  "
          f"(complex={sum(y_test)}, simple={len(y_test)-sum(y_test)})")
    return all_metrics


# ── Experiment 2: Per-Type Breakdown ─────────────────────────────────────────

def experiment_2_per_type(detectors, X_test, y_test, complexity_types_test, pred_results):
    section("EXPERIMENT 2 — Per Complexity-Type Breakdown")

    unique_types = sorted(set(complexity_types_test))
    type_indices = {ct: [i for i, t in enumerate(complexity_types_test) if t == ct]
                    for ct in unique_types}

    det_names = list(pred_results.keys())
    header = f"{'Complexity Type':<30} {'N':>4}"
    for n in det_names:
        header += f"  {'Acc':>6}"
    print(header)
    divider()

    for ct in unique_types:
        idxs = type_indices[ct]
        yt = [y_test[i] for i in idxs]
        row = f"{ct:<30} {len(idxs):>4}"
        for name in det_names:
            preds = [pred_results[name]["preds"][i] for i in idxs]
            acc = accuracy_score(yt, preds) if yt else 0.0
            row += f"  {acc:>5.1%}"
        print(row)

    print(f"\n  Columns: {', '.join(det_names)}")


# ── Experiment 3: Learning Curve ─────────────────────────────────────────────

def experiment_3_learning_curve(X_train, y_train, X_test, y_test):
    section("EXPERIMENT 3 — Learning Curve (Training Size vs Accuracy)")

    sizes = [50, 100, 150, 200, 300, 400, 500, len(X_train)]
    sizes = [s for s in sizes if s <= len(X_train)]

    header = f"{'Train Size':>12}"
    for name in ["TF-IDF+SVM", "MiniLM+SVM"]:
        header += f"  {name:>12}"
    print(header)
    divider()

    for size in sizes:
        # Stratified subsample
        if size < len(X_train):
            idxs = []
            pos = [i for i, l in enumerate(y_train) if l == 1]
            neg = [i for i, l in enumerate(y_train) if l == 0]
            n_pos = int(size * sum(y_train) / len(y_train))
            n_neg = size - n_pos
            np.random.seed(RANDOM_STATE)
            idxs = (list(np.random.choice(pos, min(n_pos, len(pos)), replace=False)) +
                    list(np.random.choice(neg, min(n_neg, len(neg)), replace=False)))
            X_sub = [X_train[i] for i in idxs]
            y_sub = [y_train[i] for i in idxs]
        else:
            X_sub, y_sub = X_train, y_train

        row = f"{len(X_sub):>12}"

        # TF-IDF+SVM
        tfidf = TFIDFSVMDetector()
        tfidf.train(X_sub, y_sub)
        preds_t = tfidf.predict_batch(X_test)
        acc_t = accuracy_score(y_test, preds_t)
        row += f"  {acc_t:>11.4f}"

        # MiniLM+SVM
        minilm = MiniLMSVMDetector()
        minilm.train(X_sub, y_sub)
        preds_m = minilm.predict_batch(X_test)
        acc_m = accuracy_score(y_test, preds_m)
        row += f"  {acc_m:>11.4f}"

        print(row)

    print("\n  Rule-based does not require training data (shown at all sizes).")
    rb = RuleBasedDetector()
    preds_rb = [int(rb.detect(q).is_complex) for q in X_test]
    print(f"  Rule-based accuracy (constant): {accuracy_score(y_test, preds_rb):.4f}")


# ── Experiment 4: Ablation Study ─────────────────────────────────────────────

def experiment_4_ablation(X_test, y_test):
    section("EXPERIMENT 4 — Ablation Study on Rule-Based Signals")

    import re
    from query_decomposition_pipeline.complexity_detector.rule_based_detector import (
        _COMPLEXITY_SIGNALS, _SIMPLE_SIGNALS, _THRESHOLD
    )

    def score_query(query, exclude_complexity_idx=None, exclude_simple_idx=None):
        q = query.lower().strip()
        cx = 0
        for i, (pattern, weight) in enumerate(_COMPLEXITY_SIGNALS):
            if i == exclude_complexity_idx:
                continue
            if re.search(pattern, q, re.IGNORECASE):
                cx += weight
        sm = 0
        for i, (pattern, weight) in enumerate(_SIMPLE_SIGNALS):
            if i == exclude_simple_idx:
                continue
            if re.search(pattern, q, re.IGNORECASE):
                sm += weight
        word_count = len(query.split())
        if word_count > 20:
            cx += 1
        return int((cx - sm) >= _THRESHOLD)

    # Baseline (all signals)
    baseline_preds = [score_query(q) for q in X_test]
    baseline_acc = accuracy_score(y_test, baseline_preds)

    signal_labels = [
        "Sequential connectives (then, after that)",
        "Comparison (compare, vs, difference between)",
        "Conditional multi-aspect (if...how/what)",
        "Comma-verb list (X, Y, and Z)",
        "Parallel connectives (and also, as well as)",
        "Multi-step instruction (step by step, first...then)",
        "Aggregation (list all, for each)",
    ]

    print(f"  {'Signal Removed':<45} {'Acc':>7} {'Drop':>7}  Impact")
    divider()
    print(f"  {'ALL SIGNALS (baseline)':<45} {baseline_acc:>7.4f} {'—':>7}")
    divider()

    for i, label in enumerate(signal_labels):
        preds = [score_query(q, exclude_complexity_idx=i) for q in X_test]
        acc = accuracy_score(y_test, preds)
        drop = baseline_acc - acc
        impact = "HIGH" if drop > 0.05 else ("MED" if drop > 0.01 else "LOW")
        sign = "-" if drop >= 0 else "+"
        print(f"  {label:<45} {acc:>7.4f} {sign}{abs(drop):>6.4f}  {impact}")

    print(f"\n  Interpretation: HIGH drop = signal is critical to accuracy.")


# ── Experiment 5: Threshold Sensitivity ──────────────────────────────────────

def experiment_5_threshold(X_test, y_test):
    section("EXPERIMENT 5 — Threshold Sensitivity (Rule-Based Score Threshold)")

    import re
    from query_decomposition_pipeline.complexity_detector.rule_based_detector import (
        _COMPLEXITY_SIGNALS, _SIMPLE_SIGNALS
    )

    def compute_net_scores(queries):
        scores = []
        for query in queries:
            q = query.lower().strip()
            cx = sum(w for p, w in _COMPLEXITY_SIGNALS if re.search(p, q, re.IGNORECASE))
            sm = sum(w for p, w in _SIMPLE_SIGNALS if re.search(p, q, re.IGNORECASE))
            if len(query.split()) > 20:
                cx += 1
            scores.append(cx - sm)
        return scores

    net_scores = compute_net_scores(X_test)
    thresholds = sorted(set(net_scores))

    best_j, best_thresh, best_acc = -1, 2, 0
    print(f"  {'Threshold':>10} {'Accuracy':>10} {'Precision':>10} {'Recall':>10} {'F1':>8} {'Youden-J':>10}")
    divider()

    for thresh in range(-2, 8):
        preds = [int(s >= thresh) for s in net_scores]
        if len(set(preds)) < 2:
            continue
        acc  = accuracy_score(y_test, preds)
        prec = precision_score(y_test, preds, zero_division=0)
        rec  = recall_score(y_test, preds, zero_division=0)
        f1   = f1_score(y_test, preds, zero_division=0)
        tn, fp, fn, tp = confusion_matrix(y_test, preds).ravel()
        sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0
        specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
        youden_j = sensitivity + specificity - 1
        marker = " ← optimal (Youden's J)" if youden_j > best_j else ""
        if youden_j > best_j:
            best_j, best_thresh, best_acc = youden_j, thresh, acc
        print(f"  {thresh:>10} {acc:>10.4f} {prec:>10.4f} {rec:>10.4f} {f1:>8.4f} {youden_j:>10.4f}{marker}")

    print(f"\n  Optimal threshold by Youden's J: {best_thresh}  (accuracy={best_acc:.4f})")
    print(f"  Current default threshold: 2")


# ── Experiment 6: Statistical Significance ────────────────────────────────────

def experiment_6_significance(y_test, pred_results):
    section("EXPERIMENT 6 — Statistical Significance (McNemar's Test)")
    print("  H0: Both classifiers make the same errors (no significant difference)")
    print("  p < 0.05 → reject H0 → difference is statistically significant\n")

    names = list(pred_results.keys())
    print(f"  {'Method A':<22} {'Method B':<22} {'b':>5} {'c':>5} {'chi2':>8} {'p-value':>10} {'Sig?':>6}")
    divider()

    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            name_a, name_b = names[i], names[j]
            preds_a = pred_results[name_a]["preds"]
            preds_b = pred_results[name_b]["preds"]

            # McNemar contingency table
            b = sum(1 for a, bb, t in zip(preds_a, preds_b, y_test)
                    if a == t and bb != t)   # A correct, B wrong
            c = sum(1 for a, bb, t in zip(preds_a, preds_b, y_test)
                    if a != t and bb == t)   # A wrong, B correct

            if b + c == 0:
                print(f"  {name_a:<22} {name_b:<22} {b:>5} {c:>5} {'N/A':>8} {'N/A':>10} {'—':>6}")
                continue

            # McNemar's test (with continuity correction)
            chi2 = (abs(b - c) - 1) ** 2 / (b + c)
            from scipy.stats import chi2 as chi2_dist
            p_value = 1 - chi2_dist.cdf(chi2, df=1)
            sig = "YES ***" if p_value < 0.001 else ("YES **" if p_value < 0.01
                  else ("YES *" if p_value < 0.05 else "NO"))
            print(f"  {name_a:<22} {name_b:<22} {b:>5} {c:>5} {chi2:>8.3f} {p_value:>10.4f} {sig:>6}")

    print("\n  b = cases where A correct but B wrong")
    print("  c = cases where A wrong but B correct")
    print("  *** p<0.001  ** p<0.01  * p<0.05")


# ── Experiment 7: Error Analysis ──────────────────────────────────────────────

def experiment_7_error_analysis(detectors, X_test, y_test, complexity_types_test, pred_results):
    section("EXPERIMENT 7 — Error Analysis (False Positives & False Negatives)")

    for name, res in pred_results.items():
        preds = res["preds"]
        fp = [(X_test[i], complexity_types_test[i]) for i in range(len(y_test))
              if y_test[i] == 0 and preds[i] == 1]
        fn = [(X_test[i], complexity_types_test[i]) for i in range(len(y_test))
              if y_test[i] == 1 and preds[i] == 0]

        print(f"\n  [{name}]  FP={len(fp)}  FN={len(fn)}")
        print(f"  False Positives (simple → predicted complex): {len(fp)}")
        for q, ct in fp[:3]:
            print(f"    [{ct}] {q[:80]}")
        print(f"  False Negatives (complex → predicted simple): {len(fn)}")
        for q, ct in fn[:3]:
            print(f"    [{ct}] {q[:80]}")

        # FP/FN by complexity type
        fp_by_type = defaultdict(int)
        fn_by_type = defaultdict(int)
        for _, ct in fp: fp_by_type[ct] += 1
        for _, ct in fn: fn_by_type[ct] += 1
        print(f"  FP by type: {dict(fp_by_type)}")
        print(f"  FN by type: {dict(fn_by_type)}")


# ── Save results ──────────────────────────────────────────────────────────────

def save_results(all_metrics: dict):
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    path = RESULTS_DIR / "experiment1_method_comparison.json"
    with open(path, "w") as f:
        json.dump(all_metrics, f, indent=2)
    print(f"\n  Results saved to {path}")


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", default=DATASET_PATH)
    parser.add_argument("--include-llm", action="store_true",
                        help="Include LLM GPT-4o-mini detector (costs ~$0.025)")
    parser.add_argument("--skip-distilbert", action="store_true",
                        help="Skip DistilBERT fine-tuning (faster run, no torch required)")
    parser.add_argument("--experiments", default="all",
                        help="Comma-separated list: 1,2,3,4,5,6,7 or 'all'")
    args = parser.parse_args()

    skip_llm = not args.include_llm
    skip_distilbert = args.skip_distilbert
    run_all = args.experiments == "all"
    run = set(args.experiments.split(",")) if not run_all else set("1234567")

    print("\n" + "═"*70)
    print("  COMPONENT 1: COMPLEXITY DETECTOR — FULL ACADEMIC EVALUATION")
    print("═"*70)

    # Load data
    print(f"\n[Data] Loading {args.dataset}...")
    queries, labels, complexity_types = load_dataset(args.dataset)
    print(f"[Data] {len(queries)} samples  |  complex={sum(labels)}  simple={len(labels)-sum(labels)}")

    from collections import Counter
    print(f"[Data] Types: {dict(Counter(complexity_types))}")

    # 80/20 stratified split
    X_train, X_test, y_train, y_test, ct_train, ct_test = train_test_split(
        queries, labels, complexity_types,
        test_size=0.20, random_state=RANDOM_STATE, stratify=labels
    )
    print(f"[Split] Train={len(X_train)}  Test={len(X_test)}")

    # Build and train detectors
    print("\n[Training] Building detectors...")
    detectors = build_and_train_detectors(
        X_train, y_train,
        skip_llm=skip_llm,
        skip_distilbert=skip_distilbert,
    )

    # Run predictions once (reused across experiments)
    print("[Inference] Running all detectors on test set...")
    pred_results = predict_all(detectors, X_test)

    # Run experiments
    all_metrics = {}
    if "1" in run:
        all_metrics = experiment_1_method_comparison(detectors, X_test, y_test, pred_results)

    if "2" in run:
        experiment_2_per_type(detectors, X_test, y_test, ct_test, pred_results)

    if "3" in run:
        experiment_3_learning_curve(X_train, y_train, X_test, y_test)

    if "4" in run:
        experiment_4_ablation(X_test, y_test)

    if "5" in run:
        experiment_5_threshold(X_test, y_test)

    if "6" in run:
        experiment_6_significance(y_test, pred_results)

    if "7" in run:
        experiment_7_error_analysis(detectors, X_test, y_test, ct_test, pred_results)

    if all_metrics:
        save_results(all_metrics)

    print("\n" + "═"*70)
    print("  EVALUATION COMPLETE")
    print("═"*70)


if __name__ == "__main__":
    main()
