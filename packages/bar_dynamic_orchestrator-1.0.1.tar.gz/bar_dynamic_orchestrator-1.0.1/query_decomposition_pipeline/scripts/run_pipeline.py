"""
Quick test — run a single query through all 3 configs.

Usage:
    cd /Users/nipundimanthahevavitharanage/Downloads/synthetic_data_generator
    python -m query_decomposition_pipeline.scripts.run_pipeline
    python -m query_decomposition_pipeline.scripts.run_pipeline --config B --query "your query"
"""

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from query_decomposition_pipeline.config import ConfigName
from query_decomposition_pipeline.pipeline.router_pipeline import RouterPipeline

TEST_QUERIES = [
    ("simple",  "What is the capital of France?"),
    ("complex", "Compare the legal implications of GDPR and CCPA, then summarise which applies to my German SaaS company."),
    ("complex", "Explain the symptoms of diabetes and hypertension and suggest a combined diet plan for both conditions."),
    ("complex", "Write a Python function to sort a list, then explain the time complexity and provide test cases."),
    ("simple",  "Hello, how are you?"),
]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", choices=["A", "B", "C"], default=None,
                        help="Run single config. Default: run all 3.")
    parser.add_argument("--query", type=str, default=None,
                        help="Single query to route.")
    args = parser.parse_args()

    configs_to_run = (
        [ConfigName[args.config]] if args.config
        else [ConfigName.A, ConfigName.B, ConfigName.C]
    )

    queries = [(None, args.query)] if args.query else TEST_QUERIES

    for config_name in configs_to_run:
        print(f"\n{'='*70}")
        print(f"  CONFIG {config_name.name} — {config_name.value.upper()}")
        print(f"{'='*70}")

        pipeline = RouterPipeline(config_name)

        for label, query in queries:
            print(f"\n[{label or 'query'}] {query}")
            print("-" * 60)
            output = pipeline.route(query)
            print(output.summary())


if __name__ == "__main__":
    main()
