"""
Golden Dataset Evaluation — All 3 Configs (No DeBERTa required)
================================================================
Runs Config A / B / C against calibration_set_v2.jsonl and produces
a comprehensive statistics report covering:
  - Complexity detection accuracy / F1
  - Decomposition rate, parallel rate, avg sub-queries
  - Latency (mean, p50, p95, p99)
  - Cost per query and total cost
  - Per-category breakdown of complexity detection
  - Length-bucket analysis

Dataset schema detected:
  {"query": "...", "categories": ["MEDICAL", "FACTUAL_KNOWLEDGE"], "complex": true, ...}

Usage:
    cd /Users/nipundimanthahevavitharanage/Downloads/synthetic_data_generator
    python -m query_decomposition_pipeline.scripts.run_golden_evaluation
    python -m query_decomposition_pipeline.scripts.run_golden_evaluation --dataset query_complexity/results/calibration_set_v2.jsonl
    python -m query_decomposition_pipeline.scripts.run_golden_evaluation --config C
"""

import argparse
import json
import sys
import time
from collections import defaultdict
from pathlib import Path

import numpy as np
from sklearn.metrics import (
    accuracy_score, f1_score, classification_report, confusion_matrix
)

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from query_decomposition_pipeline.config import ConfigName, CONFIGS
from query_decomposition_pipeline.pipeline.router_pipeline import RouterPipeline, PipelineOutput

DEFAULT_DATASET = "query_complexity/results/calibration_set_v2.jsonl"
DEFAULT_RESULTS_DIR = "query_decomposition_pipeline/results"


# ── Data loading ──────────────────────────────────────────────────────────────

def load_dataset(path: str) -> list[dict]:
    samples = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if line:
                samples.append(json.loads(line))
    return samples


def normalize_sample(raw: dict) -> dict:
    """Adapt dataset schema to unified internal format."""
    categories = raw.get("categories") or []
    primary_category = categories[0] if categories else "UNKNOWN"

    return {
        "id": raw.get("id", ""),
        "query": raw["query"],
        "primary_category": primary_category,
        "all_categories": categories,
        "is_complex": raw.get("complex", False),
        "length_bucket": raw.get("length_bucket", "unknown"),
        "word_count": raw.get("word_count", 0),
        "num_categories": raw.get("num_categories", len(categories)),
    }


# ── Per-config evaluation ─────────────────────────────────────────────────────

def evaluate_config(pipeline: RouterPipeline, samples: list[dict], config_label: str) -> dict:
    true_complex, pred_complex = [], []
    total_latencies, decomp_latencies, plan_latencies = [], [], []
    costs = []
    decomp_flags, parallel_flags = [], []
    n_subqueries_list = []
    per_category = defaultdict(lambda: {"true": [], "pred": []})
    per_length = defaultdict(lambda: {"true": [], "pred": [], "latencies": []})
    per_num_cats = defaultdict(lambda: {"true": [], "pred": []})

    print(f"\n  Running {len(samples)} queries...")
    for i, s in enumerate(samples):
        output: PipelineOutput = pipeline.route(s["query"])

        true_c = int(s["is_complex"])
        pred_c = int(output.complexity.is_complex)
        true_complex.append(true_c)
        pred_complex.append(pred_c)

        total_latencies.append(output.total_latency_ms)
        costs.append(output.total_cost_usd)

        if output.decomposition:
            decomp_latencies.append(output.decomposition.latency_ms)
            plan_latencies.append(output.execution_plan.latency_ms if output.execution_plan else 0.0)
            n_subqueries_list.append(len(output.decomposition.sub_queries))
            decomp_flags.append(1)
        else:
            decomp_flags.append(0)

        if output.execution_plan:
            has_parallel = any(len(g.sub_query_ids) > 1 for g in output.execution_plan.groups)
            parallel_flags.append(int(has_parallel))

        cat = s["primary_category"]
        per_category[cat]["true"].append(true_c)
        per_category[cat]["pred"].append(pred_c)

        lb = s["length_bucket"]
        per_length[lb]["true"].append(true_c)
        per_length[lb]["pred"].append(pred_c)
        per_length[lb]["latencies"].append(output.total_latency_ms)

        nc = s["num_categories"]
        per_num_cats[nc]["true"].append(true_c)
        per_num_cats[nc]["pred"].append(pred_c)

        if (i + 1) % 50 == 0:
            print(f"    [{config_label}] {i+1}/{len(samples)} done...")

    # Overall metrics
    overall = {
        "config": config_label,
        "n_queries": len(samples),
        "complexity_accuracy": accuracy_score(true_complex, pred_complex),
        "complexity_f1_macro": f1_score(true_complex, pred_complex, average="macro", zero_division=0),
        "complexity_f1_binary": f1_score(true_complex, pred_complex, average="binary", zero_division=0),
        "complexity_precision": f1_score(true_complex, pred_complex, average="binary", pos_label=1, zero_division=0),
        "complexity_recall": f1_score(true_complex, pred_complex, average="binary", pos_label=1, zero_division=0),
        "true_complex_count": sum(true_complex),
        "pred_complex_count": sum(pred_complex),
        # Latency
        "avg_total_latency_ms": float(np.mean(total_latencies)),
        "median_latency_ms": float(np.median(total_latencies)),
        "p95_latency_ms": float(np.percentile(total_latencies, 95)),
        "p99_latency_ms": float(np.percentile(total_latencies, 99)),
        "min_latency_ms": float(np.min(total_latencies)),
        "max_latency_ms": float(np.max(total_latencies)),
        # Cost
        "avg_cost_usd": float(np.mean(costs)),
        "total_cost_usd": float(np.sum(costs)),
        # Decomposition
        "decomposition_rate": float(np.mean(decomp_flags)),
        "parallel_rate": float(np.mean(parallel_flags)) if parallel_flags else 0.0,
        "avg_subqueries": float(np.mean(n_subqueries_list)) if n_subqueries_list else 0.0,
        "avg_decomp_latency_ms": float(np.mean(decomp_latencies)) if decomp_latencies else 0.0,
        "avg_plan_latency_ms": float(np.mean(plan_latencies)) if plan_latencies else 0.0,
        # Classification report
        "classification_report": classification_report(true_complex, pred_complex,
                                                        target_names=["SIMPLE", "COMPLEX"],
                                                        zero_division=0),
        "confusion_matrix": confusion_matrix(true_complex, pred_complex).tolist(),
        # Breakdowns
        "per_category": {
            cat: {
                "n": len(d["true"]),
                "accuracy": accuracy_score(d["true"], d["pred"]) if d["true"] else 0.0,
                "f1": f1_score(d["true"], d["pred"], average="macro", zero_division=0) if d["true"] else 0.0,
                "true_complex_rate": float(np.mean(d["true"])) if d["true"] else 0.0,
                "pred_complex_rate": float(np.mean(d["pred"])) if d["pred"] else 0.0,
            }
            for cat, d in sorted(per_category.items())
        },
        "per_length_bucket": {
            lb: {
                "n": len(d["true"]),
                "accuracy": accuracy_score(d["true"], d["pred"]) if d["true"] else 0.0,
                "f1": f1_score(d["true"], d["pred"], average="macro", zero_division=0) if d["true"] else 0.0,
                "avg_latency_ms": float(np.mean(d["latencies"])) if d["latencies"] else 0.0,
            }
            for lb, d in sorted(per_length.items())
        },
        "per_num_categories": {
            nc: {
                "n": len(d["true"]),
                "accuracy": accuracy_score(d["true"], d["pred"]) if d["true"] else 0.0,
                "true_complex_rate": float(np.mean(d["true"])) if d["true"] else 0.0,
            }
            for nc, d in sorted(per_num_cats.items())
        },
    }

    # Fix precision/recall (recompute properly)
    from sklearn.metrics import precision_score, recall_score
    overall["complexity_precision"] = float(precision_score(true_complex, pred_complex, zero_division=0))
    overall["complexity_recall"] = float(recall_score(true_complex, pred_complex, zero_division=0))

    return overall


# ── Report printing ───────────────────────────────────────────────────────────

def print_section(title: str):
    print(f"\n{'─'*70}")
    print(f"  {title}")
    print(f"{'─'*70}")


def print_comparison_table(all_results: dict):
    configs = list(all_results.keys())
    w = 32

    print("\n" + "═"*80)
    print("  GOLDEN DATASET EVALUATION — ALL CONFIGS COMPARISON")
    print("═"*80)
    print(f"{'Metric':<{w}}", end="")
    for c in configs:
        print(f"{c:>15}", end="")
    print()
    print("─"*80)

    def row(label, attr, fmt="{:.4f}", pct=False):
        print(f"{label:<{w}}", end="")
        for c in configs:
            val = all_results[c].get(attr, 0.0)
            if pct:
                print(f"{val*100:>14.1f}%", end="")
            else:
                print(f"{fmt.format(val):>15}", end="")
        print()

    print(f"\n{'── Complexity Detection ──':<{w}}")
    row("  Accuracy",             "complexity_accuracy",  pct=True)
    row("  F1 (Macro)",           "complexity_f1_macro",  "{:.4f}")
    row("  F1 (Binary-Complex)",  "complexity_f1_binary", "{:.4f}")
    row("  Precision (Complex)",  "complexity_precision", "{:.4f}")
    row("  Recall (Complex)",     "complexity_recall",    "{:.4f}")
    row("  Predicted Complex %",  "decomposition_rate",   pct=True)
    row("  True Complex %",       "true_complex_frac",    pct=True)

    print(f"\n{'── Latency (ms) ──':<{w}}")
    row("  Mean Total",     "avg_total_latency_ms",  "{:.2f}")
    row("  Median Total",   "median_latency_ms",     "{:.2f}")
    row("  P95 Total",      "p95_latency_ms",        "{:.2f}")
    row("  P99 Total",      "p99_latency_ms",        "{:.2f}")
    row("  Max Total",      "max_latency_ms",        "{:.2f}")
    row("  Avg Decomp",     "avg_decomp_latency_ms", "{:.2f}")
    row("  Avg Plan",       "avg_plan_latency_ms",   "{:.2f}")

    print(f"\n{'── Cost ──':<{w}}")
    row("  Avg per Query ($)",  "avg_cost_usd",   "{:.8f}")
    row("  Total ($)",          "total_cost_usd", "{:.6f}")

    print(f"\n{'── Decomposition Stats ──':<{w}}")
    row("  Decomposition Rate",  "decomposition_rate",  pct=True)
    row("  Parallel Rate",       "parallel_rate",       pct=True)
    row("  Avg Sub-queries",     "avg_subqueries",      "{:.2f}")

    print("═"*80)
    print("\nConfig legend:")
    print("  Config A = Accuracy-First  (Entropy detector   + LLMCompiler + DAG planner)")
    print("  Config B = Balanced        (TF-IDF+SVM heurist + LLMCompiler + DAG planner)")
    print("  Config C = Latency-First   (TF-IDF+SVM heurist + Rule-based  + Rule-based )")


def print_per_category_table(all_results: dict):
    print_section("PER-CATEGORY COMPLEXITY DETECTION ACCURACY")
    configs = list(all_results.keys())
    all_cats = sorted({cat for r in all_results.values() for cat in r["per_category"]})
    w = 25
    print(f"{'Category':<{w}}", end="")
    print(f"{'N':>5}", end="")
    for c in configs:
        print(f"  {'Acc':>7} {'F1':>7}", end="")
    print()
    print("-"*80)
    for cat in all_cats:
        n = all_results[configs[0]]["per_category"].get(cat, {}).get("n", 0)
        print(f"{cat:<{w}}{n:>5}", end="")
        for c in configs:
            d = all_results[c]["per_category"].get(cat, {})
            acc = d.get("accuracy", 0.0) * 100
            f1  = d.get("f1", 0.0)
            print(f"  {acc:>6.1f}% {f1:>6.3f}", end="")
        print()


def print_per_length_table(all_results: dict):
    print_section("PER-LENGTH-BUCKET ANALYSIS")
    configs = list(all_results.keys())
    order = ["ultra_short", "short", "medium", "long", "very_long", "unknown"]
    all_lbs = sorted(
        {lb for r in all_results.values() for lb in r["per_length_bucket"]},
        key=lambda x: order.index(x) if x in order else 99
    )
    w = 15
    print(f"{'Length Bucket':<{w}}{'N':>5}", end="")
    for c in configs:
        print(f"  {'Acc':>7} {'LatMs':>8}", end="")
    print()
    print("-"*80)
    for lb in all_lbs:
        n = all_results[configs[0]]["per_length_bucket"].get(lb, {}).get("n", 0)
        print(f"{lb:<{w}}{n:>5}", end="")
        for c in configs:
            d = all_results[c]["per_length_bucket"].get(lb, {})
            acc = d.get("accuracy", 0.0) * 100
            lat = d.get("avg_latency_ms", 0.0)
            print(f"  {acc:>6.1f}% {lat:>7.2f}", end="")
        print()


def print_confusion_matrices(all_results: dict):
    print_section("CONFUSION MATRICES  (rows=True, cols=Pred   SIMPLE / COMPLEX)")
    for c, r in all_results.items():
        cm = r["confusion_matrix"]
        tn, fp, fn, tp = cm[0][0], cm[0][1], cm[1][0], cm[1][1]
        print(f"\n  {c}:")
        print(f"              Pred:SIMPLE  Pred:COMPLEX")
        print(f"  True:SIMPLE    {tn:>6}        {fp:>6}   (false-alarm rate {fp/(tn+fp)*100:.1f}%)" if (tn+fp) > 0 else f"  True:SIMPLE    {tn:>6}        {fp:>6}")
        print(f"  True:COMPLEX   {fn:>6}        {tp:>6}   (miss rate        {fn/(fn+tp)*100:.1f}%)" if (fn+tp) > 0 else f"  True:COMPLEX   {fn:>6}        {tp:>6}")


# ── Save results ──────────────────────────────────────────────────────────────

def save_results(all_results: dict, results_dir: Path):
    # Individual config JSON (serialisable subset)
    for c, r in all_results.items():
        out = {k: v for k, v in r.items() if k != "classification_report"}
        path = results_dir / f"golden_eval_{c.replace(' ', '_')}.json"
        with open(path, "w") as f:
            json.dump(out, f, indent=2)

    # Combined summary
    summary = {}
    for c, r in all_results.items():
        summary[c] = {
            "complexity_accuracy": round(r["complexity_accuracy"], 4),
            "complexity_f1_macro": round(r["complexity_f1_macro"], 4),
            "complexity_precision": round(r["complexity_precision"], 4),
            "complexity_recall": round(r["complexity_recall"], 4),
            "avg_total_latency_ms": round(r["avg_total_latency_ms"], 3),
            "p95_latency_ms": round(r["p95_latency_ms"], 3),
            "avg_cost_usd": round(r["avg_cost_usd"], 8),
            "total_cost_usd": round(r["total_cost_usd"], 6),
            "decomposition_rate": round(r["decomposition_rate"], 4),
            "parallel_rate": round(r["parallel_rate"], 4),
            "avg_subqueries": round(r["avg_subqueries"], 3),
        }
    path = results_dir / "golden_eval_summary.json"
    with open(path, "w") as f:
        json.dump(summary, f, indent=2)
    print(f"\n[Results] Saved to {results_dir}/")


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", default=DEFAULT_DATASET)
    parser.add_argument("--config", choices=["A", "B", "C", "all"], default="all")
    parser.add_argument("--results-dir", default=DEFAULT_RESULTS_DIR)
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args()

    results_dir = Path(args.results_dir)
    results_dir.mkdir(parents=True, exist_ok=True)

    raw_samples = load_dataset(args.dataset)
    samples = [normalize_sample(s) for s in raw_samples]

    true_complex_frac = float(np.mean([s["is_complex"] for s in samples]))
    print(f"\n[Dataset] {len(samples)} queries loaded from {args.dataset}")
    print(f"[Dataset] True complex rate: {true_complex_frac*100:.1f}%")
    print(f"[Dataset] Categories: {sorted({s['primary_category'] for s in samples})}")

    configs_to_run = (
        [ConfigName[args.config]] if args.config != "all"
        else [ConfigName.A, ConfigName.B, ConfigName.C]
    )

    all_results = {}
    for config_name in configs_to_run:
        cfg = CONFIGS[config_name]
        label = f"Config {config_name.name} ({cfg.name.value})"
        print(f"\n{'='*70}")
        print(f"  {label}")
        print(f"  detector={cfg.detector}  decomposer={cfg.decomposer}  planner={cfg.planner}")
        print(f"{'='*70}")

        pipeline = RouterPipeline(config_name)
        t0 = time.time()
        result = evaluate_config(pipeline, samples, label)
        elapsed = time.time() - t0
        result["true_complex_frac"] = true_complex_frac
        all_results[label] = result
        print(f"  Done in {elapsed:.1f}s")

    # Print reports
    print_comparison_table(all_results)
    print_per_category_table(all_results)
    print_per_length_table(all_results)
    print_confusion_matrices(all_results)

    # Per-config classification reports
    print_section("DETAILED CLASSIFICATION REPORTS")
    for c, r in all_results.items():
        print(f"\n  {c}:")
        for line in r["classification_report"].split("\n"):
            print(f"    {line}")

    save_results(all_results, results_dir)


if __name__ == "__main__":
    main()
