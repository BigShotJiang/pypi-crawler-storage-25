"""
Full evaluation — compare Config A / B / C on a labeled dataset.

Usage:
    python -m query_decomposition_pipeline.scripts.run_evaluation \
        --dataset data/final/corrected_20260211_002413.jsonl \
        --config all

Dataset must have: {"query": "...", "category": "MEDICAL", "is_complex": true/false}
If is_complex is missing, complexity metrics are skipped.
"""

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from query_decomposition_pipeline.config import ConfigName
from query_decomposition_pipeline.evaluation.evaluator import PipelineEvaluator


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", required=True, help="Path to JSONL dataset")
    parser.add_argument("--config", choices=["A", "B", "C", "all"], default="all")
    parser.add_argument("--results-dir", default="query_decomposition_pipeline/results")
    args = parser.parse_args()

    evaluator = PipelineEvaluator(results_dir=args.results_dir)

    if args.config == "all":
        evaluator.evaluate_all(args.dataset)
    else:
        evaluator.evaluate_single(ConfigName[args.config], args.dataset)


if __name__ == "__main__":
    main()
