"""Base types for execution planning."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum


class ExecutionMode(str, Enum):
    PARALLEL   = "parallel"
    SEQUENTIAL = "sequential"
    MIXED      = "mixed"     # some parallel groups, some sequential


@dataclass
class ExecutionGroup:
    """A group of sub-queries that can run in parallel within this step."""
    step: int                          # execution step index (0, 1, 2, ...)
    sub_query_ids: list[str]           # e.g. ["$1", "$2"]
    mode: ExecutionMode = ExecutionMode.PARALLEL

    def __repr__(self):
        return f"Step{self.step}({self.mode.value}: {self.sub_query_ids})"


@dataclass
class ExecutionPlan:
    """
    Ordered list of ExecutionGroups.
    Groups at the same step run in parallel.
    Groups at different steps run sequentially.

    Example — Mixed plan:
        Step 0 (parallel): [$1, $2]   ← independent, run together
        Step 1 (sequential): [$3]     ← depends on $1 and $2, runs after

    Overall mode is MIXED if there are both parallel and sequential elements.
    """
    groups: list[ExecutionGroup]
    overall_mode: ExecutionMode
    method: str                        # "dag" | "rule_based"
    latency_ms: float = 0.0

    def ordered_sub_query_ids(self) -> list[list[str]]:
        """Returns [[step0_ids], [step1_ids], ...] in execution order."""
        return [g.sub_query_ids for g in sorted(self.groups, key=lambda g: g.step)]

    def __repr__(self):
        steps = " → ".join(str(g) for g in self.groups)
        return f"ExecutionPlan({self.overall_mode.value}: {steps})"


class BaseExecutionPlanner(ABC):
    @abstractmethod
    def plan(self, sub_queries) -> ExecutionPlan:
        """Build execution plan from list of SubQuery objects."""

    @abstractmethod
    def name(self) -> str:
        pass
