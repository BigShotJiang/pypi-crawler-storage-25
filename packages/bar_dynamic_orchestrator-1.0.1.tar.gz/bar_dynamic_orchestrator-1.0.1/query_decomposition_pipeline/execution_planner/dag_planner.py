"""
DAG-Based Execution Planner
==============================
Performs topological sort on the sub-query dependency graph to determine
true parallel vs sequential execution order.

Academic basis:
    Kim et al. (2024). LLMCompiler: An LLM Compiler for Parallel Function
    Calling. ICML 2024. arXiv:2312.04511.
    [Task Fetching Unit dispatches tasks with resolved dependencies immediately
     in parallel — core mechanism reproduced here.]

    Orion (2025). Dependency-Aware Query Decomposition and Logic-Parallel
    Content Expansion. arXiv:2510.24390.
    [Explicit dependency graph modeling achieves 4.25× speedup vs 2.69×
     for blind parallelism (Skeleton-of-Thought, ICLR 2024).]

Algorithm:
    Kahn's Algorithm for topological sort (Kahn, 1962).
    All nodes with in-degree=0 at any point are placed in the SAME
    execution step (parallel group). After removing them, the next
    zero in-degree nodes form the next step. Repeat until empty.

    Time complexity: O(V + E) where V = sub-queries, E = dependencies.

Used in: Config A (Accuracy-First), Config B (Balanced)
"""

import time
from collections import defaultdict, deque

from .base import BaseExecutionPlanner, ExecutionPlan, ExecutionGroup, ExecutionMode
from ..decomposer.base import SubQuery


class DAGPlanner(BaseExecutionPlanner):
    """
    Builds a dependency graph from SubQuery.depends_on fields and
    uses Kahn's topological sort to group independent sub-queries
    into parallel execution steps.
    """

    def name(self) -> str:
        return "dag"

    def plan(self, sub_queries: list[SubQuery]) -> ExecutionPlan:
        t0 = time.perf_counter()

        if len(sub_queries) == 0:
            return ExecutionPlan(groups=[], overall_mode=ExecutionMode.SEQUENTIAL,
                                 method=self.name())

        if len(sub_queries) == 1:
            groups = [ExecutionGroup(step=0, sub_query_ids=["$1"],
                                     mode=ExecutionMode.SEQUENTIAL)]
            return ExecutionPlan(groups=groups,
                                 overall_mode=ExecutionMode.SEQUENTIAL,
                                 method=self.name(),
                                 latency_ms=(time.perf_counter() - t0) * 1000)

        groups = self._topological_groups(sub_queries)
        overall_mode = self._infer_overall_mode(groups)

        return ExecutionPlan(
            groups=groups,
            overall_mode=overall_mode,
            method=self.name(),
            latency_ms=(time.perf_counter() - t0) * 1000,
        )

    # ── Internal ──────────────────────────────────────────────────────────

    def _topological_groups(self, sub_queries: list[SubQuery]) -> list[ExecutionGroup]:
        """
        Kahn's Algorithm:
        1. Build in-degree map and adjacency list
        2. Enqueue all zero in-degree nodes (first parallel group)
        3. Process: remove node, decrement successors' in-degrees
        4. Nodes reaching in-degree 0 join the NEXT parallel group
        """
        id_set = {sq.id for sq in sub_queries}
        in_degree = {sq.id: 0 for sq in sub_queries}
        # adjacency: dependency → dependents
        adj = defaultdict(list)

        for sq in sub_queries:
            for dep in sq.depends_on:
                if dep in id_set:          # ignore references to unknown ids
                    in_degree[sq.id] += 1
                    adj[dep].append(sq.id)

        # Step 0: all nodes with in-degree == 0
        queue = deque([sid for sid, deg in in_degree.items() if deg == 0])
        groups = []
        step = 0

        while queue:
            # All nodes currently in queue belong to the same parallel step
            current_step_nodes = list(queue)
            queue.clear()

            groups.append(ExecutionGroup(
                step=step,
                sub_query_ids=current_step_nodes,
                mode=(ExecutionMode.PARALLEL
                      if len(current_step_nodes) > 1
                      else ExecutionMode.SEQUENTIAL),
            ))
            step += 1

            # Unlock dependents
            for node in current_step_nodes:
                for successor in adj[node]:
                    in_degree[successor] -= 1
                    if in_degree[successor] == 0:
                        queue.append(successor)

        return groups

    def _infer_overall_mode(self, groups: list[ExecutionGroup]) -> ExecutionMode:
        has_parallel   = any(len(g.sub_query_ids) > 1 for g in groups)
        has_sequential = len(groups) > 1

        if has_parallel and has_sequential:
            return ExecutionMode.MIXED
        if has_parallel:
            return ExecutionMode.PARALLEL
        return ExecutionMode.SEQUENTIAL
