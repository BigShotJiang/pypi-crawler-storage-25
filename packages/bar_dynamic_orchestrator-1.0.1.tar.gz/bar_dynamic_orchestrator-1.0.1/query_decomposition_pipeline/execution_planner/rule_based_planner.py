"""
Rule-Based Execution Planner
================================
Determines parallel/sequential order from SubQuery.depends_on fields
using pure Python — zero LLM calls, <0.1ms latency.

Used in: Config C (Latency-First)

Logic: If depends_on is empty → parallel group.
       If depends_on is non-empty → new sequential step.
       This is a simplified topological grouping without full Kahn's algo,
       optimised for speed over correctness on edge cases.
"""

import time
from .base import BaseExecutionPlanner, ExecutionPlan, ExecutionGroup, ExecutionMode
from ..decomposer.base import SubQuery


class RuleBasedPlanner(BaseExecutionPlanner):

    def name(self) -> str:
        return "rule_based"

    def plan(self, sub_queries: list[SubQuery]) -> ExecutionPlan:
        t0 = time.perf_counter()

        if not sub_queries:
            return ExecutionPlan(groups=[], overall_mode=ExecutionMode.SEQUENTIAL,
                                 method=self.name())

        parallel_group = []
        sequential_steps = []

        for sq in sub_queries:
            if not sq.depends_on:
                parallel_group.append(sq.id)
            else:
                sequential_steps.append([sq.id])

        groups = []
        step = 0

        if parallel_group:
            groups.append(ExecutionGroup(
                step=step,
                sub_query_ids=parallel_group,
                mode=ExecutionMode.PARALLEL if len(parallel_group) > 1
                     else ExecutionMode.SEQUENTIAL,
            ))
            step += 1

        for seq in sequential_steps:
            groups.append(ExecutionGroup(
                step=step,
                sub_query_ids=seq,
                mode=ExecutionMode.SEQUENTIAL,
            ))
            step += 1

        has_parallel   = any(len(g.sub_query_ids) > 1 for g in groups)
        has_sequential = len(groups) > 1
        if has_parallel and has_sequential:
            overall = ExecutionMode.MIXED
        elif has_parallel:
            overall = ExecutionMode.PARALLEL
        else:
            overall = ExecutionMode.SEQUENTIAL

        return ExecutionPlan(
            groups=groups,
            overall_mode=overall,
            method=self.name(),
            latency_ms=(time.perf_counter() - t0) * 1000,
        )
