"""
Configuration for the RAG Similarity Router (Approach 3).
"""

from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent.parent

VALID_CATEGORIES = [
    "REASONING", "CODE", "CREATIVE_WRITING", "FACTUAL_KNOWLEDGE",
    "INSTRUCTION_FOLLOWING", "CONVERSATIONAL", "MULTILINGUAL",
    "SUMMARIZATION", "MEDICAL", "LEGAL", "FINANCE",
]

# Embedding settings
DEFAULT_EMBEDDING_MODEL = "text-embedding-3-small"

# ChromaDB settings
CHROMA_PERSIST_DIR = str(PROJECT_ROOT / "rag_router" / "data" / "chromadb")
COLLECTION_NAME = "query_categories_v1"

# k-NN settings
DEFAULT_K = 5
# Below this, neighbors are too weak to trust
MIN_SIMILARITY_THRESHOLD = 0.5

# Ingestion settings
SEED_PER_CATEGORY = 180  # ~2,000 total across 11 categories
DEFAULT_DATASET = str(
    PROJECT_ROOT / "data" / "final" / "corrected_20260211_002413.jsonl"
)
INGESTED_IDS_PATH = str(
    PROJECT_ROOT / "rag_router" / "data" / "ingested_ids.json"
)

# Cost per 1K tokens
EMBEDDING_COST_PER_1K = {
    "text-embedding-3-small": 0.00002,
    "text-embedding-3-large": 0.00013,
}

# ── Experiment Phase Constants ─────────────────────────────

# Phase A: Retrieval Optimization (no re-embedding)
EVAL_K_VALUES = [3, 5, 10, 20]
EVAL_SIMILARITY_THRESHOLDS = [0.3, 0.5, 0.7]
EVAL_RERANKERS = [None, "ms-marco", "bge-reranker"]
EVAL_HYBRID_ALPHAS = [None, 0.5, 0.7, 0.9]

# Phase B: Data Preparation (requires re-embedding)
EVAL_EMBEDDING_MODELS = ["text-embedding-3-small", "text-embedding-3-large"]
EVAL_SEEDS_PER_CATEGORY = [100, 180, 300]

# Cross-encoder models for reranking
RERANKER_MODELS = {
    "ms-marco": "cross-encoder/ms-marco-MiniLM-L-6-v2",
    "bge-reranker": "BAAI/bge-reranker-v2-m3",
}
RERANKER_TOP_N = 20  # fetch top-N candidates before reranking to top-K

# Evaluation settings
EVAL_SAMPLE_SIZE = 500
EVAL_DATASET = DEFAULT_DATASET

# Results output
RAG_RESULTS_DIR = str(PROJECT_ROOT / "rag_router" / "results")
RAG_RESULTS_FILE = str(
    PROJECT_ROOT / "rag_router" / "results"
    / "rag_router_evaluation.json"
)
CLASSIFIER_COMPARISON_FILE = str(
    PROJECT_ROOT / "rag_router" / "results"
    / "classifier_comparison.json"
)
INGESTION_STABILITY_FILE = str(
    PROJECT_ROOT / "rag_router" / "results"
    / "ingestion_stability.json"
)

# ── Ingestion Stability (Phase D extended) ─────────────────
# 3 ingestion sizes. Collections for 180 and 300 already exist.
# 600/cat is the "max practical" size — leaves ~229/cat from CODE
# (smallest category: 829 total) for the eval set.
STABILITY_SIZES = [
    {
        "label": "180",
        "seed_per_cat": 180,
        "collection": "query_categories_v1",
    },
    {
        "label": "300",
        "seed_per_cat": 300,
        "collection": "query_categories_v1_seed300",
    },
    {
        "label": "600",
        "seed_per_cat": 600,
        "collection": "query_categories_stability_600",
    },
]
# Largest size — used to compute the shared eval exclusion set
STABILITY_MAX_SEED = 600
STABILITY_MAX_COLLECTION = "query_categories_stability_600"
