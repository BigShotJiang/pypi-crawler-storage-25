"""
CLI for the RAG Similarity Router.

Usage:
    python -m rag_router.scripts.run_router --query "What are side effects of metformin?"
    python -m rag_router.scripts.run_router --interactive
"""

import argparse
import json
import time

from rag_router.router import RAGRouter


def main():
    parser = argparse.ArgumentParser(description="RAG Similarity Router CLI")
    parser.add_argument("--query", type=str, help="Single query to route")
    parser.add_argument("--k", type=int, default=5, help="Number of neighbors")
    parser.add_argument(
        "--interactive", action="store_true", help="Interactive mode"
    )
    args = parser.parse_args()

    router = RAGRouter(k=args.k)
    print(f"RAG Router ready ({router.store.count()} documents in index, k={args.k})")

    if args.query:
        start = time.time()
        result = router.route(args.query)
        elapsed = (time.time() - start) * 1000
        print(f"\nQuery: {args.query}")
        print(f"Category: {result['final_category']}")
        print(f"Confidence: {result['category_confidence']:.2%}")
        print(f"Reasoning: {result['category_reasoning']}")
        print(f"Latency: {elapsed:.0f}ms")
        print(f"Tokens: {result['total_tokens']}")
        print(f"Cost: ${result['estimated_cost_usd']:.8f}")
        print(f"\nNeighbors:")
        for n in result["neighbors"]:
            print(f"  [{n['similarity']:.3f}] {n['category']}: {n['query_snippet']}")

    elif args.interactive:
        print("Type a query (or 'quit' to exit):\n")
        while True:
            query = input("> ").strip()
            if query.lower() in ("quit", "exit", "q"):
                break
            if not query:
                continue

            start = time.time()
            result = router.route(query)
            elapsed = (time.time() - start) * 1000

            print(f"  → {result['final_category']} ({result['category_confidence']:.1%})")
            print(f"    {result['category_reasoning']}")
            print(f"    {elapsed:.0f}ms | {result['total_tokens']} tokens | ${result['estimated_cost_usd']:.8f}\n")
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
