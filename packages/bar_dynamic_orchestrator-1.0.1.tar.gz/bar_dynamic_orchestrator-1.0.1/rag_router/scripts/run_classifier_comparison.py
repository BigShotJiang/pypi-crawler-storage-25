"""
Phase D: Classifier Head Comparison for RAG Router (Approach 3).

Compares four decision heads that all share the same:
  - Embedding model (text-embedding-3-small)
  - ChromaDB collection (1,980 training vectors)
  - Evaluation set (500 queries, seed=42, same exclusions as Phase A)

Classifiers:
  1. KNN weighted vote (k=5, threshold=0.5)  — existing baseline
  2. Logistic Regression                      — linear, probabilistic
  3. Linear SVM (CalibratedCV)               — margin-based, fast
  4. RBF SVM                                 — non-linear boundary

Data consistency guarantee
--------------------------
All classifiers train on ``collection.get(include=['embeddings'])``
which returns the exact same vectors KNN searches against.
Eval records are loaded with the same seed, sample_size, and
exclude_ids as Phase A — guaranteed by using the same
``RAGRouterEvaluator.load_dataset()`` call.

Usage:
    python -m rag_router.scripts.run_classifier_comparison
    python -m rag_router.scripts.run_classifier_comparison --sample 300
    python -m rag_router.scripts.run_classifier_comparison --classifiers logistic linear_svm
"""

import argparse
import json
import time
from datetime import datetime
from pathlib import Path

from dotenv import load_dotenv
load_dotenv(Path(__file__).parent.parent.parent / ".env")

from rag_router.config.settings import (
    CLASSIFIER_COMPARISON_FILE,
    DEFAULT_DATASET,
    DEFAULT_K,
    EVAL_SAMPLE_SIZE,
    INGESTED_IDS_PATH,
    MIN_SIMILARITY_THRESHOLD,
    RAG_RESULTS_FILE,
)
from rag_router.evaluation.evaluator import RAGRouterEvaluator
from rag_router.evaluation.metrics import (
    compute_rag_metrics,
    print_rag_metrics_report,
)
from rag_router.classifiers.sklearn_classifier import (
    CLASSIFIER_TYPES,
    SklearnClassifierRouter,
)

ALL_CLASSIFIER_NAMES = ["knn"] + CLASSIFIER_TYPES

CLASSIFIER_DESCRIPTIONS = {
    "knn": (
        "k-NN weighted majority vote "
        f"(k={DEFAULT_K}, threshold={MIN_SIMILARITY_THRESHOLD})"
    ),
    "logistic": "Logistic Regression (C=1.0, lbfgs, multinomial)",
    "linear_svm": "Linear SVM + CalibratedClassifierCV (C=1.0)",
    "rbf_svm": "RBF SVM (C=1.0, gamma=scale, probability=True)",
}


def _load_eval_records(
    dataset_path: str,
    sample_size: int,
) -> list:
    """
    Load evaluation records — identical call to Phase A.

    Uses seed=42 and excludes ingested IDs from the default collection,
    so the 500 eval queries are exactly the same across all classifiers.
    """
    evaluator = RAGRouterEvaluator()
    records = evaluator.load_dataset(
        dataset_path=dataset_path,
        sample_size=sample_size,
        seed=42,
    )
    return records


def _run_knn(records: list) -> dict:
    """Run KNN baseline (existing router, best Phase A defaults)."""
    print(f"\n--- Classifier: knn ---")
    print(f"Config: k={DEFAULT_K}, threshold={MIN_SIMILARITY_THRESHOLD}")

    evaluator = RAGRouterEvaluator(
        k=DEFAULT_K,
        similarity_threshold=MIN_SIMILARITY_THRESHOLD,
    )
    evaluation = evaluator.evaluate(records)
    metrics = evaluation["metrics"]
    meta = metrics.get("evaluation_metadata", {})
    print_rag_metrics_report(metrics)

    return {
        "name": "knn",
        "description": CLASSIFIER_DESCRIPTIONS["knn"],
        "train_samples": None,
        "fit_time_s": None,
        "accuracy": metrics.get("accuracy", 0),
        "macro_f1": metrics.get("macro_f1", 0),
        "weighted_f1": metrics.get("weighted_f1", 0),
        "precision_macro": metrics.get("precision_macro", 0),
        "recall_macro": metrics.get("recall_macro", 0),
        "per_category": metrics.get("per_category", {}),
        "avg_latency_ms": meta.get("avg_latency_ms", 0),
        "total_cost_usd": meta.get("total_cost_usd", 0),
        "total_tokens": meta.get("total_tokens", 0),
    }


def _run_sklearn_classifier(
    clf_type: str,
    records: list,
) -> dict:
    """Fit a sklearn classifier on ChromaDB vectors and evaluate."""
    print(f"\n--- Classifier: {clf_type} ---")
    print(f"Config: {CLASSIFIER_DESCRIPTIONS[clf_type]}")

    router = SklearnClassifierRouter(classifier_type=clf_type)

    # Fit on the ChromaDB training vectors
    print("Fitting on ChromaDB embeddings...")
    t0 = time.time()
    n_train = router.fit()
    fit_time = round(time.time() - t0, 2)
    print(f"Fitted on {n_train} training vectors in {fit_time}s")

    # Evaluate on the same eval records
    results = []
    total_cost = 0.0
    total_tokens = 0
    start = time.time()

    for i, record in enumerate(records):
        query = record["query"]
        truth = record["category"]
        try:
            result = router.route(query)
            result["ground_truth_category"] = truth
            result["similarity_threshold"] = MIN_SIMILARITY_THRESHOLD
            total_cost += result.get("estimated_cost_usd", 0) or 0
            total_tokens += result.get("total_tokens", 0) or 0
        except Exception as e:
            result = {
                "query": query,
                "final_category": "ERROR",
                "ground_truth_category": truth,
                "error": str(e),
                "category_confidence": 0.0,
                "latency_ms": 0,
                "neighbors": [],
            }
        results.append(result)

        if (i + 1) % 50 == 0:
            elapsed = time.time() - start
            correct = sum(
                1 for r in results
                if r.get("final_category") == r.get("ground_truth_category")
            )
            print(
                f"  [{i+1}/{len(records)}] "
                f"Acc: {correct / len(results) * 100:.1f}% | "
                f"Rate: {(i+1)/elapsed:.1f} q/s"
            )

    metrics = compute_rag_metrics(results)
    avg_latency = (
        sum(r.get("latency_ms", 0) for r in results) / len(results)
        if results else 0
    )
    print_rag_metrics_report(metrics)

    return {
        "name": clf_type,
        "description": CLASSIFIER_DESCRIPTIONS[clf_type],
        "train_samples": n_train,
        "fit_time_s": fit_time,
        "accuracy": metrics.get("accuracy", 0),
        "macro_f1": metrics.get("macro_f1", 0),
        "weighted_f1": metrics.get("weighted_f1", 0),
        "precision_macro": metrics.get("precision_macro", 0),
        "recall_macro": metrics.get("recall_macro", 0),
        "per_category": metrics.get("per_category", {}),
        "avg_latency_ms": round(avg_latency, 1),
        "total_cost_usd": round(total_cost, 6),
        "total_tokens": total_tokens,
    }


def run_classifier_comparison(
    dataset_path: str = DEFAULT_DATASET,
    sample_size: int = EVAL_SAMPLE_SIZE,
    classifiers: list | None = None,
) -> dict:
    """
    Run all classifier heads on the same eval set and save results.

    Resumes automatically: already-completed classifiers in the existing
    classifier_comparison.json are kept as-is and skipped. Only missing
    or explicitly requested classifiers are re-run.

    Args:
        dataset_path: Path to labeled JSONL
        sample_size:  Number of eval queries (same as Phase A)
        classifiers:  Subset of classifiers to run (default: all 4)
    """
    if classifiers is None:
        classifiers = ALL_CLASSIFIER_NAMES

    # Load existing results so we never overwrite completed runs
    out_path = Path(CLASSIFIER_COMPARISON_FILE)
    if out_path.exists():
        with open(out_path) as f:
            existing_output = json.load(f)
        existing_experiments = {
            e["name"]: e
            for e in existing_output.get("experiments", [])
        }
    else:
        existing_output = None
        existing_experiments = {}

    # Determine which classifiers still need to run
    pending = [c for c in classifiers if c not in existing_experiments]
    skipped = [c for c in classifiers if c in existing_experiments]

    print("\n" + "=" * 70)
    print("PHASE D: CLASSIFIER HEAD COMPARISON")
    print("=" * 70)
    if skipped:
        print(f"Skipping (already done): {skipped}")
    if pending:
        print(f"Running: {pending}")
    else:
        print("All classifiers already complete — nothing to run.")
    print(
        "Data: same ChromaDB collection (180/cat) + same eval set (seed=42)"
    )

    # Load eval records only if there's something to run
    records = None
    if pending:
        print("\nLoading evaluation records...")
        records = _load_eval_records(dataset_path, sample_size)
        print(f"Eval set: {len(records)} queries (fixed, seed=42)")

    # Run only the pending classifiers
    new_experiments = []
    for clf_name in pending:
        if clf_name == "knn":
            result = _run_knn(records)
        else:
            result = _run_sklearn_classifier(clf_name, records)
        new_experiments.append(result)

    # Merge: keep existing results, add new ones
    # Preserve original ordering (ALL_CLASSIFIER_NAMES order)
    merged = {**existing_experiments}
    for exp in new_experiments:
        merged[exp["name"]] = exp
    experiments = [
        merged[name]
        for name in ALL_CLASSIFIER_NAMES
        if name in merged
    ]

    eval_size = (
        len(records) if records is not None
        else (existing_output or {}).get("eval_sample_size", sample_size)
    )

    # Build output — preserve top-level metadata if nothing new ran
    output = {
        "timestamp": datetime.now().isoformat(),
        "dataset_path": dataset_path,
        "eval_sample_size": eval_size,
        "train_collection": "query_categories_v1 (180/cat × 11)",
        "embedding_model": "text-embedding-3-small",
        "data_consistency_note": (
            "All classifiers trained on identical ChromaDB vectors. "
            "Eval queries loaded with seed=42, same exclude_ids as Phase A."
        ),
        "experiments": experiments,
    }

    # Save standalone file (out_path already set above)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w") as f:
        json.dump(output, f, indent=2)
    print(f"\nSaved to: {out_path}")

    # Merge into existing rag_router_evaluation.json (non-destructive)
    main_path = Path(RAG_RESULTS_FILE)
    if main_path.exists():
        with open(main_path) as f:
            existing = json.load(f)
    else:
        existing = {
            "timestamp": datetime.now().isoformat(),
            "dataset_path": dataset_path,
            "sample_size": sample_size,
            "phases": {},
        }

    existing["phases"]["classifier_comparison"] = {
        "phase": "D",
        "description": "Classifier head comparison (KNN vs LR vs LinearSVM vs RBF SVM)",
        "fixed": {
            "embedding_model": "text-embedding-3-small",
            "collection": "query_categories_v1 (180/cat × 11 = 1980 train)",
            "eval_size": len(records),
            "eval_seed": 42,
        },
        "experiments": experiments,
    }

    with open(main_path, "w") as f:
        json.dump(existing, f, indent=2)
    print(f"Merged into: {main_path}")

    # Summary table
    print("\n" + "=" * 70)
    print("RESULTS SUMMARY")
    print("=" * 70)
    header = f"{'Classifier':<14} {'F1 Macro':>10} {'Accuracy':>10} {'Latency':>10} {'Cost ($)':>10}"
    print(header)
    print("-" * 60)
    for e in sorted(experiments, key=lambda x: x["macro_f1"], reverse=True):
        print(
            f"{e['name']:<14} "
            f"{e['macro_f1']*100:>9.2f}% "
            f"{e['accuracy']*100:>9.2f}% "
            f"{e['avg_latency_ms']:>8.1f}ms "
            f"{e['total_cost_usd']:>10.4f}"
        )

    return output


def main():
    parser = argparse.ArgumentParser(
        description="Phase D: RAG Classifier Head Comparison"
    )
    parser.add_argument(
        "--dataset", default=DEFAULT_DATASET,
        help="Path to labeled JSONL",
    )
    parser.add_argument(
        "--sample", type=int, default=EVAL_SAMPLE_SIZE,
        help="Eval queries (default: same as Phase A)",
    )
    parser.add_argument(
        "--classifiers",
        nargs="+",
        choices=ALL_CLASSIFIER_NAMES,
        default=None,
        help="Which classifiers to run (default: all)",
    )
    args = parser.parse_args()

    run_classifier_comparison(
        dataset_path=args.dataset,
        sample_size=args.sample,
        classifiers=args.classifiers,
    )


if __name__ == "__main__":
    main()
