"""
Ingestion script: Load labeled JSONL dataset into ChromaDB.

Usage:
    python -m rag_router.scripts.ingest
    python -m rag_router.scripts.ingest --dataset path/to/data.jsonl --seed-per-category 200
    python -m rag_router.scripts.ingest --reset  # clear and re-ingest
"""

import argparse
import json
import random
from collections import defaultdict
from pathlib import Path

from dotenv import load_dotenv
load_dotenv(Path(__file__).parent.parent.parent / ".env")

from rag_router.config.settings import (
    DEFAULT_DATASET,
    INGESTED_IDS_PATH,
    SEED_PER_CATEGORY,
    VALID_CATEGORIES,
)
from rag_router.store.chroma_store import ChromaStore
from rag_router.store.embeddings import EmbeddingClient


def load_and_sample(
    dataset_path: str,
    seed_per_category: int,
    seed: int = 42,
) -> list[dict]:
    """Load JSONL and take a stratified sample."""
    by_category = defaultdict(list)

    with open(dataset_path, "r") as f:
        for line in f:
            record = json.loads(line)
            cat = record.get("category", "")
            if cat in VALID_CATEGORIES:
                by_category[cat].append(record)

    random.seed(seed)
    sampled = []
    for cat in VALID_CATEGORIES:
        pool = by_category[cat]
        n = min(seed_per_category, len(pool))
        sampled.extend(random.sample(pool, n))

    random.shuffle(sampled)
    return sampled


def ingest(
    dataset_path: str = DEFAULT_DATASET,
    seed_per_category: int = SEED_PER_CATEGORY,
    reset: bool = False,
):
    print(f"Loading dataset: {dataset_path}")
    records = load_and_sample(dataset_path, seed_per_category)
    print(f"Sampled {len(records)} records ({seed_per_category} per category)")

    # Count per category
    counts = defaultdict(int)
    for r in records:
        counts[r["category"]] += 1
    for cat in VALID_CATEGORIES:
        print(f"  {cat}: {counts[cat]}")

    # Init store
    store = ChromaStore()
    if reset:
        print("Resetting collection...")
        store.reset()

    existing = store.count()
    if existing > 0 and not reset:
        print(f"Collection already has {existing} documents. Use --reset to re-ingest.")
        return

    # Embed all queries
    print("Embedding queries...")
    queries = [r["query"] for r in records]
    embedding_client = EmbeddingClient()
    vectors, total_tokens = embedding_client.embed_batch(queries)
    cost = embedding_client.estimate_cost(total_tokens)
    print(f"Embedded {len(queries)} queries: {total_tokens} tokens, ${cost:.6f}")

    # Insert into ChromaDB
    print("Inserting into ChromaDB...")
    ids = [r["id"] for r in records]
    metadatas = [{"category": r["category"]} for r in records]
    store.add_documents(
        ids=ids,
        documents=queries,
        embeddings=vectors,
        metadatas=metadatas,
    )
    print(f"Inserted {store.count()} documents")

    # Save ingested IDs for evaluation exclusion
    ids_path = Path(INGESTED_IDS_PATH)
    ids_path.parent.mkdir(parents=True, exist_ok=True)
    with open(ids_path, "w") as f:
        json.dump(ids, f)
    print(f"Saved {len(ids)} ingested IDs to {ids_path}")

    print("\nDone!")


def main():
    parser = argparse.ArgumentParser(description="Ingest labeled data into ChromaDB")
    parser.add_argument(
        "--dataset", default=DEFAULT_DATASET, help="Path to labeled JSONL"
    )
    parser.add_argument(
        "--seed-per-category",
        type=int,
        default=SEED_PER_CATEGORY,
        help="Examples per category",
    )
    parser.add_argument(
        "--reset", action="store_true", help="Clear existing collection"
    )
    args = parser.parse_args()

    ingest(
        dataset_path=args.dataset,
        seed_per_category=args.seed_per_category,
        reset=args.reset,
    )


if __name__ == "__main__":
    main()
