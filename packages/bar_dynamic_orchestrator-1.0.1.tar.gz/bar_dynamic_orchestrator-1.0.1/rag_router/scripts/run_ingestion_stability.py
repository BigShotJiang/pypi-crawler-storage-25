"""
Phase D Extended: Ingestion Size Stability Analysis for RAG Router.

Tests whether the classifier ranking is stable across different
knowledge-base sizes (180 / 300 / 600 examples per category).

Data consistency guarantee
--------------------------
All three ingestion sizes use the EXACT SAME 500-query evaluation set.
The eval set is built by excluding IDs from the LARGEST collection
(600/cat) so no eval query ever appears in any training collection.
The seed is fixed at 42 so the same 500 queries are drawn every run.

Existing data safety
--------------------
- classifier_comparison.json  →  NEVER touched
- ingestion_stability.json    →  append-only; completed (size, clf)
  pairs are detected and skipped automatically

Collections
-----------
  180/cat: query_categories_v1          (1 980 docs — already exists)
  300/cat: query_categories_v1_seed300  (3 300 docs — already exists)
  600/cat: query_categories_stability_600 (6 600 docs — created if absent)

Usage:
    python -m rag_router.scripts.run_ingestion_stability
    python -m rag_router.scripts.run_ingestion_stability --sizes 300 600
    python -m rag_router.scripts.run_ingestion_stability \
        --classifiers logistic linear_svm
"""

import argparse
import json
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv

load_dotenv(Path(__file__).parent.parent.parent / ".env")

from rag_router.config.settings import (  # noqa: E402
    DEFAULT_DATASET,
    DEFAULT_K,
    EVAL_SAMPLE_SIZE,
    INGESTION_STABILITY_FILE,
    MIN_SIMILARITY_THRESHOLD,
    STABILITY_MAX_COLLECTION,
    STABILITY_MAX_SEED,
    STABILITY_SIZES,
)
from rag_router.classifiers.sklearn_classifier import (  # noqa: E402
    CLASSIFIER_TYPES,
    SklearnClassifierRouter,
)
from rag_router.evaluation.evaluator import (  # noqa: E402
    RAGRouterEvaluator,
)
from rag_router.evaluation.metrics import (  # noqa: E402
    compute_rag_metrics,
    print_rag_metrics_report,
)
from rag_router.scripts.ingest import load_and_sample  # noqa: E402

ALL_CLASSIFIER_NAMES = ["knn"] + CLASSIFIER_TYPES

CLASSIFIER_DESCRIPTIONS = {
    "knn": (
        f"k-NN weighted majority vote "
        f"(k={DEFAULT_K}, threshold={MIN_SIMILARITY_THRESHOLD})"
    ),
    "logistic":    "Logistic Regression (C=1.0, lbfgs)",
    "linear_svm":  "Linear SVM + CalibratedClassifierCV (C=1.0)",
    "rbf_svm":     "RBF SVM (C=1.0, gamma=scale)",
}


# ── Ingestion helper ──────────────────────────────────────────────

def _ensure_collection(
    dataset_path: str,
    seed_per_cat: int,
    collection_name: str,
) -> int:
    """
    Ingest into collection if it does not exist yet.

    Returns the final document count.
    """
    from rag_router.store.chroma_store import ChromaStore
    from rag_router.store.embeddings import EmbeddingClient

    store = ChromaStore(collection_name=collection_name)
    existing = store.count()
    if existing > 0:
        print(
            f"Collection '{collection_name}' already has "
            f"{existing} docs — skipping ingestion."
        )
        return existing

    print(
        f"Ingesting '{collection_name}' "
        f"({seed_per_cat}/cat × 11 categories)..."
    )
    records = load_and_sample(dataset_path, seed_per_cat)
    queries = [r["query"] for r in records]
    ids = [r["id"] for r in records]
    metadatas = [{"category": r["category"]} for r in records]

    client = EmbeddingClient()
    vectors, tokens = client.embed_batch(queries)
    cost = client.estimate_cost(tokens)
    print(f"Embedded {len(queries)} queries: {tokens} tokens, ${cost:.6f}")

    batch_size = 5000
    for start in range(0, len(ids), batch_size):
        end = start + batch_size
        store.add_documents(
            ids=ids[start:end],
            documents=queries[start:end],
            embeddings=vectors[start:end],
            metadatas=metadatas[start:end],
        )
        actual = min(end, len(ids))
        print(f"  Inserted batch {start}–{end} ({actual}/{len(ids)})")
    n = store.count()
    print(f"Inserted {n} documents into '{collection_name}'")
    return n


# ── Fixed eval set ────────────────────────────────────────────────

def _build_eval_set(
    dataset_path: str,
    sample_size: int,
) -> list:
    """
    Build the shared evaluation set for ALL ingestion sizes.

    Excludes IDs from the LARGEST planned collection (600/cat) so
    that no eval query ever leaks into any training collection.
    seed=42 guarantees the same 500 queries on every run.
    """
    # Reproduce the IDs that were / will be ingested at max size
    max_records = load_and_sample(dataset_path, STABILITY_MAX_SEED)
    max_ids = {r["id"] for r in max_records}
    print(
        f"Eval exclusion set: {len(max_ids)} IDs "
        f"(from {STABILITY_MAX_SEED}/cat ingestion)"
    )

    evaluator = RAGRouterEvaluator()
    records = evaluator.load_dataset(
        dataset_path=dataset_path,
        sample_size=sample_size,
        seed=42,
        exclude_ids=list(max_ids),
    )
    return records


# ── Single-classifier runners ─────────────────────────────────────

def _run_knn(records: list, collection_name: str) -> dict:
    evaluator = RAGRouterEvaluator(
        k=DEFAULT_K,
        similarity_threshold=MIN_SIMILARITY_THRESHOLD,
        collection_name=collection_name,
    )
    evaluation = evaluator.evaluate(records)
    metrics = evaluation["metrics"]
    meta = metrics.get("evaluation_metadata", {})
    print_rag_metrics_report(metrics)
    return {
        "name": "knn",
        "description": CLASSIFIER_DESCRIPTIONS["knn"],
        "train_samples": None,
        "fit_time_s": None,
        "accuracy": metrics.get("accuracy", 0),
        "macro_f1": metrics.get("macro_f1", 0),
        "weighted_f1": metrics.get("weighted_f1", 0),
        "precision_macro": metrics.get("precision_macro", 0),
        "recall_macro": metrics.get("recall_macro", 0),
        "per_category": metrics.get("per_category", {}),
        "avg_latency_ms": meta.get("avg_latency_ms", 0),
        "total_cost_usd": meta.get("total_cost_usd", 0),
        "total_tokens": meta.get("total_tokens", 0),
    }


def _run_sklearn(
    clf_type: str,
    records: list,
    collection_name: str,
) -> dict:
    router = SklearnClassifierRouter(
        classifier_type=clf_type,
        collection_name=collection_name,
    )

    print("Fitting on ChromaDB embeddings...")
    t0 = time.time()
    n_train = router.fit()
    fit_time = round(time.time() - t0, 2)
    print(f"Fitted on {n_train} vectors in {fit_time}s")

    results = []
    total_cost = 0.0
    total_tokens = 0
    start = time.time()

    for i, record in enumerate(records):
        query = record["query"]
        truth = record["category"]
        try:
            result = router.route(query)
            result["ground_truth_category"] = truth
            result["similarity_threshold"] = MIN_SIMILARITY_THRESHOLD
            total_cost += result.get("estimated_cost_usd", 0) or 0
            total_tokens += result.get("total_tokens", 0) or 0
        except Exception as e:
            result = {
                "query": query,
                "final_category": "ERROR",
                "ground_truth_category": truth,
                "error": str(e),
                "category_confidence": 0.0,
                "latency_ms": 0,
                "neighbors": [],
            }
        results.append(result)

        if (i + 1) % 50 == 0:
            elapsed = time.time() - start
            correct = sum(
                1 for r in results
                if r.get("final_category") == r.get("ground_truth_category")
            )
            print(
                f"  [{i+1}/{len(records)}] "
                f"Acc: {correct/len(results)*100:.1f}% | "
                f"Rate: {(i+1)/elapsed:.1f} q/s"
            )

    metrics = compute_rag_metrics(results)
    avg_latency = (
        sum(r.get("latency_ms", 0) for r in results) / len(results)
        if results else 0
    )
    print_rag_metrics_report(metrics)

    return {
        "name": clf_type,
        "description": CLASSIFIER_DESCRIPTIONS[clf_type],
        "train_samples": n_train,
        "fit_time_s": fit_time,
        "accuracy": metrics.get("accuracy", 0),
        "macro_f1": metrics.get("macro_f1", 0),
        "weighted_f1": metrics.get("weighted_f1", 0),
        "precision_macro": metrics.get("precision_macro", 0),
        "recall_macro": metrics.get("recall_macro", 0),
        "per_category": metrics.get("per_category", {}),
        "avg_latency_ms": round(avg_latency, 1),
        "total_cost_usd": round(total_cost, 6),
        "total_tokens": total_tokens,
    }


# ── Load / save helpers ───────────────────────────────────────────

def _load_existing() -> dict:
    path = Path(INGESTION_STABILITY_FILE)
    if path.exists():
        with open(path) as f:
            return json.load(f)
    return {}


def _save(data: dict):
    path = Path(INGESTION_STABILITY_FILE)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


# ── Main orchestrator ─────────────────────────────────────────────

def run_ingestion_stability(
    dataset_path: str = DEFAULT_DATASET,
    sample_size: int = EVAL_SAMPLE_SIZE,
    sizes: Optional[list] = None,
    classifiers: Optional[list] = None,
) -> dict:
    """
    Run classifier comparison for each ingestion size.

    Args:
        dataset_path: Path to labeled JSONL
        sample_size:  Eval queries (same 500 for all sizes)
        sizes:        Subset of size labels to run, e.g. ["300", "600"]
        classifiers:  Subset of classifiers, e.g. ["logistic", "knn"]
    """
    target_sizes = [
        s for s in STABILITY_SIZES
        if sizes is None or s["label"] in sizes
    ]
    target_classifiers = classifiers or ALL_CLASSIFIER_NAMES

    print("\n" + "=" * 70)
    print("PHASE D EXTENDED: INGESTION SIZE STABILITY")
    print("=" * 70)
    print(
        f"Sizes:       {[s['label'] for s in target_sizes]} per category"
    )
    print(f"Classifiers: {target_classifiers}")
    print(
        "Eval set:    500 queries, seed=42, excludes 600/cat IDs (all sizes)"
    )

    # Load existing results — never overwrite completed entries
    existing = _load_existing()
    by_size = existing.get("by_size", {})

    # Step 1: ensure all needed collections exist (ingest only if absent)
    print("\n--- Checking / Ingesting Collections ---")
    for size_cfg in target_sizes:
        _ensure_collection(
            dataset_path,
            size_cfg["seed_per_cat"],
            size_cfg["collection"],
        )
    # Also ensure the max collection exists (for eval exclusion)
    max_cfg = next(
        s for s in STABILITY_SIZES if s["label"] == str(STABILITY_MAX_SEED)
    )
    _ensure_collection(
        dataset_path,
        max_cfg["seed_per_cat"],
        max_cfg["collection"],
    )

    # Step 2: build the shared eval set ONCE
    print("\n--- Building Shared Evaluation Set ---")
    eval_records = _build_eval_set(dataset_path, sample_size)
    print(f"Eval set ready: {len(eval_records)} queries")

    # Step 3: run experiments — skip completed (size, classifier) pairs
    for size_cfg in target_sizes:
        label = size_cfg["label"]
        collection = size_cfg["collection"]
        seed_per_cat = size_cfg["seed_per_cat"]

        if label not in by_size:
            by_size[label] = {
                "seed_per_cat": seed_per_cat,
                "collection": collection,
                "total_train": seed_per_cat * 11,
                "experiments": {},
            }

        done = set(by_size[label]["experiments"].keys())
        pending = [c for c in target_classifiers if c not in done]
        skipped = [c for c in target_classifiers if c in done]

        print(f"\n{'='*60}")
        print(f"Size: {label}/cat  |  Collection: {collection}")
        if skipped:
            print(f"  Skipping (done): {skipped}")
        if not pending:
            print("  All classifiers complete for this size.")
            continue
        print(f"  Running: {pending}")

        for clf_name in pending:
            print(f"\n--- [{label}/cat] Classifier: {clf_name} ---")
            try:
                if clf_name == "knn":
                    result = _run_knn(eval_records, collection)
                else:
                    result = _run_sklearn(clf_name, eval_records, collection)

                by_size[label]["experiments"][clf_name] = result

                # Save after EVERY classifier — no data lost on crash
                existing["by_size"] = by_size
                existing.setdefault(
                    "timestamp", datetime.now().isoformat()
                )
                existing["eval_sample_size"] = len(eval_records)
                existing["eval_seed"] = 42
                existing["eval_exclusion"] = (
                    f"IDs from {STABILITY_MAX_SEED}/cat ingestion "
                    f"(collection: {STABILITY_MAX_COLLECTION})"
                )
                existing["data_note"] = (
                    "All sizes share the same eval set. "
                    "Existing classifier_comparison.json is untouched."
                )
                _save(existing)
                print(f"  Saved [{label}/cat, {clf_name}]")

            except Exception as e:
                print(f"  ERROR [{label}/cat, {clf_name}]: {e}")
                # Don't crash the whole run — continue with next

    # Final summary
    print("\n" + "=" * 70)
    print("STABILITY SUMMARY  (F1 Macro %)")
    print("=" * 70)
    clf_order = [c for c in ALL_CLASSIFIER_NAMES if c in target_classifiers]
    header = f"{'Classifier':<14}" + "".join(
        f"  {s['label']:>8}/cat" for s in STABILITY_SIZES
        if s["label"] in by_size
    )
    print(header)
    print("-" * len(header))
    for clf in clf_order:
        row = f"{clf:<14}"
        for size_cfg in STABILITY_SIZES:
            lbl = size_cfg["label"]
            if lbl not in by_size:
                continue
            exp = by_size[lbl]["experiments"].get(clf)
            if exp:
                row += f"  {exp['macro_f1']*100:>8.2f}%"
            else:
                row += f"  {'—':>8}"
        print(row)

    return existing


def main():
    parser = argparse.ArgumentParser(
        description="Phase D Extended: Ingestion Size Stability"
    )
    parser.add_argument(
        "--dataset", default=DEFAULT_DATASET,
        help="Path to labeled JSONL",
    )
    parser.add_argument(
        "--sample", type=int, default=EVAL_SAMPLE_SIZE,
        help="Eval queries per experiment",
    )
    parser.add_argument(
        "--sizes",
        nargs="+",
        choices=[s["label"] for s in STABILITY_SIZES],
        default=None,
        help="Which ingestion sizes to run (default: all)",
    )
    parser.add_argument(
        "--classifiers",
        nargs="+",
        choices=ALL_CLASSIFIER_NAMES,
        default=None,
        help="Which classifiers to run (default: all)",
    )
    args = parser.parse_args()

    run_ingestion_stability(
        dataset_path=args.dataset,
        sample_size=args.sample,
        sizes=args.sizes,
        classifiers=args.classifiers,
    )


if __name__ == "__main__":
    main()
