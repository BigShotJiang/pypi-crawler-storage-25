"""
3-phase cascading experiment pipeline for RAG Router.

Phase A: Retrieval Optimization (no re-embedding)
  A1: K value sweep [3, 5, 10, 20]
  A2: Similarity threshold sweep [0.3, 0.5, 0.7]
  A3: Reranker [none, ms-marco, bge-reranker]
  A4: Hybrid search [vector-only, alpha=0.5/0.7/0.9]

Phase B: Data Preparation (requires re-ingestion)
  B1: Embedding model [small, large]
  B2: Seed per category [100, 180, 300]

Phase C: Best Combination
  Combine best from A + B, run final evaluation.

Usage:
    python -m rag_router.scripts.run_experiments
    python -m rag_router.scripts.run_experiments --phase A
    python -m rag_router.scripts.run_experiments --sample 200
    python -m rag_router.scripts.run_experiments --resume
"""

import argparse
import json
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from dotenv import load_dotenv
load_dotenv(
    Path(__file__).parent.parent.parent / ".env"
)

from rag_router.config.settings import (
    DEFAULT_DATASET,
    DEFAULT_EMBEDDING_MODEL,
    DEFAULT_K,
    EVAL_EMBEDDING_MODELS,
    EVAL_HYBRID_ALPHAS,
    EVAL_K_VALUES,
    EVAL_RERANKERS,
    EVAL_SAMPLE_SIZE,
    EVAL_SEEDS_PER_CATEGORY,
    EVAL_SIMILARITY_THRESHOLDS,
    INGESTED_IDS_PATH,
    MIN_SIMILARITY_THRESHOLD,
    RAG_RESULTS_DIR,
    RAG_RESULTS_FILE,
    SEED_PER_CATEGORY,
)
from rag_router.evaluation.evaluator import (
    RAGRouterEvaluator,
)
from rag_router.evaluation.metrics import (
    print_rag_metrics_report,
)


def _extract_experiment(
    evaluation: Dict, name: str, config: Dict
) -> Dict:
    """Extract experiment summary from evaluation."""
    m = evaluation["metrics"]
    meta = m.get("evaluation_metadata", {})
    return {
        "name": name,
        "config": config,
        "accuracy": m.get("accuracy", 0),
        "macro_f1": m.get("macro_f1", 0),
        "weighted_f1": m.get("weighted_f1", 0),
        "per_category": m.get("per_category", {}),
        "confusion_matrix": m.get(
            "confusion_matrix", {}
        ),
        "rag_stats": m.get("rag_stats", {}),
        "confidence_stats": m.get(
            "confidence_stats", {}
        ),
        "avg_latency_ms": meta.get(
            "avg_latency_ms", 0
        ),
        "total_cost_usd": meta.get(
            "total_cost_usd", 0
        ),
        "total_tokens": meta.get("total_tokens", 0),
        "avg_confidence": meta.get(
            "avg_confidence", 0
        ),
    }


def _best_experiment(
    experiments: List[Dict],
) -> Dict:
    """Pick the best experiment by macro_f1."""
    return max(experiments, key=lambda x: x["macro_f1"])


def _run_single(
    config: Dict,
    records: List[Dict],
    name: str,
    progress_callback: Optional[Callable] = None,
) -> Dict:
    """Run a single experiment and return summary."""
    print(f"\n--- Experiment: {name} ---")
    evaluator = RAGRouterEvaluator(**config)
    evaluation = evaluator.evaluate(
        records, progress_callback=progress_callback
    )
    evaluator.save_evaluation(
        evaluation,
        output_dir=RAG_RESULTS_DIR,
        experiment_name=name,
    )
    print_rag_metrics_report(evaluation["metrics"])
    return _extract_experiment(
        evaluation, name, config
    )


def run_phase_a(
    records: List[Dict],
    progress_callback: Optional[Callable] = None,
) -> Dict:
    """
    Phase A: Retrieval Optimization.

    4 sub-experiments, each cascading from previous best.
    """
    print("\n" + "=" * 70)
    print("PHASE A: RETRIEVAL OPTIMIZATION")
    print("=" * 70)

    phase_data = {"phase": "A", "subphases": {}}

    # A1: K sweep
    print("\n--- A1: K Value Sweep ---")
    a1_experiments = []
    for k in EVAL_K_VALUES:
        config = {
            "k": k,
            "similarity_threshold": (
                MIN_SIMILARITY_THRESHOLD
            ),
        }
        result = _run_single(
            config, records, f"k={k}",
            progress_callback,
        )
        a1_experiments.append(result)

    phase_data["subphases"]["k_sweep"] = {
        "fixed": {
            "threshold": MIN_SIMILARITY_THRESHOLD,
            "reranker": None,
            "hybrid": None,
        },
        "experiments": a1_experiments,
    }
    best_k = _best_experiment(a1_experiments)
    best_k_val = best_k["config"]["k"]
    print(
        f"\n>> Best K: {best_k_val} "
        f"(F1={best_k['macro_f1']:.4f})"
    )

    # A2: Threshold sweep
    print("\n--- A2: Threshold Sweep ---")
    a2_experiments = []
    for thr in EVAL_SIMILARITY_THRESHOLDS:
        config = {
            "k": best_k_val,
            "similarity_threshold": thr,
        }
        result = _run_single(
            config, records,
            f"threshold={thr}",
            progress_callback,
        )
        a2_experiments.append(result)

    phase_data["subphases"]["threshold_sweep"] = {
        "fixed": {
            "k": best_k_val,
            "reranker": None,
            "hybrid": None,
        },
        "experiments": a2_experiments,
    }
    best_thr = _best_experiment(a2_experiments)
    best_thr_val = best_thr["config"][
        "similarity_threshold"
    ]
    print(
        f"\n>> Best threshold: {best_thr_val} "
        f"(F1={best_thr['macro_f1']:.4f})"
    )

    # A3: Reranker
    print("\n--- A3: Reranker Comparison ---")
    a3_experiments = []
    for reranker in EVAL_RERANKERS:
        config = {
            "k": best_k_val,
            "similarity_threshold": best_thr_val,
            "reranker": reranker,
        }
        name = reranker or "no_reranker"
        result = _run_single(
            config, records, f"reranker={name}",
            progress_callback,
        )
        a3_experiments.append(result)

    phase_data["subphases"]["reranker"] = {
        "fixed": {
            "k": best_k_val,
            "threshold": best_thr_val,
            "hybrid": None,
        },
        "experiments": a3_experiments,
    }
    best_rr = _best_experiment(a3_experiments)
    best_rr_val = best_rr["config"].get("reranker")
    print(
        f"\n>> Best reranker: {best_rr_val or 'none'} "
        f"(F1={best_rr['macro_f1']:.4f})"
    )

    # A4: Hybrid search
    print("\n--- A4: Hybrid Search ---")
    a4_experiments = []
    for alpha in EVAL_HYBRID_ALPHAS:
        config = {
            "k": best_k_val,
            "similarity_threshold": best_thr_val,
            "reranker": best_rr_val,
            "hybrid_alpha": alpha,
        }
        name = (
            f"hybrid_alpha={alpha}"
            if alpha is not None
            else "vector_only"
        )
        result = _run_single(
            config, records, name,
            progress_callback,
        )
        a4_experiments.append(result)

    phase_data["subphases"]["hybrid_search"] = {
        "fixed": {
            "k": best_k_val,
            "threshold": best_thr_val,
            "reranker": best_rr_val,
        },
        "experiments": a4_experiments,
    }
    best_hybrid = _best_experiment(a4_experiments)
    best_alpha = best_hybrid["config"].get(
        "hybrid_alpha"
    )
    print(
        f"\n>> Best hybrid: "
        f"alpha={best_alpha or 'none'} "
        f"(F1={best_hybrid['macro_f1']:.4f})"
    )

    phase_data["best_config"] = {
        "k": best_k_val,
        "similarity_threshold": best_thr_val,
        "reranker": best_rr_val,
        "hybrid_alpha": best_alpha,
    }

    return phase_data


def run_phase_b(
    dataset_path: str,
    sample_size: int,
    progress_callback: Optional[Callable] = None,
) -> Dict:
    """
    Phase B: Data Preparation experiments.

    Requires re-ingestion for different embedding models
    and seed counts.
    """
    print("\n" + "=" * 70)
    print("PHASE B: DATA PREPARATION")
    print("=" * 70)

    phase_data = {"phase": "B", "subphases": {}}

    # Build a fixed eval set excluding the max seed
    # (300/cat) to ensure consistency across B2
    max_seed = max(EVAL_SEEDS_PER_CATEGORY)
    from rag_router.scripts.ingest import load_and_sample
    max_records = load_and_sample(
        dataset_path, max_seed
    )
    max_ids = {r["id"] for r in max_records}

    # Load eval records excluding all possible ingested
    evaluator = RAGRouterEvaluator()
    eval_records = evaluator.load_dataset(
        dataset_path=dataset_path,
        sample_size=sample_size,
        exclude_ids=list(max_ids),
    )

    # B1: Embedding model comparison
    print("\n--- B1: Embedding Model ---")
    b1_experiments = []
    for emb_model in EVAL_EMBEDDING_MODELS:
        coll_name = (
            f"query_categories_v1_{emb_model.split('-')[-1]}"
        )

        # Check if collection exists, ingest if needed
        _ensure_ingested(
            dataset_path=dataset_path,
            seed_per_category=SEED_PER_CATEGORY,
            embedding_model=emb_model,
            collection_name=coll_name,
        )

        config = {
            "k": DEFAULT_K,
            "similarity_threshold": (
                MIN_SIMILARITY_THRESHOLD
            ),
            "embedding_model": emb_model,
            "collection_name": coll_name,
        }
        short = emb_model.replace(
            "text-embedding-3-", ""
        )
        result = _run_single(
            config, eval_records,
            f"embedding={short}",
            progress_callback,
        )
        b1_experiments.append(result)

    phase_data["subphases"]["embedding_model"] = {
        "fixed": {
            "k": DEFAULT_K,
            "threshold": MIN_SIMILARITY_THRESHOLD,
        },
        "experiments": b1_experiments,
    }
    best_emb = _best_experiment(b1_experiments)
    best_emb_val = best_emb["config"]["embedding_model"]
    print(
        f"\n>> Best embedding: {best_emb_val} "
        f"(F1={best_emb['macro_f1']:.4f})"
    )

    # B2: Seed per category
    print("\n--- B2: Seed Per Category ---")
    b2_experiments = []
    for seed_count in EVAL_SEEDS_PER_CATEGORY:
        coll_name = (
            f"query_categories_v1_seed{seed_count}"
        )
        emb_short = best_emb_val.split("-")[-1]
        if best_emb_val != DEFAULT_EMBEDDING_MODEL:
            coll_name = (
                f"query_categories_v1"
                f"_{emb_short}_seed{seed_count}"
            )

        _ensure_ingested(
            dataset_path=dataset_path,
            seed_per_category=seed_count,
            embedding_model=best_emb_val,
            collection_name=coll_name,
        )

        config = {
            "k": DEFAULT_K,
            "similarity_threshold": (
                MIN_SIMILARITY_THRESHOLD
            ),
            "embedding_model": best_emb_val,
            "collection_name": coll_name,
        }
        result = _run_single(
            config, eval_records,
            f"seed_per_cat={seed_count}",
            progress_callback,
        )
        b2_experiments.append(result)

    phase_data["subphases"]["seed_per_category"] = {
        "fixed": {
            "k": DEFAULT_K,
            "threshold": MIN_SIMILARITY_THRESHOLD,
            "embedding": best_emb_val,
        },
        "experiments": b2_experiments,
    }
    best_seed = _best_experiment(b2_experiments)
    best_seed_val = None
    for sc in EVAL_SEEDS_PER_CATEGORY:
        if f"seed_per_cat={sc}" == best_seed["name"]:
            best_seed_val = sc
            break

    print(
        f"\n>> Best seed/cat: {best_seed_val} "
        f"(F1={best_seed['macro_f1']:.4f})"
    )

    phase_data["best_config"] = {
        "embedding_model": best_emb_val,
        "seed_per_category": best_seed_val,
    }

    return phase_data


def run_phase_c(
    best_a: Dict,
    best_b: Dict,
    records: List[Dict],
    dataset_path: str,
    progress_callback: Optional[Callable] = None,
) -> Dict:
    """
    Phase C: Best Combination.

    Combines best from A + B and compares against
    baseline.
    """
    print("\n" + "=" * 70)
    print("PHASE C: BEST COMBINATION")
    print("=" * 70)

    phase_data = {"phase": "C", "experiments": []}

    # Ensure the best-combo collection is ingested
    a_cfg = best_a["best_config"]
    b_cfg = best_b["best_config"]

    best_emb = b_cfg.get(
        "embedding_model", DEFAULT_EMBEDDING_MODEL
    )
    best_seed = b_cfg.get(
        "seed_per_category", SEED_PER_CATEGORY
    )
    emb_short = best_emb.split("-")[-1]
    best_coll = (
        f"query_categories_v1"
        f"_{emb_short}_seed{best_seed}"
    )

    _ensure_ingested(
        dataset_path=dataset_path,
        seed_per_category=best_seed,
        embedding_model=best_emb,
        collection_name=best_coll,
    )

    # Load eval records for Phase C
    from rag_router.scripts.ingest import load_and_sample
    max_seed = max(EVAL_SEEDS_PER_CATEGORY)
    max_records = load_and_sample(
        dataset_path, max_seed
    )
    max_ids = {r["id"] for r in max_records}
    evaluator = RAGRouterEvaluator()
    eval_records = evaluator.load_dataset(
        dataset_path=dataset_path,
        sample_size=len(records),
        exclude_ids=list(max_ids),
    )

    # C1: Baseline
    baseline_config = {
        "k": DEFAULT_K,
        "similarity_threshold": (
            MIN_SIMILARITY_THRESHOLD
        ),
    }
    c1 = _run_single(
        baseline_config, eval_records,
        "baseline",
        progress_callback,
    )
    phase_data["experiments"].append(c1)

    # C2: Best combo (A + B)
    best_config = {
        "k": a_cfg["k"],
        "similarity_threshold": (
            a_cfg["similarity_threshold"]
        ),
        "reranker": a_cfg.get("reranker"),
        "hybrid_alpha": a_cfg.get("hybrid_alpha"),
        "embedding_model": best_emb,
        "collection_name": best_coll,
    }
    c2 = _run_single(
        best_config, eval_records,
        "best_combination",
        progress_callback,
    )
    phase_data["experiments"].append(c2)

    # C3: Best A only (no data prep changes)
    best_a_config = {
        "k": a_cfg["k"],
        "similarity_threshold": (
            a_cfg["similarity_threshold"]
        ),
        "reranker": a_cfg.get("reranker"),
        "hybrid_alpha": a_cfg.get("hybrid_alpha"),
    }
    c3 = _run_single(
        best_a_config, eval_records,
        "best_retrieval_only",
        progress_callback,
    )
    phase_data["experiments"].append(c3)

    # Comparison
    phase_data["baseline_comparison"] = {
        "baseline_macro_f1": c1["macro_f1"],
        "best_combo_macro_f1": c2["macro_f1"],
        "best_retrieval_macro_f1": c3["macro_f1"],
        "improvement_combo": round(
            c2["macro_f1"] - c1["macro_f1"], 4
        ),
        "improvement_retrieval": round(
            c3["macro_f1"] - c1["macro_f1"], 4
        ),
    }
    phase_data["best_config"] = best_config

    return phase_data


def _ensure_ingested(
    dataset_path: str,
    seed_per_category: int,
    embedding_model: str,
    collection_name: str,
):
    """
    Ensure a ChromaDB collection is populated.

    If collection is empty, run ingestion.
    """
    from rag_router.store.chroma_store import ChromaStore
    from rag_router.store.embeddings import (
        EmbeddingClient,
    )
    from rag_router.scripts.ingest import load_and_sample

    store = ChromaStore(collection_name=collection_name)
    if store.count() > 0:
        print(
            f"Collection '{collection_name}' already "
            f"has {store.count()} docs, skipping ingest."
        )
        return

    print(
        f"Ingesting into '{collection_name}' "
        f"({seed_per_category}/cat, "
        f"{embedding_model})..."
    )
    records = load_and_sample(
        dataset_path, seed_per_category
    )
    queries = [r["query"] for r in records]

    client = EmbeddingClient(model=embedding_model)
    vectors, tokens = client.embed_batch(queries)
    cost = client.estimate_cost(tokens)
    print(
        f"Embedded {len(queries)} queries: "
        f"{tokens} tokens, ${cost:.6f}"
    )

    ids = [r["id"] for r in records]
    metadatas = [
        {"category": r["category"]} for r in records
    ]
    store.add_documents(
        ids=ids,
        documents=queries,
        embeddings=vectors,
        metadatas=metadatas,
    )
    print(f"Inserted {store.count()} documents")


def load_existing_results() -> Optional[Dict]:
    """Load previously saved results for resume."""
    path = Path(RAG_RESULTS_FILE)
    if path.exists():
        with open(path, "r") as f:
            return json.load(f)
    return None


def save_consolidated(results: Dict):
    """Save consolidated results to master JSON."""
    path = Path(RAG_RESULTS_FILE)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nConsolidated results saved to: {path}")


def run_all(
    dataset_path: str = DEFAULT_DATASET,
    sample_size: int = EVAL_SAMPLE_SIZE,
    phase: Optional[str] = None,
    resume: bool = False,
    progress_callback: Optional[Callable] = None,
) -> Dict:
    """
    Run the full experiment pipeline.

    Args:
        dataset_path: Path to labeled JSONL
        sample_size: Eval queries per experiment
        phase: Run only 'A', 'B', or 'C'
        resume: Skip completed phases
        progress_callback: For real-time updates
    """
    # Always load existing results when running a
    # single phase, so we don't overwrite other phases
    existing = load_existing_results()
    if existing and (resume or phase is not None):
        results = existing
    else:
        results = {
            "timestamp": datetime.now().isoformat(),
            "dataset_path": dataset_path,
            "sample_size": sample_size,
            "phases": {},
        }

    # Load eval records for Phase A
    # (using default ingested IDs for exclusion)
    evaluator = RAGRouterEvaluator()
    records = evaluator.load_dataset(
        dataset_path=dataset_path,
        sample_size=sample_size,
    )

    # Phase A
    if phase in (None, "A"):
        if resume and "retrieval_optimization" in (
            results.get("phases", {})
        ):
            print("Phase A already complete, skipping.")
        else:
            phase_a = run_phase_a(
                records, progress_callback
            )
            results["phases"][
                "retrieval_optimization"
            ] = phase_a
            save_consolidated(results)

    # Phase B
    if phase in (None, "B"):
        if resume and "data_preparation" in (
            results.get("phases", {})
        ):
            print("Phase B already complete, skipping.")
        else:
            phase_b = run_phase_b(
                dataset_path, sample_size,
                progress_callback,
            )
            results["phases"][
                "data_preparation"
            ] = phase_b
            save_consolidated(results)

    # Phase C
    if phase in (None, "C"):
        best_a = results["phases"].get(
            "retrieval_optimization", {}
        )
        best_b = results["phases"].get(
            "data_preparation", {}
        )

        if not best_a or not best_b:
            print(
                "Phase C requires A and B results. "
                "Run full pipeline first."
            )
        else:
            phase_c = run_phase_c(
                best_a, best_b, records,
                dataset_path, progress_callback,
            )
            results["phases"][
                "best_combination"
            ] = phase_c
            save_consolidated(results)

    print("\n" + "=" * 70)
    print("ALL EXPERIMENTS COMPLETE")
    print("=" * 70)

    return results


def main():
    parser = argparse.ArgumentParser(
        description=(
            "RAG Router Experiment Pipeline"
        ),
    )
    parser.add_argument(
        "--dataset",
        default=DEFAULT_DATASET,
        help="Path to labeled JSONL",
    )
    parser.add_argument(
        "--sample",
        type=int,
        default=EVAL_SAMPLE_SIZE,
        help="Eval queries per experiment",
    )
    parser.add_argument(
        "--phase",
        choices=["A", "B", "C"],
        default=None,
        help="Run only one phase",
    )
    parser.add_argument(
        "--resume",
        action="store_true",
        help="Resume from previous run",
    )
    args = parser.parse_args()

    run_all(
        dataset_path=args.dataset,
        sample_size=args.sample,
        phase=args.phase,
        resume=args.resume,
    )


if __name__ == "__main__":
    main()
