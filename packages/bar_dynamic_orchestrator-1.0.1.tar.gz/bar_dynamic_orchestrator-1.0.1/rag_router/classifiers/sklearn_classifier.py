"""
Sklearn-based classifier heads for the RAG Router (Approach 3).

Replaces the weighted majority vote with a proper trained classifier
(Logistic Regression, LinearSVM, or RBF SVM), while keeping the same
embedding model and ChromaDB collection as the KNN baseline.

Data consistency guarantee
--------------------------
Training vectors are extracted directly from ChromaDB via
``get_all_with_embeddings()``.  This returns the exact same 1,980 vectors
(180/category × 11 categories) that the KNN router searches against.
Evaluation queries are loaded via the shared ``RAGRouterEvaluator`` call
with seed=42, sample_size=500, exclude_ids=ingested_ids.json — identical
to Phase A. The ONLY variable that changes across experiments is the
decision head.
"""

import time
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np

from rag_router.config.settings import (
    DEFAULT_EMBEDDING_MODEL,
    VALID_CATEGORIES,
    PROJECT_ROOT,
)
from rag_router.store.chroma_store import ChromaStore
from rag_router.store.embeddings import EmbeddingClient

# Supported classifier types
CLASSIFIER_TYPES = ["logistic", "linear_svm", "rbf_svm"]

# Directory where trained classifier models are saved
MODEL_SAVE_DIR = PROJECT_ROOT / "rag_router" / "data" / "models"


class SklearnClassifierRouter:
    """
    Embed a query → pass to a trained sklearn classifier → return category.

    The classifier is trained once on embeddings retrieved from ChromaDB
    (the same vectors used by KNN), so train/test data is identical across
    all classifier heads.
    """

    def __init__(
        self,
        classifier_type: str = "logistic",
        embedding_model: str = DEFAULT_EMBEDDING_MODEL,
        collection_name: Optional[str] = None,
        chroma_persist_dir: Optional[str] = None,
        # Logistic Regression params
        lr_C: float = 1.0,
        lr_max_iter: int = 1000,
        # SVM params
        svm_C: float = 1.0,
        svm_gamma: str = "scale",
    ):
        if classifier_type not in CLASSIFIER_TYPES:
            raise ValueError(
                f"classifier_type must be one of {CLASSIFIER_TYPES}, "
                f"got: {classifier_type}"
            )
        self.classifier_type = classifier_type
        self.embedding_client = EmbeddingClient(model=embedding_model)

        # Store ChromaDB kwargs but do NOT connect yet.
        # ChromaStore is only created lazily when fit() is called.
        # This allows load() from disk to work with zero ChromaDB contact,
        # which avoids version-mismatch errors on every server restart.
        self._store_kwargs: Dict[str, Any] = {}
        if chroma_persist_dir:
            self._store_kwargs["persist_dir"] = chroma_persist_dir
        if collection_name:
            self._store_kwargs["collection_name"] = collection_name
        self._store: Optional[ChromaStore] = None

        self.lr_C = lr_C
        self.lr_max_iter = lr_max_iter
        self.svm_C = svm_C
        self.svm_gamma = svm_gamma

        self._clf = None
        self._label_encoder = None
        self._is_fitted = False

    @property
    def store(self) -> ChromaStore:
        """Lazily initialise ChromaStore on first access."""
        if self._store is None:
            self._store = ChromaStore(**self._store_kwargs)
        return self._store

    # ── Model persistence ─────────────────────────────────────

    def _model_path(self) -> Path:
        """Return the path where this classifier's model is saved."""
        return MODEL_SAVE_DIR / f"{self.classifier_type}_classifier.joblib"

    def save(self) -> None:
        """Persist the fitted classifier to disk using joblib."""
        import joblib
        MODEL_SAVE_DIR.mkdir(parents=True, exist_ok=True)
        joblib.dump(
            {
                "clf": self._clf,
                "label_encoder": self._label_encoder,
            },
            self._model_path(),
        )

    def load(self) -> bool:
        """
        Load a previously saved classifier from disk.

        Returns True if loaded successfully, False if no saved model exists.
        """
        import joblib
        path = self._model_path()
        if not path.exists():
            return False
        data = joblib.load(path)
        self._clf = data["clf"]
        self._label_encoder = data.get("label_encoder")
        self._is_fitted = True
        return True

    def fit_or_load(self) -> tuple[int, bool]:
        """
        Load from disk if a saved model exists, otherwise train from ChromaDB
        and save the result.

        Returns:
            (n_examples, was_loaded_from_disk)
            n_examples = 0 when loaded from disk (no retraining happened)
        """
        if self.load():
            return 0, True
        n = self.fit()
        self.save()
        return n, False

    # ── Training ──────────────────────────────────────────────

    def fit(self) -> int:
        """
        Extract all embeddings from ChromaDB and train the classifier.

        Returns the number of training examples.
        """
        data = self.store.get_all_with_embeddings()
        embeddings = data.get("embeddings")
        metadatas = data.get("metadatas")

        if embeddings is None or len(embeddings) == 0:
            raise RuntimeError(
                "ChromaDB collection is empty. "
                "Run ingest first."
            )

        X = np.array(embeddings, dtype=np.float32)
        y = np.array([m["category"] for m in metadatas])

        self._clf = self._build_classifier()
        self._clf.fit(X, y)
        self._is_fitted = True

        return len(X)

    def route(self, query: str) -> Dict[str, Any]:
        """
        Embed query → classify → return routing result dict.

        Output format mirrors RAGRouter.route() so the evaluator
        and UI work without changes.
        """
        if not self._is_fitted:
            raise RuntimeError(
                "Call fit() before route()."
            )

        start = time.time()

        # Embed query
        vector, tokens = self.embedding_client.embed(query)
        cost = self.embedding_client.estimate_cost(tokens)
        X = np.array(vector, dtype=np.float32).reshape(1, -1)

        # Classify
        category = self._clf.predict(X)[0]
        confidence = self._get_confidence(X, category)

        # Per-category scores
        all_scores: dict[str, float] = {}
        if hasattr(self._clf, "predict_proba"):
            proba = self._clf.predict_proba(X)[0]
            classes = list(self._clf.classes_)
            all_scores = {
                cls: round(float(proba[i]), 4)
                for i, cls in enumerate(classes)
            }

        latency_ms = (time.time() - start) * 1000
        is_valid = category in VALID_CATEGORIES

        return {
            "query": query,
            "final_category": category,
            "category_confidence": round(float(confidence), 4),
            "is_valid": is_valid,
            "retrieval_method": self.classifier_type,
            "category_reasoning": (
                f"{self.classifier_type}: confidence={confidence:.3f}"
            ),
            "all_scores": all_scores or None,
            "total_tokens": tokens,
            "estimated_cost_usd": round(cost, 8),
            "k": 0,
            "neighbors": [],
            "latency_ms": round(latency_ms, 1),
        }

    def _build_classifier(self):
        """Build the sklearn classifier from type string."""
        from sklearn.linear_model import LogisticRegression
        from sklearn.svm import LinearSVC, SVC
        from sklearn.calibration import CalibratedClassifierCV

        if self.classifier_type == "logistic":
            return LogisticRegression(
                C=self.lr_C,
                max_iter=self.lr_max_iter,
                solver="lbfgs",
                n_jobs=-1,
            )
        elif self.classifier_type == "linear_svm":
            # LinearSVC is fast but lacks predict_proba;
            # wrap with CalibratedClassifierCV for confidence
            base = LinearSVC(
                C=self.svm_C,
                max_iter=5000,
                dual="auto",
            )
            return CalibratedClassifierCV(base, cv=3)
        else:  # rbf_svm
            return SVC(
                C=self.svm_C,
                kernel="rbf",
                gamma=self.svm_gamma,
                probability=True,
            )

    def _get_confidence(
        self, X: np.ndarray, predicted_class: str
    ) -> float:
        """Return probability of the predicted class."""
        if hasattr(self._clf, "predict_proba"):
            proba = self._clf.predict_proba(X)[0]
            classes = list(self._clf.classes_)
            idx = classes.index(predicted_class)
            return float(proba[idx])
        # Fallback: decision function score (normalised)
        if hasattr(self._clf, "decision_function"):
            scores = self._clf.decision_function(X)[0]
            exp_scores = np.exp(
                scores - scores.max()
            )
            normalised = exp_scores / exp_scores.sum()
            classes = list(self._clf.classes_)
            idx = classes.index(predicted_class)
            return float(normalised[idx])
        return 1.0
