"""
Compare multiple RAG experiment configurations.

Runs each experiment on the same dataset and produces
a side-by-side comparison report.
"""

import json
from typing import Any, Callable, Dict, List, Optional
from pathlib import Path
from datetime import datetime

from rag_router.evaluation.evaluator import RAGRouterEvaluator
from rag_router.evaluation.metrics import print_rag_metrics_report


class ExperimentComparator:
    """Compare multiple RAG experiment configurations."""

    def compare(
        self,
        experiments: List[Dict[str, Any]],
        records: List[Dict],
        output_dir: str = "rag_router/results",
        progress_callback: Optional[Callable] = None,
    ) -> Dict[str, Any]:
        """
        Run each experiment config on the same records.

        Args:
            experiments: List of {"name": str, "config": dict}
                where config keys match RAGRouterEvaluator.__init__ params
            records: Pre-loaded evaluation records
            output_dir: Where to save results
            progress_callback: Called with experiment progress updates

        Returns:
            Comparison report dict
        """
        all_metrics = {}

        for exp in experiments:
            name = exp["name"]
            config = exp["config"]

            print(f"\n{'='*70}")
            print(f"Running experiment: {name}")
            print(f"{'='*70}")

            evaluator = RAGRouterEvaluator(**config)
            evaluation = evaluator.evaluate(
                records,
                progress_callback=progress_callback,
            )

            evaluator.save_evaluation(
                evaluation,
                output_dir=output_dir,
                experiment_name=name,
            )

            all_metrics[name] = evaluation["metrics"]

            # Print summary
            print_rag_metrics_report(evaluation["metrics"])

        report = self._generate_report(all_metrics)
        self._save_report(report, output_dir)

        return report

    def _generate_report(
        self, metrics_by_experiment: Dict[str, Dict]
    ) -> Dict[str, Any]:
        """Generate side-by-side comparison report."""
        comparison_table = []

        for name, metrics in metrics_by_experiment.items():
            meta = metrics.get("evaluation_metadata", {})
            comparison_table.append({
                "name": name,
                "accuracy": metrics.get("accuracy", 0),
                "macro_f1": metrics.get("macro_f1", 0),
                "weighted_f1": metrics.get("weighted_f1", 0),
                "avg_latency_ms": meta.get("avg_latency_ms", 0),
                "total_cost_usd": meta.get("total_cost_usd", 0),
                "avg_confidence": meta.get("avg_confidence", 0),
                "rag_stats": metrics.get("rag_stats", {}),
            })

        comparison_table.sort(key=lambda x: x["macro_f1"], reverse=True)

        best = comparison_table[0] if comparison_table else None

        return {
            "timestamp": datetime.now().isoformat(),
            "num_experiments": len(metrics_by_experiment),
            "comparison_table": comparison_table,
            "best_experiment": best["name"] if best else None,
            "full_metrics": metrics_by_experiment,
        }

    def _save_report(self, report: Dict, output_dir: str):
        """Save comparison report to JSON."""
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        filepath = output_path / f"comparison_{ts}.json"

        with open(filepath, "w") as f:
            json.dump(report, f, indent=2)

        print(f"\nComparison report saved to: {filepath}")

        # Print summary table
        print(f"\n{'='*90}")
        print("EXPERIMENT COMPARISON")
        print(f"{'='*90}")
        print(
            f"{'Experiment':<30} {'Accuracy':>10} {'Macro F1':>10} "
            f"{'W-F1':>10} {'Latency':>10} {'Cost':>10}"
        )
        print("-" * 90)
        for row in report["comparison_table"]:
            print(
                f"{row['name']:<30} {row['accuracy']:>10.1%} "
                f"{row['macro_f1']:>10.4f} {row['weighted_f1']:>10.4f} "
                f"{row['avg_latency_ms']:>8.0f}ms "
                f"${row['total_cost_usd']:>8.4f}"
            )
        print(f"\nBest: {report['best_experiment']}")
        print(f"{'='*90}")
