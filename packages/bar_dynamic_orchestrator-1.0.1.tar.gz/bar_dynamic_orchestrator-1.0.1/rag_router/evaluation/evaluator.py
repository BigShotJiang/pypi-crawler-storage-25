"""
Evaluator for the RAG Similarity Router (Approach 3).

Runs the RAG router against a labeled dataset and computes
metrics. Supports configurable k, threshold, embedding model,
reranker, and hybrid search for multi-phase experiments.
"""

import json
import time
import random
from typing import Any, Callable, Dict, List, Optional
from pathlib import Path
from datetime import datetime
from collections import defaultdict

from rag_router.config.settings import (
    DEFAULT_DATASET,
    DEFAULT_EMBEDDING_MODEL,
    DEFAULT_K,
    INGESTED_IDS_PATH,
    MIN_SIMILARITY_THRESHOLD,
    VALID_CATEGORIES,
)
from rag_router.evaluation.metrics import compute_rag_metrics, save_metrics


class RAGRouterEvaluator:
    """
    Evaluate the RAG router against a labeled dataset.

    Supports configurable k, threshold, embedding model,
    reranker, and hybrid search for experiment phases.
    """

    def __init__(
        self,
        k: int = DEFAULT_K,
        similarity_threshold: float = MIN_SIMILARITY_THRESHOLD,
        embedding_model: str = DEFAULT_EMBEDDING_MODEL,
        reranker: Optional[str] = None,
        reranker_top_n: int = 20,
        hybrid_alpha: Optional[float] = None,
        chroma_persist_dir: Optional[str] = None,
        collection_name: Optional[str] = None,
    ):
        self.k = k
        self.similarity_threshold = similarity_threshold
        self.embedding_model = embedding_model
        self.reranker_name = reranker
        self.reranker_top_n = reranker_top_n
        self.hybrid_alpha = hybrid_alpha
        self.chroma_persist_dir = chroma_persist_dir
        self.collection_name = collection_name

        self._router = None

    def _get_router(self):
        """Lazy-init router with current config."""
        if self._router is None:
            from rag_router.router import RAGRouter

            kwargs = {
                "k": self.k,
                "embedding_model": self.embedding_model,
                "similarity_threshold": self.similarity_threshold,
            }
            if self.chroma_persist_dir:
                kwargs["chroma_persist_dir"] = self.chroma_persist_dir
            if self.collection_name:
                kwargs["collection_name"] = self.collection_name

            router = RAGRouter(**kwargs)

            # Attach reranker if specified
            if self.reranker_name:
                from rag_router.reranker.cross_encoder import CrossEncoderReranker
                from rag_router.config.settings import RERANKER_MODELS

                model_name = RERANKER_MODELS.get(self.reranker_name, self.reranker_name)
                router.reranker = CrossEncoderReranker(model_name=model_name)
                router.reranker_top_n = self.reranker_top_n

            # Attach hybrid store if specified
            if self.hybrid_alpha is not None:
                from rag_router.store.bm25_store import BM25Store
                from rag_router.store.hybrid_store import HybridStore

                bm25 = BM25Store.from_chroma_store(router.store)
                router.hybrid_store = HybridStore(
                    chroma_store=router.store,
                    bm25_store=bm25,
                    alpha=self.hybrid_alpha,
                )

            self._router = router
        return self._router

    def load_dataset(
        self,
        dataset_path: str = DEFAULT_DATASET,
        sample_size: Optional[int] = 500,
        exclude_ids: Optional[List[str]] = None,
        seed: int = 42,
    ) -> List[Dict]:
        """
        Load labeled dataset, exclude ingested IDs, optionally sample.

        Uses stratified sampling to ensure balanced categories.
        """
        # Load ingested IDs to exclude (prevent data leakage)
        if exclude_ids is None:
            try:
                with open(INGESTED_IDS_PATH, "r") as f:
                    exclude_ids = set(json.load(f))
            except FileNotFoundError:
                exclude_ids = set()
        else:
            exclude_ids = set(exclude_ids)

        # Load records, excluding ingested ones
        records = []
        with open(dataset_path, "r", encoding="utf-8") as f:
            for line in f:
                try:
                    record = json.loads(line.strip())
                    if (
                        "query" in record
                        and "category" in record
                        and record.get("id") not in exclude_ids
                        and record.get("category") in VALID_CATEGORIES
                    ):
                        records.append(record)
                except json.JSONDecodeError:
                    continue

        # Stratified sampling
        if sample_size and sample_size < len(records):
            by_category = defaultdict(list)
            for r in records:
                by_category[r["category"]].append(r)

            per_cat = max(1, sample_size // len(VALID_CATEGORIES))
            random.seed(seed)
            sampled = []
            for cat in VALID_CATEGORIES:
                pool = by_category.get(cat, [])
                n = min(per_cat, len(pool))
                if n > 0:
                    sampled.extend(random.sample(pool, n))

            # Fill remaining if needed (due to rounding)
            remaining = sample_size - len(sampled)
            if remaining > 0:
                sampled_ids = {r.get("id") for r in sampled}
                leftover = [r for r in records if r.get("id") not in sampled_ids]
                random.shuffle(leftover)
                sampled.extend(leftover[:remaining])

            random.shuffle(sampled)
            records = sampled

        print(
            f"Loaded {len(records)} eval queries "
            f"(excluded {len(exclude_ids)} ingested IDs)"
        )
        return records

    def evaluate(
        self,
        records: List[Dict],
        verbose: bool = False,
        progress_callback: Optional[Callable] = None,
    ) -> Dict[str, Any]:
        """
        Run evaluation on labeled records.

        Args:
            records: List with 'query', 'category'
            verbose: Print per-query results
            progress_callback: Called with (current, total, accuracy_so_far)
                for real-time WebSocket updates

        Returns:
            Dict with results list and computed metrics
        """
        router = self._get_router()
        config_desc = self._config_description()

        print(f"\nEvaluating {len(records)} queries")
        print(f"Config: {config_desc}")
        print("=" * 70)

        results = []
        start_time = time.time()

        for i, record in enumerate(records):
            query = record["query"]
            ground_truth = record["category"]

            try:
                query_start = time.time()
                result = router.route(query)
                latency_ms = (time.time() - query_start) * 1000

                result["ground_truth_category"] = ground_truth
                result["latency_ms"] = round(latency_ms, 1)
                result["similarity_threshold"] = self.similarity_threshold

                if verbose:
                    pred = result["final_category"]
                    conf = result["category_confidence"]
                    ok = "OK" if pred == ground_truth else "MISS"
                    print(
                        f"  [{i+1}] {ok} | "
                        f"pred={pred:<25} "
                        f"truth={ground_truth:<25} "
                        f"conf={conf:.2f}"
                    )

            except Exception as e:
                result = {
                    "query": query,
                    "final_category": "ERROR",
                    "ground_truth_category": ground_truth,
                    "error": str(e),
                    "category_confidence": 0.0,
                    "latency_ms": 0,
                    "neighbors": [],
                }
                if verbose:
                    print(f"  [{i+1}] ERROR: {e}")

            results.append(result)

            # Progress reporting
            if (i + 1) % 25 == 0 and not verbose:
                elapsed = time.time() - start_time
                correct = sum(
                    1 for r in results
                    if r.get("final_category") == r.get("ground_truth_category")
                )
                rate = (i + 1) / elapsed
                acc = correct / len(results) * 100
                print(
                    f"  [{i+1}/{len(records)}] "
                    f"Acc: {acc:.1f}% | "
                    f"Rate: {rate:.1f} q/s | "
                    f"Elapsed: {elapsed:.0f}s"
                )

            # Real-time callback for WebSocket
            if progress_callback and (i + 1) % 5 == 0:
                correct = sum(
                    1 for r in results
                    if r.get("final_category") == r.get("ground_truth_category")
                )
                progress_callback(i + 1, len(records), correct / len(results))

        total_time = time.time() - start_time

        # Compute metrics
        metrics = compute_rag_metrics(results)
        qps = round(len(records) / total_time, 2) if total_time > 0 else 0

        # Cost/latency aggregates
        total_cost = sum(r.get("estimated_cost_usd", 0) or 0 for r in results)
        total_tokens = sum(r.get("total_tokens", 0) or 0 for r in results)
        avg_latency = (
            sum(r.get("latency_ms", 0) for r in results) / len(results)
            if results else 0
        )
        avg_confidence = 0.0
        conf_values = [
            r.get("category_confidence", 0)
            for r in results
            if r.get("final_category") != "ERROR"
        ]
        if conf_values:
            avg_confidence = sum(conf_values) / len(conf_values)

        metrics["evaluation_metadata"] = {
            "k": self.k,
            "similarity_threshold": self.similarity_threshold,
            "embedding_model": self.embedding_model,
            "reranker": self.reranker_name,
            "reranker_top_n": self.reranker_top_n if self.reranker_name else None,
            "hybrid_alpha": self.hybrid_alpha,
            "total_queries": len(records),
            "total_time_seconds": round(total_time, 1),
            "queries_per_second": qps,
            "total_cost_usd": round(total_cost, 6),
            "total_tokens": total_tokens,
            "avg_confidence": round(avg_confidence, 4),
            "avg_latency_ms": round(avg_latency, 1),
            "timestamp": datetime.now().isoformat(),
        }

        return {"results": results, "metrics": metrics}

    def save_evaluation(
        self,
        evaluation: Dict[str, Any],
        output_dir: str = "rag_router/results",
        experiment_name: str = "baseline",
    ) -> str:
        """Save evaluation results and metrics."""
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        results_file = output_path / f"eval_{experiment_name}_{ts}.jsonl"
        with open(results_file, "w", encoding="utf-8") as f:
            for r in evaluation["results"]:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")

        metrics_file = output_path / f"metrics_{experiment_name}_{ts}.json"
        save_metrics(evaluation["metrics"], str(metrics_file))

        print(f"\nResults saved to: {results_file}")
        print(f"Metrics saved to: {metrics_file}")

        return str(results_file)

    def _config_description(self) -> str:
        """Human-readable config string."""
        parts = [
            f"k={self.k}",
            f"threshold={self.similarity_threshold}",
            f"embedding={self.embedding_model}",
        ]
        if self.reranker_name:
            parts.append(f"reranker={self.reranker_name}(top_n={self.reranker_top_n})")
        if self.hybrid_alpha is not None:
            parts.append(f"hybrid_alpha={self.hybrid_alpha}")
        return " | ".join(parts)
