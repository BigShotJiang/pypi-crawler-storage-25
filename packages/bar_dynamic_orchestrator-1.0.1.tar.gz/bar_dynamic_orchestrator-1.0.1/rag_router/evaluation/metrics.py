"""
Evaluation metrics for the RAG Similarity Router (Approach 3).

Reuses the core compute_metrics from llm_router and adds
RAG-specific statistics (similarity, threshold filtering, neighbor stats).
"""

from typing import Any, Dict, List

from llm_router.evaluation.metrics import (
    compute_metrics,
    print_metrics_report,
    save_metrics,
)


def compute_rag_metrics(results: List[Dict]) -> Dict[str, Any]:
    """
    Compute evaluation metrics with RAG-specific additions.

    Wraps llm_router's compute_metrics() and adds:
    - avg_top1_similarity: mean similarity of nearest neighbor
    - avg_topk_similarity: mean similarity across all k neighbors
    - threshold_filter_rate: fraction of queries where no neighbor passed threshold
    - avg_neighbors_above_threshold: avg strong neighbors per query
    """
    base = compute_metrics(results)

    if "error" in base:
        return base

    # RAG-specific stats
    top1_sims = []
    topk_sims = []
    threshold_filtered = 0
    neighbors_above_threshold = []

    for r in results:
        if r.get("final_category") == "ERROR":
            continue

        neighbors = r.get("neighbors", [])
        if not neighbors:
            continue

        # Top-1 similarity
        top1_sims.append(neighbors[0].get("similarity", 0))

        # All similarities
        sims = [n.get("similarity", 0) for n in neighbors]
        topk_sims.extend(sims)

        # Check if threshold filtering happened
        threshold = r.get("similarity_threshold", 0.5)
        strong = [s for s in sims if s >= threshold]
        if not strong:
            threshold_filtered += 1
        neighbors_above_threshold.append(len(strong))

    valid_count = len([
        r for r in results
        if r.get("final_category") != "ERROR" and r.get("neighbors")
    ])

    base["rag_stats"] = {
        "avg_top1_similarity": (
            round(sum(top1_sims) / len(top1_sims), 4)
            if top1_sims else 0.0
        ),
        "avg_topk_similarity": (
            round(sum(topk_sims) / len(topk_sims), 4)
            if topk_sims else 0.0
        ),
        "threshold_filter_rate": (
            round(threshold_filtered / valid_count, 4)
            if valid_count > 0 else 0.0
        ),
        "avg_neighbors_above_threshold": (
            round(
                sum(neighbors_above_threshold) / len(neighbors_above_threshold), 2
            )
            if neighbors_above_threshold else 0.0
        ),
    }

    return base


def print_rag_metrics_report(metrics: Dict[str, Any]):
    """Print the standard report plus RAG-specific stats."""
    print_metrics_report(metrics)

    rag = metrics.get("rag_stats", {})
    if rag:
        print("\nRAG Retrieval Statistics:")
        print(f"  Avg top-1 similarity:          {rag.get('avg_top1_similarity', 0):.4f}")
        print(f"  Avg top-K similarity:          {rag.get('avg_topk_similarity', 0):.4f}")
        print(f"  Threshold filter rate:         {rag.get('threshold_filter_rate', 0):.2%}")
        print(f"  Avg neighbors above threshold: {rag.get('avg_neighbors_above_threshold', 0):.1f}")
        print("=" * 80)
