"""
RAG Similarity Router (Approach 3).

Routes queries by finding the most similar past queries in a ChromaDB
vector store and using weighted majority vote on their categories.

Supports optional reranking and hybrid (dense + BM25) search.
"""

import time
from collections import defaultdict
from typing import Any, Dict, Optional

from rag_router.config.settings import (
    DEFAULT_K,
    DEFAULT_EMBEDDING_MODEL,
    MIN_SIMILARITY_THRESHOLD,
    VALID_CATEGORIES,
)
from rag_router.store.chroma_store import ChromaStore
from rag_router.store.embeddings import EmbeddingClient


class RAGRouter:
    def __init__(
        self,
        k: int = DEFAULT_K,
        embedding_model: str = DEFAULT_EMBEDDING_MODEL,
        similarity_threshold: float = (
            MIN_SIMILARITY_THRESHOLD
        ),
        chroma_persist_dir: Optional[str] = None,
        collection_name: Optional[str] = None,
    ):
        self.k = k
        self.similarity_threshold = similarity_threshold
        self.embedding_client = EmbeddingClient(
            model=embedding_model
        )

        store_kwargs = {}
        if chroma_persist_dir:
            store_kwargs["persist_dir"] = chroma_persist_dir
        if collection_name:
            store_kwargs["collection_name"] = (
                collection_name
            )
        self.store = ChromaStore(**store_kwargs)

        # Optional: set by evaluator or externally
        self.reranker = None
        self.reranker_top_n = 20
        self.hybrid_store = None

    def route(self, query: str) -> Dict[str, Any]:
        """
        Route a query using k-NN similarity search.

        Returns a dict compatible with the LLMRouter
        interface.
        """
        start = time.time()

        # 1. Embed the query
        vector, tokens = self.embedding_client.embed(
            query
        )
        cost = self.embedding_client.estimate_cost(tokens)

        # 2. Determine how many candidates to fetch
        fetch_k = self.k
        if self.reranker:
            fetch_k = self.reranker_top_n

        # 3. Search: hybrid or vector-only
        if self.hybrid_store:
            results = self.hybrid_store.query(
                query_embedding=vector,
                query_text=query,
                k=fetch_k,
                fetch_k=max(fetch_k, 50),
            )
        else:
            results = self.store.query(
                query_embedding=vector, k=fetch_k
            )

        # 4. Optional reranking
        if self.reranker:
            candidates = self._results_to_candidates(
                results
            )
            reranked = self.reranker.rerank(
                query, candidates, top_k=self.k
            )
            distances, metadatas, documents = (
                self._candidates_to_results(reranked)
            )
        else:
            distances = results["distances"][0]
            metadatas = results["metadatas"][0]
            documents = results["documents"][0]

        # 5. Weighted majority vote
        (
            category, confidence, reasoning, neighbors
        ) = self._compute_vote(
            distances, metadatas, documents
        )

        latency_ms = (time.time() - start) * 1000
        is_valid = category in VALID_CATEGORIES

        return {
            "query": query,
            "final_category": category,
            "category_confidence": round(confidence, 4),
            "is_valid": is_valid,
            "retrieval_method": self._retrieval_method(),
            "category_reasoning": reasoning,
            "total_tokens": tokens,
            "estimated_cost_usd": round(cost, 8),
            "k": self.k,
            "neighbors": neighbors,
            "latency_ms": round(latency_ms, 1),
        }

    def _retrieval_method(self) -> str:
        """Describe the retrieval pipeline used."""
        parts = ["knn"]
        if self.hybrid_store:
            parts.append("hybrid")
        if self.reranker:
            parts.append("reranked")
        parts.append("weighted_vote")
        return "_".join(parts)

    def _results_to_candidates(
        self, results: dict
    ) -> list[dict]:
        """Convert ChromaDB results to candidate dicts
        for reranker."""
        candidates = []
        for dist, meta, doc in zip(
            results["distances"][0],
            results["metadatas"][0],
            results["documents"][0],
        ):
            candidates.append({
                "document": doc,
                "category": meta["category"],
                "similarity": round(1.0 - dist, 4),
                "original_distance": dist,
            })
        return candidates

    def _candidates_to_results(
        self, reranked: list[dict]
    ) -> tuple[list, list, list]:
        """Convert reranked candidates back to
        distance/meta/doc lists."""
        distances = [
            c["original_distance"] for c in reranked
        ]
        metadatas = [
            {"category": c["category"]} for c in reranked
        ]
        documents = [c["document"] for c in reranked]
        return distances, metadatas, documents

    def _compute_vote(
        self,
        distances: list[float],
        metadatas: list[dict],
        documents: list[str],
    ) -> tuple[str, float, str, list[dict]]:
        """
        Weighted majority vote from k-NN results.

        ChromaDB cosine distance = 1 - cosine_similarity.
        So similarity = 1 - distance.
        """
        category_weights = defaultdict(float)
        category_counts = defaultdict(int)
        category_sims = defaultdict(list)
        neighbors = []
        strong_count = 0

        for dist, meta, doc in zip(
            distances, metadatas, documents
        ):
            similarity = 1.0 - dist
            cat = meta["category"]
            neighbors.append({
                "category": cat,
                "similarity": round(similarity, 4),
                "query_snippet": doc[:80],
            })
            if similarity >= self.similarity_threshold:
                category_weights[cat] += similarity
                category_counts[cat] += 1
                category_sims[cat].append(similarity)
                strong_count += 1

        # Fallback if no neighbors pass threshold
        if strong_count == 0:
            best_sim = 1.0 - distances[0]
            best_cat = metadatas[0]["category"]
            reasoning = (
                f"{self.k}-NN: no strong matches "
                f"(best={best_sim:.2f} "
                f"< {self.similarity_threshold})"
            )
            return (
                best_cat, best_sim * 0.5,
                reasoning, neighbors,
            )

        # Winner = highest total weight
        total_weight = sum(category_weights.values())
        winner = max(
            category_weights, key=category_weights.get
        )
        confidence = (
            category_weights[winner] / total_weight
            if total_weight > 0 else 0
        )

        # Build reasoning string
        sorted_cats = sorted(
            category_weights.items(),
            key=lambda x: x[1],
            reverse=True,
        )
        parts = []
        for cat, weight in sorted_cats:
            avg_sim = (
                sum(category_sims[cat])
                / len(category_sims[cat])
            )
            parts.append(
                f"{cat}({category_counts[cat]}, "
                f"avg_sim={avg_sim:.2f})"
            )
        reasoning = (
            f"{self.k}-NN: {' > '.join(parts)}"
        )

        return winner, confidence, reasoning, neighbors
