"""
Cross-encoder reranker for RAG retrieval results.

Supports multiple models:
- ms-marco-MiniLM-L-6-v2: Fast, lightweight (~80MB)
- bge-reranker-v2-m3: Stronger, heavier (~560MB)

Both are free and run locally via sentence-transformers.
"""

from typing import Dict, List


class CrossEncoderReranker:
    """
    Rerank retrieval candidates using a cross-encoder model.

    Cross-encoders score (query, document) pairs jointly,
    giving more accurate relevance scores than bi-encoder
    cosine similarity.
    """

    def __init__(
        self,
        model_name: str = (
            "cross-encoder/ms-marco-MiniLM-L-6-v2"
        ),
    ):
        self.model_name = model_name
        self._model = None

    def _load_model(self):
        """Lazy-load model on first use."""
        if self._model is None:
            from sentence_transformers import CrossEncoder

            self._model = CrossEncoder(self.model_name)
        return self._model

    def rerank(
        self,
        query: str,
        candidates: List[Dict],
        top_k: int = 5,
    ) -> List[Dict]:
        """
        Rerank candidates by cross-encoder relevance.

        Args:
            query: The search query
            candidates: List of dicts with at least
                'document', 'category', 'similarity' keys
            top_k: Number of top candidates to return

        Returns:
            Top-k candidates sorted by reranker_score,
            with original similarity preserved.
        """
        if not candidates:
            return []

        model = self._load_model()

        pairs = [
            (query, c["document"]) for c in candidates
        ]
        scores = model.predict(pairs)

        for c, score in zip(candidates, scores):
            c["reranker_score"] = round(float(score), 4)

        reranked = sorted(
            candidates,
            key=lambda x: x["reranker_score"],
            reverse=True,
        )
        return reranked[:top_k]
