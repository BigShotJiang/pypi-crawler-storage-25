"""
OpenAI embedding client with token and cost tracking.
"""

try:
    from langfuse.openai import OpenAI  # Auto-traces all OpenAI calls
except ImportError:
    from openai import OpenAI

from rag_router.config.settings import DEFAULT_EMBEDDING_MODEL, EMBEDDING_COST_PER_1K


class EmbeddingClient:
    def __init__(self, model: str = DEFAULT_EMBEDDING_MODEL):
        self._client = None
        self.model = model

    @property
    def client(self) -> OpenAI:
        if self._client is None:
            self._client = OpenAI()
        return self._client

    def embed(self, text: str) -> tuple[list[float], int]:
        """Embed a single text. Returns (vector, tokens_used)."""
        response = self.client.embeddings.create(
            model=self.model,
            input=text,
        )
        tokens = response.usage.total_tokens
        vector = response.data[0].embedding
        return vector, tokens

    def embed_batch(
        self, texts: list[str], batch_size: int = 100
    ) -> tuple[list[list[float]], int]:
        """Embed a batch of texts. Returns (vectors, total_tokens)."""
        all_vectors = []
        total_tokens = 0

        for i in range(0, len(texts), batch_size):
            batch = texts[i : i + batch_size]
            response = self.client.embeddings.create(
                model=self.model,
                input=batch,
            )
            total_tokens += response.usage.total_tokens
            # Maintain order
            batch_vectors = [d.embedding for d in response.data]
            all_vectors.extend(batch_vectors)

        return all_vectors, total_tokens

    def estimate_cost(self, tokens: int) -> float:
        """Estimate cost in USD for the given token count."""
        cost_per_1k = EMBEDDING_COST_PER_1K.get(self.model, 0.00002)
        return tokens * cost_per_1k / 1000
