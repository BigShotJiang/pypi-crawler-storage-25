"""
Hybrid retrieval store: dense (vector) + sparse (BM25) fusion.

Combines ChromaDB cosine similarity with BM25 keyword relevance
using weighted score fusion.
"""

from typing import Dict, List

from rag_router.store.bm25_store import BM25Store
from rag_router.store.chroma_store import ChromaStore


class HybridStore:
    """
    Hybrid retrieval combining dense and sparse scores.

    Formula: score = alpha * norm(dense) + (1-alpha) * norm(sparse)

    Where norm() is min-max normalization to [0, 1].
    """

    def __init__(
        self,
        chroma_store: ChromaStore,
        bm25_store: BM25Store,
        alpha: float = 0.7,
    ):
        self.chroma = chroma_store
        self.bm25 = bm25_store
        self.alpha = alpha

    def query(
        self,
        query_embedding: List[float],
        query_text: str,
        k: int = 5,
        fetch_k: int = 50,
    ) -> Dict:
        """
        Fused retrieval from both dense and sparse indexes.

        Args:
            query_embedding: Vector for dense search
            query_text: Raw text for BM25 search
            k: Final number of results to return
            fetch_k: Candidates to fetch from each source

        Returns:
            Dict in ChromaDB result format with fused scores
            stored as distances (1 - fused_score for compat).
        """
        # Dense retrieval (ChromaDB)
        dense_results = self.chroma.query(
            query_embedding=query_embedding, k=fetch_k
        )

        # Sparse retrieval (BM25)
        sparse_results = self.bm25.query(
            query=query_text, k=fetch_k
        )

        # Build score maps by document ID
        dense_scores = {}
        dense_docs = {}
        dense_metas = {}

        for doc_id, dist, doc, meta in zip(
            dense_results["ids"][0],
            dense_results["distances"][0],
            dense_results["documents"][0],
            dense_results["metadatas"][0],
        ):
            # ChromaDB cosine distance → similarity
            dense_scores[doc_id] = 1.0 - dist
            dense_docs[doc_id] = doc
            dense_metas[doc_id] = meta

        sparse_scores = {}
        for doc_id, score, doc, meta in zip(
            sparse_results["ids"][0],
            sparse_results["scores"][0],
            sparse_results["documents"][0],
            sparse_results["metadatas"][0],
        ):
            sparse_scores[doc_id] = score
            dense_docs.setdefault(doc_id, doc)
            dense_metas.setdefault(doc_id, meta)

        # Normalize scores to [0, 1]
        norm_dense = _min_max_normalize(dense_scores)
        norm_sparse = _min_max_normalize(sparse_scores)

        # Fuse: all doc IDs from both sources
        all_ids = set(dense_scores) | set(sparse_scores)
        fused = {}
        for doc_id in all_ids:
            d = norm_dense.get(doc_id, 0.0)
            s = norm_sparse.get(doc_id, 0.0)
            fused[doc_id] = self.alpha * d + (1 - self.alpha) * s

        # Sort by fused score, take top-k
        sorted_ids = sorted(
            fused, key=fused.get, reverse=True
        )[:k]

        # Format as ChromaDB-compatible result
        # distances = 1 - fused_score (to match cosine distance)
        result_ids = sorted_ids
        result_distances = [
            1.0 - fused[did] for did in sorted_ids
        ]
        result_docs = [
            dense_docs.get(did, "") for did in sorted_ids
        ]
        result_metas = [
            dense_metas.get(did, {}) for did in sorted_ids
        ]

        return {
            "ids": [result_ids],
            "distances": [result_distances],
            "documents": [result_docs],
            "metadatas": [result_metas],
        }


def _min_max_normalize(
    scores: Dict[str, float],
) -> Dict[str, float]:
    """Normalize scores to [0, 1] range."""
    if not scores:
        return {}
    vals = list(scores.values())
    mn, mx = min(vals), max(vals)
    if mx == mn:
        return {k: 1.0 for k in scores}
    return {
        k: (v - mn) / (mx - mn)
        for k, v in scores.items()
    }
