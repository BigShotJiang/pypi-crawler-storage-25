"""
BM25 sparse retrieval index for hybrid search.

Builds a keyword-based index from ChromaDB documents
and returns BM25 relevance scores for queries.
"""

from __future__ import annotations

import numpy as np
from typing import TYPE_CHECKING, Dict, List

if TYPE_CHECKING:
    from rag_router.store.chroma_store import ChromaStore


class BM25Store:
    """
    BM25 sparse retrieval index built from stored documents.

    Used alongside ChromaDB for hybrid search
    (dense vector + sparse keyword fusion).
    """

    def __init__(
        self,
        documents: List[str],
        metadatas: List[dict],
        ids: List[str],
    ):
        from rank_bm25 import BM25Okapi

        self.documents = documents
        self.metadatas = metadatas
        self.ids = ids

        tokenized = [
            doc.lower().split() for doc in documents
        ]
        self.bm25 = BM25Okapi(tokenized)

    @classmethod
    def from_chroma_store(
        cls, chroma_store: ChromaStore
    ) -> BM25Store:
        """Build BM25 index from all docs in ChromaDB."""
        all_data = chroma_store.get_all()
        return cls(
            documents=all_data["documents"],
            metadatas=all_data["metadatas"],
            ids=all_data["ids"],
        )

    def query(
        self, query: str, k: int = 20
    ) -> Dict:
        """
        Return top-k documents by BM25 score.

        Returns dict matching ChromaDB result format:
            {
                "ids": [[...]],
                "documents": [[...]],
                "metadatas": [[...]],
                "scores": [[...]]
            }
        """
        tokenized_query = query.lower().split()
        scores = self.bm25.get_scores(tokenized_query)

        # Get top-k indices
        top_indices = np.argsort(scores)[::-1][:k]

        result_ids = [self.ids[i] for i in top_indices]
        result_docs = [
            self.documents[i] for i in top_indices
        ]
        result_metas = [
            self.metadatas[i] for i in top_indices
        ]
        result_scores = [
            float(scores[i]) for i in top_indices
        ]

        return {
            "ids": [result_ids],
            "documents": [result_docs],
            "metadatas": [result_metas],
            "scores": [result_scores],
        }

    def count(self) -> int:
        """Return number of indexed documents."""
        return len(self.documents)
