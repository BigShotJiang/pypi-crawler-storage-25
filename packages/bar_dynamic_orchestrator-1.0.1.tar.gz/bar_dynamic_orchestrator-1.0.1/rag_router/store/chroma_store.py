"""
ChromaDB vector store wrapper for the RAG Similarity Router.
"""

import chromadb

from rag_router.config.settings import CHROMA_PERSIST_DIR, COLLECTION_NAME


class ChromaStore:
    def __init__(
        self,
        persist_dir: str = CHROMA_PERSIST_DIR,
        collection_name: str = COLLECTION_NAME,
    ):
        self.client = chromadb.PersistentClient(path=persist_dir)
        self.collection = self.client.get_or_create_collection(
            name=collection_name,
            metadata={"hnsw:space": "cosine"},
        )

    def add_documents(
        self,
        ids: list[str],
        documents: list[str],
        embeddings: list[list[float]],
        metadatas: list[dict],
    ) -> None:
        """Batch add documents with pre-computed embeddings."""
        self.collection.add(
            ids=ids,
            documents=documents,
            embeddings=embeddings,
            metadatas=metadatas,
        )

    def query(
        self, query_embedding: list[float], k: int = 5
    ) -> dict:
        """Return top-k results with distances, documents, and metadatas."""
        return self.collection.query(
            query_embeddings=[query_embedding],
            n_results=k,
            include=["documents", "metadatas", "distances"],
        )

    def get_all(self) -> dict:
        """Get all documents from collection.

        Used by BM25Store to build a keyword index.
        """
        return self.collection.get(
            include=["documents", "metadatas"],
        )

    def get_all_with_embeddings(self) -> dict:
        """Get all documents including stored embeddings.

        Used by sklearn classifiers (LR, SVM) to build
        a training matrix from the same vectors that KNN
        searches, guaranteeing identical train/test splits.
        """
        return self.collection.get(
            include=["embeddings", "metadatas"],
        )

    def count(self) -> int:
        """Return number of documents in collection."""
        return self.collection.count()

    def reset(self) -> None:
        """Delete and recreate the collection."""
        self.client.delete_collection(self.collection.name)
        self.collection = self.client.get_or_create_collection(
            name=COLLECTION_NAME,
            metadata={"hnsw:space": "cosine"},
        )
