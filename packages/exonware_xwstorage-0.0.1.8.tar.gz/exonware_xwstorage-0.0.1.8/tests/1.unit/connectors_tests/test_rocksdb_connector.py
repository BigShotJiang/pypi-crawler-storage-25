#!/usr/bin/env python3
"""
Unit tests for RocksDB/LevelDB connector.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
import tempfile
from pathlib import Path
from unittest.mock import patch
from exonware.xwstorage.connectors.rocksdb_connector import (
    RocksDBConnectorConfig,
    RocksDBStorageConnection
)
from exonware.xwstorage.errors import XWLocationError, XWStorageError
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_rocksdb

class TestRocksDBConnectorConfig:
    """Unit tests for RocksDBConnectorConfig."""

    def test_config_initialization_rocksdb(self):
        """Test config initialization for RocksDB."""
        config = RocksDBConnectorConfig(
            path="/tmp/testdb",
            db_type="rocksdb"
        )
        assert config.connector_type == "rocksdb"
        assert config.path == Path("/tmp/testdb")
        assert config.db_type == "rocksdb"
        assert config.create_if_missing is True

    def test_config_initialization_leveldb(self):
        """Test config initialization for LevelDB."""
        config = RocksDBConnectorConfig(
            path="/tmp/testdb",
            db_type="leveldb"
        )
        assert config.db_type == "leveldb"

    def test_config_to_dict(self):
        """Test config to_dict conversion."""
        config = RocksDBConnectorConfig(
            path="/tmp/testdb",
            db_type="rocksdb"
        )
        config_dict = config.to_dict()
        assert config_dict["connector_type"] == "rocksdb"
        assert config_dict["db_type"] == "rocksdb"
        assert "path" in config_dict
@pytest.mark.xwstorage_unit
@pytest.mark.xwstorage_connector
@pytest.mark.xwstorage_rocksdb

class TestRocksDBStorageConnection:
    """Unit tests for RocksDBStorageConnection."""

    def test_connection_embedded_without_python_rocksdb(self):
        """xwformats RocksDB fallback works without python-rocksdb / native wheel."""
        with tempfile.TemporaryDirectory() as tmpdir:
            config = RocksDBConnectorConfig(
                path=tmpdir,
                db_type="rocksdb"
            )
            conn = RocksDBStorageConnection(config, "json")
            assert conn is not None

    def test_connection_with_invalid_config_type(self):
        """Test connection requires RocksDBConnectorConfig."""
        from exonware.xwstorage.connectors.local_connector import LocalConnectorConfig
        local_config = LocalConnectorConfig(address="test.json")
        with patch('exonware.xwstorage.connectors.rocksdb_connector.ROCKSDB_AVAILABLE', True):
            with pytest.raises(XWLocationError, match="Expected RocksDBConnectorConfig"):
                RocksDBStorageConnection(local_config, "json")
    @pytest.mark.asyncio

    async def test_read_write_operations_rocksdb(self):
        """Test read and write via xwformats open_rocksdb_database (native or fallback)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            config = RocksDBConnectorConfig(
                path=tmpdir,
                db_type="rocksdb"
            )
            connection = RocksDBStorageConnection(config, "json")
            await connection._ensure_connection()
            await connection.write("test_key", b"test data")
            result = await connection.read("test_key")
            assert result == b"test data"
