"""Standalone stress benchmarks for facton (not pytest).

Run all groups:
    uv run python benchmarks/stress.py

Run selected groups:
    uv run python benchmarks/stress.py --groups entity query serialization

List groups:
    uv run python benchmarks/stress.py --list-groups
"""

from __future__ import annotations

import argparse
import concurrent.futures
import json
import os
import platform
import subprocess
import sys
import tempfile
import time
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from facton import Connection, Entity, Field, Graph, JsonFileBackend, merge, rule

RESULTS_DIR = Path(__file__).parent / "results"


def _git_sha() -> str:
    try:
        return (
            subprocess.check_output(
                ["git", "rev-parse", "--short", "HEAD"],
                stderr=subprocess.DEVNULL,
            )
            .decode()
            .strip()
        )
    except Exception:
        return "unknown"


class Collector:
    def __init__(self) -> None:
        self.start = datetime.now(UTC)
        self.steps: list[dict[str, Any]] = []
        self.cases: list[dict[str, Any]] = []

    def record_step(
        self,
        *,
        group: str,
        case: str,
        label: str,
        elapsed_s: float,
        n: int | None,
        unit: str,
    ) -> None:
        entry: dict[str, Any] = {
            "group": group,
            "case": case,
            "label": label,
            "elapsed_s": round(elapsed_s, 6),
        }
        if n is not None:
            entry["n"] = n
            entry["unit"] = unit
            if elapsed_s > 0:
                entry["throughput"] = round(n / elapsed_s, 1)
        self.steps.append(entry)

    def record_case(
        self,
        *,
        group: str,
        case: str,
        status: str,
        elapsed_s: float,
        error: str | None = None,
    ) -> None:
        entry: dict[str, Any] = {
            "group": group,
            "case": case,
            "status": status,
            "elapsed_s": round(elapsed_s, 6),
        }
        if error:
            entry["error"] = error
        self.cases.append(entry)

    def save(self, selected_groups: list[str]) -> Path:
        RESULTS_DIR.mkdir(exist_ok=True)
        sha = _git_sha()
        ts = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")

        total_elapsed = (datetime.now(UTC) - self.start).total_seconds()
        case_pass = sum(1 for c in self.cases if c["status"] == "pass")
        case_fail = sum(1 for c in self.cases if c["status"] == "fail")

        uname = platform.uname()
        payload = {
            "meta": {
                "timestamp": self.start.isoformat(),
                "git_sha": sha,
                "cwd": str(Path.cwd()),
                "argv": sys.argv,
                "groups": selected_groups,
                "total_elapsed_s": round(total_elapsed, 2),
                "platform": {
                    "os": f"{uname.system} {uname.release}",
                    "arch": uname.machine,
                    "cpu": uname.processor or platform.processor() or "unknown",
                    "cpu_count": os.cpu_count(),
                    "python": sys.version.split()[0],
                    "impl": platform.python_implementation(),
                },
                "summary": {
                    "cases_total": len(self.cases),
                    "cases_pass": case_pass,
                    "cases_fail": case_fail,
                    "steps_total": len(self.steps),
                },
            },
            "cases": self.cases,
            "results": self.steps,
        }

        out = RESULTS_DIR / f"bench_{ts}_{sha}.json"
        out.write_text(json.dumps(payload, indent=2) + "\n")
        return out


class Person(Entity):
    name: str
    age: int = Field(ge=0)
    email: str = ""


class Organization(Entity):
    name: str
    size: int = 0


class Knows(Connection[Person, Person]):
    since: int | None = None


class WorksAt(Connection[Person, Organization]):
    role: str = "employee"


def _parallel_ingest_shard(args: tuple[int, int]) -> tuple[int, float]:
    """Build one shard in a separate process and return count + elapsed."""
    shard_index, shard_size = args
    g = Graph(track_history=False)
    entities = [
        Person(
            id=f"p{shard_index}_{i}",
            name=f"P{shard_index}_{i}",
            age=i % 100,
        )
        for i in range(shard_size)
    ]
    started = time.perf_counter()
    g.add_many(entities, record_history=False)
    elapsed = time.perf_counter() - started
    return g.query(Person).count(), elapsed


def _build_chain(n: int) -> tuple[Graph, list[Person]]:
    g = Graph()
    people = [Person(id=f"p{i}", name=f"P{i}", age=i % 100) for i in range(n)]
    for p in people:
        g.add(p)
    for i in range(n - 1):
        g.connect(people[i], people[i + 1], Knows(since=2020))
    return g, people


def _expect(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)


COLLECTOR = Collector()
CURRENT_GROUP = "misc"
CURRENT_CASE = "unknown"


def timed(label: str, *, n: int | None = None, unit: str = "ops"):
    class _Timer:
        def __init__(self) -> None:
            self.elapsed = 0.0

        def __enter__(self):
            self._start = time.perf_counter()
            return self

        def __exit__(self, *_: Any):
            self.elapsed = time.perf_counter() - self._start
            parts = [f"  [{label}] {self.elapsed:.4f}s"]
            if n is not None and self.elapsed > 0:
                parts.append(f"({n / self.elapsed:,.0f} {unit}/s)")
            print(" ".join(parts))
            COLLECTOR.record_step(
                group=CURRENT_GROUP,
                case=CURRENT_CASE,
                label=label,
                elapsed_s=self.elapsed,
                n=n,
                unit=unit,
            )

    return _Timer()


def case_entity() -> None:
    g = Graph()
    n = 100_000
    with timed(f"add {n} entities", n=n) as t:
        for i in range(n):
            g.add(Person(id=f"p{i}", name=f"P{i}", age=i % 100))
    _expect(g.query(Person).count() == n, "entity count mismatch")
    _expect(t.elapsed < 30.0, "add 100k too slow")


def case_batching() -> None:
    n_people = 100_000
    n_orgs = 1_000
    people = [Person(id=f"p{i}", name=f"P{i}", age=i % 80) for i in range(n_people)]
    orgs = [Organization(id=f"o{i}", name=f"O{i}", size=i * 10) for i in range(n_orgs)]

    g_hist = Graph()
    with timed(
        "add_many 100000 people + 1000 orgs (history on)",
        n=n_people + n_orgs,
    ):
        g_hist.add_many([*people, *orgs], record_history=True)
    _expect(
        len(g_hist._change_log) == n_people + n_orgs,
        "history-on batch log size mismatch",
    )

    g = Graph()
    with timed(
        "add_many 100000 people + 1000 orgs (history off)",
        n=n_people + n_orgs,
    ) as t:
        g.add_many([*people, *orgs], record_history=False)
    _expect(g.query(Person).count() == n_people, "add_many people count mismatch")
    _expect(g.query(Organization).count() == n_orgs, "add_many org count mismatch")
    _expect(t.elapsed < 10.0, "add_many batch too slow")

    edges = [
        (people[i], orgs[i % n_orgs], WorksAt(role="dev")) for i in range(n_people)
    ]
    with timed("connect_many 100000 to 1000", n=n_people):
        created = g.connect_many(edges)
    _expect(len(created) == n_people, "connect_many count mismatch")


def case_parallel() -> None:
    total = 100_000
    workers = min(4, os.cpu_count() or 1)
    if workers < 2:
        print("  [parallel skipped] need at least 2 CPU workers")
        return

    base = total // workers
    remainder = total % workers
    shard_sizes = [base + (1 if i < remainder else 0) for i in range(workers)]
    shard_args = list(enumerate(shard_sizes))

    with (
        timed(
            f"parallel ingest {total} across {workers} shards",
            n=total,
        ) as t,
        concurrent.futures.ProcessPoolExecutor(max_workers=workers) as pool,
    ):
        results = list(pool.map(_parallel_ingest_shard, shard_args))

    total_count = sum(count for count, _ in results)
    sum_worker_elapsed = sum(elapsed for _, elapsed in results)
    _expect(total_count == total, "parallel ingest total count mismatch")
    if t.elapsed > 0:
        efficiency = sum_worker_elapsed / t.elapsed
        print(f"  [parallel efficiency] worker_sum/runtime={efficiency:.2f}x")


def case_backend_batching() -> None:
    n_people = 2_000
    n_orgs = 200

    def _make_people() -> list[Person]:
        return [Person(id=f"p{i}", name=f"P{i}", age=i % 100) for i in range(n_people)]

    def _make_orgs() -> list[Organization]:
        return [
            Organization(id=f"o{i}", name=f"O{i}", size=i * 10) for i in range(n_orgs)
        ]

    with tempfile.TemporaryDirectory(prefix="facton_bench_backend_") as td:
        base_path = Path(td)

        people_seq = _make_people()
        seq_backend = JsonFileBackend(base_path / "seq.json", types=[Person])
        seq_graph = Graph(backend=seq_backend, track_history=False)
        with timed("json backend add one-by-one 2000", n=n_people) as t_seq:
            for person in people_seq:
                seq_graph.add(person)

        people_batch = _make_people()
        batch_backend = JsonFileBackend(base_path / "batch.json", types=[Person])
        batch_graph = Graph(backend=batch_backend, track_history=False)
        with timed("json backend add_many 2000", n=n_people) as t_batch:
            batch_graph.add_many(people_batch, record_history=False)

        _expect(
            batch_graph.query(Person).count() == n_people,
            "json backend add_many count mismatch",
        )
        _expect(
            seq_graph.query(Person).count() == n_people,
            "json backend sequential add count mismatch",
        )
        _expect(
            t_batch.elapsed < t_seq.elapsed,
            "json backend add_many should outperform one-by-one",
        )

        people_conn_seq = _make_people()
        orgs_conn_seq = _make_orgs()
        edges_seq = [
            (people_conn_seq[i], orgs_conn_seq[i % n_orgs], WorksAt(role="dev"))
            for i in range(n_people)
        ]
        seq_conn_backend = JsonFileBackend(
            base_path / "conn_seq.json",
            types=[Person, Organization, WorksAt],
        )
        seq_conn_graph = Graph(backend=seq_conn_backend, track_history=False)
        seq_conn_graph.add_many(
            [*people_conn_seq, *orgs_conn_seq],
            record_history=False,
        )
        with timed("json backend connect one-by-one 2000", n=n_people) as t_conn_seq:
            for source, target, connection in edges_seq:
                seq_conn_graph.connect(source, target, connection)

        people_conn_batch = _make_people()
        orgs_conn_batch = _make_orgs()
        edges_batch = [
            (people_conn_batch[i], orgs_conn_batch[i % n_orgs], WorksAt(role="dev"))
            for i in range(n_people)
        ]
        batch_conn_backend = JsonFileBackend(
            base_path / "conn_batch.json",
            types=[Person, Organization, WorksAt],
        )
        batch_conn_graph = Graph(backend=batch_conn_backend, track_history=False)
        batch_conn_graph.add_many(
            [*people_conn_batch, *orgs_conn_batch],
            record_history=False,
        )
        with timed("json backend connect_many 2000", n=n_people) as t_conn_batch:
            created = batch_conn_graph.connect_many(edges_batch)

        _expect(
            len(created) == n_people,
            "json backend connect_many count mismatch",
        )
        _expect(
            len(seq_conn_graph._connections) == n_people,
            "json backend sequential connect count mismatch",
        )
        _expect(
            len(batch_conn_graph._connections) == n_people,
            "json backend connect_many graph state mismatch",
        )
        _expect(
            t_conn_batch.elapsed < t_conn_seq.elapsed,
            "json backend connect_many should outperform one-by-one",
        )


def case_query() -> None:
    g = Graph()
    for i in range(100_000):
        g.add(Person(id=f"p{i}", name=f"P{i}", age=i % 100))

    with timed("filter age > 50 over 100k", n=100_000) as t:
        rows = g.query(Person).where(lambda p: p.age > 50).all()
    _expect(len(rows) == 49_000, "filter result mismatch")
    _expect(t.elapsed < 2.0, "filter too slow")


def case_traversal() -> None:
    g, people = _build_chain(100_000)
    with timed("traverse depth=1000 on 100k chain", n=100_000) as t:
        result = g.traverse(people[0], Knows, depth=1000)
    _expect(len(result) == 1000, "traversal result mismatch")
    _expect(t.elapsed < 2.0, "traversal too slow")


def case_algorithms() -> None:
    g, people = _build_chain(50_000)
    with timed("shortest_path across 50k chain", n=50_000) as t:
        path = g.shortest_path(people[0], people[-1], Knows)
    _expect(path is not None and len(path) == 50_000, "shortest_path mismatch")
    _expect(t.elapsed < 30.0, "shortest_path too slow")


def case_serialization() -> None:
    g, _ = _build_chain(100_000)

    with timed("to_dict 100k", n=100_000, unit="entities") as t1:
        data = g.to_dict()
    with timed("json.dumps") as t2:
        raw = json.dumps(data, default=str)
    with timed("json.loads") as t3:
        restored = json.loads(raw)
    with timed("from_dict") as t4:
        g2 = Graph.from_dict(
            restored,
            type_registry={
                Person.__qualname__: Person,
                Knows.__qualname__: Knows,
            },
            restore_history=False,
        )

    _expect(len(g2._entities) == 100_000, "roundtrip entity count mismatch")
    _expect(len(g2._connections) == 99_999, "roundtrip connection count mismatch")
    total = t1.elapsed + t2.elapsed + t3.elapsed + t4.elapsed
    print(f"  [total roundtrip] {total:.4f}s")
    _expect(total < 60.0, "roundtrip too slow")


def case_constraints() -> None:
    class Employee(Entity):
        name: str
        badge: str = Field(unique=True)

    g = Graph()
    n = 100_000
    with timed(f"add {n} with unique constraint", n=n) as t:
        for i in range(n):
            g.add(Employee(id=f"e{i}", name=f"E{i}", badge=f"B{i}"))
    _expect(g.query(Employee).count() == n, "unique add count mismatch")
    _expect(t.elapsed < 60.0, "unique constraint add too slow")

    dup_ok = False
    try:
        g.add(Employee(id="dup", name="Dup", badge="B0"))
    except ValueError:
        dup_ok = True
    _expect(dup_ok, "duplicate unique value should fail")


def case_rules() -> None:
    @rule
    def mutual_knows(graph: Graph) -> None:
        for stored in list(graph._connections):
            if isinstance(stored.connection, Knows) and not stored.derived:
                reverse_exists = any(
                    c
                    for c in graph._outgoing.get(stored.target_id, ())
                    if isinstance(c.connection, Knows)
                    and c.target_id == stored.source_id
                )
                if not reverse_exists:
                    graph.derive(
                        stored.target_id,
                        stored.source_id,
                        Knows(since=stored.connection.since),
                    )

    g, _ = _build_chain(10_000)
    g.register_rule(mutual_knows)

    with timed("run_rules deriving ~10k connections", n=10_000) as t:
        g.run_rules()
    _expect(len(g._connections) >= 2 * 9_999 - 1, "rules result mismatch")
    _expect(t.elapsed < 10.0, "rules too slow")


def case_merge() -> None:
    g1 = Graph()
    g2 = Graph()
    n = 50_000
    for i in range(n):
        g1.add(Person(id=f"p{i}", name=f"P{i}", age=i))
    for i in range(n):
        g2.add(Person(id=f"q{i}", name=f"Q{i}", age=i))

    with timed(f"merge 2x{n}", n=n * 2, unit="entities") as t:
        merged = merge(g1, g2)
    _expect(len(merged._entities) == 2 * n, "merge entity count mismatch")
    _expect(t.elapsed < 30.0, "merge too slow")


def case_mixed() -> None:
    g = Graph()
    n_people = 100_000
    n_orgs = 1_000

    with timed(f"load {n_people} people + {n_orgs} orgs", n=n_people + n_orgs):
        for i in range(n_people):
            g.add(Person(id=f"p{i}", name=f"P{i}", age=i % 80))
        for i in range(n_orgs):
            g.add(Organization(id=f"o{i}", name=f"O{i}", size=i * 10))

    people_ids = [f"p{i}" for i in range(n_people)]

    with timed(f"connect {n_people} to {n_orgs} orgs", n=n_people):
        for i in range(n_people):
            g.connect(
                g.get(Person, people_ids[i]),
                g.get(Organization, f"o{i % n_orgs}"),
                WorksAt(role="dev"),
            )


CASE_REGISTRY: dict[str, tuple[str, Callable[[], None]]] = {
    "batching": ("batching", case_batching),
    "backend": ("backend", case_backend_batching),
    "parallel": ("parallel", case_parallel),
    "entity": ("entity", case_entity),
    "query": ("query", case_query),
    "traversal": ("traversal", case_traversal),
    "algorithms": ("algorithms", case_algorithms),
    "serialization": ("serialization", case_serialization),
    "constraints": ("constraints", case_constraints),
    "rules": ("rules", case_rules),
    "merge": ("merge", case_merge),
    "mixed": ("mixed", case_mixed),
}


def _run_case(name: str, group: str, fn: Callable[[], None]) -> bool:
    global CURRENT_CASE, CURRENT_GROUP
    CURRENT_CASE = name
    CURRENT_GROUP = group

    print(f"\n== {name} ==")
    started = time.perf_counter()
    try:
        fn()
    except Exception as exc:  # pragma: no cover - script failure path
        elapsed = time.perf_counter() - started
        COLLECTOR.record_case(
            group=group,
            case=name,
            status="fail",
            elapsed_s=elapsed,
            error=f"{type(exc).__name__}: {exc}",
        )
        print(f"  [FAIL] {exc}")
        return False

    elapsed = time.perf_counter() - started
    COLLECTOR.record_case(group=group, case=name, status="pass", elapsed_s=elapsed)
    print(f"  [PASS] {elapsed:.3f}s")
    return True


def main() -> int:
    parser = argparse.ArgumentParser(description="Run facton stress benchmarks")
    parser.add_argument(
        "--groups",
        nargs="*",
        default=list(CASE_REGISTRY.keys()),
        help="Case names to run",
    )
    parser.add_argument("--list-groups", action="store_true", help="List case names")
    parser.add_argument(
        "--fail-fast", action="store_true", help="Stop on first failure"
    )
    args = parser.parse_args()

    if args.list_groups:
        for name in CASE_REGISTRY:
            print(name)
        return 0

    selected = args.groups
    unknown = [name for name in selected if name not in CASE_REGISTRY]
    if unknown:
        print(f"Unknown case(s): {', '.join(unknown)}")
        return 2

    print(f"Running cases: {', '.join(selected)}")
    ok = True
    for name in selected:
        group, fn = CASE_REGISTRY[name]
        passed = _run_case(name, group, fn)
        if not passed:
            ok = False
            if args.fail_fast:
                break

    path = COLLECTOR.save(selected)
    print(f"\nBenchmark results saved to: {path}")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
