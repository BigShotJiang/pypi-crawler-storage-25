#!/usr/bin/env python3
"""Compare two benchmark result files side-by-side.

Usage::

    uv run python benchmarks/compare.py \
        benchmarks/results/bench_A.json \
        benchmarks/results/bench_B.json

Or compare the two most recent runs::

    uv run python benchmarks/compare.py --latest
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

RESULTS_DIR = Path(__file__).parent / "results"


def load(path: Path) -> dict:
    return json.loads(path.read_text())


def _results_by_label(data: dict) -> dict[str, dict]:
    """Normalise results to {label: record} regardless of format."""
    results = data["results"]
    if isinstance(results, list):
        keyed: dict[str, dict] = {}
        for r in results:
            case = r.get("case")
            label = r.get("label", "")
            key = f"{case} :: {label}" if case else label
            keyed[key] = r
        return keyed
    # Legacy flat format: {label: seconds}
    return {k: {"label": k, "elapsed_s": v} for k, v in results.items()}


def compare(a_path: Path, b_path: Path) -> None:
    a = load(a_path)
    b = load(b_path)
    ar = _results_by_label(a)
    br = _results_by_label(b)

    a_meta = a["meta"]
    b_meta = b["meta"]
    print(f"  A: {a_path.name}  (sha={a_meta.get('git_sha', '?')})")
    print(f"  B: {b_path.name}  (sha={b_meta.get('git_sha', '?')})")
    print()

    hdr = (
        f"  {'Benchmark':<45} {'A (s)':>9} {'B (s)':>9}"
        f" {'Change':>10} {'Throughput A':>14} {'Throughput B':>14}"
    )
    print(hdr)
    print(f"  {'-' * len(hdr.strip())}")

    all_keys = dict.fromkeys([*ar, *br])
    for key in all_keys:
        ra = ar.get(key, {})
        rb = br.get(key, {})
        va = ra.get("elapsed_s")
        vb = rb.get("elapsed_s")

        sa = f"{va:.4f}" if va is not None else "-"
        sb = f"{vb:.4f}" if vb is not None else "-"

        if va is not None and vb is not None and va > 0:
            pct = (vb - va) / va * 100
            if abs(pct) < 5:
                change = "~"
            elif pct < 0:
                change = f"{pct:+.0f}% faster"
            else:
                change = f"{pct:+.0f}% SLOWER"
        else:
            change = ""

        def _tp(rec: dict) -> str:
            tp = rec.get("throughput")
            unit = rec.get("unit", "ops")
            if tp is None:
                return "-"
            return f"{tp:,.0f} {unit}/s"

        print(f"  {key:<45} {sa:>9} {sb:>9} {change:>10} {_tp(ra):>14} {_tp(rb):>14}")


def latest_two() -> tuple[Path, Path]:
    files = sorted(RESULTS_DIR.glob("bench_*.json"))
    if len(files) < 2:
        print(f"Need at least 2 result files in {RESULTS_DIR}, found {len(files)}")
        sys.exit(1)
    return files[-2], files[-1]


def main() -> None:
    parser = argparse.ArgumentParser(description="Compare benchmark results")
    parser.add_argument("files", nargs="*", help="Two JSON result files to compare")
    parser.add_argument(
        "--latest", action="store_true", help="Compare the two most recent results"
    )
    args = parser.parse_args()

    if args.latest:
        a, b = latest_two()
    elif len(args.files) == 2:
        a, b = Path(args.files[0]), Path(args.files[1])
    else:
        parser.print_help()
        sys.exit(1)

    compare(a, b)


if __name__ == "__main__":
    main()
