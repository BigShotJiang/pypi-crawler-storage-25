"""Relation — n-ary relationships with auto-detected entity participants."""

from __future__ import annotations

from typing import Any, ClassVar, get_type_hints

from pydantic import BaseModel, ConfigDict

from facton.entity import Entity


class Relation(BaseModel):
    """An n-ary relationship with typed entity participants.

    Unlike ``Connection`` which is binary and directional, ``Relation``
    supports any number of typed participants.  Entity-typed fields are
    auto-detected as participant references; all other fields are plain
    relation data::

        class Assignment(Relation):
            person: Person       # participant (auto-detected)
            project: Project     # participant (auto-detected)
            allocation: float    # data field
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    _participant_fields: ClassVar[dict[str, type[Entity]]]
    _relation_annotations: dict[str, Any]

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        # Inspect annotations to find Entity-typed fields.
        participants: dict[str, type[Entity]] = {}
        hints = get_type_hints(cls)
        for name, hint in hints.items():
            if name.startswith("_"):
                continue
            if isinstance(hint, type) and issubclass(hint, Entity):
                participants[name] = hint
        cls._participant_fields = participants

    def model_post_init(self, __context: Any) -> None:
        self._relation_annotations = {}

    @property
    def participants(self) -> dict[str, Entity]:
        """Return a mapping of role name → entity for all participants."""
        return {name: getattr(self, name) for name in type(self)._participant_fields}

    @property
    def participant_ids(self) -> set[str]:
        """Return the set of entity IDs involved in this relation."""
        return {entity.id for entity in self.participants.values()}

    def annotate(self, **kwargs: Any) -> None:
        """Attach metadata to this relation."""
        self._relation_annotations.update(kwargs)

    @property
    def relation_annotations(self) -> dict[str, Any]:
        """Return a copy of the annotations on this relation."""
        return dict(self._relation_annotations)
