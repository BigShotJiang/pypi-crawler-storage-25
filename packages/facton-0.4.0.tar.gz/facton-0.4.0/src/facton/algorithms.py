"""Graph algorithms — shortest path, connected components."""

from __future__ import annotations

from collections import deque
from typing import TYPE_CHECKING, Any

from facton.connection import Connection
from facton.entity import Entity

if TYPE_CHECKING:
    from facton.graph import Graph


def shortest_path(
    graph: Graph,
    start: Entity | str,
    end: Entity | str,
    connection_type: type[Connection[Any, Any]],
) -> list[Entity] | None:
    """Find the shortest path between two entities via BFS.

    Returns a list of entities from start to end (inclusive), or
    ``None`` if no path exists.
    """
    start_id = start if isinstance(start, str) else start.id
    end_id = end if isinstance(end, str) else end.id
    if start_id == end_id:
        entity = graph._entities.get(start_id)
        return [entity] if entity else None

    # Track predecessors and reconstruct once at the end to avoid copying
    # full path lists at every BFS step.
    predecessors: dict[str, str | None] = {start_id: None}
    queue: deque[str] = deque([start_id])

    def _reconstruct(end_node: str) -> list[Entity]:
        path_ids: list[str] = []
        current: str | None = end_node
        while current is not None:
            path_ids.append(current)
            current = predecessors[current]
        path_ids.reverse()
        return [graph._entities[eid] for eid in path_ids]

    while queue:
        current_id = queue.popleft()
        for stored in graph._outgoing.get(current_id, ()):
            if isinstance(stored.connection, connection_type):
                nid = stored.target_id
                if nid not in predecessors:
                    predecessors[nid] = current_id
                    if nid == end_id:
                        return _reconstruct(end_id)
                    queue.append(nid)
        for stored in graph._incoming.get(current_id, ()):
            if isinstance(stored.connection, connection_type):
                nid = stored.source_id
                if nid not in predecessors:
                    predecessors[nid] = current_id
                    if nid == end_id:
                        return _reconstruct(end_id)
                    queue.append(nid)
    return None


def components(
    graph: Graph,
    connection_type: type[Connection[Any, Any]] | None = None,
) -> list[set[str]]:
    """Find connected components (undirected).

    Returns a list of sets, each containing the entity ids of one
    component. If ``connection_type`` is given, only those edges are
    considered.
    """
    remaining = set(graph._entities.keys())
    result: list[set[str]] = []
    while remaining:
        seed = next(iter(remaining))
        component: set[str] = set()
        frontier = [seed]
        while frontier:
            eid = frontier.pop()
            if eid in component:
                continue
            component.add(eid)
            for stored in graph._outgoing.get(eid, ()):
                if (
                    connection_type is None
                    or isinstance(stored.connection, connection_type)
                ) and stored.target_id not in component:
                    frontier.append(stored.target_id)
            for stored in graph._incoming.get(eid, ()):
                if (
                    connection_type is None
                    or isinstance(stored.connection, connection_type)
                ) and stored.source_id not in component:
                    frontier.append(stored.source_id)
        result.append(component)
        remaining -= component
    return result
