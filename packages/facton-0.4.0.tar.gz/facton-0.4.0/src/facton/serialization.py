"""Graph serialization — to_dict / from_dict / save_file / load_file."""

from __future__ import annotations

import json
from pathlib import Path
from typing import TYPE_CHECKING, Any, Union

from facton.connection import Connection
from facton.constraint import Constraint, Unique
from facton.entity import Entity

if TYPE_CHECKING:
    from facton.graph import Graph


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _annotation_name(annotation: Any) -> str:
    """Convert a type annotation to a portable string."""
    import types

    origin = getattr(annotation, "__origin__", None)
    if origin is types.UnionType or origin is Union:
        args = annotation.__args__
        return " | ".join(_annotation_name(a) for a in args)
    if origin is not None:
        args = getattr(annotation, "__args__", ())
        base = getattr(origin, "__qualname__", str(origin))
        if args:
            inner = ", ".join(_annotation_name(a) for a in args)
            return f"{base}[{inner}]"
        return base
    if annotation is type(None):
        return "None"
    if hasattr(annotation, "__qualname__"):
        mod = getattr(annotation, "__module__", "")
        name = annotation.__qualname__
        if mod in ("builtins", ""):
            return name
        return f"{mod}.{name}"
    return str(annotation)


def _extract_field_meta(finfo: Any) -> dict[str, Any]:
    """Extract serializable constraints and defaults from a FieldInfo."""
    from pydantic_core import PydanticUndefined

    meta: dict[str, Any] = {}
    for m in getattr(finfo, "metadata", []):
        for attr in ("ge", "le", "gt", "lt"):
            val = getattr(m, attr, None)
            if val is not None:
                meta[attr] = val
        for attr in ("max_length", "min_length"):
            val = getattr(m, attr, None)
            if val is not None:
                meta[attr] = val
        pattern = getattr(m, "pattern", None)
        if pattern is not None:
            meta["pattern"] = pattern
    extra = getattr(finfo, "json_schema_extra", None)
    if isinstance(extra, dict):
        for k, v in extra.items():
            meta[k] = v
    if finfo.default is not PydanticUndefined:
        meta["default"] = finfo.default
    return meta


def _extract_type_constraints(cls: type) -> list[dict[str, Any]]:
    """Extract serializable constraints from a type's Meta class."""
    meta_cls = getattr(cls, "Meta", None)
    constraints_list = getattr(meta_cls, "constraints", []) if meta_cls else []
    result: list[dict[str, Any]] = []
    for c in constraints_list:
        if isinstance(c, Unique):
            result.append(
                {"kind": "unique", "fields": list(c.fields)},
            )
        elif isinstance(c, Constraint):
            entry: dict[str, Any] = {
                "kind": c.kind,
                "limit": c.limit,
            }
            if c.predicate is not None:
                entry["has_predicate"] = True
            result.append(entry)
    return result


def _collect_fact_annotations(obj: Any) -> dict[str, dict[str, Any]]:
    """Collect annotations from Fact-wrapped fields."""
    from facton.fact import Fact

    result: dict[str, dict[str, Any]] = {}
    for fname in type(obj).model_fields:
        if fname == "id":
            continue
        val = getattr(obj, fname, None)
        if isinstance(val, Fact) and val._annotations:
            result[fname] = dict(val._annotations)
    return result


def _build_schema(graph: Graph) -> dict[str, Any]:
    """Build a self-describing schema for all types in the graph."""
    entity_types: dict[str, dict[str, Any]] = {}
    connection_types: dict[str, dict[str, Any]] = {}

    def _register_entity_type(cls: type) -> None:
        name = cls.__qualname__
        if name in entity_types:
            return
        fields: dict[str, Any] = {}
        for fname, finfo in cls.model_fields.items():
            if fname == "id":
                continue
            field_meta: dict[str, Any] = {
                "type": _annotation_name(finfo.annotation),
            }
            field_meta.update(_extract_field_meta(finfo))
            fields[fname] = field_meta
        entry: dict[str, Any] = {"fields": fields}
        constraints = _extract_type_constraints(cls)
        if constraints:
            entry["constraints"] = constraints
        entity_types[name] = entry

    def _register_connection_type(cls: type) -> None:
        name = cls.__qualname__
        if name in connection_types:
            return
        fields: dict[str, Any] = {}
        for fname, finfo in cls.model_fields.items():
            field_meta: dict[str, Any] = {
                "type": _annotation_name(finfo.annotation),
            }
            field_meta.update(_extract_field_meta(finfo))
            fields[fname] = field_meta
        src_type = getattr(cls, "source_type", None)
        tgt_type = getattr(cls, "target_type", None)
        entry: dict[str, Any] = {
            "source_type": (
                src_type.__qualname__ if isinstance(src_type, type) else None
            ),
            "target_type": (
                tgt_type.__qualname__ if isinstance(tgt_type, type) else None
            ),
            "fields": fields,
        }
        constraints = _extract_type_constraints(cls)
        if constraints:
            entry["constraints"] = constraints
        connection_types[name] = entry

    for entity in graph._entities.values():
        _register_entity_type(type(entity))
    for stored in graph._connections:
        _register_connection_type(type(stored.connection))
    for record in graph._change_log:
        if record.data is not None:
            _register_entity_type(type(record.data))

    return {"entities": entity_types, "connections": connection_types}


def _serialize_entity(entity: Entity) -> dict[str, Any]:
    """Serialize an entity including its annotations."""
    result: dict[str, Any] = {
        "type": type(entity).__qualname__,
        "data": entity.model_dump(mode="json"),
    }
    annots = getattr(entity, "_entity_annotations", {})
    if annots:
        result["annotations"] = dict(annots)
    fact_annots = _collect_fact_annotations(entity)
    if fact_annots:
        result["field_annotations"] = fact_annots
    return result


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def graph_to_dict(graph: Graph) -> dict[str, Any]:
    """Serialize a graph to a self-describing, lossless dict."""
    entities = [_serialize_entity(e) for e in graph._entities.values()]

    connections: list[dict[str, Any]] = []
    for stored in graph._connections:
        entry: dict[str, Any] = {
            "source_id": stored.source_id,
            "target_id": stored.target_id,
            "type": type(stored.connection).__qualname__,
            "data": stored.connection.model_dump(mode="json"),
            "derived": stored.derived,
        }
        annots = getattr(
            stored.connection,
            "_connection_annotations",
            {},
        )
        if annots:
            entry["annotations"] = dict(annots)
        fact_annots = _collect_fact_annotations(stored.connection)
        if fact_annots:
            entry["field_annotations"] = fact_annots
        connections.append(entry)

    change_log: list[dict[str, Any]] = []
    for record in graph._change_log:
        log_entry: dict[str, Any] = {
            "entity_id": record.entity_id,
            "operation": record.operation,
            "timestamp": record.timestamp.isoformat(),
        }
        if record.data is not None:
            log_entry["type"] = type(record.data).__qualname__
            log_entry["data"] = record.data.model_dump(mode="json")
            a = getattr(record.data, "_entity_annotations", {})
            if a:
                log_entry["annotations"] = dict(a)
            fa = _collect_fact_annotations(record.data)
            if fa:
                log_entry["field_annotations"] = fa
        change_log.append(log_entry)

    snapshots = {name: ts.isoformat() for name, ts in graph._snapshots.items()}

    result: dict[str, Any] = {
        "schema": _build_schema(graph),
        "entities": entities,
        "connections": connections,
    }
    if change_log:
        result["change_log"] = change_log
    if snapshots:
        result["snapshots"] = snapshots
    return result


def _resolve_annotation(type_str: str) -> Any:
    """Resolve a type string back to a Python type."""
    import datetime

    _BUILTINS: dict[str, Any] = {
        "str": str,
        "int": int,
        "float": float,
        "bool": bool,
        "None": type(None),
        "bytes": bytes,
        "datetime.date": datetime.date,
        "datetime.datetime": datetime.datetime,
        "datetime.time": datetime.time,
        "datetime.timedelta": datetime.timedelta,
    }
    if " | " in type_str:
        import functools
        import operator

        parts = [_resolve_annotation(p.strip()) for p in type_str.split(" | ")]
        return functools.reduce(operator.or_, parts)

    if "[" in type_str:
        base_str, rest = type_str.split("[", 1)
        inner_str = rest.rstrip("]")
        base = _BUILTINS.get(base_str, str)
        inner = _resolve_annotation(inner_str)
        return base[inner]  # type: ignore[index]

    return _BUILTINS.get(type_str, str)


def _create_types_from_schema(
    schema: dict[str, Any],
    registry: dict[str, type],
) -> None:
    """Dynamically create Entity/Connection subclasses from schema."""
    from facton.field import Field as FieldFn

    def _build_fields(
        fields_info: dict[str, Any],
        ns: dict[str, Any],
    ) -> dict[str, Any]:
        annotations: dict[str, Any] = {}
        for fname, fmeta in fields_info.items():
            if isinstance(fmeta, str):
                annotations[fname] = _resolve_annotation(fmeta)
            else:
                annotations[fname] = _resolve_annotation(fmeta["type"])
                field_kw = {k: v for k, v in fmeta.items() if k != "type"}
                if field_kw:
                    ns[fname] = FieldFn(**field_kw)
        return annotations

    def _apply_constraints(
        target_cls: type,
        constraints: list[dict[str, Any]],
    ) -> None:
        if not constraints:
            return
        meta_constraints: list[Any] = []
        for c in constraints:
            if c["kind"] == "unique":
                meta_constraints.append(Unique(*c["fields"]))
            elif c["kind"] in ("max_per_source", "max_per_target"):
                meta_constraints.append(
                    Constraint(kind=c["kind"], limit=c["limit"]),
                )
        if meta_constraints:
            meta_cls = type(
                "Meta",
                (),
                {"constraints": meta_constraints},
            )
            target_cls.Meta = meta_cls  # type: ignore[attr-defined]

    for name, type_info in schema.get("entities", {}).items():
        if name in registry:
            continue
        if isinstance(type_info, dict) and "fields" in type_info:
            fields_info = type_info["fields"]
        else:
            fields_info = type_info
        ns: dict[str, Any] = {
            "__module__": __name__,
            "__qualname__": name,
        }
        annotations = _build_fields(fields_info, ns)
        annotations["id"] = str
        ns["__annotations__"] = annotations
        entity_cls = type(name, (Entity,), ns)
        if isinstance(type_info, dict):
            _apply_constraints(
                entity_cls,
                type_info.get("constraints", []),
            )
        entity_cls.model_rebuild()
        registry[name] = entity_cls

    for name, info in schema.get("connections", {}).items():
        if name in registry:
            continue
        src_name = info.get("source_type")
        tgt_name = info.get("target_type")
        src_cls = registry.get(src_name, Entity) if src_name else Entity
        tgt_cls = registry.get(tgt_name, Entity) if tgt_name else Entity
        fields_info = info.get("fields", {})
        ns: dict[str, Any] = {
            "__module__": __name__,
            "__qualname__": name,
            "source_type": src_cls,
            "target_type": tgt_cls,
        }
        annotations = _build_fields(fields_info, ns)
        ns["__annotations__"] = annotations
        conn_cls = type(name, (Connection,), ns)
        conn_cls.source_type = src_cls  # type: ignore[attr-defined]
        conn_cls.target_type = tgt_cls  # type: ignore[attr-defined]
        _apply_constraints(
            conn_cls,
            info.get("constraints", []),
        )
        conn_cls.model_rebuild()
        registry[name] = conn_cls


def graph_from_dict(
    data: dict[str, Any],
    *,
    type_registry: dict[str, type] | None = None,
    restore_history: bool = True,
) -> Graph:
    """Restore a graph from a dict produced by ``graph_to_dict()``."""
    from datetime import datetime

    from facton.fact import Fact
    from facton.graph import Graph, _StoredConnection
    from facton.temporal import ChangeRecord

    registry = dict(type_registry) if type_registry else {}

    schema = data.get("schema", {})
    if schema:
        _create_types_from_schema(schema, registry)

    def _resolve(name: str) -> type:
        if name in registry:
            return registry[name]
        msg = (
            f"Type {name!r} not found. Provide a type_registry or"
            f" ensure the JSON includes a schema section."
        )
        raise KeyError(msg)

    def _restore_fact_annotations(
        obj: Any,
        field_annotations: dict[str, Any],
    ) -> None:
        for fname, fa in field_annotations.items():
            val = getattr(obj, fname, None)
            if isinstance(val, Fact) and fa:
                val._annotations.update(fa)

    graph = Graph(track_history=restore_history)
    for entry in data.get("entities", []):
        entity_cls = _resolve(entry["type"])
        entity = entity_cls.model_validate(entry["data"])
        if entry.get("annotations"):
            entity._entity_annotations.update(entry["annotations"])
        if entry.get("field_annotations"):
            _restore_fact_annotations(entity, entry["field_annotations"])
        graph._entities[entity.id] = entity
        for cls in type(entity).__mro__:
            if cls is Entity or issubclass(cls, Entity):
                graph._by_type[cls].add(entity.id)
        graph._index_entity(entity)

    for entry in data.get("connections", []):
        conn_cls = _resolve(entry["type"])
        conn = conn_cls.model_validate(entry["data"])
        if entry.get("annotations"):
            conn._connection_annotations.update(entry["annotations"])
        if entry.get("field_annotations"):
            _restore_fact_annotations(conn, entry["field_annotations"])
        source_id = entry["source_id"]
        target_id = entry["target_id"]
        if source_id not in graph._entities:
            msg = f"Source entity {source_id!r} not found during deserialization"
            raise KeyError(msg)
        if target_id not in graph._entities:
            msg = f"Target entity {target_id!r} not found during deserialization"
            raise KeyError(msg)
        stored = _StoredConnection(
            source_id=source_id,
            target_id=target_id,
            connection=conn,
            derived=bool(entry.get("derived")),
        )
        graph._connections.append(stored)
        graph._outgoing[source_id].append(stored)
        graph._incoming[target_id].append(stored)

    if restore_history and "change_log" in data:
        graph._change_log.clear()
        for entry in data["change_log"]:
            entity_data = None
            if "data" in entry and "type" in entry:
                ecls = _resolve(entry["type"])
                entity_data = ecls.model_validate(entry["data"])
                if entry.get("annotations"):
                    entity_data._entity_annotations.update(entry["annotations"])
                if entry.get("field_annotations"):
                    _restore_fact_annotations(
                        entity_data,
                        entry["field_annotations"],
                    )
            record = ChangeRecord(
                entity_id=entry["entity_id"],
                operation=entry["operation"],
                data=entity_data,
                timestamp=datetime.fromisoformat(entry["timestamp"]),
            )
            graph._change_log.append(record)

    if restore_history and "snapshots" in data:
        for name, ts_str in data["snapshots"].items():
            graph._snapshots[name] = datetime.fromisoformat(ts_str)

    if restore_history and "change_log" not in data:
        # Keep backward-compatible behaviour for payloads without explicit
        # history by recording synthetic "add" events for loaded entities.
        for entity in graph._entities.values():
            graph._record_change(entity.id, "add", entity)

    return graph


def save_file(graph: Graph, path: str | Any) -> None:
    """Save a graph to a JSON file."""
    data = graph_to_dict(graph)
    Path(path).write_text(json.dumps(data, indent=2, default=str))


def load_file(
    path: str | Any,
    *,
    type_registry: dict[str, type] | None = None,
) -> Graph:
    """Load a graph from a JSON file created by ``save_file()``."""
    data = json.loads(Path(path).read_text())
    return graph_from_dict(data, type_registry=type_registry)
