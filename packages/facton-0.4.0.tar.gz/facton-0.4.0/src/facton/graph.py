"""Graph — the primary interface for storing and querying knowledge."""

from __future__ import annotations

from collections import defaultdict
from typing import TYPE_CHECKING, Any

from facton.connection import Connection
from facton.constraint import Constraint, Unique
from facton.entity import Entity
from facton.query import QueryBuilder
from facton.relation import Relation

if TYPE_CHECKING:
    from facton.backends.protocol import StorageBackend
    from facton.transaction import ReadTransaction, Transaction


from facton.temporal import TemporalMixin


class Graph(TemporalMixin):
    """A knowledge graph that stores entities, connections, and relations.

    Provides CRUD operations, traversal, and query capabilities::

        g = Graph()
        g.add(alice)
        g.connect(alice, bob, Knows(since=2019))
    """

    def __init__(
        self,
        *,
        backend: StorageBackend | None = None,
        track_history: bool = True,
    ) -> None:
        self._entities: dict[str, Entity] = {}
        self._connections: list[_StoredConnection] = []
        self._outgoing: dict[str, list[_StoredConnection]] = defaultdict(list)
        self._incoming: dict[str, list[_StoredConnection]] = defaultdict(list)
        self._by_type: dict[type, set[str]] = defaultdict(set)
        self._relations: list[Relation] = []
        self._relations_by_entity: dict[str, list[Relation]] = defaultdict(list)
        self._rules: dict[str, Any] = {}
        self._decorated_rules: list[Any] = []
        self._backend: StorageBackend | None = backend
        self._track_history = track_history
        # Uniqueness index: {entity_type: {field_name: {value: entity_id}}}
        self._unique_index: dict[type, dict[str, dict[Any, str]]] = {}
        # Composite uniqueness: {entity_type: {field_tuple: {value_tuple: entity_id}}}
        self._composite_unique_index: dict[
            type, dict[tuple[str, ...], dict[tuple[Any, ...], str]]
        ] = {}
        self._entity_type_chain_cache: dict[type, tuple[type, ...]] = {}
        self._unique_fields_cache: dict[type, tuple[str, ...]] = {}
        self._composite_unique_fields_cache: dict[
            type, tuple[tuple[str, ...], ...]
        ] = {}
        self._init_temporal()

    # --- CRUD ---

    def add(self, entity: Entity) -> Entity:
        """Add an entity to the graph."""
        if entity.id in self._entities:
            msg = f"Entity with id {entity.id!r} already exists"
            raise ValueError(msg)
        self._check_entity_constraints(entity)
        self._entities[entity.id] = entity
        for cls in self._entity_type_chain(type(entity)):
            self._by_type[cls].add(entity.id)
        self._index_entity(entity)
        if self._backend is not None:
            self._backend.save(entity)
        if self._track_history:
            self._record_change(entity.id, "add", entity)
        return entity

    def add_many(
        self,
        entities: list[Entity],
        *,
        record_history: bool | None = None,
    ) -> list[Entity]:
        """Add many entities with optional temporary history override."""
        previous = self._track_history
        if record_history is not None:
            self._track_history = record_history
        try:
            entities_by_id = self._entities
            by_type = self._by_type
            backend = self._backend
            check_constraints = self._check_entity_constraints
            type_chain = self._entity_type_chain
            index_entity = self._index_entity
            added: list[Entity] = []
            pending_backend: list[Entity] = []

            try:
                for entity in entities:
                    entity_id = entity.id
                    if entity_id in entities_by_id:
                        msg = f"Entity with id {entity_id!r} already exists"
                        raise ValueError(msg)
                    check_constraints(entity)
                    entities_by_id[entity_id] = entity
                    for cls in type_chain(type(entity)):
                        by_type[cls].add(entity_id)
                    index_entity(entity)
                    added.append(entity)
                    if backend is not None:
                        pending_backend.append(entity)
            except Exception:
                if backend is not None and pending_backend:
                    if hasattr(backend, "save_many"):
                        backend.save_many(pending_backend)
                    else:
                        for entity in pending_backend:
                            backend.save(entity)
                raise

            if backend is not None and pending_backend:
                if hasattr(backend, "save_many"):
                    backend.save_many(pending_backend)
                else:
                    for entity in pending_backend:
                        backend.save(entity)

            if self._track_history:
                for entity in added:
                    self._record_change(entity.id, "add", entity)

            return added
        finally:
            self._track_history = previous

    def get[T: Entity](self, kind: type[T], id: str) -> T | None:
        """Retrieve an entity by type and id."""
        entity = self._entities.get(id)
        if entity is not None and isinstance(entity, kind):
            return entity
        return None

    def save(self, entity: Entity) -> None:
        """Persist updates to an existing entity."""
        if entity.id not in self._entities:
            msg = f"Entity with id {entity.id!r} not found"
            raise ValueError(msg)
        old = self._entities[entity.id]
        self._check_entity_constraints(entity, exclude_id=entity.id)
        self._unindex_entity(old)
        self._entities[entity.id] = entity
        self._index_entity(entity)
        if self._backend is not None:
            self._backend.save(entity)
        if self._track_history:
            self._record_change(entity.id, "save", entity)

    def remove(self, entity: Entity | str) -> None:
        """Remove an entity and its connections from the graph."""
        entity_id = entity if isinstance(entity, str) else entity.id
        if entity_id not in self._entities:
            msg = f"Entity with id {entity_id!r} not found"
            raise ValueError(msg)
        existing = self._entities.pop(entity_id)
        self._unindex_entity(existing)
        for cls in self._entity_type_chain(type(existing)):
            self._by_type.get(cls, set()).discard(entity_id)
        if self._backend is not None:
            self._backend.delete(entity_id)
        if self._track_history:
            self._record_change(entity_id, "remove", None)
        removed = [
            c
            for c in self._connections
            if c.source_id == entity_id or c.target_id == entity_id
        ]
        for c in removed:
            self._outgoing[c.source_id].remove(c)
            self._incoming[c.target_id].remove(c)
        self._connections = [
            c
            for c in self._connections
            if c.source_id != entity_id and c.target_id != entity_id
        ]

    # --- Connections ---

    def connect[S: Entity, T: Entity, C: Connection](
        self,
        source: S,
        target: T,
        connection: C,
    ) -> C:
        """Create a directed connection between two entities."""
        if source.id not in self._entities:
            msg = f"Source entity {source.id!r} not found"
            raise ValueError(msg)
        if target.id not in self._entities:
            msg = f"Target entity {target.id!r} not found"
            raise ValueError(msg)
        conn_type = type(connection)
        src_type = getattr(conn_type, "source_type", None)
        tgt_type = getattr(conn_type, "target_type", None)
        if src_type is not None and not isinstance(source, src_type):
            msg = (
                f"{conn_type.__name__} expects source type"
                f" {src_type.__name__}, got {type(source).__name__}"
            )
            raise TypeError(msg)
        if tgt_type is not None and not isinstance(target, tgt_type):
            msg = (
                f"{conn_type.__name__} expects target type"
                f" {tgt_type.__name__}, got {type(target).__name__}"
            )
            raise TypeError(msg)
        self._check_connection_constraints(source.id, target.id, connection)
        self._check_duplicate_connection(source.id, target.id, connection)
        stored = _StoredConnection(
            source_id=source.id,
            target_id=target.id,
            connection=connection,
        )
        self._connections.append(stored)
        self._outgoing[source.id].append(stored)
        self._incoming[target.id].append(stored)
        if self._backend is not None:
            self._backend.save_connection(source.id, target.id, connection)
        return connection

    def connect_many(
        self,
        edges: list[tuple[Entity, Entity, Connection[Any, Any]]],
    ) -> list[Connection[Any, Any]]:
        """Connect many entity pairs in sequence."""
        entities_by_id = self._entities
        backend = self._backend
        check_constraints = self._check_connection_constraints
        check_duplicate = self._check_duplicate_connection
        connections = self._connections
        outgoing = self._outgoing
        incoming = self._incoming

        created: list[Connection[Any, Any]] = []
        pending_backend: list[tuple[str, str, Connection[Any, Any], bool]] = []

        try:
            for source, target, connection in edges:
                source_id = source.id
                target_id = target.id

                if source_id not in entities_by_id:
                    msg = f"Source entity {source_id!r} not found"
                    raise ValueError(msg)
                if target_id not in entities_by_id:
                    msg = f"Target entity {target_id!r} not found"
                    raise ValueError(msg)

                conn_type = type(connection)
                src_type = getattr(conn_type, "source_type", None)
                tgt_type = getattr(conn_type, "target_type", None)
                if src_type is not None and not isinstance(source, src_type):
                    msg = (
                        f"{conn_type.__name__} expects source type"
                        f" {src_type.__name__}, got {type(source).__name__}"
                    )
                    raise TypeError(msg)
                if tgt_type is not None and not isinstance(target, tgt_type):
                    msg = (
                        f"{conn_type.__name__} expects target type"
                        f" {tgt_type.__name__}, got {type(target).__name__}"
                    )
                    raise TypeError(msg)

                check_constraints(source_id, target_id, connection)
                check_duplicate(source_id, target_id, connection)

                stored = _StoredConnection(
                    source_id=source_id,
                    target_id=target_id,
                    connection=connection,
                )
                connections.append(stored)
                outgoing[source_id].append(stored)
                incoming[target_id].append(stored)
                pending_backend.append((source_id, target_id, connection, False))
                created.append(connection)
        except Exception:
            if backend is not None and pending_backend:
                if hasattr(backend, "save_connections_many"):
                    backend.save_connections_many(pending_backend)
                else:
                    for source_id, target_id, connection, derived in pending_backend:
                        backend.save_connection(
                            source_id,
                            target_id,
                            connection,
                            derived=derived,
                        )
            raise

        if backend is not None and pending_backend:
            if hasattr(backend, "save_connections_many"):
                backend.save_connections_many(pending_backend)
            else:
                for source_id, target_id, connection, derived in pending_backend:
                    backend.save_connection(
                        source_id,
                        target_id,
                        connection,
                        derived=derived,
                    )
        return created

    def disconnect[S: Entity, T: Entity](
        self,
        source: S,
        target: T,
        connection_type: type[Connection[S, T]],
    ) -> None:
        """Remove connections of a given type between two entities."""
        to_remove = [
            c
            for c in self._connections
            if (
                c.source_id == source.id
                and c.target_id == target.id
                and isinstance(c.connection, connection_type)
            )
        ]
        for c in to_remove:
            self._connections.remove(c)
            self._outgoing[c.source_id].remove(c)
            self._incoming[c.target_id].remove(c)
        if self._backend is not None and to_remove:
            self._backend.delete_connection(source.id, target.id, connection_type)

    def connections_of(
        self,
        entity: Entity | str,
        connection_type: type[Connection[Any, Any]] | None = None,
    ) -> list[_StoredConnection]:
        """Return all connections involving an entity."""
        entity_id = entity if isinstance(entity, str) else entity.id
        seen: set[int] = set()
        results: list[_StoredConnection] = []
        for c in self._outgoing.get(entity_id, ()):
            if connection_type is None or isinstance(c.connection, connection_type):
                seen.add(id(c))
                results.append(c)
        for c in self._incoming.get(entity_id, ()):
            if id(c) not in seen and (
                connection_type is None or isinstance(c.connection, connection_type)
            ):
                results.append(c)
        return results

    # --- Relations ---

    def relate[R: Relation](self, relation: R) -> R:
        """Add an n-ary relation to the graph.

        All entity participants must already exist in the graph.
        """
        for role_name, entity in relation.participants.items():
            if entity.id not in self._entities:
                msg = (
                    f"Participant {role_name!r} entity {entity.id!r} not found in graph"
                )
                raise ValueError(msg)
        self._relations.append(relation)
        for eid in relation.participant_ids:
            self._relations_by_entity[eid].append(relation)
        if self._backend is not None:
            self._backend.save_relation(relation)
        return relation

    def relations_of(
        self,
        entity: Entity | str,
        relation_type: type[Relation] | None = None,
        *,
        role: str | None = None,
    ) -> list[Relation]:
        """Return relations involving an entity.

        Optionally filter by relation type and/or role name.
        """
        eid = entity if isinstance(entity, str) else entity.id
        rels = self._relations_by_entity.get(eid, [])
        if relation_type is not None:
            rels = [r for r in rels if isinstance(r, relation_type)]
        if role is not None:
            rels = [
                r
                for r in rels
                if role in r.participants and r.participants[role].id == eid
            ]
        return rels

    # --- Query ---

    def query[T: Entity](self, kind: type[T]) -> QueryBuilder[T]:
        """Start a query for entities of a given type (including subtypes).

        Returns a ``QueryBuilder`` that supports fluent chaining::

            g.query(Person).where(lambda p: p.age > 25).all()
        """
        return QueryBuilder(self, kind)

    # --- Traversal ---

    def traverse[T: Entity](
        self,
        start: T | str,
        connection_type: type[Connection[Any, Any]],
        *,
        depth: int | tuple[int, int] = 1,
    ) -> list[Entity]:
        """Traverse the graph following connections of a given type.

        ``depth`` can be a single int (exact depth) or a ``(min, max)``
        tuple for a range of hop counts.
        """
        start_id = start if isinstance(start, str) else start.id
        if isinstance(depth, int):
            min_depth, max_depth = 1, depth
        else:
            min_depth, max_depth = depth

        visited: set[str] = {start_id}
        current_frontier: set[str] = {start_id}
        results: list[Entity] = []

        for current_depth in range(1, max_depth + 1):
            next_frontier: set[str] = set()
            for entity_id in current_frontier:
                for stored in self._get_connections_from(entity_id, connection_type):
                    if stored.target_id not in visited:
                        visited.add(stored.target_id)
                        next_frontier.add(stored.target_id)
                # Also follow reverse direction
                for stored in self._get_connections_to(entity_id, connection_type):
                    if stored.source_id not in visited:
                        visited.add(stored.source_id)
                        next_frontier.add(stored.source_id)

            if current_depth >= min_depth:
                for eid in next_frontier:
                    entity = self._entities.get(eid)
                    if entity is not None:
                        results.append(entity)

            current_frontier = next_frontier
            if not current_frontier:
                break

        return results

    # --- Rules ---

    def add_rule(self, name: str, *, when: Any, then: Any) -> None:
        """Register a declarative inference rule."""
        self._rules[name] = {"when": when, "then": then}

    def run_rules(self) -> None:
        """Execute all registered rules (both decorated and declarative)."""
        for rule_fn in self._decorated_rules:
            rule_fn(self)

        for rule_spec in self._rules.values():
            matches = rule_spec["when"](self)
            produce = rule_spec["then"]
            if matches is not None:
                for match in matches:
                    result = produce(match)
                    if result is not None:
                        source, target, conn = result
                        self.derive(source, target, conn)

    def register_rule(self, fn: Any) -> None:
        """Register a decorated @rule function for execution."""
        self._decorated_rules.append(fn)

    # --- Transactions ---

    def transaction(self) -> Transaction:
        """Start a write transaction with atomic commit/rollback."""
        from facton.transaction import Transaction

        return Transaction(self)

    def read(self) -> ReadTransaction:
        """Start a read-only snapshot transaction."""
        from facton.transaction import ReadTransaction

        return ReadTransaction(self)

    # --- Serialization (delegated to facton.serialization) ---

    def to_dict(self) -> dict[str, Any]:
        """Serialize the graph to a self-describing, lossless dict."""
        from facton.serialization import graph_to_dict

        return graph_to_dict(self)

    @classmethod
    def from_dict(
        cls,
        data: dict[str, Any],
        *,
        type_registry: dict[str, type] | None = None,
        restore_history: bool = True,
    ) -> Graph:
        """Restore a graph from a dict produced by ``to_dict()``."""
        from facton.serialization import graph_from_dict

        return graph_from_dict(
            data,
            type_registry=type_registry,
            restore_history=restore_history,
        )

    def save_file(self, path: str | Any) -> None:
        """Save the graph to a JSON file."""
        from facton.serialization import save_file

        save_file(self, path)

    @classmethod
    def load_file(
        cls,
        path: str | Any,
        *,
        type_registry: dict[str, type] | None = None,
    ) -> Graph:
        """Load a graph from a JSON file created by ``save_file()``."""
        from facton.serialization import load_file

        return load_file(path, type_registry=type_registry)

    # --- Algorithms (delegated to facton.algorithms) ---

    def shortest_path(
        self,
        start: Entity | str,
        end: Entity | str,
        connection_type: type[Connection[Any, Any]],
    ) -> list[Entity] | None:
        """Find the shortest path between two entities via BFS."""
        from facton.algorithms import shortest_path

        return shortest_path(self, start, end, connection_type)

    def components(
        self,
        connection_type: type[Connection[Any, Any]] | None = None,
    ) -> list[set[str]]:
        """Find connected components (undirected)."""
        from facton.algorithms import components

        return components(self, connection_type)

    # --- Derived connections ---

    def derive[S: Entity, T: Entity](
        self,
        source: S | str,
        target: T | str,
        connection: Connection[S, T],
    ) -> Connection[S, T]:
        """Add a derived (inferred) connection to the graph.

        Derived connections are tagged so they can be distinguished from
        asserted facts.
        """
        source_id = source if isinstance(source, str) else source.id
        target_id = target if isinstance(target, str) else target.id
        self._check_duplicate_connection(source_id, target_id, connection)
        stored = _StoredConnection(
            source_id=source_id,
            target_id=target_id,
            connection=connection,
            derived=True,
        )
        self._connections.append(stored)
        self._outgoing[source_id].append(stored)
        self._incoming[target_id].append(stored)
        if self._backend is not None:
            self._backend.save_connection(
                source_id, target_id, connection, derived=True
            )
        return connection

    # --- Internal helpers ---

    def _get_entities_by_type[T: Entity](self, kind: type[T]) -> list[T]:
        """Return all entities matching a type (including subtypes)."""
        ids = self._by_type.get(kind, set())
        return [self._entities[eid] for eid in ids if eid in self._entities]  # type: ignore[misc]

    def _get_connections_from(
        self,
        entity_id: str,
        connection_type: type[Connection[Any, Any]],
    ) -> list[_StoredConnection]:
        """Return outgoing connections of a given type from an entity."""
        return [
            c
            for c in self._outgoing.get(entity_id, ())
            if isinstance(c.connection, connection_type)
        ]

    def _get_connections_to(
        self,
        entity_id: str,
        connection_type: type[Connection[Any, Any]],
    ) -> list[_StoredConnection]:
        """Return incoming connections of a given type to an entity."""
        return [
            c
            for c in self._incoming.get(entity_id, ())
            if isinstance(c.connection, connection_type)
        ]

    def _index_entity(self, entity: Entity) -> None:
        """Add an entity's unique field values to the uniqueness index."""
        entity_type = type(entity)
        for fname in self._unique_fields(entity_type):
            val = getattr(entity, fname)
            if val is None:
                continue
            idx = self._unique_index.setdefault(entity_type, {}).setdefault(fname, {})
            idx[val] = entity.id

        for fields in self._composite_unique_fields(entity_type):
            vals = tuple(getattr(entity, f) for f in fields)
            if any(v is None for v in vals):
                continue
            cidx = self._composite_unique_index.setdefault(entity_type, {}).setdefault(
                fields, {}
            )
            cidx[vals] = entity.id

    def _unindex_entity(self, entity: Entity) -> None:
        """Remove an entity's unique field values from the uniqueness index."""
        entity_type = type(entity)
        type_idx = self._unique_index.get(entity_type, {})
        for fname in self._unique_fields(entity_type):
            field_idx = type_idx.get(fname)
            if field_idx is None:
                continue
            val = getattr(entity, fname, None)
            if val is not None and field_idx.get(val) == entity.id:
                del field_idx[val]

        type_cidx = self._composite_unique_index.get(entity_type, {})
        for fields in self._composite_unique_fields(entity_type):
            comp_idx = type_cidx.get(fields)
            if comp_idx is None:
                continue
            vals = tuple(getattr(entity, f) for f in fields)
            if comp_idx.get(vals) == entity.id:
                del comp_idx[vals]

    def _check_entity_constraints(
        self,
        entity: Entity,
        *,
        exclude_id: str | None = None,
    ) -> None:
        """Validate uniqueness constraints before adding/saving an entity."""
        entity_type = type(entity)
        unique_fields = self._unique_fields(entity_type)
        composite_fields = self._composite_unique_fields(entity_type)
        if not unique_fields and not composite_fields:
            return

        for fname in unique_fields:
            new_val = getattr(entity, fname)
            if new_val is None:
                continue
            field_idx = self._unique_index.get(entity_type, {}).get(fname, {})
            owner = field_idx.get(new_val)
            if owner is not None and owner != exclude_id:
                msg = (
                    f"Unique constraint violated: {entity_type.__name__}"
                    f".{fname} = {new_val!r} already exists"
                )
                raise ValueError(msg)

        for fields in composite_fields:
            new_vals = tuple(getattr(entity, f) for f in fields)
            if any(v is None for v in new_vals):
                continue
            comp_idx = self._composite_unique_index.get(entity_type, {}).get(fields, {})
            owner = comp_idx.get(new_vals)
            if owner is not None and owner != exclude_id:
                msg = (
                    f"Unique constraint violated on"
                    f" {entity_type.__name__}"
                    f" for fields {fields}"
                )
                raise ValueError(msg)

    def _entity_type_chain(self, entity_type: type) -> tuple[type, ...]:
        """Return cached Entity-compatible MRO classes for an entity type."""
        chain = self._entity_type_chain_cache.get(entity_type)
        if chain is not None:
            return chain
        chain = tuple(
            cls
            for cls in entity_type.__mro__
            if isinstance(cls, type) and (cls is Entity or issubclass(cls, Entity))
        )
        self._entity_type_chain_cache[entity_type] = chain
        return chain

    def _unique_fields(self, entity_type: type) -> tuple[str, ...]:
        """Return cached field-level unique columns for an entity type."""
        fields = self._unique_fields_cache.get(entity_type)
        if fields is not None:
            return fields
        fields = tuple(
            fname
            for fname, finfo in entity_type.model_fields.items()
            if ((getattr(finfo, "json_schema_extra", None) or {}).get("unique"))
        )
        self._unique_fields_cache[entity_type] = fields
        return fields

    def _composite_unique_fields(
        self, entity_type: type
    ) -> tuple[tuple[str, ...], ...]:
        """Return cached composite unique field tuples for an entity type."""
        fields = self._composite_unique_fields_cache.get(entity_type)
        if fields is not None:
            return fields
        meta = getattr(entity_type, "Meta", None)
        constraints = getattr(meta, "constraints", []) if meta else []
        fields = tuple(
            constraint.fields
            for constraint in constraints
            if isinstance(constraint, Unique)
        )
        self._composite_unique_fields_cache[entity_type] = fields
        return fields

    def _check_connection_constraints(
        self,
        source_id: str,
        target_id: str,
        connection: Connection[Any, Any],
    ) -> None:
        """Validate cardinality constraints before adding a connection."""
        conn_type = type(connection)
        meta = getattr(conn_type, "Meta", None)
        constraints = getattr(meta, "constraints", []) if meta else []

        for constraint in constraints:
            if not isinstance(constraint, Constraint):
                continue
            if constraint.kind == "max_per_source":
                matching = [
                    c
                    for c in self._connections
                    if c.source_id == source_id and isinstance(c.connection, conn_type)
                ]
                if constraint.predicate:
                    matching = [
                        c for c in matching if constraint.predicate(c.connection)
                    ]
                if len(matching) >= constraint.limit:
                    msg = (
                        f"Cardinality constraint violated:"
                        f" max {constraint.limit} {conn_type.__name__}"
                        f" per source"
                    )
                    raise ValueError(msg)
            elif constraint.kind == "max_per_target":
                matching = [
                    c
                    for c in self._connections
                    if c.target_id == target_id and isinstance(c.connection, conn_type)
                ]
                if constraint.predicate:
                    matching = [
                        c for c in matching if constraint.predicate(c.connection)
                    ]
                if len(matching) >= constraint.limit:
                    msg = (
                        f"Cardinality constraint violated:"
                        f" max {constraint.limit} {conn_type.__name__}"
                        f" per target"
                    )
                    raise ValueError(msg)

    def _check_duplicate_connection(
        self,
        source_id: str,
        target_id: str,
        connection: Connection[Any, Any],
    ) -> None:
        """Reject duplicate connections when the type opts in."""
        conn_type = type(connection)
        if not getattr(conn_type, "unique_endpoints", False):
            return
        for stored in self._outgoing.get(source_id, ()):
            if stored.target_id == target_id and isinstance(
                stored.connection, conn_type
            ):
                msg = (
                    f"Duplicate {conn_type.__name__} connection"
                    f" from {source_id!r} to {target_id!r}"
                    f" already exists"
                )
                raise ValueError(msg)


class _StoredConnection:
    """Internal storage for a connection with its endpoint ids."""

    __slots__ = ("connection", "derived", "source_id", "target_id")

    def __init__(
        self,
        source_id: str,
        target_id: str,
        connection: Connection[Any, Any],
        *,
        derived: bool = False,
    ) -> None:
        self.source_id = source_id
        self.target_id = target_id
        self.connection = connection
        self.derived = derived
