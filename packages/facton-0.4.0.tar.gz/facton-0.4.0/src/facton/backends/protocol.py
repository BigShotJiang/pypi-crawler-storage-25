"""Storage backend protocol definition."""

from __future__ import annotations

from collections.abc import Iterator
from typing import Any, Protocol, runtime_checkable

from facton.connection import Connection
from facton.entity import Entity
from facton.relation import Relation


@runtime_checkable
class StorageBackend(Protocol):
    """Protocol that storage backends must implement.

    The default in-memory backend is built into ``Graph``. Custom
    backends (SQLite, Postgres, Redis, etc.) implement this protocol
    and are passed to ``Graph(backend=...)``.
    """

    # --- Entities ---

    def get[T: Entity](self, id: str, kind: type[T]) -> T | None:
        """Retrieve an entity by id and type."""
        ...

    def save(self, entity: Entity) -> None:
        """Persist an entity (insert or update)."""
        ...

    def save_many(self, entities: list[Entity]) -> None:
        """Persist many entities in one backend call."""
        ...

    def delete(self, id: str) -> None:
        """Delete an entity by id."""
        ...

    def query[T: Entity](self, kind: type[T]) -> Iterator[T]:
        """Iterate over all entities of a given type."""
        ...

    def has(self, id: str) -> bool:
        """Check whether an entity exists."""
        ...

    # --- Connections ---

    def save_connection(
        self,
        source_id: str,
        target_id: str,
        connection: Connection[Any, Any],
        *,
        derived: bool = False,
    ) -> None:
        """Persist a connection between two entities."""
        ...

    def save_connections_many(
        self,
        connections: list[tuple[str, str, Connection[Any, Any], bool]],
    ) -> None:
        """Persist many connections in one backend call.

        Each tuple is ``(source_id, target_id, connection, derived)``.
        """
        ...

    def delete_connection(
        self,
        source_id: str,
        target_id: str,
        connection_type: type[Connection[Any, Any]],
    ) -> None:
        """Delete connections of a given type between two entities."""
        ...

    def query_connections(
        self,
        entity_id: str,
        connection_type: type[Connection[Any, Any]],
        *,
        direction: str = "outgoing",
    ) -> Iterator[tuple[str, str, Connection[Any, Any]]]:
        """Iterate over connections for an entity.

        Yields ``(source_id, target_id, connection)`` tuples.
        ``direction`` is ``"outgoing"``, ``"incoming"``, or ``"both"``.
        """
        ...

    # --- Relations ---

    def save_relation(self, relation: Relation) -> None:
        """Persist an n-ary relation."""
        ...

    def delete_relation(self, relation: Relation) -> None:
        """Delete an n-ary relation."""
        ...

    def query_relations(
        self,
        relation_type: type[Relation],
    ) -> Iterator[Relation]:
        """Iterate over all relations of a given type."""
        ...
