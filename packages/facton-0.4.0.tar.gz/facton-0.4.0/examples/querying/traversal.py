"""Traversal — follow connections through the graph.

Run: uv run python examples/querying/traversal.py
"""

from facton import Connection, Entity, Graph


class Person(Entity):
    name: str


class Knows(Connection[Person, Person]):
    pass


g = Graph()
alice = Person(id="alice", name="Alice")
bob = Person(id="bob", name="Bob")
carol = Person(id="carol", name="Carol")
dave = Person(id="dave", name="Dave")

for p in (alice, bob, carol, dave):
    g.add(p)

g.connect(alice, bob, Knows())
g.connect(bob, carol, Knows())
g.connect(carol, dave, Knows())

# Direct connections (depth 1)
print(f"Alice's friends: {[e.name for e in g.traverse(alice, Knows, depth=1)]}")

# Up to 2 hops
print(f"Within 2 hops: {[e.name for e in g.traverse(alice, Knows, depth=2)]}")

# Exactly 2 hops (friends-of-friends only)
fof = g.traverse(alice, Knows, depth=(2, 2))
print(f"Friends-of-friends: {[e.name for e in fof]}")

# Full range
everyone = g.traverse(alice, Knows, depth=(1, 3))
print(f"All reachable: {[e.name for e in everyone]}")
