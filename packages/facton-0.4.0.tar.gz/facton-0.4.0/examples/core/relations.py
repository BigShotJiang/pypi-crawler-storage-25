"""Relation — n-ary relationships with auto-detected entity participants.

Unlike Connection (binary, directed), a Relation connects any number of
typed entities.  Entity-typed fields are auto-detected as participants;
other fields are plain relation data.

Run: uv run python examples/core/relations.py
"""

from facton import Entity, Graph, Relation

# --- Entities ---


class Person(Entity):
    name: str


class Project(Entity):
    name: str
    budget: float = 0.0


class Department(Entity):
    name: str


# --- Relations ---


class Assignment(Relation):
    """A person is assigned to a project with a given allocation."""

    person: Person
    project: Project
    allocation: float  # percentage


class Supervision(Relation):
    """A manager supervises an employee within a department."""

    manager: Person
    employee: Person
    department: Department


# --- Build the graph ---

g = Graph()

alice = Person(id="alice", name="Alice")
bob = Person(id="bob", name="Bob")
carol = Person(id="carol", name="Carol")
atlas = Project(id="atlas", name="Atlas", budget=500_000)
beacon = Project(id="beacon", name="Beacon", budget=200_000)
engineering = Department(id="eng", name="Engineering")

for entity in [alice, bob, carol, atlas, beacon, engineering]:
    g.add(entity)

# Assignments — pass entities directly, no wrapper needed
a1 = g.relate(Assignment(person=alice, project=atlas, allocation=0.8))
a2 = g.relate(Assignment(person=alice, project=beacon, allocation=0.2))
a3 = g.relate(Assignment(person=bob, project=atlas, allocation=1.0))

# Supervision — n-ary: manager, employee, and department
s1 = g.relate(Supervision(manager=carol, employee=alice, department=engineering))
s2 = g.relate(Supervision(manager=carol, employee=bob, department=engineering))

# --- Direct access — no .entity indirection ---

print("=== Assignments ===")
for rel in g._relations:
    if isinstance(rel, Assignment):
        print(f"  {rel.person.name} → {rel.project.name} ({rel.allocation:.0%})")

print("\n=== Supervision ===")
for rel in g._relations:
    if isinstance(rel, Supervision):
        print(
            f"  {rel.manager.name} supervises {rel.employee.name}"
            f" in {rel.department.name}"
        )

# --- Query relations by entity ---

print("\n=== Alice's relations ===")
for rel in g.relations_of(alice):
    print(f"  {type(rel).__name__}: {rel.participants}")

print("\n=== Alice's assignments only ===")
for rel in g.relations_of(alice, Assignment):
    print(f"  {rel.project.name} ({rel.allocation:.0%})")

print("\n=== Relations where Alice is 'person' ===")
for rel in g.relations_of(alice, role="person"):
    print(f"  {type(rel).__name__}: {rel.participants}")

# --- Relation-level annotations ---
a1.annotate(approved_by="carol", priority="high")
print("\n=== Relation annotations ===")
print(f"  Assignment(alice→atlas): {a1.relation_annotations}")
