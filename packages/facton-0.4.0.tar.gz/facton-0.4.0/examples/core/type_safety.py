"""Type safety — connection endpoint type checking.

Run: uv run python examples/core/type_safety.py
"""

from datetime import date

from facton import Connection, Entity, Field, Graph


class Person(Entity):
    name: str
    age: int = Field(ge=0)


class Organization(Entity):
    name: str


class Pet(Entity):
    name: str
    species: str


class WorksAt(Connection[Person, Organization]):
    role: str
    started: date


class Owns(Connection[Person, Pet]):
    since: int


g = Graph()
alice = Person(id="alice", name="Alice", age=30)
acme = Organization(id="acme", name="Acme Corp")
rex = Pet(id="rex", name="Rex", species="dog")
g.add(alice)
g.add(acme)
g.add(rex)

# Correct types — works fine
g.connect(alice, acme, WorksAt(role="Engineer", started=date(2022, 1, 1)))
print("alice → acme via WorksAt: OK")

g.connect(alice, rex, Owns(since=2020))
print("alice → rex  via Owns:    OK")

# Wrong source type: Organization → Organization via WorksAt
try:
    g.connect(acme, acme, WorksAt(role="X", started=date(2024, 1, 1)))
except TypeError as e:
    print("\nacme → acme via WorksAt: REJECTED")
    print(f"  {e}")

# Wrong target type: Person → Person via WorksAt
try:
    bob = Person(id="bob", name="Bob", age=28)
    g.add(bob)
    g.connect(alice, bob, WorksAt(role="Eng", started=date(2024, 1, 1)))
except TypeError as e:
    print("\nalice → bob  via WorksAt: REJECTED")
    print(f"  {e}")


# Subtypes are accepted
class Employee(Person):
    badge: str = ""


emp = Employee(id="emp1", name="Eve", age=26, badge="E001")
g.add(emp)
g.connect(emp, acme, WorksAt(role="Intern", started=date(2025, 6, 1)))
print("\nemp1 (Employee subtype) → acme via WorksAt: OK")
