"""Fact[T] — every property carries annotation metadata.

Run: uv run python examples/core/annotations.py
"""

from datetime import date

from facton import Connection, Entity, Fact, Field, Graph


class Person(Entity):
    name: str
    age: int = Field(ge=0)


class Knows(Connection[Person, Person]):
    since: int | None = None


g = Graph()
alice = Person(id="alice", name="Alice", age=30)
bob = Person(id="bob", name="Bob", age=28)
g.add(alice)
g.add(bob)

# Property-level annotations — alice.name is a Fact[str], so str methods
# AND .annotate() both work on the same object.
alice.name.annotate(source="hr_system", confidence=0.95)
alice.age.annotate(recorded=date(2024, 1, 15))

print(f"alice.name = {alice.name!r}")
print(f"alice.name.upper() = {alice.name.upper()!r}")
print(f"annotations = {alice.name.annotations}")

# Entity-level annotations
alice.annotate(imported_from="batch_42")
print(f"entity annotations = {alice.entity_annotations}")

# Connection property annotations
edge = g.connect(alice, bob, Knows(since=Fact(2019, source="user_input")))
print(f"edge.since = {edge.since}, annotations = {edge.since.annotations}")
