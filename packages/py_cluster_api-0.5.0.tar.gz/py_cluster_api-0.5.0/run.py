"""Submit a sleep job to the cluster and wait for it to finish."""

import asyncio
import logging

from cluster_api import JobMonitor, JobStatus, ResourceSpec, create_executor

logging.basicConfig(level=logging.DEBUG, format="%(asctime)s %(name)s %(message)s")


async def main():
    executor = create_executor(executor="lsf")
    monitor = JobMonitor(executor, poll_interval=5.0)
    await monitor.start()

    job = await executor.submit(
        "sleep 30", name="test-sleep",
        resources=ResourceSpec(extra_args=["-P", "scicompsoft"]),
    )
    print(f"Submitted job {job.job_id} ({job.name})")

    await monitor.wait_for(job)
    print(f"Job {job.job_id} finished with status: {job.status.value}")

    await monitor.stop()


if __name__ == "__main__":
    asyncio.run(main())
