# bf16
BF16 is a Python package for converting floating-point numbers to BFloat16 format using optimized Windows x86-64 assembly.

## Installation
```bash
pip install bf16
```
## Usage
```python
import bf16

x = bf16.bfloat16(3.14)
print(x)  # Outputs the BFloat16 approximation as a float and for the record it also actually output 3.12 because its a real breainfloat16
print(f"Size: {len(x.data)} bytes")  # Always 2 bytes
```

## Requirements
- Windows AMD x86-64
- Python 3.6+
The package includes a compiled assembly executable for fast conversion.