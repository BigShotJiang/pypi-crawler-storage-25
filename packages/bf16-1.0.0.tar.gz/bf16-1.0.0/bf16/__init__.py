import subprocess as sp,struct as st,os
def _raw(v):return sp.run([os.path.join(os.path.dirname(__file__), "bf16.exe"),str(v)],capture_output=1).stdout
class bfloat16:
 __slots__=['data']
 def __init__(self,v):self.data=_raw(v)
 def __repr__(self):
  if len(self.data)<2:return "0.00"
  return "%.2f"%st.unpack('<f',b'\x00\x00'+self.data)
 def __str__(self):return self.__repr__()