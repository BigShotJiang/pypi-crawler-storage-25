"""Data types for contract discovery results."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class ContractEntry:
    """A single contract file discovered in a repo."""

    path: str
    role: str  # "source" | "consumer" | "unknown"
    file_type: str  # "json-schema" | "openapi" | "protobuf" | "graphql" | "typescript" | "other"
    domain: str  # Logical name, e.g. "task-spec", "user-api"
    confidence: float  # 0.0 - 1.0
    reasoning: str = ""
    # Multi-model consensus fields (populated when using multiple models).
    agreement_count: int = 0  # How many models found this entry
    agreed_models: list[str] = field(default_factory=list)  # Model names that agreed


@dataclass(slots=True)
class RepoCatalog:
    """Discovery results for a single repo."""

    repo_id: str
    repo_url: str
    branch: str
    snapshot_path: str
    contracts: list[ContractEntry] = field(default_factory=list)


@dataclass(slots=True)
class ContractPair:
    """A matched source/consumer pair across repos."""

    domain: str
    source_repo: str
    source_path: str  # Relative to workspace root (includes snapshot_path prefix)
    consumer_repo: str
    consumer_path: str  # Relative to workspace root
    # Multi-model consensus fields (populated when using multiple models).
    agreement_count: int = 0  # How many models proposed this pair
    agreed_models: list[str] = field(default_factory=list)  # Model names that agreed


@dataclass(slots=True)
class DiscoverResult:
    """Full output of the discover workflow."""

    catalogs: list[RepoCatalog]
    pairs: list[ContractPair]
    config: dict[str, Any]  # The generated repo-drift config JSON
    token_usage: dict[str, int] = field(default_factory=dict)
