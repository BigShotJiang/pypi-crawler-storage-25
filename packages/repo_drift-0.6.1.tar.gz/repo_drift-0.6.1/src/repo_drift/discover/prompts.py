"""Prompt templates for the agent-powered discovery workflow.

Phase 2: Per-repo contract classification.
Phase 3: Cross-repo relationship inference + config generation.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Phase 2 — Classify candidate files within a single repo
# ---------------------------------------------------------------------------

DISCOVER_SYSTEM = """\
You are an expert at identifying cross-repository contract files in software projects.

Your job is to analyze candidate files from a repository and classify each one:

1. **Role**: Is this file a SOURCE (the authoritative definition), a CONSUMER (a generated/copied \
downstream version), or UNKNOWN?
   - SOURCE indicators: lives in `specs/`, `schemas/`, `contracts/`, `proto/` directories; \
has `$schema`, `$id` or `openapi` fields; has no "generated" markers.
   - CONSUMER indicators: lives in `generated/`, `dist/`, `lib/contracts/`; has code-gen markers \
in comments; mirrors a file from another directory structure.

2. **File type**: json-schema, openapi, protobuf, graphql, typescript, avro, xml-schema, other.

3. **Domain**: A short logical name for what this contract represents (e.g. "task-spec", \
"user-api", "event-schema", "pod-config"). Files that represent the same contract across repos \
should get the same domain name.

4. **Confidence**: 0.0 to 1.0 — how confident are you this is a real contract file?

IMPORTANT: Only classify files that are actual API contracts, schemas, or shared type definitions \
that other repositories might depend on. Ignore configuration files, test fixtures, lock files, \
and internal-only types.

Always respond with valid JSON matching the schema below. No extra text outside the JSON."""

DISCOVER_USER = """\
Repository: {repo_id} ({repo_url})
Branch: {branch}

File tree of candidate locations:
```
{file_tree}
```

File contents (first {max_lines} lines each):

{file_contents}

Classify each candidate file. Respond with:
```json
{{
  "contracts": [
    {{
      "path": "relative/path/to/file.json",
      "role": "source",
      "file_type": "json-schema",
      "domain": "task-spec",
      "confidence": 0.95,
      "reasoning": "Brief explanation"
    }}
  ]
}}
```

If no files qualify as contracts, return {{"contracts": []}}."""


# ---------------------------------------------------------------------------
# Phase 3 — Match contracts across repos and generate config
# ---------------------------------------------------------------------------

GENERATE_SYSTEM = """\
You are an expert at generating repo-drift configuration files.

Given discovery catalogs from multiple repositories, your job is to:

1. **Match contracts** across repos by domain name and file type.
2. **Determine source/consumer pairs**: For each domain, identify which repo has the SOURCE and \
which has the CONSUMER(s).
3. **Generate checks**: For each source/consumer pair:
   - A `file_pair_hash` check at `high` severity (detects any byte-level drift).
   - A `json_schema_compat` check at `medium` severity (detects breaking schema changes) — \
only for json-schema and openapi types.
4. **Set a default policy**: fail on `high` + `fail` and `critical` + `fail`.

If a domain has multiple consumers, generate separate check pairs for each consumer.
If a domain has no clear source (all roles are "unknown"), generate hash checks between all \
pairs but at `medium` severity.
Skip entries with confidence below 0.5.

IMPORTANT: Each repo's catalog includes a `snapshot_path` field. Use this as the prefix for \
file paths in check params instead of hardcoding `repos/<repo_id>`. For remote repos, \
`snapshot_path` will be `repos/<repo_id>`. For local repos, it will be an absolute path like \
`/Users/dev/my-service`. Always use `<snapshot_path>/<file_path>` for check param paths.

The generated config must conform to this schema:
```json
{{
  "version": 1,
  "repos": [
    {{
      "id": "<repo_id>",
      "url": "<repo_url>",
      "ref_policy": "develop_or_main",
      "snapshot_path": "<snapshot_path from catalog>"
    }}
  ],
  "checks": [
    {{
      "id": "<domain>-hash-sync",
      "type": "file_pair_hash",
      "severity": "high",
      "params": {{
        "left": "<source_snapshot_path>/<source_path>",
        "right": "<consumer_snapshot_path>/<consumer_path>"
      }}
    }}
  ],
  "policy": {{
    "fail_on": [
      {{ "severity": "critical", "status": "fail" }},
      {{ "severity": "high", "status": "fail" }}
    ]
  }}
}}
```

Always respond with valid JSON. No extra text outside the JSON."""

GENERATE_USER = """\
Discovery catalogs from {repo_count} repositories:

{catalogs_json}

Generate the complete repo-drift configuration.

Respond with:
```json
{{
  "config": {{ ... }},
  "pairs": [
    {{
      "domain": "task-spec",
      "source_repo": "repo-a",
      "source_path": "specs/task-spec.json",
      "consumer_repo": "repo-b",
      "consumer_path": "generated/task-spec.json"
    }}
  ],
  "notes": ["Any warnings or observations about ambiguous matches"]
}}
```"""


def format_discover_prompt(
    repo_id: str,
    repo_url: str,
    branch: str,
    file_tree: str,
    file_contents: str,
    max_lines: int = 500,
) -> tuple[str, str]:
    """Format the Phase 2 discovery prompt for a single repo.

    Returns:
        (system_prompt, user_prompt) tuple.
    """
    user = DISCOVER_USER.format(
        repo_id=repo_id,
        repo_url=repo_url,
        branch=branch,
        file_tree=file_tree,
        file_contents=file_contents,
        max_lines=max_lines,
    )
    return DISCOVER_SYSTEM, user


def format_generate_prompt(
    catalogs_json: str,
    repo_count: int,
) -> tuple[str, str]:
    """Format the Phase 3 config generation prompt.

    Returns:
        (system_prompt, user_prompt) tuple.
    """
    user = GENERATE_USER.format(
        repo_count=repo_count,
        catalogs_json=catalogs_json,
    )
    return GENERATE_SYSTEM, user
