"""Local file-tree scanning and candidate filtering for contract discovery."""

from __future__ import annotations

import fnmatch
import logging
from pathlib import Path

_logger = logging.getLogger(__name__)

# Directories likely to contain contract/spec files.
_CANDIDATE_DIRS = (
    "specs",
    "schemas",
    "contracts",
    "proto",
    "protobuf",
    "openapi",
    "generated",
    "shared",
    "api",
    "types",
    "interfaces",
)

# File extensions worth inspecting.
_CANDIDATE_EXTENSIONS = {
    ".json",
    ".yaml",
    ".yml",
    ".proto",
    ".graphql",
    ".gql",
    ".ts",
    ".d.ts",
    ".avsc",  # Avro schema
    ".xsd",  # XML schema
}

# Glob patterns for always-interesting files regardless of location.
_ALWAYS_INCLUDE = (
    "**/*.schema.json",
    "**/*.schema.yaml",
    "**/*.schema.yml",
    "**/*.openapi.json",
    "**/*.openapi.yaml",
    "**/openapi.json",
    "**/openapi.yaml",
    "**/swagger.json",
    "**/swagger.yaml",
)

# Directories to always ignore.
_IGNORE_DIRS = {
    ".git",
    "node_modules",
    "__pycache__",
    ".venv",
    "venv",
    ".tox",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    "vendor",
    "dist",
    "build",
    ".next",
    ".nuxt",
    "target",  # Rust/Java
    "coverage",
    ".coverage",
    "htmlcov",
    ".DS_Store",
}

# Max file size to read (bytes). Larger files are unlikely to be contracts.
_MAX_FILE_SIZE = 256 * 1024  # 256 KB

# Max lines to read per candidate file.
_MAX_LINES = 500


def _is_candidate_dir(rel_parts: tuple[str, ...]) -> bool:
    """Check if any component of the relative path is a known contract directory."""
    return any(part.lower() in _CANDIDATE_DIRS for part in rel_parts)


def _is_candidate_ext(path: Path) -> bool:
    suffixes = path.suffixes
    # Handle compound extensions like .schema.json
    compound = "".join(suffixes).lower()
    if compound in (
        ".schema.json",
        ".schema.yaml",
        ".schema.yml",
        ".openapi.json",
        ".openapi.yaml",
    ):
        return True
    return path.suffix.lower() in _CANDIDATE_EXTENSIONS


def _matches_always_include(rel_posix: str) -> bool:
    return any(fnmatch.fnmatch(rel_posix, pat) for pat in _ALWAYS_INCLUDE)


def scan_repo_for_candidates(repo_dir: Path) -> list[Path]:
    """Walk a repo directory and return paths to likely contract files.

    Args:
        repo_dir: Root of the cloned repository.

    Returns:
        Sorted list of absolute paths to candidate contract files.
    """
    repo_dir = repo_dir.resolve()
    candidates: list[Path] = []

    if not repo_dir.is_dir():
        _logger.warning("scan_repo_for_candidates: not a directory: %s", repo_dir)
        return candidates

    for item in repo_dir.rglob("*"):
        if not item.is_file():
            continue

        # Check ignore dirs.
        rel = item.relative_to(repo_dir)
        rel_parts = rel.parts
        if any(part in _IGNORE_DIRS for part in rel_parts):
            continue

        # Size guard.
        try:
            if item.stat().st_size > _MAX_FILE_SIZE:
                continue
        except OSError:
            continue

        rel_posix = rel.as_posix()

        # Include if: in a candidate dir, has a candidate extension, or matches always-include glob.
        if (
            _is_candidate_dir(rel_parts)
            or _is_candidate_ext(item)
            or _matches_always_include(rel_posix)
        ):
            candidates.append(item)

    candidates.sort(key=lambda p: p.relative_to(repo_dir).as_posix())
    _logger.info("Scanned %s: found %d candidate files", repo_dir, len(candidates))
    return candidates


def read_candidate_preview(path: Path, max_lines: int = _MAX_LINES) -> str:
    """Read the first N lines of a candidate file.

    Args:
        path: Absolute path to the file.
        max_lines: Maximum lines to read.

    Returns:
        File content string (truncated to max_lines).
    """
    try:
        lines = []
        with path.open("r", errors="replace") as fh:
            for i, line in enumerate(fh):
                if i >= max_lines:
                    lines.append(f"\n... [truncated at {max_lines} lines]")
                    break
                lines.append(line)
        return "".join(lines)
    except Exception as exc:
        _logger.warning("Could not read %s: %s", path, exc)
        return ""


def build_file_tree(repo_dir: Path, candidates: list[Path]) -> str:
    """Build a compact file-tree string showing candidate file locations.

    Includes parent directories for context but only marks candidate files.

    Args:
        repo_dir: Root of the cloned repository.
        candidates: List of candidate file paths.

    Returns:
        Tree string suitable for including in an LLM prompt.
    """
    repo_dir = repo_dir.resolve()
    dirs_seen: set[str] = set()
    lines: list[str] = []

    for cand in candidates:
        rel = cand.relative_to(repo_dir)
        parts = rel.parts

        # Add directory lines we haven't seen.
        for depth in range(len(parts) - 1):
            dir_key = "/".join(parts[: depth + 1])
            if dir_key not in dirs_seen:
                dirs_seen.add(dir_key)
                indent = "  " * depth
                lines.append(f"{indent}{parts[depth]}/")

        # Add the file.
        indent = "  " * (len(parts) - 1)
        lines.append(f"{indent}{parts[-1]}")

    return "\n".join(lines)
