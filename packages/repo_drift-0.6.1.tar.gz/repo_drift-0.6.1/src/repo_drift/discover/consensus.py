"""Multi-model consensus: merge and rank discovery results from multiple LLM runs.

When multiple models independently classify the same repository, this module
merges their results and ranks entries/pairs by how many models agree.

Matching strategy:
- ContractEntry: keyed by (repo_id, path) — same file in the same repo.
- ContractPair: keyed by (source_repo, source_path, consumer_repo, consumer_path).

For entries that match, we:
- Average confidence scores across agreeing models.
- Take the majority-vote role and file_type.
- Union the domain names (pick the most common one).
- Record agreement_count and agreed_models.
"""

from __future__ import annotations

import logging
from collections import Counter
from typing import Any

from .catalog import ContractEntry, ContractPair, RepoCatalog

_logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Entry merging (Phase 2 consensus)
# ---------------------------------------------------------------------------


def _entry_key(entry: ContractEntry) -> str:
    """Canonical key for deduplicating entries within a repo."""
    return entry.path


def _majority(values: list[str]) -> str:
    """Return the most common value from a list."""
    if not values:
        return ""
    counter = Counter(values)
    return counter.most_common(1)[0][0]


def merge_catalogs(
    catalogs_per_model: dict[str, RepoCatalog],
) -> RepoCatalog:
    """Merge discovery catalogs from multiple models for a single repo.

    Args:
        catalogs_per_model: Mapping of model_name -> RepoCatalog for the same repo.

    Returns:
        A single merged RepoCatalog with agreement scoring.
    """
    if not catalogs_per_model:
        msg = "merge_catalogs called with empty input"
        raise ValueError(msg)

    # Use the first catalog's metadata (repo_id, url, branch, snapshot_path).
    first = next(iter(catalogs_per_model.values()))
    total_models = len(catalogs_per_model)

    # Group entries by path across all models.
    entries_by_key: dict[str, list[tuple[str, ContractEntry]]] = {}
    for model_name, catalog in catalogs_per_model.items():
        for entry in catalog.contracts:
            key = _entry_key(entry)
            entries_by_key.setdefault(key, []).append((model_name, entry))

    merged_entries: list[ContractEntry] = []
    for _key, model_entries in entries_by_key.items():
        models = [m for m, _ in model_entries]
        entries = [e for _, e in model_entries]
        agreement = len(models)

        # Average confidence.
        avg_confidence = sum(e.confidence for e in entries) / len(entries)

        # Majority-vote on categorical fields.
        role = _majority([e.role for e in entries])
        file_type = _majority([e.file_type for e in entries])
        domain = _majority([e.domain for e in entries])

        # Collect reasoning from all models.
        reasons = [f"[{m}] {e.reasoning}" for m, e in model_entries if e.reasoning]
        combined_reasoning = " | ".join(reasons) if reasons else ""

        merged_entries.append(
            ContractEntry(
                path=entries[0].path,
                role=role,
                file_type=file_type,
                domain=domain,
                confidence=round(avg_confidence, 3),
                reasoning=combined_reasoning,
                agreement_count=agreement,
                agreed_models=sorted(models),
            )
        )

    # Sort by agreement_count desc, then confidence desc.
    merged_entries.sort(key=lambda e: (-e.agreement_count, -e.confidence))

    _logger.info(
        "Consensus for %s: %d entries from %d models (max agreement: %d/%d)",
        first.repo_id,
        len(merged_entries),
        total_models,
        max((e.agreement_count for e in merged_entries), default=0),
        total_models,
    )

    return RepoCatalog(
        repo_id=first.repo_id,
        repo_url=first.repo_url,
        branch=first.branch,
        snapshot_path=first.snapshot_path,
        contracts=merged_entries,
    )


# ---------------------------------------------------------------------------
# Pair merging (Phase 3 consensus)
# ---------------------------------------------------------------------------


def _pair_key(pair: ContractPair) -> tuple[str, str, str, str]:
    """Canonical key for deduplicating pairs."""
    return (pair.source_repo, pair.source_path, pair.consumer_repo, pair.consumer_path)


def merge_pairs(
    pairs_per_model: dict[str, list[ContractPair]],
) -> list[ContractPair]:
    """Merge contract pairs from multiple models.

    Args:
        pairs_per_model: Mapping of model_name -> list of ContractPair.

    Returns:
        Merged and ranked list of ContractPair with agreement scoring.
    """
    if not pairs_per_model:
        return []

    # Group pairs by their canonical key.
    grouped: dict[tuple[str, str, str, str], list[tuple[str, ContractPair]]] = {}
    for model_name, pairs in pairs_per_model.items():
        for pair in pairs:
            key = _pair_key(pair)
            grouped.setdefault(key, []).append((model_name, pair))

    merged: list[ContractPair] = []
    for _key, model_pairs in grouped.items():
        models = [m for m, _ in model_pairs]
        pairs = [p for _, p in model_pairs]
        agreement = len(models)

        # Take majority-vote on domain (usually the same).
        domain = _majority([p.domain for p in pairs])

        merged.append(
            ContractPair(
                domain=domain,
                source_repo=pairs[0].source_repo,
                source_path=pairs[0].source_path,
                consumer_repo=pairs[0].consumer_repo,
                consumer_path=pairs[0].consumer_path,
                agreement_count=agreement,
                agreed_models=sorted(models),
            )
        )

    # Sort by agreement desc, then domain.
    merged.sort(key=lambda p: (-p.agreement_count, p.domain))

    _logger.info(
        "Pair consensus: %d unique pairs from %d models (max agreement: %d/%d)",
        len(merged),
        len(pairs_per_model),
        max((p.agreement_count for p in merged), default=0),
        len(pairs_per_model),
    )

    return merged


# ---------------------------------------------------------------------------
# Config merging (Phase 3 consensus — config objects)
# ---------------------------------------------------------------------------


def merge_configs(
    configs_per_model: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    """Merge generated configs from multiple models.

    Strategy: take the config with the most checks (richest output), since
    the check list is the most variable part. Repos and policy are identical
    across models (deterministic from input).

    Args:
        configs_per_model: Mapping of model_name -> config dict.

    Returns:
        The merged config dict.
    """
    if not configs_per_model:
        return {}

    # Pick the config with the most checks.
    best_model = max(
        configs_per_model,
        key=lambda m: len(configs_per_model[m].get("checks", [])),
    )

    _logger.info(
        "Config consensus: using config from %s (%d checks)",
        best_model,
        len(configs_per_model[best_model].get("checks", [])),
    )

    return configs_per_model[best_model]
