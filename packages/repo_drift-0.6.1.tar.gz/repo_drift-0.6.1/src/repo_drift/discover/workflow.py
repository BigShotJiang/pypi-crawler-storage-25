"""Three-phase discover workflow: snapshot -> classify -> generate config.

Supports multi-model consensus: when multiple LLM clients are provided,
each phase runs independently against every model and results are merged
using agreement-based ranking.
"""

from __future__ import annotations

import json
import logging
from collections.abc import Sequence
from pathlib import Path
from typing import Any

from repo_drift.core.snapshot import SnapshotResult, ensure_snapshot
from repo_drift.core.types import RepoConfig
from repo_drift.llm.client import LLMClient

from .catalog import ContractEntry, ContractPair, DiscoverResult, RepoCatalog
from .consensus import merge_catalogs, merge_configs, merge_pairs
from .prompts import format_discover_prompt, format_generate_prompt
from .scan import build_file_tree, read_candidate_preview, scan_repo_for_candidates

_logger = logging.getLogger(__name__)

# Max candidate files to include in a single LLM call.
_MAX_CANDIDATES_PER_CALL = 40

# Min confidence to keep an entry through to Phase 3.
_MIN_CONFIDENCE = 0.3


def _is_local_path(url_or_path: str) -> bool:
    """Check if a string is a local filesystem path rather than a URL."""
    return (
        url_or_path.startswith("/") or url_or_path.startswith("./") or url_or_path.startswith("~")
    )


def _repo_id_from_url(url: str) -> str:
    """Derive a short repo id from a GitHub URL or local path.

    >>> _repo_id_from_url("https://github.com/acme/my-service.git")
    'my-service'
    >>> _repo_id_from_url("/Users/dev/my-service")
    'my-service'
    """
    name = url.rstrip("/").rsplit("/", 1)[-1]
    if name.endswith(".git"):
        name = name[: -len(".git")]
    return name


def _build_repo_configs(
    repo_urls: list[str],
    ref_policy: str = "develop_or_main",
) -> list[RepoConfig]:
    """Turn a list of repo URLs into RepoConfig objects with auto-derived ids.

    For local paths, ``snapshot_path`` is set to the resolved absolute path
    so that ``--no-snapshot`` can use it directly without cloning.
    """
    configs: list[RepoConfig] = []
    seen_ids: dict[str, int] = {}

    for url in repo_urls:
        base_id = _repo_id_from_url(url)
        count = seen_ids.get(base_id, 0)
        seen_ids[base_id] = count + 1
        repo_id = base_id if count == 0 else f"{base_id}-{count + 1}"

        if _is_local_path(url):
            # Local directory: snapshot_path is the resolved absolute path.
            snapshot_path = str(Path(url).expanduser().resolve())
        else:
            snapshot_path = f"repos/{repo_id}"

        configs.append(
            RepoConfig(
                id=repo_id,
                url=url,
                ref_policy=ref_policy,
                snapshot_path=snapshot_path,
            )
        )
    return configs


# ── Phase 1: Snapshot ─────────────────────────────────────────────────────


def _phase_snapshot(
    repos: list[RepoConfig],
    workspace: Path,
) -> list[SnapshotResult]:
    """Clone/fetch all repos and return snapshot results."""
    _logger.info("Phase 1: snapshotting %d repos", len(repos))
    results: list[SnapshotResult] = []
    for repo in repos:
        _logger.info("  Snapshotting %s ...", repo.id)
        result = ensure_snapshot(repo, workspace)
        _logger.info("  -> %s @ %s (%s)", result.branch, result.commit, result.path)
        results.append(result)
    return results


# ── Phase 2: Discover (per-repo LLM classification) ──────────────────────


def _phase_discover_repo(
    client: LLMClient,
    repo: RepoConfig,
    snapshot: SnapshotResult,
    workspace: Path,
) -> RepoCatalog:
    """Scan a single repo and classify its contract files via LLM."""
    snap_path = Path(repo.snapshot_path)
    repo_dir = (
        snap_path.resolve()
        if snap_path.is_absolute()
        else (workspace / repo.snapshot_path).resolve()
    )
    candidates = scan_repo_for_candidates(repo_dir)

    if not candidates:
        _logger.info("  %s: no candidate files found", repo.id)
        return RepoCatalog(
            repo_id=repo.id,
            repo_url=repo.url,
            branch=snapshot.branch,
            snapshot_path=repo.snapshot_path,
        )

    # Limit candidates to avoid token blowup.
    if len(candidates) > _MAX_CANDIDATES_PER_CALL:
        _logger.warning(
            "  %s: %d candidates found, truncating to %d",
            repo.id,
            len(candidates),
            _MAX_CANDIDATES_PER_CALL,
        )
        candidates = candidates[:_MAX_CANDIDATES_PER_CALL]

    # Build prompt inputs.
    file_tree = build_file_tree(repo_dir, candidates)

    content_parts: list[str] = []
    for cand in candidates:
        rel = cand.relative_to(repo_dir).as_posix()
        preview = read_candidate_preview(cand)
        if preview:
            content_parts.append(f"### {rel}\n```\n{preview}\n```")

    file_contents = "\n\n".join(content_parts)

    system, user = format_discover_prompt(
        repo_id=repo.id,
        repo_url=repo.url,
        branch=snapshot.branch,
        file_tree=file_tree,
        file_contents=file_contents,
    )

    _logger.info("  %s: classifying %d candidates via LLM ...", repo.id, len(candidates))
    response = client.complete(system, user)

    # Parse response.
    try:
        data = response.json()
    except (ValueError, KeyError) as exc:
        _logger.error("  %s: failed to parse LLM response: %s", repo.id, exc)
        _logger.debug("  Raw response: %s", response.content[:500])
        return RepoCatalog(
            repo_id=repo.id,
            repo_url=repo.url,
            branch=snapshot.branch,
            snapshot_path=repo.snapshot_path,
        )

    entries: list[ContractEntry] = []
    for item in data.get("contracts", []):
        confidence = float(item.get("confidence", 0))
        if confidence < _MIN_CONFIDENCE:
            continue
        entries.append(
            ContractEntry(
                path=item.get("path", ""),
                role=item.get("role", "unknown"),
                file_type=item.get("file_type", "other"),
                domain=item.get("domain", ""),
                confidence=confidence,
                reasoning=item.get("reasoning", ""),
            )
        )

    _logger.info("  %s: discovered %d contract entries", repo.id, len(entries))
    return RepoCatalog(
        repo_id=repo.id,
        repo_url=repo.url,
        branch=snapshot.branch,
        snapshot_path=repo.snapshot_path,
        contracts=entries,
    )


def _phase_discover(
    client: LLMClient,
    repos: list[RepoConfig],
    snapshots: list[SnapshotResult],
    workspace: Path,
) -> list[RepoCatalog]:
    """Run discovery across all repos with a single model."""
    _logger.info("Phase 2: discovering contracts in %d repos", len(repos))
    catalogs: list[RepoCatalog] = []
    for repo, snapshot in zip(repos, snapshots, strict=True):
        catalog = _phase_discover_repo(client, repo, snapshot, workspace)
        catalogs.append(catalog)
    return catalogs


def _phase_discover_consensus(
    clients: Sequence[LLMClient],
    repos: list[RepoConfig],
    snapshots: list[SnapshotResult],
    workspace: Path,
) -> list[RepoCatalog]:
    """Run discovery across all repos with multiple models, then merge via consensus."""
    _logger.info(
        "Phase 2 (consensus): discovering contracts in %d repos with %d models",
        len(repos),
        len(clients),
    )
    merged_catalogs: list[RepoCatalog] = []

    for repo, snapshot in zip(repos, snapshots, strict=True):
        # Run each model independently on this repo.
        catalogs_per_model: dict[str, RepoCatalog] = {}
        for client in clients:
            _logger.info("  %s: running model %s ...", repo.id, client.model)
            catalog = _phase_discover_repo(client, repo, snapshot, workspace)
            catalogs_per_model[client.model] = catalog

        # Merge results via consensus.
        merged = merge_catalogs(catalogs_per_model)
        merged_catalogs.append(merged)

    return merged_catalogs


# ── Phase 3: Generate config ─────────────────────────────────────────────


def _catalogs_to_json(catalogs: list[RepoCatalog]) -> str:
    """Serialize catalogs to JSON for the generation prompt."""
    data = []
    for cat in catalogs:
        data.append(
            {
                "repo_id": cat.repo_id,
                "repo_url": cat.repo_url,
                "branch": cat.branch,
                "snapshot_path": cat.snapshot_path,
                "contracts": [
                    {
                        "path": e.path,
                        "role": e.role,
                        "file_type": e.file_type,
                        "domain": e.domain,
                        "confidence": e.confidence,
                        "reasoning": e.reasoning,
                    }
                    for e in cat.contracts
                ],
            }
        )
    return json.dumps(data, indent=2)


def _phase_generate(
    client: LLMClient,
    catalogs: list[RepoCatalog],
    repos: list[RepoConfig],
) -> tuple[dict[str, Any], list[ContractPair], list[str]]:
    """Ask the LLM to generate the final drift config from discovery catalogs."""
    total_contracts = sum(len(c.contracts) for c in catalogs)
    _logger.info(
        "Phase 3: generating config from %d contracts across %d repos",
        total_contracts,
        len(catalogs),
    )

    if total_contracts == 0:
        _logger.warning("No contracts discovered. Generating minimal config.")
        config = {
            "version": 1,
            "repos": [
                {
                    "id": r.id,
                    "url": r.url,
                    "ref_policy": r.ref_policy,
                    "snapshot_path": r.snapshot_path,
                }
                for r in repos
            ],
            "checks": [],
            "policy": {
                "fail_on": [
                    {"severity": "critical", "status": "fail"},
                    {"severity": "high", "status": "fail"},
                ]
            },
        }
        return config, [], ["No contract files discovered in any repo."]

    catalogs_json = _catalogs_to_json(catalogs)
    system, user = format_generate_prompt(
        catalogs_json=catalogs_json,
        repo_count=len(catalogs),
    )

    response = client.complete(system, user)

    try:
        data = response.json()
    except (ValueError, KeyError) as exc:
        _logger.error("Failed to parse generation response: %s", exc)
        _logger.debug("Raw response: %s", response.content[:500])
        raise RuntimeError(f"LLM returned unparseable config: {exc}") from exc

    config = data.get("config", {})
    raw_pairs = data.get("pairs", [])
    notes = data.get("notes", [])

    pairs: list[ContractPair] = []
    for p in raw_pairs:
        pairs.append(
            ContractPair(
                domain=p.get("domain", ""),
                source_repo=p.get("source_repo", ""),
                source_path=p.get("source_path", ""),
                consumer_repo=p.get("consumer_repo", ""),
                consumer_path=p.get("consumer_path", ""),
            )
        )

    _logger.info(
        "Generated config with %d checks and %d pairs",
        len(config.get("checks", [])),
        len(pairs),
    )
    return config, pairs, notes


def _phase_generate_consensus(
    clients: Sequence[LLMClient],
    catalogs: list[RepoCatalog],
    repos: list[RepoConfig],
) -> tuple[dict[str, Any], list[ContractPair], list[str]]:
    """Run Phase 3 with multiple models and merge results via consensus."""
    _logger.info(
        "Phase 3 (consensus): generating config with %d models",
        len(clients),
    )

    configs_per_model: dict[str, dict[str, Any]] = {}
    pairs_per_model: dict[str, list[ContractPair]] = {}
    all_notes: list[str] = []

    for client in clients:
        _logger.info("  Running model %s ...", client.model)
        config, pairs, notes = _phase_generate(client, catalogs, repos)
        configs_per_model[client.model] = config
        pairs_per_model[client.model] = pairs
        all_notes.extend(f"[{client.model}] {n}" for n in notes)

    merged_config = merge_configs(configs_per_model)
    merged_pairs = merge_pairs(pairs_per_model)

    return merged_config, merged_pairs, all_notes


# ── Public API ────────────────────────────────────────────────────────────


def run_discover(
    client: LLMClient | None = None,
    repo_urls: list[str] | None = None,
    workspace: Path | None = None,
    ref_policy: str = "develop_or_main",
    skip_snapshot: bool = False,
    *,
    clients: Sequence[LLMClient] | None = None,
    orchestrator: LLMClient | None = None,
) -> DiscoverResult:
    """Run the full 3-phase discover workflow.

    Supports both single-model and multi-model consensus modes:
    - Pass ``client`` for single-model (backward compatible).
    - Pass ``clients`` (keyword-only) for multi-model consensus.
    - If both are provided, ``clients`` takes precedence.

    Args:
        client: Single LLM client for classification and generation.
        repo_urls: List of Git repo URLs.
        workspace: Local workspace root for snapshots.
        ref_policy: Default branch resolution policy.
        skip_snapshot: If True, skip cloning (assume repos are already present).
        clients: List of LLM clients for multi-model consensus.
        orchestrator: Optional orchestrator client for final synthesis.

    Returns:
        DiscoverResult with catalogs, pairs, and generated config.
    """
    # Resolve client list.
    resolved_clients: Sequence[LLMClient]
    if clients is not None and len(clients) > 0:
        resolved_clients = clients
    elif client is not None:
        resolved_clients = [client]
    else:
        msg = "Either 'client' or 'clients' must be provided"
        raise ValueError(msg)

    if repo_urls is None:
        msg = "'repo_urls' is required"
        raise ValueError(msg)
    if workspace is None:
        msg = "'workspace' is required"
        raise ValueError(msg)

    use_consensus = len(resolved_clients) > 1

    repos = _build_repo_configs(repo_urls, ref_policy)

    # Phase 1: Snapshot
    if skip_snapshot:
        _logger.info("Skipping snapshot phase (--no-snapshot)")
        snapshots = [
            SnapshotResult(
                repo_id=r.id,
                branch="unknown",
                commit="unknown",
                path=str(
                    Path(r.snapshot_path).resolve()
                    if Path(r.snapshot_path).is_absolute()
                    else (workspace / r.snapshot_path).resolve()
                ),
            )
            for r in repos
        ]
    else:
        snapshots = _phase_snapshot(repos, workspace)

    # Phase 2: Discover
    if use_consensus:
        catalogs = _phase_discover_consensus(resolved_clients, repos, snapshots, workspace)
    else:
        catalogs = _phase_discover(resolved_clients[0], repos, snapshots, workspace)

    # Phase 3: Generate
    if use_consensus:
        config, pairs, notes = _phase_generate_consensus(resolved_clients, catalogs, repos)
    else:
        config, pairs, notes = _phase_generate(resolved_clients[0], catalogs, repos)

    if notes:
        for note in notes:
            _logger.info("Note: %s", note)

    # ── Orchestrator synthesis (optional) ────────────────────────
    if orchestrator is not None:
        from repo_drift.orchestrator import synthesize_discover

        catalogs_json = [
            {
                "repo_id": cat.repo_id,
                "contracts": [
                    {
                        "path": e.path,
                        "role": e.role,
                        "file_type": e.file_type,
                        "domain": e.domain,
                        "confidence": e.confidence,
                        "agreement_count": e.agreement_count,
                    }
                    for e in cat.contracts
                ],
            }
            for cat in catalogs
        ]
        pairs_json = [
            {
                "domain": p.domain,
                "source_repo": p.source_repo,
                "source_path": p.source_path,
                "consumer_repo": p.consumer_repo,
                "consumer_path": p.consumer_path,
                "agreement_count": p.agreement_count,
            }
            for p in pairs
        ]
        config = synthesize_discover(
            orchestrator=orchestrator,
            catalogs_json=catalogs_json,
            pairs_json=pairs_json,
            config=config,
        )

    # Aggregate token usage across all clients.
    total_usage: dict[str, int] = {
        "prompt_tokens": 0,
        "completion_tokens": 0,
        "total": 0,
    }
    for c in resolved_clients:
        tokens = c.total_tokens
        total_usage["prompt_tokens"] += tokens.get("prompt_tokens", 0)
        total_usage["completion_tokens"] += tokens.get("completion_tokens", 0)
        total_usage["total"] += tokens.get("total", 0)

    # Include orchestrator token usage if present.
    if orchestrator is not None:
        tokens = orchestrator.total_tokens
        total_usage["prompt_tokens"] += tokens.get("prompt_tokens", 0)
        total_usage["completion_tokens"] += tokens.get("completion_tokens", 0)
        total_usage["total"] += tokens.get("total", 0)

    return DiscoverResult(
        catalogs=catalogs,
        pairs=pairs,
        config=config,
        token_usage=total_usage,
    )
