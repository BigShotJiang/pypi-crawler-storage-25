"""LLM prompt templates for the init command — architecture mapping.

Phase 2 (Analyze): uses repo analysis data to ask the LLM for architecture insights.
Phase 3 (Map): uses all repo analyses to build cross-repo architecture map.
"""

from __future__ import annotations

# ── Phase 2: Analyze each repo (LLM-enhanced) ────────────────────

ANALYZE_SYSTEM = """\
You are an expert software architect analyzing a repository to understand its \
role in a multi-repo system.

You will receive:
- Repository metadata (name, URL, branch)
- Detected tech stack (languages, frameworks, build tools)
- Package manifest contents
- Entry-point source code snippets
- Detected contract files (schemas, specs, protos)
- Detected infrastructure dependencies
- README content

Your task is to produce a structured JSON analysis with:

1. **summary**: 1-3 sentence description of what this repo does and its role.
2. **service_type**: One of: api, worker, gateway, frontend, cli, library, \
monorepo, data-pipeline, event-processor, unknown.
3. **tech_stack**: Refined list of key technologies (language + version, \
framework, database, etc.). Be specific (e.g., "Go 1.22" not just "Go").
4. **owns_contracts**: List of contract domain names this repo is the SOURCE \
of truth for. Use short logical names like "user-api", "order-events", \
"payment-schema". If a schema/spec file lives here and other repos consume \
copies of it, this repo owns that contract.
5. **consumes_contracts**: List of contract domain names this repo CONSUMES \
(copies/imports from other repos).
6. **endpoints**: Refined list of API endpoints/routes discovered. Each has \
method, path, description. Include only real application routes, not health \
checks or middleware.
7. **infra_dependencies**: Refined list of infrastructure this repo depends \
on (databases, caches, queues, etc.). Each has kind, technology, and purpose.
8. **risk_areas**: List of areas where contract drift could cause problems. \
Each has a description and severity (low/medium/high/critical).

Respond with ONLY valid JSON, no markdown fences, no commentary.

JSON schema:
{
  "summary": "string",
  "service_type": "string",
  "tech_stack": ["string"],
  "owns_contracts": ["string"],
  "consumes_contracts": ["string"],
  "endpoints": [{"method": "string", "path": "string", "description": "string"}],
  "infra_dependencies": [{"kind": "string", "technology": "string", "purpose": "string"}],
  "risk_areas": [{"description": "string", "severity": "string"}]
}
"""

ANALYZE_USER = """\
Repository: {repo_id}
URL: {repo_url}
Branch: {branch}

## Detected Tech Stack
Languages: {languages}
Frameworks: {frameworks}
Build tools: {build_tools}
Detected service type: {service_type}

## README
{readme}

## Package Manifests
{manifests}

## Entry Points
{entry_points}

## Detected Contract Files
{contracts}

## Detected Infrastructure
{infra}

## Detected Endpoints
{endpoints}
"""

# ── Phase 3: Map architecture across all repos ───────────────────

MAP_SYSTEM = """\
You are an expert software architect mapping the relationships between \
multiple repositories in a system.

You will receive the analysis of each repository including its summary, \
tech stack, owned/consumed contracts, endpoints, and infrastructure.

Your task is to produce a comprehensive architecture map as JSON:

1. **repos**: Array of repo summaries. For each repo:
   - repo_id, summary, tech_stack (refined), service_type
   - owns_contracts: contract domains this repo is source-of-truth for
   - consumes_contracts: contract domains this repo consumes

2. **relationships**: Array of repo-to-repo relationships. For each:
   - from_repo, to_repo
   - type: one of "http", "grpc", "event", "shared-schema", "library", \
"database", "file-sync", "unknown"
   - contracts: list of contract domain names involved
   - description: how these repos relate

3. **contract_expectations**: Array of expected contracts that should be \
monitored for drift. For each:
   - domain: logical contract name
   - type: "openapi", "json-schema", "protobuf", "graphql", "typescript", \
"avro", "config", "other"
   - owner: repo_id of the source of truth
   - consumers: list of repo_ids that consume this contract
   - risk: "low", "medium", "high", or "critical" — based on how many \
consumers and how critical the contract is
   - rationale: why this risk level

4. **notes**: Array of observations, warnings, or suggestions about the \
architecture. Include anything the operator should know about potential \
drift risks, missing contracts, or architectural concerns.

Guidelines:
- Match contracts across repos by domain name similarity, file type, and \
directory patterns.
- Infer relationships from shared dependencies, common schemas, API \
endpoints that match consumed URLs.
- Higher risk for contracts with more consumers or critical data flows.
- If a contract is only detected in one repo, note it but give it lower risk.
- Be specific about WHY repos are related, not just that they are.

Respond with ONLY valid JSON, no markdown fences, no commentary.
"""

MAP_USER = """\
## Repository Analyses

{analyses_json}

## Cross-Repo Observations

Total repos: {repo_count}
Repos with API endpoints: {api_repo_count}
Repos with contract files: {contract_repo_count}
Unique contract domains detected: {domain_count}
Shared infrastructure: {shared_infra}
"""


def format_analyze_prompt(analysis_dict: dict) -> tuple[str, str]:
    """Format the Phase 2 analyze prompt for a single repo."""
    manifests = ""
    for name, content in analysis_dict.get("manifest_contents", {}).items():
        manifests += f"\n### {name}\n```\n{content}\n```\n"
    if not manifests:
        manifests = "(none detected)"

    entry_points = ""
    for name, content in analysis_dict.get("entry_point_snippets", {}).items():
        entry_points += f"\n### {name}\n```\n{content}\n```\n"
    if not entry_points:
        entry_points = "(none detected)"

    contracts_list = analysis_dict.get("contracts", [])
    if contracts_list:
        contracts = "\n".join(f"- {c['path']} ({c['file_type']})" for c in contracts_list)
    else:
        contracts = "(none detected)"

    infra_list = analysis_dict.get("infra", [])
    if infra_list:
        infra = "\n".join(
            f"- {i['technology']} ({i['kind']}) — found in {i['evidence']}" for i in infra_list
        )
    else:
        infra = "(none detected)"

    endpoints_list = analysis_dict.get("endpoints", [])
    if endpoints_list:
        endpoints = "\n".join(
            f"- {e['method']} {e['path']} (in {e['source_file']})" for e in endpoints_list
        )
    else:
        endpoints = "(none detected from source; the LLM may find more)"

    user = ANALYZE_USER.format(
        repo_id=analysis_dict["repo_id"],
        repo_url=analysis_dict["repo_url"],
        branch=analysis_dict.get("branch", "main"),
        languages=", ".join(analysis_dict.get("languages", [])) or "unknown",
        frameworks=", ".join(analysis_dict.get("frameworks", [])) or "none detected",
        build_tools=", ".join(analysis_dict.get("build_tools", [])) or "unknown",
        service_type=analysis_dict.get("service_type", "unknown"),
        readme=analysis_dict.get("readme_summary", "(no README found)")[:2000],
        manifests=manifests,
        entry_points=entry_points,
        contracts=contracts,
        infra=infra,
        endpoints=endpoints,
    )

    return ANALYZE_SYSTEM, user


def format_map_prompt(
    analyses: list[dict],
    repo_count: int,
) -> tuple[str, str]:
    """Format the Phase 3 map prompt with all repo analyses."""
    import json

    # Count stats for the prompt
    api_repos = sum(
        1 for a in analyses if a.get("service_type") in ("api", "grpc-service", "gateway")
    )
    contract_repos = sum(1 for a in analyses if a.get("contracts"))

    # Collect unique domains
    domains: set[str] = set()
    for a in analyses:
        for c in a.get("owns_contracts", []):
            domains.add(c)
        for c in a.get("consumes_contracts", []):
            domains.add(c)

    # Find shared infra
    infra_counts: dict[str, int] = {}
    for a in analyses:
        for i in a.get("infra_dependencies", a.get("infra", [])) or []:
            tech = i.get("technology", "")
            if tech:
                infra_counts[tech] = infra_counts.get(tech, 0) + 1
    shared = [f"{tech} ({count} repos)" for tech, count in infra_counts.items() if count > 1]

    user = MAP_USER.format(
        analyses_json=json.dumps(analyses, indent=2),
        repo_count=repo_count,
        api_repo_count=api_repos,
        contract_repo_count=contract_repos,
        domain_count=len(domains),
        shared_infra=", ".join(shared) if shared else "none detected",
    )

    return MAP_SYSTEM, user
