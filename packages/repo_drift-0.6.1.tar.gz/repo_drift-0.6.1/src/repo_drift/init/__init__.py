"""Init package — architecture mapping and config generation.

The ``init`` command performs a deep analysis of all listed repositories,
builds a cross-repo architecture map, discovers contracts, and generates
both an ARCHITECTURE.md and a .repo-drift.json config file.
"""

from __future__ import annotations

from .analyze import analyze_repo
from .markdown import render_architecture_md
from .overrides import load_overrides, merge_config_with_overrides
from .types import (
    ArchitectureMap,
    ContractExpectation,
    DetectedContract,
    DetectedDependency,
    DetectedEndpoint,
    InfraComponent,
    InitResult,
    RepoAnalysis,
    RepoRelationship,
    RepoSummary,
)
from .workflow import run_init

__all__ = [
    "ArchitectureMap",
    "ContractExpectation",
    "DetectedContract",
    "DetectedDependency",
    "DetectedEndpoint",
    "InfraComponent",
    "InitResult",
    "RepoAnalysis",
    "RepoRelationship",
    "RepoSummary",
    "analyze_repo",
    "load_overrides",
    "merge_config_with_overrides",
    "render_architecture_md",
    "run_init",
]
