"""Data structures for the init command — repo analysis and architecture mapping."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class DetectedDependency:
    """An inter-repo or external dependency detected from manifests."""

    name: str
    version: str = ""
    kind: str = "external"  # "external" | "internal" (another listed repo)


@dataclass(slots=True)
class DetectedEndpoint:
    """An API endpoint or route detected from source code or specs."""

    method: str  # GET, POST, gRPC, event, etc.
    path: str
    source_file: str = ""
    description: str = ""


@dataclass(slots=True)
class DetectedContract:
    """A contract file detected during deep analysis."""

    path: str
    file_type: str  # json-schema, openapi, protobuf, graphql, typescript, etc.
    domain: str = ""
    role: str = ""  # source, consumer, unknown


@dataclass(slots=True)
class InfraComponent:
    """An infrastructure dependency (database, queue, cache, etc.)."""

    kind: str  # database, queue, cache, storage, etc.
    technology: str  # PostgreSQL, Redis, RabbitMQ, S3, etc.
    evidence: str = ""  # where we detected it


@dataclass(slots=True)
class RepoAnalysis:
    """Deep analysis results for a single repository."""

    repo_id: str
    repo_url: str
    branch: str
    snapshot_path: str

    # Detected metadata
    languages: list[str] = field(default_factory=list)
    frameworks: list[str] = field(default_factory=list)
    build_tools: list[str] = field(default_factory=list)
    service_type: str = ""  # api, worker, gateway, cli, library, monorepo, unknown
    readme_summary: str = ""

    # Detected artifacts
    dependencies: list[DetectedDependency] = field(default_factory=list)
    endpoints: list[DetectedEndpoint] = field(default_factory=list)
    contracts: list[DetectedContract] = field(default_factory=list)
    infra: list[InfraComponent] = field(default_factory=list)

    # Raw file contents for LLM context
    manifest_contents: dict[str, str] = field(default_factory=dict)
    entry_point_snippets: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize for LLM prompt or JSON output."""
        return {
            "repo_id": self.repo_id,
            "repo_url": self.repo_url,
            "branch": self.branch,
            "languages": self.languages,
            "frameworks": self.frameworks,
            "build_tools": self.build_tools,
            "service_type": self.service_type,
            "readme_summary": self.readme_summary,
            "dependencies": [
                {"name": d.name, "version": d.version, "kind": d.kind} for d in self.dependencies
            ],
            "endpoints": [
                {
                    "method": e.method,
                    "path": e.path,
                    "source_file": e.source_file,
                    "description": e.description,
                }
                for e in self.endpoints
            ],
            "contracts": [
                {
                    "path": c.path,
                    "file_type": c.file_type,
                    "domain": c.domain,
                    "role": c.role,
                }
                for c in self.contracts
            ],
            "infra": [
                {"kind": i.kind, "technology": i.technology, "evidence": i.evidence}
                for i in self.infra
            ],
        }


@dataclass(slots=True)
class RepoRelationship:
    """A dependency/communication relationship between two repos."""

    from_repo: str
    to_repo: str
    rel_type: str  # http, grpc, event, shared-schema, library, database, etc.
    contracts: list[str] = field(default_factory=list)  # domain names
    description: str = ""
    agreement_count: int = 0
    agreed_models: list[str] = field(default_factory=list)


@dataclass(slots=True)
class ContractExpectation:
    """An expected contract between repos, identified by the architecture map."""

    domain: str
    contract_type: str  # openapi, json-schema, protobuf, graphql, etc.
    owner_repo: str
    consumer_repos: list[str] = field(default_factory=list)
    risk: str = "medium"  # low, medium, high, critical
    rationale: str = ""
    agreement_count: int = 0
    agreed_models: list[str] = field(default_factory=list)


@dataclass(slots=True)
class RepoSummary:
    """LLM-generated summary for a single repo in the architecture map."""

    repo_id: str
    summary: str
    tech_stack: list[str] = field(default_factory=list)
    service_type: str = ""
    owns_contracts: list[str] = field(default_factory=list)
    consumes_contracts: list[str] = field(default_factory=list)
    agreement_count: int = 0
    agreed_models: list[str] = field(default_factory=list)


@dataclass(slots=True)
class ArchitectureMap:
    """The full architecture map produced by the init command."""

    repos: list[RepoSummary] = field(default_factory=list)
    relationships: list[RepoRelationship] = field(default_factory=list)
    contract_expectations: list[ContractExpectation] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Serialize for JSON output."""
        return {
            "repos": [
                {
                    "repo_id": r.repo_id,
                    "summary": r.summary,
                    "tech_stack": r.tech_stack,
                    "service_type": r.service_type,
                    "owns_contracts": r.owns_contracts,
                    "consumes_contracts": r.consumes_contracts,
                    "agreement_count": r.agreement_count,
                    "agreed_models": r.agreed_models,
                }
                for r in self.repos
            ],
            "relationships": [
                {
                    "from_repo": rel.from_repo,
                    "to_repo": rel.to_repo,
                    "type": rel.rel_type,
                    "contracts": rel.contracts,
                    "description": rel.description,
                    "agreement_count": rel.agreement_count,
                    "agreed_models": rel.agreed_models,
                }
                for rel in self.relationships
            ],
            "contract_expectations": [
                {
                    "domain": ce.domain,
                    "type": ce.contract_type,
                    "owner": ce.owner_repo,
                    "consumers": ce.consumer_repos,
                    "risk": ce.risk,
                    "rationale": ce.rationale,
                    "agreement_count": ce.agreement_count,
                    "agreed_models": ce.agreed_models,
                }
                for ce in self.contract_expectations
            ],
            "notes": self.notes,
        }


@dataclass(slots=True)
class InitResult:
    """Full output of the init workflow."""

    analyses: list[RepoAnalysis]
    architecture: ArchitectureMap
    config: dict[str, Any]
    markdown: str
    token_usage: dict[str, int] = field(default_factory=dict)
