"""Override merge logic for init-generated configs.

Supports a .repo-drift-overrides.json file that layers on top of the
auto-generated config. Overrides take precedence on conflict.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

_logger = logging.getLogger(__name__)


def load_overrides(path: Path) -> dict[str, Any]:
    """Load an overrides file. Returns empty dict if not found."""
    if not path.is_file():
        return {}
    try:
        text = path.read_text(encoding="utf-8")
        data = json.loads(text)
        if not isinstance(data, dict):
            _logger.warning("overrides file is not a JSON object: %s", path)
            return {}
        _logger.info("loaded overrides from %s", path)
        return data
    except (json.JSONDecodeError, OSError) as exc:
        _logger.warning("failed to load overrides from %s: %s", path, exc)
        return {}


def merge_config_with_overrides(
    config: dict[str, Any],
    overrides: dict[str, Any],
) -> dict[str, Any]:
    """Merge an auto-generated config with user overrides.

    Merge strategy:
    - repos: union by id (override wins on conflict)
    - checks: union by id (override wins on conflict)
    - policy.fail_on: union (deduplicated by severity+status)
    - extra_contracts: appended to contract expectations
    - severity_overrides: applied to matching checks by id
    - Any other top-level keys from overrides are added as-is
    """
    merged = dict(config)

    # Merge repos
    if "repos" in overrides:
        merged["repos"] = _merge_by_id(
            config.get("repos", []),
            overrides["repos"],
        )

    # Merge checks
    if "checks" in overrides:
        merged["checks"] = _merge_by_id(
            config.get("checks", []),
            overrides["checks"],
        )

    # Merge policy
    if "policy" in overrides:
        merged_policy = dict(config.get("policy", {}))
        override_policy = overrides["policy"]

        if "fail_on" in override_policy:
            existing = config.get("policy", {}).get("fail_on", [])
            merged_policy["fail_on"] = _merge_fail_on(existing, override_policy["fail_on"])

        # Copy any other policy fields
        for key, val in override_policy.items():
            if key != "fail_on":
                merged_policy[key] = val

        merged["policy"] = merged_policy

    # Apply severity overrides
    if "severity_overrides" in overrides:
        _apply_severity_overrides(merged, overrides["severity_overrides"])

    # Copy any other top-level override keys
    skip_keys = {"repos", "checks", "policy", "severity_overrides"}
    for key, val in overrides.items():
        if key not in skip_keys:
            merged[key] = val

    return merged


def _merge_by_id(
    base: list[dict[str, Any]],
    overrides: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Merge two lists of objects by 'id' field. Override wins on conflict."""
    by_id: dict[str, dict[str, Any]] = {}
    for item in base:
        item_id = item.get("id", "")
        if item_id:
            by_id[item_id] = item

    for item in overrides:
        item_id = item.get("id", "")
        if item_id:
            if item_id in by_id:
                # Merge: override fields take precedence
                merged_item = dict(by_id[item_id])
                merged_item.update(item)
                by_id[item_id] = merged_item
            else:
                by_id[item_id] = item

    return list(by_id.values())


def _merge_fail_on(
    base: list[dict[str, Any]],
    overrides: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Merge fail_on rules, deduplicated by (severity, status)."""
    seen: set[tuple[str, str]] = set()
    result: list[dict[str, Any]] = []

    # Overrides first (they take precedence)
    for rule in overrides:
        key = (rule.get("severity", ""), rule.get("status", ""))
        if key not in seen:
            seen.add(key)
            result.append(rule)

    for rule in base:
        key = (rule.get("severity", ""), rule.get("status", ""))
        if key not in seen:
            seen.add(key)
            result.append(rule)

    return result


def _apply_severity_overrides(
    config: dict[str, Any],
    severity_overrides: dict[str, str],
) -> None:
    """Apply severity overrides to checks by check ID."""
    valid_severities = {"low", "medium", "high", "critical"}
    for check in config.get("checks", []):
        check_id = check.get("id", "")
        if check_id in severity_overrides:
            new_severity = severity_overrides[check_id]
            if new_severity in valid_severities:
                _logger.info(
                    "override: check %s severity %s -> %s",
                    check_id,
                    check.get("severity", ""),
                    new_severity,
                )
                check["severity"] = new_severity
            else:
                _logger.warning("invalid severity override for %s: %s", check_id, new_severity)
