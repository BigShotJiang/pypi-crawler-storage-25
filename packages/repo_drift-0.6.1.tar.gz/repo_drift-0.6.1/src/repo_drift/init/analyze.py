"""Deep repository analysis — extract architecture signals from file system.

Scans manifests, entry points, config files, and directory structure to build
a rich understanding of each repo's tech stack, service type, and contracts.
All file-based extraction, no code execution.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

from .types import (
    DetectedContract,
    DetectedDependency,
    DetectedEndpoint,
    InfraComponent,
    RepoAnalysis,
)

_logger = logging.getLogger(__name__)

# ── Manifest detection ─────────────────────────────────────────────

_MANIFEST_FILES: dict[str, dict[str, str]] = {
    # filename -> {language, build_tool}
    "package.json": {"language": "JavaScript/TypeScript", "build_tool": "npm"},
    "package-lock.json": {"language": "JavaScript/TypeScript", "build_tool": "npm"},
    "yarn.lock": {"language": "JavaScript/TypeScript", "build_tool": "yarn"},
    "pnpm-lock.yaml": {"language": "JavaScript/TypeScript", "build_tool": "pnpm"},
    "go.mod": {"language": "Go", "build_tool": "go"},
    "Cargo.toml": {"language": "Rust", "build_tool": "cargo"},
    "pyproject.toml": {"language": "Python", "build_tool": "pip"},
    "setup.py": {"language": "Python", "build_tool": "pip"},
    "requirements.txt": {"language": "Python", "build_tool": "pip"},
    "Pipfile": {"language": "Python", "build_tool": "pipenv"},
    "pom.xml": {"language": "Java", "build_tool": "maven"},
    "build.gradle": {"language": "Java/Kotlin", "build_tool": "gradle"},
    "build.gradle.kts": {"language": "Kotlin", "build_tool": "gradle"},
    "Gemfile": {"language": "Ruby", "build_tool": "bundler"},
    "composer.json": {"language": "PHP", "build_tool": "composer"},
    "mix.exs": {"language": "Elixir", "build_tool": "mix"},
    "Makefile": {"build_tool": "make"},
    "CMakeLists.txt": {"language": "C/C++", "build_tool": "cmake"},
}

# Framework detection patterns: (file_or_dir, framework_name)
_FRAMEWORK_SIGNALS: list[tuple[str, str]] = [
    # JS/TS
    ("next.config.js", "Next.js"),
    ("next.config.ts", "Next.js"),
    ("next.config.mjs", "Next.js"),
    ("nuxt.config.ts", "Nuxt"),
    ("nuxt.config.js", "Nuxt"),
    ("angular.json", "Angular"),
    ("svelte.config.js", "SvelteKit"),
    ("remix.config.js", "Remix"),
    ("astro.config.mjs", "Astro"),
    ("vite.config.ts", "Vite"),
    ("vite.config.js", "Vite"),
    ("webpack.config.js", "Webpack"),
    ("tsconfig.json", "TypeScript"),
    # Python
    ("manage.py", "Django"),
    ("django", "Django"),
    ("fastapi", "FastAPI"),
    ("flask", "Flask"),
    ("starlette", "Starlette"),
    # Go
    ("go.mod", "Go"),
    # Ruby
    ("config/routes.rb", "Rails"),
    ("Rakefile", "Rails"),
    # Java/Kotlin
    ("spring", "Spring"),
    # Rust
    ("actix", "Actix"),
    ("axum", "Axum"),
    ("rocket", "Rocket"),
    # Infra
    ("Dockerfile", "Docker"),
    ("docker-compose.yml", "Docker Compose"),
    ("docker-compose.yaml", "Docker Compose"),
    ("Procfile", "Heroku"),
    ("serverless.yml", "Serverless"),
    ("serverless.yaml", "Serverless"),
    ("terraform", "Terraform"),
    ("pulumi", "Pulumi"),
]

# Entry-point files to read for context
_ENTRY_POINT_PATTERNS: list[str] = [
    "main.go",
    "cmd/*/main.go",
    "src/index.ts",
    "src/index.js",
    "src/main.ts",
    "src/main.js",
    "src/app.ts",
    "src/app.js",
    "app.py",
    "main.py",
    "src/main.py",
    "server.py",
    "src/server.py",
    "lib/index.ts",
    "lib/index.js",
    "index.ts",
    "index.js",
]

# Infrastructure signals in config files
_INFRA_SIGNALS: dict[str, list[tuple[str, str]]] = {
    # keyword -> [(kind, technology)]
    "postgres": [("database", "PostgreSQL")],
    "postgresql": [("database", "PostgreSQL")],
    "mysql": [("database", "MySQL")],
    "mongodb": [("database", "MongoDB")],
    "redis": [("cache", "Redis")],
    "rabbitmq": [("queue", "RabbitMQ")],
    "amqp": [("queue", "RabbitMQ")],
    "kafka": [("queue", "Kafka")],
    "nats": [("queue", "NATS")],
    "elasticsearch": [("search", "Elasticsearch")],
    "dynamodb": [("database", "DynamoDB")],
    "s3": [("storage", "S3")],
    "sqs": [("queue", "SQS")],
    "sns": [("queue", "SNS")],
    "memcached": [("cache", "Memcached")],
    "sqlite": [("database", "SQLite")],
}

# Contract file patterns (broader than discover's scan)
_CONTRACT_DIRS = {
    "specs",
    "schemas",
    "contracts",
    "proto",
    "protobuf",
    "openapi",
    "generated",
    "shared",
    "api",
    "types",
    "interfaces",
    "graphql",
    "grpc",
    "events",
    "messages",
    "models",
}

_CONTRACT_EXTENSIONS: dict[str, str] = {
    ".proto": "protobuf",
    ".graphql": "graphql",
    ".gql": "graphql",
    ".avsc": "avro",
    ".xsd": "xml-schema",
}

_IGNORE_DIRS = {
    ".git",
    "node_modules",
    "__pycache__",
    ".venv",
    "venv",
    ".tox",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    "vendor",
    "dist",
    "build",
    ".next",
    ".nuxt",
    "target",
    "coverage",
    ".coverage",
    "htmlcov",
    ".DS_Store",
    ".idea",
    ".vscode",
}

_MAX_FILE_READ = 100  # max lines to read from any single file for context
_MAX_README_LINES = 200
_MAX_MANIFEST_SIZE = 64 * 1024  # 64 KB


def analyze_repo(
    repo_id: str,
    repo_url: str,
    branch: str,
    snapshot_path: str,
    repo_dir: Path,
) -> RepoAnalysis:
    """Perform deep analysis of a single repository.

    Scans the file system for manifests, entry points, contracts, and
    infrastructure signals. Does NOT execute any code.
    """
    analysis = RepoAnalysis(
        repo_id=repo_id,
        repo_url=repo_url,
        branch=branch,
        snapshot_path=snapshot_path,
    )

    if not repo_dir.is_dir():
        _logger.warning("repo dir does not exist: %s", repo_dir)
        return analysis

    _detect_manifests(repo_dir, analysis)
    _detect_frameworks(repo_dir, analysis)
    _read_readme(repo_dir, analysis)
    _read_entry_points(repo_dir, analysis)
    _scan_contracts(repo_dir, analysis)
    _detect_infra(repo_dir, analysis)
    _infer_service_type(analysis)

    _logger.info(
        "analyzed %s: %s, %s, %d contracts, %d endpoints, %d infra",
        repo_id,
        "/".join(analysis.languages) or "unknown",
        analysis.service_type or "unknown",
        len(analysis.contracts),
        len(analysis.endpoints),
        len(analysis.infra),
    )

    return analysis


def _safe_read(path: Path, max_lines: int = _MAX_FILE_READ) -> str:
    """Read a file safely, returning empty string on error."""
    try:
        if path.stat().st_size > _MAX_MANIFEST_SIZE:
            return ""
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        if len(lines) > max_lines:
            lines = lines[:max_lines]
            lines.append(f"... (truncated at {max_lines} lines)")
        return "\n".join(lines)
    except OSError:
        return ""


def _detect_manifests(repo_dir: Path, analysis: RepoAnalysis) -> None:
    """Find package manifests and extract language/build tool info."""
    languages: set[str] = set()
    build_tools: set[str] = set()

    for filename, info in _MANIFEST_FILES.items():
        path = repo_dir / filename
        if path.is_file():
            if "language" in info:
                languages.add(info["language"])
            if "build_tool" in info:
                build_tools.add(info["build_tool"])

            # Read manifest for LLM context
            content = _safe_read(path)
            if content:
                analysis.manifest_contents[filename] = content

            # Extract dependencies from package.json
            if filename == "package.json" and content:
                _extract_npm_deps(content, analysis)

            # Extract dependencies from go.mod
            if filename == "go.mod" and content:
                _extract_go_deps(content, analysis)

    # Check for TypeScript specifically
    if (repo_dir / "tsconfig.json").is_file():
        languages.add("TypeScript")
        languages.discard("JavaScript/TypeScript")

    analysis.languages = sorted(languages)
    analysis.build_tools = sorted(build_tools)


def _extract_npm_deps(content: str, analysis: RepoAnalysis) -> None:
    """Extract dependencies from package.json content."""
    try:
        data = json.loads(content)
    except (json.JSONDecodeError, ValueError):
        return

    for section in ("dependencies", "devDependencies", "peerDependencies"):
        deps = data.get(section, {})
        if isinstance(deps, dict):
            for name, version in deps.items():
                if isinstance(version, str):
                    analysis.dependencies.append(DetectedDependency(name=name, version=version))

    # Detect frameworks from dependencies
    dep_names = set()
    for section in ("dependencies", "devDependencies"):
        deps = data.get(section, {})
        if isinstance(deps, dict):
            dep_names.update(deps.keys())

    framework_map = {
        "express": "Express",
        "fastify": "Fastify",
        "koa": "Koa",
        "hapi": "Hapi",
        "@nestjs/core": "NestJS",
        "next": "Next.js",
        "nuxt": "Nuxt",
        "react": "React",
        "vue": "Vue",
        "@angular/core": "Angular",
        "svelte": "Svelte",
    }
    for pkg, framework in framework_map.items():
        if pkg in dep_names and framework not in analysis.frameworks:
            analysis.frameworks.append(framework)


def _extract_go_deps(content: str, analysis: RepoAnalysis) -> None:
    """Extract dependencies from go.mod content."""
    in_require = False
    for line in content.splitlines():
        stripped = line.strip()
        if stripped.startswith("require ("):
            in_require = True
            continue
        if in_require and stripped == ")":
            in_require = False
            continue
        if in_require and stripped and not stripped.startswith("//"):
            parts = stripped.split()
            if len(parts) >= 2:
                analysis.dependencies.append(DetectedDependency(name=parts[0], version=parts[1]))

    # Detect Go frameworks from imports
    go_framework_map = {
        "github.com/gin-gonic/gin": "Gin",
        "github.com/go-chi/chi": "Chi",
        "github.com/labstack/echo": "Echo",
        "github.com/gofiber/fiber": "Fiber",
        "github.com/gorilla/mux": "Gorilla Mux",
        "google.golang.org/grpc": "gRPC",
        "github.com/grpc/grpc-go": "gRPC",
    }
    for mod, framework in go_framework_map.items():
        if mod in content and framework not in analysis.frameworks:
            analysis.frameworks.append(framework)


def _detect_frameworks(repo_dir: Path, analysis: RepoAnalysis) -> None:
    """Detect frameworks from config files and directory structure."""
    for signal_path, framework in _FRAMEWORK_SIGNALS:
        if framework in analysis.frameworks:
            continue
        full = repo_dir / signal_path
        if full.exists():
            analysis.frameworks.append(framework)

    analysis.frameworks = sorted(set(analysis.frameworks))


def _read_readme(repo_dir: Path, analysis: RepoAnalysis) -> None:
    """Read the repo README for self-described purpose."""
    for name in ("README.md", "readme.md", "README.rst", "README.txt", "README"):
        path = repo_dir / name
        if path.is_file():
            analysis.readme_summary = _safe_read(path, max_lines=_MAX_README_LINES)
            return


def _read_entry_points(repo_dir: Path, analysis: RepoAnalysis) -> None:
    """Read entry-point files for service context."""
    for pattern in _ENTRY_POINT_PATTERNS:
        matches = sorted(repo_dir.glob(pattern))
        for match in matches[:3]:  # cap at 3 matches per pattern
            rel = str(match.relative_to(repo_dir))
            content = _safe_read(match)
            if content:
                analysis.entry_point_snippets[rel] = content

                # Try to extract endpoints from source
                _extract_endpoints_from_source(rel, content, analysis)


def _extract_endpoints_from_source(filename: str, content: str, analysis: RepoAnalysis) -> None:
    """Best-effort endpoint extraction from source code patterns."""
    lines = content.splitlines()
    for line in lines:
        stripped = line.strip()

        # Express/Fastify/Koa patterns: app.get("/path", ...)
        for method in ("get", "post", "put", "delete", "patch"):
            prefix = f"app.{method}("
            router_prefix = f"router.{method}("
            for p in (prefix, router_prefix):
                if p in stripped.lower():
                    path = _extract_string_arg(stripped, p)
                    if path:
                        analysis.endpoints.append(
                            DetectedEndpoint(
                                method=method.upper(),
                                path=path,
                                source_file=filename,
                            )
                        )

        # FastAPI patterns: @app.get("/path")
        if stripped.startswith("@app.") or stripped.startswith("@router."):
            for method in ("get", "post", "put", "delete", "patch"):
                tag = f".{method}("
                if tag in stripped.lower():
                    path = _extract_string_arg(stripped, tag)
                    if path:
                        analysis.endpoints.append(
                            DetectedEndpoint(
                                method=method.upper(),
                                path=path,
                                source_file=filename,
                            )
                        )

        # Go Chi/Gin/Echo: r.Get("/path", handler)
        for method in ("Get", "Post", "Put", "Delete", "Patch"):
            prefix = f".{method}("
            if prefix in stripped:
                path = _extract_string_arg(stripped, prefix)
                if path:
                    analysis.endpoints.append(
                        DetectedEndpoint(
                            method=method.upper(),
                            path=path,
                            source_file=filename,
                        )
                    )


def _extract_string_arg(line: str, after: str) -> str:
    """Extract first string argument after a pattern in a line."""
    idx = line.lower().find(after.lower())
    if idx < 0:
        return ""
    rest = line[idx + len(after) :]
    for quote in ('"', "'", "`"):
        if quote in rest:
            start = rest.index(quote) + 1
            end = rest.find(quote, start)
            if end > start:
                return rest[start:end]
    return ""


def _scan_contracts(repo_dir: Path, analysis: RepoAnalysis) -> None:
    """Scan for contract-like files (broader than discover's scan)."""
    for path in sorted(repo_dir.rglob("*")):
        if not path.is_file():
            continue

        # Skip ignored dirs
        parts = path.relative_to(repo_dir).parts
        if any(p in _IGNORE_DIRS for p in parts):
            continue

        rel = str(path.relative_to(repo_dir))
        suffix = path.suffix.lower()

        # Check by extension
        if suffix in _CONTRACT_EXTENSIONS:
            analysis.contracts.append(
                DetectedContract(
                    path=rel,
                    file_type=_CONTRACT_EXTENSIONS[suffix],
                )
            )
            continue

        # Check by directory name
        if any(p.lower() in _CONTRACT_DIRS for p in parts[:-1]) and suffix in {
            ".json",
            ".yaml",
            ".yml",
            ".ts",
        }:
            ft = _guess_file_type(path, suffix)
            analysis.contracts.append(DetectedContract(path=rel, file_type=ft))
            continue

        # Check compound extensions
        name_lower = path.name.lower()
        if name_lower.endswith((".schema.json", ".schema.yaml", ".schema.yml")):
            analysis.contracts.append(DetectedContract(path=rel, file_type="json-schema"))
        elif (
            name_lower.endswith((".openapi.json", ".openapi.yaml", ".openapi.yml"))
            or name_lower in ("openapi.json", "openapi.yaml", "openapi.yml")
            or name_lower in ("swagger.json", "swagger.yaml", "swagger.yml")
        ):
            analysis.contracts.append(DetectedContract(path=rel, file_type="openapi"))


def _guess_file_type(path: Path, suffix: str) -> str:
    """Guess file type from content or suffix."""
    if suffix == ".ts":
        return "typescript"
    if suffix in (".yaml", ".yml"):
        # Quick check for openapi
        try:
            head = path.read_text(encoding="utf-8", errors="replace")[:500]
            if "openapi:" in head or "swagger:" in head:
                return "openapi"
        except OSError:
            pass
        return "yaml"
    if suffix == ".json":
        try:
            head = path.read_text(encoding="utf-8", errors="replace")[:500]
            if '"$schema"' in head or '"$id"' in head:
                return "json-schema"
            if '"openapi"' in head or '"swagger"' in head:
                return "openapi"
        except OSError:
            pass
        return "json"
    return "unknown"


def _detect_infra(repo_dir: Path, analysis: RepoAnalysis) -> None:
    """Detect infrastructure dependencies from config files."""
    infra_files = [
        "docker-compose.yml",
        "docker-compose.yaml",
        ".env.example",
        ".env.sample",
        "Dockerfile",
    ]

    # Also check k8s configs
    k8s_dir = repo_dir / "k8s"
    if k8s_dir.is_dir():
        for f in sorted(k8s_dir.rglob("*.yaml"))[:10]:
            infra_files.append(str(f.relative_to(repo_dir)))
        for f in sorted(k8s_dir.rglob("*.yml"))[:10]:
            infra_files.append(str(f.relative_to(repo_dir)))

    seen: set[str] = set()
    for filename in infra_files:
        path = repo_dir / filename
        if not path.is_file():
            continue
        content = _safe_read(path).lower()
        for keyword, components in _INFRA_SIGNALS.items():
            if keyword in content:
                for kind, tech in components:
                    key = f"{kind}:{tech}"
                    if key not in seen:
                        seen.add(key)
                        analysis.infra.append(
                            InfraComponent(
                                kind=kind,
                                technology=tech,
                                evidence=filename,
                            )
                        )

    # Also scan manifests for infra signals
    for filename, content in analysis.manifest_contents.items():
        content_lower = content.lower()
        for keyword, components in _INFRA_SIGNALS.items():
            if keyword in content_lower:
                for kind, tech in components:
                    key = f"{kind}:{tech}"
                    if key not in seen:
                        seen.add(key)
                        analysis.infra.append(
                            InfraComponent(
                                kind=kind,
                                technology=tech,
                                evidence=filename,
                            )
                        )


def _infer_service_type(analysis: RepoAnalysis) -> None:
    """Infer the service type from detected signals."""
    frameworks_lower = {f.lower() for f in analysis.frameworks}

    # API/web frameworks
    api_frameworks = {
        "express",
        "fastify",
        "koa",
        "hapi",
        "nestjs",
        "fastapi",
        "flask",
        "django",
        "starlette",
        "gin",
        "chi",
        "echo",
        "fiber",
        "gorilla mux",
        "actix",
        "axum",
        "rocket",
        "rails",
        "spring",
    }
    if frameworks_lower & api_frameworks:
        analysis.service_type = "api"
        return

    # Frontend frameworks
    frontend_frameworks = {
        "next.js",
        "nuxt",
        "angular",
        "sveltekit",
        "remix",
        "react",
        "vue",
        "svelte",
        "astro",
    }
    if frameworks_lower & frontend_frameworks:
        analysis.service_type = "frontend"
        return

    # gRPC service
    if "grpc" in frameworks_lower:
        analysis.service_type = "grpc-service"
        return

    # Check for worker patterns
    if analysis.endpoints:
        analysis.service_type = "api"
        return

    # Library if no entry points or endpoints
    if not analysis.entry_point_snippets and not analysis.endpoints:
        analysis.service_type = "library"
        return

    analysis.service_type = "unknown"
