from __future__ import annotations

import os
import stat
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlsplit

from .types import RepoConfig


@dataclass(slots=True)
class SnapshotResult:
    repo_id: str
    branch: str
    commit: str
    path: str


class SnapshotError(RuntimeError):
    pass


def _github_token() -> str | None:
    # Prefer explicit repo-drift token, then dedicated CI secret, then workflow token fallback.
    for key in ("REPO_DRIFT_GIT_TOKEN", "CROSS_REPO_READ_TOKEN", "GITHUB_TOKEN"):
        token = os.getenv(key)
        if token and token.strip():
            return token.strip()
    return None


def _needs_github_auth(url: str) -> bool:
    """Return True if the URL is a github.com HTTPS URL without embedded credentials."""
    parts = urlsplit(url)
    return parts.scheme == "https" and parts.hostname == "github.com" and not parts.username


def _git_askpass_env() -> dict[str, str]:
    """Build an env dict that supplies credentials via GIT_ASKPASS.

    This avoids embedding tokens in clone URLs where they could leak
    into error messages or process listings.  The helper script prints
    the token for *password* prompts and ``x-access-token`` for
    *username* prompts.
    """
    token = _github_token()
    if not token:
        return {}

    # Write a tiny helper script that git will invoke for credentials.
    fd, helper_path = tempfile.mkstemp(prefix="repo_drift_askpass_", suffix=".sh", text=True)
    with os.fdopen(fd, "w") as f:
        f.write(
            "#!/bin/sh\n"
            'case "$1" in\n'
            '  *assword*) printf "%s" "$REPO_DRIFT_TOKEN" ;;\n'
            '  *)         printf "x-access-token" ;;\n'
            "esac\n"
        )
    os.chmod(helper_path, stat.S_IRWXU)

    return {
        "GIT_ASKPASS": helper_path,
        "REPO_DRIFT_TOKEN": token,
        # Prevent git from prompting on a terminal if askpass somehow fails.
        "GIT_TERMINAL_PROMPT": "0",
    }


def _run(args: list[str], cwd: Path | None = None, extra_env: dict[str, str] | None = None) -> str:
    env = None
    if extra_env:
        env = {**os.environ, **extra_env}
    result = subprocess.run(
        args, cwd=str(cwd) if cwd else None, capture_output=True, text=True, env=env
    )
    if result.returncode != 0:
        raise SnapshotError(f"Command failed: {' '.join(args)}\n{result.stderr.strip()}")
    return result.stdout.strip()


def _with_auth_hint(error: SnapshotError) -> SnapshotError:
    message = str(error)
    if "could not read Username for 'https://github.com'" in message:
        return SnapshotError(
            f"{message}\nHint: configure CROSS_REPO_READ_TOKEN (fine-grained PAT or app token) "
            "with read access to all snapshot target repos."
        )
    return error


def _has_remote_branch(
    repo_dir: Path, branch: str, extra_env: dict[str, str] | None = None
) -> bool:
    env = None
    if extra_env:
        env = {**os.environ, **extra_env}
    result = subprocess.run(
        ["git", "ls-remote", "--exit-code", "--heads", "origin", branch],
        cwd=str(repo_dir),
        capture_output=True,
        text=True,
        env=env,
    )
    return result.returncode == 0


def _remote_default_branch(repo_dir: Path, extra_env: dict[str, str] | None = None) -> str | None:
    """Query the remote HEAD symref to determine the default branch."""
    env = None
    if extra_env:
        env = {**os.environ, **extra_env}
    result = subprocess.run(
        ["git", "ls-remote", "--symref", "origin", "HEAD"],
        cwd=str(repo_dir),
        capture_output=True,
        text=True,
        env=env,
    )
    if result.returncode != 0:
        return None
    # Output format: "ref: refs/heads/<branch>\tHEAD"
    for line in result.stdout.splitlines():
        if line.startswith("ref: refs/heads/"):
            return line.split("refs/heads/")[1].split()[0]
    return None


def _resolve_branch(
    repo: RepoConfig, repo_dir: Path, extra_env: dict[str, str] | None = None
) -> str:
    if repo.ref_policy == "develop_or_main":
        for candidate in ("develop", "main", "master"):
            if _has_remote_branch(repo_dir, candidate, extra_env):
                return candidate
        # Last resort: ask the remote for its default branch.
        default = _remote_default_branch(repo_dir, extra_env)
        if default:
            return default
        raise SnapshotError(
            f"No develop/main/master branch found for {repo.id}, "
            "and could not determine remote default branch"
        )
    if repo.ref_policy == "develop":
        return "develop"
    if repo.ref_policy == "main":
        return "main"
    if repo.ref_policy == "custom" and repo.custom_ref:
        return repo.custom_ref
    raise SnapshotError(f"Unsupported ref policy for {repo.id}: {repo.ref_policy}")


def ensure_snapshot(repo: RepoConfig, root: Path) -> SnapshotResult:
    repo_dir = (root / repo.snapshot_path).resolve()
    repo_dir.parent.mkdir(parents=True, exist_ok=True)

    # Use GIT_ASKPASS for authentication instead of embedding tokens in URLs.
    auth_env = _git_askpass_env() if _needs_github_auth(repo.url) else {}

    try:
        if not (repo_dir / ".git").exists():
            _run(["git", "clone", repo.url, str(repo_dir)], extra_env=auth_env)

        # Ensure the remote URL is the plain (no-token) URL.
        _run(["git", "remote", "set-url", "origin", repo.url], cwd=repo_dir, extra_env=auth_env)

        branch = _resolve_branch(repo, repo_dir, extra_env=auth_env)
        _run(["git", "fetch", "origin", branch, "--depth=1"], cwd=repo_dir, extra_env=auth_env)
        _run(
            ["git", "checkout", "-B", branch, f"origin/{branch}"], cwd=repo_dir, extra_env=auth_env
        )
        commit = _run(["git", "rev-parse", "--short", "HEAD"], cwd=repo_dir)
    except SnapshotError as exc:
        raise _with_auth_hint(exc) from exc

    return SnapshotResult(repo_id=repo.id, branch=branch, commit=commit, path=str(repo_dir))
