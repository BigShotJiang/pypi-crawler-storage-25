"""Generate a GitHub Agentic Workflows (gh-aw) template for cross-repo PR review.

Given a ``.repo-drift.json`` config, generates a ``.md`` workflow file that:
1. Triggers on ``pull_request`` events
2. Checks out the PR repo + sibling repos via ``checkout:`` frontmatter
3. Reads ``ARCHITECTURE.md`` and ``.repo-drift.json`` from workspace
4. AI agent reviews the PR diff with full architecture context
5. Posts a review comment explaining which contracts are affected

This is the **AI-powered review layer** — complementary to the deterministic
``check`` command (CI gate).
"""

from __future__ import annotations

from .types import ProjectConfig


def generate_aw_template(
    config: ProjectConfig,
    architecture_path: str = "ARCHITECTURE.md",
    config_path: str = ".repo-drift.json",
) -> str:
    """Generate a gh-aw workflow markdown file from the project config.

    Parameters
    ----------
    config:
        The loaded project config.
    architecture_path:
        Relative path to ARCHITECTURE.md (from workspace root).
    config_path:
        Relative path to .repo-drift.json (from workspace root).

    Returns
    -------
    The complete gh-aw workflow markdown string.
    """
    # Build checkout frontmatter for all repos.
    checkout_lines: list[str] = []
    repo_ids: list[str] = []
    for repo in config.repos:
        repo_ids.append(repo.id)
        # Only add checkout for remote repos (not local paths).
        if repo.url.startswith("https://") or repo.url.startswith("git@"):
            checkout_lines.append(f"  - repo: {_url_to_slug(repo.url)}")
            checkout_lines.append(f"    path: {repo.snapshot_path}")

    # Build the contract summary for the prompt.
    contract_lines: list[str] = []
    for chk in config.checks:
        left = chk.params.get("left", "?")
        right = chk.params.get("right", "?")
        contract_lines.append(
            f"- **{chk.id}** ({chk.type}, severity: {chk.severity}): `{left}` <-> `{right}`"
        )

    checkout_block = (
        "\n".join(checkout_lines) if checkout_lines else "  # No remote repos to check out"
    )
    contracts_block = "\n".join(contract_lines) if contract_lines else "- No checks configured"
    repos_list = ", ".join(repo_ids) if repo_ids else "none"

    return f"""---
description: Cross-repo contract drift review powered by repo-drift
checkout:
{checkout_block}
tools:
  - github
safe-outputs:
  - add-comment
---

# Cross-Repo Contract Drift Review

You are reviewing a pull request for potential cross-repo contract drift.

## Context

This workspace contains **{len(config.repos)} repo(s)**: {repos_list}.

These repos share contract files that must stay in sync. When a PR modifies
a contract file in one repo, the corresponding file in sibling repos may
need updating too.

## Architecture

Read the architecture map for full context:

```
cat {architecture_path}
```

## Contract Configuration

Read the drift config:

```
cat {config_path}
```

## Monitored Contracts

{contracts_block}

## Your Task

1. **Read the PR diff** to identify which files changed
2. **Check each changed file** against the contract pairs listed above
3. For each affected contract:
   - Read the **source file** (the changed contract)
   - Read the **counterpart file** (the other side of the pair)
   - Assess whether the change would cause drift or breakage
4. **Post a review comment** summarizing:
   - Which contracts are affected
   - The risk level (based on severity in the config)
   - Whether consumers would break
   - Recommended actions (update the counterpart, coordinate with the
     owning team, etc.)

If **no contract files** are affected by this PR, post a brief comment
confirming that no cross-repo drift risk was detected.

## Output Format

Use `add-comment` to post your findings. Structure the comment as:

```
### Cross-Repo Drift Review

**Status**: [No drift risk / Drift risk detected]

[If drift detected:]

| Contract | Severity | Changed File | Counterpart | Risk |
|----------|----------|-------------|-------------|------|
| ... | ... | ... | ... | ... |

**Recommendations:**
- ...
```
"""


def _url_to_slug(url: str) -> str:
    """Convert a Git URL to an org/repo slug.

    ``https://github.com/org/repo.git`` -> ``org/repo``
    ``git@github.com:org/repo.git`` -> ``org/repo``
    """
    slug = url.rstrip("/")
    if slug.endswith(".git"):
        slug = slug[:-4]
    # SSH format: git@github.com:org/repo
    if slug.startswith("git@github.com:"):
        return slug.split("git@github.com:", 1)[1]
    if "github.com/" in slug:
        return slug.split("github.com/", 1)[1]
    return slug
