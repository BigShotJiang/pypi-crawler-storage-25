from __future__ import annotations

from pathlib import Path

from .types import CheckResult


def write_markdown_report(path: Path, results: list[CheckResult]) -> None:
    lines = [
        "# Repo Drift Report",
        "",
        "| Check | Type | Severity | Status | Summary |",
        "|---|---|---|---|---|",
    ]

    for item in results:
        safe_summary = item.summary.replace("|", "\\|")
        lines.append(
            f"| `{item.check_id}` | `{item.check_type}` | {item.severity} | **{item.status.upper()}** | {safe_summary} |"
        )
    lines.append("")
    for item in results:
        lines.append(f"## {item.check_id}")
        lines.append("")
        lines.append(f"- Type: `{item.check_type}`")
        lines.append(f"- Severity: `{item.severity}`")
        lines.append(f"- Status: `{item.status}`")
        lines.append(f"- Summary: {item.summary}")
        lines.append("- Evidence:")
        if not item.evidence:
            lines.append("  - (none)")
        else:
            for ev in item.evidence:
                suffix = f" [path={ev.path}]" if ev.path else ""
                lines.append(f"  - {ev.kind}: {ev.message}{suffix}")
        lines.append("")

    path.write_text("\n".join(lines) + "\n")
