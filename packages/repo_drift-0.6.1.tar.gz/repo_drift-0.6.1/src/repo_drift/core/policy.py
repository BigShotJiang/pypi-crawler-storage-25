from __future__ import annotations

from .types import CheckResult, PolicyRule


def should_fail(results: list[CheckResult], rules: list[PolicyRule]) -> bool:
    if not rules:
        return any(item.status == "fail" for item in results)

    for result in results:
        for rule in rules:
            if result.severity == rule.severity and result.status == rule.status:
                return True
    return False
