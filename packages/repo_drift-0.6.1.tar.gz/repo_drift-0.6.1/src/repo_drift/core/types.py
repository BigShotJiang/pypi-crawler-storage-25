from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class RepoConfig:
    id: str
    url: str
    ref_policy: str
    snapshot_path: str
    custom_ref: str | None = None


@dataclass(slots=True)
class CheckConfig:
    id: str
    type: str
    severity: str
    params: dict[str, Any]


@dataclass(slots=True)
class PolicyRule:
    severity: str
    status: str


@dataclass(slots=True)
class ProjectConfig:
    version: int
    repos: list[RepoConfig]
    checks: list[CheckConfig]
    fail_on: list[PolicyRule] = field(default_factory=list)


@dataclass(slots=True)
class Evidence:
    kind: str
    message: str
    path: str | None = None
    left: str | None = None
    right: str | None = None


@dataclass(slots=True)
class CheckResult:
    check_id: str
    check_type: str
    status: str
    severity: str
    summary: str
    evidence: list[Evidence]
    artifacts: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "check_id": self.check_id,
            "check_type": self.check_type,
            "status": self.status,
            "severity": self.severity,
            "summary": self.summary,
            "evidence": [
                {
                    "kind": item.kind,
                    "message": item.message,
                    "path": item.path,
                    "left": item.left,
                    "right": item.right,
                }
                for item in self.evidence
            ],
            "artifacts": self.artifacts,
            "metadata": self.metadata,
        }
