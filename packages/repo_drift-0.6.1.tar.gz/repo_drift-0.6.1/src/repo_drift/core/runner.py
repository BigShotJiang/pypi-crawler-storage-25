from __future__ import annotations

from pathlib import Path

from repo_drift.checks import run_file_pair_hash_check, run_json_schema_compat_check
from repo_drift.core.types import CheckConfig, CheckResult


def run_check(check: CheckConfig, root: Path) -> CheckResult:
    if check.type == "file_pair_hash":
        return run_file_pair_hash_check(check, root)
    if check.type == "json_schema_compat":
        return run_json_schema_compat_check(check, root)

    return CheckResult(
        check_id=check.id,
        check_type=check.type,
        status="error",
        severity=check.severity,
        summary=f"Unsupported check type: {check.type}",
        evidence=[],
    )


def run_checks(checks: list[CheckConfig], root: Path) -> list[CheckResult]:
    return [run_check(check, root) for check in checks]
