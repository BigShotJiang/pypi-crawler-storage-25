"""GitHub Copilot API client for chat completions."""

from __future__ import annotations

import contextlib
import json
import logging
import ssl
import urllib.error
import urllib.request

from .client import (
    CLAUDE_THINKING_BUDGETS,
    LLMClient,
    LLMResponse,
    is_claude_model,
    is_o_series_model,
)

_logger = logging.getLogger(__name__)

# GitHub Copilot chat completions endpoint.
# Works with both individual and organization Copilot API keys.
_DEFAULT_BASE_URL = "https://api.githubcopilot.com"
_CHAT_COMPLETIONS_PATH = "/chat/completions"


def _make_ssl_context() -> ssl.SSLContext | None:
    """Build an SSL context that works on macOS framework Python installs.

    Returns ``None`` (= use the default) when the system certs are fine.
    When the default context fails to load certs (common on macOS Python.org
    framework builds that haven't run ``Install Certificates.command``),
    falls back to ``certifi`` if available, or a last-resort unverified
    context with a warning.
    """
    # Try the default context first.
    ctx = ssl.create_default_context()
    with contextlib.suppress(Exception):
        ctx.load_default_certs()

    # Quick check: does the context have any CA certs loaded?
    stats = ctx.cert_store_stats()
    if stats.get("x509_ca", 0) > 0:
        return None  # default context is fine

    # Try certifi bundle (stdlib-only project, but user may have it).
    try:
        import certifi  # type: ignore[import-untyped]

        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        pass

    raise RuntimeError(
        "SSL: No system CA certificates found and certifi is not installed. "
        "TLS verification cannot be disabled. Run "
        "'/Applications/Python 3.XX/Install Certificates.command' or "
        "'pip install certifi' to fix this."
    )


class CopilotError(RuntimeError):
    """Raised when a Copilot API call fails."""


class CopilotClient(LLMClient):
    """LLM client backed by GitHub Copilot's chat completions API.

    The ``api_key`` must be a **Copilot session token** (``tid=…``), not a
    raw GitHub OAuth token or PAT. Use
    :func:`repo_drift.llm.copilot_auth.exchange_token` or
    :func:`repo_drift.llm.copilot_auth.obtain_copilot_token` to get one.

    Args:
        api_key: Copilot session token.
        model: Model identifier (e.g. "claude-sonnet-4.6", "gpt-4o").
        base_url: Override the API base URL.
        timeout: HTTP request timeout in seconds.
    """

    # Headers that api.githubcopilot.com requires to identify the caller.
    # Values match those used by the VS Code Copilot Chat extension.
    _EDITOR_VERSION = "vscode/1.104.1"
    _EDITOR_PLUGIN_VERSION = "copilot-chat/0.26.7"
    _COPILOT_INTEGRATION_ID = "vscode-chat"

    def __init__(
        self,
        api_key: str,
        model: str = "claude-sonnet-4.6",
        base_url: str = _DEFAULT_BASE_URL,
        timeout: int = 120,
        thinking_effort: str | None = None,
    ):
        super().__init__(model=model, thinking_effort=thinking_effort)
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._ssl_context = _make_ssl_context()

    def complete(self, system: str, user: str) -> LLMResponse:
        """Send a chat completion request to GitHub Copilot.

        Args:
            system: System prompt.
            user: User message.

        Returns:
            LLMResponse with the assistant reply.

        Raises:
            CopilotError: On HTTP or parsing failure.
        """
        url = f"{self._base_url}{_CHAT_COMPLETIONS_PATH}"

        payload: dict[str, object] = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        }

        # Adjust payload based on model type and thinking effort.
        if is_o_series_model(self.model):
            # o-series models: omit temperature and response_format.
            if self.thinking_effort:
                payload["reasoning_effort"] = self.thinking_effort
        elif is_claude_model(self.model) and self.thinking_effort:
            # Claude with thinking: keep temperature, omit response_format,
            # add thinking budget.
            payload["temperature"] = 0.1
            budget = CLAUDE_THINKING_BUDGETS.get(self.thinking_effort, 4096)
            payload["thinking"] = {"type": "enabled", "budget_tokens": budget}
        else:
            # Normal model (or thinking model without effort specified).
            payload["temperature"] = 0.1
            payload["response_format"] = {"type": "json_object"}
            if self.thinking_effort:
                _logger.warning(
                    "Thinking effort '%s' ignored for model '%s' (not a Claude or o-series model)",
                    self.thinking_effort,
                    self.model,
                )

        body = json.dumps(payload).encode()
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Editor-Version": self._EDITOR_VERSION,
            "Editor-Plugin-Version": self._EDITOR_PLUGIN_VERSION,
            "Copilot-Integration-Id": self._COPILOT_INTEGRATION_ID,
        }

        req = urllib.request.Request(url, data=body, headers=headers, method="POST")

        _logger.debug("Copilot request: model=%s url=%s", self.model, url)

        try:
            open_kwargs: dict[str, object] = {"timeout": self._timeout}
            if self._ssl_context is not None:
                open_kwargs["context"] = self._ssl_context
            with urllib.request.urlopen(req, **open_kwargs) as resp:  # type: ignore[arg-type]
                raw = json.loads(resp.read().decode())
        except urllib.error.HTTPError as exc:
            error_body = ""
            with contextlib.suppress(Exception):
                error_body = exc.read().decode()
            raise CopilotError(
                f"Copilot API returned HTTP {exc.code} for model '{self.model}': {error_body}"
            ) from exc
        except urllib.error.URLError as exc:
            raise CopilotError(
                f"Copilot API request failed for model '{self.model}': {exc.reason}"
            ) from exc

        choices = raw.get("choices", [])
        if not choices:
            raise CopilotError(f"Copilot API returned no choices: {json.dumps(raw)}")

        content = choices[0].get("message", {}).get("content", "")
        usage = raw.get("usage", {})
        model_used = raw.get("model", self.model)

        self._track_usage(usage)

        return LLMResponse(content=content, model=model_used, usage=usage)

    def list_models(self) -> list[dict[str, str]]:
        """Query the models endpoint and return available model info.

        Returns a list of dicts, each with at least an ``"id"`` key.

        Raises:
            CopilotError: On HTTP or parsing failure.
        """
        url = f"{self._base_url}/models"

        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Accept": "application/json",
            "Editor-Version": self._EDITOR_VERSION,
            "Editor-Plugin-Version": self._EDITOR_PLUGIN_VERSION,
            "Copilot-Integration-Id": self._COPILOT_INTEGRATION_ID,
        }

        req = urllib.request.Request(url, headers=headers, method="GET")

        _logger.debug("Copilot list models: url=%s", url)

        try:
            open_kwargs: dict[str, object] = {"timeout": self._timeout}
            if self._ssl_context is not None:
                open_kwargs["context"] = self._ssl_context
            with urllib.request.urlopen(req, **open_kwargs) as resp:  # type: ignore[arg-type]
                raw = json.loads(resp.read().decode())
        except urllib.error.HTTPError as exc:
            error_body = ""
            with contextlib.suppress(Exception):
                error_body = exc.read().decode()
            raise CopilotError(
                f"Copilot models API returned HTTP {exc.code}: {error_body}"
            ) from exc
        except urllib.error.URLError as exc:
            raise CopilotError(f"Copilot models request failed: {exc.reason}") from exc

        # OpenAI-compatible format: {"data": [{"id": "...", ...}, ...]}
        data = raw.get("data", [])
        models: list[dict[str, str]] = []
        for entry in data:
            model_info: dict[str, str] = {"id": entry.get("id", "")}
            # Include optional metadata if present.
            for key in ("name", "version", "object", "owned_by"):
                val = entry.get(key)
                if val:
                    model_info[key] = str(val)
            models.append(model_info)
        return models
