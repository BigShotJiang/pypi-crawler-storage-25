"""GitHub Copilot OAuth device flow authentication.

Implements the device authorization grant flow to obtain a Copilot API token.
Uses only stdlib (urllib, json, time). The token is cached in
``~/.config/repo-drift/copilot-token.json`` so the user only has to authorize
once per session.

Flow:
1. POST to https://github.com/login/device/code with client_id
2. User visits https://github.com/login/device and enters the user_code
3. Poll https://github.com/login/oauth/access_token until authorized → ``gho_`` token
4. Exchange the ``gho_`` token for a Copilot session token via
   ``https://api.github.com/copilot_internal/v2/token``
5. Use the session token (``tid=…``) for api.githubcopilot.com calls
"""

from __future__ import annotations

import contextlib
import json
import logging
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

_logger = logging.getLogger(__name__)

# GitHub OAuth app client ID for Copilot CLI / VS Code extensions.
# This is the public client_id used by the official Copilot integrations.
_COPILOT_CLIENT_ID = "Iv1.b507a08c87ecfe98"

_DEVICE_CODE_URL = "https://github.com/login/device/code"
_ACCESS_TOKEN_URL = "https://github.com/login/oauth/access_token"

# Endpoint to exchange a GitHub OAuth token for a Copilot session token.
# The session token (``tid=…``) is what api.githubcopilot.com actually accepts.
_COPILOT_TOKEN_URL = "https://api.github.com/copilot_internal/v2/token"

_TOKEN_CACHE_DIR = Path.home() / ".config" / "repo-drift"
_TOKEN_CACHE_FILE = _TOKEN_CACHE_DIR / "copilot-token.json"


def _post_form(url: str, data: dict[str, str]) -> dict[str, str]:
    """POST form-encoded data, return parsed form response."""
    body = urllib.parse.urlencode(data).encode()
    req = urllib.request.Request(url, data=body, method="POST")
    req.add_header("Accept", "application/json")

    with urllib.request.urlopen(req, timeout=30) as resp:
        raw = json.loads(resp.read().decode())

    # GitHub returns JSON when Accept: application/json is set.
    if isinstance(raw, dict):
        return {k: str(v) for k, v in raw.items()}
    return {}


def _load_cached_token() -> str | None:
    """Load a previously cached Copilot session token if it exists and hasn't expired."""
    if not _TOKEN_CACHE_FILE.is_file():
        return None

    try:
        data = json.loads(_TOKEN_CACHE_FILE.read_text())
        token = data.get("session_token", "")
        expires_at = data.get("expires_at", 0)
        if token and time.time() < expires_at:
            _logger.debug(
                "Using cached Copilot session token (expires in %d s)",
                int(expires_at - time.time()),
            )
            return token
    except (json.JSONDecodeError, OSError, KeyError):
        _logger.debug("Failed to load cached token, will re-authenticate")

    return None


def _cache_token(session_token: str, expires_at: float) -> None:
    """Cache the session token to disk."""
    try:
        _TOKEN_CACHE_DIR.mkdir(parents=True, exist_ok=True)
        data = {
            "session_token": session_token,
            "expires_at": expires_at,
        }
        _TOKEN_CACHE_FILE.write_text(json.dumps(data))
        _TOKEN_CACHE_FILE.chmod(0o600)
    except OSError:
        _logger.debug("Failed to cache Copilot token", exc_info=True)


def _exchange_for_session_token(github_token: str) -> tuple[str, float]:
    """Exchange a GitHub OAuth token for a Copilot session token.

    Args:
        github_token: A GitHub OAuth token (``gho_…``) or PAT.

    Returns:
        Tuple of (session_token, expires_at_unix_timestamp).

    Raises:
        RuntimeError: If the exchange fails.
    """
    req = urllib.request.Request(_COPILOT_TOKEN_URL, method="GET")
    req.add_header("Authorization", f"token {github_token}")
    req.add_header("Accept", "application/json")
    # The token exchange endpoint requires the same integration headers
    # as api.githubcopilot.com to identify the caller as an approved client.
    req.add_header("Editor-Version", "vscode/1.104.1")
    req.add_header("Editor-Plugin-Version", "copilot-chat/0.26.7")
    req.add_header("Copilot-Integration-Id", "vscode-chat")

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode())
    except urllib.error.HTTPError as exc:
        error_body = ""
        with contextlib.suppress(Exception):
            error_body = exc.read().decode()
        raise RuntimeError(
            f"Copilot token exchange failed (HTTP {exc.code}): {error_body}"
        ) from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Copilot token exchange request failed: {exc.reason}") from exc

    session_token = data.get("token", "")
    if not session_token:
        raise RuntimeError(f"Token exchange returned no session token: {data}")

    # The response includes an ``expires_at`` Unix timestamp.
    expires_at = float(data.get("expires_at", time.time() + 1800))

    _logger.debug("Copilot session token obtained (expires_at=%.0f)", expires_at)
    return session_token, expires_at


def obtain_copilot_token() -> str:
    """Obtain a Copilot session token via the OAuth device flow.

    1. Checks for a cached session token first.
    2. If none, starts the device flow: prints a URL and user code,
       then polls until the user authorizes.
    3. Exchanges the resulting ``gho_`` token for a Copilot session token.

    Returns:
        A Copilot session token suitable for api.githubcopilot.com.

    Raises:
        RuntimeError: If the flow fails or the user declines.
    """
    # Check cache first.
    cached = _load_cached_token()
    if cached:
        return cached

    # Step 1: Request device code.
    _logger.info("Starting GitHub Copilot device authorization flow...")
    try:
        device_resp = _post_form(
            _DEVICE_CODE_URL,
            {
                "client_id": _COPILOT_CLIENT_ID,
                "scope": "copilot",
            },
        )
    except Exception as exc:
        raise RuntimeError(f"Failed to start device flow: {exc}") from exc

    device_code = device_resp.get("device_code", "")
    user_code = device_resp.get("user_code", "")
    verification_uri = device_resp.get("verification_uri", "https://github.com/login/device")
    interval = int(device_resp.get("interval", "5"))
    expires_in = int(device_resp.get("expires_in", "900"))

    if not device_code or not user_code:
        raise RuntimeError(f"Device flow returned unexpected response: {device_resp}")

    # Step 2: Prompt user.
    print()
    print("=== GitHub Copilot Authorization ===")
    print()
    print(f"  1. Open: {verification_uri}")
    print(f"  2. Enter code: {user_code}")
    print()
    print("Waiting for authorization...")
    print()

    # Step 3: Poll for OAuth token.
    deadline = time.time() + expires_in
    while time.time() < deadline:
        time.sleep(interval)

        try:
            token_resp = _post_form(
                _ACCESS_TOKEN_URL,
                {
                    "client_id": _COPILOT_CLIENT_ID,
                    "device_code": device_code,
                    "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                },
            )
        except (urllib.error.URLError, ValueError, OSError):
            continue

        error = token_resp.get("error", "")
        if error == "authorization_pending":
            continue
        if error == "slow_down":
            interval += 5
            continue
        if error == "expired_token":
            raise RuntimeError("Device code expired. Please try again.")
        if error == "access_denied":
            raise RuntimeError("Authorization was denied by the user.")
        if error:
            raise RuntimeError(f"OAuth error: {error} - {token_resp.get('error_description', '')}")

        oauth_token = token_resp.get("access_token", "")
        if oauth_token:
            print("OAuth authorization successful! Exchanging for Copilot session token...")
            print()

            # Step 4: Exchange OAuth token for Copilot session token.
            session_token, expires_at = _exchange_for_session_token(oauth_token)
            _cache_token(session_token, expires_at)

            print("Copilot session token obtained!")
            print()
            return session_token

    raise RuntimeError("Device code expired before authorization completed.")


def exchange_token(github_token: str) -> str:
    """Exchange a GitHub token (PAT or OAuth) for a Copilot session token.

    This is the public entry point for callers that already have a GitHub
    token (e.g. from ``COPILOT_API_KEY`` env var) and need to convert it
    into a session token that ``api.githubcopilot.com`` will accept.

    The session token is cached; subsequent calls with the same input will
    return the cached value until it expires.

    Returns:
        A Copilot session token.

    Raises:
        RuntimeError: If the exchange fails.
    """
    cached = _load_cached_token()
    if cached:
        return cached

    session_token, expires_at = _exchange_for_session_token(github_token)
    _cache_token(session_token, expires_at)
    return session_token
