"""OpenAI API client for chat completions.

Uses only stdlib (urllib.request). Compatible with the standard OpenAI
chat completions endpoint at api.openai.com/v1/chat/completions.
"""

from __future__ import annotations

import contextlib
import json
import logging
import urllib.error
import urllib.request

from .client import (
    CLAUDE_THINKING_BUDGETS,
    LLMClient,
    LLMResponse,
    is_claude_model,
    is_o_series_model,
)
from .copilot import _make_ssl_context

_logger = logging.getLogger(__name__)

_DEFAULT_BASE_URL = "https://api.openai.com/v1"
_CHAT_COMPLETIONS_PATH = "/chat/completions"


class OpenAIError(RuntimeError):
    """Raised when an OpenAI API call fails."""


class OpenAIClient(LLMClient):
    """LLM client backed by the OpenAI chat completions API.

    Args:
        api_key: OpenAI API key (sk-...).
        model: Model identifier (e.g. "claude-sonnet-4.6", "gpt-4o").
        base_url: Override the API base URL (for Azure, etc.).
        timeout: HTTP request timeout in seconds.
    """

    def __init__(
        self,
        api_key: str,
        model: str = "claude-sonnet-4.6",
        base_url: str = _DEFAULT_BASE_URL,
        timeout: int = 120,
        thinking_effort: str | None = None,
    ):
        super().__init__(model=model, thinking_effort=thinking_effort)
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._ssl_context = _make_ssl_context()

    def complete(self, system: str, user: str) -> LLMResponse:
        """Send a chat completion request to OpenAI.

        Args:
            system: System prompt.
            user: User message.

        Returns:
            LLMResponse with the assistant reply.

        Raises:
            OpenAIError: On HTTP or parsing failure.
        """
        url = f"{self._base_url}{_CHAT_COMPLETIONS_PATH}"

        payload: dict[str, object] = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        }

        # Adjust payload based on model type and thinking effort.
        if is_o_series_model(self.model):
            # o-series models: omit temperature and response_format.
            if self.thinking_effort:
                payload["reasoning_effort"] = self.thinking_effort
        elif is_claude_model(self.model) and self.thinking_effort:
            # Claude with thinking: keep temperature, omit response_format,
            # add thinking budget.
            payload["temperature"] = 0.1
            budget = CLAUDE_THINKING_BUDGETS.get(self.thinking_effort, 4096)
            payload["thinking"] = {"type": "enabled", "budget_tokens": budget}
        else:
            # Normal model (or thinking model without effort specified).
            payload["temperature"] = 0.1
            payload["response_format"] = {"type": "json_object"}
            if self.thinking_effort:
                _logger.warning(
                    "Thinking effort '%s' ignored for model '%s' (not a Claude or o-series model)",
                    self.thinking_effort,
                    self.model,
                )

        body = json.dumps(payload).encode()
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

        req = urllib.request.Request(url, data=body, headers=headers, method="POST")

        _logger.debug("OpenAI request: model=%s url=%s", self.model, url)

        try:
            open_kwargs: dict[str, object] = {"timeout": self._timeout}
            if self._ssl_context is not None:
                open_kwargs["context"] = self._ssl_context
            with urllib.request.urlopen(req, **open_kwargs) as resp:  # type: ignore[arg-type]
                raw = json.loads(resp.read().decode())
        except urllib.error.HTTPError as exc:
            error_body = ""
            with contextlib.suppress(Exception):
                error_body = exc.read().decode()
            raise OpenAIError(
                f"OpenAI API returned HTTP {exc.code} for model '{self.model}': {error_body}"
            ) from exc
        except urllib.error.URLError as exc:
            raise OpenAIError(
                f"OpenAI API request failed for model '{self.model}': {exc.reason}"
            ) from exc

        choices = raw.get("choices", [])
        if not choices:
            raise OpenAIError(f"OpenAI API returned no choices: {json.dumps(raw)}")

        content = choices[0].get("message", {}).get("content", "")
        usage = raw.get("usage", {})
        model_used = raw.get("model", self.model)

        self._track_usage(usage)

        return LLMResponse(content=content, model=model_used, usage=usage)

    def list_models(self) -> list[dict[str, str]]:
        """Query the models endpoint and return available model info.

        Returns a list of dicts, each with at least an ``"id"`` key.

        Raises:
            OpenAIError: On HTTP or parsing failure.
        """
        url = f"{self._base_url}/models"

        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Accept": "application/json",
        }

        req = urllib.request.Request(url, headers=headers, method="GET")

        _logger.debug("OpenAI list models: url=%s", url)

        try:
            open_kwargs: dict[str, object] = {"timeout": self._timeout}
            if self._ssl_context is not None:
                open_kwargs["context"] = self._ssl_context
            with urllib.request.urlopen(req, **open_kwargs) as resp:  # type: ignore[arg-type]
                raw = json.loads(resp.read().decode())
        except urllib.error.HTTPError as exc:
            error_body = ""
            with contextlib.suppress(Exception):
                error_body = exc.read().decode()
            raise OpenAIError(f"OpenAI models API returned HTTP {exc.code}: {error_body}") from exc
        except urllib.error.URLError as exc:
            raise OpenAIError(f"OpenAI models request failed: {exc.reason}") from exc

        data = raw.get("data", [])
        models: list[dict[str, str]] = []
        for entry in data:
            model_info: dict[str, str] = {"id": entry.get("id", "")}
            for key in ("name", "version", "object", "owned_by"):
                val = entry.get(key)
                if val:
                    model_info[key] = str(val)
            models.append(model_info)
        return models
