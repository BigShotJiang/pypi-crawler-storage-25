from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from repo_drift.init.types import InitResult

from repo_drift.core import (
    ConfigError,
    SnapshotError,
    ensure_snapshot,
    load_project_config,
    should_fail,
    write_markdown_report,
)
from repo_drift.core.runner import run_checks
from repo_drift.core.types import ProjectConfig
from repo_drift.discover.catalog import DiscoverResult
from repo_drift.llm.client import LLMClient


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Repo drift checker")
    parser.add_argument("-v", "--verbose", action="store_true", help="Enable debug logging")
    sub = parser.add_subparsers(dest="command", required=True)

    # ── snapshot ──────────────────────────────────────────────────────
    snap = sub.add_parser("snapshot", help="Create/update branch-pinned repo snapshots")
    snap.add_argument("--config", required=True)
    snap.add_argument("--workspace", default=".")

    # ── run ───────────────────────────────────────────────────────────
    run = sub.add_parser("run", help="Run drift checks")
    run.add_argument("--config", required=True)
    run.add_argument("--snapshot", action="store_true", help="Refresh snapshots before checks")
    run.add_argument("--output-json", default="generated/report.json")
    run.add_argument("--output-md", default="generated/report.md")
    run.add_argument("--workspace", default=".")

    # ── init ──────────────────────────────────────────────────────────
    init = sub.add_parser(
        "init",
        help="Analyze repos, map architecture, and generate drift config + ARCHITECTURE.md",
    )
    init.add_argument(
        "--repos",
        nargs="+",
        required=True,
        metavar="URL",
        help="Git repo URLs (e.g. https://github.com/org/repo.git or org/repo)",
    )
    init.add_argument(
        "--api-key",
        default=None,
        help="LLM API key (or set COPILOT_API_KEY / OPENAI_API_KEY env var)",
    )
    init.add_argument(
        "--provider",
        default=None,
        choices=["copilot", "openai"],
        help="LLM provider (default: auto-detect from key/env vars, falls back to copilot)",
    )
    init.add_argument(
        "--model",
        action="append",
        dest="models",
        metavar="MODEL",
        help="Model(s) for analysis. Repeat for consensus (e.g. --model gpt-4o --model claude-sonnet-4.6). Default: claude-sonnet-4.6",
    )
    init.add_argument(
        "--models",
        default=None,
        dest="models_csv",
        metavar="MODELS",
        help="Comma-separated model list for consensus (e.g. --models gpt-4o,claude-sonnet-4.6). Alternative to repeating --model.",
    )
    init.add_argument(
        "--workspace",
        default=".",
        help="Workspace root for cloning repos (default: .)",
    )
    init.add_argument(
        "--output-config",
        default=".repo-drift.json",
        metavar="PATH",
        help="Config output path (default: .repo-drift.json)",
    )
    init.add_argument(
        "--output-arch",
        default="ARCHITECTURE.md",
        metavar="PATH",
        help="Architecture map output path (default: ARCHITECTURE.md)",
    )
    init.add_argument(
        "--overrides",
        default=None,
        metavar="PATH",
        help="Path to overrides JSON (default: .repo-drift-overrides.json if it exists)",
    )
    init.add_argument(
        "--approve",
        action="store_true",
        help="Skip interactive review and write files directly",
    )
    init.add_argument(
        "--no-snapshot",
        action="store_true",
        help="Skip cloning; assume repos already present in workspace",
    )
    init.add_argument(
        "--ref-policy",
        default="develop_or_main",
        choices=["develop_or_main", "develop", "main"],
        help="Default branch resolution policy (default: develop_or_main)",
    )
    init.add_argument(
        "--orchestrator",
        default=None,
        metavar="MODEL",
        help="Orchestrator model for final synthesis of multi-model consensus results (e.g. --orchestrator gpt-5.4^high). Supports model^effort syntax.",
    )

    # ── models ────────────────────────────────────────────────────────
    models = sub.add_parser(
        "models",
        help="List available models for the configured LLM provider",
    )
    models.add_argument(
        "--api-key",
        default=None,
        help="LLM API key (or set COPILOT_API_KEY / OPENAI_API_KEY env var)",
    )
    models.add_argument(
        "--provider",
        default=None,
        choices=["copilot", "openai"],
        help="LLM provider (default: auto-detect from key/env vars, falls back to copilot)",
    )

    # ── check ─────────────────────────────────────────────────────────
    chk = sub.add_parser(
        "check",
        help="Assess whether changed files affect contracts (CI gate)",
    )
    chk.add_argument(
        "--config",
        required=True,
        metavar="PATH",
        help="Path to .repo-drift.json",
    )
    chk.add_argument(
        "--repo",
        default=None,
        metavar="REPO_ID",
        help="Repo ID where the PR is opened (auto-detected if config has one repo)",
    )
    chk.add_argument(
        "--files",
        nargs="*",
        metavar="FILE",
        help="Changed files (relative to repo root). If omitted, reads from stdin.",
    )
    chk.add_argument(
        "--output-json",
        default=None,
        metavar="PATH",
        help="Write JSON verdict to file (default: print to stdout)",
    )

    # ── generate-aw ──────────────────────────────────────────────────
    gaw = sub.add_parser(
        "generate-aw",
        help="Generate a GitHub Agentic Workflows (gh-aw) template for cross-repo PR review",
    )
    gaw.add_argument(
        "--config",
        required=True,
        metavar="PATH",
        help="Path to .repo-drift.json",
    )
    gaw.add_argument(
        "--output",
        default=None,
        metavar="PATH",
        help="Write template to file (default: print to stdout)",
    )
    gaw.add_argument(
        "--architecture-path",
        default="ARCHITECTURE.md",
        metavar="PATH",
        help="Relative path to ARCHITECTURE.md in the workspace (default: ARCHITECTURE.md)",
    )
    gaw.add_argument(
        "--config-path",
        default=".repo-drift.json",
        metavar="PATH",
        help="Relative path to .repo-drift.json in the workspace (default: .repo-drift.json)",
    )

    # ── discover ──────────────────────────────────────────────────────
    disc = sub.add_parser(
        "discover",
        help="Auto-discover contracts across repos and generate drift config",
    )
    disc.add_argument(
        "--repos",
        nargs="+",
        required=True,
        metavar="URL",
        help="Git repo URLs (e.g. https://github.com/org/repo.git or org/repo)",
    )
    disc.add_argument(
        "--api-key",
        default=None,
        help="LLM API key (or set COPILOT_API_KEY / OPENAI_API_KEY env var)",
    )
    disc.add_argument(
        "--provider",
        default=None,
        choices=["copilot", "openai"],
        help="LLM provider (default: auto-detect from key/env vars, falls back to copilot)",
    )
    disc.add_argument(
        "--model",
        action="append",
        dest="models",
        metavar="MODEL",
        help="Model(s) for discovery. Repeat for consensus (e.g. --model gpt-4o --model claude-sonnet-4.6). Default: claude-sonnet-4.6",
    )
    disc.add_argument(
        "--models",
        default=None,
        dest="models_csv",
        metavar="MODELS",
        help="Comma-separated model list for consensus (e.g. --models gpt-4o,claude-sonnet-4.6). Alternative to repeating --model.",
    )
    disc.add_argument(
        "--workspace",
        default=".",
        help="Workspace root for cloning repos (default: .)",
    )
    disc.add_argument(
        "--output",
        default=None,
        metavar="PATH",
        help="Write generated config to file (default: print to stdout)",
    )
    disc.add_argument(
        "--approve",
        action="store_true",
        help="Skip interactive review and write config directly",
    )
    disc.add_argument(
        "--no-snapshot",
        action="store_true",
        help="Skip cloning; assume repos already present in workspace",
    )
    disc.add_argument(
        "--ref-policy",
        default="develop_or_main",
        choices=["develop_or_main", "develop", "main"],
        help="Default branch resolution policy (default: develop_or_main)",
    )
    disc.add_argument(
        "--orchestrator",
        default=None,
        metavar="MODEL",
        help="Orchestrator model for final synthesis of multi-model consensus results (e.g. --orchestrator gpt-5.4^high). Supports model^effort syntax.",
    )

    return parser.parse_args()


def _load(config_path: Path) -> ProjectConfig:
    try:
        return load_project_config(config_path)
    except ConfigError as exc:
        raise SystemExit(f"Config error: {exc}") from exc


def _run_snapshot(config_path: Path, workspace_root: Path) -> list[dict[str, str]]:
    root = workspace_root.resolve()
    project = _load(config_path)

    snapshots: list[dict[str, str]] = []
    for repo in project.repos:
        try:
            result = ensure_snapshot(repo, root)
        except SnapshotError as exc:
            raise SystemExit(f"Snapshot failure for {repo.id}: {exc}") from exc
        snapshots.append(
            {
                "repo_id": result.repo_id,
                "branch": result.branch,
                "commit": result.commit,
                "path": result.path,
            }
        )
    return snapshots


def _command_snapshot(config_path: Path, workspace_root: Path) -> None:
    snapshots = _run_snapshot(config_path, workspace_root)
    print(json.dumps({"snapshots": snapshots}, indent=2))


def _command_run(
    config_path: Path,
    workspace_root: Path,
    with_snapshot: bool,
    output_json: Path,
    output_md: Path,
) -> None:
    root = workspace_root.resolve()
    project = _load(config_path)

    snapshots: list[dict[str, str]] = []
    if with_snapshot:
        snapshots = _run_snapshot(config_path, root)

    results = run_checks(project.checks, root)

    payload = {
        "config": str(config_path),
        "snapshots": snapshots,
        "results": [item.to_dict() for item in results],
        "summary": {
            "total": len(results),
            "pass": sum(1 for item in results if item.status == "pass"),
            "warn": sum(1 for item in results if item.status == "warn"),
            "fail": sum(1 for item in results if item.status == "fail"),
            "error": sum(1 for item in results if item.status == "error"),
        },
    }

    output_json = (root / output_json).resolve()
    output_md = (root / output_md).resolve()
    output_json.parent.mkdir(parents=True, exist_ok=True)
    output_md.parent.mkdir(parents=True, exist_ok=True)

    output_json.write_text(json.dumps(payload, indent=2) + "\n")
    write_markdown_report(output_md, results)

    print(f"Wrote JSON report: {output_json}")
    print(f"Wrote Markdown report: {output_md}")

    if should_fail(results, project.fail_on):
        raise SystemExit(1)


def _normalize_repo_url(url_or_slug: str) -> str:
    """Expand 'org/repo' shorthand to full GitHub URL.

    Local filesystem paths (absolute or relative starting with ./) are
    returned unchanged so that ``_build_repo_configs`` can detect them.
    """
    # Absolute path or explicit relative path — leave as-is.
    if url_or_slug.startswith("/") or url_or_slug.startswith("./") or url_or_slug.startswith("~"):
        return url_or_slug
    if url_or_slug.startswith("https://") or url_or_slug.startswith("git@"):
        return url_or_slug
    # Assume GitHub shorthand: org/repo
    slug = url_or_slug.rstrip("/")
    if not slug.endswith(".git"):
        slug += ".git"
    return f"https://github.com/{slug}"


def _resolve_api_key_for_provider(provider: str, cli_key: str | None) -> str:
    """Resolve API key for a specific provider.

    For ``copilot`` provider: tries env vars (exchanging for a session token
    if needed), then falls back to the OAuth device flow.
    For ``openai`` provider: tries env vars, errors if not found.
    """
    from repo_drift.llm.copilot_auth import exchange_token, obtain_copilot_token

    # Explicit CLI key always wins.
    if cli_key:
        if provider == "copilot":
            # Must exchange for a session token — raw GitHub tokens are
            # rejected by api.githubcopilot.com.
            try:
                return exchange_token(cli_key)
            except RuntimeError:
                logging.getLogger(__name__).warning(
                    "Token exchange failed for --api-key value; falling back to device flow"
                )
                return obtain_copilot_token()
        return cli_key

    if provider == "openai":
        for env_var in ("OPENAI_API_KEY", "LLM_API_KEY"):
            val = os.getenv(env_var)
            if val and val.strip():
                return val.strip()
        raise SystemExit("No OpenAI API key found. Use --api-key or set OPENAI_API_KEY env var.")

    # provider == "copilot"
    for env_var in ("COPILOT_API_KEY", "GITHUB_COPILOT_KEY", "LLM_API_KEY"):
        val = os.getenv(env_var)
        if val and val.strip():
            # Exchange the raw GitHub token for a Copilot session token.
            # If this fails (e.g. PAT without Copilot scope → 404),
            # fall back to the interactive device flow.
            try:
                return exchange_token(val.strip())
            except RuntimeError:
                logging.getLogger(__name__).warning(
                    "Token exchange failed for %s; falling back to device flow",
                    env_var,
                )
                return obtain_copilot_token()

    # No env var — use device flow (includes exchange step).
    return obtain_copilot_token()


def _resolve_models(args: argparse.Namespace) -> list[tuple[str, str | None]]:
    """Merge --model (repeatable) and --models (comma-separated) into a deduplicated list.

    Each entry is ``(model_name, thinking_effort_or_none)`` parsed from the
    ``model^effort`` syntax.
    """
    from repo_drift.llm.client import parse_model_spec

    raw_specs: list[str] = []
    seen: set[str] = set()

    # --model flags (argparse dest="models", action="append").
    # Each --model value may itself be comma-separated (e.g. --model=a,b,c).
    for raw in args.models or []:
        for spec in raw.split(","):
            spec = spec.strip()
            if spec and spec not in seen:
                raw_specs.append(spec)
                seen.add(spec)

    # --models flag (argparse dest="models_csv").
    for spec in (getattr(args, "models_csv", None) or "").split(","):
        spec = spec.strip()
        if spec and spec not in seen:
            raw_specs.append(spec)
            seen.add(spec)

    if not raw_specs:
        raw_specs = ["claude-sonnet-4.6"]

    return [parse_model_spec(s) for s in raw_specs]


def _make_clients(
    provider: str, api_key: str, model_specs: list[tuple[str, str | None]]
) -> list[LLMClient]:
    """Create LLM client instances for the given provider and model specs.

    Each *model_spec* is ``(model_name, thinking_effort_or_none)`` as returned
    by :func:`_resolve_models`.
    """
    if provider == "openai":
        from repo_drift.llm.openai import OpenAIClient

        return [
            OpenAIClient(api_key=api_key, model=m, thinking_effort=effort)
            for m, effort in model_specs
        ]

    # Default: copilot
    from repo_drift.llm.copilot import CopilotClient

    return [
        CopilotClient(api_key=api_key, model=m, thinking_effort=effort) for m, effort in model_specs
    ]


def _detect_provider(cli_provider: str | None, cli_key: str | None) -> str:
    """Auto-detect provider from env vars / key format if not explicitly set."""
    if cli_provider:
        return cli_provider

    # Check explicit key first.
    if cli_key:
        if cli_key.startswith("sk-"):
            return "openai"
        return "copilot"

    # Check env vars.
    if os.getenv("OPENAI_API_KEY"):
        return "openai"
    if os.getenv("COPILOT_API_KEY") or os.getenv("GITHUB_COPILOT_KEY"):
        return "copilot"

    # Default to copilot (will trigger device flow).
    return "copilot"


def _print_discovery_summary(result: DiscoverResult) -> None:
    """Print a human-readable discovery summary for review."""
    print("\n=== Discovery Results ===\n")

    for catalog in result.catalogs:
        print(f"  {catalog.repo_id}:")
        if not catalog.contracts:
            print("    (no contracts found)")
        for entry in catalog.contracts:
            role_tag = entry.role.upper().ljust(8)
            conf = f"{entry.confidence:.0%}"
            agreement = ""
            if entry.agreement_count > 0:
                agreement = f", {entry.agreement_count} model(s) agree"
            print(
                f"    {role_tag}  {entry.path:<50}  ({entry.file_type}, domain: {entry.domain}, {conf}{agreement})"
            )
        print()

    if result.pairs:
        print("=== Proposed Contract Pairs ===\n")
        for i, pair in enumerate(result.pairs, 1):
            agreement = ""
            if pair.agreement_count > 0:
                agreement = f" [{pair.agreement_count} model(s) agree]"
            print(f"  {i}. [{pair.domain}]{agreement}")
            print(f"     {pair.source_repo}/{pair.source_path}")
            print(f"       <-> {pair.consumer_repo}/{pair.consumer_path}")
        print()

    checks = result.config.get("checks", [])
    print(f"=== Generated Config: {len(checks)} check(s) ===\n")
    for check in checks:
        sev = check.get("severity", "?").upper()
        print(f"  [{sev}] {check.get('id', '?')} ({check.get('type', '?')})")
    print()

    usage = result.token_usage
    if usage.get("total", 0) > 0:
        print(
            f"Token usage: {usage.get('prompt_tokens', 0)} prompt + "
            f"{usage.get('completion_tokens', 0)} completion = {usage.get('total', 0)} total"
        )
        print()


def _print_init_summary(result: InitResult) -> None:
    """Print a human-readable init summary for review."""
    # InitResult is imported lazily in _command_init to avoid circular imports

    print("\n=== Architecture Map ===\n")

    arch = result.architecture
    for repo in arch.repos:
        agreement = ""
        if repo.agreement_count > 1:
            agreement = f" [{repo.agreement_count} models agree]"
        print(f"  {repo.repo_id} ({repo.service_type}){agreement}")
        print(f"    {repo.summary}")
        if repo.owns_contracts:
            print(f"    Owns: {', '.join(repo.owns_contracts)}")
        if repo.consumes_contracts:
            print(f"    Consumes: {', '.join(repo.consumes_contracts)}")
        print()

    if arch.relationships:
        print("=== Relationships ===\n")
        for rel in arch.relationships:
            contracts = f" [{', '.join(rel.contracts)}]" if rel.contracts else ""
            agreement = ""
            if rel.agreement_count > 1:
                agreement = f" ({rel.agreement_count} models)"
            print(f"  {rel.from_repo} --[{rel.rel_type}]--> {rel.to_repo}{contracts}{agreement}")
        print()

    if arch.contract_expectations:
        print("=== Contract Expectations ===\n")
        for ce in arch.contract_expectations:
            consumers = ", ".join(ce.consumer_repos) if ce.consumer_repos else "none"
            agreement = ""
            if ce.agreement_count > 1:
                agreement = f" ({ce.agreement_count} models)"
            print(f"  [{ce.risk.upper()}] {ce.domain} ({ce.contract_type}){agreement}")
            print(f"    Owner: {ce.owner_repo}, Consumers: {consumers}")
            if ce.rationale:
                print(f"    {ce.rationale}")
        print()

    checks = result.config.get("checks", [])
    print(f"=== Generated Config: {len(checks)} check(s) ===\n")
    for check in checks:
        sev = check.get("severity", "?").upper()
        print(f"  [{sev}] {check.get('id', '?')} ({check.get('type', '?')})")
    print()

    usage = result.token_usage
    if usage.get("total", 0) > 0:
        print(
            f"Token usage: {usage.get('prompt_tokens', 0)} prompt + "
            f"{usage.get('completion_tokens', 0)} completion = {usage.get('total', 0)} total"
        )
        print()


def _command_check(
    config_path: Path,
    repo_id: str | None,
    changed_files: list[str],
    output_json: Path | None,
) -> None:
    """Run the ``check`` command — deterministic CI gate."""
    from repo_drift.core.check import evaluate_changed_files

    project = _load(config_path)
    try:
        verdict = evaluate_changed_files(project, repo_id, changed_files)
    except ValueError as exc:
        raise SystemExit(f"check error: {exc}") from exc

    payload = json.dumps(verdict.to_dict(), indent=2)

    if output_json:
        out = output_json.resolve()
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(payload + "\n")
        print(f"Wrote verdict: {out}")
    else:
        print(payload)

    if verdict.verdict == "fail":
        raise SystemExit(1)


def _command_generate_aw(
    config_path: Path,
    output: Path | None,
    architecture_path: str,
    config_path_in_workspace: str,
) -> None:
    """Generate a gh-aw workflow template from the drift config."""
    from repo_drift.core.aw_template import generate_aw_template

    project = _load(config_path)
    template = generate_aw_template(
        config=project,
        architecture_path=architecture_path,
        config_path=config_path_in_workspace,
    )

    if output:
        out = output.resolve()
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(template)
        print(f"Wrote gh-aw template: {out}")
    else:
        print(template)


def _command_models(provider: str, api_key: str) -> None:
    """List available models for the given provider."""
    clients = _make_clients(provider, api_key, [("unused", None)])
    client = clients[0]

    print(f"Querying available models for provider: {provider}")
    print()

    try:
        models = client.list_models()
    except Exception as exc:
        raise SystemExit(f"Failed to list models: {exc}") from exc

    if not models:
        print("No models returned by the API.")
        return

    print(f"Available models ({len(models)}):\n")
    for m in sorted(models, key=lambda x: x.get("id", "")):
        model_id = m.get("id", "?")
        extra_parts: list[str] = []
        if "name" in m:
            extra_parts.append(m["name"])
        if "owned_by" in m:
            extra_parts.append(f"by {m['owned_by']}")
        if "version" in m:
            extra_parts.append(f"v{m['version']}")
        extra = f"  ({', '.join(extra_parts)})" if extra_parts else ""
        print(f"  {model_id}{extra}")
    print()
    print("Use --model <id> with init/discover commands to select a model.")


def _command_init(
    repo_urls: list[str],
    provider: str,
    api_key: str,
    model_specs: list[tuple[str, str | None]],
    workspace: Path,
    output_config: Path,
    output_arch: Path,
    overrides_path: Path | None,
    approve: bool,
    skip_snapshot: bool,
    ref_policy: str,
    orchestrator_spec: tuple[str, str | None] | None = None,
) -> None:
    from repo_drift.init.workflow import run_init
    from repo_drift.llm.client import validate_clients

    clients = _make_clients(provider, api_key, model_specs)
    models = [m for m, _ in model_specs]
    workspace = workspace.resolve()

    orchestrator: LLMClient | None = None
    if orchestrator_spec is not None:
        orchestrator = _make_clients(provider, api_key, [orchestrator_spec])[0]

    print(f"Using provider: {provider}")
    if len(clients) > 1:
        print(f"Running multi-model consensus with {len(clients)} models: {', '.join(models)}")
    if orchestrator is not None:
        orch_name = orchestrator_spec[0] if orchestrator_spec else "?"
        effort = orchestrator_spec[1] if orchestrator_spec else None
        label = f"{orch_name}^{effort}" if effort else orch_name
        print(f"Orchestrator for final synthesis: {label}")

    # Pre-flight model validation — drop unsupported models with user prompt.
    all_to_validate = list(clients)
    if orchestrator is not None:
        all_to_validate.append(orchestrator)
    valid = validate_clients(all_to_validate, interactive=not approve)
    clients = [c for c in clients if c in valid]
    if orchestrator is not None and orchestrator not in valid:
        print(
            f"WARNING: Orchestrator model '{orchestrator.model}' failed validation, disabling orchestrator."
        )
        orchestrator = None
    if not clients:
        raise SystemExit("No valid models remaining. Aborting.")

    # Default overrides path
    if overrides_path is None:
        default_overrides = workspace / ".repo-drift-overrides.json"
        if default_overrides.is_file():
            overrides_path = default_overrides
            print(f"Found overrides: {overrides_path}")

    result = run_init(
        clients=clients,
        repo_urls=repo_urls,
        workspace=workspace,
        ref_policy=ref_policy,
        skip_snapshot=skip_snapshot,
        overrides_path=overrides_path,
        orchestrator=orchestrator,
    )

    _print_init_summary(result)

    # Interactive review unless --approve.
    if not approve and sys.stdin.isatty():
        print("Will write:")
        print(f"  Config:       {output_config}")
        print(f"  Architecture: {output_arch}")
        print()
        try:
            answer = input("Write files? [Y/n] ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print("\nAborted.")
            return
        if answer in ("n", "no"):
            print("Files not written.")
            return

    # Write config
    config_path = (workspace / output_config).resolve()
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(json.dumps(result.config, indent=2) + "\n")
    print(f"Wrote config: {config_path}")

    # Write architecture map
    arch_path = (workspace / output_arch).resolve()
    arch_path.parent.mkdir(parents=True, exist_ok=True)
    arch_path.write_text(result.markdown)
    print(f"Wrote architecture map: {arch_path}")


def _command_discover(
    repo_urls: list[str],
    provider: str,
    api_key: str,
    model_specs: list[tuple[str, str | None]],
    workspace: Path,
    output: Path | None,
    approve: bool,
    skip_snapshot: bool,
    ref_policy: str,
    orchestrator_spec: tuple[str, str | None] | None = None,
) -> None:
    from repo_drift.discover.workflow import run_discover
    from repo_drift.llm.client import validate_clients

    clients = _make_clients(provider, api_key, model_specs)
    models = [m for m, _ in model_specs]
    workspace = workspace.resolve()

    orchestrator: LLMClient | None = None
    if orchestrator_spec is not None:
        orchestrator = _make_clients(provider, api_key, [orchestrator_spec])[0]

    print(f"Using provider: {provider}")
    if len(clients) > 1:
        print(f"Running multi-model consensus with {len(clients)} models: {', '.join(models)}")
    if orchestrator is not None:
        orch_name = orchestrator_spec[0] if orchestrator_spec else "?"
        effort = orchestrator_spec[1] if orchestrator_spec else None
        label = f"{orch_name}^{effort}" if effort else orch_name
        print(f"Orchestrator for final synthesis: {label}")

    # Pre-flight model validation — drop unsupported models with user prompt.
    all_to_validate = list(clients)
    if orchestrator is not None:
        all_to_validate.append(orchestrator)
    valid = validate_clients(all_to_validate, interactive=not approve)
    clients = [c for c in clients if c in valid]
    if orchestrator is not None and orchestrator not in valid:
        print(
            f"WARNING: Orchestrator model '{orchestrator.model}' failed validation, disabling orchestrator."
        )
        orchestrator = None
    if not clients:
        raise SystemExit("No valid models remaining. Aborting.")

    result = run_discover(
        clients=clients,
        repo_urls=repo_urls,
        workspace=workspace,
        ref_policy=ref_policy,
        skip_snapshot=skip_snapshot,
        orchestrator=orchestrator,
    )

    _print_discovery_summary(result)

    config_json = json.dumps(result.config, indent=2) + "\n"

    # Interactive review unless --approve.
    if not approve and output and sys.stdin.isatty():
        print("Proposed config:")
        print(config_json)
        try:
            answer = input(f"Write config to {output}? [Y/n/show] ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print("\nAborted.")
            return

        if answer in ("n", "no"):
            print("Config not written. Printing to stdout instead:")
            print(config_json)
            return
        if answer in ("show", "s"):
            print(config_json)
            try:
                answer = input("Write? [Y/n] ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                print("\nAborted.")
                return
            if answer in ("n", "no"):
                return

    if output:
        out_path = (workspace / output).resolve()
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(config_json)
        print(f"Wrote config: {out_path}")
    else:
        # No --output, just print to stdout.
        print(config_json)


def main() -> None:
    args = _parse_args()

    # Configure logging.
    log_level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=log_level,
        format="%(levelname)s %(name)s: %(message)s",
    )

    if args.command == "snapshot":
        config_path = Path(args.config).resolve()
        workspace_root = Path(args.workspace).resolve()
        _command_snapshot(config_path, workspace_root)
        return

    if args.command == "run":
        config_path = Path(args.config).resolve()
        workspace_root = Path(args.workspace).resolve()
        _command_run(
            config_path=config_path,
            workspace_root=workspace_root,
            with_snapshot=args.snapshot,
            output_json=Path(args.output_json),
            output_md=Path(args.output_md),
        )
        return

    if args.command == "check":
        config_path = Path(args.config).resolve()
        # Collect changed files from --files or stdin.
        if args.files is not None:
            changed_files = args.files
        elif not sys.stdin.isatty():
            changed_files = [line.strip() for line in sys.stdin if line.strip()]
        else:
            raise SystemExit(
                "check: no files specified. Use --files or pipe via stdin.\n"
                "  Example: git diff --name-only | repo-drift check --config .repo-drift.json"
            )
        _command_check(
            config_path=config_path,
            repo_id=args.repo,
            changed_files=changed_files,
            output_json=Path(args.output_json) if args.output_json else None,
        )
        return

    if args.command == "generate-aw":
        config_path = Path(args.config).resolve()
        _command_generate_aw(
            config_path=config_path,
            output=Path(args.output) if args.output else None,
            architecture_path=args.architecture_path,
            config_path_in_workspace=args.config_path,
        )
        return

    if args.command == "models":
        provider = _detect_provider(args.provider, args.api_key)
        api_key = _resolve_api_key_for_provider(provider, args.api_key)
        _command_models(provider, api_key)
        return

    if args.command == "init":
        repo_urls = [_normalize_repo_url(r) for r in args.repos]
        provider = _detect_provider(args.provider, args.api_key)
        api_key = _resolve_api_key_for_provider(provider, args.api_key)
        model_specs = _resolve_models(args)
        overrides_path = Path(args.overrides) if args.overrides else None
        orchestrator_spec = None
        if args.orchestrator:
            from repo_drift.llm.client import parse_model_spec

            orchestrator_spec = parse_model_spec(args.orchestrator)
        _command_init(
            repo_urls=repo_urls,
            provider=provider,
            api_key=api_key,
            model_specs=model_specs,
            workspace=Path(args.workspace).resolve(),
            output_config=Path(args.output_config),
            output_arch=Path(args.output_arch),
            overrides_path=overrides_path,
            approve=args.approve,
            skip_snapshot=args.no_snapshot,
            ref_policy=args.ref_policy,
            orchestrator_spec=orchestrator_spec,
        )
        return

    if args.command == "discover":
        repo_urls = [_normalize_repo_url(r) for r in args.repos]
        provider = _detect_provider(args.provider, args.api_key)
        api_key = _resolve_api_key_for_provider(provider, args.api_key)
        model_specs = _resolve_models(args)
        orchestrator_spec = None
        if args.orchestrator:
            from repo_drift.llm.client import parse_model_spec

            orchestrator_spec = parse_model_spec(args.orchestrator)
        _command_discover(
            repo_urls=repo_urls,
            provider=provider,
            api_key=api_key,
            model_specs=model_specs,
            workspace=Path(args.workspace).resolve(),
            output=Path(args.output) if args.output else None,
            approve=args.approve,
            skip_snapshot=args.no_snapshot,
            ref_policy=args.ref_policy,
            orchestrator_spec=orchestrator_spec,
        )
        return

    raise SystemExit(f"Unsupported command: {args.command}")
