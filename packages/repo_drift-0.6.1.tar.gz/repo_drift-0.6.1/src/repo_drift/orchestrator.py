"""Orchestrator synthesis — optional final LLM refinement of multi-model consensus results.

When ``--orchestrator MODEL`` is specified, the orchestrator receives the
algorithmically merged output (architecture map + generated config) together
with per-model agreement metadata and produces a refined final result.

The orchestrator can:
- Adjust check severities based on cross-cutting architectural understanding
- Remove false-positive checks that the algorithmic merge retained
- Improve architecture descriptions and relationship annotations
- Flag low-agreement items for human review
"""

from __future__ import annotations

import json
import logging
from typing import Any

from repo_drift.llm.client import LLMClient

_logger = logging.getLogger(__name__)

# ── Prompts ────────────────────────────────────────────────────────────

_SYNTHESIZE_INIT_SYSTEM = """\
You are an expert software architect performing a final quality review of an \
automated architecture analysis and drift-check configuration.

Multiple AI models independently analyzed a set of repositories. Their outputs \
were merged using algorithmic consensus (majority vote on categories, confidence \
averaging, set union). You are the orchestrator: your job is to review the \
merged result and produce a refined, higher-quality version.

You will receive:
1. The merged architecture map (repos, relationships, contract expectations)
2. The generated drift-check config (repos + checks array)
3. Agreement metadata showing which items had strong vs weak consensus

Your refinement tasks:
- **Checks**: Keep valid checks. Remove obvious false positives (e.g. checks \
  where source and consumer paths are identical, checks for non-existent \
  contract types). Adjust severity if warranted (e.g. critical for core API \
  schemas, low for internal-only configs).
- **Architecture**: Improve repo summaries for clarity. Fix any relationship \
  descriptions that are vague or contradictory.
- **Low-agreement items**: Items with agreement_count <= 1 (only one model \
  found them) are higher risk for false positives. Flag or remove them unless \
  they seem clearly valid.
- **Consistency**: Ensure check IDs are unique and follow the pattern \
  ``<domain>-<type>`` (e.g. ``user-api-hash-sync``).

Respond with ONLY valid JSON matching this schema:
{
  "config": { ... },           // The refined config (same structure as input)
  "architecture_notes": [],    // List of string notes about changes you made
  "removed_checks": [],        // IDs of checks you removed and why
  "severity_changes": []       // List of {id, old, new, reason}
}

The "config" field must contain the full refined config including "repos" and \
"checks" arrays. Do not omit any fields.

Respond with ONLY valid JSON, no markdown fences, no commentary.\
"""

_SYNTHESIZE_DISCOVER_SYSTEM = """\
You are an expert software architect performing a final quality review of an \
automated contract discovery and drift-check configuration.

Multiple AI models independently discovered contract files across repositories. \
Their outputs were merged using algorithmic consensus. You are the orchestrator: \
review the merged result and produce a refined, higher-quality version.

You will receive:
1. The discovered contract catalogs (per-repo file listings with roles/domains)
2. The proposed contract pairs (source <-> consumer matches)
3. The generated drift-check config
4. Agreement metadata

Your refinement tasks:
- **Checks**: Keep valid checks. Remove false positives. Adjust severities.
- **Pairs**: Validate that proposed pairs make sense (source and consumer in \
  different repos, matching domains, reasonable file types).
- **Low-agreement items**: Items with agreement_count <= 1 deserve extra \
  scrutiny.
- **Consistency**: Ensure check IDs are unique and descriptive.

Respond with ONLY valid JSON matching this schema:
{
  "config": { ... },           // The refined config
  "removed_checks": [],        // IDs of checks you removed and why
  "severity_changes": []       // List of {id, old, new, reason}
}

Respond with ONLY valid JSON, no markdown fences, no commentary.\
"""


def _format_init_synthesis_prompt(
    architecture_dict: dict[str, Any],
    config: dict[str, Any],
) -> str:
    """Format the user prompt for init orchestrator synthesis."""
    return (
        "## Merged Architecture Map\n\n"
        + json.dumps(architecture_dict, indent=2)
        + "\n\n## Generated Config\n\n"
        + json.dumps(config, indent=2)
    )


def _format_discover_synthesis_prompt(
    catalogs_json: list[dict[str, Any]],
    pairs_json: list[dict[str, Any]],
    config: dict[str, Any],
) -> str:
    """Format the user prompt for discover orchestrator synthesis."""
    return (
        "## Discovered Catalogs\n\n"
        + json.dumps(catalogs_json, indent=2)
        + "\n\n## Proposed Contract Pairs\n\n"
        + json.dumps(pairs_json, indent=2)
        + "\n\n## Generated Config\n\n"
        + json.dumps(config, indent=2)
    )


# ── Public API ─────────────────────────────────────────────────────────


def synthesize_init(
    orchestrator: LLMClient,
    architecture_dict: dict[str, Any],
    config: dict[str, Any],
) -> dict[str, Any]:
    """Run orchestrator synthesis on init results.

    Returns the refined config dict. If the orchestrator call fails or
    returns unparseable JSON, logs a warning and returns the original config.
    """
    _logger.info("Orchestrator synthesis (init) using %s ...", orchestrator.model)

    prompt = _format_init_synthesis_prompt(architecture_dict, config)

    try:
        response = orchestrator.complete(
            system=_SYNTHESIZE_INIT_SYSTEM,
            user=prompt,
        )
        result = response.json()
    except Exception:
        _logger.warning(
            "Orchestrator synthesis failed; using algorithmic merge result",
            exc_info=True,
        )
        return config

    refined_config = result.get("config")
    if not isinstance(refined_config, dict):
        _logger.warning("Orchestrator returned invalid config; using algorithmic merge result")
        return config

    # Log changes
    for note in result.get("architecture_notes", []):
        _logger.info("  Orchestrator note: %s", note)
    for removed in result.get("removed_checks", []):
        _logger.info("  Orchestrator removed check: %s", removed)
    for change in result.get("severity_changes", []):
        _logger.info(
            "  Orchestrator severity change: %s %s -> %s (%s)",
            change.get("id", "?"),
            change.get("old", "?"),
            change.get("new", "?"),
            change.get("reason", ""),
        )

    return refined_config


def synthesize_discover(
    orchestrator: LLMClient,
    catalogs_json: list[dict[str, Any]],
    pairs_json: list[dict[str, Any]],
    config: dict[str, Any],
) -> dict[str, Any]:
    """Run orchestrator synthesis on discover results.

    Returns the refined config dict. If the orchestrator call fails,
    logs a warning and returns the original config.
    """
    _logger.info("Orchestrator synthesis (discover) using %s ...", orchestrator.model)

    prompt = _format_discover_synthesis_prompt(catalogs_json, pairs_json, config)

    try:
        response = orchestrator.complete(
            system=_SYNTHESIZE_DISCOVER_SYSTEM,
            user=prompt,
        )
        result = response.json()
    except Exception:
        _logger.warning(
            "Orchestrator synthesis failed; using algorithmic merge result",
            exc_info=True,
        )
        return config

    refined_config = result.get("config")
    if not isinstance(refined_config, dict):
        _logger.warning("Orchestrator returned invalid config; using algorithmic merge result")
        return config

    # Log changes
    for removed in result.get("removed_checks", []):
        _logger.info("  Orchestrator removed check: %s", removed)
    for change in result.get("severity_changes", []):
        _logger.info(
            "  Orchestrator severity change: %s %s -> %s (%s)",
            change.get("id", "?"),
            change.get("old", "?"),
            change.get("new", "?"),
            change.get("reason", ""),
        )

    return refined_config
