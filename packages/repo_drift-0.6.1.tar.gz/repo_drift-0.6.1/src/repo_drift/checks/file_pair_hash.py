from __future__ import annotations

import hashlib
from pathlib import Path

from repo_drift.core.types import CheckConfig, CheckResult, Evidence


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(1024 * 64)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def run_file_pair_hash_check(check: CheckConfig, root: Path) -> CheckResult:
    left_rel = check.params.get("left")
    right_rel = check.params.get("right")

    if not isinstance(left_rel, str) or not isinstance(right_rel, str):
        return CheckResult(
            check_id=check.id,
            check_type=check.type,
            status="error",
            severity=check.severity,
            summary="Invalid check params: expected string `left` and `right`",
            evidence=[
                Evidence(kind="config", message="Missing or invalid params.left/params.right")
            ],
        )

    left = (root / left_rel).resolve()
    right = (root / right_rel).resolve()

    if not left.exists() or not right.exists():
        return CheckResult(
            check_id=check.id,
            check_type=check.type,
            status="fail",
            severity=check.severity,
            summary="Drift check failed due to missing file(s)",
            evidence=[
                Evidence(
                    kind="missing",
                    message="Left file missing" if not left.exists() else "Left file present",
                    path=str(left),
                ),
                Evidence(
                    kind="missing",
                    message="Right file missing" if not right.exists() else "Right file present",
                    path=str(right),
                ),
            ],
            metadata={"left_exists": left.exists(), "right_exists": right.exists()},
        )

    left_hash = _sha256(left)
    right_hash = _sha256(right)

    if left_hash == right_hash:
        status = "pass"
        summary = "No drift: files are byte-identical"
    else:
        status = "fail"
        summary = "Drift detected: file hashes differ"

    return CheckResult(
        check_id=check.id,
        check_type=check.type,
        status=status,
        severity=check.severity,
        summary=summary,
        evidence=[
            Evidence(kind="hash", message="Left hash", path=str(left), left=left_hash),
            Evidence(kind="hash", message="Right hash", path=str(right), right=right_hash),
        ],
        metadata={
            "left": left_rel,
            "right": right_rel,
            "left_hash": left_hash,
            "right_hash": right_hash,
        },
    )
