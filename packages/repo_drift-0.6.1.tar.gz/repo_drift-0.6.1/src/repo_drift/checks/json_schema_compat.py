from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from repo_drift.core.types import CheckConfig, CheckResult, Evidence


def _load_json(path: Path) -> dict[str, Any] | None:
    try:
        payload = json.loads(path.read_text())
    except Exception:
        return None
    if isinstance(payload, dict):
        return payload
    return None


def run_json_schema_compat_check(check: CheckConfig, root: Path) -> CheckResult:
    left_rel = check.params.get("left")
    right_rel = check.params.get("right")

    if not isinstance(left_rel, str) or not isinstance(right_rel, str):
        return CheckResult(
            check_id=check.id,
            check_type=check.type,
            status="error",
            severity=check.severity,
            summary="Invalid check params: expected string `left` and `right`",
            evidence=[
                Evidence(kind="config", message="Missing or invalid params.left/params.right")
            ],
        )

    left = (root / left_rel).resolve()
    right = (root / right_rel).resolve()

    if not left.exists() or not right.exists():
        return CheckResult(
            check_id=check.id,
            check_type=check.type,
            status="fail",
            severity=check.severity,
            summary="Schema compatibility check failed due to missing file(s)",
            evidence=[
                Evidence(
                    kind="missing",
                    message="Left schema missing",
                    path=str(left) if not left.exists() else None,
                ),
                Evidence(
                    kind="missing",
                    message="Right schema missing",
                    path=str(right) if not right.exists() else None,
                ),
            ],
        )

    left_schema = _load_json(left)
    right_schema = _load_json(right)
    if left_schema is None or right_schema is None:
        return CheckResult(
            check_id=check.id,
            check_type=check.type,
            status="error",
            severity=check.severity,
            summary="Failed to parse schema JSON",
            evidence=[
                Evidence(
                    kind="parse",
                    message="Unable to parse left schema",
                    path=str(left) if left_schema is None else None,
                ),
                Evidence(
                    kind="parse",
                    message="Unable to parse right schema",
                    path=str(right) if right_schema is None else None,
                ),
            ],
        )

    left_required = (
        set(left_schema.get("required", []))
        if isinstance(left_schema.get("required", []), list)
        else set()
    )
    right_required = (
        set(right_schema.get("required", []))
        if isinstance(right_schema.get("required", []), list)
        else set()
    )

    removed_required = sorted(left_required - right_required)

    left_props = (
        left_schema.get("properties", {}) if isinstance(left_schema.get("properties"), dict) else {}
    )
    right_props = (
        right_schema.get("properties", {})
        if isinstance(right_schema.get("properties"), dict)
        else {}
    )
    removed_props = sorted(set(left_props.keys()) - set(right_props.keys()))

    evidence: list[Evidence] = []
    status = "pass"
    summary = "Schema compatibility looks safe at root level"

    if removed_required:
        status = "fail"
        summary = "Incompatible schema change: required fields removed"
        evidence.append(
            Evidence(
                kind="required_removed",
                message=f"Removed required fields: {', '.join(removed_required)}",
                left=str(left),
                right=str(right),
            )
        )

    elif removed_props:
        status = "warn"
        summary = "Potential drift: properties removed from schema"
        evidence.append(
            Evidence(
                kind="properties_removed",
                message=f"Removed properties: {', '.join(removed_props)}",
                left=str(left),
                right=str(right),
            )
        )

    else:
        evidence.append(
            Evidence(
                kind="compat",
                message="No required/property removals detected at root level",
                left=str(left),
                right=str(right),
            )
        )

    return CheckResult(
        check_id=check.id,
        check_type=check.type,
        status=status,
        severity=check.severity,
        summary=summary,
        evidence=evidence,
        metadata={
            "removed_required": removed_required,
            "removed_props": removed_props,
        },
    )
