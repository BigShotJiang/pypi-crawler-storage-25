"""Tests for repo_drift.core.policy.should_fail."""

from repo_drift.core.policy import should_fail
from repo_drift.core.types import CheckResult, PolicyRule


def _result(status: str, severity: str = "high") -> CheckResult:
    return CheckResult(
        check_id="test",
        check_type="file_pair_hash",
        status=status,
        severity=severity,
        summary="test",
        evidence=[],
    )


class TestShouldFailNoRules:
    """When no policy rules are configured, fail on any status='fail'."""

    def test_no_results(self) -> None:
        assert should_fail([], []) is False

    def test_all_pass(self) -> None:
        assert should_fail([_result("pass")], []) is False

    def test_has_fail(self) -> None:
        assert should_fail([_result("fail")], []) is True

    def test_has_warn_only(self) -> None:
        assert should_fail([_result("warn")], []) is False

    def test_has_error(self) -> None:
        assert should_fail([_result("error")], []) is False

    def test_mixed_pass_and_fail(self) -> None:
        results = [_result("pass"), _result("fail")]
        assert should_fail(results, []) is True


class TestShouldFailWithRules:
    """When policy rules are configured, match on severity + status."""

    def test_matching_rule(self) -> None:
        rules = [PolicyRule(severity="high", status="fail")]
        assert should_fail([_result("fail", "high")], rules) is True

    def test_no_matching_severity(self) -> None:
        rules = [PolicyRule(severity="critical", status="fail")]
        assert should_fail([_result("fail", "high")], rules) is False

    def test_no_matching_status(self) -> None:
        rules = [PolicyRule(severity="high", status="fail")]
        assert should_fail([_result("warn", "high")], rules) is False

    def test_warn_rule_matches_warn_result(self) -> None:
        """This tests the bug fix: warn rules should actually match warn results."""
        rules = [PolicyRule(severity="medium", status="warn")]
        assert should_fail([_result("warn", "medium")], rules) is True

    def test_warn_rule_does_not_match_fail(self) -> None:
        rules = [PolicyRule(severity="medium", status="warn")]
        assert should_fail([_result("fail", "medium")], rules) is False

    def test_multiple_rules_first_matches(self) -> None:
        rules = [
            PolicyRule(severity="high", status="fail"),
            PolicyRule(severity="critical", status="fail"),
        ]
        assert should_fail([_result("fail", "high")], rules) is True

    def test_multiple_rules_second_matches(self) -> None:
        rules = [
            PolicyRule(severity="high", status="fail"),
            PolicyRule(severity="critical", status="fail"),
        ]
        assert should_fail([_result("fail", "critical")], rules) is True

    def test_multiple_rules_none_match(self) -> None:
        rules = [
            PolicyRule(severity="high", status="fail"),
            PolicyRule(severity="critical", status="fail"),
        ]
        assert should_fail([_result("fail", "low")], rules) is False
