"""Tests for repo_drift.discover.consensus module."""

from __future__ import annotations

from repo_drift.discover.catalog import ContractEntry, ContractPair, RepoCatalog
from repo_drift.discover.consensus import merge_catalogs, merge_configs, merge_pairs

# ---------------------------------------------------------------------------
# merge_catalogs tests
# ---------------------------------------------------------------------------


def _make_entry(
    path: str = "specs/api.json",
    role: str = "source",
    file_type: str = "json-schema",
    domain: str = "task-spec",
    confidence: float = 0.9,
    reasoning: str = "",
) -> ContractEntry:
    return ContractEntry(
        path=path,
        role=role,
        file_type=file_type,
        domain=domain,
        confidence=confidence,
        reasoning=reasoning,
    )


def _make_catalog(
    repo_id: str = "repo-a",
    contracts: list[ContractEntry] | None = None,
) -> RepoCatalog:
    return RepoCatalog(
        repo_id=repo_id,
        repo_url=f"https://github.com/org/{repo_id}.git",
        branch="main",
        snapshot_path=f"repos/{repo_id}",
        contracts=contracts or [],
    )


class TestMergeCatalogs:
    def test_single_model_passthrough(self) -> None:
        """A single model's catalog should pass through with agreement=1."""
        entry = _make_entry(confidence=0.85)
        catalog = _make_catalog(contracts=[entry])

        merged = merge_catalogs({"gpt-4o": catalog})

        assert len(merged.contracts) == 1
        e = merged.contracts[0]
        assert e.path == "specs/api.json"
        assert e.agreement_count == 1
        assert e.agreed_models == ["gpt-4o"]
        assert e.confidence == 0.85

    def test_two_models_agree_on_same_file(self) -> None:
        """Two models finding the same file should produce agreement=2."""
        cat_a = _make_catalog(contracts=[_make_entry(confidence=0.9, reasoning="obvious schema")])
        cat_b = _make_catalog(
            contracts=[_make_entry(confidence=0.8, reasoning="looks like a contract")]
        )

        merged = merge_catalogs({"gpt-4o": cat_a, "claude-sonnet": cat_b})

        assert len(merged.contracts) == 1
        e = merged.contracts[0]
        assert e.agreement_count == 2
        assert sorted(e.agreed_models) == ["claude-sonnet", "gpt-4o"]
        # Average confidence: (0.9 + 0.8) / 2 = 0.85
        assert abs(e.confidence - 0.85) < 0.001

    def test_partial_agreement(self) -> None:
        """When models disagree on which files are contracts, both appear."""
        entry_a = _make_entry(path="specs/api.json", confidence=0.9)
        entry_b = _make_entry(path="schemas/user.yaml", confidence=0.7, file_type="openapi")

        cat_a = _make_catalog(contracts=[entry_a])
        cat_b = _make_catalog(contracts=[entry_b])

        merged = merge_catalogs({"gpt-4o": cat_a, "claude-sonnet": cat_b})

        assert len(merged.contracts) == 2
        paths = {e.path for e in merged.contracts}
        assert paths == {"specs/api.json", "schemas/user.yaml"}
        # Each entry has agreement=1 since only one model found it.
        for e in merged.contracts:
            assert e.agreement_count == 1

    def test_three_models_mixed_agreement(self) -> None:
        """Three models with overlapping results should rank by agreement."""
        # All three find api.json, two find user.yaml, one finds events.proto.
        common = _make_entry(path="specs/api.json", confidence=0.95)
        user_entry = _make_entry(
            path="schemas/user.yaml", confidence=0.8, file_type="openapi", domain="user-api"
        )
        events_entry = _make_entry(
            path="proto/events.proto", confidence=0.6, file_type="protobuf", domain="events"
        )

        cat_1 = _make_catalog(contracts=[common, user_entry, events_entry])
        cat_2 = _make_catalog(
            contracts=[
                _make_entry(path="specs/api.json", confidence=0.9),
                _make_entry(
                    path="schemas/user.yaml",
                    confidence=0.7,
                    file_type="openapi",
                    domain="user-api",
                ),
            ]
        )
        cat_3 = _make_catalog(contracts=[_make_entry(path="specs/api.json", confidence=0.85)])

        merged = merge_catalogs({"m1": cat_1, "m2": cat_2, "m3": cat_3})

        assert len(merged.contracts) == 3
        # Sorted by agreement desc, then confidence desc.
        assert merged.contracts[0].path == "specs/api.json"
        assert merged.contracts[0].agreement_count == 3
        assert merged.contracts[1].path == "schemas/user.yaml"
        assert merged.contracts[1].agreement_count == 2
        assert merged.contracts[2].path == "proto/events.proto"
        assert merged.contracts[2].agreement_count == 1

    def test_majority_vote_on_role(self) -> None:
        """Majority vote should pick the most common role."""
        cat_a = _make_catalog(contracts=[_make_entry(role="source")])
        cat_b = _make_catalog(contracts=[_make_entry(role="consumer")])
        cat_c = _make_catalog(contracts=[_make_entry(role="source")])

        merged = merge_catalogs({"m1": cat_a, "m2": cat_b, "m3": cat_c})

        assert len(merged.contracts) == 1
        # 2 say source, 1 says consumer -> source wins.
        assert merged.contracts[0].role == "source"

    def test_combined_reasoning(self) -> None:
        """Reasoning from multiple models should be combined."""
        cat_a = _make_catalog(contracts=[_make_entry(reasoning="has $schema field")])
        cat_b = _make_catalog(contracts=[_make_entry(reasoning="lives in specs/ dir")])

        merged = merge_catalogs({"gpt-4o": cat_a, "claude": cat_b})

        e = merged.contracts[0]
        assert "[gpt-4o]" in e.reasoning
        assert "[claude]" in e.reasoning
        assert "$schema" in e.reasoning
        assert "specs/" in e.reasoning

    def test_empty_catalogs(self) -> None:
        """Two empty catalogs should merge to empty."""
        cat_a = _make_catalog(contracts=[])
        cat_b = _make_catalog(contracts=[])

        merged = merge_catalogs({"m1": cat_a, "m2": cat_b})

        assert len(merged.contracts) == 0

    def test_preserves_repo_metadata(self) -> None:
        """Merged catalog should preserve repo metadata from the first input."""
        cat = _make_catalog(contracts=[_make_entry()])
        merged = merge_catalogs({"m1": cat})

        assert merged.repo_id == "repo-a"
        assert merged.repo_url == "https://github.com/org/repo-a.git"
        assert merged.branch == "main"


# ---------------------------------------------------------------------------
# merge_pairs tests
# ---------------------------------------------------------------------------


def _make_pair(
    domain: str = "task-spec",
    source_repo: str = "repo-a",
    source_path: str = "specs/task.json",
    consumer_repo: str = "repo-b",
    consumer_path: str = "generated/task.json",
) -> ContractPair:
    return ContractPair(
        domain=domain,
        source_repo=source_repo,
        source_path=source_path,
        consumer_repo=consumer_repo,
        consumer_path=consumer_path,
    )


class TestMergePairs:
    def test_single_model_passthrough(self) -> None:
        pair = _make_pair()
        merged = merge_pairs({"gpt-4o": [pair]})

        assert len(merged) == 1
        assert merged[0].agreement_count == 1
        assert merged[0].agreed_models == ["gpt-4o"]

    def test_two_models_same_pair(self) -> None:
        """Identical pairs from two models should merge with agreement=2."""
        merged = merge_pairs(
            {
                "gpt-4o": [_make_pair()],
                "claude": [_make_pair()],
            }
        )

        assert len(merged) == 1
        assert merged[0].agreement_count == 2
        assert sorted(merged[0].agreed_models) == ["claude", "gpt-4o"]

    def test_different_pairs(self) -> None:
        """Different pairs should both appear."""
        pair_a = _make_pair(domain="task-spec")
        pair_b = _make_pair(
            domain="user-api",
            source_path="specs/user.json",
            consumer_path="lib/user.json",
        )

        merged = merge_pairs(
            {
                "gpt-4o": [pair_a],
                "claude": [pair_b],
            }
        )

        assert len(merged) == 2
        domains = {p.domain for p in merged}
        assert domains == {"task-spec", "user-api"}

    def test_sorted_by_agreement_then_domain(self) -> None:
        """Results should be sorted by agreement desc, then domain asc."""
        common_pair = _make_pair(domain="task-spec")
        unique_pair = _make_pair(
            domain="auth-api",
            source_path="specs/auth.json",
            consumer_path="lib/auth.json",
        )

        merged = merge_pairs(
            {
                "m1": [common_pair, unique_pair],
                "m2": [_make_pair(domain="task-spec")],
            }
        )

        assert len(merged) == 2
        # task-spec has agreement=2, auth-api has agreement=1.
        assert merged[0].domain == "task-spec"
        assert merged[0].agreement_count == 2
        assert merged[1].domain == "auth-api"
        assert merged[1].agreement_count == 1

    def test_empty_input(self) -> None:
        assert merge_pairs({}) == []

    def test_empty_pair_lists(self) -> None:
        merged = merge_pairs({"m1": [], "m2": []})
        assert merged == []


# ---------------------------------------------------------------------------
# merge_configs tests
# ---------------------------------------------------------------------------


class TestMergeConfigs:
    def test_picks_config_with_most_checks(self) -> None:
        config_a: dict[str, list[dict[str, str]]] = {"checks": [{"id": "c1"}]}
        config_b: dict[str, list[dict[str, str]]] = {"checks": [{"id": "c1"}, {"id": "c2"}]}

        merged = merge_configs({"m1": config_a, "m2": config_b})

        assert len(merged.get("checks", [])) == 2

    def test_single_config(self) -> None:
        config: dict[str, list[dict[str, str]]] = {"checks": [{"id": "c1"}]}
        merged = merge_configs({"m1": config})

        assert merged == config

    def test_empty_input(self) -> None:
        assert merge_configs({}) == {}

    def test_tie_breaking(self) -> None:
        """When configs have the same number of checks, any is valid."""
        config_a: dict[str, list[dict[str, str]]] = {"checks": [{"id": "a"}]}
        config_b: dict[str, list[dict[str, str]]] = {"checks": [{"id": "b"}]}

        merged = merge_configs({"m1": config_a, "m2": config_b})

        # Either is fine — just check it's one of them.
        assert len(merged.get("checks", [])) == 1
