"""Tests for repo_drift.init.analyze — deep repo analysis."""

from __future__ import annotations

import json
from pathlib import Path

from repo_drift.init.analyze import analyze_repo
from repo_drift.init.types import RepoAnalysis


def _analyze(tmp_path: Path) -> RepoAnalysis:
    """Helper to run analyze_repo with standard args."""
    return analyze_repo(
        repo_id="test/repo",
        repo_url="https://github.com/test/repo.git",
        branch="main",
        snapshot_path=str(tmp_path),
        repo_dir=tmp_path,
    )


# ── Basic cases ──────────────────────────────────────────────────────


def test_analyze_empty_dir(tmp_path: Path) -> None:
    result = _analyze(tmp_path)
    assert result.repo_id == "test/repo"
    assert result.languages == []
    assert result.frameworks == []
    assert result.build_tools == []
    assert result.contracts == []
    assert result.endpoints == []
    assert result.infra == []
    assert result.service_type == "library"  # no entry points/endpoints


def test_analyze_missing_dir(tmp_path: Path) -> None:
    result = analyze_repo(
        repo_id="test/missing",
        repo_url="https://github.com/test/missing.git",
        branch="main",
        snapshot_path=str(tmp_path / "nonexistent"),
        repo_dir=tmp_path / "nonexistent",
    )
    assert result.repo_id == "test/missing"
    assert result.languages == []
    assert result.service_type == ""


# ── Manifest detection ───────────────────────────────────────────────


def test_detect_manifests_package_json(tmp_path: Path) -> None:
    pkg = {
        "name": "my-app",
        "dependencies": {"express": "^4.18.0", "pg": "^8.0.0"},
        "devDependencies": {"jest": "^29.0.0"},
    }
    (tmp_path / "package.json").write_text(json.dumps(pkg))

    result = _analyze(tmp_path)
    assert "JavaScript/TypeScript" in result.languages
    assert "npm" in result.build_tools
    assert "package.json" in result.manifest_contents
    dep_names = [d.name for d in result.dependencies]
    assert "express" in dep_names
    assert "pg" in dep_names
    assert "jest" in dep_names


def test_detect_manifests_go_mod(tmp_path: Path) -> None:
    go_mod = """\
module github.com/test/repo

go 1.21

require (
	github.com/gin-gonic/gin v1.9.1
	github.com/lib/pq v1.10.9
)
"""
    (tmp_path / "go.mod").write_text(go_mod)

    result = _analyze(tmp_path)
    assert "Go" in result.languages
    assert "go" in result.build_tools
    dep_names = [d.name for d in result.dependencies]
    assert "github.com/gin-gonic/gin" in dep_names
    assert "github.com/lib/pq" in dep_names
    # Gin framework detected from go.mod
    assert "Gin" in result.frameworks


def test_detect_manifests_tsconfig_overrides(tmp_path: Path) -> None:
    (tmp_path / "package.json").write_text('{"name":"app"}')
    (tmp_path / "tsconfig.json").write_text('{"compilerOptions":{}}')

    result = _analyze(tmp_path)
    assert "TypeScript" in result.languages
    # "JavaScript/TypeScript" should be replaced
    assert "JavaScript/TypeScript" not in result.languages


# ── Framework detection ──────────────────────────────────────────────


def test_detect_frameworks_from_config(tmp_path: Path) -> None:
    (tmp_path / "Dockerfile").write_text("FROM node:18\nRUN npm install")
    (tmp_path / "next.config.js").write_text("module.exports = {}")

    result = _analyze(tmp_path)
    assert "Docker" in result.frameworks
    assert "Next.js" in result.frameworks


def test_detect_frameworks_from_npm_deps(tmp_path: Path) -> None:
    pkg = {"name": "api", "dependencies": {"express": "^4.0.0"}}
    (tmp_path / "package.json").write_text(json.dumps(pkg))

    result = _analyze(tmp_path)
    assert "Express" in result.frameworks


# ── README ───────────────────────────────────────────────────────────


def test_read_readme(tmp_path: Path) -> None:
    (tmp_path / "README.md").write_text("# My Project\n\nA test project.")

    result = _analyze(tmp_path)
    assert "My Project" in result.readme_summary
    assert "test project" in result.readme_summary


# ── Entry points ─────────────────────────────────────────────────────


def test_read_entry_points(tmp_path: Path) -> None:
    src = tmp_path / "src"
    src.mkdir()
    (src / "index.ts").write_text('import express from "express";\nconst app = express();')

    result = _analyze(tmp_path)
    assert "src/index.ts" in result.entry_point_snippets
    assert "express" in result.entry_point_snippets["src/index.ts"]


# ── Endpoint extraction ─────────────────────────────────────────────


def test_extract_endpoints_express(tmp_path: Path) -> None:
    src = tmp_path / "src"
    src.mkdir()
    (src / "index.ts").write_text(
        'const app = express();\napp.get("/users", handler);\napp.post("/users", create);'
    )

    result = _analyze(tmp_path)
    methods_paths = [(e.method, e.path) for e in result.endpoints]
    assert ("GET", "/users") in methods_paths
    assert ("POST", "/users") in methods_paths


def test_extract_endpoints_fastapi(tmp_path: Path) -> None:
    (tmp_path / "app.py").write_text(
        'from fastapi import FastAPI\napp = FastAPI()\n@app.post("/items")\ndef create(): pass'
    )

    result = _analyze(tmp_path)
    methods_paths = [(e.method, e.path) for e in result.endpoints]
    assert ("POST", "/items") in methods_paths


def test_extract_endpoints_go(tmp_path: Path) -> None:
    (tmp_path / "main.go").write_text(
        'package main\nfunc main() {\n\tr.Get("/health", handler)\n\tr.Post("/submit", handler)\n}'
    )

    result = _analyze(tmp_path)
    methods_paths = [(e.method, e.path) for e in result.endpoints]
    assert ("GET", "/health") in methods_paths
    assert ("POST", "/submit") in methods_paths


# ── Contract scanning ────────────────────────────────────────────────


def test_scan_contracts_proto(tmp_path: Path) -> None:
    proto_dir = tmp_path / "api"
    proto_dir.mkdir()
    (proto_dir / "service.proto").write_text('syntax = "proto3";')

    result = _analyze(tmp_path)
    contract_paths = [c.path for c in result.contracts]
    assert any("service.proto" in p for p in contract_paths)
    assert any(c.file_type == "protobuf" for c in result.contracts)


def test_scan_contracts_in_schemas_dir(tmp_path: Path) -> None:
    schemas = tmp_path / "schemas"
    schemas.mkdir()
    (schemas / "user.json").write_text('{"type": "object"}')
    (schemas / "order.yaml").write_text("type: object")

    result = _analyze(tmp_path)
    contract_paths = [c.path for c in result.contracts]
    assert any("user.json" in p for p in contract_paths)
    assert any("order.yaml" in p for p in contract_paths)


def test_scan_contracts_compound_ext(tmp_path: Path) -> None:
    (tmp_path / "user.schema.json").write_text('{"$schema": "..."}')
    (tmp_path / "openapi.yaml").write_text("openapi: 3.0.0")

    result = _analyze(tmp_path)
    types = {c.file_type for c in result.contracts}
    assert "json-schema" in types
    assert "openapi" in types


def test_scan_contracts_swagger(tmp_path: Path) -> None:
    (tmp_path / "swagger.json").write_text('{"swagger": "2.0"}')

    result = _analyze(tmp_path)
    types = {c.file_type for c in result.contracts}
    assert "openapi" in types


# ── Infrastructure detection ─────────────────────────────────────────


def test_detect_infra_docker_compose(tmp_path: Path) -> None:
    compose = """\
version: "3"
services:
  db:
    image: postgres:15
  cache:
    image: redis:7
"""
    (tmp_path / "docker-compose.yml").write_text(compose)

    result = _analyze(tmp_path)
    techs = {i.technology for i in result.infra}
    assert "PostgreSQL" in techs
    assert "Redis" in techs


def test_detect_infra_from_manifest(tmp_path: Path) -> None:
    pkg = {"name": "api", "dependencies": {"ioredis": "^5.0.0", "kafkajs": "^2.0.0"}}
    (tmp_path / "package.json").write_text(json.dumps(pkg))

    result = _analyze(tmp_path)
    # "redis" appears in the manifest content via "ioredis"
    # "kafka" appears via "kafkajs"
    techs = {i.technology for i in result.infra}
    assert "Redis" in techs
    assert "Kafka" in techs


# ── Service type inference ───────────────────────────────────────────


def test_infer_service_type_api(tmp_path: Path) -> None:
    pkg = {"name": "api", "dependencies": {"express": "^4.0.0"}}
    (tmp_path / "package.json").write_text(json.dumps(pkg))

    result = _analyze(tmp_path)
    assert result.service_type == "api"


def test_infer_service_type_frontend(tmp_path: Path) -> None:
    pkg = {"name": "web", "dependencies": {"react": "^18.0.0"}}
    (tmp_path / "package.json").write_text(json.dumps(pkg))
    (tmp_path / "tsconfig.json").write_text("{}")

    result = _analyze(tmp_path)
    assert result.service_type == "frontend"


def test_infer_service_type_library(tmp_path: Path) -> None:
    # No frameworks, no entry points, no endpoints
    (tmp_path / "pyproject.toml").write_text('[project]\nname = "mylib"')

    result = _analyze(tmp_path)
    assert result.service_type == "library"


def test_infer_service_type_grpc(tmp_path: Path) -> None:
    go_mod = """\
module github.com/test/repo

go 1.21

require (
	google.golang.org/grpc v1.60.0
)
"""
    (tmp_path / "go.mod").write_text(go_mod)

    result = _analyze(tmp_path)
    assert result.service_type == "grpc-service"


# ── Edge cases ───────────────────────────────────────────────────────


def test_safe_read_large_file_truncated(tmp_path: Path) -> None:
    # Create a README with > 200 lines
    lines = [f"Line {i}" for i in range(300)]
    (tmp_path / "README.md").write_text("\n".join(lines))

    result = _analyze(tmp_path)
    assert "truncated" in result.readme_summary.lower()


def test_ignores_node_modules(tmp_path: Path) -> None:
    nm = tmp_path / "node_modules" / "some-pkg"
    nm.mkdir(parents=True)
    (nm / "schema.proto").write_text('syntax = "proto3";')

    result = _analyze(tmp_path)
    # Proto in node_modules should be ignored
    contract_paths = [c.path for c in result.contracts]
    assert not any("node_modules" in p for p in contract_paths)


# ── Full integration ─────────────────────────────────────────────────


def test_full_repo_analysis(tmp_path: Path) -> None:
    # package.json with express + redis
    pkg = {
        "name": "user-service",
        "dependencies": {"express": "^4.18.0", "ioredis": "^5.0.0"},
    }
    (tmp_path / "package.json").write_text(json.dumps(pkg))

    # tsconfig
    (tmp_path / "tsconfig.json").write_text('{"compilerOptions": {}}')

    # README
    (tmp_path / "README.md").write_text("# User Service\n\nHandles user management.")

    # Dockerfile
    (tmp_path / "Dockerfile").write_text("FROM node:18\nRUN npm install")

    # Entry point with endpoints
    src = tmp_path / "src"
    src.mkdir()
    (src / "index.ts").write_text(
        'import express from "express";\n'
        "const app = express();\n"
        'app.get("/users", listUsers);\n'
        'app.post("/users", createUser);\n'
        'app.get("/users/:id", getUser);\n'
    )

    # Proto file
    proto_dir = tmp_path / "proto"
    proto_dir.mkdir()
    (proto_dir / "user.proto").write_text('syntax = "proto3";\nservice UserService {}')

    # Schemas dir
    schemas = tmp_path / "schemas"
    schemas.mkdir()
    (schemas / "user.schema.json").write_text('{"$schema":"...","type":"object"}')

    # docker-compose with postgres
    (tmp_path / "docker-compose.yml").write_text(
        'version: "3"\nservices:\n  db:\n    image: postgres:15\n'
    )

    result = _analyze(tmp_path)

    # Languages
    assert "TypeScript" in result.languages

    # Frameworks
    assert "Express" in result.frameworks
    assert "Docker" in result.frameworks

    # Build tools
    assert "npm" in result.build_tools

    # Service type
    assert result.service_type == "api"

    # README
    assert "User Service" in result.readme_summary

    # Entry points
    assert "src/index.ts" in result.entry_point_snippets

    # Endpoints
    methods_paths = [(e.method, e.path) for e in result.endpoints]
    assert ("GET", "/users") in methods_paths
    assert ("POST", "/users") in methods_paths
    assert ("GET", "/users/:id") in methods_paths

    # Contracts
    contract_types = {c.file_type for c in result.contracts}
    assert "protobuf" in contract_types
    assert "json-schema" in contract_types

    # Infra
    techs = {i.technology for i in result.infra}
    assert "PostgreSQL" in techs
    assert "Redis" in techs

    # Dependencies
    dep_names = [d.name for d in result.dependencies]
    assert "express" in dep_names
    assert "ioredis" in dep_names

    # Serialization
    d = result.to_dict()
    assert d["repo_id"] == "test/repo"
    assert d["service_type"] == "api"
    assert len(d["endpoints"]) == len(result.endpoints)
