"""Tests for repo_drift.core.report.write_markdown_report."""

import tempfile
from pathlib import Path

from repo_drift.core.report import write_markdown_report
from repo_drift.core.types import CheckResult, Evidence


def test_report_header() -> None:
    results = [
        CheckResult(
            check_id="chk-1",
            check_type="file_pair_hash",
            status="pass",
            severity="high",
            summary="No drift",
            evidence=[Evidence(kind="hash", message="Match")],
        ),
    ]
    with tempfile.TemporaryDirectory() as d:
        path = Path(d) / "report.md"
        write_markdown_report(path, results)
        text = path.read_text()

    assert text.startswith("# Repo Drift Report\n")
    assert "| `chk-1` |" in text
    assert "**PASS**" in text


def test_report_escapes_pipes() -> None:
    results = [
        CheckResult(
            check_id="chk-2",
            check_type="file_pair_hash",
            status="fail",
            severity="high",
            summary="left | right differ",
            evidence=[],
        ),
    ]
    with tempfile.TemporaryDirectory() as d:
        path = Path(d) / "report.md"
        write_markdown_report(path, results)
        text = path.read_text()

    assert "left \\| right differ" in text


def test_report_evidence_with_path() -> None:
    results = [
        CheckResult(
            check_id="chk-3",
            check_type="json_schema_compat",
            status="warn",
            severity="medium",
            summary="Properties removed",
            evidence=[
                Evidence(kind="removed", message="field gone", path="/a/b.json"),
            ],
        ),
    ]
    with tempfile.TemporaryDirectory() as d:
        path = Path(d) / "report.md"
        write_markdown_report(path, results)
        text = path.read_text()

    assert "[path=/a/b.json]" in text


def test_report_empty_evidence() -> None:
    results = [
        CheckResult(
            check_id="chk-4",
            check_type="file_pair_hash",
            status="error",
            severity="high",
            summary="Error occurred",
            evidence=[],
        ),
    ]
    with tempfile.TemporaryDirectory() as d:
        path = Path(d) / "report.md"
        write_markdown_report(path, results)
        text = path.read_text()

    assert "(none)" in text
