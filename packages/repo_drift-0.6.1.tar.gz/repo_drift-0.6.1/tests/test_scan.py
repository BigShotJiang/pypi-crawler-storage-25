"""Tests for repo_drift.discover.scan module."""

import tempfile
from pathlib import Path

from repo_drift.discover.scan import (
    build_file_tree,
    read_candidate_preview,
    scan_repo_for_candidates,
)


def _make_repo(tmp: Path, files: dict[str, str]) -> Path:
    """Create a fake repo directory structure."""
    # Resolve symlinks so /var -> /private/var on macOS doesn't break relative_to
    tmp = tmp.resolve()
    for relpath, content in files.items():
        p = tmp / relpath
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content)
    return tmp


class TestScanRepoForCandidates:
    def test_finds_files_in_candidate_dirs(self) -> None:
        with tempfile.TemporaryDirectory() as d:
            repo = _make_repo(
                Path(d),
                {
                    "specs/api.json": "{}",
                    "schemas/user.yaml": "type: object",
                    "src/main.py": "print('hello')",
                },
            )
            candidates = scan_repo_for_candidates(repo)
            rel_paths = [str(c.relative_to(repo)) for c in candidates]
            assert "specs/api.json" in rel_paths
            assert "schemas/user.yaml" in rel_paths
            # main.py is not in a candidate dir and .py is not a candidate ext
            assert "src/main.py" not in rel_paths

    def test_finds_files_with_candidate_extensions(self) -> None:
        with tempfile.TemporaryDirectory() as d:
            repo = _make_repo(
                Path(d),
                {
                    "lib/config.json": "{}",
                    "lib/readme.txt": "hello",
                },
            )
            candidates = scan_repo_for_candidates(repo)
            rel_paths = [str(c.relative_to(repo)) for c in candidates]
            assert "lib/config.json" in rel_paths
            assert "lib/readme.txt" not in rel_paths

    def test_ignores_gitignored_dirs(self) -> None:
        with tempfile.TemporaryDirectory() as d:
            repo = _make_repo(
                Path(d),
                {
                    "node_modules/pkg/schema.json": "{}",
                    ".git/objects/abc": "blob",
                    "specs/api.json": "{}",
                },
            )
            candidates = scan_repo_for_candidates(repo)
            rel_paths = [str(c.relative_to(repo)) for c in candidates]
            assert "specs/api.json" in rel_paths
            assert not any("node_modules" in p for p in rel_paths)
            assert not any(".git" in p for p in rel_paths)

    def test_empty_dir_returns_empty(self) -> None:
        with tempfile.TemporaryDirectory() as d:
            candidates = scan_repo_for_candidates(Path(d))
            assert candidates == []

    def test_always_include_patterns(self) -> None:
        with tempfile.TemporaryDirectory() as d:
            repo = _make_repo(
                Path(d),
                {
                    "lib/deep/task.schema.json": "{}",
                    "openapi.json": "{}",
                },
            )
            candidates = scan_repo_for_candidates(repo)
            rel_paths = [str(c.relative_to(repo)) for c in candidates]
            assert "lib/deep/task.schema.json" in rel_paths
            assert "openapi.json" in rel_paths


class TestReadCandidatePreview:
    def test_reads_file_contents(self) -> None:
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            f.write('{"hello": "world"}')
            f.flush()
            content = read_candidate_preview(Path(f.name))
        assert '"hello"' in content

    def test_truncates_long_files(self) -> None:
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            for i in range(1000):
                f.write(f"line {i}\n")
            f.flush()
            content = read_candidate_preview(Path(f.name), max_lines=5)
        assert "truncated" in content.lower()


class TestBuildFileTree:
    def test_builds_tree_string(self) -> None:
        with tempfile.TemporaryDirectory() as d:
            repo = Path(d).resolve()
            files = {
                "specs/api.json": "{}",
                "specs/events/task.json": "{}",
            }
            for relpath, content in files.items():
                p = repo / relpath
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(content)

            candidates = [repo / "specs/api.json", repo / "specs/events/task.json"]
            tree = build_file_tree(repo, candidates)

            assert "specs/" in tree
            assert "api.json" in tree
            assert "events/" in tree
            assert "task.json" in tree
