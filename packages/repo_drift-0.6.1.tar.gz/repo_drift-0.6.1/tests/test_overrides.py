"""Tests for repo_drift.init.overrides — config merge logic."""

from __future__ import annotations

import json
from pathlib import Path

from repo_drift.init.overrides import load_overrides, merge_config_with_overrides

# ── load_overrides ───────────────────────────────────────────────────


def test_load_overrides_missing_file(tmp_path: Path) -> None:
    result = load_overrides(tmp_path / "nonexistent.json")
    assert result == {}


def test_load_overrides_invalid_json(tmp_path: Path) -> None:
    path = tmp_path / "bad.json"
    path.write_text("{not valid json!!}")
    result = load_overrides(path)
    assert result == {}


def test_load_overrides_json_array(tmp_path: Path) -> None:
    path = tmp_path / "array.json"
    path.write_text("[1, 2, 3]")
    result = load_overrides(path)
    assert result == {}


def test_load_overrides_success(tmp_path: Path) -> None:
    path = tmp_path / "overrides.json"
    data = {"repos": [{"id": "test/repo", "url": "https://example.com"}]}
    path.write_text(json.dumps(data))
    result = load_overrides(path)
    assert result == data


def test_load_overrides_empty_object(tmp_path: Path) -> None:
    path = tmp_path / "empty.json"
    path.write_text("{}")
    result = load_overrides(path)
    assert result == {}


# ── merge_config_with_overrides ──────────────────────────────────────


def test_merge_empty_overrides() -> None:
    config = {"repos": [{"id": "a", "url": "https://a.com"}], "checks": []}
    result = merge_config_with_overrides(config, {})
    assert result == config


def test_merge_repos_union() -> None:
    config = {"repos": [{"id": "a", "url": "https://a.com"}]}
    overrides = {"repos": [{"id": "b", "url": "https://b.com"}]}
    result = merge_config_with_overrides(config, overrides)
    ids = [r["id"] for r in result["repos"]]
    assert "a" in ids
    assert "b" in ids


def test_merge_repos_override_wins() -> None:
    config = {"repos": [{"id": "a", "url": "https://old.com", "branch": "main"}]}
    overrides = {"repos": [{"id": "a", "url": "https://new.com"}]}
    result = merge_config_with_overrides(config, overrides)
    assert len(result["repos"]) == 1
    assert result["repos"][0]["url"] == "https://new.com"
    # Original fields preserved
    assert result["repos"][0]["branch"] == "main"


def test_merge_checks_union() -> None:
    config = {"checks": [{"id": "check-a", "type": "hash", "severity": "high"}]}
    overrides = {"checks": [{"id": "check-b", "type": "schema", "severity": "low"}]}
    result = merge_config_with_overrides(config, overrides)
    ids = [c["id"] for c in result["checks"]]
    assert "check-a" in ids
    assert "check-b" in ids


def test_merge_checks_override_wins() -> None:
    config = {"checks": [{"id": "check-a", "type": "hash", "severity": "high"}]}
    overrides = {"checks": [{"id": "check-a", "severity": "low"}]}
    result = merge_config_with_overrides(config, overrides)
    assert len(result["checks"]) == 1
    assert result["checks"][0]["severity"] == "low"
    assert result["checks"][0]["type"] == "hash"  # preserved from base


def test_merge_fail_on_dedup() -> None:
    config = {
        "policy": {
            "fail_on": [{"severity": "high", "status": "fail"}],
        }
    }
    overrides = {
        "policy": {
            "fail_on": [{"severity": "high", "status": "fail", "extra": True}],
        }
    }
    result = merge_config_with_overrides(config, overrides)
    fail_on = result["policy"]["fail_on"]
    # Deduplicated by (severity, status)
    assert len(fail_on) == 1
    # Override version wins (has "extra" field)
    assert fail_on[0].get("extra") is True


def test_merge_fail_on_union() -> None:
    config = {"policy": {"fail_on": [{"severity": "high", "status": "fail"}]}}
    overrides = {"policy": {"fail_on": [{"severity": "critical", "status": "fail"}]}}
    result = merge_config_with_overrides(config, overrides)
    fail_on = result["policy"]["fail_on"]
    assert len(fail_on) == 2
    severities = {r["severity"] for r in fail_on}
    assert severities == {"high", "critical"}


def test_merge_fail_on_override_first() -> None:
    config = {"policy": {"fail_on": [{"severity": "medium", "status": "fail"}]}}
    overrides = {"policy": {"fail_on": [{"severity": "critical", "status": "fail"}]}}
    result = merge_config_with_overrides(config, overrides)
    fail_on = result["policy"]["fail_on"]
    # Override rules come first
    assert fail_on[0]["severity"] == "critical"
    assert fail_on[1]["severity"] == "medium"


def test_merge_policy_other_fields() -> None:
    config = {"policy": {"fail_on": [], "max_retries": 3}}
    overrides = {"policy": {"threshold": 0.8, "verbose": True}}
    result = merge_config_with_overrides(config, overrides)
    assert result["policy"]["fail_on"] == []
    assert result["policy"]["max_retries"] == 3  # preserved
    assert result["policy"]["threshold"] == 0.8
    assert result["policy"]["verbose"] is True


def test_severity_overrides_applied() -> None:
    config = {
        "checks": [
            {"id": "check-a", "type": "hash", "severity": "medium"},
            {"id": "check-b", "type": "schema", "severity": "low"},
        ]
    }
    overrides = {"severity_overrides": {"check-a": "critical", "check-b": "high"}}
    result = merge_config_with_overrides(config, overrides)
    checks = {c["id"]: c for c in result["checks"]}
    assert checks["check-a"]["severity"] == "critical"
    assert checks["check-b"]["severity"] == "high"


def test_severity_overrides_invalid_ignored() -> None:
    config = {"checks": [{"id": "check-a", "type": "hash", "severity": "medium"}]}
    overrides = {"severity_overrides": {"check-a": "mega"}}
    result = merge_config_with_overrides(config, overrides)
    # Invalid severity "mega" is ignored
    assert result["checks"][0]["severity"] == "medium"


def test_unknown_top_level_keys_copied() -> None:
    config = {"repos": [], "checks": []}
    overrides = {"description": "My project", "custom_field": 42}
    result = merge_config_with_overrides(config, overrides)
    assert result["description"] == "My project"
    assert result["custom_field"] == 42


def test_full_merge() -> None:
    config = {
        "repos": [
            {"id": "api", "url": "https://github.com/org/api.git"},
            {"id": "web", "url": "https://github.com/org/web.git"},
        ],
        "checks": [
            {"id": "api-schema", "type": "schema-compat", "severity": "high"},
            {"id": "shared-types", "type": "file-pair-hash", "severity": "medium"},
        ],
        "policy": {
            "fail_on": [
                {"severity": "high", "status": "fail"},
            ]
        },
    }
    overrides = {
        "repos": [
            {"id": "api", "branch": "develop"},  # override branch for existing
            {"id": "worker", "url": "https://github.com/org/worker.git"},  # new repo
        ],
        "checks": [
            {"id": "new-check", "type": "hash", "severity": "low"},  # new check
        ],
        "policy": {
            "fail_on": [
                {"severity": "critical", "status": "fail"},  # new rule
                {"severity": "high", "status": "fail"},  # dedup with base
            ]
        },
        "severity_overrides": {
            "shared-types": "high",  # upgrade severity
        },
        "metadata": {"version": "2.0"},  # extra key
    }

    result = merge_config_with_overrides(config, overrides)

    # Repos: 3 total (api merged, web preserved, worker added)
    repo_ids = [r["id"] for r in result["repos"]]
    assert len(result["repos"]) == 3
    assert set(repo_ids) == {"api", "web", "worker"}
    api_repo = next(r for r in result["repos"] if r["id"] == "api")
    assert api_repo["branch"] == "develop"
    assert api_repo["url"] == "https://github.com/org/api.git"

    # Checks: 3 total
    check_ids = [c["id"] for c in result["checks"]]
    assert len(result["checks"]) == 3
    assert set(check_ids) == {"api-schema", "shared-types", "new-check"}

    # Severity override applied
    shared = next(c for c in result["checks"] if c["id"] == "shared-types")
    assert shared["severity"] == "high"

    # Policy: 2 rules (dedup removed the duplicate high/fail)
    assert len(result["policy"]["fail_on"]) == 2

    # Extra key
    assert result["metadata"] == {"version": "2.0"}
