"""Tests for repo_drift.core.config.load_project_config."""

import json
import tempfile
from pathlib import Path

import pytest

from repo_drift.core.config import ConfigError, load_project_config


def _write_config(data: dict) -> Path:
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
        json.dump(data, f)
    return Path(f.name)


_VALID_CONFIG = {
    "version": 1,
    "repos": [
        {
            "id": "repo-a",
            "url": "https://github.com/example/repo-a.git",
            "ref_policy": "main",
            "snapshot_path": "repos/repo-a",
        }
    ],
    "checks": [
        {
            "id": "chk-1",
            "type": "file_pair_hash",
            "severity": "high",
            "params": {"left": "a.json", "right": "b.json"},
        }
    ],
}


class TestLoadProjectConfig:
    def test_valid_config(self) -> None:
        path = _write_config(_VALID_CONFIG)
        project = load_project_config(path)
        assert project.version == 1
        assert len(project.repos) == 1
        assert project.repos[0].id == "repo-a"
        assert len(project.checks) == 1
        assert project.checks[0].type == "file_pair_hash"

    def test_missing_file(self) -> None:
        with pytest.raises(ConfigError, match="not found"):
            load_project_config(Path("/nonexistent/config.json"))

    def test_invalid_json(self) -> None:
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            f.write("{invalid")
        with pytest.raises(ConfigError, match="Invalid JSON"):
            load_project_config(Path(f.name))

    def test_missing_version(self) -> None:
        data = {**_VALID_CONFIG}
        del data["version"]
        with pytest.raises(ConfigError, match="version"):
            load_project_config(_write_config(data))

    def test_version_zero(self) -> None:
        data = {**_VALID_CONFIG, "version": 0}
        with pytest.raises(ConfigError, match="version"):
            load_project_config(_write_config(data))

    def test_empty_repos(self) -> None:
        data = {**_VALID_CONFIG, "repos": []}
        with pytest.raises(ConfigError, match="repos"):
            load_project_config(_write_config(data))

    def test_empty_checks(self) -> None:
        data = {**_VALID_CONFIG, "checks": []}
        with pytest.raises(ConfigError, match="checks"):
            load_project_config(_write_config(data))

    def test_invalid_ref_policy(self) -> None:
        data = {**_VALID_CONFIG, "repos": [{**_VALID_CONFIG["repos"][0], "ref_policy": "nope"}]}
        with pytest.raises(ConfigError, match="ref_policy"):
            load_project_config(_write_config(data))

    def test_invalid_check_type(self) -> None:
        data = {**_VALID_CONFIG, "checks": [{**_VALID_CONFIG["checks"][0], "type": "nope"}]}
        with pytest.raises(ConfigError, match="type"):
            load_project_config(_write_config(data))

    def test_invalid_severity(self) -> None:
        data = {**_VALID_CONFIG, "checks": [{**_VALID_CONFIG["checks"][0], "severity": "nope"}]}
        with pytest.raises(ConfigError, match="severity"):
            load_project_config(_write_config(data))

    def test_policy_with_fail_on(self) -> None:
        data = {
            **_VALID_CONFIG,
            "policy": {
                "fail_on": [
                    {"severity": "high", "status": "fail"},
                    {"severity": "medium", "status": "warn"},
                ]
            },
        }
        project = load_project_config(_write_config(data))
        assert len(project.fail_on) == 2
        assert project.fail_on[0].severity == "high"
        assert project.fail_on[0].status == "fail"
        assert project.fail_on[1].severity == "medium"
        assert project.fail_on[1].status == "warn"

    def test_custom_ref_policy_requires_custom_ref(self) -> None:
        data = {
            **_VALID_CONFIG,
            "repos": [{**_VALID_CONFIG["repos"][0], "ref_policy": "custom"}],
        }
        with pytest.raises(ConfigError, match="custom_ref"):
            load_project_config(_write_config(data))

    def test_custom_ref_policy_with_custom_ref(self) -> None:
        data = {
            **_VALID_CONFIG,
            "repos": [
                {
                    **_VALID_CONFIG["repos"][0],
                    "ref_policy": "custom",
                    "custom_ref": "release/v1",
                }
            ],
        }
        project = load_project_config(_write_config(data))
        assert project.repos[0].custom_ref == "release/v1"
