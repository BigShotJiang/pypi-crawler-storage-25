"""Tests for CLI provider detection, key resolution, and client creation."""

from __future__ import annotations

import os
from unittest.mock import patch

import pytest

from repo_drift.cli import (
    _detect_provider,
    _make_clients,
    _normalize_repo_url,
    _resolve_api_key_for_provider,
)
from repo_drift.llm.client import LLMClient
from repo_drift.llm.copilot import CopilotClient
from repo_drift.llm.openai import OpenAIClient

# ---------------------------------------------------------------------------
# _detect_provider
# ---------------------------------------------------------------------------


class TestDetectProvider:
    """Tests for _detect_provider()."""

    def test_explicit_provider_copilot(self) -> None:
        assert _detect_provider("copilot", None) == "copilot"

    def test_explicit_provider_openai(self) -> None:
        assert _detect_provider("openai", None) == "openai"

    def test_explicit_provider_overrides_key(self) -> None:
        # Even if key looks like OpenAI, explicit provider wins.
        assert _detect_provider("copilot", "sk-abc123") == "copilot"

    def test_sk_key_implies_openai(self) -> None:
        assert _detect_provider(None, "sk-abc123") == "openai"

    def test_non_sk_key_implies_copilot(self) -> None:
        assert _detect_provider(None, "gho_abc123") == "copilot"

    def test_non_sk_key_implies_copilot_random(self) -> None:
        assert _detect_provider(None, "some-random-key") == "copilot"

    @patch.dict(os.environ, {"OPENAI_API_KEY": "sk-env"}, clear=False)
    def test_openai_env_var(self) -> None:
        assert _detect_provider(None, None) == "openai"

    @patch.dict(os.environ, {"COPILOT_API_KEY": "gho_env"}, clear=False)
    def test_copilot_api_key_env_var(self) -> None:
        # Remove OPENAI_API_KEY if it happens to be set.
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("OPENAI_API_KEY", None)
            assert _detect_provider(None, None) == "copilot"

    @patch.dict(os.environ, {"GITHUB_COPILOT_KEY": "gho_env"}, clear=False)
    def test_github_copilot_key_env_var(self) -> None:
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("OPENAI_API_KEY", None)
            os.environ.pop("COPILOT_API_KEY", None)
            assert _detect_provider(None, None) == "copilot"

    def test_no_env_no_key_defaults_copilot(self) -> None:
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("OPENAI_API_KEY", None)
            os.environ.pop("COPILOT_API_KEY", None)
            os.environ.pop("GITHUB_COPILOT_KEY", None)
            assert _detect_provider(None, None) == "copilot"

    @patch.dict(
        os.environ,
        {"OPENAI_API_KEY": "sk-env", "COPILOT_API_KEY": "gho_env"},
        clear=False,
    )
    def test_openai_env_takes_priority_over_copilot(self) -> None:
        # OPENAI_API_KEY is checked first.
        assert _detect_provider(None, None) == "openai"


# ---------------------------------------------------------------------------
# _resolve_api_key_for_provider
# ---------------------------------------------------------------------------


class TestResolveApiKeyForProvider:
    """Tests for _resolve_api_key_for_provider()."""

    def test_cli_key_always_wins_openai(self) -> None:
        assert _resolve_api_key_for_provider("openai", "my-cli-key") == "my-cli-key"

    def test_cli_key_always_wins_copilot(self) -> None:
        with patch(
            "repo_drift.llm.copilot_auth.exchange_token",
            return_value="session_my-cli-key",
        ):
            assert _resolve_api_key_for_provider("copilot", "my-cli-key") == "session_my-cli-key"

    @patch.dict(os.environ, {"OPENAI_API_KEY": "sk-from-env"}, clear=False)
    def test_openai_reads_env_var(self) -> None:
        assert _resolve_api_key_for_provider("openai", None) == "sk-from-env"

    @patch.dict(os.environ, {"LLM_API_KEY": "sk-llm"}, clear=False)
    def test_openai_falls_back_to_llm_api_key(self) -> None:
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("OPENAI_API_KEY", None)
            assert _resolve_api_key_for_provider("openai", None) == "sk-llm"

    def test_openai_exits_when_no_key(self) -> None:
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("OPENAI_API_KEY", None)
            os.environ.pop("LLM_API_KEY", None)
            with pytest.raises(SystemExit, match="No OpenAI API key found"):
                _resolve_api_key_for_provider("openai", None)

    @patch.dict(os.environ, {"COPILOT_API_KEY": "gho_env"}, clear=False)
    def test_copilot_reads_env_var(self) -> None:
        with patch(
            "repo_drift.llm.copilot_auth.exchange_token",
            return_value="session_gho_env",
        ):
            assert _resolve_api_key_for_provider("copilot", None) == "session_gho_env"

    @patch.dict(os.environ, {"GITHUB_COPILOT_KEY": "gho_github"}, clear=False)
    def test_copilot_reads_github_copilot_key(self) -> None:
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("COPILOT_API_KEY", None)
            with patch(
                "repo_drift.llm.copilot_auth.exchange_token",
                return_value="session_gho_github",
            ):
                assert _resolve_api_key_for_provider("copilot", None) == "session_gho_github"

    @patch.dict(os.environ, {"LLM_API_KEY": "gho_llm"}, clear=False)
    def test_copilot_falls_back_to_llm_api_key(self) -> None:
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("COPILOT_API_KEY", None)
            os.environ.pop("GITHUB_COPILOT_KEY", None)
            with patch(
                "repo_drift.llm.copilot_auth.exchange_token",
                return_value="session_gho_llm",
            ):
                assert _resolve_api_key_for_provider("copilot", None) == "session_gho_llm"

    def test_copilot_triggers_device_flow_when_no_key(self) -> None:
        """When no env var, copilot should call obtain_copilot_token()."""
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("COPILOT_API_KEY", None)
            os.environ.pop("GITHUB_COPILOT_KEY", None)
            os.environ.pop("LLM_API_KEY", None)
            # The function does a lazy `from repo_drift.llm.copilot_auth import ...`
            # so we patch at the source module.
            with patch(
                "repo_drift.llm.copilot_auth.obtain_copilot_token",
                return_value="gho_device_flow_token",
            ):
                result = _resolve_api_key_for_provider("copilot", None)
            assert result == "gho_device_flow_token"

    @patch.dict(os.environ, {"OPENAI_API_KEY": "  sk-spaces  "}, clear=False)
    def test_key_is_stripped(self) -> None:
        assert _resolve_api_key_for_provider("openai", None) == "sk-spaces"

    def test_empty_string_key_treated_as_none(self) -> None:
        with (
            patch.dict(os.environ, {"OPENAI_API_KEY": "", "LLM_API_KEY": ""}, clear=False),
            pytest.raises(SystemExit, match="No OpenAI API key found"),
        ):
            _resolve_api_key_for_provider("openai", None)

    def test_whitespace_only_key_treated_as_none(self) -> None:
        with (
            patch.dict(os.environ, {"OPENAI_API_KEY": "   ", "LLM_API_KEY": "  "}, clear=False),
            pytest.raises(SystemExit, match="No OpenAI API key found"),
        ):
            _resolve_api_key_for_provider("openai", None)


# ---------------------------------------------------------------------------
# _make_clients
# ---------------------------------------------------------------------------


class TestMakeClients:
    """Tests for _make_clients()."""

    def test_openai_creates_openai_clients(self) -> None:
        clients = _make_clients("openai", "sk-test", [("gpt-4o", None)])
        assert len(clients) == 1
        assert isinstance(clients[0], OpenAIClient)
        assert isinstance(clients[0], LLMClient)
        assert clients[0].model == "gpt-4o"

    def test_copilot_creates_copilot_clients(self) -> None:
        clients = _make_clients("copilot", "gho_test", [("gpt-4o", None)])
        assert len(clients) == 1
        assert isinstance(clients[0], CopilotClient)
        assert isinstance(clients[0], LLMClient)
        assert clients[0].model == "gpt-4o"

    def test_multiple_models(self) -> None:
        clients = _make_clients("openai", "sk-test", [("gpt-4o", None), ("gpt-4o-mini", None)])
        assert len(clients) == 2
        assert clients[0].model == "gpt-4o"
        assert clients[1].model == "gpt-4o-mini"

    def test_unknown_provider_defaults_to_copilot(self) -> None:
        # Any unrecognized provider falls through to the copilot branch.
        clients = _make_clients("unknown", "key", [("gpt-4o", None)])
        assert len(clients) == 1
        assert isinstance(clients[0], CopilotClient)


# ---------------------------------------------------------------------------
# _normalize_repo_url (extended tests for local paths)
# ---------------------------------------------------------------------------


class TestNormalizeRepoUrl:
    """Tests for _normalize_repo_url() including local path handling."""

    def test_github_shorthand(self) -> None:
        assert _normalize_repo_url("org/repo") == "https://github.com/org/repo.git"

    def test_github_shorthand_with_git(self) -> None:
        assert _normalize_repo_url("org/repo.git") == "https://github.com/org/repo.git"

    def test_full_url_passthrough(self) -> None:
        url = "https://github.com/org/repo.git"
        assert _normalize_repo_url(url) == url

    def test_git_ssh_passthrough(self) -> None:
        url = "git@github.com:org/repo.git"
        assert _normalize_repo_url(url) == url

    def test_absolute_path_passthrough(self) -> None:
        assert _normalize_repo_url("/Users/dev/my-repo") == "/Users/dev/my-repo"

    def test_relative_path_passthrough(self) -> None:
        assert _normalize_repo_url("./my-repo") == "./my-repo"

    def test_tilde_path_passthrough(self) -> None:
        assert _normalize_repo_url("~/projects/repo") == "~/projects/repo"


# ---------------------------------------------------------------------------
# list_models
# ---------------------------------------------------------------------------


class TestCopilotListModels:
    """Tests for CopilotClient.list_models()."""

    def test_list_models_returns_model_ids(self) -> None:
        """list_models() parses the OpenAI-compatible /models response."""
        import json
        import threading
        from http.server import BaseHTTPRequestHandler, HTTPServer

        from repo_drift.llm.copilot import CopilotClient

        response_payload = {
            "data": [
                {"id": "gpt-4o", "object": "model", "owned_by": "openai"},
                {"id": "claude-sonnet-4", "object": "model", "owned_by": "anthropic"},
            ]
        }

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self) -> None:
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps(response_payload).encode())

            def log_message(self, *_args: object) -> None:
                pass  # Silence request logs in test output.

        server = HTTPServer(("127.0.0.1", 0), Handler)
        port = server.server_address[1]
        thread = threading.Thread(target=server.handle_request, daemon=True)
        thread.start()

        try:
            client = CopilotClient(api_key="test-token", base_url=f"http://127.0.0.1:{port}")
            models = client.list_models()
        finally:
            server.server_close()

        assert len(models) == 2
        assert models[0]["id"] == "gpt-4o"
        assert models[0]["owned_by"] == "openai"
        assert models[1]["id"] == "claude-sonnet-4"
        assert models[1]["owned_by"] == "anthropic"

    def test_list_models_empty_response(self) -> None:
        """list_models() returns empty list when no models."""
        import json
        import threading
        from http.server import BaseHTTPRequestHandler, HTTPServer

        from repo_drift.llm.copilot import CopilotClient

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self) -> None:
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({"data": []}).encode())

            def log_message(self, *_args: object) -> None:
                pass

        server = HTTPServer(("127.0.0.1", 0), Handler)
        port = server.server_address[1]
        thread = threading.Thread(target=server.handle_request, daemon=True)
        thread.start()

        try:
            client = CopilotClient(api_key="test-token", base_url=f"http://127.0.0.1:{port}")
            models = client.list_models()
        finally:
            server.server_close()

        assert models == []

    def test_list_models_http_error(self) -> None:
        """list_models() raises CopilotError on HTTP error."""
        import threading
        from http.server import BaseHTTPRequestHandler, HTTPServer

        from repo_drift.llm.copilot import CopilotClient, CopilotError

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self) -> None:
                self.send_response(401)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(b'{"error":"unauthorized"}')

            def log_message(self, *_args: object) -> None:
                pass

        server = HTTPServer(("127.0.0.1", 0), Handler)
        port = server.server_address[1]
        thread = threading.Thread(target=server.handle_request, daemon=True)
        thread.start()

        try:
            client = CopilotClient(api_key="bad-token", base_url=f"http://127.0.0.1:{port}")
            with pytest.raises(CopilotError, match="HTTP 401"):
                client.list_models()
        finally:
            server.server_close()

    def test_list_models_includes_copilot_headers(self) -> None:
        """list_models() sends Copilot integration headers."""
        import json
        import threading
        from http.server import BaseHTTPRequestHandler, HTTPServer

        from repo_drift.llm.copilot import CopilotClient

        captured_headers: dict[str, str] = {}

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self) -> None:
                captured_headers["Editor-Version"] = self.headers.get("Editor-Version", "")
                captured_headers["Editor-Plugin-Version"] = self.headers.get(
                    "Editor-Plugin-Version", ""
                )
                captured_headers["Copilot-Integration-Id"] = self.headers.get(
                    "Copilot-Integration-Id", ""
                )
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({"data": []}).encode())

            def log_message(self, *_args: object) -> None:
                pass

        server = HTTPServer(("127.0.0.1", 0), Handler)
        port = server.server_address[1]
        thread = threading.Thread(target=server.handle_request, daemon=True)
        thread.start()

        try:
            client = CopilotClient(api_key="test-token", base_url=f"http://127.0.0.1:{port}")
            client.list_models()
        finally:
            server.server_close()

        assert captured_headers["Editor-Version"] == "vscode/1.104.1"
        assert captured_headers["Editor-Plugin-Version"] == "copilot-chat/0.26.7"
        assert captured_headers["Copilot-Integration-Id"] == "vscode-chat"


class TestOpenAIListModels:
    """Tests for OpenAIClient.list_models()."""

    def test_list_models_returns_model_ids(self) -> None:
        import json
        import threading
        from http.server import BaseHTTPRequestHandler, HTTPServer

        from repo_drift.llm.openai import OpenAIClient

        response_payload = {
            "data": [
                {"id": "gpt-4o", "object": "model", "owned_by": "openai"},
                {"id": "gpt-4o-mini", "object": "model", "owned_by": "openai"},
            ]
        }

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self) -> None:
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps(response_payload).encode())

            def log_message(self, *_args: object) -> None:
                pass

        server = HTTPServer(("127.0.0.1", 0), Handler)
        port = server.server_address[1]
        thread = threading.Thread(target=server.handle_request, daemon=True)
        thread.start()

        try:
            client = OpenAIClient(api_key="sk-test", base_url=f"http://127.0.0.1:{port}")
            models = client.list_models()
        finally:
            server.server_close()

        assert len(models) == 2
        assert models[0]["id"] == "gpt-4o"
        assert models[1]["id"] == "gpt-4o-mini"

    def test_list_models_http_error(self) -> None:
        import threading
        from http.server import BaseHTTPRequestHandler, HTTPServer

        from repo_drift.llm.openai import OpenAIClient, OpenAIError

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self) -> None:
                self.send_response(403)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(b'{"error":"forbidden"}')

            def log_message(self, *_args: object) -> None:
                pass

        server = HTTPServer(("127.0.0.1", 0), Handler)
        port = server.server_address[1]
        thread = threading.Thread(target=server.handle_request, daemon=True)
        thread.start()

        try:
            client = OpenAIClient(api_key="sk-bad", base_url=f"http://127.0.0.1:{port}")
            with pytest.raises(OpenAIError, match="HTTP 403"):
                client.list_models()
        finally:
            server.server_close()
