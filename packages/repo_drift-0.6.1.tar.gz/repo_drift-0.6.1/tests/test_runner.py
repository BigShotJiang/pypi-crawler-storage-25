"""Tests for repo_drift.core.runner dispatch."""

from pathlib import Path

from repo_drift.core.runner import run_check, run_checks
from repo_drift.core.types import CheckConfig

_REPO_ROOT = Path(__file__).resolve().parent.parent.parent
_TESTDATA = _REPO_ROOT / "testdata"


class TestRunCheck:
    def test_dispatches_file_pair_hash(self) -> None:
        c = CheckConfig(
            id="chk-1",
            type="file_pair_hash",
            severity="high",
            params={
                "left": "testdata/fixtures/repo-a/specs/task-spec.json",
                "right": "testdata/fixtures/repo-b/generated/task-spec.json",
            },
        )
        result = run_check(c, _REPO_ROOT)
        assert result.check_type == "file_pair_hash"
        assert result.status == "pass"

    def test_dispatches_json_schema_compat(self) -> None:
        c = CheckConfig(
            id="chk-2",
            type="json_schema_compat",
            severity="medium",
            params={
                "left": "testdata/fixtures/repo-a/specs/task-spec.json",
                "right": "testdata/fixtures/repo-b/generated/task-spec.json",
            },
        )
        result = run_check(c, _REPO_ROOT)
        assert result.check_type == "json_schema_compat"
        assert result.status == "pass"

    def test_unsupported_type_returns_error(self) -> None:
        c = CheckConfig(
            id="chk-3",
            type="unknown_check",
            severity="high",
            params={},
        )
        result = run_check(c, _REPO_ROOT)
        assert result.status == "error"
        assert "Unsupported" in result.summary

    def test_run_checks_multiple(self) -> None:
        checks = [
            CheckConfig(
                id="chk-1",
                type="file_pair_hash",
                severity="high",
                params={
                    "left": "testdata/fixtures/repo-a/specs/task-spec.json",
                    "right": "testdata/fixtures/repo-b/generated/task-spec.json",
                },
            ),
            CheckConfig(
                id="chk-2",
                type="file_pair_hash",
                severity="high",
                params={
                    "left": "testdata/fixtures/repo-a/specs/task-spec.json",
                    "right": "testdata/fixtures/repo-b/generated/task-spec-drifted.json",
                },
            ),
        ]
        results = run_checks(checks, _REPO_ROOT)
        assert len(results) == 2
        assert results[0].status == "pass"
        assert results[1].status == "fail"
