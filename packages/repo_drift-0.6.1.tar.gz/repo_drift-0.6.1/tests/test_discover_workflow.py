"""Tests for discover.workflow path-handling helpers."""

from __future__ import annotations

from repo_drift.discover.workflow import _build_repo_configs, _is_local_path, _repo_id_from_url


class TestIsLocalPath:
    def test_absolute_path(self) -> None:
        assert _is_local_path("/Users/dev/my-service") is True

    def test_relative_path(self) -> None:
        assert _is_local_path("./my-service") is True

    def test_home_tilde(self) -> None:
        assert _is_local_path("~/projects/my-service") is True

    def test_https_url(self) -> None:
        assert _is_local_path("https://github.com/org/repo.git") is False

    def test_git_url(self) -> None:
        assert _is_local_path("git@github.com:org/repo.git") is False

    def test_org_repo_shorthand(self) -> None:
        assert _is_local_path("org/repo") is False


class TestRepoIdFromUrl:
    def test_github_url(self) -> None:
        assert _repo_id_from_url("https://github.com/acme/my-service.git") == "my-service"

    def test_github_url_no_git(self) -> None:
        assert _repo_id_from_url("https://github.com/acme/my-service") == "my-service"

    def test_trailing_slash(self) -> None:
        assert _repo_id_from_url("https://github.com/acme/my-service/") == "my-service"

    def test_local_path(self) -> None:
        assert _repo_id_from_url("/Users/dev/my-service") == "my-service"

    def test_local_path_trailing_slash(self) -> None:
        assert _repo_id_from_url("/Users/dev/my-service/") == "my-service"


class TestBuildRepoConfigs:
    def test_remote_url_gets_repos_prefix(self) -> None:
        configs = _build_repo_configs(["https://github.com/acme/svc.git"])
        assert len(configs) == 1
        assert configs[0].id == "svc"
        assert configs[0].snapshot_path == "repos/svc"

    def test_local_path_gets_absolute_snapshot_path(self) -> None:
        configs = _build_repo_configs(["/Users/dev/my-service"])
        assert len(configs) == 1
        assert configs[0].id == "my-service"
        # snapshot_path should be the resolved absolute path, not repos/my-service
        assert configs[0].snapshot_path == "/Users/dev/my-service"
        assert not configs[0].snapshot_path.startswith("repos/")

    def test_relative_local_path(self) -> None:
        configs = _build_repo_configs(["./my-service"])
        assert len(configs) == 1
        assert configs[0].id == "my-service"
        # Should be resolved to an absolute path
        assert not configs[0].snapshot_path.startswith("repos/")
        assert configs[0].snapshot_path.startswith("/")

    def test_dedup_ids(self) -> None:
        configs = _build_repo_configs(
            [
                "https://github.com/org1/svc.git",
                "https://github.com/org2/svc.git",
            ]
        )
        assert configs[0].id == "svc"
        assert configs[1].id == "svc-2"

    def test_mixed_local_and_remote(self) -> None:
        configs = _build_repo_configs(
            [
                "/Users/dev/my-service",
                "https://github.com/acme/other.git",
            ]
        )
        assert configs[0].snapshot_path == "/Users/dev/my-service"
        assert configs[1].snapshot_path == "repos/other"
