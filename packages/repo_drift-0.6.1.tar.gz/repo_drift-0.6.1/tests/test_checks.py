"""Tests for check functions using shared fixtures from testdata/."""

from pathlib import Path

from repo_drift.checks.file_pair_hash import run_file_pair_hash_check
from repo_drift.checks.json_schema_compat import run_json_schema_compat_check
from repo_drift.core.types import CheckConfig

# Resolve testdata relative to repo root (python/ is one level down).
_REPO_ROOT = Path(__file__).resolve().parent.parent.parent
_TESTDATA = _REPO_ROOT / "testdata"


def _check(check_type: str, left: str, right: str, severity: str = "high") -> CheckConfig:
    return CheckConfig(
        id="test-check",
        type=check_type,
        severity=severity,
        params={"left": left, "right": right},
    )


class TestFilePairHash:
    def test_identical_files_pass(self) -> None:
        c = _check(
            "file_pair_hash",
            "testdata/fixtures/repo-a/specs/task-spec.json",
            "testdata/fixtures/repo-b/generated/task-spec.json",
        )
        result = run_file_pair_hash_check(c, _REPO_ROOT)
        assert result.status == "pass"
        assert "byte-identical" in result.summary

    def test_different_files_fail(self) -> None:
        c = _check(
            "file_pair_hash",
            "testdata/fixtures/repo-a/specs/task-spec.json",
            "testdata/fixtures/repo-b/generated/task-spec-drifted.json",
        )
        result = run_file_pair_hash_check(c, _REPO_ROOT)
        assert result.status == "fail"
        assert "differ" in result.summary

    def test_missing_file_fails(self) -> None:
        c = _check(
            "file_pair_hash",
            "testdata/fixtures/repo-a/specs/task-spec.json",
            "testdata/fixtures/repo-b/generated/nonexistent.json",
        )
        result = run_file_pair_hash_check(c, _REPO_ROOT)
        assert result.status == "fail"
        assert "missing" in result.summary.lower()

    def test_bad_params_error(self) -> None:
        c = CheckConfig(
            id="test-check",
            type="file_pair_hash",
            severity="high",
            params={"left": 123},  # not a string
        )
        result = run_file_pair_hash_check(c, _REPO_ROOT)
        assert result.status == "error"

    def test_severity_preserved(self) -> None:
        c = _check(
            "file_pair_hash",
            "testdata/fixtures/repo-a/specs/task-spec.json",
            "testdata/fixtures/repo-b/generated/task-spec.json",
            severity="critical",
        )
        result = run_file_pair_hash_check(c, _REPO_ROOT)
        assert result.severity == "critical"


class TestJSONSchemaCompat:
    def test_identical_schemas_pass(self) -> None:
        c = _check(
            "json_schema_compat",
            "testdata/fixtures/repo-a/specs/task-spec.json",
            "testdata/fixtures/repo-b/generated/task-spec.json",
            severity="medium",
        )
        result = run_json_schema_compat_check(c, _REPO_ROOT)
        assert result.status == "pass"
        assert "safe" in result.summary.lower()

    def test_removed_required_fields_fail(self) -> None:
        c = _check(
            "json_schema_compat",
            "testdata/fixtures/repo-a/specs/task-spec.json",
            "testdata/fixtures/repo-b/generated/task-spec-missing-fields.json",
            severity="medium",
        )
        result = run_json_schema_compat_check(c, _REPO_ROOT)
        assert result.status == "fail"
        assert "required" in result.summary.lower()

    def test_added_fields_pass(self) -> None:
        """When the right side has MORE fields, that's not a breaking change."""
        c = _check(
            "json_schema_compat",
            "testdata/fixtures/repo-b/generated/task-spec-missing-fields.json",
            "testdata/fixtures/repo-a/specs/task-spec.json",
            severity="medium",
        )
        result = run_json_schema_compat_check(c, _REPO_ROOT)
        # Adding fields is safe, so pass
        assert result.status == "pass"

    def test_missing_file_fails(self) -> None:
        c = _check(
            "json_schema_compat",
            "testdata/fixtures/repo-a/specs/task-spec.json",
            "testdata/fixtures/repo-b/generated/nonexistent.json",
            severity="medium",
        )
        result = run_json_schema_compat_check(c, _REPO_ROOT)
        assert result.status == "fail"

    def test_extra_properties_warn(self) -> None:
        """When properties are removed (but not required fields), it's a warn."""
        c = _check(
            "json_schema_compat",
            "testdata/fixtures/repo-a/specs/task-spec.json",
            "testdata/fixtures/repo-b/generated/task-spec-missing-fields.json",
            severity="medium",
        )
        result = run_json_schema_compat_check(c, _REPO_ROOT)
        # This file removes "name" from required AND from properties
        # So it should be "fail" (required fields removed), not just "warn"
        assert result.status == "fail"
