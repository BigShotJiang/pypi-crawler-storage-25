"""crewai-no-vibes — CrewAI Task guardrail blocking verification claims without evidence.

Implements the `no-vibes` detector (MAST mode 3.3 "No or Incorrect Verification")
as a pure-Python port of the `evidence_claims` rule pack from
waitdeadai/agent-closeout-bench. Drop-in for CrewAI Task.guardrails.

Empirical baseline (MAST mode 3.3):
  - F1 0.815 (95% CI [0.615, 0.941]) on n=19 human-labelled MAD traces
  - F1 0.308 (95% CI [0.264, 0.352]) on n=954 LLM-judge-labelled MAD traces
  - Inter-annotator Fleiss kappa 1.000 for mode 3.3 on the released subset

Source: https://github.com/waitdeadai/llm-dark-patterns/blob/main/evaluation/MAST-RESULTS.md
"""
from .detector import is_done_without_evidence, extract_features, Features
from .guardrail import verification_claim_evidence_guardrail, make_guardrail

__version__ = "0.1.0"
__all__ = [
    "is_done_without_evidence",
    "extract_features",
    "Features",
    "verification_claim_evidence_guardrail",
    "make_guardrail",
]
