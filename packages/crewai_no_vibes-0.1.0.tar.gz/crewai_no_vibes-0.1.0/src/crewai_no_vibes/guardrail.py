"""CrewAI Task.guardrails wrapper for the no-vibes detector.

CrewAI's function-based guardrail contract:
    Callable[[TaskOutput], tuple[bool, str | TaskOutput]]

Where:
    return (True, output)   — pass; downstream task receives `output`
    return (False, feedback) — fail; agent retries with `feedback` as context

Reference: https://docs.crewai.com/en/concepts/tasks (Task guardrails section)
PR that introduced the feature: https://github.com/crewAIInc/crewAI/pull/1742
"""
from __future__ import annotations

from typing import Any, Callable, Optional, Tuple

from .detector import extract_features, is_done_without_evidence


_DEFAULT_FEEDBACK = (
    "Verification claim without evidence detected. The output claims completion "
    "(e.g. 'done', 'verified', 'fixed', 'shipped') but does not provide evidence "
    "of verification — no commands run, no test output, no inspection trace, or "
    "the message contains negative evidence markers like 'not run' / 'unverified'.\n\n"
    "To pass this guardrail, the output should include at least one of:\n"
    "  - `Commands run: <exact command>` followed by output excerpt\n"
    "  - `Verification: passed/blocked with detail` referencing a test or check\n"
    "  - For read-only work: `Files inspected:` or `Sources reviewed:` lines\n"
    "  - Or close honestly as `Status: partial` / `Status: blocked` instead of done.\n\n"
    "Empirical basis: MAST mode 3.3 'No or Incorrect Verification' detector, "
    "F1 0.815 (95% CI [0.615, 0.941]) on n=19 human-labelled MAD traces. "
    "See https://github.com/waitdeadai/llm-dark-patterns/blob/main/evaluation/MAST-RESULTS.md"
)


def _extract_text(task_output: Any) -> str:
    """Extract text from a CrewAI TaskOutput-shaped object.

    CrewAI's TaskOutput exposes `.raw` (string) at minimum. Some versions also
    expose `.exported_output`, `.output`, or stringify usefully via str(). We
    try in order of preference and fall back to str().
    """
    for attr in ("raw", "exported_output", "output", "result"):
        value = getattr(task_output, attr, None)
        if isinstance(value, str) and value.strip():
            return value
    return str(task_output)


def verification_claim_evidence_guardrail(task_output: Any) -> Tuple[bool, Any]:
    """Drop-in CrewAI Task.guardrails function for the no-vibes detector.

    Usage:
        from crewai import Task
        from crewai_no_vibes import verification_claim_evidence_guardrail

        task = Task(
            description="...",
            expected_output="...",
            guardrail=verification_claim_evidence_guardrail,
        )

    Returns:
        (True, task_output)  if the output does NOT exhibit done_without_evidence
        (False, feedback)    if it does — agent will retry per CrewAI's retry policy
    """
    text = _extract_text(task_output)
    if is_done_without_evidence(text):
        return False, _DEFAULT_FEEDBACK
    return True, task_output


def make_guardrail(
    custom_feedback: Optional[str] = None,
    require_command_or_verification: bool = False,
) -> Callable[[Any], Tuple[bool, Any]]:
    """Factory for a configurable guardrail.

    Args:
        custom_feedback: replace the default feedback message returned on block.
        require_command_or_verification: if True, ALSO block when the output
            lacks command/verification evidence regardless of completion-claim
            (i.e. stricter than the upstream rule pack). Default False matches
            the ACB rule pack's behavior.

    Returns:
        A guardrail function matching CrewAI's expected signature.
    """
    feedback_msg = custom_feedback or _DEFAULT_FEEDBACK

    def _guardrail(task_output: Any) -> Tuple[bool, Any]:
        text = _extract_text(task_output)
        features = extract_features(text)

        block = features.done_without_evidence
        if require_command_or_verification and features.claims_completion:
            block = block or not features.has_evidence_marker

        if block:
            return False, feedback_msg
        return True, task_output

    _guardrail.__name__ = "no_vibes_guardrail"
    return _guardrail
