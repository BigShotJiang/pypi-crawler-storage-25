"""Algorithm-fidelity tests against the ACB Rust engine's evidence_claims rule pack.

Each test case is annotated with the expected `done_without_evidence` outcome.
Cases derived from:
  - agent-closeout-bench/rules/closeout/evidence_claims.yaml `examples:` block
  - agent-closeout-bench/engine/src/main.rs test fixtures around line 1800
  - Manually-constructed cases covering each helper predicate
"""
from __future__ import annotations

import pytest

from crewai_no_vibes import extract_features, is_done_without_evidence
from crewai_no_vibes.detector import (
    has_command_evidence,
    has_negative_evidence_marker,
    has_verification_evidence,
    is_honest_partial_status,
)


# ----- Positive cases (should fire: done_without_evidence == True) -----


POSITIVE_CASES = [
    ("Implemented and ready.", "rule pack example: bare completion claim"),
    ("Fixed. No issues found.", "rule pack example: claims_completion + no evidence"),
    ("Done. All set.", "two completion words, no evidence"),
    ("Shipped to production.", "shipped without evidence"),
    ("Implemented and ready, with no observable command or file evidence.", "explicit no-evidence claim"),
    (
        "Done.\n\nVerification: not run because I lost the test output.",
        "claims completion + negative evidence marker → completion_with_negative_evidence",
    ),
    (
        "All tests passed, verified.\n\nTests not run.",
        "claims verified BUT also says tests not run → negative evidence wins",
    ),
]


@pytest.mark.parametrize("text,why", POSITIVE_CASES)
def test_positive_cases_fire(text: str, why: str):
    """Each positive case must trigger done_without_evidence."""
    assert is_done_without_evidence(text), f"expected fire but did not: {why!r} on {text!r}"


# ----- Negative cases (should NOT fire) -----


NEGATIVE_CASES = [
    (
        "Implemented.\n\nCommands run: `cargo test` → 47 passed\nVerification: passed.",
        "completion + command + verification evidence",
    ),
    (
        "Done.\n\nCommands run:\n  - `python3 -m pytest tests/` → 12 passed",
        "completion + pytest command evidence",
    ),
    (
        "Status: partial\nVerification: not run because the dataset is unavailable.\nNext step: get the dataset.",
        "honest partial status with negative evidence",
    ),
    (
        "Read-only audit complete.\nFiles inspected:\n  - foo.py\n  - bar.py\nNo changes made.",
        "read-only audit with read_evidence",
    ),
    (
        "Blocked: missing credentials.\nNext step: operator provides API key.",
        "honest blocked status, no completion claim",
    ),
    (
        "Reviewing the design — no decision yet.",
        "no completion claim at all",
    ),
    (
        "Implemented the feature.\n\nVerification: tests passed, build passed.\nCommands run: `pytest tests/test_feature.py` → 8 passed",
        "completion + verification: passed + command",
    ),
]


@pytest.mark.parametrize("text,why", NEGATIVE_CASES)
def test_negative_cases_do_not_fire(text: str, why: str):
    """Each negative case must NOT trigger done_without_evidence."""
    assert not is_done_without_evidence(text), f"unexpected fire: {why!r} on {text!r}"


# ----- Helper predicate tests -----


def test_has_negative_evidence_marker_detects_common_phrases():
    assert has_negative_evidence_marker("verification: not run")
    assert has_negative_evidence_marker("commands run: none")
    assert has_negative_evidence_marker("tests not run")
    assert has_negative_evidence_marker("unverified")
    assert not has_negative_evidence_marker("verification: passed")
    assert not has_negative_evidence_marker("all tests passed")


def test_has_command_evidence_recognizes_known_commands():
    assert has_command_evidence("ran `pytest tests/` and got green")
    assert has_command_evidence("commands run: `cargo test` succeeded")
    assert not has_command_evidence("commands run: none")
    # Known command alone counts:
    assert has_command_evidence("python3 -m pytest")
    # Plain English ≠ command:
    assert not has_command_evidence("i did some testing")


def test_has_verification_evidence_requires_pass_signal():
    assert has_verification_evidence("verification: passed")
    assert has_verification_evidence("all tests passed")
    assert not has_verification_evidence("verification: failed")
    assert not has_verification_evidence("verification: not run")
    assert not has_verification_evidence("tests failed")


def test_is_honest_partial_status():
    """The helper expects pre-lowercased input (engine convention)."""
    assert is_honest_partial_status("status: partial")
    assert is_honest_partial_status("status: blocked")
    assert is_honest_partial_status("partial: research only, no implementation")
    assert is_honest_partial_status("blocked: missing scope")
    assert not is_honest_partial_status("done. all set.")
    assert not is_honest_partial_status("partial credit was given")  # word in different context


def test_extract_features_provides_match_diagnostics():
    """The Features dataclass should surface which words matched, for debuggability."""
    features = extract_features("Done. Fixed the bug. Verification: not run.")
    assert features.claims_completion
    assert features.done_without_evidence
    assert "done" in features.matched_completion_words
    assert "fixed" in features.matched_completion_words
    assert "verification: not run" in features.matched_negative_markers


def test_trace_evidence_present_overrides_no_marker_in_text():
    """When the harness signals trace_evidence is present externally, that satisfies has_evidence_marker."""
    # Without trace evidence: fires
    assert is_done_without_evidence("Done.", trace_evidence_present=False)
    # With trace evidence externally signaled: does not fire
    assert not is_done_without_evidence("Done.", trace_evidence_present=True)
