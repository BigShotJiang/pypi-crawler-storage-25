"""CrewAI guardrail contract tests.

These tests mock the CrewAI TaskOutput interface rather than importing crewai
itself (CrewAI is a heavyweight dependency we don't need at test time, just at
runtime when a user actually wires the guardrail into a Task).
"""
from __future__ import annotations

from dataclasses import dataclass

import pytest

from crewai_no_vibes import make_guardrail, verification_claim_evidence_guardrail


@dataclass
class MockTaskOutput:
    """Minimal CrewAI TaskOutput stand-in.

    Real CrewAI TaskOutput has more fields; we only need `.raw` per the docs.
    """

    raw: str


def test_passes_output_with_evidence():
    """Output with command + verification evidence should pass."""
    out = MockTaskOutput(
        raw="Implemented the feature.\n\nCommands run: `pytest tests/` → 8 passed\nVerification: passed."
    )
    ok, returned = verification_claim_evidence_guardrail(out)
    assert ok is True
    assert returned is out  # pass-through


def test_blocks_output_without_evidence():
    """Output claiming completion with no evidence should block."""
    out = MockTaskOutput(raw="Done. All set. Implemented and ready.")
    ok, feedback = verification_claim_evidence_guardrail(out)
    assert ok is False
    assert isinstance(feedback, str)
    assert "verification" in feedback.lower()
    assert "MAST" in feedback  # citation present


def test_blocks_completion_with_negative_evidence_marker():
    """Completion claim AND 'not run' marker is the classic catch."""
    out = MockTaskOutput(raw="Fixed. Verification: not run because I forgot.")
    ok, feedback = verification_claim_evidence_guardrail(out)
    assert ok is False
    assert "Status: partial" in feedback or "partial" in feedback.lower()


def test_passes_honest_partial_status():
    """Honest partial closeout WITHOUT completion vocabulary should pass.

    Note: the algorithm is strict — saying 'Status: partial' alone does NOT
    bypass the guardrail if the message also contains completion words like
    'fixed' or 'shipped' but no actual evidence markers. Real honest partial
    closeouts describe in-progress state without claiming completion.
    """
    out = MockTaskOutput(
        raw=(
            "Status: partial. The parser scaffolding is drafted but I have not "
            "verified it.\nFiles inspected: src/parser.py\n"
            "Verification: not run because no test fixture exists.\n"
            "Next step: write fixture, then pytest tests/test_parser.py."
        )
    )
    ok, _ = verification_claim_evidence_guardrail(out)
    assert ok is True


def test_blocks_partial_status_with_completion_vocabulary_but_no_evidence():
    """The algorithm correctly catches 'Status: partial. Fixed X' without evidence —
    that pattern is the exact dishonesty the rule targets."""
    out = MockTaskOutput(
        raw="Status: partial.\nFixed the parser but couldn't run tests.\nNext step: try again."
    )
    ok, feedback = verification_claim_evidence_guardrail(out)
    assert ok is False
    assert isinstance(feedback, str)


def test_passes_read_only_audit():
    """Read-only audit with files-inspected list should pass."""
    out = MockTaskOutput(
        raw="Read-only audit complete.\nFiles inspected:\n  - src/parser.py\n  - tests/test_parser.py\nNo changes."
    )
    ok, _ = verification_claim_evidence_guardrail(out)
    assert ok is True


def test_passes_non_completion_output():
    """Output that doesn't claim completion at all should pass."""
    out = MockTaskOutput(raw="The user has three options to consider before we proceed.")
    ok, _ = verification_claim_evidence_guardrail(out)
    assert ok is True


def test_extract_text_falls_back_to_str():
    """When TaskOutput has no .raw, the guardrail should still work via str()."""

    class WeirdOutput:
        def __str__(self) -> str:
            return "Done. Implemented and ready."

    ok, _ = verification_claim_evidence_guardrail(WeirdOutput())
    assert ok is False  # still catches the vibes-y closeout


def test_make_guardrail_custom_feedback():
    """Factory should let users override the feedback message."""
    g = make_guardrail(custom_feedback="Please show test output, friend.")
    ok, feedback = g(MockTaskOutput(raw="Done. All set."))
    assert ok is False
    assert feedback == "Please show test output, friend."


def test_make_guardrail_strict_mode():
    """In strict mode, completion claim without evidence-marker blocks even if no negative marker."""
    g = make_guardrail(require_command_or_verification=True)
    out = MockTaskOutput(raw="Verified the feature works as expected.")
    ok, _ = g(out)
    # In strict mode this fires (no command/verification evidence despite no negative marker either)
    assert ok is False
