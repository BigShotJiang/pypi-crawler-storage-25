def main():
    print("Hello from acprouter!")


if __name__ == "__main__":
    main()
