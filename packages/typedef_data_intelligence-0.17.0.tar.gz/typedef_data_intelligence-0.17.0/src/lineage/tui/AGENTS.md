# TUI Development Guide

This directory contains the Textual-based terminal UI for the typedef Data Intelligence platform.

## Style Guide

**Read before making visual changes:** [docs/design/tui-style-guide.md](../../../../docs/design/tui-style-guide.md)

If a requested change conflicts with the style guide, discuss with the user
before implementing. Determine whether the guidelines should be updated to
reflect the new pattern, or whether a one-time exception is appropriate.
Guidelines are living documentation—update them when design evolves.

Key principles:

- **Borderless design** - Use background color layers, not structural borders
- **Left-edge accent borders** - Communicate message ownership and state
- **Vertical space economy** - Every terminal row matters
- **Consistent margins** - `margin: 1 2 0 2` for content blocks

## File Structure

```
tui/
├── app.py          # Main app, StatusBar, tab management
├── backend.py      # Backend connection handling
├── styles.tcss     # All CSS styles (single source of truth)
├── screens/        # Screen-level components (chat, tickets, etc.)
└── widgets/        # Reusable widget components
```

## Key Patterns

### Adding New Styles

All styles go in `styles.tcss`. Follow existing section organization:

```tcss
/* ==================================================================
   Section Name
   ================================================================== */
```

### Message Variants

Use the `.message` base class with role modifiers:

```tcss
.message.user { ... }
.message.assistant { ... }
.message.tool { ... }
.message.error { ... }
```

### Collapsible Blocks

Follow the pattern in `.thinking-block` and `.tool-result-block`:

- Single-line header (`height: 1`)
- Constrained body (`max-height` + `overflow-y: auto`)
- No outer borders

### Keyboard Shortcuts

Add to widget's `BINDINGS` class attribute with matching `action_*` method.
Update StatusBar key hints in `app.py` if globally visible.

For tab-specific shortcuts, prefer a two-layer approach:

- Screen/widget-level bindings for local behavior (`screens/*.py`)
- App-level routing in `app.py` for focus-independent reliability when the tab is active

This avoids the common Textual focus trap where shortcuts only work when a
specific child widget currently has focus.

## Recent Learnings (Daemon + Tickets Polish)

- Keep non-chat tabs keyboard-first (`Tickets`: `r/i/c`, `Daemon`: `s/r/i`) and
  ensure they work from tab header, table, and log focus states.
- Route ambiguous keys by active tab in `app.py` (for example, `r` can mean
  Tickets refresh or Daemon Reconciler selection).
- Prefer class-based state styling over inline style churn; update classes in
  Python and keep visuals in `styles.tcss`.
- For daemon status icons, avoid mixed-width emoji pairs (for example `⏸` vs
  `✅`) because terminal font rendering can shift spacing. Use width-stable
  glyphs instead (for example `○`/`●`) and color classes for state.
- Keep status/header rows visually light (transparent backgrounds when
  appropriate) and reserve heavier surfaces for data panes.
- Use punctuation-free section headers (for example `Pending Tickets`,
  `Activity Log`) and keep header-to-pane spacing uniform.
- Keep styles centralized in `styles.tcss`; avoid local `DEFAULT_CSS` on
  screens unless there is a strong reason.

## Test Patterns To Keep

- Add compose/class wiring tests for each tab to lock style hooks.
- Add app-level shortcut routing tests to prevent regressions when focus is not
  inside the target widget.
- Add status-hint tests when shortcut behavior changes.

## Example Implementation Checklist

- Confirm visual intent against `docs/design/tui-style-guide.md` before coding.
- Add or update screen-level `BINDINGS` and `action_*` handlers.
- Add or update app-level shortcut routing for focus-independent tab behavior.
- Update StatusBar key hints in `app.py` when global or tab-visible keys change.
- Add stable style classes/ids in `screens/*.py`; keep all styles in `styles.tcss`.
- Prefer state classes (`add_class` / `remove_class`) over inline style mutation.
- Verify section title spacing and punctuation are consistent with tab conventions.
- Add/adjust tests: shortcut routing, compose/style hooks, and status hints.
- Run targeted TUI tests, then do a quick interactive pass in `uv run typedef chat`.

## Testing

```bash
cd typedef_data_intelligence && uv run typedef chat
```
