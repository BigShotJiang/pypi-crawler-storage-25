"""Shared typedef TUI theme tokens."""

from textual.theme import Theme

PRIMARY = "#829df3"
SECONDARY = "#6a3cd9"
ACCENT = "#ffbf30"
WARNING = "#ffbf30"
FOREGROUND = "#ffffff"
BACKGROUND = "#111111"
SURFACE = "#131a24"
PANEL = "#192330"
ERROR_RED = "#eb5757"
SUCCESS = "#45BF55"

TYPEDEF_THEME = Theme(
    name="typedef",
    primary=PRIMARY,
    secondary=SECONDARY,
    accent=ACCENT,
    foreground=FOREGROUND,
    background=BACKGROUND,
    surface=SURFACE,
    panel=PANEL,
    warning=WARNING,
    error=ERROR_RED,
    success=SUCCESS,
    dark=True,
)
