"""Hidden key inspector screen for diagnosing terminal key mappings."""

from textual import events
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import Label, Static


class KeyInspectorScreen(ModalScreen[None]):
    """Modal that shows raw key events as Textual receives them."""

    BINDINGS = [
        Binding("escape", "close", "Close", show=True),
        Binding("ctrl+alt+k", "close", "Close", show=False),
    ]

    DEFAULT_CSS = """
    KeyInspectorScreen {
        align: center middle;
    }

    KeyInspectorScreen > Container {
        width: 84;
        height: 24;
        background: $surface;
        border: tall $primary;
        padding: 1;
    }

    #key-inspector-header {
        text-style: bold;
        margin-bottom: 1;
    }

    #key-inspector-output {
        height: 1fr;
        background: $background-darken-1;
        border-left: solid $primary 35%;
        padding: 0 1;
    }

    #key-inspector-footer {
        color: $text-muted;
        margin-top: 1;
    }
    """

    def __init__(self, max_events: int = 20) -> None:
        """Initialize key inspector with a bounded in-memory event list."""
        super().__init__()
        self.max_events = max_events
        self.event_lines: list[str] = []

    def compose(self) -> ComposeResult:
        """Compose the inspector modal layout."""
        with Container():
            yield Label("Key Inspector", id="key-inspector-header")
            with VerticalScroll(id="key-inspector-output"):
                yield Static(
                    "Press keys to inspect Textual input events...", id="key-log"
                )
            yield Label(
                "Esc closes. Hidden toggles: Ctrl+Alt+K, Ctrl+Shift+K, F12",
                id="key-inspector-footer",
            )

    def _render_lines(self) -> None:
        """Render recorded key events into the inspector output widget."""
        log = self.query_one("#key-log", Static)
        log.update("\n".join(self.event_lines) if self.event_lines else "(no keys yet)")

    def record_key_data(self, key: str, character: str | None, name: str) -> None:
        """Record one key event and refresh the on-screen log if mounted."""
        line = f"key={key!r} character={character!r} name={name!r}"
        self.event_lines.append(line)
        if len(self.event_lines) > self.max_events:
            self.event_lines = self.event_lines[-self.max_events :]

        if self.is_mounted:
            self._render_lines()

    def on_key(self, event: events.Key) -> None:
        """Capture key events and append their raw fields to the log."""
        self.record_key_data(event.key, event.character, event.name)

    def action_close(self) -> None:
        """Close the key inspector modal."""
        self.dismiss()
