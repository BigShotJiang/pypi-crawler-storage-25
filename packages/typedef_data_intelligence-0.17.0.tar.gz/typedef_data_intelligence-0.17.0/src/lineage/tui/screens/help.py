"""Help screen for the TUI application."""

import logging
from pathlib import Path

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import Label, Markdown, Static

logger = logging.getLogger(__name__)

# Path to the agent user guide documentation
DOCS_PATH = (
    Path(__file__).parent.parent.parent.parent.parent
    / "docs"
    / "reference"
    / "AGENT_USER_GUIDE.md"
)

# Fallback content if the file is not found
FALLBACK_HELP = """
# Data Concierge Help

## Getting Started

If you haven't set up yet:

```text
typedef init    # Run setup wizard
typedef sync    # Sync dbt metadata
typedef chat    # Launch this TUI
```

## Agents Quick Reference

| Agent | Best For |
|-------|----------|
| **Analyst** | Business questions, reports, visualizations |
| **Investigator** | Troubleshooting data discrepancies |
| **Insights** | Understanding data architecture |
| **Copilot** | Building/modifying dbt models |

## Choosing an Agent

- **"What was ARR last month?"** → Analyst
- **"Why is ARR wrong?"** → Investigator
- **"How does ARR get calculated?"** → Insights
- **"Add region to the ARR model"** → Copilot

## Keyboard Shortcuts

| Key | Action |
|-----|--------|
| `F1` | Open full help |
| `?` / `Ctrl+/` | Open shortcuts modal |
| `Tab` / `Shift+Tab` | Move UI focus |
| `Ctrl+,` | Previous agent |
| `Ctrl+.` | Next agent |
| `Escape` | Close help / Stop agent |
| `Enter` | Send message |
| `Shift+Enter` | Insert newline |
| `/new` / `/clear` | Reset chat session |
| `q` / `Ctrl+Q` | Cancel running agent |
| `Ctrl+C` (twice) | Quit application |

## Tips

- **Be specific** with your questions for better results
- **Analyst** only works with existing semantic views
- **Copilot** always asks for approval before making changes
- When in doubt, ask **Insights** to explain your data

Press `Escape` to dismiss this help.
"""

TUI_SHORTCUTS_HELP = """
## TUI Keyboard Shortcuts

| Key | Action |
|-----|--------|
| `F1` | Open full help |
| `?` / `Ctrl+/` | Open shortcuts modal |
| `Ctrl+,` / `Ctrl+.` | Toggle agent |
| `Tab` / `Shift+Tab` | Move UI focus |
| `i` | Focus chat input |
| `Ctrl+A` | Open artifacts |
| `Ctrl+G` | Open activity |
| `Escape` | Stop agent / close help |
| `Enter` | Send message |
| `Shift+Enter` | Insert newline |
| `/new` / `/clear` | Reset current chat session |

Tip: Start a new chat to open the agent chooser.
"""


class HelpScreen(ModalScreen[None]):
    """Modal screen displaying help documentation."""

    BINDINGS = [
        Binding("escape", "close", "Close", show=True),
        Binding("q", "close", "Close", show=False),
        Binding("ctrl+c", "app.confirm_exit", "Exit", show=False),
    ]

    def __init__(self) -> None:
        """Initialize the help screen."""
        super().__init__()
        self._help_title = "Data Concierge Help"
        self._help_content = self._load_help_content()

    def _load_help_content(self) -> str:
        """Load help content from markdown file or use fallback."""
        if DOCS_PATH.exists():
            try:
                content = DOCS_PATH.read_text(encoding="utf-8")
                return self._append_shortcuts(content)
            except Exception as e:
                logger.warning(f"Error loading help content from {DOCS_PATH}: {e}")
        return self._append_shortcuts(FALLBACK_HELP)

    def _append_shortcuts(self, content: str) -> str:
        """Append canonical TUI shortcut section to help markdown."""
        if "## TUI Keyboard Shortcuts" in content:
            return self._strip_top_heading(content)
        merged = f"{content.rstrip()}\n\n{TUI_SHORTCUTS_HELP.strip()}\n"
        return self._strip_top_heading(merged)

    def _strip_top_heading(self, content: str) -> str:
        """Remove leading H1 to avoid duplicate title in modal body."""
        lines = content.splitlines()
        start = 0
        while start < len(lines) and not lines[start].strip():
            start += 1
        if start < len(lines) and lines[start].startswith("# "):
            self._help_title = lines[start][2:].strip() or self._help_title
            start += 1
            while start < len(lines) and not lines[start].strip():
                start += 1
            return "\n".join(lines[start:]).rstrip() + "\n"
        return content

    def compose(self) -> ComposeResult:
        """Create child widgets."""
        with Container(classes="help-modal", id="help-modal"):
            with Static(id="help-header", classes="help-modal-header"):
                yield Label(self._help_title)
            with VerticalScroll(id="help-content", classes="help-modal-content"):
                yield Markdown(self._help_content)
            with Static(id="help-footer", classes="help-modal-footer"):
                with Horizontal(classes="help-footer-row"):
                    yield Label("esc", classes="help-footer-key")
                    yield Label("to close", classes="help-footer-text")

    def action_close(self) -> None:
        """Close the help screen."""
        self.dismiss()
