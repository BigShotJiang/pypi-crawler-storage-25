"""Compact modal screen showing current session status."""

from dataclasses import dataclass
from typing import Optional

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal, Vertical, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import Label, Static

# Connection status rendering (uses same color scheme as StatusBar)
_STATE_COLOR_SUCCESS = "#a6e3a1"
_STATE_COLOR_WARNING = "#f9e2af"
_STATE_COLOR_ERROR = "#f38ba8"
_STATE_COLOR_MUTED = "#a6adc8"


def _render_connection_state(value: str) -> str:
    """Render connection state with static colored circle (same palette as StatusBar)."""
    if value in {"starting", "pending"}:
        return f"[{_STATE_COLOR_WARNING}]○[/] {value}"
    if value in {"ready", "connected"}:
        return f"[{_STATE_COLOR_SUCCESS}]●[/] {value}"
    if value == "error":
        return f"[{_STATE_COLOR_ERROR}]○[/] {value}"
    return f"[{_STATE_COLOR_MUTED}]○[/] {value}"


def _format_uptime(seconds: float) -> str:
    """Format uptime seconds as human-readable string."""
    minutes, secs = divmod(int(seconds), 60)
    hours, minutes = divmod(minutes, 60)
    if hours > 0:
        return f"{hours}h {minutes}m"
    if minutes > 0:
        return f"{minutes}m {secs}s"
    return f"{secs}s"


@dataclass
class StatusData:
    """Snapshot of session state for status display."""

    agent_name: str
    model: str
    thread_id: str
    uptime_seconds: float
    context_cap: int
    message_count: int
    user_message_count: int
    assistant_message_count: int
    last_run_id: Optional[str]
    last_run_duration: Optional[float]
    last_run_tool_calls: int
    artifact_count: int
    activity_count: int
    backend_status: str
    graph_status: str
    data_status: str
    project_name: str
    verbose_mode: bool
    flat_mode: bool


class StatusScreen(ModalScreen[None]):
    """Modal screen showing concise session status information."""

    BINDINGS = [
        Binding("escape", "close", "Close", show=True),
        Binding("q", "close", "Close", show=False),
        Binding("ctrl+c", "app.confirm_exit", "Exit", show=False),
    ]

    def __init__(self, data: StatusData) -> None:
        """Initialize with a snapshot of session status data."""
        super().__init__()
        self._data = data

    def compose(self) -> ComposeResult:
        """Create compact status modal widgets."""
        d = self._data
        with Container(classes="help-modal status-modal", id="status-modal"):
            yield Static("~ ~ ~", classes="chat-agent-decoration")
            yield Label("session status", classes="chat-agent-title")
            yield Static("~ ~ ~", classes="chat-agent-decoration")
            with VerticalScroll(id="status-content", classes="help-modal-content"):
                with Vertical(classes="shortcuts-block"):
                    # Session section
                    yield from self._section(
                        "session",
                        [
                            ("agent", d.agent_name),
                            ("model", d.model),
                            ("thread", d.thread_id),
                            ("uptime", _format_uptime(d.uptime_seconds)),
                            ("context cap", str(d.context_cap)),
                        ],
                        first=True,
                    )
                    # Messages section
                    yield from self._section(
                        "messages",
                        [
                            ("total", str(d.message_count)),
                            ("user", str(d.user_message_count)),
                            ("assistant", str(d.assistant_message_count)),
                        ],
                    )
                    # Last run section
                    if d.last_run_id:
                        duration_str = (
                            f"{d.last_run_duration:.1f}s"
                            if d.last_run_duration is not None
                            else "-"
                        )
                        yield from self._section(
                            "last run",
                            [
                                ("run id", d.last_run_id),
                                ("duration", duration_str),
                                ("tool calls", str(d.last_run_tool_calls)),
                            ],
                        )
                    # Artifacts section
                    yield from self._section(
                        "artifacts",
                        [
                            ("artifacts", str(d.artifact_count)),
                            ("activities", str(d.activity_count)),
                        ],
                    )
                    # Connections section
                    yield from self._section(
                        "connections",
                        [
                            ("backend", _render_connection_state(d.backend_status)),
                            ("graph", _render_connection_state(d.graph_status)),
                            ("data", _render_connection_state(d.data_status)),
                        ],
                    )
                    # Config section
                    yield from self._section(
                        "config",
                        [
                            ("project", d.project_name),
                            ("verbose", "on" if d.verbose_mode else "off"),
                            ("flat mode", "on" if d.flat_mode else "off"),
                        ],
                    )
            with Horizontal(classes="shortcuts-footer"):
                with Horizontal(classes="shortcuts-footer-left"):
                    yield Label("esc", classes="shortcuts-footer-key")
                    yield Label("to close", classes="shortcuts-footer-text")

    @staticmethod
    def _section(
        title: str, rows: list[tuple[str, str]], *, first: bool = False
    ) -> list[Vertical]:
        """Build a section with title and key-value rows."""
        title_classes = "shortcuts-section-title"
        if first:
            title_classes += " status-section-first"
        children: list[Static | Horizontal] = []
        for key, value in rows:
            children.append(
                Horizontal(
                    Static(key, classes="status-key"),
                    Static(value, classes="status-value"),
                    classes="shortcuts-row",
                )
            )
        section = Vertical(
            Label(title, classes=title_classes),
            *children,
            classes="shortcuts-section",
        )
        return [section]

    def action_close(self) -> None:
        """Close the status modal."""
        self.dismiss()
