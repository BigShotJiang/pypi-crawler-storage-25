"""Artifacts modal screen for focused artifact exploration."""

import inspect
from typing import Awaitable, Callable, Optional

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal
from textual.screen import ModalScreen
from textual.widgets import Label, Static

from lineage.tui.widgets.artifacts import ArtifactViewer, ExportReportRequest


class ArtifactsScreen(ModalScreen[None]):
    """Modal screen that presents a modal-local artifact viewer."""

    BINDINGS = [
        Binding("escape", "close", "Close", show=True),
        Binding("q", "close", "Close", show=False),
        Binding("ctrl+c", "app.confirm_exit", "Exit", show=False),
    ]

    def __init__(
        self,
        source_viewer: ArtifactViewer,
        on_export_report: Optional[Callable[[str, str], Awaitable[None] | None]] = None,
    ) -> None:
        """Initialize modal with a source viewer to mirror from."""
        super().__init__()
        self._source_viewer = source_viewer
        self._on_export_report = on_export_report
        self.viewer = ArtifactViewer()

    def compose(self) -> ComposeResult:
        """Build modal content."""
        with Container(classes="artifacts-modal", id="artifacts-modal"):
            with Static(id="artifacts-header", classes="help-modal-header"):
                yield Label("Artifacts")
            with Container(classes="artifacts-modal-body", id="artifacts-viewer-host"):
                yield self.viewer
            with Static(id="artifacts-footer", classes="help-modal-footer"):
                with Horizontal(classes="help-footer-row"):
                    yield Label("esc", classes="help-footer-key")
                    yield Label("to close", classes="help-footer-text")

    def _refresh_modal_viewer(self) -> None:
        """Mirror source artifacts/activity into modal-local viewer."""
        self.viewer.populate_from(
            artifacts=self._source_viewer.artifacts,
            activities=self._source_viewer.activities,
        )
        if self.viewer.artifacts:
            self.viewer.artifact_list.focus()
            return

    def on_mount(self) -> None:
        """Hydrate modal-local viewer from source state."""
        self.call_after_refresh(self._refresh_modal_viewer)

    async def on_export_report_request(self, event: ExportReportRequest) -> None:
        """Forward exports to chat handler and refresh viewer state."""
        if not callable(self._on_export_report):
            return
        result = self._on_export_report(event.report_id, event.artifact_id)
        if inspect.isawaitable(result):
            await result
        self._refresh_modal_viewer()
        self.viewer.select_artifact_by_id(event.artifact_id)

    def action_close(self) -> None:
        """Dismiss modal."""
        self.dismiss()
