"""Backend manager for TUI application.

This module handles spawning and managing the local API server subprocess.
"""

import asyncio
import json
import logging
import os
import secrets
import signal
import socket
import subprocess  # nosec B404 - used to spawn internal API server
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import IO, Any, Optional

import httpx
from core.paths import logs_dir, typedef_home

from lineage.utils.env import load_env_file

logger = logging.getLogger(__name__)


@dataclass
class _BackendMarker:
    """Serialized ownership marker for stale-backend reaping."""

    pid: int
    pgid: int | None
    started_at_epoch: int | None
    instance_token: str
    python_executable: str
    active_project: str | None
    created_at_epoch: int


class BackendManager:
    """Manages the local API server process."""

    STOP_TERM_TIMEOUT_SECONDS = 5
    STOP_KILL_WAIT_SECONDS = 2

    def __init__(self):
        """Initialize the backend manager."""
        self.port: int = self._find_free_port()
        self.process: Optional[subprocess.Popen] = None
        self.log_fp: Optional[IO[str]] = None
        self.host = "localhost"
        self.base_url = f"http://{self.host}:{self.port}"

        # Setup log directory (alongside client logs)
        self.log_dir = logs_dir()
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.log_file = self.log_dir / "tui-backend.log"
        self.marker_file = typedef_home() / "tui-backend-owner.json"
        self.instance_token = secrets.token_hex(16)

    def _find_free_port(self) -> int:
        """Find a free port on localhost."""
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("", 0))
            s.listen(1)
            return s.getsockname()[1]

    def start(self):
        """Start the API server subprocess."""
        if self.process:
            return

        self._reap_stale_backend_from_marker()

        load_env_file()
        env = os.environ.copy()
        env["PORT"] = str(self.port)
        # Use GIT_WORKING_DIR from env (set by typedef chat) or fallback to cwd
        if "GIT_WORKING_DIR" not in env:
            env["GIT_WORKING_DIR"] = os.getcwd()
        # Ensure output is unbuffered
        env["PYTHONUNBUFFERED"] = "1"
        env["TYPEDEF_BACKEND_INSTANCE_TOKEN"] = self.instance_token

        # Set default config if not provided
        if "UNIFIED_CONFIG" not in env:
            config_path = Path.cwd() / "typedef_data_intelligence" / "config.cli.yml"
            if not config_path.exists():
                # Fallback to root config if not found
                config_path = Path.cwd() / "config.cli.yml"

            env["UNIFIED_CONFIG"] = str(config_path)
            logger.info(f"Setting UNIFIED_CONFIG={config_path}")

        # Pass project context to backend
        if "TYPEDEF_ACTIVE_PROJECT" in os.environ:
            env["TYPEDEF_ACTIVE_PROJECT"] = os.environ["TYPEDEF_ACTIVE_PROJECT"]

        if "TYPEDEF_GRAPH_NAME" in os.environ:
            env["TYPEDEF_GRAPH_NAME"] = os.environ["TYPEDEF_GRAPH_NAME"]

        # Command to run the API server module
        # We use sys.executable to ensure we use the same python environment
        cmd = [
            sys.executable,
            "-m",
            "lineage.api.pydantic",
        ]

        logger.info(f"Starting backend server on port {self.port}")
        logger.info(f"Backend logs -> {self.log_file.absolute()}")

        # Open log file for redirection
        self.log_fp = open(self.log_file, "w")

        try:
            self.process = subprocess.Popen(  # nosec B603 - cmd is hardcoded, runs internal module
                cmd,
                env=env,
                stdout=self.log_fp,
                stderr=subprocess.STDOUT,  # Redirect stderr to stdout
                text=True,
                start_new_session=True,
            )
            marker = self._build_marker_for_pid(self.process.pid)
            if marker is not None:
                self._write_marker(marker)
        except Exception:
            # If Popen fails, close the log file handle to prevent leak
            self.log_fp.close()
            self.log_fp = None
            raise

    def stop(self):
        """Stop the API server subprocess."""
        if self.process:
            logger.info("Stopping backend server...")
            self._terminate_spawned_backend("app_stop")
        self.process = None
        if hasattr(self, "log_fp") and self.log_fp:
            self.log_fp.close()
            self.log_fp = None

    async def wait_for_health(self, timeout: int = 30) -> Optional[dict[str, Any]]:
        """Wait for the server to become healthy and return health payload."""
        start_time = time.time()
        async with httpx.AsyncClient() as client:
            while time.time() - start_time < timeout:
                try:
                    response = await client.get(f"{self.base_url}/health")
                    if response.status_code == 200:
                        try:
                            payload = response.json()
                            if isinstance(payload, dict):
                                return payload
                        except ValueError:
                            pass
                        return {"status": "healthy"}
                except httpx.RequestError:
                    pass

                # Check if process died
                if self.process is not None and self.process.poll() is not None:
                    logger.error(
                        f"Backend process died unexpectedly. Check logs at {self.log_file}"
                    )
                    return None

                elapsed = time.time() - start_time
                interval = 0.1 if elapsed < 3 else 0.25
                await asyncio.sleep(interval)

        return None

    async def get_dependency_readiness(self) -> Optional[dict[str, Any]]:
        """Fetch explicit graph/data readiness checks from the backend."""
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"{self.base_url}/health/readiness", timeout=5.0
                )
                if response.status_code != 200:
                    return None
                payload = response.json()
                if isinstance(payload, dict):
                    return payload
        except (httpx.RequestError, ValueError):
            return None
        return None

    def _terminate_spawned_backend(self, reason: str) -> None:
        """Terminate spawned backend process with deterministic escalation."""
        process = self.process
        if process is None:
            return

        pid = process.pid
        poll_result = process.poll()
        if poll_result is not None:
            logger.info(
                "Backend process already exited",
                extra={
                    "event": "backend_stop_already_dead",
                    "pid": pid,
                    "reason": reason,
                },
            )
            self._clear_marker_if_pid_matches(pid)
            return

        pgid: int | None = None
        try:
            pgid = os.getpgid(pid)
        except ProcessLookupError:
            self._clear_marker_if_pid_matches(pid)
            return
        except Exception as exc:
            logger.debug(
                f"Failed to resolve backend process group for pid={pid}: {exc}"
            )

        logger.info(
            "Stopping backend process",
            extra={
                "event": "backend_stop_begin",
                "pid": pid,
                "pgid": pgid,
                "reason": reason,
            },
        )

        self._terminate_pid_or_group(pid=pid, pgid=pgid, signal_name="TERM")
        try:
            process.wait(timeout=self.STOP_TERM_TIMEOUT_SECONDS)
            self._clear_marker_if_pid_matches(pid)
            logger.info(
                "Backend process terminated gracefully",
                extra={"event": "backend_stop_graceful", "pid": pid, "pgid": pgid},
            )
            return
        except subprocess.TimeoutExpired:
            logger.warning(
                "Backend did not stop in TERM window; sending KILL",
                extra={"event": "backend_stop_timeout", "pid": pid, "pgid": pgid},
            )
        except Exception as exc:
            logger.warning(
                "Error waiting for backend stop after TERM",
                extra={"event": "backend_stop_wait_error", "pid": pid, "pgid": pgid},
            )
            logger.debug(f"Detailed backend stop wait error for pid={pid}: {exc}")

        self._terminate_pid_or_group(pid=pid, pgid=pgid, signal_name="KILL")
        try:
            process.wait(timeout=self.STOP_KILL_WAIT_SECONDS)
        except subprocess.TimeoutExpired:
            logger.error(
                "Backend process survived KILL wait window",
                extra={"event": "backend_stop_kill_timeout", "pid": pid, "pgid": pgid},
            )
        finally:
            self._clear_marker_if_pid_matches(pid)

    def _terminate_pid_or_group(
        self, pid: int, pgid: int | None, signal_name: str
    ) -> None:
        """Send signal to process group when available, else single process."""
        sig = getattr(signal, f"SIG{signal_name}")
        try:
            if pgid is not None:
                os.killpg(pgid, sig)
            else:
                os.kill(pid, sig)
        except ProcessLookupError:
            return
        except Exception as exc:
            logger.warning(
                "Failed to send signal to backend process",
                extra={
                    "event": "backend_stop_signal_error",
                    "pid": pid,
                    "pgid": pgid,
                    "signal": signal_name,
                },
            )
            logger.debug(
                f"Detailed backend signal failure pid={pid} pgid={pgid} signal={signal_name}: {exc}"
            )

    def _build_marker_for_pid(self, pid: int) -> _BackendMarker | None:
        """Build ownership marker for a spawned backend pid."""
        try:
            pgid = os.getpgid(pid)
        except Exception:
            pgid = None

        return _BackendMarker(
            pid=pid,
            pgid=pgid,
            started_at_epoch=self._read_process_start_ticks(pid),
            instance_token=self.instance_token,
            python_executable=sys.executable,
            active_project=os.environ.get("TYPEDEF_ACTIVE_PROJECT"),
            created_at_epoch=int(time.time()),
        )

    def _write_marker(self, marker: _BackendMarker) -> None:
        """Persist current backend ownership marker."""
        try:
            self.marker_file.parent.mkdir(parents=True, exist_ok=True)
            payload = {
                "pid": marker.pid,
                "pgid": marker.pgid,
                "started_at_epoch": marker.started_at_epoch,
                "instance_token": marker.instance_token,
                "python_executable": marker.python_executable,
                "active_project": marker.active_project,
                "created_at_epoch": marker.created_at_epoch,
            }
            self.marker_file.write_text(json.dumps(payload), encoding="utf-8")
        except Exception as exc:
            logger.warning(f"Failed to write backend ownership marker: {exc}")

    def _read_marker(self) -> _BackendMarker | None:
        """Read persisted backend ownership marker if available."""
        if not self.marker_file.exists():
            return None
        try:
            payload = json.loads(self.marker_file.read_text(encoding="utf-8"))
            return _BackendMarker(
                pid=int(payload["pid"]),
                pgid=int(payload["pgid"]) if payload.get("pgid") is not None else None,
                started_at_epoch=(
                    int(payload["started_at_epoch"])
                    if payload.get("started_at_epoch") is not None
                    else None
                ),
                instance_token=str(payload["instance_token"]),
                python_executable=str(payload["python_executable"]),
                active_project=(
                    str(payload["active_project"])
                    if payload.get("active_project") is not None
                    else None
                ),
                created_at_epoch=int(payload["created_at_epoch"]),
            )
        except Exception as exc:
            logger.warning(
                f"Ignoring invalid backend marker file {self.marker_file}: {exc}"
            )
            return None

    def _clear_marker_if_pid_matches(self, pid: int) -> None:
        """Delete ownership marker only when it still references pid."""
        marker = self._read_marker()
        if marker is None:
            return
        if marker.pid != pid:
            return
        try:
            self.marker_file.unlink(missing_ok=True)
        except Exception as exc:
            logger.warning(
                f"Failed to clear backend marker file {self.marker_file}: {exc}"
            )

    def _reap_stale_backend_from_marker(self) -> None:
        """Reap validated stale backend process from ownership marker."""
        marker = self._read_marker()
        if marker is None:
            return

        if marker.instance_token == self.instance_token:
            return

        if marker.python_executable != sys.executable:
            logger.info(
                "Skipping stale backend reap due to python executable mismatch",
                extra={
                    "event": "backend_reap_skip_python",
                    "marker_pid": marker.pid,
                    "marker_python": marker.python_executable,
                    "current_python": sys.executable,
                },
            )
            return

        if not self._is_pid_alive(marker.pid):
            self._clear_marker_if_pid_matches(marker.pid)
            return

        if not self._validate_marker_ownership(marker):
            logger.info(
                "Skipping stale backend reap because ownership validation failed",
                extra={
                    "event": "backend_reap_skip_validation",
                    "marker_pid": marker.pid,
                },
            )
            return

        logger.warning(
            "Reaping stale backend process from prior session",
            extra={
                "event": "backend_reap_begin",
                "marker_pid": marker.pid,
                "marker_pgid": marker.pgid,
            },
        )
        self._terminate_pid_or_group(
            pid=marker.pid,
            pgid=marker.pgid,
            signal_name="TERM",
        )
        deadline = time.time() + self.STOP_TERM_TIMEOUT_SECONDS
        while time.time() < deadline:
            if not self._is_pid_alive(marker.pid):
                self._clear_marker_if_pid_matches(marker.pid)
                return
            time.sleep(0.1)

        self._terminate_pid_or_group(
            pid=marker.pid,
            pgid=marker.pgid,
            signal_name="KILL",
        )
        kill_deadline = time.time() + self.STOP_KILL_WAIT_SECONDS
        while time.time() < kill_deadline:
            if not self._is_pid_alive(marker.pid):
                break
            time.sleep(0.1)
        self._clear_marker_if_pid_matches(marker.pid)

    def _validate_marker_ownership(self, marker: _BackendMarker) -> bool:
        """Validate marker ownership before any stale-process reaping."""
        current_start = self._read_process_start_ticks(marker.pid)
        if marker.started_at_epoch is not None and current_start is not None:
            if current_start != marker.started_at_epoch:
                return False

        current_token = self._read_process_env_var(
            marker.pid, "TYPEDEF_BACKEND_INSTANCE_TOKEN"
        )
        if current_token is None:
            return False
        if current_token != marker.instance_token:
            return False

        return True

    def _is_pid_alive(self, pid: int) -> bool:
        """Return whether pid currently exists."""
        if pid <= 0:
            return False
        try:
            os.kill(pid, 0)
            return True
        except ProcessLookupError:
            return False
        except PermissionError:
            return True
        except Exception:
            return False

    def _read_process_start_ticks(self, pid: int) -> int | None:
        """Read process start ticks from /proc for PID reuse protection."""
        stat_path = Path(f"/proc/{pid}/stat")
        if not stat_path.exists():
            return None
        try:
            data = stat_path.read_text(encoding="utf-8", errors="ignore")
            start = data.rfind(")")
            if start < 0:
                return None
            parts = data[start + 2 :].split()
            if len(parts) <= 19:
                return None
            return int(parts[19])
        except Exception:
            return None

    def _read_process_env_var(self, pid: int, key: str) -> str | None:
        """Read one environment variable from process environ."""
        environ_path = Path(f"/proc/{pid}/environ")
        if not environ_path.exists():
            return None
        try:
            raw = environ_path.read_bytes()
        except Exception:
            return None

        target = key.encode("utf-8") + b"="
        for entry in raw.split(b"\x00"):
            if entry.startswith(target):
                return entry[len(target) :].decode("utf-8", errors="ignore")
        return None
