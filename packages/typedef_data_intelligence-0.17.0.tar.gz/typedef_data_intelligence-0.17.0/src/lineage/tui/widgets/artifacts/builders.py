"""Builder functions for artifact widgets.

Contains functions that build reusable Textual widgets for various artifact types.
These can be used both by the ArtifactViewer sidebar and for standalone rendering.
"""
import math
from typing import Any, Dict, List, Optional

from agent.types import DownstreamImpactResult
from textual.widgets import DataTable, Markdown

from lineage.tui.widgets.artifacts.formatters import (
    _format_lineage_node_card,
    _format_node_card,
)
from lineage.tui.widgets.artifacts.helpers import (
    _detect_display_type,
    _escape_markdown,
    _get_short_name,
    _get_type_icon,
    _group_nodes_by_type,
    _render_as_table,
    _truncate,
)


def build_table_widget(*, columns: List[str], rows: List[List[Any]]) -> DataTable:
    """Build a DataTable widget for a table artifact."""
    table = DataTable()
    table.add_columns(*columns)
    table.add_rows(rows)
    return table


def build_graph_result_widget(
    *,
    title: str,
    nodes: List[Any],
    query_description: str = "",
    display_hint: Optional[str] = None,
) -> Markdown:
    """Build a Markdown widget for graph query results."""
    content_parts = [f"# {title}", ""]
    if query_description:
        content_parts.append(f"*{_escape_markdown(query_description)}*")
        content_parts.append("")

    if not nodes:
        content_parts.append("*No results*")
        return Markdown("\n".join(content_parts), classes="graph-result")

    display_type = display_hint or _detect_display_type(nodes)
    if display_type == "scalar":
        if len(nodes) == 1 and isinstance(nodes[0], dict):
            for k, v in nodes[0].items():
                content_parts.append(f"**{k}:** {v}")
                content_parts.append("")
    elif display_type == "table":
        content_parts.append(_render_as_table(nodes))
        content_parts.append("")
    else:
        content_parts.append(f"**Found {len(nodes)} results**")
        content_parts.append("")
        by_type = _group_nodes_by_type(nodes)
        for node_type, items in by_type.items():
            icon = _get_type_icon(node_type)
            content_parts.append(f"- {icon} **{node_type}**: {len(items)}")
        content_parts.append("")
        content_parts.append("---")
        content_parts.append("")

        max_cards = 10
        cards_rendered = 0
        for node in nodes:
            if cards_rendered >= max_cards:
                remaining = len(nodes) - max_cards
                if remaining > 0:
                    content_parts.append(f"*... and {remaining} more*")
                break
            if isinstance(node, dict):
                content_parts.append(_format_node_card(node))
                content_parts.append("---")
                content_parts.append("")
                cards_rendered += 1

    return Markdown("\n".join(content_parts), classes="graph-result")


def build_search_results_widget(*, search_term: str, results: List[Any]) -> Markdown:
    """Build a Markdown widget for search results."""
    content_parts = [f'# 🔎 Search: "{search_term}"', ""]
    if not results:
        content_parts.append("*No matches found*")
        return Markdown("\n".join(content_parts), classes="search-results")

    raw_scores = [item.get("score", 0) or 0 for item in results if isinstance(item, dict)]
    max_score = max(raw_scores) if raw_scores else 0
    for i, item in enumerate([r for r in results if isinstance(r, dict)][:10], 1):
        raw_score = item.get("score", 0) or 0
        norm_score = int(round((raw_score / max_score) * 100)) if max_score > 0 else 0
        stars = "⭐" * math.ceil(norm_score / 20.0)
        name = item.get("name", "Unknown")
        model_id = item.get("id", "")
        name_with_tooltip = f'[{name}](# "raw score: {raw_score}")'
        content_parts.append(f"**{i}. {stars} {name_with_tooltip}** ({norm_score})")
        content_parts.append("")
        content_parts.append(f"`{model_id}`")
        content_parts.append("")

    return Markdown("\n".join(content_parts), classes="search-results")


def build_impact_tree_widget(
    *,
    result: Optional[DownstreamImpactResult] = None,
    model_name: Optional[str] = None,
    affected_models: Optional[List[Dict[str, Any]]] = None,
    total: Optional[int] = None,
) -> Markdown:
    """Build the same Markdown widget used by the sidebar for downstream impact."""
    if result is not None:
        model_name = model_name or result.model_name or result.model_id
        affected_models = affected_models or list(result.affected_models)
        total = total if total is not None else int(result.total_affected or 0)
    model_name = model_name or "Model"
    affected_models = affected_models or []
    total = int(total or 0)

    content_parts = [f"## 📉 Impact: {model_name}", ""]

    if total == 0:
        content_parts.append("*No downstream dependencies*")
        return Markdown("\n".join(content_parts), classes="impact-tree")

    content_parts.append(f"**Affects {total} models:**")
    content_parts.append("")

    by_depth: Dict[int, List[Dict[str, Any]]] = {}
    for m in affected_models:
        if not isinstance(m, dict):
            continue
        depth = m.get("depth", 0)
        by_depth.setdefault(int(depth or 0), []).append(m)

    if 1 in by_depth:
        content_parts.append("**Direct:**")
        content_parts.append("")
        for m in by_depth[1][:10]:
            content_parts.append(f"- {m.get('name', '?')}")
        if len(by_depth[1]) > 10:
            content_parts.append(f"- *(... and {len(by_depth[1]) - 10} more)*")
        content_parts.append("")

    deeper: List[Dict[str, Any]] = []
    for depth in sorted(k for k in by_depth.keys() if k > 1):
        deeper.extend(by_depth[depth])
    if deeper:
        content_parts.append(f"**Indirect (depth 2+):** {len(deeper)} models")
        content_parts.append("")
        for m in deeper[:10]:
            content_parts.append(f"- {m.get('name', '?')} (depth {m.get('depth', '?')})")
        if len(deeper) > 10:
            content_parts.append(f"- *(... and {len(deeper) - 10} more)*")
        content_parts.append("")

    return Markdown("\n".join(content_parts), classes="impact-tree")


def build_plan_markdown(*, plan: Dict[str, Any]) -> str:
    """Build a Markdown string for a Plan artifact."""
    if plan.get("markdown_body"):
        return str(plan["markdown_body"])

    title = plan.get("title") or "Plan"
    goal = plan.get("goal") or ""
    status = (plan.get("status") or "draft").lower()
    locked = " 🔒" if status == "final" else ""

    content_parts: List[str] = [f"# 🧭 {title}{locked}", ""]
    if goal:
        content_parts.append(f"**Goal:** {_escape_markdown(goal)}")
        content_parts.append("")

    content_parts.append(f"**Status:** {status}")
    content_parts.append("")

    sections = plan.get("sections") or []
    if sections:
        content_parts.append("## Sections")
        content_parts.append("")
        for s in sections:
            if not isinstance(s, dict):
                continue
            stitle = s.get("title") or s.get("section_id") or "Section"
            content_parts.append(f"### {stitle}")
            content_parts.append("")
            body = s.get("content_markdown") or ""
            if body:
                content_parts.append(str(body))
            content_parts.append("")

    steps = plan.get("steps") or []
    content_parts.append("## Steps")
    content_parts.append("")
    if not steps:
        content_parts.append("*No steps yet*")
    else:
        for i, step in enumerate(steps, 1):
            if not isinstance(step, dict):
                continue
            text = step.get("content") or ""
            risk = step.get("risk")
            deps = step.get("dependencies") or []
            risk_str = f" _(risk: {risk})_" if risk else ""
            content_parts.append(f"{i}. {text}{risk_str}")
            if deps:
                content_parts.append(f"   - depends_on: {', '.join(str(d) for d in deps)}")
    content_parts.append("")

    return "\n".join(content_parts)


def build_plan_widget(*, plan: Dict[str, Any]) -> Markdown:
    """Build a Markdown widget for a Plan artifact."""
    return Markdown(build_plan_markdown(plan=plan), classes="plan-preview")


def build_context_brief_widget(*, brief: Dict[str, Any]) -> Markdown:
    """Build a Markdown widget for a context brief artifact."""
    title = brief.get("title") or "Context Brief"
    findings_md = brief.get("findings_markdown") or ""

    content_parts = [f"# {title}", ""]
    source = brief.get("source")
    if source:
        content_parts.append(f"**Source:** {source}")
        content_parts.append("")
    if findings_md:
        content_parts.append(str(findings_md))
    else:
        content_parts.append("*No findings provided*")
    content_parts.append("")

    return Markdown("\n".join(content_parts), classes="context-brief")


def build_lineage_widget(*, lineage: Dict[str, Any]) -> Markdown:
    """Build a Markdown widget for lineage results."""
    root_id = lineage.get("root") or lineage.get("identifier") or "?"
    nodes_data = lineage.get("nodes") or []
    dir_type = lineage.get("direction") or "unknown"
    desc = lineage.get("description") or lineage.get("query_description") or ""
    hops = lineage.get("hops") or []
    edges = lineage.get("edges") or []

    content_parts = [f"# Lineage: {_escape_markdown(root_id)}", ""]
    if desc:
        content_parts.append(f"*{_escape_markdown(desc)}*")
        content_parts.append("")

    content_parts.append(f"**Direction:** {dir_type}")
    content_parts.append(f"**Found {len(nodes_data)} nodes, {len(edges)} edges**")
    content_parts.append("")

    # Hop summary (for column lineage)
    if hops:
        transforms: List[str] = []
        for hop in hops:
            if isinstance(hop, dict):
                transforms.extend([str(t) for t in hop.get("transformations", [])])
        unique_transforms: List[str] = []
        for t in transforms:
            if t not in unique_transforms:
                unique_transforms.append(t)
        if unique_transforms:
            palette = ", ".join(unique_transforms[:8])
            more = "" if len(unique_transforms) <= 8 else f" (+{len(unique_transforms)-8} more)"
            content_parts.append(f"**Transform palette:** {palette}{more}")
        content_parts.append(f"**Hops:** {len(hops)}")
        content_parts.append("")

        content_parts.append("### Hop Steps")
        for idx, hop in enumerate(hops, start=1):
            if not isinstance(hop, dict):
                continue
            from_id = hop.get("from_id") or "?"
            to_id = hop.get("to_id") or "?"
            transformations = hop.get("transformations") or []
            t_str = ", ".join(str(t) for t in transformations) if transformations else "DERIVES_FROM"
            content_parts.append(f"{idx}. `{from_id}` -> `{to_id}`  via {t_str}")
        content_parts.append("")

    # Node type summary
    if isinstance(nodes_data, list):
        by_type = _group_nodes_by_type([n for n in nodes_data if isinstance(n, dict)])
        for node_type, items in by_type.items():
            icon = _get_type_icon(node_type)
            content_parts.append(f"- {icon} **{node_type}**: {len(items)}")
        content_parts.append("")

    # Dependencies (relation lineage)
    if edges:
        content_parts.append("### Dependencies")
        depends_on = [e for e in edges if isinstance(e, dict) and e.get("edge_type") == "DEPENDS_ON"]
        builds = [e for e in edges if isinstance(e, dict) and e.get("edge_type") == "BUILDS"]

        if depends_on:
            for edge in depends_on[:15]:
                from_name = _get_short_name(edge.get("from_id", "?"))
                to_name = _get_short_name(edge.get("to_id", "?"))
                content_parts.append(f"  `{from_name}` -> `{to_name}`")
            if len(depends_on) > 15:
                content_parts.append(f"  *... and {len(depends_on) - 15} more dependencies*")

        if builds:
            content_parts.append("")
            content_parts.append("### Builds (Logical -> Physical)")
            for edge in builds[:10]:
                from_name = _get_short_name(edge.get("from_id", "?"))
                to_name = _get_short_name(edge.get("to_id", "?"))
                content_parts.append(f"  `{from_name}` -> `{to_name}`")
            if len(builds) > 10:
                content_parts.append(f"  *... and {len(builds) - 10} more builds*")

        content_parts.append("")

    content_parts.append("---")
    content_parts.append("")

    # Node cards with semantic summaries
    max_cards = 10
    cards_rendered = 0
    for node in nodes_data:
        if cards_rendered >= max_cards:
            remaining = len(nodes_data) - max_cards
            if remaining > 0:
                content_parts.append(f"*... and {remaining} more nodes (use get_model_details for specifics)*")
            break
        if isinstance(node, dict):
            content_parts.append(_format_lineage_node_card(node))
            content_parts.append("---")
            content_parts.append("")
            cards_rendered += 1

    return Markdown("\n".join(content_parts), classes="lineage-result")


def build_model_details_widget(*, model_details: Dict[str, Any]) -> Markdown:
    """Build a Markdown widget for model details."""
    details = model_details
    content_parts = [f"# {_escape_markdown(details.get('model_name', 'Model'))}", ""]

    if details.get("description"):
        content_parts.append(f"*{_escape_markdown(details['description'])}*")
        content_parts.append("")

    mat = details.get("materialization", "model")
    path = details.get("original_path", "")
    content_parts.append(f"**Materialization:** {mat}")
    if path:
        content_parts.append(f"**Path:** `{path}`")
    content_parts.append("")

    if any(details.get(f) for f in ["grain", "intent", "analysis_summary", "measures", "dimensions", "facts"]):
        content_parts.append("## Semantic Analysis")
        content_parts.append("")

        if details.get("grain"):
            content_parts.append(f"**Grain:** {_escape_markdown(details['grain'])}")
        if details.get("intent"):
            content_parts.append(f"**Intent:** {_escape_markdown(details['intent'])}")

        flags = []
        if details.get("has_aggregations"):
            flags.append("aggregations")
        if details.get("has_window_functions"):
            flags.append("window functions")
        if flags:
            content_parts.append(f"**Features:** {', '.join(flags)}")

        if details.get("analysis_summary"):
            content_parts.append("")
            content_parts.append(f"{_escape_markdown(details['analysis_summary'])}")

        content_parts.append("")

        measures = details.get("measures") or []
        if measures:
            content_parts.append("### Measures")
            for m in measures:
                if not isinstance(m, dict):
                    continue
                name = m.get("name", "?")
                expr = m.get("expr", "")
                agg = m.get("agg_function", "")
                content_parts.append(f"- **{name}**: `{expr}` ({agg})")
            content_parts.append("")

        dimensions = details.get("dimensions") or []
        if dimensions:
            content_parts.append("### Dimensions")
            for d in dimensions:
                if not isinstance(d, dict):
                    continue
                name = d.get("name", "?")
                source = d.get("source", "")
                pii = " (PII)" if d.get("is_pii") else ""
                content_parts.append(f"- **{name}**{pii} (from: {source})")
            content_parts.append("")

        facts = details.get("facts") or []
        if facts:
            content_parts.append("### Facts")
            for f in facts:
                if not isinstance(f, dict):
                    continue
                name = f.get("name", "?")
                source = f.get("source", "")
                content_parts.append(f"- **{name}** (from: {source})")
            content_parts.append("")

        if details.get("subject_area"):
            sa_domains = details.get("subject_area_domains") or []
            domains_str = f" ({', '.join(sa_domains)})" if sa_domains else ""
            content_parts.append(f"**Subject Area:** {_escape_markdown(details['subject_area'])}{domains_str}")
            content_parts.append("")

    join_edges = details.get("join_edges") or []
    if join_edges:
        content_parts.append("## Join Edges")
        content_parts.append("")
        for je in join_edges[:15]:
            if not isinstance(je, dict):
                continue
            jtype = je.get("join_type", "JOIN")
            left = je.get("left_model") or je.get("left_alias", "?")
            right = je.get("right_model") or je.get("right_alias", "?")
            cond = je.get("condition", "")
            cond_str = f" ON `{_truncate(cond, 60)}`" if cond else ""
            content_parts.append(f"- {left} {jtype} {right}{cond_str}")
        if len(join_edges) > 15:
            content_parts.append(f"*... and {len(join_edges) - 15} more joins*")
        content_parts.append("")

    columns = details.get("columns") or []
    if columns:
        content_parts.append("## Columns")
        content_parts.append("")
        for col in columns[:20]:
            if not isinstance(col, dict):
                continue
            name = col.get("name", "?")
            dtype = col.get("data_type", "")
            desc = col.get("description", "")
            dtype_str = f" `{dtype}`" if dtype else ""
            desc_str = f" - {_truncate(desc, 50)}" if desc else ""
            content_parts.append(f"- **{name}**{dtype_str}{desc_str}")
        if len(columns) > 20:
            content_parts.append(f"*... and {len(columns) - 20} more columns*")
        content_parts.append("")

    macros = details.get("macros") or []
    if macros:
        content_parts.append("## Macro Dependencies")
        content_parts.append("")
        for macro in macros[:15]:
            if not isinstance(macro, dict):
                continue
            name = macro.get("name", "?")
            pkg = macro.get("package_name", "")
            pkg_str = f" ({pkg})" if pkg else ""
            content_parts.append(f"- `{name}`{pkg_str}")
        if len(macros) > 15:
            content_parts.append(f"*... and {len(macros) - 15} more macros*")
        content_parts.append("")

    if details.get("compiled_sql") or details.get("raw_sql"):
        content_parts.append("## SQL")
        content_parts.append("")
        sql = details.get("compiled_sql") or details.get("raw_sql") or ""
        if len(sql) > 2000:
            sql = sql[:2000] + "\n... (truncated)"
        content_parts.append("```sql")
        content_parts.append(sql)
        content_parts.append("```")
        content_parts.append("")

    return Markdown("\n".join(content_parts), classes="model-details")


def build_subject_area_list_widget(*, subject_areas: List[Dict[str, Any]], total_count: int) -> Markdown:
    """Build a Markdown widget for list_subject_areas results."""
    content_parts = ["## Subject Areas", ""]
    content_parts.append(f"**Found:** {total_count} subject area{'s' if total_count != 1 else ''}")
    content_parts.append("")

    if not subject_areas:
        content_parts.append("*No subject areas discovered*")
        return Markdown("\n".join(content_parts), classes="subject-areas")

    for sa in subject_areas[:20]:
        if not isinstance(sa, dict):
            continue
        name = sa.get("name", "?")
        model_count = sa.get("model_count", 0)
        fact_count = sa.get("fact_count", 0)
        dim_count = sa.get("dimension_count", 0)
        domains = sa.get("domains", [])
        pii = " (PII)" if sa.get("contains_pii") else ""
        domains_str = f" [{', '.join(domains[:3])}]" if domains else ""
        content_parts.append(f"- **{_escape_markdown(name)}**{pii}: {model_count} models ({fact_count}F/{dim_count}D){domains_str}")

    if len(subject_areas) > 20:
        content_parts.append(f"*... and {len(subject_areas) - 20} more*")

    return Markdown("\n".join(content_parts), classes="subject-areas")


def build_subject_area_details_widget(*, details: Dict[str, Any]) -> Markdown:
    """Build a Markdown widget for get_subject_area_details results."""
    name = details.get("name", "Subject Area")
    content_parts = [f"## {_escape_markdown(name)}", ""]

    if details.get("description"):
        content_parts.append(f"*{_escape_markdown(details['description'])}*")
        content_parts.append("")

    domains = details.get("domains", [])
    if domains:
        content_parts.append(f"**Domains:** {', '.join(domains)}")
    keywords = details.get("keywords", [])
    if keywords:
        content_parts.append(f"**Keywords:** {', '.join(keywords)}")
    content_parts.append(f"**Models:** {details.get('model_count', 0)}")
    if details.get("contains_pii"):
        content_parts.append("**PII:** Yes")
    content_parts.append("")

    # Blueprint
    if details.get("recommended_fact_model"):
        content_parts.append("### Blueprint")
        content_parts.append(f"**Fact:** `{details['recommended_fact_model']}`")
        top_dims = details.get("top_dimension_models", [])
        if top_dims:
            content_parts.append(f"**Dimensions:** {', '.join(f'`{d}`' for d in top_dims[:5])}")
        content_parts.append("")

    # Member models by role
    for role, key in [("Facts", "fact_models"), ("Dimensions", "dimension_models"), ("Mixed", "mixed_models")]:
        models = details.get(key, [])
        if models:
            content_parts.append(f"### {role}")
            for m in models[:10]:
                if not isinstance(m, dict):
                    continue
                mname = m.get("name", "?")
                intent = m.get("intent", "")
                intent_str = f" - {_truncate(intent, 60)}" if intent else ""
                content_parts.append(f"- **{mname}**{intent_str}")
            if len(models) > 10:
                content_parts.append(f"*... and {len(models) - 10} more*")
            content_parts.append("")

    # Internal edges
    edges = details.get("top_internal_edges", [])
    if edges:
        content_parts.append("### Top Joins")
        for e in edges[:10]:
            if not isinstance(e, dict):
                continue
            src = e.get("source_name", "?")
            tgt = e.get("target_name", "?")
            weight = e.get("weight", 0)
            jtypes = e.get("join_types", [])
            jtype_str = f" ({', '.join(jtypes)})" if jtypes else ""
            content_parts.append(f"- {src} -> {tgt} (weight: {weight:.1f}){jtype_str}")
        content_parts.append("")

    return Markdown("\n".join(content_parts), classes="subject-area-details")


def build_domain_search_widget(*, domain: str, subject_areas: List[Dict[str, Any]], models: List[Dict[str, Any]]) -> Markdown:
    """Build a Markdown widget for search_by_domain results."""
    content_parts = [f'## Domain Search: "{_escape_markdown(domain)}"', ""]

    if subject_areas:
        content_parts.append(f"**Subject Areas ({len(subject_areas)}):**")
        content_parts.append("")
        for sa in subject_areas[:10]:
            if not isinstance(sa, dict):
                continue
            name = sa.get("name", "?")
            count = sa.get("model_count", 0)
            content_parts.append(f"- **{_escape_markdown(name)}** ({count} models)")
        content_parts.append("")

    if models:
        content_parts.append(f"**Models ({len(models)}):**")
        content_parts.append("")
        for m in models[:15]:
            if not isinstance(m, dict):
                continue
            name = m.get("name", "?")
            role = m.get("role", "")
            sa = m.get("subject_area", "")
            sa_str = f" in {sa}" if sa else ""
            content_parts.append(f"- **{name}** ({role}){sa_str}")
        if len(models) > 15:
            content_parts.append(f"*... and {len(models) - 15} more*")
        content_parts.append("")

    if not subject_areas and not models:
        content_parts.append("*No results found*")

    return Markdown("\n".join(content_parts), classes="domain-search")


def build_command_output_widget(
    *,
    command: str,
    exit_code: int,
    stdout: str,
    stderr: Optional[str] = None,
    working_dir: Optional[str] = None,
    title: Optional[str] = None,
) -> Markdown:
    """Build a Markdown widget for command output (bash/dbt)."""
    import re

    def _wrap_code_block(text: str) -> List[str]:
        """Wrap text in a safe code fence that won't be closed by content."""
        backtick_runs = re.findall(r"`+", text)
        max_ticks = max((len(run) for run in backtick_runs), default=0)
        fence = "`" * max(3, max_ticks + 1)
        return [fence, text, fence]

    display_title = title or "Command Output"
    content_parts = [f"## {display_title}", ""]

    content_parts.append(f"**Command:** `{_escape_markdown(command)}`")
    if working_dir:
        content_parts.append(f"**Working Dir:** `{_escape_markdown(working_dir)}`")
    status = "success" if exit_code == 0 else f"exit {exit_code}"
    status_icon = "✅" if exit_code == 0 else "❌"
    content_parts.append(f"**Status:** {status_icon} {status}")
    content_parts.append("")

    stdout_text = stdout or ""
    stderr_text = stderr or ""

    # Truncate very long output
    max_output = 5000
    if len(stdout_text) > max_output:
        stdout_text = stdout_text[:max_output] + "\n... (truncated)"

    content_parts.append("### Output")
    content_parts.append("")
    if stdout_text.strip():
        content_parts.extend(_wrap_code_block(stdout_text))
    else:
        content_parts.append("*No output*")
    content_parts.append("")

    if stderr_text.strip():
        if len(stderr_text) > max_output:
            stderr_text = stderr_text[:max_output] + "\n... (truncated)"
        content_parts.append("### Errors")
        content_parts.append("")
        content_parts.extend(_wrap_code_block(stderr_text))
        content_parts.append("")

    return Markdown("\n".join(content_parts), classes="command-output")


def build_ticket_widget(*, ticket: Dict[str, Any]) -> Markdown:
    """Build a Markdown widget for a single ticket."""
    ticket_id = ticket.get("id") or ticket.get("ticket_id") or "?"
    title = ticket.get("title") or "Untitled"
    status = ticket.get("status") or "unknown"
    priority = ticket.get("priority") or "medium"
    description = ticket.get("description") or ""
    assigned_to = ticket.get("assigned_to")
    created_by = ticket.get("created_by")
    tags = ticket.get("tags") or []

    # Status and priority icons
    status_icons = {
        "open": "🔵",
        "in_progress": "🟡",
        "in_review": "🟠",
        "done": "🟢",
        "closed": "⚫",
        "cancelled": "❌",
    }
    priority_icons = {
        "urgent": "🔴",
        "high": "🟠",
        "medium": "🟡",
        "low": "🟢",
    }
    status_icon = status_icons.get(status.lower(), "⚪")
    priority_icon = priority_icons.get(priority.lower(), "⚪")

    content_parts = [f"## 🎫 {_escape_markdown(title)}", ""]

    content_parts.append(f"**ID:** `{ticket_id}`")
    content_parts.append(f"**Status:** {status_icon} {status}")
    content_parts.append(f"**Priority:** {priority_icon} {priority}")
    if assigned_to:
        content_parts.append(f"**Assigned to:** {_escape_markdown(assigned_to)}")
    if created_by:
        content_parts.append(f"**Created by:** {_escape_markdown(created_by)}")
    if tags:
        content_parts.append(f"**Tags:** {', '.join(_escape_markdown(t) for t in tags)}")
    content_parts.append("")

    if description:
        content_parts.append("### Description")
        content_parts.append("")
        # Truncate very long descriptions
        desc_text = description
        if len(desc_text) > 2000:
            desc_text = desc_text[:2000] + "\n... (truncated)"
        content_parts.append(desc_text)

    return Markdown("\n".join(content_parts), classes="ticket-details")


def build_ticket_list_widget(*, tickets: List[Dict[str, Any]], count: int) -> Markdown:
    """Build a Markdown widget for a list of tickets."""
    content_parts = ["## 📋 Tickets", ""]
    content_parts.append(f"**Found:** {count} ticket{'s' if count != 1 else ''}")
    content_parts.append("")

    if not tickets:
        content_parts.append("*No tickets match the criteria*")
        return Markdown("\n".join(content_parts), classes="ticket-list")

    # Status and priority icons
    status_icons = {
        "open": "🔵",
        "in_progress": "🟡",
        "in_review": "🟠",
        "done": "🟢",
        "closed": "⚫",
    }
    priority_icons = {
        "urgent": "🔴",
        "high": "🟠",
        "medium": "🟡",
        "low": "🟢",
    }

    for t in tickets[:20]:  # Limit display
        t_id = str(t.get("id", "?"))[:12]
        t_title = str(t.get("title", "Untitled"))[:50]
        if len(t.get("title", "")) > 50:
            t_title += "..."
        t_status = t.get("status", "unknown")
        t_priority = t.get("priority", "medium")
        status_icon = status_icons.get(str(t_status).lower(), "⚪")
        priority_icon = priority_icons.get(str(t_priority).lower(), "⚪")

        content_parts.append(f"- {priority_icon}{status_icon} **{t_id}**: {_escape_markdown(t_title)}")

    if len(tickets) > 20:
        content_parts.append(f"- *... and {len(tickets) - 20} more*")

    return Markdown("\n".join(content_parts), classes="ticket-list")


def build_ticket_update_widget(
    *,
    ticket_id: str,
    action: str,
    message: str,
) -> Markdown:
    """Build a Markdown widget for a ticket update confirmation."""
    action_icons = {
        "created": "🎫",
        "updated": "📝",
        "commented": "💬",
        "assigned": "👤",
        "closed": "✅",
        "reopened": "🔓",
    }
    icon = action_icons.get(action.lower(), "📝")

    content_parts = [f"## {icon} Ticket {action.title()}", ""]
    content_parts.append(f"**Ticket:** `{ticket_id}`")
    content_parts.append("")
    content_parts.append(message)

    return Markdown("\n".join(content_parts), classes="ticket-update")


def build_diagnostics_widget(*, data: Dict[str, Any], diag_type: str) -> Markdown:
    """Build a Markdown widget for diagnostic results."""
    content_parts = []

    if diag_type == "run_key_diagnostics" or data.get("tool_name") == "run_key_diagnostics":
        model_id = data.get("model_id", "?")
        fq_table = data.get("fq_table", "?")
        key_col = data.get("key_col", "?")
        total_rows = data.get("total_rows", 0)
        distinct_keys = data.get("distinct_keys", 0)
        null_keys = data.get("null_keys", 0)
        duplicate_keys = data.get("duplicate_keys", 0)
        has_duplicates = data.get("has_duplicates", False)
        has_nulls = data.get("has_nulls", False)

        content_parts.append("## 🔑 Key Diagnostics")
        content_parts.append("")
        content_parts.append(f"**Model:** `{model_id}`")
        content_parts.append(f"**Table:** `{fq_table}`")
        content_parts.append(f"**Key Column:** `{key_col}`")
        content_parts.append("")

        # Health verdict
        if has_duplicates or has_nulls:
            issues = []
            if has_duplicates:
                issues.append(f"{duplicate_keys} duplicates")
            if has_nulls:
                issues.append(f"{null_keys} nulls")
            content_parts.append(f"**Status:** ⚠ Issues found: {', '.join(issues)}")
        else:
            content_parts.append("**Status:** ✅ Key is unique and non-null")
        content_parts.append("")

        content_parts.append("### Metrics")
        content_parts.append("")
        content_parts.append(f"- **Total Rows:** {total_rows:,}")
        content_parts.append(f"- **Distinct Keys:** {distinct_keys:,}")
        content_parts.append(f"- **Null Keys:** {null_keys:,}")
        content_parts.append(f"- **Duplicate Keys:** {duplicate_keys:,}")

    elif diag_type == "run_join_diagnostics" or data.get("tool_name") == "run_join_diagnostics":
        fact_id = data.get("fact_id", "?")
        dim_id = data.get("dim_id", "?")
        key_col = data.get("key_col", "?")
        fact_rows = data.get("fact_rows", 0)
        orphan_count = data.get("orphan_count", 0)
        orphan_rate = data.get("orphan_rate", 0.0)
        fanout_keys = data.get("fanout_keys", 0)
        has_orphans = data.get("has_orphans", False)
        has_fanout = data.get("has_fanout", False)

        content_parts.append("## 🔗 Join Diagnostics")
        content_parts.append("")
        content_parts.append(f"**Fact:** `{fact_id}`")
        content_parts.append(f"**Dimension:** `{dim_id}`")
        content_parts.append(f"**Join Key:** `{key_col}`")
        content_parts.append("")

        # Health verdict
        if has_orphans or has_fanout:
            issues = []
            if has_orphans:
                issues.append(f"{orphan_rate:.1%} orphan rate")
            if has_fanout:
                issues.append(f"{fanout_keys} fanout keys")
            content_parts.append(f"**Status:** ⚠ Issues found: {', '.join(issues)}")
        else:
            content_parts.append("**Status:** ✅ Join is healthy")
        content_parts.append("")

        content_parts.append("### Metrics")
        content_parts.append("")
        content_parts.append(f"- **Fact Rows:** {fact_rows:,}")
        content_parts.append(f"- **Orphan Count:** {orphan_count:,}")
        content_parts.append(f"- **Orphan Rate:** {orphan_rate:.2%}")
        content_parts.append(f"- **Fanout Keys:** {fanout_keys:,}")

    elif diag_type == "run_relationship_health_check" or data.get("tool_name") == "run_relationship_health_check":
        left_model = data.get("left_model_id", "?")
        right_model = data.get("right_model_id", "?")
        join_cols = data.get("join_columns", [])
        verdict = data.get("health_verdict", "unknown")

        content_parts.append("## 🏥 Relationship Health Check")
        content_parts.append("")
        content_parts.append(f"**Left Model:** `{left_model}`")
        content_parts.append(f"**Right Model:** `{right_model}`")
        content_parts.append(f"**Join Columns:** {', '.join(f'`{c}`' for c in join_cols)}")
        content_parts.append("")

        verdict_icon = "✅" if verdict.lower() in ("healthy", "ok", "good") else "⚠"
        content_parts.append(f"**Verdict:** {verdict_icon} {verdict}")

    else:
        # Generic diagnostic display
        content_parts.append("## 🔧 Diagnostics")
        content_parts.append("")
        for key, value in data.items():
            if key not in ("tool_name",):
                content_parts.append(f"**{key}:** {value}")

    if data.get("error"):
        content_parts.append("")
        content_parts.append(f"**Error:** {data['error']}")

    return Markdown("\n".join(content_parts), classes="diagnostics-result")
