"""LookML/Looker connection step for the init wizard."""

from pathlib import Path
from typing import Any

from textual.app import ComposeResult
from textual.widgets import Checkbox, Input, Label

from lineage.tui.wizards.init.steps.integration_base import IntegrationStepBase


class LookMLConnectionStep(IntegrationStepBase):
    """Step: LookML project configuration (optional)."""

    integration_id = "lookml"
    integration_label = "LookML / Looker"

    def __init__(self):
        """Initialize LookML connection step."""
        super().__init__(
            description="Connect a LookML project to include Looker semantic layer metadata.",
        )
        self.project_dir_input: Input
        self.project_name_input: Input
        self.stitch_checkbox: Checkbox

    def get_settings_content(self) -> ComposeResult:
        """Yield project directory, name, and stitch-to-dbt widgets."""
        yield Label("Project directory:")
        self.project_dir_input = Input(
            placeholder="/path/to/lookml-project",
            id="lookml-project-dir",
        )
        yield self.project_dir_input

        yield Label("Project name (optional, defaults to directory name):")
        self.project_name_input = Input(
            placeholder="my_lookml_project",
            id="lookml-project-name",
        )
        yield self.project_name_input

        self.stitch_checkbox = Checkbox(
            "Stitch to dbt models", id="lookml-stitch", value=True,
        )
        yield self.stitch_checkbox

    async def validate_settings(self) -> tuple[bool, str]:
        """Validate that the project directory exists and contains .lkml files."""
        project_dir = self.project_dir_input.value.strip()
        if not project_dir:
            return False, "Project directory is required"

        path = Path(project_dir).expanduser()
        if not path.is_dir():
            return False, f"Directory not found: {path}"

        lkml_files = list(path.rglob("*.lkml"))
        if not lkml_files:
            return False, f"No .lkml files found in {path}"

        self.update_status(f"Valid: {path} ({len(lkml_files)} .lkml files)")
        return True, ""

    def get_settings_data(self) -> dict[str, Any]:
        """Return LookML project configuration."""
        return {
            "lookml_project_dir": self.project_dir_input.value.strip(),
            "lookml_project_name": self.project_name_input.value.strip() or None,
            "lookml_stitch_to_dbt": self.stitch_checkbox.value,
        }
