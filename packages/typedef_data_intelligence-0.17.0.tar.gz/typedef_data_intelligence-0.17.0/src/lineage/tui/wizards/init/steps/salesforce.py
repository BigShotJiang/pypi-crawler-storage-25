"""Salesforce connection step for the init wizard."""
from typing import Any

from rich.markup import escape as escape_markup
from textual import work
from textual.app import ComposeResult
from textual.css.query import NoMatches
from textual.widgets import Button, Checkbox, Input, Label, Static

from lineage.tui.wizards.base import AsyncStepMixin, StepState
from lineage.tui.wizards.init.helpers import (
    focus_button,
    set_button_disabled,
)
from lineage.tui.wizards.init.steps.integration_base import IntegrationStepBase


class SalesforceConnectionStep(IntegrationStepBase, AsyncStepMixin):
    """Step: Salesforce connection configuration (optional)."""

    integration_id = "salesforce"
    integration_label = "Salesforce"

    def __init__(self):
        """Initialize Salesforce connection step."""
        super().__init__(
            description="Connect Salesforce to include CRM metadata.",
        )
        self.init_async_state()
        self.client_id_input: Input
        self._connection_tested = False
        self._org_display_name: str = ""
        self._login_url: str = "https://login.salesforce.com"

    def get_settings_content(self) -> ComposeResult:
        """Yield client ID input and test connection button."""
        yield Label("Client ID:")
        self.client_id_input = Input(placeholder="3MVG9...", id="salesforce-client-id")
        yield self.client_id_input
        yield Button("Test Connection", id="test-sf-connection-btn", variant="primary")

    def on_checkbox_changed(self, event: Checkbox.Changed) -> None:
        """Reset connection state when the checkbox is unchecked."""
        super().on_checkbox_changed(event)
        if event.checkbox.id == f"{self.integration_id}-enabled" and not event.value:
            self._connection_tested = False
            self._org_display_name = ""
            self.reset_state()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle test connection button press."""
        if event.button.id == "test-sf-connection-btn":
            client_id = self.client_id_input.value.strip()
            if not client_id:
                self.update_status("Please enter a Client ID")
                return
            self._test_connection(client_id, self._login_url)

    @work(thread=True)
    def _test_connection(self, client_id: str, login_url: str) -> None:
        """Background worker to test Salesforce connection via OAuth."""
        self.set_state(StepState.VALIDATING)
        self.app.call_from_thread(self.update_status, "Opening browser...")
        set_button_disabled("next-btn", True, self.app)
        set_button_disabled("test-sf-connection-btn", True, self.app)

        try:
            from ingest.static_loaders.salesforce.auth.oauth_pkce import (
                OAuthPKCEAuth,
            )

            auth = OAuthPKCEAuth(client_id=client_id, login_url=login_url, org_key="default")
            creds = auth.authenticate()

            self._org_display_name = creds.instance_url
            self._connection_tested = True
            self.set_state(StepState.VALID)
            self.app.call_from_thread(self.update_status, f"Connected: {creds.instance_url}")

            set_button_disabled("test-sf-connection-btn", False, self.app)
            set_button_disabled("next-btn", False, self.app)
            focus_button("next-btn", self.app)

        except Exception as e:
            error_msg = escape_markup(str(e))
            self.set_state(StepState.INVALID, f"Failed: {error_msg}")
            self._connection_tested = False
            set_button_disabled("test-sf-connection-btn", False, self.app)
            set_button_disabled("next-btn", False, self.app)

    def _on_state_changed(self) -> None:
        """Update UI when async state changes."""
        try:
            status = self.query_one(f"#{self.integration_id}-status", Static)
            if self.state == StepState.VALIDATING:
                status.update("Testing...")
            elif self.state == StepState.VALID:
                status.update(f"Connected: {self._org_display_name}")
            elif self.state == StepState.INVALID:
                status.update(self._error_message)
        except NoMatches:
            pass

    async def validate_settings(self) -> tuple[bool, str]:
        """Validate that a connection test has succeeded."""
        client_id = self.client_id_input.value.strip()
        if not client_id:
            return False, "Client ID required"

        if not self._connection_tested:
            return False, "Test connection first"

        if self.state == StepState.VALIDATING:
            return False, ""
        if self.state == StepState.INVALID:
            return False, self._error_message

        return True, ""

    def get_settings_data(self) -> dict[str, Any]:
        """Return Salesforce connection configuration."""
        return {
            "salesforce_client_id": self.client_id_input.value.strip(),
            "salesforce_login_url": self._login_url,
            "salesforce_org_key": "default",
            "salesforce_include_reports": True,
            "salesforce_include_dashboards": True,
            "salesforce_stitch_to_dbt": True,
            "salesforce_stitch_llm": True,
            "salesforce_exclude_patterns": ["*Feed", "*History", "*Share", "*Tag", "*ChangeEvent"],
        }
