"""Base class for optional integration wizard steps.

Provides the common enable/disable checkbox, settings visibility toggle,
status widget, and validation/data boilerplate shared by all integration
connection steps (Salesforce, Cube.dev, and future integrations).

Subclasses override:
    - ``integration_id``   – unique DOM id prefix (e.g. "cube", "salesforce")
    - ``integration_label`` – human-readable name shown on the checkbox
    - ``get_settings_content()`` – yields the integration-specific widgets
    - ``validate_settings()``    – validates when the integration is enabled
    - ``get_settings_data()``    – returns the integration-specific config dict
"""

from __future__ import annotations

from typing import Any

from textual.app import ComposeResult
from textual.containers import Vertical
from textual.css.query import NoMatches
from textual.widgets import Checkbox, Static

from lineage.tui.wizards.base import WizardStep


class IntegrationStepBase(WizardStep):
    """Base wizard step for optional integrations.

    Handles the enable checkbox, settings panel visibility, and status
    widget so that concrete steps only need to define their unique fields.
    """

    # ── subclass must set these ──────────────────────────────────────
    integration_id: str = ""       # e.g. "cube", "salesforce"
    integration_label: str = ""    # e.g. "Cube.dev", "Salesforce"

    def __init__(
        self,
        *,
        title: str | None = None,
        description: str = "",
    ):
        """Initialize with auto-generated title and step ID."""
        resolved_title = title or f"{self.integration_label} (Optional)"
        super().__init__(
            title=resolved_title,
            description=description,
            step_id=f"{self.integration_id}-connection",
        )
        self.enabled_checkbox: Checkbox

    # ── layout ───────────────────────────────────────────────────────

    def get_content(self) -> ComposeResult:
        """Render enable checkbox, settings panel, and status widget."""
        self.enabled_checkbox = Checkbox(
            f"Enable {self.integration_label}",
            id=f"{self.integration_id}-enabled",
            value=False,
        )
        yield self.enabled_checkbox

        with Vertical(id=f"{self.integration_id}-settings"):
            yield from self.get_settings_content()
            yield Static("", id=f"{self.integration_id}-status")

    def get_settings_content(self) -> ComposeResult:
        """Override to yield integration-specific form widgets."""
        raise NotImplementedError

    # ── lifecycle ────────────────────────────────────────────────────

    def on_mount(self) -> None:
        """Hide settings panel until the integration is enabled."""
        try:
            self.query_one(
                f"#{self.integration_id}-settings", Vertical,
            ).display = False
        except NoMatches:
            pass

    def on_checkbox_changed(self, event: Checkbox.Changed) -> None:
        """Toggle settings panel visibility when the checkbox changes."""
        if event.checkbox.id == f"{self.integration_id}-enabled":
            try:
                settings = self.query_one(
                    f"#{self.integration_id}-settings", Vertical,
                )
                settings.display = event.value
                if not event.value:
                    self.update_status("")
            except NoMatches:
                pass

    # ── helpers ──────────────────────────────────────────────────────

    def update_status(self, message: str) -> None:
        """Update the status widget at the bottom of the settings panel."""
        try:
            self.query_one(
                f"#{self.integration_id}-status", Static,
            ).update(message)
        except NoMatches:
            pass

    @property
    def is_enabled(self) -> bool:
        """Return whether the integration checkbox is checked."""
        return hasattr(self, "enabled_checkbox") and self.enabled_checkbox.value

    # ── validation / data ────────────────────────────────────────────

    async def validate(self) -> tuple[bool, str]:
        """Validate; delegates to validate_settings() when enabled."""
        if not self.is_enabled:
            return True, ""
        return await self.validate_settings()

    async def validate_settings(self) -> tuple[bool, str]:
        """Override to validate integration-specific fields.

        Only called when the integration is enabled.
        """
        return True, ""

    def get_data(self) -> dict[str, Any]:
        """Return config data; delegates to get_settings_data() when enabled."""
        if not self.is_enabled:
            return {f"{self.integration_id}_enabled": False}
        data = self.get_settings_data()
        data[f"{self.integration_id}_enabled"] = True
        return data

    def get_settings_data(self) -> dict[str, Any]:
        """Override to return integration-specific config values.

        Only called when the integration is enabled.  The base class
        automatically adds ``{integration_id}_enabled: True``.
        """
        return {}
