"""Linear ticketing step for the init wizard."""
import os
from typing import Any

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.widgets import Button, Input, Label

from lineage.tui.wizards.init.steps.integration_base import IntegrationStepBase


class LinearConnectionStep(IntegrationStepBase):
    """Step: Linear ticketing configuration (optional)."""

    integration_id = "linear"
    integration_label = "Linear"

    def __init__(self):
        """Initialize Linear ticketing step."""
        super().__init__(
            description="Connect Linear to enable the Tickets and Daemon tabs for automated issue management.",
        )
        self.analyst_key_input: Input
        self.engineer_key_input: Input
        self.team_id_input: Input

    def get_settings_content(self) -> ComposeResult:
        """Yield API key and team ID input widgets."""
        yield Button("Load from Environment", id="load-linear-env-btn", variant="default")

        with Horizontal(classes="form-row"):
            with Vertical(classes="form-field"):
                yield Label("Linear Analyst API key:")
                self.analyst_key_input = Input(
                    placeholder="LINEAR_ANALYST_API_KEY",
                    id="linear-analyst-key-input",
                    password=True,
                )
                yield self.analyst_key_input
            with Vertical(classes="form-field"):
                yield Label("Linear Data Engineer API key:")
                self.engineer_key_input = Input(
                    placeholder="LINEAR_DATA_ENGINEER_API_KEY",
                    id="linear-engineer-key-input",
                    password=True,
                )
                yield self.engineer_key_input

        with Horizontal(classes="form-row"):
            with Vertical(classes="form-field"):
                yield Label("Linear Team ID:")
                self.team_id_input = Input(
                    placeholder="LINEAR_TEAM_ID",
                    id="linear-team-id-input",
                )
                yield self.team_id_input

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle load-from-environment button press."""
        if event.button.id == "load-linear-env-btn":
            self._load_from_env()

    def _load_from_env(self) -> None:
        from lineage.utils.env import load_env_file

        load_env_file()
        for env_var, input_widget in [
            ("LINEAR_ANALYST_API_KEY", self.analyst_key_input),
            ("LINEAR_DATA_ENGINEER_API_KEY", self.engineer_key_input),
            ("LINEAR_TEAM_ID", self.team_id_input),
        ]:
            value = os.getenv(env_var)
            if value:
                input_widget.value = value

    async def validate_settings(self) -> tuple[bool, str]:
        """Validate that all three Linear credentials are provided."""
        analyst = self.analyst_key_input.value.strip()
        engineer = self.engineer_key_input.value.strip()
        team_id = self.team_id_input.value.strip()

        if not (analyst and engineer and team_id):
            missing = []
            if not analyst:
                missing.append("Analyst API key")
            if not engineer:
                missing.append("Engineer API key")
            if not team_id:
                missing.append("Team ID")
            return False, f"Missing: {', '.join(missing)}"

        self.update_status("Linear configured")
        return True, ""

    def get_settings_data(self) -> dict[str, Any]:
        """Return Linear API keys and team ID."""
        return {
            "linear_analyst_api_key": self.analyst_key_input.value.strip(),
            "linear_data_engineer_api_key": self.engineer_key_input.value.strip(),
            "linear_team_id": self.team_id_input.value.strip(),
        }
