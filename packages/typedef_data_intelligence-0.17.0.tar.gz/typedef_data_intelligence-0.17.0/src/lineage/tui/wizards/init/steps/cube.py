"""Cube.dev connection step for the init wizard."""

from pathlib import Path
from typing import Any

from textual.app import ComposeResult
from textual.widgets import Checkbox, Input, Label

from lineage.tui.wizards.init.steps.integration_base import IntegrationStepBase


class CubeConnectionStep(IntegrationStepBase):
    """Step: Cube.dev project configuration (optional)."""

    integration_id = "cube"
    integration_label = "Cube.dev"

    def __init__(self):
        """Initialize Cube.dev connection step."""
        super().__init__(
            description="Connect a Cube.dev project to include semantic layer metadata.",
        )
        self.project_dir_input: Input
        self.project_name_input: Input
        self.stitch_checkbox: Checkbox

    def get_settings_content(self) -> ComposeResult:
        """Yield project directory, name, and stitch-to-dbt widgets."""
        yield Label("Project directory:")
        self.project_dir_input = Input(
            placeholder="/path/to/cube-project",
            id="cube-project-dir",
        )
        yield self.project_dir_input

        yield Label("Project name (optional, defaults to directory name):")
        self.project_name_input = Input(
            placeholder="my_cube_project",
            id="cube-project-name",
        )
        yield self.project_name_input

        self.stitch_checkbox = Checkbox(
            "Stitch to dbt models", id="cube-stitch", value=True,
        )
        yield self.stitch_checkbox

    async def validate_settings(self) -> tuple[bool, str]:
        """Validate that the project directory exists and has a model/ subdirectory."""
        project_dir = self.project_dir_input.value.strip()
        if not project_dir:
            return False, "Project directory is required"

        path = Path(project_dir).expanduser()
        if not path.is_dir():
            return False, f"Directory not found: {path}"

        model_dir = path / "model"
        if not model_dir.is_dir():
            return False, f"No model/ subdirectory found in {path}"

        self.update_status(f"Valid: {path}")
        return True, ""

    def get_settings_data(self) -> dict[str, Any]:
        """Return Cube.dev project configuration."""
        return {
            "cube_project_dir": self.project_dir_input.value.strip(),
            "cube_project_name": self.project_name_input.value.strip() or None,
            "cube_stitch_to_dbt": self.stitch_checkbox.value,
        }
