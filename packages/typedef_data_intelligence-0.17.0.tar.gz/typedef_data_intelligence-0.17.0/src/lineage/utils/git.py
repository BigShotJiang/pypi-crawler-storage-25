"""Git utility functions for repository management."""

from __future__ import annotations

import asyncio
import logging
import re
import subprocess
from collections.abc import AsyncIterator
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)


def is_valid_git_url(url: str) -> bool:
    """Check if a string looks like a valid git URL.

    Rejects URLs starting with ``-`` to prevent git option injection.
    """
    if not url or url.startswith("-"):
        return False
    return (
        url.startswith("http://")
        or url.startswith("https://")
        or url.startswith("git@")
        or url.endswith(".git")
    )


def clone_repo(url: str, dest_path: Path) -> None:
    """Clone a git repository to the specified path.

    Uses ``--`` separator to prevent git option injection via crafted URLs.

    Raises:
        subprocess.CalledProcessError: If git clone fails.
        ValueError: If destination exists and is not empty, or URL is invalid.
    """
    if not is_valid_git_url(url):
        raise ValueError(f"Invalid git URL: {url}")

    if dest_path.exists() and any(dest_path.iterdir()):
        raise ValueError(f"Destination path {dest_path} exists and is not empty")

    dest_path.mkdir(parents=True, exist_ok=True)

    logger.info("Cloning %s to %s", url, dest_path)
    subprocess.run(  # nosec B603 B607
        ["git", "clone", "--", url, str(dest_path)],
        check=True,
        capture_output=True,
        text=True,
    )


# ── Streaming clone with progress ────────────────────────────────────


@dataclass
class CloneProgress:
    """A single progress update from a git clone operation."""

    phase: str  # "counting", "compressing", "receiving", "resolving", "done", "error"
    percent: int  # 0-100
    message: str  # raw line from git stderr


# Regex to parse git progress lines like:
# "Receiving objects:  67% (835/1247)"
_PROGRESS_RE = re.compile(r"(Counting|Compressing|Receiving|Resolving)[^:]*:\s*(\d+)%")
_URL_CREDENTIALS_RE = re.compile(r"(?P<scheme>https?://)(?:[^/\s@]+(?::[^/\s@]*)?@)")


def _handle_clone_stderr_line(
    line: str,
    *,
    stderr_lines: list[str],
) -> CloneProgress | None:
    """Parse one stderr line as progress or retain it for failure reporting."""
    match = _PROGRESS_RE.search(line)
    if not match:
        stderr_lines.append(line)
        return None

    return CloneProgress(
        phase=match.group(1).lower(),
        percent=int(match.group(2)),
        message=line,
    )


def _build_clone_failure_message(stderr_lines: list[str], exit_code: int) -> str:
    """Return the cleaned clone failure text to surface to callers."""
    stderr_detail = "\n".join(line.strip() for line in stderr_lines if line.strip())
    return stderr_detail or f"git clone failed (exit {exit_code})"


def _build_clone_failure_log_summary(stderr_message: str, exit_code: int) -> str:
    """Return a redacted one-line summary safe for error logs."""
    first_line = next(
        (line.strip() for line in stderr_message.splitlines() if line.strip()), ""
    )
    if not first_line:
        return f"git clone failed (exit {exit_code})"
    return _URL_CREDENTIALS_RE.sub(r"\g<scheme>", first_line)


async def clone_repo_with_progress(
    url: str,
    dest_path: Path,
) -> AsyncIterator[CloneProgress]:
    """Clone a git repository with streaming progress updates.

    Uses ``asyncio.create_subprocess_exec`` with ``--progress`` flag.
    Git writes progress to stderr; we parse percentage from each line.

    Yields:
        CloneProgress instances as the clone proceeds.

    Raises:
        ValueError: If the URL is invalid.
        RuntimeError: If the clone fails (after yielding an error event).
    """
    if not is_valid_git_url(url):
        raise ValueError(f"Invalid git URL: {url}")

    if dest_path.exists() and any(dest_path.iterdir()):
        raise ValueError(f"Destination path {dest_path} exists and is not empty")

    dest_path.mkdir(parents=True, exist_ok=True)

    proc = await asyncio.create_subprocess_exec(
        "git",
        "clone",
        "--progress",
        "--",
        url,
        str(dest_path),
        stdout=asyncio.subprocess.DEVNULL,
        stderr=asyncio.subprocess.PIPE,
    )

    assert proc.stderr is not None  # guaranteed by PIPE  # nosec B101

    # Git writes progress to stderr with \r for in-place updates.
    # Read in chunks and split on \r/\n to surface progress updates.
    buffer = ""
    stderr_lines: list[str] = []
    while True:
        chunk = await proc.stderr.read(256)
        if not chunk:
            break
        text = chunk.decode("utf-8", errors="replace")
        buffer += text

        # Split on both \r and \n to catch progress lines
        while "\r" in buffer or "\n" in buffer:
            # Find the earliest delimiter
            r_pos = buffer.find("\r")
            n_pos = buffer.find("\n")
            if r_pos == -1:
                split_pos = n_pos
            elif n_pos == -1:
                split_pos = r_pos
            else:
                split_pos = min(r_pos, n_pos)

            line = buffer[:split_pos].strip()
            buffer = buffer[split_pos + 1 :]

            if not line:
                continue

            progress = _handle_clone_stderr_line(line, stderr_lines=stderr_lines)
            if progress is not None:
                yield progress

    tail = buffer.strip()
    if tail:
        progress = _handle_clone_stderr_line(tail, stderr_lines=stderr_lines)
        if progress is not None:
            yield progress

    exit_code = await proc.wait()
    if exit_code == 0:
        yield CloneProgress(phase="done", percent=100, message="Clone complete")
    else:
        stderr_message = _build_clone_failure_message(stderr_lines, exit_code)
        log_summary = _build_clone_failure_log_summary(stderr_message, exit_code)
        logger.error(
            "git clone failed (exit %s): %s",
            exit_code,
            log_summary,
        )
        logger.debug("git clone full stderr (exit %s):\n%s", exit_code, stderr_message)
        yield CloneProgress(phase="error", percent=0, message=stderr_message)
        raise RuntimeError(f"git clone failed (exit {exit_code}): {stderr_message}")
