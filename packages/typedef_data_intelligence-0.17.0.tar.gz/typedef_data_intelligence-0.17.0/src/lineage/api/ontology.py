"""Read-only ontology API endpoints."""

from __future__ import annotations

from asyncio import to_thread
from typing import Any

from fastapi import Depends, HTTPException, Query, Request
from lineage.api.app import AppState, app, get_app_state
from lineage.api.concept_cards import build_concept_card


def _require_ontology_reader(state: AppState) -> Any:
    reader = state.ontology_reader
    if reader is None:
        raise HTTPException(
            status_code=503,
            detail=(
                "Ontology API is unavailable. Configure TYPEDEF_ONTOLOGY_DB_PATH and "
                "ensure ontology data has been written."
            ),
        )
    return reader


def _matches_quality(item: dict[str, Any], quality_tier: str | None) -> bool:
    if not quality_tier:
        return True
    return item.get("quality_tier") == quality_tier


@app.get("/ontology/summary")
async def ontology_summary(
    request: Request,
    state: AppState = Depends(get_app_state),  # noqa: B008 expected for fastapi
):
    """Return high-level ontology counts and publication stats."""
    reader = _require_ontology_reader(state)
    metadata = await to_thread(reader.get_metadata)

    if metadata:
        return {
            "metadata": metadata,
            "published": {
                "event_families": metadata.get("published_event_families", 0),
                "behavior_patterns": metadata.get("published_behavior_patterns", 0),
                "process_candidates": metadata.get("published_process_candidates", 0),
                "metrics": metadata.get("published_metrics", 0),
                "metric_families": metadata.get("published_metric_families", 0),
            },
        }

    anchors = await to_thread(reader.list_anchors)
    families = await to_thread(reader.list_event_families)
    patterns = await to_thread(reader.list_behavior_patterns)
    processes = await to_thread(reader.list_process_candidates)
    primary = sum(1 for anchor in anchors if anchor.get("is_primary"))
    secondary = len(anchors) - primary
    return {
        "metadata": {
            "anchors_retained": len(anchors),
            "primary_anchor_count": primary,
            "secondary_anchor_count": secondary,
            "event_families_inferred": len(families),
            "behavior_patterns_inferred": len(patterns),
            "process_candidates_inferred": len(processes),
        },
        "published": {
            "event_families": sum(1 for family in families if family.get("is_published")),
            "behavior_patterns": sum(1 for pattern in patterns if pattern.get("is_published")),
            "process_candidates": sum(1 for process in processes if process.get("is_published")),
        },
    }


@app.get("/ontology/anchors")
async def list_ontology_anchors(
    request: Request,
    primary_only: bool = Query(False),
    anchor_kind: str | None = Query(None),
    anchor_role: str | None = Query(None),
    limit: int = Query(50, ge=1, le=500),
    state: AppState = Depends(get_app_state),  # noqa: B008 expected for fastapi
):
    """List ontology anchors with simple filtering."""
    reader = _require_ontology_reader(state)
    anchors = await to_thread(reader.list_anchors)

    if primary_only:
        anchors = [anchor for anchor in anchors if anchor.get("is_primary")]
    if anchor_kind:
        anchors = [anchor for anchor in anchors if anchor.get("anchor_kind") == anchor_kind]
    if anchor_role:
        anchors = [anchor for anchor in anchors if anchor.get("anchor_role") == anchor_role]

    anchors = sorted(anchors, key=lambda anchor: anchor.get("score", 0), reverse=True)
    return {"items": anchors[:limit], "count": len(anchors)}


@app.get("/ontology/anchors/{anchor_id}/context")
async def get_ontology_anchor_context(
    anchor_id: str,
    request: Request,
    published_only: bool = Query(True),
    debug: bool = Query(False),
    state: AppState = Depends(get_app_state),  # noqa: B008 expected for fastapi
):
    """Return a concept-card style view for a single anchor."""
    reader = _require_ontology_reader(state)
    anchor = await to_thread(reader.get_anchor, anchor_id)
    if anchor is None:
        raise HTTPException(status_code=404, detail=f"Unknown ontology anchor: {anchor_id}")

    card = await to_thread(
        build_concept_card, reader, anchor_id,
        debug=debug, published_only=published_only,
    )
    return card


@app.get("/ontology/anchors/{anchor_id}")
async def get_ontology_anchor(
    anchor_id: str,
    request: Request,
    state: AppState = Depends(get_app_state),  # noqa: B008 expected for fastapi
):
    """Get a full ontology anchor record."""
    reader = _require_ontology_reader(state)
    anchor = await to_thread(reader.get_anchor, anchor_id)
    if anchor is None:
        raise HTTPException(status_code=404, detail=f"Unknown ontology anchor: {anchor_id}")
    return anchor


@app.get("/ontology/families")
async def list_ontology_event_families(
    request: Request,
    published_only: bool = Query(True),
    anchor_id: str | None = Query(None),
    quality_tier: str | None = Query(None),
    limit: int = Query(50, ge=1, le=500),
    state: AppState = Depends(get_app_state),  # noqa: B008 expected for fastapi
):
    """List event families."""
    reader = _require_ontology_reader(state)
    if anchor_id:
        families = await to_thread(reader.get_anchor_event_families, anchor_id, published_only=published_only)
    else:
        families = await to_thread(reader.list_event_families, published_only=published_only)
    families = [family for family in families if _matches_quality(family, quality_tier)]
    families = sorted(families, key=lambda family: family.get("score", 0), reverse=True)
    return {"items": families[:limit], "count": len(families)}


@app.get("/ontology/behavior-patterns")
async def list_ontology_behavior_patterns(
    request: Request,
    published_only: bool = Query(True),
    anchor_id: str | None = Query(None),
    quality_tier: str | None = Query(None),
    limit: int = Query(50, ge=1, le=500),
    state: AppState = Depends(get_app_state),  # noqa: B008 expected for fastapi
):
    """List behavior patterns."""
    reader = _require_ontology_reader(state)
    if anchor_id:
        patterns = await to_thread(reader.get_anchor_behavior_patterns, anchor_id, published_only=published_only)
    else:
        patterns = await to_thread(reader.list_behavior_patterns, published_only=published_only)
    patterns = [pattern for pattern in patterns if _matches_quality(pattern, quality_tier)]
    patterns = sorted(patterns, key=lambda pattern: pattern.get("score", 0), reverse=True)
    return {"items": patterns[:limit], "count": len(patterns)}


@app.get("/ontology/processes")
async def list_ontology_process_candidates(
    request: Request,
    published_only: bool = Query(True),
    anchor_id: str | None = Query(None),
    quality_tier: str | None = Query(None),
    limit: int = Query(50, ge=1, le=500),
    state: AppState = Depends(get_app_state),  # noqa: B008 expected for fastapi
):
    """List process candidates."""
    reader = _require_ontology_reader(state)
    if anchor_id:
        processes = await to_thread(reader.get_anchor_process_candidates, anchor_id, published_only=published_only)
    else:
        processes = await to_thread(reader.list_process_candidates, published_only=published_only)
    processes = [process for process in processes if _matches_quality(process, quality_tier)]
    processes = sorted(processes, key=lambda process: process.get("score", 0), reverse=True)
    return {"items": processes[:limit], "count": len(processes)}


@app.get("/ontology/metrics")
async def list_ontology_metrics(
    request: Request,
    published_only: bool = Query(True),
    anchor_id: str | None = Query(None),
    quality_tier: str | None = Query(None),
    limit: int = Query(50, ge=1, le=500),
    state: AppState = Depends(get_app_state),  # noqa: B008 expected for fastapi
):
    """List metric candidates."""
    reader = _require_ontology_reader(state)
    if anchor_id:
        metrics = await to_thread(reader.get_anchor_metrics, anchor_id, published_only=published_only)
    else:
        metrics = await to_thread(reader.list_metrics, published_only=published_only)
    metrics = [m for m in metrics if _matches_quality(m, quality_tier)]
    metrics = sorted(metrics, key=lambda m: m.get("score", 0), reverse=True)
    return {"items": metrics[:limit], "count": len(metrics)}


@app.get("/ontology/metric-families")
async def list_ontology_metric_families(
    request: Request,
    published_only: bool = Query(True),
    anchor_id: str | None = Query(None),
    limit: int = Query(50, ge=1, le=500),
    state: AppState = Depends(get_app_state),  # noqa: B008 expected for fastapi
):
    """List metric families."""
    reader = _require_ontology_reader(state)
    if anchor_id:
        families = await to_thread(reader.get_anchor_metric_families, anchor_id, published_only=published_only)
    else:
        families = await to_thread(reader.list_metric_families, published_only=published_only)
    families = sorted(families, key=lambda f: f.get("score", 0), reverse=True)
    return {"items": families[:limit], "count": len(families)}


@app.get("/ontology/metrics/{metric_id}")
async def get_ontology_metric(
    metric_id: str,
    request: Request,
    state: AppState = Depends(get_app_state),  # noqa: B008 expected for fastapi
):
    """Get a single metric by ID."""
    reader = _require_ontology_reader(state)
    metric = await to_thread(reader.get_metric, metric_id)
    if metric is None:
        raise HTTPException(status_code=404, detail=f"Unknown metric: {metric_id}")
    return metric


@app.get("/ontology/search")
async def ontology_search(
    q: str,
    request: Request,
    limit: int = Query(10, ge=1, le=100),
    state: AppState = Depends(get_app_state),  # noqa: B008 expected for fastapi
):
    """Search across ontology anchors and published behavior layers."""
    reader = _require_ontology_reader(state)
    term = q.strip().lower()
    if not term:
        return {"anchors": [], "event_families": [], "behavior_patterns": [], "process_candidates": [], "metrics": [], "metric_families": []}

    anchors = await to_thread(reader.list_anchors)
    families = await to_thread(reader.list_event_families, published_only=True)
    patterns = await to_thread(reader.list_behavior_patterns, published_only=True)
    processes = await to_thread(reader.list_process_candidates, published_only=True)
    metrics = await to_thread(reader.list_metrics, published_only=True)
    metric_fams = await to_thread(reader.list_metric_families, published_only=True)

    def _match(items: list[dict[str, Any]], fields: list[str]) -> list[dict[str, Any]]:
        matched = []
        for item in items:
            haystack = " ".join(str(item.get(field, "")) for field in fields).lower()
            if term in haystack:
                matched.append(item)
        matched.sort(key=lambda item: item.get("score", 0), reverse=True)
        return matched[:limit]

    return {
        "anchors": _match(anchors, ["anchor_id", "canonical_name", "anchor_role", "anchor_kind"]),
        "event_families": _match(families, ["family_id", "family_label"]),
        "behavior_patterns": _match(patterns, ["pattern_id", "pattern_label", "family_label"]),
        "process_candidates": _match(processes, ["process_id", "process_label"]),
        "metrics": _match(metrics, ["metric_id", "display_name", "agg"]),
        "metric_families": _match(metric_fams, ["family_id", "family_label", "canonical_family_name"]),
    }
