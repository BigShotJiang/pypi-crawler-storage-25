"""Desktop quick start routes.

Guided onboarding for the public medallion-reference sample project.
"""

from __future__ import annotations

import asyncio
import json
import logging
import multiprocessing
import os
import queue as queue_module
import re
import shutil
import threading
import time
import uuid
from dataclasses import dataclass
from multiprocessing import Event, Process, Queue
from pathlib import Path
from subprocess import CalledProcessError  # nosec B404
from typing import Any

import yaml
from agent.api import shutdown_event
from core.paths import (
    config_path,
    ensure_home,
    env_path,
    logs_dir,
    profiles_dir,
    projects_dir,
)
from fastapi import APIRouter, HTTPException
from lineage.api.desktop_setup import (
    CreateProjectRequest,
    _sanitize_project_name,
    create_project,
)
from pydantic import BaseModel
from starlette.responses import StreamingResponse

logger = logging.getLogger(__name__)


def _sse_event(event_type: str, data: dict[str, Any]) -> str:
    """Format a single SSE event as a string."""
    return f"event: {event_type}\ndata: {json.dumps(data)}\n\n"


router = APIRouter(prefix="/desktop/quickstart", tags=["desktop-quickstart"])

QUICKSTART_DISPLAY_NAME = "medallion-reference"
QUICKSTART_PROJECT_NAME = _sanitize_project_name(QUICKSTART_DISPLAY_NAME)
QUICKSTART_GIT_URL = "https://github.com/typedef-ai/medallion-reference.git"
QUICKSTART_PROFILE_NAME = "medallion_reference"
QUICKSTART_DBT_TARGET = "duckdb"
QUICKSTART_DUCKDB_FILENAME = "medallion-reference.duckdb"
QUICKSTART_SEMANTIC_VIEW_EXCLUDE = ["--exclude", "config.materialized:semantic_view"]
QUICKSTART_STAGE_ORDER = {
    "clone": 1,
    "venv": 2,
    "deps": 3,
    "seed": 4,
    "build": 5,
    "docs": 6,
    "sync": 7,
    "semantic": 8,
}
QUICKSTART_TOTAL_STAGES = len(QUICKSTART_STAGE_ORDER)


@dataclass
class QuickstartOperation:
    """In-memory state for a running quick start process."""

    quickstart_id: str
    process: Process | None = None
    queue: Queue | None = None
    cancel_event: Event | None = None
    status: str = "pending"
    started_at: float = 0.0
    error: str | None = None
    previous_default_project: str | None = None
    last_event: dict[str, Any] | None = None
    terminal_event_path: Path | None = None


_quickstart_ops: dict[str, QuickstartOperation] = {}
_quickstart_lock = threading.Lock()


def _get_quickstart_op(quickstart_id: str) -> QuickstartOperation | None:
    with _quickstart_lock:
        return _quickstart_ops.get(quickstart_id)


def _remove_quickstart_op(quickstart_id: str) -> None:
    with _quickstart_lock:
        _quickstart_ops.pop(quickstart_id, None)


TERMINAL_STATUSES = {"completed", "error", "cancelled", "awaiting_input"}
ANSI_ESCAPE_RE = re.compile(r"\x1b\[[0-9;]*m")


class QuickstartStartResponse(BaseModel):
    """Response containing the quick start operation identifier."""

    quickstart_id: str
    project_name: str
    display_name: str


def _strip_ansi(text: str) -> str:
    """Remove ANSI escape sequences before surfacing subprocess errors."""
    return ANSI_ESCAPE_RE.sub("", text)


def _stage_event(
    stage: str,
    status: str,
    message: str,
    *,
    percent: int | None = None,
    detail: str | None = None,
    terminal: bool | None = None,
) -> dict[str, Any]:
    """Build a consistent quick start progress payload."""
    payload: dict[str, Any] = {
        "stage": stage,
        "status": status,
        "message": message,
        "current": QUICKSTART_STAGE_ORDER.get(stage, QUICKSTART_TOTAL_STAGES),
        "total": QUICKSTART_TOTAL_STAGES,
        "project_name": QUICKSTART_PROJECT_NAME,
        "display_name": QUICKSTART_DISPLAY_NAME,
    }
    if percent is not None:
        payload["percent"] = percent
    if detail:
        payload["detail"] = detail
    if terminal is not None:
        payload["terminal"] = terminal
    return payload


def _terminal_event_path(quickstart_id: str) -> Path:
    """Return the persisted terminal event path for a quickstart run."""
    return logs_dir() / f"quickstart-{quickstart_id}.json"


def _persist_terminal_event(path: Path, event: dict[str, Any]) -> None:
    """Persist the final worker event so the parent can recover terminal state."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = path.with_suffix(".tmp")
    tmp_path.write_text(json.dumps(event))
    os.replace(str(tmp_path), str(path))


def _read_terminal_event(path: Path | None) -> dict[str, Any] | None:
    """Load a persisted terminal event if one exists."""
    if path is None or not path.exists():
        return None

    try:
        data = json.loads(path.read_text())
    except (OSError, ValueError):
        logger.warning("[desktop:quickstart] Failed to read terminal event %s", path)
        return None

    if not isinstance(data, dict):
        return None
    if data.get("status") not in TERMINAL_STATUSES:
        return None
    return data


def _emit_terminal_event(
    queue: Queue,
    terminal_event_path: Path,
    stage: str,
    status: str,
    message: str,
) -> None:
    """Persist and enqueue a terminal event."""
    event = _stage_event(stage, status, message, terminal=True)
    _persist_terminal_event(terminal_event_path, event)
    _emit(queue, stage, status, message, terminal=True)


def _read_config() -> dict[str, Any]:
    """Read the desktop config file, returning an empty dict when absent."""
    cfg_file = config_path()
    if not cfg_file.exists():
        return {}
    return yaml.safe_load(cfg_file.read_text()) or {}


def _write_config(data: dict[str, Any]) -> None:
    """Write the desktop config file atomically."""
    cfg_file = config_path()
    tmp = cfg_file.with_suffix(".yaml.tmp")
    tmp.write_text(yaml.dump(data, default_flow_style=False, sort_keys=False))
    os.replace(str(tmp), str(cfg_file))


def _set_project_status(project_name: str, status: str) -> None:
    """Update the project status in config.yaml if the project exists."""
    config = _read_config()
    project = (config.get("projects") or {}).get(project_name)
    if not isinstance(project, dict):
        return
    project["status"] = status
    _write_config(config)


def _delete_quickstart_project(previous_default_project: str | None = None) -> None:
    """Remove quick start filesystem/config artifacts after a failed run."""
    config = _read_config()
    projects = config.get("projects") or {}
    if QUICKSTART_PROJECT_NAME in projects:
        del projects[QUICKSTART_PROJECT_NAME]
        config["projects"] = projects
        if config.get("default_project") == QUICKSTART_PROJECT_NAME:
            if previous_default_project in projects:
                config["default_project"] = previous_default_project
            else:
                remaining = list(projects.keys())
                config["default_project"] = remaining[0] if remaining else None
        _write_config(config)

    shutil.rmtree(projects_dir() / QUICKSTART_PROJECT_NAME, ignore_errors=True)
    shutil.rmtree(profiles_dir() / QUICKSTART_PROJECT_NAME, ignore_errors=True)


def _load_runtime_env(project_name: str) -> dict[str, str]:
    """Load global .env and per-project env vars for dbt and sync subprocesses."""
    from lineage.api.desktop_setup import _ALLOWED_CREDENTIAL_KEYS

    loaded: dict[str, str] = {}

    # Desktop builds inject managed credentials into the backend process env.
    # Use those as the baseline so quick start honors keychain-provided keys.
    for key in _ALLOWED_CREDENTIAL_KEYS:
        value = os.environ.get(key)
        if value:
            loaded[key] = value

    env_file = env_path()
    if env_file.exists():
        for line in env_file.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, value = line.split("=", 1)
                key = key.strip()
                value = value.strip()
                loaded[key] = value
                os.environ[key] = value

    project = (_read_config().get("projects") or {}).get(project_name) or {}
    project_env = project.get("env") or {}
    if isinstance(project_env, dict):
        for key, value in project_env.items():
            loaded[str(key)] = str(value)
            os.environ[str(key)] = str(value)

    return loaded


def _emit(queue: Queue, stage: str, status: str, message: str, **extra: Any) -> None:
    """Put a stage event onto the multiprocessing queue."""
    event = _stage_event(stage, status, message, **extra)
    while True:
        try:
            queue.put_nowait(event)
            return
        except queue_module.Full:
            dropped = 0
            while True:
                try:
                    queue.get_nowait()
                    dropped += 1
                except queue_module.Empty:
                    break

            if dropped == 0:
                logger.warning(
                    "[desktop:quickstart] Failed to enqueue quickstart event",
                    extra={"stage": stage, "status": status},
                )
                return


async def _run_clone_stage(
    project_dir: Path, queue: Queue, cancel_event: Event
) -> None:
    """Clone the sample repo while forwarding git progress to the frontend."""
    from lineage.utils.git import clone_repo_with_progress

    _emit(queue, "clone", "running", "Cloning sample project from GitHub", percent=0)
    async for progress in clone_repo_with_progress(QUICKSTART_GIT_URL, project_dir):
        if cancel_event.is_set():
            raise KeyboardInterrupt("Quick start cancelled by user")
        if progress.phase == "done":
            _emit(queue, "clone", "completed", "Cloned sample project", percent=100)
        elif progress.phase == "error":
            raise RuntimeError(progress.message)
        else:
            _emit(
                queue,
                "clone",
                "running",
                "Cloning sample project from GitHub",
                percent=progress.percent,
                detail=progress.message,
            )


def _run_dbt_stage(
    *,
    stage: str,
    message: str,
    command: list[str],
    project_dir: Path,
    profiles_path: Path,
    venv_dir: Path,
    extra_env: dict[str, str],
    queue: Queue,
    cancel_event: Event,
) -> None:
    """Run a single dbt command and convert failures into concise errors."""
    from lineage.utils.dbt import run_dbt_command

    if cancel_event.is_set():
        raise KeyboardInterrupt("Quick start cancelled by user")

    _emit(queue, stage, "running", message)
    try:
        run_dbt_command(
            command,
            project_dir,
            profiles_dir=profiles_path,
            venv_dir=venv_dir,
            extra_env=extra_env or None,
        )
    except CalledProcessError as exc:
        detail = _strip_ansi(exc.stderr or exc.stdout or str(exc)).strip()
        display = detail if len(detail) <= 2000 else detail[:2000] + "..."
        raise RuntimeError(display) from exc

    _emit(queue, stage, "completed", message.replace("Running ", "Completed "))


def _persist_quickstart_synced_commit(project_name: str) -> None:
    """Resolve the HEAD of the cloned project and persist it as last_synced_commit."""
    import subprocess  # nosec B404

    try:
        from lineage.api.desktop_sync import _persist_synced_commit

        project_dir = projects_dir() / project_name
        proc = subprocess.run(  # nosec B603, B607
            ["git", "rev-parse", "HEAD"],
            cwd=project_dir,
            capture_output=True,
            text=True,
            timeout=5,
        )
        if proc.returncode == 0:
            head = proc.stdout.strip() or None
            _persist_synced_commit(project_name, head)
    except Exception:
        logger.warning("Failed to persist quickstart synced commit", exc_info=True)


def _run_sync_stage(project_name: str, queue: Queue, cancel_event: Event) -> bool:
    """Run the unified pipeline, optionally including semantic analysis."""
    from ingest.unified.orchestrator import UnifiedOrchestrator
    from ingest.unified.stages.types import UnifiedPipelineConfig

    runtime_env = _load_runtime_env(project_name)
    should_run_semantic = bool(runtime_env.get("OPENAI_API_KEY"))
    sync_completed = False

    from ingest.unified.stages.registry import get_stage_label

    def progress_callback(stage_name: str, _current: int, _total: int) -> None:
        nonlocal sync_completed
        if cancel_event.is_set():
            raise KeyboardInterrupt("Quick start cancelled by user")
        if stage_name == "semantic":
            if not sync_completed:
                _emit(queue, "sync", "completed", "Catalog synced")
                sync_completed = True
            _emit(queue, "semantic", "running", "Analyzing semantic metadata")
            return
        if sync_completed:
            return
        label = get_stage_label(stage_name)
        _emit(queue, "sync", "running", label, detail=stage_name)

    _emit(queue, "sync", "running", "Syncing catalog")
    config = UnifiedPipelineConfig.from_project_name(
        project_name,
        full=False,
        skip_semantic=not should_run_semantic,
    )
    orchestrator = UnifiedOrchestrator(config, progress_callback=progress_callback)
    result = orchestrator.run()

    # Persist the synced commit so the frontend staleness check starts from
    # the correct baseline.  Without this, first-launch after quickstart sees
    # last_synced_commit=null + head_commit=<hash> → stale (red bar).
    _persist_quickstart_synced_commit(project_name)

    if not sync_completed:
        _emit(queue, "sync", "completed", "Catalog synced")

    if should_run_semantic:
        semantic_result = next(
            (stage for stage in result.stages if stage.stage == "semantic"), None
        )
        if semantic_result is not None and semantic_result.skipped:
            _emit(queue, "semantic", "completed", "Semantic analysis skipped")
        else:
            _emit(queue, "semantic", "completed", "Semantic analysis complete")
    else:
        _emit(
            queue,
            "semantic",
            "awaiting_input",
            "OpenAI API key not found. Save your key to continue semantic analysis.",
        )

    return should_run_semantic


def _quickstart_worker(
    project_name: str,
    previous_default_project: str | None,
    quickstart_id: str,
    progress_queue: Queue,
    cancel_event: Event,
) -> None:
    """Run the sample-project onboarding flow in a child process."""
    import logging as _logging

    _logs = logs_dir()
    _logs.mkdir(parents=True, exist_ok=True)
    _log_file = _logs / "quickstart.log"
    _fmt = _logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    _fh = _logging.FileHandler(str(_log_file), mode="a")
    _fh.setLevel(_logging.INFO)
    _fh.setFormatter(_fmt)

    root = _logging.getLogger()
    root.setLevel(_logging.INFO)
    root.addHandler(_fh)
    _logging.getLogger("httpcore").setLevel(_logging.WARNING)
    _logging.getLogger("httpx").setLevel(_logging.WARNING)
    _logging.getLogger("google_genai.models").setLevel(_logging.WARNING)

    project_dir = projects_dir() / project_name
    profiles_path = profiles_dir() / project_name
    terminal_event_path = _terminal_event_path(quickstart_id)
    quickstart_log = _logging.getLogger("desktop.quickstart")
    quickstart_log.info("=== quick start started for project '%s' ===", project_name)
    current_stage = "clone"

    try:
        if project_dir.exists() and not any(project_dir.iterdir()):
            project_dir.rmdir()
        asyncio.run(_run_clone_stage(project_dir, progress_queue, cancel_event))

        if cancel_event.is_set():
            raise KeyboardInterrupt("Quick start cancelled by user")

        from lineage.tui.wizards.init.helpers import ensure_dbt_venv

        current_stage = "venv"
        _emit(progress_queue, "venv", "running", "Preparing dbt DuckDB environment")
        venv_dir = ensure_dbt_venv("duckdb")
        _emit(progress_queue, "venv", "completed", "Prepared dbt DuckDB environment")

        extra_env = _load_runtime_env(project_name)
        target_args = ["--target", QUICKSTART_DBT_TARGET]
        current_stage = "deps"
        _run_dbt_stage(
            stage="deps",
            message="Running dbt deps",
            command=["deps"],
            project_dir=project_dir,
            profiles_path=profiles_path,
            venv_dir=venv_dir,
            extra_env=extra_env,
            queue=progress_queue,
            cancel_event=cancel_event,
        )
        current_stage = "seed"
        _run_dbt_stage(
            stage="seed",
            message="Running dbt seed",
            command=["seed", *target_args],
            project_dir=project_dir,
            profiles_path=profiles_path,
            venv_dir=venv_dir,
            extra_env=extra_env,
            queue=progress_queue,
            cancel_event=cancel_event,
        )
        current_stage = "build"
        _run_dbt_stage(
            stage="build",
            message="Running dbt build",
            command=["build", *target_args, *QUICKSTART_SEMANTIC_VIEW_EXCLUDE],
            project_dir=project_dir,
            profiles_path=profiles_path,
            venv_dir=venv_dir,
            extra_env=extra_env,
            queue=progress_queue,
            cancel_event=cancel_event,
        )
        current_stage = "docs"
        if cancel_event.is_set():
            raise KeyboardInterrupt("Quick start cancelled by user")
        _emit(progress_queue, "docs", "running", "Running dbt docs generate")

        from lineage.utils.dbt import run_dbt_docs_generate

        docs_result = run_dbt_docs_generate(
            project_dir=project_dir,
            profiles_dir=profiles_path,
            venv_dir=venv_dir,
            extra_env=extra_env or None,
            target_args=[*target_args, *QUICKSTART_SEMANTIC_VIEW_EXCLUDE],
        )
        if docs_result.success:
            _emit(progress_queue, "docs", "completed", "Completed dbt docs generate")
        else:
            error_msg = docs_result.error_summary or "Unknown error"
            if docs_result.log_hint:
                error_msg += f"\nFull dbt log: {docs_result.log_hint}"
            raise RuntimeError(error_msg)

        current_stage = "sync"
        ran_semantic = _run_sync_stage(project_name, progress_queue, cancel_event)
        _set_project_status(project_name, "ready")
        if ran_semantic:
            _emit_terminal_event(
                progress_queue,
                terminal_event_path,
                "semantic",
                "completed",
                "Quick Start complete",
            )
        else:
            _emit_terminal_event(
                progress_queue,
                terminal_event_path,
                "semantic",
                "awaiting_input",
                "Catalog ready. Save an OpenAI key to continue semantic analysis.",
            )
    except KeyboardInterrupt:
        quickstart_log.info("=== quick start cancelled ===")
        _delete_quickstart_project(previous_default_project)
        _emit_terminal_event(
            progress_queue,
            terminal_event_path,
            current_stage,
            "cancelled",
            "Quick Start cancelled by user",
        )
    except Exception as exc:
        import traceback

        quickstart_log.error("=== quick start failed ===\n%s", traceback.format_exc())
        _delete_quickstart_project(previous_default_project)
        _emit_terminal_event(
            progress_queue,
            terminal_event_path,
            current_stage,
            "error",
            _strip_ansi(str(exc)).strip() or "Quick Start failed",
        )


def _watch_quickstart_process(quickstart_id: str) -> None:
    """Mark finished operations even if no SSE client is attached."""
    op = _get_quickstart_op(quickstart_id)
    if op is None or op.process is None:
        return

    op.process.join()
    current = _get_quickstart_op(quickstart_id)
    if current is None or current.status != "running":
        return

    exit_code = current.process.exitcode if current.process else None
    if exit_code == 0:
        terminal_event = _read_terminal_event(current.terminal_event_path)
        if terminal_event is not None:
            current.status = str(terminal_event.get("status", "completed"))
            current.last_event = terminal_event
        else:
            current.status = "completed"
            current.last_event = {
                **_stage_event(
                    "semantic",
                    "completed",
                    "Quick Start complete",
                    terminal=True,
                ),
                "status": "completed",
            }
    else:
        current.status = "error"
        current.error = f"Quick Start process exited unexpectedly (code {exit_code})"
        current.last_event = {
            **_stage_event("clone", "error", current.error, terminal=True),
            "status": "error",
        }


def _cleanup_quickstart_op(operation: QuickstartOperation, *, force: bool) -> None:
    """Release process and queue resources for a finished operation."""
    if not force:
        return

    if operation.process:
        operation.process.join(timeout=5)
        if operation.process.is_alive():
            logger.warning(
                "[desktop:quickstart] Force-killing process %d",
                operation.process.pid or 0,
            )
            operation.process.terminate()
            operation.process.join(timeout=2)
        operation.process.close()
        operation.process = None

    if operation.queue:
        try:
            while not operation.queue.empty():
                operation.queue.get_nowait()
        except queue_module.Empty:
            pass
        operation.queue.close()
        operation.queue.join_thread()
        operation.queue = None

    operation.cancel_event = None
    if operation.terminal_event_path and operation.terminal_event_path.exists():
        operation.terminal_event_path.unlink(missing_ok=True)
    operation.terminal_event_path = None
    quickstart_id_ref = operation.quickstart_id

    async def _deferred_remove() -> None:
        await asyncio.sleep(30)
        _remove_quickstart_op(quickstart_id_ref)

    try:
        asyncio.get_running_loop().create_task(_deferred_remove())
    except RuntimeError:
        _remove_quickstart_op(quickstart_id_ref)


def _build_quickstart_request(project_dir: Path) -> CreateProjectRequest:
    """Construct the fixed sample-project config payload."""
    return CreateProjectRequest(
        name=QUICKSTART_DISPLAY_NAME,
        git_url=QUICKSTART_GIT_URL,
        backend="duckdb",
        duckdb_path=str(project_dir / QUICKSTART_DUCKDB_FILENAME),
        dbt_target=QUICKSTART_DBT_TARGET,
        profile_name=QUICKSTART_PROFILE_NAME,
    )


@router.post("/start", response_model=QuickstartStartResponse)
async def start_quickstart() -> QuickstartStartResponse:
    """Create sample project config and start the onboarding pipeline."""
    ensure_home()
    with _quickstart_lock:
        running = next(
            (op for op in _quickstart_ops.values() if op.status == "running"), None
        )
        if running is not None:
            raise HTTPException(
                status_code=409, detail="Quick Start is already running"
            )

        config = _read_config()
        previous_default_project = config.get("default_project")
        if QUICKSTART_PROJECT_NAME in (config.get("projects") or {}):
            raise HTTPException(
                status_code=409,
                detail="Sample project already exists. Delete it first to run Quick Start again.",
            )

        project_dir = projects_dir() / QUICKSTART_PROJECT_NAME
        profiles_path = profiles_dir() / QUICKSTART_PROJECT_NAME
        if project_dir.exists() or profiles_path.exists():
            raise HTTPException(
                status_code=409,
                detail="Sample project files already exist. Delete them first to run Quick Start again.",
            )

        project_dir.mkdir(parents=True, exist_ok=False)

        try:
            await create_project(_build_quickstart_request(project_dir))
            _set_project_status(QUICKSTART_PROJECT_NAME, "initializing")
        except Exception:
            _delete_quickstart_project(previous_default_project)
            raise

        quickstart_id = str(uuid.uuid4())
        queue: Queue = multiprocessing.Queue(maxsize=256)
        cancel_event = multiprocessing.Event()
        proc = Process(
            target=_quickstart_worker,
            args=(
                QUICKSTART_PROJECT_NAME,
                previous_default_project,
                quickstart_id,
                queue,
                cancel_event,
            ),
            daemon=False,
        )

        op = QuickstartOperation(
            quickstart_id=quickstart_id,
            process=proc,
            queue=queue,
            cancel_event=cancel_event,
            status="running",
            started_at=time.time(),
            previous_default_project=previous_default_project,
            terminal_event_path=_terminal_event_path(quickstart_id),
        )
        _quickstart_ops[quickstart_id] = op

        try:
            proc.start()
        except Exception:
            _quickstart_ops.pop(quickstart_id, None)
            _delete_quickstart_project(previous_default_project)
            raise

        threading.Thread(
            target=_watch_quickstart_process,
            args=(quickstart_id,),
            daemon=True,
        ).start()

    logger.info(
        "[desktop:quickstart] Started quick start %s (pid=%d)",
        quickstart_id,
        proc.pid or 0,
    )
    return QuickstartStartResponse(
        quickstart_id=quickstart_id,
        project_name=QUICKSTART_PROJECT_NAME,
        display_name=QUICKSTART_DISPLAY_NAME,
    )


@router.get("/{quickstart_id}/progress")
async def quickstart_progress(quickstart_id: str):
    """SSE stream for quick start progress."""
    op = _get_quickstart_op(quickstart_id)
    if not op:
        raise HTTPException(
            status_code=404, detail=f"Quick Start '{quickstart_id}' not found"
        )

    def _cleanup_op(operation: QuickstartOperation, *, force: bool) -> None:
        _cleanup_quickstart_op(operation, force=force)

    if (
        op.status in {"completed", "error", "cancelled", "awaiting_input"}
        and op.last_event
    ):
        _cleanup_op(op, force=True)
        last_event = op.last_event

        async def terminal_event():
            yield _sse_event(f"quickstart.{last_event['status']}", last_event)

        return StreamingResponse(terminal_event(), media_type="text/event-stream")

    async def generate():
        last_heartbeat = time.time()
        try:
            while not shutdown_event.is_set():
                if op.status in {"completed", "error", "cancelled", "awaiting_input"}:
                    if op.last_event is not None:
                        yield _sse_event(
                            f"quickstart.{op.last_event['status']}", op.last_event
                        )
                    break

                try:
                    event = await asyncio.get_running_loop().run_in_executor(
                        None,
                        lambda: op.queue.get(timeout=1.0) if op.queue else None,
                    )
                except Exception:
                    event = None

                if event is not None:
                    evt_status = event.get("status", "running")
                    is_terminal = evt_status in (
                        "error",
                        "cancelled",
                        "awaiting_input",
                    ) or (evt_status == "completed" and event.get("terminal") is True)
                    yield _sse_event(f"quickstart.{evt_status}", event)
                    if is_terminal:
                        op.status = evt_status
                        op.last_event = event
                        if evt_status == "error":
                            op.error = str(event.get("message") or "Quick Start failed")
                        break

                now = time.time()
                if now - last_heartbeat > 15:
                    yield _sse_event("heartbeat", {"timestamp": int(now * 1000)})
                    last_heartbeat = now

                if op.process and not op.process.is_alive() and op.status == "running":
                    exit_code = op.process.exitcode
                    op.status = "error"
                    op.error = (
                        f"Quick Start process exited unexpectedly (code {exit_code})"
                    )
                    yield _sse_event(
                        "quickstart.error",
                        {
                            **_stage_event("clone", "error", op.error),
                            "status": "error",
                        },
                    )
                    break
        finally:
            force_cleanup = op.status in (
                "completed",
                "error",
                "cancelled",
                "awaiting_input",
            ) or bool(op.process and not op.process.is_alive())
            _cleanup_op(op, force=force_cleanup)

    return StreamingResponse(generate(), media_type="text/event-stream")


@router.post("/{quickstart_id}/cancel")
async def cancel_quickstart(quickstart_id: str):
    """Cancel a running quick start operation."""
    op = _get_quickstart_op(quickstart_id)
    if not op:
        raise HTTPException(
            status_code=404, detail=f"Quick Start '{quickstart_id}' not found"
        )

    if op.status != "running":
        return {
            "message": f"Quick Start '{quickstart_id}' is not running (status: {op.status})"
        }

    if op.cancel_event:
        op.cancel_event.set()

    op.status = "cancelled"
    op.last_event = {
        **_stage_event(
            "clone",
            "cancelled",
            "Quick Start cancelled by user",
            terminal=True,
        ),
        "status": "cancelled",
    }
    if op.terminal_event_path is not None:
        _persist_terminal_event(op.terminal_event_path, op.last_event)
    _delete_quickstart_project(op.previous_default_project)
    _cleanup_quickstart_op(op, force=True)
    return {"message": f"Cancelled Quick Start '{quickstart_id}'"}
