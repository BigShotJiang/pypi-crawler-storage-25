"""Helpers for request-scoped desktop project/worktree context."""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from pathlib import Path

from core.backends.config import DataConfig, UnifiedConfig
from core.backends.unified_graph.surreal.load import connect as connect_surreal
from core.backends.unified_graph.surreal.reader import SurrealUnifiedGraphReader
from core.paths import default_surreal_url
from fastapi import HTTPException, Request

DESKTOP_WORKTREE_ID_HEADER = "X-TypeDef-Worktree-Id"
DESKTOP_WORKTREE_PATH_HEADER = "X-TypeDef-Worktree-Path"

_WORKTREE_ID_RE = re.compile(r"^[a-zA-Z0-9_-]+$")


@dataclass(frozen=True)
class DesktopRequestContext:
    """Resolved desktop project/worktree context for a request."""

    config: UnifiedConfig | None
    project_name: str | None
    worktree_id: str | None
    worktree_path: str | None
    graph_name: str | None
    data_config: DataConfig | None


def _get_unified_config(request: Request) -> UnifiedConfig | None:
    state = getattr(request.app.state, "app_state", None)
    if state is not None and getattr(state, "config", None) is not None:
        return state.config
    return getattr(request.app.state, "unified_config", None)


def _get_active_project_name(config: UnifiedConfig | None) -> str | None:
    if config is None:
        return None
    return os.getenv("TYPEDEF_ACTIVE_PROJECT") or config.default_project


def _get_worktree_id(request: Request) -> str | None:
    value = request.headers.get(DESKTOP_WORKTREE_ID_HEADER)
    if not value:
        return None
    if not _WORKTREE_ID_RE.fullmatch(value):
        raise HTTPException(status_code=400, detail="Invalid worktree id header")
    return value


def _get_worktree_path(request: Request) -> str | None:
    value = request.headers.get(DESKTOP_WORKTREE_PATH_HEADER)
    if not value:
        return None
    path = Path(value)
    if not path.is_absolute() or ".." in path.parts:
        raise HTTPException(status_code=400, detail="Invalid worktree path header")
    return str(path)


def resolve_desktop_request_context(request: Request) -> DesktopRequestContext:
    """Resolve project/worktree identifiers and effective config for a request.

    Graph name and data config are always resolved at the **project** level
    (``worktree_id=None``).  The catalog and sync pipeline operate on a single
    shared project graph regardless of which worktree the desktop UI is
    currently viewing.  Worktree-scoped graphs are reserved for future work.

    The worktree headers are still parsed and stored on the context so that
    other subsystems (terminal sessions, file operations) can use them.
    """
    config = _get_unified_config(request)
    project_name = _get_active_project_name(config)
    worktree_id = _get_worktree_id(request)
    worktree_path = _get_worktree_path(request)

    graph_name = None
    data_config = None
    if config is not None and project_name is not None:
        # Always resolve at the project level — ignore worktree overrides
        graph_name = config.get_project_graph_name(
            project_name, worktree_id=None
        )
        try:
            data_config = config.get_project_data_config(
                project_name,
                worktree_id=None,
            )
        except ValueError:
            data_config = None

    return DesktopRequestContext(
        config=config,
        project_name=project_name,
        worktree_id=worktree_id,
        worktree_path=worktree_path,
        graph_name=graph_name,
        data_config=data_config,
    )


def create_request_scoped_unified_reader(request: Request) -> SurrealUnifiedGraphReader:
    """Create a unified reader scoped to the request's project graph."""
    context = resolve_desktop_request_context(request)
    graph_name = context.graph_name or os.environ.get("SURREAL_DB", "unified")

    cache = getattr(request.app.state, "desktop_reader_cache", None)
    if not isinstance(cache, dict):
        cache = {}
        request.app.state.desktop_reader_cache = cache

    cached = cache.get(graph_name)
    if isinstance(cached, SurrealUnifiedGraphReader):
        return cached

    db = connect_surreal(
        url=os.environ.get("SURREAL_URL", default_surreal_url()),
        namespace=os.environ.get("SURREAL_NS", "lineage"),
        database=graph_name,
        username=os.environ.get("SURREAL_USER", ""),
        password=os.environ.get("SURREAL_PASSWORD", ""),
    )
    reader = SurrealUnifiedGraphReader(db)
    cache[graph_name] = reader
    return reader
