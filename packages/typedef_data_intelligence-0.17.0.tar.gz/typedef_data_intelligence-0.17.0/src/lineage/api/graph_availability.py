"""Concrete GraphAvailability backed by SurrealDB + desktop sync state."""

from __future__ import annotations

import logging
import time
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import TimeoutError as FuturesTimeoutError
from typing import Callable

from core.backends.unified_graph.availability import GraphStatus
from core.backends.unified_graph.surreal.reader import SurrealUnifiedGraphReader

logger = logging.getLogger(__name__)

_probe_pool = ThreadPoolExecutor(max_workers=2, thread_name_prefix="graph-probe")


class SurrealGraphAvailability:
    """Check graph availability by probing the reader and sync state.

    Maintains a cached ``GraphStatus`` that is refreshed at most every
    ``probe_interval`` seconds.  The probe runs in a thread pool with a
    ``probe_timeout`` so callers are never blocked by a hanging SurrealDB
    connection.

    Parameters
    ----------
    reader_factory:
        Callable that returns a ``SurrealUnifiedGraphReader`` or raises.
    sync_ops_ref:
        Callable returning the current ``_sync_ops`` dict from desktop_sync.
    project_name:
        Active project name for filtering sync operations.
    probe_interval:
        Seconds between SurrealDB probes.
    probe_timeout:
        Max seconds a single probe may take before being treated as unreachable.
    """

    def __init__(  # noqa: D107
        self,
        reader_factory: Callable[[], SurrealUnifiedGraphReader | None],
        sync_ops_ref: Callable[[], dict],
        project_name: str | None = None,
        probe_interval: float = 5.0,
        probe_timeout: float = 3.0,
    ) -> None:
        self._reader_factory = reader_factory
        self._sync_ops_ref = sync_ops_ref
        self._project_name = project_name
        self._probe_interval = probe_interval
        self._probe_timeout = probe_timeout
        self._cached_status: GraphStatus | None = None
        self._last_probe: float = 0.0

    def check(self) -> GraphStatus:  # noqa: D102
        now = time.monotonic()
        cache_stale = (now - self._last_probe) >= self._probe_interval

        if self._cached_status is not None and not cache_stale:
            # Cache is fresh — still refresh sync state (cheap, no I/O)
            sync_status, sync_error = self._derive_sync_state()
            if (
                sync_status != self._cached_status.sync_status
                or sync_error != self._cached_status.sync_error
            ):
                self._cached_status = GraphStatus(
                    reader=self._cached_status.reader,
                    db_reachable=self._cached_status.db_reachable,
                    has_data=self._cached_status.has_data,
                    sync_status=sync_status,
                    sync_error=sync_error,
                    enrichment_status=self._cached_status.enrichment_status,
                    ingest_version=self._cached_status.ingest_version,
                )
            return self._cached_status

        # Cache is stale or first call — run probe with timeout
        return self._probe()

    def _probe(self) -> GraphStatus:
        """Run the actual SurrealDB probe with a timeout."""
        try:
            future = _probe_pool.submit(self._do_probe)
            result = future.result(timeout=self._probe_timeout)
            self._cached_status = result
            self._last_probe = time.monotonic()
            return result
        except FuturesTimeoutError:
            future.cancel()  # best-effort: prevents queued tasks from starting
            logger.warning(
                "Graph availability probe timed out after %.1fs",
                self._probe_timeout,
            )
        except Exception:
            logger.debug("Graph availability probe failed", exc_info=True)

        # Probe failed or timed out — return synthetic "unreachable" status
        sync_status, sync_error = self._derive_sync_state()
        status = GraphStatus(
            reader=None,
            db_reachable=False,
            has_data=False,
            sync_status=sync_status,
            sync_error=sync_error,
        )
        self._cached_status = status
        self._last_probe = time.monotonic()
        return status

    def _do_probe(self) -> GraphStatus:
        """Probe SurrealDB reachability and sentinel. Runs in thread pool."""
        reader: SurrealUnifiedGraphReader | None = None
        db_reachable = False
        try:
            reader = self._reader_factory()
            db_reachable = reader is not None
        except Exception:
            logger.debug("SurrealDB not reachable", exc_info=True)

        has_data = False
        partial_sync_died = False
        enrichment_status: str | None = None
        ingest_version: str | None = None
        if reader is not None:
            try:
                sentinel = reader.check_load_sentinel()
                has_data = sentinel is not None
                if sentinel is not None:
                    enrichment_status = sentinel.get("enrichment_status")
                    ingest_version = sentinel.get("ingest_version")
            except Exception:
                logger.debug("Failed to check load sentinel", exc_info=True)

            # Detect crashed sync: _meta exists with load_type="in_progress"
            # but check_load_sentinel() returned None (rejects in_progress)
            if not has_data:
                try:
                    raw = reader._get_db().query("SELECT load_type FROM _meta LIMIT 1;")
                    if raw and isinstance(raw, list) and isinstance(raw[0], dict):
                        if raw[0].get("load_type") == "in_progress":
                            partial_sync_died = True
                except Exception:
                    logger.debug("Failed to detect crashed sync marker", exc_info=True)

        sync_status, sync_error = self._derive_sync_state()

        # Override sync state if we detected a crashed sync
        if partial_sync_died and sync_status == "never_synced":
            sync_status = "error"
            sync_error = "Previous sync was interrupted"

        return GraphStatus(
            reader=reader,
            db_reachable=db_reachable,
            has_data=has_data,
            sync_status=sync_status,
            sync_error=sync_error,
            enrichment_status=enrichment_status,
            ingest_version=ingest_version,
        )

    def _derive_sync_state(self) -> tuple[str, str | None]:
        """Derive sync_status and sync_error from the sync ops registry."""
        ops = self._sync_ops_ref()
        if not ops:
            return ("never_synced", None)

        # Filter to this project if we have a project name
        relevant = [
            op
            for op in ops.values()
            if self._project_name is None or op.project_name == self._project_name
        ]
        if not relevant:
            return ("never_synced", None)

        # Sort by started_at descending to get the most recent
        relevant.sort(key=lambda op: op.started_at, reverse=True)
        latest = relevant[0]

        if latest.status == "running":
            return ("running", None)
        if latest.status == "error":
            return ("error", latest.error)
        if latest.status in ("complete", "completed"):
            return ("complete", None)
        if latest.status == "cancelled":
            # Treat cancelled like idle — not an error
            return ("idle", None)

        return ("idle", None)
