"""Desktop project management routes.

CRUD for projects: list, update, delete (with two-phase safety).
"""

from __future__ import annotations

import logging
import os
import shutil
from pathlib import Path
from typing import Literal

from core.paths import config_path, env_path, profiles_dir, projects_dir
from fastapi import APIRouter, HTTPException, Request
from ingest.static_loaders.salesforce.factory import SfAuthMode
from pydantic import BaseModel, ValidationError

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/desktop/projects", tags=["desktop-projects"])

BackendType = Literal["snowflake", "duckdb"]


# ── Models ────────────────────────────────────────────────────────────


class IntegrationSummary(BaseModel):
    """Current integration state for a project."""

    salesforce_enabled: bool = False
    salesforce_client_id: str | None = None
    salesforce_login_url: str | None = None
    salesforce_auth_type: SfAuthMode | None = None
    salesforce_instance_url: str | None = None
    salesforce_username: str | None = None
    cube_enabled: bool = False
    cube_project_dir: str | None = None
    lookml_enabled: bool = False
    lookml_project_dir: str | None = None
    fivetran_enabled: bool = False
    fivetran_connector_ids: list[str] | None = None
    linear_enabled: bool = False
    linear_team_id: str | None = None
    profiling_enabled: bool = True


class ProjectSummary(BaseModel):
    """Summary of a single configured project."""

    name: str
    backend: str | None = None
    dbt_path: str | None = None
    clone_path: str | None = None
    graph_name: str | None = None
    status: str = "ready"  # ready | initializing | deleting
    integrations: IntegrationSummary = IntegrationSummary()


class ProjectListResponse(BaseModel):
    """Response containing all configured projects."""

    projects: list[ProjectSummary]
    default_project: str | None = None


class UpdateProjectRequest(BaseModel):
    """Partial update — only provided fields are changed.

    In Tauri mode, secret fields go to the OS keychain and never reach this
    endpoint. In browser-only dev mode, secrets still arrive here and are
    written to .env as a fallback.
    """

    backend_type: BackendType | None = None
    snowflake_account: str | None = None
    snowflake_user: str | None = None
    snowflake_private_key_path: str | None = None
    snowflake_warehouse: str | None = None
    snowflake_role: str | None = None
    snowflake_database: str | None = None
    snowflake_schema: str | None = None
    allowed_databases: list[str] | None = None
    dbt_target: str | None = None
    profile_name: str | None = None
    duckdb_path: str | None = None
    env_vars: str | None = None
    sub_project: str | None = None
    # Secret fields — used by browser-only dev mode (.env fallback)
    anthropic_api_key: str | None = None
    openai_api_key: str | None = None
    logfire_api_key: str | None = None
    # Integrations (explicit booleans so we can distinguish "not sent" from "disable")
    salesforce_enabled: bool | None = None
    salesforce_client_id: str | None = None
    salesforce_login_url: str | None = None
    salesforce_auth_type: SfAuthMode | None = None
    salesforce_instance_url: str | None = None
    salesforce_username: str | None = None
    # Salesforce secret fields — browser-only dev mode (.env fallback)
    sf_password: str | None = None
    sf_security_token: str | None = None
    sf_client_secret: str | None = None
    cube_enabled: bool | None = None
    cube_project_dir: str | None = None
    lookml_enabled: bool | None = None
    lookml_project_dir: str | None = None
    fivetran_enabled: bool | None = None
    fivetran_connector_ids: list[str] | None = None
    fivetran_api_key: str | None = None
    fivetran_api_secret: str | None = None
    linear_enabled: bool | None = None
    linear_team_id: str | None = None
    linear_analyst_api_key: str | None = None
    linear_data_engineer_api_key: str | None = None
    profiling_enabled: bool | None = None


class ProjectDetail(BaseModel):
    """Detailed project-specific config for the Configure Project flow."""

    name: str
    clone_path: str
    dbt_path: str
    backend_type: BackendType
    dbt_target: str | None = None
    profile_name: str | None = None
    snowflake_account: str | None = None
    snowflake_user: str | None = None
    snowflake_private_key_path: str | None = None
    snowflake_warehouse: str | None = None
    snowflake_role: str | None = None
    snowflake_database: str | None = None
    snowflake_schema: str | None = None
    allowed_databases: list[str] = []
    duckdb_path: str | None = None
    env_vars: str = ""
    profiling_enabled: bool = True
    subprojects: list[str] = []
    selected_subproject: str = ""
    subproject_warning: str | None = None


# ── Helpers ───────────────────────────────────────────────────────────


def _read_config() -> dict:
    """Read config.yaml and return as dict. Returns empty dict if not found."""
    import yaml

    path = config_path()
    if not path.exists():
        return {}
    return yaml.safe_load(path.read_text()) or {}


def _write_config(data: dict) -> None:
    """Write config.yaml atomically."""
    import yaml

    path = config_path()
    tmp = path.with_suffix(".yaml.tmp")
    tmp.write_text(yaml.dump(data, default_flow_style=False, sort_keys=False))
    os.replace(str(tmp), str(path))


_RESERVED_PROJECT_ENV_KEYS = {"SNOWFLAKE_PRIVATE_KEY_PATH", "DUCKDB_PATH"}


def _custom_project_env(project: dict) -> dict[str, str]:
    raw_env = project.get("env")
    if not isinstance(raw_env, dict):
        return {}
    return {
        str(key): str(value)
        for key, value in raw_env.items()
        if key not in _RESERVED_PROJECT_ENV_KEYS and value is not None and str(value)
    }


def _serialize_env_vars(entries: dict[str, str]) -> str:
    if not entries:
        return ""
    return ", ".join(f"{key}={value}" for key, value in sorted(entries.items()))


def _parse_env_vars(raw: str | None) -> dict[str, str]:
    if not raw:
        return {}
    parsed: dict[str, str] = {}
    for pair in raw.split(","):
        pair = pair.strip()
        if not pair or "=" not in pair:
            continue
        key, value = pair.split("=", 1)
        key = key.strip()
        value = value.strip()
        if key and key not in _RESERVED_PROJECT_ENV_KEYS:
            parsed[key] = value
    return parsed


def _backend_type(value: object) -> BackendType | None:
    if value == "snowflake":
        return "snowflake"
    if value in {None, "", "duckdb"}:
        return "duckdb"
    return None


def _coerce_mapping(value: object) -> dict:
    return dict(value) if isinstance(value, dict) else {}


def _coerce_string_list(value: object) -> list[str]:
    if isinstance(value, list) and all(isinstance(item, str) for item in value):
        return list(value)
    return []


def _build_project_env(project: dict) -> dict[str, str]:
    data = _coerce_mapping(project.get("data"))
    env_entries: dict[str, str] = {}

    if data.get("backend") == "snowflake" and data.get("private_key_path"):
        env_entries["SNOWFLAKE_PRIVATE_KEY_PATH"] = str(data["private_key_path"])
    if data.get("backend") == "duckdb" and data.get("db_path"):
        env_entries["DUCKDB_PATH"] = str(data["db_path"])

    env_entries.update(_custom_project_env(project))
    return {key: value for key, value in env_entries.items() if value}


def _resolve_subproject_path(project_name: str, sub_project: str | None) -> Path:
    project_root = (projects_dir() / project_name).resolve()
    if not sub_project or sub_project in {".", "./"}:
        resolved = project_root
    else:
        sub = Path(sub_project)
        if sub.is_absolute() or ".." in sub.parts:
            raise HTTPException(status_code=400, detail="Invalid subproject path")

        resolved = (project_root / sub).resolve()
        if not resolved.is_relative_to(project_root):
            raise HTTPException(status_code=400, detail="Invalid subproject path")

    if not resolved.exists():
        raise HTTPException(status_code=400, detail="Subproject path does not exist")
    if not (resolved / "dbt_project.yml").exists():
        raise HTTPException(
            status_code=400,
            detail="Selected subproject must contain dbt_project.yml",
        )

    return resolved


def _detect_subprojects(
    project_name: str, dbt_path: str
) -> tuple[list[str], str, str | None]:
    project_root = (projects_dir() / project_name).resolve()
    selected = ""
    warning: str | None = None
    subprojects: list[str] = []

    try:
        dbt_root = Path(dbt_path).resolve()
        if dbt_root.is_relative_to(project_root):
            rel = dbt_root.relative_to(project_root)
            selected = str(rel) if str(rel) != "." else "."

        if project_root.exists():
            dbt_files = list(project_root.rglob("dbt_project.yml"))
            values = {
                str(file.parent.relative_to(project_root)) or "." for file in dbt_files
            }
            subprojects = sorted(values, key=lambda value: (value != ".", value))
    except Exception:
        logger.warning(
            "Could not inspect dbt subprojects for project %s",
            project_name,
            exc_info=True,
        )
        warning = (
            "Could not inspect dbt subprojects. Check the project path and permissions."
        )

    return subprojects, selected, warning


def _rewrite_profiles_yml(project_name: str, project: dict) -> None:
    from lineage.api.desktop_setup import CreateProjectRequest, _build_profiles_yml

    data = _coerce_mapping(project.get("data"))
    backend = _backend_type(data.get("backend"))
    if backend is None:
        logger.warning(
            "Skipping profiles.yml rewrite for project %s due to unsupported backend %r",
            project_name,
            data.get("backend"),
        )
        return
    req = CreateProjectRequest(
        name=project_name,
        git_url="",
        backend=backend,
        snowflake_account=data.get("account"),
        snowflake_user=data.get("user"),
        snowflake_private_key_path=data.get("private_key_path"),
        snowflake_warehouse=data.get("warehouse"),
        snowflake_role=data.get("role"),
        snowflake_database=data.get("database"),
        snowflake_schema=data.get("schema_name"),
        allowed_databases=data.get("allowed_databases"),
        dbt_target=project.get("dbt_target"),
        profile_name=project.get("profile_name"),
        duckdb_path=data.get("db_path"),
        env_vars=_serialize_env_vars(_custom_project_env(project)),
        profiling_enabled=bool(
            (project.get("profiling") or {}).get("enabled", True)
            if isinstance(project.get("profiling"), dict)
            else True
        ),
    )

    profile_name = str(project.get("profile_name") or project_name)
    path_value = project.get("profiles_dir")
    profiles_path = (
        Path(str(path_value)).expanduser()
        if path_value
        else profiles_dir() / project_name
    )
    profiles_path.mkdir(parents=True, exist_ok=True)
    (profiles_path / "profiles.yml").write_text(_build_profiles_yml(req, profile_name))


# ── Endpoints ─────────────────────────────────────────────────────────


@router.get("/", response_model=ProjectListResponse)
async def list_projects():
    """List all configured projects."""
    config = _read_config()
    projects_map = config.get("projects", {})
    default = config.get("default_project")

    summaries = []
    for name, proj in projects_map.items():
        data = proj.get("data", {}) if isinstance(proj, dict) else {}
        sf = proj.get("salesforce", {}) if isinstance(proj, dict) else {}
        cube = proj.get("cube", {}) if isinstance(proj, dict) else {}
        lookml = proj.get("lookml", {}) if isinstance(proj, dict) else {}
        ft = proj.get("fivetran", {}) if isinstance(proj, dict) else {}
        ticket = proj.get("ticket", {}) if isinstance(proj, dict) else {}
        _raw_prof = proj.get("profiling") if isinstance(proj, dict) else None
        profiling = _raw_prof if isinstance(_raw_prof, dict) else {}
        linear_enabled = (
            bool(ticket.get("enabled")) and ticket.get("backend") == "linear"
        )
        ft_ids = (
            ft.get("connector_ids")
            if isinstance(ft.get("connector_ids"), list)
            else None
        )
        summaries.append(
            ProjectSummary(
                name=name,
                backend=data.get("backend"),
                dbt_path=proj.get("dbt_path") if isinstance(proj, dict) else None,
                clone_path=str(projects_dir() / name),
                graph_name=proj.get("graph_name") if isinstance(proj, dict) else None,
                status=proj.get("status", "ready")
                if isinstance(proj, dict)
                else "ready",
                integrations=IntegrationSummary(
                    salesforce_enabled=bool(sf.get("enabled")),
                    salesforce_client_id=sf.get("client_id"),
                    salesforce_login_url=sf.get("login_url"),
                    salesforce_auth_type=sf.get("auth_type"),
                    salesforce_instance_url=sf.get("instance_url"),
                    salesforce_username=sf.get("username"),
                    cube_enabled=bool(cube.get("enabled")),
                    cube_project_dir=cube.get("project_dir"),
                    lookml_enabled=bool(lookml.get("enabled")),
                    lookml_project_dir=lookml.get("project_dir"),
                    fivetran_enabled=bool(ft.get("enabled")),
                    fivetran_connector_ids=ft_ids,
                    linear_enabled=linear_enabled,
                    linear_team_id=ticket.get("team_id") if linear_enabled else None,
                    profiling_enabled=bool(profiling.get("enabled", True)),
                ),
            )
        )

    return ProjectListResponse(projects=summaries, default_project=default)


@router.get("/{name}", response_model=ProjectDetail)
async def get_project(name: str):
    """Return detailed project-specific config for the Configure Project flow."""
    config = _read_config()
    projects_map = config.get("projects", {})
    if name not in projects_map:
        raise HTTPException(status_code=404, detail=f"Project '{name}' not found")

    project = projects_map[name]
    data = _coerce_mapping(project.get("data"))
    profiling = (
        project.get("profiling") if isinstance(project.get("profiling"), dict) else {}
    )
    dbt_path = str(project.get("dbt_path") or projects_dir() / name)
    subprojects, selected_subproject, warning = _detect_subprojects(name, dbt_path)
    backend_type = _backend_type(data.get("backend"))
    if backend_type is None:
        logger.warning(
            "Project %s has unsupported backend %r in persisted config",
            name,
            data.get("backend"),
        )
        raise HTTPException(
            status_code=500,
            detail="Project config contains unsupported backend value",
        )

    return ProjectDetail(
        name=name,
        clone_path=str(projects_dir() / name),
        dbt_path=dbt_path,
        backend_type=backend_type,
        dbt_target=project.get("dbt_target"),
        profile_name=project.get("profile_name"),
        snowflake_account=data.get("account"),
        snowflake_user=data.get("user"),
        snowflake_private_key_path=data.get("private_key_path"),
        snowflake_warehouse=data.get("warehouse"),
        snowflake_role=data.get("role"),
        snowflake_database=data.get("database"),
        snowflake_schema=data.get("schema_name"),
        allowed_databases=_coerce_string_list(data.get("allowed_databases")),
        duckdb_path=data.get("db_path"),
        env_vars=_serialize_env_vars(_custom_project_env(project)),
        profiling_enabled=bool(profiling.get("enabled", True)),
        subprojects=subprojects,
        selected_subproject=selected_subproject,
        subproject_warning=warning,
    )


@router.patch("/{name}")
async def update_project(name: str, req: UpdateProjectRequest):
    """Update project credentials/settings without destroying the graph."""
    config = _read_config()
    projects_map = config.get("projects", {})

    if name not in projects_map:
        raise HTTPException(status_code=404, detail=f"Project '{name}' not found")

    # In Tauri mode, secrets go to OS keychain and never reach here.
    # In browser-only dev mode, secrets still arrive via this endpoint
    # and are written to .env as a fallback.
    fields = req.model_fields_set

    env_updates: dict[str, str] = {}
    if (
        "snowflake_private_key_path" in fields
        and req.snowflake_private_key_path is not None
    ):
        env_updates["SNOWFLAKE_PRIVATE_KEY_PATH"] = req.snowflake_private_key_path
    if "anthropic_api_key" in fields and req.anthropic_api_key is not None:
        env_updates["ANTHROPIC_API_KEY"] = req.anthropic_api_key
    if "openai_api_key" in fields and req.openai_api_key is not None:
        env_updates["OPENAI_API_KEY"] = req.openai_api_key
    if "logfire_api_key" in fields and req.logfire_api_key is not None:
        env_updates["LOGFIRE_TOKEN"] = req.logfire_api_key
    if "fivetran_api_key" in fields and req.fivetran_api_key is not None:
        env_updates["FIVETRAN_API_KEY"] = req.fivetran_api_key
    if "fivetran_api_secret" in fields and req.fivetran_api_secret is not None:
        env_updates["FIVETRAN_API_SECRET"] = req.fivetran_api_secret
    if "linear_analyst_api_key" in fields and req.linear_analyst_api_key is not None:
        env_updates["LINEAR_ANALYST_API_KEY"] = req.linear_analyst_api_key
    if "sf_password" in fields and req.sf_password is not None:
        env_updates["SF_PASSWORD"] = req.sf_password
    if "sf_security_token" in fields and req.sf_security_token is not None:
        env_updates["SF_SECURITY_TOKEN"] = req.sf_security_token
    if "sf_client_secret" in fields and req.sf_client_secret is not None:
        env_updates["SF_CLIENT_SECRET"] = req.sf_client_secret
    if (
        "linear_data_engineer_api_key" in fields
        and req.linear_data_engineer_api_key is not None
    ):
        env_updates["LINEAR_DATA_ENGINEER_API_KEY"] = req.linear_data_engineer_api_key

    if env_updates:
        existing: dict[str, str] = {}
        ep = env_path()
        if ep.exists():
            for line in ep.read_text().splitlines():
                if "=" in line and not line.startswith("#"):
                    k, v = line.split("=", 1)
                    existing[k.strip()] = v.strip()
        existing.update(env_updates)

        from lineage.api.desktop_setup import _write_env_file

        _write_env_file(ep, existing)

    # Update config fields
    proj = projects_map[name]
    data = _coerce_mapping(proj.get("data"))
    if "backend_type" in fields and req.backend_type is not None:
        data["backend"] = req.backend_type
    if "snowflake_account" in fields:
        if req.snowflake_account is None:
            data.pop("account", None)
        else:
            data["account"] = req.snowflake_account
    if "snowflake_user" in fields:
        if req.snowflake_user is None:
            data.pop("user", None)
        else:
            data["user"] = req.snowflake_user
    if "snowflake_private_key_path" in fields:
        if req.snowflake_private_key_path is None:
            data.pop("private_key_path", None)
        else:
            data["private_key_path"] = req.snowflake_private_key_path
    if "snowflake_warehouse" in fields:
        if req.snowflake_warehouse is None:
            data.pop("warehouse", None)
        else:
            data["warehouse"] = req.snowflake_warehouse
    if "snowflake_role" in fields:
        if req.snowflake_role is None:
            data.pop("role", None)
        else:
            data["role"] = req.snowflake_role
    if "snowflake_database" in fields:
        if req.snowflake_database is None:
            data.pop("database", None)
        else:
            data["database"] = req.snowflake_database
    if "snowflake_schema" in fields:
        if req.snowflake_schema is None:
            data.pop("schema_name", None)
        else:
            data["schema_name"] = req.snowflake_schema
    if "allowed_databases" in fields:
        if req.allowed_databases:
            data["allowed_databases"] = req.allowed_databases
        else:
            data.pop("allowed_databases", None)
    if "duckdb_path" in fields:
        if req.duckdb_path is None:
            data.pop("db_path", None)
        else:
            data["db_path"] = req.duckdb_path

    backend_type = data.get("backend")
    if backend_type == "duckdb":
        for key in [
            "account",
            "user",
            "private_key_path",
            "warehouse",
            "role",
            "database",
            "schema_name",
            "allowed_databases",
        ]:
            data.pop(key, None)
    elif backend_type == "snowflake":
        data.pop("db_path", None)

    proj["data"] = data

    if "dbt_target" in fields:
        if req.dbt_target is None:
            proj.pop("dbt_target", None)
        else:
            proj["dbt_target"] = req.dbt_target

    if "profile_name" in fields:
        if req.profile_name is None:
            proj.pop("profile_name", None)
        else:
            proj["profile_name"] = req.profile_name

    if "sub_project" in fields:
        proj["dbt_path"] = str(_resolve_subproject_path(name, req.sub_project))

    if any(
        field in fields
        for field in {
            "env_vars",
            "duckdb_path",
            "snowflake_private_key_path",
            "backend_type",
        }
    ):
        custom_env = (
            _parse_env_vars(req.env_vars)
            if "env_vars" in fields
            else _custom_project_env(proj)
        )
        reserved_env = {}
        if data.get("backend") == "snowflake" and data.get("private_key_path"):
            reserved_env["SNOWFLAKE_PRIVATE_KEY_PATH"] = str(data["private_key_path"])
        if data.get("backend") == "duckdb" and data.get("db_path"):
            reserved_env["DUCKDB_PATH"] = str(data["db_path"])
        env_map = {**reserved_env, **custom_env}
        if env_map:
            proj["env"] = env_map
        else:
            proj.pop("env", None)

    # Update integrations
    if req.salesforce_enabled is not None:
        if req.salesforce_enabled:
            sf = proj.get("salesforce", {})
            sf["enabled"] = True
            if req.salesforce_client_id is not None:
                sf["client_id"] = req.salesforce_client_id
            if req.salesforce_login_url is not None:
                sf["login_url"] = req.salesforce_login_url
            if req.salesforce_auth_type is not None:
                sf["auth_type"] = str(req.salesforce_auth_type)
            if req.salesforce_instance_url is not None:
                sf["instance_url"] = req.salesforce_instance_url
            if req.salesforce_username is not None:
                sf["username"] = req.salesforce_username
            proj["salesforce"] = sf
        else:
            proj.pop("salesforce", None)

    if req.cube_enabled is not None:
        if req.cube_enabled:
            cube = proj.get("cube", {})
            cube["enabled"] = True
            if req.cube_project_dir is not None:
                cube["project_dir"] = req.cube_project_dir
            proj["cube"] = cube
        else:
            proj.pop("cube", None)

    if req.lookml_enabled is not None:
        if req.lookml_enabled:
            lookml = proj.get("lookml", {})
            lookml["enabled"] = True
            if req.lookml_project_dir is not None:
                lookml["project_dir"] = req.lookml_project_dir
            proj["lookml"] = lookml
        else:
            proj.pop("lookml", None)

    if req.fivetran_enabled is not None:
        if req.fivetran_enabled:
            ft = proj.get("fivetran", {})
            ft["enabled"] = True
            if req.fivetran_connector_ids is not None:
                ft["connector_ids"] = req.fivetran_connector_ids
            proj["fivetran"] = ft
        else:
            proj.pop("fivetran", None)

    if req.linear_enabled is not None:
        if req.linear_enabled:
            ticket = proj.get("ticket", {})
            ticket["enabled"] = True
            ticket["backend"] = "linear"
            if req.linear_team_id is not None:
                ticket["team_id"] = req.linear_team_id
            proj["ticket"] = ticket
        else:
            proj.pop("ticket", None)

    if req.profiling_enabled is not None:
        _raw = proj.get("profiling")
        profiling = _raw if isinstance(_raw, dict) else {}
        profiling["enabled"] = req.profiling_enabled
        proj["profiling"] = profiling

    _rewrite_profiles_yml(name, proj)
    _write_config(config)
    return {"message": f"Project '{name}' updated"}


@router.delete("/{name}")
async def delete_project(name: str):
    """Delete a project with two-phase safety.

    Phase 1: Mark status as 'deleting' in config.
    Phase 2: Remove filesystem artifacts + SurrealDB database.
    Phase 3: Remove config entry.

    If the process crashes between phases, the next startup detects
    'deleting' entries and resumes cleanup.
    """
    import re

    config = _read_config()
    projects_map = config.get("projects", {})

    # Validate name to prevent path traversal
    if not re.fullmatch(r"[a-z0-9_]+", name):
        raise HTTPException(status_code=400, detail="Invalid project name")

    if name not in projects_map:
        raise HTTPException(status_code=404, detail=f"Project '{name}' not found")

    # Phase 1: Mark as deleting
    projects_map[name]["status"] = "deleting"
    _write_config(config)
    logger.info("[desktop:projects] Marked project '%s' as deleting", name)

    # Phase 2: Remove filesystem artifacts
    errors: list[str] = []

    # Drop SurrealDB database (best-effort)
    graph_name = projects_map[name].get("graph_name", name)
    # Validate graph_name to prevent SurrealQL injection
    if not re.fullmatch(r"[a-z0-9_]+", graph_name):
        errors.append(f"Invalid graph name: {graph_name}")
        graph_name = None
    if graph_name:
        try:
            from core.backends.unified_graph.surreal.load import connect as _connect
            from core.paths import default_surreal_url

            db = _connect(
                url=os.environ.get("SURREAL_URL", default_surreal_url()),
                namespace=os.environ.get("SURREAL_NS", "lineage"),
                database="unified",  # connect to any db to issue REMOVE
                username=os.environ.get("SURREAL_USER", ""),
                password=os.environ.get("SURREAL_PASSWORD", ""),
            )
            db.query(f"REMOVE DATABASE IF EXISTS `{graph_name}`;")
            logger.info("[desktop:projects] Dropped SurrealDB database: %s", graph_name)
        except Exception as exc:
            errors.append(f"SurrealDB drop failed: {exc}")
            logger.warning(
                "[desktop:projects] Failed to drop database '%s': %s", graph_name, exc
            )

    # Remove project directory
    project_dir = projects_dir() / name
    if project_dir.exists():
        try:
            shutil.rmtree(project_dir)
        except Exception as exc:
            errors.append(f"Project dir removal failed: {exc}")

    # Remove profiles
    profile_dir = profiles_dir() / name
    if profile_dir.exists():
        try:
            shutil.rmtree(profile_dir)
        except Exception as exc:
            errors.append(f"Profiles removal failed: {exc}")

    # Phase 3: Remove config entry
    del projects_map[name]
    if config.get("default_project") == name:
        # Switch default to first remaining project, or None
        remaining = list(projects_map.keys())
        config["default_project"] = remaining[0] if remaining else None
    _write_config(config)

    logger.info("[desktop:projects] Deleted project '%s'", name)

    if errors:
        return {
            "message": f"Project '{name}' deleted with warnings",
            "warnings": errors,
        }
    return {"message": f"Project '{name}' deleted"}


@router.post("/switch/{name}")
async def switch_project(name: str, request: Request):
    """Switch the active project by updating the config default; returns restart_required so the frontend can restart the backend."""
    config = _read_config()
    projects_map = config.get("projects", {})

    if name not in projects_map:
        raise HTTPException(status_code=404, detail=f"Project '{name}' not found")

    proj = projects_map[name]

    # Update default_project in config
    config["default_project"] = name
    _write_config(config)

    graph_name = proj.get("graph_name", name)

    # Hot-swap the in-memory config so subsequent requests (before any
    # backend restart) resolve to the new project's graph immediately.
    _hot_swap_default_project(request, name)

    return {
        "message": f"Switched to project '{name}'",
        "graph_name": graph_name,
        "restart_required": True,
    }


def _hot_swap_default_project(request: Request, name: str) -> None:
    """Reload runtime config after a project switch and clear the reader cache.

    Ensures the next request resolves the new project's graph/root even when
    the in-memory config was loaded before that project existed.
    """
    from core.backends.config import UnifiedConfig

    state = getattr(request.app.state, "app_state", None)
    try:
        refreshed = UnifiedConfig.from_yaml(config_path())
    except (FileNotFoundError, ValueError, ValidationError) as exc:
        logger.warning(
            "[desktop:projects] Failed to reload config during project switch; "
            "falling back to in-memory default_project update: %s",
            exc,
        )
        refreshed = None

    if refreshed is not None:
        if state is not None and getattr(state, "config", None) is not None:
            state.config = refreshed
        request.app.state.unified_config = refreshed
    else:
        if state is not None and getattr(state, "config", None) is not None:
            state.config.default_project = name
        ucfg = getattr(request.app.state, "unified_config", None)
        if ucfg is not None:
            ucfg.default_project = name

    # Clear the reader cache — stale readers point at the old project's DB.
    if hasattr(request.app.state, "desktop_reader_cache"):
        request.app.state.desktop_reader_cache = {}


def _get_unified_reader(request: Request):
    """Extract the unified reader from app state."""
    state = getattr(request.app.state, "app_state", None)
    if state is not None and getattr(state, "unified_reader", None) is not None:
        return state.unified_reader
    return getattr(request.app.state, "standalone_unified_reader", None)
