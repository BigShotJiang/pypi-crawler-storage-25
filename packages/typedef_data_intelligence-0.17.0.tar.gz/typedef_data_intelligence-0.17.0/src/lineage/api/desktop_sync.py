"""Desktop sync routes.

Manages sync operations: trigger, progress (SSE), cancel.
Sync runs in a multiprocessing.Process to avoid GIL contention and
nested asyncio.run() conflicts.
"""

from __future__ import annotations

import asyncio
import json
import logging
import multiprocessing
import os
import threading
import time
import uuid
from dataclasses import dataclass
from multiprocessing import Event, Process, Queue

from agent.api import shutdown_event
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from starlette.responses import StreamingResponse

logger = logging.getLogger(__name__)


def _sse_event(event_type: str, data: dict) -> str:
    """Format a single SSE event as a string."""
    return f"event: {event_type}\ndata: {json.dumps(data)}\n\n"


router = APIRouter(prefix="/desktop/sync", tags=["desktop-sync"])

# ── In-memory sync operation registry ─────────────────────────────────


@dataclass
class SyncOperation:
    """In-memory state for a running sync process."""

    sync_id: str
    project_name: str
    process: Process | None = None
    queue: Queue | None = None
    cancel_event: Event | None = None
    status: str = "pending"  # pending | running | complete | error | cancelled
    started_at: float = 0.0
    error: str | None = None


_sync_ops: dict[str, SyncOperation] = {}
_sync_lock = threading.Lock()


def _get_sync_op(sync_id: str) -> SyncOperation | None:
    """Read a sync operation from the registry under the module lock."""
    with _sync_lock:
        return _sync_ops.get(sync_id)


def _pop_sync_op(sync_id: str) -> SyncOperation | None:
    """Remove a sync operation from the registry under the module lock."""
    with _sync_lock:
        return _sync_ops.pop(sync_id, None)


def get_sync_ops() -> dict[str, SyncOperation]:
    """Return a snapshot of the current sync operations registry."""
    with _sync_lock:
        return _sync_ops.copy()


def _persist_synced_commit(project_name: str, head_commit: str | None) -> None:
    """Save the git commit that was just synced into project config."""
    if not head_commit:
        return
    try:
        import yaml
        from core.paths import config_path

        cfg_path = config_path()
        if not cfg_path.exists():
            return
        with open(cfg_path, encoding="utf-8") as f:
            cfg = yaml.safe_load(f) or {}
        projects = cfg.get("projects")
        if not isinstance(projects, dict):
            return
        project = projects.get(project_name)
        if not isinstance(project, dict):
            return
        project["last_synced_commit"] = head_commit
        tmp = cfg_path.with_suffix(".yaml.tmp")
        tmp.write_text(
            yaml.safe_dump(cfg, default_flow_style=False, sort_keys=False),
            encoding="utf-8",
        )
        os.replace(str(tmp), str(cfg_path))
    except Exception:
        logger.debug("Failed to persist synced commit", exc_info=True)


# ── Request/response models ───────────────────────────────────────────


class SyncRequest(BaseModel):
    """Request to start a sync operation for a project."""

    project_name: str
    full: bool = Field(False, description="Force full reload (drop + rebuild)")


class SyncResponse(BaseModel):
    """Response containing the sync operation identifier."""

    sync_id: str
    message: str


class SyncProgressEvent(BaseModel):
    """A single progress event emitted during a sync operation."""

    stage: str
    current: int
    total: int
    status: str  # running | completed | error
    message: str


# ── Subprocess worker ─────────────────────────────────────────────────


def _sync_worker(
    project_name: str,
    full: bool,
    progress_queue: Queue,
    cancel_event: Event,
) -> None:
    """Run UnifiedOrchestrator.run() in a child process.

    Sync always operates at the **project** level, using the project's base
    ``dbt_path`` and ``graph_name``.  Worktree-scoped sync is reserved for
    future work.

    Constructs the pipeline config from the project's config.yaml entry.
    Communicates progress via a multiprocessing.Queue.
    Checks cancel_event between stages.
    """
    # Set up file logging in the child process
    import logging as _logging

    from core.paths import logs_dir

    _logs = logs_dir()
    _logs.mkdir(parents=True, exist_ok=True)
    _log_file = _logs / "sync.log"

    _fmt = _logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    _fh = _logging.FileHandler(str(_log_file), mode="a")
    _fh.setLevel(_logging.INFO)
    _fh.setFormatter(_fmt)

    root = _logging.getLogger()
    root.setLevel(_logging.INFO)
    root.addHandler(_fh)

    # Quiet noisy libraries
    _logging.getLogger("httpcore").setLevel(_logging.WARNING)
    _logging.getLogger("httpx").setLevel(_logging.WARNING)
    _logging.getLogger("google_genai.models").setLevel(_logging.WARNING)

    # Load .env file so API keys and credentials are available in child process
    from core.paths import env_path as _env_path

    _env_file = _env_path()
    if _env_file.exists():
        for _line in _env_file.read_text().splitlines():
            _line = _line.strip()
            if _line and not _line.startswith("#") and "=" in _line:
                _k, _v = _line.split("=", 1)
                os.environ[_k.strip()] = _v.strip()

    _sync_log = _logging.getLogger("desktop.sync")
    _sync_log.info("=== desktop sync started for project '%s' ===", project_name)

    try:
        from ingest.unified.orchestrator import UnifiedOrchestrator
        from ingest.unified.stages.types import UnifiedPipelineConfig

        # Build config from project entry — resolves artifacts_dir, graph_name, SurrealDB creds.
        # Always project-level (no worktree_id) so sync uses the base dbt_path and graph.
        config = UnifiedPipelineConfig.from_project_name(
            project_name,
            full=full,
        )
        _sync_log.info(
            "artifacts_dir: %s, surreal_db: %s, full: %s",
            config.artifacts_dir,
            config.surreal_db,
            config.full,
        )

        # Validate manifest exists
        manifest = config.artifacts_dir / "manifest.json"
        if not manifest.exists():
            progress_queue.put(
                {
                    "stage": "validation",
                    "current": 0,
                    "total": 1,
                    "status": "error",
                    "message": f"manifest.json not found in {config.artifacts_dir}",
                }
            )
            return

        from ingest.unified.stages.registry import get_all_stages, get_stage_label

        total_stages = len(get_all_stages())

        def progress_callback(stage_name: str, current: int, total: int) -> None:
            if cancel_event.is_set():
                raise KeyboardInterrupt("Sync cancelled by user")
            label = get_stage_label(stage_name)
            progress_queue.put(
                {
                    "stage": stage_name,
                    "current": current,
                    "total": total,
                    "status": "running",
                    "message": label,
                }
            )

        # Write load sentinel: status = loading
        progress_queue.put(
            {
                "stage": "init",
                "current": 0,
                "total": total_stages,
                "status": "running",
                "message": "Starting sync pipeline",
            }
        )

        orchestrator = UnifiedOrchestrator(config, progress_callback=progress_callback)
        result = orchestrator.run()

        _sync_log.info("=== sync completed in %.1fs ===", result.total_elapsed_seconds)
        _sync_log.info(
            "Stage results: %s",
            {
                s.stage: ("error" if s.error else "skipped" if s.skipped else "ok")
                for s in result.stages
            },
        )

        # Resolve the git HEAD of the base worktree so the frontend can
        # detect staleness after future pulls.
        _head_commit: str | None = None
        try:
            from pathlib import Path

            from core.paths import config_path as _config_path

            from .desktop_worktree import _run_git

            _cfg_file = _config_path()
            if _cfg_file.exists():
                import yaml as _yaml

                with open(_cfg_file, encoding="utf-8") as _f:
                    _cfg = _yaml.safe_load(_f) or {}
                _proj = (_cfg.get("projects") or {}).get(project_name) or {}
                _dbt_path = _proj.get("dbt_path")
                if _dbt_path:
                    _proc = _run_git(Path(_dbt_path), ["rev-parse", "HEAD"], timeout=5)
                    if _proc.returncode == 0:
                        _head_commit = _proc.stdout.strip() or None
        except Exception:
            _sync_log.debug("Failed to resolve HEAD commit", exc_info=True)

        progress_queue.put(
            {
                "stage": "complete",
                "current": total_stages,
                "total": total_stages,
                "status": "completed",
                "message": f"Sync complete in {result.total_elapsed_seconds:.1f}s",
                "head_commit": _head_commit,
            }
        )

    except KeyboardInterrupt:
        progress_queue.put(
            {
                "stage": "cancelled",
                "current": 0,
                "total": 0,
                "status": "cancelled",
                "message": "Sync cancelled by user",
            }
        )
    except Exception as exc:
        import traceback

        _sync_log.error("=== sync failed ===\n%s", traceback.format_exc())
        progress_queue.put(
            {
                "stage": "error",
                "current": 0,
                "total": 0,
                "status": "error",
                "message": str(exc),
            }
        )


# ── Endpoints ─────────────────────────────────────────────────────────


@router.post("/", response_model=SyncResponse)
async def start_sync(req: SyncRequest):
    """Start a project-level sync in a child process. Returns sync_id for progress tracking.

    Sync always targets the project's base dbt_path and graph, regardless of
    which worktree the desktop UI is currently viewing.
    """
    with _sync_lock:
        # Check for already-running sync on this project
        for op in _sync_ops.values():
            if op.project_name == req.project_name and op.status == "running":
                raise HTTPException(
                    status_code=409,
                    detail=f"Sync already running for project '{req.project_name}'",
                )

        sync_id = str(uuid.uuid4())
        queue: Queue = multiprocessing.Queue(maxsize=256)
        cancel_event = multiprocessing.Event()

        proc = Process(
            target=_sync_worker,
            args=(
                req.project_name,
                req.full,
                queue,
                cancel_event,
            ),
            daemon=False,
        )

        op = SyncOperation(
            sync_id=sync_id,
            project_name=req.project_name,
            process=proc,
            queue=queue,
            cancel_event=cancel_event,
            status="running",
            started_at=time.time(),
        )
        _sync_ops[sync_id] = op

    proc.start()
    logger.info(
        "[desktop:sync] Started sync %s for project '%s' (pid=%d)",
        sync_id,
        req.project_name,
        proc.pid or 0,
    )

    return SyncResponse(sync_id=sync_id, message="Sync started")


@router.get("/{sync_id}/progress")
async def sync_progress(sync_id: str):
    """SSE stream for sync progress. Reads from multiprocessing.Queue."""
    op = _get_sync_op(sync_id)
    if not op:
        raise HTTPException(
            status_code=404, detail=f"Sync operation '{sync_id}' not found"
        )

    def _cleanup_op(op: SyncOperation, *, allow_retry: bool = True) -> None:
        """Join the child process and clean up resources."""
        process_alive = False
        if op.process:
            op.process.join(timeout=5)
            if op.process.is_alive():
                logger.warning(
                    "[desktop:sync] Force-killing sync process %d", op.process.pid or 0
                )
                op.process.terminate()
                op.process.join(timeout=2)
            if op.process.is_alive():
                logger.warning(
                    "[desktop:sync] Hard-killing sync process %d", op.process.pid or 0
                )
                try:
                    op.process.kill()
                    op.process.join(timeout=2)
                except Exception:
                    logger.debug(
                        "[desktop:sync] Failed to hard-kill sync process %d",
                        op.process.pid or 0,
                        exc_info=True,
                    )
            process_alive = op.process.is_alive()
            if process_alive:
                logger.warning(
                    "[desktop:sync] Sync process %d is still alive after teardown; "
                    "skipping process.close() and queue cleanup",
                    op.process.pid or 0,
                )
            else:
                try:
                    op.process.close()
                except Exception:
                    logger.debug(
                        "[desktop:sync] Failed to close sync process %d",
                        op.process.pid or 0,
                        exc_info=True,
                    )
        if op.queue and not process_alive:
            # Drain any remaining items to prevent broken pipe
            try:
                while not op.queue.empty():
                    op.queue.get_nowait()
            except Exception:
                pass  # nosec B110 — best-effort queue drain
            op.queue.close()
            op.queue.join_thread()
        if process_alive:
            if allow_retry:
                sync_id_ref = op.sync_id

                async def _retry_cleanup():
                    await asyncio.sleep(5)
                    retry_op = _get_sync_op(sync_id_ref)
                    if retry_op is not None and retry_op is op:
                        _cleanup_op(retry_op, allow_retry=False)

                try:
                    asyncio.get_running_loop().create_task(_retry_cleanup())
                except RuntimeError:
                    pass
            return
        # Remove from registry after a delay to allow late SSE reads
        sync_id_ref = op.sync_id

        async def _deferred_remove():
            await asyncio.sleep(30)
            _pop_sync_op(sync_id_ref)

        try:
            asyncio.get_running_loop().create_task(_deferred_remove())
        except RuntimeError:
            _pop_sync_op(sync_id_ref)

    async def generate():
        last_heartbeat = time.time()
        try:
            while not shutdown_event.is_set():
                # Non-blocking read from the queue
                try:
                    event = await asyncio.get_running_loop().run_in_executor(
                        None, lambda: op.queue.get(timeout=1.0) if op.queue else None
                    )
                except Exception:
                    event = None

                if event is not None:
                    evt_status = event.get("status", "running")
                    yield _sse_event(f"sync.{evt_status}", event)

                    if evt_status in ("completed", "error", "cancelled"):
                        op.status = evt_status  # type: ignore[assignment]
                        if evt_status == "error":
                            op.error = event.get("message")
                        if evt_status == "completed":
                            _persist_synced_commit(
                                op.project_name, event.get("head_commit")
                            )
                        break

                # Heartbeat every 15s to keep connection alive
                now = time.time()
                if now - last_heartbeat > 15:
                    yield _sse_event("heartbeat", {"timestamp": int(now * 1000)})
                    last_heartbeat = now

                # Check if child process died unexpectedly
                if op.process and not op.process.is_alive() and op.status == "running":
                    exit_code = op.process.exitcode
                    op.status = "error"
                    op.error = f"Sync process exited unexpectedly (code {exit_code})"
                    yield _sse_event(
                        "sync.error",
                        {
                            "stage": "error",
                            "status": "error",
                            "message": op.error,
                            "current": 0,
                            "total": 0,
                        },
                    )
                    break
        finally:
            _cleanup_op(op)

    return StreamingResponse(generate(), media_type="text/event-stream")


@router.delete("/{sync_id}")
async def cancel_sync(sync_id: str):
    """Cancel a running sync operation."""
    op = _get_sync_op(sync_id)
    if not op:
        raise HTTPException(
            status_code=404, detail=f"Sync operation '{sync_id}' not found"
        )

    if op.status != "running":
        return {"message": f"Sync '{sync_id}' is not running (status: {op.status})"}

    # Signal the child process to stop
    if op.cancel_event:
        op.cancel_event.set()

    # Give it a moment, then force-kill if needed
    if op.process and op.process.is_alive():
        op.process.join(timeout=5)
        if op.process.is_alive():
            op.process.terminate()
            op.process.join(timeout=2)

    # Clean up resources
    if op.process:
        try:
            op.process.close()
        except Exception:
            pass  # nosec B110 — best-effort process cleanup
    if op.queue:
        try:
            while not op.queue.empty():
                op.queue.get_nowait()
        except Exception:
            pass  # nosec B110 — best-effort queue drain
        try:
            op.queue.close()
            op.queue.join_thread()
        except Exception:
            pass  # nosec B110 — best-effort queue teardown

    op.status = "cancelled"
    logger.info("[desktop:sync] Cancelled sync %s", sync_id)

    # Remove from registry after brief delay
    async def _remove():
        await asyncio.sleep(10)
        _pop_sync_op(sync_id)

    asyncio.create_task(_remove())

    return {"message": f"Sync '{sync_id}' cancelled"}


# ── Debug endpoints (testing graph state simulation) ──────────────────
# Flip to True to enable debug endpoints; leave False for production.
DEBUG_ENDPOINTS_ENABLED = False


debug_router = APIRouter(prefix="/desktop/debug", tags=["desktop-debug"])


def _require_debug_mode():
    """Raise 404 unless debug endpoints are enabled."""
    if not DEBUG_ENDPOINTS_ENABLED:
        raise HTTPException(status_code=404, detail="Not found")


def _get_writer_for_debug(project_name: str | None = None):
    """Create a SurrealGraphWriter for the active project's graph."""
    import os

    from core.backends.unified_graph.surreal.load import connect
    from core.backends.unified_graph.surreal.writer import SurrealGraphWriter
    from core.paths import config_path, default_surreal_url

    graph_name = None
    if project_name:
        try:
            import yaml

            cfg_path = config_path()
            if cfg_path.exists():
                with open(cfg_path, encoding="utf-8") as f:
                    cfg = yaml.safe_load(f) or {}
                proj = (cfg.get("projects") or {}).get(project_name, {})
                graph_name = proj.get("graph_name")
        except Exception:
            logger.debug("Failed to read graph_name from project config", exc_info=True)

    if not graph_name:
        graph_name = os.environ.get("SURREAL_DB", "unified")

    db = connect(
        url=os.environ.get("SURREAL_URL", default_surreal_url()),
        namespace=os.environ.get("SURREAL_NS", "lineage"),
        database=graph_name,
        username=os.environ.get("SURREAL_USER", ""),
        password=os.environ.get("SURREAL_PASSWORD", ""),
    )
    return SurrealGraphWriter(db)


@debug_router.post(
    "/simulate-crashed-sync", dependencies=[Depends(_require_debug_mode)]
)
async def simulate_crashed_sync(project_name: str | None = None):
    """DEBUG: Set _meta to in_progress, simulating a killed-mid-sync state."""
    writer = _get_writer_for_debug(project_name)
    result = writer.debug_set_in_progress()
    return {
        "action": result,
        "message": "Sentinel set to in_progress. Catalog should show error.",
    }


@debug_router.post(
    "/simulate-partial-enrichment", dependencies=[Depends(_require_debug_mode)]
)
async def simulate_partial_enrichment(project_name: str | None = None):
    """DEBUG: Set enrichment_status to pending, simulating incomplete enrichment."""
    writer = _get_writer_for_debug(project_name)
    result = writer.debug_set_enrichment_pending()
    return {
        "action": result,
        "message": "Enrichment set to pending. Catalog should show warning.",
    }


@debug_router.delete("/sentinel", dependencies=[Depends(_require_debug_mode)])
async def clear_sentinel(project_name: str | None = None):
    """DEBUG: Delete _meta sentinel entirely, simulating no-data state."""
    writer = _get_writer_for_debug(project_name)
    result = writer.debug_clear_sentinel()
    return {
        "action": result,
        "message": "Sentinel cleared. Catalog should show 'no data synced'.",
    }


@debug_router.post("/restore-sentinel", dependencies=[Depends(_require_debug_mode)])
async def restore_sentinel(project_name: str | None = None):
    """DEBUG: Reset sentinel to healthy state (load_type=full, enrichment=complete)."""
    writer = _get_writer_for_debug(project_name)
    db = writer._db  # noqa: SLF001
    db.query("UPDATE _meta SET load_type = 'full', enrichment_status = 'complete';")
    return {"action": "restored", "message": "Sentinel restored to healthy state."}


@debug_router.post(
    "/simulate-version-mismatch", dependencies=[Depends(_require_debug_mode)]
)
async def simulate_version_mismatch(project_name: str | None = None):
    """DEBUG: Set ingest_version to a fake value so the health check reports mismatch."""
    writer = _get_writer_for_debug(project_name)
    db = writer._db  # noqa: SLF001
    db.query("UPDATE _meta SET ingest_version = '0.0.0-fake';")
    return {
        "action": "version_mismatch",
        "message": "ingest_version set to 0.0.0-fake. Health should report mismatch warning.",
    }


@debug_router.delete(
    "/last-synced-commit", dependencies=[Depends(_require_debug_mode)]
)
async def clear_last_synced_commit(project_name: str | None = None):
    """DEBUG: Remove last_synced_commit from project config → stale state on next poll."""
    import yaml
    from core.paths import config_path

    cfg_path = config_path()
    if not cfg_path.exists():
        raise HTTPException(status_code=404, detail="No config.yaml found")

    with open(cfg_path, encoding="utf-8") as f:
        cfg = yaml.safe_load(f) or {}

    resolved = project_name or cfg.get("default_project")
    projects = cfg.get("projects") or {}
    project = projects.get(resolved) if resolved else None
    if not isinstance(project, dict):
        raise HTTPException(status_code=404, detail=f"Project '{resolved}' not found")

    prev = project.pop("last_synced_commit", None)
    tmp = cfg_path.with_suffix(".yaml.tmp")
    tmp.write_text(
        yaml.safe_dump(cfg, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )
    import os

    os.replace(str(tmp), str(cfg_path))
    return {
        "action": "cleared",
        "previous": prev,
        "message": f"Cleared last_synced_commit for '{resolved}'. Worktree poll will show stale.",
    }
