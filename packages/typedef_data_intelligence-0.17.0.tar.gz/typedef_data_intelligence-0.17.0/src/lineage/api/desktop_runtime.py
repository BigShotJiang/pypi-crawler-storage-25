"""Packaged desktop backend entrypoint."""

from __future__ import annotations

import argparse
import os
from collections.abc import Sequence

import uvicorn


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    """Parse CLI arguments for the packaged desktop backend."""
    parser = argparse.ArgumentParser(description="Start the packaged desktop backend")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", default=8000, type=int)
    return parser.parse_args(argv)


def load_app():
    """Load the FastAPI app lazily for the packaged runtime."""
    from lineage.api.app import app

    return app


def main(argv: Sequence[str] | None = None) -> None:
    """Run the packaged desktop backend server."""
    args = parse_args(argv)
    os.environ.setdefault("TYPEDEF_API_PROFILE", "desktop")
    app = load_app()
    uvicorn.run(
        app,
        host=args.host,
        port=args.port,
        log_level="info",
        access_log=True,
        timeout_graceful_shutdown=5,
    )


if __name__ == "__main__":
    main()
