"""Concept card presentation layer.

Transforms raw ontology dicts into clean, business-readable concept cards.
No new inference — just orchestration, grouping, labeling, and Top-N limits.
"""

from __future__ import annotations

from typing import Any

from type_inference.display import smart_display_name

# ── Limits ────────────────────────────────────────────────────────

_MAX_FACETS = 5
_MAX_RELATIONS = 8
_MAX_METRIC_FAMILIES = 5
_MAX_STANDALONE_METRICS = 5
_MAX_BEHAVIORS = 3
_MAX_PROCESSES = 3
_MAX_EVENT_FAMILIES = 3

# ── Display label maps ───────────────────────────────────────────

_ANCHOR_KIND_LABELS: dict[str, str] = {
    "EntityLike": "Entity",
    "EventLike": "Event",
    "Mixed": "Mixed",
}

_ANCHOR_ROLE_LABELS: dict[str, str | None] = {
    "ReferenceHubLike": "Reference Hub",
    "ReferenceSourceLike": "Reference Source",
    "AssociativeLike": "Bridge",
    "IndependentLike": "Independent",
    "Unknown": None,
}

_FACET_KIND_LABELS: dict[str, str] = {
    "CoreEntity": "Core Entity",
    "SnapshotFacet": "Snapshot",
    "ActivityFacet": "Activity",
    "BridgeFacet": "Bridge",
    "StateFacet": "State",
    "Other": "Other",
}

# Predicate families that indicate directional reference relationships
_REFERENCE_PREDICATES = {"References", "BelongsTo"}
# Predicate families that indicate associative (undirected) relationships
_ASSOCIATION_PREDICATES = {"AssociatedWith", "CoOccursWith", "EquivalentTo"}


# ── Public API ────────────────────────────────────────────────────


def build_concept_card(
    reader: Any,
    anchor_id: str,
    *,
    debug: bool = False,
    published_only: bool = True,
) -> dict[str, Any]:
    """Build a presentation-ready concept card for *anchor_id*.

    Args:
        reader: An ontology reader (OntologyGraphReader or compatible stub).
        anchor_id: The anchor to build the card for.
        debug: When True, include scores/breakdowns and remove Top-N limits.
        published_only: Filter behaviour/metrics to published items.
            When *debug* is True this is forced to False.

    Returns:
        Structured dict with sections: anchor, facets, relations,
        metric_families, standalone_metrics, event_families, behaviors,
        processes, counts.

    Raises:
        ValueError: If *anchor_id* is not found.
    """
    anchor = reader.get_anchor(anchor_id)
    if anchor is None:
        raise ValueError(f"Unknown anchor: {anchor_id}")

    effective_published = False if debug else published_only

    facets = reader.get_facets(anchor_id)
    relations = reader.get_relations(anchor_id)
    event_families = reader.get_anchor_event_families(
        anchor_id, published_only=effective_published
    )
    behaviors = reader.get_anchor_behavior_patterns(
        anchor_id, published_only=effective_published
    )
    processes = reader.get_anchor_process_candidates(
        anchor_id, published_only=effective_published
    )
    metrics = reader.get_anchor_metrics(anchor_id, published_only=effective_published)
    metric_families = reader.get_anchor_metric_families(
        anchor_id, published_only=effective_published
    )

    # Family member index — used to separate standalone metrics
    family_member_ids: set[str] = set()
    for fam in metric_families:
        family_member_ids.update(fam.get("member_metric_ids", []))

    # In debug mode, remove limits
    if debug:
        fac_limit = 9999
        rel_limit = 9999
        mf_limit = 9999
        sm_limit = 9999
        ef_limit = 9999
        bh_limit = 9999
        pr_limit = 9999
    else:
        fac_limit = _MAX_FACETS
        rel_limit = _MAX_RELATIONS
        mf_limit = _MAX_METRIC_FAMILIES
        sm_limit = _MAX_STANDALONE_METRICS
        ef_limit = _MAX_EVENT_FAMILIES
        bh_limit = _MAX_BEHAVIORS
        pr_limit = _MAX_PROCESSES

    standalone = [m for m in metrics if m.get("metric_id") not in family_member_ids]

    return {
        "anchor": _present_anchor(anchor, debug=debug),
        "facets": _present_facets(facets, debug=debug, limit=fac_limit),
        "relations": _group_relations(
            relations, anchor_id, debug=debug, limit=rel_limit
        ),
        "metric_families": _present_metric_families(
            metric_families,
            metrics,
            debug=debug,
            limit=mf_limit,
        ),
        "standalone_metrics": _present_standalone_metrics(
            metrics,
            family_member_ids,
            debug=debug,
            limit=sm_limit,
        ),
        "event_families": _present_event_families(
            event_families, debug=debug, limit=ef_limit
        ),
        "behaviors": _present_behaviors(behaviors, debug=debug, limit=bh_limit),
        "processes": _present_processes(processes, debug=debug, limit=pr_limit),
        "counts": {
            "total_facets": len(facets),
            "total_relations": len(relations),
            "total_metric_families": len(metric_families),
            "total_standalone_metrics": len(standalone),
            "total_event_families": len(event_families),
            "total_behaviors": len(behaviors),
            "total_processes": len(processes),
        },
    }


# ── Section builders (internal) ──────────────────────────────────


def _display_name(canonical_name: str) -> str:
    """Convert ``order_line_item`` to ``Order Line Item``."""
    name, _confidence = smart_display_name(canonical_name)
    return name


def _present_anchor(anchor: dict[str, Any], *, debug: bool) -> dict[str, Any]:
    model_count = (
        anchor.get("metrics", {}).get("explicit_model_count", 0)
        if isinstance(
            anchor.get("metrics"),
            dict,
        )
        else 0
    )
    result: dict[str, Any] = {
        "id": anchor["anchor_id"],
        "display_name": _display_name(
            anchor.get("canonical_name", anchor["anchor_id"])
        ),
        "kind": _ANCHOR_KIND_LABELS.get(
            anchor.get("anchor_kind", ""), anchor.get("anchor_kind")
        ),
        "role": _ANCHOR_ROLE_LABELS.get(
            anchor.get("anchor_role", ""), anchor.get("anchor_role")
        ),
        "is_primary": anchor.get("is_primary", False),
        "model_count": model_count,
    }
    if debug:
        result["score"] = anchor.get("score")
        result["score_breakdown"] = anchor.get("score_breakdown")
        result["entity_likeness_score"] = anchor.get("entity_likeness_score")
        result["event_likeness_score"] = anchor.get("event_likeness_score")
        result["role_confidence"] = anchor.get("role_confidence")
        result["role_reasons"] = anchor.get("role_reasons")
        result["anchor_kind_raw"] = anchor.get("anchor_kind")
        result["anchor_role_raw"] = anchor.get("anchor_role")
    return result


def _present_facets(
    facets: list[dict[str, Any]],
    *,
    debug: bool,
    limit: int,
) -> list[dict[str, Any]]:
    sorted_facets = sorted(facets, key=lambda f: f.get("model_count", 0), reverse=True)
    results: list[dict[str, Any]] = []
    for facet in sorted_facets[:limit]:
        raw_kind = facet.get("facet_kind", "Other")
        item: dict[str, Any] = {
            "id": facet.get("facet_id"),
            "kind": _FACET_KIND_LABELS.get(raw_kind, raw_kind),
            "raw_kind": raw_kind,
            "model_count": facet.get("model_count", 0),
            "cohesion_score": facet.get("cohesion_score"),
            "behavioral_class": facet.get("behavioral_class"),
            "pipeline_operation": facet.get("pipeline_operation"),
            # Always include evidence for expandable UI
            "evidence_examples": facet.get("evidence_examples", []),
            "supporting_node_ids": facet.get("supporting_node_ids", []),
        }
        if debug:
            item["signature"] = facet.get("signature")
        results.append(item)
    return results


def _classify_relation_bucket(rel: dict[str, Any], anchor_id: str) -> str:
    """Classify a relation into one of four buckets."""
    predicate_family = rel.get("predicate_family", "")
    direction = rel.get("direction", "")
    left = rel.get("left_anchor_id", "")
    right = rel.get("right_anchor_id", "")

    if predicate_family in _REFERENCE_PREDICATES:
        if direction == "Directed" and left == anchor_id:
            return "references_out"
        if direction == "Directed" and right == anchor_id:
            return "referenced_by"
        # Directed but anchor is on neither side — shouldn't happen, fall through
    if predicate_family in _ASSOCIATION_PREDICATES:
        return "associations"
    return "other"


def _present_relation(
    rel: dict[str, Any],
    anchor_id: str,
    bucket: str,
    *,
    debug: bool,
) -> dict[str, Any]:
    """Present a single relation, oriented relative to the anchor."""
    left = rel.get("left_anchor_id", "")
    right = rel.get("right_anchor_id", "")

    if bucket == "referenced_by":
        # The anchor is the target; show who references it
        source_id = left if right == anchor_id else right
        item: dict[str, Any] = {
            "id": rel.get("canonical_relation_id"),
            "source_anchor_id": source_id,
            "source_display_name": _display_name(source_id),
            "label": rel.get("predicate_label"),
            "semantic_label": rel.get("semantic_predicate_label"),
            "cardinality": rel.get("cardinality_hint"),
            "confidence": rel.get("confidence_tier"),
        }
    else:
        # The anchor is the source (or it's an association); show the other end
        target_id = right if left == anchor_id else left
        item = {
            "id": rel.get("canonical_relation_id"),
            "target_anchor_id": target_id,
            "target_display_name": _display_name(target_id),
            "label": rel.get("predicate_label"),
            "semantic_label": rel.get("semantic_predicate_label"),
            "cardinality": rel.get("cardinality_hint"),
            "confidence": rel.get("confidence_tier"),
        }
    if debug:
        item["score"] = rel.get("score")
        item["evidence_kinds"] = rel.get("evidence_kinds")
        item["predicate_confidence"] = rel.get("predicate_confidence")
        item["predicate_reasons"] = rel.get("predicate_reasons")
    return item


def _group_relations(
    relations: list[dict[str, Any]],
    anchor_id: str,
    *,
    debug: bool,
    limit: int,
) -> dict[str, list[dict[str, Any]]]:
    """Group relations into four buckets, capped at *limit* total."""
    buckets: dict[str, list[dict[str, Any]]] = {
        "references_out": [],
        "referenced_by": [],
        "associations": [],
        "other": [],
    }
    # Sort by score descending before bucketing so the limit picks the best
    sorted_rels = sorted(relations, key=lambda r: r.get("score", 0), reverse=True)
    total = 0
    for rel in sorted_rels:
        if total >= limit:
            break
        bucket = _classify_relation_bucket(rel, anchor_id)
        buckets[bucket].append(_present_relation(rel, anchor_id, bucket, debug=debug))
        total += 1
    return buckets


def _present_metric_families(
    families: list[dict[str, Any]],
    all_metrics: list[dict[str, Any]],
    *,
    debug: bool,
    limit: int,
) -> list[dict[str, Any]]:
    metric_lookup = {m.get("metric_id"): m for m in all_metrics}
    sorted_fams = sorted(families, key=lambda f: f.get("score", 0), reverse=True)
    results: list[dict[str, Any]] = []
    for fam in sorted_fams[:limit]:
        rep_id = fam.get("representative_metric_id")
        rep_metric = metric_lookup.get(rep_id)
        rep_name = rep_metric.get("display_name") if rep_metric else None
        # Resolve member metrics for expandable UI
        member_ids = fam.get("member_metric_ids", [])
        members = []
        for mid in member_ids:
            m = metric_lookup.get(mid)
            if m:
                members.append({
                    "metric_id": m.get("metric_id"),
                    "display_name": m.get("display_name"),
                    "agg": m.get("agg"),
                    "metric_kind": m.get("metric_kind"),
                })
        item: dict[str, Any] = {
            "family_id": fam.get("family_id"),
            "family_label": fam.get("family_label"),
            "representative_metric": rep_name,
            "member_count": fam.get("member_count", 0),
            "published_member_count": fam.get("published_member_count", 0),
            "quality_tier": fam.get("quality_tier"),
            "members": members,
            "source_models": fam.get("supporting_node_ids", []),
            "agg_mix": fam.get("agg_mix", []),
        }
        if debug:
            item["score"] = fam.get("score")
            item["score_breakdown"] = fam.get("score_breakdown")
            item["reasons"] = fam.get("reasons")
            item["member_metric_ids"] = member_ids
        results.append(item)
    return results


def _present_standalone_metrics(
    metrics: list[dict[str, Any]],
    family_member_ids: set[str],
    *,
    debug: bool,
    limit: int,
) -> list[dict[str, Any]]:
    standalone = [m for m in metrics if m.get("metric_id") not in family_member_ids]
    sorted_metrics = sorted(standalone, key=lambda m: m.get("score", 0), reverse=True)
    results: list[dict[str, Any]] = []
    for m in sorted_metrics[:limit]:
        item: dict[str, Any] = {
            "metric_id": m.get("metric_id"),
            "display_name": m.get("display_name"),
            "metric_kind": m.get("metric_kind"),
            "agg": m.get("agg"),
            "quality_tier": m.get("quality_tier"),
        }
        if debug:
            item["score"] = m.get("score")
            item["score_breakdown"] = m.get("score_breakdown")
            item["reasons"] = m.get("reasons")
        results.append(item)
    return results


def _present_event_families(
    families: list[dict[str, Any]],
    *,
    debug: bool,
    limit: int,
) -> list[dict[str, Any]]:
    sorted_fams = sorted(families, key=lambda f: f.get("score", 0), reverse=True)
    results: list[dict[str, Any]] = []
    for fam in sorted_fams[:limit]:
        item: dict[str, Any] = {
            "family_id": fam.get("family_id"),
            "family_label": fam.get("family_label"),
            "member_count": fam.get("member_count", 0),
            "quality_tier": fam.get("quality_tier"),
        }
        if debug:
            item["score"] = fam.get("score")
            item["score_breakdown"] = fam.get("score_breakdown")
            item["reasons"] = fam.get("reasons")
            item["coverage_member_ratio"] = fam.get("coverage_member_ratio")
            item["shape_cohesion"] = fam.get("shape_cohesion")
            item["member_anchor_ids"] = fam.get("member_anchor_ids")
        results.append(item)
    return results


def _present_behaviors(
    patterns: list[dict[str, Any]],
    *,
    debug: bool,
    limit: int,
) -> list[dict[str, Any]]:
    sorted_patterns = sorted(patterns, key=lambda p: p.get("score", 0), reverse=True)
    results: list[dict[str, Any]] = []
    for p in sorted_patterns[:limit]:
        item: dict[str, Any] = {
            "pattern_id": p.get("pattern_id"),
            "pattern_label": p.get("pattern_label"),
            "family_label": p.get("family_label"),
            "quality_tier": p.get("quality_tier"),
        }
        if debug:
            item["score"] = p.get("score")
            item["score_breakdown"] = p.get("score_breakdown")
            item["reasons"] = p.get("reasons")
            item["support_count"] = p.get("support_count")
        results.append(item)
    return results


def _present_processes(
    candidates: list[dict[str, Any]],
    *,
    debug: bool,
    limit: int,
) -> list[dict[str, Any]]:
    sorted_procs = sorted(candidates, key=lambda c: c.get("score", 0), reverse=True)
    results: list[dict[str, Any]] = []
    for c in sorted_procs[:limit]:
        item: dict[str, Any] = {
            "process_id": c.get("process_id"),
            "process_label": c.get("process_label"),
            "steps": c.get("family_sequence", []),
            "quality_tier": c.get("quality_tier"),
        }
        if debug:
            item["score"] = c.get("score")
            item["score_breakdown"] = c.get("score_breakdown")
            item["reasons"] = c.get("reasons")
            item["support_count"] = c.get("support_count")
        results.append(item)
    return results
