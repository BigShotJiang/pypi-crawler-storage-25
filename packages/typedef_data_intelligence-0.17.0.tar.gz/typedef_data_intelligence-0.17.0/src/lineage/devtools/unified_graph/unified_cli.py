"""CLI entry point for unified graph build.

Thin wrapper around :class:`UnifiedOrchestrator` — parses args, builds
config, runs the pipeline, and prints results.

Usage:
    lineage-unified-build \
        --artifacts-dir /path/to/dbt/target \
        --ingest-config /path/to/ingest.yml \
        [--surreal-url ws://127.0.0.1:3567] \
        [--surreal-ns lineage] \
        [--surreal-db unified] \
        [--model-filter fct_] \
        [--skip-semantic] \
        [--skip-type-inference] \
        [--incremental | --full] \
        [--dry-run] \
        [--verbose]
"""

from __future__ import annotations

import warnings

# Suppress noisy version-mismatch warnings from vendored requests/urllib3
warnings.filterwarnings(
    "ignore",
    message=".*urllib3.*charset_normalizer.*doesn't match a supported version.*",
)

import argparse  # noqa: E402
import logging  # noqa: E402
import sys  # noqa: E402
from pathlib import Path  # noqa: E402
from typing import TYPE_CHECKING  # noqa: E402

from core.paths import default_surreal_url  # noqa: E402

from lineage.utils.env import load_env_file  # noqa: E402

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from ingest.unified.orchestrator import PipelineResult, UnifiedPipelineConfig


# ---------------------------------------------------------------------------
# Arg parsing
# ---------------------------------------------------------------------------


def _resolve_default_artifacts_dir() -> Path | None:
    """Resolve default artifacts dir from env vars (same chain as Justfile)."""
    import os

    local_path = os.environ.get("GITHUB_DBT_PROJECT_LOCAL_PATH")
    repo_name = os.environ.get("GITHUB_DBT_PROJECT_REPO_NAME")
    if not local_path or not repo_name:
        return None
    repo_dir = Path(local_path) / repo_name
    project_root = os.environ.get("DBT_PROJECT_ROOT", "")
    project_dir = repo_dir / project_root if project_root else repo_dir
    return project_dir / "target"


def _discover_ingest_config(artifacts_dir: Path) -> Path | None:
    """Discover ingest config file with fallback logic."""
    for name in ("ingest.yml", "config.yml"):
        candidate = artifacts_dir / name
        if candidate.exists():
            return candidate

    service_root = Path(__file__).parent.parent.parent.parent.parent
    for name in ("config.ingest.unified.yml", "config.ingest.yml"):
        candidate = service_root / name
        if candidate.exists():
            return candidate

    return None


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Build unified lineage graph directly from dbt artifacts.",
    )
    default_artifacts = _resolve_default_artifacts_dir()
    parser.add_argument(
        "--artifacts-dir",
        type=Path,
        required=default_artifacts is None,
        default=default_artifacts,
        help="Path to dbt target/ directory (default: from GITHUB_DBT_PROJECT_LOCAL_PATH)",
    )
    parser.add_argument(
        "--ingest-config",
        type=Path,
        default=None,
        help="Path to ingest config YAML (auto-discovers if not provided)",
    )
    parser.add_argument(
        "--skip-semantic",
        action="store_true",
        help="Skip semantic analysis (structural graph only)",
    )
    parser.add_argument(
        "--model-filter",
        default=None,
        help="Only process models whose name contains this substring",
    )
    # SurrealDB connection
    parser.add_argument("--surreal-url", default=None,
                        help="SurrealDB URL (overrides ingest config)")
    parser.add_argument("--surreal-ns", default="lineage", help="SurrealDB namespace")
    parser.add_argument("--surreal-db", default=None,
                        help="SurrealDB database (default: derived from dbt project name)")
    parser.add_argument("--surreal-user", default="")
    parser.add_argument("--surreal-password", default="")
    # Load mode
    load_mode = parser.add_mutually_exclusive_group()
    load_mode.add_argument(
        "--incremental",
        action="store_true",
        default=True,
        help="Incremental load (default)",
    )
    load_mode.add_argument(
        "--full",
        action="store_true",
        help="Force a full rebuild",
    )
    parser.add_argument("--dry-run", action="store_true", help="Print stats without writing")
    parser.add_argument("--verbose", action="store_true", help="Enable debug logging")
    # Salesforce integration
    parser.add_argument(
        "--salesforce",
        action="store_true",
        help="Also load Salesforce metadata into the unified graph",
    )
    parser.add_argument("--sf-org-key", default=None,
                        help="Salesforce org key (default: auto from org info)")
    parser.add_argument("--sf-sobject-filter", default=None,
                        help="Comma-separated SObject API names to include")
    parser.add_argument("--sf-no-formulas", action="store_true",
                        help="Skip formula field reference parsing")
    parser.add_argument("--sf-no-reports", action="store_true",
                        help="Skip report loading and IR generation")
    parser.add_argument("--sf-no-stitch", action="store_true",
                        help="Skip cross-domain stitching to dbt graph")
    parser.add_argument("--sf-stitch-llm", action="store_true",
                        help="Use LLM for unmatched assets during stitching")
    # Cube.dev integration
    parser.add_argument(
        "--cube",
        type=str,
        default=None,
        metavar="DIR",
        help="Path to Cube.dev project directory (loads cubes/views into unified graph)",
    )
    parser.add_argument("--cube-name", default=None,
                        help="Cube project name (default: directory name)")
    parser.add_argument("--cube-no-stitch", action="store_true",
                        help="Skip cross-domain stitching to dbt graph")
    # Profiling
    parser.add_argument(
        "--profile",
        action="store_true",
        help="Enable warehouse table profiling (requires data backend in ingest config)",
    )
    # Type inference
    parser.add_argument(
        "--skip-type-inference",
        action="store_true",
        help="Skip type inference pass (grain/behavioral classification)",
    )
    parser.add_argument(
        "--sf-grain-fallback",
        action="store_true",
        help="Enable Snowflake PK fallback for grain resolution",
    )
    return parser.parse_args()


# ---------------------------------------------------------------------------
# Config translation (args → orchestrator config)
# ---------------------------------------------------------------------------


def _build_pipeline_config(args: argparse.Namespace) -> UnifiedPipelineConfig:
    """Translate CLI args into a UnifiedPipelineConfig."""
    from ingest.config import IngestConfig
    from ingest.unified.cube.integration import CubeIntegrationConfig
    from ingest.unified.orchestrator import UnifiedPipelineConfig
    from ingest.unified.salesforce.integration import SalesforceIntegrationConfig

    # Discover + load ingest config
    ingest_config_path = args.ingest_config or _discover_ingest_config(args.artifacts_dir)
    ingest_cfg = None
    if ingest_config_path and ingest_config_path.exists():
        ingest_cfg = IngestConfig.from_yaml(ingest_config_path)
        logger.info("Using ingest config: %s", ingest_config_path)
    else:
        logger.info("No ingest config found, using defaults")

    # Salesforce sub-config
    sf_filter = None
    if args.sf_sobject_filter:
        sf_filter = {s.strip() for s in args.sf_sobject_filter.split(",")}

    salesforce = SalesforceIntegrationConfig(
        enabled=args.salesforce,
        org_key=args.sf_org_key,
        sobject_filter=sf_filter,
        parse_formulas=not args.sf_no_formulas,
        load_reports=not getattr(args, "sf_no_reports", False),
        stitch=not getattr(args, "sf_no_stitch", False),
        stitch_llm=getattr(args, "sf_stitch_llm", False),
    )

    # Cube sub-config
    cube = CubeIntegrationConfig(
        enabled=args.cube is not None,
        project_dir=Path(args.cube) if args.cube else None,
        project_name=args.cube_name,
        stitch=not getattr(args, "cube_no_stitch", False),
    )

    return UnifiedPipelineConfig(
        artifacts_dir=args.artifacts_dir,
        surreal_url=args.surreal_url or default_surreal_url(),
        surreal_ns=args.surreal_ns,
        surreal_db=args.surreal_db,
        surreal_user=args.surreal_user,
        surreal_password=args.surreal_password,
        full=args.full,
        dry_run=args.dry_run,
        model_filter=args.model_filter,
        skip_semantic=args.skip_semantic,
        skip_type_inference=args.skip_type_inference,
        skip_profiling=not args.profile,
        sf_grain_fallback=args.sf_grain_fallback,
        integration_configs={
            "salesforce": salesforce,
            "cube": cube,
        },
        verbose=args.verbose,
        ingest_config=ingest_cfg,
    )


# ---------------------------------------------------------------------------
# Result formatting
# ---------------------------------------------------------------------------


def _print_results(result: PipelineResult) -> None:
    """Print pipeline results in a human-readable format."""
    from ingest.unified.orchestrator import (
        BuildStageResult,
        ChangeDetectionResult,
        FingerprintStageResult,
        IntegrationStageResult,
        LoadStageResult,
        OntologyStageResult,
        ProfilingStageResult,
        SemanticStageResult,
        TypeInferenceStageResult,
    )

    for stage in result.stages:
        if stage.skipped:
            continue
        if stage.error:
            print(f"\n[{stage.stage}] ERROR: {stage.error}")
            continue

        if isinstance(stage, FingerprintStageResult):
            print(
                f"\nFingerprinted {stage.model_count} models "
                f"({stage.canonical_sql_count} with canonical SQL) "
                f"in {stage.elapsed_seconds:.2f}s"
            )

        elif isinstance(stage, ChangeDetectionResult):
            print(
                f"\nChange detection: {stage.added} added, {stage.modified} modified, "
                f"{stage.removed} removed, {stage.unchanged} unchanged"
            )
            if not stage.has_changes:
                print("No changes detected. Done.")

        elif isinstance(stage, BuildStageResult):
            print("\n=== Unified Graph Build ===")
            print(f"  Nodes: {stage.node_count}")
            for col, count in sorted(stage.node_counts_by_collection.items()):
                print(f"    {col}: {count}")
            print(f"  Edges: {stage.edge_count}")
            for col, count in sorted(stage.edge_counts_by_collection.items()):
                print(f"    {col}: {count}")

        elif isinstance(stage, LoadStageResult):
            print(f"\nLoaded to SurrealDB ({stage.load_type}):")
            print(f"  Nodes: {stage.node_count}")
            print(f"  Edges: {stage.edge_count}")
            if stage.change_counts:
                cc = stage.change_counts
                print(
                    f"  Changes: {cc['added']} added, {cc['modified']} modified, "
                    f"{cc['removed']} removed, {cc['unchanged']} unchanged"
                )

        elif isinstance(stage, IntegrationStageResult):
            print(f"\n{stage.stage.title()} loaded (incremental):")
            print(f"  Nodes: {stage.node_count}")
            print(f"  Edges: {stage.edge_count}")
            if stage.stitch_counts:
                print(f"  Stitch: {stage.stitch_counts}")
            print(f"  Completed in {stage.elapsed_seconds:.2f}s")

        elif isinstance(stage, ProfilingStageResult):
            print("\n=== Profiling ===")
            print(
                f"  Tables: {stage.tables_profiled} profiled, "
                f"{stage.tables_failed} failed"
            )
            print(f"  Nodes: {stage.node_count}, Edges: {stage.edge_count}")
            print(f"  Completed in {stage.elapsed_seconds:.2f}s")

        elif isinstance(stage, TypeInferenceStageResult):
            print("\n=== Type Inference ===")
            print(
                f"  {stage.typed_nodes}/{stage.total_nodes} nodes typed "
                f"({stage.coverage:.0%})"
            )
            print(f"  Write-back: {stage.write_succeeded} succeeded, {stage.write_failed} failed")
            if stage.concepts_written:
                print(f"  Concepts: {stage.concepts_written} written")
            print(f"  Completed in {stage.elapsed_seconds:.2f}s")

        elif isinstance(stage, OntologyStageResult):
            print("\n=== Ontology ===")
            print(
                f"  Anchors: {stage.anchor_count} "
                f"({stage.primary_anchor_count} primary)"
            )
            print(f"  Facets: {stage.facet_count}")
            print(f"  Relations: {stage.relation_count}")
            print(f"  Event families: {stage.event_family_count}")
            print(f"  Completed in {stage.elapsed_seconds:.2f}s")

        elif isinstance(stage, SemanticStageResult):
            print("\n=== Semantic Analysis ===")
            print(
                f"  Updated {stage.models_updated}/{stage.models_processed} process nodes"
            )
            print(f"  Completed in {stage.elapsed_seconds:.2f}s")

    if result.build and result.build.skipped:
        pass  # dry-run already handled
    elif result.change_detection and not result.change_detection.has_changes:
        pass  # already printed
    else:
        print(f"\nDone in {result.total_elapsed_seconds:.2f}s.")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    load_env_file()
    args = _parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )

    if not args.artifacts_dir.exists():
        logger.error("Artifacts directory not found: %s", args.artifacts_dir)
        sys.exit(1)

    from ingest.unified.orchestrator import UnifiedOrchestrator

    config = _build_pipeline_config(args)
    orchestrator = UnifiedOrchestrator(config)
    result = orchestrator.run()
    _print_results(result)


if __name__ == "__main__":
    main()
