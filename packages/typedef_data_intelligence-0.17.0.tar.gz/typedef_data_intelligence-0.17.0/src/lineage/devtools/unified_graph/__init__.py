"""ArangoDB unified graph transform devtool.

Transforms the existing FalkorDB lineage graph into a unified 4-node-type model
inside ArangoDB, enriched with grain propagation data.

Usage:
    uv run lineage-arango-transform \
        --grain-traces /path/to/grain_traces.json \
        --concept-index /path/to/concept_index.json \
        --skip-falkordb \
        --dry-run
"""
