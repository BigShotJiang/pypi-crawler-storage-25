"""SurrealDB backend for the unified lineage graph."""
