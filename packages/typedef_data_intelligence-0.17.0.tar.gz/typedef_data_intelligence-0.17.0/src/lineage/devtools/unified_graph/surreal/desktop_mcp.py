"""FastMCP server that wraps desktop_graph toolset via embedded SurrealDB.

Instead of reimplementing tools, this server auto-wraps every tool registered
on ``desktop_graph_toolset`` from the agent package. Changes to the toolset
are immediately available via MCP — no duplication.

The bridge works by constructing a minimal PydanticAI ``RunContext`` with real
``AgentDeps`` (containing the SurrealDB reader) and calling the original async
tool functions.

Project discovery:
  - Reads ``~/.typedef-desktop/config.yaml`` (or ``TYPEDEF_HOME/config.yaml``)
  - Each tool accepts an optional ``project`` parameter
  - Defaults to ``default_project`` from config (override with ``TYPEDEF_PROJECT``)
"""

from __future__ import annotations

import asyncio
import concurrent.futures
import inspect
import logging
import os
import re
import socket
import time
from pathlib import Path
from typing import (  # noqa: F401 — Literal used by eval'd annotations from desktop_graph
    Any,
    Literal,
)

import yaml
from agent.toolsets.common import ToolError
from agent.toolsets.desktop_graph import desktop_graph_toolset
from agent.types import AgentDeps, AgentState
from core.backends.unified_graph.surreal.load import connect as _connect
from core.backends.unified_graph.surreal.query import q, sanitize
from core.backends.unified_graph.surreal.reader import SurrealUnifiedGraphReader
from core.backends.unified_graph.surreal.schema import (
    EDGE_CONSTRAINTS,
    EDGE_TABLES,
    SHARED_NODE_FIELD_NAMES,
    VERTEX_TABLES,
)
from fastmcp import FastMCP
from pydantic_ai import RunContext
from pydantic_ai.models.test import TestModel
from pydantic_ai.usage import RunUsage

logger = logging.getLogger(__name__)

mcp = FastMCP("desktop-graph")

# ---------------------------------------------------------------------------
# Config + connection management
# ---------------------------------------------------------------------------

_config: dict[str, Any] | None = None
_connection: Any | None = None
_current_db: str | None = None
_current_url: str | None = None  # tracks which URL we connected to
_sidecar_cache: tuple[float, str | None] = (0.0, None)  # (expiry_time, url_or_None)
_SIDECAR_TTL_OK = 5.0  # seconds to cache a successful probe
_SIDECAR_TTL_FAIL = 30.0  # seconds to cache a failed probe (avoids 500ms blocks)


def _typedef_home() -> Path:
    raw = os.environ.get("TYPEDEF_HOME")
    if raw:
        return Path(raw).expanduser().resolve()
    return Path.home() / ".typedef-desktop"


def _load_config() -> dict[str, Any]:
    global _config
    if _config is not None:
        return _config

    config_path = _typedef_home() / "config.yaml"
    if not config_path.exists():
        logger.warning("No config found at %s", config_path)
        _config = {}
        return _config

    with open(config_path) as f:
        _config = yaml.safe_load(f) or {}
    return _config


def _check_sidecar() -> str | None:
    """Probe the sidecar with a short TTL cache to avoid per-call overhead."""
    global _sidecar_cache

    now = time.monotonic()
    expiry, cached_url = _sidecar_cache
    if now < expiry:
        return cached_url

    sidecar_url = os.environ.get("SURREAL_SIDECAR_URL", "ws://127.0.0.1:3567")
    result: str | None = None
    try:
        host, port = sidecar_url.split("://", 1)[-1].split(":")
        with socket.create_connection((host, int(port)), timeout=0.5):
            pass
        result = sidecar_url
    except (OSError, ValueError):
        pass

    ttl = _SIDECAR_TTL_OK if result else _SIDECAR_TTL_FAIL
    _sidecar_cache = (now + ttl, result)
    return result


def _surreal_url() -> str:
    if url := os.environ.get("SURREAL_URL"):
        return url

    # Prefer the websocket sidecar if it's reachable — the embedded driver
    # can't open the RocksDB files while the sidecar holds the lock.
    if sidecar := _check_sidecar():
        return sidecar

    # Fall back to embedded
    config = _load_config()
    if url := config.get("lineage", {}).get("surreal_url"):
        return url
    storage = _typedef_home() / "graph-storage"
    return f"surrealkv://{storage}"


def _default_project() -> str:
    if project := os.environ.get("TYPEDEF_PROJECT"):
        return project
    config = _load_config()
    if default := config.get("default_project"):
        projects = config.get("projects", {})
        if default in projects:
            return projects[default].get("graph_name", default)
    return os.environ.get("SURREAL_DB", "unified")


def _resolve_graph_name(project: str | None) -> str:
    if not project:
        return _default_project()
    config = _load_config()
    projects = config.get("projects", {})
    if project in projects:
        return projects[project].get("graph_name", project)
    for _key, proj in projects.items():
        if proj.get("graph_name") == project:
            return project
    return project


def _open_connection(url: str, ns: str, db_name: str) -> Any:
    """Open a fresh SurrealDB connection."""
    username = os.environ.get("SURREAL_USER", "root")
    password = os.environ.get("SURREAL_PASSWORD", "root")
    logger.info("Connecting to SurrealDB: url=%s ns=%s db=%s", url, ns, db_name)
    return _connect(
        url=url, namespace=ns, database=db_name,
        username=username, password=password,
    )


def _get_reader(project: str | None = None) -> SurrealUnifiedGraphReader:
    """Get a reader, reconnecting if the backend changed.

    Re-evaluates ``_surreal_url()`` on every call so the server
    automatically switches between sidecar (ws://) and embedded
    (surrealkv://) as the desktop app starts and stops.
    """
    global _connection, _current_db, _current_url

    db_name = _resolve_graph_name(project)
    ns = os.environ.get("SURREAL_NS", "lineage")
    url = _surreal_url()

    # Reconnect when the backend URL changed (sidecar came up / went down)
    # or on first call.
    if _connection is None or url != _current_url:
        _connection = _open_connection(url, ns, db_name)
        _current_url = url
        _current_db = db_name
    elif db_name != _current_db:
        _connection.use(ns, db_name)
        _current_db = db_name

    return SurrealUnifiedGraphReader(db=_connection)


# ---------------------------------------------------------------------------
# RunContext bridge — call PydanticAI tool functions from MCP
# ---------------------------------------------------------------------------

# Sentinel lineage object — desktop_graph tools only use unified_reader,
# never the lineage protocol, so this just satisfies the required field.
_FAKE_LINEAGE: Any = type("_FakeLineage", (), {})()
_TEST_MODEL = TestModel()


def _make_ctx(reader: SurrealUnifiedGraphReader) -> RunContext[AgentDeps]:
    """Build a minimal RunContext wrapping the given reader."""
    deps = AgentDeps(
        lineage=_FAKE_LINEAGE,
        thread_id="mcp",
        run_id="mcp-run",
        unified_reader=reader,
        state=AgentState(),
    )
    return RunContext(
        deps=deps,
        model=_TEST_MODEL,
        usage=RunUsage(),
        tool_call_id="mcp",
    )


def _run_async(coro: Any) -> Any:
    """Run an async coroutine synchronously."""
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop and loop.is_running():
        # We're inside an existing event loop (e.g. FastMCP's async server).
        # Create a new thread to run the coroutine.
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            return pool.submit(asyncio.run, coro).result()
    else:
        return asyncio.run(coro)


# ---------------------------------------------------------------------------
# Auto-wrap desktop_graph_toolset → FastMCP tools
# ---------------------------------------------------------------------------


def _register_tools() -> None:
    """Iterate over desktop_graph_toolset and register each as an MCP tool."""
    tools = desktop_graph_toolset.tools  # dict[str, Tool]

    for tool_name, tool_def in tools.items():
        original_func = tool_def.function
        description = tool_def.description or ""

        # Get the original function's parameters (minus ctx)
        sig = inspect.signature(original_func)
        original_params = [
            (name, param)
            for name, param in sig.parameters.items()
            if name != "ctx"
        ]

        # Build the MCP wrapper dynamically
        _make_mcp_wrapper(tool_name, original_func, original_params, description)


def _make_mcp_wrapper(
    tool_name: str,
    original_func: Any,
    original_params: list[tuple[str, inspect.Parameter]],
    description: str,
) -> None:
    """Create and register a single MCP tool that delegates to the PydanticAI tool."""

    # Build a wrapper with an explicit __signature__ so FastMCP can
    # introspect parameter names, types, and defaults for JSON schema
    # generation — no exec required.
    wrapper_parameters: list[inspect.Parameter] = []
    wrapper_annotations: dict[str, Any] = {}

    for name, param in original_params:
        wrapper_parameters.append(
            inspect.Parameter(
                name,
                kind=inspect.Parameter.POSITIONAL_OR_KEYWORD,
                annotation=(
                    param.annotation
                    if param.annotation is not inspect.Parameter.empty
                    else inspect.Parameter.empty
                ),
                default=(
                    param.default
                    if param.default is not inspect.Parameter.empty
                    else inspect.Parameter.empty
                ),
            )
        )
        if param.annotation is not inspect.Parameter.empty:
            wrapper_annotations[name] = param.annotation

    # Add project parameter at the end
    wrapper_parameters.append(
        inspect.Parameter(
            "project",
            kind=inspect.Parameter.POSITIONAL_OR_KEYWORD,
            annotation=str | None,
            default=None,
        )
    )
    wrapper_annotations["project"] = str | None

    wrapper_signature = inspect.Signature(parameters=wrapper_parameters)

    # Capture original_func in closure
    _orig = original_func

    def wrapper_func(**kwargs: Any) -> Any:
        project = kwargs.pop("project", None)
        return _call_tool(_orig, project, **kwargs)

    wrapper_func.__name__ = tool_name
    wrapper_func.__qualname__ = tool_name
    wrapper_func.__doc__ = description
    wrapper_func.__signature__ = wrapper_signature  # type: ignore[attr-defined]
    wrapper_func.__annotations__ = wrapper_annotations

    # Register with FastMCP
    mcp.tool()(wrapper_func)


def _call_tool(original_func: Any, project: str | None, **kwargs: Any) -> Any:
    """Invoke the original async PydanticAI tool function with a bridged RunContext."""
    reader = _get_reader(project)
    ctx = _make_ctx(reader)

    result = _run_async(original_func(ctx, **kwargs))

    # Unwrap ToolError into a plain dict for MCP
    if isinstance(result, ToolError):
        return {"error": result.error_message}

    return result


# ---------------------------------------------------------------------------
# Project discovery tool (MCP-only, not in the PydanticAI toolset)
# ---------------------------------------------------------------------------


@mcp.tool()
def list_projects() -> list[dict]:
    """List all typedef projects available in the local config.

    Shows project names, graph database names, and which is the default.
    Pass the project name to any tool's ``project`` parameter to query it.
    """
    config = _load_config()
    projects = config.get("projects", {})
    default = config.get("default_project")

    return [
        {
            "name": key,
            "graph_name": proj.get("graph_name", key),
            "dbt_path": proj.get("dbt_path"),
            "is_default": key == default,
        }
        for key, proj in projects.items()
    ]


# ---------------------------------------------------------------------------
# Raw SurrealQL escape hatch (MCP-only)
# ---------------------------------------------------------------------------


_READONLY_PREFIXES = {"select", "info", "show", "let", "return"}
_MUTATING_KEYWORDS = {
    "create", "update", "delete", "insert", "upsert",
    "define", "remove", "relate",
}
_SAFE_TABLE_RE = re.compile(r"^[a-zA-Z0-9_]+$")
_STRIP_STRINGS = re.compile(r"'(?:[^'\\]|\\.)*'|\"(?:[^\"\\]|\\.)*\"")
_STRIP_COMMENTS = re.compile(r"/\*.*?\*/|--[^\n]*", re.DOTALL)


def _is_readonly(query: str) -> bool:
    """Return True if *query* contains no mutation keywords.

    Two-layer check: every statement must start with a read-only keyword,
    AND the full query body (after stripping comments) must not contain any
    mutation keyword anywhere, which blocks subquery bypasses like
    ``LET $x = (DELETE FROM process)``.

    String literals are blanked before comment stripping so that ``--`` or
    ``/*`` inside a string cannot trick the comment regex into hiding a
    trailing mutation statement.
    """
    # Blank string literals first so comment markers inside strings are inert
    no_strings = _STRIP_STRINGS.sub("''", query)
    # Then strip comments
    stripped_query = _STRIP_COMMENTS.sub(" ", no_strings)

    for stmt in stripped_query.split(";"):
        stripped = stmt.strip()
        if not stripped:
            continue
        parts = stripped.split()
        first_word = parts[0].lower() if parts else ""
        if first_word not in _READONLY_PREFIXES:
            return False

    # Deep scan: reject if any mutation keyword appears as a word anywhere
    words = set(re.findall(r"[a-zA-Z_]+", stripped_query.lower()))
    if words & _MUTATING_KEYWORDS:
        return False
    return True


@mcp.tool()
def surrealql(query: str, project: str | None = None) -> dict:
    """Run a read-only SurrealQL query against the unified graph.

    Use this for ad-hoc exploration when the structured tools don't cover
    your needs.  Only SELECT, INFO, SHOW, LET, and RETURN statements are
    allowed — mutations are rejected.

    Note: for multi-statement queries, each statement's result is returned
    as a list.  Use ``LET`` + ``RETURN`` to chain intermediate results.

    Examples::

        SELECT count() FROM process GROUP ALL;
        SELECT name, kind, source FROM process WHERE source = 'dbt' LIMIT 10;
        SELECT * FROM process WHERE name CONTAINS 'revenue';
        SELECT ->produces->resource.name FROM process:⟨some_id⟩;
        INFO FOR DB;
    """
    if not _is_readonly(query):
        return {
            "ok": False,
            "error": (
                "Only read-only statements are allowed "
                "(SELECT, INFO, SHOW, LET, RETURN). "
                "Mutations (CREATE, UPDATE, DELETE, INSERT, DEFINE, RELATE, REMOVE) "
                "are not permitted."
            ),
        }

    reader = _get_reader(project)
    db = reader.get_db_connection()
    try:
        # Use db.query() directly (not q()) to preserve dict-shaped results
        # from INFO/SHOW statements that q() would normalise to [].
        result = db.query(query)
        if isinstance(result, list) and len(result) == 1:
            result = result[0]
        return {"ok": True, "results": sanitize(result)}
    except Exception as e:
        return {"ok": False, "error": str(e)}


@mcp.tool()
def describe_kind(
    kind: str,
    source: str | None = None,
    project: str | None = None,
) -> dict:
    """Describe the property shape for a given node kind (and optionally source).

    Samples up to 5 records and returns the union of all ``properties`` keys
    found, along with one example value per key.  Call this before writing
    SurrealQL queries that filter on ``properties.*`` fields so you know what's
    available.

    Examples::

        describe_kind(kind="model", source="dbt")
        describe_kind(kind="measure", source="cube")
        describe_kind(kind="column")
    """
    reader = _get_reader(project)
    db = reader.get_db_connection()

    bind: dict[str, str] = {"kind": kind}
    where = "WHERE kind = $kind"
    if source:
        where += " AND source = $source"
        bind["source"] = source

    rows: list[dict] = []
    for table in VERTEX_TABLES:
        try:
            rows = q(
                db,
                f"SELECT kind, source, properties FROM {table} {where} LIMIT 5;",  # nosec B608 — table from VERTEX_TABLES enum
                **bind,
            )
        except Exception:  # nosec B112 — graceful skip if table missing
            continue
        if rows:
            break

    if not rows:
        return {"error": f"No records found for kind={kind!r}, source={source!r}"}

    key_values: dict[str, list] = {}
    for row in rows:
        props = row.get("properties", {})
        if not isinstance(props, dict):
            continue
        for key, val in props.items():
            key_values.setdefault(key, []).append(val)

    property_fields: dict[str, dict] = {}
    for key, values in key_values.items():
        type_name = type(values[0]).__name__
        str_lengths = [len(str(v)) for v in values]
        avg_len = sum(str_lengths) // len(str_lengths)
        shortest = min(values, key=lambda v: len(str(v)))
        example = str(shortest)
        if len(example) > 120:
            example = example[:120] + "..."

        field_info: dict = {"type": type_name, "example": example}
        if type_name in ("str", "list", "dict"):
            field_info["avg_length"] = avg_len

        property_fields[key] = field_info

    # When source is not specified, sampled rows may span multiple sources
    sources_seen = sorted({r.get("source") for r in rows if r.get("source")})
    actual_source = source if source else (sources_seen[0] if len(sources_seen) == 1 else None)

    result: dict[str, Any] = {
        "kind": kind,
        "source": actual_source,
        "record_count_sampled": len(rows),
        "property_fields": property_fields,
    }
    if not source and len(sources_seen) > 1:
        result["sources_in_sample"] = sources_seen
    return result


@mcp.tool()
def schema_overview(project: str | None = None) -> dict:
    """Get an overview of the unified graph schema and current data statistics.

    Returns vertex/edge table definitions, field names, edge constraints,
    record counts per table, and load metadata.  Useful for understanding
    what's in the graph before writing SurrealQL queries.
    """
    reader = _get_reader(project)
    db = reader.get_db_connection()

    # Discover all tables from the live database
    known_tables = set(VERTEX_TABLES + EDGE_TABLES)
    other_tables: list[str] = []
    try:
        result = db.query("INFO FOR DB;")
        # SDK may return dict directly or list-wrapped
        info = result[0] if isinstance(result, list) else result
        if isinstance(info, dict):
            tables_map = info.get("tables", info.get("tb", {}))
            if isinstance(tables_map, dict):
                all_tables = list(tables_map.keys())
            else:
                all_tables = []
        else:
            all_tables = []
        other_tables = sorted(
            t for t in all_tables
            if t not in known_tables
            and not t.startswith("_")
            and _SAFE_TABLE_RE.match(t)
        )
    except Exception:
        other_tables = []

    # Record counts for all discovered tables
    counts: dict[str, int] = {}
    for table in VERTEX_TABLES + EDGE_TABLES + other_tables:
        try:
            rows = q(db, f"SELECT count() FROM {table} GROUP ALL;")  # nosec B608 — table from schema enums or validated INFO FOR DB
            counts[table] = rows[0].get("count", 0) if rows else 0
        except Exception:
            counts[table] = 0

    # Load metadata
    meta = None
    try:
        meta_rows = q(db, "SELECT * FROM _meta LIMIT 1;")
        if meta_rows:
            meta = sanitize(meta_rows[0])
    except Exception:  # nosec B110 — meta may not exist
        pass

    # Edge constraint descriptions
    constraints = {
        edge: desc for edge, (desc, _, _) in EDGE_CONSTRAINTS.items()
    }

    # Kind+source breakdown so agents know what describe_kind combos exist
    kind_source_counts: list[dict] = []
    for table in VERTEX_TABLES:
        try:
            ks_rows = q(db, f"SELECT kind, source, count() FROM {table} GROUP BY kind, source;")  # nosec B608 — table from VERTEX_TABLES enum
            for r in ks_rows:
                kind_source_counts.append(sanitize(r))
        except Exception:  # nosec B110 — graceful skip
            pass

    return {
        "vertex_tables": VERTEX_TABLES,
        "edge_tables": EDGE_TABLES,
        "other_tables": other_tables,
        "shared_node_fields": SHARED_NODE_FIELD_NAMES,
        "edge_constraints": constraints,
        "record_counts": counts,
        "kind_source_counts": kind_source_counts,
        "meta": meta,
    }


# Register all desktop_graph tools as MCP tools at import time
_register_tools()


def main():
    mcp.run()


if __name__ == "__main__":
    main()
