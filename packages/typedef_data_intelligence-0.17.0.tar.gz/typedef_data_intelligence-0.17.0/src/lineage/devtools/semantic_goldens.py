"""Backwards-compat shim — canonical module is ingest.devtools.semantic_goldens."""

from ingest.devtools.semantic_goldens import (  # noqa: F401
    EXPECTED_DIR,
    FIXTURES_DIR,
    expected_path,
    fixture_dialect,
    fixture_schema,
    list_sql_fixtures,
    normalize_semantic_payload,
    read_expected,
    read_fixture_meta,
    read_sql_fixture,
    write_expected,
)
