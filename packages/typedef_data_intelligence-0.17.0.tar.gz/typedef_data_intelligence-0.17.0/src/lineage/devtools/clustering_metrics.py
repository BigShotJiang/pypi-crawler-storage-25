"""Clustering quality metrics computation.

This module provides pure metric computation functions for evaluating clustering
quality. Metrics are divided into three categories:

1. Graph-Based (Internal) Metrics:
   - modularity: Standard community detection score
   - coverage: Fraction of edges within clusters
   - avg_cluster_size: Mean models per cluster
   - singleton_count: Clusters with 1 model
   - edge_weight_density: Total edge weight / model count per cluster

2. Semantic Coherence Metrics:
   - domain_purity: % clusters with single dominant domain
   - role_separation: Fact/dimension mixing ratio

3. Stability Metrics (partition comparison):
   - NMI: Normalized Mutual Information
   - ARI: Adjusted Rand Index
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field
from math import log2
from typing import Dict, List

import networkx as nx
from core.models.clustering import ModelEnrichmentData


@dataclass
class ClusteringMetrics:
    """Container for all computed clustering metrics."""

    # Graph-based metrics
    modularity: float = 0.0
    coverage: float = 0.0
    avg_cluster_size: float = 0.0
    singleton_count: int = 0
    cluster_count: int = 0
    total_model_count: int = 0
    edge_count: int = 0
    avg_edge_weight_density: float = 0.0

    # Semantic coherence metrics
    domain_purity: float = 0.0
    role_separation_score: float = 0.0
    avg_dominant_domain_share: float = 0.0

    # Per-cluster details (optional, for verbose output)
    cluster_details: List[Dict] = field(default_factory=list)


@dataclass
class PartitionComparisonMetrics:
    """Container for partition comparison metrics (stability analysis)."""

    nmi: float = 0.0  # Normalized Mutual Information
    ari: float = 0.0  # Adjusted Rand Index
    jaccard: float = 0.0  # Jaccard similarity between cluster assignments


def compute_modularity(G: nx.Graph, clusters: Dict[int, List[str]]) -> float:
    """Compute modularity score for a partition.

    Modularity measures how well the graph is divided into communities
    compared to a random graph with the same degree sequence.

    Args:
        G: NetworkX graph with models as nodes
        clusters: Dictionary mapping cluster_id -> list of model IDs

    Returns:
        Modularity score in range [-0.5, 1.0]. Higher is better.
    """
    if G.number_of_edges() == 0 or not clusters:
        return 0.0

    # Convert clusters dict to list of sets for NetworkX
    communities = [set(members) for members in clusters.values() if members]

    # Filter communities to only include nodes that exist in G
    communities = [
        {n for n in c if n in G} for c in communities
    ]
    communities = [c for c in communities if c]

    if not communities:
        return 0.0

    try:
        return nx.community.modularity(G, communities, weight="weight")
    except Exception:
        # Fallback if modularity computation fails
        return 0.0


def compute_coverage(G: nx.Graph, clusters: Dict[int, List[str]]) -> float:
    """Compute coverage - fraction of edges within clusters.

    Coverage measures what proportion of the graph's edges fall within
    communities, as opposed to between communities.

    Args:
        G: NetworkX graph with models as nodes
        clusters: Dictionary mapping cluster_id -> list of model IDs

    Returns:
        Coverage ratio in range [0.0, 1.0]. Higher means more intra-cluster edges.
    """
    if G.number_of_edges() == 0 or not clusters:
        return 0.0

    # Build node -> cluster mapping
    node_to_cluster = {}
    for cluster_id, members in clusters.items():
        for member in members:
            node_to_cluster[member] = cluster_id

    # Count intra-cluster edges (weighted)
    total_weight = 0.0
    intra_weight = 0.0

    for u, v, data in G.edges(data=True):
        weight = data.get("weight", 1.0)
        total_weight += weight
        if node_to_cluster.get(u) == node_to_cluster.get(v):
            intra_weight += weight

    if total_weight == 0:
        return 0.0

    return intra_weight / total_weight


def compute_domain_purity(
    clusters: Dict[int, List[str]],
    enrichment: Dict[str, ModelEnrichmentData],
) -> tuple[float, float]:
    """Compute domain purity metrics.

    Domain purity measures how coherent clusters are in terms of business domains.
    A pure cluster has all models from the same domain.

    Args:
        clusters: Dictionary mapping cluster_id -> list of model IDs
        enrichment: Dictionary mapping model_id -> enrichment data

    Returns:
        Tuple of (domain_purity, avg_dominant_share):
        - domain_purity: Fraction of clusters with >50% models from dominant domain
        - avg_dominant_share: Average share of dominant domain across clusters
    """
    if not clusters or not enrichment:
        return 0.0, 0.0

    pure_count = 0
    dominant_shares = []

    for _cluster_id, members in clusters.items():
        if not members:
            continue

        # Count domains in this cluster
        domain_counts: Counter[str] = Counter()
        models_with_domains = 0
        for model_id in members:
            model_enrich = enrichment.get(model_id)
            if model_enrich and model_enrich.domains:
                for domain in model_enrich.domains:
                    if domain:  # Skip empty strings
                        domain_counts[domain] += 1
                models_with_domains += 1

        if not domain_counts:
            # Cluster has no domain info - treat as neutral
            continue

        # Dominant domain share
        total_domain_assignments = sum(domain_counts.values())
        dominant_domain, dominant_count = domain_counts.most_common(1)[0]
        dominant_share = dominant_count / total_domain_assignments

        dominant_shares.append(dominant_share)

        # Consider pure if >50% from dominant domain
        if dominant_share > 0.5:
            pure_count += 1

    if not dominant_shares:
        return 0.0, 0.0

    domain_purity = pure_count / len(dominant_shares)
    avg_dominant_share = sum(dominant_shares) / len(dominant_shares)

    return domain_purity, avg_dominant_share


def compute_role_separation(
    clusters: Dict[int, List[str]],
    enrichment: Dict[str, ModelEnrichmentData],
) -> float:
    """Compute role separation score.

    Role separation measures how well clusters separate fact and dimension models.
    Good clustering should group related facts with supporting dimensions.

    Args:
        clusters: Dictionary mapping cluster_id -> list of model IDs
        enrichment: Dictionary mapping model_id -> enrichment data

    Returns:
        Score in [0, 1]. Higher means clearer fact/dimension separation patterns.
        A score of 1.0 means each cluster is either all facts or has 1 fact + N dims.
    """
    if not clusters or not enrichment:
        return 0.0

    cluster_scores = []

    for _cluster_id, members in clusters.items():
        if not members:
            continue

        # Count roles
        fact_count = 0
        dim_count = 0
        mixed_count = 0

        for model_id in members:
            model_enrich = enrichment.get(model_id)
            if not model_enrich:
                continue
            if model_enrich.role == "fact":
                fact_count += 1
            elif model_enrich.role == "dimension":
                dim_count += 1
            else:  # mixed
                mixed_count += 1

        total = fact_count + dim_count + mixed_count
        if total == 0:
            continue

        # Ideal patterns:
        # 1. Star schema: 1 fact + N dimensions (score high)
        # 2. All dimensions (pure dimension cluster, score high)
        # 3. Multiple facts with dimensions (score medium)
        # 4. All facts (unusual but valid, score medium)

        if total == 1:
            # Single-model cluster
            cluster_scores.append(0.5)  # Neutral
        elif fact_count == 0:
            # All dimensions - valid dimension mart
            cluster_scores.append(0.8)
        elif fact_count == 1 and dim_count > 0:
            # Ideal star schema pattern
            cluster_scores.append(1.0)
        elif fact_count == 1 and dim_count == 0:
            # Single fact with mixed/unknown
            cluster_scores.append(0.6)
        elif fact_count > 1 and dim_count >= fact_count:
            # Multiple facts with shared dimensions
            cluster_scores.append(0.7)
        else:
            # Multiple facts without enough dimensions - suboptimal
            cluster_scores.append(0.4)

    if not cluster_scores:
        return 0.0

    return sum(cluster_scores) / len(cluster_scores)


def compute_edge_weight_density(
    G: nx.Graph,
    clusters: Dict[int, List[str]],
) -> float:
    """Compute average edge weight density across clusters.

    Edge weight density = total internal edge weight / model count per cluster.
    Higher density indicates stronger internal cohesion.

    Args:
        G: NetworkX graph with models as nodes
        clusters: Dictionary mapping cluster_id -> list of model IDs

    Returns:
        Average edge weight density across all clusters.
    """
    if not clusters:
        return 0.0

    densities = []

    for _cluster_id, members in clusters.items():
        if not members:
            continue

        # Create subgraph for this cluster
        valid_members = [m for m in members if m in G]
        if not valid_members:
            continue

        subgraph = G.subgraph(valid_members)
        total_weight = subgraph.size(weight="weight")
        density = total_weight / len(valid_members) if valid_members else 0.0
        densities.append(density)

    if not densities:
        return 0.0

    return sum(densities) / len(densities)


def compute_all_metrics(
    G: nx.Graph,
    clusters: Dict[int, List[str]],
    enrichment: Dict[str, ModelEnrichmentData],
    include_details: bool = False,
) -> ClusteringMetrics:
    """Compute all clustering metrics.

    Args:
        G: NetworkX graph with models as nodes
        clusters: Dictionary mapping cluster_id -> list of model IDs
        enrichment: Dictionary mapping model_id -> enrichment data
        include_details: Include per-cluster details in result

    Returns:
        ClusteringMetrics containing all computed metrics
    """
    # Graph-based metrics
    modularity = compute_modularity(G, clusters)
    coverage = compute_coverage(G, clusters)

    # Cluster statistics
    cluster_sizes = [len(members) for members in clusters.values()]
    singleton_count = sum(1 for s in cluster_sizes if s == 1)
    avg_cluster_size = sum(cluster_sizes) / len(cluster_sizes) if cluster_sizes else 0.0

    # Semantic metrics
    domain_purity, avg_dominant_share = compute_domain_purity(clusters, enrichment)
    role_separation = compute_role_separation(clusters, enrichment)

    # Edge weight density
    avg_density = compute_edge_weight_density(G, clusters)

    # Count total models
    all_models = set()
    for members in clusters.values():
        all_models.update(members)

    metrics = ClusteringMetrics(
        modularity=modularity,
        coverage=coverage,
        avg_cluster_size=avg_cluster_size,
        singleton_count=singleton_count,
        cluster_count=len(clusters),
        total_model_count=len(all_models),
        edge_count=G.number_of_edges(),
        avg_edge_weight_density=avg_density,
        domain_purity=domain_purity,
        role_separation_score=role_separation,
        avg_dominant_domain_share=avg_dominant_share,
    )

    if include_details:
        metrics.cluster_details = _compute_cluster_details(G, clusters, enrichment)

    return metrics


def _compute_cluster_details(
    G: nx.Graph,
    clusters: Dict[int, List[str]],
    enrichment: Dict[str, ModelEnrichmentData],
) -> List[Dict]:
    """Compute per-cluster detail metrics."""
    details = []

    for cluster_id, members in sorted(clusters.items()):
        if not members:
            continue

        # Role counts
        roles = Counter()
        domains: Counter[str] = Counter()
        has_pii = False

        for model_id in members:
            model_enrich = enrichment.get(model_id)
            if model_enrich:
                roles[model_enrich.role] += 1
                if model_enrich.domains:
                    domains.update([d for d in model_enrich.domains if d])
                if model_enrich.has_pii:
                    has_pii = True

        # Subgraph metrics
        valid_members = [m for m in members if m in G]
        if valid_members:
            subgraph = G.subgraph(valid_members)
            internal_weight = subgraph.size(weight="weight")
            internal_edges = subgraph.number_of_edges()
        else:
            internal_weight = 0.0
            internal_edges = 0

        dominant_domain = domains.most_common(1)[0][0] if domains else None
        dominant_share = domains.most_common(1)[0][1] / sum(domains.values()) if domains else 0.0

        details.append({
            "cluster_id": cluster_id,
            "model_count": len(members),
            "fact_count": roles.get("fact", 0),
            "dimension_count": roles.get("dimension", 0),
            "mixed_count": roles.get("mixed", 0),
            "internal_edges": internal_edges,
            "internal_weight": round(internal_weight, 2),
            "weight_density": round(internal_weight / len(members) if members else 0, 2),
            "dominant_domain": dominant_domain,
            "dominant_domain_share": round(dominant_share, 2),
            "has_pii": has_pii,
        })

    return details


def compare_partitions(
    clusters1: Dict[int, List[str]],
    clusters2: Dict[int, List[str]],
) -> PartitionComparisonMetrics:
    """Compare two cluster partitions for stability analysis.

    Uses Normalized Mutual Information (NMI) and Adjusted Rand Index (ARI)
    to measure how similar two clusterings are.

    Args:
        clusters1: First partition (baseline)
        clusters2: Second partition (comparison)

    Returns:
        PartitionComparisonMetrics with NMI, ARI, and Jaccard scores
    """
    # Build node -> cluster mappings
    labels1 = {}
    for cluster_id, members in clusters1.items():
        for member in members:
            labels1[member] = cluster_id

    labels2 = {}
    for cluster_id, members in clusters2.items():
        for member in members:
            labels2[member] = cluster_id

    # Find common nodes
    common_nodes = sorted(set(labels1.keys()) & set(labels2.keys()))

    if len(common_nodes) < 2:
        return PartitionComparisonMetrics()

    # Create aligned label arrays
    y1 = [labels1[n] for n in common_nodes]
    y2 = [labels2[n] for n in common_nodes]

    # Compute metrics
    nmi = _normalized_mutual_info(y1, y2)
    ari = _adjusted_rand_index(y1, y2)
    jaccard = _jaccard_similarity(y1, y2)

    return PartitionComparisonMetrics(nmi=nmi, ari=ari, jaccard=jaccard)


def _normalized_mutual_info(labels1: List[int], labels2: List[int]) -> float:
    """Compute Normalized Mutual Information between two labelings."""
    n = len(labels1)
    if n == 0:
        return 0.0

    # Count cluster sizes
    clusters1: Dict[int, int] = Counter(labels1)
    clusters2: Dict[int, int] = Counter(labels2)

    # Count co-occurrences
    contingency: Dict[tuple, int] = Counter(zip(labels1, labels2, strict=False))

    # Compute entropies
    h1 = -sum((c / n) * log2(c / n) for c in clusters1.values() if c > 0)
    h2 = -sum((c / n) * log2(c / n) for c in clusters2.values() if c > 0)

    if h1 == 0 or h2 == 0:
        return 1.0 if h1 == h2 else 0.0

    # Compute mutual information
    mi = 0.0
    for (c1, c2), count in contingency.items():
        if count > 0:
            p_joint = count / n
            p1 = clusters1[c1] / n
            p2 = clusters2[c2] / n
            mi += p_joint * log2(p_joint / (p1 * p2))

    # Normalize by average entropy
    nmi = (2 * mi) / (h1 + h2)
    return max(0.0, min(1.0, nmi))


def _adjusted_rand_index(labels1: List[int], labels2: List[int]) -> float:
    """Compute Adjusted Rand Index between two labelings."""
    n = len(labels1)
    if n < 2:
        return 0.0

    # Build contingency table
    contingency: Dict[tuple, int] = Counter(zip(labels1, labels2, strict=False))

    # Compute sums
    a = Counter(labels1)
    b = Counter(labels2)

    # Sum of combinatorial terms
    sum_comb_c = sum(c * (c - 1) // 2 for c in contingency.values())
    sum_comb_a = sum(c * (c - 1) // 2 for c in a.values())
    sum_comb_b = sum(c * (c - 1) // 2 for c in b.values())
    sum_comb_n = n * (n - 1) // 2

    if sum_comb_n == 0:
        return 0.0

    # Expected index
    expected = (sum_comb_a * sum_comb_b) / sum_comb_n
    max_index = (sum_comb_a + sum_comb_b) / 2

    if max_index == expected:
        return 1.0

    ari = (sum_comb_c - expected) / (max_index - expected)
    return max(-1.0, min(1.0, ari))


def _jaccard_similarity(labels1: List[int], labels2: List[int]) -> float:
    """Compute Jaccard similarity of cluster assignments."""
    n = len(labels1)
    if n < 2:
        return 0.0

    # Count pairs that are together/apart in each clustering
    both_same = 0
    either_same = 0

    for i in range(n):
        for j in range(i + 1, n):
            same1 = labels1[i] == labels1[j]
            same2 = labels2[i] == labels2[j]

            if same1 and same2:
                both_same += 1
            if same1 or same2:
                either_same += 1

    if either_same == 0:
        return 1.0

    return both_same / either_same


__all__ = [
    "ClusteringMetrics",
    "PartitionComparisonMetrics",
    "compute_modularity",
    "compute_coverage",
    "compute_domain_purity",
    "compute_role_separation",
    "compute_edge_weight_density",
    "compute_all_metrics",
    "compare_partitions",
]
