#!/usr/bin/env python3
"""Delete all reports from the connected Salesforce org.

Usage:
    # Dry run — list reports that would be deleted
    python scripts/delete_salesforce_reports.py --dry-run

    # Delete all reports
    python scripts/delete_salesforce_reports.py

    # Delete only reports matching a name prefix
    python scripts/delete_salesforce_reports.py --prefix "TD -"
"""
from __future__ import annotations

import argparse
import os
import sys
from typing import Any


def _build_sf_connection(args: argparse.Namespace) -> Any:
    """Build a ``simple_salesforce.Salesforce`` connection from CLI args."""
    from simple_salesforce import Salesforce

    if all(getattr(args, a, None) for a in ("instance_url", "username", "password", "security_token")):
        return Salesforce(
            instance_url=args.instance_url,
            username=args.username,
            password=args.password,
            security_token=args.security_token,
        )

    if args.client_id:
        login_url = getattr(args, "login_url", "https://login.salesforce.com")
        org_key = getattr(args, "org_key", "default")

        try:
            from ingest.static_loaders.salesforce.auth.oauth_pkce import (
                OAuthPKCEAuth,
            )
            auth = OAuthPKCEAuth(
                client_id=args.client_id,
                login_url=login_url,
                org_key=org_key,
            )
            creds = auth.authenticate()
            return Salesforce(
                instance_url=creds.instance_url,
                session_id=creds.access_token,
            )
        except Exception:
            pass  # PKCE unavailable or failed — fall through to device flow

        try:
            from ingest.static_loaders.salesforce.auth.device_flow import (
                OAuthDeviceFlowAuth,
            )
            auth = OAuthDeviceFlowAuth(
                client_id=args.client_id,
                login_url=login_url,
                org_key=org_key,
            )
            creds = auth.authenticate()
            return Salesforce(
                instance_url=creds.instance_url,
                session_id=creds.access_token,
            )
        except Exception as exc:
            print(f"Error: Could not authenticate with client-id: {exc}", file=sys.stderr)
            sys.exit(1)

    print(
        "Error: Provide either --client-id (with sf-login tokens) or "
        "--instance-url/--username/--password/--security-token.",
        file=sys.stderr,
    )
    sys.exit(1)


def _list_reports(sf: Any) -> list[dict[str, str]]:
    """List all reports in the org via SOQL."""
    result = sf.query_all("SELECT Id, Name, DeveloperName, FolderName FROM Report ORDER BY Name")
    return [
        {
            "id": r["Id"],
            "name": r["Name"],
            "developer_name": r.get("DeveloperName", ""),
            "folder": r.get("FolderName", ""),
        }
        for r in result.get("records", [])
    ]


def parse_args() -> argparse.Namespace:
    """Parse CLI arguments."""
    parser = argparse.ArgumentParser(
        description="Delete Salesforce reports",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="List reports without deleting",
    )
    parser.add_argument(
        "--prefix",
        default=None,
        help="Only delete reports whose name starts with this prefix",
    )

    auth = parser.add_argument_group("authentication")
    auth.add_argument("--client-id", default=os.environ.get("SF_CLIENT_ID"))
    auth.add_argument("--instance-url", default=os.environ.get("SF_INSTANCE_URL"))
    auth.add_argument("--username", default=os.environ.get("SF_USERNAME"))
    auth.add_argument("--password", default=os.environ.get("SF_PASSWORD"))
    auth.add_argument("--security-token", default=os.environ.get("SF_SECURITY_TOKEN"))
    auth.add_argument("--login-url", default=os.environ.get("SF_LOGIN_URL", "https://login.salesforce.com"))
    auth.add_argument("--org-key", default="default")

    return parser.parse_args()


def main() -> None:
    """Delete Salesforce reports, optionally filtered by name prefix."""
    args = parse_args()

    print("Connecting to Salesforce ...")
    sf = _build_sf_connection(args)
    print(f"Connected to {sf.sf_instance}")

    print("\nFetching reports ...")
    reports = _list_reports(sf)
    print(f"Found {len(reports)} report(s)")

    if args.prefix:
        reports = [r for r in reports if r["name"].startswith(args.prefix)]
        print(f"  {len(reports)} match prefix '{args.prefix}'")

    if not reports:
        print("\nNothing to delete.")
        return

    print()
    for r in reports:
        print(f"  {r['id']}  {r['name']}  (folder: {r['folder']})")

    if args.dry_run:
        print(f"\n[DRY RUN] Would delete {len(reports)} report(s).")
        return

    deleted = 0
    failed = 0
    for r in reports:
        try:
            sf.restful(f"analytics/reports/{r['id']}", method="DELETE")
            print(f"  [DELETED] {r['name']}")
            deleted += 1
        except Exception as exc:
            print(f"  [FAILED]  {r['name']}: {exc}")
            failed += 1

    print(f"\nDone. Deleted: {deleted}, Failed: {failed}")


if __name__ == "__main__":
    main()
