#!/usr/bin/env python3
"""Create sample Salesforce reports inspired by the mattermost-looker project.

Creates 3 summary reports with groupings and rollup summaries using the
Salesforce Analytics REST API:

1. **Opportunity Pipeline by Stage** — Opportunities grouped by Stage and
   Forecast Category with SUM(Amount), COUNT, AVG(Probability).

2. **Account Overview by Industry** — Accounts grouped by Industry with
   SUM(AnnualRevenue), COUNT.

3. **Opportunities with Products** — Cross-object report (Opportunity +
   Line Items) grouped by Opportunity Type with SUM(TotalPrice),
   SUM(Quantity).

Usage:
    # List available report types in the org
    python scripts/create_salesforce_reports.py --list-types

    # Describe available columns for a report type
    python scripts/create_salesforce_reports.py --describe Opportunity

    # Dry run — resolve columns and print what would be created
    python scripts/create_salesforce_reports.py --dry-run

    # Create reports
    python scripts/create_salesforce_reports.py
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from typing import Any

# ---------------------------------------------------------------------------
# Salesforce connection (same pattern as populate_salesforce_schema.py)
# ---------------------------------------------------------------------------

def _build_sf_connection(args: argparse.Namespace) -> Any:
    """Build a ``simple_salesforce.Salesforce`` connection from CLI args."""
    from simple_salesforce import Salesforce

    if all(getattr(args, a, None) for a in ("instance_url", "username", "password", "security_token")):
        return Salesforce(
            instance_url=args.instance_url,
            username=args.username,
            password=args.password,
            security_token=args.security_token,
        )

    if args.client_id:
        login_url = getattr(args, "login_url", "https://login.salesforce.com")
        org_key = getattr(args, "org_key", "default")

        try:
            from ingest.static_loaders.salesforce.auth.oauth_pkce import (
                OAuthPKCEAuth,
            )
            auth = OAuthPKCEAuth(
                client_id=args.client_id,
                login_url=login_url,
                org_key=org_key,
            )
            creds = auth.authenticate()
            return Salesforce(
                instance_url=creds.instance_url,
                session_id=creds.access_token,
            )
        except Exception:
            pass  # PKCE unavailable or failed — fall through to device flow

        try:
            from ingest.static_loaders.salesforce.auth.device_flow import (
                OAuthDeviceFlowAuth,
            )
            auth = OAuthDeviceFlowAuth(
                client_id=args.client_id,
                login_url=login_url,
                org_key=org_key,
            )
            creds = auth.authenticate()
            return Salesforce(
                instance_url=creds.instance_url,
                session_id=creds.access_token,
            )
        except Exception as exc:
            print(f"Error: Could not authenticate with client-id: {exc}", file=sys.stderr)
            sys.exit(1)

    print(
        "Error: Provide either --client-id (with sf-login tokens) or "
        "--instance-url/--username/--password/--security-token.",
        file=sys.stderr,
    )
    sys.exit(1)


# ---------------------------------------------------------------------------
# Report type discovery
# ---------------------------------------------------------------------------

def _list_report_types(sf: Any) -> list[dict[str, Any]]:
    """List all available report types, flattened from the grouped response.

    The Analytics API returns categories, each with a nested ``reportTypes``
    list.  We flatten them into a single list with ``type`` as the key.
    """
    url = f"{sf.base_url}analytics/reportTypes"
    response = sf._call_salesforce("GET", url)
    categories = response.json()

    flat: list[dict[str, Any]] = []
    for category in categories:
        for rt in category.get("reportTypes", []):
            rt["_category"] = category.get("label", "")
            flat.append(rt)
    return flat


def _describe_report_type(sf: Any, report_type: str) -> dict[str, Any]:
    """Describe a report type to get available columns.

    Uses the describe URL from the report type listing, which is
    ``/services/data/vXX.0/analytics/report-types/{type}`` (note the hyphen).
    """
    # The describeUrl from the listing is an absolute path like
    # /services/data/v59.0/analytics/report-types/Opportunity
    # We can use it directly with sf._call_salesforce by building the full URL.
    url = f"https://{sf.sf_instance}/services/data/v{sf.sf_version}/analytics/report-types/{report_type}"
    response = sf._call_salesforce("GET", url)
    return response.json()


def _find_report_type(report_types: list[dict[str, Any]], search: str) -> str | None:
    """Find a report type by searching ``type`` or ``label`` fields."""
    term = search.lower()
    # Exact type match
    for rt in report_types:
        if rt.get("type", "").lower() == term:
            return rt["type"]
    # Exact label match
    for rt in report_types:
        if rt.get("label", "").lower() == term:
            return rt["type"]
    # Substring on label
    for rt in report_types:
        if term in rt.get("label", "").lower():
            return rt["type"]
    # Substring on type
    for rt in report_types:
        if term in rt.get("type", "").lower():
            return rt["type"]
    return None


# ---------------------------------------------------------------------------
# Column resolution
# ---------------------------------------------------------------------------

def _extract_columns(desc: dict[str, Any]) -> dict[str, Any]:
    """Extract all available columns from a report type describe response."""
    all_columns: dict[str, Any] = {}

    for top_key in ("reportTypeMetadata", ""):
        container = desc.get(top_key, desc) if top_key else desc
        if not isinstance(container, dict):
            continue
        for section in ("detailColumnInfo", "groupingColumnInfo"):
            data = container.get(section, {})
            if isinstance(data, dict):
                all_columns.update(data)

    ext = desc.get("reportExtendedMetadata", {})
    if isinstance(ext, dict):
        for section in ("detailColumnInfo", "groupingColumnInfo", "aggregateColumnInfo"):
            data = ext.get(section, {})
            if isinstance(data, dict):
                all_columns.update(data)

    # Flat list format
    for col in desc.get("columns", []):
        if isinstance(col, dict):
            key = col.get("apiName", col.get("name", ""))
            if key:
                all_columns[key] = col

    # Fields dict format
    fields = desc.get("fields", {})
    if isinstance(fields, dict):
        all_columns.update(fields)

    return all_columns


def _find_column(columns: dict[str, Any], search_term: str) -> tuple[str, dict[str, Any]] | None:
    """Find a column by label or API name (case-insensitive)."""
    term = search_term.lower()

    # Exact label
    for name, info in columns.items():
        if isinstance(info, dict) and info.get("label", "").lower() == term:
            return name, info
    # Exact API name
    for name, info in columns.items():
        if name.lower() == term:
            return name, info
    # Substring label
    for name, info in columns.items():
        if isinstance(info, dict) and term in info.get("label", "").lower():
            return name, info
    # Substring API name
    for name, info in columns.items():
        if term in name.lower():
            return name, info
    return None


# ---------------------------------------------------------------------------
# Report specs
# ---------------------------------------------------------------------------

REPORT_SPECS: list[dict[str, Any]] = [
    {
        "name": "TD - Opportunity Pipeline by Stage",
        "description": (
            "Summary of open pipeline grouped by Stage and Forecast Category. "
            "Source: mattermost-looker/views/orgm/opportunity.view.lkml"
        ),
        "report_type_search": "Opportunity",
        "format": "SUMMARY",
        "wanted_columns": [
            "Opportunity Name",
            "Account Name",
            "Amount",
            "Probability",
            "Close Date",
            "Type",
        ],
        "grouping_labels": ["Stage", "Lead Source"],
        "aggregate_specs": [
            ("Amount", "s"),       # SUM
            ("Probability", "a"),  # AVG
        ],
        "filters": [],
    },
    {
        "name": "TD - Account Overview by Industry",
        "description": (
            "Accounts grouped by Industry with revenue rollups. "
            "Source: mattermost-looker/views/orgm/account.view.lkml"
        ),
        "report_type_search": "AccountList",
        "format": "SUMMARY",
        "wanted_columns": [
            "Account Name",
            "Account Owner",
            "Rating",
            "Billing State/Province",
            "Last Activity",
        ],
        "grouping_labels": ["Type"],
        "aggregate_specs": [],
        "filters": [],
    },
    {
        "name": "TD - Opportunities with Products",
        "description": (
            "Cross-object report: Opportunities joined to Line Items, grouped "
            "by Opportunity Type. "
            "Source: mattermost-looker/views/orgm/opportunitylineitem.view.lkml"
        ),
        "report_type_search": "OpportunityProduct",
        "format": "SUMMARY",
        "wanted_columns": [
            "Opportunity Name",
            "Account Name",
            "Stage",
            "Close Date",
            "Product Name",
            "Quantity",
            "Total Price",
        ],
        "grouping_labels": ["Type"],
        "aggregate_specs": [
            ("Total Price", "s"),
            ("Quantity", "s"),
        ],
        "filters": [],
    },
]


# ---------------------------------------------------------------------------
# Report building and creation
# ---------------------------------------------------------------------------

def _build_report_metadata(
    sf: Any,
    spec: dict[str, Any],
    report_types: list[dict[str, Any]],
) -> dict[str, Any] | None:
    """Build report metadata by resolving spec against the org."""
    search = spec["report_type_search"]
    print(f"\n  Looking up report type: '{search}'")

    rt_type = _find_report_type(report_types, search)
    if not rt_type:
        print(f"    -> No report type found matching '{search}'")
        return None

    print(f"    -> Resolved to: {rt_type}")

    # Describe the report type to get available columns
    print(f"  Describing report type: {rt_type}")
    try:
        desc = _describe_report_type(sf, rt_type)
    except Exception as exc:
        print(f"    -> Could not describe: {exc}")
        return None

    print(f"    -> Response keys: {list(desc.keys()) if isinstance(desc, dict) else type(desc)}")

    all_columns = _extract_columns(desc)
    print(f"    Available columns: {len(all_columns)}")

    if not all_columns:
        print("    -> No columns found. Dumping first 2000 chars of response:")
        print(f"       {json.dumps(desc, indent=2, default=str)[:2000]}")
        return None

    # Resolve detail columns
    detail_cols: list[str] = []
    for want in spec["wanted_columns"]:
        match = _find_column(all_columns, want)
        if match:
            col_name, info = match
            detail_cols.append(col_name)
            label = info.get("label", "?") if isinstance(info, dict) else "?"
            print(f"    [OK] '{want}' -> {col_name} ({label})")
        else:
            print(f"    [SKIP] '{want}' not found")

    if not detail_cols:
        print("    -> No columns resolved, skipping report")
        return None

    # Resolve groupings
    groupings: list[dict[str, str]] = []
    for label in spec["grouping_labels"]:
        match = _find_column(all_columns, label)
        if match:
            col_name, _ = match
            groupings.append({
                "name": col_name,
                "sortOrder": "Asc",
                "dateGranularity": "NONE",
            })
            print(f"    [OK] grouping '{label}' -> {col_name}")
        else:
            print(f"    [SKIP] grouping '{label}' not found")

    # Resolve aggregates
    aggregates: list[str] = ["RowCount"]
    for col_label, agg_prefix in spec["aggregate_specs"]:
        match = _find_column(all_columns, col_label)
        if match:
            col_name, _ = match
            aggregates.append(f"{agg_prefix}!{col_name}")
            print(f"    [OK] aggregate {agg_prefix}!{col_name}")

    # Resolve filters
    report_filters: list[dict[str, str]] = []
    for filt in spec.get("filters", []):
        match = _find_column(all_columns, filt["label"])
        if match:
            col_name, _ = match
            report_filters.append({
                "column": col_name,
                "operator": filt["operator"],
                "value": filt["value"],
            })

    return {
        "reportMetadata": {
            "name": spec["name"],
            "description": spec["description"],
            "reportFormat": spec["format"],
            "reportType": {"type": rt_type},
            "detailColumns": detail_cols,
            "groupingsDown": groupings,
            "aggregates": aggregates,
            "reportFilters": report_filters,
        }
    }


def _create_report(sf: Any, report_def: dict[str, Any]) -> dict[str, Any] | None:
    """Create a report via the Analytics API."""
    name = report_def["reportMetadata"]["name"]

    print(f"\n  Creating report: {name}")
    try:
        url = f"{sf.base_url}analytics/reports"
        response = sf._call_salesforce("POST", url, json=report_def)
        result = response.json()
        report_id = result.get("reportMetadata", {}).get("id")
        print(f"    -> Created: {report_id}")

        if report_id:
            try:
                save_url = f"{sf.base_url}analytics/reports/{report_id}"
                sf._call_salesforce(
                    "PATCH", save_url,
                    json={"reportMetadata": {"name": name}},
                )
                print("    -> Saved")
            except Exception:
                print("    -> Note: Could not persist (may already be saved)")

        return result

    except Exception as exc:
        print(f"    -> FAILED: {exc}")
        return None


# ---------------------------------------------------------------------------
# CLI commands
# ---------------------------------------------------------------------------

def _list_types_command(sf: Any) -> None:
    """List all available report types."""
    report_types = _list_report_types(sf)
    print(f"\nAvailable report types ({len(report_types)}):\n")
    print(f"  {'Type':<45s} {'Label':<35s} {'Category'}")
    print(f"  {'=' * 45} {'=' * 35} {'=' * 25}")
    for rt in sorted(report_types, key=lambda r: r.get("type", "")):
        print(f"  {rt.get('type', '?'):<45s} {rt.get('label', '?'):<35s} {rt.get('_category', '')}")


def _describe_command(sf: Any, report_type: str) -> None:
    """Describe available columns for a report type."""
    report_types = _list_report_types(sf)
    resolved = _find_report_type(report_types, report_type)
    if not resolved:
        print(f"\nReport type '{report_type}' not found. Possible matches:")
        for rt in report_types:
            if report_type.lower() in rt.get("label", "").lower() or report_type.lower() in rt.get("type", "").lower():
                print(f"  {rt['type']}: {rt.get('label', '?')}")
        return

    print(f"\nDescribing report type: {resolved}")
    desc = _describe_report_type(sf, resolved)
    print(f"Response keys: {list(desc.keys())}")

    all_columns = _extract_columns(desc)
    if not all_columns:
        print("\nNo columns extracted. Raw response (first 3000 chars):\n")
        print(json.dumps(desc, indent=2, default=str)[:3000])
        return

    print(f"Available columns ({len(all_columns)}):\n")
    print(f"  {'API Name':<45s} {'Label':<30s} {'Type'}")
    print(f"  {'=' * 45} {'=' * 30} {'=' * 15}")
    for col_name, info in sorted(all_columns.items()):
        if isinstance(info, dict):
            label = info.get("label", "?")
            dtype = info.get("dataType", info.get("type", "?"))
        else:
            label = str(info)
            dtype = "?"
        print(f"  {col_name:<45s} {label:<30s} {dtype}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    """Parse CLI arguments."""
    parser = argparse.ArgumentParser(
        description="Create sample Salesforce reports from mattermost-looker patterns",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument("--dry-run", action="store_true", help="Print what would be created without creating")
    parser.add_argument("--describe", metavar="TYPE", default=None, help="Describe columns for a report type")
    parser.add_argument("--list-types", action="store_true", help="List all report types in the org")

    auth = parser.add_argument_group("authentication")
    auth.add_argument("--client-id", default=os.environ.get("SF_CLIENT_ID"))
    auth.add_argument("--instance-url", default=os.environ.get("SF_INSTANCE_URL"))
    auth.add_argument("--username", default=os.environ.get("SF_USERNAME"))
    auth.add_argument("--password", default=os.environ.get("SF_PASSWORD"))
    auth.add_argument("--security-token", default=os.environ.get("SF_SECURITY_TOKEN"))
    auth.add_argument("--login-url", default=os.environ.get("SF_LOGIN_URL", "https://login.salesforce.com"))
    auth.add_argument("--org-key", default="default")

    return parser.parse_args()


def main() -> None:
    """Create sample Salesforce reports from mattermost-looker patterns."""
    args = parse_args()

    print("=" * 60)
    print("Salesforce Report Creator")
    print("=" * 60)

    print("\nConnecting to Salesforce ...")
    sf = _build_sf_connection(args)
    print(f"Connected to {sf.sf_instance}")

    if args.list_types:
        _list_types_command(sf)
        return

    if args.describe:
        _describe_command(sf, args.describe)
        return

    # Fetch report types once
    print("\nFetching available report types ...")
    report_types = _list_report_types(sf)
    print(f"Found {len(report_types)} report types")

    results: list[tuple[str, bool]] = []

    for spec in REPORT_SPECS:
        report_def = _build_report_metadata(sf, spec, report_types)
        if report_def is None:
            results.append((spec["name"], False))
            continue

        if args.dry_run:
            meta = report_def["reportMetadata"]
            print(f"\n  [DRY RUN] Would create: {meta['name']}")
            print(f"    Report type: {meta['reportType']['type']}")
            print(f"    Columns: {meta['detailColumns']}")
            print(f"    Groupings: {[g['name'] for g in meta['groupingsDown']]}")
            print(f"    Aggregates: {meta['aggregates']}")
            results.append((spec["name"], True))
            continue

        result = _create_report(sf, report_def)
        results.append((spec["name"], result is not None))

    print(f"\n{'=' * 60}")
    print("Summary")
    print(f"{'=' * 60}")
    for name, success in results:
        status = "OK" if success else "FAILED"
        print(f"  [{status}] {name}")


if __name__ == "__main__":
    main()
