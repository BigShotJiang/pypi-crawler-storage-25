"""Tests for opt-in TUI perf event logging."""

import json

from lineage.tui.perf import PerfEventLogger


def test_perf_logger_disabled_by_default_when_flag_missing(
    tmp_path, monkeypatch
) -> None:
    """Perf logger should not write files when TYPEDEF_TUI_PERF is unset."""
    monkeypatch.delenv("TYPEDEF_TUI_PERF", raising=False)
    logger = PerfEventLogger(enabled=None, log_path=tmp_path / "tui-perf.log")

    logger.log_event("chat_submit", run_id="run-123")

    assert not (tmp_path / "tui-perf.log").exists()


def test_perf_logger_writes_json_line_when_enabled(tmp_path) -> None:
    """Perf logger should emit structured JSON lines when enabled."""
    log_path = tmp_path / "tui-perf.log"
    logger = PerfEventLogger(enabled=True, log_path=log_path)

    logger.log_event("chat_submit", run_id="run-123", thread_id="tui-abc")

    lines = log_path.read_text(encoding="utf-8").splitlines()
    assert len(lines) == 1
    payload = json.loads(lines[0])
    assert payload["event"] == "chat_submit"
    assert payload["run_id"] == "run-123"
    assert payload["thread_id"] == "tui-abc"
    assert "ts" in payload
