"""Tests for slash command handling in AgentChat submit flow."""

import asyncio
from types import SimpleNamespace

import lineage.tui.screens.chat as chat_module
from lineage.tui.screens.chat import AgentChat, ChatArea, SlashCommandSpec


def _build_chat_for_submit(message: str) -> AgentChat:
    """Create an AgentChat with lightweight stubs for submit-flow tests."""
    chat = AgentChat("analyst", SimpleNamespace())
    chat.chat_area = SimpleNamespace(
        input=SimpleNamespace(text=message, read_only=False, focus=lambda: None),
        autoscroll_enabled=False,
        remove_placeholder=lambda: None,
        close_slash_menu=lambda: None,
        chat_log=SimpleNamespace(mount=lambda *_args, **_kwargs: None),
    )
    chat._request_autoscroll = lambda: None
    return chat


def test_submit_new_runs_restart_without_stream_request(monkeypatch) -> None:
    """`/new` should restart chat and not schedule outbound streaming."""
    chat = _build_chat_for_submit("/new")
    restarted: list[bool] = []
    chat._restart_chat = lambda: restarted.append(True)

    def fail_create_task(coro):
        coro.close()
        raise AssertionError("streaming should not be scheduled for /new")

    monkeypatch.setattr(chat_module.asyncio, "create_task", fail_create_task)

    asyncio.run(chat._submit_message())

    assert restarted == [True]
    assert chat.last_user_message is None
    assert chat.chat_area.input.text == ""


def test_submit_clear_runs_restart_without_stream_request(monkeypatch) -> None:
    """`/clear` should restart chat and not schedule outbound streaming."""
    chat = _build_chat_for_submit("/clear")
    restarted: list[bool] = []
    chat._restart_chat = lambda: restarted.append(True)

    def fail_create_task(coro):
        coro.close()
        raise AssertionError("streaming should not be scheduled for /clear")

    monkeypatch.setattr(chat_module.asyncio, "create_task", fail_create_task)

    asyncio.run(chat._submit_message())

    assert restarted == [True]
    assert chat.last_user_message is None
    assert chat.chat_area.input.text == ""


def test_context_payload_caps_to_recent_turns(monkeypatch) -> None:
    """Outbound context should be capped without mutating in-memory transcript."""
    monkeypatch.setenv("TYPEDEF_TUI_MAX_CONTEXT_TURNS", "2")
    chat = _build_chat_for_submit("latest")
    chat.messages = [
        {"role": "user", "content": "u1", "id": "1"},
        {"role": "assistant", "content": "a1", "id": "2"},
        {"role": "user", "content": "u2", "id": "3"},
        {"role": "assistant", "content": "a2", "id": "4"},
        {"role": "user", "content": "u3", "id": "5"},
    ]

    outbound = chat._build_context_messages_for_send()

    assert [msg["content"] for msg in outbound] == ["u2", "a2", "u3"]
    assert [msg["content"] for msg in chat.messages] == ["u1", "a1", "u2", "a2", "u3"]


def test_context_payload_cap_can_be_disabled(monkeypatch) -> None:
    """Cap value 0 should preserve full outbound context history."""
    monkeypatch.setenv("TYPEDEF_TUI_MAX_CONTEXT_TURNS", "0")
    chat = _build_chat_for_submit("latest")
    chat.messages = [
        {"role": "user", "content": "u1", "id": "1"},
        {"role": "assistant", "content": "a1", "id": "2"},
        {"role": "user", "content": "u2", "id": "3"},
    ]

    outbound = chat._build_context_messages_for_send()

    assert outbound == chat.messages


def test_filter_slash_commands_returns_all_for_empty_query() -> None:
    """Empty query should return all supported slash commands."""
    commands = chat_module._filter_slash_commands("")

    assert [command.command for command in commands] == ["/new", "/clear", "/status"]


def test_filter_slash_commands_fuzzy_query_prefers_new() -> None:
    """Fuzzy query should rank /new highest for '/ne' typing intent."""
    commands = chat_module._filter_slash_commands("ne")

    assert commands
    assert commands[0].command == "/new"


def test_update_slash_menu_handles_bare_slash() -> None:
    """Bare slash should map to empty query without raising."""
    area = ChatArea.__new__(ChatArea)
    captured: list[str] = []
    area.slash_menu = SimpleNamespace(update_query=lambda query: captured.append(query))
    area.close_slash_menu = lambda: None

    ChatArea.update_slash_menu(area, "/")

    assert captured == [""]


def test_apply_slash_completion_moves_cursor_to_end_and_closes_menu() -> None:
    """Tab completion should place cursor at command end and close popup."""
    area = ChatArea.__new__(ChatArea)
    area.slash_menu = SimpleNamespace(
        selected=lambda: SlashCommandSpec("/clear", "reset current chat")
    )
    closed: list[bool] = []
    area.close_slash_menu = lambda: closed.append(True)

    cursor_locations: list[tuple[int, int]] = []
    input_widget = SimpleNamespace(
        text="",
        move_cursor=lambda location: cursor_locations.append(location),
    )

    applied = ChatArea.apply_slash_completion(area, input_widget)

    assert applied is True
    assert input_widget.text == "/clear "
    assert cursor_locations == [(0, len("/clear "))]
    assert closed == [True]


def test_update_slash_menu_closes_for_completed_command() -> None:
    """Exact slash command should close completion popup."""
    area = ChatArea.__new__(ChatArea)
    updates: list[str] = []
    area.slash_menu = SimpleNamespace(update_query=lambda query: updates.append(query))
    closed: list[bool] = []
    area.close_slash_menu = lambda: closed.append(True)

    ChatArea.update_slash_menu(area, "/new")

    assert updates == []
    assert closed == [True]


def test_update_slash_menu_closes_for_slash_space() -> None:
    """Space immediately after '/' means arguments began; popup should close."""
    area = ChatArea.__new__(ChatArea)
    updates: list[str] = []
    area.slash_menu = SimpleNamespace(update_query=lambda query: updates.append(query))
    closed: list[bool] = []
    area.close_slash_menu = lambda: closed.append(True)

    ChatArea.update_slash_menu(area, "/ ")

    assert updates == []
    assert closed == [True]


def test_update_slash_menu_closes_for_command_arguments() -> None:
    """Adding args after command should keep popup hidden."""
    area = ChatArea.__new__(ChatArea)
    updates: list[str] = []
    area.slash_menu = SimpleNamespace(update_query=lambda query: updates.append(query))
    closed: list[bool] = []
    area.close_slash_menu = lambda: closed.append(True)

    ChatArea.update_slash_menu(area, "/new ")

    assert updates == []
    assert closed == [True]
