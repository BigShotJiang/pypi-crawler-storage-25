"""Tests for app-level unified chat mode switching behavior."""

from types import SimpleNamespace
from typing import Any, Awaitable, cast

import pytest
from lineage.tui.app import DataConciergeApp, StatusBar
from lineage.tui.screens.tickets import OpenTicketInChat, TicketInfo


def test_next_chat_mode_wraps_and_updates_active_chat() -> None:
    """Next mode action should wrap and route to active unified chat widget."""
    app = DataConciergeApp.__new__(DataConciergeApp)
    app.current_chat_mode = "copilot"
    updates: list[str] = []
    app.query_one = lambda selector, _type=None: SimpleNamespace(  # type: ignore[method-assign]
        active="chat"
    )
    app._active_agent_chat = lambda: SimpleNamespace(  # type: ignore[method-assign]
        can_switch_mode=lambda: True,
        set_agent_mode=lambda mode: updates.append(mode),
    )

    app.action_next_chat_mode()

    assert app.current_chat_mode == "analyst"
    assert updates == ["analyst"]


def test_previous_chat_mode_wraps_and_updates_active_chat() -> None:
    """Previous mode action should wrap and route to active unified chat widget."""
    app = DataConciergeApp.__new__(DataConciergeApp)
    app.current_chat_mode = "analyst"
    updates: list[str] = []
    app.query_one = lambda selector, _type=None: SimpleNamespace(  # type: ignore[method-assign]
        active="chat"
    )
    app._active_agent_chat = lambda: SimpleNamespace(  # type: ignore[method-assign]
        can_switch_mode=lambda: True,
        set_agent_mode=lambda mode: updates.append(mode),
    )

    app.action_previous_chat_mode()

    assert app.current_chat_mode == "copilot"
    assert updates == ["copilot"]


def test_open_ticket_in_chat_uses_unified_chat_tab_and_sets_mode() -> None:
    """Ticket handoff should open unified chat tab, set mode, and prefill input."""
    app = DataConciergeApp.__new__(DataConciergeApp)
    tabbed = SimpleNamespace(active="tickets")
    calls: list[tuple[str, str]] = []

    chat_child = SimpleNamespace(
        can_switch_mode=lambda: True,
        set_agent_mode=lambda mode: calls.append(("mode", mode)),
        set_input_value=lambda value: calls.append(("input", value)),
        focus_input=lambda: calls.append(("focus", "")),
    )

    def fake_query_one(selector, _type=None):
        if selector == "#main-content":
            return tabbed
        if selector == "#chat-container":
            return SimpleNamespace(children=[chat_child])
        raise AssertionError(f"Unexpected selector: {selector}")

    app.query_one = fake_query_one  # type: ignore[method-assign]

    ticket = TicketInfo(
        id="DI-123",
        title="Fix exchange rates",
        status="open",
        priority="high",
        tags=["revenue", "fx"],
    )
    message = OpenTicketInChat(ticket=ticket, agent_type="investigator")

    app.on_open_ticket_in_chat(message)

    assert tabbed.active == "chat"
    assert ("mode", "investigator") in calls
    prompt = next(value for kind, value in calls if kind == "input")
    assert "DI-123" in prompt
    assert "Fix exchange rates" in prompt
    assert ("focus", "") in calls


def test_chat_mode_switch_is_blocked_when_chat_not_fresh() -> None:
    """Mode switching should be blocked outside a fresh/new chat state."""
    app = DataConciergeApp.__new__(DataConciergeApp)
    app.current_chat_mode = "analyst"
    app.query_one = lambda selector, _type=None: SimpleNamespace(  # type: ignore[method-assign]
        active="chat"
    )
    notifications: list[str] = []
    app.notify = lambda msg, severity="information": notifications.append(msg)  # type: ignore[method-assign]
    app._active_agent_chat = lambda: SimpleNamespace(  # type: ignore[method-assign]
        can_switch_mode=lambda: False,
        set_agent_mode=lambda mode: (_ for _ in ()).throw(
            AssertionError("set_agent_mode should not be called")
        ),
    )

    app.action_next_chat_mode()

    assert app.current_chat_mode == "analyst"
    assert notifications
    assert notifications[0] == "Tip: use /new to start a new chat session"


def test_next_chat_mode_from_tickets_returns_to_chat_tab() -> None:
    """Mode-toggle keys should return to chat tab from Tickets."""
    app = DataConciergeApp.__new__(DataConciergeApp)
    tabbed = SimpleNamespace(active="tickets")

    app.query_one = lambda selector, _type=None: tabbed  # type: ignore[method-assign]

    app.action_next_chat_mode()

    assert tabbed.active == "chat"


def test_next_chat_mode_from_tickets_refocuses_chat_target() -> None:
    """Ctrl+,/. from Tickets should return to chat and focus the chooser/input."""
    app = DataConciergeApp.__new__(DataConciergeApp)
    tabbed = SimpleNamespace(active="tickets")
    focused: list[bool] = []
    chat_child = SimpleNamespace(focus_input=lambda: focused.append(True))

    def fake_query_one(selector, _type=None):
        if selector == "#main-content":
            return tabbed
        if selector == "#chat-container":
            return SimpleNamespace(children=[chat_child])
        raise AssertionError(f"Unexpected selector: {selector}")

    app.query_one = fake_query_one  # type: ignore[method-assign]
    app.call_after_refresh = lambda fn: fn()  # type: ignore[method-assign]

    app.action_next_chat_mode()

    assert tabbed.active == "chat"
    assert focused == [True]


def test_previous_chat_mode_from_daemon_returns_to_chat_tab() -> None:
    """Mode-toggle keys should return to chat tab from Daemon."""
    app = DataConciergeApp.__new__(DataConciergeApp)
    tabbed = SimpleNamespace(active="daemon")

    app.query_one = lambda selector, _type=None: tabbed  # type: ignore[method-assign]

    app.action_previous_chat_mode()

    assert tabbed.active == "chat"


def test_new_chat_tip_toast_shows_once_per_session() -> None:
    """New-chat tip toast should only appear once per app session."""
    app = DataConciergeApp.__new__(DataConciergeApp)
    app._new_chat_tip_shown = False
    notifications: list[tuple[str, int]] = []
    app.notify = lambda msg, timeout=0, **kwargs: notifications.append(
        (  # type: ignore[method-assign]
            msg,
            timeout,
        )
    )

    app.maybe_show_new_chat_tip()
    app.maybe_show_new_chat_tip()

    assert notifications == [("Tip: use /new to start a new chat session", 4)]


@pytest.mark.asyncio
async def test_tab_activation_refocuses_chat_input_target() -> None:
    """Returning to chat tab should restore keyboard focus to chat input target."""
    app = DataConciergeApp.__new__(DataConciergeApp)
    app.status_bar = StatusBar()
    app.status_bar.active_tab = "tickets"
    app.call_after_refresh = lambda fn: fn()  # type: ignore[method-assign]
    focused: list[bool] = []

    chat_child = SimpleNamespace(focus_input=lambda: focused.append(True))

    app.query_one = lambda selector, _type=None: SimpleNamespace(  # type: ignore[method-assign]
        children=[chat_child]
    )

    event = cast(Any, SimpleNamespace(tab=SimpleNamespace(id="chat")))
    await cast(Awaitable[None], app.on_tabbed_content_tab_activated(event))

    assert focused == [True]


@pytest.mark.asyncio
async def test_select_investigator_on_chat_tab_refocuses_chat_input_target() -> None:
    """i on chat tab should return focus to the chat input target."""
    app = DataConciergeApp.__new__(DataConciergeApp)
    focused: list[bool] = []

    app.query_one = lambda selector, _type=None: SimpleNamespace(  # type: ignore[method-assign]
        active="chat"
    )
    app._focus_chat_input_target = lambda: focused.append(True)  # type: ignore[method-assign]

    await cast(Awaitable[None], app.action_select_investigator())

    assert focused == [True]
