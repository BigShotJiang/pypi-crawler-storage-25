"""Tests for app-level Daemon shortcut routing."""

from types import SimpleNamespace
from typing import Any

import pytest
from lineage.tui.app import DataConciergeApp


def test_app_exposes_global_daemon_shortcut_bindings() -> None:
    """App bindings should include daemon shortcuts for active Daemon tab."""
    keys = {
        binding[0] if isinstance(binding, tuple) else binding.key
        for binding in DataConciergeApp.BINDINGS
    }
    assert {"s", "r", "i"}.issubset(keys)


@pytest.mark.asyncio
async def test_app_daemon_shortcuts_route_to_daemon_screen_when_active() -> None:
    """Global daemon shortcuts should delegate when Daemon tab is active."""
    app: Any = DataConciergeApp.__new__(DataConciergeApp)
    calls: list[str] = []

    daemon_child = SimpleNamespace(
        action_toggle_daemon=lambda: calls.append("s"),
        action_select_reconciler=lambda: calls.append("r"),
        action_select_investigator=lambda: calls.append("i"),
    )

    def fake_query_one(selector, _type=None):
        if selector == "#main-content":
            return SimpleNamespace(active="daemon")
        if selector == "#daemon-container":
            return SimpleNamespace(children=[daemon_child])
        raise AssertionError(f"Unexpected selector: {selector}")

    app.query_one = fake_query_one  # type: ignore[method-assign]
    app._ticketing_available = True
    app._mounted_aux_tabs = {"daemon"}

    await app.action_toggle_daemon()
    await app.action_select_reconciler()
    await app.action_select_investigator()

    assert calls == ["s", "r", "i"]


@pytest.mark.asyncio
async def test_app_daemon_shortcuts_noop_when_not_on_daemon_tab() -> None:
    """Global daemon shortcuts should no-op outside Daemon tab."""
    app: Any = DataConciergeApp.__new__(DataConciergeApp)
    touched: list[bool] = []

    def fake_query_one(selector, _type=None):
        if selector == "#main-content":
            return SimpleNamespace(active="analyst")
        if selector == "#daemon-container":
            touched.append(True)
            return SimpleNamespace(children=[])
        raise AssertionError(f"Unexpected selector: {selector}")

    app.query_one = fake_query_one  # type: ignore[method-assign]
    app._ticketing_available = True
    app._mounted_aux_tabs = {"daemon"}

    await app.action_toggle_daemon()
    await app.action_select_reconciler()
    await app.action_select_investigator()

    assert touched == []


@pytest.mark.asyncio
async def test_app_select_daemon_tab_shortcut_activates_daemon() -> None:
    """Ctrl+D action should switch to Daemon tab when available."""
    app: Any = DataConciergeApp.__new__(DataConciergeApp)
    app._ticketing_available = True
    tabbed = SimpleNamespace(active="chat")
    app._mounted_aux_tabs = {"daemon"}
    app._aux_mount_tasks = {}
    app.query_one = lambda selector, _type=None: tabbed  # type: ignore[method-assign]

    await app.action_select_daemon_tab()

    assert tabbed.active == "daemon"


@pytest.mark.asyncio
async def test_app_select_daemon_tab_mounts_screen_on_first_use() -> None:
    """Ctrl+D should mount Daemon screen before first routed use."""
    app: Any = DataConciergeApp.__new__(DataConciergeApp)
    app._ticketing_available = True
    app.client = object()
    app._mounted_aux_tabs = set()
    app._aux_mount_tasks = {}

    mounted: list[object] = []
    tabbed = SimpleNamespace(active="chat")

    class _Container:
        def __init__(self) -> None:
            self.children: list[object] = []

        async def mount(self, widget: object, *_args, **_kwargs) -> object:
            self.children.append(widget)
            mounted.append(widget)
            return widget

    container = _Container()

    def fake_query_one(selector, _type=None):
        if selector == "#main-content":
            return tabbed
        if selector == "#daemon-container":
            return container
        raise AssertionError(f"Unexpected selector: {selector}")

    app.query_one = fake_query_one  # type: ignore[method-assign]

    await app.action_select_daemon_tab()

    assert tabbed.active == "daemon"
    assert len(mounted) == 1
    assert "daemon" in app._mounted_aux_tabs
