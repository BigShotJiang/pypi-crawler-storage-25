"""Tests for ActivityScreen behavior."""

from types import SimpleNamespace

from lineage.tui.screens.activity import ActivityScreen
from lineage.tui.widgets.artifacts.artifact_types import ArtifactData


class _StubList:
    def __init__(self) -> None:
        self.id = "activity-modal-list"
        self.items: list[object] = []
        self.index: int | None = None
        self.focused = False

    def append(self, item: object) -> None:
        self.items.append(item)

    def focus(self) -> None:
        self.focused = True


class _StubPreview:
    def __init__(self) -> None:
        self.updates: list[str] = []

    def update(self, value: str) -> None:
        self.updates.append(value)


def _activity(title: str, prompt: str, preview: str) -> ArtifactData:
    stats = SimpleNamespace(
        duration_seconds=1.2,
        tool_call_count=2,
        user_message=prompt,
        result_preview=preview,
        tool_calls=[SimpleNamespace(display_text="step one", duration_seconds=0.5)],
    )
    return ArtifactData(
        id=f"activity-{title}",
        type="activity",
        title=title,
        data={"stats": stats},
        render_func=lambda *_: None,
    )


def test_activity_screen_mount_populates_list_and_preview() -> None:
    """Mount should focus list and render latest activity preview."""
    first = _activity("Run A", "Prompt A", "Result A")
    second = _activity("Run B", "Prompt B", "Result B")
    screen = ActivityScreen(activities=[first, second])
    screen._list = _StubList()  # type: ignore[assignment]
    screen._preview = _StubPreview()  # type: ignore[assignment]

    screen.on_mount()

    assert len(screen._list.items) == 2
    assert screen._list.index == 1
    assert screen._list.focused is True
    assert "Run B" in screen._preview.updates[-1]
    assert "Prompt B" in screen._preview.updates[-1]
    assert "Result B" in screen._preview.updates[-1]


def test_activity_screen_selection_and_highlight_update_preview() -> None:
    """Selection/highlight events should update preview content."""
    first = _activity("Run A", "Prompt A", "Result A")
    second = _activity("Run B", "Prompt B", "Result B")
    screen = ActivityScreen(activities=[first, second])
    stub_list = _StubList()
    screen._list = stub_list  # type: ignore[assignment]
    screen._preview = _StubPreview()  # type: ignore[assignment]

    stub_list.index = 0
    screen.on_list_view_selected(SimpleNamespace(list_view=stub_list))
    assert "Run A" in screen._preview.updates[-1]

    stub_list.index = 1
    screen.on_list_view_highlighted(SimpleNamespace(list_view=stub_list))
    assert "Run B" in screen._preview.updates[-1]


def test_activity_screen_bindings_and_close_action() -> None:
    """Activity modal should support escape/q close bindings."""
    bindings = {
        (
            binding[0] if isinstance(binding, tuple) else binding.key,
            binding[1] if isinstance(binding, tuple) else binding.action,
        )
        for binding in ActivityScreen.BINDINGS
    }
    assert ("escape", "close") in bindings
    assert ("q", "close") in bindings

    screen = ActivityScreen([])
    called: list[bool] = []
    screen.dismiss = lambda: called.append(True)  # type: ignore[method-assign]

    screen.action_close()

    assert called == [True]
