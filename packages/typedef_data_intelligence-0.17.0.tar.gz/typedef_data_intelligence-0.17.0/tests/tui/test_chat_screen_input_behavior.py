"""Tests for chat screen input sizing and prompt wiring."""

from pathlib import Path
from types import SimpleNamespace

import lineage.tui.screens.chat as chat_module
from lineage.tui.screens.chat import (
    ChatArea,
    ChatInput,
    PlaceholderInput,
    SubagentActivityBlock,
    ThinkingBlock,
    ToolResultBlock,
)
from textual.widgets import Collapsible


def _chat_screen_source() -> str:
    source_path = (
        Path(__file__).resolve().parents[2]
        / "src"
        / "lineage"
        / "tui"
        / "screens"
        / "chat.py"
    )
    return source_path.read_text()


def _tui_styles_source() -> str:
    source_path = (
        Path(__file__).resolve().parents[2] / "src" / "lineage" / "tui" / "styles.tcss"
    )
    return source_path.read_text()


def test_chat_input_starts_without_inline_height() -> None:
    """ChatInput height should come from TCSS, not inline defaults."""
    area = ChatArea(SimpleNamespace(agent_name="analyst"))

    assert area.input.styles.height is None


def test_placeholder_input_starts_without_inline_height() -> None:
    """Placeholder input height should come from TCSS, not inline defaults."""
    placeholder = PlaceholderInput()

    assert placeholder.styles.height is None


def test_placeholder_input_single_line_height_matches_chat_input_behavior() -> None:
    """Placeholder input should size 1-line text to +1 cursor row."""
    placeholder = PlaceholderInput()
    placeholder.text = "hello"

    placeholder._adjust_height()

    assert placeholder.styles.height.value == 2


def test_chat_input_adjust_height_clamps_to_style_bounds() -> None:
    """Chat input growth should respect style min/max constraints."""
    chat_input = ChatInput()
    chat_input.styles.min_height = 1
    chat_input.styles.max_height = 3
    chat_input.text = "\n".join(f"line {i}" for i in range(6))

    chat_input._adjust_height()

    assert chat_input.styles.height.value == 3


def test_placeholder_input_adjust_height_clamps_to_style_bounds() -> None:
    """Placeholder input growth should respect style min/max constraints."""
    placeholder = PlaceholderInput()
    placeholder.styles.min_height = 1
    placeholder.styles.max_height = 6
    placeholder.text = "\n".join(f"line {i}" for i in range(6))

    placeholder._adjust_height()

    assert placeholder.styles.height.value == 6


def test_chat_input_submit_ignores_blank_text() -> None:
    """Chat input should not emit submit message for blank content."""
    chat_input = ChatInput()
    chat_input.text = "   \n\t  "
    submitted: list[object] = []
    chat_input.post_message = submitted.append

    chat_input.action_submit()

    assert submitted == []


def test_chat_input_does_not_submit_when_read_only() -> None:
    """Chat input should not submit while read-only."""
    chat_input = ChatInput()
    chat_input.text = "hello"
    chat_input.read_only = True
    submitted: list[object] = []
    chat_input.post_message = submitted.append

    chat_input.action_submit()

    assert submitted == []


def test_placeholder_input_submit_ignores_blank_text() -> None:
    """Placeholder input should not emit submit message for blank content."""
    placeholder = PlaceholderInput()
    placeholder.text = "   \n\t  "
    submitted: list[object] = []
    placeholder.post_message = submitted.append

    placeholder.action_submit()

    assert submitted == []


def test_sample_prompt_clicked_path_removed() -> None:
    """Legacy sample prompt message path should be removed."""
    assert not hasattr(chat_module, "SamplePromptClicked")
    assert not hasattr(chat_module.AgentChat, "on_sample_prompt_clicked")


def test_agent_placeholder_compose_does_not_wrap_sections_with_center() -> None:
    """Placeholder compose should not use no-op Center wrappers for full-width sections."""
    source = _chat_screen_source()

    assert 'with Center(classes="placeholder-prompts-center")' not in source
    assert 'with Center(classes="placeholder-input-center")' not in source


def test_placeholder_center_style_hooks_are_removed() -> None:
    """Unused placeholder Center class selectors should be removed from TCSS."""
    styles = _tui_styles_source()

    assert ".placeholder-prompts-center" not in styles
    assert ".placeholder-input-center" not in styles


def test_placeholder_input_hints_do_not_include_agent_switch_tip() -> None:
    """Empty-chat input hints should not advertise keyboard-based agent switching."""
    source = _chat_screen_source()

    assert "Tip: Ctrl+, / Ctrl+. to switch agent" not in source


def test_chat_collapsible_blocks_use_textual_collapsible_widget() -> None:
    """Chat collapsible blocks should use Textual Collapsible for keyboard support."""
    assert issubclass(ThinkingBlock, Collapsible)
    assert issubclass(ToolResultBlock, Collapsible)
    assert issubclass(SubagentActivityBlock, Collapsible)


def test_verbose_subagent_block_does_not_mutate_private_expanded_state() -> None:
    """Verbose-mode subagent block should use public collapsed API."""
    source = _chat_screen_source()

    assert "block._expanded = True" not in source
    assert "block.collapsed = False" in source


def test_collapsible_block_styles_target_collapsible_title() -> None:
    """TCSS should style built-in CollapsibleTitle for chat collapsibles."""
    styles = _tui_styles_source()

    assert ".thinking-block CollapsibleTitle" in styles
    assert ".tool-result-block CollapsibleTitle" in styles
    assert ".subagent-activity CollapsibleTitle" in styles


def test_chat_input_includes_ctrl_a_and_ctrl_g_focus_safe_intercepts() -> None:
    """ChatInput key handler should intercept ctrl+a/ctrl+g before TextArea defaults."""
    source = _chat_screen_source()

    assert 'if event.key == "ctrl+a":' in source
    assert 'open_artifacts = getattr(self.app, "action_open_artifacts", None)' in source
    assert 'if event.key == "ctrl+g":' in source
    assert 'open_activity = getattr(self.app, "action_open_activity", None)' in source


def test_chat_inputs_include_ctrl_c_intercept_for_clear_then_exit_flow() -> None:
    """Chat and placeholder inputs should forward ctrl+c to app confirm-exit flow."""
    source = _chat_screen_source()

    assert source.count('if event.key == "ctrl+c":') >= 2
    assert 'confirm_exit = getattr(self.app, "action_confirm_exit", None)' in source


def test_chat_inputs_include_slash_menu_key_intercepts() -> None:
    """Chat inputs should handle slash-popup navigation and completion keys."""
    source = _chat_screen_source()

    # Shared helper encapsulates the slash-menu key logic.
    assert "def _handle_slash_menu_key(" in source
    assert "slash_menu and slash_menu.is_open" in source
    assert 'if event.key == "tab":' in source
    assert 'if event.key == "up":' in source
    assert 'if event.key == "down":' in source
    assert 'if event.key == "escape":' in source
    # Both on_key methods delegate to the shared helper.
    assert source.count("_handle_slash_menu_key(event, chat_area, self)") >= 2


def test_chat_hints_include_tab_command_completion_tip() -> None:
    """Input hints should advertise tab-based slash command completion."""
    source = _chat_screen_source()

    assert "[bold]tab[/bold] complete command" in source


def test_slash_command_menu_style_hooks_exist_in_tcss() -> None:
    """Slash command popup classes should be defined in shared TCSS."""
    styles = _tui_styles_source()

    assert ".slash-command-menu" in styles
    assert ".slash-command-list" in styles
    assert ".slash-command-item.-selected" in styles
    assert ".slash-command-item.slash-command-active" in styles


def test_chat_busy_input_style_hooks_exist_in_tcss() -> None:
    """Busy input affordance classes should be defined in shared TCSS."""
    styles = _tui_styles_source()

    assert ".input-bar.input-bar-busy" in styles
    assert ".chat-input.chat-input-busy" in styles
    assert ".input-hints.input-hints-busy" in styles
    assert "text-align: left;" in styles


def test_chat_source_includes_phase1_perf_hooks() -> None:
    """Chat screen should include submit/stream perf instrumentation events."""
    source = _chat_screen_source()

    assert "get_perf_logger" in source
    assert '"chat_submit"' in source
    assert '"first_token_received"' in source
    assert '"assistant_first_paint"' in source
    assert '"stream_finished"' in source


def test_tool_call_result_uses_single_parse_path() -> None:
    """Tool result handling should parse JSON content once per event path."""
    source = _chat_screen_source()

    assert "parsed_content = _try_parse_json_content(content)" in source
    assert "data = json.loads(content) if content else None" not in source


def test_stream_flush_skips_mermaid_transform_until_finalize() -> None:
    """Streaming flush should avoid full mermaid transform work on each tick."""
    source = _chat_screen_source()

    assert "self.markdown.update(self.content_text)" in source
    assert "display_content = _process_mermaid_in_content(self.content_text)" in source


def test_tool_and_subagent_status_widgets_cache_labels_and_cleanup_timers() -> None:
    """Phase 3 should cache label lookups and stop spinner timers on unmount."""
    source = _chat_screen_source()

    assert 'self._status_label = self.query_one("#tool-status", Label)' in source
    assert 'self._status_label = self.query_one("#subagent-status", Label)' in source
    assert "def _stop_spinner(self) -> None:" in source
    assert "def on_unmount(self) -> None:" in source


def test_spinner_interval_is_reduced_to_limit_timer_churn() -> None:
    """Phase 3 should slow spinner tick cadence to reduce UI update pressure."""
    source = _chat_screen_source()

    assert "SPINNER_INTERVAL = 0.5" in source
