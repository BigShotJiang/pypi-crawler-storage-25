"""Tests for wizard style parity with the overhauled chat TUI."""

from pathlib import Path


def _wizard_styles() -> str:
    styles_path = (
        Path(__file__).resolve().parents[2]
        / "src"
        / "lineage"
        / "tui"
        / "wizards"
        / "styles.tcss"
    )
    return styles_path.read_text()


def _wizard_base_source() -> str:
    source_path = (
        Path(__file__).resolve().parents[2]
        / "src"
        / "lineage"
        / "tui"
        / "wizards"
        / "base.py"
    )
    return source_path.read_text()


def _selector_source() -> str:
    source_path = (
        Path(__file__).resolve().parents[2]
        / "src"
        / "lineage"
        / "tui"
        / "wizards"
        / "project_selector.py"
    )
    return source_path.read_text()


def _dbt_source_step_source() -> str:
    source_path = (
        Path(__file__).resolve().parents[2]
        / "src"
        / "lineage"
        / "tui"
        / "wizards"
        / "init"
        / "steps"
        / "dbt_source.py"
    )
    return source_path.read_text()


def _snowflake_step_source() -> str:
    source_path = (
        Path(__file__).resolve().parents[2]
        / "src"
        / "lineage"
        / "tui"
        / "wizards"
        / "init"
        / "steps"
        / "snowflake.py"
    )
    return source_path.read_text()


def test_wizard_screen_exposes_borderless_shell_hooks() -> None:
    """Wizard shell should expose explicit title/content/nav classes for styling."""
    source = _wizard_base_source()
    assert 'classes="wizard-container wizard-shell"' in source
    assert 'classes="wizard-nav"' in source


def test_project_selector_exposes_parity_shell_hook() -> None:
    """Project selector should use shared wizard shell treatment."""
    source = _selector_source()
    assert 'classes="selector-container wizard-shell"' in source


def test_wizard_base_does_not_use_border_title_framing() -> None:
    """Wizard base should not depend on border-title framing anymore."""
    source = _wizard_base_source()
    assert "border_title" not in source


def test_wizard_styles_use_left_edge_accent_pattern() -> None:
    """Wizard styles should emphasize left-edge accents, not full borders."""
    styles = _wizard_styles()

    assert ".wizard-shell" in styles
    assert "border-left: solid $primary" in styles
    assert "border: none;" in styles


def test_wizard_styles_keep_input_text_vertically_centered() -> None:
    """Wizard inputs should use centered line layout like chat input styling."""
    styles = _wizard_styles()

    assert ".wizard-shell Input {" in styles
    assert "padding: 1 1 0 1;" in styles
    assert "content-align: left middle;" in styles


def test_wizard_styles_scope_widget_type_selectors_to_wizard_shell() -> None:
    """Wizard widget type selectors should be scoped to avoid app-wide bleed."""
    styles = _wizard_styles()

    assert ".wizard-shell Label {" in styles
    assert ".wizard-shell Select {" in styles
    assert ".wizard-shell SelectionList {" in styles
    assert ".wizard-shell ListView {" in styles
    assert ".wizard-shell ListItem {" in styles
    assert ".wizard-shell ProgressBar {" in styles

    assert "\nInput {" not in styles
    assert "\nLabel {" not in styles
    assert "\nSelect {" not in styles
    assert "\nSelectionList {" not in styles
    assert "\nListView {" not in styles
    assert "\nListItem {" not in styles
    assert "\nProgressBar {" not in styles


def test_wizard_header_text_uses_chat_like_treatment() -> None:
    """Wizard titles should avoid heavy header bars and use chat-like emphasis."""
    styles = _wizard_styles()

    assert ".wizard-shell-title" in styles
    assert "color: $primary;" in styles
    assert "background: transparent;" in styles


def test_wizard_status_line_is_positioned_above_form_content() -> None:
    """Step status should be near the title/description, not below inputs."""
    source = _wizard_base_source()

    assert 'yield StepStatus("", id="step-status", classes="step-status")' in source
    assert source.index('id="step-status"') < source.index(
        'with VerticalScroll(classes="wizard-content")'
    )


def test_wizard_status_supports_animated_in_progress_icon() -> None:
    """Step status should use Rich circle-halves spinner for in-progress states."""
    source = _wizard_base_source()

    assert "from rich.spinner import Spinner" in source
    assert 'Spinner("circleHalves"' in source
    assert "self.auto_refresh = 1 / 12" in source
    assert "self.auto_refresh = None" in source


def test_wizard_screen_exposes_keyboard_navigation_bindings() -> None:
    """Wizard screen should expose keyboard-first navigation shortcuts."""
    source = _wizard_base_source()

    assert "BINDINGS = [" in source
    assert '("ctrl+enter", "wizard_next", "Next")' in source
    assert '("ctrl+b", "wizard_back", "Back")' in source
    assert '("ctrl+c", "confirm_exit", "Exit")' in source
    assert '("escape", "wizard_cancel", "Cancel")' not in source


def test_wizard_screen_handles_input_submit_for_enter_navigation() -> None:
    """Enter in text inputs should move focus forward instead of advancing step."""
    source = _wizard_base_source()

    assert (
        "from textual.widgets import Button, Input, Label, Select, Static, TextArea"
        in source
    )
    assert "def on_input_submitted(self, event: Input.Submitted) -> None:" in source
    assert "self._focus_next_interactive()" in source


def test_wizard_screen_handles_select_commit_for_enter_navigation() -> None:
    """Enter on a focused Select should commit, then advance to the next control."""
    source = _wizard_base_source()

    assert "def on_select_changed(self, event: Select.Changed) -> None:" in source
    assert "if not event.select.has_focus_within:" in source
    assert "self._focus_next_interactive()" in source


def test_wizard_screen_backspace_moves_focus_backward() -> None:
    """Backspace should mirror Enter by moving focus backward outside text fields."""
    source = _wizard_base_source()

    assert 'if event.key == "backspace":' in source
    assert "self._focus_previous_interactive()" in source


def test_wizard_screen_escape_is_consumed_and_does_not_exit() -> None:
    """Escape should be swallowed so wizard only exits via explicit controls."""
    source = _wizard_base_source()

    assert 'if event.key == "escape":' in source
    assert "event.prevent_default()" in source
    assert "event.stop()" in source


def test_wizard_screen_exposes_navigation_hint_row() -> None:
    """Wizard should show muted keyboard navigation hints near nav buttons."""
    source = _wizard_base_source()
    styles = _wizard_styles()

    assert 'classes="wizard-nav-wrap"' in source
    assert 'classes="wizard-nav-cluster"' in source
    assert 'classes="wizard-nav-hints-table"' in source
    assert 'classes="wizard-hint-row"' in source
    assert 'classes="wizard-hint-key"' in source
    assert 'classes="wizard-hint-desc"' in source
    assert "enter" in source
    assert "next field" in source
    assert 'yield Static("esc", classes="wizard-hint-key")' not in source
    assert 'yield Static("cancel", classes="wizard-hint-desc")' not in source
    assert 'yield Static("ctrl+c", classes="wizard-hint-key")' in source
    assert 'yield Static("exit", classes="wizard-hint-desc")' in source
    assert ".wizard-nav-hints-table" in styles
    assert ".wizard-hint-key" in styles


def test_wizard_screen_renders_nav_buttons_above_help_hints() -> None:
    """Navigation buttons should render before the shortcut hint table."""
    source = _wizard_base_source()

    assert source.index('classes="wizard-nav"') < source.index(
        'classes="wizard-nav-hints-table"'
    )


def test_wizard_focused_nav_button_uses_brighter_treatment() -> None:
    """Focused nav button should use brighter text and stronger highlight."""
    styles = _wizard_styles()

    assert ".wizard-button:focus" in styles
    assert "background: $primary 20%;" in styles
    assert "color: $text-muted;" in styles
    assert "text-style: bold;" in styles
    assert ".wizard-nav .wizard-button.-primary:focus" in styles
    assert "background: $primary 24%;" in styles


def test_wizard_hints_keep_balanced_top_and_bottom_spacing() -> None:
    """Hints block should keep breathing room below the shortcut rows."""
    styles = _wizard_styles()

    assert ".wizard-nav-hints-table" in styles
    assert "margin: 0 0 1 0;" in styles


def test_wizard_nav_buttons_use_roomier_vertical_sizing() -> None:
    """Wizard nav buttons should have vertical breathing room around text."""
    styles = _wizard_styles()

    assert ".wizard-nav-wrap" in styles
    assert "height: 10;" in styles
    assert ".wizard-nav-cluster" in styles
    assert "align: center top;" in styles
    assert ".wizard-nav" in styles
    assert "min-height: 3;" in styles
    assert "margin: 0 0 1 0;" in styles
    assert ".wizard-button" in styles
    assert "height: 3;" in styles


def test_wizard_steps_capture_and_restore_state_when_switched() -> None:
    """Wizard screen should persist step widget state between back/forward moves."""
    source = _wizard_base_source()

    assert "def snapshot_state(self) -> dict[str, Any]:" in source
    assert "def restore_state(self, state: dict[str, Any]) -> None:" in source
    assert "self._step_state: dict[str, dict[str, Any]] = {}" in source
    assert "self._capture_attached_step_states()" in source
    assert "self._restore_step_state(current_step)" in source


def test_dbt_git_source_retains_url_and_tracks_resolved_path() -> None:
    """Git source step should keep entered URL while storing resolved clone path separately."""
    source = _dbt_source_step_source()

    assert "self.resolved_dbt_path: Optional[str] = None" in source
    assert "self.resolved_dbt_path = str(clone_dir)" in source
    assert "mode = self._get_selected_source()" in source
    assert "clone_dir_path = self._get_clone_dir().expanduser().resolve()" in source
    assert (
        'self.app.call_from_thread(lambda: setattr(self.input, "value", str(clone_dir)))'
        not in source
    )


def test_wizard_restore_replay_sets_guard_flag() -> None:
    """State replay should expose a guard to suppress restore-triggered handlers."""
    source = _wizard_base_source()

    assert "self._restoring_state = True" in source
    assert "self._restoring_state = False" in source


def test_dbt_source_ignores_restore_triggered_input_events() -> None:
    """Dbt source input/select handlers should not reset state during replay."""
    source = _dbt_source_step_source()

    assert "and not self.is_restoring_state" in source


def test_dbt_git_source_invalidates_stale_resolved_clone_path() -> None:
    """Git source should reset stale resolved clone paths when clone target changes."""
    source = _dbt_source_step_source()

    assert "def _resolved_path_matches_clone_dir(self) -> bool:" in source
    assert (
        "if self.work_complete and not self._resolved_path_matches_clone_dir():"
        in source
    )
    assert (
        "if candidate_path is not None and candidate_path == clone_dir_path:" in source
    )
    assert "self.resolved_dbt_path = None" in source


def test_database_selection_step_restores_schema_and_additional_db_state() -> None:
    """Database/schema step should restore selected DB/schema and additional DB picks."""
    source = _snowflake_step_source()

    assert "def snapshot_state(self) -> dict[str, Any]:" in source
    assert (
        'state["__additional_db_selected"] = list(self.additional_db_select.selected)'
        in source
    )
    assert "def restore_state(self, state: dict[str, Any]) -> None:" in source
    assert 'schema_payload = state.get("schema-select", {})' in source
    assert "self.schemas_loaded_for_database: str | None = None" in source
    assert "selected_default_str != self.schemas_loaded_for_database" in source
    assert "or not self.available_schemas" in source
    assert "self.schemas_loaded_for_database = database" in source
    assert "self._pending_schema_value in schemas" in source
    assert "self._pending_schema_value == self.MANUAL_SCHEMA_VALUE" in source


def test_database_selection_step_ignores_restore_triggered_events() -> None:
    """Database selection handlers should ignore events emitted during restore."""
    source = _snowflake_step_source()

    assert 'event.select.id == "default-db-select"' in source
    assert 'event.input.id == "additional-db-filter-input"' in source
    assert "and not self.is_restoring_state" in source


def test_database_selection_step_repopulates_schema_select_from_cached_schemas() -> (
    None
):
    """Restore should rebuild schema select options when DB already loaded."""
    source = _snowflake_step_source()

    assert "if selected_default and self.available_schemas:" in source
    assert "options = [(s, s) for s in self.available_schemas]" in source
    assert "self.schema_select.set_options(options)" in source
    assert "self.schema_select.disabled = False" in source


def test_wizard_screen_exposes_auto_advance_scheduler() -> None:
    """Wizard screen should provide a guarded async auto-advance helper."""
    source = _wizard_base_source()

    assert "AUTO_ADVANCE_DELAY_SECONDS = 0.8" in source
    assert "def schedule_auto_advance(" in source
    assert "def _try_auto_advance(" in source


def test_async_steps_schedule_auto_advance_after_success() -> None:
    """Async setup/validation steps should auto-advance on success."""
    dbt_source = _dbt_source_step_source()
    snowflake = _snowflake_step_source()

    assert 'wizard.schedule_auto_advance("dbt-path")' in dbt_source
    assert 'wizard.schedule_auto_advance("dbt-subproject")' in dbt_source
    assert 'wizard.schedule_auto_advance("snowflake-connection")' in snowflake
