"""Tests for compact shortcuts modal behavior."""

from lineage.tui.screens.shortcuts import ShortcutsScreen


def test_shortcuts_screen_shows_global_shortcuts_and_full_help_handoff() -> None:
    """Compact shortcuts should prioritize key hints and advertise F1 full help."""
    screen = ShortcutsScreen(active_tab="chat")

    assert screen.TITLE_TEXT == "keyboard shortcuts"
    global_keys = {key for key, _ in screen.GLOBAL_ROWS}
    assert "?" in global_keys
    assert "ctrl+/" in global_keys
    assert ("f1", "open user guide") in screen.GLOBAL_ROWS
    assert (
        "tab / shift+tab",
        "move ui focus",
    ) in screen.GLOBAL_ROWS
    assert ("ctrl+a", "open artifacts") in screen.GLOBAL_ROWS
    assert ("ctrl+g", "open activity") in screen.GLOBAL_ROWS
    assert ("ctrl+shift+c", "copy selection") in screen.GLOBAL_ROWS
    assert ("ctrl+t", "tickets tab") in screen.GLOBAL_ROWS
    assert ("ctrl+d", "daemon tab") in screen.GLOBAL_ROWS
    assert ("ctrl+q", "stop agent") in screen.GLOBAL_ROWS
    assert ("ctrl+c ctrl+c", "exit app") in screen.GLOBAL_ROWS

    chat_rows = screen._active_rows()
    assert ("q / esc", "stop agent") in chat_rows
    assert ("ctrl+c", "clear text input") in chat_rows
    assert ("f", "toggle follow") in chat_rows
    assert ("i", "focus input") in chat_rows
    assert ("v", "toggle verbose") in chat_rows
    assert ("ctrl+, / ctrl+.", "switch mode") not in chat_rows

    assert screen._section_title("chat") == "chat"
    assert screen.ESC_KEY_TEXT == "esc"
    assert screen.ESC_HINT_TEXT == "to close"
    assert screen.F1_KEY_TEXT == "f1"
    assert screen.F1_HINT_TEXT == "user guide"


def test_shortcuts_screen_includes_tab_specific_rows() -> None:
    """Compact shortcuts should show active-tab shortcuts only."""
    tickets_screen = ShortcutsScreen(active_tab="tickets")
    daemon_screen = ShortcutsScreen(active_tab="daemon")

    tickets_rows = tickets_screen._active_rows()
    assert ("r", "refresh tickets") in tickets_rows
    assert ("i", "open investigator") in tickets_rows
    assert ("c", "open copilot") in tickets_rows
    assert ("f", "toggle follow") not in tickets_rows

    daemon_rows = daemon_screen._active_rows()
    assert ("s", "start/stop") in daemon_rows
    assert ("r", "reconciler") in daemon_rows
    assert ("i", "investigator") in daemon_rows
    assert ("f", "toggle follow") not in daemon_rows


def test_shortcuts_screen_exposes_f1_binding_for_full_help() -> None:
    """Compact modal should bind F1 to opening full help."""
    bindings = {
        (
            binding[0] if isinstance(binding, tuple) else binding.key,
            binding[1] if isinstance(binding, tuple) else binding.action,
        )
        for binding in ShortcutsScreen.BINDINGS
    }

    assert ("f1", "open_full_help") in bindings
    assert ("escape", "close") in bindings
    assert ("ctrl+c", "app.confirm_exit") in bindings
