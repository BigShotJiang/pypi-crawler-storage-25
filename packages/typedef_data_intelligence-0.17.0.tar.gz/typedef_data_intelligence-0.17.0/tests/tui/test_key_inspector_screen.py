"""Tests for key inspector debug modal."""

from lineage.tui.screens.key_inspector import KeyInspectorScreen


def test_key_inspector_records_formatted_key_events() -> None:
    """Recorded key events should be formatted for easy diagnosis."""
    screen = KeyInspectorScreen()

    screen.record_key_data("ctrl+comma", ",", "Ctrl+,")

    assert screen.event_lines
    assert "key='ctrl+comma'" in screen.event_lines[-1]
    assert "character=','" in screen.event_lines[-1]


def test_key_inspector_keeps_recent_event_window() -> None:
    """Key inspector should keep only the most recent events."""
    screen = KeyInspectorScreen(max_events=3)

    screen.record_key_data("a", "a", "a")
    screen.record_key_data("b", "b", "b")
    screen.record_key_data("c", "c", "c")
    screen.record_key_data("d", "d", "d")

    assert len(screen.event_lines) == 3
    assert "key='a'" not in "\n".join(screen.event_lines)
    assert "key='d'" in screen.event_lines[-1]
