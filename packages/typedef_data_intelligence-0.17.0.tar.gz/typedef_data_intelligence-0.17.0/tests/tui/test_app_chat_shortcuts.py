"""Tests for app-level chat shortcut routing."""

from types import SimpleNamespace

import pytest
from lineage.tui.app import DataConciergeApp


def test_app_exposes_global_chat_shortcut_bindings() -> None:
    """App bindings should include chat shortcuts for active chat tabs."""
    bindings = {
        (
            binding[0] if isinstance(binding, tuple) else binding.key,
            binding[1] if isinstance(binding, tuple) else binding.action,
        )
        for binding in DataConciergeApp.BINDINGS
    }
    assert ("f", "toggle_follow") in bindings
    assert ("ctrl+a", "open_artifacts") in bindings
    assert ("ctrl+g", "open_activity") in bindings
    assert ("v", "toggle_verbose") in bindings
    assert ("ctrl+comma", "previous_chat_mode") in bindings
    assert ("ctrl+period", "next_chat_mode") in bindings
    assert ("ctrl+full_stop", "next_chat_mode") in bindings
    assert ("ctrl+h", "previous_chat_mode") in bindings
    assert ("ctrl+l", "next_chat_mode") in bindings
    assert ("ctrl+left", "previous_chat_mode") in bindings
    assert ("ctrl+right", "next_chat_mode") in bindings
    assert ("ctrl+t", "select_tickets_tab") in bindings
    assert ("ctrl+d", "select_daemon_tab") in bindings
    assert ("f1", "help") in bindings
    assert ("?", "shortcuts_help") in bindings
    assert ("ctrl+slash", "shortcuts_help") in bindings
    assert ("ctrl+question_mark", "shortcuts_help") in bindings
    assert ("?", "help") not in bindings
    assert ("ctrl+h", "help") not in bindings


def test_app_exposes_hidden_key_inspector_binding() -> None:
    """App should have a hidden binding to open key inspector."""
    hidden = [
        binding
        for binding in DataConciergeApp.BINDINGS
        if getattr(binding, "action", None) == "toggle_key_inspector"
    ]

    assert hidden
    keys = {getattr(binding, "key", None) for binding in hidden}
    assert {"ctrl+alt+k", "ctrl+shift+k", "f12"}.issubset(keys)
    assert all(getattr(binding, "show", True) is False for binding in hidden)


def test_app_chat_shortcuts_route_to_agent_chat_when_chat_tab_active() -> None:
    """Global chat actions should delegate to AgentChat in chat tabs."""
    app = DataConciergeApp.__new__(DataConciergeApp)
    calls: list[str] = []

    chat_child = SimpleNamespace(
        action_toggle_autoscroll=lambda: calls.append("f"),
        action_toggle_verbose=lambda: calls.append("v"),
        action_open_artifacts=lambda: calls.append("artifacts"),
        action_open_activity=lambda: calls.append("activity"),
    )

    def fake_query_one(selector, _type=None):
        if selector == "#main-content":
            return SimpleNamespace(active="chat")
        if selector == "#chat-container":
            return SimpleNamespace(children=[chat_child])
        raise AssertionError(f"Unexpected selector: {selector}")

    app.query_one = fake_query_one  # type: ignore[method-assign]

    app.action_toggle_follow()
    app.action_toggle_verbose()
    app.action_open_artifacts()
    app.action_open_activity()

    assert calls == ["f", "v", "artifacts", "activity"]


def test_app_chat_shortcuts_noop_when_not_on_chat_tab() -> None:
    """Global chat actions should no-op on non-chat tabs."""
    app = DataConciergeApp.__new__(DataConciergeApp)
    touched: list[bool] = []

    def fake_query_one(selector, _type=None):
        if selector == "#main-content":
            return SimpleNamespace(active="tickets")
        if selector.endswith("-container"):
            touched.append(True)
            return SimpleNamespace(children=[])
        raise AssertionError(f"Unexpected selector: {selector}")

    app.query_one = fake_query_one  # type: ignore[method-assign]

    app.action_toggle_follow()
    app.action_toggle_verbose()
    app.action_open_artifacts()
    app.action_open_activity()

    assert touched == []


def test_show_help_panel_routes_to_shortcuts_modal() -> None:
    """Command palette Keys action should use the shortcuts modal."""
    app = DataConciergeApp.__new__(DataConciergeApp)
    calls: list[bool] = []
    app.action_shortcuts_help = lambda: calls.append(True)  # type: ignore[method-assign]

    app.action_show_help_panel()

    assert calls == [True]


def test_system_keys_command_uses_shortcuts_modal_help_text(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """System command palette should expose Keys command wired to shortcuts modal."""
    app = DataConciergeApp.__new__(DataConciergeApp)

    def fake_get_system_commands(self, screen):
        del self, screen
        return [
            SimpleNamespace(
                title="Keys",
                help="Original help",
                callback=lambda: None,
                discover=True,
            ),
            SimpleNamespace(
                title="Other",
                help="Other help",
                callback=lambda: None,
                discover=True,
            ),
        ]

    monkeypatch.setattr(
        DataConciergeApp.__mro__[1],
        "get_system_commands",
        fake_get_system_commands,
    )
    app.query_one = lambda selector, _type=None: SimpleNamespace(  # type: ignore[method-assign]
        active="chat"
    )

    keys_commands = [
        command
        for command in app.get_system_commands(object())
        if command.title == "keys"
    ]

    assert len(keys_commands) == 1
    keys_command = keys_commands[0]
    assert keys_command.help == "show keyboard shortcuts"
    assert getattr(keys_command.callback, "__name__", "") == "action_shortcuts_help"


def test_system_new_chat_command_is_exposed_with_clear_help(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """System command palette should expose lowercase new chat command."""
    app = DataConciergeApp.__new__(DataConciergeApp)

    def fake_get_system_commands(self, screen):
        del self, screen
        return [
            SimpleNamespace(
                title="Keys",
                help="Original help",
                callback=lambda: None,
                discover=True,
            )
        ]

    monkeypatch.setattr(
        DataConciergeApp.__mro__[1],
        "get_system_commands",
        fake_get_system_commands,
    )
    app.query_one = lambda selector, _type=None: SimpleNamespace(  # type: ignore[method-assign]
        active="chat"
    )

    new_chat_commands = [
        command
        for command in app.get_system_commands(object())
        if command.title == "new chat"
    ]

    assert len(new_chat_commands) == 1
    new_chat_command = new_chat_commands[0]
    assert new_chat_command.help == "start a new chat session"
    assert getattr(new_chat_command.callback, "__name__", "") == "action_new_chat"


def test_system_new_chat_command_is_not_exposed_off_chat_tab(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """New chat command should not appear when active tab is not chat."""
    app = DataConciergeApp.__new__(DataConciergeApp)

    def fake_get_system_commands(self, screen):
        del self, screen
        return [
            SimpleNamespace(
                title="Keys",
                help="Original help",
                callback=lambda: None,
                discover=True,
            )
        ]

    monkeypatch.setattr(
        DataConciergeApp.__mro__[1],
        "get_system_commands",
        fake_get_system_commands,
    )
    app.query_one = lambda selector, _type=None: SimpleNamespace(  # type: ignore[method-assign]
        active="tickets"
    )

    new_chat_commands = [
        command
        for command in app.get_system_commands(object())
        if command.title == "new chat"
    ]

    assert new_chat_commands == []


def test_system_command_text_is_normalized_to_lowercase(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Command palette entries should be normalized to lowercase labels/help."""
    app = DataConciergeApp.__new__(DataConciergeApp)

    def fake_get_system_commands(self, screen):
        del self, screen
        return [
            SimpleNamespace(
                title="Maximize",
                help="Maximize the focused widget",
                callback=lambda: None,
                discover=True,
            ),
            SimpleNamespace(
                title="Theme",
                help="Change the current theme",
                callback=lambda: None,
                discover=True,
            ),
        ]

    monkeypatch.setattr(
        DataConciergeApp.__mro__[1],
        "get_system_commands",
        fake_get_system_commands,
    )
    app.query_one = lambda selector, _type=None: SimpleNamespace(  # type: ignore[method-assign]
        active="chat"
    )

    commands = app.get_system_commands(object())
    by_title = {command.title: command for command in commands}

    assert "maximize" in by_title
    assert by_title["maximize"].help == "maximize the focused widget"
    assert "theme" in by_title
    assert by_title["theme"].help == "change the current theme"


def test_action_command_palette_uses_lowercase_placeholder(monkeypatch) -> None:
    """Command palette placeholder should match lowercase style."""
    app = DataConciergeApp.__new__(DataConciergeApp)
    app.use_command_palette = True
    pushed: list[object] = []
    app.push_screen = lambda screen: pushed.append(screen)  # type: ignore[method-assign]

    class FakeCommandPalette:
        def __init__(self, *args, **kwargs):
            self.placeholder = kwargs.get("placeholder")
            self.id = kwargs.get("id")

        @classmethod
        def is_open(cls, _app):
            return False

    monkeypatch.setattr("lineage.tui.app.CommandPalette", FakeCommandPalette)

    app.action_command_palette()

    assert len(pushed) == 1
    palette = pushed[0]
    assert getattr(palette, "placeholder", None) == "search for commands..."
    assert getattr(palette, "id", None) == "--command-palette"


def test_action_new_chat_routes_to_chat_restart() -> None:
    """New chat action should delegate to active chat restart behavior."""
    app = DataConciergeApp.__new__(DataConciergeApp)
    restarted: list[bool] = []

    chat = SimpleNamespace(_restart_chat=lambda: restarted.append(True))
    app._active_agent_chat = lambda: chat  # type: ignore[method-assign]

    app.action_new_chat()

    assert restarted == [True]


def test_action_new_chat_noops_when_no_active_chat() -> None:
    """New chat action should no-op when no chat tab is active."""
    app = DataConciergeApp.__new__(DataConciergeApp)
    app._active_agent_chat = lambda: None  # type: ignore[method-assign]

    app.action_new_chat()


def test_system_status_command_is_exposed_on_chat_tab(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """System command palette should expose status command on chat tabs."""
    app = DataConciergeApp.__new__(DataConciergeApp)

    def fake_get_system_commands(self, screen):
        del self, screen
        return [
            SimpleNamespace(
                title="Keys",
                help="Original help",
                callback=lambda: None,
                discover=True,
            )
        ]

    monkeypatch.setattr(
        DataConciergeApp.__mro__[1],
        "get_system_commands",
        fake_get_system_commands,
    )
    app.query_one = lambda selector, _type=None: SimpleNamespace(  # type: ignore[method-assign]
        active="chat"
    )

    status_commands = [
        command
        for command in app.get_system_commands(object())
        if command.title == "status"
    ]

    assert len(status_commands) == 1
    status_command = status_commands[0]
    assert status_command.help == "show current session status"
    assert getattr(status_command.callback, "__name__", "") == "action_show_status"


def test_system_status_command_is_not_exposed_off_chat_tab(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Status command should not appear when active tab is not chat."""
    app = DataConciergeApp.__new__(DataConciergeApp)

    def fake_get_system_commands(self, screen):
        del self, screen
        return [
            SimpleNamespace(
                title="Keys",
                help="Original help",
                callback=lambda: None,
                discover=True,
            )
        ]

    monkeypatch.setattr(
        DataConciergeApp.__mro__[1],
        "get_system_commands",
        fake_get_system_commands,
    )
    app.query_one = lambda selector, _type=None: SimpleNamespace(  # type: ignore[method-assign]
        active="tickets"
    )

    status_commands = [
        command
        for command in app.get_system_commands(object())
        if command.title == "status"
    ]

    assert status_commands == []


def test_action_show_status_routes_to_chat_show_status() -> None:
    """Status action should delegate to active chat _show_status."""
    app = DataConciergeApp.__new__(DataConciergeApp)
    shown: list[bool] = []

    chat = SimpleNamespace(_show_status=lambda: shown.append(True))
    app._active_agent_chat = lambda: chat  # type: ignore[method-assign]

    app.action_show_status()

    assert shown == [True]


def test_action_show_status_noops_when_no_active_chat() -> None:
    """Status action should no-op when no chat tab is active."""
    app = DataConciergeApp.__new__(DataConciergeApp)
    app._active_agent_chat = lambda: None  # type: ignore[method-assign]

    app.action_show_status()
