"""Tests for active-agent header behavior in unified chat."""

from types import SimpleNamespace

import pytest
from lineage.tui.screens.chat import AgentChat, AgentPlaceholder, ChatArea
from lineage.tui.screens.placeholders import AGENT_CHOOSER_OPTIONS
from textual.app import App, ComposeResult


def test_agent_chat_initializes_display_title_from_placeholder_metadata() -> None:
    """Initial chat mode should expose a human-friendly agent title."""
    chat = AgentChat("insights", SimpleNamespace())

    assert chat.display_agent_title == "Data Insights"


def test_set_agent_mode_updates_header_title_and_backend_agent() -> None:
    """Switching modes should update visible title and backend agent target."""
    chat = AgentChat("analyst", SimpleNamespace())
    updated_titles: list[str] = []
    refreshed: list[bool] = []
    chat.chat_area = SimpleNamespace(
        update_agent_title=lambda title: updated_titles.append(title),
        refresh_placeholder=lambda: refreshed.append(True),
    )

    chat.set_agent_mode("copilot", "copilot-flat")

    assert chat.display_agent_name == "copilot"
    assert chat.display_agent_title == "Data Engineer Copilot"
    assert chat.agent_name == "copilot-flat"
    assert updated_titles == ["Data Engineer Copilot"]
    assert refreshed == [True]


def test_can_switch_mode_only_when_chat_is_fresh() -> None:
    """Mode switches should only be allowed when no conversation exists."""
    chat = AgentChat("analyst", SimpleNamespace())

    assert chat.can_switch_mode() is True

    chat.messages.append({"role": "user", "content": "hello"})

    assert chat.can_switch_mode() is False


def test_restart_chat_hides_agent_header_for_new_chat_screen() -> None:
    """Restarting chat should hide top agent header in empty placeholder state."""
    chat = AgentChat("copilot", SimpleNamespace())
    header_state = {"visible": True}

    chat.chat_area = SimpleNamespace(
        hide_agent_header=lambda: header_state.update(visible=False),
        chat_log=SimpleNamespace(remove_children=lambda: None),
        reset_placeholder=lambda: None,
        restore_placeholder=lambda: None,
    )
    chat.artifact_viewer = SimpleNamespace(clear_history=lambda: None)
    chat.messages = [{"role": "user", "content": "hello"}]

    chat._restart_chat()

    assert header_state["visible"] is False


def test_restart_chat_restores_agent_chooser_state() -> None:
    """Restarting chat should show chooser before agent-specific placeholder."""
    chat = AgentChat("copilot", SimpleNamespace())
    chooser_state = {"shown": False}

    chat.chat_area = SimpleNamespace(
        hide_agent_header=lambda: None,
        show_agent_chooser=lambda: chooser_state.update(shown=True),
        chat_log=SimpleNamespace(remove_children=lambda: None),
        reset_placeholder=lambda: None,
    )
    chat.artifact_viewer = SimpleNamespace(clear_history=lambda: None)
    chat.messages = [{"role": "user", "content": "hello"}]

    chat._restart_chat()

    assert chooser_state["shown"] is True


def test_restart_chat_skips_mounted_only_artifact_resets_when_unmounted() -> None:
    """Restart should avoid mounted-only artifact operations outside a running app."""
    chat = AgentChat("copilot", SimpleNamespace())

    chat.chat_area = SimpleNamespace(
        hide_agent_header=lambda: None,
        show_agent_chooser=lambda: None,
        chat_log=SimpleNamespace(remove_children=lambda: None),
        reset_placeholder=lambda: None,
    )
    chat._restore_artifact_viewer_mount = lambda: pytest.fail(
        "_restore_artifact_viewer_mount should not run when chat is unmounted"
    )
    chat.artifact_viewer = SimpleNamespace(
        clear_history=lambda: pytest.fail(
            "clear_history should not run when chat is unmounted"
        )
    )

    chat._restart_chat()


def test_restart_chat_runs_artifact_resets_when_mounted(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Restart should still run artifact reset operations when mounted."""
    chat = AgentChat("copilot", SimpleNamespace())
    calls: list[str] = []

    monkeypatch.setattr(AgentChat, "is_mounted", property(lambda _self: True))
    chat.chat_area = SimpleNamespace(
        hide_agent_header=lambda: None,
        show_agent_chooser=lambda: None,
        chat_log=SimpleNamespace(remove_children=lambda: None),
        reset_placeholder=lambda: None,
    )
    chat._restore_artifact_viewer_mount = lambda: calls.append("restore")
    chat.artifact_viewer = SimpleNamespace(clear_history=lambda: calls.append("clear"))

    chat._restart_chat()

    assert calls == ["restore", "clear"]


def test_agent_chooser_options_include_all_modes() -> None:
    """Agent chooser should expose all unified chat modes with helper copy."""
    options = {option["mode"]: option for option in AGENT_CHOOSER_OPTIONS}

    assert set(options) == {"analyst", "investigator", "insights", "copilot"}
    assert all(options[mode]["label"].strip() for mode in options)
    assert all(options[mode]["summary"].strip() for mode in options)
    assert all(not options[mode]["summary"].endswith(".") for mode in options)


def test_chooser_selection_sets_mode_then_shows_agent_placeholder() -> None:
    """Chooser confirmation should update app chat mode and render agent placeholder."""
    chat = AgentChat("analyst", SimpleNamespace())
    selected_modes: list[str] = []
    placeholder_state = {"shown": False}

    chat.set_agent_mode = lambda mode: selected_modes.append(mode)  # type: ignore[method-assign]
    chat.chat_area = SimpleNamespace(
        show_agent_placeholder=lambda: placeholder_state.update(shown=True)
    )
    chat._refresh_status_bar_hint = lambda: None

    event = AgentPlaceholder.AgentSelected("copilot")
    chat.on_agent_placeholder_agent_selected(event)

    assert selected_modes == ["copilot"]
    assert placeholder_state["shown"] is True


def test_chooser_selection_triggers_new_chat_tip() -> None:
    """Chooser confirmation should trigger app-level /new tip notification helper."""
    chat = AgentChat("analyst", SimpleNamespace())
    tip_calls: list[bool] = []

    app = SimpleNamespace(
        _set_chat_mode=lambda mode: None,
        maybe_show_new_chat_tip=lambda: tip_calls.append(True),
    )
    chat._app = app  # type: ignore[attr-defined]
    chat.set_agent_mode = lambda mode: None  # type: ignore[method-assign]
    chat.chat_area = SimpleNamespace(show_agent_placeholder=lambda: None)
    chat._refresh_status_bar_hint = lambda: None

    event = AgentPlaceholder.AgentSelected("copilot")
    chat.on_agent_placeholder_agent_selected(event)

    assert tip_calls == [True]


def test_focus_input_targets_chooser_when_chooser_visible() -> None:
    """focus_input should return keyboard focus to chooser list when active."""
    chat = AgentChat("analyst", SimpleNamespace())
    focused = {"chooser": False, "input": False}
    chooser_list = SimpleNamespace(focus=lambda: focused.update(chooser=True))
    placeholder = SimpleNamespace(is_chooser=True, _chooser_list=chooser_list)

    chat.chat_area = SimpleNamespace(
        _placeholder=placeholder,
        input=SimpleNamespace(focus=lambda: focused.update(input=True)),
    )

    chat.focus_input()

    assert focused["chooser"] is True
    assert focused["input"] is False


def test_agent_chooser_selection_applies_active_highlight_class() -> None:
    """Chooser should keep a visible active-row class for keyboard selection."""
    chooser = AgentPlaceholder("analyst", chooser=True)

    chooser.set_selected_mode("insights")

    active_rows = [
        idx
        for idx, item in enumerate(chooser._chooser_items)
        if item.has_class("agent-choice-active")
    ]
    assert active_rows == [2]


def test_agent_chooser_highlight_event_updates_active_row() -> None:
    """Chooser highlight should track ListView highlight changes exactly."""
    chooser = AgentPlaceholder("analyst", chooser=True)

    chooser.on_list_view_highlighted(
        SimpleNamespace(list_view=SimpleNamespace(id="agent-chooser-list", index=1))
    )

    active_rows = [
        idx
        for idx, item in enumerate(chooser._chooser_items)
        if item.has_class("agent-choice-active")
    ]
    assert active_rows == [1]


def test_agent_chooser_hint_text_is_plain_not_bold() -> None:
    """Chooser helper line should emphasize key bindings consistently."""
    hint = AgentPlaceholder.CHOOSER_HINT_TEXT

    assert "[bold]up/down[/bold]" in hint
    assert "[bold]enter[/bold]" in hint
    assert "[bold]1-4[/bold]" in hint


def test_chat_input_hints_include_new_chat_tip() -> None:
    """Main chat input hint should explain how to start a fresh chat."""
    assert "tip: use /new to start a new chat session" in ChatArea.INPUT_HINT_TEXT


def test_chat_busy_hint_explains_unlock_and_stop_keys() -> None:
    """Busy hint should explain when input unlocks and how to stop the run."""
    assert "input unlocks when response completes" in ChatArea.INPUT_BUSY_HINT_TEXT
    assert "ctrl+q" in ChatArea.INPUT_BUSY_ACTION_TEXT


def test_agent_placeholder_input_hints_include_new_chat_tip() -> None:
    """Starter placeholder hint should include /new discoverability copy."""
    assert (
        "tip: use /new to start a new chat session" in AgentPlaceholder.INPUT_HINT_TEXT
    )


def test_set_input_busy_toggles_affordance_classes_and_hint_text() -> None:
    """Busy state should swap hint copy and toggle input-bar/input classes."""
    chat_area = ChatArea(SimpleNamespace(agent_name="analyst"))
    updates: list[str] = []
    bar_calls: list[tuple[str, str]] = []
    input_calls: list[tuple[str, str]] = []
    hint_class_calls: list[tuple[str, str]] = []
    action_updates: list[str] = []
    timer_stops: list[bool] = []

    timer = SimpleNamespace(stop=lambda: timer_stops.append(True))
    chat_area.set_interval = lambda interval, callback: timer  # type: ignore[method-assign]

    chat_area._input_bar = SimpleNamespace(
        add_class=lambda name: bar_calls.append(("add", name)),
        remove_class=lambda name: bar_calls.append(("remove", name)),
    )
    chat_area.input = SimpleNamespace(
        add_class=lambda name: input_calls.append(("add", name)),
        remove_class=lambda name: input_calls.append(("remove", name)),
    )
    chat_area._input_hints = SimpleNamespace(
        update=lambda text: updates.append(text),
        add_class=lambda name: hint_class_calls.append(("add", name)),
        remove_class=lambda name: hint_class_calls.append(("remove", name)),
    )

    class ActionStub:
        def __init__(self) -> None:
            self.display = False

        def update(self, text: str) -> None:
            action_updates.append(text)

    chat_area._input_hints_action = ActionStub()

    chat_area.set_input_busy(True)
    first_busy_text = updates[-1]
    chat_area._advance_busy_hint_spinner()
    second_busy_text = updates[-1]
    chat_area.set_input_busy(False)

    assert first_busy_text == ChatArea.INPUT_BUSY_HINT_TEXT
    assert second_busy_text != first_busy_text
    assert "agent is working..." in second_busy_text
    assert updates[-1] == ChatArea.INPUT_HINT_TEXT
    assert bar_calls == [
        ("add", "input-bar-busy"),
        ("remove", "input-bar-busy"),
    ]
    assert input_calls == [
        ("add", "chat-input-busy"),
        ("remove", "chat-input-busy"),
    ]
    assert hint_class_calls == [
        ("add", "input-hints-busy"),
        ("remove", "input-hints-busy"),
    ]
    assert action_updates == [ChatArea.INPUT_BUSY_ACTION_TEXT]
    assert chat_area._input_hints_action.display is False
    assert timer_stops == [True]


@pytest.mark.asyncio
async def test_agent_placeholder_intro_is_wrapped_for_centering() -> None:
    """Intro text should sit inside a dedicated centering wrapper container."""

    class PlaceholderHarness(App[None]):
        def compose(self) -> ComposeResult:
            yield AgentPlaceholder("analyst")

    app = PlaceholderHarness()
    async with app.run_test():
        intro = app.query_one(".placeholder-intro")
        assert intro.parent is not None
        assert intro.parent.has_class("placeholder-intro-row")
        assert intro.parent.parent is not None
        assert intro.parent.parent.has_class("placeholder-intro-wrap")
