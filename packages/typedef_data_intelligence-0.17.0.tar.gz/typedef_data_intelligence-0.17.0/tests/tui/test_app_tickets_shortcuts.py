"""Tests for app-level Tickets shortcut routing."""

from types import SimpleNamespace
from typing import Any

import pytest
from lineage.tui.app import DataConciergeApp


def test_app_exposes_global_refresh_binding() -> None:
    """App bindings should include refresh shortcut for Tickets tab."""
    keys = {
        binding[0] if isinstance(binding, tuple) else binding.key
        for binding in DataConciergeApp.BINDINGS
    }
    assert "r" in keys


@pytest.mark.asyncio
async def test_app_refresh_shortcut_routes_to_tickets_screen_when_active() -> None:
    """Global refresh action should delegate to Tickets screen when active."""
    app: Any = DataConciergeApp.__new__(DataConciergeApp)
    called: list[bool] = []

    tickets_child = SimpleNamespace(action_refresh_tickets=lambda: called.append(True))

    def fake_query_one(selector, _type=None):
        if selector == "#main-content":
            return SimpleNamespace(active="tickets")
        if selector == "#tickets-container":
            return SimpleNamespace(children=[tickets_child])
        raise AssertionError(f"Unexpected selector: {selector}")

    app.query_one = fake_query_one  # type: ignore[method-assign]

    app._ticketing_available = True
    app._mounted_aux_tabs = {"tickets"}

    await app.action_refresh_tickets()

    assert called == [True]


@pytest.mark.asyncio
async def test_app_refresh_shortcut_noop_when_not_on_tickets_tab() -> None:
    """Global refresh action should no-op outside Tickets tab."""
    app: Any = DataConciergeApp.__new__(DataConciergeApp)
    called: list[bool] = []

    def fake_query_one(selector, _type=None):
        if selector == "#main-content":
            return SimpleNamespace(active="analyst")
        if selector == "#tickets-container":
            called.append(True)
            return SimpleNamespace(children=[])
        raise AssertionError(f"Unexpected selector: {selector}")

    app.query_one = fake_query_one  # type: ignore[method-assign]

    app._ticketing_available = True
    app._mounted_aux_tabs = {"tickets"}

    await app.action_refresh_tickets()

    assert called == []


@pytest.mark.asyncio
async def test_app_select_tickets_tab_shortcut_activates_tickets() -> None:
    """Ctrl+T action should switch to Tickets tab when available."""
    app: Any = DataConciergeApp.__new__(DataConciergeApp)
    app._ticketing_available = True
    tabbed = SimpleNamespace(active="chat")
    app._mounted_aux_tabs = {"tickets"}
    app._aux_mount_tasks = {}
    app.query_one = lambda selector, _type=None: tabbed  # type: ignore[method-assign]

    await app.action_select_tickets_tab()

    assert tabbed.active == "tickets"


@pytest.mark.asyncio
async def test_app_select_tickets_tab_mounts_screen_on_first_use() -> None:
    """Ctrl+T should mount Tickets screen before first routed use."""
    app: Any = DataConciergeApp.__new__(DataConciergeApp)
    app._ticketing_available = True
    app.client = object()
    app._mounted_aux_tabs = set()
    app._aux_mount_tasks = {}

    mounted: list[object] = []
    tabbed = SimpleNamespace(active="chat")

    class _Container:
        def __init__(self) -> None:
            self.children: list[object] = []

        async def mount(self, widget: object, *_args, **_kwargs) -> object:
            self.children.append(widget)
            mounted.append(widget)
            return widget

    container = _Container()

    def fake_query_one(selector, _type=None):
        if selector == "#main-content":
            return tabbed
        if selector == "#tickets-container":
            return container
        raise AssertionError(f"Unexpected selector: {selector}")

    app.query_one = fake_query_one  # type: ignore[method-assign]

    await app.action_select_tickets_tab()

    assert tabbed.active == "tickets"
    assert len(mounted) == 1
    assert "tickets" in app._mounted_aux_tabs


@pytest.mark.asyncio
async def test_select_investigator_on_tickets_tab_keeps_existing_routing() -> None:
    """i on Tickets tab should still delegate to open investigator."""
    app: Any = DataConciergeApp.__new__(DataConciergeApp)
    called: list[bool] = []

    tickets_child = SimpleNamespace(
        action_open_investigator=lambda: called.append(True)
    )

    def fake_query_one(selector, _type=None):
        if selector == "#main-content":
            return SimpleNamespace(active="tickets")
        if selector == "#tickets-container":
            return SimpleNamespace(children=[tickets_child])
        raise AssertionError(f"Unexpected selector: {selector}")

    app.query_one = fake_query_one  # type: ignore[method-assign]

    app._ticketing_available = True
    app._mounted_aux_tabs = {"tickets"}

    await app.action_select_investigator()

    assert called == [True]
