"""Tests for Daemon keyboard-first control flow."""

import asyncio
from types import SimpleNamespace

from lineage.tui.screens.daemon import DaemonScreen


def test_daemon_screen_has_local_keyboard_shortcuts() -> None:
    """Daemon tab should expose keyboard shortcuts for control actions."""
    binding_keys = {binding[0] for binding in DaemonScreen.BINDINGS}
    assert {"s", "r", "i"}.issubset(binding_keys)


def test_daemon_toggle_shortcut_starts_when_stopped(monkeypatch) -> None:
    """Pressing s should schedule daemon start when currently stopped."""
    screen = DaemonScreen(SimpleNamespace())
    created = []

    async def fake_start_daemon() -> None:
        return None

    def fake_create_task(coro):
        created.append(coro)
        coro.close()
        return SimpleNamespace()

    screen.start_daemon = fake_start_daemon  # type: ignore[method-assign]
    monkeypatch.setattr(asyncio, "create_task", fake_create_task)

    screen.action_toggle_daemon()

    assert len(created) == 1


def test_daemon_select_shortcuts_update_agent_label(monkeypatch) -> None:
    """r and i shortcuts should update active agent in status label."""
    screen = DaemonScreen(SimpleNamespace())

    class FakeLabel:
        text = ""

        def update(self, text: str) -> None:
            self.text = text

        def add_class(self, _class_name: str) -> None:
            return None

        def remove_class(self, _class_name: str) -> None:
            return None

    class FakeLog:
        def log_info(self, _text: str) -> None:
            return None

    status = FakeLabel()
    log = FakeLog()

    def fake_query_one(selector, _type=None):
        if selector == "#daemon-status":
            return status
        if selector == "#daemon-log":
            return log
        raise AssertionError(f"Unexpected selector: {selector}")

    screen.query_one = fake_query_one  # type: ignore[method-assign]

    screen.action_select_investigator()
    assert "Investigator" in status.text

    screen.action_select_reconciler()
    assert "Reconciler" in status.text


def test_daemon_status_line_toggles_running_and_stopped_classes() -> None:
    """Status label should flip classes as daemon state changes."""
    screen = DaemonScreen(SimpleNamespace())

    class FakeLabel:
        def __init__(self) -> None:
            self.text = ""
            self.classes: set[str] = {"daemon-status"}

        def update(self, text: str) -> None:
            self.text = text

        def add_class(self, class_name: str) -> None:
            self.classes.add(class_name)

        def remove_class(self, class_name: str) -> None:
            self.classes.discard(class_name)

    class FakeRunningTask:
        @staticmethod
        def done() -> bool:
            return False

    status = FakeLabel()

    screen.query_one = lambda selector, _type=None: status  # type: ignore[method-assign]

    screen._daemon_task = None
    screen._update_status_line()
    assert "daemon-status-stopped" in status.classes
    assert "daemon-status-running" not in status.classes
    assert "│" not in status.text
    assert "Daemon:" in status.text
    assert "Agent:" in status.text
    assert status.text.startswith("○ ")

    screen._daemon_task = FakeRunningTask()  # type: ignore[assignment]
    screen._update_status_line()
    assert "daemon-status-running" in status.classes
    assert "daemon-status-stopped" not in status.classes
    assert "│" not in status.text
    assert status.text.startswith("● ")
