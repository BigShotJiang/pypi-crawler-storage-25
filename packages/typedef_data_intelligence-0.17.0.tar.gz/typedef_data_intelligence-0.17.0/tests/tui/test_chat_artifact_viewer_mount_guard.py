"""Tests for AgentChat artifact viewer remount guards."""

from types import SimpleNamespace

from lineage.tui.screens.chat import AgentChat


class _MountedStateChat(AgentChat):
    """AgentChat test double with controllable mounted state."""

    def __init__(self) -> None:
        super().__init__("analyst", SimpleNamespace())
        self._mounted_state = False

    @property
    def is_mounted(self) -> bool:
        return self._mounted_state


def test_restore_artifact_viewer_mount_noops_when_chat_is_not_mounted() -> None:
    """Restoring mount should no-op outside mounted screen context."""
    chat = _MountedStateChat()
    mount_calls: list[object] = []
    scheduled_calls: list[object] = []

    chat._artifact_viewer_holder = SimpleNamespace(
        is_mounted=False,
        mount=lambda widget: mount_calls.append(widget),
    )
    chat.call_after_refresh = lambda fn: scheduled_calls.append(fn)  # type: ignore[method-assign]

    chat._restore_artifact_viewer_mount()

    assert mount_calls == []
    assert scheduled_calls == []


def test_restore_artifact_viewer_mount_does_not_schedule_when_unmounted_after_failure() -> (
    None
):
    """Failed remount should not schedule retry once chat is unmounted."""
    chat = _MountedStateChat()
    chat._mounted_state = True
    scheduled_calls: list[object] = []

    def fail_mount(_widget: object) -> None:
        chat._mounted_state = False
        raise RuntimeError("simulated mount failure")

    chat._artifact_viewer_holder = SimpleNamespace(is_mounted=True, mount=fail_mount)
    chat.call_after_refresh = lambda fn: scheduled_calls.append(fn)  # type: ignore[method-assign]

    chat._restore_artifact_viewer_mount()

    assert scheduled_calls == []
