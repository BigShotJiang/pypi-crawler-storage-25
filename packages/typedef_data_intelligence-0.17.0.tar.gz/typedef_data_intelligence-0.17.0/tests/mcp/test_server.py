"""Tests for the unified MCP server factory and dbt tool registration."""

from __future__ import annotations

import asyncio
import inspect
from typing import Optional, Protocol
from unittest.mock import AsyncMock, Mock, patch

import pytest
from core.backends.data_query.protocol import DataQueryBackend
from core.backends.mcp_auto import auto_expose_protocol
from fastmcp import FastMCP
from lineage.mcp.server import (
    _DATA_QUERY_EXCLUDE,
    _LINEAGE_EXCLUDE,
    create_unified_server,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _tool_names(mcp) -> set[str]:
    """Return the set of registered tool names on a FastMCP server."""
    tools = await mcp.get_tools()
    return set(tools.keys())


def _mock_data_backend() -> Mock:
    return Mock(spec=DataQueryBackend)


# ---------------------------------------------------------------------------
# TestExcludeSets
# ---------------------------------------------------------------------------


class TestExcludeSets:
    """Verify the exclude sets contain expected entries."""

    def test_lineage_exclude_contains_write_ops(self):
        expected = {
            "upsert_node",
            "create_edge",
            "recreate_schema",
            "ensure_schema",
            "bulk_load",
            "delete_model_cascade",
            "close",
        }
        assert expected.issubset(_LINEAGE_EXCLUDE)

    def test_lineage_exclude_does_not_block_read_methods(self):
        read_methods = {
            "find_upstream",
            "get_job",
            "get_dataset",
            "model_has_pii",
            "get_model_business_measure_count",
            "get_model_business_dimension_count",
        }
        assert _LINEAGE_EXCLUDE.isdisjoint(read_methods)

    def test_data_query_exclude(self):
        assert "get_backend_type" in _DATA_QUERY_EXCLUDE


# ---------------------------------------------------------------------------
# TestCreateUnifiedServer
# ---------------------------------------------------------------------------


class TestCreateUnifiedServer:
    """Tests for create_unified_server factory."""

    @pytest.mark.asyncio
    async def test_creates_server_with_lineage_only(self, mock_storage):
        mcp = create_unified_server(lineage_backend=mock_storage)
        names = await _tool_names(mcp)
        # Should have at least one lineage tool and no dbt tools
        assert len(names) > 0
        assert "dbt_cli" not in names
        assert "get_dbt_project_path" not in names
        # None of the excluded methods should be registered
        assert names.isdisjoint(_LINEAGE_EXCLUDE)

    @pytest.mark.asyncio
    async def test_creates_server_with_data_backend(self, mock_storage):
        data = _mock_data_backend()
        mcp = create_unified_server(
            lineage_backend=mock_storage,
            data_backend=data,
        )
        names = await _tool_names(mcp)
        # Data query tools should be present
        assert "execute_query" in names
        # Excluded data query methods must not appear
        assert names.isdisjoint(_DATA_QUERY_EXCLUDE)

    @pytest.mark.asyncio
    async def test_no_data_tools_when_none(self, mock_storage):
        mcp = create_unified_server(
            lineage_backend=mock_storage,
            data_backend=None,
        )
        names = await _tool_names(mcp)
        # execute_query is a DataQueryBackend-only method
        assert "execute_query" not in names

    @pytest.mark.asyncio
    async def test_custom_server_name(self, mock_storage):
        mcp = create_unified_server(
            lineage_backend=mock_storage,
            name="my-custom-server",
        )
        assert mcp.name == "my-custom-server"


# ---------------------------------------------------------------------------
# TestDbtToolRegistration
# ---------------------------------------------------------------------------


class TestDbtToolRegistration:
    """Tests for dbt CLI tool registration."""

    @pytest.mark.asyncio
    async def test_dbt_tools_registered(self, mock_storage, tmp_path):
        mcp = create_unified_server(
            lineage_backend=mock_storage,
            dbt_project_path=str(tmp_path),
        )
        names = await _tool_names(mcp)
        expected_dbt_tools = {
            "get_dbt_project_path",
            "dbt_cli",
            "dbt_compile",
            "dbt_build",
            "dbt_test",
        }
        assert expected_dbt_tools.issubset(names)

    @pytest.mark.asyncio
    async def test_no_dbt_tools_when_path_none(self, mock_storage):
        mcp = create_unified_server(
            lineage_backend=mock_storage,
            dbt_project_path=None,
        )
        names = await _tool_names(mcp)
        assert "dbt_cli" not in names

    def test_invalid_dbt_project_path_raises(self, mock_storage):
        with pytest.raises(ValueError, match="does not exist"):
            create_unified_server(
                lineage_backend=mock_storage,
                dbt_project_path="/nonexistent/dbt/project",
            )

    def test_invalid_profiles_dir_raises(self, mock_storage, tmp_path):
        with pytest.raises(ValueError, match="profiles directory"):
            create_unified_server(
                lineage_backend=mock_storage,
                dbt_project_path=str(tmp_path),
                dbt_profiles_dir="/nonexistent/profiles/dir",
            )

    @pytest.mark.asyncio
    async def test_profiles_dir_from_project_path(self, mock_storage, tmp_path):
        (tmp_path / "profiles.yml").write_text("config: {}")
        mcp = create_unified_server(
            lineage_backend=mock_storage,
            dbt_project_path=str(tmp_path),
        )
        names = await _tool_names(mcp)
        assert "dbt_cli" in names


# ---------------------------------------------------------------------------
# TestDbtToolExecution
# ---------------------------------------------------------------------------


class TestDbtToolExecution:
    """Tests for the actual execution of registered dbt tools."""

    @pytest.fixture
    def dbt_server(self, mock_storage, tmp_path):
        """Create a server with dbt tools registered against tmp_path."""
        return create_unified_server(
            lineage_backend=mock_storage,
            dbt_project_path=str(tmp_path),
        )

    @pytest.fixture
    def dbt_server_with_profiles(self, mock_storage, tmp_path):
        """Create a server with dbt tools and profiles.yml present."""
        (tmp_path / "profiles.yml").write_text("config: {}")
        return create_unified_server(
            lineage_backend=mock_storage,
            dbt_project_path=str(tmp_path),
        )

    @pytest.mark.asyncio
    async def test_get_dbt_project_path_returns_paths(self, dbt_server, tmp_path):
        tools = await dbt_server.get_tools()
        tool_fn = tools["get_dbt_project_path"].fn
        result = tool_fn()
        assert result["project_path"] == str(tmp_path.resolve())
        assert result["models_path"] == str(tmp_path.resolve() / "models")

    @pytest.mark.asyncio
    async def test_dbt_cli_runs_command(self, dbt_server):
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"ok stdout", b"ok stderr")
        mock_proc.returncode = 0

        with patch("asyncio.create_subprocess_exec", return_value=mock_proc) as mock_exec:
            tools = await dbt_server.get_tools()
            result = await tools["dbt_cli"].fn(args=["run", "--select", "my_model"])

        mock_exec.assert_called_once()
        call_args = mock_exec.call_args[0]
        assert any("dbt" in str(a) for a in call_args)  # resolve_dbt_cmd may return full venv path
        assert "run" in call_args
        assert "--select" in call_args
        assert "my_model" in call_args
        assert result["exit_code"] == 0
        assert result["stdout"] == "ok stdout"
        assert "command" in result
        assert "working_dir" in result

    @pytest.mark.asyncio
    async def test_dbt_cli_handles_missing_executable(self, dbt_server):
        with patch(
            "asyncio.create_subprocess_exec",
            side_effect=FileNotFoundError("dbt not found"),
        ):
            tools = await dbt_server.get_tools()
            result = await tools["dbt_cli"].fn(args=["run"])

        assert result["exit_code"] == -1
        assert "not found" in result["stderr"]
        assert "command" in result
        assert "working_dir" in result

    @pytest.mark.asyncio
    async def test_dbt_cli_handles_timeout(self, dbt_server):
        mock_proc = AsyncMock()
        mock_proc.communicate.side_effect = asyncio.TimeoutError()
        mock_proc.kill = Mock()

        with patch("asyncio.create_subprocess_exec", return_value=mock_proc):
            with patch("asyncio.wait_for", side_effect=asyncio.TimeoutError()):
                tools = await dbt_server.get_tools()
                result = await tools["dbt_cli"].fn(args=["run"], timeout_s=1)

        assert result["exit_code"] == -1
        assert "timed out" in result["stderr"].lower()
        assert "command" in result
        assert "working_dir" in result

    @pytest.mark.asyncio
    async def test_dbt_compile_constructs_correct_args(self, dbt_server):
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"compiled", b"")
        mock_proc.returncode = 0

        with patch("asyncio.create_subprocess_exec", return_value=mock_proc) as mock_exec:
            tools = await dbt_server.get_tools()
            await tools["dbt_compile"].fn(select="my_model")

        call_args = mock_exec.call_args[0]
        # resolve_dbt_cmd may prefix with ["uv", "run", "--no-project"] when uv is available
        assert call_args[-3:] == ("compile", "--select", "my_model")
        assert any("dbt" in str(a) for a in call_args)  # resolve_dbt_cmd may return full venv path

    @pytest.mark.asyncio
    async def test_dbt_build_with_fail_fast(self, dbt_server):
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"built", b"")
        mock_proc.returncode = 0

        with patch("asyncio.create_subprocess_exec", return_value=mock_proc) as mock_exec:
            tools = await dbt_server.get_tools()
            await tools["dbt_build"].fn(select="my_model", fail_fast=True)

        call_args = mock_exec.call_args[0]
        assert "--fail-fast" in call_args

    @pytest.mark.asyncio
    async def test_dbt_build_without_fail_fast(self, dbt_server):
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"built", b"")
        mock_proc.returncode = 0

        with patch("asyncio.create_subprocess_exec", return_value=mock_proc) as mock_exec:
            tools = await dbt_server.get_tools()
            await tools["dbt_build"].fn(select="my_model", fail_fast=False)

        call_args = mock_exec.call_args[0]
        assert "--fail-fast" not in call_args

    @pytest.mark.asyncio
    async def test_dbt_test_constructs_correct_args(self, dbt_server):
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"tested", b"")
        mock_proc.returncode = 0

        with patch("asyncio.create_subprocess_exec", return_value=mock_proc) as mock_exec:
            tools = await dbt_server.get_tools()
            await tools["dbt_test"].fn(select="my_model")

        call_args = mock_exec.call_args[0]
        # resolve_dbt_cmd may prefix with ["uv", "run", "--no-project"] when uv is available
        assert call_args[-3:] == ("test", "--select", "my_model")
        assert any("dbt" in str(a) for a in call_args)  # resolve_dbt_cmd may return full venv path

    @pytest.mark.asyncio
    async def test_profiles_dir_passed_via_env(self, dbt_server_with_profiles, tmp_path):
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"ok", b"")
        mock_proc.returncode = 0

        with patch("asyncio.create_subprocess_exec", return_value=mock_proc) as mock_exec:
            tools = await dbt_server_with_profiles.get_tools()
            await tools["dbt_cli"].fn(args=["run"])

        call_args = mock_exec.call_args[0]
        call_kwargs = mock_exec.call_args[1]
        # --profiles-dir should NOT appear in the command (avoids agent mimicry)
        assert "--profiles-dir" not in call_args
        # Instead, DBT_PROFILES_DIR should be set in the subprocess env
        assert call_kwargs.get("env", {}).get("DBT_PROFILES_DIR") == str(tmp_path.resolve())


# ---------------------------------------------------------------------------
# TestAutoExposeAnnotationResolution
# ---------------------------------------------------------------------------


class _SampleProtocol(Protocol):
    """Protocol with ``from __future__ import annotations`` for testing resolution."""

    def sync_method(self, name: str, count: int) -> Optional[str]:
        """A sync method with typed params."""
        ...

    async def async_method(self, query: str, limit: int) -> list[str]:
        """An async method with typed params."""
        ...


class TestAutoExposeAnnotationResolution:
    """Verify that auto_expose_protocol resolves string annotations correctly."""

    @pytest.mark.asyncio
    async def test_sync_wrapper_has_resolved_annotations(self):
        backend = Mock()
        backend.sync_method = Mock(return_value="hello")
        mcp = FastMCP("test-annotations")

        auto_expose_protocol(
            mcp=mcp,
            backend=backend,
            protocol_class=_SampleProtocol,
        )

        tools = await mcp.get_tools()
        assert "sync_method" in tools
        wrapper = tools["sync_method"].fn
        # Verify annotations are actual types, not strings
        hints = wrapper.__annotations__
        assert hints["name"] is str
        assert hints["count"] is int
        # Verify signature parameters are resolved
        sig = inspect.signature(wrapper)
        assert sig.parameters["name"].annotation is str
        assert sig.parameters["count"].annotation is int

    @pytest.mark.asyncio
    async def test_async_wrapper_has_resolved_annotations(self):
        backend = Mock()
        backend.async_method = AsyncMock(return_value=["a", "b"])
        mcp = FastMCP("test-annotations")

        auto_expose_protocol(
            mcp=mcp,
            backend=backend,
            protocol_class=_SampleProtocol,
        )

        tools = await mcp.get_tools()
        assert "async_method" in tools
        wrapper = tools["async_method"].fn
        # Verify annotations are actual types, not strings
        hints = wrapper.__annotations__
        assert hints["query"] is str
        assert hints["limit"] is int
        # Verify the wrapper is async
        assert inspect.iscoroutinefunction(wrapper)
