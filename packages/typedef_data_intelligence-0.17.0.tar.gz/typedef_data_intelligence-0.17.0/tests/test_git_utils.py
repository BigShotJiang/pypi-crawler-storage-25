from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock, patch

import pytest
from lineage.utils.git import CloneProgress, clone_repo_with_progress


class _FakeStderr:
    def __init__(self, *chunks: bytes) -> None:
        self._chunks = list(chunks)

    async def read(self, _size: int) -> bytes:
        if self._chunks:
            return self._chunks.pop(0)
        return b""


class _FakeProc:
    def __init__(self, stderr: _FakeStderr, exit_code: int) -> None:
        self.stderr = stderr
        self._exit_code = exit_code

    async def wait(self) -> int:
        return self._exit_code


@pytest.mark.asyncio
async def test_clone_repo_with_progress_keeps_newline_terminated_git_failure(
    tmp_path: Path,
) -> None:
    proc = _FakeProc(
        _FakeStderr(
            b"Receiving objects:  67% (835/1247)\r",
            b"fatal: repository 'https://github.com/typedef-ai/missing.git/' not found\n",
        ),
        exit_code=128,
    )
    events: list[CloneProgress] = []

    with patch("asyncio.create_subprocess_exec", AsyncMock(return_value=proc)):
        with pytest.raises(
            RuntimeError,
            match="repository 'https://github.com/typedef-ai/missing.git/' not found",
        ):
            async for progress in clone_repo_with_progress(
                "https://github.com/typedef-ai/missing.git",
                tmp_path / "repo",
            ):
                events.append(progress)

    assert events[-1] == CloneProgress(
        phase="error",
        percent=0,
        message="fatal: repository 'https://github.com/typedef-ai/missing.git/' not found",
    )


@pytest.mark.asyncio
async def test_clone_repo_with_progress_preserves_full_git_failure_output(
    tmp_path: Path,
) -> None:
    proc = _FakeProc(
        _FakeStderr(
            b"remote: Repository not found.\n",
            b"fatal: repository 'https://github.com/typedef-ai/missing.git/' not found\n",
        ),
        exit_code=128,
    )
    events: list[CloneProgress] = []

    with patch("asyncio.create_subprocess_exec", AsyncMock(return_value=proc)):
        with pytest.raises(
            RuntimeError,
            match="remote: Repository not found.\nfatal: repository",
        ):
            async for progress in clone_repo_with_progress(
                "https://github.com/typedef-ai/missing.git",
                tmp_path / "repo",
            ):
                events.append(progress)

    assert (
        events[-1].message
        == "remote: Repository not found.\nfatal: repository 'https://github.com/typedef-ai/missing.git/' not found"
    )


@pytest.mark.asyncio
async def test_clone_repo_with_progress_logs_redacted_failure_summary(
    tmp_path: Path,
) -> None:
    proc = _FakeProc(
        _FakeStderr(
            b"fatal: unable to access 'https://user:ghp_secret@example.com/private.git/': The requested URL returned error: 403\n",
            b"remote: additional detail that should not be logged at error level\n",
        ),
        exit_code=128,
    )

    with patch("asyncio.create_subprocess_exec", AsyncMock(return_value=proc)):
        with patch("lineage.utils.git.logger") as mock_logger:
            with pytest.raises(RuntimeError):
                async for _ in clone_repo_with_progress(
                    "https://example.com/private.git",
                    tmp_path / "repo",
                ):
                    pass

    mock_logger.error.assert_called_once_with(
        "git clone failed (exit %s): %s",
        128,
        "fatal: unable to access 'https://example.com/private.git/': The requested URL returned error: 403",
    )
    mock_logger.debug.assert_called_once_with(
        "git clone full stderr (exit %s):\n%s",
        128,
        "fatal: unable to access 'https://user:ghp_secret@example.com/private.git/': The requested URL returned error: 403\nremote: additional detail that should not be logged at error level",
    )
