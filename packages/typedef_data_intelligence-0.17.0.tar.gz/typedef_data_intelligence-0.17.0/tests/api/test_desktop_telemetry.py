"""Tests for telemetry preference helpers and API endpoints."""
from __future__ import annotations

import json
import shutil
from pathlib import Path

import core.paths as core_paths
from fastapi import FastAPI
from fastapi.testclient import TestClient
from lineage.api import desktop_setup


def _make_typedef_home(tmp_path: Path, monkeypatch) -> Path:
    """Create a TYPEDEF_HOME under the user's home dir (security check)."""
    typedef_home = Path.home() / ".tmp-typedef-tests" / tmp_path.name
    if typedef_home.exists():
        shutil.rmtree(typedef_home)
    typedef_home.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("TYPEDEF_HOME", str(typedef_home))
    core_paths.typedef_home.cache_clear()
    return typedef_home


def _build_client(tmp_path: Path, monkeypatch) -> TestClient:
    """Create a TestClient with the credentials_router mounted."""
    _make_typedef_home(tmp_path, monkeypatch)

    app = FastAPI()
    app.include_router(desktop_setup.credentials_router)
    return TestClient(app)


# ── _read_telemetry_prefs ────────────────────────────────────────────


class TestReadTelemetryPrefs:
    def test_returns_empty_dict_when_file_missing(self, tmp_path, monkeypatch):
        _make_typedef_home(tmp_path, monkeypatch)
        assert desktop_setup._read_telemetry_prefs() == {}

    def test_returns_prefs_when_file_exists(self, tmp_path, monkeypatch):
        home = _make_typedef_home(tmp_path, monkeypatch)
        prefs = {"telemetry_opted_out": True, "telemetry_acknowledged": True}
        (home / "preferences.json").write_text(json.dumps(prefs))
        assert desktop_setup._read_telemetry_prefs() == prefs

    def test_returns_empty_dict_on_corrupt_json(self, tmp_path, monkeypatch):
        home = _make_typedef_home(tmp_path, monkeypatch)
        (home / "preferences.json").write_text("not valid json{{{")
        assert desktop_setup._read_telemetry_prefs() == {}

    def test_returns_empty_dict_when_json_is_non_dict(self, tmp_path, monkeypatch):
        """Preferences file containing a list or string should not crash callers."""
        home = _make_typedef_home(tmp_path, monkeypatch)
        (home / "preferences.json").write_text(json.dumps([1, 2, 3]))
        assert desktop_setup._read_telemetry_prefs() == {}


# ── _write_telemetry_prefs ───────────────────────────────────────────


class TestWriteTelemetryPrefs:
    def test_creates_file_and_writes_prefs(self, tmp_path, monkeypatch):
        home = _make_typedef_home(tmp_path, monkeypatch)
        prefs = {"telemetry_opted_out": True}
        desktop_setup._write_telemetry_prefs(prefs)
        result = json.loads((home / "preferences.json").read_text())
        assert result == prefs

    def test_atomic_write_does_not_leave_tmp_file(self, tmp_path, monkeypatch):
        home = _make_typedef_home(tmp_path, monkeypatch)
        desktop_setup._write_telemetry_prefs({"key": "value"})
        assert not (home / "preferences.json.tmp").exists()
        assert (home / "preferences.json").exists()


# ── GET /desktop/telemetry-status ────────────────────────────────────


class TestGetTelemetryStatus:
    def test_returns_defaults_when_no_prefs_file(self, tmp_path, monkeypatch):
        client = _build_client(tmp_path, monkeypatch)
        monkeypatch.delenv("LOGFIRE_TOKEN", raising=False)
        resp = client.get("/desktop/telemetry-status")
        assert resp.status_code == 200
        data = resp.json()
        assert data["active"] is False
        assert data["opted_out"] is False
        assert data["acknowledged"] is False

    def test_active_when_logfire_token_set(self, tmp_path, monkeypatch):
        client = _build_client(tmp_path, monkeypatch)
        monkeypatch.setenv("LOGFIRE_TOKEN", "test-token")
        resp = client.get("/desktop/telemetry-status")
        assert resp.status_code == 200
        assert resp.json()["active"] is True

    def test_reflects_opted_out_preference(self, tmp_path, monkeypatch):
        client = _build_client(tmp_path, monkeypatch)
        typedef_home = core_paths.typedef_home()
        (typedef_home / "preferences.json").write_text(
            json.dumps({"telemetry_opted_out": True, "telemetry_acknowledged": True})
        )
        resp = client.get("/desktop/telemetry-status")
        data = resp.json()
        assert data["opted_out"] is True
        assert data["acknowledged"] is True

    def test_requires_session_token(self, tmp_path, monkeypatch):
        client = _build_client(tmp_path, monkeypatch)
        monkeypatch.setenv("TYPEDEF_SESSION_TOKEN", "secret")
        resp = client.get("/desktop/telemetry-status")
        assert resp.status_code == 401

    def test_passes_with_valid_session_token(self, tmp_path, monkeypatch):
        client = _build_client(tmp_path, monkeypatch)
        monkeypatch.setenv("TYPEDEF_SESSION_TOKEN", "secret")
        resp = client.get(
            "/desktop/telemetry-status",
            headers={"Authorization": "Bearer secret"},
        )
        assert resp.status_code == 200


# ── POST /desktop/telemetry-preference ───────────────────────────────


class TestSetTelemetryPreference:
    def test_writes_opted_out(self, tmp_path, monkeypatch):
        client = _build_client(tmp_path, monkeypatch)
        resp = client.post(
            "/desktop/telemetry-preference",
            json={"opted_out": True, "acknowledged": True},
        )
        assert resp.status_code == 200
        assert resp.json()["ok"] is True
        prefs = json.loads(
            (core_paths.typedef_home() / "preferences.json").read_text()
        )
        assert prefs["telemetry_opted_out"] is True
        assert prefs["telemetry_acknowledged"] is True

    def test_partial_update_preserves_existing_prefs(self, tmp_path, monkeypatch):
        client = _build_client(tmp_path, monkeypatch)
        # First write
        client.post(
            "/desktop/telemetry-preference",
            json={"acknowledged": True},
        )
        # Partial update — only opted_out
        client.post(
            "/desktop/telemetry-preference",
            json={"opted_out": True},
        )
        prefs = json.loads(
            (core_paths.typedef_home() / "preferences.json").read_text()
        )
        assert prefs["telemetry_opted_out"] is True
        assert prefs["telemetry_acknowledged"] is True

    def test_rejects_non_object_body(self, tmp_path, monkeypatch):
        client = _build_client(tmp_path, monkeypatch)
        resp = client.post(
            "/desktop/telemetry-preference",
            content=json.dumps("not an object"),
            headers={"Content-Type": "application/json"},
        )
        assert resp.status_code == 400

    def test_requires_session_token(self, tmp_path, monkeypatch):
        client = _build_client(tmp_path, monkeypatch)
        monkeypatch.setenv("TYPEDEF_SESSION_TOKEN", "secret")
        resp = client.post(
            "/desktop/telemetry-preference",
            json={"opted_out": True},
        )
        assert resp.status_code == 401

    def test_round_trip_opt_out_and_status(self, tmp_path, monkeypatch):
        """Opt out via POST, verify via GET."""
        client = _build_client(tmp_path, monkeypatch)
        monkeypatch.setenv("LOGFIRE_TOKEN", "test-token")
        client.post(
            "/desktop/telemetry-preference",
            json={"opted_out": True, "acknowledged": True},
        )
        resp = client.get("/desktop/telemetry-status")
        data = resp.json()
        assert data["active"] is True
        assert data["opted_out"] is True
        assert data["acknowledged"] is True
