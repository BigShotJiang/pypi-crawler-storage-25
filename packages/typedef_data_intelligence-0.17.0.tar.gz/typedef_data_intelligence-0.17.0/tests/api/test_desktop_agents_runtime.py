"""Tests for desktop agent runtime composition in standalone desktop mode."""

from dataclasses import dataclass
from datetime import datetime
from types import SimpleNamespace
from unittest.mock import patch

from agent.harness_session import load_session_state, save_session_state
from agent.harness_transitions import TransitionConfig
from agent.harness_types import SessionState
from agent.toolsets.plan import persist_plan
from agent.types import AgentState, PlanPreview, PlanSection, PlanStep
from core.backends.threads.models import Artifact, ThreadContext
from fastapi import FastAPI
from fastapi.testclient import TestClient
from lineage.api.desktop_agents import _runtime_provider
from lineage.api.desktop_agents import router as desktop_agents_router


@dataclass
class _FakeThreadsBackend:
    _threads: dict[str, ThreadContext]
    _metadata: dict[tuple[str, str], object]

    def __init__(self) -> None:
        self._threads = {}
        self._metadata = {}

    def get_or_create_thread(self, thread_id: str) -> ThreadContext:
        if thread_id not in self._threads:
            self._threads[thread_id] = ThreadContext(thread_id=thread_id)
        return self._threads[thread_id]

    def add_artifact(self, thread_id: str, run_id: str, artifact: Artifact) -> None:
        thread = self.get_or_create_thread(thread_id)
        thread.artifacts.discard(artifact)
        thread.artifacts.add(artifact)

    def set_metadata(self, thread_id: str, key: str, value: object) -> None:
        self._metadata[(thread_id, key)] = value

    def get_metadata(self, thread_id: str, key: str) -> object | None:
        return self._metadata.get((thread_id, key))


def _make_plan(plan_id: str = "plan_sync") -> PlanPreview:
    return PlanPreview(
        plan_id=plan_id,
        title="Draft Plan",
        goal="Ship feature",
        status="draft",
        last_updated=datetime.now(),
        sections=[
            PlanSection(
                section_id="context",
                title="Context",
                content_markdown="Some context",
            ),
        ],
        steps=[PlanStep(step_id="step_1", content="Do the thing", risk="low")],
    )


def test_runtime_provider_uses_standalone_threads_backend_when_app_state_is_absent() -> None:
    """Desktop profile should still provide a threads backend for plan persistence."""
    standalone_threads_backend = object()
    request = SimpleNamespace(
        app=SimpleNamespace(
            state=SimpleNamespace(
                app_state=None,
                unified_config=SimpleNamespace(
                    models={},
                    harness={"enabled": True},
                ),
                standalone_data_backend=None,
                standalone_reports_backend=None,
                standalone_threads_backend=standalone_threads_backend,
                type_store=None,
                type_graph=None,
                metadata_reader=None,
            )
        ),
        state=SimpleNamespace(user_id="u1", org_id="o1"),
    )

    with patch(
        "lineage.api.desktop_agents._resolve_unified_reader",
        return_value=object(),
    ):
        runtime = _runtime_provider(request)

    assert runtime.threads_backend is standalone_threads_backend
    assert runtime.harness_config == {"enabled": True}


def test_plan_status_sync_endpoint_updates_persisted_plan(monkeypatch) -> None:
    """Plan status sync endpoint should update both artifact and harness session state."""
    threads_backend = _FakeThreadsBackend()
    scoped_thread_id = "wt_123:thread_1"
    plan = _make_plan()
    persist_plan(
        state=AgentState(),
        threads_backend=threads_backend,
        thread_id=scoped_thread_id,
        run_id="r1",
        plan=plan,
    )
    save_session_state(
        threads_backend,
        scoped_thread_id,
        SessionState(
            session_id=scoped_thread_id,
            current_mode="planning",
            transition_config=TransitionConfig(),
            active_plan_id=plan.plan_id,
            active_plan_data=plan.model_dump(mode="json"),
        ),
    )

    app = FastAPI()
    app.include_router(desktop_agents_router)
    app.state.app_state = None
    app.state.unified_config = SimpleNamespace(models={}, harness={"enabled": True})
    app.state.standalone_data_backend = None
    app.state.standalone_reports_backend = None
    app.state.standalone_threads_backend = threads_backend
    app.state.type_store = None
    app.state.type_graph = None
    app.state.metadata_reader = None

    with patch(
        "lineage.api.desktop_agents._resolve_unified_reader",
        return_value=object(),
    ):
        client = TestClient(app)
        response = client.post(
            "/desktop/agents/plan/status",
            json={
                "thread_id": "thread_1",
                "worktree_id": "wt_123",
                "plan_id": plan.plan_id,
                "status": "delegated",
            },
        )

    assert response.status_code == 200
    thread = threads_backend.get_or_create_thread(scoped_thread_id)
    persisted = next(artifact for artifact in thread.artifacts if artifact.id == plan.plan_id)
    assert persisted.data is not None
    assert persisted.data["status"] == "delegated"

    session = load_session_state(threads_backend, scoped_thread_id)
    assert session.active_plan_data is not None
    assert session.active_plan_data["status"] == "delegated"
