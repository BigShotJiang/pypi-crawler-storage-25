from __future__ import annotations

import shutil
from pathlib import Path
from types import SimpleNamespace

import core.paths as core_paths
import pytest
import yaml
from core.backends.config import UnifiedConfig
from fastapi import HTTPException
from ingest.static_loaders.salesforce.factory import SfAuthMode
from lineage.api import desktop_context, desktop_projects, desktop_setup
from pydantic import ValidationError


def _write_config(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.dump(data, default_flow_style=False, sort_keys=False))


def _make_request(unified_config: UnifiedConfig) -> SimpleNamespace:
    return SimpleNamespace(
        app=SimpleNamespace(
            state=SimpleNamespace(
                unified_config=unified_config,
                desktop_reader_cache={"unified": object()},
            )
        ),
        headers={},
    )


def _reset_typedef_home(path: Path) -> None:
    if path.exists():
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=True)


def test_hot_swap_default_project_reloads_new_project_config(tmp_path, monkeypatch):
    typedef_home = Path.home() / ".tmp-typedef-tests" / tmp_path.name
    _reset_typedef_home(typedef_home)
    monkeypatch.setenv("TYPEDEF_HOME", str(typedef_home))
    core_paths.typedef_home.cache_clear()

    cfg_file = core_paths.config_path()
    _write_config(
        cfg_file,
        {
            "default_project": None,
            "projects": {},
            "lineage": {
                "backend": "surrealdb",
                "url": "ws://127.0.0.1:3567",
                "namespace": "lineage",
            },
        },
    )

    stale_config = UnifiedConfig.from_yaml(cfg_file)

    project_root = typedef_home / "projects" / "medallion_reference"
    project_root.mkdir(parents=True, exist_ok=True)

    _write_config(
        cfg_file,
        {
            "default_project": "medallion_reference",
            "projects": {
                "medallion_reference": {
                    "name": "medallion_reference",
                    "dbt_path": str(project_root),
                    "graph_name": "medallion_reference",
                    "profile_name": "medallion_reference",
                    "profiles_dir": str(
                        typedef_home / "profiles" / "medallion_reference"
                    ),
                    "dbt_target": "duckdb",
                    "data": {
                        "backend": "duckdb",
                        "db_path": str(project_root / "medallion-reference.duckdb"),
                    },
                }
            },
            "lineage": {
                "backend": "surrealdb",
                "url": "ws://127.0.0.1:3567",
                "namespace": "lineage",
            },
        },
    )

    request = _make_request(stale_config)

    desktop_projects._hot_swap_default_project(request, "medallion_reference")
    context = desktop_context.resolve_desktop_request_context(request)

    assert context.project_name == "medallion_reference"
    assert context.graph_name == "medallion_reference"
    assert context.config is not None
    assert context.config.projects is not None
    assert "medallion_reference" in context.config.projects
    assert context.config.projects["medallion_reference"].dbt_path == project_root
    assert request.app.state.desktop_reader_cache == {}


def test_hot_swap_default_project_falls_back_when_reload_fails(tmp_path, monkeypatch):
    typedef_home = Path.home() / ".tmp-typedef-tests" / tmp_path.name
    _reset_typedef_home(typedef_home)
    monkeypatch.setenv("TYPEDEF_HOME", str(typedef_home))
    core_paths.typedef_home.cache_clear()

    cfg_file = core_paths.config_path()
    _write_config(
        cfg_file,
        {
            "default_project": "old_project",
            "projects": {
                "old_project": {
                    "name": "old_project",
                    "dbt_path": str(typedef_home / "projects" / "old_project"),
                    "graph_name": "old_project",
                }
            },
            "lineage": {
                "backend": "surrealdb",
                "url": "ws://127.0.0.1:3567",
                "namespace": "lineage",
            },
        },
    )

    stale_config = UnifiedConfig.from_yaml(cfg_file)
    request = _make_request(stale_config)
    request.app.state.app_state = SimpleNamespace(config=stale_config)

    monkeypatch.setattr(
        "core.backends.config.UnifiedConfig.from_yaml",
        lambda path: (_ for _ in ()).throw(ValueError("bad config")),
    )

    desktop_projects._hot_swap_default_project(request, "medallion_reference")

    assert stale_config.default_project == "medallion_reference"
    assert request.app.state.unified_config is stale_config
    assert request.app.state.app_state.config is stale_config
    assert request.app.state.desktop_reader_cache == {}


def test_update_project_request_rejects_invalid_backend_type():
    with pytest.raises(ValidationError):
        desktop_projects.UpdateProjectRequest(backend_type="sqlite")


def test_project_detail_rejects_invalid_backend_type():
    with pytest.raises(ValidationError):
        desktop_projects.ProjectDetail(
            name="test_project",
            clone_path="/tmp/test_project",
            dbt_path="/tmp/test_project",
            backend_type="sqlite",
        )


def test_detect_subprojects_hides_raw_exception_details(
    typedef_home, monkeypatch, caplog
):
    home, _ = typedef_home
    project_root = home / "projects" / "test_project"
    project_root.mkdir(parents=True, exist_ok=True)

    def boom(self, pattern):
        raise PermissionError(f"permission denied: {project_root / 'secret-path'}")

    monkeypatch.setattr(Path, "rglob", boom)

    with caplog.at_level("WARNING"):
        subprojects, selected, warning = desktop_projects._detect_subprojects(
            "test_project", str(project_root)
        )

    assert subprojects == []
    assert selected == "."
    assert (
        warning
        == "Could not inspect dbt subprojects. Check the project path and permissions."
    )
    assert str(project_root / "secret-path") not in warning
    assert any(
        record.message == "Could not inspect dbt subprojects for project test_project"
        and record.exc_info is not None
        for record in caplog.records
    )


# ── Fixtures ──────────────────────────────────────────────────────────


@pytest.fixture()
def typedef_home(tmp_path, monkeypatch):
    """Set up an isolated TYPEDEF_HOME and return a (home, config_path) tuple."""
    home = Path.home() / ".tmp-typedef-tests" / tmp_path.name
    _reset_typedef_home(home)
    monkeypatch.setenv("TYPEDEF_HOME", str(home))
    core_paths.typedef_home.cache_clear()
    cfg = core_paths.config_path()
    yield home, cfg
    core_paths.typedef_home.cache_clear()


def _base_config(project_name: str = "test_project", **project_overrides) -> dict:
    """Return a minimal config dict with one project."""
    proj = {
        "name": project_name,
        "dbt_path": "/tmp/dbt",
        "graph_name": project_name,
        "data": {"backend": "duckdb", "db_path": ":memory:"},
        **project_overrides,
    }
    return {
        "default_project": project_name,
        "projects": {project_name: proj},
        "lineage": {
            "backend": "surrealdb",
            "url": "ws://127.0.0.1:3567",
            "namespace": "lineage",
        },
    }


@pytest.mark.asyncio
async def test_get_project_returns_backend_detail_and_subprojects(typedef_home):
    home, cfg = typedef_home
    project_root = home / "projects" / "test_project"
    nested_root = project_root / "nested"
    nested_root.mkdir(parents=True, exist_ok=True)
    (project_root / "dbt_project.yml").write_text("name: root\n")
    (nested_root / "dbt_project.yml").write_text("name: nested\n")

    _write_config(
        cfg,
        _base_config(
            dbt_path=str(nested_root),
            profile_name="analytics_profile",
            dbt_target="prod",
            data={
                "backend": "snowflake",
                "account": "acme",
                "user": "alice",
                "private_key_path": "~/.ssh/snowflake.p8",
                "warehouse": "COMPUTE_WH",
                "role": "ANALYST",
                "database": "ANALYTICS",
                "schema_name": "CORE",
                "allowed_databases": ["ANALYTICS", "RAW"],
            },
            env={"DBT_THREADS": "8"},
            profiling={"enabled": False},
        ),
    )

    result = await desktop_projects.get_project("test_project")

    assert result.name == "test_project"
    assert result.backend_type == "snowflake"
    assert result.clone_path == str(project_root)
    assert result.dbt_path == str(nested_root)
    assert result.profile_name == "analytics_profile"
    assert result.dbt_target == "prod"
    assert result.snowflake_account == "acme"
    assert result.snowflake_user == "alice"
    assert result.snowflake_private_key_path == "~/.ssh/snowflake.p8"
    assert result.snowflake_database == "ANALYTICS"
    assert result.snowflake_schema == "CORE"
    assert result.allowed_databases == ["ANALYTICS", "RAW"]
    assert result.env_vars == "DBT_THREADS=8"
    assert result.profiling_enabled is False
    assert result.subprojects == [".", "nested"]
    assert result.selected_subproject == "nested"


@pytest.mark.asyncio
async def test_get_project_tolerates_non_list_allowed_databases(typedef_home):
    _, cfg = typedef_home
    _write_config(
        cfg,
        _base_config(
            data={
                "backend": "snowflake",
                "allowed_databases": "ANALYTICS",
            }
        ),
    )

    result = await desktop_projects.get_project("test_project")

    assert result.backend_type == "snowflake"
    assert result.allowed_databases == []


@pytest.mark.asyncio
async def test_get_project_rejects_unsupported_persisted_backend(typedef_home):
    _, cfg = typedef_home
    _write_config(cfg, _base_config(data={"backend": "sqlite"}))

    with pytest.raises(HTTPException) as exc_info:
        await desktop_projects.get_project("test_project")

    assert exc_info.value.status_code == 500
    assert exc_info.value.detail == "Project config contains unsupported backend value"


@pytest.mark.asyncio
async def test_update_project_rewrites_profiles_and_selected_subproject(typedef_home):
    home, cfg = typedef_home
    project_root = home / "projects" / "test_project"
    nested_root = project_root / "nested"
    nested_root.mkdir(parents=True, exist_ok=True)
    (project_root / "dbt_project.yml").write_text("name: root\n")
    (nested_root / "dbt_project.yml").write_text("name: nested\n")
    profiles_path = core_paths.profiles_dir() / "test_project"
    profiles_path.mkdir(parents=True, exist_ok=True)
    (profiles_path / "profiles.yml").write_text("old: true\n")

    _write_config(
        cfg,
        _base_config(
            dbt_path=str(project_root),
            profile_name="old_profile",
            dbt_target="dev",
            profiles_dir=str(profiles_path),
            data={"backend": "duckdb", "db_path": "warehouse.duckdb"},
            env={"OLD_FLAG": "1"},
        ),
    )

    await desktop_projects.update_project(
        "test_project",
        desktop_projects.UpdateProjectRequest(
            backend_type="snowflake",
            snowflake_account="acme",
            snowflake_user="alice",
            snowflake_private_key_path="~/.ssh/snowflake.p8",
            snowflake_warehouse="COMPUTE_WH",
            snowflake_role="ANALYST",
            snowflake_database="ANALYTICS",
            snowflake_schema="CORE",
            allowed_databases=["ANALYTICS", "RAW"],
            dbt_target="prod",
            profile_name="analytics_profile",
            sub_project="nested",
            env_vars="DBT_THREADS=8, FOO=bar",
            profiling_enabled=False,
        ),
    )

    raw = yaml.safe_load(cfg.read_text())
    project = raw["projects"]["test_project"]
    assert project["dbt_path"] == str(nested_root)
    assert project["profile_name"] == "analytics_profile"
    assert project["dbt_target"] == "prod"
    assert project["profiling"] == {"enabled": False}
    assert project["env"] == {
        "SNOWFLAKE_PRIVATE_KEY_PATH": "~/.ssh/snowflake.p8",
        "DBT_THREADS": "8",
        "FOO": "bar",
    }
    assert project["data"] == {
        "backend": "snowflake",
        "account": "acme",
        "user": "alice",
        "private_key_path": "~/.ssh/snowflake.p8",
        "warehouse": "COMPUTE_WH",
        "role": "ANALYST",
        "database": "ANALYTICS",
        "schema_name": "CORE",
        "allowed_databases": ["ANALYTICS", "RAW"],
    }

    profiles = yaml.safe_load((profiles_path / "profiles.yml").read_text())
    assert profiles == {
        "analytics_profile": {
            "target": "prod",
            "outputs": {
                "prod": {
                    "type": "snowflake",
                    "account": "acme",
                    "user": "alice",
                    "private_key_path": "~/.ssh/snowflake.p8",
                    "warehouse": "COMPUTE_WH",
                    "role": "ANALYST",
                    "database": "ANALYTICS",
                    "schema": "CORE",
                    "threads": 4,
                }
            },
        }
    }


@pytest.mark.asyncio
async def test_update_project_tolerates_non_mapping_data(typedef_home):
    _, cfg = typedef_home
    _write_config(cfg, _base_config(data=None))

    await desktop_projects.update_project(
        "test_project",
        desktop_projects.UpdateProjectRequest(duckdb_path="warehouse.duckdb"),
    )

    raw = yaml.safe_load(cfg.read_text())
    assert raw["projects"]["test_project"]["data"] == {"db_path": "warehouse.duckdb"}


@pytest.mark.asyncio
async def test_update_project_preserves_unsupported_persisted_backend(typedef_home):
    _, cfg = typedef_home
    _write_config(
        cfg,
        _base_config(
            data={"backend": "sqlite", "db_path": "warehouse.duckdb"},
            profiling={"enabled": False},
        ),
    )

    await desktop_projects.update_project(
        "test_project",
        desktop_projects.UpdateProjectRequest(profiling_enabled=True),
    )

    raw = yaml.safe_load(cfg.read_text())
    assert raw["projects"]["test_project"]["data"]["backend"] == "sqlite"
    assert raw["projects"]["test_project"]["profiling"] == {"enabled": True}


@pytest.mark.asyncio
async def test_update_project_rejects_missing_subproject_path(typedef_home):
    home, cfg = typedef_home
    project_root = home / "projects" / "test_project"
    project_root.mkdir(parents=True, exist_ok=True)
    (project_root / "dbt_project.yml").write_text("name: root\n")
    _write_config(cfg, _base_config(dbt_path=str(project_root)))

    with pytest.raises(HTTPException) as exc_info:
        await desktop_projects.update_project(
            "test_project",
            desktop_projects.UpdateProjectRequest(sub_project="missing"),
        )

    assert exc_info.value.status_code == 400
    assert str(exc_info.value.detail) == "Subproject path does not exist"


@pytest.mark.asyncio
async def test_update_project_rejects_subproject_without_dbt_project_yml(
    typedef_home,
):
    home, cfg = typedef_home
    project_root = home / "projects" / "test_project"
    missing_dbt_root = project_root / "missing_dbt"
    missing_dbt_root.mkdir(parents=True, exist_ok=True)
    (project_root / "dbt_project.yml").write_text("name: root\n")
    _write_config(cfg, _base_config(dbt_path=str(project_root)))

    with pytest.raises(HTTPException) as exc_info:
        await desktop_projects.update_project(
            "test_project",
            desktop_projects.UpdateProjectRequest(sub_project="missing_dbt"),
        )

    assert exc_info.value.status_code == 400
    assert "dbt_project.yml" in str(exc_info.value.detail)


# ── Profiling: list_projects ─────────────────────────────────────────


@pytest.mark.asyncio
async def test_list_projects_profiling_defaults_true_when_absent(typedef_home):
    """When config has no profiling section, list_projects returns enabled=True."""
    _, cfg = typedef_home
    _write_config(cfg, _base_config())

    result = await desktop_projects.list_projects()
    proj = result.projects[0]
    assert proj.integrations.profiling_enabled is True


@pytest.mark.asyncio
async def test_list_projects_profiling_returns_false_when_disabled(typedef_home):
    """When config has profiling.enabled=false, list_projects reflects that."""
    _, cfg = typedef_home
    config = _base_config(profiling={"enabled": False})
    _write_config(cfg, config)

    result = await desktop_projects.list_projects()
    proj = result.projects[0]
    assert proj.integrations.profiling_enabled is False


@pytest.mark.asyncio
async def test_list_projects_profiling_handles_non_dict(typedef_home):
    """When config has profiling set to a non-dict value, defaults to True."""
    _, cfg = typedef_home
    config = _base_config(profiling=None)
    _write_config(cfg, config)

    result = await desktop_projects.list_projects()
    proj = result.projects[0]
    assert proj.integrations.profiling_enabled is True


# ── Profiling: update_project ────────────────────────────────────────


@pytest.mark.asyncio
async def test_update_project_sets_profiling_enabled(typedef_home):
    """PATCH with profiling_enabled=false writes to config and is reflected by list."""
    _, cfg = typedef_home
    _write_config(cfg, _base_config())

    req = desktop_projects.UpdateProjectRequest(profiling_enabled=False)
    await desktop_projects.update_project("test_project", req)

    # Verify written to disk
    raw = yaml.safe_load(cfg.read_text())
    assert raw["projects"]["test_project"]["profiling"]["enabled"] is False

    # Verify round-trip via list_projects
    result = await desktop_projects.list_projects()
    assert result.projects[0].integrations.profiling_enabled is False


@pytest.mark.asyncio
async def test_update_project_profiling_none_leaves_unchanged(typedef_home):
    """PATCH without profiling_enabled does not alter existing profiling config."""
    _, cfg = typedef_home
    config = _base_config(profiling={"enabled": False})
    _write_config(cfg, config)

    req = desktop_projects.UpdateProjectRequest(snowflake_account="new_acct")
    await desktop_projects.update_project("test_project", req)

    raw = yaml.safe_load(cfg.read_text())
    assert raw["projects"]["test_project"]["profiling"]["enabled"] is False


@pytest.mark.asyncio
async def test_update_project_profiling_repairs_non_dict(typedef_home):
    """PATCH with profiling_enabled on a config with non-dict profiling value works."""
    _, cfg = typedef_home
    config = _base_config(profiling="broken")
    _write_config(cfg, config)

    req = desktop_projects.UpdateProjectRequest(profiling_enabled=True)
    await desktop_projects.update_project("test_project", req)

    raw = yaml.safe_load(cfg.read_text())
    assert raw["projects"]["test_project"]["profiling"] == {"enabled": True}


# ── Profiling: _build_project_config ─────────────────────────────────


def test_build_project_config_includes_profiling_enabled():
    """_build_project_config writes profiling.enabled from the request."""
    req = desktop_setup.CreateProjectRequest(
        name="proj",
        git_url="https://github.com/example/repo",
        backend="duckdb",
        profiling_enabled=True,
    )
    result = desktop_setup._build_project_config(req, "proj", "/tmp/dbt", profile_name="test")
    assert result["profiling"] == {"enabled": True}


def test_build_project_config_profiling_disabled():
    """_build_project_config respects profiling_enabled=False."""
    req = desktop_setup.CreateProjectRequest(
        name="proj",
        git_url="https://github.com/example/repo",
        backend="duckdb",
        profiling_enabled=False,
    )
    result = desktop_setup._build_project_config(req, "proj", "/tmp/dbt", profile_name="test")
    assert result["profiling"] == {"enabled": False}


# ── Salesforce auth_type YAML serialization ────────────────────────────


def test_build_project_config_serializes_sf_auth_type_as_plain_string():
    """SfAuthMode must be written as a plain string, not a !!python/object tag."""
    req = desktop_setup.CreateProjectRequest(
        name="proj",
        git_url="https://github.com/example/repo",
        backend="duckdb",
        salesforce_enabled=True,
        salesforce_auth_type=SfAuthMode.OAUTH_PKCE,
        salesforce_client_id="test-client-id",
    )
    result = desktop_setup._build_project_config(req, "proj", "/tmp/dbt", profile_name="test")
    raw_yaml = yaml.dump(result, default_flow_style=False)
    assert "!!python" not in raw_yaml
    assert result["salesforce"]["auth_type"] == "oauth_pkce"


@pytest.mark.asyncio
async def test_update_project_serializes_sf_auth_type_as_plain_string(typedef_home):
    """Updating salesforce_auth_type must write a plain string to config YAML."""
    _, cfg = typedef_home
    _write_config(cfg, _base_config())

    await desktop_projects.update_project(
        "test_project",
        desktop_projects.UpdateProjectRequest(
            salesforce_enabled=True,
            salesforce_auth_type=SfAuthMode.OAUTH_PKCE,
            salesforce_client_id="test-client-id",
        ),
    )

    raw_text = cfg.read_text()
    assert "!!python" not in raw_text
    raw = yaml.safe_load(raw_text)
    assert raw["projects"]["test_project"]["salesforce"]["auth_type"] == "oauth_pkce"


@pytest.mark.anyio
async def test_update_project_persists_cleared_browser_fallback_credentials(
    tmp_path, monkeypatch
):
    typedef_home = Path.home() / ".tmp-typedef-tests" / tmp_path.name
    _reset_typedef_home(typedef_home)
    monkeypatch.setenv("TYPEDEF_HOME", str(typedef_home))
    core_paths.typedef_home.cache_clear()

    cfg_file = core_paths.config_path()
    _write_config(
        cfg_file,
        {
            "default_project": "medallion_reference",
            "projects": {
                "medallion_reference": {
                    "name": "medallion_reference",
                    "dbt_path": str(typedef_home / "projects" / "medallion_reference"),
                    "graph_name": "medallion_reference",
                    "data": {"backend": "duckdb", "db_path": "example.duckdb"},
                }
            },
            "lineage": {
                "backend": "surrealdb",
                "url": "ws://127.0.0.1:3567",
                "namespace": "lineage",
            },
        },
    )
    core_paths.env_path().write_text(
        "ANTHROPIC_API_KEY=legacy-anthropic\n"
        "OPENAI_API_KEY=legacy-openai\n"
        "SF_PASSWORD=legacy-password\n"
        "SF_SECURITY_TOKEN=legacy-token\n"
        "SF_CLIENT_SECRET=legacy-secret\n"
    )

    await desktop_projects.update_project(
        "medallion_reference",
        desktop_projects.UpdateProjectRequest(
            anthropic_api_key="",
            openai_api_key="rotated-openai",
            sf_password="",
            sf_security_token="",
            sf_client_secret="",
        ),
    )

    env_values = {
        key: value
        for key, value in (
            line.split("=", 1)
            for line in core_paths.env_path().read_text().splitlines()
            if line and not line.startswith("#")
        )
    }

    assert "ANTHROPIC_API_KEY" not in env_values
    assert env_values["OPENAI_API_KEY"] == "rotated-openai"
    assert "SF_PASSWORD" not in env_values
    assert "SF_SECURITY_TOKEN" not in env_values
    assert "SF_CLIENT_SECRET" not in env_values
