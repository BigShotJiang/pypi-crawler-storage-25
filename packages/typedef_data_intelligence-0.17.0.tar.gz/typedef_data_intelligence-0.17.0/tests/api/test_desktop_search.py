"""Tests for the /desktop/search API endpoint.

Uses FastAPI TestClient with an in-memory SurrealDB reader injected via
dependency override. Covers facets, kind filtering, pagination, score
normalization, source dedup, and kind remapping.
"""

import pytest
from agent.api.desktop import get_unified_reader, router
from core.backends.unified_graph.surreal.load import (
    connect,
    ensure_indexes,
    ensure_tables,
)
from core.backends.unified_graph.surreal.query import q
from core.backends.unified_graph.surreal.reader import SurrealUnifiedGraphReader
from fastapi import FastAPI
from fastapi.testclient import TestClient


@pytest.fixture(scope="module")
def client():
    """FastAPI TestClient with an in-memory SurrealDB backend."""
    db = connect(url="mem://", namespace="test_api", database="test_api")
    ensure_tables(db)
    ensure_indexes(db)

    # --- Seed test data ---

    # Models (process table)
    for name, desc in [
        ("fct_revenue_monthly", "Monthly revenue aggregation"),
        ("fct_revenue_daily", "Daily revenue from billing"),
        ("stg_server_events", "Server event logs"),
        ("dim_daily_server_info", None),
        ("fct_active_users", "Daily active user counts"),
    ]:
        props = f"{{ description: '{desc}' }}" if desc else "{}"
        q(
            db,
            f"CREATE process SET name=$name, kind='model', source='dbt', "
            f"source_family='transformation', node_type='process', "
            f"source_label='DbtModel', canonical_id=$sid, properties={props};",
            name=name,
            sid=f"model.project.{name}",
        )

    # Columns (attribute table) — same name across multiple models
    for model in ["fct_revenue_monthly", "fct_revenue_daily", "stg_server_events"]:
        q(
            db,
            "CREATE attribute SET name='server_id', kind='column', source='dbt', "
            "source_family='transformation', node_type='attribute', source_label='DbtColumn', "
            "canonical_id=$sid, properties={};",
            sid=f"model.project.{model}.server_id",
        )

    # DbtSource entries (kind=source, source=dbt)
    for source_group in ["mm_telemetry_prod", "mm_telemetry_rc", "hacktoberboard"]:
        q(
            db,
            "CREATE resource SET name='activity', kind='source', source='dbt', "
            "source_family='transformation', node_type='resource', source_label='DbtSource', "
            "canonical_id=$sid, properties={};",
            sid=f"source.project.{source_group}.activity",
        )

    # Physical Dataset artifact (kind=dataset, source=dbt) — should be excluded
    q(
        db,
        "CREATE resource SET name='fct_revenue_monthly', kind='dataset', source='dbt', "
        "source_family='transformation', node_type='resource', source_label='Dataset', "
        "canonical_id='dataset::model.project.fct_revenue_monthly', properties={};",
    )

    # Physical column — should be excluded
    q(
        db,
        "CREATE attribute SET name='server_id', kind='column', source='snowflake', "
        "source_family='warehouse', node_type='attribute', source_label='PhysicalColumn', "
        "canonical_id='physical::DB.schema.tbl.server_id', properties={};",
    )

    # Derivation — should be excluded
    q(
        db,
        "CREATE process SET name='derive:col', kind='derivation', source='dbt', "
        "source_family='transformation', node_type='process', source_label='Derivation', "
        "canonical_id='derive:model.project.model.col', properties={};",
    )

    # Test resource
    q(
        db,
        "CREATE resource SET name='not_null_fct_revenue_monthly_id', kind='test', source='dbt', "
        "source_family='transformation', node_type='resource', source_label='DbtTest', "
        "canonical_id='test.project.not_null_fct_revenue_monthly_id.abc', properties={};",
    )

    # Macro
    q(
        db,
        "CREATE resource SET name='generate_schema', kind='macro', source='dbt', "
        "source_family='transformation', node_type='resource', source_label='DbtMacro', "
        "canonical_id='macro.project.generate_schema', "
        "properties={ description: 'Generates schema for models' };",
    )

    reader = SurrealUnifiedGraphReader(db)
    app = FastAPI()
    app.include_router(router)
    app.dependency_overrides[get_unified_reader] = lambda: reader

    return TestClient(app)


# ── Basic search ─────────────────────────────────────────────────────────


class TestBasicSearch:
    def test_returns_results(self, client):
        resp = client.get("/desktop/search", params={"q": "revenue"})
        assert resp.status_code == 200
        data = resp.json()
        assert data["total_count"] > 0
        assert len(data["results"]) > 0

    def test_multi_term_or(self, client):
        resp = client.get("/desktop/search", params={"q": "server event daily"})
        data = resp.json()
        names = {r["name"] for r in data["results"]}
        assert len(names) >= 2

    def test_empty_query_rejected(self, client):
        resp = client.get("/desktop/search", params={"q": ""})
        assert resp.status_code == 422


# ── Facets ───────────────────────────────────────────────────────────────


class TestFacets:
    def test_facet_tree_returned(self, client):
        resp = client.get("/desktop/search", params={"q": "revenue"})
        data = resp.json()
        assert "facet_tree" in data
        assert len(data["facet_tree"]) > 0

    def test_facet_tree_structure(self, client):
        resp = client.get("/desktop/search", params={"q": "revenue"})
        tree = resp.json()["facet_tree"]
        for fam in tree:
            assert "family" in fam
            assert "label" in fam
            assert "count" in fam
            assert fam["count"] > 0
            assert "sources" in fam
            for src in fam["sources"]:
                assert "source" in src
                assert "kinds" in src
                for k in src["kinds"]:
                    assert "kind" in k
                    assert "label" in k
                    assert "count" in k
                    assert k["count"] > 0

    def test_facet_tree_consistent_across_filter(self, client):
        """Facet tree should reflect the full result set, not the filtered one."""
        all_resp = client.get("/desktop/search", params={"q": "revenue"})
        filtered_resp = client.get(
            "/desktop/search", params={"q": "revenue", "kinds": "model"}
        )
        all_tree = all_resp.json()["facet_tree"]
        filtered_tree = filtered_resp.json()["facet_tree"]
        # Facet tree should be the same regardless of filter
        assert all_tree == filtered_tree


# ── Kind filtering ───────────────────────────────────────────────────────


class TestKindFiltering:
    def test_filter_by_kind(self, client):
        resp = client.get(
            "/desktop/search", params={"q": "revenue", "kinds": "model"}
        )
        data = resp.json()
        for r in data["results"]:
            assert r["kind"] == "model"

    def test_filter_multiple_kinds(self, client):
        resp = client.get(
            "/desktop/search", params={"q": "revenue", "kinds": "model,test"}
        )
        data = resp.json()
        kinds = {r["kind"] for r in data["results"]}
        assert kinds <= {"model", "test"}


# ── Score normalization ──────────────────────────────────────────────────


class TestScoreNormalization:
    def test_scores_between_zero_and_one(self, client):
        resp = client.get("/desktop/search", params={"q": "revenue"})
        data = resp.json()
        for r in data["results"]:
            assert 0 <= r["score"] <= 1.0, (
                f"Score {r['score']} out of range for {r['name']}"
            )

    def test_top_result_has_score_one(self, client):
        resp = client.get("/desktop/search", params={"q": "revenue"})
        results = resp.json()["results"]
        if results:
            assert results[0]["score"] == 1.0


# ── Kind remapping ───────────────────────────────────────────────────────


class TestKindRemapping:
    def test_dbt_source_has_source_kind(self, client):
        """DbtSource entries should have kind='source'."""
        resp = client.get("/desktop/search", params={"q": "activity"})
        data = resp.json()
        source_results = [r for r in data["results"] if r["name"] == "activity"]
        assert len(source_results) >= 1
        for r in source_results:
            assert r["kind"] == "source", (
                f"DbtSource should be kind='source', got {r['kind']}"
            )

    def test_source_filter_works(self, client):
        """Filtering by 'source' should return DbtSource entries."""
        resp = client.get(
            "/desktop/search", params={"q": "activity", "kinds": "source"}
        )
        data = resp.json()
        assert len(data["results"]) >= 1
        for r in data["results"]:
            assert r["kind"] == "source"

    def test_source_and_source_family_returned(self, client):
        """Search results include source and source_family fields."""
        resp = client.get(
            "/desktop/search", params={"q": "revenue", "kinds": "model"}
        )
        data = resp.json()
        for r in data["results"]:
            assert r["source"] == "dbt"
            assert r["source_family"] == "transformation"


# ── Source dedup ─────────────────────────────────────────────────────────


class TestSourceDedup:
    def test_sources_deduped_by_name(self, client):
        """Same source name across multiple YAML blocks should appear once."""
        resp = client.get(
            "/desktop/search", params={"q": "activity", "kinds": "source"}
        )
        data = resp.json()
        source_names = [r["name"] for r in data["results"] if r["kind"] == "source"]
        assert source_names.count("activity") == 1


# ── Physical exclusion ───────────────────────────────────────────────────


class TestPhysicalExclusion:
    def test_derivation_excluded(self, client):
        resp = client.get("/desktop/search", params={"q": "derive"})
        data = resp.json()
        for r in data["results"]:
            assert r["kind"] != "derivation"

    def test_dataset_artifact_excluded(self, client):
        """Physical Dataset artifacts (source_label=Dataset) should be excluded."""
        resp = client.get("/desktop/search", params={"q": "fct_revenue_monthly"})
        data = resp.json()
        for r in data["results"]:
            assert r["node_type"] != "Dataset", (
                f"Physical Dataset should be excluded: {r['name']}"
            )


# ── Pagination ───────────────────────────────────────────────────────────


class TestPagination:
    def test_has_more_field(self, client):
        resp = client.get("/desktop/search", params={"q": "server", "limit": 2})
        data = resp.json()
        assert "has_more" in data

    def test_offset_returns_different_results(self, client):
        page1 = client.get(
            "/desktop/search", params={"q": "revenue", "limit": 2, "offset": 0}
        ).json()
        page2 = client.get(
            "/desktop/search", params={"q": "revenue", "limit": 2, "offset": 2}
        ).json()
        ids1 = {r["id"] for r in page1["results"]}
        ids2 = {r["id"] for r in page2["results"]}
        # Pages should not overlap (if there are enough results)
        if page1["has_more"] and page2["results"]:
            assert ids1.isdisjoint(ids2), "Paginated results should not overlap"

    def test_offset_beyond_results(self, client):
        resp = client.get("/desktop/search", params={"q": "revenue", "offset": 9999})
        data = resp.json()
        assert len(data["results"]) == 0
        assert data["has_more"] is False


# ── Description handling ─────────────────────────────────────────────────


class TestDescriptionHandling:
    def test_model_with_description_shows_it(self, client):
        resp = client.get(
            "/desktop/search", params={"q": "fct_revenue_monthly", "kinds": "model"}
        )
        data = resp.json()
        models = [r for r in data["results"] if r["name"] == "fct_revenue_monthly"]
        assert len(models) >= 1
        assert models[0]["description"] == "Monthly revenue aggregation"

    def test_model_without_description_has_none(self, client):
        """Models without properties.description should not get canonical_id as subtitle."""
        resp = client.get(
            "/desktop/search",
            params={"q": "dim_daily_server_info", "kinds": "model"},
        )
        data = resp.json()
        models = [r for r in data["results"] if r["name"] == "dim_daily_server_info"]
        if models:
            # Should be None or the real description, not canonical_id
            desc = models[0]["description"]
            assert desc is None or not desc.startswith("model."), (
                f"Model description should not be canonical_id fallback: {desc}"
            )

    def test_columns_excluded_from_search(self, client):
        """Columns (both dbt and physical) are excluded from search results."""
        resp = client.get("/desktop/search", params={"q": "server_id"})
        data = resp.json()
        column_results = [r for r in data["results"] if r.get("kind") == "column"]
        assert len(column_results) == 0, "Columns should be excluded from search"


# ── Facet tree ──────────────────────────────────────────────────────────


class TestFacetTree:
    def test_facet_tree_returned(self, client):
        resp = client.get("/desktop/search", params={"q": "revenue"})
        data = resp.json()
        assert "facet_tree" in data
        assert len(data["facet_tree"]) > 0

    def test_facet_tree_structure(self, client):
        resp = client.get("/desktop/search", params={"q": "revenue"})
        tree = resp.json()["facet_tree"]
        for fam in tree:
            assert "family" in fam
            assert "label" in fam
            assert "count" in fam
            assert "sources" in fam
            for src in fam["sources"]:
                assert "source" in src
                assert "label" in src
                assert "count" in src
                assert "kinds" in src
                for k in src["kinds"]:
                    assert "kind" in k
                    assert "label" in k
                    assert "count" in k

    def test_facet_tree_family_is_transformation(self, client):
        """All seeded data is dbt (transformation family)."""
        resp = client.get("/desktop/search", params={"q": "revenue"})
        tree = resp.json()["facet_tree"]
        families = [f["family"] for f in tree]
        assert "transformation" in families

    def test_facet_tree_counts_consistent(self, client):
        """Sum of family counts should equal total_count."""
        resp = client.get("/desktop/search", params={"q": "revenue"})
        data = resp.json()
        tree_total = sum(f["count"] for f in data["facet_tree"])
        assert tree_total == data["total_count"]


# ── Source and family filtering ──────────────────────────────────────────


class TestSourceAndFamilyFiltering:
    def test_filter_by_source(self, client):
        resp = client.get(
            "/desktop/search", params={"q": "revenue", "sources": "dbt"}
        )
        data = resp.json()
        for r in data["results"]:
            assert r["source"] == "dbt"

    def test_filter_by_family(self, client):
        resp = client.get(
            "/desktop/search",
            params={"q": "revenue", "families": "transformation"},
        )
        data = resp.json()
        for r in data["results"]:
            assert r["source_family"] == "transformation"

    def test_filter_by_family_no_match(self, client):
        resp = client.get(
            "/desktop/search", params={"q": "revenue", "families": "bi"}
        )
        data = resp.json()
        assert len(data["results"]) == 0
