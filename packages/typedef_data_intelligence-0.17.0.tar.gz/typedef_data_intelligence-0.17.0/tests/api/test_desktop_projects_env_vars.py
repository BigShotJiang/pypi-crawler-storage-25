from lineage.api import desktop_projects


def test_parse_env_vars_ignores_reserved_keys():
    assert desktop_projects._parse_env_vars(
        "FOO=bar, SNOWFLAKE_PRIVATE_KEY_PATH=/tmp/key.p8, DUCKDB_PATH=/tmp/override.duckdb"
    ) == {"FOO": "bar"}
