"""Tests for backend readiness health checks."""

from types import SimpleNamespace

import pytest
from lineage.api.pydantic import health_readiness


class _HealthyLineage:
    def execute_raw_query(self, query: str, params=None):
        return {"rows": [{"ok": 1}]}


class _HealthyData:
    async def execute_query(self, query: str, limit=None):
        return {"rows": [{"ok": 1}]}


class _BrokenLineage:
    def execute_raw_query(self, query: str, params=None):
        raise RuntimeError("graph unavailable")


class _BrokenData:
    async def execute_query(self, query: str, limit=None):
        raise RuntimeError("warehouse unavailable")


@pytest.mark.asyncio
async def test_health_readiness_reports_ready_when_both_dependencies_respond() -> None:
    state = SimpleNamespace(
        lineage=_HealthyLineage(),
        data_backend=_HealthyData(),
        config=SimpleNamespace(
            lineage=SimpleNamespace(backend="falkordb"),
        ),
        data_config=SimpleNamespace(backend="snowflake"),
    )

    payload = await health_readiness(request=SimpleNamespace(), state=state)

    assert payload["status"] == "healthy"
    assert payload["readiness"]["lineage"] is True
    assert payload["readiness"]["data"] is True


@pytest.mark.asyncio
async def test_health_readiness_reports_errors_for_unavailable_dependencies() -> None:
    state = SimpleNamespace(
        lineage=_BrokenLineage(),
        data_backend=_BrokenData(),
        config=SimpleNamespace(
            lineage=SimpleNamespace(backend="falkordb"),
        ),
        data_config=SimpleNamespace(backend="snowflake"),
    )

    payload = await health_readiness(request=SimpleNamespace(), state=state)

    assert payload["status"] == "degraded"
    assert payload["readiness"]["lineage"] is False
    assert payload["readiness"]["data"] is False
    assert "lineage" in payload["errors"]
    assert "data" in payload["errors"]
