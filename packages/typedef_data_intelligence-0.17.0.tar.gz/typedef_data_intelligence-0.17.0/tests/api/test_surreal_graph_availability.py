"""Tests for SurrealGraphAvailability service implementation."""

from __future__ import annotations

import time
from dataclasses import dataclass
from unittest.mock import patch

import pytest
from lineage.api.graph_availability import SurrealGraphAvailability

# Stub get_ingest_version so tests don't depend on typedef-ingest being installed.
_FAKE_INGEST_VERSION = "0.0.0-test"


@pytest.fixture(autouse=True)
def _mock_ingest_version():
    from core.backends.unified_graph.availability import get_ingest_version

    get_ingest_version.cache_clear()
    with patch(
        "core.backends.unified_graph.availability.get_ingest_version",
        return_value=_FAKE_INGEST_VERSION,
    ):
        yield
    get_ingest_version.cache_clear()

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class _FakeDb:
    """Minimal DB stub for raw queries."""

    def __init__(self, raw_meta: list | None = None):
        self._raw_meta = raw_meta or []

    def query(self, q: str, params=None) -> list:
        return self._raw_meta


class _FakeReader:
    """Minimal reader stub."""

    def __init__(
        self,
        sentinel: dict | None = None,
        raise_on_sentinel: bool = False,
        raw_meta: list | None = None,
    ):
        self._sentinel = sentinel
        self._raise = raise_on_sentinel
        self._db = _FakeDb(raw_meta)

    def check_load_sentinel(self) -> dict | None:
        if self._raise:
            raise ConnectionError("db gone")
        return self._sentinel

    def _get_db(self):
        return self._db


@dataclass
class _FakeSyncOp:
    sync_id: str
    project_name: str
    status: str = "running"
    started_at: float = 0.0
    error: str | None = None


def _make_availability(
    reader: _FakeReader | None = None,
    reader_raises: bool = False,
    sync_ops: dict | None = None,
    project_name: str = "test-project",
    probe_interval: float = 0.0,
    probe_timeout: float = 3.0,
) -> SurrealGraphAvailability:
    def reader_factory():
        if reader_raises:
            raise ConnectionError("unreachable")
        return reader

    return SurrealGraphAvailability(
        reader_factory=reader_factory,
        sync_ops_ref=lambda: sync_ops or {},
        project_name=project_name,
        probe_interval=probe_interval,
        probe_timeout=probe_timeout,
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestSurrealGraphAvailabilityCheck:
    """Test the check() method across different scenarios."""

    def test_db_unreachable(self):
        avail = _make_availability(reader_raises=True)
        status = avail.check()
        assert not status.db_reachable
        assert not status.available
        assert "not reachable" in (status.error_detail() or "")

    def test_db_reachable_no_data_never_synced(self):
        reader = _FakeReader(sentinel=None)
        avail = _make_availability(reader=reader)
        status = avail.check()
        assert status.db_reachable
        assert not status.has_data
        assert status.sync_status == "never_synced"
        assert "Run a" in (status.error_detail() or "") and "sync" in (status.error_detail() or "")

    def test_db_reachable_has_data_healthy(self):
        reader = _FakeReader(sentinel={"loaded_at": "2026-01-01", "ingest_version": _FAKE_INGEST_VERSION})
        ops = {"op1": _FakeSyncOp("op1", "test-project", status="complete", started_at=1.0)}
        avail = _make_availability(reader=reader, sync_ops=ops)
        status = avail.check()
        assert status.available
        assert status.error_detail() is None
        assert status.warning() is None

    def test_sync_running_no_data(self):
        reader = _FakeReader(sentinel=None)
        ops = {"op1": _FakeSyncOp("op1", "test-project", status="running", started_at=1.0)}
        avail = _make_availability(reader=reader, sync_ops=ops)
        status = avail.check()
        assert not status.available
        assert status.sync_status == "running"
        assert "in progress" in (status.error_detail() or "")

    def test_sync_running_with_data(self):
        """Running sync makes graph unavailable even with sentinel (TOCTOU race)."""
        reader = _FakeReader(sentinel={"loaded_at": "2026-01-01"})
        ops = {"op1": _FakeSyncOp("op1", "test-project", status="running", started_at=1.0)}
        avail = _make_availability(reader=reader, sync_ops=ops)
        status = avail.check()
        assert not status.available
        assert "in progress" in (status.error_detail() or "")

    def test_sync_error_with_data(self):
        reader = _FakeReader(sentinel={"loaded_at": "2026-01-01", "ingest_version": _FAKE_INGEST_VERSION})
        ops = {"op1": _FakeSyncOp("op1", "test-project", status="error", error="OOM", started_at=1.0)}
        avail = _make_availability(reader=reader, sync_ops=ops)
        status = avail.check()
        assert status.available
        assert "OOM" in (status.warning() or "")

    def test_sentinel_check_fails_gracefully(self):
        reader = _FakeReader(raise_on_sentinel=True)
        avail = _make_availability(reader=reader)
        status = avail.check()
        assert status.db_reachable
        assert not status.has_data

    def test_filters_by_project_name(self):
        """Sync ops from other projects are ignored."""
        reader = _FakeReader(sentinel=None)
        ops = {
            "op1": _FakeSyncOp("op1", "other-project", status="running", started_at=1.0),
        }
        avail = _make_availability(reader=reader, sync_ops=ops, project_name="test-project")
        status = avail.check()
        assert status.sync_status == "never_synced"

    def test_uses_most_recent_sync_op(self):
        """When multiple ops exist, uses the most recent."""
        reader = _FakeReader(sentinel={"loaded_at": "2026-01-01"})
        ops = {
            "old": _FakeSyncOp("old", "test-project", status="complete", started_at=1.0),
            "new": _FakeSyncOp("new", "test-project", status="error", error="fail", started_at=2.0),
        }
        avail = _make_availability(reader=reader, sync_ops=ops)
        status = avail.check()
        assert status.sync_status == "error"
        assert status.sync_error == "fail"

    def test_cancelled_sync_treated_as_idle(self):
        reader = _FakeReader(sentinel={"loaded_at": "2026-01-01"})
        ops = {"op1": _FakeSyncOp("op1", "test-project", status="cancelled", started_at=1.0)}
        avail = _make_availability(reader=reader, sync_ops=ops)
        status = avail.check()
        assert status.sync_status == "idle"
        assert status.available


class TestSurrealGraphAvailabilityCaching:
    """Test probe caching and timeout behavior."""

    def test_probe_timeout_returns_unreachable(self):
        """A reader_factory that blocks beyond probe_timeout yields db_reachable=False."""
        def slow_factory():
            time.sleep(5)  # longer than timeout
            return _FakeReader(sentinel={"loaded_at": "2026-01-01"})

        avail = SurrealGraphAvailability(
            reader_factory=slow_factory,
            sync_ops_ref=lambda: {},
            probe_timeout=0.5,
            probe_interval=0.0,
        )
        status = avail.check()
        assert not status.db_reachable
        assert not status.available
        assert "not reachable" in (status.error_detail() or "")

    def test_cache_prevents_repeated_probes(self):
        """With a long probe_interval, check() returns cached status without re-probing."""
        call_count = 0

        def counting_factory():
            nonlocal call_count
            call_count += 1
            return _FakeReader(sentinel={"loaded_at": "2026-01-01"})

        ops = {"op1": _FakeSyncOp("op1", "test-project", status="complete", started_at=1.0)}
        avail = SurrealGraphAvailability(
            reader_factory=counting_factory,
            sync_ops_ref=lambda: ops,
            project_name="test-project",
            probe_interval=60.0,  # long interval — cache should not expire
            probe_timeout=3.0,
        )

        status1 = avail.check()
        status2 = avail.check()
        assert status1.available
        assert status2.available
        assert call_count == 1  # only probed once

    def test_cache_expiry_triggers_reprobe(self):
        """With probe_interval=0, every check() re-probes."""
        call_count = 0

        def counting_factory():
            nonlocal call_count
            call_count += 1
            return _FakeReader(sentinel={"loaded_at": "2026-01-01"})

        ops = {"op1": _FakeSyncOp("op1", "test-project", status="complete", started_at=1.0)}
        avail = SurrealGraphAvailability(
            reader_factory=counting_factory,
            sync_ops_ref=lambda: ops,
            project_name="test-project",
            probe_interval=0.0,
            probe_timeout=3.0,
        )

        avail.check()
        avail.check()
        assert call_count == 2

    def test_sync_state_refreshed_on_cache_hit(self):
        """Sync status changes are reflected even when probe cache is fresh."""
        ops: dict = {"op1": _FakeSyncOp("op1", "test-project", status="running", started_at=1.0)}
        reader = _FakeReader(sentinel={"loaded_at": "2026-01-01"})
        avail = SurrealGraphAvailability(
            reader_factory=lambda: reader,
            sync_ops_ref=lambda: ops,
            project_name="test-project",
            probe_interval=60.0,
            probe_timeout=3.0,
        )

        status1 = avail.check()
        assert status1.sync_status == "running"
        assert not status1.available

        # Sync completes — update ops dict
        ops["op1"] = _FakeSyncOp("op1", "test-project", status="complete", started_at=1.0)

        status2 = avail.check()
        assert status2.sync_status == "complete"
        assert status2.available  # data exists + sync complete = available


class TestEnrichmentStatus:
    """Test partial enrichment detection and warnings."""

    def test_enrichment_pending_shows_warning(self):
        """When enrichment_status is 'pending', warning() returns enrichment message."""
        reader = _FakeReader(
            sentinel={"loaded_at": "2026-01-01", "enrichment_status": "pending", "ingest_version": _FAKE_INGEST_VERSION}
        )
        ops = {"op1": _FakeSyncOp("op1", "test-project", status="complete", started_at=1.0)}
        avail = _make_availability(reader=reader, sync_ops=ops)
        status = avail.check()
        assert status.available
        assert status.enrichment_status == "pending"
        assert "partially complete" in (status.warning() or "")

    def test_enrichment_complete_no_warning(self):
        """When enrichment_status is 'complete', no warning is shown."""
        reader = _FakeReader(
            sentinel={"loaded_at": "2026-01-01", "enrichment_status": "complete", "ingest_version": _FAKE_INGEST_VERSION}
        )
        ops = {"op1": _FakeSyncOp("op1", "test-project", status="complete", started_at=1.0)}
        avail = _make_availability(reader=reader, sync_ops=ops)
        status = avail.check()
        assert status.available
        assert status.enrichment_status == "complete"
        assert status.warning() is None

    def test_enrichment_none_no_warning(self):
        """When enrichment_status is None (legacy sentinel), no warning."""
        reader = _FakeReader(sentinel={"loaded_at": "2026-01-01", "ingest_version": _FAKE_INGEST_VERSION})
        ops = {"op1": _FakeSyncOp("op1", "test-project", status="complete", started_at=1.0)}
        avail = _make_availability(reader=reader, sync_ops=ops)
        status = avail.check()
        assert status.available
        assert status.enrichment_status is None
        assert status.warning() is None

    def test_crashed_sync_detected(self):
        """When _meta has load_type='in_progress', detect crashed sync."""
        reader = _FakeReader(
            sentinel=None,
            raw_meta=[{"load_type": "in_progress"}],
        )
        avail = _make_availability(reader=reader)
        status = avail.check()
        assert not status.available
        assert status.sync_status == "error"
        assert "interrupted" in (status.sync_error or "")
