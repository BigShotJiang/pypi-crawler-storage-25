from __future__ import annotations

from fastapi import FastAPI
from fastapi.testclient import TestClient
from lineage.api import desktop_sync


class EscalatingProcess:
    def __init__(self):
        self.pid = 4242
        self.exitcode = 0
        self._alive = True
        self.close_called = False
        self.terminate_called = False
        self.kill_called = False

    def join(self, timeout=None):
        return None

    def is_alive(self):
        return self._alive

    def terminate(self):
        self.terminate_called = True

    def kill(self):
        self.kill_called = True
        self._alive = False

    def close(self):
        self.close_called = True


class CloseErrorProcess:
    def __init__(self):
        self.pid = 4242
        self.exitcode = 0
        self.close_called = False

    def join(self, timeout=None):
        return None

    def is_alive(self):
        return False

    def close(self):
        self.close_called = True
        raise ValueError(
            "Cannot close a process while it is still running. You should first call join() or terminate()."
        )


class CompletedQueue:
    def __init__(self):
        self.closed = False
        self.joined = False
        self._events = [
            {
                "stage": "complete",
                "current": 12,
                "total": 12,
                "status": "completed",
                "message": "Sync complete in 0.3s",
                "head_commit": "abc123",
            }
        ]

    def get(self, timeout=None):
        if self._events:
            return self._events.pop(0)
        raise RuntimeError("queue empty")

    def empty(self):
        return not self._events

    def get_nowait(self):
        if self._events:
            return self._events.pop(0)
        raise RuntimeError("queue empty")

    def close(self):
        self.closed = True

    def join_thread(self):
        self.joined = True


def test_sync_progress_emits_terminal_event_even_if_process_stays_alive(monkeypatch):
    app = FastAPI()
    app.include_router(desktop_sync.router)

    process = EscalatingProcess()
    queue = CompletedQueue()
    op = desktop_sync.SyncOperation(
        sync_id="sync-terminal",
        project_name="demo_project",
        process=process,
        queue=queue,
        status="running",
    )
    monkeypatch.setitem(desktop_sync._sync_ops, op.sync_id, op)
    monkeypatch.setattr(desktop_sync, "_persist_synced_commit", lambda *_: None)

    client = TestClient(app)

    response = client.get(f"/desktop/sync/{op.sync_id}/progress")

    assert response.status_code == 200
    assert "Sync complete in 0.3s" in response.text
    assert process.terminate_called is True
    assert process.kill_called is True
    assert process.close_called is True
    assert queue.closed is True
    assert queue.joined is True


def test_sync_progress_ignores_process_close_errors_during_cleanup(monkeypatch):
    app = FastAPI()
    app.include_router(desktop_sync.router)

    process = CloseErrorProcess()
    queue = CompletedQueue()
    op = desktop_sync.SyncOperation(
        sync_id="sync-close-error",
        project_name="demo_project",
        process=process,
        queue=queue,
        status="running",
    )
    monkeypatch.setitem(desktop_sync._sync_ops, op.sync_id, op)
    monkeypatch.setattr(desktop_sync, "_persist_synced_commit", lambda *_: None)

    client = TestClient(app)

    response = client.get(f"/desktop/sync/{op.sync_id}/progress")

    assert response.status_code == 200
    assert "Sync complete in 0.3s" in response.text
    assert process.close_called is True
    assert queue.closed is True
    assert queue.joined is True
