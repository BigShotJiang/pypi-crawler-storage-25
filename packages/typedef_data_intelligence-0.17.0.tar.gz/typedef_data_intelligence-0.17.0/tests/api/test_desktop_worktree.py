"""Tests for desktop worktree API helpers and routes."""

from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

import pytest
from fastapi import BackgroundTasks, HTTPException
from lineage.api import desktop_worktree


def _completed_process(
    returncode: int = 0, stdout: str = "", stderr: str = ""
) -> SimpleNamespace:
    return SimpleNamespace(returncode=returncode, stdout=stdout, stderr=stderr)


@pytest.mark.asyncio
async def test_list_worktrees_marks_project_and_managed_rows(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo_root = Path("/tmp/typedef-home/projects/foo")
    managed_root = Path("/tmp/typedef-home/worktrees")

    monkeypatch.setattr(desktop_worktree, "_repo_root", lambda: repo_root)
    monkeypatch.setattr(desktop_worktree, "_worktrees_root_dir", lambda: managed_root)
    monkeypatch.setattr(desktop_worktree, "_worktree_base_dir", lambda: managed_root)
    monkeypatch.setattr(desktop_worktree, "_default_branch", lambda root: "main")
    monkeypatch.setattr(
        desktop_worktree,
        "_run_git",
        lambda root, args, timeout=30: _completed_process(
            stdout=(
                f"worktree {repo_root}\n"
                "branch refs/heads/main\n\n"
                f"worktree {managed_root / 'baz'}\n"
                "branch refs/heads/typedef/baz\n\n"
            )
        ),
    )

    response = await desktop_worktree.list_worktrees()

    assert response.default_branch == "main"
    assert len(response.worktrees) == 2

    project = next(
        worktree for worktree in response.worktrees if worktree.name == "foo"
    )
    managed = next(
        worktree for worktree in response.worktrees if worktree.name == "baz"
    )

    assert project.is_project_worktree is True
    assert project.is_managed_worktree is False
    assert project.can_remove is False

    assert managed.is_project_worktree is False
    assert managed.is_managed_worktree is True
    assert managed.can_remove is True


@pytest.mark.asyncio
async def test_remove_worktree_rejects_project_worktree(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo_root = Path("/tmp/typedef-home/projects/foo")
    project = desktop_worktree.Worktree(
        id="foo",
        name="foo",
        branch="main",
        path=str(repo_root),
        base_branch="main",
        is_project_worktree=True,
        is_managed_worktree=False,
        can_remove=False,
    )

    monkeypatch.setattr(desktop_worktree, "_repo_root", lambda: repo_root)
    monkeypatch.setattr(desktop_worktree, "_parse_worktrees", lambda root: [project])

    with pytest.raises(HTTPException) as exc:
        await desktop_worktree.remove_worktree("foo")

    assert exc.value.status_code == 400
    assert "cannot be removed" in exc.value.detail


@pytest.mark.asyncio
async def test_remove_worktree_removes_managed_checkout_and_keeps_branch(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo_root = Path("/tmp/typedef-home/projects/foo")
    managed_path = Path("/tmp/typedef-home/worktrees/baz")
    managed = desktop_worktree.Worktree(
        id="baz",
        name="baz",
        branch="typedef/baz",
        path=str(managed_path),
        base_branch="main",
        is_project_worktree=False,
        is_managed_worktree=True,
        can_remove=True,
    )
    captured: list[list[str]] = []

    monkeypatch.setattr(desktop_worktree, "_repo_root", lambda: repo_root)
    monkeypatch.setattr(desktop_worktree, "_parse_worktrees", lambda root: [managed])

    def fake_run_git(root: Path, args: list[str], timeout: int = 30) -> SimpleNamespace:
        captured.append(args)
        return _completed_process()

    monkeypatch.setattr(desktop_worktree, "_run_git", fake_run_git)

    removed = await desktop_worktree.remove_worktree("baz")

    assert captured == [["worktree", "remove", str(managed_path), "--force"]]
    assert removed.name == "baz"
    assert removed.branch == "typedef/baz"
    assert removed.status == "removed"


@pytest.mark.asyncio
async def test_create_worktree_no_claude_config_symlink(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """Worktree creation no longer symlinks .claude/ (CLI flags handle delegation config)."""
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    wt_base = tmp_path / "worktrees"
    wt_base.mkdir()
    wt_dir = wt_base / "test-wt"

    monkeypatch.setattr(desktop_worktree, "_repo_root", lambda: repo_root)
    monkeypatch.setattr(desktop_worktree, "_worktree_base_dir", lambda: wt_base)
    monkeypatch.setattr(desktop_worktree, "_default_branch", lambda root: "main")
    monkeypatch.setattr(
        desktop_worktree, "_git_branch_exists", lambda root, branch: False
    )

    def fake_run_git(root: Path, args: list[str], timeout: int = 30) -> SimpleNamespace:
        wt_dir.mkdir(exist_ok=True)
        return _completed_process()

    monkeypatch.setattr(desktop_worktree, "_run_git", fake_run_git)

    result = await desktop_worktree.create_worktree(
        desktop_worktree.WorktreeCreateRequest(name="test-wt"),
        BackgroundTasks(),
    )

    assert result.name == "test-wt"
    assert result.status == "active"
    # No .claude symlink should exist in the worktree
    assert not (wt_dir / ".claude").exists()
