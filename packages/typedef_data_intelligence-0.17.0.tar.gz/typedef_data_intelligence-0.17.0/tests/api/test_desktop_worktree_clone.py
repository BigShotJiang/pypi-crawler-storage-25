"""Tests for desktop worktree clone lifecycle helpers and routes."""

from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

import pytest
import yaml
from core import paths as core_paths
from fastapi import BackgroundTasks, HTTPException
from lineage.api import desktop_worktree


def _completed_process(
    returncode: int = 0, stdout: str = "", stderr: str = ""
) -> SimpleNamespace:
    return SimpleNamespace(returncode=returncode, stdout=stdout, stderr=stderr)


def _clone_settings(
    tmp_path: Path, repo_root: Path
) -> desktop_worktree.ActiveProjectCloneSettings:
    private_key_path = tmp_path / "id_rsa"
    private_key_path.write_text("test-key", encoding="utf-8")
    return desktop_worktree.ActiveProjectCloneSettings(
        project_name="analytics",
        dbt_path=repo_root / "analytics",
        profile_name="analytics",
        dbt_target="prod",
        backend="snowflake",
        account="acct",
        user="user",
        role="role",
        warehouse="wh",
        source_database="ANALYTICS",
        schema_name="PUBLIC",
        private_key_path=private_key_path,
    )


def _duckdb_clone_settings(
    tmp_path: Path, repo_root: Path
) -> desktop_worktree.ActiveProjectCloneSettings:
    return desktop_worktree.ActiveProjectCloneSettings(
        project_name="analytics",
        dbt_path=repo_root / "analytics",
        profile_name="analytics",
        dbt_target="prod",
        backend="duckdb",
        db_path=tmp_path / "analytics.duckdb",
    )


def _write_active_project_config(
    cfg_path: Path,
    repo_root: Path,
    *,
    graph_name: str = "analytics",
) -> None:
    cfg_path.parent.mkdir(parents=True, exist_ok=True)
    cfg_path.write_text(
        yaml.safe_dump(
            {
                "default_project": "analytics",
                "projects": {
                    "analytics": {
                        "name": "analytics",
                        "dbt_path": str(repo_root / "analytics"),
                        "graph_name": graph_name,
                        "profile_name": "analytics",
                        "dbt_target": "prod",
                        "data": {
                            "backend": "snowflake",
                            "account": "acct",
                            "user": "user",
                            "role": "role",
                            "warehouse": "wh",
                            "database": "ANALYTICS",
                            "schema_name": "PUBLIC",
                            "private_key_path": str(cfg_path.parent / "id_rsa"),
                        },
                    }
                },
            },
            default_flow_style=False,
            sort_keys=False,
        ),
        encoding="utf-8",
    )
    (cfg_path.parent / "id_rsa").write_text("test-key", encoding="utf-8")


def test_write_and_remove_managed_clone_profile(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    worktree_root = tmp_path / "worktree"
    (repo_root / "analytics").mkdir(parents=True)
    (worktree_root / "analytics").mkdir(parents=True)

    settings = _clone_settings(tmp_path, repo_root)

    managed = desktop_worktree._write_clone_profile(
        repo_root,
        worktree_root,
        settings,
        "ANALYTICS__FEAT_METRICS",
    )

    assert managed.profile_path == worktree_root / "analytics" / "profiles.yml"
    assert managed.mode == "root_override"
    content = managed.profile_path.read_text(encoding="utf-8")
    assert content.startswith(desktop_worktree._MANAGED_CLONE_PROFILE_MARKER)
    assert "ANALYTICS__FEAT_METRICS" in content
    assert not (worktree_root / ".typedef" / "clone" / "profiles.original.yml").exists()
    assert (worktree_root / ".typedef" / "clone" / "state.yml").exists()

    parsed = desktop_worktree._read_managed_clone_profile(managed.profile_path)
    assert parsed is not None
    assert parsed.target.database == "ANALYTICS__FEAT_METRICS"

    desktop_worktree._remove_clone_profile(repo_root, worktree_root, settings)
    assert not managed.profile_path.exists()
    assert not (worktree_root / ".typedef").exists()


def test_worktree_registry_entry_tracks_graph_and_clone_override(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo_root = tmp_path / "repo"
    worktree_root = tmp_path / "worktree"
    (repo_root / "analytics").mkdir(parents=True)
    (worktree_root / "analytics").mkdir(parents=True)

    cfg_path = tmp_path / "typedef-home" / "config.yaml"
    _write_active_project_config(cfg_path, repo_root, graph_name="analytics")
    monkeypatch.setattr(core_paths, "config_path", lambda: cfg_path)

    worktree = desktop_worktree.Worktree(
        id="bar",
        name="bar",
        branch="typedef/bar",
        path=str(worktree_root),
        base_branch="main",
        is_project_worktree=False,
        is_managed_worktree=True,
        can_remove=True,
    )

    desktop_worktree._set_worktree_registry_entry(
        repo_root,
        worktree,
        clone_target=desktop_worktree.CloneTarget(
            backend="snowflake", database="ANALYTICS__BAR"
        ),
        clone_status="healthy",
        activate_data_override=True,
    )

    cfg = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
    entry = cfg["projects"]["analytics"]["worktrees"]["bar"]
    assert entry["path"] == str(worktree_root)
    assert entry["dbt_path"] == str(worktree_root / "analytics")
    assert "graph_name" not in entry  # no per-worktree graph; uses project graph
    assert entry["data"]["database"] == "ANALYTICS__BAR"
    assert entry["data"]["allowed_databases"] == ["ANALYTICS__BAR"]
    assert entry["clone"]["backend"] == "snowflake"
    assert entry["clone"]["database"] == "ANALYTICS__BAR"
    assert entry["clone"]["status"] == "healthy"


def test_worktree_registry_entry_tracks_duckdb_clone_override(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo_root = tmp_path / "repo"
    worktree_root = tmp_path / "worktree"
    (repo_root / "analytics").mkdir(parents=True)
    (worktree_root / "analytics").mkdir(parents=True)

    cfg_path = tmp_path / "typedef-home" / "config.yaml"
    _write_active_project_config(cfg_path, repo_root, graph_name="analytics")
    monkeypatch.setattr(core_paths, "config_path", lambda: cfg_path)

    worktree = desktop_worktree.Worktree(
        id="bar",
        name="bar",
        branch="typedef/bar",
        path=str(worktree_root),
        base_branch="main",
        is_project_worktree=False,
        is_managed_worktree=True,
        can_remove=True,
    )
    clone_path = tmp_path / "clones" / "bar" / "analytics.duckdb"

    desktop_worktree._set_worktree_registry_entry(
        repo_root,
        worktree,
        clone_target=desktop_worktree.CloneTarget(
            backend="duckdb",
            path=clone_path,
            label="analytics.duckdb",
        ),
        clone_status="healthy",
        activate_data_override=True,
    )

    cfg = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
    entry = cfg["projects"]["analytics"]["worktrees"]["bar"]
    assert entry["data"]["db_path"] == str(clone_path)
    assert entry["clone"]["backend"] == "duckdb"
    assert entry["clone"]["path"] == str(clone_path)
    assert entry["clone"]["label"] == "analytics.duckdb"
    assert entry["clone"]["status"] == "healthy"


def test_worktree_registry_entry_removes_legacy_clone_keys(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo_root = tmp_path / "repo"
    worktree_root = tmp_path / "worktree"
    (repo_root / "analytics").mkdir(parents=True)
    (worktree_root / "analytics").mkdir(parents=True)

    cfg_path = tmp_path / "typedef-home" / "config.yaml"
    _write_active_project_config(cfg_path, repo_root, graph_name="analytics")
    monkeypatch.setattr(core_paths, "config_path", lambda: cfg_path)

    cfg = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
    cfg["projects"]["analytics"]["worktrees"] = {
        "bar": {
            "path": str(worktree_root),
            "graph_name": "analytics__bar",
            "clone": {
                "service_id": "legacy-service",
                "clone_database": "ANALYTICS__OLD",
                "status": "healthy",
            },
        }
    }
    cfg_path.write_text(
        yaml.safe_dump(cfg, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )

    worktree = desktop_worktree.Worktree(
        id="bar",
        name="bar",
        branch="typedef/bar",
        path=str(worktree_root),
        base_branch="main",
        is_project_worktree=False,
        is_managed_worktree=True,
        can_remove=True,
    )

    desktop_worktree._set_worktree_registry_entry(
        repo_root,
        worktree,
        clone_target=desktop_worktree.CloneTarget(
            backend="snowflake", database="ANALYTICS__BAR"
        ),
        clone_status="healthy",
        activate_data_override=True,
    )

    updated = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
    clone_entry = updated["projects"]["analytics"]["worktrees"]["bar"]["clone"]
    assert clone_entry["backend"] == "snowflake"
    assert clone_entry["database"] == "ANALYTICS__BAR"
    assert "service_id" not in clone_entry
    assert "clone_database" not in clone_entry


def test_build_registry_entry_drops_clone_block_without_target(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    worktree_root = tmp_path / "worktree"
    (repo_root / "analytics").mkdir(parents=True)
    (worktree_root / "analytics").mkdir(parents=True)

    worktree = desktop_worktree.Worktree(
        id="bar",
        name="bar",
        branch="typedef/bar",
        path=str(worktree_root),
        base_branch="main",
        is_project_worktree=False,
        is_managed_worktree=True,
        can_remove=True,
    )

    entry = desktop_worktree._build_registry_entry(
        repo_root,
        worktree,
        "analytics",
        {"dbt_path": str(repo_root / "analytics")},
        {
            "clone": {
                "backend": "duckdb",
                "path": str(tmp_path / "outside.duckdb"),
                "status": "failed",
                "error": "bad state",
            }
        },
        clone_target=None,
        clone_status="failed",
        clone_error="bad state",
        activate_data_override=False,
    )

    assert "clone" not in entry


def test_remove_worktree_registry_entry_deletes_worktree_config(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo_root = tmp_path / "repo"
    (repo_root / "analytics").mkdir(parents=True)
    cfg_path = tmp_path / "typedef-home" / "config.yaml"
    _write_active_project_config(cfg_path, repo_root)
    monkeypatch.setattr(core_paths, "config_path", lambda: cfg_path)

    cfg = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
    cfg["projects"]["analytics"]["worktrees"] = {
        "bar": {
            "path": str(tmp_path / "worktree"),
            "graph_name": "analytics__bar",
        }
    }
    cfg_path.write_text(
        yaml.safe_dump(cfg, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )

    desktop_worktree._remove_worktree_registry_entry("bar")

    updated = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
    assert "worktrees" not in updated["projects"]["analytics"]


def test_write_clone_profile_backs_up_existing_root_profiles_override(
    tmp_path: Path,
) -> None:
    repo_root = tmp_path / "repo"
    worktree_root = tmp_path / "worktree"
    dbt_project_dir = worktree_root / "analytics"
    (repo_root / "analytics").mkdir(parents=True)
    dbt_project_dir.mkdir(parents=True)
    original_profile = dbt_project_dir / "profiles.yml"
    original_profile.write_text("user-managed", encoding="utf-8")

    settings = _clone_settings(tmp_path, repo_root)

    managed = desktop_worktree._write_clone_profile(
        repo_root,
        worktree_root,
        settings,
        "ANALYTICS__FEAT_METRICS",
    )

    backup_path = worktree_root / ".typedef" / "clone" / "profiles.original.yml"
    assert managed.profile_path == original_profile
    assert backup_path.read_text(encoding="utf-8") == "user-managed"
    assert "ANALYTICS__FEAT_METRICS" in original_profile.read_text(encoding="utf-8")

    desktop_worktree._remove_clone_profile(repo_root, worktree_root, settings)
    assert original_profile.read_text(encoding="utf-8") == "user-managed"
    assert not backup_path.exists()


def test_write_clone_profile_restores_backup_when_write_fails(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo_root = tmp_path / "repo"
    worktree_root = tmp_path / "worktree"
    dbt_project_dir = worktree_root / "analytics"
    (repo_root / "analytics").mkdir(parents=True)
    dbt_project_dir.mkdir(parents=True)
    original_profile = dbt_project_dir / "profiles.yml"
    original_profile.write_text("user-managed", encoding="utf-8")
    settings = _clone_settings(tmp_path, repo_root)

    original_write_text = Path.write_text

    def fail_tmp_write(
        path: Path,
        data: str,
        encoding: str | None = None,
        errors: str | None = None,
        newline: str | None = None,
    ) -> int:
        if path.name.endswith(".tmp"):
            raise OSError("disk full")
        return original_write_text(path, data, encoding, errors, newline)

    monkeypatch.setattr(Path, "write_text", fail_tmp_write)

    with pytest.raises(OSError, match="disk full"):
        desktop_worktree._write_clone_profile(
            repo_root,
            worktree_root,
            settings,
            "ANALYTICS__FEAT_METRICS",
        )

    assert original_profile.read_text(encoding="utf-8") == "user-managed"
    assert not (worktree_root / ".typedef" / "clone" / "state.yml").exists()


def test_clone_metadata_reports_healthy_when_profile_and_clone_exist(
    tmp_path: Path,
) -> None:
    repo_root = tmp_path / "repo"
    worktree_root = tmp_path / "worktree"
    (repo_root / "analytics").mkdir(parents=True)
    (worktree_root / "analytics").mkdir(parents=True)
    settings = _clone_settings(tmp_path, repo_root)
    desktop_worktree._write_clone_profile(
        repo_root,
        worktree_root,
        settings,
        "ANALYTICS__BAZ",
    )

    worktree = desktop_worktree.Worktree(
        id="baz",
        name="baz",
        branch="typedef/baz",
        path=str(worktree_root),
        base_branch="main",
        is_project_worktree=False,
        is_managed_worktree=True,
        can_remove=True,
    )

    original = desktop_worktree._snowflake_clone_exists
    desktop_worktree._snowflake_clone_exists = lambda settings, clone_database: True
    try:
        metadata = desktop_worktree._clone_metadata_for_worktree(
            repo_root,
            worktree,
            settings,
        )
    finally:
        desktop_worktree._snowflake_clone_exists = original

    assert metadata == desktop_worktree.SnowflakeClone(
        database="ANALYTICS__BAZ",
        status="healthy",
    )


def test_clone_metadata_treats_duckdb_directory_as_stale(
    tmp_path: Path,
) -> None:
    repo_root = tmp_path / "repo"
    worktree_root = tmp_path / "worktree"
    clone_path = tmp_path / "clones" / "baz" / "analytics.duckdb"
    (repo_root / "analytics").mkdir(parents=True)
    (worktree_root / "analytics").mkdir(parents=True)
    clone_path.mkdir(parents=True)
    settings = _duckdb_clone_settings(tmp_path, repo_root)
    desktop_worktree._write_clone_profile(
        repo_root,
        worktree_root,
        settings,
        desktop_worktree.CloneTarget(
            backend="duckdb",
            path=clone_path,
            label="analytics.duckdb",
        ),
    )

    worktree = desktop_worktree.Worktree(
        id="baz",
        name="baz",
        branch="typedef/baz",
        path=str(worktree_root),
        base_branch="main",
        is_project_worktree=False,
        is_managed_worktree=True,
        can_remove=True,
    )

    metadata = desktop_worktree._clone_metadata_for_worktree(
        repo_root,
        worktree,
        settings,
    )

    assert metadata == desktop_worktree.DuckDBClone(
        path=str(clone_path),
        label="analytics.duckdb",
        status="stale",
    )


def test_hydrate_worktree_reports_healthy_clone_when_root_profiles_is_overridden(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo_root = tmp_path / "repo"
    worktree_root = tmp_path / "worktree"
    dbt_project_dir = worktree_root / "analytics"
    (repo_root / "analytics").mkdir(parents=True)
    dbt_project_dir.mkdir(parents=True)
    (dbt_project_dir / "profiles.yml").write_text("user-managed", encoding="utf-8")

    settings = _clone_settings(tmp_path, repo_root)
    monkeypatch.setattr(
        desktop_worktree, "_load_clone_settings", lambda strict=False: settings
    )
    desktop_worktree._write_clone_profile(
        repo_root,
        worktree_root,
        settings,
        "ANALYTICS__BAR",
    )
    monkeypatch.setattr(
        desktop_worktree,
        "_snowflake_clone_exists",
        lambda settings, clone_database: True,
    )
    worktree = desktop_worktree.Worktree(
        id="bar",
        name="bar",
        branch="typedef/bar",
        path=str(worktree_root),
        base_branch="main",
        is_project_worktree=False,
        is_managed_worktree=True,
        can_remove=True,
    )

    hydrated = desktop_worktree._hydrate_worktree_clone_metadata(repo_root, worktree)

    assert hydrated.clone is not None
    assert hydrated.clone.backend == "snowflake"
    assert hydrated.clone.database == "ANALYTICS__BAR"
    assert hydrated.clone.status == "healthy"
    assert hydrated.clone_error is None


def test_hydrate_worktree_keeps_failed_clone_error_when_metadata_is_stale(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo_root = tmp_path / "repo"
    worktree_root = tmp_path / "worktree"
    (repo_root / "analytics").mkdir(parents=True)
    (worktree_root / "analytics").mkdir(parents=True)
    settings = _clone_settings(tmp_path, repo_root)
    monkeypatch.setattr(
        desktop_worktree, "_load_clone_settings", lambda strict=False: settings
    )
    desktop_worktree._write_clone_profile(
        repo_root,
        worktree_root,
        settings,
        "ANALYTICS__BAR",
    )
    desktop_worktree._write_clone_state(
        worktree_root,
        settings,
        "ANALYTICS__BAR",
        profile_path=worktree_root / "analytics" / "profiles.yml",
        backup_profile_path=None,
        status="failed",
        error="Clone setup failed in background.",
    )
    monkeypatch.setattr(
        desktop_worktree,
        "_snowflake_clone_exists",
        lambda settings, clone_database: False,
    )
    worktree = desktop_worktree.Worktree(
        id="bar",
        name="bar",
        branch="typedef/bar",
        path=str(worktree_root),
        base_branch="main",
        is_project_worktree=False,
        is_managed_worktree=True,
        can_remove=True,
    )

    hydrated = desktop_worktree._hydrate_worktree_clone_metadata(repo_root, worktree)

    assert hydrated.clone is not None
    assert hydrated.clone.status == "stale"
    assert hydrated.clone_error == "Clone setup failed in background."


@pytest.mark.asyncio
async def test_create_worktree_with_clone_returns_creating_metadata_and_queues_background_task(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo_root = Path("/tmp/typedef-home/projects/foo")
    managed_root = Path("/tmp/typedef-home/worktrees")
    # Clean up stale path from previous test runs
    worktree_path = managed_root / "feat-metrics"
    if worktree_path.exists():
        import shutil
        shutil.rmtree(worktree_path)
    captured: list[list[str]] = []

    monkeypatch.setattr(desktop_worktree, "_repo_root", lambda: repo_root)
    monkeypatch.setattr(desktop_worktree, "_worktree_base_dir", lambda: managed_root)
    monkeypatch.setattr(desktop_worktree, "_default_branch", lambda root: "main")
    monkeypatch.setattr(
        desktop_worktree, "_git_branch_exists", lambda root, branch: False
    )

    def fake_run_git(root: Path, args: list[str], timeout: int = 30) -> SimpleNamespace:
        captured.append(args)
        return _completed_process()

    monkeypatch.setattr(desktop_worktree, "_run_git", fake_run_git)
    queued: list[str] = []
    monkeypatch.setattr(
        desktop_worktree,
        "_queue_clone_provisioning",
        lambda background_tasks, root, worktree: (
            queued.append(worktree.id)
            or worktree.model_copy(
                update={
                    "clone": desktop_worktree.SnowflakeClone(
                        database="ANALYTICS__FEAT_METRICS",
                        status="creating",
                    )
                }
            )
        ),
    )

    created = await desktop_worktree.create_worktree(
        desktop_worktree.WorktreeCreateRequest(
            name="feat-metrics",
            base_branch="main",
            clone_data=True,
        ),
        BackgroundTasks(),
    )

    assert captured == [
        [
            "worktree",
            "add",
            "-b",
            "typedef/feat-metrics",
            str((managed_root / "feat-metrics").resolve()),
            "main",
        ]
    ]
    assert queued == ["feat-metrics"]
    assert created.clone is not None
    assert created.clone.backend == "snowflake"
    assert created.clone.database == "ANALYTICS__FEAT_METRICS"
    assert created.clone.status == "creating"


@pytest.mark.asyncio
async def test_create_worktree_rejects_existing_branch(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo_root = Path("/tmp/typedef-home/projects/foo")
    managed_root = Path("/tmp/typedef-home/worktrees")

    monkeypatch.setattr(desktop_worktree, "_repo_root", lambda: repo_root)
    monkeypatch.setattr(desktop_worktree, "_worktree_base_dir", lambda: managed_root)
    monkeypatch.setattr(desktop_worktree, "_default_branch", lambda root: "main")
    monkeypatch.setattr(
        desktop_worktree, "_git_branch_exists", lambda root, branch: True
    )

    with pytest.raises(Exception) as exc:
        await desktop_worktree.create_worktree(
            desktop_worktree.WorktreeCreateRequest(
                name="baz",
                base_branch="main",
            ),
            BackgroundTasks(),
        )

    assert getattr(exc.value, "status_code", None) == 409
    assert "Worktree branch already exists: typedef/baz" in str(exc.value.detail)


def test_clone_metadata_reports_creating_when_async_state_exists(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo_root = tmp_path / "repo"
    worktree_root = tmp_path / "worktree"
    (repo_root / "analytics").mkdir(parents=True)
    worktree_root.mkdir(parents=True)
    settings = _clone_settings(tmp_path, repo_root)

    desktop_worktree._write_clone_state(
        worktree_root,
        settings,
        "ANALYTICS__ASYNC",
        profile_path=None,
        backup_profile_path=None,
        status="creating",
    )
    monkeypatch.setattr(
        desktop_worktree,
        "_snowflake_clone_exists",
        lambda settings, clone_database: False,
    )

    worktree = desktop_worktree.Worktree(
        id="async",
        name="async",
        branch="typedef/async",
        path=str(worktree_root),
        base_branch="main",
        is_project_worktree=False,
        is_managed_worktree=True,
        can_remove=True,
    )

    metadata = desktop_worktree._clone_metadata_for_worktree(
        repo_root, worktree, settings
    )

    assert metadata is not None
    assert metadata.database == "ANALYTICS__ASYNC"
    assert metadata.status == "creating"


def test_record_clone_provisioning_failure_marks_state_failed_without_settings(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo_root = tmp_path / "repo"
    worktree_root = tmp_path / "worktree"
    worktree_root.mkdir(parents=True)
    settings = _clone_settings(tmp_path, repo_root)
    desktop_worktree._write_clone_state(
        worktree_root,
        settings,
        "ANALYTICS__ASYNC",
        profile_path=None,
        backup_profile_path=None,
        status="creating",
    )
    monkeypatch.setattr(
        desktop_worktree,
        "_load_clone_settings",
        lambda strict=False: None,
    )
    worktree = desktop_worktree.Worktree(
        id="async",
        name="async",
        branch="typedef/async",
        path=str(worktree_root),
        base_branch="main",
        is_project_worktree=False,
        is_managed_worktree=True,
        can_remove=True,
    )

    desktop_worktree._record_clone_provisioning_failure(
        repo_root,
        worktree,
        RuntimeError("warehouse unavailable"),
    )

    state = desktop_worktree._read_clone_state(worktree_root)
    assert state is not None
    assert state.status == "failed"
    assert state.error == "warehouse unavailable"


def test_create_and_drop_duckdb_clone_for_worktree(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo_root = tmp_path / "repo"
    worktree_root = tmp_path / "worktree"
    source_db = tmp_path / "analytics.duckdb"
    (repo_root / "analytics").mkdir(parents=True)
    (worktree_root / "analytics").mkdir(parents=True)
    source_db.write_text("duckdb-data", encoding="utf-8")

    cfg_path = tmp_path / "typedef-home" / "config.yaml"
    _write_active_project_config(cfg_path, repo_root)
    monkeypatch.setattr(core_paths, "config_path", lambda: cfg_path)

    settings = _duckdb_clone_settings(tmp_path, repo_root)
    monkeypatch.setattr(
        desktop_worktree, "_load_clone_settings", lambda strict=True: settings
    )

    worktree = desktop_worktree.Worktree(
        id="duck",
        name="duck",
        branch="typedef/duck",
        path=str(worktree_root),
        base_branch="main",
        is_project_worktree=False,
        is_managed_worktree=True,
        can_remove=True,
    )

    created = desktop_worktree._create_clone_for_worktree(repo_root, worktree)

    assert created.clone is not None
    assert created.clone.backend == "duckdb"
    assert Path(created.clone.path).exists()
    assert Path(created.clone.path).read_text(encoding="utf-8") == "duckdb-data"

    cfg = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
    entry = cfg["projects"]["analytics"]["worktrees"]["duck"]
    assert entry["data"]["db_path"] == created.clone.path
    assert entry["clone"]["backend"] == "duckdb"

    dropped = desktop_worktree._drop_clone_for_worktree(repo_root, worktree)

    assert dropped.clone is None
    assert not Path(created.clone.path).exists()


def test_create_duckdb_clone_rejects_directory_target(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo_root = tmp_path / "repo"
    worktree_root = tmp_path / "worktree"
    source_db = tmp_path / "analytics.duckdb"
    (repo_root / "analytics").mkdir(parents=True)
    (worktree_root / "analytics").mkdir(parents=True)
    source_db.write_text("duckdb-data", encoding="utf-8")

    cfg_path = tmp_path / "typedef-home" / "config.yaml"
    _write_active_project_config(cfg_path, repo_root)
    monkeypatch.setattr(core_paths, "config_path", lambda: cfg_path)

    settings = _duckdb_clone_settings(tmp_path, repo_root)
    monkeypatch.setattr(
        desktop_worktree, "_load_clone_settings", lambda strict=True: settings
    )

    worktree = desktop_worktree.Worktree(
        id="duck",
        name="duck",
        branch="typedef/duck",
        path=str(worktree_root),
        base_branch="main",
        is_project_worktree=False,
        is_managed_worktree=True,
        can_remove=True,
    )
    clone_dir_target = (
        tmp_path / "worktrees" / ".clone-data" / "duck" / "analytics.duckdb"
    )
    clone_dir_target.mkdir(parents=True)

    monkeypatch.setattr(
        desktop_worktree,
        "_managed_duckdb_clone_path",
        lambda *_args, **_kwargs: clone_dir_target,
    )

    with pytest.raises(HTTPException, match="not a file"):
        desktop_worktree._create_clone_for_worktree(repo_root, worktree)


def test_managed_duckdb_clone_path_sanitizes_worktree_id_and_stays_managed(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo_root = tmp_path / "repo"
    managed_root = tmp_path / "worktrees"
    (repo_root / "analytics").mkdir(parents=True)
    settings = _duckdb_clone_settings(tmp_path, repo_root)
    worktree = desktop_worktree.Worktree(
        id="../Duck / weird",
        name="duck",
        branch="typedef/duck",
        path=str(tmp_path / "worktree"),
        base_branch="main",
        is_project_worktree=False,
        is_managed_worktree=True,
        can_remove=True,
    )
    monkeypatch.setattr(desktop_worktree, "_worktree_base_dir", lambda: managed_root)

    clone_path = desktop_worktree._managed_duckdb_clone_path(worktree, settings)

    assert clone_path.parent.name.startswith("duck_weird-")
    assert clone_path.name == "analytics.duckdb"
    assert clone_path.is_absolute()
    assert clone_path.relative_to((managed_root / ".clone-data").resolve())


def test_managed_duckdb_clone_path_avoids_sanitized_worktree_id_collisions(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo_root = tmp_path / "repo"
    managed_root = tmp_path / "worktrees"
    (repo_root / "analytics").mkdir(parents=True)
    settings = _duckdb_clone_settings(tmp_path, repo_root)
    monkeypatch.setattr(desktop_worktree, "_worktree_base_dir", lambda: managed_root)

    first = desktop_worktree.Worktree(
        id="duck legacy",
        name="duck legacy",
        branch="typedef/duck-legacy",
        path=str(tmp_path / "worktree-a"),
        base_branch="main",
        is_project_worktree=False,
        is_managed_worktree=True,
        can_remove=True,
    )
    second = desktop_worktree.Worktree(
        id="duck_legacy",
        name="duck_legacy",
        branch="typedef/duck_legacy",
        path=str(tmp_path / "worktree-b"),
        base_branch="main",
        is_project_worktree=False,
        is_managed_worktree=True,
        can_remove=True,
    )

    first_path = desktop_worktree._managed_duckdb_clone_path(first, settings)
    second_path = desktop_worktree._managed_duckdb_clone_path(second, settings)

    assert first_path != second_path


def test_managed_duckdb_worktree_token_stays_within_component_limit() -> None:
    token = desktop_worktree._managed_duckdb_worktree_token("duck" * 100)

    assert len(token) <= 255


def test_read_managed_clone_profile_tolerates_malformed_duckdb_label(
    tmp_path: Path,
) -> None:
    profile_path = tmp_path / "profiles.yml"
    profile_path.write_text(
        "\n".join(
            [
                desktop_worktree._MANAGED_CLONE_PROFILE_MARKER,
                "analytics:",
                "  target: prod",
                "  outputs:",
                "    prod:",
                "      type: duckdb",
                "      path: .",
            ]
        ),
        encoding="utf-8",
    )

    managed = desktop_worktree._read_managed_clone_profile(profile_path)

    assert managed is not None
    assert managed.target.backend == "duckdb"
    assert managed.target.path == Path(".")
    assert managed.target.label is None


def test_read_clone_state_tolerates_malformed_duckdb_label(tmp_path: Path) -> None:
    state_path = tmp_path / ".typedef" / "clone" / "state.yml"
    state_path.parent.mkdir(parents=True)
    state_path.write_text(
        yaml.safe_dump(
            {
                "managed_by": "typedef",
                "backend": "duckdb",
                "path": ".",
                "status": "healthy",
            },
            default_flow_style=False,
            sort_keys=False,
        ),
        encoding="utf-8",
    )

    state = desktop_worktree._read_clone_state(tmp_path)

    assert state is not None
    assert state.target.backend == "duckdb"
    assert state.target.path == Path(".")
    assert state.target.label is None


def test_clone_target_display_label_falls_back_for_dot_path() -> None:
    target = desktop_worktree.CloneTarget(backend="duckdb", path=Path("."))

    assert target.display_label() == "."


def test_read_clone_state_supports_legacy_snowflake_clone_database(
    tmp_path: Path,
) -> None:
    state_path = tmp_path / ".typedef" / "clone" / "state.yml"
    state_path.parent.mkdir(parents=True)
    state_path.write_text(
        yaml.safe_dump(
            {
                "managed_by": "typedef",
                "clone_database": "ANALYTICS__WT_1",
                "status": "creating",
            },
            default_flow_style=False,
            sort_keys=False,
        ),
        encoding="utf-8",
    )

    state = desktop_worktree._read_clone_state(tmp_path)

    assert state is not None
    assert state.target.backend == "snowflake"
    assert state.target.database == "ANALYTICS__WT_1"
    assert state.status == "creating"


def test_drop_duckdb_clone_uses_managed_path_when_source_is_missing(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo_root = tmp_path / "repo"
    worktree_root = tmp_path / "worktree"
    managed_root = tmp_path / "managed"
    (repo_root / "analytics").mkdir(parents=True)
    (worktree_root / "analytics").mkdir(parents=True)

    settings = desktop_worktree.ActiveProjectCloneSettings(
        project_name="analytics",
        dbt_path=repo_root / "analytics",
        profile_name="analytics",
        dbt_target="prod",
        backend="duckdb",
        db_path=tmp_path / "missing.duckdb",
    )
    worktree = desktop_worktree.Worktree(
        id="duck",
        name="duck",
        branch="typedef/duck",
        path=str(worktree_root),
        base_branch="main",
        is_project_worktree=False,
        is_managed_worktree=True,
        can_remove=True,
    )
    monkeypatch.setattr(desktop_worktree, "_worktree_base_dir", lambda: managed_root)
    monkeypatch.setattr(
        desktop_worktree, "_load_clone_settings", lambda strict=True: settings
    )
    monkeypatch.setattr(
        desktop_worktree,
        "_hydrate_worktree_clone_metadata",
        lambda root, worktree, settings=None: worktree,
    )

    clone_path = desktop_worktree._managed_duckdb_clone_path(worktree, settings)
    clone_path.parent.mkdir(parents=True, exist_ok=True)
    clone_path.write_text("duckdb-data", encoding="utf-8")

    dropped = desktop_worktree._drop_clone_for_worktree(repo_root, worktree)

    assert dropped.id == worktree.id
    assert not clone_path.exists()


def test_drop_duckdb_clone_deletes_legacy_managed_path(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo_root = tmp_path / "repo"
    worktree_root = tmp_path / "worktree"
    managed_root = tmp_path / "managed"
    source_db = tmp_path / "analytics source.duckdb"
    (repo_root / "analytics").mkdir(parents=True)
    (worktree_root / "analytics").mkdir(parents=True)
    source_db.write_text("duckdb-data", encoding="utf-8")

    settings = desktop_worktree.ActiveProjectCloneSettings(
        project_name="analytics",
        dbt_path=repo_root / "analytics",
        profile_name="analytics",
        dbt_target="prod",
        backend="duckdb",
        db_path=source_db,
    )
    worktree = desktop_worktree.Worktree(
        id="duck legacy",
        name="duck legacy",
        branch="typedef/duck-legacy",
        path=str(worktree_root),
        base_branch="main",
        is_project_worktree=False,
        is_managed_worktree=True,
        can_remove=True,
    )
    monkeypatch.setattr(desktop_worktree, "_worktree_base_dir", lambda: managed_root)
    monkeypatch.setattr(
        desktop_worktree, "_load_clone_settings", lambda strict=True: settings
    )
    monkeypatch.setattr(
        desktop_worktree,
        "_hydrate_worktree_clone_metadata",
        lambda root, worktree, settings=None: worktree,
    )

    legacy_path = (
        managed_root / ".clone-data" / "duck legacy" / "analytics source.duckdb"
    )
    legacy_path.parent.mkdir(parents=True, exist_ok=True)
    legacy_path.write_text("duckdb-data", encoding="utf-8")

    desktop_worktree._write_clone_profile(
        repo_root,
        worktree_root,
        settings,
        desktop_worktree.CloneTarget(
            backend="duckdb",
            path=legacy_path,
            label="analytics_source.duckdb",
        ),
    )

    desktop_worktree._drop_clone_for_worktree(repo_root, worktree)

    assert not legacy_path.exists()


def test_drop_duckdb_clone_rejects_directory_target(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo_root = tmp_path / "repo"
    worktree_root = tmp_path / "worktree"
    managed_root = tmp_path / "managed"
    source_db = tmp_path / "analytics.duckdb"
    (repo_root / "analytics").mkdir(parents=True)
    (worktree_root / "analytics").mkdir(parents=True)
    source_db.write_text("duckdb-data", encoding="utf-8")

    settings = _duckdb_clone_settings(tmp_path, repo_root)
    worktree = desktop_worktree.Worktree(
        id="duck",
        name="duck",
        branch="typedef/duck",
        path=str(worktree_root),
        base_branch="main",
        is_project_worktree=False,
        is_managed_worktree=True,
        can_remove=True,
    )
    monkeypatch.setattr(desktop_worktree, "_worktree_base_dir", lambda: managed_root)
    monkeypatch.setattr(
        desktop_worktree, "_load_clone_settings", lambda strict=True: settings
    )

    clone_path = desktop_worktree._managed_duckdb_clone_path(worktree, settings)
    clone_path.mkdir(parents=True)

    with pytest.raises(HTTPException, match="not a file"):
        desktop_worktree._drop_clone_for_worktree(repo_root, worktree)


def test_drop_duckdb_clone_skips_unmanaged_metadata_path(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo_root = tmp_path / "repo"
    worktree_root = tmp_path / "worktree"
    managed_root = tmp_path / "managed"
    source_db = tmp_path / "analytics.duckdb"
    rogue_path = tmp_path / "rogue.duckdb"
    (repo_root / "analytics").mkdir(parents=True)
    (worktree_root / "analytics").mkdir(parents=True)
    source_db.write_text("duckdb-data", encoding="utf-8")
    rogue_path.write_text("do not delete", encoding="utf-8")

    settings = _duckdb_clone_settings(tmp_path, repo_root)
    worktree = desktop_worktree.Worktree(
        id="duck",
        name="duck",
        branch="typedef/duck",
        path=str(worktree_root),
        base_branch="main",
        is_project_worktree=False,
        is_managed_worktree=True,
        can_remove=True,
    )
    monkeypatch.setattr(desktop_worktree, "_worktree_base_dir", lambda: managed_root)
    monkeypatch.setattr(
        desktop_worktree, "_load_clone_settings", lambda strict=True: settings
    )
    monkeypatch.setattr(
        desktop_worktree,
        "_hydrate_worktree_clone_metadata",
        lambda root, worktree, settings=None: worktree,
    )

    desktop_worktree._write_clone_profile(
        repo_root,
        worktree_root,
        settings,
        desktop_worktree.CloneTarget(
            backend="duckdb",
            path=rogue_path,
            label="rogue.duckdb",
        ),
    )

    desktop_worktree._drop_clone_for_worktree(repo_root, worktree)

    assert rogue_path.exists()


def test_remove_clone_profile_restores_backup_for_corrupt_managed_root_profile(
    tmp_path: Path,
) -> None:
    repo_root = tmp_path / "repo"
    worktree_root = tmp_path / "worktree"
    (repo_root / "analytics").mkdir(parents=True)
    (worktree_root / "analytics").mkdir(parents=True)
    settings = _duckdb_clone_settings(tmp_path, repo_root)

    root_profile_path = desktop_worktree._root_clone_profile_path(
        repo_root, worktree_root, settings
    )
    root_profile_path.parent.mkdir(parents=True, exist_ok=True)
    root_profile_path.write_text(
        f"{desktop_worktree._MANAGED_CLONE_PROFILE_MARKER}\ninvalid: [\n",
        encoding="utf-8",
    )

    backup_profile_path = desktop_worktree._clone_original_profile_backup_path(
        worktree_root
    )
    backup_profile_path.parent.mkdir(parents=True, exist_ok=True)
    backup_profile_path.write_text("restored-profile", encoding="utf-8")

    desktop_worktree._remove_clone_profile(repo_root, worktree_root, settings)

    assert root_profile_path.read_text(encoding="utf-8") == "restored-profile"


def test_remove_clone_profile_restores_backup_for_non_utf8_managed_profile(
    tmp_path: Path,
) -> None:
    repo_root = tmp_path / "repo"
    worktree_root = tmp_path / "worktree"
    (repo_root / "analytics").mkdir(parents=True)
    (worktree_root / "analytics").mkdir(parents=True)
    settings = _duckdb_clone_settings(tmp_path, repo_root)

    root_profile_path = desktop_worktree._root_clone_profile_path(
        repo_root, worktree_root, settings
    )
    root_profile_path.parent.mkdir(parents=True, exist_ok=True)
    root_profile_path.write_bytes(
        desktop_worktree._MANAGED_CLONE_PROFILE_MARKER.encode("utf-8") + b"\n\xff"
    )

    backup_profile_path = desktop_worktree._clone_original_profile_backup_path(
        worktree_root
    )
    backup_profile_path.parent.mkdir(parents=True, exist_ok=True)
    backup_profile_path.write_text("restored-profile", encoding="utf-8")

    desktop_worktree._remove_clone_profile(repo_root, worktree_root, settings)

    assert root_profile_path.read_text(encoding="utf-8") == "restored-profile"


@pytest.mark.asyncio
async def test_remove_worktree_with_drop_clone_drops_clone_first(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo_root = Path("/tmp/typedef-home/projects/foo")
    managed_path = Path("/tmp/typedef-home/worktrees/baz")
    managed = desktop_worktree.Worktree(
        id="baz",
        name="baz",
        branch="typedef/baz",
        path=str(managed_path),
        base_branch="main",
        is_project_worktree=False,
        is_managed_worktree=True,
        can_remove=True,
        clone=desktop_worktree.SnowflakeClone(
            database="ANALYTICS__BAZ",
            status="healthy",
        ),
    )
    events: list[str] = []

    monkeypatch.setattr(desktop_worktree, "_repo_root", lambda: repo_root)
    monkeypatch.setattr(desktop_worktree, "_parse_worktrees", lambda root: [managed])
    monkeypatch.setattr(
        desktop_worktree,
        "_drop_clone_for_worktree",
        lambda root, worktree: events.append(f"drop:{worktree.name}"),
    )

    def fake_run_git(root: Path, args: list[str], timeout: int = 30) -> SimpleNamespace:
        events.append("git-remove")
        return _completed_process()

    monkeypatch.setattr(desktop_worktree, "_run_git", fake_run_git)

    removed = await desktop_worktree.remove_worktree("baz", drop_clone=True)

    assert events == ["drop:baz", "git-remove"]
    assert removed.status == "removed"



# Per-worktree graph tests removed — worktrees no longer create or drop
# their own graph databases.  Catalog and sync always use the project graph.
# Per-worktree graphs are reserved for future work.
