from __future__ import annotations

import asyncio
import importlib
from pathlib import Path
from types import SimpleNamespace

import core.paths as core_paths
import pytest
import yaml
from fastapi import FastAPI
from fastapi.testclient import TestClient
from lineage.api import desktop_quickstart
from lineage.utils.git import CloneProgress


class FakeProcess:
    def __init__(self, target, args, daemon=False):
        self.target = target
        self.args = args
        self.daemon = daemon
        self.pid = 4242
        self._alive = False
        self.exitcode = 0

    def start(self):
        self._alive = True

    def join(self, timeout=None):
        self._alive = False

    def is_alive(self):
        return self._alive

    def terminate(self):
        self._alive = False

    def close(self):
        self._alive = False


class FakeQueue:
    def __init__(self):
        self.items = []
        self.closed = False
        self.joined = False

    def empty(self):
        return not self.items

    def get_nowait(self):
        if not self.items:
            raise desktop_quickstart.queue_module.Empty
        return self.items.pop(0)

    def get(self, timeout=None):
        return self.get_nowait()

    def close(self):
        self.closed = True

    def join_thread(self):
        self.joined = True

    def put_nowait(self, item):
        self.items.append(item)


class FlipToCancelledQueue(FakeQueue):
    def __init__(self, op):
        super().__init__()
        self.op = op
        self._flipped = False

    def get(self, timeout=None):
        if not self._flipped:
            self._flipped = True
            self.op.status = "cancelled"
            self.op.last_event = {
                "stage": "clone",
                "status": "cancelled",
                "message": "Quick Start cancelled by user",
                "current": 1,
                "total": 8,
                "terminal": True,
                "project_name": desktop_quickstart.QUICKSTART_PROJECT_NAME,
                "display_name": desktop_quickstart.QUICKSTART_DISPLAY_NAME,
            }
        raise desktop_quickstart.queue_module.Empty


def _terminal_event_file(quickstart_id: str) -> Path:
    return core_paths.logs_dir() / f"quickstart-{quickstart_id}.json"


def _build_client(tmp_path, monkeypatch) -> TestClient:
    typedef_home = Path.home() / ".tmp-typedef-tests" / tmp_path.name
    if typedef_home.exists():
        import shutil

        shutil.rmtree(typedef_home)
    typedef_home.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("TYPEDEF_HOME", str(typedef_home))
    core_paths.typedef_home.cache_clear()
    desktop_quickstart._quickstart_ops.clear()
    monkeypatch.setattr(desktop_quickstart, "Process", FakeProcess)

    app = FastAPI()
    app.include_router(desktop_quickstart.router)
    return TestClient(app)


def test_start_quickstart_creates_sample_project_config(tmp_path, monkeypatch):
    client = _build_client(tmp_path, monkeypatch)
    typedef_home = Path(core_paths.typedef_home())

    response = client.post("/desktop/quickstart/start")

    assert response.status_code == 200
    data = response.json()
    assert data["project_name"] == desktop_quickstart.QUICKSTART_PROJECT_NAME
    assert data["display_name"] == desktop_quickstart.QUICKSTART_DISPLAY_NAME

    config = yaml.safe_load((typedef_home / "config.yaml").read_text())
    project = config["projects"][desktop_quickstart.QUICKSTART_PROJECT_NAME]
    assert project["status"] == "initializing"
    assert config["default_project"] == desktop_quickstart.QUICKSTART_PROJECT_NAME
    assert project["dbt_path"] == str(
        typedef_home / "projects" / desktop_quickstart.QUICKSTART_PROJECT_NAME
    )
    assert project["profiles_dir"] == str(
        typedef_home / "profiles" / desktop_quickstart.QUICKSTART_PROJECT_NAME
    )
    assert project["data"]["db_path"].endswith(
        desktop_quickstart.QUICKSTART_DUCKDB_FILENAME
    )
    assert Path(project["dbt_path"]).exists()


def test_start_quickstart_rejects_existing_sample_project(tmp_path, monkeypatch):
    client = _build_client(tmp_path, monkeypatch)

    first = client.post("/desktop/quickstart/start")
    second = client.post("/desktop/quickstart/start")

    assert first.status_code == 200
    assert second.status_code == 409
    assert "Sample project already exists" in second.json()["detail"]


def test_progress_terminal_response_cleans_up_resources(tmp_path, monkeypatch):
    client = _build_client(tmp_path, monkeypatch)

    process = FakeProcess(target=None, args=())
    queue = FakeQueue()
    op = desktop_quickstart.QuickstartOperation(
        quickstart_id="qs-terminal",
        process=process,
        queue=queue,
        status="completed",
        terminal_event_path=_terminal_event_file("qs-terminal"),
        last_event={
            "stage": "semantic",
            "status": "completed",
            "message": "Quick Start complete",
            "current": 8,
            "total": 8,
            "terminal": True,
            "project_name": desktop_quickstart.QUICKSTART_PROJECT_NAME,
            "display_name": desktop_quickstart.QUICKSTART_DISPLAY_NAME,
        },
    )
    desktop_quickstart._quickstart_ops[op.quickstart_id] = op

    response = client.get(f"/desktop/quickstart/{op.quickstart_id}/progress")

    assert response.status_code == 200
    assert "Quick Start complete" in response.text
    assert op.process is None
    assert op.queue is None
    assert queue.closed is True
    assert queue.joined is True


def test_cancel_quickstart_cleans_up_resources(tmp_path, monkeypatch):
    client = _build_client(tmp_path, monkeypatch)

    process = FakeProcess(target=None, args=())
    process.start()
    queue = FakeQueue()
    op = desktop_quickstart.QuickstartOperation(
        quickstart_id="qs-cancel",
        process=process,
        queue=queue,
        cancel_event=desktop_quickstart.multiprocessing.Event(),
        status="running",
        terminal_event_path=_terminal_event_file("qs-cancel"),
    )
    desktop_quickstart._quickstart_ops[op.quickstart_id] = op

    response = client.post(f"/desktop/quickstart/{op.quickstart_id}/cancel")

    assert response.status_code == 200
    assert op.status == "cancelled"
    assert op.process is None
    assert op.queue is None
    assert op.cancel_event is None
    assert queue.closed is True
    assert queue.joined is True


def test_progress_stream_emits_cancelled_event_after_status_flips(
    tmp_path, monkeypatch
):
    client = _build_client(tmp_path, monkeypatch)

    process = FakeProcess(target=None, args=())
    process.start()
    op = desktop_quickstart.QuickstartOperation(
        quickstart_id="qs-cancel-stream",
        process=process,
        status="running",
        terminal_event_path=_terminal_event_file("qs-cancel-stream"),
    )
    op.queue = FlipToCancelledQueue(op)
    desktop_quickstart._quickstart_ops[op.quickstart_id] = op

    response = client.get(f"/desktop/quickstart/{op.quickstart_id}/progress")

    assert response.status_code == 200
    assert "Quick Start cancelled by user" in response.text


def test_watch_quickstart_process_preserves_awaiting_input_terminal_event(
    tmp_path, monkeypatch
):
    _build_client(tmp_path, monkeypatch)

    process = FakeProcess(target=None, args=())
    terminal_event_path = _terminal_event_file("qs-awaiting")
    terminal_event_path.parent.mkdir(parents=True, exist_ok=True)
    terminal_event_path.write_text(
        '{"stage":"semantic","status":"awaiting_input","message":"Sample project ready without semantic analysis","current":8,"total":8,"terminal":true,"project_name":"medallion_reference","display_name":"medallion-reference"}'
    )

    op = desktop_quickstart.QuickstartOperation(
        quickstart_id="qs-awaiting",
        process=process,
        queue=FakeQueue(),
        status="running",
        terminal_event_path=terminal_event_path,
    )
    desktop_quickstart._quickstart_ops[op.quickstart_id] = op

    desktop_quickstart._watch_quickstart_process(op.quickstart_id)

    assert op.status == "awaiting_input"
    assert op.last_event is not None
    assert op.last_event["status"] == "awaiting_input"


def test_progress_stream_keeps_running_past_intermediate_completed_events(
    tmp_path, monkeypatch
):
    client = _build_client(tmp_path, monkeypatch)

    process = FakeProcess(target=None, args=())
    process.start()
    queue = FakeQueue()
    queue.items = [
        {
            "stage": "clone",
            "status": "completed",
            "message": "Cloned sample project",
            "current": 1,
            "total": 8,
            "project_name": desktop_quickstart.QUICKSTART_PROJECT_NAME,
            "display_name": desktop_quickstart.QUICKSTART_DISPLAY_NAME,
        },
        {
            "stage": "venv",
            "status": "running",
            "message": "Preparing dbt DuckDB environment",
            "current": 2,
            "total": 8,
            "project_name": desktop_quickstart.QUICKSTART_PROJECT_NAME,
            "display_name": desktop_quickstart.QUICKSTART_DISPLAY_NAME,
        },
        {
            "stage": "semantic",
            "status": "completed",
            "message": "Quick Start complete",
            "current": 8,
            "total": 8,
            "terminal": True,
            "project_name": desktop_quickstart.QUICKSTART_PROJECT_NAME,
            "display_name": desktop_quickstart.QUICKSTART_DISPLAY_NAME,
        },
    ]
    op = desktop_quickstart.QuickstartOperation(
        quickstart_id="qs-stream",
        process=process,
        queue=queue,
        status="running",
        terminal_event_path=_terminal_event_file("qs-stream"),
    )
    desktop_quickstart._quickstart_ops[op.quickstart_id] = op

    response = client.get(f"/desktop/quickstart/{op.quickstart_id}/progress")

    assert response.status_code == 200
    assert "Cloned sample project" in response.text
    assert "Preparing dbt DuckDB environment" in response.text
    assert "Quick Start complete" in response.text


def test_strip_ansi_removes_terminal_sequences():
    raw = "\x1b[0mhello\x1b[32m world\x1b[0m"

    assert desktop_quickstart._strip_ansi(raw) == "hello world"


def test_quickstart_worker_reports_actual_stage_on_error(tmp_path, monkeypatch):
    _build_client(tmp_path, monkeypatch)
    typedef_home = Path(core_paths.typedef_home())
    project_name = desktop_quickstart.QUICKSTART_PROJECT_NAME
    quickstart_id = "qs-build-error"
    (typedef_home / "projects" / project_name).mkdir(parents=True, exist_ok=True)

    async def fake_clone_stage(project_dir, queue, cancel_event):
        return None

    def fake_run_dbt_stage(*, stage, **kwargs):
        if stage == "build":
            raise RuntimeError("\x1b[31mbuild failed\x1b[0m")

    monkeypatch.setattr(desktop_quickstart, "_run_clone_stage", fake_clone_stage)
    monkeypatch.setattr(desktop_quickstart, "_run_dbt_stage", fake_run_dbt_stage)
    monkeypatch.setattr(desktop_quickstart, "_load_runtime_env", lambda project: {})
    monkeypatch.setattr(
        desktop_quickstart,
        "_delete_quickstart_project",
        lambda previous_default_project=None: None,
    )

    helpers_module = importlib.import_module("lineage.tui.wizards.init.helpers")
    monkeypatch.setattr(
        helpers_module, "ensure_dbt_venv", lambda adapter: Path("/tmp/dbt-venv")
    )

    queue = FakeQueue()
    cancel_event = SimpleNamespace(is_set=lambda: False)

    desktop_quickstart._quickstart_worker(
        project_name,
        None,
        quickstart_id,
        queue,
        cancel_event,
    )

    assert queue.items
    terminal_event = queue.items[-1]
    assert terminal_event["stage"] == "build"
    assert terminal_event["status"] == "error"
    assert terminal_event["message"] == "build failed"


def test_run_clone_stage_raises_helper_error_message(tmp_path, monkeypatch):
    async def fake_clone_repo_with_progress(url, dest_path):
        yield CloneProgress(
            phase="error",
            percent=0,
            message="fatal: repository 'https://github.com/typedef-ai/missing.git/' not found",
        )

    git_module = importlib.import_module("lineage.utils.git")
    monkeypatch.setattr(
        git_module,
        "clone_repo_with_progress",
        fake_clone_repo_with_progress,
    )

    queue = FakeQueue()
    cancel_event = SimpleNamespace(is_set=lambda: False)

    with pytest.raises(
        RuntimeError,
        match="fatal: repository 'https://github.com/typedef-ai/missing.git/' not found",
    ):
        asyncio.run(
            desktop_quickstart._run_clone_stage(tmp_path / "repo", queue, cancel_event)
        )


def test_load_runtime_env_includes_existing_process_credentials(tmp_path, monkeypatch):
    _build_client(tmp_path, monkeypatch)
    monkeypatch.setenv("OPENAI_API_KEY", "sk-openai-stored")

    loaded = desktop_quickstart._load_runtime_env(
        desktop_quickstart.QUICKSTART_PROJECT_NAME
    )

    assert loaded["OPENAI_API_KEY"] == "sk-openai-stored"


def test_run_sync_stage_persists_synced_commit(tmp_path, monkeypatch):
    """After sync, _persist_quickstart_synced_commit should write last_synced_commit."""
    _build_client(tmp_path, monkeypatch)
    typedef_home = Path(core_paths.typedef_home())
    project_name = desktop_quickstart.QUICKSTART_PROJECT_NAME

    # Set up project dir as a git repo so rev-parse HEAD works
    import os
    import subprocess

    project_dir = core_paths.projects_dir() / project_name
    project_dir.mkdir(parents=True, exist_ok=True)

    # Seed a config with the project but no last_synced_commit
    config = {
        "default_project": project_name,
        "projects": {project_name: {"dbt_path": str(project_dir)}},
    }
    (typedef_home / "config.yaml").write_text(yaml.dump(config))

    git_env = {
        **dict(os.environ),
        "GIT_AUTHOR_NAME": "test",
        "GIT_AUTHOR_EMAIL": "t@t",
        "GIT_COMMITTER_NAME": "test",
        "GIT_COMMITTER_EMAIL": "t@t",
    }
    subprocess.run(["git", "init", str(project_dir)], capture_output=True)
    (project_dir / "dummy").write_text("x")
    subprocess.run(["git", "-C", str(project_dir), "add", "."], capture_output=True)
    subprocess.run(
        ["git", "-C", str(project_dir), "commit", "-m", "init"],
        capture_output=True,
        env=git_env,
    )

    desktop_quickstart._persist_quickstart_synced_commit(project_name)

    updated = yaml.safe_load((typedef_home / "config.yaml").read_text())
    commit = updated["projects"][project_name].get("last_synced_commit")
    assert commit is not None
    assert len(commit) == 40  # full SHA


def test_run_sync_stage_keeps_sync_completed_after_semantic_boundary(monkeypatch):
    queue = FakeQueue()

    class FakeConfig:
        @classmethod
        def from_project_name(cls, project_name, full=False, skip_semantic=False):
            return cls()

    class FakeStageResult:
        stage = "semantic"
        skipped = True

    class FakeResult:
        stages = [FakeStageResult()]

    class FakeOrchestrator:
        def __init__(self, config, progress_callback):
            self.progress_callback = progress_callback

        def run(self):
            self.progress_callback("artifacts", 0, 0)
            self.progress_callback("semantic", 0, 0)
            self.progress_callback("overview", 0, 0)
            return FakeResult()

    monkeypatch.setattr(desktop_quickstart, "_load_runtime_env", lambda project: {})

    orchestrator_module = importlib.import_module("ingest.unified.orchestrator")
    stages_types_module = importlib.import_module("ingest.unified.stages.types")
    monkeypatch.setattr(
        orchestrator_module,
        "UnifiedOrchestrator",
        FakeOrchestrator,
    )
    monkeypatch.setattr(
        stages_types_module,
        "UnifiedPipelineConfig",
        FakeConfig,
    )

    ran_semantic = desktop_quickstart._run_sync_stage(
        desktop_quickstart.QUICKSTART_PROJECT_NAME,
        queue,
        SimpleNamespace(is_set=lambda: False),
    )

    assert ran_semantic is False
    sync_events = [event for event in queue.items if event["stage"] == "sync"]
    assert sync_events[-1]["status"] == "completed"
    assert sync_events[-1]["message"] == "Catalog synced"
    assert not any(
        event["stage"] == "sync"
        and event["status"] == "running"
        and event["message"] == "Generating project overview"
        for event in queue.items
    )
