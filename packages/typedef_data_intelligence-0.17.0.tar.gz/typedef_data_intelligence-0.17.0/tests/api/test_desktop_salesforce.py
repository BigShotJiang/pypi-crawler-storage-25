"""Tests for Salesforce auth endpoints in the desktop setup API."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from fastapi import HTTPException
from lineage.api.desktop_setup import (
    TestSalesforceRequest,
    _is_salesforce_host,
    _validate_salesforce_client_id,
    _validate_salesforce_instance_url,
    _validate_salesforce_login_url,
)
from lineage.api.desktop_setup import (
    test_salesforce as _test_salesforce_endpoint,
)

# ── _is_salesforce_host ──────────────────────────────────────────────


@pytest.mark.parametrize(
    "host,expected",
    [
        ("login.salesforce.com", True),
        ("test.salesforce.com", True),
        ("mycompany.my.salesforce.com", True),
        ("na1.salesforce.com", True),
        ("mycompany.lightning.force.com", True),
        ("attacker.com", False),
        ("salesforce.com.evil.com", False),
        ("", False),
    ],
)
def test_is_salesforce_host(host: str, expected: bool) -> None:
    assert _is_salesforce_host(host) is expected


# ── _validate_salesforce_client_id ───────────────────────────────────


def test_client_id_accepts_valid() -> None:
    _validate_salesforce_client_id("3MVG9abc123xyz")


def test_client_id_rejects_url() -> None:
    with pytest.raises(HTTPException, match="looks like a URL"):
        _validate_salesforce_client_id("https://mycompany.my.salesforce.com")


def test_client_id_rejects_http_url() -> None:
    with pytest.raises(HTTPException, match="looks like a URL"):
        _validate_salesforce_client_id("http://login.salesforce.com")


def test_client_id_rejects_email() -> None:
    with pytest.raises(HTTPException, match="email address"):
        _validate_salesforce_client_id("user@example.com")


def test_client_id_rejects_spaces() -> None:
    with pytest.raises(HTTPException, match="should not contain spaces"):
        _validate_salesforce_client_id("3MVG9 abc 123")


def test_client_id_rejects_empty() -> None:
    with pytest.raises(HTTPException, match="required"):
        _validate_salesforce_client_id("")


def test_client_id_rejects_whitespace_only() -> None:
    with pytest.raises(HTTPException, match="required"):
        _validate_salesforce_client_id("   ")


# ── _validate_salesforce_login_url ───────────────────────────────────


def test_login_url_accepts_production() -> None:
    _validate_salesforce_login_url("https://login.salesforce.com")


def test_login_url_accepts_sandbox() -> None:
    _validate_salesforce_login_url("https://test.salesforce.com")


def test_login_url_accepts_my_domain() -> None:
    _validate_salesforce_login_url("https://acme.my.salesforce.com")


def test_login_url_rejects_http() -> None:
    with pytest.raises(HTTPException, match="must use HTTPS"):
        _validate_salesforce_login_url("http://login.salesforce.com")


def test_login_url_rejects_arbitrary_host() -> None:
    with pytest.raises(HTTPException, match="Unrecognized Salesforce login host"):
        _validate_salesforce_login_url("https://evil.example.com")


def test_login_url_rejects_lookalike() -> None:
    with pytest.raises(HTTPException, match="Unrecognized Salesforce login host"):
        _validate_salesforce_login_url("https://salesforce.com.evil.com")


def test_login_url_rejects_empty_scheme() -> None:
    with pytest.raises(HTTPException, match="must use HTTPS"):
        _validate_salesforce_login_url("login.salesforce.com")


# ── _validate_salesforce_instance_url ────────────────────────────────


def test_instance_url_accepts_valid() -> None:
    _validate_salesforce_instance_url("https://na1.salesforce.com")


def test_instance_url_accepts_force_domain() -> None:
    _validate_salesforce_instance_url("https://acme.lightning.force.com")


def test_instance_url_rejects_http() -> None:
    with pytest.raises(HTTPException, match="must use HTTPS"):
        _validate_salesforce_instance_url("http://na1.salesforce.com")


def test_instance_url_rejects_internal() -> None:
    with pytest.raises(HTTPException, match="Unrecognized Salesforce instance host"):
        _validate_salesforce_instance_url("https://169.254.169.254")


def test_instance_url_rejects_arbitrary() -> None:
    with pytest.raises(HTTPException, match="Unrecognized Salesforce instance host"):
        _validate_salesforce_instance_url("https://evil.example.com")


# ── test_salesforce endpoint ─────────────────────────────────────────


@pytest.mark.asyncio
async def test_sf_oauth_pkce_with_tokens() -> None:
    mock_stored = MagicMock(access_token="tok", instance_url="https://na1.salesforce.com")
    with patch(
        "ingest.static_loaders.salesforce.auth.token_store.TokenStore",
        return_value=MagicMock(load=MagicMock(return_value=mock_stored)),
    ):
        req = TestSalesforceRequest(auth_type="oauth_pkce")
        resp = await _test_salesforce_endpoint(req)
    assert resp.success is True
    assert "na1.salesforce.com" in resp.message


@pytest.mark.asyncio
async def test_sf_oauth_pkce_no_tokens() -> None:
    with patch(
        "ingest.static_loaders.salesforce.auth.token_store.TokenStore",
        return_value=MagicMock(load=MagicMock(return_value=None)),
    ):
        req = TestSalesforceRequest(auth_type="oauth_pkce")
        resp = await _test_salesforce_endpoint(req)
    assert resp.success is False
    assert "No OAuth tokens" in resp.message


@pytest.mark.asyncio
async def test_sf_password_missing_fields() -> None:
    req = TestSalesforceRequest(
        auth_type="password",
        instance_url="https://na1.salesforce.com",  # gitleaks:allow
    )
    resp = await _test_salesforce_endpoint(req)
    assert resp.success is False
    assert "required" in resp.message


@pytest.mark.asyncio
async def test_sf_password_ssrf_rejected() -> None:
    req = TestSalesforceRequest(
        auth_type="password",
        instance_url="https://169.254.169.254",
        username="u",
        password="p",
        security_token="t",
    )
    with pytest.raises(HTTPException, match="Unrecognized Salesforce instance host"):
        await _test_salesforce_endpoint(req)


@pytest.mark.asyncio
async def test_sf_client_credentials_missing_fields() -> None:
    req = TestSalesforceRequest(auth_type="client_credentials", client_id="cid")
    resp = await _test_salesforce_endpoint(req)
    assert resp.success is False
    assert "Client ID and Client Secret" in resp.message


@pytest.mark.asyncio
async def test_sf_client_credentials_success() -> None:
    mock_creds = MagicMock(instance_url="https://na1.salesforce.com")
    mock_auth = MagicMock(authenticate=MagicMock(return_value=mock_creds))
    with patch(
        "ingest.static_loaders.salesforce.auth.client_creds.ClientCredentialsAuth",
        return_value=mock_auth,
    ):
        req = TestSalesforceRequest(
            auth_type="client_credentials",
            client_id="cid",
            client_secret="sec",
        )
        resp = await _test_salesforce_endpoint(req)
    assert resp.success is True
    assert "na1.salesforce.com" in resp.message
