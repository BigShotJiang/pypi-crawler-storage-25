from __future__ import annotations

import os

from lineage.api import desktop_runtime


def test_parse_args_defaults_to_loopback_host_and_port() -> None:
    args = desktop_runtime.parse_args([])

    assert args.host == "127.0.0.1"
    assert args.port == 8000


def test_main_sets_desktop_profile_before_running(monkeypatch) -> None:
    calls: dict[str, object] = {}
    fake_app = object()

    def fake_load_app() -> object:
        calls["profile_before_load"] = os.environ.get("TYPEDEF_API_PROFILE")
        return fake_app

    def fake_run(
        app,
        *,
        host: str,
        port: int,
        log_level: str,
        access_log: bool,
        timeout_graceful_shutdown: int,
    ) -> None:
        calls.update(
            {
                "app": app,
                "host": host,
                "port": port,
                "log_level": log_level,
                "access_log": access_log,
                "timeout_graceful_shutdown": timeout_graceful_shutdown,
                "profile": os.environ.get("TYPEDEF_API_PROFILE"),
            }
        )

    monkeypatch.delenv("TYPEDEF_API_PROFILE", raising=False)
    monkeypatch.setattr(desktop_runtime.uvicorn, "run", fake_run)
    monkeypatch.setattr(desktop_runtime, "load_app", fake_load_app)

    desktop_runtime.main(["--host", "127.0.0.1", "--port", "9001"])

    assert calls == {
        "profile_before_load": "desktop",
        "app": fake_app,
        "host": "127.0.0.1",
        "port": 9001,
        "log_level": "info",
        "access_log": True,
        "timeout_graceful_shutdown": 5,
        "profile": "desktop",
    }
