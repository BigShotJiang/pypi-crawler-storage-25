from __future__ import annotations

import importlib
from pathlib import Path

import pytest
from lineage.api import desktop_setup
from lineage.utils.git import CloneProgress


@pytest.mark.asyncio
async def test_run_clone_records_helper_error_message(
    tmp_path: Path, monkeypatch
) -> None:
    clone_id = "clone-1"
    desktop_setup._clone_ops.clear()
    desktop_setup._clone_ops[clone_id] = {
        "status": "pending",
        "dest": tmp_path / "repo",
        "url": "https://github.com/typedef-ai/missing.git",
        "error": None,
    }

    async def fake_clone_repo_with_progress(url: str, dest_path: Path):
        yield CloneProgress(
            phase="error",
            percent=0,
            message="fatal: repository 'https://github.com/typedef-ai/missing.git/' not found",
        )

    git_module = importlib.import_module("lineage.utils.git")
    monkeypatch.setattr(
        git_module,
        "clone_repo_with_progress",
        fake_clone_repo_with_progress,
    )

    await desktop_setup._run_clone(
        clone_id,
        "https://github.com/typedef-ai/missing.git",
        tmp_path / "repo",
    )

    assert desktop_setup._clone_ops[clone_id]["status"] == "error"
    assert (
        desktop_setup._clone_ops[clone_id]["error"]
        == "fatal: repository 'https://github.com/typedef-ai/missing.git/' not found"
    )
