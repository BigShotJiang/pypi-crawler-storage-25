"""Tests for SurrealUnifiedGraphReader.search() against an in-memory SurrealDB.

Covers OR semantics, prefix matching, description fallback, kind exclusion,
and edge cases around missing/null properties.description.
"""

import pytest
from core.backends.unified_graph.surreal.load import (
    connect,
    ensure_indexes,
    ensure_tables,
)
from core.backends.unified_graph.surreal.query import q
from core.backends.unified_graph.surreal.reader import SurrealUnifiedGraphReader


@pytest.fixture(scope="module")
def reader():
    """Set up an in-memory SurrealDB with test data, return a reader."""
    db = connect(url="mem://", namespace="test_search", database="test_search")
    ensure_tables(db)
    ensure_indexes(db)

    models = [
        # (name, kind, source_label, description or None)
        (
            "fct_revenue_monthly",
            "model",
            "DbtModel",
            "Monthly revenue aggregation by customer",
        ),
        (
            "fct_revenue_daily",
            "model",
            "DbtModel",
            "Daily revenue from billing system",
        ),
        ("stg_server_events", "model", "DbtModel", "Raw server event logs staging"),
        ("dim_customer_segments", "model", "DbtModel", None),
        ("fct_daily_active_users", "model", "DbtModel", "Daily active user counts"),
        ("stg_event_logs", "model", "DbtModel", None),
        ("dim_date", "model", "DbtModel", None),
    ]
    for name, kind, source_label, desc in models:
        props = f"{{ description: '{desc}' }}" if desc else "{}"
        q(
            db,
            f"CREATE process SET name=$name, kind=$kind, source='dbt', "
            f"source_family='transformation', node_type='process', "
            f"source_label=$sl, canonical_id=$sid, properties={props};",
            name=name,
            kind=kind,
            sl=source_label,
            sid=f"model.project.{name}",
        )

    # Add some columns
    columns = [
        (
            "server_id",
            "column",
            "DbtColumn",
            "model.project.dim_customer_segments.server_id",
        ),
        (
            "revenue_amount",
            "column",
            "DbtColumn",
            "model.project.fct_revenue_monthly.revenue_amount",
        ),
    ]
    for name, kind, source_label, canonical_id in columns:
        q(
            db,
            "CREATE attribute SET name=$name, kind=$kind, source='dbt', "
            "source_family='transformation', node_type='attribute', "
            "source_label=$sl, canonical_id=$sid, properties={};",
            name=name,
            kind=kind,
            sl=source_label,
            sid=canonical_id,
        )

    # Add a column with snowflake source (physical — should be excluded by SEARCH_EXCLUDED_KINDS)
    q(
        db,
        "CREATE attribute SET name='server_id', kind='column', source='snowflake', "
        "source_family='warehouse', node_type='attribute', source_label='PhysicalColumn', "
        "canonical_id='physical::DB.schema.tbl.server_id', properties={};",
    )

    # Add a derivation (should be excluded)
    q(
        db,
        "CREATE process SET name='derive:project.model.col', kind='derivation', source='dbt', "
        "source_family='transformation', node_type='process', source_label='Derivation', "
        "canonical_id='derive:model.project.model.col', properties={};",
    )

    # Add a resource with no properties at all
    q(
        db,
        "CREATE resource SET name='some_test', kind='test', source='dbt', "
        "source_family='transformation', node_type='resource', "
        "source_label='DbtTest', canonical_id='test.project.some_test.abc123', properties={};",
    )

    # Add a resource with properties but no description key
    q(
        db,
        "CREATE resource SET name='some_macro', kind='macro', source='dbt', "
        "source_family='transformation', node_type='resource', "
        "source_label='DbtMacro', canonical_id='macro.project.some_macro', "
        "properties={ tags: ['utils'] };",
    )

    return SurrealUnifiedGraphReader(db)


# ── OR semantics ─────────────────────────────────────────────────────────


class TestMultiTermOR:
    def test_multi_term_returns_results(self, reader):
        """Multi-word query should match entities containing ANY term."""
        results = reader.search("server event daily", limit=20)
        names = {r["name"] for r in results}
        assert len(results) >= 3
        assert "stg_server_events" in names

    def test_multi_term_scores_sum(self, reader):
        """Entities matching more terms should rank higher."""
        results = reader.search("server event", limit=20)
        names = [r["name"] for r in results]
        # stg_server_events matches both "server" and "event"
        if "stg_server_events" in names and "stg_event_logs" in names:
            idx_both = names.index("stg_server_events")
            idx_one = names.index("stg_event_logs")
            assert idx_both < idx_one, "Two-term match should rank above one-term match"


# ── Prefix matching ──────────────────────────────────────────────────────


class TestPrefixMatching:
    def test_short_prefix(self, reader):
        """Short prefix should match via edgengram."""
        results = reader.search("rev", limit=10)
        names = {r["name"] for r in results}
        assert "fct_revenue_monthly" in names or "fct_revenue_daily" in names

    def test_underscore_prefix(self, reader):
        """Underscore-joined prefix should be split and match."""
        results = reader.search("fct_rev", limit=10)
        names = {r["name"] for r in results}
        assert "fct_revenue_monthly" in names or "fct_revenue_daily" in names

    def test_single_term(self, reader):
        results = reader.search("revenue", limit=10)
        assert len(results) >= 1
        assert all(r.get("score", 0) > 0 for r in results)


# ── Description fallback ─────────────────────────────────────────────────


class TestDescriptionFallback:
    def test_matches_description_text(self, reader):
        """Search should find entities via description when name doesn't match."""
        results = reader.search("billing", limit=10)
        names = {r["name"] for r in results}
        assert (
            "fct_revenue_daily" in names
        )  # description: "Daily revenue from billing system"

    def test_null_description_no_crash(self, reader):
        """Entities with null/missing description should not crash the search."""
        # dim_customer_segments has no description
        results = reader.search("customer", limit=10)
        names = {r["name"] for r in results}
        assert "dim_customer_segments" in names

    def test_empty_properties_no_crash(self, reader):
        """Entities with empty properties dict should not crash description search."""
        results = reader.search("some_test", limit=10)
        assert len(results) >= 1

    def test_properties_without_description_key(self, reader):
        """Entities with properties but no description key should not crash."""
        results = reader.search("some_macro", limit=10)
        assert len(results) >= 1


# ── Kind exclusion ───────────────────────────────────────────────────────


class TestKindExclusion:
    def test_column_excluded(self, reader):
        """All columns (both dbt and physical) should be excluded from search."""
        results = reader.search("server_id", limit=20)
        for r in results:
            assert r.get("kind") != "column", (
                f"column should be excluded: {r['name']}"
            )

    def test_derivation_excluded(self, reader):
        """Derivation processes should not appear in search results."""
        results = reader.search("derive", limit=20)
        for r in results:
            assert r.get("kind") != "derivation", (
                f"derivation should be excluded: {r['name']}"
            )


# ── source_label in results ──────────────────────────────────────────────


class TestSourceLabel:
    def test_source_label_present(self, reader):
        results = reader.search("revenue", limit=5)
        for r in results:
            assert r.get("source_label"), f"source_label missing for {r['name']}"

    def test_source_id_present(self, reader):
        results = reader.search("revenue", limit=5)
        for r in results:
            assert r.get("canonical_id"), f"canonical_id missing for {r['name']}"


# ── Edge cases ───────────────────────────────────────────────────────────


class TestEdgeCases:
    def test_empty_query(self, reader):
        results = reader.search("", limit=10)
        assert results == []

    def test_single_char_query(self, reader):
        """Single character should return empty (min term length is 2)."""
        results = reader.search("a", limit=10)
        assert results == []

    def test_kinds_filter(self, reader):
        results = reader.search("server", kinds=["model"], limit=10)
        for r in results:
            assert r.get("kind") == "model"
