"""Tests ensuring all schema enum kinds are covered in search-related mappings.

If a new kind is added to the Kind enum but not to the search exclusion list
or the frontend badge map, these tests will catch it.
"""

from core.backends.unified_graph.surreal.reader import SEARCH_EXCLUDED_KINDS
from core.backends.unified_graph.surreal.schema import (
    Kind,
    Source,
)

# ── Excluded kinds in reader.search() ────────────────────────────────────

_EXCLUDED_KINDS = SEARCH_EXCLUDED_KINDS

# Kinds that are searchable (not excluded, and expected to appear in results)
_SEARCHABLE_KINDS = {k for k in Kind} - _EXCLUDED_KINDS


def test_excluded_kinds_are_valid_enums():
    """Every excluded kind must be a valid Kind enum member."""
    all_kinds = {k.value for k in Kind}
    for k in _EXCLUDED_KINDS:
        assert k.value in all_kinds, f"Excluded kind {k!r} is not a valid Kind enum member"


def test_all_kinds_categorized():
    """Every Kind is either excluded or searchable."""
    for k in Kind:
        assert k in _EXCLUDED_KINDS or k in _SEARCHABLE_KINDS, (
            f"Kind.{k.name} is neither excluded nor searchable"
        )


# ── Frontend BADGE_LABELS coverage ───────────────────────────────────────

# Must stay in sync with BADGE_LABELS in searchUtils.tsx
# This is the source-of-truth mapping of concept-only kind values to display labels.
_FRONTEND_BADGE_KINDS = {
    # process kinds
    "model",
    "derivation",
    "connector",
    "job",
    "run",
    # resource kinds
    "table",
    "cube",
    "join",
    "dataset",
    "macro",
    "seed",
    "source",
    "test",
    "unit_test",
    "ephemeral",
    "identity_class",
    "explore",
    "view",
    "materialized_view",
    "base_table",
    "semantic_model",
    "semantic_view",
    "overview",
    "report",
    "report_def",
    "report_ir",
    "dashboard",
    "metric",
    "object",
    "saved_query",
    "ticket",
    "table_profile",
    # attribute kinds
    "column",
    "column_profile",
    "measure",
    "dimension",
    "entity",
    "segment",
    "field",
    "grain_token",
    "fact",
    "time_attribute",
    "subject_area",
    "report_column",
    "ir_bucket",
    "ir_crossfilter",
    "ir_field",
    "ir_filter",
    "ir_formula",
    "ir_groupby",
    "ir_highlight",
    "ir_join",
    # system kinds
    "org",
    "project",
    "service",
    "warehouse",
}


def test_all_searchable_kinds_in_badge_map():
    """Every searchable Kind should have a badge label."""
    for k in _SEARCHABLE_KINDS:
        assert k.value in _FRONTEND_BADGE_KINDS, (
            f"Kind.{k.name} ({k.value!r}) missing from frontend BADGE_LABELS"
        )


# ── Source enum coverage ─────────────────────────────────────────────────


def test_source_enum_has_expected_values():
    """Source enum should cover the main integrations."""
    expected = {"dbt", "cube", "snowflake", "salesforce", "looker", "fivetran", "openlineage", "inferred", "platform"}
    actual = {s.value for s in Source}
    assert expected <= actual, f"Missing Source values: {expected - actual}"


def test_source_family_coverage():
    """Every Source should map to a SourceFamily."""
    from core.backends.unified_graph.surreal.schema import SOURCE_FAMILY_MAP

    for s in Source:
        assert s in SOURCE_FAMILY_MAP, (
            f"Source.{s.name} missing from SOURCE_FAMILY_MAP"
        )


# ── API kind_label_map coverage ──────────────────────────────────────────

# Must stay in sync with kind_label_map in desktop.py /search endpoint
_API_KIND_LABEL_MAP = {
    "model": "model",
    "source": "source",
    "column": "column",
    "test": "test",
    "macro": "macro",
    "seed": "seed",
    "measure": "measure",
    "dimension": "dimension",
    "fact": "fact",
}


def test_api_kind_label_map_has_common_kinds():
    """The API label map should cover the most common searchable kinds."""
    common = {
        "model",
        "source",
        "column",
        "test",
        "macro",
        "measure",
        "dimension",
        "fact",
    }
    for k in common:
        assert k in _API_KIND_LABEL_MAP, (
            f"Common kind {k!r} missing from API kind_label_map"
        )
