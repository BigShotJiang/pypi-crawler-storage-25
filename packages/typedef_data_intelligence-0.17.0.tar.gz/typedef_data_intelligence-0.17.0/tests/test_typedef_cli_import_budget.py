"""Import-budget tests for typedef CLI startup path."""

from __future__ import annotations

import importlib
import sys


def test_typedef_cli_import_stays_lightweight() -> None:
    """Importing CLI module should not eagerly load heavy startup dependencies."""
    module_name = "lineage.typedef_cli"
    heavy_modules = [
        "core.backends.config",
        "core.backends.data_query.factory",
        "core.backends.lineage.factory",
        "ingest.progress",
        "ingest.config",
        "lineage.templates",
        "lineage.utils.env",
        "lineage.tui.app",
    ]

    sys.modules.pop(module_name, None)
    for heavy in heavy_modules:
        sys.modules.pop(heavy, None)

    importlib.import_module(module_name)

    leaked = [heavy for heavy in heavy_modules if heavy in sys.modules]
    assert not leaked, (
        "typedef_cli imported heavyweight modules during module import: "
        f"{', '.join(leaked)}. "
        "Keep imports lightweight: move these imports inside the specific command "
        "function that needs them (lazy import pattern)."
    )
