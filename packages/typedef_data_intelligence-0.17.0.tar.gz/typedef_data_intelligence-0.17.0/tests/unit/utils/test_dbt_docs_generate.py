"""Tests for dbt docs generate error surfacing logic."""

import json
import subprocess
from pathlib import Path
from unittest.mock import patch

from lineage.utils.dbt import (
    _validate_manifest,
    extract_dbt_errors,
    run_dbt_docs_generate,
    strip_ansi,
)

# ── strip_ansi ───────────────────────────────────────────────────────


def test_strip_ansi_removes_escape_codes():
    assert strip_ansi("\x1b[31mError\x1b[0m") == "Error"


def test_strip_ansi_preserves_clean_text():
    assert strip_ansi("plain text") == "plain text"


# ── extract_dbt_errors ───────────────────────────────────────────────

DEPRECATION_HEAVY_OUTPUT = """
\x1b[33mDeprecation Warning in dbt_project_evaluator\x1b[0m
MissingPlusPrefixDeprecation: The model has no + prefix.
PropertyMovedToConfigDeprecation: 'materialized' in properties.
\x1b[33mDeprecation Warning in dbt_project_evaluator\x1b[0m
MissingPlusPrefixDeprecation: The model has no + prefix.
PropertyMovedToConfigDeprecation: 'materialized' in properties.
\x1b[33mDeprecation Warning in dbt_project_evaluator\x1b[0m
MissingPlusPrefixDeprecation: The model has no + prefix.

\x1b[31mCompilation Error in model fct_nps_score (models/marts/product/nps/fct_nps_score.sql)\x1b[0m
  In get_column_values(): relation "ANALYTICS_DEV".int_product.int_user_nps_score_spined
  does not exist and no default value was provided.

Encountered an error:
Compilation Error in model fct_nps_score
""".strip()


def test_extract_dbt_errors_filters_deprecation_warnings():
    result = extract_dbt_errors(DEPRECATION_HEAVY_OUTPUT)
    assert "Compilation Error" in result
    assert "fct_nps_score" in result
    assert "does not exist" in result
    assert "MissingPlusPrefixDeprecation" not in result
    assert "PropertyMovedToConfigDeprecation" not in result


def test_extract_dbt_errors_preserves_clean_errors():
    clean_error = (
        "Compilation Error in model dim_foo (models/dim_foo.sql)\n"
        "  'bar' is undefined"
    )
    result = extract_dbt_errors(clean_error)
    assert "Compilation Error" in result
    assert "'bar' is undefined" in result


def test_extract_dbt_errors_returns_tail_when_all_filtered():
    all_noise = "\n".join(
        [f"MissingPlusPrefixDeprecation: warning {i}" for i in range(20)]
    )
    result = extract_dbt_errors(all_noise)
    assert len(result) > 0


def test_extract_dbt_errors_handles_empty_input():
    assert extract_dbt_errors("") == ""


# ── _validate_manifest ───────────────────────────────────────────────


def test_validate_manifest_valid(tmp_path: Path):
    manifest = tmp_path / "manifest.json"
    manifest.write_text(json.dumps({"nodes": {"model.a": {}}, "metadata": {}}))
    assert _validate_manifest(manifest) is True


def test_validate_manifest_missing(tmp_path: Path):
    assert _validate_manifest(tmp_path / "nope.json") is False


def test_validate_manifest_invalid_json(tmp_path: Path):
    bad = tmp_path / "manifest.json"
    bad.write_text("not json {{{")
    assert _validate_manifest(bad) is False


def test_validate_manifest_missing_nodes_key(tmp_path: Path):
    partial = tmp_path / "manifest.json"
    partial.write_text(json.dumps({"metadata": {}}))
    assert _validate_manifest(partial) is False


def test_validate_manifest_nodes_not_dict(tmp_path: Path):
    bad = tmp_path / "manifest.json"
    bad.write_text(json.dumps({"nodes": []}))
    assert _validate_manifest(bad) is False


# ── run_dbt_docs_generate ────────────────────────────────────────────


def _make_project(tmp_path: Path) -> Path:
    """Create a minimal project structure for testing."""
    project = tmp_path / "project"
    project.mkdir()
    (project / "target").mkdir()
    (project / "logs").mkdir()
    return project


def _write_valid_manifest(project: Path) -> None:
    manifest = project / "target" / "manifest.json"
    manifest.write_text(json.dumps({"nodes": {}, "metadata": {}}))


def _write_catalog(project: Path) -> None:
    catalog = project / "target" / "catalog.json"
    catalog.write_text(json.dumps({"nodes": {}, "sources": {}}))


@patch("lineage.utils.dbt.run_dbt_command")
def test_success_on_clean_run(mock_run, tmp_path: Path):
    project = _make_project(tmp_path)
    _write_valid_manifest(project)
    _write_catalog(project)
    mock_run.return_value = ("ok", "")

    result = run_dbt_docs_generate(project)

    assert result.success is True
    assert result.manifest_valid is True
    assert result.catalog_exists is True
    assert result.error_summary is None
    mock_run.assert_called_once()


@patch("lineage.utils.dbt.run_dbt_command")
def test_failure_when_manifest_missing_despite_zero_exit(mock_run, tmp_path: Path):
    """dbt exits 0 but no manifest was produced — should report failure."""
    project = _make_project(tmp_path)
    mock_run.return_value = ("ok", "")

    result = run_dbt_docs_generate(project)

    assert result.success is False
    assert result.manifest_valid is False
    assert result.error_summary is not None
    mock_run.assert_called_once()


@patch("lineage.utils.dbt.run_dbt_command")
def test_success_when_manifest_exists_despite_error(mock_run, tmp_path: Path):
    """DuckDB Pool.__del__ case: non-zero exit but manifest was generated."""
    project = _make_project(tmp_path)
    _write_valid_manifest(project)
    _write_catalog(project)

    mock_run.side_effect = subprocess.CalledProcessError(
        1, "dbt", stderr="Pool.__del__ error"
    )

    result = run_dbt_docs_generate(project)

    assert result.success is True
    assert result.manifest_valid is True
    mock_run.assert_called_once()


@patch("lineage.utils.dbt.run_dbt_command")
def test_failure_surfaces_filtered_error(mock_run, tmp_path: Path):
    project = _make_project(tmp_path)

    mock_run.side_effect = subprocess.CalledProcessError(
        1, "dbt", stderr="Compilation Error in model fct_nps_score\n  relation does not exist"
    )

    result = run_dbt_docs_generate(project)

    assert result.success is False
    assert result.manifest_valid is False
    assert result.error_summary is not None
    assert "Compilation Error" in result.error_summary
    assert "does not exist" in result.error_summary
    mock_run.assert_called_once()


@patch("lineage.utils.dbt.run_dbt_command")
def test_failure_includes_log_hint(mock_run, tmp_path: Path):
    project = _make_project(tmp_path)
    (project / "logs" / "dbt.log").write_text("detailed log")

    mock_run.side_effect = subprocess.CalledProcessError(
        1, "dbt", stderr="Compilation Error"
    )

    result = run_dbt_docs_generate(project)

    assert result.success is False
    assert result.log_hint is not None
    assert "dbt.log" in result.log_hint


@patch("lineage.utils.dbt.run_dbt_command")
def test_target_args_forwarded(mock_run, tmp_path: Path):
    project = _make_project(tmp_path)
    _write_valid_manifest(project)
    mock_run.return_value = ("ok", "")

    run_dbt_docs_generate(project, target_args=["--target", "duckdb"])

    call_args = mock_run.call_args[0][0]
    assert "--target" in call_args
    assert "duckdb" in call_args
