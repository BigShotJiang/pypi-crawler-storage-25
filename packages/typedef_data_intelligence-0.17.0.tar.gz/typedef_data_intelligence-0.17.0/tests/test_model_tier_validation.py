"""Validate that all prompt YAML files reference defined model aliases.

Every prompt YAML (orchestrator and specialist) has a `model:` field that should
reference an alias name defined in `UnifiedConfig.models` (e.g., 'haiku', 'sonnet',
'opus') OR a fully-qualified 'family:name' string for direct passthrough.

This test catches mismatches early — e.g., a prompt referencing an alias that doesn't
exist in the default config.
"""

from pathlib import Path

import yaml
from core.backends.config import ModelConfig, UnifiedConfig

PROMPTS_DIR = (
    Path(__file__).resolve().parents[3]
    / "libs"
    / "python"
    / "agent"
    / "src"
    / "agent"
    / "prompts"
)

# Source defaults directly from UnifiedConfig to prevent drift.
DEFAULT_ALIASES: dict[str, ModelConfig] = UnifiedConfig.model_fields["models"].default_factory()


def _collect_prompt_files() -> list[Path]:
    """Collect all YAML prompt files (orchestrator + specialist)."""
    files = list(PROMPTS_DIR.glob("*.yaml.j2"))
    files += list(PROMPTS_DIR.glob("*.yaml"))
    files += list((PROMPTS_DIR / "specialists").glob("*.yaml.j2"))
    files += list((PROMPTS_DIR / "specialists").glob("*.yaml"))
    return sorted(set(files))


def test_all_prompt_model_aliases_are_defined():
    """Every prompt's model field must be a defined alias or a 'family:name' passthrough."""
    defined_aliases = set(DEFAULT_ALIASES.keys())
    prompt_files = _collect_prompt_files()

    assert prompt_files, f"No prompt files found in {PROMPTS_DIR}"

    errors: list[str] = []
    for path in prompt_files:
        with open(path) as f:
            data = yaml.safe_load(f) or {}
        model = data.get("model")
        if not model:
            continue  # No model field — will use fallback
        # Fully-qualified 'family:name' strings are always valid (direct passthrough)
        if ":" in model:
            continue
        if model not in defined_aliases:
            errors.append(
                f"{path.relative_to(PROMPTS_DIR)}: model='{model}' "
                f"not in defined aliases {sorted(defined_aliases)}"
            )

    assert not errors, "Prompt files reference undefined model aliases:\n" + "\n".join(errors)


def test_default_aliases_exist():
    """Default aliases must include at least haiku/sonnet/opus/opus-high."""
    expected = {"haiku", "sonnet", "opus", "opus-high"}
    assert expected.issubset(set(DEFAULT_ALIASES.keys())), (
        f"Missing expected default aliases: {expected - set(DEFAULT_ALIASES.keys())}"
    )
