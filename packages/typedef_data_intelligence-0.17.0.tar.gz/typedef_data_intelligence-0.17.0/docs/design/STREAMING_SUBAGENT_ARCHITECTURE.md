# Streaming Subagent Architecture

This document describes the architecture for multi-agent orchestration with streaming AG-UI events and artifact-based context sharing.

## The Core Problem: Information Loss in Multi-Agent Systems

### The "Telephone" Problem

Multi-agent systems suffer from a fundamental information degradation issue analogous to the children's game of "telephone"—each time information passes through an intermediary, fidelity is lost.

**The degradation cascade:**

```text
Explorer finds 15 models with complex relationships
    ↓ (LLM summarizes to fit in response)
Orchestrator receives: "Found several models with dependencies"
    ↓ (LLM paraphrases when delegating)
Planner receives: "There are some models that depend on fct_revenue"
    ↓ (LLM summarizes plan for handoff)
Coder receives: "Update the model and its dependencies"
```

By the final step:

- **Specific model IDs are lost** ("model.project.fct_revenue" → "the revenue model")
- **Exact counts disappear** ("15 downstream consumers" → "several dependencies")
- **Nuanced risks evaporate** ("Breaking change to grain affects 3 dashboards" → "be careful")
- **File paths get corrupted** ("/models/marts/finance/fct_revenue.sql" → "the revenue file")

### Why This Matters

The telephone problem isn't just about lost details—it causes **systematic failures**:

1. **Incomplete implementations**: Coder misses files because explorer's full list wasn't relayed
2. **Wrong assumptions**: Planner makes decisions based on orchestrator's interpretation, not explorer's findings
3. **Repeated work**: Each specialist re-explores because they don't trust the summary they received
4. **Hallucinated context**: LLMs fill in gaps with plausible-sounding but incorrect details

### Categories of Information Loss

| Information Type  | Example                                   | Telephone Effect                  |
| ----------------- | ----------------------------------------- | --------------------------------- |
| **Identifiers**   | `model.project.fct_arr_reporting_monthly` | → "the ARR model"                 |
| **Quantities**    | "15 downstream models, 3 dashboards"      | → "several consumers"             |
| **Relationships** | "JOINS dim_customers ON customer_id"      | → "related to customers"          |
| **File paths**    | `/models/marts/finance/fct_revenue.sql`   | → "the revenue model file"        |
| **Code snippets** | `SUM(arr) OVER (PARTITION BY month)`      | → "aggregates ARR by month"       |
| **Data samples**  | 500 rows of actual query results          | → "the data shows revenue trends" |

## Evolution of Solutions

### Attempt 1: Detailed Prompts (Insufficient)

**Approach**: Tell the orchestrator to "preserve all details" when delegating.

```text
When delegating to planner, include:
- All model IDs found by explorer
- All file paths discovered
- Full dependency chains
```

**Why it failed**:

- LLMs still summarize to fit context windows
- No enforcement mechanism—just instructions
- Orchestrator doesn't know which details matter to planner

### Attempt 2: Structured Output Types (Partial Solution)

**Approach**: Force explorers to return structured JSON with required fields.

```python
class ExplorationResult(BaseModel):
    model_ids: List[str]
    file_paths: List[str]
    dependencies: Dict[str, List[str]]
```

**Why it was insufficient**:

- Orchestrator still receives the JSON as a tool result
- When orchestrator delegates to planner, it still paraphrases
- JSON in → text summary out → text summary in

### Attempt 3: Shared Memory/State (Partial Solution)

**Approach**: Store exploration results in shared state that planner can access.

```python
# Explorer stores
ctx.deps.state.exploration_results["fct_revenue"] = results

# Planner reads
results = ctx.deps.state.exploration_results.get("fct_revenue")
```

**Why it was insufficient**:

- State is ephemeral—doesn't survive across runs
- No explicit "fetch" instruction—planners might not know to look
- No UI visibility into what was stored

### Attempt 4: Artifact-Based Context Sharing (Current Solution)

**Approach**: Persist exploration outputs as named artifacts that downstream specialists explicitly fetch.

```text
Explorer → save_context_brief(title, markdown) → brief_abc123
Planner → list_context_briefs() → get_context_brief("brief_abc123")
```

**Why it works**:

1. **Full fidelity**: Artifact contains complete exploration output
2. **Explicit fetch**: Planner's prompt tells it to check for artifacts first
3. **Persistent**: Survives in threads_backend across the session
4. **Auditable**: UI can show exactly what each specialist consumed
5. **Decoupled**: Orchestrator doesn't need to relay details—just artifact IDs

## Solution: Artifact-Based Context Sharing

Instead of passing context through LLM summarization, subagents persist their outputs as **artifacts** that downstream consumers can fetch directly:

```text
Explorer saves artifact → brief_abc123
    ↓
Orchestrator receives: "Exploration complete. See brief_abc123"
    ↓
Planner calls: get_context_brief("brief_abc123") → Full content
    ↓
Report Builder calls: get_context_brief("brief_abc123") → Same full content
```

**Key insight**: The orchestrator doesn't need to understand or relay the exploration details—it just needs to know an artifact was created and tell the next specialist to fetch it.

## Architecture Overview

```text
┌─────────────────────────────────────────────────────────────────────┐
│                         ORCHESTRATOR                                 │
│  (Sonnet 4) - Owns: plan_toolset, todo_toolset, task() delegation   │
└─────────────────────────────────────────────────────────────────────┘
                                   │
                    task(subagent_type, description)
                                   │
        ┌──────────────────────────┼──────────────────────────┐
        ▼                          ▼                          ▼
┌───────────────┐        ┌─────────────────┐        ┌─────────────────┐
│   EXPLORER    │        │     PLANNER     │        │     CODER       │
│   (Haiku)     │        │     (Haiku)     │        │    (Sonnet)     │
├───────────────┤        ├─────────────────┤        ├─────────────────┤
│ query_graph   │        │ create_plan     │        │ read_file       │
│ get_model_*   │        │ add_plan_*      │        │ write_file      │
│ read_file     │        │ list_briefs   │        │ edit_file       │
│ grep_files    │        │ get_brief     │        │ dbt_compile     │
│ dbt_compile   │        │ finalize_plan   │        │ get_plan        │
└───────────────┘        └─────────────────┘        └─────────────────┘
        │                          │                          │
        ▼                          ▼                          ▼
   Explore Artifact           Plan Artifact            (uses Plan)
   (threads_backend)         (threads_backend)
```

## Core Components

### 1. Streaming Subagent Toolset (`streaming_subagents.py`)

The `create_streaming_subagent_toolset()` function creates a `task()` tool that:

1. **Launches subagents** with isolated tool access
2. **Streams AG-UI events** from subagent execution to the parent stream
3. **Auto-saves artifacts** for explorer-type subagents
4. **Handles cancellation** gracefully

```python
toolset = create_streaming_subagent_toolset(
    subagents=COPILOT_SPECIALISTS,
    default_model="anthropic:claude-sonnet-4-20250514",
)
```

#### Event Multiplexing

Subagent tool calls are forwarded as AG-UI events with namespaced IDs:

```python
# When subagent calls query_graph with tool_call_id="tc_123"
# Parent stream receives:
ToolCallStartEvent(tool_call_id="subact_abc__tc_123", tool_call_name="query_graph")
ToolCallArgsEvent(tool_call_id="subact_abc__tc_123", delta="{...}")
ToolCallEndEvent(tool_call_id="subact_abc__tc_123")
ToolCallResultEvent(tool_call_id="subact_abc__tc_123", content="...")
```

The `subact_{activity_id}__{original_id}` namespacing prevents ID collisions between parent and subagent tool calls.

#### Activity Lifecycle Events

Custom events bracket subagent execution for UI rendering:

```python
CustomEvent(name="subagent_activity_start", value={
    "activity_id": "abc123",
    "subagent_type": "explorer",
    "parent_tool_call_id": "task_xyz",
    "input_prompt": "Investigate the fct_revenue model..."
})

# ... tool call events ...

CustomEvent(name="subagent_activity_end", value={
    "activity_id": "abc123",
    "subagent_type": "explorer",
})
```

#### Auto-Artifact Saving

For explorer and diagnostician subagents, the streaming toolset automatically
saves a context brief after the run completes. Executor and mechanic results are
also auto-persisted as briefs for planner consumption.

Subagents use `output_type=str` and return a markdown string. The toolset
extracts the content, calls `save_context_brief()`, and emits a `context_brief`
event for UI updates:

```python
if subagent_type_enum in {SubagentType.EXPLORER, SubagentType.DIAGNOSTICIAN}:
    # Auto-save context brief from findings_markdown output
    saved = await save_context_brief(
        ctx, source=subagent_type_enum.value, title=title, findings_markdown=output
    )
    _publish_event(CustomEvent(name="context_brief", value={
        "brief_id": saved.brief_id,
        "source": subagent_type_enum.value,
    }))
```

### 2. Specialists (`specialists.py`)

Specialists are `SubAgentConfig` definitions with:

- **name**: Identifier used by `task(subagent_type="explorer")`
- **description**: Shown in orchestrator prompt for delegation decisions
- **instructions**: Loaded from Jinja2 templates with graph schema injection
- **tools**: Hard-enforced list of allowed tools

#### Tool Enforcement

Each specialist has an explicit tool allowlist:

```python
EXPLORER_TOOLS = [
    query_graph, get_graph_schema, get_model_details,
    get_downstream_impact, get_relation_lineage, get_column_lineage,
    search_graph_nodes,
    read_file, glob_files, grep_files,
    preview_table, dbt_compile,
]

PLANNER_TOOLS = [
    get_downstream_impact, read_file, glob_files, grep_files,
    create_plan, get_plan, get_active_plan,
    add_plan_section, update_plan_section,
    add_plan_step, update_plan_step,
    add_plan_question, update_plan_question, answer_plan_question,
    finalize_plan, reopen_plan,
    list_context_briefs, get_context_brief,  # Can fetch explorer artifacts
]

CODER_TOOLS = [
    read_file, write_file, edit_file, glob_files, grep_files,
    get_active_plan, get_plan, dbt_compile,
]
```

This ensures:

- **Explorer** can't edit files (read-only exploration)
- **Planner** can't execute queries (planning only)
- **Executor** can't query the graph (implementation only)
- **Mechanic** can't plan (targeted fixes only)

#### Specialist Groups

Factory functions create specialist sets for different orchestrators:

```python
def get_all_specialists(lineage_backend) -> list[SubAgentConfig]:
    """Explorer, diagnostician, planner, executor, mechanic"""

def get_insights_specialists(lineage_backend) -> list[SubAgentConfig]:
    """Explorer, report_builder"""
```

### 3. Artifacts (`tools/context.py`, `tools/plan.py`)

Artifacts are persisted to the `threads_backend` and can be fetched by any subagent in the same thread.

#### Artifact Types

| Type     | Model           | How persisted                                                                                                    | Purpose                                                        |
| -------- | --------------- | ---------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------- |
| `brief`  | `ContextBrief`  | Streaming layer auto-saves from typed specialist output; readable via `get_context_brief`, `list_context_briefs` | Context findings from explorer/diagnostician/mechanic/executor |
| `plan`   | `PlanPreview`   | Streaming layer auto-saves from planner's `SpecialistPlan` output; readable via `get_plan`, `get_active_plan`    | Implementation plans with sections, steps, questions           |
| `report` | `ReportPreview` | `create_report`, `add_*_cell`                                                                                    | Visual reports with markdown, tables, mermaid diagrams         |

#### Artifact Storage

Artifacts are stored via `ThreadsBackend.add_artifact()`:

```python
artifact = Artifact(
    type="brief",
    id=summary.brief_id,
    run_id=ctx.deps.run_id,
    title=summary.title,
    created_at=summary.created_at,
    data=summary.model_dump(mode="json"),
)
tb.add_artifact(thread_id=thread_id, run_id=run_id, artifact=artifact)
```

#### Cross-Subagent Access

Planner can fetch explorer artifacts:

```python
# Planner instructions include:
list_context_briefs()  # See what explorations exist
get_context_brief(brief_id)  # Fetch full content
```

Report builder can also fetch explorer artifacts:

```python
# Report builder instructions include:
list_context_briefs()  # Check for existing explorations
get_context_brief(brief_id)  # Incorporate findings into report
```

### 4. Hybrid Dependencies (`deep_types.py`)

`CopilotDeps` extends `pydantic-deep`'s `DeepAgentDeps` with our backends:

```python
@dataclass
class CopilotDeps(DeepAgentDeps):
    # pydantic-deep base fields
    backend: FilesystemBackend | StateBackend
    files: dict
    todos: list
    subagents: dict
    uploads: dict

    # Our backend integrations
    lineage: Optional[LineageStorage]
    data_backend: Optional[DataQueryBackend]
    memory_backend: Optional[MemoryStorage]
    ticket_storage: Optional[TicketStorage]
    reports_backend: Optional[ReportsBackend]
    threads_backend: Optional[ThreadsBackend]

    # Session tracking
    thread_id: str
    run_id: str

    # AG-UI state
    state: AgentState

    # UI event injection for subagent streaming
    ui_event_queue: asyncio.Queue[BaseEvent] | None

    # Cancellation coordination
    cancellation_event: asyncio.Event
```

#### Subagent Cloning

When launching a subagent, deps are cloned with `clone_for_subagent()`:

```python
def clone_for_subagent(self) -> CopilotDeps:
    return CopilotDeps(
        # SHARED: backends, state, configs, ui_event_queue, cancellation_event
        lineage=self.lineage,
        data_backend=self.data_backend,
        state=self.state,  # Same AgentState instance
        ui_event_queue=self.ui_event_queue,  # Same queue for event injection
        cancellation_event=self.cancellation_event,  # Same event for coordinated cancel

        # ISOLATED: fresh todo list, no nested subagents
        todos=[],
        subagents={},
    )
```

### 5. UI Event Injection

The `ui_event_queue` enables real-time streaming of subagent events:

```python
# In streaming_subagents.py
def _publish_event(event: BaseEvent) -> None:
    collected_events.append(event)
    if ui_event_queue is not None:
        ui_event_queue.put_nowait(event)  # Injected into parent SSE stream
```

The AG-UI handler (`ag_ui_handler.py`) consumes this queue alongside the main agent stream, interleaving subagent events in real-time.

## Orchestrator Configuration

### Deep Orchestrators

Deep orchestrators use `pydantic-deep`'s `create_deep_agent()` with our streaming toolset:

```python
def create_data_engineer_copilot_deep_orchestrator(...):
    subagents = get_all_specialists(lineage)

    streaming_subagent_toolset = create_streaming_subagent_toolset(
        subagents=subagents,
        default_model=model,
    )

    agent = create_deep_agent(
        model=model,
        instructions=system_prompt,
        include_subagents=False,  # Use our streaming toolset instead
        subagents=subagents,  # Still passed for prompt generation
        toolsets=[
            streaming_subagent_toolset,  # Our streaming task() tool
            plan_toolset,  # Orchestrator owns plan creation
            todo_list_manager_toolset,
        ],
    )
```

### Orchestrator-Owned Tools

The orchestrator retains tools for:

1. **Plan management**: `plan_toolset` - creates/modifies plans that specialists reference
2. **Task tracking**: `todo_list_manager_toolset` - converts approved plans to todos
3. **Delegation**: `streaming_subagent_toolset` - the `task()` tool

Specialists do NOT have plan creation tools—they can only read plans via `get_plan()` or `get_active_plan()`.

## Workflow Example: Copilot Adding a Column

```text
User: "Add a region column to fct_revenue"

Orchestrator:
  1. task(subagent_type="explorer", description="Find fct_revenue, trace dependencies...")

Explorer:
  - query_graph("MATCH (m:DbtModel {name: 'fct_revenue'})...")
  - get_downstream_impact("model.project.fct_revenue")
  - read_file("/models/marts/fct_revenue.sql")
  → Returns: {title: "fct_revenue analysis", summary_markdown: "..."}
  → Auto-saved as brief_abc123

Orchestrator:
  2. task(subagent_type="planner", description="Create implementation plan")

Planner:
  - list_context_briefs() → ["brief_abc123"]
  - get_context_brief("brief_abc123") → Full exploration content
  - create_plan(title="Add region to fct_revenue", goal="...")
  - add_plan_section(plan_id, title="Impact Analysis", content="...")
  - add_plan_step(plan_id, content="Add region column to fct_revenue.sql")
  - finalize_plan(plan_id)
  → Returns: "Plan plan_xyz created and finalized"

Orchestrator:
  3. [Presents plan to user for approval]
  4. task(subagent_type="coder", description="Implement the plan")

Coder:
  - get_active_plan() → Full plan with steps
  - read_file("/models/marts/fct_revenue.sql")
  - edit_file(...add region column...)
  - dbt_compile(select="fct_revenue")
  → Returns: "Implementation complete, compiles successfully"

Orchestrator:
  5. task(subagent_type="tester", description="Validate the changes")

Tester:
  - get_active_plan()
  - dbt_test(select="fct_revenue")
  - dbt_build(select="fct_revenue+")
  → Returns: "All tests pass"
```

## Query Results: Solved with Blob Storage

### The Problem (Now Solved)

Query result data previously suffered from the telephone problem:

```text
Data Explorer runs: SELECT region, SUM(arr) FROM fct_revenue GROUP BY region
    ↓ (returns 50 rows to orchestrator)
Orchestrator summarizes: "Query returned regional ARR data"
    ↓ (delegates to report builder)
Report Builder receives: "Create a chart of regional ARR"
    ↓ (has to re-run the query or guess)
```

**Why this was worse than exploration context**:

- Query results are **precise data**—any summarization corrupts them
- Column names, types, and ordering matter for visualization
- Null handling and edge cases get lost in text descriptions
- Re-running queries is expensive (warehouse costs)

### Solution: Blob Storage (Implemented)

We implemented a unified `BlobStorage` protocol for persisting large/ephemeral data that can be referenced by ID across subagent boundaries.

#### Core Protocol

```python
# backends/blobs/protocol.py
class Blob(BaseModel):
    blob_id: str
    blob_type: Literal["query_result", "table_preview", "explore"]
    thread_id: str
    run_id: str
    created_at: datetime
    expires_at: datetime
    size_bytes: int = 0
    metadata: Dict[str, Any] = {}
    data: Dict[str, Any] = {}

class BlobRef(BaseModel):
    """Lightweight reference returned by store()."""
    blob_id: str
    blob_type: str
    summary: Optional[str] = None  # "150 rows, 5 columns"
    created_at: datetime
    row_count: Optional[int] = None
    columns: Optional[List[str]] = None

class BlobStorage(Protocol):
    def store(thread_id, run_id, blob_type, data, metadata=None, ttl_days=30) -> BlobRef
    def get(blob_id) -> Optional[Blob]
    def preview(blob_id, sample_rows=5) -> Optional[Blob]  # Truncated rows for inspection
    def list_by_thread(thread_id, blob_type=None, limit=50) -> List[BlobRef]
    def delete(blob_id) -> bool
    def cleanup_expired() -> int
```

#### How It Works

**Producer side** (`execute_query`, `query_semantic_view`):

```python
# tools/data.py
async def execute_query(
    ctx: RunContext[AgentDeps],
    sql: str,
    query_name: str = "SQL Query",
    persist: bool = True,  # Auto-persist to blob storage
) -> QueryResult | ToolError:
    result = await ctx.deps.data_backend.execute_query(query=sql, limit=limit)

    if persist and ctx.deps.blob_storage:
        blob_ref = ctx.deps.blob_storage.store(
            thread_id=ctx.deps.thread_id,
            run_id=ctx.deps.run_id,
            blob_type="query_result",
            data={"columns": result.columns, "rows": result.rows, "row_count": result.row_count},
            metadata={"sql": sql, "query_name": query_name},
        )
        result.result_set_id = blob_ref.blob_id  # Attached to QueryResult

    return result
```

**Consumer side** (`add_table_cell`, `add_chart_cell`):

```python
# tools/presentation.py
async def add_table_cell(
    ctx: RunContext[AgentDeps],
    report_id: str,
    data: Optional[QueryResult] = None,       # Direct data (legacy)
    result_set_id: Optional[str] = None,      # OR blob reference (preferred)
    title: Optional[str] = None,
) -> TableCellResult | ToolError:
    # Resolve from blob if result_set_id provided
    if data is None and result_set_id:
        blob = ctx.deps.blob_storage.get(result_set_id)
        if not blob:
            return tool_error(f"Result set not found: {result_set_id}")
        data = QueryResult(
            columns=blob.data["columns"],
            rows=[tuple(row) for row in blob.data["rows"]],
            row_count=blob.data["row_count"],
        )
    # ... rest of implementation
```

**Preview tool** for inspecting blobs before use:

```python
# tools/data.py
async def preview_blob(
    ctx: RunContext[AgentDeps],
    blob_id: str,
    sample_rows: int = 5,
) -> BlobPreviewResult | ToolError:
    """Preview stored query result - check columns, sample data, total rows."""
    blob = ctx.deps.blob_storage.preview(blob_id, sample_rows)
    return BlobPreviewResult(
        blob_id=blob_id,
        columns=blob.data.get("columns", []),
        sample_rows=blob.data.get("rows", []),
        total_rows=blob.data.get("total_rows", 0),
    )
```

#### Workflow with Blob Storage

```text
Data Explorer:
  - execute_query("SELECT region, SUM(arr)...")
    → QueryResult with result_set_id="blob_abc123"
  - save_context_brief(title="Revenue Analysis", markdown="Found 5 regions...")
  → Returns: "Query returned 50 rows (result_set_id: blob_abc123)"

Orchestrator:
  → Delegates to report builder: "Create chart using result_set_id=blob_abc123"

Report Builder:
  - preview_blob("blob_abc123") → See columns, sample rows, total count
  - add_table_cell(report_id="...", result_set_id="blob_abc123")
  - add_chart_cell(report_id="...", result_set_id="blob_abc123", chart_type="bar", x="region", y="arr")
  → Chart uses exact data, no re-query needed
```

#### Key Design Decisions

| Decision            | Value   | Rationale                                              |
| ------------------- | ------- | ------------------------------------------------------ |
| `persist` default   | `True`  | Most queries should be accessible to downstream agents |
| TTL default         | 30 days | Balance storage vs availability                        |
| Backward compatible | Yes     | Both raw `data` and `result_set_id` accepted           |
| Storage backend     | SQLite  | Simple, embedded, no external dependencies             |

#### Files

| File                           | Purpose                               |
| ------------------------------ | ------------------------------------- |
| `backends/blobs/protocol.py`   | Blob, BlobRef, BlobStorage protocol   |
| `backends/blobs/sqlite.py`     | SQLiteBlobStorage implementation      |
| `backends/blobs/factory.py`    | `create_blob_storage()` factory       |
| `backends/config.py`           | `BlobConfig`, `SQLiteBlobConfig`      |
| `agent/pydantic/types.py`      | `blob_storage` field in `AgentDeps`   |
| `agent/pydantic/deep_types.py` | `blob_storage` field in `CopilotDeps` |

### Remaining Potential Telephone Problems

| Context Type         | Current State                 | Potential Solution                      |
| -------------------- | ----------------------------- | --------------------------------------- |
| Exploration findings | ✅ Solved (explore artifacts) | —                                       |
| Implementation plans | ✅ Solved (plan artifacts)    | —                                       |
| Query results        | ✅ Solved (blob storage)      | —                                       |
| Git diffs            | ⚠️ Text summary only          | Diff artifacts with structured hunks    |
| Test failures        | ⚠️ Text summary only          | Test result artifacts with stack traces |
| Compilation errors   | ⚠️ Text summary only          | Error artifacts with file/line info     |

## Implementation Design Rationale

### Why Streaming vs Batch Events?

**Streaming (current approach)**:

- Events appear in UI as subagent works
- Better UX—user sees progress
- Enables cancellation mid-execution

**Batch (alternative)**:

- Collect all events, return in `ToolReturn.metadata`
- Simpler implementation
- No real-time feedback

We chose streaming via `ui_event_queue` for better UX.

### Why Auto-Save Artifacts for Explorers?

Explorers are instructed to return `{title, summary_markdown}` JSON, but:

1. LLMs sometimes return malformed JSON
2. The orchestrator might parse it incorrectly
3. We want guaranteed artifact persistence

Auto-saving in the streaming toolset ensures artifacts are always created, regardless of LLM output format issues.

### Why Orchestrator Owns Plan Tools?

If specialists could create plans:

- Multiple specialists might create conflicting plans
- No single source of truth
- User approval flow becomes ambiguous

Having the orchestrator own plan creation provides:

- Single point of plan management
- Clear approval workflow
- Consistent plan-to-execution handoff

### Why No Nested Subagent Calls?

Intuitively, it seems useful for subagents to call other subagents:

```text
Explorer finds a complex model
    → "I should delegate to graph_explorer for deeper analysis"
        → graph_explorer finds related models
            → "I should delegate to data_explorer to sample these"
                → ...
```

**We explicitly prevent this.** Here's why:

#### 1. Infinite Recursion Risk

Without strict boundaries, subagents can enter infinite loops:

```text
explorer → "need more context" → planner
planner → "need to verify assumptions" → explorer
explorer → "need more context" → planner
... (forever)
```

Even without true infinite loops, deep nesting creates unbounded execution times and token costs.

#### 2. Lost Coordination

The orchestrator exists to **coordinate**. If subagents can call each other:

- Who decides when exploration is "enough"?
- Who ensures the plan matches the exploration?
- Who controls the overall workflow?

Nested calls create **shadow coordination** that the orchestrator can't see or control.

#### 3. Context Explosion

Each nesting level adds context:

```text
Orchestrator context: 4K tokens
  └─ Explorer context: +2K tokens (6K total)
       └─ Graph Explorer context: +2K tokens (8K total)
            └─ Data Explorer context: +2K tokens (10K total)
```

With artifacts, we flatten this:

- Orchestrator: 4K tokens
- Explorer: 2K tokens (isolated)
- Graph Explorer: 2K tokens (isolated, fetches artifacts)

#### 4. Debugging Nightmare

With nested calls:

```text
Task failed somewhere in:
orchestrator → explorer → graph_explorer → data_explorer → ???
```

With flat structure:

```text
orchestrator → explorer ✓
orchestrator → graph_explorer ✗ (error here)
```

#### 5. Cancellation Complexity

Nested subagents require propagating cancellation through multiple levels. With flat structure:

- Orchestrator sets `cancellation_event`
- All subagents check the same event
- Clean, coordinated shutdown

#### The Flat Alternative

Instead of nesting, subagents **produce artifacts** and **return to orchestrator**:

```text
Orchestrator → Explorer
Explorer: "Found complex model, saved as brief_abc123.
           Recommend deeper graph analysis."
Explorer → Orchestrator

Orchestrator → Graph Explorer (with: "see brief_abc123")
Graph Explorer: fetches brief_abc123, does deeper analysis
Graph Explorer → Orchestrator
```

The orchestrator makes the decision to spawn graph_explorer, not the explorer. This keeps:

- **Single point of control** (orchestrator)
- **Flat execution** (one level deep)
- **Clear artifact chain** (orchestrator knows what was produced)

#### Implementation

In `clone_for_subagent()`, we explicitly clear the subagents dict:

```python
def clone_for_subagent(self) -> CopilotDeps:
    return CopilotDeps(
        # ... shared backends ...
        subagents={},  # No nested subagents allowed
        todos=[],      # Fresh todo list
    )
```

And in `create_streaming_subagent_toolset()`, we don't include the `task()` tool in subagent toolsets—only the orchestrator has it.

## Why Artifact-Based Context Sharing Makes Multi-Agent Viable

Multi-agent architectures promise benefits—specialized models, tool isolation, predictable workflows—but the telephone problem made them impractical. Information loss compounded at each handoff, making complex workflows unreliable.

**Artifact-based context sharing is the key innovation that makes this viable**:

### 1. Breaks the Summarization Chain

Instead of:

```text
Explorer → (summarize) → Orchestrator → (paraphrase) → Planner
```

We have:

```text
Explorer → Artifact
                ↓ (direct fetch)
           Planner
```

The orchestrator becomes a **coordinator**, not a **relay**. It knows _which_ artifact to reference, but doesn't need to understand or transmit its contents.

### 2. Preserves Full Fidelity

Artifacts store complete outputs:

- **All 15 model IDs**, not "several models"
- **Exact file paths**, not "the relevant files"
- **Complete dependency graphs**, not "some dependencies"

Downstream specialists get the same quality of information as if they'd done the exploration themselves.

### 3. Enables Audit and Debug

When something goes wrong:

- View `brief_abc123` to see exactly what explorer found
- View `plan_xyz789` to see the exact plan coder was following
- No ambiguity about "what did the orchestrator tell the planner?"

### 4. Reduces Token Costs

Without artifacts:

- Explorer outputs 2000 tokens of findings
- Orchestrator context includes those 2000 tokens
- Delegation prompt to planner includes summarized version (~500 tokens)
- Planner context includes that summary
- **Total: ~4500 tokens of exploration content**

With artifacts:

- Explorer outputs 2000 tokens → saved as artifact
- Orchestrator receives: "Saved as brief_abc123" (~20 tokens)
- Delegation to planner: "Use brief_abc123" (~30 tokens)
- Planner fetches artifact: 2000 tokens (only when needed)
- **Total: ~2050 tokens, loaded only by consumer**

### 5. Enables Reuse Across Specialists

Single exploration, multiple consumers:

```text
Explorer → brief_abc123
               ↓
    ┌──────────┼──────────┐
    ↓          ↓          ↓
 Planner   Report     Coder
           Builder
```

Each specialist fetches the same artifact, ensuring consistency.

### The Pattern is Extensible

Once the artifact pattern is established:

- **Exploration** → explore artifacts ✅
- **Planning** → plan artifacts ✅
- **Reports** → report artifacts ✅
- **Query results** → blob storage ✅
- **Git operations** → diff artifacts (future)
- **Test runs** → test result artifacts (future)

Any information that needs to survive the telephone game can be artifacted.

## Files Reference

| File                         | Purpose                                             |
| ---------------------------- | --------------------------------------------------- |
| `streaming_subagents.py`     | Streaming `task()` tool with AG-UI event forwarding |
| `specialists.py`             | Specialist definitions with tool allowlists         |
| `deep_types.py`              | `CopilotDeps` hybrid dependency class               |
| `orchestrator.py`            | Orchestrator factory functions                      |
| `tools/context.py`           | Context brief artifact tools                        |
| `tools/plan.py`              | Plan artifact tools                                 |
| `tools/data.py`              | Query tools with blob persistence                   |
| `backends/blobs/protocol.py` | Blob, BlobRef, BlobStorage protocol                 |
| `backends/blobs/sqlite.py`   | SQLiteBlobStorage implementation                    |
| `tools/presentation.py`      | Report artifact tools                               |
| `ag_ui_handler.py`           | AG-UI SSE handler with event queue consumption      |
