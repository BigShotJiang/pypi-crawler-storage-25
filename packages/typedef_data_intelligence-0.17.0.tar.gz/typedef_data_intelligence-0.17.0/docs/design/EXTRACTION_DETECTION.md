# EXTRACTION Detection: Syntax-Based + CTE Scope Traversal

## Status

**Implemented** (syntax detection + CTE scope refinement).
**Open issue**: CTE scope edges not fully persisted by builder (see Gap section).

## Overview

EXTRACTION identifies column lineage edges where a downstream column is derived
from a semi-structured (JSON/VARIANT) source column via field extraction, not
identity-preserving passthrough. Correctly classifying these edges prevents
over-merging of identity classes in the key lineage pipeline.

## Architecture

Three detection layers, from most specific to broadest:

```text
Layer 1: Syntax detection (scope engine)
  - Detects JSONExtract, Bracket, GET/GET_PATH in classify_expression()
  - Produces EXTRACTION classification in the TransformationGraph
  - Works for root-scope extraction (e.g., JIRA model: 52 edges)

Layer 2: CTE scope refinement (Pass 1, third pass)
  - Queries CteScope DERIVES_FROM edges from the graph
  - DFS traces through CTE chains to find breaking transformations
  - Demotes preserving DbtColumn edges when CTE chain reveals extraction
  - Requires CTE scope edges to be persisted (see Gap)

Layer 3: Fan-out guard (Pass 1, safety net)
  - If upstream column fans out to >= 3 differently-named downstream
    columns via passthrough/source, treats those edges as breaking
  - Catches cases where layers 1-2 missed (legacy edges, incomplete CTE data)
  - Example: payload (fanout=42), cs_uri_query (fanout=16)
```

## Detection Targets

The `_is_semi_structured_access()` helper in `transformation_lineage.py`
detects these sqlglot expression types:

| Pattern                | sqlglot type                   | Example                   |
| ---------------------- | ------------------------------ | ------------------------- |
| Snowflake colon syntax | `exp.JSONExtract`              | `data:key`                |
| Snowflake colon + cast | `exp.Cast(exp.JSONExtract)`    | `data:key::varchar`       |
| Bracket notation       | `exp.Bracket(exp.Column)`      | `data['key']`             |
| GET / GET_PATH         | `exp.Anonymous`                | `GET_PATH(data, 'key')`   |
| Nested in functions    | any of above inside `exp.Func` | `COALESCE(data:key, 'x')` |

The `classify_computed_expr()` in `classifier.py` also detects CAST-wrapped
semi-structured access and returns `"breaking"` instead of `"preserving"`.

## Files

| File                                                        | Role                                                                                                      |
| ----------------------------------------------------------- | --------------------------------------------------------------------------------------------------------- |
| `ingest/static_loaders/sqlglot/transformation_lineage.py`   | `_is_semi_structured_access()`, EXTRACTION in `classify_expression()`                                     |
| `ingest/static_loaders/key_lineage/classifier.py`           | CAST-wrapping fix in `classify_computed_expr()`                                                           |
| `ingest/static_loaders/key_lineage/pass1_classify_edges.py` | CTE scope refinement: `_load_cte_scope_edges()`, `_cte_chain_has_breaking()`, `_refine_with_cte_scopes()` |
| `ingest/static_loaders/dbt/builder.py`                      | CTE scope edge creation (lines ~600-663); fan-out heuristic removed                                       |

## Evaluation (sf_analytics graph)

After re-sync with syntax detection enabled:

| Metric                                               | Count                                              |
| ---------------------------------------------------- | -------------------------------------------------- |
| Total DERIVES_FROM edges                             | ~22,400                                            |
| DbtColumn extraction edges                           | 52 (all from JIRA `fields` column)                 |
| CteScope extraction edges                            | 11 (user-agent parsing, IP parsing, JSON metadata) |
| PhysicalColumn->DbtColumn (NULL transformation)      | 7,304 (benign bridge edges)                        |
| High-fanout passthrough still misclassified in graph | `payload` (42), `cs_uri_query` (16), others        |

The fan-out guard catches the high-fanout cases at key-lineage analysis time
(in-memory classification), but the graph still stores them as `passthrough`.

## Resolved: CTE Scope Edge Persistence (merge_keys fix)

### Problem (was)

For models using the standard dbt staging pattern:

```sql
WITH source AS (SELECT * FROM raw_table),
renamed AS (
    SELECT payload:key::varchar AS col_name, ... FROM source
)
SELECT * FROM renamed
```

The scope engine correctly produces EXTRACTION for the `payload:*` columns in
the RENAMED scope. But only **1 of ~46 expected CTE scope edges** from the
RENAMED scope was persisted to the graph (the `TO_TIMESTAMP` computed edge).

### Root Cause (confirmed)

`create_edge` in `_base_falkordb_adapter.py` used `MERGE (a)-[r:DERIVES_FROM]->(b)`
without property predicates. FalkorDB's MERGE matches any existing edge of that
type between the same node pair and overwrites its properties. When the builder
created multiple DERIVES_FROM edges between the same CteScope pair (e.g.,
RENAMED→SOURCE for `customer_email`, `company_name`, `expire_at` all pointing
to upstream `PAYLOAD`), only the last edge's properties survived.

### Fix

Added `merge_keys` class variable to `GraphEdge` (base class):

- `GraphEdge.merge_keys = ()` — default, no merge key properties
- `DerivesFrom.merge_keys = ("column_name",)` — column_name differentiates parallel edges
- `StructurallyUses.merge_keys = ("column_name",)` — same pattern

In `create_edge`, merge key values are included in the MERGE pattern:

```cypher
-- Before (deduplicates parallel edges):
MERGE (a)-[r:DERIVES_FROM]->(b)

-- After (preserves edges with different column_name):
MERGE (a)-[r:DERIVES_FROM {column_name: $mk_column_name}]->(b)
```

When `column_name` is NULL, the fix falls back to the original simple MERGE.

### Files Changed

| File                                         | Change                                                                      |
| -------------------------------------------- | --------------------------------------------------------------------------- |
| `backends/lineage/models/base.py`            | Add `merge_keys: ClassVar[tuple[str, ...]] = ()` to `GraphEdge`             |
| `backends/lineage/models/edges.py`           | Set `merge_keys = ("column_name",)` on `DerivesFrom` and `StructurallyUses` |
| `backends/lineage/_base_falkordb_adapter.py` | Include merge key properties in MERGE pattern                               |

## Test Coverage

| Test file                                                              | Tests                                      |
| ---------------------------------------------------------------------- | ------------------------------------------ |
| `tests/ingest/static_loaders/sqlglot/test_transformation_lineage.py`   | `TestExtractionClassification` (5 tests)   |
| `tests/ingest/static_loaders/key_lineage/test_classifier.py`           | `TestCastWrappingSemiStructured` (2 tests) |
| `tests/ingest/static_loaders/key_lineage/test_pass1_classify_edges.py` | `TestCteScopeRefinement` (3 tests)         |
| `tests/ingest/static_loaders/dbt/test_extraction_fanout.py`            | `TestExtractionViaScopeEngine` (3 tests)   |
| `tests/backends/lineage/test_parallel_edges.py`                        | `TestParallelEdgePersistence` (3 tests)    |
