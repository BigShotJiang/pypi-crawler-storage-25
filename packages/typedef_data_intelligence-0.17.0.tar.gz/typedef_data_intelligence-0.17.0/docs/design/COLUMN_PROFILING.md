# Column Profiling for PK/FK Inference

## Status

**Tier 1 implemented** (`d6b4cea0`). See `COLUMN_PROFILING_IMPLEMENTATION.md` for
implementation notes. Tier 2 (composite keys) and Tier 3 (cross-table overlap)
are deferred.

## Problem

Only 52 of 3,118 IdentityClasses have a PK member. The PK scoring pipeline
(Pass 3 → Pass 4) requires at least two signals to cross the 0.5 threshold, and
the only gold-tier signals come from dbt `unique`/`not_null` tests — which are
sparse in many projects. The profiling path (`collect_profiling_signals` in
`pass3_pk_signals.py`) exists in code but produces zero signals because no
`ColumnProfile` or `TableProfile` nodes exist in the graph.

Profiling also unblocks grain inference: the current grain pipeline
(`pass_10a_grain.py`) treats all SELECT columns as grain for non-aggregated
queries. Knowing which columns are unique (and therefore key-like) breaks this
circular dependency.

## Data Sources

### Free: Snowflake Metadata (no query cost)

Snowflake does not expose column-level statistics (distinct count, null rate,
min/max) through metadata views — unlike PostgreSQL's `pg_stats`. The optimizer
statistics are internal and not queryable. But these are free:

| Source                       | Fields                          | Use                                                               |
| ---------------------------- | ------------------------------- | ----------------------------------------------------------------- |
| `INFORMATION_SCHEMA.TABLES`  | `ROW_COUNT`, `BYTES`            | Row count for ratio denominators                                  |
| `INFORMATION_SCHEMA.COLUMNS` | `DATA_TYPE`, `IS_NULLABLE`      | Declared nullability (weak not-null signal), type-based filtering |
| `TABLE_STORAGE_METRICS`      | active bytes, time-travel bytes | Table size for cost estimation                                    |

`IS_NULLABLE = 'NO'` in the DDL means the column was designed as non-null.
This is not the same as actual null rate (data could violate DDL intent in
some pipelines), but it's a free filter: columns declared `NOT NULL` at the
DDL level can skip the null-rate query.

Row count from `INFORMATION_SCHEMA.TABLES` eliminates the need for
`COUNT(*)` in profiling queries.

### Cheap: Snowflake Columnar Scans

Snowflake's columnar architecture makes profiling cheaper than row-oriented
databases:

- **Null counts**: derived from null bitmaps per micropartition — `COUNT_IF(K IS NULL)` scans bitmaps, not data
- **`APPROX_COUNT_DISTINCT`**: HyperLogLog on columnar storage — sublinear cost
- **`MIN`/`MAX`**: benefits from micropartition pruning metadata (Snowflake tracks min/max per partition for query planning)

A single `SELECT` with these aggregates per column touches metadata and bitmaps,
not full row scans. Cost scales with column count and table size, but is
typically 1-2 orders of magnitude cheaper than equivalent row-oriented queries.

## Metrics

### Tier 1: Single-Column (one pass per table)

These run as a single query per table, sampling or scanning all columns:

| Metric                    | SQL Pattern                                         | Signal                                                    | Weight          |
| ------------------------- | --------------------------------------------------- | --------------------------------------------------------- | --------------- |
| **Uniqueness ratio**      | `APPROX_COUNT_DISTINCT(K) / COUNT(*)`               | `profiling_unique` when ≥ 0.99                            | 0.35 (existing) |
| **Null rate**             | `COUNT_IF(K IS NULL) / COUNT(*)`                    | `profiling_not_null` when = 0                             | 0.35 (existing) |
| **Value pattern**         | `REGEXP_COUNT(K, '^[0-9a-f]{8}-...')` on sample     | `pattern_uuid`, `pattern_sequential`, `pattern_composite` | new             |
| **Monotonicity**          | `MAX(K) - MIN(K)` vs `COUNT(*)` for numeric columns | `profiling_monotonic` when ratio ≈ 1.0                    | new             |
| **Value length variance** | `STDDEV(LENGTH(K::VARCHAR))`                        | filter: high variance → unlikely PK                       | n/a (filter)    |

**Value pattern classification** detects these patterns on a sample of ~1000 rows:

| Pattern            | Detection                                                        | Interpretation   |
| ------------------ | ---------------------------------------------------------------- | ---------------- |
| UUID               | `^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$` | Strong PK signal |
| Sequential integer | `MAX - MIN ≈ COUNT - 1` and all distinct                         | Surrogate key    |
| Composite key      | `[A-Z]+[_-][0-9]+` patterns (e.g., `ORG_001`)                    | Natural key      |
| Low cardinality    | `APPROX_COUNT_DISTINCT < 100`                                    | Not a PK         |
| Boolean-like       | distinct values ∈ {0,1,true,false,yes,no}                        | Not a PK         |

### Tier 2: Column-Pair (targeted)

These are more expensive. Candidate pairs are seeded from existing graph signals
(JOIN keys, naming heuristics) to avoid brute-forcing all `O(n²)` combinations.

| Metric                    | SQL Pattern                                  | Signal                               |
| ------------------------- | -------------------------------------------- | ------------------------------------ |
| **Composite uniqueness**  | `APPROX_COUNT_DISTINCT((A, B)) / COUNT(*)`   | `composite_pk_candidate` when ≥ 0.99 |
| **Functional dependency** | `COUNT(DISTINCT (A, B)) = COUNT(DISTINCT A)` | A → B (A is more key-like than B)    |

**Candidate pair selection** (avoids brute force):

1. Columns that appear as `join_key` in STRUCTURALLY_USES edges (679 edges in
   sf_analytics)
2. Columns ending in `_id` within the same model
3. Columns that individually have uniqueness ratio between 0.8 and 0.99
   (near-unique but not quite — likely part of a composite key)

### Tier 3: Cross-Table (targeted)

| Metric            | SQL Pattern                                                                                  | Signal                          |
| ----------------- | -------------------------------------------------------------------------------------------- | ------------------------------- |
| **Value overlap** | `COUNT(DISTINCT A) FILTER (WHERE A IN (SELECT DISTINCT B FROM other))` / `COUNT(DISTINCT A)` | FK evidence when overlap ≥ 0.95 |

**Candidate pair selection**: columns sharing the same name across tables that
belong to the same `InferredSubjectArea` (join cluster).

## Graph Schema

The existing schema already defines `TableProfile` and `ColumnProfile` nodes
with the right structure for Tier 1 metrics. Additional properties needed:

### ColumnProfile (extend existing)

New properties to add to `schema.yaml`:

```yaml
ColumnProfile:
  properties:
    # ... existing ...
    uniqueness_ratio: { type: float } # APPROX_COUNT_DISTINCT / row_count
    null_rate: { type: float } # null_count / row_count
    value_pattern: { type: str } # uuid | sequential | composite | low_cardinality | boolean_like | mixed
    is_monotonic: { type: bool } # MAX - MIN ≈ COUNT - 1 for numeric
    length_stddev: { type: float } # STDDEV(LENGTH(K::VARCHAR))
    sample_size: { type: int } # rows sampled for pattern detection
```

### New: CompositeKeyCandidate (optional)

If composite key detection is worth persisting:

```yaml
CompositeKeyCandidate:
  domain: profiling
  description: "Candidate composite key pair with joint uniqueness"
  properties:
    id: { type: str, primary_key: true } # {table_profile_id}::{col_a}::{col_b}
    table_profile_id: { type: str }
    column_a: { type: str }
    column_b: { type: str }
    joint_uniqueness_ratio: { type: float }
    functional_dependency: { type: str } # "a_determines_b" | "b_determines_a" | "none" | "mutual"
```

## Signal Integration

### New signals for Pass 3

```python
# pass3_pk_signals.py — extend collect_profiling_signals()

SIGNAL_MAP = {
    "profiling_unique":    uniqueness_ratio >= 0.99,
    "profiling_not_null":  null_rate == 0,
    "profiling_monotonic": is_monotonic == True,
    "pattern_uuid":        value_pattern == "uuid",
    "pattern_sequential":  value_pattern == "sequential",
}
```

### New weights for Pass 4

```python
# pass4_pk_scoring.py — extend SIGNAL_WEIGHTS

SIGNAL_WEIGHTS = {
    # Gold: dbt tests
    "dbt_unique_test":     0.45,
    "dbt_not_null_test":   0.45,
    # Silver: profiling
    "profiling_unique":    0.35,
    "profiling_not_null":  0.35,
    "profiling_monotonic": 0.15,
    "pattern_uuid":        0.20,
    "pattern_sequential":  0.15,
    # Bronze: structural
    "grain_member":        0.25,
    # Heuristic
    "naming_heuristic":    0.15,
}
```

With profiling enabled, a column with `uniqueness_ratio >= 0.99` AND
`null_rate == 0` scores `0.35 + 0.35 = 0.70` — crosses the 0.5 threshold
without any dbt tests. Adding UUID pattern detection pushes it to 0.90.

### Stability signal

Stability across partitions is a quality gate, not a scoring signal. A column
that appears unique today but not tomorrow has an unreliable uniqueness ratio.

Implementation: profile the same table at two different points in time (or
across two partition windows if the table is time-partitioned). Compare
uniqueness ratios. If `|ratio_t1 - ratio_t2| > 0.05`, flag the column as
unstable and suppress the `profiling_unique` signal.

This is a second-pass refinement — run after Tier 1 metrics are collected,
before feeding into Pass 3.

## Execution Strategy

### Phase 0: Metadata Collection (free)

No warehouse queries. Reads from `INFORMATION_SCHEMA`:

```sql
-- Row counts for all tables in scope (single query)
SELECT table_schema, table_name, row_count, bytes
FROM information_schema.tables
WHERE table_schema IN ({schemas})
  AND table_type IN ('BASE TABLE', 'VIEW')

-- Column metadata (single query)
SELECT table_schema, table_name, column_name, data_type,
       is_nullable, ordinal_position
FROM information_schema.columns
WHERE table_schema IN ({schemas})
```

This gives us:

- `row_count` for ratio denominators (no `COUNT(*)` needed)
- `IS_NULLABLE = 'NO'` as a free not-null signal (DDL-declared)
- `data_type` for type-based filtering (skip monotonicity on VARCHAR, etc.)

### Phase 1: Column Profiling (one query per table)

Single query per table collects all Tier 1 metrics for all columns. Uses
`row_count` from Phase 0 as the denominator:

```sql
SELECT
    APPROX_COUNT_DISTINCT({col})                        AS distinct_count,
    COUNT_IF({col} IS NULL)                             AS null_count,
    APPROX_COUNT_DISTINCT({col}) / {row_count}          AS uniqueness_ratio,
    COUNT_IF({col} IS NULL) / {row_count}               AS null_rate,
    -- Monotonicity (numeric columns only)
    CASE WHEN {is_numeric}
         THEN (MAX({col}::NUMBER) - MIN({col}::NUMBER))
              / NULLIF({row_count} - 1, 0)
         ELSE NULL END                                  AS monotonicity_ratio,
    STDDEV(LENGTH({col}::VARCHAR))                      AS length_stddev
FROM {table}
```

Each aggregate per column is a separate expression in the SELECT list. For a
table with N columns, this is one query with ~6N expressions. Snowflake
evaluates column-level aggregates in parallel across micropartitions.

For value pattern detection, sample 1000 rows per table and classify in Python:

```sql
SELECT {cols} FROM {table} TABLESAMPLE (1000 ROWS)
```

### Phase 2: Targeted Pair/Cross-Table Queries

Only for tables where Phase 1 found no single-column PK candidate.
See Tier 2 and Tier 3 metrics above.

### Scoping

Profile only tables/views that have a corresponding `PhysicalTable` or
`PhysicalView` node in the graph. Skip ephemeral models (no physical artifact).

### Cost Control

- Use `APPROX_COUNT_DISTINCT` (HyperLogLog) instead of exact `COUNT(DISTINCT)`
- Row count from `INFORMATION_SCHEMA` (free) instead of `COUNT(*)`
- `IS_NULLABLE = 'NO'` as free not-null filter (skip null-rate query for DDL-declared NOT NULL columns)
- Sample for pattern detection: `TABLESAMPLE (1000 ROWS)`
- Run Tier 2/3 only for tables where Tier 1 found no single-column PK candidate
- Parallelize across tables (bounded concurrency)

## Execution Order

```text
1. Tier 1: Single-column profiling (all tables)
   → Persist TableProfile + ColumnProfile nodes
   → Feed into Pass 3 collect_profiling_signals()

2. Stability check (optional, requires second snapshot)
   → Suppress unstable profiling_unique signals

3. Tier 2: Composite uniqueness (tables without single-column PK)
   → Candidate pairs from JOIN keys + naming + near-unique columns
   → Persist CompositeKeyCandidate nodes (optional)
   → Feed as compound signal into Pass 3

4. Tier 3: Cross-table overlap (tables with PK candidate)
   → FK evidence for identity class expansion
   → Feed into Pass 3 or directly into Pass 5 (identity class merging)
```

## Impact Estimate

Based on the sf_analytics graph:

| Current state                              | After Tier 1 profiling                 |
| ------------------------------------------ | -------------------------------------- |
| 52 IdentityClasses with PK (1.7%)          | Estimated 500-800+ (16-26%)            |
| 156 INFERRED_FK edges                      | Estimated 1,000-2,000+                 |
| grain_columns from structural signals only | grain_columns validated by PK evidence |

The estimate assumes ~50% of `_id` columns in the graph will pass the
uniqueness + not-null threshold from profiling data alone.
