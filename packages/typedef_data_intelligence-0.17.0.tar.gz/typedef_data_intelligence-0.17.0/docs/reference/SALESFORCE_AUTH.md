# Salesforce Authentication Guide

Version: 1.0
Status: Active
Last Updated: 2026-01-27

## Overview

The Salesforce integration supports five authentication flows via a strategy-pattern auth module. Each flow produces an access token used by `simple_salesforce` to call the Salesforce REST API.

| Flow                   | Use Case                     | Interactive       | Requires                                |
| ---------------------- | ---------------------------- | ----------------- | --------------------------------------- |
| **PKCE**               | CLI users with a browser     | Yes (browser)     | Connected App with PKCE enabled         |
| **Device Flow**        | Headless / SSH environments  | Yes (any browser) | Connected App with Device Flow enabled  |
| **Client Credentials** | Backend services             | No                | Connected App with client secret        |
| **JWT Bearer**         | Backend services             | No                | Connected App with uploaded certificate |
| **Password**           | Legacy / backward-compatible | No                | Username, password, security token      |

## Architecture

```
SalesforceMetadataClient
    |
    +-- auth: SalesforceAuth (protocol)
            |
            +-- PasswordAuth         (legacy SOAP login)
            +-- OAuthPKCEAuth        (browser + local callback server)
            +-- OAuthDeviceFlowAuth  (poll-based, no local server)
            +-- ClientCredentialsAuth (client_id + client_secret)
            +-- JWTBearerAuth        (signed JWT assertion)
```

The `SalesforceAuth` protocol defines two methods:

- `authenticate()` -- initial login, returns `SalesforceCredentials(access_token, instance_url)`
- `refresh_if_needed()` -- called on 401 retry, refreshes or re-authenticates

The client wraps every public method with a `@_with_retry` decorator that catches expired-session errors, calls `refresh_if_needed()`, and retries once.

### Token Persistence

OAuth flows (PKCE, Device Flow) store tokens via `TokenStore`:

1. **Primary**: OS keychain via `keyring` library
2. **Fallback**: `~/.typedef/salesforce_tokens.json` (chmod 600)

Tokens are keyed by `org_key` so multiple Salesforce orgs can coexist.

---

## Salesforce Setup

All OAuth flows require a **Connected App** in your Salesforce org.

### Creating a Connected App

1. **Setup > App Manager > New Connected App**
2. Fill in basic info (name, API name, contact email)
3. Check **Enable OAuth Settings**
4. Configure per flow (see sections below)
5. Save and note the **Consumer Key**

### Post-Save: Approve Users

For flows that require pre-authorization (JWT, Client Credentials, Device Flow):

1. **Setup > App Manager > [your app] > dropdown > Manage** (not Edit)
2. Set **Permitted Users** to **"Admin approved users are pre-authorized"**
3. Click **Manage Profiles** and add the relevant profile (e.g. System Administrator)
4. Save

Changes can take up to 10 minutes to propagate.

---

## Flow 1: PKCE (Authorization Code + Proof Key)

### When to Use

Interactive CLI sessions where you have a browser available on the same machine.

### Salesforce Connected App Settings

| Setting                            | Value                                      |
| ---------------------------------- | ------------------------------------------ |
| Callback URL                       | `http://localhost:8443/callback`           |
| OAuth Scopes                       | `api`, `refresh_token`                     |
| Require PKCE                       | Checked                                    |
| Require Secret for Web Server Flow | Unchecked (public client)                  |
| Enable for Device Flow             | Optional (enables Device Flow on same app) |
| Permitted Users                    | Admin approved users are pre-authorized    |

**Important**: The callback URL must use `http://localhost` (not `http://127.0.0.1`). Some Salesforce editions reject `http://` with `127.0.0.1` but accept it with `localhost`.

### Usage

```bash
# Step 1: Login (opens browser, stores tokens)
uv run lineage sf-login --client-id <CONSUMER_KEY>

# Step 2: Load metadata using cached tokens
uv run lineage load-salesforce --auth oauth_pkce --client-id <CONSUMER_KEY> --verbose

# For sandbox orgs:
uv run lineage sf-login --client-id <CONSUMER_KEY> --login-url https://test.salesforce.com
```

### How It Works

1. CLI generates a PKCE `code_verifier` + S256 `code_challenge`
2. Opens browser to Salesforce `/services/oauth2/authorize`
3. Local HTTP server on `localhost:8443` captures the redirect with `?code=`
4. CLI exchanges the code + `code_verifier` for access + refresh tokens
5. Tokens are persisted via `TokenStore`
6. Subsequent runs use the cached refresh token (no browser needed)

### Options

| Option        | Envvar         | Default                        | Description                   |
| ------------- | -------------- | ------------------------------ | ----------------------------- |
| `--client-id` | `SF_CLIENT_ID` | required                       | Connected App consumer key    |
| `--login-url` | `SF_LOGIN_URL` | `https://login.salesforce.com` | Login endpoint                |
| `--port`      | --             | `8443`                         | Local callback server port    |
| `--org-key`   | --             | `default`                      | Token store key for multi-org |

---

## Flow 2: Device Flow

### When to Use

Headless environments (SSH, CI) or when you cannot run a local callback server. The user can authorize from any browser on any device.

### Salesforce Connected App Settings

Uses the same Connected App as PKCE with **Enable for Device Flow** checked.

**Important**: Permitted Users must be set to **"Admin approved users are pre-authorized"** with the user's profile added. "All users may self-authorize" does not work for Device Flow on some Salesforce editions.

### Usage

```bash
# Step 1: Login (prints URL + code, polls for approval)
uv run lineage sf-login --client-id <CONSUMER_KEY> --device

# Step 2: Load metadata using cached tokens
uv run lineage load-salesforce --auth device --client-id <CONSUMER_KEY> --verbose
```

### How It Works

1. CLI requests a device code from Salesforce (POST with `response_type=device_code`)
2. Salesforce returns a `user_code` and `verification_uri`
3. CLI prints the URL and code, attempts to open the browser
4. User visits the URL and enters the code on any device
5. CLI polls the token endpoint with `grant_type=device` (Salesforce-specific, not the RFC 8628 URN)
6. On approval, Salesforce returns access + refresh tokens
7. Tokens are persisted via `TokenStore`

### Known Limitations

- **Salesforce Starter edition**: Device Flow may return "Access Denied" even with correct pre-authorization. This appears to be an edition-level restriction. Use PKCE instead.
- Device codes expire after 10 minutes.
- If Salesforce returns `slow_down`, the polling interval increases by 5 seconds.

---

## Flow 3: Client Credentials

### When to Use

Server-to-server integrations with no user interaction. The Connected App authenticates as a pre-configured "Run As" user.

### Salesforce Connected App Settings

| Setting                        | Value                                                 |
| ------------------------------ | ----------------------------------------------------- |
| Callback URL                   | `https://localhost/callback` (not used, but required) |
| OAuth Scopes                   | `api`                                                 |
| Enable Client Credentials Flow | Checked                                               |
| Permitted Users                | Admin approved users are pre-authorized               |
| Run As user                    | Configured (under Client Credentials Flow settings)   |

### Usage

```bash
uv run lineage load-salesforce --auth client_credentials \
  --client-id <CONSUMER_KEY> \
  --client-secret <CONSUMER_SECRET> \
  --verbose
```

No `sf-login` step needed -- authenticates directly on each run.

### How It Works

1. POST to `/services/oauth2/token` with `grant_type=client_credentials`, `client_id`, `client_secret`
2. Salesforce returns an access token (no refresh token)
3. On 401 retry, the client simply re-authenticates

### Known Limitations

- **Not available on all editions**: Salesforce Starter/Essentials editions return `"request not supported on this domain"`. Requires Enterprise, Unlimited, Performance, or Developer Edition.
- No refresh token -- each session requires a full authentication.

### Options

| Option            | Envvar             | Description                                              |
| ----------------- | ------------------ | -------------------------------------------------------- |
| `--client-id`     | `SF_CLIENT_ID`     | Connected App consumer key                               |
| `--client-secret` | `SF_CLIENT_SECRET` | Connected App consumer secret                            |
| `--login-url`     | `SF_LOGIN_URL`     | Login endpoint (default: `https://login.salesforce.com`) |

---

## Flow 4: JWT Bearer

### When to Use

Server-to-server integrations using a private key. More secure than Client Credentials because no shared secret is transmitted -- only a signed assertion.

### Salesforce Connected App Settings

| Setting                | Value                                                                  |
| ---------------------- | ---------------------------------------------------------------------- |
| Callback URL           | `https://localhost/callback` (not used, but required)                  |
| OAuth Scopes           | `api`, `refresh_token`                                                 |
| Use Digital Signatures | Checked, certificate uploaded                                          |
| Permitted Users        | Admin approved users are pre-authorized                                |
| Profile                | System Administrator (or the user's profile) added via Manage Profiles |

**Both** the `api` and `refresh_token` scopes are required. Without `refresh_token`, Salesforce returns: `"refresh_token scope is required and the connected app should be installed and preauthorized"`.

### Generating the Key Pair

```bash
# Generate RSA private key
openssl genrsa -out server.key 2048

# Generate self-signed certificate (upload this to Salesforce)
openssl req -new -x509 -key server.key -out server.crt -days 365
```

Upload `server.crt` to the Connected App under **Use Digital Signatures**.

### Usage

```bash
uv run lineage load-salesforce --auth jwt \
  --client-id <CONSUMER_KEY> \
  --username <SF_USERNAME> \
  --private-key-path server.key \
  --verbose
```

No `sf-login` step needed -- authenticates directly on each run.

### How It Works

1. Build a JWT with claims: `iss` (client_id), `sub` (username), `aud` (login_url), `exp` (+5 min)
2. Sign the JWT with the private key using RS256
3. POST to `/services/oauth2/token` with `grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer` and the signed assertion
4. Salesforce validates the signature against the uploaded certificate
5. Returns an access token (no refresh token)

### Options

| Option               | Envvar                | Description                                              |
| -------------------- | --------------------- | -------------------------------------------------------- |
| `--client-id`        | `SF_CLIENT_ID`        | Connected App consumer key                               |
| `--username`         | `SF_USERNAME`         | Salesforce username to impersonate                       |
| `--private-key-path` | `SF_PRIVATE_KEY_PATH` | Path to PEM private key file                             |
| `--login-url`        | `SF_LOGIN_URL`        | Login endpoint (default: `https://login.salesforce.com`) |

### Dependencies

JWT Bearer requires `PyJWT[crypto]`. Install via the `salesforce-jwt` extras:

```bash
uv sync --extra salesforce-jwt
# or
pip install 'typedef-data-intelligence[salesforce-jwt]'
```

---

## Flow 5: Password (Legacy)

### When to Use

Backward compatibility with existing integrations. Does not require a Connected App.

### Usage

```bash
uv run lineage load-salesforce \
  --instance-url https://your-instance.my.salesforce.com \
  --username user@example.com \
  --password yourpassword \
  --security-token yoursecuritytoken \
  --verbose
```

All credentials can be set via environment variables: `SF_INSTANCE_URL`, `SF_USERNAME`, `SF_PASSWORD`, `SF_SECURITY_TOKEN`.

### How It Works

When the client receives legacy credentials (all four fields set), it wraps them in `PasswordAuth` and delegates to `simple_salesforce`, which handles the SOAP login internally.

---

## Auth Mode Auto-Detection

When `--auth` is omitted from `load-salesforce`, the mode is auto-detected based on which options are provided:

| Detected Mode        | Condition                                                                   |
| -------------------- | --------------------------------------------------------------------------- |
| `password`           | `--instance-url` + `--username` + `--password` + `--security-token` all set |
| `client_credentials` | `--client-id` + `--client-secret` set                                       |
| `jwt`                | `--client-id` + `--username` + `--private-key-path` set                     |
| `oauth_pkce`         | `--client-id` alone (loads cached tokens from `sf-login`)                   |
| Error                | None of the above                                                           |

Explicit `--auth` is recommended to avoid ambiguity.

---

## Environment Variables

All credential options can be set via environment variables to avoid passing them on every invocation:

```bash
# In .env file (loaded automatically by load-env-file)
SF_CLIENT_ID=3MVG9...
SF_CLIENT_SECRET=...
SF_USERNAME=user@example.com
SF_PASSWORD=...
SF_SECURITY_TOKEN=...
SF_PRIVATE_KEY_PATH=./server.key
SF_LOGIN_URL=https://login.salesforce.com
SF_INSTANCE_URL=https://your-instance.my.salesforce.com
```

---

## Troubleshooting

### "Access Denied" on Device Flow

The Connected App must have **Permitted Users** set to "Admin approved users are pre-authorized" with the user's profile added. "All users may self-authorize" does not work for Device Flow on some editions. Salesforce Starter edition may not support Device Flow at all.

### "request not supported on this domain" (Client Credentials)

Client Credentials flow is not available on Salesforce Starter/Essentials editions. Use PKCE or JWT Bearer instead.

### "refresh_token scope is required" (JWT Bearer)

The Connected App needs both `api` and `refresh_token` OAuth scopes. Edit the app (not Manage -- Edit) and add "Perform requests at any time (refresh_token, offline_access)".

### "user is not admin approved to access this app"

Go to **Setup > App Manager > [app] > Manage**, set Permitted Users to "Admin approved users are pre-authorized", then add the user's profile via **Manage Profiles**.

### Callback URL rejected with http://127.0.0.1

Salesforce may reject `http://` with `127.0.0.1` on some editions. Use `http://localhost:8443/callback` instead.

### Cached refresh token expired

On first use after a long gap, the PKCE flow will detect the expired refresh token, log `"Cached refresh token expired"`, and automatically open the browser for re-authentication. No manual intervention needed.

### simple-salesforce not installed

The Salesforce integration is an optional dependency:

```bash
uv sync --extra salesforce           # PKCE, Device Flow, Client Credentials, Password
uv sync --extra salesforce-jwt       # Adds JWT Bearer support (PyJWT[crypto])
```

---

## Testing Status

Tested against a Salesforce Starter trial org (`dream-velocity-1633.my.salesforce.com`):

| Flow                   | Status             | Notes                                                                                   |
| ---------------------- | ------------------ | --------------------------------------------------------------------------------------- |
| **PKCE**               | Verified           | Full end-to-end: login, token caching, refresh, metadata load to FalkorDB               |
| **JWT Bearer**         | Verified           | Full end-to-end: key-based auth, metadata load to FalkorDB                              |
| **Device Flow**        | Blocked by edition | "Access Denied" despite correct pre-authorization. Likely a Starter edition restriction |
| **Client Credentials** | Blocked by edition | "request not supported on this domain". Requires Enterprise+ edition                    |
| **Password**           | Not tested         | Backward-compatible wrapper, no code changes to existing path                           |

### Unit Tests

131 tests covering all auth strategies:

```bash
# Run all Salesforce tests
uv run pytest tests/test_salesforce_models.py tests/test_salesforce_loader.py \
  tests/test_salesforce_auth.py tests/test_sf_login_cli.py -v
```

Test coverage includes: PKCE challenge generation, code exchange, token refresh, Device Flow polling (pending/slow_down/expired), Client Credentials token acquisition, JWT assertion building, TokenStore save/load/clear/multi-org isolation, client auth path selection, CLI auto-detection logic, and `sf-login` command invocation.

---

## Code Reference

| File                                                                | Description                                            |
| ------------------------------------------------------------------- | ------------------------------------------------------ |
| `src/lineage/ingest/static_loaders/salesforce/auth/protocol.py`     | `SalesforceAuth` protocol + `SalesforceCredentials`    |
| `src/lineage/ingest/static_loaders/salesforce/auth/password.py`     | Legacy password wrapper                                |
| `src/lineage/ingest/static_loaders/salesforce/auth/oauth_pkce.py`   | PKCE flow                                              |
| `src/lineage/ingest/static_loaders/salesforce/auth/device_flow.py`  | Device Flow                                            |
| `src/lineage/ingest/static_loaders/salesforce/auth/client_creds.py` | Client Credentials flow                                |
| `src/lineage/ingest/static_loaders/salesforce/auth/jwt_bearer.py`   | JWT Bearer flow                                        |
| `src/lineage/ingest/static_loaders/salesforce/auth/token_store.py`  | Token persistence (keyring + file)                     |
| `src/lineage/ingest/static_loaders/salesforce/auth/server.py`       | Local callback server for PKCE                         |
| `src/lineage/ingest/static_loaders/salesforce/client.py`            | `SalesforceMetadataClient` (dual-path auth, 401 retry) |
| `src/lineage/cli.py`                                                | `sf-login` command + `load-salesforce` auth options    |
