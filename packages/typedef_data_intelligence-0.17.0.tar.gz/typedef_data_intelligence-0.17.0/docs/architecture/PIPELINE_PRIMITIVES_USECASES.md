# Pipeline Abstraction Primitives — Use Case Exploration

This document explores how the three pipeline abstraction primitives — Grain,
Behavioral Class, and Pipeline Operation — can be applied to practical data
engineering and analytics problems. The primitives are implemented in the grain
tracer (`src/lineage/grain/tracer.py`) and produce machine-readable output for
every node and edge in the lineage DAG.

## The Three Primitives

| Primitive              | Question It Answers                  | Example                      |
| ---------------------- | ------------------------------------ | ---------------------------- |
| **Grain**              | What uniquely identifies each row?   | `{server_id, activity_date}` |
| **Behavioral Class**   | How does this data behave over time? | entity, event, snapshot      |
| **Pipeline Operation** | What transformation produced this?   | aggregate, spine, reshape    |

These are computed deterministically from the lineage graph and SQL AST
analysis. They attach to **data at a point in its journey**, not to containers.

---

## Use Case 1: Salesforce Report Reconciliation Against the BI Layer

### Problem

Business users build ad-hoc reports in Salesforce while the analytics team
maintains curated models in dbt/Cube. The two systems consume the same source
data through different paths but can produce different numbers. Today there is
no systematic way to answer:

- Which Salesforce reports are already covered by BI models?
- Which reports produce numbers that will diverge from BI?
- Where are the gaps — reports with no BI equivalent?

### Why the Primitives Enable This

The graph already contains both sides of the equation:

```text
Salesforce Report path:
  SfReport ──SF_REPORT_DEPENDS_ON_OBJECT──→ SfObject
                                               │
BI layer path:                                 │ (same entity)
  SfObject ←──DEPENDS_ON── DbtSource → DbtModel → ... → CubeView
```

The Report IR (67 reports, 379 fields, 49 group-bys, 66 joins) stores enough
structure to compute the report's effective grain, behavioral class, and
operations — the same three primitives the tracer computes for the BI layer.

### How It Works

**Step 1 — Compute report grain from ReportIRGroupBy nodes.**

A Salesforce summary report grouped by `ACCOUNT_NAME` and `STAGE_NAME` has an
effective grain of `{ACCOUNT_NAME, STAGE_NAME}`. A tabular report with no
groupings has entity-level grain (one row per record). A matrix report has
row-axis grain × column-axis grain.

```text
ReportIR → HAS_IR_GROUPBY → ReportIRGroupBy(field_alias, axis, sequence)
```

This maps directly to a `Grain` object using the field aliases as grain field
names, with identity class resolution via the `ref_entity` + `ref_field`
references on each `ReportIRField`.

**Step 2 — Classify report behavioral class.**

| Report Format | GroupBy Contains Time Field?        | Behavioral Class                           |
| ------------- | ----------------------------------- | ------------------------------------------ |
| tabular       | —                                   | entity (current state, one row per record) |
| summary       | no                                  | entity (aggregated current state)          |
| summary       | yes (e.g., `CLOSE_DATE` by quarter) | snapshot (periodic aggregation)            |
| matrix        | date on column axis                 | snapshot (cross-tabulated over time)       |

The classification uses the same temporal field heuristics as the pipeline
tracer (`_is_temporal_field`), applied to the report's `ReportIRGroupBy` fields.

**Step 3 — Map report entities to BI models via lineage.**

Each report's `base_entity` (e.g., `Opportunity`) connects to `SfObject` nodes
via `SF_REPORT_DEPENDS_ON_OBJECT`. The grain tracer already has paths from
every `SfObject` through to every `CubeView`. By following these paths, we find
which BI models serve the same source entities.

```cypher
-- Find BI models that serve the same entities as a report
MATCH (sf:SfReport {report_id: $id})-[:SF_REPORT_DEPENDS_ON_OBJECT]->(obj:SfObject)
MATCH (src:DbtSource)-[:DEPENDS_ON]->(obj)
MATCH (m:DbtModel)-[:DEPENDS_ON*1..5]->(src)
RETURN m.name, m.unique_id
```

**Step 4 — Compare grain, class, and field coverage.**

For each (report, BI model) pair that shares source entities:

```python
relation = report_grain.relation_to(bi_model_grain)
```

| Grain Relation | Class Match | Interpretation                                                                          |
| -------------- | ----------- | --------------------------------------------------------------------------------------- |
| EQUAL          | same        | **Redundant** — report and BI model answer the same question                            |
| EQUAL          | different   | **Divergent** — same grain but entity vs snapshot will give different numbers over time |
| COARSER        | —           | **Report is less detailed** — BI model provides finer grain                             |
| FINER          | —           | **Report is more detailed** — BI model aggregates away detail the report preserves      |
| INCOMPARABLE   | —           | **Different questions** — identity structures don't overlap                             |

Additionally, compare field coverage:

```text
report_fields = {f.ref_entity + "." + f.ref_field for f in report.ir_fields}
bi_fields = {grain fields + measure fields from the BI model's semantic analysis}
coverage = report_fields ∩ bi_fields
gaps = report_fields - bi_fields
```

### Expected Output

A reconciliation report per Salesforce report:

```text
Report: "Pipeline by Stage" (summary, grain={STAGE_NAME})
  Base entity: Opportunity
  Measures: SUM(AMOUNT), COUNT(OPPORTUNITY_NAME)
  Filters: CLOSED = 0 (open only)

  Matching BI models:
    ✓ fct_pipeline (grain={opportunity_id, stage})
      Grain relation: FINER (BI has per-opportunity detail, report aggregates by stage)
      Class: both entity
      Field coverage: 8/10 report fields mapped
      Missing: NEXT_STEP, LEAD_SOURCE (not in BI model)

    ~ dim_daily_server_info (grain={daily_server_id})
      Grain relation: INCOMPARABLE (different entity domain)

  Recommendation: Report is served by fct_pipeline at finer grain.
    Consider migrating users to the Cube view. 2 fields missing — file ticket.
```

### Value

- **For analytics teams**: Identify which Salesforce reports can be retired once
  users migrate to BI dashboards. Quantify the coverage gap.
- **For data governance**: Detect when reports and BI models will produce
  different numbers for the same metric (entity vs snapshot divergence).
- **For prioritization**: The reports with no BI equivalent and high usage are
  the highest-priority candidates for new dbt model development.

---

## Use Case 2: Automated dbt Test Generation

### Problem

Most dbt projects have sparse test coverage. Writing `unique_combination_of_columns`
and `not_null` tests by hand is tedious and error-prone. Grain drift (a model's
effective grain changing due to upstream changes) is caught late or not at all.

### Why the Primitives Enable This

We know the grain of 594 nodes with high confidence. For each node, the grain
fields are the exact columns that should have uniqueness and not-null
constraints. The behavioral class determines which additional tests are
appropriate.

### How It Works

**For every DbtModel with a computed grain:**

| Behavioral Class | Generated Tests                                                                      |
| ---------------- | ------------------------------------------------------------------------------------ |
| entity           | `unique_combination_of_columns` on grain fields, `not_null` on each grain field      |
| event            | Same as entity, plus `accepted_values` or recency test on temporal grain field       |
| snapshot         | Same as entity, plus date continuity test (no gaps in temporal field per entity key) |

**Example output** (dbt YAML):

```yaml
# Auto-generated from grain tracer — int_server_active_days_spined
models:
  - name: int_server_active_days_spined
    description: "Snapshot: one row per server per date"
    columns:
      - name: server_id
        tests:
          - not_null
      - name: server_date
        tests:
          - not_null
    tests:
      - dbt_utils.unique_combination_of_columns:
          combination_of_columns:
            - server_id
            - server_date
      # Snapshot completeness: no date gaps per server
      - dbt_utils.sequential_values:
          column_name: server_date
          group_by_columns: [server_id]
          interval: 1
          datepart: day
```

### Value

- **Coverage**: Generate tests for all 594 nodes, not just the handful with
  manually written tests.
- **Drift detection**: If a model's grain changes (e.g., a new column added to
  GROUP BY), the test will fail, catching the change before it propagates.
- **Behavioral contracts**: Snapshot models get date continuity tests that
  entity models don't — the behavioral class makes the test suite semantically
  appropriate.

---

## Use Case 3: Impact Analysis with Semantic Context

### Problem

Standard lineage answers "what depends on this model?" but not "how will
downstream models be affected by a specific change?" Knowing that 47 models
depend on `dim_customers` doesn't tell you which ones will break if you rename
a column, change a GROUP BY, or add a filter.

### Why the Primitives Enable This

The pipeline operation at each edge tells you _how_ the downstream model uses
its upstream dependency. An AGGREGATE that groups by `customer_id` will break
if `customer_id` is renamed. A PASSTHROUGH won't care about column renames
(it passes everything through). A SPINE that adds `activity_date` will break
if the upstream model's grain changes.

### How It Works

Given a proposed change to model X:

1. **Column rename** (`customer_id` → `account_id`):
   - Find all downstream edges where operation is AGGREGATE, RESHAPE, or FANOUT
   - Check if the renamed column appears in the downstream model's grain
   - PASSTHROUGH edges are safe (column just flows through)

2. **GROUP BY change** (adding a field to an aggregation):
   - The model's grain becomes finer
   - Every downstream AGGREGATE or COMPOSE that uses this model will now
     receive more rows per group
   - Flag: "dim_daily_server_info goes from `{daily_server_id}` to
     `{daily_server_id, region}` — 4 downstream models AGGREGATE from this
     and will see their row counts increase"

3. **Filter added** (WHERE clause restricting rows):
   - Grain unchanged, but row count decreases
   - Downstream SPINEs that expect complete entity coverage may now have gaps
   - Flag: "int_server_active_days_spined is a SNAPSHOT that spines by date.
     Removing servers via a filter will create apparent gaps in the snapshot."

### Output

```text
Proposed change: rename dim_customers.customer_id → account_id

Impact analysis:
  fct_revenue (AGGREGATE, uses customer_id in GROUP BY) — WILL BREAK
  fct_churn (RESHAPE, grain={customer_id, month}) — WILL BREAK
  int_customer_enriched (PASSTHROUGH) — safe (column flows through)
  rpt_arr_by_segment (COMPOSE via Cube) — safe (Cube uses semantic layer)

  3 downstream snapshot models depend on fct_revenue:
    int_daily_arr_snapshot — SPINE from fct_revenue
    → Will propagate the break (inherits fct_revenue's grain)
```

### Value

- **Precise blast radius**: Not just "47 models depend on this" but "3 will
  break, 12 will see different row counts, 32 are unaffected."
- **Operation-aware**: Knows that PASSTHROUGH is safe, AGGREGATE is fragile to
  column changes, SPINE is fragile to completeness changes.
- **Behavioral context**: Warns that breaking a snapshot model's upstream will
  create date gaps, while breaking an entity model's upstream is a hard failure.

---

## Use Case 4: Pipeline Anomaly Detection

### Problem

Pipeline changes can silently alter the semantics of downstream models. A new
JOIN in an intermediate model might change its grain from entity to snapshot
without anyone noticing. A refactored GROUP BY might change a model's
behavioral class. These semantic drift events are invisible to standard CI/CD.

### Why the Primitives Enable This

By computing the three primitives on every pipeline run and comparing against
a baseline, we can detect semantic drift — changes in grain, class, or
operation that indicate the pipeline's behavior has changed even if the tests
still pass.

### How It Works

**Baseline**: Store the three primitives per node as a contract:

```json
{
  "int_server_active_days_spined": {
    "grain": ["server_id", "server_date"],
    "behavioral_class": "snapshot",
    "upstream_operation": "spine"
  }
}
```

**On each pipeline change**: Recompute primitives and diff against baseline:

| Change Detected          | Severity | Example                                              |
| ------------------------ | -------- | ---------------------------------------------------- |
| Grain fields added       | Medium   | `{server_id}` → `{server_id, region}`                |
| Grain fields removed     | High     | `{server_id, server_date}` → `{server_id}`           |
| Behavioral class changed | High     | snapshot → entity (lost temporal dimension)          |
| Operation changed        | Medium   | passthrough → reshape (was identity, now transforms) |
| New SPINE or FANOUT      | Info     | Grain became finer — intentional expansion?          |
| AGGREGATE removed        | High     | Model was aggregating, now passes raw rows           |

### Value

- **Catches silent breakage**: A model that goes from snapshot to entity still
  produces output, but downstream date-continuity assumptions are violated.
- **Semantic CI/CD**: Add to the PR check: "This change alters the grain of
  3 models and changes 1 model from snapshot to entity. Is this intentional?"
- **Drift over time**: Track how the pipeline's semantic structure evolves
  across releases.

---

## Use Case 5: Refactoring Recommendations

### Problem

Pipelines accumulate technical debt: unnecessary intermediate models, redundant
transformations, over-joining. Identifying refactoring candidates requires
understanding what each model actually does to the data, which is hard to
assess manually at scale.

### Why the Primitives Enable This

The pipeline operation tells you what each model does. Patterns of operations
reveal structural inefficiencies.

### Patterns to Detect

| Pattern                                 | What It Means                           | Recommendation                                |
| --------------------------------------- | --------------------------------------- | --------------------------------------------- |
| PASSTHROUGH → PASSTHROUGH → PASSTHROUGH | 3+ models that don't transform grain    | Consolidate into fewer models                 |
| RESHAPE → RESHAPE (no class change)     | Two consecutive identity restructurings | Likely combinable into one model              |
| SPINE → AGGREGATE (same temporal field) | Date-spine immediately grouped away     | The spine may be unnecessary                  |
| FANOUT with >5 grain fields added       | Over-joining (grain exploded)           | Review join — likely too many fields          |
| EMERGE after 2+ UNRESOLVED              | Grain lost and re-established           | SQL parsing gap — fix the intermediate models |

### Current Pipeline Statistics

From the sf_analytics graph (3,900 paths, 594 nodes):

```text
Operation distribution:
  passthrough  53%  — Majority of edges are identity-preserving
  reshape      20%  — Significant identity restructuring in int_* models
  source       11%  — Root nodes
  unresolved    7%  — SQL parsing gaps
  emerge        4%  — Grain recovered after gaps
  compose       3%  — Cube view composition
  spine+agg     2%  — Date-spining and re-aggregation
  fanout       <1%  — Join expansions
```

The dominant path pattern `source → passthrough → reshape → passthrough`
reflects telemetry entering via passthroughs (base/stg models), getting
identity-restructured in `int_*` models, then passing through to BI.

### Value

- **Quantified debt**: "127 of 594 nodes are pure passthroughs — candidates
  for consolidation."
- **Operation-aware refactoring**: Don't merge a SPINE and an AGGREGATE that
  serve different analytical purposes just because they're adjacent.
- **Prioritized by blast radius**: Refactoring a model with 50 downstream
  paths is higher-risk than one with 2.

---

## Use Case 6: Auto-Generated Model Documentation

### Problem

Data model documentation is perpetually out of date. Descriptions like "staging
model for server events" don't convey the semantic transformation happening.

### Why the Primitives Enable This

The three primitives provide a formal, machine-generated description of what
each model does:

```text
int_server_active_days_spined
  Grain: {server_id, server_date}
  Behavioral class: snapshot
  Operation: SPINE (from entity upstream)

  "This model is a daily snapshot of server activity. It receives entity-grain
  data (per server) from dim_daily_server_info and date-spines it to create
  one row per server per date. The temporal key (server_date) was added by
  this model's transformation."
```

### Template

```text
{model_name}
  Grain: {grain_fields}
  Class: {behavioral_class}
  Operation: {pipeline_operation} from {parent_class} upstream

  "{model_name} is a {behavioral_class} model at the grain of
  {grain_fields_human}. It {operation_description} data from
  {upstream_model}. {class_transition_description}."
```

Where `operation_description` maps from operation:

- PASSTHROUGH → "passes through"
- AGGREGATE → "aggregates"
- SPINE → "date-spines"
- FANOUT → "joins and expands"
- RESHAPE → "restructures the identity of"
- COMPOSE → "composes via cube joins"

### Value

- **Always current**: Generated from the actual pipeline structure, not manual
  descriptions.
- **Semantic, not structural**: Describes what the model does to the data, not
  how it's implemented.
- **Consistent vocabulary**: Every model described using the same primitives.

---

## Use Case 7: Business Concept Index (Bottom-Up Ontology)

### Problem

When someone asks "what is an Account?" or "how do we define ARR?", there is no
single place that answers authoritatively. Definitions live across Salesforce
object descriptions, dbt model docs, Cube view labels, and tribal knowledge.
The definitions are often inconsistent — "ARR" in a Salesforce report means
current contract value, while "ARR" in a snapshot model means point-in-time
value, and neither doc explains the difference.

Building and maintaining a business glossary by hand is expensive and always out
of date. The question is whether the pipeline itself contains enough signal to
construct one automatically.

### Why the Primitives Enable This

The three primitives, combined with the existing semantic analysis, contain the
raw materials for a bottom-up business ontology:

1. **Grain fields are concept references.** When `account_id` appears in a
   model's grain, that model is _about_ Accounts. By collecting every node
   where `account_id` participates in the grain, you get the concept's
   footprint across the pipeline — where it originates, how it transforms,
   where it ends up.

2. **Measures are scoped to grain.** The `InferredSemanticModel` nodes (from
   Fenic analysis) already have measures attached. Each measure is computed
   _at_ a grain. `SUM(amount)` at grain `{opportunity_id, month}` is a
   different thing than `SUM(amount)` at grain `{account_id}`. The grain tells
   you what the measure is _about_ — which concept it describes.

3. **Behavioral class gives temporal semantics.** "ARR" in an entity model is
   the current value. "ARR" in a snapshot model is a point-in-time value. Same
   field name, different answer to "what is ARR?", and the behavioral class is
   what distinguishes them.

4. **Pipeline operations show how concepts transform.** Account starts as an
   entity in Salesforce, gets SPINEd into daily snapshots in `int_*` models,
   gets AGGREGATEd back to entity in `fct_*` marts. This lifecycle is the
   definition — it tells you what "Account" means at each layer.

5. **Report IR shows how the business uses concepts.** The 67 Salesforce
   reports reveal which concepts and measures the business actually cares about,
   at what grain, with what filters. This is demand-side signal that
   complements the supply-side pipeline structure.

### How It Works

**Step 1 — Extract concept identities from grain fields.**

Walk all 594 nodes in the grain cache. For each grain field, normalize the name
to extract the base concept:

```text
account_id         → Account
server_id          → Server
daily_server_id    → Server (surrogate, trace to source)
opportunity_id     → Opportunity
activity_date      → (temporal, not a concept — skip)
license_telemetry_date → (temporal, skip)
```

Normalization rules:

- Strip `_id` suffix → concept name
- Strip `daily_`, `monthly_` prefixes (surrogate keys) → trace via grain
  lineage to find the source concept
- Temporal fields (`_date`, `_at`, `_timestamp`) are not concepts — they are
  the temporal axis of a snapshot or event

Group nodes by which concepts appear in their grain. This produces a
**concept → nodes** index.

**Step 2 — Attach measures to concepts.**

For each node in a concept's footprint, look up its `InferredSemanticModel`:

```cypher
MATCH (m:DbtModel {unique_id: $node_id})
      -[:HAS_INFERRED_SEMANTICS]->(sem:InferredSemanticModel)
      -[:HAS_MEASURE]->(meas:InferredMeasure)
RETURN meas.name, meas.expr, meas.agg_function
```

Each measure is scoped to the grain (and therefore to the concept):

```text
Concept: Account
  Measures at entity grain:
    - arr: SUM(amount) in fct_arr_reporting_monthly
    - customer_count: COUNT(DISTINCT account_id) in fct_arr_reporting_monthly
    - pipeline_value: SUM(weighted_amount) in fct_pipeline
  Measures at snapshot grain (per account per day):
    - daily_arr: SUM(amount) in int_opportunity_daily_arr
    - ending_arr: last value per day in dim_daily_server_info
```

The behavioral class distinguishes these: entity measures are current-state
aggregations, snapshot measures are point-in-time values.

**Step 3 — Build the concept lifecycle from grain traces.**

For each concept, trace its path through the pipeline using the grain traces:

```text
Account lifecycle:
  SfObject "Account" → entity, grain={id}
    ↓ PASSTHROUGH
  DbtSource "account" → entity, grain={id}
    ↓ RESHAPE
  stg_salesforce__account → entity, grain={account_id}
    ↓ SPINE
  int_opportunity_daily_arr → snapshot, grain={account_id, day, ...}
    ↓ AGGREGATE
  fct_arr_reporting_monthly → entity, grain={account_id, month}
    ↓ PASSTHROUGH → COMPOSE
  CubeView → entity, grain={account_id, month}
```

This lifecycle IS the definition. It tells you:

- Where the concept originates (Salesforce)
- How its identity transforms (renamed, spined, aggregated)
- What behavioral regimes it passes through (entity → snapshot → entity)
- Where it ends up (Cube views, Salesforce reports)

**Step 4 — Add domain segmentation from Cube views and reports.**

Different parts of the business use the same concept differently. Group the
concept's appearances by the downstream consumer:

```text
Account — domain usage:
  Sales (via fct_pipeline, Cube "pipeline"):
    Grain: {opportunity_id, stage}
    Measures: pipeline_value, deal_count
    Class: entity (current pipeline state)
    Used in: 4 Salesforce reports, 1 Cube view

  Finance (via fct_arr_reporting_monthly, Cube "arr"):
    Grain: {account_id, month}
    Measures: arr, expansion_arr, contraction_arr
    Class: entity (monthly aggregation)
    Used in: 3 Salesforce reports, 2 Cube views

  Customer Success (via dim_account_health):
    Grain: {account_id}
    Measures: health_score, nps_score, ticket_count
    Class: entity (current state)
    Used in: 2 Salesforce reports, 1 Cube view
```

This reveals that "Account" means different things to different teams — and
explains why they get different numbers when they ask "what's the ARR?"

**Step 5 — Persist as agent-queryable concept nodes.**

Create `BusinessConcept` nodes in the graph:

```text
BusinessConcept
  name: "Account"
  origin: "SfObject"
  identity_fields: ["account_id", "id"]
  model_count: 47
  report_count: 12
  cube_view_count: 8
  behavioral_lifecycle: ["entity", "snapshot", "entity"]
  key_measures: ["arr", "pipeline_value", "health_score"]
```

With edges:

- `CONCEPT_APPEARS_IN` → DbtModel (with grain role: "identity" or "context")
- `CONCEPT_HAS_MEASURE` → InferredMeasure (with scope: grain + class)
- `CONCEPT_USED_BY_REPORT` → Report (with role from report's groupings)
- `CONCEPT_ORIGINATES_FROM` → SfObject or DbtSource

### Expected Output

An agent answering "what is an Account?":

```text
Account is an entity concept originating from Salesforce. It represents a
customer or prospect organization.

Identity: Tracked by `account_id` (renamed from Salesforce `Id`) across
47 dbt models and 8 Cube views.

Key metrics computed about Accounts:
  - ARR (SUM of amount): available monthly in fct_arr_reporting_monthly
    and daily in int_opportunity_daily_arr (snapshot)
  - Pipeline value (SUM of weighted amount): in fct_pipeline
  - Health score: in dim_account_health

Lifecycle: Enters as a mutable entity from Salesforce, gets date-spined
into daily snapshots for time-series analysis, then re-aggregated into
monthly entity-grain mart tables.

Used by:
  - Sales: pipeline tracking (4 SF reports, 1 dashboard)
  - Finance: ARR reporting (3 SF reports, 2 dashboards)
  - CS: health monitoring (2 SF reports, 1 dashboard)

Note: "ARR" means different things depending on context:
  - In fct_arr_reporting_monthly (entity): current monthly ARR
  - In int_opportunity_daily_arr (snapshot): ARR as of a specific date
  Salesforce reports use current-state (entity) values.
```

An agent answering "how do we define ARR?":

```text
ARR (Annual Recurring Revenue) is computed differently depending on
context:

1. Current ARR (entity grain):
   Definition: SUM(amount) grouped by account × month
   Model: fct_arr_reporting_monthly
   Source: Salesforce Opportunity.Amount flowing through
     stg_salesforce__opportunity → int_opportunity_daily_arr → fct_arr
   Used by: Finance team, 3 Salesforce reports

2. Point-in-time ARR (snapshot grain):
   Definition: SUM(amount) per account per day
   Model: int_opportunity_daily_arr
   Source: Same as above, but date-spined to create daily snapshots
   Used by: Trending dashboards, daily monitoring

3. Ending ARR (entity grain):
   Definition: Last known ARR value per opportunity
   Model: sync_opportunity_update_ending_arr
   Source: Derived from daily snapshots, collapsed back to current state
   Used by: Salesforce sync (written back to Opportunity.Ending_ARR__c)

The difference between (1) and (2) is behavioral class: entity shows
the current value, snapshot preserves history. Reports using entity-grain
models will show today's number; dashboards using snapshot models can
show how ARR changed over time.
```

### What Already Exists vs What Needs to Be Built

| Component                                  | Status                                                      |
| ------------------------------------------ | ----------------------------------------------------------- |
| Grain per node (594 nodes)                 | Exists (grain tracer)                                       |
| Behavioral class per node                  | Exists (grain tracer)                                       |
| Pipeline operations per edge               | Exists (grain tracer)                                       |
| Measures per model (InferredMeasure)       | Exists (Fenic semantic analysis)                            |
| Dimensions per model (InferredDimension)   | Exists (Fenic semantic analysis)                            |
| SfObject entity structure                  | Exists (Salesforce loader)                                  |
| Report IR with field mappings              | Exists (67 reports loaded)                                  |
| Concept name extraction from grain fields  | **Needs to be built**                                       |
| Concept → model footprint index            | **Needs to be built**                                       |
| Measure scoping to concept + class         | **Needs to be built**                                       |
| Domain segmentation (which teams use what) | **Needs to be built** (heuristic from Cube/report grouping) |
| BusinessConcept graph nodes                | **Needs to be built**                                       |
| Agent tool for concept lookup              | **Needs to be built**                                       |

The extraction and indexing is the main new work. The raw materials — grain
traces, semantic analysis, Report IR — are all in the graph already.

### Value

- **Self-maintaining glossary**: Definitions update automatically when the
  pipeline changes. A new measure added to `fct_arr_reporting_monthly` appears
  in the Account concept's description on the next trace run.
- **Disambiguation**: Explains _why_ "ARR" means different things in different
  contexts (entity vs snapshot) rather than just picking one definition.
- **Provenance**: Every claim in the definition traces back to specific models,
  measures, and grain computations — not a human's recollection.
- **Cross-domain alignment**: Reveals when Sales, Finance, and CS are looking
  at the same concept through different lenses and at different grains, which
  is often the root cause of "our numbers don't match" conversations.

---

## Implementation Priority

| Use Case                       | Effort | Value     | Dependencies                                               |
| ------------------------------ | ------ | --------- | ---------------------------------------------------------- |
| 1. SF Report Reconciliation    | Medium | High      | Report IR already loaded; need reconciler logic            |
| 2. dbt Test Generation         | Low    | High      | Just template output from existing grain data              |
| 3. Impact Analysis             | Medium | High      | Need change proposal input format                          |
| 4. Anomaly Detection           | Medium | Medium    | Need baseline storage + diff logic                         |
| 5. Refactoring Recommendations | Low    | Medium    | Pattern matching on existing traces                        |
| 6. Auto Documentation          | Low    | Medium    | Template expansion from existing data                      |
| 7. Business Concept Index      | High   | Very High | Concept extraction + measure scoping + domain segmentation |

**Use Case 7** (Business Concept Index) is the most ambitious but also the
highest-value outcome — it turns the pipeline into a self-maintaining business
glossary that agents can query directly. It subsumes Use Case 6 (auto
documentation) and strengthens Use Cases 1 and 3 by providing the concept
vocabulary they need.

**Use Case 1** (SF Report Reconciliation) is the recommended starting point
because it exercises the full primitive stack against a concrete, already-loaded
dataset and produces immediately actionable output. It also serves as a proving
ground for the concept extraction logic needed by Use Case 7.

**Use Case 2** (dbt test generation) is the lowest-effort high-value option
if speed to tangible output is the priority.
