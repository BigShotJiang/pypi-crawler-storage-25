# Phase 2 IR Node Stitching to Native Layer

This document describes how Phase 2 Report IR nodes (GroupBy, Filter, Bucket, Formula, Highlight, CrossFilter, Join) are connected to the native Salesforce layer (`SfReportColumn` / `SfField`) via `MAPS_TO_NATIVE_FIELD` edges.

## Background

Phase 1 created `ReportIRField` nodes for each `detailColumn` and stitched them to `SfReportColumn` nodes. Phase 2 added additional IR node types that also reference Salesforce fields but were initially left unstitched.

## Phase 2 Node Types and Field References

| Node Type           | Field Property                       | Example Value                    | Points To                                          |
| ------------------- | ------------------------------------ | -------------------------------- | -------------------------------------------------- |
| ReportIRGroupBy     | `field_alias`                        | `STAGE_NAME`                     | SObject field                                      |
| ReportIRFilter      | `field_ref`                          | `AMOUNT`                         | SObject field                                      |
| ReportIRBucket      | `source_field`                       | `AMOUNT`                         | SObject field                                      |
| ReportIRFormula     | `expression`                         | `AMOUNT:SUM / RowCount`          | Multiple SObject fields (embedded in expression)   |
| ReportIRHighlight   | `field_alias`                        | `FORMULA_Sum_Amount` or `AMOUNT` | Formula developer name OR summarized SObject field |
| ReportIRCrossFilter | `related_field`, `filter_conditions` | `AccountId`, criteria items      | Join field + filter fields on related entity       |
| ReportIRJoin        | `from_field`, `to_field`             | (not populated yet)              | Join key fields between objects                    |

## Implemented Stitching (GroupBy, Filter, Bucket)

### Approach

Two-part implementation:

1. **Native loader** (`loader.py`): Creates `SfReportColumn` nodes for auxiliary fields (groupings, filters, bucket sources) that are not in `detailColumns`. Uses existing `_resolve_column_to_field()` + `col_to_obj` for `SfField` linkage.

2. **IR transformer** (`transformer.py`): Creates `MAPS_TO_NATIVE_FIELD` edges from GroupBy/Filter/Bucket nodes to `SfReportColumn`.

### Auxiliary Field Extraction

Fields are extracted from `metadata_full` in the native loader:

| Source             | Metadata Path                   | Field Key      |
| ------------------ | ------------------------------- | -------------- |
| Groupings (down)   | `groupingsDown[].field`         | Field API name |
| Groupings (across) | `groupingsAcross[].field`       | Field API name |
| Filters            | `filter.criteriaItems[].column` | Field API name |
| Buckets            | `buckets[].sourceColumnName`    | Field API name |

### Synthetic Field Exclusion

Computed/derived field refs are skipped because they have no corresponding SObject field:

| Prefix         | Meaning                               | Example                     |
| -------------- | ------------------------------------- | --------------------------- |
| `BucketField_` | Bucket-derived computed field         | `BucketField_Amount_Ranges` |
| `FORMULA`      | Summary or row formula developer name | `FORMULA_Sum_Amount`        |
| `Age_`         | System-calculated age field           | `Age_Lead_Age`              |

### Results

| Metric                          | Before | After                        |
| ------------------------------- | ------ | ---------------------------- |
| SfReportColumn count            | 109    | 174 (+65 auxiliary)          |
| GroupBy -> SfReportColumn edges | 0      | 45 (92% of 49 GroupBy nodes) |
| Filter -> SfReportColumn edges  | 1      | 20 (100% of 20 Filter nodes) |
| Bucket -> SfReportColumn edges  | 2      | 4 (100% of 4 Bucket nodes)   |

4 GroupBy nodes remain unstitched — likely field refs that could not resolve through `col_to_obj`.

## Implemented

### ReportIRFormula

**Status**: Done. `mapping_type="computed"`.

Formula expressions are parsed using the `lineage.formula` parser to extract field references (both `FIELD` and `FIELD:AGG` patterns). One `MAPS_TO_NATIVE_FIELD` edge is created per referenced field with `mapping_type="computed"`. Duplicate references within a single formula are deduplicated.

**Expression syntax**:

| Formula Type  | Syntax          | Example                        | Extractable Fields        |
| ------------- | --------------- | ------------------------------ | ------------------------- |
| Row-level     | Bare field refs | `TOTAL_PRICE / QUANTITY`       | `TOTAL_PRICE`, `QUANTITY` |
| Summary-level | `FIELD:AGG`     | `AMOUNT:SUM * PROBABILITY:AVG` | `AMOUNT`, `PROBABILITY`   |

### ReportIRJoin

**Status**: Done. `from_field`/`to_field` populated via `SF_REFERENCES` edges. `mapping_type="join_key"`.

Two-part implementation:

1. **Fetcher** (`fetcher.py`): `_fetch_join_fields()` queries `SF_REFERENCES` edges between objects referenced by a report's columns. Returns `{(from_obj, to_obj): field_api_name}`.

2. **Transformer** (`transformer.py`): `_extract_joins()` collects distinct `object_api_name` values from columns (first seen = primary, rest = joined). For each pair, looks up the FK field from the join_fields dict. Handles both forward lookups (`primary→related`: `from_field=FK, to_field=Id`) and reverse lookups (`related→primary`: `from_field=Id, to_field=FK`).

Cross-stitching creates `MAPS_TO_NATIVE_FIELD` edges from `ReportIRJoin` to `SfReportColumn` when the FK field (e.g., `AccountId` → `ACCOUNT_ID`) exists as a report column.

### ReportIRHighlight

**Status**: Done. Two stitching paths: `HIGHLIGHTS_FORMULA` (formula refs) and `MAPS_TO_NATIVE_FIELD` with `mapping_type="auxiliary"` (regular field refs).

**Finding**: Conditional highlighting in Salesforce can be applied to both regular summarized fields AND custom summary formulas (source: [Salesforce Ben](https://www.salesforceben.com/create-eye-catching-salesforce-reports-with-conditional-formatting/), [Salesforce Help](https://help.salesforce.com/s/articleView?id=analytics.reports_builder_highlighting.htm&language=en_US&type=5)). The `columnName` in `colorRanges` is not limited to formula developer names.

**Two stitching paths**:

| `field_alias` Pattern               | Points To                | Stitch Target          | Edge Type              |
| ----------------------------------- | ------------------------ | ---------------------- | ---------------------- |
| `FORMULA_*` prefix                  | Custom summary formula   | `ReportIRFormula` node | `HIGHLIGHTS_FORMULA`   |
| Regular field name (e.g., `AMOUNT`) | Summarized SObject field | `SfReportColumn`       | `MAPS_TO_NATIVE_FIELD` |

**Metadata API fields**:

| Field                                 | Description                           | Example                        |
| ------------------------------------- | ------------------------------------- | ------------------------------ |
| `columnName`                          | Field alias or formula developer name | `FORMULA_Sum_Amount`, `AMOUNT` |
| `lowColor` / `midColor` / `highColor` | Hex color codes                       | `#FF0000`                      |
| `lowBreakpoint` / `highBreakpoint`    | Threshold values                      | `50000.0`                      |

### ReportIRCrossFilter

**Status**: Done. `mapping_type="auxiliary"`.

**Finding**: Cross filters are not purely object-level. They contain:

1. **`relatedEntityJoinField`** — the field on the related entity used for the cross-object join (stored as `related_field`)
2. **`criteriaItems[].column`** — additional filter conditions on the related entity's fields (stored as JSON in `filter_conditions`)

Both are field API names that create `MAPS_TO_NATIVE_FIELD` edges to `SfReportColumn`.

**Current data**: 0 instances in production graph.

**Metadata API fields**:

| Field                    | Description                         | Example                                                |
| ------------------------ | ----------------------------------- | ------------------------------------------------------ |
| `relatedEntity`          | Related SObject name                | `Contact`                                              |
| `relatedEntityJoinField` | Join field on related entity        | `AccountId`                                            |
| `operation`              | `with` or `without`                 | `without`                                              |
| `criteriaItems`          | Filter conditions on related entity | `[{column: "Email", operator: "notEqual", value: ""}]` |

## Edge Type Summary

| Edge                   | From                  | To                | mapping_type | Status         |
| ---------------------- | --------------------- | ----------------- | ------------ | -------------- |
| `MAPS_TO_NATIVE_FIELD` | `ReportIRField`       | `SfReportColumn`  | `exact`      | Done (Phase 1) |
| `MAPS_TO_NATIVE_FIELD` | `ReportIRGroupBy`     | `SfReportColumn`  | `auxiliary`  | Done           |
| `MAPS_TO_NATIVE_FIELD` | `ReportIRFilter`      | `SfReportColumn`  | `auxiliary`  | Done           |
| `MAPS_TO_NATIVE_FIELD` | `ReportIRBucket`      | `SfReportColumn`  | `auxiliary`  | Done           |
| `MAPS_TO_NATIVE_FIELD` | `ReportIRFormula`     | `SfReportColumn`  | `computed`   | Done           |
| `MAPS_TO_NATIVE_FIELD` | `ReportIRHighlight`   | `SfReportColumn`  | `auxiliary`  | Done           |
| `HIGHLIGHTS_FORMULA`   | `ReportIRHighlight`   | `ReportIRFormula` | -            | Done           |
| `MAPS_TO_NATIVE_FIELD` | `ReportIRCrossFilter` | `SfReportColumn`  | `auxiliary`  | Done           |
| `MAPS_TO_NATIVE_FIELD` | `ReportIRJoin`        | `SfReportColumn`  | `join_key`   | Done           |

## Full Lineage Paths

Once all stitching is complete, the following lineage traversals become possible:

```text
# Direct field reference (GroupBy, Filter, Bucket, Highlight on regular field)
ReportIRGroupBy -[MAPS_TO_NATIVE_FIELD]-> SfReportColumn -[SF_REPORT_COLUMN_USES_FIELD]-> SfField

# Formula → constituent fields
ReportIRFormula -[MAPS_TO_NATIVE_FIELD]-> SfReportColumn -[SF_REPORT_COLUMN_USES_FIELD]-> SfField
                                          (one edge per field in expression)

# Highlight on formula → formula → constituent fields
ReportIRHighlight -[HIGHLIGHTS_FORMULA]-> ReportIRFormula -[MAPS_TO_NATIVE_FIELD]-> SfReportColumn

# Join → FK column → field
ReportIRJoin -[MAPS_TO_NATIVE_FIELD]-> SfReportColumn -[SF_REPORT_COLUMN_USES_FIELD]-> SfField
                                        (mapping_type="join_key")

# Cross filter → related entity fields
ReportIRCrossFilter -[MAPS_TO_NATIVE_FIELD]-> SfReportColumn -[SF_REPORT_COLUMN_USES_FIELD]-> SfField
```

## Files

| File                                                                      | Role                                                                 |
| ------------------------------------------------------------------------- | -------------------------------------------------------------------- |
| `libs/python/core/src/core/models/report.py`                              | Phase 2 node model definitions                                       |
| `libs/python/core/src/core/models/edges.py`                               | `MapsToNativeField.allowed_pairs`                                    |
| `src/lineage/ingest/static_loaders/salesforce/loader.py`                  | Native loader — creates auxiliary `SfReportColumn` nodes             |
| `src/lineage/ingest/static_loaders/reports/salesforce/fetcher.py`         | Graph fetcher — fetches report data + join fields from SF_REFERENCES |
| `src/lineage/ingest/static_loaders/reports/salesforce/transformer.py`     | IR transformer — creates `MAPS_TO_NATIVE_FIELD` edges                |
| `tests/unit/ingest/static_loaders/reports/salesforce/test_transformer.py` | Unit tests for transformer (join extraction + stitching)             |
| `tests/test_salesforce_report_ir.py`                                      | Integration tests for stitching                                      |
| `tests/test_report_models.py`                                             | Edge pair validation tests                                           |
