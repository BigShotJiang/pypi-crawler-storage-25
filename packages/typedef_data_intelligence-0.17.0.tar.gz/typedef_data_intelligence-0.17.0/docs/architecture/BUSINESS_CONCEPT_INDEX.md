# Business Concept Index

The Business Concept Index is a bottom-up ontology extracted from the three
pipeline abstraction primitives (Grain, Behavioral Class, Pipeline Operation).
It answers questions like "what is an Account?", "how do we calculate ARR?",
and "is DAU computed the same way across product domains?"

## Inputs

The concept index builder (`src/lineage/grain/concept_index.py`) takes two
inputs:

1. **Grain traces** (`grain_traces.json`) — output of the grain tracer, which
   contains per-node grain fields, behavioral class, and pipeline operation for
   every node in the lineage DAG.
2. **The lineage graph** (`~/.typedef/graph.db`) — queried at build time for
   semantic metadata (measures, CTE scopes, subject areas, Salesforce objects).

```text
grain_traces.json ──┐
                    ├──→ ConceptIndexBuilder ──→ concept_index.json
lineage graph ──────┘
```

## Build Pipeline

The builder runs 7 steps sequentially:

### Step 1: Extract concepts from grain fields

Every grain field name is parsed to extract a concept:

| Field             | Rule                           | Concept                         |
| ----------------- | ------------------------------ | ------------------------------- |
| `account_id`      | strip `_id`                    | `account`                       |
| `daily_server_id` | strip surrogate prefix + `_id` | `server`                        |
| `id`              | bare id — needs context        | `_generic` (resolved in step 2) |
| `cloud_hostname`  | `_hostname` suffix kept        | `cloud_hostname`                |
| `activity_date`   | temporal — skipped             | `None`                          |
| `account_arr`     | attribute — skipped            | `None`                          |

Temporal fields (`_date`, `_time`, `_timestamp`, `day`, etc.) and attribute
fields (`is_`, `has_`, `count_`, `total_`, etc.) are excluded — they are axes
or measures, not concepts.

### Step 2: Resolve generic concepts

Bare `id` fields are resolved using node context:

- SfObject: concept = object name (e.g., `Opportunity`)
- DbtSource: concept = source name (e.g., `license`)
- CubeCube: concept = cube name
- DbtModel: concept inferred from model name patterns

### Step 3: Build appearances

For each node in the grain traces, map its grain fields to concepts and record
a `ConceptAppearance`:

```json
{
  "model_name": "int_opportunity_ext",
  "model_id": "model.mattermost_analytics.int_opportunity_ext",
  "node_label": "DbtModel",
  "grain_fields": ["opportunity_id", "account_id", "close_date", "..."],
  "behavioral_class": "entity",
  "pipeline_operation": "fanout"
}
```

Concepts with fewer than 2 appearances are filtered out (configurable via
`min_appearances`).

### Step 4: Attach measures

Measures come from `InferredSemanticModel → InferredMeasure` nodes in the
graph. Each measure is scoped to the concept(s) present in the model's grain.

**The OTHER measure problem**: The semantic analyzer classifies ~95% of measures
as `agg_function='OTHER'` because it sees column references (e.g.,
`OPPORTUNITY_EXT.SUM_NEW_AMOUNT`) rather than inline aggregations (e.g.,
`SUM(new_amount)`). The builder resolves these through three strategies, applied
in order:

| Strategy           | How it works                                                                                                                                                | When it fires                                               |
| ------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------- |
| **Upstream BFS**   | Walk upstream models in the grain trace to find the same measure name with a real aggregation function                                                      | Measure was aggregated in a parent model and passed through |
| **CTE scope**      | Query `InferredGroupingScope` nodes for the model's CTE graph; match measure names to CTE-level aggregation expressions (`SUM(...)`, `COUNT(DISTINCT ...)`) | Aggregation happens inside the model's own CTEs             |
| **Name heuristic** | Infer from name prefix: `SUM_` → SUM, `COUNT_` → COUNT, `NUM_` → COUNT, `TOTAL_` → SUM                                                                      | No graph evidence available; non-staging models only        |

Each resolved measure records its `agg_source` to track provenance.

#### CTE scope resolution details

The `InferredGroupingScope` nodes in the graph capture per-CTE aggregation
data: `measures` (SQL expressions like `SUM("T"."COL")`) and `group_by`
(with cross-CTE references like `W_END_DATE.NUM_DIFF_END_DATES`).

Resolution works in two phases:

1. **Indirect**: Check if any upstream CTE's `group_by` references a column
   from another CTE. When the count of references matches the count of measures
   in the upstream CTE, align positionally.
2. **Direct**: Match the model-level measure name against the first source
   column in each CTE measure expression.

### Step 5: Build lifecycles

For each concept, walk the grain trace paths to extract behavioral transitions:

```text
entity → snapshot (spine: int_opportunity_daily_arr)
snapshot → entity (fanout: int_opportunity_ext, rpt_current_customers)
```

### Step 6: Attach report counts

Count Salesforce reports (`SfReport`) that reference each concept's origin
object.

### Step 7: Domain segmentation

Each model is assigned to a business domain based on `InferredSubjectArea`
nodes in the graph. Every `DbtModel` connects to a subject area via
`BELONGS_TO_SUBJECT_AREA`. The subject area **name** is the domain:

```text
DbtModel -[:BELONGS_TO_SUBJECT_AREA]-> InferredSubjectArea { name: "..." }
```

For non-DbtModel nodes, the domain propagates through graph relationships:

| Node type                 | Resolution path                                      |
| ------------------------- | ---------------------------------------------------- |
| DbtSource                 | Inherit from downstream DbtModel via `DEPENDS_ON`    |
| DbtSource (no downstream) | Inherit from sibling source in same dbt source group |
| SfObject                  | Inherit from Salesforce staging models               |
| CubeCube                  | Majority vote from referenced sources/models         |
| CubeView                  | Majority vote from included CubeCubes                |
| LookMLView                | From referenced DbtModel                             |

## Output JSON Schema

The builder produces a JSON file with this structure:

```json
{
  "metadata": {
    "generated_at": "2026-02-25T...",
    "concept_count": 75,
    "total_appearances": 391,
    "total_measures": 303
  },
  "concepts": [
    {
      "name": "opportunity",
      "display_name": "Opportunity",
      "identity_fields": ["opportunity_id", "id"],
      "origin_type": "SfObject",
      "origin_name": "Opportunity",
      "model_count": 8,
      "report_count": 35,
      "cube_view_count": 2,
      "behavioral_classes": ["entity", "snapshot"],
      "lifecycle": [
        {
          "behavioral_class": "entity",
          "pipeline_operation": "source",
          "model_names": ["Opportunity"]
        }
      ],
      "measures": [
        {
          "name": "WON_ARR",
          "agg_function": "SUM",
          "agg_source": "upstream",
          "expr": "OPPORTUNITY_DAILY_ARR\".\"WON_ARR\"",
          "model_name": "int_opportunity_daily_arr",
          "behavioral_class": "snapshot",
          "grain_context": ["account_id", "day", "master_account_sfid"]
        }
      ],
      "domains": {
        "Opportunity and Trial Pipeline Management": [
          "Opportunity",
          "int_opportunity_daily_arr",
          "int_opportunity_ext",
          "stg_salesforce__opportunity"
        ],
        "License and Subscription Management": [
          "rpt_won_opportunities",
          "sv_won_opportunities"
        ]
      },
      "appearances": [
        {
          "model_name": "int_opportunity_daily_arr",
          "model_id": "model.mattermost_analytics.int_opportunity_daily_arr",
          "node_label": "DbtModel",
          "grain_fields": ["account_id", "day", "opportunity_id"],
          "behavioral_class": "snapshot",
          "pipeline_operation": "spine"
        }
      ]
    }
  ]
}
```

### Key fields

| Field                      | Type     | Description                                                                              |
| -------------------------- | -------- | ---------------------------------------------------------------------------------------- |
| `name`                     | string   | Normalized concept name (lowercase, underscored)                                         |
| `identity_fields`          | string[] | All grain field names that reference this concept                                        |
| `origin_type`              | string   | Where the concept originates: `SfObject`, `DbtSource`, or `unknown`                      |
| `behavioral_classes`       | string[] | Behavioral classes observed across the pipeline                                          |
| `lifecycle`                | object[] | Ordered behavioral transitions with model names                                          |
| `measures[].agg_source`    | string   | How the aggregation was resolved: `direct`, `upstream`, `cte_scope`, or `name_heuristic` |
| `measures[].grain_context` | string[] | Other grain fields present at this model (the full grain minus the concept's own field)  |
| `domains`                  | dict     | Subject area name → list of model names in that domain                                   |

## Querying the Index

### Cross-domain metric comparison

The JSON structure supports cross-domain metric analysis through a simple
join between `domains` and `measures`:

1. Invert `domains` to get `model_name → domain`
2. For each measure, look up `measure.model_name` in the inverted dict
3. Group measures by `measure.name` across domains
4. Compare `agg_function` values — different functions = semantic conflict

```python
# Build model → domain lookup
model_to_domain = {}
for domain, models in concept["domains"].items():
    for m in models:
        model_to_domain[m] = domain

# Tag each measure with its domain
for measure in concept["measures"]:
    domain = model_to_domain.get(measure["model_name"])
    # Now group by measure["name"] across domains
```

**Example finding**: `COUNT_KNOWN_FEATURES` is `COUNT_DISTINCT` in the
"Product telemetry" domain (counting distinct events per feature) but `SUM`
in "Server telemetry" (summing per-product counts). Same metric name, different
aggregation semantics — the downstream domain adds up the upstream counts
rather than re-counting distinct values.

### Concept lifecycle analysis

The `lifecycle` array shows how a concept's behavioral class changes as it
moves through the pipeline:

```text
entity → snapshot → entity
```

This tells you that Opportunity starts as a mutable entity, gets date-spined
into periodic snapshots (for ARR reporting), then gets joined back into
entity form for customer-facing reports.

### Domain ownership

The `domains` dict shows which subject areas (business teams) consume each
concept. A concept appearing in multiple domains is a shared entity — changes
to its upstream definition will impact all listed domains.

## CLI Usage

```bash
# Build the concept index
python -m lineage.grain.concept_index \
    --traces grain_traces.json \
    --output concept_index.json

# Describe a specific concept
python -m lineage.grain.concept_index \
    --traces grain_traces.json \
    --describe opportunity
```

## Current Statistics (Mattermost Analytics)

| Metric                             | Value |
| ---------------------------------- | ----- |
| Concepts                           | 75    |
| Total measures                     | 303   |
| Total appearances                  | 391   |
| Domains (subject areas)            | 15    |
| Coverage (appearances with domain) | 100%  |

### Measure resolution breakdown

| Strategy                   | Count | %   |
| -------------------------- | ----- | --- |
| Direct (semantic analyzer) | 77    | 25% |
| Name heuristic             | 152   | 50% |
| Upstream BFS               | 50    | 17% |
| CTE scope                  | 24    | 8%  |

### Top concepts

| Concept     | Models | Measures | Domains |
| ----------- | ------ | -------- | ------- |
| Server      | 55     | 174      | 6       |
| User        | 15     | 47       | 4       |
| Opportunity | 8      | 23       | 2       |
| Account     | 8      | 21       | 2       |
| License     | 19     | 13       | 2       |
