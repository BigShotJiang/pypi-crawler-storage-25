from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel, field_validator


# --- Supporting models ---


class BankAccount(BaseModel):
    account_number: str
    account_name: Optional[str] = None
    bank_name: Optional[str] = None
    bank_code: Optional[str] = None


class Image(BaseModel):
    format: str  # jpg, png, etc.
    data: Optional[str] = None  # base64
    stored_hash: Optional[str] = None


class Coordinate(BaseModel):
    lat: float
    long: float


class IdentifierClass(str, Enum):
    STRING = "string"
    IMAGE = "image"
    BANK_ACCOUNT = "bank_account"
    COORDINATE = "coordinate"
    CUSTOM = "custom"


class CustomIdentifier(BaseModel):
    type: str
    value: Union[str, BankAccount, Image, Coordinate, dict]
    cls: IdentifierClass = IdentifierClass.STRING
    metadata: Optional[Dict[str, str]] = None


# --- Identifiers ---


class Identifiers(BaseModel):
    bvn: Optional[List[str]] = None
    nin: Optional[List[str]] = None
    phone_number: Optional[List[str]] = None
    email_address: Optional[List[str]] = None
    ip_address: Optional[List[str]] = None
    device_id: Optional[List[str]] = None
    bank_account: Optional[List[BankAccount]] = None
    crypto_wallet: Optional[List[str]] = None
    address: Optional[List[str]] = None
    full_name: Optional[List[str]] = None
    drivers_license_number: Optional[List[str]] = None
    passport_number: Optional[List[str]] = None
    business_name: Optional[List[str]] = None
    business_registration_number: Optional[List[str]] = None
    face_photo: Optional[List[Image]] = None
    id_front_photo: Optional[List[Image]] = None
    id_back_photo: Optional[List[Image]] = None
    passport_photo: Optional[List[Image]] = None
    drivers_license_photo: Optional[List[Image]] = None
    gps_location: Optional[List[Coordinate]] = None
    date_of_birth: Optional[List[str]] = None
    nationality: Optional[List[str]] = None
    gender: Optional[List[str]] = None
    custom_identifiers: Optional[List[CustomIdentifier]] = None


# --- Identity ---


class IdentityType(str, Enum):
    customer = "customer"
    guarantor = "guarantor"
    company_director = "company_director"
    company_shareholder = "company_shareholder"
    transaction_sender = "transaction_sender"
    transaction_recipient = "transaction_recipient"
    next_of_kin = "next_of_kin"
    referrer = "referrer"


class Identity(BaseModel):
    identity_type: IdentityType
    identity_id: str
    identifiers: Identifiers
    client_user_id: Optional[str] = None
    relationship: Optional[str] = None
    metadata: Optional[Dict[str, str]] = None


# --- Request / Response models ---


class CreateEventRequest(BaseModel):
    """Local validation before sending to API."""

    client_user_id: str
    event_name: str
    event_timestamp: Optional[datetime] = None
    event_parameters: Optional[Dict[str, Any]] = None
    customer_identifiers: Optional[Identifiers] = None
    other_identities: List[Identity] = []
    metadata: Optional[Dict] = None  # admin only
    generator_type: Optional[str] = None  # admin only


class ScreenAlert(BaseModel):
    rule_configuration_id: str
    rule_name: str
    severity: float
    description: str


class ScreenResponse(BaseModel):
    alerts: List[ScreenAlert] = []


# --- Response-side models (what the API returns) ---


class IdentifierValue(BaseModel):
    """A single identifier as returned by the API in user responses."""
    type: str
    cls: IdentifierClass = IdentifierClass.STRING
    value: Union[str, BankAccount, Image, Coordinate, dict]
    metadata: Optional[Dict[str, str]] = None


class UserIdentity(BaseModel):
    """An identity as returned by the API in user responses."""
    identity_type: str
    identity_id: str
    identifiers: List[IdentifierValue] = []
    client_user_id: Optional[str] = None
    relationship: Optional[str] = None
    metadata: Optional[Dict[str, str]] = None


class UserEvent(BaseModel):
    """An event as returned by the API in user responses."""
    event_id: str
    event_name: str
    event_timestamp: datetime
    event_parameters: Optional[Dict[str, Any]] = None
    account_id: str
    account_user_id: Optional[str] = None
    client_user_id: str
    created_at: datetime
    generator_type: str


class User(BaseModel):
    client_user_id: str
    identities: List[UserIdentity] = []
    events: List[UserEvent] = []
    metadata: Dict[str, str] = {}
    computed: Dict[str, Any] = {}


class Webhook(BaseModel):
    url: str
    message_types: List[str]
    updated_at: datetime


VALID_WEBHOOK_MESSAGE_TYPES = [
    "ACTION",
    "CASE_UPDATE",
    "RAW_DATA",
    "RAW_DATA_FAILED",
    "ALERT",  # deprecated — use ACTION instead
]


class WebhookCreateRequest(BaseModel):
    url: str
    secret: str
    message_types: List[str]

    @field_validator("url")
    @classmethod
    def validate_url(cls, v: str) -> str:
        if not v.startswith("https://"):
            raise ValueError("url must start with https://")
        return v

    @field_validator("message_types")
    @classmethod
    def validate_message_types(cls, v: List[str]) -> List[str]:
        for mt in v:
            if mt not in VALID_WEBHOOK_MESSAGE_TYPES:
                raise ValueError(
                    f"Invalid message type '{mt}'. Must be one of: {VALID_WEBHOOK_MESSAGE_TYPES}"
                )
        return v
