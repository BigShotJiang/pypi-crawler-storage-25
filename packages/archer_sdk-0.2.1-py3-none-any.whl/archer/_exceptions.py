from __future__ import annotations

from typing import Optional

import httpx


class ArcherError(Exception):
    """Base exception for all Archer SDK errors."""


class APIError(ArcherError):
    """Error returned by the Archer API."""

    def __init__(
        self,
        message: str,
        status_code: int,
        code: Optional[str] = None,
    ) -> None:
        self.message = message
        self.status_code = status_code
        self.code = code
        super().__init__(message)

    @classmethod
    def from_response(cls, response: httpx.Response) -> APIError:
        status_code = response.status_code
        message = ""
        code: Optional[str] = None

        try:
            body = response.json()
            message = body.get("detail") or body.get("message") or str(body)
            code = body.get("code")
        except Exception:
            message = response.text or f"HTTP {status_code}"

        if status_code in (401, 403):
            return AuthenticationError(message=message, status_code=status_code, code=code)
        if status_code == 429:
            retry_after: Optional[float] = None
            raw = response.headers.get("retry-after")
            if raw is not None:
                try:
                    retry_after = float(raw)
                except ValueError:
                    pass
            return RateLimitError(message=message, code=code, retry_after=retry_after)

        return APIError(message=message, status_code=status_code, code=code)


class AuthenticationError(APIError):
    """Raised on 401/403 responses."""

    def __init__(self, message: str, status_code: int = 401, code: Optional[str] = None) -> None:
        super().__init__(message=message, status_code=status_code, code=code)


class RateLimitError(APIError):
    """Raised on 429 responses."""

    def __init__(
        self,
        message: str,
        code: Optional[str] = None,
        retry_after: Optional[float] = None,
    ) -> None:
        self.retry_after = retry_after
        super().__init__(message=message, status_code=429, code=code)


class ValidationError(ArcherError):
    """Local validation failed before sending the request."""


class WebhookSignatureError(ArcherError):
    """HMAC signature mismatch on a webhook payload."""
