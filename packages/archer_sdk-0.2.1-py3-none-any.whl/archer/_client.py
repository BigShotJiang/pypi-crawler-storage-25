from __future__ import annotations

import asyncio
import time

import httpx

from ._constants import DEFAULT_BASE_URL
from ._exceptions import APIError, RateLimitError
from .resources.events import AsyncEvents, Events
from .resources.users import AsyncUsers, Users
from .resources.webhooks import AsyncWebhooks, Webhooks


class Client:
    """Synchronous Archer API client."""

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
        max_retries: int = 2,
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._max_retries = max_retries
        self._http_client = httpx.Client(
            base_url=self._base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            timeout=timeout,
        )
        self.events = Events(self)
        self.users = Users(self)
        self.webhooks = Webhooks(self)

    def _request(self, method: str, path: str, **kwargs: object) -> httpx.Response:
        """Make an HTTP request with retry logic and error handling."""
        last_exc: APIError | None = None
        for attempt in range(1 + self._max_retries):
            response = self._http_client.request(method, path, **kwargs)
            if response.status_code < 400:
                return response

            error = APIError.from_response(response)

            retryable = isinstance(error, RateLimitError) or response.status_code >= 500
            if not retryable or attempt >= self._max_retries:
                raise error

            last_exc = error
            if isinstance(error, RateLimitError) and error.retry_after is not None:
                time.sleep(error.retry_after)
            else:
                time.sleep(0.5 * (2 ** attempt))

        raise last_exc  # type: ignore[misc]

    def close(self) -> None:
        self._http_client.close()

    def __enter__(self) -> Client:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


class AsyncClient:
    """Asynchronous Archer API client."""

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
        max_retries: int = 2,
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._max_retries = max_retries
        self._http_client = httpx.AsyncClient(
            base_url=self._base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            timeout=timeout,
        )
        self.events = AsyncEvents(self)
        self.users = AsyncUsers(self)
        self.webhooks = AsyncWebhooks(self)

    async def _request(self, method: str, path: str, **kwargs: object) -> httpx.Response:
        """Make an HTTP request with retry logic and error handling."""
        last_exc: APIError | None = None
        for attempt in range(1 + self._max_retries):
            response = await self._http_client.request(method, path, **kwargs)
            if response.status_code < 400:
                return response

            error = APIError.from_response(response)

            retryable = isinstance(error, RateLimitError) or response.status_code >= 500
            if not retryable or attempt >= self._max_retries:
                raise error

            last_exc = error
            if isinstance(error, RateLimitError) and error.retry_after is not None:
                await asyncio.sleep(error.retry_after)
            else:
                await asyncio.sleep(0.5 * (2 ** attempt))

        raise last_exc  # type: ignore[misc]

    async def close(self) -> None:
        await self._http_client.aclose()

    async def __aenter__(self) -> AsyncClient:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()
