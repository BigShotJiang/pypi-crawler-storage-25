from __future__ import annotations

import hashlib
import hmac
import json
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional, Union

from pydantic import BaseModel

from ._exceptions import WebhookSignatureError
from ._models import VALID_WEBHOOK_MESSAGE_TYPES


# ---------------------------------------------------------------------------
# Signature verification
# ---------------------------------------------------------------------------

def verify_signature(payload: Union[str, bytes], signature: str, secret: str) -> bool:
    """Returns True if signature is valid, False otherwise."""
    if isinstance(payload, str):
        payload = payload.encode("utf-8")
    computed = hmac.new(
        secret.encode("utf-8"),
        payload,
        hashlib.sha256,
    ).hexdigest()
    return hmac.compare_digest(computed, signature)


def validate_signature(payload: Union[str, bytes], signature: str, secret: str) -> None:
    """Raises WebhookSignatureError if signature is invalid."""
    if not verify_signature(payload, signature, secret):
        raise WebhookSignatureError("Invalid webhook signature")


# ---------------------------------------------------------------------------
# Typed webhook event models
# ---------------------------------------------------------------------------

class WebhookAlert(BaseModel):
    """A rule alert included in ACTION and ALERT webhook events."""
    alert_id: str
    rule_id: str
    description: str
    severity: float
    attributes: Dict[str, Any] = {}
    created_at: datetime
    action: Optional[str] = None


class ActionSource(BaseModel):
    """Source of an action (rule trigger, case decision, etc.)."""
    type: str  # "decision", "rule", "case"
    alert: Optional[WebhookAlert] = None
    case_id: Optional[str] = None
    account_user_id: Optional[str] = None
    description: Optional[str] = None


class ActionEvent(BaseModel):
    """Payload for ACTION webhook events — a decision was made on a user."""
    account_id: str
    client_user_id: str
    action: str
    action_parameters: Optional[Dict[str, Any]] = None
    source: ActionSource
    transaction_id: Optional[str] = None
    loan_id: Optional[str] = None
    created_at: datetime


class RawDataDetails(BaseModel):
    """Details of external data retrieved for a user."""
    source: str
    content: Dict[str, Any]
    retrieved_at: datetime


class RawDataEvent(BaseModel):
    """Payload for RAW_DATA webhook events — external data was retrieved."""
    account_id: str
    client_user_id: str
    data: RawDataDetails


class AlertEvent(BaseModel):
    """Payload for ALERT webhook events (deprecated — use ACTION instead)."""
    account_id: str
    client_user_id: str
    alert: WebhookAlert
    user_account_id: Optional[str] = None
    transaction_id: Optional[str] = None
    loan_id: Optional[str] = None


class WebhookEvent(BaseModel):
    """A parsed webhook event envelope."""
    id: str
    type: str
    created_at: datetime
    payload: Dict[str, Any]


# Map message types to their typed payload models
_PAYLOAD_MODELS: Dict[str, type] = {
    "ACTION": ActionEvent,
    "RAW_DATA": RawDataEvent,
    "ALERT": AlertEvent,
}


# ---------------------------------------------------------------------------
# Webhook handler
# ---------------------------------------------------------------------------

class WebhookHandler:
    """
    Validates, parses, and routes incoming webhook events.

    Usage:
        handler = WebhookHandler(secret="whsec_...")

        @handler.on("ACTION")
        def handle_action(event: ActionEvent):
            print(f"Action {event.action} on user {event.client_user_id}")

        @handler.on("RAW_DATA")
        def handle_raw_data(event: RawDataEvent):
            print(f"Got {event.data.source} data for {event.client_user_id}")

        # In your web framework's webhook endpoint:
        handler.process(request_body, request.headers["Archer-Signature"])
    """

    def __init__(self, secret: str) -> None:
        self._secret = secret
        self._handlers: Dict[str, Callable] = {}

    def on(self, message_type: str) -> Callable:
        """Register a handler for a webhook message type.

        Args:
            message_type: One of ACTION, CASE_UPDATE, RAW_DATA, RAW_DATA_FAILED, ALERT

        Returns:
            Decorator that registers the handler function.
        """
        if message_type not in VALID_WEBHOOK_MESSAGE_TYPES:
            raise ValueError(
                f"Invalid message type '{message_type}'. "
                f"Must be one of: {VALID_WEBHOOK_MESSAGE_TYPES}"
            )

        def decorator(fn: Callable) -> Callable:
            self._handlers[message_type] = fn
            return fn

        return decorator

    def process(self, payload: Union[str, bytes], signature: str) -> Any:
        """Validate signature, parse the event, and call the registered handler.

        Args:
            payload: Raw request body (str or bytes)
            signature: Value of the Archer-Signature header

        Returns:
            Whatever the handler function returns, or None if no handler is registered.

        Raises:
            WebhookSignatureError: If the signature is invalid.
            ValueError: If the payload cannot be parsed.
        """
        validate_signature(payload, signature, self._secret)

        if isinstance(payload, bytes):
            payload = payload.decode("utf-8")

        data = json.loads(payload)
        event = WebhookEvent.model_validate(data)

        handler = self._handlers.get(event.type)
        if handler is None:
            return None

        # Parse the payload into the typed model if available
        model = _PAYLOAD_MODELS.get(event.type)
        if model is not None:
            typed_payload = model.model_validate(event.payload)
            return handler(typed_payload)

        return handler(event.payload)
