from __future__ import annotations

DEFAULT_BASE_URL = "https://api.eu.archerprotect.com"
API_VERSION = "v3"

# API paths
EVENTS_CREATE_PATH = f"/api/{API_VERSION}/user/event/create"
EVENTS_SCREEN_PATH = f"/api/{API_VERSION}/user/event/screen"
USERS_GET_PATH = f"/api/{API_VERSION}/user/get"
WEBHOOKS_PATH = f"/api/{API_VERSION}/webhook"
