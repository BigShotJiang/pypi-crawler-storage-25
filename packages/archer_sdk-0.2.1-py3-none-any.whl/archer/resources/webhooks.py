from __future__ import annotations

from typing import TYPE_CHECKING, List

from pydantic import ValidationError as PydanticValidationError

from .._constants import WEBHOOKS_PATH
from .._exceptions import ValidationError
from .._models import Webhook, WebhookCreateRequest

if TYPE_CHECKING:
    from .._client import AsyncClient, Client


class Webhooks:
    def __init__(self, client: Client) -> None:
        self._client = client

    def get(self) -> Webhook:
        """Get current webhook configuration."""
        response = self._client._request("GET", WEBHOOKS_PATH)
        return Webhook.model_validate(response.json())

    def create(self, url: str, secret: str, message_types: List[str]) -> Webhook:
        """Create or update webhook."""
        try:
            req = WebhookCreateRequest(
                url=url, secret=secret, message_types=message_types
            )
        except PydanticValidationError as exc:
            raise ValidationError(str(exc)) from exc
        response = self._client._request(
            "POST", WEBHOOKS_PATH, json=req.model_dump()
        )
        return Webhook.model_validate(response.json())

    def delete(self) -> None:
        """Delete webhook."""
        self._client._request("DELETE", WEBHOOKS_PATH)


class AsyncWebhooks:
    def __init__(self, client: AsyncClient) -> None:
        self._client = client

    async def get(self) -> Webhook:
        """Get current webhook configuration."""
        response = await self._client._request("GET", WEBHOOKS_PATH)
        return Webhook.model_validate(response.json())

    async def create(self, url: str, secret: str, message_types: List[str]) -> Webhook:
        """Create or update webhook."""
        try:
            req = WebhookCreateRequest(
                url=url, secret=secret, message_types=message_types
            )
        except PydanticValidationError as exc:
            raise ValidationError(str(exc)) from exc
        response = await self._client._request(
            "POST", WEBHOOKS_PATH, json=req.model_dump()
        )
        return Webhook.model_validate(response.json())

    async def delete(self) -> None:
        """Delete webhook."""
        await self._client._request("DELETE", WEBHOOKS_PATH)
