from __future__ import annotations

from typing import TYPE_CHECKING

from .._constants import USERS_GET_PATH
from .._models import User

if TYPE_CHECKING:
    from .._client import AsyncClient, Client


class Users:
    def __init__(self, client: Client) -> None:
        self._client = client

    def get(self, client_user_id: str) -> User:
        """Get user details."""
        response = self._client._request(
            "POST", USERS_GET_PATH, json={"client_user_id": client_user_id}
        )
        return User.model_validate(response.json()["user"])


class AsyncUsers:
    def __init__(self, client: AsyncClient) -> None:
        self._client = client

    async def get(self, client_user_id: str) -> User:
        """Get user details."""
        response = await self._client._request(
            "POST", USERS_GET_PATH, json={"client_user_id": client_user_id}
        )
        return User.model_validate(response.json()["user"])
