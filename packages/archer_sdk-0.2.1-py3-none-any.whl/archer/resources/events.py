from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional

from pydantic import ValidationError as PydanticValidationError

from .._constants import EVENTS_CREATE_PATH, EVENTS_SCREEN_PATH
from .._exceptions import ValidationError
from .._models import CreateEventRequest, Identity, Identifiers, ScreenResponse

if TYPE_CHECKING:
    from .._client import AsyncClient, Client


class Events:
    def __init__(self, client: Client) -> None:
        self._client = client

    def _build_body(
        self,
        client_user_id: str,
        event_name: str,
        *,
        event_timestamp: Optional[str] = None,
        event_parameters: Optional[Dict[str, Any]] = None,
        customer_identifiers: Optional[Identifiers] = None,
        other_identities: Optional[List[Identity]] = None,
        metadata: Optional[Dict] = None,
        generator_type: Optional[str] = None,
    ) -> dict:
        try:
            req = CreateEventRequest(
                client_user_id=client_user_id,
                event_name=event_name,
                event_timestamp=event_timestamp,
                event_parameters=event_parameters,
                customer_identifiers=customer_identifiers,
                other_identities=other_identities or [],
                metadata=metadata,
                generator_type=generator_type,
            )
        except PydanticValidationError as exc:
            raise ValidationError(str(exc)) from exc
        return req.model_dump(exclude_none=True, mode="json")

    def create(
        self,
        client_user_id: str,
        event_name: str,
        *,
        event_timestamp: Optional[str] = None,
        event_parameters: Optional[Dict[str, Any]] = None,
        customer_identifiers: Optional[Identifiers] = None,
        other_identities: Optional[List[Identity]] = None,
        metadata: Optional[Dict] = None,
        generator_type: Optional[str] = None,
    ) -> None:
        """Create an event (async processing, returns immediately)."""
        body = self._build_body(
            client_user_id,
            event_name,
            event_timestamp=event_timestamp,
            event_parameters=event_parameters,
            customer_identifiers=customer_identifiers,
            other_identities=other_identities,
            metadata=metadata,
            generator_type=generator_type,
        )
        self._client._request("POST", EVENTS_CREATE_PATH, json=body)

    def screen(
        self,
        client_user_id: str,
        event_name: str,
        *,
        event_timestamp: Optional[str] = None,
        event_parameters: Optional[Dict[str, Any]] = None,
        customer_identifiers: Optional[Identifiers] = None,
        other_identities: Optional[List[Identity]] = None,
        metadata: Optional[Dict] = None,
        generator_type: Optional[str] = None,
    ) -> ScreenResponse:
        """Screen an event synchronously -- returns alerts."""
        body = self._build_body(
            client_user_id,
            event_name,
            event_timestamp=event_timestamp,
            event_parameters=event_parameters,
            customer_identifiers=customer_identifiers,
            other_identities=other_identities,
            metadata=metadata,
            generator_type=generator_type,
        )
        response = self._client._request("POST", EVENTS_SCREEN_PATH, json=body)
        return ScreenResponse.model_validate(response.json())


class AsyncEvents:
    def __init__(self, client: AsyncClient) -> None:
        self._client = client

    def _build_body(
        self,
        client_user_id: str,
        event_name: str,
        *,
        event_timestamp: Optional[str] = None,
        event_parameters: Optional[Dict[str, Any]] = None,
        customer_identifiers: Optional[Identifiers] = None,
        other_identities: Optional[List[Identity]] = None,
        metadata: Optional[Dict] = None,
        generator_type: Optional[str] = None,
    ) -> dict:
        try:
            req = CreateEventRequest(
                client_user_id=client_user_id,
                event_name=event_name,
                event_timestamp=event_timestamp,
                event_parameters=event_parameters,
                customer_identifiers=customer_identifiers,
                other_identities=other_identities or [],
                metadata=metadata,
                generator_type=generator_type,
            )
        except PydanticValidationError as exc:
            raise ValidationError(str(exc)) from exc
        return req.model_dump(exclude_none=True, mode="json")

    async def create(
        self,
        client_user_id: str,
        event_name: str,
        *,
        event_timestamp: Optional[str] = None,
        event_parameters: Optional[Dict[str, Any]] = None,
        customer_identifiers: Optional[Identifiers] = None,
        other_identities: Optional[List[Identity]] = None,
        metadata: Optional[Dict] = None,
        generator_type: Optional[str] = None,
    ) -> None:
        """Create an event (async processing, returns immediately)."""
        body = self._build_body(
            client_user_id,
            event_name,
            event_timestamp=event_timestamp,
            event_parameters=event_parameters,
            customer_identifiers=customer_identifiers,
            other_identities=other_identities,
            metadata=metadata,
            generator_type=generator_type,
        )
        await self._client._request("POST", EVENTS_CREATE_PATH, json=body)

    async def screen(
        self,
        client_user_id: str,
        event_name: str,
        *,
        event_timestamp: Optional[str] = None,
        event_parameters: Optional[Dict[str, Any]] = None,
        customer_identifiers: Optional[Identifiers] = None,
        other_identities: Optional[List[Identity]] = None,
        metadata: Optional[Dict] = None,
        generator_type: Optional[str] = None,
    ) -> ScreenResponse:
        """Screen an event synchronously -- returns alerts."""
        body = self._build_body(
            client_user_id,
            event_name,
            event_timestamp=event_timestamp,
            event_parameters=event_parameters,
            customer_identifiers=customer_identifiers,
            other_identities=other_identities,
            metadata=metadata,
            generator_type=generator_type,
        )
        response = await self._client._request("POST", EVENTS_SCREEN_PATH, json=body)
        return ScreenResponse.model_validate(response.json())
