"""
Switch游戏折扣与上新查询 MCP Server (v3.2)

核心改进：
1. 智能关键词匹配：中文/英文/日文自动映射，用户说"暗黑2"也能搜到"Diablo II Resurrected"
2. 两步查价：先模糊搜找正确游戏名 → 再用正确名精查各区服价格
3. 双数据源：eshop-prices.com（快）+ Nintendo官方API（兜底，国内直连）
"""

import json
import urllib.request
import urllib.parse
import re
import os
import time as _time
from fastmcp import FastMCP

os.environ["FASTMCP_LOG_LEVEL"] = "ERROR"
mcp = FastMCP("switch-game-mcp")

UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
TIMEOUT = 8

# ══════════════════════════════════════
#  中文→英文 游戏关键词映射表
#  用户说暗黑2→我们搜Diablo 2
# ══════════════════════════════════════

CN_TO_EN_KEYWORD = {
    # 暗黑破坏神
    "暗黑": "Diablo", "暗黑2": "Diablo 2", "暗黑3": "Diablo 3", "暗黑4": "Diablo 4",
    # 塞尔达
    "塞尔达": "Zelda", "旷野之息": "Breath of the Wild", "王国之泪": "Tears of the Kingdom",
    # 马力欧/马里奥
    "马力欧": "Mario", "马里奥": "Mario", "马车": "Mario Kart",
    "奥德赛": "Mario Odyssey", "马造": "Mario Maker",
    # 宝可梦
    "宝可梦": "Pokemon", "口袋妖怪": "Pokemon", "宠物小精灵": "Pokemon",
    # 怪物猎人
    "怪物猎人": "Monster Hunter", "怪猎": "Monster Hunter",
    # 异度神剑
    "异度神剑": "Xenoblade", "异度之刃": "Xenoblade",
    # 女神异闻录
    "女神异闻录": "Persona", "P5": "Persona 5", "P4G": "Persona 4 Golden",
    "P5R": "Persona 5 Royal",
    # 最终幻想
    "最终幻想": "Final Fantasy", "FF": "Final Fantasy",
    # 勇者斗恶龙
    "勇者斗恶龙": "Dragon Quest", "DQ": "Dragon Quest",
    # 火焰纹章
    "火焰纹章": "Fire Emblem", "火纹": "Fire Emblem",
    # 动物森友会
    "动物森友会": "Animal Crossing", "动森": "Animal Crossing",
    # 喷射战士
    "喷射战士": "Splatoon", "斯普拉遁": "Splatoon",
    # 星之卡比
    "星之卡比": "Kirby", "卡比": "Kirby",
    # 密特罗德
    "密特罗德": "Metroid", "银河战士": "Metroid",
    # 皮克敏
    "皮克敏": "Pikmin",
    # 猎天使魔女
    "猎天使魔女": "Bayonetta", "魔女": "Bayonetta",
    # 任天堂明星大乱斗
    "大乱斗": "Super Smash Bros", "明星大乱斗": "Super Smash Bros",
    # 其他热门
    "巫师": "Witcher", "上古卷轴": "Skyrim",
    "生化危机": "Resident Evil", "鬼泣": "Devil May Cry",
    "逆转裁判": "Ace Attorney", "弹丸论破": "Danganronpa",
    "空洞骑士": "Hollow Knight", "星露谷": "Stardew Valley",
    "哈迪斯": "Hades", "死亡细胞": "Dead Cells",
    "八方旅人": "Octopath Traveler", "勇气默示录": "Bravely Default",
    "十三机兵": "13 Sentinels", "尼尔": "Nier",
    "异界锁链": "Astral Chain",
}

# 日文搜索用映射
JP_KEYWORD_MAP = {
    "persona": "ペルソナ", "zelda": "ゼルダ", "mario": "マリオ",
    "splatoon": "スプラトゥーン", "xenoblade": "ゼノブレイド",
    "pokemon": "ポケモン", "monster hunter": "モンスターハンター",
    "dragon quest": "ドラゴンクエスト", "final fantasy": "ファイナルファンタジー",
    "fire emblem": "ファイアーエムブレム", "animal crossing": "どうぶつの森",
    "kirby": "星のカービィ", "metroid": "メトロイド",
    "pikmin": "ピクミン", "bayonetta": "ベヨネッタ",
    "diablo": "ディアブロ", "resident evil": "バイオハザード",
    "devil may cry": "デビルメイクライ",
}


def _resolve_keyword(kw: str) -> list:
    """把用户输入的中文关键词转成多个候选英文词"""
    kw = kw.strip()
    candidates = [kw]  # 原始关键词排第一位

    # 精确匹配中文映射
    for cn, en in CN_TO_EN_KEYWORD.items():
        if cn in kw:
            candidates.append(en)
    return candidates


# ══════════════════════════════════════
#  数据源1: eshop-prices.com
# ══════════════════════════════════════

def _fetch_eshop(keyword: str, limit: int = 15):
    q = urllib.parse.quote(keyword)
    url = f"https://eshop-prices.com/games?q={q}&currency=CNY"
    req = urllib.request.Request(url, headers=UA)
    resp = urllib.request.urlopen(req, timeout=TIMEOUT)
    html = resp.read().decode("utf-8", errors="replace")

    pattern = r'<a class="games-list-item"[^>]*href="(/games/\d+[^"]*)"[^>]*>(.*?)</a>'
    matches = re.findall(pattern, html, re.DOTALL)

    games = []
    for href, content in matches:
        alt = re.search(r'alt="([^"]+)"', content)
        title = alt.group(1) if alt else "?"
        prices = re.findall(r'¥([0-9,]+(?:\.\d{2})?)', content)
        disc = re.findall(r'(-\d+%)', content)
        small = re.search(r'<small[^>]*>(.*?)</small>', content)
        desc = re.sub(r'<[^>]+>', '', small.group(1)).strip() if small else ""

        games.append({
            "title": title,
            "original_price": f"¥{prices[0]}" if len(prices) >= 1 else "",
            "sale_price": f"¥{prices[1]}" if len(prices) >= 2 and prices[1] != prices[0] else "",
            "discount": disc[0] if disc else "",
            "description": desc[:120] if desc else "",
        })
        if len(games) >= limit:
            break
    return games


def _fetch_eshop_discounts(limit: int = 15):
    url = "https://eshop-prices.com/discounts?currency=CNY"
    req = urllib.request.Request(url, headers=UA)
    resp = urllib.request.urlopen(req, timeout=TIMEOUT)
    return _parse_eshop_html(resp.read().decode("utf-8", errors="replace"), limit)


def _fetch_eshop_new(limit: int = 10):
    url = "https://eshop-prices.com/new-games?currency=CNY"
    req = urllib.request.Request(url, headers=UA)
    resp = urllib.request.urlopen(req, timeout=TIMEOUT)
    return _parse_eshop_html(resp.read().decode("utf-8", errors="replace"), limit)


def _parse_eshop_html(html, limit):
    pattern = r'<a class="games-list-item"[^>]*href="(/games/\d+[^"]*)"[^>]*>(.*?)</a>'
    matches = re.findall(pattern, html, re.DOTALL)
    games = []
    for href, content in matches:
        alt = re.search(r'alt="([^"]+)"', content)
        title = alt.group(1) if alt else "?"
        prices = re.findall(r'¥([0-9,]+(?:\.\d{2})?)', content)
        disc = re.findall(r'(-\d+%)', content)
        games.append({
            "title": title,
            "original_price": f"¥{prices[0]}" if prices else "",
            "sale_price": f"¥{prices[1]}" if len(prices) > 1 and prices[0] != prices[1] else "",
            "discount": disc[0] if disc else "",
        })
        if len(games) >= limit:
            break
    return games


# ══════════════════════════════════════
#  数据源2: Nintendo 官方 API
# ══════════════════════════════════════

def _search_nintendo(keyword: str, limit: int = 10):
    q = urllib.parse.quote(keyword)
    url = f"https://search.nintendo.jp/nintendo_soft/search.json?q={q}&limit={limit}&locale=ja"
    req = urllib.request.Request(url, headers=UA)
    resp = urllib.request.urlopen(req, timeout=TIMEOUT)
    d = json.loads(resp.read().decode("utf-8", errors="replace"))
    items = d.get("result", {}).get("items", [])
    games = []
    for item in items:
        tid = item.get("id", "")
        title = item.get("title", "?")
        text = item.get("text", "")
        if not tid.isdigit() and not tid.startswith("7"):
            continue
        games.append({"title_id": tid, "title": title, "description": text[:100] if text else ""})
    return games


def _search_nintendo_smart(keyword: str, limit: int = 10):
    """智能搜索：先直搜，搜不到换日文映射再试"""
    games = _search_nintendo(keyword, limit)
    if games:
        return games
    kw_lower = keyword.lower()
    for key, jp in JP_KEYWORD_MAP.items():
        if key in kw_lower:
            games = _search_nintendo(jp, limit)
            if games:
                return games
    return []


def _nintendo_price(title_id: str, country: str = "JP"):
    url = f"https://api.ec.nintendo.com/v1/price?country={country}&lang=ja&ids={title_id}"
    req = urllib.request.Request(url, headers=UA)
    resp = urllib.request.urlopen(req, timeout=TIMEOUT)
    d = json.loads(resp.read())
    prices = d.get("prices", [])
    if not prices:
        return None
    p = prices[0]
    reg = p.get("regular_price", {})
    disc = p.get("discount_price", {})
    result = {"status": p.get("sales_status", ""),
              "regular_price": f"¥{int(reg['raw_value']):,}" if reg.get('raw_value') else ""}
    if disc and disc.get("raw_value"):
        result["discount_price"] = f"¥{int(disc['raw_value']):,}"
        if reg.get("raw_value"):
            rv, dv = int(reg["raw_value"]), int(disc["raw_value"])
            result["discount_pct"] = f"-{int((1 - dv / rv) * 100)}%"
    return result


def _nintendo_new_games(limit: int = 10):
    url = f"https://search.nintendo.jp/nintendo_soft/search.json?q=&sort=date&limit={limit}&locale=ja"
    req = urllib.request.Request(url, headers=UA)
    resp = urllib.request.urlopen(req, timeout=TIMEOUT)
    d = json.loads(resp.read().decode("utf-8", errors="replace"))
    items = d.get("result", {}).get("items", [])
    return [{"title_id": i.get("id", ""), "title": i.get("title", "?"), "date": i.get("pdate", "")}
            for i in items if i.get("id", "").isdigit() or i["id"].startswith("7")][:limit]


# ══════════════════════════════════════
#  核心：智能搜索 + 两步查价
# ══════════════════════════════════════

def _smart_search(keyword: str, limit: int = 10):
    """
    智能搜索：用户说啥都尽量找到正确的游戏名
    1. 解析中文关键词 → 生成候选英文词
    2. 逐个候选词搜eshop-prices.com
    3. 不行就Nintendo官方API兜底
    """
    candidates = _resolve_keyword(keyword)

    # 挨个候选词搜eshop-prices.com
    for kw in candidates:
        try:
            games = _fetch_eshop(kw, limit)
            if games:
                return games, "eshop"
        except Exception:
            continue
        _time.sleep(0.3)

    # 兜底：Nintendo官方
    for kw in candidates:
        try:
            games = _search_nintendo_smart(kw, limit)
            if games:
                return games, "nintendo"
        except Exception:
            continue
        _time.sleep(0.3)

    return [], ""


# ══════════════════════════════════════
#  格式化
# ══════════════════════════════════════

def _fmt_eshop(games):
    lines = []
    for g in games:
        lines.append(f"📌 {g['title']}")
        if g["original_price"]:
            line = f"   原价: {g['original_price']}"
            if g["sale_price"] and g["sale_price"] != g["original_price"]:
                line += f" → 折后: {g['sale_price']} {g['discount']}"
            lines.append(line)
        if g.get("description"):
            lines.append(f"   {g['description']}")
        lines.append("")
    return "\n".join(lines)


def _fmt_nintendo(games):
    lines = []
    for g in games:
        lines.append(f"📌 {g['title']}")
        if g.get("description"):
            lines.append(f"   {g['description']}")
        try:
            price = _nintendo_price(g["title_id"])
            if price and price["regular_price"]:
                line = f"   原价: {price['regular_price']}"
                if price.get("discount_price"):
                    line += f" → 折后: {price['discount_price']} {price.get('discount_pct', '')}"
                lines.append(line)
        except Exception:
            pass
        lines.append("")
    return "\n".join(lines)


# ══════════════════════════════════════
#  MCP 工具
# ══════════════════════════════════════

@mcp.tool()
def search_switch_games(keyword: str, limit: int = 10) -> str:
    """搜Switch游戏，返回名字、价格、有没有打折。
    支持中文/英文/日文，说"暗黑2""塞尔达"都能搜到。

    Args:
        keyword: 搜啥（中文英文都行，如"暗黑2""Persona""ゼルダ"）
        limit: 返回几条，默认10
    """
    games, source = _smart_search(keyword, limit)
    if not games:
        return f"没找到\"{keyword}\"相关的Switch游戏，换个关键词试试？"

    output = f"🎮 搜\"{keyword}\"的结果：\n\n"
    output += _fmt_eshop(games) if source == "eshop" else _fmt_nintendo(games)
    return output


@mcp.tool()
def get_game_price_info(game_name: str) -> str:
    """查某个游戏的具体价格，各区服对比。
    两步走：先搜关键词找到正确游戏名 → 再精查各区服价格。

    Args:
        game_name: 游戏名字，中文英文都行（如"暗黑2""P4G""塞尔达传说"）
    """
    # 🔥 关键改进：先搜到正确的游戏名
    games, source = _smart_search(game_name, 3)
    if not games:
        return f"没找到\"{game_name}\"的信息，换个名字试试？"

    g = games[0]
    correct_name = g.get("title", game_name)
    output = f"📊 \"{correct_name}\"\n\n"

    # eshop-prices.com 来源：已有CNY价格直接展示
    if source == "eshop":
        if g["original_price"]:
            output += f"💰 CNY价格: {g['original_price']}"
            if g["sale_price"] and g["sale_price"] != g["original_price"]:
                output += f" → {g['sale_price']} {g['discount']}"
            output += "\n\n"
        output += "数据来源: Nintendo eShop（eshop-prices.com）"
        return output

    # Nintendo官方来源：查各区服价格
    output += "💰 各区服价格：\n"
    for cc, label, emoji in [("JP", "日服", "🇯🇵"), ("US", "美服", "🇺🇸"), ("HK", "港服", "🇭🇰")]:
        try:
            price = _nintendo_price(g["title_id"], cc)
            if price and price["regular_price"]:
                line = f"  {emoji} {label}: {price['regular_price']}"
                if price.get("discount_price"):
                    line += f" → {price['discount_price']} {price.get('discount_pct', '')}"
                output += line + "\n"
            else:
                output += f"  {emoji} {label}: 暂无数据\n"
        except Exception:
            output += f"  {emoji} {label}: 暂无数据\n"
    output += "\n数据来源: Nintendo eShop官方"
    return output


@mcp.tool()
def get_switch_discounts(page_size: int = 15) -> str:
    """看看Switch现在有啥游戏在打折"""
    try:
        games = _fetch_eshop_discounts(page_size)
        if games:
            output = "🔥 Switch游戏打折清单\n\n"
            for i, g in enumerate(games, 1):
                output += f"{i}. {g['title']}\n"
                if g["original_price"] and g["sale_price"]:
                    output += f"   原价: {g['original_price']} → {g['sale_price']} {g['discount']}\n"
                output += "\n"
            return output
    except Exception:
        pass

    popular = ["ペルソナ", "ゼルダ", "マリオ", "ディアブロ", "モンスターハンター"]
    discounts = []
    for kw in popular:
        try:
            for g in _search_nintendo(kw, 3):
                price = _nintendo_price(g["title_id"])
                if price and price.get("discount_price"):
                    discounts.append({
                        "title": g["title"],
                        "regular_price": price["regular_price"],
                        "discount_price": price["discount_price"],
                        "discount_pct": price.get("discount_pct", ""),
                    })
        except Exception:
            continue
        if len(discounts) >= page_size:
            break

    if discounts:
        output = "🔥 Switch游戏打折清单（Nintendo官方数据）\n\n"
        for i, d in enumerate(discounts[:page_size], 1):
            output += f"{i}. {d['title']}\n"
            output += f"   {d['regular_price']} → {d['discount_price']} {d['discount_pct']}\n\n"
        return output
    return "今天好像没啥打折的，用 search_switch_games 搜具体游戏看看吧 🎮"


@mcp.tool()
def get_new_switch_games(page_size: int = 10) -> str:
    """最近有啥新出的Switch游戏"""
    try:
        games = _fetch_eshop_new(page_size)
        if games:
            output = "🆕 最近上架的Switch游戏\n\n"
            for i, g in enumerate(games, 1):
                output += f"{i}. {g['title']}\n"
                if g.get("original_price") and g["original_price"] != "¥":
                    output += f"   价格: {g['original_price']}\n"
                output += "\n"
            return output
    except Exception:
        pass

    try:
        games = _nintendo_new_games(page_size)
        if games:
            output = "🆕 最近上架的Switch游戏（Nintendo官方数据）\n\n"
            for i, g in enumerate(games, 1):
                output += f"{i}. {g['title']}\n"
                if g.get("date"):
                    output += f"   上线: {g['date']}\n"
                try:
                    price = _nintendo_price(g["title_id"])
                    if price and price["regular_price"]:
                        line = f"   价格: {price['regular_price']}"
                        if price.get("discount_price"):
                            line += f" → {price['discount_price']} {price.get('discount_pct', '')}"
                        output += line + "\n"
                except Exception:
                    pass
                output += "\n"
            return output
    except Exception:
        pass
    return "新游戏功能暂时不可用 🎮"


def main():
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
