// ── Imports ───────────────────────────────────────────────────────────────────

use std::{
    path::Path,
    sync::Arc,
    time::{Duration, Instant},
};

use sedes::lut::{DeviceType, LutConfig, SweepRange};
use sedes::pool::WorkerPool;
use sedes::protocol::{SimulationRequest, SimulationResponse};

// ─────────────────────────────────────────────────────────────────────────────
// Entry point
// ─────────────────────────────────────────────────────────────────────────────

fn main() {
    let args: Vec<String> = std::env::args().collect();

    if args.iter().any(|a| a == "--worker") {
        if let Err(e) = sedes::worker::run_worker() {
            eprintln!("[worker] fatal error: {e}");
            std::process::exit(1);
        }
    } else {
        tokio::runtime::Builder::new_multi_thread()
            .enable_all()
            .build()
            .expect("failed to build tokio runtime")
            .block_on(async {
                if args.iter().any(|a| a == "--lut") {
                    run_lut(args).await;
                } else {
                    run_stress_test(args).await;
                }
            });
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Stress test configuration
// ─────────────────────────────────────────────────────────────────────────────

struct Config {
    /// Number of worker processes to keep alive.
    workers: usize,
    /// Total number of simulations to submit.
    sims: usize,
    /// Maximum wall-clock time allowed per individual simulation.
    timeout: Duration,
}

impl Config {
    fn from_args(args: &[String]) -> Self {
        let mut workers = num_cpus();
        let mut sims = 100;
        let mut timeout_secs: u64 = 60;

        let mut i = 1;
        while i < args.len() {
            match args[i].as_str() {
                "--workers" => {
                    i += 1;
                    workers = args
                        .get(i)
                        .and_then(|s| s.parse().ok())
                        .unwrap_or(workers)
                        .max(1);
                }
                "--sims" => {
                    i += 1;
                    sims = args
                        .get(i)
                        .and_then(|s| s.parse().ok())
                        .unwrap_or(sims)
                        .max(1);
                }
                "--timeout" => {
                    i += 1;
                    timeout_secs = args
                        .get(i)
                        .and_then(|s| s.parse().ok())
                        .unwrap_or(timeout_secs);
                }
                "--help" | "-h" => {
                    println!("Usage: ngspice-rust [--workers N] [--sims N] [--timeout secs]");
                    println!("  --workers N    worker processes (default: CPU count)");
                    println!("  --sims N       total simulations to run (default: 100)");
                    println!("  --timeout secs per-simulation timeout (default: 60)");
                    std::process::exit(0);
                }
                other if other.starts_with("--") => {
                    eprintln!("unknown argument: {other}  (try --help)");
                    std::process::exit(1);
                }
                _ => {}
            }
            i += 1;
        }

        Self {
            workers,
            sims,
            timeout: Duration::from_secs(timeout_secs),
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Netlist library — varied circuit topologies
// ─────────────────────────────────────────────────────────────────────────────

/// All circuit types in the stress suite.
/// Each variant exercises a different ngspice analysis mode and circuit topology.
#[derive(Clone, Copy)]
enum CircuitKind {
    /// DC operating point — instant, exercises `.op` path.
    VoltageDividerOp,
    /// Transient — RC low-pass, parametric R and C values.
    RcLowPassTran,
    /// Transient — RLC series resonator, exercises stiff solver.
    RlcSeriesTran,
    /// Transient — Two-stage RC ladder, more nodes.
    RcLadderTran,
    /// Transient — Diode half-wave rectifier (non-linear device).
    DiodeRectifierTran,
    /// DC sweep — resistor network over a voltage range.
    ResistorNetworkDcSweep,
}

impl CircuitKind {
    /// Cycle through all kinds so the suite gets even coverage.
    fn from_index(i: usize) -> Self {
        match i % 6 {
            0 => Self::VoltageDividerOp,
            1 => Self::RcLowPassTran,
            2 => Self::RlcSeriesTran,
            3 => Self::RcLadderTran,
            4 => Self::DiodeRectifierTran,
            _ => Self::ResistorNetworkDcSweep,
        }
    }

    fn name(self) -> &'static str {
        match self {
            Self::VoltageDividerOp => "voltage-divider-op",
            Self::RcLowPassTran => "rc-lowpass-tran",
            Self::RlcSeriesTran => "rlc-series-tran",
            Self::RcLadderTran => "rc-ladder-tran",
            Self::DiodeRectifierTran => "diode-rectifier-tran",
            Self::ResistorNetworkDcSweep => "resistor-net-dc-sweep",
        }
    }
}

/// Generate a simulation request for the given circuit kind and index.
///
/// `idx` is used to vary component values so each simulation is distinct
/// and we're not just replaying cached state.
fn make_request(id: usize, kind: CircuitKind) -> SimulationRequest {
    // Use `idx` to produce a spread of component values.
    // Simple deterministic variation: scale a base value by a factor 1..10.
    let scale = ((id % 9) + 1) as f64; // 1.0 .. 9.0

    let netlist = match kind {
        // ── DC operating point ─────────────────────────────────────────────
        // Instant solve, no time-stepping.  Good for measuring base overhead.
        CircuitKind::VoltageDividerOp => format!(
            "voltage divider op {id}\n\
             v1 1 0 dc {vdd:.2}\n\
             r1 1 2 {r1:.0}\n\
             r2 2 0 {r2:.0}\n\
             .op\n\
             .end",
            vdd = 1.0 + scale,
            r1 = 1000.0 * scale,
            r2 = 2000.0 * scale,
        ),

        // ── RC low-pass transient ──────────────────────────────────────────
        // Classic first-order filter.  Varies time constant τ = RC.
        CircuitKind::RcLowPassTran => {
            let r_ohm = 1000.0 * scale; // 1 kΩ .. 9 kΩ
            let c_f = 1e-9 * scale; // 1 nF .. 9 nF
            let tau = r_ohm * c_f; // 1 µs .. 81 µs
            let stop = (10.0 * tau).max(10e-6); // simulate 10 time constants
            let step = stop / 1000.0;
            format!(
                "rc low-pass {id}\n\
                 v1 1 0 pulse(0 5 0 1n 1n {half_period} {period})\n\
                 r1 1 2 {r:.3e}\n\
                 c1 2 0 {c:.3e}\n\
                 .tran {step:.3e} {stop:.3e}\n\
                 .end",
                half_period = stop / 4.0,
                period = stop / 2.0,
                r = r_ohm,
                c = c_f,
                step = step,
                stop = stop,
            )
        }

        // ── RLC series resonator transient ─────────────────────────────────
        // Second-order system; tests the stiff integrator.
        CircuitKind::RlcSeriesTran => {
            let r_ohm = 10.0 * scale; // 10 Ω .. 90 Ω
            let l_h = 1e-6 * scale; // 1 µH .. 9 µH
            let c_f = 1e-9 * scale; // 1 nF .. 9 nF
            let f0 = 1.0 / (2.0 * std::f64::consts::PI * (l_h * c_f).sqrt());
            let period = 1.0 / f0;
            let stop = 20.0 * period;
            let step = period / 200.0;
            format!(
                "rlc resonator {id}\n\
                 v1 1 0 pulse(0 1 0 1p 1p {half_p:.3e} {period:.3e})\n\
                 r1 1 2 {r:.3e}\n\
                 l1 2 3 {l:.3e}\n\
                 c1 3 0 {c:.3e}\n\
                 .tran {step:.3e} {stop:.3e}\n\
                 .end",
                half_p = period / 2.0,
                period = period,
                r = r_ohm,
                l = l_h,
                c = c_f,
                step = step,
                stop = stop,
            )
        }

        // ── Two-stage RC ladder transient ──────────────────────────────────
        // More nodes, tests multi-node matrix solve.
        CircuitKind::RcLadderTran => {
            let r = 1000.0 * scale; // 1 kΩ .. 9 kΩ
            let c = 1e-9 * scale; // 1 nF .. 9 nF
            let tau = r * c;
            let stop = 20.0 * tau;
            let step = stop / 500.0;
            format!(
                "rc ladder {id}\n\
                 v1 1 0 pulse(0 3.3 0 1n 1n {half:.3e} {period:.3e})\n\
                 r1 1 2 {r:.3e}\n\
                 c1 2 0 {c:.3e}\n\
                 r2 2 3 {r:.3e}\n\
                 c2 3 0 {c:.3e}\n\
                 r3 3 4 {r:.3e}\n\
                 c3 4 0 {c:.3e}\n\
                 .tran {step:.3e} {stop:.3e}\n\
                 .end",
                half = stop / 4.0,
                period = stop / 2.0,
                r = r,
                c = c,
                step = step,
                stop = stop,
            )
        }

        // ── Diode half-wave rectifier transient ────────────────────────────
        // Non-linear element; exercises the Newton-Raphson solver.
        CircuitKind::DiodeRectifierTran => {
            let freq = 1e3 * scale; // 1 kHz .. 9 kHz
            let period = 1.0 / freq;
            let stop = 5.0 * period;
            let step = period / 400.0;
            let r_load = 10e3 * scale; // 10 kΩ .. 90 kΩ
            format!(
                "diode rectifier {id}\n\
                 .model D1N4148 D(Is=2.52n Rs=0.568 N=1.752 Cjo=4p M=0.4 tt=20n)\n\
                 v1 1 0 sin(0 5 {freq:.1})\n\
                 d1 1 2 D1N4148\n\
                 r1 2 0 {r_load:.3e}\n\
                 c1 2 0 10n\n\
                 .tran {step:.3e} {stop:.3e}\n\
                 .end",
                freq = freq,
                r_load = r_load,
                step = step,
                stop = stop,
            )
        }

        // ── Resistor network DC sweep ──────────────────────────────────────
        // Sweeps supply voltage 0→10 V; tests the DC solver loop.
        CircuitKind::ResistorNetworkDcSweep => {
            let r = 1000.0 * scale;
            format!(
                "resistor network dc sweep {id}\n\
                 v1 1 0 dc 5\n\
                 r1 1 2 {r:.3e}\n\
                 r2 2 3 {r:.3e}\n\
                 r3 3 0 {r:.3e}\n\
                 r4 1 3 {r2:.3e}\n\
                 .dc v1 0 10 0.1\n\
                 .end",
                r = r,
                r2 = r * 2.0,
            )
        }
    };

    SimulationRequest {
        id: format!("{}-{}", kind.name(), id),
        netlist,
        commands: vec!["run".to_string()],
        return_vectors: None,
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Result record — timing + outcome for one simulation
// ─────────────────────────────────────────────────────────────────────────────

struct SimResult {
    id: String,
    kind_name: &'static str,
    elapsed: Duration,
    success: bool,
    data_points: usize, // total across all vectors
    error: Option<String>,
}

// ─────────────────────────────────────────────────────────────────────────────
// Stress test runner
// ─────────────────────────────────────────────────────────────────────────────

async fn run_stress_test(args: Vec<String>) {
    let cfg = Config::from_args(&args);

    println!("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    println!(" ngspice-rust stress test");
    println!("   workers    : {}", cfg.workers);
    println!("   simulations: {}", cfg.sims);
    println!("   timeout    : {}s per simulation", cfg.timeout.as_secs());
    println!("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

    // ── Spin up the pool ──────────────────────────────────────────────────────

    let pool = Arc::new(
        WorkerPool::new(cfg.workers, cfg.timeout, None)
            .await
            .unwrap_or_else(|e| {
                eprintln!("pool creation failed: {e}");
                std::process::exit(1);
            }),
    );

    // ── Dispatch all simulations concurrently ─────────────────────────────────

    let wall_start = Instant::now();
    let mut join_set = tokio::task::JoinSet::new();

    for i in 0..cfg.sims {
        let kind = CircuitKind::from_index(i);
        let request = make_request(i, kind);
        let pool_ref = Arc::clone(&pool);

        join_set.spawn(async move {
            let t0 = Instant::now();
            let result: Result<SimulationResponse, _> = pool_ref.run_simulation(request).await;
            let elapsed = t0.elapsed();

            match result {
                Ok(resp) => {
                    let data_points = resp.vectors.iter().map(|v| v.data.len()).sum();
                    SimResult {
                        id: resp.id,
                        kind_name: kind.name(),
                        elapsed,
                        success: resp.success,
                        data_points,
                        error: resp.error,
                    }
                }
                Err(e) => SimResult {
                    id: format!("sim-{i}"),
                    kind_name: kind.name(),
                    elapsed,
                    success: false,
                    data_points: 0,
                    error: Some(e.to_string()),
                },
            }
        });
    }

    // ── Collect results, printing failures as they arrive ─────────────────────

    let mut results: Vec<SimResult> = Vec::with_capacity(cfg.sims);

    while let Some(join_result) = join_set.join_next().await {
        match join_result {
            Ok(r) => {
                if !r.success {
                    eprintln!(
                        "  FAIL  {} — {}",
                        r.id,
                        r.error.as_deref().unwrap_or("(no message)")
                    );
                }
                results.push(r);
            }
            Err(e) => {
                eprintln!("  PANIC — task panicked: {e}");
                results.push(SimResult {
                    id: "(panicked)".into(),
                    kind_name: "?",
                    elapsed: Duration::ZERO,
                    success: false,
                    data_points: 0,
                    error: Some(e.to_string()),
                });
            }
        }
    }

    let wall_elapsed = wall_start.elapsed();

    // ── Compute statistics ────────────────────────────────────────────────────

    let n_ok = results.iter().filter(|r| r.success).count();
    let n_fail = results.len() - n_ok;
    let total_data_points: usize = results.iter().map(|r| r.data_points).sum();

    // Latency percentiles (over successful simulations only).
    let mut latencies_ms: Vec<f64> = results
        .iter()
        .filter(|r| r.success)
        .map(|r| r.elapsed.as_secs_f64() * 1000.0)
        .collect();
    latencies_ms.sort_by(|a, b| a.partial_cmp(b).unwrap());

    let throughput = cfg.sims as f64 / wall_elapsed.as_secs_f64();

    // ── Per-kind breakdown ────────────────────────────────────────────────────

    let kinds = [
        "voltage-divider-op",
        "rc-lowpass-tran",
        "rlc-series-tran",
        "rc-ladder-tran",
        "diode-rectifier-tran",
        "resistor-net-dc-sweep",
    ];

    // ── Report ────────────────────────────────────────────────────────────────

    println!();
    println!("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    println!(" Results");
    println!("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    println!("  Total submitted : {}", cfg.sims);
    println!("  Passed          : {n_ok}");
    println!("  Failed          : {n_fail}");
    println!("  Wall time       : {:.2}s", wall_elapsed.as_secs_f64());
    println!("  Throughput      : {throughput:.1} sims/s");
    println!("  Total datapoints: {total_data_points}");

    if !latencies_ms.is_empty() {
        println!();
        println!("  Latency (successful sims, ms):");
        println!("    min  : {:>8.1}", latencies_ms[0]);
        println!("    p50  : {:>8.1}", percentile(&latencies_ms, 50.0));
        println!("    p90  : {:>8.1}", percentile(&latencies_ms, 90.0));
        println!("    p99  : {:>8.1}", percentile(&latencies_ms, 99.0));
        println!("    max  : {:>8.1}", latencies_ms[latencies_ms.len() - 1]);
    }

    println!();
    println!("  Per-circuit-type breakdown:");
    println!(
        "  {:<28}  {:>5}  {:>5}  {:>10}",
        "type", "ok", "fail", "avg ms"
    );
    println!("  {}", "─".repeat(56));
    for kind in &kinds {
        let kind_results: Vec<&SimResult> =
            results.iter().filter(|r| r.kind_name == *kind).collect();
        let k_ok = kind_results.iter().filter(|r| r.success).count();
        let k_fail = kind_results.len() - k_ok;
        let avg_ms = if k_ok > 0 {
            kind_results
                .iter()
                .filter(|r| r.success)
                .map(|r| r.elapsed.as_secs_f64() * 1000.0)
                .sum::<f64>()
                / k_ok as f64
        } else {
            0.0
        };
        println!(
            "  {:<28}  {:>5}  {:>5}  {:>9.1}ms",
            kind, k_ok, k_fail, avg_ms
        );
    }

    println!("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

    if n_fail > 0 {
        std::process::exit(1);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

fn num_cpus() -> usize {
    std::thread::available_parallelism()
        .map(|n| n.get())
        .unwrap_or(1)
}

/// Nearest-rank percentile on a pre-sorted slice.
fn percentile(sorted: &[f64], p: f64) -> f64 {
    if sorted.is_empty() {
        return 0.0;
    }
    let idx = ((p / 100.0) * (sorted.len() - 1) as f64).round() as usize;
    sorted[idx.min(sorted.len() - 1)]
}

// ─────────────────────────────────────────────────────────────────────────────
// LUT mode
// ─────────────────────────────────────────────────────────────────────────────

/// Parse `--lut` flags and run transistor characterisation.
///
/// ```
/// ngspice-rust --lut [options]
///
///   --type    nmos|pmos          device polarity (default: nmos)
///   --width   metres             gate width  (default: 1e-6)
///   --length  metres             gate length (default: 100e-9)
///   --vgs     start stop step    Vgs sweep in volts (default: 0 1.8 0.05)
///   --vds     start stop step    Vds sweep in volts (default: 0 1.8 0.05)
///   --vbs     volts              fixed bulk-source voltage (default: 0)
///   --model   "card..."          .model card string (default: built-in BSIM3)
///   --model-file path.lib        path to a SPICE .lib/.mod file (.include)
///   --model-name name            model name on M-line (default: nch / pch)
///   --workers N                  pool size (default: CPU count)
///   --timeout secs               per-simulation timeout (default: 120)
///   --output  file.csv           where to write the LUT (default: lut.csv)
/// ```
async fn run_lut(args: Vec<String>) {
    let mut cfg = LutConfig::default();
    let mut workers = num_cpus();
    let mut timeout_secs: u64 = 120;
    let mut csv_path = "lut.csv".to_string();

    let mut i = 1;
    while i < args.len() {
        match args[i].as_str() {
            "--lut" => {} // flag consumed by caller, skip
            "--type" => {
                i += 1;
                match args.get(i).map(|s| s.as_str()) {
                    Some("pmos") => {
                        cfg.device_type = DeviceType::Pmos;
                        if cfg.model_name == "nch" {
                            cfg.model_name = "pch".to_string();
                        }
                    }
                    Some("nmos") | None => {}
                    Some(other) => {
                        eprintln!("--type must be nmos or pmos, got '{other}'");
                        std::process::exit(1);
                    }
                }
            }
            "--width" => {
                i += 1;
                cfg.width = parse_f64(&args, i, "--width");
            }
            "--length" => {
                i += 1;
                cfg.length = parse_f64(&args, i, "--length");
            }
            "--vgs" => {
                cfg.vgs = parse_sweep(&args, &mut i, "--vgs");
            }
            "--vds" => {
                cfg.vds = parse_sweep(&args, &mut i, "--vds");
            }
            "--vbs" => {
                i += 1;
                cfg.vbs = parse_f64(&args, i, "--vbs");
            }
            "--model" => {
                i += 1;
                cfg.model_card = args.get(i).cloned().unwrap_or_default();
            }
            "--model-file" => {
                i += 1;
                cfg.model_file = args.get(i).cloned();
            }
            "--model-name" => {
                i += 1;
                cfg.model_name = args.get(i).cloned().unwrap_or(cfg.model_name);
            }
            "--workers" => {
                i += 1;
                workers = args
                    .get(i)
                    .and_then(|s| s.parse().ok())
                    .unwrap_or(workers)
                    .max(1);
            }
            "--timeout" => {
                i += 1;
                timeout_secs = args
                    .get(i)
                    .and_then(|s| s.parse().ok())
                    .unwrap_or(timeout_secs);
            }
            "--output" => {
                i += 1;
                csv_path = args.get(i).cloned().unwrap_or(csv_path);
            }
            "--help" | "-h" => {
                println!("Usage: ngspice-rust --lut [--type nmos|pmos] [--width m] [--length m]");
                println!("       [--vgs start stop step] [--vds start stop step] [--vbs v]");
                println!("       [--model 'card'] [--model-file path.lib] [--model-name name]");
                println!("       [--workers N] [--timeout secs] [--output file.csv]");
                std::process::exit(0);
            }
            other if other.starts_with("--") => {
                eprintln!("unknown --lut argument: {other}  (try --help)");
                std::process::exit(1);
            }
            _ => {}
        }
        i += 1;
    }

    let pool = Arc::new(
        WorkerPool::new(workers, Duration::from_secs(timeout_secs), None)
            .await
            .unwrap_or_else(|e| {
                eprintln!("pool error: {e}");
                std::process::exit(1);
            }),
    );

    // n_chunks = workers: one Vgs slice per worker process.
    sedes::lut::run_lut_generation(&pool, &cfg, workers, Some(Path::new(&csv_path))).await;
}

fn parse_f64(args: &[String], i: usize, flag: &str) -> f64 {
    args.get(i).and_then(|s| s.parse().ok()).unwrap_or_else(|| {
        eprintln!("{flag} requires a numeric value");
        std::process::exit(1);
    })
}

fn parse_sweep(args: &[String], i: &mut usize, flag: &str) -> SweepRange {
    let start = {
        *i += 1;
        parse_f64(args, *i, flag)
    };
    let stop = {
        *i += 1;
        parse_f64(args, *i, flag)
    };
    let step = {
        *i += 1;
        parse_f64(args, *i, flag)
    };
    SweepRange { start, stop, step }
}
