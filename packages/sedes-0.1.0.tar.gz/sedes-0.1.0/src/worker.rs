/// Worker process — the FFI boundary between Rust and libngspice.
///
/// # Architecture overview
///
/// Each worker process:
///   1. Calls `ngSpice_Init` **once** on startup, registering six C callbacks
///      and a `void* userData` pointer that points to a [`SimState`].
///   2. Enters a **JSON-lines loop** reading [`SimulationRequest`]s from stdin.
///   3. For each request, loads the netlist via `ngSpice_Circ`, runs the
///      commands via `ngSpice_Command`, then harvests result vectors via
///      `ngGet_Vec_Info`.
///   4. Writes a **binary response** to stdout: a 4-byte LE header length,
///      followed by a compact JSON metadata header, followed by raw LE f64
///      bytes for each vector.  See [`crate::protocol`] for the wire format.
///
/// # Why a separate process per simulation?
///
/// ngspice stores simulation state in **C global variables**.  If two
/// simulations ran in the same process concurrently (even on different threads)
/// they would corrupt each other.  Isolating each worker to its own process
/// gives us true independence: every worker has its own copy of all globals.
///
/// # Safety of the `void*` state pointer
///
/// ngspice's callback mechanism passes a `void* userData` pointer through
/// every callback.  We use this to hand a `*mut SimState` to the C library,
/// which echoes it back into each callback.  This is safe because:
///
///   * `SimState` is **heap-allocated** via `Box` and the `Box` is kept alive
///     for the entire duration of `run_worker` (it is only dropped at the end
///     of the function, after the stdin loop exits).
///   * We use **foreground-mode simulation** (`ngSpice_Command("run")` not
///     `"bg_run"`), so all callbacks execute **synchronously** inside the
///     `ngSpice_Command` call on the main thread — no background thread ever
///     touches `SimState` concurrently.
///   * Because there is no concurrent access, `SimState` does not need `Mutex`
///     protection.
///
/// If you ever switch to `bg_run`, you MUST wrap `SimState` in a
/// `Arc<Mutex<SimState>>` and store the raw pointer to the `Arc`'s inner data
/// after locking, or use `Arc<Mutex<SimState>>` with a raw pointer to the
/// allocation returned by `Box::into_raw(Box::new(Arc::new(...)))`.
use std::{
    ffi::{CStr, CString},
    io::{BufRead, Write},
    os::raw::{c_char, c_int, c_void},
};

use crate::{
    bindings::{
        ngGet_Vec_Info, ngSpice_AllPlots, ngSpice_AllVecs, ngSpice_Circ, ngSpice_Command,
        ngSpice_Init, vecinfoall, vector_info, vecvaluesall,
    },
    error::NgspiceError,
    protocol::{SimulationRequest, VectorData, WireHeader, WireVecMeta},
};

// ─────────────────────────────────────────────────────────────────────────────
// Binary response writer
// ─────────────────────────────────────────────────────────────────────────────

/// Write a binary-protocol response to `out`.
///
/// Format:
/// ```text
/// [4 bytes LE u32: JSON header length]
/// [N bytes: JSON WireHeader]
/// [for each vec:
///    real vectors:    vec.len × 8 bytes of LE f64
///    complex vectors: vec.len × 16 bytes (re₀, im₀, re₁, im₁, … interleaved LE f64)
/// ]
/// ```
fn write_wire_response(
    out: &mut impl Write,
    id: &str,
    success: bool,
    vectors: &[VectorData],
    log: Vec<String>,
    error: Option<String>,
    measures: Vec<(String, f64)>,
) -> Result<(), std::io::Error> {
    // Build the compact JSON header (names + lengths only, no float data).
    let wire = WireHeader {
        id: id.to_string(),
        success,
        vecs: vectors
            .iter()
            .map(|v| WireVecMeta {
                name: v.name.clone(),
                len: v.data.len(),
                is_scale: v.is_scale,
                is_complex: v.complex_data.is_some(),
            })
            .collect(),
        log,
        error,
        measures,
    };
    let header_json = serde_json::to_vec(&wire).expect("WireHeader serialization is infallible");

    // 4-byte header length prefix.
    out.write_all(&(header_json.len() as u32).to_le_bytes())?;
    out.write_all(&header_json)?;

    // Binary payload: real or interleaved-complex f64s per vector.
    for v in vectors {
        if let Some(ref cpx) = v.complex_data {
            // Complex vector: write re, im, re, im, … (2 × len f64s).
            let mut buf = vec![0u8; cpx.len() * 16];
            for (i, &(re, im)) in cpx.iter().enumerate() {
                buf[i * 16..i * 16 + 8].copy_from_slice(&re.to_le_bytes());
                buf[i * 16 + 8..i * 16 + 16].copy_from_slice(&im.to_le_bytes());
            }
            out.write_all(&buf)?;
        } else {
            // Real vector: write len f64s.
            let mut buf = vec![0u8; v.data.len() * 8];
            for (i, &f) in v.data.iter().enumerate() {
                buf[i * 8..(i + 1) * 8].copy_from_slice(&f.to_le_bytes());
            }
            out.write_all(&buf)?;
        }
    }

    out.flush()
}

// ─────────────────────────────────────────────────────────────────────────────
// Post-run helpers
// ─────────────────────────────────────────────────────────────────────────────

/// Read a null-terminated `*mut *mut c_char` returned by ngspice query functions.
/// Does NOT free the memory — ngspice owns it.
///
/// # Safety
/// `ptr` must be either null or a valid null-terminated C array of valid C strings,
/// as returned by `ngSpice_AllPlots` or `ngSpice_AllVecs`.
unsafe fn read_c_string_list(ptr: *mut *mut c_char) -> Vec<String> {
    if ptr.is_null() {
        return Vec::new();
    }
    let mut out = Vec::new();
    let mut i = 0usize;
    loop {
        // SAFETY: caller guarantees ptr is a null-terminated C array.
        let s_ptr = unsafe { *ptr.add(i) };
        if s_ptr.is_null() {
            break;
        }
        // SAFETY: each element is a valid null-terminated C string.
        let s = unsafe { CStr::from_ptr(s_ptr) }
            .to_string_lossy()
            .into_owned();
        out.push(s);
        i += 1;
    }
    out
}

/// Scan ngspice log lines for `.meas` / `.measure` results.
///
/// ngspice outputs measurement results as `name = value` lines (optionally
/// followed by `from=...` / `targ=...` annotations).  Lines where the value
/// is `FAILED` are skipped.
fn parse_measures(log_lines: &[String]) -> Vec<(String, f64)> {
    let mut measures = Vec::new();
    for raw in log_lines {
        // ngspice prefixes all output lines with "stdout " or "stderr ".
        // Strip that prefix before trying to parse measurement results.
        let line = raw
            .trim()
            .strip_prefix("stdout ")
            .or_else(|| raw.trim().strip_prefix("stderr "))
            .unwrap_or(raw.trim());
        let Some((name_part, val_part)) = line.split_once('=') else {
            continue;
        };
        let name = name_part.trim();
        let val_str = val_part.trim();

        // Skip FAILED measurements and empty values.
        if val_str.starts_with("FAILED") || val_str.is_empty() {
            continue;
        }

        // The value token is the first whitespace-delimited word
        // (the rest may be `from=...`, `targ=...` annotations).
        let val_token = val_str.split_whitespace().next().unwrap_or("");
        let Ok(value) = val_token.parse::<f64>() else {
            continue;
        };

        // Names must be valid SPICE identifiers: non-empty, no spaces,
        // alphanumeric + underscore only.
        if !name.is_empty() && name.chars().all(|c| c.is_alphanumeric() || c == '_') {
            measures.push((name.to_owned(), value));
        }
    }
    measures
}

/// Harvest vectors from ALL plots produced by the simulation.
///
/// For **single-plot** simulations (the common case), uses `fallback_names`
/// — the names captured by the `send_init_data` callback — so callers see
/// the canonical "V(out)"-style names.
///
/// For **multi-plot** simulations (e.g. `.op` + `.ac` in one netlist), uses
/// `ngSpice_AllPlots` + `ngSpice_AllVecs` and prefixes each name with the
/// plot: `"tran1.v(out)"`, `"ac1.v(out)"`, etc.
///
/// `return_vectors` filtering is applied in both paths.
///
/// # Safety
/// Must be called after all `ngSpice_Command` calls have returned.
/// The caller must NOT hold any live `vector_info` pointers — `setplot`
/// commands issued in the multi-plot path may invalidate them.
unsafe fn harvest_all_plots(
    request: &SimulationRequest,
    fallback_names: &[String],
) -> Vec<VectorData> {
    // ── Count analysis plots ─────────────────────────────────────────────────
    let all_plots: Vec<String> = unsafe {
        let ptr = ngSpice_AllPlots();
        read_c_string_list(ptr)
    };

    // ngspice always has a "const" pseudo-plot for internal constants.  Skip it.
    let analysis_plots: Vec<&str> = all_plots
        .iter()
        .map(String::as_str)
        .filter(|s| !s.eq_ignore_ascii_case("const") && !s.starts_with("const"))
        .collect();

    // ── Single-plot path: use send_init_data names (V(out) format) ───────────
    if analysis_plots.len() <= 1 {
        let vec_names: Vec<&String> = match &request.return_vectors {
            Some(filter) => fallback_names
                .iter()
                .filter(|n| filter.iter().any(|f| f.eq_ignore_ascii_case(n)))
                .collect(),
            None => fallback_names.iter().collect(),
        };

        let mut vectors: Vec<VectorData> = Vec::new();
        for name in &vec_names {
            let c_name = CString::new(name.as_str()).unwrap_or_else(|_| CString::new("").unwrap());
            // SAFETY: c_name is valid; returns null if not found.
            let vi = unsafe { ngGet_Vec_Info(c_name.as_ptr() as *mut c_char) };
            if vi.is_null() {
                continue;
            }
            // SAFETY: vi is valid; copy data immediately.
            let vd = unsafe { extract_vector_data(vi, name) };
            vectors.push(vd);
        }
        return vectors;
    }

    // ── Multi-plot path: enumerate each plot with setplot + AllVecs ──────────
    let mut vectors: Vec<VectorData> = Vec::new();

    for plot in &analysis_plots {
        // Switch to this plot.
        // SAFETY: no ngGet_Vec_Info pointers are live yet.
        let setplot_cmd = CString::new(format!("setplot {plot}")).unwrap_or_default();
        unsafe { ngSpice_Command(setplot_cmd.as_ptr() as *mut c_char) };

        let c_plot = CString::new(*plot).unwrap_or_default();
        let raw_names: Vec<String> = unsafe {
            let ptr = ngSpice_AllVecs(c_plot.as_ptr() as *mut c_char);
            read_c_string_list(ptr)
        };

        for raw_name in &raw_names {
            let external_name = format!("{plot}.{raw_name}");

            if let Some(filter) = &request.return_vectors {
                let matches = filter.iter().any(|f| {
                    f.eq_ignore_ascii_case(raw_name) || f.eq_ignore_ascii_case(&external_name)
                });
                if !matches {
                    continue;
                }
            }

            let c_name =
                CString::new(raw_name.as_str()).unwrap_or_else(|_| CString::new("").unwrap());
            // SAFETY: c_name valid; copy immediately before next setplot.
            let vi = unsafe { ngGet_Vec_Info(c_name.as_ptr() as *mut c_char) };
            if vi.is_null() {
                continue;
            }
            let vd = unsafe { extract_vector_data(vi, &external_name) };
            vectors.push(vd);
        }
    }

    vectors
}

// ─────────────────────────────────────────────────────────────────────────────
// State struct
// ─────────────────────────────────────────────────────────────────────────────

/// Mutable simulation state accumulated across callbacks during one run.
///
/// A raw pointer to this struct is cast to `void*` and passed as `userData`
/// to `ngSpice_Init`.  ngspice echoes it back into every callback so we can
/// accumulate log lines, vector names, and error information without global
/// variables.
///
/// **Invariant**: while `ngSpice_Command` is on the call stack, no other code
/// may hold a reference to `SimState`.  The callbacks obtain a `&mut SimState`
/// by casting the `void*` — this is only valid because we use foreground mode
/// (no background thread).
struct SimState {
    /// All lines emitted by ngspice via the `SendChar` callback.
    log_lines: Vec<String>,

    /// Names of all vectors in the current plot, populated by `SendInitData`.
    /// We use these names after the run to call `ngGet_Vec_Info` for each one.
    vec_names: Vec<String>,

    /// Set to `true` when `SendChar` receives a line that looks like an error.
    has_error: bool,

    /// The first error message encountered, if any.
    error_message: Option<String>,
}

impl SimState {
    fn new() -> Self {
        Self {
            log_lines: Vec::new(),
            vec_names: Vec::new(),
            has_error: false,
            error_message: None,
        }
    }

    /// Reset all fields so the struct can be reused for the next simulation
    /// without reallocating the `Box` or re-running `ngSpice_Init`.
    fn reset(&mut self) {
        self.log_lines.clear();
        self.vec_names.clear();
        self.has_error = false;
        self.error_message = None;
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// C callbacks
//
// Rules for all callbacks:
//   1. They are `unsafe extern "C"` — the C ABI requires `extern "C"` and the
//      raw pointer dereference requires `unsafe`.
//   2. They MUST NOT panic.  A panic across an FFI boundary is undefined
//      behaviour in Rust.  Use `if ptr.is_null()` guards and return early.
//   3. Return 0 on success (ngspice convention).
// ─────────────────────────────────────────────────────────────────────────────

/// Callback: `SendChar` — receives all text output from ngspice.
///
/// This includes informational messages, warnings, and errors.  Lines that
/// start with `"stderr "` (note the space) are ngspice's way of marking error
/// output; we detect them and set the error flag on `SimState`.
///
/// # Safety
///
/// `user_data` must be a valid, non-null `*mut SimState`.
/// `msg` must be a valid, non-null null-terminated C string.
/// Both are guaranteed by ngspice as long as `ngSpice_Init` was called
/// correctly.
unsafe extern "C" fn send_char(msg: *mut c_char, _id: c_int, user_data: *mut c_void) -> c_int {
    // Guard against null pointers — should never happen in practice.
    if msg.is_null() || user_data.is_null() {
        return 0;
    }

    // SAFETY: we verified user_data is non-null; it was set by run_worker to
    // point to a live SimState Box that outlives all ngSpice_Command calls.
    let state = unsafe { &mut *(user_data as *mut SimState) };

    // SAFETY: ngspice guarantees msg is a null-terminated C string.
    let line = unsafe { CStr::from_ptr(msg) }
        .to_string_lossy()
        .into_owned();

    // ngspice prefixes error output with "stderr " (with a trailing space).
    // Some versions use "Error:" — check both to be safe.
    if (line.starts_with("stderr ") && line.to_ascii_lowercase().contains("error"))
        || line.to_ascii_lowercase().starts_with("error")
    {
        state.has_error = true;
        if state.error_message.is_none() {
            state.error_message = Some(line.clone());
        }
    }

    state.log_lines.push(line);
    0
}

/// Callback: `SendStat` — receives progress status strings.
///
/// We discard these; they are only useful for interactive GUIs.
///
/// # Safety
/// See [`send_char`].
unsafe extern "C" fn send_stat(_msg: *mut c_char, _id: c_int, _user_data: *mut c_void) -> c_int {
    0
}

/// Callback: `ControlledExit` — called when ngspice wants to exit the process.
///
/// In the worker process this is non-fatal: we simply log and return.  ngspice
/// will try to call `exit()` if we return a non-zero value, which would kill
/// the worker process — we avoid that by always returning 0.
///
/// # Safety
/// See [`send_char`].
unsafe extern "C" fn controlled_exit(
    status: c_int,
    _immediate: bool,
    _quit_program: bool,
    _id: c_int,
    user_data: *mut c_void,
) -> c_int {
    if !user_data.is_null() {
        let state = unsafe { &mut *(user_data as *mut SimState) };
        state.has_error = true;
        let msg = format!("ngspice requested controlled exit with status {status}");
        if state.error_message.is_none() {
            state.error_message = Some(msg.clone());
        }
        state.log_lines.push(msg);
    }
    0
}

/// Callback: `SendData` — called once per time-step during simulation.
///
/// We intentionally **do not** accumulate data here.  Instead, after the run
/// completes, we call `ngGet_Vec_Info` for each vector name, which returns a
/// pointer to the complete, already-allocated data array.  This is simpler and
/// avoids the need to deal with point-by-point indexing into `vecvaluesall`.
///
/// If you ever need streaming data (e.g. for very long transient simulations
/// where memory is a concern), this is the place to add it.
///
/// # Safety
/// `vdata` may be null if the callback fires before any data is available.
unsafe extern "C" fn send_data(
    _vdata: *mut vecvaluesall,
    _count: c_int,
    _id: c_int,
    _user_data: *mut c_void,
) -> c_int {
    // Intentionally empty — data is harvested post-run via ngGet_Vec_Info.
    0
}

/// Callback: `SendInitData` — called once when ngspice sets up a new plot.
///
/// `vecinfoall` contains the names and types of all vectors that will be
/// produced by the upcoming simulation.  We capture the names here so we
/// know what to ask for via `ngGet_Vec_Info` after the run.
///
/// # Safety
/// `init` must be a valid `*mut vecinfoall` (guaranteed by ngspice).
/// `user_data` must be a valid `*mut SimState` (guaranteed by our init call).
unsafe extern "C" fn send_init_data(
    init: *mut vecinfoall,
    _id: c_int,
    user_data: *mut c_void,
) -> c_int {
    if init.is_null() || user_data.is_null() {
        return 0;
    }

    let state = unsafe { &mut *(user_data as *mut SimState) };

    // SAFETY: ngspice guarantees `init` is valid and `vecs` is an array of
    // `veccount` valid `*mut vecinfo` pointers.
    let info = unsafe { &*init };
    state.vec_names.clear();

    for i in 0..(info.veccount as usize) {
        // SAFETY: `info.vecs` is a C array; index access is valid for 0..veccount.
        let vec_ptr = unsafe { *info.vecs.add(i) };
        if vec_ptr.is_null() {
            continue;
        }
        let vec_info = unsafe { &*vec_ptr };
        if vec_info.vecname.is_null() {
            continue;
        }
        let name = unsafe { CStr::from_ptr(vec_info.vecname) }
            .to_string_lossy()
            .into_owned();
        state.vec_names.push(name);
    }

    0
}

/// Callback: `BGThreadRunning` — called when the background simulation thread
/// starts and stops.
///
/// We don't use background mode, but ngspice may still fire this callback.
/// We simply ignore it.
///
/// # Safety
/// See [`send_char`].
unsafe extern "C" fn bg_thread_running(
    _is_running: bool,
    _id: c_int,
    _user_data: *mut c_void,
) -> c_int {
    0
}

// ─────────────────────────────────────────────────────────────────────────────
// Vector harvesting
// ─────────────────────────────────────────────────────────────────────────────

/// Copy the data from a `vector_info` struct returned by `ngGet_Vec_Info` into
/// an owned [`VectorData`].
///
/// ngspice owns the memory behind the `vector_info` pointer — we must **copy**
/// the data into Rust-owned `Vec`s and not store the pointer itself.
///
/// # Safety
///
/// `vi` must be a valid, non-null pointer returned by `ngGet_Vec_Info`.
/// The pointed-to `vector_info` is valid only until the next `ngSpice_Command`
/// call, so this function must be called immediately after the run completes,
/// before issuing any further commands.
unsafe fn extract_vector_data(vi: *mut vector_info, name: &str) -> VectorData {
    // SAFETY: caller guarantees vi is non-null and valid.
    let info = unsafe { &*vi };

    let length = info.v_length as usize;

    // Determine if the vector holds complex data by checking whether v_compdata
    // is non-null.  Using v_type & 1 is incorrect: v_type encodes the vector kind
    // (SV_TIME=1, SV_FREQUENCY=2, SV_VOLTAGE=3, …), not a complex flag.
    // In AC analysis ngspice stores ALL vectors (including the frequency axis)
    // as complex — v_realdata is null and v_compdata is valid.
    let is_complex = !info.v_compdata.is_null();

    // SV_VOLTAGE == 4, which is also the flag for the sweep axis (scale vector).
    // ngspice marks the independent variable (time, frequency) with VF_REAL | VF_SCALE.
    // The scale flag lives in v_flags; SV_SCALE == 0x400 in most builds.
    // Using the simpler heuristic: if v_name ends with "time" or "frequency"
    // AND is the first vector, treat it as the scale.  We leave the exact
    // detection to the caller by inspecting `name`.
    let is_scale = name.eq_ignore_ascii_case("time")
        || name.eq_ignore_ascii_case("frequency")
        || name.eq_ignore_ascii_case("v-sweep");

    if is_complex && !info.v_compdata.is_null() {
        // AC analysis: copy real and imaginary parts separately.
        // SAFETY: v_compdata points to an array of `v_length` ngcomplex values.
        let comp_slice = unsafe { std::slice::from_raw_parts(info.v_compdata, length) };
        let real_data: Vec<f64> = comp_slice.iter().map(|c| c.cx_real).collect();
        let complex_data: Vec<(f64, f64)> =
            comp_slice.iter().map(|c| (c.cx_real, c.cx_imag)).collect();

        VectorData {
            name: name.to_owned(),
            data: real_data,
            complex_data: Some(complex_data),
            is_scale,
        }
    } else if !info.v_realdata.is_null() {
        // DC / transient: copy the real data array.
        // SAFETY: v_realdata points to an array of `v_length` f64 values.
        let real_slice = unsafe { std::slice::from_raw_parts(info.v_realdata, length) };

        VectorData {
            name: name.to_owned(),
            data: real_slice.to_vec(),
            complex_data: None,
            is_scale,
        }
    } else {
        // Vector exists but has no data (e.g. an empty plot).
        VectorData {
            name: name.to_owned(),
            data: Vec::new(),
            complex_data: None,
            is_scale,
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Worker entry point
// ─────────────────────────────────────────────────────────────────────────────

/// Main loop for the worker process.
///
/// Called from `main` when `--worker` is present in argv.
/// Reads JSON-lines from stdin, runs each simulation, writes JSON-lines to stdout.
///
/// # Lifecycle
///
/// ```text
/// ngSpice_Init (once)
///   └─ for each line on stdin:
///        ├─ parse SimulationRequest
///        ├─ reset SimState
///        ├─ ngSpice_Circ (load netlist)
///        ├─ ngSpice_Command (for each command)
///        ├─ ngGet_Vec_Info (for each vector name)
///        ├─ serialize SimulationResponse → stdout + flush
///        └─ ngSpice_Command("destroy all")  ← clean up for next iteration
/// ```
pub fn run_worker() -> Result<(), NgspiceError> {
    // Heap-allocate SimState so the address is stable for the entire function.
    // We take a raw pointer here and pass it to ngSpice_Init as the void* userData.
    //
    // SAFETY contract we must uphold:
    //   * state_box must not be dropped before ngSpice_Init's final callback.
    //   * SimState must not be moved (Box guarantees the heap address is stable).
    //   * No other thread may access *state while ngSpice_Command is on the
    //     call stack (foreground mode guarantees this).
    let mut state_box = Box::new(SimState::new());
    let state_ptr: *mut SimState = &mut *state_box;

    // ── Initialise ngspice ────────────────────────────────────────────────────
    //
    // ngSpice_Init signature (from sharedspice.h):
    //
    //   int ngSpice_Init(
    //     SendChar*        printfcn,        // log output
    //     SendStat*        statfcn,         // progress status
    //     ControlledExit*  ngexit,          // exit request
    //     SendData*        sdata,           // per-step data
    //     SendInitData*    sinitdata,       // plot/vector init
    //     BGThreadRunning* bgtrun,          // background thread start/stop
    //     void*            userData         // echoed into all callbacks
    //   );
    //
    // We cast state_ptr to *mut c_void — the caller (ngspice) stores it
    // opaquely and passes it back into every callback.
    let init_result = unsafe {
        ngSpice_Init(
            Some(send_char),
            Some(send_stat),
            Some(controlled_exit),
            Some(send_data),
            Some(send_init_data),
            Some(bg_thread_running),
            state_ptr as *mut c_void,
        )
    };

    if init_result != 0 {
        return Err(NgspiceError::InitFailed(format!(
            "ngSpice_Init returned {init_result}"
        )));
    }

    // ── Buffered stdout writer ────────────────────────────────────────────────
    // BufWriter batches writes; we call flush() explicitly after each response.
    let stdout = std::io::stdout();
    let mut out = std::io::BufWriter::new(stdout.lock());

    // ── Main request loop ─────────────────────────────────────────────────────
    let stdin = std::io::stdin();
    for line_result in stdin.lock().lines() {
        let line = line_result?;

        if line.trim().is_empty() {
            continue;
        }

        // Parse the request — a JSON object on a single line.
        let request: SimulationRequest = match serde_json::from_str(&line) {
            Ok(r) => r,
            Err(e) => {
                write_wire_response(
                    &mut out,
                    "unknown",
                    false,
                    &[],
                    vec![format!("failed to parse request: {e}")],
                    Some(format!("parse error: {e}")),
                    vec![],
                )?;
                continue;
            }
        };

        let request_id = request.id.clone();

        // Reset state from any previous simulation.
        // SAFETY: no callbacks are running at this point.
        let state = unsafe { &mut *state_ptr };
        state.reset();

        // ── Validate netlist ──────────────────────────────────────────────────
        // ngSpice_Circ requires the last non-null line to be ".end".
        let netlist = request.netlist.trim_end().to_string();
        if !netlist
            .lines()
            .last()
            .unwrap_or("")
            .trim()
            .eq_ignore_ascii_case(".end")
        {
            write_wire_response(
                &mut out,
                &request_id,
                false,
                &[],
                vec!["netlist must end with .end".to_string()],
                Some("netlist does not end with .end".to_string()),
                vec![],
            )?;
            continue;
        }

        // ── Load netlist via ngSpice_Circ ─────────────────────────────────────
        //
        // ngSpice_Circ takes a `*mut *mut c_char` — a null-terminated array of
        // C strings, one per netlist line.
        //
        // Lifetime hazard: we must keep the `CString`s alive until AFTER the
        // `ngSpice_Circ` call returns.  We do this by binding them to locals
        // in the same scope.
        let cstrings: Vec<CString> = netlist
            .lines()
            .map(|l| {
                let safe_line = l.replace('\0', " ");
                CString::new(safe_line).expect("netlist line contained interior null")
            })
            .collect();

        // Build the pointer array: one *mut c_char per line, terminated by null.
        let mut ptrs: Vec<*mut c_char> = cstrings
            .iter()
            .map(|cs| cs.as_ptr() as *mut c_char)
            .collect();
        ptrs.push(std::ptr::null_mut()); // null terminator required by ngspice

        // SAFETY: ptrs is a valid null-terminated array of valid C strings.
        // cstrings (and therefore ptrs) remain alive until the end of this block.
        let circ_result = unsafe { ngSpice_Circ(ptrs.as_mut_ptr()) };

        if circ_result != 0 {
            write_wire_response(
                &mut out,
                &request_id,
                false,
                &[],
                state.log_lines.clone(),
                Some(format!("ngSpice_Circ failed with code {circ_result}")),
                vec![],
            )?;
            continue;
        }

        // ── Execute simulation commands ───────────────────────────────────────
        let mut cmd_failed = false;
        for cmd in &request.commands {
            let c_cmd = CString::new(cmd.as_str()).unwrap_or_else(|_| CString::new("").unwrap());

            // SAFETY: c_cmd is a valid null-terminated C string.
            let cmd_result = unsafe { ngSpice_Command(c_cmd.as_ptr() as *mut c_char) };

            if cmd_result != 0 {
                let state = unsafe { &mut *state_ptr };
                state.has_error = true;
                let msg = format!("command '{cmd}' failed with code {cmd_result}");
                state.log_lines.push(msg.clone());
                if state.error_message.is_none() {
                    state.error_message = Some(msg);
                }
                cmd_failed = true;
                break;
            }
        }

        // Re-borrow state after all commands (callbacks have finished).
        let state = unsafe { &*state_ptr };

        // ── Harvest vectors from all plots ────────────────────────────────────
        //
        // For single-plot simulations we use `state.vec_names` (captured by the
        // `send_init_data` callback), which gives the "V(out)"-style names that
        // users expect.  For multi-plot simulations (e.g. .op + .ac in one
        // netlist) we use `ngSpice_AllPlots` + `ngSpice_AllVecs` and prefix each
        // vector name with the plot name ("tran1.v(out)").
        let fallback = state.vec_names.clone();
        let vectors: Vec<VectorData> = if !cmd_failed {
            // SAFETY: all ngSpice_Command calls have returned; no vector_info
            // pointers are live; harvest_all_plots copies all data immediately.
            unsafe { harvest_all_plots(&request, &fallback) }
        } else {
            Vec::new()
        };

        let state = unsafe { &*state_ptr };
        let success = !state.has_error && !cmd_failed;
        let measures = parse_measures(&state.log_lines);

        // ── Write binary response ─────────────────────────────────────────────
        write_wire_response(
            &mut out,
            &request_id,
            success,
            &vectors,
            state.log_lines.clone(),
            state.error_message.clone(),
            measures,
        )?;

        // ── Clean up ngspice state for the next simulation ────────────────────
        //
        // "destroy all" removes all plots and vectors from ngspice's memory.
        // Without this, vectors from a previous simulation can leak into the
        // next one, causing incorrect results or memory growth.
        let destroy_cmd = CString::new("destroy all").unwrap();
        unsafe { ngSpice_Command(destroy_cmd.as_ptr() as *mut c_char) };
    }

    // state_box is dropped here, after the stdin loop exits (EOF or error).
    // Any further callbacks would be UB, but ngspice won't fire them after EOF.
    drop(state_box);

    Ok(())
}
