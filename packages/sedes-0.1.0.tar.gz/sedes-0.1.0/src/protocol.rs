/// IPC protocol types shared between the Main Dispatcher and Worker processes.
///
/// # Wire format
///
/// Every response uses a **binary** encoding to avoid the overhead of
/// JSON-encoding large f64 arrays:
///
/// ```text
/// ┌──────────────────────┬───────────────────────────────────┐
/// │  4 bytes (LE u32)    │  JSON header (WireHeader)         │
/// │  = header byte len   │  {id, success, vecs, log, error}  │
/// ├──────────────────────┴───────────────────────────────────┤
/// │  for each vec in header.vecs:                            │
/// │    vec.len × 8 bytes  (LE f64, native order)             │
/// └──────────────────────────────────────────────────────────┘
/// ```
///
/// Requests are still JSON-lines on stdin (they are small).
///
/// # Why binary for responses?
///
/// A single f64 encoded as JSON text costs ~12-15 bytes; as raw LE bytes it
/// costs exactly 8.  For a 3601×3601 LUT chunk (1.62 M values) the difference
/// is 24 MB of JSON text vs 13 MB of binary — and JSON parsing/generation is
/// 5-10× slower than a memcpy.  At scale the IPC bandwidth becomes the
/// bottleneck; binary encoding removes it.
use serde::{Deserialize, Serialize};

// ── Request (Dispatcher → Worker, via worker's stdin) ─────────────────────────

/// Everything the worker needs to run one simulation.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SimulationRequest {
    /// Opaque correlation ID echoed back in the response.
    pub id: String,

    /// Full SPICE netlist as a UTF-8 string.  Must end with `.end`.
    pub netlist: String,

    /// Ordered list of ngspice commands to execute after the netlist is loaded.
    pub commands: Vec<String>,

    /// If set, only the named vectors are included in the response.
    /// Use this to avoid transferring vectors you don't need (e.g. for LUT
    /// generation, only `"vds#branch"` is required).  `None` → return all.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub return_vectors: Option<Vec<String>>,
}

// ── Binary wire protocol (Worker → Dispatcher) ────────────────────────────────

/// JSON header sent before the binary vector data.
///
/// This is an internal type — callers work with [`SimulationResponse`].
#[derive(Debug, Serialize, Deserialize)]
pub struct WireHeader {
    pub id: String,
    pub success: bool,
    pub vecs: Vec<WireVecMeta>,
    pub log: Vec<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub error: Option<String>,
    /// Parsed `.meas` / `.measure` results extracted from the ngspice log.
    /// Each entry is `(measure_name, value)`.  Empty when no `.meas` was used.
    #[serde(default)]
    pub measures: Vec<(String, f64)>,
}

/// Per-vector metadata inside the wire header.
#[derive(Debug, Serialize, Deserialize)]
pub struct WireVecMeta {
    pub name: String,
    /// Number of *data points* (not bytes).  For complex vectors this is still
    /// the number of complex values; the binary section contains `len * 2` f64s
    /// (interleaved real, imag).
    pub len: usize,
    pub is_scale: bool,
    /// True for AC/complex vectors.  When set the binary section contains
    /// `len * 2` LE f64s: (re₀, im₀, re₁, im₁, …).
    #[serde(default)]
    pub is_complex: bool,
}

// ── Public response types (used inside the dispatcher) ────────────────────────

/// A single simulation output vector (e.g. `v(2)`, `time`, `i(v1)`).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VectorData {
    pub name: String,
    /// Real-valued data points.
    pub data: Vec<f64>,
    /// Present for complex vectors (AC analysis).
    #[serde(skip_serializing_if = "Option::is_none")]
    pub complex_data: Option<Vec<(f64, f64)>>,
    /// True when this vector is the sweep axis (e.g. `time` or `frequency`).
    pub is_scale: bool,
}

/// Everything the dispatcher receives after a simulation completes.
#[derive(Debug, Clone)]
pub struct SimulationResponse {
    pub id: String,
    pub success: bool,
    pub vectors: Vec<VectorData>,
    pub log: Vec<String>,
    pub error: Option<String>,
    /// Parsed `.meas` results.  Empty when no `.measure` statements were used.
    pub measures: Vec<(String, f64)>,
}

/// Convenience alias kept for callers that destructure the full response.
#[allow(dead_code)]
pub type SimulationData = SimulationResponse;
