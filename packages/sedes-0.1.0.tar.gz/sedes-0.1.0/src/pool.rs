/// Asynchronous worker pool — the Main Dispatcher side of the architecture.
///
/// # Design
///
/// The pool spawns `N` child processes (dedicated `ngspice-worker` binaries, or
/// the main binary with `--worker` as a fallback).  Communication is JSON-lines
/// over piped stdin/stdout.
///
/// ```text
///   Caller
///     │  run_simulation(req)
///     ▼
///   WorkerPool
///     │  (mpsc channel)
///     ├─► WorkerTask 0  ──stdin──►  Worker Process 0  ──stdout──► response
///     ├─► WorkerTask 1  ──stdin──►  Worker Process 1  ──stdout──► response
///     └─► WorkerTask N  ──stdin──►  Worker Process N  ──stdout──► response
/// ```
///
/// Each `WorkerTask` is a tokio task that owns **one** child process and loops:
///
/// ```text
///   loop {
///     recv (request, reply_tx) from mpsc channel
///     write JSON to child stdin
///     read  JSON from child stdout  (with timeout)
///     send response back via reply_tx (oneshot)
///   }
/// ```
///
/// If the child process crashes (stdout EOF or read error), the task respawns
/// a fresh worker before serving the next request.
///
/// # Why a channel per pool rather than a channel per worker?
///
/// A single `mpsc` channel naturally load-balances: whichever worker finishes
/// its current simulation first will pick up the next request.  There is no
/// need for a separate scheduler or semaphore.
use std::{env, path::PathBuf, process::Stdio, sync::Arc, time::Duration};

use tokio::{
    io::{AsyncReadExt, AsyncWriteExt, BufReader},
    process::{Child, ChildStdin, ChildStdout, Command},
    sync::{mpsc, oneshot},
    time::timeout,
};

use crate::{
    error::NgspiceError,
    protocol::{SimulationRequest, SimulationResponse, VectorData, WireHeader},
};

// ─────────────────────────────────────────────────────────────────────────────
// Worker binary location
// ─────────────────────────────────────────────────────────────────────────────

/// The resolved executable path and any additional arguments needed to start a
/// worker process.
#[derive(Debug, Clone)]
struct WorkerBinary {
    path: PathBuf,
    /// Extra CLI arguments appended when spawning (e.g. `["--worker"]` for the
    /// legacy single-binary mode).
    args: Vec<String>,
}

/// Locate the `ngspice-worker` binary using a priority-ordered search.
///
/// Search order:
/// 1. `NGSPICE_WORKER_BIN` environment variable — explicit override.
/// 2. Directory containing the current executable — covers the CLI case where
///    both `ngspice-rust` and `ngspice-worker` sit in `target/{debug,release}/`.
/// 3. `$VIRTUAL_ENV/{bin,Scripts}/` — covers `maturin develop` / `pip install`
///    where the binary is installed as a console-script in the active venv.
/// 4. Directories on `$PATH` — covers globally installed packages.
/// 5. Current executable with `--worker` flag — backwards-compatibility
///    fallback for deployments that only have the monolithic binary.
fn find_worker_binary() -> Result<WorkerBinary, NgspiceError> {
    let binary_name = if cfg!(windows) {
        "ngspice-worker.exe"
    } else {
        "ngspice-worker"
    };

    // ── 1. Explicit environment-variable override ─────────────────────────────
    if let Ok(path_str) = std::env::var("NGSPICE_WORKER_BIN") {
        let path = PathBuf::from(path_str);
        if path.exists() {
            return Ok(WorkerBinary { path, args: vec![] });
        }
    }

    // ── 2. Adjacent to the current executable ────────────────────────────────
    if let Ok(exe) = env::current_exe()
        && let Some(dir) = exe.parent()
    {
        let candidate = dir.join(binary_name);
        if candidate.exists() {
            return Ok(WorkerBinary {
                path: candidate,
                args: vec![],
            });
        }
    }

    // ── 3. Active Python virtualenv scripts directory ─────────────────────────
    if let Ok(venv) = std::env::var("VIRTUAL_ENV") {
        let scripts_dir = if cfg!(windows) { "Scripts" } else { "bin" };
        let candidate = PathBuf::from(venv).join(scripts_dir).join(binary_name);
        if candidate.exists() {
            return Ok(WorkerBinary {
                path: candidate,
                args: vec![],
            });
        }
    }

    // ── 4. PATH lookup ────────────────────────────────────────────────────────
    if let Some(path_var) = std::env::var_os("PATH") {
        for dir in std::env::split_paths(&path_var) {
            let candidate = dir.join(binary_name);
            if candidate.exists() {
                return Ok(WorkerBinary {
                    path: candidate,
                    args: vec![],
                });
            }
        }
    }

    // ── 5. Fallback: re-exec current binary with --worker ────────────────────
    if let Ok(exe) = env::current_exe() {
        return Ok(WorkerBinary {
            path: exe,
            args: vec!["--worker".to_string()],
        });
    }

    Err(NgspiceError::InitFailed(
        "could not find 'ngspice-worker' binary. \
         Set the NGSPICE_WORKER_BIN environment variable or ensure it is on PATH."
            .to_string(),
    ))
}

// ─────────────────────────────────────────────────────────────────────────────
// Internal types
// ─────────────────────────────────────────────────────────────────────────────

/// A message sent from the pool's public API into the worker task loop.
type PoolMessage = (
    SimulationRequest,
    oneshot::Sender<Result<SimulationResponse, NgspiceError>>,
);

/// Holds all I/O handles for one live worker child process.
struct WorkerProcess {
    child: Child,
    stdin: ChildStdin,
    stdout: BufReader<ChildStdout>,
}

impl WorkerProcess {
    /// Spawn a new worker child process using the resolved binary location.
    ///
    /// stdin/stdout are piped; stderr is inherited so worker crash messages
    /// appear in the dispatcher's terminal during development.
    fn spawn(bin: &WorkerBinary) -> Result<Self, NgspiceError> {
        let mut cmd = Command::new(&bin.path);
        for arg in &bin.args {
            cmd.arg(arg);
        }

        let mut child = cmd
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            // Inherit stderr so worker crashes are visible in the dispatcher's terminal.
            // In production you might want Stdio::piped() + a logging task instead.
            .stderr(Stdio::inherit())
            .spawn()
            .map_err(NgspiceError::Io)?;

        let stdin = child
            .stdin
            .take()
            .expect("stdin was piped but is missing — this is a bug");
        let stdout_raw = child
            .stdout
            .take()
            .expect("stdout was piped but is missing — this is a bug");
        let stdout = BufReader::new(stdout_raw);

        Ok(Self {
            child,
            stdin,
            stdout,
        })
    }

    /// Returns `true` if the child process has already exited.
    fn has_exited(&mut self) -> bool {
        // `try_wait` is non-blocking: returns Ok(Some(_)) if the child exited,
        // Ok(None) if it is still running, Err if something went wrong.
        self.child
            .try_wait()
            .map(|status| status.is_some())
            .unwrap_or(true) // treat errors as "exited"
    }

    /// Send a simulation request and wait for the response.
    ///
    /// Writes one JSON line to the child's stdin, then reads the binary-protocol
    /// response from stdout.  The entire operation is bounded by `sim_timeout`.
    ///
    /// Returns `Err(NgspiceError::WorkerCrashed(...))` if the child exits or
    /// the pipe breaks, and `Err(NgspiceError::SimulationFailed("timeout"))`
    /// if the worker takes longer than `sim_timeout`.
    async fn run(
        &mut self,
        request: &SimulationRequest,
        sim_timeout: Duration,
    ) -> Result<SimulationResponse, NgspiceError> {
        // Serialise request to a single JSON line.
        let mut json = serde_json::to_string(request).map_err(NgspiceError::Serialization)?;
        json.push('\n');

        // Write to worker stdin.
        self.stdin
            .write_all(json.as_bytes())
            .await
            .map_err(|e| NgspiceError::WorkerCrashed(format!("stdin write failed: {e}")))?;
        self.stdin
            .flush()
            .await
            .map_err(|e| NgspiceError::WorkerCrashed(format!("stdin flush failed: {e}")))?;

        // Read binary response from worker stdout, with a timeout.
        timeout(sim_timeout, read_binary_response(&mut self.stdout))
            .await
            .map_err(|_| {
                NgspiceError::SimulationFailed(format!(
                    "worker timed out after {:.0}s",
                    sim_timeout.as_secs_f64()
                ))
            })?
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Binary response reader
// ─────────────────────────────────────────────────────────────────────────────

/// Read one binary-protocol response from the worker's stdout.
///
/// Wire format (from [`crate::protocol`]):
/// ```text
/// [4 bytes LE u32: JSON header length]
/// [N bytes: JSON WireHeader]
/// [for each vec:
///    real:    meta.len × 8 bytes (LE f64)
///    complex: meta.len × 16 bytes (re₀, im₀, re₁, im₁, … LE f64 pairs)
/// ]
/// ```
async fn read_binary_response(
    stdout: &mut BufReader<ChildStdout>,
) -> Result<SimulationResponse, NgspiceError> {
    // ── Step 1: read the 4-byte header length ────────────────────────────────
    let mut len_buf = [0u8; 4];
    stdout.read_exact(&mut len_buf).await.map_err(|e| {
        NgspiceError::WorkerCrashed(format!("stdout read (header len) failed: {e}"))
    })?;
    let header_len = u32::from_le_bytes(len_buf) as usize;

    // ── Step 2: read the JSON metadata header ────────────────────────────────
    let mut header_buf = vec![0u8; header_len];
    stdout
        .read_exact(&mut header_buf)
        .await
        .map_err(|e| NgspiceError::WorkerCrashed(format!("stdout read (header) failed: {e}")))?;

    let wire: WireHeader =
        serde_json::from_slice(&header_buf).map_err(NgspiceError::Serialization)?;

    // ── Step 3: read binary payload for each vector ──────────────────────────
    let mut vectors: Vec<VectorData> = Vec::with_capacity(wire.vecs.len());
    for meta in &wire.vecs {
        if meta.is_complex {
            // Complex vector: meta.len pairs → 2 × meta.len f64s on the wire.
            let byte_len = meta.len * 16;
            let mut data_buf = vec![0u8; byte_len];
            stdout.read_exact(&mut data_buf).await.map_err(|e| {
                NgspiceError::WorkerCrashed(format!("stdout read (complex vec) failed: {e}"))
            })?;

            let complex_data: Vec<(f64, f64)> = data_buf
                .chunks_exact(16)
                .map(|chunk| {
                    let re = f64::from_le_bytes(chunk[0..8].try_into().unwrap());
                    let im = f64::from_le_bytes(chunk[8..16].try_into().unwrap());
                    (re, im)
                })
                .collect();

            // Also populate `data` with the real parts for callers that don't
            // need the full complex representation.
            let data: Vec<f64> = complex_data.iter().map(|(re, _)| *re).collect();

            vectors.push(VectorData {
                name: meta.name.clone(),
                data,
                complex_data: Some(complex_data),
                is_scale: meta.is_scale,
            });
        } else {
            // Real vector: meta.len f64s on the wire.
            let byte_len = meta.len * 8;
            let mut data_buf = vec![0u8; byte_len];
            stdout.read_exact(&mut data_buf).await.map_err(|e| {
                NgspiceError::WorkerCrashed(format!("stdout read (vec data) failed: {e}"))
            })?;

            let data: Vec<f64> = data_buf
                .chunks_exact(8)
                .map(|chunk| f64::from_le_bytes(chunk.try_into().unwrap()))
                .collect();

            vectors.push(VectorData {
                name: meta.name.clone(),
                data,
                complex_data: None,
                is_scale: meta.is_scale,
            });
        }
    }

    Ok(SimulationResponse {
        id: wire.id,
        success: wire.success,
        vectors,
        log: wire.log,
        error: wire.error,
        measures: wire.measures,
    })
}

// ─────────────────────────────────────────────────────────────────────────────
// WorkerPool
// ─────────────────────────────────────────────────────────────────────────────

/// An asynchronous pool of ngspice worker processes.
///
/// # Example
///
/// ```rust,no_run
/// use sedes::pool::WorkerPool;
/// use sedes::protocol::SimulationRequest;
///
/// #[tokio::main]
/// async fn main() {
///     let pool = WorkerPool::new(4, std::time::Duration::from_secs(300), None)
///         .await
///         .expect("failed to create pool");
///
///     let request = SimulationRequest {
///         id: "sim-001".into(),
///         netlist: "RC\nv1 1 0 dc 5\nr1 1 2 1k\nc1 2 0 1u\n.tran 1u 5m\n.end".into(),
///         commands: vec!["run".into()],
///         return_vectors: None,
///     };
///
///     let response = pool.run_simulation(request).await.expect("simulation failed");
///     println!("got {} vectors", response.vectors.len());
/// }
/// ```
pub struct WorkerPool {
    /// Sender end of the shared channel.  Callers clone this to submit jobs.
    sender: mpsc::Sender<PoolMessage>,
}

impl WorkerPool {
    /// Spawn a new pool with `size` worker processes.
    ///
    /// Each worker is immediately spawned and begins waiting for requests.
    /// `sim_timeout` bounds the time each individual simulation may take.
    ///
    /// `worker_exe` optionally overrides the worker binary path.  When `None`,
    /// the pool locates the binary automatically (see `find_worker_binary`).
    ///
    /// # Errors
    ///
    /// Returns an error if the worker binary cannot be found or any worker
    /// process fails to spawn.
    pub async fn new(
        size: usize,
        sim_timeout: Duration,
        worker_exe: Option<PathBuf>,
    ) -> Result<Self, NgspiceError> {
        let worker_bin = Arc::new(match worker_exe {
            Some(path) => WorkerBinary { path, args: vec![] },
            None => find_worker_binary()?,
        });

        // Unbounded channel so callers never block on send.
        let (sender, receiver) = mpsc::channel::<PoolMessage>(size * 4);

        // Wrap the receiver in an `Arc` so each worker task can hold a clone.
        // tokio's mpsc receiver is not Clone, so we use a Mutex to share it.
        let receiver = Arc::new(tokio::sync::Mutex::new(receiver));

        for worker_id in 0..size {
            let rx = receiver.clone();
            let timeout_dur = sim_timeout;
            let bin = worker_bin.clone();

            // Each worker task is an independent async task.  It owns its child
            // process and loops waiting for messages from the shared channel.
            tokio::spawn(async move {
                worker_task(worker_id, rx, timeout_dur, bin).await;
            });
        }

        Ok(Self { sender })
    }

    /// Submit a simulation request to any available worker.
    ///
    /// Returns the simulation response when the worker completes.
    ///
    /// # Errors
    ///
    /// - `NgspiceError::PoolExhausted` — the pool's internal channel is closed
    ///   (only happens if the pool was dropped).
    /// - `NgspiceError::WorkerCrashed` — the worker process crashed during
    ///   this simulation (the pool will respawn it for the next request).
    /// - `NgspiceError::SimulationFailed("timeout")` — the worker exceeded
    ///   the configured simulation timeout.
    pub async fn run_simulation(
        &self,
        request: SimulationRequest,
    ) -> Result<SimulationResponse, NgspiceError> {
        // oneshot channel carries the response back to this caller.
        let (reply_tx, reply_rx) = oneshot::channel();

        self.sender
            .send((request, reply_tx))
            .await
            .map_err(|_| NgspiceError::PoolExhausted)?;

        // Wait for the worker task to send the response back.
        reply_rx.await.map_err(|_| {
            NgspiceError::WorkerCrashed("worker task dropped reply sender".to_string())
        })?
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Worker task (runs inside tokio::spawn)
// ─────────────────────────────────────────────────────────────────────────────

/// The async task that drives one worker child process.
///
/// Loops until the channel is closed (pool dropped), receiving messages and
/// forwarding them to the child process.  Respawns the child if it crashes.
async fn worker_task(
    worker_id: usize,
    rx: Arc<tokio::sync::Mutex<mpsc::Receiver<PoolMessage>>>,
    sim_timeout: Duration,
    bin: Arc<WorkerBinary>,
) {
    // Spawn the initial worker process.
    let mut worker = match WorkerProcess::spawn(&bin) {
        Ok(w) => w,
        Err(e) => {
            eprintln!("[pool] worker {worker_id}: failed to spawn — {e}");
            return;
        }
    };

    loop {
        // Acquire a message from the shared channel.
        let (request, reply_tx) = {
            let mut guard = rx.lock().await;
            match guard.recv().await {
                Some(msg) => msg,
                None => {
                    // Channel closed: pool was dropped.  Shut down gracefully.
                    eprintln!("[pool] worker {worker_id}: channel closed, exiting");
                    return;
                }
            }
        };

        // If the child crashed between requests, respawn before proceeding.
        if worker.has_exited() {
            eprintln!("[pool] worker {worker_id}: detected dead process, respawning");
            match WorkerProcess::spawn(&bin) {
                Ok(w) => worker = w,
                Err(e) => {
                    // Failed to respawn — report the error and try again on next request.
                    let _ = reply_tx.send(Err(NgspiceError::WorkerCrashed(format!(
                        "worker {worker_id} failed to respawn: {e}"
                    ))));
                    continue;
                }
            }
        }

        // Run the simulation.
        let result = worker.run(&request, sim_timeout).await;

        // If the worker crashed during this simulation, respawn it now so the
        // next request hits a fresh process.
        if let Err(NgspiceError::WorkerCrashed(ref msg)) = result {
            eprintln!("[pool] worker {worker_id}: crashed during simulation — {msg}");
            match WorkerProcess::spawn(&bin) {
                Ok(w) => {
                    worker = w;
                    eprintln!("[pool] worker {worker_id}: respawned successfully");
                }
                Err(e) => {
                    eprintln!("[pool] worker {worker_id}: respawn failed — {e}");
                    // We continue the loop; the next request will trigger another
                    // spawn attempt via `has_exited()`.
                }
            }
        }

        // Send the result back to the caller via the oneshot channel.
        // If the caller was cancelled (dropped their future), the send fails —
        // that is fine; we just discard the result.
        let _ = reply_tx.send(result);
    }
}
