// PyO3's #[pymethods] macro generates calls to unsafe functions inside what
// Rust 2024 now considers an "unsafe fn" context.  Suppress the resulting
// noise — the safety is upheld by PyO3's own invariants.
#![allow(unsafe_op_in_unsafe_fn)]

/// PyO3 Python bindings for the ngspice-rust worker pool.
///
/// Exposes:
///   - `SimulationPool`   — manages N worker processes; sync Python API over an
///                          internal tokio runtime.
///   - `LutConfig`        — transistor characterisation parameters.
///   - `TransistorLut`    — LUT result; array properties return numpy ndarrays.
///   - `SimulationResult` — raw simulation output with per-vector numpy arrays.
///   - `_run_worker()`    — internal function called by the `ngspice-worker`
///                          entry-point script to start the worker loop.
use std::{
    path::{Path, PathBuf},
    sync::Arc,
    sync::atomic::{AtomicU64, Ordering},
    time::Duration,
};

use ndarray::{Array1, Array2};
use numpy::{IntoPyArray, PyArray1, PyArray2};
use pyo3::{
    exceptions::{PyIOError, PyKeyError, PyRuntimeError, PyValueError},
    prelude::*,
    types::PyDict,
};

use crate::{
    error::NgspiceError,
    lut::{DeviceType, LutConfig, SweepRange, TransistorLut},
    pool::WorkerPool,
    protocol::{SimulationRequest, SimulationResponse},
};

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

/// Convert a `NgspiceError` into an appropriate Python exception.
fn to_py_err(e: NgspiceError) -> PyErr {
    match e {
        NgspiceError::InitFailed(msg) => {
            PyRuntimeError::new_err(format!("ngspice init failed: {msg}"))
        }
        NgspiceError::SimulationFailed(msg) => {
            PyRuntimeError::new_err(format!("simulation failed: {msg}"))
        }
        NgspiceError::WorkerCrashed(msg) => {
            PyRuntimeError::new_err(format!("worker crashed: {msg}"))
        }
        NgspiceError::Serialization(e) => {
            PyValueError::new_err(format!("serialization error: {e}"))
        }
        NgspiceError::Io(e) => PyIOError::new_err(e.to_string()),
        NgspiceError::PoolExhausted => PyRuntimeError::new_err("worker pool exhausted"),
    }
}

/// Find a vector by name, handling ngspice's two naming conventions:
///
/// - Numbered nodes → `"V(1)"`, `"V(2)"` (with V-wrapper)
/// - Named nodes    → `"out"`, `"in"` (bare name)
///
/// Accepts both forms interchangeably so `"v(out)"` finds `"out"` and vice versa.
fn find_vector<'a>(
    vectors: &'a [crate::protocol::VectorData],
    name: &str,
) -> Option<&'a crate::protocol::VectorData> {
    // 1. Exact case-insensitive match.
    if let Some(v) = vectors.iter().find(|v| v.name.eq_ignore_ascii_case(name)) {
        return Some(v);
    }
    // 2. Strip "V(" prefix and ")" suffix, then try the inner name.
    //    Handles: user asks for "v(out)" but vector is stored as "out".
    let lower = name.to_ascii_lowercase();
    if lower.starts_with("v(") && lower.ends_with(')') {
        let inner = &name[2..name.len() - 1];
        if let Some(v) = vectors.iter().find(|v| v.name.eq_ignore_ascii_case(inner)) {
            return Some(v);
        }
    }
    // 3. Try wrapping the bare name in "V()".
    //    Handles: user asks for "out" but vector is stored as "V(out)".
    let wrapped = format!("V({name})");
    vectors
        .iter()
        .find(|v| v.name.eq_ignore_ascii_case(&wrapped))
}

/// Convert a `Vec<f64>` into a 1-D numpy array (copies data).
fn to_array1<'py>(py: Python<'py>, data: Vec<f64>) -> Bound<'py, PyArray1<f64>> {
    Array1::from_vec(data).into_pyarray_bound(py)
}

/// Convert a `Vec<Vec<f64>>` (row-major) into a 2-D numpy array (copies data).
fn to_array2<'py>(py: Python<'py>, data: &[Vec<f64>]) -> Bound<'py, PyArray2<f64>> {
    let rows = data.len();
    let cols = if rows > 0 { data[0].len() } else { 0 };
    let flat: Vec<f64> = data.iter().flatten().copied().collect();
    Array2::from_shape_vec((rows, cols), flat)
        .expect("ragged Vec<Vec<f64>> — this is a bug in LUT generation")
        .into_pyarray_bound(py)
}

/// Auto-incrementing simulation ID used when callers don't supply one.
static SIM_COUNTER: AtomicU64 = AtomicU64::new(0);

fn next_sim_id() -> String {
    format!("py-{}", SIM_COUNTER.fetch_add(1, Ordering::Relaxed))
}

// ─────────────────────────────────────────────────────────────────────────────
// SimulationPool
// ─────────────────────────────────────────────────────────────────────────────

/// An ngspice worker pool.  Manages N worker processes and exposes a
/// synchronous Python API backed by an internal tokio runtime.
///
/// Usage::
///
///     pool = SimulationPool(workers=8, timeout_secs=120.0)
///
///     # Run an arbitrary SPICE netlist
///     result = pool.run_simulation(netlist, ["run"])
///     time = result.vector("time")   # numpy array
///
///     # Generate a MOSFET look-up table
///     config = LutConfig(model_file="sky130_fd_pr__nfet_01v8.lib",
///                        model_name="sky130_fd_pr__nfet_01v8")
///     lut = pool.generate_lut(config)
///     print(lut.id.shape)   # (37, 37)
#[pyclass(name = "SimulationPool")]
pub struct PySimulationPool {
    pool: Arc<WorkerPool>,
    runtime: tokio::runtime::Runtime,
    n_workers: usize,
}

#[pymethods]
impl PySimulationPool {
    /// Create a new pool.
    ///
    /// Args:
    ///     workers:      Number of parallel worker processes (default: CPU count).
    ///     timeout_secs: Per-simulation wall-clock timeout in seconds (default: 120).
    ///     worker_exe:   Optional path to the `ngspice-worker` binary.  When
    ///                   omitted the binary is located automatically.
    #[new]
    #[pyo3(signature = (workers=None, timeout_secs=120.0, worker_exe=None))]
    fn new(
        workers: Option<usize>,
        timeout_secs: f64,
        worker_exe: Option<String>,
    ) -> PyResult<Self> {
        let n = workers.unwrap_or_else(|| {
            std::thread::available_parallelism()
                .map(|n| n.get())
                .unwrap_or(1)
        });
        let timeout = Duration::from_secs_f64(timeout_secs);
        let exe = worker_exe.map(PathBuf::from);

        let runtime = tokio::runtime::Builder::new_multi_thread()
            .enable_all()
            .build()
            .map_err(|e| PyRuntimeError::new_err(format!("failed to build tokio runtime: {e}")))?;

        let pool = runtime
            .block_on(async { WorkerPool::new(n, timeout, exe).await })
            .map_err(to_py_err)?;

        Ok(Self {
            pool: Arc::new(pool),
            runtime,
            n_workers: n,
        })
    }

    /// Run an arbitrary SPICE netlist and return the simulation result.
    ///
    /// Args:
    ///     netlist:  Full SPICE netlist string, ending with `.end`.
    ///     commands: List of ngspice commands to execute, e.g. ``["run"]``.
    ///     id:       Optional correlation ID (auto-generated if omitted).
    ///
    /// Returns:
    ///     :class:`SimulationResult`
    #[pyo3(signature = (netlist, commands, id=None))]
    fn run_simulation(
        &self,
        py: Python<'_>,
        netlist: String,
        commands: Vec<String>,
        id: Option<String>,
    ) -> PyResult<PySimulationResult> {
        let request = SimulationRequest {
            id: id.unwrap_or_else(next_sim_id),
            netlist,
            commands,
            return_vectors: None,
        };
        let pool = self.pool.clone();
        let response = py
            .allow_threads(|| {
                self.runtime
                    .block_on(async { pool.run_simulation(request).await })
            })
            .map_err(to_py_err)?;
        Ok(PySimulationResult { inner: response })
    }

    /// Generate a transistor look-up table.
    ///
    /// Args:
    ///     config:   :class:`LutConfig` describing the device and sweep ranges.
    ///     n_chunks: Number of parallel Vgs chunks.  When omitted the pool
    ///               auto-selects based on grid size: each chunk targets ~50K
    ///               data points so that JSON IPC overhead stays low.  For
    ///               small grids this collapses to the worker count; for large
    ///               grids it scales up automatically.
    ///
    /// Returns:
    ///     :class:`TransistorLut`
    #[pyo3(signature = (config, n_chunks=None))]
    fn generate_lut(
        &self,
        py: Python<'_>,
        config: &PyLutConfig,
        n_chunks: Option<usize>,
    ) -> PyResult<PyTransistorLut> {
        let cfg = config.to_lut_config()?;
        let chunks = n_chunks.unwrap_or_else(|| auto_chunks(&cfg, self.n_workers));
        let pool = self.pool.clone();
        let lut = py
            .allow_threads(|| {
                self.runtime
                    .block_on(async { crate::lut::generate_lut(&pool, &cfg, chunks, None).await })
            })
            .map_err(to_py_err)?;
        Ok(PyTransistorLut { inner: lut })
    }

    fn __repr__(&self) -> String {
        format!("SimulationPool(workers={})", self.n_workers)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// LutConfig
// ─────────────────────────────────────────────────────────────────────────────

/// Transistor characterisation configuration.
///
/// Usage::
///
///     # Built-in Level-3 NMOS model
///     cfg = LutConfig()
///
///     # External model file (recommended for real PDKs)
///     cfg = LutConfig(
///         device_type="nmos",
///         model_file="/path/to/pdk/nfet.lib",
///         model_name="nfet_01v8",
///         width=1e-6,
///         length=150e-9,
///         vgs=(0.0, 1.8, 0.05),
///         vds=(0.0, 1.8, 0.05),
///     )
#[pyclass(name = "LutConfig")]
#[derive(Clone)]
pub struct PyLutConfig {
    device_type: String,
    model_card: String,
    model_file: Option<String>,
    model_name: String,
    width: f64,
    length: f64,
    vgs: (f64, f64, f64),
    vds: (f64, f64, f64),
    vbs: f64,
}

#[pymethods]
impl PyLutConfig {
    /// Create a LUT configuration.
    ///
    /// Args:
    ///     device_type: ``"nmos"`` or ``"pmos"`` (default: ``"nmos"``).
    ///     model_file:  Path to a SPICE ``.lib`` / ``.mod`` file.  Takes
    ///                  priority over ``model_card``.
    ///     model_card:  Inline ``.model`` card string.  Use when you don't
    ///                  have a file.  Ignored if ``model_file`` is set.
    ///     model_name:  Model name on the M-line.  Defaults to ``"nch"`` /
    ///                  ``"pch"`` depending on ``device_type``.
    ///     width:       Gate width in metres (default: 10 µm).
    ///     length:      Gate length in metres (default: 500 nm).
    ///     vgs:         ``(start, stop, step)`` sweep in volts.
    ///     vds:         ``(start, stop, step)`` sweep in volts.
    ///     vbs:         Fixed bulk-source voltage (default: 0 V).
    #[new]
    #[pyo3(signature = (
        device_type = "nmos",
        width = 10e-6,
        length = 500e-9,
        vgs = (0.0, 1.8, 0.05),
        vds = (0.0, 1.8, 0.05),
        vbs = 0.0,
        model_card = "",
        model_file = None,
        model_name = None,
    ))]
    fn new(
        device_type: &str,
        width: f64,
        length: f64,
        vgs: (f64, f64, f64),
        vds: (f64, f64, f64),
        vbs: f64,
        model_card: &str,
        model_file: Option<String>,
        model_name: Option<&str>,
    ) -> PyResult<Self> {
        let default_name = if device_type == "pmos" { "pch" } else { "nch" };
        Ok(Self {
            device_type: device_type.to_string(),
            model_card: model_card.to_string(),
            model_file,
            model_name: model_name.unwrap_or(default_name).to_string(),
            width,
            length,
            vgs,
            vds,
            vbs,
        })
    }

    #[getter]
    fn device_type(&self) -> &str {
        &self.device_type
    }
    #[getter]
    fn model_card(&self) -> &str {
        &self.model_card
    }
    #[getter]
    fn model_file(&self) -> Option<&str> {
        self.model_file.as_deref()
    }
    #[getter]
    fn model_name(&self) -> &str {
        &self.model_name
    }
    #[getter]
    fn width(&self) -> f64 {
        self.width
    }
    #[getter]
    fn length(&self) -> f64 {
        self.length
    }
    #[getter]
    fn vgs(&self) -> (f64, f64, f64) {
        self.vgs
    }
    #[getter]
    fn vds(&self) -> (f64, f64, f64) {
        self.vds
    }
    #[getter]
    fn vbs(&self) -> f64 {
        self.vbs
    }

    fn __repr__(&self) -> String {
        format!(
            "LutConfig(device_type='{}', model_name='{}', W={:.3e}, L={:.3e})",
            self.device_type, self.model_name, self.width, self.length,
        )
    }
}

impl PyLutConfig {
    /// Convert to the internal `LutConfig` type.
    pub fn to_lut_config(&self) -> PyResult<LutConfig> {
        let device_type = match self.device_type.as_str() {
            "nmos" => DeviceType::Nmos,
            "pmos" => DeviceType::Pmos,
            other => {
                return Err(PyValueError::new_err(format!(
                    "device_type must be 'nmos' or 'pmos', got '{other}'"
                )));
            }
        };
        Ok(LutConfig {
            device_type,
            model_card: self.model_card.clone(),
            model_file: self.model_file.clone(),
            model_name: self.model_name.clone(),
            width: self.width,
            length: self.length,
            vgs: SweepRange {
                start: self.vgs.0,
                stop: self.vgs.1,
                step: self.vgs.2,
            },
            vds: SweepRange {
                start: self.vds.0,
                stop: self.vds.1,
                step: self.vds.2,
            },
            vbs: self.vbs,
        })
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// TransistorLut
// ─────────────────────────────────────────────────────────────────────────────

/// A fully characterised transistor look-up table.
///
/// 2-D arrays are indexed ``[vgs_idx, vds_idx]``.
///
/// Usage::
///
///     lut = pool.generate_lut(config)
///
///     import matplotlib.pyplot as plt
///     import numpy as np
///
///     VGS, VDS = np.meshgrid(lut.vgs, lut.vds, indexing='ij')
///     plt.contourf(VGS, VDS, lut.id)
///     plt.colorbar(label='Id (A)')
///     lut.to_csv("nfet_lut.csv")
#[pyclass(name = "TransistorLut")]
pub struct PyTransistorLut {
    pub inner: TransistorLut,
}

#[pymethods]
impl PyTransistorLut {
    /// Vgs axis values (1-D numpy array, shape ``(n_vgs,)``).
    #[getter]
    fn vgs<'py>(&self, py: Python<'py>) -> Bound<'py, PyArray1<f64>> {
        to_array1(py, self.inner.vgs.clone())
    }

    /// Vds axis values (1-D numpy array, shape ``(n_vds,)``).
    #[getter]
    fn vds<'py>(&self, py: Python<'py>) -> Bound<'py, PyArray1<f64>> {
        to_array1(py, self.inner.vds.clone())
    }

    /// Drain current Id in amperes (2-D numpy array, shape ``(n_vgs, n_vds)``).
    #[getter]
    fn id<'py>(&self, py: Python<'py>) -> Bound<'py, PyArray2<f64>> {
        to_array2(py, &self.inner.id)
    }

    /// Transconductance gm = ∂Id/∂Vgs in siemens (shape ``(n_vgs, n_vds)``).
    #[getter]
    fn gm<'py>(&self, py: Python<'py>) -> Bound<'py, PyArray2<f64>> {
        to_array2(py, &self.inner.gm)
    }

    /// Output conductance gds = ∂Id/∂Vds in siemens (shape ``(n_vgs, n_vds)``).
    #[getter]
    fn gds<'py>(&self, py: Python<'py>) -> Bound<'py, PyArray2<f64>> {
        to_array2(py, &self.inner.gds)
    }

    /// Write a ``Vgs,Vds,Id,gm,gds`` CSV file.
    fn to_csv(&self, path: &str) -> PyResult<()> {
        self.inner
            .write_csv(Path::new(path))
            .map_err(|e| PyIOError::new_err(e.to_string()))
    }

    fn __repr__(&self) -> String {
        format!(
            "TransistorLut(n_vgs={}, n_vds={})",
            self.inner.vgs.len(),
            self.inner.vds.len(),
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// SimulationResult
// ─────────────────────────────────────────────────────────────────────────────

/// The result of a single ngspice simulation.
///
/// Usage::
///
///     result = pool.run_simulation(netlist, ["run"])
///     if not result.success:
///         print("failed:", result.error)
///     else:
///         time = result.vector("time")        # numpy array
///         vout = result.vector("v(out)")
///         all_vecs = result.vectors_dict()    # dict[str, np.ndarray]
#[pyclass(name = "SimulationResult")]
pub struct PySimulationResult {
    inner: SimulationResponse,
}

#[pymethods]
impl PySimulationResult {
    /// Correlation ID echoed from the request.
    #[getter]
    fn id(&self) -> &str {
        &self.inner.id
    }
    /// ``True`` if the simulation completed without ngspice errors.
    #[getter]
    fn success(&self) -> bool {
        self.inner.success
    }
    /// ngspice log lines captured during the simulation.
    #[getter]
    fn log(&self) -> Vec<String> {
        self.inner.log.clone()
    }
    /// First error message seen, if any.
    #[getter]
    fn error(&self) -> Option<&str> {
        self.inner.error.as_deref()
    }

    /// List of all vector names available in this result.
    fn vector_names(&self) -> Vec<String> {
        self.inner.vectors.iter().map(|v| v.name.clone()).collect()
    }

    /// Return a single simulation vector as a 1-D numpy array.
    ///
    /// Lookup is case-insensitive.  ngspice uses different naming conventions
    /// depending on whether circuit nodes are numbered or named:
    ///
    /// - Numbered nodes (``1``, ``2``) → vector named ``"V(1)"``, ``"V(2)"``
    /// - Named nodes (``out``, ``in``)  → vector named ``"out"``, ``"in"``
    ///
    /// To simplify user code, this method accepts both forms interchangeably:
    /// ``result.vector("v(out)")`` and ``result.vector("out")`` both work.
    ///
    /// Raises ``KeyError`` if the vector is not found under any alias.
    fn vector<'py>(&self, py: Python<'py>, name: &str) -> PyResult<Bound<'py, PyArray1<f64>>> {
        let vec = find_vector(&self.inner.vectors, name).ok_or_else(|| {
            let available: Vec<_> = self.inner.vectors.iter().map(|v| v.name.as_str()).collect();
            PyKeyError::new_err(format!(
                "vector '{name}' not found; available: {available:?}"
            ))
        })?;
        Ok(to_array1(py, vec.data.clone()))
    }

    /// Return all simulation vectors as a ``dict[str, np.ndarray]``.
    fn vectors_dict<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyDict>> {
        let dict = PyDict::new_bound(py);
        for v in &self.inner.vectors {
            dict.set_item(&v.name, to_array1(py, v.data.clone()))?;
        }
        Ok(dict)
    }

    /// Return a complex AC vector as a 1-D numpy ``complex128`` array.
    ///
    /// Raises ``KeyError`` if the vector is not found.
    /// Raises ``ValueError`` if the vector has no complex data (not an AC result).
    fn complex_vector<'py>(
        &self,
        py: Python<'py>,
        name: &str,
    ) -> PyResult<Bound<'py, numpy::PyArray1<numpy::Complex64>>> {
        let vec = find_vector(&self.inner.vectors, name).ok_or_else(|| {
            let available: Vec<_> = self.inner.vectors.iter().map(|v| v.name.as_str()).collect();
            PyKeyError::new_err(format!(
                "vector '{name}' not found; available: {available:?}"
            ))
        })?;
        let cpx = vec.complex_data.as_ref().ok_or_else(|| {
            PyValueError::new_err(format!(
                "vector '{name}' has no complex data (not an AC analysis result)"
            ))
        })?;
        let arr: Vec<numpy::Complex64> = cpx
            .iter()
            .map(|&(re, im)| numpy::Complex64::new(re, im))
            .collect();
        use ndarray::Array1;
        use numpy::IntoPyArray;
        Ok(Array1::from_vec(arr).into_pyarray_bound(py))
    }

    /// Parsed ``.meas`` / ``.measure`` results as a ``dict[str, float]``.
    ///
    /// Empty when no ``.measure`` statements were used in the netlist.
    #[getter]
    fn measures<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyDict>> {
        let dict = PyDict::new_bound(py);
        for (name, value) in &self.inner.measures {
            dict.set_item(name, value)?;
        }
        Ok(dict)
    }

    fn __repr__(&self) -> String {
        format!(
            "SimulationResult(id='{}', success={}, vectors={})",
            self.inner.id,
            self.inner.success,
            self.inner.vectors.len(),
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Worker entry point
// ─────────────────────────────────────────────────────────────────────────────

/// Internal function — runs the ngspice worker loop.
///
/// This is called by the ``ngspice-worker`` console-script entry point
/// installed alongside the Python package.  Do not call this from your own
/// code; use :class:`SimulationPool` instead.
#[pyfunction]
fn _run_worker(py: Python<'_>) -> PyResult<()> {
    // Release the GIL while the worker blocks on stdin — the worker loop is
    // pure Rust I/O and does not need Python at all.
    py.allow_threads(|| crate::worker::run_worker())
        .map_err(to_py_err)
}

// ─────────────────────────────────────────────────────────────────────────────
// Chunk auto-selection
// ─────────────────────────────────────────────────────────────────────────────

/// Choose the number of Vgs chunks automatically.
///
/// The bottleneck at large grid sizes is JSON IPC: each worker serialises its
/// slice of the Id grid into JSON and pipes it back to the dispatcher.  A
/// single f64 costs ~12-15 bytes as JSON text, so a 450 × 3601 chunk produces
/// ~24 MB of JSON — serialisation and pipe I/O dominate over simulation time.
///
/// Target: keep each chunk's response to ≤ `TARGET` data points so JSON
/// overhead is at most a few milliseconds.  At small grids this collapses to
/// `min_chunks` (= worker count); at large grids it scales up.
fn auto_chunks(cfg: &LutConfig, min_chunks: usize) -> usize {
    const TARGET: usize = 50_000; // data points per chunk response
    let n_vds = cfg.vds.num_points().max(1);
    let vgs_per_chunk = (TARGET / n_vds).max(1);
    let auto = (cfg.vgs.num_points() + vgs_per_chunk - 1) / vgs_per_chunk;
    auto.max(min_chunks)
}

// ─────────────────────────────────────────────────────────────────────────────
// Module registration
// ─────────────────────────────────────────────────────────────────────────────

pub fn register(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PySimulationPool>()?;
    m.add_class::<PyLutConfig>()?;
    m.add_class::<PyTransistorLut>()?;
    m.add_class::<PySimulationResult>()?;
    m.add_function(wrap_pyfunction!(_run_worker, m)?)?;
    Ok(())
}
