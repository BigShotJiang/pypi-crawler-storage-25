def main():
    print("Hello from ngspice-rust!")


if __name__ == "__main__":
    main()
