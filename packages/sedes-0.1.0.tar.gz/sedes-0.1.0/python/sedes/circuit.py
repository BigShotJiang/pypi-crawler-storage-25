"""
Circuit builder — programmatic SPICE netlist construction.

Usage::

    from sedes import Circuit

    ckt = (Circuit("RC filter")
        .V("v1", "in", "0", "sin(0 1 1k)")
        .R("r1", "in", "out", "1k")
        .C("c1", "out", "0", "100n")
        .tran("1u", "2m"))

    result = ckt.run(pool)          # returns TranResult
    print(result.time)              # numpy array
    print(result.vector("v(out)"))  # numpy array

"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .sedes import SimulationPool


# ─────────────────────────────────────────────────────────────────────────────
# Internal component representation
# ─────────────────────────────────────────────────────────────────────────────

class _Line:
    """A raw SPICE netlist line (component, dot-command, or comment)."""

    def __init__(self, line: str):
        self._line = line

    @property
    def name(self) -> str | None:
        """Component name (first token), or None for dot-commands."""
        stripped = self._line.strip()
        if not stripped or stripped.startswith("*") or stripped.startswith("."):
            return None
        return stripped.split()[0].lower()

    def to_spice(self) -> str:
        return self._line


# ─────────────────────────────────────────────────────────────────────────────
# Circuit
# ─────────────────────────────────────────────────────────────────────────────

class Circuit:
    """
    Programmatic SPICE netlist builder and container.

    Can be constructed from scratch or loaded from an existing file via
    :meth:`Circuit.from_file`.  All mutating methods return *self* so calls
    can be chained.

    The final netlist is produced by :meth:`to_spice`.  :meth:`run` renders
    the netlist and submits it to a :class:`~sedes.SimulationPool`.
    """

    def __init__(self, title: str = "circuit"):
        self._title = title
        self._lines: list[_Line] = []           # components, models, includes …
        self._analyses: list[str] = []           # .op / .tran / .ac …
        self._measures: list[str] = []           # .meas lines
        self._options: list[str] = []            # .options lines
        # Analysis type tag set by the last analysis method — used by run() to
        # wrap the result in the right typed class.
        self._analysis_type: str | None = None

    # ── Class constructor: load from file ────────────────────────────────────

    @classmethod
    def from_file(cls, path: str) -> "Circuit":
        """
        Parse an existing ``.cir`` / ``.net`` / ``.spice`` file into a
        mutable :class:`Circuit`.

        Continuation lines (starting with ``+``) are joined to the preceding
        line.  ``.include`` directives are resolved relative to *path*.

        Args:
            path: Path to the SPICE netlist file.

        Returns:
            A :class:`Circuit` whose title, components, models, and analyses
            reflect the file contents.  You can modify it and call
            :meth:`run` or :meth:`to_spice`.
        """
        from .parser import parse_file
        return parse_file(path)

    # ── Passive components ───────────────────────────────────────────────────

    def R(self, name: str, n1: str, n2: str, value: str) -> "Circuit":
        """
        Add a resistor.

        *name* is the full component name including the type letter, e.g.
        ``"r1"``, ``"r_load"``.  The line generated is ``<name> <n1> <n2> <value>``.
        """
        return self._add(f"{name} {n1} {n2} {value}")

    def C(self, name: str, n1: str, n2: str, value: str) -> "Circuit":
        """Add a capacitor (name must start with ``C``)."""
        return self._add(f"{name} {n1} {n2} {value}")

    def L(self, name: str, n1: str, n2: str, value: str) -> "Circuit":
        """Add an inductor (name must start with ``L``)."""
        return self._add(f"{name} {n1} {n2} {value}")

    # ── Independent sources ──────────────────────────────────────────────────

    def V(self, name: str, n_plus: str, n_minus: str, value: str) -> "Circuit":
        """
        Add a voltage source (name must start with ``V``).

        *value* can be a DC value, ``dc <v>``, ``ac <mag> [phase]``,
        ``sin(<...>)``, ``pulse(<...>)``, ``pwl(<...>)``, etc.

        Example::

            ckt.V("vdd", "vdd", "0", "dc 3.3")
            ckt.V("vin", "in", "0", "sin(0 1 1k)")
            ckt.V("vac", "in", "0", "ac 1")
        """
        return self._add(f"{name} {n_plus} {n_minus} {value}")

    def I(self, name: str, n_plus: str, n_minus: str, value: str) -> "Circuit":
        """Add a current source (name must start with ``I``)."""
        return self._add(f"{name} {n_plus} {n_minus} {value}")

    # ── Semiconductor devices ────────────────────────────────────────────────

    def M(
        self,
        name: str,
        drain: str,
        gate: str,
        source: str,
        bulk: str,
        model: str,
        **params,
    ) -> "Circuit":
        """
        Add a MOSFET (name must start with ``M``).

        Extra keyword arguments are appended as ``key=value`` tokens, e.g.
        ``W="1e-6"``, ``L="100e-9"``, ``m=4``.

        Example::

            ckt.M("m1", "drain", "gate", "source", "bulk", "nch",
                  W="1e-6", L="100e-9")
        """
        extras = " ".join(f"{k}={v}" for k, v in params.items())
        return self._add(f"{name} {drain} {gate} {source} {bulk} {model} {extras}".rstrip())

    def D(self, name: str, anode: str, cathode: str, model: str, **params) -> "Circuit":
        """Add a diode (name must start with ``D``)."""
        extras = " ".join(f"{k}={v}" for k, v in params.items())
        return self._add(f"{name} {anode} {cathode} {model} {extras}".rstrip())

    def Q(
        self,
        name: str,
        collector: str,
        base: str,
        emitter: str,
        model: str,
        **params,
    ) -> "Circuit":
        """Add a BJT (name must start with ``Q``)."""
        extras = " ".join(f"{k}={v}" for k, v in params.items())
        return self._add(f"{name} {collector} {base} {emitter} {model} {extras}".rstrip())

    # ── Dependent sources ────────────────────────────────────────────────────

    def E(self, name: str, n_plus: str, n_minus: str, nc_plus: str, nc_minus: str, gain: str) -> "Circuit":
        """Add a voltage-controlled voltage source (name starts with ``E``)."""
        return self._add(f"{name} {n_plus} {n_minus} {nc_plus} {nc_minus} {gain}")

    def F(self, name: str, n_plus: str, n_minus: str, vsource: str, gain: str) -> "Circuit":
        """Add a current-controlled current source (name starts with ``F``)."""
        return self._add(f"{name} {n_plus} {n_minus} {vsource} {gain}")

    def G(self, name: str, n_plus: str, n_minus: str, nc_plus: str, nc_minus: str, gm: str) -> "Circuit":
        """Add a voltage-controlled current source (name starts with ``G``)."""
        return self._add(f"{name} {n_plus} {n_minus} {nc_plus} {nc_minus} {gm}")

    def H(self, name: str, n_plus: str, n_minus: str, vsource: str, gain: str) -> "Circuit":
        """Add a current-controlled voltage source (name starts with ``H``)."""
        return self._add(f"{name} {n_plus} {n_minus} {vsource} {gain}")

    # ── Subcircuit support ───────────────────────────────────────────────────

    def X(self, name: str, subckt: str, *nodes: str, **params) -> "Circuit":
        """
        Instantiate a subcircuit (name must start with ``X``).

        Example::

            ckt.X("xbuf", "inv_2x", "in", "out", "vdd", "vss")
        """
        node_str = " ".join(nodes)
        extras = " ".join(f"{k}={v}" for k, v in params.items())
        line = f"{name} {node_str} {subckt}"
        if extras:
            line += f" {extras}"
        return self._add(line)

    # ── Dot-commands ─────────────────────────────────────────────────────────

    def include(self, path: str) -> "Circuit":
        """Add a ``.include <path>`` directive."""
        return self._add(f".include {path}")

    def lib(self, path: str, section: str | None = None) -> "Circuit":
        """Add a ``.lib <path> [section]`` directive."""
        if section:
            return self._add(f".lib {path} {section}")
        return self._add(f".lib {path}")

    def model(self, card: str) -> "Circuit":
        """
        Add a ``.model`` card.

        *card* should be the full model string starting with ``.model``.

        Example::

            ckt.model(".model D1N4148 D(IS=2.52e-9 N=1.752 ...)")
        """
        return self._add(card if card.strip().startswith(".model") else f".model {card}")

    def subckt(self, definition: str) -> "Circuit":
        """
        Add a raw ``.subckt`` / ``.ends`` block.

        *definition* should be the complete multi-line subcircuit text.
        """
        for line in definition.strip().splitlines():
            self._lines.append(_Line(line))
        return self

    def param(self, name: str, value: str) -> "Circuit":
        """Add a ``.param <name>=<value>`` directive."""
        return self._add(f".param {name}={value}")

    def options(self, **opts) -> "Circuit":
        """
        Add a ``.options`` directive.

        Example::

            ckt.options(ABSTOL="1e-12", RELTOL="1e-4")
        """
        opt_str = " ".join(f"{k}={v}" for k, v in opts.items())
        self._options.append(f".options {opt_str}")
        return self

    # ── Analysis commands ────────────────────────────────────────────────────

    def op(self) -> "Circuit":
        """Add a DC operating-point analysis (``.op``)."""
        self._analyses = [".op"]
        self._analysis_type = "op"
        return self

    def dc(
        self,
        source: str,
        start: float,
        stop: float,
        step: float,
        source2: str | None = None,
        start2: float | None = None,
        stop2: float | None = None,
        step2: float | None = None,
    ) -> "Circuit":
        """
        Add a DC sweep analysis.

        For a nested two-source sweep supply all ``*2`` arguments.

        Example::

            ckt.dc("vgs", 0, 1.8, 0.01)
            ckt.dc("vgs", 0, 1.8, 0.01, "vds", 0, 1.8, 0.1)
        """
        cmd = f".dc {source} {start} {stop} {step}"
        if source2 is not None:
            cmd += f" {source2} {start2} {stop2} {step2}"
        self._analyses = [cmd]
        self._analysis_type = "dc"
        return self

    def tran(
        self,
        step: str,
        stop: str,
        start: str = "0",
        uic: bool = False,
    ) -> "Circuit":
        """
        Add a transient analysis (``.tran``).

        Args:
            step:  Time step (e.g. ``"1u"``).
            stop:  Stop time (e.g. ``"2m"``).
            start: Start time (default ``"0"``).
            uic:   Use initial conditions (adds ``uic`` flag).
        """
        cmd = f".tran {step} {stop} {start}"
        if uic:
            cmd += " uic"
        self._analyses = [cmd]
        self._analysis_type = "tran"
        return self

    def ac(
        self,
        variation: str,
        n_points: int,
        fstart: float,
        fstop: float,
    ) -> "Circuit":
        """
        Add an AC small-signal analysis (``.ac``).

        Args:
            variation: ``"dec"`` (decades), ``"oct"`` (octaves), or ``"lin"``
                       (linear).
            n_points:  Points per decade/octave or total linear points.
            fstart:    Start frequency in Hz.
            fstop:     Stop frequency in Hz.

        Example::

            ckt.ac("dec", 100, 1, 1e9)
        """
        self._analyses = [f".ac {variation} {n_points} {fstart} {fstop}"]
        self._analysis_type = "ac"
        return self

    def noise(
        self,
        output: str,
        source: str,
        variation: str,
        n_points: int,
        fstart: float,
        fstop: float,
        pts_summary: int | None = None,
    ) -> "Circuit":
        """
        Add a noise analysis (``.noise``).

        Args:
            output:   Output node (e.g. ``"V(out)"``).
            source:   Input noise source name (e.g. ``"Vin"``).
            variation: ``"dec"``, ``"oct"``, or ``"lin"``.
            n_points:  Points per decade / total.
            fstart:    Start frequency in Hz.
            fstop:     Stop frequency in Hz.
            pts_summary: Optional interval for summary output (default: 1).
        """
        cmd = f".noise {output} {source} {variation} {n_points} {fstart} {fstop}"
        if pts_summary is not None:
            cmd += f" {pts_summary}"
        self._analyses = [cmd]
        self._analysis_type = "noise"
        return self

    def sens(self, output_var: str, ac: bool = False) -> "Circuit":
        """
        Add a sensitivity analysis (``.sens``).

        Args:
            output_var: Output variable (e.g. ``"V(out)"``).
            ac:         If True, runs AC sensitivity (requires ``.ac`` to also
                        be present).
        """
        cmd = f".sens {output_var}"
        if ac:
            cmd += " ac"
        self._analyses.append(cmd)
        self._analysis_type = "sens"
        return self

    def tf(self, output_var: str, input_source: str) -> "Circuit":
        """
        Add a small-signal transfer function analysis (``.tf``).

        Args:
            output_var:   Output variable (e.g. ``"V(out)"``).
            input_source: Input source name (e.g. ``"Vin"``).
        """
        self._analyses = [f".tf {output_var} {input_source}"]
        self._analysis_type = "tf"
        return self

    def measure(
        self,
        analysis: str,
        name: str,
        *args: str,
    ) -> "Circuit":
        """
        Add a ``.meas`` directive.

        Args:
            analysis: Analysis type (e.g. ``"tran"``, ``"ac"``).
            name:     Measurement label.
            *args:    Remaining tokens (keyword=value pairs as strings).

        Example::

            ckt.measure("tran", "vout_max", "MAX V(out)")
            ckt.measure("tran", "tpHL",
                        "TRIG V(in) VAL=0.9 FALL=1",
                        "TARG V(out) VAL=0.9 FALL=1")
        """
        tokens = " ".join(args)
        self._measures.append(f".meas {analysis} {name} {tokens}")
        return self

    # ── Component access / modification ──────────────────────────────────────

    def __getitem__(self, name: str) -> _Line:
        """
        Retrieve a component line by name (case-insensitive).

        Raises ``KeyError`` if not found.
        """
        key = name.lower()
        for line in self._lines:
            if line.name == key:
                return line
        raise KeyError(f"component '{name}' not found in circuit")

    def remove(self, name: str) -> "Circuit":
        """
        Remove a component by name (case-insensitive).

        Raises ``KeyError`` if not found.
        """
        key = name.lower()
        before = len(self._lines)
        self._lines = [ln for ln in self._lines if ln.name != key]
        if len(self._lines) == before:
            raise KeyError(f"component '{name}' not found in circuit")
        return self

    def replace(self, name: str, new_line: str) -> "Circuit":
        """
        Replace a component line by name.  The new line should start with
        the component letter + name (e.g. ``"R1 in out 2.2k"``).
        """
        key = name.lower()
        for i, line in enumerate(self._lines):
            if line.name == key:
                self._lines[i] = _Line(new_line)
                return self
        raise KeyError(f"component '{name}' not found in circuit")

    # ── Rendering ────────────────────────────────────────────────────────────

    def to_spice(self) -> str:
        """
        Render the circuit to a SPICE netlist string.

        The title line is always first; ``.end`` is always last.
        """
        parts = [self._title]
        parts.extend(ln.to_spice() for ln in self._lines)
        parts.extend(self._options)
        parts.extend(self._analyses)
        parts.extend(self._measures)
        parts.append(".end")
        return "\n".join(parts)

    def __str__(self) -> str:
        return self.to_spice()

    def __repr__(self) -> str:
        n_components = sum(1 for ln in self._lines if ln.name is not None)
        return (
            f"Circuit(title={self._title!r}, "
            f"components={n_components}, "
            f"analysis={self._analysis_type!r})"
        )

    # ── Simulation ───────────────────────────────────────────────────────────

    def run(self, pool: "SimulationPool", id: str | None = None):
        """
        Render the circuit to a SPICE netlist and run it on *pool*.

        Returns a typed result object depending on the last analysis added:

        - ``.op()``     → :class:`~sedes.results.OpResult`
        - ``.tran()``   → :class:`~sedes.results.TranResult`
        - ``.dc()``     → :class:`~sedes.results.DCResult`
        - ``.ac()``     → :class:`~sedes.results.ACResult`
        - ``.noise()``  → :class:`~sedes.results.NoiseResult`
        - otherwise     → :class:`~sedes.SimulationResult`

        Args:
            pool: A :class:`~sedes.SimulationPool` instance.
            id:   Optional correlation ID.
        """
        from .results import _wrap_result
        netlist = self.to_spice()
        raw = pool.run_simulation(netlist, ["run"], id=id)
        return _wrap_result(raw, self._analysis_type)

    # ── Internal helpers ─────────────────────────────────────────────────────

    def _add(self, line: str) -> "Circuit":
        self._lines.append(_Line(line))
        return self

    def _add_raw_analysis(self, line: str, atype: str) -> "Circuit":
        """Used by the parser to inject analysis lines verbatim."""
        self._analyses.append(line)
        self._analysis_type = atype
        return self
