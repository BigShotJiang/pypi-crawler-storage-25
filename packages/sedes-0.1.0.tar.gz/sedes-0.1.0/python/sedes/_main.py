"""
Entry point for the `ngspice-worker` console script.

This module is called by the script installed into the virtualenv's bin/
directory when the Python package is installed via pip / maturin develop.
It delegates immediately to the Rust worker loop (releasing the GIL) so
startup overhead is the only Python cost.
"""


def run_worker() -> None:
    """Start the ngspice worker process loop (blocking, never returns normally)."""
    import sedes  # noqa: PLC0415  (import inside function is intentional)
    sedes._run_worker()
