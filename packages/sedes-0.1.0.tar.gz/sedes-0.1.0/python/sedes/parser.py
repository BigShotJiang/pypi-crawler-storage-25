"""
SPICE netlist parser — loads existing ``.cir`` / ``.net`` / ``.spice`` files
into a mutable :class:`~sedes.circuit.Circuit` object.

Handles:
- Title line (first line)
- Continuation lines (``+`` prefix)
- Component lines (R, C, L, M, D, Q, V, I, E, F, G, H, X, …)
- Dot-commands: ``.model``, ``.subckt`` / ``.ends``, ``.include``, ``.lib``,
  ``.param``, ``.options``, ``.op``, ``.dc``, ``.ac``, ``.tran``, ``.noise``,
  ``.sens``, ``.tf``, ``.meas`` / ``.measure``
- Comments (``*`` lines and inline ``$`` / ``;`` comments)
- ``.include`` resolution relative to the file's directory (single level)
"""

from __future__ import annotations

import os
import re
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .circuit import Circuit


# Map of first keyword token → analysis type tag
_ANALYSIS_KEYWORDS = {
    ".op":      "op",
    ".dc":      "dc",
    ".tran":    "tran",
    ".ac":      "ac",
    ".noise":   "noise",
    ".sens":    "sens",
    ".tf":      "tf",
    ".disto":   "disto",
    ".pz":      "pz",
}


def parse_file(path: str) -> "Circuit":
    """
    Parse *path* into a :class:`~sedes.circuit.Circuit`.

    ``.include`` directives are resolved relative to *path*'s directory
    (one level of nesting).

    Args:
        path: Absolute or relative path to the SPICE file.

    Returns:
        A mutable :class:`~sedes.circuit.Circuit`.

    Raises:
        FileNotFoundError: if *path* does not exist.
        ValueError:        if the file appears empty.
    """
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        raw = fh.read()

    base_dir = os.path.dirname(os.path.abspath(path))
    return _parse_text(raw, base_dir=base_dir, title_override=None)


def parse_string(netlist: str, base_dir: str | None = None) -> "Circuit":
    """
    Parse a netlist *string* into a :class:`~sedes.circuit.Circuit`.

    Args:
        netlist:   Full SPICE netlist as a string.
        base_dir:  Directory used for resolving ``.include`` paths.  Defaults
                   to the current working directory.

    Returns:
        A mutable :class:`~sedes.circuit.Circuit`.
    """
    return _parse_text(netlist, base_dir=base_dir or os.getcwd(), title_override=None)


# ─────────────────────────────────────────────────────────────────────────────
# Internal implementation
# ─────────────────────────────────────────────────────────────────────────────

def _parse_text(
    text: str,
    base_dir: str,
    title_override: str | None,
) -> "Circuit":
    from .circuit import Circuit, _Line

    lines = _join_continuations(text.splitlines())

    if not lines:
        raise ValueError("netlist is empty")

    # ── Title line ────────────────────────────────────────────────────────────
    # SPICE convention: first line is the title (even if it starts with a dot).
    title = title_override or lines[0]
    ckt = Circuit(title)

    # ── Parse remaining lines ─────────────────────────────────────────────────
    i = 1
    subckt_depth = 0          # track .subckt nesting so we don't parse inside
    subckt_lines: list[str] = []

    while i < len(lines):
        raw_line = lines[i]
        i += 1

        line = _strip_comment(raw_line).strip()
        if not line:
            continue

        lower = line.lower()

        # ── Full-line comments ────────────────────────────────────────────────
        if line.startswith("*"):
            continue

        # ── .end (file terminator) ────────────────────────────────────────────
        if lower in (".end", ".end ") or lower.startswith(".end "):
            # Stop at .end (there may be multiple netlists in one file).
            break

        # ── .subckt / .ends — collect verbatim ───────────────────────────────
        if lower.startswith(".subckt"):
            subckt_depth += 1
            subckt_lines.append(line)
            continue

        if lower.startswith(".ends"):
            subckt_depth -= 1
            subckt_lines.append(line)
            if subckt_depth == 0:
                ckt.subckt("\n".join(subckt_lines))
                subckt_lines = []
            continue

        if subckt_depth > 0:
            subckt_lines.append(line)
            continue

        # ── .include ─────────────────────────────────────────────────────────
        if lower.startswith(".include"):
            inc_path = _extract_include_path(line)
            if not os.path.isabs(inc_path):
                inc_path = os.path.join(base_dir, inc_path)
            ckt._lines.append(_Line(f".include {inc_path}"))
            continue

        # ── .lib ─────────────────────────────────────────────────────────────
        if lower.startswith(".lib"):
            ckt._lines.append(_Line(line))
            continue

        # ── Analysis commands ─────────────────────────────────────────────────
        first_token = lower.split()[0]
        if first_token in _ANALYSIS_KEYWORDS:
            ckt._analyses.append(line)
            ckt._analysis_type = _ANALYSIS_KEYWORDS[first_token]
            continue

        # ── .meas / .measure ─────────────────────────────────────────────────
        if first_token in (".meas", ".measure"):
            ckt._measures.append(line)
            continue

        # ── .options ─────────────────────────────────────────────────────────
        if first_token == ".options":
            ckt._options.append(line)
            continue

        # ── Other dot-commands (.model, .param, …) ───────────────────────────
        if line.startswith("."):
            ckt._lines.append(_Line(line))
            continue

        # ── Component lines ───────────────────────────────────────────────────
        ckt._lines.append(_Line(line))

    return ckt


def _join_continuations(lines: list[str]) -> list[str]:
    """
    Join continuation lines (those starting with ``+``) to the preceding line.
    Returns a new list with continuation lines merged in.
    """
    result: list[str] = []
    for raw in lines:
        stripped = raw.strip()
        if stripped.startswith("+"):
            if result:
                result[-1] += " " + stripped[1:].strip()
            # If nothing precedes, treat as a new line (malformed netlist).
        else:
            result.append(raw)
    return result


def _strip_comment(line: str) -> str:
    """
    Remove inline ``$`` or ``;`` comments from a line.
    ``*`` full-line comments are left intact (handled by the caller).
    """
    # Simple scan: stop at $ or ; that's not inside a string
    # SPICE doesn't have quoted strings per se, so a linear scan is fine.
    for i, ch in enumerate(line):
        if ch in ("$", ";"):
            return line[:i]
    return line


def _extract_include_path(line: str) -> str:
    """
    Extract the file path from a ``.include <path>`` line.

    Handles quoted paths (``"path"`` or ``'path'``) and unquoted paths.
    """
    # Strip the .include token
    rest = re.sub(r"(?i)^\.include\s*", "", line).strip()
    # Remove surrounding quotes if present
    if (rest.startswith('"') and rest.endswith('"')) or \
       (rest.startswith("'") and rest.endswith("'")):
        return rest[1:-1]
    return rest
