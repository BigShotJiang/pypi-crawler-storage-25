"""
Matplotlib convenience helpers for ngspice simulation results.

These are thin wrappers — they do not import matplotlib at module load time
so the rest of the package works without matplotlib installed.

Usage::

    from sedes.plotting import plot_waveforms, plot_bode

    result = circuit.tran("1u", "2m").run(pool)
    plot_waveforms(result, ["v(out)", "v(in)"])

    ac_result = circuit.ac("dec", 100, 1, 1e9).run(pool)
    plot_bode(ac_result, "v(out)")
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Sequence

import numpy as np

if TYPE_CHECKING:
    from .results import ACResult, TranResult, _BaseResult


def plot_waveforms(
    result: "_BaseResult",
    vectors: Sequence[str] | None = None,
    ax=None,
    xlabel: str | None = None,
    ylabel: str | None = None,
    title: str | None = None,
    **kwargs,
):
    """
    Plot time-domain (or DC sweep) waveforms from a simulation result.

    Auto-detects the X axis: uses ``time`` for transient results, ``v-sweep``
    for DC results, or the first vector if neither is found.

    Args:
        result:  A :class:`~sedes.results.TranResult`,
                 :class:`~sedes.results.DCResult`, or any result with
                 a ``vectors_dict()``.
        vectors: Vector names to plot.  If ``None``, all non-scale vectors
                 are plotted (up to 8 to avoid clutter).
        ax:      Matplotlib ``Axes`` to plot on.  A new figure is created if
                 ``None``.
        xlabel:  X-axis label (auto-detected from scale vector name if omitted).
        ylabel:  Y-axis label.
        title:   Axes title.
        **kwargs: Forwarded to ``ax.plot()``.

    Returns:
        The ``Axes`` object.
    """
    import matplotlib.pyplot as plt

    if ax is None:
        _, ax = plt.subplots()

    vecs = result.vectors_dict()
    names = list(vecs.keys())

    # Find scale vector (X axis)
    scale_name = _find_scale(names)
    x = vecs[scale_name] if scale_name else np.arange(len(next(iter(vecs.values()))))
    x_label = xlabel or (scale_name or "index")

    # Choose which vectors to plot
    if vectors is None:
        plot_names = [n for n in names if n != scale_name][:8]
    else:
        plot_names = list(vectors)

    for name in plot_names:
        if name not in vecs:
            continue
        y = vecs[name]
        if len(y) == len(x):
            ax.plot(x, y, label=name, **kwargs)

    ax.set_xlabel(x_label)
    if ylabel:
        ax.set_ylabel(ylabel)
    if title:
        ax.set_title(title)
    if plot_names:
        ax.legend()

    return ax


def plot_bode(
    result: "ACResult",
    vector: str,
    fig=None,
    mag_label: str = "Magnitude (dB)",
    phase_label: str = "Phase (°)",
    title: str | None = None,
    **kwargs,
):
    """
    Bode plot (magnitude + phase) for an AC analysis result.

    Args:
        result:  An :class:`~sedes.results.ACResult`.
        vector:  Vector name to plot (e.g. ``"v(out)"``).
        fig:     Matplotlib ``Figure`` to use.  A new one is created if ``None``.
        mag_label: Y-axis label for the magnitude subplot.
        phase_label: Y-axis label for the phase subplot.
        title:   Suptitle for the figure.
        **kwargs: Forwarded to both ``ax.semilogx()`` calls.

    Returns:
        ``(fig, (ax_mag, ax_phase))``
    """
    import matplotlib.pyplot as plt

    if fig is None:
        fig, (ax_mag, ax_phase) = plt.subplots(2, 1, sharex=True)
    else:
        axes = fig.get_axes()
        if len(axes) >= 2:
            ax_mag, ax_phase = axes[0], axes[1]
        else:
            ax_mag = fig.add_subplot(211)
            ax_phase = fig.add_subplot(212, sharex=ax_mag)

    freq = result.frequency
    mag_db = result.mag_db(vector)
    phase_deg = result.phase(vector)

    ax_mag.semilogx(freq, mag_db, **kwargs)
    ax_mag.set_ylabel(mag_label)
    ax_mag.grid(True, which="both", alpha=0.3)

    ax_phase.semilogx(freq, phase_deg, **kwargs)
    ax_phase.set_ylabel(phase_label)
    ax_phase.set_xlabel("Frequency (Hz)")
    ax_phase.grid(True, which="both", alpha=0.3)

    if title:
        fig.suptitle(title)

    fig.tight_layout()
    return fig, (ax_mag, ax_phase)


def plot_xy(
    result: "_BaseResult",
    x: str,
    y: str,
    ax=None,
    xlabel: str | None = None,
    ylabel: str | None = None,
    **kwargs,
):
    """
    Generic X-Y plot of any two vectors from a simulation result.

    Args:
        result:  Any result with a ``vector()`` method.
        x:       Name of the X-axis vector.
        y:       Name of the Y-axis vector.
        ax:      Matplotlib ``Axes``.  Created if ``None``.
        xlabel:  X-axis label (defaults to *x*).
        ylabel:  Y-axis label (defaults to *y*).
        **kwargs: Forwarded to ``ax.plot()``.

    Returns:
        The ``Axes`` object.
    """
    import matplotlib.pyplot as plt

    if ax is None:
        _, ax = plt.subplots()

    ax.plot(result.vector(x), result.vector(y), **kwargs)
    ax.set_xlabel(xlabel or x)
    ax.set_ylabel(ylabel or y)
    return ax


def plot_smith(
    result: "ACResult",
    vector: str,
    z0: float = 50.0,
    ax=None,
    title: str | None = None,
    **kwargs,
):
    """
    Basic Smith chart scatter plot for impedance data from an AC result.

    Normalises *vector* to *z0* and plots the real/imaginary parts on a unit
    circle grid.  For full Smith chart rendering, use a dedicated library like
    ``scikit-rf``.

    Args:
        result:  An :class:`~sedes.results.ACResult`.
        vector:  Vector name (impedance, e.g. ``"v(out)/i(v1)"``).
        z0:      Reference impedance in ohms (default: 50 Ω).
        ax:      Matplotlib ``Axes``.  Created if ``None``.
        title:   Axes title.
        **kwargs: Forwarded to ``ax.plot()``.

    Returns:
        The ``Axes`` object.
    """
    import matplotlib.pyplot as plt
    import matplotlib.patches as mpatches

    if ax is None:
        _, ax = plt.subplots(figsize=(6, 6))

    z = result.complex(vector)
    gamma = (z - z0) / (z + z0)

    ax.plot(gamma.real, gamma.imag, **kwargs)
    ax.add_patch(mpatches.Circle((0, 0), 1.0, fill=False, color="gray", lw=0.5))
    ax.set_xlim(-1.2, 1.2)
    ax.set_ylim(-1.2, 1.2)
    ax.set_aspect("equal")
    ax.axhline(0, color="gray", lw=0.5)
    ax.axvline(0, color="gray", lw=0.5)
    ax.set_xlabel("Re(Γ)")
    ax.set_ylabel("Im(Γ)")
    if title:
        ax.set_title(title)

    return ax


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _find_scale(names: list[str]) -> str | None:
    """Return the first vector name that looks like a scale/axis vector."""
    for name in names:
        low = name.lower()
        if low in ("time", "frequency", "freq", "v-sweep"):
            return name
        if low.endswith(".time") or low.endswith(".frequency"):
            return name
    return None
