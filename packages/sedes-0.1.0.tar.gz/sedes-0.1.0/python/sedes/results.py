"""
Typed simulation result classes.

Each class wraps a raw :class:`~sedes.SimulationResult` and adds
analysis-aware convenience properties.

These are returned by :meth:`~sedes.circuit.Circuit.run` depending on
which analysis was added to the circuit.  You can also wrap a raw result
yourself::

    raw = pool.run_simulation(netlist, ["run"])
    result = TranResult(raw)
    print(result.time)
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from .sedes import SimulationResult


# ─────────────────────────────────────────────────────────────────────────────
# Base — re-exposes everything on SimulationResult
# ─────────────────────────────────────────────────────────────────────────────

class _BaseResult:
    """Thin wrapper around a raw :class:`~sedes.SimulationResult`."""

    def __init__(self, raw: "SimulationResult"):
        self._raw = raw

    # ── Forwarded properties ─────────────────────────────────────────────────

    @property
    def id(self) -> str:
        """Correlation ID."""
        return self._raw.id

    @property
    def success(self) -> bool:
        """``True`` if the simulation completed without errors."""
        return self._raw.success

    @property
    def log(self) -> list[str]:
        """ngspice log lines captured during the simulation."""
        return self._raw.log

    @property
    def error(self) -> str | None:
        """First error message, if any."""
        return self._raw.error

    @property
    def measures(self) -> dict[str, float]:
        """Parsed ``.meas`` results as ``{name: value}``."""
        return self._raw.measures

    def vector_names(self) -> list[str]:
        """List of all vector names available in this result."""
        return self._raw.vector_names()

    def vector(self, name: str) -> np.ndarray:
        """Return a vector by name as a 1-D numpy array."""
        return self._raw.vector(name)

    def vectors_dict(self) -> dict[str, np.ndarray]:
        """Return all vectors as ``{name: np.ndarray}``."""
        return self._raw.vectors_dict()

    def __repr__(self) -> str:
        return (
            f"{type(self).__name__}("
            f"id={self.id!r}, "
            f"success={self.success}, "
            f"vectors={self.vector_names()})"
        )


# ─────────────────────────────────────────────────────────────────────────────
# OpResult
# ─────────────────────────────────────────────────────────────────────────────

class OpResult(_BaseResult):
    """
    DC operating-point result.

    All vectors are scalars (1-element arrays).  Access them by name::

        result = circuit.op().run(pool)
        print(result.vector("V(out)")[0])   # scalar value
        print(result.node("V(out)"))        # convenience: same as [0]
    """

    def node(self, name: str) -> float:
        """
        Return a scalar node voltage or branch current by name.

        This is a convenience wrapper: equivalent to ``result.vector(name)[0]``.
        """
        arr = self.vector(name)
        if len(arr) == 0:
            raise ValueError(f"vector '{name}' is empty")
        return float(arr[0])


# ─────────────────────────────────────────────────────────────────────────────
# DCResult
# ─────────────────────────────────────────────────────────────────────────────

class DCResult(_BaseResult):
    """
    DC sweep result.

    The sweep axis is the vector named after the swept source (e.g. ``"v-sweep"``
    for a voltage source sweep).  If no scale vector is auto-detected, ``sweep``
    returns the first vector.
    """

    @property
    def sweep(self) -> np.ndarray:
        """The DC sweep axis (swept source values)."""
        # ngspice names the DC sweep axis "v-sweep" for voltage sources.
        for name in self.vector_names():
            if "sweep" in name.lower():
                return self.vector(name)
        # Fallback: return the first vector.
        names = self.vector_names()
        if names:
            return self.vector(names[0])
        return np.array([])


# ─────────────────────────────────────────────────────────────────────────────
# TranResult
# ─────────────────────────────────────────────────────────────────────────────

class TranResult(_BaseResult):
    """
    Transient analysis result.

    Usage::

        result = circuit.tran("1u", "2m").run(pool)
        plt.plot(result.time * 1e3, result.vector("v(out)"))
    """

    @property
    def time(self) -> np.ndarray:
        """Simulation time axis in seconds (1-D numpy array)."""
        for name in self.vector_names():
            if name.lower() == "time":
                return self.vector(name)
        # If prefixed (multi-plot), look for any vector containing "time".
        for name in self.vector_names():
            if name.lower().endswith(".time") or name.lower().endswith("time"):
                return self.vector(name)
        return np.array([])


# ─────────────────────────────────────────────────────────────────────────────
# ACResult
# ─────────────────────────────────────────────────────────────────────────────

class ACResult(_BaseResult):
    """
    AC small-signal analysis result.

    Usage::

        result = circuit.ac("dec", 100, 1, 1e9).run(pool)
        f = result.frequency
        plt.semilogx(f, result.mag_db("v(out)"))
        plt.semilogx(f, result.phase("v(out)"))
    """

    @property
    def frequency(self) -> np.ndarray:
        """Frequency axis in Hz (1-D numpy array)."""
        for name in self.vector_names():
            if name.lower() in ("frequency", "freq"):
                return self.vector(name)
            if name.lower().endswith(".frequency") or name.lower().endswith(".freq"):
                return self.vector(name)
        return np.array([])

    def complex(self, name: str) -> np.ndarray:
        """
        Return the AC vector as a complex128 numpy array.

        Uses the raw complex (re, im) pairs transmitted from the worker.
        Falls back to computing magnitude from the real part if complex data
        is unavailable.
        """
        return self._raw.complex_vector(name)

    def mag(self, name: str) -> np.ndarray:
        """Magnitude |H(f)| in linear scale."""
        c = self.complex(name)
        return np.abs(c)

    def mag_db(self, name: str) -> np.ndarray:
        """Magnitude in dB: ``20 * log10(|H(f)|)``."""
        return 20.0 * np.log10(np.abs(self.complex(name)))

    def phase(self, name: str) -> np.ndarray:
        """Phase in degrees: ``angle(H(f)) * 180 / π``."""
        c = self.complex(name)
        return np.angle(c, deg=True)

    def phase_unwrapped(self, name: str) -> np.ndarray:
        """Unwrapped phase in degrees."""
        return np.unwrap(self.phase(name), period=360.0)


# ─────────────────────────────────────────────────────────────────────────────
# NoiseResult
# ─────────────────────────────────────────────────────────────────────────────

class NoiseResult(_BaseResult):
    """
    Noise analysis result.

    Usage::

        result = circuit.noise("V(out)", "Vin", "dec", 100, 1, 1e9).run(pool)
        f = result.frequency
        plt.loglog(f, result.spectral_density("onoise_spectrum"))
    """

    @property
    def frequency(self) -> np.ndarray:
        """Frequency axis in Hz."""
        for name in self.vector_names():
            if "freq" in name.lower():
                return self.vector(name)
        return np.array([])

    def spectral_density(self, name: str | None = None) -> np.ndarray:
        """
        Return an output noise spectral density vector.

        If *name* is None, returns the first ``onoise`` vector found.
        """
        if name is not None:
            return self.vector(name)
        for n in self.vector_names():
            if "onoise" in n.lower():
                return self.vector(n)
        raise KeyError("no onoise vector found; use vector_names() to inspect")


# ─────────────────────────────────────────────────────────────────────────────
# SensResult / TFResult (thin wrappers)
# ─────────────────────────────────────────────────────────────────────────────

class SensResult(_BaseResult):
    """Sensitivity analysis result. Use ``vector_names()`` to discover outputs."""


class TFResult(_BaseResult):
    """Transfer function result. Use ``vector_names()`` to discover outputs."""


# ─────────────────────────────────────────────────────────────────────────────
# Factory
# ─────────────────────────────────────────────────────────────────────────────

_TYPE_MAP = {
    "op":    OpResult,
    "dc":    DCResult,
    "tran":  TranResult,
    "ac":    ACResult,
    "noise": NoiseResult,
    "sens":  SensResult,
    "tf":    TFResult,
}


def _wrap_result(raw: "SimulationResult", analysis_type: str | None):
    """
    Wrap a raw :class:`~sedes.SimulationResult` in the appropriate
    typed result class based on *analysis_type*.

    Falls back to the raw result if *analysis_type* is unknown.
    """
    cls = _TYPE_MAP.get(analysis_type or "")
    if cls is None:
        return raw
    return cls(raw)
