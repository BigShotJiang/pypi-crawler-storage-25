Test library for automating some special sauce.
