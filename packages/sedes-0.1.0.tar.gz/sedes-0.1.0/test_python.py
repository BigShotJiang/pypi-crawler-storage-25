"""
ngspice-rust Python API test script.

Run with:
    uv run python test_python.py
"""

import time
import numpy as np
import sedes

SEP = "━" * 64


def section(title: str) -> None:
    print(f"\n{SEP}")
    print(f" {title}")
    print(SEP)


# ─────────────────────────────────────────────────────────────────────────────
# 1. Pool creation
# ─────────────────────────────────────────────────────────────────────────────

section("1. Pool creation")

import os
workers = int(os.cpu_count() or 4)
print(f"  Spawning {workers} worker processes…")

t0 = time.perf_counter()
pool = sedes.SimulationPool(workers=workers, timeout_secs=60.0)
dt = time.perf_counter() - t0

print(f"  {repr(pool)}")
print(f"  Ready in {dt*1000:.1f} ms")


# ─────────────────────────────────────────────────────────────────────────────
# 2. Single raw simulation
# ─────────────────────────────────────────────────────────────────────────────

section("2. Single raw simulation — voltage divider .op")

netlist = """\
voltage divider
v1 1 0 dc 5
r1 1 2 1k
r2 2 0 1k
.op
.end"""

t0 = time.perf_counter()
result = pool.run_simulation(netlist, ["run"])
dt = time.perf_counter() - t0

print(f"  Success : {result.success}")
print(f"  Vectors : {result.vector_names()}")
print(f"  Latency : {dt*1000:.1f} ms")

if result.success:
    v2 = result.vector("v(2)")
    print(f"  V(2)    = {v2[0]:.4f} V  (expect 2.5000 V)")
    assert abs(v2[0] - 2.5) < 1e-6, f"wrong V(2): {v2[0]}"
else:
    print(f"  ERROR: {result.error}")
    for line in result.log[-5:]:
        print(f"    {line}")


# ─────────────────────────────────────────────────────────────────────────────
# 3. LUT speed benchmark — built-in BSIM3 NMOS, default sweep
# ─────────────────────────────────────────────────────────────────────────────

section("3. LUT speed benchmark — built-in NMOS, 3700×3700 grid")

cfg = sedes.LutConfig(
    device_type="nmos",
    vgs=(0.0, 1.8, 0.0005),   # 3700 points
    vds=(0.0, 1.8, 0.0005),   # 3700 points
)
print(f"  Config : {repr(cfg)}")
print(f"  Grid   : {len(np.arange(0, 1.801, 0.05))} × {len(np.arange(0, 1.801, 0.05))} = "
      f"{len(np.arange(0, 1.801, 0.05))**2} operating points")

t0 = time.perf_counter()
lut = pool.generate_lut(cfg, n_chunks=workers)
dt = time.perf_counter() - t0

n_vgs, n_vds = lut.id.shape
n_ops = n_vgs * n_vds

print(f"\n  id  shape  : {lut.id.shape}   dtype={lut.id.dtype}")
print(f"  gm  shape  : {lut.gm.shape}")
print(f"  gds shape  : {lut.gds.shape}")
print(f"\n  Wall time  : {dt*1000:.1f} ms")
print(f"  Throughput : {n_ops/dt:.0f} operating points / s")

# Sanity checks
assert lut.id.shape  == (n_vgs, n_vds)
assert lut.gm.shape  == (n_vgs, n_vds)
assert lut.gds.shape == (n_vgs, n_vds)
assert lut.id.dtype  == np.float64
# Id should be ≥ 0 for NMOS
assert np.all(lut.id >= -1e-12), "Id contains unexpected negative values"
# gm should be ≥ 0
assert np.all(lut.gm >= -1e-9), "gm contains unexpected negative values"

# Sample Id table
sample_vgs = lut.vgs[[0, 12, 18, 24, 36]]
sample_vds = lut.vds[[0, 12, 18, 36]]
print(f"\n  Id sample (A)  —  rows=Vgs, cols=Vds")
print(f"  {'Vgs\\Vds':>8}", end="")
for vds in sample_vds:
    print(f"  {vds:>10.2f}V", end="")
print()
for vgs in sample_vgs:
    gi = np.argmin(np.abs(lut.vgs - vgs))
    print(f"  {vgs:>8.2f}V", end="")
    for vds in sample_vds:
        di = np.argmin(np.abs(lut.vds - vds))
        print(f"  {lut.id[gi, di]:>11.3e}", end="")
    print()

gm_max  = lut.gm.max()
gds_max = lut.gds.max()
print(f"\n  gm  range : {lut.gm.min():.3e} .. {gm_max:.3e} S")
print(f"  gds range : {lut.gds.min():.3e} .. {gds_max:.3e} S")


# ─────────────────────────────────────────────────────────────────────────────
# 4. LUT speed benchmark — fine sweep
# ─────────────────────────────────────────────────────────────────────────────

section("4. LUT speed benchmark — fine sweep 91×91 grid")

cfg_fine = sedes.LutConfig(
    device_type="nmos",
    vgs=(0.0, 1.8, 0.02),   # 91 points
    vds=(0.0, 1.8, 0.02),   # 91 points
)
n_fine = len(np.arange(0, 1.801, 0.02)) ** 2
print(f"  Grid : {int(n_fine**0.5)} × {int(n_fine**0.5)} = {n_fine} operating points")

t0 = time.perf_counter()
lut_fine = pool.generate_lut(cfg_fine, n_chunks=workers)
dt = time.perf_counter() - t0

n_ops_fine = lut_fine.id.shape[0] * lut_fine.id.shape[1]
print(f"  Wall time  : {dt*1000:.1f} ms")
print(f"  Throughput : {n_ops_fine/dt:.0f} operating points / s")


# ─────────────────────────────────────────────────────────────────────────────
# 5. CSV output
# ─────────────────────────────────────────────────────────────────────────────

section("5. CSV output")

import tempfile, os

with tempfile.NamedTemporaryFile(suffix=".csv", delete=False) as f:
    csv_path = f.name

lut.to_csv(csv_path)
size = os.path.getsize(csv_path)
lines = open(csv_path).readlines()
print(f"  Path    : {csv_path}")
print(f"  Size    : {size} bytes")
print(f"  Lines   : {len(lines)}  (1 header + {len(lines)-1} data rows, expect {n_vgs*n_vds})")
print(f"  Header  : {lines[0].strip()}")
print(f"  Row[1]  : {lines[1].strip()}")
assert len(lines) == n_vgs * n_vds + 1, "wrong row count"
os.unlink(csv_path)


# ─────────────────────────────────────────────────────────────────────────────
# 6. PMOS built-in model
# ─────────────────────────────────────────────────────────────────────────────

section("6. PMOS built-in model — 19×19 grid")

cfg_pmos = sedes.LutConfig(
    device_type="pmos",
    vgs=(-1.8, 0.0, 0.1),
    vds=(-1.8, 0.0, 0.1),
)
t0 = time.perf_counter()
lut_pmos = pool.generate_lut(cfg_pmos)
dt = time.perf_counter() - t0
n_p = lut_pmos.id.shape[0] * lut_pmos.id.shape[1]
print(f"  Shape : {lut_pmos.id.shape}")
print(f"  Wall  : {dt*1000:.1f} ms  ({n_p/dt:.0f} op/s)")


# ─────────────────────────────────────────────────────────────────────────────
# 7. vectors_dict convenience method
# ─────────────────────────────────────────────────────────────────────────────

section("7. vectors_dict() — all vectors as a dict")

netlist_tran = """\
rc lowpass
v1 1 0 sin(0 1 1k)
r1 1 2 1k
c1 2 0 100n
.tran 1u 2m
.end"""

result2 = pool.run_simulation(netlist_tran, ["run"])
vecs = result2.vectors_dict()
print(f"  Success : {result2.success}")
print(f"  Vectors : {list(vecs.keys())}")
for name, arr in vecs.items():
    print(f"    {name:20s}  shape={arr.shape}  min={arr.min():.3e}  max={arr.max():.3e}")


# ─────────────────────────────────────────────────────────────────────────────
# Done
# ─────────────────────────────────────────────────────────────────────────────

print(f"\n{SEP}")
print(" All tests passed.")
print(SEP)
