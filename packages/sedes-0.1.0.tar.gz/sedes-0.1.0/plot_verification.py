"""
Visual verification of all ngspice-rust test cases.
Run with:  uv run python plot_verification.py
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import sedes
import time
from sedes import Circuit, parse_string

pool = sedes.SimulationPool(workers=4, timeout_secs=60.0)

fig = plt.figure(figsize=(16, 22))
fig.suptitle("ngspice-rust verification plots", fontsize=15, fontweight="bold", y=0.98)

gs = gridspec.GridSpec(5, 2, figure=fig, hspace=0.55, wspace=0.35)

# ─────────────────────────────────────────────────────────────────────────────
# 1. Transient — RC low-pass, sin excitation
# ─────────────────────────────────────────────────────────────────────────────
start_time = time.time()
ckt1 = (Circuit("RC low-pass")
    .V("v1", "in", "0", "sin(0 1 1k)")
    .R("r1", "in", "out", "1k")
    .C("c1", "out", "0", "100n")
    .tran("1u", "2m"))

r1 = ckt1.run(pool)
t   = r1.time * 1e3  # ms
vin = r1.vector("in")
vout = r1.vector("out")

ax1 = fig.add_subplot(gs[0, 0])
ax1.plot(t, vin,  label="V(in)",  lw=1.2)
ax1.plot(t, vout, label="V(out)", lw=1.2)
ax1.set_xlabel("Time (ms)")
ax1.set_ylabel("Voltage (V)")
ax1.set_title("1. Transient — RC low-pass (R=1k, C=100n, f=1kHz)")
ax1.legend(fontsize=8)
ax1.grid(True, alpha=0.3)


# ─────────────────────────────────────────────────────────────────────────────
# 2. OP — voltage divider
# ─────────────────────────────────────────────────────────────────────────────

ckt2 = (Circuit("voltage divider")
    .V("vdd", "vdd", "0", "dc 5")
    .R("r1", "vdd", "mid", "1k")
    .R("r2", "mid", "0", "1k")
    .op())

r2 = ckt2.run(pool)
nodes = {n: float(r2.vector(n)[0]) for n in r2.vector_names()
         if not n.endswith("#branch")}
labels = list(nodes.keys())
values = list(nodes.values())

ax2 = fig.add_subplot(gs[0, 1])
bars = ax2.bar(labels, values, color=["steelblue", "orange", "green"][:len(labels)])
ax2.bar_label(bars, fmt="%.4f V", padding=3, fontsize=8)
ax2.set_ylabel("Voltage (V)")
ax2.set_title("2. DC operating point — voltage divider\n(Vdd=5V, R1=R2=1k → V(mid)=2.5V)")
ax2.set_ylim(0, max(values) * 1.25)
ax2.grid(True, alpha=0.3, axis="y")


# ─────────────────────────────────────────────────────────────────────────────
# 3. AC — Bode plot
# ─────────────────────────────────────────────────────────────────────────────

ckt3 = (Circuit("RC low-pass AC")
    .V("vin", "in", "0", "ac 1")
    .R("r1", "in", "out", "1k")
    .C("c1", "out", "0", "100n")
    .ac("dec", 50, 10, 100e6))

r3 = ckt3.run(pool)
freq     = r3.frequency
mag_db   = r3.mag_db("out")
phase_d  = r3.phase("out")
fc       = 1.0 / (2 * np.pi * 1e3 * 100e-9)

ax3a = fig.add_subplot(gs[1, :])
ax3a_twin = ax3a.twinx()

l1, = ax3a.semilogx(freq, mag_db,  "b",  lw=1.5, label="Magnitude (dB)")
l2, = ax3a_twin.semilogx(freq, phase_d, "r--", lw=1.5, label="Phase (°)")
ax3a.axvline(fc, color="gray", ls=":", lw=1, label=f"f_c = {fc/1e3:.1f} kHz")
ax3a.axhline(-3, color="gray", ls="--", lw=0.8, alpha=0.6)

ax3a.set_xlabel("Frequency (Hz)")
ax3a.set_ylabel("Magnitude (dB)", color="b")
ax3a_twin.set_ylabel("Phase (°)", color="r")
ax3a.set_title("3. AC analysis — RC low-pass Bode plot (R=1k, C=100n)")
ax3a.tick_params(axis="y", labelcolor="b")
ax3a_twin.tick_params(axis="y", labelcolor="r")
ax3a_twin.set_ylim(-100, 10)
lines = [l1, l2]
ax3a.legend(lines, [l.get_label() for l in lines], fontsize=8, loc="lower left")
ax3a.grid(True, alpha=0.3)


# ─────────────────────────────────────────────────────────────────────────────
# 4. Transient + .meas
# ─────────────────────────────────────────────────────────────────────────────

ckt4 = (Circuit("meas test")
    .V("v1", "in", "0", "pulse(0 1 0 1n 1n 500n 1u)")
    .R("r1", "in", "out", "1k")
    .C("c1", "out", "0", "10n")
    .measure("tran", "vout_max", "MAX V(out)")
    .measure("tran", "vout_min", "MIN V(out)")
    .tran("1n", "3u"))

r4 = ckt4.run(pool)
t4   = r4.time * 1e6  # µs
vin4 = r4.vector("in")
vout4 = r4.vector("out")
meas4 = r4.measures

ax4 = fig.add_subplot(gs[2, 0])
ax4.plot(t4, vin4,  label="V(in)",  lw=1, alpha=0.7)
ax4.plot(t4, vout4, label="V(out)", lw=1.2)
ax4.axhline(meas4["vout_max"], color="red",  ls="--", lw=1,
            label=f".meas MAX = {meas4['vout_max']:.4f} V")
ax4.axhline(meas4["vout_min"], color="green", ls="--", lw=1,
            label=f".meas MIN = {meas4['vout_min']:.4f} V")
ax4.set_xlabel("Time (µs)")
ax4.set_ylabel("Voltage (V)")
ax4.set_title("4. .meas result parsing\n(pulse → RC, MAX/MIN measured)")
ax4.legend(fontsize=7)
ax4.grid(True, alpha=0.3)


# ─────────────────────────────────────────────────────────────────────────────
# 5. Multi-plot (.op + .ac in one netlist)
# ─────────────────────────────────────────────────────────────────────────────

netlist5 = """\
multi-plot test
Vin in 0 dc 1 ac 1
R1 in out 1k
C1 out 0 100n
.op
.ac dec 20 100 10meg
.end"""

r5 = pool.run_simulation(netlist5, ["run"])
vnames5 = r5.vector_names()

# Find the AC frequency and out vectors (prefixed "ac1.")
ac_freq  = next((v for v in vnames5 if "frequency" in v.lower()), None)
ac_out   = next((v for v in vnames5 if v.startswith("ac1.") and "out" in v.lower()), None)
op_out   = next((v for v in vnames5 if v.startswith("op1.") and "out" in v.lower()), None)

ax5 = fig.add_subplot(gs[2, 1])
if ac_freq and ac_out:
    freq5 = r5.vector(ac_freq)
    mag5  = 20 * np.log10(np.abs(r5.complex_vector(ac_out)))
    ax5.semilogx(freq5, mag5, lw=1.5, label=f"|{ac_out}| dB")

op_val = float(r5.vector(op_out)[0]) if op_out else None
if op_val is not None:
    ax5.axhline(0, color="gray", ls=":", lw=0.8)
    ax5.text(0.05, 0.85, f"OP: V(out) = {op_val:.4f} V",
             transform=ax5.transAxes, fontsize=8,
             bbox=dict(boxstyle="round", fc="white", alpha=0.8))

ax5.set_xlabel("Frequency (Hz)")
ax5.set_ylabel("Magnitude (dB)")
ax5.set_title(f"5. Multi-plot: .op + .ac\n({len(vnames5)} vectors: {vnames5})")
ax5.legend(fontsize=7)
ax5.grid(True, alpha=0.3)
# Wrap long title
ax5.title.set_fontsize(8)


# ─────────────────────────────────────────────────────────────────────────────
# 6. Netlist parser — compare C=100n vs C=10n
# ─────────────────────────────────────────────────────────────────────────────

original = """\
RC filter
V1 in 0 sin(0 1 1k)
R1 in out 1k
C1 out 0 100n
.tran 1u 2m
.end"""

parsed_a = parse_string(original)
r6a = parsed_a.run(pool)

parsed_b = parse_string(original)
parsed_b.replace("c1", "C1 out 0 10n")
r6b = parsed_b.run(pool)

ax6 = fig.add_subplot(gs[3, :])
t6a = r6a.time * 1e3
t6b = r6b.time * 1e3
ax6.plot(t6a, r6a.vector("in"),  "gray", lw=0.8, alpha=0.5, label="V(in)")
ax6.plot(t6a, r6a.vector("out"), "b",    lw=1.5, label=f"V(out) C=100n  max={r6a.vector('out').max():.3f}V")
ax6.plot(t6b, r6b.vector("out"), "r",    lw=1.5, label=f"V(out) C=10n   max={r6b.vector('out').max():.3f}V")
ax6.set_xlabel("Time (ms)")
ax6.set_ylabel("Voltage (V)")
ax6.set_title("6. Netlist parser — parse → modify capacitor → re-simulate\n(smaller C → wider bandwidth → output closer to input)")
ax6.legend(fontsize=8)
ax6.grid(True, alpha=0.3)


# ─────────────────────────────────────────────────────────────────────────────
# 7. DC sweep — diode I-V
# ─────────────────────────────────────────────────────────────────────────────

ckt7 = (Circuit("diode I-V")
    .V("vd", "anode", "0", "dc 0")
    .R("rs", "anode", "cathode", "1")
    .D("d1", "cathode", "0", "D1N4148")
    .model(".model D1N4148 D(IS=2.52e-9 N=1.752 BV=110 IBV=0.1e-3 RS=0.568)")
    .dc("vd", 0, 0.8, 0.005))

r7 = ckt7.run(pool)
sweep7  = r7.sweep
# Diode current = -branch current of voltage source
ibranch = next((v for v in r7.vector_names() if "branch" in v.lower()), None)
if ibranch:
    id_mA = -r7.vector(ibranch) * 1e3

ax7 = fig.add_subplot(gs[4, 0])
if ibranch:
    ax7.plot(sweep7, id_mA, lw=1.5, color="darkorange")
ax7.set_xlabel("Vd (V)")
ax7.set_ylabel("Id (mA)")
ax7.set_title("7. DC sweep — 1N4148 diode I-V characteristic")
ax7.grid(True, alpha=0.3)
ax7.set_xlim(0, 0.8)


# ─────────────────────────────────────────────────────────────────────────────
# 7b. Diode I-V log scale
# ─────────────────────────────────────────────────────────────────────────────

ax7b = fig.add_subplot(gs[4, 1])
if ibranch:
    mask = id_mA > 1e-6  # avoid log(0)
    ax7b.semilogy(sweep7[mask], id_mA[mask], lw=1.5, color="darkorange")
ax7b.set_xlabel("Vd (V)")
ax7b.set_ylabel("Id (mA, log scale)")
ax7b.set_title("7b. Diode I-V — log scale (exponential regime visible)")
ax7b.grid(True, alpha=0.3)
ax7b.set_xlim(0, 0.8)


plt.savefig("verification_plots.png", dpi=150, bbox_inches="tight")

print(f"Total simulation time: {time.time() - start_time:.2f} seconds")
print("Saved: verification_plots.png")
plt.show()
