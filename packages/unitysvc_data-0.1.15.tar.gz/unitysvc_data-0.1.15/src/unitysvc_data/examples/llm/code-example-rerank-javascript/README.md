+++
preset_name = "llm_code_example_rerank_javascript"
category = "code_example"
mime_type = "javascript"
file = "code-example-rerank.js.j2"
description = "JavaScript example: rerank documents via /rerank"
is_active = true
is_public = true
parameters = { version_prefix = "/v1" }
+++

# llm / code-example-rerank-javascript — document reranking via `fetch`

Customer-facing Node.js example for `/rerank` endpoints (Cohere-style). Sends a small fixed query+documents list so the output exercises the ranking path.

## Template variables (filled in by the platform when rendering for a given access interface)

- `{{ service_base_url }}` — endpoint base URL, taken from the listing's access interface.
- `{{ routing_key.model }}` — model id, taken from the access interface's routing key.

## Environment variables (read at runtime)

Required:

- `UNITYSVC_API_KEY` — bearer token: customer's svcpass for gateway access, or an upstream API key when the seller / customer wires it as a secret (BYOK).

## Versions

### v1 — initial release
