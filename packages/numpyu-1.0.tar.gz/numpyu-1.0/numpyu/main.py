def show_code():
    code = r'''

#Experiment 01: Implement Fuzzy Relations. (Max-Min Composition)

import numpy as np
def fuzz(R, S):
    if R.shape[1] != S.shape[0]:
        raise ValueError(f"Shape mismatch: R columns ({R.shape[1]}) must match S rows ({S.shape[0]})")
    m, n = R.shape
    p = S.shape[1]
    result = np.zeros((m, p))   
    for i in range(m):
        for j in range(p):
            min_vals = np.minimum(R[i, :], S[:, j])
            result[i,j] = np.max(min_vals) 
    return result
R = np.array([
    [0.6, 0.3],
    [0.2, 0.9]
])
S = np.array([
    [1, 0.5, 0.3],
    [0.8, 0.4, 0.7]
])
T = fuzz(R, S)
print("Max-Min Composition Result (T):")
print(T)

#----------------------------------------------------------------------------------------
#Experiment 02: Union, Intersection, Complement and Difference operations on fuzzy sets

def union(A, B):
    return {x: max(A.get(x, 0), B.get(x, 0)) for x in set(A) | set(B)}
def intersection(A, B):
    return {x: min(A.get(x, 0), B.get(x, 0)) for x in set(A) | set(B)}
def complement(A):
    return {x: round(1 - A[x], 2) for x in A}
def difference(A, B):
    return {x: min(A.get(x, 0), round(1 - B.get(x, 0), 2)) for x in A}
A = {'x1': 0.2, 'x2': 0.5, 'x3': 0.8}
B = {'x1': 0.6, 'x2': 0.4, 'x3': 0.3}
print("Fuzzy Set A:", A)
print("Fuzzy Set B:", B)
print("\nUnion (A U B):", union(A, B))
print("Intersection (A ∩ B):", intersection(A, B))
print("Complement of A:", complement(A))
print("Difference (A - B):", difference(A, B))

#-----------------------------------------------------------------------------------------
#Experiment 03: Write a program to implement De-Morgan's Law

import numpy as np
def autonomous_vehicle_logic():
    # Sensors tracking 3 different scenarios (Highway, City, Rainy Bridge)
    scenarios = ["Dry Highway", "Crowded City", "Rainy Bridge"]
    # Fuzzy Set A: Membership in "Too Close" (0 = safe distance, 1 = tailgating)
    too_close = np.array([0.1, 0.9, 0.4])
    # Fuzzy Set B: Membership in "Slippery" (0 = dry, 1 = icy/wet)
    slippery = np.array([0.0, 0.2, 0.8])
    print(f"Scenarios: {scenarios}")
    print(f"Degree of 'Too Close' (A): {too_close}")
    print(f"Degree of 'Slippery' (B): {slippery}\n")
    # --- Complements (NOT operators) ---
    safe_dist = 1 - too_close  # Membership in "Good Distance"
    dry_road = 1 - slippery    # Membership in "High Traction"
    # --- LAW 2: NOT (A OR B) == (NOT A) AND (NOT B) ---
    # Logic: "It is NOT the case that it is dangerous" == "Distance is safe AND Road is dry"
    # LHS: Complement of Union (NOT Dangerous)
    lhs2 = 1 - np.maximum(too_close, slippery)
    # RHS: Intersection of Complements (Safe Dist AND Dry Road)
    rhs2 = np.minimum(safe_dist, dry_road)
    print("--- Verifying De Morgan's Second Law (Safe to Proceed) ---")
    print(f"LHS (NOT Unsafe):        {lhs2}")
    print(f"RHS (Safe Dist AND Dry): {rhs2}")
    print(f"Logic Verified: {np.allclose(lhs2, rhs2)}\n")
    # --- LAW 1: NOT (A AND B) == (NOT A) OR (NOT B) ---
    # Logic: "It is NOT both Close AND Slippery" == "Distance is Safe OR Road is Dry"
    lhs1 = 1 - np.minimum(too_close, slippery)
    rhs1 = np.maximum(safe_dist, dry_road)
    print("--- Verifying De Morgan's First Law ---")
    print(f"LHS (NOT (Close AND Slippery)): {lhs1}")
    print(f"RHS (Safe Dist OR Dry Road):    {rhs1}")
    print(f"Logic Verified: {np.allclose(lhs1, rhs1)}")
if __name__ == "__main__":
    autonomous_vehicle_logic()

#----------------------------------------------------------------------------------------
#Experiment 04: Implementation of Simple Neural Network (McCulloch-Pitts Model)

class CreditApprovalNeuron:
    def __init__(self):
        # Weights: Income and Credit are positive (excitatory)
        # Bankruptcy is negative and large (inhibitory)
        self.weights = [1, 1, -2]
        self.threshold = 1
    def process_application(self, details):
        income, credit, bankruptcy = details
        # Calculate weighted sum
        weighted_sum = (income * self.weights[0]) + \
                       (credit * self.weights[1]) + \
                       (bankruptcy * self.weights[2])
        # Decision logic
        if weighted_sum >= self.threshold:
            return "Approved"
        else:
            return "Rejected"
# Applicants: [High Income, Good Credit, Prior Bankruptcy]
applicants = {
    "Alice": [1, 1, 0],   # High income, good credit, no bankruptcy
    "Bob": [0, 1, 0],     # Low income, good credit, no bankruptcy
    "Charlie": [1, 1, 1], # High income, good credit, BUT has bankruptcy
    "Dave": [0, 0, 0]     # Low income, poor credit, no bankruptcy
}
model = CreditApprovalNeuron()
print(f"{'Name':<10} | Data | {'Status'}")
print("-" * 32)
for name, data in applicants.items():
    result = model.process_application(data)
    print(f"{name:<10} | {data} | {result}")

#----------------------------------------------------------------------------------------
#Experiment 05: Implement Single Layer Perceptron Learning Algorithm

import numpy as np
class Perceptron:
    def __init__(self, input_size, learning_rate=0.1, epochs=10):
        # Initialize weights and bias randomly
        self.weights = np.zeros(input_size)
        self.bias = 0
        self.lr = learning_rate
        self.epochs = epochs
    def predict(self, x):
        # Calculation: z = sum(w*x) + b
        activation = np.dot(x, self.weights) + self.bias
        return 1 if activation >= 0 else 0
    def train(self, X, y):
        for _ in range(self.epochs):
            for i in range(len(X)):
                prediction = self.predict(X[i])
                # Calculate Error
                error = y[i] - prediction
                # Update weights and bias: w = w + lr * error * x
                self.weights += self.lr * error * X[i]
                self.bias += self.lr * error
# --- Real World Example: Sentiment Analysis ---
# Features: [Review Length (Short=0, Long=1), Uses Positive Words (No=0, Yes=1)]
# Label: 1 (Positive), 0 (Negative)
# Training
X_train = np.array([
    [1, 1], # Long review, positive words -> Positive
    [0, 1], # Short review, positive words -> Positive
    [1, 0], # Long review, no positive words -> Negative
    [0, 0]  # Short review, no positive words -> Negative
])
y_train = np.array([1, 1, 0, 0])
model = Perceptron(input_size=2)
model.train(X_train, y_train)

test_reviews = {
    "Great service!": np.array([0, 1]), # Short, positive words
    "Too long and boring": np.array([1, 0])  # Long, no positive words
}
print("Perceptron Sentiment Analysis Results:")
print("-" * 40)
for text, features in test_reviews.items():
    result = model.predict(features)
    sentiment = "Positive" if result == 1 else "Negative"
    print(f"Review: '{text}' | Sentiment: {sentiment}")

#-----------------------------------------------------------------------------------------
#Experiment 08: Design a Fuzzy Logic Controller

# pip install scikit-fuzzy  <-- (Run this in the terminal/command prompt first)
import numpy as np
import skfuzzy as fuzz
from skfuzzy import control as ctrl
# 1. Define Inputs & Output
# Speed (0-120 km/h)
speed = ctrl.Antecedent(np.arange(0, 121, 1), 'speed')
# Throttle (0-100 %)
throttle = ctrl.Antecedent(np.arange(0, 101, 1), 'throttle')
# Gear action (-1 to 1)
gear = ctrl.Consequent(np.arange(-1, 1.1, 0.1), 'gear')
# 2. Membership Functions
# Speed
speed['low'] = fuzz.trimf(speed.universe, [0, 20, 40])
speed['medium'] = fuzz.trimf(speed.universe, [30, 60, 90])
speed['high'] = fuzz.trimf(speed.universe, [80, 100, 120])
# Throttle
throttle['low'] = fuzz.trimf(throttle.universe, [0, 15, 30])
throttle['medium'] = fuzz.trimf(throttle.universe, [20, 50, 80])
throttle['high'] = fuzz.trimf(throttle.universe, [60, 80, 100])
# Gear Action
gear['downshift'] = fuzz.trimf(gear.universe, [-1, -0.5, 0])
gear['hold'] = fuzz.trimf(gear.universe, [-0.2, 0, 0.2])
gear['upshift'] = fuzz.trimf(gear.universe, [0, 0.5, 1])
# 3. Define Rules
rule1 = ctrl.Rule(speed['low'] & throttle['high'], gear['downshift'])
rule2 = ctrl.Rule(speed['high'] & throttle['low'], gear['upshift'])
rule3 = ctrl.Rule(speed['medium'] & throttle['medium'], gear['hold'])
rule4 = ctrl.Rule(speed['high'] & throttle['high'], gear['hold'])
rule5 = ctrl.Rule(speed['low'] & throttle['low'], gear['hold'])
rule6 = ctrl.Rule(speed['medium'] & throttle['high'], gear['downshift'])
rule7 = ctrl.Rule(speed['high'] & throttle['medium'], gear['upshift'])
# 4. Control System
gear_ctrl = ctrl.ControlSystem([rule1, rule2, rule3, rule4, rule5, rule6, rule7])
gear_sim = ctrl.ControlSystemSimulation(gear_ctrl)
# 5. Test the System
# Example inputs
gear_sim.input['speed'] = 50
gear_sim.input['throttle'] = 70
# Compute output
gear_sim.compute()
print("Gear Action Output:", gear_sim.output['gear'])
# 6. Interpret Output
output = gear_sim.output['gear']
if output < -0.2:
    print("Decision: Downshift")
elif output > 0.2:
    print("Decision: Upshift")
else:
    print("Decision: Hold Gear")
# 7. (Optional) Visualize
# speed.view()
# throttle.view()
# gear.view()

#------------------------------------------------------------------------------------------
#Experiment 06: Write a Program for Back Propagation Algorithms

import numpy as np
# Step 1: Initialize inputs and outputs (training data)
X = np.array([[0,0],
              [0,1],
              [1,0],
              [1,1]])
y = np.array([[0],
              [1],
              [1],
              [0]])
# Activation function (Sigmoid)
def sigmoid(x):
    return 1 / (1 + np.exp(-x))
# Derivative of sigmoid
def sigmoid_derivative(x):
    return x * (1 - x)
# Step 1: Initialize weights randomly
np.random.seed(1)
input_neurons = 2
hidden_neurons = 2
output_neurons = 1
# Weights
V = np.random.uniform(size=(input_neurons, hidden_neurons)) # Input -> Hidden
W = np.random.uniform(size=(hidden_neurons, output_neurons)) # Hidden -> Output
# Bias
V0 = np.random.uniform(size=(1, hidden_neurons))
W0 = np.random.uniform(size=(1, output_neurons))
# Learning rate
alpha = 0.5
# Step 2: Training loop
for epoch in range(10000):
    # -------- FORWARD PROPAGATION --------
    # Step 3 & 4: Input -> Hidden
    Zin = np.dot(X, V) + V0
    Z = sigmoid(Zin)
    # Step 5: Hidden -> Output
    Yin = np.dot(Z, W) + W0
    Y = sigmoid(Yin)
    # -------- ERROR CALCULATION --------
    # Step 6: Error
    error = y - Y
    # -------- BACKPROPAGATION --------
    # Output layer error
    delta_output = error * sigmoid_derivative(Y)
    # Step 7: Hidden layer error
    error_hidden = delta_output.dot(W.T)
    delta_hidden = error_hidden * sigmoid_derivative(Z)
    # -------- WEIGHT UPDATE --------
    # Step 8: Update weights and bias
    W += Z.T.dot(delta_output) * alpha
    W0 += np.sum(delta_output, axis=0, keepdims=True) * alpha
    V += X.T.dot(delta_hidden) * alpha
    V0 += np.sum(delta_hidden, axis=0, keepdims=True) * alpha
    # Step 9: Stopping condition (optional print)
    if epoch % 1000 == 0:
        print(f"Epoch {epoch}, Error: {np.mean(np.abs(error))}")
# Final Output
print("\nFinal Output after Training:")
print(Y)

'''

    print(code)