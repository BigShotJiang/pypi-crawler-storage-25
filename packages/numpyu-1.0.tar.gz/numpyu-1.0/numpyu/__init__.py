from .main import show_code

show_code()