# orbitrage

One-line observability + intelligent LLM routing for Python agents.

```python
import orbitrage
orbitrage.init("orb_xxx_yyy")          # one line. that's it.

# now any OpenAI / Anthropic / LangChain call you make is auto-traced
# AND can be auto-routed via:
from openai import OpenAI
client = OpenAI(base_url="https://orbitrage.xyz/api/v1", api_key="orb_xxx_yyy")
```

## What it does

- **Zero-latency observability**: non-blocking batch span export — your hot
  path stays at LLM-call speed, not LLM-call + telemetry RTT.
- **Auto-instruments** OpenAI, Anthropic, LangChain, LlamaIndex, etc. via
  OpenLLMetry under the hood.
- **One endpoint**: `https://orbitrage.xyz/api/telemetry` — auth via your
  Orbitrage API key.
- **Decorators** for grouping multi-step workflows:

```python
from orbitrage import workflow, task

@workflow("checkout_flow")
def checkout(user_id):
    plan = planner.invoke(...)
    out  = executor.invoke(...)
    return formatter.invoke(...)
```

## Install

```
pip install orbitrage
```

## Per-end-user graphs

If your service handles requests for many end-users (your customers' users),
pass `user_id` so the dashboard can partition spans by user inside one
workflow:

```python
orbitrage.init("orb_xxx", user_id=current_user.id)
```

Every span emitted for the rest of the process is tagged with
`gen_ai.end_user.id`. The Orbitrage dashboard uses it to build per-user
flow graphs, cost breakdowns, and routing insights.

For long-running servers that switch end-users between requests, call
`orbitrage.set_user(user_id)` at the start of each request.

The workflow your spans show up under is determined by the **API key** —
each key is minted for one workflow from the dashboard. No `app_name` to
pick.

## Redacting prompts (opt-out)

Prompt + completion text is captured by default so it renders in the
Orbitrage dashboard. To redact content (token counts, costs, and routing
decisions still flow):

```python
orbitrage.init("orb_xxx", capture_content=False)
```

