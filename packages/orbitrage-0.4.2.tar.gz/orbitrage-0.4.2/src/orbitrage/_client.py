"""orbitrage client. Thin wrapper over Traceloop / OpenLLMetry with
hot-path-safe defaults so users pay close to zero overhead per LLM call.

Design goals:
  - **One-line init**: `orbitrage.init("orb_xxx")` — no other config needed.
  - **Zero blocking on the hot path**: spans are queued to a daemon-thread
    BatchSpanProcessor; OTLP exports never run inline with the user's call.
  - **Fail-open**: if the Orbitrage backend is unreachable, the user's
    workflow MUST still succeed. Export errors are swallowed silently.
  - **No surprises**: never call `os._exit`, never install global hooks
    that the user didn't ask for, never print to stdout on success.

0.4.0 breaking changes:
  - `app_name` removed. The workflow is implicit in the API key (each key
    is minted for one workflow from the dashboard).
  - `user_id` added (optional). When passed, propagates as
    `traceloop.association.properties.user_id` + `gen_ai.end_user.id` on
    every span so the dashboard builds per-end-user graphs.

What we override vs. raw Traceloop:
  - `disable_batch=False` — Traceloop's default is fine, but raw users
    sometimes pass `disable_batch=True` (the docs show it), which makes
    every span export a synchronous HTTPS POST. We force-disable that.
  - Aggressive BatchSpanProcessor tuning via env vars for snappier flush.
  - Default endpoint -> orbitrage.xyz, default headers from the api_key,
    and a metadata-collector function so we don't have to ask the user
    for app_name / workflow_id.
  - `traceloop_sync_enabled=False` — we don't talk to Traceloop's prompt
    sync API ever; users get prompts via Orbitrage's own /v1/prompts.
"""
from __future__ import annotations

import atexit
import logging
import os
import re
import sys
from typing import Any, Callable, Optional, Set

logger = logging.getLogger("orbitrage")

# Lazy imports — keep `import orbitrage` itself sub-millisecond.
_initialized = False
_client = None
_tracer_wrapper = None
# Long-lived "workflow root" span and the context-attach token. Both LLM
# spans created by openai/anthropic instrumentors during the process become
# children of this root and inherit its trace_id, so the dashboard groups
# them into one workflow row instead of 11 separate one-node graphs.
_root_span = None
_root_token = None
# End-user id (the org's customer). Set once at init, propagated to every
# LLM call via Traceloop.set_association_properties so the per-end-user
# dashboards can partition spans by it. Unset for backend / batch flows.
_user_id: Optional[str] = None


# ── public env config ─────────────────────────────────────────────────────
# Endpoint defaults to production. Override via ORBITRAGE_ENDPOINT for
# self-hosted / staging tests.
_DEFAULT_ENDPOINT = "https://orbitrage.xyz/api/telemetry"


# Map import names → Traceloop Instruments enum value names. Detection looks
# at sys.modules first, then falls back to importlib.util.find_spec for
# packages that are installed but not yet imported. Keeping this list tight:
# only LLM / agent libraries — vector DBs / loggers / generic HTTP are opt-in.
_AUTO_INSTRUMENT_MAP: list[tuple[tuple[str, ...], str]] = [
    (("openai",),                                        "OPENAI"),
    (("anthropic",),                                     "ANTHROPIC"),
    (("langchain", "langchain_core", "langchain_openai",
      "langchain_anthropic"),                            "LANGCHAIN"),
    (("llama_index", "llama_index.core"),                "LLAMA_INDEX"),
    (("cohere",),                                        "COHERE"),
    (("groq",),                                          "GROQ"),
    (("mistralai",),                                     "MISTRAL"),
    (("google.generativeai", "google_generativeai"),     "GOOGLE_GENERATIVEAI"),
    (("ollama",),                                        "OLLAMA"),
    (("together",),                                      "TOGETHER"),
    (("replicate",),                                     "REPLICATE"),
    (("crewai",),                                        "CREWAI"),
    (("haystack",),                                      "HAYSTACK"),
    (("agno",),                                          "AGNO"),
    (("openai_agents",),                                 "OPENAI_AGENTS"),
    (("mcp",),                                           "MCP"),
]


def _autodetect_instruments() -> Optional[set]:
    """Return the Instruments set Traceloop should load.

    Strategy — only enable instruments for libraries the user is actually
    using (sys.modules), PLUS the two raw LLM clients (openai, anthropic)
    even if not yet imported. This handles the common pattern where
    `orbitrage.init()` is called at the very top of the file BEFORE the
    LLM client import — we still want the openai call to be traced.

    We deliberately exclude heavy/fragile instrumentors (langchain,
    llama_index, transformers) from the always-on set: their
    instrumentation typically wraps the underlying openai/anthropic
    client anyway, so the raw-client instrumentor catches the same span.

    Returns None if Traceloop isn't importable (caller will skip init).
    """
    try:
        from traceloop.sdk.instruments import Instruments
    except Exception:
        return None
    out = set()
    # Always-on raw LLM clients — safe, fast, near-zero startup cost.
    for enum_name in ("OPENAI", "ANTHROPIC"):
        v = getattr(Instruments, enum_name, None)
        if v is not None:
            out.add(v)
    # Modules already imported by the user — definitely in use.
    for modules, enum_name in _AUTO_INSTRUMENT_MAP:
        if any(m in sys.modules for m in modules):
            v = getattr(Instruments, enum_name, None)
            if v is not None:
                out.add(v)
    return out


def _resolve_endpoint(explicit: Optional[str]) -> str:
    """Resolve endpoint. Order: explicit arg > env var > default."""
    return (
        explicit
        or os.environ.get("ORBITRAGE_ENDPOINT")
        or os.environ.get("TRACELOOP_BASE_URL")  # for migrators
        or _DEFAULT_ENDPOINT
    )


def _normalize_telemetry_endpoint(value: str) -> str:
    """Coerce common SDK base-URL shapes to the actual telemetry path.

    Users often paste their router URL (`https://orbitrage.xyz/api/v1`) here
    because that's what `base_url=` means in the OpenAI SDK. Silently
    rewriting it to `/api/telemetry` is the friendly thing — without this,
    spans get POSTed to a 404 and disappear.

    Accepted shapes:
      - "https://host"                  → "https://host/api/telemetry"
      - "https://host/"                 → "https://host/api/telemetry"
      - "https://host/api/v1"           → "https://host/api/telemetry"  (typo / router URL)
      - "https://host/v1"               → "https://host/api/telemetry"
      - "https://host/api/telemetry"    → unchanged
      - "https://host/<anything>/telemetry/..."  → unchanged (already telemetry)
    """
    try:
        from urllib.parse import urlparse
    except Exception:
        return value
    try:
        p = urlparse(value.rstrip("/"))
    except Exception:
        return value
    if not p.scheme or not p.netloc:
        # Not a parseable URL — let the SDK fail at export time with a real
        # network error so it's visible.
        return value
    path = p.path or ""
    # Already pointing at a /telemetry path of any kind — accept as-is.
    if "/telemetry" in path:
        return f"{p.scheme}://{p.netloc}{path}"
    # Common router-URL mistakes — strip them and force the telemetry path.
    return f"{p.scheme}://{p.netloc}/api/telemetry"


def _resolve_api_key(explicit: Optional[str]) -> Optional[str]:
    return (
        explicit
        or os.environ.get("ORBITRAGE_API_KEY")
        or os.environ.get("TRACELOOP_API_KEY")
    )


def _silence_otel_exporter_noise() -> None:
    """Stop OTel from printing 'Failed to export span batch ...' on every retry.

    Export failures (auth, quota, network) are recoverable: the BSP keeps
    spans in its in-memory queue and retries on the next interval. Users
    shouldn't see scary stack traces in their normal console output —
    that's the equivalent of Sentry printing red errors every time the
    Sentry backend is down. Errors are still logged at DEBUG level so
    operators can opt in with ORBITRAGE_DEBUG=1.
    """
    level = logging.WARNING if os.environ.get("ORBITRAGE_DEBUG") else logging.CRITICAL
    for name in (
        "opentelemetry.exporter.otlp.proto.http.trace_exporter",
        "opentelemetry.exporter.otlp.proto.http._log_exporter",
        "opentelemetry.exporter.otlp.proto.http.metric_exporter",
        "opentelemetry.sdk.trace.export",
    ):
        logging.getLogger(name).setLevel(level)


def _set_bsp_env_defaults() -> None:
    """Tune OTel's BatchSpanProcessor for low-latency export.

    Env vars are read by BatchSpanProcessor at instantiation time. We only
    set them if the user didn't already — never override their intent.

    - SCHEDULE_DELAY=500ms: flush twice per second instead of every 5s, so
      short-lived scripts get data flushed without leaning on shutdown.
    - MAX_QUEUE_SIZE=4096: roomy enough for chatty agents (each LLM call
      can emit a dozen spans across http, langchain, openai, tool levels).
    - MAX_EXPORT_BATCH_SIZE=512: bigger batches = fewer HTTP RTTs.
    """
    defaults = {
        "OTEL_BSP_SCHEDULE_DELAY": "500",
        "OTEL_BSP_MAX_QUEUE_SIZE": "4096",
        "OTEL_BSP_MAX_EXPORT_BATCH_SIZE": "512",
        "OTEL_BSP_EXPORT_TIMEOUT": "10000",
    }
    for k, v in defaults.items():
        os.environ.setdefault(k, v)


_API_KEY_RE = re.compile(r"^orb_[A-Za-z0-9_\-]{10,200}$")


# ── init ──────────────────────────────────────────────────────────────────
def init(
    api_key: Optional[str] = None,
    *,
    user_id: Optional[str] = None,
    endpoint: Optional[str] = None,
    base_url: Optional[str] = None,
    enabled: bool = True,
    disable_batch: bool = False,
    capture_content: bool = True,
    instruments: Optional[Set[Any]] = None,
    block_instruments: Optional[Set[Any]] = None,
    resource_attributes: Optional[dict] = None,
    flush_on_exit: bool = True,
    quiet: bool = False,
) -> Any:
    """Initialize Orbitrage observability. Call once at program startup.

    Args:
        api_key:        Your Orbitrage API key (orb_xxx_yyy). Falls back to
                        ORBITRAGE_API_KEY env var. The key is minted per
                        workflow from the dashboard — the workflow you see
                        the data in is the one the key belongs to.

        user_id:        OPTIONAL — the org's end-user identifier (i.e. your
                        customer's user). When set, every span emitted by
                        this process is tagged with it, so the dashboard can
                        build per-user clusters / flow graphs inside one
                        workflow. Leave None for backend / cron / batch
                        flows where there is no end-user.

        endpoint:       Override the telemetry endpoint. Almost never needed.
        enabled:        Set False to no-op the SDK (tests, CI).
        disable_batch:  We force-warn on this — synchronous OTLP export adds
                        ~800ms per span. Don't use it outside Jupyter.
        capture_content: When True (default), prompt + completion text is
                         exported on every span so they render in the
                         Orbitrage flow graph. Set False to redact content
                         for compliance (token counts + cost + routing are
                         still captured).
        flush_on_exit:  Register an atexit hook that flushes spans before
                        process exit. Default True — turn off only if you
                        manage the flush yourself.
        quiet:          Suppress the one-line "telemetry on" log.

    Returns:
        The underlying Traceloop client (or None if disabled).
    """
    global _initialized, _client, _tracer_wrapper, _user_id

    if _initialized:
        return _client

    api_key = _resolve_api_key(api_key)
    if not enabled:
        if not quiet:
            logger.info("orbitrage disabled")
        _initialized = True
        return None

    if not api_key:
        # Soft-fail rather than raising: same philosophy as Sentry. The
        # user's app should not crash because telemetry was misconfigured.
        if not quiet:
            sys.stderr.write(
                "orbitrage: no API key provided — telemetry off. "
                "Set ORBITRAGE_API_KEY or call orbitrage.init('orb_...').\n"
            )
        _initialized = True
        return None

    # Cheap shape check — rejects typos that could exfiltrate prompts to a
    # wrong endpoint. Matches the live key format (orb_<prefix>_<secret>).
    if not _API_KEY_RE.match(api_key):
        sys.stderr.write(
            "orbitrage: API key format invalid (expected `orb_<prefix>_<secret>`) "
            "— telemetry off.\n"
        )
        _initialized = True
        return None

    # Force batch mode — this is the single biggest perf win. If a user
    # explicitly asks for disable_batch=True we'll honor it after warning.
    if disable_batch:
        sys.stderr.write(
            "orbitrage: disable_batch=True forces synchronous OTLP export "
            "(adds ~100-200ms per span). Strongly consider leaving it False.\n"
        )

    _set_bsp_env_defaults()
    _silence_otel_exporter_noise()

    # Privacy-first content default. Traceloop's own default is "true" —
    # meaning every prompt + completion would be POSTed to the OTLP endpoint.
    # We require an explicit opt-in via `capture_content=True`. The env var
    # is the toggle Traceloop's instrumentors read at span time.
    if capture_content:
        os.environ["TRACELOOP_TRACE_CONTENT"] = "true"
    else:
        # setdefault so a deliberately-set "true" via env still works.
        os.environ.setdefault("TRACELOOP_TRACE_CONTENT", "false")

    # Resolve endpoint. Accept `base_url=` as an alias for `endpoint=` since
    # that's the name many SDK users reach for (matches OpenAI / LangChain
    # conventions). If both are passed, `endpoint` wins — it's the more
    # explicit name. Then normalize: if the value points at the router
    # (`/api/v1`) or a bare host, rewrite to the telemetry path.
    if endpoint is None and base_url:
        endpoint = base_url
    resolved = _resolve_endpoint(endpoint)
    normalized = _normalize_telemetry_endpoint(resolved)
    if normalized != resolved and not quiet:
        sys.stderr.write(
            f"orbitrage: rewrote endpoint '{resolved}' → '{normalized}' "
            "(telemetry endpoint, not router URL).\n"
        )
    endpoint = normalized
    # The workflow comes from the API key, not from any app_name flag — we
    # use a constant for Traceloop's internal `app_name` (it only feeds the
    # OTel `service.name` resource attribute).
    internal_app_name = _default_app_name()

    # Stash the org's end-user id so the post-init association-property
    # call can propagate it to every subsequent span.
    _user_id = user_id.strip() if isinstance(user_id, str) and user_id.strip() else None

    # Lazy import: importing traceloop ~150 ms on cold disk. We pay that once
    # but only when init is actually called.
    from traceloop.sdk import Traceloop

    # Auto-detect instruments unless the caller pinned a set explicitly.
    # Cuts init from ~2.6s (all 30+ instrumentors) to ~0.9s on a typical
    # openai-only app, because Traceloop only imports what's installed.
    if instruments is None:
        instruments = _autodetect_instruments()

    try:
        client = Traceloop.init(
            app_name=internal_app_name,
            api_endpoint=endpoint,
            api_key=api_key,
            disable_batch=disable_batch,
            telemetry_enabled=False,  # don't phone home to traceloop.com
            traceloop_sync_enabled=False,
            instruments=instruments,
            block_instruments=block_instruments,
            resource_attributes=resource_attributes or {},
        )
    except Exception as e:
        sys.stderr.write(f"orbitrage: init failed ({e}) — telemetry off.\n")
        _initialized = True
        return None

    _client = client
    _initialized = True

    # Install a process-level root span AFTER Traceloop init so its tracer
    # provider is live. Every child LLM span inherits this root's trace_id
    # via the contextvars-based active context, so the dashboard groups
    # all calls in a single workflow row.
    _install_root_span()

    # Propagate the end-user id (if set) to every subsequent span via
    # Traceloop's association-property mechanism. It sets a contextvar
    # that Traceloop's span processor reads to tag spans with
    # `traceloop.association.properties.user_id = <user_id>`. The server
    # reads that attribute into telemetry_spans.end_user_id.
    if _user_id:
        try:
            Traceloop.set_association_properties({"user_id": _user_id})
        except Exception:
            # Older Traceloop versions might not expose this; fall back to
            # only the root-span tag (set in _install_root_span). Child
            # spans still inherit parent attributes in some viewers.
            pass

    # Auto-instrument httpx so the W3C traceparent header rides every LLM
    # HTTP request. Without this the orbitrage backend has no per-process
    # marker and falls back to a 30-second sticky run_id, which causes
    # back-to-back re-runs to appear as one workflow.
    _enable_http_propagation()

    if flush_on_exit:
        atexit.register(_safe_shutdown)

    if not quiet:
        if _user_id:
            logger.info("orbitrage: telemetry → %s user=%s", endpoint, _user_id)
        else:
            logger.info("orbitrage: telemetry → %s", endpoint)
    return client


def _enable_http_propagation() -> None:
    """Auto-instrument httpx so the openai client carries traceparent.

    openai's Python client uses httpx under the hood. Without the OTel httpx
    instrumentor active, the `traceparent` HTTP header is never injected,
    and the orbitrage backend falls back to a 30s sticky-window run_id when
    matching incoming calls to a workflow — back-to-back re-runs collapse.

    Best-effort: if the optional dep isn't installed, we just continue.
    """
    try:
        from opentelemetry.instrumentation.httpx import HTTPXClientInstrumentor
        # Idempotent — the instrumentor tracks its own state.
        HTTPXClientInstrumentor().instrument()
    except Exception:
        # No httpx instrumentor available, or it's already instrumented and
        # the second call raised. Either way — non-fatal.
        pass


def _install_root_span() -> None:
    """Open a long-lived root span and attach it to the global context.

    The span never ends until shutdown; it serves as the parent of every
    LLM span produced by Traceloop's instrumentors. Without this, each
    `openai.chat.completions.create()` is its own top-level trace and the
    dashboard renders 1 row per call.

    If an end-user id is bound, the root span is tagged with the OTel
    semconv `gen_ai.end_user.id` AND the Traceloop association attribute
    so dashboards / queries that key on either still light up.
    """
    global _root_span, _root_token
    try:
        from opentelemetry import context, trace
        from opentelemetry.trace import set_span_in_context
        tracer = trace.get_tracer("orbitrage")
        _root_span = tracer.start_span("orbitrage.workflow")
        if _user_id:
            _root_span.set_attribute("gen_ai.end_user.id", _user_id)
            _root_span.set_attribute("traceloop.association.properties.user_id", _user_id)
        _root_token = context.attach(set_span_in_context(_root_span))
    except Exception:
        # Non-fatal — without the root, the dashboard just shows one row
        # per call (the pre-0.3 behavior). Don't break user code.
        _root_span = None
        _root_token = None


def _default_app_name() -> str:
    """Best-effort default for Traceloop's internal app_name (becomes the
    OTel `service.name` resource attribute). NOT user-facing and NOT used
    by the Orbitrage server to identify the workflow — that's done by the
    API key. This just keeps logs readable.
    """
    try:
        argv0 = sys.argv[0] if sys.argv and sys.argv[0] else ""
        if argv0:
            base = os.path.basename(argv0)
            stem = os.path.splitext(base)[0]
            if stem:
                return stem
    except Exception:
        pass
    return "orbitrage"


# ── lifecycle ─────────────────────────────────────────────────────────────
def flush(timeout_ms: int = 5000) -> bool:
    """Force-flush pending spans. Returns True on success."""
    if not _initialized:
        return True
    try:
        from opentelemetry import trace
        provider = trace.get_tracer_provider()
        fn = getattr(provider, "force_flush", None)
        if callable(fn):
            return bool(fn(timeout_ms))
    except Exception:
        pass
    return True


def shutdown() -> None:
    """Shut down the SDK. Flushes pending spans then closes the exporter."""
    if not _initialized:
        return
    _safe_shutdown()


def _safe_shutdown() -> None:
    """atexit-friendly shutdown — never raises.

    Closes the root span (so it gets exported with the full workflow
    duration), detaches the context, then shuts down the OTel provider.
    """
    global _root_span, _root_token
    if _root_span is not None:
        try:
            _root_span.end()
        except Exception:
            pass
        _root_span = None
    if _root_token is not None:
        try:
            from opentelemetry import context as _ctx
            _ctx.detach(_root_token)
        except Exception:
            pass
        _root_token = None
    try:
        from opentelemetry import trace
        provider = trace.get_tracer_provider()
        fn = getattr(provider, "shutdown", None)
        if callable(fn):
            fn()
    except Exception:
        pass


# ── decorators (re-export from Traceloop) ─────────────────────────────────
def workflow(name: Optional[str] = None, **kwargs) -> Callable:
    """Mark a function as a workflow (groups all nested LLM calls).

    @orbitrage.workflow("checkout")
    def run():
        ...
    """
    from traceloop.sdk.decorators import workflow as _wf
    return _wf(name=name, **kwargs)


def task(name: Optional[str] = None, **kwargs) -> Callable:
    """Mark a function as a single task inside a workflow."""
    from traceloop.sdk.decorators import task as _t
    return _t(name=name, **kwargs)


def tool(name: Optional[str] = None, **kwargs) -> Callable:
    """Mark a function as a tool call."""
    from traceloop.sdk.decorators import tool as _t
    return _t(name=name, **kwargs)


def agent(name: Optional[str] = None, **kwargs) -> Callable:
    """Mark a function as an agent step."""
    from traceloop.sdk.decorators import agent as _a
    return _a(name=name, **kwargs)


def set_association_properties(properties: dict) -> None:
    """Attach metadata (user_id, tenant_id, etc.) to every span in scope.

    Use this if you want to switch end-users mid-run (e.g. a long-running
    server that processes requests for many users). The properties are
    merged into the current OTel context so all spans created downstream
    inherit them.
    """
    if not _initialized:
        return
    try:
        from traceloop.sdk import Traceloop
        Traceloop.set_association_properties(properties)
    except Exception:
        pass


def set_user(user_id: Optional[str]) -> None:
    """Convenience wrapper: bind/unbind the end-user id without manually
    constructing the association-properties dict. Pass None to clear.
    """
    global _user_id
    if user_id is None or (isinstance(user_id, str) and not user_id.strip()):
        _user_id = None
        set_association_properties({"user_id": ""})
        return
    _user_id = user_id.strip()
    set_association_properties({"user_id": _user_id})
