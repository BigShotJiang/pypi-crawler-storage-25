"""orbitrage — one-line observability + intelligent routing for Python agents.

Usage:
    import orbitrage
    orbitrage.init("orb_xxx_yyy")
"""
from __future__ import annotations

from ._client import (
    init,
    flush,
    shutdown,
    workflow,
    task,
    tool,
    agent,
    set_association_properties,
    set_user,
)

__all__ = [
    "init",
    "flush",
    "shutdown",
    "workflow",
    "task",
    "tool",
    "agent",
    "set_association_properties",
    "set_user",
]

__version__ = "0.4.2"
