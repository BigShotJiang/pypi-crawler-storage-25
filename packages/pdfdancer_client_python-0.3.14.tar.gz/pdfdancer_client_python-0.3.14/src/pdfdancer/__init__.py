"""
PDFDancer Python Client

A Python client library for the PDFDancer PDF manipulation API.
Provides a clean, Pythonic interface for PDF operations that closely
mirrors the Java client structure and functionality.
"""

from .exceptions import (
    FontNotFoundException,
    HttpClientException,
    PdfDancerException,
    RateLimitException,
    SessionException,
    SessionNotFoundException,
    ValidationException,
)
from .models import (
    Bezier,
    BoundingRect,
    Color,
    Font,
    FontRecommendation,
    FontType,
    FormFieldRef,
    Image,
    ImageFlipDirection,
    ImageTransformRequest,
    ImageTransformType,
    Line,
    ModifyPathRequest,
    ObjectRef,
    ObjectType,
    Orientation,
    PageRef,
    PageSize,
    Paragraph,
    Path,
    PathGroupInfo,
    PathObjectRef,
    PathSegment,
    Point,
    Position,
    PositionMode,
    RedactResponse,
    RedactTarget,
    ReflowPreset,
    ShapeType,
    Size,
    StandardFonts,
    TextObjectRef,
    TextStatus,
)
from .types import PathGroupObject
from .page_builder import PageBuilder
from .paragraph_builder import ParagraphBuilder
from .path_builder import BezierBuilder, LineBuilder, PathBuilder
from ._runtime_version import resolve_package_version
from .text_line_builder import TextLineBuilder

__version__ = resolve_package_version()

__all__ = [
    "PDFDancer",
    "ParagraphBuilder",
    "TextLineBuilder",
    "PageBuilder",
    "PathBuilder",
    "LineBuilder",
    "BezierBuilder",
    "ObjectRef",
    "PathObjectRef",
    "ModifyPathRequest",
    "Position",
    "ObjectType",
    "Font",
    "Color",
    "Image",
    "ImageFlipDirection",
    "ImageTransformRequest",
    "ImageTransformType",
    "Size",
    "BoundingRect",
    "Paragraph",
    "FormFieldRef",
    "TextObjectRef",
    "PageRef",
    "PositionMode",
    "ShapeType",
    "Point",
    "StandardFonts",
    "PageSize",
    "Orientation",
    "TextStatus",
    "FontRecommendation",
    "FontType",
    "PathSegment",
    "Line",
    "Bezier",
    "Path",
    "PathGroupInfo",
    "PathGroupObject",
    "RedactTarget",
    "RedactResponse",
    "ReflowPreset",
    "PdfDancerException",
    "FontNotFoundException",
    "ValidationException",
    "HttpClientException",
    "SessionException",
    "SessionNotFoundException",
    "RateLimitException",
    "set_ssl_verify",
]

from . import pdfdancer_v1
from .pdfdancer_v1 import PDFDancer


def set_ssl_verify(enabled: bool) -> None:
    """
    Enable or disable SSL certificate verification for all API requests.

    Args:
        enabled: True to enable SSL verification (default, secure),
                False to disable SSL verification (only for testing with self-signed certs)

    WARNING: Disabling SSL verification should only be done in development/testing
    environments with self-signed certificates. Never disable in production.

    Example:
        import pdfdancer
        pdfdancer.set_ssl_verify(False)  # Disable SSL verification
    """
    pdfdancer_v1.DISABLE_SSL_VERIFY = not enabled
