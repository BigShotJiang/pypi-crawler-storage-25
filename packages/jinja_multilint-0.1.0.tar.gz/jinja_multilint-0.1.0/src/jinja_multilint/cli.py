"""Command-line interface."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from . import __version__
from .config import Mode, load_config
from .linter import lint_file


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="jinja-multilint",
        description="Lint Jinja2 templates with ecosystem-aware filter/test checking.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    parser.add_argument(
        "--config",
        type=Path,
        metavar="PATH",
        help="Path to config file (default: auto-detect .jinja-multilint.yaml in CWD)",
    )
    parser.add_argument(
        "--mode",
        choices=[m.value for m in Mode],
        help=(
            "Strictness mode. "
            "strict (default): unknown filter/test is an error. "
            "warn: print warning, exit 0. "
            "lax: skip filter/test checks (syntax errors still fail)."
        ),
    )
    parser.add_argument(
        "--ecosystem",
        action="append",
        default=[],
        metavar="NAME",
        help="Enable ecosystem plugin (repeatable). E.g., --ecosystem salt",
    )
    parser.add_argument(
        "--filter",
        action="append",
        default=[],
        dest="filters",
        metavar="NAME",
        help="Add a known filter name (repeatable). Extends config and ecosystems.",
    )
    parser.add_argument(
        "--test",
        action="append",
        default=[],
        dest="tests",
        metavar="NAME",
        help="Add a known test name (repeatable). Extends config and ecosystems.",
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Suppress per-file OK lines; print only errors and warnings.",
    )
    parser.add_argument(
        "files",
        nargs="+",
        type=Path,
        metavar="FILE",
        help="Template files to lint.",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)

    try:
        config = load_config(args.config)
    except FileNotFoundError as e:
        print(f"error: {e}", file=sys.stderr)
        return 2

    if args.mode:
        config.mode = Mode(args.mode)
    config.ecosystems.extend(args.ecosystem)
    config.filters.extend(args.filters)
    config.tests.extend(args.tests)

    rc = 0
    for path in args.files:
        result = lint_file(path, config)
        for w in result.warnings:
            print(f"{result.path}: WARN: {w}", file=sys.stderr)
        for e in result.errors:
            print(f"{result.path}: ERROR: {e}", file=sys.stderr)
        if result.ok and not args.quiet:
            print(f"{result.path}: OK")
        if not result.ok:
            rc = 1

    return rc


if __name__ == "__main__":
    sys.exit(main())
