"""Jinja2 template linter with multi-ecosystem filter awareness."""

__version__ = "0.1.0"
