"""Configuration loading from YAML files."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

import yaml


class Mode(str, Enum):
    """Strictness mode for unknown filters/tests."""

    STRICT = "strict"  # Unknown filter/test = error (default)
    WARN = "warn"  # Unknown filter/test = stderr warning, exit 0
    LAX = "lax"  # Skip filter/test checks entirely (syntax still checked)


@dataclass
class Config:
    mode: Mode = Mode.STRICT
    ecosystems: list[str] = field(default_factory=list)
    filters: list[str] = field(default_factory=list)
    tests: list[str] = field(default_factory=list)
    extensions: list[str] = field(default_factory=list)


CONFIG_FILENAMES: tuple[str, ...] = (
    ".jinja-multilint.yaml",
    ".jinja-multilint.yml",
)
LEGACY_FILTER_FILENAMES: tuple[str, ...] = (".jinja-multilint-filters",)


def load_config(explicit_path: Path | None = None) -> Config:
    """Load config from explicit path, or auto-detect in CWD.

    Precedence:
    1. ``explicit_path`` if provided
    2. ``.jinja-multilint.yaml`` / ``.jinja-multilint.yml`` in CWD
    3. ``.jinja-multilint-filters`` (flat one-filter-per-line file) in CWD
    4. Defaults (empty Config)
    """
    if explicit_path is not None:
        if not explicit_path.exists():
            raise FileNotFoundError(f"Config file not found: {explicit_path}")
        return _parse_yaml(explicit_path)

    for name in CONFIG_FILENAMES:
        path = Path(name)
        if path.exists():
            return _parse_yaml(path)

    for name in LEGACY_FILTER_FILENAMES:
        path = Path(name)
        if path.exists():
            return _parse_flat_filters(path)

    return Config()


def _parse_yaml(path: Path) -> Config:
    data = yaml.safe_load(path.read_text()) or {}
    return Config(
        mode=Mode(data.get("mode", Mode.STRICT.value)),
        ecosystems=list(data.get("ecosystems", [])),
        filters=list(data.get("filters", [])),
        tests=list(data.get("tests", [])),
        extensions=list(data.get("extensions", [])),
    )


def _parse_flat_filters(path: Path) -> Config:
    filters = [
        line.split("#", 1)[0].strip()
        for line in path.read_text().splitlines()
        if line.split("#", 1)[0].strip()
    ]
    return Config(filters=filters)
