"""Plugin discovery via entry points.

Ecosystem plugins (including the built-in salt/ansible/home_assistant ones)
are discovered via the ``jinja_multilint.ecosystems`` entry-point group.

A plugin is a module exposing the following attributes:

    FILTERS:    iterable of filter name strings
    TESTS:      iterable of Jinja test name strings (used with ``is``)
    EXTENSIONS: iterable of Jinja2 extension import paths (optional)

Register via ``[project.entry-points."jinja_multilint.ecosystems"]`` in
the plugin's ``pyproject.toml``::

    [project.entry-points."jinja_multilint.ecosystems"]
    my_ecosystem = "my_plugin_package"
"""

from __future__ import annotations

import sys
from dataclasses import dataclass, field
from importlib.metadata import entry_points

ENTRY_POINT_GROUP = "jinja_multilint.ecosystems"


@dataclass
class Ecosystem:
    """Resolved ecosystem plugin data."""

    name: str
    filters: set[str] = field(default_factory=set)
    tests: set[str] = field(default_factory=set)
    extensions: list[str] = field(default_factory=list)


def discover_ecosystems() -> dict[str, Ecosystem]:
    """Discover all registered ecosystem plugins in the current environment.

    Plugins that fail to load emit a warning to stderr but do not abort
    the run, so one bad plugin doesn't break linting against the others.
    """
    found: dict[str, Ecosystem] = {}
    for ep in entry_points(group=ENTRY_POINT_GROUP):
        try:
            mod = ep.load()
        except Exception as e:  # noqa: BLE001 - one bad plugin shouldn't kill discovery
            print(
                f"warning: failed to load ecosystem plugin '{ep.name}': {e}",
                file=sys.stderr,
            )
            continue
        found[ep.name] = Ecosystem(
            name=ep.name,
            filters=set(getattr(mod, "FILTERS", ())),
            tests=set(getattr(mod, "TESTS", ())),
            extensions=list(getattr(mod, "EXTENSIONS", ())),
        )
    return found


def get_ecosystem(name: str, discovered: dict[str, Ecosystem] | None = None) -> Ecosystem:
    """Get a specific ecosystem by name. Raises KeyError with a helpful message."""
    if discovered is None:
        discovered = discover_ecosystems()
    if name not in discovered:
        available = ", ".join(sorted(discovered)) or "(none installed)"
        raise KeyError(f"Unknown ecosystem '{name}'. Available: {available}")
    return discovered[name]
