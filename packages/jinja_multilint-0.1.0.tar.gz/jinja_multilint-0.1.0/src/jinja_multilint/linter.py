"""Core lint logic: parse template, walk AST, check filter/test names."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from jinja2 import Environment, exceptions, nodes

from .config import Config, Mode
from .plugins import discover_ecosystems


@dataclass
class LintResult:
    """Result of linting a single file."""

    path: Path
    ok: bool
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


def _stub(*_args, **_kwargs):
    """Placeholder filter/test implementation; never executed at lint time."""
    return None


def lint_file(path: Path, config: Config) -> LintResult:
    """Lint a single Jinja2 template file."""
    if not path.exists():
        return LintResult(path=path, ok=False, errors=[f"File not found: {path}"])

    try:
        source = path.read_text()
    except (OSError, UnicodeDecodeError) as e:
        return LintResult(path=path, ok=False, errors=[f"Cannot read file: {e}"])

    # Resolve ecosystems: collect filters, tests, and extensions
    discovered = discover_ecosystems()
    extensions: list[str] = list(config.extensions)
    eco_filters: set[str] = set()
    eco_tests: set[str] = set()
    for eco_name in config.ecosystems:
        if eco_name not in discovered:
            available = ", ".join(sorted(discovered)) or "(none installed)"
            return LintResult(
                path=path,
                ok=False,
                errors=[f"Unknown ecosystem '{eco_name}'. Available: {available}"],
            )
        eco = discovered[eco_name]
        eco_filters |= eco.filters
        eco_tests |= eco.tests
        extensions.extend(eco.extensions)

    # Build Jinja2 environment with extensions (dedup preserving order)
    env_kwargs: dict = {}
    if extensions:
        env_kwargs["extensions"] = list(dict.fromkeys(extensions))
    try:
        env = Environment(**env_kwargs)  # noqa: S701 - linter does not render
    except Exception as e:  # noqa: BLE001
        return LintResult(path=path, ok=False, errors=[f"Invalid environment: {e}"])

    # Register stubs so allowed names are recognized as defined
    for name in eco_filters | set(config.filters):
        env.filters[name] = _stub
    for name in eco_tests | set(config.tests):
        env.tests[name] = _stub

    # Parse — catches syntax errors regardless of mode
    try:
        ast = env.parse(source, filename=str(path))
    except exceptions.TemplateSyntaxError as e:
        line = e.lineno if e.lineno else "?"
        return LintResult(
            path=path,
            ok=False,
            errors=[f"Syntax error at line {line}: {e.message}"],
        )

    if config.mode == Mode.LAX:
        return LintResult(path=path, ok=True)

    # Walk AST collecting filter/test usages
    used_filters: set[str] = {n.name for n in ast.find_all(nodes.Filter)}
    used_tests: set[str] = {n.name for n in ast.find_all(nodes.Test)}

    unknown_filters = used_filters - set(env.filters.keys())
    unknown_tests = used_tests - set(env.tests.keys())

    messages: list[str] = []
    for name in sorted(unknown_filters):
        messages.append(f"Unknown filter: '{name}'")
    for name in sorted(unknown_tests):
        messages.append(f"Unknown test: '{name}'")

    if not messages:
        return LintResult(path=path, ok=True)

    if config.mode == Mode.WARN:
        return LintResult(path=path, ok=True, warnings=messages)

    return LintResult(path=path, ok=False, errors=messages)
