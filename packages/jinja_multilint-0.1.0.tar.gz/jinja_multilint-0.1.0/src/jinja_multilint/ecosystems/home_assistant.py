"""Home Assistant Jinja2 filters and tests.

Sourced from homeassistant/helpers/template.py. List is curated for
v0.x and may not be exhaustive across all HA versions; contributions
welcome.

Reference: https://www.home-assistant.io/docs/configuration/templating/
"""

from __future__ import annotations

FILTERS: frozenset[str] = frozenset(
    {
        # Regex
        "regex_match",
        "regex_search",
        "regex_findall",
        "regex_findall_index",
        "regex_replace",
        # Bitwise
        "bitwise_and",
        "bitwise_or",
        "bitwise_xor",
        # Date / time
        "as_datetime",
        "as_timestamp",
        "as_local",
        "today_at",
        "tomorrow_at",
        "yesterday_at",
        "relative_time",
        "time_since",
        "time_until",
        "timedelta",
        # Conditional / version
        "iif",
        "version",
        # Conversion / coercion
        "bool",
        "int",
        "float",
        "ord",
        "pack",
        "unpack",
        "base64_encode",
        "base64_decode",
        "urlencode",
        "slugify",
        "ordereddict",
        "from_json",
        "to_json",
        "is_number",
        "combine",
        # Statistics
        "min",
        "max",
        "average",
        "median",
        "statistical_mode",
        # Entity / state
        "expand",
        "closest",
        "distance",
        "device_attr",
        "device_id",
        "device_entities",
        "is_hidden_entity",
        "state_attr",
        "states",
        "is_state",
        "is_state_attr",
        "entity_sources",
        "config_entry_id",
        "integration_entities",
        # Area / floor / label (HA 2024+)
        "area_name",
        "area_id",
        "area_entities",
        "area_devices",
        "label_id",
        "label_name",
        "label_areas",
        "label_devices",
        "label_entities",
        "floor_id",
        "floor_name",
        "floor_areas",
        "floor_entities",
        # Misc
        "random",
        "contains",
    }
)

TESTS: frozenset[str] = frozenset(
    {
        "match",
        "search",
        "is_state",
        "is_state_attr",
        "contains",
    }
)

EXTENSIONS: list[str] = []
