"""Built-in ecosystem plugins.

Each ecosystem is a submodule exposing ``FILTERS`` (set of filter names),
``TESTS`` (set of test names), and optionally ``EXTENSIONS`` (list of
Jinja2 extension import paths).

They are registered as plugins via ``[project.entry-points."jinja_multilint.ecosystems"]``
in this package's pyproject.toml — there is no special-cased "built-in"
loading path. See ``src/jinja_multilint/plugins.py``.
"""
