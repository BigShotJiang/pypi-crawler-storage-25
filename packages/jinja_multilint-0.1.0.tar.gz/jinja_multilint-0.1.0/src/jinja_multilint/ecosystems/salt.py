"""Salt-specific Jinja2 filters and tests.

Sourced from Salt's Jinja extensions. List is curated for v0.x and may
not be exhaustive across all Salt versions; contributions welcome.

Reference: https://docs.saltproject.io/en/latest/topics/jinja/index.html
"""

from __future__ import annotations

FILTERS: frozenset[str] = frozenset(
    {
        # YAML / serialization
        "yaml",
        "yaml_dquote",
        "yaml_squote",
        "yaml_encode",
        "json",
        "json_decode_dict",
        "json_decode_list",
        "json_encode_dict",
        "json_encode_list",
        "load_json",
        "load_yaml",
        "tojson",
        # Encoding
        "base64_encode",
        "base64_decode",
        "hex_encode",
        "hex_decode",
        "url_encode",
        "url_decode",
        # Hashing / crypto
        "md5",
        "sha1",
        "sha256",
        "sha512",
        "hmac",
        "random_hash",
        "rand_str",
        # Regex
        "regex_escape",
        "regex_match",
        "regex_replace",
        "regex_search",
        # Network / IP
        "is_ip",
        "is_ipv4",
        "is_ipv6",
        "ipaddr",
        "ipv4",
        "ipv6",
        "ip_to_int",
        "int_to_ipv4",
        "network_hosts",
        "network_size",
        "cidr_to_ipv4_netmask",
        "mac_str_to_bytes",
        # Date / time
        "date_format",
        "strftime",
        "timestamp",
        "to_timestamp",
        # Identifiers
        "uuid",
        "gen_uuid",
        # Type / conversion
        "to_bool",
        "to_bytes",
        "to_num",
        "to_str",
        # Sequences / mappings
        "avg",
        "max",
        "min",
        "quantile",
        "sorted_ignorecase",
        "substring_in_list",
        "check_whitelist_blacklist",
        "exactly_n_true",
        "exactly_one_true",
        "compare_dicts",
        "compare_lists",
        # Strings
        "to_snake_case",
        "to_camelcase",
        "indent",
        "strip_proto",
        # Salt-specific helpers
        "skip",
        "list_files",
        "http_query",
        "random_int",
    }
)

TESTS: frozenset[str] = frozenset(
    {
        "match",
        "equalto",
        "is_ip",
        "is_ipv4",
        "is_ipv6",
    }
)

EXTENSIONS: list[str] = []
