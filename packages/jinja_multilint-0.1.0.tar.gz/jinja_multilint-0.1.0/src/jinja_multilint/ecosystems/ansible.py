"""Ansible-specific Jinja2 filters and tests.

Sourced from ansible-core. Does NOT include filters from external
collections (ansible.netcommon, community.general, etc.); those
would be separate plugin packages or extended via config ``filters:``.

List is curated for v0.x and may not be exhaustive; contributions welcome.

Reference: https://docs.ansible.com/ansible/latest/playbook_guide/playbooks_filters.html
"""

from __future__ import annotations

FILTERS: frozenset[str] = frozenset(
    {
        # YAML / JSON
        "to_yaml",
        "to_nice_yaml",
        "from_yaml",
        "from_yaml_all",
        "to_json",
        "to_nice_json",
        "from_json",
        # Encoding
        "b64decode",
        "b64encode",
        "urlencode",
        "urldecode",
        "url_split",
        "quote",
        # Hashing
        "hash",
        "checksum",
        "password_hash",
        "sha1",
        # Type coercion
        "bool",
        "int",
        "float",
        "string",
        "to_uuid",
        "ternary",
        # Collections
        "combine",
        "dict2items",
        "items2dict",
        "subelements",
        "zip",
        "zip_longest",
        "product",
        "permutations",
        "combinations",
        "flatten",
        "unique",
        "difference",
        "intersect",
        "union",
        "symmetric_difference",
        # Math / numeric
        "log",
        "pow",
        "root",
        "min",
        "max",
        # Strings
        "regex_escape",
        "regex_replace",
        "regex_search",
        "regex_findall",
        "comment",
        "expandvars",
        "expanduser",
        "basename",
        "dirname",
        "splitext",
        "realpath",
        "relpath",
        "win_basename",
        "win_dirname",
        "win_splitdrive",
        "splitter",
        # Network / IP
        "ipaddr",
        "ipv4",
        "ipv6",
        "ipsubnet",
        "ipmath",
        "ipwrap",
        "ipnet",
        "ipnetwork",
        "nthhost",
        "next_nth_usable",
        "previous_nth_usable",
        "network_in_network",
        "network_in_usable",
        "reduce_on_network",
        "cidr_merge",
        "hwaddr",
        "macaddr",
        # JSON query
        "json_query",
        # Randomness
        "random",
        "shuffle",
        "random_mac",
        # Date / time
        "to_datetime",
        "strftime",
        # Misc
        "mandatory",
        "default",
        "type_debug",
        "ansible_eval",
        "extract",
        "vault_decrypt",
    }
)

TESTS: frozenset[str] = frozenset(
    {
        # State tests (task results)
        "changed",
        "succeeded",
        "failed",
        "skipped",
        "success",
        "failure",
        "skip",
        # String tests
        "match",
        "search",
        "regex",
        "contains",
        # Set tests
        "subset",
        "superset",
        "issubset",
        "issuperset",
        # File tests
        "file",
        "directory",
        "link",
        "exists",
        "any",
        "all",
        "abs",
        # Type tests
        "truthy",
        "falsy",
        # Version comparison
        "version",
        "version_compare",
    }
)

EXTENSIONS: list[str] = []
