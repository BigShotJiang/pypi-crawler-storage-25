"""Tests for the linter core."""

from __future__ import annotations

from pathlib import Path

from jinja_multilint.config import Config, Mode
from jinja_multilint.linter import lint_file

FIXTURES = Path(__file__).parent / "fixtures"


def test_valid_salt_template_passes_with_salt_ecosystem():
    config = Config(ecosystems=["salt"])
    result = lint_file(FIXTURES / "valid_salt.j2", config)
    assert result.ok, result.errors


def test_valid_ansible_template_passes_with_ansible_ecosystem():
    config = Config(ecosystems=["ansible"])
    result = lint_file(FIXTURES / "valid_ansible.j2", config)
    assert result.ok, result.errors


def test_valid_ha_template_passes_with_home_assistant_ecosystem():
    config = Config(ecosystems=["home_assistant"])
    result = lint_file(FIXTURES / "valid_ha.j2", config)
    assert result.ok, result.errors


def test_unknown_filter_fails_in_strict_mode():
    config = Config(mode=Mode.STRICT)
    result = lint_file(FIXTURES / "unknown_filter.j2", config)
    assert not result.ok
    assert any("totally_made_up_filter_name" in e for e in result.errors)


def test_unknown_filter_warns_in_warn_mode():
    config = Config(mode=Mode.WARN)
    result = lint_file(FIXTURES / "unknown_filter.j2", config)
    assert result.ok
    assert any("totally_made_up_filter_name" in w for w in result.warnings)


def test_unknown_filter_ignored_in_lax_mode():
    config = Config(mode=Mode.LAX)
    result = lint_file(FIXTURES / "unknown_filter.j2", config)
    assert result.ok
    assert not result.warnings
    assert not result.errors


def test_unknown_test_fails_in_strict_mode():
    config = Config(mode=Mode.STRICT)
    result = lint_file(FIXTURES / "unknown_test.j2", config)
    assert not result.ok
    assert any("totally_made_up_test" in e for e in result.errors)


def test_syntax_error_fails_in_all_modes():
    for mode in (Mode.STRICT, Mode.WARN, Mode.LAX):
        config = Config(mode=mode)
        result = lint_file(FIXTURES / "syntax_error.j2", config)
        assert not result.ok, f"Should fail in {mode}"
        assert any("Syntax error" in e for e in result.errors)


def test_custom_filter_via_config_filters():
    config = Config(filters=["totally_made_up_filter_name"])
    result = lint_file(FIXTURES / "unknown_filter.j2", config)
    assert result.ok, result.errors


def test_missing_file_returns_error():
    config = Config()
    result = lint_file(FIXTURES / "does_not_exist.j2", config)
    assert not result.ok
    assert any("not found" in e for e in result.errors)


def test_unknown_ecosystem_returns_error():
    config = Config(ecosystems=["this_does_not_exist"])
    result = lint_file(FIXTURES / "valid_salt.j2", config)
    assert not result.ok
    assert any("Unknown ecosystem" in e for e in result.errors)
