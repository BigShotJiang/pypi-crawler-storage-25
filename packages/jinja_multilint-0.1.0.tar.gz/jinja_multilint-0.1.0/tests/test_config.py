"""Tests for config loading."""

from __future__ import annotations

from pathlib import Path

import pytest

from jinja_multilint.config import Config, Mode, load_config


def test_load_config_yaml(tmp_path: Path):
    cfg_path = tmp_path / ".jinja-multilint.yaml"
    cfg_path.write_text(
        "mode: warn\n"
        "ecosystems:\n"
        "  - salt\n"
        "filters:\n"
        "  - my_filter\n"
        "tests:\n"
        "  - my_test\n"
    )
    config = load_config(cfg_path)
    assert config.mode == Mode.WARN
    assert config.ecosystems == ["salt"]
    assert config.filters == ["my_filter"]
    assert config.tests == ["my_test"]


def test_load_config_defaults(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.chdir(tmp_path)
    config = load_config()
    assert config.mode == Mode.STRICT
    assert config.ecosystems == []
    assert config.filters == []
    assert config.tests == []


def test_load_config_missing_explicit_raises(tmp_path: Path):
    with pytest.raises(FileNotFoundError):
        load_config(tmp_path / "nonexistent.yaml")


def test_load_config_flat_filter_file_fallback(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.chdir(tmp_path)
    flat = tmp_path / ".jinja-multilint-filters"
    flat.write_text("# Comment line\nfilter_one\n\nfilter_two  # trailing comment\n")
    config = load_config()
    assert "filter_one" in config.filters
    assert "filter_two" in config.filters
    assert len(config.filters) == 2


def test_load_config_yaml_takes_precedence_over_flat(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
):
    monkeypatch.chdir(tmp_path)
    (tmp_path / ".jinja-multilint-filters").write_text("flat_filter\n")
    (tmp_path / ".jinja-multilint.yaml").write_text("filters: [yaml_filter]\n")
    config = load_config()
    assert config.filters == ["yaml_filter"]


def test_empty_yaml_config(tmp_path: Path):
    cfg_path = tmp_path / ".jinja-multilint.yaml"
    cfg_path.write_text("")
    config = load_config(cfg_path)
    assert config == Config()
