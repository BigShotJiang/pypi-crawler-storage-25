"""Tests for plugin discovery."""

from __future__ import annotations

import pytest

from jinja_multilint.plugins import discover_ecosystems, get_ecosystem


def test_builtin_ecosystems_discovered():
    discovered = discover_ecosystems()
    assert "salt" in discovered
    assert "ansible" in discovered
    assert "home_assistant" in discovered


def test_salt_ecosystem_has_known_filters():
    eco = get_ecosystem("salt")
    assert "regex_replace" in eco.filters
    assert "is_ip" in eco.filters
    assert "ipv6" in eco.filters


def test_ansible_ecosystem_has_known_filters():
    eco = get_ecosystem("ansible")
    assert "to_nice_yaml" in eco.filters
    assert "ipaddr" in eco.filters


def test_home_assistant_ecosystem_has_known_filters():
    eco = get_ecosystem("home_assistant")
    assert "as_local" in eco.filters
    assert "state_attr" in eco.filters


def test_get_unknown_ecosystem_raises():
    with pytest.raises(KeyError, match="Unknown ecosystem"):
        get_ecosystem("definitely_not_a_real_ecosystem")


def test_ecosystem_has_tests():
    salt = get_ecosystem("salt")
    assert "match" in salt.tests
    ansible = get_ecosystem("ansible")
    assert "succeeded" in ansible.tests
