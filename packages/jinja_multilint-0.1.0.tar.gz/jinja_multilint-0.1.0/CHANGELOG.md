# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0] - Initial release

### Added

- Plugin-based architecture for ecosystem support, using Python's
  `importlib.metadata` entry-point mechanism. Built-in ecosystems
  (salt, ansible, home_assistant) and third-party plugins are
  discovered via the same `jinja_multilint.ecosystems` entry point.
- Bundled ecosystem plugins for Salt, Ansible, and Home Assistant.
- YAML config file (`.jinja-multilint.yaml`) with `ecosystems`,
  `filters`, `tests`, `extensions`, and `mode`.
- Fallback to flat `.jinja-multilint-filters` file for migration from
  drm/jinja2-lint-style setups.
- Three operating modes: `strict` (default), `warn`, `lax`,
  selectable via `--mode` flag or config.
- CLI: `--config`, `--mode`, `--ecosystem`, `--filter`, `--test`,
  `--quiet`.
- Syntax-level checking via Jinja2 parser.
- Name-only validation of filters and tests against allow-list.
