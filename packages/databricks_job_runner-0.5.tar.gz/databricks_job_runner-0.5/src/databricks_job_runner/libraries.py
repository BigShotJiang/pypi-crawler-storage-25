"""Cluster library reconciliation helpers."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.compute import (
    Library,
    LibraryFullStatus,
    LibraryInstallStatus,
    MavenLibrary,
    PythonPyPiLibrary,
)

LibraryKind = Literal["whl", "pypi", "maven", "jar"]

_INSTALLED = {
    LibraryInstallStatus.INSTALLED,
    LibraryInstallStatus.RESTORED,
    LibraryInstallStatus.SKIPPED,
}
_PENDING = {
    LibraryInstallStatus.INSTALLING,
    LibraryInstallStatus.PENDING,
    LibraryInstallStatus.RESOLVING,
}


@dataclass(frozen=True)
class LibraryIdentity:
    """Comparable identity for Databricks cluster library sources."""

    kind: LibraryKind
    name: str
    version: str | None = None

    @property
    def key(self) -> tuple[str, str]:
        return self.kind, self.name

    def matches(self, other: "LibraryIdentity", *, exact: bool) -> bool:
        if self.key != other.key:
            return False
        if exact:
            return self.version == other.version
        return True


@dataclass(frozen=True)
class DesiredLibrary:
    """A desired cluster library and how strictly to compare it."""

    label: str
    library: Library
    identity: LibraryIdentity
    exact: bool = True
    project_owned: bool = False

    @classmethod
    def whl(
        cls, path: str, *, package: str, project_owned: bool = True
    ) -> "DesiredLibrary":
        identity = LibraryIdentity(
            "whl",
            _normalize_wheel_package(package),
            _wheel_version(Path(path).name),
        )
        return cls(
            label=f"wheel {package}",
            library=Library(whl=path),
            identity=identity,
            exact=True,
            project_owned=project_owned,
        )

    @classmethod
    def pypi(cls, package: str, *, repo: str | None = None) -> "DesiredLibrary":
        name, version = _parse_pypi_package(package)
        return cls(
            label=f"pypi {package}",
            library=Library(pypi=PythonPyPiLibrary(package=package, repo=repo)),
            identity=LibraryIdentity("pypi", name, version),
            exact=version is not None,
        )

    @classmethod
    def maven(
        cls,
        coordinates: str,
        *,
        repo: str | None = None,
        exclusions: list[str] | None = None,
    ) -> "DesiredLibrary":
        group_artifact, version = _parse_maven_coordinates(coordinates)
        return cls(
            label=f"maven {coordinates}",
            library=Library(
                maven=MavenLibrary(
                    coordinates=coordinates,
                    repo=repo,
                    exclusions=exclusions,
                )
            ),
            identity=LibraryIdentity("maven", group_artifact, version),
            exact=version is not None,
        )

    @classmethod
    def jar(cls, path: str) -> "DesiredLibrary":
        return cls(
            label=f"jar {path}",
            library=Library(jar=path),
            identity=LibraryIdentity("jar", path),
            exact=True,
        )


@dataclass(frozen=True)
class LibraryIssue:
    """A current cluster library status that needs operator attention."""

    label: str
    status: LibraryInstallStatus | None
    messages: tuple[str, ...] = ()


@dataclass(frozen=True)
class ClusterLibraryPlan:
    """Desired-vs-current cluster library reconciliation result."""

    installed: list[DesiredLibrary] = field(default_factory=list)
    missing: list[DesiredLibrary] = field(default_factory=list)
    pending: list[LibraryIssue] = field(default_factory=list)
    failed: list[LibraryIssue] = field(default_factory=list)
    uninstall_on_restart: list[LibraryIssue] = field(default_factory=list)
    stale: list[Library] = field(default_factory=list)

    @property
    def restart_required(self) -> bool:
        return bool(self.uninstall_on_restart or self.stale)

    @property
    def ready(self) -> bool:
        return not (
            self.missing
            or self.pending
            or self.failed
            or self.uninstall_on_restart
            or self.stale
        )


def check_cluster_libraries(
    ws: WorkspaceClient,
    cluster_id: str,
    desired: list[DesiredLibrary],
) -> ClusterLibraryPlan:
    """Compare desired libraries with current cluster library status."""
    current = list(ws.libraries.cluster_status(cluster_id=cluster_id))

    installed: list[DesiredLibrary] = []
    missing: list[DesiredLibrary] = []
    pending: list[LibraryIssue] = []
    failed: list[LibraryIssue] = []
    uninstall_on_restart: list[LibraryIssue] = []
    stale: list[Library] = []

    for spec in desired:
        matches = _matching_statuses(current, spec)
        install_matches = [
            item
            for item in matches
            if item.status in _INSTALLED and _status_satisfies(item, spec)
        ]
        pending_matches = [item for item in matches if item.status in _PENDING]
        failed_matches = [
            item for item in matches if item.status == LibraryInstallStatus.FAILED
        ]
        restart_matches = [
            item
            for item in matches
            if item.status == LibraryInstallStatus.UNINSTALL_ON_RESTART
        ]

        if install_matches:
            installed.append(spec)
        elif not pending_matches and not failed_matches and not restart_matches:
            missing.append(spec)

        pending.extend(_issues(pending_matches))
        failed.extend(_issues(failed_matches))
        uninstall_on_restart.extend(_issues(restart_matches))

        if spec.identity.kind == "whl" and spec.project_owned:
            for item in matches:
                lib = item.library
                if (
                    lib
                    and lib.whl
                    and lib.whl != spec.library.whl
                    and lib not in stale
                ):
                    stale.append(lib)

    return ClusterLibraryPlan(
        installed=installed,
        missing=missing,
        pending=pending,
        failed=failed,
        uninstall_on_restart=uninstall_on_restart,
        stale=stale,
    )


def sync_cluster_libraries(
    ws: WorkspaceClient,
    cluster_id: str,
    desired: list[DesiredLibrary],
    *,
    uninstall_stale: bool = True,
) -> ClusterLibraryPlan:
    """Install missing libraries and optionally uninstall stale owned wheels."""
    plan = check_cluster_libraries(ws, cluster_id, desired)
    if plan.missing:
        ws.libraries.install(
            cluster_id=cluster_id,
            libraries=[item.library for item in plan.missing],
        )
    if uninstall_stale and plan.stale:
        ws.libraries.uninstall(cluster_id=cluster_id, libraries=plan.stale)
    return plan


def format_cluster_library_plan(plan: ClusterLibraryPlan) -> str:
    """Return a readable multi-line summary for CLI output."""
    lines: list[str] = []
    _extend(lines, "Installed", [item.label for item in plan.installed])
    _extend(lines, "Missing", [item.label for item in plan.missing])
    _extend(lines, "Pending", [issue.label for issue in plan.pending])
    _extend(lines, "Failed", [_format_issue(issue) for issue in plan.failed])
    _extend(
        lines,
        "Uninstall on restart",
        [issue.label for issue in plan.uninstall_on_restart],
    )
    _extend(lines, "Stale", [_library_label(lib) for lib in plan.stale])
    if plan.restart_required:
        lines.append("Restart required: yes")
    return "\n".join(lines) if lines else "No cluster libraries found."


def identity_for_library(library: Library) -> LibraryIdentity | None:
    """Return a comparable identity for a Databricks SDK Library."""
    if library.whl:
        name = Path(library.whl).name
        return LibraryIdentity("whl", _wheel_package_name(name), _wheel_version(name))
    if library.pypi:
        name, version = _parse_pypi_package(library.pypi.package)
        return LibraryIdentity("pypi", name, version)
    if library.maven:
        name, version = _parse_maven_coordinates(library.maven.coordinates)
        return LibraryIdentity("maven", name, version)
    if library.jar:
        return LibraryIdentity("jar", library.jar)
    return None


def _matching_statuses(
    statuses: list[LibraryFullStatus], spec: DesiredLibrary
) -> list[LibraryFullStatus]:
    matches: list[LibraryFullStatus] = []
    for status in statuses:
        if not status.library:
            continue
        identity = identity_for_library(status.library)
        if identity and spec.identity.matches(identity, exact=False):
            matches.append(status)
    return matches


def _issues(statuses: list[LibraryFullStatus]) -> list[LibraryIssue]:
    return [
        LibraryIssue(
            label=_library_label(status.library),
            status=status.status,
            messages=tuple(status.messages or ()),
        )
        for status in statuses
    ]


def _same_library(left: Library | None, right: Library | None) -> bool:
    if left is None or right is None:
        return False
    return (
        left.whl == right.whl
        and left.jar == right.jar
        and _pypi_identity(left) == _pypi_identity(right)
        and _maven_coordinates(left) == _maven_coordinates(right)
    )


def _status_satisfies(status: LibraryFullStatus, spec: DesiredLibrary) -> bool:
    if spec.exact:
        return _same_library(status.library, spec.library)
    if not status.library:
        return False
    identity = identity_for_library(status.library)
    return bool(identity and spec.identity.matches(identity, exact=False))


def _pypi_identity(library: Library) -> tuple[str, str | None] | None:
    return _parse_pypi_package(library.pypi.package) if library.pypi else None


def _maven_coordinates(library: Library) -> str | None:
    return library.maven.coordinates if library.maven else None


def _library_label(library: Library | None) -> str:
    if library is None:
        return "(unknown library)"
    if library.whl:
        return f"wheel {library.whl}"
    if library.pypi:
        return f"pypi {library.pypi.package}"
    if library.maven:
        return f"maven {library.maven.coordinates}"
    if library.jar:
        return f"jar {library.jar}"
    return str(library)


def _format_issue(issue: LibraryIssue) -> str:
    if not issue.messages:
        return issue.label
    return f"{issue.label}: {'; '.join(issue.messages)}"


def _extend(lines: list[str], title: str, values: list[str]) -> None:
    if not values:
        return
    lines.append(f"{title}:")
    lines.extend(f"  - {value}" for value in values)


def _parse_pypi_package(package: str) -> tuple[str, str | None]:
    name = package
    version: str | None = None
    if "==" in package:
        name, version = package.split("==", 1)
        version = version.strip() or None
    return _normalize_pypi_name(name.strip()), version


def _parse_maven_coordinates(coordinates: str) -> tuple[str, str | None]:
    parts = coordinates.split(":")
    if len(parts) >= 3:
        return f"{parts[0]}:{parts[1]}", parts[2]
    return coordinates, None


def _normalize_pypi_name(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name).lower()


def _normalize_wheel_package(package: str) -> str:
    return package.replace("-", "_")


def _wheel_package_name(filename: str) -> str:
    return filename.removesuffix(".whl").split("-", 1)[0]


def _wheel_version(filename: str) -> str | None:
    parts = filename.removesuffix(".whl").split("-")
    return parts[1] if len(parts) > 1 else None
