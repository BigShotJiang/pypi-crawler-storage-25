"""Upload Python scripts and wheels to Databricks."""

from __future__ import annotations

import re
import subprocess
from pathlib import Path

from databricks.sdk import WorkspaceClient
from databricks.sdk.errors import DatabricksError, NotFound, ResourceAlreadyExists
from databricks.sdk.service.workspace import ImportFormat

from databricks_job_runner._paths import ensure_volumes_prefix
from databricks_job_runner.errors import RunnerError


def upload_file(ws: WorkspaceClient, local_path: Path, remote_path: str) -> None:
    """Upload a single file to the Databricks workspace.

    Handles FILE-vs-NOTEBOOK type mismatches by deleting the existing
    object and re-uploading, since the workspace API cannot overwrite
    across object types.
    """
    print(f"Uploading: {local_path.name} -> {remote_path}")
    content = local_path.read_bytes()
    try:
        ws.workspace.upload(
            path=remote_path,
            content=content,
            format=ImportFormat.AUTO,
            overwrite=True,
        )
    except DatabricksError as exc:
        if "type mismatch" in str(exc).lower():
            ws.workspace.delete(path=remote_path)
            ws.workspace.upload(
                path=remote_path,
                content=content,
                format=ImportFormat.AUTO,
                overwrite=True,
            )
        else:
            raise
    print("  Done.")


def ensure_remote_dirs(
    ws: WorkspaceClient, workspace_dir: str, scripts_dir: str = "agent_modules"
) -> None:
    """Create the workspace and scripts directories if needed."""
    ws.workspace.mkdirs(workspace_dir)
    ws.workspace.mkdirs(f"{workspace_dir}/{scripts_dir}")


def upload_agent_modules(
    ws: WorkspaceClient,
    agent_modules_dir: Path,
    workspace_dir: str,
    scripts_dir: str = "agent_modules",
    extra_files: list[tuple[Path, str]] | None = None,
) -> None:
    """Upload all .py files from the scripts directory, plus any extra files.

    *extra_files* is a list of ``(local_path, remote_filename)`` pairs. Each
    file is uploaded into the same remote scripts directory alongside the
    Python scripts.  Use this to co-locate non-Python assets (e.g. ``.sql``
    schema files) that job scripts read via ``Path(__file__).parent``.
    """
    ensure_remote_dirs(ws, workspace_dir, scripts_dir)
    remote_dir = f"{workspace_dir}/{scripts_dir}"
    for f in sorted(agent_modules_dir.glob("*.py")):
        upload_file(ws, f, f"{remote_dir}/{f.name}")
    for local_path, remote_name in (extra_files or []):
        upload_file(ws, local_path, f"{remote_dir}/{remote_name}")


def upload_bootstrap_script(
    ws: WorkspaceClient,
    workspace_dir: str,
    scripts_dir: str = "agent_modules",
) -> None:
    """Upload the packaged bootstrap script alongside the project scripts.

    The bootstrap is shipped by databricks-job-runner and submitted as a
    ``SparkPythonTask``.  It is not attached as a cluster or task
    library.
    """
    from databricks_job_runner.submit import (
        BOOTSTRAP_SCRIPT_NAME,
        bootstrap_script_path,
    )

    ensure_remote_dirs(ws, workspace_dir, scripts_dir)
    upload_file(
        ws,
        bootstrap_script_path(),
        f"{workspace_dir}/{scripts_dir}/{BOOTSTRAP_SCRIPT_NAME}",
    )


def _wheel_glob_prefix(package: str) -> str:
    """Return the normalised wheel filename prefix for *package*.

    Applies PEP 625 normalisation (hyphens → underscores) and appends a
    dash so callers can use it with ``startswith`` or ``glob``:
    ``"my-pkg"`` → ``"my_pkg-"``.
    """
    return package.replace("-", "_") + "-"


def find_latest_wheel(dist_dir: Path, wheel_package: str) -> Path | None:
    """Return the most recently built wheel for *wheel_package* in *dist_dir*.

    Uses PEP 625 name normalisation (hyphens become underscores) and sorts
    by mtime descending so the newest build wins.
    """
    prefix = _wheel_glob_prefix(wheel_package)
    wheels = sorted(
        dist_dir.glob(f"{prefix}*.whl"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    return wheels[0] if wheels else None


def _delete_old_wheels_from_volume(
    ws: WorkspaceClient,
    volume_path: str,
    wheel_package: str,
) -> None:
    """Delete all existing wheels for *wheel_package* from *volume_path*."""
    prefix = _wheel_glob_prefix(wheel_package)
    # Materialise before deleting: mutating the directory mid-iteration can
    # cause the SDK paginator to skip or repeat entries.
    try:
        entries = list(ws.files.list_directory_contents(directory_path=volume_path))
    except NotFound:
        return
    to_delete = [e for e in entries if e.name and e.name.startswith(prefix) and e.name.endswith(".whl")]
    for entry in to_delete:
        print(f"  Removing old wheel: {entry.name}")
        ws.files.delete(f"{volume_path}/{entry.name}")


def _bump_patch_version(project_dir: Path) -> str:
    """Increment the patch version in pyproject.toml and return the new version."""
    pyproject = project_dir / "pyproject.toml"
    content = pyproject.read_text()
    match = re.search(r'^(version = ")(\d+)\.(\d+)\.(\d+)(")', content, re.MULTILINE)
    if not match:
        raise RunnerError("Could not find version = \"x.y.z\" in pyproject.toml")
    prefix, major, minor, patch, suffix = match.groups()
    new_version = f"{major}.{minor}.{int(patch) + 1}"
    pyproject.write_text(content[: match.start()] + f'{prefix}{new_version}{suffix}' + content[match.end() :])
    return new_version


def build_and_upload_wheel(
    ws: WorkspaceClient,
    project_dir: Path,
    wheel_volume_dir: str,
    wheel_package: str,
) -> None:
    """Build a Python wheel with ``uv build`` and upload it to a UC Volume.

    .. note::
        This function **mutates** ``project_dir/pyproject.toml`` on every
        call by incrementing the patch version, so each uploaded wheel has
        a fresh filename and clusters always pick it up over older cached
        copies.  The change is left uncommitted for the caller to commit
        or revert.
    """
    if not wheel_volume_dir:
        raise RunnerError(
            "volume path not set in .env — cannot determine wheel upload path."
        )

    dist_dir = project_dir / "dist"
    pyproject = project_dir / "pyproject.toml"

    # Snapshot pyproject.toml before bumping so we can revert if the build or
    # upload fails.  Otherwise a failed run consumes a version number, and the
    # next successful run skips ahead, leaving holes in the published series.
    original_pyproject = pyproject.read_text()
    new_version = _bump_patch_version(project_dir)
    print(f"Building {wheel_package} wheel (v{new_version})...")
    try:
        # ``--out-dir dist`` forces output into project_dir/dist even when the
        # project is a uv workspace member (where the default is the workspace
        # root's dist/).
        subprocess.run(
            ["uv", "build", "--wheel", "--quiet", "--out-dir", "dist"],
            cwd=project_dir,
            check=True,
        )

        whl = find_latest_wheel(dist_dir, wheel_package)
        if whl is None:
            raise RunnerError(
                f"wheel build failed — no {_wheel_glob_prefix(wheel_package)}*.whl found in dist/"
            )

        volume_path = ensure_volumes_prefix(wheel_volume_dir)
        dest = f"{volume_path}/{whl.name}"

        _delete_old_wheels_from_volume(ws, volume_path, wheel_package)
        print(f"Uploading: {whl.name} -> {dest}")
        try:
            ws.files.create_directory(volume_path)
        except ResourceAlreadyExists:
            pass

        with whl.open("rb") as fh:
            ws.files.upload(file_path=dest, contents=fh, overwrite=True)
        print("  Done.")
    except Exception:
        pyproject.write_text(original_pyproject)
        raise


def stable_wheel_name(wheel_package: str) -> str:
    """Fixed Volume destination filename for the stable-publish API.

    Deliberately not a PEP 427 wheel filename: the destination never
    changes across versions so the bootstrap can resolve it without a
    version lookup.  The bootstrap reconstructs a valid wheel filename
    from the wheel's own METADATA before installing.
    """
    return f"{_wheel_glob_prefix(wheel_package)}stable.whl"


def publish_wheel_stable(
    ws: WorkspaceClient,
    project_dir: Path,
    wheel_volume_dir: str,
    wheel_package: str,
) -> str:
    """Build a versioned wheel and publish it to a fixed Volume path.

    Opt-in alternative to :func:`build_and_upload_wheel`.  The local
    build keeps a real PEP 427 versioned filename (the PyPI release and
    ``package_name`` resolution still need it), but the Volume copy is
    written to a single fixed destination name with a plain
    ``overwrite=True`` PUT.  Unlike :func:`build_and_upload_wheel`, this
    does not bump the patch version and does not prune old Volume
    wheels: the destination name never changes, so each run's bootstrap
    always picks up the newest code without a filename change or a
    cluster restart.

    Returns the Volume destination path.
    """
    if not wheel_volume_dir:
        raise RunnerError(
            "volume path not set in .env — cannot determine wheel upload path."
        )

    dist_dir = project_dir / "dist"
    print(f"Building {wheel_package} wheel (stable publish)...")
    subprocess.run(
        ["uv", "build", "--wheel", "--quiet", "--out-dir", "dist"],
        cwd=project_dir,
        check=True,
    )

    whl = find_latest_wheel(dist_dir, wheel_package)
    if whl is None:
        raise RunnerError(
            f"wheel build failed — no {_wheel_glob_prefix(wheel_package)}*.whl "
            "found in dist/"
        )

    volume_path = ensure_volumes_prefix(wheel_volume_dir)
    dest = f"{volume_path}/{stable_wheel_name(wheel_package)}"

    try:
        ws.files.create_directory(volume_path)
    except ResourceAlreadyExists:
        pass

    print(f"Uploading: {whl.name} -> {dest}")
    with whl.open("rb") as fh:
        ws.files.upload(file_path=dest, contents=fh, overwrite=True)
    print("  Done.")
    return dest


_DEFAULT_EXCLUDE_DIRS = frozenset({
    ".venv", "venv", "__pycache__", ".git", ".tox", ".mypy_cache",
    ".pytest_cache", ".ruff_cache", "node_modules", ".eggs",
})

_DEFAULT_EXCLUDE_FILES = frozenset({
    ".env", ".env.local", ".env.production", ".env.development",
    ".gitignore", ".gitattributes", ".DS_Store",
    "credentials.json", "secrets.json", "token.json",
})

_DEFAULT_EXCLUDE_PREFIXES = (".env.",)


def _is_excluded_file(name: str) -> bool:
    """Return True if *name* matches a sensitive-file pattern."""
    if name in _DEFAULT_EXCLUDE_FILES:
        return True
    return name.startswith(_DEFAULT_EXCLUDE_PREFIXES)


def upload_data_to_volume(
    ws: WorkspaceClient,
    local_dir: Path,
    volume_path: str,
    *,
    exclude_dirs: set[str] | None = None,
) -> None:
    """Upload a local directory tree to a UC Volume, preserving structure.

    Walks *local_dir* recursively and uploads every file to
    ``{volume_path}/{relative_path}``.  Creates subdirectories as needed
    via the Files API.

    Directories whose names appear in *exclude_dirs* (or the built-in
    default set) are silently skipped.  Sensitive files (``.env``,
    ``credentials.json``, etc.) are also skipped regardless of location.
    """
    volume_path = ensure_volumes_prefix(volume_path)
    excluded = exclude_dirs if exclude_dirs is not None else _DEFAULT_EXCLUDE_DIRS

    # Collect all files and the set of directories to create
    dirs_created: set[str] = set()

    for local_file in sorted(local_dir.rglob("*")):
        if not local_file.is_file():
            continue

        rel = local_file.relative_to(local_dir)

        # Skip files inside excluded directories
        if excluded & set(rel.parts[:-1]):
            continue

        # Skip sensitive files
        if _is_excluded_file(local_file.name):
            print(f"  [skipped] {rel}")
            continue

        # Force POSIX separators so Windows callers don't send backslashed
        # remote paths to the Files API.
        rel_posix = rel.as_posix()
        rel_parent_posix = rel.parent.as_posix()
        remote_file = f"{volume_path}/{rel_posix}"

        # Ensure parent directory exists
        remote_parent = (
            f"{volume_path}/{rel_parent_posix}" if rel_parent_posix != "." else volume_path
        )
        if remote_parent not in dirs_created:
            try:
                ws.files.create_directory(remote_parent)
            except ResourceAlreadyExists:
                pass
            dirs_created.add(remote_parent)

        print(f"  {rel} -> {remote_file}")
        with local_file.open("rb") as fh:
            ws.files.upload(file_path=remote_file, contents=fh, overwrite=True)
