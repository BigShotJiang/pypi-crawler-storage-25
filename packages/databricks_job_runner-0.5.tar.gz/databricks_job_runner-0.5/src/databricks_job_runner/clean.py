"""Clean up remote workspace directories and job runs."""

from __future__ import annotations

from pathlib import Path

from databricks.sdk import WorkspaceClient
from databricks.sdk.errors import NotFound
from databricks.sdk.service.compute import Library
from databricks.sdk.service.jobs import RunType

from databricks_job_runner.errors import RunnerError
from databricks_job_runner.upload import _wheel_glob_prefix

# Minimum number of non-empty path segments a workspace_dir must have before
# we will recursively delete it.  Guards against typos like
# ``DATABRICKS_WORKSPACE_DIR=/Users/me`` wiping a user-root workspace.  The
# README example (``/Users/you/my_project``) has 3 segments.
_MIN_WORKSPACE_DEPTH = 3


def clean_cluster_wheel_libraries(
    ws: WorkspaceClient,
    cluster_id: str,
    wheel_package: str,
) -> None:
    """Uninstall all wheel libraries for *wheel_package* from the cluster.

    Matches installed libraries whose wheel filename starts with the
    normalised package name (hyphens → underscores), leaving unrelated
    libraries untouched.
    """
    prefix = _wheel_glob_prefix(wheel_package)
    statuses = ws.libraries.cluster_status(cluster_id=cluster_id)
    to_remove: list[Library] = [
        s.library
        for s in statuses
        if s.library
        and s.library.whl
        and Path(s.library.whl).name.startswith(prefix)
    ]
    if not to_remove:
        print("  No old wheel libraries on cluster.")
        return
    for lib in to_remove:
        print(f"  Removing cluster library: {lib.whl}")
    ws.libraries.uninstall(cluster_id=cluster_id, libraries=to_remove)
    noun = "library" if len(to_remove) == 1 else "libraries"
    print(f"  Removed {len(to_remove)} old wheel {noun} from cluster.")


def clean_workspace(ws: WorkspaceClient, workspace_dir: str) -> None:
    """Delete the remote workspace directory recursively.

    Raises :class:`RunnerError` if *workspace_dir* has fewer than
    :data:`_MIN_WORKSPACE_DEPTH` path segments, to prevent a misconfigured
    ``DATABRICKS_WORKSPACE_DIR`` from accidentally wiping a user-root
    workspace.
    """
    parts = [p for p in workspace_dir.split("/") if p]
    if len(parts) < _MIN_WORKSPACE_DEPTH:
        raise RunnerError(
            f"refusing to recursively delete {workspace_dir!r}: workspace path "
            f"must have at least {_MIN_WORKSPACE_DEPTH} non-empty segments "
            f"(got {len(parts)}).  Set DATABRICKS_WORKSPACE_DIR to a "
            "project-specific subdirectory (e.g. /Users/you/my_project)."
        )

    print(f"Deleting remote workspace: {workspace_dir}")
    try:
        ws.workspace.delete(path=workspace_dir, recursive=True)
        print("  Done.")
    except NotFound:
        print("  Directory does not exist or already deleted.")


def clean_runs(ws: WorkspaceClient, run_name_prefix: str) -> None:
    """Find and delete all one-time job runs whose name starts with *prefix*."""
    print(f"Finding job runs matching '{run_name_prefix}*'...")

    # Materialize matching run IDs before issuing any delete calls.  Mutating
    # server state mid-pagination can cause the cursor to skip or repeat
    # entries depending on how the SDK pages results.
    matches: list[tuple[int, str]] = []
    for run in ws.jobs.list_runs(run_type=RunType.SUBMIT_RUN, expand_tasks=False):
        run_name = run.run_name or ""
        run_id = run.run_id
        if run_id is None or not run_name.startswith(run_name_prefix):
            continue
        matches.append((run_id, run_name))

    deleted = 0
    for run_id, run_name in matches:
        print(f"  Deleting run {run_id} ({run_name})")
        try:
            ws.jobs.delete_run(run_id)
            deleted += 1
        except NotFound:
            print(f"    Run {run_id} already deleted.")

    if deleted:
        print(f"  Deleted {deleted} run(s).")
    else:
        print("  No matching runs found.")
