"""Webhook signature verification rules."""
