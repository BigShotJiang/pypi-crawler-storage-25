# -*- coding: utf-8 -*-
"""
:Date: 2022-09-06 15:17:12
:LastEditTime: 2023-02-21 15:47:49
:Description: 
"""

#此文件由rigger自动生成
from seven_framework.mysql import MySQLHelper
from seven_framework.base_model import *
from seven_cloudapp_frame.models.cache_model import CacheModel
from enum import Enum


class MemberEventModel(CacheModel):
    def __init__(self, db_connect_key='db_cloudapp_member', sub_table=None, db_transaction=None, context=None, is_auto=False):
        super(MemberEventModel, self).__init__(MemberEvent, sub_table)
        self.db = MySQLHelper(config.get_value(db_connect_key))
        self.db_connect_key = db_connect_key
        self.db_transaction = db_transaction
        self.db.context = context

    #方法扩展请继承此类
    
class MemberEvent:

    def __init__(self):
        super(MemberEvent, self).__init__()
        self.id = 0  # id
        self.business_id = 0  # 商家标识
        self.one_id = ""  # one_id
        self.store_id = 0  # 店铺标识
        self.platform_id = 0  # 平台标识(1-淘宝 2-抖音 3-京东 4-微信)
        self.event_type = 0  # 事件类型(1-初始化 2-激活 3-绑定 4-注册 5-退会 6-合并 7-获取手机号)
        self.event_reason = ""  # 事件原因
        self.event_desc = ""  # 事件描述
        self.create_date = "1970-01-01 00:00:00.000"  # 创建时间

    @classmethod
    def get_field_list(self):
        return ['id','business_id','one_id','store_id','platform_id','event_type','event_reason','event_desc','create_date']
        
    @classmethod
    def get_primary_key(self):
        return "id"

    def __str__(self):
        return "member_event_tb"
    
