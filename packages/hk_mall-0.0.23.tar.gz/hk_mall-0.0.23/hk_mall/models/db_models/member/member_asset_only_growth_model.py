# -*- coding: utf-8 -*-
"""
:Date: 2022-09-06 15:17:12
:LastEditTime: 2023-02-21 15:47:49
:Description: 
"""

#此文件由rigger自动生成
from seven_framework.mysql import MySQLHelper
from seven_framework.base_model import *
from seven_cloudapp_frame.models.cache_model import CacheModel
from enum import Enum


class MemberAssetOnlyGrowthModel(CacheModel):
    def __init__(self, db_connect_key='db_cloudapp_member', sub_table=None, db_transaction=None, context=None, is_auto=False):
        super(MemberAssetOnlyGrowthModel, self).__init__(MemberAssetOnlyGrowth, sub_table)
        self.db = MySQLHelper(config.get_value(db_connect_key))
        self.db_connect_key = db_connect_key
        self.db_transaction = db_transaction
        self.db.context = context

    #方法扩展请继承此类
    
class MemberAssetOnlyGrowth:

    def __init__(self):
        super(MemberAssetOnlyGrowth, self).__init__()
        self.id = 0  # id
        self.change_no = ""  # 变更流水号(流水表的流水号)
        self.platform_id = 0  # 平台标识(1-淘宝 2-抖音 3-京东 4-微信)
        self.only_type = 0  # 唯一类型(1-请求标识 2-订单号 3-资产流水号)
        self.only_id = ""  # 唯一标识(用于幂等)
        self.create_date = "1900-01-01 00:00:00"  # 创建时间

    @classmethod
    def get_field_list(self):
        return ['id','change_no','platform_id','only_type','only_id','create_date']
        
    @classmethod
    def get_primary_key(self):
        return "id"

    def __str__(self):
        return "member_asset_only_growth_tb"
    
