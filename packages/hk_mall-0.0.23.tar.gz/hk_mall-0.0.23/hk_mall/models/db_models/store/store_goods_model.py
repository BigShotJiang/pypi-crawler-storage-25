# -*- coding: utf-8 -*-
"""
:Date: 2022-09-06 15:17:12
:LastEditTime: 2023-02-21 15:47:49
:Description: 
"""

#此文件由rigger自动生成
from seven_framework.mysql import MySQLHelper
from seven_framework.base_model import *
from seven_cloudapp_frame.models.cache_model import CacheModel
from enum import Enum


class StoreGoodsModel(CacheModel):
    def __init__(self, db_connect_key='db_cloudapp_member', sub_table=None, db_transaction=None, context=None, is_auto=False):
        super(StoreGoodsModel, self).__init__(StoreGoods, sub_table)
        self.db = MySQLHelper(config.get_value(db_connect_key))
        self.db_connect_key = db_connect_key
        self.db_transaction = db_transaction
        self.db.context = context

    #方法扩展请继承此类
    
class StoreGoods:

    def __init__(self):
        super(StoreGoods, self).__init__()
        self.id = 0  # id
        self.guid = ""  # guid
        self.business_id = 0  # 商家标识
        self.store_id = 0  # 店铺标识
        self.business_type = 0  # 业务类型(0-大活动 1-线上活动 2-小活动 3-小部件 4-一番赏 5-线下门店 6-商城 7-抽盒机)
        self.cid = ""  # 分类ID
        self.goods_id = ""  # 商品ID
        self.goods_code = ""  # 商家编码
        self.goods_name = ""  # 商品名称
        self.goods_pic = ""  # 商品主图片
        self.approve_status = ""  # 商品上传后的状态。onsale出售中，instock库中
        self.price = "0.0000"  # 商品价格
        self.goods_num = 0  # 商品件数
        self.create_date = "1970-01-01 00:00:00.000"  # 创建时间
        self.modify_date = "1970-01-01 00:00:00.000"  # 修改时间
        self.is_delete = 0  # 是否删除（1-是 0-否）

    @classmethod
    def get_field_list(self):
        return ['id','guid','business_id','store_id','business_type','cid','goods_id','goods_code','goods_name','goods_pic','approve_status','price','goods_num','create_date','modify_date','is_delete']
        
    @classmethod
    def get_primary_key(self):
        return "id"

    def __str__(self):
        return "store_goods_tb"
    
