from __future__ import annotations

import typing as t

from dbt_run_cache.decision_logger import DecisionEnvelope
from query_cache_common.models import shared_models
from query_cache_common.models.shared_models import SubmitSQLResultType


if t.TYPE_CHECKING:
    from dbt_run_cache._typing import SQLSubmitResponse


@t.overload
def _rejection_reason_to_text(reason: None, rejection_subject: SubmitSQLResultType) -> None: ...


@t.overload
def _rejection_reason_to_text(
    reason: shared_models.RejectionReason, rejection_subject: SubmitSQLResultType
) -> str: ...


def _rejection_reason_to_text(
    reason: t.Optional[shared_models.RejectionReason], rejection_subject: SubmitSQLResultType
) -> t.Optional[str]:
    if not reason:
        return None
    action = "skip" if rejection_subject == SubmitSQLResultType.SKIP_EXECUTION else "clone"
    if reason == shared_models.RejectionReason.FORCED_NOT_ELIGIBLE:
        return f"Cannot {action} because action is not eligible for this request."
    if reason == shared_models.RejectionReason.NO_SUITABLE_MATCH_FOUND:
        return f"Cannot {action} because there was no matching entry in cache."
    if reason == shared_models.RejectionReason.TARGET_TABLE_MISMATCH:
        if rejection_subject != SubmitSQLResultType.SKIP_EXECUTION:
            raise RuntimeError(
                "It should not be possible to have TARGET_TABLE_MISMATCH for anything but SKIP_EXECUTION"
            )
        return f"Cannot skip because the match in cache is for a different target table."
    if reason == shared_models.RejectionReason.TARGET_TABLE_DOES_NOT_EXIST:
        if rejection_subject != SubmitSQLResultType.SKIP_EXECUTION:
            raise RuntimeError(
                "It should not be possible to have TARGET_TABLE_DOES_NOT_EXIST for anything but SKIP_EXECUTION."
            )
        return f"Cannot skip because the table that would have been skipped doesn't exist yet."
    if reason == shared_models.RejectionReason.EXECUTION_TYPE_MISMATCH:
        return f"Cannot {action} because the execution type (full vs incremental) does not match the previous execution stored in cache."
    if reason == shared_models.RejectionReason.EXECUTION_TYPE_NOT_FULL:
        if rejection_subject != SubmitSQLResultType.READY_TO_CLONE:
            raise RuntimeError(
                "It should not be possible to have EXECUTION_TYPE_NOT_FULL for anything but READY_TO_CLONE"
            )
        return f"Cannot clone because only full-refresh models are eligible for cloning."
    if reason == shared_models.RejectionReason.LATEST_QUERY_HASH_NOT_MATCH:
        if rejection_subject != SubmitSQLResultType.SKIP_EXECUTION:
            raise RuntimeError(
                "It should not be possible to have LATEST_QUERY_HASH_NOT_MATCH for anything but SKIP_EXECUTION"
            )
        return f"Cannot skip because the latest known version of the table has different logic then what is being asked to skip and therefore skipping isn't possible."
    if reason == shared_models.RejectionReason.TARGET_TABLE_MATCH:
        if rejection_subject != SubmitSQLResultType.READY_TO_CLONE:
            raise RuntimeError(
                "It should not be possible to have TARGET_TABLE_MATCH for anything but READY_TO_CLONE"
            )
        return f"Cannot clone because the target table matches and dbt run cache doesn't currently support doing a clone onto itself."
    if reason == shared_models.RejectionReason._UNSUPPORTED:
        return f"Unknown rejection reason for this client version. Please upgrade run-cache to properly support this reason."
    raise RuntimeError(f"Unhandled rejection reason: {reason}")


def _explained_decision_to_text(explained_decision: shared_models.ExplainedDecision) -> str:
    if explained_decision.decision == SubmitSQLResultType.SKIP_EXECUTION:
        return "Skipped execution because the table was already loaded with the same logic and input data."
    if explained_decision.decision == SubmitSQLResultType.READY_TO_EXECUTE:
        return "Could not skip or clone therefore the model had to be executed"
    if explained_decision.decision == SubmitSQLResultType.READY_TO_CLONE:
        return "Could not skip execution but eligible to clone from an existing table instead of executing."
    if explained_decision.decision == SubmitSQLResultType._UNSUPPORTED:
        return "Unknown decision type for this client version. Please upgrade run-cache to properly support this feature."
    raise RuntimeError(f"Unhandled decision type: {explained_decision.decision}")


def _get_additional_info(response: SQLSubmitResponse) -> t.Dict[str, t.Any]:
    info = {}
    if hasattr(response, "request_id"):
        info["request_id"] = response.request_id
    if hasattr(response, "transformed_nodes_by_query"):
        info["non_deterministic_function_replacements"] = response.transformed_nodes_by_query
    if hasattr(response, "clone_source"):
        info["clone_source"] = response.clone_source
    if hasattr(response, "query_hash_metadata_info"):
        qhmi = response.query_hash_metadata_info
        if qhmi:
            if not qhmi.semantic_hash_match and not qhmi.data_hash_match:  # ty: ignore[unresolved-attribute]
                query_hash_match_info = "The model's definition matched an entry in cache but the upstream dependencies did not match in terms of their definition and data."
            elif qhmi.semantic_hash_match:  # ty: ignore[unresolved-attribute]
                query_hash_match_info = "The model's definition matched an entry in cache but upstream data dependencies had changed."
            elif qhmi.data_hash_match:  # ty: ignore[unresolved-attribute]
                query_hash_match_info = "The model's definition matched an entry in cache but upstream view dependencies had changed."
            else:
                raise RuntimeError(
                    f"Unexpected state in query hash match metadata info. QHMI: {qhmi}."
                )
        else:
            query_hash_match_info = "The model's definition changed which is why the model had to be executed. If this is unexpected, check `non_deterministic_function_replacements` changes made to the query due to non-deterministic functions."
        info["partial_match_info"] = query_hash_match_info
    return info


def _get_detailed_info(envelope: DecisionEnvelope) -> t.Dict:
    reason = _explained_decision_to_text(envelope.decision.explained_decision)
    skip_rejection_reason = _rejection_reason_to_text(
        envelope.decision.explained_decision.skip_rejection_reason,
        SubmitSQLResultType.SKIP_EXECUTION,
    )
    clone_rejection_reason = _rejection_reason_to_text(
        envelope.decision.explained_decision.clone_rejection_reason,
        SubmitSQLResultType.READY_TO_CLONE,
    )
    freshness_status = (
        "within tolerance" if envelope.decision.explained_decision.is_stale else "fresh"
    )
    additional_info = _get_additional_info(envelope.decision)
    return {
        k: v
        for k, v in {
            "model_name": envelope.model_name,
            "decision_type": envelope.decision_type_short,
            "reason": reason,
            "skip_rejection_reason": skip_rejection_reason,
            "clone_rejection_reason": clone_rejection_reason,
            "freshness_status": freshness_status,
            **additional_info,
        }.items()
        if v is not None and v != {}
    }
