from __future__ import annotations

import hashlib
import sys
import threading
import typing as t
import json
import uuid
from concurrent.futures import Future
from dataclasses import dataclass, replace
from functools import cached_property
from pathlib import Path
from time import perf_counter

import agate
import grpc

from sqlglot import exp, parse_one
from sqlglot.errors import SqlglotError

from dbt.adapters.base.relation import BaseRelation, RelationType

try:
    from dbt.adapters.contracts.connection import AdapterResponse
    from dbt.artifacts.resources.v1.components import DeferRelation
except ImportError:
    from dbt.contracts.connection import AdapterResponse  # type: ignore
    from dbt.contracts.graph.nodes import DeferRelation  # type: ignore[no-redef]

from dbt.clients.jinja import get_rendered
from dbt.config.runtime import RuntimeConfig
from dbt.contracts.results import RunResult, RunStatus
from dbt.context.providers import generate_runtime_model_context
from dbt.contracts.graph.manifest import Manifest, SourceDefinition
from dbt.contracts.graph.nodes import (
    GenericTestNode,
    ModelNode,
    ManifestNode,
    ManifestSQLNode,
    SeedNode,
    SnapshotNode,
    SingularTestNode,
)

try:
    from dbt_common.clients import agate_helper
except ImportError:
    from dbt.clients import agate_helper  # type: ignore

from dbt_run_cache import events
from dbt_run_cache.adapters import create_adapter_extension, BaseAdapterExtension
from dbt_run_cache.adapters.clock import EngineHeuristicsClock
from dbt_run_cache.config import RunCacheConfig
from dbt_run_cache.dev_cloner import DevCloner
from dbt_run_cache.dispatcher import AsyncTelemetryDispatcher
from dbt_run_cache.session import SessionManager
from dbt_run_cache.grpc.client import QueryCacheGrpcClient
from dbt_run_cache.profiles import Profiles
from dbt_run_cache.relation import DeferredRelationResolver
from dbt_run_cache.utils import (
    is_custom_materialization,
    is_full_refresh,
    is_incremental_or_snapshot,
    is_table,
    is_view,
    DBT_VERSION,
)
from dbt_run_cache.decision_logger import create_decision_logger, BaseDecisionLogger
from query_cache_common.constants import NO_OP_STATUS, SUPPORTED_DIALECT_TIME_TRAVEL_DEFAULTS
from query_cache_common.models import shared_models
from query_cache_common.models.services import (
    client_telemetry_service_models,
    sql_service_models,
    clone_service_models,
    execution_service_models,
)

if t.TYPE_CHECKING:
    from dbt.adapters.base import BaseRelation
    from dbt.adapters.sql import SQLAdapter
    from dbt_run_cache._typing import ModelOrSnapshotNode, ModelOrSnapshotOrTestNode

RequestId = str
FailedToClone = bool


# Additional model configs that impact data outcomes and should be included in hash calculations
SEMANTIC_EXTRAS_CONFIG_KEYS = (
    "on_schema_change",
    "incremental_predicates",
    "merge_update_columns",
    "merge_exclude_columns",
    # Test attributes
    "severity",
    "limit",
    "where",
    "fail_calc",
    "warn_if",
    "error_if",
    "store_failures",
    "store_failures_as",
)

SEED_SEMANTIC_EXTRAS_CONFIG_KEYS = (
    "column_types",
    "quote_columns",
    "delimiter",
)

_HASH_READ_CHUNK_SIZE = 64 * 1024


@dataclass
class EnrichmentTimings:
    view_traversal_duration_ms: t.Optional[int] = None
    last_modified_duration_ms: t.Optional[int] = None


@dataclass
class NoRunResult:
    request_id: str
    """The unique identifier for the execution request."""
    failed_to_clone: bool


class RunCache:
    def __init__(
        self,
        query_cache_client: QueryCacheGrpcClient,
        dev_cloner: t.Optional[DevCloner],
        profiles: Profiles,
        deferred_relation_resolver: t.Optional[DeferredRelationResolver],
        adapter_ext: BaseAdapterExtension,
        config: RuntimeConfig,
        manifest: Manifest,
        response_logger: BaseDecisionLogger,
        run_cache_config: RunCacheConfig,
        telemetry_dispatcher: AsyncTelemetryDispatcher,
        session_manager: SessionManager,
    ) -> None:
        self._query_cache_client = query_cache_client
        self._dev_cloner = dev_cloner
        self._profiles = profiles
        self._deferred_relation_resolver = deferred_relation_resolver
        self._dev_cloned_nodes: t.Set[str] = set()
        self._deferred_fqns: t.Set[str] = set()
        self._adapter_ext = adapter_ext
        self._config = config
        self._manifest = manifest
        self._response_logger = response_logger
        self._run_cache_config = run_cache_config
        self._telemetry_dispatcher = telemetry_dispatcher
        self._session_manager = session_manager

        self._engine_heuristics_clock = EngineHeuristicsClock(adapter_ext)
        self._use_heuristic_clock: bool = adapter_ext.supports_current_timestamp_utc

        self._prefetch_tables_lock = threading.Lock()
        self._prefetch_future: t.Optional[Future[None]] = None
        self._prefetch_done: bool = False

        self._total_cache_hits: int = 0
        self._total_time_saved_ms: int = 0
        events.register_callback("run-cache", self.on_event)

        self._run_result = client_telemetry_service_models.ClientResult.SUCCESS

        self._clone_time_travel_limit: t.Optional[int] = (
            run_cache_config.clone_time_travel_limit
            if self.dialect in SUPPORTED_DIALECT_TIME_TRAVEL_DEFAULTS
            else 0
        )

    @classmethod
    def create(
        cls,
        run_cache_config: RunCacheConfig,
        config: RuntimeConfig,
        adapter: SQLAdapter,
        manifest: Manifest,
        query_cache_client: QueryCacheGrpcClient,
        telemetry_dispatcher: AsyncTelemetryDispatcher,
        session_manager: SessionManager,
        response_logger: t.Optional[BaseDecisionLogger] = None,
    ) -> RunCache:
        profiles = Profiles.from_config(config, run_cache_config)
        adapter_ext = create_adapter_extension(
            adapter,
            threads=config.threads,
            cache_ttl_seconds=run_cache_config.metadata_cache_ttl,
            get_view_ddl_override=run_cache_config.snowflake_get_view_ddl_override,
            metadata_warehouse=run_cache_config.snowflake_metadata_warehouse,
        )
        if profiles.has_defer_to_profile:
            deferred_relation_resolver: t.Optional[DeferredRelationResolver] = (
                DeferredRelationResolver(
                    config=config,
                    manifest=manifest,
                    defer_to_profile=profiles.defer_to_profile,
                )
            )
            dev_cloner: t.Optional[DevCloner] = DevCloner(
                config=config,
                adapter_ext=adapter_ext,
                profiles=profiles,
                deferred_relation_resolver=deferred_relation_resolver,
                run_cache_config=run_cache_config,
            )
        else:
            events.fire_info_event(
                "Target '{}' not found in profile '{}'. Deferral and dev cloning are disabled",
                run_cache_config.defer_to,
                config.profile_name,
            )
            deferred_relation_resolver = None
            dev_cloner = None
        if response_logger is None:
            response_logger = create_decision_logger(
                project_root=config.project_root,
                log_path=config.log_path,
                config=run_cache_config,
            )
        if (
            run_cache_config.clone_time_travel_limit is not None
            and run_cache_config.clone_time_travel_limit > 0
            and adapter.type() not in SUPPORTED_DIALECT_TIME_TRAVEL_DEFAULTS
        ):
            events.fire_warn_event(
                "clone_time_travel_limit is configured but %s does not support time travel for cloning. "
                "The setting will be ignored.",
                adapter.type(),
            )
        return cls(
            query_cache_client=query_cache_client,
            dev_cloner=dev_cloner,
            profiles=profiles,
            deferred_relation_resolver=deferred_relation_resolver,
            adapter_ext=adapter_ext,
            config=config,
            manifest=manifest,
            response_logger=response_logger,
            run_cache_config=run_cache_config,
            telemetry_dispatcher=telemetry_dispatcher,
            session_manager=session_manager,
        )

    def on_execute(
        self, node: t.Union[ModelOrSnapshotNode, SeedNode]
    ) -> RunResult | NoRunResult | None:
        """Invoked before executing a model node.

        Invokes the query cache to determine if the model execution can be skipped
        or replaced with a clone operation.

        Args:
            node: The model node being executed.

        Returns:
            One of the following:
            - A RunResult if the execution was skipped or replaced with a clone, otherwise None to proceed with normal execution.
            - A RequestId if the execution should proceed normally but needs to be confirmed once it's done.
            - None if the execution should proceed normally without confirmation.
        """
        if isinstance(node, SeedNode):
            query_cache_response = self._submit_values_request(node)
        elif (
            isinstance(node, (ModelNode, SnapshotNode))
            and node.language == "sql"
            and (
                is_table(node) or (is_view(node) and self._adapter_ext.supports_view_last_modified)
            )
        ):
            query_cache_response = self._submit_sql_request(node)
        else:
            return None
        return self._process_query_cache_response(node, query_cache_response)

    def on_compile(self, node: ManifestSQLNode) -> None:
        """Invoked during the compilation of a model node.

        Automatically clones selected incremental models when appropriate.

        Args:
            node: The model node being compiled.
        """
        try:
            self._prefetch_last_modified()
        except Exception as e:
            events.fire_warn_event("Failed to prefetch last modified timestamps: {}", str(e))

        if isinstance(node, (ModelNode, SnapshotNode)):
            if self._try_clone(node):
                self._dev_cloned_nodes.add(node.unique_id)

    def get_defer_relation(self, node: ManifestNode) -> t.Optional[DeferRelation]:
        """Returns a DeferRelation for the given node if it should be deferred.

        A node is deferred when:
        - Deferral is enabled and the target is not already the defer-to profile
        - The node is not ephemeral
        - The node is not in the selected resource set

        Also tracks the deferred relation name in ``_deferred_nodes`` for lenient
        dependency matching in cache requests.

        Args:
            node: The manifest node to potentially defer.

        Returns:
            A DeferRelation if the node should be deferred, otherwise None.
        """
        if (
            not self._defer_enabled
            or self._profiles.is_defer_to_profile
            or getattr(node, "is_ephemeral", False)
            or node.unique_id in self._selected_resource_ids
        ):
            return None

        assert self._deferred_relation_resolver is not None
        compiled_code = getattr(node, "compiled_code", None)
        dev_relation = self._adapter.Relation.create_from(self._config, node)  # type: ignore[arg-type]
        target_relation = self._defer_relation(dev_relation, node)
        target_relation_name = target_relation.render()

        defer_rel_kwargs: t.Dict[str, t.Any] = dict(
            database=target_relation.database or node.database,
            schema=target_relation.schema or node.schema,
            alias=node.alias,
            relation_name=target_relation_name,
        )
        if DBT_VERSION >= (1, 8, 0):
            defer_rel_kwargs.update(
                dict(
                    resource_type=node.resource_type,
                    name=node.name,
                    description=node.description,
                    compiled_code=str(compiled_code) if compiled_code is not None else None,
                    meta=node.meta,
                    tags=node.tags,
                    config=node.config,
                )
            )
        defer_rel = DeferRelation(**defer_rel_kwargs)
        if self._run_cache_config.defer_logging_enabled:
            events.fire_event(
                self._run_cache_config.defer_log_level,
                "Deferring relation {} to {}",
                dev_relation.render(),
                target_relation_name,
            )
        self._deferred_fqns.add(self._adapter_ext.relation_to_fqn(target_relation))
        return defer_rel

    def cache_compiled_view_sql(self, node: ManifestSQLNode) -> None:
        """Pre-populate the view definition cache from a compiled dbt model node.

        Only caches plain view models (not materialized_view, ephemeral, etc.) that have
        compiled SQL available. This avoids expensive database round-trips for views whose
        SQL is already known from dbt compilation.

        Args:
            node: The compiled manifest node to potentially cache.
        """
        if (
            isinstance(node, ModelNode)
            and (node.get_materialization() or "view") == "view"
            and node.compiled_code
        ):
            table = self._node_to_table(node)
            self._adapter_ext.cache_view_definition(
                table=table,
                definition=node.compiled_code,
                default_schema=node.schema,
            )

    def data_test_adapter_proxy(
        self, node: t.Union[GenericTestNode, SingularTestNode]
    ) -> _DataTestAdapterProxy:
        """Returns a proxy adapter for executing SQL related to data tests that checks the query cache before executing the test SQL.

        Args:
            node: The test node being executed.

         Returns:
            A proxy adapter that can be used to execute data test SQL with query cache integration.
        """
        return _DataTestAdapterProxy(node, self)

    def on_event(self, msg: events.EventMsg) -> None:
        if msg.info.name == "ResourceReport":
            if hasattr(msg.data, "command_success") and isinstance(msg.data.command_success, bool):
                if msg.data.command_success:
                    self._run_result = client_telemetry_service_models.ClientResult.SUCCESS
                else:
                    self._run_result = client_telemetry_service_models.ClientResult.FAILURE
        elif msg.info.name == "CommandCompleted":
            self._session_manager.end(
                result=self._run_result, description="", metrics=self._adapter_ext.report()
            )

    def confirm_execution(
        self,
        node: t.Union[ModelOrSnapshotOrTestNode, SeedNode],
        request_id: RequestId,
        failed_to_clone: bool = False,
        execution_runtime_ms: t.Optional[int] = None,
    ) -> None:
        """Confirms the execution of a model node with the query cache service.

        Args:
            node: The model node that was executed.
            request_id: The request ID returned from the query cache for the given model's execution.
            failed_to_clone: Whether the model failed to be cloned during execution.
        """
        target_table = self._node_to_table(node)
        self._adapter_ext.clear_cache([target_table])

        last_modified_epoch = self._get_heuristic_last_modified_epoch(target_table)
        if last_modified_epoch is None:
            events.fire_debug_event(
                "Skipping confirmation for node {} due to missing last modified epoch",
                node.unique_id,
            )
            return
        target_table_type = self._node_table_type(node)

        confirmation_request = execution_service_models.ConfirmExecutionRequest(
            request_id=request_id,
            last_modified_epoch=last_modified_epoch,
            failed_to_clone=failed_to_clone,
            table_type=target_table_type,
            execution_runtime_ms=execution_runtime_ms,
            labels=self._get_request_labels(node),
        )
        self._query_cache_client.confirm_execution(confirmation_request)
        events.fire_debug_event(
            "Confirmed execution for node {}, request_id {}", node.unique_id, request_id
        )

    def prewarm_connections(self) -> None:
        self._adapter_ext.prewarm_connections()

    def close(self) -> None:
        self._adapter_ext.close()

    def _collect_all_prefetch_tables(self, selected_ids: t.Set[str]) -> t.Set[str]:
        """Collect tables from selected model/snapshot nodes and their dependencies for batch prefetching.

        Args:
            selected_ids: The set of unique IDs for models/snapshots selected for this run.
                When non-empty, only tables relevant to these nodes are collected.
                When empty, all model/snapshot tables are collected (full-project run).
        """
        tables: t.Set[str] = set()
        source_ids: t.Set[str] = set()
        unselected_model_dep_ids: t.Set[str] = set()

        for node in self._manifest.nodes.values():
            if not isinstance(node, (ModelNode, SnapshotNode)):
                continue
            if selected_ids and node.unique_id not in selected_ids:
                continue
            tables.add(self._node_to_table(node).sql(dialect=self.dialect))
            model_node_ids, source_node_ids = self._resolve_deps(node)
            source_ids.update(source_node_ids)
            if selected_ids:
                unselected_model_dep_ids.update(model_node_ids - selected_ids)

        for source_id in source_ids:
            source = self._manifest.sources.get(source_id)
            if source is not None:
                tables.add(self._node_to_table(source).sql(dialect=self.dialect))

        for dep_id in unselected_model_dep_ids:
            dep_node = self._manifest.nodes.get(dep_id)
            if dep_node is None:
                continue
            table = (
                self._node_to_deferred_table(dep_node)
                if self._defer_enabled
                else self._node_to_table(dep_node)
            )
            tables.add(table.sql(dialect=self.dialect))

        return tables

    def _prefetch_last_modified(self) -> None:
        """Collect tables for selected models and prefetch their last modified timestamps.

        On the first call, reads the globally selected resources, collects relevant
        model/snapshot/source FQNs, and triggers an async prefetch. Subsequent calls
        block until the prefetch completes, then become no-ops.
        """
        if self._prefetch_done:
            return

        with self._prefetch_tables_lock:
            if self._prefetch_done:
                return
            if self._prefetch_future is None:
                tables = self._collect_all_prefetch_tables(self._selected_resource_ids)
                if not tables:
                    self._prefetch_done = True
                    return
                events.fire_debug_event(
                    "Prefetching last modified timestamps for {} tables",
                    len(tables),
                )
                self._prefetch_future = self._adapter_ext.prefetch_last_modified_epochs(tables)
            future = self._prefetch_future
        future.result()
        self._prefetch_done = True

    def _commit_if_open(self) -> None:
        self._adapter.connections.get_thread_connection().transaction_open = True
        self._adapter.commit_if_has_connection()

    def _on_data_test_query(
        self,
        node: ModelOrSnapshotOrTestNode,
        test_sql: str,
        original_op: t.Callable[[], t.Tuple[AdapterResponse, agate.Table]],
    ) -> t.Tuple[AdapterResponse, agate.Table]:
        """Called during the execution of a data test to determine whether to execute the test SQL or return results from the query cache.

        Args:
            node: The test node being executed.
            test_sql: The compiled SQL of the test.
            original_op: The original operation to execute on cache miss.

         Returns:
            A tuple of AdapterResponse and agate.Table.
        """
        query_cache_response = self._submit_sql_request(
            node, sql=test_sql, execution_type=shared_models.ModelExecutionType.DBT_DATA_TEST
        )
        if isinstance(query_cache_response, sql_service_models.ReadyToExecuteResponse):
            start = perf_counter()
            adapter_response, agate_table = original_op()
            elapsed_ms = int((perf_counter() - start) * 1000)
            if agate_table is not None and len(agate_table) == 1:
                results = dict(agate_table[0])
                results = {k.lower(): v for k, v in results.items()}
                request_id = query_cache_response.request_id
                confirmation_request = execution_service_models.ConfirmExecutionRequest(
                    request_id=request_id,
                    last_modified_epoch=None,
                    failed_to_clone=False,
                    table_type=None,
                    execution_results=results,
                    execution_runtime_ms=elapsed_ms,
                    labels=self._get_request_labels(node),
                )
                self._query_cache_client.confirm_execution(confirmation_request)
                events.fire_debug_event(
                    "Confirmed execution for test {}, request_id {}", node.unique_id, request_id
                )
            return adapter_response, agate_table
        if isinstance(query_cache_response, sql_service_models.SkipExecutionResponse):
            events.fire_debug_event("Received skip execution response for node {}", node.name)
            self._record_cache_hit(query_cache_response)
            agate_table = agate.Table.from_object(  # ty: ignore[unresolved-attribute]
                [query_cache_response.execution_results],
                column_types={
                    "failures": agate_helper.Integer(),
                    "should_error": agate.Boolean(),
                    "should_warn": agate.Boolean(),
                },
            )
            adapter_response = AdapterResponse(_message=NO_OP_STATUS)
            return adapter_response, agate_table
        events.fire_warn_event_with_cache_bypass(
            "Unexpected cache response type for test '{}': {}",
            node.unique_id,
            type(query_cache_response).__name__,
        )
        return original_op()

    def _process_query_cache_response(
        self,
        node: t.Union[ModelOrSnapshotOrTestNode, SeedNode],
        query_cache_response: t.Union[
            sql_service_models.ReadyToExecuteResponse,
            sql_service_models.SkipExecutionResponse,
            clone_service_models.ReadyToCloneResponse,
            None,
        ],
    ) -> t.Union[RunResult, NoRunResult, None]:
        if query_cache_response is None:
            return None

        freshness_status = (
            " (within tolerance)" if query_cache_response.explained_decision.is_stale else ""
        )
        clone_status = "CLONE" + freshness_status
        noop_status = NO_OP_STATUS + freshness_status
        if isinstance(query_cache_response, sql_service_models.SkipExecutionResponse):
            events.fire_debug_event("Received skip execution response for node {}", node.name)
            self._record_cache_hit(query_cache_response)
            should_run_hooks = self._run_cache_config.resolve_run_hooks_on_no_op(node.config)
        elif isinstance(query_cache_response, clone_service_models.ReadyToCloneResponse):
            events.fire_debug_event(
                "Received ready to clone response for node {}, request_id: {}",
                node.name,
                query_cache_response.request_id,
            )
            should_run_hooks = True
        else:
            events.fire_debug_event(
                "Received execute response for node {}, request_id: {}",
                node.name,
                query_cache_response.request_id,
            )
            return NoRunResult(query_cache_response.request_id, failed_to_clone=False)

        # Note: pre-hooks run before the try block. On clone failure, dbt's fallback
        # materialization will re-run them. This is acceptable since clone failures are exceptional.
        context = None
        if should_run_hooks:
            context = generate_runtime_model_context(node, self._config, self._manifest)
            context_config = context["config"]
            hook_ctx = self._adapter.pre_model_hook(context_config)
            self._run_hooks(getattr(node.config, "pre_hook", []), context)

        try:
            if isinstance(query_cache_response, sql_service_models.SkipExecutionResponse):
                if node.unique_id in self._dev_cloned_nodes:
                    return RunResult.from_node(
                        node,
                        RunStatus.Success,
                        clone_status,
                    )
                return RunResult.from_node(
                    node,
                    RunStatus.Success,
                    noop_status,
                )
            if query_cache_response.clone_required_last_modified_epoch is not None:
                current_last_modified_epoch = self._get_last_modified_epoch(
                    exp.to_table(query_cache_response.clone_source, dialect=self.dialect)
                )
                if current_last_modified_epoch is None or (
                    current_last_modified_epoch
                    > query_cache_response.clone_required_last_modified_epoch
                ):
                    events.fire_debug_event(
                        "Unable to clone node '{}' due to table's latest state not matching what is expected. "
                        "Expected last modified epoch: {}, actual last modified epoch: {}.",
                        node.name,
                        query_cache_response.clone_required_last_modified_epoch,
                        current_last_modified_epoch,
                    )
                    should_run_hooks = False
                    return NoRunResult(query_cache_response.request_id, failed_to_clone=True)
            with events.downgrade_adapter_error_events():
                for sql in query_cache_response.clone_sqls:
                    self._adapter.execute(sql)
            self._commit_if_open()
            # when we clone a table, we put it in the relation cache so that the remainder of the
            # invocation knows it exists without hitting the db
            self._adapter_ext.cache_node_relation(node)
            self.confirm_execution(node, query_cache_response.request_id)
            self._record_cache_hit(query_cache_response)
            return RunResult.from_node(
                node,
                RunStatus.Success,
                clone_status,
            )
        except Exception as e:
            self._adapter_ext.rollback()
            should_run_hooks = False
            if isinstance(query_cache_response, clone_service_models.ReadyToCloneResponse):
                events.fire_warn_event(
                    "Clone failed for node '{}', falling back to full execution: {}",
                    node.name,
                    str(e),
                )
                return NoRunResult(query_cache_response.request_id, failed_to_clone=True)
            raise
        finally:
            if should_run_hooks:
                self._run_hooks(getattr(node.config, "post_hook", []), context)
                self._commit_if_open()
                self._adapter.post_model_hook(context_config, hook_ctx)

    def _run_hooks(self, hooks: t.List[t.Any], context: t.Dict[str, t.Any]) -> None:
        for hook in hooks:
            rendered_sql = get_rendered(hook.sql, context)
            if rendered_sql.strip():
                self._adapter.execute(rendered_sql, auto_begin=hook.transaction)

    def _try_clone(self, node: ModelOrSnapshotNode) -> bool:
        if self._dev_cloner is None:
            return False
        clone_response = self._submit_clone_request(node)
        if clone_response is None:
            return False
        self._dev_cloner.clone(
            self._adapter,
            node,
            clone_response.clone_sqls,
            clone_response.clone_source,
            clone_response.clone_target,
        )
        self._commit_if_open()
        if isinstance(clone_response, clone_service_models.ReadyToCloneResponse):
            self.confirm_execution(node, clone_response.request_id)
        return True

    def _submit_sql_request(
        self,
        node: ModelOrSnapshotOrTestNode,
        sql: t.Optional[str] = None,
        execution_type: t.Optional[shared_models.ModelExecutionType] = None,
    ) -> t.Union[
        sql_service_models.ReadyToExecuteResponse,
        sql_service_models.SkipExecutionResponse,
        clone_service_models.ReadyToCloneResponse,
        None,
    ]:
        request_id = uuid.uuid4().hex
        request_start_time = perf_counter()
        try:
            request, timings = self._build_submit_enriched_sql_request(node, sql, execution_type)
            request_end_time = perf_counter()
            duration = request_end_time - request_start_time

            self._emit_enriched_sql_prepared_telemetry(
                request_id,
                duration,
                target_table_fqn=node.relation_name,
                labels=self._get_request_labels(node),
                num_dependencies=len(request.tables) - 1,  # exclude the target table in count
                num_view_dependencies=len(request.query_dependencies),
                view_traversal_duration_ms=timings.view_traversal_duration_ms,
                last_modified_duration_ms=timings.last_modified_duration_ms,
            )

            response = self._query_cache_client.submit_sql(request, request_id)
            self._response_logger.log_decision(response, model_name=node.name)

            return response

        except Exception as e:
            request_end_time = perf_counter()
            self._log_submit_sql_error(e, node)
            duration = request_end_time - request_start_time
            self._emit_enriched_sql_prepared_telemetry(
                request_id,
                duration=duration,
                target_table_fqn=node.relation_name,
                labels=self._get_request_labels(node),
                num_dependencies=None,
                num_view_dependencies=None,
                error_type=type(e).__name__,
            )
            if isinstance(e, grpc.RpcError):
                raise

        return None

    def _submit_values_request(
        self,
        node: SeedNode,
    ) -> t.Union[
        sql_service_models.ReadyToExecuteResponse,
        sql_service_models.SkipExecutionResponse,
        clone_service_models.ReadyToCloneResponse,
        None,
    ]:
        request_id = uuid.uuid4().hex
        try:
            request = self._build_submit_values_request(node)
            response = self._query_cache_client.submit_values(request, request_id)
            self._response_logger.log_decision(response, model_name=node.name)
            return response
        except Exception as e:
            events.fire_warn_event_with_cache_bypass(
                "Error preparing values request for seed '{}': {}",
                node.name,
                str(e),
            )
            if isinstance(e, grpc.RpcError):
                raise
        return None

    def _build_submit_values_request(
        self,
        node: SeedNode,
    ) -> sql_service_models.SubmitValuesRequest:
        node_config = node.config
        semantic_extras = {
            key: json.dumps(value) if (value := node_config.get(key)) is not None else ""
            for key in SEED_SEMANTIC_EXTRAS_CONFIG_KEYS
            if key in node_config
        }
        last_modified_epoch = self._get_last_modified_epoch(self._node_to_table(node))
        return sql_service_models.SubmitValuesRequest(
            target_table=node.relation_name or "",
            dialect=self._adapter.type(),
            default_catalog=self._adapter_ext.default_catalog,
            values_hash=self._compute_seed_values_hash(node),
            semantic_extras=semantic_extras,
            last_modified_epoch=last_modified_epoch,
            labels=self._get_request_labels(node),
            clone_time_travel_limit=self._clone_time_travel_limit,
        )

    def _emit_enriched_sql_prepared_telemetry(
        self,
        request_id: str,
        duration: float,
        target_table_fqn: t.Optional[str],
        labels: t.Dict[str, str],
        num_dependencies: t.Optional[int] = None,
        num_view_dependencies: t.Optional[int] = None,
        error_type: t.Optional[str] = None,
        view_traversal_duration_ms: t.Optional[int] = None,
        last_modified_duration_ms: t.Optional[int] = None,
    ) -> None:
        try:
            enriched_sql_request = client_telemetry_service_models.ClientPrepareEnrichedSQLRequest(
                request_id=request_id,
                duration=duration,
                target_table_fqn=target_table_fqn,
                num_dependencies=num_dependencies,
                num_view_dependencies=num_view_dependencies,
                error_type=error_type,
                view_traversal_duration_ms=view_traversal_duration_ms,
                last_modified_duration_ms=last_modified_duration_ms,
                labels=labels,
            )
            self._telemetry_dispatcher.add_event(enriched_sql_request)
        except Exception as e:
            events.fire_debug_event(
                "Failed to emit enriched SQL telemetry: {} ({})", type(e).__name__, str(e)
            )

    def _log_submit_sql_error(self, e: Exception, node: ModelOrSnapshotOrTestNode) -> None:
        node_type = (
            "test"
            if isinstance(node, (GenericTestNode, SingularTestNode))
            else "snapshot"
            if isinstance(node, SnapshotNode)
            else "model"
        )
        if isinstance(e, SqlglotError):
            events.fire_warn_event_with_cache_bypass(
                "Failed to parse compiled SQL for {} '{}': {}",
                node_type,
                node.name,
                str(e),
            )
        elif isinstance(e, (ValueError, TypeError, AttributeError, KeyError)):
            events.fire_warn_event_with_cache_bypass(
                "Data validation error preparing enriched SQL for {} '{}': {}",
                node_type,
                node.name,
                str(e),
            )
        elif isinstance(e, RuntimeError):
            events.fire_warn_event_with_cache_bypass(
                "Runtime error preparing enriched SQL for {} '{}': {}",
                node_type,
                node.name,
                str(e),
            )
        else:
            events.fire_warn_event_with_cache_bypass(
                "Error preparing enriched SQL for {} '{}': {}",
                node_type,
                node.name,
                str(e),
            )

    def _submit_clone_request(
        self, node: ModelOrSnapshotNode
    ) -> t.Optional[
        t.Union[
            clone_service_models.ReadyToCloneResponse, clone_service_models.UntrackableCloneResponse
        ]
    ]:
        assert self._dev_cloner is not None
        result = self._dev_cloner.get_clone_source(node)
        if not result:
            return None
        clone_source, clone_source_table_type = result
        clone_request = self._build_clone_request(node, clone_source, clone_source_table_type)
        return self._query_cache_client.register_clone(clone_request)

    def _build_submit_enriched_sql_request(
        self,
        node: ModelOrSnapshotOrTestNode,
        sql: t.Optional[str],
        execution_type: t.Optional[shared_models.ModelExecutionType],
    ) -> t.Tuple[sql_service_models.SubmitEnrichedSQLRequest, EnrichmentTimings]:
        sql = sql or node.compiled_code or ""

        if not sql:
            raise RuntimeError(f"Model node '{node.unique_id}' must be compiled")

        execution_type = execution_type or shared_models.ModelExecutionType(
            self._node_execution_type(node)
        )
        target_table = (
            self._node_to_table(node).sql(dialect=self.dialect)
            if execution_type != shared_models.ModelExecutionType.DBT_DATA_TEST
            else None
        )
        dialect = self._adapter.type()
        default_catalog = self._adapter_ext.default_catalog
        node_config = node.config

        if execution_type == shared_models.ModelExecutionType.VIEW:
            # Views don't need dependency traversal — only the view's own last_modified_epoch
            # and query hash matter, since the query is re-evaluated every time the view is queried
            assert target_table is not None
            last_modified_start = perf_counter()
            last_modified_epoch = self._adapter_ext.get_last_modified_epoch([target_table])
            last_modified_duration_ms = int((perf_counter() - last_modified_start) * 1000)
            table_infos = [
                shared_models.TableModifiedInfo(name=name, last_modified_epoch=epoch)  # ty: ignore[invalid-argument-type]
                for name, epoch in last_modified_epoch.items()
            ]
            return sql_service_models.SubmitEnrichedSQLRequest(
                tables=table_infos,
                query_dependencies=[],
                target_table=target_table,
                dialect=dialect,
                default_catalog=default_catalog,
                execution_type=execution_type,
                sql=sql,
                semantic_extras={},
                freshness_tolerance_seconds=0,
                lenient_dependencies=set(),
                tolerate_nondeterminism=True,
                labels=self._get_request_labels(node),
                clone_time_travel_limit=self._clone_time_travel_limit,
            ), EnrichmentTimings(last_modified_duration_ms=last_modified_duration_ms)

        view_traversal_start = perf_counter()
        traversal_result = self._adapter_ext.traverse_view_definitions(sql)
        view_traversal_duration_ms = int((perf_counter() - view_traversal_start) * 1000)

        # Include the target table's last modified epoch to enable detection of unobserved modifications
        all_tables = traversal_result.seen_tables.copy()
        if target_table is not None:
            all_tables.add(target_table)
        last_modified_start = perf_counter()
        last_modified_epoch = self._adapter_ext.get_last_modified_epoch(all_tables)
        last_modified_duration_ms = int((perf_counter() - last_modified_start) * 1000)

        table_infos = [
            shared_models.TableModifiedInfo(name=name, last_modified_epoch=epoch)  # ty: ignore[invalid-argument-type]
            for name, epoch in last_modified_epoch.items()
        ]
        query_dependencies = [
            shared_models.QueryDependency(
                name=name,
                query=v.definition,
                default_catalog=v.default_catalog,
                default_schema=v.default_schema,
            )
            for name, v in traversal_result.view_definitions.items()
        ]

        all_seen_fqns = traversal_result.seen_tables | set(traversal_result.view_definitions)

        semantic_extras = {
            key: json.dumps(value) if (value := node_config.get(key)) is not None else ""
            for key in SEMANTIC_EXTRAS_CONFIG_KEYS
            if key in node_config
        }
        return sql_service_models.SubmitEnrichedSQLRequest(
            tables=table_infos,
            query_dependencies=query_dependencies,
            target_table=target_table,
            dialect=dialect,
            default_catalog=default_catalog,
            execution_type=execution_type,
            sql=sql,
            semantic_extras=semantic_extras,
            freshness_tolerance_seconds=self._run_cache_config.resolve_freshness_tolerance(
                node_config
            ),
            lenient_dependencies=self._deferred_fqns & all_seen_fqns,
            tolerate_nondeterminism=self._run_cache_config.resolve_tolerate_nondeterminism(
                node_config
            ),
            labels=self._get_request_labels(node),
            clone_time_travel_limit=self._clone_time_travel_limit,
        ), EnrichmentTimings(
            view_traversal_duration_ms=view_traversal_duration_ms,
            last_modified_duration_ms=last_modified_duration_ms,
        )

    def _build_clone_request(
        self,
        node: ModelOrSnapshotOrTestNode,
        clone_source: str,
        clone_source_table_type: t.Optional[str],
    ) -> clone_service_models.CloneRequest:
        clone_source_last_modified_epoch = self._get_last_modified_epoch(
            exp.to_table(clone_source, dialect=self.dialect)
        )
        return clone_service_models.CloneRequest(
            target_table=node.relation_name or "",
            clone_source_table=clone_source,
            dialect=self.dialect,
            default_catalog=self._adapter_ext.default_catalog,
            execution_type=shared_models.ModelExecutionType(self._node_execution_type(node)),
            clone_source_last_modified_epoch=clone_source_last_modified_epoch,
            labels=self._get_request_labels(node),
            clone_source_table_type=clone_source_table_type,
        )

    @staticmethod
    def _get_request_labels(node: t.Union[ModelOrSnapshotOrTestNode, SeedNode]) -> t.Dict[str, str]:
        unique_id = node.unique_id

        return {
            "dbt_node_name": node.name,
            "dbt_node_fqn": ".".join(node.fqn),
            "dbt_node_unique_id": unique_id,
        }

    def _node_execution_type(self, node: ModelOrSnapshotOrTestNode) -> str:
        if isinstance(node, (GenericTestNode, SingularTestNode)):
            return "DBT_DATA_TEST"
        if is_view(node):
            return "VIEW"
        if is_custom_materialization(node):
            return "DBT_CUSTOM"
        execution_type = "full"
        if is_incremental_or_snapshot(node) and not is_full_refresh(self._config, node):
            if node.resource_type == "snapshot":
                execution_type = "snapshot"
            else:
                execution_type_str = getattr(node.config, "incremental_strategy", None) or "append"
                execution_type = execution_type_str.replace("+", "_").lower()
                if execution_type == "merge" and not getattr(node.config, "unique_key", None):
                    execution_type = "append"
        return execution_type.upper()

    def _node_table_type(
        self, node: t.Union[ModelOrSnapshotOrTestNode, SeedNode]
    ) -> t.Optional[str]:
        # note: get_relation() only returns a relation for relations that exist
        # it's intended that the table type is determined *after* dbt has created the tables, not before
        if (
            relation := self._adapter.get_relation(
                database=node.database, schema=node.schema, identifier=node.identifier
            )
        ) and isinstance(relation, BaseRelation):
            return self._adapter_ext.get_relation_table_type(node=node, relation=relation)

        return None

    def _get_heuristic_last_modified_epoch(self, table: exp.Table) -> t.Optional[int]:
        if not self._use_heuristic_clock:
            return self._get_last_modified_epoch(table)

        try:
            heuristic_now = self._engine_heuristics_clock.now_utc()
            epoch_millis = int(heuristic_now.timestamp() * 1000)
            self._adapter_ext.cache_last_modified_epoch(table, epoch_millis)
            return epoch_millis
        except Exception:
            events.fire_debug_event(
                "Failed to get heuristic last modified for table '{}', falling back to warehouse query",
                table.sql(dialect=self.dialect),
            )
            self._use_heuristic_clock = False
            return self._get_last_modified_epoch(table)

    def _get_last_modified_epoch(self, table: exp.Table) -> t.Optional[int]:
        last_modified_epochs = self._adapter_ext.get_last_modified_epoch([table])
        if len(last_modified_epochs) != 1:
            raise RuntimeError("Expected exactly one table info")
        last_modified_epoch = next(iter(last_modified_epochs.values()))
        if last_modified_epoch is None:
            events.fire_debug_event(
                "Failed to get last modified for table: '{}'", table.sql(dialect=self.dialect)
            )
        return last_modified_epoch

    def _node_to_table(self, node: ManifestNode | SourceDefinition) -> exp.Table:
        database = node.database
        schema = node.schema
        table_name = t.cast(str, node.alias if hasattr(node, "alias") else node.identifier)
        table = self._adapter_ext.table_(table_name, schema, database, quoted=False)
        return self._adapter_ext._normalize_and_quote_table(table)

    def _node_to_deferred_table(self, node: ManifestNode) -> exp.Table:
        assert self._deferred_relation_resolver is not None
        database = self._deferred_relation_resolver.get_deferred_database(node) or node.database
        schema = self._deferred_relation_resolver.get_deferred_schema(node) or node.schema
        table_name = node.alias if hasattr(node, "alias") else node.identifier
        table = self._adapter_ext.table_(table_name, schema, database, quoted=False)
        return self._adapter_ext._normalize_and_quote_table(table)

    def _record_cache_hit(
        self,
        response: t.Union[
            sql_service_models.SkipExecutionResponse, clone_service_models.ReadyToCloneResponse
        ],
    ) -> None:
        self._total_cache_hits += 1
        self._total_time_saved_ms += response.execution_runtime_ms or 0

    def _compute_seed_values_hash(self, node: SeedNode) -> str:
        seed_path = Path(self._config.project_root) / node.original_file_path
        md5 = hashlib.md5(usedforsecurity=False)
        with open(seed_path, "rb") as f:
            for chunk in iter(lambda: f.read(_HASH_READ_CHUNK_SIZE), b""):
                md5.update(chunk)
        return md5.hexdigest()

    def _resolve_deps(self, node: ManifestSQLNode) -> t.Tuple[t.Set[str], t.Set[str]]:
        """Return model dependency IDs and source IDs, resolving transitively through ephemeral models."""
        model_ids: t.Set[str] = set()
        source_ids: t.Set[str] = set()
        stack: t.List[str] = []
        for n in getattr(node.depends_on, "nodes", []):
            if n.startswith("source."):
                source_ids.add(n)
            else:
                stack.append(n)
        visited: t.Set[str] = set()
        while stack:
            dep_id = stack.pop()
            if dep_id in visited:
                continue
            visited.add(dep_id)
            dep_node = self._manifest.nodes.get(dep_id)
            if isinstance(dep_node, ModelNode) and dep_node.get_materialization() == "ephemeral":
                for n in getattr(dep_node.depends_on, "nodes", []):
                    if n.startswith("source."):
                        source_ids.add(n)
                    else:
                        stack.append(n)
            else:
                model_ids.add(dep_id)
        return model_ids, source_ids

    def _defer_relation(self, relation: BaseRelation, target_node: ManifestNode) -> BaseRelation:
        assert self._deferred_relation_resolver is not None
        deferred_relation = replace(relation, path=replace(relation.path))
        deferred_relation.path.schema = self._deferred_relation_resolver.get_deferred_schema(
            target_node
        )
        deferred_relation.path.database = self._deferred_relation_resolver.get_deferred_database(
            target_node
        )
        return deferred_relation

    @cached_property
    def _selected_resource_ids(self) -> t.Set[str]:
        from dbt.selected_resources import SELECTED_RESOURCES

        return set(SELECTED_RESOURCES)

    @property
    def _adapter(self) -> SQLAdapter:
        return self._adapter_ext.adapter

    @property
    def _defer_enabled(self) -> bool:
        if self._deferred_relation_resolver is None:
            return False
        # defer should always be considered enabled (for RunCache plugin purposes) unless --no-defer was explicitly provided by the user
        # note that we have to check sys.argv because:
        # - the original cli args are not available on RuntimeConfig
        # - RuntimeConfig.args.defer defaults to False which means we cannot tell the difference between the default and a explicitly supplied --no-defer argument
        return "--no-defer" not in sys.argv

    @property
    def dialect(self) -> str:
        return self._adapter.type()

    @property
    def run_cache_config(self) -> RunCacheConfig:
        return self._run_cache_config

    @property
    def total_cache_hits(self) -> int:
        return self._total_cache_hits

    @property
    def total_time_saved_ms(self) -> int:
        return self._total_time_saved_ms


class _DataTestAdapterProxy:
    def __init__(
        self, node: t.Union[GenericTestNode, SingularTestNode], run_cache: RunCache
    ) -> None:
        self._node = node
        self._run_cache = run_cache
        self._adapter = run_cache._adapter
        self._adapter_ext = self._run_cache._adapter_ext
        self._relation_to_drop: t.Optional[BaseRelation] = None

    def __getattr__(self, name: str) -> t.Any:
        return getattr(self._adapter, name)

    def execute(
        self,
        sql: str,
        *args: t.Any,
        **kwargs: t.Any,
    ) -> t.Tuple[AdapterResponse, agate.Table]:
        try:
            parsed_test_sql = parse_one(sql, dialect=self._adapter_ext.dialect)
            named_selects = (
                parsed_test_sql.named_selects if isinstance(parsed_test_sql, exp.Select) else []
            )
            if sorted(named_selects) == ["failures", "should_error", "should_warn"]:
                return self._run_cache._on_data_test_query(
                    self._node,
                    sql,
                    lambda: self._adapter.execute(sql, *args, **kwargs),
                )
            if isinstance(parsed_test_sql, exp.Create) and parsed_test_sql.kind == "TABLE":
                # Handle the CTAS statement which creates a table with data test failures
                cached_run_result = None
                try:
                    query_cache_response = self._run_cache._submit_sql_request(
                        self._node, sql=sql, execution_type=shared_models.ModelExecutionType.FULL
                    )
                    cached_run_result = self._run_cache._process_query_cache_response(
                        self._node, query_cache_response
                    )
                    if isinstance(cached_run_result, RunResult):
                        # We got a cache hit for the CTAS statement
                        self._adapter.commit_if_has_connection()
                        return AdapterResponse(_message=NO_OP_STATUS), agate.Table.from_object([])  # ty: ignore[unresolved-attribute]
                except Exception as e:
                    events.fire_warn_event_with_cache_bypass(
                        "Error processing query cache response for test '{}': {}",
                        self._node.unique_id,
                        str(e),
                    )

                execution_start_ts = perf_counter()
                if self._relation_to_drop:
                    # Execute the postponed drop
                    self._adapter.drop_relation(self._relation_to_drop)
                result = self._adapter.execute(sql, *args, **kwargs)
                elapsed_ms = int((perf_counter() - execution_start_ts) * 1000)
                self._adapter_ext.cache_node_relation(self._node)

                try:
                    self._adapter.commit_if_has_connection()
                    self._adapter.connections.begin()
                except Exception as e:
                    events.fire_debug_event(
                        "Error starting a new transaction for test '{}': {}",
                        self._node.unique_id,
                        str(e),
                    )

                if isinstance(cached_run_result, NoRunResult):
                    try:
                        self._run_cache.confirm_execution(
                            self._node,
                            cached_run_result.request_id,
                            failed_to_clone=cached_run_result.failed_to_clone,
                            execution_runtime_ms=elapsed_ms,
                        )
                    except Exception as e:
                        events.fire_warn_event_with_cache_bypass(
                            "Error confirming execution for test '{}': {}",
                            self._node.unique_id,
                            str(e),
                        )
                return result

        except SqlglotError as e:
            events.fire_warn_event_with_cache_bypass(
                "Failed to parse SQL for test '{}': {}",
                self._node.unique_id,
                str(e),
            )
        except Exception as e:
            events.fire_warn_event_with_cache_bypass(
                "Unexpected error processing cache response for test '{}': {}",
                self._node.unique_id,
                str(e),
            )
        return self._adapter.execute(sql, *args, **kwargs)

    def drop_relation(self, relation: BaseRelation) -> None:
        if relation.type == RelationType.Table and (
            self._node.schema.lower(),
            self._node.identifier.lower(),
        ) == (
            (relation.schema or "").lower(),
            (relation.identifier or "").lower(),
        ):
            # Postpone deletion of the test relation until after we check the cache response for the
            # test's CTAS statement which follows this call
            self._relation_to_drop = relation
        else:
            self._adapter.drop_relation(relation)
