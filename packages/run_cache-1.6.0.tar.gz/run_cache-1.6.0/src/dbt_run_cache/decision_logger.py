from __future__ import annotations

import datetime
import json
import glob
import os
import threading
import typing as t
from abc import ABC, abstractmethod
from dataclasses import dataclass
from functools import cached_property
from pathlib import Path

from dbt_run_cache.config import RunCacheConfig

if t.TYPE_CHECKING:
    from dbt_run_cache._typing import SQLSubmitResponse


@dataclass
class DecisionEnvelope:
    model_name: str
    decision_type: str
    decision: SQLSubmitResponse

    @classmethod
    def response_class(cls, decision_type: str) -> t.Type[SQLSubmitResponse]:
        from dbt_run_cache._typing import sql_service_models, clone_service_models

        mapping: dict[str, t.Type[SQLSubmitResponse]] = {
            "ReadyToExecuteResponse": sql_service_models.ReadyToExecuteResponse,
            "SkipExecutionResponse": sql_service_models.SkipExecutionResponse,
            "ReadyToCloneResponse": clone_service_models.ReadyToCloneResponse,
        }
        if decision_type not in mapping:
            raise ValueError(f"Unknown response type: {decision_type}")
        return mapping[decision_type]

    @classmethod
    def from_json(cls, json_str: str) -> DecisionEnvelope:
        data = json.loads(json_str)
        return cls(
            model_name=data["model_name"],
            decision_type=data["decision_type"],
            decision=cls.response_class(data["decision_type"]).from_dict(data["decision"]),
        )

    def to_json(self) -> str:
        return json.dumps(
            {
                "model_name": self.model_name,
                "decision_type": self.decision_type,
                "decision": self.decision.to_dict(),
            }
        )

    @property
    def decision_type_short(self) -> str:
        mapping = {
            "ReadyToExecuteResponse": "Execute",
            "SkipExecutionResponse": "No-Op",
            "ReadyToCloneResponse": "Clone",
        }
        if self.decision_type not in mapping:
            raise ValueError(f"Unknown response type: {self.decision_type}")
        return mapping[self.decision_type]


def create_decision_logger(
    project_root: Path | str,
    log_path: str,
    config: RunCacheConfig,
) -> BaseDecisionLogger:
    if config.enable_response_logging:
        logger = DecisionLogger(project_root=project_root, log_path=log_path, config=config)
        logger.remove_extra_logs()
        return logger
    return NoOpLogger()


class BaseDecisionLogger(ABC):
    """Abstract base class for decision loggers."""

    @abstractmethod
    def log_decision(self, response: SQLSubmitResponse, model_name: str) -> None:
        """Log a decision response."""
        ...


class DecisionLogger(BaseDecisionLogger):
    """Decision logger that writes responses to log files."""

    def __init__(self, project_root: Path | str, log_path: str, config: RunCacheConfig) -> None:
        self._project_root = Path(project_root)
        self._log_path = log_path
        self._log_filepath: Path | None = None
        self._config = config
        self._lock = threading.Lock()
        self.log_limit = config.log_file_limit

    @cached_property
    def log_prefix(self) -> Path:
        """Prefix path for log files."""
        return self.log_dir / self._config.log_prefix

    def logs_filepaths(self, desc: bool = True) -> t.List[Path]:
        """Returns list of existing log files."""
        return [Path(x) for x in sorted(glob.glob(f"{self.log_prefix}*.jsonl"), reverse=desc)]

    @property
    def log_dir(self) -> Path:
        """Directory where log files are stored. Can be overridden via config."""
        if self._config.log_dir_override:
            return Path(self._config.log_dir_override).expanduser()
        if self._project_root is None:
            raise RuntimeError("DecisionLogger not configured with project_root")
        if self._log_path is None:
            raise RuntimeError("DecisionLogger not configured with log_path")
        log_dir = self._project_root / self._log_path / "run_cache"
        return Path(log_dir).expanduser()

    @property
    def log_filepath(self) -> Path:
        """Current log file path for writing. Creates directory if needed."""
        if not self._log_filepath:
            self._log_filepath = Path(
                f"{self.log_prefix}{datetime.datetime.now().strftime('%Y_%m_%d_%H_%M_%S')}.jsonl"
            )
            self._log_filepath.parent.mkdir(parents=True, exist_ok=True)
        return self._log_filepath

    def remove_extra_logs(self) -> None:
        """Remove old log files beyond the configured limit."""
        if self.log_limit < 0:
            return

        for path in self.logs_filepaths()[self.log_limit :]:
            os.remove(path)

    def log_decision(self, response: SQLSubmitResponse, model_name: str) -> None:
        """Log a decision response to the log file."""
        envelope = DecisionEnvelope(
            model_name=model_name,
            decision_type=type(response).__name__,
            decision=response,
        )
        with self._lock:
            with open(self.log_filepath, "a") as f:
                f.write(f"{envelope.to_json()}\n")


class NoOpLogger(BaseDecisionLogger):
    """No-op logger that can read existing logs but does not write new ones."""

    def log_decision(self, response: SQLSubmitResponse, model_name: str) -> None:
        """No-op: NoOpLogger does not write logs."""
        pass
