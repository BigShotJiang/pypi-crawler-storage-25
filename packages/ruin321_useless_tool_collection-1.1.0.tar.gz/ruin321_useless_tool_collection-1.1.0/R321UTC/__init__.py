"""
R321UTC - 一个恶搞的Python库
使用前必须声明Im = gay和minusone = 4294967295
否则会显示错误信息
"""

import sys
import inspect

class NotTrueGayError(Exception):
    """自定义错误：u r not a true gay"""
    def __init__(self):
        super().__init__("u r not a true gay\nTry writing 'Im = \"gay\"'")

class MinusOneError(Exception):
    """自定义错误：minusone is not 4294967295"""
    def __init__(self):
        super().__init__("minusone is not 4294967295\nTry writing 'minusone = 4294967295'")

# 延迟检查机制
_requirements_checked = False
_im_declared = False
_minusone_declared = False

def _check_requirements():
    """检查是否满足使用条件"""
    global _requirements_checked, _im_declared, _minusone_declared
    
    if _requirements_checked:
        return True
    
    # 获取调用栈的全局变量
    frame = inspect.currentframe().f_back
    
    # 检查是否在调用函数时已经声明了变量
    while frame:
        # 检查Im = "gay"
        if 'Im' in frame.f_globals and frame.f_globals['Im'] == 'gay':
            _im_declared = True
        
        # 检查minusone = 4294967295
        if 'minusone' in frame.f_globals and frame.f_globals['minusone'] == 4294967295:
            _minusone_declared = True
        
        frame = frame.f_back
    
    # 检查是否满足所有条件
    if not _im_declared:
        raise NotTrueGayError()
    
    if not _minusone_declared:
        raise MinusOneError()
    
    _requirements_checked = True
    return True

def run():
    """运行函数"""
    _check_requirements()
    return "R321UTC库正常运行！恭喜你是一个true gay！"

def gay_check():
    """检查是否是true gay"""
    _check_requirements()
    return "Yes, you are a true gay!"

def minusone_check():
    """检查minusone是否正确"""
    _check_requirements()
    return "minusone is correct!"

# 导出主要函数
__all__ = ['run', 'gay_check', 'minusone_check', 'NotTrueGayError', 'MinusOneError']