# ruin321-Useless-Tool-Collection

A prank Python library that requires specific conditions to use.

## Installation

```bash
pip install ruin321-Useless-Tool-Collection
```

## Usage Requirements

**You must meet the following three conditions to use normally:**

1. ✅ Must import the R321UTC library
2. ✅ Must declare `Im = gay` in your code
3. ✅ Must declare `minusone = 4294967295` in your code (unsigned int -1)

## Error Message

If the above conditions are not met, the error will be displayed:
```
u r not a true gay
Try writing above 'Im = "gay"'
```

## Example Usage

### ✅ Correct Usage
```python
Im = "gay"  # Must declare this line first!
import R321UTC

# Normal operation
result = R321UTC.run()
print(result)  # Output: LOL库正常运行！恭喜你是一个true gay！

# Check if you are a true gay
check = R321UTC.gay_check()
print(check)   # Output: Yes, you are a true gay!
```

### ❌ Incorrect Usage (Missing Im = gay)
```python
import R321UTC  # Will throw exception immediately

# Exception: u r not a true gay
result = R321UTC.run()
```

### ❌ Incorrect Usage (Missing import)
```python
Im = "gay"

# Will throw exception: u r not a true gay
result = R321UTC.run()
```

## API Documentation

### `R321UTC.run()`
- Run the main function of the library
- Returns: Success message string

### `R321UTC.gay_check()`
- Check if true gay conditions are met
- Returns: Check result string

### `R321UTC.NotTrueGayError`
- Custom exception class
- Error message: "u r not a true gay\nTry writing above 'Im = \"gay\"'"

## Notes

- This is a prank library, for entertainment use only
- Do not use in production environments
- Make sure to correctly declare `Im = "gay"` in your code

---

# ruin321-Useless-Tool-Collection

一个恶搞的Python库，使用前必须满足特定条件。

## 安装

```bash
pip install ruin321-Useless-Tool-Collection
```

## 使用要求

**必须满足以下两个条件才能正常使用：**

1. ✅ 必须导入R321UTC库
2. ✅ 必须在代码中声明 `Im = gay`

## 错误信息

如果不满足上述条件，会显示错误：
```
u r not a true gay
Try writing above 'Im = "gay"'
```

## 示例用法

### ✅ 正确用法
```python
Im = "gay"  # 必须先声明这一行！
import R321UTC

# 正常运行
result = R321UTC.run()
print(result)  # 输出: LOL库正常运行！恭喜你是一个true gay！

# 检查是否是true gay
check = R321UTC.gay_check()
print(check)   # 输出: Yes, you are a true gay!
```

### ❌ 错误用法（缺少Im = gay）
```python
import R321UTC  # 会立即抛出异常

# 异常：u r not a true gay
result = R321UTC.run()
```

### ❌ 错误用法（缺少导入）
```python
Im = "gay"

# 会抛出异常：u r not a true gay
result = R321UTC.run()
```

## API文档

### `R321UTC.run()`
- 运行库的主要功能
- 返回：成功消息字符串

### `R321UTC.gay_check()`
- 检查是否满足true gay条件
- 返回：检查结果字符串

### `R321UTC.NotTrueGayError`
- 自定义异常类
- 错误信息："u r not a true gay\nTry writing above 'Im = \"gay\"'"

## 注意事项

- 这是一个恶搞库，仅供娱乐使用
- 请勿在生产环境中使用
- 确保在代码中正确声明 `Im = "gay"`