"""Output formatting and display."""
