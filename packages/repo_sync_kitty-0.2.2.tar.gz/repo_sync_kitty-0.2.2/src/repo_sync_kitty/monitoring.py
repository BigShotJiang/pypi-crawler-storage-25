"""Sentry monitoring setup."""

import sentry_sdk

from repo_sync_kitty.__about__ import VERSION

_TRACES_SAMPLE_RATES: dict[str, float] = {
    "production": 0.1,
    "staging": 0.5,
}
_DEFAULT_TRACES_SAMPLE_RATE = 1.0  # local / development


def setup_sentry(environment: str = "local") -> None:
    traces_sample_rate = _TRACES_SAMPLE_RATES.get(
        environment, _DEFAULT_TRACES_SAMPLE_RATE
    )
    sentry_sdk.init(
        dsn="https://1f04a1828fa9baae9f93e64d4385f76d@o4508594232426496.ingest.us.sentry.io/4511123439484928",
        traces_sample_rate=traces_sample_rate,
        environment=environment,
        release=f"repo-sync-kitty@{VERSION}",
        attach_stacktrace=True,
        send_default_pii=False,
    )
