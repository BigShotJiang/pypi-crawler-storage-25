"""Shared utility functions."""
