"""Git-related utility functions shared across commands."""

import re
from pathlib import Path


def is_git_repo(path: Path) -> bool:
    """Check if directory is a git repo (.git can be dir, file, or symlink).

    Args:
        path: Directory path to check

    Returns:
        True if path contains a .git entry, False if not or on permission error
    """
    try:
        return (path / ".git").exists()
    except PermissionError:
        return False


def git_url_to_web_url(git_url: str) -> str | None:
    """Convert a git remote URL to a web browser URL.

    Handles SSH shorthand, SSH URLs, HTTPS, and HTTP for GitHub,
    GitLab, Bitbucket, and similar forges.

    Args:
        git_url: Git remote URL (ssh or https)

    Returns:
        Web URL or None if pattern not recognized
    """
    url = git_url.strip()

    # Remove .git suffix
    if url.endswith(".git"):
        url = url[:-4]

    # SSH shorthand: git@github.com:owner/repo
    ssh_shorthand = re.match(r"^git@([^:]+):(.+)$", url)
    if ssh_shorthand:
        host, path = ssh_shorthand.groups()
        return f"https://{host}/{path}"

    # SSH URL: ssh://git@github.com/owner/repo
    ssh_url = re.match(r"^ssh://[^@]+@([^/]+)/(.+)$", url)
    if ssh_url:
        host, path = ssh_url.groups()
        return f"https://{host}/{path}"

    # HTTPS URL: already web-compatible
    if url.startswith("https://"):
        return url

    # HTTP URL
    if url.startswith("http://"):
        return url.replace("http://", "https://", 1)

    return None


def normalize_git_url(url: str) -> str:
    """Normalize a git URL for comparison.

    Handles variations like:
    - https://github.com/owner/repo vs https://github.com/owner/repo.git
    - git@github.com:owner/repo vs ssh://git@github.com/owner/repo
    - Trailing slashes

    Args:
        url: Git URL to normalize

    Returns:
        Normalized URL for comparison
    """
    url = url.strip().rstrip("/")

    # Remove .git suffix
    if url.endswith(".git"):
        url = url[:-4]

    # Convert SSH shorthand (git@host:path) to ssh:// format
    ssh_shorthand = re.match(r"^(\w+)@([^:]+):(.+)$", url)
    if ssh_shorthand:
        user, host, path = ssh_shorthand.groups()
        url = f"ssh://{user}@{host}/{path}"

    # Normalize to lowercase for comparison
    return url.lower()
