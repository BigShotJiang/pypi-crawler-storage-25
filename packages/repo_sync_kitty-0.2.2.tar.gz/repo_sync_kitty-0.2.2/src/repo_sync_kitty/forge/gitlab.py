"""GitLab API client."""


class GitLabClient:
    """Client for GitLab API."""

    def __init__(self, token: str | None = None) -> None:
        self.token = token
