"""Bitbucket API client."""


class BitbucketClient:
    """Client for Bitbucket API."""

    def __init__(self, token: str | None = None) -> None:
        self.token = token
