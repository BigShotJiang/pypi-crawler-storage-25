# CLAUDE.md - repo-sync-kitty

**System type**: `cli`
**Stack**: Python 3.13, Typer, Pydantic Settings, Rich, httpx, GitPython

Git repository synchronization tool for teams. Manages multi-repo manifests, syncs branches across forges (GitHub, GitLab, Bitbucket), and detects orphaned or detached repos.

## Configuration

| Variable | Purpose | Example |
|----------|---------|---------|
| `GITHUB_TOKEN` / `GH_TOKEN` | GitHub API access for enroll/scan | `ghp_...` |
| `GITLAB_TOKEN` | GitLab API access for scan | `glpat-...` |

## Domain Concepts

- **Manifest**: TOML config file tracking repos, remotes, and sync settings
- **Forge**: Git hosting platform (GitHub, GitLab, Bitbucket)
- **Enroll**: Register a GitHub org/user's repos into the manifest
- **Orphan**: Local repo not tracked in the manifest
- **Detached**: Repo in manifest whose local clone is on wrong branch or missing remote

## Repository Integration

See repository root for workflow, skills, and patterns.
