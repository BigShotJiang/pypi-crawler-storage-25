# Changelog

## 0.2.1 (2026-03-28)

- Core commands: sync, status, check, init, add, scan
- Extended commands: move, open, find-orphans, fix-detached, import-repo, enroll, scrub
- GitHub and GitLab forge support
- Parallel execution with configurable concurrency
- Safe pull with multiple precondition checks
- Shell completion support
- Pydantic-based configuration with manifest.toml
