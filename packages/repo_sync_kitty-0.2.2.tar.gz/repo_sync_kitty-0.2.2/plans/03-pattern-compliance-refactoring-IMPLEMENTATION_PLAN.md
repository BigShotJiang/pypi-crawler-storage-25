# repo-sync-kitty Pattern Compliance Refactoring - Implementation Plan

## Implementation Progress

- [x] Phase 1: Shared Infrastructure ✅
- [x] Phase 2: Core Module Cleanup ✅
- [x] Phase 3: Commands Batch 1 Cleanup ✅
- [x] Phase 4: Commands Batch 2 + Git/Util Cleanup ✅
- [x] Phase 5: Quality Gate and Reconciliation ✅

## Summary of Deliverables Per Phase

### Phase 1: Shared Infrastructure ✅
☑ `exitcodes.py` module with ExitCode(IntEnum) enum (1.1)
☑ Error console pattern documented for adoption in Phases 2-4 (1.1)
☑ All 414 tests pass with new module present (1.2)

### Phase 2: Core Module Cleanup ✅
☑ `cli.py` - error_console, ExitCode enum, redundant docstrings/comments removed (2.1)
☑ `monitoring.py` - environment-dependent traces_sample_rate (2.2)
☑ `config/loader.py` - `import re` moved to module level (2.3)
☑ `config/models.py` - redundant docstrings/comments removed (2.3)
☑ `output/display.py` - redundant docstrings/comments removed (2.4)
☑ `forge/bitbucket.py` - redundant docstrings/comments removed (2.5)
☑ `forge/github.py` - redundant docstrings/comments removed (2.5)
☑ `forge/gitlab.py` - redundant docstrings/comments removed (2.5)
☑ ruff check + mypy clean on all 8 files (2.6)

### Phase 3: Commands Batch 1 Cleanup ✅
☑ `commands/__init__.py` - redundant docstrings/comments removed (3.1)
☑ `commands/add.py` - error_console, ExitCode, docstrings/comments cleaned (3.2)
☑ `commands/check.py` - error_console, ExitCode, `from None` removed, docstrings/comments cleaned (3.3)
☑ `commands/enroll.py` - error_console, ExitCode, docstrings/comments cleaned (3.4)
☑ `commands/find_orphans.py` - error_console, ExitCode, docstrings/comments cleaned (3.4)
☑ `commands/fix_detached.py` - error_console, ExitCode, concurrent.futures to module level, docstrings/comments cleaned (3.5)
☑ `commands/import_manifest.py` - error_console, ExitCode, docstrings/comments cleaned (3.6)
☑ ruff check + mypy clean on all 7 files (3.7)

### Phase 4: Commands Batch 2 + Git/Util Cleanup ✅
☑ `commands/init.py` - error_console, ExitCode, specific exception types, docstrings/comments cleaned (4.1)
☑ `commands/move.py` - error_console, ExitCode, `import re` to module level, docstrings/comments cleaned (4.2)
☑ `commands/open.py` - error_console, ExitCode, docstrings/comments cleaned (4.3)
☑ `commands/scan.py` - error_console, ExitCode, imports to module level, os.getenv replaced, docstrings/comments cleaned (4.4)
☑ `commands/scrub.py` - error_console, ExitCode, docstrings/comments cleaned (4.5)
☑ `commands/status.py` - error_console, ExitCode, docstrings/comments cleaned (4.5)
☑ `commands/sync.py` - error_console, ExitCode, docstrings/comments cleaned (4.6)
☑ `git/operations.py` - specific GitPython exceptions, docstrings/comments cleaned (4.7)
☑ `git/retry.py` - structlog logging on retry attempts, docstrings/comments cleaned (4.8)
☑ `git/safety.py` - docstrings/comments cleaned (4.8)
☑ ruff check + mypy clean on all 10 files (4.9)

### Phase 5: Quality Gate and Reconciliation ✅
☑ Full test suite: all 414 tests pass (5.1)
☑ ruff check clean on entire project (5.1)
☑ mypy clean on src/ (5.1)
☑ CLI help output unchanged (behavioral equivalence verified) (5.2)
☑ Combined diff reviewed for cross-batch consistency (5.2)

## Overview

This plan addresses systemic pattern compliance issues found across 25+ source files in repo-sync-kitty. A validation audit identified approximately 210+ violations of project code patterns (CODE-STYLE-001, CODE-PY-CLI-001, CODE-ERR-001, CODE-PY-STYLE-001, CODE-PY-LOG-001, CODE-MON-001).

**Problem**: Source files contain redundant docstrings, WHAT-not-WHY comments, error output going to stdout instead of stderr, bare integer exit codes, bare exception handlers, function-level imports, hardcoded environment values, and missing retry logging. These violate established project patterns and reduce code quality.

**Scope**: Pure refactoring -- NO behavioral changes, NO new features. The 414 existing tests must pass identically before and after every phase.

**Key Design Decision**: Phases 2, 3, and 4 are designed to run in parallel by separate agents. Each agent owns a non-overlapping set of files. Phase 1 creates shared infrastructure they all depend on. Phase 5 reconciles and validates the combined result.

**What is NOT included**: New tests, new features, changes to util/git.py, changes to __about__.py/__init__.py/__main__.py.

## Architecture

```
src/repo_sync_kitty/
├── exitcodes.py              # NEW: ExitCode(IntEnum) enum
├── cli.py                    # Phase 2 (Agent A)
├── monitoring.py             # Phase 2 (Agent A)
├── config/
│   ├── models.py             # Phase 2 (Agent A)
│   └── loader.py             # Phase 2 (Agent A)
├── output/
│   └── display.py            # Phase 2 (Agent A)
├── forge/
│   ├── bitbucket.py          # Phase 2 (Agent A)
│   ├── github.py             # Phase 2 (Agent A)
│   └── gitlab.py             # Phase 2 (Agent A)
├── commands/
│   ├── __init__.py           # Phase 3 (Agent B)
│   ├── add.py                # Phase 3 (Agent B)
│   ├── check.py              # Phase 3 (Agent B)
│   ├── enroll.py             # Phase 3 (Agent B)
│   ├── find_orphans.py       # Phase 3 (Agent B)
│   ├── fix_detached.py       # Phase 3 (Agent B)
│   ├── import_manifest.py    # Phase 3 (Agent B)
│   ├── init.py               # Phase 4 (Agent C)
│   ├── move.py               # Phase 4 (Agent C)
│   ├── open.py               # Phase 4 (Agent C)
│   ├── scan.py               # Phase 4 (Agent C)
│   ├── scrub.py              # Phase 4 (Agent C)
│   ├── status.py             # Phase 4 (Agent C)
│   └── sync.py               # Phase 4 (Agent C)
├── git/
│   ├── operations.py         # Phase 4 (Agent C)
│   ├── retry.py              # Phase 4 (Agent C)
│   └── safety.py             # Phase 4 (Agent C)
└── util/
    └── git.py                # CLEAN - DO NOT TOUCH
```

**Parallel Execution Model:**

```
Phase 1 (Sequential)
    |
    +---> Phase 2 (Agent A: core modules)
    |
    +---> Phase 3 (Agent B: commands batch 1)
    |
    +---> Phase 4 (Agent C: commands batch 2 + git)
    |
    v
Phase 5 (Sequential, after 2+3+4)
```

**Refactoring Patterns Applied:**

| Pattern | Fix | Files Affected |
|---------|-----|----------------|
| CODE-STYLE-001 | Remove redundant docstrings, WHAT-not-WHY comments | ~25 files |
| CODE-PY-CLI-001 | error_console for stderr, ExitCode enum | ~15 command/CLI files |
| CODE-ERR-001 | Replace bare `except Exception`, remove `from None` | 3 files |
| CODE-PY-STYLE-001 | Move imports to module level | 4 files |
| CODE-PY-LOG-001 | Add structlog logging on retry | 1 file |
| CODE-MON-001 | Environment-dependent sample rate, os.getenv removal | 2 files |

## Detailed Implementation Phases

### Phase 1: Shared Infrastructure ✅

**Goal**: Create the ExitCode enum module and establish the error_console pattern so parallel phases can adopt them independently.

#### Step 1.1: Create ExitCode Module and Document Patterns ✅

**Implementation**:
- Create `src/repo_sync_kitty/exitcodes.py` with an `ExitCode(IntEnum)` enum containing: `SUCCESS = 0`, `GENERAL_ERROR = 1`, `USAGE_ERROR = 2`
- The enum values map to existing bare integers already used in `typer.Exit()` calls throughout the codebase
- Document the error_console pattern: `error_console = Console(stderr=True)` to be adopted per-file in Phases 2-4
- No existing code is changed in this step -- only new module created

**Deliverables**:
☑ `src/repo_sync_kitty/exitcodes.py` created with ExitCode enum
☑ Error console pattern documented for per-file adoption

#### Step 1.2: Verify No Breakage ✅

**Implementation**:
- Run the full test suite to confirm the new module does not interfere with existing code
- Run ruff and mypy on the new module

**Deliverables**:
☑ All 414 tests pass
☑ ruff + mypy clean on exitcodes.py

**Validation Checkpoint**:
```bash
cd /home/vlad/Proj/mine/claude-tools/tools/repo-sink-kitty
uv run pytest --tb=short -q
# Expected: 414 passed

uv run ruff check src/repo_sync_kitty/exitcodes.py
# Expected: All checks passed

uv run mypy src/repo_sync_kitty/exitcodes.py
# Expected: Success
```
**User Validated**: ☑

### Phase 2: Core Module Cleanup ✅

**Goal**: Apply all pattern fixes to the 8 core module files (cli.py, monitoring.py, config/*, output/*, forge/*). This phase is owned exclusively by Agent A.

**File Ownership (EXCLUSIVE)**: cli.py, monitoring.py, config/models.py, config/loader.py, output/display.py, forge/bitbucket.py, forge/github.py, forge/gitlab.py

#### Step 2.1: cli.py Refactoring ✅

**Implementation**:
- Add `error_console = Console(stderr=True)` for error output
- Replace bare `typer.Exit(1)` / `typer.Exit(2)` with `typer.Exit(ExitCode.GENERAL_ERROR)` / `typer.Exit(ExitCode.USAGE_ERROR)`
- Remove docstrings that merely restate the function or class name
- Remove inline comments that describe WHAT the code does rather than WHY

**Deliverables**:
☑ cli.py updated with error_console, ExitCode, cleaned docstrings/comments

#### Step 2.2: monitoring.py Refactoring ✅

**Implementation**:
- Replace fixed `traces_sample_rate` with environment-dependent value: 1.0 for local/development, 0.5 for staging, 0.1 for production
- Use the existing environment detection mechanism (config or ENVIRONMENT env var via settings)
- Remove redundant docstrings and WHAT-not-WHY comments

**Deliverables**:
☑ monitoring.py updated with environment-dependent sample rate, cleaned docstrings/comments

#### Step 2.3: config/ Module Refactoring ✅

**Implementation**:
- `config/loader.py`: Move `import re` from inside function(s) to module level
- `config/models.py`: Remove redundant docstrings and WHAT-not-WHY comments
- `config/loader.py`: Remove redundant docstrings and WHAT-not-WHY comments

**Deliverables**:
☑ config/loader.py updated with module-level import, cleaned docstrings/comments
☑ config/models.py cleaned docstrings/comments

#### Step 2.4: output/display.py Refactoring ✅

**Implementation**:
- Remove redundant docstrings and WHAT-not-WHY comments

**Deliverables**:
☑ output/display.py cleaned docstrings/comments

#### Step 2.5: forge/ Module Refactoring ✅

**Implementation**:
- `forge/bitbucket.py`: Remove redundant docstrings and WHAT-not-WHY comments
- `forge/github.py`: Remove redundant docstrings and WHAT-not-WHY comments
- `forge/gitlab.py`: Remove redundant docstrings and WHAT-not-WHY comments

**Deliverables**:
☑ forge/bitbucket.py cleaned
☑ forge/github.py cleaned
☑ forge/gitlab.py cleaned

#### Step 2.6: Phase 2 Verification ✅

**Implementation**:
- Run ruff check on all 8 files
- Run mypy on all 8 files
- Run full test suite

**Deliverables**:
☑ ruff check + mypy clean on all Phase 2 files
☑ All 414 tests pass

**Validation Checkpoint**:
```bash
cd /home/vlad/Proj/mine/claude-tools/tools/repo-sink-kitty
uv run ruff check src/repo_sync_kitty/cli.py src/repo_sync_kitty/monitoring.py src/repo_sync_kitty/config/models.py src/repo_sync_kitty/config/loader.py src/repo_sync_kitty/output/display.py src/repo_sync_kitty/forge/bitbucket.py src/repo_sync_kitty/forge/github.py src/repo_sync_kitty/forge/gitlab.py
# Expected: All checks passed

uv run mypy src/repo_sync_kitty/cli.py src/repo_sync_kitty/monitoring.py src/repo_sync_kitty/config/ src/repo_sync_kitty/output/display.py src/repo_sync_kitty/forge/
# Expected: Success

uv run pytest --tb=short -q
# Expected: 414 passed
```
**User Validated**: ☑

### Phase 3: Commands Batch 1 Cleanup ✅

**Goal**: Apply all pattern fixes to the 7 command files in batch 1. This phase is owned exclusively by Agent B and runs in parallel with Phases 2 and 4.

**File Ownership (EXCLUSIVE)**: commands/__init__.py, commands/add.py, commands/check.py, commands/enroll.py, commands/find_orphans.py, commands/fix_detached.py, commands/import_manifest.py

#### Step 3.1: commands/__init__.py Cleanup ✅

**Implementation**:
- Remove redundant docstrings and WHAT-not-WHY comments

**Deliverables**:
☑ commands/__init__.py cleaned

#### Step 3.2: commands/add.py Refactoring ✅

**Implementation**:
- Add `error_console = Console(stderr=True)` for error output
- Replace bare exit codes with ExitCode enum values
- Remove redundant docstrings and WHAT-not-WHY comments

**Deliverables**:
☑ commands/add.py updated with error_console, ExitCode, cleaned docstrings/comments

#### Step 3.3: commands/check.py Refactoring ✅

**Implementation**:
- Add `error_console = Console(stderr=True)` for error output
- Replace bare exit codes with ExitCode enum values
- Remove `from None` exception suppression (per CODE-ERR-001)
- Remove redundant docstrings and WHAT-not-WHY comments

**Deliverables**:
☑ commands/check.py updated with error_console, ExitCode, `from None` removed, cleaned docstrings/comments

#### Step 3.4: commands/enroll.py and commands/find_orphans.py Refactoring ✅

**Implementation**:
- Both files: Add error_console, ExitCode, remove redundant docstrings/comments

**Deliverables**:
☑ commands/enroll.py updated
☑ commands/find_orphans.py updated

#### Step 3.5: commands/fix_detached.py Refactoring ✅

**Implementation**:
- Add `error_console = Console(stderr=True)` for error output
- Replace bare exit codes with ExitCode enum values
- Move `import concurrent.futures` from inside function to module level
- Remove redundant docstrings and WHAT-not-WHY comments

**Deliverables**:
☑ commands/fix_detached.py updated with error_console, ExitCode, module-level import, cleaned docstrings/comments

#### Step 3.6: commands/import_manifest.py Refactoring ✅

**Implementation**:
- Add error_console, ExitCode, remove redundant docstrings/comments

**Deliverables**:
☑ commands/import_manifest.py updated

#### Step 3.7: Phase 3 Verification ✅

**Implementation**:
- Run ruff check on all 7 files
- Run mypy on all 7 files
- Run full test suite

**Deliverables**:
☑ ruff check + mypy clean on all Phase 3 files
☑ All 414 tests pass

**Validation Checkpoint**:
```bash
cd /home/vlad/Proj/mine/claude-tools/tools/repo-sink-kitty
uv run ruff check src/repo_sync_kitty/commands/__init__.py src/repo_sync_kitty/commands/add.py src/repo_sync_kitty/commands/check.py src/repo_sync_kitty/commands/enroll.py src/repo_sync_kitty/commands/find_orphans.py src/repo_sync_kitty/commands/fix_detached.py src/repo_sync_kitty/commands/import_manifest.py
# Expected: All checks passed

uv run mypy src/repo_sync_kitty/commands/__init__.py src/repo_sync_kitty/commands/add.py src/repo_sync_kitty/commands/check.py src/repo_sync_kitty/commands/enroll.py src/repo_sync_kitty/commands/find_orphans.py src/repo_sync_kitty/commands/fix_detached.py src/repo_sync_kitty/commands/import_manifest.py
# Expected: Success

uv run pytest --tb=short -q
# Expected: 414 passed
```
**User Validated**: ☑

### Phase 4: Commands Batch 2 + Git/Util Cleanup ✅

**Goal**: Apply all pattern fixes to the 10 remaining files (7 command files + 3 git files). This phase is owned exclusively by Agent C and runs in parallel with Phases 2 and 3.

**File Ownership (EXCLUSIVE)**: commands/init.py, commands/move.py, commands/open.py, commands/scan.py, commands/scrub.py, commands/status.py, commands/sync.py, git/operations.py, git/retry.py, git/safety.py

#### Step 4.1: commands/init.py Refactoring ✅

**Implementation**:
- Add error_console, ExitCode
- Replace bare `except Exception` with specific exception types (OSError, PermissionError, or other appropriate types based on the operations performed)
- Remove redundant docstrings and WHAT-not-WHY comments

**Deliverables**:
☑ commands/init.py updated with error_console, ExitCode, specific exceptions, cleaned docstrings/comments

#### Step 4.2: commands/move.py Refactoring ✅

**Implementation**:
- Add error_console, ExitCode
- Move `import re` from inside function to module level
- Remove redundant docstrings and WHAT-not-WHY comments

**Deliverables**:
☑ commands/move.py updated with error_console, ExitCode, module-level import, cleaned docstrings/comments

#### Step 4.3: commands/open.py Refactoring ✅

**Implementation**:
- Add error_console, ExitCode
- Remove redundant docstrings and WHAT-not-WHY comments

**Deliverables**:
☑ commands/open.py updated

#### Step 4.4: commands/scan.py Refactoring ✅

**Implementation**:
- Add error_console, ExitCode
- Move imports from inside functions to module level
- Replace `os.getenv()` calls with config parameter or settings-based access pattern
- Remove redundant docstrings and WHAT-not-WHY comments

**Deliverables**:
☑ commands/scan.py updated with error_console, ExitCode, module-level imports, config-based env access, cleaned docstrings/comments

#### Step 4.5: commands/scrub.py and commands/status.py Refactoring ✅

**Implementation**:
- Both files: Add error_console, ExitCode, remove redundant docstrings/comments

**Deliverables**:
☑ commands/scrub.py updated
☑ commands/status.py updated

#### Step 4.6: commands/sync.py Refactoring ✅

**Implementation**:
- Add error_console, ExitCode
- Remove redundant docstrings and WHAT-not-WHY comments

**Deliverables**:
☑ commands/sync.py updated

#### Step 4.7: git/operations.py Refactoring ✅

**Implementation**:
- Replace bare `except Exception` with specific GitPython exception types (GitCommandError, InvalidGitRepositoryError, or other appropriate git.exc types)
- Remove redundant docstrings and WHAT-not-WHY comments

**Deliverables**:
☑ git/operations.py updated with specific exceptions, cleaned docstrings/comments

#### Step 4.8: git/retry.py and git/safety.py Refactoring ✅

**Implementation**:
- `git/retry.py`: Add structlog logging on retry attempts (log retry count, delay, exception type before each retry)
- `git/retry.py`: Remove redundant docstrings and WHAT-not-WHY comments
- `git/safety.py`: Remove redundant docstrings and WHAT-not-WHY comments

**Deliverables**:
☑ git/retry.py updated with retry logging, cleaned docstrings/comments
☑ git/safety.py cleaned docstrings/comments

#### Step 4.9: Phase 4 Verification ✅

**Implementation**:
- Run ruff check on all 10 files
- Run mypy on all 10 files
- Run full test suite

**Deliverables**:
☑ ruff check + mypy clean on all Phase 4 files
☑ All 414 tests pass

**Validation Checkpoint**:
```bash
cd /home/vlad/Proj/mine/claude-tools/tools/repo-sink-kitty
uv run ruff check src/repo_sync_kitty/commands/init.py src/repo_sync_kitty/commands/move.py src/repo_sync_kitty/commands/open.py src/repo_sync_kitty/commands/scan.py src/repo_sync_kitty/commands/scrub.py src/repo_sync_kitty/commands/status.py src/repo_sync_kitty/commands/sync.py src/repo_sync_kitty/git/operations.py src/repo_sync_kitty/git/retry.py src/repo_sync_kitty/git/safety.py
# Expected: All checks passed

uv run mypy src/repo_sync_kitty/commands/init.py src/repo_sync_kitty/commands/move.py src/repo_sync_kitty/commands/open.py src/repo_sync_kitty/commands/scan.py src/repo_sync_kitty/commands/scrub.py src/repo_sync_kitty/commands/status.py src/repo_sync_kitty/commands/sync.py src/repo_sync_kitty/git/operations.py src/repo_sync_kitty/git/retry.py src/repo_sync_kitty/git/safety.py
# Expected: Success

uv run pytest --tb=short -q
# Expected: 414 passed
```
**User Validated**: ☑

### Phase 5: Quality Gate and Reconciliation ✅

**Goal**: Verify the combined result of all three parallel phases produces a clean, consistent, behaviorally-equivalent codebase.

#### Step 5.1: Full Quality Suite ✅

**Implementation**:
- Run full test suite (all 414 tests)
- Run ruff check on entire project
- Run mypy on entire src/ directory
- Verify no regressions introduced by parallel work

**Deliverables**:
☑ All 414 tests pass
☑ ruff check clean on entire project
☑ mypy clean on src/

#### Step 5.2: Behavioral Equivalence and Consistency Review ✅

**Implementation**:
- Run `repo-sync-kitty --help` and compare output to pre-refactoring baseline (should be identical)
- Review combined diff across all three agent batches for consistency:
  - Same error_console pattern used everywhere
  - Same ExitCode import style everywhere
  - Docstring/comment removal is consistent in approach
- Verify no file was modified by more than one agent (exclusive ownership check)

**Deliverables**:
☑ CLI help output unchanged
☑ Combined diff reviewed for cross-batch consistency

**Validation Checkpoint**:
```bash
cd /home/vlad/Proj/mine/claude-tools/tools/repo-sink-kitty
uv run pytest --tb=short -q
# Expected: 414 passed

uv run ruff check src/
# Expected: All checks passed

uv run mypy src/
# Expected: Success

uv run repo-sync-kitty --help
# Expected: Same help output as before refactoring
```
**User Validated**: ☑

## Dependencies

**Internal Dependencies:**
- Phase 1 creates `exitcodes.py` which Phases 2, 3, 4 all import from
- Phases 2, 3, 4 have NO mutual dependencies (non-overlapping file sets)
- Phase 5 depends on all three parallel phases completing

**External Dependencies:**
- None (pure refactoring of existing code)

## Notes

**Files Explicitly Excluded (CLEAN):**
- `src/repo_sync_kitty/util/git.py`
- `src/repo_sync_kitty/__about__.py`
- `src/repo_sync_kitty/__init__.py`
- `src/repo_sync_kitty/__main__.py`

**Refactoring Safety Rules:**
- NO behavioral changes -- same inputs produce same outputs
- NO new features introduced
- NO test modifications (tests validate behavioral equivalence)
- If any test fails after a change, the change must be reverted and reconsidered

**ExitCode Mapping:**
- `typer.Exit(0)` or `typer.Exit()` maps to `ExitCode.SUCCESS`
- `typer.Exit(1)` maps to `ExitCode.GENERAL_ERROR`
- `typer.Exit(2)` maps to `ExitCode.USAGE_ERROR`
- The integer values are preserved, only the symbolic names change

**Parallel Execution Notes:**
- Each agent must only modify files in its exclusive ownership set
- Each agent independently imports from `exitcodes.py` (read-only dependency)
- Each agent independently creates `error_console = Console(stderr=True)` in its files (local pattern, not shared instance)
- If merge conflicts arise in Phase 5, they indicate an ownership violation
