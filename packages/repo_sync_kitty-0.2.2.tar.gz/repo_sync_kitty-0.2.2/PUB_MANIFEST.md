# Publication Manifest: repo-sink-kitty

## Metadata
- **Internal Path**: tools/repo-sink-kitty/
- **Public Repo**: https://github.com/vladistan/repo-sync-kitty
- **Package Name**: repo-sync-kitty
- **PyPI**: https://pypi.org/project/repo-sync-kitty/
- **License**: MIT
- **First Published**: (not yet published)
- **Last Published**: (not yet published)

## Version History

| Version | Date | Commit (Internal) | Commit (Public) | Notes |
|---------|------|-------------------|-----------------|-------|
| 0.2.1 | 2026-03-28 | (pending) | (pending) | First public release |

## Sanitization Config

### Tool-Specific Patterns
exclude_files:
  - ".venv/"
  - "__pycache__/"
  - "*.pyc"
  - ".pytest_cache/"
  - ".mypy_cache/"
  - ".coverage"
  - "htmlcov/"
  - "dist/"
  - "build/"
  - "*.egg-info/"

replace_patterns:
  - pattern: "tools/repo-sink-kitty"
    replacement: "repo-sync-kitty"
  - pattern: "tools/repo-sync-kitty"
    replacement: "repo-sync-kitty"
  - pattern: "/home/vlad/Proj/mine/claude-tools/tools/repo-sink-kitty"
    replacement: "."
  - pattern: "vlad@v-lad.org"
    replacement: "(public contact to be determined)"
  - pattern: "https://1f04a1828fa9baae9f93e64d4385f76d@o4508594232426496.ingest.us.sentry.io/4511123439484928"
    replacement: "https://YOUR_DSN@sentry.io/YOUR_PROJECT_ID"

### Notes
- Internal folder is `repo-sink-kitty` (typo); public repo and package are `repo-sync-kitty`
- Sentry DSN in `src/repo_sync_kitty/monitoring.py` must be replaced before publishing

### Override Global Patterns
skip_global_patterns:
  - "(if needed)"

## Publication Checklist
- [ ] All tests pass
- [ ] No secrets detected
- [ ] LICENSE file present
- [ ] README.md updated for public
- [ ] Package manifest has public-appropriate metadata
- [ ] Sentry DSN replaced with placeholder in monitoring.py
- [ ] Verify no internal endpoint URLs in config examples
- [ ] Check pyproject.toml for public-appropriate metadata
