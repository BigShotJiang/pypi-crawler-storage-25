"""Sync service."""

from __future__ import annotations

from pathlib import Path

from envctl.domain.project import ProjectContext
from envctl.services.context_service import load_project_context
from envctl.services.group_selection_service import (
    build_variable_groups,
    filter_projection_values,
)
from envctl.services.projection_validation import resolve_projectable_environment
from envctl.utils.atomic import write_text_atomic
from envctl.utils.project_paths import build_repo_sync_env_path, normalize_profile_name
from envctl.utils.projection_rendering import render_dotenv


def run_sync(
    active_profile: str | None = None,
    *,
    output_path: Path | None = None,
    group: str | None = None,
) -> tuple[ProjectContext, str, Path]:
    """Materialize the resolved environment into the repository env file."""
    _config, context = load_project_context()
    resolved_profile = normalize_profile_name(active_profile)

    contract, report = resolve_projectable_environment(
        context,
        active_profile=resolved_profile,
        group=group,
        operation="sync",
    )

    values = filter_projection_values(
        {key: item.value for key, item in sorted(report.values.items())},
        contract,
        group=group,
    )

    rendered = render_dotenv(
        values,
        include_header=True,
        variable_groups=build_variable_groups(contract, values),
    )
    target_path = output_path or build_repo_sync_env_path(context.repo_root, resolved_profile)
    write_text_atomic(target_path, rendered)

    return context, resolved_profile, target_path
