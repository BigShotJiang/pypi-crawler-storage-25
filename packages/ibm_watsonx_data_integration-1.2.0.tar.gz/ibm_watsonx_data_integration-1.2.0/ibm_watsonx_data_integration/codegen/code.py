#  IBM Confidential
#  PID 5900-BAF
#  Copyright StreamSets Inc., an IBM Company 2025

"""Module containing Python Generator custom class to hold generated script."""

import nbformat
from abc import ABC, abstractmethod
from nbformat.v4 import new_code_cell, new_markdown_cell, new_notebook
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pathlib import Path


class Code:
    """Utility class to hold generate script of recreating pipeline."""

    def __init__(self, content: str) -> None:
        """The __init__ of the Code class.

        Args:
            content: Generated script as string.
        """
        self._content = content

    def __str__(self) -> str:
        """String representation of containing script."""
        return self._content

    def save(self, path: "Path") -> "Path":
        """Save script content to given path.

        Args:
            path: Location where to save containing script.

        Return:
            Path where generate script was saved.
        """
        with open(path, "w") as f:
            f.write(self._content)

        return path


class NotebookCode(Code):
    """Utility class to hold generated code as Jupyter notebook."""

    def __init__(self, cells: list[dict[str, str]]) -> None:
        """The __init__ of the NotebookCode class.

        Args:
            cells: List of cell dictionaries with 'type' and 'content' keys.
                   type can be 'code' or 'markdown'.
        """
        self._cells = cells
        # Create string representation for __str__
        content_parts = []
        for cell in cells:
            if cell["type"] == "markdown":
                content_parts.append(f"# {cell['content']}")
            else:
                content_parts.append(cell["content"])
        super().__init__("\n\n".join(content_parts))

    def save(self, path: "Path") -> "Path":
        """Save notebook content to given path as .ipynb file.

        Args:
            path: Location where to save containing notebook.

        Return:
            Path where generated notebook was saved.
        """
        # Ensure path has .ipynb extension
        if not str(path).endswith(".ipynb"):
            path = path.with_suffix(".ipynb")

        # Create notebook cells
        nb_cells = []
        for cell in self._cells:
            if cell["type"] == "markdown":
                nb_cells.append(new_markdown_cell(cell["content"]))
            else:
                nb_cells.append(new_code_cell(cell["content"]))

        # Create notebook
        nb = new_notebook(cells=nb_cells)

        # Write notebook to file
        with open(path, "w") as f:
            nbformat.write(nb, f)

        return path


class Coder(ABC):
    """Interface for classes that should return generated scrip wrapped in ``Code`` class."""

    @abstractmethod
    def to_code(self) -> Code:
        """Here we should return code representation."""
