# IBM Confidential
# PID 5900-BAF
# Copyright StreamSets Inc., an IBM Company 2025

"""Contains classes responsible for generating python script preamble."""

from abc import ABC, abstractmethod
from ibm_watsonx_data_integration.codegen.code_generatable import CodeGeneratable
from ibm_watsonx_data_integration.common.constants import (
    PROD_BASE_API_URL,
    PROD_BASE_URL,
    IBMCloudRegion,
)
from jinja2 import Environment, FileSystemLoader, Template
from pathlib import Path
from typing import ClassVar
from typing_extensions import override

TEMPLATE_DIR = Path(__file__).parent / "_templates"
TEMPLATE_LOADER = FileSystemLoader(TEMPLATE_DIR)
TEMPLATE_ENVIRONMENT = Environment(loader=TEMPLATE_LOADER)


class Preamble(ABC):
    """Script preamble containing required imports and class initialization."""

    _imports_template: ClassVar[Template] = TEMPLATE_ENVIRONMENT.get_template("common/imports.py.jinja")
    _auth_template: ClassVar[Template] = TEMPLATE_ENVIRONMENT.get_template("common/auth.py.jinja")
    _platform_template: ClassVar[Template] = TEMPLATE_ENVIRONMENT.get_template("common/platform.py.jinja")
    _project_template: ClassVar[Template] = TEMPLATE_ENVIRONMENT.get_template("common/project.py.jinja")

    def __init__(
        self,
        source_data: dict,
        auth: CodeGeneratable,
        mask_credentials: bool = True,
        base_url: str = PROD_BASE_URL,
        base_api_url: str | IBMCloudRegion = PROD_BASE_API_URL,
    ) -> None:
        """The __init__ of the Preamble class.

        Args:
            source_data: Raw flow data.
            auth: Authenticator object to use in the preamble.
            mask_credentials: Whether or not to mask sensitive credentials.
            base_url: URL for IBM Cloud.
            base_api_url: URL for API endpoints.
        """
        self._source_data = source_data
        self._base_url = base_url
        self._base_api_url = base_api_url.value if isinstance(base_api_url, IBMCloudRegion) else base_api_url
        self._auth_type = type(auth).__name__
        self._auth_as_init = auth._as_init(masked=mask_credentials)

    @abstractmethod
    def _get_template_context(self) -> dict:
        """Get common template context for all sections."""

    @abstractmethod
    def __str__(self) -> str:
        """Here we should return preamble string representation."""

    def get_imports(self) -> str:
        """Get imports section."""
        return self._imports_template.render(**self._get_template_context())

    def get_auth(self) -> str:
        """Get authentication section."""
        return self._auth_template.render(**self._get_template_context())

    def get_platform(self) -> str:
        """Get platform initialization section."""
        return self._platform_template.render(**self._get_template_context())

    def get_project(self) -> str:
        """Get project retrieval section."""
        return self._project_template.render(**self._get_template_context())


class StreamingPreamble(Preamble):
    """Preamble for streaming flow recreation scripts."""

    _template: ClassVar[Template] = TEMPLATE_ENVIRONMENT.get_template("streaming/preamble.py.jinja")
    _environment_template: ClassVar[Template] = TEMPLATE_ENVIRONMENT.get_template("streaming/environment.py.jinja")
    _flow_template: ClassVar[Template] = TEMPLATE_ENVIRONMENT.get_template("streaming/flow.py.jinja")

    @override
    def _get_template_context(self) -> dict:
        """Get common template context for all sections."""
        return {
            "auth_type": self._auth_type,
            "auth": self._auth_as_init,
            "base_url": self._base_url,
            "base_api_url": self._base_api_url,
            "project_id": self._source_data["flow"]["metadata"]["project_id"],
            "environment_id": self._source_data["flow"]["entity"]["streamsets_flow"]["environment_id"],
            "description": self._source_data["flow"]["metadata"]["description"],
        }

    @override
    def __str__(self) -> str:
        return self._template.render(**self._get_template_context())

    def get_environment(self) -> str:
        """Get environment retrieval section."""
        return self._environment_template.render(**self._get_template_context())

    def get_flow(self) -> str:
        """Get flow creation section."""
        return self._flow_template.render(**self._get_template_context())


class ConnectionPreamble(Preamble):
    """Preamble for connection recreation scripts."""

    _template: ClassVar[Template] = TEMPLATE_ENVIRONMENT.get_template("connection/preamble.py.jinja")

    @override
    def _get_template_context(self) -> dict:
        """Get common template context for all sections."""
        return {
            "auth_type": self._auth_type,
            "auth": self._auth_as_init,
            "base_url": self._base_url,
            "base_api_url": self._base_api_url,
            "project_id": self._source_data.get("metadata", {}).get("project_id", "<INSERT PROJECT ID>"),
        }

    @override
    def __str__(self) -> str:
        return self._template.render(**self._get_template_context())
