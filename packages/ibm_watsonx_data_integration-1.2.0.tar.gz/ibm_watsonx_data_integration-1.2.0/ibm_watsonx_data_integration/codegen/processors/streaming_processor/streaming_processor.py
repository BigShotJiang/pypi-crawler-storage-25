#  IBM Confidential
#  PID 5900-BAF
#  Copyright StreamSets Inc., an IBM Company 2025

"""Module containing Python Generator processors for streaming flow."""

import copy
from collections import defaultdict
from dataclasses import dataclass
from ibm_watsonx_data_integration.codegen.code import Code, Coder, NotebookCode
from ibm_watsonx_data_integration.codegen.generator import PythonGeneratorFormat
from ibm_watsonx_data_integration.codegen.preamble import StreamingPreamble
from ibm_watsonx_data_integration.codegen.processors.streaming_processor.streaming_flow_graph import (
    StageVertex,
    StreamingFlowGraph,
)
from ibm_watsonx_data_integration.common.constants import (
    PROD_BASE_API_URL,
    PROD_BASE_URL,
)
from ibm_watsonx_data_integration.services.streamsets.api import EnvironmentApiClient
from jinja2 import Environment, PackageLoader
from typing import TYPE_CHECKING, Any, ClassVar

if TYPE_CHECKING:
    from ibm_watsonx_data_integration.common.auth import BaseAuthenticator


@dataclass(frozen=True)
class DefaultStageDefinition:
    """Wrapper structure for stage definition."""

    label: str
    type: str
    config_definitions: list[dict[str, Any]]


class StreamingProcessor(Coder):
    """Main processor for recreating script to create streaming flow.

    Responsible for creating ``StageVertex`` class for each stage within pipeline definition.
    Handle building relation graph between stages using adjacency list.
    """

    _definitions: dict[str, DefaultStageDefinition] | None
    _template_env: ClassVar[Environment] = Environment(
        loader=PackageLoader("ibm_watsonx_data_integration.codegen", "_templates")
    )
    _script_template: ClassVar = _template_env.get_template("streaming/complete_script.py.jinja")

    def __init__(
        self,
        source_data: dict,
        auth: "BaseAuthenticator",  # pragma: allowlist secret
        mask_credentials: bool = True,
        base_url: str = PROD_BASE_URL,
        base_api_url: str = PROD_BASE_API_URL,
        persist_topology: bool = False,
        output_format: PythonGeneratorFormat = PythonGeneratorFormat.PYTHON,
    ) -> None:
        """The __init__ of the StreamingProcessor class.

        Args:
            source_data: Streaming flow definition as python dictionary.
            auth: Authenticator instance.
            mask_credentials: Whether or not to mask sensitive credentials.
            base_url: URL to IBM Cloud.
            base_api_url: URL to API endpoints.
            persist_topology: Whether to preserve stage coordinates in generated code.
            output_format: Output format for generated code.
        """
        self._source_data = source_data
        self._environment_api_client = EnvironmentApiClient(auth=auth, base_url=base_api_url)
        self._stage_counter = defaultdict(int)
        self._stages = list()
        self._preamble = StreamingPreamble(
            source_data=source_data,
            auth=auth,
            mask_credentials=mask_credentials,
            base_url=base_url,
            base_api_url=base_api_url,
        )
        self._lanes_to_vertex_lookup = dict()
        self._graph = StreamingFlowGraph()
        self._definitions = None
        self._persist_topology = persist_topology
        self._output_format = output_format

    @property
    def definitions(self) -> dict[str, DefaultStageDefinition]:
        """Parsed stage definitions with configuration definition."""
        if not self._definitions:
            res_json = self._environment_api_client.get_library_definitions_for_engine_version(
                engine_version=self._source_data["flow"]["entity"]["streamsets_flow"]["engine_version"]
            ).json()
            self._definitions = self._parse_definition_response(res_json)

        return self._definitions

    @property
    def graph(self) -> StreamingFlowGraph:
        """Returns streaming flow DAG structure."""
        if self._graph.is_empty():
            self._extract_stages()

        return self._graph

    @staticmethod
    def _parse_definition_response(definition_json: dict) -> dict[str, DefaultStageDefinition]:
        result = dict()
        for _, stage_definition in definition_json["stageDefinitionMap"].items():
            stage_name = stage_definition["name"]
            result[stage_name] = DefaultStageDefinition(
                label=stage_definition["label"],
                type=stage_definition["type"],
                config_definitions=copy.deepcopy(stage_definition["configDefinitions"]),
            )

        return result

    def _extract_stages(self) -> None:
        """Actual StaveVertex creation and building relation graph between stages."""
        for stage_dict in self._source_data["pipeline_definition"]["stages"]:
            self._stage_counter[stage_dict["stageName"]] += 1
            default_stage_definition: DefaultStageDefinition = self.definitions[stage_dict["stageName"]]

            for index, output_lane_id in enumerate(stage_dict["outputLanes"]):
                vertex = StageVertex(
                    instance_name=stage_dict["instanceName"],
                    stage_data=stage_dict,
                    default_stage_definition=default_stage_definition,
                    number_suffix=self._stage_counter[stage_dict["stageName"]],
                    output_lane_index=index,
                    persist_topology=self._persist_topology,
                )
                self._lanes_to_vertex_lookup[output_lane_id] = vertex

            for event_lane_id in stage_dict["eventLanes"]:
                vertex = StageVertex(
                    instance_name=stage_dict["instanceName"],
                    stage_data=stage_dict,
                    default_stage_definition=default_stage_definition,
                    number_suffix=self._stage_counter[stage_dict["stageName"]],
                    persist_topology=self._persist_topology,
                )
                self._lanes_to_vertex_lookup[event_lane_id] = vertex

            for input_lane_id in stage_dict["inputLanes"]:
                is_event_lane = True if "eventlane" in input_lane_id.lower() else False

                vertex = StageVertex(
                    instance_name=stage_dict["instanceName"],
                    stage_data=stage_dict,
                    default_stage_definition=default_stage_definition,
                    number_suffix=self._stage_counter[stage_dict["stageName"]],
                    persist_topology=self._persist_topology,
                )
                source = self._lanes_to_vertex_lookup[input_lane_id]

                # Code order dependency here: first lane then vertex
                self._graph.add_lane(source, vertex, {"is_event_lane": is_event_lane})
                self._graph.add_stage_vertex(vertex)

    def stages_as_str(self) -> str:
        """Collect string representation of all stages.

        Returns:
            A string representation of create stage code for all stages.
        """
        result = []
        for stage in self.graph.stage_vertexes:
            result.append(str(stage))

        return "\n".join(result)

    def stages_connection_as_str(self) -> str:
        """Collect string representation of connection between stages.

        Returns:
            A string representation of connection between stages.
        """
        result = []
        for lane in self.graph.lanes:
            result.append(str(lane))

        return "\n".join(result)

    @property
    def script_footer(self) -> str:
        """Return generated script footer."""
        return "project.update_flow(flow)"

    def to_code(self) -> Code:
        """Returns object holding generated python script or notebook."""
        if self._output_format == PythonGeneratorFormat.NOTEBOOK:
            # Generate notebook with separate cells
            cells = [
                {
                    "type": "markdown",
                    "content": (
                        "## Imports\n\n"
                        "These are the imports needed from the ibm_watsonx_data_integration SDK "
                        "to create a streaming flow."
                    ),
                },
                {"type": "code", "content": self._preamble.get_imports()},
                {
                    "type": "markdown",
                    "content": (
                        "## Authentication\n\n"
                        "Set up authentication to connect to IBM Cloud. "
                        "The authenticator will be used to authenticate all API requests."
                    ),
                },
                {"type": "code", "content": self._preamble.get_auth()},
                {
                    "type": "markdown",
                    "content": (
                        "## Platform Setup\n\n"
                        "Create a Platform instance that provides access to IBM watsonx.data integration services."
                    ),
                },
                {"type": "code", "content": self._preamble.get_platform()},
                {
                    "type": "markdown",
                    "content": (
                        "## Project and Environment Setup\n\n"
                        "Get the project and streaming environment where the flow will be created. "
                        "The environment defines the runtime configuration for streaming flows."
                    ),
                },
                {"type": "code", "content": self._preamble.get_project()},
                {"type": "code", "content": self._preamble.get_environment()},
                {"type": "code", "content": self._preamble.get_flow()},
                {
                    "type": "markdown",
                    "content": (
                        "## Create Stages\n\n"
                        "Create all the stages (origins, processors, destinations) that make up the streaming flow. "
                        "Each stage performs a specific data processing operation."
                    ),
                },
                {"type": "code", "content": self.stages_as_str()},
                {
                    "type": "markdown",
                    "content": (
                        "## Connect Stages\n\n"
                        "Connect the stages together to define the data flow path. "
                        "Data flows from origins through processors to destinations."
                    ),
                },
                {"type": "code", "content": self.stages_connection_as_str()},
                {
                    "type": "markdown",
                    "content": ("## Update Flow\n\nSave the flow with all its stages and connections to the project."),
                },
                {"type": "code", "content": self.script_footer},
            ]
            return NotebookCode(cells=cells)
        else:
            # Generate regular Python script using template
            content = self._script_template.render(
                preamble=str(self._preamble),
                stages=self.stages_as_str(),
                connections=self.stages_connection_as_str(),
                footer=self.script_footer,
            )
            return Code(content=content)
