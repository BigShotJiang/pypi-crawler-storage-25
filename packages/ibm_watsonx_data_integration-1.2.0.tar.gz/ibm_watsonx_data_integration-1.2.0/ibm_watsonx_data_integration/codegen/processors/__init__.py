# IBM Confidential
# PID 5900-BAF
# Copyright StreamSets Inc., an IBM Company 2025

"""This module contains processors used by Python Generator."""

import warnings
from ibm_watsonx_data_integration.codegen.code import Coder
from ibm_watsonx_data_integration.codegen.sources import ConnectionObjectSource, FlowObjectSource, Source
from typing import Any


def processor_factory(source: Source, **kwargs: Any) -> Coder:
    """Factory wrapping source to appropriate Coder.

    Args:
        source: Source to generate code for
        **kwargs: additional key word arguments to pass into the processor object

    Raises:
        TypeError: if source is not a supported as a processor

    Returns:
        Coder: processor object
    """
    from ibm_watsonx_data_integration.codegen.processors.connection_processor import ConnectionProcessor
    from ibm_watsonx_data_integration.codegen.processors.streaming_processor import StreamingProcessor

    match source:
        case FlowObjectSource():
            return StreamingProcessor(source_data=source.to_json(), **kwargs)
        case ConnectionObjectSource():
            # ConnectionProcessor doesn't support persist_topology, so filter it out
            if kwargs.get("persist_topology", False):
                warnings.warn(
                    "\n\033[33mpersist_topology parameter has no effect when generating code for connections. "
                    "This parameter is only supported for flow objects.\033[0m",
                    UserWarning,
                    stacklevel=2,
                )
            connection_kwargs = {k: v for k, v in kwargs.items() if k != "persist_topology"}
            return ConnectionProcessor(source_data=source.to_json(), **connection_kwargs)
        case _:
            raise TypeError(f"{type(source)} is currently not supported as a processor.")


__all__ = ["processor_factory"]
