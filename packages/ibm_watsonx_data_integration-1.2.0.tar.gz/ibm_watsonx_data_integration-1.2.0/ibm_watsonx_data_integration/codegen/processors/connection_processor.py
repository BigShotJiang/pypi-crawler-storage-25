#  IBM Confidential
#  PID 5900-BAF
#  Copyright StreamSets Inc., an IBM Company 2025

"""Module containing Python Generator processor for connections."""

import json
from ibm_watsonx_data_integration.codegen.code import Code, Coder, NotebookCode
from ibm_watsonx_data_integration.codegen.generator import PythonGeneratorFormat
from ibm_watsonx_data_integration.codegen.preamble import ConnectionPreamble
from ibm_watsonx_data_integration.common.constants import (
    PROD_BASE_API_URL,
    PROD_BASE_URL,
)
from jinja2 import Environment, FileSystemLoader, PackageLoader
from pathlib import Path
from pprint import pformat
from typing import TYPE_CHECKING, ClassVar

if TYPE_CHECKING:
    from ibm_watsonx_data_integration.common.auth import BaseAuthenticator


class ConnectionProcessor(Coder):
    """Processor for recreating script to create a connection."""

    _template_env: ClassVar[Environment] = Environment(
        loader=PackageLoader("ibm_watsonx_data_integration.codegen", "_templates")
    )
    _script_template: ClassVar = _template_env.get_template("connection/complete_script.py.jinja")

    def __init__(
        self,
        source_data: dict,
        auth: "BaseAuthenticator",  # pragma: allowlist secret
        mask_credentials: bool,
        base_url: str = PROD_BASE_URL,
        base_api_url: str = PROD_BASE_API_URL,
        output_format: PythonGeneratorFormat = PythonGeneratorFormat.PYTHON,
    ) -> None:
        """The __init__ of the ConnectionProcessor class.

        Args:
            source_data: Connection definition as python dictionary.
            auth: Authenticator instance.
            mask_credentials: Whether or not to mask sensitive credentials.
            base_url: URL to IBM Cloud.
            base_api_url: URL to API endpoints.
            output_format: Output format for generated code.
        """
        self._source_data = source_data
        self._auth = auth
        self._output_format = output_format
        self._preamble = ConnectionPreamble(
            source_data=source_data,
            auth=auth,
            mask_credentials=mask_credentials,
            base_url=base_url,
            base_api_url=base_api_url,
        )

    def connection_as_str(self) -> str:
        """Returns project.create_connection statement."""
        environment = Environment(loader=FileSystemLoader(Path(__file__).parent / ".." / "_templates"))
        environment.filters["format_dict"] = pformat
        template = environment.get_template("connection/create_connection.py.jinja")

        entity: dict = self._source_data["entity"]
        properties_json = "\n    ".join(json.dumps(entity["properties"], indent=4).splitlines())

        return template.render(
            name=entity["name"],
            datasource_id=entity["datasource_type"],
            description=entity.get("description", None),
            properties=properties_json,
        )

    def to_code(self) -> Code | NotebookCode:
        """Returns object holding generated python script or notebook."""
        if self._output_format == PythonGeneratorFormat.NOTEBOOK:
            # Generate notebook with separate cells
            cells = [
                {
                    "type": "markdown",
                    "content": (
                        "## Imports\n\n"
                        "These are the imports needed from the ibm_watsonx_data_integration SDK to create a connection."
                    ),
                },
                {"type": "code", "content": self._preamble.get_imports()},
                {
                    "type": "markdown",
                    "content": (
                        "## Authentication\n\n"
                        "Set up authentication to connect to IBM Cloud. "
                        "The authenticator will be used to authenticate all API requests."
                    ),
                },
                {"type": "code", "content": self._preamble.get_auth()},
                {
                    "type": "markdown",
                    "content": (
                        "## Platform Setup\n\n"
                        "Create a Platform instance that provides access to IBM watsonx.data integration services."
                    ),
                },
                {"type": "code", "content": self._preamble.get_platform()},
                {
                    "type": "markdown",
                    "content": (
                        "## Project Setup\n\n"
                        "Get the project where the connection will be created. "
                        "Projects organize your data integration assets."
                    ),
                },
                {"type": "code", "content": self._preamble.get_project()},
                {
                    "type": "markdown",
                    "content": (
                        "## Create Connection\n\n"
                        "Create the connection with the specified datasource type and properties. "
                        "This connection can be used in flows to access external data sources."
                    ),
                },
                {"type": "code", "content": self.connection_as_str()},
            ]
            return NotebookCode(cells=cells)
        else:
            # Generate regular Python script using template
            content = self._script_template.render(
                preamble=str(self._preamble),
                connection=self.connection_as_str(),
            )
            return Code(content=content)
