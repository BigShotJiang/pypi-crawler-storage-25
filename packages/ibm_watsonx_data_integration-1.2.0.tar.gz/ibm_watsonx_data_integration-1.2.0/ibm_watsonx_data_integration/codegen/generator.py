# IBM Confidential
# PID 5900-BAF
# Copyright StreamSets Inc., an IBM Company 2025

"""This module contains PythonGenerator class."""

from abc import ABC
from enum import Enum
from ibm_watsonx_data_integration.codegen.processors import processor_factory
from ibm_watsonx_data_integration.codegen.sources import source_factory
from ibm_watsonx_data_integration.common.constants import (
    PROD_BASE_API_URL,
    PROD_BASE_URL,
)
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ibm_watsonx_data_integration.codegen.code import Coder
    from ibm_watsonx_data_integration.common.auth import BaseAuthenticator


class PythonGeneratorFormat(str, Enum):
    """Output format options for code generation."""

    PYTHON = "python"
    NOTEBOOK = "notebook"


class Generatable(ABC):
    """Interface indicating an object can be gnerated by the PythonGenerator."""

    pass


class PythonGenerator:
    """Flow code generation entrypoint."""

    def __init__(
        self,
        source: Generatable,
        destination: str | Path,
        auth: "BaseAuthenticator",  # pragma: allowlist secret
        mask_credentials: bool = True,
        persist_topology: bool = False,
        output_format: PythonGeneratorFormat = PythonGeneratorFormat.PYTHON,
        **kwargs: str | object,
    ) -> None:
        """The __init__ of the PythonGenerator class.

        Args:
            source: Location from ``Flow`` definition will be loaded.
            destination: Location where save generated script.
            auth: Reference to authenticator object.
            mask_credentials: Whether or not to mask sensitive authentication credentials. Defaults to true.
            persist_topology: Whether to preserve stage coordinates in generated code. Defaults to false.
            output_format: Output format - PythonGeneratorFormat.PYTHON for .py or PythonGeneratorFormat.NOTEBOOK
                for .ipynb.
            kwargs: Additional configuration values.
        """
        self._source = source_factory(source)
        self._destination = Path(destination)
        self._output_format = output_format
        base_url = kwargs.get("base_url", PROD_BASE_URL)
        base_api_url = kwargs.get("base_api_url", PROD_BASE_API_URL)

        self._processor: Coder = processor_factory(
            self._source,
            auth=auth,
            mask_credentials=mask_credentials,
            base_url=base_url,
            base_api_url=base_api_url,
            persist_topology=persist_topology,
            output_format=output_format,
        )

    def save(self) -> Path:
        """Run code generation then save it to destination.

        Returns:
            Path to the location where the generated script was saved.
        """
        code = self._processor.to_code()
        return code.save(self._destination)
