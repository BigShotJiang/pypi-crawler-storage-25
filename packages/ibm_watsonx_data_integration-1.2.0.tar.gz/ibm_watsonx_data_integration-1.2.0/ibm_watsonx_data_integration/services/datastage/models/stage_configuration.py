#  IBM Confidential
#  PID 5900-BAF
#  Copyright StreamSets Inc., an IBM Company 2026

"""Protocol interface for stage configuration classes.

This module defines a Protocol that specifies the interface that all stage
configuration classes must implement. This allows type checkers to properly
validate that configuration objects have the required methods and attributes
without requiring inheritance from a common base class.
"""

from ibm_watsonx_data_integration.cpd_models.connections_model import Connection
from typing import ClassVar, Protocol, runtime_checkable


@runtime_checkable
class StageConfiguration(Protocol):
    """Protocol defining the interface for stage configuration classes.

    All stage configuration classes (pydantic BaseModel subclasses) should
    implement these class variables and methods to be compatible with the
    DAG StageNode class.

    Class Variables:
        op_name: The operation name for the stage
        node_type: The type of node (e.g., "execution_node")
        image: Path to the stage's icon/image
        label: Human-readable label for the stage
        runtime_column_propagation: Whether runtime column propagation is enabled
        auto_column_propagation: Optional auto column propagation setting
        connection: Optional connection object for connector stages
    """

    # Class variables that all stage configurations must have
    op_name: ClassVar[str]
    node_type: ClassVar[str]
    image: ClassVar[str]
    label: ClassVar[str]
    runtime_column_propagation: bool

    # Optional attributes that some stages may have
    auto_column_propagation: bool | None
    connection: Connection | None  # Connection object for connector stages

    def _get_parameters_props(self) -> dict:
        """Get the parameters properties for the stage.

        Returns:
            Dictionary of parameter properties
        """
        ...

    def _get_advanced_props(self) -> dict:
        """Get the advanced properties for the stage.

        Returns:
            Dictionary of advanced properties
        """
        ...

    def _get_input_ports_props(self, link: str | None = None) -> dict:
        """Get the input port properties for the stage.

        Args:
            link: Optional link name for specific port properties

        Returns:
            Dictionary of input port properties
        """
        ...

    def _get_output_ports_props(self, link: str | None = None) -> dict:
        """Get the output port properties for the stage.

        Args:
            link: Optional link name for specific port properties

        Returns:
            Dictionary of output port properties
        """
        ...

    def _get_input_cardinality(self) -> dict:
        """Get the input cardinality constraints for the stage.

        Returns:
            Dictionary with 'min' and 'max' keys specifying input constraints
        """
        ...

    def _get_output_cardinality(self) -> dict:
        """Get the output cardinality constraints for the stage.

        Returns:
            Dictionary with 'min' and 'max' keys specifying output constraints
        """
        ...

    def _get_app_data_props(self) -> dict:
        """Get the application data properties for the stage.

        Returns:
            Dictionary containing app-specific data like reject/reference input limits
        """
        ...

    def _get_source_props(self) -> dict:
        """Get the source connection properties for the stage.

        Returns:
            Dictionary of source connection properties
        """
        ...

    def _get_target_props(self) -> dict:
        """Get the target connection properties for the stage.

        Returns:
            Dictionary of target connection properties
        """
        ...
