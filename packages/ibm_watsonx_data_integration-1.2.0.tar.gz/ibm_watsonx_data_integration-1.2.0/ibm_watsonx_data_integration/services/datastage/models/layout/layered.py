"""Layout for batch flow."""

import collections
import typing
from ibm_watsonx_data_integration.services.datastage.models.flow.dag import DAG, CommentNode, Node, StageNode
from ibm_watsonx_data_integration.services.datastage.models.layout.common import GroupBoundingBox, NodeBoundingBox

NodeLayer = list[Node]


class LayeredLayout:
    """Layered layout for flow dag."""

    # Default node dimensions
    NODE_WIDTH = 48
    NODE_HEIGHT = 48
    COMMENT_WIDTH = 175
    COMMENT_HEIGHT = 60

    # Constraints for spacing
    NODE_SPACING = 200
    LAYER_SPACING = 200

    # Estimated center of the canvas
    CANVAS_WIDTH = 1600
    CANVAS_HEIGHT = 800

    # Number of iterations of node-swapping to minimize edge crossings. One iteration consists of two sweeps
    BARYCENTRIC_SWEEP_ITERATIONS = 2

    # Number of iterations to refine node positions
    REFINEMENT_ITERATIONS = 300

    def __init__(self, dag: DAG) -> None:
        """Initializes a layered layout."""
        self.dag = dag
        self.layers: list[NodeLayer] = []
        self.comments: list[CommentNode] = []
        self.node_boxes: dict[Node, NodeBoundingBox] = {}
        self.master_container = GroupBoundingBox()
        self.fixed_nodes: set[Node] = set()

    def compute(self) -> None:
        """Compute the layered layout of the DAG.

        Populates the x, y, and height (if non-default) properties of each node.
        Nodes with pre-existing x,y coordinates are treated as fixed anchor points.
        """
        # Identify nodes with pre-existing coordinates
        self.__identify_fixed_nodes()

        self.__collect_comment_nodes()
        # self.__insert_ghost_nodes()
        self.__collect_layers()
        self.__order_layer_nodes()

        self.__position_nodes()

        for _ in range(self.REFINEMENT_ITERATIONS):
            self.__apply_forces()

        # Position comment/annotation nodes after force-based layout is complete
        self.__position_comment_nodes()

        # self.__remove_ghost_nodes()
        self.master_container.center_within(GroupBoundingBox(width=self.CANVAS_WIDTH, height=self.CANVAS_HEIGHT))
        self.master_container.update_absolute_positions(0, 0)

    def __identify_fixed_nodes(self) -> None:
        """Identify nodes with pre-existing coordinates.

        Nodes are considered fixed if they have both x and y coordinates already set
        (not None). These nodes will act as anchor points and will not be repositioned.
        """
        for node in self.dag.nodes():
            if isinstance(node, CommentNode):
                if not node.metadata.get("x"):
                    node.metadata["x"] = node.configuration.x_pos
                    x = node.configuration.x_pos
                if not node.metadata.get("y"):
                    node.metadata["y"] = node.configuration.y_pos
                    y = node.configuration.y_pos
                if not node.metadata.get("height"):
                    node.metadata["height"] = node.configuration.height
                if not node.metadata.get("width"):
                    node.metadata["width"] = node.configuration.width
            else:
                x = node.metadata.get("x")
                y = node.metadata.get("y")
            if x is not None and y is not None:
                self.fixed_nodes.add(node)

    def __collect_comment_nodes(self) -> None:
        """Collect comment/annotation nodes from the DAG."""
        for node in self.dag.nodes():
            if not isinstance(node, CommentNode):
                continue
            self.comments.append(node)

    # def __insert_ghost_nodes(self):
    #     """Insert ghost nodes for edges that span non-adjacent layers. This helps reduce edge crossings caused by
    #     long edges that span multiple layers.

    #     For each edge from a parent to a child where child's layer > parent's layer + 1, create ghost nodes for each
    #     intermediate layer. Each ghost node is marked with metadata['ghost'] = True.
    #     """
    #     for parent in list(self.dag.nodes()):
    #         # Not necessary for comment nodes, as we will position these later
    #         if isinstance(parent, CommentNode):
    #             continue

    #         for child in list(parent.metadata["children"]):
    #             parent_layer_num = parent.metadata["layer"]
    #             child_layer_num = child.metadata["layer"]

    #             # Check if the edge spans more than one layer
    #             if child_layer_num > parent_layer_num + 1:
    #                 last: Node = parent
    #                 # Insert ghost nodes for each intermediate layer
    #                 for layer_num in range(parent_layer_num + 1, child_layer_num):
    #                     ghost_node = GhostNode()
    #                     ghost_node.metadata["layer"] = layer_num
    #                     ghost_node.metadata["children"] = []
    #                     ghost_node.metadata["parents"] = [last]
    #                     # Connect the previous node to the ghost node
    #                     self.dag.adj.setdefault(last, {})[ghost_node] = []
    #                     last.metadata["children"].append(ghost_node)
    #                     last = ghost_node

    #                 # Connect the last ghost node to the child node
    #                 last.metadata["children"].append(child)
    #                 child.metadata["parents"].append(last)
    #                 self.dag.adj.setdefault(last, {})[child] = []

    # def __remove_ghost_nodes(self):
    #     """Remove previously inserted ghost nodes from the DAG."""
    #     clean_adj: dict[Node, dict[Node, list[Link]]] = {}

    #     for from_node in self.dag.nodes():
    #         if from_node.metadata.get("ghost", False):
    #             continue

    #         # Add non-ghost parent nodes to the new adjacency list
    #         # If the parent has any non-ghost children, their links will also be added
    #         clean_adj.setdefault(from_node, {})
    #         for to_node, links in self.dag.adj[from_node].items():
    #             if not to_node.metadata.get("ghost", False):
    #                 # Only keep links where both the parent and child are not ghost nodes
    #                 clean_adj[from_node][to_node] = links

    #     self.dag.adj = clean_adj

    def __apply_forces(self) -> None:
        """Applies two sets of forces.

        1. Weak attractive forces from nodes to their parents
        2. Strong repulsive forces between neighboring nodes in the same layer
        3. Strong attractive forces between nodes connected by a comment/annotation.

        Fixed nodes (with pre-existing coordinates) do not move but still exert
        forces on unfixed nodes.
        """
        # Apply attractive forces from parents to children
        for layer_box in self.master_container.children:
            layer_box = typing.cast(GroupBoundingBox, layer_box)
            for node_box in layer_box.children:
                node_box = typing.cast(NodeBoundingBox, node_box)
                # Skip force application for fixed nodes
                if node_box.is_fixed:
                    continue

                node = node_box.node
                for parent in node.metadata["parents"]:
                    parent_box = self.node_boxes[parent]
                    # TODO: Diminishing force based on layer proximity
                    node_box.add_force(0, min(80, (parent_box.center_y() - node_box.center_y()) * 0.2))

        # Apply strong attractive forces between nodes connected by a comment/annotation
        for comment in self.comments:
            children = comment.metadata.get("children", [])
            if len(children) >= 2:
                # Calculate the center point of all children
                child_boxes = [self.node_boxes[child] for child in children if child in self.node_boxes]
                if len(child_boxes) >= 2:
                    center_y = sum(box.center_y() for box in child_boxes) / len(child_boxes)

                    # Apply attractive force to pull each child toward the center
                    for child_box in child_boxes:
                        if not child_box.is_fixed:
                            force = (center_y - child_box.center_y()) * 0.3
                            child_box.add_force(0, min(100, max(-100, force)))

        # Apply repulsive forces between neighboring nodes in the same layer
        for layer_box in self.master_container.children:
            layer_box = typing.cast(GroupBoundingBox, layer_box)
            for i, node_box in enumerate(layer_box.children):
                node_box = typing.cast(NodeBoundingBox, node_box)
                # Skip force application for fixed nodes
                if node_box.is_fixed:
                    continue

                for j, other_node_box in enumerate(layer_box.children):
                    if i == j:
                        continue
                    other_node_box = typing.cast(NodeBoundingBox, other_node_box)

                    # Check if these nodes are connected by a comment/annotation
                    connected_by_comment = self.__are_nodes_connected_by_comment(node_box.node, other_node_box.node)

                    # Apply force that exponentially grows as the nodes get closer to MIN_NODE_SPACING
                    sign = -1 if node_box.center_y() < other_node_box.center_y() else 1
                    dist = node_box.y_boundary_distance(other_node_box)

                    # Reduce repulsive force if nodes are connected by a comment/annotation
                    if connected_by_comment:
                        # Allow nodes to be much closer when connected by a comment/annotation
                        if dist < 150:
                            force = (300 / max(dist, 1)) ** 2
                            node_box.add_force(0, sign * force)
                    else:
                        # Normal repulsive force
                        if dist < 300:
                            force = (600 / max(dist, 1)) ** 2
                            node_box.add_force(0, sign * force)

        # Apply accumulated forces to unfixed nodes only
        for layer_box in self.master_container.children:
            layer_box = typing.cast(GroupBoundingBox, layer_box)
            for node_box in layer_box.children:
                node_box = typing.cast(NodeBoundingBox, node_box)
                # Only apply forces to unfixed nodes
                if not node_box.is_fixed:
                    node_box.apply_forces()

    def __are_nodes_connected_by_comment(self, node1: Node, node2: Node) -> bool:
        """Check if two nodes are connected by the same comment node."""
        for comment in self.comments:
            children = comment.metadata.get("children", [])
            if node1 in children and node2 in children:
                return True
        return False

    @staticmethod
    def __count_node_relatives(node: Node) -> int:
        """Count the number of relatives (parents and children) of a node, excluding ghost nodes."""

        def is_relative(n: Node) -> bool:
            return not n.metadata.get("ghost", False) and not isinstance(n, CommentNode)

        parent_count = len([n for n in node.metadata["parents"] if is_relative(n)])
        child_count = len([n for n in node.metadata["children"] if is_relative(n)])

        return max(parent_count, child_count)

    def __position_nodes(self) -> None:
        """Position nodes based on their layer number and order within the layer as an initial starting point.

        Also adjust the height of nodes with many relatives to improve visual distinction.
        Nodes with pre-existing coordinates are treated as fixed anchor points.
        """
        for layer_num, layer in enumerate(self.layers):
            has_comment = False
            layer_container = GroupBoundingBox()

            for node_num, node in enumerate(layer):
                # Check if this node has pre-existing coordinates
                is_fixed = node in self.fixed_nodes

                # Determine node dimensions
                if isinstance(node, StageNode):
                    width = self.NODE_WIDTH
                    height = self.NODE_HEIGHT
                    if (relatives := self.__count_node_relatives(node)) >= 3 and not is_fixed:
                        # Increase height of nodes with many relatives (either many parents or many children)
                        height = (self.NODE_HEIGHT + 10) * relatives
                else:
                    width = self.COMMENT_WIDTH
                    height = self.COMMENT_HEIGHT
                    has_comment = True

                if is_fixed:
                    # Use pre-existing coordinates for fixed nodes
                    # Get stored dimensions if available, otherwise use calculated dimensions
                    stored_width = node.metadata.get("width", None) or width
                    stored_height = node.metadata.get("height", None) or height
                    box = NodeBoundingBox(node=node, width=stored_width, height=stored_height, is_fixed=True)
                    # Set position relative to canvas origin (will be adjusted by master_container later)
                    box.x = node.metadata["x"]
                    box.y = node.metadata["y"]
                else:
                    # Create unfixed node box with calculated dimensions
                    box = NodeBoundingBox(node=node, width=width, height=height, is_fixed=False)

                self.node_boxes[node] = box
                layer_container.children.append(box)

            layer_container.width = self.COMMENT_WIDTH if has_comment else self.NODE_WIDTH
            layer_container.arrange_children_vertically(self.NODE_SPACING)
            self.master_container.children.append(layer_container)
            self.master_container.arrange_children_horizontally(self.LAYER_SPACING)

    def __order_layer_nodes(self) -> None:
        """Order nodes within each layer based on the barycentric heuristic.

        The barycentric heuristic reduces edge crossings by ordering nodes in one layer based on the average order of
        their neighbors. We perform alternating downward and upward sweeps to iteratively improve the ordering of nodes
        within each layer.
        """
        # Initially order nodes within each layer alphabetically for consistency
        for layer in self.layers:
            layer.sort(key=lambda n: type(n).__name__)

        # Then order nodes based on barycentric heuristic
        for _ in range(self.BARYCENTRIC_SWEEP_ITERATIONS):
            # Downward sweep - order layers from top to bottom
            for i in range(1, len(self.layers)):
                barycenters = {}
                for node in self.layers[i]:
                    barycenters[node] = self.__compute_weighted_barycenter(node, i)
                self.layers[i].sort(key=lambda n: barycenters[n])

            # Upward sweep - order layers from bottom to top
            for i in range(len(self.layers) - 2, -1, -1):
                barycenters = {}
                for node in self.layers[i]:
                    barycenters[node] = self.__compute_weighted_barycenter(node, i)
                self.layers[i].sort(key=lambda n: barycenters[n])

    def __compute_normalized_index(self, node: Node, current_layer_num: int) -> float:
        """Computes the continuous normalized index of a node within its layer.

        0.5 means the node is in the middle of the layer.
        0 means the node is the first in the layer.
        1 means the node is last.
        """
        layer = self.layers[current_layer_num]
        if len(layer) == 1:
            return 0.5
        return layer.index(node) / (len(layer) - 1)

    def __compute_weighted_barycenter(self, node: Node, current_layer_num: int) -> float:
        """Computes the barycenter of a node within its layer.

        The computation discounts the influence of neighbor nodes
        that are in layers further away from the current layer.
        """
        total_weight = 0
        weighted_sum = 0

        for parent in node.metadata["parents"]:
            parent_layer_num = parent.metadata["layer"]
            if parent_layer_num < current_layer_num:
                weight = 1 / (current_layer_num - parent_layer_num)
                weighted_sum += weight * self.__compute_normalized_index(parent, parent_layer_num)
                total_weight += weight

        for child in node.metadata["children"]:
            child_layer_num = child.metadata["layer"]
            if child_layer_num > current_layer_num:
                weight = 1 / (child_layer_num - current_layer_num)
                weighted_sum += weight * self.__compute_normalized_index(child, child_layer_num)
                total_weight += weight

        if total_weight > 0:
            return weighted_sum / total_weight
        else:
            return 0.5

    def __collect_layers(self) -> None:
        """Collect nodes into list of layers based on the topological order of the DAG."""
        assert self.dag.adj, "DAG is empty"

        # Collect nodes into a dictionary mapping the layer # to the Layer
        layer_dict: dict[int, NodeLayer] = collections.defaultdict(list)
        max_layer = 0
        for node in self.dag.nodes():
            # Don't include comment nodes in layers yet
            if isinstance(node, CommentNode):
                continue
            layer_num = node.metadata["layer"]
            max_layer = max(max_layer, layer_num)
            layer_dict[layer_num].append(node)

        # Assign comment nodes to layers
        for comment in self.comments:
            children = comment.metadata["children"]
            if not children:
                layer_dict[0].append(comment)
                continue

            # Put comment node in layer upstream to children
            layer_num = min([child.metadata["layer"] for child in children]) - 1
            comment.metadata["layer"] = layer_num
            layer_dict[layer_num].append(comment)

        # Convert the dictionary mapping to an ordered list of Layers
        for layer_num in range(max_layer + 1):
            self.layers.append(layer_dict[layer_num])

    def __position_comment_nodes(self) -> None:
        """Position comment/annotation nodes around their connected nodes.

        After the force-based layout is complete, position each comment node
        to be centered around its connected nodes and resize it to encompass them.
        """
        # Padding around child nodes (in pixels)
        PADDING = 75

        for comment in self.comments:
            if comment in self.fixed_nodes:
                continue

            children = comment.metadata.get("children", [])
            if not children:
                continue

            # Get bounding boxes for all connected nodes
            child_boxes = [self.node_boxes[child] for child in children if child in self.node_boxes]
            if not child_boxes:
                continue

            # Get the comment's bounding box
            comment_box = self.node_boxes.get(comment)
            if not comment_box:
                continue

            # Calculate absolute positions of child nodes by finding their layer containers
            child_absolute_positions = []
            for child_box in child_boxes:
                # Find which layer this child belongs to
                for layer_idx, layer_container in enumerate(self.master_container.children):
                    layer_container = typing.cast(GroupBoundingBox, layer_container)
                    if child_box in layer_container.children:
                        # Calculate absolute position: master + layer + child
                        abs_y = self.master_container.y + layer_container.y + child_box.y
                        abs_x = self.master_container.x + layer_container.x + child_box.x
                        child_absolute_positions.append(
                            {
                                "box": child_box,
                                "abs_x": abs_x,
                                "abs_y": abs_y,
                                "layer_idx": layer_idx,
                                "layer_container": layer_container,
                            }
                        )
                        break

            if not child_absolute_positions:
                continue

            # Calculate the bounding box that encompasses all connected nodes (in absolute coordinates)
            min_abs_x = min(pos["abs_x"] for pos in child_absolute_positions)
            max_abs_x = max(pos["abs_x"] + pos["box"].width for pos in child_absolute_positions)
            min_abs_y = min(pos["abs_y"] for pos in child_absolute_positions)
            max_abs_y = max(pos["abs_y"] + pos["box"].height for pos in child_absolute_positions)

            # Find the comment's layer container
            comment_layer_container = None
            for layer_container in self.master_container.children:
                layer_container = typing.cast(GroupBoundingBox, layer_container)
                if comment_box in layer_container.children:
                    comment_layer_container = layer_container
                    break

            if not comment_layer_container:
                continue

            # Calculate desired size with padding
            desired_width = (max_abs_x - min_abs_x) + (2 * PADDING)
            desired_height = (max_abs_y - min_abs_y) + (2 * PADDING)

            # Update comment box dimensions
            comment_box.width = desired_width
            comment_box.height = desired_height

            # Position comment to be centered around the connected nodes
            # Calculate desired top-left position in absolute coordinates
            desired_abs_x = min_abs_x - PADDING
            desired_abs_y = min_abs_y - PADDING

            # Convert back to relative coordinates within the comment's layer
            comment_box.x = desired_abs_x - self.master_container.x - comment_layer_container.x
            comment_box.y = desired_abs_y - self.master_container.y - comment_layer_container.y
