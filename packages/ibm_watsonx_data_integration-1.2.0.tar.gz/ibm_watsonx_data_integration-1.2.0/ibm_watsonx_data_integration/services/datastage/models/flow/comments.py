#  IBM Confidential
#  PID 5900-BAF
#  Copyright StreamSets Inc., an IBM Company 2026

"""Comments class."""

from ibm_watsonx_data_integration.common.utils import SeekableList
from ibm_watsonx_data_integration.services.datastage.models.flow.dag import CommentNode
from typing_extensions import override


class Comments(SeekableList):
    """Seekable List of Comments/Annotations."""

    @override
    def get_all(self, **kwargs: dict) -> "Comments":
        """Retrieve all comments/annotations that match the arguments."""
        return Comments(super().get_all(**kwargs))

    @override
    def get(self, **kwargs: dict) -> CommentNode:
        """Retrieve the first comment/annotation that matches the arguments."""
        return super().get(**kwargs)
