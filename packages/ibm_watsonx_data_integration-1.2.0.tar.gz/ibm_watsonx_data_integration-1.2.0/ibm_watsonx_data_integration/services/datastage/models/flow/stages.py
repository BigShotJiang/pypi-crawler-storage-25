#  IBM Confidential
#  PID 5900-BAF
#  Copyright StreamSets Inc., an IBM Company 2026

"""Stages class."""

from ibm_watsonx_data_integration.common.utils import SeekableList
from ibm_watsonx_data_integration.services.datastage.models.flow.dag import StageNode
from ibm_watsonx_data_integration.services.datastage.models.flow.string_to_stage import string_to_stage_class
from typing_extensions import override


class Stages(SeekableList):
    """Seekable List of Batch Stages."""

    @override
    def get_all(self, **kwargs: dict) -> "Stages":
        """Retrieve all stages that match the arguments."""
        stages = self
        if "type" in kwargs:
            stage_type: str = str(kwargs["type"])
            stages = [stage for stage in stages if isinstance(stage, string_to_stage_class(stage_type))]
            del kwargs["type"]
        if "label" in kwargs:
            found = False
            for stage in stages:
                if stage.label == kwargs["label"]:
                    stages = [stage]
                    found = True
                    del kwargs["label"]
                    break
            if not found:
                raise ValueError(f"No stage with label {kwargs['label']} in the flow")

        results = []
        for obj in stages:
            config = getattr(obj, "configuration", {})
            if all(hasattr(config, key) and getattr(config, key) == value for key, value in kwargs.items()):
                results.append(obj)
        return Stages(results)

    @override
    def get(self, **kwargs: dict) -> StageNode:
        """Retrieve the first stage that matches the arguments."""
        results = self.get_all(**kwargs)
        if not results:
            raise ValueError(f"No stage that matches the arguments {kwargs}")
        return next(iter(results))
