#  IBM Confidential
#  PID 5900-BAF
#  Copyright StreamSets Inc., an IBM Company 2026

"""Links class."""

from ibm_watsonx_data_integration.common.utils import SeekableList
from ibm_watsonx_data_integration.services.datastage.models.flow.dag import Link
from typing_extensions import override


class Links(SeekableList):
    """Seekable List of Links."""

    @override
    def get_all(self, **kwargs: dict) -> "Links":
        """Retrieve all links that match the arguments."""
        return Links(super().get_all(**kwargs))

    @override
    def get(self, **kwargs: dict) -> Link:
        """Retrieve the first link that matches the arguments."""
        return super().get(**kwargs)
