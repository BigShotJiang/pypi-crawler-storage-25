"""Base connection for batch connections."""

from ibm_watsonx_data_integration.cpd_models.connections_model import Connection
from pydantic import BaseModel


class BaseConnection(BaseModel):
    """Base class for batch connections."""

    asset_id: str | None = None
    proj_id: str | None = None
    raw_properties: dict | None = None

    def from_connection(self, connection: Connection) -> "BaseConnection":
        """Initializes the underlying DataStage connection object from a generic cpd connection."""
        self.asset_id = connection.metadata.asset_id
        self.proj_id = connection.metadata.project_id
        self.name = connection.name

        alias_to_attr = {}
        for field_name, field_info in self.__class__.model_fields.items():
            if field_info.alias:
                alias_to_attr[field_info.alias] = field_name

        missing_keys = set()

        for k, v in connection.properties.items():
            if k in alias_to_attr:
                setattr(self, alias_to_attr[k], v)
            else:
                # couldn't find a matching attribute on the Conn object to set
                missing_keys.add(k)

        if missing_keys:
            print(f"Connection attributes could not be set: {missing_keys}")
        return self

    def __str__(self) -> str:
        """Format string into pretty json."""
        # Unfortunately, there are many scenarios where we need to stifle warnings in model_dump_json
        # For whatever reason, the generated zip files that contain connections do not have 1:1 type matching with
        # the models. For example, the value in a zip file for a connetion's port is a string, but the model is an
        # integer. We are stifling the warnings here to avoid the warning in the generated code.
        return self.model_dump_json(indent=4, warnings="none")

    def __repr__(self) -> str:
        """Represent model as string."""
        return self.__str__()

    def __getitem__(self, item: str) -> any:
        """Override getting to allow bracket notation."""
        return getattr(self, item)

    def __setitem__(self, key: str, value: any) -> None:
        """Override setting to allow bracket notation."""
        setattr(self, key, value)
