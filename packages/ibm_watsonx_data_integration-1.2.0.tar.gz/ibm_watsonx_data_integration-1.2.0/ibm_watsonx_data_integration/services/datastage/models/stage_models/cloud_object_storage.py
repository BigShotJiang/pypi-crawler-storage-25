"""This module defines configuration for the IBM Cloud Object Storage stage."""

import re
import warnings
from ibm_watsonx_data_integration.services.datastage.models.base_stage import BaseStage
from ibm_watsonx_data_integration.services.datastage.models.connections.cloud_object_storage_connection import (
    CloudObjectStorageConn,
)
from ibm_watsonx_data_integration.services.datastage.models.enums import CLOUD_OBJECT_STORAGE
from pydantic import Field
from typing import ClassVar


class cloud_object_storage(BaseStage):
    """Properties for the IBM Cloud Object Storage stage."""

    op_name: ClassVar[str] = "cloudobjectstoragePX"
    node_type: ClassVar[str] = "binding"
    image: ClassVar[str] = "/data-intg/flows/graphics/palette/cloudobjectstoragePX.svg"
    label: ClassVar[str] = "IBM Cloud Object Storage"
    runtime_column_propagation: bool = Field(False, alias="runtime_column_propagation")
    connection: CloudObjectStorageConn = CloudObjectStorageConn()
    append_unique_identifier: bool | None = Field(
        False,
        alias="append_uid",
        description=(
            "Use this property to choose if a unique identifier is to be appended to the file name. When the "
            "value of this property is set to yes, then the file name gets appended with the unique identifier, "
            "and a new file would be written for every wave of data that is streamed into the stage. When the "
            "value of this property is set to No, then the file would be overwritten on every wave."
        ),
    )
    bucket: str | None = Field(
        None, alias="bucket", description=("The name of the bucket that contains the files to access")
    )
    buf_free_run_ronly: int | None = Field(50, alias="buf_free_run_ronly")
    buf_mode_ronly: CLOUD_OBJECT_STORAGE.BufModeRonly | None = Field(
        CLOUD_OBJECT_STORAGE.BufModeRonly.default, alias="buf_mode_ronly"
    )
    buffer_free_run_percent: int | None = Field(
        50,
        alias="buf_free_run",
        description=("Specifies how much of the available in-memory buffer to use before the buffer writes to disk."),
    )
    buffering_mode: CLOUD_OBJECT_STORAGE.BufferingMode | None = Field(
        CLOUD_OBJECT_STORAGE.BufferingMode.default,
        alias="buf_mode",
        description=(
            "(Default): The link takes the settings that are specified by the environment variables. This is "
            "Auto buffer unless you have changed the value of the APT_BUFFERING _POLICY environment variable.   "
            "Auto buffer: The link buffers incoming data only if necessary to prevent a dataflow deadlock "
            "situation.  Buffer: The link unconditionally buffer all incoming data.  No buffer: The link does "
            "not buffer data under any circumstances. This setting might cause deadlocks if not used carefully."
        ),
    )
    byte_limit: str | None = Field(
        None,
        alias="byte_limit",
        description=(
            "The maximum number of bytes to return. Use any of following suffixes to change the unit: KB, MB, "
            "GB, or TB. A value of 0 returns all data."
        ),
    )
    cell_range: str | None = Field(
        None,
        alias="range",
        description=("The range of cells to retrieve from the Excel worksheet, for example, C1:F10"),
    )
    codec_avro: CLOUD_OBJECT_STORAGE.CodecAvro | None = Field(
        None, alias="codec_avro", description=("The compression codec to use when writing")
    )
    codec_csv: CLOUD_OBJECT_STORAGE.CodecCsv | None = Field(
        None, alias="codec_csv", description=("The compression codec to use when writing")
    )
    codec_delimited: CLOUD_OBJECT_STORAGE.CodecDelimited | None = Field(
        None, alias="codec_delimited", description=("The compression codec to use when writing")
    )
    codec_orc: CLOUD_OBJECT_STORAGE.CodecOrc | None = Field(
        None, alias="codec_orc", description=("The compression codec to use when writing")
    )
    codec_parquet: CLOUD_OBJECT_STORAGE.CodecParquet | None = Field(
        None, alias="codec_parquet", description=("The compression codec to use when writing")
    )
    collecting: CLOUD_OBJECT_STORAGE.Collecting | None = Field(
        CLOUD_OBJECT_STORAGE.Collecting.auto,
        alias="coll_type",
        description=("Specify the order in which data is read."),
    )
    column_metadata_change_propagation: bool | None = Field(
        None,
        alias="auto_column_propagation",
        description=("Automatically apply column metadata changes to downstream stages(See Settings in toolbar)"),
    )
    combinability_mode: CLOUD_OBJECT_STORAGE.CombinabilityMode | None = Field(
        CLOUD_OBJECT_STORAGE.CombinabilityMode.auto,
        alias="combinability",
        description=("Specify whether to combine underlying operators into a single process."),
    )
    create_bucket: bool | None = Field(
        False, alias="create_bucket", description=("Create the bucket that contains the files to write to")
    )
    create_data_asset: bool | None = Field(
        False,
        alias="registerDataAsset",
        description=(
            "If this checkbox is selected and a data asset with the file name does not already exist, a project "
            "data asset will be created. The asset will not be updated if the job is rerun."
        ),
    )
    current_output_link_type: str = Field("PRIMARY", alias="currentOutputLinkType")
    data_asset_name: str = Field(None, alias="dataAssetName", description="Data asset name")
    date_format: str | None = Field(
        None, alias="date_format", description=("The format of date values, for example, yyyy-[M]M-[d]d")
    )
    db2_database_name: str | None = Field(None, alias="part_client_dbname", description="Db2 Database name")
    db2_instance_name: str | None = Field(None, alias="part_client_instance", description="Db2 Instance name")
    db2_source_connection_required: str | None = Field(
        "", alias="part_dbconnection", description=("Db2 Source connection (required)")
    )
    db2_table_name: str | None = Field(None, alias="part_table", description="Db2 Table name")
    decimal_format: str | None = Field(
        None, alias="decimal_format", description=("The format of decimal values, for example, #,###.##")
    )
    decimal_grouping_separator: str | None = Field(
        None,
        alias="decimal_format_grouping_separator",
        description=(
            "The character used to group digits of similar significance. This property and decimal separator "
            "property must be unique. If you encounter error related to them not being unique when only one of "
            "them was provided then please provide the missing one explicitly."
        ),
    )
    decimal_rounding_mode: CLOUD_OBJECT_STORAGE.DecimalRoundingMode | None = Field(
        CLOUD_OBJECT_STORAGE.DecimalRoundingMode.floor,
        alias="decimal_rounding_mode",
        description=("Different rounding modes for values in columns of decimal and numeric data types"),
    )
    decimal_separator: str | None = Field(
        None,
        alias="decimal_format_decimal_separator",
        description=(
            "The character used to separate the integer part from the fractional part of a number. This property "
            "and decimal grouping separator property must be unique. If you encounter error related to them not "
            "being unique when only one of them was provided then please provide the missing one explicitly."
        ),
    )
    default_maximum_length_for_columns: int | None = Field(
        20000,
        alias="default_max_string_binary_precision",
        description=(
            "Default maximum length for columns. This property can be set/is applicable only when runtime column "
            "propagation is used"
        ),
    )
    defer_credentials: bool | None = Field(
        False, alias="defer_credentials", description=("Defer specifying credentials until usage")
    )
    delete_bucket: bool | None = Field(False, alias="delete_bucket", description="Delete the bucket")
    disk_write_inc_ronly: int | None = Field(1048576, alias="disk_write_inc_ronly")
    disk_write_increment_bytes: int | None = Field(
        1048576,
        alias="disk_write_inc",
        description=("Sets the size, in bytes, of blocks of data being moved to and from disk."),
    )
    display_value_labels: bool | None = Field(
        None, alias="display_value_labels", description="Display the value labels"
    )
    ds_java_heap_size: int | None = Field(
        256, alias="_java._heap_size", description=("Specify the maximum Java Virtual Machine heap size in megabytes.")
    )
    enable_flow_acp_control: bool = Field(True, alias="enableFlowAcpControl")
    enable_schemaless_design: bool = Field(False, alias="enableSchemalessDesign")
    encoding: str | None = Field(
        "utf-8", alias="encoding", description=("The appropriate character encoding for your data, for example, UTF-8")
    )
    encryption_key: str | None = Field(None, alias="encryption_key", description="Key to decrypt sav file")
    endpoint_folder: str | None = Field(None, alias="table_folder_name", description="The endpoint folder of the table")
    escape_character: CLOUD_OBJECT_STORAGE.EscapeCharacter | None = Field(
        CLOUD_OBJECT_STORAGE.EscapeCharacter.none,
        alias="escape_character",
        description=(
            "The character that's used to escape other characters, for example, a backslash. Escaping is a "
            "string technique that identifies characters as being part of a string value."
        ),
    )
    escape_character_value: str = Field(
        None,
        alias="escape_character_value",
        description=("The custom character that is used to escape other characters."),
    )
    exclude_missing_values: bool | None = Field(
        None,
        alias="exclude_missing_values",
        description=("Set values that have been defined as missing values to null"),
    )
    execution_mode: CLOUD_OBJECT_STORAGE.ExecutionMode | None = Field(
        CLOUD_OBJECT_STORAGE.ExecutionMode.default_par,
        alias="execmode",
        description=("Specify whether your stage runs sequentially or in parallel."),
    )
    field_delimiter: CLOUD_OBJECT_STORAGE.FieldDelimiter | None = Field(
        CLOUD_OBJECT_STORAGE.FieldDelimiter.comma,
        alias="field_delimiter",
        description=("The character that separates each value from the next value, for example, a comma"),
    )
    field_delimiter_value: str = Field(
        None,
        alias="field_delimiter_value",
        description=("The custom character that separates each value from the next value"),
    )
    fields_xml_path: str | None = Field(
        None,
        alias="xml_path_fields",
        description=(
            "The path that identifies the specified elements to retrieve from the root path of a XML document, "
            "for example, ../publisher"
        ),
    )
    file_format: CLOUD_OBJECT_STORAGE.FileFormat | None = Field(
        CLOUD_OBJECT_STORAGE.FileFormat.csv, alias="file_format", description=("The format of the file to write to")
    )
    file_name: str | None = Field(None, alias="file_name", description="The name of the file to write to or delete")
    file_size_threshold: int | None = Field(
        1,
        alias="file_size_threshold",
        description=(
            "Specify the threshold for the file size in megabytes. Processing nodes will start a new file each "
            "time the size exceeds the value specified in the threshold."
        ),
    )
    first_line: int | None = Field(0, alias="first_line", description="Indicates at which row start reading")
    first_line_is_header: bool | None = Field(
        False, alias="first_line_header", description=("Indicates whether the row where reading starts is the header")
    )
    flow_dirty: str | None = Field("false", alias="flow_dirty")
    generate_unicode_type_columns: bool | None = Field(
        False,
        alias="generate_unicode_columns",
        description=(
            "Generate unicode type columns. This property can be set/is applicable only when runtime column "
            "propagation is used"
        ),
    )
    hide: bool | None = Field(False, alias="hide")
    iam_cos_url: str | None = Field(None, alias="iam_cos_url")
    include_types: bool | None = Field(
        False, alias="include_types", description=("Include data types in the first line of the file")
    )
    infer_as_varchar: bool | None = Field(
        None, alias="infer_as_varchar", description=("Treat the data in all columns as VARCHARs")
    )
    infer_null_as_empty_string: bool | None = Field(
        False,
        alias="infer_null_as_empty_string",
        description=("Treat empty values in string type columns as empty strings instead of null"),
    )
    infer_record_count: int | None = Field(
        1000,
        alias="infer_record_count",
        description=("The number of records to process to obtain the structure of the data"),
    )
    infer_schema: bool | None = Field(None, alias="infer_schema", description="Obtain the schema from the file")
    infer_timestamp_as_date: bool | None = Field(
        True, alias="infer_timestamp_as_date", description=("Infer columns containing date and time data as date")
    )
    input_count: int | None = Field(0, alias="input_count")
    input_link_description: list | None = Field("", alias="inputLinkDescription")
    inputcol_properties: list | None = Field([], alias="inputcolProperties")
    invalid_data_handling: CLOUD_OBJECT_STORAGE.InvalidDataHandling | None = Field(
        CLOUD_OBJECT_STORAGE.InvalidDataHandling.fail,
        alias="invalid_data_handling",
        description=("How to handle values that are not valid: fail the job, null the column, or drop the row"),
    )
    json_infer_record_count: int | None = Field(
        None,
        alias="json_infer_record_count",
        description=(
            "Deprecated. Use infer_record_count property. The number of JSON elements to process to obtain the "
            "structure of the data"
        ),
    )
    json_path: str | None = Field(
        None,
        alias="json_path",
        description=(
            "The path that identifies the elements to retrieve from a JSON document, for example, $.book.publisher"
        ),
    )
    key_cols_coll: list | None = Field([], alias="keyColsColl")
    key_cols_coll_ordered: list | None = Field([], alias="keyColsCollOrdered")
    key_cols_coll_robin: list | None = Field([], alias="keyColsCollRobin")
    key_cols_none: list | None = Field([], alias="keyColsNone")
    key_cols_part: list | None = Field([], alias="keyColsPart")
    labels_as_names: bool | None = Field(
        None, alias="labels_as_names", description=("Set column names to the value of the column label")
    )
    max_mem_buf_size_ronly: int | None = Field(3145728, alias="max_mem_buf_size_ronly")
    maximum_memory_buffer_size_bytes: int | None = Field(
        3145728,
        alias="max_mem_buf_size",
        description=(
            "Specifies the maximum amount of virtual memory, in bytes, used per buffer. The default size is "
            "3145728 (3 MB)."
        ),
    )
    names_as_labels: bool | None = Field(
        None, alias="names_as_labels", description=("Set column labels to the value of the column name")
    )
    node_count: int | None = Field(1, alias="node_count", description="Node count")
    node_number: int | None = Field(0, alias="node_number", description="Node number")
    null_value: str | None = Field(
        None,
        alias="null_value",
        description=("The value that represents null (a missing value) in the file, for example, NULL"),
    )
    output_acp_should_hide: bool = Field(True, alias="outputAcpShouldHide")
    output_as_json: bool | None = Field(
        None,
        alias="output_avro_as_json",
        description=("Each row in the Avro file would be exported as JSON to a string column"),
    )
    output_count: int | None = Field(1, alias="output_count")
    output_link_description: list | None = Field("", alias="outputLinkDescription")
    outputcol_properties: list | None = Field([], alias="outputcolProperties")
    part_stable_coll: bool | None = Field(False, alias="part_stable_coll")
    part_stable_ordered: bool | None = Field(False, alias="part_stable_ordered")
    part_stable_roundrobin_coll: bool | None = Field(False, alias="part_stable_roundrobin_coll")
    part_unique_coll: bool | None = Field(False, alias="part_unique_coll")
    part_unique_ordered: bool | None = Field(False, alias="part_unique_ordered")
    part_unique_roundrobin_coll: bool | None = Field(False, alias="part_unique_roundrobin_coll")
    partition_name_prefix: str | None = Field(
        "part", alias="partition_name_prefix", description=("The prefix in each partition name")
    )
    partition_type: CLOUD_OBJECT_STORAGE.PartitionType | None = Field(
        CLOUD_OBJECT_STORAGE.PartitionType.auto, alias="part_type", description=("Partition type")
    )
    partitioned: bool | None = Field(False, alias="partitioned", description="Write the file as multiple partitions")
    perform_sort: bool | None = Field(False, alias="perform_sort", description="Perform sort")
    perform_sort_coll: bool | None = Field(False, alias="perform_sort_coll")
    perform_sort_modulus: bool | None = Field(False, alias="perform_sort_modulus", description="Perform sort")
    preserve_partitioning: CLOUD_OBJECT_STORAGE.PreservePartitioning | None = Field(
        CLOUD_OBJECT_STORAGE.PreservePartitioning.default_propagate,
        alias="preserve",
        description=("Specify whether to maintain data in current partitions."),
    )
    queue_upper_bound_size_bytes: int | None = Field(
        0,
        alias="queue_upper_size",
        description=("Specifies the maximum amount of data buffered at any time using both memory and disk."),
    )
    queue_upper_size_ronly: int | None = Field(0, alias="queue_upper_size_ronly")
    quote_character: CLOUD_OBJECT_STORAGE.QuoteCharacter | None = Field(
        CLOUD_OBJECT_STORAGE.QuoteCharacter.none,
        alias="quote_character",
        description=("The character that's used to enclose string values, for example, a double quotation mark"),
    )
    quote_numeric_values: bool | None = Field(
        True,
        alias="quote_numerics",
        description=("Enclose numeric values the same as strings using the quote character"),
    )
    read_mode: CLOUD_OBJECT_STORAGE.ReadMode | None = Field(
        CLOUD_OBJECT_STORAGE.ReadMode.read_single, alias="read_mode", description=("The method for reading files")
    )
    read_part_size: int | None = Field(
        None, alias="read_part_size", description=("The part size in MB at which a file gets split")
    )
    row_delimiter: CLOUD_OBJECT_STORAGE.RowDelimiter | None = Field(
        CLOUD_OBJECT_STORAGE.RowDelimiter.new_line,
        alias="row_delimiter",
        description=(
            "The character or characters that separate one line from another, for example, CR/LF (Carriage "
            "Return/Line Feed)"
        ),
    )
    row_delimiter_value: str = Field(
        None, alias="row_delimiter_value", description=("The custom string that separates each rows from the next one.")
    )
    row_limit: int | None = Field(None, alias="row_limit", description="The maximum number of rows to return")
    row_start: int | None = Field(
        None,
        alias="row_start",
        description=("Indicates the offset from the row where reading starts to treat as the start of the data"),
    )
    runtime_column_propagation: bool | None = Field(
        None,
        alias="runtime_column_propagation",
        description=("Propagate extra columns that are not defined in the metadata through the rest of the job."),
    )
    schema_of_xml: str | None = Field(
        None,
        alias="xml_schema",
        description=(
            "The schema that specified metadata information of elements, for example, data type, values, min, max"
        ),
    )
    show_coll_type: int | None = Field(0, alias="showCollType")
    show_part_type: int | None = Field(1, alias="showPartType")
    show_sort_options: int | None = Field(0, alias="showSortOptions")
    sort_instructions: str | None = Field("", alias="sortInstructions")
    sort_instructions_text: str | None = Field("", alias="sortInstructionsText")
    sorting_key: CLOUD_OBJECT_STORAGE.KeyColSelect | None = Field(
        CLOUD_OBJECT_STORAGE.KeyColSelect.default, alias="keyColSelect"
    )
    stable: bool | None = Field(
        None, alias="part_stable", description=("Select Stable if you want to preserve previously sorted data sets.")
    )
    stage_description: list | None = Field("", alias="stageDescription", description="Description")
    storage_class: CLOUD_OBJECT_STORAGE.StorageClass | None = Field(
        CLOUD_OBJECT_STORAGE.StorageClass.standard,
        alias="storage_class",
        description=("The storage class for the created bucket"),
    )
    store_shared_strings_in_the_temporary_file: bool | None = Field(
        None,
        alias="use_sst_temp_file",
        description=(
            "Whether to store shared strings in the encrypted temporary file and trade memory usage for a disk "
            "space usage. Shared strings are stored in the memory by default, which can lead to memory issues "
            "when dealing with large workbooks. It is recommended to enable this option for a large XLSX files."
        ),
    )
    table_action: CLOUD_OBJECT_STORAGE.TableAction | None = Field(
        CLOUD_OBJECT_STORAGE.TableAction.append,
        alias="table_action",
        description=("The action to take on the target table to handle the new data set"),
    )
    table_data_file_compression_codec: CLOUD_OBJECT_STORAGE.TableDataFileCompressionCodec | None = Field(
        None, alias="table_data_file_compression_codec", description=("The compression codec of table data file")
    )
    table_data_file_format: CLOUD_OBJECT_STORAGE.TableDataFileFormat | None = Field(
        CLOUD_OBJECT_STORAGE.TableDataFileFormat.avro,
        alias="table_data_file_format",
        description=("The format of the table data file"),
    )
    table_format: CLOUD_OBJECT_STORAGE.TableFormat | None = Field(
        None, alias="table_format", description=("The format of the table")
    )
    table_name: str | None = Field(None, alias="table_name", description="The name of the table")
    table_namespace: str | None = Field(None, alias="table_namespace", description="The namespace of the table")
    the_cache_expiration: str | None = Field(
        None, alias="table_partition_cache_expiration", description=("The eviction time for partition writers")
    )
    the_cache_size: int | None = Field(
        None, alias="table_partition_cache_size", description=("The size of cache for partition writers")
    )
    the_data_path: str | None = Field(
        None, alias="table_data_path", description=("The start path for storing files with data")
    )
    the_partition_columns: str | None = Field(
        None, alias="table_partition_columns", description=("The columns for partitions")
    )
    the_partition_paths: str | None = Field(
        None, alias="table_partition_path", description=("The path for partitioned data")
    )
    time_format: str | None = Field(
        None, alias="time_format", description=("The format of time values, for example, HH:mm:ss[.f]")
    )
    timestamp_format: str | None = Field(
        None, alias="timestamp_format", description=("The format of timestamp values, for example, yyyy-MM-dd H:m:s")
    )
    timezone_format: str | None = Field(
        None,
        alias="time_zone_format",
        description=("The format of timezone values, for example, yyyy-MM-dd HH:mm:ss.SSS XXX"),
    )
    trust_all_ssl_certificates: bool | None = Field(
        False, alias="trust_all_ssl_cert", description=("Trust all SSL certificates")
    )
    type_mapping: str | None = Field(
        None,
        alias="type_mapping",
        description=(
            "Overrides the data types of specified columns in the file's inferred schema, for example, "
            "inferredType1:newType1;inferredType2:newType2"
        ),
    )
    unique: bool | None = Field(
        None,
        alias="part_unique",
        description=(
            "Select Unique to specify that, if multiple records have identical sorting key values, only one "
            "record is retained. If stable sort is also set, the first record is retained."
        ),
    )
    use_4_digit_years_in_date_formats: bool | None = Field(
        None,
        alias="use_4_digit_year",
        description=("Whether to use 4 digit years in all date formats. By default, 2 digit years will be used."),
    )
    use_field_formats: bool | None = Field(
        None, alias="use_field_formats", description=("Format data using specified field formats")
    )
    use_variable_formats: bool | None = Field(
        None, alias="use_variable_formats", description=("Format data using specified variable formats.")
    )
    worksheet_name: str | None = Field(
        None, alias="sheet_name", description=("The name of the Excel worksheet to write to")
    )
    write_mode: CLOUD_OBJECT_STORAGE.WriteMode | None = Field(
        CLOUD_OBJECT_STORAGE.WriteMode.write,
        alias="write_mode",
        description=("Whether to write to, or delete, the target"),
    )
    write_part_size: int | None = Field(
        None, alias="write_part_size", description=("The part size in MB at which a file gets split")
    )
    xml_path: str | None = Field(
        None,
        alias="xml_path",
        description=(
            "The path that identifies the root elements to retrieve from a XML document, for example, /book/publisher"
        ),
    )

    def _validate_parameters(self) -> tuple[set, set]:
        include = set()
        exclude = set()

        include.add("preserve_partitioning") if (self.output_count and self.output_count > 0) else exclude.add(
            "preserve_partitioning"
        )
        return include, exclude

    def _validate_source(self) -> tuple[set, set]:
        include = set()
        exclude = set()

        include.add("decimal_separator") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                        or (self.file_format == "avro")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                        or (self.file_format == "parquet")
                    )
                )
            )
            and (not self.output_as_json)
        ) else exclude.add("decimal_separator")
        include.add("infer_timestamp_as_date") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "sav") or (self.file_format == "sav")
            )
        ) else exclude.add("infer_timestamp_as_date")
        include.add("table_format") if (
            self.read_mode
            and (
                (hasattr(self.read_mode, "value") and self.read_mode.value == "read_single")
                or (self.read_mode == "read_single")
            )
        ) else exclude.add("table_format")
        include.add("xml_path") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "xml") or (self.file_format == "xml")
            )
        ) else exclude.add("xml_path")
        include.add("table_namespace") if (
            (
                self.table_format
                and (
                    (hasattr(self.table_format, "value") and self.table_format.value == "iceberg")
                    or (self.table_format == "iceberg")
                )
            )
            and (self.endpoint_folder)
        ) else exclude.add("table_namespace")
        include.add("first_line") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                    or (self.file_format == "excel")
                )
            )
        ) else exclude.add("first_line")
        include.add("null_value") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
        ) else exclude.add("null_value")
        include.add("endpoint_folder") if (
            (
                self.table_format
                and (
                    (hasattr(self.table_format, "value") and self.table_format.value == "deltalake")
                    or (self.table_format == "deltalake")
                )
            )
            or (
                self.table_format
                and (
                    (hasattr(self.table_format, "value") and self.table_format.value == "iceberg")
                    or (self.table_format == "iceberg")
                )
            )
        ) else exclude.add("endpoint_folder")
        include.add("cell_range") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                or (self.file_format == "excel")
            )
        ) else exclude.add("cell_range")
        include.add("first_line_is_header") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                    or (self.file_format == "excel")
                )
            )
        ) else exclude.add("first_line_is_header")
        include.add("table_name") if (self.endpoint_folder) else exclude.add("table_name")
        include.add("use_4_digit_years_in_date_formats") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                or (self.file_format == "excel")
            )
        ) else exclude.add("use_4_digit_years_in_date_formats")
        include.add("json_infer_record_count") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "json")
                or (self.file_format == "json")
            )
        ) else exclude.add("json_infer_record_count")
        include.add("store_shared_strings_in_the_temporary_file") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                or (self.file_format == "excel")
            )
        ) else exclude.add("store_shared_strings_in_the_temporary_file")
        include.add("quote_character") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
        ) else exclude.add("quote_character")
        include.add("infer_null_as_empty_string") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                    or (self.file_format == "excel")
                )
            )
        ) else exclude.add("infer_null_as_empty_string")
        include.add("escape_character") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
        ) else exclude.add("escape_character")
        include.add("invalid_data_handling") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
        ) else exclude.add("invalid_data_handling")
        include.add("display_value_labels") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "sav")
                    or (self.file_format == "sav")
                )
            )
            and (not self.exclude_missing_values)
        ) else exclude.add("display_value_labels")
        include.add("file_format") if (
            (
                (
                    self.read_mode
                    and (
                        (hasattr(self.read_mode, "value") and self.read_mode.value == "read_multiple_regex")
                        or (self.read_mode == "read_multiple_regex")
                    )
                )
                or (
                    self.read_mode
                    and (
                        (hasattr(self.read_mode, "value") and self.read_mode.value == "read_multiple_wildcard")
                        or (self.read_mode == "read_multiple_wildcard")
                    )
                )
                or (
                    self.read_mode
                    and (
                        (hasattr(self.read_mode, "value") and self.read_mode.value == "read_single")
                        or (self.read_mode == "read_single")
                    )
                )
            )
            and (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                        or (self.table_format != "deltalake")
                    )
                )
                and (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                        or (self.table_format != "iceberg")
                    )
                )
            )
        ) else exclude.add("file_format")
        include.add("escape_character_value") if (
            self.escape_character
            and (
                (hasattr(self.escape_character, "value") and self.escape_character.value == "<?>")
                or (self.escape_character == "<?>")
            )
        ) else exclude.add("escape_character_value")
        include.add("field_delimiter_value") if (
            self.field_delimiter
            and (
                (hasattr(self.field_delimiter, "value") and self.field_delimiter.value == "<?>")
                or (self.field_delimiter == "<?>")
            )
        ) else exclude.add("field_delimiter_value")
        include.add("row_delimiter") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                or (self.file_format == "delimited")
            )
        ) else exclude.add("row_delimiter")
        include.add("time_format") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                        or (self.file_format == "avro")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                        or (self.file_format == "parquet")
                    )
                )
            )
            and (not self.output_as_json)
        ) else exclude.add("time_format")
        include.add("fields_xml_path") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "xml")
                    or (self.file_format == "xml")
                )
            )
            and (self.xml_path)
        ) else exclude.add("fields_xml_path")
        include.add("use_field_formats") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "sav") or (self.file_format == "sav")
            )
        ) else exclude.add("use_field_formats")
        include.add("file_name") if (
            (
                self.table_format
                and (
                    (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                    or (self.table_format != "deltalake")
                )
            )
            and (
                self.table_format
                and (
                    (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                    or (self.table_format != "iceberg")
                )
            )
        ) else exclude.add("file_name")
        include.add("schema_of_xml") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "xml")
                    or (self.file_format == "xml")
                )
            )
            and (self.infer_schema)
        ) else exclude.add("schema_of_xml")
        include.add("json_path") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "json")
                or (self.file_format == "json")
            )
        ) else exclude.add("json_path")
        include.add("encoding") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "shp")
                    or (self.file_format == "shp")
                )
            )
        ) else exclude.add("encoding")
        include.add("field_delimiter") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                or (self.file_format == "delimited")
            )
        ) else exclude.add("field_delimiter")
        include.add("row_delimiter_value") if (
            self.row_delimiter
            and (
                (hasattr(self.row_delimiter, "value") and self.row_delimiter.value == "<?>")
                or (self.row_delimiter == "<?>")
            )
        ) else exclude.add("row_delimiter_value")
        include.add("use_variable_formats") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "sas")
                    or (self.file_format == "sas")
                )
            )
            and (not self.infer_schema)
        ) else exclude.add("use_variable_formats")
        include.add("timestamp_format") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                        or (self.file_format == "avro")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                        or (self.file_format == "parquet")
                    )
                )
            )
            and (not self.output_as_json)
        ) else exclude.add("timestamp_format")
        include.add("decimal_rounding_mode") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
        ) else exclude.add("decimal_rounding_mode")
        include.add("decimal_format") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                        or (self.file_format == "avro")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                        or (self.file_format == "parquet")
                    )
                )
            )
            and (not self.output_as_json)
        ) else exclude.add("decimal_format")
        include.add("infer_record_count") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                        or (self.file_format == "excel")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "json")
                        or (self.file_format == "json")
                    )
                )
            )
            and (self.infer_schema)
        ) else exclude.add("infer_record_count")
        include.add("labels_as_names") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "sav") or (self.file_format == "sav")
            )
        ) else exclude.add("labels_as_names")
        include.add("decimal_grouping_separator") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                        or (self.file_format == "avro")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                        or (self.file_format == "parquet")
                    )
                )
            )
            and (not self.output_as_json)
        ) else exclude.add("decimal_grouping_separator")
        include.add("exclude_missing_values") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "sav")
                    or (self.file_format == "sav")
                )
            )
            and (not self.display_value_labels)
        ) else exclude.add("exclude_missing_values")
        include.add("encryption_key") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "sav") or (self.file_format == "sav")
            )
        ) else exclude.add("encryption_key")
        include.add("date_format") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                        or (self.file_format == "avro")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                        or (self.file_format == "parquet")
                    )
                )
            )
            and (not self.output_as_json)
        ) else exclude.add("date_format")
        include.add("worksheet_name") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                or (self.file_format == "excel")
            )
        ) else exclude.add("worksheet_name")
        include.add("type_mapping") if (
            (
                (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                            or (self.file_format == "csv")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                            or (self.file_format == "delimited")
                        )
                    )
                )
                or (self.infer_schema)
            )
            and (self.infer_schema)
        ) else exclude.add("type_mapping")
        include.add("output_as_json") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                or (self.file_format == "avro")
            )
        ) else exclude.add("output_as_json")
        include.add("decimal_separator") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                        or (self.file_format == "avro")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                        or (self.file_format == "parquet")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and ((not self.output_as_json) or (self.output_as_json and "#" in str(self.output_as_json)))
        ) else exclude.add("decimal_separator")
        include.add("infer_timestamp_as_date") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "sav")
                    or (self.file_format == "sav")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("infer_timestamp_as_date")
        include.add("table_format") if (
            (
                self.read_mode
                and (
                    (hasattr(self.read_mode, "value") and self.read_mode.value == "read_single")
                    or (self.read_mode == "read_single")
                )
            )
            or (
                self.read_mode
                and (
                    (hasattr(self.read_mode, "value") and self.read_mode.value and "#" in str(self.read_mode.value))
                    or ("#" in str(self.read_mode))
                )
            )
        ) else exclude.add("table_format")
        include.add("xml_path") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "xml")
                    or (self.file_format == "xml")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("xml_path")
        include.add("table_namespace") if (
            (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value == "iceberg")
                        or (self.table_format == "iceberg")
                    )
                )
                or (
                    self.table_format
                    and (
                        (
                            hasattr(self.table_format, "value")
                            and self.table_format.value
                            and "#" in str(self.table_format.value)
                        )
                        or ("#" in str(self.table_format))
                    )
                )
            )
            and ((self.endpoint_folder) or (self.endpoint_folder and "#" in str(self.endpoint_folder)))
        ) else exclude.add("table_namespace")
        include.add("first_line") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                    or (self.file_format == "excel")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("first_line")
        include.add("null_value") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("null_value")
        include.add("endpoint_folder") if (
            (
                self.table_format
                and (
                    (hasattr(self.table_format, "value") and self.table_format.value == "deltalake")
                    or (self.table_format == "deltalake")
                )
            )
            or (
                self.table_format
                and (
                    (hasattr(self.table_format, "value") and self.table_format.value == "iceberg")
                    or (self.table_format == "iceberg")
                )
            )
            or (
                self.table_format
                and (
                    (
                        hasattr(self.table_format, "value")
                        and self.table_format.value
                        and "#" in str(self.table_format.value)
                    )
                    or ("#" in str(self.table_format))
                )
            )
        ) else exclude.add("endpoint_folder")
        include.add("cell_range") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                    or (self.file_format == "excel")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("cell_range")
        include.add("output_as_json") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                    or (self.file_format == "avro")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("output_as_json")
        include.add("first_line_is_header") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                    or (self.file_format == "excel")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("first_line_is_header")
        include.add("table_name") if (
            (self.endpoint_folder) or (self.endpoint_folder and "#" in str(self.endpoint_folder))
        ) else exclude.add("table_name")
        include.add("use_4_digit_years_in_date_formats") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                    or (self.file_format == "excel")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("use_4_digit_years_in_date_formats")
        include.add("json_infer_record_count") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "json")
                    or (self.file_format == "json")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("json_infer_record_count")
        include.add("store_shared_strings_in_the_temporary_file") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                    or (self.file_format == "excel")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("store_shared_strings_in_the_temporary_file")
        include.add("quote_character") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("quote_character")
        include.add("infer_null_as_empty_string") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                    or (self.file_format == "excel")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("infer_null_as_empty_string")
        include.add("escape_character") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("escape_character")
        include.add("invalid_data_handling") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("invalid_data_handling")
        include.add("display_value_labels") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "sav")
                        or (self.file_format == "sav")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (
                (not self.exclude_missing_values)
                or (self.exclude_missing_values and "#" in str(self.exclude_missing_values))
            )
        ) else exclude.add("display_value_labels")
        include.add("file_format") if (
            (
                (
                    self.read_mode
                    and (
                        (hasattr(self.read_mode, "value") and self.read_mode.value == "read_multiple_regex")
                        or (self.read_mode == "read_multiple_regex")
                    )
                )
                or (
                    self.read_mode
                    and (
                        (hasattr(self.read_mode, "value") and self.read_mode.value == "read_multiple_wildcard")
                        or (self.read_mode == "read_multiple_wildcard")
                    )
                )
                or (
                    self.read_mode
                    and (
                        (hasattr(self.read_mode, "value") and self.read_mode.value == "read_single")
                        or (self.read_mode == "read_single")
                    )
                )
                or (
                    self.read_mode
                    and (
                        (hasattr(self.read_mode, "value") and self.read_mode.value and "#" in str(self.read_mode.value))
                        or ("#" in str(self.read_mode))
                    )
                )
            )
            and (
                (
                    (
                        self.table_format
                        and (
                            (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                            or (self.table_format != "deltalake")
                        )
                    )
                    or (
                        self.table_format
                        and (
                            (
                                hasattr(self.table_format, "value")
                                and self.table_format.value
                                and "#" in str(self.table_format.value)
                            )
                            or ("#" in str(self.table_format))
                        )
                    )
                )
                and (
                    (
                        self.table_format
                        and (
                            (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                            or (self.table_format != "iceberg")
                        )
                    )
                    or (
                        self.table_format
                        and (
                            (
                                hasattr(self.table_format, "value")
                                and self.table_format.value
                                and "#" in str(self.table_format.value)
                            )
                            or ("#" in str(self.table_format))
                        )
                    )
                )
            )
        ) else exclude.add("file_format")
        include.add("escape_character_value") if (
            (
                self.escape_character
                and (
                    (hasattr(self.escape_character, "value") and self.escape_character.value == "<?>")
                    or (self.escape_character == "<?>")
                )
            )
            or (
                self.escape_character
                and (
                    (
                        hasattr(self.escape_character, "value")
                        and self.escape_character.value
                        and "#" in str(self.escape_character.value)
                    )
                    or ("#" in str(self.escape_character))
                )
            )
        ) else exclude.add("escape_character_value")
        include.add("field_delimiter_value") if (
            (
                self.field_delimiter
                and (
                    (hasattr(self.field_delimiter, "value") and self.field_delimiter.value == "<?>")
                    or (self.field_delimiter == "<?>")
                )
            )
            or (
                self.field_delimiter
                and (
                    (
                        hasattr(self.field_delimiter, "value")
                        and self.field_delimiter.value
                        and "#" in str(self.field_delimiter.value)
                    )
                    or ("#" in str(self.field_delimiter))
                )
            )
        ) else exclude.add("field_delimiter_value")
        include.add("row_delimiter") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("row_delimiter")
        include.add("time_format") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                        or (self.file_format == "avro")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                        or (self.file_format == "parquet")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and ((not self.output_as_json) or (self.output_as_json and "#" in str(self.output_as_json)))
        ) else exclude.add("time_format")
        include.add("fields_xml_path") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "xml")
                        or (self.file_format == "xml")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and ((self.xml_path) or (self.xml_path and "#" in str(self.xml_path)))
        ) else exclude.add("fields_xml_path")
        include.add("use_field_formats") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "sav")
                    or (self.file_format == "sav")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("use_field_formats")
        include.add("file_name") if (
            (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                        or (self.table_format != "deltalake")
                    )
                )
                or (
                    self.table_format
                    and (
                        (
                            hasattr(self.table_format, "value")
                            and self.table_format.value
                            and "#" in str(self.table_format.value)
                        )
                        or ("#" in str(self.table_format))
                    )
                )
            )
            and (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                        or (self.table_format != "iceberg")
                    )
                )
                or (
                    self.table_format
                    and (
                        (
                            hasattr(self.table_format, "value")
                            and self.table_format.value
                            and "#" in str(self.table_format.value)
                        )
                        or ("#" in str(self.table_format))
                    )
                )
            )
        ) else exclude.add("file_name")
        include.add("schema_of_xml") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "xml")
                        or (self.file_format == "xml")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and ((self.infer_schema) or (self.infer_schema and "#" in str(self.infer_schema)))
        ) else exclude.add("schema_of_xml")
        include.add("json_path") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "json")
                    or (self.file_format == "json")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("json_path")
        include.add("encoding") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "shp")
                    or (self.file_format == "shp")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("encoding")
        include.add("field_delimiter") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("field_delimiter")
        include.add("row_delimiter_value") if (
            (
                self.row_delimiter
                and (
                    (hasattr(self.row_delimiter, "value") and self.row_delimiter.value == "<?>")
                    or (self.row_delimiter == "<?>")
                )
            )
            or (
                self.row_delimiter
                and (
                    (
                        hasattr(self.row_delimiter, "value")
                        and self.row_delimiter.value
                        and "#" in str(self.row_delimiter.value)
                    )
                    or ("#" in str(self.row_delimiter))
                )
            )
        ) else exclude.add("row_delimiter_value")
        include.add("use_variable_formats") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "sas")
                        or (self.file_format == "sas")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and ((not self.infer_schema) or (self.infer_schema and "#" in str(self.infer_schema)))
        ) else exclude.add("use_variable_formats")
        include.add("timestamp_format") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                        or (self.file_format == "avro")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                        or (self.file_format == "parquet")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and ((not self.output_as_json) or (self.output_as_json and "#" in str(self.output_as_json)))
        ) else exclude.add("timestamp_format")
        include.add("decimal_rounding_mode") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("decimal_rounding_mode")
        include.add("decimal_format") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                        or (self.file_format == "avro")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                        or (self.file_format == "parquet")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and ((not self.output_as_json) or (self.output_as_json and "#" in str(self.output_as_json)))
        ) else exclude.add("decimal_format")
        include.add("infer_record_count") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                        or (self.file_format == "excel")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "json")
                        or (self.file_format == "json")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and ((self.infer_schema) or (self.infer_schema and "#" in str(self.infer_schema)))
        ) else exclude.add("infer_record_count")
        include.add("labels_as_names") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "sav")
                    or (self.file_format == "sav")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("labels_as_names")
        include.add("decimal_grouping_separator") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                        or (self.file_format == "avro")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                        or (self.file_format == "parquet")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and ((not self.output_as_json) or (self.output_as_json and "#" in str(self.output_as_json)))
        ) else exclude.add("decimal_grouping_separator")
        include.add("exclude_missing_values") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "sav")
                        or (self.file_format == "sav")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (
                (not self.display_value_labels) or (self.display_value_labels and "#" in str(self.display_value_labels))
            )
        ) else exclude.add("exclude_missing_values")
        include.add("encryption_key") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "sav")
                    or (self.file_format == "sav")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("encryption_key")
        include.add("date_format") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                        or (self.file_format == "avro")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                        or (self.file_format == "parquet")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and ((not self.output_as_json) or (self.output_as_json and "#" in str(self.output_as_json)))
        ) else exclude.add("date_format")
        include.add("worksheet_name") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                    or (self.file_format == "excel")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("worksheet_name")
        include.add("type_mapping") if (
            (
                (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                            or (self.file_format == "csv")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                            or (self.file_format == "delimited")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (
                                hasattr(self.file_format, "value")
                                and self.file_format.value
                                and "#" in str(self.file_format.value)
                            )
                            or ("#" in str(self.file_format))
                        )
                    )
                )
                or (self.infer_schema)
                or (self.infer_schema and "#" in str(self.infer_schema))
            )
            and ((self.infer_schema) or (self.infer_schema and "#" in str(self.infer_schema)))
        ) else exclude.add("type_mapping")

        include.add("infer_as_varchar") if (()) else exclude.add("infer_as_varchar")
        include.add("infer_schema") if (()) else exclude.add("infer_schema")
        include.add("maximum_memory_buffer_size_bytes") if (self.buffering_mode != "nobuffer") else exclude.add(
            "maximum_memory_buffer_size_bytes"
        )
        include.add("buffer_free_run_percent") if (self.buffering_mode != "nobuffer") else exclude.add(
            "buffer_free_run_percent"
        )
        include.add("queue_upper_bound_size_bytes") if (self.buffering_mode != "nobuffer") else exclude.add(
            "queue_upper_bound_size_bytes"
        )
        include.add("disk_write_increment_bytes") if (self.buffering_mode != "nobuffer") else exclude.add(
            "disk_write_increment_bytes"
        )
        include.add("runtime_column_propagation") if (not self.enable_schemaless_design) else exclude.add(
            "runtime_column_propagation"
        )
        include.add("column_metadata_change_propagation") if (not self.output_acp_should_hide) else exclude.add(
            "column_metadata_change_propagation"
        )
        include.add("max_mem_buf_size_ronly") if (self.buf_mode_ronly != "nobuffer") else exclude.add(
            "max_mem_buf_size_ronly"
        )
        include.add("buf_free_run_ronly") if (self.buf_mode_ronly != "nobuffer") else exclude.add("buf_free_run_ronly")
        include.add("queue_upper_size_ronly") if (self.buf_mode_ronly != "nobuffer") else exclude.add(
            "queue_upper_size_ronly"
        )
        include.add("disk_write_inc_ronly") if (self.buf_mode_ronly != "nobuffer") else exclude.add(
            "disk_write_inc_ronly"
        )
        include.add("stable") if (
            (self.show_part_type)
            and (self.partition_type != "auto")
            and (self.partition_type != "db2connector")
            and (self.show_sort_options)
        ) else exclude.add("stable")
        include.add("unique") if (
            (self.show_part_type)
            and (self.partition_type != "auto")
            and (self.partition_type != "db2connector")
            and (self.show_sort_options)
        ) else exclude.add("unique")
        include.add("key_cols_part") if (
            (
                (self.show_part_type)
                and (not self.show_coll_type)
                and (self.partition_type != "auto")
                and (self.partition_type != "db2connector")
                and (self.partition_type != "modulus")
            )
            or (
                (self.show_part_type)
                and (not self.show_coll_type)
                and (self.partition_type == "modulus")
                and (self.perform_sort_modulus)
            )
        ) else exclude.add("key_cols_part")
        include.add("db2_source_connection_required") if (
            (self.partition_type == "db2part") and (self.show_part_type)
        ) else exclude.add("db2_source_connection_required")
        include.add("db2_database_name") if (
            (self.partition_type == "db2part") and (self.show_part_type)
        ) else exclude.add("db2_database_name")
        include.add("db2_instance_name") if (
            (self.partition_type == "db2part") and (self.show_part_type)
        ) else exclude.add("db2_instance_name")
        include.add("db2_table_name") if (
            (self.partition_type == "db2part") and (self.show_part_type)
        ) else exclude.add("db2_table_name")
        include.add("perform_sort") if (
            (self.show_part_type) and ((self.partition_type == "hash") or (self.partition_type == "range"))
        ) else exclude.add("perform_sort")
        include.add("perform_sort_modulus") if (
            (self.show_part_type) and (self.partition_type == "modulus")
        ) else exclude.add("perform_sort_modulus")
        include.add("sorting_key") if (
            (self.show_part_type) and (self.partition_type == "modulus") and (not self.perform_sort_modulus)
        ) else exclude.add("sorting_key")
        include.add("sort_instructions") if (
            (self.show_part_type)
            and (
                (self.partition_type == "db2part")
                or (self.partition_type == "entire")
                or (self.partition_type == "random")
                or (self.partition_type == "roundrobin")
                or (self.partition_type == "same")
            )
        ) else exclude.add("sort_instructions")
        include.add("sort_instructions_text") if (
            (self.show_part_type)
            and (
                (self.partition_type == "db2part")
                or (self.partition_type == "entire")
                or (self.partition_type == "random")
                or (self.partition_type == "roundrobin")
                or (self.partition_type == "same")
            )
        ) else exclude.add("sort_instructions_text")
        include.add("collecting") if (self.show_coll_type) else exclude.add("collecting")
        include.add("partition_type") if (self.show_part_type) else exclude.add("partition_type")
        include.add("perform_sort_coll") if (
            (
                (self.show_coll_type)
                and (
                    (self.collecting == "ordered")
                    or (self.collecting == "roundrobin_coll")
                    or (self.collecting == "sortmerge")
                )
            )
            or ((not self.show_part_type) and (not self.show_coll_type))
        ) else exclude.add("perform_sort_coll")
        include.add("key_cols_coll") if (
            (self.show_coll_type)
            and (not self.show_part_type)
            and (self.collecting != "auto")
            and ((self.collecting == "sortmerge") or (self.perform_sort_coll))
        ) else exclude.add("key_cols_coll")
        include.add("key_cols_none") if (
            (not self.show_part_type) and (not self.show_coll_type) and (self.perform_sort_coll)
        ) else exclude.add("key_cols_none")
        include.add("part_stable_coll") if (
            (self.perform_sort_coll)
            and (
                (
                    (not self.show_part_type)
                    and (self.show_coll_type)
                    and (self.collecting != "auto")
                    and (self.show_sort_options)
                )
                or ((not self.show_part_type) and (not self.show_coll_type) and (self.show_sort_options))
            )
        ) else exclude.add("part_stable_coll")
        include.add("part_unique_coll") if (
            (self.perform_sort_coll)
            and (
                (
                    (not self.show_part_type)
                    and (self.show_coll_type)
                    and (self.collecting != "auto")
                    and (self.show_sort_options)
                )
                or ((not self.show_part_type) and (not self.show_coll_type) and (self.show_sort_options))
            )
        ) else exclude.add("part_unique_coll")
        include.add("trust_all_ssl_certificates") if (()) else exclude.add("trust_all_ssl_certificates")
        include.add("defer_credentials") if (()) else exclude.add("defer_credentials")
        include.add("type_mapping") if (
            (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "csv" in str(self.file_format.value)
                    )
                    or ("csv" in str(self.file_format))
                )
                or self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "delimited" in str(self.file_format.value)
                    )
                    or ("delimited" in str(self.file_format))
                )
            )
            or (self.infer_schema == "true" or self.infer_schema is True)
        ) and (self.infer_schema == "true" or self.infer_schema is True) else exclude.add("type_mapping")
        include.add("decimal_format") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "avro" in str(self.file_format.value)
                )
                or ("avro" in str(self.file_format))
            )
            and self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "parquet" in str(self.file_format.value)
                )
                or ("parquet" in str(self.file_format))
            )
        ) and (not self.output_as_json) else exclude.add("decimal_format")
        include.add("decimal_grouping_separator") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "avro" in str(self.file_format.value)
                )
                or ("avro" in str(self.file_format))
            )
            and self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "parquet" in str(self.file_format.value)
                )
                or ("parquet" in str(self.file_format))
            )
        ) and (not self.output_as_json) else exclude.add("decimal_grouping_separator")
        include.add("store_shared_strings_in_the_temporary_file") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "excel" in str(self.file_format.value)
                )
                or ("excel" in str(self.file_format))
            )
        ) else exclude.add("store_shared_strings_in_the_temporary_file")
        include.add("escape_character") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
        ) else exclude.add("escape_character")
        include.add("time_format") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "avro" in str(self.file_format.value)
                )
                or ("avro" in str(self.file_format))
            )
            and self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "parquet" in str(self.file_format.value)
                )
                or ("parquet" in str(self.file_format))
            )
        ) and (not self.output_as_json) else exclude.add("time_format")
        include.add("decimal_separator") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "avro" in str(self.file_format.value)
                )
                or ("avro" in str(self.file_format))
            )
            and self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "parquet" in str(self.file_format.value)
                )
                or ("parquet" in str(self.file_format))
            )
        ) and (not self.output_as_json) else exclude.add("decimal_separator")
        include.add("endpoint_folder") if (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "deltalake" in str(self.table_format.value)
                )
                or ("deltalake" in str(self.table_format))
            )
            or self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" in str(self.table_format.value)
                )
                or ("iceberg" in str(self.table_format))
            )
        ) else exclude.add("endpoint_folder")
        include.add("encryption_key") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "sav") or (self.file_format == "sav")
            )
        ) else exclude.add("encryption_key")
        include.add("first_line_is_header") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "excel" in str(self.file_format.value)
                )
                or ("excel" in str(self.file_format))
            )
        ) else exclude.add("first_line_is_header")
        include.add("json_path") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "json")
                or (self.file_format == "json")
            )
        ) else exclude.add("json_path")
        include.add("first_line") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "excel" in str(self.file_format.value)
                )
                or ("excel" in str(self.file_format))
            )
        ) else exclude.add("first_line")
        include.add("file_name") if (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "deltalake" not in str(self.table_format.value)
                )
                or ("deltalake" not in str(self.table_format))
            )
            or self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" not in str(self.table_format.value)
                )
                or ("iceberg" not in str(self.table_format))
            )
        ) else exclude.add("file_name")
        include.add("row_delimiter_value") if (
            self.row_delimiter
            and (
                (
                    hasattr(self.row_delimiter, "value")
                    and self.row_delimiter.value
                    and "<?>" in str(self.row_delimiter.value)
                )
                or ("<?>" in str(self.row_delimiter))
            )
        ) else exclude.add("row_delimiter_value")
        include.add("escape_character_value") if (
            self.escape_character
            and (
                (
                    hasattr(self.escape_character, "value")
                    and self.escape_character.value
                    and "<?>" in str(self.escape_character.value)
                )
                or ("<?>" in str(self.escape_character))
            )
        ) else exclude.add("escape_character_value")
        include.add("file_format") if (
            self.read_mode
            and (
                (
                    hasattr(self.read_mode, "value")
                    and self.read_mode.value
                    and "read_multiple_regex" in str(self.read_mode.value)
                )
                or ("read_multiple_regex" in str(self.read_mode))
            )
            or self.read_mode
            and (
                (
                    hasattr(self.read_mode, "value")
                    and self.read_mode.value
                    and "read_multiple_wildcard" in str(self.read_mode.value)
                )
                or ("read_multiple_wildcard" in str(self.read_mode))
            )
            or self.read_mode
            and (
                (
                    hasattr(self.read_mode, "value")
                    and self.read_mode.value
                    and "read_single" in str(self.read_mode.value)
                )
                or ("read_single" in str(self.read_mode))
            )
        ) and (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "deltalake" not in str(self.table_format.value)
                )
                or ("deltalake" not in str(self.table_format))
            )
            or self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" not in str(self.table_format.value)
                )
                or ("iceberg" not in str(self.table_format))
            )
        ) else exclude.add("file_format")
        include.add("date_format") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "avro" in str(self.file_format.value)
                )
                or ("avro" in str(self.file_format))
            )
            and self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "parquet" in str(self.file_format.value)
                )
                or ("parquet" in str(self.file_format))
            )
        ) and (not self.output_as_json) else exclude.add("date_format")
        include.add("table_format") if (
            self.read_mode
            and (
                (hasattr(self.read_mode, "value") and self.read_mode.value == "read_single")
                or (self.read_mode == "read_single")
            )
        ) else exclude.add("table_format")
        include.add("xml_path") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "xml") or (self.file_format == "xml")
            )
        ) else exclude.add("xml_path")
        include.add("fields_xml_path") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "xml") or (self.file_format == "xml")
            )
        ) and (self.xml_path) else exclude.add("fields_xml_path")
        include.add("labels_as_names") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "sav") or (self.file_format == "sav")
            )
        ) else exclude.add("labels_as_names")
        include.add("exclude_missing_values") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "sav") or (self.file_format == "sav")
            )
        ) and (self.display_value_labels != "true" or self.display_value_labels is not True) else exclude.add(
            "exclude_missing_values"
        )
        include.add("null_value") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
        ) else exclude.add("null_value")
        include.add("timestamp_format") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "avro" in str(self.file_format.value)
                )
                or ("avro" in str(self.file_format))
            )
            and self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "parquet" in str(self.file_format.value)
                )
                or ("parquet" in str(self.file_format))
            )
        ) and (not self.output_as_json) else exclude.add("timestamp_format")
        include.add("json_infer_record_count") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "json")
                or (self.file_format == "json")
            )
        ) else exclude.add("json_infer_record_count")
        include.add("worksheet_name") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                or (self.file_format == "excel")
            )
        ) else exclude.add("worksheet_name")
        include.add("infer_record_count") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "excel" in str(self.file_format.value)
                )
                or ("excel" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "json" in str(self.file_format.value)
                )
                or ("json" in str(self.file_format))
            )
        ) and (self.infer_schema == "true" or self.infer_schema is True) else exclude.add("infer_record_count")
        include.add("output_as_json") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                or (self.file_format == "avro")
            )
        ) else exclude.add("output_as_json")
        include.add("encoding") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            or self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "shp" in str(self.file_format.value))
                or ("shp" in str(self.file_format))
            )
        ) else exclude.add("encoding")
        include.add("use_variable_formats") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "sas") or (self.file_format == "sas")
            )
        ) and (self.infer_schema != "true" or self.infer_schema is not True) else exclude.add("use_variable_formats")
        include.add("infer_as_varchar") if (
            (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "csv" in str(self.file_format.value)
                    )
                    or ("csv" in str(self.file_format))
                )
                or self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "delimited" in str(self.file_format.value)
                    )
                    or ("delimited" in str(self.file_format))
                )
            )
            or (self.infer_schema == "true" or self.infer_schema is True)
            or (self.type_mapping == "false" or self.type_mapping is False)
        ) and (self.infer_schema == "true" or self.infer_schema is True) else exclude.add("infer_as_varchar")
        include.add("display_value_labels") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "sav") or (self.file_format == "sav")
            )
        ) and (self.exclude_missing_values != "true" or self.exclude_missing_values is not True) else exclude.add(
            "display_value_labels"
        )
        include.add("invalid_data_handling") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
        ) else exclude.add("invalid_data_handling")
        include.add("table_namespace") if (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" in str(self.table_format.value)
                )
                or ("iceberg" in str(self.table_format))
            )
        ) and (self.endpoint_folder) else exclude.add("table_namespace")
        include.add("infer_timestamp_as_date") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "sav") or (self.file_format == "sav")
            )
        ) else exclude.add("infer_timestamp_as_date")
        include.add("schema_of_xml") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "xml") or (self.file_format == "xml")
            )
        ) and (self.infer_schema == "true" or self.infer_schema is True) else exclude.add("schema_of_xml")
        include.add("cell_range") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                or (self.file_format == "excel")
            )
        ) else exclude.add("cell_range")
        include.add("table_name") if (self.endpoint_folder) else exclude.add("table_name")
        include.add("use_field_formats") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "sav") or (self.file_format == "sav")
            )
        ) else exclude.add("use_field_formats")
        include.add("field_delimiter") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
        ) else exclude.add("field_delimiter")
        include.add("decimal_rounding_mode") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
        ) else exclude.add("decimal_rounding_mode")
        include.add("use_4_digit_years_in_date_formats") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "excel" in str(self.file_format.value)
                )
                or ("excel" in str(self.file_format))
            )
        ) else exclude.add("use_4_digit_years_in_date_formats")
        include.add("field_delimiter_value") if (
            self.field_delimiter
            and (
                (
                    hasattr(self.field_delimiter, "value")
                    and self.field_delimiter.value
                    and "<?>" in str(self.field_delimiter.value)
                )
                or ("<?>" in str(self.field_delimiter))
            )
        ) else exclude.add("field_delimiter_value")
        include.add("row_delimiter") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
        ) else exclude.add("row_delimiter")
        include.add("quote_character") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
        ) else exclude.add("quote_character")
        include.add("infer_null_as_empty_string") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "excel" in str(self.file_format.value)
                )
                or ("excel" in str(self.file_format))
            )
        ) else exclude.add("infer_null_as_empty_string")
        return include, exclude

    def _validate_target(self) -> tuple[set, set]:
        include = set()
        exclude = set()

        include.add("decimal_separator") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                    or (self.file_format == "avro")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                    or (self.file_format == "parquet")
                )
            )
        ) else exclude.add("decimal_separator")
        include.add("table_format") if (
            self.write_mode
            and (
                (hasattr(self.write_mode, "value") and self.write_mode.value == "write") or (self.write_mode == "write")
            )
        ) else exclude.add("table_format")
        include.add("the_partition_columns") if (self.endpoint_folder) else exclude.add("the_partition_columns")
        include.add("partition_name_prefix") if (
            (
                self.table_format
                and (
                    (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                    or (self.table_format != "deltalake")
                )
            )
            and (
                self.table_format
                and (
                    (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                    or (self.table_format != "iceberg")
                )
            )
        ) else exclude.add("partition_name_prefix")
        include.add("codec_parquet") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                        or (self.file_format == "parquet")
                    )
                )
                or (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and not self.file_format.value)
                            or (not self.file_format)
                        )
                    )
                    and (re.match(r".*\.parquet$", self.file_name))
                )
            )
            and (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                        or (self.table_format != "deltalake")
                    )
                )
                and (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                        or (self.table_format != "iceberg")
                    )
                )
            )
        ) else exclude.add("codec_parquet")
        include.add("partitioned") if (
            (
                self.write_mode
                and (
                    (hasattr(self.write_mode, "value") and self.write_mode.value == "write")
                    or (self.write_mode == "write")
                )
            )
            and (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
            )
        ) else exclude.add("partitioned")
        include.add("the_data_path") if (
            self.table_format
            and (
                (hasattr(self.table_format, "value") and self.table_format.value == "iceberg")
                or (self.table_format == "iceberg")
            )
        ) else exclude.add("the_data_path")
        include.add("codec_avro") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                        or (self.file_format == "avro")
                    )
                )
                or (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and not self.file_format.value)
                            or (not self.file_format)
                        )
                    )
                    and (re.match(r".*\.avro$", self.file_name))
                )
            )
            and (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                        or (self.table_format != "deltalake")
                    )
                )
                and (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                        or (self.table_format != "iceberg")
                    )
                )
            )
        ) else exclude.add("codec_avro")
        include.add("file_size_threshold") if (self.append_unique_identifier) else exclude.add("file_size_threshold")
        include.add("quote_character") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                or (self.file_format == "delimited")
            )
        ) else exclude.add("quote_character")
        include.add("codec_delimited") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            and (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                        or (self.table_format != "deltalake")
                    )
                )
                and (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                        or (self.table_format != "iceberg")
                    )
                )
            )
        ) else exclude.add("codec_delimited")
        include.add("codec_csv") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "csv") or (self.file_format == "csv")
            )
        ) else exclude.add("codec_csv")
        include.add("escape_character") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                or (self.file_format == "delimited")
            )
        ) else exclude.add("escape_character")
        include.add("file_format") if (
            (
                self.write_mode
                and (
                    (hasattr(self.write_mode, "value") and self.write_mode.value == "write")
                    or (self.write_mode == "write")
                )
            )
            and (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                        or (self.table_format != "deltalake")
                    )
                )
                and (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                        or (self.table_format != "iceberg")
                    )
                )
            )
        ) else exclude.add("file_format")
        include.add("table_action") if (
            (
                self.table_format
                and (
                    (hasattr(self.table_format, "value") and self.table_format.value == "deltalake")
                    or (self.table_format == "deltalake")
                )
            )
            or (
                self.table_format
                and (
                    (hasattr(self.table_format, "value") and self.table_format.value == "iceberg")
                    or (self.table_format == "iceberg")
                )
            )
        ) else exclude.add("table_action")
        include.add("storage_class") if ((self.create_bucket) and (self.create_bucket)) else exclude.add(
            "storage_class"
        )
        include.add("time_format") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                    or (self.file_format == "avro")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                    or (self.file_format == "parquet")
                )
            )
        ) else exclude.add("time_format")
        include.add("delete_bucket") if (
            self.write_mode
            and (
                (hasattr(self.write_mode, "value") and self.write_mode.value == "delete")
                or (self.write_mode == "delete")
            )
        ) else exclude.add("delete_bucket")
        include.add("quote_numeric_values") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
        ) else exclude.add("quote_numeric_values")
        include.add("include_types") if (
            (self.first_line_is_header)
            and (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                        or (self.file_format == "excel")
                    )
                )
            )
        ) else exclude.add("include_types")
        include.add("append_unique_identifier") if (
            (
                self.write_mode
                and (
                    (hasattr(self.write_mode, "value") and self.write_mode.value == "write")
                    or (self.write_mode == "write")
                )
            )
            or (
                self.write_mode
                and (
                    (hasattr(self.write_mode, "value") and self.write_mode.value == "write_raw")
                    or (self.write_mode == "write_raw")
                )
            )
        ) else exclude.add("append_unique_identifier")
        include.add("encoding") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
        ) else exclude.add("encoding")
        include.add("table_data_file_compression_codec") if (
            (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value == "deltalake")
                        or (self.table_format == "deltalake")
                    )
                )
                or (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value == "iceberg")
                        or (self.table_format == "iceberg")
                    )
                )
            )
            and (
                self.table_data_file_format
                and (
                    (hasattr(self.table_data_file_format, "value") and self.table_data_file_format.value)
                    or (self.table_data_file_format)
                )
            )
            and (self.endpoint_folder)
            and (
                self.write_mode
                and (
                    (hasattr(self.write_mode, "value") and self.write_mode.value == "write")
                    or (self.write_mode == "write")
                )
            )
        ) else exclude.add("table_data_file_compression_codec")
        include.add("timestamp_format") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                    or (self.file_format == "avro")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                    or (self.file_format == "parquet")
                )
            )
        ) else exclude.add("timestamp_format")
        include.add("decimal_format") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                    or (self.file_format == "avro")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                    or (self.file_format == "parquet")
                )
            )
        ) else exclude.add("decimal_format")
        include.add("create_bucket") if (
            self.write_mode
            and (
                (hasattr(self.write_mode, "value") and self.write_mode.value != "delete")
                or (self.write_mode != "delete")
            )
        ) else exclude.add("create_bucket")
        include.add("codec_orc") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "orc")
                        or (self.file_format == "orc")
                    )
                )
                or (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and not self.file_format.value)
                            or (not self.file_format)
                        )
                    )
                    and (re.match(r".*\.orc$", self.file_name))
                )
            )
            and (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                        or (self.table_format != "deltalake")
                    )
                )
                and (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                        or (self.table_format != "iceberg")
                    )
                )
            )
        ) else exclude.add("codec_orc")
        include.add("names_as_labels") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "sav")
                        or (self.file_format == "sav")
                    )
                )
                or (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and not self.file_format.value)
                            or (not self.file_format)
                        )
                    )
                    and (re.match(r".*\.sav$", self.file_name))
                )
            )
            and (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                        or (self.table_format != "deltalake")
                    )
                )
                and (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                        or (self.table_format != "iceberg")
                    )
                )
            )
        ) else exclude.add("names_as_labels")
        include.add("decimal_grouping_separator") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                    or (self.file_format == "avro")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                    or (self.file_format == "parquet")
                )
            )
        ) else exclude.add("decimal_grouping_separator")
        include.add("encryption_key") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "sav")
                        or (self.file_format == "sav")
                    )
                )
                or (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and not self.file_format.value)
                            or (not self.file_format)
                        )
                    )
                    and (re.match(r".*\.sav$", self.file_name))
                )
            )
            and (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                        or (self.table_format != "deltalake")
                    )
                )
                and (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                        or (self.table_format != "iceberg")
                    )
                )
            )
        ) else exclude.add("encryption_key")
        include.add("date_format") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                    or (self.file_format == "avro")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                    or (self.file_format == "parquet")
                )
            )
        ) else exclude.add("date_format")
        include.add("table_data_file_format") if (
            (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value == "deltalake")
                        or (self.table_format == "deltalake")
                    )
                )
                or (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value == "iceberg")
                        or (self.table_format == "iceberg")
                    )
                )
            )
            and (self.endpoint_folder)
        ) else exclude.add("table_data_file_format")
        include.add("worksheet_name") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                    or (self.file_format == "excel")
                )
            )
            and (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                        or (self.table_format != "deltalake")
                    )
                )
                and (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                        or (self.table_format != "iceberg")
                    )
                )
            )
        ) else exclude.add("worksheet_name")
        include.add("decimal_separator") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                    or (self.file_format == "avro")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                    or (self.file_format == "parquet")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("decimal_separator")
        include.add("table_format") if (
            (
                self.write_mode
                and (
                    (hasattr(self.write_mode, "value") and self.write_mode.value == "write")
                    or (self.write_mode == "write")
                )
            )
            or (
                self.write_mode
                and (
                    (hasattr(self.write_mode, "value") and self.write_mode.value and "#" in str(self.write_mode.value))
                    or ("#" in str(self.write_mode))
                )
            )
        ) else exclude.add("table_format")
        include.add("the_partition_columns") if (
            (self.endpoint_folder) or (self.endpoint_folder and "#" in str(self.endpoint_folder))
        ) else exclude.add("the_partition_columns")
        include.add("partition_name_prefix") if (
            (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                        or (self.table_format != "deltalake")
                    )
                )
                or (
                    self.table_format
                    and (
                        (
                            hasattr(self.table_format, "value")
                            and self.table_format.value
                            and "#" in str(self.table_format.value)
                        )
                        or ("#" in str(self.table_format))
                    )
                )
            )
            and (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                        or (self.table_format != "iceberg")
                    )
                )
                or (
                    self.table_format
                    and (
                        (
                            hasattr(self.table_format, "value")
                            and self.table_format.value
                            and "#" in str(self.table_format.value)
                        )
                        or ("#" in str(self.table_format))
                    )
                )
            )
        ) else exclude.add("partition_name_prefix")
        include.add("codec_parquet") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                        or (self.file_format == "parquet")
                    )
                )
                or (
                    (
                        (
                            self.file_format
                            and (
                                (hasattr(self.file_format, "value") and not self.file_format.value)
                                or (not self.file_format)
                            )
                        )
                        or (
                            self.file_format
                            and (
                                (
                                    hasattr(self.file_format, "value")
                                    and self.file_format.value
                                    and "#" in str(self.file_format.value)
                                )
                                or ("#" in str(self.file_format))
                            )
                        )
                    )
                    and ((re.match(r".*\.parquet$", self.file_name)) or (self.file_name and "#" in str(self.file_name)))
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (
                (
                    (
                        self.table_format
                        and (
                            (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                            or (self.table_format != "deltalake")
                        )
                    )
                    or (
                        self.table_format
                        and (
                            (
                                hasattr(self.table_format, "value")
                                and self.table_format.value
                                and "#" in str(self.table_format.value)
                            )
                            or ("#" in str(self.table_format))
                        )
                    )
                )
                and (
                    (
                        self.table_format
                        and (
                            (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                            or (self.table_format != "iceberg")
                        )
                    )
                    or (
                        self.table_format
                        and (
                            (
                                hasattr(self.table_format, "value")
                                and self.table_format.value
                                and "#" in str(self.table_format.value)
                            )
                            or ("#" in str(self.table_format))
                        )
                    )
                )
            )
        ) else exclude.add("codec_parquet")
        include.add("partitioned") if (
            (
                (
                    self.write_mode
                    and (
                        (hasattr(self.write_mode, "value") and self.write_mode.value == "write")
                        or (self.write_mode == "write")
                    )
                )
                or (
                    self.write_mode
                    and (
                        (
                            hasattr(self.write_mode, "value")
                            and self.write_mode.value
                            and "#" in str(self.write_mode.value)
                        )
                        or ("#" in str(self.write_mode))
                    )
                )
            )
            and (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
        ) else exclude.add("partitioned")
        include.add("the_data_path") if (
            (
                self.table_format
                and (
                    (hasattr(self.table_format, "value") and self.table_format.value == "iceberg")
                    or (self.table_format == "iceberg")
                )
            )
            or (
                self.table_format
                and (
                    (
                        hasattr(self.table_format, "value")
                        and self.table_format.value
                        and "#" in str(self.table_format.value)
                    )
                    or ("#" in str(self.table_format))
                )
            )
        ) else exclude.add("the_data_path")
        include.add("codec_avro") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                        or (self.file_format == "avro")
                    )
                )
                or (
                    (
                        (
                            self.file_format
                            and (
                                (hasattr(self.file_format, "value") and not self.file_format.value)
                                or (not self.file_format)
                            )
                        )
                        or (
                            self.file_format
                            and (
                                (
                                    hasattr(self.file_format, "value")
                                    and self.file_format.value
                                    and "#" in str(self.file_format.value)
                                )
                                or ("#" in str(self.file_format))
                            )
                        )
                    )
                    and ((re.match(r".*\.avro$", self.file_name)) or (self.file_name and "#" in str(self.file_name)))
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (
                (
                    (
                        self.table_format
                        and (
                            (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                            or (self.table_format != "deltalake")
                        )
                    )
                    or (
                        self.table_format
                        and (
                            (
                                hasattr(self.table_format, "value")
                                and self.table_format.value
                                and "#" in str(self.table_format.value)
                            )
                            or ("#" in str(self.table_format))
                        )
                    )
                )
                and (
                    (
                        self.table_format
                        and (
                            (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                            or (self.table_format != "iceberg")
                        )
                    )
                    or (
                        self.table_format
                        and (
                            (
                                hasattr(self.table_format, "value")
                                and self.table_format.value
                                and "#" in str(self.table_format.value)
                            )
                            or ("#" in str(self.table_format))
                        )
                    )
                )
            )
        ) else exclude.add("codec_avro")
        include.add("file_size_threshold") if (
            (self.append_unique_identifier)
            or (self.append_unique_identifier and "#" in str(self.append_unique_identifier))
        ) else exclude.add("file_size_threshold")
        include.add("quote_character") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("quote_character")
        include.add("codec_delimited") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (
                (
                    (
                        self.table_format
                        and (
                            (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                            or (self.table_format != "deltalake")
                        )
                    )
                    or (
                        self.table_format
                        and (
                            (
                                hasattr(self.table_format, "value")
                                and self.table_format.value
                                and "#" in str(self.table_format.value)
                            )
                            or ("#" in str(self.table_format))
                        )
                    )
                )
                and (
                    (
                        self.table_format
                        and (
                            (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                            or (self.table_format != "iceberg")
                        )
                    )
                    or (
                        self.table_format
                        and (
                            (
                                hasattr(self.table_format, "value")
                                and self.table_format.value
                                and "#" in str(self.table_format.value)
                            )
                            or ("#" in str(self.table_format))
                        )
                    )
                )
            )
        ) else exclude.add("codec_delimited")
        include.add("codec_csv") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("codec_csv")
        include.add("escape_character") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("escape_character")
        include.add("file_format") if (
            (
                (
                    self.write_mode
                    and (
                        (hasattr(self.write_mode, "value") and self.write_mode.value == "write")
                        or (self.write_mode == "write")
                    )
                )
                or (
                    self.write_mode
                    and (
                        (
                            hasattr(self.write_mode, "value")
                            and self.write_mode.value
                            and "#" in str(self.write_mode.value)
                        )
                        or ("#" in str(self.write_mode))
                    )
                )
            )
            and (
                (
                    (
                        self.table_format
                        and (
                            (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                            or (self.table_format != "deltalake")
                        )
                    )
                    or (
                        self.table_format
                        and (
                            (
                                hasattr(self.table_format, "value")
                                and self.table_format.value
                                and "#" in str(self.table_format.value)
                            )
                            or ("#" in str(self.table_format))
                        )
                    )
                )
                and (
                    (
                        self.table_format
                        and (
                            (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                            or (self.table_format != "iceberg")
                        )
                    )
                    or (
                        self.table_format
                        and (
                            (
                                hasattr(self.table_format, "value")
                                and self.table_format.value
                                and "#" in str(self.table_format.value)
                            )
                            or ("#" in str(self.table_format))
                        )
                    )
                )
            )
        ) else exclude.add("file_format")
        include.add("table_action") if (
            (
                self.table_format
                and (
                    (hasattr(self.table_format, "value") and self.table_format.value == "deltalake")
                    or (self.table_format == "deltalake")
                )
            )
            or (
                self.table_format
                and (
                    (hasattr(self.table_format, "value") and self.table_format.value == "iceberg")
                    or (self.table_format == "iceberg")
                )
            )
            or (
                self.table_format
                and (
                    (
                        hasattr(self.table_format, "value")
                        and self.table_format.value
                        and "#" in str(self.table_format.value)
                    )
                    or ("#" in str(self.table_format))
                )
            )
        ) else exclude.add("table_action")
        include.add("storage_class") if (
            ((self.create_bucket) or (self.create_bucket and "#" in str(self.create_bucket)))
            and ((self.create_bucket) or (self.create_bucket and "#" in str(self.create_bucket)))
        ) else exclude.add("storage_class")
        include.add("time_format") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                    or (self.file_format == "avro")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                    or (self.file_format == "parquet")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("time_format")
        include.add("delete_bucket") if (
            (
                self.write_mode
                and (
                    (hasattr(self.write_mode, "value") and self.write_mode.value == "delete")
                    or (self.write_mode == "delete")
                )
            )
            or (
                self.write_mode
                and (
                    (hasattr(self.write_mode, "value") and self.write_mode.value and "#" in str(self.write_mode.value))
                    or ("#" in str(self.write_mode))
                )
            )
        ) else exclude.add("delete_bucket")
        include.add("quote_numeric_values") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("quote_numeric_values")
        include.add("include_types") if (
            ((self.first_line_is_header) or (self.first_line_is_header and "#" in str(self.first_line_is_header)))
            and (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                        or (self.file_format == "excel")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
        ) else exclude.add("include_types")
        include.add("append_unique_identifier") if (
            (
                self.write_mode
                and (
                    (hasattr(self.write_mode, "value") and self.write_mode.value == "write")
                    or (self.write_mode == "write")
                )
            )
            or (
                self.write_mode
                and (
                    (hasattr(self.write_mode, "value") and self.write_mode.value == "write_raw")
                    or (self.write_mode == "write_raw")
                )
            )
            or (
                self.write_mode
                and (
                    (hasattr(self.write_mode, "value") and self.write_mode.value and "#" in str(self.write_mode.value))
                    or ("#" in str(self.write_mode))
                )
            )
        ) else exclude.add("append_unique_identifier")
        include.add("encoding") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("encoding")
        include.add("table_data_file_compression_codec") if (
            (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value == "deltalake")
                        or (self.table_format == "deltalake")
                    )
                )
                or (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value == "iceberg")
                        or (self.table_format == "iceberg")
                    )
                )
                or (
                    self.table_format
                    and (
                        (
                            hasattr(self.table_format, "value")
                            and self.table_format.value
                            and "#" in str(self.table_format.value)
                        )
                        or ("#" in str(self.table_format))
                    )
                )
            )
            and (
                (
                    self.table_data_file_format
                    and (
                        (hasattr(self.table_data_file_format, "value") and self.table_data_file_format.value)
                        or (self.table_data_file_format)
                    )
                )
                or (
                    self.table_data_file_format
                    and (
                        (
                            hasattr(self.table_data_file_format, "value")
                            and self.table_data_file_format.value
                            and "#" in str(self.table_data_file_format.value)
                        )
                        or ("#" in str(self.table_data_file_format))
                    )
                )
            )
            and ((self.endpoint_folder) or (self.endpoint_folder and "#" in str(self.endpoint_folder)))
            and (
                (
                    self.write_mode
                    and (
                        (hasattr(self.write_mode, "value") and self.write_mode.value == "write")
                        or (self.write_mode == "write")
                    )
                )
                or (
                    self.write_mode
                    and (
                        (
                            hasattr(self.write_mode, "value")
                            and self.write_mode.value
                            and "#" in str(self.write_mode.value)
                        )
                        or ("#" in str(self.write_mode))
                    )
                )
            )
        ) else exclude.add("table_data_file_compression_codec")
        include.add("timestamp_format") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                    or (self.file_format == "avro")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                    or (self.file_format == "parquet")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("timestamp_format")
        include.add("decimal_format") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                    or (self.file_format == "avro")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                    or (self.file_format == "parquet")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("decimal_format")
        include.add("create_bucket") if (
            (
                self.write_mode
                and (
                    (hasattr(self.write_mode, "value") and self.write_mode.value != "delete")
                    or (self.write_mode != "delete")
                )
            )
            or (
                self.write_mode
                and (
                    (hasattr(self.write_mode, "value") and self.write_mode.value and "#" in str(self.write_mode.value))
                    or ("#" in str(self.write_mode))
                )
            )
        ) else exclude.add("create_bucket")
        include.add("codec_orc") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "orc")
                        or (self.file_format == "orc")
                    )
                )
                or (
                    (
                        (
                            self.file_format
                            and (
                                (hasattr(self.file_format, "value") and not self.file_format.value)
                                or (not self.file_format)
                            )
                        )
                        or (
                            self.file_format
                            and (
                                (
                                    hasattr(self.file_format, "value")
                                    and self.file_format.value
                                    and "#" in str(self.file_format.value)
                                )
                                or ("#" in str(self.file_format))
                            )
                        )
                    )
                    and ((re.match(r".*\.orc$", self.file_name)) or (self.file_name and "#" in str(self.file_name)))
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (
                (
                    (
                        self.table_format
                        and (
                            (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                            or (self.table_format != "deltalake")
                        )
                    )
                    or (
                        self.table_format
                        and (
                            (
                                hasattr(self.table_format, "value")
                                and self.table_format.value
                                and "#" in str(self.table_format.value)
                            )
                            or ("#" in str(self.table_format))
                        )
                    )
                )
                and (
                    (
                        self.table_format
                        and (
                            (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                            or (self.table_format != "iceberg")
                        )
                    )
                    or (
                        self.table_format
                        and (
                            (
                                hasattr(self.table_format, "value")
                                and self.table_format.value
                                and "#" in str(self.table_format.value)
                            )
                            or ("#" in str(self.table_format))
                        )
                    )
                )
            )
        ) else exclude.add("codec_orc")
        include.add("names_as_labels") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "sav")
                        or (self.file_format == "sav")
                    )
                )
                or (
                    (
                        (
                            self.file_format
                            and (
                                (hasattr(self.file_format, "value") and not self.file_format.value)
                                or (not self.file_format)
                            )
                        )
                        or (
                            self.file_format
                            and (
                                (
                                    hasattr(self.file_format, "value")
                                    and self.file_format.value
                                    and "#" in str(self.file_format.value)
                                )
                                or ("#" in str(self.file_format))
                            )
                        )
                    )
                    and ((re.match(r".*\.sav$", self.file_name)) or (self.file_name and "#" in str(self.file_name)))
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (
                (
                    (
                        self.table_format
                        and (
                            (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                            or (self.table_format != "deltalake")
                        )
                    )
                    or (
                        self.table_format
                        and (
                            (
                                hasattr(self.table_format, "value")
                                and self.table_format.value
                                and "#" in str(self.table_format.value)
                            )
                            or ("#" in str(self.table_format))
                        )
                    )
                )
                and (
                    (
                        self.table_format
                        and (
                            (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                            or (self.table_format != "iceberg")
                        )
                    )
                    or (
                        self.table_format
                        and (
                            (
                                hasattr(self.table_format, "value")
                                and self.table_format.value
                                and "#" in str(self.table_format.value)
                            )
                            or ("#" in str(self.table_format))
                        )
                    )
                )
            )
        ) else exclude.add("names_as_labels")
        include.add("decimal_grouping_separator") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                    or (self.file_format == "avro")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                    or (self.file_format == "parquet")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("decimal_grouping_separator")
        include.add("encryption_key") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "sav")
                        or (self.file_format == "sav")
                    )
                )
                or (
                    (
                        (
                            self.file_format
                            and (
                                (hasattr(self.file_format, "value") and not self.file_format.value)
                                or (not self.file_format)
                            )
                        )
                        or (
                            self.file_format
                            and (
                                (
                                    hasattr(self.file_format, "value")
                                    and self.file_format.value
                                    and "#" in str(self.file_format.value)
                                )
                                or ("#" in str(self.file_format))
                            )
                        )
                    )
                    and ((re.match(r".*\.sav$", self.file_name)) or (self.file_name and "#" in str(self.file_name)))
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (
                (
                    (
                        self.table_format
                        and (
                            (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                            or (self.table_format != "deltalake")
                        )
                    )
                    or (
                        self.table_format
                        and (
                            (
                                hasattr(self.table_format, "value")
                                and self.table_format.value
                                and "#" in str(self.table_format.value)
                            )
                            or ("#" in str(self.table_format))
                        )
                    )
                )
                and (
                    (
                        self.table_format
                        and (
                            (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                            or (self.table_format != "iceberg")
                        )
                    )
                    or (
                        self.table_format
                        and (
                            (
                                hasattr(self.table_format, "value")
                                and self.table_format.value
                                and "#" in str(self.table_format.value)
                            )
                            or ("#" in str(self.table_format))
                        )
                    )
                )
            )
        ) else exclude.add("encryption_key")
        include.add("date_format") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                    or (self.file_format == "avro")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                    or (self.file_format == "parquet")
                )
            )
            or (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "#" in str(self.file_format.value)
                    )
                    or ("#" in str(self.file_format))
                )
            )
        ) else exclude.add("date_format")
        include.add("table_data_file_format") if (
            (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value == "deltalake")
                        or (self.table_format == "deltalake")
                    )
                )
                or (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value == "iceberg")
                        or (self.table_format == "iceberg")
                    )
                )
                or (
                    self.table_format
                    and (
                        (
                            hasattr(self.table_format, "value")
                            and self.table_format.value
                            and "#" in str(self.table_format.value)
                        )
                        or ("#" in str(self.table_format))
                    )
                )
            )
            and ((self.endpoint_folder) or (self.endpoint_folder and "#" in str(self.endpoint_folder)))
        ) else exclude.add("table_data_file_format")
        include.add("worksheet_name") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                        or (self.file_format == "excel")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (
                (
                    (
                        self.table_format
                        and (
                            (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                            or (self.table_format != "deltalake")
                        )
                    )
                    or (
                        self.table_format
                        and (
                            (
                                hasattr(self.table_format, "value")
                                and self.table_format.value
                                and "#" in str(self.table_format.value)
                            )
                            or ("#" in str(self.table_format))
                        )
                    )
                )
                and (
                    (
                        self.table_format
                        and (
                            (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                            or (self.table_format != "iceberg")
                        )
                    )
                    or (
                        self.table_format
                        and (
                            (
                                hasattr(self.table_format, "value")
                                and self.table_format.value
                                and "#" in str(self.table_format.value)
                            )
                            or ("#" in str(self.table_format))
                        )
                    )
                )
            )
        ) else exclude.add("worksheet_name")
        include.add("data_asset_name") if (self.create_data_asset) else exclude.add("data_asset_name")
        include.add("create_data_asset") if (()) else exclude.add("create_data_asset")
        include.add("decimal_format") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "avro" in str(self.file_format.value)
                )
                or ("avro" in str(self.file_format))
            )
            or self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "parquet" in str(self.file_format.value)
                )
                or ("parquet" in str(self.file_format))
            )
        ) else exclude.add("decimal_format")
        include.add("decimal_grouping_separator") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "avro" in str(self.file_format.value)
                )
                or ("avro" in str(self.file_format))
            )
            or self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "parquet" in str(self.file_format.value)
                )
                or ("parquet" in str(self.file_format))
            )
        ) else exclude.add("decimal_grouping_separator")
        include.add("delete_bucket") if (
            self.write_mode
            and (
                (hasattr(self.write_mode, "value") and self.write_mode.value == "delete")
                or (self.write_mode == "delete")
            )
        ) else exclude.add("delete_bucket")
        include.add("table_data_file_format") if (
            self.table_format
            and (
                (hasattr(self.table_format, "value") and self.table_format.value == "iceberg")
                or (self.table_format == "iceberg")
            )
        ) else exclude.add("table_data_file_format")
        include.add("escape_character") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
        ) else exclude.add("escape_character")
        include.add("time_format") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "avro" in str(self.file_format.value)
                )
                or ("avro" in str(self.file_format))
            )
            or self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "parquet" in str(self.file_format.value)
                )
                or ("parquet" in str(self.file_format))
            )
        ) else exclude.add("time_format")
        include.add("table_data_file_compression_codec") if (
            self.table_data_file_format
            and (
                (hasattr(self.table_data_file_format, "value") and self.table_data_file_format.value == "parquet")
                or (self.table_data_file_format == "parquet")
            )
        ) else exclude.add("table_data_file_compression_codec")
        include.add("include_types") if (self.first_line_is_header == "yes") and (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "excel" in str(self.file_format.value)
                )
                or ("excel" in str(self.file_format))
            )
        ) else exclude.add("include_types")
        include.add("decimal_separator") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "avro" in str(self.file_format.value)
                )
                or ("avro" in str(self.file_format))
            )
            or self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "parquet" in str(self.file_format.value)
                )
                or ("parquet" in str(self.file_format))
            )
        ) else exclude.add("decimal_separator")
        include.add("encryption_key") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "sav")
                    or (self.file_format == "sav")
                )
            )
            or (
                (
                    self.file_format
                    and ((hasattr(self.file_format, "value") and not self.file_format.value) or (not self.file_format))
                )
                and (re.match(r".*\.sav$", self.file_name))
            )
        ) and (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "deltalake" not in str(self.table_format.value)
                )
                or ("deltalake" not in str(self.table_format))
            )
            or self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" not in str(self.table_format.value)
                )
                or ("iceberg" not in str(self.table_format))
            )
        ) else exclude.add("encryption_key")
        include.add("table_data_file_compression_codec") if (
            self.table_data_file_format
            and (
                (hasattr(self.table_data_file_format, "value") and self.table_data_file_format.value == "avro")
                or (self.table_data_file_format == "avro")
            )
        ) else exclude.add("table_data_file_compression_codec")
        include.add("the_data_path") if (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" in str(self.table_format.value)
                )
                or ("iceberg" in str(self.table_format))
            )
        ) else exclude.add("the_data_path")
        include.add("the_partition_columns") if (self.endpoint_folder) else exclude.add("the_partition_columns")
        include.add("quote_numeric_values") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
        ) else exclude.add("quote_numeric_values")
        include.add("names_as_labels") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "sav")
                    or (self.file_format == "sav")
                )
            )
            or (
                (
                    self.file_format
                    and ((hasattr(self.file_format, "value") and not self.file_format.value) or (not self.file_format))
                )
                and (re.match(r".*\.sav$", self.file_name))
            )
        ) and (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "deltalake" not in str(self.table_format.value)
                )
                or ("deltalake" not in str(self.table_format))
            )
            or self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" not in str(self.table_format.value)
                )
                or ("iceberg" not in str(self.table_format))
            )
        ) else exclude.add("names_as_labels")
        include.add("codec_orc") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "orc")
                    or (self.file_format == "orc")
                )
            )
            or (
                (
                    self.file_format
                    and ((hasattr(self.file_format, "value") and not self.file_format.value) or (not self.file_format))
                )
                and (re.match(r".*\.orc$", self.file_name))
            )
        ) and (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "deltalake" not in str(self.table_format.value)
                )
                or ("deltalake" not in str(self.table_format))
            )
            or self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" not in str(self.table_format.value)
                )
                or ("iceberg" not in str(self.table_format))
            )
        ) else exclude.add("codec_orc")
        include.add("file_format") if (
            self.write_mode
            and (
                (hasattr(self.write_mode, "value") and self.write_mode.value == "write") or (self.write_mode == "write")
            )
        ) and (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "deltalake" not in str(self.table_format.value)
                )
                or ("deltalake" not in str(self.table_format))
            )
            or self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" not in str(self.table_format.value)
                )
                or ("iceberg" not in str(self.table_format))
            )
        ) else exclude.add("file_format")
        include.add("partitioned") if (
            self.write_mode
            and (
                (hasattr(self.write_mode, "value") and self.write_mode.value == "write") or (self.write_mode == "write")
            )
        ) and (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
        ) else exclude.add("partitioned")
        include.add("date_format") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "avro" in str(self.file_format.value)
                )
                or ("avro" in str(self.file_format))
            )
            or self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "parquet" in str(self.file_format.value)
                )
                or ("parquet" in str(self.file_format))
            )
        ) else exclude.add("date_format")
        include.add("table_data_file_format") if (
            self.table_format
            and (
                (hasattr(self.table_format, "value") and self.table_format.value == "deltalake")
                or (self.table_format == "deltalake")
            )
        ) else exclude.add("table_data_file_format")
        include.add("storage_class") if (self.create_bucket) and (self.create_bucket is True) else exclude.add(
            "storage_class"
        )
        include.add("table_format") if (
            self.write_mode
            and (
                (hasattr(self.write_mode, "value") and self.write_mode.value == "write") or (self.write_mode == "write")
            )
        ) else exclude.add("table_format")
        include.add("table_action") if (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "deltalake" in str(self.table_format.value)
                )
                or ("deltalake" in str(self.table_format))
            )
            or self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" in str(self.table_format.value)
                )
                or ("iceberg" in str(self.table_format))
            )
        ) else exclude.add("table_action")
        include.add("timestamp_format") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "avro" in str(self.file_format.value)
                )
                or ("avro" in str(self.file_format))
            )
            or self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "parquet" in str(self.file_format.value)
                )
                or ("parquet" in str(self.file_format))
            )
        ) else exclude.add("timestamp_format")
        include.add("codec_parquet") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                    or (self.file_format == "parquet")
                )
            )
            or (
                (
                    self.file_format
                    and ((hasattr(self.file_format, "value") and not self.file_format.value) or (not self.file_format))
                )
                and (re.match(r".*\.parquet$", self.file_name))
            )
        ) and (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "deltalake" not in str(self.table_format.value)
                )
                or ("deltalake" not in str(self.table_format))
            )
            or self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" not in str(self.table_format.value)
                )
                or ("iceberg" not in str(self.table_format))
            )
        ) else exclude.add("codec_parquet")
        include.add("append_unique_identifier") if (
            self.write_mode
            and (
                (hasattr(self.write_mode, "value") and self.write_mode.value and "write" in str(self.write_mode.value))
                or ("write" in str(self.write_mode))
            )
            or self.write_mode
            and (
                (
                    hasattr(self.write_mode, "value")
                    and self.write_mode.value
                    and "write_raw" in str(self.write_mode.value)
                )
                or ("write_raw" in str(self.write_mode))
            )
        ) else exclude.add("append_unique_identifier")
        include.add("table_data_file_format") if (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "deltalake" in str(self.table_format.value)
                )
                or ("deltalake" in str(self.table_format))
            )
            and self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" in str(self.table_format.value)
                )
                or ("iceberg" in str(self.table_format))
            )
        ) and (self.endpoint_folder) else exclude.add("table_data_file_format")
        include.add("worksheet_name") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                or (self.file_format == "excel")
            )
        ) and (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "deltalake" not in str(self.table_format.value)
                )
                or ("deltalake" not in str(self.table_format))
            )
            or self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" not in str(self.table_format.value)
                )
                or ("iceberg" not in str(self.table_format))
            )
        ) else exclude.add("worksheet_name")
        include.add("file_size_threshold") if (
            self.append_unique_identifier == "true" or self.append_unique_identifier is True
        ) else exclude.add("file_size_threshold")
        include.add("codec_avro") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                    or (self.file_format == "avro")
                )
            )
            or (
                (
                    self.file_format
                    and ((hasattr(self.file_format, "value") and not self.file_format.value) or (not self.file_format))
                )
                and (re.match(r".*\.avro$", self.file_name))
            )
        ) and (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "deltalake" not in str(self.table_format.value)
                )
                or ("deltalake" not in str(self.table_format))
            )
            or self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" not in str(self.table_format.value)
                )
                or ("iceberg" not in str(self.table_format))
            )
        ) else exclude.add("codec_avro")
        include.add("encoding") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
        ) else exclude.add("encoding")
        include.add("table_data_file_compression_codec") if (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "deltalake" in str(self.table_format.value)
                )
                or ("deltalake" in str(self.table_format))
            )
            and self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" in str(self.table_format.value)
                )
                or ("iceberg" in str(self.table_format))
            )
        ) and (
            self.table_data_file_format
            and (
                (hasattr(self.table_data_file_format, "value") and self.table_data_file_format.value)
                or (self.table_data_file_format)
            )
        ) and (self.endpoint_folder) and (
            self.write_mode
            and (
                (hasattr(self.write_mode, "value") and self.write_mode.value == "write") or (self.write_mode == "write")
            )
        ) else exclude.add("table_data_file_compression_codec")
        include.add("partition_name_prefix") if (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "deltalake" not in str(self.table_format.value)
                )
                or ("deltalake" not in str(self.table_format))
            )
            or self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" not in str(self.table_format.value)
                )
                or ("iceberg" not in str(self.table_format))
            )
        ) else exclude.add("partition_name_prefix")
        include.add("codec_csv") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "csv") or (self.file_format == "csv")
            )
        ) else exclude.add("codec_csv")
        include.add("create_bucket") if (
            self.write_mode
            and (
                (hasattr(self.write_mode, "value") and self.write_mode.value != "delete")
                or (self.write_mode != "delete")
            )
        ) else exclude.add("create_bucket")
        include.add("table_data_file_compression_codec") if (
            self.table_data_file_format
            and (
                (hasattr(self.table_data_file_format, "value") and self.table_data_file_format.value == "orc")
                or (self.table_data_file_format == "orc")
            )
        ) else exclude.add("table_data_file_compression_codec")
        include.add("codec_delimited") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                or (self.file_format == "delimited")
            )
        ) and (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "deltalake" not in str(self.table_format.value)
                )
                or ("deltalake" not in str(self.table_format))
            )
            or self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" not in str(self.table_format.value)
                )
                or ("iceberg" not in str(self.table_format))
            )
        ) else exclude.add("codec_delimited")
        include.add("quote_character") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
        ) else exclude.add("quote_character")
        return include, exclude

    def _get_source_props(self) -> dict:
        include, exclude = self._validate_source()
        props = {
            "bucket",
            "buf_free_run_ronly",
            "buf_mode_ronly",
            "buffer_free_run_percent",
            "buffering_mode",
            "byte_limit",
            "cell_range",
            "collecting",
            "column_metadata_change_propagation",
            "combinability_mode",
            "current_output_link_type",
            "date_format",
            "db2_database_name",
            "db2_instance_name",
            "db2_source_connection_required",
            "db2_table_name",
            "decimal_format",
            "decimal_grouping_separator",
            "decimal_rounding_mode",
            "decimal_separator",
            "default_maximum_length_for_columns",
            "disk_write_inc_ronly",
            "disk_write_increment_bytes",
            "display_value_labels",
            "ds_java_heap_size",
            "enable_flow_acp_control",
            "enable_schemaless_design",
            "encoding",
            "encryption_key",
            "endpoint_folder",
            "escape_character",
            "escape_character_value",
            "exclude_missing_values",
            "execution_mode",
            "field_delimiter",
            "field_delimiter_value",
            "fields_xml_path",
            "file_format",
            "file_name",
            "first_line",
            "first_line_is_header",
            "flow_dirty",
            "generate_unicode_type_columns",
            "hide",
            "infer_as_varchar",
            "infer_null_as_empty_string",
            "infer_record_count",
            "infer_schema",
            "infer_timestamp_as_date",
            "input_count",
            "input_link_description",
            "inputcol_properties",
            "invalid_data_handling",
            "json_infer_record_count",
            "json_path",
            "key_cols_coll",
            "key_cols_coll_ordered",
            "key_cols_coll_robin",
            "key_cols_none",
            "key_cols_part",
            "labels_as_names",
            "max_mem_buf_size_ronly",
            "maximum_memory_buffer_size_bytes",
            "node_count",
            "node_number",
            "null_value",
            "output_acp_should_hide",
            "output_as_json",
            "output_count",
            "output_link_description",
            "outputcol_properties",
            "part_stable_coll",
            "part_stable_ordered",
            "part_stable_roundrobin_coll",
            "part_unique_coll",
            "part_unique_ordered",
            "part_unique_roundrobin_coll",
            "partition_name_prefix",
            "partition_type",
            "perform_sort",
            "perform_sort_coll",
            "perform_sort_modulus",
            "preserve_partitioning",
            "queue_upper_bound_size_bytes",
            "queue_upper_size_ronly",
            "quote_character",
            "read_mode",
            "read_part_size",
            "row_delimiter",
            "row_delimiter_value",
            "row_limit",
            "row_start",
            "runtime_column_propagation",
            "schema_of_xml",
            "show_coll_type",
            "show_part_type",
            "show_sort_options",
            "sort_instructions",
            "sort_instructions_text",
            "sorting_key",
            "stable",
            "stage_description",
            "store_shared_strings_in_the_temporary_file",
            "table_format",
            "table_name",
            "table_namespace",
            "time_format",
            "timestamp_format",
            "timezone_format",
            "type_mapping",
            "unique",
            "use_4_digit_years_in_date_formats",
            "use_field_formats",
            "use_variable_formats",
            "worksheet_name",
            "xml_path",
        }
        required = {
            "access_key",
            "api_key",
            "authentication_method",
            "credentials_file_path",
            "current_output_link_type",
            "enable_flow_acp_control",
            "enable_schemaless_design",
            "escape_character_value",
            "field_delimiter_value",
            "output_acp_should_hide",
            "resource_instance_id",
            "row_delimiter_value",
            "secret_key",
            "service_credentials",
            "url",
        }
        props = props & (self.model_fields_set | required)
        conflict = exclude & self.model_fields_set & props
        if conflict:
            conflict = list(conflict)
            if len(conflict) == 1:
                warnings.warn(f"\n\033[33mFound conflicting property {conflict[0]}\033[0m")
            else:
                warnings.warn(
                    f"\n\033[33mFound conflicting properties{', '.join(conflict[:-1])} and {conflict[-1]}\033[0m"
                )
        exclude = exclude - self.model_fields_set
        return self.model_dump(include=props - exclude, by_alias=True, exclude_none=True, warnings=False)

    def _get_target_props(self) -> dict:
        include, exclude = self._validate_target()
        props = {
            "append_unique_identifier",
            "bucket",
            "buf_free_run_ronly",
            "buf_mode_ronly",
            "buffer_free_run_percent",
            "buffering_mode",
            "codec_avro",
            "codec_csv",
            "codec_delimited",
            "codec_orc",
            "codec_parquet",
            "collecting",
            "column_metadata_change_propagation",
            "combinability_mode",
            "create_bucket",
            "create_data_asset",
            "current_output_link_type",
            "data_asset_name",
            "date_format",
            "db2_database_name",
            "db2_instance_name",
            "db2_source_connection_required",
            "db2_table_name",
            "decimal_format",
            "decimal_grouping_separator",
            "decimal_separator",
            "delete_bucket",
            "disk_write_inc_ronly",
            "disk_write_increment_bytes",
            "ds_java_heap_size",
            "enable_flow_acp_control",
            "enable_schemaless_design",
            "encoding",
            "encryption_key",
            "endpoint_folder",
            "escape_character",
            "escape_character_value",
            "execution_mode",
            "field_delimiter",
            "field_delimiter_value",
            "file_format",
            "file_name",
            "file_size_threshold",
            "first_line_is_header",
            "flow_dirty",
            "hide",
            "include_types",
            "input_count",
            "input_link_description",
            "inputcol_properties",
            "key_cols_coll",
            "key_cols_coll_ordered",
            "key_cols_coll_robin",
            "key_cols_none",
            "key_cols_part",
            "max_mem_buf_size_ronly",
            "maximum_memory_buffer_size_bytes",
            "names_as_labels",
            "node_count",
            "node_number",
            "null_value",
            "output_acp_should_hide",
            "output_count",
            "output_link_description",
            "outputcol_properties",
            "part_stable_coll",
            "part_stable_ordered",
            "part_stable_roundrobin_coll",
            "part_unique_coll",
            "part_unique_ordered",
            "part_unique_roundrobin_coll",
            "partition_name_prefix",
            "partition_type",
            "partitioned",
            "perform_sort",
            "perform_sort_coll",
            "perform_sort_modulus",
            "preserve_partitioning",
            "queue_upper_bound_size_bytes",
            "queue_upper_size_ronly",
            "quote_character",
            "quote_numeric_values",
            "row_delimiter",
            "row_delimiter_value",
            "runtime_column_propagation",
            "show_coll_type",
            "show_part_type",
            "show_sort_options",
            "sort_instructions",
            "sort_instructions_text",
            "sorting_key",
            "stable",
            "stage_description",
            "storage_class",
            "table_action",
            "table_data_file_compression_codec",
            "table_data_file_format",
            "table_format",
            "table_name",
            "table_namespace",
            "the_cache_expiration",
            "the_cache_size",
            "the_data_path",
            "the_partition_columns",
            "the_partition_paths",
            "time_format",
            "timestamp_format",
            "timezone_format",
            "unique",
            "worksheet_name",
            "write_mode",
            "write_part_size",
        }
        required = {
            "access_key",
            "api_key",
            "authentication_method",
            "credentials_file_path",
            "current_output_link_type",
            "data_asset_name",
            "enable_flow_acp_control",
            "enable_schemaless_design",
            "escape_character_value",
            "field_delimiter_value",
            "output_acp_should_hide",
            "resource_instance_id",
            "row_delimiter_value",
            "secret_key",
            "service_credentials",
            "url",
        }
        props = props & (self.model_fields_set | required)
        conflict = exclude & self.model_fields_set & props
        if conflict:
            conflict = list(conflict)
            if len(conflict) == 1:
                warnings.warn(f"\n\033[33mFound conflicting property {conflict[0]}\033[0m")
            else:
                warnings.warn(
                    f"\n\033[33mFound conflicting properties{', '.join(conflict[:-1])} and {conflict[-1]}\033[0m"
                )
        exclude = exclude - self.model_fields_set
        return self.model_dump(include=props - exclude, by_alias=True, exclude_none=True, warnings=False)

    def _get_parameters_props(self) -> dict:
        include, exclude = self._validate_parameters()
        props = {"execution_mode", "input_count", "output_count", "preserve_partitioning"}
        required = set()
        props = props & (self.model_fields_set | required)
        conflict = exclude & self.model_fields_set & props
        if conflict:
            conflict = list(conflict)
            if len(conflict) == 1:
                warnings.warn(f"\n\033[33mFound conflicting property {conflict[0]}\033[0m")
            else:
                warnings.warn(
                    f"\n\033[33mFound conflicting properties{', '.join(conflict[:-1])} and {conflict[-1]}\033[0m"
                )
        exclude = exclude - self.model_fields_set
        return self.model_dump(include=props - exclude, by_alias=True, exclude_none=True, warnings=False)

    def _get_app_data_props(self) -> dict:
        return {
            "datastage": {
                "active": 0,
                "SupportsRef": True,
                "maxRejectOutputs": 0,
                "minRejectOutputs": 0,
                "maxReferenceInputs": 0,
                "minReferenceInputs": 0,
            }
        }

    def _get_input_ports_props(self) -> dict:
        include, exclude = self._validate_target()
        props = {"runtime_column_propagation"}
        required = set()
        props = props & (self.model_fields_set | required)
        conflict = exclude & self.model_fields_set & props
        if conflict:
            conflict = list(conflict)
            if len(conflict) == 1:
                warnings.warn(f"\n\033[33mFound conflicting property: {conflict[0]}\033[0m")
            else:
                warnings.warn(
                    f"\n\033[33mFound conflicting properties: {', '.join(conflict[:-1])} and {conflict[-1]}\033[0m"
                )
        exclude = exclude - self.model_fields_set
        return self.model_dump(include=props - exclude, by_alias=True, exclude_none=True, warnings=False)

    def _get_input_cardinality(self) -> dict:
        return {"min": 0, "max": 1}

    def _get_output_ports_props(self) -> dict:
        include, exclude = self._validate_source()
        props = set()
        required = set()
        props = props & (self.model_fields_set | required)
        conflict = exclude & self.model_fields_set & props
        if conflict:
            conflict = list(conflict)
            if len(conflict) == 1:
                warnings.warn(f"\n\033[33mFound conflicting property: {conflict[0]}\033[0m")
            else:
                warnings.warn(
                    f"\n\033[33mFound conflicting properties: {', '.join(conflict[:-1])} and {conflict[-1]}\033[0m"
                )
        exclude = exclude - self.model_fields_set
        return self.model_dump(include=props - exclude, by_alias=True, exclude_none=True, warnings=False)

    def _get_output_cardinality(self) -> dict:
        return {"min": 0, "max": 1}

    def _get_allowed_as_source_props(self) -> bool:
        return True

    def _get_allowed_as_target_props(self) -> bool:
        return True
