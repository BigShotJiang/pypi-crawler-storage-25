"""This module defines configuration for the Column Export stage."""

import warnings
from ibm_watsonx_data_integration.services.datastage.models.base_stage import BaseStage
from ibm_watsonx_data_integration.services.datastage.models.enums import COLUMN_EXPORT
from pydantic import Field
from typing import ClassVar


class column_export(BaseStage):
    """Properties for the Column Export stage."""

    op_name: ClassVar[str] = "PxColumnExport"
    node_type: ClassVar[str] = "execution_node"
    image: ClassVar[str] = "/data-intg/flows/graphics/palette/PxColumnExport.svg"
    label: ClassVar[str] = "Column Export"
    runtime_column_propagation: bool = Field(False, alias="runtime_column_propagation")
    actual_length: int | None = Field(
        None,
        alias="actual_length",
        description=(
            "Specifies the number of bytes skipped by the importer or filled with the null-field or specified "
            "pad character by the exporter when a field has been identified as null."
        ),
    )
    allow_all_zeros: COLUMN_EXPORT.AllowAllZeros | None = Field(
        COLUMN_EXPORT.AllowAllZeros.nofix_zero,
        alias="allow_all_zeros",
        description=(
            "Specifies whether or not to treat a packed decimal field containing all zeros (normally illegal) as "
            "a valid representation of zero."
        ),
    )
    allow_signed_import: COLUMN_EXPORT.AllowSignedImport | None = Field(
        COLUMN_EXPORT.AllowSignedImport.allow_signed_import,
        alias="allow_signed_import",
        description=("Force import both signed and unsigned values as unsigned."),
    )
    auto_column_propagation: bool | None = Field(
        None,
        alias="auto_column_propagation",
        description=("Automatically apply column metadata changes to downstream stages(See Settings in toolbar)"),
    )
    buf_free_run: int | None = Field(
        50,
        alias="buf_free_run",
        description=("Specifies how much of the available in-memory buffer to use before the buffer writes to disk."),
    )
    buf_free_run_ronly: int | None = Field(50, alias="buf_free_run_ronly")
    buf_mode: COLUMN_EXPORT.BufMode | None = Field(
        COLUMN_EXPORT.BufMode.default,
        alias="buf_mode",
        description=(
            "(Default): The link takes the settings that are specified by the environment variables. This is "
            "Auto buffer unless you have changed the value of the APT_BUFFERING _POLICY environment variable.   "
            "Auto buffer: The link buffers incoming data only if necessary to prevent a dataflow deadlock "
            "situation.  Buffer: The link unconditionally buffer all incoming data.  No buffer: The link does "
            "not buffer data under any circumstances. This setting might cause deadlocks if not used carefully."
        ),
    )
    buf_mode_ronly: COLUMN_EXPORT.BufModeRonly | None = Field(
        COLUMN_EXPORT.BufModeRonly.default, alias="buf_mode_ronly"
    )
    byte_order: COLUMN_EXPORT.ByteOrder | None = Field(
        COLUMN_EXPORT.ByteOrder.native_endian,
        alias="byte_order",
        description=(
            "Multiple-byte data types, except strings and raw data types, are formatted with: little-endian: the "
            "high byte on the left. big-endian: the high byte on the right. native-endian: as defined by the "
            "native format of the machine."
        ),
    )
    c_format: str | None = Field(
        "", alias="c_format", description=("Format string passed on import to sscanf() and on export to sprintf().")
    )
    charset: COLUMN_EXPORT.Charset | None = Field(
        COLUMN_EXPORT.Charset.ascii,
        alias="charset",
        description=(
            "ASCII: ASCII character set used by string fields of imported/exported data. EBCDIC: EBCDIC "
            "character set used by string fields of imported/exported data."
        ),
    )
    check_intact: COLUMN_EXPORT.CheckIntact | None = Field(
        COLUMN_EXPORT.CheckIntact.check_intact,
        alias="check_intact",
        description=(
            "Forces validation of fields of an intact schema during import. This may inhibit performance somewhat."
        ),
    )
    check_intact_flag: bool | None = Field(False, alias="check_intact_flag", description="Whether check intact")
    coll_type: COLUMN_EXPORT.CollType | None = Field(
        COLUMN_EXPORT.CollType.auto, alias="coll_type", description=("Specify the order in which data is read.")
    )
    combinability: COLUMN_EXPORT.Combinability | None = Field(
        COLUMN_EXPORT.Combinability.auto,
        alias="combinability",
        description=("Specify whether to combine underlying operators into a single process."),
    )
    current_output_link_type: str = Field("PRIMARY", alias="currentOutputLinkType")
    data_format: COLUMN_EXPORT.DataFormat | None = Field(
        COLUMN_EXPORT.DataFormat.text,
        alias="data_format",
        description=(
            "binary: imported/exported data is represented in binary format. text: Imported/exported data is "
            "represented as text characters."
        ),
    )
    date_format: str | None = Field(
        "",
        alias="date_format",
        description=("The string format of a date. By default, the format of the date string is %yyyy-%mm-%dd."),
    )
    date_option: COLUMN_EXPORT.DateOption | None = Field(
        COLUMN_EXPORT.DateOption.none, alias="dateOption", description=("Date option")
    )
    days_since: str | None = Field(
        "",
        alias="days_since",
        description=(
            "The imported/exported field stores the date as a signed integer in binary format containing the "
            "number of days since the specified date (use the form %yyyy-%mm-%dd)."
        ),
    )
    decimal_options: COLUMN_EXPORT.DecimalOption | None = Field([], alias="decimalOption", description="Decimal option")
    decimal_packed: COLUMN_EXPORT.DecimalPacked | None = Field(
        COLUMN_EXPORT.DecimalPacked.packed,
        alias="decimal_packed",
        description=(
            "yes: field contains data in packed decimal format. no (separate): Field contains an unpacked "
            "decimal with a separate sign byte. no (zoned) => Field contains an unpacked decimal in either ASCII "
            "or EBCDIC text. no (overpunch) => Field contains an unpacked decimal with an overpunched sign byte."
        ),
    )
    decimal_packed_check: COLUMN_EXPORT.DecimalPackedCheck | None = Field(
        COLUMN_EXPORT.DecimalPackedCheck.check,
        alias="decimal_packed_check",
        description=("yes/no: perform/bypass the data verification process on import/export."),
    )
    decimal_packed_sign_position: COLUMN_EXPORT.DecimalPackedSignPosition | None = Field(
        COLUMN_EXPORT.DecimalPackedSignPosition.trailing,
        alias="decimal_packed_sign_position",
        description=("trailing: (default) the sign is in the last byte. leading => the sign is in the first byte."),
    )
    decimal_packed_signed: COLUMN_EXPORT.DecimalPackedSigned | None = Field(
        COLUMN_EXPORT.DecimalPackedSigned.signed,
        alias="decimal_packed_signed",
        description=(
            "yes (signed): use the sign of the source decimal on import or export. no (unsigned) => generate a "
            "sign nibble of 0xf, meaning a positive value, regardless of the imported or exported field's actual "
            "sign."
        ),
    )
    decimal_sep_value: str | None = Field(
        "", alias="decimal_sep_value", description=("Input the custom value of decimal separator")
    )
    decimal_separator: COLUMN_EXPORT.DecimalSeparator | None = Field(
        COLUMN_EXPORT.DecimalSeparator.period,
        alias="decimal_separator",
        description=(
            "The character used to separate the parts of a decimal number. By default, this is a period (.), but "
            "can be specified as any other single ASCII character."
        ),
    )
    delim: COLUMN_EXPORT.Delim | None = Field(
        COLUMN_EXPORT.Delim.comma,
        alias="delim",
        description=(
            "Trailing delimiter on all fields of the record. whitespace: Import skips all standard white-space "
            "characters (space, tab, and newline) trailing a field. end: The last field in the record is "
            "composed of all remaining bytes until the end of the record. none: Fields have no delimiter. null: "
            "The delimiter is the ASCII null character. other: A single ASCII character."
        ),
    )
    delim_string: str | None = Field(
        "",
        alias="delim_string",
        description=(
            "Specifies one or more ASCII delimiter characters as the trailing delimiter for all fields of the "
            "record. Use backslash (\\) as an escape character to specify special characters within a string, "
            "e.g. '\\t' for TAB. Import skips the delimiter string in the source data file. On export, the "
            "trailing delimiter string is written after the final field in the data file."
        ),
    )
    delim_value: str | None = Field("", alias="delim_value", description="Input the custom value of delimiter")
    disk_write_inc: int | None = Field(
        1048576,
        alias="disk_write_inc",
        description=("Sets the size, in bytes, of blocks of data being moved to and from disk."),
    )
    disk_write_inc_ronly: int | None = Field(1048576, alias="disk_write_inc_ronly")
    enable_flow_acp_control: bool = Field(True, alias="enableFlowAcpControl")
    enable_schemaless_design: bool = Field(False, alias="enableSchemalessDesign")
    execmode: COLUMN_EXPORT.Execmode | None = Field(
        COLUMN_EXPORT.Execmode.default_par,
        alias="execmode",
        description=("Specify whether your stage runs sequentially or in parallel."),
    )
    export_ebcdic_as_ascii: COLUMN_EXPORT.ExportEbcdicAsAscii | None = Field(
        COLUMN_EXPORT.ExportEbcdicAsAscii.export_ebcdic_as_ascii,
        alias="export_ebcdic_as_ascii",
        description=("Causes a string field to be translated from EBCDIC to ASCII during export."),
    )
    field: str = Field(
        None,
        alias="field",
        description=("Name of the varchar or binary column to which the input column or columns are exported."),
    )
    field_option: COLUMN_EXPORT.FieldOption | None = Field(
        COLUMN_EXPORT.FieldOption.delimiter, alias="fieldOption", description=("Field defaults option")
    )
    fill: COLUMN_EXPORT.Fill | None = Field(
        COLUMN_EXPORT.Fill.null,
        alias="fill",
        description=(
            "Byte value to fill in any gaps in an exported record caused by field positioning properties. Valid "
            "only for export. By default, the fill value is the null byte (0); it may be an integer between 0 "
            "and 255, or a single-character value."
        ),
    )
    fill_char_value: str | None = Field("", alias="fill_char_value", description="Input the custom value of fill char")
    final_delim: COLUMN_EXPORT.FinalDelim | None = Field(
        COLUMN_EXPORT.FinalDelim.end,
        alias="final_delim",
        description=(
            "Specifies a delimiter for the last field of the record. whitespace: Import skips all standard "
            "white-space characters (space, tab, and newline) trailing a field. end: The last field in the "
            "record is composed of all remaining bytes until the end of the record. none: Fields have no "
            "delimiter. null: The delimiter is the ASCII null character. other: A single ASCII character."
        ),
    )
    final_delim_string: str | None = Field(
        "",
        alias="final_delim_string",
        description=(
            "Specifies one or more ASCII delimiter characters as the trailing delimiter for the last field of "
            "the record. Use backslash (\\) as an escape character to specify special characters within a "
            "string, e.g. '\\t' for TAB. Import skips the delimiter string in the source data file. On export, "
            "the trailing delimiter string is written after the final field in the data file."
        ),
    )
    final_delim_value: str | None = Field(
        "", alias="final_delim_value", description=("Input the custom value of final delimiter")
    )
    flow_dirty: str | None = Field("false", alias="flow_dirty")
    general_option: COLUMN_EXPORT.GeneralOption | None = Field([], alias="generalOption", description="General option")
    hide: bool | None = Field(False, alias="hide")
    import_ascii_as_ebcdic: COLUMN_EXPORT.ImportAsciiAsEbcdic | None = Field(
        COLUMN_EXPORT.ImportAsciiAsEbcdic.import_ascii_as_ebcdic,
        alias="import_ascii_as_ebcdic",
        description=("Causes a string field to be translated from ASCII to EBCDIC during import."),
    )
    in_format: str | None = Field(
        "",
        alias="in_format",
        description=("Format string passed on import to the sscanf() routine to perform a numeric conversion."),
    )
    input_count: int | None = Field(0, alias="input_count")
    input_link_description: list | None = Field("", alias="inputLinkDescription")
    inputcol_properties: list | None = Field([], alias="inputcolProperties")
    intact: str | None = Field(
        "",
        alias="intact",
        description=(
            "Defines a partial record schema, which allows you to define only those fields of interest in your "
            "data. You may enter an optional identifier for the intact schema."
        ),
    )
    is_julian: COLUMN_EXPORT.IsJulian | None = Field(
        COLUMN_EXPORT.IsJulian.julian,
        alias="is_julian",
        description=(
            "The imported/exported field represents the date as a binary numeric value denoting the Julian day "
            "(the number of days from 4713 BCE January 1, 12:00 hours GMT)."
        ),
    )
    is_midnight_seconds: COLUMN_EXPORT.IsMidnightSeconds | None = Field(
        COLUMN_EXPORT.IsMidnightSeconds.midnight_seconds,
        alias="is_midnight_seconds",
        description=(
            "Time is represented as a binary 32-bit integer containing the number of seconds elapsed from the "
            "previous midnight."
        ),
    )
    keep_exported_fields: COLUMN_EXPORT.KeepExportedFields | None = Field(
        COLUMN_EXPORT.KeepExportedFields.false,
        alias="keepExportedFields",
        description=(
            "Set to True to allow columns used to create the exported column are also propagated to output in "
            "their own right."
        ),
    )
    key_col_select: COLUMN_EXPORT.KeyColSelect | None = Field(COLUMN_EXPORT.KeyColSelect.default, alias="keyColSelect")
    key_cols_coll: list | None = Field([], alias="keyColsColl")
    key_cols_coll_ordered: list | None = Field([], alias="keyColsCollOrdered")
    key_cols_coll_robin: list | None = Field([], alias="keyColsCollRobin")
    key_cols_none: list | None = Field([], alias="keyColsNone")
    key_cols_part: list | None = Field([], alias="keyColsPart")
    max_length: int | None = Field(
        200,
        alias="maxLength",
        description=(
            "Maximum length of the varchar or binary column to which the input column or columns are exported."
        ),
    )
    max_mem_buf_size: int | None = Field(
        3145728,
        alias="max_mem_buf_size",
        description=(
            "Specifies the maximum amount of virtual memory, in bytes, used per buffer. The default size is "
            "3145728 (3 MB)."
        ),
    )
    max_mem_buf_size_ronly: int | None = Field(3145728, alias="max_mem_buf_size_ronly")
    max_width: int | None = Field(
        None,
        alias="max_width",
        description=("Specifies the maximum number of bytes of a text-format field; useful for numeric types."),
    )
    null_field: str | None = Field(
        "NULL",
        alias="null_field",
        description=(
            "On import, the value given to a field containing a null. On export, the value given to an exported "
            "field if the source field is set to null. May be a number, string, or C-style literal escape "
            "character, such as \\123 or \\xAB, if you want to use a non-printable byte value."
        ),
    )
    null_field_sep: COLUMN_EXPORT.NullFieldSep | None = Field(
        COLUMN_EXPORT.NullFieldSep.comma,
        alias="null_field_sep",
        description=(
            "Allows you to specify more than one value that can represent a null field on import. If set, "
            "indicates that there are multiple entries in the null field value property, separated by this "
            "character. If omitted, there is only one value that represents a null field."
        ),
    )
    null_field_sep_flag: bool | None = Field(
        False, alias="null_field_sep_flag", description=("Whether specify null field value separator")
    )
    null_field_sep_value: str | None = Field(
        "", alias="null_field_sep_value", description=("Input the custom value of null field value separator")
    )
    null_length: int | None = Field(
        None,
        alias="null_length",
        description=("Specifies the value of the length prefix of a variable-length field that contains a null."),
    )
    numeric_option: COLUMN_EXPORT.NumericOption | None = Field([], alias="numericOption", description="Numeric option")
    out_format: str | None = Field(
        "",
        alias="out_format",
        description=(
            "Format string passed on export to the sprintf() routine to control numeric to string conversion."
        ),
    )
    output_acp_should_hide: bool = Field(True, alias="outputAcpShouldHide")
    output_count: int | None = Field(0, alias="output_count")
    output_link_description: list | None = Field("", alias="outputLinkDescription")
    outputcol_properties: list | None = Field([], alias="outputcolProperties")
    padchar: COLUMN_EXPORT.PadChar | None = Field(
        COLUMN_EXPORT.PadChar.space,
        alias="padchar",
        description=(
            "Pad character used when strings or numeric values are exported to an external string "
            "representation. Ignored on import. null: use ASCII null character."
        ),
    )
    padchar_value: str | None = Field("", alias="padchar_value", description="Input the custom value of pad char")
    part_client_dbname: str | None = Field(None, alias="part_client_dbname", description="Db2 Database name")
    part_client_instance: str | None = Field(None, alias="part_client_instance", description="Db2 Instance name")
    part_dbconnection: str | None = Field("", alias="part_dbconnection", description="Db2 Source connection (required)")
    part_stable: bool | None = Field(
        None, alias="part_stable", description=("Select Stable if you want to preserve previously sorted data sets.")
    )
    part_stable_coll: bool | None = Field(False, alias="part_stable_coll")
    part_stable_ordered: bool | None = Field(False, alias="part_stable_ordered")
    part_stable_roundrobin_coll: bool | None = Field(False, alias="part_stable_roundrobin_coll")
    part_table: str | None = Field(None, alias="part_table", description="Db2 Table name")
    part_type: COLUMN_EXPORT.PartType | None = Field(
        COLUMN_EXPORT.PartType.auto, alias="part_type", description=("Partition type")
    )
    part_unique: bool | None = Field(
        None,
        alias="part_unique",
        description=(
            "Select Unique to specify that, if multiple records have identical sorting key values, only one "
            "record is retained. If stable sort is also set, the first record is retained."
        ),
    )
    part_unique_coll: bool | None = Field(False, alias="part_unique_coll")
    part_unique_ordered: bool | None = Field(False, alias="part_unique_ordered")
    part_unique_roundrobin_coll: bool | None = Field(False, alias="part_unique_roundrobin_coll")
    perform_sort: bool | None = Field(False, alias="perform_sort", description="Perform sort")
    perform_sort_coll: bool | None = Field(False, alias="perform_sort_coll")
    perform_sort_modulus: bool | None = Field(False, alias="perform_sort_modulus", description="Perform sort")
    precision: int | None = Field(
        None,
        alias="precision",
        description=(
            "On import, specifies the precision of a source packed decimal. On export, specifies the precision "
            "of a destination string when a decimal is exported in text format."
        ),
    )
    prefix: COLUMN_EXPORT.Prefix | None = Field(
        COLUMN_EXPORT.Prefix.one,
        alias="prefix",
        description=(
            "Specifies that each imported/exported field in the data file is prefixed by 1, 2, or 4 bytes "
            "containing, as a binary value, either the field's length or the tag value for a tagged field."
        ),
    )
    preserve: COLUMN_EXPORT.Preserve | None = Field(
        COLUMN_EXPORT.Preserve.default_propagate,
        alias="preserve",
        description=("Specify whether to maintain data in current partitions."),
    )
    print_field: COLUMN_EXPORT.PrintField | None = Field(
        COLUMN_EXPORT.PrintField.print_field,
        alias="print_field",
        description=("Import writes a message for each imported field: Importing 'fieldname': 'value'"),
    )
    queue_upper_size: int | None = Field(
        0,
        alias="queue_upper_size",
        description=("Specifies the maximum amount of data buffered at any time using both memory and disk."),
    )
    queue_upper_size_ronly: int | None = Field(0, alias="queue_upper_size_ronly")
    quote: COLUMN_EXPORT.Quote | None = Field(
        COLUMN_EXPORT.Quote.double,
        alias="quote",
        description=(
            "Variable-length fields contained within single or double quotes, another character or pair of "
            "characters; or explicitly not quoted."
        ),
    )
    quote_value: str | None = Field("", alias="quote_value", description="Input the custom value of quote")
    rec_level_option: COLUMN_EXPORT.RecLevelOption | None = Field(
        [], alias="recLevelOption", description=("Record level option")
    )
    record_delim: COLUMN_EXPORT.RecordDelim | None = Field(
        COLUMN_EXPORT.RecordDelim.newline,
        alias="record_delim",
        description=(
            "Records terminated by a trailing delimiter character. Import skips the delimiter; export writes the "
            "delimiter after each record. By default, the record delimiter is the UNIX newline character. For "
            "fixed-width files with no explicit record delimiter, remove this property altogether."
        ),
    )
    record_delim_string: str | None = Field(
        "",
        alias="record_delim_string",
        description=(
            "Specifies ASCII characters to delimit a record. Pick 'DOS format' to get CR/LF delimiters; Unix "
            "format is best specified using 'Record delimiter=UNIX newline', since it is only a single character."
        ),
    )
    record_delim_value: str | None = Field(
        "", alias="record_delim_value", description=("Input the custom value of record delimiter")
    )
    record_format: COLUMN_EXPORT.RecordFormat | None = Field(
        COLUMN_EXPORT.RecordFormat.type_implicit,
        alias="record_format",
        description=(
            "implicit: import/export data as a stream with no explicit record boundaries. varying => import data "
            "using one of the IBM blocked or spanned formats."
        ),
    )
    record_len_value: int | None = Field(
        0, alias="record_len_value", description=("Input the custom value of record length")
    )
    record_length: COLUMN_EXPORT.RecordLength | None = Field(
        COLUMN_EXPORT.RecordLength.fixed,
        alias="record_length",
        description=(
            "Fixed-length records of a specified length (including any record delimiter), or, if the keyword "
            "'fixed' is used, must contain only fixed-length columns so that the record length can be calculated."
        ),
    )
    record_prefix: COLUMN_EXPORT.RecordPrefix | None = Field(
        COLUMN_EXPORT.RecordPrefix.one,
        alias="record_prefix",
        description=("Variable-length records prefixed by length prefix of 1, 2, or 4 bytes.  Default is 1 byte."),
    )
    round: COLUMN_EXPORT.Round | None = Field(
        COLUMN_EXPORT.Round.trunc_zero,
        alias="round",
        description=(
            "How to round the source field to fit into the destination decimal when importing to a decimal, or "
            "how to round a source decimal when exporting a decimal. up (ceiling): truncate source field toward "
            "positive infinity. down (floor): truncate source field toward negative infinity. nearest value: "
            "Round the source field toward the nearest representable value. truncate towards zero: (Default) "
            "Discard fractional digits to the right of the right-most fractional digit supported by the "
            "destination, regardless of sign."
        ),
    )
    runtime_column_propagation: bool | None = Field(
        None,
        alias="runtime_column_propagation",
        description=("Propagate extra columns that are not defined in the metadata through the rest of the job."),
    )
    save_rejects: COLUMN_EXPORT.SaveRejects | None = Field(
        COLUMN_EXPORT.SaveRejects.custom,
        alias="saveRejects",
        description=(
            "Continue = report failing rows as log messages; Fail = abort stage; Output = write them to a reject "
            "link (second output link)."
        ),
    )
    scale: int | None = Field(
        None,
        alias="scale",
        description=(
            "On import, specifies how to round the source field to fit into the destination decimal when the "
            "source field is imported to a decimal. On export, specifies how to round a source decimal when its "
            "precision and scale are greater than those of the destination."
        ),
    )
    schema_: list | None = Field(
        [],
        alias="schema",
        description=(
            "Name of a column To export. Columns must appear in the properties list in the same order as they "
            "appear on the Input Link. Type information for Columns to export should be set in the Column & "
            "Format Tabs on the Input Link."
        ),
    )
    schemafile: str = Field(
        None,
        alias="schemafile",
        description=(
            "Name of a file containing a schema for the data, that specifies how input columns are packed into "
            "the exported column. Setting this property will override any settings on the Format tab & any Input "
            "Columns that are not on the output."
        ),
    )
    selection: COLUMN_EXPORT.Selection | None = Field(
        COLUMN_EXPORT.Selection.explicit,
        alias="selection",
        description=("Whether to specify columns to export explicitly or use a Schema File."),
    )
    show_coll_type: int | None = Field(0, alias="showCollType")
    show_part_type: int | None = Field(1, alias="showPartType")
    show_sort_options: int | None = Field(0, alias="showSortOptions")
    sort_instructions: str | None = Field("", alias="sortInstructions")
    sort_instructions_text: str | None = Field("", alias="sortInstructionsText")
    stage_description: list | None = Field("", alias="stageDescription", description="Description")
    string_option: COLUMN_EXPORT.StringOption | None = Field([], alias="stringOption", description="String option")
    time_format: str | None = Field(
        "",
        alias="time_format",
        description=(
            "Format of a field representing a time as a string. By default, the format of the time string is "
            "%hh:%mm:%ss."
        ),
    )
    time_option: COLUMN_EXPORT.TimeOption | None = Field(
        COLUMN_EXPORT.TimeOption.none, alias="timeOption", description=("Time option")
    )
    timestamp_format: str | None = Field(
        "",
        alias="timestamp_format",
        description=(
            "Format of a field representing a timestamp as a string. By default, the format of the timestamp "
            "string is %yyyy-%mm-%dd %hh:%mm:%ss."
        ),
    )
    timestamp_option: COLUMN_EXPORT.TimestampOption | None = Field(
        COLUMN_EXPORT.TimestampOption.none, alias="timestampOption", description=("Timestamp option")
    )
    type: COLUMN_EXPORT.Type | None = Field(
        COLUMN_EXPORT.Type.raw,
        alias="type",
        description=("Data type of the output column; that is, the type to which the stage converts input data."),
    )
    vector_prefix: COLUMN_EXPORT.VectorPrefix | None = Field(
        COLUMN_EXPORT.VectorPrefix.one,
        alias="vector_prefix",
        description=("Specifies 1-, 2-, or 4-byte prefix containing the number of elements in the vector."),
    )
    width: int | None = Field(
        None,
        alias="width",
        description=(
            "Specifies the number of bytes of an imported or exported text-format field; useful for numeric types."
        ),
    )

    def _validate_parameters(self) -> tuple[set, set]:
        include = set()
        exclude = set()

        include.add("schemafile") if (
            self.selection
            and ((hasattr(self.selection, "value") and self.selection.value == "file") or (self.selection == "file"))
        ) else exclude.add("schemafile")
        include.add("schema_") if (
            self.selection
            and (
                (hasattr(self.selection, "value") and self.selection.value == "explicit")
                or (self.selection == "explicit")
            )
        ) else exclude.add("schema_")
        include.add("max_length") if (()) else exclude.add("max_length")
        include.add("preserve") if (self.output_count and self.output_count > 0) else exclude.add("preserve")
        include.add("max_mem_buf_size") if (self.buf_mode != "nobuffer") else exclude.add("max_mem_buf_size")
        include.add("buf_free_run") if (self.buf_mode != "nobuffer") else exclude.add("buf_free_run")
        include.add("queue_upper_size") if (self.buf_mode != "nobuffer") else exclude.add("queue_upper_size")
        include.add("disk_write_inc") if (self.buf_mode != "nobuffer") else exclude.add("disk_write_inc")

        include.add("runtime_column_propagation") if (not self.enable_schemaless_design) else exclude.add(
            "runtime_column_propagation"
        )
        include.add("auto_column_propagation") if (not self.output_acp_should_hide) else exclude.add(
            "auto_column_propagation"
        )
        include.add("max_mem_buf_size_ronly") if (self.buf_mode_ronly != "nobuffer") else exclude.add(
            "max_mem_buf_size_ronly"
        )
        include.add("buf_free_run_ronly") if (self.buf_mode_ronly != "nobuffer") else exclude.add("buf_free_run_ronly")
        include.add("queue_upper_size_ronly") if (self.buf_mode_ronly != "nobuffer") else exclude.add(
            "queue_upper_size_ronly"
        )
        include.add("disk_write_inc_ronly") if (self.buf_mode_ronly != "nobuffer") else exclude.add(
            "disk_write_inc_ronly"
        )
        include.add("part_stable") if (
            (self.show_part_type)
            and (self.part_type != "auto")
            and (self.part_type != "db2connector")
            and (self.show_sort_options)
        ) else exclude.add("part_stable")
        include.add("part_unique") if (
            (self.show_part_type)
            and (self.part_type != "auto")
            and (self.part_type != "db2connector")
            and (self.show_sort_options)
        ) else exclude.add("part_unique")
        include.add("key_cols_part") if (
            (
                (self.show_part_type)
                and (not self.show_coll_type)
                and (self.part_type != "auto")
                and (self.part_type != "db2connector")
                and (self.part_type != "modulus")
            )
            or (
                (self.show_part_type)
                and (not self.show_coll_type)
                and (self.part_type == "modulus")
                and (self.perform_sort_modulus)
            )
        ) else exclude.add("key_cols_part")
        include.add("part_dbconnection") if ((self.part_type == "db2part") and (self.show_part_type)) else exclude.add(
            "part_dbconnection"
        )
        include.add("part_client_dbname") if ((self.part_type == "db2part") and (self.show_part_type)) else exclude.add(
            "part_client_dbname"
        )
        include.add("part_client_instance") if (
            (self.part_type == "db2part") and (self.show_part_type)
        ) else exclude.add("part_client_instance")
        include.add("part_table") if ((self.part_type == "db2part") and (self.show_part_type)) else exclude.add(
            "part_table"
        )
        include.add("perform_sort") if (
            (self.show_part_type) and ((self.part_type == "hash") or (self.part_type == "range"))
        ) else exclude.add("perform_sort")
        include.add("perform_sort_modulus") if (
            (self.show_part_type) and (self.part_type == "modulus")
        ) else exclude.add("perform_sort_modulus")
        include.add("key_col_select") if (
            (self.show_part_type) and (self.part_type == "modulus") and (not self.perform_sort_modulus)
        ) else exclude.add("key_col_select")
        include.add("sort_instructions") if (
            (self.show_part_type)
            and (
                (self.part_type == "db2part")
                or (self.part_type == "entire")
                or (self.part_type == "random")
                or (self.part_type == "roundrobin")
                or (self.part_type == "same")
            )
        ) else exclude.add("sort_instructions")
        include.add("sort_instructions_text") if (
            (self.show_part_type)
            and (
                (self.part_type == "db2part")
                or (self.part_type == "entire")
                or (self.part_type == "random")
                or (self.part_type == "roundrobin")
                or (self.part_type == "same")
            )
        ) else exclude.add("sort_instructions_text")
        include.add("coll_type") if (self.show_coll_type) else exclude.add("coll_type")
        include.add("part_type") if (self.show_part_type) else exclude.add("part_type")
        include.add("perform_sort_coll") if (
            (
                (self.show_coll_type)
                and (
                    (self.coll_type == "ordered")
                    or (self.coll_type == "roundrobin_coll")
                    or (self.coll_type == "sortmerge")
                )
            )
            or ((not self.show_part_type) and (not self.show_coll_type))
        ) else exclude.add("perform_sort_coll")
        include.add("key_cols_coll") if (
            (self.show_coll_type)
            and (not self.show_part_type)
            and (self.coll_type != "auto")
            and ((self.coll_type == "sortmerge") or (self.perform_sort_coll))
        ) else exclude.add("key_cols_coll")
        include.add("key_cols_none") if (
            (not self.show_part_type) and (not self.show_coll_type) and (self.perform_sort_coll)
        ) else exclude.add("key_cols_none")
        include.add("part_stable_coll") if (
            (self.perform_sort_coll)
            and (
                (
                    (not self.show_part_type)
                    and (self.show_coll_type)
                    and (self.coll_type != "auto")
                    and (self.show_sort_options)
                )
                or ((not self.show_part_type) and (not self.show_coll_type) and (self.show_sort_options))
            )
        ) else exclude.add("part_stable_coll")
        include.add("part_unique_coll") if (
            (self.perform_sort_coll)
            and (
                (
                    (not self.show_part_type)
                    and (self.show_coll_type)
                    and (self.coll_type != "auto")
                    and (self.show_sort_options)
                )
                or ((not self.show_part_type) and (not self.show_coll_type) and (self.show_sort_options))
            )
        ) else exclude.add("part_unique_coll")
        include.add("final_delim") if (
            self.rec_level_option and "final_delimiter" in str(self.rec_level_option)
        ) else exclude.add("final_delim")
        include.add("final_delim_value") if (
            (self.rec_level_option and "final_delimiter" in str(self.rec_level_option)) and (self.final_delim == " ")
        ) else exclude.add("final_delim_value")
        include.add("fill") if (self.rec_level_option and "fill" in str(self.rec_level_option)) else exclude.add("fill")
        include.add("fill_char_value") if (
            (self.rec_level_option and "fill" in str(self.rec_level_option)) and (self.fill == -1)
        ) else exclude.add("fill_char_value")
        include.add("final_delim_string") if (
            self.rec_level_option and "final_delim_string" in str(self.rec_level_option)
        ) else exclude.add("final_delim_string")
        include.add("intact") if (self.rec_level_option and "intact" in str(self.rec_level_option)) else exclude.add(
            "intact"
        )
        include.add("check_intact_flag") if (
            self.rec_level_option and "intact" in str(self.rec_level_option)
        ) else exclude.add("check_intact_flag")
        include.add("check_intact") if (
            (self.check_intact_flag) and (self.rec_level_option and "intact" in str(self.rec_level_option))
        ) else exclude.add("check_intact")
        include.add("record_delim") if (
            self.rec_level_option and "record_delimiter" in str(self.rec_level_option)
        ) else exclude.add("record_delim")
        include.add("record_delim_value") if (
            (self.rec_level_option and "record_delimiter" in str(self.rec_level_option)) and (self.record_delim == " ")
        ) else exclude.add("record_delim_value")
        include.add("record_delim_string") if (
            self.rec_level_option and "record_delim_string" in str(self.rec_level_option)
        ) else exclude.add("record_delim_string")
        include.add("record_length") if (
            self.rec_level_option and "record_length" in str(self.rec_level_option)
        ) else exclude.add("record_length")
        include.add("record_len_value") if (
            (self.rec_level_option and "record_length" in str(self.rec_level_option)) and (self.record_length == " ")
        ) else exclude.add("record_len_value")
        include.add("record_prefix") if (
            self.rec_level_option and "record_prefix" in str(self.rec_level_option)
        ) else exclude.add("record_prefix")
        include.add("record_format") if (
            self.rec_level_option and "record_format" in str(self.rec_level_option)
        ) else exclude.add("record_format")
        include.add("delim") if (self.field_option and "delimiter" in str(self.field_option)) else exclude.add("delim")
        include.add("delim_value") if (
            (self.field_option and "delimiter" in str(self.field_option)) and (self.delim == " ")
        ) else exclude.add("delim_value")
        include.add("quote") if (self.field_option and "quote" in str(self.field_option)) else exclude.add("quote")
        include.add("quote_value") if (
            (self.field_option and "quote" in str(self.field_option)) and (self.quote == " ")
        ) else exclude.add("quote_value")
        include.add("actual_length") if (
            self.field_option and "actual_length" in str(self.field_option)
        ) else exclude.add("actual_length")
        include.add("delim_string") if (
            self.field_option and "delim_string" in str(self.field_option)
        ) else exclude.add("delim_string")
        include.add("null_length") if (self.field_option and "null_length" in str(self.field_option)) else exclude.add(
            "null_length"
        )
        include.add("null_field") if (self.field_option and "null_field" in str(self.field_option)) else exclude.add(
            "null_field"
        )
        include.add("null_field_sep_flag") if (
            self.field_option and "null_field" in str(self.field_option)
        ) else exclude.add("null_field_sep_flag")
        include.add("null_field_sep") if (
            (self.null_field_sep_flag) and (self.field_option and "null_field" in str(self.field_option))
        ) else exclude.add("null_field_sep")
        include.add("null_field_sep_value") if (
            (self.field_option and "null_field" in str(self.field_option))
            and (self.null_field_sep_flag)
            and (self.null_field_sep == " ")
        ) else exclude.add("null_field_sep_value")
        include.add("prefix") if (self.field_option and "prefix_bytes" in str(self.field_option)) else exclude.add(
            "prefix"
        )
        include.add("print_field") if (self.field_option and "print_field" in str(self.field_option)) else exclude.add(
            "print_field"
        )
        include.add("vector_prefix") if (
            self.field_option and "vector_prefix" in str(self.field_option)
        ) else exclude.add("vector_prefix")
        include.add("byte_order") if (
            self.general_option and "byte_order" in str(self.general_option)
        ) else exclude.add("byte_order")
        include.add("charset") if (self.general_option and "charset" in str(self.general_option)) else exclude.add(
            "charset"
        )
        include.add("data_format") if (
            self.general_option and "data_format" in str(self.general_option)
        ) else exclude.add("data_format")
        include.add("max_width") if (self.general_option and "max_width" in str(self.general_option)) else exclude.add(
            "max_width"
        )
        include.add("width") if (self.general_option and "field_width" in str(self.general_option)) else exclude.add(
            "width"
        )
        include.add("padchar") if (self.general_option and "padchar" in str(self.general_option)) else exclude.add(
            "padchar"
        )
        include.add("padchar_value") if (
            (self.general_option and "padchar" in str(self.general_option)) and (self.padchar == " ")
        ) else exclude.add("padchar_value")
        include.add("export_ebcdic_as_ascii") if (
            self.string_option and "export_ebcdic_as_ascii" in str(self.string_option)
        ) else exclude.add("export_ebcdic_as_ascii")
        include.add("import_ascii_as_ebcdic") if (
            self.string_option and "import_ascii_as_ebcdic" in str(self.string_option)
        ) else exclude.add("import_ascii_as_ebcdic")
        include.add("allow_all_zeros") if (
            self.decimal_options and "allow_all_zeros" in str(self.decimal_options)
        ) else exclude.add("allow_all_zeros")
        include.add("decimal_separator") if (
            self.decimal_options and "decimal_separator" in str(self.decimal_options)
        ) else exclude.add("decimal_separator")
        include.add("decimal_sep_value") if (
            (self.decimal_options and "decimal_separator" in str(self.decimal_options))
            and (self.decimal_separator == " ")
        ) else exclude.add("decimal_sep_value")
        include.add("decimal_packed") if (
            self.decimal_options and "decimal_packed" in str(self.decimal_options)
        ) else exclude.add("decimal_packed")
        include.add("precision") if (
            self.decimal_options and "precision" in str(self.decimal_options)
        ) else exclude.add("precision")
        include.add("round") if (self.decimal_options and "round" in str(self.decimal_options)) else exclude.add(
            "round"
        )
        include.add("scale") if (self.decimal_options and "scale" in str(self.decimal_options)) else exclude.add(
            "scale"
        )
        include.add("decimal_packed_check") if (
            (self.decimal_options and "decimal_packed" in str(self.decimal_options))
            and (self.decimal_packed == "packed")
        ) else exclude.add("decimal_packed_check")
        include.add("decimal_packed_sign_position") if (
            (self.decimal_options and "decimal_packed" in str(self.decimal_options))
            and (self.decimal_packed != "packed")
        ) else exclude.add("decimal_packed_sign_position")
        include.add("decimal_packed_signed") if (
            (self.decimal_options and "decimal_packed" in str(self.decimal_options))
            and ((self.decimal_packed == "packed") or (self.decimal_packed == "zoned"))
        ) else exclude.add("decimal_packed_signed")
        include.add("allow_signed_import") if (
            (self.decimal_options and "decimal_packed" in str(self.decimal_options))
            and (self.decimal_packed == "packed")
            and (self.decimal_packed_signed == "unsigned")
        ) else exclude.add("allow_signed_import")
        include.add("c_format") if (self.numeric_option and "c_format" in str(self.numeric_option)) else exclude.add(
            "c_format"
        )
        include.add("in_format") if (self.numeric_option and "in_format" in str(self.numeric_option)) else exclude.add(
            "in_format"
        )
        include.add("out_format") if (
            self.numeric_option and "out_format" in str(self.numeric_option)
        ) else exclude.add("out_format")
        include.add("days_since") if (self.date_option == "days_since") else exclude.add("days_since")
        include.add("date_format") if (self.date_option == "date_format") else exclude.add("date_format")
        include.add("is_julian") if (self.date_option == "is_julian") else exclude.add("is_julian")
        include.add("time_format") if (self.time_option == "time_format") else exclude.add("time_format")
        include.add("is_midnight_seconds") if (self.time_option == "is_midnight_seconds") else exclude.add(
            "is_midnight_seconds"
        )
        include.add("timestamp_format") if (self.timestamp_option == "timestamp_format") else exclude.add(
            "timestamp_format"
        )
        return include, exclude

    def _get_input_ports_props(self) -> dict:
        include, exclude = self._validate()
        props = {"runtime_column_propagation"}
        required = set()
        props = props & (self.model_fields_set | required)
        conflict = exclude & self.model_fields_set & props
        if conflict:
            conflict = list(conflict)
            if len(conflict) == 1:
                warnings.warn(f"\n\033[33mFound conflicting property: {conflict[0]}\033[0m")
            else:
                warnings.warn(
                    f"\n\033[33mFound conflicting properties: {', '.join(conflict[:-1])} and {conflict[-1]}\033[0m"
                )
        exclude = exclude - self.model_fields_set
        return self.model_dump(include=props - exclude, by_alias=True, exclude_none=True, warnings=False)

    def _get_input_cardinality(self) -> dict:
        return {"min": 1, "max": 1}

    def _get_output_ports_props(self) -> dict:
        include, exclude = self._validate()
        props = set()
        required = set()
        props = props & (self.model_fields_set | required)
        conflict = exclude & self.model_fields_set & props
        if conflict:
            conflict = list(conflict)
            if len(conflict) == 1:
                warnings.warn(f"\n\033[33mFound conflicting property: {conflict[0]}\033[0m")
            else:
                warnings.warn(
                    f"\n\033[33mFound conflicting properties: {', '.join(conflict[:-1])} and {conflict[-1]}\033[0m"
                )
        exclude = exclude - self.model_fields_set
        return self.model_dump(include=props - exclude, by_alias=True, exclude_none=True, warnings=False)

    def _get_output_cardinality(self) -> dict:
        return {"min": 1, "max": 1}

    def _get_parameters_props(self) -> dict:
        include, exclude = self._validate()
        props = {
            "actual_length",
            "additional_properties_set",
            "allow_all_zeros",
            "allow_signed_import",
            "auto_column_propagation",
            "buf_free_run",
            "buf_free_run_ronly",
            "buf_mode",
            "buf_mode_ronly",
            "byte_order",
            "c_format",
            "charset",
            "check_intact",
            "check_intact_flag",
            "coll_type",
            "combinability",
            "current_output_link_type",
            "data_format",
            "date_format",
            "date_option",
            "days_since",
            "decimal_options",
            "decimal_packed",
            "decimal_packed_check",
            "decimal_packed_sign_position",
            "decimal_packed_signed",
            "decimal_sep_value",
            "decimal_separator",
            "delim",
            "delim_string",
            "delim_value",
            "disk_write_inc",
            "disk_write_inc_ronly",
            "enable_flow_acp_control",
            "enable_schemaless_design",
            "execmode",
            "export_ebcdic_as_ascii",
            "field",
            "field_option",
            "fill",
            "fill_char_value",
            "final_delim",
            "final_delim_string",
            "final_delim_value",
            "flow_dirty",
            "general_option",
            "hide",
            "import_ascii_as_ebcdic",
            "in_format",
            "input_count",
            "input_link_description",
            "inputcol_properties",
            "intact",
            "is_julian",
            "is_midnight_seconds",
            "keep_exported_fields",
            "key_col_select",
            "key_cols_coll",
            "key_cols_coll_ordered",
            "key_cols_coll_robin",
            "key_cols_none",
            "key_cols_part",
            "max_length",
            "max_mem_buf_size",
            "max_mem_buf_size_ronly",
            "max_width",
            "null_field",
            "null_field_sep",
            "null_field_sep_flag",
            "null_field_sep_value",
            "null_length",
            "numeric_option",
            "out_format",
            "output_acp_should_hide",
            "output_count",
            "output_link_description",
            "outputcol_properties",
            "padchar",
            "padchar_value",
            "part_client_dbname",
            "part_client_instance",
            "part_dbconnection",
            "part_stable",
            "part_stable_coll",
            "part_stable_ordered",
            "part_stable_roundrobin_coll",
            "part_table",
            "part_type",
            "part_unique",
            "part_unique_coll",
            "part_unique_ordered",
            "part_unique_roundrobin_coll",
            "perform_sort",
            "perform_sort_coll",
            "perform_sort_modulus",
            "precision",
            "prefix",
            "preserve",
            "print_field",
            "queue_upper_size",
            "queue_upper_size_ronly",
            "quote",
            "quote_value",
            "rec_level_option",
            "record_delim",
            "record_delim_string",
            "record_delim_value",
            "record_format",
            "record_len_value",
            "record_length",
            "record_prefix",
            "round",
            "runtime_column_propagation",
            "save_rejects",
            "scale",
            "schema_",
            "schemafile",
            "selection",
            "show_coll_type",
            "show_part_type",
            "show_sort_options",
            "sort_instructions",
            "sort_instructions_text",
            "stage_description",
            "string_option",
            "time_format",
            "time_option",
            "timestamp_format",
            "timestamp_option",
            "type",
            "vector_prefix",
            "width",
        }
        required = {
            "current_output_link_type",
            "enable_flow_acp_control",
            "enable_schemaless_design",
            "field",
            "output_acp_should_hide",
            "schema_",
            "schemafile",
            "selection",
        }
        props = props & (self.model_fields_set | required)
        conflict = exclude & self.model_fields_set & props
        if conflict:
            conflict = list(conflict)
            if len(conflict) == 1:
                warnings.warn(f"\n\033[33mFound conflicting property {conflict[0]}\033[0m")
            else:
                warnings.warn(
                    f"\n\033[33mFound conflicting properties{', '.join(conflict[:-1])} and {conflict[-1]}\033[0m"
                )
        exclude = exclude - self.model_fields_set
        return self.model_dump(include=props - exclude, by_alias=True, exclude_none=True, warnings=False)

    def _get_app_data_props(self) -> dict:
        return {
            "datastage": {
                "maxRejectOutputs": 1,
                "minRejectOutputs": 0,
                "maxReferenceInputs": 0,
                "minReferenceInputs": 0,
            }
        }
