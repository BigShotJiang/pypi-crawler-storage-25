"""This module defines configuration for the Apache Impala stage."""

import warnings
from ibm_watsonx_data_integration.services.datastage.models.base_stage import BaseStage
from ibm_watsonx_data_integration.services.datastage.models.connections.impala_connection import ImpalaConn
from ibm_watsonx_data_integration.services.datastage.models.enums import IMPALA
from pydantic import Field
from typing import ClassVar


class impala(BaseStage):
    """Properties for the Apache Impala stage."""

    op_name: ClassVar[str] = "impala"
    node_type: ClassVar[str] = "binding"
    image: ClassVar[str] = "/data-intg/flows/graphics/palette/impala.svg"
    label: ClassVar[str] = "Apache Impala"
    runtime_column_propagation: bool = Field(False, alias="runtime_column_propagation")
    connection: ImpalaConn = ImpalaConn()
    buf_free_run_ronly: int | None = Field(50, alias="buf_free_run_ronly")
    buf_mode_ronly: IMPALA.BufModeRonly | None = Field(IMPALA.BufModeRonly.default, alias="buf_mode_ronly")
    buffer_free_run_percent: int | None = Field(
        50,
        alias="buf_free_run",
        description=("Specifies how much of the available in-memory buffer to use before the buffer writes to disk."),
    )
    buffering_mode: IMPALA.BufferingMode | None = Field(
        IMPALA.BufferingMode.default,
        alias="buf_mode",
        description=(
            "(Default): The link takes the settings that are specified by the environment variables. This is "
            "Auto buffer unless you have changed the value of the APT_BUFFERING _POLICY environment variable.   "
            "Auto buffer: The link buffers incoming data only if necessary to prevent a dataflow deadlock "
            "situation.  Buffer: The link unconditionally buffer all incoming data.  No buffer: The link does "
            "not buffer data under any circumstances. This setting might cause deadlocks if not used carefully."
        ),
    )
    byte_limit: str | None = Field(
        None,
        alias="byte_limit",
        description=(
            "The maximum number of bytes to return. Use any of following suffixes to change the unit: KB, MB, "
            "GB, or TB. A value of 0 returns all data."
        ),
    )
    collecting: IMPALA.Collecting | None = Field(
        IMPALA.Collecting.auto, alias="coll_type", description=("Specify the order in which data is read.")
    )
    column_metadata_change_propagation: bool | None = Field(
        None,
        alias="auto_column_propagation",
        description=("Automatically apply column metadata changes to downstream stages(See Settings in toolbar)"),
    )
    combinability_mode: IMPALA.CombinabilityMode | None = Field(
        IMPALA.CombinabilityMode.auto,
        alias="combinability",
        description=("Specify whether to combine underlying operators into a single process."),
    )
    create_data_asset: bool | None = Field(
        False,
        alias="registerDataAsset",
        description=(
            "If this checkbox is selected and a data asset with the file name does not already exist, a project "
            "data asset will be created. The asset will not be updated if the job is rerun."
        ),
    )
    current_output_link_type: str = Field("PRIMARY", alias="currentOutputLinkType")
    data_asset_name: str = Field(None, alias="dataAssetName", description="Data asset name")
    db2_database_name: str | None = Field(None, alias="part_client_dbname", description="Db2 Database name")
    db2_instance_name: str | None = Field(None, alias="part_client_instance", description="Db2 Instance name")
    db2_source_connection_required: str | None = Field(
        "", alias="part_dbconnection", description=("Db2 Source connection (required)")
    )
    db2_table_name: str | None = Field(None, alias="part_table", description="Db2 Table name")
    decimal_rounding_mode: IMPALA.DecimalRoundingMode | None = Field(
        IMPALA.DecimalRoundingMode.floor,
        alias="decimal_rounding_mode",
        description=("Different rounding modes for values in columns of decimal and numeric data types"),
    )
    default_maximum_length_for_columns: int | None = Field(
        20000,
        alias="default_max_string_binary_precision",
        description=(
            "Default maximum length for columns. This property can be set/is applicable only when runtime column "
            "propagation is used"
        ),
    )
    defer_credentials: bool | None = Field(
        False, alias="defer_credentials", description=("Defer specifying credentials until usage")
    )
    disk_write_inc_ronly: int | None = Field(1048576, alias="disk_write_inc_ronly")
    disk_write_increment_bytes: int | None = Field(
        1048576,
        alias="disk_write_inc",
        description=("Sets the size, in bytes, of blocks of data being moved to and from disk."),
    )
    ds_before_after: bool | None = Field(
        False,
        alias="_before_after",
        description=("Select Yes to run SQL statements before and after data is accessed in the database."),
    )
    ds_before_after_after_sql: str | None = Field(
        None,
        alias="_before_after._after_sql",
        description=("Enter the SQL statement to run once after all of the data is processed."),
    )
    ds_before_after_after_sql_fail_on_error: bool | None = Field(
        True,
        alias="_before_after._after_sql._fail_on_error",
        description=("Select Yes to stop the job if the After SQL statement fails."),
    )
    ds_before_after_after_sql_node: str | None = Field(
        None,
        alias="_before_after._after_sql_node",
        description=(
            "Enter the SQL statement to run once on each node after all of the data is processed on that node."
        ),
    )
    ds_before_after_after_sql_node_fail_on_error: bool | None = Field(
        True,
        alias="_before_after._after_sql_node._fail_on_error",
        description=("Select Yes to stop the job if the After SQL (node) statement fails."),
    )
    ds_before_after_after_sql_node_read_from_file_after_sql_node: bool | None = Field(
        False,
        alias="_before_after._after_sql_node._read_from_file_after_sql_node",
        description=(
            "Select Yes to read the SQL statement from the file that is specified in the After SQL (node) "
            "statement property."
        ),
    )
    ds_before_after_after_sql_read_from_file_after_sql: bool | None = Field(
        False,
        alias="_before_after._after_sql._read_from_file_after_sql",
        description=(
            "Select Yes to read the SQL statement from the file that is specified in the After SQL statement property."
        ),
    )
    ds_before_after_before_sql: str | None = Field(
        None,
        alias="_before_after._before_sql",
        description=("Enter the SQL statement to run once before any data is processed."),
    )
    ds_before_after_before_sql_fail_on_error: bool | None = Field(
        True,
        alias="_before_after._before_sql._fail_on_error",
        description=("Select Yes to stop the job if the Before SQL statement fails."),
    )
    ds_before_after_before_sql_node: str | None = Field(
        None,
        alias="_before_after._before_sql_node",
        description=("Enter the SQL statement to run once on each node before any data is processed on that node."),
    )
    ds_before_after_before_sql_node_fail_on_error: bool | None = Field(
        True,
        alias="_before_after._before_sql_node._fail_on_error",
        description=("Select Yes to stop the job if the Before SQL (node) statement fails."),
    )
    ds_before_after_before_sql_node_read_from_file_before_sql_node: bool | None = Field(
        False,
        alias="_before_after._before_sql_node._read_from_file_before_sql_node",
        description=(
            "Select Yes to read the SQL statement from the file that is specified in the Before SQL (node) "
            "statement property."
        ),
    )
    ds_before_after_before_sql_read_from_file_before_sql: bool | None = Field(
        False,
        alias="_before_after._before_sql._read_from_file_before_sql",
        description=(
            "Select Yes to read the SQL statement from the file that is specified in the Before SQL statement property."
        ),
    )
    ds_custom_statements: str | None = Field(
        None, alias="_custom_statements", description=("Custom statements to be run for each input row")
    )
    ds_custom_statements_read_from_file_custom: bool | None = Field(
        False,
        alias="_custom_statements._read_from_file_custom",
        description=(
            "Select Yes to read the custom statements from the file that is specified in the Custom statements "
            "property."
        ),
    )
    ds_delete_statement: str = Field(
        None,
        alias="_delete_statement",
        description=("Enter a DELETE statement. The statement is used to delete rows from the database."),
    )
    ds_delete_statement_read_from_file_delete: bool | None = Field(
        False,
        alias="_delete_statement._read_from_file_delete",
        description=(
            "Select Yes to read the DELETE statement from the file that is specified in the DELETE statement property."
        ),
    )
    ds_enable_partitioned_reads: bool | None = Field(
        False,
        alias="_enable_partitioned_reads",
        description=(
            "Select Yes to run the statement on each processing node. When using 'Database partition' as "
            "Partitioned read method the statement should consist of a where clause <parition-column> = "
            "[[part-value]], where partition-column is the partition from which you want to query and the "
            "[[part-value]] is the placeholder which is replaced on each processing node with the actual "
            "partition values to prepare the query. A simple example is SELECT c1,c2 from part_table where "
            "pc1=[[part-value]]. When using 'Modulus', [[mod-part-expr]] should be used. Example: SELECT * from "
            "part_table where [[mod-part-value]]. With 'Minimum and Maximum range' the placeholder is "
            "[[range-part-expr]]. Example: SELECT * from part_table where [[range-part-value]]"
        ),
    )
    ds_enable_partitioned_reads_column_name: str | None = Field(
        None,
        alias="_enable_partitioned_reads._column_name",
        description=(
            "Use this property to specify the key column that will be used by the selected partition read "
            "method. This column must be a numeric datatype."
        ),
    )
    ds_enable_partitioned_reads_partition_method: IMPALA.DSEnablePartitionedReadsPartitionMethod | None = Field(
        IMPALA.DSEnablePartitionedReadsPartitionMethod._hive_partition,
        alias="_enable_partitioned_reads._partition_method",
        description=(
            "Use this property to set the type of the partitioned to be used when the partitioned reads is enabled."
        ),
    )
    ds_enable_partitioned_reads_table_name: str | None = Field(
        None,
        alias="_enable_partitioned_reads._table_name",
        description=("Use this property to specify the table that will used by the selected partition read method."),
    )
    ds_enable_partitioned_write: bool | None = Field(
        False,
        alias="_enable_partitioned_write",
        description=(
            "Select Yes to insert data into partitioned table. In the insert query, "
            "ORCHESTRATE.<partitioned-column> would be replaced by the column data passed from input link."
        ),
    )
    ds_enable_quoted_ids: bool | None = Field(
        False,
        alias="_enable_quoted_ids",
        description=(
            "Select Yes to enclose the specified table name and column names on the links in quoting strings "
            "when SQL statements are generated. The connector queries the driver to determine the quoting "
            "string. If it fails to obtain this information from the driver, the connector uses the backtick (`) "
            "character as the quoting string. The default is No."
        ),
    )
    ds_generate_sql: bool | None = Field(
        True,
        alias="_generate_sql",
        description=("Select Yes to automatically generate the SQL statements at run time."),
    )
    ds_hive_parameters: str | None = Field(
        None, alias="_hive_parameters", description=("Enter the statement to set the database parameters.")
    )
    ds_hive_parameters_fail_on_error: bool | None = Field(
        False,
        alias="_hive_parameters._fail_on_error",
        description=("Select Yes to stop the job if the database parameters are not set."),
    )
    ds_insert_statement: str = Field(
        None,
        alias="_insert_statement",
        description=("Enter an INSERT statement. The statement is used to insert rows into the database."),
    )
    ds_insert_statement_read_from_file_insert: bool | None = Field(
        False,
        alias="_insert_statement._read_from_file_insert",
        description=(
            "Select Yes to read the INSERT statement from the file that is specified in the INSERT statement property."
        ),
    )
    ds_java_heap_size: int | None = Field(
        256, alias="_java._heap_size", description=("Specify the maximum Java Virtual Machine heap size in megabytes.")
    )
    ds_limit_rows_limit: int | None = Field(
        None,
        alias="_limit_rows._limit",
        description=(
            "Enter the maximum number of rows to be returned by the connector or each node when Partition Read "
            "is enabled."
        ),
    )
    ds_read_mode: IMPALA.DSReadMode | None = Field(
        IMPALA.DSReadMode._select,
        alias="_read_mode",
        description=("Select the mode that you want to use to read from the data source."),
    )
    ds_record_ordering: IMPALA.DSRecordOrdering | None = Field(
        IMPALA.DSRecordOrdering.zero, alias="_record_ordering", description=("Record ordering")
    )
    ds_record_ordering_key_column: list | None = Field([], alias="_record_ordering._key_column")
    ds_select_statement: str = Field(
        None,
        alias="_select_statement",
        description=("Enter a SELECT statement. The statement is used to read rows from the database."),
    )
    ds_select_statement_other_clause: str | None = Field(
        None, alias="_select_statement._other_clause", description=("Other clause")
    )
    ds_select_statement_read_from_file_select: bool | None = Field(
        False,
        alias="_select_statement._read_from_file_select",
        description=(
            "Select Yes to read the SELECT statement from the file that is specified in the SELECT statement property."
        ),
    )
    ds_select_statement_where_clause: str | None = Field(
        None, alias="_select_statement._where_clause", description=("Where clause")
    )
    ds_session_array_size: int | None = Field(1, alias="_session._array_size", description="Array size")
    ds_session_batch_size: int | None = Field(
        2000,
        alias="_session._batch_size",
        description=(
            "Enter the number of records to include in the batch of records for each statement execution. The "
            "value 0 indicates that all input records are passed to the statements in a single batch."
        ),
    )
    ds_session_character_set_for_non_unicode_columns: IMPALA.DSSessionCharacterSetForNonUnicodeColumns | None = Field(
        IMPALA.DSSessionCharacterSetForNonUnicodeColumns._default,
        alias="_session._character_set_for_non_unicode_columns",
        description=(
            "Select the character set option for the values of Char, VarChar and LongVarChar link columns for "
            "which the Extended attribute is not set to Unicode. If you select the Default option, the character "
            "set encoding of the engine host system locale is used. If you select the Custom option, you must "
            "provide the character set name to be used."
        ),
    )
    ds_session_character_set_for_non_unicode_columns_character_set_name: str = Field(
        None,
        alias="_session._character_set_for_non_unicode_columns._character_set_name",
        description=(
            "Specify the name of the character set encoding for the values of Char, VarChar and LongVarChar link "
            "columns for which the Extended attribute is not set to Unicode."
        ),
    )
    ds_session_default_length_for_columns: int | None = Field(
        200,
        alias="_session._default_length_for_columns",
        description=(
            "Enter the default length for the Char, NChar, Binary, VarChar, NVarChar, and VarBinary link columns "
            "for which the Length attribute is not set."
        ),
    )
    ds_session_default_length_for_long_columns: int | None = Field(
        20000,
        alias="_session._default_length_for_long_columns",
        description=(
            "Enter the default length for the LongVarChar, LongNVarChar and LongVarBinary link columns for which "
            "the Length attribute is not set."
        ),
    )
    ds_session_drop_unmatched_fields: bool | None = Field(
        False,
        alias="_session._drop_unmatched_fields",
        description=(
            "Select Yes to drop any fields from the input link for which there are no matching parameters in the "
            "statements configured for the stage. Select No to issue error message when an unmatched field is "
            "present on the link."
        ),
    )
    ds_session_fail_on_truncation: bool | None = Field(
        True,
        alias="_session._fail_on_truncation",
        description=(
            "Select Yes to fail the operation when truncation is detected for the Long Columns (LongVarChar, "
            "LongNVarChar and LongVarBinary). When the the value of this property is set to No, then the "
            "connector continues execution even when data truncation is detected."
        ),
    )
    ds_session_fetch_size: int | None = Field(
        0,
        alias="_session._fetch_size",
        description=(
            "Specify the number of rows that the driver must try to fetch from the data source when the "
            "connector requests a single row. Fetching rows in addition to the row requested by the connector "
            "can improve performance because the driver can complete the subsequent requests for more rows from "
            "the connector locally without a need to access the data source. The default value is 0, which "
            "indicates that the driver optimizes the fetch operation based on its internal logic."
        ),
    )
    ds_session_generate_all_columns_as_unicode: bool | None = Field(
        False,
        alias="_session._generate_all_columns_as_unicode",
        description=(
            "Always generate columns as NChar, NVarChar and LongNVarChar columns instead of Char, VarChar and "
            "LongVarChar columns."
        ),
    )
    ds_session_keep_conductor_connection_alive: bool | None = Field(
        True,
        alias="_session._keep_conductor_connection_alive",
        description=(
            "Select Yes to keep the connection alive in the conductor process while the player processes are "
            "processing records. Select No to close the connection in the conductor process before player "
            "processes start processing records, and to connect again if necessary after the player processes "
            "complete processing the records."
        ),
    )
    ds_session_report_schema_mismatch: bool | None = Field(
        False,
        alias="_session._report_schema_mismatch",
        description=(
            "Select Yes to perform early comparison of the column definitions on the link with the column "
            "definitions in the data source and to issue warning messages for any detected discrepancies which "
            "can result in data corruption. Depending on the environment and the usage scenario the early "
            "detection of discrepancies may not be possible in which case the error messages are reported only "
            "when the actual data corruption is detected."
        ),
    )
    ds_table_action: IMPALA.DSTableAction = Field(
        IMPALA.DSTableAction._append,
        alias="_table_action",
        description=("Select the action to complete before writing data to the table."),
    )
    ds_table_action_generate_create_statement: bool | None = Field(
        True,
        alias="_table_action._generate_create_statement",
        description=(
            "Select Yes to automatically generate the CREATE TABLE statement at run time. Depending on the input "
            "link column data types, the driver, and the data source, the connector might not be able to "
            "determine the corresponding native data types and produce a valid statement."
        ),
    )
    ds_table_action_generate_create_statement_create_statement: str = Field(
        None,
        alias="_table_action._generate_create_statement._create_statement",
        description=("Enter the CREATE TABLE statement to run to create the target database table."),
    )
    ds_table_action_generate_create_statement_fail_on_error: bool | None = Field(
        True,
        alias="_table_action._generate_create_statement._fail_on_error",
        description=("Select Yes to stop the job if the CREATE TABLE statement fails."),
    )
    ds_table_action_generate_create_statement_row_format: (
        IMPALA.DSTableActionGenerateCreateStatementRowFormat | None
    ) = Field(
        IMPALA.DSTableActionGenerateCreateStatementRowFormat._storage_format,
        alias="_table_action._generate_create_statement._row_format",
        description=("Select row format option for table creation."),
    )
    ds_table_action_generate_create_statement_row_format_field_terminator: str | None = Field(
        None,
        alias="_table_action._generate_create_statement._row_format._field_terminator",
        description=("Use this property to specify the field terminator to create the table."),
    )
    ds_table_action_generate_create_statement_row_format_line_terminator: str | None = Field(
        None,
        alias="_table_action._generate_create_statement._row_format._line_terminator",
        description=("Use this property to specify the line terminator to create the table."),
    )
    ds_table_action_generate_create_statement_row_format_serde_library: str = Field(
        None,
        alias="_table_action._generate_create_statement._row_format._serde_library",
        description=(
            "Use this property to specify the library name for SerDe for creating the table e.g "
            "org.apache.hadoop.hive.serde2.columnar.ColumnarSerDe"
        ),
    )
    ds_table_action_generate_create_statement_storage_format: (
        IMPALA.DSTableActionGenerateCreateStatementStorageFormat | None
    ) = Field(
        IMPALA.DSTableActionGenerateCreateStatementStorageFormat._text_file,
        alias="_table_action._generate_create_statement._storage_format",
        description=("Use this property to specify the storage format of the file that stores the data in the table."),
    )
    ds_table_action_generate_create_statement_table_location: str | None = Field(
        None,
        alias="_table_action._generate_create_statement._table_location",
        description=("Use this property to specify the location of the file that serves as storage for the table."),
    )
    ds_table_action_generate_drop_statement: bool | None = Field(
        True,
        alias="_table_action._generate_drop_statement",
        description=("Select Yes to automatically generate the DROP TABLE statement at run time."),
    )
    ds_table_action_generate_drop_statement_drop_statement: str = Field(
        None,
        alias="_table_action._generate_drop_statement._drop_statement",
        description=("Enter the DROP TABLE statement to run to drop the target database table."),
    )
    ds_table_action_generate_drop_statement_fail_on_error: bool | None = Field(
        False,
        alias="_table_action._generate_drop_statement._fail_on_error",
        description=("Select Yes to stop the job if the DROP TABLE statement fails."),
    )
    ds_table_action_generate_truncate_statement: bool | None = Field(
        True,
        alias="_table_action._generate_truncate_statement",
        description=("Select Yes to automatically generate the TRUNCATE TABLE statement at run time."),
    )
    ds_table_action_generate_truncate_statement_fail_on_error: bool | None = Field(
        True,
        alias="_table_action._generate_truncate_statement._fail_on_error",
        description=("Select Yes to stop the job if the TRUNCATE TABLE statement fails."),
    )
    ds_table_action_generate_truncate_statement_truncate_statement: str = Field(
        None,
        alias="_table_action._generate_truncate_statement._truncate_statement",
        description=("Enter the TRUNCATE TABLE statement to run to truncate the target database table."),
    )
    ds_table_action_table_action_first: bool | None = Field(
        True,
        alias="_table_action._table_action_first",
        description=("Select Yes to perform the table action first. Select No to run the Before SQL statements first."),
    )
    ds_table_name: str = Field(
        None,
        alias="_table_name",
        description=("Enter the fully qualified name of the table that you want to access in the data source."),
    )
    ds_transaction_auto_commit_mode: IMPALA.DSTransactionAutoCommitMode | None = Field(
        IMPALA.DSTransactionAutoCommitMode._disable,
        alias="_transaction._auto_commit_mode",
        description=(
            "Configure the stage to run in an auto-commit mode. In auto-commit mode, the transaction is "
            "committed automatically after each statement is executed. When the connector writes records to the "
            "data source, the transaction is committed after each row is written to the data source. When the "
            "stage is configured to run multiple statements on each row, the transaction is committed after each "
            "statement is executed on the row."
        ),
    )
    ds_transaction_begin_end: bool | None = Field(
        False,
        alias="_transaction._begin_end",
        description=(
            "Select Yes to run SQL statements every time when a transaction begins and every time before a "
            "transaction ends."
        ),
    )
    ds_transaction_begin_end_begin_sql: str | None = Field(
        None,
        alias="_transaction._begin_end._begin_sql",
        description=("Enter the SQL statement to run one time before any records are processed in the transaction."),
    )
    ds_transaction_begin_end_end_sql: str | None = Field(
        None,
        alias="_transaction._begin_end._end_sql",
        description=(
            "Enter the SQL statement to run one time in the transaction after all the records were processed in "
            "the transaction and before the transaction completes successfully."
        ),
    )
    ds_transaction_begin_end_run_end_sql_if_no_records_processed: bool | None = Field(
        False,
        alias="_transaction._begin_end._run_end_sql_if_no_records_processed",
        description=(
            "Select Yes to run the End SQL statement irrespective of the number of records processed in the "
            "transaction. Select No to run the End SQL statement only if one or more records were processed in "
            "the transaction."
        ),
    )
    ds_transaction_end_of_wave: IMPALA.DSTransactionEndOfWave | None = Field(
        IMPALA.DSTransactionEndOfWave._no,
        alias="_transaction._end_of_wave",
        description=(
            "Select Yes to generate an end-of-wave record after each wave of records, where the number of "
            "records in each wave is specified in the Record count property. When the Record count property is "
            "set to 0, the end-of-wave records are not generated."
        ),
    )
    ds_transaction_isolation_level: IMPALA.DSTransactionIsolationLevel | None = Field(
        IMPALA.DSTransactionIsolationLevel._default,
        alias="_transaction._isolation_level",
        description=(
            "Specify how the connector manages statements in transactions. As soon as the connector establishes "
            "a connection and issues the first transactional statement, the connector implicitly starts a "
            "transaction that uses the specified isolation level."
        ),
    )
    ds_transaction_record_count: int | None = Field(
        2000,
        alias="_transaction._record_count",
        description=(
            "Specify the number of rows that the stage reads from or writes to the data source in a single "
            "transaction. When this property is set to 0, the transaction is committed only once on each "
            "processing node of the stage after the stage processes all the rows on that node. When rows arrive "
            "on the input link of the stage in waves, the Record count value applies to each wave separately."
        ),
    )
    ds_update_statement: str = Field(
        None,
        alias="_update_statement",
        description=("Enter an UPDATE statement. The statement is used to update rows in the database."),
    )
    ds_update_statement_read_from_file_update: bool | None = Field(
        False,
        alias="_update_statement._read_from_file_update",
        description=(
            "Select Yes to read the UPDATE statement from the file that is specified in the UPDATE statement property."
        ),
    )
    ds_use_datastage: bool | None = Field(
        True,
        alias="_use_datastage",
        description=(
            "The DataStage-specific properties provide more features and granular control of the flow execution, "
            "similar to DataStage 'optimized' connectors."
        ),
    )
    ds_write_mode: IMPALA.DSWriteMode | None = Field(
        IMPALA.DSWriteMode._insert,
        alias="_write_mode",
        description=("Select the mode that you want to use to write to the data source."),
    )
    enable_after_sql: str | None = Field(
        "", alias="before_after.after", description=("Enter the SQL statement to run once after all data is processed.")
    )
    enable_after_sql_node: str | None = Field(
        "",
        alias="before_after.after_node",
        description=("Enter the SQL statement to run once on each node after all data is processed on that node."),
    )
    enable_before_sql: str | None = Field(
        "",
        alias="before_after.before",
        description=("Enter the SQL statement to run once before any data is processed."),
    )
    enable_before_sql_node: str | None = Field(
        "",
        alias="before_after.before_node",
        description=("Enter the SQL statement to run once on each node before any data is processed on that node."),
    )
    enable_flow_acp_control: bool = Field(True, alias="enableFlowAcpControl")
    enable_schemaless_design: bool = Field(False, alias="enableSchemalessDesign")
    execution_mode: IMPALA.ExecutionMode | None = Field(
        IMPALA.ExecutionMode.default_par,
        alias="execmode",
        description=("Specify whether your stage runs sequentially or in parallel."),
    )
    fail_on_error_after_sql: bool | None = Field(
        True,
        alias="before_after.after.fail_on_error",
        description=("Abort the job if there is an error executing a command"),
    )
    fail_on_error_after_sql_node: bool | None = Field(
        True,
        alias="before_after.after_node.fail_on_error",
        description=("Abort the job if there is an error executing a command"),
    )
    fail_on_error_before_sql: bool | None = Field(
        True,
        alias="before_after.before.fail_on_error",
        description=("Abort the job if there is an error executing a command"),
    )
    fail_on_error_before_sql_node: bool | None = Field(
        True,
        alias="before_after.before_node.fail_on_error",
        description=("Abort the job if there is an error executing a command"),
    )
    flow_dirty: str | None = Field("false", alias="flow_dirty")
    generate_unicode_type_columns: bool | None = Field(
        False,
        alias="generate_unicode_columns",
        description=(
            "Generate unicode type columns. This property can be set/is applicable only when runtime column "
            "propagation is used"
        ),
    )
    has_reference_output: bool | None = Field(
        False, alias="has_ref_output", description=("Set to true if stage has an output reference link")
    )
    hide: bool | None = Field(False, alias="hide")
    infer_schema: bool | None = Field(True, alias="rcp", description="Obtain the schema from the data source")
    input_count: int | None = Field(0, alias="input_count")
    input_link_description: list | None = Field("", alias="inputLinkDescription")
    inputcol_properties: list | None = Field([], alias="inputcolProperties")
    key_cols_coll: list | None = Field([], alias="keyColsColl")
    key_cols_coll_ordered: list | None = Field([], alias="keyColsCollOrdered")
    key_cols_coll_robin: list | None = Field([], alias="keyColsCollRobin")
    key_cols_none: list | None = Field([], alias="keyColsNone")
    key_cols_part: list | None = Field([], alias="keyColsPart")
    key_column_names: str | None = Field(
        None,
        alias="key_column_names",
        description=(
            "A comma separated list of column names to override the primary key used for partitioning. The "
            "connector algorithm will try to select partitioning index from this list."
        ),
    )
    lookup_type: IMPALA.LookupType | None = Field(
        IMPALA.LookupType.empty, alias="lookup_type", description=("Lookup Type")
    )
    max_mem_buf_size_ronly: int | None = Field(3145728, alias="max_mem_buf_size_ronly")
    maximum_memory_buffer_size_bytes: int | None = Field(
        3145728,
        alias="max_mem_buf_size",
        description=(
            "Specifies the maximum amount of virtual memory, in bytes, used per buffer. The default size is "
            "3145728 (3 MB)."
        ),
    )
    output_acp_should_hide: bool = Field(True, alias="outputAcpShouldHide")
    output_count: int | None = Field(1, alias="output_count")
    output_link_description: list | None = Field("", alias="outputLinkDescription")
    outputcol_properties: list | None = Field([], alias="outputcolProperties")
    part_stable_coll: bool | None = Field(False, alias="part_stable_coll")
    part_stable_ordered: bool | None = Field(False, alias="part_stable_ordered")
    part_stable_roundrobin_coll: bool | None = Field(False, alias="part_stable_roundrobin_coll")
    part_unique_coll: bool | None = Field(False, alias="part_unique_coll")
    part_unique_ordered: bool | None = Field(False, alias="part_unique_ordered")
    part_unique_roundrobin_coll: bool | None = Field(False, alias="part_unique_roundrobin_coll")
    partition_type: IMPALA.PartitionType | None = Field(
        IMPALA.PartitionType.auto, alias="part_type", description=("Partition type")
    )
    perform_sort: bool | None = Field(False, alias="perform_sort", description="Perform sort")
    perform_sort_coll: bool | None = Field(False, alias="perform_sort_coll")
    perform_sort_modulus: bool | None = Field(False, alias="perform_sort_modulus", description="Perform sort")
    preserve_partitioning: IMPALA.PreservePartitioning | None = Field(
        IMPALA.PreservePartitioning.default_propagate,
        alias="preserve",
        description=("Specify whether to maintain data in current partitions."),
    )
    push_filters: str | None = Field(
        None, alias="push_filters", description=("Filters as Spark SQL to be pushed to the data source")
    )
    pushed_filters: str | None = Field(
        None,
        alias="pushed_filters",
        description=("Inferred property that returns filters as Spark SQL that were pushed to the data source"),
    )
    queue_upper_bound_size_bytes: int | None = Field(
        0,
        alias="queue_upper_size",
        description=("Specifies the maximum amount of data buffered at any time using both memory and disk."),
    )
    queue_upper_size_ronly: int | None = Field(0, alias="queue_upper_size_ronly")
    read_method: IMPALA.ReadMethod | None = Field(
        IMPALA.ReadMethod.general, alias="read_mode", description=("The method for reading records from the table")
    )
    rejected_filters: str | None = Field(
        None,
        alias="rejected_filters",
        description=(
            "Inferred property that returns filters as Spark SQL that could not be pushed to the data source and "
            "still need to be evaluated"
        ),
    )
    row_limit: int | None = Field(None, alias="row_limit", description="The maximum number of rows to return")
    runtime_column_propagation: bool | None = Field(
        None,
        alias="runtime_column_propagation",
        description=("Propagate extra columns that are not defined in the metadata through the rest of the job."),
    )
    sampling_percentage: str | None = Field(
        None, alias="sampling_percentage", description=("Percentage for each row or block to be included in the sample")
    )
    sampling_seed: int | None = Field(
        None, alias="sampling_seed", description=("Seed to be used for getting a repeatable sample")
    )
    sampling_type: IMPALA.SamplingType | None = Field(
        IMPALA.SamplingType.none,
        alias="sampling_type",
        description=("Indicates which data sampling type should be used in the select statement"),
    )
    schema_name: str | None = Field(
        None, alias="schema_name", description=("The name of the schema that contains the table to write to")
    )
    select_statement: str = Field(
        None, alias="select_statement", description=("The SQL SELECT statement for retrieving data from the table")
    )
    show_coll_type: int | None = Field(0, alias="showCollType")
    show_part_type: int | None = Field(1, alias="showPartType")
    show_sort_options: int | None = Field(0, alias="showSortOptions")
    sort_instructions: str | None = Field("", alias="sortInstructions")
    sort_instructions_text: str | None = Field("", alias="sortInstructionsText")
    sorting_key: IMPALA.KeyColSelect | None = Field(IMPALA.KeyColSelect.default, alias="keyColSelect")
    stable: bool | None = Field(
        None, alias="part_stable", description=("Select Stable if you want to preserve previously sorted data sets.")
    )
    stage_description: list | None = Field("", alias="stageDescription", description="Description")
    static_statement: str = Field(
        None,
        alias="static_statement",
        description=("The SQL used for setup operations, for example a CREATE statement"),
    )
    table_action: IMPALA.TableAction | None = Field(
        IMPALA.TableAction.append,
        alias="table_action",
        description=("The action to take on the target table to handle the new data set"),
    )
    table_name: str = Field(None, alias="table_name", description="The name of the table to write to")
    unique: bool | None = Field(
        None,
        alias="part_unique",
        description=(
            "Select Unique to specify that, if multiple records have identical sorting key values, only one "
            "record is retained. If stable sort is also set, the first record is retained."
        ),
    )
    write_mode: IMPALA.WriteMode | None = Field(
        IMPALA.WriteMode.insert, alias="write_mode", description=("The mode for writing records to the target table")
    )

    def _validate_parameters(self) -> tuple[set, set]:
        include = set()
        exclude = set()

        include.add("preserve_partitioning") if (self.output_count and self.output_count > 0) else exclude.add(
            "preserve_partitioning"
        )
        include.add("ds_record_ordering") if (self.input_count and self.input_count > 1) else exclude.add(
            "ds_record_ordering"
        )

        include.add("ds_record_ordering_key_column") if (
            (self.input_count and self.input_count > 1) and (self.ds_record_ordering == 2)
        ) else exclude.add("ds_record_ordering_key_column")
        return include, exclude

    def _validate_source(self) -> tuple[set, set]:
        include = set()
        exclude = set()

        include.add("ds_select_statement_where_clause") if (not self.ds_generate_sql) else exclude.add(
            "ds_select_statement_where_clause"
        )
        include.add("ds_session_report_schema_mismatch") if (self.ds_generate_sql) else exclude.add(
            "ds_session_report_schema_mismatch"
        )
        include.add("ds_before_after_before_sql_node") if (self.ds_before_after) else exclude.add(
            "ds_before_after_before_sql_node"
        )
        include.add("ds_before_after_before_sql_node_fail_on_error") if (self.ds_before_after) else exclude.add(
            "ds_before_after_before_sql_node_fail_on_error"
        )
        include.add("ds_enable_partitioned_reads_partition_method") if (
            (self.ds_enable_partitioned_reads)
            and (
                (
                    self.lookup_type
                    and ((hasattr(self.lookup_type, "value") and not self.lookup_type.value) or (not self.lookup_type))
                )
                or (
                    self.lookup_type
                    and (
                        (hasattr(self.lookup_type, "value") and self.lookup_type.value == "empty")
                        or (self.lookup_type == "empty")
                    )
                )
            )
        ) else exclude.add("ds_enable_partitioned_reads_partition_method")
        include.add("ds_before_after_after_sql_node_fail_on_error") if (self.ds_before_after) else exclude.add(
            "ds_before_after_after_sql_node_fail_on_error"
        )
        include.add("ds_enable_partitioned_reads_table_name") if (
            (self.ds_enable_partitioned_reads_partition_method == "_minimum_and_maximum_range")
            and (
                (
                    self.lookup_type
                    and ((hasattr(self.lookup_type, "value") and not self.lookup_type.value) or (not self.lookup_type))
                )
                or (
                    self.lookup_type
                    and (
                        (hasattr(self.lookup_type, "value") and self.lookup_type.value == "empty")
                        or (self.lookup_type == "empty")
                    )
                )
            )
        ) else exclude.add("ds_enable_partitioned_reads_table_name")
        include.add("ds_before_after_after_sql_read_from_file_after_sql") if (self.ds_before_after) else exclude.add(
            "ds_before_after_after_sql_read_from_file_after_sql"
        )
        include.add("ds_table_name") if (self.ds_generate_sql) else exclude.add("ds_table_name")
        include.add("ds_before_after_after_sql_node_read_from_file_after_sql_node") if (
            self.ds_before_after
        ) else exclude.add("ds_before_after_after_sql_node_read_from_file_after_sql_node")
        include.add("ds_before_after_before_sql_fail_on_error") if (self.ds_before_after) else exclude.add(
            "ds_before_after_before_sql_fail_on_error"
        )
        include.add("ds_select_statement_read_from_file_select") if (not self.ds_generate_sql) else exclude.add(
            "ds_select_statement_read_from_file_select"
        )
        include.add("ds_before_after_before_sql_node_read_from_file_before_sql_node") if (
            self.ds_before_after
        ) else exclude.add("ds_before_after_before_sql_node_read_from_file_before_sql_node")
        include.add("ds_before_after_after_sql_node") if (self.ds_before_after) else exclude.add(
            "ds_before_after_after_sql_node"
        )
        include.add("ds_enable_partitioned_reads_column_name") if (
            (
                (self.ds_enable_partitioned_reads_partition_method == "_minimum_and_maximum_range")
                or (self.ds_enable_partitioned_reads_partition_method == "_modulus")
            )
            and (
                (
                    self.lookup_type
                    and ((hasattr(self.lookup_type, "value") and not self.lookup_type.value) or (not self.lookup_type))
                )
                or (
                    self.lookup_type
                    and (
                        (hasattr(self.lookup_type, "value") and self.lookup_type.value == "empty")
                        or (self.lookup_type == "empty")
                    )
                )
            )
        ) else exclude.add("ds_enable_partitioned_reads_column_name")
        include.add("ds_transaction_begin_end_begin_sql") if (self.ds_transaction_begin_end) else exclude.add(
            "ds_transaction_begin_end_begin_sql"
        )
        include.add("ds_select_statement") if (not self.ds_generate_sql) else exclude.add("ds_select_statement")
        include.add("ds_enable_partitioned_reads") if (
            (
                self.lookup_type
                and ((hasattr(self.lookup_type, "value") and not self.lookup_type.value) or (not self.lookup_type))
            )
            or (
                self.lookup_type
                and (
                    (hasattr(self.lookup_type, "value") and self.lookup_type.value == "empty")
                    or (self.lookup_type == "empty")
                )
            )
        ) else exclude.add("ds_enable_partitioned_reads")
        include.add("ds_session_character_set_for_non_unicode_columns_character_set_name") if (
            self.ds_session_character_set_for_non_unicode_columns == "_custom"
        ) else exclude.add("ds_session_character_set_for_non_unicode_columns_character_set_name")
        include.add("ds_before_after_before_sql") if (self.ds_before_after) else exclude.add(
            "ds_before_after_before_sql"
        )
        include.add("ds_before_after_after_sql_fail_on_error") if (self.ds_before_after) else exclude.add(
            "ds_before_after_after_sql_fail_on_error"
        )
        include.add("ds_transaction_begin_end_end_sql") if (self.ds_transaction_begin_end) else exclude.add(
            "ds_transaction_begin_end_end_sql"
        )
        include.add("ds_before_after_before_sql_read_from_file_before_sql") if (self.ds_before_after) else exclude.add(
            "ds_before_after_before_sql_read_from_file_before_sql"
        )
        include.add("lookup_type") if (self.has_reference_output) else exclude.add("lookup_type")
        include.add("ds_transaction_begin_end_run_end_sql_if_no_records_processed") if (
            self.ds_transaction_begin_end
        ) else exclude.add("ds_transaction_begin_end_run_end_sql_if_no_records_processed")
        include.add("ds_limit_rows_limit") if (
            (
                self.lookup_type
                and ((hasattr(self.lookup_type, "value") and not self.lookup_type.value) or (not self.lookup_type))
            )
            or (
                self.lookup_type
                and (
                    (hasattr(self.lookup_type, "value") and self.lookup_type.value == "empty")
                    or (self.lookup_type == "empty")
                )
            )
        ) else exclude.add("ds_limit_rows_limit")
        include.add("ds_select_statement_other_clause") if (not self.ds_generate_sql) else exclude.add(
            "ds_select_statement_other_clause"
        )
        include.add("ds_before_after_after_sql") if (self.ds_before_after) else exclude.add("ds_before_after_after_sql")
        include.add("select_statement") if (
            (not self.schema_name)
            and (not self.table_name)
            and (
                self.read_method
                and (
                    (hasattr(self.read_method, "value") and self.read_method.value == "select")
                    or (self.read_method == "select")
                )
            )
        ) else exclude.add("select_statement")
        include.add("table_name") if (
            (not self.select_statement)
            and (
                self.read_method
                and (
                    (hasattr(self.read_method, "value") and self.read_method.value == "general")
                    or (self.read_method == "general")
                )
            )
        ) else exclude.add("table_name")
        include.add("schema_name") if (
            (not self.select_statement)
            and (
                self.read_method
                and (
                    (hasattr(self.read_method, "value") and self.read_method.value == "general")
                    or (self.read_method == "general")
                )
            )
        ) else exclude.add("schema_name")
        include.add("ds_select_statement_where_clause") if (
            ((not self.ds_generate_sql) or (self.ds_generate_sql and "#" in str(self.ds_generate_sql)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_select_statement_where_clause")
        include.add("ds_session_report_schema_mismatch") if (
            ((self.ds_generate_sql) or (self.ds_generate_sql and "#" in str(self.ds_generate_sql)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_session_report_schema_mismatch")
        include.add("select_statement") if (
            (
                ((not self.schema_name) or (self.schema_name and "#" in str(self.schema_name)))
                and ((not self.table_name) or (self.table_name and "#" in str(self.table_name)))
                and (
                    (
                        self.read_method
                        and (
                            (hasattr(self.read_method, "value") and self.read_method.value == "select")
                            or (self.read_method == "select")
                        )
                    )
                    or (
                        self.read_method
                        and (
                            (
                                hasattr(self.read_method, "value")
                                and self.read_method.value
                                and "#" in str(self.read_method.value)
                            )
                            or ("#" in str(self.read_method))
                        )
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("select_statement")
        include.add("ds_before_after_before_sql_node") if (
            ((self.ds_before_after) or (self.ds_before_after and "#" in str(self.ds_before_after)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_before_after_before_sql_node")
        include.add("ds_before_after_before_sql_node_fail_on_error") if (
            ((self.ds_before_after) or (self.ds_before_after and "#" in str(self.ds_before_after)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_before_after_before_sql_node_fail_on_error")
        include.add("table_name") if (
            (
                ((not self.select_statement) or (self.select_statement and "#" in str(self.select_statement)))
                and (
                    (
                        self.read_method
                        and (
                            (hasattr(self.read_method, "value") and self.read_method.value == "general")
                            or (self.read_method == "general")
                        )
                    )
                    or (
                        self.read_method
                        and (
                            (
                                hasattr(self.read_method, "value")
                                and self.read_method.value
                                and "#" in str(self.read_method.value)
                            )
                            or ("#" in str(self.read_method))
                        )
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("table_name")
        include.add("ds_enable_partitioned_reads_partition_method") if (
            (
                (
                    (self.ds_enable_partitioned_reads)
                    or (self.ds_enable_partitioned_reads and "#" in str(self.ds_enable_partitioned_reads))
                )
                and (
                    (
                        self.lookup_type
                        and (
                            (hasattr(self.lookup_type, "value") and not self.lookup_type.value)
                            or (not self.lookup_type)
                        )
                    )
                    or (
                        self.lookup_type
                        and (
                            (hasattr(self.lookup_type, "value") and self.lookup_type.value == "empty")
                            or (self.lookup_type == "empty")
                        )
                    )
                    or (
                        self.lookup_type
                        and (
                            (
                                hasattr(self.lookup_type, "value")
                                and self.lookup_type.value
                                and "#" in str(self.lookup_type.value)
                            )
                            or ("#" in str(self.lookup_type))
                        )
                    )
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_enable_partitioned_reads_partition_method")
        include.add("ds_before_after_after_sql_node_fail_on_error") if (
            ((self.ds_before_after) or (self.ds_before_after and "#" in str(self.ds_before_after)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_before_after_after_sql_node_fail_on_error")
        include.add("ds_enable_partitioned_reads_table_name") if (
            (
                (
                    (self.ds_enable_partitioned_reads_partition_method == "_minimum_and_maximum_range")
                    or (
                        self.ds_enable_partitioned_reads_partition_method
                        and "#" in str(self.ds_enable_partitioned_reads_partition_method)
                    )
                )
                and (
                    (
                        self.lookup_type
                        and (
                            (hasattr(self.lookup_type, "value") and not self.lookup_type.value)
                            or (not self.lookup_type)
                        )
                    )
                    or (
                        self.lookup_type
                        and (
                            (hasattr(self.lookup_type, "value") and self.lookup_type.value == "empty")
                            or (self.lookup_type == "empty")
                        )
                    )
                    or (
                        self.lookup_type
                        and (
                            (
                                hasattr(self.lookup_type, "value")
                                and self.lookup_type.value
                                and "#" in str(self.lookup_type.value)
                            )
                            or ("#" in str(self.lookup_type))
                        )
                    )
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_enable_partitioned_reads_table_name")
        include.add("ds_before_after_after_sql_read_from_file_after_sql") if (
            ((self.ds_before_after) or (self.ds_before_after and "#" in str(self.ds_before_after)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_before_after_after_sql_read_from_file_after_sql")
        include.add("ds_table_name") if (
            ((self.ds_generate_sql) or (self.ds_generate_sql and "#" in str(self.ds_generate_sql)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_table_name")
        include.add("ds_before_after_after_sql_node_read_from_file_after_sql_node") if (
            ((self.ds_before_after) or (self.ds_before_after and "#" in str(self.ds_before_after)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_before_after_after_sql_node_read_from_file_after_sql_node")
        include.add("ds_before_after_before_sql_fail_on_error") if (
            ((self.ds_before_after) or (self.ds_before_after and "#" in str(self.ds_before_after)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_before_after_before_sql_fail_on_error")
        include.add("ds_select_statement_read_from_file_select") if (
            ((not self.ds_generate_sql) or (self.ds_generate_sql and "#" in str(self.ds_generate_sql)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_select_statement_read_from_file_select")
        include.add("ds_before_after_before_sql_node_read_from_file_before_sql_node") if (
            ((self.ds_before_after) or (self.ds_before_after and "#" in str(self.ds_before_after)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_before_after_before_sql_node_read_from_file_before_sql_node")
        include.add("ds_before_after_after_sql_node") if (
            ((self.ds_before_after) or (self.ds_before_after and "#" in str(self.ds_before_after)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_before_after_after_sql_node")
        include.add("ds_enable_partitioned_reads_column_name") if (
            (
                (
                    (self.ds_enable_partitioned_reads_partition_method == "_minimum_and_maximum_range")
                    or (self.ds_enable_partitioned_reads_partition_method == "_modulus")
                    or (
                        self.ds_enable_partitioned_reads_partition_method
                        and "#" in str(self.ds_enable_partitioned_reads_partition_method)
                    )
                )
                and (
                    (
                        self.lookup_type
                        and (
                            (hasattr(self.lookup_type, "value") and not self.lookup_type.value)
                            or (not self.lookup_type)
                        )
                    )
                    or (
                        self.lookup_type
                        and (
                            (hasattr(self.lookup_type, "value") and self.lookup_type.value == "empty")
                            or (self.lookup_type == "empty")
                        )
                    )
                    or (
                        self.lookup_type
                        and (
                            (
                                hasattr(self.lookup_type, "value")
                                and self.lookup_type.value
                                and "#" in str(self.lookup_type.value)
                            )
                            or ("#" in str(self.lookup_type))
                        )
                    )
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_enable_partitioned_reads_column_name")
        include.add("ds_transaction_begin_end_begin_sql") if (
            (self.ds_transaction_begin_end) and (self.ds_use_datastage)
        ) else exclude.add("ds_transaction_begin_end_begin_sql")
        include.add("ds_select_statement") if (
            ((not self.ds_generate_sql) or (self.ds_generate_sql and "#" in str(self.ds_generate_sql)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_select_statement")
        include.add("ds_enable_partitioned_reads") if (
            (
                (
                    self.lookup_type
                    and ((hasattr(self.lookup_type, "value") and not self.lookup_type.value) or (not self.lookup_type))
                )
                or (
                    self.lookup_type
                    and (
                        (hasattr(self.lookup_type, "value") and self.lookup_type.value == "empty")
                        or (self.lookup_type == "empty")
                    )
                )
                or (
                    self.lookup_type
                    and (
                        (
                            hasattr(self.lookup_type, "value")
                            and self.lookup_type.value
                            and "#" in str(self.lookup_type.value)
                        )
                        or ("#" in str(self.lookup_type))
                    )
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_enable_partitioned_reads")
        include.add("schema_name") if (
            (
                ((not self.select_statement) or (self.select_statement and "#" in str(self.select_statement)))
                and (
                    (
                        self.read_method
                        and (
                            (hasattr(self.read_method, "value") and self.read_method.value == "general")
                            or (self.read_method == "general")
                        )
                    )
                    or (
                        self.read_method
                        and (
                            (
                                hasattr(self.read_method, "value")
                                and self.read_method.value
                                and "#" in str(self.read_method.value)
                            )
                            or ("#" in str(self.read_method))
                        )
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("schema_name")
        include.add("ds_session_character_set_for_non_unicode_columns_character_set_name") if (
            (
                (self.ds_session_character_set_for_non_unicode_columns == "_custom")
                or (
                    self.ds_session_character_set_for_non_unicode_columns
                    and "#" in str(self.ds_session_character_set_for_non_unicode_columns)
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_session_character_set_for_non_unicode_columns_character_set_name")
        include.add("ds_before_after_before_sql") if (
            ((self.ds_before_after) or (self.ds_before_after and "#" in str(self.ds_before_after)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_before_after_before_sql")
        include.add("ds_before_after_after_sql_fail_on_error") if (
            ((self.ds_before_after) or (self.ds_before_after and "#" in str(self.ds_before_after)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_before_after_after_sql_fail_on_error")
        include.add("ds_transaction_begin_end_end_sql") if (
            (self.ds_transaction_begin_end) and (self.ds_use_datastage)
        ) else exclude.add("ds_transaction_begin_end_end_sql")
        include.add("ds_before_after_before_sql_read_from_file_before_sql") if (
            ((self.ds_before_after) or (self.ds_before_after and "#" in str(self.ds_before_after)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_before_after_before_sql_read_from_file_before_sql")
        include.add("lookup_type") if ((self.has_reference_output) and (self.ds_use_datastage)) else exclude.add(
            "lookup_type"
        )
        include.add("ds_transaction_begin_end_run_end_sql_if_no_records_processed") if (
            (self.ds_transaction_begin_end) and (self.ds_use_datastage)
        ) else exclude.add("ds_transaction_begin_end_run_end_sql_if_no_records_processed")
        include.add("ds_limit_rows_limit") if (
            (
                (
                    self.lookup_type
                    and ((hasattr(self.lookup_type, "value") and not self.lookup_type.value) or (not self.lookup_type))
                )
                or (
                    self.lookup_type
                    and (
                        (hasattr(self.lookup_type, "value") and self.lookup_type.value == "empty")
                        or (self.lookup_type == "empty")
                    )
                )
                or (
                    self.lookup_type
                    and (
                        (
                            hasattr(self.lookup_type, "value")
                            and self.lookup_type.value
                            and "#" in str(self.lookup_type.value)
                        )
                        or ("#" in str(self.lookup_type))
                    )
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_limit_rows_limit")
        include.add("ds_select_statement_other_clause") if (
            ((not self.ds_generate_sql) or (self.ds_generate_sql and "#" in str(self.ds_generate_sql)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_select_statement_other_clause")
        include.add("ds_before_after_after_sql") if (
            ((self.ds_before_after) or (self.ds_before_after and "#" in str(self.ds_before_after)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_before_after_after_sql")
        include.add("pushed_filters") if (not self.ds_use_datastage) else exclude.add("pushed_filters")
        include.add("ds_session_keep_conductor_connection_alive") if (self.ds_use_datastage) else exclude.add(
            "ds_session_keep_conductor_connection_alive"
        )
        include.add("rejected_filters") if (not self.ds_use_datastage) else exclude.add("rejected_filters")
        include.add("ds_session_fail_on_truncation") if (self.ds_use_datastage) else exclude.add(
            "ds_session_fail_on_truncation"
        )
        include.add("ds_session_fetch_size") if (self.ds_use_datastage) else exclude.add("ds_session_fetch_size")
        include.add("sampling_type") if (not self.ds_use_datastage) else exclude.add("sampling_type")
        include.add("ds_transaction_begin_end") if (self.ds_use_datastage) else exclude.add("ds_transaction_begin_end")
        include.add("ds_session_generate_all_columns_as_unicode") if (self.ds_use_datastage) else exclude.add(
            "ds_session_generate_all_columns_as_unicode"
        )
        include.add("fail_on_error_after_sql_node") if (not self.ds_use_datastage) else exclude.add(
            "fail_on_error_after_sql_node"
        )
        include.add("has_reference_output") if (self.ds_use_datastage) else exclude.add("has_reference_output")
        include.add("ds_transaction_auto_commit_mode") if (self.ds_use_datastage) else exclude.add(
            "ds_transaction_auto_commit_mode"
        )
        include.add("fail_on_error_before_sql") if (not self.ds_use_datastage) else exclude.add(
            "fail_on_error_before_sql"
        )
        include.add("read_method") if (not self.ds_use_datastage) else exclude.add("read_method")
        include.add("ds_hive_parameters") if (self.ds_use_datastage) else exclude.add("ds_hive_parameters")
        include.add("ds_hive_parameters_fail_on_error") if (self.ds_use_datastage) else exclude.add(
            "ds_hive_parameters_fail_on_error"
        )
        include.add("key_column_names") if (not self.ds_use_datastage) else exclude.add("key_column_names")
        include.add("enable_after_sql_node") if (not self.ds_use_datastage) else exclude.add("enable_after_sql_node")
        include.add("sampling_seed") if (not self.ds_use_datastage) else exclude.add("sampling_seed")
        include.add("fail_on_error_before_sql_node") if (not self.ds_use_datastage) else exclude.add(
            "fail_on_error_before_sql_node"
        )
        include.add("sampling_percentage") if (not self.ds_use_datastage) else exclude.add("sampling_percentage")
        include.add("ds_transaction_end_of_wave") if (self.ds_use_datastage) else exclude.add(
            "ds_transaction_end_of_wave"
        )
        include.add("ds_session_default_length_for_columns") if (self.ds_use_datastage) else exclude.add(
            "ds_session_default_length_for_columns"
        )
        include.add("ds_read_mode") if (self.ds_use_datastage) else exclude.add("ds_read_mode")
        include.add("enable_before_sql") if (not self.ds_use_datastage) else exclude.add("enable_before_sql")
        include.add("ds_session_default_length_for_long_columns") if (self.ds_use_datastage) else exclude.add(
            "ds_session_default_length_for_long_columns"
        )
        include.add("ds_enable_quoted_ids") if (self.ds_use_datastage) else exclude.add("ds_enable_quoted_ids")
        include.add("byte_limit") if (not self.ds_use_datastage) else exclude.add("byte_limit")
        include.add("ds_session_array_size") if (self.ds_use_datastage) else exclude.add("ds_session_array_size")
        include.add("default_maximum_length_for_columns") if (not self.ds_use_datastage) else exclude.add(
            "default_maximum_length_for_columns"
        )
        include.add("enable_after_sql") if (not self.ds_use_datastage) else exclude.add("enable_after_sql")
        include.add("generate_unicode_type_columns") if (not self.ds_use_datastage) else exclude.add(
            "generate_unicode_type_columns"
        )
        include.add("infer_schema") if (not self.ds_use_datastage) else exclude.add("infer_schema")
        include.add("ds_transaction_isolation_level") if (self.ds_use_datastage) else exclude.add(
            "ds_transaction_isolation_level"
        )
        include.add("ds_transaction_record_count") if (self.ds_use_datastage) else exclude.add(
            "ds_transaction_record_count"
        )
        include.add("enable_before_sql_node") if (not self.ds_use_datastage) else exclude.add("enable_before_sql_node")
        include.add("ds_generate_sql") if (self.ds_use_datastage) else exclude.add("ds_generate_sql")
        include.add("ds_before_after") if (self.ds_use_datastage) else exclude.add("ds_before_after")
        include.add("decimal_rounding_mode") if (not self.ds_use_datastage) else exclude.add("decimal_rounding_mode")
        include.add("row_limit") if (not self.ds_use_datastage) else exclude.add("row_limit")
        include.add("ds_session_character_set_for_non_unicode_columns") if (self.ds_use_datastage) else exclude.add(
            "ds_session_character_set_for_non_unicode_columns"
        )
        include.add("fail_on_error_after_sql") if (not self.ds_use_datastage) else exclude.add(
            "fail_on_error_after_sql"
        )
        include.add("push_filters") if (not self.ds_use_datastage) else exclude.add("push_filters")
        include.add("maximum_memory_buffer_size_bytes") if (self.buffering_mode != "nobuffer") else exclude.add(
            "maximum_memory_buffer_size_bytes"
        )
        include.add("buffer_free_run_percent") if (self.buffering_mode != "nobuffer") else exclude.add(
            "buffer_free_run_percent"
        )
        include.add("queue_upper_bound_size_bytes") if (self.buffering_mode != "nobuffer") else exclude.add(
            "queue_upper_bound_size_bytes"
        )
        include.add("disk_write_increment_bytes") if (self.buffering_mode != "nobuffer") else exclude.add(
            "disk_write_increment_bytes"
        )
        include.add("ds_record_ordering_key_column") if (
            (self.input_count and self.input_count > 1) and (self.ds_record_ordering == 2)
        ) else exclude.add("ds_record_ordering_key_column")
        include.add("runtime_column_propagation") if (not self.enable_schemaless_design) else exclude.add(
            "runtime_column_propagation"
        )
        include.add("column_metadata_change_propagation") if (not self.output_acp_should_hide) else exclude.add(
            "column_metadata_change_propagation"
        )
        include.add("max_mem_buf_size_ronly") if (self.buf_mode_ronly != "nobuffer") else exclude.add(
            "max_mem_buf_size_ronly"
        )
        include.add("buf_free_run_ronly") if (self.buf_mode_ronly != "nobuffer") else exclude.add("buf_free_run_ronly")
        include.add("queue_upper_size_ronly") if (self.buf_mode_ronly != "nobuffer") else exclude.add(
            "queue_upper_size_ronly"
        )
        include.add("disk_write_inc_ronly") if (self.buf_mode_ronly != "nobuffer") else exclude.add(
            "disk_write_inc_ronly"
        )
        include.add("stable") if (
            (self.show_part_type)
            and (self.partition_type != "auto")
            and (self.partition_type != "db2connector")
            and (self.show_sort_options)
        ) else exclude.add("stable")
        include.add("unique") if (
            (self.show_part_type)
            and (self.partition_type != "auto")
            and (self.partition_type != "db2connector")
            and (self.show_sort_options)
        ) else exclude.add("unique")
        include.add("key_cols_part") if (
            (
                (self.show_part_type)
                and (not self.show_coll_type)
                and (self.partition_type != "auto")
                and (self.partition_type != "db2connector")
                and (self.partition_type != "modulus")
            )
            or (
                (self.show_part_type)
                and (not self.show_coll_type)
                and (self.partition_type == "modulus")
                and (self.perform_sort_modulus)
            )
        ) else exclude.add("key_cols_part")
        include.add("db2_source_connection_required") if (
            (self.partition_type == "db2part") and (self.show_part_type)
        ) else exclude.add("db2_source_connection_required")
        include.add("db2_database_name") if (
            (self.partition_type == "db2part") and (self.show_part_type)
        ) else exclude.add("db2_database_name")
        include.add("db2_instance_name") if (
            (self.partition_type == "db2part") and (self.show_part_type)
        ) else exclude.add("db2_instance_name")
        include.add("db2_table_name") if (
            (self.partition_type == "db2part") and (self.show_part_type)
        ) else exclude.add("db2_table_name")
        include.add("perform_sort") if (
            (self.show_part_type) and ((self.partition_type == "hash") or (self.partition_type == "range"))
        ) else exclude.add("perform_sort")
        include.add("perform_sort_modulus") if (
            (self.show_part_type) and (self.partition_type == "modulus")
        ) else exclude.add("perform_sort_modulus")
        include.add("sorting_key") if (
            (self.show_part_type) and (self.partition_type == "modulus") and (not self.perform_sort_modulus)
        ) else exclude.add("sorting_key")
        include.add("sort_instructions") if (
            (self.show_part_type)
            and (
                (self.partition_type == "db2part")
                or (self.partition_type == "entire")
                or (self.partition_type == "random")
                or (self.partition_type == "roundrobin")
                or (self.partition_type == "same")
            )
        ) else exclude.add("sort_instructions")
        include.add("sort_instructions_text") if (
            (self.show_part_type)
            and (
                (self.partition_type == "db2part")
                or (self.partition_type == "entire")
                or (self.partition_type == "random")
                or (self.partition_type == "roundrobin")
                or (self.partition_type == "same")
            )
        ) else exclude.add("sort_instructions_text")
        include.add("collecting") if (self.show_coll_type) else exclude.add("collecting")
        include.add("partition_type") if (self.show_part_type) else exclude.add("partition_type")
        include.add("perform_sort_coll") if (
            (
                (self.show_coll_type)
                and (
                    (self.collecting == "ordered")
                    or (self.collecting == "roundrobin_coll")
                    or (self.collecting == "sortmerge")
                )
            )
            or ((not self.show_part_type) and (not self.show_coll_type))
        ) else exclude.add("perform_sort_coll")
        include.add("key_cols_coll") if (
            (self.show_coll_type)
            and (not self.show_part_type)
            and (self.collecting != "auto")
            and ((self.collecting == "sortmerge") or (self.perform_sort_coll))
        ) else exclude.add("key_cols_coll")
        include.add("key_cols_none") if (
            (not self.show_part_type) and (not self.show_coll_type) and (self.perform_sort_coll)
        ) else exclude.add("key_cols_none")
        include.add("part_stable_coll") if (
            (self.perform_sort_coll)
            and (
                (
                    (not self.show_part_type)
                    and (self.show_coll_type)
                    and (self.collecting != "auto")
                    and (self.show_sort_options)
                )
                or ((not self.show_part_type) and (not self.show_coll_type) and (self.show_sort_options))
            )
        ) else exclude.add("part_stable_coll")
        include.add("part_unique_coll") if (
            (self.perform_sort_coll)
            and (
                (
                    (not self.show_part_type)
                    and (self.show_coll_type)
                    and (self.collecting != "auto")
                    and (self.show_sort_options)
                )
                or ((not self.show_part_type) and (not self.show_coll_type) and (self.show_sort_options))
            )
        ) else exclude.add("part_unique_coll")
        include.add("defer_credentials") if (()) else exclude.add("defer_credentials")
        include.add("ds_transaction_begin_end_begin_sql") if (
            self.ds_transaction_begin_end == "true" or self.ds_transaction_begin_end is True
        ) else exclude.add("ds_transaction_begin_end_begin_sql")
        include.add("ds_before_after_before_sql_node_read_from_file_before_sql_node") if (
            self.ds_before_after == "true" or self.ds_before_after is True
        ) else exclude.add("ds_before_after_before_sql_node_read_from_file_before_sql_node")
        include.add("ds_session_character_set_for_non_unicode_columns_character_set_name") if (
            self.ds_session_character_set_for_non_unicode_columns
            and "_custom" in str(self.ds_session_character_set_for_non_unicode_columns)
        ) else exclude.add("ds_session_character_set_for_non_unicode_columns_character_set_name")
        include.add("ds_before_after_after_sql_fail_on_error") if (
            self.ds_before_after == "true" or self.ds_before_after is True
        ) else exclude.add("ds_before_after_after_sql_fail_on_error")
        include.add("ds_session_report_schema_mismatch") if (
            self.ds_generate_sql and "true" in str(self.ds_generate_sql)
        ) else exclude.add("ds_session_report_schema_mismatch")
        include.add("ds_select_statement_other_clause") if (
            self.ds_generate_sql == "false" or self.ds_generate_sql is False
        ) else exclude.add("ds_select_statement_other_clause")
        include.add("ds_transaction_begin_end_run_end_sql_if_no_records_processed") if (
            self.ds_transaction_begin_end == "true" or self.ds_transaction_begin_end is True
        ) else exclude.add("ds_transaction_begin_end_run_end_sql_if_no_records_processed")
        include.add("ds_enable_partitioned_reads_column_name") if (
            self.ds_enable_partitioned_reads_partition_method
            and "_minimum_and_maximum_range" in str(self.ds_enable_partitioned_reads_partition_method)
            and self.ds_enable_partitioned_reads_partition_method
            and "_modulus" in str(self.ds_enable_partitioned_reads_partition_method)
        ) and (
            (
                self.lookup_type
                and ((hasattr(self.lookup_type, "value") and not self.lookup_type.value) or (not self.lookup_type))
            )
            or (
                self.lookup_type
                and (
                    (hasattr(self.lookup_type, "value") and self.lookup_type.value == "empty")
                    or (self.lookup_type == "empty")
                )
            )
        ) else exclude.add("ds_enable_partitioned_reads_column_name")
        include.add("ds_before_after_before_sql") if (
            self.ds_before_after == "true" or self.ds_before_after is True
        ) else exclude.add("ds_before_after_before_sql")
        include.add("ds_select_statement") if (
            self.ds_generate_sql == "false" or self.ds_generate_sql is False
        ) else exclude.add("ds_select_statement")
        include.add("ds_before_after_after_sql_node") if (
            self.ds_before_after == "true" or self.ds_before_after is True
        ) else exclude.add("ds_before_after_after_sql_node")
        include.add("ds_before_after_before_sql_read_from_file_before_sql") if (
            self.ds_before_after == "true" or self.ds_before_after is True
        ) else exclude.add("ds_before_after_before_sql_read_from_file_before_sql")
        include.add("ds_before_after_after_sql_node_read_from_file_after_sql_node") if (
            self.ds_before_after == "true" or self.ds_before_after is True
        ) else exclude.add("ds_before_after_after_sql_node_read_from_file_after_sql_node")
        include.add("ds_transaction_begin_end_end_sql") if (
            self.ds_transaction_begin_end == "true" or self.ds_transaction_begin_end is True
        ) else exclude.add("ds_transaction_begin_end_end_sql")
        include.add("ds_before_after_after_sql_read_from_file_after_sql") if (
            self.ds_before_after == "true" or self.ds_before_after is True
        ) else exclude.add("ds_before_after_after_sql_read_from_file_after_sql")
        include.add("ds_table_name") if (
            self.ds_generate_sql == "true" or self.ds_generate_sql is True
        ) else exclude.add("ds_table_name")
        include.add("ds_enable_partitioned_reads") if (
            self.lookup_type
            and ((hasattr(self.lookup_type, "value") and not self.lookup_type.value) or (not self.lookup_type))
        ) or (
            self.lookup_type
            and (
                (hasattr(self.lookup_type, "value") and self.lookup_type.value == "empty")
                or (self.lookup_type == "empty")
            )
        ) else exclude.add("ds_enable_partitioned_reads")
        include.add("ds_enable_partitioned_reads_partition_method") if (
            self.ds_enable_partitioned_reads == "true" or self.ds_enable_partitioned_reads is True
        ) and (
            (
                self.lookup_type
                and ((hasattr(self.lookup_type, "value") and not self.lookup_type.value) or (not self.lookup_type))
            )
            or (
                self.lookup_type
                and (
                    (hasattr(self.lookup_type, "value") and self.lookup_type.value == "empty")
                    or (self.lookup_type == "empty")
                )
            )
        ) else exclude.add("ds_enable_partitioned_reads_partition_method")
        include.add("lookup_type") if (
            self.has_reference_output == "true" or self.has_reference_output is True
        ) else exclude.add("lookup_type")
        include.add("ds_limit_rows_limit") if (
            self.lookup_type
            and ((hasattr(self.lookup_type, "value") and not self.lookup_type.value) or (not self.lookup_type))
        ) or (
            self.lookup_type
            and (
                (hasattr(self.lookup_type, "value") and self.lookup_type.value == "empty")
                or (self.lookup_type == "empty")
            )
        ) else exclude.add("ds_limit_rows_limit")
        include.add("ds_before_after_before_sql_node_fail_on_error") if (
            self.ds_before_after == "true" or self.ds_before_after is True
        ) else exclude.add("ds_before_after_before_sql_node_fail_on_error")
        include.add("schema_name") if (not self.select_statement) and (
            self.read_method
            and (
                (hasattr(self.read_method, "value") and self.read_method.value == "general")
                or (self.read_method == "general")
            )
        ) else exclude.add("schema_name")
        include.add("ds_select_statement_read_from_file_select") if (
            self.ds_generate_sql == "false" or self.ds_generate_sql is False
        ) else exclude.add("ds_select_statement_read_from_file_select")
        include.add("ds_before_after_before_sql_fail_on_error") if (
            self.ds_before_after == "true" or self.ds_before_after is True
        ) else exclude.add("ds_before_after_before_sql_fail_on_error")
        include.add("table_name") if (not self.select_statement) and (
            self.read_method
            and (
                (hasattr(self.read_method, "value") and self.read_method.value == "general")
                or (self.read_method == "general")
            )
        ) else exclude.add("table_name")
        include.add("select_statement") if (not self.schema_name) and (not self.table_name) and (
            self.read_method
            and (
                (hasattr(self.read_method, "value") and self.read_method.value == "select")
                or (self.read_method == "select")
            )
        ) else exclude.add("select_statement")
        include.add("ds_before_after_after_sql") if (
            self.ds_before_after == "true" or self.ds_before_after is True
        ) else exclude.add("ds_before_after_after_sql")
        include.add("ds_select_statement_where_clause") if (
            self.ds_generate_sql == "false" or self.ds_generate_sql is False
        ) else exclude.add("ds_select_statement_where_clause")
        include.add("ds_enable_partitioned_reads_table_name") if (
            self.ds_enable_partitioned_reads_partition_method == "_minimum_and_maximum_range"
        ) and (
            (
                self.lookup_type
                and ((hasattr(self.lookup_type, "value") and not self.lookup_type.value) or (not self.lookup_type))
            )
            or (
                self.lookup_type
                and (
                    (hasattr(self.lookup_type, "value") and self.lookup_type.value == "empty")
                    or (self.lookup_type == "empty")
                )
            )
        ) else exclude.add("ds_enable_partitioned_reads_table_name")
        include.add("ds_before_after_after_sql_node_fail_on_error") if (
            self.ds_before_after == "true" or self.ds_before_after is True
        ) else exclude.add("ds_before_after_after_sql_node_fail_on_error")
        include.add("ds_before_after_before_sql_node") if (
            self.ds_before_after == "true" or self.ds_before_after is True
        ) else exclude.add("ds_before_after_before_sql_node")
        return include, exclude

    def _validate_target(self) -> tuple[set, set]:
        include = set()
        exclude = set()

        include.add("ds_table_action_generate_create_statement_row_format_line_terminator") if (
            self.ds_table_action_generate_create_statement_row_format == "_delimited"
        ) else exclude.add("ds_table_action_generate_create_statement_row_format_line_terminator")
        include.add("ds_table_action_generate_create_statement_row_format") if (
            self.ds_table_action_generate_create_statement
        ) else exclude.add("ds_table_action_generate_create_statement_row_format")
        include.add("ds_table_action_generate_create_statement_storage_format") if (
            self.ds_table_action_generate_create_statement
        ) else exclude.add("ds_table_action_generate_create_statement_storage_format")
        include.add("ds_insert_statement_read_from_file_insert") if (
            (not self.ds_generate_sql) and (self.ds_write_mode == "_insert")
        ) else exclude.add("ds_insert_statement_read_from_file_insert")
        include.add("ds_table_name") if (
            (self.ds_table_action_generate_create_statement)
            or (self.ds_table_action_generate_drop_statement)
            or (self.ds_table_action_generate_truncate_statement)
            or (self.ds_generate_sql)
        ) else exclude.add("ds_table_name")
        include.add("ds_table_action_generate_drop_statement") if (self.ds_table_action == "_replace") else exclude.add(
            "ds_table_action_generate_drop_statement"
        )
        include.add("ds_delete_statement_read_from_file_delete") if (
            (not self.ds_generate_sql) and (self.ds_write_mode == "_delete")
        ) else exclude.add("ds_delete_statement_read_from_file_delete")
        include.add("ds_table_action_generate_truncate_statement_fail_on_error") if (
            self.ds_table_action_generate_truncate_statement
        ) else exclude.add("ds_table_action_generate_truncate_statement_fail_on_error")
        include.add("ds_table_action_generate_create_statement_fail_on_error") if (
            self.ds_table_action_generate_create_statement
        ) else exclude.add("ds_table_action_generate_create_statement_fail_on_error")
        include.add("ds_table_action_generate_create_statement_table_location") if (
            self.ds_table_action_generate_create_statement
        ) else exclude.add("ds_table_action_generate_create_statement_table_location")
        include.add("ds_update_statement_read_from_file_update") if (
            (not self.ds_generate_sql) and (self.ds_write_mode == "_update")
        ) else exclude.add("ds_update_statement_read_from_file_update")
        include.add("ds_enable_partitioned_write") if (self.ds_write_mode == "_insert") else exclude.add(
            "ds_enable_partitioned_write"
        )
        include.add("ds_table_action_generate_create_statement_create_statement") if (
            not self.ds_table_action_generate_create_statement
        ) else exclude.add("ds_table_action_generate_create_statement_create_statement")
        include.add("ds_table_action_generate_create_statement_row_format_field_terminator") if (
            self.ds_table_action_generate_create_statement_row_format == "_delimited"
        ) else exclude.add("ds_table_action_generate_create_statement_row_format_field_terminator")
        include.add("ds_insert_statement") if (
            (not self.ds_generate_sql) and (self.ds_write_mode == "_insert")
        ) else exclude.add("ds_insert_statement")
        include.add("ds_table_action_generate_drop_statement_drop_statement") if (
            not self.ds_table_action_generate_drop_statement
        ) else exclude.add("ds_table_action_generate_drop_statement_drop_statement")
        include.add("ds_table_action_generate_truncate_statement") if (
            self.ds_table_action == "_truncate"
        ) else exclude.add("ds_table_action_generate_truncate_statement")
        include.add("ds_table_action_table_action_first") if (
            (self.ds_table_action == "_create")
            or (self.ds_table_action == "_replace")
            or (self.ds_table_action == "_truncate")
        ) else exclude.add("ds_table_action_table_action_first")
        include.add("ds_custom_statements_read_from_file_custom") if (self.ds_write_mode == "_custom") else exclude.add(
            "ds_custom_statements_read_from_file_custom"
        )
        include.add("ds_table_action_generate_truncate_statement_truncate_statement") if (
            not self.ds_table_action_generate_truncate_statement
        ) else exclude.add("ds_table_action_generate_truncate_statement_truncate_statement")
        include.add("ds_session_batch_size") if (
            (self.ds_write_mode == "_custom")
            or (self.ds_write_mode == "_delete")
            or (self.ds_write_mode == "_insert")
            or (self.ds_write_mode == "_update")
        ) else exclude.add("ds_session_batch_size")
        include.add("ds_table_action_generate_drop_statement_fail_on_error") if (
            self.ds_table_action_generate_drop_statement
        ) else exclude.add("ds_table_action_generate_drop_statement_fail_on_error")
        include.add("ds_generate_sql") if (
            (self.ds_write_mode == "_delete") or (self.ds_write_mode == "_insert") or (self.ds_write_mode == "_update")
        ) else exclude.add("ds_generate_sql")
        include.add("ds_delete_statement") if (
            (not self.ds_generate_sql) and (self.ds_write_mode == "_delete")
        ) else exclude.add("ds_delete_statement")
        include.add("ds_update_statement") if (
            (not self.ds_generate_sql) and (self.ds_write_mode == "_update")
        ) else exclude.add("ds_update_statement")
        include.add("ds_table_action_generate_create_statement_row_format_serde_library") if (
            self.ds_table_action_generate_create_statement_row_format == "_ser_de"
        ) else exclude.add("ds_table_action_generate_create_statement_row_format_serde_library")
        include.add("ds_table_action_generate_create_statement") if (
            (self.ds_table_action == "_create") or (self.ds_table_action == "_replace")
        ) else exclude.add("ds_table_action_generate_create_statement")
        include.add("ds_custom_statements") if (self.ds_write_mode == "_custom") else exclude.add(
            "ds_custom_statements"
        )
        include.add("table_name") if (
            (not self.static_statement)
            and (
                self.write_mode
                and (
                    (hasattr(self.write_mode, "value") and self.write_mode.value != "static_statement")
                    or (self.write_mode != "static_statement")
                )
            )
        ) else exclude.add("table_name")
        include.add("table_action") if (
            (not self.static_statement)
            and (
                (
                    self.write_mode
                    and (
                        (hasattr(self.write_mode, "value") and self.write_mode.value != "static_statement")
                        or (self.write_mode != "static_statement")
                    )
                )
                and (
                    self.write_mode
                    and (
                        (hasattr(self.write_mode, "value") and self.write_mode.value != "update_statement")
                        or (self.write_mode != "update_statement")
                    )
                )
            )
        ) else exclude.add("table_action")
        include.add("schema_name") if (
            (not self.static_statement)
            and (
                self.write_mode
                and (
                    (hasattr(self.write_mode, "value") and self.write_mode.value != "static_statement")
                    or (self.write_mode != "static_statement")
                )
            )
        ) else exclude.add("schema_name")
        include.add("static_statement") if (
            (not self.schema_name)
            and (not self.table_name)
            and (
                self.write_mode
                and (
                    (hasattr(self.write_mode, "value") and self.write_mode.value == "static_statement")
                    or (self.write_mode == "static_statement")
                )
            )
        ) else exclude.add("static_statement")
        include.add("ds_session_report_schema_mismatch") if (
            ((self.ds_generate_sql) or (self.ds_generate_sql and "#" in str(self.ds_generate_sql)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_session_report_schema_mismatch")
        include.add("ds_table_action_generate_create_statement_row_format_line_terminator") if (
            (
                (self.ds_table_action_generate_create_statement_row_format == "_delimited")
                or (
                    self.ds_table_action_generate_create_statement_row_format
                    and "#" in str(self.ds_table_action_generate_create_statement_row_format)
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_table_action_generate_create_statement_row_format_line_terminator")
        include.add("table_name") if (
            (
                ((not self.static_statement) or (self.static_statement and "#" in str(self.static_statement)))
                and (
                    (
                        self.write_mode
                        and (
                            (hasattr(self.write_mode, "value") and self.write_mode.value != "static_statement")
                            or (self.write_mode != "static_statement")
                        )
                    )
                    or (
                        self.write_mode
                        and (
                            (
                                hasattr(self.write_mode, "value")
                                and self.write_mode.value
                                and "#" in str(self.write_mode.value)
                            )
                            or ("#" in str(self.write_mode))
                        )
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("table_name")
        include.add("ds_table_action_generate_create_statement_row_format") if (
            (
                (self.ds_table_action_generate_create_statement)
                or (
                    self.ds_table_action_generate_create_statement
                    and "#" in str(self.ds_table_action_generate_create_statement)
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_table_action_generate_create_statement_row_format")
        include.add("ds_table_action_generate_create_statement_storage_format") if (
            (
                (self.ds_table_action_generate_create_statement)
                or (
                    self.ds_table_action_generate_create_statement
                    and "#" in str(self.ds_table_action_generate_create_statement)
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_table_action_generate_create_statement_storage_format")
        include.add("ds_insert_statement_read_from_file_insert") if (
            (
                ((not self.ds_generate_sql) or (self.ds_generate_sql and "#" in str(self.ds_generate_sql)))
                and ((self.ds_write_mode == "_insert") or (self.ds_write_mode and "#" in str(self.ds_write_mode)))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_insert_statement_read_from_file_insert")
        include.add("ds_table_name") if (
            (
                (self.ds_table_action_generate_create_statement)
                or (self.ds_table_action_generate_drop_statement)
                or (self.ds_table_action_generate_truncate_statement)
                or (self.ds_generate_sql)
                or (
                    self.ds_table_action_generate_create_statement
                    and "#" in str(self.ds_table_action_generate_create_statement)
                )
                or (
                    self.ds_table_action_generate_drop_statement
                    and "#" in str(self.ds_table_action_generate_drop_statement)
                )
                or (
                    self.ds_table_action_generate_truncate_statement
                    and "#" in str(self.ds_table_action_generate_truncate_statement)
                )
                or (self.ds_generate_sql and "#" in str(self.ds_generate_sql))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_table_name")
        include.add("ds_table_action_generate_drop_statement") if (
            ((self.ds_table_action == "_replace") or (self.ds_table_action and "#" in str(self.ds_table_action)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_table_action_generate_drop_statement")
        include.add("ds_delete_statement_read_from_file_delete") if (
            (
                ((not self.ds_generate_sql) or (self.ds_generate_sql and "#" in str(self.ds_generate_sql)))
                and ((self.ds_write_mode == "_delete") or (self.ds_write_mode and "#" in str(self.ds_write_mode)))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_delete_statement_read_from_file_delete")
        include.add("ds_table_action_generate_truncate_statement_fail_on_error") if (
            (
                (self.ds_table_action_generate_truncate_statement)
                or (
                    self.ds_table_action_generate_truncate_statement
                    and "#" in str(self.ds_table_action_generate_truncate_statement)
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_table_action_generate_truncate_statement_fail_on_error")
        include.add("ds_table_action_generate_create_statement_fail_on_error") if (
            (
                (self.ds_table_action_generate_create_statement)
                or (
                    self.ds_table_action_generate_create_statement
                    and "#" in str(self.ds_table_action_generate_create_statement)
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_table_action_generate_create_statement_fail_on_error")
        include.add("ds_table_action_generate_create_statement_table_location") if (
            (
                (self.ds_table_action_generate_create_statement)
                or (
                    self.ds_table_action_generate_create_statement
                    and "#" in str(self.ds_table_action_generate_create_statement)
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_table_action_generate_create_statement_table_location")
        include.add("table_action") if (
            (
                ((not self.static_statement) or (self.static_statement and "#" in str(self.static_statement)))
                and (
                    (
                        (
                            self.write_mode
                            and (
                                (hasattr(self.write_mode, "value") and self.write_mode.value != "static_statement")
                                or (self.write_mode != "static_statement")
                            )
                        )
                        or (
                            self.write_mode
                            and (
                                (
                                    hasattr(self.write_mode, "value")
                                    and self.write_mode.value
                                    and "#" in str(self.write_mode.value)
                                )
                                or ("#" in str(self.write_mode))
                            )
                        )
                    )
                    and (
                        (
                            self.write_mode
                            and (
                                (hasattr(self.write_mode, "value") and self.write_mode.value != "update_statement")
                                or (self.write_mode != "update_statement")
                            )
                        )
                        or (
                            self.write_mode
                            and (
                                (
                                    hasattr(self.write_mode, "value")
                                    and self.write_mode.value
                                    and "#" in str(self.write_mode.value)
                                )
                                or ("#" in str(self.write_mode))
                            )
                        )
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("table_action")
        include.add("ds_update_statement_read_from_file_update") if (
            (
                ((not self.ds_generate_sql) or (self.ds_generate_sql and "#" in str(self.ds_generate_sql)))
                and ((self.ds_write_mode == "_update") or (self.ds_write_mode and "#" in str(self.ds_write_mode)))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_update_statement_read_from_file_update")
        include.add("ds_enable_partitioned_write") if (
            ((self.ds_write_mode == "_insert") or (self.ds_write_mode and "#" in str(self.ds_write_mode)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_enable_partitioned_write")
        include.add("ds_table_action_generate_create_statement_create_statement") if (
            (
                (not self.ds_table_action_generate_create_statement)
                or (
                    self.ds_table_action_generate_create_statement
                    and "#" in str(self.ds_table_action_generate_create_statement)
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_table_action_generate_create_statement_create_statement")
        include.add("ds_table_action_generate_create_statement_row_format_field_terminator") if (
            (
                (self.ds_table_action_generate_create_statement_row_format == "_delimited")
                or (
                    self.ds_table_action_generate_create_statement_row_format
                    and "#" in str(self.ds_table_action_generate_create_statement_row_format)
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_table_action_generate_create_statement_row_format_field_terminator")
        include.add("ds_insert_statement") if (
            (
                ((not self.ds_generate_sql) or (self.ds_generate_sql and "#" in str(self.ds_generate_sql)))
                and ((self.ds_write_mode == "_insert") or (self.ds_write_mode and "#" in str(self.ds_write_mode)))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_insert_statement")
        include.add("ds_table_action_generate_drop_statement_drop_statement") if (
            (
                (not self.ds_table_action_generate_drop_statement)
                or (
                    self.ds_table_action_generate_drop_statement
                    and "#" in str(self.ds_table_action_generate_drop_statement)
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_table_action_generate_drop_statement_drop_statement")
        include.add("ds_table_action_generate_truncate_statement") if (
            ((self.ds_table_action == "_truncate") or (self.ds_table_action and "#" in str(self.ds_table_action)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_table_action_generate_truncate_statement")
        include.add("ds_table_action_table_action_first") if (
            (
                (self.ds_table_action == "_create")
                or (self.ds_table_action == "_replace")
                or (self.ds_table_action == "_truncate")
                or (self.ds_table_action and "#" in str(self.ds_table_action))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_table_action_table_action_first")
        include.add("schema_name") if (
            (
                ((not self.static_statement) or (self.static_statement and "#" in str(self.static_statement)))
                and (
                    (
                        self.write_mode
                        and (
                            (hasattr(self.write_mode, "value") and self.write_mode.value != "static_statement")
                            or (self.write_mode != "static_statement")
                        )
                    )
                    or (
                        self.write_mode
                        and (
                            (
                                hasattr(self.write_mode, "value")
                                and self.write_mode.value
                                and "#" in str(self.write_mode.value)
                            )
                            or ("#" in str(self.write_mode))
                        )
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("schema_name")
        include.add("ds_custom_statements_read_from_file_custom") if (
            ((self.ds_write_mode == "_custom") or (self.ds_write_mode and "#" in str(self.ds_write_mode)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_custom_statements_read_from_file_custom")
        include.add("ds_table_action_generate_truncate_statement_truncate_statement") if (
            (
                (not self.ds_table_action_generate_truncate_statement)
                or (
                    self.ds_table_action_generate_truncate_statement
                    and "#" in str(self.ds_table_action_generate_truncate_statement)
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_table_action_generate_truncate_statement_truncate_statement")
        include.add("ds_session_batch_size") if (
            (
                (self.ds_write_mode == "_custom")
                or (self.ds_write_mode == "_delete")
                or (self.ds_write_mode == "_insert")
                or (self.ds_write_mode == "_update")
                or (self.ds_write_mode and "#" in str(self.ds_write_mode))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_session_batch_size")
        include.add("ds_table_action_generate_drop_statement_fail_on_error") if (
            (
                (self.ds_table_action_generate_drop_statement)
                or (
                    self.ds_table_action_generate_drop_statement
                    and "#" in str(self.ds_table_action_generate_drop_statement)
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_table_action_generate_drop_statement_fail_on_error")
        include.add("ds_generate_sql") if (
            (
                (self.ds_write_mode == "_delete")
                or (self.ds_write_mode == "_insert")
                or (self.ds_write_mode == "_update")
                or (self.ds_write_mode and "#" in str(self.ds_write_mode))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_generate_sql")
        include.add("ds_delete_statement") if (
            (
                ((not self.ds_generate_sql) or (self.ds_generate_sql and "#" in str(self.ds_generate_sql)))
                and ((self.ds_write_mode == "_delete") or (self.ds_write_mode and "#" in str(self.ds_write_mode)))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_delete_statement")
        include.add("ds_update_statement") if (
            (
                ((not self.ds_generate_sql) or (self.ds_generate_sql and "#" in str(self.ds_generate_sql)))
                and ((self.ds_write_mode == "_update") or (self.ds_write_mode and "#" in str(self.ds_write_mode)))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_update_statement")
        include.add("ds_table_action_generate_create_statement_row_format_serde_library") if (
            (
                (self.ds_table_action_generate_create_statement_row_format == "_ser_de")
                or (
                    self.ds_table_action_generate_create_statement_row_format
                    and "#" in str(self.ds_table_action_generate_create_statement_row_format)
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_table_action_generate_create_statement_row_format_serde_library")
        include.add("ds_table_action_generate_create_statement") if (
            (
                (self.ds_table_action == "_create")
                or (self.ds_table_action == "_replace")
                or (self.ds_table_action and "#" in str(self.ds_table_action))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_table_action_generate_create_statement")
        include.add("ds_custom_statements") if (
            ((self.ds_write_mode == "_custom") or (self.ds_write_mode and "#" in str(self.ds_write_mode)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_custom_statements")
        include.add("static_statement") if (
            (
                ((not self.schema_name) or (self.schema_name and "#" in str(self.schema_name)))
                and ((not self.table_name) or (self.table_name and "#" in str(self.table_name)))
                and (
                    (
                        self.write_mode
                        and (
                            (hasattr(self.write_mode, "value") and self.write_mode.value == "static_statement")
                            or (self.write_mode == "static_statement")
                        )
                    )
                    or (
                        self.write_mode
                        and (
                            (
                                hasattr(self.write_mode, "value")
                                and self.write_mode.value
                                and "#" in str(self.write_mode.value)
                            )
                            or ("#" in str(self.write_mode))
                        )
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("static_statement")
        include.add("ds_session_drop_unmatched_fields") if (self.ds_use_datastage) else exclude.add(
            "ds_session_drop_unmatched_fields"
        )
        include.add("write_mode") if (not self.ds_use_datastage) else exclude.add("write_mode")
        include.add("ds_table_action") if (self.ds_use_datastage) else exclude.add("ds_table_action")
        include.add("ds_write_mode") if (self.ds_use_datastage) else exclude.add("ds_write_mode")
        include.add("data_asset_name") if (self.create_data_asset) else exclude.add("data_asset_name")
        include.add("create_data_asset") if (()) else exclude.add("create_data_asset")
        include.add("ds_table_action_generate_drop_statement") if (
            self.ds_table_action and "_replace" in str(self.ds_table_action)
        ) else exclude.add("ds_table_action_generate_drop_statement")
        include.add("ds_table_action_generate_truncate_statement") if (
            self.ds_table_action and "_truncate" in str(self.ds_table_action)
        ) else exclude.add("ds_table_action_generate_truncate_statement")
        include.add("ds_custom_statements") if (self.ds_write_mode == "_custom") else exclude.add(
            "ds_custom_statements"
        )
        include.add("ds_table_action_generate_create_statement_row_format_serde_library") if (
            self.ds_table_action_generate_create_statement_row_format == "_ser_de"
        ) else exclude.add("ds_table_action_generate_create_statement_row_format_serde_library")
        include.add("ds_table_action_table_action_first") if (
            self.ds_table_action
            and "_create" in str(self.ds_table_action)
            and self.ds_table_action
            and "_replace" in str(self.ds_table_action)
            and self.ds_table_action
            and "_truncate" in str(self.ds_table_action)
        ) else exclude.add("ds_table_action_table_action_first")
        include.add("ds_update_statement_read_from_file_update") if (
            self.ds_generate_sql == "false" or self.ds_generate_sql is False
        ) and (self.ds_write_mode and "_update" in str(self.ds_write_mode)) else exclude.add(
            "ds_update_statement_read_from_file_update"
        )
        include.add("ds_custom_statements_read_from_file_custom") if (self.ds_write_mode == "_custom") else exclude.add(
            "ds_custom_statements_read_from_file_custom"
        )
        include.add("ds_insert_statement") if (self.ds_generate_sql == "false" or self.ds_generate_sql is False) and (
            self.ds_write_mode and "_insert" in str(self.ds_write_mode)
        ) else exclude.add("ds_insert_statement")
        include.add("ds_table_action_generate_create_statement_row_format_line_terminator") if (
            self.ds_table_action_generate_create_statement_row_format == "_delimited"
        ) else exclude.add("ds_table_action_generate_create_statement_row_format_line_terminator")
        include.add("ds_table_action_generate_create_statement_fail_on_error") if (
            self.ds_table_action_generate_create_statement
            and "true" in str(self.ds_table_action_generate_create_statement)
        ) else exclude.add("ds_table_action_generate_create_statement_fail_on_error")
        include.add("ds_table_action_generate_create_statement_table_location") if (
            self.ds_table_action_generate_create_statement
            and "true" in str(self.ds_table_action_generate_create_statement)
        ) else exclude.add("ds_table_action_generate_create_statement_table_location")
        include.add("ds_table_action_generate_create_statement_row_format_field_terminator") if (
            self.ds_table_action_generate_create_statement_row_format == "_delimited"
        ) else exclude.add("ds_table_action_generate_create_statement_row_format_field_terminator")
        include.add("ds_delete_statement_read_from_file_delete") if (
            self.ds_generate_sql == "false" or self.ds_generate_sql is False
        ) and (self.ds_write_mode and "_delete" in str(self.ds_write_mode)) else exclude.add(
            "ds_delete_statement_read_from_file_delete"
        )
        include.add("ds_enable_partitioned_write") if (self.ds_write_mode == "_insert") else exclude.add(
            "ds_enable_partitioned_write"
        )
        include.add("ds_table_action_generate_truncate_statement_truncate_statement") if (
            self.ds_table_action_generate_truncate_statement
            and "false" in str(self.ds_table_action_generate_truncate_statement)
        ) else exclude.add("ds_table_action_generate_truncate_statement_truncate_statement")
        include.add("ds_table_action_generate_create_statement_row_format") if (
            self.ds_table_action_generate_create_statement
            and "true" in str(self.ds_table_action_generate_create_statement)
        ) else exclude.add("ds_table_action_generate_create_statement_row_format")
        include.add("ds_delete_statement") if (self.ds_generate_sql == "false" or self.ds_generate_sql is False) and (
            self.ds_write_mode and "_delete" in str(self.ds_write_mode)
        ) else exclude.add("ds_delete_statement")
        include.add("table_action") if (not self.static_statement) and (
            self.write_mode
            and (
                (
                    hasattr(self.write_mode, "value")
                    and self.write_mode.value
                    and "static_statement" not in str(self.write_mode.value)
                )
                or ("static_statement" not in str(self.write_mode))
            )
            and self.write_mode
            and (
                (
                    hasattr(self.write_mode, "value")
                    and self.write_mode.value
                    and "update_statement" not in str(self.write_mode.value)
                )
                or ("update_statement" not in str(self.write_mode))
            )
        ) else exclude.add("table_action")
        include.add("ds_table_action_generate_drop_statement_drop_statement") if (
            self.ds_table_action_generate_drop_statement
            and "false" in str(self.ds_table_action_generate_drop_statement)
        ) else exclude.add("ds_table_action_generate_drop_statement_drop_statement")
        include.add("ds_table_action_generate_create_statement") if (
            self.ds_table_action
            and "_create" in str(self.ds_table_action)
            and self.ds_table_action
            and "_replace" in str(self.ds_table_action)
        ) else exclude.add("ds_table_action_generate_create_statement")
        include.add("ds_insert_statement_read_from_file_insert") if (
            self.ds_generate_sql == "false" or self.ds_generate_sql is False
        ) and (self.ds_write_mode and "_insert" in str(self.ds_write_mode)) else exclude.add(
            "ds_insert_statement_read_from_file_insert"
        )
        include.add("static_statement") if (not self.schema_name) and (not self.table_name) and (
            self.write_mode
            and (
                (hasattr(self.write_mode, "value") and self.write_mode.value == "static_statement")
                or (self.write_mode == "static_statement")
            )
        ) else exclude.add("static_statement")
        include.add("ds_table_name") if (
            self.ds_table_action_generate_create_statement == "true"
            or self.ds_table_action_generate_create_statement is True
        ) or (
            self.ds_table_action_generate_drop_statement == "true"
            or self.ds_table_action_generate_drop_statement is True
        ) or (
            self.ds_table_action_generate_truncate_statement == "true"
            or self.ds_table_action_generate_truncate_statement is True
        ) or (self.ds_generate_sql == "true" or self.ds_generate_sql is True) else exclude.add("ds_table_name")
        include.add("ds_table_action_generate_drop_statement_fail_on_error") if (
            self.ds_table_action_generate_drop_statement and "true" in str(self.ds_table_action_generate_drop_statement)
        ) else exclude.add("ds_table_action_generate_drop_statement_fail_on_error")
        include.add("ds_session_batch_size") if (
            self.ds_write_mode
            and "_custom" in str(self.ds_write_mode)
            and self.ds_write_mode
            and "_delete" in str(self.ds_write_mode)
            and self.ds_write_mode
            and "_insert" in str(self.ds_write_mode)
            and self.ds_write_mode
            and "_update" in str(self.ds_write_mode)
        ) else exclude.add("ds_session_batch_size")
        include.add("schema_name") if (not self.static_statement) and (
            self.write_mode
            and (
                (
                    hasattr(self.write_mode, "value")
                    and self.write_mode.value
                    and "static_statement" not in str(self.write_mode.value)
                )
                or ("static_statement" not in str(self.write_mode))
            )
        ) else exclude.add("schema_name")
        include.add("ds_table_action_generate_create_statement_storage_format") if (
            self.ds_table_action_generate_create_statement
            and "true" in str(self.ds_table_action_generate_create_statement)
        ) else exclude.add("ds_table_action_generate_create_statement_storage_format")
        include.add("ds_table_action_generate_truncate_statement_fail_on_error") if (
            self.ds_table_action_generate_truncate_statement
            and "true" in str(self.ds_table_action_generate_truncate_statement)
        ) else exclude.add("ds_table_action_generate_truncate_statement_fail_on_error")
        include.add("table_name") if (not self.static_statement) and (
            self.write_mode
            and (
                (
                    hasattr(self.write_mode, "value")
                    and self.write_mode.value
                    and "static_statement" not in str(self.write_mode.value)
                )
                or ("static_statement" not in str(self.write_mode))
            )
        ) else exclude.add("table_name")
        include.add("ds_table_action_generate_create_statement_create_statement") if (
            self.ds_table_action_generate_create_statement
            and "false" in str(self.ds_table_action_generate_create_statement)
        ) else exclude.add("ds_table_action_generate_create_statement_create_statement")
        include.add("ds_generate_sql") if (
            self.ds_write_mode
            and "_delete" in str(self.ds_write_mode)
            and self.ds_write_mode
            and "_insert" in str(self.ds_write_mode)
            and self.ds_write_mode
            and "_update" in str(self.ds_write_mode)
        ) else exclude.add("ds_generate_sql")
        include.add("ds_update_statement") if (self.ds_generate_sql == "false" or self.ds_generate_sql is False) and (
            self.ds_write_mode and "_update" in str(self.ds_write_mode)
        ) else exclude.add("ds_update_statement")
        return include, exclude

    def _get_source_props(self) -> dict:
        include, exclude = self._validate_source()
        props = {
            "buf_free_run_ronly",
            "buf_mode_ronly",
            "buffer_free_run_percent",
            "buffering_mode",
            "byte_limit",
            "collecting",
            "column_metadata_change_propagation",
            "combinability_mode",
            "current_output_link_type",
            "db2_database_name",
            "db2_instance_name",
            "db2_source_connection_required",
            "db2_table_name",
            "decimal_rounding_mode",
            "default_maximum_length_for_columns",
            "disk_write_inc_ronly",
            "disk_write_increment_bytes",
            "ds_before_after",
            "ds_before_after_after_sql",
            "ds_before_after_after_sql_fail_on_error",
            "ds_before_after_after_sql_node",
            "ds_before_after_after_sql_node_fail_on_error",
            "ds_before_after_after_sql_node_read_from_file_after_sql_node",
            "ds_before_after_after_sql_read_from_file_after_sql",
            "ds_before_after_before_sql",
            "ds_before_after_before_sql_fail_on_error",
            "ds_before_after_before_sql_node",
            "ds_before_after_before_sql_node_fail_on_error",
            "ds_before_after_before_sql_node_read_from_file_before_sql_node",
            "ds_before_after_before_sql_read_from_file_before_sql",
            "ds_enable_partitioned_reads",
            "ds_enable_partitioned_reads_column_name",
            "ds_enable_partitioned_reads_partition_method",
            "ds_enable_partitioned_reads_table_name",
            "ds_enable_quoted_ids",
            "ds_generate_sql",
            "ds_hive_parameters",
            "ds_hive_parameters_fail_on_error",
            "ds_java_heap_size",
            "ds_limit_rows_limit",
            "ds_read_mode",
            "ds_record_ordering",
            "ds_record_ordering_key_column",
            "ds_select_statement",
            "ds_select_statement_other_clause",
            "ds_select_statement_read_from_file_select",
            "ds_select_statement_where_clause",
            "ds_session_array_size",
            "ds_session_character_set_for_non_unicode_columns",
            "ds_session_character_set_for_non_unicode_columns_character_set_name",
            "ds_session_default_length_for_columns",
            "ds_session_default_length_for_long_columns",
            "ds_session_fail_on_truncation",
            "ds_session_fetch_size",
            "ds_session_generate_all_columns_as_unicode",
            "ds_session_keep_conductor_connection_alive",
            "ds_session_report_schema_mismatch",
            "ds_table_name",
            "ds_transaction_auto_commit_mode",
            "ds_transaction_begin_end",
            "ds_transaction_begin_end_begin_sql",
            "ds_transaction_begin_end_end_sql",
            "ds_transaction_begin_end_run_end_sql_if_no_records_processed",
            "ds_transaction_end_of_wave",
            "ds_transaction_isolation_level",
            "ds_transaction_record_count",
            "ds_use_datastage",
            "enable_after_sql",
            "enable_after_sql_node",
            "enable_before_sql",
            "enable_before_sql_node",
            "enable_flow_acp_control",
            "enable_schemaless_design",
            "execution_mode",
            "fail_on_error_after_sql",
            "fail_on_error_after_sql_node",
            "fail_on_error_before_sql",
            "fail_on_error_before_sql_node",
            "flow_dirty",
            "generate_unicode_type_columns",
            "has_reference_output",
            "hide",
            "infer_schema",
            "input_count",
            "input_link_description",
            "inputcol_properties",
            "key_cols_coll",
            "key_cols_coll_ordered",
            "key_cols_coll_robin",
            "key_cols_none",
            "key_cols_part",
            "key_column_names",
            "lookup_type",
            "max_mem_buf_size_ronly",
            "maximum_memory_buffer_size_bytes",
            "output_acp_should_hide",
            "output_count",
            "output_link_description",
            "outputcol_properties",
            "part_stable_coll",
            "part_stable_ordered",
            "part_stable_roundrobin_coll",
            "part_unique_coll",
            "part_unique_ordered",
            "part_unique_roundrobin_coll",
            "partition_type",
            "perform_sort",
            "perform_sort_coll",
            "perform_sort_modulus",
            "preserve_partitioning",
            "push_filters",
            "pushed_filters",
            "queue_upper_bound_size_bytes",
            "queue_upper_size_ronly",
            "read_method",
            "rejected_filters",
            "row_limit",
            "runtime_column_propagation",
            "sampling_percentage",
            "sampling_seed",
            "sampling_type",
            "schema_name",
            "select_statement",
            "show_coll_type",
            "show_part_type",
            "show_sort_options",
            "sort_instructions",
            "sort_instructions_text",
            "sorting_key",
            "stable",
            "stage_description",
            "table_name",
            "unique",
        }
        required = {
            "current_output_link_type",
            "ds_select_statement",
            "ds_session_character_set_for_non_unicode_columns_character_set_name",
            "ds_table_name",
            "enable_flow_acp_control",
            "enable_schemaless_design",
            "hostname_or_ip_address",
            "keytab_file",
            "output_acp_should_hide",
            "password",
            "port",
            "select_statement",
            "service_principal_name",
            "table_name",
            "user_principal_name",
            "username",
        }
        props = props & (self.model_fields_set | required)
        conflict = exclude & self.model_fields_set & props
        if conflict:
            conflict = list(conflict)
            if len(conflict) == 1:
                warnings.warn(f"\n\033[33mFound conflicting property {conflict[0]}\033[0m")
            else:
                warnings.warn(
                    f"\n\033[33mFound conflicting properties{', '.join(conflict[:-1])} and {conflict[-1]}\033[0m"
                )
        exclude = exclude - self.model_fields_set
        return self.model_dump(include=props - exclude, by_alias=True, exclude_none=True, warnings=False)

    def _get_target_props(self) -> dict:
        include, exclude = self._validate_target()
        props = {
            "buf_free_run_ronly",
            "buf_mode_ronly",
            "buffer_free_run_percent",
            "buffering_mode",
            "collecting",
            "column_metadata_change_propagation",
            "combinability_mode",
            "create_data_asset",
            "current_output_link_type",
            "data_asset_name",
            "db2_database_name",
            "db2_instance_name",
            "db2_source_connection_required",
            "db2_table_name",
            "disk_write_inc_ronly",
            "disk_write_increment_bytes",
            "ds_before_after",
            "ds_before_after_after_sql",
            "ds_before_after_after_sql_fail_on_error",
            "ds_before_after_after_sql_node",
            "ds_before_after_after_sql_node_fail_on_error",
            "ds_before_after_after_sql_node_read_from_file_after_sql_node",
            "ds_before_after_after_sql_read_from_file_after_sql",
            "ds_before_after_before_sql",
            "ds_before_after_before_sql_fail_on_error",
            "ds_before_after_before_sql_node",
            "ds_before_after_before_sql_node_fail_on_error",
            "ds_before_after_before_sql_node_read_from_file_before_sql_node",
            "ds_before_after_before_sql_read_from_file_before_sql",
            "ds_custom_statements",
            "ds_custom_statements_read_from_file_custom",
            "ds_delete_statement",
            "ds_delete_statement_read_from_file_delete",
            "ds_enable_partitioned_write",
            "ds_enable_quoted_ids",
            "ds_generate_sql",
            "ds_hive_parameters",
            "ds_hive_parameters_fail_on_error",
            "ds_insert_statement",
            "ds_insert_statement_read_from_file_insert",
            "ds_java_heap_size",
            "ds_record_ordering",
            "ds_record_ordering_key_column",
            "ds_session_array_size",
            "ds_session_batch_size",
            "ds_session_character_set_for_non_unicode_columns",
            "ds_session_character_set_for_non_unicode_columns_character_set_name",
            "ds_session_default_length_for_columns",
            "ds_session_default_length_for_long_columns",
            "ds_session_drop_unmatched_fields",
            "ds_session_keep_conductor_connection_alive",
            "ds_session_report_schema_mismatch",
            "ds_table_action",
            "ds_table_action_generate_create_statement",
            "ds_table_action_generate_create_statement_create_statement",
            "ds_table_action_generate_create_statement_fail_on_error",
            "ds_table_action_generate_create_statement_row_format",
            "ds_table_action_generate_create_statement_row_format_field_terminator",
            "ds_table_action_generate_create_statement_row_format_line_terminator",
            "ds_table_action_generate_create_statement_row_format_serde_library",
            "ds_table_action_generate_create_statement_storage_format",
            "ds_table_action_generate_create_statement_table_location",
            "ds_table_action_generate_drop_statement",
            "ds_table_action_generate_drop_statement_drop_statement",
            "ds_table_action_generate_drop_statement_fail_on_error",
            "ds_table_action_generate_truncate_statement",
            "ds_table_action_generate_truncate_statement_fail_on_error",
            "ds_table_action_generate_truncate_statement_truncate_statement",
            "ds_table_action_table_action_first",
            "ds_table_name",
            "ds_transaction_auto_commit_mode",
            "ds_transaction_begin_end",
            "ds_transaction_begin_end_begin_sql",
            "ds_transaction_begin_end_end_sql",
            "ds_transaction_begin_end_run_end_sql_if_no_records_processed",
            "ds_transaction_isolation_level",
            "ds_transaction_record_count",
            "ds_update_statement",
            "ds_update_statement_read_from_file_update",
            "ds_use_datastage",
            "ds_write_mode",
            "enable_flow_acp_control",
            "enable_schemaless_design",
            "execution_mode",
            "flow_dirty",
            "hide",
            "input_count",
            "input_link_description",
            "inputcol_properties",
            "key_cols_coll",
            "key_cols_coll_ordered",
            "key_cols_coll_robin",
            "key_cols_none",
            "key_cols_part",
            "max_mem_buf_size_ronly",
            "maximum_memory_buffer_size_bytes",
            "output_acp_should_hide",
            "output_count",
            "output_link_description",
            "outputcol_properties",
            "part_stable_coll",
            "part_stable_ordered",
            "part_stable_roundrobin_coll",
            "part_unique_coll",
            "part_unique_ordered",
            "part_unique_roundrobin_coll",
            "partition_type",
            "perform_sort",
            "perform_sort_coll",
            "perform_sort_modulus",
            "preserve_partitioning",
            "queue_upper_bound_size_bytes",
            "queue_upper_size_ronly",
            "runtime_column_propagation",
            "schema_name",
            "show_coll_type",
            "show_part_type",
            "show_sort_options",
            "sort_instructions",
            "sort_instructions_text",
            "sorting_key",
            "stable",
            "stage_description",
            "static_statement",
            "table_action",
            "table_name",
            "unique",
            "write_mode",
        }
        required = {
            "current_output_link_type",
            "data_asset_name",
            "ds_delete_statement",
            "ds_insert_statement",
            "ds_session_character_set_for_non_unicode_columns_character_set_name",
            "ds_table_action",
            "ds_table_action_generate_create_statement_create_statement",
            "ds_table_action_generate_create_statement_row_format_serde_library",
            "ds_table_action_generate_drop_statement_drop_statement",
            "ds_table_action_generate_truncate_statement_truncate_statement",
            "ds_table_name",
            "ds_update_statement",
            "enable_flow_acp_control",
            "enable_schemaless_design",
            "hostname_or_ip_address",
            "keytab_file",
            "output_acp_should_hide",
            "password",
            "port",
            "service_principal_name",
            "static_statement",
            "table_name",
            "user_principal_name",
            "username",
        }
        props = props & (self.model_fields_set | required)
        conflict = exclude & self.model_fields_set & props
        if conflict:
            conflict = list(conflict)
            if len(conflict) == 1:
                warnings.warn(f"\n\033[33mFound conflicting property {conflict[0]}\033[0m")
            else:
                warnings.warn(
                    f"\n\033[33mFound conflicting properties{', '.join(conflict[:-1])} and {conflict[-1]}\033[0m"
                )
        exclude = exclude - self.model_fields_set
        return self.model_dump(include=props - exclude, by_alias=True, exclude_none=True, warnings=False)

    def _get_parameters_props(self) -> dict:
        include, exclude = self._validate_parameters()
        props = {
            "ds_record_ordering",
            "ds_record_ordering_key_column",
            "execution_mode",
            "input_count",
            "output_count",
            "preserve_partitioning",
        }
        required = set()
        props = props & (self.model_fields_set | required)
        conflict = exclude & self.model_fields_set & props
        if conflict:
            conflict = list(conflict)
            if len(conflict) == 1:
                warnings.warn(f"\n\033[33mFound conflicting property {conflict[0]}\033[0m")
            else:
                warnings.warn(
                    f"\n\033[33mFound conflicting properties{', '.join(conflict[:-1])} and {conflict[-1]}\033[0m"
                )
        exclude = exclude - self.model_fields_set
        return self.model_dump(include=props - exclude, by_alias=True, exclude_none=True, warnings=False)

    def _get_app_data_props(self) -> dict:
        return {
            "datastage": {
                "active": 0,
                "SupportsRef": True,
                "maxRejectOutputs": 0,
                "minRejectOutputs": 0,
                "maxReferenceInputs": 0,
                "minReferenceInputs": 0,
            }
        }

    def _get_input_ports_props(self) -> dict:
        include, exclude = self._validate_target()
        props = {"runtime_column_propagation"}
        required = set()
        props = props & (self.model_fields_set | required)
        conflict = exclude & self.model_fields_set & props
        if conflict:
            conflict = list(conflict)
            if len(conflict) == 1:
                warnings.warn(f"\n\033[33mFound conflicting property: {conflict[0]}\033[0m")
            else:
                warnings.warn(
                    f"\n\033[33mFound conflicting properties: {', '.join(conflict[:-1])} and {conflict[-1]}\033[0m"
                )
        exclude = exclude - self.model_fields_set
        return self.model_dump(include=props - exclude, by_alias=True, exclude_none=True, warnings=False)

    def _get_input_cardinality(self) -> dict:
        return {"min": 0, "max": -1}

    def _get_output_ports_props(self) -> dict:
        include, exclude = self._validate_source()
        props = set()
        required = set()
        props = props & (self.model_fields_set | required)
        conflict = exclude & self.model_fields_set & props
        if conflict:
            conflict = list(conflict)
            if len(conflict) == 1:
                warnings.warn(f"\n\033[33mFound conflicting property: {conflict[0]}\033[0m")
            else:
                warnings.warn(
                    f"\n\033[33mFound conflicting properties: {', '.join(conflict[:-1])} and {conflict[-1]}\033[0m"
                )
        exclude = exclude - self.model_fields_set
        return self.model_dump(include=props - exclude, by_alias=True, exclude_none=True, warnings=False)

    def _get_output_cardinality(self) -> dict:
        return {"min": 0, "max": 1}

    def _get_allowed_as_source_props(self) -> bool:
        return True
