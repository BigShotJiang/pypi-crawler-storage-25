"""This module defines configuration for the Difference stage."""

import warnings
from ibm_watsonx_data_integration.services.datastage.models.base_stage import BaseStage
from ibm_watsonx_data_integration.services.datastage.models.enums import DIFFERENCE
from pydantic import Field
from typing import ClassVar


class difference(BaseStage):
    """Properties for the Difference stage."""

    op_name: ClassVar[str] = "PxDifference"
    node_type: ClassVar[str] = "execution_node"
    image: ClassVar[str] = "/data-intg/flows/graphics/palette/PxDifference.svg"
    label: ClassVar[str] = "Difference"
    runtime_column_propagation: bool = Field(False, alias="runtime_column_propagation")
    all_values: DIFFERENCE.AllValues | None = Field(
        DIFFERENCE.AllValues.false,
        alias="allValues",
        description=(
            "Specifies that all value columns other than any key columns specified are used as value "
            "columns.When a before and after row are determined to be copies based on the difference keys, the "
            "value columns can then be used to determine if the after row is an edited version of the before row."
        ),
    )
    auto_column_propagation: bool | None = Field(
        None,
        alias="auto_column_propagation",
        description=("Automatically apply column metadata changes to downstream stages(See Settings in toolbar)"),
    )
    buf_free_run: int | None = Field(
        50,
        alias="buf_free_run",
        description=("Specifies how much of the available in-memory buffer to use before the buffer writes to disk."),
    )
    buf_free_run_ronly: int | None = Field(50, alias="buf_free_run_ronly")
    buf_mode: DIFFERENCE.BufMode | None = Field(
        DIFFERENCE.BufMode.default,
        alias="buf_mode",
        description=(
            "(Default): The link takes the settings that are specified by the environment variables. This is "
            "Auto buffer unless you have changed the value of the APT_BUFFERING _POLICY environment variable.   "
            "Auto buffer: The link buffers incoming data only if necessary to prevent a dataflow deadlock "
            "situation.  Buffer: The link unconditionally buffer all incoming data.  No buffer: The link does "
            "not buffer data under any circumstances. This setting might cause deadlocks if not used carefully."
        ),
    )
    buf_mode_ronly: DIFFERENCE.BufModeRonly | None = Field(DIFFERENCE.BufModeRonly.default, alias="buf_mode_ronly")
    ci_cs2: DIFFERENCE.CiCs2 | None = Field(DIFFERENCE.CiCs2.cs, alias="ci-cs2")
    coll_type: DIFFERENCE.CollType | None = Field(
        DIFFERENCE.CollType.auto, alias="coll_type", description=("Specify the order in which data is read.")
    )
    collation_sequence: DIFFERENCE.CollationSequence | None = Field(
        DIFFERENCE.CollationSequence.OFF,
        alias="collation_sequence",
        description=("Locale to be used for the collation sequence."),
    )
    combinability: DIFFERENCE.Combinability | None = Field(
        DIFFERENCE.Combinability.auto,
        alias="combinability",
        description=("Specify whether to combine underlying operators into a single process."),
    )
    copy_code: int | None = Field(
        2,
        alias="copyCode",
        description=(
            "Value for the diff column in the output when the before and after rows are copies. A copy means all "
            "keys and all optional values are equal."
        ),
    )
    current_output_link_type: str = Field("PRIMARY", alias="currentOutputLinkType")
    delete_code: int | None = Field(
        1,
        alias="deleteCode",
        description=(
            "Value for the diff column in the output row for the delete result. A delete means that a row exists "
            "in the before data set but not in the after data set as defined by the difference keys."
        ),
    )
    diff_name: str | None = Field(None, alias="diff_name")
    disk_write_inc: int | None = Field(
        1048576,
        alias="disk_write_inc",
        description=("Sets the size, in bytes, of blocks of data being moved to and from disk."),
    )
    disk_write_inc_ronly: int | None = Field(1048576, alias="disk_write_inc_ronly")
    drop_copy: DIFFERENCE.DropCopy | None = Field(
        DIFFERENCE.DropCopy.false,
        alias="dropCopy",
        description=("Keep or drop the output record, meaning not generate it, for the copy result type."),
    )
    drop_delete: DIFFERENCE.DropDelete | None = Field(
        DIFFERENCE.DropDelete.false,
        alias="dropDelete",
        description=("Keep or drop the output record, meaning not generate it, for the delete result type."),
    )
    drop_edit: DIFFERENCE.DropEdit | None = Field(
        DIFFERENCE.DropEdit.false,
        alias="dropEdit",
        description=("Keep or drop the output record, meaning not generate it, for the edit result type."),
    )
    drop_insert: DIFFERENCE.DropInsert | None = Field(
        DIFFERENCE.DropInsert.false,
        alias="dropInsert",
        description=("Keep or drop the output record, meaning not generate it, for the insert result type."),
    )
    edit_code: int | None = Field(
        3,
        alias="editCode",
        description=(
            "Value for the diff column in the output row for the edit result. An edit means that all difference "
            "keys are equal but one or more values are different."
        ),
    )
    enable_flow_acp_control: bool = Field(True, alias="enableFlowAcpControl")
    enable_schemaless_design: bool = Field(False, alias="enableSchemalessDesign")
    execmode: DIFFERENCE.Execmode | None = Field(
        DIFFERENCE.Execmode.default_par,
        alias="execmode",
        description=("Specify whether your stage runs sequentially or in parallel."),
    )
    flow_dirty: str | None = Field("false", alias="flow_dirty")
    hide: bool | None = Field(False, alias="hide")
    hide_case_sensitive_column: bool | None = Field(None, alias="hideCaseSensitiveColumn")
    input_count: int | None = Field(0, alias="input_count")
    input_link_description: list | None = Field("", alias="inputLinkDescription")
    inputcol_properties: list | None = Field([], alias="inputcolProperties")
    inputlink_ordering_list: list | None = Field(
        [],
        alias="InputlinkOrderingList",
        description=(
            "List of input links you want to reorder. If there is one primary link and multiple reference links, "
            "re-ordering can occur only on reference links"
        ),
    )
    insert_code: int | None = Field(
        0,
        alias="insertCode",
        description=(
            "Value for the diff column in the output row for the insert result. An insert means that a row "
            "exists in the after data set but not in the before data set as defined by the difference keys."
        ),
    )
    key_col_select: DIFFERENCE.KeyColSelect | None = Field(DIFFERENCE.KeyColSelect.default, alias="keyColSelect")
    key_cols_coll: list | None = Field([], alias="keyColsColl")
    key_cols_coll_ordered: list | None = Field([], alias="keyColsCollOrdered")
    key_cols_coll_robin: list | None = Field([], alias="keyColsCollRobin")
    key_cols_none: list | None = Field([], alias="keyColsNone")
    key_cols_part: list | None = Field([], alias="keyColsPart")
    key_properties: list | None = Field([], alias="keyProperties")
    max_mem_buf_size: int | None = Field(
        3145728,
        alias="max_mem_buf_size",
        description=(
            "Specifies the maximum amount of virtual memory, in bytes, used per buffer. The default size is "
            "3145728 (3 MB)."
        ),
    )
    max_mem_buf_size_ronly: int | None = Field(3145728, alias="max_mem_buf_size_ronly")
    output_acp_should_hide: bool = Field(True, alias="outputAcpShouldHide")
    output_count: int | None = Field(0, alias="output_count")
    output_link_description: list | None = Field("", alias="outputLinkDescription")
    outputcol_properties: list | None = Field([], alias="outputcolProperties")
    part_client_dbname: str | None = Field(None, alias="part_client_dbname", description="Db2 Database name")
    part_client_instance: str | None = Field(None, alias="part_client_instance", description="Db2 Instance name")
    part_dbconnection: str | None = Field("", alias="part_dbconnection", description="Db2 Source connection (required)")
    part_stable: bool | None = Field(
        None, alias="part_stable", description=("Select Stable if you want to preserve previously sorted data sets.")
    )
    part_stable_coll: bool | None = Field(False, alias="part_stable_coll")
    part_stable_ordered: bool | None = Field(False, alias="part_stable_ordered")
    part_stable_roundrobin_coll: bool | None = Field(False, alias="part_stable_roundrobin_coll")
    part_table: str | None = Field(None, alias="part_table", description="Db2 Table name")
    part_type: DIFFERENCE.PartType | None = Field(
        DIFFERENCE.PartType.auto, alias="part_type", description=("Partition type")
    )
    part_unique: bool | None = Field(
        None,
        alias="part_unique",
        description=(
            "Select Unique to specify that, if multiple records have identical sorting key values, only one "
            "record is retained. If stable sort is also set, the first record is retained."
        ),
    )
    part_unique_coll: bool | None = Field(False, alias="part_unique_coll")
    part_unique_ordered: bool | None = Field(False, alias="part_unique_ordered")
    part_unique_roundrobin_coll: bool | None = Field(False, alias="part_unique_roundrobin_coll")
    perform_sort: bool | None = Field(False, alias="perform_sort", description="Perform sort")
    perform_sort_coll: bool | None = Field(False, alias="perform_sort_coll")
    perform_sort_modulus: bool | None = Field(False, alias="perform_sort_modulus", description="Perform sort")
    preserve: DIFFERENCE.Preserve | None = Field(
        DIFFERENCE.Preserve.default_propagate,
        alias="preserve",
        description=("Specify whether to maintain data in current partitions."),
    )
    queue_upper_size: int | None = Field(
        0,
        alias="queue_upper_size",
        description=("Specifies the maximum amount of data buffered at any time using both memory and disk."),
    )
    queue_upper_size_ronly: int | None = Field(0, alias="queue_upper_size_ronly")
    runtime_column_propagation: bool | None = Field(
        None,
        alias="runtime_column_propagation",
        description=("Propagate extra columns that are not defined in the metadata through the rest of the job."),
    )
    show_coll_type: int | None = Field(0, alias="showCollType")
    show_part_type: int | None = Field(1, alias="showPartType")
    show_sort_options: int | None = Field(0, alias="showSortOptions")
    sort_instructions: str | None = Field("", alias="sortInstructions")
    sort_instructions_text: str | None = Field("", alias="sortInstructionsText")
    stage_description: list | None = Field("", alias="stageDescription", description="Description")
    stats: DIFFERENCE.Stats | None = Field(
        DIFFERENCE.Stats.false,
        alias="stats",
        description=(
            "Log information about the number of input rows and the number of copy, delete, edit, and insert rows."
        ),
    )
    tolerate_unsorted: DIFFERENCE.TolerateUnsorted | None = Field(
        DIFFERENCE.TolerateUnsorted.false,
        alias="tolerateUnsorted",
        description=(
            "By default, this stage expects its inputs to be sorted by the key columns and with (Auto) "
            "Partitioning set, will sort its inputs if they are not sorted. Setting this property to True allows "
            "you to process groups of records that may be arranged by the difference key columns but not sorted."
        ),
    )
    value_ci_cs: DIFFERENCE.ValueCiCs | None = Field(
        DIFFERENCE.ValueCiCs.cs, alias="value-ci-cs", description=("Whether this column is case sensitive or not.")
    )
    value_properties: list | None = Field([], alias="valueProperties")

    def _validate_parameters(self) -> tuple[set, set]:
        include = set()
        exclude = set()

        include.add("value_properties") if ((self.all_values != "allValues") and (())) else exclude.add(
            "value_properties"
        )
        include.add("value_ci_cs") if ((self.all_values == "allValues") and (())) else exclude.add("value_ci_cs")
        include.add("preserve") if (self.output_count and self.output_count > 0) else exclude.add("preserve")
        include.add("insert_code") if (()) else exclude.add("insert_code")
        include.add("delete_code") if (()) else exclude.add("delete_code")
        include.add("edit_code") if (()) else exclude.add("edit_code")
        include.add("copy_code") if (()) else exclude.add("copy_code")
        include.add("max_mem_buf_size") if (self.buf_mode != "nobuffer") else exclude.add("max_mem_buf_size")
        include.add("buf_free_run") if (self.buf_mode != "nobuffer") else exclude.add("buf_free_run")
        include.add("queue_upper_size") if (self.buf_mode != "nobuffer") else exclude.add("queue_upper_size")
        include.add("disk_write_inc") if (self.buf_mode != "nobuffer") else exclude.add("disk_write_inc")

        include.add("runtime_column_propagation") if (not self.enable_schemaless_design) else exclude.add(
            "runtime_column_propagation"
        )
        include.add("auto_column_propagation") if (not self.output_acp_should_hide) else exclude.add(
            "auto_column_propagation"
        )
        include.add("max_mem_buf_size_ronly") if (self.buf_mode_ronly != "nobuffer") else exclude.add(
            "max_mem_buf_size_ronly"
        )
        include.add("buf_free_run_ronly") if (self.buf_mode_ronly != "nobuffer") else exclude.add("buf_free_run_ronly")
        include.add("queue_upper_size_ronly") if (self.buf_mode_ronly != "nobuffer") else exclude.add(
            "queue_upper_size_ronly"
        )
        include.add("disk_write_inc_ronly") if (self.buf_mode_ronly != "nobuffer") else exclude.add(
            "disk_write_inc_ronly"
        )
        include.add("part_stable") if (
            (self.show_part_type)
            and (self.part_type != "auto")
            and (self.part_type != "db2connector")
            and (self.show_sort_options)
        ) else exclude.add("part_stable")
        include.add("part_unique") if (
            (self.show_part_type)
            and (self.part_type != "auto")
            and (self.part_type != "db2connector")
            and (self.show_sort_options)
        ) else exclude.add("part_unique")
        include.add("key_cols_part") if (
            (
                (self.show_part_type)
                and (not self.show_coll_type)
                and (self.part_type != "auto")
                and (self.part_type != "db2connector")
                and (self.part_type != "modulus")
            )
            or (
                (self.show_part_type)
                and (not self.show_coll_type)
                and (self.part_type == "modulus")
                and (self.perform_sort_modulus)
            )
        ) else exclude.add("key_cols_part")
        include.add("part_dbconnection") if ((self.part_type == "db2part") and (self.show_part_type)) else exclude.add(
            "part_dbconnection"
        )
        include.add("part_client_dbname") if ((self.part_type == "db2part") and (self.show_part_type)) else exclude.add(
            "part_client_dbname"
        )
        include.add("part_client_instance") if (
            (self.part_type == "db2part") and (self.show_part_type)
        ) else exclude.add("part_client_instance")
        include.add("part_table") if ((self.part_type == "db2part") and (self.show_part_type)) else exclude.add(
            "part_table"
        )
        include.add("perform_sort") if (
            (self.show_part_type) and ((self.part_type == "hash") or (self.part_type == "range"))
        ) else exclude.add("perform_sort")
        include.add("perform_sort_modulus") if (
            (self.show_part_type) and (self.part_type == "modulus")
        ) else exclude.add("perform_sort_modulus")
        include.add("key_col_select") if (
            (self.show_part_type) and (self.part_type == "modulus") and (not self.perform_sort_modulus)
        ) else exclude.add("key_col_select")
        include.add("sort_instructions") if (
            (self.show_part_type)
            and (
                (self.part_type == "db2part")
                or (self.part_type == "entire")
                or (self.part_type == "random")
                or (self.part_type == "roundrobin")
                or (self.part_type == "same")
            )
        ) else exclude.add("sort_instructions")
        include.add("sort_instructions_text") if (
            (self.show_part_type)
            and (
                (self.part_type == "db2part")
                or (self.part_type == "entire")
                or (self.part_type == "random")
                or (self.part_type == "roundrobin")
                or (self.part_type == "same")
            )
        ) else exclude.add("sort_instructions_text")
        include.add("coll_type") if (self.show_coll_type) else exclude.add("coll_type")
        include.add("part_type") if (self.show_part_type) else exclude.add("part_type")
        include.add("perform_sort_coll") if (
            (
                (self.show_coll_type)
                and (
                    (self.coll_type == "ordered")
                    or (self.coll_type == "roundrobin_coll")
                    or (self.coll_type == "sortmerge")
                )
            )
            or ((not self.show_part_type) and (not self.show_coll_type))
        ) else exclude.add("perform_sort_coll")
        include.add("key_cols_coll") if (
            (self.show_coll_type)
            and (not self.show_part_type)
            and (self.coll_type != "auto")
            and ((self.coll_type == "sortmerge") or (self.perform_sort_coll))
        ) else exclude.add("key_cols_coll")
        include.add("key_cols_none") if (
            (not self.show_part_type) and (not self.show_coll_type) and (self.perform_sort_coll)
        ) else exclude.add("key_cols_none")
        include.add("part_stable_coll") if (
            (self.perform_sort_coll)
            and (
                (
                    (not self.show_part_type)
                    and (self.show_coll_type)
                    and (self.coll_type != "auto")
                    and (self.show_sort_options)
                )
                or ((not self.show_part_type) and (not self.show_coll_type) and (self.show_sort_options))
            )
        ) else exclude.add("part_stable_coll")
        include.add("part_unique_coll") if (
            (self.perform_sort_coll)
            and (
                (
                    (not self.show_part_type)
                    and (self.show_coll_type)
                    and (self.coll_type != "auto")
                    and (self.show_sort_options)
                )
                or ((not self.show_part_type) and (not self.show_coll_type) and (self.show_sort_options))
            )
        ) else exclude.add("part_unique_coll")
        include.add("key_properties") if (self.key_properties) else exclude.add("key_properties")
        return include, exclude

    def _get_input_ports_props(self) -> dict:
        include, exclude = self._validate()
        props = {"runtime_column_propagation"}
        required = set()
        props = props & (self.model_fields_set | required)
        conflict = exclude & self.model_fields_set & props
        if conflict:
            conflict = list(conflict)
            if len(conflict) == 1:
                warnings.warn(f"\n\033[33mFound conflicting property: {conflict[0]}\033[0m")
            else:
                warnings.warn(
                    f"\n\033[33mFound conflicting properties: {', '.join(conflict[:-1])} and {conflict[-1]}\033[0m"
                )
        exclude = exclude - self.model_fields_set
        return self.model_dump(include=props - exclude, by_alias=True, exclude_none=True, warnings=False)

    def _get_input_cardinality(self) -> dict:
        return {"min": 2, "max": 2}

    def _get_output_ports_props(self) -> dict:
        include, exclude = self._validate()
        props = set()
        required = set()
        props = props & (self.model_fields_set | required)
        conflict = exclude & self.model_fields_set & props
        if conflict:
            conflict = list(conflict)
            if len(conflict) == 1:
                warnings.warn(f"\n\033[33mFound conflicting property: {conflict[0]}\033[0m")
            else:
                warnings.warn(
                    f"\n\033[33mFound conflicting properties: {', '.join(conflict[:-1])} and {conflict[-1]}\033[0m"
                )
        exclude = exclude - self.model_fields_set
        return self.model_dump(include=props - exclude, by_alias=True, exclude_none=True, warnings=False)

    def _get_output_cardinality(self) -> dict:
        return {"min": 0, "max": 1}

    def _get_parameters_props(self) -> dict:
        include, exclude = self._validate()
        props = {
            "additional_properties_set_difference_values",
            "additional_properties_set_options",
            "all_values",
            "auto_column_propagation",
            "buf_free_run",
            "buf_free_run_ronly",
            "buf_mode",
            "buf_mode_ronly",
            "ci_cs2",
            "coll_type",
            "collation_sequence",
            "combinability",
            "copy_code",
            "current_output_link_type",
            "delete_code",
            "diff_name",
            "disk_write_inc",
            "disk_write_inc_ronly",
            "drop_copy",
            "drop_delete",
            "drop_edit",
            "drop_insert",
            "edit_code",
            "enable_flow_acp_control",
            "enable_schemaless_design",
            "execmode",
            "flow_dirty",
            "hide",
            "hide_case_sensitive_column",
            "input_count",
            "input_link_description",
            "inputcol_properties",
            "inputlink_ordering_list",
            "insert_code",
            "key_col_select",
            "key_cols_coll",
            "key_cols_coll_ordered",
            "key_cols_coll_robin",
            "key_cols_none",
            "key_cols_part",
            "key_properties",
            "max_mem_buf_size",
            "max_mem_buf_size_ronly",
            "output_acp_should_hide",
            "output_count",
            "output_link_description",
            "outputcol_properties",
            "part_client_dbname",
            "part_client_instance",
            "part_dbconnection",
            "part_stable",
            "part_stable_coll",
            "part_stable_ordered",
            "part_stable_roundrobin_coll",
            "part_table",
            "part_type",
            "part_unique",
            "part_unique_coll",
            "part_unique_ordered",
            "part_unique_roundrobin_coll",
            "perform_sort",
            "perform_sort_coll",
            "perform_sort_modulus",
            "preserve",
            "queue_upper_size",
            "queue_upper_size_ronly",
            "runtime_column_propagation",
            "show_coll_type",
            "show_part_type",
            "show_sort_options",
            "sort_instructions",
            "sort_instructions_text",
            "stage_description",
            "stats",
            "tolerate_unsorted",
            "value_ci_cs",
            "value_properties",
        }
        required = {
            "current_output_link_type",
            "enable_flow_acp_control",
            "enable_schemaless_design",
            "output_acp_should_hide",
        }
        props = props & (self.model_fields_set | required)
        conflict = exclude & self.model_fields_set & props
        if conflict:
            conflict = list(conflict)
            if len(conflict) == 1:
                warnings.warn(f"\n\033[33mFound conflicting property {conflict[0]}\033[0m")
            else:
                warnings.warn(
                    f"\n\033[33mFound conflicting properties{', '.join(conflict[:-1])} and {conflict[-1]}\033[0m"
                )
        exclude = exclude - self.model_fields_set
        return self.model_dump(include=props - exclude, by_alias=True, exclude_none=True, warnings=False)

    def _get_app_data_props(self) -> dict:
        return {
            "datastage": {
                "maxRejectOutputs": 0,
                "minRejectOutputs": 0,
                "maxReferenceInputs": 0,
                "minReferenceInputs": 0,
            }
        }
