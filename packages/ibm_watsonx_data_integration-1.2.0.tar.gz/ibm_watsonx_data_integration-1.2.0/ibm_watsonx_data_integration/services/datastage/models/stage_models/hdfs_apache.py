"""This module defines configuration for the Apache HDFS stage."""

import re
import warnings
from ibm_watsonx_data_integration.services.datastage.models.base_stage import BaseStage
from ibm_watsonx_data_integration.services.datastage.models.connections.hdfs_apache_connection import HdfsApacheConn
from ibm_watsonx_data_integration.services.datastage.models.enums import HDFS_APACHE
from pydantic import Field
from typing import ClassVar


class hdfs_apache(BaseStage):
    """Properties for the Apache HDFS stage."""

    op_name: ClassVar[str] = "hdfs-apache"
    node_type: ClassVar[str] = "binding"
    image: ClassVar[str] = "/data-intg/flows/graphics/palette/hdfs-apache.svg"
    label: ClassVar[str] = "Apache HDFS"
    runtime_column_propagation: bool = Field(False, alias="runtime_column_propagation")
    connection: HdfsApacheConn = HdfsApacheConn()
    buf_free_run_ronly: int | None = Field(50, alias="buf_free_run_ronly")
    buf_mode_ronly: HDFS_APACHE.BufModeRonly | None = Field(HDFS_APACHE.BufModeRonly.default, alias="buf_mode_ronly")
    buffer_free_run_percent: int | None = Field(
        50,
        alias="buf_free_run",
        description=("Specifies how much of the available in-memory buffer to use before the buffer writes to disk."),
    )
    buffering_mode: HDFS_APACHE.BufferingMode | None = Field(
        HDFS_APACHE.BufferingMode.default,
        alias="buf_mode",
        description=(
            "(Default): The link takes the settings that are specified by the environment variables. This is "
            "Auto buffer unless you have changed the value of the APT_BUFFERING _POLICY environment variable.   "
            "Auto buffer: The link buffers incoming data only if necessary to prevent a dataflow deadlock "
            "situation.  Buffer: The link unconditionally buffer all incoming data.  No buffer: The link does "
            "not buffer data under any circumstances. This setting might cause deadlocks if not used carefully."
        ),
    )
    byte_limit: str | None = Field(
        None,
        alias="byte_limit",
        description=(
            "The maximum number of bytes to return. Use any of following suffixes to change the unit: KB, MB, "
            "GB, or TB. A value of 0 returns all data."
        ),
    )
    cell_range: str | None = Field(
        None,
        alias="range",
        description=("The range of cells to retrieve from the Excel worksheet, for example, C1:F10"),
    )
    codec_avro: HDFS_APACHE.CodecAvro | None = Field(
        HDFS_APACHE.CodecAvro.null, alias="codec_avro", description=("The compression codec to use when writing")
    )
    codec_csv: HDFS_APACHE.CodecCsv | None = Field(
        None, alias="codec_csv", description=("The compression codec to use when writing")
    )
    codec_delimited: HDFS_APACHE.CodecDelimited | None = Field(
        None, alias="codec_delimited", description=("The compression codec to use when writing")
    )
    codec_orc: HDFS_APACHE.CodecOrc | None = Field(
        HDFS_APACHE.CodecOrc.none, alias="codec_orc", description=("The compression codec to use when writing")
    )
    codec_parquet: HDFS_APACHE.CodecParquet | None = Field(
        HDFS_APACHE.CodecParquet.snappy,
        alias="codec_parquet",
        description=("The compression codec to use when writing"),
    )
    collecting: HDFS_APACHE.Collecting | None = Field(
        HDFS_APACHE.Collecting.auto, alias="coll_type", description=("Specify the order in which data is read.")
    )
    column_metadata_change_propagation: bool | None = Field(
        None,
        alias="auto_column_propagation",
        description=("Automatically apply column metadata changes to downstream stages(See Settings in toolbar)"),
    )
    combinability_mode: HDFS_APACHE.CombinabilityMode | None = Field(
        HDFS_APACHE.CombinabilityMode.auto,
        alias="combinability",
        description=("Specify whether to combine underlying operators into a single process."),
    )
    create_data_asset: bool | None = Field(
        False,
        alias="registerDataAsset",
        description=(
            "If this checkbox is selected and a data asset with the file name does not already exist, a project "
            "data asset will be created. The asset will not be updated if the job is rerun."
        ),
    )
    create_or_use_existing_hive_table: bool | None = Field(
        False, alias="create_hive_table", description=("Create a table in the database")
    )
    current_output_link_type: str = Field("PRIMARY", alias="currentOutputLinkType")
    data_asset_name: str = Field(None, alias="dataAssetName", description="Data asset name")
    date_format: str | None = Field(
        None, alias="date_format", description=("The format of date values, for example, yyyy-[M]M-[d]d")
    )
    db2_database_name: str | None = Field(None, alias="part_client_dbname", description="Db2 Database name")
    db2_instance_name: str | None = Field(None, alias="part_client_instance", description="Db2 Instance name")
    db2_source_connection_required: str | None = Field(
        "", alias="part_dbconnection", description=("Db2 Source connection (required)")
    )
    db2_table_name: str | None = Field(None, alias="part_table", description="Db2 Table name")
    decimal_format: str | None = Field(
        None, alias="decimal_format", description=("The format of decimal values, for example, #,###.##")
    )
    decimal_grouping_separator: str | None = Field(
        None,
        alias="decimal_format_grouping_separator",
        description=(
            "The character used to group digits of similar significance. This property and decimal separator "
            "property must be unique. If you encounter error related to them not being unique when only one of "
            "them was provided then please provide the missing one explicitly."
        ),
    )
    decimal_rounding_mode: HDFS_APACHE.DecimalRoundingMode | None = Field(
        HDFS_APACHE.DecimalRoundingMode.floor,
        alias="decimal_rounding_mode",
        description=("Different rounding modes for values in columns of decimal and numeric data types"),
    )
    decimal_separator: str | None = Field(
        None,
        alias="decimal_format_decimal_separator",
        description=(
            "The character used to separate the integer part from the fractional part of a number. This property "
            "and decimal grouping separator property must be unique. If you encounter error related to them not "
            "being unique when only one of them was provided then please provide the missing one explicitly."
        ),
    )
    default_maximum_length_for_columns: int | None = Field(
        20000,
        alias="default_max_string_binary_precision",
        description=(
            "Default maximum length for columns. This property can be set/is applicable only when runtime column "
            "propagation is used"
        ),
    )
    defer_credentials: bool | None = Field(
        False, alias="defer_credentials", description=("Defer specifying credentials until usage")
    )
    disk_write_inc_ronly: int | None = Field(1048576, alias="disk_write_inc_ronly")
    disk_write_increment_bytes: int | None = Field(
        1048576,
        alias="disk_write_inc",
        description=("Sets the size, in bytes, of blocks of data being moved to and from disk."),
    )
    display_value_labels: bool | None = Field(
        None, alias="display_value_labels", description="Display the value labels"
    )
    ds_cleanup: bool | None = Field(
        True,
        alias="_cleanup",
        description=("If a job fails, select whether the connector deletes the file or files that have been created."),
    )
    ds_create_hive_table: bool | None = Field(
        False,
        alias="_create_hive_table",
        description=("Select <B>Yes</B> to create or use an existing Hive table after data has been loaded to HDFS."),
    )
    ds_create_hive_table_additional_driver_params: str | None = Field(
        None,
        alias="_create_hive_table.additional_driver_params",
        description=(
            "Specify any additional driver-specific connection attributes. Enter the attributes in the "
            "name=value format, separated by semi-colon if multiple attributes needs to be specified. For "
            "information about the supported driver-specific attributes, refer to the Progress DataDirect driver "
            "documentation."
        ),
    )
    ds_create_hive_table_create_hive_schema: bool | None = Field(
        False,
        alias="_create_hive_table.create_hive_schema",
        description=(
            "Specify Yes to create the schema indicated in the fully qualified table name if it does not already "
            "exist. If Yes is specified and the table name does not contain a schema, the job will fail. If Yes "
            "is specified and the schema already exists, the job will not fail."
        ),
    )
    ds_create_hive_table_drop_hive_table: bool | None = Field(
        True,
        alias="_create_hive_table.drop_hive_table",
        description=(
            "Specify <B>Yes</B> to drop the Hive table if it already exists. <B>No</B> to append to existing "
            "Hive table."
        ),
    )
    ds_create_hive_table_hive_kerberos: bool | None = Field(
        False, alias="_create_hive_table.hive_kerberos", description=("Select Yes to use Kerberos")
    )
    ds_create_hive_table_hive_keytab: str = Field(
        None,
        alias="_create_hive_table.hive_keytab",
        description=("Enter the fully qualified path of the keytab for the specified user."),
    )
    ds_create_hive_table_hive_service_principal: str | None = Field(
        None,
        alias="_create_hive_table.hive_service_principal",
        description=(
            "Use this property to specify the service principal for hive. Service principal for the hive service "
            "is of the format <B>hive/FQDN@REALM</B>"
        ),
    )
    ds_create_hive_table_hive_table: str = Field(
        None, alias="_create_hive_table.hive_table", description=("Enter the name of the table to create.")
    )
    ds_create_hive_table_hive_table_type: HDFS_APACHE.DSCreateHiveTableHiveTableType | None = Field(
        HDFS_APACHE.DSCreateHiveTableHiveTableType.external,
        alias="_create_hive_table.hive_table_type",
        description=("Specify Hive table type, as external (default) or internal."),
    )
    ds_create_hive_table_hive_use_keytab: bool | None = Field(
        False,
        alias="_create_hive_table.hive_use_keytab",
        description=("Select Yes to use keytab instead of password for Kerberos login"),
    )
    ds_create_hive_table_use_staging_table: bool | None = Field(
        False,
        alias="_create_hive_table.use_staging_table",
        description=(
            "Set <B>Yes</B> to use staging table. This option will be enabled only when the <B>FileFormat</B> is "
            "<B>Delimited</B>"
        ),
    )
    ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_drop_staging_table: bool | None = Field(
        True,
        alias="_create_hive_table.use_staging_table.hive_target_table_properties.hive_drop_staging_table",
        description=(
            "Use this property to drop the staging table. By default, the staging table would be dropped once "
            "the target table has been created. In case, the user do not want the staging table to be removed, "
            "set the value of this property to No"
        ),
    )
    ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_orc_compress: (
        HDFS_APACHE.DSCreateHiveTableUseStagingTableHiveTargetTablePropertiesHiveOrcCompress | None
    ) = Field(
        HDFS_APACHE.DSCreateHiveTableUseStagingTableHiveTargetTablePropertiesHiveOrcCompress.zlib,
        alias="_create_hive_table.use_staging_table.hive_target_table_properties.hive_orc_compress",
        description=("Use this property to set the compression type for the target table when the table format is ORC"),
    )
    ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_orc_stripe_size: int | None = Field(
        64,
        alias="_create_hive_table.use_staging_table.hive_target_table_properties.hive_orc_stripe_size",
        description=("Stripe size"),
    )
    ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_parquet_compress: (
        HDFS_APACHE.DSCreateHiveTableUseStagingTableHiveTargetTablePropertiesHiveParquetCompress | None
    ) = Field(
        HDFS_APACHE.DSCreateHiveTableUseStagingTableHiveTargetTablePropertiesHiveParquetCompress.snappy,
        alias="_create_hive_table.use_staging_table.hive_target_table_properties.hive_parquet_compress",
        description=(
            "Use this property to set the compression type for the target table when the table format is Parquet"
        ),
    )
    ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_format: (
        HDFS_APACHE.DSCreateHiveTableUseStagingTableHiveTargetTablePropertiesHiveTargetTableFormat | None
    ) = Field(
        HDFS_APACHE.DSCreateHiveTableUseStagingTableHiveTargetTablePropertiesHiveTargetTableFormat.parquet,
        alias="_create_hive_table.use_staging_table.hive_target_table_properties.hive_target_table_format",
        description=("Use this property to set the format of the target table"),
    )
    ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_location: str | None = Field(
        None,
        alias="_create_hive_table.use_staging_table.hive_target_table_properties.hive_target_table_location",
        description=("Use this property to set the location of the HDFS files serving as storage for the Hive table"),
    )
    ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_type: (
        HDFS_APACHE.DSCreateHiveTableUseStagingTableHiveTargetTablePropertiesHiveTargetTableType | None
    ) = Field(
        HDFS_APACHE.DSCreateHiveTableUseStagingTableHiveTargetTablePropertiesHiveTargetTableType.external,
        alias="_create_hive_table.use_staging_table.hive_target_table_properties.hive_target_table_type",
        description=("Use this property to set the format of the type of the target table."),
    )
    ds_create_hive_table_use_staging_table_load_existing_table_max_dynamic_partitions: int | None = Field(
        1000,
        alias="_create_hive_table.use_staging_table.load_existing_table.max_dynamic_partitions",
        description=(
            "Use this property to set the maximum number of Dynamic paritions to be created while loading into a "
            "partitioned table."
        ),
    )
    ds_exclude_files: str | None = Field(
        None,
        alias="_exclude_files",
        description=(
            "Specify a comma-separated list of file prefixes to exclude from the files that are read. If a "
            "prefix includes a comma, escape the comma by using a backslash (\\\\)."
        ),
    )
    ds_file_exists: HDFS_APACHE.DSFileExists | None = Field(
        HDFS_APACHE.DSFileExists.overwrite_file,
        alias="_file_exists",
        description=(
            "Specify what the connector does when it tries to write a file that already exists. Select "
            "<B>Overwrite file</B> to overwrite a file if it already exists, <B>Do not overwrite file</B> to not "
            "overwrite the file and stop the job, or <B>Fail</B> to stop the job with an error message."
        ),
    )
    ds_file_format: HDFS_APACHE.DSFileFormat | None = Field(
        HDFS_APACHE.DSFileFormat.delimited,
        alias="_file_format",
        description=(
            "Specify the format of the files to read or write. The implicit file format specifies that the input "
            "to the file connector is in binary or string format without a delimiter."
        ),
    )
    ds_file_format_avro_source_output_json: bool | None = Field(
        False,
        alias="_file_format.avro_source.output_json",
        description=("Specify if each rows in the avro file should be exported as JSON to a string column."),
    )
    ds_file_format_avro_target_avro_array_keys: str | None = Field(
        None,
        alias="_file_format.avro_target.avro_array_keys",
        description=(
            "If the file format is Avro in a target stage, then normalization is controlled through array keys. "
            "Specify ''ITERATE()'' in the description for the corresponding array field in column definition in "
            "the input tab of file connector."
        ),
    )
    ds_file_format_avro_target_avro_codec: HDFS_APACHE.DSFileFormatAvroTargetAvroCodec | None = Field(
        HDFS_APACHE.DSFileFormatAvroTargetAvroCodec.none,
        alias="_file_format.avro_target.avro_codec",
        description=("Specify the compression algorithm that will be used to compress the data."),
    )
    ds_file_format_avro_target_avro_schema: str = Field(
        None,
        alias="_file_format.avro_target.avro_schema",
        description=("Specify the fully qualified path for a JSON file that defines the schema for the Avro file."),
    )
    ds_file_format_avro_target_input_json: bool | None = Field(
        False,
        alias="_file_format.avro_target.input_json",
        description=("Specify if each rows in avro file should be imported from a JSON string."),
    )
    ds_file_format_delimited_syntax_encoding: str | None = Field(
        None,
        alias="_file_format.delimited_syntax.encoding",
        description=("Specify the encoding of the files to read or write, for example, UTF-8."),
    )
    ds_file_format_delimited_syntax_encoding_output_bom: bool | None = Field(
        False,
        alias="_file_format.delimited_syntax.encoding.output_bom",
        description=(
            "Specify whether to include a byte order mark in the file when the file encoding is a Unicode "
            "encoding such as UTF-8, UTF-16, or UTF-32."
        ),
    )
    ds_file_format_delimited_syntax_escape: str | None = Field(
        None,
        alias="_file_format.delimited_syntax.escape",
        description=(
            "Specify the character to use to escape field and row delimiters. If an escape character exists in "
            "the data, the escape character is also escaped. Because escape characters require additional "
            "processing, do not specify a value for this property if you do not need to include escape "
            "characters in the data."
        ),
    )
    ds_file_format_delimited_syntax_field_delimiter: str | None = Field(
        ",",
        alias="_file_format.delimited_syntax.field_delimiter",
        description=(
            "Specify a string or one of the following values: <NL>, <CR>, <LF>, <TAB>. The string can include "
            "Unicode escape strings in the form \\\\uNNNN where NNNN is the Unicode character code."
        ),
    )
    ds_file_format_delimited_syntax_field_formats_date_format: str | None = Field(
        None,
        alias="_file_format.delimited_syntax.field_formats.date_format",
        description=("Specify a string that defines the format for fields that have the Date data type."),
    )
    ds_file_format_delimited_syntax_field_formats_decimal_format: str | None = Field(
        None,
        alias="_file_format.delimited_syntax.field_formats.decimal_format",
        description=("Specify a string that defines the format for fields that have the Decimal or Numeric data type."),
    )
    ds_file_format_delimited_syntax_field_formats_time_format: str | None = Field(
        None,
        alias="_file_format.delimited_syntax.field_formats.time_format",
        description=("Specify a string that defines the format for fields that have the Time data type."),
    )
    ds_file_format_delimited_syntax_field_formats_timestamp_format: str | None = Field(
        None,
        alias="_file_format.delimited_syntax.field_formats.timestamp_format",
        description=("Specify a string that defines the format for fields that have the Timestamp data type."),
    )
    ds_file_format_delimited_syntax_header: bool | None = Field(
        False,
        alias="_file_format.delimited_syntax.header",
        description=(
            "Select <B>Yes</B> if the first row of the file contains field headers and is not part of the data. "
            "If you select <B>Yes</B>, when the connector writes data, the field names will be the first row of "
            "the output. If runtime column propagation is enabled, metadata can be obtained from the first row "
            "of the file."
        ),
    )
    ds_file_format_delimited_syntax_header_include_types: bool | None = Field(
        False,
        alias="_file_format.delimited_syntax.header.include_types",
        description=(
            "Select <B>Yes</B> to append the data type to each field name that the connector writes in the first "
            "row of the output."
        ),
    )
    ds_file_format_delimited_syntax_null_value: str | None = Field(
        None,
        alias="_file_format.delimited_syntax.null_value",
        description=(
            "Specify the character or string that represents null values in the data. For a source stage, input "
            "data that has the value that you specify is set to null on the output link. For a target stage, in "
            "the output file that is written to the file system, null values are represented by the value that "
            "is specified for this property. To specify that an empty string represents a null value, specify "
            '"" (two double quotation marks).'
        ),
    )
    ds_file_format_delimited_syntax_quotes: HDFS_APACHE.DSFileFormatDelimitedSyntaxQuotes | None = Field(
        HDFS_APACHE.DSFileFormatDelimitedSyntaxQuotes.none, alias="_file_format.delimited_syntax.quotes"
    )
    ds_file_format_delimited_syntax_record_def: HDFS_APACHE.DSFileFormatDelimitedSyntaxRecordDef | None = Field(
        HDFS_APACHE.DSFileFormatDelimitedSyntaxRecordDef.none,
        alias="_file_format.delimited_syntax.record_def",
        description=(
            "Select whether the record definition is provided to the connector from the source file, a delimited "
            "string, a file that contains a delimited string, or a schema file. When runtime column propagation "
            "is enabled, this metadata provides the column definitions. If a schema file is provided, the schema "
            "file overrides the values of formatting properties in the stage and the column definitions that are "
            "specified on the Columns page of the output link."
        ),
    )
    ds_file_format_delimited_syntax_record_def_record_def_source: str | None = Field(
        None,
        alias="_file_format.delimited_syntax.record_def.record_def_source",
        description=(
            "If the record definition is a delimited string, enter a delimited string that specifies the names "
            "and data types of the files. Use the format name:data_type, and separate each field with the "
            "delimiter specified as the >B<Field delimiter>/B< property. If the record definition is in a "
            "delimited string file or Osh schema file, specify the full path of the file."
        ),
    )
    ds_file_format_delimited_syntax_record_limit: int | None = Field(
        None,
        alias="_file_format.delimited_syntax.record_limit",
        description=(
            "Specify the maximum number of records to read from the file per node. If a value is not specified "
            "for this property, the entire file is read."
        ),
    )
    ds_file_format_delimited_syntax_row_delimiter: str | None = Field(
        "<NL>",
        alias="_file_format.delimited_syntax.row_delimiter",
        description=(
            "Specify a string or one of the following values: <NL>, <CR>, <LF>, <TAB>. The string can include "
            "Unicode escape strings in the form \\\\uNNNN where NNNN is the Unicode character code."
        ),
    )
    ds_file_format_impl_syntax_binary: HDFS_APACHE.DSFileFormatImplSyntaxBinary | None = Field(
        HDFS_APACHE.DSFileFormatImplSyntaxBinary.binary,
        alias="_file_format.impl_syntax.binary",
        description=("Specify the type of implicit file"),
    )
    ds_file_format_impl_syntax_encoding: str | None = Field(
        None,
        alias="_file_format.impl_syntax.encoding",
        description=("Specify the encoding of the files to read or write, for example, UTF-8."),
    )
    ds_file_format_impl_syntax_encoding_output_bom: bool | None = Field(
        False,
        alias="_file_format.impl_syntax.encoding.output_bom",
        description=(
            "Specify whether to include a byte order mark in the file when the file encoding is a Unicode "
            "encoding such as UTF-8, UTF-16, or UTF-32."
        ),
    )
    ds_file_format_impl_syntax_header: bool | None = Field(
        False,
        alias="_file_format.impl_syntax.header",
        description=(
            "Select <B>Yes</B> if the first row of the file contains field headers and is not part of the data. "
            "If you select <B>Yes</B>, when the connector writes data, the field names will be the first row of "
            "the output. If runtime column propagation is enabled, metadata can be obtained from the first row "
            "of the file."
        ),
    )
    ds_file_format_impl_syntax_header_include_types: bool | None = Field(
        False,
        alias="_file_format.impl_syntax.header.include_types",
        description=(
            "Select <B>Yes</B> to append the data type to each field name that the connector writes in the first "
            "row of the output."
        ),
    )
    ds_file_format_impl_syntax_record_def: HDFS_APACHE.DSFileFormatImplSyntaxRecordDef | None = Field(
        HDFS_APACHE.DSFileFormatImplSyntaxRecordDef.none,
        alias="_file_format.impl_syntax.record_def",
        description=(
            "Select whether the record definition is provided to the connector from the source file, a delimited "
            "string, a file that contains a delimited string, or a schema file. When runtime column propagation "
            "is enabled, this metadata provides the column definitions. If a schema file is provided, the schema "
            "file overrides the values of formatting properties in the stage and the column definitions that are "
            "specified on the Columns page of the output link."
        ),
    )
    ds_file_format_impl_syntax_record_def_record_def_source: str | None = Field(
        None,
        alias="_file_format.impl_syntax.record_def.record_def_source",
        description=(
            "Enter a delimited string that specifies the names and data types and length of each fields. Use the "
            "format name:data_type[length], and separate each field with the delimiter specified as the >B<Field "
            "delimiter>/B< property. If the record definition is in a delimited string file or Osh schema file, "
            "specify the full path of the file."
        ),
    )
    ds_file_format_impl_syntax_record_limit: int | None = Field(
        None,
        alias="_file_format.impl_syntax.record_limit",
        description=(
            "Specify the maximum number of records to read from the file per node. If a value is not specified "
            "for this property, the entire file is read."
        ),
    )
    ds_file_format_orc_target_orc_buffer_size: int | None = Field(
        10000, alias="_file_format.orc_target.orc_buffer_size", description=("Buffer Size")
    )
    ds_file_format_orc_target_orc_compress: HDFS_APACHE.DSFileFormatOrcTargetOrcCompress | None = Field(
        HDFS_APACHE.DSFileFormatOrcTargetOrcCompress.snappy,
        alias="_file_format.orc_target.orc_compress",
        description=("Specify Compression mechanism"),
    )
    ds_file_format_orc_target_orc_stripe_size: int | None = Field(
        100000, alias="_file_format.orc_target.orc_stripe_size", description=("Stripe Size")
    )
    ds_file_format_parquet_target_parquet_block_size: int | None = Field(
        10000000, alias="_file_format.parquet_target.parquet_block_size", description=("Block size")
    )
    ds_file_format_parquet_target_parquet_compress: HDFS_APACHE.DSFileFormatParquetTargetParquetCompress | None = Field(
        HDFS_APACHE.DSFileFormatParquetTargetParquetCompress.snappy,
        alias="_file_format.parquet_target.parquet_compress",
        description=("Specify compression mechanism"),
    )
    ds_file_format_parquet_target_parquet_page_size: int | None = Field(
        10000, alias="_file_format.parquet_target.parquet_page_size", description=("Page size")
    )
    ds_file_format_trace_file: str | None = Field(
        None,
        alias="_file_format.trace_file",
        description=(
            "Specify the full path to a file to contain trace information from the parser for delimited files. "
            "Because writing to a trace file requires additional processing, specify a value for this property "
            "only during job development."
        ),
    )
    ds_filename_column: str | None = Field(
        None, alias="_filename_column", description=("Specify the name of the column to write the source file name to.")
    )
    ds_filename_source: str = Field(
        None,
        alias="_filename_source",
        description=("Specify the name of the file to read from, or specify a pattern to read from multiple files."),
    )
    ds_filename_target: str = Field(
        None, alias="_filename_target", description="Specify the name of the file to write to."
    )
    ds_force_sequential: bool | None = Field(
        False, alias="_force_sequential", description=("Select Yes to run the connector sequentially on one node.")
    )
    ds_java_heap_size: int | None = Field(
        256, alias="_java._heap_size", description=("Specify the maximum Java Virtual Machine heap size in megabytes.")
    )
    ds_java_heap_size: int | None = Field(256, alias="_java.heap_size", description="Heap size.")
    ds_max_file_size: int | None = Field(
        0,
        alias="_max_file_size",
        description=(
            "Specify the maximum file size in megabytes. Processing nodes will start a new file each time the "
            "size exceeds this value."
        ),
    )
    ds_read_mode: HDFS_APACHE.DSReadMode | None = Field(
        HDFS_APACHE.DSReadMode.read_single_file,
        alias="_read_mode",
        description=(
            "Select <B>Read single file</B> to read from a single file or <B>Read multiple files</B> to read "
            "from the files that match a specified file prefix. Select <B>List buckets</B> to list the buckets "
            "for your account in the specified region. Select <B>List files</B> to list files files for your "
            "account in the specified bucket."
        ),
    )
    ds_reject_mode: HDFS_APACHE.DSRejectMode | None = Field(
        HDFS_APACHE.DSRejectMode.cont,
        alias="_reject_mode",
        description=(
            "Specify what the connector does when a record that contains invalid data is found in the source "
            "file. Select <B>Continue</B> to read the rest of the file, <B>Fail</B> to stop the job with an "
            "error message, or <B>Reject</B> to send the rejected data to a reject link."
        ),
    )
    ds_split_on_key: bool | None = Field(
        False,
        alias="_split_on_key",
        description=(
            "Select Yes to create a new file when key column value changes. Data must be sorted and partitioned "
            "for this to work properly."
        ),
    )
    ds_split_on_key_case_sensitive: bool | None = Field(
        False, alias="_split_on_key.case_sensitive", description=("Select Yes to make the key value case sensitive.")
    )
    ds_split_on_key_exclude_part_string: bool | None = Field(
        False,
        alias="_split_on_key.exclude_part_string",
        description=("Select Yes to exclude the partition string each processing node appends to the file name."),
    )
    ds_split_on_key_key_column: str | None = Field(
        None,
        alias="_split_on_key.key_column",
        description=(
            "Specify the key column to use for splitting files. If not specified, the connector will use the "
            "first key column on the link."
        ),
    )
    ds_split_on_key_key_in_filename: bool | None = Field(
        False,
        alias="_split_on_key.key_in_filename",
        description=("Select Yes to use the key value in the generated file name."),
    )
    ds_use_datastage: bool | None = Field(
        True,
        alias="_use_datastage",
        description=(
            "The DataStage-specific properties provide more features and granular control of the flow execution, "
            "similar to DataStage 'optimized' connectors."
        ),
    )
    ds_user_class_name: str | None = Field(
        "com.ibm.iis.cc.filesystem.FileSystem", alias="_user_class_name", description=("user_class_name")
    )
    ds_wave_handling_append_uid: bool | None = Field(
        False,
        alias="_wave_handling.append_uid",
        description=(
            "Use this property to choose if a unique identifier is to be appended to the file name. When the "
            "value of this property is set to yes, then the file name gets appended with the unique identifier, "
            "and a new file would be written for every wave of data that is streamed into the stage. When the "
            "value of this property is set to No, then the file would be overwritten on every wave"
        ),
    )
    ds_wave_handling_file_size_threshold: int | None = Field(
        1,
        alias="_wave_handling.file_size_threshold",
        description=(
            "Specify the threshold for the file size in megabytes. Processing nodes will start a new file each "
            "time the size exceeds the value specified in the threshold and on reaching the wave boundary. The "
            "file will be written only on the wave boundary and hence the threshold value specified is only a "
            "soft limit. The actual size of the file can be higher than the specified threshold depending on the "
            "size of the wave"
        ),
    )
    ds_write_mode: HDFS_APACHE.DSWriteMode | None = Field(
        HDFS_APACHE.DSWriteMode.write_single_file,
        alias="_write_mode",
        description=(
            "Select Write single file to write a file per node, select Write multiple files to write multiple "
            "files per node (based on size and/or key value), or select Delete to delete files."
        ),
    )
    enable_flow_acp_control: bool = Field(True, alias="enableFlowAcpControl")
    enable_schemaless_design: bool = Field(False, alias="enableSchemalessDesign")
    encoding: str | None = Field(
        "utf-8", alias="encoding", description=("The appropriate character encoding for your data, for example, UTF-8")
    )
    encryption_key: str | None = Field(None, alias="encryption_key", description="Key to decrypt sav file")
    endpoint_folder: str | None = Field(None, alias="table_folder_name", description="The endpoint folder of the table")
    escape_character: HDFS_APACHE.EscapeCharacter | None = Field(
        HDFS_APACHE.EscapeCharacter.none,
        alias="escape_character",
        description=(
            "The character that's used to escape other characters, for example, a backslash. Escaping is a "
            "string technique that identifies characters as being part of a string value."
        ),
    )
    escape_character_value: str = Field(
        None,
        alias="escape_character_value",
        description=("The custom character that is used to escape other characters."),
    )
    exclude_missing_values: bool | None = Field(
        None,
        alias="exclude_missing_values",
        description=("Set values that have been defined as missing values to null"),
    )
    execution_mode: HDFS_APACHE.ExecutionMode | None = Field(
        HDFS_APACHE.ExecutionMode.default_par,
        alias="execmode",
        description=("Specify whether your stage runs sequentially or in parallel."),
    )
    field_delimiter: HDFS_APACHE.FieldDelimiter | None = Field(
        HDFS_APACHE.FieldDelimiter.comma,
        alias="field_delimiter",
        description=("The character that separates each value from the next value, for example, a comma"),
    )
    field_delimiter_value: str = Field(
        None,
        alias="field_delimiter_value",
        description=("The custom character that separates each value from the next value"),
    )
    fields_xml_path: str | None = Field(
        None,
        alias="xml_path_fields",
        description=(
            "The path that identifies the specified elements to retrieve from the root path of a XML document, "
            "for example, ../publisher"
        ),
    )
    file_format: HDFS_APACHE.FileFormat | None = Field(
        HDFS_APACHE.FileFormat.csv, alias="file_format", description=("The format of the file to write to")
    )
    file_name: str = Field(None, alias="file_name", description="The name of the file to write to or delete")
    first_line: int | None = Field(0, alias="first_line", description="Indicates at which row start reading")
    first_line_is_header: bool | None = Field(
        False, alias="first_line_header", description=("Indicates whether the row where reading starts is the header")
    )
    flow_dirty: str | None = Field("false", alias="flow_dirty")
    generate_unicode_type_columns: bool | None = Field(
        False,
        alias="generate_unicode_columns",
        description=(
            "Generate unicode type columns. This property can be set/is applicable only when runtime column "
            "propagation is used"
        ),
    )
    hide: bool | None = Field(False, alias="hide")
    hive_table: str | None = Field(None, alias="hive_table", description="The name of the table to create")
    include_types: bool | None = Field(
        False, alias="include_types", description=("Include data types in the first line of the file")
    )
    infer_as_varchar: bool | None = Field(
        None, alias="infer_as_varchar", description=("Treat the data in all columns as VARCHARs")
    )
    infer_null_as_empty_string: bool | None = Field(
        False,
        alias="infer_null_as_empty_string",
        description=("Treat empty values in string type columns as empty strings instead of null"),
    )
    infer_record_count: int | None = Field(
        1000,
        alias="infer_record_count",
        description=("The number of records to process to obtain the structure of the data"),
    )
    infer_schema: bool | None = Field(None, alias="infer_schema", description="Obtain the schema from the file")
    infer_timestamp_as_date: bool | None = Field(
        True, alias="infer_timestamp_as_date", description=("Infer columns containing date and time data as date")
    )
    input_count: int | None = Field(0, alias="input_count", description="Input count")
    input_link_description: list | None = Field("", alias="inputLinkDescription")
    inputcol_properties: list | None = Field([], alias="inputcolProperties")
    invalid_data_handling: HDFS_APACHE.InvalidDataHandling | None = Field(
        HDFS_APACHE.InvalidDataHandling.fail,
        alias="invalid_data_handling",
        description=("How to handle values that are not valid: fail the job, null the column, or drop the row"),
    )
    is_reject: bool | None = Field(
        False,
        alias="is_reject",
        description=("Select Yes if the link is configured to carry rejected data from the source stage."),
    )
    json_infer_record_count: int | None = Field(
        None,
        alias="json_infer_record_count",
        description=(
            "Deprecated. Use infer_record_count property. The number of JSON elements to process to obtain the "
            "structure of the data"
        ),
    )
    json_path: str | None = Field(
        None,
        alias="json_path",
        description=(
            "The path that identifies the elements to retrieve from a JSON document, for example, $.book.publisher"
        ),
    )
    key_cols_coll: list | None = Field([], alias="keyColsColl")
    key_cols_coll_ordered: list | None = Field([], alias="keyColsCollOrdered")
    key_cols_coll_robin: list | None = Field([], alias="keyColsCollRobin")
    key_cols_none: list | None = Field([], alias="keyColsNone")
    key_cols_part: list | None = Field([], alias="keyColsPart")
    labels_as_names: bool | None = Field(
        None, alias="labels_as_names", description=("Set column names to the value of the column label")
    )
    max_mem_buf_size_ronly: int | None = Field(3145728, alias="max_mem_buf_size_ronly")
    maximum_memory_buffer_size_bytes: int | None = Field(
        3145728,
        alias="max_mem_buf_size",
        description=(
            "Specifies the maximum amount of virtual memory, in bytes, used per buffer. The default size is "
            "3145728 (3 MB)."
        ),
    )
    names_as_labels: bool | None = Field(
        None, alias="names_as_labels", description=("Set column labels to the value of the column name")
    )
    node_count: int | None = Field(1, alias="node_count", description="Node count")
    node_number: int | None = Field(0, alias="node_number", description="Node number")
    null_value: str | None = Field(
        None,
        alias="null_value",
        description=("The value that represents null (a missing value) in the file, for example, NULL"),
    )
    output_acp_should_hide: bool = Field(True, alias="outputAcpShouldHide")
    output_avro_as_json: bool | None = Field(
        None,
        alias="output_avro_as_json",
        description=("Each row in the Avro file would be exported as JSON to a string column"),
    )
    output_count: int | None = Field(1, alias="output_count", description="Output count")
    output_link_description: list | None = Field("", alias="outputLinkDescription")
    outputcol_properties: list | None = Field([], alias="outputcolProperties")
    part_stable_coll: bool | None = Field(False, alias="part_stable_coll")
    part_stable_ordered: bool | None = Field(False, alias="part_stable_ordered")
    part_stable_roundrobin_coll: bool | None = Field(False, alias="part_stable_roundrobin_coll")
    part_unique_coll: bool | None = Field(False, alias="part_unique_coll")
    part_unique_ordered: bool | None = Field(False, alias="part_unique_ordered")
    part_unique_roundrobin_coll: bool | None = Field(False, alias="part_unique_roundrobin_coll")
    partition_name_prefix: str | None = Field(
        "part", alias="partition_name_prefix", description=("The prefix in each partition name")
    )
    partition_type: HDFS_APACHE.PartitionType | None = Field(
        HDFS_APACHE.PartitionType.auto, alias="part_type", description=("Partition type")
    )
    partitioned: bool | None = Field(False, alias="partitioned", description="Write the file as multiple partitions")
    perform_sort: bool | None = Field(False, alias="perform_sort", description="Perform sort")
    perform_sort_coll: bool | None = Field(False, alias="perform_sort_coll")
    perform_sort_modulus: bool | None = Field(False, alias="perform_sort_modulus", description="Perform sort")
    preserve_partitioning: HDFS_APACHE.PreservePartitioning | None = Field(
        HDFS_APACHE.PreservePartitioning.default_propagate,
        alias="preserve",
        description=("Specify whether to maintain data in current partitions."),
    )
    queue_upper_bound_size_bytes: int | None = Field(
        0,
        alias="queue_upper_size",
        description=("Specifies the maximum amount of data buffered at any time using both memory and disk."),
    )
    queue_upper_size_ronly: int | None = Field(0, alias="queue_upper_size_ronly")
    quote_character: HDFS_APACHE.QuoteCharacter | None = Field(
        HDFS_APACHE.QuoteCharacter.none,
        alias="quote_character",
        description=("The character that's used to enclose string values, for example, a double quotation mark"),
    )
    quote_numeric_values: bool | None = Field(
        True,
        alias="quote_numerics",
        description=("Enclose numeric values the same as strings using the quote character"),
    )
    read_mode: HDFS_APACHE.ReadMode | None = Field(
        HDFS_APACHE.ReadMode.read_single, alias="read_mode", description=("The method for reading files")
    )
    row_delimiter: HDFS_APACHE.RowDelimiter | None = Field(
        HDFS_APACHE.RowDelimiter.new_line,
        alias="row_delimiter",
        description=(
            "The character or characters that separate one line from another, for example, CR/LF (Carriage "
            "Return/Line Feed)"
        ),
    )
    row_delimiter_value: str = Field(
        None, alias="row_delimiter_value", description=("The custom string that separates each rows from the next one.")
    )
    row_limit: int | None = Field(None, alias="row_limit", description="The maximum number of rows to return")
    runtime_column_propagation: bool | None = Field(
        None,
        alias="runtime_column_propagation",
        description=("Propagate extra columns that are not defined in the metadata through the rest of the job."),
    )
    schema_of_xml: str | None = Field(
        None,
        alias="xml_schema",
        description=(
            "The schema that specified metadata information of elements, for example, data type, values, min, max"
        ),
    )
    show_coll_type: int | None = Field(0, alias="showCollType")
    show_part_type: int | None = Field(1, alias="showPartType")
    show_sort_options: int | None = Field(0, alias="showSortOptions")
    sort_instructions: str | None = Field("", alias="sortInstructions")
    sort_instructions_text: str | None = Field("", alias="sortInstructionsText")
    sorting_key: HDFS_APACHE.KeyColSelect | None = Field(HDFS_APACHE.KeyColSelect.default, alias="keyColSelect")
    stable: bool | None = Field(
        None, alias="part_stable", description=("Select Stable if you want to preserve previously sorted data sets.")
    )
    stage_description: list | None = Field("", alias="stageDescription", description="Description")
    store_shared_strings_in_the_temporary_file: bool | None = Field(
        None,
        alias="use_sst_temp_file",
        description=(
            "Whether to store shared strings in the encrypted temporary file and trade memory usage for a disk "
            "space usage. Shared strings are stored in the memory by default, which can lead to memory issues "
            "when dealing with large workbooks. It is recommended to enable this option for a large XLSX files."
        ),
    )
    table_action: HDFS_APACHE.TableAction | None = Field(
        HDFS_APACHE.TableAction.append,
        alias="table_action",
        description=("The action to take on the target table to handle the new data set"),
    )
    table_data_file_compression_codec: HDFS_APACHE.TableDataFileCompressionCodec | None = Field(
        None, alias="table_data_file_compression_codec", description=("The compression codec of table data file")
    )
    table_data_file_format: HDFS_APACHE.TableDataFileFormat | None = Field(
        HDFS_APACHE.TableDataFileFormat.avro,
        alias="table_data_file_format",
        description=("The format of the table data file"),
    )
    table_format: HDFS_APACHE.TableFormat | None = Field(
        None, alias="table_format", description=("The format of the table")
    )
    table_name: str | None = Field(None, alias="table_name", description="The name of the table")
    table_namespace: str | None = Field(None, alias="table_namespace", description="The namespace of the table")
    the_cache_expiration: str | None = Field(
        None, alias="table_partition_cache_expiration", description=("The eviction time for partition writers")
    )
    the_cache_size: int | None = Field(
        None, alias="table_partition_cache_size", description=("The size of cache for partition writers")
    )
    the_data_path: str | None = Field(
        None, alias="table_data_path", description=("The start path for storing files with data")
    )
    the_partition_columns: str | None = Field(
        None, alias="table_partition_columns", description=("The columns for partitions")
    )
    the_partition_paths: str | None = Field(
        None, alias="table_partition_path", description=("The path for partitioned data")
    )
    time_format: str | None = Field(
        None, alias="time_format", description=("The format of time values, for example, HH:mm:ss[.f]")
    )
    timestamp_format: str | None = Field(
        None, alias="timestamp_format", description=("The format of timestamp values, for example, yyyy-MM-dd H:m:s")
    )
    timezone_format: str | None = Field(
        None,
        alias="time_zone_format",
        description=("The format of timezone values, for example, yyyy-MM-dd HH:mm:ss.SSS XXX"),
    )
    type_mapping: str | None = Field(
        None,
        alias="type_mapping",
        description=(
            "Overrides the data types of specified columns in the file's inferred schema, for example, "
            "inferredType1:newType1;inferredType2:newType2"
        ),
    )
    unique: bool | None = Field(
        None,
        alias="part_unique",
        description=(
            "Select Unique to specify that, if multiple records have identical sorting key values, only one "
            "record is retained. If stable sort is also set, the first record is retained."
        ),
    )
    use_4_digit_years_in_date_formats: bool | None = Field(
        None,
        alias="use_4_digit_year",
        description=("Whether to use 4 digit years in all date formats. By default, 2 digit years will be used."),
    )
    use_field_formats: bool | None = Field(
        None, alias="use_field_formats", description=("Format data using specified field formats")
    )
    use_variable_formats: bool | None = Field(
        None, alias="use_variable_formats", description=("Format data using specified variable formats.")
    )
    worksheet_name: str | None = Field(
        None, alias="sheet_name", description=("The name of the Excel worksheet to write to")
    )
    write_mode: HDFS_APACHE.WriteMode | None = Field(
        HDFS_APACHE.WriteMode.write, alias="write_mode", description=("Whether to write to, or delete, the target")
    )
    xml_path: str | None = Field(
        None,
        alias="xml_path",
        description=(
            "The path that identifies the root elements to retrieve from a XML document, for example, /book/publisher"
        ),
    )

    def _validate_parameters(self) -> tuple[set, set]:
        include = set()
        exclude = set()

        include.add("preserve_partitioning") if (self.output_count and self.output_count > 0) else exclude.add(
            "preserve_partitioning"
        )
        return include, exclude

    def _validate_source(self) -> tuple[set, set]:
        include = set()
        exclude = set()

        include.add("ds_file_format_delimited_syntax_field_formats_decimal_format") if (
            (self.ds_file_format == "comma-separated_value_csv") or (self.ds_file_format == "delimited")
        ) else exclude.add("ds_file_format_delimited_syntax_field_formats_decimal_format")
        include.add("ds_file_format_delimited_syntax_row_delimiter") if (
            self.ds_file_format == "delimited"
        ) else exclude.add("ds_file_format_delimited_syntax_row_delimiter")
        include.add("ds_file_format_delimited_syntax_record_def") if (
            (self.ds_file_format == "comma-separated_value_csv") or (self.ds_file_format == "delimited")
        ) else exclude.add("ds_file_format_delimited_syntax_record_def")
        include.add("ds_file_format_impl_syntax_record_def") if (self.ds_file_format == "implicit") else exclude.add(
            "ds_file_format_impl_syntax_record_def"
        )
        include.add("ds_file_format_delimited_syntax_field_formats_time_format") if (
            (self.ds_file_format == "comma-separated_value_csv") or (self.ds_file_format == "delimited")
        ) else exclude.add("ds_file_format_delimited_syntax_field_formats_time_format")
        include.add("ds_file_format_delimited_syntax_record_def_record_def_source") if (
            (self.ds_file_format_delimited_syntax_record_def == "delimited_string")
            or (self.ds_file_format_delimited_syntax_record_def == "delimited_string_in_a_file")
            or (self.ds_file_format_delimited_syntax_record_def == "schema_file")
        ) else exclude.add("ds_file_format_delimited_syntax_record_def_record_def_source")
        include.add("ds_file_format_delimited_syntax_field_formats_date_format") if (
            (self.ds_file_format == "comma-separated_value_csv") or (self.ds_file_format == "delimited")
        ) else exclude.add("ds_file_format_delimited_syntax_field_formats_date_format")
        include.add("ds_file_format_delimited_syntax_header") if (
            (self.ds_file_format_delimited_syntax_record_def == "delimited_string")
            or (self.ds_file_format_delimited_syntax_record_def == "delimited_string_in_a_file")
            or (self.ds_file_format_delimited_syntax_record_def == "none")
            or (self.ds_file_format_delimited_syntax_record_def == "schema_file")
        ) else exclude.add("ds_file_format_delimited_syntax_header")
        include.add("ds_file_format_avro_source_output_json") if (self.ds_file_format == "avro") else exclude.add(
            "ds_file_format_avro_source_output_json"
        )
        include.add("ds_file_format_impl_syntax_record_limit") if (self.ds_file_format == "implicit") else exclude.add(
            "ds_file_format_impl_syntax_record_limit"
        )
        include.add("ds_file_format_delimited_syntax_escape") if (self.ds_file_format == "delimited") else exclude.add(
            "ds_file_format_delimited_syntax_escape"
        )
        include.add("ds_reject_mode") if (
            (self.ds_file_format == "avro")
            or (self.ds_file_format == "comma-separated_value_csv")
            or (self.ds_file_format == "delimited")
            or (self.ds_file_format == "implicit")
        ) else exclude.add("ds_reject_mode")
        include.add("ds_file_format_delimited_syntax_null_value") if (
            (self.ds_file_format == "comma-separated_value_csv") or (self.ds_file_format == "delimited")
        ) else exclude.add("ds_file_format_delimited_syntax_null_value")
        include.add("ds_file_format_delimited_syntax_record_limit") if (
            (self.ds_file_format == "comma-separated_value_csv") or (self.ds_file_format == "delimited")
        ) else exclude.add("ds_file_format_delimited_syntax_record_limit")
        include.add("ds_file_format_impl_syntax_binary") if (self.ds_file_format == "implicit") else exclude.add(
            "ds_file_format_impl_syntax_binary"
        )
        include.add("ds_file_format_delimited_syntax_field_delimiter") if (
            self.ds_file_format == "delimited"
        ) else exclude.add("ds_file_format_delimited_syntax_field_delimiter")
        include.add("ds_file_format_impl_syntax_header") if (
            (self.ds_file_format_impl_syntax_record_def == "delimited_string")
            or (self.ds_file_format_impl_syntax_record_def == "delimited_string_in_a_file")
            or (self.ds_file_format_impl_syntax_record_def == "none")
            or (self.ds_file_format_impl_syntax_record_def == "schema_file")
        ) else exclude.add("ds_file_format_impl_syntax_header")
        include.add("ds_file_format_impl_syntax_encoding") if (self.ds_file_format == "implicit") else exclude.add(
            "ds_file_format_impl_syntax_encoding"
        )
        include.add("ds_file_format_delimited_syntax_field_formats_timestamp_format") if (
            (self.ds_file_format == "comma-separated_value_csv") or (self.ds_file_format == "delimited")
        ) else exclude.add("ds_file_format_delimited_syntax_field_formats_timestamp_format")
        include.add("ds_file_format_delimited_syntax_quotes") if (self.ds_file_format == "delimited") else exclude.add(
            "ds_file_format_delimited_syntax_quotes"
        )
        include.add("ds_file_format_impl_syntax_record_def_record_def_source") if (
            (self.ds_file_format_impl_syntax_record_def == "delimited_string")
            or (self.ds_file_format_impl_syntax_record_def == "delimited_string_in_a_file")
            or (self.ds_file_format_impl_syntax_record_def == "schema_file")
        ) else exclude.add("ds_file_format_impl_syntax_record_def_record_def_source")
        include.add("ds_file_format_delimited_syntax_encoding") if (
            (self.ds_file_format == "comma-separated_value_csv") or (self.ds_file_format == "delimited")
        ) else exclude.add("ds_file_format_delimited_syntax_encoding")
        include.add("decimal_separator") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                        or (self.file_format == "avro")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                        or (self.file_format == "parquet")
                    )
                )
            )
            and (not self.output_avro_as_json)
        ) else exclude.add("decimal_separator")
        include.add("xml_path") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "xml") or (self.file_format == "xml")
            )
        ) else exclude.add("xml_path")
        include.add("table_namespace") if (
            (
                self.table_format
                and (
                    (hasattr(self.table_format, "value") and self.table_format.value == "iceberg")
                    or (self.table_format == "iceberg")
                )
            )
            and (self.endpoint_folder)
        ) else exclude.add("table_namespace")
        include.add("null_value") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
        ) else exclude.add("null_value")
        include.add("output_avro_as_json") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                or (self.file_format == "avro")
            )
        ) else exclude.add("output_avro_as_json")
        include.add("first_line_is_header") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                    or (self.file_format == "excel")
                )
            )
        ) else exclude.add("first_line_is_header")
        include.add("table_name") if (self.endpoint_folder) else exclude.add("table_name")
        include.add("store_shared_strings_in_the_temporary_file") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                or (self.file_format == "excel")
            )
        ) else exclude.add("store_shared_strings_in_the_temporary_file")
        include.add("quote_character") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
        ) else exclude.add("quote_character")
        include.add("infer_null_as_empty_string") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                    or (self.file_format == "excel")
                )
            )
        ) else exclude.add("infer_null_as_empty_string")
        include.add("escape_character") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
        ) else exclude.add("escape_character")
        include.add("display_value_labels") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "sav")
                    or (self.file_format == "sav")
                )
            )
            and (not self.exclude_missing_values)
        ) else exclude.add("display_value_labels")
        include.add("invalid_data_handling") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
        ) else exclude.add("invalid_data_handling")
        include.add("escape_character_value") if (
            self.escape_character
            and (
                (hasattr(self.escape_character, "value") and self.escape_character.value == "<?>")
                or (self.escape_character == "<?>")
            )
        ) else exclude.add("escape_character_value")
        include.add("time_format") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                        or (self.file_format == "avro")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                        or (self.file_format == "parquet")
                    )
                )
            )
            and (not self.output_avro_as_json)
        ) else exclude.add("time_format")
        include.add("fields_xml_path") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "xml")
                    or (self.file_format == "xml")
                )
            )
            and (self.xml_path)
        ) else exclude.add("fields_xml_path")
        include.add("schema_of_xml") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "xml")
                    or (self.file_format == "xml")
                )
            )
            and (self.infer_schema)
        ) else exclude.add("schema_of_xml")
        include.add("encoding") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "shp")
                    or (self.file_format == "shp")
                )
            )
        ) else exclude.add("encoding")
        include.add("field_delimiter") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                or (self.file_format == "delimited")
            )
        ) else exclude.add("field_delimiter")
        include.add("use_variable_formats") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "sas")
                    or (self.file_format == "sas")
                )
            )
            and (not self.infer_schema)
        ) else exclude.add("use_variable_formats")
        include.add("timestamp_format") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                        or (self.file_format == "avro")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                        or (self.file_format == "parquet")
                    )
                )
            )
            and (not self.output_avro_as_json)
        ) else exclude.add("timestamp_format")
        include.add("infer_record_count") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                        or (self.file_format == "excel")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "json")
                        or (self.file_format == "json")
                    )
                )
            )
            and (self.infer_schema)
        ) else exclude.add("infer_record_count")
        include.add("decimal_grouping_separator") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                        or (self.file_format == "avro")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                        or (self.file_format == "parquet")
                    )
                )
            )
            and (not self.output_avro_as_json)
        ) else exclude.add("decimal_grouping_separator")
        include.add("exclude_missing_values") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "sav")
                    or (self.file_format == "sav")
                )
            )
            and (not self.display_value_labels)
        ) else exclude.add("exclude_missing_values")
        include.add("encryption_key") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "sav") or (self.file_format == "sav")
            )
        ) else exclude.add("encryption_key")
        include.add("worksheet_name") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                or (self.file_format == "excel")
            )
        ) else exclude.add("worksheet_name")
        include.add("table_format") if (
            self.read_mode
            and (
                (hasattr(self.read_mode, "value") and self.read_mode.value == "read_single")
                or (self.read_mode == "read_single")
            )
        ) else exclude.add("table_format")
        include.add("infer_timestamp_as_date") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "sav") or (self.file_format == "sav")
            )
        ) else exclude.add("infer_timestamp_as_date")
        include.add("first_line") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                    or (self.file_format == "excel")
                )
            )
        ) else exclude.add("first_line")
        include.add("endpoint_folder") if (
            (
                self.table_format
                and (
                    (hasattr(self.table_format, "value") and self.table_format.value == "deltalake")
                    or (self.table_format == "deltalake")
                )
            )
            or (
                self.table_format
                and (
                    (hasattr(self.table_format, "value") and self.table_format.value == "iceberg")
                    or (self.table_format == "iceberg")
                )
            )
        ) else exclude.add("endpoint_folder")
        include.add("cell_range") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                or (self.file_format == "excel")
            )
        ) else exclude.add("cell_range")
        include.add("use_4_digit_years_in_date_formats") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                or (self.file_format == "excel")
            )
        ) else exclude.add("use_4_digit_years_in_date_formats")
        include.add("json_infer_record_count") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "json")
                or (self.file_format == "json")
            )
        ) else exclude.add("json_infer_record_count")
        include.add("file_format") if (
            (
                (
                    self.read_mode
                    and (
                        (hasattr(self.read_mode, "value") and self.read_mode.value == "read_multiple_regex")
                        or (self.read_mode == "read_multiple_regex")
                    )
                )
                or (
                    self.read_mode
                    and (
                        (hasattr(self.read_mode, "value") and self.read_mode.value == "read_multiple_wildcard")
                        or (self.read_mode == "read_multiple_wildcard")
                    )
                )
                or (
                    self.read_mode
                    and (
                        (hasattr(self.read_mode, "value") and self.read_mode.value == "read_single")
                        or (self.read_mode == "read_single")
                    )
                )
            )
            and (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                        or (self.table_format != "deltalake")
                    )
                )
                and (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                        or (self.table_format != "iceberg")
                    )
                )
            )
        ) else exclude.add("file_format")
        include.add("field_delimiter_value") if (
            self.field_delimiter
            and (
                (hasattr(self.field_delimiter, "value") and self.field_delimiter.value == "<?>")
                or (self.field_delimiter == "<?>")
            )
        ) else exclude.add("field_delimiter_value")
        include.add("row_delimiter") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                or (self.file_format == "delimited")
            )
        ) else exclude.add("row_delimiter")
        include.add("use_field_formats") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "sav") or (self.file_format == "sav")
            )
        ) else exclude.add("use_field_formats")
        include.add("file_name") if (
            (
                self.table_format
                and (
                    (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                    or (self.table_format != "deltalake")
                )
            )
            and (
                self.table_format
                and (
                    (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                    or (self.table_format != "iceberg")
                )
            )
        ) else exclude.add("file_name")
        include.add("json_path") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "json")
                or (self.file_format == "json")
            )
        ) else exclude.add("json_path")
        include.add("row_delimiter_value") if (
            self.row_delimiter
            and (
                (hasattr(self.row_delimiter, "value") and self.row_delimiter.value == "<?>")
                or (self.row_delimiter == "<?>")
            )
        ) else exclude.add("row_delimiter_value")
        include.add("decimal_format") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                        or (self.file_format == "avro")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                        or (self.file_format == "parquet")
                    )
                )
            )
            and (not self.output_avro_as_json)
        ) else exclude.add("decimal_format")
        include.add("decimal_rounding_mode") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
        ) else exclude.add("decimal_rounding_mode")
        include.add("labels_as_names") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "sav") or (self.file_format == "sav")
            )
        ) else exclude.add("labels_as_names")
        include.add("date_format") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                        or (self.file_format == "avro")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                        or (self.file_format == "parquet")
                    )
                )
            )
            and (not self.output_avro_as_json)
        ) else exclude.add("date_format")
        include.add("type_mapping") if (
            (
                (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                            or (self.file_format == "csv")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                            or (self.file_format == "delimited")
                        )
                    )
                )
                or (self.infer_schema)
            )
            and (self.infer_schema)
        ) else exclude.add("type_mapping")
        include.add("decimal_separator") if (
            (
                (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                            or (self.file_format == "avro")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                            or (self.file_format == "csv")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                            or (self.file_format == "delimited")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                            or (self.file_format == "parquet")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (
                                hasattr(self.file_format, "value")
                                and self.file_format.value
                                and "#" in str(self.file_format.value)
                            )
                            or ("#" in str(self.file_format))
                        )
                    )
                )
                and (
                    (not self.output_avro_as_json)
                    or (self.output_avro_as_json and "#" in str(self.output_avro_as_json))
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("decimal_separator")
        include.add("xml_path") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "xml")
                        or (self.file_format == "xml")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("xml_path")
        include.add("table_namespace") if (
            (
                (
                    (
                        self.table_format
                        and (
                            (hasattr(self.table_format, "value") and self.table_format.value == "iceberg")
                            or (self.table_format == "iceberg")
                        )
                    )
                    or (
                        self.table_format
                        and (
                            (
                                hasattr(self.table_format, "value")
                                and self.table_format.value
                                and "#" in str(self.table_format.value)
                            )
                            or ("#" in str(self.table_format))
                        )
                    )
                )
                and ((self.endpoint_folder) or (self.endpoint_folder and "#" in str(self.endpoint_folder)))
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("table_namespace")
        include.add("null_value") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("null_value")
        include.add("ds_file_format_delimited_syntax_field_formats_decimal_format") if (
            (
                (self.ds_file_format == "comma-separated_value_csv")
                or (self.ds_file_format == "delimited")
                or (self.ds_file_format and "#" in str(self.ds_file_format))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_delimited_syntax_field_formats_decimal_format")
        include.add("output_avro_as_json") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                        or (self.file_format == "avro")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("output_avro_as_json")
        include.add("first_line_is_header") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                        or (self.file_format == "excel")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("first_line_is_header")
        include.add("table_name") if (
            ((self.endpoint_folder) or (self.endpoint_folder and "#" in str(self.endpoint_folder)))
            and (not self.ds_use_datastage)
        ) else exclude.add("table_name")
        include.add("ds_file_format_delimited_syntax_row_delimiter") if (
            ((self.ds_file_format == "delimited") or (self.ds_file_format and "#" in str(self.ds_file_format)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_delimited_syntax_row_delimiter")
        include.add("ds_file_format_delimited_syntax_record_def") if (
            (
                (self.ds_file_format == "comma-separated_value_csv")
                or (self.ds_file_format == "delimited")
                or (self.ds_file_format and "#" in str(self.ds_file_format))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_delimited_syntax_record_def")
        include.add("ds_file_format_impl_syntax_record_def") if (
            ((self.ds_file_format == "implicit") or (self.ds_file_format and "#" in str(self.ds_file_format)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_impl_syntax_record_def")
        include.add("ds_file_format_delimited_syntax_field_formats_time_format") if (
            (
                (self.ds_file_format == "comma-separated_value_csv")
                or (self.ds_file_format == "delimited")
                or (self.ds_file_format and "#" in str(self.ds_file_format))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_delimited_syntax_field_formats_time_format")
        include.add("store_shared_strings_in_the_temporary_file") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                        or (self.file_format == "excel")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("store_shared_strings_in_the_temporary_file")
        include.add("ds_file_format_delimited_syntax_record_def_record_def_source") if (
            (
                (self.ds_file_format_delimited_syntax_record_def == "delimited_string")
                or (self.ds_file_format_delimited_syntax_record_def == "delimited_string_in_a_file")
                or (self.ds_file_format_delimited_syntax_record_def == "schema_file")
                or (
                    self.ds_file_format_delimited_syntax_record_def
                    and "#" in str(self.ds_file_format_delimited_syntax_record_def)
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_delimited_syntax_record_def_record_def_source")
        include.add("quote_character") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("quote_character")
        include.add("infer_null_as_empty_string") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                        or (self.file_format == "excel")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("infer_null_as_empty_string")
        include.add("escape_character") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("escape_character")
        include.add("display_value_labels") if (
            (
                (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "sav")
                            or (self.file_format == "sav")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (
                                hasattr(self.file_format, "value")
                                and self.file_format.value
                                and "#" in str(self.file_format.value)
                            )
                            or ("#" in str(self.file_format))
                        )
                    )
                )
                and (
                    (not self.exclude_missing_values)
                    or (self.exclude_missing_values and "#" in str(self.exclude_missing_values))
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("display_value_labels")
        include.add("invalid_data_handling") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("invalid_data_handling")
        include.add("escape_character_value") if (
            (
                (
                    self.escape_character
                    and (
                        (hasattr(self.escape_character, "value") and self.escape_character.value == "<?>")
                        or (self.escape_character == "<?>")
                    )
                )
                or (
                    self.escape_character
                    and (
                        (
                            hasattr(self.escape_character, "value")
                            and self.escape_character.value
                            and "#" in str(self.escape_character.value)
                        )
                        or ("#" in str(self.escape_character))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("escape_character_value")
        include.add("ds_file_format_delimited_syntax_field_formats_date_format") if (
            (
                (self.ds_file_format == "comma-separated_value_csv")
                or (self.ds_file_format == "delimited")
                or (self.ds_file_format and "#" in str(self.ds_file_format))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_delimited_syntax_field_formats_date_format")
        include.add("time_format") if (
            (
                (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                            or (self.file_format == "avro")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                            or (self.file_format == "csv")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                            or (self.file_format == "delimited")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                            or (self.file_format == "parquet")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (
                                hasattr(self.file_format, "value")
                                and self.file_format.value
                                and "#" in str(self.file_format.value)
                            )
                            or ("#" in str(self.file_format))
                        )
                    )
                )
                and (
                    (not self.output_avro_as_json)
                    or (self.output_avro_as_json and "#" in str(self.output_avro_as_json))
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("time_format")
        include.add("fields_xml_path") if (
            (
                (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "xml")
                            or (self.file_format == "xml")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (
                                hasattr(self.file_format, "value")
                                and self.file_format.value
                                and "#" in str(self.file_format.value)
                            )
                            or ("#" in str(self.file_format))
                        )
                    )
                )
                and ((self.xml_path) or (self.xml_path and "#" in str(self.xml_path)))
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("fields_xml_path")
        include.add("ds_file_format_delimited_syntax_header") if (
            (
                (self.ds_file_format_delimited_syntax_record_def == "delimited_string")
                or (self.ds_file_format_delimited_syntax_record_def == "delimited_string_in_a_file")
                or (self.ds_file_format_delimited_syntax_record_def == "none")
                or (self.ds_file_format_delimited_syntax_record_def == "schema_file")
                or (
                    self.ds_file_format_delimited_syntax_record_def
                    and "#" in str(self.ds_file_format_delimited_syntax_record_def)
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_delimited_syntax_header")
        include.add("schema_of_xml") if (
            (
                (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "xml")
                            or (self.file_format == "xml")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (
                                hasattr(self.file_format, "value")
                                and self.file_format.value
                                and "#" in str(self.file_format.value)
                            )
                            or ("#" in str(self.file_format))
                        )
                    )
                )
                and ((self.infer_schema) or (self.infer_schema and "#" in str(self.infer_schema)))
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("schema_of_xml")
        include.add("encoding") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "shp")
                        or (self.file_format == "shp")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("encoding")
        include.add("field_delimiter") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("field_delimiter")
        include.add("use_variable_formats") if (
            (
                (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "sas")
                            or (self.file_format == "sas")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (
                                hasattr(self.file_format, "value")
                                and self.file_format.value
                                and "#" in str(self.file_format.value)
                            )
                            or ("#" in str(self.file_format))
                        )
                    )
                )
                and ((not self.infer_schema) or (self.infer_schema and "#" in str(self.infer_schema)))
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("use_variable_formats")
        include.add("timestamp_format") if (
            (
                (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                            or (self.file_format == "avro")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                            or (self.file_format == "csv")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                            or (self.file_format == "delimited")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                            or (self.file_format == "parquet")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (
                                hasattr(self.file_format, "value")
                                and self.file_format.value
                                and "#" in str(self.file_format.value)
                            )
                            or ("#" in str(self.file_format))
                        )
                    )
                )
                and (
                    (not self.output_avro_as_json)
                    or (self.output_avro_as_json and "#" in str(self.output_avro_as_json))
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("timestamp_format")
        include.add("infer_record_count") if (
            (
                (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                            or (self.file_format == "csv")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                            or (self.file_format == "delimited")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                            or (self.file_format == "excel")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "json")
                            or (self.file_format == "json")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (
                                hasattr(self.file_format, "value")
                                and self.file_format.value
                                and "#" in str(self.file_format.value)
                            )
                            or ("#" in str(self.file_format))
                        )
                    )
                )
                and ((self.infer_schema) or (self.infer_schema and "#" in str(self.infer_schema)))
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("infer_record_count")
        include.add("decimal_grouping_separator") if (
            (
                (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                            or (self.file_format == "avro")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                            or (self.file_format == "csv")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                            or (self.file_format == "delimited")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                            or (self.file_format == "parquet")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (
                                hasattr(self.file_format, "value")
                                and self.file_format.value
                                and "#" in str(self.file_format.value)
                            )
                            or ("#" in str(self.file_format))
                        )
                    )
                )
                and (
                    (not self.output_avro_as_json)
                    or (self.output_avro_as_json and "#" in str(self.output_avro_as_json))
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("decimal_grouping_separator")
        include.add("exclude_missing_values") if (
            (
                (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "sav")
                            or (self.file_format == "sav")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (
                                hasattr(self.file_format, "value")
                                and self.file_format.value
                                and "#" in str(self.file_format.value)
                            )
                            or ("#" in str(self.file_format))
                        )
                    )
                )
                and (
                    (not self.display_value_labels)
                    or (self.display_value_labels and "#" in str(self.display_value_labels))
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("exclude_missing_values")
        include.add("encryption_key") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "sav")
                        or (self.file_format == "sav")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("encryption_key")
        include.add("worksheet_name") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                        or (self.file_format == "excel")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("worksheet_name")
        include.add("ds_file_format_avro_source_output_json") if (
            ((self.ds_file_format == "avro") or (self.ds_file_format and "#" in str(self.ds_file_format)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_avro_source_output_json")
        include.add("table_format") if (
            (
                (
                    self.read_mode
                    and (
                        (hasattr(self.read_mode, "value") and self.read_mode.value == "read_single")
                        or (self.read_mode == "read_single")
                    )
                )
                or (
                    self.read_mode
                    and (
                        (hasattr(self.read_mode, "value") and self.read_mode.value and "#" in str(self.read_mode.value))
                        or ("#" in str(self.read_mode))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("table_format")
        include.add("infer_timestamp_as_date") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "sav")
                        or (self.file_format == "sav")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("infer_timestamp_as_date")
        include.add("first_line") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                        or (self.file_format == "excel")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("first_line")
        include.add("ds_file_format_impl_syntax_record_limit") if (
            ((self.ds_file_format == "implicit") or (self.ds_file_format and "#" in str(self.ds_file_format)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_impl_syntax_record_limit")
        include.add("endpoint_folder") if (
            (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value == "deltalake")
                        or (self.table_format == "deltalake")
                    )
                )
                or (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value == "iceberg")
                        or (self.table_format == "iceberg")
                    )
                )
                or (
                    self.table_format
                    and (
                        (
                            hasattr(self.table_format, "value")
                            and self.table_format.value
                            and "#" in str(self.table_format.value)
                        )
                        or ("#" in str(self.table_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("endpoint_folder")
        include.add("cell_range") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                        or (self.file_format == "excel")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("cell_range")
        include.add("ds_file_format_delimited_syntax_escape") if (
            ((self.ds_file_format == "delimited") or (self.ds_file_format and "#" in str(self.ds_file_format)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_delimited_syntax_escape")
        include.add("use_4_digit_years_in_date_formats") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                        or (self.file_format == "excel")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("use_4_digit_years_in_date_formats")
        include.add("json_infer_record_count") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "json")
                        or (self.file_format == "json")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("json_infer_record_count")
        include.add("ds_reject_mode") if (
            (
                (self.ds_file_format == "avro")
                or (self.ds_file_format == "comma-separated_value_csv")
                or (self.ds_file_format == "delimited")
                or (self.ds_file_format == "implicit")
                or (self.ds_file_format and "#" in str(self.ds_file_format))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_reject_mode")
        include.add("ds_file_format_delimited_syntax_null_value") if (
            (
                (self.ds_file_format == "comma-separated_value_csv")
                or (self.ds_file_format == "delimited")
                or (self.ds_file_format and "#" in str(self.ds_file_format))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_delimited_syntax_null_value")
        include.add("file_format") if (
            (
                (
                    (
                        self.read_mode
                        and (
                            (hasattr(self.read_mode, "value") and self.read_mode.value == "read_multiple_regex")
                            or (self.read_mode == "read_multiple_regex")
                        )
                    )
                    or (
                        self.read_mode
                        and (
                            (hasattr(self.read_mode, "value") and self.read_mode.value == "read_multiple_wildcard")
                            or (self.read_mode == "read_multiple_wildcard")
                        )
                    )
                    or (
                        self.read_mode
                        and (
                            (hasattr(self.read_mode, "value") and self.read_mode.value == "read_single")
                            or (self.read_mode == "read_single")
                        )
                    )
                    or (
                        self.read_mode
                        and (
                            (
                                hasattr(self.read_mode, "value")
                                and self.read_mode.value
                                and "#" in str(self.read_mode.value)
                            )
                            or ("#" in str(self.read_mode))
                        )
                    )
                )
                and (
                    (
                        (
                            self.table_format
                            and (
                                (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                                or (self.table_format != "deltalake")
                            )
                        )
                        or (
                            self.table_format
                            and (
                                (
                                    hasattr(self.table_format, "value")
                                    and self.table_format.value
                                    and "#" in str(self.table_format.value)
                                )
                                or ("#" in str(self.table_format))
                            )
                        )
                    )
                    and (
                        (
                            self.table_format
                            and (
                                (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                                or (self.table_format != "iceberg")
                            )
                        )
                        or (
                            self.table_format
                            and (
                                (
                                    hasattr(self.table_format, "value")
                                    and self.table_format.value
                                    and "#" in str(self.table_format.value)
                                )
                                or ("#" in str(self.table_format))
                            )
                        )
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("file_format")
        include.add("field_delimiter_value") if (
            (
                (
                    self.field_delimiter
                    and (
                        (hasattr(self.field_delimiter, "value") and self.field_delimiter.value == "<?>")
                        or (self.field_delimiter == "<?>")
                    )
                )
                or (
                    self.field_delimiter
                    and (
                        (
                            hasattr(self.field_delimiter, "value")
                            and self.field_delimiter.value
                            and "#" in str(self.field_delimiter.value)
                        )
                        or ("#" in str(self.field_delimiter))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("field_delimiter_value")
        include.add("ds_file_format_delimited_syntax_record_limit") if (
            (
                (self.ds_file_format == "comma-separated_value_csv")
                or (self.ds_file_format == "delimited")
                or (self.ds_file_format and "#" in str(self.ds_file_format))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_delimited_syntax_record_limit")
        include.add("row_delimiter") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("row_delimiter")
        include.add("ds_file_format_impl_syntax_binary") if (
            ((self.ds_file_format == "implicit") or (self.ds_file_format and "#" in str(self.ds_file_format)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_impl_syntax_binary")
        include.add("use_field_formats") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "sav")
                        or (self.file_format == "sav")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("use_field_formats")
        include.add("file_name") if (
            (
                (
                    (
                        self.table_format
                        and (
                            (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                            or (self.table_format != "deltalake")
                        )
                    )
                    or (
                        self.table_format
                        and (
                            (
                                hasattr(self.table_format, "value")
                                and self.table_format.value
                                and "#" in str(self.table_format.value)
                            )
                            or ("#" in str(self.table_format))
                        )
                    )
                )
                and (
                    (
                        self.table_format
                        and (
                            (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                            or (self.table_format != "iceberg")
                        )
                    )
                    or (
                        self.table_format
                        and (
                            (
                                hasattr(self.table_format, "value")
                                and self.table_format.value
                                and "#" in str(self.table_format.value)
                            )
                            or ("#" in str(self.table_format))
                        )
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("file_name")
        include.add("ds_file_format_delimited_syntax_field_delimiter") if (
            ((self.ds_file_format == "delimited") or (self.ds_file_format and "#" in str(self.ds_file_format)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_delimited_syntax_field_delimiter")
        include.add("ds_file_format_impl_syntax_header") if (
            (
                (self.ds_file_format_impl_syntax_record_def == "delimited_string")
                or (self.ds_file_format_impl_syntax_record_def == "delimited_string_in_a_file")
                or (self.ds_file_format_impl_syntax_record_def == "none")
                or (self.ds_file_format_impl_syntax_record_def == "schema_file")
                or (
                    self.ds_file_format_impl_syntax_record_def
                    and "#" in str(self.ds_file_format_impl_syntax_record_def)
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_impl_syntax_header")
        include.add("json_path") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "json")
                        or (self.file_format == "json")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("json_path")
        include.add("row_delimiter_value") if (
            (
                (
                    self.row_delimiter
                    and (
                        (hasattr(self.row_delimiter, "value") and self.row_delimiter.value == "<?>")
                        or (self.row_delimiter == "<?>")
                    )
                )
                or (
                    self.row_delimiter
                    and (
                        (
                            hasattr(self.row_delimiter, "value")
                            and self.row_delimiter.value
                            and "#" in str(self.row_delimiter.value)
                        )
                        or ("#" in str(self.row_delimiter))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("row_delimiter_value")
        include.add("ds_file_format_impl_syntax_encoding") if (
            ((self.ds_file_format == "implicit") or (self.ds_file_format and "#" in str(self.ds_file_format)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_impl_syntax_encoding")
        include.add("ds_file_format_delimited_syntax_field_formats_timestamp_format") if (
            (
                (self.ds_file_format == "comma-separated_value_csv")
                or (self.ds_file_format == "delimited")
                or (self.ds_file_format and "#" in str(self.ds_file_format))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_delimited_syntax_field_formats_timestamp_format")
        include.add("ds_file_format_delimited_syntax_quotes") if (
            ((self.ds_file_format == "delimited") or (self.ds_file_format and "#" in str(self.ds_file_format)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_delimited_syntax_quotes")
        include.add("ds_file_format_impl_syntax_record_def_record_def_source") if (
            (
                (self.ds_file_format_impl_syntax_record_def == "delimited_string")
                or (self.ds_file_format_impl_syntax_record_def == "delimited_string_in_a_file")
                or (self.ds_file_format_impl_syntax_record_def == "schema_file")
                or (
                    self.ds_file_format_impl_syntax_record_def
                    and "#" in str(self.ds_file_format_impl_syntax_record_def)
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_impl_syntax_record_def_record_def_source")
        include.add("decimal_format") if (
            (
                (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                            or (self.file_format == "avro")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                            or (self.file_format == "csv")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                            or (self.file_format == "delimited")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                            or (self.file_format == "parquet")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (
                                hasattr(self.file_format, "value")
                                and self.file_format.value
                                and "#" in str(self.file_format.value)
                            )
                            or ("#" in str(self.file_format))
                        )
                    )
                )
                and (
                    (not self.output_avro_as_json)
                    or (self.output_avro_as_json and "#" in str(self.output_avro_as_json))
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("decimal_format")
        include.add("decimal_rounding_mode") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("decimal_rounding_mode")
        include.add("labels_as_names") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "sav")
                        or (self.file_format == "sav")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("labels_as_names")
        include.add("ds_file_format_delimited_syntax_encoding") if (
            (
                (self.ds_file_format == "comma-separated_value_csv")
                or (self.ds_file_format == "delimited")
                or (self.ds_file_format and "#" in str(self.ds_file_format))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_delimited_syntax_encoding")
        include.add("date_format") if (
            (
                (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                            or (self.file_format == "avro")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                            or (self.file_format == "csv")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                            or (self.file_format == "delimited")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                            or (self.file_format == "parquet")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (
                                hasattr(self.file_format, "value")
                                and self.file_format.value
                                and "#" in str(self.file_format.value)
                            )
                            or ("#" in str(self.file_format))
                        )
                    )
                )
                and (
                    (not self.output_avro_as_json)
                    or (self.output_avro_as_json and "#" in str(self.output_avro_as_json))
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("date_format")
        include.add("type_mapping") if (
            (
                (
                    (
                        (
                            self.file_format
                            and (
                                (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                                or (self.file_format == "csv")
                            )
                        )
                        or (
                            self.file_format
                            and (
                                (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                                or (self.file_format == "delimited")
                            )
                        )
                        or (
                            self.file_format
                            and (
                                (
                                    hasattr(self.file_format, "value")
                                    and self.file_format.value
                                    and "#" in str(self.file_format.value)
                                )
                                or ("#" in str(self.file_format))
                            )
                        )
                    )
                    or (self.infer_schema)
                    or (self.infer_schema and "#" in str(self.infer_schema))
                )
                and ((self.infer_schema) or (self.infer_schema and "#" in str(self.infer_schema)))
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("type_mapping")

        include.add("infer_as_varchar") if (()) else exclude.add("infer_as_varchar")
        include.add("infer_schema") if (()) else exclude.add("infer_schema")
        include.add("ds_java_heap_size") if (not self.ds_use_datastage) else exclude.add("ds_java_heap_size")
        include.add("partition_name_prefix") if (not self.ds_use_datastage) else exclude.add("partition_name_prefix")
        include.add("ds_file_format_trace_file") if (self.ds_use_datastage) else exclude.add(
            "ds_file_format_trace_file"
        )
        include.add("read_mode") if (not self.ds_use_datastage) else exclude.add("read_mode")
        include.add("ds_user_class_name") if (self.ds_use_datastage) else exclude.add("ds_user_class_name")
        include.add("ds_read_mode") if (self.ds_use_datastage) else exclude.add("ds_read_mode")
        include.add("node_number") if (not self.ds_use_datastage) else exclude.add("node_number")
        include.add("byte_limit") if (not self.ds_use_datastage) else exclude.add("byte_limit")
        include.add("default_maximum_length_for_columns") if (not self.ds_use_datastage) else exclude.add(
            "default_maximum_length_for_columns"
        )
        include.add("generate_unicode_type_columns") if (not self.ds_use_datastage) else exclude.add(
            "generate_unicode_type_columns"
        )
        include.add("node_count") if (not self.ds_use_datastage) else exclude.add("node_count")
        include.add("ds_filename_source") if (self.ds_use_datastage) else exclude.add("ds_filename_source")
        include.add("ds_file_format") if (self.ds_use_datastage) else exclude.add("ds_file_format")
        include.add("ds_filename_column") if (self.ds_use_datastage) else exclude.add("ds_filename_column")
        include.add("row_limit") if (not self.ds_use_datastage) else exclude.add("row_limit")
        include.add("ds_exclude_files") if (self.ds_use_datastage) else exclude.add("ds_exclude_files")
        include.add("timezone_format") if (not self.ds_use_datastage) else exclude.add("timezone_format")
        include.add("maximum_memory_buffer_size_bytes") if (self.buffering_mode != "nobuffer") else exclude.add(
            "maximum_memory_buffer_size_bytes"
        )
        include.add("buffer_free_run_percent") if (self.buffering_mode != "nobuffer") else exclude.add(
            "buffer_free_run_percent"
        )
        include.add("queue_upper_bound_size_bytes") if (self.buffering_mode != "nobuffer") else exclude.add(
            "queue_upper_bound_size_bytes"
        )
        include.add("disk_write_increment_bytes") if (self.buffering_mode != "nobuffer") else exclude.add(
            "disk_write_increment_bytes"
        )
        include.add("runtime_column_propagation") if (not self.enable_schemaless_design) else exclude.add(
            "runtime_column_propagation"
        )
        include.add("column_metadata_change_propagation") if (not self.output_acp_should_hide) else exclude.add(
            "column_metadata_change_propagation"
        )
        include.add("max_mem_buf_size_ronly") if (self.buf_mode_ronly != "nobuffer") else exclude.add(
            "max_mem_buf_size_ronly"
        )
        include.add("buf_free_run_ronly") if (self.buf_mode_ronly != "nobuffer") else exclude.add("buf_free_run_ronly")
        include.add("queue_upper_size_ronly") if (self.buf_mode_ronly != "nobuffer") else exclude.add(
            "queue_upper_size_ronly"
        )
        include.add("disk_write_inc_ronly") if (self.buf_mode_ronly != "nobuffer") else exclude.add(
            "disk_write_inc_ronly"
        )
        include.add("stable") if (
            (self.show_part_type)
            and (self.partition_type != "auto")
            and (self.partition_type != "db2connector")
            and (self.show_sort_options)
        ) else exclude.add("stable")
        include.add("unique") if (
            (self.show_part_type)
            and (self.partition_type != "auto")
            and (self.partition_type != "db2connector")
            and (self.show_sort_options)
        ) else exclude.add("unique")
        include.add("key_cols_part") if (
            (
                (self.show_part_type)
                and (not self.show_coll_type)
                and (self.partition_type != "auto")
                and (self.partition_type != "db2connector")
                and (self.partition_type != "modulus")
            )
            or (
                (self.show_part_type)
                and (not self.show_coll_type)
                and (self.partition_type == "modulus")
                and (self.perform_sort_modulus)
            )
        ) else exclude.add("key_cols_part")
        include.add("db2_source_connection_required") if (
            (self.partition_type == "db2part") and (self.show_part_type)
        ) else exclude.add("db2_source_connection_required")
        include.add("db2_database_name") if (
            (self.partition_type == "db2part") and (self.show_part_type)
        ) else exclude.add("db2_database_name")
        include.add("db2_instance_name") if (
            (self.partition_type == "db2part") and (self.show_part_type)
        ) else exclude.add("db2_instance_name")
        include.add("db2_table_name") if (
            (self.partition_type == "db2part") and (self.show_part_type)
        ) else exclude.add("db2_table_name")
        include.add("perform_sort") if (
            (self.show_part_type) and ((self.partition_type == "hash") or (self.partition_type == "range"))
        ) else exclude.add("perform_sort")
        include.add("perform_sort_modulus") if (
            (self.show_part_type) and (self.partition_type == "modulus")
        ) else exclude.add("perform_sort_modulus")
        include.add("sorting_key") if (
            (self.show_part_type) and (self.partition_type == "modulus") and (not self.perform_sort_modulus)
        ) else exclude.add("sorting_key")
        include.add("sort_instructions") if (
            (self.show_part_type)
            and (
                (self.partition_type == "db2part")
                or (self.partition_type == "entire")
                or (self.partition_type == "random")
                or (self.partition_type == "roundrobin")
                or (self.partition_type == "same")
            )
        ) else exclude.add("sort_instructions")
        include.add("sort_instructions_text") if (
            (self.show_part_type)
            and (
                (self.partition_type == "db2part")
                or (self.partition_type == "entire")
                or (self.partition_type == "random")
                or (self.partition_type == "roundrobin")
                or (self.partition_type == "same")
            )
        ) else exclude.add("sort_instructions_text")
        include.add("collecting") if (self.show_coll_type) else exclude.add("collecting")
        include.add("partition_type") if (self.show_part_type) else exclude.add("partition_type")
        include.add("perform_sort_coll") if (
            (
                (self.show_coll_type)
                and (
                    (self.collecting == "ordered")
                    or (self.collecting == "roundrobin_coll")
                    or (self.collecting == "sortmerge")
                )
            )
            or ((not self.show_part_type) and (not self.show_coll_type))
        ) else exclude.add("perform_sort_coll")
        include.add("key_cols_coll") if (
            (self.show_coll_type)
            and (not self.show_part_type)
            and (self.collecting != "auto")
            and ((self.collecting == "sortmerge") or (self.perform_sort_coll))
        ) else exclude.add("key_cols_coll")
        include.add("key_cols_none") if (
            (not self.show_part_type) and (not self.show_coll_type) and (self.perform_sort_coll)
        ) else exclude.add("key_cols_none")
        include.add("part_stable_coll") if (
            (self.perform_sort_coll)
            and (
                (
                    (not self.show_part_type)
                    and (self.show_coll_type)
                    and (self.collecting != "auto")
                    and (self.show_sort_options)
                )
                or ((not self.show_part_type) and (not self.show_coll_type) and (self.show_sort_options))
            )
        ) else exclude.add("part_stable_coll")
        include.add("part_unique_coll") if (
            (self.perform_sort_coll)
            and (
                (
                    (not self.show_part_type)
                    and (self.show_coll_type)
                    and (self.collecting != "auto")
                    and (self.show_sort_options)
                )
                or ((not self.show_part_type) and (not self.show_coll_type) and (self.show_sort_options))
            )
        ) else exclude.add("part_unique_coll")
        include.add("defer_credentials") if (()) else exclude.add("defer_credentials")
        include.add("ds_file_format_impl_syntax_header") if (
            self.ds_file_format_impl_syntax_record_def
            and "delimited_string" in str(self.ds_file_format_impl_syntax_record_def)
            or self.ds_file_format_impl_syntax_record_def
            and "delimited_string_in_a_file" in str(self.ds_file_format_impl_syntax_record_def)
            or self.ds_file_format_impl_syntax_record_def
            and "none" in str(self.ds_file_format_impl_syntax_record_def)
            or self.ds_file_format_impl_syntax_record_def
            and "schema_file" in str(self.ds_file_format_impl_syntax_record_def)
        ) else exclude.add("ds_file_format_impl_syntax_header")
        include.add("time_format") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "avro" in str(self.file_format.value)
                )
                or ("avro" in str(self.file_format))
            )
            and self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "parquet" in str(self.file_format.value)
                )
                or ("parquet" in str(self.file_format))
            )
        ) and (not self.output_avro_as_json) else exclude.add("time_format")
        include.add("ds_file_format_delimited_syntax_field_delimiter") if (
            self.ds_file_format == "delimited"
        ) else exclude.add("ds_file_format_delimited_syntax_field_delimiter")
        include.add("endpoint_folder") if (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "deltalake" in str(self.table_format.value)
                )
                or ("deltalake" in str(self.table_format))
            )
            or self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" in str(self.table_format.value)
                )
                or ("iceberg" in str(self.table_format))
            )
        ) else exclude.add("endpoint_folder")
        include.add("first_line_is_header") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "excel" in str(self.file_format.value)
                )
                or ("excel" in str(self.file_format))
            )
        ) else exclude.add("first_line_is_header")
        include.add("json_path") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "json")
                or (self.file_format == "json")
            )
        ) else exclude.add("json_path")
        include.add("first_line") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "excel" in str(self.file_format.value)
                )
                or ("excel" in str(self.file_format))
            )
        ) else exclude.add("first_line")
        include.add("file_name") if (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "deltalake" not in str(self.table_format.value)
                )
                or ("deltalake" not in str(self.table_format))
            )
            or self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" not in str(self.table_format.value)
                )
                or ("iceberg" not in str(self.table_format))
            )
        ) else exclude.add("file_name")
        include.add("row_delimiter_value") if (
            self.row_delimiter
            and (
                (
                    hasattr(self.row_delimiter, "value")
                    and self.row_delimiter.value
                    and "<?>" in str(self.row_delimiter.value)
                )
                or ("<?>" in str(self.row_delimiter))
            )
        ) else exclude.add("row_delimiter_value")
        include.add("ds_file_format_delimited_syntax_encoding") if (
            self.ds_file_format
            and "comma-separated_value_csv" in str(self.ds_file_format)
            or self.ds_file_format
            and "delimited" in str(self.ds_file_format)
        ) else exclude.add("ds_file_format_delimited_syntax_encoding")
        include.add("escape_character_value") if (
            self.escape_character
            and (
                (
                    hasattr(self.escape_character, "value")
                    and self.escape_character.value
                    and "<?>" in str(self.escape_character.value)
                )
                or ("<?>" in str(self.escape_character))
            )
        ) else exclude.add("escape_character_value")
        include.add("ds_file_format_avro_source_output_json") if (self.ds_file_format == "avro") else exclude.add(
            "ds_file_format_avro_source_output_json"
        )
        include.add("ds_file_format_delimited_syntax_escape") if (self.ds_file_format == "delimited") else exclude.add(
            "ds_file_format_delimited_syntax_escape"
        )
        include.add("ds_file_format_impl_syntax_binary") if (self.ds_file_format == "implicit") else exclude.add(
            "ds_file_format_impl_syntax_binary"
        )
        include.add("date_format") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "avro" in str(self.file_format.value)
                )
                or ("avro" in str(self.file_format))
            )
            and self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "parquet" in str(self.file_format.value)
                )
                or ("parquet" in str(self.file_format))
            )
        ) and (not self.output_avro_as_json) else exclude.add("date_format")
        include.add("xml_path") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "xml") or (self.file_format == "xml")
            )
        ) else exclude.add("xml_path")
        include.add("fields_xml_path") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "xml") or (self.file_format == "xml")
            )
        ) and (self.xml_path) else exclude.add("fields_xml_path")
        include.add("labels_as_names") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "sav") or (self.file_format == "sav")
            )
        ) else exclude.add("labels_as_names")
        include.add("ds_file_format_delimited_syntax_record_def") if (
            self.ds_file_format
            and "comma-separated_value_csv" in str(self.ds_file_format)
            or self.ds_file_format
            and "delimited" in str(self.ds_file_format)
        ) else exclude.add("ds_file_format_delimited_syntax_record_def")
        include.add("null_value") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
        ) else exclude.add("null_value")
        include.add("timestamp_format") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "avro" in str(self.file_format.value)
                )
                or ("avro" in str(self.file_format))
            )
            and self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "parquet" in str(self.file_format.value)
                )
                or ("parquet" in str(self.file_format))
            )
        ) and (not self.output_avro_as_json) else exclude.add("timestamp_format")
        include.add("ds_file_format_delimited_syntax_field_formats_decimal_format") if (
            self.ds_file_format
            and "comma-separated_value_csv" in str(self.ds_file_format)
            or self.ds_file_format
            and "delimited" in str(self.ds_file_format)
        ) else exclude.add("ds_file_format_delimited_syntax_field_formats_decimal_format")
        include.add("ds_file_format_delimited_syntax_quotes") if (self.ds_file_format == "delimited") else exclude.add(
            "ds_file_format_delimited_syntax_quotes"
        )
        include.add("worksheet_name") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                or (self.file_format == "excel")
            )
        ) else exclude.add("worksheet_name")
        include.add("infer_record_count") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "excel" in str(self.file_format.value)
                )
                or ("excel" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "json" in str(self.file_format.value)
                )
                or ("json" in str(self.file_format))
            )
        ) and (self.infer_schema == "true" or self.infer_schema is True) else exclude.add("infer_record_count")
        include.add("ds_file_format_impl_syntax_record_limit") if (self.ds_file_format == "implicit") else exclude.add(
            "ds_file_format_impl_syntax_record_limit"
        )
        include.add("ds_reject_mode") if (
            self.ds_file_format
            and "avro" in str(self.ds_file_format)
            or self.ds_file_format
            and "comma-separated_value_csv" in str(self.ds_file_format)
            or self.ds_file_format
            and "delimited" in str(self.ds_file_format)
            or self.ds_file_format
            and "implicit" in str(self.ds_file_format)
        ) else exclude.add("ds_reject_mode")
        include.add("encoding") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            or self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "shp" in str(self.file_format.value))
                or ("shp" in str(self.file_format))
            )
        ) else exclude.add("encoding")
        include.add("infer_as_varchar") if (
            (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "csv" in str(self.file_format.value)
                    )
                    or ("csv" in str(self.file_format))
                )
                or self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "delimited" in str(self.file_format.value)
                    )
                    or ("delimited" in str(self.file_format))
                )
            )
            or (self.infer_schema == "true" or self.infer_schema is True)
            or (self.type_mapping == "false" or self.type_mapping is False)
        ) and (self.infer_schema == "true" or self.infer_schema is True) else exclude.add("infer_as_varchar")
        include.add("ds_file_format_delimited_syntax_row_delimiter") if (
            self.ds_file_format == "delimited"
        ) else exclude.add("ds_file_format_delimited_syntax_row_delimiter")
        include.add("ds_file_format_delimited_syntax_record_def_record_def_source") if (
            self.ds_file_format_delimited_syntax_record_def
            and "delimited_string" in str(self.ds_file_format_delimited_syntax_record_def)
            or self.ds_file_format_delimited_syntax_record_def
            and "delimited_string_in_a_file" in str(self.ds_file_format_delimited_syntax_record_def)
            or self.ds_file_format_delimited_syntax_record_def
            and "schema_file" in str(self.ds_file_format_delimited_syntax_record_def)
        ) else exclude.add("ds_file_format_delimited_syntax_record_def_record_def_source")
        include.add("invalid_data_handling") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
        ) else exclude.add("invalid_data_handling")
        include.add("infer_timestamp_as_date") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "sav") or (self.file_format == "sav")
            )
        ) else exclude.add("infer_timestamp_as_date")
        include.add("schema_of_xml") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "xml") or (self.file_format == "xml")
            )
        ) and (self.infer_schema == "true" or self.infer_schema is True) else exclude.add("schema_of_xml")
        include.add("ds_file_format_delimited_syntax_field_formats_timestamp_format") if (
            self.ds_file_format
            and "comma-separated_value_csv" in str(self.ds_file_format)
            or self.ds_file_format
            and "delimited" in str(self.ds_file_format)
        ) else exclude.add("ds_file_format_delimited_syntax_field_formats_timestamp_format")
        include.add("cell_range") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                or (self.file_format == "excel")
            )
        ) else exclude.add("cell_range")
        include.add("table_name") if (self.endpoint_folder) else exclude.add("table_name")
        include.add("ds_file_format_delimited_syntax_record_limit") if (
            self.ds_file_format
            and "comma-separated_value_csv" in str(self.ds_file_format)
            or self.ds_file_format
            and "delimited" in str(self.ds_file_format)
        ) else exclude.add("ds_file_format_delimited_syntax_record_limit")
        include.add("use_field_formats") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "sav") or (self.file_format == "sav")
            )
        ) else exclude.add("use_field_formats")
        include.add("field_delimiter") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
        ) else exclude.add("field_delimiter")
        include.add("decimal_rounding_mode") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
        ) else exclude.add("decimal_rounding_mode")
        include.add("ds_file_format") if (self.ds_read_mode == "read_multiple_files") else exclude.add("ds_file_format")
        include.add("ds_file_format_impl_syntax_record_def") if (self.ds_file_format == "implicit") else exclude.add(
            "ds_file_format_impl_syntax_record_def"
        )
        include.add("field_delimiter_value") if (
            self.field_delimiter
            and (
                (
                    hasattr(self.field_delimiter, "value")
                    and self.field_delimiter.value
                    and "<?>" in str(self.field_delimiter.value)
                )
                or ("<?>" in str(self.field_delimiter))
            )
        ) else exclude.add("field_delimiter_value")
        include.add("row_delimiter") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
        ) else exclude.add("row_delimiter")
        include.add("quote_character") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
        ) else exclude.add("quote_character")
        include.add("type_mapping") if (
            (
                self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "csv" in str(self.file_format.value)
                    )
                    or ("csv" in str(self.file_format))
                )
                or self.file_format
                and (
                    (
                        hasattr(self.file_format, "value")
                        and self.file_format.value
                        and "delimited" in str(self.file_format.value)
                    )
                    or ("delimited" in str(self.file_format))
                )
            )
            or (self.infer_schema == "true" or self.infer_schema is True)
        ) and (self.infer_schema == "true" or self.infer_schema is True) else exclude.add("type_mapping")
        include.add("decimal_format") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "avro" in str(self.file_format.value)
                )
                or ("avro" in str(self.file_format))
            )
            and self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "parquet" in str(self.file_format.value)
                )
                or ("parquet" in str(self.file_format))
            )
        ) and (not self.output_avro_as_json) else exclude.add("decimal_format")
        include.add("decimal_grouping_separator") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "avro" in str(self.file_format.value)
                )
                or ("avro" in str(self.file_format))
            )
            and self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "parquet" in str(self.file_format.value)
                )
                or ("parquet" in str(self.file_format))
            )
        ) and (not self.output_avro_as_json) else exclude.add("decimal_grouping_separator")
        include.add("ds_file_format_impl_syntax_encoding") if (self.ds_file_format == "implicit") else exclude.add(
            "ds_file_format_impl_syntax_encoding"
        )
        include.add("ds_file_format_impl_syntax_record_def_record_def_source") if (
            self.ds_file_format_impl_syntax_record_def
            and "delimited_string" in str(self.ds_file_format_impl_syntax_record_def)
            or self.ds_file_format_impl_syntax_record_def
            and "delimited_string_in_a_file" in str(self.ds_file_format_impl_syntax_record_def)
            or self.ds_file_format_impl_syntax_record_def
            and "schema_file" in str(self.ds_file_format_impl_syntax_record_def)
        ) else exclude.add("ds_file_format_impl_syntax_record_def_record_def_source")
        include.add("store_shared_strings_in_the_temporary_file") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "excel" in str(self.file_format.value)
                )
                or ("excel" in str(self.file_format))
            )
        ) else exclude.add("store_shared_strings_in_the_temporary_file")
        include.add("escape_character") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
        ) else exclude.add("escape_character")
        include.add("ds_file_format_delimited_syntax_header") if (
            self.ds_file_format_delimited_syntax_record_def
            and "delimited_string" in str(self.ds_file_format_delimited_syntax_record_def)
            or self.ds_file_format_delimited_syntax_record_def
            and "delimited_string_in_a_file" in str(self.ds_file_format_delimited_syntax_record_def)
            or self.ds_file_format_delimited_syntax_record_def
            and "none" in str(self.ds_file_format_delimited_syntax_record_def)
            or self.ds_file_format_delimited_syntax_record_def
            and "schema_file" in str(self.ds_file_format_delimited_syntax_record_def)
        ) else exclude.add("ds_file_format_delimited_syntax_header")
        include.add("decimal_separator") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "avro" in str(self.file_format.value)
                )
                or ("avro" in str(self.file_format))
            )
            and self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "parquet" in str(self.file_format.value)
                )
                or ("parquet" in str(self.file_format))
            )
        ) and (not self.output_avro_as_json) else exclude.add("decimal_separator")
        include.add("encryption_key") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "sav") or (self.file_format == "sav")
            )
        ) else exclude.add("encryption_key")
        include.add("file_format") if (
            self.read_mode
            and (
                (
                    hasattr(self.read_mode, "value")
                    and self.read_mode.value
                    and "read_multiple_regex" in str(self.read_mode.value)
                )
                or ("read_multiple_regex" in str(self.read_mode))
            )
            or self.read_mode
            and (
                (
                    hasattr(self.read_mode, "value")
                    and self.read_mode.value
                    and "read_multiple_wildcard" in str(self.read_mode.value)
                )
                or ("read_multiple_wildcard" in str(self.read_mode))
            )
            or self.read_mode
            and (
                (
                    hasattr(self.read_mode, "value")
                    and self.read_mode.value
                    and "read_single" in str(self.read_mode.value)
                )
                or ("read_single" in str(self.read_mode))
            )
        ) and (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "deltalake" not in str(self.table_format.value)
                )
                or ("deltalake" not in str(self.table_format))
            )
            or self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" not in str(self.table_format.value)
                )
                or ("iceberg" not in str(self.table_format))
            )
        ) else exclude.add("file_format")
        include.add("ds_file_format_delimited_syntax_field_formats_time_format") if (
            self.ds_file_format
            and "comma-separated_value_csv" in str(self.ds_file_format)
            or self.ds_file_format
            and "delimited" in str(self.ds_file_format)
        ) else exclude.add("ds_file_format_delimited_syntax_field_formats_time_format")
        include.add("table_format") if (
            self.read_mode
            and (
                (hasattr(self.read_mode, "value") and self.read_mode.value == "read_single")
                or (self.read_mode == "read_single")
            )
        ) else exclude.add("table_format")
        include.add("exclude_missing_values") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "sav") or (self.file_format == "sav")
            )
        ) and (self.display_value_labels != "true" or self.display_value_labels is not True) else exclude.add(
            "exclude_missing_values"
        )
        include.add("json_infer_record_count") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "json")
                or (self.file_format == "json")
            )
        ) else exclude.add("json_infer_record_count")
        include.add("output_avro_as_json") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                or (self.file_format == "avro")
            )
        ) else exclude.add("output_avro_as_json")
        include.add("ds_file_format_delimited_syntax_null_value") if (
            self.ds_file_format
            and "comma-separated_value_csv" in str(self.ds_file_format)
            or self.ds_file_format
            and "delimited" in str(self.ds_file_format)
        ) else exclude.add("ds_file_format_delimited_syntax_null_value")
        include.add("use_variable_formats") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "sas") or (self.file_format == "sas")
            )
        ) and (self.infer_schema != "true" or self.infer_schema is not True) else exclude.add("use_variable_formats")
        include.add("display_value_labels") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "sav") or (self.file_format == "sav")
            )
        ) and (self.exclude_missing_values != "true" or self.exclude_missing_values is not True) else exclude.add(
            "display_value_labels"
        )
        include.add("table_namespace") if (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" in str(self.table_format.value)
                )
                or ("iceberg" in str(self.table_format))
            )
        ) and (self.endpoint_folder) else exclude.add("table_namespace")
        include.add("ds_file_format_delimited_syntax_field_formats_date_format") if (
            self.ds_file_format
            and "comma-separated_value_csv" in str(self.ds_file_format)
            or self.ds_file_format
            and "delimited" in str(self.ds_file_format)
        ) else exclude.add("ds_file_format_delimited_syntax_field_formats_date_format")
        include.add("use_4_digit_years_in_date_formats") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "excel" in str(self.file_format.value)
                )
                or ("excel" in str(self.file_format))
            )
        ) else exclude.add("use_4_digit_years_in_date_formats")
        include.add("infer_null_as_empty_string") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "excel" in str(self.file_format.value)
                )
                or ("excel" in str(self.file_format))
            )
        ) else exclude.add("infer_null_as_empty_string")
        return include, exclude

    def _validate_target(self) -> tuple[set, set]:
        include = set()
        exclude = set()

        include.add("ds_split_on_key") if (
            (not self.ds_wave_handling_append_uid) and (self.ds_write_mode == "write_multiple_files")
        ) else exclude.add("ds_split_on_key")
        include.add("ds_create_hive_table_hive_keytab") if (self.ds_create_hive_table_hive_use_keytab) else exclude.add(
            "ds_create_hive_table_hive_keytab"
        )
        include.add("ds_create_hive_table") if (
            (
                ((self.ds_write_mode == "write_multiple_files") or (self.ds_write_mode == "write_single_file"))
                and (self.ds_file_format == "delimited")
                and (self.ds_file_format_delimited_syntax_quotes == "none")
            )
            or (
                ((self.ds_write_mode == "write_multiple_files") or (self.ds_write_mode == "write_single_file"))
                and (
                    (self.ds_file_format == "avro")
                    or (self.ds_file_format == "orc")
                    or (self.ds_file_format == "parquet")
                )
            )
        ) else exclude.add("ds_create_hive_table")
        include.add("ds_file_format_parquet_target_parquet_compress") if (
            self.ds_file_format == "parquet"
        ) else exclude.add("ds_file_format_parquet_target_parquet_compress")
        include.add("ds_create_hive_table_hive_table_type") if (
            (self.ds_create_hive_table) and (self.ds_file_format == "parquet")
        ) else exclude.add("ds_create_hive_table_hive_table_type")
        include.add("ds_split_on_key_key_in_filename") if (self.ds_split_on_key) else exclude.add(
            "ds_split_on_key_key_in_filename"
        )
        include.add("ds_file_format_orc_target_orc_stripe_size") if (self.ds_file_format == "orc") else exclude.add(
            "ds_file_format_orc_target_orc_stripe_size"
        )
        include.add("ds_create_hive_table_hive_kerberos") if (self.ds_create_hive_table) else exclude.add(
            "ds_create_hive_table_hive_kerberos"
        )
        include.add("ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_type") if (
            self.ds_create_hive_table_use_staging_table
        ) else exclude.add("ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_type")
        include.add("ds_file_format_impl_syntax_encoding_output_bom") if (
            self.ds_file_format == "implicit"
        ) else exclude.add("ds_file_format_impl_syntax_encoding_output_bom")
        include.add("ds_file_format_avro_target_avro_schema") if (self.ds_file_format == "avro") else exclude.add(
            "ds_file_format_avro_target_avro_schema"
        )
        include.add("ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_orc_stripe_size") if (
            self.ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_format == "orc"
        ) else exclude.add("ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_orc_stripe_size")
        include.add("ds_file_format_delimited_syntax_header_include_types") if (
            self.ds_file_format_delimited_syntax_header
        ) else exclude.add("ds_file_format_delimited_syntax_header_include_types")
        include.add("ds_file_format_impl_syntax_header_include_types") if (
            self.ds_file_format_impl_syntax_header
        ) else exclude.add("ds_file_format_impl_syntax_header_include_types")
        include.add("ds_split_on_key_exclude_part_string") if (
            (self.ds_split_on_key) and (self.ds_split_on_key_key_in_filename)
        ) else exclude.add("ds_split_on_key_exclude_part_string")
        include.add("ds_file_format_impl_syntax_header") if (self.ds_file_format == "implicit") else exclude.add(
            "ds_file_format_impl_syntax_header"
        )
        include.add("ds_wave_handling_file_size_threshold") if (self.ds_wave_handling_append_uid) else exclude.add(
            "ds_wave_handling_file_size_threshold"
        )
        include.add("ds_create_hive_table_use_staging_table_load_existing_table_max_dynamic_partitions") if (
            self.ds_create_hive_table_use_staging_table
        ) else exclude.add("ds_create_hive_table_use_staging_table_load_existing_table_max_dynamic_partitions")
        include.add("ds_create_hive_table_hive_use_keytab") if (
            self.ds_create_hive_table_hive_kerberos
        ) else exclude.add("ds_create_hive_table_hive_use_keytab")
        include.add("ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_format") if (
            self.ds_create_hive_table_use_staging_table
        ) else exclude.add(
            "ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_format"
        )
        include.add("ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_orc_compress") if (
            self.ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_format == "orc"
        ) else exclude.add("ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_orc_compress")
        include.add("ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_parquet_compress") if (
            self.ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_format
            == "parquet"
        ) else exclude.add("ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_parquet_compress")
        include.add("ds_file_format_delimited_syntax_header") if (
            (self.ds_file_format == "comma-separated_value_csv") or (self.ds_file_format == "delimited")
        ) else exclude.add("ds_file_format_delimited_syntax_header")
        include.add("ds_max_file_size") if (
            (not self.ds_wave_handling_append_uid) and (self.ds_write_mode == "write_multiple_files")
        ) else exclude.add("ds_max_file_size")
        include.add("ds_file_format_delimited_syntax_encoding_output_bom") if (
            (self.ds_file_format == "comma-separated_value_csv") or (self.ds_file_format == "delimited")
        ) else exclude.add("ds_file_format_delimited_syntax_encoding_output_bom")
        include.add("ds_create_hive_table_create_hive_schema") if (self.ds_create_hive_table) else exclude.add(
            "ds_create_hive_table_create_hive_schema"
        )
        include.add("ds_file_exists") if (
            (not self.ds_wave_handling_append_uid)
            and ((self.ds_write_mode == "write_multiple_files") or (self.ds_write_mode == "write_single_file"))
        ) else exclude.add("ds_file_exists")
        include.add("ds_wave_handling_append_uid") if (
            (self.ds_write_mode == "write_multiple_files") or (self.ds_write_mode == "write_single_file")
        ) else exclude.add("ds_wave_handling_append_uid")
        include.add("ds_file_format_avro_target_avro_codec") if (self.ds_file_format == "avro") else exclude.add(
            "ds_file_format_avro_target_avro_codec"
        )
        include.add("ds_split_on_key_key_column") if (self.ds_split_on_key) else exclude.add(
            "ds_split_on_key_key_column"
        )
        include.add("ds_file_format_parquet_target_parquet_block_size") if (
            self.ds_file_format == "parquet"
        ) else exclude.add("ds_file_format_parquet_target_parquet_block_size")
        include.add("ds_cleanup") if (
            (self.ds_write_mode == "write_multiple_files") or (self.ds_write_mode == "write_single_file")
        ) else exclude.add("ds_cleanup")
        include.add("ds_file_format_avro_target_avro_array_keys") if (self.ds_file_format == "avro") else exclude.add(
            "ds_file_format_avro_target_avro_array_keys"
        )
        include.add("ds_create_hive_table_hive_table") if (self.ds_create_hive_table) else exclude.add(
            "ds_create_hive_table_hive_table"
        )
        include.add("ds_file_format_orc_target_orc_buffer_size") if (self.ds_file_format == "orc") else exclude.add(
            "ds_file_format_orc_target_orc_buffer_size"
        )
        include.add("ds_create_hive_table_hive_service_principal") if (
            self.ds_create_hive_table_hive_kerberos
        ) else exclude.add("ds_create_hive_table_hive_service_principal")
        include.add("ds_file_format_avro_target_input_json") if (self.ds_file_format == "avro") else exclude.add(
            "ds_file_format_avro_target_input_json"
        )
        include.add("ds_force_sequential") if (
            (not self.ds_wave_handling_append_uid) and (self.ds_write_mode == "write_multiple_files")
        ) else exclude.add("ds_force_sequential")
        include.add("ds_file_format_orc_target_orc_compress") if (self.ds_file_format == "orc") else exclude.add(
            "ds_file_format_orc_target_orc_compress"
        )
        include.add("ds_split_on_key_case_sensitive") if (self.ds_split_on_key) else exclude.add(
            "ds_split_on_key_case_sensitive"
        )
        include.add(
            "ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_location"
        ) if (self.ds_create_hive_table_use_staging_table) else exclude.add(
            "ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_location"
        )
        include.add("ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_drop_staging_table") if (
            self.ds_create_hive_table_use_staging_table
        ) else exclude.add(
            "ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_drop_staging_table"
        )
        include.add("ds_file_format_parquet_target_parquet_page_size") if (
            self.ds_file_format == "parquet"
        ) else exclude.add("ds_file_format_parquet_target_parquet_page_size")
        include.add("ds_create_hive_table_use_staging_table") if (
            (self.ds_create_hive_table) and (self.ds_file_format == "delimited")
        ) else exclude.add("ds_create_hive_table_use_staging_table")
        include.add("ds_file_format") if (
            (self.ds_write_mode == "write_multiple_files") or (self.ds_write_mode == "write_single_file")
        ) else exclude.add("ds_file_format")
        include.add("ds_create_hive_table_additional_driver_params") if (self.ds_create_hive_table) else exclude.add(
            "ds_create_hive_table_additional_driver_params"
        )
        include.add("ds_create_hive_table_drop_hive_table") if (
            (not self.ds_create_hive_table_use_staging_table)
            or (
                (
                    (self.ds_file_format == "avro")
                    or (self.ds_file_format == "orc")
                    or (self.ds_file_format == "parquet")
                )
                and (self.ds_create_hive_table)
            )
        ) else exclude.add("ds_create_hive_table_drop_hive_table")
        include.add("codec_parquet") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                        or (self.file_format == "parquet")
                    )
                )
                or (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and not self.file_format.value)
                            or (not self.file_format)
                        )
                    )
                    and (re.match(r".*\.parquet$", self.file_name))
                )
            )
            and (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                        or (self.table_format != "deltalake")
                    )
                )
                and (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                        or (self.table_format != "iceberg")
                    )
                )
            )
        ) else exclude.add("codec_parquet")
        include.add("the_data_path") if (
            self.table_format
            and (
                (hasattr(self.table_format, "value") and self.table_format.value == "iceberg")
                or (self.table_format == "iceberg")
            )
        ) else exclude.add("the_data_path")
        include.add("quote_character") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                or (self.file_format == "delimited")
            )
        ) else exclude.add("quote_character")
        include.add("escape_character") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                or (self.file_format == "delimited")
            )
        ) else exclude.add("escape_character")
        include.add("codec_delimited") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            and (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                        or (self.table_format != "deltalake")
                    )
                )
                and (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                        or (self.table_format != "iceberg")
                    )
                )
            )
        ) else exclude.add("codec_delimited")
        include.add("time_format") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                    or (self.file_format == "avro")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                    or (self.file_format == "parquet")
                )
            )
        ) else exclude.add("time_format")
        include.add("codec_orc") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "orc")
                        or (self.file_format == "orc")
                    )
                )
                or (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and not self.file_format.value)
                            or (not self.file_format)
                        )
                    )
                    and (re.match(r".*\.orc$", self.file_name))
                )
            )
            and (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                        or (self.table_format != "deltalake")
                    )
                )
                and (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                        or (self.table_format != "iceberg")
                    )
                )
            )
        ) else exclude.add("codec_orc")
        include.add("table_format") if (
            self.write_mode
            and (
                (hasattr(self.write_mode, "value") and self.write_mode.value == "write") or (self.write_mode == "write")
            )
        ) else exclude.add("table_format")
        include.add("codec_csv") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "csv") or (self.file_format == "csv")
            )
        ) else exclude.add("codec_csv")
        include.add("table_action") if (
            (
                self.table_format
                and (
                    (hasattr(self.table_format, "value") and self.table_format.value == "deltalake")
                    or (self.table_format == "deltalake")
                )
            )
            or (
                self.table_format
                and (
                    (hasattr(self.table_format, "value") and self.table_format.value == "iceberg")
                    or (self.table_format == "iceberg")
                )
            )
        ) else exclude.add("table_action")
        include.add("include_types") if (
            (self.first_line_is_header)
            and (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                        or (self.file_format == "excel")
                    )
                )
            )
        ) else exclude.add("include_types")
        include.add("decimal_format") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                    or (self.file_format == "avro")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                    or (self.file_format == "parquet")
                )
            )
        ) else exclude.add("decimal_format")
        include.add("date_format") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                    or (self.file_format == "avro")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                    or (self.file_format == "parquet")
                )
            )
        ) else exclude.add("date_format")
        include.add("decimal_separator") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                    or (self.file_format == "avro")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                    or (self.file_format == "parquet")
                )
            )
        ) else exclude.add("decimal_separator")
        include.add("partition_name_prefix") if (
            (
                self.table_format
                and (
                    (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                    or (self.table_format != "deltalake")
                )
            )
            and (
                self.table_format
                and (
                    (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                    or (self.table_format != "iceberg")
                )
            )
        ) else exclude.add("partition_name_prefix")
        include.add("codec_avro") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                        or (self.file_format == "avro")
                    )
                )
                or (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and not self.file_format.value)
                            or (not self.file_format)
                        )
                    )
                    and (re.match(r".*\.avro$", self.file_name))
                )
            )
            and (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                        or (self.table_format != "deltalake")
                    )
                )
                and (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                        or (self.table_format != "iceberg")
                    )
                )
            )
        ) else exclude.add("codec_avro")
        include.add("encoding") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
        ) else exclude.add("encoding")
        include.add("table_data_file_compression_codec") if (
            (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value == "deltalake")
                        or (self.table_format == "deltalake")
                    )
                )
                or (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value == "iceberg")
                        or (self.table_format == "iceberg")
                    )
                )
            )
            and (
                self.table_data_file_format
                and (
                    (hasattr(self.table_data_file_format, "value") and self.table_data_file_format.value)
                    or (self.table_data_file_format)
                )
            )
            and (self.endpoint_folder)
            and (
                self.write_mode
                and (
                    (hasattr(self.write_mode, "value") and self.write_mode.value == "write")
                    or (self.write_mode == "write")
                )
            )
        ) else exclude.add("table_data_file_compression_codec")
        include.add("timestamp_format") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                    or (self.file_format == "avro")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                    or (self.file_format == "parquet")
                )
            )
        ) else exclude.add("timestamp_format")
        include.add("decimal_grouping_separator") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                    or (self.file_format == "avro")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                    or (self.file_format == "parquet")
                )
            )
        ) else exclude.add("decimal_grouping_separator")
        include.add("encryption_key") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "sav")
                        or (self.file_format == "sav")
                    )
                )
                or (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and not self.file_format.value)
                            or (not self.file_format)
                        )
                    )
                    and (re.match(r".*\.sav$", self.file_name))
                )
            )
            and (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                        or (self.table_format != "deltalake")
                    )
                )
                and (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                        or (self.table_format != "iceberg")
                    )
                )
            )
        ) else exclude.add("encryption_key")
        include.add("table_data_file_format") if (
            (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value == "deltalake")
                        or (self.table_format == "deltalake")
                    )
                )
                or (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value == "iceberg")
                        or (self.table_format == "iceberg")
                    )
                )
            )
            and (self.endpoint_folder)
        ) else exclude.add("table_data_file_format")
        include.add("worksheet_name") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                    or (self.file_format == "excel")
                )
            )
            and (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                        or (self.table_format != "deltalake")
                    )
                )
                and (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                        or (self.table_format != "iceberg")
                    )
                )
            )
        ) else exclude.add("worksheet_name")
        include.add("the_partition_columns") if (self.endpoint_folder) else exclude.add("the_partition_columns")
        include.add("partitioned") if (
            (
                self.write_mode
                and (
                    (hasattr(self.write_mode, "value") and self.write_mode.value == "write")
                    or (self.write_mode == "write")
                )
            )
            and (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
            )
        ) else exclude.add("partitioned")
        include.add("file_format") if (
            (
                self.write_mode
                and (
                    (hasattr(self.write_mode, "value") and self.write_mode.value == "write")
                    or (self.write_mode == "write")
                )
            )
            and (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                        or (self.table_format != "deltalake")
                    )
                )
                and (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                        or (self.table_format != "iceberg")
                    )
                )
            )
        ) else exclude.add("file_format")
        include.add("quote_numeric_values") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                    or (self.file_format == "csv")
                )
            )
            or (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                    or (self.file_format == "delimited")
                )
            )
        ) else exclude.add("quote_numeric_values")
        include.add("names_as_labels") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "sav")
                        or (self.file_format == "sav")
                    )
                )
                or (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and not self.file_format.value)
                            or (not self.file_format)
                        )
                    )
                    and (re.match(r".*\.sav$", self.file_name))
                )
            )
            and (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                        or (self.table_format != "deltalake")
                    )
                )
                and (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                        or (self.table_format != "iceberg")
                    )
                )
            )
        ) else exclude.add("names_as_labels")
        include.add("ds_split_on_key") if (
            (
                (
                    (not self.ds_wave_handling_append_uid)
                    or (self.ds_wave_handling_append_uid and "#" in str(self.ds_wave_handling_append_uid))
                )
                and (
                    (self.ds_write_mode == "write_multiple_files")
                    or (self.ds_write_mode and "#" in str(self.ds_write_mode))
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_split_on_key")
        include.add("codec_parquet") if (
            (
                (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                            or (self.file_format == "parquet")
                        )
                    )
                    or (
                        (
                            (
                                self.file_format
                                and (
                                    (hasattr(self.file_format, "value") and not self.file_format.value)
                                    or (not self.file_format)
                                )
                            )
                            or (
                                self.file_format
                                and (
                                    (
                                        hasattr(self.file_format, "value")
                                        and self.file_format.value
                                        and "#" in str(self.file_format.value)
                                    )
                                    or ("#" in str(self.file_format))
                                )
                            )
                        )
                        and (
                            (re.match(r".*\.parquet$", self.file_name))
                            or (self.file_name and "#" in str(self.file_name))
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (
                                hasattr(self.file_format, "value")
                                and self.file_format.value
                                and "#" in str(self.file_format.value)
                            )
                            or ("#" in str(self.file_format))
                        )
                    )
                )
                and (
                    (
                        (
                            self.table_format
                            and (
                                (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                                or (self.table_format != "deltalake")
                            )
                        )
                        or (
                            self.table_format
                            and (
                                (
                                    hasattr(self.table_format, "value")
                                    and self.table_format.value
                                    and "#" in str(self.table_format.value)
                                )
                                or ("#" in str(self.table_format))
                            )
                        )
                    )
                    and (
                        (
                            self.table_format
                            and (
                                (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                                or (self.table_format != "iceberg")
                            )
                        )
                        or (
                            self.table_format
                            and (
                                (
                                    hasattr(self.table_format, "value")
                                    and self.table_format.value
                                    and "#" in str(self.table_format.value)
                                )
                                or ("#" in str(self.table_format))
                            )
                        )
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("codec_parquet")
        include.add("ds_create_hive_table_hive_keytab") if (
            (
                (self.ds_create_hive_table_hive_use_keytab)
                or (self.ds_create_hive_table_hive_use_keytab and "#" in str(self.ds_create_hive_table_hive_use_keytab))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_create_hive_table_hive_keytab")
        include.add("the_data_path") if (
            (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value == "iceberg")
                        or (self.table_format == "iceberg")
                    )
                )
                or (
                    self.table_format
                    and (
                        (
                            hasattr(self.table_format, "value")
                            and self.table_format.value
                            and "#" in str(self.table_format.value)
                        )
                        or ("#" in str(self.table_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("the_data_path")
        include.add("ds_create_hive_table") if (
            (
                (
                    (
                        (self.ds_write_mode == "write_multiple_files")
                        or (self.ds_write_mode == "write_single_file")
                        or (self.ds_write_mode and "#" in str(self.ds_write_mode))
                    )
                    and (
                        (self.ds_file_format == "delimited")
                        or (self.ds_file_format and "#" in str(self.ds_file_format))
                    )
                    and (
                        (self.ds_file_format_delimited_syntax_quotes == "none")
                        or (
                            self.ds_file_format_delimited_syntax_quotes
                            and "#" in str(self.ds_file_format_delimited_syntax_quotes)
                        )
                    )
                )
                or (
                    (
                        (self.ds_write_mode == "write_multiple_files")
                        or (self.ds_write_mode == "write_single_file")
                        or (self.ds_write_mode and "#" in str(self.ds_write_mode))
                    )
                    and (
                        (self.ds_file_format == "avro")
                        or (self.ds_file_format == "orc")
                        or (self.ds_file_format == "parquet")
                        or (self.ds_file_format and "#" in str(self.ds_file_format))
                    )
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_create_hive_table")
        include.add("ds_file_format_parquet_target_parquet_compress") if (
            ((self.ds_file_format == "parquet") or (self.ds_file_format and "#" in str(self.ds_file_format)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_parquet_target_parquet_compress")
        include.add("ds_create_hive_table_hive_table_type") if (
            (
                ((self.ds_create_hive_table) or (self.ds_create_hive_table and "#" in str(self.ds_create_hive_table)))
                and ((self.ds_file_format == "parquet") or (self.ds_file_format and "#" in str(self.ds_file_format)))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_create_hive_table_hive_table_type")
        include.add("quote_character") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("quote_character")
        include.add("ds_split_on_key_key_in_filename") if (
            ((self.ds_split_on_key) or (self.ds_split_on_key and "#" in str(self.ds_split_on_key)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_split_on_key_key_in_filename")
        include.add("escape_character") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("escape_character")
        include.add("ds_file_format_orc_target_orc_stripe_size") if (
            ((self.ds_file_format == "orc") or (self.ds_file_format and "#" in str(self.ds_file_format)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_orc_target_orc_stripe_size")
        include.add("codec_delimited") if (
            (
                (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                            or (self.file_format == "delimited")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (
                                hasattr(self.file_format, "value")
                                and self.file_format.value
                                and "#" in str(self.file_format.value)
                            )
                            or ("#" in str(self.file_format))
                        )
                    )
                )
                and (
                    (
                        (
                            self.table_format
                            and (
                                (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                                or (self.table_format != "deltalake")
                            )
                        )
                        or (
                            self.table_format
                            and (
                                (
                                    hasattr(self.table_format, "value")
                                    and self.table_format.value
                                    and "#" in str(self.table_format.value)
                                )
                                or ("#" in str(self.table_format))
                            )
                        )
                    )
                    and (
                        (
                            self.table_format
                            and (
                                (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                                or (self.table_format != "iceberg")
                            )
                        )
                        or (
                            self.table_format
                            and (
                                (
                                    hasattr(self.table_format, "value")
                                    and self.table_format.value
                                    and "#" in str(self.table_format.value)
                                )
                                or ("#" in str(self.table_format))
                            )
                        )
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("codec_delimited")
        include.add("ds_create_hive_table_hive_kerberos") if (
            ((self.ds_create_hive_table) or (self.ds_create_hive_table and "#" in str(self.ds_create_hive_table)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_create_hive_table_hive_kerberos")
        include.add("time_format") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                        or (self.file_format == "avro")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                        or (self.file_format == "parquet")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("time_format")
        include.add("ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_type") if (
            (
                (self.ds_create_hive_table_use_staging_table)
                or (
                    self.ds_create_hive_table_use_staging_table
                    and "#" in str(self.ds_create_hive_table_use_staging_table)
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_type")
        include.add("codec_orc") if (
            (
                (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "orc")
                            or (self.file_format == "orc")
                        )
                    )
                    or (
                        (
                            (
                                self.file_format
                                and (
                                    (hasattr(self.file_format, "value") and not self.file_format.value)
                                    or (not self.file_format)
                                )
                            )
                            or (
                                self.file_format
                                and (
                                    (
                                        hasattr(self.file_format, "value")
                                        and self.file_format.value
                                        and "#" in str(self.file_format.value)
                                    )
                                    or ("#" in str(self.file_format))
                                )
                            )
                        )
                        and ((re.match(r".*\.orc$", self.file_name)) or (self.file_name and "#" in str(self.file_name)))
                    )
                    or (
                        self.file_format
                        and (
                            (
                                hasattr(self.file_format, "value")
                                and self.file_format.value
                                and "#" in str(self.file_format.value)
                            )
                            or ("#" in str(self.file_format))
                        )
                    )
                )
                and (
                    (
                        (
                            self.table_format
                            and (
                                (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                                or (self.table_format != "deltalake")
                            )
                        )
                        or (
                            self.table_format
                            and (
                                (
                                    hasattr(self.table_format, "value")
                                    and self.table_format.value
                                    and "#" in str(self.table_format.value)
                                )
                                or ("#" in str(self.table_format))
                            )
                        )
                    )
                    and (
                        (
                            self.table_format
                            and (
                                (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                                or (self.table_format != "iceberg")
                            )
                        )
                        or (
                            self.table_format
                            and (
                                (
                                    hasattr(self.table_format, "value")
                                    and self.table_format.value
                                    and "#" in str(self.table_format.value)
                                )
                                or ("#" in str(self.table_format))
                            )
                        )
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("codec_orc")
        include.add("ds_file_format_impl_syntax_encoding_output_bom") if (
            ((self.ds_file_format == "implicit") or (self.ds_file_format and "#" in str(self.ds_file_format)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_impl_syntax_encoding_output_bom")
        include.add("ds_file_format_avro_target_avro_schema") if (
            ((self.ds_file_format == "avro") or (self.ds_file_format and "#" in str(self.ds_file_format)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_avro_target_avro_schema")
        include.add("table_format") if (
            (
                (
                    self.write_mode
                    and (
                        (hasattr(self.write_mode, "value") and self.write_mode.value == "write")
                        or (self.write_mode == "write")
                    )
                )
                or (
                    self.write_mode
                    and (
                        (
                            hasattr(self.write_mode, "value")
                            and self.write_mode.value
                            and "#" in str(self.write_mode.value)
                        )
                        or ("#" in str(self.write_mode))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("table_format")
        include.add("ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_orc_stripe_size") if (
            (
                (
                    self.ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_format
                    == "orc"
                )
                or (
                    self.ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_format
                    and "#"
                    in str(
                        self.ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_format
                    )
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_orc_stripe_size")
        include.add("ds_file_format_delimited_syntax_header_include_types") if (
            (
                (self.ds_file_format_delimited_syntax_header)
                or (
                    self.ds_file_format_delimited_syntax_header
                    and "#" in str(self.ds_file_format_delimited_syntax_header)
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_delimited_syntax_header_include_types")
        include.add("ds_file_format_impl_syntax_header_include_types") if (
            (
                (self.ds_file_format_impl_syntax_header)
                or (self.ds_file_format_impl_syntax_header and "#" in str(self.ds_file_format_impl_syntax_header))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_impl_syntax_header_include_types")
        include.add("ds_split_on_key_exclude_part_string") if (
            (
                ((self.ds_split_on_key) or (self.ds_split_on_key and "#" in str(self.ds_split_on_key)))
                and (
                    (self.ds_split_on_key_key_in_filename)
                    or (self.ds_split_on_key_key_in_filename and "#" in str(self.ds_split_on_key_key_in_filename))
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_split_on_key_exclude_part_string")
        include.add("codec_csv") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("codec_csv")
        include.add("table_action") if (
            (
                (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value == "deltalake")
                        or (self.table_format == "deltalake")
                    )
                )
                or (
                    self.table_format
                    and (
                        (hasattr(self.table_format, "value") and self.table_format.value == "iceberg")
                        or (self.table_format == "iceberg")
                    )
                )
                or (
                    self.table_format
                    and (
                        (
                            hasattr(self.table_format, "value")
                            and self.table_format.value
                            and "#" in str(self.table_format.value)
                        )
                        or ("#" in str(self.table_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("table_action")
        include.add("ds_file_format_impl_syntax_header") if (
            ((self.ds_file_format == "implicit") or (self.ds_file_format and "#" in str(self.ds_file_format)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_impl_syntax_header")
        include.add("ds_wave_handling_file_size_threshold") if (
            (
                (self.ds_wave_handling_append_uid)
                or (self.ds_wave_handling_append_uid and "#" in str(self.ds_wave_handling_append_uid))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_wave_handling_file_size_threshold")
        include.add("include_types") if (
            (
                ((self.first_line_is_header) or (self.first_line_is_header and "#" in str(self.first_line_is_header)))
                and (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                            or (self.file_format == "csv")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                            or (self.file_format == "delimited")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                            or (self.file_format == "excel")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (
                                hasattr(self.file_format, "value")
                                and self.file_format.value
                                and "#" in str(self.file_format.value)
                            )
                            or ("#" in str(self.file_format))
                        )
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("include_types")
        include.add("ds_create_hive_table_use_staging_table_load_existing_table_max_dynamic_partitions") if (
            (
                (self.ds_create_hive_table_use_staging_table)
                or (
                    self.ds_create_hive_table_use_staging_table
                    and "#" in str(self.ds_create_hive_table_use_staging_table)
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_create_hive_table_use_staging_table_load_existing_table_max_dynamic_partitions")
        include.add("decimal_format") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                        or (self.file_format == "avro")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                        or (self.file_format == "parquet")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("decimal_format")
        include.add("ds_create_hive_table_hive_use_keytab") if (
            (
                (self.ds_create_hive_table_hive_kerberos)
                or (self.ds_create_hive_table_hive_kerberos and "#" in str(self.ds_create_hive_table_hive_kerberos))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_create_hive_table_hive_use_keytab")
        include.add("date_format") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                        or (self.file_format == "avro")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                        or (self.file_format == "parquet")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("date_format")
        include.add("decimal_separator") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                        or (self.file_format == "avro")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                        or (self.file_format == "parquet")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("decimal_separator")
        include.add("partition_name_prefix") if (
            (
                (
                    (
                        self.table_format
                        and (
                            (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                            or (self.table_format != "deltalake")
                        )
                    )
                    or (
                        self.table_format
                        and (
                            (
                                hasattr(self.table_format, "value")
                                and self.table_format.value
                                and "#" in str(self.table_format.value)
                            )
                            or ("#" in str(self.table_format))
                        )
                    )
                )
                and (
                    (
                        self.table_format
                        and (
                            (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                            or (self.table_format != "iceberg")
                        )
                    )
                    or (
                        self.table_format
                        and (
                            (
                                hasattr(self.table_format, "value")
                                and self.table_format.value
                                and "#" in str(self.table_format.value)
                            )
                            or ("#" in str(self.table_format))
                        )
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("partition_name_prefix")
        include.add("ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_format") if (
            (
                (self.ds_create_hive_table_use_staging_table)
                or (
                    self.ds_create_hive_table_use_staging_table
                    and "#" in str(self.ds_create_hive_table_use_staging_table)
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add(
            "ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_format"
        )
        include.add("codec_avro") if (
            (
                (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                            or (self.file_format == "avro")
                        )
                    )
                    or (
                        (
                            (
                                self.file_format
                                and (
                                    (hasattr(self.file_format, "value") and not self.file_format.value)
                                    or (not self.file_format)
                                )
                            )
                            or (
                                self.file_format
                                and (
                                    (
                                        hasattr(self.file_format, "value")
                                        and self.file_format.value
                                        and "#" in str(self.file_format.value)
                                    )
                                    or ("#" in str(self.file_format))
                                )
                            )
                        )
                        and (
                            (re.match(r".*\.avro$", self.file_name)) or (self.file_name and "#" in str(self.file_name))
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (
                                hasattr(self.file_format, "value")
                                and self.file_format.value
                                and "#" in str(self.file_format.value)
                            )
                            or ("#" in str(self.file_format))
                        )
                    )
                )
                and (
                    (
                        (
                            self.table_format
                            and (
                                (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                                or (self.table_format != "deltalake")
                            )
                        )
                        or (
                            self.table_format
                            and (
                                (
                                    hasattr(self.table_format, "value")
                                    and self.table_format.value
                                    and "#" in str(self.table_format.value)
                                )
                                or ("#" in str(self.table_format))
                            )
                        )
                    )
                    and (
                        (
                            self.table_format
                            and (
                                (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                                or (self.table_format != "iceberg")
                            )
                        )
                        or (
                            self.table_format
                            and (
                                (
                                    hasattr(self.table_format, "value")
                                    and self.table_format.value
                                    and "#" in str(self.table_format.value)
                                )
                                or ("#" in str(self.table_format))
                            )
                        )
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("codec_avro")
        include.add("ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_orc_compress") if (
            (
                (
                    self.ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_format
                    == "orc"
                )
                or (
                    self.ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_format
                    and "#"
                    in str(
                        self.ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_format
                    )
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_orc_compress")
        include.add("ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_parquet_compress") if (
            (
                (
                    self.ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_format
                    == "parquet"
                )
                or (
                    self.ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_format
                    and "#"
                    in str(
                        self.ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_format
                    )
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_parquet_compress")
        include.add("ds_file_format_delimited_syntax_header") if (
            (
                (self.ds_file_format == "comma-separated_value_csv")
                or (self.ds_file_format == "delimited")
                or (self.ds_file_format and "#" in str(self.ds_file_format))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_delimited_syntax_header")
        include.add("ds_max_file_size") if (
            (
                (
                    (not self.ds_wave_handling_append_uid)
                    or (self.ds_wave_handling_append_uid and "#" in str(self.ds_wave_handling_append_uid))
                )
                and (
                    (self.ds_write_mode == "write_multiple_files")
                    or (self.ds_write_mode and "#" in str(self.ds_write_mode))
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_max_file_size")
        include.add("encoding") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("encoding")
        include.add("table_data_file_compression_codec") if (
            (
                (
                    (
                        self.table_format
                        and (
                            (hasattr(self.table_format, "value") and self.table_format.value == "deltalake")
                            or (self.table_format == "deltalake")
                        )
                    )
                    or (
                        self.table_format
                        and (
                            (hasattr(self.table_format, "value") and self.table_format.value == "iceberg")
                            or (self.table_format == "iceberg")
                        )
                    )
                    or (
                        self.table_format
                        and (
                            (
                                hasattr(self.table_format, "value")
                                and self.table_format.value
                                and "#" in str(self.table_format.value)
                            )
                            or ("#" in str(self.table_format))
                        )
                    )
                )
                and (
                    (
                        self.table_data_file_format
                        and (
                            (hasattr(self.table_data_file_format, "value") and self.table_data_file_format.value)
                            or (self.table_data_file_format)
                        )
                    )
                    or (
                        self.table_data_file_format
                        and (
                            (
                                hasattr(self.table_data_file_format, "value")
                                and self.table_data_file_format.value
                                and "#" in str(self.table_data_file_format.value)
                            )
                            or ("#" in str(self.table_data_file_format))
                        )
                    )
                )
                and ((self.endpoint_folder) or (self.endpoint_folder and "#" in str(self.endpoint_folder)))
                and (
                    (
                        self.write_mode
                        and (
                            (hasattr(self.write_mode, "value") and self.write_mode.value == "write")
                            or (self.write_mode == "write")
                        )
                    )
                    or (
                        self.write_mode
                        and (
                            (
                                hasattr(self.write_mode, "value")
                                and self.write_mode.value
                                and "#" in str(self.write_mode.value)
                            )
                            or ("#" in str(self.write_mode))
                        )
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("table_data_file_compression_codec")
        include.add("timestamp_format") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                        or (self.file_format == "avro")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                        or (self.file_format == "parquet")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("timestamp_format")
        include.add("ds_file_format_delimited_syntax_encoding_output_bom") if (
            (
                (self.ds_file_format == "comma-separated_value_csv")
                or (self.ds_file_format == "delimited")
                or (self.ds_file_format and "#" in str(self.ds_file_format))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_delimited_syntax_encoding_output_bom")
        include.add("ds_create_hive_table_create_hive_schema") if (
            ((self.ds_create_hive_table) or (self.ds_create_hive_table and "#" in str(self.ds_create_hive_table)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_create_hive_table_create_hive_schema")
        include.add("ds_file_exists") if (
            (
                (
                    (not self.ds_wave_handling_append_uid)
                    or (self.ds_wave_handling_append_uid and "#" in str(self.ds_wave_handling_append_uid))
                )
                and (
                    (self.ds_write_mode == "write_multiple_files")
                    or (self.ds_write_mode == "write_single_file")
                    or (self.ds_write_mode and "#" in str(self.ds_write_mode))
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_exists")
        include.add("decimal_grouping_separator") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                        or (self.file_format == "avro")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                        or (self.file_format == "parquet")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("decimal_grouping_separator")
        include.add("ds_wave_handling_append_uid") if (
            (
                (self.ds_write_mode == "write_multiple_files")
                or (self.ds_write_mode == "write_single_file")
                or (self.ds_write_mode and "#" in str(self.ds_write_mode))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_wave_handling_append_uid")
        include.add("encryption_key") if (
            (
                (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "sav")
                            or (self.file_format == "sav")
                        )
                    )
                    or (
                        (
                            (
                                self.file_format
                                and (
                                    (hasattr(self.file_format, "value") and not self.file_format.value)
                                    or (not self.file_format)
                                )
                            )
                            or (
                                self.file_format
                                and (
                                    (
                                        hasattr(self.file_format, "value")
                                        and self.file_format.value
                                        and "#" in str(self.file_format.value)
                                    )
                                    or ("#" in str(self.file_format))
                                )
                            )
                        )
                        and ((re.match(r".*\.sav$", self.file_name)) or (self.file_name and "#" in str(self.file_name)))
                    )
                    or (
                        self.file_format
                        and (
                            (
                                hasattr(self.file_format, "value")
                                and self.file_format.value
                                and "#" in str(self.file_format.value)
                            )
                            or ("#" in str(self.file_format))
                        )
                    )
                )
                and (
                    (
                        (
                            self.table_format
                            and (
                                (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                                or (self.table_format != "deltalake")
                            )
                        )
                        or (
                            self.table_format
                            and (
                                (
                                    hasattr(self.table_format, "value")
                                    and self.table_format.value
                                    and "#" in str(self.table_format.value)
                                )
                                or ("#" in str(self.table_format))
                            )
                        )
                    )
                    and (
                        (
                            self.table_format
                            and (
                                (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                                or (self.table_format != "iceberg")
                            )
                        )
                        or (
                            self.table_format
                            and (
                                (
                                    hasattr(self.table_format, "value")
                                    and self.table_format.value
                                    and "#" in str(self.table_format.value)
                                )
                                or ("#" in str(self.table_format))
                            )
                        )
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("encryption_key")
        include.add("table_data_file_format") if (
            (
                (
                    (
                        self.table_format
                        and (
                            (hasattr(self.table_format, "value") and self.table_format.value == "deltalake")
                            or (self.table_format == "deltalake")
                        )
                    )
                    or (
                        self.table_format
                        and (
                            (hasattr(self.table_format, "value") and self.table_format.value == "iceberg")
                            or (self.table_format == "iceberg")
                        )
                    )
                    or (
                        self.table_format
                        and (
                            (
                                hasattr(self.table_format, "value")
                                and self.table_format.value
                                and "#" in str(self.table_format.value)
                            )
                            or ("#" in str(self.table_format))
                        )
                    )
                )
                and ((self.endpoint_folder) or (self.endpoint_folder and "#" in str(self.endpoint_folder)))
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("table_data_file_format")
        include.add("worksheet_name") if (
            (
                (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                            or (self.file_format == "excel")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (
                                hasattr(self.file_format, "value")
                                and self.file_format.value
                                and "#" in str(self.file_format.value)
                            )
                            or ("#" in str(self.file_format))
                        )
                    )
                )
                and (
                    (
                        (
                            self.table_format
                            and (
                                (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                                or (self.table_format != "deltalake")
                            )
                        )
                        or (
                            self.table_format
                            and (
                                (
                                    hasattr(self.table_format, "value")
                                    and self.table_format.value
                                    and "#" in str(self.table_format.value)
                                )
                                or ("#" in str(self.table_format))
                            )
                        )
                    )
                    and (
                        (
                            self.table_format
                            and (
                                (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                                or (self.table_format != "iceberg")
                            )
                        )
                        or (
                            self.table_format
                            and (
                                (
                                    hasattr(self.table_format, "value")
                                    and self.table_format.value
                                    and "#" in str(self.table_format.value)
                                )
                                or ("#" in str(self.table_format))
                            )
                        )
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("worksheet_name")
        include.add("ds_file_format_avro_target_avro_codec") if (
            ((self.ds_file_format == "avro") or (self.ds_file_format and "#" in str(self.ds_file_format)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_avro_target_avro_codec")
        include.add("ds_split_on_key_key_column") if (
            ((self.ds_split_on_key) or (self.ds_split_on_key and "#" in str(self.ds_split_on_key)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_split_on_key_key_column")
        include.add("ds_file_format_parquet_target_parquet_block_size") if (
            ((self.ds_file_format == "parquet") or (self.ds_file_format and "#" in str(self.ds_file_format)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_parquet_target_parquet_block_size")
        include.add("the_partition_columns") if (
            ((self.endpoint_folder) or (self.endpoint_folder and "#" in str(self.endpoint_folder)))
            and (not self.ds_use_datastage)
        ) else exclude.add("the_partition_columns")
        include.add("ds_cleanup") if (
            (
                (self.ds_write_mode == "write_multiple_files")
                or (self.ds_write_mode == "write_single_file")
                or (self.ds_write_mode and "#" in str(self.ds_write_mode))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_cleanup")
        include.add("ds_file_format_avro_target_avro_array_keys") if (
            ((self.ds_file_format == "avro") or (self.ds_file_format and "#" in str(self.ds_file_format)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_avro_target_avro_array_keys")
        include.add("partitioned") if (
            (
                (
                    (
                        self.write_mode
                        and (
                            (hasattr(self.write_mode, "value") and self.write_mode.value == "write")
                            or (self.write_mode == "write")
                        )
                    )
                    or (
                        self.write_mode
                        and (
                            (
                                hasattr(self.write_mode, "value")
                                and self.write_mode.value
                                and "#" in str(self.write_mode.value)
                            )
                            or ("#" in str(self.write_mode))
                        )
                    )
                )
                and (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                            or (self.file_format == "csv")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                            or (self.file_format == "delimited")
                        )
                    )
                    or (
                        self.file_format
                        and (
                            (
                                hasattr(self.file_format, "value")
                                and self.file_format.value
                                and "#" in str(self.file_format.value)
                            )
                            or ("#" in str(self.file_format))
                        )
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("partitioned")
        include.add("ds_create_hive_table_hive_table") if (
            ((self.ds_create_hive_table) or (self.ds_create_hive_table and "#" in str(self.ds_create_hive_table)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_create_hive_table_hive_table")
        include.add("ds_file_format_orc_target_orc_buffer_size") if (
            ((self.ds_file_format == "orc") or (self.ds_file_format and "#" in str(self.ds_file_format)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_orc_target_orc_buffer_size")
        include.add("ds_create_hive_table_hive_service_principal") if (
            (
                (self.ds_create_hive_table_hive_kerberos)
                or (self.ds_create_hive_table_hive_kerberos and "#" in str(self.ds_create_hive_table_hive_kerberos))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_create_hive_table_hive_service_principal")
        include.add("ds_file_format_avro_target_input_json") if (
            ((self.ds_file_format == "avro") or (self.ds_file_format and "#" in str(self.ds_file_format)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_avro_target_input_json")
        include.add("ds_force_sequential") if (
            (
                (
                    (not self.ds_wave_handling_append_uid)
                    or (self.ds_wave_handling_append_uid and "#" in str(self.ds_wave_handling_append_uid))
                )
                and (
                    (self.ds_write_mode == "write_multiple_files")
                    or (self.ds_write_mode and "#" in str(self.ds_write_mode))
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_force_sequential")
        include.add("ds_file_format_orc_target_orc_compress") if (
            ((self.ds_file_format == "orc") or (self.ds_file_format and "#" in str(self.ds_file_format)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_orc_target_orc_compress")
        include.add("file_format") if (
            (
                (
                    (
                        self.write_mode
                        and (
                            (hasattr(self.write_mode, "value") and self.write_mode.value == "write")
                            or (self.write_mode == "write")
                        )
                    )
                    or (
                        self.write_mode
                        and (
                            (
                                hasattr(self.write_mode, "value")
                                and self.write_mode.value
                                and "#" in str(self.write_mode.value)
                            )
                            or ("#" in str(self.write_mode))
                        )
                    )
                )
                and (
                    (
                        (
                            self.table_format
                            and (
                                (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                                or (self.table_format != "deltalake")
                            )
                        )
                        or (
                            self.table_format
                            and (
                                (
                                    hasattr(self.table_format, "value")
                                    and self.table_format.value
                                    and "#" in str(self.table_format.value)
                                )
                                or ("#" in str(self.table_format))
                            )
                        )
                    )
                    and (
                        (
                            self.table_format
                            and (
                                (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                                or (self.table_format != "iceberg")
                            )
                        )
                        or (
                            self.table_format
                            and (
                                (
                                    hasattr(self.table_format, "value")
                                    and self.table_format.value
                                    and "#" in str(self.table_format.value)
                                )
                                or ("#" in str(self.table_format))
                            )
                        )
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("file_format")
        include.add("ds_split_on_key_case_sensitive") if (
            ((self.ds_split_on_key) or (self.ds_split_on_key and "#" in str(self.ds_split_on_key)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_split_on_key_case_sensitive")
        include.add(
            "ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_location"
        ) if (
            (
                (self.ds_create_hive_table_use_staging_table)
                or (
                    self.ds_create_hive_table_use_staging_table
                    and "#" in str(self.ds_create_hive_table_use_staging_table)
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add(
            "ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_location"
        )
        include.add("quote_numeric_values") if (
            (
                (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "csv")
                        or (self.file_format == "csv")
                    )
                )
                or (
                    self.file_format
                    and (
                        (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                        or (self.file_format == "delimited")
                    )
                )
                or (
                    self.file_format
                    and (
                        (
                            hasattr(self.file_format, "value")
                            and self.file_format.value
                            and "#" in str(self.file_format.value)
                        )
                        or ("#" in str(self.file_format))
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("quote_numeric_values")
        include.add("ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_drop_staging_table") if (
            (
                (self.ds_create_hive_table_use_staging_table)
                or (
                    self.ds_create_hive_table_use_staging_table
                    and "#" in str(self.ds_create_hive_table_use_staging_table)
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add(
            "ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_drop_staging_table"
        )
        include.add("ds_file_format_parquet_target_parquet_page_size") if (
            ((self.ds_file_format == "parquet") or (self.ds_file_format and "#" in str(self.ds_file_format)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format_parquet_target_parquet_page_size")
        include.add("ds_create_hive_table_use_staging_table") if (
            (
                ((self.ds_create_hive_table) or (self.ds_create_hive_table and "#" in str(self.ds_create_hive_table)))
                and ((self.ds_file_format == "delimited") or (self.ds_file_format and "#" in str(self.ds_file_format)))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_create_hive_table_use_staging_table")
        include.add("ds_file_format") if (
            (
                (self.ds_write_mode == "write_multiple_files")
                or (self.ds_write_mode == "write_single_file")
                or (self.ds_write_mode and "#" in str(self.ds_write_mode))
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_file_format")
        include.add("ds_create_hive_table_additional_driver_params") if (
            ((self.ds_create_hive_table) or (self.ds_create_hive_table and "#" in str(self.ds_create_hive_table)))
            and (self.ds_use_datastage)
        ) else exclude.add("ds_create_hive_table_additional_driver_params")
        include.add("ds_create_hive_table_drop_hive_table") if (
            (
                (not self.ds_create_hive_table_use_staging_table)
                or (
                    (
                        (self.ds_file_format == "avro")
                        or (self.ds_file_format == "orc")
                        or (self.ds_file_format == "parquet")
                        or (self.ds_file_format and "#" in str(self.ds_file_format))
                    )
                    and (
                        (self.ds_create_hive_table)
                        or (self.ds_create_hive_table and "#" in str(self.ds_create_hive_table))
                    )
                )
                or (
                    self.ds_create_hive_table_use_staging_table
                    and "#" in str(self.ds_create_hive_table_use_staging_table)
                )
            )
            and (self.ds_use_datastage)
        ) else exclude.add("ds_create_hive_table_drop_hive_table")
        include.add("names_as_labels") if (
            (
                (
                    (
                        self.file_format
                        and (
                            (hasattr(self.file_format, "value") and self.file_format.value == "sav")
                            or (self.file_format == "sav")
                        )
                    )
                    or (
                        (
                            (
                                self.file_format
                                and (
                                    (hasattr(self.file_format, "value") and not self.file_format.value)
                                    or (not self.file_format)
                                )
                            )
                            or (
                                self.file_format
                                and (
                                    (
                                        hasattr(self.file_format, "value")
                                        and self.file_format.value
                                        and "#" in str(self.file_format.value)
                                    )
                                    or ("#" in str(self.file_format))
                                )
                            )
                        )
                        and ((re.match(r".*\.sav$", self.file_name)) or (self.file_name and "#" in str(self.file_name)))
                    )
                    or (
                        self.file_format
                        and (
                            (
                                hasattr(self.file_format, "value")
                                and self.file_format.value
                                and "#" in str(self.file_format.value)
                            )
                            or ("#" in str(self.file_format))
                        )
                    )
                )
                and (
                    (
                        (
                            self.table_format
                            and (
                                (hasattr(self.table_format, "value") and self.table_format.value != "deltalake")
                                or (self.table_format != "deltalake")
                            )
                        )
                        or (
                            self.table_format
                            and (
                                (
                                    hasattr(self.table_format, "value")
                                    and self.table_format.value
                                    and "#" in str(self.table_format.value)
                                )
                                or ("#" in str(self.table_format))
                            )
                        )
                    )
                    and (
                        (
                            self.table_format
                            and (
                                (hasattr(self.table_format, "value") and self.table_format.value != "iceberg")
                                or (self.table_format != "iceberg")
                            )
                        )
                        or (
                            self.table_format
                            and (
                                (
                                    hasattr(self.table_format, "value")
                                    and self.table_format.value
                                    and "#" in str(self.table_format.value)
                                )
                                or ("#" in str(self.table_format))
                            )
                        )
                    )
                )
            )
            and (not self.ds_use_datastage)
        ) else exclude.add("names_as_labels")
        include.add("hive_table") if (not self.ds_use_datastage) else exclude.add("hive_table")
        include.add("write_mode") if (not self.ds_use_datastage) else exclude.add("write_mode")
        include.add("ds_write_mode") if (self.ds_use_datastage) else exclude.add("ds_write_mode")
        include.add("ds_filename_target") if (self.ds_use_datastage) else exclude.add("ds_filename_target")
        include.add("create_or_use_existing_hive_table") if (not self.ds_use_datastage) else exclude.add(
            "create_or_use_existing_hive_table"
        )
        include.add("ds_java_heap_size") if (self.ds_use_datastage) else exclude.add("ds_java_heap_size")
        include.add("the_partition_paths") if (not self.ds_use_datastage) else exclude.add("the_partition_paths")
        include.add("the_cache_expiration") if (not self.ds_use_datastage) else exclude.add("the_cache_expiration")
        include.add("the_cache_size") if (not self.ds_use_datastage) else exclude.add("the_cache_size")
        include.add("data_asset_name") if (self.create_data_asset) else exclude.add("data_asset_name")
        include.add("create_data_asset") if (()) else exclude.add("create_data_asset")
        include.add("ds_file_format_impl_syntax_header") if (self.ds_file_format == "implicit") else exclude.add(
            "ds_file_format_impl_syntax_header"
        )
        include.add("ds_create_hive_table_hive_table_type") if (
            self.ds_create_hive_table == "true" or self.ds_create_hive_table is True
        ) and (self.ds_file_format == "parquet") else exclude.add("ds_create_hive_table_hive_table_type")
        include.add("ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_type") if (
            self.ds_create_hive_table_use_staging_table == "true" or self.ds_create_hive_table_use_staging_table is True
        ) else exclude.add("ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_type")
        include.add("include_types") if (self.first_line_is_header == "yes") and (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "excel" in str(self.file_format.value)
                )
                or ("excel" in str(self.file_format))
            )
        ) else exclude.add("include_types")
        include.add("ds_split_on_key_key_column") if (
            self.ds_split_on_key == "true" or self.ds_split_on_key is True
        ) else exclude.add("ds_split_on_key_key_column")
        include.add("names_as_labels") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "sav")
                    or (self.file_format == "sav")
                )
            )
            or (
                (
                    self.file_format
                    and ((hasattr(self.file_format, "value") and not self.file_format.value) or (not self.file_format))
                )
                and (re.match(r".*\.sav$", self.file_name))
            )
        ) and (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "deltalake" not in str(self.table_format.value)
                )
                or ("deltalake" not in str(self.table_format))
            )
            or self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" not in str(self.table_format.value)
                )
                or ("iceberg" not in str(self.table_format))
            )
        ) else exclude.add("names_as_labels")
        include.add(
            "ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_location"
        ) if (
            self.ds_create_hive_table_use_staging_table == "true" or self.ds_create_hive_table_use_staging_table is True
        ) else exclude.add(
            "ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_location"
        )
        include.add("ds_file_format_avro_target_input_json") if (self.ds_file_format == "avro") else exclude.add(
            "ds_file_format_avro_target_input_json"
        )
        include.add("ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_drop_staging_table") if (
            self.ds_create_hive_table_use_staging_table == "true" or self.ds_create_hive_table_use_staging_table is True
        ) else exclude.add(
            "ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_drop_staging_table"
        )
        include.add("ds_create_hive_table_additional_driver_params") if (
            self.ds_create_hive_table == "true" or self.ds_create_hive_table is True
        ) else exclude.add("ds_create_hive_table_additional_driver_params")
        include.add("encoding") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
        ) else exclude.add("encoding")
        include.add("ds_create_hive_table_drop_hive_table") if (
            self.ds_create_hive_table_use_staging_table == "false"
            or self.ds_create_hive_table_use_staging_table is False
        ) or (
            (
                self.ds_file_format
                and "avro" in str(self.ds_file_format)
                and self.ds_file_format
                and "orc" in str(self.ds_file_format)
                and self.ds_file_format
                and "parquet" in str(self.ds_file_format)
            )
            and (self.ds_create_hive_table == "true" or self.ds_create_hive_table is True)
        ) else exclude.add("ds_create_hive_table_drop_hive_table")
        include.add("ds_create_hive_table_use_staging_table_load_existing_table_max_dynamic_partitions") if (
            self.ds_create_hive_table_use_staging_table == "true" or self.ds_create_hive_table_use_staging_table is True
        ) else exclude.add("ds_create_hive_table_use_staging_table_load_existing_table_max_dynamic_partitions")
        include.add("ds_file_format_orc_target_orc_buffer_size") if (self.ds_file_format == "orc") else exclude.add(
            "ds_file_format_orc_target_orc_buffer_size"
        )
        include.add("codec_csv") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "csv") or (self.file_format == "csv")
            )
        ) else exclude.add("codec_csv")
        include.add("ds_split_on_key_key_in_filename") if (
            self.ds_split_on_key == "true" or self.ds_split_on_key is True
        ) else exclude.add("ds_split_on_key_key_in_filename")
        include.add("codec_delimited") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "delimited")
                or (self.file_format == "delimited")
            )
        ) and (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "deltalake" not in str(self.table_format.value)
                )
                or ("deltalake" not in str(self.table_format))
            )
            or self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" not in str(self.table_format.value)
                )
                or ("iceberg" not in str(self.table_format))
            )
        ) else exclude.add("codec_delimited")
        include.add("quote_character") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
        ) else exclude.add("quote_character")
        include.add("ds_file_format_avro_target_avro_array_keys") if (self.ds_file_format == "avro") else exclude.add(
            "ds_file_format_avro_target_avro_array_keys"
        )
        include.add("ds_wave_handling_file_size_threshold") if (
            self.ds_wave_handling_append_uid == "true" or self.ds_wave_handling_append_uid is True
        ) else exclude.add("ds_wave_handling_file_size_threshold")
        include.add("decimal_format") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "avro" in str(self.file_format.value)
                )
                or ("avro" in str(self.file_format))
            )
            or self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "parquet" in str(self.file_format.value)
                )
                or ("parquet" in str(self.file_format))
            )
        ) else exclude.add("decimal_format")
        include.add("ds_file_format_avro_target_avro_codec") if (self.ds_file_format == "avro") else exclude.add(
            "ds_file_format_avro_target_avro_codec"
        )
        include.add("ds_max_file_size") if (
            self.ds_wave_handling_append_uid == "false" or self.ds_wave_handling_append_uid is False
        ) and (self.ds_write_mode == "write_multiple_files") else exclude.add("ds_max_file_size")
        include.add("ds_split_on_key_case_sensitive") if (
            self.ds_split_on_key == "true" or self.ds_split_on_key is True
        ) else exclude.add("ds_split_on_key_case_sensitive")
        include.add("encryption_key") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "sav")
                    or (self.file_format == "sav")
                )
            )
            or (
                (
                    self.file_format
                    and ((hasattr(self.file_format, "value") and not self.file_format.value) or (not self.file_format))
                )
                and (re.match(r".*\.sav$", self.file_name))
            )
        ) and (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "deltalake" not in str(self.table_format.value)
                )
                or ("deltalake" not in str(self.table_format))
            )
            or self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" not in str(self.table_format.value)
                )
                or ("iceberg" not in str(self.table_format))
            )
        ) else exclude.add("encryption_key")
        include.add("table_data_file_compression_codec") if (
            self.table_data_file_format
            and (
                (hasattr(self.table_data_file_format, "value") and self.table_data_file_format.value == "avro")
                or (self.table_data_file_format == "avro")
            )
        ) else exclude.add("table_data_file_compression_codec")
        include.add("the_partition_columns") if (self.endpoint_folder) else exclude.add("the_partition_columns")
        include.add("quote_numeric_values") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
        ) else exclude.add("quote_numeric_values")
        include.add("codec_orc") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "orc")
                    or (self.file_format == "orc")
                )
            )
            or (
                (
                    self.file_format
                    and ((hasattr(self.file_format, "value") and not self.file_format.value) or (not self.file_format))
                )
                and (re.match(r".*\.orc$", self.file_name))
            )
        ) and (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "deltalake" not in str(self.table_format.value)
                )
                or ("deltalake" not in str(self.table_format))
            )
            or self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" not in str(self.table_format.value)
                )
                or ("iceberg" not in str(self.table_format))
            )
        ) else exclude.add("codec_orc")
        include.add("file_format") if (
            self.write_mode
            and (
                (hasattr(self.write_mode, "value") and self.write_mode.value == "write") or (self.write_mode == "write")
            )
        ) and (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "deltalake" not in str(self.table_format.value)
                )
                or ("deltalake" not in str(self.table_format))
            )
            or self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" not in str(self.table_format.value)
                )
                or ("iceberg" not in str(self.table_format))
            )
        ) else exclude.add("file_format")
        include.add("ds_create_hive_table") if (
            (
                self.ds_write_mode
                and "write_multiple_files" in str(self.ds_write_mode)
                and self.ds_write_mode
                and "write_single_file" in str(self.ds_write_mode)
            )
            and (self.ds_file_format == "delimited")
            and (self.ds_file_format_delimited_syntax_quotes == "none")
        ) or (
            (
                self.ds_write_mode
                and "write_multiple_files" in str(self.ds_write_mode)
                and self.ds_write_mode
                and "write_single_file" in str(self.ds_write_mode)
            )
            and (
                self.ds_file_format
                and "avro" in str(self.ds_file_format)
                and self.ds_file_format
                and "orc" in str(self.ds_file_format)
                and self.ds_file_format
                and "parquet" in str(self.ds_file_format)
            )
        ) else exclude.add("ds_create_hive_table")
        include.add("ds_file_exists") if (
            self.ds_wave_handling_append_uid == "false" or self.ds_wave_handling_append_uid is False
        ) and (
            self.ds_write_mode
            and "write_multiple_files" in str(self.ds_write_mode)
            and self.ds_write_mode
            and "write_single_file" in str(self.ds_write_mode)
        ) else exclude.add("ds_file_exists")
        include.add("ds_create_hive_table_hive_keytab") if (
            self.ds_create_hive_table_hive_use_keytab == "true" or self.ds_create_hive_table_hive_use_keytab is True
        ) else exclude.add("ds_create_hive_table_hive_keytab")
        include.add("ds_create_hive_table_use_staging_table") if (
            self.ds_create_hive_table == "true" or self.ds_create_hive_table is True
        ) and (self.ds_file_format == "delimited") else exclude.add("ds_create_hive_table_use_staging_table")
        include.add("table_format") if (
            self.write_mode
            and (
                (hasattr(self.write_mode, "value") and self.write_mode.value == "write") or (self.write_mode == "write")
            )
        ) else exclude.add("table_format")
        include.add("table_action") if (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "deltalake" in str(self.table_format.value)
                )
                or ("deltalake" in str(self.table_format))
            )
            or self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" in str(self.table_format.value)
                )
                or ("iceberg" in str(self.table_format))
            )
        ) else exclude.add("table_action")
        include.add("ds_create_hive_table_hive_kerberos") if (
            self.ds_create_hive_table == "true" or self.ds_create_hive_table is True
        ) else exclude.add("ds_create_hive_table_hive_kerberos")
        include.add("ds_split_on_key") if (
            self.ds_wave_handling_append_uid == "false" or self.ds_wave_handling_append_uid is False
        ) and (self.ds_write_mode == "write_multiple_files") else exclude.add("ds_split_on_key")
        include.add("ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_format") if (
            self.ds_create_hive_table_use_staging_table == "true" or self.ds_create_hive_table_use_staging_table is True
        ) else exclude.add(
            "ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_format"
        )
        include.add("ds_cleanup") if (
            self.ds_write_mode
            and "write_multiple_files" in str(self.ds_write_mode)
            or self.ds_write_mode
            and "write_single_file" in str(self.ds_write_mode)
        ) else exclude.add("ds_cleanup")
        include.add("ds_create_hive_table_hive_use_keytab") if (
            self.ds_create_hive_table_hive_kerberos == "true" or self.ds_create_hive_table_hive_kerberos is True
        ) else exclude.add("ds_create_hive_table_hive_use_keytab")
        include.add("ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_parquet_compress") if (
            self.ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_format
            == "parquet"
        ) else exclude.add("ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_parquet_compress")
        include.add("ds_wave_handling_append_uid") if (
            self.ds_write_mode
            and "write_multiple_files" in str(self.ds_write_mode)
            or self.ds_write_mode
            and "write_single_file" in str(self.ds_write_mode)
        ) else exclude.add("ds_wave_handling_append_uid")
        include.add("table_data_file_format") if (
            self.table_format
            and (
                (hasattr(self.table_format, "value") and self.table_format.value == "iceberg")
                or (self.table_format == "iceberg")
            )
        ) else exclude.add("table_data_file_format")
        include.add("time_format") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "avro" in str(self.file_format.value)
                )
                or ("avro" in str(self.file_format))
            )
            or self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "parquet" in str(self.file_format.value)
                )
                or ("parquet" in str(self.file_format))
            )
        ) else exclude.add("time_format")
        include.add("ds_file_format_parquet_target_parquet_page_size") if (
            self.ds_file_format == "parquet"
        ) else exclude.add("ds_file_format_parquet_target_parquet_page_size")
        include.add("ds_file_format_avro_target_avro_schema") if (self.ds_file_format == "avro") else exclude.add(
            "ds_file_format_avro_target_avro_schema"
        )
        include.add("ds_file_format") if (
            self.ds_write_mode
            and "write_multiple_files" in str(self.ds_write_mode)
            or self.ds_write_mode
            and "write_single_file" in str(self.ds_write_mode)
        ) else exclude.add("ds_file_format")
        include.add("partitioned") if (
            self.write_mode
            and (
                (hasattr(self.write_mode, "value") and self.write_mode.value == "write") or (self.write_mode == "write")
            )
        ) and (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            and self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
        ) else exclude.add("partitioned")
        include.add("date_format") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "avro" in str(self.file_format.value)
                )
                or ("avro" in str(self.file_format))
            )
            or self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "parquet" in str(self.file_format.value)
                )
                or ("parquet" in str(self.file_format))
            )
        ) else exclude.add("date_format")
        include.add("table_data_file_format") if (
            self.table_format
            and (
                (hasattr(self.table_format, "value") and self.table_format.value == "deltalake")
                or (self.table_format == "deltalake")
            )
        ) else exclude.add("table_data_file_format")
        include.add("timestamp_format") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "avro" in str(self.file_format.value)
                )
                or ("avro" in str(self.file_format))
            )
            or self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "parquet" in str(self.file_format.value)
                )
                or ("parquet" in str(self.file_format))
            )
        ) else exclude.add("timestamp_format")
        include.add("worksheet_name") if (
            self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value == "excel")
                or (self.file_format == "excel")
            )
        ) and (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "deltalake" not in str(self.table_format.value)
                )
                or ("deltalake" not in str(self.table_format))
            )
            or self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" not in str(self.table_format.value)
                )
                or ("iceberg" not in str(self.table_format))
            )
        ) else exclude.add("worksheet_name")
        include.add("table_data_file_compression_codec") if (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "deltalake" in str(self.table_format.value)
                )
                or ("deltalake" in str(self.table_format))
            )
            and self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" in str(self.table_format.value)
                )
                or ("iceberg" in str(self.table_format))
            )
        ) and (
            self.table_data_file_format
            and (
                (hasattr(self.table_data_file_format, "value") and self.table_data_file_format.value)
                or (self.table_data_file_format)
            )
        ) and (self.endpoint_folder) and (
            self.write_mode
            and (
                (hasattr(self.write_mode, "value") and self.write_mode.value == "write") or (self.write_mode == "write")
            )
        ) else exclude.add("table_data_file_compression_codec")
        include.add("partition_name_prefix") if (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "deltalake" not in str(self.table_format.value)
                )
                or ("deltalake" not in str(self.table_format))
            )
            or self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" not in str(self.table_format.value)
                )
                or ("iceberg" not in str(self.table_format))
            )
        ) else exclude.add("partition_name_prefix")
        include.add("ds_create_hive_table_create_hive_schema") if (
            self.ds_create_hive_table == "true" or self.ds_create_hive_table is True
        ) else exclude.add("ds_create_hive_table_create_hive_schema")
        include.add("ds_file_format_parquet_target_parquet_compress") if (
            self.ds_file_format == "parquet"
        ) else exclude.add("ds_file_format_parquet_target_parquet_compress")
        include.add("ds_file_format_orc_target_orc_stripe_size") if (self.ds_file_format == "orc") else exclude.add(
            "ds_file_format_orc_target_orc_stripe_size"
        )
        include.add("decimal_grouping_separator") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "avro" in str(self.file_format.value)
                )
                or ("avro" in str(self.file_format))
            )
            or self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "parquet" in str(self.file_format.value)
                )
                or ("parquet" in str(self.file_format))
            )
        ) else exclude.add("decimal_grouping_separator")
        include.add("escape_character") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
        ) else exclude.add("escape_character")
        include.add("table_data_file_compression_codec") if (
            self.table_data_file_format
            and (
                (hasattr(self.table_data_file_format, "value") and self.table_data_file_format.value == "parquet")
                or (self.table_data_file_format == "parquet")
            )
        ) else exclude.add("table_data_file_compression_codec")
        include.add("ds_file_format_delimited_syntax_header") if (
            self.ds_file_format
            and "comma-separated_value_csv" in str(self.ds_file_format)
            or self.ds_file_format
            and "delimited" in str(self.ds_file_format)
        ) else exclude.add("ds_file_format_delimited_syntax_header")
        include.add("decimal_separator") if (
            self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "avro" in str(self.file_format.value)
                )
                or ("avro" in str(self.file_format))
            )
            or self.file_format
            and (
                (hasattr(self.file_format, "value") and self.file_format.value and "csv" in str(self.file_format.value))
                or ("csv" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "delimited" in str(self.file_format.value)
                )
                or ("delimited" in str(self.file_format))
            )
            or self.file_format
            and (
                (
                    hasattr(self.file_format, "value")
                    and self.file_format.value
                    and "parquet" in str(self.file_format.value)
                )
                or ("parquet" in str(self.file_format))
            )
        ) else exclude.add("decimal_separator")
        include.add("the_data_path") if (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" in str(self.table_format.value)
                )
                or ("iceberg" in str(self.table_format))
            )
        ) else exclude.add("the_data_path")
        include.add("ds_file_format_impl_syntax_header_include_types") if (
            self.ds_file_format_impl_syntax_header == "true" or self.ds_file_format_impl_syntax_header is True
        ) else exclude.add("ds_file_format_impl_syntax_header_include_types")
        include.add("ds_create_hive_table_hive_service_principal") if (
            self.ds_create_hive_table_hive_kerberos == "true" or self.ds_create_hive_table_hive_kerberos is True
        ) else exclude.add("ds_create_hive_table_hive_service_principal")
        include.add("ds_file_format_delimited_syntax_encoding_output_bom") if (
            self.ds_file_format
            and "comma-separated_value_csv" in str(self.ds_file_format)
            or self.ds_file_format
            and "delimited" in str(self.ds_file_format)
        ) else exclude.add("ds_file_format_delimited_syntax_encoding_output_bom")
        include.add("ds_force_sequential") if (
            self.ds_wave_handling_append_uid == "false" or self.ds_wave_handling_append_uid is False
        ) and (self.ds_write_mode == "write_multiple_files") else exclude.add("ds_force_sequential")
        include.add("ds_create_hive_table_hive_table") if (
            self.ds_create_hive_table == "true" or self.ds_create_hive_table is True
        ) else exclude.add("ds_create_hive_table_hive_table")
        include.add("ds_file_format_impl_syntax_encoding_output_bom") if (
            self.ds_file_format == "implicit"
        ) else exclude.add("ds_file_format_impl_syntax_encoding_output_bom")
        include.add("ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_orc_stripe_size") if (
            self.ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_format == "orc"
        ) else exclude.add("ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_orc_stripe_size")
        include.add("codec_parquet") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "parquet")
                    or (self.file_format == "parquet")
                )
            )
            or (
                (
                    self.file_format
                    and ((hasattr(self.file_format, "value") and not self.file_format.value) or (not self.file_format))
                )
                and (re.match(r".*\.parquet$", self.file_name))
            )
        ) and (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "deltalake" not in str(self.table_format.value)
                )
                or ("deltalake" not in str(self.table_format))
            )
            or self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" not in str(self.table_format.value)
                )
                or ("iceberg" not in str(self.table_format))
            )
        ) else exclude.add("codec_parquet")
        include.add("table_data_file_format") if (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "deltalake" in str(self.table_format.value)
                )
                or ("deltalake" in str(self.table_format))
            )
            and self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" in str(self.table_format.value)
                )
                or ("iceberg" in str(self.table_format))
            )
        ) and (self.endpoint_folder) else exclude.add("table_data_file_format")
        include.add("ds_file_format_orc_target_orc_compress") if (self.ds_file_format == "orc") else exclude.add(
            "ds_file_format_orc_target_orc_compress"
        )
        include.add("codec_avro") if (
            (
                self.file_format
                and (
                    (hasattr(self.file_format, "value") and self.file_format.value == "avro")
                    or (self.file_format == "avro")
                )
            )
            or (
                (
                    self.file_format
                    and ((hasattr(self.file_format, "value") and not self.file_format.value) or (not self.file_format))
                )
                and (re.match(r".*\.avro$", self.file_name))
            )
        ) and (
            self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "deltalake" not in str(self.table_format.value)
                )
                or ("deltalake" not in str(self.table_format))
            )
            or self.table_format
            and (
                (
                    hasattr(self.table_format, "value")
                    and self.table_format.value
                    and "iceberg" not in str(self.table_format.value)
                )
                or ("iceberg" not in str(self.table_format))
            )
        ) else exclude.add("codec_avro")
        include.add("ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_orc_compress") if (
            self.ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_format == "orc"
        ) else exclude.add("ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_orc_compress")
        include.add("ds_file_format_delimited_syntax_header_include_types") if (
            self.ds_file_format_delimited_syntax_header == "true" or self.ds_file_format_delimited_syntax_header is True
        ) else exclude.add("ds_file_format_delimited_syntax_header_include_types")
        include.add("ds_split_on_key_exclude_part_string") if (
            self.ds_split_on_key == "true" or self.ds_split_on_key is True
        ) and (
            self.ds_split_on_key_key_in_filename == "true" or self.ds_split_on_key_key_in_filename is True
        ) else exclude.add("ds_split_on_key_exclude_part_string")
        include.add("table_data_file_compression_codec") if (
            self.table_data_file_format
            and (
                (hasattr(self.table_data_file_format, "value") and self.table_data_file_format.value == "orc")
                or (self.table_data_file_format == "orc")
            )
        ) else exclude.add("table_data_file_compression_codec")
        include.add("ds_file_format_parquet_target_parquet_block_size") if (
            self.ds_file_format == "parquet"
        ) else exclude.add("ds_file_format_parquet_target_parquet_block_size")
        return include, exclude

    def _get_source_props(self) -> dict:
        include, exclude = self._validate_source()
        props = {
            "buf_free_run_ronly",
            "buf_mode_ronly",
            "buffer_free_run_percent",
            "buffering_mode",
            "byte_limit",
            "cell_range",
            "collecting",
            "column_metadata_change_propagation",
            "combinability_mode",
            "current_output_link_type",
            "date_format",
            "db2_database_name",
            "db2_instance_name",
            "db2_source_connection_required",
            "db2_table_name",
            "decimal_format",
            "decimal_grouping_separator",
            "decimal_rounding_mode",
            "decimal_separator",
            "default_maximum_length_for_columns",
            "disk_write_inc_ronly",
            "disk_write_increment_bytes",
            "display_value_labels",
            "ds_exclude_files",
            "ds_file_format",
            "ds_file_format_avro_source_output_json",
            "ds_file_format_delimited_syntax_encoding",
            "ds_file_format_delimited_syntax_escape",
            "ds_file_format_delimited_syntax_field_delimiter",
            "ds_file_format_delimited_syntax_field_formats_date_format",
            "ds_file_format_delimited_syntax_field_formats_decimal_format",
            "ds_file_format_delimited_syntax_field_formats_time_format",
            "ds_file_format_delimited_syntax_field_formats_timestamp_format",
            "ds_file_format_delimited_syntax_header",
            "ds_file_format_delimited_syntax_null_value",
            "ds_file_format_delimited_syntax_quotes",
            "ds_file_format_delimited_syntax_record_def",
            "ds_file_format_delimited_syntax_record_def_record_def_source",
            "ds_file_format_delimited_syntax_record_limit",
            "ds_file_format_delimited_syntax_row_delimiter",
            "ds_file_format_impl_syntax_binary",
            "ds_file_format_impl_syntax_encoding",
            "ds_file_format_impl_syntax_header",
            "ds_file_format_impl_syntax_record_def",
            "ds_file_format_impl_syntax_record_def_record_def_source",
            "ds_file_format_impl_syntax_record_limit",
            "ds_file_format_trace_file",
            "ds_filename_column",
            "ds_filename_source",
            "ds_java_heap_size",
            "ds_read_mode",
            "ds_reject_mode",
            "ds_use_datastage",
            "ds_user_class_name",
            "enable_flow_acp_control",
            "enable_schemaless_design",
            "encoding",
            "encryption_key",
            "endpoint_folder",
            "escape_character",
            "escape_character_value",
            "exclude_missing_values",
            "execution_mode",
            "field_delimiter",
            "field_delimiter_value",
            "fields_xml_path",
            "file_format",
            "file_name",
            "first_line",
            "first_line_is_header",
            "flow_dirty",
            "generate_unicode_type_columns",
            "hide",
            "infer_as_varchar",
            "infer_null_as_empty_string",
            "infer_record_count",
            "infer_schema",
            "infer_timestamp_as_date",
            "input_count",
            "input_link_description",
            "inputcol_properties",
            "invalid_data_handling",
            "json_infer_record_count",
            "json_path",
            "key_cols_coll",
            "key_cols_coll_ordered",
            "key_cols_coll_robin",
            "key_cols_none",
            "key_cols_part",
            "labels_as_names",
            "max_mem_buf_size_ronly",
            "maximum_memory_buffer_size_bytes",
            "node_count",
            "node_number",
            "null_value",
            "output_acp_should_hide",
            "output_avro_as_json",
            "output_count",
            "output_link_description",
            "outputcol_properties",
            "part_stable_coll",
            "part_stable_ordered",
            "part_stable_roundrobin_coll",
            "part_unique_coll",
            "part_unique_ordered",
            "part_unique_roundrobin_coll",
            "partition_name_prefix",
            "partition_type",
            "perform_sort",
            "perform_sort_coll",
            "perform_sort_modulus",
            "preserve_partitioning",
            "queue_upper_bound_size_bytes",
            "queue_upper_size_ronly",
            "quote_character",
            "read_mode",
            "row_delimiter",
            "row_delimiter_value",
            "row_limit",
            "runtime_column_propagation",
            "schema_of_xml",
            "show_coll_type",
            "show_part_type",
            "show_sort_options",
            "sort_instructions",
            "sort_instructions_text",
            "sorting_key",
            "stable",
            "stage_description",
            "store_shared_strings_in_the_temporary_file",
            "table_format",
            "table_name",
            "table_namespace",
            "time_format",
            "timestamp_format",
            "timezone_format",
            "type_mapping",
            "unique",
            "use_4_digit_years_in_date_formats",
            "use_field_formats",
            "use_variable_formats",
            "worksheet_name",
            "xml_path",
        }
        required = {
            "current_output_link_type",
            "ds_filename_source",
            "enable_flow_acp_control",
            "enable_schemaless_design",
            "escape_character_value",
            "field_delimiter_value",
            "file_name",
            "output_acp_should_hide",
            "row_delimiter_value",
            "url",
            "user_principal_name",
            "username",
        }
        props = props & (self.model_fields_set | required)
        conflict = exclude & self.model_fields_set & props
        if conflict:
            conflict = list(conflict)
            if len(conflict) == 1:
                warnings.warn(f"\n\033[33mFound conflicting property {conflict[0]}\033[0m")
            else:
                warnings.warn(
                    f"\n\033[33mFound conflicting properties{', '.join(conflict[:-1])} and {conflict[-1]}\033[0m"
                )
        exclude = exclude - self.model_fields_set
        return self.model_dump(include=props - exclude, by_alias=True, exclude_none=True, warnings=False)

    def _get_target_props(self) -> dict:
        include, exclude = self._validate_target()
        props = {
            "buf_free_run_ronly",
            "buf_mode_ronly",
            "buffer_free_run_percent",
            "buffering_mode",
            "codec_avro",
            "codec_csv",
            "codec_delimited",
            "codec_orc",
            "codec_parquet",
            "collecting",
            "column_metadata_change_propagation",
            "combinability_mode",
            "create_data_asset",
            "create_or_use_existing_hive_table",
            "current_output_link_type",
            "data_asset_name",
            "date_format",
            "db2_database_name",
            "db2_instance_name",
            "db2_source_connection_required",
            "db2_table_name",
            "decimal_format",
            "decimal_grouping_separator",
            "decimal_separator",
            "disk_write_inc_ronly",
            "disk_write_increment_bytes",
            "ds_cleanup",
            "ds_create_hive_table",
            "ds_create_hive_table_additional_driver_params",
            "ds_create_hive_table_create_hive_schema",
            "ds_create_hive_table_drop_hive_table",
            "ds_create_hive_table_hive_kerberos",
            "ds_create_hive_table_hive_keytab",
            "ds_create_hive_table_hive_service_principal",
            "ds_create_hive_table_hive_table",
            "ds_create_hive_table_hive_table_type",
            "ds_create_hive_table_hive_use_keytab",
            "ds_create_hive_table_use_staging_table",
            "ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_drop_staging_table",
            "ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_orc_compress",
            "ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_orc_stripe_size",
            "ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_parquet_compress",
            "ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_format",
            "ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_location",
            "ds_create_hive_table_use_staging_table_hive_target_table_properties_hive_target_table_type",
            "ds_create_hive_table_use_staging_table_load_existing_table_max_dynamic_partitions",
            "ds_file_exists",
            "ds_file_format",
            "ds_file_format_avro_target_avro_array_keys",
            "ds_file_format_avro_target_avro_codec",
            "ds_file_format_avro_target_avro_schema",
            "ds_file_format_avro_target_input_json",
            "ds_file_format_delimited_syntax_encoding",
            "ds_file_format_delimited_syntax_encoding_output_bom",
            "ds_file_format_delimited_syntax_escape",
            "ds_file_format_delimited_syntax_field_delimiter",
            "ds_file_format_delimited_syntax_field_formats_date_format",
            "ds_file_format_delimited_syntax_field_formats_decimal_format",
            "ds_file_format_delimited_syntax_field_formats_time_format",
            "ds_file_format_delimited_syntax_field_formats_timestamp_format",
            "ds_file_format_delimited_syntax_header",
            "ds_file_format_delimited_syntax_header_include_types",
            "ds_file_format_delimited_syntax_null_value",
            "ds_file_format_delimited_syntax_quotes",
            "ds_file_format_delimited_syntax_row_delimiter",
            "ds_file_format_impl_syntax_binary",
            "ds_file_format_impl_syntax_encoding",
            "ds_file_format_impl_syntax_encoding_output_bom",
            "ds_file_format_impl_syntax_header",
            "ds_file_format_impl_syntax_header_include_types",
            "ds_file_format_orc_target_orc_buffer_size",
            "ds_file_format_orc_target_orc_compress",
            "ds_file_format_orc_target_orc_stripe_size",
            "ds_file_format_parquet_target_parquet_block_size",
            "ds_file_format_parquet_target_parquet_compress",
            "ds_file_format_parquet_target_parquet_page_size",
            "ds_filename_target",
            "ds_force_sequential",
            "ds_java_heap_size",
            "ds_max_file_size",
            "ds_split_on_key",
            "ds_split_on_key_case_sensitive",
            "ds_split_on_key_exclude_part_string",
            "ds_split_on_key_key_column",
            "ds_split_on_key_key_in_filename",
            "ds_use_datastage",
            "ds_user_class_name",
            "ds_wave_handling_append_uid",
            "ds_wave_handling_file_size_threshold",
            "ds_write_mode",
            "enable_flow_acp_control",
            "enable_schemaless_design",
            "encoding",
            "encryption_key",
            "endpoint_folder",
            "escape_character",
            "escape_character_value",
            "execution_mode",
            "field_delimiter",
            "field_delimiter_value",
            "file_format",
            "file_name",
            "first_line_is_header",
            "flow_dirty",
            "hide",
            "hive_table",
            "include_types",
            "input_count",
            "input_link_description",
            "inputcol_properties",
            "key_cols_coll",
            "key_cols_coll_ordered",
            "key_cols_coll_robin",
            "key_cols_none",
            "key_cols_part",
            "max_mem_buf_size_ronly",
            "maximum_memory_buffer_size_bytes",
            "names_as_labels",
            "node_count",
            "node_number",
            "null_value",
            "output_acp_should_hide",
            "output_count",
            "output_link_description",
            "outputcol_properties",
            "part_stable_coll",
            "part_stable_ordered",
            "part_stable_roundrobin_coll",
            "part_unique_coll",
            "part_unique_ordered",
            "part_unique_roundrobin_coll",
            "partition_name_prefix",
            "partition_type",
            "partitioned",
            "perform_sort",
            "perform_sort_coll",
            "perform_sort_modulus",
            "preserve_partitioning",
            "queue_upper_bound_size_bytes",
            "queue_upper_size_ronly",
            "quote_character",
            "quote_numeric_values",
            "row_delimiter",
            "row_delimiter_value",
            "runtime_column_propagation",
            "show_coll_type",
            "show_part_type",
            "show_sort_options",
            "sort_instructions",
            "sort_instructions_text",
            "sorting_key",
            "stable",
            "stage_description",
            "table_action",
            "table_data_file_compression_codec",
            "table_data_file_format",
            "table_format",
            "table_name",
            "table_namespace",
            "the_cache_expiration",
            "the_cache_size",
            "the_data_path",
            "the_partition_columns",
            "the_partition_paths",
            "time_format",
            "timestamp_format",
            "timezone_format",
            "unique",
            "worksheet_name",
            "write_mode",
        }
        required = {
            "current_output_link_type",
            "data_asset_name",
            "ds_create_hive_table_hive_keytab",
            "ds_create_hive_table_hive_table",
            "ds_file_format_avro_target_avro_schema",
            "ds_filename_target",
            "enable_flow_acp_control",
            "enable_schemaless_design",
            "escape_character_value",
            "field_delimiter_value",
            "file_name",
            "output_acp_should_hide",
            "row_delimiter_value",
            "url",
            "user_principal_name",
            "username",
        }
        props = props & (self.model_fields_set | required)
        conflict = exclude & self.model_fields_set & props
        if conflict:
            conflict = list(conflict)
            if len(conflict) == 1:
                warnings.warn(f"\n\033[33mFound conflicting property {conflict[0]}\033[0m")
            else:
                warnings.warn(
                    f"\n\033[33mFound conflicting properties{', '.join(conflict[:-1])} and {conflict[-1]}\033[0m"
                )
        exclude = exclude - self.model_fields_set
        return self.model_dump(include=props - exclude, by_alias=True, exclude_none=True, warnings=False)

    def _get_parameters_props(self) -> dict:
        include, exclude = self._validate_parameters()
        props = {"execution_mode", "input_count", "output_count", "preserve_partitioning"}
        required = set()
        props = props & (self.model_fields_set | required)
        conflict = exclude & self.model_fields_set & props
        if conflict:
            conflict = list(conflict)
            if len(conflict) == 1:
                warnings.warn(f"\n\033[33mFound conflicting property {conflict[0]}\033[0m")
            else:
                warnings.warn(
                    f"\n\033[33mFound conflicting properties{', '.join(conflict[:-1])} and {conflict[-1]}\033[0m"
                )
        exclude = exclude - self.model_fields_set
        return self.model_dump(include=props - exclude, by_alias=True, exclude_none=True, warnings=False)

    def _get_app_data_props(self) -> dict:
        return {
            "datastage": {
                "active": 1,
                "SupportsRef": True,
                "maxRejectOutputs": 0,
                "minRejectOutputs": 0,
                "maxReferenceInputs": 0,
                "minReferenceInputs": 0,
            }
        }

    def _get_input_ports_props(self) -> dict:
        include, exclude = self._validate_target()
        props = {"runtime_column_propagation"}
        required = set()
        props = props & (self.model_fields_set | required)
        conflict = exclude & self.model_fields_set & props
        if conflict:
            conflict = list(conflict)
            if len(conflict) == 1:
                warnings.warn(f"\n\033[33mFound conflicting property: {conflict[0]}\033[0m")
            else:
                warnings.warn(
                    f"\n\033[33mFound conflicting properties: {', '.join(conflict[:-1])} and {conflict[-1]}\033[0m"
                )
        exclude = exclude - self.model_fields_set
        return self.model_dump(include=props - exclude, by_alias=True, exclude_none=True, warnings=False)

    def _get_input_cardinality(self) -> dict:
        return {"min": 0, "max": 1}

    def _get_output_ports_props(self) -> dict:
        include, exclude = self._validate_source()
        props = {"is_reject"}
        required = set()
        props = props & (self.model_fields_set | required)
        conflict = exclude & self.model_fields_set & props
        if conflict:
            conflict = list(conflict)
            if len(conflict) == 1:
                warnings.warn(f"\n\033[33mFound conflicting property: {conflict[0]}\033[0m")
            else:
                warnings.warn(
                    f"\n\033[33mFound conflicting properties: {', '.join(conflict[:-1])} and {conflict[-1]}\033[0m"
                )
        exclude = exclude - self.model_fields_set
        return self.model_dump(include=props - exclude, by_alias=True, exclude_none=True, warnings=False)

    def _get_output_cardinality(self) -> dict:
        return {"min": 0, "max": 2}

    def _get_allowed_as_source_props(self) -> bool:
        return True

    def _get_allowed_as_target_props(self) -> bool:
        return True
