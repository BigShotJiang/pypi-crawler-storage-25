"""This module defines configuration for the Apache Cassandra for DataStage stage."""

import warnings
from ibm_watsonx_data_integration.services.datastage.models.base_stage import BaseStage
from ibm_watsonx_data_integration.services.datastage.models.connections.cassandra_datastage_connection import (
    CassandraDatastageConn,
)
from ibm_watsonx_data_integration.services.datastage.models.enums import CASSANDRA_DATASTAGE
from pydantic import Field
from typing import ClassVar


class cassandra_datastage(BaseStage):
    """Properties for the Apache Cassandra for DataStage stage."""

    op_name: ClassVar[str] = "CassandraConnectorPX"
    node_type: ClassVar[str] = "binding"
    image: ClassVar[str] = "/data-intg/flows/graphics/palette/CassandraConnectorPX.svg"
    label: ClassVar[str] = "Apache Cassandra for DataStage"
    runtime_column_propagation: bool = Field(False, alias="runtime_column_propagation")
    connection: CassandraDatastageConn = CassandraDatastageConn()
    buf_free_run_ronly: int | None = Field(50, alias="buf_free_run_ronly")
    buf_mode_ronly: CASSANDRA_DATASTAGE.BufModeRonly | None = Field(
        CASSANDRA_DATASTAGE.BufModeRonly.default, alias="buf_mode_ronly"
    )
    buffer_free_run_percent: int | None = Field(
        50,
        alias="buf_free_run",
        description=("Specifies how much of the available in-memory buffer to use before the buffer writes to disk."),
    )
    buffering_mode: CASSANDRA_DATASTAGE.BufferingMode | None = Field(
        CASSANDRA_DATASTAGE.BufferingMode.default,
        alias="buf_mode",
        description=(
            "(Default): The link takes the settings that are specified by the environment variables. This is "
            "Auto buffer unless you have changed the value of the APT_BUFFERING _POLICY environment variable.   "
            "Auto buffer: The link buffers incoming data only if necessary to prevent a dataflow deadlock "
            "situation.  Buffer: The link unconditionally buffer all incoming data.  No buffer: The link does "
            "not buffer data under any circumstances. This setting might cause deadlocks if not used carefully."
        ),
    )
    check_schema_agreement: bool | None = Field(
        True, alias="check_schema_agreement", description=("Check if schema is exactly the same on all cluster nodes")
    )
    collecting: CASSANDRA_DATASTAGE.Collecting | None = Field(
        CASSANDRA_DATASTAGE.Collecting.auto, alias="coll_type", description=("Specify the order in which data is read.")
    )
    column_metadata_change_propagation: bool | None = Field(
        None,
        alias="auto_column_propagation",
        description=("Automatically apply column metadata changes to downstream stages(See Settings in toolbar)"),
    )
    combinability_mode: CASSANDRA_DATASTAGE.CombinabilityMode | None = Field(
        CASSANDRA_DATASTAGE.CombinabilityMode.auto,
        alias="combinability",
        description=("Specify whether to combine underlying operators into a single process."),
    )
    current_output_link_type: str = Field("PRIMARY", alias="currentOutputLinkType")
    custom_type_codecs: str | None = Field(
        "",
        alias="custom_typecodecs",
        description=(
            "You can provide list of type codec classes that can be used to support your custom mappings between "
            "Cassandra and DataStage (semicolon separated list of classes)"
        ),
    )
    db2_database_name: str | None = Field(None, alias="part_client_dbname", description="Db2 Database name")
    db2_instance_name: str | None = Field(None, alias="part_client_instance", description="Db2 Instance name")
    db2_source_connection_required: str | None = Field(
        "", alias="part_dbconnection", description=("Db2 Source connection (required)")
    )
    db2_table_name: str | None = Field(None, alias="part_table", description="Db2 Table name")
    defer_credentials: bool | None = Field(
        False, alias="defer_credentials", description=("Defer specifying credentials until usage")
    )
    disk_write_inc_ronly: int | None = Field(1048576, alias="disk_write_inc_ronly")
    disk_write_increment_bytes: int | None = Field(
        1048576,
        alias="disk_write_inc",
        description=("Sets the size, in bytes, of blocks of data being moved to and from disk."),
    )
    enable_cql_statement_tracing: bool | None = Field(
        False,
        alias="tracing_statements",
        description=(
            "With tracing enabled the connector provides execution plan for each CQL statement (SELECT, INSERT, "
            "UPDATE, DELETE)"
        ),
    )
    enable_flow_acp_control: bool = Field(True, alias="enableFlowAcpControl")
    enable_quoted_identifiers: bool | None = Field(
        False,
        alias="enable_quoted_identifiers",
        description=(
            "Specifies whether or not to enclose database object names in quotes when generating CQL statements"
        ),
    )
    enable_schemaless_design: bool = Field(False, alias="enableSchemalessDesign")
    execution_mode: CASSANDRA_DATASTAGE.ExecutionMode | None = Field(
        CASSANDRA_DATASTAGE.ExecutionMode.default_par,
        alias="execmode",
        description=("Specify whether your stage runs sequentially or in parallel."),
    )
    flow_dirty: str | None = Field("false", alias="flow_dirty")
    has_reference_output: bool | None = Field(
        False, alias="has_ref_output", description=("Set to true if stage has an output reference link")
    )
    hide: bool | None = Field(False, alias="hide")
    ignore_blob_column_value_truncation_errors: bool | None = Field(
        False,
        alias="ignore_blob_truncation_errors",
        description=(
            "Should we ignore BLOB truncation errors when value's length is bigger than column field length "
            "provided in link column definition"
        ),
    )
    ignore_string_column_value_truncation_errors: bool | None = Field(
        False,
        alias="ignore_string_truncation_errors",
        description=(
            "Should we ignore string truncation errors when value's length is bigger than column field length "
            "provided in link column definition"
        ),
    )
    input_count: int | None = Field(0, alias="input_count")
    input_link_description: list | None = Field("", alias="inputLinkDescription")
    inputcol_properties: list | None = Field([], alias="inputcolProperties")
    key_cols_coll: list | None = Field([], alias="keyColsColl")
    key_cols_coll_ordered: list | None = Field([], alias="keyColsCollOrdered")
    key_cols_coll_robin: list | None = Field([], alias="keyColsCollRobin")
    key_cols_none: list | None = Field([], alias="keyColsNone")
    key_cols_part: list | None = Field([], alias="keyColsPart")
    keyspace_name: str = Field(
        None, alias="cassandra_keyspace", description=("The name of the keyspace in the target Cassandra database")
    )
    lookup_type: CASSANDRA_DATASTAGE.LookupType | None = Field(
        CASSANDRA_DATASTAGE.LookupType.empty, alias="lookup_type", description=("Lookup Type")
    )
    max_mem_buf_size_ronly: int | None = Field(3145728, alias="max_mem_buf_size_ronly")
    maximum_memory_buffer_size_bytes: int | None = Field(
        3145728,
        alias="max_mem_buf_size",
        description=(
            "Specifies the maximum amount of virtual memory, in bytes, used per buffer. The default size is "
            "3145728 (3 MB)."
        ),
    )
    modification_type: CASSANDRA_DATASTAGE.ModificationType | None = Field(
        CASSANDRA_DATASTAGE.ModificationType.insert,
        alias="mutation_type",
        description=("Chose the type of modification that you would like perform"),
    )
    output_acp_should_hide: bool = Field(True, alias="outputAcpShouldHide")
    output_count: int | None = Field(1, alias="output_count")
    output_link_description: list | None = Field("", alias="outputLinkDescription")
    outputcol_properties: list | None = Field([], alias="outputcolProperties")
    page_size: int | None = Field(
        10, alias="page_size", description=("The size of page that is used to retrive a subset of data")
    )
    parallel_read_strategy: CASSANDRA_DATASTAGE.ParallelReadStrategy | None = Field(
        CASSANDRA_DATASTAGE.ParallelReadStrategy.equal_splitter,
        alias="parallel_read_strategy",
        description=("Parallel read strategy determines how workload is distributed among players"),
    )
    part_stable_coll: bool | None = Field(False, alias="part_stable_coll")
    part_stable_ordered: bool | None = Field(False, alias="part_stable_ordered")
    part_stable_roundrobin_coll: bool | None = Field(False, alias="part_stable_roundrobin_coll")
    part_unique_coll: bool | None = Field(False, alias="part_unique_coll")
    part_unique_ordered: bool | None = Field(False, alias="part_unique_ordered")
    part_unique_roundrobin_coll: bool | None = Field(False, alias="part_unique_roundrobin_coll")
    partition_type: CASSANDRA_DATASTAGE.PartitionType | None = Field(
        CASSANDRA_DATASTAGE.PartitionType.auto, alias="part_type", description=("Partition type")
    )
    perform_sort: bool | None = Field(False, alias="perform_sort", description="Perform sort")
    perform_sort_coll: bool | None = Field(False, alias="perform_sort_coll")
    perform_sort_modulus: bool | None = Field(False, alias="perform_sort_modulus", description="Perform sort")
    pre_fetching_threshold: int | None = Field(
        2,
        alias="prefetching_threshold",
        description=("Start pre-fetching when current page contains less rows than the value set in this property"),
    )
    preserve_partitioning: CASSANDRA_DATASTAGE.PreservePartitioning | None = Field(
        CASSANDRA_DATASTAGE.PreservePartitioning.default_propagate,
        alias="preserve",
        description=("Specify whether to maintain data in current partitions."),
    )
    queue_upper_bound_size_bytes: int | None = Field(
        0,
        alias="queue_upper_size",
        description=("Specifies the maximum amount of data buffered at any time using both memory and disk."),
    )
    queue_upper_size_ronly: int | None = Field(0, alias="queue_upper_size_ronly")
    read_consistency_level: CASSANDRA_DATASTAGE.ReadConsistencyLevel | None = Field(
        CASSANDRA_DATASTAGE.ReadConsistencyLevel.quorum,
        alias="read_consistency_level",
        description=("The level of consistency used in the read or write operation"),
    )
    reconcile_tables_definitions: bool | None = Field(
        False,
        alias="reconcile_tables_definitions",
        description=(
            "Perform early comparison of the design-time schema and the external schema and issue error messages "
            "for any detected discrepancies that can result in data corruption."
        ),
    )
    runtime_column_propagation: bool | None = Field(
        None,
        alias="runtime_column_propagation",
        description=("Propagate extra columns that are not defined in the metadata through the rest of the job."),
    )
    save_null_values: bool | None = Field(
        True,
        alias="save_null_values",
        description=(
            "Should we save null values in the target table (this will create tombstones for each null value)"
        ),
    )
    show_coll_type: int | None = Field(0, alias="showCollType")
    show_part_type: int | None = Field(1, alias="showPartType")
    show_sort_options: int | None = Field(0, alias="showSortOptions")
    sort_instructions: str | None = Field("", alias="sortInstructions")
    sort_instructions_text: str | None = Field("", alias="sortInstructionsText")
    sorting_key: CASSANDRA_DATASTAGE.KeyColSelect | None = Field(
        CASSANDRA_DATASTAGE.KeyColSelect.default, alias="keyColSelect"
    )
    stable: bool | None = Field(
        None, alias="part_stable", description=("Select Stable if you want to preserve previously sorted data sets.")
    )
    stage_description: list | None = Field("", alias="stageDescription", description="Description")
    table_name: str = Field(
        None, alias="cassandra_table", description=("The name of the table in the target Cassandra database")
    )
    unique: bool | None = Field(
        None,
        alias="part_unique",
        description=(
            "Select Unique to specify that, if multiple records have identical sorting key values, only one "
            "record is retained. If stable sort is also set, the first record is retained."
        ),
    )
    use_json_encoded_map_for_a_single_row: bool | None = Field(
        False,
        alias="use_json_mapped_rows",
        description=("Enables selecting and inserting a single row as a JSON encoded map"),
    )
    use_parallel_read: bool | None = Field(
        False,
        alias="use_parallel_read",
        description=("Split reading data to all available nodes to speed up the process"),
    )
    write_consistency_level: CASSANDRA_DATASTAGE.WriteConsistencyLevel | None = Field(
        CASSANDRA_DATASTAGE.WriteConsistencyLevel.quorum,
        alias="write_consistency_level",
        description=("The level of consistency used in the read or write operation"),
    )

    def _validate_parameters(self) -> tuple[set, set]:
        include = set()
        exclude = set()

        include.add("preserve_partitioning") if (self.output_count and self.output_count > 0) else exclude.add(
            "preserve_partitioning"
        )
        return include, exclude

    def _validate_source(self) -> tuple[set, set]:
        include = set()
        exclude = set()

        include.add("reconcile_tables_definitions") if (
            not self.use_json_encoded_map_for_a_single_row
        ) else exclude.add("reconcile_tables_definitions")
        include.add("parallel_read_strategy") if (self.use_parallel_read) else exclude.add("parallel_read_strategy")
        include.add("lookup_type") if (self.has_reference_output) else exclude.add("lookup_type")
        include.add("reconcile_tables_definitions") if (
            (not self.use_json_encoded_map_for_a_single_row)
            or (self.use_json_encoded_map_for_a_single_row and "#" in str(self.use_json_encoded_map_for_a_single_row))
        ) else exclude.add("reconcile_tables_definitions")
        include.add("parallel_read_strategy") if (
            (self.use_parallel_read) or (self.use_parallel_read and "#" in str(self.use_parallel_read))
        ) else exclude.add("parallel_read_strategy")
        include.add("lookup_type") if (self.has_reference_output) else exclude.add("lookup_type")

        include.add("maximum_memory_buffer_size_bytes") if (self.buffering_mode != "nobuffer") else exclude.add(
            "maximum_memory_buffer_size_bytes"
        )
        include.add("buffer_free_run_percent") if (self.buffering_mode != "nobuffer") else exclude.add(
            "buffer_free_run_percent"
        )
        include.add("queue_upper_bound_size_bytes") if (self.buffering_mode != "nobuffer") else exclude.add(
            "queue_upper_bound_size_bytes"
        )
        include.add("disk_write_increment_bytes") if (self.buffering_mode != "nobuffer") else exclude.add(
            "disk_write_increment_bytes"
        )
        include.add("runtime_column_propagation") if (not self.enable_schemaless_design) else exclude.add(
            "runtime_column_propagation"
        )
        include.add("column_metadata_change_propagation") if (not self.output_acp_should_hide) else exclude.add(
            "column_metadata_change_propagation"
        )
        include.add("max_mem_buf_size_ronly") if (self.buf_mode_ronly != "nobuffer") else exclude.add(
            "max_mem_buf_size_ronly"
        )
        include.add("buf_free_run_ronly") if (self.buf_mode_ronly != "nobuffer") else exclude.add("buf_free_run_ronly")
        include.add("queue_upper_size_ronly") if (self.buf_mode_ronly != "nobuffer") else exclude.add(
            "queue_upper_size_ronly"
        )
        include.add("disk_write_inc_ronly") if (self.buf_mode_ronly != "nobuffer") else exclude.add(
            "disk_write_inc_ronly"
        )
        include.add("stable") if (
            (self.show_part_type)
            and (self.partition_type != "auto")
            and (self.partition_type != "db2connector")
            and (self.show_sort_options)
        ) else exclude.add("stable")
        include.add("unique") if (
            (self.show_part_type)
            and (self.partition_type != "auto")
            and (self.partition_type != "db2connector")
            and (self.show_sort_options)
        ) else exclude.add("unique")
        include.add("key_cols_part") if (
            (
                (self.show_part_type)
                and (not self.show_coll_type)
                and (self.partition_type != "auto")
                and (self.partition_type != "db2connector")
                and (self.partition_type != "modulus")
            )
            or (
                (self.show_part_type)
                and (not self.show_coll_type)
                and (self.partition_type == "modulus")
                and (self.perform_sort_modulus)
            )
        ) else exclude.add("key_cols_part")
        include.add("db2_source_connection_required") if (
            (self.partition_type == "db2part") and (self.show_part_type)
        ) else exclude.add("db2_source_connection_required")
        include.add("db2_database_name") if (
            (self.partition_type == "db2part") and (self.show_part_type)
        ) else exclude.add("db2_database_name")
        include.add("db2_instance_name") if (
            (self.partition_type == "db2part") and (self.show_part_type)
        ) else exclude.add("db2_instance_name")
        include.add("db2_table_name") if (
            (self.partition_type == "db2part") and (self.show_part_type)
        ) else exclude.add("db2_table_name")
        include.add("perform_sort") if (
            (self.show_part_type) and ((self.partition_type == "hash") or (self.partition_type == "range"))
        ) else exclude.add("perform_sort")
        include.add("perform_sort_modulus") if (
            (self.show_part_type) and (self.partition_type == "modulus")
        ) else exclude.add("perform_sort_modulus")
        include.add("sorting_key") if (
            (self.show_part_type) and (self.partition_type == "modulus") and (not self.perform_sort_modulus)
        ) else exclude.add("sorting_key")
        include.add("sort_instructions") if (
            (self.show_part_type)
            and (
                (self.partition_type == "db2part")
                or (self.partition_type == "entire")
                or (self.partition_type == "random")
                or (self.partition_type == "roundrobin")
                or (self.partition_type == "same")
            )
        ) else exclude.add("sort_instructions")
        include.add("sort_instructions_text") if (
            (self.show_part_type)
            and (
                (self.partition_type == "db2part")
                or (self.partition_type == "entire")
                or (self.partition_type == "random")
                or (self.partition_type == "roundrobin")
                or (self.partition_type == "same")
            )
        ) else exclude.add("sort_instructions_text")
        include.add("collecting") if (self.show_coll_type) else exclude.add("collecting")
        include.add("partition_type") if (self.show_part_type) else exclude.add("partition_type")
        include.add("perform_sort_coll") if (
            (
                (self.show_coll_type)
                and (
                    (self.collecting == "ordered")
                    or (self.collecting == "roundrobin_coll")
                    or (self.collecting == "sortmerge")
                )
            )
            or ((not self.show_part_type) and (not self.show_coll_type))
        ) else exclude.add("perform_sort_coll")
        include.add("key_cols_coll") if (
            (self.show_coll_type)
            and (not self.show_part_type)
            and (self.collecting != "auto")
            and ((self.collecting == "sortmerge") or (self.perform_sort_coll))
        ) else exclude.add("key_cols_coll")
        include.add("key_cols_none") if (
            (not self.show_part_type) and (not self.show_coll_type) and (self.perform_sort_coll)
        ) else exclude.add("key_cols_none")
        include.add("part_stable_coll") if (
            (self.perform_sort_coll)
            and (
                (
                    (not self.show_part_type)
                    and (self.show_coll_type)
                    and (self.collecting != "auto")
                    and (self.show_sort_options)
                )
                or ((not self.show_part_type) and (not self.show_coll_type) and (self.show_sort_options))
            )
        ) else exclude.add("part_stable_coll")
        include.add("part_unique_coll") if (
            (self.perform_sort_coll)
            and (
                (
                    (not self.show_part_type)
                    and (self.show_coll_type)
                    and (self.collecting != "auto")
                    and (self.show_sort_options)
                )
                or ((not self.show_part_type) and (not self.show_coll_type) and (self.show_sort_options))
            )
        ) else exclude.add("part_unique_coll")
        include.add("defer_credentials") if (()) else exclude.add("defer_credentials")
        include.add("lookup_type") if (
            self.has_reference_output == "true" or self.has_reference_output is True
        ) else exclude.add("lookup_type")
        include.add("parallel_read_strategy") if (
            self.use_parallel_read and "true" in str(self.use_parallel_read)
        ) else exclude.add("parallel_read_strategy")
        include.add("reconcile_tables_definitions") if (
            self.use_json_encoded_map_for_a_single_row and "false" in str(self.use_json_encoded_map_for_a_single_row)
        ) else exclude.add("reconcile_tables_definitions")
        return include, exclude

    def _validate_target(self) -> tuple[set, set]:
        include = set()
        exclude = set()

        include.add("use_json_encoded_map_for_a_single_row") if (
            self.modification_type
            and (
                (hasattr(self.modification_type, "value") and self.modification_type.value == "insert")
                or (self.modification_type == "insert")
            )
        ) else exclude.add("use_json_encoded_map_for_a_single_row")
        include.add("use_json_encoded_map_for_a_single_row") if (
            (
                self.modification_type
                and (
                    (hasattr(self.modification_type, "value") and self.modification_type.value == "insert")
                    or (self.modification_type == "insert")
                )
            )
            or (
                self.modification_type
                and (
                    (
                        hasattr(self.modification_type, "value")
                        and self.modification_type.value
                        and "#" in str(self.modification_type.value)
                    )
                    or ("#" in str(self.modification_type))
                )
            )
        ) else exclude.add("use_json_encoded_map_for_a_single_row")
        include.add("use_json_encoded_map_for_a_single_row") if (
            self.modification_type
            and (
                (
                    hasattr(self.modification_type, "value")
                    and self.modification_type.value
                    and "insert" in str(self.modification_type.value)
                )
                or ("insert" in str(self.modification_type))
            )
        ) else exclude.add("use_json_encoded_map_for_a_single_row")
        return include, exclude

    def _get_source_props(self) -> dict:
        include, exclude = self._validate_source()
        props = {
            "buf_free_run_ronly",
            "buf_mode_ronly",
            "buffer_free_run_percent",
            "buffering_mode",
            "check_schema_agreement",
            "collecting",
            "column_metadata_change_propagation",
            "combinability_mode",
            "current_output_link_type",
            "custom_type_codecs",
            "db2_database_name",
            "db2_instance_name",
            "db2_source_connection_required",
            "db2_table_name",
            "disk_write_inc_ronly",
            "disk_write_increment_bytes",
            "enable_cql_statement_tracing",
            "enable_flow_acp_control",
            "enable_quoted_identifiers",
            "enable_schemaless_design",
            "execution_mode",
            "flow_dirty",
            "has_reference_output",
            "hide",
            "ignore_blob_column_value_truncation_errors",
            "ignore_string_column_value_truncation_errors",
            "input_count",
            "input_link_description",
            "inputcol_properties",
            "key_cols_coll",
            "key_cols_coll_ordered",
            "key_cols_coll_robin",
            "key_cols_none",
            "key_cols_part",
            "keyspace_name",
            "lookup_type",
            "max_mem_buf_size_ronly",
            "maximum_memory_buffer_size_bytes",
            "output_acp_should_hide",
            "output_count",
            "output_link_description",
            "outputcol_properties",
            "page_size",
            "parallel_read_strategy",
            "part_stable_coll",
            "part_stable_ordered",
            "part_stable_roundrobin_coll",
            "part_unique_coll",
            "part_unique_ordered",
            "part_unique_roundrobin_coll",
            "partition_type",
            "perform_sort",
            "perform_sort_coll",
            "perform_sort_modulus",
            "pre_fetching_threshold",
            "preserve_partitioning",
            "queue_upper_bound_size_bytes",
            "queue_upper_size_ronly",
            "read_consistency_level",
            "reconcile_tables_definitions",
            "runtime_column_propagation",
            "show_coll_type",
            "show_part_type",
            "show_sort_options",
            "sort_instructions",
            "sort_instructions_text",
            "sorting_key",
            "stable",
            "stage_description",
            "table_name",
            "unique",
            "use_json_encoded_map_for_a_single_row",
            "use_parallel_read",
        }
        required = {
            "cluster_contact_points",
            "current_output_link_type",
            "enable_flow_acp_control",
            "enable_schemaless_design",
            "keyspace_name",
            "local_datacenter",
            "output_acp_should_hide",
            "password",
            "table_name",
            "username",
        }
        props = props & (self.model_fields_set | required)
        conflict = exclude & self.model_fields_set & props
        if conflict:
            conflict = list(conflict)
            if len(conflict) == 1:
                warnings.warn(f"\n\033[33mFound conflicting property {conflict[0]}\033[0m")
            else:
                warnings.warn(
                    f"\n\033[33mFound conflicting properties{', '.join(conflict[:-1])} and {conflict[-1]}\033[0m"
                )
        exclude = exclude - self.model_fields_set
        return self.model_dump(include=props - exclude, by_alias=True, exclude_none=True, warnings=False)

    def _get_target_props(self) -> dict:
        include, exclude = self._validate_target()
        props = {
            "buf_free_run_ronly",
            "buf_mode_ronly",
            "buffer_free_run_percent",
            "buffering_mode",
            "check_schema_agreement",
            "collecting",
            "column_metadata_change_propagation",
            "combinability_mode",
            "current_output_link_type",
            "custom_type_codecs",
            "db2_database_name",
            "db2_instance_name",
            "db2_source_connection_required",
            "db2_table_name",
            "disk_write_inc_ronly",
            "disk_write_increment_bytes",
            "enable_cql_statement_tracing",
            "enable_flow_acp_control",
            "enable_quoted_identifiers",
            "enable_schemaless_design",
            "execution_mode",
            "flow_dirty",
            "hide",
            "input_count",
            "input_link_description",
            "inputcol_properties",
            "key_cols_coll",
            "key_cols_coll_ordered",
            "key_cols_coll_robin",
            "key_cols_none",
            "key_cols_part",
            "keyspace_name",
            "max_mem_buf_size_ronly",
            "maximum_memory_buffer_size_bytes",
            "modification_type",
            "output_acp_should_hide",
            "output_count",
            "output_link_description",
            "outputcol_properties",
            "part_stable_coll",
            "part_stable_ordered",
            "part_stable_roundrobin_coll",
            "part_unique_coll",
            "part_unique_ordered",
            "part_unique_roundrobin_coll",
            "partition_type",
            "perform_sort",
            "perform_sort_coll",
            "perform_sort_modulus",
            "preserve_partitioning",
            "queue_upper_bound_size_bytes",
            "queue_upper_size_ronly",
            "reconcile_tables_definitions",
            "runtime_column_propagation",
            "save_null_values",
            "show_coll_type",
            "show_part_type",
            "show_sort_options",
            "sort_instructions",
            "sort_instructions_text",
            "sorting_key",
            "stable",
            "stage_description",
            "table_name",
            "unique",
            "use_json_encoded_map_for_a_single_row",
            "write_consistency_level",
        }
        required = {
            "cluster_contact_points",
            "current_output_link_type",
            "enable_flow_acp_control",
            "enable_schemaless_design",
            "keyspace_name",
            "local_datacenter",
            "output_acp_should_hide",
            "password",
            "table_name",
            "username",
        }
        props = props & (self.model_fields_set | required)
        conflict = exclude & self.model_fields_set & props
        if conflict:
            conflict = list(conflict)
            if len(conflict) == 1:
                warnings.warn(f"\n\033[33mFound conflicting property {conflict[0]}\033[0m")
            else:
                warnings.warn(
                    f"\n\033[33mFound conflicting properties{', '.join(conflict[:-1])} and {conflict[-1]}\033[0m"
                )
        exclude = exclude - self.model_fields_set
        return self.model_dump(include=props - exclude, by_alias=True, exclude_none=True, warnings=False)

    def _get_parameters_props(self) -> dict:
        include, exclude = self._validate_parameters()
        props = {"execution_mode", "input_count", "output_count", "preserve_partitioning"}
        required = set()
        props = props & (self.model_fields_set | required)
        conflict = exclude & self.model_fields_set & props
        if conflict:
            conflict = list(conflict)
            if len(conflict) == 1:
                warnings.warn(f"\n\033[33mFound conflicting property {conflict[0]}\033[0m")
            else:
                warnings.warn(
                    f"\n\033[33mFound conflicting properties{', '.join(conflict[:-1])} and {conflict[-1]}\033[0m"
                )
        exclude = exclude - self.model_fields_set
        return self.model_dump(include=props - exclude, by_alias=True, exclude_none=True, warnings=False)

    def _get_app_data_props(self) -> dict:
        return {
            "datastage": {
                "active": 0,
                "SupportsRef": True,
                "maxRejectOutputs": 0,
                "minRejectOutputs": 0,
                "maxReferenceInputs": 0,
                "minReferenceInputs": 0,
            }
        }

    def _get_input_ports_props(self) -> dict:
        include, exclude = self._validate_target()
        props = {"runtime_column_propagation"}
        required = set()
        props = props & (self.model_fields_set | required)
        conflict = exclude & self.model_fields_set & props
        if conflict:
            conflict = list(conflict)
            if len(conflict) == 1:
                warnings.warn(f"\n\033[33mFound conflicting property: {conflict[0]}\033[0m")
            else:
                warnings.warn(
                    f"\n\033[33mFound conflicting properties: {', '.join(conflict[:-1])} and {conflict[-1]}\033[0m"
                )
        exclude = exclude - self.model_fields_set
        return self.model_dump(include=props - exclude, by_alias=True, exclude_none=True, warnings=False)

    def _get_input_cardinality(self) -> dict:
        return {"min": 0, "max": -1}

    def _get_output_ports_props(self) -> dict:
        include, exclude = self._validate_source()
        props = set()
        required = set()
        props = props & (self.model_fields_set | required)
        conflict = exclude & self.model_fields_set & props
        if conflict:
            conflict = list(conflict)
            if len(conflict) == 1:
                warnings.warn(f"\n\033[33mFound conflicting property: {conflict[0]}\033[0m")
            else:
                warnings.warn(
                    f"\n\033[33mFound conflicting properties: {', '.join(conflict[:-1])} and {conflict[-1]}\033[0m"
                )
        exclude = exclude - self.model_fields_set
        return self.model_dump(include=props - exclude, by_alias=True, exclude_none=True, warnings=False)

    def _get_output_cardinality(self) -> dict:
        return {"min": 0, "max": -1}

    def _get_allowed_as_source_props(self) -> bool:
        return True

    def _get_allowed_as_target_props(self) -> bool:
        return True
