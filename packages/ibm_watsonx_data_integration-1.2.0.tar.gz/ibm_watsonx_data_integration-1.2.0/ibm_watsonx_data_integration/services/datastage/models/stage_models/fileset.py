"""This module defines configuration for the File set stage."""

import warnings
from ibm_watsonx_data_integration.services.datastage.models.base_stage import BaseStage
from ibm_watsonx_data_integration.services.datastage.models.enums import FILESET
from pydantic import Field
from typing import ClassVar


class fileset(BaseStage):
    """Properties for the File set stage."""

    op_name: ClassVar[str] = "PxFileSet"
    node_type: ClassVar[str] = "binding"
    image: ClassVar[str] = "/data-intg/flows/graphics/palette/PxFileSet.svg"
    label: ClassVar[str] = "File set"
    runtime_column_propagation: bool = Field(False, alias="runtime_column_propagation")
    actual_field_length: int | None = Field(
        None,
        alias="actual_length",
        description=(
            "Specifies the number of bytes skipped by the importer or filled with the null-field or specified "
            "pad character by the exporter when a field has been identified as null."
        ),
    )
    allow_all_zeros: FILESET.AllowAllZeros | None = Field(
        FILESET.AllowAllZeros.nofix_zero,
        alias="allow_all_zeros",
        description=(
            "Specifies whether or not to treat a packed decimal field containing all zeros (normally illegal) as "
            "a valid representation of zero."
        ),
    )
    allow_per_column_mapping: FILESET.AllowPerColumnMapping | None = Field(
        FILESET.AllowPerColumnMapping.false, alias="allow_column_mapping", description=("Allow per-column mapping")
    )
    allow_signed_import: FILESET.AllowSignedImport | None = Field(
        FILESET.AllowSignedImport.allow_signed_import,
        alias="allow_signed_import",
        description=("Force import both signed and unsigned values as unsigned."),
    )
    buf_free_run_ronly: int | None = Field(50, alias="buf_free_run_ronly")
    buf_mode_ronly: FILESET.BufModeRonly | None = Field(FILESET.BufModeRonly.default, alias="buf_mode_ronly")
    buffer_free_run_percent: int | None = Field(
        50,
        alias="buf_free_run",
        description=("Specifies how much of the available in-memory buffer to use before the buffer writes to disk."),
    )
    buffering_mode: FILESET.BufferingMode | None = Field(
        FILESET.BufferingMode.default,
        alias="buf_mode",
        description=(
            "(Default): The link takes the settings that are specified by the environment variables. This is "
            "Auto buffer unless you have changed the value of the APT_BUFFERING _POLICY environment variable.   "
            "Auto buffer: The link buffers incoming data only if necessary to prevent a dataflow deadlock "
            "situation.  Buffer: The link unconditionally buffer all incoming data.  No buffer: The link does "
            "not buffer data under any circumstances. This setting might cause deadlocks if not used carefully."
        ),
    )
    byte_order: FILESET.ByteOrder | None = Field(
        FILESET.ByteOrder.native_endian,
        alias="byte_order",
        description=(
            "Multiple-byte data types, except strings and raw data types, are formatted with: little-endian: the "
            "high byte on the left. big-endian: the high byte on the right. native-endian: as defined by the "
            "native format of the machine."
        ),
    )
    c_format: str | None = Field(
        "", alias="c_format", description=("Format string passed on import to sscanf() and on export to sprintf().")
    )
    character_set: FILESET.CharacterSet | None = Field(
        FILESET.CharacterSet.ascii,
        alias="charset",
        description=("Character set used when importing and exporting data."),
    )
    check_intact: FILESET.CheckIntact | None = Field(
        FILESET.CheckIntact.check_intact,
        alias="check_intact",
        description=(
            "Forces validation of fields of an intact schema during import. This may inhibit performance somewhat."
        ),
    )
    cleanup_on_failure: FILESET.CleanupOnFailure | None = Field(
        FILESET.CleanupOnFailure.false,
        alias="nocleanup",
        description=("If set true, the stage will delete any partially written data if it fails for any reason."),
    )
    collecting: FILESET.Collecting | None = Field(
        FILESET.Collecting.auto, alias="coll_type", description=("Specify the order in which data is read.")
    )
    column_metadata_change_propagation: bool | None = Field(
        None,
        alias="auto_column_propagation",
        description=("Automatically apply column metadata changes to downstream stages(See Settings in toolbar)"),
    )
    combinability_mode: FILESET.CombinabilityMode | None = Field(
        FILESET.CombinabilityMode.auto,
        alias="combinability",
        description=("Specify whether to combine underlying operators into a single process."),
    )
    create_data_asset: bool | None = Field(
        False,
        alias="registerDataAsset",
        description=(
            "If this checkbox is selected and a data asset with the file name does not already exist, a project "
            "data asset will be created. The asset will not be updated if the job is rerun."
        ),
    )
    current_output_link_type: str = Field("PRIMARY", alias="currentOutputLinkType")
    data_asset_name: str = Field(None, alias="dataAssetName", description="Data asset name")
    data_format: FILESET.DataFormat | None = Field(
        FILESET.DataFormat.text,
        alias="data_format",
        description=(
            "binary: imported/exported data is represented in binary format. text: Imported/exported data is "
            "represented as text characters."
        ),
    )
    date_format: str | None = Field(
        "",
        alias="date_format",
        description=("The string format of a date. By default, the format of the date string is %yyyy-%mm-%dd."),
    )
    date_options: FILESET.DateOption | None = Field(
        FILESET.DateOption.none, alias="dateOption", description=("Date option")
    )
    days_since: str | None = Field(
        "",
        alias="days_since",
        description=(
            "The imported/exported field stores the date as a signed integer in binary format containing the "
            "number of days since the specified date (use the form %yyyy-%mm-%dd)."
        ),
    )
    db2_database_name: str | None = Field(None, alias="part_client_dbname", description="Db2 Database name")
    db2_instance_name: str | None = Field(None, alias="part_client_instance", description="Db2 Instance name")
    db2_source_connection_required: str | None = Field(
        "", alias="part_dbconnection", description=("Db2 Source connection (required)")
    )
    db2_table_name: str | None = Field(None, alias="part_table", description="Db2 Table name")
    decimal_options: FILESET.DecimalOption | None = Field([], alias="decimalOption", description="Decimal option")
    decimal_packed: FILESET.DecimalPacked | None = Field(
        FILESET.DecimalPacked.packed,
        alias="decimal_packed",
        description=(
            "yes: field contains data in packed decimal format. no (separate): Field contains an unpacked "
            "decimal with a separate sign byte. no (zoned) => Field contains an unpacked decimal in either ASCII "
            "or EBCDIC text. no (overpunch) => Field contains an unpacked decimal with an overpunched sign byte."
        ),
    )
    decimal_packed_check: FILESET.DecimalPackedCheck | None = Field(
        FILESET.DecimalPackedCheck.check,
        alias="decimal_packed_check",
        description=("yes/no: perform/bypass the data verification process on import/export."),
    )
    decimal_packed_sign_position: FILESET.DecimalPackedSignPosition | None = Field(
        FILESET.DecimalPackedSignPosition.trailing,
        alias="decimal_packed_sign_position",
        description=("trailing: (default) the sign is in the last byte. leading => the sign is in the first byte."),
    )
    decimal_packed_signed: FILESET.DecimalPackedSigned | None = Field(
        FILESET.DecimalPackedSigned.signed,
        alias="decimal_packed_signed",
        description=(
            "yes (signed): use the sign of the source decimal on import or export. no (unsigned) => generate a "
            "sign nibble of 0xf, meaning a positive value, regardless of the imported or exported field's actual "
            "sign."
        ),
    )
    decimal_sep_value: str | None = Field(
        "", alias="decimal_sep_value", description=("Input the custom value of decimal separator")
    )
    decimal_separator: FILESET.DecimalSeparator | None = Field(
        FILESET.DecimalSeparator.period,
        alias="decimal_separator",
        description=(
            "The character used to separate the parts of a decimal number. By default, this is a period (.), but "
            "can be specified as any other single ASCII character."
        ),
    )
    delim_value: str | None = Field("", alias="delim_value", description="Input the custom value of delimiter")
    delimiter: FILESET.Delimiter | None = Field(
        FILESET.Delimiter.comma,
        alias="delim",
        description=(
            "Trailing delimiter on all fields of the record. whitespace: Import skips all standard white-space "
            "characters (space, tab, and newline) trailing a field. end: The last field in the record is "
            "composed of all remaining bytes until the end of the record. none: Fields have no delimiter. null: "
            "The delimiter is the ASCII null character. other: A single ASCII character."
        ),
    )
    delimiter_string: str | None = Field(
        "",
        alias="delim_string",
        description=(
            "Specifies one or more ASCII delimiter characters as the trailing delimiter for all fields of the "
            "record. Use backslash (\\) as an escape character to specify special characters within a string, "
            "e.g. '\\t' for TAB. Import skips the delimiter string in the source data file. On export, the "
            "trailing delimiter string is written after the final field in the data file."
        ),
    )
    disk_write_inc_ronly: int | None = Field(1048576, alias="disk_write_inc_ronly")
    disk_write_increment_bytes: int | None = Field(
        1048576,
        alias="disk_write_inc",
        description=("Sets the size, in bytes, of blocks of data being moved to and from disk."),
    )
    diskpool: str | None = Field(
        None, alias="diskpool", description=("Name of the disk pool into which to write the file set.")
    )
    enable_flow_acp_control: bool = Field(True, alias="enableFlowAcpControl")
    enable_schemaless_design: bool = Field(False, alias="enableSchemalessDesign")
    execution_mode: FILESET.ExecutionMode | None = Field(
        FILESET.ExecutionMode.default_par,
        alias="execmode",
        description=("Specify whether your stage runs sequentially or in parallel."),
    )
    export_ebcdic_as_ascii: FILESET.ExportEbcdicAsAscii | None = Field(
        FILESET.ExportEbcdicAsAscii.export_ebcdic_as_ascii,
        alias="export_ebcdic_as_ascii",
        description=("Causes a string field to be translated from EBCDIC to ASCII during export."),
    )
    field_defaults_options: FILESET.FieldOption | None = Field(
        FILESET.FieldOption.delimiter, alias="fieldOption", description=("Field defaults option")
    )
    field_max_width: int | None = Field(
        None,
        alias="max_width",
        description=("Specifies the maximum number of bytes of a text-format field; useful for numeric types."),
    )
    field_width: int | None = Field(
        None,
        alias="width",
        description=(
            "Specifies the number of bytes of an imported or exported text-format field; useful for numeric types."
        ),
    )
    file_name_column: str | None = Field(
        None,
        alias="sourceNameField",
        description=(
            "Adds a VarChar (Unicode for NLS installs) column to the output that contains the name of the file "
            "that the record is sourced from. User must add this column definition to the output columns to "
            "prevent it from being dropped if runtime column propagation is unchecked."
        ),
    )
    file_prefix: str | None = Field(None, alias="filePrefix")
    file_set: str = Field(None, alias="fileset", description="Name of the control file for the file set, suffix .fs")
    file_set_schema_policy: FILESET.OmitSchemaWriteSchema | None = Field(
        FILESET.OmitSchemaWriteSchema.writeSchema,
        alias="omitSchema-writeSchema",
        description=("Whether the schema should be written to the file set or omitted."),
    )
    file_set_update_policy: FILESET.CreateReplaceDiscardRecordsDiscardSchemaAndRecords | None = Field(
        FILESET.CreateReplaceDiscardRecordsDiscardSchemaAndRecords.replace,
        alias="create-replace-discard_records-discard_schema_and_records",
        description=("Action to be taken if the file set you are writing to already exists."),
    )
    file_suffix: str | None = Field(
        None, alias="suffix", description=("Suffix for the name of the file set components. Omitted by default.")
    )
    fill_char: FILESET.FillChar | None = Field(
        FILESET.FillChar.null,
        alias="fill",
        description=(
            "Byte value to fill in any gaps in an exported record caused by field positioning properties. Valid "
            "only for export. By default, the fill value is the null byte (0); it may be an integer between 0 "
            "and 255, or a single-character value."
        ),
    )
    fill_char_value: str | None = Field("", alias="fill_char_value", description="Input the custom value of fill char")
    filter: str | None = Field(
        None,
        alias="filter",
        description=("Name and arguments of a filter program through which the data is passed after being read."),
    )
    final_delim_value: str | None = Field(
        "", alias="final_delim_value", description=("Input the custom value of final delimiter")
    )
    final_delimiter: FILESET.FinalDelimiter | None = Field(
        FILESET.FinalDelimiter.end,
        alias="final_delim",
        description=(
            "Specifies a delimiter for the last field of the record. whitespace: Import skips all standard "
            "white-space characters (space, tab, and newline) trailing a field. end: The last field in the "
            "record is composed of all remaining bytes until the end of the record. none: Fields have no "
            "delimiter. null: The delimiter is the ASCII null character. other: A single ASCII character."
        ),
    )
    final_delimiter_string: str | None = Field(
        "",
        alias="final_delim_string",
        description=(
            "Specifies one or more ASCII delimiter characters as the trailing delimiter for the last field of "
            "the record. Use backslash (\\) as an escape character to specify special characters within a "
            "string, e.g. '\\t' for TAB. Import skips the delimiter string in the source data file. On export, "
            "the trailing delimiter string is written after the final field in the data file."
        ),
    )
    flow_dirty: str | None = Field("false", alias="flow_dirty")
    general_options: FILESET.GeneralOption | None = Field([], alias="generalOption", description="General option")
    hide: bool | None = Field(False, alias="hide")
    import_ascii_as_ebcdic: FILESET.ImportAsciiAsEbcdic | None = Field(
        FILESET.ImportAsciiAsEbcdic.import_ascii_as_ebcdic,
        alias="import_ascii_as_ebcdic",
        description=("Causes a string field to be translated from ASCII to EBCDIC during import."),
    )
    in_format: str | None = Field(
        "",
        alias="in_format",
        description=("Format string passed on import to the sscanf() routine to perform a numeric conversion."),
    )
    input_count: int | None = Field(0, alias="input_count")
    input_link_description: list | None = Field("", alias="inputLinkDescription")
    inputcol_properties: list | None = Field([], alias="inputcolProperties")
    intact: str | None = Field(
        "",
        alias="intact",
        description=(
            "Defines a partial record schema, which allows you to define only those fields of interest in your "
            "data. You may enter an optional identifier for the intact schema."
        ),
    )
    is_julian: FILESET.IsJulian | None = Field(
        FILESET.IsJulian.julian,
        alias="is_julian",
        description=(
            "The imported/exported field represents the date as a binary numeric value denoting the Julian day "
            "(the number of days from 4713 BCE January 1, 12:00 hours GMT)."
        ),
    )
    is_midnight_seconds: FILESET.IsMidnightSeconds | None = Field(
        FILESET.IsMidnightSeconds.midnight_seconds,
        alias="is_midnight_seconds",
        description=(
            "Time is represented as a binary 32-bit integer containing the number of seconds elapsed from the "
            "previous midnight."
        ),
    )
    keep_file_partitions: FILESET.KeepPartitions | None = Field(
        FILESET.KeepPartitions.false,
        alias="keepPartitions",
        description=("Set True to partition the read data set according to the organization of the input file(s)."),
    )
    key_cols_coll: list | None = Field([], alias="keyColsColl")
    key_cols_coll_ordered: list | None = Field([], alias="keyColsCollOrdered")
    key_cols_coll_robin: list | None = Field([], alias="keyColsCollRobin")
    key_cols_none: list | None = Field([], alias="keyColsNone")
    key_cols_part: list | None = Field([], alias="keyColsPart")
    map_name: FILESET.MapName | None = Field(FILESET.MapName.UTF_8, alias="nls_map_name", description="Map name")
    max_mem_buf_size_ronly: int | None = Field(3145728, alias="max_mem_buf_size_ronly")
    maximum_file_size: str = Field(None, alias="maxFileSize", description="Maximum file size in megabytes.")
    maximum_memory_buffer_size_bytes: int | None = Field(
        3145728,
        alias="max_mem_buf_size",
        description=(
            "Specifies the maximum amount of virtual memory, in bytes, used per buffer. The default size is "
            "3145728 (3 MB)."
        ),
    )
    null_field_length: int | None = Field(
        None,
        alias="null_length",
        description=("Specifies the value of the length prefix of a variable-length field that contains a null."),
    )
    null_field_sep_value: str | None = Field(
        "", alias="null_field_sep_value", description=("Input the custom value of null field value separator")
    )
    null_field_value: str | None = Field(
        "NULL",
        alias="null_field",
        description=(
            "On import, the value given to a field containing a null. On export, the value given to an exported "
            "field if the source field is set to null. May be a number, string, or C-style literal escape "
            "character, such as \\123 or \\xAB, if you want to use a non-printable byte value."
        ),
    )
    null_field_value_separator: FILESET.NullFieldValueSeparator | None = Field(
        FILESET.NullFieldValueSeparator.comma,
        alias="null_field_sep",
        description=(
            "Allows you to specify more than one value that can represent a null field on import. If set, "
            "indicates that there are multiple entries in the null field value property, separated by this "
            "character. If omitted, there is only one value that represents a null field."
        ),
    )
    numeric_options: FILESET.NumericOption | None = Field([], alias="numericOption", description="Numeric option")
    out_format: str | None = Field(
        "",
        alias="out_format",
        description=(
            "Format string passed on export to the sprintf() routine to control numeric to string conversion."
        ),
    )
    output_acp_should_hide: bool = Field(True, alias="outputAcpShouldHide")
    output_count: int | None = Field(0, alias="output_count")
    output_link_description: list | None = Field("", alias="outputLinkDescription")
    outputcol_properties: list | None = Field([], alias="outputcolProperties")
    pad_char: FILESET.PadChar | None = Field(
        FILESET.PadChar.false_,
        alias="padchar",
        description=(
            "Pad character used when strings or numeric values are exported to an external string "
            "representation. Ignored on import. null: use ASCII null character."
        ),
    )
    padchar_value: str | None = Field("", alias="padchar_value", description="Input the custom value of pad char")
    part_stable_coll: bool | None = Field(False, alias="part_stable_coll")
    part_stable_ordered: bool | None = Field(False, alias="part_stable_ordered")
    part_stable_roundrobin_coll: bool | None = Field(False, alias="part_stable_roundrobin_coll")
    part_unique_coll: bool | None = Field(False, alias="part_unique_coll")
    part_unique_ordered: bool | None = Field(False, alias="part_unique_ordered")
    part_unique_roundrobin_coll: bool | None = Field(False, alias="part_unique_roundrobin_coll")
    partition_type: FILESET.PartitionType | None = Field(
        FILESET.PartitionType.auto, alias="part_type", description=("Partition type")
    )
    perform_sort: bool | None = Field(False, alias="perform_sort", description="Perform sort")
    perform_sort_coll: bool | None = Field(False, alias="perform_sort_coll")
    perform_sort_modulus: bool | None = Field(False, alias="perform_sort_modulus", description="Perform sort")
    precision: int | None = Field(
        None,
        alias="precision",
        description=(
            "On import, specifies the precision of a source packed decimal. On export, specifies the precision "
            "of a destination string when a decimal is exported in text format."
        ),
    )
    prefix_bytes: FILESET.PrefixBytes | None = Field(
        FILESET.PrefixBytes.one,
        alias="prefix",
        description=(
            "Prefix for the name of the file set components. Default: export.username, where username is your login."
        ),
    )
    preserve_partitioning: FILESET.PreservePartitioning | None = Field(
        FILESET.PreservePartitioning.default_clear,
        alias="preserve",
        description=("Specify whether to maintain data in current partitions."),
    )
    print_field: FILESET.PrintField | None = Field(
        FILESET.PrintField.print_field,
        alias="print_field",
        description=("Import writes a message for each imported field: Importing 'fieldname': 'value'"),
    )
    queue_upper_bound_size_bytes: int | None = Field(
        0,
        alias="queue_upper_size",
        description=("Specifies the maximum amount of data buffered at any time using both memory and disk."),
    )
    queue_upper_size_ronly: int | None = Field(0, alias="queue_upper_size_ronly")
    quote: FILESET.Quote | None = Field(
        FILESET.Quote.double,
        alias="quote",
        description=(
            "Variable-length fields contained within single or double quotes, another character or pair of "
            "characters; or explicitly not quoted."
        ),
    )
    quote_value: str | None = Field("", alias="quote_value", description="Input the custom value of quote")
    record_delim_value: str | None = Field(
        "", alias="record_delim_value", description=("Input the custom value of record delimiter")
    )
    record_delimiter: FILESET.RecordDelimiter | None = Field(
        FILESET.RecordDelimiter.newline,
        alias="record_delim",
        description=(
            "Records terminated by a trailing delimiter character. Import skips the delimiter; export writes the "
            "delimiter after each record. By default, the record delimiter is the UNIX newline character. For "
            "fixed-width files with no explicit record delimiter, remove this property altogether."
        ),
    )
    record_delimiter_string: str | None = Field(
        "",
        alias="record_delim_string",
        description=(
            "Specifies ASCII characters to delimit a record. Pick 'DOS format' to get CR/LF delimiters; Unix "
            "format is best specified using 'Record delimiter=UNIX newline', since it is only a single character."
        ),
    )
    record_len_value: int | None = Field(
        0, alias="record_len_value", description=("Input the custom value of record length")
    )
    record_length: FILESET.RecordLength | None = Field(
        FILESET.RecordLength.fixed,
        alias="record_length",
        description=(
            "Fixed-length records of a specified length (including any record delimiter), or, if the keyword "
            "'fixed' is used, must contain only fixed-length columns so that the record length can be calculated."
        ),
    )
    record_level_options: FILESET.RecLevelOption | None = Field(
        [], alias="recLevelOption", description=("Record level option")
    )
    record_prefix: FILESET.RecordPrefix | None = Field(
        FILESET.RecordPrefix.one,
        alias="record_prefix",
        description=("Variable-length records prefixed by length prefix of 1, 2, or 4 bytes.  Default is 1 byte."),
    )
    record_type: FILESET.RecordType | None = Field(
        FILESET.RecordType.type_implicit,
        alias="record_format",
        description=(
            "implicit: import/export data as a stream with no explicit record boundaries. varying => import data "
            "using one of the IBM blocked or spanned formats."
        ),
    )
    reject_mode: FILESET.RejectMode | None = Field(
        FILESET.RejectMode.cont,
        alias="rejects",
        description=(
            "Continue to simply discard any rejected rows; Fail to stop if any row is rejected; Output to send "
            "rejected rows down a reject link."
        ),
    )
    reject_reason_column: str | None = Field(
        None,
        alias="rejectReasonField",
        description=(
            "Adds a column with the given name to the reject link. At runtime this column will contain messages "
            "produced by the failed rows."
        ),
    )
    report_progress: FILESET.ReportProgress | None = Field(
        FILESET.ReportProgress.yes,
        alias="reportProgress",
        description=("Enable or disable logging of a progress report at intervals."),
    )
    rounding: FILESET.Rounding | None = Field(
        FILESET.Rounding.trunc_zero,
        alias="round",
        description=(
            "How to round the source field to fit into the destination decimal when importing to a decimal, or "
            "how to round a source decimal when exporting a decimal. up (ceiling): truncate source field toward "
            "positive infinity. down (floor): truncate source field toward negative infinity. nearest value: "
            "Round the source field toward the nearest representable value. truncate towards zero: (Default) "
            "Discard fractional digits to the right of the right-most fractional digit supported by the "
            "destination, regardless of sign."
        ),
    )
    row_number_column: str | None = Field(
        None,
        alias="recordNumberField",
        description=(
            "Adds an unsigned BigInt column with the specified name to the output that contains the row number. "
            "User must add this column definition to the output columns to prevent it from being dropped if "
            "runtime column propagation is unchecked."
        ),
    )
    runtime_column_propagation: bool | None = Field(
        None,
        alias="runtime_column_propagation",
        description=("Propagate extra columns that are not defined in the metadata through the rest of the job."),
    )
    scale: int | None = Field(
        None,
        alias="scale",
        description=(
            "On import, specifies how to round the source field to fit into the destination decimal when the "
            "source field is imported to a decimal. On export, specifies how to round a source decimal when its "
            "precision and scale are greater than those of the destination."
        ),
    )
    schema_file: str | None = Field(
        None,
        alias="schemafile",
        description=(
            "Name of a file containing a schema for the data. Setting this property will override any settings "
            "on the Format & Columns tabs."
        ),
    )
    show_coll_type: int | None = Field(0, alias="showCollType")
    show_part_type: int | None = Field(1, alias="showPartType")
    show_sort_options: int | None = Field(0, alias="showSortOptions")
    single_file_per_partition: FILESET.SingleFilePerPartition | None = Field(
        FILESET.SingleFilePerPartition.false,
        alias="singleFilePerPartition",
        description=("True to specify that one file is written for each partition."),
    )
    sort_instructions: str | None = Field("", alias="sortInstructions")
    sort_instructions_text: str | None = Field("", alias="sortInstructionsText")
    sorting_key: FILESET.KeyColSelect | None = Field(FILESET.KeyColSelect.default, alias="keyColSelect")
    stable: bool | None = Field(
        None, alias="part_stable", description=("Select Stable if you want to preserve previously sorted data sets.")
    )
    stage_description: list | None = Field("", alias="stageDescription", description="Description")
    string_options: FILESET.StringOption | None = Field([], alias="stringOption", description="String option")
    strip_bom: FILESET.StripBom | None = Field(
        FILESET.StripBom.false,
        alias="stripbom",
        description=("If set true, the UTF-16 Endianess Byte Order Mark will be dropped."),
    )
    time_format: str | None = Field(
        "",
        alias="time_format",
        description=(
            "Format of a field representing a time as a string. By default, the format of the time string is "
            "%hh:%mm:%ss."
        ),
    )
    time_options: FILESET.TimeOption | None = Field(
        FILESET.TimeOption.none, alias="timeOption", description=("Time option")
    )
    timestamp_format: str | None = Field(
        "",
        alias="timestamp_format",
        description=(
            "Format of a field representing a timestamp as a string. By default, the format of the timestamp "
            "string is %yyyy-%mm-%dd %hh:%mm:%ss."
        ),
    )
    timestamp_options: FILESET.TimestampOption | None = Field(
        FILESET.TimestampOption.none, alias="timestampOption", description=("Timestamp option")
    )
    unique: bool | None = Field(
        None,
        alias="part_unique",
        description=(
            "Select Unique to specify that, if multiple records have identical sorting key values, only one "
            "record is retained. If stable sort is also set, the first record is retained."
        ),
    )
    use_schema_defined_in_file_set: FILESET.UseSchemaDefinedInFileSet | None = Field(
        FILESET.UseSchemaDefinedInFileSet.true,
        alias="schemafileset",
        description=(
            "When set to true this property will override any settings on the Format & Columns tabs by using "
            "what is saved in the file set itself."
        ),
    )
    vector_prefix: FILESET.VectorPrefix | None = Field(
        FILESET.VectorPrefix.one,
        alias="vector_prefix",
        description=("Specifies 1-, 2-, or 4-byte prefix containing the number of elements in the vector."),
    )
    whether_check_intact: bool | None = Field(False, alias="check_intact_flag", description="Whether check intact")
    whether_specify_null_field_value_separator: bool | None = Field(
        False, alias="null_field_sep_flag", description=("Whether specify null field value separator")
    )

    def _validate_target(self) -> tuple[set, set]:
        include = set()
        exclude = set()

        include.add("diskpool") if (()) else exclude.add("diskpool")
        include.add("schema_file") if (()) else exclude.add("schema_file")
        include.add("maximum_file_size") if (()) else exclude.add("maximum_file_size")
        include.add("file_suffix") if (()) else exclude.add("file_suffix")

        include.add("file_name_column") if (()) else exclude.add("file_name_column")
        include.add("filter") if (()) else exclude.add("filter")
        include.add("reject_reason_column") if (()) else exclude.add("reject_reason_column")
        include.add("row_number_column") if (()) else exclude.add("row_number_column")
        include.add("strip_bom") if (()) else exclude.add("strip_bom")
        include.add("file_prefix") if (()) else exclude.add("file_prefix")
        include.add("preserve_partitioning") if (self.output_count and self.output_count > 0) else exclude.add(
            "preserve_partitioning"
        )
        include.add("data_asset_name") if (self.create_data_asset) else exclude.add("data_asset_name")
        include.add("maximum_memory_buffer_size_bytes") if (self.buffering_mode != "nobuffer") else exclude.add(
            "maximum_memory_buffer_size_bytes"
        )
        include.add("buffer_free_run_percent") if (self.buffering_mode != "nobuffer") else exclude.add(
            "buffer_free_run_percent"
        )
        include.add("queue_upper_bound_size_bytes") if (self.buffering_mode != "nobuffer") else exclude.add(
            "queue_upper_bound_size_bytes"
        )
        include.add("disk_write_increment_bytes") if (self.buffering_mode != "nobuffer") else exclude.add(
            "disk_write_increment_bytes"
        )
        include.add("runtime_column_propagation") if (not self.enable_schemaless_design) else exclude.add(
            "runtime_column_propagation"
        )
        include.add("column_metadata_change_propagation") if (not self.output_acp_should_hide) else exclude.add(
            "column_metadata_change_propagation"
        )
        include.add("max_mem_buf_size_ronly") if (self.buf_mode_ronly != "nobuffer") else exclude.add(
            "max_mem_buf_size_ronly"
        )
        include.add("buf_free_run_ronly") if (self.buf_mode_ronly != "nobuffer") else exclude.add("buf_free_run_ronly")
        include.add("queue_upper_size_ronly") if (self.buf_mode_ronly != "nobuffer") else exclude.add(
            "queue_upper_size_ronly"
        )
        include.add("disk_write_inc_ronly") if (self.buf_mode_ronly != "nobuffer") else exclude.add(
            "disk_write_inc_ronly"
        )
        include.add("stable") if (
            (self.show_part_type)
            and (self.partition_type != "auto")
            and (self.partition_type != "db2connector")
            and (self.show_sort_options)
        ) else exclude.add("stable")
        include.add("unique") if (
            (self.show_part_type)
            and (self.partition_type != "auto")
            and (self.partition_type != "db2connector")
            and (self.show_sort_options)
        ) else exclude.add("unique")
        include.add("key_cols_part") if (
            (
                (self.show_part_type)
                and (not self.show_coll_type)
                and (self.partition_type != "auto")
                and (self.partition_type != "db2connector")
                and (self.partition_type != "modulus")
            )
            or (
                (self.show_part_type)
                and (not self.show_coll_type)
                and (self.partition_type == "modulus")
                and (self.perform_sort_modulus)
            )
        ) else exclude.add("key_cols_part")
        include.add("db2_source_connection_required") if (
            (self.partition_type == "db2part") and (self.show_part_type)
        ) else exclude.add("db2_source_connection_required")
        include.add("db2_database_name") if (
            (self.partition_type == "db2part") and (self.show_part_type)
        ) else exclude.add("db2_database_name")
        include.add("db2_instance_name") if (
            (self.partition_type == "db2part") and (self.show_part_type)
        ) else exclude.add("db2_instance_name")
        include.add("db2_table_name") if (
            (self.partition_type == "db2part") and (self.show_part_type)
        ) else exclude.add("db2_table_name")
        include.add("perform_sort") if (
            (self.show_part_type) and ((self.partition_type == "hash") or (self.partition_type == "range"))
        ) else exclude.add("perform_sort")
        include.add("perform_sort_modulus") if (
            (self.show_part_type) and (self.partition_type == "modulus")
        ) else exclude.add("perform_sort_modulus")
        include.add("sorting_key") if (
            (self.show_part_type) and (self.partition_type == "modulus") and (not self.perform_sort_modulus)
        ) else exclude.add("sorting_key")
        include.add("sort_instructions") if (
            (self.show_part_type)
            and (
                (self.partition_type == "db2part")
                or (self.partition_type == "entire")
                or (self.partition_type == "random")
                or (self.partition_type == "roundrobin")
                or (self.partition_type == "same")
            )
        ) else exclude.add("sort_instructions")
        include.add("sort_instructions_text") if (
            (self.show_part_type)
            and (
                (self.partition_type == "db2part")
                or (self.partition_type == "entire")
                or (self.partition_type == "random")
                or (self.partition_type == "roundrobin")
                or (self.partition_type == "same")
            )
        ) else exclude.add("sort_instructions_text")
        include.add("collecting") if (self.show_coll_type) else exclude.add("collecting")
        include.add("partition_type") if (self.show_part_type) else exclude.add("partition_type")
        include.add("perform_sort_coll") if (
            (
                (self.show_coll_type)
                and (
                    (self.collecting == "ordered")
                    or (self.collecting == "roundrobin_coll")
                    or (self.collecting == "sortmerge")
                )
            )
            or ((not self.show_part_type) and (not self.show_coll_type))
        ) else exclude.add("perform_sort_coll")
        include.add("key_cols_coll") if (
            (self.show_coll_type)
            and (not self.show_part_type)
            and (self.collecting != "auto")
            and ((self.collecting == "sortmerge") or (self.perform_sort_coll))
        ) else exclude.add("key_cols_coll")
        include.add("key_cols_none") if (
            (not self.show_part_type) and (not self.show_coll_type) and (self.perform_sort_coll)
        ) else exclude.add("key_cols_none")
        include.add("part_stable_coll") if (
            (self.perform_sort_coll)
            and (
                (
                    (not self.show_part_type)
                    and (self.show_coll_type)
                    and (self.collecting != "auto")
                    and (self.show_sort_options)
                )
                or ((not self.show_part_type) and (not self.show_coll_type) and (self.show_sort_options))
            )
        ) else exclude.add("part_stable_coll")
        include.add("part_unique_coll") if (
            (self.perform_sort_coll)
            and (
                (
                    (not self.show_part_type)
                    and (self.show_coll_type)
                    and (self.collecting != "auto")
                    and (self.show_sort_options)
                )
                or ((not self.show_part_type) and (not self.show_coll_type) and (self.show_sort_options))
            )
        ) else exclude.add("part_unique_coll")
        include.add("final_delimiter") if (
            self.record_level_options and "final_delimiter" in str(self.record_level_options)
        ) else exclude.add("final_delimiter")
        include.add("final_delim_value") if (
            (self.record_level_options and "final_delimiter" in str(self.record_level_options))
            and (self.final_delimiter == " ")
        ) else exclude.add("final_delim_value")
        include.add("fill_char") if (
            self.record_level_options and "fill" in str(self.record_level_options)
        ) else exclude.add("fill_char")
        include.add("fill_char_value") if (
            (self.record_level_options and "fill" in str(self.record_level_options)) and (self.fill_char == -1)
        ) else exclude.add("fill_char_value")
        include.add("final_delimiter_string") if (
            self.record_level_options and "final_delim_string" in str(self.record_level_options)
        ) else exclude.add("final_delimiter_string")
        include.add("intact") if (
            self.record_level_options and "intact" in str(self.record_level_options)
        ) else exclude.add("intact")
        include.add("whether_check_intact") if (
            self.record_level_options and "intact" in str(self.record_level_options)
        ) else exclude.add("whether_check_intact")
        include.add("check_intact") if (
            (self.whether_check_intact) and (self.record_level_options and "intact" in str(self.record_level_options))
        ) else exclude.add("check_intact")
        include.add("record_delimiter") if (
            self.record_level_options and "record_delimiter" in str(self.record_level_options)
        ) else exclude.add("record_delimiter")
        include.add("record_delim_value") if (
            (self.record_level_options and "record_delimiter" in str(self.record_level_options))
            and (self.record_delimiter == " ")
        ) else exclude.add("record_delim_value")
        include.add("record_delimiter_string") if (
            self.record_level_options and "record_delim_string" in str(self.record_level_options)
        ) else exclude.add("record_delimiter_string")
        include.add("record_length") if (
            self.record_level_options and "record_length" in str(self.record_level_options)
        ) else exclude.add("record_length")
        include.add("record_len_value") if (
            (self.record_level_options and "record_length" in str(self.record_level_options))
            and (self.record_length == " ")
        ) else exclude.add("record_len_value")
        include.add("record_prefix") if (
            self.record_level_options and "record_prefix" in str(self.record_level_options)
        ) else exclude.add("record_prefix")
        include.add("record_type") if (
            self.record_level_options and "record_format" in str(self.record_level_options)
        ) else exclude.add("record_type")
        include.add("delimiter") if (
            self.field_defaults_options and "delimiter" in str(self.field_defaults_options)
        ) else exclude.add("delimiter")
        include.add("delim_value") if (
            (self.field_defaults_options and "delimiter" in str(self.field_defaults_options))
            and (self.delimiter == " ")
        ) else exclude.add("delim_value")
        include.add("quote") if (
            self.field_defaults_options and "quote" in str(self.field_defaults_options)
        ) else exclude.add("quote")
        include.add("quote_value") if (
            (self.field_defaults_options and "quote" in str(self.field_defaults_options)) and (self.quote == " ")
        ) else exclude.add("quote_value")
        include.add("actual_field_length") if (
            self.field_defaults_options and "actual_length" in str(self.field_defaults_options)
        ) else exclude.add("actual_field_length")
        include.add("delimiter_string") if (
            self.field_defaults_options and "delim_string" in str(self.field_defaults_options)
        ) else exclude.add("delimiter_string")
        include.add("null_field_length") if (
            self.field_defaults_options and "null_length" in str(self.field_defaults_options)
        ) else exclude.add("null_field_length")
        include.add("null_field_value") if (
            self.field_defaults_options and "null_field" in str(self.field_defaults_options)
        ) else exclude.add("null_field_value")
        include.add("whether_specify_null_field_value_separator") if (
            self.field_defaults_options and "null_field" in str(self.field_defaults_options)
        ) else exclude.add("whether_specify_null_field_value_separator")
        include.add("null_field_value_separator") if (
            (self.whether_specify_null_field_value_separator)
            and (self.field_defaults_options and "null_field" in str(self.field_defaults_options))
        ) else exclude.add("null_field_value_separator")
        include.add("null_field_sep_value") if (
            (self.field_defaults_options and "null_field" in str(self.field_defaults_options))
            and (self.whether_specify_null_field_value_separator)
            and (self.null_field_value_separator == " ")
        ) else exclude.add("null_field_sep_value")
        include.add("prefix_bytes") if (
            self.field_defaults_options and "prefix_bytes" in str(self.field_defaults_options)
        ) else exclude.add("prefix_bytes")
        include.add("print_field") if (
            self.field_defaults_options and "print_field" in str(self.field_defaults_options)
        ) else exclude.add("print_field")
        include.add("vector_prefix") if (
            self.field_defaults_options and "vector_prefix" in str(self.field_defaults_options)
        ) else exclude.add("vector_prefix")
        include.add("byte_order") if (
            self.general_options and "byte_order" in str(self.general_options)
        ) else exclude.add("byte_order")
        include.add("character_set") if (
            self.general_options and "charset" in str(self.general_options)
        ) else exclude.add("character_set")
        include.add("data_format") if (
            self.general_options and "data_format" in str(self.general_options)
        ) else exclude.add("data_format")
        include.add("field_max_width") if (
            self.general_options and "max_width" in str(self.general_options)
        ) else exclude.add("field_max_width")
        include.add("field_width") if (
            self.general_options and "field_width" in str(self.general_options)
        ) else exclude.add("field_width")
        include.add("pad_char") if (self.general_options and "padchar" in str(self.general_options)) else exclude.add(
            "pad_char"
        )
        include.add("padchar_value") if (
            (self.general_options and "padchar" in str(self.general_options)) and (self.pad_char == " ")
        ) else exclude.add("padchar_value")
        include.add("export_ebcdic_as_ascii") if (
            self.string_options and "export_ebcdic_as_ascii" in str(self.string_options)
        ) else exclude.add("export_ebcdic_as_ascii")
        include.add("import_ascii_as_ebcdic") if (
            self.string_options and "import_ascii_as_ebcdic" in str(self.string_options)
        ) else exclude.add("import_ascii_as_ebcdic")
        include.add("allow_all_zeros") if (
            self.decimal_options and "allow_all_zeros" in str(self.decimal_options)
        ) else exclude.add("allow_all_zeros")
        include.add("decimal_separator") if (
            self.decimal_options and "decimal_separator" in str(self.decimal_options)
        ) else exclude.add("decimal_separator")
        include.add("decimal_sep_value") if (
            (self.decimal_options and "decimal_separator" in str(self.decimal_options))
            and (self.decimal_separator == " ")
        ) else exclude.add("decimal_sep_value")
        include.add("decimal_packed") if (
            self.decimal_options and "decimal_packed" in str(self.decimal_options)
        ) else exclude.add("decimal_packed")
        include.add("precision") if (
            self.decimal_options and "precision" in str(self.decimal_options)
        ) else exclude.add("precision")
        include.add("rounding") if (self.decimal_options and "round" in str(self.decimal_options)) else exclude.add(
            "rounding"
        )
        include.add("scale") if (self.decimal_options and "scale" in str(self.decimal_options)) else exclude.add(
            "scale"
        )
        include.add("decimal_packed_check") if (
            (self.decimal_options and "decimal_packed" in str(self.decimal_options))
            and (self.decimal_packed == "packed")
        ) else exclude.add("decimal_packed_check")
        include.add("decimal_packed_sign_position") if (
            (self.decimal_options and "decimal_packed" in str(self.decimal_options))
            and (self.decimal_packed != "packed")
        ) else exclude.add("decimal_packed_sign_position")
        include.add("decimal_packed_signed") if (
            (self.decimal_options and "decimal_packed" in str(self.decimal_options))
            and ((self.decimal_packed == "packed") or (self.decimal_packed == "zoned"))
        ) else exclude.add("decimal_packed_signed")
        include.add("allow_signed_import") if (
            (self.decimal_options and "decimal_packed" in str(self.decimal_options))
            and (self.decimal_packed == "packed")
            and (self.decimal_packed_signed == "unsigned")
        ) else exclude.add("allow_signed_import")
        include.add("c_format") if (self.numeric_options and "c_format" in str(self.numeric_options)) else exclude.add(
            "c_format"
        )
        include.add("in_format") if (
            self.numeric_options and "in_format" in str(self.numeric_options)
        ) else exclude.add("in_format")
        include.add("out_format") if (
            self.numeric_options and "out_format" in str(self.numeric_options)
        ) else exclude.add("out_format")
        include.add("days_since") if (self.date_options == "days_since") else exclude.add("days_since")
        include.add("date_format") if (self.date_options == "date_format") else exclude.add("date_format")
        include.add("is_julian") if (self.date_options == "is_julian") else exclude.add("is_julian")
        include.add("time_format") if (self.time_options == "time_format") else exclude.add("time_format")
        include.add("is_midnight_seconds") if (self.time_options == "is_midnight_seconds") else exclude.add(
            "is_midnight_seconds"
        )
        include.add("timestamp_format") if (self.timestamp_options == "timestamp_format") else exclude.add(
            "timestamp_format"
        )
        return include, exclude

    def _validate_source(self) -> tuple[set, set]:
        include = set()
        exclude = set()

        return include, exclude

    def _get_input_ports_props(self) -> dict:
        include, exclude = self._validate()
        props = {
            "additional_properties_set_input",
            "cleanup_on_failure",
            "create_data_asset",
            "data_asset_name",
            "diskpool",
            "file_prefix",
            "file_set",
            "file_set_schema_policy",
            "file_set_update_policy",
            "file_suffix",
            "maximum_file_size",
            "reject_mode",
            "runtime_column_propagation",
            "schema_file",
            "single_file_per_partition",
        }
        required = {"data_asset_name", "file_set"}
        props = props & (self.model_fields_set | required)
        conflict = exclude & self.model_fields_set & props
        if conflict:
            conflict = list(conflict)
            if len(conflict) == 1:
                warnings.warn(f"\n\033[33mFound conflicting property: {conflict[0]}\033[0m")
            else:
                warnings.warn(
                    f"\n\033[33mFound conflicting properties: {', '.join(conflict[:-1])} and {conflict[-1]}\033[0m"
                )
        exclude = exclude - self.model_fields_set
        return self.model_dump(include=props - exclude, by_alias=True, exclude_none=True, warnings=False)

    def _get_input_cardinality(self) -> dict:
        return {"min": 0, "max": 1}

    def _get_output_ports_props(self) -> dict:
        include, exclude = self._validate()
        props = {
            "file_name_column",
            "file_set",
            "filter",
            "keep_file_partitions",
            "output_additional_properties",
            "reject_mode",
            "reject_reason_column",
            "report_progress",
            "row_number_column",
            "schema_file",
            "strip_bom",
            "use_schema_defined_in_file_set",
        }
        required = {"file_set"}
        props = props & (self.model_fields_set | required)
        conflict = exclude & self.model_fields_set & props
        if conflict:
            conflict = list(conflict)
            if len(conflict) == 1:
                warnings.warn(f"\n\033[33mFound conflicting property: {conflict[0]}\033[0m")
            else:
                warnings.warn(
                    f"\n\033[33mFound conflicting properties: {', '.join(conflict[:-1])} and {conflict[-1]}\033[0m"
                )
        exclude = exclude - self.model_fields_set
        return self.model_dump(include=props - exclude, by_alias=True, exclude_none=True, warnings=False)

    def _get_output_cardinality(self) -> dict:
        return {"min": 0, "max": 1}

    def _get_parameters_props(self) -> dict:
        include, exclude = self._validate()
        props = {
            "actual_field_length",
            "allow_all_zeros",
            "allow_per_column_mapping",
            "allow_signed_import",
            "buf_free_run_ronly",
            "buf_mode_ronly",
            "buffer_free_run_percent",
            "buffering_mode",
            "byte_order",
            "c_format",
            "character_set",
            "check_intact",
            "collecting",
            "column_metadata_change_propagation",
            "combinability_mode",
            "current_output_link_type",
            "data_format",
            "date_format",
            "date_options",
            "days_since",
            "db2_database_name",
            "db2_instance_name",
            "db2_source_connection_required",
            "db2_table_name",
            "decimal_options",
            "decimal_packed",
            "decimal_packed_check",
            "decimal_packed_sign_position",
            "decimal_packed_signed",
            "decimal_sep_value",
            "decimal_separator",
            "delim_value",
            "delimiter",
            "delimiter_string",
            "disk_write_inc_ronly",
            "disk_write_increment_bytes",
            "enable_flow_acp_control",
            "enable_schemaless_design",
            "execution_mode",
            "export_ebcdic_as_ascii",
            "field_defaults_options",
            "field_max_width",
            "field_width",
            "file_name_column",
            "file_set",
            "fill_char",
            "fill_char_value",
            "filter",
            "final_delim_value",
            "final_delimiter",
            "final_delimiter_string",
            "flow_dirty",
            "general_options",
            "hide",
            "import_ascii_as_ebcdic",
            "in_format",
            "input_count",
            "input_link_description",
            "inputcol_properties",
            "intact",
            "is_julian",
            "is_midnight_seconds",
            "keep_file_partitions",
            "key_cols_coll",
            "key_cols_coll_ordered",
            "key_cols_coll_robin",
            "key_cols_none",
            "key_cols_part",
            "map_name",
            "max_mem_buf_size_ronly",
            "maximum_memory_buffer_size_bytes",
            "null_field_length",
            "null_field_sep_value",
            "null_field_value",
            "null_field_value_separator",
            "numeric_options",
            "out_format",
            "output_acp_should_hide",
            "output_additional_properties",
            "output_count",
            "output_link_description",
            "outputcol_properties",
            "pad_char",
            "padchar_value",
            "part_stable_coll",
            "part_stable_ordered",
            "part_stable_roundrobin_coll",
            "part_unique_coll",
            "part_unique_ordered",
            "part_unique_roundrobin_coll",
            "partition_type",
            "perform_sort",
            "perform_sort_coll",
            "perform_sort_modulus",
            "precision",
            "prefix_bytes",
            "preserve_partitioning",
            "print_field",
            "queue_upper_bound_size_bytes",
            "queue_upper_size_ronly",
            "quote",
            "quote_value",
            "record_delim_value",
            "record_delimiter",
            "record_delimiter_string",
            "record_len_value",
            "record_length",
            "record_level_options",
            "record_prefix",
            "record_type",
            "reject_mode",
            "reject_reason_column",
            "report_progress",
            "rounding",
            "row_number_column",
            "runtime_column_propagation",
            "scale",
            "schema_file",
            "show_coll_type",
            "show_part_type",
            "show_sort_options",
            "sort_instructions",
            "sort_instructions_text",
            "sorting_key",
            "stable",
            "stage_description",
            "string_options",
            "strip_bom",
            "time_format",
            "time_options",
            "timestamp_format",
            "timestamp_options",
            "unique",
            "use_schema_defined_in_file_set",
            "vector_prefix",
            "whether_check_intact",
            "whether_specify_null_field_value_separator",
        }
        required = {
            "current_output_link_type",
            "enable_flow_acp_control",
            "enable_schemaless_design",
            "file_set",
            "output_acp_should_hide",
        }
        props = props & (self.model_fields_set | required)
        conflict = exclude & self.model_fields_set & props
        if conflict:
            conflict = list(conflict)
            if len(conflict) == 1:
                warnings.warn(f"\n\033[33mFound conflicting property {conflict[0]}\033[0m")
            else:
                warnings.warn(
                    f"\n\033[33mFound conflicting properties{', '.join(conflict[:-1])} and {conflict[-1]}\033[0m"
                )
        exclude = exclude - self.model_fields_set
        return self.model_dump(include=props - exclude, by_alias=True, exclude_none=True, warnings=False)

    def _get_app_data_props(self) -> dict:
        return {
            "datastage": {
                "maxRejectOutputs": 1,
                "minRejectOutputs": 0,
                "maxReferenceInputs": 0,
                "minReferenceInputs": 0,
            }
        }

    def _get_target_props(self) -> dict:
        include, exclude = self._validate()
        props = {
            "actual_field_length",
            "additional_properties_set_input",
            "allow_all_zeros",
            "allow_per_column_mapping",
            "allow_signed_import",
            "buf_free_run_ronly",
            "buf_mode_ronly",
            "buffer_free_run_percent",
            "buffering_mode",
            "byte_order",
            "c_format",
            "character_set",
            "check_intact",
            "cleanup_on_failure",
            "collecting",
            "column_metadata_change_propagation",
            "combinability_mode",
            "create_data_asset",
            "current_output_link_type",
            "data_asset_name",
            "data_format",
            "date_format",
            "date_options",
            "days_since",
            "db2_database_name",
            "db2_instance_name",
            "db2_source_connection_required",
            "db2_table_name",
            "decimal_options",
            "decimal_packed",
            "decimal_packed_check",
            "decimal_packed_sign_position",
            "decimal_packed_signed",
            "decimal_sep_value",
            "decimal_separator",
            "delim_value",
            "delimiter",
            "delimiter_string",
            "disk_write_inc_ronly",
            "disk_write_increment_bytes",
            "diskpool",
            "enable_flow_acp_control",
            "enable_schemaless_design",
            "execution_mode",
            "export_ebcdic_as_ascii",
            "field_defaults_options",
            "field_max_width",
            "field_width",
            "file_name_column",
            "file_prefix",
            "file_set",
            "file_set_schema_policy",
            "file_set_update_policy",
            "file_suffix",
            "fill_char",
            "fill_char_value",
            "filter",
            "final_delim_value",
            "final_delimiter",
            "final_delimiter_string",
            "flow_dirty",
            "general_options",
            "hide",
            "import_ascii_as_ebcdic",
            "in_format",
            "input_count",
            "input_link_description",
            "inputcol_properties",
            "intact",
            "is_julian",
            "is_midnight_seconds",
            "keep_file_partitions",
            "key_cols_coll",
            "key_cols_coll_ordered",
            "key_cols_coll_robin",
            "key_cols_none",
            "key_cols_part",
            "map_name",
            "max_mem_buf_size_ronly",
            "maximum_file_size",
            "maximum_memory_buffer_size_bytes",
            "null_field_length",
            "null_field_sep_value",
            "null_field_value",
            "null_field_value_separator",
            "numeric_options",
            "out_format",
            "output_acp_should_hide",
            "output_additional_properties",
            "output_count",
            "output_link_description",
            "outputcol_properties",
            "pad_char",
            "padchar_value",
            "part_stable_coll",
            "part_stable_ordered",
            "part_stable_roundrobin_coll",
            "part_unique_coll",
            "part_unique_ordered",
            "part_unique_roundrobin_coll",
            "partition_type",
            "perform_sort",
            "perform_sort_coll",
            "perform_sort_modulus",
            "precision",
            "prefix_bytes",
            "preserve_partitioning",
            "print_field",
            "queue_upper_bound_size_bytes",
            "queue_upper_size_ronly",
            "quote",
            "quote_value",
            "record_delim_value",
            "record_delimiter",
            "record_delimiter_string",
            "record_len_value",
            "record_length",
            "record_level_options",
            "record_prefix",
            "record_type",
            "reject_mode",
            "reject_reason_column",
            "report_progress",
            "rounding",
            "row_number_column",
            "runtime_column_propagation",
            "scale",
            "schema_file",
            "show_coll_type",
            "show_part_type",
            "show_sort_options",
            "single_file_per_partition",
            "sort_instructions",
            "sort_instructions_text",
            "sorting_key",
            "stable",
            "stage_description",
            "string_options",
            "strip_bom",
            "target_additional_properties",
            "time_format",
            "time_options",
            "timestamp_format",
            "timestamp_options",
            "unique",
            "use_schema_defined_in_file_set",
            "vector_prefix",
            "whether_check_intact",
            "whether_specify_null_field_value_separator",
        }
        required = {
            "current_output_link_type",
            "data_asset_name",
            "enable_flow_acp_control",
            "enable_schemaless_design",
            "file_set",
            "output_acp_should_hide",
        }
        props = props & (self.model_fields_set | required)
        conflict = exclude & self.model_fields_set & props
        if conflict:
            conflict = list(conflict)
            if len(conflict) == 1:
                warnings.warn(f"\n\033[33mFound conflicting property {conflict[0]}\033[0m")
            else:
                warnings.warn(
                    f"\n\033[33mFound conflicting properties{', '.join(conflict[:-1])} and {conflict[-1]}\033[0m"
                )
        exclude = exclude - self.model_fields_set
        return self.model_dump(include=props - exclude, by_alias=True, exclude_none=True, warnings=False)
