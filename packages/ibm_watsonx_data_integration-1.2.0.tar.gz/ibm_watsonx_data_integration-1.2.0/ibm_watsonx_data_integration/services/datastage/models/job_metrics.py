"""Module containing batch job run metrics models."""

from ibm_watsonx_data_integration.common.models import BaseModel
from ibm_watsonx_data_integration.common.utils import SeekableList
from ibm_watsonx_data_integration.cpd_models.job_model.job_model import JobRunMetrics, MetricsList
from pydantic import Field, model_validator


class LinkMetrics(BaseModel):
    """Holds link metrics information."""

    start_time: float | None = Field(repr=False, default=None)
    rows_read: int | None = Field(repr=True, default=None)
    rows_written: int | None = Field(repr=True, default=None)
    stop_time: float | None = Field(repr=False, default=None)
    source: str | None = Field(repr=True, default=None)
    state: str | None = Field(repr=True, default=None)
    dest: str | None = Field(repr=True, default=None)
    link_name: str | None = Field(repr=True, default=None)

    def __str__(self) -> str:
        """Return JSON string representation of link metrics."""
        return self.model_dump_json(indent=4)

    def __repr__(self) -> str:
        """Return string representation."""
        return self.__str__()


class StageMetrics(BaseModel):
    """Holds stage metrics information."""

    stage_seconds_cpu: float | None = Field(repr=False, default=None)
    start_time: float | None = Field(repr=False, default=None)
    rows_read: int | None = Field(repr=True, default=None)
    rows_written: int | None = Field(repr=True, default=None)
    stop_time: float | None = Field(repr=False, default=None)
    total_memory: int | None = Field(repr=False, default=None)
    stage_type: str | None = Field(repr=True, default=None)
    stage_name: str | None = Field(repr=True, default=None)
    partition_row_counts: list[dict] | None = Field(repr=True, default=None)
    num_partitions: int | None = Field(repr=True, default=None)
    state: str | None = Field(repr=True, default=None)

    def __str__(self) -> str:
        """Return JSON string representation of stage metrics."""
        return self.model_dump_json(indent=4)

    def __repr__(self) -> str:
        """Return string representation."""
        return self.__str__()


class BatchJobRunMetrics(JobRunMetrics):
    """Holds all batch job run metrics information."""

    link_metrics: MetricsList[LinkMetrics] = Field(repr=True, default_factory=MetricsList)
    stage_metrics: MetricsList[StageMetrics] = Field(repr=True, default_factory=MetricsList)

    @model_validator(mode="before")
    @classmethod
    def _convert_lists_to_seekable(cls, data: dict) -> dict:
        """Turns list into SeekableList with proper model instances."""
        if isinstance(data, dict):
            # Map field names to their corresponding model classes
            field_to_model = {
                "link_metrics": LinkMetrics,
                "stage_metrics": StageMetrics,
            }

            for field, model_class in field_to_model.items():
                value = data.get(field)
                if isinstance(value, list) and not isinstance(value, SeekableList):
                    # Convert each dict item to the appropriate model instance
                    model_instances = [model_class(**item) if isinstance(item, dict) else item for item in value]
                    data[field] = MetricsList(model_instances)
        return data
