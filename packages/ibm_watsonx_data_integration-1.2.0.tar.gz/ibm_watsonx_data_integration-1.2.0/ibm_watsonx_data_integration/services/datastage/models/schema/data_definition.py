"""Module for schema data definition."""

import ibm_watsonx_data_integration.services.datastage.models.schema.field as SchemaField
import logging
import requests
from ibm_watsonx_data_integration.common.models import BaseModel, CollectionModel, CollectionModelResults
from ibm_watsonx_data_integration.cpd_models.asset_model import Asset
from ibm_watsonx_data_integration.services.datastage.models.flow_json_model import FieldModelComplex
from ibm_watsonx_data_integration.services.datastage.models.schema import field
from ibm_watsonx_data_integration.services.datastage.models.schema.field.base_field import BaseField
from pydantic import (
    ConfigDict,
    Field,
    model_serializer,
)
from typing import TYPE_CHECKING, Any, Literal, overload

if TYPE_CHECKING:
    from ibm_watsonx_data_integration.cpd_models.project_model import Project

logger = logging.getLogger(__name__)

_ODBC_TYPE_TO_FIELD_CLASS = {
    "BIGINT": field.BigInt,
    "BINARY": field.Binary,
    "BIT": field.Bit,
    "CHAR": field.Char,
    "DATE": field.Date,
    "DECIMAL": field.Decimal,
    "DOUBLE": field.Double,
    "FLOAT": field.Float,
    "INTEGER": field.Integer,
    "LONGVARBINARY": field.LongVarBinary,
    "LONGVARCHAR": field.LongVarChar,
    "NUMERIC": field.Numeric,
    "REAL": field.Real,
    "SMALLINT": field.SmallInt,
    "TIME": field.Time,
    "TIMESTAMP": field.Timestamp,
    "TINYINT": field.TinyInt,
    "UNKNOWN": field.Unknown,
    "VARBINARY": field.VarBinary,
    "VARCHAR": field.VarChar,
    "NCHAR": field.NChar,
    "LONGNVARCHAR": field.LongNVarChar,
    "NVARCHAR": field.NVarChar,
}


ODBC_TO_CLASS = {
    "BIGINT": SchemaField.BigInt,
    "BINARY": SchemaField.Binary,
    "BIT": SchemaField.Bit,
    "CHAR": SchemaField.Char,
    "DATE": SchemaField.Date,
    "DECIMAL": SchemaField.Decimal,
    "DOUBLE": SchemaField.Double,
    "FLOAT": SchemaField.Float,
    "INTEGER": SchemaField.Integer,
    "LONGVARBINARY": SchemaField.LongVarBinary,
    "LONGVARCHAR": SchemaField.LongVarChar,
    "LONGNVARCHAR": SchemaField.LongVarChar,
    "NUMERIC": SchemaField.Numeric,
    "REAL": SchemaField.Real,
    "SMALLINT": SchemaField.SmallInt,
    "TIME": SchemaField.Time,
    "TIMESTAMP": SchemaField.Timestamp,
    "TINYINT": SchemaField.TinyInt,
    "UNKNOWN": SchemaField.Unknown,
    "VARBINARY": SchemaField.VarBinary,
    "VARCHAR": SchemaField.VarChar,
    "NCHAR": SchemaField.NChar,
    "NVARCHAR": SchemaField.VarChar,
    "WCHAR": SchemaField.NChar,
    "WLONGVARCHAR": SchemaField.LongNVarChar,
    "WVARCHAR": SchemaField.NVarChar,
}


class DataDefinitionMetadata(BaseModel):
    """System metadata about a table definition."""

    asset_id: str = Field(repr=False, frozen=True)
    project_id: str = Field(repr=False, frozen=True)
    name: str = Field()
    description: str = Field("")


class DataDefinitionDataAsset(BaseModel):
    """Column definitions and table properties."""

    _columns: list[BaseField] = []
    additional_properties: dict = Field(default_factory=dict, alias="additionalProperties")
    mime_type: str = Field(default="application/json")
    dataset: bool = Field(default=True)

    def __init__(self, **data: Any) -> None:
        """Initialize DataDefinitionDataAsset.

        Converts FieldModelComplex objects from API to BaseField objects.
        """
        # Extract columns before calling super().__init__
        columns_data = data.pop("columns", [])

        # Initialize the base model
        super().__init__(**data)

        # Convert columns to BaseField objects
        self._columns = []
        for col_data in columns_data:
            if isinstance(col_data, BaseField):
                # Already a BaseField, use directly
                self._columns.append(col_data)
            elif isinstance(col_data, FieldModelComplex):
                # Convert FieldModelComplex to BaseField
                self._columns.append(self._field_model_to_base_field(col_data))
            else:
                # Raw dict from API - create FieldModelComplex first, then convert
                field_model = FieldModelComplex(**col_data)
                self._columns.append(self._field_model_to_base_field(field_model))

    @staticmethod
    def _field_model_to_base_field(field_model: FieldModelComplex) -> BaseField:
        """Convert FieldModelComplex to appropriate BaseField subclass.

        Args:
            field_model: The FieldModelComplex to convert.

        Returns:
            Appropriate BaseField subclass instance.

        Raises:
            ValueError: If odbc_type is not supported.
        """
        odbc_type = field_model.odbc_type or "UNKNOWN"
        if odbc_type not in ODBC_TO_CLASS:
            raise ValueError(f"Unsupported ODBC type: {odbc_type}")

        field_class = ODBC_TO_CLASS[odbc_type]
        return field_class(field_model.name)._create_from_model(model=field_model)

    @property
    def columns(self) -> list[BaseField]:
        """Get columns as BaseField objects.

        Returns:
            List of BaseField objects.
        """
        return self._columns

    @columns.setter
    def columns(self, value: list[BaseField]) -> None:
        """Set columns from BaseField objects.

        Args:
            value: List of BaseField objects.
        """
        self._columns = value

    @model_serializer(mode="wrap")
    def serialize_model(self, handler: Any, info: Any) -> dict[str, Any]:
        """Serializer to serialize this class to a dict by converting fields to the appropriate type.

        Args:
            handler: The default serialization handler.
            info: Serialization context information.

        Returns:
            Serialized dictionary representation.
        """
        # Get the base serialization
        data = handler(self)

        # Override columns with custom serialization
        data["columns"] = [col.configuration.serialize_to_data_definition_column() for col in self._columns]

        return data


class DataDefinitionTypeDefaults(BaseModel):
    """default properties for data types."""

    general: dict = Field(default_factory=dict)
    string: dict = Field(default_factory=dict)
    decimal: dict = Field(default_factory=dict)
    numeric: dict = Field(default_factory=dict)
    date: dict = Field(default_factory=dict)
    time: dict = Field(default_factory=dict)
    timestamp: dict = Field(default_factory=dict)


class DataDefinitionDSInfo(BaseModel):
    """data type defaults and format properties."""

    data_types: list = Field(default_factory=list)
    record_level: dict = Field(default_factory=dict)
    field_defaults: dict = Field(default_factory=dict)
    type_defaults: DataDefinitionTypeDefaults = Field(default_factory=DataDefinitionTypeDefaults)


class DirectoryAsset(BaseModel):
    """DirectoryAsset."""

    path: str | None = Field(default=None)


class DataDefinitionEntity(BaseModel):
    """The underlying table definition entity."""

    data_asset: DataDefinitionDataAsset = Field(default_factory=DataDefinitionDataAsset)
    column_info: dict = Field(default_factory=dict)
    data_definition: dict = Field(default_factory=dict)
    ds_info: DataDefinitionDSInfo = Field(default_factory=DataDefinitionDSInfo)
    directory_asset: DirectoryAsset | None = Field(default=None)


class DataDefinition(Asset):
    """Class for data definition."""

    model_config = ConfigDict(populate_by_name=True, use_enum_values=True, serialize_by_alias=True)

    # Nested objects from API response
    metadata: DataDefinitionMetadata
    entity: DataDefinitionEntity = Field(repr=False, default_factory=DataDefinitionEntity)

    @property
    def data_definition_id(self) -> str | None:
        """Get the asset ID from metadata."""
        return self.metadata.asset_id

    @property
    def name(self) -> str:
        """Get the name from metadata."""
        return self.metadata.name

    @name.setter
    def name(self, value: str) -> None:
        """Set the name in metadata."""
        self.metadata.name = value

    @property
    def description(self) -> str:
        """Get the description from metadata."""
        return self.metadata.description

    @description.setter
    def description(self, value: str) -> None:
        """Set the description in metadata."""
        self.metadata.description = value

    def get_field_by_name(self, name: str) -> BaseField:
        """Get a field by name.

        Args:
            name: The field name to search for.

        Returns:
            The BaseField if found.
        """
        for _field in self.fields:
            if _field.configuration.name == name:
                return _field

        raise ValueError(f"No field with name '{name}' found.")

    @property
    def fields(self) -> list[BaseField]:
        """Get all fields in the data definition.

        Returns:
            List of all BaseField objects.
        """
        return self.entity.data_asset.columns

    @fields.setter
    def fields(self, val: list[BaseField]) -> None:
        """Set the fields of the class."""
        self.entity.data_asset.columns = val

    def remove_field(self, name: str) -> bool:
        """Remove a field by name.

        Args:
            name: The field name to remove.

        Returns:
            True if field was removed, False if not found.
        """
        initial_length = len(self.fields)
        self.fields = [field for field in self.fields if field.configuration.name != name]
        return len(self.fields) < initial_length

    def clear_fields(self) -> None:
        """Remove all fields from the data definition."""
        self.fields.clear()

    def to_base_fields(self, field_names: list[str] | None = None) -> list[BaseField]:
        """Convert columns to BaseField objects for use in Schema.

        Args:
            field_names: Optional list of field names to convert. If None, converts all available fields.

        Returns:
            List of BaseField objects.

        Note:
            When field_names is None, all fields in the data definition are converted.
            Since fields are already BaseField objects, this method now just filters them.
        """
        if field_names is None:
            # Return all fields (already BaseField objects)
            return list(self.fields)
        else:
            # Return only the specified fields
            return [field for field in self.fields if field.configuration.name in field_names]

    @classmethod
    def from_base_fields(
        cls,
        project: "Project",
        fields: list[BaseField],
        name: str,
        description: str = "",
        **kwargs: Any,
    ) -> "DataDefinition":
        """Create a DataDefinition from BaseField objects.

        Args:
            project: The Project instance.
            fields: List of BaseField objects to convert.
            name: Name for the data definition.
            description: Optional description.
            **kwargs: Additional DataDefinition properties.

        Returns:
            A new DataDefinition instance.
        """
        columns: list[FieldModelComplex] = [field.configuration for field in fields]
        return cls._create(project=project, name=name, description=description, columns=columns, **kwargs)

    def __len__(self) -> int:
        """Get the number of columns."""
        return len(self.fields)

    def __contains__(self, name: str) -> bool:
        """Check if a field exists by name."""
        return any(col.configuration.name == name for col in self.fields)

    def has_field(self, name: str) -> bool:
        """Check if a field exists.

        Args:
            name: The field name to check.

        Returns:
            True if field exists, False otherwise.
        """
        return name in self

    @overload
    def add_field(self, odbc_type: Literal["BIGINT"], name: str, **kwargs: Any) -> field.BigInt: ...

    @overload
    def add_field(self, odbc_type: Literal["BINARY"], name: str, **kwargs: Any) -> field.Binary: ...

    @overload
    def add_field(self, odbc_type: Literal["BIT"], name: str, **kwargs: Any) -> field.Bit: ...

    @overload
    def add_field(self, odbc_type: Literal["CHAR"], name: str, **kwargs: Any) -> field.Char: ...

    @overload
    def add_field(self, odbc_type: Literal["DATE"], name: str, **kwargs: Any) -> field.Date: ...

    @overload
    def add_field(self, odbc_type: Literal["DECIMAL"], name: str, **kwargs: Any) -> field.Decimal: ...

    @overload
    def add_field(self, odbc_type: Literal["DOUBLE"], name: str, **kwargs: Any) -> field.Double: ...

    @overload
    def add_field(self, odbc_type: Literal["FLOAT"], name: str, **kwargs: Any) -> field.Float: ...

    @overload
    def add_field(self, odbc_type: Literal["INTEGER"], name: str, **kwargs: Any) -> field.Integer: ...

    @overload
    def add_field(self, odbc_type: Literal["LONGVARBINARY"], name: str, **kwargs: Any) -> field.LongVarBinary: ...

    @overload
    def add_field(self, odbc_type: Literal["LONGVARCHAR"], name: str, **kwargs: Any) -> field.LongVarChar: ...

    @overload
    def add_field(self, odbc_type: Literal["NUMERIC"], name: str, **kwargs: Any) -> field.Numeric: ...

    @overload
    def add_field(self, odbc_type: Literal["REAL"], name: str, **kwargs: Any) -> field.Real: ...

    @overload
    def add_field(self, odbc_type: Literal["SMALLINT"], name: str, **kwargs: Any) -> field.SmallInt: ...

    @overload
    def add_field(self, odbc_type: Literal["TIME"], name: str, **kwargs: Any) -> field.Time: ...

    @overload
    def add_field(self, odbc_type: Literal["TIMESTAMP"], name: str, **kwargs: Any) -> field.Timestamp: ...

    @overload
    def add_field(self, odbc_type: Literal["TINYINT"], name: str, **kwargs: Any) -> field.TinyInt: ...

    @overload
    def add_field(self, odbc_type: Literal["UNKNOWN"], name: str, **kwargs: Any) -> field.Unknown: ...

    @overload
    def add_field(self, odbc_type: Literal["VARBINARY"], name: str, **kwargs: Any) -> field.VarBinary: ...

    @overload
    def add_field(self, odbc_type: Literal["VARCHAR"], name: str, **kwargs: Any) -> field.VarChar: ...

    @overload
    def add_field(self, odbc_type: Literal["NCHAR"], name: str, **kwargs: Any) -> field.NChar: ...

    @overload
    def add_field(self, odbc_type: Literal["LONGNVARCHAR"], name: str, **kwargs: Any) -> field.LongNVarChar: ...

    @overload
    def add_field(self, odbc_type: Literal["NVARCHAR"], name: str, **kwargs: Any) -> field.NVarChar: ...

    def add_field(self, odbc_type: str, name: str, description: str = "", **kwargs: Any):
        """Add fields to data definition."""
        if self.has_field(name=name):
            raise ValueError(f"Field {name} already exists in DataDefinition.")

        if odbc_type.upper() in _ODBC_TYPE_TO_FIELD_CLASS:
            field_class = _ODBC_TYPE_TO_FIELD_CLASS[odbc_type.upper()]
            new_field = field_class(name=name, **kwargs)
            new_field.description = description
            self.fields.append(new_field)
            return new_field
        else:
            raise ValueError(
                f"Unsupported field type: {odbc_type}. Supported types are: {list(_ODBC_TYPE_TO_FIELD_CLASS.keys())}"
            )

    @staticmethod
    def _create(
        project: "Project",
        name: str,
        description: str = "",
        columns: list | None = None,
        **kwargs: Any,
    ) -> "DataDefinition":
        """Create a new data definition in the project.

        Args:
            project: The Project instance.
            name: Name of the data definition.
            description: Optional description.
            columns: Optional list of FieldModelComplex objects.
            **kwargs: Additional DataDefinition properties.

        Returns:
            The created DataDefinition instance.
        """
        body = {
            "metadata": dict(name=name, description=description),
            "entity": dict(
                data_asset=DataDefinitionDataAsset(columns=columns or [], **kwargs).model_dump(),
                column_info={},
                data_definition={},
                ds_info={},
            ),
        }

        response = project._platform._data_definition_api.create_data_definition(
            project_id=project.project_id,
            data=body,
        )

        return DataDefinition(project=project, **response.json())

    def _update(self, project: "Project") -> requests.Response:
        """Update this data definition.

        Args:
            project: The Project instance.

        Returns:
            The updated Data Definition instance.
        """
        if not self.data_definition_id:
            raise ValueError("DataDefinition must already be created to be updated.")

        body = {
            "metadata": self.metadata.model_dump(),
            "entity": self.entity.model_dump(),
        }

        response = project._platform._data_definition_api.update_data_definition(
            project_id=project.project_id,
            table_definition_id=self.data_definition_id,
            data=body,
        )

        # Update the current instance with the response
        updated_data = response.json()
        self.__init__(project=self._project, **updated_data)

        return response

    def _delete(self, project: "Project") -> requests.Response:
        """Delete this data definition.

        Args:
            project: The Project instance.

        Returns:
            HTTP response from the delete operation.
        """
        if not self.data_definition_id:
            raise ValueError("DataDefinition must be created to be deleted")

        response = project._platform._data_definition_api.delete_data_definition(
            project_id=project.project_id,
            table_definition_id=self.data_definition_id,
        )

        return response

    def _duplicate(self, project: "Project", name: str) -> "DataDefinition":
        """Clone this data definition with a new name.

        Args:
            project: The Project instance.
            name: The name for the cloned data definition.

        Returns:
            The cloned DataDefinition instance.
        """
        if not self.data_definition_id:
            raise ValueError("DataDefinition must be created to be duplicated")

        response = project._platform._data_definition_api.clone_data_definition(
            project_id=project.project_id,
            table_definition_id=self.data_definition_id,
            name=name,
        )

        return DataDefinition(project=project, **response.json())


class DataDefinitions(CollectionModel[DataDefinition]):
    """Collection of DataDefinition objects in a project."""

    def __init__(self, project: "Project") -> None:
        """Initialize DataDefinitions collection.

        Args:
            project: The Project instance.
        """
        super().__init__(platform=project._platform, unique_id="data_definition_id")
        self._project = project

    def _request_parameters(self) -> list[str]:
        """Get list of valid request parameters for filtering.

        Returns:
            List of parameter names that can be used in API requests.
        """
        return [
            "data_definition_id",
            "project_id",
            "limit",
            "bookmark",
            "sort",
            "name",
        ]

    def __len__(self) -> int:
        """Get total count of data definitions.

        Returns:
            Total number of data definitions in the project.
        """
        response = self._platform._data_definition_api.list_data_definitions(
            project_id=self._project.project_id,
            params={"limit": 1},
        )
        return response.json().get("total_count", 0)

    def _get_all_results_from_api(self, **kwargs: Any) -> CollectionModelResults:
        """Fetch data definitions from the API.

        Args:
            **kwargs: Query parameters for filtering results.

        Returns:
            CollectionModelResults containing the data definitions.
        """
        # Set default parameters
        request_params = {
            "limit": 100,
        }
        request_params.update(kwargs)
        params = {k: v for k, v in request_params.items() if v is not None}

        response = self._platform._data_definition_api.list_data_definitions(
            project_id=self._project.project_id,
            params=params,
        )
        results = response.json()

        return CollectionModelResults(
            results=results,
            class_type=DataDefinition,
            response_bookmark="next",
            request_bookmark="start",
            response_location="table_definitions",
            constructor_params={"project": self._project},
        )

    def _get_by_id(self, id_val: str, **kwargs: Any) -> CollectionModelResults:
        """Return results for a single DataDefinition instance by id.

        Args:
            id_val: The data definition ID to fetch.
            **kwargs: Additional query parameters.

        Returns:
            CollectionModelResults containing the single data definition.
        """
        response_json = self._platform._data_definition_api.get_data_definition(
            project_id=self._project.project_id,
            table_definition_id=id_val,
            params=kwargs if kwargs else None,
        ).json()

        # Wrap single result in resources array to match collection format
        response = {"table_definitions": [response_json]}

        return CollectionModelResults(
            results=response,
            class_type=DataDefinition,
            response_bookmark="next",
            request_bookmark="start",
            response_location="table_definitions",
            constructor_params={"project": self._project},
        )
