"""Abstract base stage."""

from enum import Enum
from pydantic import BaseModel, Field


class BufMode(Enum):
    """Enum for bufmode property for all stages."""

    default = "default"
    auto_buffer = "autobuffer"
    buffer = "buffer"
    no_buffer = "nobuffer"


class BaseStage(BaseModel):
    """Abstract base stage class."""

    buf_mode: BufMode | str = Field(BufMode.default, alias="buf_mode")
    max_mem_buf_size: int = Field(3145728, alias="max_mem_buf_size")
    buf_free_run: int = Field(50, alias="buf_free_run")
    queue_upper_size: int = Field(0, alias="queue_upper_size")
    disk_write_inc: int = Field(1048576, alias="disk_write_inc")

    def _validate(self) -> tuple[set, set]:
        include = set()
        exclude = set()

        (
            include.add("max_mem_buf_size")
            if (
                ((getattr(self.buf_mode, "value", None) != "default") or self.buf_mode != "default")
                and ((getattr(self.buf_mode, "value", None) != "no_buffer") or self.buf_mode != "nobuffer")
            )
            else exclude.add("max_mem_buf_size")
        )
        (
            include.add("buf_free_run")
            if (
                ((getattr(self.buf_mode, "value", None) != "default") or self.buf_mode != "default")
                and ((getattr(self.buf_mode, "value", None) != "no_buffer") or self.buf_mode != "nobuffer")
            )
            else exclude.add("buf_free_run")
        )
        (
            include.add("queue_upper_size")
            if (
                ((getattr(self.buf_mode, "value", None) != "default") or self.buf_mode != "default")
                and ((getattr(self.buf_mode, "value", None) != "no_buffer") or self.buf_mode != "nobuffer")
            )
            else exclude.add("queue_upper_size")
        )
        (
            include.add("disk_write_inc")
            if (
                ((getattr(self.buf_mode, "value", None) != "default") or self.buf_mode != "default")
                and ((getattr(self.buf_mode, "value", None) != "no_buffer") or self.buf_mode != "nobuffer")
            )
            else exclude.add("disk_write_inc")
        )

        return include, exclude

    def _get_advanced_props(self) -> dict:
        include, exclude = self._validate()
        return self.model_dump(include=include, exclude=exclude, by_alias=True, exclude_none=True)

    def __str__(self) -> str:
        """Format string into pretty json."""
        return self.model_dump_json(indent=4)

    def __repr__(self) -> str:
        """Represent model as string."""
        return self.__str__()

    def __getitem__(self, item: str) -> any:
        """Override getting to allow bracket notation."""
        return getattr(self, item)

    def __setitem__(self, key: str, value: any) -> None:
        """Override setting to allow bracket notation."""
        setattr(self, key, value)
