"""Defines the model structure of a flow JSON."""

import builtins
import json
import logging
import re
from enum import Enum
from ibm_watsonx_data_integration.services.datastage.models.enums import FIELD
from pydantic import BaseModel, ConfigDict, Discriminator, Field, RootModel, Tag, model_validator
from typing import Annotated, Any, ClassVar, Literal

logger = logging.getLogger(__name__)


class Version(Enum):
    """Enum for DataStage version number."""

    v3 = "3.0"


class JsonSchema(Enum):
    """Enum for JSON Schema version."""

    http = "http://api.dataplatform.ibm.com/schemas/common-pipeline/pipeline-flow/pipeline-flow-v3-schema.json"
    https = "https://api.dataplatform.ibm.com/schemas/common-pipeline/pipeline-flow/pipeline-flow-v3-schema.json"


class SubflowRef(BaseModel):
    """Model for referencing an external subflow."""

    url: str | None = None
    pipeline_id_ref: str
    name: str | None = None


class JsonSchema1(Enum):
    """Enum for JSON Schema for datarecord."""

    datarecord_schema = "https://api.dataplatform.ibm.com/schemas/common-pipeline/datarecord-metadata/datarecord-metadata-v3-schema.json"


class Measure(Enum):
    """Enum for measure."""

    range = "range"
    discrete = "discrete"
    flag = "flag"
    set = "set"
    ordered_set = "ordered-set"
    typeless = "typeless"
    collection = "collection"
    geospatial = "geospatial"
    default = "default"

    def __str__(self) -> str:
        """Returns a string representation of a measure."""
        return self.name


class ModelingRole(Enum):
    """Enum for modeling role."""

    input = "input"
    target = "target"
    both = "both"
    none = "none"
    partition = "partition"
    split = "split"
    frequency = "frequency"
    record_id = "record-id"

    def __str__(self) -> str:
        """Returns a string representation of modeling role."""
        return self.name


class Range(BaseModel):
    """Model for range."""

    min: str | float
    max: str | float


class Metadata(BaseModel):
    """Model for flow JSON metadata."""

    description: str | None = None
    measure: Measure | None = None
    modeling_role: ModelingRole | None = None
    max_length: int | None = None
    min_length: int | None = None
    decimal_precision: int | None = None
    decimal_scale: int | None = None
    values: list[str | int | bool] | None = None
    range: Range | None = None
    runtime_type: str | None = None
    is_key: bool | None = None
    is_signed: bool | int | None = None
    item_index: int | None = None
    source_field_id: str | None = None

    def __str__(self) -> str:
        """Returns a string representation of the metadata."""
        dictionary = {
            "description": self.description,
            "measure": self.measure,
            "modeling_role": self.modeling_role,
            "max_length": self.max_length,
            "min_length": self.min_length,
            "decimal_precision": self.decimal_precision,
            "decimal_scale": self.decimal_scale,
            "values": self.values,
            "range": self.range,
            "runtime_type": self.runtime_type,
            "is_key": self.is_key,
            "is_signed": self.is_signed,
            "item_index": self.item_index,
            "source_field_id": self.source_field_id,
        }

        # remove all fields that is None.
        for key, value in dictionary.copy().items():
            if value is None:
                dictionary.pop(key)

        return json.dumps(dictionary, indent=4)


class AppDataDef(BaseModel):
    """Model for appdata definition."""

    pass


class ParamSetReference(BaseModel):
    """Model for parameter set."""

    name: str | None = None
    ref: str
    catalog_ref: str | None = None
    project_ref: str | None = None
    space_ref: str | None = None


class PipelineFlowUI(BaseModel):
    """Model for pipieline flow ui."""

    model_config = ConfigDict(extra="allow")

    name: str | None = None
    description: str | None = None
    class_name: str | None = None


class ZoomObject(BaseModel):
    """Model for zoom object."""

    model_config = ConfigDict(extra="forbid")

    x: float
    y: float
    k: float


class ZoomObjectDef(RootModel[int | ZoomObject]):
    """Model for zoom object definition."""

    pass


class CommentLink(BaseModel):
    """Model for comment link."""

    model_config = ConfigDict(extra="allow")

    node_ref: str
    class_name: str | None = None
    style: str | dict[str, Any] | None = None


class Type5(Enum):
    """Model for validation status."""

    info = "info"
    error = "error"
    warning = "warning"


class Message(BaseModel):
    """Model for validation message."""

    id_ref: str
    validation_id: str | None = None
    type: Type5
    text: str


class Position(Enum):
    """Model for position."""

    topLeft = "topLeft"
    topCenter = "topCenter"
    topRight = "topRight"
    middleLeft = "middleLeft"
    middleCenter = "middleCenter"
    middleRight = "middleRight"
    bottomLeft = "bottomLeft"
    bottomCenter = "bottomCenter"
    bottomRight = "bottomRight"


class Position2(Enum):
    """Model for position 2."""

    source = "source"
    middle = "middle"
    target = "target"


class LabelAlign(Enum):
    """Model for label align."""

    left = "left"
    center = "center"


class DecorationSharedProperties(BaseModel):
    """Model for shared properties for decorations."""

    id: str | None = None
    x_pos: float | None = None
    y_pos: float | None = None
    width: int | None = None
    height: int | None = None
    hotspot: bool | None = None
    class_name: str | None = None
    tooltip: str | None = None
    temporary: bool | None = None


class Cardinality(BaseModel):
    """Model for cardinality."""

    model_config = ConfigDict(extra="forbid")

    min: int | None = 1
    max: int | None = None


class PortUI(BaseModel):
    """Model for port ui."""

    model_config = ConfigDict(extra="allow")

    cardinality: Cardinality | None = None
    class_name: str | None = None
    style: str | dict[str, Any] | None = None
    label: str | None = None


class RuntimeUI(BaseModel):
    """Model for runtime ui."""

    model_config = ConfigDict(extra="allow")

    pass


class CommonPipelineConnection(BaseModel):
    """Model for common pipeline connections."""

    name: str | None = None
    app_data: AppDataDef | None = None
    ref: str | None = None
    catalog_ref: str | None = None
    project_ref: str | None = None
    space_ref: str | None = None
    properties: dict[str, Any] | None = None
    connData: dict[str, Any] | None = None


class Properties(BaseModel):
    """Model for properties."""

    model_config = ConfigDict(extra="allow")

    attachment_ref: str | None = None
    name: str | None = None
    no_write_schema: bool | None = False
    no_write_status: bool | None = False


class CommonPipelineDataAsset(BaseModel):
    """Model for common pipeline data assets."""

    app_data: AppDataDef | None = None
    ref: str | None = None
    catalog_ref: str | None = None
    project_ref: str | None = None
    space_ref: str | None = None
    properties: Properties | None = None


class AppDataAdditionalProperties(BaseModel):
    """Model for AppData additional properties."""

    model_config = ConfigDict(extra="allow")

    globalAcp: bool = True
    runMode: str = "ETL"
    ELTDropdown: dict | None = None


class AppData(BaseModel):
    """Model for app data."""

    model_config = ConfigDict(extra="allow")

    ui_data: PipelineFlowUI | None = None
    additionalProperties: AppDataAdditionalProperties | None = AppDataAdditionalProperties()


class PortAppData(BaseModel):
    """Model for port app data."""

    model_config = ConfigDict(extra="allow")

    ui_data: PortUI | None = None


class RuntimeAppData(BaseModel):
    """Model for runtime app data."""

    model_config = ConfigDict(extra="allow")

    ui_data: RuntimeUI | None = None


class Runtime(BaseModel):
    """Model for runtime."""

    id: str
    name: str
    version: str | None = None
    app_data: RuntimeAppData | None = None


class FieldModel(BaseModel):
    """Serializable proxy for the FieldModelComplex class. Used in serializing fields for use in schema JSONs."""

    name: str
    type: str | None = "unknown"
    nullable: bool | None = False
    metadata: Metadata | None = None
    app_data: dict[str, Any] | None = None


class FieldModelComplex(BaseModel):
    """Model for schema fields."""

    model_config = ConfigDict(use_enum_values=True, populate_by_name=True)
    name: str
    type: dict | str | None = "unknown"
    type_code: str | None = None
    odbc_type: str | None = None
    nullable: bool | None = False
    metadata: Metadata | None = None
    app_data: dict[str, Any] = {}
    length: int | None = None
    scale: int | None = None
    signed: bool | None = Field(True)
    description: str | None = ""
    primary_key: bool | None = False
    unicode: FIELD.Unicode | None = Field(None, alias="extended")
    sqltype: int | None = 1
    ds_data_type: str | None = "WSMQ.QUEUENAME"
    data_element: str | None = "null"
    key_position: int | None = 1
    display_size: int | None = 0
    field_pos: int | None = 1
    level_no: int | None = None
    occurs: int | None = None
    sign_option: int | None = 0
    ds_scd_purpose: int | None = 0
    ds_sync_indicator: int | None = 0
    pad_char: str | None = ""  # TODO: Why are there two padchars (pad_char and padchar)
    extended_precision: int | None = 0
    tagged_subrec: int | None = 0
    occurs_varying: int | None = 0
    Maps_from_input_column: str | None = Field("", alias="Maps from input column")
    byte_to_skip: int | str | None = Field("", alias="skip")
    delim: FIELD.Delim | None = None
    delim_string: str | None = None
    generate: bool | None = False
    prefix_bytes: FIELD.Prefix | None = Field(None, alias="prefix")
    vector_prefix: FIELD.VectorPrefix | None = (
        None  # TODO: figure out why 0 is the default, but is not in the Prefix Enum
    )
    quote: FIELD.Quote | None = None
    start_position: int | None = Field(None, alias="position")
    tagcase: int | None = None
    charset: FIELD.CharSet | None = None
    default: int | str | None = None
    export_ebcdic_as_ascii: bool | None = Field(False)
    max_width: int | None = None
    width: int | None = max_width
    link_keep: bool | None = Field(False)
    padchar: FIELD.PadChar | None = None
    cycle_increment: FIELD.CycleIncrement | int | None = None
    cycle_initial_value: FIELD.CycleInitialValue | int | None = None
    cycle_limit: FIELD.CycleLimit | int | None = None
    cycle_values: list[str | int] | None = None
    alphabet: str | None = None
    time_scale: int | None = None
    byte_order: FIELD.ByteOrder | None = None
    c_format: str | None = Field(None)  # not sure how the handle the fact that this should only be included sometimes
    data_format: FIELD.DataFormat | None = None

    out_format: str | None = None
    reference: str | None = None
    generate_algorithm: FIELD.GenerateAlgorithm | None = None
    generate_type: FIELD.GenerateType | None = None
    random_limit: FIELD.RandomLimit | None = None
    random_seed: FIELD.RandomSeed | None = None
    random_signed: bool | None = False

    days_since: int | None = None
    date_format: str | None = None
    julian: bool | None = None

    generated_percent_invalid: int | None = Field(None, alias="invalids")
    epoch: int | None = None
    use_current_date: bool = Field(False)

    decimal_separator: FIELD.DecimalSeparator | None = None
    rounding: FIELD.Round | None = Field(None, alias="round")
    decimal_packed: FIELD.DecimalPacked | None = None
    check_decimal_packed: bool | None = Field(None, alias="check")
    decimal_packed_signed: bool | None = None
    sign_position: FIELD.SignPosition | None = None
    generated_percent_zeros: int | None = Field(None, alias="zeros")
    increment_scale: int | None = None
    precision: int | None = None

    midnight_seconds: bool = Field(False)
    time_scale_factor: int | None = Field(None, alias="_scale")
    extended_type: FIELD.TimeExtendedType | None = None
    allow_all_zeros: FIELD.AllowAllZeros | None = None

    timestamp_format: str | None = None
    vector_length_type: FIELD.VectorType | None = None
    apt_field_properties: str | None = None

    dimension_min_size: int | None = None

    actual_length: int | None = None
    null_length: int | None = None
    null_field: str | None = None
    nullseed: int | None = None
    nulls: int | None = None

    cycle: str | None = None

    @model_validator(mode="before")
    @classmethod
    def _preprocess_data_definition_format(cls, data: Any) -> Any:
        """Preprocess data from DataDefinition API format to FieldModelComplex format.

        The DataDefinition API returns columns with a nested structure where type information
        is in a 'type' dict and field properties are in a 'properties' dict. This validator
        flattens both structures for Pydantic validation.

        Args:
            data: Input data, either dict or already processed object.

        Returns:
            Preprocessed data dict with flattened structure.
        """
        if not isinstance(data, dict):
            return data

        # Check if this is DataDefinition format (has nested 'type' dict)
        type_value = data.get("type")
        if isinstance(type_value, dict):
            # Extract odbc_type from nested structure
            if "type" in type_value:
                data["odbc_type"] = type_value["type"]

            # Extract other fields from nested type dict
            for field in ["length", "scale", "nullable", "signed"]:
                if field in type_value and field not in data:
                    data[field] = type_value[field]

        # Check if this is DataDefinition format (has nested 'properties' dict)
        properties_value = data.get("properties")
        if isinstance(properties_value, dict):
            # Flatten all properties to top level, but don't overwrite existing fields
            for key, value in properties_value.items():
                if key not in data:
                    data[key] = value

        # Ensure odbc_type is set (required field)
        if "odbc_type" not in data or data["odbc_type"] is None:
            # If still no odbc_type, try to infer from type field
            if isinstance(data.get("type"), str):
                data["odbc_type"] = data["type"]
            else:
                data["odbc_type"] = "UNKNOWN"

        # Convert empty strings to None for enum fields that don't accept empty strings
        enum_fields_to_clean = ["delim", "quote", "charset", "padchar"]
        for field_name in enum_fields_to_clean:
            if field_name in data and data[field_name] == "":
                data[field_name] = None

        # Convert 0 to None for prefix field (enum expects 1, 2, or 4)
        if "prefix" in data and data["prefix"] == 0:
            data["prefix"] = None

        return data

    def __setattr__(self, name: str, value: Any) -> None:  # noqa
        """Overrides some setters."""
        if name == "length":
            object.__setattr__(self, name, value)
            if self.metadata is not None:
                self.metadata.max_length = value
                if self.odbc_type in ["BINARY", "CHAR", "NCHAR"]:
                    self.metadata.min_length = value
                elif self.odbc_type in ["DECIMAL", "NUMERIC", "TIME", "TIMESTAMP"]:
                    self.metadata.decimal_precision = value
            if self.odbc_type in ["BIGINT", "BIT", "DATE", "DOUBLE", "FLOAT", "INTEGER", "SMALLINT", "TINYINT"]:
                raise AttributeError(f"Cannot set length property of {self.odbc_type} type")
        elif name == "description":
            object.__setattr__(self, name, value)
            if self.metadata is not None:
                self.metadata.description = value
        elif name == "scale":
            if self.odbc_type in ["DECIMAL", "NUMERIC", "REAL", "UNKNOWN"]:
                object.__setattr__(self, name, value)
                if self.metadata is not None:
                    self.metadata.decimal_scale = value
            elif self.odbc_type in ["TIME", "TIMESTAMP"]:
                self.time_scale = value
                if self.app_data is not None:
                    self.app_data["time_scale"] = value
            else:
                raise AttributeError(f"Cannot set scale property of {self.odbc_type} type")
        elif name == "extended_type":
            if self.odbc_type not in ["TIME", "TIMESTAMP"]:
                raise AttributeError(f"Cannot set extended_type property of {self.odbc_type} type")
            object.__setattr__(self, name, value)
            if self.app_data is not None:
                self.app_data["extended_type"] = value
            if self.metadata is not None:
                self.metadata.decimal_scale = 6
            self.scale = 6
        elif name == "allow_all_zeros":
            if self.odbc_type not in ["DECIMAL", "NUMERIC"]:
                raise AttributeError(f"Cannot set allow_all_zeros property of {self.odbc_type} type")
            if not isinstance(value, bool):
                raise ValueError("Allow_all_zeros must be a boolean")
            if value:
                self.allow_all_zeros = FIELD.AllowAllZeros.fix_zero
            else:
                self.allow_all_zeros = None
        elif name == "timezone":
            if self.odbc_type not in ["TIME", "TIMESTAMP"]:
                raise AttributeError(f"Cannot set timezone property of {self.odbc_type} type")
            if not isinstance(value, bool):
                raise ValueError("Timezone must be a boolean")
            if value:
                if self._extended_type == FIELD.TimeExtendedType.microseconds:
                    self._extended_type = FIELD.TimeExtendedType.microseconds_and_timezone
                else:
                    self._extended_type = self.extended_type = FIELD.TimeExtendedType.timezone
            else:
                if self._extended_type == FIELD.TimeExtendedType.microseconds_and_timezone:
                    self._extended_type = FIELD.TimeExtendedType.microseconds
                else:
                    self._extended_type = None
        elif name == "microseconds":
            if self.odbc_type not in ["TIME", "TIMESTAMP"]:
                raise AttributeError(f"Cannot set microseconds property of {self.odbc_type} type")
            if not isinstance(value, bool):
                raise ValueError("Microseconds must be a boolean")
            if value:
                if self._extended_type == FIELD.TimeExtendedType.timezone:
                    self._extended_type = FIELD.TimeExtendedType.microseconds_and_timezone
                else:
                    self._extended_type = self.extended_type = FIELD.TimeExtendedType.microseconds
            else:
                if self._extended_type == FIELD.TimeExtendedType.microseconds_and_timezone:
                    self._extended_type = FIELD.TimeExtendedType.timezone
                else:
                    self._extended_type = None
        else:
            super().__setattr__(name, value)

    # @property
    # def length(self):
    #     return self.__dict__['length']

    # @length.setter
    # def length(self, length: int):
    #     self.__dict__['length'] = length
    #     self.metadata.max_length = length
    #     if self.odbc_type in ["BINARY", "CHAR", "NCHAR"]:
    #         self.metadata.min_length = length
    #     elif self.odbc_type in ["DECIMAL", "NUMERIC", "TIME", "TIMESTAMP"]:
    #         self.metadata.decimal_precision = length
    #     elif self.odbc_type in ["BIGINT", "BIT", "DATE", "DOUBLE", "FLOAT", "INTEGER", "SMALLINT", "TINYINT"]:
    #         raise AttributeError(f"Cannot set length property of {self.odbc_type} type")

    @property
    def key(self) -> bool | None:
        """Gets the key property."""
        return self.primary_key

    @key.setter
    def key(self, is_key: bool = True) -> None:
        """Sets the key property."""
        setattr(self.metadata, "is_key", is_key)
        self.primary_key = True

    @property
    def source(self) -> str | None:
        """Gets the source property."""
        if self.metadata is not None:
            return self.metadata.source_field_id
        return None

    @source.setter
    def source(self, name: str) -> None:
        """Sets the source property."""
        setattr(self.metadata, "source_field_id", name)

    # @property
    # def description(self):
    #     return self._description

    # @description.setter
    # def description(self, description: str):
    #     """Sets the description property."""
    #     self.metadata.description = description
    #     self._description = description

    @property
    def pivot(self) -> str | None:
        """Gets the pivot property."""
        if self.app_data is not None:
            return self.app_data["pivot_property"]
        return None

    @pivot.setter
    def pivot(self, pivot_property: str | None = None) -> None:
        """Sets the pivot property."""
        setattr(self.app_data, "pivot_property", pivot_property)

    @property
    def level_number(self) -> int | None:
        """Gets the level number property."""
        return self.level_no

    @level_number.setter
    def level_number(self, level_number: int) -> None:
        """Sets the level number property."""
        self.level_no = level_number
        setattr(self.metadata, "item_index", level_number)

    @property
    def vector(self) -> FIELD.VectorType | None:
        """Gets the vector property."""
        return self.vector_length_type

    @vector.setter
    def vector(self, vector_length_type: FIELD.VectorType) -> None:
        """Sets the vector property."""
        if vector_length_type == FIELD.VectorType.variable:
            assert self.app_data is not None
            self.app_data["dimension_min_size"] = 0
            self.dimension_min_size = 0
        self.vector_length_type = vector_length_type

    @property
    def vector_occurs(self) -> int | None:
        """Gets the vector occurs property."""
        return self.occurs

    @vector_occurs.setter
    def vector_occurs(self, vector_occurs: int) -> None:
        """Sets the vector occurs property."""
        assert self.app_data is not None
        self.occurs = vector_occurs
        self.app_data["dimension_min_size"] = vector_occurs
        self.dimension_min_size = vector_occurs
        self.app_data["dimension_max_size"] = vector_occurs

    @property
    def actual_field_length(self) -> int | None:
        """Gets the actual length property."""
        return self.actual_length

    @actual_field_length.setter
    def actual_field_length(self, length: int) -> None:
        """Sets the actual length property."""
        self.actual_length = length

    @property
    def null_field_length(self) -> int | None:
        """Gets the null length property."""
        return self.null_length

    @null_field_length.setter
    def null_field_length(self, length: int) -> None:
        """Sets the null length property."""
        self.null_length = length

    @property
    def null_field_value(self) -> str | None:
        """Gets the null field property."""
        return self.null_field

    @null_field_value.setter
    def null_field_value(self, value: str) -> None:
        """Sets the null field property."""
        self.null_field = value

    @property
    def change_code(self) -> bool:
        """Gets the change code property."""
        return self.app_data["change_code"]

    @change_code.setter
    def change_code(self, change_code: bool = True) -> None:
        """Sets the change code property."""
        self.app_data["change_code"] = change_code

    @property
    def derivation(self) -> str:
        """Gets the derivation property."""
        return self.app_data["derivation"]

    @derivation.setter
    def derivation(self, derivation: str) -> None:
        """Sets the derivation property."""
        self.app_data["derivation"] = derivation

    @property
    def unsigned(self) -> bool | None:
        """Gets the unsigned field."""
        return self.signed

    @unsigned.setter
    def unsigned(self, is_unsigned: bool = True) -> None:
        """Sets field to unsigned."""
        if self.odbc_type not in ["BIGINT", "INTEGER", "SMALLINT", "TINYINT"]:
            raise AttributeError(f"{self.odbc_type} cannot be unsigned")

        setattr(self.metadata, "is_signed", not is_unsigned)
        self.signed = not is_unsigned

    @property
    def delimiter(self) -> FIELD.Delim | None:
        """Gets delimiter."""
        return self.delim

    @delimiter.setter
    def delimiter(self, delim: FIELD.Delim) -> None:
        """Sets delimiter."""
        self.delim = delim

    @property
    def delimiter_string(self) -> str | None:
        """Gets delimiter string."""
        return self.delim_string

    @delimiter_string.setter
    def delimiter_string(self, delimiter_string: str) -> None:
        """Sets delimiter string."""
        self.delim_string = delimiter_string

    @property
    def generate_on_output(self) -> bool | None:
        """Gets generate on output."""
        return self.generate

    @generate_on_output.setter
    def generate_on_output(self, generate_on_output: bool = True) -> None:
        """Sets generate on output."""
        self.generate = generate_on_output

    @property
    def tag_case_value(self) -> int | None:
        """Gets tag case value."""
        return self.tagcase

    @tag_case_value.setter
    def tag_case_value(self, tag_case_value: int) -> None:
        """Sets tag case value."""
        self.tagcase = tag_case_value

    @property
    def field_max_width(self) -> int | None:
        """Gets field max width."""
        return self.max_width

    @field_max_width.setter
    def field_max_width(self, max_width: int) -> None:
        """Sets field max width."""
        if self.odbc_type in ["BINARY", "DATE", "LONGVARBINARY", "TIME", "TIMESTAMP", "VARBINARY"]:
            raise AttributeError(f"Cannot set field_max_width of {self.odbc_type} type")
        self.max_width = max_width

    @property
    def field_width(self) -> int | None:
        """Gets field width."""
        return self.width

    @field_width.setter
    def field_width(self, width: int) -> None:
        """Sets field width."""
        if self.odbc_type in ["BINARY", "DATE", "LONGVARBINARY", "TIME", "TIMESTAMP", "VARBINARY"]:
            raise AttributeError(f"Cannot set field_width of {self.odbc_type} type")
        self.width = width

    @property
    def is_link_field(self) -> bool | None:
        """Gets is link field."""
        return self.link_keep

    @is_link_field.setter
    def is_link_field(self, is_link_field: bool = True) -> None:
        """Sets is link field."""
        if self.odbc_type in ["BINARY", "DATE", "LONGVARBINARY", "TIME", "TIMESTAMP", "VARBINARY"]:
            raise AttributeError(f"Cannot set is_link_field of {self.odbc_type} type")
        self.link_keep = is_link_field

    @property
    def null_seed(self) -> int | None:
        """Gets null seed."""
        return self.nullseed

    @null_seed.setter
    def null_seed(self, seed: int) -> None:
        """Sets null seed."""
        if self.odbc_type in ["BINARY", "LONGVARBINARY", "VARBINARY"]:
            raise AttributeError(f"Cannot set null_seed property of {self.odbc_type} type")
        self.nullseed = seed

    @property
    def percent_null(self) -> int | None:
        """Gets percent null."""
        return self.nulls

    @percent_null.setter
    def percent_null(self, percent_null: int) -> None:
        """Sets percent null."""
        if self.odbc_type in ["BINARY", "LONGVARBINARY", "VARBINARY"]:
            raise AttributeError(f"Cannot set percent_null property of {self.odbc_type} type")
        self.nulls = percent_null

    # @property
    # def scale(self):
    #     if self.odbc_type in ["DECIMAL", "NUMERIC", "REAL", "UNKNOWN"]:
    #         return self.metadata.decimal_scale
    #     elif self.odbc_type in ["TIME", "TIMESTAMP"]:
    #         return self.time_scale
    #     else:
    #         raise AttributeError(f"{self.odbc_type} type has no scale property")

    # @scale.setter
    # def scale(self, scale: int):
    #     """Sets scale."""
    #     if self.odbc_type in ["DECIMAL", "NUMERIC", "REAL", "UNKNOWN"]:
    #         self._scale = scale
    #         self.metadata.decimal_scale = scale
    #     elif self.odbc_type in ["TIME", "TIMESTAMP"]:
    #         self.time_scale = scale
    #         self.app_data["time_scale"] = scale
    #     else:
    #         raise AttributeError(f"Cannot set scale property of {self.odbc_type} type")

    # @property
    # def extended_type(self):
    #     return self._extended_type

    # @extended_type.setter
    # def extended_type(self, type: FIELD.TimeExtendedType):
    #     """Sets extended_type."""
    #     self.app_data["extended_type"] = type
    #     self._extended_type = type
    #     self.metadata.decimal_scale = 6
    #     self._scale = 6

    @property
    def cluster_key_change(self) -> bool | None:
        """Gets cluster key change."""
        if "cluser_key_change" not in self.app_data:
            return None
        return self.app_data["cluster_key_change"]

    @cluster_key_change.setter
    def cluster_key_change(self, cluster_key_change: bool = True) -> None:
        """Sets cluster key change."""
        if self.odbc_type != "TINYINT":
            raise AttributeError(f"Cannot set cluster_key_change property of {self.odbc_type} type")
        self.app_data["cluster_key_change"] = cluster_key_change

    @property
    def key_change(self) -> bool | None:
        """Gets key change."""
        if "key_change" not in self.app_data:
            return None
        return self.app_data["key_change"]

    @key_change.setter
    def key_change(self, key_change: bool = True) -> None:
        """Sets key change."""
        if self.odbc_type != "TINYINT":
            raise AttributeError(f"Cannot set key_change property of {self.odbc_type} type")
        self.app_data["key_change"] = key_change

    @property
    def difference(self) -> bool | None:
        """Gets difference."""
        if "difference" not in self.app_data:
            return None
        return self.app_data["difference"]

    @difference.setter
    def difference(self, difference: bool = True) -> None:
        """Sets difference."""
        if self.odbc_type != "TINYINT":
            raise AttributeError(f"Cannot set difference property of {self.odbc_type} type")
        self.app_data["difference"] = difference

    @property
    def format_string(self) -> str | None:
        """Gets format string."""
        if self.odbc_type == "TIMESTAMP":
            return self.timestamp_format
        elif self.odbc_type in ["DATE", "TIME"]:
            return self.date_format
        else:
            raise AttributeError(f"{self.odbc_type} type has no format_string property")

    @format_string.setter
    def format_string(self, format_string: str) -> None:
        """Sets format string."""
        if self.odbc_type == "TIMESTAMP":
            self.timestamp_format = format_string
        elif self.odbc_type in ["DATE", "TIME"]:
            self.date_format = format_string
        else:
            raise AttributeError(f"Cannot set format_string property of {self.odbc_type} type")

    @property
    def link_field_reference(self) -> str | None:
        """Gets link field reference."""
        if self.odbc_type in ["BIGINT", "BIT", "CHAR"]:
            raise AttributeError(f"{self.odbc_type} type has no link_field_reference property")
        return self.reference

    @link_field_reference.setter
    def link_field_reference(self, link_field_reference: str) -> None:
        """Sets link field reference."""
        if self.odbc_type in ["BIGINT", "BIT", "CHAR"]:
            raise AttributeError(f"Cannot set link_field_reference property of {self.odbc_type} type")
        self.reference = link_field_reference

    @property
    def scale_factor(self) -> int | None:
        """Gets scale factor."""
        if self.odbc_type not in ["TIME", "TIMESTAMP"]:
            raise AttributeError(f"{self.odbc_type} type has no scale_factor property")
        return self.time_scale_factor

    @scale_factor.setter
    def scale_factor(self, time_scale_factor: int) -> None:
        """Sets scale factor."""
        if self.odbc_type not in ["TIME", "TIMESTAMP"]:
            raise AttributeError(f"Cannot set scale_factor property of {self.odbc_type} type")
        self.time_scale_factor = time_scale_factor

    @property
    def percent_invalid(self) -> int | None:
        """Gets percent invalid."""
        if self.odbc_type not in ["DATE", "DECIMAL", "NUMERIC", "TIME", "TIMESTAMP"]:
            raise AttributeError(f"{self.odbc_type} type has no percent_invalid property")
        return self.generated_percent_invalid

    @percent_invalid.setter
    def percent_invalid(self, generated_percent_invalid: int) -> None:
        """Sets percent invalid."""
        if self.odbc_type not in ["DATE", "DECIMAL", "NUMERIC", "TIME", "TIMESTAMP"]:
            raise AttributeError(f"Cannot set percent_invalid property of {self.odbc_type} type")
        self.generated_percent_invalid = generated_percent_invalid

    @property
    def percent_zeros(self) -> int | None:
        """Gets percent zeros."""
        if self.odbc_type not in ["DECIMAL", "NUMERIC"]:
            raise AttributeError(f"{self.odbc_type} type has no percent_zeros property")
        return self.generated_percent_zeros

    @percent_zeros.setter
    def percent_zeros(self, generated_percent_zeros: int) -> None:
        """Sets percent zeros."""
        if self.odbc_type not in ["DECIMAL", "NUMERIC"]:
            raise AttributeError(f"Cannot set percent_zeros property of {self.odbc_type} type")
        self.generated_percent_zeros = generated_percent_zeros

    @property
    def check_packed(self) -> bool | None:
        """Gets check packed."""
        if self.odbc_type != "DECIMAL":
            raise AttributeError(f"{self.odbc_type} type has no check_packed property")
        return self.check_decimal_packed

    @check_packed.setter
    def check_packed(self, check_packed: bool = True) -> None:
        """Sets check packed."""
        if self.odbc_type != "DECIMAL":
            raise AttributeError(f"Cannot set check_packed property of {self.odbc_type} type")
        self.check_decimal_packed = check_packed

    @property
    def packed_signed(self) -> bool | None:
        """Gets packed signed."""
        if self.odbc_type != "DECIMAL":
            raise AttributeError(f"{self.odbc_type} type has no packed_signed property")
        return self.decimal_packed_signed

    @packed_signed.setter
    def packed_signed(self, packed_signed: bool = True) -> None:
        """Sets packed signed."""
        if self.odbc_type != "DECIMAL":
            raise AttributeError(f"Cannot set packed_signed property of {self.odbc_type} type")
        self.decimal_packed_signed = packed_signed

    @property
    def is_midnight_seconds(self) -> bool:
        """Gets is midnight seconds."""
        if self.odbc_type != "DECIMAL":
            raise AttributeError(f"{self.odbc_type} type has no is_midnight_seconds property")
        return self.midnight_seconds

    @is_midnight_seconds.setter
    def is_midnight_seconds(self, midnight_seconds: bool = True) -> None:
        """Sets is midnight seconds."""
        if self.odbc_type != "DECIMAL":
            raise AttributeError(f"Cannot set is_midnight_seconds property of {self.odbc_type} type")
        self.midnight_seconds = midnight_seconds

    @property
    def packed(self) -> FIELD.DecimalPacked | None:
        """Gets packed."""
        if self.odbc_type not in ["DECIMAL", "NUMERIC"]:
            raise AttributeError(f"{self.odbc_type} type has no packed property")
        return self.decimal_packed

    @packed.setter
    def packed(self, packed_option: FIELD.DecimalPacked) -> None:
        """Sets packed."""
        if self.odbc_type not in ["DECIMAL", "NUMERIC"]:
            raise AttributeError(f"Cannot set packed property of {self.odbc_type} type")
        self.decimal_packed = packed_option

    # @property
    # def allow_all_zeros(self):
    #     if self.odbc_type not in ["DECIMAL", "NUMERIC"]:
    #         raise AttributeError(f"{self.odbc_type} type has no allow_all_zeros property")
    #     return self._allow_all_zeros

    # @allow_all_zeros.setter
    # def allow_all_zeros(self, allow_all_zeros: bool = True):
    #     if self.odbc_type not in ["DECIMAL", "NUMERIC"]:
    #         raise AttributeError(f"Cannot set allow_all_zeros property of {self.odbc_type} type")
    #     if allow_all_zeros:
    #         self._allow_all_zeros = FIELD.AllowAllZeros.fix_zero
    #     else:
    #         self._allow_all_zeros = None

    @property
    def decimal_type_scale(self) -> int | None:
        """Gets decimal type scale."""
        if self.odbc_type != "DECIMAL":
            raise AttributeError(f"{self.odbc_type} type has no decimal_type_scale property")
        return self.increment_scale

    @decimal_type_scale.setter
    def decimal_type_scale(self, scale: int) -> None:
        """Sets decimal type scale."""
        if self.odbc_type != "DECIMAL":
            raise AttributeError(f"Cannot set decimal_type_scale property of {self.odbc_type} type")
        self.increment_scale = scale

    # @property
    # def timezone(self):
    #     if self.odbc_type not in ["TIME", "TIMESTAMP"]:
    #         raise AttributeError(f"{self.odbc_type} type has no timezone property")
    #     return self._extended_type

    # @timezone.setter
    # def timezone(self, timezone: bool = True):
    #     if self.odbc_type not in ["TIME", "TIMESTAMP"]:
    #         raise AttributeError(f"Cannot set timezone property of {self.odbc_type} type")
    #     if timezone:
    #         if self._extended_type == FIELD.TimeExtendedType.microseconds:
    #             self._extended_type = FIELD.TimeExtendedType.microseconds_and_timezone
    #         else:
    #             self._extended_type = self.extended_type = FIELD.TimeExtendedType.timezone
    #     else:
    #         if self._extended_type == FIELD.TimeExtendedType.microseconds_and_timezone:
    #             self._extended_type = FIELD.TimeExtendedType.microseconds
    #         else:
    #             self._extended_type = None

    # @property
    # def microseconds(self):
    #     if self.odbc_type not in ["TIME", "TIMESTAMP"]:
    #         raise AttributeError(f"{self.odbc_type} type has no microseconds property")
    #     return self._extended_type

    # @microseconds.setter
    # def microseconds(self, microseconds: bool = True):
    #     if self.odbc_type not in ["TIME", "TIMESTAMP"]:
    #         raise AttributeError(f"Cannot set microseconds property of {self.odbc_type} type")
    #     if microseconds:
    #         if self._extended_type == FIELD.TimeExtendedType.timezone:
    #             self._extended_type = FIELD.TimeExtendedType.microseconds_and_timezone
    #         else:
    #             self._extended_type = self.extended_type = FIELD.TimeExtendedType.microseconds
    #     else:
    #         if self._extended_type == FIELD.TimeExtendedType.microseconds_and_timezone:
    #             self._extended_type = FIELD.TimeExtendedType.timezone
    #         else:
    #             self._extended_type = None

    def _get_length(self) -> int:
        # return value, or return default derived from data type
        if self.length is not None:
            return self.length
        elif self.odbc_type in ["TIME"]:
            return 8
        elif self.odbc_type in ["TIMESTAMP"]:
            return 19
        elif self.odbc_type in [
            "SMALLINT",
            "INTEGER",
            "FLOAT",
            "DOUBLE",
            "DATE",
            "BIT",
            "TINYINT",
        ]:
            return 0
        else:
            return 100

    def _get_scale(self) -> int:
        if self.scale is not None:
            return self.scale

        if self.extended_type is not None and self.extended_type != "" and self.extended_type != " ":
            return 6  # default value if extended type is set (see TIME and TIMESTAMP data types)

        return 0  # normal default value

    def _get_cycle(self) -> str:
        if self.cycle:
            return self.cycle
        if self.generate_type == FIELD.GenerateType.cycle:
            cycle_dict_elements = []
            limit = self.cycle_limit
            if limit:
                limit = FieldModelComplex._get_enum_value(limit)
                if isinstance(limit, str):
                    cycle_dict_elements += [f"limit='{limit}'"]
                elif isinstance(limit, int):
                    cycle_dict_elements += [f"limit={limit}"]
            increment = self.cycle_increment
            if increment:
                increment = FieldModelComplex._get_enum_value(increment)
                if isinstance(increment, str):
                    cycle_dict_elements += [f"incr='{increment}'"]
                elif isinstance(increment, int):
                    cycle_dict_elements += [f"incr={increment}"]
            initial_value = self.cycle_initial_value
            if initial_value:
                initial_value = FieldModelComplex._get_enum_value(initial_value)
                if isinstance(initial_value, str):
                    cycle_dict_elements += [f"init='{initial_value}'"]
                elif isinstance(initial_value, int):
                    cycle_dict_elements += [f"init={initial_value}"]
            return "{" + ",".join(cycle_dict_elements) + "}"
        elif self.generate_algorithm == FIELD.GenerateAlgorithm.cycle:
            cycle_dict_elements = []
            cycle_values = self.cycle_values
            if cycle_values:
                for val in cycle_values:
                    if isinstance(val, str):
                        cycle_dict_elements += [f"value='{val}'"]
                    elif isinstance(val, int):
                        cycle_dict_elements += [f"value={val}"]
            return "{" + ",".join(cycle_dict_elements) + "}"
        return ""

    def _get_random(self) -> str:
        random_dict_elements = []
        limit = self.random_limit
        if limit:
            limit = FieldModelComplex._get_enum_value(limit)
            if isinstance(limit, str):
                random_dict_elements += [f"limit='{limit}'"]
            elif isinstance(limit, int):
                random_dict_elements += [f"limit={limit}"]
        seed = self.random_seed
        if seed:
            seed = FieldModelComplex._get_enum_value(seed)
            if isinstance(seed, str):
                random_dict_elements += [f"seed='{seed}'"]
            elif isinstance(seed, int):
                random_dict_elements += [f"seed={seed}"]
        rand_signed = self.random_signed
        if rand_signed:
            random_dict_elements += ["signed"]
        return "{" + ",".join(random_dict_elements) + "}"

    @staticmethod
    def from_field_model(field_model: FieldModel) -> "FieldModelComplex":
        """Returns a FieldModelComplex from a FieldModel."""
        conversion_args = {
            "name": field_model.name,
            "type": field_model.type,
            "app_data": field_model.app_data,
            "metadata": field_model.metadata,
            "nullable": field_model.nullable,
        }

        assert field_model.app_data is not None
        if "odbc_type" in field_model.app_data:
            conversion_args["odbc_type"] = field_model.app_data["odbc_type"]
        else:
            raise Exception(
                "FieldModel was created without odbc data type, conversion to FieldModelComplex is impossible"
            )

        if "apt_field_properties" in field_model.app_data:
            conversion_args["apt_field_properties"] = field_model.app_data["apt_field_properties"]

        if (
            "dimension_min_size" in field_model.app_data
            and "dimension_max_size" in field_model.app_data
            and field_model.app_data["dimension_min_size"] == field_model.app_data["dimension_max_size"]
        ):
            conversion_args["occurs"] = field_model.app_data["dimension_min_size"]

        unicode = field_model.app_data.get("is_unicode_string", None)
        if unicode is not None:
            if unicode:
                conversion_args["unicode"] = FIELD.Unicode.true
            else:
                conversion_args["unicode"] = FIELD.Unicode.false

        extended_type = field_model.app_data.get("extended_type", None)
        if extended_type is not None:
            conversion_args["extended_type"] = FIELD.TimeExtendedType(extended_type)

        # if length is a consistent value (always if not default), then set length property.
        # Otherwise rely on existing default setting logic
        assert field_model.metadata is not None
        if (
            (
                conversion_args["odbc_type"] in ["BINARY", "CHAR", "WCHAR"]
                and field_model.metadata.min_length == field_model.metadata.max_length
            )
            or (
                conversion_args["odbc_type"] in ["DECIMAL", "NUMERIC", "TIME", "TIMESTAMP"]
                and field_model.metadata.decimal_precision == field_model.metadata.max_length
            )
            or (
                conversion_args["odbc_type"]
                in [
                    "WLONGVARCHAR",
                    "LONGVARBINARY",
                    "LONGVARCHAR",
                    "WVARCHAR",
                    "REAL",
                    "UNKNOWN",
                    "VARBINARY",
                    "VARCHAR",
                ]
            )
        ):
            conversion_args["length"] = field_model.metadata.max_length

        conversion_args["time_scale"] = field_model.app_data.get("time_scale", 0)

        conversion_args["scale"] = field_model.metadata.decimal_scale

        conversion_args["primary_key"] = field_model.metadata.is_key
        conversion_args["description"] = field_model.metadata.description
        conversion_args["signed"] = field_model.metadata.is_signed
        conversion_args["level_no"] = (
            field_model.metadata.item_index if field_model.metadata.item_index is not None else 0
        )

        return FieldModelComplex(**conversion_args)

    def get_field_model(self) -> "FieldModel":
        """Returns a field model."""
        self._validate_properties()
        extended_properties_app_data = self.app_data.copy()

        extended_properties_app_data["odbc_type"] = self.odbc_type

        apt_props = self._get_aptfieldproperties()
        if apt_props != "":
            extended_properties_app_data["apt_field_properties"] = apt_props

        if self.occurs is not None:
            extended_properties_app_data["dimension_min_size"] = f"{self.occurs}"
            extended_properties_app_data["dimension_max_size"] = f"{self.occurs}"

        if (
            self.vector_length_type == FIELD.VectorType.variable
            or self.vector_length_type == FIELD.VectorType.variable.value
        ):
            extended_properties_app_data["dimension_min_size"] = "0"

        if self.unicode == FIELD.Unicode.true or self.unicode == FIELD.Unicode.true.value:
            extended_properties_app_data["is_unicode_string"] = True
        elif self.unicode == FIELD.Unicode.false or self.unicode == FIELD.Unicode.false.value:
            extended_properties_app_data["is_unicode_string"] = False

        if self.extended_type is not None:
            extended_properties_app_data["extended_type"] = (
                self.extended_type.value
                if isinstance(self.extended_type, FIELD.TimeExtendedType)
                else self.extended_type
            )

        # Ensure metadata exists, create empty Metadata if None
        if self.metadata is None:
            self.metadata = Metadata()
        if self.length is not None:
            if self.odbc_type in ["BINARY", "CHAR", "WCHAR"]:
                self.metadata.min_length = self.length
                self.metadata.max_length = self.length
            elif self.odbc_type in ["DECIMAL", "NUMERIC", "TIME", "TIMESTAMP"]:
                self.metadata.max_length = self.length
                self.metadata.decimal_precision = self.length
            elif self.odbc_type in [
                "WLONGVARCHAR",
                "LONGVARBINARY",
                "LONGVARCHAR",
                "WVARCHAR",
                "REAL",
                "UNKNOWN",
                "VARBINARY",
                "VARCHAR",
            ]:
                self.metadata.max_length = self.length

        self.metadata.decimal_scale = self._get_scale()

        if self.time_scale is not None:
            self.app_data["time_scale"] = self.time_scale

        self.metadata.is_key = self.primary_key
        self.metadata.description = self.description
        self.metadata.is_signed = self.signed
        self.metadata.item_index = self.level_no if self.level_no is not None else 0

        if self.type_code is not None:
            extended_properties_app_data["type_code"] = self.type_code

        return FieldModel(
            name=self.name,
            type=self.type["type"] if isinstance(self.type, dict) else self.type,
            nullable=self.nullable,
            metadata=self.metadata,
            app_data=extended_properties_app_data,
        )

    def serialize_to_data_definition_column(self) -> dict[str, Any]:
        """Serialize a data defintiion column."""
        self._validate_properties()
        dumped: dict[str, Any] = {"name": self.name}
        dumped["type"] = self._get_type_props()
        dumped["properties"] = self._get_properties_props()

        return dumped

    def _get_type_props(self) -> dict[str, Any]:
        props = {"length", "scale", "nullable", "signed"}
        dumped = self.model_dump(include=props, by_alias=True)
        dumped["length"] = self._get_length()
        dumped["scale"] = self._get_scale()
        type_mapping = {
            "WCHAR": "NCHAR",
            "WVARCHAR": "NVARCHAR",
            "WLONGVARCHAR": "LONGNVARCHAR",
        }
        odbc_type = self.odbc_type or "UNKNOWN"
        dumped["type"] = type_mapping.get(odbc_type, odbc_type)

        return dumped

    def _get_properties_props(self) -> dict[str, Any]:
        include_props: set[str] = {
            "Maps_from_input_column",
            "alphabet",
            "charset",
            "data_element",
            "default",
            "delim",
            "delim_string",
            "description",
            "display_size",
            "ds_data_type",
            "ds_scd_purpose",
            "ds_sync_indicator",
            "export_ebcdic_as_ascii",
            "unicode",
            "extended_precision",
            "field_pos",
            "generate",
            "key_position",
            "link_keep",
            "max_width",
            "occurs_varying",
            "pad_char",
            "padchar",
            "start_position",
            "primary_key",
            "quote",
            "sign_option",
            "byte_to_skip",
            "sqltype",
            "tagcase",
            "tagged_subrec",
            "time_scale",
            "width",
        }
        # add optional properties
        optional_props = {"occurs", "level_no", "extended_type"}
        include_props.update(optional_props)

        # special case for TIMESTAMP data type
        if self.extended_type is None and self.odbc_type == "TIMESTAMP":
            self.extended_type = " "  # type: ignore[assignment]

        dumped: dict = json.loads(
            self.model_dump_json(
                include=include_props,
                by_alias=True,
            )
        )

        # remove optional properties if unset
        for optional_prop in optional_props:
            if dumped[optional_prop] is None:
                dumped.pop(optional_prop)

        dumped["APTFieldProperties"] = self._get_aptfieldproperties()
        dumped["MisFieldProperties"] = self._get_misfieldproperties()
        default_overrides_for_unset_apt_properties = {
            "position": 0,
            "tagcase": 0,
            "default": "",
            "max_width": 0,
            "width": 0,
            "charset": "",
            "padchar": "",
            "delim": "",
            "delim_string": "",
            "time_scale": 0,
            "quote": "",
            "alphabet": "",
        }

        for key, value in default_overrides_for_unset_apt_properties.items():
            if dumped[key] is None:
                dumped[key] = value

        # dealing with dominance of vector prefix over prefix
        if self.vector_prefix is not None:
            dumped["prefix"] = FieldModelComplex._get_enum_value(self.vector_prefix)
        elif self.prefix_bytes is not None:
            dumped["prefix"] = FieldModelComplex._get_enum_value(self.prefix_bytes)
        else:
            dumped["prefix"] = 0

        dumped["cycle"] = self._get_cycle()

        return dumped

    def _get_aptfieldproperties(self) -> str:
        if self.apt_field_properties is not None:
            return self.apt_field_properties
        string_props: set[str] = {
            "c_format",
            "default",
            "out_format",
            "padchar",
            "reference",
            "date_format",
            "decimal_separator",
            "timestamp_format",
            "delim_string",
            "delim",
            "null_field",
        }
        integer_props: set[str] = {
            "start_position",
            "tagcase",
            "default",
            "max_width",
            "width",
            "prefix_bytes",
            "vector_prefix",
            "days_since",
            "generated_percent_invalid",
            "epoch",
            "generated_percent_zeros",
            "precision",
            "time_scale_factor",
            "byte_to_skip",
            "actual_length",
            "null_length",
            "nullseed",
            "nulls",
        }
        # not sure if default could ever be a boolean
        boolean_props: set[str] = {
            "generate",
            "link_keep",
            "export_ebcdic_as_ascii",
            "julian",
            "check_decimal_packed",
            "midnight_seconds",
        }
        # Some enums may be included in strings if they are represented internally that way
        enum_props: set[str] = {
            "byte_order",
            "charset",
            "data_format",
            "sign_position",
            "allow_all_zeros",
            "decimal_packed",
        }
        all_props: set[str] = string_props | integer_props | boolean_props | enum_props
        prop_dict: dict = json.loads(self.model_dump_json(include=all_props, by_alias=True))
        fields: list[str] = []
        integer_prop_aliases = {
            "position",
            "prefix",
            "invalids",
            "zeros",
            "_scale",
            "skip",
        }
        boolean_prop_aliases = {"generate", "check"}
        enum_prop_aliases = {}
        for key, value in prop_dict.items():
            if key == "padchar" and value == "null":
                fields += [f"{key}={value}"]
            elif key == "round" and value:
                fields += [f"{key}={value}"]
            elif (key in string_props) and isinstance(value, str):
                fields += [f"{key}='{value}'"]
            elif (key in integer_props or key in integer_prop_aliases) and isinstance(value, int):
                fields += [f"{key}={value}"]
            elif (key in boolean_props or key in boolean_prop_aliases) and isinstance(value, bool) and value:
                fields += [f"{key}"]
            elif (key in enum_props or key in enum_prop_aliases) and value is not None:
                fields += [f"{value}"]

        cycle_val = self._get_cycle()
        if cycle_val:
            fields += [f"cycle={cycle_val}"]

        if self.generate_type == FIELD.GenerateType.random:
            fields += [f"random={self._get_random()}"]
        elif self.generate_algorithm == FIELD.GenerateAlgorithm.alphabet:
            fields += [f"alphabet={self.alphabet}"]

        if self.use_current_date:
            fields += ["function=rundate"]

        if self.rounding:
            fields += [f"round={self.rounding.value}"]

        if self.increment_scale is not None:
            fields += [f"scale={self.increment_scale}"]

        if self.decimal_packed_signed:
            fields += ["signed"]

        if self.quote is not None:
            fields += [f"quote={self.quote.value}"]

        return ",".join(fields)

    def _get_misfieldproperties(self) -> str:
        fields: list[str] = []
        if self.occurs is not None:
            fields += [f"dimension_min_size={self.occurs}"]
        elif self.dimension_min_size is not None:
            fields += [f"dimension_min_size={self.dimension_min_size}"]
        if self.level_no is not None:
            fields += [f"LevelNumber={self.level_no}"]
        return "|".join(fields)

    @classmethod
    def from_data_definition_column_dict(cls, _dict: dict) -> "FieldModelComplex":
        """Initialize a DataDefinitionColumn object from a json dictionary."""
        args = {}
        if (name := _dict.get("name")) is not None:
            args["name"] = name
        else:
            raise ValueError("Required property 'name' not present in DataDefinitionColumn JSON")
        type_dict = _dict.get("type")
        if type_dict is not None and (type := type_dict.get("type")) is not None:
            args["odbc_type"] = type
        else:
            raise ValueError("Required property 'type' not present in DataDefinitionColumn JSON")
        if type_dict is not None and (length := type_dict.get("length")) is not None:
            args["length"] = length
        else:
            args["length"] = None
        if type_dict is not None and (scale := type_dict.get("scale")) is not None:
            args["scale"] = scale
        else:
            args["scale"] = None
        if type_dict is not None and (nullable := type_dict.get("nullable")) is not None:
            args["nullable"] = nullable
        else:
            args["nullable"] = None
        if type_dict is not None and (signed := type_dict.get("signed")) is not None:
            args["signed"] = signed
        else:
            args["signed"] = None
        properties_keys = {
            "APTFieldProperties",
            "Maps from input column",
            # "MisFieldProperties",
            "alphabet",
            "charset",
            "cycle",
            "data_element",
            "default",
            "delim",
            "delim_string",
            "description",
            "display_size",
            "ds_data_type",
            "ds_scd_purpose",
            "ds_sync_indicator",
            "export_ebcdic_as_ascii",
            "extended",
            "extended_precision",
            "field_pos",
            "generate",
            "key_position",
            "link_keep",
            "max_width",
            "occurs_varying",
            "pad_char",
            "padchar",
            "position",
            "prefix",
            "primary_key",
            "quote",
            "sign_option",
            "skip",
            "sqltype",
            "tagcase",
            "tagged_subrec",
            "time_scale",
            "width",
        }

        optional_properties_keys = {"occurs"}

        enum_mappings = {
            "extended": FIELD.Unicode,
            "delim": FIELD.Delim,
            "quote": FIELD.Quote,
            "charset": FIELD.CharSet,
            "padchar": FIELD.PadChar,
        }

        inverse_alias_map = {
            "extended": "unicode",
            "level_no": "level_no",
            "Maps from input column": "Maps_from_input_column",
            "skip": "byte_to_skip",
            "generate": "generate",
        }
        # TODO: deal with prefix vs vector_prefix here, dominance, etc.

        properties_dict: dict = _dict.get("properties") or {}

        enums_with_invalid_empty_str_defaults = {
            "quote",
            "charset",
            "padchar",
            "delim",
            "delim_string",
        }
        for key in enums_with_invalid_empty_str_defaults:
            if properties_dict.get(key) == "":
                properties_dict[key] = None
                args[key] = None
                properties_keys.remove(key)

        apt_field_props_str = properties_dict.get("APTFieldProperties")
        if apt_field_props_str and "vector_prefix" in apt_field_props_str and properties_dict.get("prefix") != 0:
            args["vector_prefix"] = FIELD.VectorPrefix(properties_dict.get("prefix"))
        elif properties_dict.get("prefix", 0) != 0:
            args["prefix_bytes"] = FIELD.Prefix(properties_dict.get("prefix"))
        properties_keys.remove("prefix")
        args["prefix_bytes"] = args.get("prefix_bytes", None)

        if apt_field_props_str and ("vector_prefix" in apt_field_props_str or "reference" in apt_field_props_str):
            args["dimension_min_size"] = "0"

        args["vector_prefix"] = args.get("vector_prefix", None)

        for key in properties_keys:
            if (key_value := properties_dict.get(key)) is not None:
                args[inverse_alias_map.get(key, key)] = FieldModelComplex._get_value_from_json_value(
                    key_value, enum_mappings.get(key, None)
                )
            else:
                args[inverse_alias_map.get(key, key)] = None

        for key in optional_properties_keys:
            if (key_value := properties_dict.get(key)) is not None:
                args[inverse_alias_map.get(key, key)] = FieldModelComplex._get_value_from_json_value(
                    key_value, enum_mappings.get(key, None)
                )

        # parse misfieldproperties
        misfield_props = properties_dict.get("MisFieldProperties")
        if misfield_props:
            dim_min_size_search = re.search(r"dimension_min_size=(\d+)", misfield_props)
        else:
            dim_min_size_search = None
        if dim_min_size_search is not None:
            dim_min_size_value = int(dim_min_size_search.group(1))
            # if vector length is variable, then dim_min_size is set to 0 when vector occurs propogates
            if dim_min_size_value == 0 and properties_dict.get("occurs") != 0:
                args["vector_length_type"] = FIELD.VectorType.variable
                args["occurs"] = None
                args["dimension_min_size"] = "0"
            else:
                args["occurs"] = dim_min_size_value
        elif properties_dict.get("occurs", 0) != 0:
            args["occurs"] = properties_dict.get("occurs")
        else:
            args["occurs"] = None
        args["dimension_min_size"] = args.get("dimension_min_size", args["occurs"])

        args["vector_length_type"] = args.get("vector_length_type", None)

        if misfield_props:
            level_number_search = re.search(r"LevelNumber=(\d+)", misfield_props)
        else:
            level_number_search = None
        if level_number_search is not None:
            args["level_no"] = int(level_number_search.group(1))
        else:
            args["level_no"] = None

        odbc_type: str = args["odbc_type"]

        odbc_type_to_type = {
            "BIGINT": "integer",
            "BINARY": "binary",
            "BIT": "boolean",
            "CHAR": "string",
            "DATE": "date",
            "DECIMAL": "double",
            "DOUBLE": "double",
            "FLOAT": "double",
            "INTEGER": "integer",
            "WLONGVARCHAR": "string",
            "LONGNVARCHAR": "string",
            "LONGVARBINARY": "binary",
            "LONGVARCHAR": "string",
            "WCHAR": "string",
            "NCHAR": "string",
            "NUMERIC": "double",
            "WVARCHAR": "string",
            "NVARCHAR": "string",
            "REAL": "double",
            "SMALLINT": "integer",
            "TIME": "time",
            "TIMESTAMP": "timestamp",
            "TINYINT": "integer",
            "UNKNOWN": "string",
            "VARBINARY": "binary",
            "VARCHAR": "string",
        }
        args["type"] = odbc_type_to_type[odbc_type]

        odbc_type_to_type_code = {
            "BIGINT": "INT64",
            "BINARY": "BINARY",
            "BIT": "BOOLEAN",
            "CHAR": "STRING",
            "DATE": "DATE",
            "DECIMAL": "DECIMAL",
            "DOUBLE": "DFLOAT",
            "FLOAT": "SFLOAT",
            "INTEGER": "INT32",
            "WLONGVARCHAR": "STRING",
            "LONGNVARCHAR": "STRING",
            "LONGVARBINARY": "BINARY",
            "LONGVARCHAR": "STRING",
            "WCHAR": "STRING",
            "NCHAR": "STRING",
            "NUMERIC": "DECIMAL",
            "WVARCHAR": "STRING",
            "NVARCHAR": "STRING",
            "REAL": "SFLOAT",
            "SMALLINT": "INT16",
            "TIME": "TIME",
            "TIMESTAMP": "DATETIME",
            "TINYINT": "INT8",
            "UNKNOWN": "UNKNOWN",
            "VARBINARY": "BINARY",
            "VARCHAR": "STRING",
        }

        args["type_code"] = odbc_type_to_type_code[odbc_type]

        imported_metadata = Metadata(
            is_key=False,
            item_index=0,
            is_signed=True,
            description="",
            min_length=0,
            decimal_precision=100,
            decimal_scale=0,
        )
        # defaults: (min_length, max_length, decimal_precision, decimal_scale)
        odbc_type_to_metadata_updates = {
            "BIGINT": (0, 6),
            "BINARY": (100, 100, 0),
            "BIT": (6, 6),
            "CHAR": (100, 100, 0),
            "DATE": (0, 10),
            "DECIMAL": (0, 100),
            "DOUBLE": (0, 6),
            "FLOAT": (0, 6),
            "INTEGER": (0, 6),
            "WLONGVARCHAR": (0, 100),
            "LONGNVARCHAR": (0, 100),
            "LONGVARBINARY": (0, 100),
            "LONGVARCHAR": (0, 100),
            "WCHAR": (100, 100),
            "NCHAR": (100, 100),
            "NUMERIC": (0, 100),
            "WVARCHAR": (0, 100),
            "NVARCHAR": (0, 100),
            "REAL": (0, 100),
            "SMALLINT": (0, 6),
            "TIME": (0, 8, 8, 0),
            "TIMESTAMP": (0, 19, 19, 0),
            "TINYINT": (0, 6),
            "UNKNOWN": (0, 100),
            "VARBINARY": (0, 100),
            "VARCHAR": (0, 100),
        }

        metadata_updates = odbc_type_to_metadata_updates[odbc_type]

        imported_metadata.min_length = metadata_updates[0]
        imported_metadata.max_length = metadata_updates[1]
        if len(metadata_updates) > 2:
            imported_metadata.decimal_precision = metadata_updates[2]
        if len(metadata_updates) > 3:
            imported_metadata.decimal_scale = metadata_updates[3]

        args["metadata"] = imported_metadata
        args["app_data"] = {"time_scale": args.get("time_scale", 0)}

        if "extended_type" in properties_dict and properties_dict["extended_type"] != " ":
            args["extended_type"] = FieldModelComplex._get_value_from_json_value(
                properties_dict["extended_type"], FIELD.TimeExtendedType
            )
        args["extended_type"] = args.get("extended_type", None)

        return FieldModelComplex(
            name=args["name"],
            metadata=args["metadata"],
            app_data=args["app_data"],
            type=args["type"],
            type_code=args["type_code"],
            odbc_type=args["odbc_type"],
            length=args["length"],
            scale=args["scale"],
            nullable=args["nullable"],
            signed=args["signed"],
            pad_char=args["pad_char"],
            primary_key=args["primary_key"],
            max_width=args["max_width"],
            tagged_subrec=args["tagged_subrec"],
            width=args["width"],
            Maps_from_input_column=args["Maps_from_input_column"],  # type: ignore[arg-type]
            quote=args["quote"],
            tagcase=args["tagcase"],
            alphabet=args["alphabet"],
            delim_string=args["delim_string"],
            cycle=args["cycle"],
            byte_to_skip=args["byte_to_skip"],  # type: ignore[arg-type]
            generate=args["generate"],
            ds_sync_indicator=args["ds_sync_indicator"],
            ds_scd_purpose=args["ds_scd_purpose"],
            vector_prefix=args["vector_prefix"],
            prefix_bytes=args["prefix_bytes"],  # type: ignore[arg-type]
            display_size=args["display_size"],
            padchar=args["padchar"],
            data_element=args["data_element"],
            field_pos=args["field_pos"],
            description=args["description"],
            position=args["position"],
            sign_option=args["sign_option"],
            default=args["default"],
            sqltype=args["sqltype"],
            occurs_varying=args["occurs_varying"],
            time_scale=args["time_scale"],
            charset=args["charset"],
            unicode=args["unicode"],  # type: ignore[arg-type]
            delim=args["delim"],
            key_position=args["key_position"],
            ds_data_type=args["ds_data_type"],
            apt_field_properties=args["APTFieldProperties"],
            extended_precision=args["extended_precision"],
            link_keep=args["link_keep"],
            export_ebcdic_as_ascii=args["export_ebcdic_as_ascii"],
            occurs=args["occurs"],
            level_no=args["level_no"],
            vector_length_type=args["vector_length_type"],
            dimension_min_size=args["dimension_min_size"],
            extended_type=args["extended_type"],  # type: ignore[arg-type]
        )

    @staticmethod
    def _get_value_from_json_value(
        internal_value: str | int, enum_type: builtins.type[Enum] | None
    ) -> Enum | str | int:
        if enum_type is None:
            return internal_value
        return enum_type(internal_value)

    @staticmethod
    def _get_enum_value(possible_enum: Enum | int | str) -> Enum | int | str:
        if isinstance(possible_enum, Enum):
            return possible_enum.value
        else:
            return possible_enum

    def _validate_properties(self) -> None:
        prop_to_incompatible_props: dict[str, set] = {
            "date_format": {"days_since", "julian", "data_format"},
            "reference": {"delim_string", "delim", "quote", "prefix_bytes"},
            "prefix_bytes": {"delim_string", "delim", "quote", "reference"},
            "days_since": {"data_format", "julian", "date_format"},
            "julian": {"days_since", "data_format", "date_format"},
            "data_format": {"days_since", "julian", "date_format"},
            "delim": {"delim_string", "prefix_bytes"},
            "delim_string": {"delim", "prefix_bytes"},
            "quote": {"prefix_bytes"},
            "actual_length": {"null_field"},
            "null_length": {"null_field"},
            "null_field": {"actual_length", "null_length"},
        }
        for prop, incompatible_props in prop_to_incompatible_props.items():
            self._validate_prop_with_incompatibilities(prop, incompatible_props)

        sub_properties_to_valid_super_props: dict[str, list[tuple[str, Any]]] = {
            # subproperty: [(superproperty name, valid superproperty value), ...]
            "reference": [("vector_length_type", FIELD.VectorType.variable)],
            "vector_prefix": [("vector_length_type", FIELD.VectorType.variable)],
            "check_decimal_packed": [("decimal_packed", FIELD.DecimalPacked.packed)],
            "decimal_packed_signed": [
                ("decimal_packed", FIELD.DecimalPacked.packed),
                ("decimal_packed", FIELD.DecimalPacked.zoned),
            ],
            "sign_position": [
                ("decimal_packed", FIELD.DecimalPacked.overpunch),
                ("decimal_packed", FIELD.DecimalPacked.separate),
                ("decimal_packed", FIELD.DecimalPacked.zoned),
            ],
            "occurs": [("vector_length_type", FIELD.VectorType.vector_occurs)],
            "cycle_increment": [("generate_type", FIELD.GenerateType.cycle)],
            "cycle_initial_value": [("generate_type", FIELD.GenerateType.cycle)],
            "cycle_limit": [("generate_type", FIELD.GenerateType.cycle)],
            "cycle_values": [("generate_algorithm", FIELD.GenerateAlgorithm.cycle)],
            "alphabet": [("generate_algorithm", FIELD.GenerateAlgorithm.alphabet)],
            "actual_length": [("nullable", True)],
            "null_length": [("nullable", True)],
            "null_field": [("nullable", True)],
            "nullseed": [("nullable", True)],
            "nulls": [("nullable", True)],
        }

        for sub_prop, valid_super_props in sub_properties_to_valid_super_props.items():
            self._validate_subproperty(sub_prop, valid_super_props)

    def _validate_prop_with_incompatibilities(self, prop: str, incompatible_props: set[str]) -> None:
        dumped = self.model_dump(include=(incompatible_props | {prop}))
        if dumped[prop] is not None:
            for incompat_prop in incompatible_props:
                if dumped[incompat_prop] is not None:
                    logger.warning(
                        "Property '%s' set on field '%s', despite incompatible property '%s' also being set.",
                        prop,
                        self.name,
                        incompat_prop,
                    )

    def _validate_subproperty(self, sub_prop: str, valid_super_props: list[tuple[str, Any]]) -> None:
        super_prop_names = set([super_prop[0] for super_prop in valid_super_props])
        dumped = self.model_dump(include=(super_prop_names | {sub_prop}))
        if dumped[sub_prop] is None:
            return
        for super_prop_name, super_prop_valid_value in valid_super_props:
            if dumped[super_prop_name] == super_prop_valid_value:
                return
        logger.warning(
            "Subproperty '%s' set without required/compatible "
            "superproperties being set on field '%s'."
            " Possible superproperties that could be set for subproperty include: %s.",
            sub_prop,
            self.name,
            super_prop_names,
        )


class Comment(BaseModel):
    """Model for comments."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str
    x_pos: float | None
    y_pos: float | None
    width: Annotated[float, Field(ge=10.0)]
    height: Annotated[float, Field(ge=10.0)]
    class_name: str | None = None
    style: str | dict[str, Any] | None = None
    attributes: str | None = None
    content: str | None = None
    content_type: str | None = Field(None, alias="contentType")
    associated_id_refs: list[CommentLink] | None = None

    TEXT_SIZES: ClassVar[set] = {10, 11, 12, 14, 18, 24, 30, 36, 48, 60, 72, 96}

    class TextDecoration(Enum):
        """Enum for text decoration."""

        UNDERLINE = "underline"

    class HAlign(Enum):
        """Enum for horizontal align."""

        LEFT = "align-left"
        MIDDLE = "align-middle"
        RIGHT = "align-right"

    class VAlign(Enum):
        """Enum for vertical align."""

        TOP = "align-top"
        CENTER = "align-center"
        BOTTOM = "align-bottom"

    @property
    def bold(self) -> bool:
        """Bold property."""
        return self._get_field("bold")

    @bold.setter
    def bold(self, bold: bool = True) -> None:
        """Setter to bold or unbold the text."""
        if not bold:
            return self.__del_format("bold")
        return self.__set_format("bold")

    @property
    def italics(self) -> bool:
        """Italics property."""
        return self._get_field("italics")

    @italics.setter
    def italics(self, italics: bool = True) -> None:
        """Setter to italicize or un-italicize the text."""
        if not italics:
            return self.__del_format("italics")
        return self.__set_format("italics")

    @property
    def font(self) -> str:
        """Font property."""
        return self._get_field("fontType")

    @font.setter
    def font(self, font: str) -> None:
        """Setter to set the font of the text."""
        if " " in font:
            # Converts a font name like 'IBM Plex Sans Condensed' into 'font-ibm-plex-sans-condensed'
            font = "font-" + font.replace(" ", "-").lower()
        return self.__set_format("fontType", font)

    @property
    def text_decoration(self) -> TextDecoration | str:
        """Text decoration property."""
        return self._get_field("textDecoration")

    @text_decoration.setter
    def text_decoration(self, decoration: TextDecoration | str) -> None:
        """Setter to set the text decoration of the text."""
        if isinstance(decoration, str):
            return self.__set_format("textDecoration", decoration)
        return self.__set_format("textDecoration", decoration.value)

    @property
    def background_color(self) -> str:
        """Background color property."""
        return self._get_field("backgroundColor")

    @background_color.setter
    def background_color(self, color: str) -> None:
        """Setter to set the background color of the text."""
        return self.__set_format("backgroundColor", color)

    @property
    def text_color(self) -> str:
        """Text color property."""
        return self._get_field("textColor")

    @text_color.setter
    def text_color(self, color: str) -> None:
        """Setter to set the text color of the text."""
        return self.__set_format("textColor", color)

    @property
    def vertical_align(self) -> VAlign | str:
        """Vertical align property."""
        return self._get_field("alignVertically")

    @vertical_align.setter
    def vertical_align(self, align: VAlign | str) -> None:
        """Setter to set the vertical alignment of the text."""
        if isinstance(align, str):
            return self.__set_format("alignVertically", align)
        return self.__set_format("alignVertically", align.value)

    @property
    def horizontal_align(self) -> HAlign | str:
        """Horizontal align property."""
        return self._get_field("alignHorizontally")

    @horizontal_align.setter
    def horizontal_align(self, align: HAlign | str) -> None:
        """Setter to set the horizontal alignment of the text."""
        if isinstance(align, str):
            return self.__set_format("alignHorizontally", align)
        return self.__set_format("alignHorizontally", align.value)

    @property
    def text_size(self) -> int:
        """Text size property."""
        return self._get_field("textSize")

    @text_size.setter
    def text_size(self, size: int) -> None:
        """Setter to set the text size of the text."""
        if size not in self.TEXT_SIZES:
            raise ValueError(f"Invalid text size: {size}. Valid sizes: {self.TEXT_SIZES}")
        return self.__set_format("textSize", f"text-size-{size}")

    @property
    def outline(self) -> bool:
        """Outline property."""
        return self._get_field("outlineStyle")

    @outline.setter
    def outline(self, outline: bool = True) -> None:
        """Setter to set the outline of the comment."""
        if not outline:
            return self.__set_format("outlineStyle", "outline-none")
        return self.__del_format("outlineStyle")

    @property
    def line_height(self) -> float:
        """Line height property."""
        return self._get_field("line-height")

    @line_height.setter
    def line_height(self, height: float) -> None:
        """Setter to set the line height of the comment (probably only legacy)."""
        return self.__set_format("line-height", f"{height}")

    @property
    def letter_spacing(self) -> str:
        """Letter spacing property."""
        return self._get_field("letter-spacing")

    @letter_spacing.setter
    def letter_spacing(self, spacing: str) -> None:
        """Setter to set the letter spacing of the comment (probably only legacy)."""
        return self.__set_format("letter-spacing", spacing)

    @property
    def border_color(self) -> str:
        """Border color property."""
        return self._get_field("border-color")

    @border_color.setter
    def border_color(self, color: str) -> None:
        """Setter to set the border color of the comment (probably only legacy)."""
        return self.__set_format("border-color", color)

    @property
    def padding(self) -> str:
        """Padding property."""
        return self._get_field("padding")

    @padding.setter
    def padding(self, padding: str) -> None:
        """Setter to set padding of the comment (probably only legacy)."""
        return self.__set_format("padding", padding)

    def __set_format(self, typ: str, value: str | None = None) -> None:
        # Clear any existing format of the same type
        self.__del_format(typ)

        # Add the new format
        fmt = {"type": typ}
        if value:
            fmt["value"] = value
        self.formats.append(fmt)

        return self

    def __del_format(self, typ: str) -> None:
        self.formats = [fmt for fmt in self.formats if fmt["type"] != typ]
        return self

    def _get_field(self, typ: str) -> bool | int | str | float | TextDecoration | VAlign | HAlign:
        for fmt in self.formats:
            if fmt["type"] == typ:
                if fmt.get("value"):
                    return fmt.get("value")
                else:
                    return True
        return f"Cannot find field {typ}"


class ImageDecoration(DecorationSharedProperties):
    """Model for image decoration."""

    image: str | None = None
    outline: bool | None = None


class LabelDecoration(DecorationSharedProperties):
    """Model for label decoration."""

    label: str | None = None
    label_editable: bool | None = None
    label_align: LabelAlign | None = None
    label_single_line: bool | None = None
    label_max_characters: int | None = None
    label_allow_return_key: bool | None = None


class ShapeDecoration(DecorationSharedProperties):
    """Model for shape decoration."""

    path: str | None = None


class JsxDecoration(DecorationSharedProperties):
    """Model for jsx decoration."""

    jsx: dict[str, Any] | None = None


class StructTypes(BaseModel):
    """Model for struct types."""

    fields: list[FieldModel] | None = None


class RecordSchema(BaseModel):
    """Model for record schema."""

    id: str
    name: str | None = None
    json_schema: JsonSchema1 | None = None
    type: str | None = None
    fields: list[FieldModel | FieldModelComplex] | list[FieldModel]
    struct_types: dict[Annotated[str, Field(pattern=r".")], StructTypes] | None = None


class PipelineUI(BaseModel):
    """Model for pipeline ui."""

    model_config = ConfigDict(extra="allow")

    description: str | None = None
    zoom: ZoomObjectDef | None = None
    comments: list[Comment] | None = None


class NodeDecoration1(ImageDecoration):
    """Model for node decoration image."""

    position: Position | None = None


class NodeDecoration2(LabelDecoration):
    """Model for node decoration label."""

    position: Position | None = None


class NodeDecoration3(ShapeDecoration):
    """Model for node decoration shape."""

    position: Position | None = None


class NodeDecoration4(JsxDecoration):
    """Model for node decoration jsx."""

    position: Position | None = None


class NodeDecoration(RootModel[NodeDecoration1 | NodeDecoration2 | NodeDecoration3 | NodeDecoration4]):
    """Model for node decoration."""

    pass


class LinkDecoration1(ImageDecoration):
    """Model for link decoration image."""

    position: Position2 | None = None
    distance: int | None = None


class LinkDecoration2(LabelDecoration):
    """Model for link decoration label."""

    position: Position2 | None = None
    distance: int | None = None


class LinkDecoration3(ShapeDecoration):
    """Model for link decoration shape."""

    position: Position2 | None = None
    distance: int | None = None


class LinkDecoration4(JsxDecoration):
    """Model for link decoration jsx."""

    position: Position2 | None = None
    distance: int | None = None


class LinkDecoration(RootModel[LinkDecoration1 | LinkDecoration2 | LinkDecoration3 | LinkDecoration4]):
    """Model for link decoration."""

    pass


class PipelineAppData(BaseModel):
    """Model for app data for pipelines."""

    model_config = ConfigDict(extra="allow")

    ui_data: PipelineUI | None = None


class Decoration(RootModel[NodeDecoration | LinkDecoration]):
    """Model for all decorations."""

    pass


class NodeLinkUI(BaseModel):
    """Model for node link ui."""

    model_config = ConfigDict(extra="allow")

    description: str | None = None
    class_name: str | None = None
    style: str | dict[str, Any] | None = None
    decorations: list[Decoration] | None = None


class LinkAppData(BaseModel):
    """Model for app data for links."""

    model_config = ConfigDict(extra="allow")

    ui_data: NodeLinkUI | None = None


class NodeLink(BaseModel):
    """Model for node links."""

    model_config = ConfigDict(extra="forbid")

    id: str | None = None
    node_id_ref: str
    port_id_ref: str | None = None
    link_name: str | None = None
    type_attr: str | None = None
    description: str | None = None
    app_data: LinkAppData | None = None


class AssociationLink(BaseModel):
    """Model for association links."""

    model_config = ConfigDict(extra="forbid")

    id: str
    node_ref: str
    class_name: str | None = None
    style: str | dict[str, Any] | None = None
    decorations: list[Decoration] | None = None


class Port(BaseModel):
    """Model for ports."""

    model_config = ConfigDict(extra="forbid")

    id: str
    schema_ref: str | None = None
    links: list[NodeLink] | None = None
    parameters: dict[str, Any] | None = None
    app_data: PortAppData | None = None


class BoundPort(BaseModel):
    """Model for bound ports."""

    model_config = ConfigDict(extra="forbid")

    id: str = Field(...)
    schema_ref: str | None = None
    links: list[NodeLink] | None = None
    subflow_node_ref: str | None = None
    parameters: dict[str, Any] | None = None
    app_data: PortAppData | None = None


class NodeUI(BaseModel):
    """Model for node ui."""

    model_config = ConfigDict(extra="allow")

    label: str | None = None
    description: str | None = None
    class_name: str | None = None
    style: str | dict[str, Any] | None = None
    image: str | dict[str, Any] | None = None
    x_pos: float | None = None
    y_pos: float | None = None
    is_expanded: bool | None = None
    expanded_height: float | None = None
    expanded_width: float | None = None
    is_resized: bool | None = None
    resize_height: float | None = None
    resize_width: float | None = None
    sub_pipelines: list | None = None
    attributes: str | None = None
    associations: list[AssociationLink] | None = None
    messages: list[Message] | None = None
    ui_parameters: dict[str, Any] | None = None
    palette_image: str | None = None
    palette_class_name: str | None = None
    palette_disabled: bool | None = None
    decorations: list[Decoration] | None = None


class NodeAppData(BaseModel):
    """Model for app data for nodes."""

    model_config = ConfigDict(extra="allow")

    ui_data: NodeUI | None = None


def _get_node_discriminator(v: dict | object) -> str:
    if isinstance(v, dict):
        node_type = v.get("type")
        inputs = v.get("inputs")
        outputs = v.get("outputs")
    else:
        node_type = getattr(v, "type")
        inputs = getattr(v, "inputs", None)
        outputs = getattr(v, "outputs", None)
    if node_type == "binding":
        if inputs and outputs:
            return "binding_solo_node"
        elif outputs:
            return "binding_entry_node"
        elif inputs:
            return "binding_exit_node"
        else:
            raise ValueError("Binding node is none of the three binding types")
    else:
        return str(node_type) if node_type else ""


class Node(BaseModel):
    """Model for nodes."""

    model_config = ConfigDict(extra="forbid")

    type: str
    id: str
    description: str | None = None
    app_data: NodeAppData | None = None


class ExecutionNode(Node):
    """Model for execution nodes."""

    type: Literal["execution_node"] = "execution_node"  # type: ignore[assignment]
    op: str
    inputs: list[Port] | None = None
    outputs: list[Port] | None = None
    parameters: dict[str, Any] | None = None
    runtime_ref: str | None = None


class BindingEntryNode(Node):
    """Model for binding nodes."""

    type: Literal["binding"] = "binding"  # type: ignore[assignment]
    outputs: list[Port]
    connection: CommonPipelineConnection | None = None
    data_asset: CommonPipelineDataAsset | None = None
    op: str | None = None
    parameters: dict[str, Any] | None = None


class BindingExitNode(Node):
    """Model for binding exit nodes."""

    type: Literal["binding"] = "binding"  # type: ignore[assignment]
    inputs: list[Port]
    outputs: list[Port] | None = None
    connection: CommonPipelineConnection | None = None
    data_asset: CommonPipelineDataAsset | None = None
    op: str | None = None
    parameters: dict[str, Any] | None = None


class BindingSoloNode(Node):
    """Model for binding node with no links."""

    type: Literal["binding"] = "binding"
    inputs: list[Port] = [{"id": ""}]
    outputs: list[Port] = [{"id": ""}]
    connection: CommonPipelineConnection | None = None
    data_asset: CommonPipelineDataAsset | None = None
    op: str | None = None
    parameters: dict[str, Any] | None = None


class ModelNode(Node):
    """Model for model nodes."""

    type: Literal["model_node"] = "model_node"  # type: ignore[assignment]
    model_ref: str | None = None
    inputs: list[Port]
    outputs: list[Port] | None = None
    op: str | None = None
    parameters: dict[str, Any] | None = None
    runtime_ref: str | None = None


class Supernode(Node):
    """Model for super nodes."""

    type: Literal["super_node"] = "super_node"  # type: ignore[assignment]
    open_with_tool: str | None = None
    subflow_ref: SubflowRef
    inputs: list[Port | BoundPort] | None = None
    outputs: list[Port | BoundPort] | None = None
    parameters: dict[str, Any] | None = None


class Pipeline(BaseModel):
    """Model for pipelines."""

    model_config = ConfigDict(extra="forbid")

    id: str
    description: str | None = None
    name: str | None = None
    runtime_ref: str
    nodes: list[
        Annotated[
            Annotated[Supernode, Tag("super_node")]
            | Annotated[BindingEntryNode, Tag("binding_entry_node")]
            | Annotated[BindingExitNode, Tag("binding_exit_node")]
            | Annotated[BindingSoloNode, Tag("binding_solo_node")]
            | Annotated[ModelNode, Tag("model_node")]
            | Annotated[ExecutionNode, Tag("execution_node")],
            Discriminator(_get_node_discriminator),
        ]
    ]
    parameters: dict[str, Any] | None = None
    app_data: PipelineAppData | None = None


class Flow(BaseModel):
    """Overall model for flow JSON."""

    model_config = ConfigDict(extra="forbid", use_enum_values=True)

    doc_type: str | None = "pipeline"
    version: Version = Version.v3
    json_schema: JsonSchema | None = JsonSchema.https
    open_with_tool: str | None = None
    id: str | None = None
    parameters: dict[str, Any] | None = None
    primary_pipeline: str
    pipelines: list[Pipeline]
    schemas: list[RecordSchema] | None = None
    runtimes: list[Runtime] | None = None
    external_paramsets: list[ParamSetReference] | None = None
    app_data: AppData | None = None
    name: str | None = None
