#  IBM Confidential
#  PID 5900-BAF
#  Copyright StreamSets Inc., an IBM Company 2025

"""Module containing the Data Definition API client."""

import json
import requests
from ibm_watsonx_data_integration.common.constants import PROD_BASE_URL
from ibm_watsonx_data_integration.cpd_api.base import BaseAPIClient
from typing import TYPE_CHECKING
from urllib.parse import quote

if TYPE_CHECKING:
    from ibm_watsonx_data_integration.common.auth import BaseAuthenticator

DEFAULT_TABLE_DEFINITIONS_API_VERSION = 3


class DataDefinitionApiClient(BaseAPIClient):
    """Api Client for Data Definition endpoints."""

    def __init__(
        self,
        auth: "BaseAuthenticator",  # pragma: allowlist secret
        base_url: str = PROD_BASE_URL,
    ) -> None:
        """The __init__ of the DataDefinitionApiClient.

        Args:
            auth: The Authentication object.
            base_url: The Cloud Pak for Data URL.
        """
        super().__init__(auth=auth, base_url=base_url)
        self.url_path = f"data_intg/v{DEFAULT_TABLE_DEFINITIONS_API_VERSION}/table_definitions"

    def create_data_definition(
        self,
        project_id: str,
        data: dict,
        params: dict | None = None,
    ) -> requests.Response:
        """Create a new table definition (data definition) in a project.

        Creates a table definition asset in the specified project. Table definitions
        define the structure and properties of data tables that can be used in DataStage flows.

        Args:
            project_id: The ID of the project to use.
            data: Request body containing metadata and entity.
                Required structure:
                {
                    'metadata': {
                        'name': str,
                        'description': str (optional)
                    },
                    'entity': {
                        'data_asset': {...},
                        'column_info': {...},
                        'data_definition': {...},
                        'ds_info': {...}
                    }
                }
            params: Additional query parameters.

        Returns:
            A HTTP response.
        """
        if not project_id:
            raise ValueError("project_id must be provided")
        if not data:
            raise ValueError("data must be provided")
        if "metadata" not in data:
            raise ValueError("data must contain 'metadata' key")
        if "entity" not in data:
            raise ValueError("data must contain 'entity' key")
        if "name" not in data["metadata"]:
            raise ValueError("data['metadata'] must contain 'name' key")

        query_params = {"project_id": project_id}
        if params:
            query_params.update(params)

        url = f"{self.base_url}/{self.url_path}"
        return self.post(
            url=url,
            params=query_params,
            data=json.dumps(data),
        )

    def get_data_definition(
        self,
        project_id: str,
        table_definition_id: str,
        params: dict | None = None,
    ) -> requests.Response:
        """Get a table definition by ID.

        Retrieves the details of a specific table definition from the specified project.

        Args:
            project_id: The ID of the project to use.
            table_definition_id: The table definition ID to retrieve.
            params: Additional query parameters.

        Returns:
            A HTTP response.
        """
        if not project_id:
            raise ValueError("project_id must be provided")
        if not table_definition_id:
            raise ValueError("table_definition_id must be provided")

        query_params = {"project_id": project_id}
        if params:
            query_params.update(params)

        url = f"{self.base_url}/{self.url_path}/{quote(table_definition_id, safe='')}"
        return self.get(url=url, params=query_params)

    def list_data_definitions(
        self,
        project_id: str,
        params: dict | None = None,
    ) -> requests.Response:
        """List table definitions in a project.

        Lists all table definitions in the specified project with optional filtering.

        Args:
            project_id: The ID of the project to use.
            params: Additional query parameters including:
                - name (str): Filter by name (use asset.name for exact matching)
                - limit (int): Maximum number of results to return
                - bookmark (str): Bookmark for pagination

        Returns:
            A HTTP response.
        """
        if not project_id:
            raise ValueError("project_id must be provided")

        query_params = {"project_id": project_id}
        if params:
            query_params.update(params)

        url = f"{self.base_url}/{self.url_path}"
        return self.get(url=url, params=query_params)

    def update_data_definition(
        self,
        project_id: str,
        table_definition_id: str,
        data: dict,
        params: dict | None = None,
    ) -> requests.Response:
        """Update an existing table definition.

        Updates the metadata and entity of an existing table definition in the specified project.

        Args:
            project_id: The ID of the project to use.
            table_definition_id: The table definition ID to update.
            data: Request body containing metadata and entity.
            params: Additional query parameters.

        Returns:
            A HTTP response.
        """
        if not project_id:
            raise ValueError("project_id must be provided")
        if not table_definition_id:
            raise ValueError("table_definition_id must be provided")
        if not data:
            raise ValueError("data must be provided")
        if "metadata" not in data:
            raise ValueError("data must contain 'metadata' key")
        if "entity" not in data:
            raise ValueError("data must contain 'entity' key")

        query_params = {"project_id": project_id}
        if params:
            query_params.update(params)

        url = f"{self.base_url}/{self.url_path}/{quote(table_definition_id, safe='')}"
        return self.put(
            url=url,
            params=query_params,
            data=json.dumps(data),
        )

    def delete_data_definition(
        self,
        project_id: str,
        table_definition_id: str,
        params: dict | None = None,
    ) -> requests.Response:
        """Delete a table definition.

        Deletes the specified table definition from the project.

        Args:
            project_id: The ID of the project to use.
            table_definition_id: The table definition ID to delete.
            params: Additional query parameters.

        Returns:
            A HTTP response.
        """
        if not project_id:
            raise ValueError("project_id must be provided")
        if not table_definition_id:
            raise ValueError("table_definition_id must be provided")

        query_params = {"project_id": project_id}
        if params:
            query_params.update(params)

        url = f"{self.base_url}/{self.url_path}/{quote(table_definition_id, safe='')}"
        return self.delete(url=url, params=query_params)

    def clone_data_definition(
        self,
        project_id: str,
        table_definition_id: str,
        name: str,
    ) -> requests.Response:
        """Clone an existing table definition.

        Creates a copy of an existing table definition with a new name in the specified project.

        Args:
            project_id: The ID of the project to use.
            table_definition_id: The table definition ID to clone.
            name: The name for the cloned table definition.

        Returns:
            A HTTP response.
        """
        if not project_id:
            raise ValueError("project_id must be provided")
        if not table_definition_id:
            raise ValueError("table_definition_id must be provided")
        if not name:
            raise ValueError("name must be provided")

        query_params = {"project_id": project_id, "name": name}

        url = f"{self.base_url}/{self.url_path}/{quote(table_definition_id, safe='')}/clone"
        return self.post(url=url, params=query_params)
