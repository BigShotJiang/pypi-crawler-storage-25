#  IBM Confidential
#  PID 5900-BAF
#  Copyright StreamSets Inc., an IBM Company 2026


"""Module containing Account Model for AWS."""

from enum import Enum
from ibm_watsonx_data_integration.common.models import BaseModel, CollectionModel, CollectionModelResults
from pydantic import Field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ibm_watsonx_data_integration.platform import Platform


class ScopeStatus(str, Enum):
    """Enum representing the status of an account."""

    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"


class AccountAWS(BaseModel):
    """Model representing an AWS account."""

    account_id: str = Field(repr=True, alias="id", frozen=True)
    name: str = Field(repr=True)
    status: ScopeStatus = Field(repr=True)

    def __init__(self, platform: "Platform", **account_json: dict) -> None:
        """The __init__ of the AccountAWS.

        Args:
            platform: The Platform object.
            account_json: The JSON for the AWS Account.
        """
        super().__init__(**account_json)
        self._platform = platform


class AccountsAWS(CollectionModel[AccountAWS]):
    """Collection of AccountsAWS instances."""

    def __init__(self, platform: "Platform") -> None:
        """The __init__ of the AccountsAWS class.

        Args:
            platform: The Platform object.
        """
        super().__init__(platform=platform, unique_id="account_id")

    def __len__(self) -> int:
        """Total number of AWS accounts."""
        res = self._platform._account_api.get_accounts()
        res_json = res.json()
        return len(res_json)

    def _request_parameters(self) -> list:
        return []

    def _get_all_results_from_api(self, **kwargs: Any) -> CollectionModelResults:  # noqa: ANN401
        """Returns results of an api request."""
        response = self._platform._account_api.get_accounts(
            params={k: v for k, v in kwargs.items() if v is not None}
        ).json()

        response = {"resources": response}

        return CollectionModelResults(
            response,
            AccountAWS,
            None,
            None,
            "resources",
            {"platform": self._platform},
        )
