#  IBM Confidential
#  PID 5900-BAF
#  Copyright StreamSets Inc., an IBM Company 2026

"""Module containing Parameter Set and Parameter Models."""

from __future__ import annotations

import json
import re
import requests
from enum import Enum
from ibm_watsonx_data_integration.common.json_patch_format import prepare_json_patch_payload
from ibm_watsonx_data_integration.common.models import BaseModel, CollectionModel, CollectionModelResults
from pydantic import Field, model_validator
from typing import TYPE_CHECKING, Any, ClassVar
from typing_extensions import override
from urllib.parse import parse_qs, urlparse

if TYPE_CHECKING:
    from ibm_watsonx_data_integration.cpd_models import Project

from ibm_watsonx_data_integration.cpd_models.asset_model import Asset

ParameterValue = str | int | float | bool | list
_PARAMETER_VALUE_TYPES = (str, int, float, bool, list)


class ParameterType(str, Enum):
    """Available types for parameter."""

    Date = "date"
    Encrypted = "encrypted"
    List = "enum"
    Integer = "int64"
    Path = "path"
    Float = "sfloat"
    String = "string"
    Time = "time"
    Timestamp = "timestamp"
    Multiline_string = "multilinestring"
    Email = "email"
    Multiline_encrypted_string = "encrypted"


class ValueSet(BaseModel):
    """Class for a value set for a parameter set."""

    name: str
    values: list[dict[str, ParameterValue]] = Field(default_factory=list)

    def add_value(self, name: str, value: ParameterValue) -> ValueSet:
        """Add or replace value in ValueSet."""
        for value_dict in self.values:
            if value_dict["name"] == name:
                value_dict["value"] = value
                return self
        self.values.append({"name": name, "value": value})
        return self

    def remove_value(self, name: str) -> ValueSet:
        """Remove value from ValueSet."""
        self.values = [value for value in self.values if value["name"] != name]
        return self

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ValueSet:
        """Create ValueSet from dict with normalized values format.

        Args:
            data: Dictionary with 'name' and 'values' keys.

        Returns:
            A ValueSet instance with normalized values.

        Raises:
            ValueError: If 'name' field is missing.
        """
        name = data.get("name")
        if not name:
            raise ValueError("ValueSet dict must contain 'name' field")

        values = data.get("values", [])
        if not isinstance(values, list):
            raise ValueError(f"'values' must be a list, got {type(values).__name__}")

        normalized_values = []
        for value_item in values:
            if isinstance(value_item, dict):
                for param_name, param_value in value_item.items():
                    if not isinstance(param_name, str):
                        raise ValueError(f"Parameter name must be a string, got {type(param_name).__name__}")
                    if not isinstance(param_value, _PARAMETER_VALUE_TYPES):
                        raise ValueError(
                            f"Parameter value must be str, int, float, bool, or list, got {type(param_value).__name__}"
                        )
                    normalized_values.append({"name": param_name, "value": param_value})
            else:
                raise ValueError(f"Invalid value type in ValueSet: {type(value_item)}. Expected dict.")

        return cls(name=name, values=normalized_values)

    def _validate_and_fill_defaults(self, parameters: list[Parameter]) -> ValueSet:
        """Validate parameter names exist and fill missing ones with defaults.

        Args:
            parameters: List of Parameter objects to validate against.

        Returns:
            Self for method chaining.

        Raises:
            ValueError: If a parameter name in values doesn't exist in parameters list.
        """
        param_names = {p.name for p in parameters}
        found_names = set()

        for value in self.values:
            param_name = value["name"]
            if param_name not in param_names:
                raise ValueError(f"Parameter {param_name} is not present in parameter set")
            found_names.add(param_name)

        for param in parameters:
            if param.name not in found_names:
                self.add_value(param.name, param.value)

        return self


class Parameter(BaseModel):
    """Class for a parameter in a parameter set."""

    _TYPE_MAPPINGS: ClassVar[dict[str, str]] = {
        "list": "enum",
        "integer": "int64",
        "float": "sfloat",
    }

    _ALLOWED_PARAM_TYPES: ClassVar[list[str]] = [
        "date",
        "email",
        "encrypted",
        "float",
        "integer",
        "list",
        "multilinestring",
        "path",
        "string",
        "time",
        "timestamp",
        "sfloat",
        "enum",
        "int64",
    ]

    name: str
    param_type: str = Field(alias="type")
    description: str | None = None
    prompt: str | None = None
    value: Any | None = None
    valid_values: list | None = None

    model_config = {"populate_by_name": True}

    @classmethod
    def _normalize_type(cls, param_type: str) -> str:
        """Normalize parameter type to internal representation.

        Args:
            param_type: The parameter type to normalize.

        Returns:
            The normalized parameter type.
        """
        param_type_lower = param_type.lower()
        return cls._TYPE_MAPPINGS.get(param_type_lower, param_type_lower)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Parameter:
        """Create Parameter from dict with validation.

        Args:
            data: Dictionary containing parameter data.

        Returns:
            A validated Parameter instance.

        Raises:
            ValueError: If parameter type is missing, invalid, or if enum type lacks valid_values.
        """
        param_type = data.get("type") or data.get("param_type")
        if not param_type:
            raise ValueError("Parameter type is required (use 'param_type' or 'param' key)")

        normalized_type = cls._normalize_type(param_type)
        if normalized_type not in cls._ALLOWED_PARAM_TYPES:
            raise ValueError(f"Unsupported param type: {param_type}. Supported types are: {cls._ALLOWED_PARAM_TYPES}")

        if normalized_type == "enum" and not data.get("valid_values"):
            raise ValueError("Valid values must be provided for list/enum type")

        return cls(
            name=data["name"],
            param_type=normalized_type,
            description=data.get("description"),
            prompt=data.get("prompt"),
            value=data.get("value"),
            valid_values=data.get("valid_values"),
        )

    @model_validator(mode="after")
    def validate_enum_has_valid_values(self) -> Parameter:
        """Ensure enum type has valid_values."""
        if self.param_type == "enum" and not self.valid_values:
            raise ValueError("Valid values must be provided for enum type")
        return self

    def _to_local_parameter(self) -> dict:
        return {
            "prompt": self.prompt,
            "value": self.value,
            "name": self.name,
            "suptype": getattr(self, "subtype", ""),
            "type": self.param_type,
        }


class ParameterSetMetadata(BaseModel):
    """Metadata for a parameter set."""

    asset_category: str | None = Field(None, description='The asset category ("USER" or "SYSTEM")', repr=False)
    asset_id: str | None = Field(None, description="The ID of the asset", repr=False)
    asset_type: str | None = Field(None, description="The type of the asset", repr=False)
    catalog_id: str | None = Field(
        None,
        description="The ID of the catalog which contains the asset. catalog_id, project_id or spaceid is required.",
        repr=False,
    )
    create_time: str | None = Field(
        None,
        description="The timestamp when the asset was created",
        repr=False,
    )
    creator_id: str | None = Field(None, description="The IAM ID of the user that created the asset", repr=False)
    href: str | None = Field(None, description="URL that can be used to get the asset.", repr=False)
    owner_id: str | None = Field(None, description="The IAM ID of the user that owns the asset", repr=False)
    project_id: str | None = Field(
        None,
        description="The ID of the project which contains the asset. catalog_id, project_id or spaceid is required.",
        repr=False,
    )
    resource_key: str | None = Field(
        None, description="Optional external unique key for assets that supports it", repr=False
    )
    space_id: str | None = Field(
        None,
        description="The ID of the space which contains the asset. catalog_id, project_id or spaceid is required.",
        repr=False,
    )
    tags: list[str] | None = Field(None, repr=False)


class ParameterSet(Asset):
    """A parameter set consists of a name, a list of parameters, a list of value sets, and a description.

    Args:
        name: The name of the parameter set.
        parameters: A list of Parameter objects.
        description: An optional description of the parameter set.
        value_sets: A list of ValueSet objects.
    """

    EXPOSED_DATA_PATH: ClassVar[dict] = {"entity.parameter_set": {}}
    metadata: ParameterSetMetadata | None = Field(None, repr=False)

    parameter_set_id: str | None = Field(
        repr=False,
        default_factory=lambda fields: fields["metadata"].asset_id if fields["metadata"] else None,
        description="Returns id of parameter set",
        exclude=True,
        frozen=True,
    )
    name: str = Field(description="The name of the parameter set.", repr=True)
    parameters: list[Parameter] = Field(
        default_factory=list, description="The parameters in a parameter set", repr=True
    )
    description: str | None = Field("", description="The description of the parameter set", repr=True)
    value_sets: list[ValueSet] = Field(default_factory=list, description="The value sets of a parameter set", repr=True)

    @staticmethod
    def _convert_parameters(v: list[Parameter] | list[dict] | None) -> list[Parameter]:
        """Convert dict items to Parameter objects with validation.

        Args:
            v: List of Parameter objects or dicts, or None.

        Returns:
            List of Parameter objects.
        """
        if v is None:
            return []

        result = []
        for item in v:
            if isinstance(item, Parameter):
                result.append(item)
            elif isinstance(item, dict):
                result.append(Parameter.from_dict(item))
            else:
                raise ValueError(f"Invalid parameter type: {type(item)}. Expected Parameter or dict.")

        return result

    @staticmethod
    def _convert_value_sets(v: list[ValueSet] | list[dict] | None) -> list[ValueSet]:
        """Convert dict items to ValueSet objects.

        Args:
            v: List of ValueSet objects or dicts, or None.

        Returns:
            List of ValueSet objects.
        """
        if v is None:
            return []

        result = []
        for item in v:
            if isinstance(item, ValueSet):
                result.append(item)
            elif isinstance(item, dict):
                result.append(ValueSet.from_dict(item))
            else:
                raise ValueError(f"Invalid value set type: {type(item)}. Expected ValueSet or dict.")

        return result

    def __init__(self, project: Project | None = None, **parameter_set_json: dict) -> None:  # noqa: D417
        """The __init__ of the ParameterSet class.

        Args:
            platform: The Platform object.
            project: The Project object.
        """
        super().__init__(project, **parameter_set_json)
        self._origin = self.model_dump(by_alias=True, exclude_none=True)

    def __getitem__(self, parameter: str) -> str:
        """Get parameter from parameter set by name."""
        for param in self.parameters:
            if param.name == parameter:
                return f"#{self.name}.{param.name}#"
        raise ValueError(f"Parameter {parameter} does not exist in set {self.name}")

    def __contains__(self, parameter: str) -> bool:
        """Check if parameter is in the parameter set by name."""
        for param in self.parameters:
            if param.name == parameter:
                return True
        return False

    def add_parameter(
        self,
        parameter_type: str,
        name: str,
        description: str | None = None,
        prompt: str | None = None,
        value: ParameterValue | None = None,
        valid_values: list | None = None,
    ) -> ParameterSet:
        """Adds a Parameter to the parameter set or updates it if it already exists.

        Args:
            parameter_type: Parameter type.
            name: Parameter name.
            description: Parameter help text.
            prompt: Parameter prompt
            value: Parameter value
            valid_values: Valid values for List Parameter only.

        Returns:
            The ParameterSet object with an updated list of parameters.
        """
        new_param: Parameter = Parameter.from_dict(
            {
                "param_type": parameter_type,
                "name": name,
                "description": description,
                "prompt": prompt,
                "value": value,
                "valid_values": valid_values,
            }
        )

        # Update existing parameter or append new one
        for i, param in enumerate(self.parameters):
            if param.name == name:
                self.parameters[i] = new_param
                return self

        self.parameters.append(new_param)
        return self

    def remove_parameter(self, parameter_name: str) -> ParameterSet:
        """Removes a parameter from the parameter set.

        Args:
            parameter_name: Name of the parameter to remove

        Returns:
            The ParameterSet object with an updated list of parameters.
        """
        self.parameters = [parameter for parameter in self.parameters if parameter.name != parameter_name]
        return self

    @staticmethod
    def _validate_name(name: str) -> None:
        """Validate parameter set name contains only allowed characters.

        Args:
            name: The name to validate.

        Raises:
            ValueError: If the name contains characters other than letters, numbers, and underscores.
        """
        if not re.match(r"^[a-zA-Z0-9_]+$", name):
            raise ValueError(
                f"Invalid parameter set name '{name}'. Parameter set name can only contain letters, numbers, and _."
            )

    @staticmethod
    def _validate_value_sets_against_parameters(parameters: list[Parameter], value_sets: list[ValueSet]) -> None:
        """Validate and fill defaults for all value_sets.

        Args:
            parameters: List of Parameter objects to validate against.
            value_sets: List of ValueSet objects to validate.
        """
        for vs in value_sets:
            vs._validate_and_fill_defaults(parameters)  # noqa

    @staticmethod
    def _create(
        project: Project,
        name: str,
        description: str,
        parameters: list[Parameter] | list[dict] | None = None,
        value_sets: list[ValueSet] | list[dict] | None = None,
    ) -> ParameterSet:
        """Create a new parameter set in the project.

        Args:
            project: The Project object where the parameter set will be created.
            name: The name of the parameter set.
            description: The description of the parameter set.
            parameters: A list of Parameter objects or dicts for the parameter set.
            value_sets: A list of value sets for the parameter set.

        Returns:
            A new ParameterSet object with the created parameter set details.

        Raises:
            ValueError: If the name contains characters other than letters, numbers, and underscores.
            ValueError: If value set is created for not existing parameter.
        """
        ParameterSet._validate_name(name)

        converted_parameters = ParameterSet._convert_parameters(parameters)
        converted_value_sets = ParameterSet._convert_value_sets(value_sets)

        ParameterSet._validate_value_sets_against_parameters(converted_parameters, converted_value_sets)

        properties = {
            "name": name,
            "description": description,
            "parameters": [p.model_dump(by_alias=True, exclude_none=True) for p in converted_parameters],
            "value_sets": [vs.model_dump(by_alias=True, exclude_none=True) for vs in converted_value_sets],
        }

        response = project._platform._parameter_set_api_client.create_parameter_set(
            parameter_set=properties, project_id=project.project_id
        )
        return ParameterSet(
            project=project,
            **response.json(),
        )

    def _update(self) -> requests.Response:
        # Validate name if it has been changed
        if self.name != self._origin.get("name"):
            ParameterSet._validate_name(self.name)

        properties = self.model_dump(exclude_none=True, by_alias=True, warnings=False)
        patch_request = json.loads(
            prepare_json_patch_payload(
                origin=self.origin,
                updated=properties,
                exclude_properties=["/metadata"],
                config={"add_insert_at_end": True},
            )
        )
        response = self._project._platform._parameter_set_api_client.patch_parameter_set(
            parameter_set_patch_entity=patch_request,
            parameter_set_id=self.metadata.asset_id,
            project_id=self._project.project_id,
        )

        # Update origin after successful update to prevent stale state issues
        if response.status_code == 200:
            self._origin = properties

        return response

    def _delete(self) -> requests.Response:
        return self._project._platform._parameter_set_api_client.delete_parameter_sets(
            id=[self.parameter_set_id], project_id=self._project.project_id
        )

    def _duplicate(self) -> ParameterSet:
        response = self._project._platform._parameter_set_api_client.clone_parameter_set(
            parameter_set_id=self.metadata.asset_id, project_id=self._project.project_id
        )
        return ParameterSet(
            project=self._project,
            **response.json(),
        )

    def add_value_set(self, value_set: ValueSet | dict) -> ParameterSet:
        """Adds a ValueSet to the list of value sets.

        Args:
            value_set: A ValueSet object or dict.

        Returns:
            The ParameterSet object with an updated list of value_sets.
        """
        if isinstance(value_set, dict):
            value_set = ValueSet.from_dict(value_set)

        value_set._validate_and_fill_defaults(self.parameters)  # noqa
        self.value_sets.append(value_set)
        return self

    @property
    def origin(self) -> dict:
        """Returns origin model dump."""
        return self._origin

    @classmethod
    def from_dict(cls, parameter_set_data: dict[str, Any]) -> ParameterSet:
        """Creates a new ParameterSet object from a dictionary of values.

        Args:
            parameter_set_data: A dictionary of values for a ParameterSet object.

        Returns:
            A new ParameterSet object with the existing parameter set details.
        """
        # Use Parameter.from_dict for centralized validation and creation
        parameters = parameter_set_data.get("parameters")
        param_objects = []
        if parameters:
            for param in parameters:
                # Handle legacy 'int' types by converting to 'integer'
                param_type = param.get("type")
                if param_type and "int" in param_type and param_type != "integer":
                    param = {**param, "type": "integer"}

                param_objects.append(Parameter.from_dict(param))

        name = parameter_set_data.get("name")
        description = parameter_set_data.get("description")
        value_sets = []
        asset_id = parameter_set_data.get("asset_id")
        proj_id = parameter_set_data.get("proj_id")
        formatted_dict = {
            "platform": None,
            "project": None,
            "name": name,
            "parameters": param_objects,
            "description": description,
            "value_sets": value_sets,
            "metadata": {"asset_id": asset_id},
            "proj_id": proj_id,
        }
        return cls(**formatted_dict)

    def _to_external_parameter(self) -> dict:
        return {
            "name": self.name,
            "description": self.description if self.description else "",
            "ref": self.parameter_set_id,
            "project_id": self.metadata.project_id,
        }

    def as_dict(self) -> list[dict[str, ParameterValue]]:
        """Convert parameter set to list of parameter dictionaries.

        Returns:
            List of parameter dictionaries with name and value.
        """
        result = list()
        for parameter in self.parameters:
            result.append({"name": f"{self.name}.{parameter.name}", "value": parameter.value})
        return result


class ParameterSets(CollectionModel[ParameterSet]):
    """Collection of ParameterSet instances."""

    def __init__(self, project: Project) -> None:
        """The __init__ of the ParameterSets class.

        Args:
            project: Instance of Project in which parameter set was created.
        """
        super().__init__(platform=project._platform, unique_id="parameter_set_id")
        self._project = project

    def get_by_ids(self, ids: list[str]) -> list[ParameterSet]:
        """Fetch parameter sets by their IDs in bulk.

        Args:
            ids: List of parameter set IDs to fetch.

        Returns:
            List of ParameterSet instances.
        """
        if not ids:
            return []

        response = self._project._platform._parameter_set_api_client.get_parameter_sets_bulk(
            ids=ids,
            project_id=self._project.metadata.guid,
        ).json()

        parameter_sets = []
        for paramset_json in response["parameter_sets"]:
            paramset_json["parameter_set_id"] = paramset_json["metadata"]["asset_id"]
            paramset_json["name"] = paramset_json["metadata"]["name"]
            paramset_json["description"] = paramset_json["metadata"]["description"]
            parameter_sets.append(ParameterSet(project=self._project, **paramset_json))

        return parameter_sets

    @override
    def __len__(self) -> int:
        parametersets_json = self._project._platform._parameter_set_api_client.get_parameter_sets(
            project_id=self._project.project_id
        ).json()
        return parametersets_json["total_count"]

    def _request_parameters(self) -> list:
        return [
            "parameter_set_id",
            "project_id",
            "sort",
            "start",
            "limit",
            "entity.parameter_set.name",
            "entity.parameter_set.description",
            "entity.parameter_set.parameters",
            "entity.parameter_set.value_sets",
        ]

    def _get_all_results_from_api(self, **kwargs: Any) -> CollectionModelResults:
        """Returns results of an api request."""
        start_val = kwargs.get("start")
        if isinstance(start_val, dict) and "href" in start_val:
            parsed_url = urlparse(start_val["href"])
            params = parse_qs(parsed_url.query)
            kwargs["start"] = params.get("start", [None])[0]

        request_params_defaults = {
            "project_id": self._project.metadata.guid,
            "sort": None,
            "start": None,
            "limit": 100,
            "entity.parameter_set.name": None,
            "entity.parameter_set.description": None,
            "entity.parameter_set.parameters": None,
            "entity.parameter_set.value_sets": None,
        }
        request_params_unioned = request_params_defaults.copy()
        request_params_unioned.update(kwargs)

        if "entity.parameter_set.name" in request_params_unioned:
            request_params_unioned["entity_name"] = request_params_unioned.get("entity.parameter_set.name")
        if "entity.parameter_set.description" in request_params_unioned:
            request_params_unioned["entity_description"] = request_params_unioned.get(
                "entity.parameter_set.description"
            )

        params = {k: v for k, v in request_params_unioned.items() if v is not None}
        response = self._project._platform._parameter_set_api_client.get_parameter_sets(**params).json()

        parameter_set_ids = [paramset_json["metadata"]["asset_id"] for paramset_json in response["parameter_sets"]]
        if parameter_set_ids:
            bulk_response = self._project._platform._parameter_set_api_client.get_parameter_sets_bulk(
                ids=parameter_set_ids,
                project_id=self._project.metadata.guid,
            ).json()
            response["parameter_sets"] = bulk_response["parameter_sets"]

        return CollectionModelResults(
            results=response,
            class_type=ParameterSet,
            response_bookmark="next",
            request_bookmark="start",
            response_location="parameter_sets",
            constructor_params={"project": self._project},
        )

    def _get_by_id(self, id_val: str, **kwargs: Any) -> CollectionModelResults:
        """Return results for a single parameter set by id (single API call)."""
        response_json = self._project._platform._parameter_set_api_client.get_parameter_set(
            parameter_set_id=id_val,
            project_id=self._project.metadata.guid,
        ).json()

        response = {"parameter_sets": [response_json]}

        return CollectionModelResults(
            results=response,
            class_type=ParameterSet,
            response_bookmark="next",
            request_bookmark="start",
            response_location="parameter_sets",
            constructor_params={"project": self._project},
        )
