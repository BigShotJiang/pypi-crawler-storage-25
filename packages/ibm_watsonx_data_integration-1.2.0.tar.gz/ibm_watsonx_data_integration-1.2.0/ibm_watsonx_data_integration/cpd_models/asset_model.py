#  IBM Confidential
#  PID 5900-BAF
#  Copyright StreamSets Inc., an IBM Company 2026


"""Module containing Project Asset Model.

Purpose of this model file is only of internal usage.
Classes within this modules shouldn't be exposed to user.
"""

import inspect
from enum import Enum
from ibm_watsonx_data_integration.common.models import BaseModel
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ibm_watsonx_data_integration.cpd_models import Project


class AssetType(str, Enum):
    """Enumeration of supported asset types."""

    PARAMETER_SET = "parameter_set"


class AssetRelationshipType(str, Enum):
    """Enumeration of asset relationship types."""

    USES = "uses"


class FindAssetRelationShipResponse(BaseModel):
    """Response model for asset relationship queries."""

    options: dict
    resources: list["AssetResponse"]


class Asset(BaseModel):
    """Base model that indicates a class is a project asset."""

    def __init__(self, project: "Project", **asset_json: dict) -> None:
        """__init__ function for Asset class."""
        super().__init__(**asset_json)
        self._project: Project = project

    @property
    def project_id(self) -> str:
        """Returns the project id of the asset."""
        return self._project.project_id


class AssetResponse(BaseModel):
    """Response model representing an asset with its metadata."""

    project_id: str
    asset_id: str
    relationship_name: str
    asset_type: str
    href: str
    created: int
    updated: int
    creator_id: str
    updater_id: str
    asset_name: str | None = None


class AssetLike:
    """Base class for components that automatically discover their parent Asset, AssetLike or Project.

    This is utility class, meant to readily provide the base project object for interactions.

    Current issues:
    The current issue is that codegen does not provide a way to currently pass down a project object,
    we can probably make all codegen classes into AssetLikes and go from there, but for now,
    the _project attribute is either a Project instance or None.

    Currently all codegen tests pass None into Project param of __init__ and everything is currently working,
    we can worry about the ticket when we break some usage.
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """Initialize and discover parent Asset or AssetLike from call stack."""
        # avoiding circular imports for now
        from ibm_watsonx_data_integration.cpd_models.project_model import Project

        self._project_type = Project

        self._parent_asset_like = self._find_parent_asset_or_component()

        # enable chaining multiple inits
        super().__init__(*args, **kwargs)

    def _find_parent_asset_or_component(self) -> "Asset | AssetLike | Project | None":
        stack = inspect.stack()

        # Search up to 20 frames in the call stack, disregarding this function call and __init__
        for frame_info in stack[2:22]:
            frame_locals = frame_info.frame.f_locals

            # Look for AssetLike first, then Asset
            for var_value in frame_locals.values():
                # Skip self to avoid circular reference
                if var_value is self:
                    continue
                if isinstance(var_value, self.__class__ | Asset | self._project_type):
                    return var_value

        return None

    @property
    def _project(self) -> "Project | None":
        # return None for backwards compat, and codegen. ToDo: Raise an error instead
        if self._parent_asset_like is None:
            return None

        if isinstance(self._parent_asset_like, self._project_type):
            return self._parent_asset_like

        return self._parent_asset_like._project
