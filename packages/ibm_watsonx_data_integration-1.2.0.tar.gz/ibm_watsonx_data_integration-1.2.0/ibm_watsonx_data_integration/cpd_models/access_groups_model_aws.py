#  IBM Confidential
#  PID 5900-BAF
#  Copyright StreamSets Inc., an IBM Company 2026

"""Module containing AccessGroupAWS Model."""

from __future__ import annotations

import json
import requests
from ibm_watsonx_data_integration.common.models import BaseModel, CollectionModel, CollectionModelResults
from ibm_watsonx_data_integration.cpd_models.project_collaborator_model import (
    CollaboratorRole,
    CollaboratorType,
    ProjectCollaboratable,
    ProjectCollaborator,
)
from ibm_watsonx_data_integration.cpd_models.user_model_aws import UserProfileAWS
from pydantic import Field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ibm_watsonx_data_integration.platform import Platform
    from ibm_watsonx_data_integration.cpd_models.project_model import Project


class AccessGroupAWS(BaseModel, ProjectCollaboratable):
    """AWS Access Group model."""

    id: str = Field(frozen=True, repr=True, alias="uid")
    access_group_id: str = Field(repr=False, default_factory=lambda fields: fields["id"], frozen=True, exclude=True)
    scope_type: str = Field(repr=False, alias="scopeType")
    scope_id: str = Field(repr=False, alias="scopeId")
    name: str = Field(repr=True)
    description: str = Field(default="")
    status: str = Field(repr=False)
    custom: bool = Field(repr=False)
    jit: bool = Field(repr=False)
    created_by: dict = Field(repr=False, alias="createdBy")
    created_ts: str = Field(repr=False, alias="createdTs")
    modified_by: dict = Field(repr=False, alias="modifiedBy")
    modified_ts: str = Field(repr=False, alias="modifiedTs")
    version: int = Field(repr=False)
    dynamic: bool = Field(repr=False)

    def __init__(self, platform: Platform, **group_json: dict) -> None:
        """The __init__ of the AccessGroup class."""
        super().__init__(**group_json)
        self._platform = platform

    @staticmethod
    def _create(platform: Platform, name: str, description: str | None = None) -> AccessGroupAWS:
        """Create the AccessGroup object using MCSP IAM API."""
        scope_id = platform.current_account.account_id

        payload = {
            "name": name,
            "description": description if description else "",
        }

        data = json.dumps(payload)
        response = platform._access_group_api.create_access_group(scope_id=scope_id, data=data)
        access_group_json = response.json()
        return AccessGroupAWS(platform=platform, **access_group_json)

    def _update(self) -> requests.Response:
        """Update the AccessGroup object."""
        payload = {"name": self.name, "description": self.description, "op": "UPDATE"}

        if hasattr(self, "rules") and self.rules is not None:
            payload["rules"] = self.rules

        data = json.dumps(payload)

        response = self._platform._access_group_api.update_access_group(
            scope_id=self.scope_id, access_group_id=self.id, data=data
        )

        return response

    def _delete(self) -> requests.Response:
        """Delete the AccessGroup object."""
        return self._platform._access_group_api.delete_access_group(scope_id=self.scope_id, access_group_id=self.id)

    def add_members_to_access_group(self, users: list[object] | object) -> requests.Response:
        """Adds members to an AccessGroup.

        Args:
            users: The members to be added to the access group.

        Returns:
            An HTTP response.
        """
        if not isinstance(users, list):
            users = [users]

        member_uids = [user.id for user in users]
        data = json.dumps({"memberType": "USER", "memberUids": member_uids, "op": "ADD"})

        return self._platform._access_group_api.update_group_members(
            scope_id=self.scope_id, access_group_id=self.id, data=data
        )

    def remove_members_from_access_group(self, users: list[object] | object) -> requests.Response:
        """Removes members from access group.

        Args:
            users: Member(s) to be removed from access group.

        Returns:
            An HTTP response.
        """
        if not isinstance(users, list):
            users = [users]

        member_uids = [user.id for user in users]
        data = json.dumps({"memberType": "USER", "memberUids": member_uids, "op": "DELETE"})

        return self._platform._access_group_api.update_group_members(
            scope_id=self.scope_id, access_group_id=self.id, data=data
        )

    def get_access_group_members(self) -> list:
        """Gets all members of an AccessGroup.

        Returns:
            A list of current members of an Access Group.
        """
        member_list = []
        params = {}
        while True:
            response = self._platform._access_group_api.get_members(
                scope_id=self.scope_id, access_group_id=self.id, params=params
            )
            members_json = response.json()

            if "resources" in members_json:
                for member in members_json["resources"]:
                    member_list.append(member)
            if "resources" not in members_json or "page-last-key" not in members_json:
                break
            else:
                params["pageLastKey"] = members_json["page-last-key"]

        return member_list

    def check_membership(self, member: UserProfileAWS) -> bool:
        """Checks the membership of a member in an access group.

        Args:
            member: The member object to check membership of.

        Returns:
            True if the member is in the access group, False otherwise.
        """
        all_users = self.get_access_group_members()
        return any(user.get("memberUid") == member.id for user in all_users)

    def _to_collaborator(self, project: Project, role: CollaboratorRole) -> ProjectCollaborator:
        """Returns ProjectCollaborator object."""
        return ProjectCollaborator(
            project=project,
            user_name=str(self.id),
            id=str(self.id),
            role=role,
            type=CollaboratorType.GROUP,
        )


class AccessGroupsAWS(CollectionModel[AccessGroupAWS]):
    """Collection of AccessGroupAWS instances."""

    def __init__(self, platform: Platform, user_scope_id: str) -> None:
        """The __init__ of the AccessGroupsAWS class."""
        super().__init__(platform=platform, unique_id="id")
        self._user_scope_id = user_scope_id

    def __len__(self) -> int:
        """Total amount of AWS access groups."""
        resp = self._platform._access_group_api.get_all_access_groups(scope_id=self._user_scope_id, params={})
        response = resp.json()
        return response["total-results"]

    def _request_parameters(self) -> list:
        return ["id"]

    def _get_all_results_from_api(self, **kwargs: Any) -> CollectionModelResults:  # noqa: ANN401
        """Returns results of an API request, normalizing different possible shapes."""
        request_params = dict(kwargs)

        response = self._platform._access_group_api.get_all_access_groups(
            self._user_scope_id, params={k: v for k, v in request_params.items() if v is not None}
        ).json()

        return CollectionModelResults(
            response,
            AccessGroupAWS,
            "page-last-key",
            "pageLastKey",
            "resources",
            {"platform": self._platform},
        )

    def _get_by_id(self, id_val: str, **kwargs: Any) -> CollectionModelResults:  # noqa: ANN401
        """Return results for a single group by id (single API call)."""
        request_params = dict(kwargs)

        response = self._platform._access_group_api.get_access_group_by_id(
            self._user_scope_id, access_group_id=id_val, params=request_params
        ).json()
        response = {"resources": [response]}

        return CollectionModelResults(
            response,
            AccessGroupAWS,
            "page-last-key",
            "pageLastKey",
            "resources",
            {"platform": self._platform},
        )
