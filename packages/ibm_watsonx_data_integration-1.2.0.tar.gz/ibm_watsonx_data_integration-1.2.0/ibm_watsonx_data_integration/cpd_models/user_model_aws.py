#  IBM Confidential
#  PID 5900-BAF
#  Copyright StreamSets Inc., an IBM Company 2026

"""Models for User, and Users collection."""

from __future__ import annotations

from enum import Enum
from ibm_watsonx_data_integration.common.models import BaseModel, CollectionModel, CollectionModelResults
from ibm_watsonx_data_integration.cpd_models.project_collaborator_model import (
    CollaboratorRole,
    CollaboratorType,
    ProjectCollaboratable,
    ProjectCollaborator,
)
from pydantic import ConfigDict, Field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ibm_watsonx_data_integration.platform import Platform
    from ibm_watsonx_data_integration.cpd_models.project_model import Project


class ScopeType(Enum):
    """ScopeType enum for user scope."""

    ACCOUNT_ROOT = "ACCOUNT_ROOT"
    ACCOUNT = "ACCOUNT"
    SUBSCRIPTION = "SUBSCRIPTION"
    SERVICE = "SERVICE"
    PRODUCT_ROOT = "PRODUCT_ROOT"
    PRODUCT = "PRODUCT"
    EXTERNAL_SERVICE_ROOT = "EXTERNALSERVICE_ROOT"
    EXTERNAL_SERVICE = "EXTERNALSERVICE"


class UserStatus(Enum):
    """User status enum."""

    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"
    PENDING = "PENDING"


class AuthorType(Enum):
    """Author type enum for createdBy/modifiedBy."""

    APP_BOOTSTRAP = "APP_BOOTSTRAP"
    APP_IDENTITY = "APP_IDENTITY"
    DB_MIGRATION = "DB_MIGRATION"
    SYNCHRONIZER = "SYNCHRONIZER"


class Author(BaseModel):
    """Represents author information for createdBy/modifiedBy fields."""

    author_type: AuthorType = Field(alias="authorType", repr=False)
    user_uid: str | None = Field(default=None, alias="userUid", repr=False, frozen=True)
    service_id_uid: str | None = Field(default=None, alias="serviceidUid", repr=False, frozen=True)


class UserProfileAWS(BaseModel, ProjectCollaboratable):
    """Model representing an identity user in the platform."""

    id: str | None = Field(default=None, repr=True, frozen=True, alias="uid")
    scope_type: ScopeType = Field(alias="scopeType", repr=False)
    scope_id: str = Field(alias="scopeId", repr=False)
    idp: str = Field(repr=False)
    realm: str = Field(repr=False)
    audiences: list[str] = Field(repr=False)
    email: str = Field(repr=True)
    idp_unique_id: str | None = Field(default=None, alias="idpUniqueId", repr=False)
    name: str | None = Field(default=None, repr=True)
    display_name: str | None = Field(default=None, alias="displayName", repr=True)
    family_name: str | None = Field(default=None, alias="familyName", repr=False)
    given_name: str | None = Field(default=None, alias="givenName", repr=False)
    jwt_ext: Any | None = Field(default=None, alias="jwtExt", repr=False)
    status: UserStatus | None = Field(default=None, repr=False)
    jit: bool = Field(repr=False)
    created_by: Author = Field(alias="createdBy", repr=False)
    modified_by: Author = Field(alias="modifiedBy", repr=False)
    version: int = Field(repr=False)
    created_ts: str | None = Field(default=None, alias="createdTs", repr=False)
    modified_ts: str | None = Field(default=None, alias="modifiedTs", repr=False)

    model_config = ConfigDict(use_enum_values=True, frozen=True)
    _expose: bool = True

    def __init__(self, platform: Platform, **user_json: dict) -> None:
        """__init__ for UserProfileAWS."""
        super().__init__(**user_json)
        self._platform = platform
        if platform is not None and hasattr(platform, "_user_api"):
            self._identity_api = platform._user_api

    def _to_collaborator(self, project: Project, role: CollaboratorRole) -> ProjectCollaborator:
        """Returns ProjectCollaborator object."""
        return ProjectCollaborator(
            project=project, user_name=self.name, id=self.id, role=role, type=CollaboratorType.USER
        )


class UserProfilesAWS(CollectionModel[UserProfileAWS]):
    """Collection of AWS User instances backed by the identity API."""

    def __init__(self, platform: Platform, account_id: str) -> None:
        """__init__ for UserProfilesAWS."""
        super().__init__(platform=platform, unique_id="id")
        self._account_id = account_id

    def __len__(self) -> int:
        """Return total number of users."""
        params = {}
        res = self._platform._user_api.get_users(account_id=self._account_id, params=params)
        res_json = res.json()
        return res_json["total-results"]

    def _request_parameters(self) -> list:
        return ["id", "limit", "start"]

    def _get_all_results_from_api(self, **kwargs: Any) -> CollectionModelResults:  # noqa: ANN401
        """Fetch and normalize results."""
        start_val = kwargs.get("_start")
        if isinstance(start_val, str) and "_start=" in start_val:
            kwargs["_start"] = start_val.split("_start=", 1)[1].split("&", 1)[0]

        if "limit" in kwargs:
            kwargs["pageSize"] = kwargs.pop("limit")

        request_params_defaults = {"pageSize": 10, "pageLastKey": None}

        request_params_unioned = request_params_defaults.copy()
        request_params_unioned.update(kwargs)

        id = request_params_unioned.get("id")

        if "id" in request_params_unioned:
            response = self._platform._user_api.get_user_by_id(account_id=self._account_id, user_id=id).json()
            response = {"resources": [response]}
        else:
            response = self._platform._user_api.get_users(
                account_id=self._account_id, params={k: v for k, v in request_params_unioned.items() if v is not None}
            ).json()

        return CollectionModelResults(
            response,
            UserProfileAWS,
            "page-last-key",
            "pageLastKey",
            "resources",
            {"platform": self._platform},
        )

    def _get_by_id(self, id_val: str, **kwargs: Any) -> CollectionModelResults:  # noqa: ANN401
        """Return results for a single User instance by id (single API call)."""
        response = self._platform._user_api.get_user_by_id(
            account_id=self._account_id, user_id=id_val, params={}
        ).json()
        response = {"resources": [response]}

        return CollectionModelResults(
            response,
            UserProfileAWS,
            "page-last-key",
            "pageLastKey",
            "resources",
            {"platform": self._platform},
        )
