#  IBM Confidential
#  PID 5900-BAF
#  Copyright StreamSets Inc., an IBM Company 2026

"""Job run payload factory for creating job run payloads for job-creatable assets."""

from abc import ABC, abstractmethod
from collections.abc import Callable
from typing import TYPE_CHECKING, Any, ClassVar
from typing_extensions import override

if TYPE_CHECKING:
    from ibm_watsonx_data_integration.cpd_models.job_model import Job
    from ibm_watsonx_data_integration.cpd_models.job_model.job_model import JobCreatable


class JobRunPayloadFactory(ABC):
    """Abstract factory for creating job run payloads based on job-creatable asset type."""

    _job_type_registry: ClassVar[dict[str, type["JobRunPayloadFactory"]]] = {}
    _default_factory: ClassVar[type["JobRunPayloadFactory"] | None] = None

    @classmethod
    def register(
        cls, job_creatable_class: type["JobCreatable"]
    ) -> Callable[[type["JobRunPayloadFactory"]], type["JobRunPayloadFactory"]]:
        """Decorator to register a factory for a specific job-creatable asset type.

        Args:
            job_creatable_class: The JobCreatable subclass this factory handles.

        Returns:
            Decorator function that registers the factory.

        Raises:
            AttributeError: If job_creatable_class does not define JOB_TYPE.
        """

        def decorator(factory_class: type["JobRunPayloadFactory"]) -> type["JobRunPayloadFactory"]:
            if not hasattr(job_creatable_class, "JOB_TYPE"):
                raise AttributeError(
                    f"JobCreatable class '{job_creatable_class.__name__}' must define a JOB_TYPE class variable"
                )

            job_type = job_creatable_class.JOB_TYPE
            cls._job_type_registry[job_type] = factory_class

            return factory_class

        return decorator

    @classmethod
    def set_default(cls, factory_class: type["JobRunPayloadFactory"]) -> type["JobRunPayloadFactory"]:
        """Set the default factory for unknown job-creatable asset types.

        Args:
            factory_class: The factory to use as default.

        Returns:
            The factory class (for decorator chaining).
        """
        cls._default_factory = factory_class
        return factory_class

    @classmethod
    def get_factory(cls, job: "Job") -> "JobRunPayloadFactory":
        """Get the appropriate factory instance for a job.

        Args:
            job: The job instance to create run payload for.

        Returns:
            Factory instance for the job's job-creatable asset type.

        Raises:
            ValueError: If no factory found and no default set.
        """
        factory_class = cls._job_type_registry.get(job.job_type, cls._default_factory)

        if factory_class is None:
            available_types = list(cls._job_type_registry.keys())
            raise ValueError(
                f"No job run payload factory registered for job type '{job.job_type}'. "
                f"Available types: {available_types}"
            )

        return factory_class()

    @abstractmethod
    def create_payload(
        self,
        job: "Job",
        base_payload: dict[str, Any],
        runtime_parameters: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Create the job run payload for the given job.

        Args:
            job: The job to create run payload for.
            base_payload: Base payload dictionary to extend.
            runtime_parameters: Runtime parameters passed by user.
            **kwargs: Additional parameters for future extensibility.

        Returns:
            Complete payload dictionary for job run creation.
        """
        raise NotImplementedError

    def create(
        self,
        job: "Job",
        base_payload: dict[str, Any],
        runtime_parameters: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Main entry point: run pre-operations then create payload.

        Args:
            job: The job to create run payload for.
            base_payload: Base payload dictionary.
            runtime_parameters: Runtime parameters passed by user.
            **kwargs: Additional parameters for future extensibility.

        Returns:
            Complete payload dictionary.
        """
        return self.create_payload(job, base_payload, runtime_parameters=runtime_parameters, **kwargs)


@JobRunPayloadFactory.set_default
class DefaultJobRunPayloadFactory(JobRunPayloadFactory):
    """Default factory for job run payload creation."""

    @override
    def create_payload(
        self,
        job: "Job",
        base_payload: dict[str, Any],
        runtime_parameters: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        return base_payload
