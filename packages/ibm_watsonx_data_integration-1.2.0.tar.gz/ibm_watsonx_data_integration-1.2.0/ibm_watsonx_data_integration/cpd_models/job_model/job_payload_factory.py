#  IBM Confidential
#  PID 5900-BAF
#  Copyright StreamSets Inc., an IBM Company 2026

"""Job payload factory for creating job payloads for job-creatable assets."""

from abc import ABC, abstractmethod
from collections.abc import Callable
from ibm_watsonx_data_integration.cpd_models.parameter_set_model import ParameterSet
from typing import Any, ClassVar


class JobCreatable(ABC):
    """Interface that indicates jobs can be created for the asset.

    Subclasses must define a JOB_TYPE class variable that specifies
    the job type string used by the backend API.
    """

    JOB_TYPE: ClassVar[str]


class JobPayloadFactory(ABC):
    """Abstract factory for creating job payloads based on job-creatable asset type."""

    _factory_registry: ClassVar[dict[type[JobCreatable], type["JobPayloadFactory"]]] = {}

    @classmethod
    def register(
        cls, job_creatable_class: type[JobCreatable]
    ) -> Callable[[type["JobPayloadFactory"]], type["JobPayloadFactory"]]:
        """Decorator to register a factory for a specific job-creatable asset type.

        Args:
            job_creatable_class: The JobCreatable subclass this factory handles.

        Returns:
            Decorator function that registers the factory.
        """

        def decorator(factory_class: type["JobPayloadFactory"]) -> type["JobPayloadFactory"]:
            cls._factory_registry[job_creatable_class] = factory_class
            return factory_class

        return decorator

    @classmethod
    def get_factory(cls, job_creatable: JobCreatable) -> "JobPayloadFactory":
        """Get the appropriate factory instance for a job-creatable asset.

        Args:
            job_creatable: The job-creatable asset instance to create payload for.

        Returns:
            Factory instance for the job-creatable asset type.

        Raises:
            ValueError: If no factory registered for the job-creatable asset type.
        """
        job_creatable_type = type(job_creatable)
        factory_class = cls._factory_registry.get(job_creatable_type)

        if factory_class is None:
            available_types = [ft.__name__ for ft in cls._factory_registry.keys()]
            raise ValueError(
                f"No payload factory registered for job-creatable asset type '{job_creatable_type.__name__}'. "
                f"Available types: {available_types}"
            )

        return factory_class()

    @abstractmethod
    def create_payload(
        self,
        job_creatable: JobCreatable,
        base_payload: dict[str, Any],
        runtime_parameters: dict | ParameterSet | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Create the job payload for the given job-creatable asset.

        Args:
            job_creatable: The job-creatable asset to create payload for.
            base_payload: Base payload dictionary to extend.
            runtime_parameters: Runtime parameters passed by user.
            **kwargs: Additional parameters for future extensibility.

        Returns:
            Complete payload dictionary for job creation.
        """
        raise NotImplementedError

    def run_pre_operations(self, job_creatable: JobCreatable) -> None:
        """Run pre-creation operations (validation, compilation, etc.).

        Override this method to add asset-specific pre-checks.

        Args:
            job_creatable: The job-creatable asset to validate/prepare.

        Raises:
            FlowPreStartOperationError: If pre-operations fail.
        """
        pass

    def create(
        self,
        job_creatable: JobCreatable,
        base_payload: dict[str, Any],
        runtime_parameters: dict | ParameterSet | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Main entry point: run pre-operations then create payload.

        Args:
            job_creatable: The job-creatable asset to create payload for.
            base_payload: Base payload dictionary.
            runtime_parameters: Runtime parameters passed by user.
            **kwargs: Additional parameters for future extensibility.

        Returns:
            Complete payload dictionary.
        """
        self.run_pre_operations(job_creatable)
        return self.create_payload(job_creatable, base_payload, runtime_parameters=runtime_parameters, **kwargs)
