#  IBM Confidential
#  PID 5900-BAF
#  Copyright StreamSets Inc., an IBM Company 2026

"""Generic base class for stage information across different flow types."""

from abc import ABC
from ibm_watsonx_data_integration.common.models import BaseModel
from pydantic import ConfigDict, Field
from typing import Generic, TypeVar

# TypeVar for the stage type (e.g., StageTypeEnum for DataStage, StageType for StreamSets)
StageTypeT = TypeVar("StageTypeT")


class StageInfo(BaseModel, ABC, Generic[StageTypeT]):
    """Base class for information about an available stage.

    This is a generic base class that can be specialized for different flow types
    (e.g., DataStage, StreamSets) with their specific stage type enums.
    """

    name: str = Field(repr=True, description="Stage name")
    stage_type: StageTypeT = Field(repr=True, description="Stage type")

    model_config = ConfigDict(frozen=True)
