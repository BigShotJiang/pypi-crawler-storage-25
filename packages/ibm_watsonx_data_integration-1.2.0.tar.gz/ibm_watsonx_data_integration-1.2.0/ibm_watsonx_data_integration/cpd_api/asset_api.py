# IBM Confidential
# PID 5900-BAF
# Copyright StreamSets Inc., an IBM Company 2026

"""This module containing the AssetApiClient class."""

import requests
from ibm_watsonx_data_integration.cpd_api.base import BaseAPIClient
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ibm_watsonx_data_integration.common.auth import BaseAuthenticator


DEFAULT_ASSET_API_VERSION = 2


class AssetApiClient(BaseAPIClient):
    """API client for managing asset relationships in Cloud Pak for Data."""

    def __init__(
        self,
        auth: "BaseAuthenticator",  # pragma: allowlist secret
        base_url: str = "https://api.dataplatform.cloud.ibm.com",
    ) -> None:
        """The __init__ of the AssetApiClient.

        Args:
            auth: The Authentication object.
            base_url: The Cloud Pak for Data URL.
        """
        super().__init__(auth=auth, base_url=base_url)
        self.url_path_assets = f"v{DEFAULT_ASSET_API_VERSION}/assets"

    def get_relationships(self, params: dict[str, Any]) -> requests.Response:
        """Gets assets related to given asset.

        Args:
            params: Query params required by endpoint.

        Returns:
            A HTTP response.
        """
        url = f"{self.base_url}/{self.url_path_assets}/get_relationships"
        response = self.post(url=url, params=params)
        return response

    def set_relationships(self, data: str) -> requests.Response:
        """Establish relationship between two assets. Up to 20 relations based on backend docs.

        Args:
            data: Payload data required by endpoint.

        Returns:
            A HTTP response.
        """
        url = f"{self.base_url}/{self.url_path_assets}/set_relationships"
        response = self.post(url=url, data=data)
        return response

    def unset_relationships(self, data: str, params: dict[str, Any]) -> requests.Response:
        """Delete relationship between two assets. Up to 20 relations based on backend docs.

        Args:
            data: Payload data required by endpoint.
            params: Query params required by endpoint.

        Returns:
            A HTTP response.
        """
        url = f"{self.base_url}/{self.url_path_assets}/unset_relationships"
        response = self.post(url=url, data=data, params=params)
        return response
