#  IBM Confidential
#  PID 5900-BAF
#  Copyright StreamSets Inc., an IBM Company 2026


"""This module contains the AccountAPIClientAWS class."""

import json
import requests
from ibm_watsonx_data_integration.cpd_api.base import BaseAPIClient
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ibm_watsonx_data_integration.common.auth import BaseAuthenticator

DEFAULT_ACCOUNT_API_VERSION = 2


class AccountAPIClientAWS(BaseAPIClient):
    """The API client of the AWS Accounts service."""

    def __init__(
        self,
        auth: "BaseAuthenticator",  # pragma: allowlist secret
        base_url: str = "https://account-iam.platform.test.saas.ibm.com",
    ) -> None:
        """Initializes the AccountAPIClientAWS.

        Args:
            auth: The Authentication object.
            base_url: The Accounts Service URL.
        """
        super().__init__(auth=auth, base_url=base_url)
        self.url_path = f"v{DEFAULT_ACCOUNT_API_VERSION}/accounts"
        self._auth = auth

    def get_accounts(self, params: dict | None = None) -> requests.Response:
        """Retrieve a list of accounts associated with the current IAM bearer token.

        Args:
            params: Query Parameters.

        Returns:
            A HTTP response.
        """
        url = f"{self.base_url}/api/2.0/token-accounts"
        data = json.dumps({"jwt": self._auth.iam_token})
        response = self.post(url=url, params=params, data=data)
        return response
