# IBM Confidential
# PID 5900-BAF
# Copyright StreamSets Inc., an IBM Company 2026

"""This module containing the AccessGroupsApiClient class."""

import requests
from ibm_watsonx_data_integration.cpd_api.base import BaseAPIClient
from typing import TYPE_CHECKING
from urllib.parse import quote

if TYPE_CHECKING:
    from ibm_watsonx_data_integration.common.auth import BaseAuthenticator

DEFAULT_ACCESS_GROUP_API_VERSION = "2.0"


class AccessGroupsApiClientAWS(BaseAPIClient):
    """The API Client of Access Groups."""

    def __init__(
        self,
        auth: "BaseAuthenticator",  # pragma: allowlist secret
        base_url: str = None,
    ) -> None:
        """Initializes the AccessGroupsApiClientAWS.

        Args:
            auth: The Authentication object.
            base_url: Default is None.
        """
        super().__init__(auth=auth, base_url=base_url)
        self.url_path = f"api/{DEFAULT_ACCESS_GROUP_API_VERSION}/accounts"

    def get_all_access_groups(self, scope_id: str, params: dict) -> requests.Response:
        """Lists all access groups under a user account. Will only list those the listed user can access.

        Args:
            scope_id: Scope id of a user.
            params: Query parameters.

        Returns:
            A HTTP response.
        """
        url = f"{self.base_url}/{self.url_path}/{quote(scope_id, safe='')}/descendants/groups"
        response = self.get(url=url, params=params)
        return response

    def get_access_group_by_id(
        self, scope_id: str, access_group_id: str, params: dict | None = None
    ) -> requests.Response:
        """Lists access group with specified uid.

        Args:
            scope_id: Scope id of a user.
            access_group_id: id of the group which you want to retrieve.
            params: Query parameters.

        Returns:
            A HTTP response.
        """
        url = f"{self.base_url}/{self.url_path}/{quote(scope_id, safe='')}/groups/{quote(access_group_id, safe='')}"
        response = self.get(url=url, params=params)
        return response

    def create_access_group(self, scope_id: str, data: str) -> requests.Response:
        """Creates a new access group.

        Args:
            scope_id: Scope id of a user.
            data: JSON with name, description, dynamic, and rules fields.

        Returns:
            A HTTP response.
        """
        url = f"{self.base_url}/{self.url_path}/{quote(scope_id, safe='')}/groups"
        response = self.post(url=url, data=data)
        return response

    def update_access_group(self, scope_id: str, access_group_id: str, data: str) -> requests.Response:
        """Updates existing access group.

        Args:
            scope_id: Scope id of a user.
            access_group_id: The group ID.
            data: JSON with fields to update (name, description, rules).

        Returns:
            A HTTP response.
        """
        url = f"{self.base_url}/{self.url_path}/{quote(scope_id, safe='')}/groups/{quote(access_group_id, safe='')}"
        response = self.patch(url=url, data=data)
        return response

    def delete_access_group(self, scope_id: str, access_group_id: str) -> requests.Response:
        """Deletes an access group from an account.

        Args:
            scope_id: Scope id of a user.
            access_group_id: The group ID.

        Returns:
            A HTTP response.
        """
        url = f"{self.base_url}/{self.url_path}/{quote(scope_id, safe='')}/groups/{quote(access_group_id, safe='')}"
        response = self.delete(url=url)
        return response

    def update_group_members(self, scope_id: str, access_group_id: str, data: str) -> requests.Response:
        """Updates group members (add or remove).

        Args:
            scope_id: Scope id of a user
            access_group_id: The group ID.
            data: JSON with memberType, memberUids, and op (ADD/DELETE/UPDATE).

        Returns:
            A HTTP response.
        """
        url = f"{self.base_url}/{self.url_path}/{quote(scope_id, safe='')}/groups/{quote(access_group_id, safe='')}"
        response = self.patch(url=url, data=data)
        return response

    def get_members(self, scope_id: str, access_group_id: str, params: dict | None = None) -> requests.Response:
        """Lists all members in an access group.

        Args:
            scope_id: Scope id of a user
            access_group_id: The group ID.
            params: Optional query parameters.

        Returns:
            A HTTP response.
        """
        url = (
            f"{self.base_url}/{self.url_path}/{quote(scope_id, safe='')}"
            f"/groups/{quote(access_group_id, safe='')}/members"
        )
        response = self.get(url=url, params=params or {})
        return response
