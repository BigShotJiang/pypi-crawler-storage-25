#  IBM Confidential
#  PID 5900-BAF
#  Copyright StreamSets Inc., an IBM Company 2026


"""This module contains the UserAPIClientAWS class."""

import requests
from ibm_watsonx_data_integration.cpd_api.base import BaseAPIClient
from typing import TYPE_CHECKING
from urllib.parse import quote

if TYPE_CHECKING:
    from ibm_watsonx_data_integration.common.auth import BaseAuthenticator


class UserAPIClientAWS(BaseAPIClient):
    """The API client of the AWS User service."""

    def __init__(
        self,
        auth: "BaseAuthenticator",  # pragma: allowlist secret
        base_url: str,
    ) -> None:
        """Initializes the UserAPIClientAWS.

        Args:
            auth: The Authentication object.
            base_url: The User Service URL.
        """
        super().__init__(auth=auth, base_url=base_url)
        self.url_path = "api/2.0/accounts"

    def get_users(self, account_id: str, params: dict | None = None) -> requests.Response:
        """Retrieve a list of aws users.

        Args:
            account_id: aws account id.
            params: Query Parameters.

        Returns:
            A HTTP response.
        """
        url = f"{self.base_url}/{self.url_path}/{quote(account_id, safe='')}/identity/users"
        response = self.get(url=url, params=params)
        return response

    def get_user_by_id(self, account_id: str, user_id: str, params: dict | None = None) -> requests.Response:
        """Retrieve an aws user.

        Args:
            account_id: aws account id.
            user_id: Unique identifier of the account.
            params: Query Parameters.

        Returns:
            A HTTP response.
        """
        url = f"{self.base_url}/{self.url_path}/{quote(account_id, safe='')}/identity/users/{quote(user_id, safe='')}"
        response = self.get(url=url, params=params)
        return response

    def delete_user(self, account_id: str, user_id: str) -> requests.Response:
        """Remove a user.

        Args:
            account_id: aws account id.
            user_id: Uid of the user.

        Returns:
            A HTTP response.
        """
        url = f"{self.base_url}/{self.url_path}/{quote(account_id, safe='')}/identity/users/{quote(user_id, safe='')}"
        response = self.delete(url=url)
        return response

    def update_user(self, account_id: str, user_id: str, data: dict) -> requests.Response:
        """Update the fields for a specific aws user in an account. Only displayName and status can be updated.

        Args:
            account_id: aws account id.
            user_id: Uid of the user.
            data: Dictionary containing any or all settings to update. For example:
                {
                    "displayName": "New display name",
                    "status": "INACTIVE"
                }

        Returns:
            A HTTP response.
        """
        url = f"{self.base_url}/{self.url_path}/{quote(account_id, safe='')}/identity/users/{quote(user_id, safe='')}"
        response = self.put(url=url, data=data)
        return response
