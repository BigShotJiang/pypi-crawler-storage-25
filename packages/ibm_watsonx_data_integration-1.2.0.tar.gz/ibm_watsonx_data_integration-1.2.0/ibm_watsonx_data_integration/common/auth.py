# IBM Confidential
# PID 5900-BAF
# Copyright StreamSets Inc., an IBM Company 2025

"""Authentication module."""

import base64
import json
import logging
import requests
import textwrap
import time
from abc import ABC, abstractmethod
from ibm_watsonx_data_integration.codegen.code_generatable import CodeGeneratable
from ibm_watsonx_data_integration.common.exceptions import (
    InvalidApiKeyError,
    InvalidUrlError,
)
from ibm_watsonx_data_integration.common.user_agent import get_user_agent
from urllib.parse import urlparse, urlunparse

logger = logging.getLogger(__name__)


class BaseAuthenticator(CodeGeneratable, ABC):
    """Base Authenticator class to be inherited by other authenticators."""

    def __init__(
        self,
        disable_ssl_verification: bool = False,
        proxies: dict[str, str] | None = None,
    ) -> None:
        """Initializes BaseAuthenticator.

        Args:
            disable_ssl_verification: Whether to disable SSL Verification.
            proxies: Optional proxy configuration for requests.
        """
        self.disable_ssl_verification = disable_ssl_verification
        self.proxies = proxies

    @abstractmethod
    def get_authorization_header(self) -> str:
        """Returns the token formatted to be plugged into the Authorization header of a request.

        Returns:
            The value to be plugged into the `Authorization` header of a request.
        """
        pass


class IAMAuthenticator(BaseAuthenticator):
    """Authenticator class to authenticate using an IBM Cloud IBM API Key.

    Attributes:
        api_key: API key being used to authenticate.
        token_url: URL being used to authenticate against.
        iam_token: The token generated using the api_key and url.
        token_expiry_time: UNIX time in seconds for when the token will expire.
    """

    # give a time buffer for expiration, to have ample time to make a request without the token being expired.
    EXPIRATION_TIME_BUFFER = 5

    def __init__(
        self,
        api_key: str,
        base_auth_url: str = "https://cloud.ibm.com",
        disable_ssl_verification: bool = False,
        proxies: dict[str, str] | None = None,
    ) -> None:
        """Initializes IAM Authenticator.

        Args:
            api_key: The API key to be used for authentication.
            base_auth_url: The base URL of the IBM cloud instance to be used for authentication.
            disable_ssl_verification: Whether to disable SSL Verification.
            proxies: Optional proxy configuration for requests.

        Raises:
            InvalidApiKeyError: If api_key is not of type str, or is an empty str.
            InvalidUrlError: If base_auth_url is not of type str, or is an empty str.
            requests.exceptions.HTTPError: If there is an error getting a valid token.
        """
        super().__init__(disable_ssl_verification=disable_ssl_verification, proxies=proxies)
        if not isinstance(api_key, str):
            raise InvalidApiKeyError("api_key should be of type str.")
        if not api_key:
            raise InvalidApiKeyError("api_key should not be an empty str.")

        if not isinstance(base_auth_url, str):
            raise InvalidUrlError("base_auth_url should be of type str.")
        if not base_auth_url:
            raise InvalidUrlError("base_auth_url should not be an empty str.")

        self._base_auth_url = base_auth_url
        self.api_key = api_key

        # base_auth_url looks like: "https://cloud.ibm.com"
        # token url looks like: "https://iam.cloud.ibm.com/identity/token"
        parsed_url = urlparse(url=base_auth_url)
        new_netloc = "iam." + parsed_url.netloc
        new_path = parsed_url.path + "/identity/token"
        if "aws.data.ibm.com" in self._base_auth_url:
            self._aws = True
            # Extract environment from base_auth_url format: https://api.{env}.aws.data.ibm.com
            env = self._base_auth_url.split(".")[1]
            self.token_url = f"https://{env}.aws.data.ibm.com/api/rest/mcsp/apikeys/token"
        else:
            self._aws = False
            self.token_url = urlunparse((parsed_url.scheme, new_netloc, new_path, "", "", ""))

        self.iam_token: str | None = None
        self.token_expiry_time: int | None = None
        self.request_token()

    def request_token(self) -> None:
        """Request a token from the servers using the API key.

        Raises:
            InvalidApiKeyError: If api_key is invalid.
            InvalidUrlError: If token_url is invalid.
            requests.exceptions.HTTPError: If there is an error getting a valid token.
        """
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": get_user_agent(),
        }
        data = {"apikey": self.api_key, "grant_type": "urn:ibm:params:oauth:grant-type:apikey"}

        try:
            response = requests.post(
                self.token_url,
                headers=headers,
                data=data,
                verify=not self.disable_ssl_verification,
                proxies=self.proxies,
            )
        except requests.exceptions.ConnectionError as e:
            logger.error("IAMAuthenticator incorrect URL. %s", e)
            raise InvalidUrlError("IAMAuthenticator incorrect URL.")
        if response.status_code == 400:
            raise InvalidApiKeyError("IAMAuthenticator api_key is not valid.")
        response.raise_for_status()

        if self._aws:
            self.iam_token = response.json()["token"]
        else:
            self.iam_token = response.json()["access_token"]
        self.token_expiry_time = response.json()["expiration"]

    def get_token(self) -> str:
        """Get existing token, or request a new one if the current token is expired.

        Returns:
            The current bearer token used for auth.
        """
        current_time = int(time.time())
        if self.iam_token is None:
            logger.debug("Getting first token.")
            self.request_token()
        elif (
            self.token_expiry_time is not None
            and (current_time + self.EXPIRATION_TIME_BUFFER) >= self.token_expiry_time
        ):
            logger.debug("Previous token expired, refreshing.")
            self.request_token()

        assert self.iam_token is not None, "Failed to obtain IAM token"
        return self.iam_token

    def get_authorization_header(self) -> str:
        """Returns the token formatted to be plugged into the Authorization header of a request.

        Returns:
            The value to be plugged into the `Authorization` header of a request.
        """
        return f"Bearer {self.get_token()}"

    def _as_init(self, masked: bool = True) -> str:
        """Returns a string on how to instantiate the auth object.

        Args:
            masked: Whether to mask sensitive credentials. Defaults to True.
        """
        if not masked:
            api_key = f'"{self.api_key}"'
        else:
            api_key = 'os.getenv("IBM_CLOUD_API_KEY")'

        return textwrap.dedent(f"""\
            IAMAuthenticator(
                api_key={api_key},
                base_auth_url="{self._base_auth_url}",
                disable_ssl_verification={self.disable_ssl_verification}
            )
        """)


class ZenApiKeyAuthenticator(BaseAuthenticator):
    """Authentication class for using a Zen API Key.

    Attributes:
        username: Username to use for authentication.
        zen_api_key: Zen API Key to use for authentication.
        disable_ssl_verification: Whether to disable SSL Verification.
    """

    def __init__(
        self,
        username: str,
        zen_api_key: str,
        disable_ssl_verification: bool = False,
        proxies: dict[str, str] | None = None,
    ) -> None:
        """__init__ for the class.

        Args:
            username: Username to use for authentication.
            zen_api_key: Zen API Key to use for authentication.
            disable_ssl_verification: Whether to disable SSL Verification.
            proxies: Optional proxy configuration for requests.
        """
        super().__init__(disable_ssl_verification=disable_ssl_verification, proxies=proxies)
        self.username = username
        self.zen_api_key = zen_api_key
        self.disable_ssl_verification = disable_ssl_verification

    def encode(self) -> str:
        """Encodes the username and Zen API key in base64.

        Returns:
            The base64-encoded string "<username>:<zen_api_key>".
        """
        combined = f"{self.username}:{self.zen_api_key}"
        encoded_bytes = base64.b64encode(combined.encode("utf-8"))

        return encoded_bytes.decode("utf-8")

    def get_authorization_header(self) -> str:
        """Returns the token formatted to be plugged into the Authorization header of a request.

        Returns:
            The value to be plugged into the `Authorization` header of a request.
        """
        return f"ZenApiKey {self.encode()}"

    def _as_init(self, masked: bool = True) -> str:
        """Returns a string on how to instantiate the auth object.

        Args:
            masked: Whether to mask sensitive credentials. Defaults to True.
        """
        if not masked:
            zen_api_key = f'"{self.zen_api_key}"'
        else:
            zen_api_key = 'os.getenv("ZEN_API_KEY")'

        return textwrap.dedent(f"""\
            ZenApiKeyAuthenticator(
                username="{self.username}",
                zen_api_key={zen_api_key},
                disable_ssl_verification={self.disable_ssl_verification}
            )
        """)


class BearerTokenAuthenticator(BaseAuthenticator):
    """Authentication class for directly using a bearer token.

    Attributes:
        bearer_token: bearer token to use for authentication.
        disable_ssl_verification: Whether to disable SSL Verification.
    """

    def __init__(
        self,
        bearer_token: str,
        disable_ssl_verification: bool = False,
        proxies: dict[str, str] | None = None,
    ) -> None:
        """__init__ for the class.

        Args:
            bearer_token: bearer token to use for authentication.
            disable_ssl_verification: Whether to disable SSL Verification.
            proxies: Optional proxy configuration for requests.
        """
        super().__init__(disable_ssl_verification=disable_ssl_verification, proxies=proxies)
        self.bearer_token = bearer_token
        self.disable_ssl_verification = disable_ssl_verification

    def get_authorization_header(self) -> str:
        """Returns the token formatted to be plugged into the Authorization header of a request.

        Returns:
            The value to be plugged into the `Authorization` header of a request.
        """
        return f"Bearer {self.bearer_token}"

    def _as_init(self, masked: bool = True) -> str:
        """Returns a string on how to instantiate the auth object.

        Args:
            masked: Whether to mask sensitive credentials. Defaults to True.
        """
        if not masked:
            bearer_token = f'"{self.bearer_token}"'
        else:
            bearer_token = 'os.getenv("BEARER_TOKEN")'

        return textwrap.dedent(f"""\
            BearerTokenAuthenticator(
                bearer_token={bearer_token},
                disable_ssl_verification={self.disable_ssl_verification}
            )
        """)


class ICP4DAuthenticator(BaseAuthenticator):
    """Authenticator for on-prem cpd using IAM or API credentials.

    Attributes:
        url: CPD instance URL.
        username: Username of the user trying to authenticate.
        password: Password of the user.
        zen_api_key: ZenApiKey of the user.
        disable_ssl_verification: Whether to disable SSL verification.
    """

    AUTH_PATH = "/icp4d-api/v1/authorize"
    # give a time buffer for expiration, to have ample time to make a request without the token being expired.
    EXPIRATION_TIME_BUFFER = 5

    def __init__(
        self,
        url: str,
        username: str,
        password: str | None = None,
        zen_api_key: str | None = None,
        disable_ssl_verification: bool = False,
        proxies: dict[str, str] | None = None,
    ) -> None:
        """Init for ICP4D Authenticator.

        Args:
            url: CPD instance URL
            username: Username of the user trying to authenticate
            password: Password of the user, if provided zen_api_key should be left None
            zen_api_key: ZenApiKey of the user, if provided password should be left None
            disable_ssl_verification: Whether to disable SSL verification. Default: ``False``.
            proxies: Optional proxy configuration for requests.
        """
        super().__init__(disable_ssl_verification=disable_ssl_verification, proxies=proxies)

        # save original input of url for _as_init()
        self._url = url

        if not url.endswith(self.AUTH_PATH):
            url = url + self.AUTH_PATH

        self.url = url

        self.username = username

        if password and zen_api_key:
            raise ValueError("Both password and zen_api_key should not be supplied. Only one.")

        self.password = password
        self.zen_api_key = zen_api_key

        self.iam_bearer_token: str | None = None

    def request_token(self) -> None:
        """Requests a new token from the endpoint."""
        logger.debug("Requesting cp4d token.")
        headers = {
            "Content-Type": "application/json",
            "User-Agent": get_user_agent(),
        }
        response = requests.post(
            url=self.url,
            headers=headers,
            data=json.dumps(dict(username=self.username, password=self.password, api_key=self.zen_api_key)),
            verify=not self.disable_ssl_verification,
            proxies=self.proxies,
        )
        response.raise_for_status()
        self.iam_bearer_token = response.json()["token"]

    def get_token(self) -> str:
        """Get existing token, or request a new one if the current token is expired.

        Returns:
            The current bearer token used for auth.
        """
        if self.iam_bearer_token is None:
            self.request_token()

        # After request_token(), iam_bearer_token should never be None
        assert self.iam_bearer_token is not None, "Token should be set after request_token()"
        return self.iam_bearer_token

    def get_authorization_header(self) -> str:
        """Get the authorization header to be used for requests."""
        return f"Bearer {self.get_token()}"

    def _as_init(self, masked: bool = True) -> str:
        """Returns a string on how to instantiate the auth object.

        Args:
            masked: Whether to mask sensitive credentials. Defaults to True.
        """
        if not masked:
            password = f'"{self.password}"' if self.password is not None else "None"
            zen_api_key = f'"{self.zen_api_key}"' if self.zen_api_key is not None else "None"
        else:
            password = 'os.getenv("CP4D_PASSWORD")'
            zen_api_key = 'os.getenv("ZEN_API_KEY")'

        return textwrap.dedent(f"""\
            ICP4DAuthenticator(
                url="{self._url}",
                username="{self.username}",
                password={password},
                zen_api_key={zen_api_key},
                disable_ssl_verification={self.disable_ssl_verification}
            )
        """)
