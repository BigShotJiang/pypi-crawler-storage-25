# IBM Confidential
# PID 5900-BAF
# Copyright StreamSets Inc., an IBM Company 2025

"""This module contains project-wide constants."""

from enum import Enum

DATASTAGE = "datastage"

RESOURCE_PLAN_ID_MAP = {DATASTAGE: "aaa6e83e-27df-4393-9a55-63feec09c685"}
DEFAULT_RESOURCE_REGION_ID_MAP = {DATASTAGE: "us-south"}

# BASE MODEL VARS
HIDDEN_DICTIONARY = "_hidden_key_paths"
EXPOSE_SUB_CLASS = "_expose"

# PROD URLS
PROD_BASE_URL = "https://cloud.ibm.com"


class IBMCloudRegion(str, Enum):
    """IBM Cloud regions with their corresponding base API URLs."""

    DALLAS = "https://api.dataplatform.cloud.ibm.com"
    FRANKFURT = "https://api.eu-de.dataplatform.cloud.ibm.com"
    LONDON = "https://api.eu-gb.dataplatform.cloud.ibm.com"
    TOKYO = "https://api.jp-tok.dataplatform.cloud.ibm.com"
    SYDNEY = "https://api.au-syd.dai.cloud.ibm.com"
    TORONTO = "https://api.ca-tor.dai.cloud.ibm.com"


PROD_BASE_API_URL = IBMCloudRegion.DALLAS


class DataActions(str, Enum):
    """Actions supported in EXPOSED_DATH_PATH."""

    IGNORE = "IGNORE"
    EXPOSE = "EXPOSE"  # Shouldn't be used on the base level


class DeploymentEnvironment(str, Enum):
    """Possible deployment platforms."""

    AWS = "AWS"
    ON_PREM = "ON_PREM"
    SAAS = "SAAS"


SUPPORTED_FLOWS = {"streaming", "batch"}
