#  IBM Confidential
#  PID 5900-BAF
#  Copyright StreamSets Inc., an IBM Company 2026

"""Module containing unit of work implementation for transactional like operations."""

import logging
from collections.abc import Callable
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class OperationType(Enum):
    """Types of operations that can be tracked in Unit of Work."""

    INSERT = "insert"
    UPDATE = "update"
    DELETE = "delete"


class Operation:
    """Represents a single operation to be performed."""

    def __init__(self, operation_type: OperationType, entity: Any, action: Callable) -> None:
        """__init__ for Operation class."""
        self.operation_type = operation_type
        self.entity = entity
        self.action = action

    def execute(self) -> Any:
        """Returns the result of executing the action."""
        return self.action()


class UnitOfWork:
    """Tracks operations and commits them all at once."""

    def __init__(self) -> None:
        """__init__ for UnitOfWork class."""
        self._operations: list[Operation] = []
        self._committed = False

    def register_new(self, entity: Any, action: Callable) -> None:
        """Register a new entity to be inserted.

        Args:
            entity: The entity to be created.
            action: The callable that performs the insert operation.
        """
        operation = Operation(OperationType.INSERT, entity, action)
        self._operations.append(operation)

    def register_dirty(self, entity: Any, action: Callable) -> None:
        """Register an entity to be updated.

        Args:
            entity: The entity to be updated.
            action: The callable that performs the update operation.
        """
        operation = Operation(OperationType.UPDATE, entity, action)
        self._operations.append(operation)

    def register_deleted(self, entity: Any, action: Callable) -> None:
        """Register an entity to be deleted.

        Args:
            entity: The entity to be deleted.
            action: The callable that performs the delete operation.
        """
        operation = Operation(OperationType.DELETE, entity, action)
        self._operations.append(operation)

    def commit(self) -> list[Any]:
        """Commit all registered operations.

        Executes all operations in order. If any operation fails,
        the entire transaction is considered failed.

        Returns:
            List of results from each operation.

        Raises:
            RuntimeError: If the Unit of Work has already been committed.
            Exception: If any operation fails during execution.
        """
        if self._committed:
            raise RuntimeError("Unit of Work already committed")

        try:
            results = []
            for operation in self._operations:
                result = operation.execute()
                results.append(result)

            self._committed = True
            logger.debug("Successfully committed %s operations", len(self._operations))
            return results

        except Exception as e:
            logger.error("Commit failed: %s", e)
            self.rollback()
            raise

    def rollback(self) -> None:
        """Rollback all operations by clearing the operation list."""
        self._operations.clear()
        logger.debug("Rolled back all operations")

    def has_changes(self) -> bool:
        """Returns True if there are pending operations, False otherwise."""
        return len(self._operations) > 0

    def clear(self) -> None:
        """Clear all pending operations without executing them."""
        self._operations.clear()
        self._committed = False
