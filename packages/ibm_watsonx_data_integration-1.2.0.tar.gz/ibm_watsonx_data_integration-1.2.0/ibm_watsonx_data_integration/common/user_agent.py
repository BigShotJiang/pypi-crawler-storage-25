# IBM Confidential
# PID 5900-BAF
# Copyright StreamSets Inc., an IBM Company 2026

"""Module for generating User-Agent header."""

import platform
from ibm_watsonx_data_integration.__version__ import __version__


def get_user_agent() -> str:
    """Returns User-Agent header with SDK info."""
    return (
        f"ibm-watsonx-data-integration-python-sdk/{__version__} "
        f"(lang=Python; os={platform.system()}; version={platform.python_version()})"
    )


# Made with Bob
