"""Optional bot memory backed by SQLite.

Lets a bot remember encounters with other bots. Use it however you want —
this is just a helper that gives you a typed key-value store keyed by
counterparty bot ID, plus a recent-events log.

Heavyweight memory (vector RAG, long-term reflection summaries) is out of
scope; for that, plug in Mem0 or Letta directly.
"""

from __future__ import annotations

import json
import sqlite3
import time
from dataclasses import dataclass
from typing import Any, Optional


@dataclass(frozen=True)
class CounterpartyNote:
    counterparty_id: str
    kind: str
    payload: dict[str, Any]
    ts: float


@dataclass
class CounterpartyProfile:
    counterparty_id: str
    trust_score: int = 0
    interactions: int = 0
    last_seen: float = 0.0
    tags: list[str] = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self.tags is None:
            self.tags = []


class BotMemory:
    """SQLite-backed per-counterparty notes + profile."""

    def __init__(self, path: str = "./zorlek_memory.db"):
        self.conn = sqlite3.connect(path)
        self.conn.row_factory = sqlite3.Row
        self._init_schema()

    def _init_schema(self) -> None:
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS notes (
                id INTEGER PRIMARY KEY,
                counterparty_id TEXT NOT NULL,
                kind TEXT NOT NULL,
                payload TEXT NOT NULL,
                ts REAL NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_notes_cp_ts
                ON notes(counterparty_id, ts DESC);

            CREATE TABLE IF NOT EXISTS profiles (
                counterparty_id TEXT PRIMARY KEY,
                trust_score INTEGER NOT NULL DEFAULT 0,
                interactions INTEGER NOT NULL DEFAULT 0,
                last_seen REAL NOT NULL DEFAULT 0,
                tags TEXT NOT NULL DEFAULT '[]'
            );
            """
        )
        self.conn.commit()

    def note(self, counterparty_id: str, kind: str, payload: dict[str, Any]) -> None:
        """Append a structured event note about a counterparty."""
        self.conn.execute(
            "INSERT INTO notes(counterparty_id, kind, payload, ts) VALUES (?, ?, ?, ?)",
            (counterparty_id, kind, json.dumps(payload), time.time()),
        )
        self.conn.execute(
            """
            INSERT INTO profiles(counterparty_id, interactions, last_seen)
            VALUES(?, 1, ?)
            ON CONFLICT(counterparty_id) DO UPDATE SET
                interactions = interactions + 1,
                last_seen = excluded.last_seen
            """,
            (counterparty_id, time.time()),
        )
        self.conn.commit()

    def recent(self, counterparty_id: str, limit: int = 10) -> list[CounterpartyNote]:
        cur = self.conn.execute(
            "SELECT counterparty_id, kind, payload, ts FROM notes "
            "WHERE counterparty_id = ? ORDER BY ts DESC LIMIT ?",
            (counterparty_id, limit),
        )
        return [
            CounterpartyNote(
                counterparty_id=r["counterparty_id"],
                kind=r["kind"],
                payload=json.loads(r["payload"]),
                ts=r["ts"],
            )
            for r in cur.fetchall()
        ]

    def trust(self, counterparty_id: str, delta: int) -> int:
        """Adjust trust score. Returns the new value."""
        self.conn.execute(
            """
            INSERT INTO profiles(counterparty_id, trust_score, interactions, last_seen)
            VALUES(?, ?, 0, ?)
            ON CONFLICT(counterparty_id) DO UPDATE SET
                trust_score = trust_score + ?,
                last_seen = excluded.last_seen
            """,
            (counterparty_id, delta, time.time(), delta),
        )
        self.conn.commit()
        row = self.conn.execute(
            "SELECT trust_score FROM profiles WHERE counterparty_id = ?",
            (counterparty_id,),
        ).fetchone()
        return row["trust_score"] if row else 0

    def profile(self, counterparty_id: str) -> Optional[CounterpartyProfile]:
        row = self.conn.execute(
            "SELECT * FROM profiles WHERE counterparty_id = ?",
            (counterparty_id,),
        ).fetchone()
        if row is None:
            return None
        return CounterpartyProfile(
            counterparty_id=row["counterparty_id"],
            trust_score=row["trust_score"],
            interactions=row["interactions"],
            last_seen=row["last_seen"],
            tags=json.loads(row["tags"]),
        )

    def tag(self, counterparty_id: str, tag: str) -> None:
        """Add a free-form tag (e.g., "rugged_me", "fair_partner")."""
        profile = self.profile(counterparty_id)
        tags = profile.tags if profile else []
        if tag not in tags:
            tags.append(tag)
        self.conn.execute(
            """
            INSERT INTO profiles(counterparty_id, tags, interactions, last_seen)
            VALUES(?, ?, 0, ?)
            ON CONFLICT(counterparty_id) DO UPDATE SET
                tags = excluded.tags
            """,
            (counterparty_id, json.dumps(tags), time.time()),
        )
        self.conn.commit()

    def close(self) -> None:
        self.conn.close()
