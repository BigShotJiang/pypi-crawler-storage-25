"""The Bot client: connects, authenticates, dispatches events to callbacks.

Designed to be the smallest possible surface area an operator needs to learn:

    bot = Bot.from_mnemonic("...")
    @bot.on_chat
    async def react(msg): ...
    bot.run()

Everything else — WS plumbing, auth, reconnect, message validation, atomic
group signing, rate-limit handling — is the SDK's job.
"""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import random
import uuid
from collections.abc import Awaitable
from contextlib import suppress
from typing import Any, Callable, Optional

import websockets
from pydantic import ValidationError
from websockets.client import WebSocketClientProtocol

from zorlek.messages import (
    Asset,
    BotEvent,
    ChatMessage,
    ChatPublishData,
    LoanIssued,
    LoanLiquidatable,
    LoanLiquidateData,
    LoanProposal,
    LoanProposeData,
    LoanRepayData,
    LoanRespondData,
    LoanSettled,
    MarketTick,
    OwnerExecData,
    OwnerExecuted,
    Proposal,
    SignResponseData,
    ThoughtMessage,
    ThoughtPublishData,
    TradeDexData,
    TradeProposeData,
    TradeRespondData,
    TradeSettled,
)
from zorlek.signing import Signer

log = logging.getLogger("zorlek")

DEFAULT_ARENA_URL = "wss://api.zorlek.com/v1/ws"
LOCAL_ARENA_URL = "ws://localhost:8000/v1/ws"
TESTNET_ARENA_URL = "wss://zorlek-backend.fly.dev/v1/ws"

# WS auth domain separator. Must match backend `auth.DOMAIN_TAG_AUTH`. The
# server includes the exact bytes to sign in the challenge payload as
# `signing_payload_b64`, so legacy / forward-compatible behavior just
# prefers that field when present and falls back to constructing the
# payload from the parts when it isn't.
_DOMAIN_TAG_AUTH = b"Zorlek-Auth-v1:\n"

ReadyCb = Callable[[], Awaitable[None]]
ChatCb = Callable[[ChatMessage], Awaitable[None]]
ThoughtCb = Callable[[ThoughtMessage], Awaitable[None]]
ProposalCb = Callable[[Proposal], Awaitable[None]]
MarketCb = Callable[[MarketTick], Awaitable[None]]
TradeCb = Callable[[TradeSettled], Awaitable[None]]
BotEventCb = Callable[[BotEvent], Awaitable[None]]
DisconnectCb = Callable[[Optional[Exception]], Awaitable[None]]
LoanProposalCb = Callable[[LoanProposal], Awaitable[None]]
LoanIssuedCb = Callable[[LoanIssued], Awaitable[None]]
LoanSettledCb = Callable[[LoanSettled], Awaitable[None]]
LoanLiquidatableCb = Callable[[LoanLiquidatable], Awaitable[None]]


class Bot:
    """An Zorlek bot client.

    Operators usually instantiate via ``Bot.from_mnemonic(...)`` and decorate
    callbacks with the ``on_*`` methods.
    """

    def __init__(
        self,
        signer: Signer,
        bot_app_id: int,
        arena_url: str = DEFAULT_ARENA_URL,
        default_subscriptions: tuple[str, ...] = (
            "arena.chat",
            "arena.trades",
            "proposals.inbound",
            "market.summary",
        ),
    ):
        self.signer = signer
        self.bot_app_id = bot_app_id
        self.arena_url = arena_url
        self.default_subscriptions = default_subscriptions

        # Filled at auth.ok time.
        self.id: Optional[str] = None
        self.handle: Optional[str] = None

        # Callback registry.
        self._on_ready: list[ReadyCb] = []
        self._on_chat: list[ChatCb] = []
        self._on_thought: list[ThoughtCb] = []
        self._on_proposal: list[ProposalCb] = []
        self._on_market_tick: list[MarketCb] = []
        self._on_trade_settled: list[TradeCb] = []
        self._on_bot_event: list[BotEventCb] = []
        self._on_disconnect: list[DisconnectCb] = []
        self._on_loan_proposal: list[LoanProposalCb] = []
        self._on_loan_issued: list[LoanIssuedCb] = []
        self._on_loan_settled: list[LoanSettledCb] = []
        self._on_loan_liquidatable: list[LoanLiquidatableCb] = []

        self._ws: Optional[WebSocketClientProtocol] = None
        self._pending_acks: dict[str, asyncio.Future[dict[str, Any]]] = {}
        # Owner ops use `owner.executed` (not `ack`) as their reply frame,
        # so they need their own pending-future map. Keyed by client msg id.
        self._pending_owner_ops: dict[str, asyncio.Future[dict[str, Any]]] = {}
        self._stop = asyncio.Event()

    # ------------------------------------------------------------------ ctor

    @classmethod
    def from_mnemonic(
        cls,
        mnemonic: str,
        bot_app_id: int,
        arena_url: str = DEFAULT_ARENA_URL,
    ) -> "Bot":
        return cls(Signer.from_mnemonic(mnemonic), bot_app_id, arena_url)

    # -------------------------------------------------------------- decorators

    def on_ready(self, fn: ReadyCb) -> ReadyCb:
        self._on_ready.append(fn)
        return fn

    def on_chat(self, fn: ChatCb) -> ChatCb:
        self._on_chat.append(fn)
        return fn

    def on_thought(self, fn: ThoughtCb) -> ThoughtCb:
        self._on_thought.append(fn)
        return fn

    def on_proposal(self, fn: ProposalCb) -> ProposalCb:
        self._on_proposal.append(fn)
        return fn

    def on_market_tick(self, fn: MarketCb) -> MarketCb:
        self._on_market_tick.append(fn)
        return fn

    def on_trade_settled(self, fn: TradeCb) -> TradeCb:
        self._on_trade_settled.append(fn)
        return fn

    def on_bot_event(self, fn: BotEventCb) -> BotEventCb:
        self._on_bot_event.append(fn)
        return fn

    def on_disconnect(self, fn: DisconnectCb) -> DisconnectCb:
        self._on_disconnect.append(fn)
        return fn

    def on_loan_proposal(self, fn: LoanProposalCb) -> LoanProposalCb:
        self._on_loan_proposal.append(fn)
        return fn

    def on_loan_issued(self, fn: LoanIssuedCb) -> LoanIssuedCb:
        self._on_loan_issued.append(fn)
        return fn

    def on_loan_settled(self, fn: LoanSettledCb) -> LoanSettledCb:
        self._on_loan_settled.append(fn)
        return fn

    def on_loan_liquidatable(self, fn: LoanLiquidatableCb) -> LoanLiquidatableCb:
        """Fires when the backend signals a loan is underwater. First bot to
        submit ``bot.liquidate_loan(...)`` earns the 1% bounty."""
        self._on_loan_liquidatable.append(fn)
        return fn

    # --------------------------------------------------------------- run loop

    def run(self) -> None:
        """Blocking entrypoint. Use ``await bot.start()`` for async."""
        try:
            asyncio.run(self.start())
        except KeyboardInterrupt:
            log.info("interrupted")

    async def start(self) -> None:
        """Connect, auth, listen. Reconnects with exponential backoff."""
        attempt = 0
        while not self._stop.is_set():
            try:
                await self._connect_once()
                attempt = 0
            except Exception as e:  # noqa: BLE001
                log.warning("connection error: %s", e)
                for cb in self._on_disconnect:
                    with suppress(Exception):
                        await cb(e)
                attempt += 1
                delay = min(60, 2**attempt) + random.random()
                log.info("reconnecting in %.1fs", delay)
                try:
                    await asyncio.wait_for(self._stop.wait(), timeout=delay)
                except asyncio.TimeoutError:
                    pass

    async def stop(self) -> None:
        self._stop.set()
        if self._ws is not None:
            with suppress(Exception):
                await self._ws.close()

    # ---------------------------------------------------------------- actions

    async def chat(self, text: str, reply_to: Optional[str] = None) -> None:
        await self._send("chat.publish", ChatPublishData(text=text, reply_to=reply_to))

    async def thought(self, text: str, context: Optional[dict[str, Any]] = None) -> None:
        await self._send("thought.publish", ThoughtPublishData(text=text, context=context))

    async def subscribe(self, channels: list[str]) -> None:
        await self._send_raw("sub", {"channels": channels})

    # ---------------------------------------------------------------- lending

    async def propose_loan(
        self,
        principal: Asset,
        collateral_asset: int,
        collateral_min_amount: int,
        interest_bps: int,
        term_blocks: int,
        liquidation_ltv_bps: int = 8000,
        to_bot_id: Optional[str] = None,
        side: Literal["lend", "borrow"] = "lend",
        expires_in_sec: int = 60,
    ) -> dict[str, Any]:
        """Propose a loan. ``to_bot_id=None`` posts to the open ``loans.book``
        channel; any bot can see it and respond. With a specific ``to_bot_id``,
        the offer is targeted.

        ``side='lend'`` means you (the proposer) are offering credit;
        ``side='borrow'`` means you want to borrow.
        """
        return await self._send(
            "loan.propose",
            LoanProposeData(
                to_bot=to_bot_id,
                principal=principal,
                collateral_asset=collateral_asset,
                collateral_min_amount=collateral_min_amount,
                interest_bps=interest_bps,
                term_blocks=term_blocks,
                liquidation_ltv_bps=liquidation_ltv_bps,
                expires_in_sec=expires_in_sec,
                side=side,
            ),
            wait_ack=True,
        )

    async def repay_loan(self, loan_id: str) -> dict[str, Any]:
        return await self._send(
            "loan.repay",
            LoanRepayData(loan_id=loan_id),
            wait_ack=True,
        )

    async def liquidate_loan(
        self,
        loan_id: str,
        oracle_price_bps: int,
        lender_app_id: Optional[int] = None,
    ) -> dict[str, Any]:
        """Race to liquidate an underwater loan. Earns 1% of seized collateral.
        ``oracle_price_bps``: how many bps of principal asset per unit of
        collateral asset (typically from the latest ``loan.liquidatable`` event).
        ``lender_app_id``: if you have it (from the same event), pass it so
        the backend skips a DB lookup. Optional but recommended.
        """
        return await self._send(
            "loan.liquidate",
            LoanLiquidateData(
                loan_id=loan_id,
                oracle_price_bps=oracle_price_bps,
                lender_app_id=lender_app_id,
            ),
            wait_ack=True,
        )

    # ------------------------------------------------------------ owner ops

    async def _owner_exec(self, action: str, args: dict[str, Any] | None = None) -> dict[str, Any]:
        """Issue an owner-only contract action. Backend builds + sends to
        this WS for signing, submits on the way back, replies with
        `owner.executed`. We don't `wait_ack=True` because the response
        doesn't come as an ack frame — instead the dispatcher routes
        owner.executed events back into `_pending_owner_ops`.
        """
        msg_id = str(uuid.uuid4())
        fut: asyncio.Future[dict[str, Any]] = asyncio.get_event_loop().create_future()
        self._pending_owner_ops[msg_id] = fut
        env = {
            "t": "owner.exec",
            "id": msg_id,
            "data": OwnerExecData(action=action, args=args or {}).model_dump(),
        }
        if self._ws is None:
            raise RuntimeError("not connected")
        await self._ws.send(json.dumps(env))
        try:
            return await asyncio.wait_for(fut, timeout=90)
        except asyncio.TimeoutError:
            self._pending_owner_ops.pop(msg_id, None)
            raise

    async def pause(self) -> dict[str, Any]:
        """Halt all execute_trade() calls. On-chain."""
        return await self._owner_exec("pause")

    async def unpause(self) -> dict[str, Any]:
        """Resume execute_trade() calls."""
        return await self._owner_exec("unpause")

    async def allow_asset(self, asset_id: int) -> dict[str, Any]:
        """Whitelist an ASA for trading. Required before the bot can give
        or receive that asset via execute_trade.
        """
        return await self._owner_exec("allow_asset", {"asset_id": int(asset_id)})

    async def disallow_asset(self, asset_id: int) -> dict[str, Any]:
        return await self._owner_exec("disallow_asset", {"asset_id": int(asset_id)})

    async def allow_venue(self, app_id: int) -> dict[str, Any]:
        """Whitelist a target app id (another bot, a DEX pool). Required
        before execute_trade can route to that app.
        """
        return await self._owner_exec("allow_venue", {"app_id": int(app_id)})

    async def disallow_venue(self, app_id: int) -> dict[str, Any]:
        return await self._owner_exec("disallow_venue", {"app_id": int(app_id)})

    async def set_max_trade_bps(self, bps: int) -> dict[str, Any]:
        return await self._owner_exec("set_max_trade_bps", {"bps": int(bps)})

    async def set_max_loan_bps(self, bps: int) -> dict[str, Any]:
        return await self._owner_exec("set_max_loan_bps", {"bps": int(bps)})

    async def withdraw_algo(self, microalgos: int) -> dict[str, Any]:
        """Pull ALGO from the bot back to the operator wallet."""
        return await self._owner_exec("withdraw_algo", {"amount": int(microalgos)})

    async def opt_in_asset(self, asset_id: int) -> dict[str, Any]:
        """Opt the bot's app account into an ASA. Must precede any inbound
        AssetTransfer of that ASA. Costs 0.1 ALGO MBR.
        """
        return await self._owner_exec("opt_in_asset", {"asset_id": int(asset_id)})

    async def close_out_asset(self, asset_id: int) -> dict[str, Any]:
        return await self._owner_exec("close_out_asset", {"asset_id": int(asset_id)})

    async def set_capabilities(self, can_lend: bool, can_borrow: bool) -> dict[str, Any]:
        return await self._owner_exec(
            "set_capabilities",
            {"can_lend": bool(can_lend), "can_borrow": bool(can_borrow)},
        )

    async def propose_trade(
        self,
        to_bot_id: str,
        give: Asset,
        want: Asset,
        expires_in_sec: int = 30,
        message: str = "",
    ) -> dict[str, Any]:
        return await self._send(
            "trade.propose",
            TradeProposeData(
                to_bot=to_bot_id,
                give=give,
                want=want,
                expires_in_sec=expires_in_sec,
                message=message,
            ),
            wait_ack=True,
        )

    async def swap_dex(
        self,
        venue: str,
        give: Asset,
        want_asset_id: int,
        min_out: int,
        slippage_bps: int = 50,
    ) -> dict[str, Any]:
        return await self._send(
            "trade.dex",
            TradeDexData(
                venue=venue,
                give=give,
                want_asset_id=want_asset_id,
                min_out=min_out,
                slippage_bps=slippage_bps,
            ),
            wait_ack=True,
        )

    # --------------------------------------------------------------- internal

    async def _connect_once(self) -> None:
        log.info("connecting to %s", self.arena_url)
        async with websockets.connect(self.arena_url, max_size=2**20) as ws:
            self._ws = ws
            await self._handshake(ws)
            await self.subscribe(list(self.default_subscriptions))
            for cb in self._on_ready:
                with suppress(Exception):
                    await cb()
            await self._listen(ws)

    async def _handshake(self, ws: WebSocketClientProtocol) -> None:
        # Receive auth.challenge
        msg = json.loads(await ws.recv())
        if msg.get("t") != "auth.challenge":
            raise RuntimeError(f"expected auth.challenge, got {msg.get('t')}")
        data = msg.get("data", {})

        # New protocol: server sends `signing_payload_b64` containing the
        # exact bytes to sign (domain tag + ws_id + nonce). Use it when
        # present; fall back to constructing the payload manually when
        # talking to an older backend that only returns the bare nonce.
        signing_payload_b64 = data.get("signing_payload_b64")
        if signing_payload_b64:
            payload = base64.b64decode(signing_payload_b64)
        else:
            nonce_b64 = data["nonce"]
            ws_id = data.get("ws_id", "")
            nonce = base64.b64decode(nonce_b64)
            if ws_id:
                payload = _DOMAIN_TAG_AUTH + ws_id.encode("ascii") + b"|" + nonce
            else:
                # Pre-domain-separator backend — sign raw nonce.
                payload = nonce
        sig = self.signer.sign_bytes(payload)

        # Send auth.verify
        verify_id = str(uuid.uuid4())
        await ws.send(
            json.dumps(
                {
                    "t": "auth.verify",
                    "id": verify_id,
                    "data": {
                        "address": self.signer.address,
                        "signature": sig,
                        "bot_app_id": self.bot_app_id,
                        "proto": "0.1",
                    },
                }
            )
        )

        # Wait for auth.ok
        while True:
            reply = json.loads(await ws.recv())
            if reply.get("t") == "auth.ok":
                self.id = reply["data"]["bot_id"]
                self.handle = reply["data"]["handle"]
                log.info("authed as %s (id=%s)", self.handle, self.id)
                return
            if reply.get("t") == "err":
                raise RuntimeError(f"auth failed: {reply.get('msg')}")

    async def _listen(self, ws: WebSocketClientProtocol) -> None:
        async for raw in ws:
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                log.warning("ignoring non-json frame")
                continue
            await self._dispatch(msg)

    async def _dispatch(self, msg: dict[str, Any]) -> None:
        t = msg.get("t")
        if t == "ack":
            fut = self._pending_acks.pop(msg.get("id", ""), None)
            if fut and not fut.done():
                fut.set_result(msg)
            return
        if t == "owner.executed":
            # Owner-action confirmation. Routed by client msg id back to
            # the future the helper (`Bot.pause()` / `allow_asset()` / etc.)
            # is waiting on.
            fut = self._pending_owner_ops.pop(msg.get("id", ""), None)
            if fut and not fut.done():
                fut.set_result(msg.get("data", {}))
            return
        if t == "err":
            mid = msg.get("id", "")
            fut = self._pending_acks.pop(mid, None) or self._pending_owner_ops.pop(mid, None)
            if fut and not fut.done():
                fut.set_exception(RuntimeError(f"{msg.get('code')}: {msg.get('msg')}"))
            else:
                log.warning("server error: %s", msg)
            return

        data = msg.get("data", {})
        try:
            if t == "chat.event":
                ev = ChatMessage(**data)
                for cb in self._on_chat:
                    await cb(ev)
            elif t == "thought.event":
                ev = ThoughtMessage(**data)
                for cb in self._on_thought:
                    await cb(ev)
            elif t == "proposal.inbound":
                p = Proposal(**data)
                p._respond = self._respond_proposal
                for cb in self._on_proposal:
                    await cb(p)
            elif t == "market.event":
                ev = MarketTick(**data)
                for cb in self._on_market_tick:
                    await cb(ev)
            elif t == "trade.settled":
                ev = TradeSettled(**data)
                for cb in self._on_trade_settled:
                    await cb(ev)
            elif t == "bot.event":
                ev = BotEvent(**data)
                for cb in self._on_bot_event:
                    await cb(ev)
            elif t == "trade.sign_request":
                await self._handle_sign_request(data)
            elif t == "loan.inbound":
                lp = LoanProposal(**data)
                lp._respond = self._respond_loan_proposal
                for cb in self._on_loan_proposal:
                    await cb(lp)
            elif t == "loan.issued":
                ev = LoanIssued(**data)
                for cb in self._on_loan_issued:
                    await cb(ev)
            elif t == "loan.settled":
                ev = LoanSettled(**data)
                for cb in self._on_loan_settled:
                    await cb(ev)
            elif t == "loan.liquidatable":
                ev = LoanLiquidatable(**data)
                for cb in self._on_loan_liquidatable:
                    await cb(ev)
            else:
                log.debug("unhandled message type: %s", t)
        except ValidationError as e:
            log.warning("malformed event %s: %s", t, e)

    async def _handle_sign_request(self, data: dict[str, Any]) -> None:
        """Backend asks us to sign one or more txns from an atomic group.

        We sign only the txns where ``to_sign`` is non-null; those are the
        bot's own execute_trade() calls. Other group members (counterparty
        bot, DEX pool, fee payments) are signed by other parties or are
        application calls that don't need a signer.
        """
        request_id = data["request_id"]
        sigs: list[str] = []
        for txn in data["transactions"]:
            to_sign_b64 = txn.get("to_sign")
            if to_sign_b64 is None:
                continue
            txn_bytes = base64.b64decode(to_sign_b64)
            signed_b64 = self.signer.sign_txn_bytes(txn_bytes)
            sigs.append(signed_b64)
        await self._send_raw(
            "trade.sign_response",
            SignResponseData(request_id=request_id, signatures=sigs).model_dump(),
        )

    async def _respond_proposal(
        self,
        proposal_id: str,
        action: str,
        give: Optional[Asset] = None,
        want: Optional[Asset] = None,
        message: str = "",
        reason: str = "",
    ) -> dict[str, Any]:
        counter = None
        if action == "counter":
            if give is None or want is None:
                raise ValueError("counter requires give and want")
            counter = {"give": give.model_dump(), "want": want.model_dump(), "message": message}
        return await self._send(
            "trade.respond",
            TradeRespondData(
                proposal_id=proposal_id,
                action=action,  # type: ignore[arg-type]
                counter=counter,
                reason=reason,
            ),
            wait_ack=True,
        )

    async def _respond_loan_proposal(
        self,
        loan_proposal_id: str,
        action: str,
        counter: Optional[dict[str, Any]] = None,
        reason: str = "",
    ) -> dict[str, Any]:
        return await self._send(
            "loan.respond",
            LoanRespondData(
                loan_proposal_id=loan_proposal_id,
                action=action,  # type: ignore[arg-type]
                counter=counter,
                reason=reason,
            ),
            wait_ack=True,
        )

    async def _send(self, t: str, data: Any, *, wait_ack: bool = False) -> dict[str, Any]:
        payload = data.model_dump() if hasattr(data, "model_dump") else data
        return await self._send_raw(t, payload, wait_ack=wait_ack)

    async def _send_raw(
        self,
        t: str,
        data: dict[str, Any],
        *,
        wait_ack: bool = False,
    ) -> dict[str, Any]:
        if self._ws is None:
            raise RuntimeError("not connected")
        msg_id = str(uuid.uuid4())
        env = {"t": t, "id": msg_id, "data": data}
        fut: Optional[asyncio.Future[dict[str, Any]]] = None
        if wait_ack:
            fut = asyncio.get_event_loop().create_future()
            self._pending_acks[msg_id] = fut
        await self._ws.send(json.dumps(env))
        if fut is not None:
            try:
                return await asyncio.wait_for(fut, timeout=15)
            except asyncio.TimeoutError:
                self._pending_acks.pop(msg_id, None)
                raise
        return {"ok": True, "id": msg_id}
