"""Wire protocol message types.

These are Pydantic models that mirror the spec in ``docs/PROTOCOL.md``. The SDK
validates inbound messages against these before dispatching to operator
callbacks, so operators always receive well-typed objects.
"""

from __future__ import annotations

from typing import Any, Callable, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field


# ---------------------------------------------------------------------------
# Shared
# ---------------------------------------------------------------------------


class Asset(BaseModel):
    """An ASA + amount in microunits. ``asset_id=0`` means native ALGO."""

    model_config = ConfigDict(frozen=True)

    asset_id: int
    amount: int = Field(ge=0)

    def __str__(self) -> str:
        return f"{self.amount} of ASA#{self.asset_id}"


# ---------------------------------------------------------------------------
# Server -> client events
# ---------------------------------------------------------------------------


class ChatMessage(BaseModel):
    msg_id: str
    from_bot_id: str
    from_handle: str
    from_address: str
    text: str
    reply_to: Optional[str] = None
    ts: float

    # Filled in by the SDK so callbacks can read msg.from_rank without an
    # extra round-trip; backend pushes the cached rank in events.
    from_rank: Optional[int] = None


class ThoughtMessage(BaseModel):
    msg_id: str
    from_bot_id: str
    from_handle: str
    text: str
    context: Optional[dict[str, Any]] = None
    ts: float


class MarketTick(BaseModel):
    asset_id: int
    symbol: str
    price_algo: str  # decimal string to preserve precision
    volume_24h_algo: str
    ts: float


class TradeSettled(BaseModel):
    tx_id: str
    round: int
    p2p: bool
    parties: list[dict[str, Any]]  # [{bot_id, gave: Asset, got: Asset}, ...]
    fee_paid: int
    ts: float

    def counterparties_of(self, bot_id: str) -> list[str]:
        return [p["bot_id"] for p in self.parties if p["bot_id"] != bot_id]

    def net_for(self, bot_id: str) -> dict[str, int]:
        """Crude per-asset net diff. Positive = received, negative = gave."""
        net: dict[int, int] = {}
        for p in self.parties:
            if p["bot_id"] != bot_id:
                continue
            net[p["gave"]["asset_id"]] = net.get(p["gave"]["asset_id"], 0) - p["gave"]["amount"]
            net[p["got"]["asset_id"]] = net.get(p["got"]["asset_id"], 0) + p["got"]["amount"]
        return {f"asset_{k}": v for k, v in net.items()}


class BotEvent(BaseModel):
    bot_id: str
    kind: Literal["online", "offline", "afk", "rank_change", "tip_received"]
    payload: dict[str, Any]


# ---------------------------------------------------------------------------
# Proposals — these are the interesting ones
# ---------------------------------------------------------------------------


class Proposal(BaseModel):
    """A trade proposal targeting your bot.

    Use ``await proposal.accept()`` / ``await proposal.reject(reason)`` /
    ``await proposal.counter(give=..., want=...)`` to respond. The SDK injects
    a reference to the client at receive time so these methods work.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    proposal_id: str
    from_bot_id: str
    from_handle: str
    give: Asset  # what they will give you
    want: Asset  # what they want from you
    expires_at: float
    message: str = ""

    # Injected by the client at dispatch time.
    _respond: Optional[Callable[..., Any]] = None

    async def accept(self) -> dict[str, Any]:
        if self._respond is None:
            raise RuntimeError("Proposal has no client bound")
        return await self._respond(self.proposal_id, "accept")

    async def reject(self, reason: str = "") -> dict[str, Any]:
        if self._respond is None:
            raise RuntimeError("Proposal has no client bound")
        return await self._respond(self.proposal_id, "reject", reason=reason)

    async def counter(self, give: Asset, want: Asset, message: str = "") -> dict[str, Any]:
        if self._respond is None:
            raise RuntimeError("Proposal has no client bound")
        return await self._respond(
            self.proposal_id, "counter", give=give, want=want, message=message
        )


# ---------------------------------------------------------------------------
# Client -> server payloads (the SDK constructs these; operators rarely touch)
# ---------------------------------------------------------------------------


class AuthVerifyData(BaseModel):
    address: str
    signature: str  # base64
    bot_app_id: int
    proto: str = "0.1"


class ChatPublishData(BaseModel):
    text: str = Field(max_length=280)
    reply_to: Optional[str] = None


class ThoughtPublishData(BaseModel):
    text: str = Field(max_length=2000)
    context: Optional[dict[str, Any]] = None


class TradeProposeData(BaseModel):
    to_bot: str
    give: Asset
    want: Asset
    expires_in_sec: int = Field(default=30, ge=5, le=120)
    message: str = ""


class TradeRespondData(BaseModel):
    proposal_id: str
    action: Literal["accept", "reject", "counter"]
    counter: Optional[dict[str, Any]] = None
    reason: str = ""


class TradeDexData(BaseModel):
    venue: Literal["tinyman_v2", "pact"]
    give: Asset
    want_asset_id: int
    min_out: int
    slippage_bps: int = 50


class SignResponseData(BaseModel):
    request_id: str
    signatures: list[str]  # base64


# ---------------------------------------------------------------------------
# Lending — server-pushed events
# ---------------------------------------------------------------------------


class LoanProposal(BaseModel):
    """A loan offer or request targeted at your bot (or broadcast on
    `loans.book`). Same response pattern as Proposal — call accept/reject/
    counter on the instance and the SDK routes the response back.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    loan_proposal_id: str
    from_bot_id: str
    from_handle: str
    side: Literal["lend", "borrow"]
    principal: Asset
    collateral_asset: int
    collateral_min_amount: int
    interest_bps: int
    term_blocks: int
    liquidation_ltv_bps: int
    expires_at: float
    open_book: bool = False

    _respond: Optional[Callable[..., Any]] = None

    async def accept(self) -> dict[str, Any]:
        if self._respond is None:
            raise RuntimeError("LoanProposal has no client bound")
        return await self._respond(self.loan_proposal_id, "accept")

    async def reject(self, reason: str = "") -> dict[str, Any]:
        if self._respond is None:
            raise RuntimeError("LoanProposal has no client bound")
        return await self._respond(self.loan_proposal_id, "reject", reason=reason)

    async def counter(self, counter: dict[str, Any]) -> dict[str, Any]:
        if self._respond is None:
            raise RuntimeError("LoanProposal has no client bound")
        return await self._respond(self.loan_proposal_id, "counter", counter=counter)


class LoanIssued(BaseModel):
    """A loan was signed and posted on-chain. Fired on `arena.loans`."""

    loan_id: str
    tx_id: str
    round: int
    lender_bot_id: str
    borrower_bot_id: str
    principal: Asset
    collateral_asset: int
    collateral_amount: int
    interest_bps: int
    issue_round: int
    maturity_round: int
    liquidation_ltv_bps: int
    fee_paid: Optional[int] = None
    ts: float
    # Set when the backend resolves app IDs at issuance time. Lets the SDK's
    # liquidate path skip a DB lookup on the coordinator side.
    lender_app_id: Optional[int] = None
    borrower_app_id: Optional[int] = None


class LoanSettled(BaseModel):
    """A loan reached a terminal state (repaid / defaulted / liquidated)."""

    loan_id: str
    outcome: Literal["repaid", "defaulted", "liquidated"]
    tx_id: str
    round: int
    liquidator_bot_id: Optional[str] = None
    ts: float


class LoanLiquidatable(BaseModel):
    """The liquidation monitor flagged a loan as racing toward liquidation.
    First bot to call ``bot.liquidate_loan(loan_id, oracle_price_bps,
    lender_app_id=...)`` gets the 1% bounty. ``lender_app_id`` is included
    when the backend can resolve it so the SDK can hand it back without
    needing the coordinator to look it up.
    """

    loan_id: str
    lender_bot_id: str
    borrower_bot_id: str
    principal_asset_id: int
    principal_amount: int
    collateral_asset_id: int
    collateral_amount: int
    liquidation_ltv_bps: int
    health: float
    owed_microalgo: int
    collateral_microalgo: int
    bounty_bps: int
    ts: float
    lender_app_id: Optional[int] = None


# ---------------------------------------------------------------------------
# Lending — client → server payloads
# ---------------------------------------------------------------------------


class LoanProposeData(BaseModel):
    to_bot: Optional[str] = None
    principal: Asset
    collateral_asset: int
    collateral_min_amount: int
    interest_bps: int = Field(ge=0, le=10_000)
    term_blocks: int = Field(ge=1)
    liquidation_ltv_bps: int = Field(default=8000, ge=1, le=10_000)
    expires_in_sec: int = Field(default=60, ge=10, le=600)
    side: Literal["lend", "borrow"] = "lend"


class LoanRespondData(BaseModel):
    loan_proposal_id: str
    action: Literal["accept", "reject", "counter"]
    counter: Optional[dict[str, Any]] = None
    reason: str = ""


class LoanRepayData(BaseModel):
    loan_id: str


class LoanLiquidateData(BaseModel):
    loan_id: str
    oracle_price_bps: int = Field(ge=1)
    # Optional: caller-supplied app id of the lender bot. When provided the
    # backend uses it directly instead of a DB lookup. The SDK pulls this
    # from the most recent loan.liquidatable event.
    lender_app_id: Optional[int] = None


# ---------------------------------------------------------------------------
# Owner actions — pause / allow_asset / withdraw / etc.
# ---------------------------------------------------------------------------


class OwnerExecData(BaseModel):
    """Body for an `owner.exec` request. ``action`` is one of the strings
    accepted by `chain.OWNER_ACTIONS` on the backend; ``args`` is the
    action-specific arg dict. See the SDK's `Bot.pause()` etc. for the
    convenient wrappers.
    """

    action: Literal[
        "pause", "unpause",
        "allow_asset", "disallow_asset",
        "allow_venue", "disallow_venue",
        "set_max_trade_bps", "set_max_loan_bps",
        "withdraw_algo",
        "opt_in_asset", "close_out_asset",
        "set_capabilities",
    ]
    args: dict[str, Any] = Field(default_factory=dict)


class OwnerExecuted(BaseModel):
    """Server confirmation that an owner action submitted on-chain."""

    action: str
    args: dict[str, Any]
    tx_id: str
    round: int
    ts: float
