"""Algorand key handling for bot operators.

Wraps py-algorand-sdk's account utilities into a single ``Signer`` class that
the SDK uses for authentication challenges and atomic-group signing.
"""

from __future__ import annotations

import base64
from dataclasses import dataclass
from typing import Optional

from algosdk import account, mnemonic
from algosdk.transaction import SignedTransaction, Transaction
from algosdk.util import sign_bytes, verify_bytes


@dataclass(frozen=True)
class Signer:
    """An Algorand keypair. Do not log this object."""

    address: str
    private_key: str  # base64-encoded sk

    @classmethod
    def from_mnemonic(cls, words: str) -> "Signer":
        sk = mnemonic.to_private_key(words.strip())
        addr = account.address_from_private_key(sk)
        return cls(address=addr, private_key=sk)

    @classmethod
    def from_private_key(cls, sk: str) -> "Signer":
        addr = account.address_from_private_key(sk)
        return cls(address=addr, private_key=sk)

    @classmethod
    def generate(cls) -> "Signer":
        sk, addr = account.generate_account()
        return cls(address=addr, private_key=sk)

    def sign_bytes(self, payload: bytes) -> str:
        """Sign arbitrary bytes (used for the auth nonce). Returns base64.

        ``algosdk.util.sign_bytes`` already returns a base64 string AND
        prepends the "MX" domain prefix internally. Do not re-encode and do
        not strip the prefix — the backend's ``verify_bytes`` expects the
        same shape. (An earlier revision wrapped this in another b64encode
        and crashed every WS handshake at runtime.)
        """
        return sign_bytes(payload, self.private_key)

    def sign_txn(self, txn: Transaction) -> SignedTransaction:
        """Sign a raw transaction. Used during atomic-group sign requests."""
        return txn.sign(self.private_key)

    def sign_txn_bytes(self, txn_bytes: bytes) -> str:
        """Sign pre-encoded txn bytes (as delivered in a sign_request).

        The platform sends transactions as base64'd msgpack; we decode,
        sign, and return the signed-txn as base64'd msgpack — `msgpack_encode`
        already returns a base64 string, so no extra encoding step. (An older
        revision of this function double-encoded; the on-the-wire path was
        unused at the time, but it's now load-bearing for owner-signed
        repay_loan.)
        """
        from algosdk.encoding import msgpack_decode, msgpack_encode

        # Decode raw msgpack bytes → Transaction; sign with operator key;
        # re-encode as base64'd msgpack (the form algod.send_transaction
        # accepts after a msgpack_decode round-trip on the backend).
        txn = msgpack_decode(base64.b64encode(txn_bytes).decode())
        signed = txn.sign(self.private_key)
        return msgpack_encode(signed)

    def __repr__(self) -> str:
        return f"Signer(address={self.address[:8]}...{self.address[-6:]})"

    def __str__(self) -> str:
        return self.__repr__()


def verify_signature(address: str, payload: bytes, signature_b64: str) -> bool:
    """Verify an Ed25519 signature against an Algorand address."""
    sig = base64.b64decode(signature_b64)
    return verify_bytes(payload, sig, address)


def derive_mnemonic(signer: Optional[Signer] = None) -> str:
    """Return the 25-word mnemonic for a signer (for backup display only)."""
    s = signer or Signer.generate()
    return mnemonic.from_private_key(s.private_key)
