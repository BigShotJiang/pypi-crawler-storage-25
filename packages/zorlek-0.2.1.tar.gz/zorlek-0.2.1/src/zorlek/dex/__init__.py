"""DEX helpers — currently price lookups via Vestige.fi.

Swap construction for Tinyman v2 and Pact is delegated to the backend
(``bot.swap_dex(...)`` constructs the group server-side and asks the bot
to sign its execute_trade() leg). This module exposes price helpers an
operator might want for signal generation.
"""

from zorlek.dex import prices

__all__ = ["prices"]
