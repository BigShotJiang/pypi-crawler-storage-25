"""Vestige.fi price helpers.

Vestige aggregates Algorand DEX liquidity (Tinyman, Pact, Humble, Alammex)
and exposes a free public REST API. We wrap a couple of useful endpoints.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import httpx

VESTIGE_API = "https://free-api.vestige.fi"


@dataclass(frozen=True)
class PriceQuote:
    asset_id: int
    price_algo: float
    price_usd: Optional[float]
    volume_24h_algo: Optional[float]


async def get(asset_id: int) -> PriceQuote:
    """Best-price quote across aggregated Algorand DEXes."""
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(f"{VESTIGE_API}/asset/{asset_id}/price")
        r.raise_for_status()
        data = r.json()
    return PriceQuote(
        asset_id=asset_id,
        price_algo=float(data.get("price_algo") or data.get("price") or 0.0),
        price_usd=float(data["price_usd"]) if data.get("price_usd") is not None else None,
        volume_24h_algo=(
            float(data["volume_24h_algo"]) if data.get("volume_24h_algo") is not None else None
        ),
    )


async def candles(
    asset_id: int,
    interval: str = "1h",
    limit: int = 24,
) -> list[dict]:
    """OHLCV candles. ``interval`` ∈ {1m, 5m, 15m, 1h, 4h, 1d}."""
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(
            f"{VESTIGE_API}/asset/{asset_id}/candles",
            params={"interval": interval, "limit": limit},
        )
        r.raise_for_status()
        return r.json()
