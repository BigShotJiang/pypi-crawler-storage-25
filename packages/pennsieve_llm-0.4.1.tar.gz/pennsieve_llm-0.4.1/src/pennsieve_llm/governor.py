"""Governor — a thin configuration wrapper that returns a pre-configured
``anthropic.Anthropic`` client pointed at the Pennsieve LLM Governor.

The SDK's design philosophy: don't reinvent the LLM client. Hand back the
official ``anthropic.Anthropic`` instance with the right base URL, auth,
and headers wired up. Users get the full Anthropic SDK API surface
(streaming, tool use, prompt caching, extended thinking, future features)
for free.

Backend auto-selection from environment:

  * ``LLM_GOVERNOR_URL`` set → ``anthropic.Anthropic`` configured for the
    Pennsieve governor (HTTPS + SigV4-signed).
  * ``PENNSIEVE_LLM_MOCK=1`` set → :class:`~pennsieve_llm.MockClient` for
    local tests without a governor. **Must be opt-in**: production code
    must not silently fall through to mock because that masks
    misconfiguration as a "successful" run with garbage output.
  * Otherwise → ``RuntimeError`` at construction time.

For local development against ``api.anthropic.com``, use
``anthropic.Anthropic()`` directly with your API key. The SDK no longer
provides a separate Anthropic backend — that's not its job, the Anthropic
SDK does it natively.
"""
from __future__ import annotations

import os
from typing import Any

from .backends import MockClient, _SigV4Auth
from .errors import GovernorError


class Governor:
    """Configuration helper for talking to the Pennsieve LLM Governor.

    Typical usage::

        from pennsieve_llm import Governor

        gov = Governor()                          # auto-select from env
        resp = gov.client().messages.create(
            model="us.anthropic.claude-sonnet-4-5-20250929-v1:0",
            messages=[{"role": "user", "content": "Hello"}],
            max_tokens=1024,
        )
        print(resp.content[0].text)

    Streaming + tool use work via the underlying Anthropic SDK::

        with gov.client().messages.stream(...) as stream:
            for delta in stream.text_stream:
                print(delta, end="")
    """

    def __init__(
        self,
        *,
        url: str | None = None,
        execution_run_id: str | None = None,
        client: Any | None = None,
        region: str | None = None,
    ):
        """Configure a Governor.

        :param url: Governor URL. Default: ``$LLM_GOVERNOR_URL``.
        :param execution_run_id: Used for cost attribution. Default: ``$EXECUTION_RUN_ID``.
        :param client: Explicit client instance to use. Overrides auto-selection.
            Useful for injecting a :class:`MockClient` in tests.
        :param region: AWS region for SigV4 signing. Default: ``$AWS_REGION``
            or ``us-east-1``.
        """
        self._url = url or os.environ.get("LLM_GOVERNOR_URL") or ""
        self._execution_run_id = execution_run_id or os.environ.get("EXECUTION_RUN_ID", "")
        self._region = region or os.environ.get("AWS_REGION") or "us-east-1"

        if client is not None:
            # Explicit client wins — used by tests injecting MockClient.
            self._client = client
        elif self._url:
            self._client = self._build_anthropic_client()
        elif os.environ.get("PENNSIEVE_LLM_MOCK") == "1":
            # Opt-in mock for local dev / unit tests without a governor URL.
            # Production must NOT silently fall through to mock — that masks
            # real misconfiguration as "successful" runs with garbage output.
            self._client = MockClient()
        else:
            raise RuntimeError(
                "pennsieve-llm: no governor URL configured. Set $LLM_GOVERNOR_URL "
                "(or pass url=...) to point at a deployed governor, or set "
                "PENNSIEVE_LLM_MOCK=1 to opt into the MockClient for local tests."
            )

    def _build_anthropic_client(self):
        try:
            import anthropic
            import httpx
        except ImportError as e:
            raise ImportError(
                "`anthropic` and `httpx` are required. "
                "Install: pip install pennsieve-llm"
            ) from e

        default_headers: dict[str, str] = {}
        if self._execution_run_id:
            # The governor accepts execution_run_id in the request body OR via
            # this header. Header is more convenient because the Anthropic SDK
            # propagates default_headers on every messages.create() call without
            # the caller having to add it manually.
            default_headers["x-execution-run-id"] = self._execution_run_id

        return anthropic.Anthropic(
            base_url=self._url.rstrip("/"),
            # anthropic SDK requires *some* api_key value; the real auth is
            # SigV4 via the http_client below.
            api_key="placeholder-using-sigv4-instead",
            http_client=httpx.Client(
                auth=_SigV4Auth(region=self._region),
                timeout=900.0,
            ),
            default_headers=default_headers,
        )

    def client(self) -> Any:
        """Return the underlying ``anthropic.Anthropic`` (or :class:`MockClient`)
        instance. Use this for all LLM calls::

            gov.client().messages.create(...)
        """
        return self._client

    def available(self) -> bool:
        """Return True if the governor is configured (URL is set). False
        means we're in mock mode."""
        return bool(self._url)

    @property
    def execution_run_id(self) -> str:
        """The execution run ID attached to every request via headers."""
        return self._execution_run_id

    def check_budget(self) -> dict:
        """Query the governor's ``GET /v1/budget`` endpoint.

        Returns a dict with budget period + usage. When not connected to a
        real governor (mock mode), returns a permissive default.
        """
        if not self._url:
            return {
                "budgetPeriod": "none",
                "periodBudgetUsd": 0.0,
                "periodUsedUsd": 0.0,
                "periodRemainingUsd": float("inf"),
            }
        params = {}
        if self._execution_run_id:
            params["execution_run_id"] = self._execution_run_id
        return self._raw_get("/v1/budget", params=params)

    def list_models(self) -> dict:
        """Query the governor's ``GET /v1/models`` endpoint.

        Returns a dict with ``models`` array of `{modelId, status, hint?}`.
        In mock mode, returns an empty list.
        """
        if not self._url:
            return {"models": []}
        return self._raw_get("/v1/models")

    def efs_document(self, path: str) -> dict:
        """Build an ``efs_document`` content block — a Pennsieve-governor-
        specific content type that references an EFS file by path. The
        governor reads the file server-side (subject to execution-scoped
        access) rather than the caller needing to base64-encode it.

        Usage::

            resp = gov.client().messages.create(
                model="...",
                messages=[{
                    "role": "user",
                    "content": [
                        {"type": "text", "text": "Summarize this PDF:"},
                        gov.efs_document("workdir/paper.pdf"),
                    ],
                }],
                max_tokens=1024,
            )
        """
        return {"type": "efs_document", "path": path}

    def _raw_get(self, path: str, params: dict | None = None) -> dict:
        """SigV4-signed GET against a governor non-Anthropic endpoint."""
        import httpx

        with httpx.Client(auth=_SigV4Auth(region=self._region), timeout=60.0) as http:
            resp = http.get(self._url.rstrip("/") + path, params=params or {})
        if resp.status_code >= 400:
            try:
                body = resp.json()
            except Exception:
                body = {}
            raise GovernorError(
                code=body.get("error", "http_error"),
                msg=body.get("message", f"governor returned HTTP {resp.status_code}: {resp.text}"),
                allowed_models=body.get("allowedModels"),
                budget_remaining=body.get("budgetRemaining"),
                retry_after_sec=body.get("retryAfterSeconds"),
            )
        return resp.json()
