# Well-known Bedrock inference profile IDs for convenience.
# Use "us." prefix for US region on-demand inference profiles (HIPAA-friendly
# default — keeps inference in US AWS regions).

MODEL_HAIKU_45 = "us.anthropic.claude-haiku-4-5-20251001-v1:0"
MODEL_SONNET_4 = "us.anthropic.claude-sonnet-4-20250514-v1:0"
MODEL_SONNET_45 = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"
MODEL_SONNET_46 = "us.anthropic.claude-sonnet-4-6"
MODEL_OPUS_47 = "us.anthropic.claude-opus-4-7"