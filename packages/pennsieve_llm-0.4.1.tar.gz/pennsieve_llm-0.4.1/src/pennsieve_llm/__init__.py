"""Python SDK for the Pennsieve LLM Governor.

The SDK is a thin configuration helper over the official ``anthropic``
Python SDK. Typical usage::

    from pennsieve_llm import Governor

    gov = Governor()  # auto-configures from $LLM_GOVERNOR_URL + AWS creds
    resp = gov.client().messages.create(
        model="us.anthropic.claude-sonnet-4-5-20250929-v1:0",
        messages=[{"role": "user", "content": "Hello"}],
        max_tokens=1024,
    )
    print(resp.content[0].text)

The underlying client is a real ``anthropic.Anthropic`` instance, so
streaming, tool use, prompt caching, extended thinking, and all future
Anthropic SDK features work without any wrapping on our side.
"""

from .backends import MockClient
from .errors import GovernorError, is_governor_error
from .governor import Governor
from .models import MODEL_HAIKU_45, MODEL_OPUS_47, MODEL_SONNET_4, MODEL_SONNET_45, MODEL_SONNET_46

__all__ = [
    # Main entry point
    "Governor",
    # Testing
    "MockClient",
    # Errors
    "GovernorError",
    "is_governor_error",
    # Model ID constants (Bedrock inference profile IDs)
    "MODEL_HAIKU_45",
    "MODEL_SONNET_4",
    "MODEL_SONNET_45",
    "MODEL_SONNET_46",
    "MODEL_OPUS_47",
]
