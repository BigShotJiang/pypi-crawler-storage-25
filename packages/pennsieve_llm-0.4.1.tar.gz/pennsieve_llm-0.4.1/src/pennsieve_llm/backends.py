"""Backend infrastructure for the Pennsieve LLM SDK.

This module is intentionally thin: the SDK delegates to the official
``anthropic`` Python SDK for all LLM interactions. We only own:

  * ``_SigV4Auth`` — httpx auth plugin that signs requests against the
    AWS ``lambda`` service (for Function URL invocations).
  * ``MockClient`` — a stand-in for ``anthropic.Anthropic`` used in tests
    when no governor URL or Anthropic API key is configured.

Everything else (request/response types, streaming, tool use, content
blocks, prompt caching) is exposed by returning the underlying
``anthropic.Anthropic`` client via ``Governor.client()``.
"""
from __future__ import annotations

from types import SimpleNamespace
from typing import Any


class _SigV4Auth:
    """httpx auth plugin that SigV4-signs requests against the AWS ``lambda``
    service (the service signing name for Lambda Function URLs).

    Reads credentials from the default boto3 chain (env vars, IAM role, etc.).
    Compatible with httpx.Auth's protocol: a callable that takes a request and
    yields the (signed) request.
    """

    requires_request_body = True

    def __init__(self, region: str = "us-east-1"):
        try:
            import boto3
            from botocore.auth import SigV4Auth
            from botocore.awsrequest import AWSRequest
        except ImportError as e:
            raise ImportError(
                "boto3 + botocore are required. Install pennsieve-llm with "
                "its default extras: `pip install pennsieve-llm`."
            ) from e
        self._SigV4Auth = SigV4Auth
        self._AWSRequest = AWSRequest
        self._creds = boto3.session.Session().get_credentials()
        self._region = region
        if self._creds is None:
            raise RuntimeError(
                "No AWS credentials found. SigV4 signing requires env vars, "
                "an IAM role, or a configured AWS profile."
            )

    def auth_flow(self, request):
        aws_request = self._AWSRequest(
            method=request.method,
            url=str(request.url),
            data=request.content if request.content else b"",
            headers=dict(request.headers),
        )
        # botocore re-derives Host from the URL; remove any pre-existing one
        # so the signature uses the canonical value.
        aws_request.headers.pop("Host", None)
        self._SigV4Auth(self._creds, "lambda", self._region).add_auth(aws_request)
        for k, v in aws_request.headers.items():
            request.headers[k] = v
        yield request


class _MockMessages:
    """Mock implementation of ``anthropic.Anthropic.messages``. Stores every
    call's kwargs in ``.calls`` and returns canned responses.

    Tests can:
        - Inspect ``mock_client.messages.calls`` to assert what was sent.
        - Override the response via ``mock_client.set_response(text=...)``.
    """

    def __init__(self):
        self.calls: list[dict] = []
        self._response_text = "[mock] response"
        self._input_tokens = 10
        self._output_tokens = 5

    def set_response(self, text: str = "[mock] response", input_tokens: int = 10, output_tokens: int = 5):
        self._response_text = text
        self._input_tokens = input_tokens
        self._output_tokens = output_tokens

    def create(self, **kwargs) -> Any:
        self.calls.append(kwargs)
        # Return a response shape that matches anthropic.types.Message enough
        # for typical caller code (resp.content[i].text, resp.usage.input_tokens,
        # resp.model, resp.stop_reason).
        return SimpleNamespace(
            id="msg_mock",
            type="message",
            role="assistant",
            content=[SimpleNamespace(type="text", text=self._response_text)],
            model=kwargs.get("model", "mock"),
            stop_reason="end_turn",
            stop_sequence=None,
            usage=SimpleNamespace(
                input_tokens=self._input_tokens,
                output_tokens=self._output_tokens,
            ),
        )


class MockClient:
    """Drop-in replacement for ``anthropic.Anthropic`` for tests.

    Mimics the parts of the anthropic.Anthropic surface that typical caller
    code uses (``.messages.create(...)``). Implements just enough to make
    unit tests pass without making real network calls.

    Use directly or pass into ``Governor(client=MockClient())`` to override
    the auto-selected backend.
    """

    def __init__(self):
        self.messages = _MockMessages()

    def set_response(self, text: str = "[mock] response", input_tokens: int = 10, output_tokens: int = 5):
        """Set the canned response for subsequent ``messages.create()`` calls."""
        self.messages.set_response(text=text, input_tokens=input_tokens, output_tokens=output_tokens)

    @property
    def calls(self) -> list[dict]:
        """Inspect the kwargs of every ``messages.create()`` call so far."""
        return self.messages.calls
