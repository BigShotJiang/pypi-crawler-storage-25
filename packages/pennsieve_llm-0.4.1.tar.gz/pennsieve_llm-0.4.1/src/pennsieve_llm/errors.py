from __future__ import annotations

from typing import Any


class GovernorError(Exception):
    """Error returned by the LLM Governor.

    Distinct from anthropic.BadRequestError / etc. — this is raised for
    governor-specific failures (budget exceeded, model not in allow-list,
    HIPAA-mode provider rejection, etc.) when calling governor-side endpoints
    like ``Governor.check_budget()`` and ``Governor.list_models()``.

    Errors that come back from Bedrock via the chat path (``messages.create``)
    are surfaced as ``anthropic.APIError`` subclasses — those use the
    Anthropic SDK's native exception hierarchy.
    """

    def __init__(
        self,
        code: str,
        msg: str,
        allowed_models: list[str] | None = None,
        budget_remaining: dict[str, Any] | None = None,
        retry_after_sec: int = 0,
    ):
        super().__init__(f"governor error [{code}]: {msg}")
        self.code = code
        self.msg = msg
        self.allowed_models = allowed_models or []
        self.budget_remaining = budget_remaining
        self.retry_after_sec = retry_after_sec

    def is_budget_exceeded(self) -> bool:
        """Return True if the error is a budget_exceeded error."""
        return self.code == "budget_exceeded"

    def is_model_not_allowed(self) -> bool:
        """Return True if the error is a model_not_allowed error."""
        return self.code == "model_not_allowed"

    def is_provider_not_allowed(self) -> bool:
        """Return True if the error is a provider_not_allowed error."""
        return self.code == "provider_not_allowed"

    def is_model_not_enabled(self) -> bool:
        """Return True if the model needs to be enabled in Bedrock console."""
        return self.code == "model_not_enabled"

    def is_throttled(self) -> bool:
        """Return True if the request was rate-limited."""
        return self.code == "bedrock_throttled"


def is_governor_error(err: BaseException) -> GovernorError | None:
    """Return the GovernorError if *err* is one, else None."""
    return err if isinstance(err, GovernorError) else None