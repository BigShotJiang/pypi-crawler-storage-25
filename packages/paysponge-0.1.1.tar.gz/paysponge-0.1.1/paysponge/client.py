from __future__ import annotations

import json
import os
from typing import Any
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from paysponge.errors import SpongeApiError, SpongeConfigError
from paysponge.models import Agent, JsonDict, McpConfig, Wallet
from paysponge._version import VERSION

DEFAULT_BASE_URL = "https://api.wallet.paysponge.com"
PYTHON_SDK_VERSION = VERSION


class _HttpTransport:
    def request(
        self,
        *,
        method: str,
        url: str,
        headers: dict[str, str],
        body: JsonDict | None = None,
        timeout: float = 30,
    ) -> Any:
        data = None
        if body is not None:
            data = json.dumps(body).encode("utf-8")

        request = Request(url=url, data=data, headers=headers, method=method)

        try:
            with urlopen(request, timeout=timeout) as response:
                raw = response.read()
        except HTTPError as error:
            raw = error.read()
            payload = _decode_body(raw)
            message = _error_message(payload) or error.reason or "Request failed"
            code = payload.get("code") if isinstance(payload, dict) else None
            raise SpongeApiError(
                status_code=error.code,
                message=str(message),
                code=str(code) if code else None,
                data=payload,
            ) from error

        return _decode_body(raw)


def _decode_body(raw: bytes) -> Any:
    if not raw:
        return None
    return json.loads(raw.decode("utf-8"))


def _error_message(payload: Any) -> str | None:
    if not isinstance(payload, dict):
        return None

    for key in ("message", "error"):
        value = payload.get(key)
        if isinstance(value, str):
            return value
        if isinstance(value, dict):
            nested = value.get("message")
            if isinstance(nested, str):
                return nested

    return None


def _clean_query(query: JsonDict | None) -> JsonDict:
    if not query:
        return {}

    cleaned: JsonDict = {}
    for key, value in query.items():
        if value is None:
            continue
        if isinstance(value, bool):
            cleaned[key] = "true" if value else "false"
        elif isinstance(value, (list, tuple)):
            cleaned[key] = ",".join(str(item) for item in value)
        else:
            cleaned[key] = value
    return cleaned


def _pick_api_key(explicit: str | None, env_name: str) -> str:
    api_key = explicit or os.environ.get(env_name) or os.environ.get("SPONGE_API_KEY")
    if not api_key:
        raise SpongeConfigError(f"Missing API key. Pass api_key or set {env_name}.")
    return api_key


class _BaseClient:
    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30,
        transport: Any | None = None,
    ) -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._transport = transport or _HttpTransport()

    def _request(
        self,
        method: str,
        path: str,
        *,
        query: JsonDict | None = None,
        body: JsonDict | None = None,
    ) -> Any:
        url = f"{self.base_url}{path}"
        cleaned_query = _clean_query(query)
        if cleaned_query:
            url = f"{url}?{urlencode(cleaned_query)}"

        headers = {
            "Accept": "application/json",
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Sponge-Version": PYTHON_SDK_VERSION,
        }

        return self._transport.request(
            method=method,
            url=url,
            headers=headers,
            body=body,
            timeout=self.timeout,
        )


class SpongeWallet(_BaseClient):
    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        agent_id: str | None = None,
        timeout: float = 30,
        transport: Any | None = None,
    ) -> None:
        super().__init__(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            transport=transport,
        )
        self.agent_id = agent_id

    @classmethod
    def connect(
        cls,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        agent_id: str | None = None,
        timeout: float = 30,
    ) -> "SpongeWallet":
        return cls(
            api_key=_pick_api_key(api_key, "SPONGE_API_KEY"),
            base_url=base_url or os.environ.get("SPONGE_API_URL", DEFAULT_BASE_URL),
            agent_id=agent_id,
            timeout=timeout,
        )

    def get_agent(self) -> Agent:
        payload = self._request("GET", "/api/agents/me")
        agent = Agent.model_validate(payload)
        self.agent_id = agent.id
        return agent

    def get_balances(
        self,
        *,
        chain: str = "all",
        allowed_chains: list[str] | str | None = None,
        only_usdc: bool | None = None,
        agent_id: str | None = None,
    ) -> Any:
        return self._request(
            "GET",
            "/api/balances",
            query={
                "chain": chain,
                "allowedChains": allowed_chains,
                "onlyUsdc": only_usdc,
                "agentId": agent_id or self.agent_id,
            },
        )

    def get_wallets(
        self,
        *,
        include_balances: bool = False,
        agent_id: str | None = None,
    ) -> list[Wallet]:
        payload = self._request(
            "GET",
            "/api/wallets/",
            query={
                "agentId": agent_id or self.agent_id,
                "includeBalances": include_balances,
            },
        )
        values = payload.get("wallets", payload) if isinstance(payload, dict) else payload
        if not isinstance(values, list):
            return []
        return [Wallet.model_validate(item) for item in values if isinstance(item, dict)]

    def get_addresses(self, *, agent_id: str | None = None) -> dict[str, str]:
        addresses: dict[str, str] = {}
        for wallet in self.get_wallets(agent_id=agent_id):
            chain = wallet.chain_name or wallet.chain
            if chain and wallet.address:
                addresses[chain] = wallet.address
        return addresses

    def transfer(
        self,
        *,
        chain: str,
        to: str,
        amount: str,
        currency: str = "USDC",
        agent_id: str | None = None,
    ) -> Any:
        normalized_chain = chain.lower()
        endpoint = "/api/transfers/evm"
        body_key = "currency"

        if normalized_chain in {"solana", "solana-mainnet", "solana-devnet"}:
            endpoint = "/api/transfers/solana"
        elif normalized_chain in {"tempo", "tempo-testnet"}:
            endpoint = "/api/transfers/tempo"
            body_key = "token"

        body = {
            "chain": chain,
            "to": to,
            "amount": amount,
            body_key: currency,
            "agentId": agent_id or self.agent_id,
        }
        return self._request("POST", endpoint, body=body)

    def paid_fetch(
        self,
        *,
        url: str,
        method: str = "GET",
        headers: dict[str, str] | None = None,
        body: Any = None,
        agent_id: str | None = None,
    ) -> Any:
        return self._request(
            "POST",
            "/api/paid/fetch",
            body={
                "url": url,
                "method": method,
                "headers": headers,
                "body": body,
                "agentId": agent_id or self.agent_id,
            },
        )

    def x402_fetch(
        self,
        *,
        url: str,
        method: str = "GET",
        headers: dict[str, str] | None = None,
        body: Any = None,
        preferred_chain: str | None = None,
        agent_id: str | None = None,
    ) -> Any:
        return self._request(
            "POST",
            "/api/x402/fetch",
            body={
                "url": url,
                "method": method,
                "headers": headers,
                "body": body,
                "preferred_chain": preferred_chain,
                "agentId": agent_id or self.agent_id,
            },
        )

    def mpp_fetch(
        self,
        *,
        url: str,
        method: str = "GET",
        headers: dict[str, str] | None = None,
        body: Any = None,
        agent_id: str | None = None,
    ) -> Any:
        return self._request(
            "POST",
            "/api/mpp/fetch",
            body={
                "url": url,
                "method": method,
                "headers": headers,
                "body": body,
                "agentId": agent_id or self.agent_id,
            },
        )

    def mcp(self) -> McpConfig:
        return McpConfig(
            url=f"{self.base_url}/mcp",
            headers={"Authorization": f"Bearer {self.api_key}"},
        )


class SpongePlatform(_BaseClient):
    @classmethod
    def connect(
        cls,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = 30,
    ) -> "SpongePlatform":
        return cls(
            api_key=_pick_api_key(api_key, "SPONGE_MASTER_KEY"),
            base_url=base_url or os.environ.get("SPONGE_API_URL", DEFAULT_BASE_URL),
            timeout=timeout,
        )

    def create_agent(
        self,
        *,
        name: str,
        description: str | None = None,
        is_test_mode: bool = True,
        **extra: Any,
    ) -> Agent:
        body: JsonDict = {
            "name": name,
            "description": description,
            "isTestMode": is_test_mode,
            **extra,
        }
        return Agent.model_validate(self._request("POST", "/api/agents/", body=body))

    def list_agents(self, *, include_balances: bool = False) -> list[Agent]:
        payload = self._request(
            "GET",
            "/api/agents/",
            query={"includeBalances": include_balances},
        )
        values = payload.get("agents", payload) if isinstance(payload, dict) else payload
        if not isinstance(values, list):
            return []
        return [Agent.model_validate(item) for item in values if isinstance(item, dict)]

    def get_agent(self, agent_id: str) -> Agent:
        return Agent.model_validate(self._request("GET", f"/api/agents/{agent_id}"))

    def connect_agent(
        self,
        *,
        api_key: str,
        agent_id: str | None = None,
    ) -> SpongeWallet:
        return SpongeWallet(
            api_key=api_key,
            base_url=self.base_url,
            agent_id=agent_id,
            timeout=self.timeout,
        )
