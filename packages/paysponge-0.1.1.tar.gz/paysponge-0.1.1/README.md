# paysponge

Python SDK for PaySponge.

The `paysponge` package is a small first-class SDK surface for common wallet
and platform workflows.

## Install

```bash
cd mobwallet/python/paysponge
uv sync --group dev
```

## Quick Start

```python
from paysponge import SpongeWallet

wallet = SpongeWallet.connect(api_key="sponge_test_xxx")

agent = wallet.get_agent()
addresses = wallet.get_addresses()
balances = wallet.get_balances()
```

Platform/master-key usage:

```python
from paysponge import SpongePlatform

platform = SpongePlatform.connect(api_key="sponge_master_xxx")
agent = platform.create_agent(name="Hackathon Agent")
```

## Examples

- `examples/basic.py`
- `examples/transfer.py`
- `examples/basic_sdk.py`

Run them with `uv run` so they use the package environment:

```bash
cd mobwallet/python/paysponge
SPONGE_API_KEY=sponge_test_xxx uv run python examples/basic.py
SPONGE_API_KEY=sponge_test_xxx RECIPIENT_ADDRESS=0x... uv run python examples/transfer.py
```

## Tests

```bash
cd mobwallet/python/paysponge
uv run python -m unittest discover -s tests
```
