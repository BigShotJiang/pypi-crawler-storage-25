from __future__ import annotations

"""
plan_templates.py — 事業計画書テンプレート（Phase 3: hojokin_plan_draft 用）

各セクションは補助金申請書の一般的な構成に基づく。
Claude APIは使用せず、構造化テンプレート＋データを返す。
呼び出し側AI（BPB v7等）がテンプレートを使って計画書を生成する。

注意: テンプレートはあくまで参考例であり、最終的な申請書は
専門家のレビューを受けることを強く推奨します。
"""

from typing import Any


def get_plan_sections() -> list[dict[str, Any]]:
    """事業計画書の標準セクション定義を返す"""
    return [
        {
            "section_number": 1,
            "section_title": "事業概要（事業テーマ・概要説明）",
            "guidance": "事業の全体像を簡潔に説明する。事業テーマ（タイトル）、実施する内容の概要、対象市場・顧客、期待する成果を含める。審査員が最初に読む部分なので、インパクトと具体性を両立させること。",
            "scoring_hint": "事業計画の妥当性・合理性に直結。審査員は最初の印象でスコアの方向性を決めることが多い。",
            "example_text": "【事業テーマ】{project_title}\n\n当社（{company_name}）は、{business_description}を営む企業です。本事業では、{project_description}に取り組みます。\n\n本事業により、{expected_outcomes}の達成を目指します。",
            "max_chars": 800,
        },
        {
            "section_number": 2,
            "section_title": "現状の課題と解決策",
            "guidance": "自社が直面している経営課題を具体的に記述し、その課題を本事業でどのように解決するかを論理的に説明する。課題→原因→解決策→効果の流れで記述すると説得力が増す。数値データ（売上推移、生産性、顧客数等）を含めること。",
            "scoring_hint": "経営計画の妥当性、課題の明確さ。審査基準の「課題や目標の明確さ」に対応。現状分析が甘いと大幅減点される。",
            "example_text": "【現状の課題】\n当社は現在、以下の課題を抱えています。\n\n1. {challenge_1}: （具体的な数値や状況を記載）\n2. {challenge_2}: （具体的な数値や状況を記載）\n\n【解決策】\n上記の課題に対し、本事業では以下の取り組みを実施します。\n\n1. （具体的な解決策を記載）\n2. （具体的な解決策を記載）",
            "max_chars": 1500,
        },
        {
            "section_number": 3,
            "section_title": "事業の新規性・独自性",
            "guidance": "本事業が従来の取り組みと異なる点、競合他社にない独自の強みを明確にする。「新規性」は業界初である必要はなく、自社にとって新しい取り組みであればよい。ただし、既存製品・サービスの単なる改良ではなく、革新的な要素を示すこと。",
            "scoring_hint": "技術面の審査（革新性）、事業化面の審査（市場ニーズ）に直結。「他社との差別化」を明確に示せるかがポイント。",
            "example_text": "【新規性】\n本事業は、以下の点で新規性があります。\n\n1. （自社にとって新しい技術・手法の導入）\n2. （新しい市場・顧客層へのアプローチ）\n\n【独自性（自社の強み）】\n{company_strengths}\n\nこれらの強みを活かし、競合他社にはない独自の価値を提供します。",
            "max_chars": 1200,
        },
        {
            "section_number": 4,
            "section_title": "実施体制",
            "guidance": "本事業を遂行するための社内体制（担当者、役割分担）と、外部連携先（ITベンダー、コンサルタント、認定支援機関等）を記載する。事業を確実に遂行できる体制があることを示す。",
            "scoring_hint": "事業化面の審査（実現可能性）に対応。体制が不明確だと「本当に実施できるのか」と疑われる。",
            "example_text": "【社内体制】\n・事業責任者: （氏名・役職）\n・実務担当: （氏名・役職・担当内容）\n・経理担当: （氏名・役職）\n\n【外部連携先】\n・（連携先名）: （連携内容）\n・認定経営革新等支援機関: （機関名）",
            "max_chars": 800,
        },
        {
            "section_number": 5,
            "section_title": "スケジュール",
            "guidance": "事業実施期間内のマイルストーンを月単位で記載する。準備→導入→運用→効果測定の流れを明確にし、無理のないスケジュールであることを示す。",
            "scoring_hint": "事業計画の妥当性に影響。非現実的なスケジュールは減点対象。事業実施期間を超える計画はNG。",
            "example_text": "【実施スケジュール】\n\n| 時期 | 内容 |\n|------|------|\n| 1〜2ヶ月目 | 準備・発注（仕様確定、見積取得、契約） |\n| 3〜4ヶ月目 | 導入・構築（設備導入、システム開発） |\n| 5〜6ヶ月目 | 試運用・調整 |\n| 7〜8ヶ月目 | 本格運用・効果測定 |\n| 9〜10ヶ月目 | 改善・最適化 |\n| 11〜12ヶ月目 | 成果報告書作成・実績報告 |",
            "max_chars": 600,
        },
        {
            "section_number": 6,
            "section_title": "資金計画（補助対象経費の内訳）",
            "guidance": "投資総額、補助対象経費の内訳、自己負担額を明記する。各経費の必要性と金額の根拠（見積書等）を説明する。補助対象外の経費を含めないよう注意。",
            "scoring_hint": "積算の適切性に直結。経費の必要性と妥当性が不明確だと減点。相見積もりの取得が加点要素になる補助金もある。",
            "example_text": "【資金計画】\n\n| 経費区分 | 内容 | 金額（税抜） |\n|----------|------|-------------|\n| 機械装置費 | （具体的な設備名） | ○○○万円 |\n| システム構築費 | （具体的なシステム名） | ○○○万円 |\n| 外注費 | （具体的な外注内容） | ○○○万円 |\n| 合計 | | ○○○万円 |\n\n投資総額: {investment_amount}円\n補助対象経費: ○○○万円\n補助金額（補助率 ○/○）: ○○○万円\n自己負担額: ○○○万円",
            "max_chars": 1000,
        },
        {
            "section_number": 7,
            "section_title": "期待される成果（定量目標）",
            "guidance": "本事業の実施により達成する定量的な目標を記載する。売上増加率、生産性向上率、コスト削減額、新規顧客数など、数値で示すこと。補助金ごとに必須の数値目標（付加価値額、給与支給総額等）がある場合は必ず含める。",
            "scoring_hint": "事業化面の審査（費用対効果）、政策面の審査（賃上げ、地域経済波及）に直結。数値目標が曖昧だと大幅減点。",
            "example_text": "【定量目標】\n\n| 指標 | 現状 | 目標（事業完了後） | 改善率 |\n|------|------|-------------------|--------|\n| 売上高 | ○○○万円 | ○○○万円 | +○○% |\n| 付加価値額 | ○○○万円 | ○○○万円 | +○○% |\n| 労働生産性 | ○○○万円/人 | ○○○万円/人 | +○○% |\n| 給与支給総額 | ○○○万円 | ○○○万円 | +○○% |",
            "max_chars": 800,
        },
    ]


def get_default_self_check_items() -> list[dict[str, Any]]:
    """審査基準に基づくデフォルトのセルフチェック項目"""
    return [
        {
            "criterion": "課題の具体性",
            "check_question": "自社の経営課題が具体的な数値やデータで示されているか",
            "importance": "high",
        },
        {
            "criterion": "解決策の論理性",
            "check_question": "課題→原因→解決策→効果の論理的なつながりがあるか",
            "importance": "high",
        },
        {
            "criterion": "新規性の明確さ",
            "check_question": "既存事業との違い、革新的な要素が明確に示されているか",
            "importance": "high",
        },
        {
            "criterion": "実現可能性",
            "check_question": "実施体制・スケジュールが現実的で、遂行能力があることが示されているか",
            "importance": "high",
        },
        {
            "criterion": "定量目標の妥当性",
            "check_question": "数値目標が具体的で、達成可能かつ意欲的な水準か",
            "importance": "high",
        },
        {
            "criterion": "経費の必要性",
            "check_question": "各経費が事業に必要であること、金額の根拠が明確か",
            "importance": "medium",
        },
        {
            "criterion": "賃上げ要件",
            "check_question": "賃上げに関する数値目標（給与支給総額、事業場内最低賃金）が記載されているか",
            "importance": "medium",
        },
        {
            "criterion": "地域経済への波及効果",
            "check_question": "本事業が地域経済や雇用にどのような好影響を与えるか記載されているか",
            "importance": "low",
        },
    ]


def get_default_warnings() -> list[str]:
    """計画書ドラフトに付与するデフォルトの警告メッセージ"""
    return [
        "これはAIが生成したテンプレートベースのドラフトです。必ず専門家（認定経営革新等支援機関等）のレビューを受けてください。",
        "記載されている数値や金額はテンプレートの例示です。実際の数値に置き換えてください。",
        "補助金の公募要領は毎回変更される可能性があります。最新の公募要領を必ず確認してください。",
        "交付決定前に発注・契約・支払いを行うと補助対象外となります。",
        "経費の見積書は原則2社以上から取得してください（補助金により異なる）。",
    ]


def build_scoring_alignment(
    scoring_criteria: list[dict[str, Any]] | None,
) -> dict[int, list[str]]:
    """
    審査基準からセクション番号ごとのスコアリングヒントを生成する。
    Returns: {section_number: [関連する審査基準の説明リスト]}
    """
    if not scoring_criteria:
        return {}

    # 審査基準のカテゴリとセクションの対応マッピング
    category_to_sections: dict[str, list[int]] = {
        "経営計画": [1, 2],
        "技術面": [3],
        "事業化面": [3, 4, 7],
        "事業面": [1, 2, 7],
        "政策面": [7],
        "積算": [6],
        "補助事業計画": [1, 2, 3],
        "賃上げ": [7],
        "加点": [7],
    }

    alignment: dict[int, list[str]] = {}

    for criterion in scoring_criteria:
        category = criterion.get("category", "")
        description = criterion.get("description", "")
        weight = criterion.get("weight", "")

        matched_sections: list[int] = []
        for keyword, sections in category_to_sections.items():
            if keyword in category:
                matched_sections.extend(sections)

        # マッチしなかった場合は全セクションに薄く関連
        if not matched_sections:
            matched_sections = [1, 2, 3, 7]

        hint_text = "【{}】{} （重要度: {}）".format(category, description, weight)
        for sec_num in set(matched_sections):
            if sec_num not in alignment:
                alignment[sec_num] = []
            alignment[sec_num].append(hint_text)

    return alignment
