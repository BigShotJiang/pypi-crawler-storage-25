"""
matching.py — 補助金マッチングエンジン

app.js の filterHojokin ロジックをPythonに移植。
ルールベースのスコアリングで、企業情報に基づいて該当補助金を判定する。
"""

from __future__ import annotations

from typing import List, Dict, Any, Optional

from .requirements_data import SUBSIDY_NAME_TO_ID


def lookup_subsidy_id(subsidies, subsidy_id):
    # type: (List[Dict[str, Any]], int) -> Optional[Dict[str, Any]]
    """
    subsidy_id から補助金データを検索する。
    既存データ（hojokin_supabase_import.json）と主要補助金シードデータの両方を探索。

    Args:
        subsidies: load_subsidies() で読み込んだ補助金リスト
        subsidy_id: 補助金ID

    Returns:
        マッチした補助金データ、見つからない場合は None
    """
    # 1. 既存データからID検索
    for item in subsidies:
        if item.get("id") == subsidy_id:
            return item

    # 2. 主要補助金のシードデータID（9001〜9005）はrequirements_dataで管理
    #    requirements/checklist ツール側で直接参照するため、ここでは None を返す
    return None

# 地方区分（app.js の REGIONS を移植）
REGIONS = {
    "hokkaido": ["北海道"],
    "tohoku": ["青森県", "岩手県", "宮城県", "秋田県", "山形県", "福島県"],
    "kanto": ["茨城県", "栃木県", "群馬県", "埼玉県", "千葉県", "東京都", "神奈川県"],
    "chubu": ["新潟県", "富山県", "石川県", "福井県", "山梨県", "長野県", "岐阜県", "静岡県", "愛知県"],
    "kinki": ["三重県", "滋賀県", "京都府", "大阪府", "兵庫県", "奈良県", "和歌山県"],
    "chugoku": ["鳥取県", "島根県", "岡山県", "広島県", "山口県"],
    "shikoku": ["徳島県", "香川県", "愛媛県", "高知県"],
    "kyushu": ["福岡県", "佐賀県", "長崎県", "熊本県", "大分県", "宮崎県", "鹿児島県", "沖縄県"],
}

REGION_NAMES = {
    "hokkaido": "北海道",
    "tohoku": "東北",
    "kanto": "関東",
    "chubu": "中部",
    "kinki": "近畿",
    "chugoku": "中国",
    "shikoku": "四国",
    "kyushu": "九州・沖縄",
}

# 利用目的の同義語マッピング（app.js の PURPOSE_SYNONYMS を移植）
PURPOSE_SYNONYMS = {
    "DX": ["dx", "デジタル", "it", "ict", "情報", "システム", "ai", "iot"],
    "設備投資": ["設備", "機械", "導入", "整備"],
    "研究開発": ["研究", "開発", "r&d", "実用化", "技術"],
    "人材育成": ["人材", "雇用", "採用", "研修", "育成", "女性活躍"],
    "賃上げ": ["賃上げ", "賃金", "給与", "給料", "環境整備"],
    "販路開拓": ["販路", "海外", "輸出", "展示", "マーケティング", "販売"],
    "省エネ": ["省エネ", "環境", "グリーン", "脱炭素", "再エネ", "電気料金", "エネルギー"],
    "観光": ["観光", "宿泊", "旅行", "インバウンド", "コンベンション"],
}


def get_region_for_prefecture(prefecture):
    # type: (str) -> Optional[str]
    """都道府県から地方名を返す"""
    for region_key, prefs in REGIONS.items():
        if prefecture in prefs:
            return region_key
    return None


def calculate_confidence(
    prefecture,      # type: Optional[str]
    industries,      # type: Optional[List[str]]
    employee_count,  # type: Optional[int]
    business_stage,  # type: Optional[str]
    purposes,        # type: Optional[List[str]]
    capital,         # type: Optional[int]
):
    # type: (...) -> float
    """
    提供された情報量に基づいて信頼度スコアを計算する。
    設計書 Section 10 のロジックに準拠。
    """
    score = 0.0

    if prefecture:
        score += 0.2
    if industries and len(industries) > 0:
        score += 0.3
    if employee_count is not None:
        score += 0.2
    if business_stage:
        score += 0.1
    if purposes and len(purposes) > 0:
        score += 0.1
    if capital is not None:
        score += 0.1

    return min(score, 1.0)


def get_missing_fields(
    prefecture,      # type: Optional[str]
    industries,      # type: Optional[List[str]]
    employee_count,  # type: Optional[int]
    business_stage,  # type: Optional[str]
    purposes,        # type: Optional[List[str]]
    capital,         # type: Optional[int]
):
    # type: (...) -> List[Dict[str, str]]
    """不足している情報フィールドのリストを返す"""
    missing = []

    if not industries or len(industries) == 0:
        missing.append({
            "field": "industries",
            "label": "業種（日本標準産業分類）",
            "reason": "業種別の補助金マッチングおよび中小企業の定義判定",
            "priority": "high",
        })

    if employee_count is None:
        missing.append({
            "field": "employee_count",
            "label": "従業員数",
            "reason": "小規模事業者持続化補助金の判定（従業員20名以下が対象）",
            "priority": "high",
        })

    if not business_stage:
        missing.append({
            "field": "business_stage",
            "label": "事業ステージ（創業/成長/安定等）",
            "reason": "創業系補助金の判定",
            "priority": "medium",
        })

    if not purposes or len(purposes) == 0:
        missing.append({
            "field": "purposes",
            "label": "利用目的（DX、設備投資、研究開発等）",
            "reason": "目的別の補助金マッチング精度向上",
            "priority": "medium",
        })

    if capital is None:
        missing.append({
            "field": "capital",
            "label": "資本金（円）",
            "reason": "中小企業基本法に基づく企業規模の判定",
            "priority": "low",
        })

    return missing


def match_subsidies(
    subsidies,       # type: List[Dict[str, Any]]
    prefecture=None,      # type: Optional[str]
    industries=None,      # type: Optional[List[str]]
    employee_count=None,  # type: Optional[int]
    capital=None,         # type: Optional[int]
    business_stage=None,  # type: Optional[str]
    purposes=None,        # type: Optional[List[str]]
    keyword=None,         # type: Optional[str]
    limit=20,             # type: int
):
    # type: (...) -> Dict[str, Any]
    """
    補助金マッチングのメインロジック。
    app.js の filterHojokin を移植・拡張。

    Returns:
        マッチ結果辞書 (matches, total_count, query_summary, confidence, need_more_info等)
    """
    if industries is None:
        industries = []
    if purposes is None:
        purposes = []

    # 信頼度計算
    confidence = calculate_confidence(
        prefecture, industries, employee_count, business_stage, purposes, capital
    )

    def _safe(val):
        # type: (Any) -> str
        """None を空文字に変換"""
        return val if val is not None else ""

    # マッチング実行
    results = []
    for item in subsidies:
        match_reasons = []  # type: List[Dict[str, str]]
        score = 0.0

        # --- 都道府県フィルター ---
        if prefecture:
            item_pref = _safe(item.get("prefecture"))
            if item_pref and item_pref != prefecture:
                # 全国向け補助金（prefecture が空 or "全国"）は通す
                if item_pref not in ("", "全国"):
                    continue
            if item_pref == prefecture:
                match_reasons.append({
                    "type": "pref",
                    "label": "{}の補助金".format(prefecture),
                })
                score += 2.0
            elif item_pref in ("", "全国"):
                match_reasons.append({
                    "type": "pref",
                    "label": "全国対象の補助金",
                })
                score += 1.0

        # --- 業種フィルター ---
        if len(industries) > 0:
            item_industries = item.get("industries") or []
            text = " ".join([
                _safe(item.get("target")),
                _safe(item.get("summary")),
                _safe(item.get("name")),
            ]).lower()

            matched_industries = []
            for ind in industries:
                if ind in item_industries or "その他" in item_industries:
                    matched_industries.append(ind)
                elif ind.lower() in text:
                    matched_industries.append(ind)

            if len(matched_industries) > 0:
                match_reasons.append({
                    "type": "industry",
                    "label": "業種: {}".format("・".join(matched_industries)),
                })
                score += 2.0 * len(matched_industries)
            else:
                # 業種が指定されているのにマッチしない場合はスキップ
                # ただしtargetに「中小企業」「全業種」等がある場合は通す
                general_targets = ["中小企業", "小規模", "全業種", "事業者"]
                target_text = _safe(item.get("target"))
                if any(gt in target_text for gt in general_targets):
                    match_reasons.append({
                        "type": "industry",
                        "label": "業種: 幅広い事業者対象",
                    })
                    score += 0.5
                else:
                    continue

        # --- 事業ステージフィルター ---
        if business_stage:
            text = " ".join([
                _safe(item.get("target")),
                _safe(item.get("summary")),
                _safe(item.get("name")),
            ]).lower()
            if business_stage.lower() in text:
                match_reasons.append({
                    "type": "stage",
                    "label": "ステージ: {}".format(business_stage),
                })
                score += 1.5

        # --- 利用目的フィルター ---
        if len(purposes) > 0:
            text = " ".join([
                _safe(item.get("name")),
                _safe(item.get("summary")),
                _safe(item.get("target")),
            ]).lower()

            matched_purposes = []
            for purpose in purposes:
                synonyms = PURPOSE_SYNONYMS.get(purpose, [purpose.lower()])
                if any(w in text for w in synonyms):
                    matched_purposes.append(purpose)

            if len(matched_purposes) > 0:
                match_reasons.append({
                    "type": "purpose",
                    "label": "目的: {}".format("・".join(matched_purposes)),
                })
                score += 1.5 * len(matched_purposes)

        # --- フリーワード検索 ---
        if keyword:
            text = " ".join([
                _safe(item.get("name")),
                _safe(item.get("summary")),
                _safe(item.get("target")),
                _safe(item.get("prefecture")),
            ]).lower()

            keywords = [kw for kw in keyword.lower().replace("\u3000", " ").replace(",", " ").replace("\u3001", " ").split() if kw]
            if all(kw in text for kw in keywords):
                match_reasons.append({
                    "type": "keyword",
                    "label": "キーワード「{}」にマッチ".format(keyword),
                })
                score += 1.0
            else:
                continue

        # マッチ理由が1つもなければスキップ
        if len(match_reasons) == 0:
            continue

        results.append({
            "subsidy_id": item.get("id", 0),
            "name": _safe(item.get("name")),
            "prefecture": _safe(item.get("prefecture")),
            "max_amount": item.get("max_amount"),
            "deadline": item.get("deadline"),
            "target": _safe(item.get("target")),
            "summary": _safe(item.get("summary")),
            "url": _safe(item.get("url")),
            "match_score": round(score, 2),
            "match_reasons": match_reasons,
        })

    # スコア降順でソート
    results.sort(key=lambda x: x["match_score"], reverse=True)

    # limit 適用
    total_count = len(results)
    results = results[:limit]

    # クエリサマリー生成
    query_parts = []
    if prefecture:
        query_parts.append(prefecture)
    if len(industries) > 0:
        query_parts.append("・".join(industries))
    if business_stage:
        query_parts.append(business_stage)
    if len(purposes) > 0:
        query_parts.append("・".join(purposes))
    if keyword:
        query_parts.append('「{}」'.format(keyword))
    query_summary = " / ".join(query_parts) if query_parts else "条件なし"

    # need_more_info 判定
    missing_fields = get_missing_fields(
        prefecture, industries, employee_count, business_stage, purposes, capital
    )

    response = {
        "matches": results,
        "total_count": total_count,
        "query_summary": query_summary,
        "confidence": round(confidence, 2),
        "version": "Beta版",
    }  # type: Dict[str, Any]

    if confidence < 0.6 and len(missing_fields) > 0:
        response["need_more_info"] = {
            "message": "より正確なマッチングのために、以下の情報をお聞かせください",
            "required_fields": missing_fields,
        }

    return response
