from __future__ import annotations

"""
requirements_data.py — 主要補助金の申請要件・チェックリスト シードデータ（Beta版）

Phase 2: 国の5大補助金・助成金のデータを手動管理。
Phase 3以降: Supabase requirements テーブルに移行予定。

対象補助金:
  1. 小規模事業者持続化補助金
  2. IT導入補助金（デジタル化・AI導入補助金）
  3. ものづくり補助金（ものづくり・商業・サービス生産性向上促進補助金）
  4. 事業再構築補助金
  5. キャリアアップ助成金

注意: このデータは2026年3月時点の公募要領に基づくBeta版です。
最新情報は各補助金の公式サイトで必ず確認してください。
"""

from typing import Any

# --- 補助金IDの定義 ---
# 既存の hojokin_supabase_import.json のIDと衝突しないよう 9001〜 を使用
SUBSIDY_ID_SHOKIBO = 9001       # 小規模事業者持続化補助金
SUBSIDY_ID_IT_DONYU = 9002      # IT導入補助金
SUBSIDY_ID_MONOZUKURI = 9003    # ものづくり補助金
SUBSIDY_ID_JIGYOU_SAIKOUCHIKU = 9004  # 事業再構築補助金
SUBSIDY_ID_CAREER_UP = 9005     # キャリアアップ助成金

# 名前からIDへの逆引き（matching.py から使用）
SUBSIDY_NAME_TO_ID: dict[str, int] = {
    "小規模事業者持続化補助金": SUBSIDY_ID_SHOKIBO,
    "IT導入補助金": SUBSIDY_ID_IT_DONYU,
    "デジタル化・AI導入補助金": SUBSIDY_ID_IT_DONYU,
    "ものづくり補助金": SUBSIDY_ID_MONOZUKURI,
    "ものづくり・商業・サービス生産性向上促進補助金": SUBSIDY_ID_MONOZUKURI,
    "事業再構築補助金": SUBSIDY_ID_JIGYOU_SAIKOUCHIKU,
    "キャリアアップ助成金": SUBSIDY_ID_CAREER_UP,
}


def get_requirements_data() -> dict[int, dict[str, Any]]:
    """全補助金の申請要件データを返す"""
    return {
        # =============================================
        # 1. 小規模事業者持続化補助金
        # =============================================
        SUBSIDY_ID_SHOKIBO: {
            "subsidy_name": "小規模事業者持続化補助金",
            "version": "Beta版",
            "eligibility": {
                "business_types": [
                    "商業・サービス業（宿泊業・娯楽業除く）: 常時使用する従業員の数 5人以下",
                    "サービス業のうち宿泊業・娯楽業: 常時使用する従業員の数 20人以下",
                    "製造業その他: 常時使用する従業員の数 20人以下",
                ],
                "employee_limit": "業種により5人以下〜20人以下",
                "capital_limit": "制限なし（小規模事業者であること）",
                "region_requirements": "全国",
                "other_conditions": [
                    "商工会議所・商工会の管轄地域内で事業を営んでいること",
                    "持続的な経営に向けた経営計画を策定していること",
                    "過去10ヶ月以内に同補助金の補助事業を実施していないこと",
                ],
            },
            "subsidy_details": {
                "subsidy_rate": "2/3",
                "max_amount": 500000,
                "eligible_expenses": [
                    "機械装置等費",
                    "広報費",
                    "ウェブサイト関連費",
                    "展示会等出展費",
                    "旅費",
                    "開発費",
                    "資料購入費",
                    "雑役務費",
                    "借料",
                    "設備処分費",
                    "委託・外注費",
                ],
            },
            "required_documents": [
                {"name": "経営計画書（様式2）", "description": "事業概要、経営方針、今後のプラン等", "required": True, "template_available": True},
                {"name": "補助事業計画書（様式3）", "description": "補助事業の内容、経費明細、資金調達方法", "required": True, "template_available": True},
                {"name": "事業支援計画書（様式4）", "description": "商工会議所・商工会が作成", "required": True, "template_available": True},
                {"name": "補助金交付申請書（様式5）", "description": "交付申請の様式", "required": True, "template_available": True},
                {"name": "直近の確定申告書（写し）", "description": "法人: 決算書、個人: 確定申告書", "required": True, "template_available": False},
                {"name": "貸借対照表・損益計算書", "description": "直近1期分（法人のみ）", "required": True, "template_available": False},
            ],
            "application_method": "jGrants（電子申請）※GビズIDプライムが必要",
            "schedule": {
                "application_start": "公募回により異なる（年複数回）",
                "application_end": "公募回により異なる",
                "review_period": "申請締切後 約2〜3ヶ月",
                "project_period": "交付決定日〜約8ヶ月間",
            },
            "scoring_criteria": [
                {"category": "経営計画の妥当性", "description": "自社の経営状況分析の的確さ、経営方針・目標の適切さ", "weight": "高"},
                {"category": "補助事業計画の有効性", "description": "補助事業計画の具体性、創意工夫、ITの利活用", "weight": "高"},
                {"category": "積算の適切性", "description": "補助対象経費の必要性・妥当性", "weight": "中"},
                {"category": "賃上げ加点", "description": "事業場内最低賃金の引上げ", "weight": "加点"},
                {"category": "パワーアップ型加点", "description": "地域資源型・地域コミュニティ型・賃金引上げ型", "weight": "加点"},
                {"category": "経営力向上計画加点", "description": "経営力向上計画の認定を受けていること", "weight": "加点"},
            ],
            "source_url": "https://s23.jizokukahojokin.info/",
        },

        # =============================================
        # 2. IT導入補助金（デジタル化・AI導入補助金）
        # =============================================
        SUBSIDY_ID_IT_DONYU: {
            "subsidy_name": "IT導入補助金（デジタル化・AI導入補助金）",
            "version": "Beta版",
            "eligibility": {
                "business_types": [
                    "中小企業（中小企業基本法の定義に準ずる）",
                    "小規模事業者",
                ],
                "employee_limit": "業種により異なる（製造業: 300人以下、卸売業: 100人以下、サービス業: 100人以下、小売業: 50人以下）",
                "capital_limit": "業種により異なる（製造業: 3億円以下、卸売業: 1億円以下、サービス業: 5000万円以下、小売業: 5000万円以下）",
                "region_requirements": "全国",
                "other_conditions": [
                    "gBizIDプライムを取得していること",
                    "SECURITY ACTIONの宣言を行っていること",
                    "みらデジ経営チェックを実施していること",
                    "3年間の事業計画を策定し、労働生産性の向上に取り組むこと",
                ],
            },
            "subsidy_details": {
                "subsidy_rate": "1/2〜4/5（枠により異なる）",
                "max_amount": 4500000,
                "eligible_expenses": [
                    "ソフトウェア購入費",
                    "クラウド利用料（最大2年分）",
                    "導入関連費",
                    "ハードウェア購入費（PC・タブレット等、枠による）",
                    "セキュリティ対策推進費",
                ],
            },
            "required_documents": [
                {"name": "交付申請（電子申請）", "description": "IT導入補助金の申請システムから入力", "required": True, "template_available": False},
                {"name": "事業計画書", "description": "3年間の事業計画（労働生産性の伸び率等）", "required": True, "template_available": True},
                {"name": "SECURITY ACTION自己宣言ID", "description": "IPAのSECURITY ACTION制度で宣言", "required": True, "template_available": False},
                {"name": "みらデジ経営チェック結果", "description": "みらデジポータルで経営チェックを実施", "required": True, "template_available": False},
                {"name": "直近の決算書・確定申告書", "description": "法人: 直近2期分の決算書、個人: 直近2年分の確定申告書", "required": True, "template_available": False},
                {"name": "導入するITツールの見積書", "description": "IT導入支援事業者から取得", "required": True, "template_available": False},
            ],
            "application_method": "IT導入補助金 申請マイページ（電子申請）※GビズIDプライムが必要。IT導入支援事業者と共同申請",
            "schedule": {
                "application_start": "2026年3月頃（年度により異なる）",
                "application_end": "複数回の締切あり（年間通じて受付）",
                "review_period": "申請締切後 約1〜2ヶ月",
                "project_period": "交付決定日〜約6ヶ月間",
            },
            "scoring_criteria": [
                {"category": "事業面からの審査", "description": "事業計画の妥当性・合理性、労働生産性の向上", "weight": "高"},
                {"category": "政策面からの審査", "description": "生産性向上、賃上げ、地域経済への波及効果", "weight": "高"},
                {"category": "賃上げ加点", "description": "給与支給総額の年率平均1.5%以上増加", "weight": "加点"},
                {"category": "インボイス対応加点", "description": "インボイス制度への対応", "weight": "加点"},
                {"category": "セキュリティ対策推進加点", "description": "情報セキュリティ対策の実施", "weight": "加点"},
            ],
            "source_url": "https://it-shien.smrj.go.jp/",
        },

        # =============================================
        # 3. ものづくり補助金
        # =============================================
        SUBSIDY_ID_MONOZUKURI: {
            "subsidy_name": "ものづくり・商業・サービス生産性向上促進補助金",
            "version": "Beta版",
            "eligibility": {
                "business_types": [
                    "中小企業者（中小企業基本法に準ずる）",
                    "特定事業者（従業員規模で判定）",
                    "NPO法人（条件あり）",
                ],
                "employee_limit": "業種により異なる（製造業: 300人以下、卸売業: 100人以下、サービス業: 100人以下、小売業: 50人以下）",
                "capital_limit": "業種により異なる（製造業: 3億円以下、卸売業: 1億円以下、サービス業: 5000万円以下、小売業: 5000万円以下）",
                "region_requirements": "全国",
                "other_conditions": [
                    "付加価値額 年率平均3%以上の増加",
                    "給与支給総額 年率平均1.5%以上の増加",
                    "事業場内最低賃金を地域別最低賃金+30円以上に設定",
                    "3〜5年の事業計画を策定すること",
                ],
            },
            "subsidy_details": {
                "subsidy_rate": "1/2〜2/3（枠・従業員規模により異なる）",
                "max_amount": 12500000,
                "eligible_expenses": [
                    "機械装置・システム構築費",
                    "技術導入費",
                    "専門家経費",
                    "運搬費",
                    "クラウドサービス利用費",
                    "原材料費",
                    "外注費",
                    "知的財産権等関連経費",
                ],
            },
            "required_documents": [
                {"name": "事業計画書", "description": "具体的取組内容、将来の展望、数値目標", "required": True, "template_available": True},
                {"name": "賃金引上げ計画の誓約書", "description": "賃上げ要件の誓約", "required": True, "template_available": True},
                {"name": "決算書（直近2期分）", "description": "貸借対照表・損益計算書・製造原価報告書等", "required": True, "template_available": False},
                {"name": "従業員名簿", "description": "常時使用する従業員の一覧", "required": True, "template_available": False},
                {"name": "見積書（2社以上）", "description": "補助対象経費50万円以上は相見積もり必要", "required": True, "template_available": False},
                {"name": "労働者名簿", "description": "雇用条件の確認用", "required": True, "template_available": False},
            ],
            "application_method": "jGrants（電子申請）※GビズIDプライムが必要",
            "schedule": {
                "application_start": "公募回により異なる（年複数回）",
                "application_end": "公募回により異なる",
                "review_period": "申請締切後 約2ヶ月",
                "project_period": "交付決定日〜約10ヶ月間",
            },
            "scoring_criteria": [
                {"category": "技術面", "description": "取組内容の革新性、課題や目標の明確さ", "weight": "高"},
                {"category": "事業化面", "description": "事業化の実現可能性、市場ニーズの有無、費用対効果", "weight": "高"},
                {"category": "政策面", "description": "地域経済への波及効果、ニッチトップ企業への成長性", "weight": "中"},
                {"category": "賃上げ加点", "description": "給与支給総額・事業場内最低賃金の引上げ", "weight": "加点"},
                {"category": "被災事業者加点", "description": "災害で被害を受けた事業者", "weight": "加点"},
                {"category": "デジタル技術活用加点", "description": "DXに資する取組み", "weight": "加点"},
            ],
            "source_url": "https://portal.monodukuri-hojo.jp/",
        },

        # =============================================
        # 4. 事業再構築補助金
        # =============================================
        SUBSIDY_ID_JIGYOU_SAIKOUCHIKU: {
            "subsidy_name": "事業再構築補助金",
            "version": "Beta版",
            "eligibility": {
                "business_types": [
                    "中小企業者（中小企業基本法に準ずる）",
                    "中堅企業（資本金10億円未満）",
                ],
                "employee_limit": "業種により異なる（中小企業の定義に準ずる）",
                "capital_limit": "中小企業: 業種により異なる、中堅企業: 10億円未満",
                "region_requirements": "全国",
                "other_conditions": [
                    "事業再構築指針に沿った新分野展開、事業転換、業種転換、業態転換、事業再編のいずれかを行うこと",
                    "認定経営革新等支援機関と事業計画を策定すること",
                    "補助事業終了後3〜5年で付加価値額の年率平均3.0%以上増加、または従業員一人当たり付加価値額の年率平均3.0%以上増加",
                ],
            },
            "subsidy_details": {
                "subsidy_rate": "1/2〜3/4（枠・企業規模により異なる）",
                "max_amount": 70000000,
                "eligible_expenses": [
                    "建物費（建設・改修）",
                    "機械装置・システム構築費",
                    "技術導入費",
                    "専門家経費",
                    "運搬費",
                    "クラウドサービス利用費",
                    "外注費",
                    "知的財産権等関連経費",
                    "広告宣伝・販売促進費",
                    "研修費",
                ],
            },
            "required_documents": [
                {"name": "事業計画書", "description": "補助事業の具体的取組内容（最大15ページ）", "required": True, "template_available": True},
                {"name": "認定経営革新等支援機関による確認書", "description": "認定支援機関との共同策定を証明", "required": True, "template_available": True},
                {"name": "決算書（直近2期分）", "description": "貸借対照表・損益計算書等", "required": True, "template_available": False},
                {"name": "ミラサポplus「活動レポート」", "description": "電子申請の際に必要", "required": True, "template_available": False},
                {"name": "従業員数を示す書類", "description": "法人事業概況説明書等", "required": True, "template_available": False},
                {"name": "収益事業を行っていることを示す書類", "description": "確定申告書等", "required": True, "template_available": False},
                {"name": "見積書（相見積もり）", "description": "補助対象経費50万円以上は相見積もり", "required": True, "template_available": False},
            ],
            "application_method": "jGrants（電子申請）※GビズIDプライムが必要。認定支援機関との共同申請が必須",
            "schedule": {
                "application_start": "公募回により異なる",
                "application_end": "公募回により異なる",
                "review_period": "申請締切後 約2〜3ヶ月",
                "project_period": "交付決定日〜約12ヶ月間",
            },
            "scoring_criteria": [
                {"category": "補助対象事業の適格性", "description": "事業再構築指針への適合、付加価値額の向上", "weight": "必須"},
                {"category": "事業化点", "description": "事業実施体制、市場ニーズ、収益性、費用対効果", "weight": "高"},
                {"category": "再構築点", "description": "再構築の必要性、取組の具体性・新規性、市場の将来性", "weight": "高"},
                {"category": "政策点", "description": "地域経済への貢献、ニッチトップ、グリーン・デジタル", "weight": "中"},
                {"category": "賃上げ加点", "description": "事業場内最低賃金の引上げ", "weight": "加点"},
                {"category": "経営力向上計画加点", "description": "経営力向上計画の認定", "weight": "加点"},
            ],
            "source_url": "https://jigyou-saikouchiku.go.jp/",
        },

        # =============================================
        # 5. キャリアアップ助成金
        # =============================================
        SUBSIDY_ID_CAREER_UP: {
            "subsidy_name": "キャリアアップ助成金",
            "version": "Beta版",
            "eligibility": {
                "business_types": [
                    "雇用保険適用事業所の事業主",
                    "全業種対象",
                ],
                "employee_limit": "制限なし",
                "capital_limit": "制限なし（ただし大企業と中小企業で助成額が異なる）",
                "region_requirements": "全国",
                "other_conditions": [
                    "キャリアアップ管理者を置いていること",
                    "キャリアアップ計画を作成し、管轄労働局長の受給資格の認定を受けていること",
                    "対象労働者に対する労働条件、勤務状況及び賃金の支払い状況等を明らかにする書類を整備していること",
                ],
            },
            "subsidy_details": {
                "subsidy_rate": "定額支給（コース・企業規模により異なる）",
                "max_amount": 800000,
                "eligible_expenses": [
                    "正社員化コース: 有期→正規 1人当たり80万円（中小企業）",
                    "賃金規定等改定コース: 対象労働者1人当たり6.5万円",
                    "賃金規定等共通化コース: 1事業所当たり60万円",
                    "賞与・退職金制度導入コース: 1事業所当たり40万円",
                    "社会保険適用時処遇改善コース: 1人当たり最大50万円",
                ],
            },
            "required_documents": [
                {"name": "キャリアアップ計画書", "description": "3年以上5年以内の計画期間を設定し、取組内容を記載", "required": True, "template_available": True},
                {"name": "支給申請書", "description": "各コース共通の支給申請書", "required": True, "template_available": True},
                {"name": "対象労働者の雇用契約書", "description": "転換前後の雇用契約書（写し）", "required": True, "template_available": False},
                {"name": "就業規則（写し）", "description": "正社員と非正規社員の区分が明確な就業規則", "required": True, "template_available": False},
                {"name": "賃金台帳", "description": "転換前6ヶ月・転換後6ヶ月分の賃金台帳", "required": True, "template_available": False},
                {"name": "出勤簿・タイムカード", "description": "転換前後の勤務状況を示す書類", "required": True, "template_available": False},
                {"name": "雇用保険被保険者資格取得確認通知書", "description": "対象労働者の雇用保険加入を確認", "required": True, "template_available": False},
            ],
            "application_method": "管轄のハローワークまたは都道府県労働局に郵送・窓口提出。電子申請にも対応（一部コース）",
            "schedule": {
                "application_start": "通年（随時申請可能）",
                "application_end": "正社員化コース: 転換後6ヶ月の賃金支払日の翌日から2ヶ月以内",
                "review_period": "申請後 約2〜6ヶ月",
                "project_period": "キャリアアップ計画期間（3〜5年）",
            },
            "scoring_criteria": [
                {"category": "支給要件の充足", "description": "各コースの支給要件を全て満たしているか（審査制ではなく要件充足型）", "weight": "必須"},
                {"category": "生産性要件", "description": "生産性が向上している場合は助成額が割増される", "weight": "加算"},
            ],
            "source_url": "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/part_haken/jigyounushi/career.html",
        },
    }


def get_checklist_data() -> dict[int, dict[str, Any]]:
    """全補助金の申請チェックリストデータを返す"""
    return {
        # =============================================
        # 1. 小規模事業者持続化補助金
        # =============================================
        SUBSIDY_ID_SHOKIBO: {
            "subsidy_name": "小規模事業者持続化補助金",
            "version": "Beta版",
            "phases": [
                {
                    "phase_name": "事前準備",
                    "estimated_days": 14,
                    "items": [
                        {"task": "GビズIDプライムの取得", "description": "jGrants電子申請に必須。取得に2〜3週間かかる場合あり", "required": True, "completed": False, "tips": "早めに申請を。書類不備で差し戻されると更に時間がかかる"},
                        {"task": "商工会議所・商工会への相談", "description": "事業支援計画書（様式4）の発行依頼。経営計画のアドバイスも受けられる", "required": True, "completed": False, "tips": "締切間際は混雑するため、1ヶ月前には相談を開始"},
                        {"task": "対象経費の見積もり取得", "description": "補助事業で使用する経費の見積書を事前に取得", "required": True, "completed": False, "tips": "見積書の日付は申請日より前であること"},
                    ],
                },
                {
                    "phase_name": "書類作成",
                    "estimated_days": 21,
                    "items": [
                        {"task": "経営計画書（様式2）の作成", "description": "自社の強み、市場環境、経営方針を記載", "required": True, "completed": False, "tips": "具体的な数字を入れると説得力が増す。「売上○%増」等"},
                        {"task": "補助事業計画書（様式3）の作成", "description": "具体的な取組内容、スケジュール、経費明細", "required": True, "completed": False, "tips": "審査員は補助金の専門家。わかりやすく、具体的に書く"},
                        {"task": "決算書・確定申告書の準備", "description": "直近の財務書類を準備", "required": True, "completed": False, "tips": "法人は決算書、個人事業主は確定申告書（第一表＋収支内訳書）"},
                        {"task": "商工会議所による事業支援計画書（様式4）の受領", "description": "商工会議所が作成するため、早めに依頼", "required": True, "completed": False, "tips": "商工会議所の担当者との打ち合わせが必要"},
                    ],
                },
                {
                    "phase_name": "申請",
                    "estimated_days": 3,
                    "items": [
                        {"task": "jGrantsでの電子申請", "description": "GビズIDでログインし、各書類をアップロード", "required": True, "completed": False, "tips": "PDFは10MB以下に。締切日当日はアクセス集中で重くなることがある"},
                        {"task": "申請内容の最終確認", "description": "記入漏れ、添付書類の不足がないか確認", "required": True, "completed": False, "tips": "第三者にレビューしてもらうと安心"},
                    ],
                },
                {
                    "phase_name": "採択後",
                    "estimated_days": 240,
                    "items": [
                        {"task": "交付決定通知の確認", "description": "交付決定の内容を確認。経費の変更がある場合は変更申請", "required": True, "completed": False, "tips": "交付決定前の発注・契約・支払いは補助対象外"},
                        {"task": "補助事業の実施", "description": "計画に沿って事業を実施。証拠書類を必ず保管", "required": True, "completed": False, "tips": "発注書→納品書→請求書→振込明細の一連の書類を保管"},
                        {"task": "実績報告書の提出", "description": "事業完了後30日以内に実績報告書を提出", "required": True, "completed": False, "tips": "写真付きの報告が効果的。経費は銀行振込が原則"},
                        {"task": "補助金の請求・受領", "description": "確定検査後に補助金を請求", "required": True, "completed": False, "tips": "精算払い（後払い）。事業完了後に支払われる"},
                    ],
                },
            ],
            "critical_warnings": [
                "【最重要】交付決定前の発注・契約・支払いは一切補助対象になりません",
                "補助事業期間外の経費は対象外です",
                "経費の支払いは原則として銀行振込（現金払い・クレジットカード払いは原則不可）",
                "採択後5年間は事業効果の報告義務があります",
                "補助事業で取得した財産（50万円以上）は、処分制限期間中の処分に承認が必要",
            ],
            "recommended_timeline": "申請締切の2ヶ月前から準備開始を推奨。GビズIDの取得に2〜3週間かかるため、初回申請の場合は3ヶ月前が理想",
        },

        # =============================================
        # 2. IT導入補助金
        # =============================================
        SUBSIDY_ID_IT_DONYU: {
            "subsidy_name": "IT導入補助金（デジタル化・AI導入補助金）",
            "version": "Beta版",
            "phases": [
                {
                    "phase_name": "事前準備",
                    "estimated_days": 21,
                    "items": [
                        {"task": "GビズIDプライムの取得", "description": "電子申請に必須", "required": True, "completed": False, "tips": "取得に2〜3週間かかる。早めに申請"},
                        {"task": "SECURITY ACTION宣言", "description": "IPAの「SECURITY ACTION」制度で★一つ以上の宣言", "required": True, "completed": False, "tips": "宣言自体は無料。IPA公式サイトから即日可能"},
                        {"task": "みらデジ経営チェックの実施", "description": "みらデジポータルで経営チェックを実施", "required": True, "completed": False, "tips": "所要時間約15分。結果は申請時に自動連携"},
                        {"task": "IT導入支援事業者の選定", "description": "導入したいITツールを扱う支援事業者を選ぶ", "required": True, "completed": False, "tips": "IT導入補助金公式サイトのITツール検索から探せる"},
                    ],
                },
                {
                    "phase_name": "書類作成",
                    "estimated_days": 14,
                    "items": [
                        {"task": "事業計画の策定", "description": "3年間の事業計画（労働生産性の伸び率を含む）", "required": True, "completed": False, "tips": "労働生産性 = 粗利益 ÷ 従業員数。年率3%以上の向上が求められる"},
                        {"task": "ITツールの選定・見積もり", "description": "IT導入支援事業者と共に導入ツールを選定", "required": True, "completed": False, "tips": "補助金登録済みのITツールのみが対象"},
                        {"task": "決算書・確定申告書の準備", "description": "直近2期分の財務書類", "required": True, "completed": False, "tips": "法人は法人税確定申告書別表一＋決算書。個人は所得税確定申告書"},
                    ],
                },
                {
                    "phase_name": "申請",
                    "estimated_days": 3,
                    "items": [
                        {"task": "IT導入支援事業者との共同申請", "description": "申請マイページからIT導入支援事業者と連携して申請", "required": True, "completed": False, "tips": "支援事業者側の入力完了後に申請者が最終確認・提出"},
                        {"task": "申請内容の最終確認", "description": "入力内容と添付書類の確認", "required": True, "completed": False, "tips": "特に事業計画の数値に矛盾がないか確認"},
                    ],
                },
                {
                    "phase_name": "採択後",
                    "estimated_days": 180,
                    "items": [
                        {"task": "交付決定の確認", "description": "交付決定通知を受領", "required": True, "completed": False, "tips": "交付決定前のITツール発注・契約は補助対象外"},
                        {"task": "ITツールの契約・導入", "description": "交付決定後にITツールを契約・導入", "required": True, "completed": False, "tips": "IT導入支援事業者を通じて契約すること"},
                        {"task": "事業実績報告", "description": "ITツール導入後に事業実績報告を提出", "required": True, "completed": False, "tips": "導入したITツールのスクリーンショット等が必要"},
                        {"task": "事業実施効果報告", "description": "補助事業完了後、3年間の効果報告", "required": True, "completed": False, "tips": "毎年の効果報告を怠ると補助金返還の可能性あり"},
                    ],
                },
            ],
            "critical_warnings": [
                "【最重要】交付決定前のITツール発注・契約・支払いは補助対象外",
                "IT導入補助金に登録されたITツール・IT導入支援事業者のみが対象",
                "補助事業完了後、3年間の事業実施効果報告が義務",
                "クラウドサービスは最大2年分が補助対象",
                "他の補助金との二重受給は不可",
            ],
            "recommended_timeline": "申請締切の1.5ヶ月前から準備開始。GビズID未取得の場合は2.5ヶ月前から",
        },

        # =============================================
        # 3. ものづくり補助金
        # =============================================
        SUBSIDY_ID_MONOZUKURI: {
            "subsidy_name": "ものづくり・商業・サービス生産性向上促進補助金",
            "version": "Beta版",
            "phases": [
                {
                    "phase_name": "事前準備",
                    "estimated_days": 21,
                    "items": [
                        {"task": "GビズIDプライムの取得", "description": "jGrants電子申請に必須", "required": True, "completed": False, "tips": "取得に2〜3週間。代表者の印鑑証明書が必要"},
                        {"task": "加点項目の確認・準備", "description": "経営革新計画、事業継続力強化計画等の認定取得を検討", "required": False, "completed": False, "tips": "加点項目の準備には数ヶ月かかるものもある。早めに着手"},
                        {"task": "補助対象経費の見積書取得", "description": "50万円以上の経費は2社以上の相見積もりが必要", "required": True, "completed": False, "tips": "見積書の宛名は申請者名と一致させること"},
                    ],
                },
                {
                    "phase_name": "書類作成",
                    "estimated_days": 30,
                    "items": [
                        {"task": "事業計画書の作成", "description": "具体的取組内容、革新性、将来の展望（10ページ以内推奨）", "required": True, "completed": False, "tips": "図表やデータを活用して説得力を高める。審査員は多数の計画書を読むため簡潔に"},
                        {"task": "数値目標の設定", "description": "付加価値額年率3%以上、給与年率1.5%以上の計画", "required": True, "completed": False, "tips": "現実的かつ野心的な数値設定を。根拠を明示すること"},
                        {"task": "賃金引上げ計画の誓約書作成", "description": "事業場内最低賃金を地域別最低賃金+30円以上に設定", "required": True, "completed": False, "tips": "未達の場合は補助金返還の可能性あり。慎重に設定を"},
                        {"task": "決算書の準備", "description": "直近2期分の貸借対照表・損益計算書等", "required": True, "completed": False, "tips": "設立間もない企業は1期分でも可（要確認）"},
                    ],
                },
                {
                    "phase_name": "申請",
                    "estimated_days": 3,
                    "items": [
                        {"task": "jGrantsでの電子申請", "description": "申請書類一式をアップロード", "required": True, "completed": False, "tips": "アップロードファイルはPDF形式。ファイルサイズに注意"},
                        {"task": "申請内容の最終チェック", "description": "数値の整合性、誤字脱字、添付漏れの確認", "required": True, "completed": False, "tips": "事業計画書の数字と申請フォームの数字が一致しているか"},
                    ],
                },
                {
                    "phase_name": "採択後",
                    "estimated_days": 300,
                    "items": [
                        {"task": "交付申請", "description": "採択通知後に交付申請を行う", "required": True, "completed": False, "tips": "採択 ≠ 交付決定。交付決定前の発注は不可"},
                        {"task": "補助事業の実施", "description": "事業計画に沿って設備導入等を実施", "required": True, "completed": False, "tips": "計画変更がある場合は事前に変更申請が必要"},
                        {"task": "中間監査対応（該当する場合）", "description": "事務局による中間検査への対応", "required": False, "completed": False, "tips": "書類を日常的に整理しておくこと"},
                        {"task": "実績報告書の提出", "description": "事業完了後の実績報告", "required": True, "completed": False, "tips": "経費の証拠書類（発注→納品→検収→支払い）を漏れなく提出"},
                        {"task": "事業化状況報告（5年間）", "description": "補助事業完了後5年間の事業化状況を毎年報告", "required": True, "completed": False, "tips": "付加価値額・給与の目標未達は補助金返還の可能性あり"},
                    ],
                },
            ],
            "critical_warnings": [
                "【最重要】交付決定前の発注・契約・支払いは一切補助対象になりません",
                "賃上げ目標未達の場合、補助金の一部返還が求められる可能性があります",
                "事業化状況・知的財産権等報告を5年間行う義務があります",
                "補助対象経費50万円以上は相見積もり（2社以上）が必須",
                "補助事業で取得した財産の処分には事前承認が必要",
            ],
            "recommended_timeline": "申請締切の2〜3ヶ月前から準備開始。事業計画書の作成に最も時間がかかるため、余裕をもって着手",
        },

        # =============================================
        # 4. 事業再構築補助金
        # =============================================
        SUBSIDY_ID_JIGYOU_SAIKOUCHIKU: {
            "subsidy_name": "事業再構築補助金",
            "version": "Beta版",
            "phases": [
                {
                    "phase_name": "事前準備",
                    "estimated_days": 30,
                    "items": [
                        {"task": "GビズIDプライムの取得", "description": "jGrants電子申請に必須", "required": True, "completed": False, "tips": "取得に2〜3週間"},
                        {"task": "認定経営革新等支援機関の選定・相談", "description": "事業計画の共同策定が必須。金融機関、税理士、中小企業診断士等", "required": True, "completed": False, "tips": "補助金額3,000万円超は金融機関の関与も必要"},
                        {"task": "事業再構築指針の確認", "description": "新分野展開・事業転換・業種転換・業態転換・事業再編のいずれに該当するか確認", "required": True, "completed": False, "tips": "指針に該当しない事業計画は不採択になる。事前に確認必須"},
                        {"task": "ミラサポplus活動レポートの作成", "description": "ミラサポplusで活動レポートを作成", "required": True, "completed": False, "tips": "事前に作成しておくこと。申請時に必要"},
                    ],
                },
                {
                    "phase_name": "書類作成",
                    "estimated_days": 30,
                    "items": [
                        {"task": "事業計画書の作成（最大15ページ）", "description": "補助事業の具体的取組内容、将来の展望、数値計画", "required": True, "completed": False, "tips": "事業再構築の必要性を明確に。「なぜ今、この事業転換が必要か」を説得力をもって記載"},
                        {"task": "認定支援機関との事業計画のすり合わせ", "description": "認定支援機関と共同で事業計画を策定", "required": True, "completed": False, "tips": "認定支援機関の確認書が申請に必要"},
                        {"task": "収支計画の策定", "description": "付加価値額年率3%以上の増加を示す計画", "required": True, "completed": False, "tips": "根拠のある数値を。市場調査データ等を活用"},
                        {"task": "決算書・確定申告書の準備", "description": "直近2期分", "required": True, "completed": False, "tips": "税理士に確認し最新の正確な書類を準備"},
                        {"task": "見積書の取得", "description": "50万円以上は相見積もりが必要", "required": True, "completed": False, "tips": "建物費がある場合は複数業者からの見積もりを"},
                    ],
                },
                {
                    "phase_name": "申請",
                    "estimated_days": 5,
                    "items": [
                        {"task": "jGrantsでの電子申請", "description": "全書類をアップロードして申請", "required": True, "completed": False, "tips": "締切日のアクセス集中に注意。前日までに完了推奨"},
                        {"task": "認定支援機関の確認書の添付", "description": "認定支援機関が発行する確認書をPDFで添付", "required": True, "completed": False, "tips": "確認書の発行に時間がかかる場合があるため早めに依頼"},
                    ],
                },
                {
                    "phase_name": "採択後",
                    "estimated_days": 365,
                    "items": [
                        {"task": "交付申請", "description": "採択後に交付申請書を提出", "required": True, "completed": False, "tips": "採択と交付決定は別。交付決定前の発注は不可"},
                        {"task": "補助事業の実施", "description": "事業計画に沿って事業を実施", "required": True, "completed": False, "tips": "計画変更は事前承認が必要。大幅な変更は認められない場合あり"},
                        {"task": "実績報告書の提出", "description": "補助事業期間終了後の報告", "required": True, "completed": False, "tips": "全経費の証拠書類を漏れなく準備"},
                        {"task": "事業化状況報告（5年間）", "description": "毎年の事業化状況を報告", "required": True, "completed": False, "tips": "付加価値額の目標未達は返還リスクあり"},
                    ],
                },
            ],
            "critical_warnings": [
                "【最重要】交付決定前の発注・契約・支払いは一切補助対象になりません",
                "事業再構築指針に該当しない事業は不採択になります",
                "認定支援機関との共同申請が必須です",
                "補助金額3,000万円を超える場合は金融機関の関与が必要です",
                "建物費は補助対象ですが、土地の取得費は対象外です",
                "補助事業完了後5年間の事業化状況報告が義務です",
            ],
            "recommended_timeline": "申請締切の3ヶ月前から準備開始。認定支援機関との共同策定に時間がかかるため、余裕をもって着手",
        },

        # =============================================
        # 5. キャリアアップ助成金
        # =============================================
        SUBSIDY_ID_CAREER_UP: {
            "subsidy_name": "キャリアアップ助成金",
            "version": "Beta版",
            "phases": [
                {
                    "phase_name": "事前準備",
                    "estimated_days": 14,
                    "items": [
                        {"task": "キャリアアップ管理者の選任", "description": "事業所ごとにキャリアアップ管理者を配置", "required": True, "completed": False, "tips": "管理者は事業主または人事担当者が一般的"},
                        {"task": "キャリアアップ計画書の作成・提出", "description": "3〜5年の計画期間で、対象労働者・取組内容を記載し、管轄労働局に提出", "required": True, "completed": False, "tips": "計画書の提出は取組実施の前日までに行うこと（事後提出は不可）"},
                        {"task": "就業規則の整備・届出", "description": "正社員と非正規社員の区分を明確にした就業規則", "required": True, "completed": False, "tips": "就業規則に「正社員転換制度」を明記すること。労基署への届出も忘れずに"},
                    ],
                },
                {
                    "phase_name": "取組の実施",
                    "estimated_days": 180,
                    "items": [
                        {"task": "対象労働者の正社員転換等の実施", "description": "就業規則の転換規定に基づき、正社員への転換を実施", "required": True, "completed": False, "tips": "転換前に6ヶ月以上雇用されていることが必要"},
                        {"task": "転換後の賃金を6ヶ月以上支払う", "description": "転換後6ヶ月分の賃金を支払った後に申請可能", "required": True, "completed": False, "tips": "転換後の賃金が転換前より3%以上増加していること"},
                        {"task": "賃金台帳・出勤簿等の整備", "description": "転換前後の勤務状況・賃金支払い状況を記録", "required": True, "completed": False, "tips": "書類不備は不支給の最大の原因。日常的に整理しておく"},
                    ],
                },
                {
                    "phase_name": "支給申請",
                    "estimated_days": 7,
                    "items": [
                        {"task": "支給申請書の作成", "description": "各コースの支給申請書と添付書類を準備", "required": True, "completed": False, "tips": "申請期限は転換後6ヶ月の賃金支払日の翌日から2ヶ月以内"},
                        {"task": "添付書類の準備", "description": "雇用契約書、就業規則、賃金台帳、出勤簿等", "required": True, "completed": False, "tips": "書類はコピーで可。原本は手元に保管"},
                        {"task": "管轄ハローワーク・労働局への提出", "description": "郵送または窓口で提出", "required": True, "completed": False, "tips": "提出期限を過ぎると受理されない。余裕をもって提出"},
                    ],
                },
                {
                    "phase_name": "支給決定後",
                    "estimated_days": 30,
                    "items": [
                        {"task": "支給決定通知の確認", "description": "支給決定通知書を受領", "required": True, "completed": False, "tips": "審査に2〜6ヶ月かかることがある"},
                        {"task": "助成金の受領", "description": "指定口座に助成金が振り込まれる", "required": True, "completed": False, "tips": "支給決定から振込まで約1ヶ月"},
                        {"task": "書類の保管（5年間）", "description": "申請書類と関連書類を5年間保管", "required": True, "completed": False, "tips": "労働局の調査が入る場合がある。必ず保管を"},
                    ],
                },
            ],
            "critical_warnings": [
                "【最重要】キャリアアップ計画書は取組実施の前日までに管轄労働局に提出が必要（事後提出は不可）",
                "支給申請期限（転換後6ヶ月の賃金支払日翌日から2ヶ月以内）を過ぎると申請不可",
                "転換後の賃金が転換前より3%以上増加していることが必要",
                "就業規則に正社員転換制度が明記されていない場合は不支給",
                "同一の対象労働者について他の助成金と併給できない場合がある",
                "不正受給が発覚した場合、助成金の返還に加えペナルティが科される",
            ],
            "recommended_timeline": "正社員転換の1ヶ月前にはキャリアアップ計画書を提出。転換後6ヶ月の賃金支払い後に申請するため、全体で約8ヶ月の期間が必要",
        },
    }
