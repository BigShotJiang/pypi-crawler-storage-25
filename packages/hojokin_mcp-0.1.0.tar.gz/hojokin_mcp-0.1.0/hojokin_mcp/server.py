"""
Hojokin MCP Server — Supabase hojokin.subsidies 統合版

Phase 1: hojokin_match — 企業情報から補助金マッチング
Phase 2: hojokin_requirements — 補助金申請要件の取得
         hojokin_checklist — 申請準備チェックリストの生成
Phase 3: hojokin_plan_draft — 事業計画書テンプレート生成（Claude API不使用）

データソース:
  - Primary: Supabase hojokin.subsidies テーブル
  - Fallback: ローカルJSON (data/hojokin_supabase_import.json)

起動方法:
    hojokin-mcp
    # or
    python3 -m hojokin_mcp

Claude Code からの利用:
    .mcp.json に以下を追加:
    {
      "mcpServers": {
        "hojokin": {
          "command": "hojokin-mcp"
        }
      }
    }
"""

from __future__ import annotations

import json
import os
import sys
import urllib.request
import urllib.error
from datetime import datetime, timezone
from typing import Optional, List, Dict, Any, Tuple

try:
    from dotenv import load_dotenv
except ImportError:
    def load_dotenv(*args, **kwargs):
        pass

from mcp.server.fastmcp import FastMCP

from .data_loader import load_subsidies
from .matching import match_subsidies
from .plan_templates import (
    get_plan_sections,
    get_default_self_check_items,
    get_default_warnings,
    build_scoring_alignment,
)
from .requirements_data import (
    get_requirements_data,
    get_checklist_data,
    SUBSIDY_NAME_TO_ID,
)

# .env 読み込み
load_dotenv(os.path.join(os.path.dirname(__file__), ".env"))
# プロジェクトルートの .env も読み込む
load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))

# MCP サーバー初期化
mcp = FastMCP(
    "hojokin",
    instructions="補助金ガイド（hojoguide.jp）— 補助金マッチング・申請支援MCPサービス（Supabase subsidies統合版）",
)


# ===========================================
# Supabase クライアント (urllib ベース, hojokin.subsidies)
# ===========================================

class SupabaseClient:
    """軽量な Supabase REST API クライアント — hojokin.subsidies テーブル用"""

    def __init__(self):
        # type: () -> None
        self.url = os.environ.get("SUPABASE_URL", "")
        self.anon_key = os.environ.get("SUPABASE_ANON_KEY", "")
        self.service_key = os.environ.get("SUPABASE_SERVICE_ROLE_KEY", "")
        self.schema = os.environ.get("SUPABASE_SCHEMA", "hojokin")
        self._available = None  # type: Optional[bool]

    @property
    def is_configured(self):
        # type: () -> bool
        return bool(self.url and (self.anon_key or self.service_key))

    def _api_key(self, write=False):
        # type: (bool) -> str
        if write and self.service_key:
            return self.service_key
        return self.anon_key or self.service_key

    def _request(
        self,
        endpoint,       # type: str
        method="GET",   # type: str
        data=None,      # type: Any
        params=None,    # type: Optional[Dict[str, str]]
        write=False,    # type: bool
        extra_headers=None,  # type: Optional[Dict[str, str]]
    ):
        # type: (...) -> Any
        """Supabase REST API にリクエストを送る"""
        api_key = self._api_key(write=write)
        base = "{}/rest/v1/{}".format(self.url.rstrip("/"), endpoint)

        if params:
            qs = "&".join(
                "{}={}".format(k, urllib.request.quote(str(v), safe=".:,*()"))
                for k, v in params.items()
            )
            base = "{}?{}".format(base, qs)

        headers = {
            "apikey": api_key,
            "Authorization": "Bearer {}".format(api_key),
            "Accept-Profile": self.schema,
            "Content-Profile": self.schema,
        }
        if extra_headers:
            headers.update(extra_headers)

        body = None
        if data is not None:
            body = json.dumps(data, ensure_ascii=False).encode("utf-8")
            headers["Content-Type"] = "application/json"

        req = urllib.request.Request(base, data=body, headers=headers, method=method)
        with urllib.request.urlopen(req, timeout=10) as resp:
            resp_body = resp.read().decode("utf-8")
            if resp_body:
                return json.loads(resp_body)
            return None

    def check_available(self):
        # type: () -> bool
        """Supabase 接続テスト — subsidies テーブルにクエリ"""
        if not self.is_configured:
            self._available = False
            return False
        if self._available is not None:
            return self._available
        try:
            self._request("subsidies", params={"select": "id", "limit": "1"})
            self._available = True
        except Exception:
            self._available = False
        return self._available

    def query_subsidies(
        self,
        select="*",     # type: str
        filters=None,   # type: Optional[Dict[str, str]]
        order=None,     # type: Optional[str]
        limit=None,     # type: Optional[int]
    ):
        # type: (...) -> List[Dict[str, Any]]
        """hojokin.subsidies をクエリ"""
        params = {"select": select}  # type: Dict[str, str]
        if filters:
            params.update(filters)
        if order:
            params["order"] = order
        if limit is not None:
            params["limit"] = str(limit)

        result = self._request("subsidies", params=params)
        return result if isinstance(result, list) else []


# グローバルクライアント
_supabase = SupabaseClient()


# ===========================================
# Supabase データ変換ヘルパー
# ===========================================

def _supabase_subsidies_to_local_format(rows):
    # type: (List[Dict[str, Any]]) -> List[Dict[str, Any]]
    """Supabase subsidies レコードをローカルJSON形式に変換（matchingエンジン互換）"""
    result = []
    for row in rows:
        item = {
            "id": row.get("id", 0),
            "prefecture": row.get("prefecture", ""),
            "prefecture_code": row.get("prefecture_code", ""),
            "name": row.get("name", ""),
            "target": row.get("target", ""),
            "max_amount": row.get("max_amount"),
            "deadline": row.get("deadline"),
            "url": row.get("url", ""),
            "summary": row.get("summary", ""),
            "structured": row.get("structured", False),
            "source_url": row.get("source_url", ""),
            "category": row.get("category"),
            "subcategory": row.get("subcategory"),
            "status": row.get("status"),
            "fiscal_year": row.get("fiscal_year"),
        }
        result.append(item)
    return result


def _extract_requirements_from_eligibility(row):
    # type: (Dict[str, Any]) -> Optional[Dict[str, Any]]
    """subsidies.eligibility JSONB から requirements データを抽出"""
    elig_jsonb = row.get("eligibility")
    if not elig_jsonb or not isinstance(elig_jsonb, dict):
        return None

    data = {
        "subsidy_name": row.get("name", ""),
        "version": "Supabase subsidies統合版",
    }  # type: Dict[str, Any]

    if elig_jsonb.get("eligibility"):
        data["eligibility"] = elig_jsonb["eligibility"]
    if elig_jsonb.get("subsidy_details"):
        data["subsidy_details"] = elig_jsonb["subsidy_details"]
    if elig_jsonb.get("required_documents"):
        data["required_documents"] = elig_jsonb["required_documents"]
    if elig_jsonb.get("application_method"):
        data["application_method"] = elig_jsonb["application_method"]
    if elig_jsonb.get("schedule"):
        data["schedule"] = elig_jsonb["schedule"]
    if elig_jsonb.get("scoring_criteria"):
        data["scoring_criteria"] = elig_jsonb["scoring_criteria"]

    # eligibility キー以外に何もなければ空と判定
    if len(data) <= 2:
        return None

    return data


# ===========================================
# データ取得関数（Supabase優先、ローカルフォールバック）
# ===========================================

def _load_subsidies_with_fallback():
    # type: () -> Tuple[List[Dict[str, Any]], str]
    """
    補助金データを読み込む。Supabase 優先、失敗時ローカルJSON。
    Returns: (subsidies_list, source_label)
    """
    if _supabase.is_configured and _supabase.check_available():
        try:
            rows = _supabase.query_subsidies(
                select="id,name,prefecture,prefecture_code,target,max_amount,deadline,url,summary,structured,source_url,category,subcategory,status,fiscal_year",
                order="prefecture_code.asc",
            )
            if rows:
                return _supabase_subsidies_to_local_format(rows), "supabase"
        except Exception:
            pass

    # フォールバック: ローカルJSON
    return load_subsidies(), "local-json"


def _load_requirements_with_fallback(subsidy_id):
    # type: (int) -> Tuple[Optional[Dict[str, Any]], str]
    """
    Requirements データを取得。Supabase 優先、ローカルフォールバック。
    """
    # まずローカルの5大補助金データを確認
    local_reqs = get_requirements_data()
    if subsidy_id in local_reqs:
        return local_reqs[subsidy_id], "local-seed"

    # Supabase から subsidies.eligibility を取得
    if _supabase.is_configured and _supabase.check_available():
        try:
            rows = _supabase.query_subsidies(
                select="id,name,eligibility",
                filters={
                    "id": "eq.{}".format(subsidy_id),
                    "structured": "eq.true",
                },
                limit=1,
            )
            if rows and len(rows) > 0:
                data = _extract_requirements_from_eligibility(rows[0])
                if data:
                    return data, "supabase"
        except Exception:
            pass

    return None, "not-found"


# ===========================================
# MCP ツール
# ===========================================

@mcp.tool()
def hojokin_match(
    prefecture,          # type: str
    industries=None,     # type: Optional[List[str]]
    employee_count=None, # type: Optional[int]
    capital=None,        # type: Optional[int]
    business_stage=None, # type: Optional[str]
    purposes=None,       # type: Optional[List[str]]
    keyword=None,        # type: Optional[str]
    limit=20,            # type: int
):
    # type: (...) -> str
    """企業情報から該当する補助金・助成金を判定し、マッチ度順にリストを返す

    Supabase hojokin.subsidies テーブルを参照（フォールバック: ローカルJSON）。

    Args:
        prefecture: 都道府県名（例: 東京都）（必須）
        industries: 業種リスト（例: ["製造業", "情報通信業"]）
        employee_count: 従業員数
        capital: 資本金（円）
        business_stage: 事業ステージ（創業前/創業期/成長期/安定期/事業承継/事業再生）
        purposes: 利用目的（例: ["DX", "設備投資", "賃上げ"]）
        keyword: フリーワード検索
        limit: 返却する最大件数（デフォルト20）

    Returns:
        マッチした補助金リスト（JSON文字列）
    """
    try:
        subsidies, source = _load_subsidies_with_fallback()

        result = match_subsidies(
            subsidies=subsidies,
            prefecture=prefecture,
            industries=industries,
            employee_count=employee_count,
            capital=capital,
            business_stage=business_stage,
            purposes=purposes,
            keyword=keyword,
            limit=limit,
        )

        result["data_source"] = source
        result["fetched_at"] = datetime.now(timezone.utc).isoformat()
        return json.dumps(result, ensure_ascii=False, indent=2)

    except FileNotFoundError as e:
        return json.dumps({
            "error": str(e),
            "message": "補助金データの読み込みに失敗しました。",
            "fallback_used": True,
        }, ensure_ascii=False)
    except Exception as e:
        return json.dumps({
            "error": "内部エラー: {}".format(str(e)),
            "message": "予期せぬエラーが発生しました。",
        }, ensure_ascii=False)


@mcp.tool()
def hojokin_requirements(
    subsidy_id,          # type: int
    include_scoring=True,  # type: bool
):
    # type: (...) -> str
    """補助金IDから申請要件・必要書類・審査基準の詳細を返す

    データソース:
      - Supabase hojokin.subsidies テーブルの eligibility JSONB
      - ローカルシードデータ（5大補助金: 9001-9005）

    対応補助金（ローカルシードデータ）:
      - 9001: 小規模事業者持続化補助金
      - 9002: IT導入補助金（デジタル化・AI導入補助金）
      - 9003: ものづくり補助金
      - 9004: 事業再構築補助金
      - 9005: キャリアアップ助成金

    structured=true の全補助金も Supabase 経由で対応。

    Args:
        subsidy_id: 補助金ID（hojokin_matchの結果から取得、または上記IDを直接指定）
        include_scoring: 審査基準・加点項目を含めるか（デフォルト: True）

    Returns:
        申請要件の詳細（JSON文字列）
    """
    try:
        data, source = _load_requirements_with_fallback(subsidy_id)

        if data is None:
            # 既存データから名前でシードデータのIDに変換を試みる
            subsidies, _ = _load_subsidies_with_fallback()
            resolved_id = None
            for item in subsidies:
                if item.get("id") == subsidy_id:
                    name = item.get("name", "")
                    for key, sid in SUBSIDY_NAME_TO_ID.items():
                        if key in name or name in key:
                            resolved_id = sid
                            break
                    break

            if resolved_id:
                data, source = _load_requirements_with_fallback(resolved_id)

        if data is None:
            requirements_db = get_requirements_data()
            available = [
                {"subsidy_id": sid, "name": d["subsidy_name"]}
                for sid, d in requirements_db.items()
            ]
            return json.dumps({
                "error": "指定された補助金ID（{}）の申請要件データがありません".format(subsidy_id),
                "message": "以下の主要補助金または structured=true の補助金に対応しています",
                "available_subsidies": available,
                "data_source": "not-found",
                "fallback_used": False,
            }, ensure_ascii=False, indent=2)

        if not include_scoring:
            data = {k: v for k, v in data.items() if k != "scoring_criteria"}

        data["data_source"] = source
        data["fetched_at"] = datetime.now(timezone.utc).isoformat()
        data["fallback_used"] = source == "local-seed"
        return json.dumps(data, ensure_ascii=False, indent=2)

    except Exception as e:
        return json.dumps({
            "error": "内部エラー: {}".format(str(e)),
            "message": "予期せぬエラーが発生しました。",
        }, ensure_ascii=False)


@mcp.tool()
def hojokin_checklist(
    subsidy_id,                    # type: int
    has_gbiz_id=None,              # type: Optional[bool]
    has_certified_advisor=None,    # type: Optional[bool]
    has_financial_statements=None, # type: Optional[bool]
):
    # type: (...) -> str
    """補助金IDから申請準備のチェックリストを生成する

    対応補助金:
      - 9001: 小規模事業者持続化補助金
      - 9002: IT導入補助金（デジタル化・AI導入補助金）
      - 9003: ものづくり補助金
      - 9004: 事業再構築補助金
      - 9005: キャリアアップ助成金

    Args:
        subsidy_id: 補助金ID（hojokin_matchの結果から取得、または上記IDを直接指定）
        has_gbiz_id: GビズIDプライム取得済みか（任意）
        has_certified_advisor: 認定支援機関の確認済みか（任意）
        has_financial_statements: 直近の決算書があるか（任意）

    Returns:
        申請準備チェックリスト（JSON文字列）
    """
    try:
        checklist_db = get_checklist_data()
        source = "local-seed"

        if subsidy_id not in checklist_db:
            # 既存データから名前でID解決を試みる
            subsidies, _ = _load_subsidies_with_fallback()
            resolved_id = None
            for item in subsidies:
                if item.get("id") == subsidy_id:
                    name = item.get("name", "")
                    for key, sid in SUBSIDY_NAME_TO_ID.items():
                        if key in name or name in key:
                            resolved_id = sid
                            break
                    break

            if resolved_id and resolved_id in checklist_db:
                subsidy_id = resolved_id
            else:
                available = [
                    {"subsidy_id": sid, "name": data["subsidy_name"]}
                    for sid, data in checklist_db.items()
                ]
                return json.dumps({
                    "error": "指定された補助金ID（{}）のチェックリストデータがありません".format(subsidy_id),
                    "message": "以下の主要補助金のみ対応しています",
                    "available_subsidies": available,
                    "data_source": source,
                }, ensure_ascii=False, indent=2)

        data = checklist_db[subsidy_id].copy()

        company_status = {
            "has_gbiz_id": has_gbiz_id,
            "has_certified_advisor": has_certified_advisor,
            "has_financial_statements": has_financial_statements,
        }

        status_task_map = {
            "has_gbiz_id": ["GビズID"],
            "has_certified_advisor": ["認定経営革新等支援機関", "認定支援機関"],
            "has_financial_statements": ["決算書", "確定申告書"],
        }

        phases = data.get("phases", [])
        for phase in phases:
            for item in phase.get("items", []):
                task_text = item.get("task", "") + item.get("description", "")
                for status_key, keywords in status_task_map.items():
                    status_val = company_status.get(status_key)
                    if status_val is True and any(kw in task_text for kw in keywords):
                        item["completed"] = True

        total_items = sum(len(p.get("items", [])) for p in phases)
        completed_items = sum(
            1 for p in phases for item in p.get("items", []) if item.get("completed")
        )
        total_days = sum(p.get("estimated_days", 0) for p in phases)

        data["progress_summary"] = {
            "total_items": total_items,
            "completed_items": completed_items,
            "completion_rate": "{}%".format(round(completed_items / total_items * 100)) if total_items > 0 else "0%",
            "total_estimated_days": total_days,
        }

        data["data_source"] = source
        data["fetched_at"] = datetime.now(timezone.utc).isoformat()
        return json.dumps(data, ensure_ascii=False, indent=2)

    except Exception as e:
        return json.dumps({
            "error": "内部エラー: {}".format(str(e)),
            "message": "予期せぬエラーが発生しました。",
        }, ensure_ascii=False)


@mcp.tool()
def hojokin_plan_draft(
    subsidy_id,        # type: int
    company_profile,   # type: Dict[str, Any]
    project_overview,  # type: Dict[str, Any]
    output_format="structured_json",  # type: str
):
    # type: (...) -> str
    """事業概要と補助金情報から申請用事業計画書のテンプレートを返す

    Claude APIは使用しません。構造化テンプレート＋補助金データを返し、
    呼び出し側AI（BPB v7等）がテンプレートを使って計画書を生成します。

    各セクションには以下を含みます:
      - section_title: セクション名
      - guidance: 何を書くべきか
      - scoring_hint: 審査基準との対応
      - example_text: 例文テンプレート（プレースホルダ付き）
      - max_chars: 推奨文字数
      - scoring_alignment: この補助金の審査基準に基づく具体的なアドバイス

    Args:
        subsidy_id: 対象補助金のID（hojokin_matchの結果から取得、または9001-9005を直接指定）
        company_profile: 企業プロフィール
            - name (str, 必須): 企業名
            - business_description (str, 必須): 事業内容
            - strengths (str, 任意): 自社の強み
            - challenges (str, 任意): 現在の課題
            - employee_count (int, 任意): 従業員数
            - annual_revenue (int, 任意): 年間売上高（円）
        project_overview: 申請事業の概要
            - title (str, 必須): 事業タイトル
            - description (str, 必須): 事業の詳細説明
            - investment_amount (int, 任意): 投資総額（円）
            - timeline_months (int, 任意): 事業期間（月数）
            - expected_outcomes (list[str], 任意): 期待する成果（定量目標）
        output_format: 出力形式（"structured_json" または "markdown"、デフォルト: structured_json）

    Returns:
        計画書テンプレート（JSON文字列）— セクション、セルフチェック項目、警告を含む
    """
    try:
        # --- 入力バリデーション ---
        if not company_profile or not isinstance(company_profile, dict):
            return json.dumps({
                "error": "company_profile は必須です（name, business_description を含む辞書）",
            }, ensure_ascii=False)

        if not company_profile.get("name") or not company_profile.get("business_description"):
            return json.dumps({
                "error": "company_profile には name と business_description が必須です",
            }, ensure_ascii=False)

        if not project_overview or not isinstance(project_overview, dict):
            return json.dumps({
                "error": "project_overview は必須です（title, description を含む辞書）",
            }, ensure_ascii=False)

        if not project_overview.get("title") or not project_overview.get("description"):
            return json.dumps({
                "error": "project_overview には title と description が必須です",
            }, ensure_ascii=False)

        # --- 補助金データの取得 ---
        subsidy_data, req_source = _load_requirements_with_fallback(subsidy_id)

        # IDで見つからない場合、名前ベースで解決を試みる
        subsidy_name = ""
        subsidy_url = ""
        scoring_criteria = None  # type: Optional[List[Dict[str, Any]]]

        if subsidy_data is None:
            subsidies, _ = _load_subsidies_with_fallback()
            resolved_id = None
            for item in subsidies:
                if item.get("id") == subsidy_id:
                    subsidy_name = item.get("name", "")
                    subsidy_url = item.get("url", "") or item.get("source_url", "")
                    for key, sid in SUBSIDY_NAME_TO_ID.items():
                        if key in subsidy_name or subsidy_name in key:
                            resolved_id = sid
                            break
                    break

            if resolved_id:
                subsidy_data, req_source = _load_requirements_with_fallback(resolved_id)

        if subsidy_data:
            subsidy_name = subsidy_data.get("subsidy_name", subsidy_name)
            scoring_criteria = subsidy_data.get("scoring_criteria")
            if not subsidy_url:
                subsidy_url = subsidy_data.get("source_url", "")

        # --- テンプレートセクションの構築 ---
        base_sections = get_plan_sections()
        scoring_alignment = build_scoring_alignment(scoring_criteria)

        # プレースホルダを実データで置換
        placeholders = {
            "{company_name}": company_profile.get("name", "（企業名）"),
            "{business_description}": company_profile.get("business_description", "（事業内容）"),
            "{company_strengths}": company_profile.get("strengths", "（自社の強みを記載）"),
            "{project_title}": project_overview.get("title", "（事業タイトル）"),
            "{project_description}": project_overview.get("description", "（事業の説明）"),
            "{investment_amount}": str(project_overview.get("investment_amount", "（未定）")),
        }

        # 課題のプレースホルダ
        challenges = company_profile.get("challenges", "")
        if challenges:
            placeholders["{challenge_1}"] = challenges
            placeholders["{challenge_2}"] = "（追加の課題があれば記載）"
        else:
            placeholders["{challenge_1}"] = "（課題1を記載）"
            placeholders["{challenge_2}"] = "（課題2を記載）"

        # 期待される成果
        outcomes = project_overview.get("expected_outcomes", [])
        if outcomes:
            placeholders["{expected_outcomes}"] = "、".join(outcomes)
        else:
            placeholders["{expected_outcomes}"] = "（期待される成果を記載）"

        sections_output = []
        for section in base_sections:
            example = section["example_text"]
            for key, value in placeholders.items():
                example = example.replace(key, value)

            sec_data = {
                "section_number": section["section_number"],
                "section_title": section["section_title"],
                "guidance": section["guidance"],
                "scoring_hint": section["scoring_hint"],
                "example_text": example,
                "max_chars": section["max_chars"],
            }  # type: Dict[str, Any]

            # 補助金固有のスコアリングアライメントを追加
            sec_num = section["section_number"]
            if sec_num in scoring_alignment:
                sec_data["scoring_alignment"] = scoring_alignment[sec_num]

            sections_output.append(sec_data)

        # --- セルフチェック項目の構築 ---
        self_check_items = get_default_self_check_items()

        # 審査基準がある場合、補助金固有のチェック項目を追加
        if scoring_criteria:
            for criterion in scoring_criteria:
                cat = criterion.get("category", "")
                desc = criterion.get("description", "")
                weight = criterion.get("weight", "")
                if weight == "加点":
                    self_check_items.append({
                        "criterion": "加点項目: {}".format(cat),
                        "check_question": "{}に対応する内容が計画書に含まれているか".format(desc),
                        "importance": "bonus",
                    })

        # --- 警告メッセージ ---
        warnings = get_default_warnings()

        if not subsidy_data:
            warnings.insert(0,
                "指定された補助金ID（{}）の詳細データが見つかりませんでした。汎用テンプレートを使用しています。対象補助金の公募要領を必ず確認してください。".format(subsidy_id)
            )

        # --- レスポンス組み立て ---
        result = {
            "subsidy_id": subsidy_id,
            "subsidy_name": subsidy_name or "（補助金名不明）",
            "subsidy_url": subsidy_url,
            "company_name": company_profile.get("name", ""),
            "project_title": project_overview.get("title", ""),
            "sections": sections_output,
            "self_check_items": self_check_items,
            "warnings": warnings,
            "data_source": req_source,
            "fetched_at": datetime.now(timezone.utc).isoformat(),
            "note": "このテンプレートはAIによる計画書生成の入力データです。Claude APIは使用していません。呼び出し側AIがこのデータを基に計画書を生成してください。",
        }  # type: Dict[str, Any]

        # スコアリング基準があれば含める
        if scoring_criteria:
            result["scoring_criteria"] = scoring_criteria

        # markdown 出力の場合、テンプレートのMarkdownプレビューも生成
        if output_format == "markdown":
            md_lines = [
                "# 事業計画書ドラフト",
                "",
                "**補助金名**: {}".format(subsidy_name or "（補助金名不明）"),
                "**企業名**: {}".format(company_profile.get("name", "")),
                "**事業タイトル**: {}".format(project_overview.get("title", "")),
                "",
                "---",
                "",
            ]
            for sec in sections_output:
                md_lines.append("## {}. {}".format(sec["section_number"], sec["section_title"]))
                md_lines.append("")
                md_lines.append("> **ガイダンス**: {}".format(sec["guidance"]))
                md_lines.append("")
                md_lines.append("> **審査基準との対応**: {}".format(sec["scoring_hint"]))
                md_lines.append("")
                if sec.get("scoring_alignment"):
                    md_lines.append("**この補助金の関連審査基準:**")
                    for sa in sec["scoring_alignment"]:
                        md_lines.append("- {}".format(sa))
                    md_lines.append("")
                md_lines.append("**例文テンプレート:**")
                md_lines.append("")
                md_lines.append(sec["example_text"])
                md_lines.append("")
                md_lines.append("*推奨文字数: {}文字以内*".format(sec["max_chars"]))
                md_lines.append("")
                md_lines.append("---")
                md_lines.append("")

            md_lines.append("## セルフチェック")
            md_lines.append("")
            for item in self_check_items:
                importance = item.get("importance", "")
                marker = {"high": "[重要]", "medium": "[中]", "low": "[低]", "bonus": "[加点]"}.get(importance, "")
                md_lines.append("- [ ] {} {}: {}".format(marker, item["criterion"], item["check_question"]))
            md_lines.append("")

            md_lines.append("## 注意事項")
            md_lines.append("")
            for w in warnings:
                md_lines.append("- {}".format(w))
            md_lines.append("")

            result["markdown_preview"] = "\n".join(md_lines)

        return json.dumps(result, ensure_ascii=False, indent=2)

    except Exception as e:
        return json.dumps({
            "error": "内部エラー: {}".format(str(e)),
            "message": "予期せぬエラーが発生しました。",
        }, ensure_ascii=False)


def main():
    """Entry point for the hojokin-mcp command."""
    mcp.run()


if __name__ == "__main__":
    main()
