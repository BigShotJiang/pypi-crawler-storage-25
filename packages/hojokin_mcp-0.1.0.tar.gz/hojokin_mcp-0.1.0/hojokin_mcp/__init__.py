"""hojokin-mcp: 日本の補助金・助成金マッチングMCPサーバー"""

__version__ = "0.1.0"
