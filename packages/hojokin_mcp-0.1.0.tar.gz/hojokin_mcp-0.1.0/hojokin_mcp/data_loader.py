"""
data_loader.py — 補助金データの読み込み

MVP: ローカルJSONファイルから読み込み
Phase 2以降: Supabase接続に切り替え可能
"""

from __future__ import annotations

import json
import os
from typing import List, Dict, Any, Optional


# グローバルキャッシュ
_subsidies_cache = None  # type: Optional[List[Dict[str, Any]]]


def load_subsidies_from_json(json_path=None):
    # type: (Optional[str]) -> List[Dict[str, Any]]
    """ローカルJSONファイルから補助金データを読み込む"""
    global _subsidies_cache

    if _subsidies_cache is not None:
        return _subsidies_cache

    if json_path is None:
        json_path = os.environ.get(
            "DATA_JSON_PATH",
            os.path.join(os.path.dirname(__file__), "data", "hojokin_supabase_import.json"),
        )

    # 相対パスを絶対パスに変換
    json_path = os.path.abspath(json_path)

    if not os.path.exists(json_path):
        raise FileNotFoundError("補助金データファイルが見つかりません: {}".format(json_path))

    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    # IDが無い場合はインデックスで割り当て
    for i, item in enumerate(data):
        if "id" not in item:
            item["id"] = i + 1

    _subsidies_cache = data
    return _subsidies_cache


def load_subsidies(source=None):
    # type: (Optional[str]) -> List[Dict[str, Any]]
    """
    データソースに応じて補助金データを読み込む。
    source: "json" or "supabase" (デフォルトは環境変数 DATA_SOURCE)
    """
    if source is None:
        source = os.environ.get("DATA_SOURCE", "json")

    if source == "json":
        return load_subsidies_from_json()
    elif source == "supabase":
        raise NotImplementedError(
            "Supabase接続はPhase 2で実装予定です。DATA_SOURCE=json を使用してください。"
        )
    else:
        raise ValueError("不明なデータソース: {}".format(source))


def clear_cache():
    # type: () -> None
    """キャッシュをクリア（データ再読み込み用）"""
    global _subsidies_cache
    _subsidies_cache = None
