from hojokin_mcp.server import main

main()
