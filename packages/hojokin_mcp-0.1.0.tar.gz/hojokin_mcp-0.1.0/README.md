# hojokin-mcp

日本の補助金・助成金マッチングMCPサーバー。

企業情報を入力すると、該当する補助金・助成金をマッチ度順に返します。申請要件の確認、チェックリスト生成、事業計画書テンプレート生成にも対応。

## インストール

```bash
pip install hojokin-mcp
```

Supabase連携や `.env` ファイルを使う場合:

```bash
pip install hojokin-mcp[dotenv]
```

## 使い方

### Claude Code から利用する

`.mcp.json` に以下を追加:

```json
{
  "mcpServers": {
    "hojokin": {
      "command": "hojokin-mcp"
    }
  }
}
```

### コマンドラインから起動

```bash
hojokin-mcp
```

または:

```bash
python -m hojokin_mcp
```

stdio経由でMCPプロトコルを待ち受けます。

## 提供ツール

### hojokin_match

企業情報から該当する補助金・助成金を判定し、マッチ度順にリストを返す。

| パラメータ | 型 | 必須 | 説明 |
|-----------|------|------|------|
| prefecture | string | はい | 都道府県名（例: 東京都） |
| industries | string[] | いいえ | 業種リスト |
| employee_count | integer | いいえ | 従業員数 |
| capital | integer | いいえ | 資本金（円） |
| business_stage | string | いいえ | 事業ステージ |
| purposes | string[] | いいえ | 利用目的 |
| keyword | string | いいえ | フリーワード検索 |
| limit | integer | いいえ | 最大件数（デフォルト: 20） |

### hojokin_requirements

補助金IDから申請要件・必要書類・審査基準の詳細を返す。

対応補助金（ローカルシードデータ）:
- 9001: 小規模事業者持続化補助金
- 9002: IT導入補助金（デジタル化・AI導入補助金）
- 9003: ものづくり補助金
- 9004: 事業再構築補助金
- 9005: キャリアアップ助成金

### hojokin_checklist

補助金IDから申請準備のチェックリストを生成する。

### hojokin_plan_draft

事業概要と補助金情報から申請用事業計画書のテンプレートを返す。

## データソース

- Primary: Supabase `hojokin.subsidies` テーブル（環境変数で設定）
- Fallback: パッケージ同梱のローカルJSON

### Supabase連携（オプション）

環境変数または `.env` ファイルで設定:

```bash
SUPABASE_URL=https://xxxxx.supabase.co
SUPABASE_ANON_KEY=eyJhbGci...
SUPABASE_SCHEMA=hojokin
```

## ライセンス

MIT
