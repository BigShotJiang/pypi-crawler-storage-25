#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include <Windows.h>

#include "module/py_types.h"

// ------------- Shared State -------------- //

HINSTANCE e_hINSTANCE;

// --------------- PY-Defs ---------------- //

static PyMethodDef methods[] = {
        {NULL, NULL, 0, NULL}
};

static struct PyModuleDef moduledef = {
        PyModuleDef_HEAD_INIT,
        "_mWinPy",
        NULL,
        -1,
        methods
};

PyMODINIT_FUNC PyInit__mWinPy(void) {
        e_hINSTANCE = GetModuleHandleW(NULL);

        if (PyType_Ready(&PyProcessType) < 0) return NULL;
        if (PyType_Ready(&PyProcessesType) < 0) return NULL;

        PyObject *m = PyModule_Create(&moduledef);
        if (!m) return NULL;

        Py_INCREF(&PyProcessType);
        if (PyModule_AddObject(m, "Process", (PyObject *)&PyProcessType) < 0) {
                Py_DECREF(&PyProcessType);
                Py_DECREF(m);
                return NULL;
        }

        Py_INCREF(&PyProcessesType);
        if (PyModule_AddObject(m, "Processes", (PyObject *)&PyProcessesType) < 0) {
                Py_DECREF(&PyProcessesType);
                Py_DECREF(m);
                return NULL;
        }

        return m;
}
