#include "mProcesses.h"
#include <stdlib.h>
#include <Psapi.h> //https://learn.microsoft.com/de-de/windows/win32/psapi/psapi-reference

DWORD *getAllProcessesIDs(DWORD *count) {
        if (!count) {
                return NULL;
        }

        DWORD maxCount = *count;
        DWORD capacity = (maxCount > 0) ? maxCount * sizeof(DWORD) : 1024 * sizeof(DWORD);
        DWORD *processes = NULL;

        while (1) {
                DWORD *tmpP = (DWORD *)realloc(processes, capacity);
                if (!tmpP) { free(processes); return NULL; }

                processes = tmpP;

                DWORD bytesNeeded = 0;
                if (!EnumProcesses(processes, capacity, &bytesNeeded)) {
                        free(processes);
                        return NULL;
                }

                if (bytesNeeded < capacity) {
                        DWORD actualCount = bytesNeeded / sizeof(DWORD);
                        *count = (maxCount > 0 && actualCount > maxCount) ? maxCount : actualCount;
                        return processes;
                }

                if (capacity > (DWORD)(~0u) / 2) { free(processes); return NULL; }

                capacity *= 2;
        }
}