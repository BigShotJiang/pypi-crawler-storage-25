class Process:
    """Represents the current process handle exposed by the native extension.

    Attributes:
        pid: Operating-system process identifier.
        handle: Native Windows process handle.
    """

    pid: int
    handle: int

    def __init__(self) -> None:
        """Create a process wrapper bound to the current running process.

        Returns:
            None.
        """
        ...

    def destroy(self) -> None:
        """Release the native process handle.

        Returns:
            None.
        """
        ...

class Processes:
    @classmethod
    def getAllProcessesIDs(cls, count: int = 1024) -> list[int]:
        """Get a list of all process IDs currently running on the system.

        Returns:
            A list of process IDs.
        """
        ...