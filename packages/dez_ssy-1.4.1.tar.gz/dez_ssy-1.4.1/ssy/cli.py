"""
ssy.cli — Interactive command-line interface for DeZ SSY (Selfsustainability).

First-run flow:
  1. Consent   — explicit user confirmation before any file parsing (DOI)
  2. Discover  — workspace scan with live progress bar
  3. Assess    — compliance check with per-agent progress bar
  4. Summary   — ranked findings table + benefit estimate
  5. Repair    — user selects mode (full / selective / step-by-step / abort)
  6. Progress  — repair phase with live progress bar
  7. Report    — what was repaired, resolved, kept; which library modules helped

Entry points:
    py -3 -m ssy [options]
    py -3 _scripts/selfsustainability.py [options]
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path
from typing import Any

from .config import load_config_or_discover
from .engine import SustainabilityEngine
from .finding import Finding, RepairResult, REPAIR_ORDER
from .version import VERSION, RELEASE_DATE, CODENAME

# ── Constants ─────────────────────────────────────────────────────────────────

_W = 70  # display width for separator lines

# Per repair-key: (estimated display time, is_auto_fixable)
_REPAIR_EST: dict[str, tuple[str, bool]] = {
    "coverage_json":     ("~1 min",   True),
    "test_plan":         ("~2 min",   True),
    "qualification_run": ("~2 min",   True),
    "aspice_wp":         ("~2 min",   True),
    "sbom":              ("~3 min",   True),
    "iso27001_soa":      ("~5 min",   True),
    "iso21434_goals":    ("~5 min",   True),
    "stub_test_case":    ("~1 min",   True),
    "unverified_req":    ("~1 min",   True),
    "trace_links":       ("~1 min",   True),
    "baseline_tag":      ("~1 min",   True),
    "consultation":      ("2-8 h",    False),
    "forge_ticket":      ("30+ min",  False),
}

# Which SSY library module each repair handler lives in
_REPAIR_MODULE: dict[str, str] = {
    "coverage_json":     "ssy/engine.py  _repair_coverage_json()",
    "test_plan":         "ssy/engine.py  _repair_test_plan()",
    "qualification_run": "ssy/engine.py  _repair_qualification_run()",
    "aspice_wp":         "ssy/engine.py  _repair_aspice_wp()",
    "sbom":              "ssy/engine.py  _repair_sbom()",
    "iso27001_soa":      "ssy/engine.py  _repair_iso27001_soa()",
    "iso21434_goals":    "ssy/engine.py  _repair_iso21434_goals()",
    "stub_test_case":    "ssy/engine.py  _repair_stub_test_case()",
    "unverified_req":    "ssy/engine.py  _repair_unverified_req()",
    "trace_links":       "ssy/engine.py  _repair_trace_links()",
    "baseline_tag":      "ssy/engine.py  _repair_baseline_tag()",
    "consultation":      "ssy/engine.py  _repair_consultation()",
    "forge_ticket":      "ssy/engine.py  _repair_forge_ticket()",
}

# Which assessor module detected each finding agent prefix
_ASSESSOR_MODULE: dict[str, str] = {
    "ssy-discovery":  "ssy/discovery.py  ProjectDiscovery.scan()",
    "direct-scan":    "ssy/engine.py     _assess_direct()",
    "reqvault-scan":  "ssy/engine.py     _assess_unverified_reqs()",
    "trace-val":      "ssy/engine.py     _assess_trace()",
    "norm-orchest":   "ssy/engine.py     _assess_norm_orchestrator()  +  _scripts/norm-agent-orchestrator.py",
}

_SEV_RANK = {"critical": 0, "fail": 0, "error": 0,
             "high": 1, "warn": 1, "warning": 1,
             "medium": 2, "info": 2, "low": 3}

_SEV_LABEL = {"fail": "FAIL    ", "critical": "CRITICAL",
              "error": "CRITICAL", "warn": "WARN    ",
              "warning": "WARN    ", "high": "HIGH    ",
              "medium": "MEDIUM  ", "info": "INFO    ", "low": "LOW     "}


# ── Display helpers ───────────────────────────────────────────────────────────

def _hr(char: str = "=") -> str:
    return char * _W


def _banner() -> None:
    print()
    print(_hr())
    print(f"  DeZ SSY {VERSION}  '{CODENAME}'  ({RELEASE_DATE})")
    print(f"  Selfsustainability — Adaptive Self-Repair Engine")
    print(_hr())


def _progress(step: int, total: int, label: str, bar_w: int = 38) -> None:
    """Overwrite current line with an ASCII progress bar."""
    pct    = int(100 * step / max(total, 1))
    filled = int(bar_w * step / max(total, 1))
    bar    = "#" * filled + "-" * (bar_w - filled)
    short  = label[:30] if len(label) > 30 else label
    sys.stdout.write(f"\r  [{bar}] {pct:3d}%  {short:<30}")
    sys.stdout.flush()


def _progress_done(final_label: str = "done", bar_w: int = 38) -> None:
    bar = "#" * bar_w
    sys.stdout.write(f"\r  [{bar}] 100%  {final_label:<30}\n")
    sys.stdout.flush()


def _clr() -> None:
    """Clear the progress line before printing normal output."""
    sys.stdout.write("\r" + " " * (_W + 10) + "\r")
    sys.stdout.flush()


# ── Consent / DOI ─────────────────────────────────────────────────────────────

def _consent(root: Path, project_name: str) -> bool:
    """Display the DOI consent request and return True if the user agrees."""
    print()
    print(_hr())
    print("  ANALYSIS CONSENT")
    print(_hr("-"))
    print(f"""
  Project  : {project_name}
  Location : {root}

  DeZ SSY needs your permission before reading project files.

  During analysis this tool will:
    READ   all files in the project directory (source, YAML, Markdown, CI)
    NEVER  transmit any data outside this machine
    WRITE  only if you confirm repair in step 4 (can be aborted at any time)

  You can review all findings before deciding whether to apply any fixes.
""")
    print(_hr("-"))
    try:
        answer = input("  Proceed with analysis? [y/N]: ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print()
        return False
    print()
    return answer in ("y", "yes")


# ── Findings table ────────────────────────────────────────────────────────────

def _is_auto(repair_key: str) -> bool:
    return _REPAIR_EST.get(repair_key, ("", False))[1]


def _est_time(repair_key: str) -> str:
    return _REPAIR_EST.get(repair_key, ("?", False))[0]


def _findings_table(findings: list[Finding]) -> None:
    """Print ranked findings table and benefit summary."""
    if not findings:
        print()
        print("  No findings — project is already clean.")
        return

    # Sort: severity rank first, then rule_id
    ranked = sorted(findings, key=lambda f: (_SEV_RANK.get(f.severity.lower(), 3), f.rule_id))

    auto   = [f for f in ranked if _is_auto(f.repair_key)]
    manual = [f for f in ranked if not _is_auto(f.repair_key)]

    # Deduplicate repair keys for time estimation
    auto_keys   = sorted({f.repair_key for f in auto},   key=lambda k: REPAIR_ORDER.get(k, 99))
    manual_keys = sorted({f.repair_key for f in manual}, key=lambda k: REPAIR_ORDER.get(k, 99))

    print()
    print(_hr())
    print(f"  ANALYSIS SUMMARY — {len(findings)} finding(s)")
    print(f"  Auto-fixable: {len(auto)}   Manual review: {len(manual)}")
    print(_hr())
    print()

    # Header
    c = [4, 10, 38, 26, 10]
    hdr = (f"  {'#':<{c[0]}} {'SEVERITY':<{c[1]}} {'Finding':<{c[2]}} "
           f"{'Rule / Agent':<{c[3]}} Est. Time")
    sep = "  " + "  ".join("-" * w for w in c)
    print(hdr)
    print(sep)

    for i, f in enumerate(ranked, 1):
        sev   = _SEV_LABEL.get(f.severity.lower(), f.severity.upper()[:8])
        msg   = (f.message[:37] + "..") if len(f.message) > 37 else f.message
        rule  = (f.rule_id[:25] + "..") if len(f.rule_id) > 25 else f.rule_id
        fix   = _est_time(f.repair_key) if _is_auto(f.repair_key) else f"MANUAL {_est_time(f.repair_key)}"
        print(f"  {i:<{c[0]}} {sev:<{c[1]}} {msg:<{c[2]}} {rule:<{c[3]}} {fix}")

    print()
    print(_hr("-"))

    # Benefit block
    auto_time_parts = [_est_time(k) for k in auto_keys]
    auto_time_str   = " + ".join(auto_time_parts) if auto_time_parts else "0 min"

    print(f"  WHAT SSY REPAIR WILL DO:")
    print()

    _category_benefit(ranked)

    print()
    print(f"  Estimated auto-repair time : {auto_time_str}")
    if manual_keys:
        print(f"  Manual review required for : {', '.join(manual_keys)}")
        print(f"  Estimated manual effort    : {_manual_time(manual)}")
    print()


def _category_benefit(findings: list[Finding]) -> None:
    """Print per-category benefit description."""
    repair_keys = {f.repair_key for f in findings if _is_auto(f.repair_key)}
    manual_keys = {f.repair_key for f in findings if not _is_auto(f.repair_key)}

    benefits = {
        "coverage_json":     "Generate coverage.json — activates MC/DC gate (DO-178C / ASPICE SWE.4.BP5)",
        "test_plan":         "Create Master Test Plan stub (IEEE 829 / ISO 29119-3 / ASPICE SWE.4-SWE.6)",
        "qualification_run": "Log qualification test run record (ASPICE SWE.6.BP3 / ISTQB TE.1)",
        "aspice_wp":         "Generate unit + integration verification records (ASPICE SWE.4.BP4 / SWE.5.BP4)",
        "sbom":              "Generate CycloneDX SBOM — satisfies EU Cyber Resilience Act Art.13",
        "iso27001_soa":      "Generate ISO 27001:2022 Statement of Applicability (93 Annex A controls)",
        "iso21434_goals":    "Generate ISO 21434 cybersecurity goal stubs (TARA / threat scenarios)",
        "stub_test_case":    "Create stub test cases for every uncovered requirement (ASPICE SWE.6.BP2)",
        "unverified_req":    "Patch verified_by links on requirements already covered by existing tests",
        "trace_links":       "Prune stale traceability links (derived_from / realized_by / verified_by)",
        "baseline_tag":      "Create annotated git baseline tag BL-{date} (ASPICE SWE.4.BP6 / SWE.6.BP6)",
        "consultation":      "Write consultation YAML for MISRA / SEC gaps — human follow-up required",
        "forge_ticket":      "Create FORGE issue for each residual gap — ensures nothing is silently dropped",
    }

    for key in sorted(repair_keys | manual_keys, key=lambda k: REPAIR_ORDER.get(k, 99)):
        tag = "AUTO  " if key in repair_keys else "MANUAL"
        desc = benefits.get(key, key)
        print(f"    [{tag}]  {desc}")


def _manual_time(manual_findings: list[Finding]) -> str:
    parts = sorted({_est_time(f.repair_key) for f in manual_findings})
    return ", ".join(parts) if parts else "unknown"


# ── Repair menu ───────────────────────────────────────────────────────────────

def _repair_menu(findings: list[Finding]) -> str:
    """Prompt user to choose a repair mode. Returns one of:
    'full' | 'selective' | 'stepwise' | 'abort'
    """
    auto_n = sum(1 for f in findings if _is_auto(f.repair_key))

    print(_hr())
    print("  REPAIR OPTIONS")
    print(_hr("-"))
    print(f"  [1]  Full repair     — auto-fix all {auto_n} fixable finding(s) in one pass")
    print(f"  [2]  Selective       — choose individual findings to repair")
    print(f"  [3]  Step-by-step    — confirm each repair handler before it runs")
    print(f"  [4]  Abort           — keep analysis report only; no changes made")
    print()

    while True:
        try:
            answer = input("  Your choice [1/2/3/4]: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return "abort"
        if answer == "1":
            return "full"
        if answer == "2":
            return "selective"
        if answer == "3":
            return "stepwise"
        if answer == "4":
            return "abort"
        print("  Please enter 1, 2, 3, or 4.")


def _select_findings(findings: list[Finding]) -> list[Finding]:
    """Selective mode: let user pick which repair keys to run."""
    auto = [f for f in findings if _is_auto(f.repair_key)]
    keys = sorted({f.repair_key for f in auto}, key=lambda k: REPAIR_ORDER.get(k, 99))

    if not keys:
        print("  No auto-fixable findings to select.")
        return []

    print()
    print("  Auto-fixable repair handlers:")
    for i, k in enumerate(keys, 1):
        count = sum(1 for f in auto if f.repair_key == k)
        print(f"    [{i}]  {k:<22}  ({count} finding(s))  {_est_time(k)}")
    print()

    while True:
        try:
            raw = input("  Select handlers (comma-separated numbers, e.g. 1,3): ").strip()
        except (EOFError, KeyboardInterrupt):
            return []
        try:
            indices   = [int(p.strip()) for p in raw.split(",") if p.strip()]
            sel_keys  = {keys[i - 1] for i in indices if 1 <= i <= len(keys)}
            return [f for f in findings if f.repair_key in sel_keys]
        except (ValueError, IndexError):
            print(f"  Invalid selection. Enter numbers 1–{len(keys)}.")


# ── Repair runner ─────────────────────────────────────────────────────────────

def _run_repair(
    engine: SustainabilityEngine,
    mode: str,
    findings: list[Finding],
    dry_run: bool,
    severity: str,
) -> list[RepairResult]:
    """Run repair for the given mode, showing a progress bar."""

    if mode == "selective":
        findings = _select_findings(findings)
        if not findings:
            print("  No findings selected — skipping repair.")
            return []

    print()
    print(_hr())
    print(f"  REPAIR{'  (dry-run)' if dry_run else ''}  — mode: {mode}")
    print(_hr("-"))

    ordered = engine.triage(findings)
    keys    = sorted({f.repair_key for f in ordered}, key=lambda k: REPAIR_ORDER.get(k, 99))
    total   = len(keys)
    results: list[RepairResult] = []

    if mode == "stepwise":
        for i, key in enumerate(keys, 1):
            subset = [f for f in ordered if f.repair_key == key]
            est    = _est_time(key)
            is_a   = _is_auto(key)
            print()
            print(f"  [{i}/{total}]  Handler: {key}  ({est})"
                  f"{'  [AUTO]' if is_a else '  [MANUAL — review recommended]'}")
            print(f"          Findings: {len(subset)}")
            try:
                ok = input("  Apply this repair? [y/N]: ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                print("\n  Repair aborted by user.")
                break
            if ok not in ("y", "yes"):
                results.append(RepairResult(key, False, dry_run, "Skipped by user"))
                continue
            # Run single key
            sub_result = engine.repair(subset, dry_run, severity)
            results.extend(sub_result)
            for r in sub_result:
                icon  = "+" if r.applied else "-"
                state = "DRY" if (dry_run and r.applied) else ("OK" if r.applied else "SKIP")
                print(f"  [{icon}] {r.key:<22}  [{state}]  {r.description}")
        print()
    else:
        # Full or selective — progress bar
        _progress(0, total, "Starting repair ...")

        def _on_step(step: int, _tot: int, key: str) -> None:
            _progress(step, total, key)

        results = engine.repair(ordered, dry_run, severity, on_step=_on_step)
        _progress_done("Repair complete")
        print()
        for r in results:
            icon  = "+" if r.applied else "-"
            state = "DRY" if (dry_run and r.applied) else ("OK" if r.applied else "SKIP")
            print(f"  [{icon}] {r.key:<22}  [{state}]  {r.description}")
            if r.error:
                print(f"        ! {r.error}")
        print()

    return results


# ── Post-repair summary ───────────────────────────────────────────────────────

def _repair_summary(findings: list[Finding], results: list[RepairResult]) -> None:
    repaired  = [r for r in results if r.applied and not r.dry_run]
    dry_shown = [r for r in results if r.applied and r.dry_run]
    skipped   = [r for r in results if not r.applied]
    manual    = [f for f in findings if not _is_auto(f.repair_key)]

    print(_hr())
    print("  REPAIR SUMMARY")
    print(_hr("-"))
    print(f"  Repaired (applied)    : {len(repaired)}")
    if dry_shown:
        print(f"  Dry-run shown         : {len(dry_shown)}")
    print(f"  Skipped / not needed  : {len(skipped)}")
    print(f"  Manual review needed  : {len(manual)}")
    print()

    if repaired:
        print("  Resolved:")
        for r in repaired:
            print(f"    + {r.key:<22}  {r.description}")
    if skipped:
        print("  Not applied:")
        for r in skipped:
            reason = r.error or r.description
            print(f"    - {r.key:<22}  {reason}")
    if manual:
        print("  Manual (requires human review):")
        for f in manual:
            print(f"    ! {f.rule_id:<24}  {f.message[:45]}")
    print()


# ── Detailed library report ───────────────────────────────────────────────────

def _library_report(findings: list[Finding], results: list[RepairResult]) -> None:
    """Print which SSY library modules detected and fixed each item."""
    print(_hr())
    print("  DETAILED LIBRARY REPORT — Agents & Modules Involved")
    print(_hr("-"))
    print()

    # Assessors that detected findings
    agent_map: dict[str, list[Finding]] = {}
    for f in findings:
        prefix = f.agent[:10]
        agent_map.setdefault(f.agent, []).append(f)

    print("  [ ASSESSORS — detected findings ]")
    for agent, flist in sorted(agent_map.items()):
        mod = "ssy/engine.py"
        for key, val in _ASSESSOR_MODULE.items():
            if agent.startswith(key):
                mod = val
                break
        nf = sum(1 for f in flist if f.is_fail)
        nw = len(flist) - nf
        print(f"    {agent:<22}  {len(flist):>2} finding(s)  [{nf} FAIL  {nw} WARN]")
        print(f"    {'':22}  => {mod}")
    print()

    # Repairers that ran
    applied_r  = [r for r in results if r.applied]
    skipped_r  = [r for r in results if not r.applied]

    if applied_r:
        print("  [ REPAIRERS — handlers that applied changes ]")
        for r in applied_r:
            mod = _REPAIR_MODULE.get(r.key, f"ssy/engine.py  _repair_{r.key}()")
            print(f"    {r.key:<22}  => {mod}")
        print()

    if skipped_r:
        print("  [ REPAIRERS — skipped / already satisfied ]")
        for r in skipped_r:
            reason = "already present" if "already exists" in r.description else r.description[:50]
            print(f"    {r.key:<22}  {reason}")
        print()

    # Norm coverage
    norm_agents = {f.agent for f in findings if f.agent.startswith("norm-")}
    if norm_agents:
        print("  [ NORM AGENTS — invoked via norm-agent-orchestrator.py ]")
        print(f"    Orchestrator : _scripts/norm-agent-orchestrator.py")
        print(f"    Norm base    : _shared/norm_agent_base.py")
        print()

    print("  [ LIBRARY MODULES INVOLVED IN THIS RUN ]")
    involved = {
        "ssy/engine.py":       "SustainabilityEngine — 6-phase DISCOVER→ASSESS→TRIAGE→REPAIR→VERIFY→CONVERGE",
        "ssy/discovery.py":    "ProjectDiscovery — auto-scan workspace; detect language, format, CI",
        "ssy/config.py":       "SustainabilityConfig — project config schema; load_config_or_discover()",
        "ssy/finding.py":      "Finding / RepairResult / IterationState — data structures + constants",
        "ssy/cli.py":          "CLI entry point — consent, progress UI, summary, library report (this file)",
        "ssy/version.py":      "Version metadata — VERSION, ASSESSORS, REPAIRERS, CHANGELOG",
    }
    for mod, role in involved.items():
        print(f"    {mod:<26}  {role}")
    print()
    print(_hr())


# ── Argument parser ───────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="ssy",
        description=(
            f"DeZ SSY {VERSION} — Selfsustainability: drop into any project, "
            "auto-discover, self-repair until clean."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
How it works:
  1. Consent   — explicit permission before any file parsing
  2. Discover  — workspace scan (languages, req format, CI, violations)
  3. Assess    — compliance check (ASPICE, MISRA, GDPR, EU AI Act, ...)
  4. Summary   — ranked findings table + what SSY will fix
  5. Repair    — choose: full / selective / step-by-step / abort
  6. Report    — what changed, which library modules helped

Examples:
  py -3 -m ssy                         # Full interactive flow
  py -3 -m ssy --yes                   # Skip consent prompt (CI use)
  py -3 -m ssy --dry-run               # Analyse only; never write files
  py -3 -m ssy --phase assess          # Show findings table then exit
  py -3 -m ssy --quick                 # Skip slow norm agents
  py -3 -m ssy --max-iterations 5      # Up to 5 convergence passes
  py -3 -m ssy --root /path/to/project # Target a different project
  py -3 -m ssy --config /path/ssy.yaml # Use an explicit project config
""",
    )
    parser.add_argument(
        "--version", action="version",
        version=f"DeZ SSY {VERSION} '{CODENAME}' ({RELEASE_DATE})",
    )
    parser.add_argument(
        "--yes", "-y", action="store_true",
        help="Skip the consent prompt (for CI / scripted use)",
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Analyse only; no file writes or git operations",
    )
    parser.add_argument(
        "--quick", action="store_true",
        help="Skip slow norm agents (Tier 4 orchestrator)",
    )
    parser.add_argument(
        "--max-iterations", type=int, default=None, metavar="N",
        help="Convergence iterations limit (default: from ssy.yaml or 3)",
    )
    parser.add_argument(
        "--severity", default="all", metavar="LEVEL",
        choices=["all", "fail", "warn"],
        help="Filter repairs: all | fail | warn  (default: all)",
    )
    parser.add_argument(
        "--phase", default="all", choices=["discover", "assess", "all"],
        help=(
            "discover = scan only  |  "
            "assess = scan + assess (no repair)  |  "
            "all = full interactive cycle (default)"
        ),
    )
    parser.add_argument(
        "--verbose", action="store_true",
        help="Verbose sub-step output",
    )
    parser.add_argument(
        "--config", metavar="PATH", default=None,
        help="Path to ssy.yaml  (skips auto-discovery)",
    )
    parser.add_argument(
        "--root", metavar="DIR", default=None,
        help="Project root directory  (default: cwd or ssy.yaml parent)",
    )
    parser.add_argument(
        "--list-artifacts", action="store_true",
        help="List all files SSY has written to this project, then exit",
    )
    return parser


# ── Setup / phase helpers (keep main() CC low) ───────────────────────────────

def _show_list_artifacts(engine: SustainabilityEngine, root: Path) -> None:
    """Print every file SSY has written to this project, grouped by category."""
    groups = engine.list_artifacts()

    _LABELS = {
        "config":  ("Config", "keep if you want to re-run SSY with the same settings"),
        "reports": ("Reports", "safe to delete — regenerated on every run"),
        "exports": ("Exports", "safe to delete — regenerated on every run"),
        "repair":  ("Repair outputs", "review before deleting — may contain your work"),
        "tagged":  ("Tagged artifacts", "created by SSY repair handlers — review before deleting"),
    }

    print()
    print("  DeZ SSY Artifact Inventory")
    print(f"  Root: {root}")
    print()

    if not groups:
        print("  No SSY-created artifacts found in this project.")
        print()
        return

    total = sum(len(v) for v in groups.values())
    total_bytes = 0

    for key in ("config", "reports", "exports", "repair", "tagged"):
        paths = groups.get(key)
        if not paths:
            continue
        label, note = _LABELS[key]
        print(f"  {label} ({len(paths)} file{'s' if len(paths) != 1 else ''} — {note})")
        for p in paths:
            try:
                size = p.stat().st_size
                total_bytes += size
                size_str = f"{size/1024:.1f} kB" if size >= 1024 else f"{size} B"
            except OSError:
                size_str = "?"
            try:
                rel = p.relative_to(root)
            except ValueError:
                rel = p
            print(f"    {rel}  ({size_str})")
        print()

    print(f"  Total: {total} file{'s' if total != 1 else ''}, {total_bytes/1024:.1f} kB")
    print()
    print("  To remove DeZ SSY from this machine:")
    print("    pip uninstall dez-ssy")
    print("    # pyyaml (dependency) is NOT auto-removed — to also remove it:")
    print("    #   pip uninstall pyyaml")
    print()
    print("  The files listed above are NOT removed by pip uninstall.")
    print("  Delete them manually if you no longer need them.")
    print()


def _check_consent(args: Any, root: Path, project_name: str) -> bool:
    if args.yes or args.dry_run:
        return True
    return _consent(root, project_name)


def _load_config(args: Any):
    cfg, discovered = load_config_or_discover(
        config_path=Path(args.config) if args.config else None,
        root=Path(args.root) if args.root else None,
    )
    if args.max_iterations is not None:
        cfg.max_iterations = args.max_iterations
    return cfg, discovered

def _phase_discover(engine: SustainabilityEngine, root: Path, args: Any) -> None:
    print("[1/3  DISCOVER]")
    sys.stdout.write("  Scanning workspace ...")
    sys.stdout.flush()
    profile = engine.discover(verbose=False)
    _clr()
    print("  Workspace scan complete.")
    print(f"    {profile.as_summary()}")
    if profile.languages:
        print(f"    Languages : {', '.join(profile.languages[:5])}")
    if profile.req_dirs:
        print(f"    Reqs      : {profile.req_format} in "
              f"{', '.join(str(d.relative_to(root)) for d in profile.req_dirs[:3])}")
    if profile.test_dirs:
        print(f"    Tests     : {profile.test_framework} in "
              f"{', '.join(str(d.relative_to(root)) for d in profile.test_dirs[:3])}")
    if profile.violations:
        print(f"    Pre-scan  : {len(profile.violations)} violation(s) detected")


def _phase_assess(engine: SustainabilityEngine, args: Any) -> list[Finding]:
    tiers_total = 5 if not args.quick else 4
    print(f"\n[2/3  ASSESS]")
    _progress(0, tiers_total, "Initialising ...")
    findings = engine.assess(
        full=not args.quick,
        verbose=False,
        on_step=lambda step, total, label: _progress(step, total, label),
    )
    _progress_done("Assessment complete")
    engine._print_vitals(findings, "Findings by V-cycle layer")
    _findings_table(findings)
    return findings


def _run_verify_and_print(engine: SustainabilityEngine, results: list[RepairResult]) -> None:
    if not any(r.applied for r in results):
        return
    print(_hr("-"))
    print("  VERIFY")
    for check, status in engine.verify(results).items():
        icon = "+" if status == "PASS" else ("~" if status == "WARN" else "!")
        print(f"  [{icon}] {check:<28}  {status}")
    print()


def _build_repair_state(findings: list[Finding], results: list[RepairResult]):
    from .finding import IterationState
    return IterationState(
        iteration=1,
        findings_total=len(findings),
        fail_count=sum(1 for f in findings if f.is_fail),
        warn_count=sum(1 for f in findings if f.is_warn and not f.is_fail),
        repairs_applied=sum(1 for r in results if r.applied),
        repairs_skipped=sum(1 for r in results if not r.applied),
    )


def _phase_repair_and_finalize(
    engine: SustainabilityEngine, findings: list[Finding], root: Path, args: Any,
) -> int:
    if args.dry_run:
        print("  DRY-RUN — analysis only. No changes will be made.")
        print("  Run without --dry-run to apply repairs.")
        return 0

    mode = _repair_menu(findings)
    if mode == "abort":
        print()
        print("  Aborted — analysis report saved; no changes made.")
        engine.write_report([], dry_run=True)
        return 0

    print(f"\n[3/3  REPAIR]")
    results = _run_repair(engine, mode, findings, args.dry_run, args.severity)
    _run_verify_and_print(engine, results)
    _repair_summary(findings, results)
    _library_report(findings, results)

    state = _build_repair_state(findings, results)
    report_path = engine.write_report([state], dry_run=args.dry_run)
    print(f"  Report   : {report_path.relative_to(root) if report_path else 'not written'}")
    print()
    print(_hr())

    applied_keys = {r.key for r in results if r.applied}
    fail_remaining = sum(1 for f in findings if f.is_fail and f.repair_key not in applied_keys)
    return 1 if fail_remaining > 0 else 0


# ── Main entry point ──────────────────────────────────────────────────────────

def main(argv: list[str] | None = None) -> None:
    parser = build_parser()
    args   = parser.parse_args(argv)
    _banner()

    cfg, was_discovered = _load_config(args)
    root = cfg.paths.root

    print(f"\n  Project  : {cfg.project_name}")
    print(f"  Location : {root}")
    print(f"  Mode     : {'DRY-RUN (no writes)' if args.dry_run else 'LIVE'}")
    if was_discovered:
        print(f"  Config   : auto-generated (review ssy.yaml before committing)")
    print()

    engine = SustainabilityEngine(cfg)

    if args.list_artifacts:
        _show_list_artifacts(engine, root)
        sys.exit(0)

    if not _check_consent(args, root, cfg.project_name):
        print("  Aborted — no changes made.")
        sys.exit(0)

    _phase_discover(engine, root, args)
    if args.phase == "discover":
        if was_discovered:
            print("\n  ssy.yaml written — review and adjust before the full cycle.")
        sys.exit(0)

    findings = _phase_assess(engine, args)
    if args.phase == "assess" or not findings:
        if args.phase == "assess" and findings:
            sys.exit(1 if any(f.is_fail for f in findings) else 0)
        sys.exit(0)

    sys.exit(_phase_repair_and_finalize(engine, findings, root, args))
