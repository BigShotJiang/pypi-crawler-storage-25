"""
ssy.finding — Data structures and classification constants for the DeZ SSY engine.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

# ── Severity → urgency rank (lower = more urgent) ────────────────────────────
SEV_RANK: dict[str, int] = {
    "fail": 0, "error": 0, "critical": 0,
    "high": 1, "warn": 1, "warning": 1,
    "medium": 2, "info": 2, "low": 3,
}

# ── Repair handler execution order (lower = runs first) ──────────────────────
REPAIR_ORDER: dict[str, int] = {
    "coverage_json":     10,
    "test_plan":         20,
    "qualification_run": 25,
    "aspice_wp":         30,
    "sbom":              35,
    "iso27001_soa":      36,
    "iso21434_goals":    37,
    "stub_test_case":    40,
    "unverified_req":    50,
    "trace_links":       60,
    "baseline_tag":      70,
    "consultation":      85,
    "forge_ticket":      90,
}

# ── V-cycle level ordering (bottom-up repair) ─────────────────────────────────
LEVEL_ORDER: dict[str, int] = {
    "component": 0, "software": 1, "system": 2, "cross": 1,
}

# ── Rule-ID prefix → V-cycle level ───────────────────────────────────────────
RULE_LEVEL: dict[str, str] = {
    "SWE.4":    "component",  "SWE4":     "component",
    "METRIC":   "component",  "R.14":     "component",   "R.17":    "component",
    "MISRA":    "component",  "IEC62304": "component",
    "SWE.5":    "software",   "SWE5":     "software",
    "SWE.1":    "software",   "SWE.2":    "software",   "SWE.3":   "software",
    "TRACE":    "software",   "ISTQB":    "software",
    "SWE.6":    "system",     "SWE6":     "system",
    "SYS.":     "system",     "GATE":     "system",
    "CRA":      "system",     "ISO27001": "system",
    "ISO21434": "system",     "IEC62443": "system",
    "ISO26262": "component",  "DO178C":   "component",
    "GDPR":     "software",   "DSGVO":    "software",
    "EU-AI-Act": "system",
}

# ── Agent-ID prefix → normalised domain label ─────────────────────────────────
AGENT_DOMAIN: dict[str, str] = {
    "ASPICE":    "ASPICE",    "MISRA":     "MISRA",
    "IEC-62304": "IEC62304",  "IEC62304":  "IEC62304",
    "ISO-26262": "ISO26262",  "ISO26262":  "ISO26262",
    "DO-178C":   "DO178C",    "DO178C":    "DO178C",
    "ISTQB":     "ISTQB",     "IEC-62443": "IEC62443",
    "CRA":       "CRA",       "ISO-27001": "ISO27001",
    "ISO-21434": "ISO21434",  "ISO21434":  "ISO21434",
    "SOTIF":     "SOTIF",     "AUTOSAR":   "AUTOSAR",
    "GDPR":      "GDPR",      "ISO-45001": "ISO45001",
    "DSGVO":     "DSGVO",     "EU-AI-Act": "EU_AI_ACT",
    "EU-AI-ACT": "EU_AI_ACT",
    "reqvault":  "REQVAULT",  "trace-val": "TRACE",
    "direct-sc": "DIRECT",
}

# ── Domain → stages it is responsible for ─────────────────────────────────────
DOMAIN_STAGES: dict[str, list[str]] = {
    "ASPICE":   ["SWE.4", "SWE.5", "SWE.6"],
    "MISRA":    ["SWE.4", "SWE.5"],
    "IEC62304": ["SWE.4", "SWE.5", "SWE.6"],
    "ISO26262": ["SWE.4", "SWE.5", "SWE.6"],
    "DO178C":   ["SWE.4", "SWE.5", "SWE.6"],
    "ISTQB":    ["SWE.4", "SWE.5", "SWE.6"],
    "IEC62443": ["SWE.4", "SWE.5"],
    "CRA":      ["SWE.4", "SWE.5", "SWE.6"],
    "ISO27001":  ["SWE.6"],
    "ISO21434":  ["SWE.6"],
    "DSGVO":     ["SWE.1", "SWE.2", "SWE.3", "SWE.4", "SUP.1"],
    "EU_AI_ACT": ["SWE.1", "SWE.2", "SWE.3", "SWE.4", "SWE.6", "SUP.1"],
}

# ── Neighboring domains for boundary-gap consultation ─────────────────────────
DOMAIN_NEIGHBORS: dict[str, list[str]] = {
    "MISRA":    ["ASPICE", "IEC62304", "ISO26262", "DO178C"],
    "IEC62304": ["ASPICE", "MISRA",    "ISO26262", "ISTQB"],
    "ASPICE":   ["IEC62304", "MISRA",  "ISTQB",    "ISO26262"],
    "ISO26262": ["ASPICE",   "MISRA",  "IEC62304", "DO178C"],
    "DO178C":   ["ASPICE",   "MISRA",  "IEC62304", "ISO26262"],
    "ISTQB":    ["ASPICE",   "IEC62304", "ISO26262"],
    "CRA":      ["IEC62304", "ISO27001", "IEC62443"],
    "ISO27001": ["CRA",      "IEC62443", "ASPICE"],
    "ISO21434": ["ASPICE",   "ISO26262", "CRA"],
    "IEC62443":  ["CRA",      "ISO27001", "IEC62304"],
    "DSGVO":     ["GDPR",     "CRA",      "ISO27001"],
    "EU_AI_ACT": ["ISO27001", "CRA",      "IEC62443", "SOTIF"],
}


@dataclass
class Finding:
    agent:      str
    rule_id:    str
    severity:   str       # "fail" | "warn" | "info"
    target:     str
    message:    str
    repair_key: str
    meta:       dict = field(default_factory=dict)

    @property
    def rank(self) -> int:
        return SEV_RANK.get(self.severity.lower(), 3)

    @property
    def is_fail(self) -> bool:
        return self.rank == 0

    @property
    def is_warn(self) -> bool:
        return self.rank <= 1

    @property
    def level(self) -> str:
        rid = self.rule_id.upper()
        agent = self.agent.upper()
        for prefix, lvl in RULE_LEVEL.items():
            if rid.startswith(prefix.upper()) or prefix.upper() in rid:
                return lvl
        for prefix, lvl in RULE_LEVEL.items():
            if agent.startswith(prefix.upper()):
                return lvl
        return "software"

    @property
    def domain(self) -> str:
        agent = self.agent.upper()
        for prefix, dom in AGENT_DOMAIN.items():
            if agent.startswith(prefix.upper()):
                return dom
        return self.agent


@dataclass
class RepairResult:
    key:         str
    applied:     bool
    dry_run:     bool
    description: str
    error:       str = ""


@dataclass
class IterationState:
    iteration:       int
    findings_total:  int
    fail_count:      int
    warn_count:      int
    repairs_applied: int
    repairs_skipped: int
