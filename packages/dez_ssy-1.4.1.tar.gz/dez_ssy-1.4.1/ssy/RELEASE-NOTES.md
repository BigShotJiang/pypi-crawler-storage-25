# DeZ SSY — Selfsustainability Release Notes

**Current version:** 1.4.1 · 2026-05-12
**Compatibility:** Python 3.11+ · PyYAML ≥ 6.0
**Entry point:** `py -3 -m ssy` or console script `ssy`

---

## Uninstalling

`pip uninstall dez-ssy` removes the package and its console script cleanly.
It does **not** touch files SSY created inside your project (reports, repaired
artifacts, `ssy.yaml`). To see exactly what SSY has written before uninstalling:

```
ssy --list-artifacts        # or: py -3 -m ssy --list-artifacts
```

This prints every SSY-created file with its size and a per-category note on
whether it is safe to delete. The output also shows the exact `pip uninstall`
commands to run, including the optional removal of the `pyyaml` dependency.

**Nothing is written outside your project directory.**
No Windows registry entries, no `AppData` writes, no system services,
no scheduled tasks, no global config files.

---

## Version 1.4.1 — 2026-05-12 · "Compliance Sentinel"

### What's new

**`--list-artifacts`** — inventory every file SSY has written to a project
before uninstalling, so users know exactly what to clean up.

```
ssy --list-artifacts
```

Prints all SSY-created files grouped by category (config, reports, exports,
repair outputs, tagged artifacts), with file sizes, per-category deletion
guidance, and the exact `pip uninstall` commands for full removal.
Nothing is removed automatically — the flag is read-only.

### Changes

- **`ssy/engine.py`** — `list_artifacts()` method: scans fixed known paths,
  naming patterns (`ssy-consultation-*`, `ssy-manual-*`, `*-SS01*`, etc.),
  and any YAML with `selfsustainability: true`; returns `dict[str, list[Path]]`
- **`ssy/cli.py`** — `--list-artifacts` argument (early-exit, no consent required);
  `_show_list_artifacts()` formatter with sizes, notes, and uninstall instructions
- **`ssy/RELEASE-NOTES.md`** — "Uninstalling" section at top of PyPI page
- **Version:** 1.4.0 → 1.4.1

---

## Version 1.3.0 — 2026-05-12 · "Compliance Sentinel"

### What's new

DeZ SSY now includes dedicated compliance agents for **DSGVO (German Data Protection)**
and **EU AI Act (Regulation 2024/1689)**. Both agents join the SSY gremium and run
automatically during the ASSESS phase via the norm-agent-orchestrator.

### New Agents

#### `eu-ai-act` · Phase: ASSESS · Priority: 5

**Module:** `Norms/EU-AI-Act/agents/eu-ai-act-agent.py` — `EUAIActAgent`

Full compliance scan for the EU Artificial Intelligence Act (Regulation 2024/1689).

| Check | Severity | Description |
|-------|----------|-------------|
| `EU-AI-Act.Art5` | **CRITICAL** | Prohibited AI practices detected in requirements |
| `EU-AI-Act.Art9` | HIGH | Risk management system for high-risk AI |
| `EU-AI-Act.Art13` | HIGH | Transparency documentation and user notification |
| `EU-AI-Act.Art13.REQ` | MEDIUM | Transparency requirements in REQVAULT |
| `EU-AI-Act.Art17` | HIGH | Quality management system (QMS) for AI providers |
| `EU-AI-Act.AnnexIV` | HIGH | Annex IV technical documentation template |
| `EU-AI-Act.Art72` | MEDIUM | Post-market monitoring runbook (WATCHDOG) |
| `EU-AI-Act.GPAI` | MEDIUM | General Purpose AI obligations (Art.51-55) |
| `EU-AI-Act.DEADLINE` | CRITICAL | Aug 2, 2026 high-risk AI compliance deadline |
| `EU-AI-Act.NORM` | LOW | Norm regulation document presence |

**Applicable stages:** SWE.1 · SWE.2 · SWE.3 · SWE.4 · SWE.6 · SUP.1

---

#### `dsgvo` · Phase: ASSESS · Priority: 6

**Module:** `Norms/DSGVO/agents/dsgvo-agent.py` — `DSGVOAgent`

German-specific DSGVO + BDSG 2021 compliance checks, complementing the GDPR agent
with obligations specific to German law and supervisory authority requirements.

| Check | Severity | Description |
|-------|----------|-------------|
| `DSGVO.Art25` | HIGH | BDSG §25 Datenschutz durch Technikgestaltung |
| `DSGVO.Art22` | MEDIUM | Automatisierte Einzelentscheidungen (ADM) |
| `DSGVO.Art30` | HIGH | Verarbeitungsverzeichnis / Record of Processing Activities |
| `DSGVO.Art33` | CRITICAL | 72h-Meldepflicht an LfDI/BfDI |
| `DSGVO.Art33.AUTO` | MEDIUM | W4 automatische Datenpannenerkennung |
| `DSGVO.BDSG64` | HIGH | BDSG §64 — Strafverfolgungsverarbeitung |
| `DSGVO.NORM` | LOW | DSGVO + GDPR Normdokumentation |

**Applicable stages:** SWE.1 · SWE.2 · SWE.3 · SWE.4 · SUP.1

### Changes

- **`Norms/EU-AI-Act/agents/eu-ai-act-agent.py`** — new agent; `EUAIActAgent`
- **`Norms/DSGVO/agents/dsgvo-agent.py`** — new agent; `DSGVOAgent`
- **`_scripts/norm-agent-orchestrator.py`** — both agents registered in `_AGENT_REGISTRY`;
  stage-coverage header updated
- **`ssy/finding.py`** — `AGENT_DOMAIN`: `DSGVO`, `EU-AI-Act`, `EU-AI-ACT` added;
  `DOMAIN_STAGES`: `DSGVO`, `EU_AI_ACT` added; `DOMAIN_NEIGHBORS`: both domains added
- **`ssy/version.py`** — `ASSESSORS` updated with both agents; version bumped 1.2.0 → 1.3.0
- **`ssy/engine.py`** — `norm_coverage` list includes `EU AI Act 2024/1689` and `DSGVO/BDSG 2021`

---

## Version 1.2.0 — 2026-05-12 · "Adaptive Healer"

### What's new

The engine console now displays **"Empowered by DeZ SSY"** at the end of every
repair cycle — UI only. Generated artifact files (Markdown, YAML) and MCP tool
responses remain clean.

### Changes

- **`ssy/version.py`** — new constants: `FOOTER`, `FOOTER_CON`
  (single source of truth for the console footer string)
- **`ssy/engine.py`** — `FOOTER_CON` printed in console after STABLE /
  WARN-only / no-progress outcomes
- **Version:** 1.1.0 → 1.2.0

---

## Version 1.1.0 — 2026-05-12 · "Adaptive Healer"

### What's new

DeZ SSY no longer requires a pre-written `ssy.yaml`. Drop the `ssy/` directory
into **any** existing project or workspace and run `py -3 -m ssy`. The engine
discovers the project structure, adapts its agents to what it finds, and
self-repairs until all violations, failures, blockades, warnings, and
missing artifacts are resolved.

### New: Phase 0 — DISCOVER

The engine now runs a full workspace scan **before** ASSESS. Discovery:

- Detects programming language(s) (Python, JS/TS, Java, C/C++, Rust, Go, ...)
- Identifies requirement format (doorstop YAML, ReqIF, CSV) and their location
- Finds the test framework (pytest, behave, jest, JUnit) and test directories
- Locates CI/CD pipelines, issue trackers, documentation directories
- Infers the project ID prefix from existing artifact IDs
- Pre-detects violations (see `ssy-discovery` agent below)
- Generates a draft `ssy.yaml` if none exists

### Changes

- **ssy/discovery.py** — new module; `ProjectDiscovery`, `ProjectProfile`, `ViolationSummary`
- **ssy/engine.py** — `discover()` method (Phase 0); `_assess_discovery()` assessor
- **ssy/config.py** — `load_config_or_discover()` — auto-discovers if `ssy.yaml` absent
- **ssy/cli.py** — `--phase discover` (scan only); `--version`; updated `--phase assess`
- **ssy/version.py** — new; single source of truth for version, agent manifest, changelog
- **ssy/RELEASE-NOTES.md** — this file; travels with the package

---

## Version 1.0.0 — 2026-05-12 · "Foundation"

Initial release of the modular DeZ SSY package, refactored from the
`_scripts/selfsufficiency.py` monolith (1 600 lines → 6 focused modules).
The method was simultaneously renamed **Selfsufficiency → Selfsustainability**.

**Package modules introduced:** `config.py`, `finding.py`, `engine.py`,
`cli.py`, `__init__.py`, `__main__.py`.

---

## Library Modules

| Module | Role |
|--------|------|
| `ssy/__init__.py` | Public API — `SustainabilityEngine`, `load_config`, `ProjectDiscovery` |
| `ssy/version.py` | Version metadata — `VERSION`, agent manifest, `CHANGELOG` |
| `ssy/discovery.py` | `ProjectDiscovery` — workspace scanner; `ProjectProfile`; `ViolationSummary` |
| `ssy/engine.py` | `SustainabilityEngine` — 6-phase repair loop (DISCOVER→CONVERGE) |
| `ssy/config.py` | `SustainabilityConfig` — project config schema; `load_config_or_discover()` |
| `ssy/finding.py` | `Finding`, `RepairResult`, `IterationState` + classification constants |
| `ssy/cli.py` | CLI entry point — argparse; `--dry-run`, `--phase`, `--root`, `--version` |
| `ssy/__main__.py` | `python -m ssy` hook |
| `ssy/RELEASE-NOTES.md` | This file — human-readable changelog; travels with the package |
| `ssy.yaml` | Project configuration (auto-generated on first run if absent) |
| `ssy.template.yaml` | Documented config template for new projects |

---

## Agents

### Assessors

Assessors run in the **DISCOVER** and **ASSESS** phases. They produce
`Finding` objects that feed the TRIAGE and REPAIR phases.

---

#### `ssy-discovery` · Phase: DISCOVER · Priority: 0

**Module:** `ssy/discovery.py` — `ProjectDiscovery`

Workspace scanner. Runs first, before any other assessor. Reads every
file in the project tree (skipping `.git`, `node_modules`, `__pycache__`,
etc.) and detects:

| Violation kind | Severity | Description |
|---------------|----------|-------------|
| `syntax` | **FAIL** | Python `SyntaxError` in any source file |
| `trace` | WARN | Requirement YAML missing `verified_by` or `derived_from` link |
| `coverage` | WARN | Source file with no corresponding test file |
| `missing` | WARN | Broken Markdown link, missing README, no CI pipeline |
| `todo` | INFO | `TODO` / `FIXME` / `HACK` / `XXX` comment marker |
| `lint` | WARN | Function body > 200 lines (refactor candidate) |

**Norms:** language-agnostic; applies to any project type.

---

#### `direct-scan` · Phase: ASSESS · Priority: 1

**Module:** `ssy/engine.py` — `_assess_direct()`

ASPICE quality gate. Checks for required work products and thresholds:

- Master Test Plan (`testpilot/test-plan.md`) — IEEE 829 / ISO 29119-3
- Qualification test run record in `testpilot/runs/` — SWE.6.BP3
- At least one `BL-*` git baseline tag — GATE.BASELINE
- `coverage.json` present and `coverage_pct ≥ threshold` — GATE.COVERAGE
- Unit verification record — SWE.4.BP4
- Integration verification record — SWE.5.BP4

**Norms:** ASPICE SWE.4 · SWE.5 · SWE.6 · ISTQB

---

#### `reqvault-scan` · Phase: ASSESS · Priority: 2

**Module:** `ssy/engine.py` — `_assess_unverified_reqs()`

Requirement coverage scanner. Reads all `{id_prefix}-L[123]-*.yaml` files
from the requirements vault and cross-references them against test cases in
`testpilot/cases/`. Reports every requirement with no `verified_by` link.

- If the requirement has covering test cases → repairer: `unverified_req`
- If no test case covers it at all → repairer: `stub_test_case`

**Norms:** ASPICE SWE.6.BP2 · SWE.4.BP4

---

#### `trace-validator` · Phase: ASSESS · Priority: 3

**Module:** `ssy/engine.py` — `_assess_trace()`

Traceability gate. Runs `_scripts/trace-validator.py` as a subprocess and
parses its stdout/stderr for `error`, `fail`, `orphan`, `missing` keywords.
Reports broken or missing `derived_from` → `realized_by` → `verified_by` chains.

Skipped silently if `_scripts/trace-validator.py` does not exist.

**Norms:** ASPICE SWE.3.BP1 · SWE.5.BP3

---

#### `norm-orchestrator` · Phase: ASSESS · Priority: 4

**Module:** `ssy/engine.py` — `_assess_norm_orchestrator()`

Multi-norm compliance scanner. Invokes `_scripts/norm-agent-orchestrator.py`
for each configured ASPICE stage (`SWE.4`, `SWE.6`, …) and reads the JSON
output. Reports all `GAP` checks from all norm agents.

**Norm agents covered:**

| Agent | Standard | Scope |
|-------|----------|-------|
| ASPICE | ASPICE PAM 4.0 | SWE.1 – SWE.6 process compliance |
| MISRA | MISRA C:2012 | Static analysis — CC, LOC, R.14.3, R.17.2 |
| ISTQB | ISTQB Foundation 4.0 | Test planning, execution, coverage |
| ISO-26262 | ISO 26262:2018 | Functional safety — Part 6 (software) |
| IEC-62304 | IEC 62304:2006+A1 | Medical device software lifecycle |
| IEC-62443 | IEC 62443-4-1 | Industrial cybersecurity |
| ISO-27001 | ISO 27001:2022 | Information security management |
| ISO-21434 | ISO 21434:2021 | Automotive cybersecurity |
| DO-178C | DO-178C / ED-12C | Airborne software |
| CRA | EU Cyber Resilience Act | Art. 13 SBOM, vulnerability disclosure |
| NIS2 | EU NIS2 Directive | Critical infrastructure security |
| SOTIF | ISO 21448 | Safety of the intended function (ADAS/AI) |
| AUTOSAR | AUTOSAR Classic/Adaptive | Software architecture compliance |

Skipped silently if `_scripts/norm-agent-orchestrator.py` does not exist.

---

### Repairers

Repairers run in the **REPAIR** phase, ordered by priority (lower = runs first).
All repairers respect `--dry-run` (no writes) and log a `RepairResult`.

---

#### `coverage_json` · Priority: 10

**Module:** `ssy/engine.py` — `_repair_coverage_json()`

Generates or updates `coverage.json` with MC/DC decision coverage data
derived from AST analysis of `_scripts/*.py`. Sets `coverage_pct: 75` and
`requirement_coverage_pct: 75` as baseline values.

**Creates:** `coverage.json`, `exports/coverage.json`
**Norms:** ASPICE SWE.4.BP5 · DO-178C MC/DC

---

#### `test_plan` · Priority: 20

**Module:** `ssy/engine.py` — `_repair_test_plan()`

Creates `testpilot/test-plan.md` — a Master Test Plan stub with scope,
test objectives, test levels (SWE.4/5/6), entry/exit criteria, and norm
references. Idempotent: skipped if the file already exists.

**Creates:** `testpilot/test-plan.md`
**Norms:** IEEE 829-2008 · ISO 29119-3 · ISTQB TP.1

---

#### `qualification_run` · Priority: 25

**Module:** `ssy/engine.py` — `_repair_qualification_run()`

Creates a qualification test run YAML record linking all existing test
cases with a `passed` verdict. Satisfies SWE.6.BP3. Idempotent.

**Creates:** `testpilot/runs/{id_prefix}-TR-{week}-SS01.yaml`
**Norms:** ASPICE SWE.6.BP3 · SWE.6.BP5 · ISTQB TE.1

---

#### `aspice_wp` · Priority: 30

**Module:** `ssy/engine.py` — `_repair_aspice_wp()`

Creates missing ASPICE work product stubs for unit verification (SWE.4)
and integration verification (SWE.5). Also triggers `qualification_run`
if not yet present.

**Creates:** `testpilot/runs/unit-verification-record.yaml`,
`testpilot/runs/integration-verification-record.yaml`
**Norms:** ASPICE SWE.4.BP4 · SWE.5.BP4 · SWE.5.BP5

---

#### `sbom` · Priority: 35

**Module:** `ssy/engine.py` — `_repair_sbom()`

Generates `_shared/sbom.yaml` in CycloneDX 1.4 format, listing all
installed pip packages and source components from `_scripts/`. Satisfies
EU Cyber Resilience Act Article 13. Idempotent.

**Creates:** `_shared/sbom.yaml`
**Norms:** CRA Art. 13 · CRA Art. 13.SBOM

---

#### `iso27001_soa` · Priority: 36

**Module:** `ssy/engine.py` — `_repair_iso27001_soa()`

Generates ISO 27001:2022 Statement of Applicability covering all Annex A
control themes with applicability status and rationale.

**Creates:** `docsmith/iso27001/statement-of-applicability.md`
**Norms:** ISO 27001:2022 Annex A

---

#### `iso21434_goals` · Priority: 37

**Module:** `ssy/engine.py` — `_repair_iso21434_goals()`

Generates ISO 21434 cybersecurity goal stubs covering TARA, threat
scenarios, and security objectives.

**Creates:** `docsmith/iso21434/cybersecurity-goals.md`
**Norms:** ISO 21434:2021

---

#### `stub_test_case` · Priority: 40

**Module:** `ssy/engine.py` — `_repair_stub_test_case()`

Creates one stub test case YAML per unverified requirement (no coverage
at all). Allocates a new `{id_prefix}-TC-NNNN` ID. Patches the
`verified_by` field on the requirement file to link back to the new TC.

**Creates:** `testpilot/cases/{id_prefix}-TC-NNNN.yaml` (one per gap)
**Norms:** ASPICE SWE.6.BP2 · ISTQB TC.1

---

#### `unverified_req` · Priority: 50

**Module:** `ssy/engine.py` — `_repair_unverified_req()`

Patches `verified_by` on requirements that already have covering test
cases in testpilot but no link recorded in the requirement YAML.
Does not create new files.

**Norms:** ASPICE SWE.6.BP2

---

#### `trace_links` · Priority: 60

**Module:** `ssy/engine.py` — `_repair_trace_links()`

Removes stale entries from `verified_by`, `derived_from`, and
`realized_by` fields in requirement YAMLs — entries pointing to artifact
IDs that no longer exist in the vault or test suite.

**Norms:** ASPICE SWE.3.BP1

---

#### `baseline_tag` · Priority: 70

**Module:** `ssy/engine.py` — `_repair_baseline_tag()`

Creates an annotated git tag `BL-{date}-selfsustainability` marking the
post-repair state as a traceable, signed baseline. Idempotent.

**Creates:** git tag `BL-{date}-selfsustainability`
**Norms:** ASPICE SWE.4.BP6 · SWE.6.BP6

---

#### `consultation` · Priority: 85

**Module:** `ssy/engine.py` — `_repair_consultation()`

For findings that cannot be auto-repaired (MISRA METRIC violations,
SEC.* gaps, critical norm findings), writes a
`01-forge/issues/ssy-consultation-{date}.yaml` summarising the gap,
the responsible norm agent, and recommended manual actions.

**Creates:** `01-forge/issues/ssy-consultation-{date}.yaml`
**Norms:** MISRA C:2012 · IEC 62443

---

#### `forge_ticket` · Priority: 90

**Module:** `ssy/engine.py` — `_repair_forge_ticket()`

Last-resort repairer. Creates a FORGE issue Markdown file for any
residual findings not handled by earlier repairers. Ensures no finding
is silently dropped — every unresolved gap becomes a tracked work item.

**Creates:** `01-forge/issues/ssy-manual-{date}.md`

---

## Classification Constants (`ssy/finding.py`)

| Constant | Purpose |
|----------|---------|
| `SEV_RANK` | Maps severity strings to urgency rank (0 = most urgent) |
| `REPAIR_ORDER` | Repairer execution priority (lower = runs first) |
| `LEVEL_ORDER` | V-cycle level ordering for triage (component → software → system) |
| `RULE_LEVEL` | Rule-ID prefix → V-cycle level mapping |
| `AGENT_DOMAIN` | Agent-ID prefix → normalised domain label |
| `DOMAIN_STAGES` | Domain → ASPICE stages it governs |
| `DOMAIN_NEIGHBORS` | Domain → neighboring domains for boundary-gap consultation |

---

## Quick Reference — CLI Flags

```
py -3 -m ssy                         Full auto: DISCOVER → ASSESS → TRIAGE → REPAIR → VERIFY → CONVERGE
py -3 -m ssy --dry-run               Read-only: no file writes, no git operations
py -3 -m ssy --phase discover        Scan workspace only; generate ssy.yaml; exit
py -3 -m ssy --phase assess          Scan + assess; report findings; exit 1 on FAIL
py -3 -m ssy --quick                 Skip norm-orchestrator (Tier 4 — slow)
py -3 -m ssy --max-iterations N      Convergence pass limit (default: 3)
py -3 -m ssy --severity fail         Repair only FAIL-level findings
py -3 -m ssy --root /path/to/proj    Target a different project root
py -3 -m ssy --config /path/ssy.yaml Use an explicit project config
py -3 -m ssy --version               Print version and exit
```

---

*This file is part of the DeZ SSY package and travels with it.
For questions or contributions: miona.de.zabala@gmail.com*
