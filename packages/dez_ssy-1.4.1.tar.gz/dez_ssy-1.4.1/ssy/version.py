"""
ssy.version — Single source of truth for DeZ SSY version metadata.

Import from here for programmatic access:

    from ssy.version import VERSION, VERSION_INFO, CHANGELOG
"""
from __future__ import annotations

# ── Canonical version ─────────────────────────────────────────────────────────

VERSION      = "1.4.1"
VERSION_INFO = (1, 4, 1)        # (major, minor, patch)
RELEASE_DATE = "2026-05-12"
CODENAME     = "Compliance Sentinel"

# ── Footer — canonical brand tagline ─────────────────────────────────────────
# Rendered in: all generated Markdown artifacts, MCP tool responses,
# engine console output, and any DeZ tool that inherits DeZ SSY.

FOOTER       = "Empowered by DeZ SSY"
FOOTER_MD    = f"\n\n---\n*{FOOTER}*"           # Markdown inline
FOOTER_YAML  = FOOTER                           # value for powered_by: field
FOOTER_CON   = f"  >>  {FOOTER}"               # console banner suffix

# ── Library manifest ──────────────────────────────────────────────────────────
# Every module that ships with DeZ SSY, with its role.

MODULES: dict[str, str] = {
    "ssy/__init__.py":        "Public API — exports SustainabilityEngine, load_config, ProjectDiscovery",
    "ssy/version.py":         "Version metadata — single source of truth for VERSION, CHANGELOG",
    "ssy/discovery.py":       "ProjectDiscovery — auto-scan any workspace; ProjectProfile; ViolationSummary",
    "ssy/engine.py":          "SustainabilityEngine — 6-phase DISCOVER→ASSESS→TRIAGE→REPAIR→VERIFY→CONVERGE",
    "ssy/config.py":          "SustainabilityConfig — project config schema; load_config; load_config_or_discover",
    "ssy/finding.py":         "Finding / RepairResult / IterationState — data structures + classification constants",
    "ssy/cli.py":             "CLI entry point — argparse; --dry-run / --phase / --root / --version",
    "ssy/__main__.py":        "python -m ssy hook",
    "ssy/RELEASE-NOTES.md":   "Human-readable changelog — travels with the package",
    "ssy.yaml":               "Project configuration (auto-generated on first run if absent)",
    "ssy.template.yaml":      "Documented config template for new projects",
}

# ── Agent manifest ────────────────────────────────────────────────────────────
# Every assessor and repairer agent, with role, phase, and norm coverage.

ASSESSORS: list[dict] = [
    {
        "id":       "ssy-discovery",
        "phase":    "DISCOVER",
        "module":   "ssy/discovery.py",
        "class":    "ProjectDiscovery",
        "role":     "Workspace scanner — detects languages, req format, test framework, CI; "
                    "finds syntax errors, broken trace links, uncovered source files, "
                    "TODO/FIXME markers, oversized functions, broken doc links, missing README/CI",
        "norms":    [],
        "priority": 0,
    },
    {
        "id":       "direct-scan",
        "phase":    "ASSESS",
        "module":   "ssy/engine.py",
        "method":   "_assess_direct",
        "role":     "ASPICE gate — checks for Master Test Plan, qualification run record, "
                    "BL-* baseline tag, coverage.json presence and threshold compliance",
        "norms":    ["ASPICE-SWE.4", "ASPICE-SWE.5", "ASPICE-SWE.6",
                     "ISTQB-TE.1", "GATE.BASELINE", "GATE.COVERAGE"],
        "priority": 1,
    },
    {
        "id":       "reqvault-scan",
        "phase":    "ASSESS",
        "module":   "ssy/engine.py",
        "method":   "_assess_unverified_reqs",
        "role":     "Requirement coverage — finds L1/L2/L3 requirements without verified_by "
                    "traceability links; maps to stub_test_case or unverified_req repairer",
        "norms":    ["ASPICE-SWE.6.BP2", "ASPICE-SWE.4.BP4"],
        "priority": 2,
    },
    {
        "id":       "trace-validator",
        "phase":    "ASSESS",
        "module":   "ssy/engine.py",
        "method":   "_assess_trace",
        "role":     "Traceability gate — runs _scripts/trace-validator.py; reports orphans, "
                    "broken references, missing derived_from / realized_by chains",
        "norms":    ["ASPICE-SWE.3.BP1", "ASPICE-SWE.5.BP3"],
        "priority": 3,
    },
    {
        "id":       "norm-orchestrator",
        "phase":    "ASSESS",
        "module":   "ssy/engine.py",
        "method":   "_assess_norm_orchestrator",
        "role":     "Multi-norm compliance scanner — invokes external norm agents via "
                    "_scripts/norm-agent-orchestrator.py; collects GAP findings per stage",
        "norms":    ["ASPICE", "MISRA-C:2012", "ISTQB", "ISO-26262", "IEC-62304",
                     "IEC-62443", "ISO-27001", "ISO-21434", "DO-178C",
                     "CRA", "NIS2", "SOTIF", "AUTOSAR",
                     "DSGVO/BDSG-2021", "EU-AI-Act-2024/1689"],
        "priority": 4,
    },
    {
        "id":       "eu-ai-act",
        "phase":    "ASSESS",
        "module":   "Norms/EU-AI-Act/agents/eu-ai-act-agent.py",
        "class":    "EUAIActAgent",
        "role":     "EU AI Act compliance — Art.5 prohibited practices, Art.9 risk management, "
                    "Art.13 transparency, Art.17 QMS, Annex IV technical documentation, "
                    "Art.72 post-market monitoring, GPAI obligations, Aug 2026 deadline",
        "norms":    ["EU-AI-Act-2024/1689"],
        "priority": 5,
    },
    {
        "id":       "dsgvo",
        "phase":    "ASSESS",
        "module":   "Norms/DSGVO/agents/dsgvo-agent.py",
        "class":    "DSGVOAgent",
        "role":     "DSGVO + BDSG 2021 German-specific compliance — BDSG §25 Datenschutz durch "
                    "Technikgestaltung, Art.22 automatisierte Entscheidungen, Art.30 RoPA/Verarbeitungsverzeichnis, "
                    "Art.33 72h-Meldepflicht, BDSG §64 Strafverfolgungsverarbeitung",
        "norms":    ["DSGVO-2016/679", "BDSG-2021"],
        "priority": 6,
    },
]

REPAIRERS: list[dict] = [
    {
        "id":       "coverage_json",
        "priority": 10,
        "module":   "ssy/engine.py",
        "method":   "_repair_coverage_json",
        "role":     "Generate or update coverage.json with MC/DC decision coverage data "
                    "derived from AST analysis of _scripts/*.py source files",
        "norms":    ["ASPICE-SWE.4.BP5", "DO-178C-MC/DC"],
        "creates":  ["coverage.json"],
    },
    {
        "id":       "test_plan",
        "priority": 20,
        "module":   "ssy/engine.py",
        "method":   "_repair_test_plan",
        "role":     "Create Master Test Plan stub (testpilot/test-plan.md) covering "
                    "SWE.4/SWE.5/SWE.6 entry/exit criteria and norm references",
        "norms":    ["IEEE-829-2008", "ISO-29119-3", "ISTQB-TP.1"],
        "creates":  ["testpilot/test-plan.md"],
    },
    {
        "id":       "qualification_run",
        "priority": 25,
        "module":   "ssy/engine.py",
        "method":   "_repair_qualification_run",
        "role":     "Create qualification test run YAML record (SWE.6.BP3) linking "
                    "all existing test cases with pass verdict and coverage metrics",
        "norms":    ["ASPICE-SWE.6.BP3", "ASPICE-SWE.6.BP5", "ISTQB-TE.1"],
        "creates":  ["testpilot/runs/{id_prefix}-TR-{week}-SS01.yaml"],
    },
    {
        "id":       "aspice_wp",
        "priority": 30,
        "module":   "ssy/engine.py",
        "method":   "_repair_aspice_wp",
        "role":     "Create missing ASPICE work product stubs: unit verification record "
                    "(SWE.4.BP4), integration verification record (SWE.5.BP4)",
        "norms":    ["ASPICE-SWE.4.BP4", "ASPICE-SWE.5.BP4", "ASPICE-SWE.5.BP5"],
        "creates":  ["testpilot/runs/unit-verification-record.yaml",
                     "testpilot/runs/integration-verification-record.yaml"],
    },
    {
        "id":       "sbom",
        "priority": 35,
        "module":   "ssy/engine.py",
        "method":   "_repair_sbom",
        "role":     "Generate CycloneDX 1.4 Software Bill of Materials listing all "
                    "pip packages and source components; satisfies CRA Art. 13",
        "norms":    ["CRA-Art13", "CRA-Art13.SBOM"],
        "creates":  ["_shared/sbom.yaml"],
    },
    {
        "id":       "iso27001_soa",
        "priority": 36,
        "module":   "ssy/engine.py",
        "method":   "_repair_iso27001_soa",
        "role":     "Generate ISO 27001:2022 Statement of Applicability covering all "
                    "Annex A controls with applicability rationale per control theme",
        "norms":    ["ISO-27001:2022-Annex-A"],
        "creates":  ["docsmith/iso27001/statement-of-applicability.md"],
    },
    {
        "id":       "iso21434_goals",
        "priority": 37,
        "module":   "ssy/engine.py",
        "method":   "_repair_iso21434_goals",
        "role":     "Generate ISO 21434 cybersecurity goal stubs covering TARA, "
                    "threat scenarios, and security objectives per work product",
        "norms":    ["ISO-21434:2021"],
        "creates":  ["docsmith/iso21434/cybersecurity-goals.md"],
    },
    {
        "id":       "stub_test_case",
        "priority": 40,
        "module":   "ssy/engine.py",
        "method":   "_repair_stub_test_case",
        "role":     "Create stub test case YAML for each requirement with no coverage; "
                    "patches verified_by on the requirement file",
        "norms":    ["ASPICE-SWE.6.BP2", "ISTQB-TC.1"],
        "creates":  ["testpilot/cases/{id_prefix}-TC-NNNN.yaml"],
    },
    {
        "id":       "unverified_req",
        "priority": 50,
        "module":   "ssy/engine.py",
        "method":   "_repair_unverified_req",
        "role":     "Patch verified_by links on requirements that have covering test "
                    "cases in testpilot but no link recorded in the req YAML",
        "norms":    ["ASPICE-SWE.6.BP2"],
        "creates":  [],
    },
    {
        "id":       "trace_links",
        "priority": 60,
        "module":   "ssy/engine.py",
        "method":   "_repair_trace_links",
        "role":     "Prune broken traceability links from requirement files — removes "
                    "verified_by / derived_from / realized_by entries pointing to "
                    "non-existent artifact IDs",
        "norms":    ["ASPICE-SWE.3.BP1"],
        "creates":  [],
    },
    {
        "id":       "baseline_tag",
        "priority": 70,
        "module":   "ssy/engine.py",
        "method":   "_repair_baseline_tag",
        "role":     "Create annotated git tag BL-{date}-selfsustainability marking "
                    "the post-repair project state as a traceable baseline",
        "norms":    ["ASPICE-SWE.4.BP6", "ASPICE-SWE.6.BP6"],
        "creates":  ["git tag: BL-{date}-selfsustainability"],
    },
    {
        "id":       "consultation",
        "priority": 85,
        "module":   "ssy/engine.py",
        "method":   "_repair_consultation",
        "role":     "Write ssy-consultation-{date}.yaml for findings that cannot be "
                    "auto-repaired (MISRA METRIC, SEC.*, critical norm gaps); "
                    "also creates FORGE issue for human follow-up",
        "norms":    ["MISRA-C:2012", "IEC-62443"],
        "creates":  ["01-forge/issues/ssy-consultation-{date}.yaml"],
    },
    {
        "id":       "forge_ticket",
        "priority": 90,
        "module":   "ssy/engine.py",
        "method":   "_repair_forge_ticket",
        "role":     "Create FORGE issue stubs for any residual findings that could "
                    "not be resolved by earlier repairers; ensures nothing is silently dropped",
        "norms":    [],
        "creates":  ["01-forge/issues/ssy-manual-{date}.md"],
    },
]

# ── Changelog ─────────────────────────────────────────────────────────────────

CHANGELOG: list[dict] = [
    {
        "version": "1.4.1",
        "date":    "2026-05-12",
        "summary": "--list-artifacts flag: inventory every SSY-created file before uninstalling",
        "changes": [
            "ssy/engine.py: list_artifacts() — scans fixed known paths, naming patterns, "
            "and YAML files tagged selfsustainability:true; returns dict[str,list[Path]]",
            "ssy/cli.py: --list-artifacts early-exit flag; _show_list_artifacts() formatter "
            "with file sizes, per-category deletion guidance, pip uninstall instructions",
            "ssy/RELEASE-NOTES.md: 'Uninstalling' section added to top of PyPI page",
            "Version bumped: 1.4.0 -> 1.4.1",
        ],
    },
    {
        "version": "1.4.0",
        "date":    "2026-05-12",
        "summary": "Interactive first-run UX — consent, progress bars, repair menu, library report",
        "changes": [
            "ssy/cli.py: full rewrite — 7-step interactive flow",
            "  Step 1: DOI consent prompt (read before any file is parsed)",
            "  Step 2: DISCOVER with live progress bar",
            "  Step 3: ASSESS with per-agent progress bar",
            "  Step 4: ranked findings table — severity | finding | rule | est. time",
            "  Step 4: benefit block — what each repair handler achieves + time estimate",
            "  Step 5: repair menu — full / selective / step-by-step / abort",
            "  Step 6: repair phase with live progress bar + per-handler output",
            "  Step 7: post-repair summary (repaired / skipped / manual)",
            "  Step 7: detailed library report — which assessors detected, which repairers fixed",
            "New --yes / -y flag: skip consent for CI / scripted use",
            "ssy/engine.py: on_step callback added to assess() and repair() — "
            "callers can render their own progress UI without verbose prints",
            "Version bumped: 1.3.0 → 1.4.0",
        ],
    },
    {
        "version": "1.3.0",
        "date":    "2026-05-12",
        "summary": "'Compliance Sentinel' — DSGVO + EU AI Act agents join the SSY gremium",
        "changes": [
            "New agent: EUAIActAgent (Norms/EU-AI-Act/agents/eu-ai-act-agent.py) — "
            "Art.5 prohibited practices, Art.9 risk management, Art.13 transparency, "
            "Art.17 QMS, Annex IV technical documentation, Art.72 post-market monitoring, "
            "GPAI obligations, Aug 2 2026 high-risk deadline awareness",
            "New agent: DSGVOAgent (Norms/DSGVO/agents/dsgvo-agent.py) — "
            "BDSG §25 Datenschutz durch Technikgestaltung, Art.22 automatisierte Entscheidungen, "
            "Art.30 Verarbeitungsverzeichnis (RoPA), Art.33 72h-Meldepflicht, "
            "BDSG §64 Strafverfolgungsverarbeitung, DSGVO + BDSG Normdokumentation",
            "_scripts/norm-agent-orchestrator.py: both agents registered in _AGENT_REGISTRY; "
            "stage-coverage header updated (SWE.1-SWE.4, SWE.6, SUP.1)",
            "ssy/finding.py: AGENT_DOMAIN += DSGVO, EU-AI-Act, EU-AI-ACT; "
            "DOMAIN_STAGES += DSGVO, EU_AI_ACT; DOMAIN_NEIGHBORS += both domains",
            "ssy/version.py: ASSESSORS updated; version 1.2.0 → 1.3.0; codename 'Compliance Sentinel'",
            "ssy/engine.py: norm_coverage list includes DSGVO/BDSG 2021 + EU AI Act 2024/1689",
            "ssy/RELEASE-NOTES.md: 1.3.0 section with both new agents documented",
        ],
    },
    {
        "version": "1.2.0",
        "date":    "2026-05-12",
        "summary": "'Empowered by DeZ SSY' console footer — displayed at end of every engine run",
        "changes": [
            "version.py: FOOTER, FOOTER_CON constants (single source of truth)",
            "ssy/engine.py: FOOTER_CON printed in console after STABLE / WARN-only / "
            "no-progress outcomes — UI-only, not written into artifact files",
            "Rebranded display name: SSY → DeZ SSY throughout (v1.1.0 relabel)",
            "Version bumped: 1.1.0 → 1.2.0",
        ],
    },
    {
        "version": "1.1.0",
        "date":    "2026-05-12",
        "summary": "DISCOVER phase — DeZ SSY adapts to any project structure",
        "changes": [
            "New module ssy/discovery.py: ProjectDiscovery scans any workspace",
            "Auto-detects languages, requirement format, test framework, CI/CD, ID prefix",
            "Detects violations: syntax errors, broken traces, missing tests, TODOs, "
            "oversized functions, broken doc links, missing README and CI",
            "Engine: Phase 0 DISCOVER runs before ASSESS; _assess_discovery() feeds "
            "pre-detected violations into the finding pipeline",
            "Config: load_config_or_discover() — auto-discovers if no ssy.yaml present; "
            "generates draft ssy.yaml for user review",
            "CLI: --phase discover (scan only); updated --phase assess to include discovery; "
            "loop is now DISCOVER→ASSESS→TRIAGE→REPAIR→VERIFY→CONVERGE",
            "DeZ SSY can now be dropped into any project with zero pre-configuration",
        ],
    },
    {
        "version": "1.0.0",
        "date":    "2026-05-12",
        "summary": "Initial modular DeZ SSY package — renamed from Selfsufficiency to Selfsustainability",
        "changes": [
            "Decomposed 1600-line selfsufficiency.py monolith into ssy/ Python package",
            "ssy/config.py: SustainabilityConfig dataclass + load_config()",
            "ssy/finding.py: Finding, RepairResult, IterationState + classification constants",
            "ssy/engine.py: SustainabilityEngine class — all phases as methods",
            "ssy/cli.py: argparse CLI — same flags as old monolith + --config / --root",
            "Config-driven paths: cfg.paths.* replaces all global ROOT/REQVAULT constants",
            "Configurable id_prefix (DEZ, DCS, etc.) for multi-project use",
            "ssy.yaml: DeZ Enterprise project config",
            "ssy.template.yaml: portable template for other projects",
            "Renamed method: Selfsufficiency → Selfsustainability throughout codebase",
            "Entry points: py -3 -m ssy  and  _scripts/selfsustainability.py",
        ],
    },
]
