"""Entry point for `python -m ssy`."""
from .cli import main

main()
