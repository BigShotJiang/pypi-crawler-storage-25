"""
DeZ SSY — Selfsustainability: drop into any project, auto-discover, self-repair.

Usage (CLI):
    py -3 -m ssy                          # full cycle: discover + heal
    py -3 -m ssy --dry-run                # read-only health check
    py -3 -m ssy --phase discover         # scan only, generate ssy.yaml
    py -3 -m ssy --root /other/project    # target a different project

Usage (API):
    from ssy import load_config_or_discover, SustainabilityEngine
    cfg, discovered = load_config_or_discover()
    engine = SustainabilityEngine(cfg)
    profile = engine.discover()     # Phase 0: scan workspace
    engine.run()                    # Phases 1-5: assess → repair → converge
"""
from __future__ import annotations

from .version import VERSION as __version__, RELEASE_DATE, CODENAME

__all__ = [
    "SustainabilityConfig",
    "load_config",
    "load_config_or_discover",
    "SustainabilityEngine",
    "ProjectDiscovery",
    "ProjectProfile",
    "ViolationSummary",
    "__version__",
    "RELEASE_DATE",
    "CODENAME",
]

from .config import SustainabilityConfig, load_config, load_config_or_discover
from .engine import SustainabilityEngine
from .discovery import ProjectDiscovery, ProjectProfile, ViolationSummary
