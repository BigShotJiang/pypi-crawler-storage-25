"""
ssy.discovery — Project auto-discovery for the DeZ SSY engine.

Scan any workspace, identify structure, detect violations, and produce a
ProjectProfile that drives the engine without requiring a pre-written ssy.yaml.

Usage::

    from ssy.discovery import ProjectDiscovery
    profile = ProjectDiscovery().scan(Path("/some/project"))
    cfg     = ProjectDiscovery().to_config(profile)
"""
from __future__ import annotations

import ast
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# ── Scan exclusions ───────────────────────────────────────────────────────────

_IGNORE_DIRS: frozenset[str] = frozenset({
    ".git", ".venv", "venv", ".env", "env",
    "node_modules", "__pycache__", ".tox", ".mypy_cache", ".ruff_cache",
    "dist", "build", ".eggs", ".pytest_cache", "htmlcov", "site",
    ".sass-cache", ".next", ".nuxt", "target", "bin", "obj",
})

# ── Language detection ────────────────────────────────────────────────────────

_EXT_LANG: dict[str, str] = {
    ".py":    "python",
    ".js":    "javascript",  ".mjs": "javascript", ".cjs": "javascript",
    ".ts":    "typescript",  ".tsx": "typescript",
    ".java":  "java",
    ".c":     "c",           ".h":   "c",
    ".cpp":   "cpp",         ".cc":  "cpp",  ".hpp": "cpp",
    ".rs":    "rust",
    ".go":    "go",
    ".rb":    "ruby",
    ".cs":    "csharp",
    ".swift": "swift",
    ".kt":    "kotlin",
    ".scala": "scala",
    ".lua":   "lua",
    ".r":     "r",
    ".m":     "matlab",
    ".f90":   "fortran",     ".f":   "fortran",
}

# Fields that appear in doorstop-style requirement YAML
_REQ_FIELDS: frozenset[str] = frozenset({
    "id", "text", "derived_from", "verified_by", "rationale",
    "status", "level", "type", "norm_refs", "satisfies",
})

# Repair key for each violation kind
_DISC_REPAIR: dict[str, str] = {
    "syntax":   "forge_ticket",
    "trace":    "trace_links",
    "coverage": "stub_test_case",
    "missing":  "aspice_wp",
    "todo":     "consultation",
    "doc":      "consultation",
    "lint":     "consultation",
}


# ── Data structures ───────────────────────────────────────────────────────────

@dataclass
class ViolationSummary:
    path:     str
    kind:     str      # syntax | trace | coverage | missing | todo | doc | lint
    severity: str      # fail | warn | info
    message:  str
    line:     int = 0

    @property
    def repair_key(self) -> str:
        return _DISC_REPAIR.get(self.kind, "forge_ticket")


@dataclass
class ProjectProfile:
    """Everything DeZ SSY knows about the project after the DISCOVER phase."""
    root:           Path
    languages:      list[str]        # dominant language(s), most common first
    project_type:   str              # aspice | python | node | java | rust | go | generic
    req_dirs:       list[Path]       # directories that contain requirement files
    req_format:     str              # doorstop | reqif | csv | none
    test_dirs:      list[Path]       # directories containing test files
    test_framework: str              # pytest | behave | jest | junit | none
    source_dirs:    list[Path]       # directories containing source files
    doc_dirs:       list[Path]       # documentation source directories
    issue_dirs:     list[Path]       # issue-tracker artifact directories
    ci_files:       list[Path]       # CI/CD pipeline config files
    id_prefix:      str              # artifact ID prefix, e.g. "DEZ"
    violations:     list[ViolationSummary] = field(default_factory=list)
    meta:           dict = field(default_factory=dict)   # extra metadata

    # ── Convenience properties ────────────────────────────────────────────────

    @property
    def has_requirements(self) -> bool:
        return bool(self.req_dirs) and self.req_format != "none"

    @property
    def has_tests(self) -> bool:
        return bool(self.test_dirs) and self.test_framework != "none"

    @property
    def primary_language(self) -> str:
        return self.languages[0] if self.languages else "generic"

    @property
    def violation_summary(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        for v in self.violations:
            counts[v.kind] = counts.get(v.kind, 0) + 1
        return counts

    @property
    def fail_count(self) -> int:
        return sum(1 for v in self.violations if v.severity == "fail")

    @property
    def warn_count(self) -> int:
        return sum(1 for v in self.violations if v.severity == "warn")

    def as_summary(self) -> str:
        langs  = ", ".join(self.languages[:3]) or "unknown"
        counts = self.violation_summary
        parts  = [f"{n} {k}" for k, n in sorted(counts.items()) if n]
        vstr   = ", ".join(parts) if parts else "none"
        return (
            f"type={self.project_type}  lang=[{langs}]  "
            f"reqs={self.req_format}  tests={self.test_framework}  "
            f"violations=[{vstr}]"
        )


# ── Discovery engine ──────────────────────────────────────────────────────────

class ProjectDiscovery:
    """
    Drop DeZ SSY into any project root — this class figures out what it's dealing with.

    Two main entry points:

    * ``scan(root)``        → ``ProjectProfile``   (read-only scan)
    * ``to_config(profile)``→ ``SustainabilityConfig``  (build engine config)
    """

    # ── Public API ────────────────────────────────────────────────────────────

    def scan(self, root: Path, *, deep: bool = True) -> ProjectProfile:
        """Scan *root* and return a full ``ProjectProfile``."""
        root  = root.resolve()
        files = self._collect_files(root)

        languages    = self._detect_languages(files)
        project_type = self._detect_project_type(root, files, languages)
        req_dirs, req_fmt  = self._detect_requirements(root, files)
        test_dirs, test_fw = self._detect_tests(root, files, languages)
        source_dirs        = self._detect_sources(root, files, languages, test_dirs, req_dirs)
        doc_dirs           = self._detect_docs(root, files)
        issue_dirs         = self._detect_issues(root)
        ci_files           = self._detect_ci(root, files)
        id_prefix          = self._detect_id_prefix(root, files, req_dirs)

        profile = ProjectProfile(
            root=root,
            languages=languages,
            project_type=project_type,
            req_dirs=req_dirs,
            req_format=req_fmt,
            test_dirs=test_dirs,
            test_framework=test_fw,
            source_dirs=source_dirs,
            doc_dirs=doc_dirs,
            issue_dirs=issue_dirs,
            ci_files=ci_files,
            id_prefix=id_prefix,
        )

        if deep:
            self._scan_violations(profile, files)

        return profile

    def to_config(self, profile: ProjectProfile) -> "SustainabilityConfig":
        """Convert a ``ProjectProfile`` into a ``SustainabilityConfig``."""
        from .config import (
            ProjectPaths, NormConfig, SustainabilityConfig, _DEFAULTS,
        )

        root   = profile.root
        px     = profile.id_prefix
        ptype  = profile.project_type

        # Derive reasonable path guesses based on what we found
        def _first_or(dirs: list[Path], fallback: str) -> Path:
            return dirs[0] if dirs else root / fallback

        req_dir   = _first_or(profile.req_dirs,   _DEFAULTS["paths"]["reqvault"])
        test_dir  = _first_or(profile.test_dirs,  _DEFAULTS["paths"]["testpilot"])
        issue_dir = _first_or(profile.issue_dirs, _DEFAULTS["paths"]["forge"])
        doc_dir   = _first_or(profile.doc_dirs,   _DEFAULTS["paths"]["docsmith"])

        # Detect ASPICE stages from project type
        if ptype in ("aspice",):
            stages = ["SWE.4", "SWE.6"]
        elif ptype in ("python", "node", "ruby", "go", "rust"):
            stages = ["SWE.4"]   # component-level only
        else:
            stages = list(_DEFAULTS["norm"]["stages"])

        # Detect sw_class (IEC 62304) from project hints
        sw_class = profile.meta.get("sw_class", _DEFAULTS["norm"]["sw_class"])

        paths = ProjectPaths(
            root=root,
            reqvault=req_dir,
            testpilot=test_dir,
            forge=issue_dir,
            scripts=root / _DEFAULTS["paths"]["scripts"],
            shared=root / _DEFAULTS["paths"]["shared"],
            exports=root / _DEFAULTS["paths"]["exports"],
            coverage_json=root / _DEFAULTS["paths"]["coverage_json"],
            docsmith=doc_dir,
        )

        # Determine enabled assessors — always include generic discovery scan
        assessors = ["discovery"]
        if profile.has_requirements:
            assessors.append("unverified_reqs")
            assessors.append("trace")
        if (root / "_scripts" / "norm-agent-orchestrator.py").exists():
            assessors.append("norm_orchestrator")

        # Determine enabled repairers based on what the project needs
        repairers = list(_DEFAULTS["repairers"])

        return SustainabilityConfig(
            project_name=profile.meta.get("project_name", root.name),
            project_type=ptype,
            id_prefix=px,
            paths=paths,
            norm=NormConfig(stages=stages, sw_class=sw_class),
            assessors=assessors,
            repairers=repairers,
            max_iterations=_DEFAULTS["max_iterations"],
            coverage_threshold=_DEFAULTS["coverage_threshold"],
        )

    def generate_ssy_yaml(self, profile: ProjectProfile) -> str:
        """Render a ssy.yaml string for the discovered project (for user review)."""
        root = profile.root

        def _rel(p: Path) -> str:
            try:
                return str(p.relative_to(root))
            except ValueError:
                return str(p)

        req_path  = _rel(profile.req_dirs[0])  if profile.req_dirs  else "requirements"
        test_path = _rel(profile.test_dirs[0]) if profile.test_dirs else "tests"
        iss_path  = _rel(profile.issue_dirs[0]) if profile.issue_dirs else "issues"
        doc_path  = _rel(profile.doc_dirs[0])  if profile.doc_dirs  else "docs"

        lines = [
            f"# ssy.yaml — auto-generated by SSY discovery ({profile.project_type} project)",
            f"# Review and adjust before committing.",
            f"",
            f'project_name: "{root.name}"',
            f'project_type: {profile.project_type}',
            f'id_prefix:    {profile.id_prefix}',
            f"",
            f"paths:",
            f'  reqvault:      "{req_path}"',
            f'  testpilot:     "{test_path}"',
            f'  forge:         "{iss_path}"',
            f'  scripts:       "_scripts"',
            f'  shared:        "_shared"',
            f'  exports:       "exports/ssy"',
            f'  coverage_json: "coverage.json"',
            f'  docsmith:      "{doc_path}"',
            f"",
            f"norm:",
            f"  stages:   [{', '.join(self._stages_for(profile))}]",
            f"  sw_class: {profile.meta.get('sw_class', 'B')}",
            f"",
            f"# Detected violations in discovery scan: {len(profile.violations)}",
            f"#   {profile.violation_summary}",
            f"",
            f"max_iterations:     3",
            f"coverage_threshold: 70",
        ]
        return "\n".join(lines) + "\n"

    # ── File collection ───────────────────────────────────────────────────────

    def _collect_files(self, root: Path) -> list[Path]:
        files: list[Path] = []
        for p in root.rglob("*"):
            if p.is_file() and not any(part in _IGNORE_DIRS for part in p.parts):
                files.append(p)
        return files

    # ── Language detection ────────────────────────────────────────────────────

    def _detect_languages(self, files: list[Path]) -> list[str]:
        counts: dict[str, int] = {}
        data_langs: set[str]   = set()
        for f in files:
            lang = _EXT_LANG.get(f.suffix.lower())
            if lang:
                counts[lang] = counts.get(lang, 0) + 1
            elif f.suffix.lower() in (".yaml", ".yml"):
                data_langs.add("yaml")
            elif f.suffix.lower() == ".json":
                data_langs.add("json")
        ranked = sorted(counts, key=lambda k: -counts[k])
        return ranked + [s for s in sorted(data_langs) if s not in ranked]

    # ── Project-type detection ────────────────────────────────────────────────

    def _detect_project_type(
        self, root: Path, files: list[Path], langs: list[str]
    ) -> str:
        names = {f.name.lower() for f in files}
        dirs  = {p.name.lower() for p in root.iterdir() if p.is_dir()}

        # DeZ ASPICE V-cycle layout
        if {"02-reqvault", "04-testpilot", "01-forge"} & dirs:
            return "aspice"
        # Python project markers
        if {"pyproject.toml", "setup.py", "setup.cfg"} & names:
            return "python"
        # Node / JS / TS
        if "package.json" in names:
            return "node"
        # Java
        if {"pom.xml", "build.gradle", "build.gradle.kts"} & names:
            return "java"
        # Rust
        if "cargo.toml" in names:
            return "rust"
        # Go
        if "go.mod" in names:
            return "go"
        # Embedded / C
        if {"makefile", "cmake", "cmakelists.txt"} & names and "c" in langs:
            return "embedded-c"
        # Fall back to primary language
        if langs:
            return langs[0]
        return "generic"

    # ── Requirement detection ─────────────────────────────────────────────────

    def _detect_requirements(
        self, root: Path, files: list[Path]
    ) -> tuple[list[Path], str]:
        req_dirs: set[Path] = set()
        fmt = "none"

        for f in files:
            suf = f.suffix.lower()
            if suf in (".reqif", ".reqifz"):
                req_dirs.add(f.parent)
                fmt = "reqif"
                continue
            if suf == ".csv":
                header = ""
                try:
                    header = f.read_text(encoding="utf-8", errors="ignore")[:200].lower()
                except Exception:
                    pass
                if any(k in header for k in ("requirement", "id,", "req_id", "text,")):
                    req_dirs.add(f.parent)
                    if fmt == "none":
                        fmt = "csv"
                continue
            if suf in (".yaml", ".yml"):
                try:
                    text = f.read_text(encoding="utf-8", errors="ignore")
                    hits = sum(1 for fld in _REQ_FIELDS
                               if f"\n{fld}:" in text or text.startswith(f"{fld}:"))
                    if hits >= 2:
                        req_dirs.add(f.parent)
                        if fmt == "none":
                            fmt = "doorstop"
                except Exception:
                    pass

        # Deduplicate: keep only the shallowest ancestor dirs
        dirs  = sorted(req_dirs, key=lambda p: len(p.parts))
        pruned: list[Path] = []
        for d in dirs:
            if not any(d != o and str(d).startswith(str(o) + "/") for o in pruned):
                pruned.append(d)
        return pruned, fmt

    # ── Test detection ────────────────────────────────────────────────────────

    def _detect_tests(
        self, root: Path, files: list[Path], langs: list[str]
    ) -> tuple[list[Path], str]:
        test_dirs: set[Path] = set()
        fw = "none"

        for f in files:
            n = f.name.lower()
            if n.endswith(".feature"):
                test_dirs.add(f.parent)
                fw = "behave" if fw == "none" else fw
                continue
            if n.endswith(".py") and (n.startswith("test_") or n.endswith("_test.py")):
                test_dirs.add(f.parent)
                fw = "pytest"
                continue
            if n.endswith((".test.js", ".spec.js", ".test.ts", ".spec.ts")):
                test_dirs.add(f.parent)
                fw = "jest" if fw == "none" else fw
                continue
            if n.endswith(("test.java", "tests.java", "testcase.java")):
                test_dirs.add(f.parent)
                fw = "junit" if fw == "none" else fw

        # Well-known test directory names
        for d_name in ("tests", "test", "__tests__", "spec", "specs",
                       "04-testpilot", "testpilot"):
            d = root / d_name
            if d.is_dir():
                test_dirs.add(d)
                if fw == "none" and "python" in langs:
                    fw = "pytest"

        return sorted(test_dirs), fw

    # ── Source detection ──────────────────────────────────────────────────────

    def _detect_sources(
        self,
        root: Path,
        files: list[Path],
        langs: list[str],
        test_dirs: list[Path],
        req_dirs: list[Path],
    ) -> list[Path]:
        exclude: set[str] = {str(d) for d in test_dirs + req_dirs}
        src_dirs: set[Path] = set()

        for f in files:
            if f.suffix.lower() in _EXT_LANG:
                p = str(f.parent)
                if not any(p.startswith(ex) for ex in exclude):
                    src_dirs.add(f.parent)

        # Canonical source directories
        for d_name in ("src", "lib", "app", "core", "source", "_scripts"):
            d = root / d_name
            if d.is_dir():
                src_dirs.add(d)

        return sorted(src_dirs)

    # ── Docs / issues / CI ────────────────────────────────────────────────────

    def _detect_docs(self, root: Path, files: list[Path]) -> list[Path]:
        doc_dirs: set[Path] = set()
        for f in files:
            if f.name.lower() in ("mkdocs.yml", "mkdocs.yaml", "conf.py",
                                   "book.toml", "docusaurus.config.js"):
                doc_dirs.add(f.parent)
        for d_name in ("docs", "doc", "documentation", "06-docsmith"):
            d = root / d_name
            if d.is_dir():
                doc_dirs.add(d)
        return sorted(doc_dirs)

    def _detect_issues(self, root: Path) -> list[Path]:
        issue_dirs: set[Path] = set()
        for d_name in ("01-forge", "forge", "issues", ".github"):
            d = root / d_name
            if d.is_dir():
                issue_dirs.add(d)
        return sorted(issue_dirs)

    def _detect_ci(self, root: Path, files: list[Path]) -> list[Path]:
        ci: list[Path] = []
        for f in files:
            n = f.name.lower()
            if n in ("jenkinsfile", ".travis.yml", "circle.yml", "tox.ini"):
                ci.append(f)
            elif ".github/workflows" in f.as_posix() and f.suffix in (".yml", ".yaml"):
                ci.append(f)
            elif ".gitlab-ci" in n:
                ci.append(f)
            elif n in ("azure-pipelines.yml", "bitbucket-pipelines.yml"):
                ci.append(f)
        return ci

    # ── ID-prefix inference ───────────────────────────────────────────────────

    def _detect_id_prefix(
        self, root: Path, files: list[Path], req_dirs: list[Path]
    ) -> str:
        id_pattern = re.compile(r"\bid\s*:\s*([A-Z]{2,8})-")
        for f in files:
            if f.suffix.lower() not in (".yaml", ".yml"):
                continue
            if not any(str(f).startswith(str(d)) for d in req_dirs):
                continue
            try:
                m = id_pattern.search(f.read_text(encoding="utf-8", errors="ignore"))
                if m:
                    return m.group(1)
            except Exception:
                pass

        # Derive from project root name: strip non-alpha, take first 3 uppercase chars
        alpha = re.sub(r"[^A-Z]", "", root.name.upper())
        return alpha[:3] if len(alpha) >= 2 else "SSY"

    # ── Norm stage inference ──────────────────────────────────────────────────

    def _stages_for(self, profile: ProjectProfile) -> list[str]:
        if profile.project_type == "aspice":
            return ["SWE.4", "SWE.6"]
        if profile.project_type in ("python", "node", "ruby", "go", "rust"):
            return ["SWE.4"]
        return ["SWE.4", "SWE.6"]

    # ── Violation scanning ────────────────────────────────────────────────────

    def _scan_violations(self, profile: ProjectProfile, files: list[Path]) -> None:
        """Populate profile.violations with pre-detected issues."""
        for f in files:
            suf = f.suffix.lower()
            if suf == ".py":
                self._check_syntax_py(profile, f)
                self._check_todos(profile, f)
                self._check_large_functions(profile, f)
            elif suf in (".yaml", ".yml"):
                self._check_req_trace(profile, f)
            elif suf in (".md", ".rst"):
                self._check_broken_links(profile, f)

        self._check_missing_tests(profile, files)
        self._check_missing_readme(profile)
        self._check_missing_ci(profile)

    # ── Syntax violations ─────────────────────────────────────────────────────

    def _check_syntax_py(self, profile: ProjectProfile, path: Path) -> None:
        try:
            ast.parse(path.read_text(encoding="utf-8", errors="ignore"))
        except SyntaxError as e:
            profile.violations.append(ViolationSummary(
                path=self._rel(profile.root, path),
                kind="syntax", severity="fail",
                message=f"SyntaxError: {e.msg}",
                line=e.lineno or 0,
            ))

    # ── TODO / FIXME violations ───────────────────────────────────────────────

    def _check_todos(self, profile: ProjectProfile, path: Path) -> None:
        _todo_re = re.compile(r"\b(TODO|FIXME|HACK|XXX)\b", re.IGNORECASE)
        try:
            for i, line in enumerate(
                path.read_text(encoding="utf-8", errors="ignore").splitlines(), 1
            ):
                stripped = line.strip()
                if stripped.startswith("#") and _todo_re.search(stripped):
                    profile.violations.append(ViolationSummary(
                        path=self._rel(profile.root, path),
                        kind="todo", severity="info",
                        message=stripped[:120], line=i,
                    ))
        except Exception:
            pass

    # ── Oversized function violations ─────────────────────────────────────────

    def _check_large_functions(self, profile: ProjectProfile, path: Path) -> None:
        try:
            tree = ast.parse(path.read_text(encoding="utf-8", errors="ignore"))
        except Exception:
            return
        for node in ast.walk(tree):
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            if not node.body:
                continue
            start = node.body[0].lineno
            end   = node.body[-1].end_lineno or node.body[-1].lineno
            body_lines = end - start + 1
            if body_lines > 200:
                profile.violations.append(ViolationSummary(
                    path=self._rel(profile.root, path),
                    kind="lint", severity="warn",
                    message=(
                        f"Function '{node.name}' is {body_lines} lines "
                        f"(limit 200) — refactor into sub-functions"
                    ),
                    line=node.lineno,
                ))

    # ── Requirement traceability violations ───────────────────────────────────

    def _check_req_trace(self, profile: ProjectProfile, path: Path) -> None:
        if not any(str(path).startswith(str(d)) for d in profile.req_dirs):
            return
        try:
            import yaml as _yaml
            doc = _yaml.safe_load(path.read_text(encoding="utf-8", errors="ignore")) or {}
        except Exception:
            return
        if not isinstance(doc, dict):
            return
        rid = str(doc.get("id", "")).strip()
        if not rid or any(x in rid for x in ("TMPL", "EXAMPLE", "STUB")):
            return

        if not doc.get("verified_by"):
            profile.violations.append(ViolationSummary(
                path=self._rel(profile.root, path),
                kind="trace", severity="warn",
                message=f"{rid}: missing 'verified_by' traceability link",
            ))
        if not doc.get("derived_from") and rid.count("-") >= 2:
            profile.violations.append(ViolationSummary(
                path=self._rel(profile.root, path),
                kind="trace", severity="warn",
                message=f"{rid}: missing 'derived_from' traceability link",
            ))

    # ── Broken markdown reference violations ──────────────────────────────────

    def _check_broken_links(self, profile: ProjectProfile, path: Path) -> None:
        _link_re = re.compile(r"\[.*?\]\(([^)]+)\)")
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            return
        for m in _link_re.finditer(text):
            href = m.group(1).strip()
            # Skip URLs and anchors
            if href.startswith(("http://", "https://", "#", "mailto:")):
                continue
            target = (path.parent / href).resolve()
            if not target.exists():
                profile.violations.append(ViolationSummary(
                    path=self._rel(profile.root, path),
                    kind="missing", severity="warn",
                    message=f"Broken link: [{href}] target not found",
                ))

    # ── Coverage violations ───────────────────────────────────────────────────

    def _check_missing_tests(self, profile: ProjectProfile, files: list[Path]) -> None:
        if not profile.test_dirs or profile.test_framework == "none":
            return

        # Build set of stems that have a test file
        test_stems: set[str] = set()
        for f in files:
            if any(str(f).startswith(str(d)) for d in profile.test_dirs):
                stem = f.stem.lower()
                # Normalise test_ prefix / _test suffix
                stem = stem.removeprefix("test_").removesuffix("_test")
                test_stems.add(stem)
                test_stems.add(f"test_{stem}")

        tested_exts = {".py"} if "python" in profile.languages else set(_EXT_LANG)
        exclude_dirs = set(str(d) for d in profile.test_dirs + profile.req_dirs)

        for f in files:
            if f.suffix.lower() not in tested_exts:
                continue
            if any(str(f).startswith(ex) for ex in exclude_dirs):
                continue
            if f.name.startswith(("_", ".")):
                continue
            # Skip __init__ and conftest etc.
            if f.stem.lower() in ("__init__", "conftest", "__main__", "setup"):
                continue
            stem = f.stem.lower()
            if stem not in test_stems:
                profile.violations.append(ViolationSummary(
                    path=self._rel(profile.root, f),
                    kind="coverage", severity="warn",
                    message=f"No test file found for {f.name}",
                ))

    # ── Missing artifacts ─────────────────────────────────────────────────────

    def _check_missing_readme(self, profile: ProjectProfile) -> None:
        for name in ("README.md", "README.rst", "README.txt", "README"):
            if (profile.root / name).exists():
                return
        profile.violations.append(ViolationSummary(
            path="README.md",
            kind="missing", severity="warn",
            message="README.md is missing — projects must have top-level documentation",
        ))

    def _check_missing_ci(self, profile: ProjectProfile) -> None:
        if profile.ci_files:
            return
        # Only warn if project has source code (not pure-doc repos)
        if not profile.source_dirs:
            return
        profile.violations.append(ViolationSummary(
            path=".github/workflows/",
            kind="missing", severity="info",
            message="No CI/CD pipeline detected — consider adding GitHub Actions or similar",
        ))

    # ── Helper ────────────────────────────────────────────────────────────────

    @staticmethod
    def _rel(root: Path, path: Path) -> str:
        try:
            return str(path.relative_to(root))
        except ValueError:
            return str(path)
