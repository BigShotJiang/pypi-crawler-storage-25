"""
ssy.config — Project configuration schema and loader.

Each project provides a ssy.yaml in its root directory.
Missing keys fall back to sensible defaults (ASPICE + DeZ layout).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

try:
    import yaml
except ImportError:
    yaml = None  # type: ignore[assignment]


# ── Defaults (compatible with DeZ Enterprise layout) ─────────────────────────

_DEFAULTS: dict[str, Any] = {
    "project_name": "DeZ SSY Project",
    "project_type": "aspice",
    "id_prefix":    "DEZ",
    "paths": {
        "reqvault":      "02-reqvault",
        "testpilot":     "04-testpilot",
        "forge":         "01-forge",
        "scripts":       "_scripts",
        "shared":        "_shared",
        "exports":       "exports/ssy",
        "coverage_json": "coverage.json",
        "docsmith":      "06-docsmith",
    },
    "norm": {
        "stages":   ["SWE.4", "SWE.6"],
        "sw_class": "B",
    },
    "assessors": [
        "filesystem",
        "unverified_reqs",
        "trace",
        "norm_orchestrator",
    ],
    "repairers": [
        "coverage_json", "test_plan", "qualification_run", "aspice_wp",
        "sbom", "iso27001_soa", "iso21434_goals",
        "stub_test_case", "unverified_req", "trace_links",
        "baseline_tag", "consultation", "forge_ticket",
    ],
    "max_iterations": 3,
    "coverage_threshold": 70,
}


@dataclass
class ProjectPaths:
    root:          Path
    reqvault:      Path
    testpilot:     Path
    forge:         Path
    scripts:       Path
    shared:        Path
    exports:       Path
    coverage_json: Path
    docsmith:      Path


@dataclass
class NormConfig:
    stages:   list[str]
    sw_class: str


@dataclass
class SustainabilityConfig:
    """Full project configuration for the DeZ SSY engine."""
    project_name:       str
    project_type:       str          # aspice | iso26262 | do178c | generic
    id_prefix:          str          # artifact ID prefix, e.g. "DEZ" → DEZ-TC-NNNN
    paths:              ProjectPaths
    norm:               NormConfig
    assessors:          list[str]    # ordered list of assessors to run
    repairers:          list[str]    # enabled repair handlers
    max_iterations:     int
    coverage_threshold: int          # minimum acceptable coverage %

    def __str__(self) -> str:
        return (
            f"DeZ SSY Config: {self.project_name} ({self.project_type}) "
            f"| root={self.paths.root} | stages={self.norm.stages}"
        )


def load_config(
    config_path: Path | None = None,
    root: Path | None = None,
) -> SustainabilityConfig:
    """Load ssy.yaml from *root* (or *config_path*); merge with defaults.

    Priority: explicit config_path > root/ssy.yaml > cwd/ssy.yaml > defaults.
    """
    if config_path is None:
        search_root = root or Path.cwd()
        config_path = search_root / "ssy.yaml"

    effective_root = config_path.parent if config_path.exists() else (root or Path.cwd())

    raw: dict[str, Any] = {}
    if config_path.exists():
        if yaml is None:
            raise ImportError("pyyaml is required: pip install pyyaml")
        with config_path.open(encoding="utf-8") as fh:
            raw = yaml.safe_load(fh) or {}

    # Deep-merge paths and norm sections
    raw_paths = {**_DEFAULTS["paths"], **raw.get("paths", {})}
    raw_norm  = {**_DEFAULTS["norm"],  **raw.get("norm", {})}

    paths = ProjectPaths(
        root=effective_root,
        reqvault=effective_root / raw_paths["reqvault"],
        testpilot=effective_root / raw_paths["testpilot"],
        forge=effective_root / raw_paths["forge"],
        scripts=effective_root / raw_paths["scripts"],
        shared=effective_root / raw_paths["shared"],
        exports=effective_root / raw_paths["exports"],
        coverage_json=effective_root / raw_paths["coverage_json"],
        docsmith=effective_root / raw_paths["docsmith"],
    )

    return SustainabilityConfig(
        project_name=raw.get("project_name", _DEFAULTS["project_name"]),
        project_type=raw.get("project_type", _DEFAULTS["project_type"]),
        id_prefix=raw.get("id_prefix", _DEFAULTS["id_prefix"]),
        paths=paths,
        norm=NormConfig(
            stages=raw_norm["stages"],
            sw_class=raw_norm["sw_class"],
        ),
        assessors=raw.get("assessors", list(_DEFAULTS["assessors"])),
        repairers=raw.get("repairers", list(_DEFAULTS["repairers"])),
        max_iterations=raw.get("max_iterations", _DEFAULTS["max_iterations"]),
        coverage_threshold=raw.get("coverage_threshold", _DEFAULTS["coverage_threshold"]),
    )


def load_config_or_discover(
    config_path: Path | None = None,
    root: Path | None = None,
) -> tuple["SustainabilityConfig", bool]:
    """Load ssy.yaml if it exists; otherwise auto-discover the project structure.

    Returns ``(config, was_discovered)`` where *was_discovered* is True when
    no ssy.yaml was found and the config was built from directory scanning.
    When *was_discovered* is True, a draft ssy.yaml is written to the project
    root so the user can review and commit it.
    """
    effective_root = (
        config_path.parent if config_path else (root or Path.cwd())
    )
    yaml_path = config_path or (effective_root / "ssy.yaml")

    if yaml_path.exists():
        return load_config(config_path=yaml_path, root=root), False

    # No ssy.yaml found — run auto-discovery
    from .discovery import ProjectDiscovery
    disc    = ProjectDiscovery()
    profile = disc.scan(effective_root)
    cfg     = disc.to_config(profile)

    # Write a draft ssy.yaml so the user can review / commit it
    draft_path = effective_root / "ssy.yaml"
    try:
        draft_content = disc.generate_ssy_yaml(profile)
        draft_path.write_text(draft_content, encoding="utf-8")
    except Exception:
        pass

    return cfg, True
