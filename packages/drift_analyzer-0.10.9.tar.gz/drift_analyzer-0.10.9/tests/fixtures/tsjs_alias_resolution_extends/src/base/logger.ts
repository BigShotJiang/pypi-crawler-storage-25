export const logger = "base";
