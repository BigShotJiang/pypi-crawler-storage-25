export const Card = () => null;
