export const b = () => "ok";
