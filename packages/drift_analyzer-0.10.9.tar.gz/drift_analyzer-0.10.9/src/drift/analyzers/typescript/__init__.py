"""TypeScript analyzer helpers."""
