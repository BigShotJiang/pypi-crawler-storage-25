"""
Carapace SDK — key generation helpers.
"""

from __future__ import annotations

import os
from dataclasses import dataclass

import nacl.signing


@dataclass
class KeyPair:
    """An Ed25519 key pair (hex-encoded)."""
    private_key: str  # 64 hex chars (32-byte seed)
    public_key: str   # 64 hex chars (32-byte point)


def generate_key_pair() -> KeyPair:
    """
    Generate a fresh Ed25519 key pair.

    The private key is a 32-byte random seed encoded as hex.
    Store it in a secrets manager or environment variable — never hard-code.

    :returns: :class:`KeyPair` with ``private_key`` and ``public_key`` hex strings.

    Example::

        from carapace.keys import generate_key_pair

        kp = generate_key_pair()
        print(kp.private_key)  # store this securely!
        print(kp.public_key)   # safe to share
    """
    signing_key = nacl.signing.SigningKey.generate()
    private_hex = bytes(signing_key).hex()           # 32-byte seed
    public_hex = bytes(signing_key.verify_key).hex() # 32-byte point
    return KeyPair(private_key=private_hex, public_key=public_hex)
