"""
Carapace SDK — shared type definitions.

These mirror the TypeScript types in the JS SDK so that
cards produced by either SDK are wire-compatible.
"""

from __future__ import annotations

from typing import Any, Literal, Optional
from dataclasses import dataclass, field


# ---------------------------------------------------------------------------
# Core sub-types
# ---------------------------------------------------------------------------

@dataclass
class Capability:
    id: str
    name: str
    description: str


@dataclass
class Endpoint:
    protocol: str
    url: str
    auth: Optional[Literal["none", "api_key", "oauth2"]] = None


@dataclass
class Owner:
    public_key: str
    did: Optional[str] = None


# ---------------------------------------------------------------------------
# Registration input / output
# ---------------------------------------------------------------------------

@dataclass
class RegisterAgentOptions:
    name: str
    description: str
    framework: str
    capabilities: list[Capability]
    endpoints: list[Endpoint]
    version: Optional[str] = None
    tags: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class AgentCard:
    id: str
    name: str
    description: str
    framework: str
    capabilities: list[Capability]
    endpoints: list[Endpoint]
    owner: Owner
    signature: str
    issued_at: str
    updated_at: str
    version: Optional[str] = None
    tags: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Verify / Discover
# ---------------------------------------------------------------------------

@dataclass
class VerifyResult:
    agent_id: str
    verified: bool
    reason: Optional[str] = None


@dataclass
class DiscoverFilters:
    capability: Optional[str] = None
    framework: Optional[str] = None
    tag: Optional[str] = None
    text: Optional[str] = None
    limit: Optional[int] = None
