"""
Carapace SDK — A2A (Agent-to-Agent) compatibility helpers.

Converts a Carapace AgentCard to a Google A2A AgentCard
suitable for serving at ``/.well-known/agent.json``.

Targets A2A Protocol spec v1.0.
Reference: https://a2a-protocol.org/latest/specification/
"""

from __future__ import annotations

# A2A protocol version this SDK targets
A2A_PROTOCOL_VERSION = "1.0"

from dataclasses import dataclass, field, asdict
from typing import Any, Optional

from .types import AgentCard


# ---------------------------------------------------------------------------
# A2A types (mirrors the JS SDK's a2a.ts)
# ---------------------------------------------------------------------------


@dataclass
class A2ASkill:
    id: str
    name: str
    description: str


@dataclass
class A2ASecurityScheme:
    type: str  # "apiKey" | "oauth2" | "none"


@dataclass
class A2AAgentCard:
    """
    Minimal A2A AgentCard (A2A Protocol spec v1.0).

    The ``x_carapace`` extension embeds provenance info so verifiers can
    optionally cross-check against the Carapace registry.
    """
    name: str
    description: str
    url: str
    version: str
    skills: list[A2ASkill]
    security_schemes: dict[str, A2ASecurityScheme]
    x_carapace: dict[str, Any] = field(default_factory=dict)
    protocol_version: str = A2A_PROTOCOL_VERSION

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a dict ready for JSON serialisation as agent.json."""
        result: dict[str, Any] = {
            "protocolVersion": self.protocol_version,  # Required by A2A spec 1.0
            "name": self.name,
            "description": self.description,
            "url": self.url,
            "version": self.version,
            "skills": [{"id": s.id, "name": s.name, "description": s.description} for s in self.skills],
            "securitySchemes": {
                k: {"type": v.type} for k, v in self.security_schemes.items()
            },
        }
        if self.x_carapace:
            result["x-carapace"] = self.x_carapace
        return result


# ---------------------------------------------------------------------------
# Converter
# ---------------------------------------------------------------------------


def generate_well_known_card(card: AgentCard) -> A2AAgentCard:
    """
    Convert a :class:`~carapace.types.AgentCard` to an :class:`A2AAgentCard`.

    The resulting card can be serialized to JSON and served at
    ``/.well-known/agent.json`` so that any A2A-compatible agent discovery
    tool can find and verify the agent.

    :param card: A registered Carapace agent card.
    :returns: A2A-compatible agent card with a ``x-carapace`` provenance extension.
    """
    # Pick the A2A endpoint URL: prefer protocol="a2a", fall back to first endpoint
    endpoint_url = ""
    for ep in card.endpoints:
        if ep.protocol == "a2a":
            endpoint_url = ep.url
            break
    if not endpoint_url and card.endpoints:
        endpoint_url = card.endpoints[0].url

    # Map capabilities → A2A skills
    skills = [
        A2ASkill(id=cap.id, name=cap.name, description=cap.description)
        for cap in card.capabilities
    ]

    # Collect unique auth schemes across endpoints
    seen: set[str] = set()
    security_schemes: dict[str, A2ASecurityScheme] = {}
    for ep in card.endpoints:
        auth = ep.auth or "none"
        if auth not in seen:
            seen.add(auth)
            a2a_type = _map_auth_scheme(auth)
            security_schemes[a2a_type] = A2ASecurityScheme(type=a2a_type)

    if not security_schemes:
        security_schemes["none"] = A2ASecurityScheme(type="none")

    # Provenance extension (mirrors JS SDK x-carapace structure)
    x_carapace: dict[str, Any] = {}
    if card.id:
        x_carapace["registryId"] = card.id
    x_carapace["ownerPublicKey"] = card.owner.public_key
    if card.issued_at:
        x_carapace["issuedAt"] = card.issued_at

    return A2AAgentCard(
        name=card.name,
        description=card.description,
        url=endpoint_url,
        version=card.version or "0.1.0",
        skills=skills,
        security_schemes=security_schemes,
        x_carapace=x_carapace,
    )


def _map_auth_scheme(carapace_auth: str) -> str:
    mapping = {
        "api_key": "apiKey",
        "oauth2": "oauth2",
        "none": "none",
    }
    return mapping.get(carapace_auth, "none")
