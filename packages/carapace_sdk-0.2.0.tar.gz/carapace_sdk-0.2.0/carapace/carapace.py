"""
Carapace — top-level convenience class.

Matches the directive spec API exactly:

    from carapace import Carapace

    client = Carapace(
        registry_url="https://api.relayforge.tools/aria/v1",
        owner_key=os.environ["CARAPACE_OWNER_KEY"]
    )

    card = client.register(
        name="MyAgent",
        description="A helpful research agent",
        framework="langchain",
        capabilities=[{"id": "research", "name": "Research", "description": "Searches topics"}],
        endpoints=[{"protocol": "https", "url": "https://my-server.com/agent"}]
    )

    result = client.verify(card.id)
    agents = client.discover(capability="research")
    ok = client.verify_local(card, signature, public_key)

This is a thin wrapper over :class:`~carapace.client.CarapaceClient`.
Use ``CarapaceClient`` directly for full method-name access; use ``Carapace``
for the compact directive-spec API.
"""

from __future__ import annotations

from typing import Any, Optional

import httpx

from .client import CarapaceClient
from .crypto import verify_payload
from .keys import generate_key_pair
from .types import AgentCard, DiscoverFilters, RegisterAgentOptions, VerifyResult


class Carapace:
    """
    Carapace convenience client.

    Provides the three core operations — ``register``, ``verify``, ``discover`` —
    plus ``verify_local`` for fully offline signature checking.

    :param registry_url: Base URL of the ARIA registry (without trailing slash).
        Example: ``"https://api.relayforge.tools/aria/v1"``
    :param owner_key: Hex-encoded Ed25519 private key seed.
        If omitted, operations that require signing will raise ``ValueError``.
        Generate one with :func:`~carapace.keys.generate_key_pair`.
        Store securely — never hard-code.
    :param http_client: Optional :class:`httpx.Client` override (useful in tests).
    """

    def __init__(
        self,
        registry_url: str,
        owner_key: Optional[str] = None,
        http_client: Optional[httpx.Client] = None,
    ) -> None:
        self._registry_url = registry_url.rstrip("/")
        self._owner_key = owner_key
        self._http = http_client
        self._inner: Optional[CarapaceClient] = None

        if owner_key:
            self._inner = CarapaceClient(
                registry_url=registry_url,
                owner_private_key=owner_key,
                http_client=http_client,
            )

    # ------------------------------------------------------------------
    # Class factory (auto-keygen)
    # ------------------------------------------------------------------

    @classmethod
    def create(
        cls,
        registry_url: str,
        owner_key: Optional[str] = None,
        http_client: Optional[httpx.Client] = None,
    ) -> "Carapace":
        """
        Factory method — generates a fresh Ed25519 keypair when no ``owner_key``
        is passed. Convenient for testing and ephemeral agents.

        :example:

            carapace = Carapace.create(registry_url="https://api.relayforge.tools/aria/v1")
            # A new keypair was generated; carapace is ready for signing.
        """
        if owner_key is None:
            kp = generate_key_pair()
            owner_key = kp.private_key
        return cls(registry_url=registry_url, owner_key=owner_key, http_client=http_client)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @property
    def _client(self) -> CarapaceClient:
        if self._inner is None:
            raise ValueError(
                "Carapace: owner_key not set. Pass owner_key to the constructor "
                "or use Carapace.create() to auto-generate a keypair."
            )
        return self._inner

    # ------------------------------------------------------------------
    # Core API (matches directive spec)
    # ------------------------------------------------------------------

    def register(
        self,
        name: str,
        description: str,
        framework: str,
        capabilities: list[dict[str, Any]],
        endpoints: list[dict[str, Any]],
        version: Optional[str] = None,
        tags: Optional[list[str]] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> AgentCard:
        """
        Register an agent with the ARIA registry.

        The SDK automatically derives the public key, constructs the identity card,
        JCS-canonicalizes it, signs it with Ed25519, and sends it to the registry.

        :returns: The registered :class:`~carapace.types.AgentCard` with an assigned ``id``.
        """
        return self._client.register(
            name=name,
            description=description,
            framework=framework,
            capabilities=capabilities,
            endpoints=endpoints,
            version=version,
            tags=tags,
            metadata=metadata,
        )

    def verify(self, agent_id: str) -> VerifyResult:
        """
        Ask the ARIA registry to verify an agent's stored signature.

        :param agent_id: UUID returned by :meth:`register`.
        :returns: :class:`~carapace.types.VerifyResult` with ``verified`` bool.
        """
        return self._client.verify(agent_id)

    def discover(
        self,
        capability: Optional[str] = None,
        framework: Optional[str] = None,
        tag: Optional[str] = None,
        text: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> list[AgentCard]:
        """
        Discover agents in the registry.
        All filters are optional — omit to list all agents.

        :returns: List of matching :class:`~carapace.types.AgentCard` objects.
        """
        return self._client.discover(
            capability=capability,
            framework=framework,
            tag=tag,
            text=text,
            limit=limit,
        )

    def get(self, agent_id: str) -> AgentCard:
        """
        Fetch a single agent card by ID from the registry.

        :param agent_id: The agent's registry UUID.
        :returns: The :class:`~carapace.types.AgentCard` for the given ID.
        """
        return self._client.get_agent(agent_id)

    def verify_local(
        self,
        card: AgentCard,
        signature: str,
        public_key: str,
    ) -> bool:
        """
        Fully offline Ed25519 signature verification — no network required.

        Useful for:
        - Peer-to-peer agent authentication before trusting a remote tool call.
        - Verifying a card saved locally.
        - CI/test environments without a live registry.

        :param card: The :class:`~carapace.types.AgentCard` to verify.
        :param signature: Hex-encoded Ed25519 signature.
        :param public_key: Hex-encoded Ed25519 public key of the expected owner.
        :returns: ``True`` if the signature is valid, ``False`` otherwise.
        """
        # Reconstruct the signed payload exactly as _build_signed_payload did.
        # The signed object never includes: id, signature, updated_at, or None/empty
        # optional fields. Capabilities and endpoints are plain dicts, not dataclasses.
        signable = {
            "name": card.name,
            "description": card.description,
            "framework": card.framework,
            "capabilities": [
                {"id": c.id, "name": c.name, "description": c.description}
                for c in card.capabilities
            ],
            "endpoints": [
                {k: v for k, v in {"protocol": e.protocol, "url": e.url, "auth": e.auth}.items() if v is not None}
                for e in card.endpoints
            ],
            "issued_at": card.issued_at,
            "owner": {k: v for k, v in {"public_key": card.owner.public_key, "did": card.owner.did}.items() if v is not None},
        }
        if card.version:
            signable["version"] = card.version
        if card.tags:
            signable["tags"] = card.tags
        if card.metadata:
            signable["metadata"] = card.metadata
        return verify_payload(signable, signature, public_key)

    def public_key(self) -> str:
        """
        Return the hex-encoded Ed25519 public key derived from the owner key.
        Cached after first call.
        """
        return self._client.get_public_key()
