"""
Carapace SDK — main client.

Usage::

    from carapace import CarapaceClient

    client = CarapaceClient(
        registry_url="https://api.relayforge.tools/aria/v1",
        owner_private_key=os.environ["CARAPACE_OWNER_KEY"],
        owner_auth_token=os.environ.get("CARAPACE_AUTH_TOKEN"),
    )

    card = client.register(
        name="MyAgent",
        description="A helpful research agent",
        framework="langchain",
        capabilities=[{"id": "research", "name": "Research", "description": "Searches and summarizes"}],
        endpoints=[{"protocol": "https", "url": "https://my-server.com/agent"}]
    )

    result = client.verify(card.id)
    agents = client.discover(capability="research")
"""

from __future__ import annotations

import base64
import os
import secrets
from dataclasses import asdict
from datetime import datetime, timezone
from typing import Any, Callable, Optional

import httpx

from .crypto import _jcs_canonicalize, derive_public_key, sign_payload
from .types import (
    AgentCard,
    Capability,
    DiscoverFilters,
    Endpoint,
    Owner,
    RegisterAgentOptions,
    VerifyResult,
)

import nacl.signing


def generate_owner_token() -> str:
    """Generate a cryptographically-secure 32-byte hex owner auth token."""
    return secrets.token_hex(32)


class CarapaceClient:
    """
    Main entry point for the Carapace SDK.

    :param registry_url: Base URL for the ARIA registry API.
    :param owner_private_key: Hex-encoded Ed25519 private key seed (64 chars).
        Generate one with :func:`carapace.keys.generate_key_pair`.
        Store securely in an env var or secrets manager — never hard-code.
    :param owner_auth_token: Bearer token for protected endpoints (register/revoke).
        Generate with :func:`generate_owner_token`. Store securely.
    :param http_client: Optional :class:`httpx.Client` override (useful in tests).
    """

    def __init__(
        self,
        registry_url: str,
        owner_private_key: str,
        owner_auth_token: Optional[str] = None,
        http_client: Optional[httpx.Client] = None,
    ) -> None:
        self.registry_url = registry_url.rstrip("/")
        self._private_key = owner_private_key
        self._owner_auth_token = owner_auth_token
        self._http = http_client or httpx.Client(timeout=30.0)
        self._public_key: Optional[str] = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def register(
        self,
        name: str,
        description: str,
        framework: str,
        capabilities: list[dict[str, Any]],
        endpoints: list[dict[str, Any]],
        version: Optional[str] = None,
        tags: Optional[list[str]] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> AgentCard:
        """
        Register a new agent with the ARIA registry.

        The SDK automatically:

        - Derives the public key from your private key.
        - Constructs the full identity card with embedded verification object.
        - JCS-canonicalizes with signature="" and Ed25519-signs.
        - Embeds the base64url signature in verification.signature.
        - Sends { card: signedCard } to the registry.

        :returns: The registered :class:`~carapace.types.AgentCard` with the assigned ``id``.
        """
        options = RegisterAgentOptions(
            name=name,
            description=description,
            framework=framework,
            capabilities=[Capability(**c) for c in capabilities],
            endpoints=[Endpoint(**e) for e in endpoints],
            version=version,
            tags=tags or [],
            metadata=metadata or {},
        )
        signed_card = self._build_signed_card(options)
        headers = self._auth_headers()
        resp = self._http.post(
            f"{self.registry_url}/agents/register",
            json={"card": signed_card},
            headers=headers,
        )
        _raise_for_status(resp)
        return _agent_card_from_dict(resp.json())

    def get_agent(self, agent_id: str) -> AgentCard:
        """
        Fetch a single agent card by ID from the registry.
        """
        resp = self._http.get(f"{self.registry_url}/agents/{agent_id}")
        _raise_for_status(resp)
        return _agent_card_from_dict(resp.json())

    def verify(self, agent_id: str) -> VerifyResult:
        """
        Ask the ARIA registry to verify an agent's signature.
        """
        resp = self._http.post(f"{self.registry_url}/agents/{agent_id}/verify")
        _raise_for_status(resp)
        data = resp.json()
        return VerifyResult(
            agent_id=data["agent_id"],
            verified=data["verified"],
            reason=data.get("reason"),
        )

    def revoke(self, agent_id: str) -> dict[str, Any]:
        """
        Revoke a registered agent. Requires owner auth token.
        """
        headers = self._auth_headers()
        resp = self._http.post(
            f"{self.registry_url}/agents/{agent_id}/revoke",
            json={},
            headers=headers,
        )
        _raise_for_status(resp)
        return resp.json()

    def discover(
        self,
        capability: Optional[str] = None,
        framework: Optional[str] = None,
        tag: Optional[str] = None,
        text: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> list[AgentCard]:
        """
        Search the registry for agents matching the given filters.
        """
        params: dict[str, Any] = {}
        if capability is not None:
            params["capability"] = capability
        if framework is not None:
            params["framework"] = framework
        if tag is not None:
            params["tag"] = tag
        if text is not None:
            params["text"] = text
        if limit is not None:
            params["limit"] = limit

        resp = self._http.get(f"{self.registry_url}/agents/search", params=params)
        _raise_for_status(resp)
        return [_agent_card_from_dict(d) for d in resp.json()]

    def get_public_key(self) -> str:
        """
        Return the hex-encoded Ed25519 public key derived from the owner key.
        Cached after first call.
        """
        return self._cached_public_key()

    def create_epoch(
        self,
        agent_id: str,
        version: str,
        change_reason: str,
        capability_snapshot: list[str],
    ) -> dict[str, Any]:
        """
        Create a new capability epoch for an agent (v0.2).
        Requires owner auth token.
        """
        headers = self._auth_headers()
        resp = self._http.post(
            f"{self.registry_url}/agents/{agent_id}/epoch",
            json={
                "version": version,
                "change_reason": change_reason,
                "capability_snapshot": capability_snapshot,
            },
            headers=headers,
        )
        _raise_for_status(resp)
        return resp.json()

    def get_epochs(self, agent_id: str) -> list[dict[str, Any]]:
        """
        Get full epoch history for an agent (v0.2).
        """
        resp = self._http.get(f"{self.registry_url}/agents/{agent_id}/epochs")
        _raise_for_status(resp)
        return resp.json()

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _cached_public_key(self) -> str:
        if self._public_key is None:
            self._public_key = derive_public_key(self._private_key)
        return self._public_key

    def _auth_headers(self) -> dict[str, str]:
        if self._owner_auth_token:
            return {"Authorization": f"Bearer {self._owner_auth_token}"}
        return {}

    def _build_signed_card(self, options: RegisterAgentOptions) -> dict[str, Any]:
        """
        Build a signed card per the Carapace spec (v0.1+):
          1. Build full card with verification.signature = ""
          2. JCS-canonicalize
          3. Ed25519-sign
          4. Set verification.signature = base64url(signatureBytes)
          5. Return the complete signed card (signature embedded)
        """
        public_key = self._cached_public_key()
        issued_at = datetime.now(timezone.utc).isoformat()
        signed_at = issued_at

        card: dict[str, Any] = {
            "name": options.name,
            "description": options.description,
            "framework": options.framework,
            "capabilities": [
                {"id": c.id, "name": c.name, "description": c.description}
                for c in options.capabilities
            ],
            "endpoints": [
                {k: v for k, v in {"protocol": e.protocol, "url": e.url, "auth": e.auth}.items() if v is not None}
                for e in options.endpoints
            ],
            "issued_at": issued_at,
            "owner": {"public_key": public_key},
            "verification": {
                "algorithm": "ed25519",
                "public_key": public_key,
                "signed_at": signed_at,
                "signature": "",
            },
        }
        if options.version:
            card["version"] = options.version
        if options.tags:
            card["tags"] = options.tags
        if options.metadata:
            card["metadata"] = options.metadata

        # Canonicalize with signature="" and sign
        canonical = _jcs_canonicalize(card)
        message = canonical.encode("utf-8")

        seed = bytes.fromhex(self._private_key.lstrip("0x") if self._private_key.startswith("0x") else self._private_key)
        signing_key = nacl.signing.SigningKey(seed)
        signed = signing_key.sign(message)
        sig_bytes = signed.signature

        # base64url encode (no padding)
        sig_b64url = base64.urlsafe_b64encode(sig_bytes).rstrip(b"=").decode("ascii")
        card["verification"]["signature"] = sig_b64url

        return card


# ---------------------------------------------------------------------------
# Wire → dataclass helpers
# ---------------------------------------------------------------------------


def _agent_card_from_dict(data: dict[str, Any]) -> AgentCard:
    return AgentCard(
        id=data["id"],
        name=data["name"],
        description=data["description"],
        framework=data["framework"],
        capabilities=[
            Capability(id=c["id"], name=c["name"], description=c["description"])
            for c in data.get("capabilities", [])
        ],
        endpoints=[
            Endpoint(protocol=e["protocol"], url=e["url"], auth=e.get("auth"))
            for e in data.get("endpoints", [])
        ],
        owner=Owner(
            public_key=data["owner"]["public_key"],
            did=data["owner"].get("did"),
        ),
        signature=data.get("signature", ""),
        issued_at=data.get("issued_at", ""),
        updated_at=data.get("updated_at", ""),
        version=data.get("version"),
        tags=data.get("tags", []),
        metadata=data.get("metadata", {}),
    )


def _raise_for_status(resp: httpx.Response) -> None:
    if resp.is_error:
        raise httpx.HTTPStatusError(
            f"ARIA registry error {resp.status_code}: {resp.text}",
            request=resp.request,
            response=resp,
        )
