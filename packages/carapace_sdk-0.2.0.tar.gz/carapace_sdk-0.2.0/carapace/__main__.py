"""
carapace CLI — offline demo, keygen, and version.

Usage:
    python -m carapace demo       # offline demo: keygen → sign → verify → A2A + MCP
    python -m carapace keygen     # generate a new Ed25519 keypair
    python -m carapace version    # print SDK version
    python -m carapace help       # show this help

Or (after pip install):
    carapace demo
    carapace keygen
    carapace version
"""

from __future__ import annotations

import sys
from datetime import datetime, timezone

# ─── ANSI helpers ────────────────────────────────────────────────────────────

# Disable colours if not a TTY or on Windows without ANSI support
_USE_COLOUR = sys.stdout.isatty()


def _wrap(code: str, text: str) -> str:
    return f"\033[{code}m{text}\033[0m" if _USE_COLOUR else text


def green(s: str) -> str:   return _wrap("32", s)
def red(s: str) -> str:     return _wrap("31", s)
def bold(s: str) -> str:    return _wrap("1", s)
def dim(s: str) -> str:     return _wrap("2", s)
def cyan(s: str) -> str:    return _wrap("36", s)


def abbrev(hex_str: str, n: int = 16) -> str:
    """Return the first n + last 8 chars of a hex string with an ellipsis."""
    return hex_str[:n] + "…" + hex_str[-8:]


def check(label: str, ok: bool) -> None:
    print(f"  {'  ' + green('✓') if ok else '  ' + red('✗')} {label}")
    if not ok:
        print(red(f"\nFAIL: {label}"), file=sys.stderr)
        sys.exit(1)


# ─── Commands ────────────────────────────────────────────────────────────────

def cmd_keygen() -> None:
    from .keys import generate_key_pair

    kp = generate_key_pair()
    print()
    print(bold("Ed25519 keypair generated"))
    print(dim("─" * 60))
    print(f"  {cyan('Private key')}  {kp.private_key}")
    print(f"  {cyan('Public key ')}  {kp.public_key}")
    print()
    print(dim("  Store the private key in an env var (CARAPACE_OWNER_KEY)."))
    print(dim("  The public key is embedded in the AgentCard automatically."))
    print()


def cmd_version() -> None:
    try:
        from importlib.metadata import version
        ver = version("carapace-sdk")
    except Exception:
        ver = "unknown"
    print(f"carapace-sdk {ver}")


def cmd_help() -> None:
    print()
    print(bold("carapace CLI"))
    print()
    print("  Commands:")
    print(f"  {cyan('demo')}          Run the offline demo (keygen → sign → verify → A2A + MCP)")
    print(f"  {cyan('keygen')}        Generate a new Ed25519 keypair")
    print(f"  {cyan('version')}       Print SDK version")
    print(f"  {cyan('help')}          Show this help")
    print()
    print("  Quick start:")
    print(f"  {dim('python -m carapace demo')}        # offline demo — no registry needed")
    print(f"  {dim('python -m carapace keygen')}      # generate your owner keypair")
    print()


def cmd_demo() -> None:
    from .keys import generate_key_pair
    from .crypto import sign_payload, verify_payload
    from .a2a import generate_well_known_card
    from .mcp import generate_tools_list
    from .types import AgentCard, AgentOwner, AgentCapability, AgentEndpoint

    print()
    print(bold("Carapace Protocol — offline demo"))
    print(dim("  No registry. No network. Just math."))
    print()

    # ── Step 1: keygen ────────────────────────────────────────────────────────
    print(bold("Step 1: Generate Ed25519 keypair"))
    kp = generate_key_pair()
    print(f"  Private key  {dim(abbrev(kp.private_key))}")
    print(f"  Public key   {dim(abbrev(kp.public_key))}")
    check("keypair generated", len(kp.private_key) == 64 and len(kp.public_key) == 64)
    print()

    # ── Step 2: build card payload ────────────────────────────────────────────
    print(bold("Step 2: Build an agent identity card"))
    card_payload: dict = {
        "name": "DemoAgent",
        "description": "A demonstration agent for the Carapace offline demo.",
        "framework": "carapace-demo",
        "version": "0.1.0",
        "capabilities": [
            {"id": "summarize", "name": "Summarize", "description": "Summarizes text."}
        ],
        "endpoints": [
            {"protocol": "https", "url": "https://demo.example.com/agent", "auth": "none"}
        ],
        "tags": ["demo"],
    }
    check("card built", bool(card_payload["name"]))
    print()

    # ── Step 3: sign ──────────────────────────────────────────────────────────
    print(bold("Step 3: Sign the card (Ed25519 + JCS)"))
    signature = sign_payload(card_payload, kp.private_key)
    print(f"  Signature    {dim(abbrev(signature, 20))}")
    check("signature produced", len(signature) == 128)
    print()

    # ── Step 4: verify ────────────────────────────────────────────────────────
    print(bold("Step 4: Verify the signature (offline)"))
    valid = verify_payload(card_payload, signature, kp.public_key)
    check("signature valid", valid)
    print()

    # ── Step 5: tamper detection ──────────────────────────────────────────────
    print(bold("Step 5: Tamper detection"))
    tampered = {**card_payload, "name": "EvilAgent"}
    rejected = not verify_payload(tampered, signature, kp.public_key)
    check("tampered card rejected", rejected)
    print()

    # ── Step 6: A2A card ──────────────────────────────────────────────────────
    print(bold("Step 6: Generate A2A AgentCard (.well-known/agent.json)"))
    issued = datetime.now(timezone.utc).isoformat()
    full_card = AgentCard(
        id="demo-00000000-0000-0000-0000-000000000000",
        name=card_payload["name"],
        description=card_payload["description"],
        framework=card_payload["framework"],
        version=card_payload.get("version"),
        capabilities=[
            AgentCapability(
                id=c["id"],
                name=c["name"],
                description=c["description"],
            )
            for c in card_payload["capabilities"]
        ],
        endpoints=[
            AgentEndpoint(
                protocol=e["protocol"],
                url=e["url"],
                auth=e.get("auth"),
            )
            for e in card_payload["endpoints"]
        ],
        tags=card_payload.get("tags"),
        owner=AgentOwner(public_key=kp.public_key),
        signature=signature,
        issued_at=issued,
        updated_at=issued,
    )
    a2a_card = generate_well_known_card(full_card)
    check("A2A card name matches", a2a_card.name == "DemoAgent")
    check("x-carapace extension present", a2a_card.extensions is not None and "carapace" in a2a_card.extensions)
    print()

    # ── Step 7: MCP manifest ──────────────────────────────────────────────────
    print(bold("Step 7: Generate MCP tool manifest"))
    mcp = generate_tools_list(full_card)
    check("MCP tools generated", len(mcp.tools) > 0)
    check("tool id matches capability", mcp.tools[0].name == "summarize")
    print()

    # ── Summary ───────────────────────────────────────────────────────────────
    print(dim("─" * 60))
    print(green(bold("  ✓ All checks passed — Carapace SDK is working correctly.")))
    print()
    print(dim("  Next step: register with the live ARIA registry."))
    print(dim("  See https://relayforge.tools for the hosted registry,"))
    print(dim("  or self-host: cd api && ./start.sh"))
    print()


# ─── Entry point ─────────────────────────────────────────────────────────────

def main() -> None:
    cmd = sys.argv[1] if len(sys.argv) > 1 else "help"

    if cmd == "demo":
        cmd_demo()
    elif cmd == "keygen":
        cmd_keygen()
    elif cmd in ("version", "--version", "-v"):
        cmd_version()
    elif cmd in ("help", "--help", "-h"):
        cmd_help()
    else:
        print(red(f"Unknown command: {cmd}"), file=sys.stderr)
        cmd_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
