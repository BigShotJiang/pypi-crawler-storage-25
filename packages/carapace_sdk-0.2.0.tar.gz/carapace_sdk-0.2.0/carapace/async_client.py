"""
Carapace SDK — async client.

Identical surface to :class:`CarapaceClient` but fully async, using
:class:`httpx.AsyncClient` under the hood.  Suitable for FastAPI, LangChain,
CrewAI, OpenClaw, and any other async-first Python framework.

Usage::

    from carapace import AsyncCarapaceClient

    async with AsyncCarapaceClient(
        registry_url="https://api.relayforge.tools/aria/v1",
        owner_private_key=os.environ["CARAPACE_OWNER_KEY"]
    ) as client:

        card = await client.register(
            name="MyAgent",
            description="A helpful research agent",
            framework="langchain",
            capabilities=[{"id": "research", "name": "Research", "description": "Searches topics"}],
            endpoints=[{"protocol": "https", "url": "https://my-server.com/agent"}]
        )

        result = await client.verify(card.id)
        agents = await client.discover(capability="research")

Or manage lifecycle manually::

    client = AsyncCarapaceClient(...)
    await client.__aenter__()
    ...
    await client.__aexit__(None, None, None)

Or inject an existing :class:`httpx.AsyncClient`::

    async with httpx.AsyncClient() as http:
        client = AsyncCarapaceClient(..., http_client=http)
        card = await client.register(...)
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Optional

import httpx

from .crypto import derive_public_key, sign_payload
from .client import _agent_card_from_dict, _raise_for_status
from .types import (
    AgentCard,
    Capability,
    Endpoint,
    RegisterAgentOptions,
    VerifyResult,
)


class AsyncCarapaceClient:
    """
    Async entry point for the Carapace SDK.

    Identical API to :class:`CarapaceClient` but all network calls are
    ``async def``.  Manages its own :class:`httpx.AsyncClient` unless you
    pass one in via ``http_client``.

    :param registry_url: Base URL for the ARIA registry API.
    :param owner_private_key: Hex-encoded Ed25519 private key seed (64 chars).
    :param http_client: Optional :class:`httpx.AsyncClient` to inject (useful in tests).
    """

    def __init__(
        self,
        registry_url: str,
        owner_private_key: str,
        http_client: Optional[httpx.AsyncClient] = None,
    ) -> None:
        self.registry_url = registry_url.rstrip("/")
        self._private_key = owner_private_key
        self._owned_client = http_client is None
        self._http: httpx.AsyncClient = http_client or httpx.AsyncClient(timeout=30.0)
        self._public_key: Optional[str] = None

    # ------------------------------------------------------------------
    # Async context manager
    # ------------------------------------------------------------------

    async def __aenter__(self) -> "AsyncCarapaceClient":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        """Close the underlying HTTP client (only if owned by this instance)."""
        if self._owned_client:
            await self._http.aclose()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def register(
        self,
        name: str,
        description: str,
        framework: str,
        capabilities: list[dict[str, Any]],
        endpoints: list[dict[str, Any]],
        version: Optional[str] = None,
        tags: Optional[list[str]] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> AgentCard:
        """
        Register a new agent with the ARIA registry.

        The SDK automatically:

        - Derives the public key from your private key.
        - Constructs the full identity card.
        - JCS-canonicalizes and Ed25519-signs the card.
        - Sends the signed payload to the registry.

        :returns: The registered :class:`~carapace.types.AgentCard` with the assigned ``id``.
        """
        options = RegisterAgentOptions(
            name=name,
            description=description,
            framework=framework,
            capabilities=[Capability(**c) for c in capabilities],
            endpoints=[Endpoint(**e) for e in endpoints],
            version=version,
            tags=tags or [],
            metadata=metadata or {},
        )
        wire = self._build_signed_payload(options)
        resp = await self._http.post(f"{self.registry_url}/agents/register", json=wire)
        _raise_for_status(resp)
        return _agent_card_from_dict(resp.json())

    async def get_agent(self, agent_id: str) -> AgentCard:
        """
        Fetch a single agent card by ID from the registry.

        :param agent_id: The agent's registry UUID.
        :returns: The :class:`~carapace.types.AgentCard` for the given ID.
        :raises httpx.HTTPStatusError: If the agent is not found or the registry returns an error.
        """
        resp = await self._http.get(f"{self.registry_url}/agents/{agent_id}")
        _raise_for_status(resp)
        return _agent_card_from_dict(resp.json())

    async def verify(self, agent_id: str) -> VerifyResult:
        """
        Ask the ARIA registry to verify an agent's signature.

        :param agent_id: The agent's registry UUID.
        :returns: :class:`~carapace.types.VerifyResult` with ``verified`` bool.
        """
        resp = await self._http.post(f"{self.registry_url}/agents/{agent_id}/verify")
        _raise_for_status(resp)
        data = resp.json()
        return VerifyResult(
            agent_id=data["agent_id"],
            verified=data["verified"],
            reason=data.get("reason"),
        )

    async def discover(
        self,
        capability: Optional[str] = None,
        framework: Optional[str] = None,
        tag: Optional[str] = None,
        text: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> list[AgentCard]:
        """
        Search the registry for agents matching the given filters.
        All filters are optional — omit to list all agents.

        :returns: List of matching :class:`~carapace.types.AgentCard` objects.
        """
        params: dict[str, Any] = {}
        if capability is not None:
            params["capability"] = capability
        if framework is not None:
            params["framework"] = framework
        if tag is not None:
            params["tag"] = tag
        if text is not None:
            params["text"] = text
        if limit is not None:
            params["limit"] = limit

        resp = await self._http.get(
            f"{self.registry_url}/agents/search", params=params
        )
        _raise_for_status(resp)
        return [_agent_card_from_dict(d) for d in resp.json()]

    async def get_public_key(self) -> str:
        """
        Return the hex-encoded Ed25519 public key derived from the owner key.
        Cached after first call.
        """
        return self._cached_public_key()

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _cached_public_key(self) -> str:
        if self._public_key is None:
            self._public_key = derive_public_key(self._private_key)
        return self._public_key

    def _build_signed_payload(self, options: RegisterAgentOptions) -> dict[str, Any]:
        """Build the signed wire payload (sync — crypto is CPU-bound, not I/O)."""
        public_key = self._cached_public_key()
        issued_at = datetime.now(timezone.utc).isoformat()

        unsigned_card: dict[str, Any] = {
            "name": options.name,
            "description": options.description,
            "framework": options.framework,
            "capabilities": [
                {"id": c.id, "name": c.name, "description": c.description}
                for c in options.capabilities
            ],
            "endpoints": [
                {
                    k: v
                    for k, v in {
                        "protocol": e.protocol,
                        "url": e.url,
                        "auth": e.auth,
                    }.items()
                    if v is not None
                }
                for e in options.endpoints
            ],
            "issued_at": issued_at,
            "owner": {"public_key": public_key},
        }
        if options.version:
            unsigned_card["version"] = options.version
        if options.tags:
            unsigned_card["tags"] = options.tags
        if options.metadata:
            unsigned_card["metadata"] = options.metadata

        signature = sign_payload(unsigned_card, self._private_key)
        return {"card": unsigned_card, "signature": signature}
