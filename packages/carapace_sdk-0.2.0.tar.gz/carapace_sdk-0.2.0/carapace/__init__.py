"""
Carapace SDK for Python.

Federated agent identity in a single function call.

Quick start::

    from carapace import Carapace

    client = Carapace(
        registry_url="https://api.relayforge.tools/aria/v1",
        owner_key=os.environ["CARAPACE_OWNER_KEY"]
    )

Or using the lower-level client::

    from carapace import CarapaceClient

    client = CarapaceClient(
        registry_url="https://api.relayforge.tools/aria/v1",
        owner_private_key=os.environ["CARAPACE_OWNER_KEY"]
    )

    card = client.register(
        name="MyAgent",
        description="Does useful things",
        framework="langchain",
        capabilities=[{"id": "research", "name": "Research", "description": "Searches topics"}],
        endpoints=[{"protocol": "https", "url": "https://my-agent.example.com"}]
    )

Key generation::

    from carapace.keys import generate_key_pair
    kp = generate_key_pair()
    # store kp.private_key securely; kp.public_key is safe to share

A2A compatibility::

    from carapace.a2a import generate_well_known_card
    a2a_card = generate_well_known_card(card)
    # serve a2a_card.to_dict() as JSON at /.well-known/agent.json

MCP tool export::

    from carapace.mcp import generate_tools_list
    tools_response = generate_tools_list(card)
    # tools_response.to_dict() returns the MCP tools/list wire format
    # tools_response.to_dict()["tools"] is a list of MCPTool dicts
"""

from .carapace import Carapace
from .client import CarapaceClient
from .async_client import AsyncCarapaceClient
from .keys import generate_key_pair, KeyPair
from .types import (
    AgentCard,
    Capability,
    DiscoverFilters,
    Endpoint,
    Owner,
    RegisterAgentOptions,
    VerifyResult,
)
from .a2a import A2AAgentCard, A2ASkill, A2ASecurityScheme, generate_well_known_card, A2A_PROTOCOL_VERSION
from .mcp import (
    MCPTool,
    MCPToolInputSchema,
    MCPToolsListResponse,
    generate_tools_list,
    generate_mcp_server_config,
)
from .crypto import sign_payload, verify_payload, derive_public_key

__all__ = [
    # Convenience class (directive-spec API)
    "Carapace",
    # Main client (sync)
    "CarapaceClient",
    # Async client
    "AsyncCarapaceClient",
    # Key management
    "generate_key_pair",
    "KeyPair",
    # Types
    "AgentCard",
    "Capability",
    "DiscoverFilters",
    "Endpoint",
    "Owner",
    "RegisterAgentOptions",
    "VerifyResult",
    # A2A
    "A2AAgentCard",
    "A2ASkill",
    "A2ASecurityScheme",
    "A2A_PROTOCOL_VERSION",
    "generate_well_known_card",
    # MCP
    "MCPTool",
    "MCPToolInputSchema",
    "MCPToolsListResponse",
    "generate_tools_list",
    "generate_mcp_server_config",
    # Crypto (advanced use)
    "sign_payload",
    "verify_payload",
    "derive_public_key",
]

__version__ = "0.1.0"
