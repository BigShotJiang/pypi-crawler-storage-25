"""
Carapace SDK — cryptographic helpers.

Uses PyNaCl (libsodium) for Ed25519 signing/verification and
json-canonicalize (jcs) for deterministic JSON serialization (JCS).

Both match the JS SDK's cryptographic contract:
  - Private keys are 32-byte seeds (hex-encoded, 64 chars).
  - Public keys are 32-byte Ed25519 points (hex-encoded, 64 chars).
  - Signatures are 64-byte values (hex-encoded, 128 chars).
  - Payloads are JCS-canonicalized then UTF-8 encoded before signing.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import re
from typing import Any

# PyNaCl
import nacl.encoding
import nacl.signing


# ---------------------------------------------------------------------------
# Public helpers
# ---------------------------------------------------------------------------


def sign_payload(payload: Any, private_key_hex: str) -> str:
    """
    Sign an arbitrary JSON-serialisable payload.

    The payload is first JCS-canonicalized so the signature is deterministic
    regardless of key ordering.

    :param payload: Any JSON-serialisable value.
    :param private_key_hex: Hex-encoded Ed25519 private key seed (64 chars).
    :returns: Hex-encoded 64-byte signature.
    """
    canonical = _jcs_canonicalize(payload)
    message = canonical.encode("utf-8")

    seed = bytes.fromhex(_normalize_hex(private_key_hex))
    signing_key = nacl.signing.SigningKey(seed)
    signed = signing_key.sign(message)
    # nacl returns prefix + signature; signature is the last 64 bytes
    signature_bytes = signed.signature
    return signature_bytes.hex()


def verify_payload(payload: Any, signature_hex: str, public_key_hex: str) -> bool:
    """
    Verify a signature produced by :func:`sign_payload`.

    :param payload: The original JSON payload that was signed.
    :param signature_hex: Hex-encoded 64-byte signature.
    :param public_key_hex: Hex-encoded Ed25519 public key (64 chars).
    :returns: True if the signature is valid, False otherwise.
    """
    try:
        canonical = _jcs_canonicalize(payload)
        message = canonical.encode("utf-8")

        sig_bytes = bytes.fromhex(_normalize_hex(signature_hex))
        pub_bytes = bytes.fromhex(_normalize_hex(public_key_hex))

        verify_key = nacl.signing.VerifyKey(pub_bytes)
        verify_key.verify(message, sig_bytes)
        return True
    except Exception:
        return False


def derive_public_key(private_key_hex: str) -> str:
    """
    Derive the hex-encoded Ed25519 public key from a hex-encoded private key seed.

    :param private_key_hex: Hex-encoded 32-byte seed (64 chars).
    :returns: Hex-encoded 32-byte public key (64 chars).
    """
    seed = bytes.fromhex(_normalize_hex(private_key_hex))
    signing_key = nacl.signing.SigningKey(seed)
    return bytes(signing_key.verify_key).hex()


# ---------------------------------------------------------------------------
# Internal utilities
# ---------------------------------------------------------------------------


def _normalize_hex(key: str) -> str:
    """Strip optional '0x' prefix."""
    return key[2:] if key.startswith("0x") else key


def _jcs_canonicalize(obj: Any) -> str:
    """
    RFC 8785 JSON Canonicalization Scheme (JCS).

    Produces a deterministic UTF-8 string:
      - Keys sorted lexicographically (recursive).
      - No insignificant whitespace.
      - Unicode escapes only where required.

    This matches the behaviour of the `json-canonicalize` npm package used
    by the JS SDK, ensuring cross-language signature compatibility.
    """
    return _serialize(obj)


def _serialize(obj: Any) -> str:
    if obj is None:
        return "null"
    if isinstance(obj, bool):
        return "true" if obj else "false"
    if isinstance(obj, int):
        return str(obj)
    if isinstance(obj, float):
        return _serialize_float(obj)
    if isinstance(obj, str):
        return json.dumps(obj, ensure_ascii=False)
    if isinstance(obj, (list, tuple)):
        items = ",".join(_serialize(v) for v in obj)
        return f"[{items}]"
    if isinstance(obj, dict):
        pairs = ",".join(
            f"{json.dumps(k, ensure_ascii=False)}:{_serialize(v)}"
            for k, v in sorted(obj.items())
        )
        return "{" + pairs + "}"
    raise TypeError(f"Object of type {type(obj)} is not JCS serializable")


def _serialize_float(value: float) -> str:
    """
    Serialize a float following RFC 8785 §3.2.2.3.
    Uses Python's repr to get full precision, then strips trailing zeros.
    """
    import math

    if math.isnan(value) or math.isinf(value):
        raise ValueError("NaN and Infinity are not valid JSON values")

    # Use repr for lossless round-trip, then normalize
    s = repr(value)
    # Python repr may produce 'e' notation; keep as-is — it matches JS behavior
    return s
