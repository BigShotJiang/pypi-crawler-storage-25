"""
Carapace SDK — MCP (Model Context Protocol) compatibility helpers.

Converts a Carapace AgentCard into an MCP-compatible ``tools/list``
response payload.  This is a *client-side, offline* helper — no network
call is made.  The result can be served from any MCP server's
``tools/list`` handler or embedded in a static config file.

Reference: carapace-protocol/docs/mcp-compatibility.md

What's supported here (v0.1.0):
  - ``generate_tools_list`` — map Carapace capabilities → MCP tool definitions
  - ``generate_mcp_server_config`` — produce a minimal MCP server config stub
    that can be dropped into ``claude_desktop_config.json`` or VS Code settings

What's intentionally NOT included (v0.2.0+):
  - Full MCP shim server (stdin/stdout JSON-RPC transport)
  - Async polling workarounds
  - Identity forwarding (MCP has no identity layer)

See ``docs/mcp-compatibility.md`` for the full design rationale.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

from .types import AgentCard, Capability


# ---------------------------------------------------------------------------
# MCP types
# ---------------------------------------------------------------------------


@dataclass
class MCPToolInputSchema:
    """JSON Schema for an MCP tool's input.

    When a Carapace capability carries an ``input_schema`` in its metadata,
    that schema is used verbatim.  Otherwise a minimal open schema is
    generated with a single ``input`` string property so the tool is
    callable without requiring any specific arguments.
    """

    type: str = "object"
    properties: dict[str, Any] = field(default_factory=dict)
    required: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"type": self.type}
        if self.properties:
            d["properties"] = self.properties
        if self.required:
            d["required"] = self.required
        return d


@dataclass
class MCPTool:
    """Minimal MCP tool definition (``tools/list`` item).

    Only the fields that MCP hosts universally consume are included.
    The ``x_carapace`` extension embeds provenance info for hosts that
    support custom extensions.
    """

    name: str
    description: str
    input_schema: MCPToolInputSchema
    x_carapace: Optional[dict[str, Any]] = None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "name": self.name,
            "description": self.description,
            "inputSchema": self.input_schema.to_dict(),
        }
        if self.x_carapace:
            d["x-carapace"] = self.x_carapace
        return d


@dataclass
class MCPToolsListResponse:
    """Full ``tools/list`` JSON-RPC response payload."""

    tools: list[MCPTool]
    # Metadata for informational use — not part of the MCP wire format
    agent_name: str = ""
    agent_id: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Return the MCP wire-format ``tools/list`` result object."""
        return {"tools": [t.to_dict() for t in self.tools]}


# ---------------------------------------------------------------------------
# Converter
# ---------------------------------------------------------------------------


def generate_tools_list(card: AgentCard) -> MCPToolsListResponse:
    """
    Convert a :class:`~carapace.types.AgentCard` into an MCP
    ``tools/list`` response payload.

    Each Carapace capability becomes one MCP tool:
      - ``capability.id`` → ``tool.name`` (sanitized to snake_case)
      - ``capability.description`` → ``tool.description``
      - ``capability metadata.input_schema`` → ``tool.inputSchema`` (if present)
      - Provenance extension attached under ``x-carapace``

    **Usage**

    .. code-block:: python

        from carapace.mcp import generate_tools_list
        import json

        tools_response = generate_tools_list(card)
        # In an MCP server's tools/list handler:
        return tools_response.to_dict()

        # Or dump to a file for static config:
        with open("tools.json", "w") as f:
            json.dump(tools_response.to_dict(), f, indent=2)

    :param card: A Carapace agent card (registered or locally constructed).
    :returns: An :class:`MCPToolsListResponse` with one tool per capability.
    """
    tools: list[MCPTool] = []

    for cap in card.capabilities:
        tool_name = _sanitize_tool_name(cap.id)
        input_schema = _extract_input_schema(cap)

        x_carapace: dict[str, Any] = {
            "capabilityId": cap.id,
            "agentId": card.id,
            "ownerPublicKey": card.owner.public_key,
        }

        tools.append(
            MCPTool(
                name=tool_name,
                description=cap.description,
                input_schema=input_schema,
                x_carapace=x_carapace,
            )
        )

    return MCPToolsListResponse(
        tools=tools,
        agent_name=card.name,
        agent_id=card.id,
    )


def generate_mcp_server_config(
    card: AgentCard,
    command: Optional[str] = None,
    args: Optional[list[str]] = None,
    env: Optional[dict[str, str]] = None,
) -> dict[str, Any]:
    """
    Generate a minimal MCP server config stub for ``claude_desktop_config.json``
    or VS Code MCP settings.

    The result is a dict suitable for inclusion in:

    .. code-block:: json

        {
          "mcpServers": {
            "<server_name>": { ... }
          }
        }

    :param card:    The Carapace agent card to derive metadata from.
    :param command: The executable to launch as an MCP server.
                    Defaults to ``"carapace-mcp-shim"`` (placeholder).
    :param args:    CLI args for the command.
    :param env:     Environment variable overrides (e.g. API keys).
    :returns: A single MCP server config entry (not the full config file).
    """
    server_name = _sanitize_tool_name(card.name)
    config: dict[str, Any] = {
        "command": command or "carapace-mcp-shim",
        "args": args or [f"--agent-id={card.id}"],
        "env": env or {},
        "metadata": {
            "description": card.description,
            "carapaceAgentId": card.id,
            "ownerPublicKey": card.owner.public_key,
        },
    }
    return {server_name: config}


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _sanitize_tool_name(name: str) -> str:
    """
    Convert an arbitrary identifier to a valid MCP tool name.

    MCP tool names must be ``[a-zA-Z0-9_-]+``.  Spaces and dots become
    underscores; other non-alphanumeric characters are stripped.
    """
    sanitized = name.replace(" ", "_").replace("-", "_").replace(".", "_")
    return "".join(c for c in sanitized if c.isalnum() or c in "_")


def _extract_input_schema(cap: Capability) -> MCPToolInputSchema:
    """
    Extract or generate an MCP input schema from a Carapace capability.

    If the capability has no metadata schema we emit a minimal open schema
    with a single string ``input`` field so the tool is always callable.
    """
    # In future schema versions, capabilities may have an explicit
    # ``input_schema`` field.  For now, check the metadata dict.
    # (Carapace types.py Capability doesn't carry metadata yet — placeholder.)
    return MCPToolInputSchema(
        type="object",
        properties={"input": {"type": "string", "description": f"Input for the {cap.name} capability"}},
        required=[],
    )
