"""
Tests for carapace.mcp — MCP tool definition export.
"""

import pytest
from carapace.mcp import (
    MCPToolInputSchema,
    MCPTool,
    MCPToolsListResponse,
    generate_tools_list,
    generate_mcp_server_config,
    _sanitize_tool_name,
)
from carapace.types import AgentCard, Capability, Endpoint, Owner


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


_DEFAULT_CAPABILITIES = [
    Capability(id="code_review", name="Code Review", description="Reviews code for bugs and security issues"),
    Capability(id="summarize", name="Summarize", description="Summarizes long documents"),
]

_SENTINEL = object()


def make_card(capabilities=_SENTINEL, endpoints=None, agent_id="test-uuid-1234") -> AgentCard:
    resolved_caps = _DEFAULT_CAPABILITIES if capabilities is _SENTINEL else capabilities
    return AgentCard(
        id=agent_id,
        name="TestAgent",
        description="A test agent for MCP export",
        framework="langchain",
        capabilities=resolved_caps,
        endpoints=endpoints or [
            Endpoint(protocol="https", url="https://my-agent.example.com")
        ],
        owner=Owner(public_key="abc123deadbeef"),
        signature="fakesig",
        issued_at="2026-03-16T00:00:00Z",
        updated_at="2026-03-16T00:00:00Z",
    )


# ---------------------------------------------------------------------------
# _sanitize_tool_name
# ---------------------------------------------------------------------------


class TestSanitizeToolName:
    def test_simple_id_unchanged(self):
        assert _sanitize_tool_name("code_review") == "code_review"

    def test_spaces_become_underscores(self):
        assert _sanitize_tool_name("code review") == "code_review"

    def test_hyphens_become_underscores(self):
        assert _sanitize_tool_name("code-review") == "code_review"

    def test_dots_become_underscores(self):
        assert _sanitize_tool_name("review.code") == "review_code"

    def test_special_chars_stripped(self):
        assert _sanitize_tool_name("code@review!") == "codereview"

    def test_mixed(self):
        assert _sanitize_tool_name("My Agent Tool v2.0") == "My_Agent_Tool_v2_0"


# ---------------------------------------------------------------------------
# generate_tools_list
# ---------------------------------------------------------------------------


class TestGenerateToolsList:
    def test_returns_response_object(self):
        card = make_card()
        result = generate_tools_list(card)
        assert isinstance(result, MCPToolsListResponse)

    def test_one_tool_per_capability(self):
        card = make_card()
        result = generate_tools_list(card)
        assert len(result.tools) == 2

    def test_tool_names_match_capability_ids(self):
        card = make_card()
        result = generate_tools_list(card)
        assert result.tools[0].name == "code_review"
        assert result.tools[1].name == "summarize"

    def test_tool_descriptions_match_capability_descriptions(self):
        card = make_card()
        result = generate_tools_list(card)
        assert result.tools[0].description == "Reviews code for bugs and security issues"

    def test_agent_metadata_attached(self):
        card = make_card()
        result = generate_tools_list(card)
        assert result.agent_name == "TestAgent"
        assert result.agent_id == "test-uuid-1234"

    def test_x_carapace_provenance_in_each_tool(self):
        card = make_card()
        result = generate_tools_list(card)
        xc = result.tools[0].x_carapace
        assert xc["capabilityId"] == "code_review"
        assert xc["agentId"] == "test-uuid-1234"
        assert xc["ownerPublicKey"] == "abc123deadbeef"

    def test_input_schema_is_mcp_schema_object(self):
        card = make_card()
        result = generate_tools_list(card)
        schema = result.tools[0].input_schema
        assert isinstance(schema, MCPToolInputSchema)
        assert schema.type == "object"
        assert "input" in schema.properties

    def test_empty_capabilities_yields_empty_tools(self):
        card = make_card(capabilities=[])
        result = generate_tools_list(card)
        assert result.tools == []

    def test_single_capability(self):
        card = make_card(capabilities=[
            Capability(id="search", name="Search", description="Searches the web")
        ])
        result = generate_tools_list(card)
        assert len(result.tools) == 1
        assert result.tools[0].name == "search"

    def test_capability_id_with_spaces_sanitized(self):
        card = make_card(capabilities=[
            Capability(id="my capability", name="My Cap", description="desc")
        ])
        result = generate_tools_list(card)
        assert result.tools[0].name == "my_capability"


# ---------------------------------------------------------------------------
# MCPToolsListResponse.to_dict (MCP wire format)
# ---------------------------------------------------------------------------


class TestToolsListToDict:
    def test_to_dict_has_tools_key(self):
        card = make_card()
        result = generate_tools_list(card)
        d = result.to_dict()
        assert "tools" in d
        assert isinstance(d["tools"], list)

    def test_to_dict_tool_has_required_fields(self):
        card = make_card()
        result = generate_tools_list(card)
        tool_dict = result.to_dict()["tools"][0]
        assert "name" in tool_dict
        assert "description" in tool_dict
        assert "inputSchema" in tool_dict

    def test_to_dict_input_schema_structure(self):
        card = make_card()
        result = generate_tools_list(card)
        schema = result.to_dict()["tools"][0]["inputSchema"]
        assert schema["type"] == "object"
        assert "properties" in schema

    def test_to_dict_x_carapace_extension_present(self):
        card = make_card()
        result = generate_tools_list(card)
        tool_dict = result.to_dict()["tools"][0]
        assert "x-carapace" in tool_dict

    def test_to_dict_no_agent_metadata(self):
        """Wire format must NOT include agent_name / agent_id at top level."""
        card = make_card()
        result = generate_tools_list(card)
        d = result.to_dict()
        assert "agent_name" not in d
        assert "agent_id" not in d


# ---------------------------------------------------------------------------
# generate_mcp_server_config
# ---------------------------------------------------------------------------


class TestGenerateMcpServerConfig:
    def test_returns_dict_with_server_name_key(self):
        card = make_card()
        config = generate_mcp_server_config(card)
        assert isinstance(config, dict)
        assert len(config) == 1

    def test_server_name_derived_from_agent_name(self):
        card = make_card()
        config = generate_mcp_server_config(card)
        assert "TestAgent" in config  # spaces become underscores but name is single word here

    def test_default_command_is_placeholder(self):
        card = make_card()
        config = generate_mcp_server_config(card)
        server = list(config.values())[0]
        assert server["command"] == "carapace-mcp-shim"

    def test_custom_command_respected(self):
        card = make_card()
        config = generate_mcp_server_config(card, command="npx carapace-server", args=["--port=8080"])
        server = list(config.values())[0]
        assert server["command"] == "npx carapace-server"
        assert "--port=8080" in server["args"]

    def test_metadata_contains_agent_id(self):
        card = make_card()
        config = generate_mcp_server_config(card)
        metadata = list(config.values())[0]["metadata"]
        assert metadata["carapaceAgentId"] == "test-uuid-1234"

    def test_env_dict_present(self):
        card = make_card()
        config = generate_mcp_server_config(card, env={"API_KEY": "secret"})
        server = list(config.values())[0]
        assert server["env"]["API_KEY"] == "secret"
