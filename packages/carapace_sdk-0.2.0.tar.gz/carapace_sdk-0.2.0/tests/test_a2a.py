"""
Tests for carapace.a2a — Carapace → A2A card conversion.
"""

import pytest
from carapace.a2a import generate_well_known_card, A2AAgentCard, A2A_PROTOCOL_VERSION
from carapace.types import AgentCard, Capability, Endpoint, Owner


def _make_card(**kwargs) -> AgentCard:
    defaults = dict(
        id="test-uuid",
        name="TestAgent",
        description="A test agent",
        framework="openclaw",
        capabilities=[Capability(id="research", name="Research", description="Searches topics")],
        endpoints=[Endpoint(protocol="https", url="https://agent.example.com")],
        owner=Owner(public_key="ab" * 32),
        signature="ef" * 64,
        issued_at="2026-03-16T00:00:00Z",
        updated_at="2026-03-16T00:00:00Z",
    )
    defaults.update(kwargs)
    return AgentCard(**defaults)


class TestGenerateWellKnownCard:
    def test_returns_a2a_agent_card(self):
        card = _make_card()
        result = generate_well_known_card(card)
        assert isinstance(result, A2AAgentCard)

    def test_protocol_version_set(self):
        """A2A spec 1.0 requires protocolVersion field."""
        card = _make_card()
        result = generate_well_known_card(card)
        assert result.protocol_version == A2A_PROTOCOL_VERSION
        assert result.protocol_version == "1.0"
        d = result.to_dict()
        assert d["protocolVersion"] == "1.0"

    def test_name_and_description_preserved(self):
        card = _make_card(name="MyBot", description="Does stuff")
        result = generate_well_known_card(card)
        assert result.name == "MyBot"
        assert result.description == "Does stuff"

    def test_prefers_a2a_protocol_endpoint(self):
        card = _make_card(endpoints=[
            Endpoint(protocol="https", url="https://fallback.example.com"),
            Endpoint(protocol="a2a", url="https://a2a.example.com"),
        ])
        result = generate_well_known_card(card)
        assert result.url == "https://a2a.example.com"

    def test_falls_back_to_first_endpoint(self):
        card = _make_card(endpoints=[
            Endpoint(protocol="https", url="https://first.example.com"),
            Endpoint(protocol="mcp", url="https://second.example.com"),
        ])
        result = generate_well_known_card(card)
        assert result.url == "https://first.example.com"

    def test_capabilities_become_skills(self):
        card = _make_card(capabilities=[
            Capability(id="search", name="Search", description="Searches"),
            Capability(id="summarize", name="Summarize", description="Summarizes"),
        ])
        result = generate_well_known_card(card)
        assert len(result.skills) == 2
        assert result.skills[0].id == "search"
        assert result.skills[1].id == "summarize"

    def test_auth_none_maps_to_none_scheme(self):
        card = _make_card(endpoints=[Endpoint(protocol="https", url="https://x.test", auth="none")])
        result = generate_well_known_card(card)
        assert "none" in result.security_schemes

    def test_auth_api_key_maps_to_apiKey_scheme(self):
        card = _make_card(endpoints=[Endpoint(protocol="https", url="https://x.test", auth="api_key")])
        result = generate_well_known_card(card)
        assert "apiKey" in result.security_schemes

    def test_auth_oauth2_maps_to_oauth2_scheme(self):
        card = _make_card(endpoints=[Endpoint(protocol="https", url="https://x.test", auth="oauth2")])
        result = generate_well_known_card(card)
        assert "oauth2" in result.security_schemes

    def test_deduplicates_security_schemes(self):
        card = _make_card(endpoints=[
            Endpoint(protocol="a2a", url="https://a.test", auth="api_key"),
            Endpoint(protocol="https", url="https://b.test", auth="api_key"),
        ])
        result = generate_well_known_card(card)
        assert len(result.security_schemes) == 1

    def test_x_carapace_extension_embeds_owner_key(self):
        card = _make_card()
        result = generate_well_known_card(card)
        assert result.x_carapace["ownerPublicKey"] == "ab" * 32

    def test_x_carapace_extension_embeds_registry_id(self):
        card = _make_card(id="specific-registry-id")
        result = generate_well_known_card(card)
        assert result.x_carapace["registryId"] == "specific-registry-id"

    def test_x_carapace_extension_embeds_issued_at(self):
        """issuedAt must be present for JS/Python x-carapace parity."""
        card = _make_card(issued_at="2026-03-17T22:00:00Z")
        result = generate_well_known_card(card)
        assert result.x_carapace["issuedAt"] == "2026-03-17T22:00:00Z"

    def test_version_is_preserved(self):
        card = _make_card(version="3.0.0")
        result = generate_well_known_card(card)
        assert result.version == "3.0.0"

    def test_version_defaults_to_0_1_0_when_none(self):
        card = _make_card(version=None)
        result = generate_well_known_card(card)
        assert result.version == "0.1.0"

    def test_to_dict_produces_valid_structure(self):
        card = _make_card()
        result = generate_well_known_card(card)
        d = result.to_dict()
        assert "name" in d
        assert "description" in d
        assert "url" in d
        assert "version" in d
        assert "skills" in d
        assert "securitySchemes" in d
        assert "x-carapace" in d
