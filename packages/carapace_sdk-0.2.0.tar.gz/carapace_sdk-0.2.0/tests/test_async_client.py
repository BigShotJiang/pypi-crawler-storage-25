"""
Tests for AsyncCarapaceClient.

These tests mirror test_client.py but exercise the async surface.
All HTTP is intercepted via respx so no real network is required.
"""
import pytest
import respx
import httpx

from carapace import AsyncCarapaceClient
from carapace.keys import generate_key_pair


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def keypair():
    return generate_key_pair()


@pytest.fixture
def registry_url():
    return "https://registry.test/aria/v1"


@pytest.fixture
def minimal_register_kwargs():
    return dict(
        name="AsyncTestAgent",
        description="Tests the async client",
        framework="langchain",
        capabilities=[{"id": "query", "name": "Query", "description": "Runs queries"}],
        endpoints=[{"protocol": "https", "url": "https://agent.example.com"}],
    )


FAKE_CARD = {
    "id": "async-uuid-1234",
    "name": "AsyncTestAgent",
    "description": "Tests the async client",
    "framework": "langchain",
    "capabilities": [{"id": "query", "name": "Query", "description": "Runs queries"}],
    "endpoints": [{"protocol": "https", "url": "https://agent.example.com"}],
    "owner": {"public_key": "a" * 64},
    "signature": "b" * 128,
    "issued_at": "2026-03-17T00:00:00+00:00",
    "updated_at": "2026-03-17T00:00:00+00:00",
}


# ---------------------------------------------------------------------------
# Context manager
# ---------------------------------------------------------------------------

class TestContextManager:
    @pytest.mark.asyncio
    async def test_async_context_manager(self, keypair, registry_url):
        async with AsyncCarapaceClient(
            registry_url=registry_url,
            owner_private_key=keypair.private_key,
        ) as client:
            assert isinstance(client, AsyncCarapaceClient)

    @pytest.mark.asyncio
    async def test_injected_client_not_closed(self, keypair, registry_url):
        """When http_client is injected, aclose() must not close it."""
        http = httpx.AsyncClient()
        client = AsyncCarapaceClient(
            registry_url=registry_url,
            owner_private_key=keypair.private_key,
            http_client=http,
        )
        await client.aclose()
        assert not http.is_closed
        await http.aclose()


# ---------------------------------------------------------------------------
# register
# ---------------------------------------------------------------------------

class TestRegister:
    @pytest.mark.asyncio
    @respx.mock
    async def test_register_returns_agent_card(self, keypair, registry_url, minimal_register_kwargs):
        respx.post(f"{registry_url}/agents/register").mock(
            return_value=httpx.Response(201, json=FAKE_CARD)
        )
        async with AsyncCarapaceClient(registry_url=registry_url, owner_private_key=keypair.private_key) as client:
            card = await client.register(**minimal_register_kwargs)
        assert card.id == "async-uuid-1234"
        assert card.name == "AsyncTestAgent"

    @pytest.mark.asyncio
    @respx.mock
    async def test_register_posts_signed_payload(self, keypair, registry_url, minimal_register_kwargs):
        route = respx.post(f"{registry_url}/agents/register").mock(
            return_value=httpx.Response(201, json=FAKE_CARD)
        )
        async with AsyncCarapaceClient(registry_url=registry_url, owner_private_key=keypair.private_key) as client:
            await client.register(**minimal_register_kwargs)
        body = route.calls[0].request.content
        import json
        payload = json.loads(body)
        assert "card" in payload
        assert "signature" in payload
        assert payload["card"]["name"] == "AsyncTestAgent"

    @pytest.mark.asyncio
    @respx.mock
    async def test_register_raises_on_error(self, keypair, registry_url, minimal_register_kwargs):
        respx.post(f"{registry_url}/agents/register").mock(
            return_value=httpx.Response(400, text="bad request")
        )
        with pytest.raises(httpx.HTTPStatusError):
            async with AsyncCarapaceClient(registry_url=registry_url, owner_private_key=keypair.private_key) as client:
                await client.register(**minimal_register_kwargs)


# ---------------------------------------------------------------------------
# get_agent
# ---------------------------------------------------------------------------

class TestGetAgent:
    @pytest.mark.asyncio
    @respx.mock
    async def test_get_agent_returns_card(self, keypair, registry_url):
        respx.get(f"{registry_url}/agents/async-uuid-1234").mock(
            return_value=httpx.Response(200, json=FAKE_CARD)
        )
        async with AsyncCarapaceClient(registry_url=registry_url, owner_private_key=keypair.private_key) as client:
            card = await client.get_agent("async-uuid-1234")
        assert card.id == "async-uuid-1234"

    @pytest.mark.asyncio
    @respx.mock
    async def test_get_agent_raises_on_404(self, keypair, registry_url):
        respx.get(f"{registry_url}/agents/missing").mock(
            return_value=httpx.Response(404, text="not found")
        )
        with pytest.raises(httpx.HTTPStatusError):
            async with AsyncCarapaceClient(registry_url=registry_url, owner_private_key=keypair.private_key) as client:
                await client.get_agent("missing")


# ---------------------------------------------------------------------------
# verify
# ---------------------------------------------------------------------------

class TestVerify:
    @pytest.mark.asyncio
    @respx.mock
    async def test_verify_returns_verified_true(self, keypair, registry_url):
        respx.post(f"{registry_url}/agents/async-uuid-1234/verify").mock(
            return_value=httpx.Response(200, json={"agent_id": "async-uuid-1234", "verified": True})
        )
        async with AsyncCarapaceClient(registry_url=registry_url, owner_private_key=keypair.private_key) as client:
            result = await client.verify("async-uuid-1234")
        assert result.verified is True
        assert result.agent_id == "async-uuid-1234"

    @pytest.mark.asyncio
    @respx.mock
    async def test_verify_returns_verified_false(self, keypair, registry_url):
        respx.post(f"{registry_url}/agents/async-uuid-1234/verify").mock(
            return_value=httpx.Response(200, json={
                "agent_id": "async-uuid-1234",
                "verified": False,
                "reason": "signature mismatch"
            })
        )
        async with AsyncCarapaceClient(registry_url=registry_url, owner_private_key=keypair.private_key) as client:
            result = await client.verify("async-uuid-1234")
        assert result.verified is False
        assert result.reason == "signature mismatch"


# ---------------------------------------------------------------------------
# discover
# ---------------------------------------------------------------------------

class TestDiscover:
    @pytest.mark.asyncio
    @respx.mock
    async def test_discover_returns_list(self, keypair, registry_url):
        respx.get(f"{registry_url}/agents/search").mock(
            return_value=httpx.Response(200, json=[FAKE_CARD, FAKE_CARD])
        )
        async with AsyncCarapaceClient(registry_url=registry_url, owner_private_key=keypair.private_key) as client:
            agents = await client.discover()
        assert len(agents) == 2

    @pytest.mark.asyncio
    @respx.mock
    async def test_discover_passes_filters(self, keypair, registry_url):
        route = respx.get(f"{registry_url}/agents/search").mock(
            return_value=httpx.Response(200, json=[])
        )
        async with AsyncCarapaceClient(registry_url=registry_url, owner_private_key=keypair.private_key) as client:
            await client.discover(capability="research", framework="langchain", limit=5)
        qs = str(route.calls[0].request.url)
        assert "capability=research" in qs
        assert "framework=langchain" in qs
        assert "limit=5" in qs

    @pytest.mark.asyncio
    @respx.mock
    async def test_discover_returns_empty_list(self, keypair, registry_url):
        respx.get(f"{registry_url}/agents/search").mock(
            return_value=httpx.Response(200, json=[])
        )
        async with AsyncCarapaceClient(registry_url=registry_url, owner_private_key=keypair.private_key) as client:
            agents = await client.discover()
        assert agents == []


# ---------------------------------------------------------------------------
# get_public_key
# ---------------------------------------------------------------------------

class TestGetPublicKey:
    @pytest.mark.asyncio
    async def test_returns_correct_public_key(self, keypair, registry_url):
        async with AsyncCarapaceClient(registry_url=registry_url, owner_private_key=keypair.private_key) as client:
            pub = await client.get_public_key()
        assert pub == keypair.public_key

    @pytest.mark.asyncio
    async def test_cached_after_first_call(self, keypair, registry_url):
        async with AsyncCarapaceClient(registry_url=registry_url, owner_private_key=keypair.private_key) as client:
            pub1 = await client.get_public_key()
            pub2 = await client.get_public_key()
        assert pub1 is pub2  # same object — cached
