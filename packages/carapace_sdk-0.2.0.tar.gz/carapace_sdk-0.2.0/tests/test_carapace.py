"""
Tests for the Carapace convenience class.

Mirrors the JS carapace.test.ts structure:
  Carapace(registry_url, owner_key)
  Carapace.create(registry_url)
  carapace.register(...)
  carapace.verify(id)
  carapace.discover(...)
  carapace.verify_local(card, sig, pubkey)
"""
import dataclasses
import json
from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

import httpx
import pytest

from carapace.carapace import Carapace
from carapace.crypto import sign_payload, derive_public_key
from carapace.keys import generate_key_pair
from carapace.types import (
    AgentCard,
    Capability,
    Endpoint,
    Owner,
    VerifyResult,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def build_signed_card(private_key: str, public_key: str) -> tuple[AgentCard, str]:
    """Build a signed AgentCard for local-verify tests."""
    issued_at = datetime.now(timezone.utc).isoformat()
    unsigned = {
        "name": "LocalTestAgent",
        "description": "For offline verify tests",
        "framework": "openclaw",
        "capabilities": [{"id": "research", "name": "Research", "description": "Search stuff"}],
        "endpoints": [{"protocol": "a2a", "url": "https://example.com/a2a"}],
        "issued_at": issued_at,
        "owner": {"public_key": public_key},
    }
    signature = sign_payload(unsigned, private_key)
    card = AgentCard(
        id="local-test-uuid",
        name=unsigned["name"],
        description=unsigned["description"],
        framework=unsigned["framework"],
        capabilities=[Capability(id="research", name="Research", description="Search stuff")],
        endpoints=[Endpoint(protocol="a2a", url="https://example.com/a2a")],
        owner=Owner(public_key=public_key),
        signature=signature,
        issued_at=issued_at,
        updated_at="",
    )
    return card, signature


def _make_response(status_code: int, body) -> httpx.Response:
    """Create a mock httpx.Response."""
    content = json.dumps(body).encode()
    return httpx.Response(status_code=status_code, content=content)


def _make_card_dict(public_key: str) -> dict:
    return {
        "id": "uuid-from-registry",
        "name": "DirectiveAgent",
        "description": "Matches directive spec",
        "framework": "openclaw",
        "capabilities": [],
        "endpoints": [],
        "owner": {"public_key": public_key},
        "signature": "abc123",
        "issued_at": "2026-01-01T00:00:00+00:00",
        "updated_at": "2026-01-01T00:00:00+00:00",
    }


# ---------------------------------------------------------------------------
# Constructor tests
# ---------------------------------------------------------------------------

class TestCarapaceConstructor:
    def test_accepts_owner_key_and_registry_url(self):
        kp = generate_key_pair()
        c = Carapace(registry_url="https://aria.example.com", owner_key=kp.private_key)
        assert c.public_key() == kp.public_key

    def test_raises_if_signing_methods_called_without_owner_key(self):
        c = Carapace(registry_url="https://aria.example.com")
        with pytest.raises(ValueError, match="owner_key"):
            c.register(
                name="X",
                description="Y",
                framework="z",
                capabilities=[],
                endpoints=[],
            )

    def test_no_owner_key_ok_for_verify_local(self):
        """verify_local is offline — should work without owner_key."""
        kp = generate_key_pair()
        card, signature = build_signed_card(kp.private_key, kp.public_key)
        c = Carapace(registry_url="https://aria.example.com")
        assert c.verify_local(card, signature, kp.public_key) is True


# ---------------------------------------------------------------------------
# Carapace.create() — auto-keygen factory
# ---------------------------------------------------------------------------

class TestCarapaceCreate:
    def test_generates_keypair_when_owner_key_omitted(self):
        c = Carapace.create(registry_url="https://aria.example.com")
        pk = c.public_key()
        assert isinstance(pk, str)
        assert len(pk) == 64

    def test_uses_provided_owner_key(self):
        kp = generate_key_pair()
        c = Carapace.create(registry_url="https://aria.example.com", owner_key=kp.private_key)
        assert c.public_key() == kp.public_key


# ---------------------------------------------------------------------------
# register()
# ---------------------------------------------------------------------------

class TestCarapaceRegister:
    def test_delegates_and_returns_card(self):
        kp = generate_key_pair()
        mock_card_dict = _make_card_dict(kp.public_key)

        mock_http = MagicMock()
        mock_http.post.return_value = _make_response(200, mock_card_dict)

        c = Carapace(
            registry_url="https://aria.example.com/aria/v1",
            owner_key=kp.private_key,
            http_client=mock_http,
        )
        card = c.register(
            name="DirectiveAgent",
            description="Matches directive spec",
            framework="openclaw",
            capabilities=[],
            endpoints=[],
        )
        assert card.id == "uuid-from-registry"
        assert card.name == "DirectiveAgent"

    def test_sends_to_correct_endpoint(self):
        kp = generate_key_pair()
        mock_card_dict = _make_card_dict(kp.public_key)
        mock_http = MagicMock()
        mock_http.post.return_value = _make_response(200, mock_card_dict)

        c = Carapace(
            registry_url="https://aria.example.com/aria/v1",
            owner_key=kp.private_key,
            http_client=mock_http,
        )
        c.register(
            name="DirectiveAgent",
            description="Test",
            framework="openclaw",
            capabilities=[],
            endpoints=[],
        )
        call_url = mock_http.post.call_args[0][0]
        assert "agents/register" in call_url


# ---------------------------------------------------------------------------
# verify()
# ---------------------------------------------------------------------------

class TestCarapaceVerify:
    def test_returns_verify_result_from_registry(self):
        kp = generate_key_pair()
        mock_http = MagicMock()
        mock_http.post.return_value = _make_response(
            200, {"agent_id": "abc", "verified": True, "reason": None}
        )

        c = Carapace(
            registry_url="https://aria.example.com",
            owner_key=kp.private_key,
            http_client=mock_http,
        )
        result = c.verify("abc")
        assert result.verified is True
        assert result.agent_id == "abc"

    def test_returns_false_when_registry_says_not_verified(self):
        kp = generate_key_pair()
        mock_http = MagicMock()
        mock_http.post.return_value = _make_response(
            200, {"agent_id": "xyz", "verified": False, "reason": "signature_mismatch"}
        )

        c = Carapace(
            registry_url="https://aria.example.com",
            owner_key=kp.private_key,
            http_client=mock_http,
        )
        result = c.verify("xyz")
        assert result.verified is False
        assert result.reason == "signature_mismatch"


# ---------------------------------------------------------------------------
# discover()
# ---------------------------------------------------------------------------

class TestCarapaceDiscover:
    def test_returns_list_of_matching_agents(self):
        kp = generate_key_pair()
        mock_agents = [_make_card_dict(kp.public_key)]
        mock_http = MagicMock()
        mock_http.get.return_value = _make_response(200, mock_agents)

        c = Carapace(
            registry_url="https://aria.example.com",
            owner_key=kp.private_key,
            http_client=mock_http,
        )
        agents = c.discover(capability="research")
        assert len(agents) == 1
        assert agents[0].id == "uuid-from-registry"

    def test_works_with_no_filters(self):
        kp = generate_key_pair()
        mock_http = MagicMock()
        mock_http.get.return_value = _make_response(200, [])

        c = Carapace(
            registry_url="https://aria.example.com",
            owner_key=kp.private_key,
            http_client=mock_http,
        )
        agents = c.discover()
        assert agents == []

    def test_passes_filters_as_query_params(self):
        kp = generate_key_pair()
        mock_http = MagicMock()
        mock_http.get.return_value = _make_response(200, [])

        c = Carapace(
            registry_url="https://aria.example.com",
            owner_key=kp.private_key,
            http_client=mock_http,
        )
        c.discover(capability="analysis", framework="langchain", limit=5)
        call_kwargs = mock_http.get.call_args[1]
        params = call_kwargs.get("params", {})
        assert params.get("capability") == "analysis"
        assert params.get("framework") == "langchain"
        assert params.get("limit") == 5


# ---------------------------------------------------------------------------
# verify_local() — fully offline, no network required
# ---------------------------------------------------------------------------

class TestCarapaceVerifyLocal:
    def test_returns_true_for_valid_locally_signed_card(self):
        kp = generate_key_pair()
        card, signature = build_signed_card(kp.private_key, kp.public_key)

        c = Carapace(registry_url="https://aria.example.com", owner_key=kp.private_key)
        assert c.verify_local(card, signature, kp.public_key) is True

    def test_returns_false_if_signature_is_wrong(self):
        kp = generate_key_pair()
        card, _ = build_signed_card(kp.private_key, kp.public_key)

        kp2 = generate_key_pair()
        wrong_sig = sign_payload({"tampered": True}, kp2.private_key)

        c = Carapace(registry_url="https://aria.example.com", owner_key=kp.private_key)
        assert c.verify_local(card, wrong_sig, kp.public_key) is False

    def test_returns_false_if_card_was_tampered(self):
        kp = generate_key_pair()
        _, signature = build_signed_card(kp.private_key, kp.public_key)

        # Different issued_at → different canonical form → signature mismatch
        tampered_card = AgentCard(
            id="local-test-uuid",
            name="TAMPERED_NAME",
            description="For offline verify tests",
            framework="openclaw",
            capabilities=[Capability(id="research", name="Research", description="Search stuff")],
            endpoints=[Endpoint(protocol="a2a", url="https://example.com/a2a")],
            owner=Owner(public_key=kp.public_key),
            signature=signature,
            issued_at="2099-01-01T00:00:00+00:00",
            updated_at="",
        )

        c = Carapace(registry_url="https://aria.example.com", owner_key=kp.private_key)
        assert c.verify_local(tampered_card, signature, kp.public_key) is False

    def test_returns_false_if_wrong_public_key(self):
        kp = generate_key_pair()
        card, signature = build_signed_card(kp.private_key, kp.public_key)
        kp2 = generate_key_pair()

        c = Carapace(registry_url="https://aria.example.com", owner_key=kp.private_key)
        assert c.verify_local(card, signature, kp2.public_key) is False

    def test_does_not_require_owner_key(self):
        """verify_local is pure crypto — no signing key needed."""
        kp = generate_key_pair()
        card, signature = build_signed_card(kp.private_key, kp.public_key)

        c = Carapace(registry_url="https://aria.example.com")  # no owner_key
        assert c.verify_local(card, signature, kp.public_key) is True


# ---------------------------------------------------------------------------
# public_key()
# ---------------------------------------------------------------------------

class TestCarapacePublicKey:
    def test_returns_derived_public_key(self):
        kp = generate_key_pair()
        c = Carapace(registry_url="https://aria.example.com", owner_key=kp.private_key)
        assert c.public_key() == kp.public_key

    def test_raises_without_owner_key(self):
        c = Carapace(registry_url="https://aria.example.com")
        with pytest.raises(ValueError, match="owner_key"):
            c.public_key()
