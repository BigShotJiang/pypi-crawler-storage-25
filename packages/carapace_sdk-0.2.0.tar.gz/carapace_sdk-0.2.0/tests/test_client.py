"""
Tests for CarapaceClient — register, verify, discover flows.
Uses httpx mock transport so no network calls are made.
"""

import json
import pytest
import httpx

from carapace import CarapaceClient
from carapace.keys import generate_key_pair
from carapace.crypto import verify_payload


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_registry_card(unsigned_card: dict, agent_id: str = "test-agent-uuid") -> dict:
    """Simulate a registry response: echo back the card with added fields."""
    from datetime import datetime, timezone
    card = dict(unsigned_card)
    card["id"] = agent_id
    card["updated_at"] = datetime.now(timezone.utc).isoformat()
    if "owner" not in card:
        card["owner"] = {"public_key": "deadbeef" * 8}
    return card


def _mock_transport(
    register_response: dict | None = None,
    verify_response: dict | None = None,
    discover_response: list | None = None,
):
    """Build an httpx MockTransport that handles all three endpoints."""

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path

        if path.endswith("/agents/register") and request.method == "POST":
            body = json.loads(request.content)
            card_data = body.get("card", {})
            response_data = register_response or _make_registry_card(card_data)
            return httpx.Response(200, json=response_data)

        if "/verify" in path and request.method == "POST":
            response_data = verify_response or {
                "agent_id": "test-agent-uuid",
                "verified": True,
            }
            return httpx.Response(200, json=response_data)

        if path.endswith("/agents/search") and request.method == "GET":
            response_data = discover_response or []
            return httpx.Response(200, json=response_data)

        return httpx.Response(404, json={"error": "not found"})

    return httpx.MockTransport(handler)


def _make_client(kp=None, **kwargs) -> tuple[CarapaceClient, object]:
    if kp is None:
        kp = generate_key_pair()
    transport = _mock_transport(**kwargs)
    http = httpx.Client(transport=transport)
    client = CarapaceClient(
        registry_url="https://registry.test/aria/v1",
        owner_private_key=kp.private_key,
        http_client=http,
    )
    return client, kp


# ---------------------------------------------------------------------------
# Tests: register
# ---------------------------------------------------------------------------

class TestRegister:
    def test_register_returns_agent_card(self):
        client, _ = _make_client()
        card = client.register(
            name="TestAgent",
            description="A test agent",
            framework="pytest",
            capabilities=[{"id": "test", "name": "Test", "description": "Does testing"}],
            endpoints=[{"protocol": "https", "url": "https://test.example.com"}],
        )
        assert card.name == "TestAgent"
        assert card.id == "test-agent-uuid"

    def test_register_sends_signed_payload(self):
        sent_body: dict = {}

        def handler(request: httpx.Request) -> httpx.Response:
            nonlocal sent_body
            sent_body = json.loads(request.content)
            card_data = sent_body["card"]
            return httpx.Response(200, json=_make_registry_card(card_data))

        kp = generate_key_pair()
        transport = httpx.MockTransport(handler)
        http = httpx.Client(transport=transport)
        client = CarapaceClient(
            registry_url="https://registry.test/aria/v1",
            owner_private_key=kp.private_key,
            http_client=http,
        )

        client.register(
            name="Signer",
            description="Tests signing",
            framework="test",
            capabilities=[{"id": "sign", "name": "Sign", "description": "Signs"}],
            endpoints=[{"protocol": "https", "url": "https://signer.test"}],
        )

        assert "card" in sent_body
        # v0.2: signature embedded in card.verification.signature
        assert "verification" in sent_body["card"]
        assert "signature" in sent_body["card"]["verification"]

    def test_register_signature_is_valid(self):
        """The signature in the wire payload must verify against the unsigned card."""
        sent_body: dict = {}

        def handler(request: httpx.Request) -> httpx.Response:
            nonlocal sent_body
            sent_body = json.loads(request.content)
            card_data = sent_body["card"]
            return httpx.Response(200, json=_make_registry_card(card_data))

        kp = generate_key_pair()
        transport = httpx.MockTransport(handler)
        http = httpx.Client(transport=transport)
        client = CarapaceClient(
            registry_url="https://registry.test/aria/v1",
            owner_private_key=kp.private_key,
            http_client=http,
        )

        client.register(
            name="CryptoCheck",
            description="Verifies the signature is real",
            framework="test",
            capabilities=[{"id": "check", "name": "Check", "description": "Checks"}],
            endpoints=[{"protocol": "https", "url": "https://check.test"}],
        )

        card = sent_body["card"]
        # v0.2: signature is base64url-encoded and embedded in card.verification.signature
        import copy, base64
        sig_b64 = card["verification"]["signature"]
        # Decode base64url → hex for verify_payload (which expects hex)
        padding = 4 - len(sig_b64) % 4
        sig_hex = base64.urlsafe_b64decode(sig_b64 + "=" * (padding % 4)).hex()
        # Strip signature before verify (matches server-side canonicalization logic)
        card_for_verify = copy.deepcopy(card)
        card_for_verify["verification"]["signature"] = ""
        assert verify_payload(card_for_verify, sig_hex, kp.public_key), "Signature should verify with owner public key"

    def test_register_embeds_public_key(self):
        sent_body: dict = {}

        def handler(request: httpx.Request) -> httpx.Response:
            nonlocal sent_body
            sent_body = json.loads(request.content)
            card_data = sent_body["card"]
            return httpx.Response(200, json=_make_registry_card(card_data))

        kp = generate_key_pair()
        transport = httpx.MockTransport(handler)
        http = httpx.Client(transport=transport)
        client = CarapaceClient(
            registry_url="https://registry.test/aria/v1",
            owner_private_key=kp.private_key,
            http_client=http,
        )
        client.register(
            name="PubKeyCheck",
            description="Test",
            framework="test",
            capabilities=[{"id": "c", "name": "C", "description": "D"}],
            endpoints=[{"protocol": "https", "url": "https://test"}],
        )

        assert sent_body["card"]["owner"]["public_key"] == kp.public_key

    def test_register_raises_on_error(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(500, json={"error": "internal"})

        kp = generate_key_pair()
        http = httpx.Client(transport=httpx.MockTransport(handler))
        client = CarapaceClient(
            registry_url="https://registry.test/aria/v1",
            owner_private_key=kp.private_key,
            http_client=http,
        )
        with pytest.raises(Exception):
            client.register(
                name="ErrorAgent",
                description="Will error",
                framework="test",
                capabilities=[],
                endpoints=[],
            )

    def test_register_with_optional_fields(self):
        client, _ = _make_client()
        card = client.register(
            name="Full",
            description="Has all optional fields",
            framework="test",
            capabilities=[{"id": "c", "name": "C", "description": "D"}],
            endpoints=[{"protocol": "https", "url": "https://full.test"}],
            version="2.0.0",
            tags=["alpha", "research"],
            metadata={"custom": True},
        )
        assert card.name == "Full"


# ---------------------------------------------------------------------------
# Tests: verify
# ---------------------------------------------------------------------------

class TestVerify:
    def test_verify_returns_verified_true(self):
        client, _ = _make_client(verify_response={"agent_id": "abc", "verified": True})
        result = client.verify("abc")
        assert result.verified is True
        assert result.agent_id == "abc"

    def test_verify_returns_verified_false(self):
        client, _ = _make_client(
            verify_response={"agent_id": "abc", "verified": False, "reason": "signature_mismatch"}
        )
        result = client.verify("abc")
        assert result.verified is False
        assert result.reason == "signature_mismatch"

    def test_verify_raises_on_404(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(404, json={"error": "not found"})

        kp = generate_key_pair()
        http = httpx.Client(transport=httpx.MockTransport(handler))
        client = CarapaceClient(
            registry_url="https://registry.test/aria/v1",
            owner_private_key=kp.private_key,
            http_client=http,
        )
        with pytest.raises(Exception):
            client.verify("missing-agent")


# ---------------------------------------------------------------------------
# Tests: discover
# ---------------------------------------------------------------------------

class TestDiscover:
    def test_discover_returns_empty_list(self):
        client, _ = _make_client(discover_response=[])
        agents = client.discover()
        assert agents == []

    def test_discover_returns_agent_cards(self):
        from datetime import datetime, timezone
        mock_card = {
            "id": "found-agent",
            "name": "FoundAgent",
            "description": "Was discovered",
            "framework": "langchain",
            "capabilities": [{"id": "research", "name": "Research", "description": "Searches"}],
            "endpoints": [{"protocol": "https", "url": "https://found.example.com"}],
            "owner": {"public_key": "ab" * 32},
            "signature": "cd" * 64,
            "issued_at": datetime.now(timezone.utc).isoformat(),
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }
        client, _ = _make_client(discover_response=[mock_card])
        agents = client.discover(capability="research")
        assert len(agents) == 1
        assert agents[0].id == "found-agent"
        assert agents[0].name == "FoundAgent"

    def test_discover_with_framework_filter(self):
        sent_params: dict = {}

        def handler(request: httpx.Request) -> httpx.Response:
            nonlocal sent_params
            sent_params = dict(request.url.params)
            return httpx.Response(200, json=[])

        kp = generate_key_pair()
        http = httpx.Client(transport=httpx.MockTransport(handler))
        client = CarapaceClient(
            registry_url="https://registry.test/aria/v1",
            owner_private_key=kp.private_key,
            http_client=http,
        )
        client.discover(framework="openclaw")
        assert sent_params.get("framework") == "openclaw"


# ---------------------------------------------------------------------------
# Tests: get_public_key
# ---------------------------------------------------------------------------

class TestGetPublicKey:
    def test_returns_correct_public_key(self):
        kp = generate_key_pair()
        transport = _mock_transport()
        http = httpx.Client(transport=transport)
        client = CarapaceClient(
            registry_url="https://registry.test/aria/v1",
            owner_private_key=kp.private_key,
            http_client=http,
        )
        assert client.get_public_key() == kp.public_key

    def test_cached_after_first_call(self):
        kp = generate_key_pair()
        transport = _mock_transport()
        http = httpx.Client(transport=transport)
        client = CarapaceClient(
            registry_url="https://registry.test/aria/v1",
            owner_private_key=kp.private_key,
            http_client=http,
        )
        key1 = client.get_public_key()
        key2 = client.get_public_key()
        assert key1 is key2  # same object (cached)
