"""
Tests for carapace.crypto — signing, verification, and key derivation.
"""

import pytest
from carapace.crypto import (
    sign_payload,
    verify_payload,
    derive_public_key,
    _jcs_canonicalize,
)
from carapace.keys import generate_key_pair


class TestJCS:
    def test_empty_object(self):
        assert _jcs_canonicalize({}) == "{}"

    def test_keys_sorted(self):
        result = _jcs_canonicalize({"z": 1, "a": 2})
        assert result == '{"a":2,"z":1}'

    def test_nested_object_keys_sorted(self):
        result = _jcs_canonicalize({"b": {"z": 1, "a": 2}, "a": 3})
        assert result == '{"a":3,"b":{"a":2,"z":1}}'

    def test_array_preserves_order(self):
        result = _jcs_canonicalize([3, 1, 2])
        assert result == "[3,1,2]"

    def test_none_serializes_to_null(self):
        assert _jcs_canonicalize(None) == "null"

    def test_bool_true(self):
        assert _jcs_canonicalize(True) == "true"

    def test_bool_false(self):
        assert _jcs_canonicalize(False) == "false"

    def test_string_with_unicode(self):
        result = _jcs_canonicalize("hello")
        assert result == '"hello"'

    def test_integer(self):
        assert _jcs_canonicalize(42) == "42"


class TestKeyGeneration:
    def test_generate_key_pair_returns_hex_strings(self):
        kp = generate_key_pair()
        assert isinstance(kp.private_key, str)
        assert isinstance(kp.public_key, str)

    def test_private_key_is_64_chars(self):
        kp = generate_key_pair()
        assert len(kp.private_key) == 64

    def test_public_key_is_64_chars(self):
        kp = generate_key_pair()
        assert len(kp.public_key) == 64

    def test_keys_are_hex(self):
        kp = generate_key_pair()
        int(kp.private_key, 16)  # should not raise
        int(kp.public_key, 16)   # should not raise

    def test_two_pairs_are_different(self):
        kp1 = generate_key_pair()
        kp2 = generate_key_pair()
        assert kp1.private_key != kp2.private_key
        assert kp1.public_key != kp2.public_key


class TestDerivePublicKey:
    def test_derived_key_matches_generated(self):
        kp = generate_key_pair()
        derived = derive_public_key(kp.private_key)
        assert derived == kp.public_key

    def test_accepts_0x_prefix(self):
        kp = generate_key_pair()
        derived = derive_public_key("0x" + kp.private_key)
        assert derived == kp.public_key


class TestSignAndVerify:
    def test_sign_and_verify_simple_payload(self):
        kp = generate_key_pair()
        payload = {"name": "test", "version": "1.0"}
        sig = sign_payload(payload, kp.private_key)
        assert verify_payload(payload, sig, kp.public_key)

    def test_verify_fails_with_wrong_key(self):
        kp1 = generate_key_pair()
        kp2 = generate_key_pair()
        payload = {"name": "test"}
        sig = sign_payload(payload, kp1.private_key)
        assert not verify_payload(payload, sig, kp2.public_key)

    def test_verify_fails_with_tampered_payload(self):
        kp = generate_key_pair()
        payload = {"name": "original"}
        sig = sign_payload(payload, kp.private_key)
        tampered = {"name": "tampered"}
        assert not verify_payload(tampered, sig, kp.public_key)

    def test_signature_is_deterministic_regardless_of_key_order(self):
        kp = generate_key_pair()
        payload_a = {"z": 1, "a": 2}
        payload_b = {"a": 2, "z": 1}
        sig_a = sign_payload(payload_a, kp.private_key)
        sig_b = sign_payload(payload_b, kp.private_key)
        assert sig_a == sig_b, "JCS canonicalization must make signatures key-order-independent"

    def test_verify_accepts_0x_prefixed_signature(self):
        kp = generate_key_pair()
        payload = {"hello": "world"}
        sig = sign_payload(payload, kp.private_key)
        assert verify_payload(payload, "0x" + sig, kp.public_key)

    def test_signature_is_128_hex_chars(self):
        kp = generate_key_pair()
        sig = sign_payload({"x": 1}, kp.private_key)
        assert len(sig) == 128
        int(sig, 16)  # must be valid hex

    def test_nested_payload(self):
        kp = generate_key_pair()
        payload = {
            "name": "complex-agent",
            "capabilities": [{"id": "search", "name": "Search"}],
            "owner": {"public_key": kp.public_key},
        }
        sig = sign_payload(payload, kp.private_key)
        assert verify_payload(payload, sig, kp.public_key)
