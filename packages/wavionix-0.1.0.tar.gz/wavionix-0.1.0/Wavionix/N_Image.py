import os
import io
import base64
import mimetypes
import urllib.parse
from PIL import Image as PIL_Image
from nicegui import ui
from .N_GUI import GUI
from .N_Custom import Event_Bind

PIL_Image.MAX_IMAGE_PIXELS = None


class Image:

    def __init__(self, Main, *args, **kwargs):
        self._GUI = GUI._Instance
        if self._GUI is not None:
            self._Type = 'Image'
            try:
                self._Config = {
                    'Name': False,
                    'Background': False,
                    'Border_Color': 'transparent',
                    'Border_Size': 0,
                    'Border_Radius': 0,
                    'Display': True,
                    'Left': None,
                    'Top': None,
                    'Right': None,
                    'Bottom': None,
                    'Width': None,
                    'Height': None,
                    'Path': False,
                    'Path_Initial': False,
                    'Rotate': 0,
                    'Aspect_Ratio': True,
                    'Hover_Background': False,
                    'Hover_Border_Color': False,
                    'Padding': 0,
                    'Margin': 0,
                    'Mode': 'Flow',
                    'Classes': '',
                    'Style': '',
                    'Z_Index': None,
                    'Shadow_X': 0,
                    'Shadow_Y': 0,
                    'Shadow_Blur': 0,
                    'Shadow_Spread': 0,
                    'Shadow_Color': 'transparent',
                }
                self._Initialized = False
                self._Main = Main
                self._Widget = None
                self._Image = None
                self._Name = False
                self._Display = True
                self._Background = False
                self._Border_Color = 'transparent'
                self._Border_Size = 0
                self._Border_Radius = 0
                self._Left = None
                self._Top = None
                self._Right = None
                self._Bottom = None
                self._Width = None
                self._Height = None
                self._Path = False
                self._Path_Initial = False
                self._Rotate = 0
                self._Angle = 0
                self._Aspect_Ratio = True
                self._Hover_Background = False
                self._Hover_Border_Color = False
                self._Padding = 0
                self._Margin = 0
                self._Mode = 'Flow'
                self._Classes = ''
                self._Style = ''
                self._Z_Index = None
                self._Shadow_X = 0
                self._Shadow_Y = 0
                self._Shadow_Blur = 0
                self._Shadow_Spread = 0
                self._Shadow_Color = 'transparent'
                self._On_Show = False
                self._On_Hide = False
                if kwargs:
                    self.Config(**kwargs)
            except Exception as E:
                self._GUI.Error(f'{self._Type} -> Init -> {E}')
        else:
            print('Error: Wavionix -> GUI Instance Has Not Been Created')

    def __str__(self):
        return 'Nucleon_Wavionix_Image[]'

    def __repr__(self):
        return 'Nucleon_Wavionix_Image[]'

    def _Hive_Color(self, Value):
        Hive = {
            'Hive_Yellow': '#F4C430',
            'Hive_Gold': '#D4A017',
            'Hive_Honey': '#FFBF00',
            'Hive_Amber': '#FFB000',
            'Hive_Orange': '#F28C28',
            'Hive_Brown': '#6B4F1D',
            'Hive_Dark': '#1F1B16',
            'Hive_Light': '#FFF8E1',
            'Hive_Cream': '#FFF3BF',
            'Hive_White': '#FFFFFF',
            'Hive_Black': '#000000',
        }
        if isinstance(Value, str) and Value in Hive:
            return Hive[Value]
        return Value

    def _Unit(self, Value):
        if Value is None or Value is False or Value == '':
            return None
        if isinstance(Value, (int, float)):
            return f'{Value}px'
        return str(Value)

    def _Number(self, Value):
        if Value is None or Value is False:
            return 0
        try:
            return float(Value)
        except Exception:
            return 0

    def _Get_Parent(self):
        if hasattr(self._Main, 'Widget') and callable(self._Main.Widget):
            return self._Main.Widget()
        if hasattr(self._Main, '_Frame') and self._Main._Frame is not None:
            return self._Main._Frame
        if hasattr(self._Main, '_Widget') and not isinstance(self._Main._Widget, list):
            return self._Main._Widget
        return self._Main

    def _Get_Background(self):
        if self._Background is False or self._Background is None or self._Background == '':
            if hasattr(self._Main, '_Background'):
                return self._Hive_Color(self._Main._Background)
            return 'transparent'
        return self._Hive_Color(self._Background)

    def _Get_Border_Color(self):
        return self._Hive_Color(self._Border_Color)

    def _Get_Shadow_Color(self):
        return self._Hive_Color(self._Shadow_Color)

    def _Build_Shadow(self):
        X = self._Unit(self._Shadow_X) or '0px'
        Y = self._Unit(self._Shadow_Y) or '0px'
        Blur = self._Unit(self._Shadow_Blur) or '0px'
        Spread = self._Unit(self._Shadow_Spread) or '0px'
        Color = self._Get_Shadow_Color() or 'transparent'
        return f'{X} {Y} {Blur} {Spread} {Color}'

    def _Build_Frame_Style(self):
        Style = []
        Style.append('box-sizing: border-box')
        Style.append(f'display: {"flex" if self._Display else "none"}')
        Style.append('align-items: center')
        Style.append('justify-content: center')
        Style.append('overflow: hidden')
        Style.append(f'background: {self._Get_Background()}')
        Style.append(f'border: {self._Unit(self._Border_Size) or "0px"} solid {self._Get_Border_Color()}')
        Style.append(f'border-radius: {self._Unit(self._Border_Radius) or "0px"}')
        Style.append(f'box-shadow: {self._Build_Shadow()}')
        Style.append(f'padding: {self._Unit(self._Padding) or "0px"}')
        Style.append(f'margin: {self._Unit(self._Margin) or "0px"}')
        Style.append('transition: all 0.2s ease')

        if self._Mode == 'Place':
            Style.append('position: absolute')
            if self._Left is not None:
                Style.append(f'left: {self._Unit(self._Left)}')
            if self._Top is not None:
                Style.append(f'top: {self._Unit(self._Top)}')
            if self._Right is not None:
                Style.append(f'right: {self._Unit(self._Right)}')
            if self._Bottom is not None:
                Style.append(f'bottom: {self._Unit(self._Bottom)}')

        if self._Width is not None:
            Style.append(f'width: {self._Unit(self._Width)}')
        if self._Height is not None:
            Style.append(f'height: {self._Unit(self._Height)}')

        if self._Z_Index is not None:
            Style.append(f'z-index: {self._Z_Index}')

        if self._Style:
            Style.append(self._Style)

        return '; '.join(Style)

    def _Build_Image_Style(self):
        Style = []
        Style.append('display: block')
        Style.append('width: 100%')
        Style.append('height: 100%')
        Style.append('max-width: 100%')
        Style.append('max-height: 100%')
        Style.append('object-fit: contain' if self._Aspect_Ratio else 'object-fit: fill')
        Style.append('object-position: center center')
        Style.append(f'transform: rotate({self._Rotate + self._Angle}deg)')
        return '; '.join(Style)

    def _Image_To_Data_Url(self, Image_Obj):
        Buffer = io.BytesIO()
        Temp = Image_Obj.copy()
        if Temp.mode not in ('RGB', 'RGBA', 'L'):
            Temp = Temp.convert('RGBA')
        Temp.save(Buffer, format='PNG')
        Encoded = base64.b64encode(Buffer.getvalue()).decode('utf-8')
        return f'data:image/png;base64,{Encoded}'

    def _Bytes_To_Data_Url(self, Data, Mime='image/png'):
        Encoded = base64.b64encode(Data).decode('utf-8')
        return f'data:{Mime};base64,{Encoded}'

    def _Resolve_Source(self, Value):
        try:
            if Value is False or Value is None or Value == '':
                return None

            if isinstance(Value, str):
                if Value.startswith('data:'):
                    return Value
                Parsed = urllib.parse.urlparse(Value)
                if Parsed.scheme in ('http', 'https'):
                    return Value
                if os.path.exists(Value):
                    with open(Value, 'rb') as File_Handle:
                        Data = File_Handle.read()
                    Mime = mimetypes.guess_type(Value)[0] or 'application/octet-stream'
                    return self._Bytes_To_Data_Url(Data, Mime)
                return Value

            if isinstance(Value, bytes):
                return self._Bytes_To_Data_Url(Value)

            if isinstance(Value, PIL_Image.Image):
                return self._Image_To_Data_Url(Value)

            Module_Name = getattr(type(Value), '__module__', '')
            if Module_Name.startswith('numpy'):
                Array = Value
                if len(Array.shape) == 2:
                    Temp = PIL_Image.fromarray(Array)
                    return self._Image_To_Data_Url(Temp)
                if len(Array.shape) == 3:
                    if Array.shape[2] == 3:
                        Temp = PIL_Image.fromarray(Array[:, :, ::-1])
                        return self._Image_To_Data_Url(Temp)
                    if Array.shape[2] == 4:
                        Temp = PIL_Image.fromarray(Array[:, :, [2, 1, 0, 3]])
                        return self._Image_To_Data_Url(Temp)
                    Temp = PIL_Image.fromarray(Array)
                    return self._Image_To_Data_Url(Temp)

            return None
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Resolve_Source -> {E}')
            return None

    def _Rebuild_Image(self):
        try:
            if self._Widget is None:
                return
            self._Widget.clear()
            self._Image = None
            Source = self._Resolve_Source(self._Path)
            if not Source:
                return
            Fit = 'contain' if self._Aspect_Ratio else 'fill'
            with self._Widget:
                self._Image = ui.image(Source)
            if hasattr(self._Image, '_style'):
                self._Image._style.clear()
            if hasattr(self._Image, '_classes'):
                self._Image._classes.clear()
            self._Image.props(f'fit={Fit} position="center center"')
            self._Image.classes('w-full h-full')
            self._Image.style(self._Build_Image_Style())
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Rebuild_Image -> {E}')

    def _Apply(self):
        try:
            if self._Widget is None:
                return
            if hasattr(self._Widget, '_style'):
                self._Widget._style.clear()
            if hasattr(self._Widget, '_classes'):
                self._Widget._classes.clear()
            self._Widget.style(self._Build_Frame_Style())
            Classes = []
            if self._Classes:
                Classes.append(self._Classes)
            if self._Hover_Background:
                Classes.append(f'hover:!bg-[{self._Hive_Color(self._Hover_Background)}]')
            if self._Hover_Border_Color:
                Classes.append(f'hover:!border-[{self._Hive_Color(self._Hover_Border_Color)}]')
            if len(Classes) > 0:
                self._Widget.classes(' '.join(Classes))
            if self._Image is not None:
                Fit = 'contain' if self._Aspect_Ratio else 'fill'
                if hasattr(self._Image, '_style'):
                    self._Image._style.clear()
                if hasattr(self._Image, '_classes'):
                    self._Image._classes.clear()
                self._Image.props(f'fit={Fit} position="center center"')
                self._Image.classes('w-full h-full')
                self._Image.style(self._Build_Image_Style())
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Apply -> {E}')

    def Copy(self, Name=False, Main=False):
        try:
            if not Main:
                Main = self._Main
            Instance = type(self)(Main)
            for Key in self._Config:
                if hasattr(self, '_' + Key):
                    setattr(Instance, '_' + Key, getattr(self, '_' + Key))
            if Name:
                Instance._Name = Name
            Instance.Create()
            return Instance
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Copy -> {E}')

    def Delete(self):
        try:
            if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self in self._Main._Widget:
                self._Main._Widget.remove(self)
            if self._Widget is not None:
                self._Widget.delete()
                self._Widget = None
                self._Image = None
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Delete -> {E}')

    def Clear(self):
        try:
            self._Path = False
            if self._Widget is not None:
                self._Widget.clear()
            self._Image = None
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Clear -> {E}')

    def Hide(self):
        try:
            self._Display = False
            self._Apply()
            if self._On_Hide:
                self._On_Hide()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Hide -> {E}')

    def Show(self):
        try:
            self._Display = True
            self._Apply()
            if self._On_Show:
                self._On_Show()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Show -> {E}')

    def Set(self, Path):
        try:
            self._Path = Path
            if not self._Path_Initial:
                self._Path_Initial = Path
            if self._Initialized:
                self._Rebuild_Image()
                self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Set -> {E}')

    def Initial(self):
        try:
            if self._Path_Initial:
                self.Set(self._Path_Initial)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Initial -> {E}')

    def Reset(self):
        try:
            self._Angle = 0
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Reset -> {E}')

    def Refresh(self):
        try:
            self._Rebuild_Image()
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Refresh -> {E}')

    def Rotate(self, Value=0):
        try:
            self._Angle += Value
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Rotate -> {E}')

    def Widget(self):
        try:
            return self._Widget
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Widget -> {E}')

    def Bind(self, **Input):
        try:
            if 'On_Show' in Input:
                self._On_Show = Input['On_Show']
            if 'On_Hide' in Input:
                self._On_Hide = Input['On_Hide']
            if self._Widget is not None:
                Event_Bind(self._Widget, **Input)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Bind -> {E}')

    def Config_Get(self, *Input):
        try:
            Return = {}
            for Each in self._Config:
                if Each in Input:
                    Return[Each] = getattr(self, '_' + Each)
            return Return
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config_Get -> {E}')

    def Config(self, **Input):
        try:
            Rebuild = False
            Run = False
            for Each in self._Config:
                if Each in Input:
                    setattr(self, '_' + Each, Input[Each])
                    Run = True
                    if Each in ['Path', 'Path_Initial']:
                        Rebuild = True
            if self._Initialized and Run:
                if Rebuild:
                    self._Rebuild_Image()
                self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config -> {E}')

    def Move(self, Left=None, Top=None):
        try:
            if Left is not None:
                self._Left = self._Number(self._Left) + self._Number(Left)
            if Top is not None:
                self._Top = self._Number(self._Top) + self._Number(Top)
            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()
            return [self._Left, self._Top]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Move -> {E}')

    def Center(self, Left=None, Top=None):
        try:
            Width = self._Number(self._Width)
            Height = self._Number(self._Height)
            if Left is not None:
                self._Left = self._Number(Left) - Width / 2
            if Top is not None:
                self._Top = self._Number(Top) - Height / 2
            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()
            return [self._Number(self._Left) + Width / 2, self._Number(self._Top) + Height / 2]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Center -> {E}')

    def Position(self, Left=None, Top=None, Right=None, Bottom=None):
        try:
            if Left is not None:
                self._Left = Left
            if Top is not None:
                self._Top = Top
            if Right is not None:
                self._Right = Right
            if Bottom is not None:
                self._Bottom = Bottom
            if Left is not None or Top is not None or Right is not None or Bottom is not None:
                self._Mode = 'Place'
                self._Apply()
            return [self._Left, self._Top, self._Right, self._Bottom]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Position -> {E}')

    def Size(self, Width=None, Height=None):
        try:
            if Width is not None:
                self._Width = Width
            if Height is not None:
                self._Height = Height
            if Width is not None or Height is not None:
                self._Apply()
            return [self._Width, self._Height]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Size -> {E}')

    def Enlarge(self, Value=None):
        try:
            if Value is not None:
                self._Width = self._Number(self._Width) + self._Number(Value)
                self._Height = self._Number(self._Height) + self._Number(Value)
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Enlarge -> {E}')

    def Shrink(self, Value=None):
        try:
            if Value is not None:
                self._Width = max(0, self._Number(self._Width) - self._Number(Value))
                self._Height = max(0, self._Number(self._Height) - self._Number(Value))
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Shrink -> {E}')

    def Box(self):
        try:
            return [self._Left, self._Top, self._Width, self._Height]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Box -> {E}')

    def Locate(self, Width, Height, Left, Top):
        try:
            Width = self._Number(self._Width) * (Width / 100)
            Height = self._Number(self._Height) * (Height / 100)
            Left = self._Number(self._Width) * (Left / 100)
            Top = self._Number(self._Height) * (Top / 100)
            return [Width, Height, Left, Top]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Locate -> {E}')

    def Locate_Reverse(self, Width, Height, Left, Top):
        try:
            Width = round((Width / self._Number(self._Width)) * 100, 3) if self._Number(self._Width) else 0
            Height = round((Height / self._Number(self._Height)) * 100, 3) if self._Number(self._Height) else 0
            Left = round((Left / self._Number(self._Width)) * 100, 3) if self._Number(self._Width) else 0
            Top = round((Top / self._Number(self._Height)) * 100, 3) if self._Number(self._Height) else 0
            return [Width, Height, Left, Top]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Locate_Reverse -> {E}')

    def Colors(self, Background=None, Border_Color=None):
        try:
            if Background is not None:
                self._Background = Background
            if Border_Color is not None:
                self._Border_Color = Border_Color
            self._Apply()
            return [self._Background, self._Border_Color]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Colors -> {E}')

    def Radius(self, Value=None):
        try:
            if Value is not None:
                self._Border_Radius = Value
                self._Apply()
            return self._Border_Radius
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Radius -> {E}')

    def Shadow(self, X=None, Y=None, Blur=None, Spread=None, Color=None):
        try:
            if X is not None:
                self._Shadow_X = X
            if Y is not None:
                self._Shadow_Y = Y
            if Blur is not None:
                self._Shadow_Blur = Blur
            if Spread is not None:
                self._Shadow_Spread = Spread
            if Color is not None:
                self._Shadow_Color = Color
            self._Apply()
            return [self._Shadow_X, self._Shadow_Y, self._Shadow_Blur, self._Shadow_Spread, self._Shadow_Color]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Shadow -> {E}')

    def Place(self, Left=None, Top=None, Right=None, Bottom=None, Width=None, Height=None):
        try:
            self._Mode = 'Place'
            if Left is not None:
                self._Left = Left
            if Top is not None:
                self._Top = Top
            if Right is not None:
                self._Right = Right
            if Bottom is not None:
                self._Bottom = Bottom
            if Width is not None:
                self._Width = Width
            if Height is not None:
                self._Height = Height
            self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Place -> {E}')

    def Pack(self, Classes=None, Style=None, Margin=None, Padding=None):
        try:
            self._Mode = 'Flow'
            self._Left = None
            self._Top = None
            self._Right = None
            self._Bottom = None
            if Classes is not None:
                self._Classes = Classes
            if Style is not None:
                self._Style = Style
            if Margin is not None:
                self._Margin = Margin
            if Padding is not None:
                self._Padding = Padding
            self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Pack -> {E}')

    def Create(self):
        try:
            if self._Widget is None:
                Parent = self._Get_Parent()
                
                if self._Mode != 'Place':
                    if self._Left is not None or self._Top is not None or self._Right is not None or self._Bottom is not None:
                        self._Mode = 'Place'


                if Parent is not None:
                    with Parent:
                        self._Widget = ui.element('div')
                else:
                    self._Widget = ui.element('div')

                if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self not in self._Main._Widget:
                    self._Main._Widget.append(self)

                self._Initialized = True

            self._Apply()
            self._Rebuild_Image()

            if self._Name:
                self._Main.__dict__[self._Name] = self

            if not self._Display:
                self.Hide()

            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Create -> {E}')