import os
from copy import deepcopy
from nicegui import ui
from .N_GUI import GUI
from .N_Custom import Event_Bind


class Tree:

    def __init__(self, Main, *args, **kwargs):
        self._GUI = GUI._Instance
        if self._GUI is None:
            print('Error: Wavionix -> GUI Instance Has Not Been Created')
            return

        self._Type = 'Tree'
        self._Main = Main

        self._Config = {
            'Name': False,
            'Auto_Dark': False,
            'Background': '#ffffff',
            'Light_Background': False,
            'Dark_Background': False,
            'Foreground': '#000000',
            'Light_Foreground': False,
            'Dark_Foreground': False,
            'Border_Color': '#000000',
            'Light_Border_Color': False,
            'Dark_Border_Color': False,
            'Border_Size': 1,
            'Border_Radius': 8,
            'Resize': True,
            'Popup': False,
            'Display': True,
            'Left': None,
            'Top': None,
            'Right': None,
            'Bottom': None,
            'Width': '100%',
            'Height': 260,
            'Font_Size': 13,
            'Font_Weight': 'normal',
            'Font_Family': 'Helvetica',
            'Scrollbar_Size': 10,
            'Scrollbar_Active': True,
            'Background_Selected': '#d0e4f5',
            'Foreground_Selected': '#000000',
            'Hover_Background': '#eef4fb',
            'Light_Hover_Background': False,
            'Dark_Hover_Background': False,
            'Hover_Foreground': False,
            'Light_Hover_Foreground': False,
            'Dark_Hover_Foreground': False,
            'Hover_Border_Color': False,
            'Light_Hover_Border_Color': False,
            'Dark_Hover_Border_Color': False,
            'Padding': 6,
            'Margin': 0,
            'Mode': 'Flow',
            'Classes': '',
            'Style': '',
            'Z_Index': None,
            'Dense': True,
            'Multi_Select': False,
            'Tick_Strategy': 'strict',
            'Default_Expand': False,
            'Shadow_X': 0,
            'Shadow_Y': 0,
            'Shadow_Blur': 0,
            'Shadow_Spread': 0,
            'Shadow_Color': 'transparent',
        }

        for Each, Value in self._Config.items():
            setattr(self, '_' + Each, deepcopy(Value))

        self._Initialized = False
        self._Widget = None
        self._Body = None
        self._Frame = None

        self._Name = False
        self._Last_Name = False

        self._Nodes = {}
        self._Root = []
        self._Tags = {}
        self._Focused = None
        self._Selected = []
        self._Expanded = set()
        self._Next_ID = 1

        self._On_Show = False
        self._On_Hide = False
        self._On_Change = False
        self._On_Select = False
        self._On_Expand = False
        self._On_Collapse = False

        self._Widget_Row_Map = {}

        self.Tag('Default', Foreground=self._Foreground, Background=False)

        if kwargs:
            self.Config(**kwargs)

    def __str__(self):
        return 'Nucleon_Wavionix_Tree[]'

    def __repr__(self):
        return 'Nucleon_Wavionix_Tree[]'

    # ---------------------------------------------------------
    # Helpers
    # ---------------------------------------------------------

    def _Hive_Color(self, Value):
        Hive = {
            'Hive_Yellow': '#F4C430',
            'Hive_Gold': '#D4A017',
            'Hive_Honey': '#FFBF00',
            'Hive_Amber': '#FFB000',
            'Hive_Orange': '#F28C28',
            'Hive_Brown': '#6B4F1D',
            'Hive_Dark': '#1F1B16',
            'Hive_Light': '#FFF8E1',
            'Hive_Cream': '#FFF3BF',
            'Hive_White': '#FFFFFF',
            'Hive_Black': '#000000',
        }
        if isinstance(Value, str) and Value in Hive:
            return Hive[Value]
        return Value

    def _Unit(self, Value):
        if Value in [None, False, '']:
            return None
        if isinstance(Value, (int, float)):
            return f'{Value}px'
        return str(Value)

    def _Number(self, Value):
        if Value in [None, False, '']:
            return 0
        try:
            if isinstance(Value, str) and Value.endswith('px'):
                return float(Value[:-2])
            if isinstance(Value, str) and Value.endswith('%'):
                return 0
            return float(Value)
        except Exception:
            return 0

    def _Get_Parent(self):
        if hasattr(self._Main, 'Widget') and callable(self._Main.Widget):
            return self._Main.Widget()
        if hasattr(self._Main, '_Frame') and self._Main._Frame is not None:
            return self._Main._Frame
        if hasattr(self._Main, '_Widget') and not isinstance(self._Main._Widget, list):
            return self._Main._Widget
        return self._Main

    def _Get_Background(self):
        Value = self._Background
        if Value in [False, None]:
            if hasattr(self._Main, '_Background'):
                return self._Hive_Color(self._Main._Background)
            return '#ffffff'
        return self._Hive_Color(Value)

    def _Get_Foreground(self):
        return self._Hive_Color(self._Foreground)

    def _Get_Border_Color(self):
        return self._Hive_Color(self._Border_Color)

    def _Get_Shadow_Color(self):
        return self._Hive_Color(self._Shadow_Color)

    def _Build_Shadow(self):
        return f'{self._Unit(self._Shadow_X) or "0px"} {self._Unit(self._Shadow_Y) or "0px"} {self._Unit(self._Shadow_Blur) or "0px"} {self._Unit(self._Shadow_Spread) or "0px"} {self._Get_Shadow_Color() or "transparent"}'

    def _Build_Frame_Style(self):
        Style = []
        Style.append('box-sizing:border-box')
        Style.append(f'display:{"block" if self._Display else "none"}')
        Style.append('overflow:hidden')
        Style.append(f'background:{self._Get_Background()}')
        Style.append(f'color:{self._Get_Foreground()}')
        Style.append(f'border:{self._Unit(self._Border_Size) or "0px"} solid {self._Get_Border_Color()}')
        Style.append(f'border-radius:{self._Unit(self._Border_Radius) or "0px"}')
        Style.append(f'box-shadow:{self._Build_Shadow()}')
        Style.append(f'padding:{self._Unit(self._Padding) or "0px"}')
        Style.append(f'margin:{self._Unit(self._Margin) or "0px"}')

        if self._Mode == 'Place':
            Style.append('position:absolute')
            if self._Left is not None:
                Style.append(f'left:{self._Unit(self._Left)}')
            if self._Top is not None:
                Style.append(f'top:{self._Unit(self._Top)}')
            if self._Right is not None:
                Style.append(f'right:{self._Unit(self._Right)}')
            if self._Bottom is not None:
                Style.append(f'bottom:{self._Unit(self._Bottom)}')
        else:
            Style.append('position:relative')

        if self._Width is not None:
            Style.append(f'width:{self._Unit(self._Width)}')
        if self._Height is not None:
            Style.append(f'height:{self._Unit(self._Height)}')
            Style.append(f'min-height:{self._Unit(self._Height)}')

        if self._Z_Index is not None:
            Style.append(f'z-index:{self._Z_Index}')

        if self._Style:
            Style.append(str(self._Style))

        return '; '.join(Style)

    def _Generate_ID(self):
        while True:
            ID = f'tree_{self._Next_ID}'
            self._Next_ID += 1
            if ID not in self._Nodes:
                return ID

    def _Make_Event(self, Value=None, ID=None, Name=None, Data=None):
        Payload = {
            'value': Value,
            'id': ID,
            'name': Name,
            'data': Data,
            'tree': self,
        }
        return type('Tree_Event', (), Payload)()

    def _Get_Tag_Style(self, Tag):
        if Tag in self._Tags:
            return self._Tags[Tag]
        return self._Tags.get('Default', {'Foreground': self._Foreground, 'Background': False})

    def _Has_Children(self, ID):
        return ID in self._Nodes and len(self._Nodes[ID]['children']) > 0

    def _Node_Is_Selected(self, ID):
        if self._Multi_Select:
            return ID in self._Selected
        return self._Focused == ID

    def _Select_From_Click(self, ID):
        try:
            if ID not in self._Nodes:
                return

            if self._Multi_Select:
                if ID not in self._Selected:
                    self._Selected.append(ID)
                self._Focused = ID
                Event_Value = list(self._Selected)
            else:
                self._Focused = ID
                self._Selected = [ID]
                Event_Value = ID

            self._Render()

            Data = self.Get_All(ID)

            if self._On_Select:
                self._On_Select(self._Make_Event(Value=Event_Value, ID=ID, Name='select', Data=Data))

            if self._On_Change:
                self._On_Change(self._Make_Event(Value=Event_Value, ID=ID, Name='change', Data=Data))

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Select_From_Click -> {E}')

    def _Toggle_From_Click(self, ID):
        try:
            if ID not in self._Nodes:
                return

            if ID in self._Expanded:
                self._Expanded.remove(ID)
                self._Render()
                if self._On_Collapse:
                    self._On_Collapse(self._Make_Event(Value=ID, ID=ID, Name='collapse', Data=self.Get_All(ID)))
            else:
                self._Expanded.add(ID)
                self._Render()
                if self._On_Expand:
                    self._On_Expand(self._Make_Event(Value=ID, ID=ID, Name='expand', Data=self.Get_All(ID)))

            if self._On_Change:
                self._On_Change(self._Make_Event(Value=self.Current(), ID=self.Current(), Name='change', Data=self.Get_All(self.Current())))

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Toggle_From_Click -> {E}')

    def _Row_Style(self, ID, Depth):
        Node = self._Nodes[ID]
        Tag = self._Get_Tag_Style(Node['tag'])

        Foreground = self._Hive_Color(Tag.get('Foreground') or self._Foreground)
        Tag_Background = self._Hive_Color(Tag.get('Background')) if Tag.get('Background') not in [False, None] else None

        if self._Node_Is_Selected(ID):
            Background = self._Hive_Color(self._Background_Selected)
            Foreground = self._Hive_Color(self._Foreground_Selected)
            Border = self._Hive_Color(self._Hover_Border_Color) if self._Hover_Border_Color not in [False, None] else 'transparent'
        else:
            Background = Tag_Background if Tag_Background else 'transparent'
            Border = 'transparent'

        Height = 28 if self._Dense else 34
        Indent = 18 * Depth

        return (
            'display:flex; align-items:center; width:100%; box-sizing:border-box; '
            f'min-height:{Height}px; padding:4px 8px 4px {Indent + 6}px; '
            f'background:{Background}; color:{Foreground}; '
            f'border:1px solid {Border}; border-radius:8px; '
            'cursor:pointer; user-select:none; gap:0;'
        )

    def _Render_Node(self, Parent, ID, Depth=0):
        Node = self._Nodes[ID]
        Has_Children = len(Node['children']) > 0

        with Parent:
            Row = ui.element('div').style(self._Row_Style(ID, Depth))
            Row.on('click', lambda E=None, Item_ID=ID: self._Select_From_Click(Item_ID))
            self._Widget_Row_Map[ID] = Row

            with Row:
                if Has_Children:
                    Arrow = ui.button('▼' if ID in self._Expanded else '▶')
                    Arrow.props('flat dense')
                    Arrow.style(
                        'width:20px; min-width:20px; height:20px; min-height:20px; '
                        'padding:0; margin-right:6px; line-height:1; font-size:18px; '
                        'font-weight:700; background:transparent; color:inherit;'
                    )
                    Arrow.on('click.stop', lambda E=None, Item_ID=ID: self._Toggle_From_Click(Item_ID))
                else:
                    ui.element('div').style(
                        'width:20px; min-width:20px; height:20px; min-height:20px; margin-right:6px;'
                    )

                if Node.get('icon'):
                    ui.label(str(Node['icon'])).style('margin-right:6px; min-width:18px; font-size:0.95em;')

                ui.label(str(Node['text'])).style(
                    f'font-size:{self._Unit(self._Font_Size) or "13px"}; '
                    f'font-weight:{self._Font_Weight}; '
                    f'font-family:{self._Font_Family};'
                )

                if Node.get('description'):
                    ui.label(str(Node['description'])).style(
                        f'margin-left:8px; opacity:0.72; font-size:{max(11, self._Number(self._Font_Size)-1)}px;'
                    )

            if ID in self._Expanded:
                for Child_ID in Node['children']:
                    self._Render_Node(Parent, Child_ID, Depth + 1)

    def _Render(self):
        try:
            if self._Widget is None:
                return

            if self._Default_Expand:
                self._Expanded = set(self._Nodes.keys())

            self._Widget_Row_Map = {}
            self._Widget.clear()

            with self._Widget:
                self._Body = ui.element('div').style(
                    'width:100%; height:100%; overflow:{}; box-sizing:border-box;'.format(
                        'auto' if self._Scrollbar_Active else 'hidden'
                    )
                )

                with self._Body:
                    for Root_ID in self._Root:
                        self._Render_Node(self._Body, Root_ID, 0)

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Render -> {E}')

    def _Apply(self):
        try:
            if self._Widget is None:
                return

            if hasattr(self._Widget, '_style'):
                self._Widget._style.clear()
            if hasattr(self._Widget, '_classes'):
                self._Widget._classes.clear()

            self._Widget.style(self._Build_Frame_Style())

            if self._Classes not in [False, None, '']:
                self._Widget.classes(str(self._Classes))

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Apply -> {E}')

    # ---------------------------------------------------------
    # Core
    # ---------------------------------------------------------

    def Create(self):
        try:
            if self._Widget is None:
                Parent = self._Get_Parent()
                
                if self._Mode != 'Place':
                    if self._Left is not None or self._Top is not None or self._Right is not None or self._Bottom is not None:
                        self._Mode = 'Place'

                if Parent is not None:
                    with Parent:
                        self._Widget = ui.element('div')
                else:
                    self._Widget = ui.element('div')

                if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list):
                    if self not in self._Main._Widget:
                        self._Main._Widget.append(self)

                self._Initialized = True

            self._Apply()
            self._Render()

            if self._Name != self._Last_Name:
                if self._Last_Name and self._Last_Name in self._Main.__dict__:
                    del self._Main.__dict__[self._Last_Name]
                if self._Name:
                    self._Main.__dict__[self._Name] = self
                self._Last_Name = self._Name

            if not self._Display:
                self.Hide()

            return self

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Create -> {E}')

    def Copy(self, Name=False, Main=False):
        try:
            if not Main:
                Main = self._Main

            Instance = type(self)(Main)

            for Key in self._Config:
                setattr(Instance, '_' + Key, deepcopy(getattr(self, '_' + Key)))

            Instance._Nodes = deepcopy(self._Nodes)
            Instance._Root = deepcopy(self._Root)
            Instance._Tags = deepcopy(self._Tags)
            Instance._Focused = deepcopy(self._Focused)
            Instance._Selected = deepcopy(self._Selected)
            Instance._Expanded = deepcopy(self._Expanded)
            Instance._Next_ID = self._Next_ID

            if Name:
                Instance._Name = Name

            Instance.Create()
            return Instance

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Copy -> {E}')

    def Delete(self):
        try:
            if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list):
                if self in self._Main._Widget:
                    self._Main._Widget.remove(self)

            if self._Widget is not None:
                self._Widget.delete()

            self._Widget = None
            self._Body = None
            self._Frame = None

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Delete -> {E}')

    def Show(self):
        try:
            self._Display = True
            self._Apply()
            if self._On_Show:
                self._On_Show()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Show -> {E}')

    def Hide(self):
        try:
            self._Display = False
            self._Apply()
            if self._On_Hide:
                self._On_Hide()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Hide -> {E}')

    def Widget(self):
        try:
            return self._Widget
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Widget -> {E}')

    def Refresh(self):
        try:
            self._Apply()
            self._Render()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Refresh -> {E}')

    def Clear(self):
        try:
            self.Remove_All()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Clear -> {E}')

    def Grab(self, Path=False):
        try:
            if hasattr(self._GUI, 'Grab_Widget'):
                return self._GUI.Grab_Widget(Path=Path, Widget=self)
            return False
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Grab -> {E}')

    def Animate(self, Hide=False, Thread=True):
        try:
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Animate -> {E}')

    def Animate_Cancel(self):
        try:
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Animate_Cancel -> {E}')

    def Scroll(self, E=None, Value=0):
        try:
            Amount = 0
            if hasattr(E, 'delta'):
                Amount = int(-1 * (E.delta / 120) * 36)
            else:
                Amount = int(Value)

            ui.run_javascript(f'''
                (() => {{
                    const root = document.getElementById("{id(self)}");
                    if (root) root.scrollBy(0, {Amount});
                }})()
            ''')
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Scroll -> {E}')

    # ---------------------------------------------------------
    # Data
    # ---------------------------------------------------------

    def Tag(self, Name, Foreground=False, Background=False):
        try:
            self._Tags[Name] = {
                'Foreground': Foreground if Foreground not in [None, False] else self._Foreground,
                'Background': Background,
            }
            if self._Initialized:
                self._Render()
            return Name
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Tag -> {E}')

    def Add(self, Name, Parent='', Index='end', Tag='Default', Value=None, ID=None, Path=None, Icon=None, Description=None):
        try:
            if ID is None:
                ID = self._Generate_ID()

            if ID in self._Nodes:
                raise Exception(f'ID already exists: {ID}')

            if Value is None:
                Value = []

            Parent_ID = Parent if Parent not in [None, ''] else None
            if Parent_ID is not None and Parent_ID not in self._Nodes:
                raise Exception(f'Parent does not exist: {Parent_ID}')

            Node = {
                'id': ID,
                'text': str(Name),
                'value': Value,
                'tag': Tag or 'Default',
                'parent': Parent_ID,
                'children': [],
                'description': str(Description) if Description not in [False, None] else '',
                'icon': Icon if Icon not in [False, None] else None,
                'image': Path if Path not in [False, None] else None,
                'disabled': False,
                'selectable': True,
                'tickable': True,
            }

            self._Nodes[ID] = Node

            if Parent_ID is None:
                Target = self._Root
            else:
                Target = self._Nodes[Parent_ID]['children']

            if Index == 'end':
                Target.append(ID)
            else:
                Target.insert(int(Index), ID)

            if self._Default_Expand and Parent_ID is not None:
                self._Expanded.add(Parent_ID)

            if self._Initialized:
                self._Render()

            return ID

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Add -> {E}')

    def Edit(self, Name=False, Value=False, Tag=False, ID=False, Path=False, Icon=False, Description=False):
        try:
            if not ID:
                ID = self._Focused

            if not ID or ID not in self._Nodes:
                return

            if Name not in [False, None]:
                self._Nodes[ID]['text'] = str(Name)
            if Value not in [False, None]:
                self._Nodes[ID]['value'] = Value
            if Tag not in [False, None]:
                self._Nodes[ID]['tag'] = Tag
            if Path not in [False, None]:
                self._Nodes[ID]['image'] = Path
            if Icon not in [False, None]:
                self._Nodes[ID]['icon'] = Icon
            if Description not in [False, None]:
                self._Nodes[ID]['description'] = str(Description)

            if self._Initialized:
                self._Render()

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Edit -> {E}')

    def Remove(self, ID):
        try:
            if ID not in self._Nodes:
                return

            for Child_ID in list(self._Nodes[ID]['children']):
                self.Remove(Child_ID)

            Parent_ID = self._Nodes[ID]['parent']
            if Parent_ID is None:
                if ID in self._Root:
                    self._Root.remove(ID)
            else:
                if Parent_ID in self._Nodes and ID in self._Nodes[Parent_ID]['children']:
                    self._Nodes[Parent_ID]['children'].remove(ID)

            if ID in self._Expanded:
                self._Expanded.remove(ID)
            if ID in self._Selected:
                self._Selected.remove(ID)
            if self._Focused == ID:
                self._Focused = None

            del self._Nodes[ID]

            if self._Initialized:
                self._Render()

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Remove -> {E}')

    def Remove_All(self):
        try:
            self._Nodes = {}
            self._Root = []
            self._Focused = None
            self._Selected = []
            self._Expanded = set()
            if self._Initialized:
                self._Render()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Remove_All -> {E}')

    def Remove_Selected(self):
        try:
            Temp = list(self._Selected)
            if not Temp and self._Focused:
                Temp = [self._Focused]

            for Each in Temp:
                if Each in self._Nodes:
                    self.Remove(Each)

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Remove_Selected -> {E}')

    def Update_Tree(self, Name=False, Item=False):
        try:
            if self._Initialized:
                self._Render()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Update_Tree -> {E}')

    # ---------------------------------------------------------
    # Query
    # ---------------------------------------------------------

    def Get(self, ID=False):
        try:
            if ID in [False, None, '']:
                ID = self._Focused

            if isinstance(ID, (list, tuple, set)):
                Return = []
                for Each in ID:
                    if Each in self._Nodes:
                        Return.append(deepcopy(self._Nodes[Each]['value']))
                return Return

            if not ID or ID not in self._Nodes:
                return None

            return deepcopy(self._Nodes[ID]['value'])

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Get -> {E}')

    def Get_All(self, ID=False):
        try:
            if ID in [False, None, '']:
                ID = self._Focused

            if isinstance(ID, (list, tuple, set)):
                Return = []
                for Each in ID:
                    if Each in self._Nodes:
                        Return.append(deepcopy(self._Nodes[Each]))
                return Return

            if not ID or ID not in self._Nodes:
                return None

            return deepcopy(self._Nodes[ID])

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Get_All -> {E}')

    def Get_Selected(self):
        try:
            Return = []
            for Each in self._Selected:
                if Each in self._Nodes:
                    Return.append(deepcopy(self._Nodes[Each]))
            return Return
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Get_Selected -> {E}')

    def Current(self):
        try:
            return self._Focused
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Current -> {E}')

    def Selected(self):
        try:
            return list(self._Selected)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Selected -> {E}')

    def Child(self, ID=False):
        try:
            if ID and ID in self._Nodes:
                return list(self._Nodes[ID]['children'])
            return []
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Child -> {E}')

    def Parent(self, ID=False):
        try:
            if ID and ID in self._Nodes:
                return self._Nodes[ID]['parent']
            return None
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Parent -> {E}')

    def Index(self, Item):
        try:
            if Item not in self._Nodes:
                return None

            Parent_ID = self._Nodes[Item]['parent']
            if Parent_ID is None:
                return self._Root.index(Item)
            return self._Nodes[Parent_ID]['children'].index(Item)

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Index -> {E}')

    def Level(self, Item):
        try:
            if Item not in self._Nodes:
                return 0

            Count = 0
            Parent_ID = self._Nodes[Item]['parent']
            while Parent_ID:
                Count += 1
                Parent_ID = self._Nodes[Parent_ID]['parent'] if Parent_ID in self._Nodes else None
            return Count

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Level -> {E}')

    # ---------------------------------------------------------
    # Selection / Expand
    # ---------------------------------------------------------

    def Select(self, ID=None, Keep=False):
        try:
            if ID is None:
                return

            if isinstance(ID, (list, tuple)):
                ID_List = [Each for Each in ID if Each in self._Nodes]
            else:
                ID_List = [ID] if ID in self._Nodes else []

            if not ID_List:
                return

            if self._Multi_Select:
                if Keep:
                    for Each in ID_List:
                        if Each not in self._Selected:
                            self._Selected.append(Each)
                else:
                    self._Selected = list(ID_List)
                self._Focused = self._Selected[0]
                Fire_Value = list(self._Selected)
            else:
                self._Focused = ID_List[0]
                self._Selected = [self._Focused]
                Fire_Value = self._Focused

            Parent_ID = self.Parent(self._Focused)
            while Parent_ID:
                self._Expanded.add(Parent_ID)
                Parent_ID = self.Parent(Parent_ID)

            self._Render()

            Data = self.Get_All(self._Focused)

            if self._On_Select:
                self._On_Select(self._Make_Event(Value=Fire_Value, ID=self._Focused, Name='select', Data=Data))
            if self._On_Change:
                self._On_Change(self._Make_Event(Value=Fire_Value, ID=self._Focused, Name='change', Data=Data))

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Select -> {E}')

    def Unselect(self, ID=None):
        try:
            if ID is None:
                self._Selected = []
                self._Focused = None
            else:
                if ID in self._Selected:
                    self._Selected.remove(ID)
                if self._Focused == ID:
                    self._Focused = self._Selected[0] if self._Selected else None

            self._Render()

            if self._On_Change:
                self._On_Change(self._Make_Event(Value=self._Focused, ID=self._Focused, Name='change', Data=self.Get_All(self._Focused)))

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Unselect -> {E}')

    def Expand(self, ID=False):
        try:
            if not ID:
                ID = self._Focused
            if ID and ID in self._Nodes:
                self._Expanded.add(ID)
                self._Render()
                if self._On_Expand:
                    self._On_Expand(self._Make_Event(Value=ID, ID=ID, Name='expand', Data=self.Get_All(ID)))
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Expand -> {E}')

    def Collapse(self, ID=False):
        try:
            if not ID:
                ID = self._Focused
            if ID and ID in self._Expanded:
                self._Expanded.remove(ID)
                self._Render()
                if self._On_Collapse:
                    self._On_Collapse(self._Make_Event(Value=ID, ID=ID, Name='collapse', Data=self.Get_All(ID)))
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Collapse -> {E}')

    def Expand_All(self):
        try:
            self._Expanded = set(self._Nodes.keys())
            self._Render()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Expand_All -> {E}')

    def Collapse_All(self):
        try:
            self._Expanded = set()
            self._Render()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Collapse_All -> {E}')

    # ---------------------------------------------------------
    # Export
    # ---------------------------------------------------------

    def Export(self, Path='TreeStructure.txt'):
        try:
            with open(Path, 'w', encoding='utf-8') as File_Handle:
                self.Export_All(File_Handle)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Export -> {E}')

    def Export_All(self, File, Parent='', Indent=0):
        try:
            if Parent in [False, None, '']:
                for Root_ID in self._Root:
                    self.Export_All(File, Root_ID, Indent)
                return

            if Parent not in self._Nodes:
                return

            Node = self._Nodes[Parent]
            File.write(' ' * Indent + Node['text'] + '\n')

            for Child in Node['children']:
                self.Export_All(File, Child, Indent + 4)

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Export_All -> {E}')

    # ---------------------------------------------------------
    # Events / Config
    # ---------------------------------------------------------

    def Bind(self, **Input):
        try:
            if 'On_Show' in Input:
                self._On_Show = Input['On_Show']
            if 'On_Hide' in Input:
                self._On_Hide = Input['On_Hide']
            if 'On_Change' in Input:
                self._On_Change = Input['On_Change']
            if 'On_Select' in Input:
                self._On_Select = Input['On_Select']
            if 'On_Expand' in Input:
                self._On_Expand = Input['On_Expand']
            if 'On_Collapse' in Input:
                self._On_Collapse = Input['On_Collapse']

            if self._Widget is not None:
                Skip = ['On_Show', 'On_Hide', 'On_Change', 'On_Select', 'On_Expand', 'On_Collapse']
                Forward = {K: V for K, V in Input.items() if K not in Skip}
                if len(Forward) > 0:
                    Event_Bind(self._Widget, **Forward)

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Bind -> {E}')

    def Config_Get(self, *Input):
        try:
            Return = {}
            if len(Input) == 0:
                for Each in self._Config:
                    Return[Each] = getattr(self, '_' + Each)
                return Return

            for Each in self._Config:
                if Each in Input:
                    Return[Each] = getattr(self, '_' + Each)
            return Return

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config_Get -> {E}')

    def Config(self, **Input):
        try:
            Run = False
            for Each in self._Config:
                if Each in Input:
                    setattr(self, '_' + Each, Input[Each])
                    Run = True

            if self._Initialized and Run:
                self._Apply()
                self._Render()

            return True

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config -> {E}')

    # ---------------------------------------------------------
    # Geometry
    # ---------------------------------------------------------

    def Move(self, Left=None, Top=None):
        try:
            if Left is not None:
                self._Left = self._Number(self._Left) + self._Number(Left)
            if Top is not None:
                self._Top = self._Number(self._Top) + self._Number(Top)

            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()

            return [self._Left, self._Top]

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Move -> {E}')

    def Center(self, Left=None, Top=None):
        try:
            Width = self._Number(self._Width)
            Height = self._Number(self._Height)

            if Left is not None:
                self._Left = self._Number(Left) - (Width / 2)
            if Top is not None:
                self._Top = self._Number(Top) - (Height / 2)

            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()

            return [self._Number(self._Left) + (Width / 2), self._Number(self._Top) + (Height / 2)]

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Center -> {E}')

    def Position(self, Left=None, Top=None, Right=None, Bottom=None):
        try:
            if Left is not None:
                self._Left = Left
            if Top is not None:
                self._Top = Top
            if Right is not None:
                self._Right = Right
            if Bottom is not None:
                self._Bottom = Bottom

            if Left is not None or Top is not None or Right is not None or Bottom is not None:
                self._Mode = 'Place'
                self._Apply()

            return [self._Left, self._Top, self._Right, self._Bottom]

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Position -> {E}')

    def Size(self, Width=False, Height=False):
        try:
            if Width is not False:
                self._Width = Width
            if Height is not False:
                self._Height = Height

            if Width is not False or Height is not False:
                self._Apply()

            return [self._Width, self._Height]

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Size -> {E}')

    def Enlarge(self, Value=None):
        try:
            if Value is not None:
                Value_Number = self._Number(Value)

                if self._Left is not None:
                    self._Left = self._Number(self._Left) - Value_Number
                if self._Top is not None:
                    self._Top = self._Number(self._Top) - Value_Number

                self._Width = self._Number(self._Width) + Value_Number
                self._Height = self._Number(self._Height) + Value_Number

                self._Apply()

            return True

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Enlarge -> {E}')

    def Shrink(self, Value=None):
        try:
            if Value is not None:
                Value_Number = self._Number(Value)

                if self._Left is not None:
                    self._Left = self._Number(self._Left) + Value_Number
                if self._Top is not None:
                    self._Top = self._Number(self._Top) + Value_Number

                self._Width = max(0, self._Number(self._Width) - Value_Number)
                self._Height = max(0, self._Number(self._Height) - Value_Number)

                self._Apply()

            return True

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Shrink -> {E}')

    def Box(self):
        try:
            return [self._Left, self._Top, self._Width, self._Height]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Box -> {E}')

    def Ratio(self):
        try:
            Width = self._Number(self._Width)
            Height = self._Number(self._Height)
            return [Width, Height]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Ratio -> {E}')

    def Locate(self, Width, Height, Left, Top):
        try:
            Base_Width = self._Number(self._Width)
            Base_Height = self._Number(self._Height)

            Width = Base_Width * (Width / 100)
            Height = Base_Height * (Height / 100)
            Left = Base_Width * (Left / 100)
            Top = Base_Height * (Top / 100)

            return [Width, Height, Left, Top]

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Locate -> {E}')

    def Locate_Reverse(self, Width, Height, Left, Top):
        try:
            Base_Width = self._Number(self._Width)
            Base_Height = self._Number(self._Height)

            if Base_Width == 0 or Base_Height == 0:
                return [0, 0, 0, 0]

            Width = round((Width / Base_Width) * 100, 3)
            Height = round((Height / Base_Height) * 100, 3)
            Left = round((Left / Base_Width) * 100, 3)
            Top = round((Top / Base_Height) * 100, 3)

            return [Width, Height, Left, Top]

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Locate_Reverse -> {E}')

    def Colors(self, Background=None, Foreground=None, Border_Color=None):
        try:
            if Background is not None:
                self._Background = Background
            if Foreground is not None:
                self._Foreground = Foreground
            if Border_Color is not None:
                self._Border_Color = Border_Color

            self._Apply()
            self._Render()

            return [self._Background, self._Foreground, self._Border_Color]

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Colors -> {E}')

    def Radius(self, Value=None):
        try:
            if Value is not None:
                self._Border_Radius = Value
                self._Apply()
            return self._Border_Radius
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Radius -> {E}')

    def Shadow(self, X=None, Y=None, Blur=None, Spread=None, Color=None):
        try:
            if X is not None:
                self._Shadow_X = X
            if Y is not None:
                self._Shadow_Y = Y
            if Blur is not None:
                self._Shadow_Blur = Blur
            if Spread is not None:
                self._Shadow_Spread = Spread
            if Color is not None:
                self._Shadow_Color = Color

            self._Apply()

            return [self._Shadow_X, self._Shadow_Y, self._Shadow_Blur, self._Shadow_Spread, self._Shadow_Color]

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Shadow -> {E}')

    def Place(self, Left=None, Top=None, Right=None, Bottom=None, Width=None, Height=None):
        try:
            self._Mode = 'Place'

            if Left is not None:
                self._Left = Left
            if Top is not None:
                self._Top = Top
            if Right is not None:
                self._Right = Right
            if Bottom is not None:
                self._Bottom = Bottom
            if Width is not None:
                self._Width = Width
            if Height is not None:
                self._Height = Height

            self._Apply()
            return self

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Place -> {E}')

    def Pack(self, **kwargs):
        try:
            self._Mode = 'Flow'
            self._Left = None
            self._Top = None
            self._Right = None
            self._Bottom = None

            if 'Classes' in kwargs:
                self._Classes = kwargs['Classes']
            if 'Style' in kwargs:
                self._Style = kwargs['Style']
            if 'Margin' in kwargs:
                self._Margin = kwargs['Margin']
            if 'Padding' in kwargs:
                self._Padding = kwargs['Padding']

            self._Apply()
            return self

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Pack -> {E}')