from types import SimpleNamespace
from nicegui import ui
from .N_GUI import GUI
from .N_Custom import Event_Bind


class Switch:

    def __init__(self, Main, *args, **kwargs):
        self._GUI = GUI._Instance
        if self._GUI is not None:
            self._Type = 'Switch'
            try:
                self._Config = {
                    'Name': False,
                    'Background': '#c9ced6',
                    'Foreground': '#ffffff',
                    'Active_Background': '#22c55e',
                    'Active_Foreground': '#ffffff',
                    'Knob_Background': '#ffffff',
                    'Border_Color': 'transparent',
                    'Border_Size': 0,
                    'Border_Radius': 999,
                    'Display': True,
                    'Left': None,
                    'Top': None,
                    'Right': None,
                    'Bottom': None,
                    'Width': 58,
                    'Height': 30,
                    'Font_Size': 10,
                    'Font_Weight': '700',
                    'Font_Family': 'Helvetica',
                    'Disable': False,
                    'Value': False,
                    'Text_On': 'ON',
                    'Text_Off': 'OFF',
                    'Hover_Background': False,
                    'Hover_Border_Color': False,
                    'Padding': 3,
                    'Margin': 0,
                    'Mode': 'Flow',
                    'Classes': '',
                    'Style': '',
                    'Z_Index': None,
                    'Shadow_X': 0,
                    'Shadow_Y': 2,
                    'Shadow_Blur': 8,
                    'Shadow_Spread': 0,
                    'Shadow_Color': 'rgba(0,0,0,0.18)',
                    'Text_On': '',
                    'Text_Off': '',
                }

                self._Initialized = False
                self._Main = Main
                self._Widget = None
                self._Frame = None
                self._Text = None
                self._Knob = None

                self._Name = False
                self._Background = '#c9ced6'
                self._Foreground = '#ffffff'
                self._Active_Background = '#22c55e'
                self._Active_Foreground = '#ffffff'
                self._Knob_Background = '#ffffff'
                self._Border_Color = 'transparent'
                self._Border_Size = 0
                self._Border_Radius = 999
                self._Display = True
                self._Left = None
                self._Top = None
                self._Right = None
                self._Bottom = None
                self._Width = 58
                self._Height = 30
                self._Font_Size = 10
                self._Font_Weight = '700'
                self._Font_Family = 'Helvetica'
                self._Disable = False
                self._Value = False
                self._Text_On = 'ON'
                self._Text_Off = 'OFF'
                self._Hover_Background = False
                self._Hover_Border_Color = False
                self._Padding = 3
                self._Margin = 0
                self._Mode = 'Flow'
                self._Classes = ''
                self._Style = ''
                self._Z_Index = None
                self._Shadow_X = 0
                self._Shadow_Y = 2
                self._Shadow_Blur = 8
                self._Shadow_Spread = 0
                self._Shadow_Color = 'rgba(0,0,0,0.18)'
                self._Text_On = ''
                self._Text_Off = ''

                self._Hover = False
                self._On_Show = False
                self._On_Hide = False
                self._On_Change = False

                if kwargs:
                    self.Config(**kwargs)
            except Exception as E:
                self._GUI.Error(f'{self._Type} -> Init -> {E}')
        else:
            print('Error: Wavionix -> GUI Instance Has Not Been Created')

    def __str__(self):
        return 'Nucleon_Wavionix_Switch[]'

    def __repr__(self):
        return 'Nucleon_Wavionix_Switch[]'

    def _Unit(self, Value):
        if Value is None or Value is False or Value == '':
            return None
        if isinstance(Value, (int, float)):
            return f'{Value}px'
        return str(Value)

    def _Number(self, Value):
        if Value is None or Value is False or Value == '':
            return 0.0
        if isinstance(Value, (int, float)):
            return float(Value)
        try:
            Text = str(Value).strip().lower().replace('px', '')
            return float(Text)
        except Exception:
            return 0.0

    def _Get_Parent(self):
        if hasattr(self._Main, 'Widget') and callable(self._Main.Widget):
            return self._Main.Widget()
        if hasattr(self._Main, '_Frame') and self._Main._Frame is not None:
            return self._Main._Frame
        if hasattr(self._Main, '_Widget') and not isinstance(self._Main._Widget, list):
            return self._Main._Widget
        return self._Main

    def _Build_Shadow(self):
        X = self._Unit(self._Shadow_X) or '0px'
        Y = self._Unit(self._Shadow_Y) or '0px'
        Blur = self._Unit(self._Shadow_Blur) or '0px'
        Spread = self._Unit(self._Shadow_Spread) or '0px'
        Color = self._Shadow_Color or 'transparent'
        return f'{X} {Y} {Blur} {Spread} {Color}'

    def _Current_Background(self):
        if self._Value:
            return self._Active_Background
        if self._Hover and self._Hover_Background:
            return self._Hover_Background
        return self._Background

    def _Current_Foreground(self):
        if self._Value:
            return self._Active_Foreground
        return self._Foreground

    def _Current_Border_Color(self):
        if self._Hover and self._Hover_Border_Color:
            return self._Hover_Border_Color
        return self._Border_Color

    def _Knob_Size(self):
        Height = self._Number(self._Height or 30)
        Padding = self._Number(self._Padding or 0)
        Border = self._Number(self._Border_Size or 0)
        Size = Height - (Padding * 2) - (Border * 2)
        return max(12.0, Size)

    def _Knob_Travel(self):
        Width = self._Number(self._Width or 58)
        Padding = self._Number(self._Padding or 0)
        Border = self._Number(self._Border_Size or 0)
        Knob = self._Knob_Size()
        Travel = Width - Knob - (Padding * 2) - (Border * 2)
        return max(0.0, Travel)

    def _Bool(self, Value=False):
        try:
            if isinstance(Value, bool):
                return Value
            if isinstance(Value, (int, float)):
                return Value != 0
            if isinstance(Value, str):
                Text = Value.strip().lower()
                if Text in ['1', 'true', 'yes', 'on', 'active', 'checked']:
                    return True
                if Text in ['0', 'false', 'no', 'off', 'none', '', 'inactive', 'unchecked']:
                    return False
            return bool(Value)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Bool -> {E}')
            return False

    def _Build_Frame_Style(self):
        Width = self._Unit(self._Width) or '58px'
        Height = self._Unit(self._Height) or '30px'
        Padding = self._Unit(self._Padding) or '3px'
        Justify = 'flex-end' if self._Value else 'flex-start'
        Style = []
        Style.append('box-sizing: border-box')
        Style.append(f'display: {"flex" if self._Display else "none"}')
        Style.append('position: relative')
        Style.append('align-items: center')
        Style.append(f'justify-content: {Justify}')
        Style.append('overflow: hidden')
        Style.append('user-select: none')
        Style.append('outline: none')
        Style.append('touch-action: manipulation')
        Style.append(f'background: {self._Current_Background()}')
        Style.append(f'border: {self._Unit(self._Border_Size) or "0px"} solid {self._Current_Border_Color()}')
        Style.append(f'border-radius: {self._Unit(self._Border_Radius) or "999px"}')
        Style.append(f'box-shadow: {self._Build_Shadow()}')
        Style.append(f'padding: {Padding}')
        Style.append(f'margin: {self._Unit(self._Margin) or "0px"}')
        Style.append(f'width: {Width}')
        Style.append(f'height: {Height}')
        Style.append(f'min-width: {Width}')
        Style.append(f'min-height: {Height}')
        Style.append('transition: background 0.18s ease, border-color 0.18s ease, box-shadow 0.18s ease')
        Style.append('cursor: not-allowed' if self._Disable else 'cursor: pointer')
        if self._Mode == 'Place':
            Style.append('position: absolute')
            if self._Left is not None:
                Style.append(f'left: {self._Unit(self._Left)}')
            if self._Top is not None:
                Style.append(f'top: {self._Unit(self._Top)}')
            if self._Right is not None:
                Style.append(f'right: {self._Unit(self._Right)}')
            if self._Bottom is not None:
                Style.append(f'bottom: {self._Unit(self._Bottom)}')
        if self._Z_Index is not None:
            Style.append(f'z-index: {self._Z_Index}')
        if self._Disable:
            Style.append('pointer-events: none')
            Style.append('opacity: 0.55')
        if self._Style:
            Style.append(self._Style)
        return '; '.join(Style)

    def _Current_Text(self):
        try:
            Text = self._Text_On if self._Value else self._Text_Off
            if Text in [None, False]:
                return ''
            return str(Text)
        except Exception:
            return ''

    def _Build_Text_Style(self):
        Padding = max(8.0, self._Number(self._Padding or 0) + 8.0)
        Align = 'flex-start' if self._Value else 'flex-end'
        Current_Text = self._Current_Text()
        Style = []
        Style.append('position: absolute')
        Style.append('inset: 0')
        Style.append(f'display: {"flex" if Current_Text != "" else "none"}')
        Style.append('align-items: center')
        Style.append(f'justify-content: {Align}')
        Style.append(f'padding-left: {round(Padding, 2)}px')
        Style.append(f'padding-right: {round(Padding, 2)}px')
        Style.append('pointer-events: none')
        Style.append('user-select: none')
        Style.append('white-space: nowrap')
        Style.append('overflow: hidden')
        Style.append('text-overflow: ellipsis')
        Style.append(f'color: {self._Current_Foreground()}')
        Style.append(f'font-size: {self._Unit(self._Font_Size) or "10px"}')
        Style.append(f'font-weight: {self._Font_Weight}')
        Style.append(f'font-family: {self._Font_Family}')
        Style.append('letter-spacing: 0.06em')
        Style.append('line-height: 1')
        Style.append('text-transform: uppercase')
        Style.append('transition: all 0.18s ease')
        return '; '.join(Style)

    def _Build_Knob_Style(self):
        Style = []
        Style.append('position: relative')
        Style.append('height: 100%')
        Style.append('aspect-ratio: 1 / 1')
        Style.append('flex: 0 0 auto')
        Style.append(f'background: {self._Knob_Background}')
        Style.append('border-radius: 999px')
        Style.append('box-shadow: 0 1px 4px rgba(0,0,0,0.22)')
        Style.append('transition: transform 0.18s ease, margin 0.18s ease, box-shadow 0.18s ease')
        Style.append('will-change: transform')
        Style.append('z-index: 2')
        return '; '.join(Style)

    def _Emit_Change(self):
        try:
            if self._On_Change:
                self._On_Change(SimpleNamespace(value=self._Value, sender=self))
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Emit_Change -> {E}')

    def _Hover_In(self):
        try:
            self._Hover = True
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Hover_In -> {E}')

    def _Hover_Out(self):
        try:
            self._Hover = False
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Hover_Out -> {E}')

    def _Toggle_Click(self):
        try:
            if self._Disable:
                return
            self._Value = not self._Bool(self._Value)
            self._Apply()
            self._Emit_Change()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Toggle_Click -> {E}')

    def _Apply(self):
        try:
            if self._Frame is None or self._Text is None or self._Knob is None:
                return

            if hasattr(self._Frame, '_style'):
                self._Frame._style.clear()
            if hasattr(self._Frame, '_classes'):
                self._Frame._classes.clear()

            if hasattr(self._Text, '_style'):
                self._Text._style.clear()
            if hasattr(self._Text, '_classes'):
                self._Text._classes.clear()

            if hasattr(self._Knob, '_style'):
                self._Knob._style.clear()
            if hasattr(self._Knob, '_classes'):
                self._Knob._classes.clear()

            self._Frame.style(self._Build_Frame_Style())

            Classes = []
            if self._Classes:
                Classes.append(self._Classes)
            if len(Classes) > 0:
                self._Frame.classes(' '.join(Classes))

            self._Frame.props(
                f'tabindex={"-1" if self._Disable else "0"} '
                f'role=switch '
                f'aria-checked={"true" if self._Value else "false"} '
                f'aria-disabled={"true" if self._Disable else "false"}'
            )

            self._Text.set_text(self._Current_Text())
            self._Text.style(self._Build_Text_Style())

            self._Knob.style(self._Build_Knob_Style())

            self._Text.update()
            self._Knob.update()
            self._Frame.update()

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Apply -> {E}')

    def Copy(self, Name=False, Main=False):
        try:
            if not Main:
                Main = self._Main
            Instance = type(self)(Main)
            for Key in self._Config:
                if hasattr(self, '_' + Key):
                    setattr(Instance, '_' + Key, getattr(self, '_' + Key))
            if Name:
                Instance._Name = Name
            Instance.Create()
            return Instance
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Copy -> {E}')

    def Delete(self):
        try:
            if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self in self._Main._Widget:
                self._Main._Widget.remove(self)
            if self._Widget is not None:
                self._Widget.delete()
                self._Widget = None
                self._Frame = None
                self._Text = None
                self._Knob = None
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Delete -> {E}')

    def Hide(self):
        try:
            self._Display = False
            self._Apply()
            if self._On_Hide:
                self._On_Hide()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Hide -> {E}')

    def Show(self):
        try:
            self._Display = True
            self._Apply()
            if self._On_Show:
                self._On_Show()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Show -> {E}')

    def Get(self):
        try:
            return self._Value
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Get -> {E}')

    def Set(self, Value=False):
        try:
            self._Value = self._Bool(Value)
            self._Apply()
            return self._Value
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Set -> {E}')

    def Toggle(self):
        try:
            self._Toggle_Click()
            return self._Value
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Toggle -> {E}')

    def Set_On_Click(self):
        try:
            self._Toggle_Click()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Set_On_Click -> {E}')

    def Refresh(self):
        try:
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Refresh -> {E}')

    def Focus(self):
        try:
            if self._Frame is not None:
                self._Frame.run_method('focus')
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Focus -> {E}')

    def Widget(self):
        try:
            return self._Frame
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Widget -> {E}')

    def Bind(self, **Input):
        try:
            if 'On_Show' in Input:
                self._On_Show = Input['On_Show']
                del Input['On_Show']
            if 'On_Hide' in Input:
                self._On_Hide = Input['On_Hide']
                del Input['On_Hide']
            if 'On_Change' in Input:
                self._On_Change = Input['On_Change']
                del Input['On_Change']
            if self._Frame is not None and len(Input) > 0:
                Event_Bind(self._Frame, **Input)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Bind -> {E}')

    def Config_Get(self, *Input):
        try:
            Return = {}
            for Each in self._Config:
                if Each in Input:
                    Return[Each] = getattr(self, '_' + Each)
            return Return
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config_Get -> {E}')

    def Config(self, **Input):
        try:
            Run = False
            for Each in self._Config:
                if Each in Input:
                    setattr(self, '_' + Each, Input[Each])
                    Run = True
            if 'Value' in Input:
                self._Value = self._Bool(Input['Value'])
            if 'Check' in Input:
                self._Value = self._Bool(Input['Check'])
            if self._Initialized and Run:
                self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config -> {E}')

    def Move(self, Left=None, Top=None):
        try:
            if Left is not None:
                self._Left = (self._Left or 0) + Left
            if Top is not None:
                self._Top = (self._Top or 0) + Top
            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Move -> {E}')

    def Center(self, Left=None, Top=None):
        try:
            Width = self._Width or 0
            Height = self._Height or 0
            if Left is not None:
                self._Left = Left - Width / 2
            if Top is not None:
                self._Top = Top - Height / 2
            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()
            return [self._Left + Width / 2, self._Top + Height / 2]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Center -> {E}')

    def Position(self, Left=None, Top=None, Right=None, Bottom=None):
        try:
            if Left is not None:
                self._Left = Left
            if Top is not None:
                self._Top = Top
            if Right is not None:
                self._Right = Right
            if Bottom is not None:
                self._Bottom = Bottom
            if Left is not None or Top is not None or Right is not None or Bottom is not None:
                self._Mode = 'Place'
                self._Apply()
            return [self._Left, self._Top, self._Right, self._Bottom]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Position -> {E}')

    def Size(self, Width=False, Height=False):
        try:
            if Width is not False:
                self._Width = Width
            if Height is not False:
                self._Height = Height
            if Width is not False or Height is not False:
                self._Apply()
            return [self._Width, self._Height]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Size -> {E}')

    def Enlarge(self, Value=None):
        try:
            if Value is not None:
                self._Width = (self._Width or 0) + Value
                self._Height = (self._Height or 0) + Value
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Enlarge -> {E}')

    def Shrink(self, Value=None):
        try:
            if Value is not None:
                self._Width = max(0, (self._Width or 0) - Value)
                self._Height = max(0, (self._Height or 0) - Value)
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Shrink -> {E}')

    def Box(self):
        try:
            return [self._Left, self._Top, self._Width, self._Height]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Box -> {E}')

    def Ratio(self):
        try:
            return [1, 1]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Ratio -> {E}')

    def Locate(self, Width, Height, Left, Top):
        try:
            Width = self._Width * (Width / 100)
            Height = self._Height * (Height / 100)
            Left = self._Width * (Left / 100)
            Top = self._Height * (Top / 100)
            return [Width, Height, Left, Top]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Locate -> {E}')

    def Locate_Reverse(self, Width, Height, Left, Top):
        try:
            Width = round((Width / self._Width) * 100, 3)
            Height = round((Height / self._Height) * 100, 3)
            Left = round((Left / self._Width) * 100, 3)
            Top = round((Top / self._Height) * 100, 3)
            return [Width, Height, Left, Top]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Locate_Reverse -> {E}')

    def Place(self, Left=None, Top=None, Right=None, Bottom=None, Width=None, Height=None):
        try:
            self._Mode = 'Place'
            if Left is not None:
                self._Left = Left
            if Top is not None:
                self._Top = Top
            if Right is not None:
                self._Right = Right
            if Bottom is not None:
                self._Bottom = Bottom
            if Width is not None:
                self._Width = Width
            if Height is not None:
                self._Height = Height
            self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Place -> {E}')

    def Pack(self, Classes=None, Style=None, Margin=None, Padding=None):
        try:
            self._Mode = 'Flow'
            self._Left = None
            self._Top = None
            self._Right = None
            self._Bottom = None
            if Classes is not None:
                self._Classes = Classes
            if Style is not None:
                self._Style = Style
            if Margin is not None:
                self._Margin = Margin
            if Padding is not None:
                self._Padding = Padding
            self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Pack -> {E}')

    def Create(self):
        try:
            if self._Widget is None:
                Parent = self._Get_Parent()
                
                if self._Mode != 'Place':
                    if self._Left is not None or self._Top is not None or self._Right is not None or self._Bottom is not None:
                        self._Mode = 'Place'


                if Parent is not None:
                    with Parent:
                        self._Widget = ui.element('div')
                        self._Widget.style('display: contents')

                        self._Frame = ui.element('div')
                        with self._Frame:
                            self._Text = ui.label('')
                            self._Knob = ui.element('div')
                else:
                    self._Widget = ui.element('div')
                    self._Widget.style('display: contents')

                    self._Frame = ui.element('div')
                    with self._Frame:
                        self._Text = ui.label('')
                        self._Knob = ui.element('div')

                self._Frame.on('click', lambda E: self._Toggle_Click())
                self._Frame.on('keydown.enter', lambda E: self._Toggle_Click())
                self._Frame.on('keydown.space', lambda E: self._Toggle_Click())
                self._Frame.on('mouseenter', lambda E: self._Hover_In())
                self._Frame.on('mouseleave', lambda E: self._Hover_Out())

                if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self not in self._Main._Widget:
                    self._Main._Widget.append(self)

                self._Initialized = True

            self._Apply()

            if self._Name:
                self._Main.__dict__[self._Name] = self

            if not self._Display:
                self.Hide()

            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Create -> {E}')