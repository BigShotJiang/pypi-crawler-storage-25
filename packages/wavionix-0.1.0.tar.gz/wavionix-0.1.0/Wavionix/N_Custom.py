Event_Map = {
    'On_Click': {'Event': 'click'},
    'On_Release': {'Event': 'mouseup', 'Button': 0},
    'On_Double_Click': {'Event': 'dblclick', 'Button': 0},
    'On_Right_Click': {'Event': 'contextmenu', 'Button': 2},
    'On_Right_Release': {'Event': 'mouseup', 'Button': 2},
    'On_Middle_Click': {'Event': 'mousedown', 'Button': 1},
    'On_Middle_Release': {'Event': 'mouseup', 'Button': 1},
    'On_Drag': {'Event': 'mousemove', 'Buttons': 1},
    'On_Right_Drag': {'Event': 'mousemove', 'Buttons': 2},
    'On_Middle_Drag': {'Event': 'mousemove', 'Buttons': 4},
    'On_Hover_In': {'Event': 'mouseenter'},
    'On_Hover_Out': {'Event': 'mouseleave'},
    'On_Motion': {'Event': 'mousemove'},
    'On_Focus_In': {'Event': 'focus'},
    'On_Focus_Out': {'Event': 'blur'},
    'On_Key': {'Event': 'keydown'},
    'On_Key_Release': {'Event': 'keyup'},
    'On_Mouse_Wheel': {'Event': 'wheel'},
    'On_Change': {'Event': 'update:model-value'},
    'On_Copy': {'Event': 'copy'},
    'On_Paste': {'Event': 'paste'},
    'On_Cut': {'Event': 'cut'},
    'On_Undo': {'Event': 'keydown', 'Ctrl': True, 'Key': 'z'},
    'On_Redo': [
        {'Event': 'keydown', 'Ctrl': True, 'Key': 'y'},
        {'Event': 'keydown', 'Ctrl': True, 'Shift': True, 'Key': 'Z'},
        {'Event': 'keydown', 'Ctrl': True, 'Shift': True, 'Key': 'z'},
    ],
    'On_Control_Click': {'Event': 'click', 'Ctrl': True},
    'On_Control_Release': {'Event': 'mouseup', 'Ctrl': True, 'Button': 0},
    'On_Control_Double_Click': {'Event': 'dblclick', 'Ctrl': True, 'Button': 0},
    'On_Control_Right_Click': {'Event': 'contextmenu', 'Ctrl': True, 'Button': 2},
    'On_Control_Right_Release': {'Event': 'mouseup', 'Ctrl': True, 'Button': 2},
    'On_Control_Middle_Click': {'Event': 'mousedown', 'Ctrl': True, 'Button': 1},
    'On_Control_Middle_Release': {'Event': 'mouseup', 'Ctrl': True, 'Button': 1},
    'On_Control_Drag': {'Event': 'mousemove', 'Ctrl': True, 'Buttons': 1},
    'On_Control_Right_Drag': {'Event': 'mousemove', 'Ctrl': True, 'Buttons': 2},
    'On_Control_Middle_Drag': {'Event': 'mousemove', 'Ctrl': True, 'Buttons': 4},
    'On_Control_Hover_In': {'Event': 'mouseenter', 'Ctrl': True},
    'On_Control_Hover_Out': {'Event': 'mouseleave', 'Ctrl': True},
    'On_Control_Mouse_Wheel': {'Event': 'wheel', 'Ctrl': True},
    'On_Shift_Click': {'Event': 'click', 'Shift': True},
    'On_Shift_Release': {'Event': 'mouseup', 'Shift': True, 'Button': 0},
    'On_Shift_Double_Click': {'Event': 'dblclick', 'Shift': True, 'Button': 0},
    'On_Shift_Right_Click': {'Event': 'contextmenu', 'Shift': True, 'Button': 2},
    'On_Shift_Right_Release': {'Event': 'mouseup', 'Shift': True, 'Button': 2},
    'On_Shift_Middle_Click': {'Event': 'mousedown', 'Shift': True, 'Button': 1},
    'On_Shift_Middle_Release': {'Event': 'mouseup', 'Shift': True, 'Button': 1},
    'On_Shift_Drag': {'Event': 'mousemove', 'Shift': True, 'Buttons': 1},
    'On_Shift_Right_Drag': {'Event': 'mousemove', 'Shift': True, 'Buttons': 2},
    'On_Shift_Middle_Drag': {'Event': 'mousemove', 'Shift': True, 'Buttons': 4},
    'On_Shift_Hover_In': {'Event': 'mouseenter', 'Shift': True},
    'On_Shift_Hover_Out': {'Event': 'mouseleave', 'Shift': True},
    'On_Shift_Mouse_Wheel': {'Event': 'wheel', 'Shift': True},
    'On_Alt_Click': {'Event': 'click', 'Alt': True},
    'On_Alt_Release': {'Event': 'mouseup', 'Alt': True, 'Button': 0},
    'On_Alt_Double_Click': {'Event': 'dblclick', 'Alt': True, 'Button': 0},
    'On_Alt_Right_Click': {'Event': 'contextmenu', 'Alt': True, 'Button': 2},
    'On_Alt_Right_Release': {'Event': 'mouseup', 'Alt': True, 'Button': 2},
    'On_Alt_Middle_Click': {'Event': 'mousedown', 'Alt': True, 'Button': 1},
    'On_Alt_Middle_Release': {'Event': 'mouseup', 'Alt': True, 'Button': 1},
    'On_Alt_Drag': {'Event': 'mousemove', 'Alt': True, 'Buttons': 1},
    'On_Alt_Right_Drag': {'Event': 'mousemove', 'Alt': True, 'Buttons': 2},
    'On_Alt_Middle_Drag': {'Event': 'mousemove', 'Alt': True, 'Buttons': 4},
    'On_Alt_Hover_In': {'Event': 'mouseenter', 'Alt': True},
    'On_Alt_Hover_Out': {'Event': 'mouseleave', 'Alt': True},
    'On_Alt_Mouse_Wheel': {'Event': 'wheel', 'Alt': True},
}

_Cursor_Map = {
    'Cursor_Hand': 'pointer',
    'Cursor_Loading': 'progress',
    'Cursor_Resize_Vertical': 'ns-resize',
    'Cursor_Resize_Horizontal': 'ew-resize',
    'Cursor_Arrow': 'default',
}


def _Get_Event_Args(Event):
    Args = getattr(Event, 'args', None)
    if isinstance(Args, dict):
        return Args
    return {}


def _Get_Arg(Args, *Names, Default=None):
    for Name in Names:
        if Name in Args:
            return Args[Name]
    return Default


def _To_Bool(Value):
    if isinstance(Value, bool):
        return Value
    if isinstance(Value, str):
        return Value.lower() in ('true', '1', 'yes', 'on')
    if isinstance(Value, (int, float)):
        return Value != 0
    return bool(Value)


def _Normalize_Specs(Spec):
    if isinstance(Spec, list):
        return Spec
    return [Spec]


def _Matches_Spec(Event, Spec):
    Args = _Get_Event_Args(Event)

    if 'Button' in Spec:
        Button = _Get_Arg(Args, 'button', 'Button', Default=None)
        if Button is None:
            return False
        try:
            if int(Button) != int(Spec['Button']):
                return False
        except Exception:
            return False

    if 'Buttons' in Spec:
        Buttons = _Get_Arg(Args, 'buttons', 'Buttons', Default=None)
        if Buttons is None:
            return False
        try:
            Buttons = int(Buttons)
        except Exception:
            return False
        if (Buttons & int(Spec['Buttons'])) == 0:
            return False

    if 'Ctrl' in Spec:
        Ctrl = _To_Bool(_Get_Arg(Args, 'ctrlKey', 'ctrl', 'Control', Default=False))
        if Ctrl != bool(Spec['Ctrl']):
            return False

    if 'Shift' in Spec:
        Shift = _To_Bool(_Get_Arg(Args, 'shiftKey', 'shift', 'Shift', Default=False))
        if Shift != bool(Spec['Shift']):
            return False

    if 'Alt' in Spec:
        Alt = _To_Bool(_Get_Arg(Args, 'altKey', 'alt', 'Alt', Default=False))
        if Alt != bool(Spec['Alt']):
            return False

    if 'Key' in Spec:
        Key = _Get_Arg(Args, 'key', 'Key', Default=None)
        if Key != Spec['Key']:
            return False

    return True


def _Call_Handler(Handler, Event):
    try:
        return Handler(Event)
    except TypeError:
        return Handler()


def _Create_Wrapped_Handler(Spec, Handler):
    def _Wrapped(Event):
        if _Matches_Spec(Event, Spec):
            return _Call_Handler(Handler, Event)
    return _Wrapped


def _Apply_Cursor(Widget, Input):
    if 'Cursor' in Input and Input['Cursor']:
        Widget.style(f'cursor: {Input["Cursor"]};')
        return

    for Key, Value in _Cursor_Map.items():
        if Input.get(Key):
            Widget.style(f'cursor: {Value};')
            return


def _Bind_Event_Spec(Widget, Spec, Handler):
    Widget.on(Spec['Event'], _Create_Wrapped_Handler(Spec, Handler))


def Event_Bind(Widget, **Input):
    _Apply_Cursor(Widget, Input)

    for Key, Value in Input.items():
        if Key not in Event_Map:
            continue
        if not callable(Value):
            continue
        Specs = _Normalize_Specs(Event_Map[Key])
        for Spec in Specs:
            _Bind_Event_Spec(Widget, Spec, Value)

    return Widget