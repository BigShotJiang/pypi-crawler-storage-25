from nicegui import ui
from .N_GUI import GUI
from .N_Custom import Event_Bind


class Variable:

    def __init__(self, *args, **kwargs):
        self._GUI = GUI._Instance
        if self._GUI is not None:
            self._Type = 'Variable'
            self._Variable = False
            self._Widget = []
        else:
            print('Error: GUI Create Instance Has Not Been Created')

    def __str__(self):
        return 'Nucleon_GUI_Radio_Value[]'

    def __repr__(self):
        return 'Nucleon_GUI_Radio_Value[]'

    def Get(self):
        try:
            return self._Variable
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Get -> {E}')

    def Set(self, Value):
        try:
            self._Variable = Value
            for Each in list(self._Widget):
                Each.Refresh()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Set -> {E}')


class Radio:

    def __init__(self, Main, *args, **kwargs):
        self._GUI = GUI._Instance
        if self._GUI is not None:
            self._Type = 'Radio'
            try:
                self._Config = {
                    'Name': False,
                    'Background': False,
                    'Foreground': '#000000',
                    'Border_Color': 'transparent',
                    'Border_Size': 0,
                    'Border_Radius': 0,
                    'Display': True,
                    'Left': None,
                    'Top': None,
                    'Right': None,
                    'Bottom': None,
                    'Width': None,
                    'Height': None,
                    'Text': '',
                    'Value': False,
                    'Variable': False,
                    'Disable': False,
                    'Hover_Background': False,
                    'Hover_Foreground': False,
                    'Hover_Border_Color': False,
                    'Padding': 0,
                    'Margin': 0,
                    'Mode': 'Flow',
                    'Classes': '',
                    'Style': '',
                    'Z_Index': None,
                    'Shadow_X': 0,
                    'Shadow_Y': 0,
                    'Shadow_Blur': 0,
                    'Shadow_Spread': 0,
                    'Shadow_Color': 'transparent',
                }
                self._Initialized = False
                self._Main = Main
                self._Widget = None
                self._Row = None
                self._Icon = None
                self._Label = None
                self._Name = False
                self._Background = False
                self._Foreground = '#000000'
                self._Border_Color = 'transparent'
                self._Border_Size = 0
                self._Border_Radius = 0
                self._Display = True
                self._Left = None
                self._Top = None
                self._Right = None
                self._Bottom = None
                self._Width = None
                self._Height = None
                self._Text = ''
                self._Value = False
                self._Variable = False
                self._Disable = False
                self._Hover_Background = False
                self._Hover_Foreground = False
                self._Hover_Border_Color = False
                self._Padding = 0
                self._Margin = 0
                self._Mode = 'Flow'
                self._Classes = ''
                self._Style = ''
                self._Z_Index = None
                self._Shadow_X = 0
                self._Shadow_Y = 0
                self._Shadow_Blur = 0
                self._Shadow_Spread = 0
                self._Shadow_Color = 'transparent'
                self._On_Change = False
                self._On_Show = False
                self._On_Hide = False
                if kwargs:
                    self.Config(**kwargs)
            except Exception as E:
                self._GUI.Error(f'{self._Type} -> Init -> {E}')
        else:
            print('Error: Wavionix -> GUI Instance Has Not Been Created')

    def __str__(self):
        return 'Nucleon_Wavionix_Radio[]'

    def __repr__(self):
        return 'Nucleon_Wavionix_Radio[]'

    def _Hive_Color(self, Value):
        Hive = {
            'Hive_Yellow': '#F4C430',
            'Hive_Gold': '#D4A017',
            'Hive_Honey': '#FFBF00',
            'Hive_Amber': '#FFB000',
            'Hive_Orange': '#F28C28',
            'Hive_Brown': '#6B4F1D',
            'Hive_Dark': '#1F1B16',
            'Hive_Light': '#FFF8E1',
            'Hive_Cream': '#FFF3BF',
            'Hive_White': '#FFFFFF',
            'Hive_Black': '#000000',
        }
        if isinstance(Value, str) and Value in Hive:
            return Hive[Value]
        return Value

    def _Unit(self, Value):
        if Value is None or Value is False or Value == '':
            return None
        if isinstance(Value, (int, float)):
            return f'{Value}px'
        return str(Value)

    def _Number(self, Value):
        if Value is None or Value is False:
            return 0
        try:
            return float(Value)
        except Exception:
            return 0

    def _Get_Parent(self):
        if hasattr(self._Main, 'Widget') and callable(self._Main.Widget):
            return self._Main.Widget()
        if hasattr(self._Main, '_Frame') and self._Main._Frame is not None:
            return self._Main._Frame
        if hasattr(self._Main, '_Widget') and not isinstance(self._Main._Widget, list):
            return self._Main._Widget
        return self._Main

    def _Selected(self):
        try:
            return bool(self._Variable and self._Variable.Get() == self._Value)
        except Exception:
            return False

    def _Get_Background(self):
        if self._Selected():
            if self._Background in [False, None, '']:
                return self._Hive_Color('Hive_Honey')
            return self._Hive_Color(self._Background)
        if self._Background in [False, None, '']:
            if hasattr(self._Main, '_Background'):
                return self._Hive_Color(self._Main._Background)
            return 'transparent'
        return self._Hive_Color(self._Background)

    def _Get_Foreground(self):
        return self._Hive_Color(self._Foreground)

    def _Get_Border_Color(self):
        return self._Hive_Color(self._Border_Color)

    def _Get_Shadow_Color(self):
        return self._Hive_Color(self._Shadow_Color)

    def _Build_Shadow(self):
        X = self._Unit(self._Shadow_X) or '0px'
        Y = self._Unit(self._Shadow_Y) or '0px'
        Blur = self._Unit(self._Shadow_Blur) or '0px'
        Spread = self._Unit(self._Shadow_Spread) or '0px'
        Color = self._Get_Shadow_Color() or 'transparent'
        return f'{X} {Y} {Blur} {Spread} {Color}'

    def _Build_Style(self):
        Style = []
        Style.append('box-sizing: border-box')
        Style.append(f'display: {"flex" if self._Display else "none"}')
        Style.append('align-items: center')
        Style.append('justify-content: flex-start')
        Style.append('gap: 10px')
        Style.append(f'background: {self._Get_Background()}')
        Style.append(f'color: {self._Get_Foreground()}')
        Style.append(f'border: {self._Unit(self._Border_Size) or "0px"} solid {self._Get_Border_Color()}')
        Style.append(f'border-radius: {self._Unit(self._Border_Radius) or "0px"}')
        Style.append(f'box-shadow: {self._Build_Shadow()}')
        Style.append(f'padding: {self._Unit(self._Padding) or "0px"}')
        Style.append(f'margin: {self._Unit(self._Margin) or "0px"}')
        Style.append('transition: all 0.2s ease')
        Style.append('user-select: none')

        if self._Mode == 'Place':
            Style.append('position: absolute')
            if self._Left is not None:
                Style.append(f'left: {self._Unit(self._Left)}')
            if self._Top is not None:
                Style.append(f'top: {self._Unit(self._Top)}')
            if self._Right is not None:
                Style.append(f'right: {self._Unit(self._Right)}')
            if self._Bottom is not None:
                Style.append(f'bottom: {self._Unit(self._Bottom)}')

        if self._Width is not None:
            Style.append(f'width: {self._Unit(self._Width)}')
        if self._Height is not None:
            Style.append(f'height: {self._Unit(self._Height)}')

        if self._Z_Index is not None:
            Style.append(f'z-index: {self._Z_Index}')

        if self._Disable:
            Style.append('pointer-events: none')
            Style.append('opacity: 0.55')
            Style.append('cursor: default')
        else:
            Style.append('cursor: pointer')

        if self._Style:
            Style.append(self._Style)

        return '; '.join(Style)

    def _Build_Icon_Style(self):
        Border = self._Hive_Color('Hive_Amber') if self._Selected() else self._Hive_Color('Hive_Brown')
        Fill = self._Hive_Color('Hive_Amber') if self._Selected() else 'transparent'
        return '; '.join([
            'width: 18px',
            'height: 18px',
            'min-width: 18px',
            'min-height: 18px',
            'border-radius: 9999px',
            f'border: 2px solid {Border}',
            f'background: radial-gradient(circle, {Fill} 0 45%, transparent 50%)',
            'transition: all 0.2s ease',
        ])

    def _Click(self, E=None):
        try:
            if self._Disable:
                return
            if self._Variable:
                if self._Variable.Get() != self._Value:
                    self._Variable._Variable = self._Value
                    for Each in list(self._Variable._Widget):
                        Each.Refresh()
                    if self._On_Change:
                        self._On_Change(E)
        except Exception as E2:
            self._GUI.Error(f'{self._Type} -> _Click -> {E2}')

    def _Apply(self):
        try:
            if self._Widget is None:
                return

            if hasattr(self._Widget, '_style'):
                self._Widget._style.clear()

            if hasattr(self._Widget, '_classes'):
                self._Widget._classes.clear()

            self._Widget.style(self._Build_Style())

            Classes = []
            if self._Classes:
                Classes.append(self._Classes)

            if self._Hover_Background and not self._Disable:
                Classes.append(f'hover:!bg-[{self._Hive_Color(self._Hover_Background)}]')

            if self._Hover_Foreground and not self._Disable:
                Classes.append(f'hover:!text-[{self._Hive_Color(self._Hover_Foreground)}]')

            if self._Hover_Border_Color and not self._Disable:
                Classes.append(f'hover:!border-[{self._Hive_Color(self._Hover_Border_Color)}]')

            if self._Selected():
                Classes.append('font-bold')

            if len(Classes) > 0:
                self._Widget.classes(' '.join(Classes))

            if self._Icon is not None:
                if hasattr(self._Icon, '_style'):
                    self._Icon._style.clear()
                self._Icon.style(self._Build_Icon_Style())

            if self._Label is not None:
                self._Label.set_text(str(self._Text))
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Apply -> {E}')

    def Copy(self, Name=False, Main=False):
        try:
            if not Main:
                Main = self._Main
            Instance = type(self)(Main)
            for Key in self._Config:
                if hasattr(self, '_' + Key):
                    setattr(Instance, '_' + Key, getattr(self, '_' + Key))
            if Name:
                Instance._Name = Name
            Instance.Create()
            return Instance
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Copy -> {E}')

    def Delete(self):
        try:
            if self._Variable and self in self._Variable._Widget:
                self._Variable._Widget.remove(self)
            if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self in self._Main._Widget:
                self._Main._Widget.remove(self)
            if self._Widget is not None:
                self._Widget.delete()
                self._Widget = None
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Delete -> {E}')

    def Hide(self):
        try:
            self._Display = False
            self._Apply()
            if self._On_Hide:
                self._On_Hide()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Hide -> {E}')

    def Show(self):
        try:
            self._Display = True
            self._Apply()
            if self._On_Show:
                self._On_Show()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Show -> {E}')

    def Get(self):
        try:
            return self._Selected()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Get -> {E}')

    def Set(self):
        try:
            if self._Variable:
                self._Variable.Set(self._Value)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Set -> {E}')

    def Reset(self):
        try:
            self.Refresh()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Reset -> {E}')

    def Refresh(self):
        try:
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Refresh -> {E}')

    def Widget(self):
        try:
            return self._Widget
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Widget -> {E}')

    def Bind(self, **Input):
        try:
            if 'On_Show' in Input:
                self._On_Show = Input['On_Show']
                del Input['On_Show']
            if 'On_Hide' in Input:
                self._On_Hide = Input['On_Hide']
                del Input['On_Hide']
            if 'On_Change' in Input:
                self._On_Change = Input['On_Change']
                del Input['On_Change']
            if self._Widget is not None and len(Input) > 0:
                Event_Bind(self._Widget, **Input)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Bind -> {E}')

    def Config_Get(self, *Input):
        try:
            Return = {}
            for Each in self._Config:
                if Each in Input:
                    Return[Each] = getattr(self, '_' + Each)
            return Return
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config_Get -> {E}')

    def Config(self, **Input):
        try:
            Run = False
            for Each in self._Config:
                if Each in Input:
                    setattr(self, '_' + Each, Input[Each])
                    Run = True
            if self._Initialized and Run:
                self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config -> {E}')

    def Move(self, Left=None, Top=None):
        try:
            if Left is not None:
                self._Left = self._Number(self._Left) + self._Number(Left)
            if Top is not None:
                self._Top = self._Number(self._Top) + self._Number(Top)
            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()
            return [self._Left, self._Top]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Move -> {E}')

    def Center(self, Left=None, Top=None):
        try:
            Width = self._Number(self._Width)
            Height = self._Number(self._Height)
            if Left is not None:
                self._Left = self._Number(Left) - Width / 2
            if Top is not None:
                self._Top = self._Number(Top) - Height / 2
            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()
            return [self._Number(self._Left) + Width / 2, self._Number(self._Top) + Height / 2]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Center -> {E}')

    def Position(self, Left=None, Top=None, Right=None, Bottom=None):
        try:
            if Left is not None:
                self._Left = Left
            if Top is not None:
                self._Top = Top
            if Right is not None:
                self._Right = Right
            if Bottom is not None:
                self._Bottom = Bottom
            if Left is not None or Top is not None or Right is not None or Bottom is not None:
                self._Mode = 'Place'
                self._Apply()
            return [self._Left, self._Top, self._Right, self._Bottom]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Position -> {E}')

    def Size(self, Width=None, Height=None):
        try:
            if Width is not None:
                self._Width = Width
            if Height is not None:
                self._Height = Height
            if Width is not None or Height is not None:
                self._Apply()
            return [self._Width, self._Height]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Size -> {E}')

    def Enlarge(self, Value=None):
        try:
            if Value is not None:
                self._Width = self._Number(self._Width) + self._Number(Value)
                self._Height = self._Number(self._Height) + self._Number(Value)
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Enlarge -> {E}')

    def Shrink(self, Value=None):
        try:
            if Value is not None:
                self._Width = max(0, self._Number(self._Width) - self._Number(Value))
                self._Height = max(0, self._Number(self._Height) - self._Number(Value))
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Shrink -> {E}')

    def Box(self):
        try:
            return [self._Left, self._Top, self._Width, self._Height]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Box -> {E}')

    def Colors(self, Background=None, Foreground=None, Border_Color=None):
        try:
            if Background is not None:
                self._Background = Background
            if Foreground is not None:
                self._Foreground = Foreground
            if Border_Color is not None:
                self._Border_Color = Border_Color
            self._Apply()
            return [self._Background, self._Foreground, self._Border_Color]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Colors -> {E}')

    def Radius(self, Value=None):
        try:
            if Value is not None:
                self._Border_Radius = Value
                self._Apply()
            return self._Border_Radius
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Radius -> {E}')

    def Shadow(self, X=None, Y=None, Blur=None, Spread=None, Color=None):
        try:
            if X is not None:
                self._Shadow_X = X
            if Y is not None:
                self._Shadow_Y = Y
            if Blur is not None:
                self._Shadow_Blur = Blur
            if Spread is not None:
                self._Shadow_Spread = Spread
            if Color is not None:
                self._Shadow_Color = Color
            self._Apply()
            return [self._Shadow_X, self._Shadow_Y, self._Shadow_Blur, self._Shadow_Spread, self._Shadow_Color]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Shadow -> {E}')

    def Disable(self, Value=True):
        try:
            self._Disable = Value
            self._Apply()
            return self._Disable
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Disable -> {E}')

    def Enable(self):
        try:
            self._Disable = False
            self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Enable -> {E}')

    def Place(self, Left=None, Top=None, Right=None, Bottom=None, Width=None, Height=None):
        try:
            self._Mode = 'Place'
            if Left is not None:
                self._Left = Left
            if Top is not None:
                self._Top = Top
            if Right is not None:
                self._Right = Right
            if Bottom is not None:
                self._Bottom = Bottom
            if Width is not None:
                self._Width = Width
            if Height is not None:
                self._Height = Height
            self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Place -> {E}')

    def Pack(self, Classes=None, Style=None, Margin=None, Padding=None):
        try:
            self._Mode = 'Flow'
            self._Left = None
            self._Top = None
            self._Right = None
            self._Bottom = None
            if Classes is not None:
                self._Classes = Classes
            if Style is not None:
                self._Style = Style
            if Margin is not None:
                self._Margin = Margin
            if Padding is not None:
                self._Padding = Padding
            self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Pack -> {E}')

    def Create(self):
        try:
            if self._Widget is None:
                Parent = self._Get_Parent()
                
                if self._Mode != 'Place':
                    if self._Left is not None or self._Top is not None or self._Right is not None or self._Bottom is not None:
                        self._Mode = 'Place'


                if Parent is not None:
                    with Parent:
                        self._Widget = ui.row().classes('items-center no-wrap')
                        with self._Widget:
                            self._Icon = ui.element('div')
                            self._Label = ui.label(str(self._Text))
                else:
                    self._Widget = ui.row().classes('items-center no-wrap')
                    with self._Widget:
                        self._Icon = ui.element('div')
                        self._Label = ui.label(str(self._Text))

                self._Widget.on('click', lambda E: self._Click(E))

                if self._Variable and self not in self._Variable._Widget:
                    self._Variable._Widget.append(self)

                if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self not in self._Main._Widget:
                    self._Main._Widget.append(self)

                self._Initialized = True

            self._Apply()

            if self._Name:
                self._Main.__dict__[self._Name] = self

            if not self._Display:
                self.Hide()

            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Create -> {E}')