from nicegui import ui
from .N_GUI import GUI
from .N_Custom import Event_Bind


class Text:

    def __init__(self, Main, *args, **kwargs):
        self._GUI = GUI._Instance
        if self._GUI is not None:
            self._Type = 'Text'
            try:
                self._Config = {
                    'Name': False,
                    'Background': '#ffffff',
                    'Foreground': '#000000',
                    'Border_Color': '#000000',
                    'Border_Size': 0,
                    'Border_Radius': 0,
                    'Display': True,
                    'Left': None,
                    'Top': None,
                    'Right': None,
                    'Bottom': None,
                    'Width': None,
                    'Height': 160,
                    'Font_Size': 12,
                    'Font_Weight': 'normal',
                    'Font_Family': 'Helvetica',
                    'Disable': False,
                    'Placeholder': '',
                    'Value': '',
                    'Padding': '8px 10px',
                    'Margin': 0,
                    'Mode': 'Flow',
                    'Classes': '',
                    'Style': '',
                    'Z_Index': None,
                    'Shadow_X': 0,
                    'Shadow_Y': 0,
                    'Shadow_Blur': 0,
                    'Shadow_Spread': 0,
                    'Shadow_Color': 'transparent',
                    'Hover_Background': False,
                    'Hover_Foreground': False,
                    'Hover_Border_Color': False,
                }
                self._Initialized = False
                self._Main = Main
                self._Widget = None
                self._Frame = None
                self._Textarea = None
                self._Name = False
                self._Background = '#ffffff'
                self._Foreground = '#000000'
                self._Border_Color = '#000000'
                self._Border_Size = 0
                self._Border_Radius = 0
                self._Display = True
                self._Left = None
                self._Top = None
                self._Right = None
                self._Bottom = None
                self._Width = None
                self._Height = 160
                self._Font_Size = 12
                self._Font_Weight = 'normal'
                self._Font_Family = 'Helvetica'
                self._Disable = False
                self._Placeholder = ''
                self._Value = ''
                self._Padding = '8px 10px'
                self._Margin = 0
                self._Mode = 'Flow'
                self._Classes = ''
                self._Style = ''
                self._Z_Index = None
                self._Shadow_X = 0
                self._Shadow_Y = 0
                self._Shadow_Blur = 0
                self._Shadow_Spread = 0
                self._Shadow_Color = 'transparent'
                self._Hover_Background = False
                self._Hover_Foreground = False
                self._Hover_Border_Color = False
                self._On_Show = False
                self._On_Hide = False
                self._On_Change = False
                if kwargs:
                    self.Config(**kwargs)
            except Exception as E:
                self._GUI.Error(f'{self._Type} -> Init -> {E}')
        else:
            print('Error: Wavionix -> GUI Instance Has Not Been Created')

    def __str__(self):
        return 'Nucleon_Wavionix_Text[]'

    def __repr__(self):
        return 'Nucleon_Wavionix_Text[]'

    def _Unit(self, Value):
        if Value is None or Value is False or Value == '':
            return None
        if isinstance(Value, (int, float)):
            return f'{Value}px'
        return str(Value)

    def _Get_Parent(self):
        if hasattr(self._Main, 'Widget') and callable(self._Main.Widget):
            return self._Main.Widget()
        if hasattr(self._Main, '_Frame') and self._Main._Frame is not None:
            return self._Main._Frame
        if hasattr(self._Main, '_Widget') and not isinstance(self._Main._Widget, list):
            return self._Main._Widget
        return self._Main

    def _Build_Shadow(self):
        X = self._Unit(self._Shadow_X) or '0px'
        Y = self._Unit(self._Shadow_Y) or '0px'
        Blur = self._Unit(self._Shadow_Blur) or '0px'
        Spread = self._Unit(self._Shadow_Spread) or '0px'
        Color = self._Shadow_Color or 'transparent'
        return f'{X} {Y} {Blur} {Spread} {Color}'

    def _Build_Frame_Style(self):
        Style = []
        Style.append('box-sizing: border-box')
        Style.append(f'display: {"flex" if self._Display else "none"}')
        Style.append(f'background: {self._Background}')
        Style.append(f'color: {self._Foreground}')
        Style.append(f'border: {self._Unit(self._Border_Size) or "0px"} solid {self._Border_Color}')
        Style.append(f'border-radius: {self._Unit(self._Border_Radius) or "0px"}')
        Style.append(f'box-shadow: {self._Build_Shadow()}')
        Style.append(f'padding: {self._Unit(self._Padding) or "8px 10px"}')
        Style.append(f'margin: {self._Unit(self._Margin) or "0px"}')
        Style.append('overflow: hidden')
        Style.append('transition: all 0.2s ease')

        if self._Mode == 'Place':
            Style.append('position: absolute')
            if self._Left is not None:
                Style.append(f'left: {self._Unit(self._Left)}')
            if self._Top is not None:
                Style.append(f'top: {self._Unit(self._Top)}')
            if self._Right is not None:
                Style.append(f'right: {self._Unit(self._Right)}')
            if self._Bottom is not None:
                Style.append(f'bottom: {self._Unit(self._Bottom)}')

        if self._Width is not None:
            Style.append(f'width: {self._Unit(self._Width)}')
        if self._Height is not None:
            Style.append(f'height: {self._Unit(self._Height)}')
            Style.append(f'min-height: {self._Unit(self._Height)}')

        if self._Z_Index is not None:
            Style.append(f'z-index: {self._Z_Index}')

        if self._Disable:
            Style.append('opacity: 0.55')

        if self._Style:
            Style.append(self._Style)

        return '; '.join(Style)

    def _Build_Textarea_Props(self):
        Props = []
        Props.append('borderless')
        if self._Disable:
            Props.append('disable')
        if self._Placeholder:
            Props.append(f'placeholder="{self._Placeholder}"')
        Props.append(
            f'input-style="'
            f'color:{self._Foreground};'
            f'font-size:{self._Unit(self._Font_Size) or "12px"};'
            f'font-weight:{self._Font_Weight};'
            f'font-family:{self._Font_Family};'
            f'line-height:1.4;'
            f'height:144px;'
            f'overflow-y:auto;'
            f'resize:none;'
            f'"'
        )
        return ' '.join(Props)

    def _Build_Textarea_Style(self):
        Style = []
        Style.append('width: 100%')
        Style.append('background: transparent')
        Style.append(f'color: {self._Foreground}')
        return '; '.join(Style)

    def _Handle_Change(self, Event):
        try:
            self._Value = Event.value
            if self._On_Change:
                self._On_Change(Event)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Handle_Change -> {E}')

    def _Hover_In(self):
        try:
            if self._Disable or self._Frame is None:
                return
            Background = self._Hover_Background if self._Hover_Background else self._Background
            Foreground = self._Hover_Foreground if self._Hover_Foreground else self._Foreground
            Border = self._Hover_Border_Color if self._Hover_Border_Color else self._Border_Color
            self._Frame.style(self._Build_Frame_Style() + f'; background: {Background}; color: {Foreground}; border-color: {Border}')
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Hover_In -> {E}')

    def _Hover_Out(self):
        try:
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Hover_Out -> {E}')

    def Place(self, Left=None, Top=None, Right=None, Bottom=None, Width=None, Height=None):
        try:
            self._Mode = 'Place'
            if Left is not None:
                self._Left = Left
            if Top is not None:
                self._Top = Top
            if Right is not None:
                self._Right = Right
            if Bottom is not None:
                self._Bottom = Bottom
            if Width is not None:
                self._Width = Width
            if Height is not None:
                self._Height = Height
            self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Place -> {E}')

    def Pack(self, Classes=None, Style=None, Margin=None, Padding=None):
        try:
            self._Mode = 'Flow'
            self._Left = None
            self._Top = None
            self._Right = None
            self._Bottom = None

            if Classes is not None:
                self._Classes = Classes
            if Style is not None:
                self._Style = Style
            if Margin is not None:
                self._Margin = Margin
            if Padding is not None:
                self._Padding = Padding

            self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Pack -> {E}')

    def _Apply(self):
        try:
            if self._Frame is None or self._Textarea is None:
                return

            if hasattr(self._Frame, '_style'):
                self._Frame._style.clear()
            if hasattr(self._Frame, '_classes'):
                self._Frame._classes.clear()

            self._Frame.style(self._Build_Frame_Style())

            Classes = []
            if self._Classes:
                Classes.append(self._Classes)

            if len(Classes) > 0:
                self._Frame.classes(' '.join(Classes))

            self._Textarea.value = self._Value
            self._Textarea.style(self._Build_Textarea_Style())
            self._Textarea.props(self._Build_Textarea_Props())
            self._Textarea.update()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Apply -> {E}')

    def Copy(self, Name=False, Main=False):
        try:
            if not Main:
                Main = self._Main
            Instance = type(self)(Main)
            for Key in self._Config:
                if hasattr(self, '_' + Key):
                    setattr(Instance, '_' + Key, getattr(self, '_' + Key))
            if Name:
                Instance._Name = Name
            Instance._Value = self._Value
            Instance.Create()
            return Instance
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Copy -> {E}')

    def Delete(self):
        try:
            if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self in self._Main._Widget:
                self._Main._Widget.remove(self)
            if self._Widget is not None:
                self._Widget.delete()
                self._Widget = None
                self._Frame = None
                self._Textarea = None
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Delete -> {E}')

    def Hide(self):
        try:
            self._Display = False
            self._Apply()
            if self._On_Hide:
                self._On_Hide()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Hide -> {E}')

    def Show(self):
        try:
            self._Display = True
            self._Apply()
            if self._On_Show:
                self._On_Show()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Show -> {E}')

    def Get(self):
        try:
            if self._Textarea is not None:
                self._Value = self._Textarea.value
            return self._Value
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Get -> {E}')

    def Set(self, Value):
        try:
            self._Value = '' if Value is None else str(Value)
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Set -> {E}')

    def Add(self, Value):
        try:
            Value = '' if Value is None else str(Value)
            self._Value = f'{self._Value}{Value}'
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Add -> {E}')

    def Clear(self):
        try:
            self._Value = ''
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Clear -> {E}')

    def Widget(self):
        try:
            return self._Textarea
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Widget -> {E}')

    def Bind(self, **Input):
        try:
            if 'On_Show' in Input:
                self._On_Show = Input['On_Show']
                del Input['On_Show']
            if 'On_Hide' in Input:
                self._On_Hide = Input['On_Hide']
                del Input['On_Hide']
            if 'On_Change' in Input:
                self._On_Change = Input['On_Change']
                del Input['On_Change']
            if self._Textarea is not None and len(Input) > 0:
                Event_Bind(self._Textarea, **Input)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Bind -> {E}')

    def Config_Get(self, *Input):
        try:
            Return = {}
            for Each in self._Config:
                if Each in Input:
                    Return[Each] = getattr(self, '_' + Each)
            return Return
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config_Get -> {E}')

    def Config(self, **Input):
        try:
            Run = False
            for Each in self._Config:
                if Each in Input:
                    setattr(self, '_' + Each, Input[Each])
                    Run = True
            if 'Value' in Input:
                self._Value = '' if Input['Value'] is None else str(Input['Value'])
            if self._Initialized and Run:
                self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config -> {E}')

    def Move(self, Left=None, Top=None):
        try:
            if Left is not None:
                self._Left = (self._Left or 0) + Left
            if Top is not None:
                self._Top = (self._Top or 0) + Top
            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Move -> {E}')

    def Center(self, Left=None, Top=None):
        try:
            Width = self._Width or 0
            Height = self._Height or 0
            if Left is not None:
                self._Left = Left - Width / 2
            if Top is not None:
                self._Top = Top - Height / 2
            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()
            return [self._Left + Width / 2, self._Top + Height / 2]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Center -> {E}')

    def Position(self, Left=None, Top=None, Right=None, Bottom=None):
        try:
            if Left is not None:
                self._Left = Left
            if Top is not None:
                self._Top = Top
            if Right is not None:
                self._Right = Right
            if Bottom is not None:
                self._Bottom = Bottom
            if Left is not None or Top is not None or Right is not None or Bottom is not None:
                self._Mode = 'Place'
                self._Apply()
            return [self._Left, self._Top, self._Right, self._Bottom]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Position -> {E}')

    def Size(self, Width=False, Height=False):
        try:
            if Width is not False:
                self._Width = Width
            if Height is not False:
                self._Height = Height
            if Width is not False or Height is not False:
                self._Apply()
            return [self._Width, self._Height]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Size -> {E}')

    def Enlarge(self, Value=None):
        try:
            if Value is not None:
                self._Width = (self._Width or 0) + Value
                self._Height = (self._Height or 0) + Value
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Enlarge -> {E}')

    def Shrink(self, Value=None):
        try:
            if Value is not None:
                self._Width = max(0, (self._Width or 0) - Value)
                self._Height = max(0, (self._Height or 0) - Value)
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Shrink -> {E}')

    def Box(self):
        try:
            return [self._Left, self._Top, self._Width, self._Height]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Box -> {E}')

    def Ratio(self):
        try:
            return [1, 1]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Ratio -> {E}')

    def Locate(self, Width, Height, Left, Top):
        try:
            Width = self._Width * (Width / 100)
            Height = self._Height * (Height / 100)
            Left = self._Width * (Left / 100)
            Top = self._Height * (Top / 100)
            return [Width, Height, Left, Top]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Locate -> {E}')

    def Locate_Reverse(self, Width, Height, Left, Top):
        try:
            Width = round((Width / self._Width) * 100, 3)
            Height = round((Height / self._Height) * 100, 3)
            Left = round((Left / self._Width) * 100, 3)
            Top = round((Top / self._Height) * 100, 3)
            return [Width, Height, Left, Top]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Locate_Reverse -> {E}')

    def Create(self):
        try:
            if self._Widget is None:
                Parent = self._Get_Parent()
                
                if self._Mode != 'Place':
                    if self._Left is not None or self._Top is not None or self._Right is not None or self._Bottom is not None:
                        self._Mode = 'Place'


                if Parent is not None:
                    with Parent:
                        self._Widget = ui.element('div')
                        self._Widget.style('display: contents')
                        self._Frame = ui.element('div')
                        with self._Frame:
                            self._Textarea = ui.textarea(
                                value=self._Value,
                                on_change=lambda E: self._Handle_Change(E),
                            )
                else:
                    self._Widget = ui.element('div')
                    self._Widget.style('display: contents')
                    self._Frame = ui.element('div')
                    with self._Frame:
                        self._Textarea = ui.textarea(
                            value=self._Value,
                            on_change=lambda E: self._Handle_Change(E),
                        )

                self._Frame.on('mouseenter', lambda E: self._Hover_In())
                self._Frame.on('mouseleave', lambda E: self._Hover_Out())

                if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self not in self._Main._Widget:
                    self._Main._Widget.append(self)

                self._Initialized = True

            self._Apply()

            if self._Name:
                self._Main.__dict__[self._Name] = self

            if not self._Display:
                self.Hide()

            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Create -> {E}')