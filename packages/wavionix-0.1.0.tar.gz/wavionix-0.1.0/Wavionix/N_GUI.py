import os
import time
import datetime
import base64
import mimetypes
from nicegui import ui
from .N_Custom import Event_Bind


class GUI():

    _Instance = None

    def __new__(Class, *Args, **KArgs):
        if Class._Instance is None:
            Class._Instance = super().__new__(Class)
        return Class._Instance

    def __init__(self, *Args, **KArgs):
        if hasattr(self, '_Initialized'):
            if KArgs:
                self.Config(**KArgs)
            return
        self._Config = {
            'Error_Display': True,
            'Error_Log': False,
            'Title': 'Nucleon Wavionix',
            'Icon': '',
            'IP': '0.0.0.0',
            'Port': 8080,
            'Reload': False,
            'Show': True,
            'Background': '#F0F0F0',
            'Foreground': '#111111',
            'Width': '100%',
            'Height': '100%',
            'Min_Height': '100vh',
            'Max_Width': 'none',
            'Padding': '0',
            'Gap': '0',
            'Classes': '',
            'Style': '',
            'Body_Classes': 'w-full h-full',
            'Body_Style': '',
            'Visible': True,
            'Full_Screen': False,
            'Scroll': True,
            'Scroll_X': None,
            'Scroll_Y': None,
        }
        self._Initialized = True
        self._Type = 'GUI'
        self._Error_Display = self._Config['Error_Display']
        self._Error_Log = self._Config['Error_Log']
        self._Log_Folder = './Log'
        self._Log_File = 'Wavionix_Error.log'
        self._Error = []
        self._Title = self._Config['Title']
        self._Icon = self._Config['Icon']
        self._Icon_Source = ''
        self._IP = self._Config['IP']
        self._Port = self._Config['Port']
        self._Reload = self._Config['Reload']
        self._Show = self._Config['Show']
        self._Background = self._Config['Background']
        self._Foreground = self._Config['Foreground']
        self._Width = self._Config['Width']
        self._Height = self._Config['Height']
        self._Min_Height = self._Config['Min_Height']
        self._Max_Width = self._Config['Max_Width']
        self._Padding = self._Config['Padding']
        self._Gap = self._Config['Gap']
        self._Classes = self._Config['Classes']
        self._Style = self._Config['Style']
        self._Body_Classes = self._Config['Body_Classes']
        self._Body_Style = self._Config['Body_Style']
        self._Visible = self._Config['Visible']
        self._Full_Screen = self._Config['Full_Screen']
        self._Scroll = self._Config['Scroll']
        self._Scroll_X = self._Config['Scroll_X']
        self._Scroll_Y = self._Config['Scroll_Y']
        self._Widget = []
        self._Popup = []
        self._Body = None
        self._Binding = {}
        self._Page_Function = None
        self._Page_Args = []
        self._Page_KArgs = {}
        self._Page_Route = '/'
        self._Page_Registered = False
        self._Start_Function = None
        self._Start_Args = []
        self._Start_KArgs = {}
        self._Created = False
        
        if KArgs:
            self.Config(**KArgs)

    def __str__(self):
        return 'GUI[' + str(self._Title) + ']'

    def __repr__(self):
        return 'GUI[' + str(self._Title) + ']'

    def Error(self, E):
        Error_Time = int(time.time())
        self._Error.append([E, Error_Time])

        if len(self._Error) > 1000:
            self._Error.pop(0)

        if self._Error_Display:
            print(E)

        if self._Error_Log:
            if not os.path.exists(self._Log_Folder):
                os.makedirs(self._Log_Folder)

            Log_Path = os.path.join(self._Log_Folder, self._Log_File)
            Date_Str = datetime.datetime.fromtimestamp(Error_Time).strftime('%Y-%m-%d %H:%M:%S')
            Line = f'{Date_Str} - {E}\n'

            try:
                with open(Log_Path, 'a', encoding='utf-8') as File:
                    File.write(Line)
            except Exception as Error_Value:
                print(f'Wavionix -> Critical Logging Error: {Error_Value}')

    def Nothing(self):
        return False
        
    def Page(self, Function=None, *Args, **KArgs):
        try:
            Route = KArgs.pop('Route', '/')
            self._Page_Function = Function
            self._Page_Args = Args
            self._Page_KArgs = KArgs
            self._Page_Route = Route
            self._Page_Registered = False
            return self
        except Exception as E:
            self.Error(f'{self._Type} -> Page -> {E}')

    def _Build_Page(self):
        try:
            self._Body = None
            self._Created = False
            self._Widget = []
            self._Popup = []
            self._Icon_Source = ''
            if self._Page_Function is not None:
                return self._Page_Function(*self._Page_Args, **self._Page_KArgs)
        except Exception as E:
            self.Error(f'{self._Type} -> _Build_Page -> {E}')
            
    def _Root_Style(self):
        try:
            Style = []
            Style.append('position: relative')
            Style.append(f'width: {self._Width}')
            Style.append(f'height: {self._Height}')
            Style.append(f'min-height: {self._Min_Height}')
            Style.append(f'max-width: {self._Max_Width}')
            Style.append(f'padding: {self._Padding}')
            Style.append(f'gap: {self._Gap}')
            Style.append(f'background: {self._Background}')
            Style.append(f'color: {self._Foreground}')
            Style.append('box-sizing: border-box')
            Style.append('display: flex' if self._Visible else 'display: none')
            Style.append('flex-direction: column')
            Style.append('align-items: stretch')
            Overflow = self._Scroll_Mode(self._Scroll, 'auto')
            Style.append(f'overflow: {Overflow}')
            if self._Scroll_X is not None:
                Style.append(f'overflow-x: {self._Scroll_Mode(self._Scroll_X, Overflow)}')
            if self._Scroll_Y is not None:
                Style.append(f'overflow-y: {self._Scroll_Mode(self._Scroll_Y, Overflow)}')
            if self._Style:
                Style.append(self._Style)
            return '; '.join(Style)
        except Exception as E:
            self.Error(f'{self._Type} -> _Root_Style -> {E}')

    def _Scroll_Mode(self, Value, Default='auto'):
        try:
            if Value is None:
                return Default
            if Value is True:
                return 'auto'
            if Value is False:
                return 'hidden'
            return str(Value)
        except Exception as E:
            self.Error(f'{self._Type} -> _Scroll_Mode -> {E}')
            return Default

    def _Page_Scroll_CSS(self):
        try:
            Overflow = self._Scroll_Mode(self._Scroll, 'auto')
            Overflow_X = None if self._Scroll_X is None else self._Scroll_Mode(self._Scroll_X, Overflow)
            Overflow_Y = None if self._Scroll_Y is None else self._Scroll_Mode(self._Scroll_Y, Overflow)
            Style = []
            Style.append('html, body {')
            Style.append('margin: 0 !important;')
            Style.append('padding: 0 !important;')
            Style.append('width: 100% !important;')
            Style.append('height: 100% !important;')
            Style.append(f'overflow: {Overflow} !important;')
            if Overflow_X is not None:
                Style.append(f'overflow-x: {Overflow_X} !important;')
            if Overflow_Y is not None:
                Style.append(f'overflow-y: {Overflow_Y} !important;')
            Style.append('}')
            Style.append('#app, .nicegui-content, .nicegui-layout, .q-page-container, .q-page {')
            Style.append('margin: 0 !important;')
            Style.append('padding: 0 !important;')
            Style.append('width: 100% !important;')
            Style.append('max-width: none !important;')
            Style.append('height: 100% !important;')
            Style.append('min-height: 100% !important;')
            Style.append(f'overflow: {Overflow} !important;')
            if Overflow_X is not None:
                Style.append(f'overflow-x: {Overflow_X} !important;')
            if Overflow_Y is not None:
                Style.append(f'overflow-y: {Overflow_Y} !important;')
            Style.append('}')
            Style.append('.q-pa-md, .q-px-md, .q-py-md, .q-ma-md, .q-mx-md, .q-my-md {')
            Style.append('padding: 0 !important;')
            Style.append('margin: 0 !important;')
            Style.append('}')
            return '\n'.join(Style)
        except Exception as E:
            self.Error(f'{self._Type} -> _Page_Scroll_CSS -> {E}')
            return ''

    def _Apply_Page_Scroll(self):
        try:
            Css = self._Page_Scroll_CSS()
            if not Css:
                return
            Safe_Css = Css.replace('`', '')
            ui.add_head_html(f'''<script>
                (() => {{
                let Style_Tag = document.getElementById('wavionix-page-scroll-style');
                if (!Style_Tag) {{
                Style_Tag = document.createElement('style');
                Style_Tag.id = 'wavionix-page-scroll-style';
                document.head.appendChild(Style_Tag);
                }}
                Style_Tag.textContent = `{Safe_Css}`;
                }})();
                </script>''', shared=True)
        except Exception as E:
            self.Error(f'{self._Type} -> _Apply_Page_Scroll -> {E}')

    def _Resolve_Icon(self, Value=None):
        try:
            if Value is None:
                Value = self._Icon
            if Value is False or Value is None or Value == '':
                return ['', '']
            if isinstance(Value, os.PathLike):
                Value = os.fspath(Value)
            if isinstance(Value, bytes):
                Mime = 'image/png'
                Encoded = base64.b64encode(Value).decode('utf-8')
                return [f'data:{Mime};base64,{Encoded}', Mime]
            if isinstance(Value, str):
                if Value.startswith('data:'):
                    Mime = Value.split(';', 1)[0].replace('data:', '')
                    return [Value, Mime]
                if Value.startswith('http://') or Value.startswith('https://'):
                    Mime = mimetypes.guess_type(Value.split('?', 1)[0])[0] or 'image/x-icon'
                    return [Value, Mime]
                if os.path.exists(Value):
                    Mime = mimetypes.guess_type(Value)[0] or 'image/x-icon'
                    with open(Value, 'rb') as File:
                        Data = File.read()
                    Encoded = base64.b64encode(Data).decode('utf-8')
                    return [f'data:{Mime};base64,{Encoded}', Mime]
                Mime = mimetypes.guess_type(Value)[0] or 'image/x-icon'
                return [Value, Mime]
            return ['', '']
        except Exception as E:
            self.Error(f'{self._Type} -> _Resolve_Icon -> {E}')
            return ['', '']

    def _Apply_Icon(self):
        try:
            Icon_Source, Icon_Mime = self._Resolve_Icon(self._Icon)
            if not Icon_Source:
                return
            if self._Icon_Source == Icon_Source:
                return
            self._Icon_Source = Icon_Source
            Safe_Source = Icon_Source.replace('`', '').replace('\\', '\\\\')
            Safe_Mime = Icon_Mime.replace('`', '')
            ui.add_head_html(f'''<script>
                (() => {{
                let Icon_Link = document.getElementById('wavionix-icon-link');
                if (!Icon_Link) {{
                Icon_Link = document.createElement('link');
                Icon_Link.id = 'wavionix-icon-link';
                Icon_Link.rel = 'icon';
                document.head.appendChild(Icon_Link);
                }}
                Icon_Link.href = `{Safe_Source}`;
                Icon_Link.type = `{Safe_Mime}`;
                }})();
                </script>''', shared=True)
        except Exception as E:
            self.Error(f'{self._Type} -> _Apply_Icon -> {E}')

    def Icon(self, Value=None):
        try:
            if Value is not None:
                self._Icon = Value
                self._Icon_Source = ''
                if self._Created:
                    self._Apply_Icon()
            return self._Icon
        except Exception as E:
            self.Error(f'{self._Type} -> Icon -> {E}')
            return self._Icon

    def _Refresh(self):
        try:
            self._Apply_Page_Scroll()
            self._Apply_Icon()
            if self._Body is not None:
                Body_Classes = 'w-full'
                if self._Classes:
                    Body_Classes += ' ' + self._Classes
                if self._Body_Classes:
                    Body_Classes += ' ' + self._Body_Classes
                self._Body.classes(replace=Body_Classes)
                Body_Style = self._Root_Style()
                if self._Body_Style:
                    Body_Style += '; ' + self._Body_Style
                self._Body.style(replace=Body_Style)
            ui.page_title(self._Title)
        except Exception as E:
            self.Error(f'{self._Type} -> _Refresh -> {E}')

    def Create(self):
        try:
            self._Apply_Page_Scroll()
            self._Apply_Icon()
            Body_Classes = 'w-full'
            if self._Classes:
                Body_Classes += ' ' + self._Classes
            if self._Body_Classes:
                Body_Classes += ' ' + self._Body_Classes
            Body_Style = self._Root_Style()
            if self._Body_Style:
                Body_Style += '; ' + self._Body_Style
            self._Body = None
            with ui.element('div').classes(Body_Classes).style(Body_Style) as self._Body:
                pass
            if self._Binding:
                Event_Bind(self._Body, **self._Binding)
            ui.page_title(self._Title)
            self._Created = True
            return self
        except Exception as E:
            self.Error(f'{self._Type} -> Create -> {E}')

    def After(self, Delay, Function):
        try:
            return ui.timer(float(Delay) / 1000.0, Function, once=True)
        except Exception as E:
            self.Error(f'{self._Type} -> After -> {E}')

    def Widget(self):
        try:
            return self._Body
        except Exception as E:
            self.Error(f'{self._Type} -> Widget -> {E}')

    def Body(self):
        try:
            return self._Body
        except Exception as E:
            self.Error(f'{self._Type} -> Body -> {E}')

    def Bind(self, **Input):
        try:
            for Key, Value in Input.items():
                self._Binding[Key] = Value
            if self._Body is not None:
                Event_Bind(self._Body, **Input)
            return self
        except Exception as E:
            self.Error(f'{self._Type} -> Bind -> {E}')

    def Title(self, Value=None):
        try:
            if Value is not None:
                self._Title = Value
                if self._Created:
                    ui.page_title(self._Title)
            return self._Title
        except Exception as E:
            self.Error(f'{self._Type} -> Title -> {E}')
            return self._Title

    def IP(self, Value=None):
        try:
            if Value is not None:
                self._IP = str(Value)
            return self._IP
        except Exception as E:
            self.Error(f'{self._Type} -> IP -> {E}')
            return self._IP

    def Port(self, Value=None):
        try:
            if Value is not None:
                self._Port = int(Value)
            return self._Port
        except Exception as E:
            self.Error(f'{self._Type} -> Port -> {E}')
            return self._Port

    def Address(self, IP=None, Port=None):
        try:
            if IP is not None:
                self._IP = str(IP)
            if Port is not None:
                self._Port = int(Port)
            return {'IP': self._IP, 'Port': self._Port}
        except Exception as E:
            self.Error(f'{self._Type} -> Address -> {E}')
            return {'IP': self._IP, 'Port': self._Port}

    def Scroll(self, Value=None, X=None, Y=None):
        try:
            if Value is not None:
                self._Scroll = Value
            if X is not None:
                self._Scroll_X = X
            if Y is not None:
                self._Scroll_Y = Y

            self._Apply_Page_Scroll()

            if self._Created:
                self._Refresh()

            return {
                'Scroll': self._Scroll,
                'Scroll_X': self._Scroll_X,
                'Scroll_Y': self._Scroll_Y,
            }
        except Exception as E:
            self.Error(f'{self._Type} -> Scroll -> {E}')
            return {
                'Scroll': self._Scroll,
                'Scroll_X': self._Scroll_X,
                'Scroll_Y': self._Scroll_Y,
            }

    async def Page_Scroll(self, Value=True, X=None, Y=None):
        try:
            self._Scroll = Value if Value is not None else self._Scroll
            if X is not None:
                self._Scroll_X = X
            if Y is not None:
                self._Scroll_Y = Y
            Css = self._Page_Scroll_CSS()
            Safe_Css = Css.replace('`', '')
            await ui.run_javascript(f'''
                let Style_Tag = document.getElementById('wavionix-page-scroll-style');
                if (!Style_Tag) {{
                    Style_Tag = document.createElement('style');
                    Style_Tag.id = 'wavionix-page-scroll-style';
                    document.head.appendChild(Style_Tag);
                }}
                Style_Tag.textContent = `{Safe_Css}`;
            ''')
            if self._Created:
                self._Refresh()
            return {'Scroll': self._Scroll, 'Scroll_X': self._Scroll_X, 'Scroll_Y': self._Scroll_Y}
        except Exception as E:
            self.Error(f'{self._Type} -> Page_Scroll -> {E}')
            return {'Scroll': self._Scroll, 'Scroll_X': self._Scroll_X, 'Scroll_Y': self._Scroll_Y}

    async def Full_Screen(self, Toggle=None):
        try:
            if Toggle is None:
                Toggle = not self._Full_Screen

            self._Full_Screen = bool(Toggle)

            if self._Full_Screen:
                await ui.run_javascript('if (!document.fullscreenElement) { await document.documentElement.requestFullscreen(); }')
            else:
                await ui.run_javascript('if (document.fullscreenElement) { await document.exitFullscreen(); }')

            return self._Full_Screen
        except Exception as E:
            self.Error(f'{self._Type} -> Full_Screen -> {E}')
            return self._Full_Screen

    async def Full_Screen_Toggle(self):
        try:
            return await self.Full_Screen()
        except Exception as E:
            self.Error(f'{self._Type} -> Full_Screen_Toggle -> {E}')
            return self._Full_Screen

    def Show(self):
        try:
            self._Visible = True
            self._Refresh()
            return self
        except Exception as E:
            self.Error(f'{self._Type} -> Show -> {E}')

    def Hide(self):
        try:
            self._Visible = False
            self._Refresh()
            return self
        except Exception as E:
            self.Error(f'{self._Type} -> Hide -> {E}')

    def Config_Get(self, *Input):
        try:
            if not Input:
                Return = {}
                for Each in self._Config:
                    Return[Each] = getattr(self, '_' + Each)
                return Return

            Return = {}
            for Each in self._Config:
                if Each in Input:
                    Return[Each] = getattr(self, '_' + Each)
            return Return
        except Exception as E:
            self.Error(f'{self._Type} -> Config_Get -> {E}')
            return {}

    def Config(self, **Input):
        try:
            for Each in self._Config:
                if Each in Input:
                    setattr(self, '_' + Each, Input[Each])
            if 'Icon' in Input:
                self._Icon_Source = ''
            if self._Created:
                self._Refresh()
            return self
        except Exception as E:
            self.Error(f'{self._Type} -> Config -> {E}')

    def Start_Config(self, Function=None, *Args, **KArgs):
        try:
            self._Start_Function = Function
            self._Start_Args = Args
            self._Start_KArgs = KArgs
            return self
        except Exception as E:
            self.Error(f'{self._Type} -> Start_Config -> {E}')

    def Start(self):
        try:
            if self._Start_Function is not None:
                self._Start_Function(*self._Start_Args, **self._Start_KArgs)
            if self._Page_Function is not None and not self._Page_Registered:
                ui.page(self._Page_Route)(self._Build_Page)
                self._Page_Registered = True
            Run_Input = {
                'host': self._IP,
                'port': self._Port,
                'title': self._Title,
                'reload': self._Reload,
                'show': self._Show,
            }
            Icon_Source, _ = self._Resolve_Icon(self._Icon)
            if Icon_Source:
                Run_Input['favicon'] = Icon_Source
            ui.run(**Run_Input)
        except Exception as E:
            self.Error(f'{self._Type} -> Start -> {E}')