from nicegui import ui
from .N_GUI import GUI


class Menu:

    def __init__(self, Main, *Args, **Kwargs):
        self._GUI = GUI._Instance
        if self._GUI is not None:
            self._Type = 'Menu'
            try:
                self._Main = Main
                self._Config = {
                    'Layout': {},
                    'Disable': False,
                    'Font_Size': 12,
                    'Font_Weight': 'normal',
                    'Font_Family': 'Helvetica',
                    'Foreground': '#000000',
                    'Background': '#ffffff',
                    'Active_Foreground': '#000000',
                    'Active_Background': '#d9d9d9',
                    'Border_Color': '#000000',
                    'Border_Size': 0,
                    'Border_Radius': 0,
                    'Shadow_X': 0,
                    'Shadow_Y': 0,
                    'Shadow_Blur': 0,
                    'Shadow_Spread': 0,
                    'Shadow_Color': 'transparent',
                }
                self._Layout = {}
                self._Disable = False
                self._Font_Size = 12
                self._Font_Weight = 'normal'
                self._Font_Family = 'Helvetica'
                self._Foreground = '#000000'
                self._Background = '#ffffff'
                self._Active_Foreground = '#000000'
                self._Active_Background = '#d9d9d9'
                self._Border_Color = '#000000'
                self._Border_Size = 0
                self._Border_Radius = 0
                self._Shadow_X = 0
                self._Shadow_Y = 0
                self._Shadow_Blur = 0
                self._Shadow_Spread = 0
                self._Shadow_Color = 'transparent'
                self._Widget = None
                self._Menu = None
                self._Last_Target = None
                self._Initialized = False
                if Kwargs:
                    self.Config(**Kwargs)
                self.Create()
            except Exception as E:
                self._GUI.Error(f'{self._Type} -> Init -> {E}')
        else:
            print('Error: Wavionix -> GUI Instance Has Not Been Created')

    def __str__(self):
        return 'Nucleon_Wavionix_Menu[]'

    def __repr__(self):
        return 'Nucleon_Wavionix_Menu[]'

    def _Unit(self, Value):
        if Value is None or Value is False or Value == '':
            return None
        if isinstance(Value, (int, float)):
            return f'{Value}px'
        return str(Value)

    def _Resolve_Master(self):
        try:
            if hasattr(self._Main, 'Widget') and callable(self._Main.Widget):
                return self._Main.Widget()
            if hasattr(self._Main, '_Frame'):
                return self._Main._Frame
            if hasattr(self._Main, '_Widget') and not isinstance(self._Main._Widget, list):
                return self._Main._Widget
            return self._Main
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Resolve_Master -> {E}')

    def _Resolve_Target(self, Widget=False):
        try:
            if Widget is not False and Widget is not None:
                if hasattr(Widget, 'Widget') and callable(Widget.Widget):
                    return Widget.Widget()
                if hasattr(Widget, '_Widget') and not isinstance(Widget._Widget, list):
                    return Widget._Widget
                return Widget
            return self._Resolve_Master()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Resolve_Target -> {E}')

    def _Empty_Command(self):
        try:
            return None
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Empty_Command -> {E}')

    def _Wrap_Command(self, Value):
        try:
            if callable(Value):
                return lambda Value=Value: Value()
            return lambda Value=Value: Value
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Wrap_Command -> {E}')

    def _Build_Shadow(self):
        X = self._Unit(self._Shadow_X) or '0px'
        Y = self._Unit(self._Shadow_Y) or '0px'
        Blur = self._Unit(self._Shadow_Blur) or '0px'
        Spread = self._Unit(self._Shadow_Spread) or '0px'
        Color = self._Shadow_Color or 'transparent'
        return f'{X} {Y} {Blur} {Spread} {Color}'

    def _Item_Text_Style(self):
        return (
            f'color: {self._Foreground}; '
            f'font-size: {self._Unit(self._Font_Size) or "12px"}; '
            f'font-weight: {self._Font_Weight}; '
            f'font-family: {self._Font_Family};'
        )

    def _Menu_Style(self):
        Style = []
        Style.append(f'background: {self._Background}')
        Style.append(f'color: {self._Foreground}')
        Style.append(f'border: {self._Unit(self._Border_Size) or "0px"} solid {self._Border_Color}')
        Style.append(f'border-radius: {self._Unit(self._Border_Radius) or "0px"}')
        Style.append(f'box-shadow: {self._Build_Shadow()}')
        Style.append(f'font-size: {self._Unit(self._Font_Size) or "12px"}')
        Style.append(f'font-weight: {self._Font_Weight}')
        Style.append(f'font-family: {self._Font_Family}')
        return '; '.join(Style)

    def _Build_Menu_Level(self, Layout):
        Level_State = {
            'Open_Sub_Menu': None,
        }

        def _Close_Open_Sub_Menu():
            if Level_State['Open_Sub_Menu'] is not None:
                try:
                    Level_State['Open_Sub_Menu'].close()
                except Exception:
                    pass
                Level_State['Open_Sub_Menu'] = None

        def _Open_Sub_Menu(Sub_Menu):
            if Level_State['Open_Sub_Menu'] is not None and Level_State['Open_Sub_Menu'] != Sub_Menu:
                try:
                    Level_State['Open_Sub_Menu'].close()
                except Exception:
                    pass
            Level_State['Open_Sub_Menu'] = Sub_Menu
            Sub_Menu.open()

        for Key, Value in Layout.items():
            if isinstance(Key, str) and len(Key) > 1 and Key[0] == 'S' and Key[1:].isdigit():
                ui.separator()
            elif isinstance(Value, dict):
                if len(Value) == 0:
                    Item = ui.menu_item(on_click=self._Empty_Command).props('v-close-popup')
                    with Item:
                        ui.label(str(Key)).style(self._Item_Text_Style())
                    Item.on('mouseenter', lambda: _Close_Open_Sub_Menu())
                else:
                    with ui.menu_item(auto_close=False).props('clickable=false') as Parent_Item:
                        with ui.row().classes('w-full items-center no-wrap'):
                            ui.label(str(Key)).style(self._Item_Text_Style())
                            ui.space()
                            ui.icon('keyboard_arrow_right').style(f'color: {self._Foreground}')
                        with ui.menu().props('anchor="top end" self="top start" :offset="[0,0]" auto-close') as Sub_Menu:
                            self._Build_Menu_Level(Value)
                    Parent_Item.on('mouseenter', lambda Sub_Menu=Sub_Menu: _Open_Sub_Menu(Sub_Menu))
            else:
                if Value in ['', None, False]:
                    Item = ui.menu_item(on_click=self._Empty_Command)
                elif callable(Value):
                    Item = ui.menu_item(on_click=Value)
                else:
                    Item = ui.menu_item(on_click=self._Wrap_Command(Value))
                Item.props('v-close-popup')
                with Item:
                    ui.label(str(Key)).style(self._Item_Text_Style())
                Item.on('mouseenter', lambda: _Close_Open_Sub_Menu())

    def _Destroy_Menu(self):
        try:
            if self._Widget is not None:
                self._Widget.delete()
            self._Widget = None
            self._Menu = None
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Destroy_Menu -> {E}')

    def _Rebuild(self, Widget=False):
        try:
            self._Destroy_Menu()
            Target = self._Resolve_Target(Widget)

            if Target is not None:
                with Target:
                    self._Widget = ui.element('div').style('display: contents')
                    with ui.menu().props('auto-close') as self._Menu:
                        if isinstance(self._Layout, dict):
                            self._Build_Menu_Level(self._Layout)

            if self._Menu is not None:
                self._Menu.style(self._Menu_Style())

            self._Last_Target = Target
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Rebuild -> {E}')

    def Create(self):
        try:
            self._Rebuild()
            self._Initialized = True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Create -> {E}')

    def Delete(self):
        try:
            self._Destroy_Menu()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Delete -> {E}')

    def Set(self, Value=False):
        try:
            if Value is not False:
                self._Layout = Value if isinstance(Value, dict) else {}
                if self._Initialized:
                    self._Rebuild(self._Last_Target if self._Last_Target is not None else False)
            return self._Layout
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Set -> {E}')

    def Get(self):
        try:
            return self._Layout
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Get -> {E}')

    def Config_Get(self, *Input):
        try:
            Return = {}
            for Each in self._Config:
                if Each in Input:
                    Return[Each] = getattr(self, '_' + Each)
            return Return
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config_Get -> {E}')

    def Config(self, **Input):
        try:
            Run = False
            for Each in self._Config:
                if Each in Input:
                    setattr(self, '_' + Each, Input[Each])
                    Run = True
            if self._Initialized and Run:
                self._Rebuild(self._Last_Target if self._Last_Target is not None else False)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config -> {E}')

    def Open(self, Left=False, Top=False, Widget=False, Event=False):
        try:
            if self._Disable:
                return False
            if not isinstance(self._Layout, dict) or len(self._Layout) == 0:
                return False

            self._Rebuild(Widget)

            if self._Menu is None:
                return False

            self._Menu.open()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Open -> {E}')

    def Close(self):
        try:
            if self._Menu:
                self._Menu.close()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Close -> {E}')