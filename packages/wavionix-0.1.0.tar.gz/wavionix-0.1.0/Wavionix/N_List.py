from types import SimpleNamespace
from nicegui import ui
from .N_GUI import GUI
from .N_Custom import Event_Bind


class List:

    def __init__(self, Main, *args, **kwargs):
        self._GUI = GUI._Instance
        if self._GUI is not None:
            self._Type = 'List'
            try:
                self._Config = {
                    'Name': False,
                    'Background': '#ffffff',
                    'Foreground': '#000000',
                    'Border_Color': '#000000',
                    'Border_Size': 0,
                    'Border_Radius': 0,
                    'Display': True,
                    'Left': None,
                    'Top': None,
                    'Right': None,
                    'Bottom': None,
                    'Width': None,
                    'Height': 160,
                    'Font_Size': 12,
                    'Font_Weight': 'normal',
                    'Font_Family': 'Helvetica',
                    'Disable': False,
                    'Scrollbar_Size': 12,
                    'Select_Foreground': '#000000',
                    'Select_Background': '#ffffff',
                    'Multiple': False,
                    'Values': [],
                    'Value': '',
                    'Hover_Background': False,
                    'Hover_Foreground': False,
                    'Hover_Border_Color': False,
                    'Padding': 4,
                    'Margin': 0,
                    'Mode': 'Flow',
                    'Classes': '',
                    'Style': '',
                    'Z_Index': None,
                    'Shadow_X': 0,
                    'Shadow_Y': 0,
                    'Shadow_Blur': 0,
                    'Shadow_Spread': 0,
                    'Shadow_Color': 'transparent',
                }
                self._Initialized = False
                self._Main = Main
                self._Widget = None
                self._Frame = None
                self._Body = None
                self._Items = []
                self._Labels = []
                self._Selected = set()
                self._Hover_Index = None
                self._Name = False
                self._Values = []
                self._Value = ''
                self._Background = '#ffffff'
                self._Foreground = '#000000'
                self._Border_Color = '#000000'
                self._Border_Size = 0
                self._Border_Radius = 0
                self._Display = True
                self._Left = None
                self._Top = None
                self._Right = None
                self._Bottom = None
                self._Width = None
                self._Height = 160
                self._Font_Size = 12
                self._Font_Weight = 'normal'
                self._Font_Family = 'Helvetica'
                self._Disable = False
                self._Scrollbar_Size = 12
                self._Select_Foreground = '#000000'
                self._Select_Background = '#ffffff'
                self._Multiple = False
                self._Hover_Background = False
                self._Hover_Foreground = False
                self._Hover_Border_Color = False
                self._Padding = 4
                self._Margin = 0
                self._Mode = 'Flow'
                self._Classes = ''
                self._Style = ''
                self._Z_Index = None
                self._Shadow_X = 0
                self._Shadow_Y = 0
                self._Shadow_Blur = 0
                self._Shadow_Spread = 0
                self._Shadow_Color = 'transparent'
                self._On_Show = False
                self._On_Hide = False
                self._On_Change = False
                if kwargs:
                    self.Config(**kwargs)
            except Exception as E:
                self._GUI.Error(f'{self._Type} -> Init -> {E}')
        else:
            print('Error: Wavionix -> GUI Instance Has Not Been Created')

    def __str__(self):
        return 'Nucleon_Wavionix_List[]'

    def __repr__(self):
        return 'Nucleon_Wavionix_List[]'

    def _Unit(self, Value):
        if Value is None or Value is False or Value == '':
            return None
        if isinstance(Value, (int, float)):
            return f'{Value}px'
        return str(Value)

    def _Get_Parent(self):
        if hasattr(self._Main, 'Widget') and callable(self._Main.Widget):
            return self._Main.Widget()
        if hasattr(self._Main, '_Frame') and self._Main._Frame is not None:
            return self._Main._Frame
        if hasattr(self._Main, '_Widget') and not isinstance(self._Main._Widget, list):
            return self._Main._Widget
        return self._Main

    def _Build_Shadow(self):
        X = self._Unit(self._Shadow_X) or '0px'
        Y = self._Unit(self._Shadow_Y) or '0px'
        Blur = self._Unit(self._Shadow_Blur) or '0px'
        Spread = self._Unit(self._Shadow_Spread) or '0px'
        Color = self._Shadow_Color or 'transparent'
        return f'{X} {Y} {Blur} {Spread} {Color}'

    def _Build_Frame_Style(self):
        Style = []
        Style.append('box-sizing: border-box')
        Style.append(f'display: {"flex" if self._Display else "none"}')
        Style.append('flex-direction: column')
        Style.append('position: relative')
        Style.append('overflow: hidden')
        Style.append('user-select: none')
        Style.append(f'background: {self._Background}')
        Style.append(f'color: {self._Foreground}')
        Style.append(f'border: {self._Unit(self._Border_Size) or "0px"} solid {self._Border_Color}')
        Style.append(f'border-radius: {self._Unit(self._Border_Radius) or "0px"}')
        Style.append(f'box-shadow: {self._Build_Shadow()}')
        Style.append(f'margin: {self._Unit(self._Margin) or "0px"}')
        Style.append('min-width: 0')
        Style.append('min-height: 0')

        if self._Mode == 'Place':
            Style.append('position: absolute')
            if self._Left is not None:
                Style.append(f'left: {self._Unit(self._Left)}')
            if self._Top is not None:
                Style.append(f'top: {self._Unit(self._Top)}')
            if self._Right is not None:
                Style.append(f'right: {self._Unit(self._Right)}')
            if self._Bottom is not None:
                Style.append(f'bottom: {self._Unit(self._Bottom)}')

        if self._Width is not None:
            Style.append(f'width: {self._Unit(self._Width)}')

        if self._Height is not None:
            Height = self._Unit(self._Height)
            Style.append(f'height: {Height}')
            Style.append(f'min-height: {Height}')

        if self._Z_Index is not None:
            Style.append(f'z-index: {self._Z_Index}')

        if self._Disable:
            Style.append('pointer-events: none')
            Style.append('opacity: 0.55')

        if self._Style:
            Style.append(self._Style)

        return '; '.join(Style)

    def _Build_Body_Style(self):
        Style = []
        Style.append('width: 100%')
        Style.append('height: 100%')
        Style.append('flex: 1 1 auto')
        Style.append('display: flex')
        Style.append('flex-direction: column')
        Style.append('gap: 4px')
        Style.append('box-sizing: border-box')
        Style.append(f'padding: {self._Unit(self._Padding) or "0px"}')
        Style.append('overflow-x: hidden')
        Style.append('overflow-y: auto')
        Style.append('min-width: 0')
        Style.append('min-height: 0')
        Style.append('scrollbar-gutter: stable')
        return '; '.join(Style)

    def _Build_Label_Style(self):
        Style = []
        Style.append('margin: 0')
        Style.append('width: 100%')
        Style.append('pointer-events: none')
        Style.append('color: inherit')
        Style.append('font: inherit')
        Style.append('white-space: nowrap')
        Style.append('overflow: hidden')
        Style.append('text-overflow: ellipsis')
        return '; '.join(Style)

    def _Build_Item_Style(self, Index):
        Selected = Index in self._Selected
        Hover = Index == self._Hover_Index

        Background = 'transparent'
        Foreground = self._Foreground
        Border_Color = 'transparent'

        if Selected:
            Background = self._Select_Background
            Foreground = self._Select_Foreground
            Border_Color = 'transparent'
        elif Hover:
            if self._Hover_Background:
                Background = self._Hover_Background
            if self._Hover_Foreground:
                Foreground = self._Hover_Foreground
            if self._Hover_Border_Color:
                Border_Color = self._Hover_Border_Color

        Radius = self._Unit(self._Border_Radius) or '0px'

        Style = []
        Style.append('display: flex')
        Style.append('align-items: center')
        Style.append('width: 100%')
        Style.append('min-height: 32px')
        Style.append('box-sizing: border-box')
        Style.append('min-width: 0')
        Style.append('cursor: not-allowed' if self._Disable else 'cursor: pointer')
        Style.append(f'background: {Background}')
        Style.append(f'color: {Foreground}')
        Style.append(f'border: 1px solid {Border_Color}')
        Style.append(f'border-radius: {Radius}')
        Style.append(f'font-size: {self._Unit(self._Font_Size) or "12px"}')
        Style.append(f'font-weight: {self._Font_Weight}')
        Style.append(f'font-family: {self._Font_Family}')
        Style.append('padding: 6px 10px')
        Style.append('transition: all 0.12s ease')

        Style.append('outline: none')
        Style.append('box-shadow: none')
        Style.append('-webkit-tap-highlight-color: transparent')

        return '; '.join(Style)

    def _Selected_Values(self):
        Result = []
        for Index in sorted(self._Selected):
            if 0 <= Index < len(self._Values):
                Result.append(self._Values[Index])
        return Result

    def _Apply_Item_Styles(self):
        try:
            for Index, Item in enumerate(self._Items):
                if hasattr(Item, '_style'):
                    Item._style.clear()
                if hasattr(Item, '_classes'):
                    Item._classes.clear()
                Item.style(self._Build_Item_Style(Index))
                Item.props(
                    f'tabindex="-1" '
                    f'role=option '
                    f'aria-selected={"true" if Index in self._Selected else "false"}'
                )
                Item.update()

            for Label in self._Labels:
                if hasattr(Label, '_style'):
                    Label._style.clear()
                if hasattr(Label, '_classes'):
                    Label._classes.clear()
                Label.style(self._Build_Label_Style())
                Label.update()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Apply_Item_Styles -> {E}')

    def _Emit_Change(self):
        try:
            if self._On_Change:
                self._On_Change(SimpleNamespace(value=self.Get(), sender=self, indices=sorted(self._Selected)))
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Emit_Change -> {E}')

    def _Set_Hover(self, Index=None):
        try:
            self._Hover_Index = Index
            self._Apply_Item_Styles()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Set_Hover -> {E}')

    def _Select_Index(self, Index):
        try:
            if self._Disable:
                return
            if not 0 <= Index < len(self._Values):
                return

            if self._Multiple:
                if Index in self._Selected:
                    self._Selected.remove(Index)
                else:
                    self._Selected.add(Index)
            else:
                self._Selected = {Index}

            self._Apply_Item_Styles()
            self._Emit_Change()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Select_Index -> {E}')

    def _Rebuild(self):
        try:
            if self._Body is None:
                return

            Fixed = set()
            for Index in self._Selected:
                if 0 <= Index < len(self._Values):
                    Fixed.add(Index)
            self._Selected = Fixed

            if self._Hover_Index is not None:
                if not 0 <= self._Hover_Index < len(self._Values):
                    self._Hover_Index = None

            self._Body.clear()
            self._Items = []
            self._Labels = []

            with self._Body:
                for Index, Each in enumerate(self._Values):
                    Item = ui.element('div')
                    with Item:
                        Label = ui.label(str(Each))

                    Item.on('click', lambda E, Index=Index: self._Select_Index(Index))
                    Item.on('keydown.enter', lambda E, Index=Index: self._Select_Index(Index))
                    Item.on('keydown.space', lambda E, Index=Index: self._Select_Index(Index))
                    Item.on('mouseenter', lambda E, Index=Index: self._Set_Hover(Index))
                    Item.on('mouseleave', lambda E: self._Set_Hover(None))

                    self._Items.append(Item)
                    self._Labels.append(Label)

            self._Apply_Item_Styles()
            self._Body.update()

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Rebuild -> {E}')

    def Place(self, Left=None, Top=None, Right=None, Bottom=None, Width=None, Height=None):
        try:
            self._Mode = 'Place'
            if Left is not None:
                self._Left = Left
            if Top is not None:
                self._Top = Top
            if Right is not None:
                self._Right = Right
            if Bottom is not None:
                self._Bottom = Bottom
            if Width is not None:
                self._Width = Width
            if Height is not None:
                self._Height = Height
            self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Place -> {E}')

    def Pack(self, Classes=None, Style=None, Margin=None, Padding=None):
        try:
            self._Mode = 'Flow'
            self._Left = None
            self._Top = None
            self._Right = None
            self._Bottom = None
            if Classes is not None:
                self._Classes = Classes
            if Style is not None:
                self._Style = Style
            if Margin is not None:
                self._Margin = Margin
            if Padding is not None:
                self._Padding = Padding
            self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Pack -> {E}')

    def _Apply(self):
        try:
            if self._Frame is None or self._Body is None:
                return

            if hasattr(self._Frame, '_style'):
                self._Frame._style.clear()
            if hasattr(self._Frame, '_classes'):
                self._Frame._classes.clear()

            if hasattr(self._Body, '_style'):
                self._Body._style.clear()
            if hasattr(self._Body, '_classes'):
                self._Body._classes.clear()

            self._Frame.style(self._Build_Frame_Style())

            Classes = []
            if self._Classes:
                Classes.append(self._Classes)
            if len(Classes) > 0:
                self._Frame.classes(' '.join(Classes))

            self._Body.style(self._Build_Body_Style())

            self._Frame.update()
            self._Body.update()

            self._Rebuild()

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Apply -> {E}')

    def _Values_From_Input(self, Value):
        try:
            if Value is None or Value is False:
                return []
            if isinstance(Value, str):
                Text = Value.strip()
                if Text == '':
                    return []
                return [Each.strip() for Each in Text.split('/') if Each.strip() != '']
            if isinstance(Value, (list, tuple, set)):
                return [Each for Each in list(Value) if Each is not None and Each is not False and str(Each).strip() != '']
            return [Value]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Values_From_Input -> {E}')
            return []

    def Copy(self, Name=False, Main=False):
        try:
            if not Main:
                Main = self._Main
            Instance = type(self)(Main)
            for Key in self._Config:
                if hasattr(self, '_' + Key):
                    setattr(Instance, '_' + Key, getattr(self, '_' + Key))
            Instance._Value = self._Value
            Instance._Values = list(self._Values)
            Instance._Selected = set(self._Selected)
            if Name:
                Instance._Name = Name
            Instance.Create()
            return Instance
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Copy -> {E}')

    def Delete(self):
        try:
            if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self in self._Main._Widget:
                self._Main._Widget.remove(self)
            if self._Widget is not None:
                self._Widget.delete()
                self._Widget = None
                self._Frame = None
                self._Body = None
                self._Items = []
                self._Labels = []
                self._Selected = set()
                self._Hover_Index = None
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Delete -> {E}')

    def Hide(self):
        try:
            self._Display = False
            self._Apply()
            if self._On_Hide:
                self._On_Hide()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Hide -> {E}')

    def Show(self):
        try:
            self._Display = True
            self._Apply()
            if self._On_Show:
                self._On_Show()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Show -> {E}')

    def Focus(self):
        try:
            if len(self._Items) > 0:
                self._Items[0].run_method('focus')
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Focus -> {E}')

    def Top(self):
        try:
            if self._Body is not None:
                self._Body.run_method('scrollTo', 0, 0)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Top -> {E}')

    def Get(self):
        try:
            Values = self._Selected_Values()
            if self._Multiple:
                return Values
            if len(Values) == 1:
                return Values[0]
            return None
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Get -> {E}')

    def Set(self, Value):
        try:
            New_Selected = set()
            if isinstance(Value, str) and '/' in Value:
                Values = self._Values_From_Input(Value)
            else:
                Values = Value
            if isinstance(Values, (list, tuple, set)):
                for Each in Values:
                    if isinstance(Each, int):
                        if 0 <= Each < len(self._Values):
                            New_Selected.add(Each)
                    elif Each in self._Values:
                        New_Selected.add(self._Values.index(Each))
            else:
                if isinstance(Values, int):
                    if 0 <= Values < len(self._Values):
                        New_Selected.add(Values)
                elif Values in self._Values:
                    New_Selected.add(self._Values.index(Values))
            if not self._Multiple and len(New_Selected) > 1:
                New_Selected = {sorted(New_Selected)[0]}
            self._Selected = New_Selected
            self._Apply_Item_Styles()
            return self.Get()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Set -> {E}')

    def Reset(self):
        try:
            self._Selected = set()
            self._Apply_Item_Styles()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Reset -> {E}')

    def Add(self, Value):
        try:
            Values = self._Values_From_Input(Value)
            for Each in Values:
                if Each not in self._Values:
                    self._Values.append(Each)
            self._Value = '/'.join([str(Each) for Each in self._Values])
            self._Apply()
            return self._Values
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Add -> {E}')

    def Remove(self, Value):
        try:
            Values = self._Values_From_Input(Value)
            Selected = self._Selected_Values()
            for Each in Values:
                if Each in self._Values:
                    self._Values.remove(Each)
            self._Value = '/'.join([str(Each) for Each in self._Values])
            self._Selected = set()
            for Each in Selected:
                if Each in self._Values:
                    self._Selected.add(self._Values.index(Each))
            if not self._Multiple and len(self._Selected) > 1:
                self._Selected = {sorted(self._Selected)[0]}
            self._Apply()
            return self._Values
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Remove -> {E}')

    def Clear(self):
        try:
            self._Value = ''
            self._Values = []
            self._Selected = set()
            self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Clear -> {E}')

    def Sort(self):
        try:
            Selected = self._Selected_Values()
            self._Values = sorted(self._Values, key=lambda X: str(X))
            self._Selected = set()
            for Each in Selected:
                if Each in self._Values:
                    self._Selected.add(self._Values.index(Each))
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Sort -> {E}')

    def Refresh(self, Value=False):
        try:
            self._Apply()
            if Value is not False:
                self.Set(Value)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Refresh -> {E}')

    def Widget(self):
        try:
            return self._Frame
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Widget -> {E}')

    def Bind(self, **Input):
        try:
            if 'On_Show' in Input:
                self._On_Show = Input['On_Show']
                del Input['On_Show']
            if 'On_Hide' in Input:
                self._On_Hide = Input['On_Hide']
                del Input['On_Hide']
            if 'On_Change' in Input:
                self._On_Change = Input['On_Change']
                del Input['On_Change']
            if self._Frame is not None and len(Input) > 0:
                Event_Bind(self._Frame, **Input)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Bind -> {E}')

    def Config_Get(self, *Input):
        try:
            Return = {}
            for Each in self._Config:
                if Each in Input:
                    Return[Each] = getattr(self, '_' + Each)
            return Return
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config_Get -> {E}')

    def Config(self, **Input):
        try:
            Run = False
            for Each in self._Config:
                if Each in Input:
                    setattr(self, '_' + Each, Input[Each])
                    Run = True
            if 'Value' in Input:
                self._Value = Input['Value']
                self._Values = self._Values_From_Input(Input['Value'])
                self._Selected = {Index for Index in self._Selected if 0 <= Index < len(self._Values)}
            if 'Values' in Input:
                self._Values = self._Values_From_Input(Input['Values'])
                self._Value = Input['Values']
                self._Selected = {Index for Index in self._Selected if 0 <= Index < len(self._Values)}
            if not self._Multiple and len(self._Selected) > 1:
                self._Selected = {sorted(self._Selected)[0]}
            if self._Initialized and Run:
                self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config -> {E}')

    def Move(self, Left=None, Top=None):
        try:
            if Left is not None:
                self._Left = (self._Left or 0) + Left
            if Top is not None:
                self._Top = (self._Top or 0) + Top
            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Move -> {E}')

    def Center(self, Left=None, Top=None):
        try:
            Width = self._Width or 0
            Height = self._Height or 0
            if Left is not None:
                self._Left = Left - Width / 2
            if Top is not None:
                self._Top = Top - Height / 2
            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()
            return [self._Left + Width / 2, self._Top + Height / 2]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Center -> {E}')

    def Position(self, Left=None, Top=None, Right=None, Bottom=None):
        try:
            if Left is not None:
                self._Left = Left
            if Top is not None:
                self._Top = Top
            if Right is not None:
                self._Right = Right
            if Bottom is not None:
                self._Bottom = Bottom
            if Left is not None or Top is not None or Right is not None or Bottom is not None:
                self._Mode = 'Place'
                self._Apply()
            return [self._Left, self._Top, self._Right, self._Bottom]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Position -> {E}')

    def Size(self, Width=False, Height=False):
        try:
            if Width is not False:
                self._Width = Width
            if Height is not False:
                self._Height = Height
            if Width is not False or Height is not False:
                self._Apply()
            return [self._Width, self._Height]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Size -> {E}')

    def Enlarge(self, Value=None):
        try:
            if Value is not None:
                self._Width = (self._Width or 0) + Value
                self._Height = (self._Height or 0) + Value
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Enlarge -> {E}')

    def Shrink(self, Value=None):
        try:
            if Value is not None:
                self._Width = max(0, (self._Width or 0) - Value)
                self._Height = max(0, (self._Height or 0) - Value)
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Shrink -> {E}')

    def Box(self):
        try:
            return [self._Left, self._Top, self._Width, self._Height]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Box -> {E}')

    def Ratio(self):
        try:
            return [1, 1]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Ratio -> {E}')

    def Locate(self, Width, Height, Left, Top):
        try:
            Width = self._Width * (Width / 100)
            Height = self._Height * (Height / 100)
            Left = self._Width * (Left / 100)
            Top = self._Height * (Top / 100)
            return [Width, Height, Left, Top]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Locate -> {E}')

    def Locate_Reverse(self, Width, Height, Left, Top):
        try:
            Width = round((Width / self._Width) * 100, 3)
            Height = round((Height / self._Height) * 100, 3)
            Left = round((Left / self._Width) * 100, 3)
            Top = round((Top / self._Height) * 100, 3)
            return [Width, Height, Left, Top]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Locate_Reverse -> {E}')

    def Create(self):
        try:
            if self._Widget is None:
                Parent = self._Get_Parent()
                if self._Mode != 'Place':
                    if self._Left is not None or self._Top is not None or self._Right is not None or self._Bottom is not None:
                        self._Mode = 'Place'
                if Parent is not None:
                    with Parent:
                        self._Widget = ui.element('div')
                        self._Widget.style('display: contents')
                        self._Frame = ui.element('div')
                        with self._Frame:
                            self._Body = ui.element('div')
                else:
                    self._Widget = ui.element('div')
                    self._Widget.style('display: contents')
                    self._Frame = ui.element('div')
                    with self._Frame:
                        self._Body = ui.element('div')
                if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self not in self._Main._Widget:
                    self._Main._Widget.append(self)
                self._Initialized = True
            self._Apply()
            if self._Name:
                self._Main.__dict__[self._Name] = self
            if not self._Display:
                self.Hide()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Create -> {E}')