from nicegui import ui
from .N_GUI import GUI
from .N_Custom import Event_Bind


class Popup:

    _Registered = False
    _Instance = []

    def __init__(self, Main=False, **kwargs):
        self._GUI = GUI._Instance
        if self._GUI is not None:
            self._Type = 'Popup'
            try:
                self._Config = [
                    'Background',
                    'Foreground',
                    'Border_Color',
                    'Border_Size',
                    'Border_Radius',
                    'Width',
                    'Height',
                    'Left',
                    'Top',
                    'Display',
                    'Draggable',
                    'Padding',
                    'Gap',
                    'Z_Index',
                    'Shadow_X',
                    'Shadow_Y',
                    'Shadow_Blur',
                    'Shadow_Spread',
                    'Shadow_Color',
                    'Handle_Foreground',
                    'Handle_Size',
                    'Handle_Mark',
                    'Handle_Left',
                    'Handle_Top',
                    'Scroll',
                    'Scroll_X',
                    'Scroll_Y',
                ]

                self._Initialized = False
                self._Main = Main
                self._Widget = None
                self._Frame = None
                self._Handle = None
                self._Handle_Label = None
                self._Body = None

                self._Background = '#ffffff'
                self._Foreground = '#000000'
                self._Border_Color = '#000000'
                self._Border_Size = 1
                self._Border_Radius = 12
                self._Width = 420
                self._Height = 220
                self._Left = 240
                self._Top = 160
                self._Display = False
                self._Draggable = True
                self._Padding = 12
                self._Gap = 10
                self._Z_Index = 3000

                self._Shadow_X = 0
                self._Shadow_Y = 12
                self._Shadow_Blur = 30
                self._Shadow_Spread = 0
                self._Shadow_Color = 'rgba(0,0,0,0.18)'

                self._Handle_Foreground = '#666666'
                self._Handle_Size = 18
                self._Handle_Mark = '✥'
                self._Handle_Left = 8
                self._Handle_Top = 6

                self._Dragging = False
                self._Drag_Start_X = 0.0
                self._Drag_Start_Y = 0.0
                self._Start_Left = 0.0
                self._Start_Top = 0.0
                
                self._Scroll = True
                self._Scroll_X = None
                self._Scroll_Y = None                
                self._Start_Left_CSS = '0px'
                self._Start_Top_CSS = '0px'

                self._On_Show = False
                self._On_Hide = False
                self._On_Close = False

                if kwargs:
                    self.Config(**kwargs)

                self._Register_Global()

            except Exception as E:
                self._GUI.Error(f'{self._Type} -> Init -> {E}')
                raise
        else:
            print('Error: Wavionix -> GUI Instance Has Not Been Created')

    def __str__(self):
        return f'Nucleon_Wavionix_Popup[{self._Left},{self._Top},{self._Width},{self._Height}]'

    def __repr__(self):
        return f'Nucleon_Wavionix_Popup[{self._Left},{self._Top},{self._Width},{self._Height}]'

    @classmethod
    def _Register_Global(cls):
        if cls._Registered:
            return

        def _Mouse_Move(Event):
            for Each in list(cls._Instance):
                try:
                    Each._Update_Drag(Event)
                except Exception:
                    pass

        def _Mouse_Up(Event=None):
            for Each in list(cls._Instance):
                try:
                    Each._Stop_Drag(Event)
                except Exception:
                    pass

        ui.on('mousemove', _Mouse_Move)
        ui.on('mouseup', _Mouse_Up)
        cls._Registered = True

    def _Unit(self, Value):
        if Value is None or Value is False or Value == '':
            return None
        if isinstance(Value, (int, float)):
            return f'{Value}px'
        return str(Value)

    def _Get_Parent(self):
        if hasattr(self._Main, 'Widget') and callable(self._Main.Widget):
            return self._Main.Widget()
        if hasattr(self._Main, '_Frame') and self._Main._Frame is not None:
            return self._Main._Frame
        if hasattr(self._Main, '_Widget') and not isinstance(self._Main._Widget, list):
            return self._Main._Widget
        return self._Main

    def _Get_Event_Value(self, Event, Name_List, Default_Value=0.0):
        for Name in Name_List:
            Value = getattr(Event, Name, None)
            if Value is not None:
                return Value

        Event_Args = getattr(Event, 'args', None)
        if isinstance(Event_Args, dict):
            for Name in Name_List:
                if Name in Event_Args and Event_Args[Name] is not None:
                    return Event_Args[Name]

        return Default_Value

    def _Build_Shadow(self):
        X = self._Unit(self._Shadow_X) or '0px'
        Y = self._Unit(self._Shadow_Y) or '0px'
        Blur = self._Unit(self._Shadow_Blur) or '0px'
        Spread = self._Unit(self._Shadow_Spread) or '0px'
        Color = self._Shadow_Color or 'transparent'
        return f'{X} {Y} {Blur} {Spread} {Color}'

    def _Scroll_Mode(self, Value, Default='auto'):
        try:
            if Value is None:
                return Default
            if Value is True:
                return 'auto'
            if Value is False:
                return 'hidden'
            return str(Value)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Scroll_Mode -> {E}')
            return Default
            
    def _Frame_Style(self):
        return '; '.join([
            'position: fixed',
            f'left: {self._Unit(self._Left) or "0px"}',
            f'top: {self._Unit(self._Top) or "0px"}',
            f'width: {self._Unit(self._Width) or "420px"}',
            f'height: {self._Unit(self._Height) or "220px"}',
            f'display: {"block" if self._Display else "none"}',
            f'z-index: {self._Z_Index}',
            f'background: {self._Background}',
            f'color: {self._Foreground}',
            f'border: {self._Unit(self._Border_Size) or "0px"} solid {self._Border_Color}',
            f'border-radius: {self._Unit(self._Border_Radius) or "12px"}',
            f'box-shadow: {self._Build_Shadow()}',
            'overflow: hidden',
            'box-sizing: border-box',
            'padding: 0',
            'margin: 0',
        ])

    def _Handle_Style(self):
        return '; '.join([
            'position: absolute',
            f'left: {self._Unit(self._Handle_Left) or "8px"}',
            f'top: {self._Unit(self._Handle_Top) or "6px"}',
            'display: flex',
            'align-items: center',
            'justify-content: center',
            'background: transparent',
            'border: none',
            'padding: 0',
            'margin: 0',
            'min-width: 16px',
            'min-height: 16px',
            'line-height: 1',
            'user-select: none',
            'pointer-events: auto',
            'touch-action: none',
            f'cursor: {"move" if self._Draggable else "default"}',
            'z-index: 50',
        ])

    def _Body_Style(self):
        Pad = self._Unit(self._Padding) or '12px'
        Top_Pad = f'calc({Pad} + {self._Unit(self._Handle_Size) or "18px"} + 2px)'

        Overflow = self._Scroll_Mode(self._Scroll, 'auto')

        Style = [
            'width: 100%',
            'height: 100%',
            f'overflow: {Overflow}',
            'box-sizing: border-box',
            f'padding-top: {Top_Pad}',
            f'padding-right: {Pad}',
            f'padding-bottom: {Pad}',
            f'padding-left: {Pad}',
            f'background: {self._Background}',
            f'color: {self._Foreground}',
        ]

        if self._Scroll_X is not None:
            Style.append(f'overflow-x: {self._Scroll_Mode(self._Scroll_X, Overflow)}')

        if self._Scroll_Y is not None:
            Style.append(f'overflow-y: {self._Scroll_Mode(self._Scroll_Y, Overflow)}')

        return '; '.join(Style)

    def _Apply(self):
        try:
            if self._Frame is None:
                return

            self._Frame.style(self._Frame_Style())

            if self._Handle is not None:
                self._Handle.style(self._Handle_Style())

            if self._Handle_Label is not None:
                self._Handle_Label.set_text(self._Handle_Mark)
                self._Handle_Label.style(
                    f'color: {self._Handle_Foreground}; '
                    f'font-size: {self._Unit(self._Handle_Size) or "18px"}; '
                    'font-weight: 700; line-height: 1; margin: 0; padding: 0;'
                )

            if self._Body is not None:
                self._Body.style(self._Body_Style())

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Apply -> {E}')
            raise

    def _Css_Unit(self, Value, Default='0px'):
        try:
            Unit = self._Unit(Value)
            if Unit is None:
                return Default
            return Unit
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Css_Unit -> {E}')
            return Default

    def _Css_Calc(self, Base, Delta):
        try:
            Delta = round(float(Delta), 3)
            if Delta == 0:
                return Base
            return f'calc({Base} + {Delta}px)'
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Css_Calc -> {E}')
            return Base

    def _Start_Drag(self, Event):
        try:
            if not self._Display:
                return
            if not self._Draggable:
                return
            self._Dragging = True
            self._Drag_Start_X = float(self._Get_Event_Value(Event, ['client_x', 'clientX', 'x'], 0.0))
            self._Drag_Start_Y = float(self._Get_Event_Value(Event, ['client_y', 'clientY', 'y'], 0.0))
            self._Start_Left_CSS = self._Css_Unit(self._Left, '0px')
            self._Start_Top_CSS = self._Css_Unit(self._Top, '0px')
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Start_Drag -> {E}')

    def _Update_Drag(self, Event):
        try:
            if not self._Dragging:
                return
            Current_X = float(self._Get_Event_Value(Event, ['client_x', 'clientX', 'x'], self._Drag_Start_X))
            Current_Y = float(self._Get_Event_Value(Event, ['client_y', 'clientY', 'y'], self._Drag_Start_Y))
            Delta_X = Current_X - self._Drag_Start_X
            Delta_Y = Current_Y - self._Drag_Start_Y
            self._Left = self._Css_Calc(self._Start_Left_CSS, Delta_X)
            self._Top = self._Css_Calc(self._Start_Top_CSS, Delta_Y)
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Update_Drag -> {E}')

    def _Stop_Drag(self, Event=None):
        try:
            self._Dragging = False
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Stop_Drag -> {E}')

    def Config(self, **Input):
        try:
            Run = False
            for Each in self._Config:
                if Each in Input:
                    setattr(self, '_' + Each, Input[Each])
                    Run = True

            if self._Initialized and Run:
                self._Apply()

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config -> {E}')
            raise

    def Config_Get(self, *Input):
        try:
            Return = {}
            for Each in self._Config:
                if Each in Input:
                    Return[Each] = getattr(self, '_' + Each)
            return Return

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config_Get -> {E}')
            raise

    def Create(self):
        try:
            if self._Widget is None:
                self._Widget = ui.element('div')
                self._Widget.style('display: contents')
                self._Frame = ui.card()
                self._Frame.style('padding: 0; margin: 0;')

                with self._Frame:
                    self._Handle = ui.row().classes('items-center justify-center')
                    with self._Handle:
                        self._Handle_Label = ui.label(self._Handle_Mark)
                    self._Body = ui.column().classes('w-full')

                self._Handle.on('mousedown', self._Start_Drag)
                self._Handle_Label.on('mousedown', self._Start_Drag)

                ui.on('mousemove', self._Update_Drag)
                ui.on('mouseup', self._Stop_Drag)

                if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self not in self._Main._Widget:
                    self._Main._Widget.append(self)

                self._Initialized = True

            self._Apply()
            return self

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Create -> {E}')
            raise

    def Delete(self):
        try:
            if self in Popup._Instance:
                Popup._Instance.remove(self)

            if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self in self._Main._Widget:
                self._Main._Widget.remove(self)

            if self._Widget is not None:
                self._Widget.delete()

            self._Widget = None
            self._Frame = None
            self._Handle = None
            self._Handle_Label = None
            self._Body = None

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Delete -> {E}')
            raise

    def Show(self):
        try:
            self._Display = True
            self._Apply()
            if self._On_Show:
                self._On_Show()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Show -> {E}')
            raise

    def Hide(self):
        try:
            self._Display = False
            self._Dragging = False
            self._Apply()
            if self._On_Hide:
                self._On_Hide()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Hide -> {E}')
            raise

    def Toggle(self):
        try:
            if self._Display:
                self.Hide()
            else:
                self.Show()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Toggle -> {E}')
            raise

    def Close(self):
        try:
            if self._On_Close:
                self._On_Close()
            self.Delete()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Close -> {E}')
            raise

    def Scroll(self, Value=None, X=None, Y=None):
        try:
            if Value is not None:
                self._Scroll = Value
            if X is not None:
                self._Scroll_X = X
            if Y is not None:
                self._Scroll_Y = Y

            self._Apply()
            return [self._Scroll, self._Scroll_X, self._Scroll_Y]

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Scroll -> {E}')

    def After(self, Delay, Function):
        try:
            ui.timer(float(Delay) / 1000.0, Function, once=True)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> After -> {E}')
            raise

    def Widget(self):
        try:
            return self._Body
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Widget -> {E}')
            raise

    def Body(self):
        try:
            return self._Body
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Body -> {E}')
            raise

    def Bind(self, **Input):
        try:
            if 'On_Show' in Input:
                self._On_Show = Input['On_Show']
                del Input['On_Show']

            if 'On_Hide' in Input:
                self._On_Hide = Input['On_Hide']
                del Input['On_Hide']

            if 'On_Close' in Input:
                self._On_Close = Input['On_Close']
                del Input['On_Close']

            if self._Frame is not None and len(Input) > 0:
                Event_Bind(self._Frame, **Input)

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Bind -> {E}')
            raise

    def Move(self, Left=None, Top=None):
        try:
            if Left is not None:
                self._Left += Left
            if Top is not None:
                self._Top += Top

            if Left is not None or Top is not None:
                self._Apply()

            return True

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Move -> {E}')
            raise

    def Center(self, Left=None, Top=None):
        try:
            if Left is not None:
                self._Left = Left - self._Width / 2
            if Top is not None:
                self._Top = Top - self._Height / 2

            if Left is not None or Top is not None:
                self._Apply()

            return [self._Left + self._Width / 2, self._Top + self._Height / 2]

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Center -> {E}')
            raise

    def Position(self, Left=None, Top=None):
        try:
            if Left is not None:
                self._Left = Left
            if Top is not None:
                self._Top = Top

            if Left is not None or Top is not None:
                self._Apply()

            return [self._Left, self._Top]

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Position -> {E}')
            raise

    def Size(self, Width=None, Height=None):
        try:
            if Width is not None:
                self._Width = Width
            if Height is not None:
                self._Height = Height

            if Width is not None or Height is not None:
                self._Apply()

            return [self._Width, self._Height]

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Size -> {E}')
            raise

    def Enlarge(self, Value=None):
        try:
            if Value is not None:
                self._Left -= Value
                self._Top -= Value
                self._Width += Value
                self._Height += Value
                self._Apply()

            return True

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Enlarge -> {E}')
            raise

    def Shrink(self, Value=None):
        try:
            if Value is not None:
                self._Left += Value
                self._Top += Value
                self._Width -= Value
                self._Height -= Value
                self._Apply()

            return True

        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Shrink -> {E}')
            raise

    def Box(self):
        try:
            return [self._Left, self._Top, self._Width, self._Height]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Box -> {E}')
            raise