from nicegui import ui
from .N_GUI import GUI
from .N_Custom import Event_Bind


class Entry:

    def __init__(self, Main, *args, **kwargs):
        self._GUI = GUI._Instance
        if self._GUI is not None:
            self._Type = 'Entry'
            try:
                self._Config = {
                    'Name': False,
                    'Background': '#ffffff',
                    'Foreground': '#000000',
                    'Border_Color': '#000000',
                    'Border_Size': 0,
                    'Border_Radius': 0,
                    'Display': True,
                    'Left': None,
                    'Top': None,
                    'Right': None,
                    'Bottom': None,
                    'Width': None,
                    'Height': 40,
                    'Font_Size': 12,
                    'Font_Weight': 'normal',
                    'Font_Family': 'Helvetica',
                    'Align': 'center',
                    'Disable': False,
                    'Secure': False,
                    'Placeholder': '',
                    'Value': '',
                    'Disable_Background': '#d0d3d4',
                    'Disable_Foreground': '#7b7d7d',
                    'Select_Background': '#000000',
                    'Select_Foreground': '#ffffff',
                    'Hover_Background': False,
                    'Hover_Foreground': False,
                    'Hover_Border_Color': False,
                    'Padding': '0 10px',
                    'Margin': 0,
                    'Mode': 'Flow',
                    'Classes': '',
                    'Style': '',
                    'Z_Index': None,
                    'Shadow_X': 0,
                    'Shadow_Y': 0,
                    'Shadow_Blur': 0,
                    'Shadow_Spread': 0,
                    'Shadow_Color': 'transparent',
                }
                self._Initialized = False
                self._Main = Main
                self._Widget = None
                self._Frame = None
                self._Row = None
                self._Input = None
                self._Toggle_Button = None
                self._Name = False
                self._Background = '#ffffff'
                self._Foreground = '#000000'
                self._Border_Color = '#000000'
                self._Border_Size = 0
                self._Border_Radius = 0
                self._Display = True
                self._Left = None
                self._Top = None
                self._Right = None
                self._Bottom = None
                self._Width = None
                self._Height = 40
                self._Font_Size = 12
                self._Font_Weight = 'normal'
                self._Font_Family = 'Helvetica'
                self._Align = 'center'
                self._Disable = False
                self._Secure = False
                self._Password_Visible = False
                self._Placeholder = ''
                self._Value = ''
                self._Disable_Background = '#d0d3d4'
                self._Disable_Foreground = '#7b7d7d'
                self._Select_Background = '#000000'
                self._Select_Foreground = '#ffffff'
                self._Hover_Background = False
                self._Hover_Foreground = False
                self._Hover_Border_Color = False
                self._Padding = '0 10px'
                self._Margin = 0
                self._Mode = 'Flow'
                self._Classes = ''
                self._Style = ''
                self._Z_Index = None
                self._Shadow_X = 0
                self._Shadow_Y = 0
                self._Shadow_Blur = 0
                self._Shadow_Spread = 0
                self._Shadow_Color = 'transparent'
                self._On_Show = False
                self._On_Hide = False
                self._On_Change = False
                if kwargs:
                    self.Config(**kwargs)
            except Exception as E:
                self._GUI.Error(f'{self._Type} -> Init -> {E}')
        else:
            print('Error: Wavionix -> GUI Instance Has Not Been Created')

    def __str__(self):
        return 'Nucleon_Wavionix_Entry[]'

    def __repr__(self):
        return 'Nucleon_Wavionix_Entry[]'

    def _Unit(self, Value):
        if Value is None or Value is False or Value == '':
            return None
        if isinstance(Value, (int, float)):
            return f'{Value}px'
        return str(Value)

    def _Get_Parent(self):
        if hasattr(self._Main, 'Widget') and callable(self._Main.Widget):
            return self._Main.Widget()
        if hasattr(self._Main, '_Frame') and self._Main._Frame is not None:
            return self._Main._Frame
        if hasattr(self._Main, '_Widget') and not isinstance(self._Main._Widget, list):
            return self._Main._Widget
        return self._Main

    def _Build_Shadow(self):
        X = self._Unit(self._Shadow_X) or '0px'
        Y = self._Unit(self._Shadow_Y) or '0px'
        Blur = self._Unit(self._Shadow_Blur) or '0px'
        Spread = self._Unit(self._Shadow_Spread) or '0px'
        Color = self._Shadow_Color or 'transparent'
        return f'{X} {Y} {Blur} {Spread} {Color}'

    def _Current_Background(self):
        if self._Disable:
            return self._Disable_Background
        return self._Background

    def _Current_Foreground(self):
        if self._Disable:
            return self._Disable_Foreground
        return self._Foreground

    def _Input_Type(self):
        if self._Secure and not self._Password_Visible:
            return 'password'
        return 'text'

    def _Toggle_Icon(self):
        if self._Secure and not self._Password_Visible:
            return 'visibility_off'
        return 'visibility'

    def _Build_Frame_Style(self):
        Style = []
        Style.append('box-sizing: border-box')
        Style.append(f'display: {"flex" if self._Display else "none"}')
        Style.append('align-items: center')
        Style.append(f'background: {self._Current_Background()}')
        Style.append(f'color: {self._Current_Foreground()}')
        Style.append(f'border: {self._Unit(self._Border_Size) or "0px"} solid {self._Border_Color}')
        Style.append(f'border-radius: {self._Unit(self._Border_Radius) or "0px"}')
        Style.append(f'box-shadow: {self._Build_Shadow()}')
        Style.append(f'padding: {self._Unit(self._Padding) or "0 10px"}')
        Style.append(f'margin: {self._Unit(self._Margin) or "0px"}')
        Style.append('overflow: hidden')
        Style.append('transition: all 0.2s ease')

        if self._Mode == 'Place':
            Style.append('position: absolute')
            if self._Left is not None:
                Style.append(f'left: {self._Unit(self._Left)}')
            if self._Top is not None:
                Style.append(f'top: {self._Unit(self._Top)}')
            if self._Right is not None:
                Style.append(f'right: {self._Unit(self._Right)}')
            if self._Bottom is not None:
                Style.append(f'bottom: {self._Unit(self._Bottom)}')

        if self._Width is not None:
            Style.append(f'width: {self._Unit(self._Width)}')
        if self._Height is not None:
            Style.append(f'height: {self._Unit(self._Height)}')
            Style.append(f'min-height: {self._Unit(self._Height)}')

        if self._Z_Index is not None:
            Style.append(f'z-index: {self._Z_Index}')

        if self._Style:
            Style.append(self._Style)

        return '; '.join(Style)

    def _Build_Row_Style(self):
        Style = []
        Style.append('display: flex')
        Style.append('align-items: center')
        Style.append('gap: 6px')
        Style.append('width: 100%')
        Style.append('height: 100%')
        return '; '.join(Style)

    def _Build_Input_Props(self):
        Align = str(self._Align).lower()
        if Align not in ['left', 'center', 'right']:
            Align = 'center'

        Props = []
        Props.append('borderless')
        Props.append('dense')
        Props.append(f'type={self._Input_Type()}')
        Props.append(
            f'input-style="'
            f'color:{self._Current_Foreground()};'
            f'text-align:{Align};'
            f'font-size:{self._Unit(self._Font_Size) or "12px"};'
            f'font-weight:{self._Font_Weight};'
            f'font-family:{self._Font_Family};'
            f'"'
        )

        if self._Placeholder:
            Props.append(f'placeholder="{self._Placeholder}"')

        if self._Disable:
            Props.append('disable')

        return ' '.join(Props)

    def _Build_Input_Style(self):
        Style = []
        Style.append('flex: 1 1 auto')
        Style.append('width: 100%')
        Style.append('background: transparent')
        Style.append(f'color: {self._Current_Foreground()}')
        return '; '.join(Style)

    def _Build_Toggle_Button_Props(self):
        Icon = self._Toggle_Icon()
        return f'flat round dense icon={Icon}'

    def _Build_Toggle_Button_Style(self):
        Style = []
        Style.append('min-width: 28px')
        Style.append('width: 28px')
        Style.append('height: 28px')
        Style.append('padding: 0')
        Style.append(f'color: {self._Current_Foreground()}')
        Style.append(f'display: {"flex" if self._Secure else "none"}')
        return '; '.join(Style)

    def _Handle_Change(self, Event):
        try:
            self._Value = Event.value
            if self._On_Change:
                self._On_Change(Event)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Handle_Change -> {E}')

    def _Toggle_Password(self):
        try:
            if not self._Secure:
                return
            self._Password_Visible = not self._Password_Visible
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Toggle_Password -> {E}')

    def _Hover_In(self):
        try:
            if self._Disable or self._Frame is None:
                return
            Background = self._Hover_Background if self._Hover_Background else self._Current_Background()
            Foreground = self._Hover_Foreground if self._Hover_Foreground else self._Current_Foreground()
            Border = self._Hover_Border_Color if self._Hover_Border_Color else self._Border_Color
            self._Frame.style(self._Build_Frame_Style() + f'; background: {Background}; color: {Foreground}; border-color: {Border}')
            if self._Toggle_Button is not None:
                self._Toggle_Button.style(self._Build_Toggle_Button_Style() + f'; color: {Foreground}')
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Hover_In -> {E}')

    def _Hover_Out(self):
        try:
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Hover_Out -> {E}')

    def Place(self, Left=None, Top=None, Right=None, Bottom=None, Width=None, Height=None):
        try:
            self._Mode = 'Place'
            if Left is not None:
                self._Left = Left
            if Top is not None:
                self._Top = Top
            if Right is not None:
                self._Right = Right
            if Bottom is not None:
                self._Bottom = Bottom
            if Width is not None:
                self._Width = Width
            if Height is not None:
                self._Height = Height
            self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Place -> {E}')

    def Pack(self, Classes=None, Style=None, Margin=None, Padding=None):
        try:
            self._Mode = 'Flow'
            self._Left = None
            self._Top = None
            self._Right = None
            self._Bottom = None

            if Classes is not None:
                self._Classes = Classes
            if Style is not None:
                self._Style = Style
            if Margin is not None:
                self._Margin = Margin
            if Padding is not None:
                self._Padding = Padding

            self._Apply()
            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Pack -> {E}')

    def _Apply(self):
        try:
            if self._Frame is None or self._Input is None:
                return

            if hasattr(self._Frame, '_style'):
                self._Frame._style.clear()
            if hasattr(self._Frame, '_classes'):
                self._Frame._classes.clear()

            self._Frame.style(self._Build_Frame_Style())

            Classes = []
            if self._Classes:
                Classes.append(self._Classes)

            if len(Classes) > 0:
                self._Frame.classes(' '.join(Classes))

            if self._Row is not None:
                if hasattr(self._Row, '_style'):
                    self._Row._style.clear()
                self._Row.style(self._Build_Row_Style())

            self._Input.value = self._Value
            self._Input.style(self._Build_Input_Style())
            self._Input.props(self._Build_Input_Props())
            self._Input.update()

            if self._Toggle_Button is not None:
                if hasattr(self._Toggle_Button, '_style'):
                    self._Toggle_Button._style.clear()
                self._Toggle_Button.props(self._Build_Toggle_Button_Props())
                self._Toggle_Button.style(self._Build_Toggle_Button_Style())
                self._Toggle_Button.update()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> _Apply -> {E}')

    def Copy(self, Name=False, Main=False):
        try:
            if not Main:
                Main = self._Main
            Instance = type(self)(Main)
            for Key in self._Config:
                if hasattr(self, '_' + Key):
                    setattr(Instance, '_' + Key, getattr(self, '_' + Key))
            if Name:
                Instance._Name = Name
            Instance._Value = self._Value
            Instance.Create()
            return Instance
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Copy -> {E}')

    def Delete(self):
        try:
            if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self in self._Main._Widget:
                self._Main._Widget.remove(self)
            if self._Widget is not None:
                self._Widget.delete()
                self._Widget = None
                self._Frame = None
                self._Row = None
                self._Input = None
                self._Toggle_Button = None
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Delete -> {E}')

    def Hide(self):
        try:
            self._Display = False
            self._Apply()
            if self._On_Hide:
                self._On_Hide()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Hide -> {E}')

    def Show(self):
        try:
            self._Display = True
            self._Apply()
            if self._On_Show:
                self._On_Show()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Show -> {E}')

    def Focus(self):
        try:
            if self._Input is not None:
                self._Input.run_method('focus')
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Focus -> {E}')

    def Get(self):
        try:
            if self._Input is not None:
                self._Value = self._Input.value
            return self._Value
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Get -> {E}')

    def Set(self, Value):
        try:
            self._Value = '' if Value is None else str(Value)
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Set -> {E}')

    def Clear(self):
        try:
            self._Value = ''
            self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Clear -> {E}')

    def Widget(self):
        try:
            return self._Input
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Widget -> {E}')

    def Bind(self, **Input):
        try:
            if 'On_Show' in Input:
                self._On_Show = Input['On_Show']
                del Input['On_Show']
            if 'On_Hide' in Input:
                self._On_Hide = Input['On_Hide']
                del Input['On_Hide']
            if 'On_Change' in Input:
                self._On_Change = Input['On_Change']
                del Input['On_Change']
            if self._Input is not None and len(Input) > 0:
                Event_Bind(self._Input, **Input)
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Bind -> {E}')

    def Config_Get(self, *Input):
        try:
            Return = {}
            for Each in self._Config:
                if Each in Input:
                    Return[Each] = getattr(self, '_' + Each)
            return Return
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config_Get -> {E}')

    def Config(self, **Input):
        try:
            Run = False
            for Each in self._Config:
                if Each in Input:
                    setattr(self, '_' + Each, Input[Each])
                    Run = True
            if 'Value' in Input:
                self._Value = '' if Input['Value'] is None else str(Input['Value'])
            if self._Initialized and Run:
                self._Apply()
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Config -> {E}')

    def Move(self, Left=None, Top=None):
        try:
            if Left is not None:
                self._Left = (self._Left or 0) + Left
            if Top is not None:
                self._Top = (self._Top or 0) + Top
            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Move -> {E}')

    def Center(self, Left=None, Top=None):
        try:
            Width = self._Width or 0
            Height = self._Height or 0
            if Left is not None:
                self._Left = Left - Width / 2
            if Top is not None:
                self._Top = Top - Height / 2
            if Left is not None or Top is not None:
                self._Mode = 'Place'
                self._Apply()
            return [self._Left + Width / 2, self._Top + Height / 2]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Center -> {E}')

    def Position(self, Left=None, Top=None, Right=None, Bottom=None):
        try:
            if Left is not None:
                self._Left = Left
            if Top is not None:
                self._Top = Top
            if Right is not None:
                self._Right = Right
            if Bottom is not None:
                self._Bottom = Bottom
            if Left is not None or Top is not None or Right is not None or Bottom is not None:
                self._Mode = 'Place'
                self._Apply()
            return [self._Left, self._Top, self._Right, self._Bottom]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Position -> {E}')

    def Size(self, Width=False, Height=False):
        try:
            if Width is not False:
                self._Width = Width
            if Height is not False:
                self._Height = Height
            if Width is not False or Height is not False:
                self._Apply()
            return [self._Width, self._Height]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Size -> {E}')

    def Enlarge(self, Value=None):
        try:
            if Value is not None:
                self._Width = (self._Width or 0) + Value
                self._Height = (self._Height or 0) + Value
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Enlarge -> {E}')

    def Shrink(self, Value=None):
        try:
            if Value is not None:
                self._Width = max(0, (self._Width or 0) - Value)
                self._Height = max(0, (self._Height or 0) - Value)
                self._Apply()
            return True
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Shrink -> {E}')

    def Box(self):
        try:
            return [self._Left, self._Top, self._Width, self._Height]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Box -> {E}')

    def Ratio(self):
        try:
            return [1, 1]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Ratio -> {E}')

    def Locate(self, Width, Height, Left, Top):
        try:
            Width = self._Width * (Width / 100)
            Height = self._Height * (Height / 100)
            Left = self._Width * (Left / 100)
            Top = self._Height * (Top / 100)
            return [Width, Height, Left, Top]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Locate -> {E}')

    def Locate_Reverse(self, Width, Height, Left, Top):
        try:
            Width = round((Width / self._Width) * 100, 3)
            Height = round((Height / self._Height) * 100, 3)
            Left = round((Left / self._Width) * 100, 3)
            Top = round((Top / self._Height) * 100, 3)
            return [Width, Height, Left, Top]
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Locate_Reverse -> {E}')

    def Create(self):
        try:
            if self._Widget is None:
                Parent = self._Get_Parent()
                
                if self._Mode != 'Place':
                    if self._Left is not None or self._Top is not None or self._Right is not None or self._Bottom is not None:
                        self._Mode = 'Place'


                if Parent is not None:
                    with Parent:
                        self._Widget = ui.element('div')
                        self._Widget.style('display: contents')
                        self._Frame = ui.element('div')
                        with self._Frame:
                            self._Row = ui.element('div')
                            with self._Row:
                                self._Input = ui.input(
                                    value=self._Value,
                                    on_change=lambda E: self._Handle_Change(E),
                                )
                                self._Toggle_Button = ui.button(
                                    on_click=lambda: self._Toggle_Password(),
                                )
                else:
                    self._Widget = ui.element('div')
                    self._Widget.style('display: contents')
                    self._Frame = ui.element('div')
                    with self._Frame:
                        self._Row = ui.element('div')
                        with self._Row:
                            self._Input = ui.input(
                                value=self._Value,
                                on_change=lambda E: self._Handle_Change(E),
                            )
                            self._Toggle_Button = ui.button(
                                on_click=lambda: self._Toggle_Password(),
                            )

                self._Frame.on('mouseenter', lambda E: self._Hover_In())
                self._Frame.on('mouseleave', lambda E: self._Hover_Out())

                if hasattr(self._Main, '_Widget') and isinstance(self._Main._Widget, list) and self not in self._Main._Widget:
                    self._Main._Widget.append(self)

                self._Initialized = True

            self._Apply()

            if self._Name:
                self._Main.__dict__[self._Name] = self

            if not self._Display:
                self.Hide()

            return self
        except Exception as E:
            self._GUI.Error(f'{self._Type} -> Create -> {E}')