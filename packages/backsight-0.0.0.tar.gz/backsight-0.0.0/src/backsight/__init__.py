"""Backsight: time-travel debugger for AI agents."""

__version__ = "0.0.0"
