# Backsight

> Time-travel debugger for AI agents. Capture every decision. Replay any path. Fork what should have happened.

**Status: pre-release.** This is a 0.0.0 placeholder. The first usable release is 0.1.0, shipping soon.

For details on the project and the v0.1 roadmap, visit [backsight.dev](https://backsight.dev).

## License

Apache-2.0
