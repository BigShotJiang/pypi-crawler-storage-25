"""Central runtime planner for per-session MCP availability.

This module is the single runtime source of truth for what MCP capabilities a new
agent session should receive and what upstream MCP environment must be injected
into the Ralph MCP subprocess for that session.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from ralph.config.enums import AgentTransport
from ralph.config.mcp_loader import load_mcp_config
from ralph.mcp.protocol.capability_mapping import DrainClass, drain_class_for_session
from ralph.mcp.transport.claude import load_existing_claude_upstream_servers
from ralph.mcp.transport.common import (
    mcp_toml_as_upstreams,
    merge_mcp_toml_into_upstreams,
    set_upstream_mcp_config,
)

_CAPABILITY_PRESETS: dict[str, frozenset[str]] = {
    "planning": frozenset(),
    "review": frozenset({"run.report_progress"}),
    "analysis": frozenset({"process.exec_bounded", "run.report_progress"}),
    "commit": frozenset({"run.report_progress"}),
}

if TYPE_CHECKING:
    from pathlib import Path

    from ralph.policy.models import AgentsPolicy


@dataclass(frozen=True)
class SessionMcpPlan:
    capabilities: frozenset[str]
    server_env: dict[str, str] | None = None


def build_session_mcp_plan(
    *,
    transport: AgentTransport | None,
    drain: str,
    workspace_path: Path | None,
    agents_policy: AgentsPolicy | None = None,
) -> SessionMcpPlan:
    """Build the runtime MCP plan for a new agent session.

    The result captures both session capability grants and any upstream MCP
    environment that must be present in the Ralph MCP subprocess so its runtime
    tool registry matches what the agent is expected to see.
    """

    capabilities = _base_capabilities_for_drain(drain, agents_policy)
    mcp_config = load_mcp_config(
        config_path=(
            (workspace_path / ".agent" / "mcp.toml")
            if workspace_path is not None
            else None
        )
    )

    capability_cls = _resolve_capability_cls(drain, agents_policy)
    is_commit = capability_cls == DrainClass.COMMIT

    if mcp_config.web_search.enabled and not is_commit:
        capabilities.add("web.search")
    if mcp_config.web_visit.enabled and not is_commit:
        capabilities.add("web.visit")
    if mcp_config.media.enabled:
        capabilities.add("media.read")

    server_env: dict[str, str] = {}
    upstreams = mcp_toml_as_upstreams(workspace_path)
    if transport == AgentTransport.CLAUDE:
        upstreams = merge_mcp_toml_into_upstreams(
            load_existing_claude_upstream_servers(workspace_path),
            upstreams,
        )
        set_upstream_mcp_config(server_env, upstreams)

    if upstreams and not is_commit:
        capabilities.add("upstream.tool_use")

    return SessionMcpPlan(
        capabilities=frozenset(capabilities),
        server_env=server_env or None,
    )


def _resolve_capability_cls(
    drain: str,
    agents_policy: AgentsPolicy | None = None,
) -> DrainClass:
    """Resolve the effective capability class for a drain.

    Uses capability_class from agents_policy when declared, falling back to
    drain_class. This is the single source of truth for MCP surface selection.
    """
    drain_class = drain_class_for_session(drain, agents_policy)
    if agents_policy is not None:
        drain_cfg = agents_policy.agent_drains.get(drain)
        if drain_cfg is not None and drain_cfg.capability_class is not None:
            return DrainClass(drain_cfg.capability_class)
    return drain_class


_DEVELOPMENT_EXTRA: frozenset[str] = frozenset({
    "workspace.write_ephemeral",
    "workspace.write_tracked",
    "workspace.edit",
    "workspace.delete",
    "process.exec_bounded",
    "run.report_progress",
    "env.read",
})


def _base_capabilities_for_drain(
    drain: str,
    agents_policy: AgentsPolicy | None = None,
) -> set[str]:
    capability_cls = _resolve_capability_cls(drain, agents_policy)

    base = {
        "workspace.read",
        "git.status_read",
        "git.diff_read",
        "artifact.submit",
        "workspace.metadata_read",
    }

    cls_value = capability_cls.value
    if cls_value in _CAPABILITY_PRESETS:
        return base | _CAPABILITY_PRESETS[cls_value]
    # development and fix classes: full write surface
    return base | _DEVELOPMENT_EXTRA


__all__ = ["SessionMcpPlan", "build_session_mcp_plan"]
