"""Test doubles for process-lifecycle tests.

Provides deterministic fake subprocess and psutil implementations that let tests
drive process state transitions without spawning real OS processes.
"""

from __future__ import annotations

import asyncio
import subprocess
from dataclasses import dataclass, field
from typing import IO, TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Iterator, Sequence
    from typing import Protocol

    class _SyncFactoryCallable(Protocol):
        def __call__(  # noqa: PLR0913
            self,
            command: Sequence[str],
            *,
            cwd: str | None,
            env: dict[str, str] | None,
            stdin: int | None,
            stdout: int | None,
            stderr: int | None,
            start_new_session: bool,
            text: bool,
        ) -> FakePopen: ...

    class _AsyncFactoryCallable(Protocol):
        async def __call__(  # noqa: PLR0913
            self,
            command: Sequence[str],
            *,
            cwd: str | None,
            env: dict[str, str] | None,
            stdin: int | None,
            stdout: int | None,
            stderr: int | None,
            start_new_session: bool,
        ) -> FakeAsyncProcess: ...


@dataclass
class FakePsutilProcess:
    """Minimal psutil.Process-like fake for descendant_snapshot tests."""

    pid: int
    _running: bool = True
    _status: str = "sleeping"
    _create_time: float = 0.0
    _terminated: bool = False
    _killed: bool = False
    _children: list["FakePsutilProcess"] = field(default_factory=list)  # noqa: UP037

    def is_running(self) -> bool:
        return (
            self._running
            and not self._terminated
            and not self._killed
            and self.status() != "zombie"
        )

    def status(self) -> str:
        if self._killed:
            return "zombie"
        if self._terminated:
            return "zombie"
        return self._status

    def create_time(self) -> float:
        return self._create_time

    def children(self, recursive: bool = False) -> list["FakePsutilProcess"]:  # noqa: UP037
        return self._children

    def terminate(self) -> None:
        self._terminated = True

    def kill(self) -> None:
        self._killed = True


class FakePsutil:
    """Fake psutil module for testing without real process operations.

    Simulates psutil.Process() and psutil.wait_procs() for deterministic
    testing of process tree operations.
    """

    NoSuchProcess = Exception
    AccessDenied = Exception

    def __init__(self) -> None:
        self._processes: dict[int, FakePsutilProcess] = {}
        self._next_pid = 1

    def Process(self, pid: int) -> FakePsutilProcess:  # noqa: N802
        """Mimics psutil.Process()."""
        if pid not in self._processes:
            self._processes[pid] = FakePsutilProcess(pid=pid)
        return self._processes[pid]

    def wait_procs(
        self,
        procs: list[FakePsutilProcess],
        timeout: float | None = None,
    ) -> tuple[list[FakePsutilProcess], list[FakePsutilProcess]]:
        """Simulate wait_procs - processes that were terminate()'d are considered dead."""
        dead = []
        alive = []
        for p in procs:
            if p._terminated or p._killed:
                dead.append(p)
            else:
                alive.append(p)
        return dead, alive


class FakePopen:
    """Minimal subprocess.Popen-like fake for testing.

    Provides only the interface that ProcessManager/ManagedProcess uses.
    Tests control state transitions directly.
    """

    def __init__(  # noqa: PLR0913
        self,
        pid: int,
        *,
        returncode: int | None = None,
        terminated: bool = False,
        killed: bool = False,
        stdin: IO[bytes] | None = None,
        stdout: IO[bytes] | None = None,
        stderr: IO[bytes] | None = None,
    ) -> None:
        self.pid = pid
        self._returncode = returncode
        self._terminated = terminated
        self._killed = killed
        self.stdin = stdin
        self.stdout = stdout
        self.stderr = stderr

    @property
    def returncode(self) -> int | None:
        return self._returncode

    def poll(self) -> int | None:
        return self._returncode

    def wait(self, timeout: float | None = None) -> int:
        return self._returncode if self._returncode is not None else 0

    def communicate(
        self, input: bytes | None = None, timeout: float | None = None
    ) -> tuple[bytes | None, bytes | None]:
        return None, None

    def terminate(self) -> None:
        self._terminated = True

    def kill(self) -> None:
        self._killed = True


class FakeAsyncProcess:
    """Minimal asyncio.subprocess.Process-like fake for testing."""

    _stdin: "asyncio.StreamWriter | None"  # noqa: UP037
    _stdout: "asyncio.StreamReader | None"  # noqa: UP037
    _stderr: "asyncio.StreamReader | None"  # noqa: UP037

    def __init__(  # noqa: PLR0913
        self,
        pid: int,
        *,
        returncode: int | None = None,
        terminated: bool = False,
        killed: bool = False,
        stdin: "asyncio.StreamWriter | None" = None,  # noqa: UP037
        stdout: "asyncio.StreamReader | None" = None,  # noqa: UP037
        stderr: "asyncio.StreamReader | None" = None,  # noqa: UP037
    ) -> None:
        self.pid = pid
        self._returncode = returncode
        self._terminated = terminated
        self._killed = killed
        self._stdin = stdin
        self._stdout = stdout
        self._stderr = stderr

    @property
    def returncode(self) -> int | None:
        return self._returncode

    async def wait(self) -> int:
        return self._returncode if self._returncode is not None else 0

    async def communicate(self, input: bytes | None = None) -> tuple[bytes, bytes]:
        return b"", b""


class FakeTimeoutPopen:
    """FakePopen variant that raises TimeoutExpired on first communicate() with timeout.

    Simulates a slow process for testing timeout-handling code paths without
    spawning real subprocesses or sleeping.

    On the first communicate(timeout=T) call, raises subprocess.TimeoutExpired.
    On subsequent communicate() calls (after terminate()), returns partial_output.
    """

    def __init__(
        self,
        pid: int,
        *,
        partial_stdout: bytes = b"",
    ) -> None:
        self.pid = pid
        self._returncode: int | None = None
        self._terminated = False
        self._killed = False
        self._partial_stdout = partial_stdout
        self._communicate_count = 0
        self.stdin: IO[bytes] | None = None
        self.stdout: IO[bytes] | None = None
        self.stderr: IO[bytes] | None = None

    @property
    def returncode(self) -> int | None:
        return self._returncode

    def poll(self) -> int | None:
        return self._returncode

    def wait(self, timeout: float | None = None) -> int:
        return self._returncode if self._returncode is not None else 0

    def communicate(
        self, input: bytes | None = None, timeout: float | None = None
    ) -> tuple[bytes, bytes]:
        self._communicate_count += 1
        if self._communicate_count == 1 and timeout is not None:
            raise subprocess.TimeoutExpired(
                cmd="fake-process",
                timeout=timeout,
                output=self._partial_stdout,
                stderr=b"",
            )
        return self._partial_stdout, b""

    def terminate(self) -> None:
        self._terminated = True

    def kill(self) -> None:
        self._killed = True


class FakeControllableAsyncProcess:
    """Async process fake with controllable stdout and completion.

    Suitable for testing code paths that need a process to stay running while
    assertions are made, then complete deterministically — without spawning real
    subprocesses or using real wall-clock sleeps.

    Usage::

        completion = asyncio.Event()
        proc = FakeControllableAsyncProcess(
            pid=1,
            stdout_data=b"ready\n",
            completion_event=completion,
        )
        # ... start task that reads proc.stdout and waits on proc.wait() ...
        # when you're done: completion.set() to let it finish
    """

    def __init__(
        self,
        pid: int,
        *,
        stdout_data: bytes = b"",
        returncode: int = 0,
        completion_event: asyncio.Event | None = None,
    ) -> None:
        self.pid = pid
        self._final_returncode = returncode
        self._returncode: int | None = None
        self._completion_event = completion_event or asyncio.Event()
        self._stdout: asyncio.StreamReader = asyncio.StreamReader()
        if stdout_data:
            self._stdout.feed_data(stdout_data)
            self._stdout.feed_eof()
        else:
            self._stdout.feed_eof()
        self.stdin = None
        self.stderr = None

    @property
    def stdout(self) -> asyncio.StreamReader:
        return self._stdout

    @property
    def returncode(self) -> int | None:
        return self._returncode

    async def wait(self) -> int:
        await self._completion_event.wait()
        self._returncode = self._final_returncode
        return self._final_returncode

    async def communicate(self, input: bytes | None = None) -> tuple[bytes, bytes]:
        await self._completion_event.wait()
        return b"", b""

    def terminate(self) -> None:
        self._returncode = self._final_returncode
        self._completion_event.set()

    def kill(self) -> None:
        self._returncode = self._final_returncode
        self._completion_event.set()


def make_sync_process_factory(
    pids: Iterator[int],
    *,
    returncode: int | None = None,
    terminated: bool = False,
    killed: bool = False,
) -> _SyncFactoryCallable:
    """Create a sync process factory that generates FakePopen with sequential PIDs.

    Args:
        pids: Iterator that returns the next PID (e.g., itertools.count(1))
        returncode: Set returncode on all created processes
        terminated: Set terminated flag on all created processes
        killed: Set killed flag on all created processes
    """

    def factory(  # noqa: PLR0913
        command: "Sequence[str]",  # noqa: UP037
        *,
        cwd: str | None,
        env: dict[str, str] | None,
        stdin: int | None,
        stdout: int | None,
        stderr: int | None,
        start_new_session: bool,
        text: bool,
    ) -> FakePopen:
        return FakePopen(
            pid=next(pids),
            returncode=returncode,
            terminated=terminated,
            killed=killed,
        )

    return factory


def make_async_process_factory(
    pids: Iterator[int],
    *,
    returncode: int | None = None,
) -> _AsyncFactoryCallable:
    """Create an async process factory that generates FakeAsyncProcess with sequential PIDs."""

    async def factory(  # noqa: PLR0913
        command: "Sequence[str]",  # noqa: UP037
        *,
        cwd: str | None,
        env: dict[str, str] | None,
        stdin: int | None,
        stdout: int | None,
        stderr: int | None,
        start_new_session: bool,
    ) -> FakeAsyncProcess:
        return FakeAsyncProcess(pid=next(pids), returncode=returncode)

    return factory


def make_psutil_factory(
    processes: dict[int, FakePsutilProcess],
) -> FakePsutil:
    """Create a FakePsutil instance pre-populated with specific processes.

    Args:
        processes: Dict mapping PIDs to FakePsutilProcess instances
    """
    fake = FakePsutil()
    fake._processes = dict(processes)
    return fake


__all__ = [
    "FakeAsyncProcess",
    "FakeControllableAsyncProcess",
    "FakePopen",
    "FakePsutil",
    "FakePsutilProcess",
    "FakeTimeoutPopen",
    "make_async_process_factory",
    "make_psutil_factory",
    "make_sync_process_factory",
]
