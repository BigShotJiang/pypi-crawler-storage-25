# Changelog

All notable changes to the `synapsai` Python package are documented here.

---

## [0.3.0] — 2026-05-16

### Added

- **`client.verify.claim_with_evidence(claim, ...)`** — fast-path text claim verification via Claude AI. Submits to `/v1/verify/claim`, polls until evidence is ready (~5–15 s), and returns a `ClaimEvidence` dataclass. Full async variant available on `AsyncSynapsAI`.
- **`ClaimEvidence`** — dataclass: `claim_id`, `claim`, `claim_hash`, `claimant`, `verified`, `reward`, `status`, `verification_status`, `verdict`, `confidence`, `ai_assessment`, `web_sources`, `checks`, `verified_at`, `tx_hash`, `explorer`.
- **`ClaimVerdict`** — `Literal["SUPPORTED", "CONTRADICTED", "UNVERIFIABLE", "INCONCLUSIVE"]`.
- **`AIAssessment`** — dataclass: `verdict`, `confidence`, `reasoning`, `key_facts`, `caveats`.
- **`EvidenceSource`** — dataclass: `title`, `url`, `snippet`.
- **`EvidenceCheck`** — dataclass: `name`, `passed`, `detail`.
- All new types exported from top-level `synapsai` package.

### Architectural note

Two text claim paths coexist:

| Method | Endpoint | Speed | Checks |
|--------|----------|-------|--------|
| `verify.claim()` | `POST /v1/verify` | async, poll `verified` | 9-check oracle network |
| `verify.claim_with_evidence()` | `POST /v1/verify/claim` | ~5–15 s | Claude AI + web search |

### Unchanged

No existing methods, types, or signatures were modified.

---

## [0.2.0] — 2026-05-15

### Added

- **`client.verify.video(video, ...)`** — end-to-end video deepfake detection. Accepts `Path`, `str`, `bytes`, or any file-like object. Handles upload → analyze → poll internally behind a single blocking call (sync) or `await` (async).
- **`AsyncSynapsAI.verify.video(video, ...)`** — async variant with `asyncio.sleep` polling.
- **`VideoVerifyResult`** — dataclass result: `job_id`, `verdict`, `confidence`, `frames_analyzed`, `tx_hash`, `explorer`, `raw_scores`.
- **`VideoRawScores`** — dataclass: `hive_ai_generated`, `hive_deepfake`, `frames_analyzed`.
- Both types exported from the top-level `synapsai` package.

### Unchanged

No existing methods, types, or signatures were modified. Users on `0.1.0` can upgrade without any code changes.

---

## [0.1.0] — 2026-05-13

Initial public release.

- `client.verify.claim()` — submit a text claim to ProofOfImpact on Sepolia
- `client.verify.get()` — poll claim verification status
- `client.verify.image()` — image deepfake + AI-generation detection
- `client.verify.document()` — document AI-content detection with on-chain hash commit
- `client.verify.luxury()` — luxury goods authentication
- `client.verify.rx()` — pharmaceutical authentication
- `client.verify.credential()` — academic credential verification
- `client.verify.art()`, `.sneakers()`, `.cards()`, `.wine()`, `.ticket()`, `.jewelry()`, `.electronics()` — category-specific visual authentication
- `client.trust.get()` — on-chain trust score lookup
- `client.account.info()`, `.usage()` — API key info and usage
- `client.webhooks.*` — webhook CRUD
- `client.health.check()` — API health
- Full async support via `AsyncSynapsAI`
