"""Tests for webhooks resource — mirrors test/webhooks.test.ts."""
import hashlib
import hmac

import pytest
from pytest_httpx import HTTPXMock

from .conftest import BASE, WEBHOOK_CREATE_RAW, HISTORY_PAGE


WEBHOOK_LIST_RAW = {
    "webhooks": [
        {
            "id": "wh_abc123",
            "url": "https://example.com/hooks",
            "events": ["verification.completed"],
            "created": "2026-05-12T00:00:00.000Z",
        }
    ]
}


def _make_signature(secret: str, payload: str) -> str:
    return "sha256=" + hmac.new(secret.encode(), payload.encode(), hashlib.sha256).hexdigest()


# ─── webhooks.create() ───────────────────────────────────────────────────────

def test_create_normalizes_webhook_id(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(method="POST", url=f"{BASE}/v1/webhooks", json=WEBHOOK_CREATE_RAW)
    res = client.webhooks.create("https://example.com/hooks", ["verification.completed"])
    assert res.id == "wh_abc123"
    assert res.secret == "whsec_deadbeef"
    assert res.url == "https://example.com/hooks"
    assert res.created_at is not None


# ─── webhooks.list() ─────────────────────────────────────────────────────────

def test_list_returns_normalized_webhooks(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(method="GET", url=f"{BASE}/v1/webhooks", json=WEBHOOK_LIST_RAW)
    result = client.webhooks.list()
    assert len(result) == 1
    assert result[0].id == "wh_abc123"
    assert result[0].created_at is not None


# ─── webhooks.delete() ───────────────────────────────────────────────────────

def test_delete_resolves(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(method="DELETE", url=f"{BASE}/v1/webhooks/wh_abc123", json={"deleted": True})
    client.webhooks.delete("wh_abc123")  # no exception = pass


# ─── webhooks.deliveries() ───────────────────────────────────────────────────

def test_deliveries_returns_list(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(method="GET", url=f"{BASE}/v1/webhooks/deliveries", json={"deliveries": []})
    result = client.webhooks.deliveries()
    assert isinstance(result, list)


# ─── webhooks.test() ─────────────────────────────────────────────────────────

def test_test_resolves(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(method="POST", url=f"{BASE}/v1/webhooks/wh_abc123/test", json={"sent": True})
    client.webhooks.test("wh_abc123")  # no exception = pass


# ─── webhooks.verify_signature() ─────────────────────────────────────────────

SECRET = "my-webhook-secret"
PAYLOAD = '{"event": "verification.completed", "data": {}}'


def test_valid_signature_returns_true(client):
    sig = _make_signature(SECRET, PAYLOAD)
    assert client.webhooks.verify_signature(PAYLOAD, sig, SECRET) is True


def test_tampered_payload_returns_false(client):
    sig = _make_signature(SECRET, PAYLOAD)
    assert client.webhooks.verify_signature(PAYLOAD + "tampered", sig, SECRET) is False


def test_wrong_secret_returns_false(client):
    sig = _make_signature("wrong-secret", PAYLOAD)
    assert client.webhooks.verify_signature(PAYLOAD, sig, SECRET) is False


def test_handles_sha256_prefix(client):
    sig = _make_signature(SECRET, PAYLOAD)
    sig_hex = sig[len("sha256="):]  # strip prefix
    assert client.webhooks.verify_signature(PAYLOAD, sig_hex, SECRET) is True


def test_accepts_bytes_payload(client):
    sig = _make_signature(SECRET, PAYLOAD)
    assert client.webhooks.verify_signature(PAYLOAD.encode(), sig, SECRET) is True
