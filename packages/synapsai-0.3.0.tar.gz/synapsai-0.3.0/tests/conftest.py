"""Shared fixtures and response stubs — mirrors test/setup.ts."""
import pytest
from synapsai import SynapsAI

BASE = "https://api.synapsai.org"

# ─── Fixture data (mirrors TS test/setup.ts) ─────────────────────────────────

CLAIM_RESULT = {
    "requestId": "uuid-1",
    "claimId": 94,
    "txHash": "0xabc123",
    "status": "submitted",
    "impactType": "research_dataset",
    "impactValue": 1,
    "poll": "/v1/verify/94",
    "explorer": "https://sepolia.etherscan.io/tx/0xabc123",
}

CLAIM_STATUS = {
    "claimId": "94",
    "claimant": "0xOwner",
    "impactType": "research_dataset",
    "impactValue": "1",
    "verified": True,
    "reward": "10",
    "status": "verified",
}

IMAGE_RESULT = {
    "requestId": "uuid-2",
    "claimId": 95,
    "verdict": "AUTHENTIC",
    "verdictReason": "All forensic checks clean.",
    "authenticityScore": 91,
    "rawScores": {
        "hiveAiGenerated": 0.02,
        "hiveDeepfake": 0.01,
        "hiveTopGenerators": [],
        "elaEdited": False,
        "elaSizeRatio": 0.21,
        "exifAbsent": False,
        "exifInconsistent": False,
        "claudeAuthenticityScore": 88,
    },
    "thresholdsUsed": {"hiveAiGenerated": 0.9, "hiveDeepfake": 0.9},
    "imageHash": "0xhash",
    "txHash": "0xdef456",
    "flags": [],
    "claimsExtracted": [],
    "timestamp": "2026-05-12T00:00:00.000Z",
}

DOCUMENT_RESULT = {
    "requestId": "uuid-doc",
    "verdict": "AUTHENTIC",
    "confidence": 0.88,
    "documentHash": "0xhash",
    "txHash": "0xdoc",
    "explorer": None,
    "checks": [{"name": "Text Extraction", "passed": True, "detail": "1842 chars"}],
    "aiDetection": {"isAiGenerated": False, "confidence": 0.1, "detail": "Human likely"},
}

LUXURY_RESULT = {
    "requestId": "uuid-3",
    "claimId": 96,
    "brand": "Rolex",
    "model": "Submariner",
    "verdict": "AUTHENTIC",
    "verdictReason": "All authentication markers consistent.",
    "confidence": 92,
    "authenticityScore": 90,
    "indicators": {"authentic": ["Crown logo sharp"], "suspicious": []},
    "flags": [],
    "serialFormat": "valid",
    "finishing": "high",
    "summary": "Appears genuine.",
    "photoAuthenticity": {"aiGeneratedScore": 0.01, "isAIGenerated": False},
    "imageHashes": ["0xhash1"],
    "imagesAnalyzed": 1,
    "txHash": "0xghi789",
    "explorer": "https://sepolia.etherscan.io/tx/0xghi789",
    "timestamp": "2026-05-12T00:00:00.000Z",
}

TRUST_RESULT = {
    "address": "0xOwner",
    "trustScore": 590,
    "neutral": 500,
    "range": "0-1000",
    "interpretation": "trusted",
    "formula": "TrustScore(t) = 500 + (TrustScore(t-1) - 500) × e^(-λt)",
}

KEY_INFO = {
    "name": "Jane Smith",
    "email": "jane@insurer.com",
    "company": "Acme Insurance",
    "plan": "growth",
    "createdAt": "2026-05-01T00:00:00.000Z",
    "keyPreview": "taas_ab...xy",
}

WEBHOOK_CREATE_RAW = {
    "webhookId": "wh_abc123",
    "url": "https://example.com/hooks",
    "events": ["verification.completed"],
    "secret": "whsec_deadbeef",
    "created": "2026-05-12T00:00:00.000Z",
}

HISTORY_PAGE = {
    "verifications": [
        {
            "ts": 1747000000000,
            "type": "image",
            "requestId": "uuid-2",
            "verdict": "AUTHENTIC",
            "authenticityScore": 91,
            "txHash": "0xdef456",
            "claimId": None,
            "verdictReason": "All checks clean.",
        }
    ],
    "total": 1,
    "offset": 0,
    "limit": 20,
    "hasMore": False,
}

HEALTH_RESULT = {
    "status": "ok",
    "chain": "sepolia",
    "block": 10841774,
    "claims": 155,
    "signer": "0xF658",
    "writeEnabled": True,
    "contracts": {"proofOfImpact": "0x4cBd77"},
}


@pytest.fixture
def client():
    return SynapsAI(api_key="taas_test", base_url=BASE)
