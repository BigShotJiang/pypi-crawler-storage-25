"""Tests for account resource — mirrors test/account.test.ts."""
import re
from datetime import datetime, timezone

import pytest
from pytest_httpx import HTTPXMock

from .conftest import BASE, KEY_INFO, HISTORY_PAGE


USAGE_RESULT = {
    "key": "taas_ab...xy",
    "currentMonth": "2026-05",
    "totalCalls": 42,
    "byEndpoint": {"/v1/verify/image": 42},
    "generatedAt": "2026-05-12T00:00:00.000Z",
}


def test_key_info(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(method="GET", url=f"{BASE}/v1/key-info", json=KEY_INFO)
    info = client.account.key_info()
    assert info.name == KEY_INFO["name"]
    assert info.company == KEY_INFO["company"]
    assert info.plan == "growth"
    assert "..." in info.key_preview


def test_usage(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(method="GET", url=f"{BASE}/v1/usage", json=USAGE_RESULT)
    usage = client.account.usage()
    assert usage.total_calls == 42
    assert usage.by_endpoint["/v1/verify/image"] == 42
    assert usage.current_month == "2026-05"


def test_history_returns_page(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(method="GET", url=re.compile(rf"{re.escape(BASE)}/v1/history"), json=HISTORY_PAGE)
    page = client.account.history(type="image", limit=20)
    assert page.total == 1
    assert page.has_more is False
    assert page.verifications[0].verdict == "AUTHENTIC"
    assert page.verifications[0].authenticity_score == 91


def test_history_datetime_from(client, httpx_mock: HTTPXMock):
    captured = {}

    def handler(request):
        captured["url"] = str(request.url)
        import httpx as _httpx
        return _httpx.Response(200, json=HISTORY_PAGE)

    httpx_mock.add_callback(handler, method="GET", url=re.compile(rf"{re.escape(BASE)}/v1/history"))
    dt = datetime(2026, 5, 1, 0, 0, 0, tzinfo=timezone.utc)
    client.account.history(from_=dt, limit=10)
    assert "from=" in captured["url"]
    assert "2026-05-01" in captured["url"]
    assert "limit=10" in captured["url"]


def test_history_unix_ms_from(client, httpx_mock: HTTPXMock):
    captured = {}

    def handler(request):
        captured["url"] = str(request.url)
        import httpx as _httpx
        return _httpx.Response(200, json=HISTORY_PAGE)

    httpx_mock.add_callback(handler, method="GET", url=re.compile(rf"{re.escape(BASE)}/v1/history"))
    client.account.history(from_=1746316800000)
    assert "from=" in captured["url"]
