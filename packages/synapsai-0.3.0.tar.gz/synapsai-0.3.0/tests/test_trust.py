"""Tests for trust resource — mirrors test/trust.test.ts."""
from pytest_httpx import HTTPXMock

from .conftest import BASE, TRUST_RESULT


def test_trust_get(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(method="GET", url=f"{BASE}/v1/trust/0xOwner", json=TRUST_RESULT)
    res = client.trust.get("0xOwner")
    assert res.trust_score == 590
    assert res.neutral == 500
    assert res.interpretation == "trusted"
    assert "e^" in res.formula


def test_trust_batch(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(method="POST", url=f"{BASE}/v1/trust/batch", json=[TRUST_RESULT])
    results = client.trust.batch(["0xOwner", "0xOther"])
    assert isinstance(results, list)
    assert results[0].trust_score == TRUST_RESULT["trustScore"]
