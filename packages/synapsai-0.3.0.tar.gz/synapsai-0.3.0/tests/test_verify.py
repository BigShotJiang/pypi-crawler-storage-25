"""Tests for verify resource — mirrors test/verify.test.ts."""
import pytest
import httpx
from pytest_httpx import HTTPXMock

from synapsai import (
    SynapsAI,
    AuthError,
    RateLimitError,
    ValidationError,
    ServerError,
)
from .conftest import (
    BASE,
    CLAIM_RESULT,
    CLAIM_STATUS,
    IMAGE_RESULT,
    DOCUMENT_RESULT,
    LUXURY_RESULT,
)


# ─── verify.claim() ──────────────────────────────────────────────────────────

def test_claim_submit(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(method="POST", url=f"{BASE}/v1/verify", json=CLAIM_RESULT, status_code=202)
    res = client.verify.claim("Company X reduced CO2 by 500 tons")
    assert res.claim_id == CLAIM_RESULT["claimId"]
    assert res.status == "submitted"
    assert res.tx_hash == CLAIM_RESULT["txHash"]
    assert res.poll == "/v1/verify/94"


def test_claim_with_content_hash(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(method="POST", url=f"{BASE}/v1/verify", json=CLAIM_RESULT, status_code=202)
    res = client.verify.claim(content_hash="0x" + "a" * 64)
    assert res.request_id is not None


# ─── verify.get() ────────────────────────────────────────────────────────────

def test_claim_get(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(method="GET", url=f"{BASE}/v1/verify/94", json=CLAIM_STATUS)
    res = client.verify.get(94)
    assert res.verified is True
    assert res.status == "verified"
    assert res.claim_id == CLAIM_STATUS["claimId"]


# ─── verify.image() ──────────────────────────────────────────────────────────

def test_image_verify(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(method="POST", url=f"{BASE}/v1/verify/image", json=IMAGE_RESULT)
    res = client.verify.image(b"fake-image-bytes", claim="Product photo")
    assert res.verdict == "AUTHENTIC"
    assert res.authenticity_score == 91
    assert res.raw_scores.hive_ai_generated == 0.02
    assert res.tx_hash == IMAGE_RESULT["txHash"]


# ─── verify.document() ───────────────────────────────────────────────────────

def test_document_verify(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(method="POST", url=f"{BASE}/v1/verify/document", json=DOCUMENT_RESULT)
    res = client.verify.document(b"%PDF-1.4 fake pdf")
    assert res.verdict == "AUTHENTIC"
    assert res.document_hash is not None
    assert len(res.checks) > 0
    assert res.ai_detection.is_ai_generated is False


# ─── verify.luxury() ─────────────────────────────────────────────────────────

def test_luxury_verify(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(method="POST", url=f"{BASE}/v1/verify/luxury", json=LUXURY_RESULT)
    res = client.verify.luxury(b"fake-image", brand="Rolex", model="Submariner")
    assert res.verdict == LUXURY_RESULT["verdict"]
    assert res.extra["brand"] == "Rolex"
    assert res.confidence == 92
    assert res.extra["serialFormat"] == "valid"


def test_luxury_multiple_images(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(method="POST", url=f"{BASE}/v1/verify/luxury", json=LUXURY_RESULT)
    res = client.verify.luxury([b"img1", b"img2"])
    assert res.verdict is not None


# ─── Visual auth endpoints ────────────────────────────────────────────────────

@pytest.mark.parametrize("method,path,kwargs", [
    ("rx",          "rx",          {"drug_name": "Advil"}),
    ("credential",  "credential",  {"credential_type": "degree"}),
    ("art",         "art",         {"artist": "Monet"}),
    ("sneakers",    "sneakers",    {"brand": "Nike"}),
    ("cards",       "cards",       {"card_type": "Pokemon"}),
    ("wine",        "wine",        {"producer": "Château Pétrus"}),
    ("ticket",      "ticket",      {"event": "Concert"}),
    ("jewelry",     "jewelry",     {"metal": "gold"}),
    ("electronics", "electronics", {"brand": "Apple"}),
])
def test_visual_auth_endpoints(client, httpx_mock: HTTPXMock, method, path, kwargs):
    httpx_mock.add_response(method="POST", url=f"{BASE}/v1/verify/{path}", json=LUXURY_RESULT)
    res = getattr(client.verify, method)(b"fake-image", **kwargs)
    assert res.verdict is not None
    assert isinstance(res.authenticity_score, int)


# ─── verify.video() ──────────────────────────────────────────────────────────

_VIDEO_UPLOAD_RESP = {
    "jobId": "vid_abc123",
    "uploadUrl": "https://r2.example.com/presigned/vid_abc123",
    "contentType": "video/mp4",
}

_VIDEO_JOB_RESULT = {
    "jobId": "vid_abc123",
    "status": "complete",
    "verdict": "LIKELY_AUTHENTIC",
    "verdictLabel": "Likely Authentic",
    "confidence": 72,
    "summary": "12 frames analyzed. No manipulation detected.",
    "rawScores": {
        "avgAiGenerated": 0.12,
        "avgDeepfake": 0.08,
        "maxAiGenerated": 0.23,
        "maxDeepfake": 0.15,
        "flaggedFrames": 0,
    },
    "framesAnalyzed": 12,
    "durationSecs": 118,
    "escalated": False,
    "txHash": "0xvid123",
    "explorer": "https://sepolia.etherscan.io/tx/0xvid123",
    "claim": None,
    "billingType": "per_call",
    "completedAt": "2026-05-13T00:00:00.000Z",
}


def test_video_verify(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(method="POST", url=f"{BASE}/v1/verify/video/upload-url", json=_VIDEO_UPLOAD_RESP)
    httpx_mock.add_response(method="PUT", url=_VIDEO_UPLOAD_RESP["uploadUrl"], status_code=200)
    httpx_mock.add_response(method="POST", url=f"{BASE}/v1/verify/video/vid_abc123/analyze", status_code=202)
    httpx_mock.add_response(method="GET", url=f"{BASE}/v1/verify/video/vid_abc123", json=_VIDEO_JOB_RESULT)

    res = client.verify.video(b"fake-video-bytes", filename="clip.mp4", poll_interval_ms=0)
    assert res.job_id == "vid_abc123"
    assert res.verdict == "LIKELY_AUTHENTIC"
    assert res.confidence == 72
    assert res.frames_analyzed == 12
    assert res.raw_scores is not None
    assert res.raw_scores.avg_ai_generated == 0.12
    assert res.escalated is False
    assert res.billing_type == "per_call"


def test_video_stub_raises_server_error(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST", url=f"{BASE}/v1/verify/video/upload-url",
        json={"_stub": True, "_setup": "Set R2_* env vars."},
    )
    with pytest.raises(ServerError) as exc_info:
        client.verify.video(b"fake", filename="clip.mp4")
    assert "R2 storage not configured" in str(exc_info.value)
    assert exc_info.value.code == "storage_not_configured"


def test_video_bytes_missing_filename_raises(client):
    with pytest.raises(ValidationError) as exc_info:
        client.verify.video(b"fake-bytes")
    assert exc_info.value.field == "filename"


def test_video_failed_job_raises(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(method="POST", url=f"{BASE}/v1/verify/video/upload-url", json=_VIDEO_UPLOAD_RESP)
    httpx_mock.add_response(method="PUT", url=_VIDEO_UPLOAD_RESP["uploadUrl"], status_code=200)
    httpx_mock.add_response(method="POST", url=f"{BASE}/v1/verify/video/vid_abc123/analyze", status_code=202)
    httpx_mock.add_response(
        method="GET", url=f"{BASE}/v1/verify/video/vid_abc123",
        json={"status": "failed", "summary": "ffmpeg crashed"},
    )
    with pytest.raises(ServerError) as exc_info:
        client.verify.video(b"bad-video", filename="bad.mp4", poll_interval_ms=0)
    assert exc_info.value.code == "processing_failed"


# ─── Error handling ───────────────────────────────────────────────────────────

def test_auth_error_on_401(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST", url=f"{BASE}/v1/verify",
        json={"error": "invalid_api_key"}, status_code=401,
    )
    client = SynapsAI(api_key="bad_key", base_url=BASE)
    with pytest.raises(AuthError):
        client.verify.claim("test")


def test_rate_limit_error_exposes_retry_after(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST", url=f"{BASE}/v1/verify",
        json={"error": "rate_limited", "retryAfter": 30}, status_code=429,
    )
    client = SynapsAI(api_key="taas_test", base_url=BASE)
    with pytest.raises(RateLimitError) as exc_info:
        client.verify.claim("test")
    assert exc_info.value.retry_after_ms == 30_000


def test_validation_error_on_400(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST", url=f"{BASE}/v1/verify",
        json={"error": "missing_params", "message": "Provide content."}, status_code=400,
    )
    client = SynapsAI(api_key="taas_test", base_url=BASE)
    with pytest.raises(ValidationError):
        client.verify.claim()


def test_retries_on_500_and_raises_server_error(httpx_mock: HTTPXMock):
    for _ in range(3):  # 1 initial + 2 retries
        httpx_mock.add_response(
            method="POST", url=f"{BASE}/v1/verify",
            json={"error": "server_error"}, status_code=500,
        )
    client = SynapsAI(api_key="taas_test", base_url=BASE, max_retries=2)
    with pytest.raises(ServerError):
        client.verify.claim("test")
    # all 3 responses consumed → exactly 3 attempts
    assert httpx_mock.get_requests() is not None
