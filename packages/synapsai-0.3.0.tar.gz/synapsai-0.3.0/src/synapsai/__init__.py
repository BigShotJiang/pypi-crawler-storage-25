from __future__ import annotations

import os
from typing import Optional

from ._client import (
    _AsyncTransport,
    _SyncTransport,
    _DEFAULT_BASE_URL,
    _DEFAULT_MAX_RETRIES,
    _DEFAULT_TIMEOUT,
)
from ._errors import (
    AuthError,
    NotFoundError,
    RateLimitError,
    ServerError,
    SynapsAIError,
    ValidationError,
)
from ._types import (
    AIAssessment,
    ClaimEvidence,
    ClaimResult,
    ClaimStatus,
    ClaimVerdict,
    DocumentVerifyResult,
    EvidenceCheck,
    EvidenceSource,
    HealthStatus,
    HistoryEntry,
    HistoryPage,
    ImageVerifyResult,
    KeyInfo,
    ProtocolStats,
    RawImageScores,
    TrustScore,
    UsageStats,
    VideoRawScores,
    VideoVerifyResult,
    VisualAuthResult,
    Webhook,
    WebhookCreateResult,
    WebhookDelivery,
)
from .resources.account import AccountResource, AsyncAccountResource
from .resources.health import AsyncHealthResource, HealthResource
from .resources.trust import AsyncTrustResource, TrustResource
from .resources.verify import AsyncVerifyResource, VerifyResource
from .resources.webhooks import AsyncWebhooksResource, WebhooksResource

__version__ = "0.3.0"
__all__ = [
    "SynapsAI",
    "AsyncSynapsAI",
    # errors
    "SynapsAIError",
    "AuthError",
    "RateLimitError",
    "ValidationError",
    "NotFoundError",
    "ServerError",
    # types
    "ClaimResult",
    "ClaimStatus",
    "ClaimEvidence",
    "ClaimVerdict",
    "AIAssessment",
    "EvidenceSource",
    "EvidenceCheck",
    "ImageVerifyResult",
    "RawImageScores",
    "DocumentVerifyResult",
    "VisualAuthResult",
    "VideoVerifyResult",
    "VideoRawScores",
    "TrustScore",
    "Webhook",
    "WebhookCreateResult",
    "WebhookDelivery",
    "KeyInfo",
    "UsageStats",
    "HistoryEntry",
    "HistoryPage",
    "HealthStatus",
    "ProtocolStats",
]


def _resolve_api_key(api_key: Optional[str]) -> str:
    key = api_key or os.environ.get("SYNAPSAI_API_KEY")
    if not key:
        raise ValueError(
            "No API key provided. Pass api_key= to the constructor "
            "or set the SYNAPSAI_API_KEY environment variable."
        )
    return key


class SynapsAI:
    """Synchronous SynapsAI client.

    Example::

        from synapsai import SynapsAI
        client = SynapsAI(api_key="taas_your_key")
        result = client.verify.image(image=Path("photo.jpg"))
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        base_url: str = _DEFAULT_BASE_URL,
        max_retries: int = _DEFAULT_MAX_RETRIES,
        timeout: float = _DEFAULT_TIMEOUT,
    ) -> None:
        transport = _SyncTransport(
            api_key=_resolve_api_key(api_key),
            base_url=base_url,
            max_retries=max_retries,
            timeout=timeout,
        )
        self.verify = VerifyResource(transport)
        self.trust = TrustResource(transport)
        self.webhooks = WebhooksResource(transport)
        self.account = AccountResource(transport)
        self.health = HealthResource(transport)
        self._transport = transport

    def close(self) -> None:
        self._transport.close()

    def __enter__(self) -> SynapsAI:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()


class AsyncSynapsAI:
    """Asynchronous SynapsAI client for use with asyncio / FastAPI.

    Example::

        from synapsai import AsyncSynapsAI
        async with AsyncSynapsAI(api_key="taas_your_key") as client:
            result = await client.verify.image(image=Path("photo.jpg"))
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        base_url: str = _DEFAULT_BASE_URL,
        max_retries: int = _DEFAULT_MAX_RETRIES,
        timeout: float = _DEFAULT_TIMEOUT,
    ) -> None:
        transport = _AsyncTransport(
            api_key=_resolve_api_key(api_key),
            base_url=base_url,
            max_retries=max_retries,
            timeout=timeout,
        )
        self.verify = AsyncVerifyResource(transport)
        self.trust = AsyncTrustResource(transport)
        self.webhooks = AsyncWebhooksResource(transport)
        self.account = AsyncAccountResource(transport)
        self.health = AsyncHealthResource(transport)
        self._transport = transport

    async def aclose(self) -> None:
        await self._transport.aclose()

    async def __aenter__(self) -> AsyncSynapsAI:
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.aclose()
