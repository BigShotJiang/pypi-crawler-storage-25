from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, BinaryIO, Dict, List, Literal, Optional, Union
from pathlib import Path

# ─── Input types ─────────────────────────────────────────────────────────────

ImageInput = Union[Path, bytes, BinaryIO]
DocumentInput = Union[Path, bytes, BinaryIO]

AuthVerdict = Literal["AUTHENTIC", "COUNTERFEIT", "SUSPICIOUS", "INCONCLUSIVE", "UNVERIFIABLE"]
ImageVerdict = Literal["AI_GENERATED", "DEEPFAKE", "EDITED", "AUTHENTIC", "INCONCLUSIVE"]

# ─── Verify — claim ───────────────────────────────────────────────────────────

@dataclass
class ClaimResult:
    claim_id: int               # on-chain claim ID
    request_id: str
    status: str                 # 'submitted'
    tx_hash: str
    poll: str                   # e.g. '/v1/verify/94'
    explorer: Optional[str]
    impact_type: Optional[str]
    impact_value: Optional[int]

    @classmethod
    def _from_dict(cls, d: Dict[str, Any]) -> ClaimResult:
        return cls(
            claim_id=d["claimId"],
            request_id=d.get("requestId", ""),
            status=d.get("status", "submitted"),
            tx_hash=d.get("txHash", ""),
            poll=d.get("poll", f"/v1/verify/{d.get('claimId')}"),
            explorer=d.get("explorer"),
            impact_type=d.get("impactType"),
            impact_value=d.get("impactValue"),
        )


@dataclass
class ClaimStatus:
    claim_id: str
    claimant: str
    impact_type: str
    impact_value: str
    verified: bool
    status: str
    reward: Optional[str]

    @classmethod
    def _from_dict(cls, d: Dict[str, Any]) -> ClaimStatus:
        return cls(
            claim_id=str(d["claimId"]),
            claimant=d.get("claimant", ""),
            impact_type=d.get("impactType", ""),
            impact_value=str(d.get("impactValue", "")),
            verified=bool(d.get("verified", False)),
            status=d.get("status", ""),
            reward=d.get("reward"),
        )


# ─── Verify — fast-path text claim with evidence ─────────────────────────────

ClaimVerdict = Literal["SUPPORTED", "CONTRADICTED", "UNVERIFIABLE", "INCONCLUSIVE"]


@dataclass
class AIAssessment:
    verdict: str                 # SUPPORTED | CONTRADICTED | UNVERIFIABLE | INCONCLUSIVE
    confidence: int              # 0-100
    reasoning: str
    key_facts: List[str]
    caveats: List[str]

    @classmethod
    def _from_dict(cls, d: Dict[str, Any]) -> "AIAssessment":
        return cls(
            verdict=d.get("verdict", "INCONCLUSIVE"),
            confidence=int(d.get("confidence", 0)),
            reasoning=d.get("reasoning", ""),
            key_facts=d.get("keyFacts", []),
            caveats=d.get("caveats", []),
        )


@dataclass
class EvidenceSource:
    title: str
    url: str
    snippet: str

    @classmethod
    def _from_dict(cls, d: Dict[str, Any]) -> "EvidenceSource":
        return cls(title=d.get("title", ""), url=d.get("url", ""), snippet=d.get("snippet", ""))


@dataclass
class EvidenceCheck:
    name: str
    passed: bool
    detail: str

    @classmethod
    def _from_dict(cls, d: Dict[str, Any]) -> "EvidenceCheck":
        return cls(name=d.get("name", ""), passed=bool(d.get("passed", False)), detail=d.get("detail", ""))


@dataclass
class ClaimEvidence:
    """Full evidence bundle returned by verify.claim_with_evidence()."""
    claim_id: str
    claim: str
    claim_hash: str
    claimant: str
    verified: bool
    reward: str
    status: str                          # 'verified' | 'pending'
    verification_status: str             # 'verifying' | 'verified' | 'error'
    verdict: str                         # SUPPORTED | CONTRADICTED | UNVERIFIABLE | INCONCLUSIVE
    confidence: int                      # 0-100
    ai_assessment: Optional[AIAssessment]
    web_sources: List[EvidenceSource]
    checks: List[EvidenceCheck]
    verified_at: Optional[str]
    tx_hash: Optional[str]
    explorer: Optional[str]

    @classmethod
    def _from_dict(cls, d: Dict[str, Any]) -> "ClaimEvidence":
        return cls(
            claim_id=str(d.get("claimId", "")),
            claim=d.get("claim", ""),
            claim_hash=d.get("claimHash", ""),
            claimant=d.get("claimant", ""),
            verified=bool(d.get("verified", False)),
            reward=str(d.get("reward", "0")),
            status=d.get("status", "pending"),
            verification_status=d.get("verificationStatus", "verifying"),
            verdict=d.get("verdict", "INCONCLUSIVE"),
            confidence=int(d.get("confidence", 0)),
            ai_assessment=AIAssessment._from_dict(d["aiAssessment"]) if d.get("aiAssessment") else None,
            web_sources=[EvidenceSource._from_dict(s) for s in d.get("webSources", [])],
            checks=[EvidenceCheck._from_dict(c) for c in d.get("checks", [])],
            verified_at=d.get("verifiedAt"),
            tx_hash=d.get("txHash"),
            explorer=d.get("explorer"),
        )


# ─── Verify — image ───────────────────────────────────────────────────────────

@dataclass
class RawImageScores:
    hive_ai_generated: float    # 0.0–1.0 probability
    hive_deepfake: float        # 0.0–1.0 probability
    hive_top_generators: List[str]
    ela_edited: bool
    ela_size_ratio: float
    exif_absent: bool
    exif_inconsistent: bool
    claude_authenticity_score: int  # 0-100

    @classmethod
    def _from_dict(cls, d: Dict[str, Any]) -> RawImageScores:
        return cls(
            hive_ai_generated=d.get("hiveAiGenerated", 0.0),
            hive_deepfake=d.get("hiveDeepfake", 0.0),
            hive_top_generators=d.get("hiveTopGenerators", []),
            ela_edited=bool(d.get("elaEdited", False)),
            ela_size_ratio=float(d.get("elaSizeRatio", 0.0)),
            exif_absent=bool(d.get("exifAbsent", False)),
            exif_inconsistent=bool(d.get("exifInconsistent", False)),
            claude_authenticity_score=int(d.get("claudeAuthenticityScore", 0)),
        )


@dataclass
class ImageVerifyResult:
    verdict: ImageVerdict
    verdict_reason: str
    authenticity_score: int     # 0-100 integer, matches server exactly
    raw_scores: RawImageScores
    thresholds_used: Dict[str, float]
    image_hash: str
    tx_hash: str
    flags: List[str]
    claims_extracted: List[str]
    timestamp: str
    request_id: str
    claim_id: Optional[int]

    @classmethod
    def _from_dict(cls, d: Dict[str, Any]) -> ImageVerifyResult:
        return cls(
            verdict=d["verdict"],
            verdict_reason=d.get("verdictReason", ""),
            authenticity_score=int(d.get("authenticityScore", 0)),
            raw_scores=RawImageScores._from_dict(d.get("rawScores", {})),
            thresholds_used=d.get("thresholdsUsed", {}),
            image_hash=d.get("imageHash", ""),
            tx_hash=d.get("txHash", ""),
            flags=d.get("flags", []),
            claims_extracted=d.get("claimsExtracted", []),
            timestamp=d.get("timestamp", ""),
            request_id=d.get("requestId", ""),
            claim_id=d.get("claimId"),
        )


# ─── Verify — document ────────────────────────────────────────────────────────

@dataclass
class DocumentCheck:
    name: str
    passed: bool
    detail: str

    @classmethod
    def _from_dict(cls, d: Dict[str, Any]) -> DocumentCheck:
        return cls(name=d["name"], passed=bool(d["passed"]), detail=d.get("detail", ""))


@dataclass
class AiDetection:
    is_ai_generated: bool
    confidence: float
    detail: str

    @classmethod
    def _from_dict(cls, d: Dict[str, Any]) -> AiDetection:
        return cls(
            is_ai_generated=bool(d.get("isAiGenerated", False)),
            confidence=float(d.get("confidence", 0.0)),
            detail=d.get("detail", ""),
        )


@dataclass
class DocumentVerifyResult:
    verdict: AuthVerdict
    confidence: float
    document_hash: str
    tx_hash: str
    explorer: Optional[str]
    checks: List[DocumentCheck]
    ai_detection: AiDetection
    request_id: str

    @classmethod
    def _from_dict(cls, d: Dict[str, Any]) -> DocumentVerifyResult:
        return cls(
            verdict=d["verdict"],
            confidence=float(d.get("confidence", 0.0)),
            document_hash=d.get("documentHash", ""),
            tx_hash=d.get("txHash", ""),
            explorer=d.get("explorer"),
            checks=[DocumentCheck._from_dict(c) for c in d.get("checks", [])],
            ai_detection=AiDetection._from_dict(d.get("aiDetection", {})),
            request_id=d.get("requestId", ""),
        )


# ─── Verify — visual auth (luxury, rx, etc.) ─────────────────────────────────

@dataclass
class VisualAuthIndicators:
    authentic: List[str]
    suspicious: List[str]

    @classmethod
    def _from_dict(cls, d: Dict[str, Any]) -> VisualAuthIndicators:
        return cls(authentic=d.get("authentic", []), suspicious=d.get("suspicious", []))


@dataclass
class PhotoAuthenticity:
    ai_generated_score: float
    is_ai_generated: bool

    @classmethod
    def _from_dict(cls, d: Dict[str, Any]) -> PhotoAuthenticity:
        return cls(
            ai_generated_score=float(d.get("aiGeneratedScore", 0.0)),
            is_ai_generated=bool(d.get("isAIGenerated", False)),
        )


@dataclass
class VisualAuthResult:
    """Base result returned by luxury, rx, credential, art, sneakers, etc."""
    verdict: AuthVerdict
    verdict_reason: str
    authenticity_score: int     # 0-100
    confidence: int             # 0-100
    indicators: VisualAuthIndicators
    flags: List[str]
    summary: str
    photo_authenticity: Optional[PhotoAuthenticity]
    image_hashes: List[str]
    images_analyzed: int
    tx_hash: str
    explorer: Optional[str]
    timestamp: str
    request_id: str
    claim_id: Optional[int]
    # extra fields preserved verbatim for endpoint-specific data
    extra: Dict[str, Any]

    @classmethod
    def _from_dict(cls, d: Dict[str, Any]) -> VisualAuthResult:
        known = {
            "verdict", "verdictReason", "authenticityScore", "confidence",
            "indicators", "flags", "summary", "photoAuthenticity",
            "imageHashes", "imagesAnalyzed", "txHash", "explorer",
            "timestamp", "requestId", "claimId",
        }
        return cls(
            verdict=d["verdict"],
            verdict_reason=d.get("verdictReason", ""),
            authenticity_score=int(d.get("authenticityScore", 0)),
            confidence=int(d.get("confidence", 0)),
            indicators=VisualAuthIndicators._from_dict(d.get("indicators", {})),
            flags=d.get("flags", []),
            summary=d.get("summary", ""),
            photo_authenticity=(
                PhotoAuthenticity._from_dict(d["photoAuthenticity"])
                if d.get("photoAuthenticity") else None
            ),
            image_hashes=d.get("imageHashes", []),
            images_analyzed=int(d.get("imagesAnalyzed", 0)),
            tx_hash=d.get("txHash", ""),
            explorer=d.get("explorer"),
            timestamp=d.get("timestamp", ""),
            request_id=d.get("requestId", ""),
            claim_id=d.get("claimId"),
            extra={k: v for k, v in d.items() if k not in known},
        )


# ─── Video verification ───────────────────────────────────────────────────────

VideoVerdict = Literal[
    "HIGH_CONFIDENCE_AUTHENTIC",
    "LIKELY_AUTHENTIC",
    "INCONCLUSIVE",
    "LIKELY_MANIPULATED",
    "HIGH_CONFIDENCE_MANIPULATED",
]


@dataclass
class VideoRawScores:
    avg_ai_generated: Optional[float]
    avg_deepfake: Optional[float]
    max_ai_generated: Optional[float]
    max_deepfake: Optional[float]
    flagged_frames: Optional[int]

    @classmethod
    def _from_dict(cls, d: Dict[str, Any]) -> "VideoRawScores":
        return cls(
            avg_ai_generated=d.get("avgAiGenerated"),
            avg_deepfake=d.get("avgDeepfake"),
            max_ai_generated=d.get("maxAiGenerated"),
            max_deepfake=d.get("maxDeepfake"),
            flagged_frames=d.get("flaggedFrames"),
        )


@dataclass
class VideoVerifyResult:
    job_id: str
    verdict: str
    verdict_label: str
    confidence: int
    summary: str
    raw_scores: Optional[VideoRawScores]
    frames_analyzed: int
    duration_secs: int
    escalated: bool
    tx_hash: Optional[str]
    explorer: Optional[str]
    claim: Optional[str]
    billing_type: str
    completed_at: str

    @classmethod
    def _from_dict(cls, d: Dict[str, Any]) -> "VideoVerifyResult":
        raw = d.get("rawScores")
        return cls(
            job_id=d["jobId"],
            verdict=d["verdict"],
            verdict_label=d["verdictLabel"],
            confidence=int(d.get("confidence", 0)),
            summary=d.get("summary", ""),
            raw_scores=VideoRawScores._from_dict(raw) if raw else None,
            frames_analyzed=int(d.get("framesAnalyzed", 0)),
            duration_secs=int(d.get("durationSecs", 0)),
            escalated=bool(d.get("escalated", False)),
            tx_hash=d.get("txHash"),
            explorer=d.get("explorer"),
            claim=d.get("claim"),
            billing_type=d.get("billingType", "per_call"),
            completed_at=d.get("completedAt", ""),
        )


# ─── Trust ────────────────────────────────────────────────────────────────────

@dataclass
class TrustScore:
    address: str
    trust_score: int            # 0-1000, neutral = 500
    neutral: int
    range: str
    interpretation: str
    formula: str

    @classmethod
    def _from_dict(cls, d: Dict[str, Any]) -> TrustScore:
        return cls(
            address=d.get("address", ""),
            trust_score=int(d.get("trustScore", 500)),
            neutral=int(d.get("neutral", 500)),
            range=d.get("range", "0-1000"),
            interpretation=d.get("interpretation", ""),
            formula=d.get("formula", ""),
        )


# ─── Webhooks ─────────────────────────────────────────────────────────────────

@dataclass
class Webhook:
    id: str
    url: str
    events: List[str]
    created_at: str

    @classmethod
    def _from_dict(cls, d: Dict[str, Any]) -> Webhook:
        return cls(
            id=d.get("id", d.get("webhookId", "")),
            url=d["url"],
            events=d.get("events", []),
            created_at=d.get("createdAt", d.get("created", "")),
        )


@dataclass
class WebhookCreateResult:
    id: str
    url: str
    events: List[str]
    secret: str                 # shown once — store immediately
    created_at: str

    @classmethod
    def _from_dict(cls, d: Dict[str, Any]) -> WebhookCreateResult:
        return cls(
            id=d.get("webhookId", d.get("id", "")),
            url=d["url"],
            events=d.get("events", []),
            secret=d.get("secret", ""),
            created_at=d.get("createdAt", d.get("created", "")),
        )


@dataclass
class WebhookDelivery:
    id: str
    webhook_id: str
    event: str
    status: str
    status_code: Optional[int]
    created_at: str

    @classmethod
    def _from_dict(cls, d: Dict[str, Any]) -> WebhookDelivery:
        return cls(
            id=d.get("id", ""),
            webhook_id=d.get("webhookId", ""),
            event=d.get("event", ""),
            status=d.get("status", ""),
            status_code=d.get("statusCode"),
            created_at=d.get("createdAt", d.get("created", "")),
        )


# ─── Account ─────────────────────────────────────────────────────────────────

@dataclass
class KeyInfo:
    name: str
    email: str
    company: str
    plan: str
    key_preview: str
    created_at: str

    @classmethod
    def _from_dict(cls, d: Dict[str, Any]) -> KeyInfo:
        return cls(
            name=d.get("name", ""),
            email=d.get("email", ""),
            company=d.get("company", ""),
            plan=d.get("plan", ""),
            key_preview=d.get("keyPreview", ""),
            created_at=d.get("createdAt", ""),
        )


@dataclass
class UsageStats:
    key: str
    current_month: str          # 'YYYY-MM'
    total_calls: int
    by_endpoint: Dict[str, int]
    generated_at: str

    @classmethod
    def _from_dict(cls, d: Dict[str, Any]) -> UsageStats:
        return cls(
            key=d.get("key", ""),
            current_month=d.get("currentMonth", ""),
            total_calls=int(d.get("totalCalls", 0)),
            by_endpoint=d.get("byEndpoint", {}),
            generated_at=d.get("generatedAt", ""),
        )


@dataclass
class HistoryEntry:
    ts: int                     # Unix ms
    type: str
    request_id: str
    verdict: Optional[str]
    authenticity_score: Optional[int]
    tx_hash: Optional[str]
    claim_id: Optional[int]
    verdict_reason: Optional[str]

    @classmethod
    def _from_dict(cls, d: Dict[str, Any]) -> HistoryEntry:
        return cls(
            ts=int(d.get("ts", 0)),
            type=d.get("type", ""),
            request_id=d.get("requestId", ""),
            verdict=d.get("verdict"),
            authenticity_score=d.get("authenticityScore"),
            tx_hash=d.get("txHash"),
            claim_id=d.get("claimId"),
            verdict_reason=d.get("verdictReason"),
        )


@dataclass
class HistoryPage:
    verifications: List[HistoryEntry]
    total: int
    offset: int
    limit: int
    has_more: bool

    @classmethod
    def _from_dict(cls, d: Dict[str, Any]) -> HistoryPage:
        return cls(
            verifications=[HistoryEntry._from_dict(e) for e in d.get("verifications", [])],
            total=int(d.get("total", 0)),
            offset=int(d.get("offset", 0)),
            limit=int(d.get("limit", 20)),
            has_more=bool(d.get("hasMore", False)),
        )


# ─── Health ───────────────────────────────────────────────────────────────────

@dataclass
class HealthStatus:
    status: str
    chain: str
    block: int
    claims: int
    signer: str
    write_enabled: bool
    contracts: Dict[str, str]

    @classmethod
    def _from_dict(cls, d: Dict[str, Any]) -> HealthStatus:
        return cls(
            status=d.get("status", ""),
            chain=d.get("chain", ""),
            block=int(d.get("block", 0)),
            claims=int(d.get("claims", 0)),
            signer=d.get("signer", ""),
            write_enabled=bool(d.get("writeEnabled", False)),
            contracts=d.get("contracts", {}),
        )


@dataclass
class ProtocolStats:
    claims: int
    extra: Dict[str, Any]

    @classmethod
    def _from_dict(cls, d: Dict[str, Any]) -> ProtocolStats:
        return cls(claims=int(d.get("claims", 0)), extra={k: v for k, v in d.items() if k != "claims"})
