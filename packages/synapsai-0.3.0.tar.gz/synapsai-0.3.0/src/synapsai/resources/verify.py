from __future__ import annotations

import time
from pathlib import Path
from typing import BinaryIO, Dict, List, Optional, Union

from .._errors import ServerError, ValidationError
from .._multipart import ImageInput, build_files
from .._types import (
    ClaimEvidence,
    ClaimResult,
    ClaimStatus,
    DocumentInput,
    DocumentVerifyResult,
    ImageVerifyResult,
    VideoVerifyResult,
    VisualAuthResult,
)


class VerifyResource:
    def __init__(self, client: object) -> None:
        self._c = client  # _SyncTransport

    def claim(
        self,
        content: Optional[str] = None,
        *,
        content_hash: Optional[str] = None,
        impact_type: Optional[str] = None,
        impact_value: Optional[int] = None,
    ) -> ClaimResult:
        """Submit a text claim for on-chain fact-checking (returns 202 immediately)."""
        body: Dict = {}
        if content is not None:
            body["content"] = content
        if content_hash is not None:
            body["contentHash"] = content_hash
        if impact_type is not None:
            body["impactType"] = impact_type
        if impact_value is not None:
            body["impactValue"] = impact_value
        return ClaimResult._from_dict(self._c.post("/v1/verify", json=body))

    def get(self, claim_id: Union[int, str]) -> ClaimStatus:
        """Poll verification status for a submitted claim."""
        return ClaimStatus._from_dict(self._c.get(f"/v1/verify/{claim_id}"))

    def claim_with_evidence(
        self,
        claim: str,
        *,
        source: Optional[str] = None,
        poll_interval_ms: int = 3_000,
        timeout_ms: int = 60_000,
    ) -> ClaimEvidence:
        """Fast-path text claim verification via Claude AI.

        Submits *claim* to ``/v1/verify/claim``, then blocks and polls until
        the evidence pipeline completes (typically 5–15 s). Returns a
        :class:`ClaimEvidence` bundle with verdict, confidence, AI reasoning,
        key facts, and web sources.

        Use this for an immediate answer. For the full oracle network pipeline
        (9 independent checks, adversarial red team, on-chain verdict), use
        :meth:`claim` and poll with :meth:`get` instead.

        Example::

            evidence = client.verify.claim_with_evidence(
                "FDA fully approved Leqembi for Alzheimer's in July 2023"
            )
            print(evidence.verdict)      # 'SUPPORTED'
            print(evidence.confidence)   # 95
            print(evidence.ai_assessment.reasoning)
        """
        submitted = self._c.post("/v1/verify/claim", json={
            "claim": claim,
            **({"source": source} if source else {}),
        })
        claim_id = submitted["claimId"]

        deadline = time.monotonic() + timeout_ms / 1000
        while time.monotonic() < deadline:
            time.sleep(poll_interval_ms / 1000)
            status = self._c.get(f"/v1/verify/{claim_id}")
            vs = status.get("verificationStatus")
            if vs in ("verified", "error"):
                return ClaimEvidence._from_dict(status)

        raise ServerError(
            f"Evidence pipeline timed out after {timeout_ms}ms. "
            f"Poll manually: GET /v1/verify/{claim_id}",
            status=0,
            code="timeout",
        )

    def image(
        self,
        image: ImageInput,
        *,
        claim: Optional[str] = None,
    ) -> ImageVerifyResult:
        """Verify an image for AI generation, deepfakes, and editing."""
        files = build_files("image", image, {"claim": claim} if claim else None)
        return ImageVerifyResult._from_dict(self._c.post_form("/v1/verify/image", files))

    def document(
        self,
        document: DocumentInput,
        *,
        claim: Optional[str] = None,
    ) -> DocumentVerifyResult:
        """Verify a document (PDF, DOCX, etc.) for authenticity."""
        files = build_files("document", document, {"claim": claim} if claim else None)
        return DocumentVerifyResult._from_dict(self._c.post_form("/v1/verify/document", files))

    def luxury(
        self,
        images: Union[ImageInput, List[ImageInput]],
        *,
        brand: Optional[str] = None,
        model: Optional[str] = None,
    ) -> VisualAuthResult:
        """Authenticate a luxury item (watches, handbags, art). Accepts 1–4 images."""
        extra = {k: v for k, v in {"brand": brand, "model": model}.items() if v}
        return VisualAuthResult._from_dict(self._c.post_form("/v1/verify/luxury", build_files("images", images, extra or None)))

    def rx(self, images: Union[ImageInput, List[ImageInput]], *, drug_name: Optional[str] = None) -> VisualAuthResult:
        """Authenticate a prescription drug."""
        extra = {"drugName": drug_name} if drug_name else None
        return VisualAuthResult._from_dict(self._c.post_form("/v1/verify/rx", build_files("images", images, extra)))

    def credential(self, images: Union[ImageInput, List[ImageInput]], *, credential_type: Optional[str] = None) -> VisualAuthResult:
        """Authenticate an academic or professional credential."""
        extra = {"credentialType": credential_type} if credential_type else None
        return VisualAuthResult._from_dict(self._c.post_form("/v1/verify/credential", build_files("images", images, extra)))

    def art(self, images: Union[ImageInput, List[ImageInput]], *, artist: Optional[str] = None) -> VisualAuthResult:
        """Authenticate fine art."""
        extra = {"artist": artist} if artist else None
        return VisualAuthResult._from_dict(self._c.post_form("/v1/verify/art", build_files("images", images, extra)))

    def sneakers(self, images: Union[ImageInput, List[ImageInput]], *, brand: Optional[str] = None) -> VisualAuthResult:
        """Authenticate sneakers/footwear."""
        extra = {"brand": brand} if brand else None
        return VisualAuthResult._from_dict(self._c.post_form("/v1/verify/sneakers", build_files("images", images, extra)))

    def cards(self, images: Union[ImageInput, List[ImageInput]], *, card_type: Optional[str] = None) -> VisualAuthResult:
        """Authenticate trading cards (Pokemon, sports, etc.)."""
        extra = {"cardType": card_type} if card_type else None
        return VisualAuthResult._from_dict(self._c.post_form("/v1/verify/cards", build_files("images", images, extra)))

    def wine(self, images: Union[ImageInput, List[ImageInput]], *, producer: Optional[str] = None) -> VisualAuthResult:
        """Authenticate wine bottles."""
        extra = {"producer": producer} if producer else None
        return VisualAuthResult._from_dict(self._c.post_form("/v1/verify/wine", build_files("images", images, extra)))

    def ticket(self, images: Union[ImageInput, List[ImageInput]], *, event: Optional[str] = None) -> VisualAuthResult:
        """Authenticate event tickets."""
        extra = {"event": event} if event else None
        return VisualAuthResult._from_dict(self._c.post_form("/v1/verify/ticket", build_files("images", images, extra)))

    def jewelry(self, images: Union[ImageInput, List[ImageInput]], *, metal: Optional[str] = None) -> VisualAuthResult:
        """Authenticate jewelry."""
        extra = {"metal": metal} if metal else None
        return VisualAuthResult._from_dict(self._c.post_form("/v1/verify/jewelry", build_files("images", images, extra)))

    def electronics(self, images: Union[ImageInput, List[ImageInput]], *, brand: Optional[str] = None) -> VisualAuthResult:
        """Authenticate electronics."""
        extra = {"brand": brand} if brand else None
        return VisualAuthResult._from_dict(self._c.post_form("/v1/verify/electronics", build_files("images", images, extra)))

    def video(
        self,
        video: Union[Path, str, bytes, BinaryIO],
        *,
        filename: Optional[str] = None,
        claim: Optional[str] = None,
        poll_interval_ms: int = 3_000,
        timeout_ms: int = 120_000,
    ) -> VideoVerifyResult:
        """Detect deepfakes in video. Uploads to R2, analyzes frames with Hive AI, commits verdict on-chain."""
        import httpx as _httpx

        name, data, mimetype = _resolve_video(video, filename)

        upload_resp = self._c.post("/v1/verify/video/upload-url", json={
            "filename": name,
            "filesize": len(data),
            "mimetype": mimetype,
        })

        if upload_resp.get("_stub"):
            setup = upload_resp.get("_setup", "Set R2_* env vars in taas-api/.env and restart.")
            raise ServerError(f"R2 storage not configured. {setup}", status=503, code="storage_not_configured")

        job_id = upload_resp["jobId"]
        put_resp = _httpx.put(upload_resp["uploadUrl"], content=data, headers={"Content-Type": mimetype})
        if put_resp.status_code >= 300:
            raise ServerError(
                f"Video upload to storage failed (HTTP {put_resp.status_code})",
                status=put_resp.status_code,
                code="upload_error",
            )

        self._c.post(f"/v1/verify/video/{job_id}/analyze", json={"claim": claim})

        deadline = time.monotonic() + timeout_ms / 1000
        interval = poll_interval_ms / 1000
        while time.monotonic() < deadline:
            time.sleep(interval)
            status = self._c.get(f"/v1/verify/video/{job_id}")
            if status.get("status") == "complete":
                return VideoVerifyResult._from_dict(status)
            if status.get("status") == "failed":
                raise ServerError(status.get("summary", "Video processing failed"), status=0, code="processing_failed")

        raise ServerError(
            f"Video verification timed out after {timeout_ms}ms. Poll manually: GET /v1/verify/video/{job_id}",
            status=0,
            code="timeout",
        )


class AsyncVerifyResource:
    def __init__(self, client: object) -> None:
        self._c = client  # _AsyncTransport

    async def claim(
        self,
        content: Optional[str] = None,
        *,
        content_hash: Optional[str] = None,
        impact_type: Optional[str] = None,
        impact_value: Optional[int] = None,
    ) -> ClaimResult:
        body: Dict = {}
        if content is not None:
            body["content"] = content
        if content_hash is not None:
            body["contentHash"] = content_hash
        if impact_type is not None:
            body["impactType"] = impact_type
        if impact_value is not None:
            body["impactValue"] = impact_value
        return ClaimResult._from_dict(await self._c.post("/v1/verify", json=body))

    async def get(self, claim_id: Union[int, str]) -> ClaimStatus:
        return ClaimStatus._from_dict(await self._c.get(f"/v1/verify/{claim_id}"))

    async def claim_with_evidence(
        self,
        claim: str,
        *,
        source: Optional[str] = None,
        poll_interval_ms: int = 3_000,
        timeout_ms: int = 60_000,
    ) -> ClaimEvidence:
        """Async fast-path text claim verification via Claude AI. See sync version for full docs."""
        import asyncio
        submitted = await self._c.post("/v1/verify/claim", json={
            "claim": claim,
            **({"source": source} if source else {}),
        })
        claim_id = submitted["claimId"]

        deadline = time.monotonic() + timeout_ms / 1000
        while time.monotonic() < deadline:
            await asyncio.sleep(poll_interval_ms / 1000)
            status = await self._c.get(f"/v1/verify/{claim_id}")
            vs = status.get("verificationStatus")
            if vs in ("verified", "error"):
                return ClaimEvidence._from_dict(status)

        raise ServerError(
            f"Evidence pipeline timed out after {timeout_ms}ms. "
            f"Poll manually: GET /v1/verify/{claim_id}",
            status=0,
            code="timeout",
        )

    async def image(self, image: ImageInput, *, claim: Optional[str] = None) -> ImageVerifyResult:
        files = build_files("image", image, {"claim": claim} if claim else None)
        return ImageVerifyResult._from_dict(await self._c.post_form("/v1/verify/image", files))

    async def document(self, document: DocumentInput, *, claim: Optional[str] = None) -> DocumentVerifyResult:
        files = build_files("document", document, {"claim": claim} if claim else None)
        return DocumentVerifyResult._from_dict(await self._c.post_form("/v1/verify/document", files))

    async def luxury(self, images: Union[ImageInput, List[ImageInput]], *, brand: Optional[str] = None, model: Optional[str] = None) -> VisualAuthResult:
        extra = {k: v for k, v in {"brand": brand, "model": model}.items() if v}
        return VisualAuthResult._from_dict(await self._c.post_form("/v1/verify/luxury", build_files("images", images, extra or None)))

    async def rx(self, images: Union[ImageInput, List[ImageInput]], *, drug_name: Optional[str] = None) -> VisualAuthResult:
        extra = {"drugName": drug_name} if drug_name else None
        return VisualAuthResult._from_dict(await self._c.post_form("/v1/verify/rx", build_files("images", images, extra)))

    async def credential(self, images: Union[ImageInput, List[ImageInput]], *, credential_type: Optional[str] = None) -> VisualAuthResult:
        extra = {"credentialType": credential_type} if credential_type else None
        return VisualAuthResult._from_dict(await self._c.post_form("/v1/verify/credential", build_files("images", images, extra)))

    async def art(self, images: Union[ImageInput, List[ImageInput]], *, artist: Optional[str] = None) -> VisualAuthResult:
        extra = {"artist": artist} if artist else None
        return VisualAuthResult._from_dict(await self._c.post_form("/v1/verify/art", build_files("images", images, extra)))

    async def sneakers(self, images: Union[ImageInput, List[ImageInput]], *, brand: Optional[str] = None) -> VisualAuthResult:
        extra = {"brand": brand} if brand else None
        return VisualAuthResult._from_dict(await self._c.post_form("/v1/verify/sneakers", build_files("images", images, extra)))

    async def cards(self, images: Union[ImageInput, List[ImageInput]], *, card_type: Optional[str] = None) -> VisualAuthResult:
        extra = {"cardType": card_type} if card_type else None
        return VisualAuthResult._from_dict(await self._c.post_form("/v1/verify/cards", build_files("images", images, extra)))

    async def wine(self, images: Union[ImageInput, List[ImageInput]], *, producer: Optional[str] = None) -> VisualAuthResult:
        extra = {"producer": producer} if producer else None
        return VisualAuthResult._from_dict(await self._c.post_form("/v1/verify/wine", build_files("images", images, extra)))

    async def ticket(self, images: Union[ImageInput, List[ImageInput]], *, event: Optional[str] = None) -> VisualAuthResult:
        extra = {"event": event} if event else None
        return VisualAuthResult._from_dict(await self._c.post_form("/v1/verify/ticket", build_files("images", images, extra)))

    async def jewelry(self, images: Union[ImageInput, List[ImageInput]], *, metal: Optional[str] = None) -> VisualAuthResult:
        extra = {"metal": metal} if metal else None
        return VisualAuthResult._from_dict(await self._c.post_form("/v1/verify/jewelry", build_files("images", images, extra)))

    async def electronics(self, images: Union[ImageInput, List[ImageInput]], *, brand: Optional[str] = None) -> VisualAuthResult:
        extra = {"brand": brand} if brand else None
        return VisualAuthResult._from_dict(await self._c.post_form("/v1/verify/electronics", build_files("images", images, extra)))

    async def video(
        self,
        video: Union[Path, str, bytes, BinaryIO],
        *,
        filename: Optional[str] = None,
        claim: Optional[str] = None,
        poll_interval_ms: int = 3_000,
        timeout_ms: int = 120_000,
    ) -> VideoVerifyResult:
        """Detect deepfakes in video. Uploads to R2, analyzes frames with Hive AI, commits verdict on-chain."""
        import asyncio
        import httpx as _httpx

        name, data, mimetype = _resolve_video(video, filename)

        upload_resp = await self._c.post("/v1/verify/video/upload-url", json={
            "filename": name,
            "filesize": len(data),
            "mimetype": mimetype,
        })

        if upload_resp.get("_stub"):
            setup = upload_resp.get("_setup", "Set R2_* env vars in taas-api/.env and restart.")
            raise ServerError(f"R2 storage not configured. {setup}", status=503, code="storage_not_configured")

        job_id = upload_resp["jobId"]
        async with _httpx.AsyncClient() as ac:
            put_resp = await ac.put(upload_resp["uploadUrl"], content=data, headers={"Content-Type": mimetype})
        if put_resp.status_code >= 300:
            raise ServerError(
                f"Video upload to storage failed (HTTP {put_resp.status_code})",
                status=put_resp.status_code,
                code="upload_error",
            )

        await self._c.post(f"/v1/verify/video/{job_id}/analyze", json={"claim": claim})

        deadline = time.monotonic() + timeout_ms / 1000
        interval = poll_interval_ms / 1000
        while time.monotonic() < deadline:
            await asyncio.sleep(interval)
            status = await self._c.get(f"/v1/verify/video/{job_id}")
            if status.get("status") == "complete":
                return VideoVerifyResult._from_dict(status)
            if status.get("status") == "failed":
                raise ServerError(status.get("summary", "Video processing failed"), status=0, code="processing_failed")

        raise ServerError(
            f"Video verification timed out after {timeout_ms}ms. Poll manually: GET /v1/verify/video/{job_id}",
            status=0,
            code="timeout",
        )


# ─── Helpers ─────────────────────────────────────────────────────────────────

def _mime_from_filename(filename: str) -> str:
    ext = Path(filename).suffix.lower()
    if ext == ".mov":
        return "video/quicktime"
    if ext == ".webm":
        return "video/webm"
    return "video/mp4"


def _resolve_video(
    video: Union[Path, str, bytes, BinaryIO],
    filename: Optional[str],
) -> tuple:
    if isinstance(video, (str, Path)):
        p = Path(video)
        name = filename or p.name
        data = p.read_bytes()
    elif isinstance(video, bytes):
        if not filename:
            raise ValidationError(
                "Pass filename when video is bytes (e.g. video=data, filename='clip.mp4').",
                status=0,
                code="missing_filename",
                field="filename",
            )
        name = filename
        data = video
    else:  # BinaryIO
        name = filename or getattr(video, "name", None)
        if not name:
            raise ValidationError(
                "Pass filename when video is a file object without a .name attribute.",
                status=0,
                code="missing_filename",
                field="filename",
            )
        data = video.read()
    return name, data, _mime_from_filename(name)
