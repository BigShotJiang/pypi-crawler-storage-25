from __future__ import annotations

import hashlib
import hmac
from typing import List, Optional, Union

from .._types import Webhook, WebhookCreateResult, WebhookDelivery


class WebhooksResource:
    def __init__(self, client: object) -> None:
        self._c = client

    def create(self, url: str, events: List[str]) -> WebhookCreateResult:
        """Register a webhook endpoint. The returned secret is shown once — store it immediately."""
        return WebhookCreateResult._from_dict(
            self._c.post("/v1/webhooks", json={"url": url, "events": events})
        )

    def list(self) -> List[Webhook]:
        """List all registered webhooks."""
        raw = self._c.get("/v1/webhooks")
        return [Webhook._from_dict(w) for w in raw.get("webhooks", [])]

    def delete(self, webhook_id: str) -> None:
        """Delete a webhook by ID."""
        self._c.delete(f"/v1/webhooks/{webhook_id}")

    def deliveries(self, webhook_id: Optional[str] = None) -> List[WebhookDelivery]:
        """List recent delivery attempts."""
        raw = self._c.get("/v1/webhooks/deliveries")
        return [WebhookDelivery._from_dict(d) for d in raw.get("deliveries", [])]

    def test(self, webhook_id: str) -> None:
        """Send a test event to a registered webhook."""
        self._c.post(f"/v1/webhooks/{webhook_id}/test")

    def verify_signature(
        self,
        payload: Union[bytes, str],
        signature: str,
        secret: str,
    ) -> bool:
        """Verify the HMAC-SHA256 signature on an incoming webhook event.

        Always pass the raw, unparsed request body — not JSON-parsed.
        Accepts signatures with or without the ``sha256=`` prefix.
        Uses ``hmac.compare_digest`` for constant-time comparison.
        """
        if isinstance(payload, str):
            payload = payload.encode()
        sig = signature.removeprefix("sha256=") if signature.startswith("sha256=") else signature
        computed = hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()
        return hmac.compare_digest(computed, sig)


class AsyncWebhooksResource:
    def __init__(self, client: object) -> None:
        self._c = client

    async def create(self, url: str, events: List[str]) -> WebhookCreateResult:
        return WebhookCreateResult._from_dict(
            await self._c.post("/v1/webhooks", json={"url": url, "events": events})
        )

    async def list(self) -> List[Webhook]:
        raw = await self._c.get("/v1/webhooks")
        return [Webhook._from_dict(w) for w in raw.get("webhooks", [])]

    async def delete(self, webhook_id: str) -> None:
        await self._c.delete(f"/v1/webhooks/{webhook_id}")

    async def deliveries(self, webhook_id: Optional[str] = None) -> List[WebhookDelivery]:
        raw = await self._c.get("/v1/webhooks/deliveries")
        return [WebhookDelivery._from_dict(d) for d in raw.get("deliveries", [])]

    async def test(self, webhook_id: str) -> None:
        await self._c.post(f"/v1/webhooks/{webhook_id}/test")

    def verify_signature(
        self,
        payload: Union[bytes, str],
        signature: str,
        secret: str,
    ) -> bool:
        """Sync — uses stdlib hmac, no IO needed."""
        if isinstance(payload, str):
            payload = payload.encode()
        sig = signature.removeprefix("sha256=") if signature.startswith("sha256=") else signature
        computed = hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()
        return hmac.compare_digest(computed, sig)
