from __future__ import annotations

from .._types import HealthStatus, ProtocolStats


class HealthResource:
    def __init__(self, client: object) -> None:
        self._c = client

    def status(self) -> HealthStatus:
        """Return API and chain health."""
        return HealthStatus._from_dict(self._c.get("/v1/health"))

    def stats(self) -> ProtocolStats:
        """Return protocol-level statistics."""
        return ProtocolStats._from_dict(self._c.get("/v1/stats"))


class AsyncHealthResource:
    def __init__(self, client: object) -> None:
        self._c = client

    async def status(self) -> HealthStatus:
        return HealthStatus._from_dict(await self._c.get("/v1/health"))

    async def stats(self) -> ProtocolStats:
        return ProtocolStats._from_dict(await self._c.get("/v1/stats"))
