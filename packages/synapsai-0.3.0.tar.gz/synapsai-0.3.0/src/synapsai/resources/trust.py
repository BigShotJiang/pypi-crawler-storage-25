from __future__ import annotations

from typing import List

from .._types import TrustScore


class TrustResource:
    def __init__(self, client: object) -> None:
        self._c = client

    def get(self, address: str) -> TrustScore:
        """Get the trust score for a single wallet address."""
        return TrustScore._from_dict(self._c.get(f"/v1/trust/{address}"))

    def batch(self, addresses: List[str]) -> List[TrustScore]:
        """Get trust scores for multiple wallet addresses in one call."""
        raw = self._c.post("/v1/trust/batch", json={"addresses": addresses})
        return [TrustScore._from_dict(d) for d in raw]


class AsyncTrustResource:
    def __init__(self, client: object) -> None:
        self._c = client

    async def get(self, address: str) -> TrustScore:
        return TrustScore._from_dict(await self._c.get(f"/v1/trust/{address}"))

    async def batch(self, addresses: List[str]) -> List[TrustScore]:
        raw = await self._c.post("/v1/trust/batch", json={"addresses": addresses})
        return [TrustScore._from_dict(d) for d in raw]
