from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional, Union

from .._types import HistoryPage, KeyInfo, UsageStats


def _to_iso(value: Union[datetime, int, str, None]) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")
    if isinstance(value, int):
        return datetime.fromtimestamp(value / 1000, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")
    return str(value)


class AccountResource:
    def __init__(self, client: object) -> None:
        self._c = client

    def key_info(self) -> KeyInfo:
        """Return metadata about the authenticated API key."""
        return KeyInfo._from_dict(self._c.get("/v1/key-info"))

    def usage(self) -> UsageStats:
        """Return call counts for the current billing month."""
        return UsageStats._from_dict(self._c.get("/v1/usage"))

    def history(
        self,
        *,
        type: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        from_: Optional[Union[datetime, int, str]] = None,
        to: Optional[Union[datetime, int, str]] = None,
    ) -> HistoryPage:
        """Return paginated verification history.

        ``from_`` and ``to`` accept :class:`datetime`, Unix ms integers, or ISO strings.
        They are always sent to the server as ISO 8601 strings.
        """
        params: dict = {}
        if type is not None:
            params["type"] = type
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset
        if from_ is not None:
            params["from"] = _to_iso(from_)
        if to is not None:
            params["to"] = _to_iso(to)
        return HistoryPage._from_dict(self._c.get("/v1/history", params=params or None))


class AsyncAccountResource:
    def __init__(self, client: object) -> None:
        self._c = client

    async def key_info(self) -> KeyInfo:
        return KeyInfo._from_dict(await self._c.get("/v1/key-info"))

    async def usage(self) -> UsageStats:
        return UsageStats._from_dict(await self._c.get("/v1/usage"))

    async def history(
        self,
        *,
        type: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        from_: Optional[Union[datetime, int, str]] = None,
        to: Optional[Union[datetime, int, str]] = None,
    ) -> HistoryPage:
        params: dict = {}
        if type is not None:
            params["type"] = type
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset
        if from_ is not None:
            params["from"] = _to_iso(from_)
        if to is not None:
            params["to"] = _to_iso(to)
        return HistoryPage._from_dict(await self._c.get("/v1/history", params=params or None))
