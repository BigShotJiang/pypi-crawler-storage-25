from __future__ import annotations

from typing import Optional


class SynapsAIError(Exception):
    """Base exception for all SynapsAI SDK errors."""

    def __init__(self, message: str, *, status: int, code: str) -> None:
        super().__init__(message)
        self.message = message
        self.status = status
        self.code = code


class AuthError(SynapsAIError):
    """API key is missing or invalid (HTTP 401)."""


class RateLimitError(SynapsAIError):
    """Rate limit exceeded (HTTP 429)."""

    def __init__(
        self,
        message: str,
        *,
        status: int,
        code: str,
        retry_after_ms: int,
    ) -> None:
        super().__init__(message, status=status, code=code)
        self.retry_after_ms = retry_after_ms  # milliseconds, consistent with TS SDK


class ValidationError(SynapsAIError):
    """Request payload is invalid (HTTP 400)."""

    def __init__(
        self,
        message: str,
        *,
        status: int,
        code: str,
        field: Optional[str] = None,
    ) -> None:
        super().__init__(message, status=status, code=code)
        self.field = field


class NotFoundError(SynapsAIError):
    """Requested resource does not exist (HTTP 404)."""


class ServerError(SynapsAIError):
    """Server returned 5xx after all retries exhausted."""
