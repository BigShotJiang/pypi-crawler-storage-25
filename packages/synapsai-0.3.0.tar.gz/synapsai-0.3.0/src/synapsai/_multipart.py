from __future__ import annotations

from pathlib import Path
from typing import BinaryIO, List, Tuple, Union

ImageInput = Union[Path, bytes, BinaryIO]

# httpx file tuple: (filename, content, content_type)
_FileTuple = Tuple[str, bytes, str]


def _to_bytes(inp: ImageInput, fallback_name: str = "file") -> Tuple[str, bytes]:
    if isinstance(inp, Path):
        return inp.name, inp.read_bytes()
    if isinstance(inp, bytes):
        return fallback_name, inp
    # file-like object
    raw_name = getattr(inp, "name", fallback_name)
    name = Path(raw_name).name if raw_name else fallback_name
    return name, inp.read()


def build_files(
    field: str,
    inputs: Union[ImageInput, List[ImageInput]],
    extra: Union[dict, None] = None,
) -> list:
    """Return httpx-compatible `files` list for multipart upload."""
    items = inputs if isinstance(inputs, list) else [inputs]
    result: list = []
    for i, inp in enumerate(items):
        name, content = _to_bytes(inp, f"file{i}")
        result.append((field, (name, content, "application/octet-stream")))
    if extra:
        for k, v in extra.items():
            if v is not None:
                result.append((k, (None, str(v), "text/plain")))
    return result
