from __future__ import annotations

import random
import time
from typing import Any, Dict, List, Optional

import httpx

from ._errors import (
    AuthError,
    NotFoundError,
    RateLimitError,
    ServerError,
    SynapsAIError,
    ValidationError,
)

_DEFAULT_BASE_URL = "https://api.synapsai.org"
_DEFAULT_MAX_RETRIES = 3
_DEFAULT_TIMEOUT = 30.0  # seconds


def _map_error(response: httpx.Response) -> SynapsAIError:
    try:
        body = response.json()
    except Exception:
        body = {}
    code = body.get("error", "unknown_error")
    message = body.get("message", response.text or f"HTTP {response.status_code}")
    status = response.status_code

    if status == 401:
        return AuthError(message, status=status, code=code)
    if status == 404:
        return NotFoundError(message, status=status, code=code)
    if status == 429:
        retry_after_s = body.get("retryAfter", 60)
        return RateLimitError(
            message,
            status=status,
            code=code,
            retry_after_ms=int(retry_after_s * 1000),
        )
    if status == 400:
        return ValidationError(message, status=status, code=code, field=body.get("field"))
    return ServerError(message, status=status, code=code)


def _backoff(attempt: int) -> float:
    """Exponential backoff with ±20% jitter, in seconds."""
    base = 0.5 * (2 ** attempt)
    return base * (0.8 + 0.4 * random.random())


class _SyncTransport:
    def __init__(
        self,
        api_key: str,
        base_url: str,
        max_retries: int,
        timeout: float,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._max_retries = max_retries
        self._headers = {
            "x-api-key": api_key,
            "ngrok-skip-browser-warning": "true",
        }
        self._http = httpx.Client(timeout=timeout)

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> _SyncTransport:
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    def _request(self, method: str, path: str, **kwargs: Any) -> Dict[str, Any]:
        url = self._base_url + path
        kwargs.setdefault("headers", {}).update(self._headers)
        last_exc: Optional[SynapsAIError] = None

        for attempt in range(self._max_retries + 1):
            resp = self._http.request(method, url, **kwargs)
            if resp.status_code < 500:
                if resp.status_code >= 400:
                    raise _map_error(resp)
                return resp.json() if resp.content else {}
            last_exc = _map_error(resp)
            if attempt < self._max_retries:
                time.sleep(_backoff(attempt))

        raise last_exc  # type: ignore[misc]

    def get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        return self._request("GET", path, params=params)

    def post(self, path: str, json: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        return self._request("POST", path, json=json)

    def post_form(self, path: str, files: list) -> Dict[str, Any]:
        return self._request("POST", path, files=files)

    def delete(self, path: str) -> Dict[str, Any]:
        return self._request("DELETE", path)


class _AsyncTransport:
    def __init__(
        self,
        api_key: str,
        base_url: str,
        max_retries: int,
        timeout: float,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._max_retries = max_retries
        self._headers = {
            "x-api-key": api_key,
            "ngrok-skip-browser-warning": "true",
        }
        self._http = httpx.AsyncClient(timeout=timeout)

    async def aclose(self) -> None:
        await self._http.aclose()

    async def __aenter__(self) -> _AsyncTransport:
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.aclose()

    async def _request(self, method: str, path: str, **kwargs: Any) -> Dict[str, Any]:
        import asyncio
        url = self._base_url + path
        kwargs.setdefault("headers", {}).update(self._headers)
        last_exc: Optional[SynapsAIError] = None

        for attempt in range(self._max_retries + 1):
            resp = await self._http.request(method, url, **kwargs)
            if resp.status_code < 500:
                if resp.status_code >= 400:
                    raise _map_error(resp)
                return resp.json() if resp.content else {}
            last_exc = _map_error(resp)
            if attempt < self._max_retries:
                await asyncio.sleep(_backoff(attempt))

        raise last_exc  # type: ignore[misc]

    async def get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        return await self._request("GET", path, params=params)

    async def post(self, path: str, json: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        return await self._request("POST", path, json=json)

    async def post_form(self, path: str, files: list) -> Dict[str, Any]:
        return await self._request("POST", path, files=files)

    async def delete(self, path: str) -> Dict[str, Any]:
        return await self._request("DELETE", path)
