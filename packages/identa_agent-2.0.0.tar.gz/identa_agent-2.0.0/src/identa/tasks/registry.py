class AlignmentTaskRegistry:
    pass
