class PromptStore:
    pass
