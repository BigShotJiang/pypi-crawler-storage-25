import io
import json
import math
from datetime import datetime, timedelta
from typing import Any

import matplotlib.pyplot as plt

# matrix-nio is not marked py.typed; keep import-untyped for strict mypy.
from nio import (
    MatrixRoom,
    ReactionEvent,
    RoomMessageEmote,
    RoomMessageNotice,
    RoomMessageText,
)
from PIL import Image

from mmrelay.constants.domain import MATRIX_EVENT_TYPE_ROOM_MESSAGE
from mmrelay.constants.formats import (
    GRAPH_IMAGE_FORMAT,
    GRAPH_XLABEL_ROTATION_DEGREES,
    HOUR_FORMAT,
    TELEMETRY_APP_PORTNUM,
    TELEMETRY_GRAPH_FILENAME,
)
from mmrelay.constants.messages import MSG_GRAPH_UPLOAD_FAILED
from mmrelay.constants.plugins import TELEMETRY_DEFAULT_HOURS, TELEMETRY_MAX_DATA_ROWS
from mmrelay.meshtastic_utils import _get_portnum_name
from mmrelay.plugins.base_plugin import BasePlugin


class Plugin(BasePlugin):
    plugin_name = "telemetry"
    is_core_plugin = True
    max_data_rows_per_node = TELEMETRY_MAX_DATA_ROWS

    def commands(self) -> list[str]:
        """
        List supported telemetry metric command names.

        Returns:
            list[str]: Supported telemetry command names: "batteryLevel", "voltage", and "airUtilTx".
        """
        return ["batteryLevel", "voltage", "airUtilTx"]

    @property
    def description(self) -> str:
        """
        Short description of the plugin's visualization purpose.

        Returns:
            str: The text "Graph of avg Mesh telemetry value for last 12 hours".
        """
        return f"Graph of avg Mesh telemetry value for last {TELEMETRY_DEFAULT_HOURS} hours"

    def _generate_timeperiods(
        self, hours: int = TELEMETRY_DEFAULT_HOURS
    ) -> list[datetime]:
        """
        Generate hourly datetime anchors spanning the past `hours` hours up to the current time.

        Parameters:
            hours (int): Number of hours to look back from now (default TELEMETRY_DEFAULT_HOURS).

        Returns:
            list[datetime]: Hourly datetime objects from (now - hours) up to and including now.
        """
        end_time = datetime.now()
        start_time = end_time - timedelta(hours=hours)

        # Create a list of hourly intervals for the specified time period
        hourly_intervals = []
        current_time = start_time
        while current_time <= end_time:
            hourly_intervals.append(current_time)
            current_time += timedelta(hours=1)
        return hourly_intervals

    async def handle_meshtastic_message(
        self,
        packet: dict[str, Any],
        formatted_message: str,
        longname: str,
        meshnet_name: str,
    ) -> bool:
        # Support deviceMetrics only for now
        """
        Record device telemetry from an incoming Meshtastic telemetry packet for the sending node.

        When `packet` contains a normalized `decoded.portnum` matching `TELEMETRY_APP_PORTNUM` (numeric values and enum-name strings are both accepted), `decoded.telemetry.deviceMetrics`, and a `fromId`, extracts the telemetry timestamp and the `batteryLevel`, `voltage`, and `airUtilTx` fields (each `None` if missing) and appends a telemetry record for that sender. Other packet contents are not modified.

        Parameters:
            packet (dict): Meshtastic packet expected to include `decoded` with `portnum` and `telemetry.deviceMetrics`.
            formatted_message (str): Unused.
            longname (str): Unused.
            meshnet_name (str): Unused.

        Returns:
            bool: `False` always; telemetry is recorded but the message is not consumed by this handler.
        """
        _ = formatted_message, longname, meshnet_name
        decoded = packet.get("decoded")
        if not isinstance(decoded, dict):
            return False
        telemetry = decoded.get("telemetry")
        device_metrics = (
            telemetry.get("deviceMetrics") if isinstance(telemetry, dict) else None
        )
        if (
            _get_portnum_name(decoded.get("portnum")) == TELEMETRY_APP_PORTNUM
            and isinstance(telemetry, dict)
            and isinstance(device_metrics, dict)
        ):
            from_id = packet.get("fromId")
            if from_id is None:
                return False
            telemetry_data = []
            data = self.get_node_data(meshtastic_id=from_id)
            if data:
                telemetry_data = data if isinstance(data, list) else [data]

            telemetry_time = telemetry.get("time")
            if not isinstance(telemetry_time, (int, float)) or not math.isfinite(
                telemetry_time
            ):
                telemetry_time = None
            telemetry_data.append(
                {
                    "time": (
                        telemetry_time
                        if telemetry_time is not None
                        else packet.get("rxTime")
                    ),
                    "batteryLevel": device_metrics.get("batteryLevel"),
                    "voltage": device_metrics.get("voltage"),
                    "airUtilTx": device_metrics.get("airUtilTx"),
                }
            )
            self.set_node_data(meshtastic_id=from_id, node_data=telemetry_data)
            return False

        return False

    def get_matrix_commands(self) -> list[str]:
        """
        Telemetry command names supported for Matrix messages.

        Returns:
            list[str]: Supported telemetry command names: ["batteryLevel", "voltage", "airUtilTx"].
        """
        return self.commands()

    def get_mesh_commands(self) -> list[str]:
        """
        List supported mesh commands for this plugin.

        Returns:
            list[str]: An empty list indicating the plugin exposes no mesh commands.
        """
        return []

    async def handle_room_message(
        self,
        room: MatrixRoom,
        event: RoomMessageText | RoomMessageNotice | ReactionEvent | RoomMessageEmote,
        full_message: str,
    ) -> bool:
        # Pass the event to matches()
        """
        Handle a Matrix message that requests a telemetry graph and send the generated image to the originating room.

        Parses a telemetry command (one of `batteryLevel`, `voltage`, `airUtilTx`) optionally followed by a node identifier, computes hourly averages for the last 12 hours for that node or for the whole network, renders a line plot of those averages, and uploads the image to the originating room. If a specified node has no telemetry data, a notice is sent instead of an image.

        Parameters:
            room: Matrix room object where the event originated and where the response will be sent.
            event: Matrix event used to determine whether it matches a supported telemetry command.
            full_message: Full plaintext message content used to parse the command and optional node identifier.

        Returns:
            `True` if the message matched a telemetry command and a graph was generated and sent or a notice was sent for a node with no data, `False` otherwise.
        """
        if not self.matches(event):
            return False

        parsed_command = self.get_matching_matrix_command(event)
        if not parsed_command:
            return False

        args = self.extract_command_args(parsed_command, full_message) or ""
        telemetry_option = parsed_command
        node = args or None

        hourly_intervals = self._generate_timeperiods()
        from mmrelay.matrix_utils import connect_matrix

        matrix_client = await connect_matrix()
        if matrix_client is None:
            self.logger.warning(
                "Matrix client unavailable; skipping telemetry graph generation"
            )
            return False

        # Compute the hourly averages for each node
        hourly_averages: dict[int, list[float]] = {}

        def calculate_averages(node_data_rows: list[dict[str, Any]]) -> None:
            """
            Accumulate per-record telemetry values into hourly bins keyed by indices of the outer `hourly_intervals`.

            Parameters:
                node_data_rows (list[dict[str, Any]]): Records containing a "time" POSIX timestamp (seconds) and a telemetry value under the key named by the enclosing `telemetry_option`; values are appended to the outer `hourly_averages` dictionary for the matching hourly interval.
            """
            for record in node_data_rows:
                if not isinstance(record, dict):
                    continue
                timestamp = record.get("time")
                telemetry_value = record.get(telemetry_option)
                if timestamp is None or telemetry_value is None:
                    continue
                try:
                    record_time = datetime.fromtimestamp(timestamp)
                    value = float(telemetry_value)
                    if not math.isfinite(value):
                        continue
                except (TypeError, ValueError, OSError, OverflowError):
                    continue
                for i in range(len(hourly_intervals) - 1):
                    if hourly_intervals[i] <= record_time < hourly_intervals[i + 1]:
                        if i not in hourly_averages:
                            hourly_averages[i] = []
                        hourly_averages[i].append(value)
                        break

        if node:
            node_data_rows = self.get_node_data(node)
            if node_data_rows:
                calculate_averages(
                    node_data_rows
                    if isinstance(node_data_rows, list)
                    else [node_data_rows]
                )
            else:
                await self.send_matrix_message(
                    room.room_id,
                    f"No telemetry data found for node '{node}'.",
                    formatted=False,
                )
                return True
        else:
            for node_data_json in self.get_data():
                node_data_rows = json.loads(node_data_json[0])
                calculate_averages(node_data_rows)

        # Compute the final hourly averages
        final_averages = {}
        for i, interval in enumerate(hourly_intervals[:-1]):
            if i in hourly_averages:
                final_averages[interval] = sum(hourly_averages[i]) / len(
                    hourly_averages[i]
                )
            else:
                final_averages[interval] = 0.0

        # Extract the hourly intervals and average values into separate lists
        hourly_intervals = list(final_averages.keys())
        average_values = list(final_averages.values())

        # Convert the hourly intervals to strings
        hourly_strings = [hour.strftime(HOUR_FORMAT) for hour in hourly_intervals]

        # Create the plot
        fig, ax = plt.subplots()
        ax.plot(hourly_strings, average_values)

        # Set the plot title and axis labels
        if node:
            title = f"{node} Hourly {telemetry_option} Averages"
        else:
            title = f"Network Hourly {telemetry_option} Averages"
        ax.set_title(title)
        ax.set_xlabel("Hour")
        ax.set_ylabel(f"{telemetry_option}")

        # Rotate the x-axis labels for readability
        plt.xticks(rotation=GRAPH_XLABEL_ROTATION_DEGREES)

        # Save the plot as a PIL image
        buf = io.BytesIO()
        fig.savefig(buf, format=GRAPH_IMAGE_FORMAT, bbox_inches="tight")
        plt.close(fig)
        buf.seek(0)
        with Image.open(buf) as img:
            pil_image = img.copy() if img.mode == "RGBA" else img.convert("RGBA")

        from mmrelay.matrix_utils import ImageUploadError, send_image

        try:
            await send_image(
                matrix_client, room.room_id, pil_image, TELEMETRY_GRAPH_FILENAME
            )
        except ImageUploadError:
            self.logger.exception("Failed to send telemetry graph")
            await matrix_client.room_send(
                room_id=room.room_id,
                message_type=MATRIX_EVENT_TYPE_ROOM_MESSAGE,
                content={
                    "msgtype": "m.notice",
                    "body": MSG_GRAPH_UPLOAD_FAILED,
                },
            )
            return True
        return True
