"""
Test cases for the __main__.py module entry point.

This module tests the alternative entry point for MMRelay that provides
Windows compatibility and fallback functionality when setuptools console
scripts fail.
"""

import os
import runpy
import sys
import unittest
from unittest.mock import patch

# Add src to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from mmrelay.constants.app import EXIT_CODE_SIGINT


def _run_main_module() -> None:
    """
    Execute mmrelay.__main__ as if run with python -m mmrelay.

    Clears mmrelay modules from sys.modules to ensure fresh execution.
    """
    saved_modules = {
        name: module
        for name, module in sys.modules.items()
        if name == "mmrelay" or name.startswith("mmrelay.")
    }

    # Clear only the modules that trigger stale-import runtime warnings when
    # executing the entry point via runpy.
    sys.modules.pop("mmrelay.paths", None)
    sys.modules.pop("mmrelay.__main__", None)
    sys.modules.pop("mmrelay.main", None)
    sys.modules.pop("mmrelay", None)
    try:
        runpy.run_module("mmrelay.__main__", run_name="__main__")
    finally:
        # Restore original module graph to avoid leaking fresh package/module
        # objects into later tests that already captured function globals.
        for module_name in list(sys.modules):
            if module_name == "mmrelay" or module_name.startswith("mmrelay."):
                sys.modules.pop(module_name, None)
        sys.modules.update(saved_modules)


class TestMainEntryPoint(unittest.TestCase):
    """Test cases for __main__.py module functionality."""

    def setUp(self):
        """
        Save a copy of sys.argv before each test.

        Preserves the original command-line arguments so individual tests can modify sys.argv and restore it in tearDown.
        """
        self.original_argv = sys.argv.copy()

    def tearDown(self):
        """
        Restore sys.argv to its pre-test value.

        Replaces the process-wide sys.argv with the copy saved in setUp to avoid leaking
        test-specific command-line arguments between tests.
        """
        sys.argv = self.original_argv

    @patch("mmrelay.cli.main")
    @patch("sys.exit")
    def test_main_entry_point_success(self, mock_exit, mock_main):
        """Test successful execution of main entry point."""
        mock_main.return_value = 0

        _run_main_module()

        mock_main.assert_called_once()
        mock_exit.assert_called_once_with(0)

    @patch("mmrelay.cli.main", side_effect=ImportError("Module not found"))
    @patch("builtins.print")
    @patch("sys.exit")
    def test_main_entry_point_import_error(self, mock_exit, mock_print, mock_main):
        """
        Verify that when mmrelay.cli.main raises ImportError, the package entry point prints two specific error messages to stderr and exits with status 1.

        The test executes src/mmrelay/__main__.py with __name__ == "__main__" while mmrelay.cli.main is patched to raise ImportError("Module not found"), then asserts:
        - "Error importing MMRelay CLI: Module not found" is printed to stderr.
        - "Please ensure MMRelay is properly installed." is printed to stderr.
        - sys.exit is called with code 1.
        """
        _run_main_module()

        mock_print.assert_any_call(
            "Error importing MMRelay CLI: Module not found", file=sys.stderr
        )
        mock_print.assert_any_call(
            "Please ensure MMRelay is properly installed.", file=sys.stderr
        )
        mock_exit.assert_called_once_with(1)

    @patch("mmrelay.cli.main", side_effect=KeyboardInterrupt())
    @patch("builtins.print")
    @patch("sys.exit")
    def test_main_entry_point_keyboard_interrupt(
        self, mock_exit, mock_print, mock_main
    ):
        """Test handling of KeyboardInterrupt."""
        _run_main_module()

        mock_print.assert_called_once_with("Interrupted.", file=sys.stderr)
        mock_exit.assert_called_once_with(EXIT_CODE_SIGINT)

    @patch("mmrelay.cli.main", side_effect=KeyboardInterrupt())
    @patch("builtins.print")
    @patch("sys.exit")
    def test_main_entry_point_keyboard_interrupt_falls_back_to_130_on_import_error(
        self, mock_exit, mock_print, _mock_main
    ):
        """KeyboardInterrupt branch should use exit 130 when EXIT_CODE_SIGINT import fails."""
        import builtins as _builtins

        real_import = _builtins.__import__

        def _import_side_effect(name, globs=None, locs=None, fromlist=(), level=0):
            if "mmrelay.constants" in name:
                raise ImportError("constants unavailable")
            return real_import(name, globs, locs, fromlist, level)

        with patch("builtins.__import__", side_effect=_import_side_effect):
            _run_main_module()

        mock_print.assert_called_once_with("Interrupted.", file=sys.stderr)
        mock_exit.assert_called_once_with(130)

    @patch("mmrelay.cli.main", side_effect=SystemExit(42))
    @patch("sys.exit")
    def test_main_entry_point_system_exit_passthrough(self, mock_exit, mock_main):
        """
        Verify that a SystemExit raised by mmrelay.cli.main is propagated unchanged when executing __main__.py.

        Executes the package's __main__ module as a script (via exec with __name__ == "__main__") and asserts the raised SystemExit carries the original exit code (42), ensuring passthrough behavior rather than being swallowed or remapped.
        """
        with self.assertRaises(SystemExit) as cm:
            _run_main_module()

        self.assertEqual(cm.exception.code, 42)

    @patch("mmrelay.cli.main", side_effect=RuntimeError("Unexpected error"))
    @patch("builtins.print")
    @patch("sys.exit")
    def test_main_entry_point_unexpected_exception(
        self, mock_exit, mock_print, mock_main
    ):
        """
        Verify that an unexpected exception raised by mmrelay.cli.main is reported to stderr and causes the process to exit with code 1.

        Executes src/mmrelay/__main__.py with __name__ set to "__main__" (the test patches mmrelay.cli.main to raise a RuntimeError). Asserts that a single error message of the form "Unexpected error: <message>" is printed to stderr and that sys.exit is called with 1.
        """
        _run_main_module()

        mock_print.assert_called_once_with(
            "Unexpected error: Unexpected error", file=sys.stderr
        )
        mock_exit.assert_called_once_with(1)

    def test_main_entry_point_module_structure(self):
        """Test that the __main__.py module has the expected structure."""
        # Read the module content
        with open("src/mmrelay/__main__.py", "r") as f:
            content = f.read()

        # Check for expected components
        self.assertIn('if __name__ == "__main__":', content)
        self.assertIn("from mmrelay.cli import main", content)
        self.assertIn("sys.exit(main())", content)
        self.assertIn("ImportError", content)
        self.assertIn("KeyboardInterrupt", content)
        self.assertIn("SystemExit", content)

    def test_main_entry_point_docstring(self):
        """
        Verify mmrelay.__main__ provides the expected module docstring.

        Checks that the module-level docstring exists and contains the phrases
        "Alternative entry point", "Windows", and "python -m mmrelay", which
        are required for user guidance and compatibility notes.
        """
        # Import the module to check its docstring
        import mmrelay.__main__

        doc = mmrelay.__main__.__doc__
        self.assertIsNotNone(doc)
        self.assertIn("Alternative entry point", doc)
        self.assertIn("Windows", doc)
        self.assertIn("python -m mmrelay", doc)

    @patch("mmrelay.cli.main")
    @patch("sys.exit")
    def test_main_entry_point_with_arguments(self, mock_exit, mock_main):
        """Test main entry point execution with command line arguments."""
        mock_main.return_value = 5
        sys.argv = ["python", "-m", "mmrelay", "--help"]

        _run_main_module()

        mock_main.assert_called_once()
        mock_exit.assert_called_once_with(5)

    def test_main_entry_point_imports(self):
        """Test that the __main__.py module can import required modules."""
        # This test verifies that the import structure is correct
        try:
            import sys

            # The module should be able to import sys
            self.assertTrue(hasattr(sys, "exit"))
            self.assertTrue(hasattr(sys, "stderr"))
        except ImportError as e:
            self.fail(f"Failed to import required modules: {e}")


class TestMainEntryPointIntegration(unittest.TestCase):
    """Integration tests for __main__.py module."""

    def test_main_entry_point_can_be_executed_as_module(self):
        """Test that the main entry point can be executed as a module."""
        # This is more of a structural test to ensure the module is set up correctly
        import subprocess  # nosec B404  # test: testing subprocess entry point behavior
        import sys

        # Try to run the module with --help to see if it executes without import errors
        try:
            result = subprocess.run(  # noqa: S603  # nosec B603  # test: running program under test via subprocess
                [sys.executable, "-m", "mmrelay", "--help"],
                capture_output=True,
                text=True,
                timeout=10,
                cwd=os.path.join(os.path.dirname(__file__), ".."),
            )
            # We expect this to either succeed or fail with a specific error
            # The important thing is that it doesn't fail with ImportError
            self.assertNotIn("ImportError", result.stderr)
        except subprocess.TimeoutExpired:
            # If it times out, that's also acceptable - it means the module loaded
            pass
        except FileNotFoundError:
            # If mmrelay isn't installed, that's expected in test environment
            pass

    def test_main_entry_point_error_messages(self):
        """
        Verify that __main__.py emits correctly formatted error messages and directs them to stderr.

        Reads src/mmrelay/__main__.py and asserts the source contains:
        - a write to stderr (e.g., `file=sys.stderr`),
        - the import error guidance "Error importing MMRelay CLI" and "Please ensure MMRelay is properly installed",
        - interruption message "Interrupted",
        - and a generic failure prefix "Unexpected error".
        """
        # Read the module content to verify error message formatting
        with open("src/mmrelay/__main__.py", "r") as f:
            content = f.read()

        # Check that error messages are written to stderr
        self.assertIn("file=sys.stderr", content)

        # Check that error messages are descriptive
        self.assertIn("Error importing MMRelay CLI", content)
        self.assertIn("Please ensure MMRelay is properly installed", content)
        self.assertIn("Interrupted", content)
        self.assertIn("Unexpected error", content)


if __name__ == "__main__":
    unittest.main()
