from pathlib import Path
import sys


def main():
    from dotenv import load_dotenv
    load_dotenv(Path.cwd() / ".env", override=False)

    if sys.stdin.isatty():
        # Interactive terminal — full-screen TUI + HTTP server
        from edge8_mcp.tui import run_tui
        run_tui()
    else:
        # Piped (Claude Code stdio MCP) — silent, protocol only
        from mcp_server.server import mcp
        mcp.run(show_banner=False)


if __name__ == "__main__":
    main()
