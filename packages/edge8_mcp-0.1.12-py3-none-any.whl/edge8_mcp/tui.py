"""
Edge8 MCP — Full-screen terminal TUI (Rich-based).

Runs the MCP server over HTTP in a background thread while rendering
a live dashboard in the foreground terminal.
"""
from __future__ import annotations

import asyncio
import logging
import threading
import time
from collections import deque
from datetime import datetime
from importlib.metadata import version as pkg_version
from typing import Deque

from rich import box
from rich.align import Align
from rich.console import Console, Group
from rich.layout import Layout
from rich.live import Live
from rich.panel import Panel
from rich.text import Text

# ── Brand palette ─────────────────────────────────────────────────────────────
#   Lark blue  ──► Claude purple  (gradient across logo lines)
#   Zernio teal ── accent / tagline
_B = "rgb(51,112,255)"    # Lark blue
_P = "rgb(124,58,237)"    # Claude purple
_T = "rgb(0,178,178)"     # Zernio teal
_D = "grey50"

_PORT = 8080

try:
    _VERSION = pkg_version("edge8-mcp")
except Exception:
    _VERSION = "dev"

# ── Shared mutable state (GIL-safe for deque + list) ─────────────────────────
_logs: Deque[tuple[str, str, str]] = deque(maxlen=100)
_server_holder: list = []   # _server_holder[0] = uvicorn.Server after start


# ── Log interceptor ───────────────────────────────────────────────────────────
class _TUILogHandler(logging.Handler):
    _STYLES = {
        "DEBUG":    _D,
        "INFO":     _B,
        "WARNING":  "yellow",
        "ERROR":    "red",
        "CRITICAL": "bold red",
    }

    def emit(self, record: logging.LogRecord) -> None:
        ts = datetime.fromtimestamp(record.created).strftime("%H:%M:%S")
        _logs.append((ts, record.levelname, record.getMessage()[:120]))


# ── Logo ──────────────────────────────────────────────────────────────────────
_LOGO_LINES = [
    ("rgb(51,112,255)",  "  ███████╗██████╗  ██████╗ ███████╗ █████╗ "),
    ("rgb(75,90,252)",   "  ██╔════╝██╔══██╗██╔════╝ ██╔════╝██╔══██╗"),
    ("rgb(99,68,249)",   "  █████╗  ██║  ██║██║  ███╗█████╗  ╚█████╔╝"),
    ("rgb(111,63,248)",  "  ██╔══╝  ██║  ██║██║   ██║██╔══╝  ██╔══██╗"),
    ("rgb(124,58,237)",  "  ███████╗██████╔╝╚██████╔╝███████╗╚█████╔╝"),
    ("grey50",           "  ╚══════╝╚═════╝  ╚═════╝ ╚══════╝ ╚════╝ "),
]

# ── Render helpers ────────────────────────────────────────────────────────────
def _render_header() -> Panel:
    t = Text()
    for style, line in _LOGO_LINES:
        t.append(f"{line}\n", style=style)
    t.append(f"\n  Workspace Automation MCP", style=f"bold {_T}")
    t.append("  ·  ", style=_D)
    t.append("edge8.ai", style=f"bold {_T}")
    t.append(f"  ·  v{_VERSION}", style=_D)
    return Panel(t, box=box.ROUNDED, border_style=_D, padding=(0, 1))


def _render_status(running: bool) -> Panel:
    line = Text()
    if running:
        line.append("●  ", style="bold green")
        line.append(f"http://0.0.0.0:{_PORT}/mcp", style="white")
        line.append("   ·  Claude Code endpoint: ", style=_D)
        line.append(f"http://localhost:{_PORT}/mcp", style=f"bold {_T}")
    else:
        line.append("◌  ", style=f"bold {_D}")
        line.append("Starting server…", style=_D)
    return Panel(Align(line, align="center"), box=box.SIMPLE, border_style=_D)


def _render_tools(tools: list[dict]) -> Panel:
    _COLOR = {"lark": _B, "typeform": _T, "zernio": _P, "agent": "yellow"}
    groups: dict[str, list[str]] = {}
    for t in tools:
        prefix = t["name"].split("_")[0]
        groups.setdefault(prefix, []).append(t["name"])

    body = Text()
    for prefix, names in sorted(groups.items()):
        c = _COLOR.get(prefix, "white")
        body.append(f"\n  {prefix.upper()} ", style=f"bold {c}")
        body.append(f"({len(names)})\n", style=_D)
        for name in names[:6]:
            body.append(f"    ├─ {name}\n", style=_D)
        if len(names) > 6:
            body.append(f"    └─ +{len(names) - 6} more\n", style=_D)

    total = sum(len(v) for v in groups.values())
    return Panel(
        body,
        title=f"[bold {_B}] TOOLS ({total}) [/]",
        border_style=_B,
        box=box.ROUNDED,
    )


def _render_logs() -> Panel:
    rows = list(_logs)[-20:]
    if not rows:
        content: Text | Group = Text("  Waiting for activity…", style=_D)
    else:
        lines = []
        for ts, level, msg in rows:
            style = _TUILogHandler._STYLES.get(level, "white")
            row = Text(no_wrap=True)
            row.append(f"  {ts}  ", style=_D)
            row.append(f"{level:<8}", style=style)
            row.append(msg, style="white")
            lines.append(row)
        content = Group(*lines)

    return Panel(
        content,
        title=f"[bold {_P}] ACTIVITY LOG [/]",
        border_style=_P,
        box=box.ROUNDED,
    )


def _render_footer() -> Text:
    t = Text(justify="center")
    t.append("Ctrl+C", style=f"bold {_T}")
    t.append("  to stop  ·  ", style=_D)
    t.append("Claude Code config: ", style=_D)
    t.append('{"command": "uvx", "args": ["edge8-mcp"]}', style="bold white")
    return t


# ── Background HTTP server ────────────────────────────────────────────────────
def _run_http_server(mcp, ready: threading.Event) -> None:
    """Run FastMCP over HTTP in its own asyncio event loop (background thread)."""
    import uvicorn

    app = mcp.http_app(path="/mcp")
    config = uvicorn.Config(
        app,
        host="0.0.0.0",
        port=_PORT,
        lifespan="on",
        log_level="info",
    )
    server = uvicorn.Server(config)
    server.install_signal_handlers = lambda: None   # main thread owns SIGINT

    _server_holder.append(server)

    # Patch startup to fire the ready event
    _orig_startup = server.startup

    async def _startup_with_signal(*a, **kw):
        await _orig_startup(*a, **kw)
        ready.set()

    server.startup = _startup_with_signal

    asyncio.run(server.serve())


# ── Public entry point ────────────────────────────────────────────────────────
def run_tui() -> None:
    """Launch the full-screen TUI. Blocks until Ctrl+C."""

    # Wire up log interception
    handler = _TUILogHandler()
    for name in ("fastmcp", "uvicorn", "uvicorn.error"):
        lg = logging.getLogger(name)
        lg.addHandler(handler)
        lg.setLevel(logging.DEBUG)
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)

    from mcp_server.server import mcp

    # Fetch registered tools (FastMCP list_tools is async)
    tools = asyncio.run(_fetch_tools(mcp))

    # Start HTTP server in background
    ready = threading.Event()
    thread = threading.Thread(
        target=_run_http_server,
        args=(mcp, ready),
        daemon=True,
    )
    thread.start()

    # Build layout skeleton
    layout = Layout()
    layout.split_column(
        Layout(name="header", size=10),   # logo (6) + tagline + borders
        Layout(name="status", size=3),
        Layout(name="body"),
        Layout(name="footer", size=3),
    )
    layout["body"].split_row(
        Layout(name="tools", minimum_size=34),
        Layout(name="logs", ratio=3),
    )

    console = Console()
    try:
        with Live(layout, console=console, screen=True, refresh_per_second=4):
            while True:
                layout["header"].update(_render_header())
                layout["status"].update(_render_status(ready.is_set()))
                layout["tools"].update(_render_tools(tools))
                layout["logs"].update(_render_logs())
                layout["footer"].update(
                    Align(_render_footer(), align="center", vertical="middle")
                )
                time.sleep(0.25)
    except KeyboardInterrupt:
        pass
    finally:
        if _server_holder:
            _server_holder[0].should_exit = True
        thread.join(timeout=3)


async def _fetch_tools(mcp) -> list[dict]:
    result = await mcp.list_tools()
    return [
        {"name": t.name, "description": getattr(t, "description", "")}
        for t in result
    ]
