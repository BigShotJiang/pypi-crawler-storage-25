"""
Agent Tools for Edge8 MCP Server

Provides daemon management and project registration tools for the Lark
agent worker system. Uses only stdlib + pyyaml — no FastAPI, Supabase,
or lark-oapi dependencies.
"""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml
from fastmcp import FastMCP

# ── Hook script installed globally at ~/.local/bin/edge8-check-project ────────
_HOOK_SCRIPT = """\
#!/usr/bin/env bash
# edge8-check-project — Claude Code PreToolUse hook
# Detects unregistered Lark agent definitions in the current project.
# Silent (no output, exit 0) when project is clean or already registered.

# Cache: only check once per CWD (reset naturally when CWD changes)
_hash() { echo -n "$1" | md5 2>/dev/null || echo -n "$1" | md5sum | cut -d' ' -f1; }
CACHE="/tmp/edge8-chk-$(_hash "$PWD")"
[ -f "$CACHE" ] && exit 0
touch "$CACHE"

# Find agent definitions in CWD
AGENTS_DIR=""
for candidate in "$PWD/lark-agents" "$PWD/.claude/agents" "$PWD/agents"; do
    [ -d "$candidate" ] && { AGENTS_DIR="$candidate"; break; }
done
[ -z "$AGENTS_DIR" ] && exit 0

# Already registered? (path appears in registry)
REGISTRY="$HOME/.edge8/agent_registry.yaml"
if [ -f "$REGISTRY" ]; then
    grep -qF "$AGENTS_DIR" "$REGISTRY" 2>/dev/null && exit 0
fi

# Count non-hidden, non-router agent dirs / md files
COUNT=$(find "$AGENTS_DIR" -mindepth 1 -maxdepth 1 \\( -type d -o -name "*.md" \\) \\
    ! -name '_*' ! -name '.*' | wc -l | tr -d ' ')
[ "$COUNT" -eq 0 ] && exit 0

echo "edge8: $COUNT agent(s) in $AGENTS_DIR are not registered with the Lark daemon. Call lark_register_project to connect them."
"""


def register_agent_tools(mcp: FastMCP) -> None:
    """Register agent daemon management tools with the MCP server."""

    @mcp.tool()
    async def lark_daemon_status() -> dict:
        """Check if the Lark agent daemon is running on this machine."""
        try:
            result = subprocess.run(
                ["launchctl", "list"],
                capture_output=True,
                text=True,
            )
            label = "com.edge8.lark-agent-worker"
            for line in result.stdout.splitlines():
                if label in line:
                    parts = line.split()
                    # launchctl list columns: PID  Status  Label
                    pid_str = parts[0] if parts else "-"
                    pid = None if pid_str == "-" else int(pid_str)
                    return {
                        "running": pid is not None,
                        "pid": pid,
                        "label": label,
                    }
            return {"running": False, "pid": None, "label": label}
        except Exception as e:
            return {"running": False, "error": str(e)}

    @mcp.tool()
    async def lark_register_project(
        root: str,
        app_id: str,
        name: str,
    ) -> dict:
        """Register a project's agent workspaces with the local Lark daemon.

        Args:
            root: Absolute path to the project's lark-agents/ or .claude/agents/ directory
            app_id: Lark App ID (format: cli_xxxxxxxx)
            name: Human-readable project name
        """
        root_path = Path(root)
        if not root_path.exists():
            return {"registered": False, "error": f"Path does not exist: {root}"}

        # ── Detect format ──────────────────────────────────────────────────────
        root_str = str(root_path)
        is_format_b = root_str.endswith(".claude/agents") or root_str.endswith(
            ".claude/agents/"
        )

        # Also check contents: Format B has .md files with YAML frontmatter
        if not is_format_b:
            md_files = list(root_path.glob("*.md"))
            if md_files:
                try:
                    content = md_files[0].read_text(encoding="utf-8")
                    if content.startswith("---"):
                        is_format_b = True
                except OSError:
                    pass

        agents: List[Dict[str, Any]] = []

        if is_format_b:
            # Format B: .md files with YAML frontmatter
            for md_file in sorted(root_path.glob("*.md")):
                try:
                    content = md_file.read_text(encoding="utf-8")
                    if not content.startswith("---"):
                        continue
                    end = content.index("---", 3)
                    frontmatter = yaml.safe_load(content[3:end])
                    if isinstance(frontmatter, dict):
                        agents.append(
                            {
                                "id": md_file.stem,
                                "display_name": frontmatter.get(
                                    "name", md_file.stem
                                ),
                                "description": frontmatter.get("description", ""),
                            }
                        )
                except (OSError, ValueError, yaml.YAMLError):
                    continue
        else:
            # Format A: subdirectories (exclude _router), each with CLAUDE.md
            for subdir in sorted(root_path.iterdir()):
                if not subdir.is_dir() or subdir.name.startswith("_"):
                    continue
                claude_md = subdir / "CLAUDE.md"
                display_name = subdir.name
                description = ""
                if claude_md.exists():
                    try:
                        lines = claude_md.read_text(encoding="utf-8").splitlines()
                        for line in lines:
                            stripped = line.strip()
                            if stripped.startswith("# "):
                                display_name = stripped[2:].strip()
                                break
                        # Next non-empty line after heading = description
                        found_heading = False
                        for line in lines:
                            stripped = line.strip()
                            if stripped.startswith("# "):
                                found_heading = True
                                continue
                            if found_heading and stripped:
                                description = stripped
                                break
                    except OSError:
                        pass
                agents.append(
                    {
                        "id": subdir.name,
                        "display_name": display_name,
                        "description": description,
                    }
                )

        # ── Locate registry ────────────────────────────────────────────────────
        registry_path: Optional[Path] = None

        env_path = os.getenv("EDGE8_REGISTRY_PATH")
        if env_path:
            registry_path = Path(env_path)
        else:
            home_path = Path.home() / ".edge8" / "agent_registry.yaml"
            if home_path.exists():
                registry_path = home_path
            else:
                cwd_path = Path.cwd() / "config" / "agent_registry.yaml"
                if cwd_path.exists():
                    registry_path = cwd_path
                else:
                    # Fall back to home path (will be created)
                    registry_path = home_path

        # ── Read / create registry ─────────────────────────────────────────────
        if registry_path.exists():
            try:
                data = yaml.safe_load(registry_path.read_text(encoding="utf-8")) or {}
            except yaml.YAMLError:
                data = {}
        else:
            data = {}

        if not isinstance(data.get("projects"), list):
            data["projects"] = []

        # ── Upsert by app_id ───────────────────────────────────────────────────
        project_entry = {
            "app_id": app_id,
            "name": name,
            "root": str(root_path),
            "agents": [
                {
                    "id": a["id"],
                    "display_name": a["display_name"],
                    "description": a["description"],
                }
                for a in agents
            ],
        }

        existing_index = next(
            (i for i, p in enumerate(data["projects"]) if p.get("app_id") == app_id),
            None,
        )
        if existing_index is not None:
            data["projects"][existing_index] = project_entry
        else:
            data["projects"].append(project_entry)

        # ── Write back ─────────────────────────────────────────────────────────
        registry_path.parent.mkdir(parents=True, exist_ok=True)
        registry_path.write_text(
            yaml.dump(data, default_flow_style=False, allow_unicode=True),
            encoding="utf-8",
        )

        return {
            "registered": True,
            "agents": [a["id"] for a in agents],
            "registry_path": str(registry_path),
        }

    @mcp.tool()
    async def lark_daemon_start() -> dict:
        """Start the Lark agent daemon via launchctl."""
        label = "com.edge8.lark-agent-worker"
        plist_path = (
            Path.home() / "Library" / "LaunchAgents" / f"{label}.plist"
        )
        if not plist_path.exists():
            return {
                "started": False,
                "error": (
                    f"Plist not found at {plist_path}. "
                    "Run setup.sh first to install the daemon, "
                    "then retry lark_daemon_start."
                ),
            }
        try:
            result = subprocess.run(
                ["launchctl", "start", label],
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                return {"started": True}
            return {
                "started": False,
                "error": result.stderr.strip() or f"exit code {result.returncode}",
            }
        except Exception as e:
            return {"started": False, "error": str(e)}

    @mcp.tool()
    async def lark_global_setup() -> dict:
        """Install edge8-mcp globally for Claude Code on this machine.

        Performs three steps:
        1. Writes the edge8-check-project hook script to ~/.local/bin/
        2. Adds the PreToolUse hook to ~/.claude/settings.json
        3. Adds the MCP server entry to ~/.claude/mcp.json

        Safe to run multiple times — all steps are idempotent.
        After this, restart Claude Code for changes to take effect.
        """
        home = Path.home()
        steps: List[str] = []

        # ── 1. Hook script ─────────────────────────────────────────────────
        bin_dir = home / ".local" / "bin"
        bin_dir.mkdir(parents=True, exist_ok=True)
        hook_path = bin_dir / "edge8-check-project"
        hook_path.write_text(_HOOK_SCRIPT, encoding="utf-8")
        hook_path.chmod(0o755)
        steps.append(f"hook_script: written to {hook_path}")

        # ── 2. ~/.claude/settings.json — PreToolUse hook ───────────────────
        settings_path = home / ".claude" / "settings.json"
        settings_path.parent.mkdir(parents=True, exist_ok=True)

        settings: Dict[str, Any] = {}
        if settings_path.exists():
            try:
                settings = json.loads(settings_path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                settings = {}

        hooks = settings.setdefault("hooks", {})
        pre = hooks.setdefault("PreToolUse", [])

        hook_cmd = str(hook_path)
        already = any(
            hook_cmd in json.dumps(entry)
            for entry in pre
        )
        if not already:
            pre.append({
                "matcher": "Bash",
                "hooks": [{"type": "command", "command": hook_cmd}],
            })
            settings_path.write_text(
                json.dumps(settings, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
            steps.append(f"settings: PreToolUse hook added to {settings_path}")
        else:
            steps.append("settings: hook already present — skipped")

        # ── 3. ~/.claude/mcp.json — MCP server entry ──────────────────────
        mcp_path = home / ".claude" / "mcp.json"
        mcp_config: Dict[str, Any] = {}
        if mcp_path.exists():
            try:
                mcp_config = json.loads(mcp_path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                mcp_config = {}

        servers = mcp_config.setdefault("mcpServers", {})
        if "edge8-mcp" not in servers:
            servers["edge8-mcp"] = {"command": "uvx", "args": ["edge8-mcp"]}
            mcp_path.write_text(
                json.dumps(mcp_config, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
            steps.append(f"mcp.json: edge8-mcp server added to {mcp_path}")
        else:
            steps.append("mcp.json: edge8-mcp already present — skipped")

        return {
            "success": True,
            "steps": steps,
            "next": "Restart Claude Code for the MCP server and hook to take effect.",
        }
