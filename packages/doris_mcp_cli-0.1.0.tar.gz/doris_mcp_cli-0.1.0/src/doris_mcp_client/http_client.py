"""HTTP client for non-MCP endpoints (auth, semantic push/pull/reload/status)."""

from __future__ import annotations

import io
import json
import os
import tarfile
from pathlib import Path
from typing import Any

import httpx

# CLI connects to a user-configured MCP server — typically on localhost or an
# intranet. Honoring system-wide HTTP_PROXY (httpx's default trust_env=True
# behavior) breaks these connections whenever the user has a global proxy set
# (common on macOS with VPN/proxy tools). We disable it by default; users who
# need to reach a remote server through a proxy can set
# DORIS_MCP_USE_SYSTEM_PROXY=1 to opt in to httpx's standard proxy discovery.
def _use_system_proxy() -> bool:
    val = os.environ.get("DORIS_MCP_USE_SYSTEM_PROXY", "").strip().lower()
    return val in ("1", "true", "yes", "on")


def _client(**overrides) -> httpx.Client:
    """Create an httpx.Client with CLI-appropriate defaults.

    trust_env is a hard-override, not a default: letting callers pass
    trust_env=True would silently re-enable the system proxy that causes
    502s on machines with a global HTTP proxy set. Users who genuinely
    need proxy support must opt in via DORIS_MCP_USE_SYSTEM_PROXY.
    """
    opts = {"timeout": 60}
    opts.update(overrides)
    opts["trust_env"] = _use_system_proxy()
    return httpx.Client(**opts)


def _wrap_httpx(url: str, op: str, func):
    """Run an httpx call and convert httpx.* exceptions to RuntimeError.

    CLI callers catch RuntimeError + ValueError and print a clean message.
    Without this wrapper, lower-level httpx exceptions (InvalidURL,
    UnsupportedProtocol, ConnectError, TimeoutException, ...) bubble up
    and produce a rich traceback. Every network call in this module must
    go through here to keep the UX consistent.
    """
    try:
        return func()
    except httpx.InvalidURL as e:
        raise RuntimeError(f"Invalid URL '{url}': {e}") from None
    except httpx.UnsupportedProtocol as e:
        raise RuntimeError(
            f"Invalid URL '{url}': missing 'http://' or 'https://' scheme."
        ) from None
    except httpx.ConnectError as e:
        raise RuntimeError(
            f"Cannot connect to {url} ({op}). "
            "Check that the server is running and reachable."
        ) from None
    except httpx.TimeoutException:
        raise RuntimeError(f"Connection to {url} timed out during {op}.") from None
    except httpx.HTTPError as e:
        raise RuntimeError(f"Network error during {op}: {e}") from None


def auth_token(server_url: str, username: str, password: str) -> dict:
    """POST /api/auth/token — exchange credentials for token pair."""
    url = f"{server_url}/api/auth/token"

    def _call():
        with _client(timeout=30) as client:
            return client.post(url, json={"username": username, "password": password})

    resp = _wrap_httpx(url, "login", _call)
    if resp.status_code == 401:
        raise RuntimeError("Authentication failed: invalid username or password.")
    if resp.status_code == 501:
        # Server is not in OAuth mode — give a clear hint
        try:
            msg = resp.json().get("message", "")
        except Exception:
            msg = ""
        raise RuntimeError(
            msg or "This MCP server does not support username/password login. "
            "Use --token instead."
        )
    if resp.status_code != 200:
        _raise_for_error(resp)
    return resp.json()


def semantic_push(server_url: str, token: str, local_path: str) -> dict:
    """POST /api/semantic/push — upload YAML files from local_path."""
    path = Path(local_path)
    if not path.exists():
        raise FileNotFoundError(f"Path not found: {local_path}")

    # Collect YAML files as (relative_path, content) pairs
    files_to_upload: list[tuple[str, bytes]] = []
    if path.is_file():
        if not path.name.endswith((".yml", ".yaml")):
            raise ValueError(f"Not a YAML file: {path.name}")
        files_to_upload.append((path.name, path.read_bytes()))
    else:
        for root, _, filenames in os.walk(path):
            for fn in filenames:
                if not fn.endswith((".yml", ".yaml")):
                    continue
                full = Path(root) / fn
                rel = str(full.relative_to(path))
                files_to_upload.append((rel, full.read_bytes()))

    if not files_to_upload:
        raise ValueError(f"No YAML files found in {local_path}")

    # Build multipart
    multipart_files = [
        ("files", (rel, content, "application/x-yaml"))
        for rel, content in files_to_upload
    ]

    url = f"{server_url}/api/semantic/push"

    def _call():
        with _client(timeout=60) as client:
            return client.post(
                url,
                headers={"Authorization": f"Bearer {token}"},
                files=multipart_files,
            )

    resp = _wrap_httpx(url, "push", _call)
    if resp.status_code not in (200, 202):
        _raise_for_error(resp)
    return resp.json()


# Limits for semantic_pull. Aligned with server push limits so a roundtrip
# (push → pull) succeeds with the same content. Extra network-layer cap
# guards against decompression-bomb responses.
_MAX_RESPONSE_BYTES = 20 * 1024 * 1024   # 20MB on the wire (gzip compressed)
_MAX_EXTRACTED_BYTES = 10 * 1024 * 1024  # 10MB total after extraction
_MAX_EXTRACTED_FILE = 1 * 1024 * 1024    # 1MB per file after extraction
_MAX_MEMBER_COUNT = 10000                # Number of files in the tar


def semantic_pull(server_url: str, token: str, output_dir: str) -> int:
    """GET /api/semantic/pull — download and extract models tar.gz.

    Returns the number of files extracted.

    Safety:
      - Total response body size limited (防 network-layer bomb)
      - Total extracted size limited (防 decompression bomb)
      - Per-file extracted size limited (consistent with server push limit)
      - Member count limited (防 header flooding)
      - Extract to a staging tmp dir first; only move to output on success
      - tarfile filter="data" rejects absolute paths, .., symlinks, devices
    """
    url = f"{server_url}/api/semantic/pull"

    def _call():
        with _client(timeout=60) as client:
            return client.get(url, headers={"Authorization": f"Bearer {token}"})

    resp = _wrap_httpx(url, "pull", _call)
    if resp.status_code != 200:
        _raise_for_error(resp)

    if len(resp.content) > _MAX_RESPONSE_BYTES:
        raise RuntimeError(
            f"Pull response too large ({len(resp.content)} bytes, "
            f"max {_MAX_RESPONSE_BYTES}). Possible compression bomb."
        )

    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    # Stage to a tmp dir next to output; only move to out after full validation.
    import shutil
    import tempfile
    staging = Path(tempfile.mkdtemp(prefix=".doris-mcp-pull-", dir=str(out.parent)))
    try:
        count, total_bytes = _extract_with_limits(resp.content, staging)

        # All checks passed: atomic replace of output with staging content.
        # Copy files over so existing files in `out` are updated; we don't
        # rm out because user may have other files there.
        for root, _, filenames in os.walk(staging):
            for fn in filenames:
                src = Path(root) / fn
                rel = src.relative_to(staging)
                dst = out / rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(str(src), str(dst))
        return count
    finally:
        shutil.rmtree(staging, ignore_errors=True)


def _extract_with_limits(tar_bytes: bytes, dest: Path) -> tuple[int, int]:
    """Extract tar.gz to dest, enforcing size/count limits. Stream members."""
    count = 0
    total_bytes = 0
    buf = io.BytesIO(tar_bytes)
    with tarfile.open(fileobj=buf, mode="r:gz") as tar:
        # Iterate members as a stream (do NOT call getmembers() — that
        # parses all headers into memory up front; a tar with millions of
        # tiny headers could OOM us before we see the first byte of data).
        for member in tar:
            count += 1
            if count > _MAX_MEMBER_COUNT:
                raise RuntimeError(
                    f"Too many entries in archive (>{_MAX_MEMBER_COUNT}). "
                    "Possible header flooding attack."
                )
            if member.isfile():
                if member.size > _MAX_EXTRACTED_FILE:
                    raise RuntimeError(
                        f"File '{member.name}' too large "
                        f"({member.size} bytes, max {_MAX_EXTRACTED_FILE})."
                    )
                total_bytes += member.size
                if total_bytes > _MAX_EXTRACTED_BYTES:
                    raise RuntimeError(
                        f"Archive total size exceeds {_MAX_EXTRACTED_BYTES} bytes "
                        "after extraction. Possible decompression bomb."
                    )
            # Extract with 3.12 data filter (rejects .., absolute paths,
            # symlinks, devices, clamps permissions).
            tar.extract(member, path=str(dest), filter="data")
    # Recount actual extracted files (member loop counts dirs too)
    file_count = 0
    for _, _, filenames in os.walk(dest):
        file_count += len(filenames)
    return file_count, total_bytes


def semantic_reload(server_url: str, token: str) -> dict:
    """POST /api/reload-semantic-layer — trigger reload."""
    url = f"{server_url}/api/reload-semantic-layer"

    def _call():
        with _client(timeout=30) as client:
            return client.post(url, headers={"Authorization": f"Bearer {token}"})

    resp = _wrap_httpx(url, "reload", _call)
    if resp.status_code != 200:
        _raise_for_error(resp)
    return resp.json()


def semantic_result(server_url: str, token: str, request_id: str) -> dict:
    """GET /api/semantic/push/{request_id} — query async push result.

    Returns the full JSON response dict. Possible states (under data.state):
      - success            — push + validation + reload all succeeded
      - validation_failed  — bootstrap failed, source store NOT modified
      - failed             — validation passed but commit/reload failed
      - pending            — still being processed
    404 from server (not_found) is also raised as RuntimeError; CLI treats
    that as a distinct exit code.
    """
    url = f"{server_url}/api/semantic/push/{request_id}"

    def _call():
        with _client(timeout=30) as client:
            return client.get(url, headers={"Authorization": f"Bearer {token}"})

    resp = _wrap_httpx(url, "push result query", _call)
    if resp.status_code == 404:
        raise RuntimeError(
            f"No push request found with id '{request_id}'. "
            "It may have been cleaned up, or the id is wrong."
        )
    if resp.status_code != 200:
        _raise_for_error(resp)
    return resp.json()


def semantic_status(server_url: str, token: str) -> dict:
    """Call check_service_health via MCP to get semantic layer status.

    Uses the HTTP health endpoint if available, otherwise falls back
    to MCP tool call.
    """
    from doris_mcp_client.mcp_client import tool_call
    result = tool_call(server_url, token, "check_service_health", {"detail": True})
    return result


import re

# Patterns that look like secrets — used to mask output under --verbose
_TOKEN_PATTERNS = [
    re.compile(r"Bearer\s+\S+", re.IGNORECASE),
    re.compile(r"sk-[\w\-]+"),
    # Long base64-ish strings (≥30 chars of [A-Za-z0-9_-]) — catches most
    # access tokens, JWTs (by piece), and opaque opaque bearer tokens.
    re.compile(r"[A-Za-z0-9_\-]{30,}"),
]


def _mask_secrets(text: str) -> str:
    """Replace anything that looks like a token with a masked placeholder."""
    for pat in _TOKEN_PATTERNS:
        text = pat.sub("***REDACTED***", text)
    return text


def _is_debug() -> bool:
    """True if DORIS_MCP_DEBUG=1 is set in the environment."""
    val = os.environ.get("DORIS_MCP_DEBUG", "").strip().lower()
    return val in ("1", "true", "yes", "on")


def _raise_for_error(resp: httpx.Response) -> None:
    """Raise RuntimeError with server error details.

    Default: only status code + error.message (if response is standard JSON).
    Debug (DORIS_MCP_DEBUG=1): append a token-masked preview of the body.
    """
    msg = None
    try:
        body = resp.json()
        if isinstance(body, dict):
            err = body.get("error", {})
            if isinstance(err, dict):
                msg = err.get("message")
            elif isinstance(err, str):
                msg = err
    except (ValueError, TypeError):
        pass

    if msg:
        base = f"Server error (HTTP {resp.status_code}): {msg}"
    else:
        base = f"Server error (HTTP {resp.status_code})"

    if _is_debug():
        # Include response body for debugging, but mask anything that
        # looks like a secret to avoid leaking tokens via logs/screenshots.
        preview = resp.text[:2000]
        base += f"\n--- response body (debug, masked) ---\n{_mask_secrets(preview)}"

    raise RuntimeError(base)
