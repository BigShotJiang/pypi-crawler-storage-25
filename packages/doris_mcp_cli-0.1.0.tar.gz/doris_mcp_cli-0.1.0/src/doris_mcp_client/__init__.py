"""Doris MCP CLI client."""

import sys as _sys

# tarfile's `filter="data"` parameter — used by semantic pull to reject
# path traversal / symlink / device files — was backported to 3.11.4,
# 3.10.12, 3.9.17 per PEP 706. Earlier patch releases of 3.11 (and pip
# installers that honor only the major.minor requirement) may slip past
# the pyproject.toml constraint, so enforce at runtime.
if _sys.version_info < (3, 11, 4):
    raise RuntimeError(
        f"doris-mcp-client requires Python >= 3.11.4 "
        f"(for tarfile data filter, PEP 706). "
        f"Current: {_sys.version.split()[0]}"
    )

__version__ = "0.1.0"
