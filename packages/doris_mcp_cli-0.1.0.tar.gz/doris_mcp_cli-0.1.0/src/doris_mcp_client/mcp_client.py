"""FastMCP Client wrapper for MCP tool operations."""

from __future__ import annotations

import asyncio
from typing import Any

import httpx
from fastmcp import Client
from fastmcp.client.transports import StreamableHttpTransport


def _httpx_async_factory(**kwargs) -> httpx.AsyncClient:
    """Build an httpx.AsyncClient with trust_env hard-overridden.

    CLI targets a user-configured MCP server (often localhost/intranet) and
    should not route requests through the system HTTP proxy. This factory is
    passed to StreamableHttpTransport so fastmcp's internal httpx client
    inherits the same policy as our direct http_client.py calls.

    trust_env is a hard-override (not setdefault): if fastmcp ever starts
    passing trust_env=True internally, setdefault would silently let the
    system proxy back in. Users who need proxy support must opt in via
    DORIS_MCP_USE_SYSTEM_PROXY=1 — same contract as http_client._client().

    Accepts **kwargs to stay forward-compatible with fastmcp's factory
    contract (it may pass headers, timeout, auth, follow_redirects, etc.).
    """
    from doris_mcp_client.http_client import _use_system_proxy
    kwargs["trust_env"] = _use_system_proxy()
    return httpx.AsyncClient(**kwargs)


async def _run_with_client(server_url: str, token: str, coro_factory):
    """Create a fastmcp Client, connect, run the coroutine, return result."""
    transport = StreamableHttpTransport(
        f"{server_url}/mcp",
        headers={"Authorization": f"Bearer {token}"},
        httpx_client_factory=_httpx_async_factory,
    )
    async with Client(transport) as client:
        return await coro_factory(client)


def _run(server_url: str, token: str, op: str, coro_factory):
    """Run an MCP coroutine and convert transport / protocol exceptions to
    RuntimeError so the CLI's outer except (RuntimeError, ValueError) can
    display a clean one-line error instead of a rich traceback.
    """
    try:
        return asyncio.run(_run_with_client(server_url, token, coro_factory))
    except httpx.InvalidURL as e:
        raise RuntimeError(f"Invalid URL '{server_url}': {e}") from None
    except httpx.UnsupportedProtocol:
        raise RuntimeError(
            f"Invalid URL '{server_url}': missing 'http://' or 'https://' scheme."
        ) from None
    except httpx.ConnectError:
        raise RuntimeError(
            f"Cannot connect to {server_url} ({op}). "
            "Check that the server is running and reachable."
        ) from None
    except httpx.TimeoutException:
        raise RuntimeError(f"Connection to {server_url} timed out during {op}.") from None
    except httpx.HTTPStatusError as e:
        code = e.response.status_code
        if code == 401:
            raise RuntimeError(
                f"Authentication failed (HTTP 401) during {op}. "
                "Credentials may be expired or rejected by the server."
            ) from None
        if code == 403:
            raise RuntimeError(
                f"Permission denied (HTTP 403) during {op}. "
                "Your token is valid but lacks permission for this operation."
            ) from None
        raise RuntimeError(
            f"Server error during {op}: HTTP {code}"
        ) from None
    except RuntimeError:
        # Upstream already produced a clean message; don't wrap twice.
        raise
    except Exception as e:
        # Any other unexpected error from fastmcp / mcp SDK — present a
        # concise message. Users can set DORIS_MCP_DEBUG=1 to see the full
        # type + message (still no traceback).
        import os
        if os.environ.get("DORIS_MCP_DEBUG", "").strip().lower() in ("1", "true", "yes", "on"):
            raise RuntimeError(f"{op} failed: {type(e).__name__}: {e}") from None
        raise RuntimeError(f"{op} failed: {e}") from None


def validate_token(server_url: str, token: str) -> None:
    """Verify a token works by making a minimal MCP call.

    Used by 'login --token' to fail fast before writing credentials.json.
    A successful list_tools call proves:
      - server is reachable
      - token is accepted by the server's auth provider
      - MCP protocol handshake succeeds

    Raises RuntimeError with a clear message on any failure (the _run
    wrapper translates 401/403 into user-facing wording).
    """
    async def _check(client: Client):
        await client.list_tools()
    _run(server_url, token, "token validation", _check)


def tool_list(server_url: str, token: str) -> list[dict[str, Any]]:
    """List all available MCP tools."""
    async def _tl(client: Client):
        tools = await client.list_tools()
        return [
            {"name": t.name, "description": t.description or ""}
            for t in tools
        ]
    return _run(server_url, token, "tool list", _tl)


def tool_describe(server_url: str, token: str, name: str) -> dict[str, Any]:
    """Get the full schema for a specific tool."""
    async def _td(client: Client):
        tools = await client.list_tools()
        for t in tools:
            if t.name == name:
                return {
                    "name": t.name,
                    "description": t.description or "",
                    "inputSchema": t.inputSchema if hasattr(t, "inputSchema") else {},
                }
        raise ValueError(f"Tool '{name}' not found")
    return _run(server_url, token, "tool describe", _td)


def tool_call(
    server_url: str,
    token: str,
    name: str,
    arguments: dict[str, Any],
) -> Any:
    """Call an MCP tool and return the result."""
    async def _tc(client: Client):
        return await client.call_tool(name, arguments)
    return _run(server_url, token, f"tool call '{name}'", _tc)
