"""Configuration resolution.

Priority: CLI parameters > environment variables > credentials.json active server.
"""

from __future__ import annotations

import os

from doris_mcp_client.auth import get_server_entry, get_active_name


def _get_env(name: str) -> str | None:
    """Read an env var and strip whitespace. Return None for missing/blank."""
    val = os.environ.get(name)
    if val is None:
        return None
    val = val.strip()
    return val if val else None


def resolve_server_url(name: str | None = None) -> str:
    """Resolve the server URL. Priority: CLI --name > env > active server."""
    # CLI --name is highest priority
    if name:
        entry = get_server_entry(name)
        if entry:
            return entry["server_url"]
        raise RuntimeError(f"Server '{name}' not found. Run 'doris-mcp-cli server login' first.")

    # Env var (for CI/scripts without credentials.json)
    env_url = _get_env("DORIS_MCP_SERVER_URL")
    if env_url:
        return env_url.rstrip("/")

    # Active server from credentials
    entry = get_server_entry(None)
    if entry:
        return entry["server_url"]

    raise RuntimeError(
        "No server configured. "
        "Set DORIS_MCP_SERVER_URL or run 'doris-mcp-cli server login'."
    )


def resolve_token(name: str | None = None) -> tuple[str, str]:
    """Resolve (server_url, bearer_token). Priority: CLI --name > env > active server."""
    # CLI --name is highest priority
    if name:
        from doris_mcp_client.auth import resolve_token as _resolve
        return _resolve(name)

    # Env vars (for CI/scripts) — both must be set (and non-blank) to use env path
    env_token = _get_env("DORIS_MCP_TOKEN")
    env_url = _get_env("DORIS_MCP_SERVER_URL")
    if env_token and env_url:
        return env_url.rstrip("/"), env_token

    # Active server from credentials
    from doris_mcp_client.auth import resolve_token as _resolve
    return _resolve(None)
