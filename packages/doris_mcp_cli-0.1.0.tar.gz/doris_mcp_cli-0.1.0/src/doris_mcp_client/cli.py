"""Doris MCP CLI — command line client for doris-mcp-pro."""

from __future__ import annotations

import json
import os
import sys
from typing import Annotated, Optional

import typer

from doris_mcp_client import formatting


def _verbose_callback(value: bool):
    """--verbose flag sets DORIS_MCP_DEBUG=1 for the current process.

    Downstream modules (http_client) read the env var to decide whether
    to include response-body detail in error messages.
    """
    if value:
        os.environ["DORIS_MCP_DEBUG"] = "1"


# pretty_exceptions_enable=False disables typer's rich traceback panel for
# unhandled exceptions. CLI users should see a concise error message, not
# internal Python stack frames. All command paths catch exceptions and echo
# a clean message; this flag is the last-resort backstop if one slips
# through. Debug mode (DORIS_MCP_DEBUG=1 / --verbose) still surfaces the
# exception type + message, just not the traceback.
app = typer.Typer(
    name="doris-mcp-cli",
    help="CLI client for doris-mcp-pro MCP server.",
    no_args_is_help=True,
    pretty_exceptions_enable=False,
)


@app.callback()
def main(
    verbose: Annotated[
        bool,
        typer.Option("--verbose", "-v", callback=_verbose_callback,
                     help="Show detailed error responses (tokens masked). "
                          "Equivalent to DORIS_MCP_DEBUG=1."),
    ] = False,
):
    """Doris MCP CLI — entry point callback for global flags."""
    pass
tool_app = typer.Typer(
    help="MCP tool operations.",
    no_args_is_help=True,
    pretty_exceptions_enable=False,
)
server_app = typer.Typer(
    help="Server connection management.",
    no_args_is_help=True,
    pretty_exceptions_enable=False,
)
semantic_app = typer.Typer(
    help="Semantic model management.",
    no_args_is_help=True,
    pretty_exceptions_enable=False,
)
app.add_typer(tool_app, name="tool")
app.add_typer(server_app, name="server")
app.add_typer(semantic_app, name="semantic")


# ========== server login ==========

@server_app.command("login")
def server_login(
    name: Annotated[str, typer.Option("--name", help="Name for this server connection (required)")],
    server: Annotated[str, typer.Option("--server", help="MCP server URL")] = "",
    token: Annotated[str, typer.Option("--token", help="Static token or JWT")] = "",
    user: Annotated[str, typer.Option("--user", help="Doris username (OAuth mode)")] = "",
    password: Annotated[str, typer.Option("--password", help="Doris password (OAuth mode)")] = "",
):
    """Register a new MCP server connection and store credentials locally."""
    from doris_mcp_client import auth, http_client

    if not name or not name.strip():
        typer.echo("Error: --name is required and must not be empty.", err=True)
        raise typer.Exit(1)
    name = name.strip()

    # Step 1: mutual exclusion check (before any prompts)
    if token and user:
        typer.echo("Error: --token and --user are mutually exclusive.", err=True)
        raise typer.Exit(1)

    # Step 2: interactive prompts for missing fields
    if not server:
        server = typer.prompt("Server URL")
    if not token and not user:
        # Custom-format the default hint instead of relying on typer's
        # auto-appended " [1]:". show_default=False suppresses typer's
        # bracket so we can show "[default:1]" for clarity.
        # Database credentials is the recommended path for most users, so it
        # sits at position 1 (the default).
        choice = typer.prompt(
            "Auth mode: 1) Database credentials  2) Static token [default:1]",
            default="1",
            show_default=False,
        )
        if choice == "1":
            user = typer.prompt("Username")
        else:
            token = typer.prompt("Token")
    if user and not password:
        password = typer.prompt("Password", hide_input=True)

    # Step 3: completeness check
    if not token and not user:
        typer.echo("Error: provide --token or --user/--password.", err=True)
        raise typer.Exit(1)

    # Step 4: URL format validation (before any network call)
    # Without this, httpx raises UnsupportedProtocol deep in the stack and
    # we'd either need to wrap every path or tolerate a rich traceback.
    server = server.strip()
    if not (server.startswith("http://") or server.startswith("https://")):
        typer.echo(
            f"Error: server URL must start with 'http://' or 'https://', got: {server!r}",
            err=True,
        )
        raise typer.Exit(1)

    # Step 5: same-name policy — allow overwrite ONLY when the server URL
    # matches the stored entry. This handles the common "re-login after
    # OAuth session expired" case without forcing `server remove` first,
    # while still guarding against typo'd --name (e.g. user meant 'dev'
    # but typed 'prod') by rejecting when URLs differ.
    existing = auth.get_server_entry(name)
    overwrite = False
    if existing is not None:
        stored_url = existing.get("server_url", "").rstrip("/")
        provided_url = server.rstrip("/")
        if stored_url == provided_url:
            overwrite = True
        else:
            typer.echo(
                f"Error: Server '{name}' already exists with a different URL.\n"
                f"  stored:   {stored_url}\n"
                f"  provided: {provided_url}\n"
                f"To replace, first run:\n"
                f"  doris-mcp-cli server remove {name}\n"
                f"Then re-run your login command.",
                err=True,
            )
            raise typer.Exit(1)

    try:
        if token:
            # Validate the token against the server BEFORE persisting.
            # Without this, users can silently register a wrong token in
            # OAuth-only mode and only discover the mistake on first tool
            # call. Credentials-mode already validates via /api/auth/token,
            # so no extra check is needed there.
            from doris_mcp_client import mcp_client
            mcp_client.validate_token(server.rstrip("/"), token)
            auth.register_token(name, server, token, overwrite=overwrite)
            action = "Updated" if overwrite else "Registered"
            typer.echo(f"{action} server '{name}' with static token.")
        else:
            result = http_client.auth_token(server.rstrip("/"), user, password)
            auth.register_credentials(
                name=name,
                server_url=server,
                access_token=result["access_token"],
                refresh_token=result["refresh_token"],
                expires_in=result["expires_in"],
                refresh_expires_in=result["refresh_expires_in"],
                username=user,
                overwrite=overwrite,
            )
            action = "Updated" if overwrite else "Registered"
            typer.echo(f"{action} server '{name}' with database credentials.")
    except (ValueError, RuntimeError) as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


# ========== server ==========

@server_app.command("list")
def server_list():
    """List all registered servers."""
    from doris_mcp_client import auth
    servers = auth.list_servers()
    formatting.print_server_list(servers)


@server_app.command("switch")
def server_switch(
    name: Annotated[str, typer.Argument(help="Server name to switch to")],
):
    """Switch the active server."""
    from doris_mcp_client import auth
    try:
        auth.switch_server(name)
        typer.echo(f"Switched active server to '{name}'.")
    except ValueError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@server_app.command("remove")
def server_remove(
    name: Annotated[str, typer.Argument(help="Server name to remove")],
):
    """Remove a registered server and its credentials."""
    from doris_mcp_client import auth
    try:
        auth.remove_server(name)
        typer.echo(f"Removed server '{name}'.")
    except ValueError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


# ========== tool ==========

def _resolve(name: str | None) -> tuple[str, str]:
    """Resolve server_url and token, exit on failure."""
    from doris_mcp_client.config import resolve_token
    try:
        return resolve_token(name)
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@tool_app.command("list")
def tool_list(
    name: Annotated[Optional[str], typer.Option("--name", help="Server name")] = None,
):
    """List all available MCP tools."""
    from doris_mcp_client import mcp_client
    server_url, token = _resolve(name)
    try:
        tools = mcp_client.tool_list(server_url, token)
        formatting.print_tool_list(tools)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@tool_app.command("describe")
def tool_describe(
    tool_name: Annotated[str, typer.Argument(help="Tool name")],
    name: Annotated[Optional[str], typer.Option("--name", help="Server name")] = None,
):
    """Show the full schema of a tool."""
    from doris_mcp_client import mcp_client
    server_url, token = _resolve(name)
    try:
        schema = mcp_client.tool_describe(server_url, token, tool_name)
        formatting.print_tool_schema(schema)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@tool_app.command("call")
def tool_call(
    tool_name: Annotated[str, typer.Argument(help="Tool name")],
    arg: Annotated[Optional[list[str]], typer.Option("--arg", help="key=value argument")] = None,
    json_arg: Annotated[Optional[str], typer.Option("--json", help="Full JSON arguments")] = None,
    name: Annotated[Optional[str], typer.Option("--name", help="Server name")] = None,
):
    """Call an MCP tool with arguments."""
    from doris_mcp_client import mcp_client

    if arg and json_arg:
        typer.echo("Error: --arg and --json are mutually exclusive.", err=True)
        raise typer.Exit(1)

    arguments: dict = {}
    if json_arg:
        try:
            arguments = json.loads(json_arg)
        except json.JSONDecodeError as e:
            typer.echo(f"Error: invalid JSON: {e}", err=True)
            raise typer.Exit(1)
    elif arg:
        for a in arg:
            if "=" not in a:
                typer.echo(f"Error: argument must be key=value, got: {a}", err=True)
                raise typer.Exit(1)
            k, v = a.split("=", 1)
            # Try to parse numeric/bool values
            try:
                arguments[k] = json.loads(v)
            except (json.JSONDecodeError, TypeError):
                arguments[k] = v

    server_url, token = _resolve(name)
    try:
        result = mcp_client.tool_call(server_url, token, tool_name, arguments)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)
    # print_tool_result returns False when the tool reported an error
    # (protocol-layer isError=True OR business-layer {"success": false}).
    # We exit non-zero in both cases so shell scripts can branch on $?.
    if not formatting.print_tool_result(result):
        raise typer.Exit(1)


# ========== semantic ==========

@semantic_app.command("push")
def semantic_push(
    local_path: Annotated[str, typer.Argument(help="Local directory or file to upload")],
    name: Annotated[Optional[str], typer.Option("--name", help="Server name")] = None,
):
    """Upload semantic model files to the server."""
    from doris_mcp_client import http_client
    server_url, token = _resolve(name)
    try:
        result = http_client.semantic_push(server_url, token, local_path)
        data = result.get("data", {})
        rid = data.get("request_id", "?")
        typer.echo(
            f"Push accepted: {data.get('file_count', '?')} files, request_id={rid}"
        )
        typer.echo(
            f"Server is processing asynchronously. "
            f"Use 'doris-mcp-cli semantic result {rid}' to check."
        )
    except (RuntimeError, FileNotFoundError, ValueError) as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@semantic_app.command("result")
def semantic_result(
    request_id: Annotated[str, typer.Argument(help="request_id returned by 'semantic push'")],
    name: Annotated[Optional[str], typer.Option("--name", help="Server name")] = None,
):
    """Query the result of an async semantic push.

    Exit codes:
      0  success
      1  failed / validation_failed / not_found / network error
      2  pending — still processing, try again later
    """
    from doris_mcp_client import http_client
    server_url, token = _resolve(name)
    try:
        result = http_client.semantic_result(server_url, token, request_id)
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)

    data = result.get("data", {}) if isinstance(result, dict) else {}
    state = data.get("state", "unknown")
    message = data.get("message", "")

    # Display
    typer.echo(f"Request: {data.get('request_id', request_id)}")
    typer.echo(f"State:   {state}")
    if message:
        typer.echo(f"Message: {message}")

    # Exit code: 0 success / 2 pending / 1 anything else
    if state == "success":
        raise typer.Exit(0)
    if state == "pending":
        raise typer.Exit(2)
    raise typer.Exit(1)


@semantic_app.command("pull")
def semantic_pull(
    output: Annotated[str, typer.Option("--output", help="Output directory")] = "./models",
    name: Annotated[Optional[str], typer.Option("--name", help="Server name")] = None,
):
    """Download current semantic models from the server."""
    from doris_mcp_client import http_client
    server_url, token = _resolve(name)
    try:
        count = http_client.semantic_pull(server_url, token, output)
        typer.echo(f"Pulled {count} files to {output}/")
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@semantic_app.command("reload")
def semantic_reload(
    name: Annotated[Optional[str], typer.Option("--name", help="Server name")] = None,
):
    """Trigger server-side semantic layer reload."""
    from doris_mcp_client import http_client
    server_url, token = _resolve(name)
    try:
        result = http_client.semantic_reload(server_url, token)
        data = result.get("data", {})
        typer.echo(f"Reload {data.get('status', '?')}: {data.get('message', '')}")
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@semantic_app.command("status")
def semantic_status(
    name: Annotated[Optional[str], typer.Option("--name", help="Server name")] = None,
):
    """Show current semantic layer status."""
    from doris_mcp_client import http_client
    server_url, token = _resolve(name)
    try:
        result = http_client.semantic_status(server_url, token)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)
    if not formatting.print_semantic_status(result):
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
