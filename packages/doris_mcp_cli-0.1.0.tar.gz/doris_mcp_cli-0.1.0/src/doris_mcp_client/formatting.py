"""Output formatting for CLI display."""

from __future__ import annotations

import json
from typing import Any

from rich.console import Console
from rich.table import Table

console = Console()


def print_tool_list(tools: list[dict[str, Any]]) -> None:
    """Print tool list as a table."""
    table = Table(title="Available Tools")
    table.add_column("Name", style="cyan", no_wrap=True)
    table.add_column("Description", style="white")
    for t in tools:
        desc = t.get("description", "")
        if len(desc) > 80:
            desc = desc[:77] + "..."
        table.add_row(t["name"], desc)
    console.print(table)


def print_tool_schema(schema: dict[str, Any]) -> None:
    """Print tool schema as formatted JSON."""
    console.print(f"[cyan bold]{schema.get('name', '?')}[/]")
    if schema.get("description"):
        console.print(f"  {schema['description']}")
    console.print()
    input_schema = schema.get("inputSchema", {})
    if input_schema:
        console.print_json(json.dumps(input_schema, indent=2, ensure_ascii=False))


def _extract_tool_text(result: Any) -> tuple[str | None, bool]:
    """Normalize a tool result into (text, is_error).

    Accepts:
      - fastmcp.CallToolResult (Pydantic BaseModel; fastmcp exposes the
        MCP spec's `isError` field as snake_case `is_error`)
      - mcp SDK CallToolResult (camelCase `isError`)
      - raw string (tool returned JSON directly)
      - dict / list (pre-parsed)

    Returns:
      (text, is_error) where:
        text: the textual payload (usually a JSON string) or None if no text extracted
        is_error: True if the *protocol* layer flagged the result as an error.
                  Business-layer errors (JSON {"success": false}) are NOT
                  detected here — the caller parses the text to check that.
    """
    # CallToolResult — fastmcp and mcp SDK both expose `.content`, but
    # fastmcp uses `is_error` (snake_case) while the raw mcp SDK uses
    # `isError` (camelCase per spec). Accept either.
    if hasattr(result, "content"):
        content = getattr(result, "content", None)
        if content is not None:
            is_error = bool(
                getattr(result, "is_error", None)
                or getattr(result, "isError", False)
            )
            text_parts = []
            for block in content:
                text = getattr(block, "text", None)
                if text is not None:
                    text_parts.append(text)
            return ("\n".join(text_parts) if text_parts else None, is_error)

    if isinstance(result, str):
        return (result, False)

    if isinstance(result, (dict, list)):
        return (json.dumps(result, ensure_ascii=False), False)

    # Unknown type — fall back to repr (diagnostic only, shouldn't happen)
    return (str(result), False)


def print_tool_result(result: Any) -> bool:
    """Print a tool call result and return whether it represents success.

    Detects both protocol-layer errors (CallToolResult.isError == True) and
    business-layer errors (JSON payload `{"success": false, ...}`). Returns
    False on either. The CLI uses the return value to set a non-zero exit
    code so shell scripts can branch on $?.
    """
    text, is_error = _extract_tool_text(result)

    if text is None:
        # Nothing textual to show — still honor is_error
        console.print(str(result))
        return not is_error

    # Try to pretty-print JSON; also inspect for business-layer success flag
    try:
        parsed = json.loads(text)
    except (json.JSONDecodeError, TypeError):
        console.print(text)
        return not is_error

    console.print_json(json.dumps(parsed, indent=2, ensure_ascii=False))

    if is_error:
        return False
    # Business-layer convention used by doris-mcp-pro tools:
    # {"success": true, "data": ...} or {"success": false, "error": ...}
    if isinstance(parsed, dict) and parsed.get("success") is False:
        return False
    return True


def print_server_list(servers: list[dict[str, Any]]) -> None:
    """Print server list as a table."""
    if not servers:
        console.print("[yellow]No servers registered. Run 'doris-mcp-cli server login' first.[/]")
        return
    table = Table(title="Registered Servers")
    table.add_column("", style="green", no_wrap=True, width=3)
    table.add_column("Name", style="cyan", no_wrap=True)
    table.add_column("URL", style="white")
    table.add_column("Auth", style="white", no_wrap=True)
    table.add_column("Status", style="white", no_wrap=True)
    for s in servers:
        marker = " * " if s["active"] else "   "
        if s["auth_type"] == "credentials":
            status = s.get("status", "unknown")
        else:
            status = "ok"
        table.add_row(marker, s["name"], s["server_url"], s["auth_type"], status)
    console.print(table)


def print_semantic_status(result: Any) -> bool:
    """Display semantic-layer-specific fields from check_service_health.

    Returns True on success, False if the health call itself failed or the
    response can't be parsed. CLI uses the return value to set exit code.
    """
    text, is_error = _extract_tool_text(result)

    if is_error:
        if text:
            console.print(f"[red]Health check returned an error:[/]\n{text}")
        else:
            console.print("[red]Health check returned an error[/]")
        return False

    data = None
    if text:
        try:
            data = json.loads(text)
        except (json.JSONDecodeError, TypeError):
            console.print(text)
            return False
    elif isinstance(result, dict):
        data = result

    if not data or not isinstance(data, dict):
        console.print("[yellow]Unable to parse status response[/]")
        return False

    if data.get("success") is False:
        err = data.get("error", {})
        msg = err.get("message") if isinstance(err, dict) else str(err)
        console.print(f"[red]Health check failed:[/] {msg}")
        return False

    # Top-level summary: enabled + state + guidance for next action.
    # Field locations (server-side):
    #   data.metric_enabled            — bool
    #   data.metric_state              — dict {state, message} (detail) or str (compact)
    #   data.components                — dict of health components
    #   data.semantic_layer            — version info dict (detail mode only, when loaded)
    # Component naming on server is inconsistent: the init path registers
    # `metric_layer`, the reload path writes to `semantic_layer`. We treat
    # either as "loaded" and deduplicate for display.
    inner = data.get("data", {}) if isinstance(data.get("data"), dict) else {}
    metric_enabled = inner.get("metric_enabled")
    metric_state_raw = inner.get("metric_state")
    components = inner.get("components") if isinstance(inner.get("components"), dict) else {}
    # Version info sits at inner.semantic_layer (NOT under components)
    version_info = inner.get("semantic_layer")

    # Normalize metric_state: dict {state, message} in detail, str in compact
    state_value: str | None = None
    state_message: str | None = None
    if isinstance(metric_state_raw, dict):
        state_value = metric_state_raw.get("state")
        state_message = metric_state_raw.get("message")
    elif isinstance(metric_state_raw, str):
        state_value = metric_state_raw

    # "Semantic layer is loaded" — either a concrete health component is
    # registered, or version info carries a real timestamp. Server returns
    # inner.semantic_layer = {"version": None} even when no models are loaded,
    # so we must look at the actual field value, not just dict truthiness.
    version_loaded_at = None
    if isinstance(version_info, dict):
        version_loaded_at = version_info.get("version") or version_info.get("loaded_at")
    loaded = (
        "metric_layer" in components
        or "semantic_layer" in components
        or bool(version_loaded_at)
    )

    # ===== Branch 1: disabled =====
    if metric_enabled is False:
        console.print("[yellow]Semantic layer is disabled on the server "
                      "(metric_enabled=false)[/]")
        console.print("To enable, set [cyan]metric_enabled: true[/] in server config "
                      "and restart.")
        return True

    # ===== Branch 2: enabled but not loaded =====
    if metric_enabled is True and not loaded:
        state_display = state_value or "unknown"
        msg_display = state_message or "no semantic models loaded yet"
        style = "yellow" if state_value in ("initializing", "unready", None) else "red"
        console.print(f"[{style}]Semantic layer: {state_display}[/] — {msg_display}")
        console.print()
        console.print("[bold]No semantic models are loaded.[/] Upload models to enable "
                      "metric tools:")
        console.print("  [cyan]doris-mcp-cli semantic push <path-to-models>[/]")
        console.print("  [cyan]doris-mcp-cli semantic reload[/]")
        if components:
            console.print()
            _print_component_table(components, title="Server components")
        return True

    # ===== Branch 3: loaded (metric_enabled may be None for older servers) =====
    loaded_at = version_loaded_at

    table = Table(title="Semantic Layer Status")
    table.add_column("Component", style="cyan", no_wrap=True)
    table.add_column("Status", style="white", no_wrap=True)
    table.add_column("Details", style="white")

    # Deduplicate: server's init path uses `metric_layer`, reload path uses
    # `semantic_layer` — same logical component. Merge details from whichever
    # is present (reload path wins because metric_count is attached there).
    sem_comp = components.get("semantic_layer") or components.get("metric_layer")
    if sem_comp:
        status = sem_comp.get("status", "unknown")
        message = sem_comp.get("message", "")
        style = "green" if status == "healthy" else ("yellow" if status == "degraded" else "red")
        # Version timestamp semantics differ by status:
        #   - healthy:   loaded_at = when the current (serving) version loaded
        #   - error/degraded: loaded_at is the PREVIOUS successful load,
        #     preserved by VersionTracker.mark_failure(). Without clarifying
        #     this, users read "error ... loaded at 09:08" and assume the
        #     error happened at 09:08 — but that's actually when the
        #     still-running old version was loaded.
        details = message
        if loaded_at:
            if status == "healthy":
                suffix = f"(loaded at {loaded_at})"
            else:
                suffix = f"(last successful load: {loaded_at})"
            details = f"{message}  [dim]{suffix}[/]" if message else suffix
        table.add_row("semantic_layer", f"[{style}]{status}[/]", details)

    for key in ("metricflow_engine", "config_watcher"):
        comp = components.get(key)
        if not comp:
            continue
        status = comp.get("status", "unknown")
        message = comp.get("message", "")
        style = "green" if status == "healthy" else ("yellow" if status == "degraded" else "red")
        table.add_row(key, f"[{style}]{status}[/]", message)

    console.print(table)
    if state_value and state_value not in ("ready",):
        console.print(f"[yellow]Current state: {state_value}[/]"
                      + (f" — {state_message}" if state_message else ""))
    return True


def _print_component_table(components: dict, title: str) -> None:
    """Helper: render an arbitrary components dict as a compact table."""
    table = Table(title=title)
    table.add_column("Component", style="cyan", no_wrap=True)
    table.add_column("Status", style="white", no_wrap=True)
    table.add_column("Details", style="white")
    for key, comp in components.items():
        if not isinstance(comp, dict):
            continue
        status = comp.get("status", "unknown")
        message = comp.get("message", "")
        style = "green" if status == "healthy" else ("yellow" if status == "degraded" else "red")
        table.add_row(key, f"[{style}]{status}[/]", message)
    console.print(table)


def print_json_response(data: Any) -> None:
    """Print any JSON-serializable response."""
    if isinstance(data, str):
        try:
            data = json.loads(data)
        except (json.JSONDecodeError, TypeError):
            console.print(data)
            return
    console.print_json(json.dumps(data, indent=2, ensure_ascii=False))
