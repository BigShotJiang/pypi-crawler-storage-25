"""Multi-server credential management.

Stores credentials in ~/.doris-mcp/credentials.json with chmod 600.
Supports multiple named server entries with an active pointer.
Handles token lifecycle: static tokens pass through, credentials mode
does lazy refresh on each CLI invocation.
"""

from __future__ import annotations

import json
import logging
import os
import stat
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import httpx

logger = logging.getLogger(__name__)

CREDENTIALS_DIR = Path.home() / ".doris-mcp"
CREDENTIALS_FILE = CREDENTIALS_DIR / "credentials.json"

# Current schema version. Bump when adding fields that older CLI versions
# can safely ignore (minor) or that require migration (major).
# Migration rules (enforced by _load_store):
#   - missing or schema_version <= CURRENT: upgrade in place to CURRENT
#   - schema_version > CURRENT: refuse to load (prevents a newer CLI's
#     state from being corrupted by an older CLI)
CURRENT_SCHEMA_VERSION = 1


def _empty_store() -> dict:
    return {"schema_version": CURRENT_SCHEMA_VERSION, "active": None, "servers": {}}


def _load_store() -> dict:
    """Load the credentials store, returning empty structure if missing.

    Enforces schema_version: files without the field are treated as v1 and
    tagged on load; files with a newer version raise to prevent corruption.
    """
    if not CREDENTIALS_FILE.exists():
        return _empty_store()
    try:
        data = json.loads(CREDENTIALS_FILE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return _empty_store()
    if not isinstance(data, dict):
        return _empty_store()

    version = data.get("schema_version")
    if version is None:
        # Legacy file from before schema_version was introduced — treat as v1.
        version = 1
    if not isinstance(version, int) or version > CURRENT_SCHEMA_VERSION:
        raise RuntimeError(
            f"credentials.json has schema_version={version!r}, but this CLI "
            f"supports up to {CURRENT_SCHEMA_VERSION}. Upgrade the CLI or "
            f"remove {CREDENTIALS_FILE} to re-login."
        )

    data["schema_version"] = CURRENT_SCHEMA_VERSION
    data.setdefault("active", None)
    data.setdefault("servers", {})
    return data


_chmod_warning_shown = False


def _save_store(store: dict) -> None:
    """Write credentials store atomically with 0600 permissions.

    Writes to a temporary file (created with 0600 from the start) then
    atomically replaces the target. os.replace (not os.rename) handles
    the Windows case where renaming onto an existing file would fail.

    On Windows, POSIX permission bits have no real effect — file access
    is governed by NTFS ACLs inherited from the user profile directory
    (%USERPROFILE%\\.doris-mcp\\), which by default grant access to the
    current user only. We still call os.chmod on Windows (it sets the
    read-only flag harmlessly), but tolerate failure and warn once.
    """
    CREDENTIALS_DIR.mkdir(parents=True, exist_ok=True)
    content = json.dumps(store, indent=2, ensure_ascii=False).encode("utf-8")
    tmp_path = CREDENTIALS_FILE.with_suffix(".tmp")
    fd = os.open(str(tmp_path), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        os.write(fd, content)
    finally:
        os.close(fd)

    # Belt-and-suspenders: explicitly chmod in case umask or FS didn't honor
    # the open() mode. On Windows this is mostly cosmetic but harmless.
    global _chmod_warning_shown
    try:
        os.chmod(str(tmp_path), stat.S_IRUSR | stat.S_IWUSR)
    except (OSError, NotImplementedError) as e:
        if not _chmod_warning_shown:
            import sys
            sys.stderr.write(
                f"Warning: could not set file permissions on credentials "
                f"(OS limitation: {e}). On Windows, the file is protected "
                f"by NTFS ACLs inherited from your user profile directory.\n"
            )
            _chmod_warning_shown = True

    os.replace(str(tmp_path), str(CREDENTIALS_FILE))


def register_token(name: str, server_url: str, token: str, overwrite: bool = False) -> None:
    """Register a static token entry.

    Default behavior rejects same-name duplicates — callers that want to
    replace an existing entry (e.g. the CLI's "same URL means re-login",
    see policy in cli.py:server_login) must pass overwrite=True.
    """
    store = _load_store()
    if name in store["servers"] and not overwrite:
        raise ValueError(f"Server '{name}' already exists. Use 'server remove {name}' first.")
    store["servers"][name] = {
        "server_url": server_url.rstrip("/"),
        "auth_type": "token",
        "token": token,
    }
    if store["active"] is None:
        store["active"] = name
    _save_store(store)


def register_credentials(
    name: str,
    server_url: str,
    access_token: str,
    refresh_token: str,
    expires_in: int,
    refresh_expires_in: int,
    username: str | None = None,
    overwrite: bool = False,
) -> None:
    """Register a credentials entry from /api/auth/token response.

    ``username`` is optional for backward compatibility with entries written
    by older CLI versions, but new-style callers should always pass it so
    that the re-login hint shown when the refresh token expires can include
    a concrete --user flag.
    """
    store = _load_store()
    if name in store["servers"] and not overwrite:
        raise ValueError(f"Server '{name}' already exists. Use 'server remove {name}' first.")
    now = time.time()
    entry = {
        "server_url": server_url.rstrip("/"),
        "auth_type": "credentials",
        "access_token": access_token,
        "refresh_token": refresh_token,
        "access_token_expires_at": datetime.fromtimestamp(
            now + expires_in, tz=timezone.utc
        ).isoformat(),
        "refresh_token_expires_at": datetime.fromtimestamp(
            now + refresh_expires_in, tz=timezone.utc
        ).isoformat(),
    }
    if username:
        entry["username"] = username
    store["servers"][name] = entry
    if store["active"] is None:
        store["active"] = name
    _save_store(store)


def remove_server(name: str) -> None:
    """Remove a server entry. Clears active if it was the removed server."""
    store = _load_store()
    if name not in store["servers"]:
        raise ValueError(f"Server '{name}' not found.")
    del store["servers"][name]
    if store["active"] == name:
        store["active"] = None
    _save_store(store)


def switch_server(name: str) -> None:
    """Set a different server as active."""
    store = _load_store()
    if name not in store["servers"]:
        raise ValueError(f"Server '{name}' not found.")
    store["active"] = name
    _save_store(store)


def list_servers() -> list[dict[str, Any]]:
    """Return list of server entries with status info."""
    store = _load_store()
    result = []
    for name, entry in store["servers"].items():
        info: dict[str, Any] = {
            "name": name,
            "server_url": entry["server_url"],
            "auth_type": entry["auth_type"],
            "active": name == store["active"],
        }
        if entry["auth_type"] == "credentials":
            info["status"] = _token_status(entry)
        result.append(info)
    return result


def _token_status(entry: dict) -> str:
    """Check token expiry status for a credentials entry."""
    now = datetime.now(tz=timezone.utc)
    try:
        access_exp = datetime.fromisoformat(entry["access_token_expires_at"])
        refresh_exp = datetime.fromisoformat(entry["refresh_token_expires_at"])
    except (KeyError, ValueError):
        return "unknown"
    if refresh_exp <= now:
        return "expired"
    if access_exp <= now:
        return "refresh needed"
    return "active"


def get_server_entry(name: str | None = None) -> dict | None:
    """Get server entry by name, or the active server if name is None."""
    store = _load_store()
    if name is None:
        name = store["active"]
    if name is None:
        return None
    return store["servers"].get(name)


def get_active_name() -> str | None:
    """Return the active server name, or None."""
    store = _load_store()
    return store["active"]


def resolve_token(name: str | None = None) -> tuple[str, str]:
    """Resolve a usable Bearer token for the given (or active) server.

    For token auth: returns (server_url, token) directly.
    For credentials auth: checks expiry, refreshes if needed, returns token.

    Returns:
        (server_url, bearer_token)

    Raises:
        RuntimeError: if no server configured, token expired, or refresh fails.
    """
    entry = get_server_entry(name)
    if entry is None:
        effective = name or "(active)"
        raise RuntimeError(
            f"No server '{effective}' found. Run 'doris-mcp-cli server login' first."
        )

    server_url = entry["server_url"]

    if entry["auth_type"] == "token":
        return server_url, entry["token"]

    # credentials mode — check expiry
    effective_name = name or _load_store()["active"] or "<name>"
    now = datetime.now(tz=timezone.utc)
    try:
        access_exp = datetime.fromisoformat(entry["access_token_expires_at"])
        refresh_exp = datetime.fromisoformat(entry["refresh_token_expires_at"])
    except (KeyError, ValueError):
        raise RuntimeError(_relogin_hint(
            effective_name, server_url, entry.get("username"),
            reason="Corrupted credentials entry",
        ))

    if access_exp > now:
        return server_url, entry["access_token"]

    if refresh_exp <= now:
        raise RuntimeError(_relogin_hint(
            effective_name, server_url, entry.get("username"),
            reason=f"Session expired for server '{effective_name}' (refresh token expired)",
        ))

    # Refresh the access token. If server rejects the refresh (e.g. token
    # store lost on server restart, admin revocation, or any auth-layer
    # failure), _do_refresh raises a generic "Token refresh failed ...".
    # Re-wrap it with a copy-pasteable re-login command, matching the
    # "refresh_token expired" branch above — both paths lead to the same
    # user action (re-login) so the hint shape should be identical.
    try:
        result = _do_refresh(server_url, entry["refresh_token"])
    except RuntimeError as e:
        msg = str(e)
        # Only substitute for auth/token-layer failures; network errors
        # (ConnectError, timeout) have their own clear messages that are
        # already actionable — wrapping them with a "re-login" hint would
        # be misleading (login won't fix "server unreachable").
        if "Token refresh failed" in msg:
            raise RuntimeError(_relogin_hint(
                effective_name, server_url, entry.get("username"),
                reason=f"Session expired for server '{effective_name}' "
                       f"(server rejected refresh token)",
            )) from None
        raise
    _update_credentials(name, server_url, result)
    return server_url, result["access_token"]


def _relogin_hint(name: str, server_url: str, username: str | None, reason: str) -> str:
    """Build a user-facing message that includes a copy-pasteable login command.

    username may be missing on entries written by CLI versions before the
    field was added; in that case we emit a placeholder and let the user
    fill it in.
    """
    user_flag = f"--user {username}" if username else "--user <your-username>"
    return (
        f"{reason}.\n"
        f"Run the following to re-login:\n"
        f"  doris-mcp-cli server login --server {server_url} --name {name} {user_flag}"
    )


def _do_refresh(server_url: str, refresh_token: str) -> dict:
    """Call /api/auth/refresh to get new tokens."""
    # trust_env disabled unless user opts in via DORIS_MCP_USE_SYSTEM_PROXY.
    # Matches http_client._client() policy — see that module for rationale.
    from doris_mcp_client.http_client import _use_system_proxy
    try:
        with httpx.Client(trust_env=_use_system_proxy(), timeout=30) as client:
            resp = client.post(
                f"{server_url}/api/auth/refresh",
                json={"refresh_token": refresh_token},
            )
    except httpx.ConnectError:
        raise RuntimeError(
            f"Cannot connect to server at {server_url}. "
            "Check that the server is running and the URL is correct."
        )
    except httpx.TimeoutException:
        raise RuntimeError(
            f"Connection to {server_url} timed out during token refresh."
        )
    except httpx.HTTPError as e:
        raise RuntimeError(f"Network error during token refresh: {e}")
    if resp.status_code != 200:
        raise RuntimeError(
            f"Token refresh failed (HTTP {resp.status_code}). "
            "Run 'doris-mcp-cli server login' again."
        )
    return resp.json()


def _update_credentials(name: str | None, server_url: str, result: dict) -> None:
    """Update stored credentials after a successful refresh."""
    store = _load_store()
    effective_name = name or store["active"]
    if effective_name is None or effective_name not in store["servers"]:
        return
    now = time.time()
    entry = store["servers"][effective_name]
    entry["access_token"] = result["access_token"]
    entry["refresh_token"] = result["refresh_token"]
    entry["access_token_expires_at"] = datetime.fromtimestamp(
        now + result["expires_in"], tz=timezone.utc
    ).isoformat()
    entry["refresh_token_expires_at"] = datetime.fromtimestamp(
        now + result["refresh_expires_in"], tz=timezone.utc
    ).isoformat()
    _save_store(store)
