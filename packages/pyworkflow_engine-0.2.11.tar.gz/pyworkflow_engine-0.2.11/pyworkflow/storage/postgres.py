"""
PostgreSQL storage backend using asyncpg.

This backend stores workflow data in a PostgreSQL database, suitable for:
- Production deployments requiring scalability
- Multi-instance deployments
- High-availability requirements

Provides ACID guarantees, connection pooling, and efficient querying with SQL indexes.

Note: The connection pool is bound to a specific event loop. When running in
environments where each task creates a new event loop (e.g., Celery prefork),
the pool is automatically recreated when a loop change is detected.
"""

import asyncio
import contextlib
import json
import os
from datetime import UTC, datetime
from typing import Any

import asyncpg
from loguru import logger

from pyworkflow.engine.events import Event, EventType
from pyworkflow.storage.base import StorageBackend
from pyworkflow.storage.migrations import Migration, MigrationRegistry, MigrationRunner
from pyworkflow.storage.schemas import (
    Hook,
    HookStatus,
    OverlapPolicy,
    RunStatus,
    Schedule,
    ScheduleSpec,
    ScheduleStatus,
    StepExecution,
    StepStatus,
    WorkflowRun,
)


class PostgresMigrationRunner(MigrationRunner):
    """PostgreSQL-specific migration runner."""

    def __init__(self, pool: asyncpg.Pool, registry: MigrationRegistry | None = None) -> None:
        super().__init__(registry)
        self._pool = pool

    async def ensure_schema_versions_table(self) -> None:
        """Create schema_versions table if it doesn't exist."""
        async with self._pool.acquire() as conn:
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS schema_versions (
                    version INTEGER PRIMARY KEY,
                    applied_at TIMESTAMPTZ NOT NULL,
                    description TEXT
                )
            """)

    async def get_current_version(self) -> int:
        """Get the highest applied migration version."""
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT COALESCE(MAX(version), 0) as version FROM schema_versions"
            )
            return row["version"] if row else 0

    async def detect_existing_schema(self) -> bool:
        """Check if the events table exists (pre-versioning database)."""
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow("""
                SELECT EXISTS (
                    SELECT FROM information_schema.tables
                    WHERE table_name = 'events'
                ) as exists
            """)
            return row["exists"] if row else False

    async def record_baseline_version(self, version: int, description: str) -> None:
        """Record a baseline version without running migrations."""
        async with self._pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO schema_versions (version, applied_at, description)
                VALUES ($1, $2, $3)
                ON CONFLICT (version) DO NOTHING
                """,
                version,
                datetime.now(UTC),
                description,
            )

    async def apply_migration(self, migration: Migration) -> None:
        """Apply a migration with PostgreSQL-specific handling."""
        logger.info(
            f"PG_MIGRATION: opening transaction for v{migration.version}",
            version=migration.version,
        )
        async with self._pool.acquire() as conn, conn.transaction():
            if migration.version == 2:
                # V2: Add step_id column to events table
                # First check if events table exists (fresh databases won't have it yet)
                table_exists = await conn.fetchrow("""
                    SELECT EXISTS (
                        SELECT FROM information_schema.tables
                        WHERE table_name = 'events'
                    ) as exists
                """)

                if table_exists and table_exists["exists"]:
                    # Use IF NOT EXISTS for idempotency
                    await conn.execute("""
                        DO $$
                        BEGIN
                            IF NOT EXISTS (
                                SELECT 1 FROM information_schema.columns
                                WHERE table_name = 'events' AND column_name = 'step_id'
                            ) THEN
                                ALTER TABLE events ADD COLUMN step_id TEXT;
                            END IF;
                        END $$
                    """)

                    # Create index for optimized has_event() queries
                    await conn.execute("""
                        CREATE INDEX IF NOT EXISTS idx_events_run_id_step_id_type
                        ON events(run_id, step_id, type)
                    """)

                    # Backfill step_id from JSON data
                    await conn.execute("""
                        UPDATE events
                        SET step_id = (data::jsonb)->>'step_id'
                        WHERE step_id IS NULL
                          AND (data::jsonb)->>'step_id' IS NOT NULL
                    """)
                # If table doesn't exist, schema will be created with step_id column
            elif migration.version == 3:
                # V3: Restructure signals table — PK changes from signal_id
                # to (stream_run_id, sequence). Drop and recreate.
                await conn.execute("DROP TABLE IF EXISTS signal_acknowledgments")
                await conn.execute("DROP TABLE IF EXISTS signals")
                await conn.execute("""
                    CREATE TABLE signals (
                        stream_run_id TEXT NOT NULL,
                        sequence INTEGER NOT NULL,
                        signal_id TEXT NOT NULL,
                        stream_id TEXT NOT NULL,
                        signal_type TEXT NOT NULL,
                        payload JSONB NOT NULL DEFAULT '{}',
                        published_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                        source_run_id TEXT,
                        metadata JSONB DEFAULT '{}',
                        PRIMARY KEY (stream_id, stream_run_id, sequence)
                    )
                """)
                await conn.execute(
                    "CREATE UNIQUE INDEX idx_signals_signal_id ON signals(signal_id)"
                )
                await conn.execute("""
                    CREATE TABLE signal_acknowledgments (
                        signal_id TEXT NOT NULL,
                        step_run_id TEXT NOT NULL,
                        acknowledged_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                        PRIMARY KEY (signal_id, step_run_id)
                    )
                """)
            elif migration.version == 4:
                # V4: Drop FK constraints on stream_id — streams are code-defined
                await conn.execute(
                    "ALTER TABLE IF EXISTS signals DROP CONSTRAINT IF EXISTS signals_stream_id_fkey"
                )
                await conn.execute(
                    "ALTER TABLE IF EXISTS stream_subscriptions DROP CONSTRAINT IF EXISTS stream_subscriptions_stream_id_fkey"
                )
            elif migration.version == 5:
                # V5: stream_run_id on stream_subscriptions + scheduled_signals table.
                # Use top-level ALTER (not a DO $$ block) for consistency with
                # CitusMigrationRunner — DDL inside DO blocks is executed via SPI
                # and bypasses the Citus ProcessUtility hook, so worker shards
                # silently miss the column. Plain Postgres is unaffected either way,
                # but keeping both runners symmetric avoids future foot-guns.
                logger.info("PG_MIGRATION v5: ALTER stream_subscriptions ADD stream_run_id")
                await conn.execute(
                    "ALTER TABLE stream_subscriptions "
                    "ADD COLUMN IF NOT EXISTS stream_run_id TEXT NULL"
                )
                logger.info("PG_MIGRATION v5: CREATE INDEX idx_subscriptions_stream_run")
                await conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_subscriptions_stream_run "
                    "ON stream_subscriptions(stream_id, stream_run_id)"
                )
                logger.info("PG_MIGRATION v5: CREATE TABLE scheduled_signals")
                await conn.execute("""
                    CREATE TABLE IF NOT EXISTS scheduled_signals (
                        id TEXT PRIMARY KEY,
                        stream_id TEXT NOT NULL,
                        signal_type TEXT NOT NULL,
                        payload JSONB NOT NULL DEFAULT '{}',
                        due_at TIMESTAMPTZ NOT NULL,
                        stream_run_id TEXT,
                        metadata JSONB DEFAULT '{}',
                        delivered BOOLEAN NOT NULL DEFAULT FALSE,
                        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
                    )
                """)
                logger.info("PG_MIGRATION v5: CREATE INDEX idx_scheduled_signals_due")
                await conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_scheduled_signals_due "
                    "ON scheduled_signals(delivered, due_at)"
                )
            elif migration.version == 6:
                # V6: parent linkage columns on stream_subscriptions so the
                # stream-step dispatcher can resume the parent @workflow via
                # resume_hook() instead of pinning a worker on an asyncio.Event.
                # Top-level ALTERs for Citus propagation symmetry (see V5 note).
                logger.info("PG_MIGRATION v6: ALTER stream_subscriptions ADD parent_run_id")
                await conn.execute(
                    "ALTER TABLE stream_subscriptions "
                    "ADD COLUMN IF NOT EXISTS parent_run_id TEXT NULL"
                )
                logger.info("PG_MIGRATION v6: ALTER stream_subscriptions ADD parent_hook_token")
                await conn.execute(
                    "ALTER TABLE stream_subscriptions "
                    "ADD COLUMN IF NOT EXISTS parent_hook_token TEXT NULL"
                )
            elif migration.version == 7:
                # V7: result column on stream_subscriptions for step output payloads.
                logger.info("PG_MIGRATION v7: ALTER stream_subscriptions ADD result")
                await conn.execute(
                    "ALTER TABLE stream_subscriptions "
                    "ADD COLUMN IF NOT EXISTS result JSONB NULL"
                )
            elif migration.up_func:
                await migration.up_func(conn)
            elif migration.up_sql and migration.up_sql != "SELECT 1":
                await conn.execute(migration.up_sql)

            # Record the migration
            await conn.execute(
                """
                INSERT INTO schema_versions (version, applied_at, description)
                VALUES ($1, $2, $3)
                """,
                migration.version,
                datetime.now(UTC),
                migration.description,
            )


class PostgresStorageBackend(StorageBackend):
    """
    PostgreSQL storage backend using asyncpg for async operations.

    All workflow data is stored in a PostgreSQL database with proper
    indexes for efficient querying and connection pooling for performance.
    """

    def __init__(
        self,
        dsn: str | None = None,
        host: str = "localhost",
        port: int = 5432,
        user: str = "pyworkflow",
        password: str = "",
        database: str = "pyworkflow",
        min_pool_size: int | None = None,
        max_pool_size: int | None = None,
        max_inactive_connection_lifetime: float | None = None,
        command_timeout: float | None = None,
    ):
        """
        Initialize PostgreSQL storage backend.

        Args:
            dsn: Connection string (e.g., postgresql://user:pass@host:5432/db)
            host: Database host (used if dsn not provided)
            port: Database port (used if dsn not provided)
            user: Database user (used if dsn not provided)
            password: Database password (used if dsn not provided)
            database: Database name (used if dsn not provided)
            min_pool_size: Minimum connections in pool (defaults to env var PYWORKFLOW_POSTGRES_MIN_POOL_SIZE or 1)
            max_pool_size: Maximum connections in pool (defaults to env var PYWORKFLOW_POSTGRES_MAX_POOL_SIZE or 10)
            max_inactive_connection_lifetime: How long (seconds) an idle connection can
                                              stay in the pool before being closed.
                                              Defaults to env var PYWORKFLOW_POSTGRES_MAX_INACTIVE_LIFETIME or 1800s (30 min).
            command_timeout: Default timeout (seconds) for queries. None for no timeout.
                            Defaults to env var PYWORKFLOW_POSTGRES_COMMAND_TIMEOUT or 60s.
        """
        self.dsn = dsn
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.database = database

        # Read from env vars if not provided
        self.min_pool_size = min_pool_size or int(
            os.getenv("PYWORKFLOW_POSTGRES_MIN_POOL_SIZE", "1")
        )
        self.max_pool_size = max_pool_size or int(
            os.getenv("PYWORKFLOW_POSTGRES_MAX_POOL_SIZE", "10")
        )
        self.max_inactive_connection_lifetime = max_inactive_connection_lifetime or float(
            os.getenv("PYWORKFLOW_POSTGRES_MAX_INACTIVE_LIFETIME", "1800.0")
        )
        self.command_timeout = (
            command_timeout
            if command_timeout is not None
            else (
                float(os.getenv("PYWORKFLOW_POSTGRES_COMMAND_TIMEOUT", "60.0"))
                if os.getenv("PYWORKFLOW_POSTGRES_COMMAND_TIMEOUT")
                else 60.0
            )
        )

        self._pool: asyncpg.Pool | None = None
        self._pool_loop_id: int | None = None  # Track which loop the pool was created on
        self._initialized = False

    def _build_dsn(self) -> str:
        """Build DSN from individual parameters."""
        if self.password:
            return (
                f"postgresql://{self.user}:{self.password}@{self.host}:{self.port}/{self.database}"
            )
        return f"postgresql://{self.user}@{self.host}:{self.port}/{self.database}"

    async def connect(self) -> None:
        """Initialize connection pool and create tables if needed.

        The pool is bound to the current event loop. If the loop has changed
        since the pool was created (e.g., in Celery prefork workers), the old
        pool is closed and a new one is created.
        """
        current_loop_id = id(asyncio.get_running_loop())

        # Check if we need to recreate the pool due to loop change
        if self._pool is not None and self._pool_loop_id != current_loop_id:
            # Loop changed - the old pool is invalid, close it
            with contextlib.suppress(Exception):
                self._pool.terminate()  # Use terminate() instead of close() to avoid awaiting on wrong loop
            self._pool = None
            self._initialized = False

        if self._pool is None:
            self._pool = await asyncpg.create_pool(
                dsn=self.dsn or self._build_dsn(),
                min_size=self.min_pool_size,
                max_size=self.max_pool_size,
                max_inactive_connection_lifetime=self.max_inactive_connection_lifetime,
                command_timeout=self.command_timeout,
                # Disable statement caching to avoid InvalidCachedStatementError
                # after schema migrations
                statement_cache_size=0,
            )
            self._pool_loop_id = current_loop_id

        if not self._initialized:
            await self._initialize_schema()
            self._initialized = True

    async def disconnect(self) -> None:
        """Close connection pool."""
        if self._pool:
            await self._pool.close()
            self._pool = None
            self._pool_loop_id = None
            self._initialized = False

    async def _initialize_schema(self) -> None:
        """Create database tables if they don't exist and run migrations."""
        if not self._pool:
            await self.connect()

        pool = await self._get_pool()

        # Run migrations first (handles schema versioning)
        runner = PostgresMigrationRunner(pool)
        await runner.run_migrations()

        async with pool.acquire() as conn:
            # Workflow runs table
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS workflow_runs (
                    run_id TEXT PRIMARY KEY,
                    workflow_name TEXT NOT NULL,
                    status TEXT NOT NULL,
                    created_at TIMESTAMPTZ NOT NULL,
                    updated_at TIMESTAMPTZ NOT NULL,
                    started_at TIMESTAMPTZ,
                    completed_at TIMESTAMPTZ,
                    input_args TEXT NOT NULL DEFAULT '[]',
                    input_kwargs TEXT NOT NULL DEFAULT '{}',
                    result TEXT,
                    error TEXT,
                    idempotency_key TEXT,
                    max_duration TEXT,
                    metadata TEXT DEFAULT '{}',
                    recovery_attempts INTEGER DEFAULT 0,
                    max_recovery_attempts INTEGER DEFAULT 3,
                    recover_on_worker_loss BOOLEAN DEFAULT TRUE,
                    parent_run_id TEXT REFERENCES workflow_runs(run_id),
                    nesting_depth INTEGER DEFAULT 0,
                    continued_from_run_id TEXT,
                    continued_to_run_id TEXT
                )
            """)

            # Indexes for workflow_runs
            await conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_runs_status ON workflow_runs(status)"
            )
            await conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_runs_workflow_name ON workflow_runs(workflow_name)"
            )
            await conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_runs_created_at ON workflow_runs(created_at DESC)"
            )
            await conn.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS idx_runs_idempotency_key ON workflow_runs(idempotency_key) WHERE idempotency_key IS NOT NULL"
            )
            await conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_runs_parent_run_id ON workflow_runs(parent_run_id)"
            )

            # Events table (includes step_id column added in V2 migration)
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS events (
                    event_id TEXT PRIMARY KEY,
                    run_id TEXT NOT NULL REFERENCES workflow_runs(run_id) ON DELETE CASCADE,
                    sequence INTEGER NOT NULL,
                    type TEXT NOT NULL,
                    timestamp TIMESTAMPTZ NOT NULL,
                    data TEXT NOT NULL DEFAULT '{}',
                    step_id TEXT
                )
            """)

            # Indexes for events
            await conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_events_run_id_sequence ON events(run_id, sequence)"
            )
            # Composite index for get_events() with type filter
            await conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_events_run_id_type ON events(run_id, type)"
            )
            # NOTE: idx_events_run_id_step_id_type is intentionally NOT created here.
            # On a pre-v2 database, the step_id column does not yet exist
            # (CREATE TABLE IF NOT EXISTS above is a no-op on existing tables, so
            # the new column declaration is ignored). The v2 migration adds the
            # column AND creates this index — see PostgresMigrationRunner version 2.

            # Steps table
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS steps (
                    step_id TEXT PRIMARY KEY,
                    run_id TEXT NOT NULL REFERENCES workflow_runs(run_id) ON DELETE CASCADE,
                    step_name TEXT NOT NULL,
                    status TEXT NOT NULL,
                    created_at TIMESTAMPTZ NOT NULL,
                    started_at TIMESTAMPTZ,
                    completed_at TIMESTAMPTZ,
                    input_args TEXT NOT NULL DEFAULT '[]',
                    input_kwargs TEXT NOT NULL DEFAULT '{}',
                    result TEXT,
                    error TEXT,
                    retry_count INTEGER DEFAULT 0
                )
            """)

            # Indexes for steps
            await conn.execute("CREATE INDEX IF NOT EXISTS idx_steps_run_id ON steps(run_id)")

            # Hooks table (composite PK: run_id + hook_id since hook_id is only unique per run)
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS hooks (
                    run_id TEXT NOT NULL REFERENCES workflow_runs(run_id) ON DELETE CASCADE,
                    hook_id TEXT NOT NULL,
                    token TEXT UNIQUE NOT NULL,
                    created_at TIMESTAMPTZ NOT NULL,
                    received_at TIMESTAMPTZ,
                    expires_at TIMESTAMPTZ,
                    status TEXT NOT NULL,
                    payload TEXT,
                    metadata TEXT DEFAULT '{}',
                    PRIMARY KEY (run_id, hook_id)
                )
            """)

            # Indexes for hooks
            await conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_hooks_token ON hooks(token)")
            await conn.execute("CREATE INDEX IF NOT EXISTS idx_hooks_run_id ON hooks(run_id)")
            await conn.execute("CREATE INDEX IF NOT EXISTS idx_hooks_status ON hooks(status)")

            # Schedules table
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS schedules (
                    schedule_id TEXT PRIMARY KEY,
                    workflow_name TEXT NOT NULL,
                    spec TEXT NOT NULL,
                    spec_type TEXT NOT NULL,
                    timezone TEXT,
                    input_args TEXT NOT NULL DEFAULT '[]',
                    input_kwargs TEXT NOT NULL DEFAULT '{}',
                    status TEXT NOT NULL,
                    overlap_policy TEXT NOT NULL,
                    next_run_time TIMESTAMPTZ,
                    last_run_time TIMESTAMPTZ,
                    running_run_ids TEXT DEFAULT '[]',
                    metadata TEXT DEFAULT '{}',
                    created_at TIMESTAMPTZ NOT NULL,
                    updated_at TIMESTAMPTZ NOT NULL,
                    paused_at TIMESTAMPTZ,
                    deleted_at TIMESTAMPTZ
                )
            """)

            # Indexes for schedules
            await conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_schedules_status ON schedules(status)"
            )
            await conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_schedules_next_run_time ON schedules(next_run_time)"
            )
            await conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_schedules_workflow_name ON schedules(workflow_name)"
            )

            # Cancellation flags table
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS cancellation_flags (
                    run_id TEXT PRIMARY KEY REFERENCES workflow_runs(run_id) ON DELETE CASCADE,
                    created_at TIMESTAMPTZ NOT NULL
                )
            """)

            # Checkpoints table
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS checkpoints (
                    step_run_id TEXT PRIMARY KEY,
                    data JSONB NOT NULL,
                    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
                )
            """)

            # Streams table
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS streams (
                    stream_id TEXT PRIMARY KEY,
                    status TEXT NOT NULL DEFAULT 'active',
                    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    metadata JSONB DEFAULT '{}'
                )
            """)

            # Signals table — PK is (stream_id, stream_run_id, sequence) so sequences
            # restart per stream run and queries by run are index-only scans.
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS signals (
                    stream_run_id TEXT NOT NULL,
                    sequence INTEGER NOT NULL,
                    signal_id TEXT NOT NULL,
                    stream_id TEXT NOT NULL,
                    signal_type TEXT NOT NULL,
                    payload JSONB NOT NULL DEFAULT '{}',
                    published_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    source_run_id TEXT,
                    metadata JSONB DEFAULT '{}',
                    PRIMARY KEY (stream_id, stream_run_id, sequence)
                )
            """)
            await conn.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS idx_signals_signal_id ON signals(signal_id)"
            )

            # Stream subscriptions table
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS stream_subscriptions (
                    stream_id TEXT NOT NULL,
                    step_run_id TEXT NOT NULL,
                    signal_types JSONB NOT NULL DEFAULT '[]',
                    status TEXT NOT NULL DEFAULT 'waiting',
                    stream_run_id TEXT,
                    parent_run_id TEXT,
                    parent_hook_token TEXT,
                    result JSONB,
                    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    PRIMARY KEY (stream_id, step_run_id)
                )
            """)
            await conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_subscriptions_status ON stream_subscriptions(stream_id, status)"
            )
            # NOTE: idx_subscriptions_stream_run is intentionally NOT created here.
            # On a pre-v5 database, the stream_run_id column does not yet exist
            # (CREATE TABLE IF NOT EXISTS above is a no-op on existing tables, so
            # the new column declarations are ignored). The v5 migration adds the
            # column AND creates this index idempotently — see PostgresMigrationRunner
            # version 5. Creating the index here would crash _initialize_schema
            # before run_migrations() ever gets a chance to run.

            # Scheduled signals table (for schedule_signal() primitive)
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS scheduled_signals (
                    id TEXT PRIMARY KEY,
                    stream_id TEXT NOT NULL,
                    signal_type TEXT NOT NULL,
                    payload JSONB NOT NULL DEFAULT '{}',
                    due_at TIMESTAMPTZ NOT NULL,
                    stream_run_id TEXT,
                    metadata JSONB DEFAULT '{}',
                    delivered BOOLEAN NOT NULL DEFAULT FALSE,
                    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
                )
            """)
            await conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_scheduled_signals_due "
                "ON scheduled_signals(delivered, due_at)"
            )

            # Signal acknowledgments table
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS signal_acknowledgments (
                    signal_id TEXT NOT NULL,
                    step_run_id TEXT NOT NULL,
                    acknowledged_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    PRIMARY KEY (signal_id, step_run_id)
                )
            """)

    async def _get_pool(self) -> asyncpg.Pool:
        """Get the connection pool, connecting/reconnecting if needed.

        This method ensures the pool is connected and on the correct event loop.
        It handles automatic reconnection when the event loop has changed.
        """
        current_loop_id = id(asyncio.get_running_loop())

        # Check if we need to connect or reconnect
        # - If no pool exists, we need to connect
        # - If pool exists but was created on a different loop, we need to reconnect
        # - If _pool_loop_id is None but pool exists (e.g., mocked for testing),
        #   we trust the pool and set the loop ID to current
        if self._pool is None:
            await self.connect()
        elif self._pool_loop_id is not None and self._pool_loop_id != current_loop_id:
            # Pool was created on a different loop - need to reconnect
            await self.connect()
        elif self._pool_loop_id is None:
            # Pool was set externally (e.g., for testing) - track current loop
            self._pool_loop_id = current_loop_id

        return self._pool  # type: ignore

    def _ensure_connected(self) -> asyncpg.Pool:
        """Ensure database pool is connected.

        DEPRECATED: Use _get_pool() instead for automatic reconnection.
        This method is kept for backward compatibility but will raise an error
        if the pool is on a different event loop.
        """
        if not self._pool:
            raise RuntimeError("Database not connected. Call connect() first.")

        # Check if we're on a different event loop than when the pool was created
        try:
            current_loop_id = id(asyncio.get_running_loop())
            if self._pool_loop_id is not None and self._pool_loop_id != current_loop_id:
                raise RuntimeError(
                    "Database pool was created on a different event loop. "
                    "Call connect() to recreate the pool on the current loop."
                )
        except RuntimeError as e:
            if "no running event loop" in str(e).lower():
                # No running loop - this will fail anyway when we try to use the pool
                pass
            else:
                raise

        return self._pool

    # Workflow Run Operations

    async def create_run(self, run: WorkflowRun) -> None:
        """Create a new workflow run record."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO workflow_runs (
                    run_id, workflow_name, status, created_at, updated_at, started_at,
                    completed_at, input_args, input_kwargs, result, error, idempotency_key,
                    max_duration, metadata, recovery_attempts, max_recovery_attempts,
                    recover_on_worker_loss, parent_run_id, nesting_depth,
                    continued_from_run_id, continued_to_run_id
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21)
                """,
                run.run_id,
                run.workflow_name,
                run.status.value,
                run.created_at,
                run.updated_at,
                run.started_at,
                run.completed_at,
                run.input_args,
                run.input_kwargs,
                run.result,
                run.error,
                run.idempotency_key,
                run.max_duration,
                json.dumps(run.context),
                run.recovery_attempts,
                run.max_recovery_attempts,
                run.recover_on_worker_loss,
                run.parent_run_id,
                run.nesting_depth,
                run.continued_from_run_id,
                run.continued_to_run_id,
            )

    async def get_run(self, run_id: str) -> WorkflowRun | None:
        """Retrieve a workflow run by ID."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM workflow_runs WHERE run_id = $1", run_id)

        if not row:
            return None

        return self._row_to_workflow_run(row)

    async def get_run_by_idempotency_key(self, key: str) -> WorkflowRun | None:
        """Retrieve a workflow run by idempotency key."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM workflow_runs WHERE idempotency_key = $1", key)

        if not row:
            return None

        return self._row_to_workflow_run(row)

    async def update_run_status(
        self,
        run_id: str,
        status: RunStatus,
        result: str | None = None,
        error: str | None = None,
    ) -> None:
        """Update workflow run status."""
        pool = await self._get_pool()

        now = datetime.now(UTC)
        completed_at = now if status == RunStatus.COMPLETED else None

        # Build dynamic query
        updates = ["status = $1", "updated_at = $2"]
        params: list[Any] = [status.value, now]
        param_idx = 3

        if result is not None:
            updates.append(f"result = ${param_idx}")
            params.append(result)
            param_idx += 1

        if error is not None:
            updates.append(f"error = ${param_idx}")
            params.append(error)
            param_idx += 1

        if completed_at:
            updates.append(f"completed_at = ${param_idx}")
            params.append(completed_at)
            param_idx += 1

        params.append(run_id)

        async with pool.acquire() as conn:
            await conn.execute(
                f"UPDATE workflow_runs SET {', '.join(updates)} WHERE run_id = ${param_idx}",
                *params,
            )

    async def update_run_recovery_attempts(
        self,
        run_id: str,
        recovery_attempts: int,
    ) -> None:
        """Update the recovery attempts counter for a workflow run."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            await conn.execute(
                """
                UPDATE workflow_runs
                SET recovery_attempts = $1, updated_at = $2
                WHERE run_id = $3
                """,
                recovery_attempts,
                datetime.now(UTC),
                run_id,
            )

    async def update_run_context(
        self,
        run_id: str,
        context: dict,
    ) -> None:
        """Update the step context for a workflow run."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            await conn.execute(
                """
                UPDATE workflow_runs
                SET metadata = $1, updated_at = $2
                WHERE run_id = $3
                """,
                json.dumps(context),
                datetime.now(UTC),
                run_id,
            )

    async def get_run_context(self, run_id: str) -> dict:
        """Get the current step context for a workflow run."""
        run = await self.get_run(run_id)
        return run.context if run else {}

    async def list_runs(
        self,
        query: str | None = None,
        status: RunStatus | None = None,
        start_time: datetime | None = None,
        end_time: datetime | None = None,
        limit: int = 100,
        cursor: str | None = None,
    ) -> tuple[list[WorkflowRun], str | None]:
        """List workflow runs with optional filtering and pagination."""
        pool = await self._get_pool()

        conditions = []
        params: list[Any] = []
        param_idx = 1

        if cursor:
            conditions.append(
                f"created_at < (SELECT created_at FROM workflow_runs WHERE run_id = ${param_idx})"
            )
            params.append(cursor)
            param_idx += 1

        if query:
            conditions.append(
                f"(workflow_name LIKE ${param_idx} OR input_kwargs LIKE ${param_idx + 1})"
            )
            search_param = f"%{query}%"
            params.extend([search_param, search_param])
            param_idx += 2

        if status:
            conditions.append(f"status = ${param_idx}")
            params.append(status.value)
            param_idx += 1

        if start_time:
            conditions.append(f"created_at >= ${param_idx}")
            params.append(start_time)
            param_idx += 1

        if end_time:
            conditions.append(f"created_at < ${param_idx}")
            params.append(end_time)
            param_idx += 1

        where_clause = f"WHERE {' AND '.join(conditions)}" if conditions else ""
        params.append(limit + 1)  # Fetch one extra to determine if there are more

        sql = f"""
            SELECT * FROM workflow_runs
            {where_clause}
            ORDER BY created_at DESC
            LIMIT ${param_idx}
        """

        async with pool.acquire() as conn:
            rows = await conn.fetch(sql, *params)

        has_more = len(rows) > limit
        if has_more:
            rows = rows[:limit]

        runs = [self._row_to_workflow_run(row) for row in rows]
        next_cursor = runs[-1].run_id if runs and has_more else None

        return runs, next_cursor

    # Event Log Operations

    async def record_event(self, event: Event) -> None:
        """Record an event to the append-only event log."""
        pool = await self._get_pool()

        # Extract step_id from event data for indexed column
        step_id = event.data.get("step_id") if event.data else None

        async with pool.acquire() as conn, conn.transaction():
            # Get next sequence number and insert in a transaction
            row = await conn.fetchrow(
                "SELECT COALESCE(MAX(sequence), -1) + 1 FROM events WHERE run_id = $1",
                event.run_id,
            )
            sequence = row[0] if row else 0

            await conn.execute(
                """
                INSERT INTO events (event_id, run_id, sequence, type, timestamp, data, step_id)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
                """,
                event.event_id,
                event.run_id,
                sequence,
                event.type.value,
                event.timestamp,
                json.dumps(event.data),
                step_id,
            )

    async def get_events(
        self,
        run_id: str,
        event_types: list[str] | None = None,
    ) -> list[Event]:
        """Retrieve all events for a workflow run, ordered by sequence."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            if event_types:
                rows = await conn.fetch(
                    """
                    SELECT * FROM events
                    WHERE run_id = $1 AND type = ANY($2)
                    ORDER BY sequence ASC
                    """,
                    run_id,
                    event_types,
                )
            else:
                rows = await conn.fetch(
                    "SELECT * FROM events WHERE run_id = $1 ORDER BY sequence ASC",
                    run_id,
                )

        return [self._row_to_event(row) for row in rows]

    async def get_latest_event(
        self,
        run_id: str,
        event_type: str | None = None,
    ) -> Event | None:
        """Get the latest event for a run, optionally filtered by type."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            if event_type:
                row = await conn.fetchrow(
                    """
                    SELECT * FROM events
                    WHERE run_id = $1 AND type = $2
                    ORDER BY sequence DESC
                    LIMIT 1
                    """,
                    run_id,
                    event_type,
                )
            else:
                row = await conn.fetchrow(
                    """
                    SELECT * FROM events
                    WHERE run_id = $1
                    ORDER BY sequence DESC
                    LIMIT 1
                    """,
                    run_id,
                )

        if not row:
            return None

        return self._row_to_event(row)

    async def has_event(
        self,
        run_id: str,
        event_type: str,
        **filters: str,
    ) -> bool:
        """
        Check if an event exists using optimized indexed queries.

        When step_id is the only filter, uses a direct indexed query (O(1) lookup).
        For other filters, falls back to loading events of the type and filtering in Python.

        Args:
            run_id: Workflow run identifier
            event_type: Event type to check for
            **filters: Additional filters for event data fields

        Returns:
            True if a matching event exists, False otherwise
        """
        pool = await self._get_pool()

        # Optimized path: if only filtering by step_id, use indexed column directly
        if filters.keys() == {"step_id"}:
            step_id = str(filters["step_id"])
            async with pool.acquire() as conn:
                row = await conn.fetchrow(
                    """
                    SELECT 1 FROM events
                    WHERE run_id = $1 AND type = $2 AND step_id = $3
                    LIMIT 1
                    """,
                    run_id,
                    event_type,
                    step_id,
                )
            return row is not None

        # Fallback: load events of type and filter in Python
        events = await self.get_events(run_id, event_types=[event_type])

        for event in events:
            match = True
            for key, value in filters.items():
                if str(event.data.get(key)) != str(value):
                    match = False
                    break
            if match:
                return True

        return False

    # Step Operations

    async def create_step(self, step: StepExecution) -> None:
        """Create a step execution record."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO steps (
                    step_id, run_id, step_name, status, created_at, started_at,
                    completed_at, input_args, input_kwargs, result, error, retry_count
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
                """,
                step.step_id,
                step.run_id,
                step.step_name,
                step.status.value,
                step.created_at,
                step.started_at,
                step.completed_at,
                step.input_args,
                step.input_kwargs,
                step.result,
                step.error,
                step.attempt,
            )

    async def get_step(self, step_id: str) -> StepExecution | None:
        """Retrieve a step execution by ID."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM steps WHERE step_id = $1", step_id)

        if not row:
            return None

        return self._row_to_step_execution(row)

    async def update_step_status(
        self,
        step_id: str,
        status: str,
        result: str | None = None,
        error: str | None = None,
    ) -> None:
        """Update step execution status."""
        pool = await self._get_pool()

        updates = ["status = $1"]
        params: list[Any] = [status]
        param_idx = 2

        if result is not None:
            updates.append(f"result = ${param_idx}")
            params.append(result)
            param_idx += 1

        if error is not None:
            updates.append(f"error = ${param_idx}")
            params.append(error)
            param_idx += 1

        if status == "completed":
            updates.append(f"completed_at = ${param_idx}")
            params.append(datetime.now(UTC))
            param_idx += 1

        params.append(step_id)

        async with pool.acquire() as conn:
            await conn.execute(
                f"UPDATE steps SET {', '.join(updates)} WHERE step_id = ${param_idx}",
                *params,
            )

    async def list_steps(self, run_id: str) -> list[StepExecution]:
        """List all steps for a workflow run."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM steps WHERE run_id = $1 ORDER BY created_at ASC",
                run_id,
            )

        return [self._row_to_step_execution(row) for row in rows]

    # Hook Operations

    async def create_hook(self, hook: Hook) -> None:
        """Create a hook record."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO hooks (
                    hook_id, run_id, token, created_at, received_at, expires_at,
                    status, payload, metadata
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
                """,
                hook.hook_id,
                hook.run_id,
                hook.token,
                hook.created_at,
                hook.received_at,
                hook.expires_at,
                hook.status.value,
                hook.payload,
                json.dumps(hook.metadata),
            )

    async def get_hook(self, hook_id: str, run_id: str | None = None) -> Hook | None:
        """Retrieve a hook by ID (requires run_id for composite key lookup)."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            if run_id:
                row = await conn.fetchrow(
                    "SELECT * FROM hooks WHERE run_id = $1 AND hook_id = $2",
                    run_id,
                    hook_id,
                )
            else:
                # Fallback: find any hook with this ID (may return wrong one if duplicates)
                row = await conn.fetchrow("SELECT * FROM hooks WHERE hook_id = $1", hook_id)

        if not row:
            return None

        return self._row_to_hook(row)

    async def get_hook_by_token(self, token: str) -> Hook | None:
        """Retrieve a hook by its token."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM hooks WHERE token = $1", token)

        if not row:
            return None

        return self._row_to_hook(row)

    async def update_hook_status(
        self,
        hook_id: str,
        status: HookStatus,
        payload: str | None = None,
        run_id: str | None = None,
    ) -> None:
        """Update hook status and optionally payload."""
        pool = await self._get_pool()

        updates = ["status = $1"]
        params: list[Any] = [status.value]
        param_idx = 2

        if payload is not None:
            updates.append(f"payload = ${param_idx}")
            params.append(payload)
            param_idx += 1

        if status == HookStatus.RECEIVED:
            updates.append(f"received_at = ${param_idx}")
            params.append(datetime.now(UTC))
            param_idx += 1

        async with pool.acquire() as conn:
            if run_id:
                params.append(run_id)
                params.append(hook_id)
                await conn.execute(
                    f"UPDATE hooks SET {', '.join(updates)} WHERE run_id = ${param_idx} AND hook_id = ${param_idx + 1}",
                    *params,
                )
            else:
                params.append(hook_id)
                await conn.execute(
                    f"UPDATE hooks SET {', '.join(updates)} WHERE hook_id = ${param_idx}",
                    *params,
                )

    async def list_hooks(
        self,
        run_id: str | None = None,
        status: HookStatus | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[Hook]:
        """List hooks with optional filtering."""
        pool = await self._get_pool()

        conditions = []
        params: list[Any] = []
        param_idx = 1

        if run_id:
            conditions.append(f"run_id = ${param_idx}")
            params.append(run_id)
            param_idx += 1

        if status:
            conditions.append(f"status = ${param_idx}")
            params.append(status.value)
            param_idx += 1

        where_clause = f"WHERE {' AND '.join(conditions)}" if conditions else ""
        params.extend([limit, offset])

        sql = f"""
            SELECT * FROM hooks
            {where_clause}
            ORDER BY created_at DESC
            LIMIT ${param_idx} OFFSET ${param_idx + 1}
        """

        async with pool.acquire() as conn:
            rows = await conn.fetch(sql, *params)

        return [self._row_to_hook(row) for row in rows]

    # Atomic Status Transition

    async def try_claim_run(
        self, run_id: str, from_status: RunStatus, to_status: RunStatus
    ) -> bool:
        """Atomically transition run status using conditional UPDATE."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            result = await conn.execute(
                """
                UPDATE workflow_runs
                SET status = $1, updated_at = $2
                WHERE run_id = $3 AND status = $4
                """,
                to_status.value,
                datetime.now(UTC),
                run_id,
                from_status.value,
            )

        # asyncpg returns 'UPDATE N' where N is rows affected
        return result == "UPDATE 1"

    # Cancellation Flag Operations

    async def set_cancellation_flag(self, run_id: str) -> None:
        """Set a cancellation flag for a workflow run."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO cancellation_flags (run_id, created_at)
                VALUES ($1, $2)
                ON CONFLICT (run_id) DO NOTHING
                """,
                run_id,
                datetime.now(UTC),
            )

    async def check_cancellation_flag(self, run_id: str) -> bool:
        """Check if a cancellation flag is set for a workflow run."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            row = await conn.fetchrow("SELECT 1 FROM cancellation_flags WHERE run_id = $1", run_id)

        return row is not None

    async def clear_cancellation_flag(self, run_id: str) -> None:
        """Clear the cancellation flag for a workflow run."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            await conn.execute("DELETE FROM cancellation_flags WHERE run_id = $1", run_id)

    # Checkpoint Operations

    async def save_checkpoint(self, step_run_id: str, data: dict) -> None:
        """Save or update a checkpoint for a step run."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO checkpoints (step_run_id, data, created_at, updated_at)
                VALUES ($1, $2, $3, $3)
                ON CONFLICT (step_run_id) DO UPDATE SET data = $2, updated_at = $3
                """,
                step_run_id,
                json.dumps(data),
                datetime.now(UTC),
            )

    async def load_checkpoint(self, step_run_id: str) -> dict | None:
        """Load a checkpoint for a step run, or None if not found."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT data FROM checkpoints WHERE step_run_id = $1", step_run_id
            )

        if row is None:
            return None
        return json.loads(row["data"])

    async def delete_checkpoint(self, step_run_id: str) -> None:
        """Delete a checkpoint for a step run."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            await conn.execute("DELETE FROM checkpoints WHERE step_run_id = $1", step_run_id)

    # Continue-As-New Chain Operations

    async def update_run_continuation(
        self,
        run_id: str,
        continued_to_run_id: str,
    ) -> None:
        """Update the continuation link for a workflow run."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            await conn.execute(
                """
                UPDATE workflow_runs
                SET continued_to_run_id = $1, updated_at = $2
                WHERE run_id = $3
                """,
                continued_to_run_id,
                datetime.now(UTC),
                run_id,
            )

    async def get_workflow_chain(
        self,
        run_id: str,
    ) -> list[WorkflowRun]:
        """Get all runs in a continue-as-new chain."""
        pool = await self._get_pool()

        # Find the first run in the chain
        current_id: str | None = run_id
        async with pool.acquire() as conn:
            while True:
                row = await conn.fetchrow(
                    "SELECT continued_from_run_id FROM workflow_runs WHERE run_id = $1",
                    current_id,
                )

                if not row or not row[0]:
                    break

                current_id = row[0]

        # Now collect all runs in the chain from first to last
        runs = []
        while current_id:
            run = await self.get_run(current_id)
            if not run:
                break
            runs.append(run)
            current_id = run.continued_to_run_id

        return runs

    # Child Workflow Operations

    async def get_children(
        self,
        parent_run_id: str,
        status: RunStatus | None = None,
    ) -> list[WorkflowRun]:
        """Get all child workflow runs for a parent workflow."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            if status:
                rows = await conn.fetch(
                    """
                    SELECT * FROM workflow_runs
                    WHERE parent_run_id = $1 AND status = $2
                    ORDER BY created_at ASC
                    """,
                    parent_run_id,
                    status.value,
                )
            else:
                rows = await conn.fetch(
                    """
                    SELECT * FROM workflow_runs
                    WHERE parent_run_id = $1
                    ORDER BY created_at ASC
                    """,
                    parent_run_id,
                )

        return [self._row_to_workflow_run(row) for row in rows]

    async def get_parent(self, run_id: str) -> WorkflowRun | None:
        """Get the parent workflow run for a child workflow."""
        run = await self.get_run(run_id)
        if not run or not run.parent_run_id:
            return None

        return await self.get_run(run.parent_run_id)

    async def get_nesting_depth(self, run_id: str) -> int:
        """Get the nesting depth for a workflow."""
        run = await self.get_run(run_id)
        return run.nesting_depth if run else 0

    # Schedule Operations

    async def create_schedule(self, schedule: Schedule) -> None:
        """Create a new schedule record."""
        pool = await self._get_pool()

        # Derive spec_type from the ScheduleSpec
        spec_type = (
            "cron" if schedule.spec.cron else ("interval" if schedule.spec.interval else "calendar")
        )

        async with pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO schedules (
                    schedule_id, workflow_name, spec, spec_type, timezone,
                    input_args, input_kwargs, status, overlap_policy,
                    next_run_time, last_run_time, running_run_ids, metadata,
                    created_at, updated_at, paused_at, deleted_at
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17)
                """,
                schedule.schedule_id,
                schedule.workflow_name,
                json.dumps(schedule.spec.to_dict()),
                spec_type,
                schedule.spec.timezone,
                schedule.args,
                schedule.kwargs,
                schedule.status.value,
                schedule.overlap_policy.value,
                schedule.next_run_time,
                schedule.last_run_at,
                json.dumps(schedule.running_run_ids),
                "{}",  # metadata - not in current dataclass
                schedule.created_at,
                schedule.updated_at,
                None,  # paused_at - not in current dataclass
                None,  # deleted_at - not in current dataclass
            )

    async def get_schedule(self, schedule_id: str) -> Schedule | None:
        """Retrieve a schedule by ID."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM schedules WHERE schedule_id = $1", schedule_id)

        if not row:
            return None

        return self._row_to_schedule(row)

    async def update_schedule(self, schedule: Schedule) -> None:
        """Update an existing schedule."""
        pool = await self._get_pool()

        # Derive spec_type from the ScheduleSpec
        spec_type = (
            "cron" if schedule.spec.cron else ("interval" if schedule.spec.interval else "calendar")
        )

        async with pool.acquire() as conn:
            await conn.execute(
                """
                UPDATE schedules SET
                    workflow_name = $1, spec = $2, spec_type = $3, timezone = $4,
                    input_args = $5, input_kwargs = $6, status = $7, overlap_policy = $8,
                    next_run_time = $9, last_run_time = $10, running_run_ids = $11,
                    metadata = $12, updated_at = $13, paused_at = $14, deleted_at = $15
                WHERE schedule_id = $16
                """,
                schedule.workflow_name,
                json.dumps(schedule.spec.to_dict()),
                spec_type,
                schedule.spec.timezone,
                schedule.args,
                schedule.kwargs,
                schedule.status.value,
                schedule.overlap_policy.value,
                schedule.next_run_time,
                schedule.last_run_at,
                json.dumps(schedule.running_run_ids),
                "{}",  # metadata - not in current dataclass
                schedule.updated_at,
                None,  # paused_at - not in current dataclass
                None,  # deleted_at - not in current dataclass
                schedule.schedule_id,
            )

    async def delete_schedule(self, schedule_id: str) -> None:
        """Mark a schedule as deleted (soft delete)."""
        pool = await self._get_pool()

        now = datetime.now(UTC)
        async with pool.acquire() as conn:
            await conn.execute(
                """
                UPDATE schedules
                SET status = $1, deleted_at = $2, updated_at = $3
                WHERE schedule_id = $4
                """,
                ScheduleStatus.DELETED.value,
                now,
                now,
                schedule_id,
            )

    async def list_schedules(
        self,
        workflow_name: str | None = None,
        status: ScheduleStatus | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[Schedule]:
        """List schedules with optional filtering."""
        pool = await self._get_pool()

        conditions = []
        params: list[Any] = []
        param_idx = 1

        if workflow_name:
            conditions.append(f"workflow_name = ${param_idx}")
            params.append(workflow_name)
            param_idx += 1

        if status:
            conditions.append(f"status = ${param_idx}")
            params.append(status.value)
            param_idx += 1

        where_clause = f"WHERE {' AND '.join(conditions)}" if conditions else ""
        params.extend([limit, offset])

        sql = f"""
            SELECT * FROM schedules
            {where_clause}
            ORDER BY created_at DESC
            LIMIT ${param_idx} OFFSET ${param_idx + 1}
        """

        async with pool.acquire() as conn:
            rows = await conn.fetch(sql, *params)

        return [self._row_to_schedule(row) for row in rows]

    async def get_due_schedules(self, now: datetime) -> list[Schedule]:
        """Get all schedules that are due to run."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT * FROM schedules
                WHERE status = $1 AND next_run_time IS NOT NULL AND next_run_time <= $2
                ORDER BY next_run_time ASC
                """,
                ScheduleStatus.ACTIVE.value,
                now,
            )

        return [self._row_to_schedule(row) for row in rows]

    async def add_running_run(self, schedule_id: str, run_id: str) -> None:
        """Add a run_id to the schedule's running_run_ids list."""
        schedule = await self.get_schedule(schedule_id)
        if not schedule:
            raise ValueError(f"Schedule {schedule_id} not found")

        if run_id not in schedule.running_run_ids:
            schedule.running_run_ids.append(run_id)
            schedule.updated_at = datetime.now(UTC)
            await self.update_schedule(schedule)

    async def remove_running_run(self, schedule_id: str, run_id: str) -> None:
        """Remove a run_id from the schedule's running_run_ids list."""
        schedule = await self.get_schedule(schedule_id)
        if not schedule:
            raise ValueError(f"Schedule {schedule_id} not found")

        if run_id in schedule.running_run_ids:
            schedule.running_run_ids.remove(run_id)
            schedule.updated_at = datetime.now(UTC)
            await self.update_schedule(schedule)

    async def delete_old_runs(self, older_than: datetime) -> int:
        """Delete terminal runs (and all related data) updated before older_than."""
        terminal = ["completed", "failed", "cancelled", "continued_as_new", "interrupted"]
        pool = await self._get_pool()
        async with pool.acquire() as conn, conn.transaction():
            subq = "SELECT run_id FROM workflow_runs WHERE status = ANY($1) AND updated_at < $2"
            await conn.execute(f"DELETE FROM events WHERE run_id IN ({subq})", terminal, older_than)
            step_subq = f"SELECT step_id FROM steps WHERE run_id IN ({subq})"
            await conn.execute(
                f"DELETE FROM checkpoints WHERE step_run_id IN ({step_subq})",
                terminal,
                older_than,
            )
            await conn.execute(f"DELETE FROM steps WHERE run_id IN ({subq})", terminal, older_than)
            await conn.execute(f"DELETE FROM hooks WHERE run_id IN ({subq})", terminal, older_than)
            await conn.execute(
                f"DELETE FROM cancellation_flags WHERE run_id IN ({subq})",
                terminal,
                older_than,
            )
            result = await conn.execute(
                "DELETE FROM workflow_runs WHERE status = ANY($1) AND updated_at < $2",
                terminal,
                older_than,
            )
            # asyncpg returns e.g. "DELETE 42"
            return int(result.split()[-1])

    # Helper methods for converting database rows to domain objects

    def _row_to_workflow_run(self, row: asyncpg.Record) -> WorkflowRun:
        """Convert database row to WorkflowRun object."""
        return WorkflowRun(
            run_id=row["run_id"],
            workflow_name=row["workflow_name"],
            status=RunStatus(row["status"]),
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            started_at=row["started_at"],
            completed_at=row["completed_at"],
            input_args=row["input_args"],
            input_kwargs=row["input_kwargs"],
            result=row["result"],
            error=row["error"],
            idempotency_key=row["idempotency_key"],
            max_duration=row["max_duration"],
            context=json.loads(row["metadata"]) if row["metadata"] else {},
            recovery_attempts=row["recovery_attempts"],
            max_recovery_attempts=row["max_recovery_attempts"],
            recover_on_worker_loss=row["recover_on_worker_loss"],
            parent_run_id=row["parent_run_id"],
            nesting_depth=row["nesting_depth"],
            continued_from_run_id=row["continued_from_run_id"],
            continued_to_run_id=row["continued_to_run_id"],
        )

    def _row_to_event(self, row: asyncpg.Record) -> Event:
        """Convert database row to Event object."""
        return Event(
            event_id=row["event_id"],
            run_id=row["run_id"],
            sequence=row["sequence"],
            type=EventType(row["type"]),
            timestamp=row["timestamp"],
            data=json.loads(row["data"]) if row["data"] else {},
        )

    def _row_to_step_execution(self, row: asyncpg.Record) -> StepExecution:
        """Convert database row to StepExecution object."""
        return StepExecution(
            step_id=row["step_id"],
            run_id=row["run_id"],
            step_name=row["step_name"],
            status=StepStatus(row["status"]),
            created_at=row["created_at"],
            started_at=row["started_at"],
            completed_at=row["completed_at"],
            input_args=row["input_args"],
            input_kwargs=row["input_kwargs"],
            result=row["result"],
            error=row["error"],
            attempt=row["retry_count"] or 1,
        )

    def _row_to_hook(self, row: asyncpg.Record) -> Hook:
        """Convert database row to Hook object."""
        return Hook(
            hook_id=row["hook_id"],
            run_id=row["run_id"],
            token=row["token"],
            created_at=row["created_at"],
            received_at=row["received_at"],
            expires_at=row["expires_at"],
            status=HookStatus(row["status"]),
            payload=row["payload"],
            metadata=json.loads(row["metadata"]) if row["metadata"] else {},
        )

    def _row_to_schedule(self, row: asyncpg.Record) -> Schedule:
        """Convert database row to Schedule object."""
        # Parse the spec from JSON and create ScheduleSpec
        spec_data = json.loads(row["spec"]) if row["spec"] else {}
        spec = ScheduleSpec.from_dict(spec_data)

        return Schedule(
            schedule_id=row["schedule_id"],
            workflow_name=row["workflow_name"],
            spec=spec,
            status=ScheduleStatus(row["status"]),
            args=row["input_args"],
            kwargs=row["input_kwargs"],
            overlap_policy=OverlapPolicy(row["overlap_policy"]),
            next_run_time=row["next_run_time"],
            last_run_at=row["last_run_time"],
            running_run_ids=json.loads(row["running_run_ids"]) if row["running_run_ids"] else [],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
        )

    # Stream Operations

    async def create_stream(self, stream_id: str, metadata: dict | None = None) -> None:
        """Create a new stream."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO streams (stream_id, status, created_at, metadata)
                VALUES ($1, $2, $3, $4)
                """,
                stream_id,
                "active",
                datetime.now(UTC),
                json.dumps(metadata or {}),
            )

    async def get_stream(self, stream_id: str) -> dict | None:
        """Get a stream by ID."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT stream_id, status, created_at, metadata FROM streams WHERE stream_id = $1",
                stream_id,
            )

        if row is None:
            return None
        return {
            "stream_id": row["stream_id"],
            "status": row["status"],
            "created_at": row["created_at"].isoformat() if row["created_at"] else None,
            "metadata": json.loads(row["metadata"]) if row["metadata"] else {},
        }

    async def publish_signal(
        self,
        signal_id: str,
        stream_id: str,
        signal_type: str,
        payload: dict,
        source_run_id: str | None = None,
        stream_run_id: str | None = None,
        metadata: dict | None = None,
    ) -> int:
        """Publish a signal to a stream."""
        pool = await self._get_pool()
        now = datetime.now(UTC)
        # stream_run_id is part of the signals PK and cannot be NULL.
        # Coerce missing values to a sentinel so legacy emit() callers
        # (which never passed stream_run_id) keep working.
        if not stream_run_id:
            stream_run_id = "__none__"

        async with pool.acquire() as conn:
            # Get next sequence number (scoped per stream_run_id)
            row = await conn.fetchrow(
                "SELECT COALESCE(MAX(sequence), -1) + 1 AS seq FROM signals WHERE stream_run_id = $1",
                stream_run_id,
            )
            seq = row["seq"] if row else 0

            await conn.execute(
                """
                INSERT INTO signals (signal_id, stream_id, signal_type, payload, published_at, sequence, source_run_id, stream_run_id, metadata)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
                """,
                signal_id,
                stream_id,
                signal_type,
                json.dumps(payload),
                now,
                seq,
                source_run_id,
                stream_run_id,
                json.dumps(metadata or {}),
            )
        return seq

    async def get_signals(
        self,
        stream_id: str,
        after_sequence: int = 0,
        limit: int = 100,
    ) -> list[dict]:
        """Get signals from a stream after a given sequence number."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT signal_id, stream_id, signal_type, payload, published_at, sequence, source_run_id, stream_run_id, metadata
                FROM signals
                WHERE stream_id = $1 AND sequence >= $2
                ORDER BY sequence ASC
                LIMIT $3
                """,
                stream_id,
                after_sequence,
                limit,
            )

        return [
            {
                "signal_id": row["signal_id"],
                "stream_id": row["stream_id"],
                "signal_type": row["signal_type"],
                "payload": json.loads(row["payload"]) if row["payload"] else {},
                "published_at": row["published_at"].isoformat() if row["published_at"] else None,
                "sequence": row["sequence"],
                "source_run_id": row["source_run_id"],
                "stream_run_id": row.get("stream_run_id"),
                "metadata": json.loads(row["metadata"]) if row["metadata"] else {},
            }
            for row in rows
        ]

    async def query_stream_signals(
        self,
        stream_id: str,
        stream_run_id: str,
        *,
        source_run_id: str | None = None,
        signal_type: str | None = None,
        after_sequence: int | None = None,
        before_sequence: int | None = None,
        last_n: int | None = None,
        limit: int = 50,
    ) -> list[dict]:
        """Query signals from a stream with rich filtering."""
        pool = await self._get_pool()

        # Build WHERE clauses dynamically
        conditions = ["stream_id = $1", "stream_run_id = $2"]
        params: list = [stream_id, stream_run_id]
        idx = 3

        if source_run_id is not None:
            conditions.append(f"source_run_id = ${idx}")
            params.append(source_run_id)
            idx += 1

        if signal_type is not None:
            conditions.append(f"signal_type = ${idx}")
            params.append(signal_type)
            idx += 1

        if last_n is not None:
            # last_n mode: get the N most recent, ignore after_sequence
            effective_limit = min(last_n, 200)
        else:
            if after_sequence is not None:
                conditions.append(f"sequence >= ${idx}")
                params.append(after_sequence)
                idx += 1
            if before_sequence is not None:
                conditions.append(f"sequence <= ${idx}")
                params.append(before_sequence)
                idx += 1
            effective_limit = min(limit, 200)

        where = " AND ".join(conditions)

        if last_n is not None:
            # Fetch in DESC then reverse for chronological output
            query = f"""
                SELECT signal_id, stream_id, signal_type, payload,
                       published_at, sequence, source_run_id, stream_run_id, metadata
                FROM signals
                WHERE {where}
                ORDER BY sequence DESC
                LIMIT ${idx}
            """
        else:
            query = f"""
                SELECT signal_id, stream_id, signal_type, payload,
                       published_at, sequence, source_run_id, stream_run_id, metadata
                FROM signals
                WHERE {where}
                ORDER BY sequence ASC
                LIMIT ${idx}
            """
        params.append(effective_limit)

        async with pool.acquire() as conn:
            rows = await conn.fetch(query, *params)

        results = [
            {
                "signal_id": row["signal_id"],
                "stream_id": row["stream_id"],
                "signal_type": row["signal_type"],
                "payload": json.loads(row["payload"]) if row["payload"] else {},
                "published_at": (row["published_at"].isoformat() if row["published_at"] else None),
                "sequence": row["sequence"],
                "source_run_id": row["source_run_id"],
                "stream_run_id": row.get("stream_run_id"),
                "metadata": json.loads(row["metadata"]) if row["metadata"] else {},
            }
            for row in rows
        ]

        # Reverse DESC results to chronological order
        if last_n is not None:
            results.reverse()

        return results

    async def register_stream_subscription(
        self,
        stream_id: str,
        step_run_id: str,
        signal_types: list[str],
        stream_run_id: str | None = None,
    ) -> None:
        """Register a stream step's subscription to signal types."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO stream_subscriptions
                    (stream_id, step_run_id, signal_types, status, stream_run_id, created_at)
                VALUES ($1, $2, $3, $4, $5, $6)
                ON CONFLICT (stream_id, step_run_id)
                DO UPDATE SET signal_types = $3, status = $4, stream_run_id = $5
                """,
                stream_id,
                step_run_id,
                json.dumps(signal_types),
                "waiting",
                stream_run_id,
                datetime.now(UTC),
            )

    async def set_subscription_result(
        self,
        stream_id: str,
        step_run_id: str,
        result: Any,
    ) -> None:
        """Persist a stream step's result payload on its subscription row."""
        pool = await self._get_pool()
        async with pool.acquire() as conn:
            await conn.execute(
                """
                UPDATE stream_subscriptions
                   SET result = $3::jsonb
                 WHERE stream_id = $1 AND step_run_id = $2
                """,
                stream_id,
                step_run_id,
                json.dumps(result),
            )

    async def set_stream_parent_link(
        self,
        stream_id: str,
        stream_run_id: str,
        parent_run_id: str,
        parent_hook_token: str,
    ) -> None:
        """Record (parent_run_id, parent_hook_token) on every subscription
        for this stream run so the dispatcher can call resume_hook() when
        the stream reaches a terminal aggregate state."""
        pool = await self._get_pool()
        async with pool.acquire() as conn:
            await conn.execute(
                """
                UPDATE stream_subscriptions
                   SET parent_run_id = $3, parent_hook_token = $4
                 WHERE stream_id = $1 AND stream_run_id = $2
                """,
                stream_id,
                stream_run_id,
                parent_run_id,
                parent_hook_token,
            )

    async def get_stream_parent_link(
        self,
        stream_id: str,
        stream_run_id: str,
    ) -> tuple[str, str] | None:
        """Return (parent_run_id, parent_hook_token) for a stream run, if set."""
        pool = await self._get_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT parent_run_id, parent_hook_token
                  FROM stream_subscriptions
                 WHERE stream_id = $1 AND stream_run_id = $2
                   AND parent_run_id IS NOT NULL
                 LIMIT 1
                """,
                stream_id,
                stream_run_id,
            )
            if row and row["parent_run_id"] and row["parent_hook_token"]:
                return (row["parent_run_id"], row["parent_hook_token"])
            return None

    async def get_subscription_states(
        self,
        stream_id: str,
        stream_run_id: str | None = None,
    ) -> list[dict]:
        """Return all subscriptions and statuses for a stream run."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            if stream_run_id is None:
                rows = await conn.fetch(
                    """
                    SELECT stream_id, step_run_id, status, stream_run_id, result
                    FROM stream_subscriptions
                    WHERE stream_id = $1
                    """,
                    stream_id,
                )
            else:
                rows = await conn.fetch(
                    """
                    SELECT stream_id, step_run_id, status, stream_run_id, result
                    FROM stream_subscriptions
                    WHERE stream_id = $1
                      AND stream_run_id = $2
                    """,
                    stream_id,
                    stream_run_id,
                )

        return [
            {
                "stream_id": row["stream_id"],
                "step_run_id": row["step_run_id"],
                "status": row["status"],
                "stream_run_id": row["stream_run_id"],
                "result": json.loads(row["result"]) if row["result"] else None,
            }
            for row in rows
        ]

    async def schedule_signal(
        self,
        *,
        stream_id: str,
        signal_type: str,
        payload: dict,
        due_at: datetime,
        stream_run_id: str | None = None,
        metadata: dict | None = None,
    ) -> str:
        """Persist a signal to be emitted at ``due_at``."""
        import uuid as _uuid

        sched_id = f"sched_{_uuid.uuid4().hex[:16]}"
        pool = await self._get_pool()
        async with pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO scheduled_signals
                    (id, stream_id, signal_type, payload, due_at, stream_run_id, metadata)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
                """,
                sched_id,
                stream_id,
                signal_type,
                json.dumps(payload or {}),
                due_at,
                stream_run_id,
                json.dumps(metadata or {}),
            )
        return sched_id

    async def fetch_due_scheduled_signals(
        self,
        now: datetime,
        limit: int = 100,
    ) -> list[dict]:
        """Return due, undelivered scheduled signals."""
        pool = await self._get_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT id, stream_id, signal_type, payload, due_at, stream_run_id, metadata
                FROM scheduled_signals
                WHERE delivered = FALSE AND due_at <= $1
                ORDER BY due_at ASC
                LIMIT $2
                """,
                now,
                limit,
            )

        return [
            {
                "id": row["id"],
                "stream_id": row["stream_id"],
                "signal_type": row["signal_type"],
                "payload": json.loads(row["payload"]) if row["payload"] else {},
                "due_at": row["due_at"],
                "stream_run_id": row["stream_run_id"],
                "metadata": json.loads(row["metadata"]) if row["metadata"] else {},
            }
            for row in rows
        ]

    async def mark_scheduled_signal_delivered(self, sched_id: str) -> None:
        """Mark a scheduled signal as delivered."""
        pool = await self._get_pool()
        async with pool.acquire() as conn:
            await conn.execute(
                "UPDATE scheduled_signals SET delivered = TRUE WHERE id = $1",
                sched_id,
            )

    async def get_waiting_steps(
        self,
        stream_id: str,
        signal_type: str,
        stream_run_id: str | None = None,
    ) -> list[dict]:
        """Get step_run_ids waiting for a specific signal type on a stream."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            if stream_run_id is not None:
                rows = await conn.fetch(
                    """
                    SELECT stream_id, step_run_id, signal_types, status, created_at
                    FROM stream_subscriptions
                    WHERE stream_id = $1 AND status IN ('waiting', 'suspended')
                      AND stream_run_id = $2
                    """,
                    stream_id,
                    stream_run_id,
                )
            else:
                rows = await conn.fetch(
                    """
                    SELECT stream_id, step_run_id, signal_types, status, created_at
                    FROM stream_subscriptions
                    WHERE stream_id = $1 AND status IN ('waiting', 'suspended')
                    """,
                    stream_id,
                )

        result = []
        for row in rows:
            signal_types = json.loads(row["signal_types"]) if row["signal_types"] else []
            if signal_type in signal_types:
                result.append(
                    {
                        "stream_id": row["stream_id"],
                        "step_run_id": row["step_run_id"],
                        "signal_types": signal_types,
                        "status": row["status"],
                        "created_at": row["created_at"].isoformat() if row["created_at"] else None,
                    }
                )
        return result

    async def get_subscriptions_for_stream(
        self,
        stream_id: str,
        signal_type: str,
        stream_run_id: str | None = None,
    ) -> list[dict]:
        """Get ALL subscriptions for a signal type, regardless of status."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            if stream_run_id is not None:
                rows = await conn.fetch(
                    """
                    SELECT stream_id, step_run_id, signal_types, status, created_at
                    FROM stream_subscriptions
                    WHERE stream_id = $1 AND stream_run_id = $2
                    """,
                    stream_id,
                    stream_run_id,
                )
            else:
                rows = await conn.fetch(
                    """
                    SELECT stream_id, step_run_id, signal_types, status, created_at
                    FROM stream_subscriptions
                    WHERE stream_id = $1
                    """,
                    stream_id,
                )

        result = []
        for row in rows:
            signal_types = json.loads(row["signal_types"]) if row["signal_types"] else []
            if signal_type in signal_types:
                result.append(
                    {
                        "stream_id": row["stream_id"],
                        "step_run_id": row["step_run_id"],
                        "signal_types": signal_types,
                        "status": row["status"],
                        "created_at": row["created_at"].isoformat() if row["created_at"] else None,
                    }
                )
        return result

    async def update_subscription_status(
        self,
        stream_id: str,
        step_run_id: str,
        status: str,
    ) -> None:
        """Update a subscription's status."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            await conn.execute(
                """
                UPDATE stream_subscriptions SET status = $1
                WHERE stream_id = $2 AND step_run_id = $3
                """,
                status,
                stream_id,
                step_run_id,
            )

    async def acknowledge_signal(
        self,
        signal_id: str,
        step_run_id: str,
    ) -> None:
        """Acknowledge that a signal has been processed by a step."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO signal_acknowledgments (signal_id, step_run_id, acknowledged_at)
                VALUES ($1, $2, $3)
                ON CONFLICT (signal_id, step_run_id) DO NOTHING
                """,
                signal_id,
                step_run_id,
                datetime.now(UTC),
            )

    async def get_pending_signals(
        self,
        stream_id: str,
        step_run_id: str,
    ) -> list[dict]:
        """Get signals that arrived for a step but haven't been acknowledged."""
        pool = await self._get_pool()

        async with pool.acquire() as conn:
            # Get subscription
            sub_row = await conn.fetchrow(
                "SELECT signal_types FROM stream_subscriptions WHERE stream_id = $1 AND step_run_id = $2",
                stream_id,
                step_run_id,
            )

            if not sub_row:
                return []

            signal_types = json.loads(sub_row["signal_types"]) if sub_row["signal_types"] else []
            if not signal_types:
                return []

            rows = await conn.fetch(
                """
                SELECT s.signal_id, s.stream_id, s.signal_type, s.payload, s.published_at,
                       s.sequence, s.source_run_id, s.stream_run_id, s.metadata
                FROM signals s
                WHERE s.stream_id = $1 AND s.signal_type = ANY($2)
                  AND NOT EXISTS (
                      SELECT 1 FROM signal_acknowledgments a
                      WHERE a.signal_id = s.signal_id AND a.step_run_id = $3
                  )
                ORDER BY s.sequence ASC
                """,
                stream_id,
                signal_types,
                step_run_id,
            )

        return [
            {
                "signal_id": row["signal_id"],
                "stream_id": row["stream_id"],
                "signal_type": row["signal_type"],
                "payload": json.loads(row["payload"]) if row["payload"] else {},
                "published_at": row["published_at"].isoformat() if row["published_at"] else None,
                "sequence": row["sequence"],
                "source_run_id": row["source_run_id"],
                "stream_run_id": row.get("stream_run_id"),
                "metadata": json.loads(row["metadata"]) if row["metadata"] else {},
            }
            for row in rows
        ]
