"""Tests for run context instruction overlays."""

from swarm.context import InstructionOverlay, render_instructions


class TestInstructionOverlays:
    def test_render_instructions_returns_base_prompt_when_no_overlays(self) -> None:
        assert (
            render_instructions(
                instructions="Base instructions.",
                instruction_overlays=(),
            )
            == "Base instructions."
        )

    def test_render_instructions_orders_overlays_before_agent_instructions(
        self,
    ) -> None:
        result = render_instructions(
            instructions="Do the task.",
            instruction_overlays=(
                InstructionOverlay(name="ownership", content="Stay in workflow."),
                InstructionOverlay(name="safety", content="Follow policy."),
            ),
        )

        assert result == (
            '<system_overlay name="ownership">\n'
            "Stay in workflow.\n"
            "</system_overlay>\n\n"
            '<system_overlay name="safety">\n'
            "Follow policy.\n"
            "</system_overlay>\n\n"
            "<agent_instructions>\n"
            "Do the task.\n"
            "</agent_instructions>"
        )
