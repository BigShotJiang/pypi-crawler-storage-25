"""Tests for provider parameter forwarding."""

from swarm.providers.litellm import LiteLLMProvider
from swarm.providers.openai import OpenAIProvider
from swarm.providers.types import CompletionRequest


def _request_with_parallel_tool_calls() -> CompletionRequest:
    return CompletionRequest(
        model=["openai/gpt-4o"],
        messages=[{"role": "user", "content": "Hi"}],
        tools=[
            {
                "type": "function",
                "function": {
                    "name": "display_budget",
                    "description": "Display budget",
                    "parameters": {"type": "object", "properties": {}},
                },
            }
        ],
        parallel_tool_calls=False,
    )


def test_openai_provider_forwards_parallel_tool_calls() -> None:
    provider = OpenAIProvider(sync_client=object(), async_client=object())

    params = provider._prepare_params(
        _request_with_parallel_tool_calls(),
        stream=True,
        model="openai/gpt-4o",
    )

    assert params["parallel_tool_calls"] is False


def test_litellm_provider_forwards_parallel_tool_calls() -> None:
    provider = LiteLLMProvider(config_getter=dict)

    params = provider._prepare_params(
        _request_with_parallel_tool_calls(),
        stream=True,
        model="anthropic/claude-3",
    )

    assert params["parallel_tool_calls"] is False
