#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import copy
import os

from AnyQt.QtCore import pyqtSignal, QObject

from aps.common.scripts.script_data import ScriptData
from aps.common.singleton import synchronized_method

from aps.beamline_driver.motion_management.facade import MotorsInfo

from aps.ai.beamline_controller.initialization.beamline_controller_configuration import BeamlineControllerConfiguration
from aps.ai.beamline_controller.execution.beamline_controller_initialization_manager import BeamlineControllerInitializationManager

class IConfigurationManager():
    def save_configuration(self, configuration: BeamlineControllerConfiguration): raise NotImplementedError
    def load_motors_info(self, configuration: BeamlineControllerConfiguration) -> MotorsInfo: raise NotImplementedError()
    def save_motors_info(self, new_motors_info: MotorsInfo, configuration: BeamlineControllerConfiguration): raise NotImplementedError()

class AbstractConfigurationManager(BeamlineControllerInitializationManager, IConfigurationManager):
    def __init__(self, application_name: str, working_directory: str, optical_system_id: str, **kwargs):
        super(AbstractConfigurationManager, self).__init__(application_name, working_directory, optical_system_id, **kwargs)

    # ----------------------------------------------------------------------------
    #
    # CONFIGURATION
    #
    # ----------------------------------------------------------------------------

    def save_configuration(self, configuration: BeamlineControllerConfiguration):
        configuration.to_ini()

    def load_motors_info(self, configuration: BeamlineControllerConfiguration) -> MotorsInfo:
        motion_manager_json_file = configuration.driver_configuration.motion_manager_configuration.get("json_file",
                                                                                                       MotorsInfo.default_json_file_name(self._optical_system_id))

        return copy.deepcopy(MotorsInfo.from_json(motion_manager_json_file))

    def save_motors_info(self, new_motors_info: MotorsInfo, configuration: BeamlineControllerConfiguration):
        motion_manager_json_file = configuration.driver_configuration.motion_manager_configuration.get("json_file",
                                                                                                       MotorsInfo.default_json_file_name(self._optical_system_id))

        current_motors_info = MotorsInfo.from_json(motion_manager_json_file)
        for motor_id in current_motors_info.get_motor_ids():
            current_motors_info.add_motor_info(motor_id, copy.deepcopy(new_motors_info.get_motor_info(motor_id)))

        current_motors_info.to_json(motion_manager_json_file)

 # ----------------------------------------------------------------------------
 # ----------------------------------------------------------------------------
 # ----------------------------------------------------------------------------
 # ----------------------------------------------------------------------------

# EXECUTION AS SCRIPT OR BLUESKY PLAN
class ConfigurationManager(AbstractConfigurationManager):
    def __init__(self, application_name: str, working_directory: str, optical_system_id: str, **kwargs):
        super(ConfigurationManager, self).__init__(application_name, working_directory, optical_system_id, **kwargs)

# QT APPLICATION: BATCH OR GUI
class QtConfigurationManager(AbstractConfigurationManager, QObject):
    configuration_saved = pyqtSignal()
    motors_info_saved   = pyqtSignal()

    def __init__(self, application_name: str, working_directory: str, optical_system_id: str, **kwargs):
        QObject.__init__(self)
        AbstractConfigurationManager.__init__(self, application_name, working_directory, optical_system_id, **kwargs)

    @synchronized_method
    def save_motors_info(self, new_motors_info: MotorsInfo, configuration: BeamlineControllerConfiguration):
        super(QtConfigurationManager, self).save_motors_info(new_motors_info, configuration)
        self.motors_info_saved.emit()

    @synchronized_method
    def save_configuration(self, configuration: BeamlineControllerConfiguration):
        super(QtConfigurationManager, self).save_configuration(configuration)
        self.configuration_saved.emit()

