#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #

import sys

from aps.ai.beamline_controller.initialization.beamline_controller_configuration import BeamlineControllerConfiguration, AutoAlignmentPlan, AutoAlignmentStage
from aps.common.plot import gui
from aps.common.plot.gui import MessageDialog
from aps.common.widgets.generic_widget import GenericWidget
from aps.common.widgets.congruence import *
from aps.common.scripts.script_data import ScriptData
from aps.common.utilities import string_to_list, string_to_dict, string_to_bool, string_to_number

from AnyQt.QtWidgets import QVBoxLayout, QTableWidget, QTableWidgetItem
from AnyQt.QtCore import QRect, Qt
from AnyQt.QtGui import QFont, QPalette, QColor, QGuiApplication

from aps.ai.beamline_controller.common.legacy_keys import Keys
from aps.ai.beamline_controller.agent.optimization.facade import WarmStartStrategy, WarmStartDataType
from aps.ai.beamline_controller.agent.optimization.decorators.direct_beam_image_decorator import DirectBeamImageOptimizationCriteria
from aps.ai.beamline_controller.agent.optimization.decorators.wavefront_analysis_decorator import WavefrontAnalysisOptimizationCriteria
from aps.ai.beamline_controller.agent.optimization.decorators.speckle_analysis_decorator import SpeckleAnalysisOptimizationCriteria

from aps.beamline_driver.motion_management.facade import MotorsInfo, MotorInfo, Units, MotorType
from aps.beamline_driver.beam_management.abstract_beam_manager import DirectBeamImageProperties, WavefrontAnalysisProperties, SpeckleAnalysisProperties

IS_DEBUG = os.getenv('BC_DEBUG', "0") == "1"

class ConfigurationEditorWidget(GenericWidget):
    def __init__(self, parent, application_name=None, **kwargs):
        self._working_directory       = kwargs["working_directory"]
        self._optical_system_id       = kwargs["optical_system_id"]
        self._available_beam_managers = kwargs["available_beam_managers"]
        self._configuration           = kwargs["configuration"]
        self._gui_parameters          = kwargs["gui_parameters"]

        # METHODS
        self._close                                         = kwargs["close_method"]
        self._load_motors_info                              = kwargs["load_motors_info_method"]
        self._save_configuration                            = kwargs["save_configuration_method"]
        self._set_current_motor_positions_as_initial_points = kwargs.get("set_current_motor_positions_as_initial_points", None)

        self._has_set_initial_points = not self._set_current_motor_positions_as_initial_points is None

        self.__is_init = True

        # motor form
        self.motor_type = 0
        self.units             = 0
        self.resolution        = 0.0
        self.repeatability     = 0.0
        self.boundary_from     = 0.0
        self.boundary_to       = 0.0
        self.shift_from_ideal  = 0.0
        self.legacy_id_get     = "<>"
        self.legacy_id_set     = "<>"

        self.search_range_from          = 0.0
        self.search_range_to            = 0.0
        self.search_transfer_range_from = 0.0
        self.search_transfer_range_to   = 0.0
        self.initial_position           = 0.0
        self.optimized                  = 1

        #stage form

        self.stage_beam_manager_type = 0
        self.stage_beam_manager_id = 0
        self.stage_ai_type = 0
        self.stage_optimizer_type = 0
        self.stage_optimizer_name_mobo = 0
        self.stage_optimizer_name_sonl = 0
        self.stage_optimizer_name_sobo = 0
        self.stage_acquisition_function_mobo = 0
        self.stage_surrogate_mobo = 0
        self.stage_surrogate_action_mobo = 0
        self.stage_acquisition_function_sobo = 0
        self.stage_optimization_type = 0
        self.stage_sobol_iterations_mobo = 0
        self.stage_sobol_iterations_sobo = 0
        self.stage_mobo_iterations = 0
        self.stage_max_iterations = 0
        self.stage_sobo_iterations = 0
        self.stage_pareto_selection = 0
        self.stage_use_hypervolume_exit = 0
        self.stage_hypervolume_exit_convergence_threshold = 0.0
        self.stage_hypervolume_exit_patience = 0.0
        self.stage_erase_warm_start_data = 0
        self.stage_save_warm_start_data = 0
        self.stage_warm_start_strategy = 0
        self.stage_warm_start_search_space_expansion_factor = 0
        self.stage_warm_start_loss_expansion_factor = 0
        self.stage_move_motors_on_best_trial = False
        self.stage_requires_pause_at_end = False
        self.stage_optimization_summary = ""

        self._set_values_from_initialization_parameters()

        super(ConfigurationEditorWidget, self).__init__(parent=parent, application_name=application_name, **kwargs)

    def _set_values_from_initialization_parameters(self):
        # protected/private elements are for storing information and won't be used as fields
        # public elements are fields

        self.working_directory = self._working_directory
        self.optical_system_id = self._optical_system_id

        configuration: BeamlineControllerConfiguration = self._configuration

        self.real_time_data      = configuration.gui_configuration.configuration_configuration.get("real_time_data", 0)
        self.capture_stdout      = configuration.gui_configuration.configuration_configuration.get("capture_stdout", 0)
        self.save_beams          = configuration.gui_configuration.configuration_configuration.get("save_beams", 1)

        self._ai_types             = configuration.ai_configuration.ai_types
        self._ai_types_combo_items = configuration.ai_configuration.ai_types_combo

        # -------------------------------- Optimization

        self._optimizer_types_combo_items    = configuration.ai_configuration.optimization_configuration["optimizer_types_combo"]
        self._optimizer_types                = configuration.ai_configuration.optimization_configuration["optimizer_types"]
        self._optimization_types_combo_items = configuration.ai_configuration.optimization_configuration["optimization_types_combo"]
        self._optimization_types             = configuration.ai_configuration.optimization_configuration["optimization_types"]

        self._optimizer_type_configuration     = configuration.ai_configuration.optimization_configuration
        self._optimization_type_configuration  = {optimization_type : configuration.ai_configuration.optimization_configuration[optimization_type] for optimization_type in self._optimization_types}
        self._neural_network_configuration     = configuration.ai_configuration.neural_network_configuration

        self._optimizer_names_combo_items = {optimizer_type: configuration.ai_configuration.optimization_configuration[optimizer_type]["names_combo"] for optimizer_type in self._optimizer_types}
        self._optimizer_names             = {optimizer_type: configuration.ai_configuration.optimization_configuration[optimizer_type]["names"] for optimizer_type in self._optimizer_types}

        self._optimizer_configuration_mobo = configuration.ai_configuration.optimization_configuration[Keys.OptimizerType.MOBO]
        self._optimizer_configuration_sonl = configuration.ai_configuration.optimization_configuration[Keys.OptimizerType.SONL]
        self._optimizer_configuration_sobo = configuration.ai_configuration.optimization_configuration[Keys.OptimizerType.SOBO]

        self._acquisition_function_mobo_combo_items = {name :  self._optimizer_configuration_mobo[name].get("acquisition_functions") for name in self._optimizer_names[Keys.OptimizerType.MOBO]}
        self._acquisition_function_sobo_combo_items = {name :  self._optimizer_configuration_sobo[name].get("acquisition_functions") for name in self._optimizer_names[Keys.OptimizerType.SOBO]}

        self._surrogates_mobo_combo_items         = {name : self._optimizer_configuration_mobo[name].get("surrogates", []) for name in self._optimizer_names[Keys.OptimizerType.MOBO]}
        self._surrogates_actions_mobo_combo_items = {name : self._optimizer_configuration_mobo[name].get("surrogate_actions", []) for name in self._optimizer_names[Keys.OptimizerType.MOBO]}

        # Optimization Type --------------------------

        self._full_start_configuration           = self._optimization_type_configuration[Keys.OptimizationType.FULL_START]
        self._warm_start_same_configuration      = self._optimization_type_configuration[Keys.OptimizationType.WARM_START_SAME]
        self._warm_start_different_configuration = self._optimization_type_configuration[Keys.OptimizationType.WARM_START_DIFFERENT]

        self._warm_start_home_directory_types_combo_items = self._warm_start_same_configuration.get("warm_start_home_directory_types_combo")
        self._warm_start_data_types_combo_items           = self._warm_start_same_configuration.get("warm_start_data_types_combo")
        self._warm_start_strategies_combo_items           = self._warm_start_same_configuration.get("warm_start_strategies_combo")
        self._warm_start_strategies                       = self._warm_start_same_configuration.get("warm_start_strategies")

        # -------------------------------- NN

        self._neural_network_types_combo_items      = self._neural_network_configuration.get("neural_network_types_combo")
        self._neural_network_model_from_combo_items = self._neural_network_configuration.get("neural_network_model_from_combo")
        self._neural_network_data_types_combo_items = self._neural_network_configuration.get("neural_network_data_types_combo")

        # -------------------------------- Driver

        self._platform_combo_items = configuration.driver_configuration.platforms_combo
        self._platforms            = configuration.driver_configuration.platforms

        self._beam_manager_type_combo_items = configuration.driver_configuration.beam_manager_types_combo
        self._beam_manager_types            = configuration.driver_configuration.beam_manager_types
        self._beam_manager_configuration    = configuration.driver_configuration.beam_manager_configuration
        self._motion_manager_configuration  = configuration.driver_configuration.motion_manager_configuration

        self._motors_info: MotorsInfo       = self._load_motors_info(configuration)

        # -------------------------------- Plans

        self._plans_platforms            = configuration.plans_configuration.get_available_platforms()
        self._plans_platform_combo_items = [self._platform_combo_items[self._platforms.index(platform)] for platform in self._plans_platforms]

        self._reload_gui_parameters()
        self._reload_configuration()

    def _reload_gui_parameters(self):
        gui_parameters: ScriptData = self._gui_parameters

        self.optimizer_type    = gui_parameters.get_parameter("optimizer_type", 0)
        self.optimization_type = gui_parameters.get_parameter("optimization_type", 0)

        selected_optimizer_names = gui_parameters.get_parameter("optimizer_names")
        self.optimizer_name_mobo = selected_optimizer_names[Keys.OptimizerType.MOBO]
        self.optimizer_name_sonl = selected_optimizer_names[Keys.OptimizerType.SONL]
        self.optimizer_name_sobo = selected_optimizer_names[Keys.OptimizerType.SOBO]

        self.neural_network_type = gui_parameters.get_parameter("neural_network_type")

        selected_neural_network_model_from = gui_parameters.get_parameter("neural_network_models_from")
        self.neural_network_model_from     = selected_neural_network_model_from[Keys.NeuralNetworkModelType.TANDEM]

        self.platform          = gui_parameters.get_parameter("platform", 1)
        self.beam_manager_type = gui_parameters.get_parameter("beam_manager_type", 0)
        self._beam_manager_ids = gui_parameters.get_parameter("beam_manager_ids", {})
        self.beam_manager_id   = self._beam_manager_ids[self._beam_manager_types[self.beam_manager_type]]

        # set the previous values with the current for error management
        gui_parameters.set_parameter("previous_platform", self.platform)
        gui_parameters.set_parameter("previous_beam_manager_type", self.beam_manager_type)
        self._previous_beam_manager_ids = gui_parameters.get_parameter("previous_beam_manager_ids")
        for beam_manager_type in self._previous_beam_manager_ids.keys(): self._previous_beam_manager_ids[beam_manager_type] = self._beam_manager_ids[beam_manager_type]

        self.motor             = gui_parameters.get_parameter("motor", 0)

        self.plans_platform = gui_parameters.get_parameter("plans_platform", 0)
        self._plan_ids      = gui_parameters.get_parameter("plan_ids")
        self.plan_id        = self._plan_ids[self._plans_platforms[self.plans_platform]]
        self.stage_id       = 0

    def _reload_configuration(self):
        # -------------------------------- Optimization
        optimizer_name_key_mobo = self._optimizer_names[Keys.OptimizerType.MOBO][int(self.optimizer_name_mobo)]
        optimizer_name_key_sonl = self._optimizer_names[Keys.OptimizerType.SONL][int(self.optimizer_name_sonl)]
        optimizer_name_key_sobo = self._optimizer_names[Keys.OptimizerType.SOBO][int(self.optimizer_name_sobo)]

        self.acquisition_function_mobo = self._optimizer_configuration_mobo[optimizer_name_key_mobo]["defaults"].get("acquisition_function", 0)
        self.surrogate_mobo            = self._optimizer_configuration_mobo[optimizer_name_key_mobo]["defaults"].get("surrogate", 0)
        self.surrogate_action_mobo     = self._optimizer_configuration_mobo[optimizer_name_key_mobo]["defaults"].get("surrogate_action", 0)

        self.sobol_iterations_mobo     = self._optimizer_configuration_mobo[optimizer_name_key_mobo]["defaults"].get("sobol_iterations", 20)
        self.mobo_iterations           = self._optimizer_configuration_mobo[optimizer_name_key_mobo]["defaults"].get("mobo_iterations", 100)
        self.pareto_selection          = self._optimizer_configuration_mobo[optimizer_name_key_mobo]["defaults"].get("pareto_selection", 0)

        self.hypervolume_exit_convergence_threshold = self._optimizer_configuration_mobo[optimizer_name_key_mobo]["defaults"]["hypervolume_exit"].get("convergence_threshold", 0.1)
        self.hypervolume_exit_patience              = self._optimizer_configuration_mobo[optimizer_name_key_mobo]["defaults"]["hypervolume_exit"].get("patience", 10)

        self.max_iterations    = self._optimizer_configuration_sonl[optimizer_name_key_sonl]["defaults"].get("max_iterations", 50)
        self.x_absolute_change = self._optimizer_configuration_sonl[optimizer_name_key_sonl]["defaults"].get("x_absolute_change", 1e-8)
        self.f_absolute_change = self._optimizer_configuration_sonl[optimizer_name_key_sonl]["defaults"].get("f_absolute_change", 1e-8)

        self.acquisition_function_sobo = self._optimizer_configuration_sobo[optimizer_name_key_sobo]["defaults"].get("acquisition_function", 0)
        self.sobol_iterations_sobo     = self._optimizer_configuration_sobo[optimizer_name_key_sobo]["defaults"].get("sobol_iterations", 20)
        self.sobo_iterations           = self._optimizer_configuration_sobo[optimizer_name_key_sobo]["defaults"].get("sobo_iterations", 100)

        # Transfer Learning --------------------------

        self.full_start_erase_warm_start_data = int(self._full_start_configuration["defaults"].get("erase_warm_start_data", False))
        self.full_start_save_warm_start_data  = int(self._full_start_configuration["defaults"].get("save_warm_start_data", True))

        self.warm_start_home_directory_type = self._warm_start_same_configuration["defaults"].get("warm_start_home_directory_type", 0)
        self.warm_start_home_directory      = self._warm_start_same_configuration["defaults"].get("warm_start_home_directory", os.path.abspath(os.curdir))
        self.warm_start_data_type           = self._warm_start_same_configuration["defaults"].get("warm_start_data_type", WarmStartDataType.PARETO_FRONTIERS)
        self.warm_start_strategy            = self._warm_start_same_configuration["defaults"].get("warm_start_strategy", WarmStartStrategy.MAXIMUM_EXTENSION)

        self._warm_start_expansion_factors  = self._warm_start_same_configuration["defaults"].get("warm_start_expansion_factors", {Keys.WarmStartStrategies.FROM_MAXIMUM_LOSS : [0.0, 0.01],
                                                                                                                                   Keys.WarmStartStrategies.FROM_MINIMUM_LOSS : [0.1, 1.5]})
        warm_start_expansion_factors = self._warm_start_expansion_factors[self._warm_start_strategies[self.warm_start_strategy]]

        self.warm_start_search_space_expansion_factor = warm_start_expansion_factors[0]
        self.warm_start_loss_expansion_factor         = warm_start_expansion_factors[1]

        self.use_warm_start_search_space                 = int(self._warm_start_same_configuration["defaults"].get("use_warm_start_search_space", True))
        self.use_warm_start_hypervolume_reference_points = int(self._warm_start_same_configuration["defaults"].get("use_warm_start_hypervolume_reference_points", True))

        # -------------------------------- NN

        # For now is only Tandem.
        self.neural_network_trained_model_file = self._neural_network_configuration[Keys.NeuralNetworkModelType.TANDEM]["defaults"].get("neural_network_trained_model_file", "")
        self.neural_network_home_directory     = self._neural_network_configuration[Keys.NeuralNetworkModelType.TANDEM]["defaults"].get("neural_network_home_directory", os.path.abspath(os.curdir))
        self.neural_network_data_type          = self._neural_network_configuration[Keys.NeuralNetworkModelType.TANDEM]["defaults"].get("neural_network_data_type", 2)

        neural_network_parameters = self._neural_network_configuration[Keys.NeuralNetworkModelType.TANDEM]["defaults"].get("neural_network_parameters", {})

        self.learning_rate    = neural_network_parameters.get("learning_rate", 1e-6)
        self.weight_decay     = neural_network_parameters.get("weight_decay", 1e-5)
        self.total_epochs     = neural_network_parameters.get("total_epochs", 5000)
        self.patience         = neural_network_parameters.get("patience", 50)
        self.train_batch_size = neural_network_parameters.get("train_batch_size", 2048)

        # -------------------------------- Driver Motion Manager

        self._motor_ids = self._motors_info.get_motor_ids()

        # -------------------------------- Driver Beam Manager

        ################################################################################
        # Runtime management -> user interacion
        ################################################################################
        if not self.__is_init:
            if self.optimizer_type == 0:
                if self.optimizer_name_mobo in [0, 1]:
                    self.cb_acquisition_function_mobo_1.setCurrentIndex(self.acquisition_function_mobo)
                    self.le_sobol_iterations_mobo_1.setText(str(self.sobol_iterations_mobo))
                    self.le_mobo_iterations_1.setText(str(self.mobo_iterations))
                    self.cb_pareto_selection_1.setCurrentIndex(self.pareto_selection)
                else:
                    self.cb_acquisition_function_mobo_2.setCurrentIndex(self.acquisition_function_mobo)
                    self.le_sobol_iterations_mobo_2.setText(str(self.sobol_iterations_mobo))
                    self.le_mobo_iterations_2.setText(str(self.mobo_iterations))
            elif self.optimizer_type == 1:
                self.le_max_iterations.setText(str(self.max_iterations))
                self.le_x_absolute_change.setText(str(self.x_absolute_change))
                self.le_f_absolute_change.setText(str(self.f_absolute_change))
            elif self.optimizer_type == 2:
                self.cb_acquisition_function_sobo.setCurrentIndex(self.acquisition_function_sobo)
                self.le_sobol_iterations_sobo.setText(str(self.sobol_iterations_sobo))
                self.le_sobo_iterations.setText(str(self.sobo_iterations))

            if self.optimization_type == 0:
                self.cb_erase_warm_start_data.setCurrentIndex(self.full_start_erase_warm_start_data)
                self.cb_save_warm_start_data.setCurrentIndex(self.full_start_save_warm_start_data)
            elif self.optimization_type == 1:
                self.cb_warm_start_home_directory_type.setCurrentIndex(self.warm_start_home_directory_type)
                self.le_warm_start_home_directory.setText(self.warm_start_home_directory)
                self.cb_warm_start_data_type.setCurrentIndex(self.warm_start_data_type)
                self.cb_use_warm_start_search_space.setCurrentIndex(self.use_warm_start_search_space)
                self.cb_use_warm_start_hypervolume_reference_points.setCurrentIndex(self.use_warm_start_hypervolume_reference_points)
                self.cb_warm_start_strategy.setCurrentIndex(self.warm_start_strategy)

                self.le_warm_start_search_space_expansion_factor.setText(str(self.warm_start_search_space_expansion_factor))
                self.le_warm_start_loss_expansion_factor.setText(str(self.warm_start_loss_expansion_factor))

    def _check_fields(self):
        if not check_positive(self.sobol_iterations_mobo, strictly=False): raise ValueError("Sobol iterations should be a number \u2265 0")
        if not check_positive(self.mobo_iterations, strictly=False): raise ValueError("MOBO iterations should be a number \u2265 0")
        if not check_positive(self.max_iterations, strictly=True): raise ValueError("Max iterations should be a number > 0")
        if not check_positive(self.x_absolute_change, strictly=True): raise ValueError("X Absolute Change should be a number > 0")
        if not check_positive(self.f_absolute_change, strictly=True): raise ValueError("F Absolute Change should be a number > 0")
        if not check_positive(self.sobol_iterations_sobo, strictly=False): raise ValueError("Sobol iterations should be a number \u2265 0")
        if not check_positive(self.sobo_iterations, strictly=False): raise ValueError("SOBO iterations should be a number \u2265 0")

        #TODO:
        # CHECK IF NEEDED ERRORS FROM OTHER/NEW NUMERICAL FIELDS

    def _collect_configuration_parameters(self):
        configuration: BeamlineControllerConfiguration = self._configuration
        gui_parameters: ScriptData                     = self._gui_parameters

        self._check_fields()

        # GUI PARAMETERS -----------------

        gui_parameters.set_parameter("optimizer_type", self.optimizer_type)
        gui_parameters.set_parameter("optimization_type", self.optimization_type)

        selected_optimizer_names = gui_parameters.get_parameter("optimizer_names")
        selected_optimizer_names[Keys.OptimizerType.MOBO] = self.optimizer_name_mobo
        selected_optimizer_names[Keys.OptimizerType.SONL] = self.optimizer_name_sonl
        selected_optimizer_names[Keys.OptimizerType.SOBO] = self.optimizer_name_sobo

        gui_parameters.set_parameter("neural_network_type", self.neural_network_type)

        selected_neural_network_model_from = gui_parameters.get_parameter("neural_network_models_from")
        selected_neural_network_model_from[Keys.NeuralNetworkModelType.TANDEM] = self.neural_network_model_from

        gui_parameters.set_parameter("platform", self.platform)
        gui_parameters.set_parameter("beam_manager_type", self.beam_manager_type)
        gui_parameters.set_parameter("beam_manager_ids", self._beam_manager_ids)
        gui_parameters.set_parameter("motor", self.motor)

        gui_parameters.set_parameter("plans_platform", self.plans_platform)
        gui_parameters.set_parameter("plan_ids", self._plan_ids)

        # CONFIGURATION

        configuration.gui_configuration.configuration_configuration["real_time_data"] = self.real_time_data
        configuration.gui_configuration.configuration_configuration["capture_stdout"] = self.capture_stdout
        configuration.gui_configuration.configuration_configuration["save_beams"]     = self.save_beams

        optimizer_name_key_mobo = self._optimizer_names[Keys.OptimizerType.MOBO][int(self.optimizer_name_mobo)]
        optimizer_name_key_sonl = self._optimizer_names[Keys.OptimizerType.SONL][int(self.optimizer_name_sonl)]
        optimizer_name_key_sobo = self._optimizer_names[Keys.OptimizerType.SOBO][int(self.optimizer_name_sobo)]

        self._optimizer_configuration_mobo[optimizer_name_key_mobo]["defaults"]["acquisition_function"]                      = self.acquisition_function_mobo
        self._optimizer_configuration_mobo[optimizer_name_key_mobo]["defaults"]["surrogate"]                                 = self.surrogate_mobo
        self._optimizer_configuration_mobo[optimizer_name_key_mobo]["defaults"]["surrogate_action"]                          = self.surrogate_action_mobo
        self._optimizer_configuration_mobo[optimizer_name_key_mobo]["defaults"]["sobol_iterations"]                          = self.sobol_iterations_mobo
        self._optimizer_configuration_mobo[optimizer_name_key_mobo]["defaults"]["mobo_iterations"]                           = self.mobo_iterations
        self._optimizer_configuration_mobo[optimizer_name_key_mobo]["defaults"]["pareto_selection"]                          = self.pareto_selection
        self._optimizer_configuration_mobo[optimizer_name_key_mobo]["defaults"]["hypervolume_exit"]["convergence_threshold"] = self.hypervolume_exit_convergence_threshold
        self._optimizer_configuration_mobo[optimizer_name_key_mobo]["defaults"]["hypervolume_exit"]["patience"]              = self.hypervolume_exit_patience

        self._optimizer_configuration_sonl[optimizer_name_key_sonl]["defaults"]["max_iterations"]    = self.max_iterations
        self._optimizer_configuration_sonl[optimizer_name_key_sonl]["defaults"]["x_absolute_change"] = self.x_absolute_change
        self._optimizer_configuration_sonl[optimizer_name_key_sonl]["defaults"]["f_absolute_change"] = self.f_absolute_change

        self._optimizer_configuration_sobo[optimizer_name_key_sobo]["defaults"]["acquisition_function"] = self.acquisition_function_sobo
        self._optimizer_configuration_sobo[optimizer_name_key_sobo]["defaults"]["sobol_iterations"]     = self.sobol_iterations_sobo
        self._optimizer_configuration_sobo[optimizer_name_key_sobo]["defaults"]["sobo_iterations"]      = self.sobo_iterations

        self._full_start_configuration["defaults"]["erase_warm_start_data"] = self.full_start_erase_warm_start_data == 1
        self._full_start_configuration["defaults"]["save_warm_start_data"]  = self.full_start_save_warm_start_data == 1

        self._warm_start_same_configuration["defaults"]["warm_start_home_directory_type"] = self.warm_start_home_directory_type
        self._warm_start_same_configuration["defaults"]["warm_start_home_directory"]      = self.warm_start_home_directory
        self._warm_start_same_configuration["defaults"]["warm_start_data_type"]           = self.warm_start_data_type
        self._warm_start_same_configuration["defaults"]["warm_start_strategy"]            = self.warm_start_strategy

        warm_start_expansion_factors = self._warm_start_expansion_factors[self._warm_start_strategies[self.warm_start_strategy]]

        warm_start_expansion_factors[0] = self.warm_start_search_space_expansion_factor
        warm_start_expansion_factors[1] = self.warm_start_loss_expansion_factor

        self._warm_start_same_configuration["defaults"]["use_warm_start_search_space"]                 = self.use_warm_start_search_space == 1
        self._warm_start_same_configuration["defaults"]["use_warm_start_hypervolume_reference_points"] = self.use_warm_start_hypervolume_reference_points == 1

        self._neural_network_configuration[Keys.NeuralNetworkModelType.TANDEM]["defaults"]["neural_network_trained_model_file"] = self.neural_network_trained_model_file
        self._neural_network_configuration[Keys.NeuralNetworkModelType.TANDEM]["defaults"]["neural_network_home_directory"]     = self.neural_network_home_directory
        self._neural_network_configuration[Keys.NeuralNetworkModelType.TANDEM]["defaults"]["neural_network_data_type"]          = self.neural_network_data_type

        neural_network_parameters = {}
        neural_network_parameters["learning_rate"]    = self.learning_rate
        neural_network_parameters["weight_decay"]     = self.weight_decay
        neural_network_parameters["total_epochs"]     = self.total_epochs
        neural_network_parameters["patience"]         = self.patience
        neural_network_parameters["train_batch_size"] = self.train_batch_size

        self._neural_network_configuration[Keys.NeuralNetworkModelType.TANDEM]["defaults"]["neural_network_parameters"] = neural_network_parameters

        self._set_current_motor()
        self._set_current_motor_optimization()
        self._set_current_objectives()
        self._set_current_properties()
        self._set_current_plan()

    def _reload_values(self):
        self._reload_configuration()

    def _save_values(self):
        self._collect_configuration_parameters()

    def _get_beam_manager_keys(self):
        platform_key = self._platforms[int(self.platform)]
        beam_manager_type_key = self._beam_manager_types[int(self.beam_manager_type)]

        beam_manager_type_configuration = self._beam_manager_configuration[beam_manager_type_key]
        beam_manager_ids = beam_manager_type_configuration["beam_manager_ids"]

        if self.beam_manager_id < len(beam_manager_ids):
            beam_manager_id_key = beam_manager_ids[int(self.beam_manager_id)]
        else:
            self.beam_manager_id = 0
            beam_manager_id_key = beam_manager_ids[0]

        return platform_key, beam_manager_type_key, beam_manager_id_key

    def _get_beam_manager_keys_and_dictionary(self):
        platform_key, beam_manager_type_key, beam_manager_id_key = self._get_beam_manager_keys()

        try:
            dictionary = self._beam_manager_configuration[beam_manager_type_key]["defaults"][platform_key][beam_manager_id_key]

            return platform_key, beam_manager_type_key, beam_manager_id_key, dictionary
        except KeyError:
            raise ValueError("The selected combination of Platform, Beam Properties and Detection System is not available")

    def _get_beam_manager_item(self, item_key):
        platform_key, beam_manager_type_key, beam_manager_id_key, dictionary = self._get_beam_manager_keys_and_dictionary()

        return dictionary.get(item_key, {})

    def _set_beam_manager_item(self, item_key, value):
        _, _, _, dictionary = self._get_beam_manager_keys_and_dictionary()
        dictionary[item_key] = value


    def _get_objectives(self):
        return self._get_beam_manager_item("objectives")

    def _get_properties(self):
        return self._get_beam_manager_item("properties")

    def _get_arguments(self):
        platform_key, beam_manager_type_key, beam_manager_id_key = self._get_beam_manager_keys()

        try:             arguments = self._beam_manager_configuration[beam_manager_type_key]["arguments"][platform_key][beam_manager_id_key]
        except KeyError: raise ValueError("The selected combination of Platform, Beam Properties and Detection System is not available")

        return arguments

    def _set_current_objectives(self):
        self._set_beam_manager_item("objectives", self._get_objectives_from_table())

    def _set_current_properties(self):
        self._set_beam_manager_item("properties", self._get_properties_from_table())

    def _set_current_arguments(self):
        platform_key, beam_manager_type_key, beam_manager_id_key = self._get_beam_manager_keys()
        arguments = self._get_arguments_from_table()
        for argument_key in arguments.keys():
            self._beam_manager_configuration[beam_manager_type_key]["arguments"][platform_key][beam_manager_id_key][argument_key] = arguments[argument_key]

    def get_acquisition_functions_mobo_combo_items(self):
        optimizer_name_key_mobo = self._optimizer_names[Keys.OptimizerType.MOBO][int(self.optimizer_name_mobo)]

        return self._acquisition_function_mobo_combo_items[optimizer_name_key_mobo]

    def get_acquisition_functions_sobo_combo_items(self):
        optimizer_name_key_sobo = self._optimizer_names[Keys.OptimizerType.SOBO][int(self.optimizer_name_sobo)]

        return self._acquisition_function_sobo_combo_items[optimizer_name_key_sobo]

    def get_surrogate_mobo_combo_items(self):
        optimizer_name_key_mobo = self._optimizer_names[Keys.OptimizerType.MOBO][int(self.optimizer_name_mobo)]

        return self._surrogates_mobo_combo_items[optimizer_name_key_mobo]

    def get_surrogate_action_mobo_combo_items(self):
        optimizer_name_key_mobo = self._optimizer_names[Keys.OptimizerType.MOBO][int(self.optimizer_name_mobo)]

        return self._surrogates_actions_mobo_combo_items[optimizer_name_key_mobo]

    def get_plot_tab_name(self): return self._optical_system_id + " Optics Controller: Configuration Editor"

    def build_widget(self, **kwargs):
        geom = QGuiApplication.primaryScreen().availableGeometry()

        try:    widget_width = kwargs["widget_width"]
        except: widget_width = min(1000, geom.width()*0.98)
        try:    widget_height = kwargs["widget_height"]
        except:
            if sys.platform == 'darwin' : widget_height = min(750, geom.height()*0.95)
            else:                         widget_height = min(850, geom.height()*0.95)
        self.setGeometry(QRect(10, 10, int(widget_width), int(widget_height)))
        self.setFixedWidth(int(widget_width))
        self.setFixedHeight(int(widget_height))

        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignLeft)
        self.setLayout(layout)

        upper_box = gui.widgetBox(self, "", width=self.width() - 20, height=50, orientation="horizontal")
        lower_box = gui.widgetBox(self, "", width=self.width() - 20, height=self.height() - 70)

        button_box = gui.widgetBox(upper_box, "", width= 450, orientation='horizontal')
        button_box.layout().setAlignment(Qt.AlignCenter)

        self._save_configuration_button = gui.button(button_box, None, "Save Configuration", callback=self._save_configuration_callback, width=int(0.5 * button_box.width() - 3), height=35)
        exit_button = gui.button(button_box, None, "Exit", callback=self._close_callback, width=int(0.5 * button_box.width() - 3), height=35)

        font = QFont(exit_button.font())
        font.setBold(False)
        font.setItalic(True)
        exit_button.setFont(font)
        palette = QPalette(exit_button.palette())
        palette.setColor(QPalette.ButtonText, QColor('Dark Blue'))
        exit_button.setPalette(palette)

        self._bl_box   = gui.widgetBox(upper_box, "", width=upper_box.width() - button_box.width() - 5)
        self.le_optical_system_id = gui.lineEdit(self._bl_box, self, "optical_system_id",
                                                 label="                                                 Optical System",
                                                 labelWidth=self._bl_box.width() - 30, controlWidth=250, orientation='horizontal', valueType=str)
        self.le_optical_system_id.setReadOnly(True)
        font = QFont(self.le_optical_system_id.font())
        font.setBold(True)
        font.setItalic(False)
        font.setPixelSize(25)
        self.le_optical_system_id.setFont(font)
        self.le_optical_system_id.setAlignment(Qt.AlignRight)
        self.le_optical_system_id.setStyleSheet("QLineEdit {color : darkgreen; background : rgb(243, 240, 160); text-align : right}")

        self._main_box = gui.widgetBox(lower_box, "", width=self.width() - 20, height=self.height() - 70)

        tab_widget = gui.tabWidget(self._main_box)
        ai_settings_tab      = gui.createTabPage(tab_widget, "AI")
        driver_settings_tab  = gui.createTabPage(tab_widget, "Driver")
        plans_settings_tab   = gui.createTabPage(tab_widget, "Autoalignment Plans")
        general_settings_tab = gui.createTabPage(tab_widget, "GUI")

        labels_width = 450

        # ------------------------------------------------------------
        # AI SETTING
        ai_box_1 = gui.widgetBox(ai_settings_tab, "AI Settings", width=self._main_box.width() - 15, height=self._main_box.height() - 40, orientation='horizontal', addSpace=False)

        # -------------------------

        self._opt_box = gui.widgetBox(ai_box_1, "Optimization", width=0.5*(ai_box_1.width()) - 10, height=ai_box_1.height() - 40,  orientation='vertical', addSpace=False)
        self._nn_box  = gui.widgetBox(ai_box_1, "Neural Network", width=0.5*(ai_box_1.width()) - 10, height=ai_box_1.height() - 40, orientation='vertical', addSpace=False)

        # -------------------------------- Optimization

        self.cb_optimizer_type = gui.comboBox(self._opt_box, self, "optimizer_type", label="Optimizer Type", labelWidth=250,
                                              items=self._optimizer_types_combo_items, orientation="horizontal",
                                              callback=self._set_optimizer_type)

        gui.separator(self._opt_box)

        self._mobo_optimizers_box_1 = gui.widgetBox(self._opt_box, "", width=self._opt_box.width() - 20, height=23, orientation='vertical', addSpace=False)
        self._sonl_optimizers_box_1 = gui.widgetBox(self._opt_box, "", width=self._opt_box.width() - 20, height=23, orientation='vertical', addSpace=False)
        self._sobo_optimizers_box_1 = gui.widgetBox(self._opt_box, "", width=self._opt_box.width() - 20, height=23, orientation='vertical', addSpace=False)

        self.cb_mobo_optimizers = gui.comboBox(self._mobo_optimizers_box_1, self, "optimizer_name_mobo", label="Optimizer Name",
                                               items=self._optimizer_names_combo_items[Keys.OptimizerType.MOBO], orientation="horizontal",
                                               callback=self._set_optimizer_name)
        self.cb_sonl_optimizers = gui.comboBox(self._sonl_optimizers_box_1, self, "optimizer_name_sonl", label="Optimizer Name", items=self._optimizer_names_combo_items[Keys.OptimizerType.SONL], orientation="horizontal", callback=self._set_optimizer_name)
        self.cb_sobo_optimizers = gui.comboBox(self._sobo_optimizers_box_1, self, "optimizer_name_sobo", label="Optimizer Name", items=self._optimizer_names_combo_items[Keys.OptimizerType.SOBO], orientation="horizontal", callback=self._set_optimizer_name)

        # MOBO -----------------------------

        height_darwin = 190
        height_else   = 210

        if sys.platform == 'darwin':
            self._mobo_optimizers_box_2 = gui.widgetBox(self._opt_box, "", width=self._opt_box.width() - 20, height=height_darwin, orientation='vertical', addSpace=False)
        else:
            self._mobo_optimizers_box_2 = gui.widgetBox(self._opt_box, "", width=self._opt_box.width() - 20, height=height_else, orientation='vertical', addSpace=False)

        self.cb_acquisition_function_mobo_1 = gui.comboBox(self._mobo_optimizers_box_2, self, "acquisition_function_mobo", label="Acquisition Function", items=[], orientation="horizontal", callback=self._save_values)
        self.cb_surrogate_mobo_1            = gui.comboBox(self._mobo_optimizers_box_2, self, "surrogate_mobo", label="Surrogate Model", items=[], orientation="horizontal", callback=self._save_values)
        self.cb_surrogate_action_mobo_1     = gui.comboBox(self._mobo_optimizers_box_2, self, "surrogate_action_mobo", label="Surrogate Initialization", items=[], orientation="horizontal", callback=self._save_values)

        self.le_sobol_iterations_mobo_1     = gui.lineEdit(self._mobo_optimizers_box_2, self, "sobol_iterations_mobo", "Sobol iterations", labelWidth=labels_width, orientation='horizontal', controlWidth=50, valueType=int, callback=self._save_values)
        self.le_mobo_iterations_1           = gui.lineEdit(self._mobo_optimizers_box_2, self, "mobo_iterations", "MOBO iterations", labelWidth=labels_width, orientation='horizontal', controlWidth=50, valueType=int, callback=self._save_values)
        self.cb_pareto_selection_1          = gui.comboBox(self._mobo_optimizers_box_2, self, "pareto_selection", label="Pareto Best Trial", items=["Nash Equilibrium", "Most Intense", "Narrowest", "Closest to Center"], orientation="horizontal", callback=self._save_values)

        box = gui.widgetBox(self._mobo_optimizers_box_2, "", width=self._mobo_optimizers_box_2.width(), orientation='horizontal', addSpace=False)
        gui.lineEdit(box, self, "hypervolume_exit_convergence_threshold", "Hypervolume Exit:                      \u0394hv Threshold  ", orientation='horizontal', controlWidth=50, valueType=float, callback=self._save_values)
        gui.lineEdit(box, self, "hypervolume_exit_patience",         "Patience",  orientation='horizontal', controlWidth=50, valueType=int, callback=self._save_values)

        if sys.platform == 'darwin':
            self._mobo_optimizers_box_3 = gui.widgetBox(self._opt_box, "", width=self._opt_box.width() - 20, height=height_darwin, orientation='vertical', addSpace=False)
        else:
            self._mobo_optimizers_box_3 = gui.widgetBox(self._opt_box, "", width=self._opt_box.width() - 20, height=height_else, orientation='vertical', addSpace=False)

        self.cb_acquisition_function_mobo_2 = gui.comboBox(self._mobo_optimizers_box_3, self, "acquisition_function_mobo", label="Acquisition Function", items=[], orientation="horizontal", callback=self._save_values)
        self.le_sobol_iterations_mobo_2     = gui.lineEdit(self._mobo_optimizers_box_3, self, "sobol_iterations_mobo", "Random iterations", labelWidth=labels_width, orientation='horizontal', controlWidth=50, valueType=int, callback=self._save_values)
        self.le_mobo_iterations_2           = gui.lineEdit(self._mobo_optimizers_box_3, self, "mobo_iterations", "MOBO iterations", labelWidth=labels_width, orientation='horizontal', controlWidth=50, valueType=int, callback=self._save_values)

        # SONL -----------------------------

        if sys.platform == 'darwin':
            self._sonl_optimizers_box_2 = gui.widgetBox(self._opt_box, "", width=self._opt_box.width() - 20, height=height_darwin, orientation='vertical', addSpace=False)
        else:
            self._sonl_optimizers_box_2 = gui.widgetBox(self._opt_box, "", width=self._opt_box.width() - 20, height=height_else, orientation='vertical', addSpace=False)

        self.le_max_iterations    = gui.lineEdit(self._sonl_optimizers_box_2, self, "max_iterations", "Max iterations per Step", labelWidth=labels_width, orientation='horizontal', controlWidth=50, valueType=int, callback=self._save_values)
        self.le_x_absolute_change = gui.lineEdit(self._sonl_optimizers_box_2, self, "x_absolute_change", "X Absolute Change", labelWidth=labels_width, orientation='horizontal', controlWidth=50, valueType=float, callback=self._save_values)
        self.le_f_absolute_change = gui.lineEdit(self._sonl_optimizers_box_2, self, "f_absolute_change", "F Absolute Change", labelWidth=labels_width, orientation='horizontal', controlWidth=50, valueType=float, callback=self._save_values)

        # SOBO -----------------------------

        if sys.platform == 'darwin':
            self._sobo_optimizers_box_2 = gui.widgetBox(self._opt_box, "", width=self._opt_box.width() - 20, height=height_darwin, orientation='vertical', addSpace=False)
        else:
            self._sobo_optimizers_box_2 = gui.widgetBox(self._opt_box, "", width=self._opt_box.width() - 20, height=height_else, orientation='vertical', addSpace=False)

        self.cb_acquisition_function_sobo = gui.comboBox(self._sobo_optimizers_box_2, self, "acquisition_function_sobo", label="Acquisition Function", items=[], orientation="horizontal", callback=self._save_values)
        self.le_sobol_iterations_sobo     = gui.lineEdit(self._sobo_optimizers_box_2, self, "sobol_iterations_sobo", "Sobol iterations", labelWidth=labels_width, orientation='horizontal', controlWidth=50, valueType=int, callback=self._save_values)
        self.le_sobo_iterations           = gui.lineEdit(self._sobo_optimizers_box_2, self, "sobo_iterations", "SOBO iterations", labelWidth=labels_width, orientation='horizontal', controlWidth=50, valueType=int, callback=self._save_values)

        # ---------------------------------------------------
        # Transfer learning

        gui.separator(self._opt_box)

        tab_widget         = gui.tabWidget(self._opt_box)
        self._transfer_tab = gui.createTabPage(tab_widget, "Transfer Learning")

        gui.separator(self._transfer_tab)
        self.cb_optimization_type    = gui.comboBox(self._transfer_tab, self, "optimization_type", label="Optimization Type", items=self._optimization_types_combo_items, orientation="horizontal", callback=self._set_optimization_type)
        gui.separator(self._transfer_tab)

        self._fs_box      = gui.widgetBox(self._transfer_tab, "", width=self._opt_box.width() - 35, height=210, orientation='vertical', addSpace=False)
        self._ws_same_box = gui.widgetBox(self._transfer_tab, "", width=self._opt_box.width() - 35, height=210, orientation='vertical', addSpace=False)
        self._ws_diff_box = gui.widgetBox(self._transfer_tab, "", width=self._opt_box.width() - 35, height=210, orientation='vertical', addSpace=False)

        # FS
        self.cb_erase_warm_start_data = gui.comboBox(self._fs_box, self, "full_start_erase_warm_start_data", label="Erase warm start data", labelWidth=labels_width, items=["No", "Yes"], orientation="horizontal", callback=self._save_values)
        self.cb_save_warm_start_data  = gui.comboBox(self._fs_box, self, "full_start_save_warm_start_data", label="Save results as warm start", labelWidth=labels_width, items=["No", "Yes"], orientation="horizontal", callback=self._save_values)

        # WS - SAME
        self.cb_warm_start_home_directory_type = gui.comboBox(self._ws_same_box, self, "warm_start_home_directory_type", label="Warm Start Home Directory", items=self._warm_start_home_directory_types_combo_items, orientation="horizontal", callback=self._set_warm_start_home_directory_type)

        self._warm_start_home_directory_box = gui.widgetBox(self._ws_same_box, "", width=self._opt_box.width() - 35, orientation='horizontal', addSpace=False)
        self.le_warm_start_home_directory   = gui.lineEdit(self._warm_start_home_directory_box, self, "warm_start_home_directory", "Data From", orientation='horizontal', valueType=str, callback=self._save_values)
        gui.button(self._warm_start_home_directory_box, self, "...", width=30, callback=self._set_warm_start_home_directory)

        self.cb_warm_start_data_type                        = gui.comboBox(self._ws_same_box, self, "warm_start_data_type", label="Warm Start Data Type", items=self._warm_start_data_types_combo_items, orientation="horizontal", callback=self._set_warm_start_data_type)

        gui.separator(self._ws_same_box)
        self.cb_warm_start_strategy                         = gui.comboBox(self._ws_same_box, self, "warm_start_strategy", label="Warm Start Strategy", labelWidth=labels_width, items=self._warm_start_strategies_combo_items, orientation="horizontal", callback=self._set_warm_start_strategy)

        box = gui.widgetBox(self._ws_same_box, "", width=self._ws_same_box.width(), orientation='horizontal', addSpace=False)
        self.le_warm_start_search_space_expansion_factor = gui.lineEdit(box, self, "warm_start_search_space_expansion_factor", "Coefficients:                                  Search Space  ", orientation='horizontal', controlWidth=50, valueType=float, callback=self._save_values)
        self.le_warm_start_loss_expansion_factor         = gui.lineEdit(box, self, "warm_start_loss_expansion_factor",         "Loss",  orientation='horizontal', controlWidth=50, valueType=float, callback=self._save_values)

        self.cb_use_warm_start_search_space                 = gui.comboBox(self._ws_same_box, self, "use_warm_start_search_space", label="Warm Start Search Space", labelWidth=labels_width, items=["No", "Yes"], orientation="horizontal", callback=self._save_values)
        self.cb_use_warm_start_hypervolume_reference_points = gui.comboBox(self._ws_same_box, self, "use_warm_start_hypervolume_reference_points", label="Warm Start Hypervolume Reference Points", labelWidth=labels_width, items=["No", "Yes"], orientation="horizontal", callback=self._save_values)

        # -------------------------------- NN

        self.cb_neural_network_type = gui.comboBox(self._nn_box, self, "neural_network_type", label="Neural Network Type", labelWidth=250,
                                                   items=self._neural_network_types_combo_items, orientation="horizontal", callback=self._save_values)

        self._tandem_nn_box_1 = gui.widgetBox(self._nn_box, "", width=self._nn_box.width(), height=320, orientation='vertical', addSpace=False)

        self.cb_neural_network_model_from = gui.comboBox(self._tandem_nn_box_1, self, "neural_network_model_from", label="Neural Network model from", labelWidth=250,
                                                         items=self._neural_network_model_from_combo_items, orientation="horizontal", callback=self._set_neural_network_model_from)

        gui.separator(self._tandem_nn_box_1)

        self._neural_network_model_box_1   = gui.widgetBox(self._tandem_nn_box_1, "", width=self._tandem_nn_box_1.width() - 20, height=280, orientation='vertical', addSpace=False)
        self._neural_network_model_box_2   = gui.widgetBox(self._tandem_nn_box_1, "", width=self._tandem_nn_box_1.width() - 20, height=280, orientation='vertical', addSpace=False)

        self._neural_network_home_directory_box = gui.widgetBox(self._neural_network_model_box_1, "", width=self._tandem_nn_box_1.width() - 20, orientation='horizontal', addSpace=False)
        self.le_neural_network_home_directory  = gui.lineEdit(self._neural_network_home_directory_box, self, "neural_network_home_directory", "Data From", orientation='horizontal', valueType=str, callback=self._save_values)
        gui.button(self._neural_network_home_directory_box, self, "...", width=30, callback=self._set_neural_network_home_directory)

        self.cb_neural_network_data_type = gui.comboBox(self._neural_network_model_box_1, self, "neural_network_data_type", label="Training Data Type", items=self._neural_network_data_types_combo_items, orientation="horizontal", callback=self._save_values)

        gui.lineEdit(self._neural_network_model_box_1, self, "learning_rate",    "Learning Rate", labelWidth=labels_width, orientation='horizontal', controlWidth=75, valueType=float, callback=self._save_values)
        gui.lineEdit(self._neural_network_model_box_1, self, "weight_decay",     "Weight Decay",  labelWidth=labels_width, orientation='horizontal', controlWidth=75, valueType=float, callback=self._save_values)
        gui.lineEdit(self._neural_network_model_box_1, self, "total_epochs",     "Epochs",        labelWidth=labels_width, orientation='horizontal', controlWidth=75, valueType=int, callback=self._save_values)
        gui.lineEdit(self._neural_network_model_box_1, self, "patience",         "Patience",      labelWidth=labels_width, orientation='horizontal', controlWidth=75, valueType=int, callback=self._save_values)
        gui.lineEdit(self._neural_network_model_box_1, self, "train_batch_size", "Batch Size",    labelWidth=labels_width, orientation='horizontal', controlWidth=75, valueType=int, callback=self._save_values)

        self._neural_network_trained_model_file_box = gui.widgetBox(self._neural_network_model_box_2, "", width=self._tandem_nn_box_1.width() - 20, orientation='horizontal', addSpace=False)
        self.le_neural_network_trained_model_file  = gui.lineEdit(self._neural_network_trained_model_file_box, self, "neural_network_trained_model_file", "Trained model", orientation='horizontal', valueType=str, callback=self._save_values)
        gui.button(self._neural_network_trained_model_file_box, self, "...", width=30, callback=self._set_neural_network_trained_model_file)

        # ------------------------------------------------------------
        # Driver Setting

        driver_box_1 = gui.widgetBox(driver_settings_tab, "Driver Settings", width=self._main_box.width() - 15, height=self._main_box.height() - 40, orientation='horizontal', addSpace=False)

        # ------------------------- MM

        self._mm_box = gui.widgetBox(driver_box_1, "Motion Manager", width=0.5*(driver_box_1.width()) - 10, height=driver_box_1.height() - 40,  orientation='vertical', addSpace=False)
        self._bm_box  = gui.widgetBox(driver_box_1, "Beam Manager", width=0.5*(driver_box_1.width()) - 10, height=driver_box_1.height() - 40, orientation='vertical', addSpace=False)

        self.cb_motors = gui.comboBox(self._mm_box, self, "motor", label="Motors", items=self._motor_ids, orientation="horizontal", callback=self._load_current_motor)

        gui.separator(self._mm_box)

        self.mm_box_input = gui.widgetBox(self._mm_box, "", width=self._mm_box.width() - 25, orientation='vertical', addSpace=False)

        self.cb_motor_type = gui.comboBox(self.mm_box_input, self, "motor_type", label="Type", items=MotorType.get_labels_list(), orientation="horizontal", callback=self._set_current_motor)
        self.cb_units      = gui.comboBox(self.mm_box_input, self, "units", label="Units", items=Units.get_labels_list(), orientation="horizontal", callback=self._set_current_motor)

        box = gui.widgetBox(self.mm_box_input, "", width=self.mm_box_input.width(), height=30, orientation='horizontal', addSpace=False)
        self.le_boundary_from = gui.lineEdit(box, self, value="boundary_from", label="Boundary:                            From", labelWidth=210, orientation='horizontal', controlWidth=100, valueType=float, callback=self._set_current_motor)
        self.le_boundary_to   = gui.lineEdit(box, self, value="boundary_to",   label="   To",           labelWidth=30,  orientation='horizontal', controlWidth=100, valueType=float, callback=self._set_current_motor)

        self.le_resolution        = gui.lineEdit(self.mm_box_input, self, "resolution", "Step/Resolution", labelWidth=300, orientation='horizontal', valueType=float, callback=self._set_current_motor)
        self.le_repeatability     = gui.lineEdit(self.mm_box_input, self, "repeatability", "Repeatability", labelWidth=300, orientation='horizontal', valueType=float, callback=self._set_current_motor)
        self.le_shift_from_ideal  = gui.lineEdit(self.mm_box_input, self, "shift_from_ideal", "Shift from Ideal", labelWidth=300, orientation='horizontal', valueType=float, callback=self._set_current_motor)

        box = gui.widgetBox(self.mm_box_input, "", width=self.mm_box_input.width(), height=30, orientation='horizontal', addSpace=False)
        self.le_legacy_id_get = gui.lineEdit(box, self, "legacy_id_get", "Legacy ID:           Read", labelWidth=135, orientation='horizontal', controlWidth=130, valueType=str, callback=self._set_current_motor)
        self.le_legacy_id_set = gui.lineEdit(box, self, "legacy_id_set", " Write",         labelWidth=40, orientation='horizontal', controlWidth=130, valueType=str, callback=self._set_current_motor)

        gui.separator(self.mm_box_input, height=10)

        self.mm_box_input_2 = gui.widgetBox(self._mm_box, "Optimization Parameters", width=self._mm_box.width() - 25, orientation='vertical', addSpace=False)

        box = gui.widgetBox(self.mm_box_input_2, "", width=self.mm_box_input_2.width() - 20, height=30, orientation='horizontal', addSpace=False)
        self.le_search_range_from = gui.lineEdit(box, self, "search_range_from", label="Search Range:                From", labelWidth=210, orientation='horizontal', controlWidth=100, valueType=float, callback=self._set_current_motor_optimization)
        self.le_search_range_to   = gui.lineEdit(box, self, "search_range_to",   label="   To", labelWidth=30, orientation='horizontal', controlWidth=100, valueType=float, callback=self._set_current_motor_optimization)

        box = gui.widgetBox(self.mm_box_input_2, "", width=self.mm_box_input_2.width() -20, height=30, orientation='horizontal', addSpace=False)
        self.le_search_transfer_range_from = gui.lineEdit(box, self, "search_transfer_range_from",     "Search Transfer Range: From", labelWidth=210, orientation='horizontal', controlWidth=100, valueType=float, callback=self._set_current_motor_optimization)
        self.le_search_transfer_range_to   = gui.lineEdit(box, self, "search_transfer_range_to", "   To", labelWidth=30, orientation='horizontal', controlWidth=100, valueType=float, callback=self._set_current_motor_optimization)

        self.le_initial_position  = gui.lineEdit(self.mm_box_input_2, self, "initial_position",  "Initial Position", labelWidth=300, orientation='horizontal', valueType=float, callback=self._set_current_motor_optimization)

        self.cb_optimized = gui.checkBox(self.mm_box_input_2, self, "optimized", "Optimized", callback=self._set_current_motor_optimization)

        if self._has_set_initial_points:
            gui.separator(self._mm_box, height=10)
            gui.button(self._mm_box, None, "Set Current Positions as Initial", callback=self._set_current_motor_positions_as_initial_points_of_motors_info, width=0.95*self._mm_box.width(), height=30)

        # ------------------------- BM

        self.cb_platform          = gui.comboBox(self._bm_box, self, "platform", label="Platform", items=self._platform_combo_items, orientation="horizontal", callback=self._set_optimization_key)
        self.cb_beam_manager_type = gui.comboBox(self._bm_box, self, "beam_manager_type", label="Beam Properties", items=self._beam_manager_type_combo_items, orientation="horizontal", callback=self._set_optimization_key)
        self.cb_beam_manager_id   = gui.comboBox(self._bm_box, self, "beam_manager_id", label="Detection System", items=[], orientation="horizontal", callback=self._set_beam_manager_id)

        self._criteria_tab_widget = gui.tabWidget(self._bm_box)
        tab_0 = gui.createTabPage(self._criteria_tab_widget, "Objectives")
        tab_1 = gui.createTabPage(self._criteria_tab_widget, "Properties")
        tab_2 = gui.createTabPage(self._criteria_tab_widget, "Arguments")

        self._objective_table = QTableWidget()
        self._property_table  = QTableWidget()
        self._arguments_table = QTableWidget()
        tab_0.layout().addWidget(self._objective_table)
        tab_1.layout().addWidget(self._property_table)
        tab_2.layout().addWidget(self._arguments_table)

        # ------------------------------------------------------------
        # PLANS SETTING

        plans_box_1 = gui.widgetBox(plans_settings_tab, "Plans Settings", width=self._main_box.width() - 15, height=self._main_box.height() - 40, orientation='vertical', addSpace=False)

        box = gui.widgetBox(plans_box_1, "", orientation='horizontal', addSpace=False)
        self.cb_plans_platform  = gui.comboBox(box, self, "plans_platform", label="Platform", items=self._plans_platform_combo_items, labelWidth=100, orientation="horizontal", callback=self._set_plans_platform)
        gui.widgetBox(box, "", orientation='horizontal', width=plans_box_1.width()*0.55, addSpace=False)

        box = gui.widgetBox(plans_box_1, "", orientation='horizontal', addSpace=False)
        self._cb_plans = gui.comboBox(box, self, "plan_id", label="Plan", items=[], labelWidth=100, orientation="horizontal", callback=self._load_current_plan)
        gui.widgetBox(box, "", orientation='horizontal', width=plans_box_1.width()*0.55, addSpace=False)

        plans_box_2 = gui.widgetBox(plans_box_1, "Selected Plan", width=plans_box_1.width() - 20, height=plans_box_1.height() - 95, orientation='vertical', addSpace=False)

        box = gui.widgetBox(plans_box_2, "", orientation='horizontal', addSpace=False)
        self._cb_stages = gui.comboBox(box, self, "stage_id", label="Stage", items=[], labelWidth=100, orientation="horizontal", callback=self._load_current_stage)
        gui.widgetBox(box, "", orientation='horizontal', width=plans_box_1.width()*0.6, addSpace=False)

        plans_box_3 = gui.widgetBox(plans_box_2, "Selected Stage", width=plans_box_2.width() - 20, height=plans_box_2.height() - 70, orientation='horizontal', addSpace=False)

        self._stage_box    = gui.widgetBox(plans_box_3, "", width=0.5*(plans_box_3.width()) - 25, height=plans_box_3.height() - 15,  orientation='vertical', addSpace=False)
        gui.separator(plans_box_3, 15)
        self._summary_box  = gui.widgetBox(plans_box_3, "Optimization Summary", width=0.5*(plans_box_3.width()) - 10, height=plans_box_3.height() - 40, orientation='vertical', addSpace=False)


        box = gui.widgetBox(self._stage_box, "", orientation='horizontal', addSpace=False)

        gui.widgetLabel(box, label="Stage Info")
        self.lb_detection_system = gui.widgetLabel(box, label="", labelWidth=350)
        self.lb_detection_system.setFixedHeight(25)
        font = QFont(self.lb_detection_system.font())
        font.setBold(True)
        self.lb_detection_system.setFont(font)
        self.lb_detection_system.setStyleSheet("""
            QLabel {
                color : darkgreen; 
                background-color : rgb(243, 240, 160);
                border: 1px solid grey;
                border-radius: 2px;
                font-weight: bold;
                padding: 6px;
            }
        """)

        gui.separator(self._stage_box)
        self.cb_stage_optimizer_type    = gui.comboBox(self._stage_box, self, "stage_optimizer_type", label="Optimizer Type", labelWidth=250,
                                                       items=self._optimizer_types_combo_items, orientation="horizontal", callback=self._set_stage_optimizer_type)
        gui.separator(self._stage_box)

        self._stage_mobo_optimizers_box_1 = gui.widgetBox(self._stage_box, "", width=self._stage_box.width(), height=23, orientation='vertical', addSpace=False)
        self._stage_sonl_optimizers_box_1 = gui.widgetBox(self._stage_box, "", width=self._stage_box.width(), height=23, orientation='vertical', addSpace=False)
        self._stage_sobo_optimizers_box_1 = gui.widgetBox(self._stage_box, "", width=self._stage_box.width(), height=23, orientation='vertical', addSpace=False)

        self.cb_stage_mobo_optimizers = gui.comboBox(self._stage_mobo_optimizers_box_1, self, "stage_optimizer_name_mobo", label="Optimizer Name",
                                               items=self._optimizer_names_combo_items[Keys.OptimizerType.MOBO], orientation="horizontal",
                                               callback=self._set_stage_optimizer_name)
        self.cb_stage_sonl_optimizers = gui.comboBox(self._stage_sonl_optimizers_box_1, self, "stage_optimizer_name_sonl", label="Optimizer Name", items=self._optimizer_names_combo_items[Keys.OptimizerType.SONL], orientation="horizontal", callback=self._set_stage_optimizer_name)
        self.cb_stage_sobo_optimizers = gui.comboBox(self._stage_sobo_optimizers_box_1, self, "stage_optimizer_name_sobo", label="Optimizer Name", items=self._optimizer_names_combo_items[Keys.OptimizerType.SOBO], orientation="horizontal", callback=self._set_stage_optimizer_name)

        # MOBO -----------------------------

        height_darwin = 220
        height_else   = 240

        if sys.platform == 'darwin':
            self._stage_mobo_optimizers_box_2 = gui.widgetBox(self._stage_box, "", width=self._stage_box.width(), height=height_darwin, orientation='vertical', addSpace=False)
        else:
            self._stage_mobo_optimizers_box_2 = gui.widgetBox(self._stage_box, "", width=self._stage_box.width(), height=height_else, orientation='vertical', addSpace=False)

        self.cb_stage_acquisition_function_mobo_1 = gui.comboBox(self._stage_mobo_optimizers_box_2, self, "stage_acquisition_function_mobo", label="Acquisition Function", items=[], orientation="horizontal", callback=self._save_values)
        self.cb_stage_surrogate_mobo_1           = gui.comboBox(self._stage_mobo_optimizers_box_2, self, "stage_surrogate_mobo", label="Surrogate Model", items=[], orientation="horizontal", callback=self._save_values)
        self.cb_stage_surrogate_action_mobo_1    = gui.comboBox(self._stage_mobo_optimizers_box_2, self, "stage_surrogate_action_mobo", label="Surrogate Initialization", items=[], orientation="horizontal", callback=self._save_values)

        self.le_stage_sobol_iterations_mobo_1     = gui.lineEdit(self._stage_mobo_optimizers_box_2, self, "stage_sobol_iterations_mobo", "Sobol iterations", labelWidth=labels_width, orientation='horizontal', controlWidth=50, valueType=int, callback=self._save_values)
        self.le_stage_mobo_iterations_1           = gui.lineEdit(self._stage_mobo_optimizers_box_2, self, "stage_mobo_iterations", "MOBO iterations", labelWidth=labels_width, orientation='horizontal', controlWidth=50, valueType=int, callback=self._save_values)
        self.cb_stage_pareto_selection_1          = gui.comboBox(self._stage_mobo_optimizers_box_2, self, "stage_pareto_selection", label="Pareto Best Trial", items=["Nash Equilibrium", "Most Intense", "Narrowest", "Closest to Center"], orientation="horizontal", callback=self._save_values)

        self.cb_stage_use_hypervolume_exit_1      = gui.comboBox(self._stage_mobo_optimizers_box_2, self, "stage_use_hypervolume_exit", label="Analyze Hypervolume Improvement", items=["No", "Yes"], labelWidth=labels_width, orientation="horizontal", callback=self._set_stage_use_hypervolume_exit)

        box = gui.widgetBox(self._stage_mobo_optimizers_box_2, "", width=self._stage_mobo_optimizers_box_2.width(), orientation='horizontal', addSpace=False)
        self.le_stage_hypervolume_exit_convergence_threshold = gui.lineEdit(box, self, "stage_hypervolume_exit_convergence_threshold", "Hypervolume Exit:                      \u0394hv Threshold  ", orientation='horizontal', controlWidth=50, valueType=float, callback=self._save_values)
        self.le_stage_hypervolume_exit_patience              = gui.lineEdit(box, self, "stage_hypervolume_exit_patience",         "Patience",  orientation='horizontal', controlWidth=50, valueType=int, callback=self._save_values)

        if sys.platform == 'darwin':
            self._stage_mobo_optimizers_box_3 = gui.widgetBox(self._stage_box, "", width=self._stage_box.width(), height=height_darwin, orientation='vertical', addSpace=False)
        else:
            self._stage_mobo_optimizers_box_3 = gui.widgetBox(self._stage_box, "", width=self._stage_box.width(), height=height_else, orientation='vertical', addSpace=False)

        self.cb_stage_acquisition_function_mobo_2 = gui.comboBox(self._stage_mobo_optimizers_box_3, self, "stage_acquisition_function_mobo", label="Acquisition Function", items=[], orientation="horizontal", callback=self._save_values)
        self.le_stage_sobol_iterations_mobo_2     = gui.lineEdit(self._stage_mobo_optimizers_box_3, self, "stage_sobol_iterations_mobo", "Random iterations", labelWidth=labels_width, orientation='horizontal', controlWidth=50, valueType=int, callback=self._save_values)
        self.le_stage_mobo_iterations_2           = gui.lineEdit(self._stage_mobo_optimizers_box_3, self, "stage_mobo_iterations", "MOBO iterations", labelWidth=labels_width, orientation='horizontal', controlWidth=50, valueType=int, callback=self._save_values)

        # SONL -----------------------------

        if sys.platform == 'darwin':
            self._stage_sonl_optimizers_box_2 = gui.widgetBox(self._stage_box, "", width=self._stage_box.width(), height=height_darwin, orientation='vertical', addSpace=False)
        else:
            self._stage_sonl_optimizers_box_2 = gui.widgetBox(self._stage_box, "", width=self._stage_box.width(), height=height_else, orientation='vertical', addSpace=False)

        self.le_stage_max_iterations    = gui.lineEdit(self._stage_sonl_optimizers_box_2, self, "stage_max_iterations", "Max iterations per Step", labelWidth=labels_width, orientation='horizontal', controlWidth=50, valueType=int, callback=self._save_values)

        # SOBO -----------------------------

        if sys.platform == 'darwin':
            self._stage_sobo_optimizers_box_2 = gui.widgetBox(self._stage_box, "", width=self._stage_box.width(), height=height_darwin, orientation='vertical', addSpace=False)
        else:
            self._stage_sobo_optimizers_box_2 = gui.widgetBox(self._stage_box, "", width=self._stage_box.width(), height=height_else, orientation='vertical', addSpace=False)

        self.cb_stage_acquisition_function_sobo = gui.comboBox(self._stage_sobo_optimizers_box_2, self, "stage_acquisition_function_sobo", label="Acquisition Function", items=[], orientation="horizontal", callback=self._save_values)
        self.le_stage_sobol_iterations_sobo     = gui.lineEdit(self._stage_sobo_optimizers_box_2, self, "stage_sobol_iterations_sobo", "Sobol iterations", labelWidth=labels_width, orientation='horizontal', controlWidth=50, valueType=int, callback=self._save_values)
        self.le_stage_sobo_iterations           = gui.lineEdit(self._stage_sobo_optimizers_box_2, self, "stage_sobo_iterations", "SOBO iterations", labelWidth=labels_width, orientation='horizontal', controlWidth=50, valueType=int, callback=self._save_values)

        self._stage_full_start_box    = gui.widgetBox(self._stage_box, "", width=self._stage_box.width(), height=60, orientation='vertical', addSpace=False)
        self._stage_warm_start_sd_box = gui.widgetBox(self._stage_box, "", width=self._stage_box.width(), height=60, orientation='vertical', addSpace=False)
        self._stage_warm_start_dd_box = gui.widgetBox(self._stage_box, "", width=self._stage_box.width(), height=60, orientation='vertical', addSpace=False)

        self.cb_stage_erase_warm_start_data_fs = gui.comboBox(self._stage_full_start_box, self, "stage_erase_warm_start_data", label="Erase warm start data", labelWidth=labels_width, items=["No", "Yes"], orientation="horizontal", callback=self._save_values)
        self.cb_stage_save_warm_start_data_fs  = gui.comboBox(self._stage_full_start_box, self, "stage_save_warm_start_data", label="Save results as warm start", labelWidth=labels_width, items=["No", "Yes"], orientation="horizontal", callback=self._save_values)

        self.cb_stage_warm_start_strategy      = gui.comboBox(self._stage_warm_start_sd_box, self, "stage_warm_start_strategy", label="Warm Start Strategy", labelWidth=labels_width, items=self._warm_start_strategies_combo_items, orientation="horizontal", callback=self._set_stage_warm_start_strategy)

        box = gui.widgetBox(self._stage_warm_start_sd_box, "", width=self._stage_warm_start_sd_box.width(), orientation='horizontal', addSpace=False)
        self.le_stage_warm_start_search_space_expansion_factor = gui.lineEdit(box, self, "stage_warm_start_search_space_expansion_factor", "Coefficients:                                  Search Space  ", orientation='horizontal', controlWidth=50, valueType=float, callback=self._save_values)
        self.le_stage_warm_start_loss_expansion_factor         = gui.lineEdit(box, self, "stage_warm_start_loss_expansion_factor",         "Loss",  orientation='horizontal', controlWidth=50, valueType=float, callback=self._save_values)

        self.cb_stage_erase_warm_start_data_wsdd = gui.comboBox(self._stage_warm_start_dd_box, self, "stage_erase_warm_start_data", label="Erase warm start data", labelWidth=labels_width, items=["No", "Yes"], orientation="horizontal", callback=self._save_values)
        self.cb_stage_save_warm_start_data_wsdd  = gui.comboBox(self._stage_warm_start_dd_box, self, "stage_save_warm_start_data", label="Save results as warm start", labelWidth=labels_width, items=["No", "Yes"], orientation="horizontal", callback=self._save_values)

        self.cb_stage_move_motors_on_best_trial = gui.comboBox(self._stage_box, self, "stage_move_motors_on_best_trial", label="Move motors on best trial", labelWidth=labels_width, items=["No", "Yes"], orientation="horizontal", callback=self._save_values)
        self.cb_stage_requires_pause_at_end     = gui.comboBox(self._stage_box, self, "stage_requires_pause_at_end", label="Stage requires pause at end", labelWidth=labels_width, items=["No", "Yes"], orientation="horizontal", callback=self._save_values)

        self._summary_text_area = gui.textArea(height=self._summary_box.height()-40,
                                               width=self._summary_box.width()-20,
                                               readOnly=True)
        self._summary_box.layout().addWidget(self._summary_text_area)


        # ------------------------------------------------------------
        # GUI SETTING

        if sys.platform == 'darwin':
            general_setting_box_1 = gui.widgetBox(general_settings_tab, "GUI", width=self._main_box.width() - 15, height=140, orientation='vertical', addSpace=False)
            general_setting_box_2 = gui.widgetBox(general_settings_tab, "Runtime", width=self._main_box.width() - 15, height=100, orientation='vertical', addSpace=False)
        else:
            general_setting_box_1 = gui.widgetBox(general_settings_tab, "GUI", width=self._main_box.width() - 15, height=150, orientation='vertical', addSpace=False)
            general_setting_box_2 = gui.widgetBox(general_settings_tab, "Runtime", width=self._main_box.width() - 15, height=110, orientation='vertical', addSpace=False)

        self.cb_real_time_data = gui.checkBox(general_setting_box_1, self, "real_time_data", "Show Plots",)
        self.cb_capture_stdout = gui.checkBox(general_setting_box_1, self, "capture_stdout", "Capture StdOut")
        self.cb_save_beams     = gui.checkBox(general_setting_box_1, self, "save_beams", "Save Beam Data")

        self.le_working_directory = gui.lineEdit(general_setting_box_2, self, "working_directory", label="Working Directory", labelWidth=labels_width, valueType=str, orientation="vertical")
        self.le_working_directory.setReadOnly(True)
        self.le_working_directory.setStyleSheet("QLineEdit {color : black; background : rgb(243, 240, 160); text-align : left}")

        ########################################################################################
        # Grafic and data setup

        self._refresh_widget()

        self.__is_init = False

    #############################################################################
    #
    # RUNTIME MANAGEMENT
    #
    #############################################################################

    def _refresh_widget(self):
        self._set_optimizer_type()
        self._set_optimization_type()
        self._set_neural_network_model_from()
        self._load_current_motor()
        self._set_optimization_key()
        self._set_plans_platform()

    # AI -------------------------------------------------------------

    def _set_optimizer_type(self):
        self._mobo_optimizers_box_1.setVisible(self.optimizer_type == 0)
        self._sonl_optimizers_box_1.setVisible(self.optimizer_type == 1)
        self._sobo_optimizers_box_1.setVisible(self.optimizer_type == 2)
        self._mobo_optimizers_box_2.setVisible(self.optimizer_type == 0)
        self._mobo_optimizers_box_3.setVisible(self.optimizer_type == 0)
        self._sonl_optimizers_box_2.setVisible(self.optimizer_type == 1)
        self._sobo_optimizers_box_2.setVisible(self.optimizer_type == 2)

        self._set_optimizer_name()

    def _set_optimizer_name(self):
        if self.optimizer_type == 0:
            self._mobo_optimizers_box_2.setVisible(False)
            self._mobo_optimizers_box_3.setVisible(False)

            if self.optimizer_name_mobo in [0, 1]: # AX, Optuna
                self._mobo_optimizers_box_2.setVisible(True)
                self.cb_acquisition_function_mobo_1.clear()
                self.cb_acquisition_function_mobo_1.addItems(self.get_acquisition_functions_mobo_combo_items())
                self.cb_acquisition_function_mobo_1.setCurrentIndex(self.acquisition_function_mobo)
                if self.optimizer_name_mobo == 0: # Ax
                    self.cb_surrogate_mobo_1.clear()
                    self.cb_surrogate_mobo_1.addItems(self.get_surrogate_mobo_combo_items())
                    self.cb_surrogate_mobo_1.setCurrentIndex(self.surrogate_mobo)
                    self.cb_surrogate_action_mobo_1.clear()
                    self.cb_surrogate_action_mobo_1.addItems(self.get_surrogate_action_mobo_combo_items())
                    self.cb_surrogate_action_mobo_1.setCurrentIndex(self.surrogate_action_mobo)
            else:
                self._mobo_optimizers_box_3.setVisible(True)
                self.cb_acquisition_function_mobo_2.clear()
                self.cb_acquisition_function_mobo_2.addItems(self.get_acquisition_functions_mobo_combo_items())
                self.cb_acquisition_function_mobo_2.setCurrentIndex(self.acquisition_function_mobo)
        elif self.optimizer_type == 2:
            self._sobo_optimizers_box_2.setVisible(True)

            self.cb_acquisition_function_sobo.clear()
            self.cb_acquisition_function_sobo.addItems(self.get_acquisition_functions_sobo_combo_items())
            self.cb_acquisition_function_sobo.setCurrentIndex(self.acquisition_function_sobo)

        if not self.__is_init: self._reload_values()

    def _set_optimization_type(self):
        self._fs_box.setVisible(self.optimization_type == 0)
        self._ws_same_box.setVisible(self.optimization_type == 1)
        self._ws_diff_box.setVisible(self.optimization_type == 2)

        if self.optimization_type == 1:
            self._set_warm_start_home_directory_type()
            self._set_warm_start_data_type()
            self._set_warm_start_strategy()

        if not self.__is_init: self._reload_values()

    def _set_neural_network_model_from(self):
        self._neural_network_model_box_1.setVisible(self.neural_network_model_from==0)
        self._neural_network_model_box_2.setVisible(self.neural_network_model_from==1)

        if not self.__is_init: self._save_values()

    def _set_neural_network_home_directory(self):
        self.le_neural_network_home_directory.setText(
            gui.selectDirectoryFromDialog(self,
                                          previous_directory_path=self.neural_network_home_directory,
                                          start_directory=self.neural_network_home_directory)
        )

        if not self.__is_init: self._save_values()

    def _set_neural_network_trained_model_file(self):
        self.le_neural_network_trained_model_file.setText(
            gui.selectFileFromDialog(self,
                                     previous_file_path=self.neural_network_trained_model_file,
                                     start_directory=self.neural_network_home_directory)
        )

        if not self.__is_init: self._save_values()

    def _set_warm_start_home_directory_type(self):
        self._warm_start_home_directory_box.setEnabled(self.warm_start_home_directory_type==1)

        if not self.__is_init: self._save_values()

    def _set_warm_start_home_directory(self):
        self.le_warm_start_home_directory.setText(
            gui.selectDirectoryFromDialog(self,
                                          previous_directory_path=self.warm_start_home_directory,
                                          start_directory=self.warm_start_home_directory)
        )
        if not self.__is_init: self._save_values()

    def _set_warm_start_data_type(self):
        if not self.__is_init: self._save_values()

    def _set_warm_start_strategy(self):
        self.le_warm_start_search_space_expansion_factor.setEnabled(self.warm_start_strategy==1)

        if not self.__is_init:
            self._warm_start_same_configuration["defaults"]["warm_start_strategy"] = self.warm_start_strategy
            self._reload_values()

    # BEAM MANAGER -------------------------------------------------------------

    def _set_optimization_key(self):
        beam_manager_type_key           = self._beam_manager_types[int(self.beam_manager_type)]
        beam_manager_type_configuration = self._beam_manager_configuration[beam_manager_type_key]

        self.cb_beam_manager_id.clear()
        self.cb_beam_manager_id.addItems(beam_manager_type_configuration["beam_manager_ids_combo"])

        self.beam_manager_id = self._beam_manager_ids[beam_manager_type_key]

        self._set_beam_manager_id()

    def _restore_previous_optimization_key(self):
        self.platform             = self._gui_parameters.get_parameter("previous_platform", self.platform)
        self.beam_manager_type    = self._gui_parameters.get_parameter("previous_beam_manager_type", self.beam_manager_type)
        self.beam_manager_id      = self._previous_beam_manager_ids[self._beam_manager_types[self.beam_manager_type]]

        beam_manager_type_key = self._beam_manager_types[int(self.beam_manager_type)]
        beam_manager_type_configuration = self._beam_manager_configuration[beam_manager_type_key]

        self.cb_beam_manager_id.clear()
        self.cb_beam_manager_id.addItems(beam_manager_type_configuration["beam_manager_ids_combo"])

        self.cb_platform.setCurrentIndex(self.platform)
        self.cb_beam_manager_type.setCurrentIndex(self.beam_manager_type)
        self.cb_beam_manager_id.setCurrentIndex(self.beam_manager_id)

    def _save_current_optimization_key(self):
        self._gui_parameters.set_parameter("previous_platform", self.platform)
        self._gui_parameters.set_parameter("previous_beam_manager_type", self.beam_manager_type)
        self._previous_beam_manager_ids[self._beam_manager_types[self.beam_manager_type]] = self.beam_manager_id

    def _set_beam_manager_id(self):
        try:
            self._load_objective_table()
            self._load_property_table()
            self._load_arguments_table()
            if not self.__is_init: self._load_current_motor_optimization()

            self._save_current_optimization_key()
        except ValueError as error:
            MessageDialog.message(self, title="Input Error", message=error.args[0], type="critical", width=500)
            self._restore_previous_optimization_key()
        except Exception as exception:
            MessageDialog.message(self, title="Unexpected Exception", message=exception.args[0], type="critical", width=700)
            self._restore_previous_optimization_key()

    def _update_objective_table(self):
        self._set_current_objectives()
        self._load_objective_table()

    def _update_property_table(self):
        self._set_current_properties()
        self._load_property_table()

    def _update_arguments_table(self):
        self._set_current_arguments()
        self._load_arguments_table()

    def _load_objective_table(self):
        try: self._objective_table.cellChanged.disconnect(self._update_objective_table)
        except: pass

        if   self.beam_manager_type == 0: criteria = DirectBeamImageOptimizationCriteria.to_list()
        elif self.beam_manager_type == 1: criteria = WavefrontAnalysisOptimizationCriteria.to_list()
        elif self.beam_manager_type == 2: criteria = SpeckleAnalysisOptimizationCriteria.to_list()
        else:                             criteria = [] # work in progress

        objectives = self._get_objectives()

        self._objective_table.clear()
        self._objective_table.setColumnCount(5)
        self._objective_table.setHorizontalHeaderLabels(['Objective', 'Reference', 'Boundary', 'Weight', 'Exit'])
        font = self._objective_table.horizontalHeader().font()
        font.setPixelSize(10)
        self._objective_table.horizontalHeader().setFont(font)
        self._objective_table.setRowCount(len(criteria))
        self._objective_table.setColumnWidth(0, 200)
        self._objective_table.setColumnWidth(1, 55)
        self._objective_table.setColumnWidth(2, 55)
        self._objective_table.setColumnWidth(3, 55)
        self._objective_table.setColumnWidth(4, 55)

        for row, criterion in zip(range(len(criteria)), criteria):
            cb_criterion = QTableWidgetItem(criterion)
            cb_criterion.setText(criterion)
            font = cb_criterion.font()
            font.setPixelSize(10)
            cb_criterion.setFont(font)
            cb_criterion.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
            cb_criterion.setCheckState(Qt.Checked if criterion in objectives.keys() else Qt.Unchecked)
            self._objective_table.setItem(row, 0, cb_criterion)

            reference = str(objectives[criterion][0]) if criterion in objectives.keys() else "0.0"
            le_reference = QTableWidgetItem(reference)
            le_reference.setText(reference)
            font = le_reference.font()
            font.setPixelSize(10)
            le_reference.setFont(font)
            le_reference.setFlags(Qt.ItemIsEditable | Qt.ItemIsEnabled)
            self._objective_table.setItem(row, 1, le_reference)

            boundary = str(objectives[criterion][1]) if criterion in objectives.keys() else "0.0"
            le_boundary = QTableWidgetItem(boundary)
            le_boundary.setText(boundary)
            font = le_boundary.font()
            font.setPixelSize(10)
            le_boundary.setFont(font)
            le_boundary.setFlags(Qt.ItemIsEditable | Qt.ItemIsEnabled)
            self._objective_table.setItem(row, 2, le_boundary)

            weight = str(objectives[criterion][2]) if criterion in objectives.keys() else "1.0"
            le_weight = QTableWidgetItem(weight)
            le_weight.setText(weight)
            font = le_weight.font()
            font.setPixelSize(10)
            le_weight.setFont(font)
            le_weight.setFlags(Qt.ItemIsEditable | Qt.ItemIsEnabled)
            self._objective_table.setItem(row, 3, le_weight)

            exit = str(objectives[criterion][3]) if criterion in objectives.keys() else "0.0"
            le_exit = QTableWidgetItem(exit)
            le_exit.setText(exit)
            font = le_exit.font()
            font.setPixelSize(10)
            le_exit.setFont(font)
            le_exit.setFlags(Qt.ItemIsEditable | Qt.ItemIsEnabled)
            self._objective_table.setItem(row, 4, le_exit)

        self._objective_table.cellChanged.connect(self._update_objective_table)

    def _load_property_table(self):
        try: self._property_table.cellChanged.disconnect(self._update_property_table)
        except: pass

        if   self.beam_manager_type == 0: criteria = DirectBeamImageProperties.to_list()
        elif self.beam_manager_type == 1: criteria = WavefrontAnalysisProperties.to_list()
        elif self.beam_manager_type == 2: criteria = SpeckleAnalysisProperties.to_list()
        else:                             criteria = [] # work in progress

        properties = self._get_properties()

        self._property_table.clear()
        self._property_table.setColumnCount(2)
        self._property_table.setHorizontalHeaderLabels(['Property', 'Target Value'])
        font = self._property_table.horizontalHeader().font()
        font.setPixelSize(10)
        self._property_table.horizontalHeader().setFont(font)
        self._property_table.setRowCount(len(criteria))
        self._property_table.setColumnWidth(0, 200)
        self._property_table.setColumnWidth(1, 110)

        for row, criterion in zip(range(len(criteria)), criteria):
            cb_criterion = QTableWidgetItem(criterion)
            cb_criterion.setText(criterion)
            font = cb_criterion.font()
            font.setPixelSize(10)
            cb_criterion.setFont(font)
            cb_criterion.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
            cb_criterion.setCheckState(Qt.Checked if criterion in properties.keys() else Qt.Unchecked)
            self._property_table.setItem(row, 0, cb_criterion)

            target = str(properties[criterion]) if criterion in properties.keys() else "0.0"
            le_target = QTableWidgetItem(target)
            le_target.setText(target)
            font = le_target.font()
            font.setPixelSize(10)
            le_target.setFont(font)
            le_target.setFlags(Qt.ItemIsEditable | Qt.ItemIsEnabled)
            self._property_table.setItem(row, 1, le_target)

        self._property_table.cellChanged.connect(self._update_property_table)

    def _load_arguments_table(self):
        try: self._arguments_table.cellChanged.disconnect(self._update_arguments_table)
        except: pass

        arguments = self._get_arguments()

        self._arguments_table.clear()
        self._arguments_table.setColumnCount(2)
        self._arguments_table.setHorizontalHeaderLabels(['Argument', 'Value'])
        font = self._arguments_table.horizontalHeader().font()
        font.setPixelSize(10)
        self._arguments_table.horizontalHeader().setFont(font)
        self._arguments_table.setRowCount(len(arguments) - 1)
        self._arguments_table.setColumnWidth(0, 200)
        self._arguments_table.setColumnWidth(1, 1000)

        for row, argument in zip(range(len(arguments)), arguments):
            if not argument == "beam_manager_id":
                le_argument = QTableWidgetItem(argument)
                le_argument.setText(argument)
                font = le_argument.font()
                font.setPixelSize(10)
                le_argument.setFont(font)
                le_argument.setFlags(Qt.ItemIsEnabled)
                self._arguments_table.setItem(row, 0, le_argument)

                value = str(arguments[argument])
                le_value = QTableWidgetItem(value)
                le_value.setText(value)
                font = le_value.font()
                font.setPixelSize(10)
                le_value.setFont(font)
                le_value.setFlags(Qt.ItemIsEditable | Qt.ItemIsEnabled)
                self._arguments_table.setItem(row, 1, le_value)

        self._arguments_table.cellChanged.connect(self._update_arguments_table)

    def _get_objectives_from_table(self):
        objectives = {}
        for row_index in range(self._objective_table.rowCount()):
            criterion_item = self._objective_table.item(row_index, 0)
            reference_item = self._objective_table.item(row_index, 1)
            boundary_item  = self._objective_table.item(row_index, 2)
            weight_item    = self._objective_table.item(row_index, 3)
            exit_item      = self._objective_table.item(row_index, 4)

            if criterion_item.checkState() == Qt.Checked:
                if not check_number(reference_item.text()): raise ValueError(f"Target (row {row_index + 1}) is not numeric")
                if not check_number(boundary_item.text()):  raise ValueError(f"Boundary (row {row_index + 1}) is not numeric")
                if not check_number(weight_item.text()):    raise ValueError(f"Weight (row {row_index + 1}) is not numeric")
                if not check_number(exit_item.text()):      raise ValueError(f"Exit (row {row_index + 1}) is not numeric")
                objectives[criterion_item.text()] = [string_to_number(reference_item.text()),
                                                     string_to_number(boundary_item.text()),
                                                     string_to_number(weight_item.text()),
                                                     string_to_number(exit_item.text())]

        return objectives

    def _get_properties_from_table(self):
        properties = {}
        for row_index in range(self._property_table.rowCount()):
            property_item = self._property_table.item(row_index, 0)
            target_item = self._property_table.item(row_index, 1)

            if property_item.checkState() == Qt.Checked:
                if not check_number(target_item.text()): raise ValueError(f"Target Value (row {row_index + 1}) is not numeric")
                properties[property_item.text()] = string_to_number(target_item.text())

        return properties

    def _get_arguments_from_table(self):
        arguments = {}
        for row_index in range(self._arguments_table.rowCount()):
            argument_item = self._arguments_table.item(row_index, 0)
            value_item    = self._arguments_table.item(row_index, 1)

            text = value_item.text()
            if "[" in text:
                value = string_to_list(text, str)
                if len(value) > 0 and check_number(value[0]): value = [string_to_number(x) for x in value]
            elif "{" in text:
                value = string_to_dict(text, str)
                if len(value) > 0 and check_number(value[list(value.keys())[0]]): value = {k : string_to_number(value[k]) for k in value.keys()}
            else:
                value = text
                if not value is None:
                    if  check_number(value): value = string_to_number(text)
                    elif check_bool(value):  value = string_to_bool(value)

            arguments[argument_item.text()] = value

        return arguments

    # MOTION MANAGER -------------------------------------------------------------

    def _load_current_motor(self):
        try:
            current_motor_id      = self._motors_info.get_motor_ids()[self.motor]
            motor_info: MotorInfo = self._motors_info.get_motor_info(motor_id=current_motor_id)

            boundaries            = motor_info.boundaries
            legacy_ids            = motor_info.legacy_ids

            self.motor_type        = motor_info.type.value - 1
            self.units             = motor_info.units.value - 1
            self.boundary_from     = boundaries[0]
            self.boundary_to       = boundaries[1]
            self.resolution        = motor_info.resolution
            self.repeatability     = motor_info.repeatability
            self.shift_from_ideal  = motor_info.shift_from_ideal
            self.legacy_id_get     = legacy_ids[0]
            self.legacy_id_set     = legacy_ids[1]

            self.cb_motor_type.setCurrentIndex(motor_info.type.value - 1)
            self.cb_units.setCurrentIndex(motor_info.units.value - 1)
            self.le_boundary_from.setText(str(boundaries[0]))
            self.le_boundary_to.setText(str(boundaries[1]))
            self.le_resolution.setText(str(motor_info.resolution))
            self.le_repeatability.setText(str(motor_info.repeatability))
            self.le_shift_from_ideal.setText(str(motor_info.shift_from_ideal))
            self.le_legacy_id_get.setText(str(legacy_ids[1]))
            self.le_legacy_id_set.setText(str(legacy_ids[0]))

        except ValueError as error:
            MessageDialog.message(self, title="Input Error", message=error.args[0], type="critical", width=500)
        except Exception as exception:
            MessageDialog.message(self, title="Unexpected Exception", message=exception.args[0], type="critical", width=700)

        self._load_current_motor_optimization()

    def _load_current_motor_optimization(self):
        current_motor_id = self._motors_info.get_motor_ids()[self.motor]
        platform_key, beam_manager_type_key, beam_manager_id_key, _ = self._get_beam_manager_keys_and_dictionary()

        motor_config = self._motion_manager_configuration["defaults"][current_motor_id]

        search_range          = motor_config["search_range"][beam_manager_type_key][platform_key][beam_manager_id_key]
        search_transfer_range = motor_config["search_transfer_range"][beam_manager_type_key][platform_key][beam_manager_id_key]
        initial_position      = motor_config["initial_position"][beam_manager_type_key][platform_key][beam_manager_id_key]
        optimized             = motor_config["optimized"][beam_manager_type_key][platform_key][beam_manager_id_key]

        self.search_range_from          = search_range[0]
        self.search_range_to            = search_range[1]
        self.search_transfer_range_from = search_transfer_range[0]
        self.search_transfer_range_to   = search_transfer_range[1]
        self.initial_position           = initial_position
        self.optimized                  = optimized

        self.le_search_range_from.setText(str(search_range[0]))
        self.le_search_range_to.setText(str(search_range[1]))
        self.le_search_transfer_range_from.setText(str(search_transfer_range[0]))
        self.le_search_transfer_range_to.setText(str(search_transfer_range[1]))
        self.le_initial_position.setText(str(initial_position))
        self.cb_optimized.setChecked(optimized)

    def _set_current_motor(self):
        if self._motors_info is None: return

        try:
            current_motor_id        = self.cb_motors.currentText()
            dictionary              = self._motors_info.get_motor_info(motor_id=current_motor_id).to_dictionary()

            dictionary["boundaries"]       = [self.boundary_from, self.boundary_to]
            dictionary["resolution"]       = self.resolution
            dictionary["repeatability"]    = self.repeatability
            dictionary["shift_from_ideal"] = self.shift_from_ideal
            dictionary["legacy_ids"]       = [self.legacy_id_set, self.legacy_id_get]
            dictionary["type"]             = self.motor_type + 1
            dictionary["units"]            = self.units + 1

            self._motors_info.add_motor_info(current_motor_id, MotorInfo.from_dictionary(dictionary))
        except ValueError as error:
            MessageDialog.message(self, title="Input Error", message=error.args[0], type="critical", width=500)
        except Exception as exception:
            MessageDialog.message(self, title="Unexpected Exception", message=exception.args[0], type="critical", width=700)

    def _set_current_motor_optimization(self):
        current_motor_id = self.cb_motors.currentText()
        platform_key, beam_manager_type_key, beam_manager_id_key, _ = self._get_beam_manager_keys_and_dictionary()

        motor_config = self._motion_manager_configuration["defaults"][current_motor_id]

        motor_config["search_range"][beam_manager_type_key][platform_key][beam_manager_id_key]          =  [self.search_range_from, self.search_range_to]
        motor_config["search_transfer_range"][beam_manager_type_key][platform_key][beam_manager_id_key] =  [self.search_transfer_range_from, self.search_transfer_range_to]
        motor_config["initial_position"][beam_manager_type_key][platform_key][beam_manager_id_key]      =  self.initial_position
        motor_config["optimized"][beam_manager_type_key][platform_key][beam_manager_id_key]             =  self.optimized

    def _set_current_motor_positions_as_initial_points_of_motors_info(self):
        if self._motors_info is None: return

        try:
            self._collect_configuration_parameters()

            if ConfirmDialog.confirmed(self,
                                       title="Confirm setting initial position from current motor positions",
                                       message="Confirm setting initial position from current motor positions?"):
                self._set_current_motor_positions_as_initial_points(self._motors_info, self._gui_parameters)
                self._load_current_motor_optimization()

        except ValueError as error:
            MessageDialog.message(self, title="Input Error", message=error.args[0], type="critical", width=500)
        except Exception as exception:
            MessageDialog.message(self, title="Unexpected Exception", message=exception.args[0], type="critical", width=700)

    # PLANS -------------------------------------------------------------

    def _set_plans_platform(self):
        configuration = self._configuration
        plan_platform = self._plans_platforms[self.plans_platform]
        self.plan_id  = self._plan_ids[plan_platform]

        self._cb_plans.clear()
        self._cb_plans.addItems(configuration.plans_configuration.get_plan_names_by_platform(plan_platform))
        self._cb_plans.setCurrentIndex(int(self.plan_id))

        self._load_current_plan()

    def _load_current_plan(self):
        configuration = self._configuration

        plan_platform = self._plans_platforms[self.plans_platform]
        plan_id       = configuration.plans_configuration.get_plan_ids_by_platform(plan_platform)[self.plan_id]

        self._plan_ids[plan_platform]          = self.plan_id
        self._current_plan : AutoAlignmentPlan = configuration.plans_configuration.get_plan(plan_platform, plan_id)
        self.stage_id                          = 0

        self._cb_stages.clear()
        self._cb_stages.addItems([(id.split("_")[1] + ": "  + name) for id, name in zip(self._current_plan.get_stages_id(), self._current_plan.get_stages_names())])
        self._cb_stages.setCurrentIndex(self.stage_id)

        self._load_current_stage()

    def _load_current_stage(self):
        self.__is_loading_stage = True

        plan_platform = self._plans_platforms[self.plans_platform]
        stage_id      = self._current_plan.get_stages_id()[self.stage_id]

        self._current_stage : AutoAlignmentStage = self._current_plan.get_stage(stage_id)

        self.stage_beam_manager_type = self._current_stage.beam_manager_type
        self.stage_beam_manager_id   = self._current_stage.beam_manager_id
        self.stage_ai_type           = self._current_stage.ai_type

        platform_key                    = plan_platform
        beam_manager_type_key           = self._beam_manager_types[int(self.stage_beam_manager_type)]
        beam_manager_type_configuration = self._beam_manager_configuration[beam_manager_type_key]
        beam_manager_ids                = beam_manager_type_configuration["beam_manager_ids"]
        beam_manager_id_key             = beam_manager_ids[int(self.stage_beam_manager_id)]
        stage_ai_configuration          = self._current_stage.ai_configuration

        self.stage_optimizer_type = stage_ai_configuration["optimizer_type"]

        beam_manager_str = beam_manager_type_configuration["beam_manager_ids_combo"][self.stage_beam_manager_id]

        properties_label = f"{self._beam_manager_type_combo_items[self.stage_beam_manager_type]}: " + \
                           f"{beam_manager_str}"

        self.stage_optimizer_type = stage_ai_configuration["optimizer_type"]
        self.cb_stage_optimizer_type.setCurrentIndex(self.stage_optimizer_type)

        if self.stage_optimizer_type == 0:
            self.stage_optimizer_name_mobo       = stage_ai_configuration.get("name", self.optimizer_name_mobo)
            self.stage_acquisition_function_mobo = stage_ai_configuration.get("acquisition_function", self.acquisition_function_mobo)
            self.stage_surrogate_mobo            = stage_ai_configuration.get("surrogate", self.surrogate_mobo)
            self.stage_surrogate_action_mobo     = stage_ai_configuration.get("surrogate_action", self.surrogate_action_mobo)
            self.stage_sobol_iterations_mobo     = stage_ai_configuration.get("sobol_iterations", self.sobol_iterations_mobo)
            self.stage_mobo_iterations           = stage_ai_configuration.get("mobo_iterations", self.mobo_iterations)
            self.cb_stage_mobo_optimizers.setCurrentIndex(self.stage_optimizer_name_mobo)

            if self.stage_optimizer_name_mobo in [0, 1]:
                self.stage_pareto_selection  = stage_ai_configuration.get("pareto_selection", self.pareto_selection)
                self.stage_use_hypervolume_exit = stage_ai_configuration.get("use_hypervolume_exit", 0)
                self.stage_hypervolume_exit_convergence_threshold = stage_ai_configuration["hypervolume_exit"].get("convergence_threshold", self.hypervolume_exit_convergence_threshold)
                self.stage_hypervolume_exit_patience =              stage_ai_configuration["hypervolume_exit"].get("patience", self.hypervolume_exit_patience)

                self.le_stage_sobol_iterations_mobo_1.setText(str(self.stage_sobol_iterations_mobo))
                self.le_stage_mobo_iterations_1.setText(str(self.stage_mobo_iterations))
                self.le_stage_hypervolume_exit_convergence_threshold.setText(str(self.stage_hypervolume_exit_convergence_threshold))
                self.le_stage_hypervolume_exit_patience.setText(str(self.stage_hypervolume_exit_patience))
                self.cb_stage_pareto_selection_1.setCurrentIndex(self.stage_pareto_selection)
                self.cb_stage_use_hypervolume_exit_1.setCurrentIndex(self.stage_use_hypervolume_exit)
            else:
                self.le_stage_sobol_iterations_mobo_2.setText(str(self.stage_sobol_iterations_mobo))
                self.le_stage_mobo_iterations_2.setText(str(self.stage_mobo_iterations))
        elif self.stage_optimizer_type == 1:
            self.stage_optimizer_name_sonl       = stage_ai_configuration.get("name", self.optimizer_name_sonl)
            self.stage_max_iterations            = stage_ai_configuration.get("max_iterations", self.max_iterations)
            
            self.cb_stage_sonl_optimizers.setCurrentIndex(self.stage_optimizer_name_sonl)
            self.le_stage_max_iterations.setText(str(self.stage_max_iterations))
        elif self.stage_optimizer_type == 2:
            self.stage_optimizer_name_sobo       = stage_ai_configuration.get("name", self.optimizer_name_sobo)
            self.stage_sobol_iterations_sobo     = stage_ai_configuration.get("sobol_iterations", self.sobol_iterations_sobo)
            self.stage_sobo_iterations           = stage_ai_configuration.get("sobo_iterations", self.sobo_iterations)

            self.cb_stage_sobo_optimizers.setCurrentIndex(self.stage_optimizer_name_sobo)
            self.le_stage_sobol_iterations_sobo.setText(str(self.stage_sobol_iterations_sobo))
            self.le_stage_sobo_iterations.setText(str(self.stage_sobo_iterations))
        
        self._set_stage_optimizer_type()

        self.stage_optimization_type         = stage_ai_configuration["optimization_type"]

        if self.stage_optimization_type in [0, 2]:
            self.stage_erase_warm_start_data     = int(stage_ai_configuration.get("erase_warm_start_data", self.full_start_erase_warm_start_data))
            self.stage_save_warm_start_data      = int(stage_ai_configuration.get("save_warm_start_data", self.full_start_save_warm_start_data))
        else:
            self._stage_warm_start_expansion_factors = stage_ai_configuration.get("warm_start_expansion_factors", {Keys.WarmStartStrategies.FROM_MAXIMUM_LOSS: [0.0, 0.01],
                                                                                                                               Keys.WarmStartStrategies.FROM_MINIMUM_LOSS: [0.1, 1.5]})
            self.stage_warm_start_strategy = stage_ai_configuration.get("warm_start_strategy", self.warm_start_strategy)

        self.stage_move_motors_on_best_trial = int(stage_ai_configuration.get("move_motors_on_best_trial", False))
        self.stage_requires_pause_at_end     = int(self._current_stage.requires_pause_at_end)

        self._set_stage_optimization_type()

        self.cb_stage_move_motors_on_best_trial.setCurrentIndex(self.stage_move_motors_on_best_trial)
        self.cb_stage_requires_pause_at_end.setCurrentIndex(self.stage_requires_pause_at_end)

        def get_optimization_type_short():
            if   self.stage_optimization_type == 0: return "Full Start"
            elif self.stage_optimization_type == 1: return "Warm Start S.D."
            elif self.stage_optimization_type == 2: return "Warm Start D.D."

        properties_label += f" - {get_optimization_type_short()}"

        self.lb_detection_system.setText(properties_label)

        self.stage_optimization_summary = ("---------------------------------------------\n" +
                                           "Motor Configurations:\n" +
                                           "---------------------------------------------\n")

        for motor_id in self._motors_info.get_motor_ids():
            motor_config = self._motion_manager_configuration["defaults"][motor_id]

            search_range          = motor_config["search_range"][beam_manager_type_key][platform_key][beam_manager_id_key]
            search_transfer_range = motor_config["search_transfer_range"][beam_manager_type_key][platform_key][beam_manager_id_key]
            initial_position      = motor_config["initial_position"][beam_manager_type_key][platform_key][beam_manager_id_key]
            optimized             = motor_config["optimized"][beam_manager_type_key][platform_key][beam_manager_id_key]

            self.stage_optimization_summary += f"id : {motor_id}\n"
            if optimized:
                if self.stage_optimization_type == 0:   self.stage_optimization_summary += f"Search Range: {search_range}\n"
                else:                                   self.stage_optimization_summary += f"Search Range: from transfer learning\n"
                if   self.stage_optimization_type == 1: self.stage_optimization_summary += f"Search Transfer Range: from warm start strategy\n"
                elif self.stage_optimization_type == 2: self.stage_optimization_summary += f"Search Transfer Range: {search_transfer_range}\n"
                if self.stage_optimization_type == 0:   self.stage_optimization_summary += f"Initial Position: {initial_position}\n"
                else:                                   self.stage_optimization_summary += f"Initial Position: last best trial \n"
                self.stage_optimization_summary += "---------------------------------------------\n"

        self.stage_optimization_summary += ("\n---------------------------------------------\n" +
                                            "Hypervolume targets and reference points:\n" +
                                            "---------------------------------------------\n")
        objectives = self._beam_manager_configuration[beam_manager_type_key]["defaults"][platform_key][beam_manager_id_key]["objectives"]
        for optimization_criterion in objectives.keys():
            if self.stage_optimization_type == 0: self.stage_optimization_summary += f"{optimization_criterion}: {objectives[optimization_criterion][0]}, {objectives[optimization_criterion][1]}\n"
            else:                                 self.stage_optimization_summary += f"{optimization_criterion}: {objectives[optimization_criterion][0]}, from transfer learning\n"

        self._summary_text_area.clear()
        self._summary_text_area.setFont(QFont('Courier New', 9))
        self._summary_text_area.setText(self.stage_optimization_summary)

        self.__is_loading_stage = False

    def _set_stage_optimizer_type(self):
        self._stage_mobo_optimizers_box_1.setVisible(self.stage_optimizer_type == 0)
        self._stage_sonl_optimizers_box_1.setVisible(self.stage_optimizer_type == 1)
        self._stage_sobo_optimizers_box_1.setVisible(self.stage_optimizer_type == 2)
        self._stage_mobo_optimizers_box_2.setVisible(self.stage_optimizer_type == 0)
        self._stage_mobo_optimizers_box_3.setVisible(self.stage_optimizer_type == 0)
        self._stage_sonl_optimizers_box_2.setVisible(self.stage_optimizer_type == 1)
        self._stage_sobo_optimizers_box_2.setVisible(self.stage_optimizer_type == 2)

        self._set_stage_optimizer_name()

    def _set_stage_optimizer_name(self):
        if self.stage_optimizer_type == 0:
            self._stage_mobo_optimizers_box_2.setVisible(False)
            self._stage_mobo_optimizers_box_3.setVisible(False)

            if self.stage_optimizer_name_mobo in [0, 1]: # AX, Optuna
                self._stage_mobo_optimizers_box_2.setVisible(True)
                self.cb_stage_acquisition_function_mobo_1.clear()
                self.cb_stage_acquisition_function_mobo_1.addItems(self.get_acquisition_functions_mobo_combo_items())
                self.cb_stage_acquisition_function_mobo_1.setCurrentIndex(self.stage_acquisition_function_mobo)

                if self.stage_optimizer_name_mobo == 0: # Ax
                    self.cb_stage_surrogate_mobo_1.clear()
                    self.cb_stage_surrogate_mobo_1.addItems(self.get_surrogate_mobo_combo_items())
                    self.cb_stage_surrogate_mobo_1.setCurrentIndex(self.stage_surrogate_mobo)
                    self.cb_stage_surrogate_action_mobo_1.clear()
                    self.cb_stage_surrogate_action_mobo_1.addItems(self.get_surrogate_action_mobo_combo_items())
                    self.cb_stage_surrogate_action_mobo_1.setCurrentIndex(self.stage_surrogate_action_mobo)

                self._set_stage_use_hypervolume_exit()
            else:
                self._stage_mobo_optimizers_box_3.setVisible(True)
                self.cb_stage_acquisition_function_mobo_2.clear()
                self.cb_stage_acquisition_function_mobo_2.addItems(self.get_acquisition_functions_mobo_combo_items())
                self.cb_stage_acquisition_function_mobo_2.setCurrentIndex(self.stage_acquisition_function_mobo)
        elif self.stage_optimizer_type == 2:
            self._stage_sobo_optimizers_box_2.setVisible(True)

            self.cb_stage_acquisition_function_sobo.clear()
            self.cb_stage_acquisition_function_sobo.addItems(self.get_acquisition_functions_sobo_combo_items())
            self.cb_stage_acquisition_function_sobo.setCurrentIndex(self.acquisition_function_sobo)

        if not (self.__is_init or self.__is_loading_stage): self._save_values()

    def _set_stage_use_hypervolume_exit(self):
        self.le_stage_hypervolume_exit_convergence_threshold.setEnabled(self.stage_use_hypervolume_exit==1)
        self.le_stage_hypervolume_exit_patience.setEnabled(self.stage_use_hypervolume_exit==1)

    def _set_stage_optimization_type(self):
        if self.stage_optimization_type == 0: # FS
            self._stage_full_start_box.setVisible(True)
            self._stage_warm_start_sd_box.setVisible(False)
            self._stage_warm_start_dd_box.setVisible(False)
            self.cb_stage_erase_warm_start_data_fs.setCurrentIndex(self.stage_erase_warm_start_data)
            self.cb_stage_save_warm_start_data_fs.setCurrentIndex(self.stage_save_warm_start_data)
            self.le_stage_sobol_iterations_mobo_1.setEnabled(True)
            self.le_stage_sobol_iterations_mobo_2.setEnabled(True)
        elif self.stage_optimization_type == 1: # WS SD
            self._stage_full_start_box.setVisible(False)
            self._stage_warm_start_sd_box.setVisible(True)
            self._stage_warm_start_dd_box.setVisible(False)
            self.stage_erase_warm_start_data = 0
            self.stage_save_warm_start_data  = 0
            self.le_stage_sobol_iterations_mobo_1.setEnabled(False)
            self.le_stage_sobol_iterations_mobo_2.setEnabled(False)
            self.cb_stage_warm_start_strategy.setCurrentIndex(self.stage_warm_start_strategy)

            self._set_stage_warm_start_strategy()
        elif self.stage_optimization_type == 2: # WS DD
            self._stage_full_start_box.setVisible(False)
            self._stage_warm_start_sd_box.setVisible(False)
            self._stage_warm_start_dd_box.setVisible(True)
            self.cb_stage_erase_warm_start_data_wsdd.setCurrentIndex(self.stage_erase_warm_start_data)
            self.cb_stage_save_warm_start_data_wsdd.setCurrentIndex(self.stage_save_warm_start_data)
            self.le_stage_sobol_iterations_mobo_1.setEnabled(True)
            self.le_stage_sobol_iterations_mobo_2.setEnabled(True)

        if not (self.__is_init or self.__is_loading_stage): self._save_values()

    def _set_stage_warm_start_strategy(self):
        self.le_stage_warm_start_search_space_expansion_factor.setEnabled(self.stage_warm_start_strategy==1)

        warm_start_expansion_factors = self._stage_warm_start_expansion_factors[self._warm_start_strategies[self.stage_warm_start_strategy]]

        self.stage_warm_start_search_space_expansion_factor = warm_start_expansion_factors[0]
        self.stage_warm_start_loss_expansion_factor         = warm_start_expansion_factors[1]

        self.le_stage_warm_start_search_space_expansion_factor.setText(str(self.stage_warm_start_search_space_expansion_factor))
        self.le_stage_warm_start_loss_expansion_factor.setText(str(self.stage_warm_start_loss_expansion_factor))

        if not (self.__is_init or self.__is_loading_stage): self._save_values()

    def _set_current_plan(self):
        plan_platform = self._plans_platforms[self.plans_platform]

        self._plan_ids[plan_platform]          = self.plan_id # new plan to display

        self._current_stage.beam_manager_type = self.stage_beam_manager_type # previous stage to be updates
        self._current_stage.beam_manager_id   = self.stage_beam_manager_id
        self._current_stage.ai_type           = self.stage_ai_type

        ai_configuration = {}
        ai_configuration["optimizer_type"] = self.stage_optimizer_type

        if self.stage_optimizer_type == 0:
            ai_configuration["name"]                 = self.stage_optimizer_name_mobo
            ai_configuration["acquisition_function"] = self.stage_acquisition_function_mobo
            ai_configuration["surrogate"]            = self.stage_surrogate_mobo
            ai_configuration["surrogate_action"]     = self.stage_surrogate_action_mobo
            ai_configuration["sobol_iterations"]     = self.stage_sobol_iterations_mobo
            ai_configuration["mobo_iterations"]      = self.stage_mobo_iterations

            if self.stage_optimizer_name_mobo in [0, 1]:
                ai_configuration["pareto_selection"]     = self.stage_pareto_selection
                ai_configuration["use_hypervolume_exit"] = self.stage_use_hypervolume_exit == 1
                ai_configuration["hypervolume_exit"] = {}
                ai_configuration["hypervolume_exit"]["convergence_threshold"] = self.stage_hypervolume_exit_convergence_threshold
                ai_configuration["hypervolume_exit"]["patience"]              = self.stage_hypervolume_exit_patience
        elif self.stage_optimizer_type == 1:
            ai_configuration["name"]           = self.stage_optimizer_name_sonl
            ai_configuration["max_iterations"] = self.stage_max_iterations

        elif self.stage_optimizer_type == 2:
            ai_configuration["name"]             = self.stage_optimizer_name_sobo
            ai_configuration["sobol_iterations"] = self.stage_sobol_iterations_sobo
            ai_configuration["sobo_iterations"]  = self.stage_sobo_iterations

        ai_configuration["optimization_type"]         = self.stage_optimization_type
        ai_configuration["erase_warm_start_data"]     = self.stage_erase_warm_start_data == 1
        ai_configuration["save_warm_start_data"]      = self.stage_save_warm_start_data == 1
        if self.stage_optimization_type == 1:
            warm_start_expansion_factors    = self._stage_warm_start_expansion_factors[self._warm_start_strategies[self.stage_warm_start_strategy]]
            warm_start_expansion_factors[0] = self.stage_warm_start_search_space_expansion_factor
            warm_start_expansion_factors[1] = self.stage_warm_start_loss_expansion_factor

            ai_configuration["warm_start_strategy"]          = self.stage_warm_start_strategy
            ai_configuration["warm_start_expansion_factors"] = self._stage_warm_start_expansion_factors

        ai_configuration["move_motors_on_best_trial"] = self.stage_move_motors_on_best_trial == 1
        
        self._current_stage.ai_configuration      = ai_configuration
        self._current_stage.requires_pause_at_end = self.stage_requires_pause_at_end == 1

    # -------------------------------------------------------------

    def _save_configuration_callback(self, **kwargs):
        try:
            if ConfirmDialog.confirmed(self,
                                       title="Save Configuration",
                                       message="Do you confirm saving this configuration?"):

                self._collect_configuration_parameters()
                self._save_configuration(configuration=self._configuration, **{"motors_info" : self._motors_info})
        except ValueError as error:
            MessageDialog.message(self, title="Input Error", message=error.args[0], type="critical", width=500)
            if IS_DEBUG: raise error
        except Exception as exception:
            MessageDialog.message(self, title="Unexpected Exception", message=exception.args[0], type="critical", width=700)
            if IS_DEBUG: raise exception

    def _close_callback(self):
        if ConfirmDialog.confirmed(self, "Confirm Exit?\n(Modifications not saved will be lost)"):
            self._close()
