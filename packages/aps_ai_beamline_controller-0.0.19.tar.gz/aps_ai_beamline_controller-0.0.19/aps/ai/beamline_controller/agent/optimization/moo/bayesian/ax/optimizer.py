#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import traceback
import os

import numpy as np
from time import time

from aps.ai.beamline_controller.agent.optimization.common.bayesian.facade import BayesianOptimizationResult
from botorch.models import ModelList
from torch.nn import ModuleList
from ax.analysis import UtilityProgressionAnalysis
from ax.api.client import Client
from ax.core import ChoiceParameter

from aps.ai.beamline_controller.agent.optimization.common.bayesian.ax.ax_optimizer_decorator import AxOptimizerDecorator
from aps.beamline_driver.beam_management.facade import IBeamManager
from aps.beamline_driver.motion_management.facade import IMotionManager, MotorsInfo
from aps.ai.beamline_controller.agent.facade import IAgentListener
from aps.ai.beamline_controller.agent.optimization.facade import OptimizationDirection, OptimizationCriteria, OptimizationInitParameters, WarmStartDataType, OptimizationType

from aps.ai.beamline_controller.agent.optimization.moo.bayesian.facade import MOBOBayesianOptimizationResult, MOBOBayesianOptimizationExecutionParameters, MOBOBayesianOptimizationResultItem
from aps.ai.beamline_controller.agent.optimization.moo.bayesian.abstract_optimizer import MOBOAbstractBayesianOptimizer
from aps.ai.beamline_controller.agent.optimization.moo.bayesian.ax.hypervolume_manager import to_ax_objective_name



class AxOptimizer(MOBOAbstractBayesianOptimizer, AxOptimizerDecorator):
    def __init__(self, optimization_listener : IAgentListener, **kwargs):
        super(AxOptimizer, self).__init__(optimization_listener, **kwargs)

    def initialize_driver(self,
                          beam_manager : IBeamManager,
                          motion_manager : IMotionManager):
        super(AxOptimizer, self).initialize_driver(beam_manager, motion_manager)

        if self.requires_run_engine(): setattr(self, "_run_optimization", self.__run_optimization_generator)
        else:                          setattr(self, "_run_optimization", self.__run_optimization)

    # ------------------------------------------------------------------------------
    #  AbstractBayesianOptimizer implementation
    # ------------------------------------------------------------------------------

    def _create_optimization_agent(self, **kwargs):
        return self._create_optimization_agent_decorator(**kwargs)

    def _create_objectives(self,
                           execution_parameters: MOBOBayesianOptimizationExecutionParameters,
                           motor_ids_to_optimize: list[str],
                           optimization_criteria: OptimizationCriteria,
                           optimization_parameters: OptimizationInitParameters,
                           search_ranges: dict[str, list]) -> tuple[str, list[float]]:
        objective_parts = []
        threshold_constraints = []
        hypervolume_thresholds = {}  # kept separately for display / message logging
        hypervolume_reference_points = optimization_parameters.get_parameter("hypervolume_reference_points")

        for optimization_criterion in optimization_criteria.names:
            optimization_direction = optimization_parameters.get_parameter("optimization_directions")[optimization_criterion]

            if execution_parameters.optimization_type == OptimizationType.WARM_START_SAME_DETECTOR and execution_parameters.use_warm_start_hypervolume_reference_points:
                warm_start_hypervolume_reference_points = self._warm_start_data.get_warm_start_hypervolume_reference_points()
                hypervolume_reference_point = warm_start_hypervolume_reference_points.get(optimization_criterion,
                                                                                          optimization_parameters.get_parameter("hypervolume_reference_points")[optimization_criterion])
            else:
                hypervolume_reference_point = hypervolume_reference_points[optimization_criterion]

            ax_optimization_criterion = to_ax_objective_name(optimization_criterion)

            is_minimize = optimization_direction == OptimizationDirection.MINIMIZE
            # In the new Client API: prefix "-" means minimize, no prefix means maximize
            objective_parts.append(f"-{ax_optimization_criterion}" if is_minimize else ax_optimization_criterion)
            # Thresholds become outcome constraints: <= for minimize, >= for maximize
            op = "<=" if is_minimize else ">="
            threshold_constraints.append(f"{ax_optimization_criterion} {op} {hypervolume_reference_point}")

            hypervolume_thresholds[optimization_criterion] = hypervolume_reference_point

        objective_string = ", ".join(objective_parts)

        message = ["**************************************************"]
        if execution_parameters.optimization_type == OptimizationType.WARM_START_SAME_DETECTOR:
            message.append("Surrogate Model pre-fit: True (attached " + str(self._warm_start_data.get_number_of_items()) + " trials)")
        else:
            message.append("Surrogate Model pre-fit: False")
        message.append("Search Space:")
        message.extend([" - " + motor_id + ":" + str(search_ranges[motor_id]) for motor_id in motor_ids_to_optimize])
        message.append("Hypervolume reference points: ")
        message.extend([" - " + optimization_criterion + ": " + str(hypervolume_thresholds[optimization_criterion]) for optimization_criterion in hypervolume_thresholds.keys()])
        message.append("**************************************************")

        self._optimization_listener.feedback(None, None, None, None, None, message=message)

        return objective_string, threshold_constraints

    # ------------------------------------------------------------------------------

    def __run_optimization(self, **kwargs) -> (int, dict):
        ax_client                 = self._optimization_agent
        execution_parameters      = self._execution_parameters
        input_parameters          = self._input_parameters
        optimization_parameters   = self._optimization_parameters
        optimization_directions   = optimization_parameters.get_parameter("optimization_directions")
        current_timestamps        = {}
        current_raw_data          = {}
        exit_strategy_fulfilled   = False
        current_node_name         = None

        self._hypervolumes           = []
        self.__no_improvement_trials = 0

        new_model_index, trials_to_execute = self.__manage_transfer_learning_initialization(execution_parameters, input_parameters)

        is_first_trial = True
        for i in range(trials_to_execute):
            if self.interrupt or exit_strategy_fulfilled: break

            suggested_motor_positions, trial_index, current_node_name = self.__get_suggested_motor_positions(ax_client=ax_client,
                                                                                                             current_node_name=current_node_name,
                                                                                                             current_timestamps=current_timestamps)
            loss_function, error_message                                      = self.__evaluate_suggested_motor_positions(suggested_motor_positions=suggested_motor_positions,
                                                                                                                          trial_index=trial_index,
                                                                                                                          current_raw_data=current_raw_data,
                                                                                                                          is_first_trial=is_first_trial)

            exit_strategy_fulfilled, trials_to_execute                        = self.__process_and_complete_trial(ax_client=ax_client,
                                                                                                                  error_message=error_message,
                                                                                                                  execution_parameters=execution_parameters,
                                                                                                                  exit_strategy_fulfilled=exit_strategy_fulfilled,
                                                                                                                  loss_function=loss_function,
                                                                                                                  optimization_directions=optimization_directions,
                                                                                                                  trial_index=trial_index,
                                                                                                                  trials_to_execute=trials_to_execute)
            is_first_trial = False

        if execution_parameters.optimization_type == OptimizationType.WARM_START_SAME_DETECTOR: return trials_to_execute + new_model_index, current_timestamps, current_raw_data
        else:                                                                                   return trials_to_execute,                   current_timestamps, current_raw_data

    def __run_optimization_generator(self, **kwargs) -> (int, dict):
        ax_client               = self._optimization_agent
        execution_parameters    = self._execution_parameters
        input_parameters        = self._input_parameters
        optimization_parameters = self._optimization_parameters
        optimization_directions = optimization_parameters.get_parameter("optimization_directions")
        current_timestamps      = {}
        current_raw_data        = {}
        exit_strategy_fulfilled = False
        current_node_name       = None

        self._hypervolumes          = []
        self.__no_improvement_trials = 0

        new_model_index, trials_to_execute = self.__manage_transfer_learning_initialization(execution_parameters, input_parameters)

        is_first_trial = True
        for i in range(trials_to_execute):
            if self.interrupt or exit_strategy_fulfilled: break

            suggested_motor_positions, trial_index, current_node_name = self.__get_suggested_motor_positions(ax_client=ax_client,
                                                                                                             current_node_name=current_node_name,
                                                                                                             current_timestamps=current_timestamps)
            loss_function, error_message                                      = yield from self.__evaluate_suggested_motor_positions_generator(suggested_motor_positions=suggested_motor_positions,
                                                                                                                                               trial_index=trial_index,
                                                                                                                                               current_raw_data=current_raw_data,
                                                                                                                                               is_first_trial=is_first_trial)
            exit_strategy_fulfilled, trials_to_execute                        = self.__process_and_complete_trial(ax_client=ax_client,
                                                                                                                  error_message=error_message,
                                                                                                                  execution_parameters=execution_parameters,
                                                                                                                  exit_strategy_fulfilled=exit_strategy_fulfilled,
                                                                                                                  loss_function=loss_function,
                                                                                                                  optimization_directions=optimization_directions,
                                                                                                                  trial_index=trial_index,
                                                                                                                  trials_to_execute=trials_to_execute)
            is_first_trial = False

        if execution_parameters.optimization_type == OptimizationType.WARM_START_SAME_DETECTOR: return trials_to_execute + new_model_index, current_timestamps, current_raw_data
        else:                                                                                   return trials_to_execute,                   current_timestamps, current_raw_data


    def _bo_optimize_end(self, **kwargs) -> BayesianOptimizationResult:
        optimization_result: MOBOBayesianOptimizationResult = super(AxOptimizer, self)._bo_optimize_end(**kwargs)

        if len(self._hypervolumes) > 0:
            for trial_number, hypervolume in self._hypervolumes:
               item: MOBOBayesianOptimizationResultItem =  optimization_result.get_optimization_item(trial_number)
               item.hypervolume = hypervolume

        return optimization_result

    # ------------------------------------------------------------------------------
    #  OBJECTIVE FUNCTION METHODS
    # ------------------------------------------------------------------------------

    def __manage_transfer_learning_initialization(self, execution_parameters, input_parameters):
        return self._manage_transfer_learning_initialization_decorator(execution_parameters, input_parameters)

    def __get_suggested_motor_positions(self, ax_client: Client, current_node_name, current_timestamps):
        return self._get_suggested_motor_positions_decorator(ax_client, current_node_name ,current_timestamps)

    def __manage_error(self, trial_index, optimization_criteria, motor_ids_to_optimize, suggested_motor_positions, current_motors_positions):
        return self._manager_error_decorator(trial_index,
                                             optimization_criteria,
                                             motor_ids_to_optimize,
                                             suggested_motor_positions,
                                             current_motors_positions)

    def __evaluate_suggested_motor_positions(self, suggested_motor_positions, trial_index, current_raw_data, is_first_trial):
        return self._evaluate_suggested_motor_positions_decorator(suggested_motor_positions, trial_index, current_raw_data, is_first_trial)

    def __evaluate_suggested_motor_positions_generator(self, suggested_motor_positions, trial_index, current_raw_data, is_first_trial):
        ret = yield from self._evaluate_suggested_motor_positions_generator_decorator(suggested_motor_positions,trial_index, current_raw_data, is_first_trial)
        return ret

    def __compute_pareto_hypervolume(self, ax_client: Client, trial_index):
        if ax_client._generation_strategy.current_node_name in ["Sobol", "CenterOfSearchSpace"]:
            self._sobol_last_index = trial_index
            hypervolume = 0.0
        else:
            try:
                hypervolume = self._hypervolume_manager.compute_pareto_hypervolume(optimization_agent=ax_client)
            except:
                traceback.print_exc()
                hypervolume = np.nan

        return [trial_index, hypervolume]

    def __process_and_complete_trial(self, ax_client: Client, error_message, execution_parameters, exit_strategy_fulfilled, loss_function, optimization_directions, trial_index, trials_to_execute):
        if error_message is None:
            ax_client.complete_trial(trial_index=trial_index, raw_data={to_ax_objective_name(oc) : loss_function[oc] for oc in loss_function})

            self._hypervolumes.append(self.__compute_pareto_hypervolume(ax_client, trial_index))
            if execution_parameters.optimization_type == OptimizationType.WARM_START_SAME_DETECTOR and not hasattr(self, "_sobol_last_index"): self._sobol_last_index = trial_index - 1

            message = f"\n\u2192 Hypervolume: {self._hypervolumes[-1][1]}"

            if trial_index > self._sobol_last_index + 1:
                if self._hypervolumes[-1][1] == 0.0: self.__no_improvement_trials = 0
                else:
                    variation = (self._hypervolumes[-1][1] - self._hypervolumes[-2][1]) / self._hypervolumes[-1][1]
                    if execution_parameters.use_hypervolume_exit:
                        if abs(variation) < execution_parameters.convergence_threshold: self.__no_improvement_trials += 1
                        else:                                                           self.__no_improvement_trials = 0
                    message += f" \u2192 \u0394: {round(100 * variation, 2)}%"

            if execution_parameters.use_hypervolume_exit:
                exit_strategy_fulfilled = self.__no_improvement_trials >= execution_parameters.patience
                if exit_strategy_fulfilled: message += f"\n\u2192 EXIT STRATEGY FULLFILLED: no hypervolume improvement for more than {execution_parameters.patience} trials"

            if not exit_strategy_fulfilled and execution_parameters.use_exit_strategy:
                exit_strategy_fulfilled = True
                for optimization_criterion in execution_parameters.exit_loss_function.keys():
                    if optimization_directions[optimization_criterion] == OptimizationDirection.MINIMIZE:
                        if loss_function[optimization_criterion] > execution_parameters.exit_loss_function[optimization_criterion]:
                            exit_strategy_fulfilled = False
                            break
                    elif optimization_directions[optimization_criterion] == OptimizationDirection.MAXIMIZE:
                        if loss_function[optimization_criterion] < execution_parameters.exit_loss_function[optimization_criterion]:
                            exit_strategy_fulfilled = False
                            break
                if exit_strategy_fulfilled: message += "\u2192 EXIT STRATEGY FULLFILLED: all objectives under exit threshold"

            if execution_parameters.use_hypervolume_exit or execution_parameters.use_exit_strategy:
                if exit_strategy_fulfilled: trials_to_execute = trial_index + 1

            if not ax_client._generation_strategy.current_node_name in ["Sobol", "CenterOfSearchSpace"]:
                self._optimization_listener.feedback(None, None, None, None, None, message=message)
        else:
            self._optimization_listener.feedback(trial_index, None, None, None, None, message=error_message)
            ax_client.mark_trial_failed(trial_index=trial_index, failed_reason=error_message)

        return exit_strategy_fulfilled, trials_to_execute

    # ---------------------------------------------------------------------
    # WARM-START
    # ---------------------------------------------------------------------

    @classmethod
    def _get_pareto_file_prefix(cls) -> str: return "ax_mobo_experiment"

    @classmethod
    def _get_ml_file_prefix(cls) -> str: return cls._get_pareto_file_prefix()

    def _attach_warm_start_data(self, **kwargs):
        execution_parameter: MOBOBayesianOptimizationExecutionParameters = self._execution_parameters
        ax_client: Client = self._optimization_agent

        if execution_parameter.warm_start_data_type == WarmStartDataType.PRETRAINED_MODEL:
            raise NotImplementedError("Pretrained models are not supported, yet")
        else:
            warm_start_data: MOBOBayesianOptimizationResult = self._warm_start_data
            parameters_list = list(ax_client._experiment.search_space.parameters.values())

            for warm_start_item in warm_start_data.get_optimization_items():
                motor_positions = warm_start_item.motor_positions

                for parameter in parameters_list:
                    if isinstance(parameter, ChoiceParameter):
                        motor_id                  = parameter.name
                        motor_allowed_positions   = np.array(parameter.values)
                        motor_position            = motor_allowed_positions[np.argmin(np.absolute(motor_allowed_positions - motor_positions[motor_id]))]
                        motor_positions[motor_id] = motor_position

                try:
                    warm_start_loss_function = warm_start_item.loss_function

                    ax_client.attach_trial(parameters=motor_positions)
                    ax_client.complete_trial(trial_index=warm_start_item.trial_number,
                                             raw_data={to_ax_objective_name(oc) : warm_start_loss_function[oc] for oc in warm_start_loss_function})
                except Exception as e:
                    print(f"Trial not attached: {e}")

            print(f'****** All {warm_start_data.get_number_of_items()} prior trials are completed ******')
            print(f'****************************************************************************************************')

    # -----------------------------------------------------------------------
    # DKL
    # -----------------------------------------------------------------------

    # ------------------------------------------------------------------------------
    #  SAVE TO FILE AND PLOTS
    # ------------------------------------------------------------------------------

    @classmethod
    def _get_result_file_prefix(cls) -> str: return cls._get_pareto_file_prefix()


