#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
from typing import List
import numpy as np

from aps.beamline_driver.motion_management.facade import MotorsInfo
from aps.common.initializer import IniFacade

class AutoAlignmentStage(object):
    def __init__(self,
                 stage_id: str,
                 stage_name: str,
                 beam_manager_type,
                 beam_manager_id,
                 ai_type: int,
                 ai_configuration: dict,
                 requires_pause_at_end=False):
        self.__stage_id = stage_id
        self.__stage_name = stage_name
        self.__beam_manager_type = beam_manager_type
        self.__beam_manager_id = beam_manager_id
        self.__ai_type = ai_type
        self.__ai_configuration = ai_configuration
        self.__requires_pause_at_end = requires_pause_at_end

    @property
    def stage_id(self) -> str:  return self.__stage_id
    @property
    def stage_name(self) -> str: return self.__stage_name
    @property
    def beam_manager_type(self) -> int:  return self.__beam_manager_type
    @property
    def beam_manager_id(self) -> int:  return self.__beam_manager_id
    @property
    def ai_type(self) -> int: return self.__ai_type
    @property
    def ai_configuration(self) -> dict:  return self.__ai_configuration
    @property
    def requires_pause_at_end(self) -> bool: return self.__requires_pause_at_end

    @stage_id.setter
    def stage_id(self, stage_id: str): self.__stage_id = stage_id
    @stage_name.setter
    def stage_name(self, stage_name: str): self.__stage_name = stage_name
    @beam_manager_type.setter
    def beam_manager_type(self, beam_manager_type: int):self.__beam_manager_type = beam_manager_type
    @beam_manager_id.setter
    def beam_manager_id(self, beam_manager_id: int):self.__beam_manager_id = beam_manager_id
    @ai_type.setter
    def ai_type(self, ai_type: int):self.__ai_type = ai_type
    @ai_configuration.setter
    def ai_configuration(self, ai_configuration: dict): self.__ai_configuration = ai_configuration
    @requires_pause_at_end.setter
    def requires_pause_at_end(self, requires_pause_at_end: bool): self.__requires_pause_at_end = requires_pause_at_end

    def to_dict(self) -> dict:
        return {
            "stage_name"  : self.stage_name,
            "beam_manager_type" : self.beam_manager_type,
            "beam_manager_id" : self.beam_manager_id,
            "ai_type" : self.ai_type,
            "ai_configuration" : self.ai_configuration,
            "requires_pause_at_end" : self.requires_pause_at_end
        }

class AutoAlignmentPlan(object):
    def __init__(self,
                 plan_id: str,
                 plan_name: str,
                 platform: str,
                 stages: List[AutoAlignmentStage]):
        self.__plan_id = plan_id
        self.__plan_name = plan_name
        self.__platform = platform
        self.__stages = stages
        self.__stages_dict = {stage.stage_id  : stage for stage in self.stages}

    @property
    def plan_id(self): return self.__plan_id
    @property
    def plan_name(self): return self.__plan_name
    @property
    def platform(self): return self.__platform
    @property
    def stages(self) -> List[AutoAlignmentStage]: return self.__stages

    def get_stages_id(self) -> list: return [stage.stage_id for stage in self.stages]
    def get_stages_names(self) -> list: return [stage.stage_name for stage in self.stages]
    def get_stage(self, stage_id: str) -> AutoAlignmentStage: return self.__stages_dict[stage_id]
    def is_last_stage(self, stage_id: str) -> bool: return self.stages[-1].stage_id == stage_id

    def to_dict(self) -> dict:
        return {"plan_name" : self.plan_name,
                "stages" : {stage.stage_id  : stage.to_dict() for stage in self.stages}}

class GUIConfiguration(object):
    def __init__(self, configuration: dict):
        self.__alignment_configuration     = configuration["alignment"]
        self.__configuration_configuration = configuration["configuration"]
        self.__results_configuration       = configuration["results"]

    @property
    def alignment_configuration(self) -> dict: return self.__alignment_configuration
    @property
    def configuration_configuration(self) -> dict: return self.__configuration_configuration
    @property
    def results_configuration(self) -> dict: return self.__results_configuration

    def to_dict(self) -> dict:
        return {"alignment" : self.__alignment_configuration,
                "configuration" : self.__configuration_configuration,
                "results" : self.__results_configuration}

class DriverConfiguration(object):
    def __init__(self, configuration: dict):
        self.__platforms                    = configuration["platforms"]
        self.__platforms_combo              = configuration["platforms_combo"]
        self.__beam_manager_types           = configuration["beam_manager_types"]
        self.__beam_manager_types_combo     = configuration["beam_manager_types_combo"]
        self.__beam_manager_configuration   = configuration["beam_manager"]
        self.__motion_manager_configuration = configuration["motion_manager"]

    @property
    def platforms(self): return self.__platforms
    @property
    def platforms_combo(self): return self.__platforms_combo
    @property
    def beam_manager_types(self): return self.__beam_manager_types
    @property
    def beam_manager_types_combo(self): return self.__beam_manager_types_combo
    @property
    def beam_manager_configuration(self): return self.__beam_manager_configuration
    @property
    def motion_manager_configuration(self): return self.__motion_manager_configuration

    def to_dict(self) -> dict:
        return {"platforms" : self.platforms,
                "platforms_combo" : self.platforms_combo,
                "beam_manager_types" : self.beam_manager_types,
                "beam_manager_types_combo" : self.beam_manager_types_combo,
                "beam_manager" : self.beam_manager_configuration,
                "motion_manager" : self.motion_manager_configuration}

    def get_motor_ids_to_optimize(self, beam_manager_type, platform, beam_manager_id):
        motor_ids_to_optimize = []
        configuration = self.motion_manager_configuration["defaults"]

        for motor_id in list(configuration.keys()):
            motor_configuration = configuration[motor_id]

            optimized = motor_configuration["optimized"][beam_manager_type][platform][beam_manager_id]
            if optimized == 1: motor_ids_to_optimize.append(motor_id)

        return motor_ids_to_optimize

    def get_motors_to_optimize(self, beam_manager_type, platform, beam_manager_id, motors_info : MotorsInfo):
        motor_to_optimize = {}
        configuration = self.motion_manager_configuration["defaults"]

        for motor_id in list(configuration.keys()):
            motor_configuration = configuration[motor_id]
            motor_info          = motors_info.get_motor_info(motor_id)

            optimized = motor_configuration["optimized"][beam_manager_type][platform][beam_manager_id]
            if optimized == 1:
                search_range = motor_configuration["search_range"][beam_manager_type][platform][beam_manager_id]

                motor_to_optimize[motor_id] = {"search_range" :          motor_configuration["search_range"][beam_manager_type][platform][beam_manager_id],
                                               "search_space" :          [round(item, motor_info.digits) for item in np.arange(start=search_range[0],
                                                                                                                               stop=search_range[1] + motor_info.resolution,
                                                                                                                               step=motor_info.resolution)],
                                               "search_transfer_range" : motor_configuration["search_range"][beam_manager_type][platform][beam_manager_id],
                                               "initial_position":       motor_configuration["initial_position"][beam_manager_type][platform][beam_manager_id]}

        return motor_to_optimize

class AIConfiguration(object):
    def __init__(self, configuration: dict):
        self.__ai_types = configuration["ai_types"]
        self.__ai_types_combo = configuration["ai_types_combo"]
        self.__neural_network_configuration = configuration["neural_network"]
        self.__optimization_configuration = configuration["optimization"]
        self.__initializer = configuration["initializer"]

    @property
    def ai_types(self): return self.__ai_types
    @property
    def ai_types_combo(self): return self.__ai_types_combo
    @property
    def neural_network_configuration(self): return self.__neural_network_configuration
    @property
    def optimization_configuration(self): return self.__optimization_configuration
    @property
    def initializer(self): return self.__initializer

    def to_dict(self) -> dict:
        return {"ai_types" : self.ai_types,
                "ai_types_combo" : self.ai_types_combo,
                "neural_network" : self.neural_network_configuration,
                "optimization" : self.optimization_configuration,
                "initializer": self.initializer}

class PlansConfiguration(object):
    def __init__(self, configuration: dict):
        self.__plans = {}

        for platform in configuration.keys():
            self.__plans[platform] = {}

            for plan_id in configuration[platform].keys():
                plan_configuration = configuration[platform][plan_id]

                plan_name = plan_configuration["plan_name"]

                stages = []
                for stage_id in plan_configuration["stages"]:
                    stage_configuration = plan_configuration["stages"][stage_id]

                    stage = AutoAlignmentStage(stage_id=stage_id,
                                               stage_name=stage_configuration["stage_name"],
                                               beam_manager_type=stage_configuration["beam_manager_type"],
                                               beam_manager_id=stage_configuration["beam_manager_id"],
                                               ai_type=stage_configuration["ai_type"],
                                               ai_configuration=stage_configuration["ai_configuration"],
                                               requires_pause_at_end=stage_configuration["requires_pause_at_end"])
                    stages.append(stage)

                self.__plans[platform][plan_id] = AutoAlignmentPlan(plan_id=plan_id,
                                                                    plan_name=plan_name,
                                                                    platform=platform,
                                                                    stages=stages)

    def get_plans(self) -> dict: return self.__plans
    def get_available_platforms(self) -> list: return list(self.__plans.keys())
    def get_plans_by_platform(self, platform) -> dict: return self.__plans[platform]
    def get_plan_ids_by_platform(self, platform) -> list: return list(self.__plans[platform].keys())
    def get_plan_names_by_platform(self, platform) -> list: return list(self.get_plan(platform, plan_id).plan_name for plan_id in self.get_plan_ids_by_platform(platform))
    def get_plan(self, platform, plan_id) -> AutoAlignmentPlan: return self.__plans[platform][plan_id]

    def to_dict(self) -> dict:
        platforms  = self.get_available_platforms()
        dictionary = {platform: {} for platform in platforms}
        for platform in platforms:
            dictionary[platform] = {plan_id : self.get_plan(platform, plan_id).to_dict() for plan_id in self.get_plan_ids_by_platform(platform)}
        return dictionary

class BeamlineControllerConfiguration(object):
    def __init__(self, ini: IniFacade, optical_system_id: str):
        self.__gui_configuration = GUIConfiguration(ini.get_dict_from_ini(section=optical_system_id, key="GUI"))
        self.__ai_configuration = AIConfiguration(ini.get_dict_from_ini(section=optical_system_id, key="AI"))
        self.__driver_configuration = DriverConfiguration(ini.get_dict_from_ini(section=optical_system_id, key="Driver"))
        self.__plans_configuration = PlansConfiguration(ini.get_dict_from_ini(section=optical_system_id, key="Plans"))
        self.__optical_system_id = optical_system_id
        self.__ini = ini

    @property
    def gui_configuration(self) -> GUIConfiguration: return self.__gui_configuration

    @property
    def ai_configuration(self): return self.__ai_configuration

    @property
    def driver_configuration(self): return self.__driver_configuration

    @property
    def plans_configuration(self): return self.__plans_configuration

    def to_ini(self):
        self.__ini.set_dict_at_ini(section=self.__optical_system_id, key="GUI",    values_dict=self.gui_configuration.to_dict())
        self.__ini.set_dict_at_ini(section=self.__optical_system_id, key="AI",     values_dict=self.ai_configuration.to_dict())
        self.__ini.set_dict_at_ini(section=self.__optical_system_id, key="Driver", values_dict=self.driver_configuration.to_dict())
        self.__ini.set_dict_at_ini(section=self.__optical_system_id, key="Plans",  values_dict=self.plans_configuration.to_dict())
        self.__ini.push(verbose=True, configuration="Beamline Controller configuration")

