from django.conf import settings
# from pymongo import MongoClient


# def get_database():
#     db_url = settings.MONGODB_LOGGER_URL
#     if db_url:
#         client = MongoClient(db_url)
#         database = settings.MONGODB_LOGGER_DATABASE
#         return client[database]
#     return None
