"""Tests for obabot library."""

