"""ONNX export functionality for spaCy transformers."""

from pathlib import Path
from typing import Any, Optional

import torch
import torch.nn as nn

from ..exceptions import ConversionError
from .._logging import get_logger
from .fp16_converter import convert_to_fp16
from .weight_mapper import create_hf_model, map_weights_to_hf


class ONNXWrapper(nn.Module):
    """
    Wrapper module for ONNX export.

    This wrapper ensures the model returns only the last hidden state,
    which is what spaCy's transformer component expects.
    """

    def __init__(self, model: nn.Module):
        super().__init__()
        self.model = model

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
    ) -> torch.Tensor:
        outputs = self.model(
            input_ids,
            attention_mask,
            output_hidden_states=True,
        )
        return outputs.hidden_states[-1]


def export_to_onnx(
    shim: Any,
    output_dir: Path,
    precision: str = "fp32",
    provider: str = "cuda",
    opset_version: int = 17,
    verbose: bool = False,
    fixed_batch_size: Optional[int] = None,
) -> Path:
    """
    Export spaCy transformer to ONNX format.

    This function:
    1. Maps spaCy curated transformer weights to HuggingFace format
    2. Creates a HuggingFace model with the mapped weights
    3. Exports to ONNX with fixed shapes for stability
    4. Optionally converts to FP16 precision

    Args:
        shim: The PyTorchShim from the spaCy transformer component.
        output_dir: Directory to save the ONNX model.
        precision: Model precision - "fp32" or "fp16".
        provider: Target execution provider for the exported model.
        opset_version: ONNX opset version (default: 17).
        verbose: Enable verbose logging.

    Returns:
        Path to the exported ONNX model.

    Raises:
        ConversionError: If export fails.
    """
    logger = get_logger(verbose)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    spacy_model = shim._model
    state_dict = spacy_model.state_dict()

    # Detect model architecture
    from ..core.discovery import get_model_info

    model_info = get_model_info(shim)
    architecture = model_info["architecture"]
    num_layers = model_info["num_layers"]
    hidden_size = model_info["hidden_size"]
    num_heads = model_info["num_heads"]

    logger.info(
        f"Detected architecture: {architecture}, "
        f"layers={num_layers}, hidden={hidden_size}, heads={num_heads}"
    )

    # Map weights to HuggingFace format
    logger.info("Mapping weights to HuggingFace format...")
    try:
        hf_state_dict = map_weights_to_hf(
            spacy_model,
            architecture=architecture,
            num_layers=num_layers,
            hidden_size=hidden_size,
        )
    except Exception as e:
        raise ConversionError(f"Weight mapping failed: {e}")

    # Create HuggingFace model
    logger.info("Creating HuggingFace model...")
    try:
        hf_model, config = create_hf_model(
            hf_state_dict,
            architecture=architecture,
            num_layers=num_layers,
            hidden_size=hidden_size,
            num_heads=num_heads,
        )
    except Exception as e:
        raise ConversionError(f"Model creation failed: {e}")

    # Verify parity (optional but recommended)
    logger.info("Verifying weight mapping parity...")
    try:
        _verify_parity(spacy_model, hf_model, logger)
    except Exception as e:
        logger.warning(f"Parity check failed: {e}. Proceeding anyway...")

    # Create wrapper for ONNX export
    wrapper = ONNXWrapper(hf_model).cpu()
    wrapper.eval()

    # Get max sequence length from model config for reference
    max_seq_len = getattr(config, "max_position_embeddings", 512)

    # Use a representative sequence length for dummy input (not max to reduce export time)
    dummy_seq_len = min(128, max_seq_len)
    logger.info(f"Using dummy sequence length: {dummy_seq_len} (max: {max_seq_len})")

    # Prepare dummy inputs
    # Use batch size 2 to prevent ONNX from inferring static batch size 1
    # This helps avoid shape mismatch errors like {1,seq} != {N,seq}
    if fixed_batch_size:
        batch_size = fixed_batch_size
        logger.info(f"Exporting with FIXED batch size: {batch_size}")
    else:
        batch_size = 2  # Default for dynamic export

    dummy_ids = torch.randint(0, 50000, (batch_size, dummy_seq_len), dtype=torch.long)
    dummy_mask = torch.ones_like(dummy_ids)

    # Export to ONNX
    onnx_path = output_dir / "model.onnx"
    logger.info(f"Exporting to ONNX: {onnx_path}")

    # Configure dynamic axes
    # We ALWAYS use dynamic batch (0) to ensure the model isn't pinned to batch 1
    # TensorRT optimization happens by passing the expected/optimal shape during session init
    dynamic_axes = {
        "input_ids": {0: "batch", 1: "seq"},
        "attention_mask": {0: "batch", 1: "seq"},
        "last_hidden_state": {0: "batch", 1: "seq"},
    }

    try:
        torch.onnx.export(
            wrapper,
            (dummy_ids, dummy_mask),
            str(onnx_path),
            input_names=["input_ids", "attention_mask"],
            output_names=["last_hidden_state"],
            # Allow dynamic dimensions based on configuration
            dynamic_axes=dynamic_axes,
            opset_version=opset_version,
            do_constant_folding=True,  # Standard practice, safe for fixed batch size
        )
    except Exception as e:
        raise ConversionError(f"ONNX export failed: {e}")

    logger.info("ONNX export complete")

    # Convert to FP16 if requested
    if precision == "fp16":
        fp16_path = output_dir / "model_fp16.onnx"
        logger.info(f"Converting to FP16: {fp16_path}")
        try:
            convert_to_fp16(
                str(onnx_path),
                str(fp16_path),
                num_heads=num_heads,
                hidden_size=hidden_size,
                provider=provider,
            )
            return fp16_path
        except Exception as e:
            raise ConversionError(f"FP16 conversion failed: {e}")

    return onnx_path


def _verify_parity(
    spacy_model: nn.Module,
    hf_model: nn.Module,
    logger: Any,
    tolerance: float = 1e-4,
) -> bool:
    """
    Verify that spaCy and HuggingFace models produce similar outputs.

    Args:
        spacy_model: Original spaCy PyTorch model.
        hf_model: HuggingFace model with mapped weights.
        logger: Logger instance.
        tolerance: Maximum allowed difference.

    Returns:
        True if parity check passes.

    Raises:
        ConversionError: If parity check fails.
    """
    device = "cuda" if torch.cuda.is_available() else "cpu"

    hf_model = hf_model.to(device).eval()
    spacy_model = spacy_model.to(device).eval()

    dummy_ids = torch.randint(0, 50000, (1, 16), dtype=torch.long, device=device)

    with torch.no_grad():
        # spaCy model expects int32 input
        out_spacy = spacy_model(dummy_ids.to(torch.int32))
        out_hf = hf_model(dummy_ids)

    # Extract hidden states from spaCy output
    spacy_hidden = None
    if hasattr(out_spacy, "layer_hidden_states") and out_spacy.layer_hidden_states:
        spacy_hidden = out_spacy.layer_hidden_states[-1]
    elif hasattr(out_spacy, "all_outputs") and out_spacy.all_outputs:
        spacy_hidden = out_spacy.all_outputs[-1]
    elif hasattr(out_spacy, "embedding_output"):
        spacy_hidden = out_spacy.embedding_output

    if spacy_hidden is None:
        logger.warning("Could not extract hidden states from spaCy output")
        return False

    hf_hidden = out_hf.last_hidden_state
    diff = (spacy_hidden - hf_hidden).abs().max().item()

    logger.info(f"Max difference between spaCy and HF: {diff:.6f}")

    if diff < tolerance:
        logger.info("Parity check passed")
        return True
    else:
        raise ConversionError(
            f"Parity check failed: max difference {diff:.6f} > tolerance {tolerance}"
        )
