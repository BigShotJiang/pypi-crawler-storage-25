"""Weight mapping from spaCy transformers to HuggingFace format."""

from typing import Any, Dict, Optional, Tuple

import torch
import torch.nn as nn

from ..exceptions import ConversionError


def map_curated_to_roberta(
    spacy_model: nn.Module,
    num_layers: int = 12,
    hidden_size: int = 768,
) -> Dict[str, torch.Tensor]:
    """
    Map weights from spaCy's curated transformer to HuggingFace RoBERTa format.

    The curated transformer in spaCy uses a different weight naming convention
    than HuggingFace models. This function creates a mapping from spaCy's format
    to HuggingFace's format.

    Args:
        spacy_model: The PyTorch model from spaCy's transformer.
        num_layers: Number of transformer layers.
        hidden_size: Hidden dimension size.

    Returns:
        Dictionary mapping HuggingFace weight names to tensors.

    Raises:
        ConversionError: If required weights are not found.
    """
    sp_sd = spacy_model.state_dict()
    new_sd: Dict[str, torch.Tensor] = {}

    try:
        # 1. Embeddings
        new_sd["embeddings.word_embeddings.weight"] = sp_sd[
            "curated_encoder.embeddings.inner.word_embeddings.weight"
        ]
        new_sd["embeddings.position_embeddings.weight"] = sp_sd[
            "curated_encoder.embeddings.inner.position_embeddings.weight"
        ]
        new_sd["embeddings.token_type_embeddings.weight"] = sp_sd[
            "curated_encoder.embeddings.inner.token_type_embeddings.weight"
        ]
        new_sd["embeddings.LayerNorm.weight"] = sp_sd[
            "curated_encoder.embeddings.inner.layer_norm.weight"
        ]
        new_sd["embeddings.LayerNorm.bias"] = sp_sd[
            "curated_encoder.embeddings.inner.layer_norm.bias"
        ]

        # 2. Encoder layers
        for i in range(num_layers):
            # Multi-Head Attention Input -> Q, K, V
            # spaCy combines Q, K, V into a single weight matrix
            mha_in_w = sp_sd[f"curated_encoder.layers.{i}.mha.input.weight"]
            mha_in_b = sp_sd[f"curated_encoder.layers.{i}.mha.input.bias"]

            # Split into Q, K, V
            q_w, k_w, v_w = torch.chunk(mha_in_w, 3, dim=0)
            q_b, k_b, v_b = torch.chunk(mha_in_b, 3, dim=0)

            new_sd[f"encoder.layer.{i}.attention.self.query.weight"] = q_w
            new_sd[f"encoder.layer.{i}.attention.self.query.bias"] = q_b
            new_sd[f"encoder.layer.{i}.attention.self.key.weight"] = k_w
            new_sd[f"encoder.layer.{i}.attention.self.key.bias"] = k_b
            new_sd[f"encoder.layer.{i}.attention.self.value.weight"] = v_w
            new_sd[f"encoder.layer.{i}.attention.self.value.bias"] = v_b

            # Multi-Head Attention Output
            new_sd[f"encoder.layer.{i}.attention.output.dense.weight"] = sp_sd[
                f"curated_encoder.layers.{i}.mha.output.weight"
            ]
            new_sd[f"encoder.layer.{i}.attention.output.dense.bias"] = sp_sd[
                f"curated_encoder.layers.{i}.mha.output.bias"
            ]
            new_sd[f"encoder.layer.{i}.attention.output.LayerNorm.weight"] = sp_sd[
                f"curated_encoder.layers.{i}.attn_output_layernorm.weight"
            ]
            new_sd[f"encoder.layer.{i}.attention.output.LayerNorm.bias"] = sp_sd[
                f"curated_encoder.layers.{i}.attn_output_layernorm.bias"
            ]

            # Feed-Forward Network
            new_sd[f"encoder.layer.{i}.intermediate.dense.weight"] = sp_sd[
                f"curated_encoder.layers.{i}.ffn.intermediate.weight"
            ]
            new_sd[f"encoder.layer.{i}.intermediate.dense.bias"] = sp_sd[
                f"curated_encoder.layers.{i}.ffn.intermediate.bias"
            ]
            new_sd[f"encoder.layer.{i}.output.dense.weight"] = sp_sd[
                f"curated_encoder.layers.{i}.ffn.output.weight"
            ]
            new_sd[f"encoder.layer.{i}.output.dense.bias"] = sp_sd[
                f"curated_encoder.layers.{i}.ffn.output.bias"
            ]
            new_sd[f"encoder.layer.{i}.output.LayerNorm.weight"] = sp_sd[
                f"curated_encoder.layers.{i}.ffn_output_layernorm.weight"
            ]
            new_sd[f"encoder.layer.{i}.output.LayerNorm.bias"] = sp_sd[
                f"curated_encoder.layers.{i}.ffn_output_layernorm.bias"
            ]

    except KeyError as e:
        raise ConversionError(
            f"Missing weight key during conversion: {e}. "
            "This model may not be a standard curated transformer."
        )

    return new_sd


def map_curated_to_bert(
    spacy_model: nn.Module,
    num_layers: int = 12,
    hidden_size: int = 768,
) -> Dict[str, torch.Tensor]:
    """
    Map weights from spaCy's curated transformer to HuggingFace BERT format.

    BERT and RoBERTa use the same architecture, so this is an alias for
    map_curated_to_roberta.
    """
    return map_curated_to_roberta(spacy_model, num_layers, hidden_size)


def map_curated_to_xlm_roberta(
    spacy_model: nn.Module,
    num_layers: int = 12,
    hidden_size: int = 768,
) -> Dict[str, torch.Tensor]:
    """
    Map weights from spaCy's curated transformer to HuggingFace XLM-RoBERTa format.

    XLM-RoBERTa uses the same architecture as RoBERTa.
    """
    return map_curated_to_roberta(spacy_model, num_layers, hidden_size)


def map_weights_to_hf(
    spacy_model: nn.Module,
    architecture: str,
    num_layers: int = 12,
    hidden_size: int = 768,
) -> Dict[str, torch.Tensor]:
    """
    Map weights from spaCy transformer to HuggingFace format.

    Args:
        spacy_model: The PyTorch model from spaCy's transformer.
        architecture: The target architecture (roberta, bert, xlm-roberta).
        num_layers: Number of transformer layers.
        hidden_size: Hidden dimension size.

    Returns:
        Dictionary mapping HuggingFace weight names to tensors.

    Raises:
        ConversionError: If the architecture is not supported.
    """
    mappers = {
        "curated_transformer": map_curated_to_roberta,
        "roberta": map_curated_to_roberta,
        "bert": map_curated_to_bert,
        "xlm-roberta": map_curated_to_xlm_roberta,
    }

    if architecture not in mappers:
        raise ConversionError(
            f"Unsupported architecture: {architecture}. "
            f"Supported: {', '.join(mappers.keys())}"
        )

    return mappers[architecture](spacy_model, num_layers, hidden_size)


def create_hf_model(
    state_dict: Dict[str, torch.Tensor],
    architecture: str,
    num_layers: int = 12,
    hidden_size: int = 768,
    num_heads: int = 12,
) -> Tuple[nn.Module, Any]:
    """
    Create a HuggingFace model and load the mapped weights.

    Args:
        state_dict: Mapped weight dictionary.
        architecture: The target architecture.
        num_layers: Number of transformer layers.
        hidden_size: Hidden dimension size.
        num_heads: Number of attention heads.

    Returns:
        Tuple of (model, config).

    Raises:
        ConversionError: If model creation fails.
    """
    try:
        from transformers import (
            BertConfig,
            BertModel,
            RobertaConfig,
            RobertaModel,
            XLMRobertaConfig,
            XLMRobertaModel,
        )
    except ImportError:
        raise ConversionError(
            "transformers library is required for model conversion. "
            "Install with: pip install transformers"
        )

    # Determine dimensions from embeddings in state_dict
    vocab_size = state_dict["embeddings.word_embeddings.weight"].shape[0]
    max_position_embeddings = state_dict["embeddings.position_embeddings.weight"].shape[
        0
    ]
    type_vocab_size = state_dict["embeddings.token_type_embeddings.weight"].shape[0]

    if architecture in ("roberta", "curated_transformer"):
        config = RobertaConfig(
            vocab_size=vocab_size,
            hidden_size=hidden_size,
            num_hidden_layers=num_layers,
            num_attention_heads=num_heads,
            intermediate_size=hidden_size * 4,
            max_position_embeddings=max_position_embeddings,
            type_vocab_size=type_vocab_size,
            output_hidden_states=True,
        )
        model = RobertaModel(config)
    elif architecture == "bert":
        config = BertConfig(
            vocab_size=vocab_size,
            hidden_size=hidden_size,
            num_hidden_layers=num_layers,
            num_attention_heads=num_heads,
            intermediate_size=hidden_size * 4,
            max_position_embeddings=max_position_embeddings,
            type_vocab_size=type_vocab_size,
            output_hidden_states=True,
        )
        model = BertModel(config)
    elif architecture == "xlm-roberta":
        config = XLMRobertaConfig(
            vocab_size=vocab_size,
            hidden_size=hidden_size,
            num_hidden_layers=num_layers,
            num_attention_heads=num_heads,
            intermediate_size=hidden_size * 4,
            max_position_embeddings=max_position_embeddings,
            type_vocab_size=type_vocab_size,
            output_hidden_states=True,
        )
        model = XLMRobertaModel(config)
    else:
        raise ConversionError(f"Unsupported architecture: {architecture}")

    # Load weights
    model.load_state_dict(state_dict, strict=False)
    model.eval()

    return model, config
