"""Conversion module for spacy-accelerate."""

from .exporter import export_to_onnx

__all__ = ["export_to_onnx"]
