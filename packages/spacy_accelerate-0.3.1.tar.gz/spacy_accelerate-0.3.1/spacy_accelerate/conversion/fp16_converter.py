"""FP16 conversion helpers for ONNX models."""

from typing import Literal

from ..exceptions import ConversionError


def convert_to_fp16(
    input_path: str,
    output_path: str,
    model_type: str = "bert",
    num_heads: int = 12,
    hidden_size: int = 768,
    provider: Literal["cuda", "tensorrt", "cpu"] = "cuda",
) -> None:
    """
    Convert ONNX model to FP16 precision.

    For CUDA we keep the transformer optimizer enabled. For TensorRT we use a
    more conservative path and avoid attention fusion, since the fused
    ``com.microsoft::Attention`` node can fail TensorRT session creation on a
    cold cache.

    The optimizer performs several optimizations:
    - Fuses multi-head attention
    - Fuses layer normalization
    - Fuses GELU activation
    - Converts compatible operations to FP16

    Args:
        input_path: Path to input ONNX model.
        output_path: Path to save optimized FP16 model.
        model_type: Model type for optimization ("bert", "gpt2", etc.).
        num_heads: Number of attention heads.
        hidden_size: Hidden dimension size.
        provider: Target execution provider for the exported model.

    Raises:
        ConversionError: If conversion fails.
    """
    try:
        from onnxruntime.transformers import optimizer
        from onnxruntime.transformers.fusion_options import FusionOptions
    except ImportError:
        raise ConversionError(
            "onnxruntime.transformers is required for FP16 conversion. "
            "Install with: pip install onnxruntime-gpu"
        )

    try:
        optimization_options = FusionOptions(model_type)
        optimization_options.enable_bias_gelu = False
        optimization_options.enable_shape_inference = True

        # TensorRT FP16 is sensitive to the fused com.microsoft::Attention node.
        # Keep the graph closer to standard ONNX so TensorRT EP can import it
        # reliably on a fresh cache.
        if provider == "tensorrt":
            optimization_options.enable_attention = False
            optimization_options.enable_skip_layer_norm = False
            optimization_options.enable_bias_skip_layer_norm = False
            optimization_options.enable_embed_layer_norm = False

        optimized_model = optimizer.optimize_model(
            input_path,
            model_type=model_type,
            num_heads=num_heads,
            hidden_size=hidden_size,
            optimization_options=optimization_options,
        )

        optimized_model.convert_float_to_float16(
            use_symbolic_shape_infer=True,
            keep_io_types=True,  # Keep input/output as FP32 for compatibility
        )

        optimized_model.save_model_to_file(output_path)

    except Exception as e:
        raise ConversionError(f"FP16 conversion failed: {e}")
