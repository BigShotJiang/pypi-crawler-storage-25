"""Main API for spacy-accelerate."""

from pathlib import Path
from typing import List, Literal, Optional, Union

from ._logging import get_logger
from .cache import CacheManager
from .config import OptimizeConfig
from .conversion import export_to_onnx
from .core import (
    ensure_supported_model,
    find_transformer_shim,
    patch_pipeline,
    validate_pipeline,
)
from .exceptions import ProviderNotAvailableError
from .runtime import create_proxy
from .runtime.providers import check_provider_available


def optimize(
    nlp,
    *,
    precision: Literal["fp32", "fp16"] = "fp16",
    cache_dir: Optional[Union[str, Path]] = None,
    warmup: bool = True,
    provider: Literal["tensorrt", "cuda", "cpu"] = "cuda",
    trt_max_workspace_size: int = 4 * 1024**3,
    trt_builder_optimization_level: int = 3,
    trt_timing_cache: bool = True,
    device_id: int = 0,
    max_batch_size: int = 128,
    max_seq_length: int = 512,
    use_io_binding: bool = True,
    fixed_batch_size: Optional[int] = None,
    align_seq_length: int = 16,
    batch_buckets: Optional[List[int]] = None,
    fixed_seq_length: Optional[int] = None,
    verbose: bool = False,
):
    """
    Optimize a spaCy transformer pipeline with ONNX Runtime / TensorRT.

    This function replaces the transformer component in a spaCy pipeline
    with an optimized ONNX Runtime version, providing significant speedups
    for inference.

    Args:
        nlp: A spaCy Language object with a transformer component.
        precision: Model precision - "fp32" or "fp16". FP16 provides faster
            inference with minimal accuracy loss.
        cache_dir: Directory for cached ONNX models. Defaults to
            ~/.cache/spacy-accelerate.
        warmup: Run warmup inference after optimization. Recommended for
            accurate benchmarking.
        provider: Execution provider:
            - "tensorrt": Maximum performance with TensorRT (requires TensorRT)
            - "cuda": Good performance with ONNX Runtime CUDA
            - "cpu": CPU-only inference
        trt_max_workspace_size: TensorRT workspace size in bytes (default: 4GB).
        trt_builder_optimization_level: TensorRT optimization level (0-5).
            Higher values may improve performance but increase build time.
        trt_timing_cache: Enable TensorRT timing cache for faster engine builds.
        device_id: CUDA device ID for GPU inference.
        max_batch_size: Maximum batch size for buffer pre-allocation.
            Only used with IO Binding.
        max_seq_length: Maximum sequence length for buffer pre-allocation.
            Only used with IO Binding.
        use_io_binding: Use IO Binding for zero-copy GPU transfers.
            Provides best performance when inputs are already on GPU.
        fixed_batch_size: Export ONNX model with fixed batch size.
            Required for optimal TensorRT performance. If None, uses dynamic batch size.
        align_seq_length: Align sequence length to multiple of this value (default: 16).
        batch_buckets: List of batch sizes to pre-compile TRT engines for.
            Incoming batches are padded to the nearest bucket on GPU to avoid
            TRT recompilation. Defaults to [1,2,4,8,16,32,64,128] for TensorRT.
            For en_core_web_trf production use: [8,16,64,96,128,160,192,224,256].
        fixed_seq_length: Fixed sequence length for GPU-side padding. None means
            dynamic sequence length. For en_core_web_trf, use 144 (128 window +
            16 overhead from thinc).
        verbose: Enable verbose logging.

    Returns:
        The optimized spaCy Language object (modified in-place).

    Raises:
        SpacyAccelerateError: If the pipeline cannot be optimized.
        ModelNotSupportedError: If the transformer architecture is not supported.
        ConversionError: If ONNX export fails.
        ProviderNotAvailableError: If the requested provider is not available.

    Example:
        >>> import spacy
        >>> import spacy_accelerate
        >>>
        >>> nlp = spacy.load("en_core_web_trf")
        >>> nlp = spacy_accelerate.optimize(nlp, precision="fp16")
        >>>
        >>> # Use as normal
        >>> doc = nlp("Apple Inc. was founded by Steve Jobs.")
        >>> print([(ent.text, ent.label_) for ent in doc.ents])
        [('Apple Inc.', 'ORG'), ('Steve Jobs', 'PERSON')]

    Example with batching:
        >>> texts = ["Text one.", "Text two.", "Text three."]
        >>> docs = list(nlp.pipe(texts, batch_size=32))

    Example with TensorRT:
        >>> nlp = spacy_accelerate.optimize(
        ...     nlp,
        ...     provider="tensorrt",
        ...     precision="fp16",
        ...     trt_max_workspace_size=8 * 1024**3,  # 8GB
        ... )
    """
    logger = get_logger(verbose)

    # Validate pipeline
    logger.info("Validating pipeline...")
    validate_pipeline(nlp)

    # Find the transformer shim
    logger.info("Finding transformer shim...")
    shim = find_transformer_shim(nlp)

    model_class = type(shim._model).__name__
    logger.info(f"Found transformer model: {model_class}")

    # Fail fast for architectures the export path does not support.
    model_info = ensure_supported_model(nlp, shim)
    logger.info(f"Detected supported architecture: {model_info['architecture']}")

    # Detect architecture details for output compatibility
    num_layers = 12  # Default
    hidden_size = 768  # Default
    try:
        # For curated-transformers
        if hasattr(shim._model, "curated_encoder"):
            encoder = shim._model.curated_encoder
            if hasattr(encoder, "config"):
                num_layers = getattr(encoder.config, "num_hidden_layers", 12)
                hidden_size = getattr(encoder.config, "hidden_width", 768)
            elif hasattr(encoder, "num_layers"):
                num_layers = encoder.num_layers
                # Try to find hidden dimension
                for attr in ["hidden_width", "hidden_size", "d_model"]:
                    if hasattr(encoder, attr):
                        hidden_size = getattr(encoder, attr)
                        break

            # Curated Transformers returns [embedding, layer 1, ..., layer N] -> N+1 states
            num_layers += 1

        # For spacy-transformers (HF models)
        elif hasattr(shim._model, "config"):
            num_layers = getattr(shim._model.config, "num_hidden_layers", 12)
            hidden_size = getattr(shim._model.config, "hidden_size", 768)
            num_layers += 1

        logger.info(
            f"Detected architecture: {model_class}, layers={num_layers}, hidden={hidden_size}"
        )
    except Exception:
        logger.warning(
            f"Could not detect model details, defaulting to layers={num_layers}, hidden={hidden_size}"
        )

    # Build configuration
    config = OptimizeConfig(
        precision=precision,
        cache_dir=cache_dir,
        warmup=warmup,
        provider=provider,
        trt_max_workspace_size=trt_max_workspace_size,
        trt_builder_optimization_level=trt_builder_optimization_level,
        trt_timing_cache=trt_timing_cache,
        device_id=device_id,
        max_batch_size=max_batch_size,
        max_seq_length=max_seq_length,
        use_io_binding=use_io_binding,
        fixed_batch_size=fixed_batch_size,
        align_seq_length=align_seq_length,
        num_layers=num_layers,
        hidden_size=hidden_size,
        batch_buckets=batch_buckets,
        fixed_seq_length=fixed_seq_length,
    )

    logger.info(f"Optimizing with config: provider={provider}, precision={precision}")

    # Check provider availability
    if not check_provider_available(config.provider):
        if provider == "tensorrt":
            raise ProviderNotAvailableError(
                "\n\n"
                "TensorRT Execution Provider is not available.\n"
                "\n"
                "The standard PyPI build of onnxruntime-gpu does not include TensorRT EP.\n"
                "You need the NVIDIA build. Run:\n"
                "\n"
                "  pip install --force-reinstall \\\n"
                "      --extra-index-url https://pypi.nvidia.com \\\n"
                "      onnxruntime-gpu==1.23.2\n"
                "\n"
                "To verify TensorRT EP is available after install:\n"
                "  python -m spacy_accelerate\n"
            )
        elif provider == "cuda":
            raise ProviderNotAvailableError(
                "CUDA execution provider is not available. "
                "Ensure CUDA is installed and onnxruntime-gpu is available. "
                "Alternatively, use provider='cpu'."
            )
        else:
            raise ProviderNotAvailableError(f"Provider '{provider}' is not available.")

    # Get or create cached ONNX model
    cache_manager = CacheManager(config.cache_dir, verbose=verbose)

    logger.info("Checking cache for ONNX model...")
    onnx_path = cache_manager.get_or_create(
        nlp=nlp,
        shim=shim,
        precision=config.precision,
        export_fn=export_to_onnx,
        provider=config.provider,
        verbose=verbose,
        fixed_batch_size=config.fixed_batch_size,
    )
    logger.info(f"Using ONNX model: {onnx_path}")

    # Create optimized proxy
    logger.info(f"Creating {config.provider} proxy...")
    proxy = create_proxy(onnx_path, config)
    logger.info("Proxy created successfully")

    # Patch the pipeline
    logger.info("Patching pipeline...")
    patch_pipeline(shim, proxy)
    logger.info("Pipeline patched successfully")

    # Warmup
    if config.warmup:
        logger.info("Running warmup inference...")
        try:
            _ = nlp("This is a warmup sentence for the optimized transformer model.")
            logger.info("Warmup complete")
        except Exception as e:
            logger.warning(f"Warmup failed: {e}")

    logger.info("Optimization complete!")
    return nlp


def _get_cache_manager(cache_dir: Optional[Union[str, Path]] = None) -> CacheManager:
    """Get a CacheManager for the given or default cache directory."""
    if cache_dir is None:
        cache_dir = Path.home() / ".cache" / "spacy-accelerate"
    return CacheManager(Path(cache_dir))


def clear_cache(cache_dir: Optional[Union[str, Path]] = None) -> int:
    """
    Clear the ONNX model cache.

    Args:
        cache_dir: Cache directory to clear. If None, uses the default
            cache directory (~/.cache/spacy-accelerate).

    Returns:
        Number of cache entries cleared.
    """
    return _get_cache_manager(cache_dir).clear()


def list_cached(cache_dir: Optional[Union[str, Path]] = None) -> list:
    """
    List all cached models.

    Args:
        cache_dir: Cache directory to list. If None, uses the default
            cache directory.

    Returns:
        List of cache keys for cached models.
    """
    return _get_cache_manager(cache_dir).list_cached()


def get_cache_size(cache_dir: Optional[Union[str, Path]] = None) -> int:
    """
    Get total size of cached models in bytes.

    Args:
        cache_dir: Cache directory to check. If None, uses the default
            cache directory.

    Returns:
        Total cache size in bytes.
    """
    return _get_cache_manager(cache_dir).get_cache_size()
