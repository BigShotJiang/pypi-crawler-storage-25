"""Core module for spacy-accelerate."""

from .discovery import ensure_supported_model, find_transformer_shim
from .patcher import is_patched, patch_pipeline, restore_pipeline
from .validation import validate_pipeline

__all__ = [
    "ensure_supported_model",
    "find_transformer_shim",
    "is_patched",
    "patch_pipeline",
    "restore_pipeline",
    "validate_pipeline",
]
