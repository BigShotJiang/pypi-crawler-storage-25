"""Patcher module for replacing transformer models with optimized proxies."""

from typing import Any

import torch.nn as nn


def patch_pipeline(shim: Any, proxy: nn.Module) -> None:
    """
    Replace the internal model in a PyTorchShim with an optimized proxy.

    This function monkey-patches the shim to use the ONNX Runtime proxy
    instead of the original PyTorch model. The original model is preserved
    in `shim._original_model` for potential restoration.

    Args:
        shim: The PyTorchShim from the spaCy transformer component.
        proxy: The optimized proxy module (ORTProxy, TRTProxy, etc.).
    """
    # Store original model for potential restoration
    if not hasattr(shim, "_original_model"):
        shim._original_model = shim._model

    # Replace with optimized proxy
    shim._model = proxy


def restore_pipeline(shim: Any) -> bool:
    """
    Restore the original model in a PyTorchShim.

    Args:
        shim: The PyTorchShim that was previously patched.

    Returns:
        True if restoration was successful, False if no original model was found.
    """
    if hasattr(shim, "_original_model"):
        shim._model = shim._original_model
        del shim._original_model
        return True
    return False


def is_patched(shim: Any) -> bool:
    """
    Check if a PyTorchShim has been patched with an optimized proxy.

    Args:
        shim: The PyTorchShim to check.

    Returns:
        True if the shim has been patched, False otherwise.
    """
    return hasattr(shim, "_original_model")
