"""Validation utilities for spacy-accelerate."""

from typing import Any

from ..exceptions import SpacyAccelerateError


def validate_pipeline(nlp: Any) -> None:
    """
    Validate that the pipeline can be optimized.

    Args:
        nlp: A spaCy Language object.

    Raises:
        SpacyAccelerateError: If the pipeline is invalid.
    """
    # Import here to avoid requiring spacy at import time
    try:
        import spacy
    except ImportError:
        raise SpacyAccelerateError(
            "spaCy is required for spacy-accelerate. "
            "Install with: pip install spacy"
        )

    if not isinstance(nlp, spacy.Language):
        raise SpacyAccelerateError(
            f"Expected spacy.Language, got {type(nlp).__name__}"
        )

    # Check for transformer component
    if "transformer" not in nlp.pipe_names:
        available = ", ".join(nlp.pipe_names) if nlp.pipe_names else "none"
        raise SpacyAccelerateError(
            f"Pipeline must have a 'transformer' component. "
            f"Available components: {available}"
        )


