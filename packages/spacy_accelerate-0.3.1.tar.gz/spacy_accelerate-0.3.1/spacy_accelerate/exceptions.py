"""Custom exceptions for spacy-accelerate."""


class SpacyAccelerateError(Exception):
    """Base exception for spacy-accelerate."""

    pass


class ModelNotSupportedError(SpacyAccelerateError):
    """Raised when a model architecture is not supported."""

    pass


class ConversionError(SpacyAccelerateError):
    """Raised when ONNX export or conversion fails."""

    pass


class RuntimeInitError(SpacyAccelerateError):
    """Raised when runtime initialization fails."""

    pass


class CacheError(SpacyAccelerateError):
    """Raised when cache operations fail."""

    pass


class ProviderNotAvailableError(SpacyAccelerateError):
    """Raised when requested execution provider is not available."""

    pass
