"""Configuration for spacy-accelerate."""

from dataclasses import dataclass
from pathlib import Path
from typing import List, Literal, Optional, Union


@dataclass
class OptimizeConfig:
    """
    Configuration for spacy-accelerate optimization.

    This dataclass holds all configuration options for the optimize() function.
    It validates inputs and provides sensible defaults.

    Attributes:
        precision: Model precision - "fp32" or "fp16".
        cache_dir: Directory for cached ONNX models.
        warmup: Whether to run warmup inference after optimization.
        provider: Execution provider - "tensorrt", "cuda", or "cpu".
        trt_max_workspace_size: TensorRT maximum workspace size in bytes.
        trt_builder_optimization_level: TensorRT builder optimization level (0-5).
        trt_timing_cache: Enable TensorRT timing cache.
        device_id: CUDA device ID.
        max_batch_size: Maximum batch size for buffer pre-allocation.
        max_seq_length: Maximum sequence length for buffer pre-allocation.
        use_io_binding: Use IO Binding for zero-copy GPU transfers.
    """

    precision: Literal["fp32", "fp16"] = "fp16"
    cache_dir: Optional[Union[str, Path]] = None
    warmup: bool = True
    provider: Literal["tensorrt", "cuda", "cpu"] = "cuda"
    trt_max_workspace_size: int = 4 * 1024**3  # 4GB
    trt_builder_optimization_level: int = 3
    trt_timing_cache: bool = True
    device_id: int = 0
    max_batch_size: int = 128
    max_seq_length: int = 512
    use_io_binding: bool = True
    # Fixed batch size for TensorRT optimization (None = dynamic)
    fixed_batch_size: Optional[int] = None
    # Number of transformer layers (auto-detected)
    num_layers: int = 12
    hidden_size: int = 768
    # Sequence length alignment (default 16)
    align_seq_length: int = 16
    # Batch bucket sizes for TRT engine pre-compilation (None = auto-default for TRT)
    batch_buckets: Optional[List[int]] = None
    # Fixed sequence length for GPU-side padding (None = dynamic, 144 = en_core_web_trf)
    fixed_seq_length: Optional[int] = None

    def __post_init__(self):
        """Validate and normalize configuration."""
        # Normalize cache_dir
        if self.cache_dir is None:
            self.cache_dir = Path.home() / ".cache" / "spacy-accelerate"
        else:
            self.cache_dir = Path(self.cache_dir)

        # Validate precision
        if self.precision not in ("fp32", "fp16"):
            raise ValueError(
                f"Invalid precision '{self.precision}'. Must be 'fp32' or 'fp16'."
            )

        # Validate provider
        if self.provider not in ("tensorrt", "cuda", "cpu"):
            raise ValueError(
                f"Invalid provider '{self.provider}'. "
                "Must be 'tensorrt', 'cuda', or 'cpu'."
            )

        # Validate device_id
        if self.device_id < 0 and self.provider != "cpu":
            raise ValueError(
                f"Invalid device_id {self.device_id}. Must be >= 0 for GPU providers."
            )

        # Validate batch/sequence limits
        if self.max_batch_size < 1:
            raise ValueError(
                f"Invalid max_batch_size {self.max_batch_size}. Must be >= 1."
            )
        if self.max_seq_length < 1:
            raise ValueError(
                f"Invalid max_seq_length {self.max_seq_length}. Must be >= 1."
            )

        # Validate TensorRT settings
        if self.trt_builder_optimization_level < 0:
            raise ValueError(
                f"Invalid trt_builder_optimization_level "
                f"{self.trt_builder_optimization_level}. Must be >= 0."
            )

        # Validate and normalize batch_buckets
        if self.batch_buckets is not None:
            if len(self.batch_buckets) == 0:
                raise ValueError("batch_buckets must be non-empty if provided.")
            if any(b < 1 for b in self.batch_buckets):
                raise ValueError("All batch_buckets values must be positive integers.")
            self.batch_buckets = sorted(self.batch_buckets)
        elif self.provider == "tensorrt":
            self.batch_buckets = [1, 2, 4, 8, 16, 32, 64, 128]

        # Validate fixed_seq_length
        if self.fixed_seq_length is not None and self.fixed_seq_length < 1:
            raise ValueError(
                f"Invalid fixed_seq_length {self.fixed_seq_length}. Must be >= 1."
            )

    def to_dict(self) -> dict:
        """
        Convert configuration to dictionary.

        Returns:
            Dictionary representation of the configuration.
        """
        return {
            "precision": self.precision,
            "cache_dir": str(self.cache_dir),
            "warmup": self.warmup,
            "provider": self.provider,
            "trt_max_workspace_size": self.trt_max_workspace_size,
            "trt_builder_optimization_level": self.trt_builder_optimization_level,
            "trt_timing_cache": self.trt_timing_cache,
            "device_id": self.device_id,
            "max_batch_size": self.max_batch_size,
            "max_seq_length": self.max_seq_length,
            "use_io_binding": self.use_io_binding,
            "fixed_batch_size": self.fixed_batch_size,
            "num_layers": self.num_layers,
            "hidden_size": self.hidden_size,
            "batch_buckets": self.batch_buckets,
            "fixed_seq_length": self.fixed_seq_length,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "OptimizeConfig":
        """
        Create configuration from dictionary.

        Args:
            data: Dictionary with configuration values.

        Returns:
            OptimizeConfig instance.
        """
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})
