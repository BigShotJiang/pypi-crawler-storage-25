"""spacy-accelerate: Accelerate spaCy transformers with TensorRT/ONNX Runtime."""

# Configure TensorRT library path early (before onnxruntime is imported elsewhere)
from . import runtime  # noqa: F401

from ._version import __version__
from .api import clear_cache, get_cache_size, list_cached, optimize
from .config import OptimizeConfig
from .exceptions import (
    CacheError,
    ConversionError,
    ModelNotSupportedError,
    ProviderNotAvailableError,
    RuntimeInitError,
    SpacyAccelerateError,
)

__all__ = [
    # Version
    "__version__",
    # Main API
    "optimize",
    "clear_cache",
    "list_cached",
    "get_cache_size",
    # Configuration
    "OptimizeConfig",
    # Exceptions
    "SpacyAccelerateError",
    "ModelNotSupportedError",
    "ConversionError",
    "RuntimeInitError",
    "CacheError",
    "ProviderNotAvailableError",
]
