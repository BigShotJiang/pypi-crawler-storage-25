"""Provider factory for creating ONNX Runtime proxies."""

import os
import sys
from pathlib import Path
from typing import TYPE_CHECKING, Iterable, List, Union

from ..exceptions import ProviderNotAvailableError, RuntimeInitError

if TYPE_CHECKING:
    from ..config import OptimizeConfig
    from .proxy_base import BaseProxy


def _find_native_library_dirs(search_paths: Iterable[str] = ()) -> List[Path]:
    """Discover pip-installed CUDA/TensorRT library directories."""
    candidate_roots = list(search_paths) if search_paths else sys.path
    relative_dirs = [
        "tensorrt_libs",
        "nvidia/cublas/lib",
        "nvidia/cuda_runtime/lib",
        "nvidia/cuda_nvrtc/lib",
        "nvidia/cudnn/lib",
        "nvidia/cufft/lib",
        "nvidia/curand/lib",
        "nvidia/cusolver/lib",
        "nvidia/cusparse/lib",
        "nvidia/nccl/lib",
        "nvidia/nvjitlink/lib",
        "nvidia/nvtx/lib",
    ]

    found = []
    seen = set()
    for root in candidate_roots:
        root_path = Path(root)
        for relative_dir in relative_dirs:
            lib_dir = root_path / relative_dir
            if lib_dir.exists() and lib_dir.is_dir():
                lib_dir_str = str(lib_dir)
                if lib_dir_str not in seen:
                    found.append(lib_dir)
                    seen.add(lib_dir_str)

    return found


def _prepend_library_paths(lib_dirs: Iterable[Path]) -> None:
    """Prepend discovered library directories to LD_LIBRARY_PATH."""
    current = os.environ.get("LD_LIBRARY_PATH", "")
    current_paths = [path for path in current.split(":") if path]

    merged = []
    seen = set()
    for lib_dir in [str(path) for path in lib_dirs] + current_paths:
        if lib_dir and lib_dir not in seen:
            merged.append(lib_dir)
            seen.add(lib_dir)

    if merged:
        os.environ["LD_LIBRARY_PATH"] = ":".join(merged)


def _configure_native_library_paths() -> bool:
    """
    Automatically configure/load CUDA and TensorRT libraries from pip packages.

    When CUDA/TensorRT components are installed from pip wheels, the shared
    libraries live under site-packages but are not always visible to CuPy or
    ONNX Runtime automatically. This function discovers the relevant directories,
    updates LD_LIBRARY_PATH for subprocesses, and preloads the core libraries
    into the current process.

    Returns:
        True if any native library directory was found and configured.
    """
    import ctypes
    import platform

    if platform.system() != "Linux":
        return False

    lib_dirs = _find_native_library_dirs()
    if not lib_dirs:
        return False

    _prepend_library_paths(lib_dirs)

    libs_to_preload = [
        "libcudart.so.12",
        "libcublas.so.12",
        "libcublasLt.so.12",
        "libcudnn.so.9",
        "libnvrtc.so.12",
        "libnvJitLink.so.12",
        "libnvinfer.so.10",
        "libnvinfer_plugin.so.10",
        "libnvonnxparser.so.10",
    ]

    loaded_any = False
    for lib_name in libs_to_preload:
        for lib_dir in lib_dirs:
            lib_path = lib_dir / lib_name
            if lib_path.exists():
                try:
                    ctypes.CDLL(str(lib_path), mode=ctypes.RTLD_GLOBAL)
                    loaded_any = True
                    break
                except OSError:
                    pass

    return loaded_any


# Configure CUDA/TensorRT library paths at module import.
_configure_native_library_paths()


def create_proxy(
    onnx_path: Union[str, Path],
    config: "OptimizeConfig",
) -> "BaseProxy":
    """
    Create the appropriate proxy based on configuration.

    This factory function creates the best available proxy for the given
    configuration. It handles fallbacks when certain providers are not
    available.

    Args:
        onnx_path: Path to the ONNX model file.
        config: Optimization configuration.

    Returns:
        An initialized proxy instance.

    Raises:
        ProviderNotAvailableError: If the requested provider is not available.
        RuntimeInitError: If proxy initialization fails.
    """
    onnx_path = str(onnx_path)

    if config.provider == "tensorrt":
        return _create_tensorrt_proxy(onnx_path, config)

    elif config.provider == "cuda":
        return _create_cuda_proxy(onnx_path, config)

    elif config.provider == "cpu":
        return _create_cpu_proxy(onnx_path, config)

    else:
        raise ValueError(f"Unknown provider: {config.provider}")


def _create_tensorrt_proxy(
    onnx_path: str,
    config: "OptimizeConfig",
) -> "BaseProxy":
    """Create TensorRT proxy with IOBinding for zero-copy."""
    from .io_binding_proxy import IOBindingProxy

    return IOBindingProxy(
        onnx_path=onnx_path,
        device_id=config.device_id,
        max_batch_size=config.max_batch_size,
        max_seq_length=config.max_seq_length,
        hidden_size=config.hidden_size,
        gpu_mem_limit=config.trt_max_workspace_size,
        warmup=config.warmup,
        # TensorRT-specific settings
        provider="tensorrt",
        cache_dir=config.cache_dir,
        fp16_enable=config.precision == "fp16",
        builder_optimization_level=config.trt_builder_optimization_level,
        timing_cache_enable=config.trt_timing_cache,
        num_layers=config.num_layers,
        fixed_batch_size=config.fixed_batch_size,
        align_seq_length=config.align_seq_length,
        batch_buckets=config.batch_buckets,
        fixed_seq_length=config.fixed_seq_length,
    )


def _create_cuda_proxy(
    onnx_path: str,
    config: "OptimizeConfig",
) -> "BaseProxy":
    """Create CUDA proxy (ORT or IO Binding)."""
    if config.use_io_binding:
        from .io_binding_proxy import IOBindingProxy

        return IOBindingProxy(
            onnx_path=onnx_path,
            device_id=config.device_id,
            max_batch_size=config.max_batch_size,
            max_seq_length=config.max_seq_length,
            hidden_size=config.hidden_size,
            gpu_mem_limit=config.trt_max_workspace_size,
            warmup=config.warmup,
            num_layers=config.num_layers,
            align_seq_length=config.align_seq_length,
            batch_buckets=config.batch_buckets,
            fixed_seq_length=config.fixed_seq_length,
        )
    else:
        from .ort_proxy import ORTProxy

        return ORTProxy(
            onnx_path=onnx_path,
            device_id=config.device_id,
            warmup=config.warmup,
        )


def _create_cpu_proxy(
    onnx_path: str,
    config: "OptimizeConfig",
) -> "BaseProxy":
    """Create CPU-only proxy."""
    from .cpu_proxy import CPUProxy

    return CPUProxy(
        onnx_path=onnx_path,
        warmup=config.warmup,
    )


def get_available_providers() -> list:
    """
    Get list of available ONNX Runtime providers.

    Returns:
        List of available provider names.
    """
    try:
        import onnxruntime as ort

        return ort.get_available_providers()
    except ImportError:
        return []


def check_provider_available(provider: str) -> bool:
    """
    Check if a specific provider is available.

    Args:
        provider: Provider name ("tensorrt", "cuda", "cpu").

    Returns:
        True if the provider is available.
    """
    available = get_available_providers()

    if provider == "tensorrt":
        return "TensorrtExecutionProvider" in available
    elif provider == "cuda":
        return "CUDAExecutionProvider" in available
    elif provider == "cpu":
        return "CPUExecutionProvider" in available
    else:
        return False
