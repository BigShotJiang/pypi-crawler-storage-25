"""Base proxy class for ONNX Runtime inference."""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional

import torch
import torch.nn as nn


class UniversalTransformerOutput:
    """
    Universal output wrapper that satisfies all spaCy transformer requirements.

    Different versions of spacy-transformers and curated-transformers expect
    different attribute names for the transformer output. This class provides
    all known attribute names pointing to the same underlying tensor data,
    ensuring compatibility across versions.

    Attributes:
        embedding_output: The last hidden state tensor (batch, seq, hidden).
        all_hidden_layer_states: List of hidden states, one per layer.
            Since ONNX only outputs the final hidden state, we replicate it
            for all layers to satisfy spaCy's layer indexing.
    """

    def __init__(self, tensor: torch.Tensor, num_layers: int):
        # Primary hidden state (batch, seq, hidden)
        self.embedding_output = tensor
        self.last_hidden_layer_state = tensor

        # Replicate final state for all layers (ONNX only produces the last one)
        self.all_hidden_layer_states: List[torch.Tensor] = [
            tensor for _ in range(num_layers)
        ]

        # Compatibility aliases for different spacy-transformers versions
        self.layer_hidden_states = self.all_hidden_layer_states
        self.last_hidden_layer_states = self.all_hidden_layer_states
        self.all_outputs = self.all_hidden_layer_states

        self.num_outputs = num_layers
        self.num_layers = num_layers

    def __getitem__(self, idx: int) -> torch.Tensor:
        return self.all_hidden_layer_states[idx]

    def __len__(self) -> int:
        return len(self.all_hidden_layer_states)


class BaseProxy(nn.Module, ABC):
    """
    Base class for ONNX Runtime proxies.

    All proxy implementations (IOBindingProxy, ORTProxy, CPUProxy) inherit
    from this class. It provides a common interface matching what spaCy's
    PyTorchShim expects from the underlying model.
    """

    def __init__(self, num_layers: int = 12):
        super().__init__()
        self.num_layers = num_layers
        self.stats: Dict[str, float] = {
            "d2h_ms": 0.0,
            "inference_ms": 0.0,
            "h2d_ms": 0.0,
            "calls": 0,
        }
        self.profiling_enabled: bool = False

    @abstractmethod
    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        token_type_ids: Optional[torch.Tensor] = None,
    ) -> Any:
        """
        Run inference on the ONNX model.

        Args:
            input_ids: Input token IDs [batch, seq_len].
            attention_mask: Attention mask [batch, seq_len].
            token_type_ids: Token type IDs (unused, accepted for compatibility).

        Returns:
            UniversalTransformerOutput with embeddings.
        """
        pass

    def get_stats(self) -> Dict[str, float]:
        """Return a copy of profiling statistics."""
        return self.stats.copy()

    def reset_stats(self) -> None:
        """Reset profiling statistics to zero."""
        self.stats = {"d2h_ms": 0.0, "inference_ms": 0.0, "h2d_ms": 0.0, "calls": 0}

    def _get_transformer_output(
        self, embedding_output: torch.Tensor
    ) -> UniversalTransformerOutput:
        """
        Wrap a hidden state tensor into a UniversalTransformerOutput.

        spaCy's transformer component expects the model output to have specific
        attributes (embedding_output, layer_hidden_states, etc.). This method
        wraps the raw ONNX output tensor into the compatible format.

        Args:
            embedding_output: The last hidden state tensor (batch, seq, hidden).

        Returns:
            UniversalTransformerOutput instance.
        """
        return UniversalTransformerOutput(embedding_output, self.num_layers)
