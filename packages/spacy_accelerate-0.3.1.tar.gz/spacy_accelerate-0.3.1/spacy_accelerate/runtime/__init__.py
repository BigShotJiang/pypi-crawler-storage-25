"""Runtime module for spacy-accelerate."""

from .providers import create_proxy
from .proxy_base import BaseProxy

__all__ = [
    "create_proxy",
    "BaseProxy",
]
