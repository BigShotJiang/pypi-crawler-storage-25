"""Logging configuration for spacy-accelerate."""

import logging
import sys
from typing import Optional

_logger: Optional[logging.Logger] = None


def get_logger(verbose: bool = False) -> logging.Logger:
    """
    Configure and return the spacy-accelerate logger.

    Args:
        verbose: If True, set log level to DEBUG. Otherwise, set to WARNING.

    Returns:
        Configured logger instance.
    """
    global _logger

    if _logger is None:
        _logger = logging.getLogger("spacy_accelerate")

        if not _logger.handlers:
            handler = logging.StreamHandler(sys.stdout)
            formatter = logging.Formatter(
                "%(asctime)s | %(levelname)s | spacy-accelerate | %(message)s",
                datefmt="%H:%M:%S",
            )
            handler.setFormatter(formatter)
            _logger.addHandler(handler)
            _logger.propagate = False

    # Only increase verbosity — never silently downgrade a verbose logger.
    # This prevents a later caller with verbose=False from hiding debug output
    # that an earlier caller with verbose=True explicitly requested.
    target_level = logging.DEBUG if verbose else logging.WARNING
    if _logger.level == logging.NOTSET or target_level < _logger.level:
        _logger.setLevel(target_level)

    return _logger


def reset_logger() -> None:
    """Reset the global logger (useful for testing)."""
    global _logger
    if _logger is not None:
        _logger.handlers.clear()
        _logger = None
