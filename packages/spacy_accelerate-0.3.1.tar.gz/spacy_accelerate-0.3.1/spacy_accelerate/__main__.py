"""Diagnostic tool for spacy-accelerate.

Run with: python -m spacy_accelerate
"""

import sys


def main():
    print("=" * 60)
    print("spacy-accelerate diagnostics")
    print("=" * 60)

    # Version
    try:
        from spacy_accelerate._version import __version__
        print(f"spacy-accelerate : {__version__}")
    except Exception:
        print("spacy-accelerate : unknown")

    # Python
    print(f"Python           : {sys.version.split()[0]}")

    # PyTorch + CUDA
    print()
    print("--- PyTorch ---")
    try:
        import torch
        print(f"torch            : {torch.__version__}")
        if torch.cuda.is_available():
            print(f"CUDA             : {torch.version.cuda}")
            print(f"GPU              : {torch.cuda.get_device_name(0)}")
        else:
            print("CUDA             : not available")
    except ImportError:
        print("torch            : NOT INSTALLED")

    # CuPy
    print()
    print("--- CuPy ---")
    try:
        import cupy
        import cupy.cublas  # noqa: F401

        print(f"cupy             : {cupy.__version__}")
    except Exception as e:
        print(f"cupy             : IMPORT FAILED ({e})")

    # ONNX Runtime
    print()
    print("--- ONNX Runtime ---")
    try:
        import onnxruntime as ort
        print(f"onnxruntime-gpu  : {ort.__version__}")
        providers = ort.get_available_providers()
        print(f"Providers        : {', '.join(providers)}")

        trt_ok = "TensorrtExecutionProvider" in providers
        cuda_ok = "CUDAExecutionProvider" in providers

        print(f"TensorRT EP      : {'OK' if trt_ok else 'MISSING'}")
        print(f"CUDA EP          : {'OK' if cuda_ok else 'MISSING'}")

        if not trt_ok:
            print()
            print("TensorRT EP is missing. Fix with:")
            print()
            print("  pip install --force-reinstall \\")
            print("      --extra-index-url https://pypi.nvidia.com \\")
            print("      onnxruntime-gpu==1.23.2")

    except ImportError:
        print("onnxruntime-gpu  : NOT INSTALLED")

    # TensorRT packages
    print()
    print("--- TensorRT packages ---")
    try:
        import tensorrt
        print(f"tensorrt         : {tensorrt.__version__}")
    except ImportError:
        print("tensorrt         : NOT INSTALLED")

    try:
        import tensorrt_cu12_bindings
        print(f"tensorrt-cu12    : OK")
    except ImportError:
        print("tensorrt-cu12    : NOT INSTALLED")

    print()
    print("=" * 60)


if __name__ == "__main__":
    main()
