"""Cache module for spacy-accelerate."""

from .manager import CacheManager

__all__ = ["CacheManager"]
