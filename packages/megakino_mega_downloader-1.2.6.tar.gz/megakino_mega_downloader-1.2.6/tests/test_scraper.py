from megakino.api.scraper import parse_media_details, parse_search_results


def test_parse_search_results_normalizes_urls_and_deduplicates():
    html = b"""
    <a class="poster" href="/movie/demo"><h3 class="poster__title">Demo</h3></a>
    <a class="poster" href="/movie/demo"><h3 class="poster__title">Demo Duplicate</h3></a>
    <a class="poster" href="series/demo"><h3 class="poster__title">Series</h3></a>
    """

    results = parse_search_results(html, "https://example.test")

    assert [result.title for result in results] == ["Demo", "Series"]
    assert [result.url for result in results] == [
        "https://example.test/movie/demo",
        "https://example.test/series/demo",
    ]


def test_parse_media_details_reads_series_options_and_iframe_mirrors():
    html = b"""
    <meta property="og:title" content="Example Show">
    <div class="pmovie__series-select">
      <select><option value="episode-1">Episode 1</option></select>
    </div>
    <select id="episode-1"><option value="https://example.test/e1"></option></select>
    <iframe data-src="//voe.test/embed/demo"></iframe>
    <iframe src="https://voe.test/embed/demo"></iframe>
    """

    details = parse_media_details(html)

    assert details.title == "Example Show"
    assert [episode.title for episode in details.episodes] == [
        "Example Show - Episode 1",
        "Example Show (VOE Mirror)",
    ]
    assert [episode.url for episode in details.episodes] == [
        "https://example.test/e1",
        "https://voe.test/embed/demo",
    ]
