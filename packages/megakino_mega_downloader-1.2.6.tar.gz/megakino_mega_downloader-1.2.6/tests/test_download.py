from megakino.cli.actions.download import sanitize_filename


def test_sanitize_filename_removes_invalid_characters():
    assert sanitize_filename('Bad:/Name*?"<>|') == "BadName"


def test_sanitize_filename_handles_empty_name():
    assert sanitize_filename(" . ") == "download"


def test_sanitize_filename_avoids_windows_reserved_names():
    assert sanitize_filename("CON") == "CON_"


def test_sanitize_filename_truncates_long_names():
    assert len(sanitize_filename("x" * 300)) == 180
