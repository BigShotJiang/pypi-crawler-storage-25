from megakino.core import streams
from megakino.core.models import Episode


def test_provider_order_uses_known_preferred_provider():
    assert streams.provider_order("VOE") == ("VOE", "Megakino")


def test_provider_order_falls_back_to_default_for_unknown_provider():
    assert streams.provider_order("Unknown") == ("Megakino", "VOE")


def test_normalize_episode_accepts_existing_episode():
    episode = Episode(title="Demo", url="https://example.test")
    assert streams.normalize_episode(episode) is episode


def test_normalize_episode_accepts_dict():
    episode = streams.normalize_episode({"title": "Demo", "url": "https://example.test"})
    assert episode == Episode(title="Demo", url="https://example.test")
