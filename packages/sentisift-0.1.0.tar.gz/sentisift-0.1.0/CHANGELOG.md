# Changelog

All notable changes to the `sentisift` Python SDK are documented here.

This project follows [Semantic Versioning](https://semver.org/). Before 1.0.0, minor-version bumps may include breaking changes; patch versions are always backward-compatible.

## [0.1.0] - 2026-04-18

### Added

- First public release.
- `SentiSift` client with automatic retries on HTTP 429 (honors `Retry-After`) and 503 (models loading).
- `analyze()`: submit a batch of comments plus article metadata; returns a typed `BufferedResponse` or `ProcessedResponse`.
- `get_usage()`: balance, grants, subscription state, feature flags, influence stats.
- `get_results()`: retrieve already-processed results for an article URL.
- `get_health()` and `wait_until_ready()` for service readiness probing.
- Typed exception hierarchy (`SentiSiftError`, `SentiSiftAuthError`, `SentiSiftValidationError`, `SentiSiftRateLimitError`, `SentiSiftServiceLoadingError`, `SentiSiftServerError`) with `docs_url` and `request_id` exposed on every instance.
- Pydantic v2 response models with `extra="allow"` for forward compatibility.
- User-Agent header identifies the SDK version for API-side analytics.
- Unit tests via pytest + respx covering success paths, error paths, retries, and header propagation.
