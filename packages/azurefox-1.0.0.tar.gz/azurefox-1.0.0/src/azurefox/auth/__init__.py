"""AzureFox module."""
