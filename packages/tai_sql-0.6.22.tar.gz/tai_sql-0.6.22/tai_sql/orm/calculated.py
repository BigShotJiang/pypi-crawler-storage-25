# -*- coding: utf-8 -*-
"""
Calculated column support for tai-sql ORM.

Provides the CalculatedColumn descriptor and the @calculated_column decorator.
Calculated columns are physical DB columns whose values are auto-computed
from other columns on insert and update.

The generated SQLAlchemy model uses hybrid_property (same pattern as encrypted
columns) plus event listeners for automatic recomputation.
"""
from __future__ import annotations

import ast
import inspect
import textwrap
from typing import Any, Dict, List, Optional, Callable, TYPE_CHECKING

from .descriptors import AutoRegisterDescriptor

if TYPE_CHECKING:
    from .table import Table


class _UnsupportedExpression(Exception):
    """Raised when an AST node cannot be converted to a SQL expression."""


_BINOP_MAP: Dict[type, str] = {
    ast.Add: '+',
    ast.Sub: '-',
    ast.Mult: '*',
    ast.Div: '/',
    ast.FloorDiv: '/',
    ast.Mod: '%',
}

_UNARYOP_MAP: Dict[type, str] = {
    ast.USub: '-',
    ast.UAdd: '+',
}


class _DependencyExtractor(ast.NodeVisitor):
    """AST visitor that extracts ``self.X`` attribute accesses from a function body."""

    def __init__(self) -> None:
        self.dependencies: List[str] = []

    def visit_Attribute(self, node: ast.Attribute) -> None:
        if isinstance(node.value, ast.Name) and node.value.id == 'self':
            if node.attr not in self.dependencies:
                self.dependencies.append(node.attr)
        self.generic_visit(node)


class _ExternalNameExtractor(ast.NodeVisitor):
    """AST visitor that collects all top-level Name references that are NOT ``self``."""

    def __init__(self) -> None:
        self.names: set[str] = set()

    def visit_Name(self, node: ast.Name) -> None:
        if node.id != 'self':
            self.names.add(node.id)
        self.generic_visit(node)


class CalculatedColumn(AutoRegisterDescriptor):
    """
    Descriptor for calculated columns that auto-register on their owner Table.

    Calculated columns are physical DB columns whose values are derived from
    other columns.  The computation is defined as a method decorated with
    ``@calculated_column`` and is stored/executed via a ``hybrid_property``
    in the generated SQLAlchemy model.

    The descriptor uses ``__set_name__`` (inherited from AutoRegisterDescriptor)
    to register itself in ``owner.calculated_columns``.
    """

    @property
    def collection_name(self) -> str:
        return 'calculated_columns'

    def __init__(
        self,
        function: Callable,
        source_code: str,
        ast_tree: ast.FunctionDef,
        return_type: str,
        return_type_raw: Any,
        nullable: bool,
        imports: Optional[List[str]] = None,
        docstring: Optional[str] = None,
    ) -> None:
        super().__init__()
        self.function = function
        self.source_code = source_code
        self.ast_tree = ast_tree
        self.return_type = return_type
        self.return_type_raw = return_type_raw
        self.nullable = nullable
        self.imports: List[str] = imports or []
        self.docstring = docstring
        self.dependencies: List[str] = self._extract_dependencies()

    # ── Descriptor protocol ──────────────────────────────────────────────

    def __get__(self, instance: Any, owner: Any) -> Any:
        if instance is None:
            return self
        return self.function.__get__(instance, owner)

    def _initialize_collection(self, owner: Table) -> None:
        """Ensure ``owner.calculated_columns`` is a fresh dict for this class."""
        # Always create a new dict for the declaring class to prevent
        # descriptors leaking into sibling classes via inheritance.
        if self.collection_name not in owner.__dict__:
            setattr(owner, self.collection_name, {})

    # ── Analysis helpers ─────────────────────────────────────────────────

    def _extract_dependencies(self) -> List[str]:
        """Parse the function AST to find all ``self.<attr>`` references."""
        body = list(self.ast_tree.body)
        # Skip docstring node
        if (body and isinstance(body[0], ast.Expr)
                and isinstance(getattr(body[0], 'value', None), ast.Constant)
                and isinstance(body[0].value.value, str)):
            body = body[1:]

        extractor = _DependencyExtractor()
        for node in body:
            extractor.visit(node)
        return extractor.dependencies

    def _get_computation_body(self) -> List[str]:
        """
        Return the full function body as a list of Python source lines.

        The docstring is stripped.  The last ``return`` statement is converted
        to ``self._<name> = <expr>`` so the body can be rendered directly
        inside ``_recompute_<name>(self)``.

        Returns:
            List of source lines (without leading indentation).
        """
        body = list(self.ast_tree.body)
        # Skip docstring
        if (body and isinstance(body[0], ast.Expr)
                and isinstance(getattr(body[0], 'value', None), ast.Constant)
                and isinstance(body[0].value.value, str)):
            body = body[1:]

        if not body:
            return [f'self._{self.name} = None']

        # Convert the last return statement to an assignment
        last = body[-1]
        if isinstance(last, ast.Return) and last.value is not None:
            assign = ast.Assign(
                targets=[ast.Attribute(
                    value=ast.Name(id='self', ctx=ast.Load()),
                    attr=f'_{self.name}',
                    ctx=ast.Store(),
                )],
                value=last.value,
                lineno=last.lineno,
            )
            body[-1] = assign
        elif isinstance(last, ast.Return):
            # return with no value → assign None
            body[-1] = ast.parse(f'self._{self.name} = None').body[0]

        module = ast.Module(body=body, type_ignores=[])
        ast.fix_missing_locations(module)
        return [ast.unparse(stmt) for stmt in module.body]

    # ── SQL expression generation ────────────────────────────────────────

    def _to_sql_expression(self, model_var: str = 'cls') -> Optional[str]:
        """
        Try to convert the return expression to a SQLAlchemy column expression string.

        Converts ``self.xxx`` references to ``{model_var}.xxx`` and translates
        supported Python constructs (f-strings, arithmetic, concatenation) into
        equivalent SQLAlchemy column operations.

        Returns ``None`` when the expression uses constructs that cannot be
        translated to SQL (e.g. external function calls, method calls).
        """
        body = list(self.ast_tree.body)
        # Skip docstring
        if (body and isinstance(body[0], ast.Expr)
                and isinstance(getattr(body[0], 'value', None), ast.Constant)
                and isinstance(body[0].value.value, str)):
            body = body[1:]

        # Find the return statement (must be the last statement, ignoring non-return stmts)
        return_expr = None
        for stmt in reversed(body):
            if isinstance(stmt, ast.Return) and stmt.value is not None:
                return_expr = stmt.value
                break

        if return_expr is None:
            return None

        # Only allow pure expression bodies (no intermediate assignments, calls, etc.)
        non_return = [s for s in body if not isinstance(s, ast.Return)]
        if non_return:
            return None

        try:
            return self._node_to_sql(return_expr, model_var)
        except _UnsupportedExpression:
            return None

    def _node_to_sql(self, node: ast.expr, model_var: str) -> str:
        """Recursively convert an AST expression node to a SQLAlchemy expression string."""

        # self.xxx → Model.xxx
        if isinstance(node, ast.Attribute):
            if isinstance(node.value, ast.Name) and node.value.id == 'self':
                return f'{model_var}.{node.attr}'
            raise _UnsupportedExpression()

        # String / numeric constants
        if isinstance(node, ast.Constant):
            return repr(node.value)

        # Binary operations: +, -, *, /, //, %, **
        if isinstance(node, ast.BinOp):
            left = self._node_to_sql(node.left, model_var)
            right = self._node_to_sql(node.right, model_var)
            op = _BINOP_MAP.get(type(node.op))
            if op is None:
                raise _UnsupportedExpression()
            return f'({left} {op} {right})'

        # Unary operations: -, +, ~
        if isinstance(node, ast.UnaryOp):
            operand = self._node_to_sql(node.operand, model_var)
            op = _UNARYOP_MAP.get(type(node.op))
            if op is None:
                raise _UnsupportedExpression()
            return f'({op}{operand})'

        # f-strings → concatenation with +
        if isinstance(node, ast.JoinedStr):
            parts: List[str] = []
            for value in node.values:
                if isinstance(value, ast.Constant) and isinstance(value.value, str):
                    if value.value:  # skip empty strings
                        parts.append(repr(value.value))
                elif isinstance(value, ast.FormattedValue):
                    # Only support simple references, no format specs
                    if value.format_spec is not None or value.conversion != -1:
                        raise _UnsupportedExpression()
                    parts.append(self._node_to_sql(value.value, model_var))
                else:
                    raise _UnsupportedExpression()
            if not parts:
                return repr('')
            return ' + '.join(parts)

        raise _UnsupportedExpression()

    # ── Serialisation ────────────────────────────────────────────────────

    def info(self) -> Dict[str, Any]:
        """Return metadata dict consumed by Jinja2 templates."""
        from .types import get_type_registry
        registry = get_type_registry()
        type_desc = registry.get_by_name(self.return_type)
        python_type = type_desc.python_type.__name__ if type_desc and type_desc.python_type else self.return_type
        pydantic_type = type_desc.pydantic_type if type_desc else python_type

        return {
            'name': self.name,
            'return_type': self.return_type,
            'python_type': python_type,
            'pydantic_type': pydantic_type,
            'nullable': self.nullable,
            'dependencies': self.dependencies,
            'body_lines': self._get_computation_body(),
            'sql_expression': self._to_sql_expression(model_var=self.owner.__name__ if self.owner else 'cls'),
            'imports': self.imports,
            'docstring': self.docstring or '',
        }


# ─────────────────────────────────────────────────────────────────────────────
# @calculated_column decorator
# ─────────────────────────────────────────────────────────────────────────────

# Canonical mapping from Python built-in types to tai-sql type names
_PYTHON_TYPE_MAP: Dict[str, str] = {
    'str': 'str',
    'int': 'int',
    'float': 'float',
    'bool': 'bool',
    'datetime': 'datetime',
    'date': 'date',
    'time': 'time',
    'dict': 'dict',
}

# Names that are always available (builtins, self, common) and should
# never generate an import statement in the output.
_BUILTIN_NAMES: set[str] = set(dir(__builtins__)) if isinstance(__builtins__, dict) else set(dir(__builtins__))
_SKIP_NAMES: set[str] = _BUILTIN_NAMES | {
    'self', 'None', 'True', 'False',
    # Python builtins that dir() might miss
    'print', 'len', 'range', 'int', 'str', 'float', 'bool', 'list',
    'dict', 'set', 'tuple', 'type', 'isinstance', 'issubclass',
    'max', 'min', 'sum', 'abs', 'round', 'sorted', 'reversed',
    'enumerate', 'zip', 'map', 'filter', 'any', 'all', 'hasattr',
    'getattr', 'setattr',
}


def _extract_imports(func: Callable, func_ast: ast.FunctionDef) -> List[str]:
    """
    Detect external names used in the function body and resolve them to
    ``import`` statements by inspecting the function's module source.

    This works by:
    1. Walking the AST to find all ``Name`` references in the body.
    2. Filtering out builtins and ``self``.
    3. For each remaining name, checking the function's defining module
       for an import statement that brings that name into scope.
    4. Returning the matching import lines.
    """
    # 1. Collect names used in the body (skip docstring)
    body = list(func_ast.body)
    if (body and isinstance(body[0], ast.Expr)
            and isinstance(getattr(body[0], 'value', None), ast.Constant)
            and isinstance(body[0].value.value, str)):
        body = body[1:]

    extractor = _ExternalNameExtractor()
    for node in body:
        extractor.visit(node)

    needed = extractor.names - _SKIP_NAMES
    if not needed:
        return []

    # 2. Parse the module source to find import statements
    func_module = inspect.getmodule(func)
    if func_module is None:
        return []

    try:
        module_source = inspect.getsource(func_module)
        module_ast = ast.parse(module_source)
    except (OSError, TypeError):
        return []

    import_lines: List[str] = []
    seen: set[str] = set()

    for node in ast.iter_child_nodes(module_ast):
        if isinstance(node, ast.Import):
            for alias in node.names:
                name = alias.asname or alias.name
                if name in needed and name not in seen:
                    import_lines.append(ast.unparse(node))
                    seen.add(name)
        elif isinstance(node, ast.ImportFrom):
            matched_aliases = [
                alias for alias in node.names
                if (alias.asname or alias.name) in needed
                and (alias.asname or alias.name) not in seen
            ]
            if matched_aliases:
                # Reconstruct a from...import with only the needed names
                for alias in matched_aliases:
                    name = alias.asname or alias.name
                    seen.add(name)
                new_node = ast.ImportFrom(
                    module=node.module,
                    names=matched_aliases,
                    level=node.level,
                )
                import_lines.append(ast.unparse(new_node))

    return import_lines


def calculated_column(func: Callable) -> CalculatedColumn:
    """
    Decorator that marks a method as a calculated column.

    The method's return-type annotation determines the column type, and its
    body defines the computation that will be inlined into the generated
    SQLAlchemy model as a ``hybrid_property``.

    Any external names referenced in the body (imported functions, classes,
    constants) are detected automatically and their ``import`` statements
    are included in the generated model file.

    Example::

        from mylib import compute_score

        class Usuario(Table):
            __tablename__ = "usuario"

            first_name: col[str]
            last_name: col[str]

            @calculated_column
            def full_name(self) -> str:
                return f"{self.first_name} {self.last_name}"

            @calculated_column
            def risk(self) -> float:
                return compute_score(self.age, self.income)
    """
    # ── Source & AST extraction ───────────────────────────────────────
    try:
        source = inspect.getsource(func)
        source = textwrap.dedent(source)
        tree = ast.parse(source)
        func_ast: ast.FunctionDef = tree.body[0]
    except Exception as e:
        raise RuntimeError(
            f"Could not extract source for calculated column '{func.__name__}': {e}"
        )

    # ── Return type ───────────────────────────────────────────────────
    annotations = func.__annotations__
    raw_return = annotations.get('return')
    if raw_return is None:
        raise TypeError(
            f"Calculated column '{func.__name__}' must have a return type annotation."
        )

    # Determine nullable (Optional / X | None)
    nullable = False
    inner = raw_return
    origin = getattr(raw_return, '__origin__', None)
    if origin is type(None):
        nullable = True
        inner = type(None)
    # Handle Union[X, None]  or  X | None
    import typing
    if origin is typing.Union:
        args = raw_return.__args__
        if type(None) in args:
            nullable = True
            inner = next(a for a in args if a is not type(None))

    # Resolve canonical type name
    type_name = getattr(inner, '__name__', str(inner)).lower()
    canonical = _PYTHON_TYPE_MAP.get(type_name, type_name)

    # ── Import extraction ─────────────────────────────────────────────
    imports = _extract_imports(func, func_ast)

    return CalculatedColumn(
        function=func,
        source_code=source,
        ast_tree=func_ast,
        return_type=canonical,
        return_type_raw=raw_return,
        nullable=nullable,
        imports=imports,
        docstring=func.__doc__,
    )
