"""FIX gateway client for the CPZ AI SDK.

Lets Python callers talk to the long-lived ``fix-gateway.cpz-lab.com``
service for institutional FIX 4.4 execution against SpiderRock SRTrader,
IBKR CTCI, Bloomberg EMSX, CME STP, and generic FIX 4.4 / 5.0 brokers.

The gateway is fronted by the apex Vercel proxy at
``https://api.cpz-lab.com``, which validates either a Supabase JWT
(``Authorization: Bearer ...``) or a CPZ API key pair
(``X-CPZ-Key`` + ``X-CPZ-Secret``) and rewrites onto the long-lived
service.

Two clients are provided:

- :class:`FixClient` — synchronous, built on ``requests`` and
  ``websocket-client``. The default surface used by ``CPZClient.fix``.
- :class:`AsyncFixClient` — async, built on ``aiohttp``. Exposed on
  ``AsyncCPZClient.fix`` for coroutine-based trading bots.

Aligned with the FIX Trading Community Family of Standards: FIX 4.2 /
4.4 / 5.0 SP2 + FIXT, FIXP, SOFH, FIXS, Orchestra, FIXatdl, MMT.

Example
-------

>>> from cpz import CPZClient
>>> client = CPZClient(cpz_key="...", cpz_secret="...")
>>> for s in client.fix.list_sessions()["sessions"]:
...     print(s["name"], s["status"])
>>> resp = client.fix.place_order(
...     session_id=s["id"],
...     symbol="AAPL",
...     side="Buy",
...     qty=10,
...     ord_type="Limit",
...     price=150.0,
... )
>>> for env in client.fix.subscribe_drop_copy(session_id=s["id"]):
...     if env.get("type") == "exec_report":
...         print(env["last_qty"], env["last_px"])
"""

from __future__ import annotations

from ._client import (
    DEFAULT_API_BASE,
    AsyncFixClient,
    FixClient,
    FixError,
)

__all__ = [
    "AsyncFixClient",
    "FixClient",
    "FixError",
    "DEFAULT_API_BASE",
]
