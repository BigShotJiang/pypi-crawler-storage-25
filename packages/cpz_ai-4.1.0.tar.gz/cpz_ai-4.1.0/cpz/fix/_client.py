"""Internal implementation of the FIX gateway clients.

Re-exported by :mod:`cpz.fix`. This module is dependency-free at import
time (``requests``, ``websocket-client``, and ``aiohttp`` are imported
lazily inside the class methods) so plain ``import cpz`` keeps cold-
start cheap for users who never touch the FIX surface.
"""

from __future__ import annotations

import json
import os
import uuid
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Any, AsyncIterator, Awaitable, Callable, Iterator, Optional, Tuple

from ..common.errors import CPZError

DEFAULT_API_BASE = "https://api.cpz-lab.com"


class FixError(CPZError):
    """Raised when the FIX gateway returns a non-2xx response or the WS rejects."""

    def __init__(self, message: str, status: int = 0, body: Any = None) -> None:
        super().__init__(message)
        self.status = status
        self.body = body


# ── Auth resolution shared by sync + async clients ────────────────────────


@dataclass
class _Auth:
    """Resolved authentication headers."""

    headers: dict
    bearer_for_ws: Optional[str]  # used as ?access_token= on WS upgrades


def _resolve_auth(
    cpz_key: Optional[str],
    cpz_secret: Optional[str],
    bearer: Optional[str],
) -> _Auth:
    """Build auth headers from explicit args or environment.

    Precedence: explicit ``bearer`` > explicit CPZ key/secret >
    environment ``CPZ_BEARER_TOKEN`` > environment ``CPZ_API_KEY`` +
    ``CPZ_API_SECRET``.
    """
    bearer = bearer or os.environ.get("CPZ_BEARER_TOKEN") or None
    cpz_key = cpz_key or os.environ.get("CPZ_API_KEY") or None
    cpz_secret = cpz_secret or os.environ.get("CPZ_API_SECRET") or None

    headers: dict = {"Content-Type": "application/json"}
    ws_token: Optional[str] = None
    if bearer:
        headers["Authorization"] = f"Bearer {bearer}"
        ws_token = bearer
    elif cpz_key and cpz_secret:
        headers["X-CPZ-Key"] = cpz_key
        headers["X-CPZ-Secret"] = cpz_secret
        # Browsers can't send custom headers on WS upgrades; the proxy
        # also accepts the joined cpz_key.cpz_secret as a Bearer token.
        ws_token = f"{cpz_key}.{cpz_secret}"
    else:
        raise FixError(
            "Authentication required: pass cpz_key+cpz_secret, bearer=, "
            "or set CPZ_API_KEY+CPZ_API_SECRET in the environment."
        )
    return _Auth(headers=headers, bearer_for_ws=ws_token)


def _build_place_order_body(
    *,
    session_id: str,
    symbol: str,
    side: str,
    qty: float,
    ord_type: str,
    cl_ord_id: Optional[str] = None,
    price: Optional[float] = None,
    stop_price: Optional[float] = None,
    time_in_force: str = "Day",
    account: Optional[str] = None,
    ex_destination: Optional[str] = None,
    security_exchange: Optional[str] = None,
    security_type: Optional[str] = None,
    exec_inst: Optional[str] = None,
    extra: Optional[dict] = None,
) -> Tuple[dict, dict]:
    """Returns ``(body, headers)`` for ``/cpz/orders/fix`` POSTs."""
    cl_ord_id = cl_ord_id or str(uuid.uuid4())
    body: dict = {
        "session_id": session_id,
        "cl_ord_id": cl_ord_id,
        "symbol": symbol,
        "side": side,
        "qty": qty,
        "ord_type": ord_type,
        "time_in_force": time_in_force,
    }
    if price is not None:
        body["price"] = price
    if stop_price is not None:
        body["stop_price"] = stop_price
    if account is not None:
        body["account"] = account
    if ex_destination is not None:
        body["ex_destination"] = ex_destination
    if security_exchange is not None:
        body["security_exchange"] = security_exchange
    if security_type is not None:
        body["security_type"] = security_type
    if exec_inst is not None:
        body["exec_inst"] = exec_inst
    if extra is not None:
        body["extra"] = extra
    headers = {"Idempotency-Key": cl_ord_id}
    return body, headers


# ── Synchronous client ────────────────────────────────────────────────────


class FixClient:
    """Synchronous FIX gateway client backed by ``requests``.

    The :class:`cpz.CPZClient` exposes one of these on its ``fix``
    attribute, so most users do ``cpz_client.fix.place_order(...)``
    rather than instantiating directly.

    Parameters
    ----------
    cpz_key, cpz_secret:
        CPZ API key pair. Mutually exclusive with ``bearer``.
    bearer:
        Pre-issued bearer token (Supabase JWT or OAuth access token).
    base_url:
        Override the apex base URL (defaults to
        ``https://api.cpz-lab.com``).
    timeout:
        Per-request timeout in seconds.
    """

    def __init__(
        self,
        cpz_key: Optional[str] = None,
        cpz_secret: Optional[str] = None,
        bearer: Optional[str] = None,
        base_url: str = DEFAULT_API_BASE,
        timeout: float = 30.0,
    ) -> None:
        self._auth = _resolve_auth(cpz_key, cpz_secret, bearer)
        self._base = base_url.rstrip("/")
        self._timeout = timeout

    # ── HTTP plumbing ────────────────────────────────────────────────────

    def _request(
        self,
        method: str,
        path: str,
        body: Any = None,
        headers: Optional[dict] = None,
    ) -> Any:
        try:
            import requests  # local import keeps cold-start cheap
        except ImportError as exc:  # pragma: no cover — tested via separate path
            raise ImportError(
                "FixClient requires the `requests` package. Install with "
                "`pip install requests`."
            ) from exc

        merged_headers = dict(self._auth.headers)
        if headers:
            merged_headers.update(headers)

        url = f"{self._base}{path}"
        resp = requests.request(
            method=method,
            url=url,
            headers=merged_headers,
            data=json.dumps(body) if body is not None else None,
            timeout=self._timeout,
        )
        text = resp.text
        try:
            parsed: Any = json.loads(text) if text else None
        except json.JSONDecodeError:
            parsed = text
        if not resp.ok:
            err_msg = (
                parsed.get("error")
                if isinstance(parsed, dict) and "error" in parsed
                else f"HTTP {resp.status_code}"
            )
            raise FixError(str(err_msg), status=resp.status_code, body=parsed)
        return parsed

    # ── Sessions ─────────────────────────────────────────────────────────

    def list_sessions(self) -> dict:
        """List FIX sessions owned by the authenticated user."""
        return self._request("GET", "/cpz/fix/sessions")

    def get_session_status(self, session_id: str) -> dict:
        return self._request("GET", f"/cpz/fix/sessions/{session_id}/status")

    def test_logon(self, session_id: str) -> dict:
        return self._request("POST", f"/cpz/fix/sessions/{session_id}/test-logon")

    # ── Orders ───────────────────────────────────────────────────────────

    def place_order(self, **kwargs: Any) -> dict:
        """Place a FIX order. Returns the persisted-order envelope.

        Required kwargs: ``session_id``, ``symbol``, ``side``, ``qty``,
        ``ord_type``. Optional: ``cl_ord_id``, ``price``, ``stop_price``,
        ``time_in_force``, ``account``, ``ex_destination``,
        ``security_exchange``, ``security_type``, ``exec_inst``,
        ``extra``, ``idempotency_key``.

        ``idempotency_key`` defaults to ``cl_ord_id`` so safe retries
        return the same row.
        """
        idempotency_key = kwargs.pop("idempotency_key", None)
        body, headers = _build_place_order_body(**kwargs)
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key
        return self._request("POST", "/cpz/orders/fix", body=body, headers=headers)

    def cancel_order(self, cl_ord_id: str) -> dict:
        from urllib.parse import quote

        return self._request(
            "DELETE", f"/cpz/orders/fix/{quote(cl_ord_id, safe='')}"
        )

    def replace_order(self, cl_ord_id: str, **changes: Any) -> dict:
        from urllib.parse import quote

        return self._request(
            "PATCH",
            f"/cpz/orders/fix/{quote(cl_ord_id, safe='')}",
            body=changes,
        )

    # ── Drop-copy WebSocket ──────────────────────────────────────────────

    @contextmanager
    def _ws_connect(
        self,
        session_id: Optional[str],
        symbols: Optional[list],
    ) -> Iterator[Any]:
        try:
            import websocket  # type: ignore[import-untyped]
        except ImportError as exc:  # pragma: no cover — install-extra path
            raise ImportError(
                "subscribe_drop_copy() requires the `websocket-client` package. "
                "Install with `pip install websocket-client`."
            ) from exc

        ws_base = self._base.replace("https://", "wss://").replace("http://", "ws://")
        url = f"{ws_base}/cpz/fix/dropcopy?access_token={self._auth.bearer_for_ws}"
        if session_id:
            url += f"&session_id={session_id}"
        if symbols:
            url += "&symbols=" + ",".join(symbols)
        ws = websocket.create_connection(url, timeout=self._timeout)
        try:
            yield ws
        finally:
            try:
                ws.close()
            except Exception:
                pass

    def subscribe_drop_copy(
        self,
        *,
        session_id: Optional[str] = None,
        symbols: Optional[list] = None,
    ) -> Iterator[dict]:
        """Yield drop-copy envelopes (ExecReports + control frames).

        The first frame is always ``{"type":"subscribed", ...}`` confirming
        the subscription. Subsequent frames have ``type=exec_report``.
        Yields until the socket closes or the iterator is broken.
        """
        with self._ws_connect(session_id, symbols) as ws:
            while True:
                try:
                    frame = ws.recv()
                except Exception:
                    return
                if not frame:
                    return
                try:
                    yield json.loads(frame)
                except json.JSONDecodeError:
                    continue


# ── Async client ──────────────────────────────────────────────────────────


class AsyncFixClient:
    """Async FIX gateway client backed by ``aiohttp``.

    Behaves identically to :class:`FixClient` but every method is a
    coroutine. Exposed on :class:`cpz.AsyncCPZClient.fix`.
    """

    def __init__(
        self,
        cpz_key: Optional[str] = None,
        cpz_secret: Optional[str] = None,
        bearer: Optional[str] = None,
        base_url: str = DEFAULT_API_BASE,
        timeout: float = 30.0,
    ) -> None:
        self._auth = _resolve_auth(cpz_key, cpz_secret, bearer)
        self._base = base_url.rstrip("/")
        self._timeout = timeout

    async def _request(
        self,
        method: str,
        path: str,
        body: Any = None,
        headers: Optional[dict] = None,
    ) -> Any:
        try:
            import aiohttp
        except ImportError as exc:  # pragma: no cover
            raise ImportError(
                "AsyncFixClient requires the `aiohttp` package. Install with "
                "`pip install aiohttp`."
            ) from exc

        merged = dict(self._auth.headers)
        if headers:
            merged.update(headers)

        timeout = aiohttp.ClientTimeout(total=self._timeout)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.request(
                method,
                f"{self._base}{path}",
                headers=merged,
                data=json.dumps(body) if body is not None else None,
            ) as resp:
                text = await resp.text()
                try:
                    parsed: Any = json.loads(text) if text else None
                except json.JSONDecodeError:
                    parsed = text
                if not resp.ok:
                    err_msg = (
                        parsed.get("error")
                        if isinstance(parsed, dict) and "error" in parsed
                        else f"HTTP {resp.status}"
                    )
                    raise FixError(str(err_msg), status=resp.status, body=parsed)
                return parsed

    async def list_sessions(self) -> dict:
        return await self._request("GET", "/cpz/fix/sessions")

    async def get_session_status(self, session_id: str) -> dict:
        return await self._request("GET", f"/cpz/fix/sessions/{session_id}/status")

    async def test_logon(self, session_id: str) -> dict:
        return await self._request(
            "POST", f"/cpz/fix/sessions/{session_id}/test-logon"
        )

    async def place_order(self, **kwargs: Any) -> dict:
        idempotency_key = kwargs.pop("idempotency_key", None)
        body, headers = _build_place_order_body(**kwargs)
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key
        return await self._request(
            "POST", "/cpz/orders/fix", body=body, headers=headers
        )

    async def cancel_order(self, cl_ord_id: str) -> dict:
        from urllib.parse import quote

        return await self._request(
            "DELETE", f"/cpz/orders/fix/{quote(cl_ord_id, safe='')}"
        )

    async def replace_order(self, cl_ord_id: str, **changes: Any) -> dict:
        from urllib.parse import quote

        return await self._request(
            "PATCH",
            f"/cpz/orders/fix/{quote(cl_ord_id, safe='')}",
            body=changes,
        )

    async def subscribe_drop_copy(
        self,
        *,
        session_id: Optional[str] = None,
        symbols: Optional[list] = None,
        on_message: Optional[Callable[[dict], Awaitable[None]]] = None,
    ) -> AsyncIterator[dict]:
        """Async generator yielding drop-copy envelopes."""
        try:
            import aiohttp
        except ImportError as exc:  # pragma: no cover
            raise ImportError(
                "subscribe_drop_copy() requires the `aiohttp` package. "
                "Install with `pip install aiohttp`."
            ) from exc

        ws_base = self._base.replace("https://", "wss://").replace("http://", "ws://")
        url = f"{ws_base}/cpz/fix/dropcopy?access_token={self._auth.bearer_for_ws}"
        if session_id:
            url += f"&session_id={session_id}"
        if symbols:
            url += "&symbols=" + ",".join(symbols)

        timeout = aiohttp.ClientTimeout(total=None)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.ws_connect(url, heartbeat=30) as ws:
                async for msg in ws:
                    if msg.type != aiohttp.WSMsgType.TEXT:
                        continue
                    try:
                        env = json.loads(msg.data)
                    except json.JSONDecodeError:
                        continue
                    if on_message is not None:
                        await on_message(env)
                    yield env
