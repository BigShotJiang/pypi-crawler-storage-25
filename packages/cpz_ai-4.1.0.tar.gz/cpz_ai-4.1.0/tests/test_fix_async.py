"""Tests for cpz.fix.AsyncFixClient.

Uses ``aioresponses`` to mock aiohttp so tests run offline and fast.
"""

from __future__ import annotations

import json

import pytest
from aioresponses import aioresponses

from cpz import AsyncCPZClient, AsyncFixClient, FixError


SESSION_ID = "00000000-0000-0000-0000-000000000001"


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch):
    for key in ("CPZ_BEARER_TOKEN", "CPZ_API_KEY", "CPZ_API_SECRET"):
        monkeypatch.delenv(key, raising=False)


def _client(**overrides) -> AsyncFixClient:
    defaults = {
        "cpz_key": "cpz_key_test",
        "cpz_secret": "cpz_secret_test",
    }
    defaults.update(overrides)
    return AsyncFixClient(**defaults)


@pytest.mark.asyncio
async def test_async_list_sessions():
    with aioresponses() as m:
        m.get(
            "https://api.cpz-lab.com/cpz/fix/sessions",
            payload={"sessions": [{"id": SESSION_ID}], "count": 1},
            status=200,
        )
        out = await _client().list_sessions()
    assert out["count"] == 1
    assert out["sessions"][0]["id"] == SESSION_ID


@pytest.mark.asyncio
async def test_async_place_order_posts_canonical_body():
    captured: dict = {}

    def callback(url, **kwargs):
        captured["body"] = kwargs.get("data")
        captured["headers"] = kwargs.get("headers", {})

    with aioresponses() as m:
        m.post(
            "https://api.cpz-lab.com/cpz/orders/fix",
            payload={"cl_ord_id": "c1", "status": "pending_new"},
            status=202,
            callback=callback,
        )
        await _client().place_order(
            session_id=SESSION_ID,
            cl_ord_id="c1",
            symbol="AAPL",
            side="Buy",
            qty=10,
            ord_type="Limit",
            price=150.0,
        )

    assert captured["headers"]["Idempotency-Key"] == "c1"
    parsed = json.loads(captured["body"])
    assert parsed["symbol"] == "AAPL"
    assert parsed["price"] == 150.0


@pytest.mark.asyncio
async def test_async_error_response_raises_with_status():
    with aioresponses() as m:
        m.post(
            "https://api.cpz-lab.com/cpz/orders/fix",
            payload={"error": "risk_rejected", "risk_code": "fat_finger_qty"},
            status=403,
        )
        with pytest.raises(FixError) as exc:
            await _client().place_order(
                session_id=SESSION_ID, symbol="AAPL", side="Buy", qty=1_000_000, ord_type="Market"
            )
        assert exc.value.status == 403
        assert exc.value.body["risk_code"] == "fat_finger_qty"


@pytest.mark.asyncio
async def test_async_cancel_url_encodes():
    with aioresponses() as m:
        m.delete(
            "https://api.cpz-lab.com/cpz/orders/fix/abc%2Fdef",
            payload={"cl_ord_id": "abc/def", "status": "pending_cancel"},
            status=202,
        )
        out = await _client().cancel_order("abc/def")
    assert out["status"] == "pending_cancel"


@pytest.mark.asyncio
async def test_async_cpz_client_exposes_fix(monkeypatch):
    # AsyncCPZClient pulls its credentials from the ambient CPZAIClient
    # (env vars). The FIX namespace reuses them.
    monkeypatch.setenv("CPZ_AI_API_KEY", "env-key")
    monkeypatch.setenv("CPZ_AI_SECRET_KEY", "env-secret")

    with aioresponses() as m:
        m.get(
            "https://api.cpz-lab.com/cpz/fix/sessions",
            payload={"sessions": [], "count": 0},
            status=200,
        )
        client = AsyncCPZClient()
        out = await client.fix.list_sessions()
    assert out["count"] == 0
    # Lazy + cached
    assert client.fix is client.fix
