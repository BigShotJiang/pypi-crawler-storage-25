"""Tests for cpz.fix.FixClient (sync).

We use the `responses` library to mock requests so tests run offline.
"""

from __future__ import annotations

import os
from unittest.mock import patch

import pytest
import responses

from cpz import CPZClient, FixClient, FixError


SESSION_ID = "00000000-0000-0000-0000-000000000001"


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch):
    """Ensure environment-based auth doesn't leak between tests."""
    for key in ("CPZ_BEARER_TOKEN", "CPZ_API_KEY", "CPZ_API_SECRET"):
        monkeypatch.delenv(key, raising=False)


def _client(**overrides):
    defaults = {
        "cpz_key": "cpz_key_test",
        "cpz_secret": "cpz_secret_test",
    }
    defaults.update(overrides)
    return FixClient(**defaults)


# ── Auth resolution ───────────────────────────────────────────────────────


def test_auth_requires_credentials():
    with pytest.raises(FixError, match="Authentication required"):
        FixClient()


def test_bearer_takes_precedence_over_key_pair(monkeypatch):
    monkeypatch.setenv("CPZ_API_KEY", "ignored")
    monkeypatch.setenv("CPZ_API_SECRET", "ignored")
    c = FixClient(bearer="real-jwt")
    assert c._auth.headers["Authorization"] == "Bearer real-jwt"
    assert "X-CPZ-Key" not in c._auth.headers


def test_env_var_fallback(monkeypatch):
    monkeypatch.setenv("CPZ_API_KEY", "env-key")
    monkeypatch.setenv("CPZ_API_SECRET", "env-secret")
    c = FixClient()
    assert c._auth.headers["X-CPZ-Key"] == "env-key"
    assert c._auth.headers["X-CPZ-Secret"] == "env-secret"


# ── Sessions ──────────────────────────────────────────────────────────────


@responses.activate
def test_list_sessions_returns_parsed_body():
    responses.add(
        responses.GET,
        "https://api.cpz-lab.com/cpz/fix/sessions",
        json={
            "sessions": [
                {"id": SESSION_ID, "name": "SR prod", "broker": "spiderrock", "status": "active"}
            ],
            "count": 1,
        },
        status=200,
    )
    out = _client().list_sessions()
    assert out["count"] == 1
    assert out["sessions"][0]["broker"] == "spiderrock"


@responses.activate
def test_get_session_status():
    responses.add(
        responses.GET,
        f"https://api.cpz-lab.com/cpz/fix/sessions/{SESSION_ID}/status",
        json={"session_id": SESSION_ID, "status": "active"},
        status=200,
    )
    assert _client().get_session_status(SESSION_ID)["status"] == "active"


# ── Orders ────────────────────────────────────────────────────────────────


@responses.activate
def test_place_order_posts_canonical_body():
    responses.add(
        responses.POST,
        "https://api.cpz-lab.com/cpz/orders/fix",
        json={"cl_ord_id": "c1", "order_id": "o1", "status": "pending_new"},
        status=202,
    )
    resp = _client().place_order(
        session_id=SESSION_ID,
        cl_ord_id="c1",
        symbol="AAPL",
        side="Buy",
        qty=10,
        ord_type="Limit",
        price=150.0,
    )
    assert resp["status"] == "pending_new"

    sent = responses.calls[0].request
    assert sent.headers["Content-Type"] == "application/json"
    assert sent.headers["Idempotency-Key"] == "c1"
    body = sent.body
    if isinstance(body, bytes):
        body = body.decode()
    import json

    parsed = json.loads(body)
    assert parsed["symbol"] == "AAPL"
    assert parsed["side"] == "Buy"
    assert parsed["qty"] == 10
    assert parsed["price"] == 150.0


@responses.activate
def test_place_order_generates_cl_ord_id_when_missing():
    responses.add(
        responses.POST,
        "https://api.cpz-lab.com/cpz/orders/fix",
        json={"cl_ord_id": "auto", "status": "pending_new"},
        status=202,
    )
    _client().place_order(
        session_id=SESSION_ID, symbol="AAPL", side="Buy", qty=1, ord_type="Market"
    )
    import json

    body = responses.calls[0].request.body
    if isinstance(body, bytes):
        body = body.decode()
    cl_ord_id = json.loads(body)["cl_ord_id"]
    assert len(cl_ord_id) == 36  # UUID4


@responses.activate
def test_place_order_explicit_idempotency_key_overrides_default():
    responses.add(
        responses.POST,
        "https://api.cpz-lab.com/cpz/orders/fix",
        json={"cl_ord_id": "c1", "status": "pending_new"},
        status=202,
    )
    _client().place_order(
        session_id=SESSION_ID,
        cl_ord_id="c1",
        symbol="AAPL",
        side="Buy",
        qty=1,
        ord_type="Market",
        idempotency_key="explicit-idem",
    )
    assert responses.calls[0].request.headers["Idempotency-Key"] == "explicit-idem"


@responses.activate
def test_place_order_non_2xx_raises_fix_error_with_status_and_body():
    responses.add(
        responses.POST,
        "https://api.cpz-lab.com/cpz/orders/fix",
        json={
            "cl_ord_id": "c1",
            "status": "rejected",
            "error": "risk_rejected",
            "risk_code": "fat_finger_qty",
            "risk_reason": "qty 1000000 > limit 1000",
        },
        status=403,
    )
    with pytest.raises(FixError) as exc:
        _client().place_order(
            session_id=SESSION_ID, symbol="AAPL", side="Buy", qty=1_000_000, ord_type="Market"
        )
    assert exc.value.status == 403
    assert exc.value.body["risk_code"] == "fat_finger_qty"


@responses.activate
def test_cancel_order_url_encodes_special_characters():
    responses.add(
        responses.DELETE,
        "https://api.cpz-lab.com/cpz/orders/fix/abc%2Fdef",
        json={"cl_ord_id": "abc/def", "status": "pending_cancel"},
        status=202,
    )
    out = _client().cancel_order("abc/def")
    assert out["status"] == "pending_cancel"


@responses.activate
def test_replace_order_patches_with_partial_body():
    responses.add(
        responses.PATCH,
        "https://api.cpz-lab.com/cpz/orders/fix/r1",
        json={"cl_ord_id": "r1", "status": "pending_replace"},
        status=202,
    )
    _client().replace_order("r1", qty=200, price=155)
    import json

    body = responses.calls[0].request.body
    if isinstance(body, bytes):
        body = body.decode()
    assert json.loads(body) == {"qty": 200, "price": 155}


# ── Top-level CPZClient.fix integration ───────────────────────────────────


@responses.activate
def test_cpz_client_exposes_fix_namespace_lazily(monkeypatch):
    # The platform CPZClient takes its credentials through the ambient
    # CPZAIClient (env vars), not through cpz_key/cpz_secret kwargs. The
    # FIX namespace pulls those same creds via `cpz_client.api_key/secret_key`
    # so users don't double-configure.
    monkeypatch.setenv("CPZ_AI_API_KEY", "env-key")
    monkeypatch.setenv("CPZ_AI_SECRET_KEY", "env-secret")

    responses.add(
        responses.GET,
        "https://api.cpz-lab.com/cpz/fix/sessions",
        json={"sessions": [], "count": 0},
        status=200,
    )

    # CPZClient construction should not eagerly instantiate the FIX client
    # (so users who never touch FIX never pay the cost).
    with patch.object(FixClient, "__init__", return_value=None) as mock_init:
        client = CPZClient()
        assert mock_init.call_count == 0

    # First .fix access lazily constructs and exposes the namespace.
    client = CPZClient()
    assert client.fix.list_sessions()["count"] == 0
    # Subsequent accesses reuse the same instance.
    assert client.fix is client.fix
