import shlex
import readline
import glob
import argparse
import os
import shutil
import pandas as pd
from collections import OrderedDict
import textwrap
from contextlib import redirect_stdout
import sys
import io
import yaml
import subprocess
import signal
import importlib.util

from dsi.core import Terminal
from dsi.sync import Sync

from ._version import __version__

def autofill_path(text, state):
    """ Completes file and directory paths for the current input """
    line = readline.get_line_buffer()
    parts = shlex.split(line[:readline.get_endidx()], posix=True)

    if line and line[-1].isspace():
        parts.append('')

    curr = parts[-1] if parts else ''

    matches = glob.glob(os.path.expanduser(curr) + '*')
    matches = [m + '/' if os.path.isdir(m) else m for m in matches]
    matches = [m[m[:-1].rfind('/')+1:] if '/' in m[:-1] else m for m in matches]

    try:
        return matches[state]
    except IndexError:
        return None

readline.set_completer(autofill_path)
if "libedit" in readline.__doc__:
    readline.parse_and_bind("bind ^I rl_complete")
else:
    readline.parse_and_bind("tab: complete")


class DSI_cli:
    '''
    A class for command line interface for DSI
    '''
    t = []

    def __init__(self):
        self.name = None
        self.start_dir = os.getcwd() + "/"
        return

    def viewers_check(self):
        '''
        Checks which viewers are available depending on the user's environment.

        To register a new viewer, add it to all_viewers with the viewer name as the key and its required PyPI packages as the value.
        Also include a checker to test if those packages can be installed (using import name. ex: sklearn for the scikit-learn)
        '''
        # both objects must be include only lowercase strings
        available_viewers = []
        all_viewers = {"dashboard" : ["streamlit"], 
                       "ml" : ["streamlit", "scikit-learn"] #pypi package names
                      }

        # dashboard checker
        if importlib.util.find_spec("streamlit") is not None:
            available_viewers.append("dashboard")

        # ml checker
        if all(importlib.util.find_spec(pkg) is not None for pkg in ["streamlit", "sklearn"]):
            available_viewers.append("ml")

        # # jupyter checker
        # if all(importlib.util.find_spec(pkg) is not None for pkg in ["ipykernel", "nbformat"]):
        #     available_viewers.append("jupyter")

        return (None, all_viewers) if not available_viewers else (available_viewers, all_viewers)


    def startup(self, backend="sqlite"):
        self.t = Terminal(debug = 0, runTable=False)
        self.t.user_wrapper = True

        self.valid_viewers, self.all_viewers = self.viewers_check()
        self.start_dir = os.getcwd()
        self.db_path = os.path.join(self.start_dir, ".temp_dsi.db")

        fnull = open(os.devnull, 'w')
        if not self.t.can_create_file_here(self.start_dir):
            print("Cannot start the DSI CLI due to write permissions in this directory. Please try elsewhere.")
            with redirect_stdout(fnull):
                self.exit_cli([])

        if os.path.exists(self.db_path):
            os.remove(self.db_path)
        
        keywords = None
        if backend.lower() == "ndp":
            keywords = input("Enter NDP search keywords (e.g., climate, temperature): ").strip()
            
        try:
            with redirect_stdout(fnull):
                if backend=="duckdb":
                    self.t.load_module('backend','DuckDB','back-write', filename = self.db_path)
                    self.name = "duckdb"
                    backend = "DuckDB"
                elif backend.lower() == "ndp":
                    # NDP requires params dict for initialization
                    self.t.load_module('backend', 'NDP', 'back-read', params={"keywords": keywords})
                    self.name = "ndp"
                    backend = "NDP"
                elif backend.lower() == "osti":
                    # PLACEHOLDER for future implement
                    # OSTI requires params dict for initialization
                    print("OSTI backend requires configuration.")
                    print("Use Python API: t.load_module('backend', 'OSTI', 'back-read', params={...})")
                    backend = "OSTI"
                    self.exit_cli([])
                else:
                    backend = "Sqlite"
                    self.t.load_module('backend','Sqlite','back-write', filename = self.db_path)
                    self.name = "sqlite"
        except Exception as e:
            print(f"backend ERROR: {e}")
            with redirect_stdout(fnull):
                self.exit_cli([])
        print(f"Created a temporary {backend} DSI backend")


    def help_fn(self, args):
        commands = {
            'display' :("<table name> [-n num_rows] [-e filename]",
                        "Displays a table's data. Optionally limit displayed rows and export to CSV/Parquet"),
            'draw' :("[-f filename]", "Draws an ER diagram of all tables in the current DSI database"),
            'exit': ("", "Exits the DSI Command Line Interface (CLI)"),
            'federate' : ("<config file> [-w workspace_folder]", 
                          "Collects data from sources defined in the YAML config file, optionally saving it to a workspace folder."),
            'find' : ("<condition>", "Finds all rows of a table that match a column-level condition."),
            'help': ("", "Shows this help message."),
            'list' : ("", "Lists all tables in the current DSI database"),
            'plot_table' : ("<table name> [-f filename]", "Plots numerical data from a table to an optional file name argument"),
            'query' : ("<SQL query> [-n num_rows] [-e filename]",
                       "Executes a SQL query (in quotes). Optionally limit printed rows or export to CSV/Parquet"),
            'read' : ("<data source> [-t table_name]", "Reads a file or URL into the DSI database. Optionally set table name."),
            'search' : ("<value>", "Searches for a string or number across DSI."),
            'summary' : ("[-t table_name]", "Summary of the database or a specific table."),
            'viewers' : ("", "Prints the available viewers for the user."),
            'view' : ("<available viewer>", "Creates an instance of the DSI viewer in another application."),
            'write' : ("<filename>", "Writes data in DSI database to a permanent location."),
            'ls' : ("", "Lists all files in the current or specified directory."),
            'cd' : ("<path>", "Changes the working directory within the CLI environment.")
        }
        if self.viewers_check()[0] is None:
            del commands["view"]

        print()
        terminal_width = shutil.get_terminal_size().columns
        for key, val in commands.items():
            cmd = f'{key} {val[0]}'
            print(textwrap.fill(f"{cmd:48} {val[1]}", width=terminal_width, subsequent_indent=' ' * 50))
        print()


    def cd(self, args):
        '''
        Changes the current working directory only within the CLI environment
        '''
        if not args:
            print("Usage: cd <directory>")
            return
        path = os.path.expanduser(args[0])
        if os.path.isdir(path):
            os.chdir(path)
            print(f"Changed directory to {os.getcwd()}")
        else:
            print(f"{path} is not a directory.")
        print()


    def clear(self, args):
        '''
        Clears the command line
        '''
        os.system('cls' if os.name == 'nt' else 'clear')


    def get_display_parser(self):
        parser = argparse.ArgumentParser(prog='display')
        parser.add_argument('table_name', help='Table to display')
        parser.add_argument('-n', '--num_rows', type=int, required=False, help='Show first n rows of the table')
        parser.add_argument('-e', '--export', type=str, required=False, help='Export to csv or parquet file')
        return parser


    def display(self, args):
        '''
        Displays the contents of a table
        '''
        table_name = args.table_name
        num_rows = 25
        if args.num_rows is not None:
            num_rows = args.num_rows

        try:
            self.t.display(table_name, num_rows)
        except Exception as e:
            print(f"display ERROR: {e}")
            return

        if args.export is not None:
            file_extension = args.export.rsplit(".", 1)[-1] if '.' in args.export else ''
            if file_extension.lower() not in ["csv", "pq", "parquet"]:
                filename = args.export + ".csv"
            else:
                filename = args.export
            error = self.export_table(table_name, filename)
            if error != 1:
                print(f"Exported {table_name} to {filename}")
            print()


    def get_draw_parser(self):
        parser = argparse.ArgumentParser(prog='draw')
        parser.add_argument('-f', '--filename', type=str, required=False, help='ER Diagram filename')
        return parser


    def draw_schema(self, args):
        '''
        Generates an ER diagram from all data loaded in
        '''
        erd_name = "er_diagram.png"
        if args.filename is not None:
            erd_name = args.filename

        error = self.export_table("dsi_erd_gen", erd_name)
        if error != 1:
            print(f"Saved an ER Diagram at {erd_name}")
        print()


    def exit_cli(self, args):
        '''
        Exits the CLI
        '''
        print("\nExiting...")
        fnull = open(os.devnull, 'w')
        with redirect_stdout(fnull):
            self.t.close()
        exit(0)


    def export_table(self, table_name, filename):
        '''
        Exports to a csv/parquet file
        '''
        if table_name != "temp_query":
            try:
                self.t.artifact_handler(interaction_type='process')
            except Exception as e:
                self.t.active_metadata = OrderedDict()
                print(f"export ERROR: {e}")
                return 1

        file_extension = filename.rsplit(".", 1)[-1] if '.' in filename else ''
        success_load = True

        if "/" not in filename:
            filename = os.path.join(self.start_dir, filename)

        fnull = open(os.devnull, 'w')
        try:
            with redirect_stdout(fnull):
                if table_name == "dsi_erd_gen":
                    self.t.load_module('plugin', "ER_Diagram", "writer", filename = filename)
                elif "dsi_tb_" in table_name:
                    self.t.load_module('plugin', "Table_Plot", "writer", table_name = table_name[7:], filename = filename)
                elif file_extension.lower() == "csv":
                    self.t.load_module('plugin', "Csv_Writer", "writer", filename = filename, table_name = table_name)
                elif file_extension.lower() in ['pq', 'parquet']:
                    self.t.load_module('plugin', "Parquet_Writer", "writer", filename = filename, table_name = table_name)
                else:
                    success_load = False
        except Exception as e:
            self.t.active_metadata = OrderedDict()
            print(f"export ERROR: {e}")
            return 1

        if success_load:
            try:
                self.t.transload()
            except Exception as e:
                self.t.active_modules['writer'].pop(0)
                self.t.active_metadata = OrderedDict()
                print(f"export ERROR: {e}")
                return 1

        self.t.active_metadata = OrderedDict()


    def get_federate_parser(self):
        parser = argparse.ArgumentParser(prog='federate')
        parser.add_argument('config_file', help='YAML config file that lists all data sources to download')
        parser.add_argument('-w', '--workspace_folder', type=str, required=False, default="", help='folder to store all downloaded sources')
        return parser


    def federate(self, args):
        '''
        Federate data from multiple sources using a yaml config file
        '''
        config_file = args.config_file

        workspace_folder = None
        if args.workspace_folder is not None and args.workspace_folder != "":
            workspace_folder = args.workspace_folder

        # Check if the config file exists and is a valid yaml file before trying to federate
        if not os.path.exists(config_file):
            print(f"federate ERROR: {config_file} does not exist. Please check the filepath and try again.")
            return
        else:
            try:
                with open(config_file, 'r') as f:
                    data = f.read()
                config_data = yaml.safe_load(data)
            except yaml.YAMLError as e:
                print(f"Invalid YAML file {config_file}. Please check the yaml file and try again. Error {e}")
                return

        try:
            s = Sync()
            if workspace_folder is None:
                workspace_folder = config_data.get("workspace_folder", "dsi_data")
            print(f"Synchronizing data from {config_file} into {workspace_folder}\n")
            s.get(config_file, workspace_folder)
        except Exception as e:
            print(f"federate ERROR: {e}")
            return


    def find(self, args):
        '''
        Global find to see where the condition is met
        '''
        if not args:
            print("find ERROR: need to specify an object to find")
            return
        if len(args) > 1:
            print("find ERROR: need to wrap a multi-word search in quotes. Ex: find 'this is'")
            return
        query = args[0]

        if not isinstance(query, str):
            print("find ERROR: <condition> must be a string.")
            return
        operators = ['==', '!=', '>=', '<=', '=', '<', '>', '(', "~", "~~"]
        if not any(op in query for op in operators):
            print("find ERROR: <condition> must contain an operator. If just searching for a value, use the 'search' command.")
            return

        print(f"Finding all rows where '{query}'")
        output = None
        try:
            f = io.StringIO()
            with redirect_stdout(f):
                find_data = self.t.find_relation(query)
            output = f.getvalue()
        except Exception as e:
            e = str(e).replace("query_object", "condition")
            print(f"find ERROR: {e}")
            return

        if output and "WARNING" in output:
            warn_msg = output[output.find("WARNING"):]
            if "artifact_handler" in warn_msg:
                lines = warn_msg.splitlines()
                start = lines[1].find('`')
                between = lines[1][start + 1 : lines[1].find('`', start + 1)]
                lines[1] = lines[1].replace(between, "query")
                lines[2] = lines[2].replace(lines[2][lines[2].find('artifact'):-1], "`query`")
                warn_msg = '\n'.join(lines)
            elif "Could not find" in warn_msg:
                ending_ind = warn_msg.find("in this database")
                warn_msg = warn_msg[:40] + query + warn_msg[ending_ind-2:]
            print("\n"+warn_msg.replace("database", "backend"))
            return

        table_name = None
        output_df = None
        row_list = [f.row_num for f in find_data]
        for val in find_data:
            if table_name is None:
                table_name = val.t_name
                output_df = pd.DataFrame([val.value], columns=val.c_name)
            else:
                output_df.loc[len(output_df)] = val.value

        print(f'\nTable: {table_name}')
        output_df.insert(0, "row_index", row_list)
        self.t.table_print_helper(output_df.columns.tolist(), output_df.values.tolist(), output_df.shape[0])
        print()


    def list_tables(self, args):
        '''
        Lists the tables in the database
        '''
        try:
            self.t.list()
        except Exception as e:
            print(f"list ERROR: {e}")


    def ls(self, args):
        '''
        Lists contents of the current directory or specified path
        '''
        path = args[0] if args else '.'
        try:
            files = [file for file in os.listdir(path) if not file.startswith('.')]
            files = [file + '/' if os.path.isdir(os.path.join(path, file)) else file for file in files]
            files.sort()

            try:
                term_width = os.get_terminal_size().columns
            except OSError:
                term_width = 80
            col_width = max((len(file) for file in files), default=0) + 3
            num_cols = max(1, term_width // col_width)
            num_rows = (len(files) + num_cols - 1)// num_cols

            for row in range(num_rows):
                line = ''
                for col in range(num_cols):
                    idx = col * num_rows + row
                    if idx < len(files):
                        line += files[idx].ljust(col_width)
                print(line.rstrip())
            print()
        except FileNotFoundError:
            print(f"No such filepath: {path}")
            return
        except Exception as e:
            print(f"Error: {e}")
            return


    def get_plot_table_parser(self):
        parser = argparse.ArgumentParser(prog='plot_table')
        parser.add_argument('table_name', help='Table to plot')
        parser.add_argument('-f', '--filename', type=str, required=False, default="", help='Table plot filename')
        return parser


    def plot_table(self, args):
        '''
        Plot a table's numerical data and store in an image
        '''
        table_name = args.table_name
        filename = f"{table_name}_plot.png"
        if args.filename != "":
            filename = args.filename

        error = self.export_table("dsi_tb_" + table_name, filename)
        if error != 1:
            print(f"Saved a plot of the {table_name} table in {filename}")
        print()


    def get_query_parser(self):
        parser = argparse.ArgumentParser(prog='query')
        parser.add_argument('sql_query', help='SQL query (in quotes) to execute')
        parser.add_argument('-n', '--num_rows', type=int, required=False, help='Show first n rows of the table')
        parser.add_argument('-e', '--export', type=str, required=False, help='Export to csv or parquet file')
        return parser


    def query(self, args):
        '''
        Runs the query sent to it
        '''
        sql_query = args.sql_query
        num_rows = 25
        if args.num_rows is not None:
            num_rows = args.num_rows

        print(f"Printing the result from input SQL query: {sql_query}")

        try:
            data = self.t.artifact_handler(interaction_type='query', query = sql_query)
        except Exception as e:
            print(f"query ERROR: {e}")
            return
        if data.empty:
            print()
            return

        headers = data.columns.tolist()
        rows = data.values.tolist()
        self.t.table_print_helper(headers, rows, len(rows), num_rows)

        if args.export is not None:
            file_extension = args.export.rsplit(".", 1)[-1] if '.' in args.export else ''
            if file_extension.lower() not in ["csv", "pq", "parquet"]:
                filename = args.export + ".csv"
            else:
                filename = args.export
            self.t.active_metadata["temp_query"] = OrderedDict(data.to_dict(orient='list'))
            error = self.export_table("temp_query", filename)
            if error != 1:
                print()
                print(f"Exported the query result to {filename}")
        print()


    def get_read_parser(self):
        parser = argparse.ArgumentParser(prog='read')
        parser.add_argument('data_source', help='Data to read into DSI. Either a filename or a URL to the data')
        parser.add_argument('-t', '--table_name', type=str, required=False, default="", help='table name to store data into')
        return parser


    def read(self, args):
        '''
        Reads data file or a database into DSI

        Args:
            data_source (obj): name of the data source (file, database, URL, etc) to read
            table_name (str): name of the table to store the data within
        '''
        table_name = ""
        if args.table_name != "":
            table_name = args.table_name
        else:
            table_name = os.path.splitext(os.path.basename(args.data_source))[0]

        dbfile = args.data_source
        if self.__is_url(dbfile): # if it's a url, do fetch
            url = dbfile
            output_path = url.split('/')[-1]

            try:
                import ssl
                import urllib.request
                # Use certifi's trusted certificate bundle
                context = ssl._create_unverified_context()

                # Use urlopen instead of urlretrieve
                with urllib.request.urlopen(url, context=context) as response:
                    with open(output_path, 'wb') as out_file:
                        out_file.write(response.read())

                print(f"File downloaded successfully as {output_path}")
                dbfile = output_path

            except Exception as e:
                print(f"Download failed: {e}")
                return

        if not os.path.exists(dbfile):
            print("read ERROR: The input file must be a valid filepath. Please check again.")
            return

        file_extension = dbfile.rsplit(".", 1)[-1] if '.' in dbfile else ''
        fnull = open(os.devnull, 'w')
        try:
            with redirect_stdout(fnull):
                backend_name = self.t.identify_backend(dbfile)
                if backend_name:
                    self.t.load_module('backend',backend_name,'back-read', filename=dbfile)
                    self.t.artifact_handler(interaction_type="process")
                    self.t.unload_module('backend',backend_name,'back-read')
                elif file_extension.lower() == 'csv':
                    self.t.load_module('plugin', "Csv", "reader", filenames = dbfile, table_name = table_name)
                elif file_extension.lower() == 'toml':
                    self.t.load_module('plugin', "TOML", "reader", filenames = dbfile, table_name = table_name)
                elif file_extension.lower() in ['yaml', 'yml']:
                    self.t.load_module('plugin', "YAML", "reader", filenames = dbfile, table_name = table_name)
                elif file_extension.lower() == 'json':
                    self.t.load_module('plugin', "JSON", "reader", filenames = dbfile, table_name = table_name)
                elif file_extension.lower() in ['pq', 'parquet']:
                    self.t.load_module('plugin', "Parquet", "reader", filenames = dbfile, table_name = table_name)
        except Exception as e:
            print(f"read ERROR: {e}\n")
            self.t.active_metadata = OrderedDict()
            return

        if self.t.active_metadata:
            try:
                self.t.artifact_handler(interaction_type='ingest')
            except Exception as e:
                print(f"read ERROR: {e}")
                self.t.active_metadata = OrderedDict()
                return

            table_keys = [k for k in self.t.active_metadata if k not in ("dsi_relations", "dsi_units")]
            if len(table_keys) > 1:
                print(f"Loaded {dbfile} into the tables: {', '.join(table_keys)}")
            else:
                print(f"Loaded {dbfile} into the table {table_keys[0]}")

            self.t.num_tables()
            print()
            self.t.active_metadata = OrderedDict()
        else:
            print()
            print("Ensure input data is structured properly.")
            print("Supported formats: ")
            print("   - csv (extension: .csv)")
            print("   - json (extension: .json)")
            print("   - toml (extension: .toml)")
            print("   - yaml (extension: .yaml, .yml)")
            print("   - parquet (extension: .pq, .parquet)")
            print("   - sqlite (extension: .db, .sqlite, .sqlite3)")
            print("   - duckdb (extension: .duckdb, .db)\n")
            return


    def search(self, args):
        '''
        Global search to see where that value exists
        '''
        if not args:
            print("search ERROR: need to specify an object to search for")
            return
        if len(args) > 1:
            print("search ERROR: need to wrap a multi-word search in quotes. Ex: find 'this is'")
            return
        query = args[0]

        val = f"'{query}'" if isinstance(query, str) else query
        print(f"Searching for all instances of {val} in the active backend")

        fnull = open(os.devnull, 'w')
        try:
            with redirect_stdout(fnull):
                find_data = self.t.find_cell(query, row=True)
        except Exception as e:
            print(f"search ERROR: {e}")
            return

        if find_data is None:
            print(f"WARNING: {val} was not found in this backend\n")
            return
        print()
        for val in find_data:
            print(f"Table: {val.t_name}")
            print(f"  - Columns: {val.c_name}")
            print(f"  - Row Number: {val.row_num}")
            print(f"  - Data: {val.value}")
        print()


    def get_summary_parser(self):
        parser = argparse.ArgumentParser(prog='summary')
        parser.add_argument('-t', '--table', type=str, required=False, help='Show only this table')
        return parser


    def summary(self, args):
        '''
        Get the summary of a table or database
        '''
        table_name = None
        if args.table is not None:
            table_name = args.table

        try:
            self.t.summary(table_name)
        except Exception as e:
            print(f"summary ERROR: {e}")
        print()


    def version(self):
        '''
        Output the version of DSI being used
        '''
        return str(__version__)


    def viewers(self, args):
        if self.valid_viewers is None:
            print("There are no available viewers. Install requirements.heavy.txt to access them.")
            for v, p in self.all_viewers.items():
                print(f"  {v:<12}: pip install {' '.join(p)}")
            print()
            return
        print(f'Available viewers are: {", ".join(self.valid_viewers)}\n')


    def view(self, args):
        if not args:
            if self.valid_viewers is not None:
                print(f"view ERROR: need to specify a DSI viewer to use. Available: {', '.join(self.valid_viewers)}")
            else:
                print("view ERROR: need to specify a DSI viewer to use")
            return
        
        viewer = str(args[0]).lower()
        if viewer not in self.all_viewers.keys():
            print("view ERROR: This viewer does not exist.")
            return
        if len(set(args) & set(self.all_viewers.keys())) > 1:
            print("view ERROR: can only use one viewer at a time")
            return
        if viewer not in self.valid_viewers:
            print(f"view ERROR: To load the {viewer} viewer, pip install {' '.join(self.all_viewers[viewer])}")
            return
        
        if os.name != 'nt':
            bash_script_filepath = os.path.join(os.path.dirname(__file__),"utils","launch_streamlit.sh")
        else:
            bash_script_filepath = os.path.join(os.path.dirname(__file__),"utils","launch_streamlit.bat")

        if viewer == "dashboard":
            # user must specify at least one directory
            if len(args) == 1:
                print("view ERROR: dashboard viewer requires at least one input directory.")
                return
            # check if other inputs are valid folder paths
            for f in args[1:]:
                if not os.path.isdir(f):
                    print(f"view ERROR: dashboard viewer has an invalid input directory: {f}")
                    return
                
            if os.name != 'nt':
                subprocess.run(["chmod", "+x", bash_script_filepath], check=True)

            env = dict(os.environ)
            dashboard_code_filepath = os.path.join(os.path.dirname(__file__),"plugins","dashboard.py")
            bash_command = [bash_script_filepath, dashboard_code_filepath] + args[1:]
            with subprocess.Popen(bash_command, env=env, start_new_session=True, text=True, 
                                  stdout=subprocess.PIPE, stderr=subprocess.DEVNULL) as proc:
                try:
                    is_remote = False
                    for idx, line in enumerate(proc.stdout):
                        if idx == 0 and line == "remote\n":
                            is_remote = True
                        if is_remote:
                            if idx in [1, 2] or idx > 9:
                                print(line[:-1])
                            if idx == 3:
                                print(" (Leave the new terminal running while using the Dashboard)")
                                print("\nView the Dashboard at", line[:-1])
                                print("To exit, press [Ctrl + C] here")
                        else:
                            if idx == 4:
                                print("\nView the Dashboard at", line[line.index("http"):-1])
                                print("To exit, press [Ctrl + C] here")
                            elif idx>12:
                                print(line[:-1])
                except KeyboardInterrupt:
                    print("\nClosing Dashboard.\n")
                    os.killpg(proc.pid, signal.SIGTERM)
                    try:
                        proc.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        os.killpg(proc.pid, signal.SIGKILL)
                        proc.wait()

        elif viewer == "ml":
            #check if current db is empty
            if not self.t.valid_backend(self.t.loaded_backends[0]):
                print("view ERROR: the ML viewer requires data to run models.")
                return
            
            if os.name != 'nt':
                subprocess.run(["chmod", "+x", bash_script_filepath], check=True)
            
            env = dict(os.environ)
            ml_code_filepath = os.path.join(os.path.dirname(__file__),"plugins","ml_emulator.py")
            bash_command = [bash_script_filepath, ml_code_filepath, self.db_path, self.name]
            with subprocess.Popen(bash_command, env=env, start_new_session=True, text=True, 
                                  stdout=subprocess.PIPE, stderr=subprocess.DEVNULL) as proc:
                try:
                    is_remote = False
                    for idx, line in enumerate(proc.stdout):
                        if idx == 0 and line == "remote\n":
                            is_remote = True
                        if is_remote:
                            if idx in [1, 2] or idx > 9:
                                print(line[:-1])
                            if idx == 3:
                                print(" (Leave the new terminal running while using the Emulator)")
                                print("\nView the ML emulator at", line[:-1])
                                print("To exit, press [Ctrl + C] here")
                        else:
                            if idx == 4:
                                print("\nView the ML emulator at", line[line.index("http"):-1])
                                print("To exit, press [Ctrl + C] here")
                            elif idx>12:
                                print(line[:-1])
                except KeyboardInterrupt:
                    print("\n Closing ML Emulator.\n")
                    os.killpg(proc.pid, signal.SIGTERM)
                    try:
                        proc.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        os.killpg(proc.pid, signal.SIGKILL)
                        proc.wait()
            
        else:
            print("view ERROR: input viewer was invalid. Please try again.")
            return


    def get_write_parser(self):
        parser = argparse.ArgumentParser(prog='write')
        parser.add_argument('filename', help='file DSI data will be written to')
        return parser


    def write_to_file(self, args):
        '''
        Writes the database to file
        '''
        new_name = args.filename
        file_extension = new_name.rsplit(".", 1)[-1] if '.' in new_name else ''
        dsi_db_path = os.path.join(self.start_dir, ".temp_dsi.db")
        final_name = None
        if "sqlite" == self.name:
            if file_extension.lower() in ["db", "sqlite", "sqlite3"]:
                shutil.copyfile(dsi_db_path, os.path.join(self.start_dir, new_name))
                final_name = new_name
            else:
                shutil.copyfile(dsi_db_path, os.path.join(self.start_dir, new_name) + ".sqlite")
                final_name = new_name + ".sqlite"
        elif "duckdb" == self.name:
            if file_extension.lower() in ["db", "duckdb"]:
                shutil.copyfile(dsi_db_path, os.path.join(self.start_dir, new_name))
                final_name = new_name
            else:
                shutil.copyfile(dsi_db_path, os.path.join(self.start_dir, new_name) + ".duckdb")
                final_name = new_name + ".duckdb"
        print(f"Successfully wrote all data to {final_name}\n")
    

    def __is_url(self, s):
        '''
        Checks if the string is a url link

        Args:
            s (str): string to check
        '''
        try:
            from urllib.parse import urlparse
            result = urlparse(s)
            return all([result.scheme, result.netloc])
        except ValueError:
            return False


cli = DSI_cli()

COMMANDS = {
    'clear': (None, cli.clear),
    'display' : (cli.get_display_parser, cli.display),
    'draw' : (cli.get_draw_parser, cli.draw_schema),
    'exit': (None, cli.exit_cli),
    'federate' : (cli.get_federate_parser, cli.federate),
    'find' : (None, cli.find),
    'help': (None, cli.help_fn),
    'list' : (None, cli.list_tables),
    'plot_table' : (cli.get_plot_table_parser, cli.plot_table),
    'query' : (cli.get_query_parser, cli.query),
    'read' : (cli.get_read_parser, cli.read),
    'search' : (None, cli.search),
    'summary' : (cli.get_summary_parser, cli.summary),
    'viewers' : (None, cli.viewers),
    'view' : (None, cli.view),
    'write' : (cli.get_write_parser, cli.write_to_file),
    'ls' : (None, cli.ls),
    'cd' : (None, cli.cd)
}

def main():
    if sys.argv[1:] and sys.argv[1].lower() == "help":
        cli.help_fn([])
        exit(0)

    parser = argparse.ArgumentParser()
    parser.add_argument("-b", "--backend", type=str, default="sqlite", help="Supported backends are sqlite, duckdb, and ndp")

    args = parser.parse_args()
    if args.backend.lower() not in ["sqlite", "duckdb", "ndp"]:
        print("ERROR: Invalid backend input. Valid backends are: sqlite, duckdb, and ndp")
        exit(1)
    print("   ", textwrap.dedent(fr"""
         _____           ___
        /  /  \         /  /\         ___
       /  / /\ \       /  / /_       /  /\
      /  / /  \ \     /  / / /\     /  / /
     /__/ / \__\ |   /  / / /  \   /__/  \
     \  \ \ /  / /  /__/ / / /\ \  \__\/\ \__
      \  \ \  / /   \  \ \/ / / /     \  \ \/\
       \  \ \/ /     \  \  / / /       \__\  /
        \  \  /       \__\/ / /        /__/ /
         \__\/          /__/ /         \__\/
                        \__\/                   v{cli.version()}
    """).strip())
    print()
    cli.startup(args.backend)
    print("\nEnter \"help\" for usage hints.")

    while True:
        try:
            user_input = input("dsi> ")
            tokens = shlex.split(user_input)
            if not tokens:
                continue

            command, *args = tokens

            if command not in COMMANDS:
                print("Unknown command. Type \"help\" to see valid commands.\n")
                continue

            parser_factory, handler = COMMANDS[command]

            if parser_factory:
                parser = parser_factory()
                try:
                    parsed_args = parser.parse_args(args)
                    handler(parsed_args)
                except SystemExit:
                    pass # argparse tries to exit on error — suppress that in shell
            else:
                handler(args)

        except KeyboardInterrupt:
            cli.exit_cli([])
        except EOFError:
            print()
            cli.exit_cli([])
        except Exception as e:
            print(f"Error: {e}\n")


if __name__ == "__main__":
    main()
