from datetime import date

from yardmaster.core.version import EPOCH_BASE_DATE, Version, days_since_epoch


def test_version_parse_three_part() -> None:
    v = Version.parse("1.2.3")
    assert (v.epoch, v.stream, v.revision) == (1, 2, 3)
    assert str(v) == "1.2.3"


def test_version_parse_default_revision() -> None:
    v = Version(epoch=1, stream=2)
    assert (v.epoch, v.stream, v.revision) == (1, 2, 0)
    assert str(v) == "1.2.0"


def test_days_since_epoch_known_date() -> None:
    assert days_since_epoch(date(2013, 7, 1)) == 0
    assert days_since_epoch(date(2013, 7, 2)) == 1
    assert days_since_epoch(date(2026, 4, 13)) == 4669


def test_epoch_base_date() -> None:
    assert EPOCH_BASE_DATE == date(2013, 7, 1)
