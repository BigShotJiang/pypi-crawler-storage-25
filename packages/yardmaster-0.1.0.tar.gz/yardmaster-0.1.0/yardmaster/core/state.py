from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

DEFAULT_STATE_FILE = ".yardmaster/release.json"


def resolve_state_path(config: Any | None = None) -> Path:
    """Return the state file path from config, or the default."""
    if config is not None and hasattr(config, "paths"):
        return Path(config.paths.state_file)
    return Path(DEFAULT_STATE_FILE)


def load_release_state(state_path: Path) -> dict[str, Any]:
    if not state_path.exists():
        raise FileNotFoundError(f"Release state not found: {state_path}")
    state: dict[str, Any] = json.loads(state_path.read_text(encoding="utf-8"))
    return state


def save_release_state(state: dict[str, Any], state_path: Path) -> None:
    state_path.parent.mkdir(parents=True, exist_ok=True)
    state_path.write_text(json.dumps(state, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def update_release_state(status: str, state_path: Path) -> None:
    state = load_release_state(state_path)
    state["status"] = status
    state["updated_at"] = datetime.now(timezone.utc).isoformat()
    save_release_state(state, state_path)


def get_completed_steps(state_path: Path) -> list[str]:
    if not state_path.exists():
        return []
    state = load_release_state(state_path)
    steps = state.get("completed_steps", [])
    return steps if isinstance(steps, list) else []


def mark_step_completed(step_name: str, state_path: Path) -> None:
    state = load_release_state(state_path)
    completed = state.get("completed_steps", [])
    if not isinstance(completed, list):
        completed = []
    if step_name not in completed:
        completed.append(step_name)
    state["completed_steps"] = completed
    state["updated_at"] = datetime.now(timezone.utc).isoformat()
    save_release_state(state, state_path)
