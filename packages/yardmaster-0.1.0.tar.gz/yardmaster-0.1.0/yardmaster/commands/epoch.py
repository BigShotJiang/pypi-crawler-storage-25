from __future__ import annotations

from datetime import date

import click
from rich.console import Console

from yardmaster.core.version import EPOCH_BASE_DATE, days_since_epoch

console = Console()


@click.command(help="Show the alpha epoch for a given date (default: today).")
@click.argument("date_str", required=False, default=None)
def epoch_command(date_str: str | None) -> None:
    if date_str is not None:
        try:
            target = date.fromisoformat(date_str)
        except ValueError:
            console.print(f"[red]Invalid date '{date_str}'. Use YYYY-MM-DD format.[/red]")
            raise SystemExit(1)
    else:
        target = date.today()

    epoch = days_since_epoch(target)
    console.print(f"Base date:  {EPOCH_BASE_DATE}")
    console.print(f"Target:     {target}")
    console.print(f"Epoch:      [bold green]{epoch}[/bold green]")
