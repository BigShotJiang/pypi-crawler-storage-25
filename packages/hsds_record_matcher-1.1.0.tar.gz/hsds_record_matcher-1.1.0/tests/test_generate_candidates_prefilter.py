"""Tests for candidate overlap prefilter behavior."""

from __future__ import annotations

import polars as pl
import pytest

import hsds_entity_resolution.core.generate_candidates as generate_candidates_module
from hsds_entity_resolution.config import EntityResolutionRunConfig
from hsds_entity_resolution.core.generate_candidates import generate_candidates


def test_generate_candidates_rejects_taxonomy_only_overlap() -> None:
    """Taxonomy-only overlap should not pass without non-taxonomy evidence."""
    config = EntityResolutionRunConfig.defaults_for_entity_type(
        team_id="team-taxonomy",
        scope_id="scope-taxonomy",
        entity_type="organization",
    )
    organization_entities = _organization_frame(
        taxonomies=[[{"code": "101-201-301"}], [{"code": "101-201"}]],
        locations=[[], []],
    )
    result = generate_candidates(
        denormalized_organization=organization_entities,
        denormalized_service=_empty_entity_frame(),
        changed_entities=_changed_entities("organization"),
        config=config,
        explicit_backfill=False,
    )

    assert result.candidate_pairs.is_empty()


def test_generate_candidates_keeps_parent_taxonomy_overlap() -> None:
    """Parent-child HSIS taxonomy matches still need non-taxonomy evidence."""
    config = EntityResolutionRunConfig.defaults_for_entity_type(
        team_id="team-taxonomy-parent",
        scope_id="scope-taxonomy-parent",
        entity_type="organization",
    )
    organization_entities = _organization_frame(
        taxonomies=[[{"code": "BD"}], [{"code": "B"}]],
        locations=[[], []],
    )
    result = generate_candidates(
        denormalized_organization=organization_entities,
        denormalized_service=_empty_entity_frame(),
        changed_entities=_changed_entities("organization"),
        config=config,
        explicit_backfill=False,
    )

    assert result.candidate_pairs.is_empty()


def test_generate_candidates_rejects_location_only_overlap() -> None:
    """Location-only overlap should not pass without taxonomy evidence."""
    config = EntityResolutionRunConfig.defaults_for_entity_type(
        team_id="team-location",
        scope_id="scope-location",
        entity_type="organization",
    )
    organization_entities = _organization_frame(
        taxonomies=[[], []],
        locations=[
            [{"city": "Chicago", "state": "IL"}],
            [{"city": "chicago", "state": "il"}],
        ],
    )
    result = generate_candidates(
        denormalized_organization=organization_entities,
        denormalized_service=_empty_entity_frame(),
        changed_entities=_changed_entities("organization"),
        config=config,
        explicit_backfill=False,
    )

    assert result.candidate_pairs.is_empty()


def test_generate_candidates_rejects_taxonomy_overlap_for_mixed_shapes() -> None:
    """Legacy taxonomy variants still need non-taxonomy evidence to pass blocking."""
    config = EntityResolutionRunConfig.defaults_for_entity_type(
        team_id="team-taxonomy-mixed",
        scope_id="scope-taxonomy-mixed",
        entity_type="organization",
    )
    organization_entities = _organization_frame(
        taxonomies=[
            [{"CODE": "261Q00000X"}],
            ["261q00000x"],
        ],
        locations=[[], []],
    )
    result = generate_candidates(
        denormalized_organization=organization_entities,
        denormalized_service=_empty_entity_frame(),
        changed_entities=_changed_entities("organization"),
        config=config,
        explicit_backfill=False,
    )

    assert result.candidate_pairs.is_empty()


def test_generate_candidates_respects_configured_overlap_channels() -> None:
    """Configured prefilter channels should control candidate retention behavior."""
    payload = EntityResolutionRunConfig.defaults_for_entity_type(
        team_id="team-config",
        scope_id="scope-config",
        entity_type="organization",
    ).model_dump()
    payload["blocking"]["overlap_prefilter_channels"] = ["email"]
    config = EntityResolutionRunConfig.model_validate(payload)
    organization_entities = _organization_frame(
        taxonomies=[[{"code": "T101"}], [{"code": "T101"}]],
        locations=[[], []],
    )
    result = generate_candidates(
        denormalized_organization=organization_entities,
        denormalized_service=_empty_entity_frame(),
        changed_entities=_changed_entities("organization"),
        config=config,
        explicit_backfill=False,
    )

    assert result.candidate_pairs.is_empty()


def test_generate_candidates_rejects_domain_overlap_for_url_variants_without_taxonomy() -> None:
    """Website overlap alone should not pass when taxonomy is mandatory."""
    config = EntityResolutionRunConfig.defaults_for_entity_type(
        team_id="team-domain",
        scope_id="scope-domain",
        entity_type="organization",
    )
    organization_entities = _organization_frame(
        taxonomies=[[], []],
        locations=[[], []],
        websites=[
            ["https://www.alpha.org/about"],
            ["http://alpha.org/contact"],
        ],
    )
    result = generate_candidates(
        denormalized_organization=organization_entities,
        denormalized_service=_empty_entity_frame(),
        changed_entities=_changed_entities("organization"),
        config=config,
        explicit_backfill=False,
    )

    assert result.candidate_pairs.is_empty()


def test_generate_candidates_rejects_domain_overlap_for_email_and_website() -> None:
    """Domain overlap alone should not pass when taxonomy is mandatory."""
    config = EntityResolutionRunConfig.defaults_for_entity_type(
        team_id="team-domain-mixed",
        scope_id="scope-domain-mixed",
        entity_type="organization",
    )
    organization_entities = _organization_frame(
        taxonomies=[[], []],
        locations=[[], []],
        emails=[["hello@alpha.org"], []],
        websites=[[], ["https://www.alpha.org/path"]],
    )
    result = generate_candidates(
        denormalized_organization=organization_entities,
        denormalized_service=_empty_entity_frame(),
        changed_entities=_changed_entities("organization"),
        config=config,
        explicit_backfill=False,
    )

    assert result.candidate_pairs.is_empty()


def test_generate_candidates_contact_overlap_keeps_address_below_threshold() -> None:
    """Exact address overlap should create a candidate even below embedding threshold."""
    config = EntityResolutionRunConfig.defaults_for_entity_type(
        team_id="team-contact-address",
        scope_id="scope-contact-address",
        entity_type="organization",
    )
    organization_entities = _address_overlap_frame(
        ["SOURCE_A", "SOURCE_B"],
        embedding_vectors=[[1.0, 0.0], [0.0, 1.0]],
    )

    result = generate_candidates(
        denormalized_organization=organization_entities,
        denormalized_service=_empty_entity_frame(),
        changed_entities=_changed_entities("organization"),
        config=config,
        explicit_backfill=False,
    )

    row = result.candidate_pairs.row(0, named=True)
    assert result.candidate_pairs.height == 1
    assert row["embedding_similarity"] == 0.0
    assert row["blocking_rule_id"] == "default_contact_overlap"
    assert row["candidate_reason_codes"] == ["contact_overlap", "shared_address"]


def test_generate_candidates_contact_overlap_keeps_phone_below_embedding_threshold() -> None:
    """Exact phone overlap should create a candidate even below embedding threshold."""
    config = EntityResolutionRunConfig.defaults_for_entity_type(
        team_id="team-contact-phone",
        scope_id="scope-contact-phone",
        entity_type="organization",
    )
    organization_entities = _organization_frame(
        taxonomies=[[], []],
        locations=[[], []],
        phones=[["5550100"], ["5550100"]],
    ).with_columns(pl.Series("embedding_vector", [[1.0, 0.0], [0.0, 1.0]]))

    result = generate_candidates(
        denormalized_organization=organization_entities,
        denormalized_service=_empty_entity_frame(),
        changed_entities=_changed_entities("organization"),
        config=config,
        explicit_backfill=False,
    )

    row = result.candidate_pairs.row(0, named=True)
    assert result.candidate_pairs.height == 1
    assert row["blocking_rule_id"] == "default_contact_overlap"
    assert row["candidate_reason_codes"] == ["contact_overlap", "shared_phone"]


def test_generate_candidates_contact_overlap_keeps_email_below_embedding_threshold() -> None:
    """Exact email overlap should create a candidate even below embedding threshold."""
    config = EntityResolutionRunConfig.defaults_for_entity_type(
        team_id="team-contact-email",
        scope_id="scope-contact-email",
        entity_type="organization",
    )
    organization_entities = _organization_frame(
        taxonomies=[[], []],
        locations=[[], []],
        emails=[["hello@north.org"], ["hello@north.org"]],
    ).with_columns(pl.Series("embedding_vector", [[1.0, 0.0], [0.0, 1.0]]))

    result = generate_candidates(
        denormalized_organization=organization_entities,
        denormalized_service=_empty_entity_frame(),
        changed_entities=_changed_entities("organization"),
        config=config,
        explicit_backfill=False,
    )

    row = result.candidate_pairs.row(0, named=True)
    assert result.candidate_pairs.height == 1
    assert row["blocking_rule_id"] == "default_contact_overlap"
    assert row["candidate_reason_codes"] == ["contact_overlap", "shared_email"]


def test_generate_candidates_contact_overlap_keeps_gov_website_domain_below_threshold() -> None:
    """Shared registrable .gov website domains should bypass embedding."""
    config = EntityResolutionRunConfig.defaults_for_entity_type(
        team_id="team-contact-gov",
        scope_id="scope-contact-gov",
        entity_type="service",
    )
    service_entities = _service_frame(
        source_schemas=["SOURCE_A", "SOURCE_B"],
        taxonomies=[[], []],
        locations=[[], []],
        websites=[
            ["https://healthcare.gov/get-coverage/"],
            ["https://localhelp.healthcare.gov/search"],
        ],
    ).with_columns(pl.Series("embedding_vector", [[1.0, 0.0], [0.0, 1.0]]))

    result = generate_candidates(
        denormalized_organization=_empty_entity_frame(),
        denormalized_service=service_entities,
        changed_entities=_changed_entities("service"),
        config=config,
        explicit_backfill=False,
    )

    row = result.candidate_pairs.row(0, named=True)
    assert result.candidate_pairs.height == 1
    assert row["blocking_rule_id"] == "default_contact_overlap"
    assert row["candidate_reason_codes"] == ["contact_overlap", "shared_gov_domain"]


def test_generate_candidates_non_gov_website_overlap_does_not_bypass_embedding() -> None:
    """Non-.gov website overlap should not create below-threshold candidates by itself."""
    config = EntityResolutionRunConfig.defaults_for_entity_type(
        team_id="team-contact-non-gov",
        scope_id="scope-contact-non-gov",
        entity_type="organization",
    )
    organization_entities = _organization_frame(
        taxonomies=[[], []],
        locations=[[], []],
        websites=[["https://alpha.org/help"], ["https://www.alpha.org/contact"]],
    ).with_columns(pl.Series("embedding_vector", [[1.0, 0.0], [0.0, 1.0]]))

    result = generate_candidates(
        denormalized_organization=organization_entities,
        denormalized_service=_empty_entity_frame(),
        changed_entities=_changed_entities("organization"),
        config=config,
        explicit_backfill=False,
    )

    assert result.candidate_pairs.is_empty()


def test_generate_candidates_email_to_website_domain_does_not_bypass_embedding() -> None:
    """Email-domain to website-domain overlap is scoring evidence, not a candidate bypass."""
    config = EntityResolutionRunConfig.defaults_for_entity_type(
        team_id="team-contact-email-website",
        scope_id="scope-contact-email-website",
        entity_type="organization",
    )
    organization_entities = _organization_frame(
        taxonomies=[[], []],
        locations=[[], []],
        emails=[["hello@medicare.gov"], []],
        websites=[[], ["https://medicare.gov"]],
    ).with_columns(pl.Series("embedding_vector", [[1.0, 0.0], [0.0, 1.0]]))

    result = generate_candidates(
        denormalized_organization=organization_entities,
        denormalized_service=_empty_entity_frame(),
        changed_entities=_changed_entities("organization"),
        config=config,
        explicit_backfill=False,
    )

    assert result.candidate_pairs.is_empty()


def test_generate_candidates_location_only_does_not_bypass_embedding() -> None:
    """City/state-only location overlap remains insufficient below embedding threshold."""
    config = EntityResolutionRunConfig.defaults_for_entity_type(
        team_id="team-contact-location",
        scope_id="scope-contact-location",
        entity_type="organization",
    )
    organization_entities = _organization_frame(
        taxonomies=[[], []],
        locations=[
            [{"city": "Chicago", "state": "IL"}],
            [{"city": "Chicago", "state": "IL"}],
        ],
    ).with_columns(pl.Series("embedding_vector", [[1.0, 0.0], [0.0, 1.0]]))

    result = generate_candidates(
        denormalized_organization=organization_entities,
        denormalized_service=_empty_entity_frame(),
        changed_entities=_changed_entities("organization"),
        config=config,
        explicit_backfill=False,
    )

    assert result.candidate_pairs.is_empty()


def test_generate_candidates_embedding_and_contact_routes_merge_reasons() -> None:
    """Embedding and contact routes should produce one canonical pair with merged reasons."""
    config = EntityResolutionRunConfig.defaults_for_entity_type(
        team_id="team-contact-merge",
        scope_id="scope-contact-merge",
        entity_type="organization",
    )
    organization_entities = _organization_frame(
        taxonomies=[[{"code": "BD"}], [{"code": "BD"}]],
        locations=[[], []],
        emails=[["hello@north.org"], ["hello@north.org"]],
    )

    result = generate_candidates(
        denormalized_organization=organization_entities,
        denormalized_service=_empty_entity_frame(),
        changed_entities=_changed_entities("organization"),
        config=config,
        explicit_backfill=False,
    )

    row = result.candidate_pairs.row(0, named=True)
    assert result.candidate_pairs.height == 1
    assert row["blocking_rule_id"] == "default_contact_overlap"
    assert row["candidate_reason_codes"] == [
        "contact_overlap",
        "embedding_threshold",
        "shared_domain",
        "shared_email",
        "shared_taxonomy",
    ]


def test_generate_candidates_keeps_exact_taxonomy_plus_email_overlap() -> None:
    """Exact taxonomy plus email overlap should pass the combined gate."""
    config = EntityResolutionRunConfig.defaults_for_entity_type(
        team_id="team-taxonomy-email",
        scope_id="scope-taxonomy-email",
        entity_type="organization",
    )
    organization_entities = _organization_frame(
        taxonomies=[[{"code": "BD"}], [{"code": "BD"}]],
        locations=[[], []],
        emails=[["hello@north.org"], ["hello@north.org"]],
    )
    result = generate_candidates(
        denormalized_organization=organization_entities,
        denormalized_service=_empty_entity_frame(),
        changed_entities=_changed_entities("organization"),
        config=config,
        explicit_backfill=False,
    )

    assert result.candidate_pairs.height == 1
    reason_codes = result.candidate_pairs.row(0, named=True)["candidate_reason_codes"]
    assert "shared_taxonomy" in reason_codes
    assert "shared_email" in reason_codes


def test_generate_candidates_keeps_parent_taxonomy_plus_location_overlap() -> None:
    """Parent-child taxonomy plus location overlap should pass the combined gate."""
    config = EntityResolutionRunConfig.defaults_for_entity_type(
        team_id="team-taxonomy-location",
        scope_id="scope-taxonomy-location",
        entity_type="organization",
    )
    organization_entities = _organization_frame(
        taxonomies=[[{"code": "BD"}], [{"code": "B"}]],
        locations=[
            [{"city": "Chicago", "state": "IL"}],
            [{"city": "Chicago", "state": "IL"}],
        ],
    )
    result = generate_candidates(
        denormalized_organization=organization_entities,
        denormalized_service=_empty_entity_frame(),
        changed_entities=_changed_entities("organization"),
        config=config,
        explicit_backfill=False,
    )

    assert result.candidate_pairs.height == 1
    reason_codes = result.candidate_pairs.row(0, named=True)["candidate_reason_codes"]
    assert "shared_taxonomy" in reason_codes
    assert "shared_location" in reason_codes


def test_generate_candidates_keeps_taxonomy_plus_phone_overlap() -> None:
    """Taxonomy plus phone overlap should pass the combined gate."""
    config = EntityResolutionRunConfig.defaults_for_entity_type(
        team_id="team-taxonomy-phone",
        scope_id="scope-taxonomy-phone",
        entity_type="organization",
    )
    organization_entities = _organization_frame(
        taxonomies=[[{"code": "BD"}], [{"code": "BD"}]],
        locations=[[], []],
        phones=[["555-0100"], ["555-0100"]],
    )
    result = generate_candidates(
        denormalized_organization=organization_entities,
        denormalized_service=_empty_entity_frame(),
        changed_entities=_changed_entities("organization"),
        config=config,
        explicit_backfill=False,
    )

    assert result.candidate_pairs.height == 1
    reason_codes = result.candidate_pairs.row(0, named=True)["candidate_reason_codes"]
    assert "shared_taxonomy" in reason_codes
    assert "shared_phone" in reason_codes


def test_generate_candidates_keeps_sibling_taxonomy_pair_with_exact_email_overlap() -> None:
    """Exact email overlap now creates a candidate even when taxonomy is sibling-only."""
    config = EntityResolutionRunConfig.defaults_for_entity_type(
        team_id="team-taxonomy-sibling",
        scope_id="scope-taxonomy-sibling",
        entity_type="organization",
    )
    organization_entities = _organization_frame(
        taxonomies=[[{"code": "BD"}], [{"code": "BF"}]],
        locations=[[], []],
        emails=[["hello@north.org"], ["hello@north.org"]],
    )
    result = generate_candidates(
        denormalized_organization=organization_entities,
        denormalized_service=_empty_entity_frame(),
        changed_entities=_changed_entities("organization"),
        config=config,
        explicit_backfill=False,
    )

    row = result.candidate_pairs.row(0, named=True)
    assert result.candidate_pairs.height == 1
    assert row["blocking_rule_id"] == "default_contact_overlap"
    assert row["candidate_reason_codes"] == ["contact_overlap", "shared_email"]


def test_generate_candidates_keeps_grandparent_taxonomy_pair_with_exact_email_overlap() -> None:
    """Exact email overlap now creates a candidate even when taxonomy is too broad."""
    config = EntityResolutionRunConfig.defaults_for_entity_type(
        team_id="team-taxonomy-grandparent",
        scope_id="scope-taxonomy-grandparent",
        entity_type="organization",
    )
    organization_entities = _organization_frame(
        taxonomies=[[{"code": "B"}], [{"code": "BD-1800"}]],
        locations=[[], []],
        emails=[["hello@north.org"], ["hello@north.org"]],
    )
    result = generate_candidates(
        denormalized_organization=organization_entities,
        denormalized_service=_empty_entity_frame(),
        changed_entities=_changed_entities("organization"),
        config=config,
        explicit_backfill=False,
    )

    row = result.candidate_pairs.row(0, named=True)
    assert result.candidate_pairs.height == 1
    assert row["blocking_rule_id"] == "default_contact_overlap"
    assert row["candidate_reason_codes"] == ["contact_overlap", "shared_email"]


def test_generate_candidates_keeps_taxonomy_plus_domain_overlap_for_email_and_website() -> None:
    """Taxonomy plus domain overlap should pass even across email-vs-website evidence."""
    config = EntityResolutionRunConfig.defaults_for_entity_type(
        team_id="team-taxonomy-domain-mixed",
        scope_id="scope-taxonomy-domain-mixed",
        entity_type="organization",
    )
    organization_entities = _organization_frame(
        taxonomies=[[{"code": "BD"}], [{"code": "BD"}]],
        locations=[[], []],
        emails=[["hello@alpha.org"], []],
        websites=[[], ["https://www.alpha.org/path"]],
    )
    result = generate_candidates(
        denormalized_organization=organization_entities,
        denormalized_service=_empty_entity_frame(),
        changed_entities=_changed_entities("organization"),
        config=config,
        explicit_backfill=False,
    )

    assert result.candidate_pairs.height == 1
    reason_codes = result.candidate_pairs.row(0, named=True)["candidate_reason_codes"]
    assert "shared_taxonomy" in reason_codes
    assert "shared_domain" in reason_codes


def test_generate_candidates_logs_blocking_overview_summary(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Generate-candidates should emit one info summary for coarse blocking tuning."""

    class _FakeLogger:
        def __init__(self) -> None:
            self.info_messages: list[str] = []
            self.debug_messages: list[str] = []

        def info(self, message: str, *args: object) -> None:
            self.info_messages.append(message % args if args else message)

        def debug(self, message: str, *args: object) -> None:
            self.debug_messages.append(message % args if args else message)

    logger = _FakeLogger()
    monkeypatch.setattr(generate_candidates_module, "get_dagster_logger", lambda: logger)

    payload = EntityResolutionRunConfig.defaults_for_entity_type(
        team_id="team-overview",
        scope_id="scope-overview",
        entity_type="organization",
    ).model_dump()
    payload["blocking"]["max_candidates_per_entity"] = 1
    config = EntityResolutionRunConfig.model_validate(payload)
    organization_entities = pl.DataFrame(
        {
            "entity_id": ["org-a", "org-b", "org-c", "org-d"],
            "entity_type": ["organization"] * 4,
            "source_schema": ["SOURCE_A"] * 4,
            "name": ["A", "B", "C", "D"],
            "description": ["", "", "", ""],
            "emails": [
                ["shared@north.org"],
                [],
                ["shared@north.org"],
                [],
            ],
            "phones": [[], [], [], []],
            "websites": [[], [], [], []],
            "locations": [[], [], [], []],
            "taxonomies": [
                [{"code": "BD"}],
                [{"code": "BD"}],
                [{"code": "BD"}],
                [{"code": "ZZ"}],
            ],
            "identifiers": [[], [], [], []],
            "services_rollup": [[], [], [], []],
            "organization_name": ["", "", "", ""],
            "organization_id": ["", "", "", ""],
            "embedding_vector": [
                [1.0, 0.0],
                [0.999, 0.001],
                [0.998, 0.002],
                [0.0, 1.0],
            ],
            "content_hash": ["hash-a", "hash-b", "hash-c", "hash-d"],
        }
    )

    _ = generate_candidates(
        denormalized_organization=organization_entities,
        denormalized_service=_empty_entity_frame(),
        changed_entities=_changed_entities("organization"),
        config=config,
        explicit_backfill=False,
    )

    assert logger.info_messages
    overview_message = logger.info_messages[-1]
    assert overview_message.startswith("ℹ️ generate_candidates_overview")
    assert "threshold=0.750" in overview_message
    assert "max_candidates_per_entity=1" in overview_message
    assert "anchors_at_cap=1 (100.0%)" in overview_message
    assert "heuristic=max_candidates_may_be_low" in overview_message


def test_generate_candidates_policy_admits_exact_address_without_taxonomy() -> None:
    """Source policy can admit exact-address pairs without requiring taxonomy overlap."""
    config = _source_policy_config(
        relation="cross_source_same_profile",
        rule_id="address-only-cross-source-shared-profile",
    )
    organization_entities = _address_overlap_frame(["SOURCE_A", "SOURCE_B"])

    result = generate_candidates(
        denormalized_organization=organization_entities,
        denormalized_service=_empty_entity_frame(),
        changed_entities=_changed_entities("organization"),
        config=config,
        explicit_backfill=False,
    )

    assert result.candidate_pairs.height == 1
    row = result.candidate_pairs.row(0, named=True)
    assert row["blocking_rule_id"] == "address-only-cross-source-shared-profile"
    assert "shared_address" in row["candidate_reason_codes"]


def test_generate_candidates_contact_overlap_keeps_same_source_even_when_policy_rejects() -> None:
    """Default contact overlap still creates same-source candidates outside source policy."""
    config = _source_policy_config(
        relation="cross_source_same_profile",
        rule_id="address-only-cross-source-shared-profile",
    )
    organization_entities = _address_overlap_frame(["SOURCE_A", "SOURCE_A"])

    result = generate_candidates(
        denormalized_organization=organization_entities,
        denormalized_service=_empty_entity_frame(),
        changed_entities=_changed_entities("organization"),
        config=config,
        explicit_backfill=False,
    )

    row = result.candidate_pairs.row(0, named=True)
    assert result.candidate_pairs.height == 1
    assert row["blocking_rule_id"] == "default_contact_overlap"
    assert "shared_address" in row["candidate_reason_codes"]


def test_generate_candidates_same_profile_still_admits_same_and_cross_source_pairs() -> None:
    """The older same-profile relation continues to include same-source pairs."""
    config = _source_policy_config(relation="same_profile", rule_id="address-only-same-profile")
    same_source = generate_candidates(
        denormalized_organization=_address_overlap_frame(["SOURCE_A", "SOURCE_A"]),
        denormalized_service=_empty_entity_frame(),
        changed_entities=_changed_entities("organization"),
        config=config,
        explicit_backfill=False,
    )
    cross_source = generate_candidates(
        denormalized_organization=_address_overlap_frame(["SOURCE_A", "SOURCE_B"]),
        denormalized_service=_empty_entity_frame(),
        changed_entities=_changed_entities("organization"),
        config=config,
        explicit_backfill=False,
    )

    assert same_source.candidate_pairs.height == 1
    assert cross_source.candidate_pairs.height == 1


def test_generate_candidates_policy_min_similarity_can_lower_global_scan_floor() -> None:
    """Admission rule min similarity is honored below the default blocking threshold."""
    config = _source_policy_config(
        relation="cross_source_same_profile",
        rule_id="address-low-similarity",
        min_embedding_similarity=0.70,
    )
    organization_entities = _address_overlap_frame(
        ["SOURCE_A", "SOURCE_B"],
        embedding_vectors=[[1.0, 0.0], [0.72, 0.693974]],
    )

    result = generate_candidates(
        denormalized_organization=organization_entities,
        denormalized_service=_empty_entity_frame(),
        changed_entities=_changed_entities("organization"),
        config=config,
        explicit_backfill=False,
    )

    assert result.candidate_pairs.height == 1
    assert result.candidate_pairs.row(0, named=True)["blocking_rule_id"] == "address-low-similarity"


def test_generate_candidates_legacy_fallback_still_uses_global_similarity_threshold() -> None:
    """Lower policy scan floors must not lower default taxonomy+non-taxonomy admission."""
    config = _source_policy_config(
        relation="cross_source_same_profile",
        rule_id="unmatched-source-policy",
        min_embedding_similarity=0.70,
    )
    organization_entities = _organization_frame(
        taxonomies=[[{"code": "BD"}], [{"code": "BD"}]],
        locations=[[{"city": "Chicago", "state": "IL"}], [{"city": "Chicago", "state": "IL"}]],
    ).with_columns(
        pl.Series("source_schema", ["SOURCE_X", "SOURCE_Y"]),
        pl.Series("embedding_vector", [[1.0, 0.0], [0.72, 0.693974]]),
    )

    result = generate_candidates(
        denormalized_organization=organization_entities,
        denormalized_service=_empty_entity_frame(),
        changed_entities=_changed_entities("organization"),
        config=config,
        explicit_backfill=False,
    )

    assert result.candidate_pairs.is_empty()


def test_generate_candidates_service_policy_admits_taxonomy_plus_phone_cross_source_pair() -> None:
    """WellSky cross-source service pairs can be admitted with taxonomy plus phone."""
    config = _source_policy_config(
        relation="cross_source_same_profile",
        rule_id="wellsky-taxonomy-plus-contact",
        entity_type="service",
        all_of=["taxonomy"],
        any_of=["phone", "website", "address_exact"],
    )
    service_entities = _service_frame(
        source_schemas=["SOURCE_A", "SOURCE_B"],
        phones=[["555-0100"], ["555-0100"]],
        websites=[[], []],
        locations=[[], []],
        taxonomies=[[{"code": "T1017"}], [{"code": "T1017"}]],
    )

    result = generate_candidates(
        denormalized_organization=_empty_entity_frame(),
        denormalized_service=service_entities,
        changed_entities=_changed_entities("service"),
        config=config,
        explicit_backfill=False,
    )

    assert result.candidate_pairs.height == 1
    row = result.candidate_pairs.row(0, named=True)
    assert row["blocking_rule_id"] == "wellsky-taxonomy-plus-contact"
    assert "shared_taxonomy" in row["candidate_reason_codes"]
    assert "shared_phone" in row["candidate_reason_codes"]


def test_generate_candidates_service_policy_admits_same_address_semantic_pair() -> None:
    """WellSky-style same-address service pairs can admit without taxonomy overlap."""
    config = _source_policy_config(
        relation="same_profile",
        rule_id="il211_wellsky_service_same_address_semantic",
        entity_type="service",
        all_of=["address_exact"],
        min_embedding_similarity=0.76,
    )
    service_entities = _service_frame(
        source_schemas=["SOURCE_A", "SOURCE_A"],
        phones=[[], []],
        websites=[[], []],
        locations=[
            [{"address_1": "123 Main St", "city": "Chicago", "state": "IL"}],
            [{"address_1": "123 Main Street", "city": "Chicago", "state": "IL"}],
        ],
        taxonomies=[[{"code": "LJ-2000.6500"}], [{"code": "BM-6500.1500-100"}]],
    ).with_columns(pl.Series("embedding_vector", [[1.0, 0.0], [0.80, 0.60]]))

    result = generate_candidates(
        denormalized_organization=_empty_entity_frame(),
        denormalized_service=service_entities,
        changed_entities=_changed_entities("service"),
        config=config,
        explicit_backfill=False,
    )

    assert result.candidate_pairs.height == 1
    row = result.candidate_pairs.row(0, named=True)
    assert row["blocking_rule_id"] == "il211_wellsky_service_same_address_semantic"
    assert "shared_address" in row["candidate_reason_codes"]
    assert "shared_taxonomy" not in row["candidate_reason_codes"]


def test_generate_candidates_service_policy_admits_taxonomy_plus_domain_cross_source_pair() -> None:
    """WellSky cross-source service pairs can be admitted with taxonomy plus website overlap."""
    config = _source_policy_config(
        relation="cross_source_same_profile",
        rule_id="wellsky-taxonomy-plus-contact",
        entity_type="service",
        all_of=["taxonomy"],
        any_of=["phone", "website", "address_exact"],
    )
    service_entities = _service_frame(
        source_schemas=["SOURCE_A", "SOURCE_B"],
        phones=[[], []],
        websites=[["https://north.org/services"], ["http://www.north.org/help"]],
        locations=[[], []],
        taxonomies=[[{"code": "T1017"}], [{"code": "T1017"}]],
    )

    result = generate_candidates(
        denormalized_organization=_empty_entity_frame(),
        denormalized_service=service_entities,
        changed_entities=_changed_entities("service"),
        config=config,
        explicit_backfill=False,
    )

    assert result.candidate_pairs.height == 1
    row = result.candidate_pairs.row(0, named=True)
    assert row["blocking_rule_id"] == "wellsky-taxonomy-plus-contact"
    assert "shared_taxonomy" in row["candidate_reason_codes"]
    assert "shared_domain" in row["candidate_reason_codes"]


def test_generate_candidates_service_policy_rejects_taxonomy_only_cross_source_pair() -> None:
    """WellSky cross-source service pairs still need a non-taxonomy corroborating signal."""
    config = _source_policy_config(
        relation="cross_source_same_profile",
        rule_id="wellsky-taxonomy-plus-contact",
        entity_type="service",
        all_of=["taxonomy"],
        any_of=["phone", "website", "address_exact"],
    )
    service_entities = _service_frame(
        source_schemas=["SOURCE_A", "SOURCE_B"],
        phones=[[], []],
        websites=[[], []],
        locations=[[], []],
        taxonomies=[[{"code": "T1017"}], [{"code": "T1017"}]],
    )

    result = generate_candidates(
        denormalized_organization=_empty_entity_frame(),
        denormalized_service=service_entities,
        changed_entities=_changed_entities("service"),
        config=config,
        explicit_backfill=False,
    )

    assert result.candidate_pairs.is_empty()


def _source_policy_config(
    *,
    relation: str,
    rule_id: str,
    min_embedding_similarity: float | None = None,
    entity_type: str = "organization",
    all_of: list[str] | None = None,
    any_of: list[str] | None = None,
) -> EntityResolutionRunConfig:
    """Build a generic source-policy config for candidate admission tests."""
    payload = EntityResolutionRunConfig.defaults_for_entity_type(
        team_id="team-source-policy",
        scope_id="scope-source-policy",
        entity_type=entity_type,
    ).model_dump()
    rule = {
        "rule_id": rule_id,
        "entity_types": [entity_type],
        "source_relation": relation,
        "source_profiles": ["PROFILE_SHARED"],
        "all_of": all_of if all_of is not None else ["address_exact"],
    }
    if any_of is not None:
        rule["any_of"] = any_of
    if min_embedding_similarity is not None:
        rule["min_embedding_similarity"] = min_embedding_similarity
    payload["source_policy"] = {
        "source_profiles": {
            "PROFILE_SHARED": {"source_schemas": ["SOURCE_A", "SOURCE_B"]},
        },
        "admission_rules": [rule],
        "pair_rules": [],
    }
    return EntityResolutionRunConfig.model_validate(payload)


def _address_overlap_frame(
    source_schemas: list[str],
    *,
    embedding_vectors: list[list[float]] | None = None,
) -> pl.DataFrame:
    """Return two generic entities that share an exact normalized address."""
    frame = _organization_frame(
        taxonomies=[[], []],
        locations=[
            [
                {
                    "address_1": "123 N Main St",
                    "city": "Chicago",
                    "state": "IL",
                    "postal_code": "60601",
                }
            ],
            [
                {
                    "address_1": "123 North Main Street",
                    "city": "Chicago",
                    "state": "IL",
                    "postal_code": "60601",
                }
            ],
        ],
    ).with_columns(pl.Series("source_schema", source_schemas))
    if embedding_vectors is not None:
        frame = frame.with_columns(pl.Series("embedding_vector", embedding_vectors))
    return frame


def _organization_frame(
    *,
    taxonomies: list[object],
    locations: list[object],
    emails: list[object] | None = None,
    phones: list[object] | None = None,
    websites: list[object] | None = None,
    services_rollup: list[object] | None = None,
) -> pl.DataFrame:
    """Build normalized-organization frame with configurable overlap payloads."""
    resolved_emails = emails if emails is not None else [[], []]
    resolved_phones = phones if phones is not None else [[], []]
    resolved_websites = websites if websites is not None else [[], []]
    resolved_services_rollup = services_rollup if services_rollup is not None else [[], []]
    return pl.DataFrame(
        {
            "entity_id": ["org-a", "org-b"],
            "entity_type": ["organization", "organization"],
            "source_schema": ["SOURCE_A", "SOURCE_A"],
            "name": ["North Clinic", "North Clinic LLC"],
            "description": ["Primary care", "Primary care services"],
            "emails": resolved_emails,
            "phones": resolved_phones,
            "websites": resolved_websites,
            "locations": locations,
            "taxonomies": taxonomies,
            "identifiers": [[], []],
            "services_rollup": resolved_services_rollup,
            "organization_name": ["", ""],
            "organization_id": ["", ""],
            "embedding_vector": [[1.0, 0.0], [0.99, 0.01]],
            "content_hash": ["hash-a", "hash-b"],
        }
    )


def _service_frame(
    *,
    source_schemas: list[str],
    taxonomies: list[object],
    locations: list[object],
    emails: list[object] | None = None,
    phones: list[object] | None = None,
    websites: list[object] | None = None,
) -> pl.DataFrame:
    """Build normalized-service rows with configurable overlap payloads."""
    resolved_emails = emails if emails is not None else [[], []]
    resolved_phones = phones if phones is not None else [[], []]
    resolved_websites = websites if websites is not None else [[], []]
    return pl.DataFrame(
        {
            "entity_id": ["svc-a", "svc-b"],
            "entity_type": ["service", "service"],
            "source_schema": source_schemas,
            "name": ["Case Management", "Case Management Support"],
            "description": ["Care coordination", "Care coordination support"],
            "emails": resolved_emails,
            "phones": resolved_phones,
            "websites": resolved_websites,
            "locations": locations,
            "taxonomies": taxonomies,
            "identifiers": [[], []],
            "services_rollup": [[], []],
            "organization_name": ["North Org", "North Org"],
            "organization_id": ["org-a", "org-b"],
            "embedding_vector": [[1.0, 0.0], [0.99, 0.01]],
            "content_hash": ["hash-a", "hash-b"],
        }
    )


def _empty_entity_frame() -> pl.DataFrame:
    """Return empty normalized-entity frame with required schema."""
    return _organization_frame(taxonomies=[[], []], locations=[[], []]).head(0)


def _changed_entities(entity_type: str) -> pl.DataFrame:
    """Return one changed anchor entity for candidate expansion."""
    entity_id = "svc-a" if entity_type == "service" else "org-a"
    return pl.DataFrame(
        {
            "entity_id": [entity_id],
            "entity_type": [entity_type],
            "delta_class": ["added"],
        }
    )
