"""Integration modules for tracing with external frameworks.

This module uses lazy loading to avoid importing heavy dependencies unless needed.
Each integration only loads when explicitly imported.
"""

__all__ = [
    "BeaconLangGraphHandler",
    "BeaconLiteLLMLogger",
]

def __getattr__(name: str):
    """Lazy load integrations to avoid importing heavy dependencies.

    This prevents importing one integration from triggering others to load.
    For example, importing BeaconLangGraphHandler won't load litellm.
    """
    if name in ("BeaconLangGraphHandler", "BeaconCallbackHandler"):
        from lumenova_beacon.tracing.integrations.langchain import BeaconLangGraphHandler

        if name == "BeaconCallbackHandler":
            import warnings

            warnings.warn(
                "BeaconCallbackHandler is deprecated, use BeaconLangGraphHandler instead",
                DeprecationWarning,
                stacklevel=2,
            )
        return BeaconLangGraphHandler
    elif name == "BeaconLiteLLMLogger":
        from lumenova_beacon.tracing.integrations.litellm import BeaconLiteLLMLogger
        return BeaconLiteLLMLogger
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
