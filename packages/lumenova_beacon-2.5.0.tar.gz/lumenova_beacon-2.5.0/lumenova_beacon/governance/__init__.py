"""Beacon governance integration for LangChain/LangGraph agents."""

from lumenova_beacon.governance.config import GovernanceConfig
from lumenova_beacon.governance.decorators import governance


__all__ = ['BeaconLangGraphGovernanceHandler', 'GovernanceConfig', 'governance']


def __getattr__(name: str) -> type:
    if name == 'BeaconLangGraphGovernanceHandler':
        from lumenova_beacon.governance.integrations.langchain import BeaconLangGraphGovernanceHandler

        return BeaconLangGraphGovernanceHandler

    raise AttributeError(f'module {__name__!r} has no attribute {name!r}')
