"""AWS Secrets Manager integration for API key retrieval."""

from __future__ import annotations

import json
import logging
import os

from lumenova_beacon.exceptions import ConfigurationError

logger = logging.getLogger(__name__)


def _traverse_secret(data: dict, key_path: str) -> str | None:
    """Traverse a nested dict using dot-notation key path.

    Args:
        data: Parsed JSON secret data
        key_path: Dot-separated path (e.g., "beacon.api_key")

    Returns:
        The string value at the path, or None if not found
    """
    keys = key_path.split(".")
    current = data
    for key in keys:
        # If current is a JSON string, parse it before continuing traversal
        if isinstance(current, str):
            try:
                current = json.loads(current)
            except (json.JSONDecodeError, TypeError):
                pass
        if not isinstance(current, dict) or key not in current:
            logger.warning(
                f"Key path '{key_path}' not found in secret "
                f"(failed at '{key}')"
            )
            return None
        current = current[key]
    return str(current) if current is not None else None


def resolve_aws_secret(
    secret_name: str,
    secret_key: str | None = None,
    region: str | None = None,
) -> str | None:
    """Retrieve a value from AWS Secrets Manager.

    Args:
        secret_name: Secret name or ARN in Secrets Manager
        secret_key: Dot-notation path for nested JSON (e.g., "beacon.api_key").
            If None, returns the raw secret string.
        region: AWS region. If None, uses boto3 default chain.

    Returns:
        The secret value, or None if retrieval fails

    Raises:
        ConfigurationError: If boto3 is not installed
    """
    try:
        import boto3
        from botocore.exceptions import ClientError
    except ImportError:
        raise ConfigurationError(
            "boto3 is required for AWS Secrets Manager integration. "
            "Install with: pip install lumenova-beacon[aws]"
        )

    try:
        client = boto3.client("secretsmanager", region_name=region)
        response = client.get_secret_value(SecretId=secret_name)
    except ClientError as e:
        logger.warning(f"Failed to retrieve secret '{secret_name}': {e}")
        return None

    secret_string = response.get("SecretString")
    if secret_string is None:
        logger.warning(f"Secret '{secret_name}' has no SecretString value")
        return None

    if not secret_key:
        return secret_string

    try:
        data = json.loads(secret_string)
    except json.JSONDecodeError:
        logger.warning(
            f"Secret '{secret_name}' is not valid JSON but "
            f"a key path '{secret_key}' was specified"
        )
        return None

    return _traverse_secret(data, secret_key)


def resolve_api_key_from_aws() -> str | None:
    """Resolve API key from AWS Secrets Manager using BEACON_AWS_* env vars.

    Environment variables:
        BEACON_AWS_SECRET_NAME: Secret name or ARN (required for AWS resolution)
        BEACON_AWS_SECRET_KEY: Dot-notation key path (default: "api_key")
        BEACON_AWS_REGION: AWS region (optional, uses boto3 default chain)

    Returns:
        The API key string, or None if AWS is not configured or retrieval fails
    """
    secret_name = os.getenv("BEACON_AWS_SECRET_NAME")
    if not secret_name:
        return None

    secret_key = os.getenv("BEACON_AWS_SECRET_KEY", "api_key")
    region = os.getenv("BEACON_AWS_REGION")

    return resolve_aws_secret(secret_name, secret_key, region)
