#!/usr/bin/env bash
# Copyright 2025 the LlamaFactory team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# On EC2: align venv with package.pip_spec (same as clients), then run inference REPL or shell payload server.
# Args: <workspace_dir> <inference_yaml_relative_to_workspace>
#
# Env:
#   LF_REMOTE_PACKAGE_SPEC — identical pip requirement clients use (see package.pip_spec).
#                            When set: force-reinstall root + deps pass (parity with bootstrap_remote.sh).
#   HF_TOKEN               — optional; pipeline may write .hf_token on workspace
#   LF_EC2_INFERENCE_MODE  — chat (default) or shell
#   LF_EC2_INFER_PORT      — localhost port for payload server in shell mode (default: 18080)

set -euo pipefail

WORK_DIR="${1:?workspace dir required}"
INFER_REL="${2:?inference yaml path relative to workspace required}"

VENV_DIR="${HOME}/llamafactory-venv"
if [ ! -f "${VENV_DIR}/bin/activate" ]; then
  echo "ERROR: venv not found at ${VENV_DIR}. Use the same EC2 image/setup as training." >&2
  exit 1
fi
# shellcheck disable=SC1090
source "${VENV_DIR}/bin/activate"

PIP_STAMP_PY="${WORK_DIR}/src/llamafactory/ec2/pip_stamp.py"

# If a legacy "llamafactory" wheel exists in site-packages, it can shadow editable
# installs from this workspace and hide newly added modules. Remove it proactively.
if python3 -m pip show llamafactory >/dev/null 2>&1; then
  echo "[inference_prepare] Removing legacy site-packages distribution: llamafactory"
  python3 -m pip uninstall -y llamafactory >/dev/null 2>&1 || true
fi

# Put runtime caches / temp files on NVMe when available so root EBS only keeps
# repo + venv (persistent essentials). Inference model caches are safe on ephemeral NVMe.
# If NVMe exists but is not writable, fall back to a tree under ~/.cache (EBS) instead of aborting.
NVME_BASE="/opt/dlami/nvme"
CACHE_ROOT=""
TMP_ROOT=""

_set_cache_exports() {
  export TMPDIR="${TMP_ROOT}"
  export TEMP="${TMP_ROOT}"
  export TMP="${TMP_ROOT}"
  export XDG_CACHE_HOME="${CACHE_ROOT}/xdg"
  export HF_HOME="${CACHE_ROOT}/huggingface"
  export HF_HUB_CACHE="${CACHE_ROOT}/huggingface/hub"
  export HF_ASSETS_CACHE="${CACHE_ROOT}/huggingface/assets"
  export HF_XET_CACHE="${CACHE_ROOT}/xet"
  export TRANSFORMERS_CACHE="${CACHE_ROOT}/huggingface/hub"
  export PIP_CACHE_DIR="${CACHE_ROOT}/pip"
  export TRITON_CACHE_DIR="${CACHE_ROOT}/triton"
  export TORCHINDUCTOR_CACHE_DIR="${CACHE_ROOT}/torchinductor"
}

_mkdir_cache_tree() {
  mkdir -p \
    "${CACHE_ROOT}/xdg" \
    "${CACHE_ROOT}/huggingface" \
    "${CACHE_ROOT}/huggingface/hub" \
    "${CACHE_ROOT}/huggingface/assets" \
    "${CACHE_ROOT}/pip" \
    "${CACHE_ROOT}/triton" \
    "${CACHE_ROOT}/torchinductor" \
    "${CACHE_ROOT}/xet" \
    "${TMP_ROOT}"
}

if [ -d "$NVME_BASE" ] && df "$NVME_BASE" >/dev/null 2>&1; then
  _nvme_ws="${NVME_BASE}/lf-workspace"
  CACHE_ROOT="${_nvme_ws}/runtime-cache"
  TMP_ROOT="${_nvme_ws}/tmp"
  if _mkdir_cache_tree; then
    _set_cache_exports
    echo "[inference_prepare] NVMe cache mode: ${CACHE_ROOT} (free: $(df -h "$NVME_BASE" | awk 'NR==2{print $4}'))"
  else
    echo "[inference_prepare] WARN: NVMe at ${NVME_BASE} is present but not writable (cannot create ${CACHE_ROOT}). Skipping NVMe cache; using EBS-backed cache at ${HOME}/.cache/lf-inference-runtime." >&2
    CACHE_ROOT="${HOME}/.cache/lf-inference-runtime"
    TMP_ROOT="${CACHE_ROOT}/tmp"
    if ! _mkdir_cache_tree; then
      echo "ERROR: NVMe cache was skipped but EBS fallback cache could not be created at ${CACHE_ROOT}." >&2
      exit 1
    fi
    _set_cache_exports
    echo "[inference_prepare] EBS cache mode (NVMe skipped): ${CACHE_ROOT}"
  fi
else
  echo "[inference_prepare] WARN: NVMe not found at ${NVME_BASE}; cache/temp will use root EBS." >&2
fi

DRIVER_CUDA_VER=$(nvidia-smi 2>/dev/null | grep -oP 'CUDA Version:\s*\K[0-9]+\.[0-9]+' | head -1 || true)
if [ -n "${DRIVER_CUDA_VER}" ]; then
  TORCH_CUDA_TAG="cu$(echo "${DRIVER_CUDA_VER}" | tr -d '.')"
  EXTRA_INDEX=(--extra-index-url "https://download.pytorch.org/whl/${TORCH_CUDA_TAG}")
else
  EXTRA_INDEX=()
fi

# Same policy as training: when package.pip_spec is set, force-reinstall root spec then resolve deps
# (matches client ensure_local_venv_matches_pip_spec + bootstrap_remote.sh). Stamp in
# WORK_DIR/.lf_ec2_pip_stamp skips both steps when spec / editable fingerprint is unchanged.
if [ -n "${LF_REMOTE_PACKAGE_SPEC:-}" ]; then
  _run_lf_pip=1
  if [ -f "$PIP_STAMP_PY" ] && skip_msg="$(python3 "$PIP_STAMP_PY" check "$WORK_DIR" "${LF_REMOTE_PACKAGE_SPEC:-}")"; then
    echo "[inference_prepare] ${skip_msg}"
    _run_lf_pip=0
  fi
  if [ "$_run_lf_pip" -eq 1 ]; then
    echo "[inference_prepare] pip force-reinstall from LF_REMOTE_PACKAGE_SPEC (client + EC2 use same spec)..."
    # shellcheck disable=SC2068
    pip install -U --no-cache-dir --force-reinstall --no-deps ${EXTRA_INDEX[@]+"${EXTRA_INDEX[@]}"} \
      "${LF_REMOTE_PACKAGE_SPEC}" 2>&1 | tail -40
    # shellcheck disable=SC2068
    pip install -U --no-cache-dir --upgrade-strategy only-if-needed ${EXTRA_INDEX[@]+"${EXTRA_INDEX[@]}"} \
      "${LF_REMOTE_PACKAGE_SPEC}" 2>&1 | tail -40
    if [ -f "$PIP_STAMP_PY" ]; then
      python3 "$PIP_STAMP_PY" write-stamp "$WORK_DIR" "${LF_REMOTE_PACKAGE_SPEC:-}" || true
    fi
  fi
elif [ -f "${WORK_DIR}/pyproject.toml" ]; then
  _run_lf_pip=1
  if [ -f "$PIP_STAMP_PY" ] && skip_msg="$(python3 "$PIP_STAMP_PY" check "$WORK_DIR")"; then
    echo "[inference_prepare] ${skip_msg}"
    _run_lf_pip=0
  fi
  if [ "$_run_lf_pip" -eq 1 ]; then
    echo "[inference_prepare] No package.pip_spec — pip install -e from synced workspace..."
    # shellcheck disable=SC2068
    pip install -U --no-cache-dir --force-reinstall --no-deps ${EXTRA_INDEX[@]+"${EXTRA_INDEX[@]}"} \
      -e "$WORK_DIR" 2>&1 | tail -40
    # shellcheck disable=SC2068
    pip install -U --no-cache-dir --upgrade-strategy only-if-needed ${EXTRA_INDEX[@]+"${EXTRA_INDEX[@]}"} \
      -e "$WORK_DIR" 2>&1 | tail -40
    if [ -f "$PIP_STAMP_PY" ]; then
      python3 "$PIP_STAMP_PY" write-stamp "$WORK_DIR" || true
    fi
  fi
elif ! python3 -c "import llamafactory.ec2.inference_repl, llamafactory.ec2.inference_server, llamafactory.ec2.inference_request" 2>/dev/null; then
  echo "ERROR: inference modules missing and no package.pip_spec." >&2
  echo "  Set package.pip_spec in the pipeline YAML (same string clients use with pip install -U)" >&2
  echo "  or sync a workspace that contains pyproject.toml." >&2
  exit 1
fi

python3 -c "import llamafactory.ec2.inference_repl, llamafactory.ec2.inference_server, llamafactory.ec2.inference_request" || {
  echo "ERROR: required inference modules still not importable after install." >&2
  echo "  Fix package.pip_spec / network / private index auth, or sync a tree that contains inference_repl." >&2
  exit 1
}

HF_TOKEN_FILE="${WORK_DIR}/.hf_token"
if [ -z "${HF_TOKEN:-}" ] && [ -f "$HF_TOKEN_FILE" ]; then
  HF_TOKEN=$(cat "$HF_TOKEN_FILE")
  export HF_TOKEN
  rm -f "$HF_TOKEN_FILE"
fi

INFER_ABS="${WORK_DIR}/${INFER_REL}"
if [ ! -f "$INFER_ABS" ]; then
  echo "ERROR: inference yaml not found: $INFER_ABS" >&2
  exit 1
fi

cd "$WORK_DIR"
MODE="${LF_EC2_INFERENCE_MODE:-chat}"
if [ "$MODE" = "chat" ]; then
  exec python3 -u -m llamafactory.ec2.inference_repl "$INFER_ABS"
fi

if [ "$MODE" != "shell" ]; then
  echo "ERROR: unsupported LF_EC2_INFERENCE_MODE=$MODE (expected chat or shell)." >&2
  exit 1
fi

PORT="${LF_EC2_INFER_PORT:-18080}"
SESSION_NAME="llamafactory-infer"
LOG_PATH="${WORK_DIR}/inference_server.log"
if tmux has-session -t "$SESSION_NAME" 2>/dev/null; then
  tmux kill-session -t "$SESSION_NAME"
fi
tmux new-session -d -s "$SESSION_NAME" \
  "cd ${WORK_DIR@Q} && python3 -u -m llamafactory.ec2.inference_server ${INFER_ABS@Q} --host 127.0.0.1 --port ${PORT} 2>&1 | tee ${LOG_PATH@Q}"

echo
echo "[inference_prepare] Shell mode ready. You are now on a normal SSH shell."
echo "[inference_prepare] Inference server runs in tmux session: ${SESSION_NAME} (127.0.0.1:${PORT})"
echo "[inference_prepare] Tip: one prompt call:"
echo "  python3 -m llamafactory.ec2.inference_request --prompt \"hello\" --port ${PORT}"
echo "[inference_prepare] Tip: view server logs:"
echo "  tmux attach -t ${SESSION_NAME}   # detach with Ctrl+b then d"
echo "  tail -f ${LOG_PATH}"
echo

exec bash -l
