# Copyright 2025 the LlamaFactory team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Console entry for `lmf-ec2-chat` (chat or shell payload mode)."""

from __future__ import annotations

import argparse
import logging
import sys

from .inference_runner import run_ec2_inference
from .runner import EC2TrainingError


logging.basicConfig(level=logging.INFO, format="%(message)s", stream=sys.stdout)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Run EC2 inference session (chat REPL or shell payload mode) via pipeline YAML.",
    )
    parser.add_argument(
        "config",
        help="Path to an EC2 inference pipeline YAML (see examples/ec2_pipeline/inference_chat_template.yaml)",
    )
    args = parser.parse_args()

    try:
        return run_ec2_inference(args.config)
    except EC2TrainingError as e:
        print(f"\nEC2 inference error: {e}", file=sys.stderr)
        return e.exit_code
    except (FileNotFoundError, ValueError) as e:
        print(f"\nConfiguration error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
