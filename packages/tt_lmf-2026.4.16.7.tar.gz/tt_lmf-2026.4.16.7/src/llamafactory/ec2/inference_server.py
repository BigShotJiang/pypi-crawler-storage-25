# Copyright 2025 the LlamaFactory team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Persistent EC2 inference server for prompt payloads over localhost TCP."""

from __future__ import annotations

import argparse
import json
import socket
import threading
from pathlib import Path
from typing import Any

import torch

from ..data import get_template_and_fix_tokenizer
from ..extras.constants import EngineName
from ..hparams import get_infer_args
from ..model import load_model, load_tokenizer
from .inference_repl import _apply_env_overrides, _load_infer_dict


class InferenceRuntime:
    def __init__(self, yaml_path: str | Path):
        infer_dict = _apply_env_overrides(_load_infer_dict(Path(yaml_path).resolve()))
        model_args, data_args, finetuning_args, generating_args = get_infer_args(infer_dict)
        if model_args.infer_backend != EngineName.HF:
            raise ValueError(f"infer_backend must be huggingface (got {model_args.infer_backend!r})")

        tokenizer_module = load_tokenizer(model_args)
        self.tokenizer = tokenizer_module["tokenizer"]
        # Gemma 4 and other multimodal hubs still load AutoProcessor; text-only chat uses tokenizer +
        # generate(input_ids=...) only. Image/audio/video inputs are not supported on this server.
        if tokenizer_module.get("processor") is not None:
            print(
                "[inference_server] Multimodal processor present; using text-only path (tokenizer + generate).",
                flush=True,
            )

        get_template_and_fix_tokenizer(self.tokenizer, data_args)
        self.model = load_model(self.tokenizer, model_args, finetuning_args, is_trainable=False)
        self.model.eval()
        self.device = next(self.model.parameters()).device
        self.default_gen_kwargs: dict[str, Any] = {
            "max_new_tokens": generating_args.max_new_tokens if generating_args.max_new_tokens > 0 else generating_args.max_length,
            "do_sample": generating_args.do_sample,
            "temperature": generating_args.temperature,
            "top_p": generating_args.top_p,
            "top_k": generating_args.top_k,
            "num_beams": generating_args.num_beams,
            "repetition_penalty": generating_args.repetition_penalty,
            "length_penalty": generating_args.length_penalty,
            "pad_token_id": self.tokenizer.pad_token_id,
        }
        self.default_gen_kwargs = {k: v for k, v in self.default_gen_kwargs.items() if v is not None}
        if getattr(self.tokenizer, "chat_template", None) is None:
            raise ValueError("Tokenizer has no chat_template after template fix; cannot run payload inference.")
        self.skip_special_tokens = generating_args.skip_special_tokens
        self.lock = threading.Lock()

    def infer(self, payload: dict[str, Any]) -> dict[str, Any]:
        prompt = str(payload.get("prompt", "") or "").strip()
        messages = payload.get("messages")
        if messages is None:
            if not prompt:
                raise ValueError("Payload must provide either non-empty 'prompt' or 'messages'.")
            messages = [{"role": "user", "content": prompt}]
        if not isinstance(messages, list) or not messages:
            raise ValueError("'messages' must be a non-empty list.")

        encoded = self.tokenizer.apply_chat_template(
            conversation=messages,
            add_generation_prompt=True,
            tokenize=True,
            return_tensors="pt",
        )
        attention_mask = None
        if hasattr(encoded, "input_ids"):
            inputs = encoded.input_ids
            attention_mask = getattr(encoded, "attention_mask", None)
        elif isinstance(encoded, dict):
            inputs = encoded["input_ids"]
            attention_mask = encoded.get("attention_mask")
        elif isinstance(encoded, torch.Tensor):
            inputs = encoded
        else:
            inputs = torch.tensor(encoded, dtype=torch.long)

        inputs = inputs.to(self.device)
        if inputs.dim() == 1:
            inputs = inputs.unsqueeze(0)
        if attention_mask is not None:
            attention_mask = attention_mask.to(self.device)
            if attention_mask.dim() == 1:
                attention_mask = attention_mask.unsqueeze(0)
        else:
            attention_mask = torch.ones_like(inputs, dtype=torch.long, device=self.device)

        req_gen = payload.get("generation", {}) if isinstance(payload.get("generation"), dict) else {}
        gen_kwargs = dict(self.default_gen_kwargs)
        gen_kwargs.update({k: v for k, v in req_gen.items() if v is not None})

        with self.lock, torch.inference_mode():
            output_ids = self.model.generate(input_ids=inputs, attention_mask=attention_mask, **gen_kwargs)

        seq = output_ids[0].tolist()
        prompt_len = int(inputs.shape[-1])
        reply = self.tokenizer.decode(seq[prompt_len:], skip_special_tokens=self.skip_special_tokens)
        return {"text": reply}


def serve(yaml_path: str, host: str, port: int) -> int:
    runtime = InferenceRuntime(yaml_path)
    print(f"[inference_server] ready on {host}:{port}", flush=True)
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((host, port))
        server.listen(8)
        while True:
            conn, _ = server.accept()
            with conn:
                try:
                    raw = b""
                    while not raw.endswith(b"\n"):
                        chunk = conn.recv(4096)
                        if not chunk:
                            break
                        raw += chunk
                    payload = json.loads(raw.decode("utf-8").strip() or "{}")
                    response = runtime.infer(payload)
                except Exception as e:
                    response = {"error": str(e)}
                conn.sendall((json.dumps(response, ensure_ascii=True) + "\n").encode("utf-8"))
    return 0


def main() -> None:
    parser = argparse.ArgumentParser(description="Run EC2 local inference payload server.")
    parser.add_argument("yaml_path", help="Inference YAML path")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=18080)
    args = parser.parse_args()
    raise SystemExit(serve(args.yaml_path, args.host, args.port))


if __name__ == "__main__":
    main()
