# Copyright 2025 the LlamaFactory team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""EC2 pip install idempotency: stamp file + VCS revision resolution (git ls-remote).

Runnable as ``python3 path/to/pip_stamp.py`` on EC2 before the package is installed
(imports only the standard library). Imported by ``runner.py`` for local clients.
"""

from __future__ import annotations

import argparse
import hashlib
import re
import subprocess
import sys
from pathlib import Path


STAMP_VERSION = "1"
STAMP_FILENAME = ".lf_ec2_pip_stamp"
EDITABLE_SPEC_HASH = hashlib.sha256(b"mode=editable").hexdigest()

GIT_PREFIX_RE = re.compile(r"^git\+", re.IGNORECASE)
_VCS_MARKERS = ("git+", "hg+", "svn+", "bzr+")

# PEP 440 version specifiers — presence of any means the spec is pinned.
_VERSION_SPECIFIERS = ("==", "!=", ">=", "<=", "~=", ">", "<")


def normalize_pip_spec(spec: str) -> str:
    """Collapse whitespace for stable hashing and comparison."""
    return " ".join(spec.strip().split())


def is_vcs_pip_spec(spec: str) -> bool:
    """True if spec looks like a VCS direct URL (PEP 508 or bare URL)."""
    s = spec.strip()
    if not s:
        return False
    low = s.lower()
    if " @ " in s:
        tail = s.split(" @ ", 1)[1].strip().lower()
        return any(m in tail for m in _VCS_MARKERS)
    return any(low.startswith(m) for m in _VCS_MARKERS)


def is_git_pip_spec(spec: str) -> bool:
    s = spec.strip()
    if " @ " in s:
        tail = s.split(" @ ", 1)[1].strip()
        return bool(GIT_PREFIX_RE.match(tail))
    return bool(GIT_PREFIX_RE.match(s))


def _url_part(spec: str) -> str:
    s = normalize_pip_spec(spec)
    if " @ " in s:
        return s.split(" @ ", 1)[1].strip()
    return s


def _strip_fragment_and_query(url: str) -> str:
    u = url.split("#", 1)[0]
    return u.split("?", 1)[0]


def parse_git_ls_remote_target(spec: str) -> tuple[str, str] | None:
    """Return ``(base_clone_url_without_git_prefix, ref)`` for ``git ls-remote``, or None."""
    raw = _url_part(spec)
    if not GIT_PREFIX_RE.match(raw):
        return None
    u = _strip_fragment_and_query(raw)
    u = GIT_PREFIX_RE.sub("", u, count=1)
    if ".git@" in u:
        base, ref = u.split(".git@", 1)
        return base + ".git", ref
    if u.lower().endswith(".git"):
        return u, "HEAD"
    slash = u.rfind("/")
    if slash != -1:
        last = u[slash + 1 :]
        if "@" in last and not last.lower().endswith(".git"):
            base = u[: slash + 1] + last.rsplit("@", 1)[0]
            ref = last.rsplit("@", 1)[1]
            return base, ref
    return None


_FULL_HEX_SHA40 = re.compile(r"^[0-9a-f]{40}$", re.IGNORECASE)


def resolve_git_revision(spec: str, *, timeout_sec: int = 120) -> str:
    """Resolve git pip spec to a full hex SHA (``git ls-remote``) or a pinned 40-char SHA."""
    parsed = parse_git_ls_remote_target(spec)
    if parsed is None:
        raise ValueError("not a git VCS pip requirement")
    base_url, ref = parsed
    if not ref or ref.upper() == "HEAD":
        ref = "HEAD"
    if _FULL_HEX_SHA40.match(ref):
        return ref.lower()

    trials: list[list[str]] = []
    if ref == "HEAD":
        trials.append(["git", "ls-remote", base_url, "HEAD"])
    else:
        trials.extend(
            [
                ["git", "ls-remote", base_url, f"refs/heads/{ref}"],
                ["git", "ls-remote", base_url, f"refs/tags/{ref}"],
                ["git", "ls-remote", base_url, ref],
            ]
        )
    last_err: str | None = None
    for cmd in trials:
        try:
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout_sec,
                check=False,
            )
        except FileNotFoundError:
            raise RuntimeError("git executable not found") from None
        except subprocess.TimeoutExpired as e:
            last_err = str(e)
            continue
        if proc.returncode != 0:
            last_err = (proc.stderr or proc.stdout or "").strip() or f"exit {proc.returncode}"
            continue
        lines = [ln for ln in proc.stdout.splitlines() if ln.strip()]
        if not lines:
            continue
        sha = lines[0].split()[0].strip()
        if _FULL_HEX_SHA40.match(sha):
            return sha.lower()
        last_err = f"unexpected ls-remote line: {lines[0]!r}"
    raise RuntimeError(last_err or "git ls-remote returned no revision")


def editable_fingerprint(repo_root: Path) -> str:
    """Fast, good-enough fingerprint: ``pyproject`` stat + py file count + max mtime under package."""
    pyproject = repo_root / "pyproject.toml"
    if not pyproject.is_file():
        return "missing-pyproject"
    st = pyproject.stat()
    parts = [f"mtime_ns={st.st_mtime_ns}", f"size={st.st_size}"]
    pkg = repo_root / "src" / "llamafactory"
    max_ns = 0
    n_py = 0
    if pkg.is_dir():
        for p in pkg.rglob("*.py"):
            try:
                stp = p.stat()
            except OSError:
                continue
            n_py += 1
            if stp.st_mtime_ns > max_ns:
                max_ns = stp.st_mtime_ns
    parts.append(f"n_py={n_py}")
    parts.append(f"max_mtime_ns={max_ns}")
    return hashlib.sha256("|".join(parts).encode()).hexdigest()


def read_stamp(path: Path) -> dict[str, str]:
    if not path.is_file():
        return {}
    out: dict[str, str] = {}
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        k, v = line.split("=", 1)
        out[k.strip()] = v.strip()
    return out


def write_stamp(
    path: Path,
    *,
    mode: str,
    spec_hash: str,
    resolved: str,
    norm_spec: str,
) -> None:
    lines = [
        f"version={STAMP_VERSION}",
        f"mode={mode}",
        f"spec_hash={spec_hash}",
        f"resolved={resolved}",
        f"norm_spec={norm_spec}",
        "",
    ]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


def short_sha(resolved: str) -> str:
    if len(resolved) >= 7 and re.match(r"^[0-9a-f]+$", resolved, re.I):
        return resolved[:7]
    return resolved[:12] if resolved else "-"


def compute_desired_stamp(repo_root: Path, pip_spec: str) -> tuple[str, str, str, str] | None:
    """Return ``(mode, spec_hash, resolved, norm_spec)`` for stamp, or None if no pip target."""
    spec = pip_spec.strip()
    norm = normalize_pip_spec(spec) if spec else ""

    if spec:
        h = hashlib.sha256(norm.encode("utf-8")).hexdigest()
        if is_git_pip_spec(spec):
            rev = resolve_git_revision(spec)
            return ("vcs", h, rev, norm)
        if is_vcs_pip_spec(spec):
            # Non-git VCS: skip remote resolution; reinstall only when spec string changes.
            return ("vcs_nogit", h, "-", norm)
        return ("pypi", h, "-", norm)

    if (repo_root / "pyproject.toml").is_file():
        fp = editable_fingerprint(repo_root)
        return ("editable", EDITABLE_SPEC_HASH, fp, "-")
    return None


def stamp_matches(current: tuple[str, str, str, str], stamp: dict[str, str]) -> bool:
    mode, spec_hash, resolved, norm = current
    if stamp.get("version") != STAMP_VERSION:
        return False
    return (
        stamp.get("mode") == mode
        and stamp.get("spec_hash") == spec_hash
        and stamp.get("resolved") == resolved
        and stamp.get("norm_spec") == norm
    )


def pip_skip_message(current: tuple[str, str, str, str]) -> str:
    _mode, _sh, resolved, _norm = current
    if resolved == "-":
        return "pip: skipped, spec unchanged"
    return f"pip: skipped, spec unchanged at {short_sha(resolved)}"


def pip_install_needed(repo_root: Path, pip_spec: str, stamp_path: Path) -> tuple[bool, str]:
    """Return ``(needed, message)``: ``needed`` False means skip; ``message`` set only when skipping."""
    # Unversioned PyPI spec (e.g. "tt-lmf[ec2,plots,multimodal]"): there is no way to
    # detect whether a newer release exists without actually running pip.  Always install
    # so that `pip install -U` can upgrade to the latest published version.
    spec = pip_spec.strip()
    norm = normalize_pip_spec(spec) if spec else ""
    if spec and not is_vcs_pip_spec(spec) and not any(op in norm for op in _VERSION_SPECIFIERS):
        return True, ""
    desired = compute_desired_stamp(repo_root, pip_spec)
    if desired is None:
        return False, ""
    stamp = read_stamp(stamp_path)
    if stamp_matches(desired, stamp):
        return False, pip_skip_message(desired)
    return True, ""


def record_stamp_after_pip_install(repo_root: Path, pip_spec: str) -> None:
    stamp_path = repo_root / STAMP_FILENAME
    desired = compute_desired_stamp(repo_root, pip_spec)
    if desired is None:
        return
    mode, spec_hash, resolved, norm = desired
    write_stamp(stamp_path, mode=mode, spec_hash=spec_hash, resolved=resolved, norm_spec=norm)


def cmd_check(repo_root: Path, pip_spec: str) -> int:
    stamp_path = repo_root / STAMP_FILENAME
    try:
        needed, msg = pip_install_needed(repo_root, pip_spec, stamp_path)
    except Exception as e:
        print(f"pip stamp check failed ({e!r}); will run pip", file=sys.stderr)
        return 1
    if not needed:
        if msg:
            print(msg, end="\n", file=sys.stdout)
        return 0
    return 1


def cmd_write(repo_root: Path, pip_spec: str) -> int:
    try:
        record_stamp_after_pip_install(repo_root, pip_spec)
    except Exception as e:
        print(f"pip stamp write failed: {e!r}", file=sys.stderr)
        return 2
    return 0


def _cli(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="LlamaFactory EC2 pip install stamp helper.")
    sub = p.add_subparsers(dest="cmd", required=True)

    c = sub.add_parser("check", help="exit 0 if pip install can be skipped, else 1")
    c.add_argument("work_dir", type=Path)
    c.add_argument("pip_spec", nargs="?", default="", help="LF_REMOTE_PACKAGE_SPEC or empty for editable")

    w = sub.add_parser("write-stamp", help="write stamp after successful pip install")
    w.add_argument("work_dir", type=Path)
    w.add_argument("pip_spec", nargs="?", default="", help="same as for check")

    args = p.parse_args(argv)
    repo_root = args.work_dir.expanduser().resolve()
    spec = args.pip_spec if args.pip_spec is not None else ""
    if args.cmd == "check":
        return cmd_check(repo_root, spec)
    if args.cmd == "write-stamp":
        return cmd_write(repo_root, spec)
    return 2


if __name__ == "__main__":
    raise SystemExit(_cli())
