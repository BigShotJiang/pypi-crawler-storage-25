# Copyright 2025 the LlamaFactory team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Helpers to materialize Orbi (or other) bundle files into an EC2 workspace directory."""

from __future__ import annotations

import shutil
from collections.abc import Iterable
from pathlib import Path


def stage_bundle_assets(workspace: str | Path, assets: Iterable[tuple[str | Path, str]]) -> None:
    """Copy local files or directories into a workspace.

    Each entry is ``(source_path, relative_dest)`` where ``relative_dest`` is
    relative to ``workspace`` (e.g. ``"data/train.jsonl"``, ``"train.yaml"``).

    Directories are copied with ``copytree(..., dirs_exist_ok=True)``.
    """
    root = Path(workspace).resolve()
    root.mkdir(parents=True, exist_ok=True)

    for src, rel in assets:
        rel_s = rel.strip().replace("\\", "/")
        if not rel_s or rel_s.startswith("..") or rel_s.startswith("/"):
            raise ValueError(f"Invalid relative dest (no absolute or parent segments): {rel!r}")

        s = Path(src).expanduser().resolve()
        if not s.exists():
            raise FileNotFoundError(f"Bundle asset missing: {s}")

        dest = root / rel_s
        dest.parent.mkdir(parents=True, exist_ok=True)

        if s.is_dir():
            shutil.copytree(s, dest, dirs_exist_ok=True)
        else:
            shutil.copy2(s, dest)
