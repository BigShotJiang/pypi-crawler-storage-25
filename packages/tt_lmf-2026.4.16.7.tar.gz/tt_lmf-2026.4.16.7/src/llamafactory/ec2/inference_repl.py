# Copyright 2025 the LlamaFactory team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Run an interactive text chat on the EC2 host using HuggingFace generate (inference YAML)."""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any

import torch
import yaml

from ..data import get_template_and_fix_tokenizer
from ..extras.constants import EngineName
from ..hparams import get_infer_args
from ..model import load_model, load_tokenizer


def _load_infer_dict(path: Path) -> dict[str, Any]:
    with open(path, encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    if not isinstance(data, dict):
        raise ValueError(f"Inference YAML must be a mapping: {path}")
    return data


def _apply_env_overrides(data: dict[str, Any]) -> dict[str, Any]:
    out = dict(data)
    override = os.environ.get("LF_EC2_MODEL_PATH", "").strip()
    if override:
        out["model_name_or_path"] = override
    return out


def run_chat(yaml_path: str | Path) -> int:
    path = Path(yaml_path).resolve()
    if not path.is_file():
        print(f"Inference config not found: {path}", file=sys.stderr)
        return 1

    infer_dict = _apply_env_overrides(_load_infer_dict(path))
    model_args, data_args, finetuning_args, generating_args = get_infer_args(infer_dict)

    if model_args.infer_backend != EngineName.HF:
        print(
            "ec2 inference REPL only supports infer_backend: huggingface "
            f"(got {model_args.infer_backend!r}). Adjust your inference YAML.",
            file=sys.stderr,
        )
        return 2

    tokenizer_module = load_tokenizer(model_args)
    tokenizer = tokenizer_module["tokenizer"]
    if tokenizer_module.get("processor") is not None:
        print(
            "Multimodal processor present; using text-only chat (tokenizer + generate). "
            "Image/audio/video inputs are not supported in this REPL.",
            file=sys.stderr,
        )

    get_template_and_fix_tokenizer(tokenizer, data_args)
    model = load_model(tokenizer, model_args, finetuning_args, is_trainable=False)
    model.eval()

    device = next(model.parameters()).device
    print("Interactive chat (HuggingFace). Type /exit to quit.", flush=True)

    messages: list[dict[str, str]] = []
    gen_kwargs: dict[str, Any] = {
        "max_new_tokens": generating_args.max_new_tokens,
        "do_sample": generating_args.do_sample,
        "temperature": generating_args.temperature,
        "top_p": generating_args.top_p,
        "top_k": generating_args.top_k,
        "num_beams": generating_args.num_beams,
        "repetition_penalty": generating_args.repetition_penalty,
        "length_penalty": generating_args.length_penalty,
        "pad_token_id": tokenizer.pad_token_id,
    }
    if gen_kwargs["max_new_tokens"] <= 0:
        gen_kwargs["max_new_tokens"] = generating_args.max_length
    gen_kwargs = {k: v for k, v in gen_kwargs.items() if v is not None}

    if getattr(tokenizer, "chat_template", None) is None:
        print("Tokenizer has no chat_template after template fix; cannot chat.", file=sys.stderr)
        return 2

    while True:
        try:
            line = input()
        except (EOFError, KeyboardInterrupt):
            print("", flush=True)
            break
        text = line.rstrip("\n")
        if text.strip() == "/exit":
            break
        if not text.strip():
            continue

        messages.append({"role": "user", "content": text})
        encoded = tokenizer.apply_chat_template(
            conversation=messages,
            add_generation_prompt=True,
            tokenize=True,
            return_tensors="pt",
        )
        attention_mask = None
        if hasattr(encoded, "input_ids"):
            inputs = encoded.input_ids
            attention_mask = getattr(encoded, "attention_mask", None)
        elif isinstance(encoded, dict):
            inputs = encoded["input_ids"]
            attention_mask = encoded.get("attention_mask")
        elif isinstance(encoded, torch.Tensor):
            inputs = encoded
        else:
            inputs = torch.tensor(encoded, dtype=torch.long)
        inputs = inputs.to(device)
        if inputs.dim() == 1:
            inputs = inputs.unsqueeze(0)
        if attention_mask is not None:
            attention_mask = attention_mask.to(device)
            if attention_mask.dim() == 1:
                attention_mask = attention_mask.unsqueeze(0)
        else:
            # Some tokenizers set pad_token_id == eos_token_id, so generate() cannot infer mask reliably.
            attention_mask = torch.ones_like(inputs, dtype=torch.long, device=device)

        with torch.inference_mode():
            output_ids = model.generate(input_ids=inputs, attention_mask=attention_mask, **gen_kwargs)

        seq = output_ids[0].tolist()
        prompt_len = int(inputs.shape[-1])
        new_tokens = seq[prompt_len:]
        reply = tokenizer.decode(
            new_tokens,
            skip_special_tokens=generating_args.skip_special_tokens,
        )
        print(reply, flush=True)
        messages.append({"role": "assistant", "content": reply})

    return 0


def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: python -m llamafactory.ec2.inference_repl <inference.yaml>", file=sys.stderr)
        raise SystemExit(1)
    raise SystemExit(run_chat(sys.argv[1]))


if __name__ == "__main__":
    main()
