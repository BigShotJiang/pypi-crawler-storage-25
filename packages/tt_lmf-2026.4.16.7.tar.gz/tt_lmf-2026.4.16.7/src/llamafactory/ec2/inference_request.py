# Copyright 2025 the LlamaFactory team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Send one inference payload to the EC2 localhost inference server."""

from __future__ import annotations

import argparse
import json
import socket


def request(prompt: str, host: str, port: int, timeout_sec: int) -> int:
    payload = {"prompt": prompt}
    with socket.create_connection((host, port), timeout=timeout_sec) as s:
        s.sendall((json.dumps(payload, ensure_ascii=True) + "\n").encode("utf-8"))
        raw = b""
        while not raw.endswith(b"\n"):
            chunk = s.recv(4096)
            if not chunk:
                break
            raw += chunk
    out = json.loads(raw.decode("utf-8").strip() or "{}")
    if "error" in out:
        print(f"ERROR: {out['error']}")
        return 1
    print(out.get("text", ""))
    return 0


def main() -> None:
    parser = argparse.ArgumentParser(description="Send one prompt to the EC2 inference payload server.")
    parser.add_argument("--prompt", required=True, help="User prompt payload")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=18080)
    parser.add_argument("--timeout-sec", type=int, default=600)
    args = parser.parse_args()
    raise SystemExit(request(args.prompt, args.host, args.port, args.timeout_sec))


if __name__ == "__main__":
    main()
