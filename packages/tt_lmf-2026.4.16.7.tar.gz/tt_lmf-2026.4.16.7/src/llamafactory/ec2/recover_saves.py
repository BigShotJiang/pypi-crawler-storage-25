# Copyright 2025 the LlamaFactory team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Pull checkpoints from EC2 when the main runner's final rsync failed (e.g. broken pipe).

Reads ``.ec2_state`` left in the workspace when ``run_ec2_training`` could not sync."""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path

from .config import EC2SSHSettings
from .runner import (
    EC2TrainingError,
    preflight_ssh_key_permissions,
    pull_saves_from_remote,
    start_ec2_instance,
    stop_ec2_instance,
    wait_ssh_ready,
)


def _configure_logging() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="[%(levelname)s|%(name)s] %(message)s",
    )


def main(argv: list[str] | None = None) -> int:
    _configure_logging()
    parser = argparse.ArgumentParser(
        description=(
            "Recover LlamaFactory EC2 checkpoints after a failed final rsync. "
            "Requires `.ec2_state` from the interrupted run (same format as scripts/ec2_sft/sync_results.sh)."
        )
    )
    parser.add_argument(
        "--state-file",
        default=".ec2_state",
        help="Path to `.ec2_state` (default: ./.ec2_state)",
    )
    parser.add_argument(
        "--start-instance",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Call EC2 StartInstances before SSH (default: true). Use --no-start-instance if already running.",
    )
    parser.add_argument(
        "--stop-instance-after",
        action="store_true",
        help="Stop the instance after a successful pull (optional; default leaves it running).",
    )
    args = parser.parse_args(argv)

    state_path = Path(args.state_file).expanduser().resolve()
    try:
        settings = EC2SSHSettings.from_ec2_state_file(state_path)
    except (OSError, ValueError) as e:
        print(f"Error: cannot read EC2 state file: {e}", file=sys.stderr)
        return 2

    if not settings.local_output_dir:
        print("Error: RESULTS_LOCAL missing from state file.", file=sys.stderr)
        return 2

    preflight_ssh_key_permissions(settings.key_file)

    try:
        if args.start_instance:
            start_ec2_instance(settings.instance_id, settings.region)
        wait_ssh_ready(settings)
        ok = pull_saves_from_remote(settings, write_ack=True, cleanup_ebs_artifacts=True)
        if not ok:
            return 1
        if args.stop_instance_after:
            stop_ec2_instance(settings.instance_id, settings.region)
    except EC2TrainingError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    try:
        state_path.unlink()
    except OSError:
        pass
    logging.getLogger("llamafactory.ec2").info("Recovery complete; removed %s", state_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
