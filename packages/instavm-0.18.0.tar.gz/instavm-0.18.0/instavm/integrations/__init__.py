"""
InstaVM LLM Integrations

Pre-built integrations with popular LLM frameworks to eliminate boilerplate code.

Available integrations:
- OpenAI (including Azure OpenAI)  
- LangChain
- LlamaIndex
- Ollama
- OpenAI Agents SDK Sandbox Provider (pip install instavm[agents])
- OpenAI Agents SDK Cloud Mount Strategy (pip install instavm[agents])

Usage:
    from instavm.integrations.openai import get_tools, execute_tool
    from instavm.integrations.langchain import get_langchain_tools  
    from instavm.integrations.llamaindex import get_llamaindex_tools
    from instavm.integrations.ollama import OllamaAgent
    from instavm.integrations.openai_agents import InstaVMSandboxClient
    from instavm.integrations.mounts import InstaVMCloudBucketMountStrategy

Each integration provides simple utility functions - no complex classes needed!
"""