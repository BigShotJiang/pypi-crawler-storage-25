"""
InstaVM sandbox provider for the OpenAI Agents SDK (v0.14.0+).

Install with::

    pip install instavm[agents]

Usage::

    from instavm.integrations.openai_agents import (
        InstaVMSandboxClient,
        InstaVMSandboxClientOptions,
    )
    from agents import Runner, RunConfig
    from agents.sandbox import SandboxAgent, SandboxRunConfig

    agent = SandboxAgent(name="coder", model="gpt-4o")
    result = await Runner.run(
        agent,
        "Hello",
        run_config=RunConfig(
            sandbox=SandboxRunConfig(
                client=InstaVMSandboxClient(api_key="..."),
                options=InstaVMSandboxClientOptions(memory_mb=2048),
            ),
        ),
    )
"""

from __future__ import annotations

import asyncio
import base64
import codecs
import io
import json
import logging
import math
import os
import posixpath
import re
import shlex
import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from typing import Any, Literal

try:
    from pydantic import Field

    from agents.sandbox.errors import (
        ConfigurationError,
        ErrorCode,
        ExecNonZeroError,
        ExecTimeoutError,
        ExecTransportError,
        InvalidManifestPathError,
        WorkspaceArchiveReadError,
        WorkspaceArchiveWriteError,
        WorkspaceReadNotFoundError,
        WorkspaceWriteTypeError,
    )
    from agents.sandbox.manifest import Manifest
    from agents.sandbox.session import SandboxSession, SandboxSessionState
    from agents.sandbox.session.base_sandbox_session import BaseSandboxSession
    from agents.sandbox.session.dependencies import Dependencies
    from agents.sandbox.session.manager import Instrumentation
    from agents.sandbox.session.pty_types import (
        PTY_PROCESSES_MAX,
        PTY_PROCESSES_WARNING,
        PtyExecUpdate,
        allocate_pty_process_id,
        clamp_pty_yield_time_ms,
        process_id_to_prune_from_meta,
        resolve_pty_write_yield_time_ms,
        truncate_text_by_tokens,
    )
    from agents.sandbox.session.sandbox_client import BaseSandboxClient, BaseSandboxClientOptions
    from agents.sandbox.snapshot import SnapshotBase, SnapshotSpec, resolve_snapshot
    from agents.sandbox.types import ExecResult, ExposedPortEndpoint, User

    _AGENTS_AVAILABLE = True
except ImportError:
    _AGENTS_AVAILABLE = False

from ..sandbox_client import InstaVM

logger = logging.getLogger(__name__)

DEFAULT_INSTAVM_WORKSPACE_ROOT = "/workspace"

# Magic prefix for native InstaVM VM snapshot references.  The framework
# stores the result of persist_workspace() via SnapshotBase.persist(), which
# only sees an opaque byte stream.  We use a magic prefix so hydrate_workspace()
# can distinguish a native snapshot reference from a plain tar archive.
_INSTAVM_SNAPSHOT_MAGIC = b"__INSTAVM_SNAPSHOT__"


def _encode_instavm_snapshot_ref(*, snapshot_id: str) -> bytes:
    """Encode a native snapshot id into the magic-prefixed format."""
    body = json.dumps(
        {"snapshot_id": snapshot_id}, separators=(",", ":"), sort_keys=True
    ).encode("utf-8")
    return _INSTAVM_SNAPSHOT_MAGIC + body


def _decode_instavm_snapshot_ref(raw: bytes) -> str | None:
    """Decode a snapshot ref; returns the snapshot_id or None for non-native payloads."""
    if not raw.startswith(_INSTAVM_SNAPSHOT_MAGIC):
        return None
    body = raw[len(_INSTAVM_SNAPSHOT_MAGIC) :]
    try:
        obj = json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return None
    snapshot_id = obj.get("snapshot_id") if isinstance(obj, dict) else None
    return snapshot_id if isinstance(snapshot_id, str) and snapshot_id else None


def _require_agents_sdk() -> None:
    """Raise a clear install hint if the Agents SDK is not available."""
    if not _AGENTS_AVAILABLE:
        raise ImportError(
            "The openai_agents integration requires optional dependencies. "
            "Install them with: pip install instavm[agents]"
        )


if not _AGENTS_AVAILABLE:
    # Module was imported without optional deps — public names are placeholders
    # that raise on use.  This keeps the module importable for introspection.
    def __getattr__(name: str):  # type: ignore[override]
        _require_agents_sdk()
        raise AttributeError(name)

else:
    # -----------------------------------------------------------------------
    # All class definitions below require the optional agents SDK.
    # -----------------------------------------------------------------------

    # ---------------------------------------------------------------------------
    # Session state — persisted between runs for resume
    # ---------------------------------------------------------------------------


    class InstaVMSandboxSessionState(SandboxSessionState):
        """Serializable state for an InstaVM-backed sandbox session."""

        type: Literal["instavm"] = "instavm"

        # InstaVM identifiers needed for reconnection.
        instavm_session_id: str
        base_url: str = "https://api.instavm.io"

        # Options captured at create-time so resume can recreate if needed.
        timeout: int = 300
        cpu_count: int | None = None
        memory_mb: int | None = None
        env: dict[str, str] = Field(default_factory=dict)
        metadata: dict[str, Any] = Field(default_factory=dict)

        # Egress policy captured at create-time for resume reapplication.
        allow_internet_access: bool = True
        allow_http: bool = True
        allow_https: bool = True
        allow_package_managers: bool = True
        allowed_domains: tuple[str, ...] = ()
        allowed_cidrs: tuple[str, ...] = ()

        @property
        def _has_egress_restrictions(self) -> bool:
            """Return True when any egress field differs from the unrestricted default."""
            return (
                not self.allow_internet_access
                or not self.allow_http
                or not self.allow_https
                or not self.allow_package_managers
                or len(self.allowed_domains) > 0
                or len(self.allowed_cidrs) > 0
            )


    # ---------------------------------------------------------------------------
    # Client options — auto-registers "instavm" backend via Pydantic subclass hook
    # ---------------------------------------------------------------------------


    class InstaVMSandboxClientOptions(BaseSandboxClientOptions):
        """Client options for the InstaVM sandbox backend."""

        type: Literal["instavm"] = "instavm"

        memory_mb: int | None = None
        cpu_count: int | None = None
        timeout: int = 300
        env: dict[str, str] = Field(default_factory=dict)
        metadata: dict[str, Any] = Field(default_factory=dict)
        snapshot_id: str | None = None
        exposed_ports: tuple[int, ...] = ()

        # When True the backend automatically takes a VM snapshot just before the
        # VM is terminated, making the next ``resume()`` faster because the saved
        # snapshot can be used to recreate the workspace without tar extraction.
        snapshot_on_terminate: bool = False
        snapshot_name: str | None = None

        # Egress / network policy — applied immediately after session creation.
        # When ``allow_internet_access`` is False, all outbound traffic is blocked
        # except for domains/CIDRs in the allow-lists.
        # NOTE: Free-plan accounts have server-side egress restrictions
        # (HTTP/HTTPS blocked). Upgrading to a paid plan unlocks full control.
        allow_internet_access: bool = True
        allow_http: bool = True
        allow_https: bool = True
        allow_package_managers: bool = True
        allowed_domains: tuple[str, ...] = ()
        allowed_cidrs: tuple[str, ...] = ()

        def __init__(
            self,
            memory_mb: int | None = None,
            cpu_count: int | None = None,
            timeout: int = 300,
            env: dict[str, str] | None = None,
            metadata: dict[str, Any] | None = None,
            snapshot_id: str | None = None,
            exposed_ports: tuple[int, ...] = (),
            snapshot_on_terminate: bool = False,
            snapshot_name: str | None = None,
            allow_internet_access: bool = True,
            allow_http: bool = True,
            allow_https: bool = True,
            allow_package_managers: bool = True,
            allowed_domains: tuple[str, ...] | list[str] = (),
            allowed_cidrs: tuple[str, ...] | list[str] = (),
            *,
            type: Literal["instavm"] = "instavm",
        ) -> None:
            super().__init__(
                type=type,
                memory_mb=memory_mb,
                cpu_count=cpu_count,
                timeout=timeout,
                env=env or {},
                metadata=metadata or {},
                snapshot_id=snapshot_id,
                exposed_ports=exposed_ports,
                snapshot_on_terminate=snapshot_on_terminate,
                snapshot_name=snapshot_name,
                allow_internet_access=allow_internet_access,
                allow_http=allow_http,
                allow_https=allow_https,
                allow_package_managers=allow_package_managers,
                allowed_domains=tuple(allowed_domains),
                allowed_cidrs=tuple(allowed_cidrs),
            )


    # ---------------------------------------------------------------------------
    # PTY entry — tracks one remote PTY process proxied over WebSocket
    # ---------------------------------------------------------------------------

    @dataclass
    class _RemotePtyEntry:
        """State for a single PTY process running inside a remote InstaVM VM.

        The in-VM PTY service exposes REST lifecycle + WebSocket I/O.  This
        entry holds the WS connection and a local output buffer that the
        collect/finalize cycle drains on each SDK call.
        """

        pty_id: str
        tty: bool
        ws: Any | None = None  # websockets.WebSocketClientProtocol
        last_used: float = field(default_factory=time.monotonic)
        output_chunks: deque[bytes] = field(default_factory=deque)
        output_lock: asyncio.Lock = field(default_factory=asyncio.Lock)
        output_notify: asyncio.Event = field(default_factory=asyncio.Event)
        closed: bool = False
        exit_code: int | None = None
        pump_task: asyncio.Task[None] | None = None
        # When the non-TTY exec path hits a transport/timeout error we stash
        # the exception here so the caller can re-raise it properly instead of
        # delivering a misleading empty PtyExecUpdate.
        exec_error: BaseException | None = None
        # Incremental decoder handles multi-byte UTF-8 chars split across chunks
        _utf8_decoder: codecs.IncrementalDecoder = field(
            default_factory=lambda: codecs.getincrementaldecoder("utf-8")("replace"),
        )


    # ---------------------------------------------------------------------------
    # Sandbox session — wraps the sync InstaVM SDK with asyncio.to_thread
    # ---------------------------------------------------------------------------


    class InstaVMSandboxSession(BaseSandboxSession):
        """SandboxSession implementation backed by an InstaVM VM."""

        state: InstaVMSandboxSessionState
        _client: InstaVM | None
        _api_key: str | None

        def __init__(
            self,
            *,
            state: InstaVMSandboxSessionState,
            client: InstaVM | None = None,
            api_key: str | None = None,
        ) -> None:
            self.state = state
            self._client = client
            self._api_key = api_key or os.environ.get("INSTAVM_API_KEY")
            # Tri-state: None = not yet probed, True = API returns exit_code,
            # False = old API, use sentinel wrapping.
            self._api_has_exit_code: bool | None = None
            # PTY state
            self._pty_lock = asyncio.Lock()
            self._pty_entries: dict[int, _RemotePtyEntry] = {}
            self._reserved_pty_ids: set[int] = set()

        @classmethod
        def from_state(
            cls,
            state: InstaVMSandboxSessionState,
            *,
            client: InstaVM | None = None,
            api_key: str | None = None,
        ) -> InstaVMSandboxSession:
            return cls(state=state, client=client, api_key=api_key)

        def supports_pty(self) -> bool:
            return True

        # -- helpers ---------------------------------------------------------

        def _ensure_client(self) -> InstaVM:
            if self._client is not None:
                return self._client
            if not self._api_key:
                raise ConfigurationError(
                    message=(
                        "Cannot reconstruct InstaVM client: no API key available. "
                        "Set the INSTAVM_API_KEY environment variable or pass api_key "
                        "to InstaVMSandboxClient."
                    ),
                    error_code=ErrorCode.SANDBOX_CONFIG_INVALID,
                    op="ensure_client",
                    context={"backend": "instavm"},
                )
            self._client = InstaVM(
                api_key=self._api_key,
                base_url=self.state.base_url,
                timeout=self.state.timeout,
                cpu_count=self.state.cpu_count,
                memory_mb=self.state.memory_mb,
                env=dict(self.state.env),
                metadata=dict(self.state.metadata),
                auto_start_session=False,
            )
            self._client.session_id = self.state.instavm_session_id
            return self._client

        async def _run_in_thread(self, fn, *args, **kwargs):
            """Run a sync InstaVM SDK call in a thread to avoid blocking the event loop."""
            return await asyncio.to_thread(fn, *args, **kwargs)

        def normalize_path(self, path: Path | str) -> Path:  # type: ignore[override]
            if isinstance(path, str):
                path = PurePosixPath(path)
            elif not isinstance(path, PurePosixPath):
                # Convert platform Path to PurePosixPath to avoid backslashes on Windows.
                path = PurePosixPath(*path.parts)
            root = PurePosixPath(posixpath.normpath(self.state.manifest.root))
            normalized = PurePosixPath(
                posixpath.normpath(
                    str(path) if path.is_absolute() else str(root / path)
                )
            )
            try:
                normalized.relative_to(root)
            except ValueError:
                from agents.sandbox.errors import InvalidManifestPathError

                reason: Literal["absolute", "escape_root"] = (
                    "absolute" if path.is_absolute() else "escape_root"
                )
                raise InvalidManifestPathError(rel=path, reason=reason)
            return normalized  # type: ignore[return-value]

        async def _normalize_path_for_io(self, path: Path | str) -> Path:
            return self.normalize_path(path)

        async def _verify_path_containment(
            self, workspace_path: Path, *, parent_only: bool = False,
        ) -> None:
            """Run ``realpath`` inside the VM to verify symlinks don't escape the workspace.

            When *parent_only* is True (used for writes where the leaf may not
            exist yet), the check first tries to resolve the full path.  If the
            leaf does not exist, it falls back to resolving the parent and
            re-attaching the basename.  This prevents an existing leaf symlink
            (e.g. ``/workspace/out -> /etc/passwd``) from bypassing containment.
            """
            root = self.state.manifest.root
            qpath = shlex.quote(str(workspace_path))
            qroot = shlex.quote(str(root))
            if parent_only:
                # Try full resolve first (catches existing symlink leaves).
                # Fall back to parent resolve when the leaf doesn't exist yet.
                script = (
                    f'resolved=$(realpath -- {qpath} 2>/dev/null); '
                    f'if [ -z "$resolved" ]; then '
                    f'  p=$(dirname {qpath}) && '
                    f'  rp=$(realpath -- "$p" 2>/dev/null) || exit 111; '
                    f'  resolved="$rp/$(basename {qpath})"; '
                    f'fi; '
                    f'case "$resolved" in {qroot}|{qroot}/*) echo ok;; *) exit 111;; esac'
                )
            else:
                script = (
                    f'resolved=$(realpath -- {qpath} 2>/dev/null) || exit 111; '
                    f'case "$resolved" in {qroot}|{qroot}/*) echo ok;; *) exit 111;; esac'
                )
            result = await self._exec_internal("sh", "-c", script)
            if not result.ok():
                raise InvalidManifestPathError(rel=Path(str(workspace_path)), reason="escape_root")

        @staticmethod
        def _is_session_active(status: object) -> bool:
            """Check whether a get_session_status response indicates the session is usable.

            The InstaVM status dict contains ``exists``, ``vm_assigned``,
            ``vm_alive``, and ``vm_status`` — there is no top-level ``status``
            key.  A session is considered active when it exists and either:
            * no VM has been assigned yet (lazy assignment on first exec), or
            * the assigned VM is still alive.
            """
            if not isinstance(status, dict):
                return False
            if not status.get("exists", False):
                return False
            # VM not yet assigned — session is still valid (lazy assignment).
            if not status.get("vm_assigned", False):
                return True
            # VM assigned — check if it is alive.
            return bool(status.get("vm_alive", False))

        # -- lifecycle -------------------------------------------------------

        async def _ensure_backend_started(self) -> None:
            """Start or reconnect the InstaVM session."""
            client = self._ensure_client()
            try:
                status = await self._run_in_thread(
                    client.get_session_status, self.state.instavm_session_id
                )
                if self._is_session_active(status):
                    return
            except Exception:
                pass

            # Session gone or not running — create a new one.
            sid = await self._run_in_thread(client.start_session)
            self.state.instavm_session_id = sid
            client.session_id = sid
            # A fresh VM won't have the workspace prepared.
            self.state.workspace_root_ready = False

        async def _prepare_backend_workspace(self) -> None:
            root = self.state.manifest.root
            result = await self._exec_internal("mkdir", "-p", root)
            if not result.ok():
                from agents.sandbox.errors import WorkspaceStartError

                raise WorkspaceStartError(
                    path=Path(root),
                    context={
                        "exit_code": result.exit_code,
                        "stderr": result.stderr.decode("utf-8", errors="replace"),
                    },
                )

        async def _shutdown_backend(self) -> None:
            client = self._ensure_client()
            try:
                await self._run_in_thread(client.kill, self.state.instavm_session_id)
            except Exception:
                # The /kill endpoint may return 404 when the session has already
                # expired or been cleaned up — this is expected and safe to ignore.
                logger.debug(
                    "InstaVM session cleanup returned an error (session may already be expired).",
                    extra={"session_id": self.state.instavm_session_id},
                )

        async def shutdown(self) -> None:
            await self.pty_terminate_all()
            await self._shutdown_backend()
            self._client = None

        # -- PTY support -------------------------------------------------------

        async def pty_exec_start(
            self,
            *command: str | Path,
            timeout: float | None = None,
            shell: bool | list[str] = True,
            user: str | User | None = None,
            tty: bool = False,
            yield_time_s: float | None = None,
            max_output_tokens: int | None = None,
        ) -> PtyExecUpdate:
            client = self._ensure_client()
            sanitized = self._prepare_exec_command(*command, shell=shell, user=user)
            cmd_str = shlex.join(str(part) for part in sanitized)
            session_id = self.state.instavm_session_id

            pty_id = f"pty-{uuid.uuid4().hex[:12]}"
            entry = _RemotePtyEntry(pty_id=pty_id, tty=tty)

            # For TTY mode, validate websockets is importable *before*
            # creating a remote PTY session to avoid orphaned resources.
            if tty:
                try:
                    import websockets
                except ImportError:
                    raise ImportError(
                        "PTY support requires websockets. "
                        "Install with: pip install instavm[pty]"
                    )

            registered = False
            try:
                if tty:
                    # Create the in-VM PTY session via REST
                    resp = await self._run_in_thread(
                        client.pty.create, session_id, 80, 24, None, pty_id,
                    )
                    entry.pty_id = resp.get("session_id", pty_id)

                    # Connect WebSocket and start the output pump
                    ws_url = client.pty.ws_url(session_id, entry.pty_id)
                    connect_timeout = min(timeout, 30) if timeout else 15
                    ws = await asyncio.wait_for(
                        websockets.connect(ws_url, ping_interval=20, ping_timeout=20),
                        timeout=connect_timeout,
                    )
                    entry.ws = ws
                    entry.pump_task = asyncio.create_task(self._pump_pty_ws(entry))

                    # Send the command as first input
                    await asyncio.wait_for(
                        ws.send(cmd_str.encode("utf-8") + b"\n"),
                        timeout=5,
                    )
                else:
                    # Non-TTY: run via the normal exec path — no remote PTY needed.
                    # Use the sanitized command so shell/user settings are respected.
                    async def _exec_and_capture() -> None:
                        try:
                            result = await self._exec_internal(
                                *sanitized, timeout=timeout,
                            )
                            raw = result.stdout + result.stderr
                            async with entry.output_lock:
                                entry.output_chunks.append(raw)
                            entry.exit_code = result.exit_code
                        except asyncio.TimeoutError as exc:
                            entry.exec_error = exc
                            entry.exit_code = 1
                        except Exception as exc:
                            entry.exec_error = exc
                            err_msg = f"[PTY non-tty exec error] {type(exc).__name__}: {exc}"
                            async with entry.output_lock:
                                entry.output_chunks.append(err_msg)
                            entry.exit_code = 1
                        finally:
                            entry.closed = True
                            entry.output_notify.set()

                    entry.pump_task = asyncio.create_task(_exec_and_capture())

                # Register in the process table
                pruned: _RemotePtyEntry | None = None
                async with self._pty_lock:
                    process_id = allocate_pty_process_id(self._reserved_pty_ids)
                    self._reserved_pty_ids.add(process_id)
                    pruned = self._evict_lru_pty()
                    self._pty_entries[process_id] = entry
                    count = len(self._pty_entries)
                    registered = True

                if pruned is not None:
                    await self._teardown_pty(pruned)

                if count >= PTY_PROCESSES_WARNING:
                    logger.warning("PTY count at warning threshold: %s", count)

            except asyncio.TimeoutError as e:
                if not registered:
                    await self._teardown_pty(entry)
                raise ExecTimeoutError(command=command, timeout_s=timeout, cause=e) from e
            except (ImportError, ExecTimeoutError):
                raise
            except Exception as e:
                if not registered:
                    await self._teardown_pty(entry)
                raise ExecTransportError(command=command, cause=e) from e

            yield_time_ms = 10_000 if yield_time_s is None else int(yield_time_s * 1000)
            output, token_count = await self._collect_pty_output(
                entry=entry,
                yield_time_ms=clamp_pty_yield_time_ms(yield_time_ms),
                max_output_tokens=max_output_tokens,
            )

            # Re-raise transport/timeout errors from the non-TTY background task
            # so callers see proper exceptions instead of empty PtyExecUpdates.
            if entry.exec_error is not None:
                exc = entry.exec_error
                if isinstance(exc, asyncio.TimeoutError):
                    raise ExecTimeoutError(command=command, timeout_s=timeout, cause=exc) from exc
                raise ExecTransportError(command=command, cause=exc) from exc

            return await self._finalize_pty_update(
                process_id=process_id,
                entry=entry,
                output=output,
                original_token_count=token_count,
            )

        async def pty_write_stdin(
            self,
            *,
            session_id: int,
            chars: str,
            yield_time_s: float | None = None,
            max_output_tokens: int | None = None,
        ) -> PtyExecUpdate:
            async with self._pty_lock:
                entry = self._resolve_pty_session_entry(
                    pty_processes=self._pty_entries,
                    session_id=session_id,
                )

            if chars:
                if not entry.tty or entry.ws is None:
                    raise RuntimeError("stdin is not available for this process")
                try:
                    await asyncio.wait_for(
                        entry.ws.send(chars.encode("utf-8")),
                        timeout=5,
                    )
                except Exception as exc:
                    entry.closed = True
                    entry.exit_code = 1
                    entry.output_notify.set()
                    raise ExecTransportError(
                        command=("<write_stdin>",), cause=exc,
                    ) from exc
                # Brief pause so the remote PTY has time to echo before we
                # start the output-collection window (all upstream providers
                # include this 0.1 s delay).
                await asyncio.sleep(0.1)

            yield_time_ms = 250 if yield_time_s is None else int(yield_time_s * 1000)
            output, token_count = await self._collect_pty_output(
                entry=entry,
                yield_time_ms=resolve_pty_write_yield_time_ms(
                    yield_time_ms=yield_time_ms, input_empty=chars == ""
                ),
                max_output_tokens=max_output_tokens,
            )
            entry.last_used = time.monotonic()
            return await self._finalize_pty_update(
                process_id=session_id,
                entry=entry,
                output=output,
                original_token_count=token_count,
            )

        async def pty_terminate_all(self) -> None:
            async with self._pty_lock:
                entries = list(self._pty_entries.values())
                self._pty_entries.clear()
                self._reserved_pty_ids.clear()
            for entry in entries:
                await self._teardown_pty(entry)

        # -- PTY internals -----------------------------------------------------

        async def _pump_pty_ws(self, entry: _RemotePtyEntry) -> None:
            """Read frames from the in-VM PTY WebSocket into output_chunks."""
            ws = entry.ws
            if ws is None:
                return
            try:
                async for msg in ws:
                    if isinstance(msg, bytes):
                        async with entry.output_lock:
                            entry.output_chunks.append(msg)
                        entry.output_notify.set()
                    elif isinstance(msg, str):
                        try:
                            frame = json.loads(msg)
                        except json.JSONDecodeError:
                            continue
                        if frame.get("type") == "exit":
                            entry.exit_code = frame.get("exit_code")
                            break
            except Exception:
                pass
            finally:
                entry.closed = True
                entry.output_notify.set()

        async def _collect_pty_output(
            self,
            *,
            entry: _RemotePtyEntry,
            yield_time_ms: int,
            max_output_tokens: int | None,
        ) -> tuple[bytes, int | None]:
            """Drain buffered output until deadline or stream closes."""
            deadline = time.monotonic() + (yield_time_ms / 1000)
            output = bytearray()

            while True:
                async with entry.output_lock:
                    while entry.output_chunks:
                        output.extend(entry.output_chunks.popleft())

                if time.monotonic() >= deadline:
                    break

                if entry.closed:
                    async with entry.output_lock:
                        while entry.output_chunks:
                            output.extend(entry.output_chunks.popleft())
                    break

                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    break

                try:
                    await asyncio.wait_for(entry.output_notify.wait(), timeout=remaining)
                except asyncio.TimeoutError:
                    break
                entry.output_notify.clear()

            text = entry._utf8_decoder.decode(bytes(output), False)
            truncated, token_count = truncate_text_by_tokens(text, max_output_tokens)
            return truncated.encode("utf-8", errors="replace"), token_count

        async def _finalize_pty_update(
            self,
            *,
            process_id: int,
            entry: _RemotePtyEntry,
            output: bytes,
            original_token_count: int | None,
        ) -> PtyExecUpdate:
            exit_code = entry.exit_code if entry.closed else None
            live_id: int | None = process_id

            if entry.closed:
                async with self._pty_lock:
                    removed = self._pty_entries.pop(process_id, None)
                    self._reserved_pty_ids.discard(process_id)
                if removed is not None:
                    await self._teardown_pty(removed)
                live_id = None

            return PtyExecUpdate(
                process_id=live_id,
                output=output,
                exit_code=exit_code,
                original_token_count=original_token_count,
            )

        def _evict_lru_pty(self) -> _RemotePtyEntry | None:
            """Evict the least-recently-used PTY entry if at capacity."""
            if len(self._pty_entries) < PTY_PROCESSES_MAX:
                return None
            meta: list[tuple[int, float, bool]] = [
                (pid, e.last_used, e.closed)
                for pid, e in self._pty_entries.items()
            ]
            pid = process_id_to_prune_from_meta(meta)
            if pid is None:
                return None
            self._reserved_pty_ids.discard(pid)
            return self._pty_entries.pop(pid, None)

        async def _teardown_pty(self, entry: _RemotePtyEntry) -> None:
            """Close the WS connection and kill the remote PTY session."""
            if entry.pump_task is not None:
                entry.pump_task.cancel()
                try:
                    await entry.pump_task
                except (asyncio.CancelledError, Exception):
                    pass
            if entry.ws is not None:
                try:
                    await entry.ws.close()
                except Exception:
                    pass
                entry.ws = None
            # Best-effort kill via REST
            try:
                client = self._ensure_client()
                sid = self.state.instavm_session_id
                await self._run_in_thread(client.pty.kill, sid, entry.pty_id)
            except Exception:
                pass

        # -- abstract method implementations ----------------------------------

        # Sentinel used to extract exit codes from stdout when the API does not
        # return an exit_code field natively (pre-v0.18 backend).
        _EXIT_CODE_SENTINEL = "__INSTAVM_EC__"

        async def _exec_internal(
            self,
            *command: str | Path,
            timeout: float | None = None,
        ) -> ExecResult:
            client = self._ensure_client()
            raw_cmd = shlex.join(str(c) for c in command)
            int_timeout = max(1, math.ceil(timeout)) if timeout is not None else None

            # First call: probe with a no-op to detect native exit_code support
            # without executing the user's command twice.
            if self._api_has_exit_code is None:
                probe = await self._exec_raw(client, "true", 10, 10.0)
                self._api_has_exit_code = (
                    "exit_code" in probe and probe["exit_code"] is not None
                )

            if self._api_has_exit_code:
                result = await self._exec_raw(client, raw_cmd, int_timeout, timeout)
                return self._parse_native_result(result)
            else:
                return await self._exec_with_sentinel(client, raw_cmd, int_timeout, timeout)

        async def _exec_raw(
            self,
            client: InstaVM,
            cmd_str: str,
            int_timeout: int | None,
            timeout: float | None,
        ) -> dict[str, Any]:
            """Execute a command without sentinel wrapping."""
            try:
                if timeout is not None:
                    return await asyncio.wait_for(
                        self._run_in_thread(client.execute, cmd_str, "bash", int_timeout),
                        timeout=timeout + 5,
                    )
                return await self._run_in_thread(client.execute, cmd_str, "bash", int_timeout)
            except (TimeoutError, asyncio.TimeoutError) as exc:
                raise ExecTimeoutError(
                    command=(cmd_str,), timeout_s=timeout, cause=exc
                ) from exc
            except ExecTimeoutError:
                raise
            except Exception as exc:
                raise ExecTransportError(
                    command=(cmd_str,),
                    context={"backend": "instavm", "session_id": self.state.instavm_session_id},
                    cause=exc,
                ) from exc

        def _parse_native_result(self, result: dict[str, Any]) -> ExecResult:
            """Parse an API response that includes a native exit_code field."""
            stdout = str(result.get("stdout", "") or "")
            stderr = str(result.get("stderr", "") or "")
            exit_code = int(result.get("exit_code", 0) or 0)
            return ExecResult(
                stdout=stdout.encode("utf-8", errors="replace"),
                stderr=stderr.encode("utf-8", errors="replace"),
                exit_code=exit_code,
            )

        async def _exec_with_sentinel(
            self,
            client: InstaVM,
            raw_cmd: str,
            int_timeout: int | None,
            timeout: float | None,
        ) -> ExecResult:
            """Execute with sentinel wrapping to extract exit code from stdout."""
            sentinel = self._EXIT_CODE_SENTINEL
            cmd_str = f"{raw_cmd}\n__ec=$?\necho\necho \"{sentinel}$__ec\"\nexit 0"

            try:
                if timeout is not None:
                    result = await asyncio.wait_for(
                        self._run_in_thread(client.execute, cmd_str, "bash", int_timeout),
                        timeout=timeout + 5,
                    )
                else:
                    result = await self._run_in_thread(client.execute, cmd_str, "bash", int_timeout)

                stdout_raw = str(result.get("stdout", "") or "")
                stderr = str(result.get("stderr", "") or "")

                # Extract exit code from the sentinel line and strip it from stdout.
                exit_code = 0
                stdout_lines = stdout_raw.split("\n")
                cleaned_lines: list[str] = []
                for line in stdout_lines:
                    if line.startswith(sentinel):
                        try:
                            exit_code = int(line[len(sentinel):].strip())
                        except ValueError:
                            pass
                    else:
                        cleaned_lines.append(line)

                stdout = "\n".join(cleaned_lines)
                if cleaned_lines and stdout_raw.endswith("\n"):
                    stdout = stdout.rstrip("\n") + "\n"

                # If we didn't find a sentinel (e.g. IPython caught the error),
                # try to parse exit code from CalledProcessError in stderr.
                if sentinel not in stdout_raw and "CalledProcessError" in stderr:
                    m = re.search(r"non-zero exit status (\d+)", stderr)
                    if m:
                        exit_code = int(m.group(1))

                return ExecResult(
                    stdout=stdout.encode("utf-8", errors="replace"),
                    stderr=stderr.encode("utf-8", errors="replace"),
                    exit_code=exit_code,
                )
            except (TimeoutError, asyncio.TimeoutError) as exc:
                raise ExecTimeoutError(
                    command=(raw_cmd,), timeout_s=timeout, cause=exc
                ) from exc
            except ExecTimeoutError:
                raise
            except Exception as exc:
                raise ExecTransportError(
                    command=(raw_cmd,),
                    context={"backend": "instavm", "session_id": self.state.instavm_session_id},
                    cause=exc,
                ) from exc

        def _reject_user_arg(
            self, *, op: Literal["exec", "read", "write"], user: str | User,
        ) -> None:
            user_name = user.name if isinstance(user, User) else user
            raise ConfigurationError(
                message=(
                    "InstaVMSandboxSession does not support sandbox-local users; "
                    f"`{op}` must be called without `user`"
                ),
                error_code=ErrorCode.SANDBOX_CONFIG_INVALID,
                op=op,
                context={"backend": "instavm", "user": user_name},
            )

        async def read(self, path: Path, *, user: str | User | None = None) -> io.IOBase:
            if user is not None:
                self._reject_user_arg(op="read", user=user)

            workspace_path = await self._normalize_path_for_io(path)
            # Verify symlinks don't escape the workspace (file must exist for read).
            await self._verify_path_containment(workspace_path)
            quoted = shlex.quote(str(workspace_path))
            result = await self._exec_internal(
                "sh", "-c", f"base64 < {quoted}"
            )
            if not result.ok():
                raise WorkspaceReadNotFoundError(
                    path=path,
                    context={
                        "stderr": result.stderr.decode("utf-8", errors="replace"),
                    },
                )
            encoded = result.stdout.decode("utf-8", errors="replace").strip()
            try:
                raw = base64.b64decode(encoded)
            except Exception:
                raw = result.stdout
            return io.BytesIO(raw)

        # 64 KiB per chunk keeps the base64 shell argument under ~90 KB,
        # well within the Linux ARG_MAX default (~128 KB).
        _WRITE_CHUNK_SIZE = 64 * 1024

        async def write(
            self,
            path: Path,
            data: io.IOBase,
            *,
            user: str | User | None = None,
        ) -> None:
            if user is not None:
                self._reject_user_arg(op="write", user=user)

            workspace_path = await self._normalize_path_for_io(path)
            payload = data.read()
            if isinstance(payload, str):
                payload = payload.encode("utf-8")
            if not isinstance(payload, bytes | bytearray):
                raise WorkspaceWriteTypeError(path=workspace_path, actual_type=type(payload).__name__)

            # Ensure parent directory exists.
            parent = str(PurePosixPath(str(workspace_path)).parent)
            await self._exec_internal("mkdir", "-p", parent)

            # Verify symlinks don't escape the workspace (parent must exist for write).
            await self._verify_path_containment(workspace_path, parent_only=True)

            quoted = shlex.quote(str(workspace_path))

            if len(payload) <= self._WRITE_CHUNK_SIZE:
                # Small file — single exec call.
                encoded = base64.b64encode(payload).decode("ascii")
                result = await self._exec_internal(
                    "sh", "-c",
                    f"printf '%s' {shlex.quote(encoded)} | base64 -d > {quoted}",
                )
                if not result.ok():
                    raise WorkspaceArchiveWriteError(
                        path=workspace_path,
                        cause=RuntimeError(
                            f"write failed: exit_code={result.exit_code}, "
                            f"stderr={result.stderr.decode('utf-8', errors='replace')}"
                        ),
                    )
            else:
                # Large file — write in chunks to avoid ARG_MAX limits.
                first = True
                for offset in range(0, len(payload), self._WRITE_CHUNK_SIZE):
                    chunk = payload[offset : offset + self._WRITE_CHUNK_SIZE]
                    encoded = base64.b64encode(chunk).decode("ascii")
                    op = ">" if first else ">>"
                    result = await self._exec_internal(
                        "sh", "-c",
                        f"printf '%s' {shlex.quote(encoded)} | base64 -d {op} {quoted}",
                    )
                    if not result.ok():
                        raise WorkspaceArchiveWriteError(
                            path=workspace_path,
                            cause=RuntimeError(
                                f"chunk write failed at offset {offset}: exit_code={result.exit_code}, "
                                f"stderr={result.stderr.decode('utf-8', errors='replace')}"
                            ),
                        )
                    first = False

        async def running(self) -> bool:
            client = self._ensure_client()
            try:
                status = await self._run_in_thread(
                    client.get_session_status, self.state.instavm_session_id
                )
                return self._is_session_active(status)
            except Exception:
                return False

        async def persist_workspace(self) -> io.IOBase:
            """Persist the workspace as a native InstaVM VM snapshot.

            Uses ``vms.snapshot()`` to create a full VM snapshot stored on S3.
            The returned bytes contain a magic-prefixed JSON reference that
            ``hydrate_workspace`` recognises to restore via snapshot clone
            instead of tar extraction.  Falls back to tar if the native snapshot
            call fails or the VM id is unavailable.
            """
            root = self.state.manifest.root
            client = self._ensure_client()

            # Attempt native VM snapshot.
            try:
                status = await self._run_in_thread(
                    client.get_session_status, self.state.instavm_session_id
                )
                vm_id = status.get("vm_id") if isinstance(status, dict) else None
                if isinstance(vm_id, str) and vm_id:
                    snap = await self._run_in_thread(
                        client.vms.snapshot,
                        vm_id,
                        True,  # wait
                        f"sandbox-{self.state.session_id.hex[:12]}",
                    )
                    snap_id = snap.get("id") or snap.get("snapshot_id")
                    if isinstance(snap_id, str) and snap_id:
                        return io.BytesIO(
                            _encode_instavm_snapshot_ref(snapshot_id=snap_id)
                        )
                    logger.debug("Native snapshot returned no id, falling back to tar.")
            except Exception as exc:
                logger.debug("Native VM snapshot failed, falling back to tar: %s", exc)

            return await self._persist_workspace_via_tar()

        async def _persist_workspace_via_tar(self) -> io.IOBase:
            """Fallback: persist workspace as a tar archive.

            Unmounts ephemeral FUSE/rclone mounts before running tar to avoid
            capturing remote bucket contents, then restores them afterward.
            """
            root = self.state.manifest.root
            quoted_root = shlex.quote(str(root))

            # Phase 1 — unmount ephemeral mounts so tar doesn't recurse into them.
            unmounted: list[tuple[Any, Path]] = []
            unmount_error: WorkspaceArchiveReadError | None = None
            for mount_entry, mount_path in self.state.manifest.ephemeral_mount_targets():
                try:
                    await mount_entry.mount_strategy.teardown_for_snapshot(
                        mount_entry, self, mount_path
                    )
                except Exception as e:
                    unmount_error = WorkspaceArchiveReadError(
                        path=Path(root),
                        cause=e,
                    )
                    break
                unmounted.append((mount_entry, mount_path))

            # Phase 2 — create the tar archive (only if unmounts succeeded).
            snapshot_error: WorkspaceArchiveReadError | None = None
            tar_bytes: io.BytesIO | None = None
            if unmount_error is None:
                result = await self._exec_internal(
                    "sh", "-c",
                    f"tar -C {quoted_root} -cf - . | base64",
                )
                if not result.ok():
                    snapshot_error = WorkspaceArchiveReadError(
                        path=Path(root),
                        context={
                            "reason": "tar_failed",
                            "stderr": result.stderr.decode("utf-8", errors="replace"),
                        },
                    )
                else:
                    encoded = result.stdout.decode("utf-8", errors="replace").strip()
                    try:
                        raw = base64.b64decode(encoded)
                    except Exception:
                        raw = result.stdout
                    tar_bytes = io.BytesIO(raw)

            # Phase 3 — remount in reverse order regardless of success.
            remount_error: WorkspaceArchiveReadError | None = None
            for mount_entry, mount_path in reversed(unmounted):
                try:
                    await mount_entry.mount_strategy.restore_after_snapshot(
                        mount_entry, self, mount_path
                    )
                except Exception as e:
                    current = WorkspaceArchiveReadError(path=Path(root), cause=e)
                    if remount_error is None:
                        remount_error = current
                        if unmount_error is not None:
                            remount_error.context["earlier_unmount_error"] = str(unmount_error)
                    else:
                        extras = remount_error.context.setdefault(
                            "additional_remount_errors", []
                        )
                        extras.append(str(current))

            # Priority: remount > unmount > snapshot.
            if remount_error is not None:
                if snapshot_error is not None:
                    remount_error.context["snapshot_error"] = str(snapshot_error)
                raise remount_error
            if unmount_error is not None:
                raise unmount_error
            if snapshot_error is not None:
                raise snapshot_error

            assert tar_bytes is not None
            return tar_bytes

        async def hydrate_workspace(self, data: io.IOBase) -> None:
            """Restore a workspace from a native snapshot reference or tar archive.

            Native InstaVM snapshot references are decoded and restored by creating a
            new session from the saved VM snapshot.  Non-native payloads fall back to
            tar hydration so cross-provider snapshots keep working.
            """
            root = Path(self.state.manifest.root)
            raw = data.read()
            if isinstance(raw, str):
                raw = raw.encode("utf-8")
            if not isinstance(raw, bytes | bytearray):
                raise WorkspaceWriteTypeError(path=root, actual_type=type(raw).__name__)

            snapshot_id = _decode_instavm_snapshot_ref(bytes(raw))
            if snapshot_id is not None:
                await self._hydrate_from_native_snapshot(snapshot_id)
                return

            await self._hydrate_from_tar(bytes(raw))

        async def _hydrate_from_native_snapshot(self, snapshot_id: str) -> None:
            """Replace the current session with one created from a VM snapshot.

            ``vms.create(snapshot_id=...)`` boots a new VM from the saved snapshot
            and returns both ``vm_id`` and ``session_id``, so we swap the session
            identity in-place without a separate ``start_session`` call.
            """
            root = Path(self.state.manifest.root)
            client = self._ensure_client()

            # Kill the current session first.
            try:
                await self._run_in_thread(client.kill, self.state.instavm_session_id)
            except Exception:
                pass

            try:
                # Create a new VM from the snapshot.  The API returns both vm_id
                # and session_id when booting from a snapshot.
                vm_resp = await self._run_in_thread(
                    client.vms.create,
                    True,  # wait
                    None,  # volumes
                    snapshot_id=snapshot_id,
                )
                new_session_id = vm_resp.get("session_id")
                if not isinstance(new_session_id, str) or not new_session_id:
                    raise WorkspaceArchiveWriteError(
                        path=root,
                        context={
                            "reason": "snapshot_restore_no_session_id",
                            "snapshot_id": snapshot_id,
                            "response_keys": list(vm_resp.keys()) if isinstance(vm_resp, dict) else [],
                        },
                    )

                self.state.instavm_session_id = new_session_id
                client.session_id = new_session_id
                self._workspace_root_ready = True
            except WorkspaceArchiveWriteError:
                raise
            except Exception as e:
                raise WorkspaceArchiveWriteError(
                    path=root,
                    context={
                        "reason": "snapshot_restore_failed",
                        "snapshot_id": snapshot_id,
                    },
                    cause=e,
                ) from e

        async def _hydrate_from_tar(self, raw: bytes) -> None:
            """Restore workspace from a tar archive (fallback path)."""
            root = Path(self.state.manifest.root)
            tar_path = f"/tmp/instavm-hydrate-{self.state.session_id.hex}.tar"
            quoted_tar = shlex.quote(tar_path)
            quoted_root = shlex.quote(str(root))
            chunk_size = self._WRITE_CHUNK_SIZE

            # Remove any stale file.
            await self._exec_internal("sh", "-c", f"rm -f {quoted_tar}")

            first = True
            for offset in range(0, len(raw), chunk_size):
                chunk = raw[offset : offset + chunk_size]
                encoded = base64.b64encode(chunk).decode("ascii")
                op = ">" if first else ">>"
                chunk_result = await self._exec_internal(
                    "sh", "-c",
                    f"printf '%s' {shlex.quote(encoded)} | base64 -d {op} {quoted_tar}",
                )
                if not chunk_result.ok():
                    raise WorkspaceArchiveWriteError(
                        path=root,
                        context={
                            "reason": "hydrate_chunk_write_failed",
                            "offset": offset,
                            "stderr": chunk_result.stderr.decode(
                                "utf-8", errors="replace"
                            ),
                        },
                    )
                first = False

            try:
                await self._exec_internal("mkdir", "-p", str(root))
                result = await self._exec_internal(
                    "sh", "-c",
                    f"tar -C {quoted_root} -xf {quoted_tar}"
                )
                if not result.ok():
                    raise WorkspaceArchiveWriteError(
                        path=root,
                        context={
                            "reason": "hydrate_tar_extract_failed",
                            "stderr": result.stderr.decode("utf-8", errors="replace"),
                        },
                    )
            finally:
                await self._exec_internal("sh", "-c", f"rm -f {quoted_tar}")

        # -- volume helpers --------------------------------------------------

        async def _get_vm_id(self) -> str:
            """Return the underlying VM ID for this session.

            The InstaVM session is a logical entity that wraps a VM.  Volume
            operations require the ``vm_id`` which is fetched from the session
            status endpoint and cached for the lifetime of the session object.
            """
            cached = getattr(self, "_cached_vm_id", None)
            if cached is not None:
                return cached
            client = self._ensure_client()
            status = await self._run_in_thread(
                client.get_session_status, self.state.instavm_session_id,
            )
            vm_id = status.get("vm_id")
            if not isinstance(vm_id, str) or not vm_id:
                raise ConfigurationError(
                    message=(
                        "Cannot determine VM ID for this session. "
                        "The session may not have a VM assigned yet."
                    ),
                    error_code=ErrorCode.SANDBOX_CONFIG_INVALID,
                    op="get_vm_id",
                    context={"session_id": self.state.instavm_session_id},
                )
            self._cached_vm_id = vm_id
            return vm_id

        async def mount_volume(
            self,
            volume_id: str,
            mount_path: str,
            *,
            mode: str = "rw",
            checkpoint_id: str | None = None,
        ) -> dict[str, Any]:
            """Mount an InstaVM managed volume inside the VM.

            Args:
                volume_id: The volume to mount (must already exist).
                mount_path: Absolute path inside the VM where the volume appears.
                mode: ``"rw"`` (default) or ``"ro"`` for read-only.
                checkpoint_id: Optional checkpoint to restore before mounting.

            Returns:
                The raw API response dict from the mount operation.
            """
            client = self._ensure_client()
            vm_id = await self._get_vm_id()
            return await self._run_in_thread(
                client.vms.mount_volume,
                vm_id,
                volume_id,
                mount_path,
                mode,
                checkpoint_id,
            )

        async def unmount_volume(
            self,
            volume_id: str,
            mount_path: str,
        ) -> dict[str, Any]:
            """Unmount an InstaVM managed volume from the VM.

            Args:
                volume_id: The volume to unmount.
                mount_path: The path where the volume is currently mounted.

            Returns:
                The raw API response dict from the unmount operation.
            """
            client = self._ensure_client()
            vm_id = await self._get_vm_id()
            return await self._run_in_thread(
                client.vms.unmount_volume,
                vm_id,
                volume_id,
                mount_path,
            )

        async def list_mounted_volumes(self) -> list[dict[str, Any]]:
            """List all volumes currently mounted in this VM.

            Returns:
                A list of volume mount dicts from the InstaVM API.
            """
            client = self._ensure_client()
            vm_id = await self._get_vm_id()
            return await self._run_in_thread(client.vms.list_volumes, vm_id)

        # -- Egress / network policy helpers ------------------------------------

        async def set_egress_policy(
            self,
            *,
            allow_http: bool = True,
            allow_https: bool = True,
            allow_package_managers: bool = True,
            allowed_domains: list[str] | tuple[str, ...] = (),
            allowed_cidrs: list[str] | tuple[str, ...] = (),
        ) -> dict[str, Any]:
            """Apply an egress policy to the current session.

            The policy controls outbound network access from the sandbox VM.
            Supported modes:

            * **Unrestricted** (default): all outbound traffic allowed.
            * **Package managers only**: ``allow_http=False, allow_https=False,
              allow_package_managers=True`` — only known package registry domains
              (pypi, npm, apt, etc.) are reachable.
            * **Domain / CIDR allowlist**: specific ``allowed_domains`` and/or
              ``allowed_cidrs`` with HTTP/HTTPS toggles.
            * **Nothing allowed**: set all flags to ``False`` and leave the
              allow-lists empty.

            .. note::
               Free-plan accounts have server-side egress restrictions that may
               override requested settings.  Upgrade to a paid plan for full
               egress control.
            """
            client = self._ensure_client()
            return await self._run_in_thread(
                client.set_session_egress,
                self.state.instavm_session_id,
                allow_package_managers=allow_package_managers,
                allow_http=allow_http,
                allow_https=allow_https,
                allowed_domains=list(allowed_domains),
                allowed_cidrs=list(allowed_cidrs),
            )

        async def get_egress_policy(self) -> dict[str, Any]:
            """Return the current egress policy for this session."""
            client = self._ensure_client()
            return await self._run_in_thread(
                client.get_session_egress,
                self.state.instavm_session_id,
            )

        async def _apply_egress_from_state(self) -> None:
            """Apply egress restrictions stored in session state.

            Called automatically after session creation and resume when the state
            has non-default egress settings.
            """
            if not self.state._has_egress_restrictions:
                return
            # When allow_internet_access is False, block everything except
            # explicit allow-lists.
            if not self.state.allow_internet_access:
                await self.set_egress_policy(
                    allow_http=False,
                    allow_https=False,
                    allow_package_managers=False,
                    allowed_domains=list(self.state.allowed_domains),
                    allowed_cidrs=list(self.state.allowed_cidrs),
                )
            else:
                await self.set_egress_policy(
                    allow_http=self.state.allow_http,
                    allow_https=self.state.allow_https,
                    allow_package_managers=self.state.allow_package_managers,
                    allowed_domains=list(self.state.allowed_domains),
                    allowed_cidrs=list(self.state.allowed_cidrs),
                )

        async def _resolve_exposed_port(self, port: int) -> ExposedPortEndpoint:
            """Resolve an exposed port to a publicly reachable endpoint.

            InstaVM exposes ports via *shares*: ``shares.create(port, session_id)``
            returns a URL like ``https://{share_id}.instavm.site/`` that proxies to
            the given port inside the VM.  If the share already exists it returns
            the same URL.  Falls back to the ``get_session_app_url`` path-proxy
            endpoint when share creation fails.
            """
            client = self._ensure_client()
            try:
                # Create a share for this port — returns a proper subdomain URL.
                share_resp = await self._run_in_thread(
                    client.shares.create,
                    port,
                    self.state.instavm_session_id,
                    None,   # vm_id
                    True,   # is_public
                )
                share_url = share_resp.get("url", "")
                if share_url:
                    from urllib.parse import urlsplit

                    parsed = urlsplit(share_url)
                    host = parsed.hostname or "localhost"
                    tls = parsed.scheme == "https"
                    return ExposedPortEndpoint(
                        host=host,
                        port=parsed.port or (443 if tls else 80),
                        tls=tls,
                    )

                # Fallback: use the app-url proxy endpoint.
                result = await self._run_in_thread(
                    client.get_session_app_url, self.state.instavm_session_id, port
                )
                # Prefer direct_url (subdomain) > url (path-proxy).
                app_url = result.get("direct_url") or result.get("url") or ""
                if not app_url:
                    raise ValueError("no reachable URL from app-url or shares API")
                from urllib.parse import urlsplit

                parsed = urlsplit(app_url)
                host = parsed.hostname or "localhost"
                tls = parsed.scheme == "https"
                return ExposedPortEndpoint(
                    host=host,
                    port=parsed.port or (443 if tls else 80),
                    tls=tls,
                )
            except Exception as exc:
                from agents.sandbox.errors import ExposedPortUnavailableError

                raise ExposedPortUnavailableError(
                    port=port,
                    exposed_ports=self.state.exposed_ports,
                    reason="backend_unavailable",
                    context={"backend": "instavm"},
                    cause=exc,
                ) from exc


    # ---------------------------------------------------------------------------
    # Sandbox client — factory for creating / resuming / deleting sessions
    # ---------------------------------------------------------------------------


    class InstaVMSandboxClient(BaseSandboxClient[InstaVMSandboxClientOptions]):
        """InstaVM-backed sandbox client for the OpenAI Agents SDK."""

        backend_id = "instavm"

        _api_key: str | None
        _base_url: str
        _instrumentation: Instrumentation

        def __init__(
            self,
            *,
            api_key: str | None = None,
            base_url: str = "https://api.instavm.io",
            instrumentation: Instrumentation | None = None,
            dependencies: Dependencies | None = None,
        ) -> None:
            super().__init__()
            self._api_key = api_key or os.environ.get("INSTAVM_API_KEY")
            self._base_url = base_url
            self._instrumentation = instrumentation or Instrumentation()
            self._dependencies = dependencies

        def _make_instavm_client(
            self, options: InstaVMSandboxClientOptions
        ) -> InstaVM:
            return InstaVM(
                api_key=self._api_key,
                base_url=self._base_url,
                timeout=options.timeout,
                cpu_count=options.cpu_count,
                memory_mb=options.memory_mb,
                env=dict(options.env),
                metadata=dict(options.metadata),
                auto_start_session=False,
            )

        async def create(
            self,
            *,
            snapshot: SnapshotSpec | SnapshotBase | None = None,
            manifest: Manifest | None = None,
            options: InstaVMSandboxClientOptions,
        ) -> SandboxSession:
            if options is None:
                raise ValueError("InstaVMSandboxClient.create requires options")
            manifest = manifest or Manifest(root=DEFAULT_INSTAVM_WORKSPACE_ROOT)

            # Default the manifest root to /workspace if it's the generic default.
            default_root = Manifest.model_fields["root"].default
            if manifest.root == default_root:
                manifest = manifest.model_copy(update={"root": DEFAULT_INSTAVM_WORKSPACE_ROOT})

            client = self._make_instavm_client(options)

            # Create the VM — either from a pre-built snapshot or a fresh session.
            # Extra VM-level kwargs forwarded to the InstaVM API.
            vm_extra: dict[str, Any] = {}
            if options.snapshot_on_terminate:
                vm_extra["snapshot_on_terminate"] = True
            if options.snapshot_name:
                vm_extra["snapshot_name"] = options.snapshot_name

            if options.snapshot_id:
                vm_resp = await asyncio.to_thread(
                    client.vms.create, True, None,
                    snapshot_id=options.snapshot_id, **vm_extra,
                )
                session_id_str = vm_resp.get("session_id")
                if not isinstance(session_id_str, str) or not session_id_str:
                    # Fallback: boot from snapshot gave us a VM but no session.
                    session_id_str = await asyncio.to_thread(client.start_session)
                client.session_id = session_id_str
            elif vm_extra:
                # Use vms.create to pass snapshot_on_terminate to the API.
                vm_resp = await asyncio.to_thread(
                    client.vms.create, True, None, **vm_extra,
                )
                session_id_str = vm_resp.get("session_id")
                if not isinstance(session_id_str, str) or not session_id_str:
                    session_id_str = await asyncio.to_thread(client.start_session)
                client.session_id = session_id_str
            else:
                session_id_str = await asyncio.to_thread(client.start_session)

            sdk_session_id = uuid.uuid4()
            snapshot_instance = resolve_snapshot(snapshot, str(sdk_session_id))

            state = InstaVMSandboxSessionState(
                session_id=sdk_session_id,
                manifest=manifest,
                snapshot=snapshot_instance,
                instavm_session_id=session_id_str,
                base_url=self._base_url,
                timeout=options.timeout,
                cpu_count=options.cpu_count,
                memory_mb=options.memory_mb,
                env=dict(options.env),
                metadata=dict(options.metadata),
                exposed_ports=options.exposed_ports,
                allow_internet_access=options.allow_internet_access,
                allow_http=options.allow_http,
                allow_https=options.allow_https,
                allow_package_managers=options.allow_package_managers,
                allowed_domains=options.allowed_domains,
                allowed_cidrs=options.allowed_cidrs,
            )

            inner = InstaVMSandboxSession.from_state(state, client=client, api_key=self._api_key)

            # Apply egress policy if any restrictions are configured.
            await inner._apply_egress_from_state()

            return self._wrap_session(inner, instrumentation=self._instrumentation)

        async def delete(self, session: SandboxSession) -> SandboxSession:
            inner = session._inner
            if not isinstance(inner, InstaVMSandboxSession):
                raise TypeError("InstaVMSandboxClient.delete expects an InstaVMSandboxSession")
            try:
                await inner.shutdown()
            except Exception:
                pass
            return session

        async def resume(self, state: SandboxSessionState) -> SandboxSession:
            """Resume a previously serialized session.

            InstaVM sessions are logical entities that wrap underlying VMs.  The
            resume flow first tries to reconnect to the existing session (which
            will succeed if the VM is still alive within its timeout window).
            If the session is gone or the VM has been recycled, a fresh session
            is created.  In the fresh-session case the SDK framework will handle
            workspace restoration from the saved snapshot via ``start()`` →
            ``hydrate_workspace()``.
            """
            if not isinstance(state, InstaVMSandboxSessionState):
                raise TypeError("InstaVMSandboxClient.resume expects an InstaVMSandboxSessionState")

            client = InstaVM(
                api_key=self._api_key,
                base_url=state.base_url,
                timeout=state.timeout,
                cpu_count=state.cpu_count,
                memory_mb=state.memory_mb,
                env=dict(state.env),
                metadata=dict(state.metadata),
                auto_start_session=False,
            )
            client.session_id = state.instavm_session_id

            reconnected = False
            try:
                status = await asyncio.to_thread(
                    client.get_session_status, state.instavm_session_id
                )
                if InstaVMSandboxSession._is_session_active(status):
                    reconnected = True
                else:
                    # Session exists but not running — start fresh.
                    new_sid = await asyncio.to_thread(client.start_session)
                    state.instavm_session_id = new_sid
                    client.session_id = new_sid
                    state.workspace_root_ready = False
            except Exception:
                # Session is gone — create a fresh one.
                new_sid = await asyncio.to_thread(client.start_session)
                state.instavm_session_id = new_sid
                client.session_id = new_sid
                state.workspace_root_ready = False

            inner = InstaVMSandboxSession.from_state(state, client=client, api_key=self._api_key)
            inner._set_start_state_preserved(reconnected, system=reconnected)

            # Re-apply egress policy on the (possibly new) session.
            await inner._apply_egress_from_state()

            return self._wrap_session(inner, instrumentation=self._instrumentation)

        def deserialize_session_state(self, payload: dict[str, object] | str) -> SandboxSessionState:
            if isinstance(payload, str):
                return InstaVMSandboxSessionState.model_validate_json(payload)
            return InstaVMSandboxSessionState.model_validate(payload)


__all__ = [
    "InstaVMSandboxClient",
    "InstaVMSandboxClientOptions",
    "InstaVMSandboxSession",
    "InstaVMSandboxSessionState",
]
