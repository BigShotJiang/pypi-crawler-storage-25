"""Mount strategies for InstaVM sandboxes.

Provides ``InstaVMCloudBucketMountStrategy``, a wrapper around the generic
:class:`InContainerMountStrategy` that ensures ``rclone`` and FUSE are
installed inside the VM before delegating to :class:`RcloneMountPattern`.

Compatible with :class:`S3Mount`, :class:`R2Mount`, :class:`GCSMount`,
and :class:`AzureBlobMount`.

Install with::

    pip install instavm[agents]

Usage::

    from instavm.integrations.mounts import InstaVMCloudBucketMountStrategy
    from agents.sandbox.entries import S3Mount
    from pathlib import Path

    mount = S3Mount(
        bucket="my-bucket",
        access_key_id="...",
        secret_access_key="...",
        mount_path=Path("/mnt/bucket"),
        mount_strategy=InstaVMCloudBucketMountStrategy(),
    )
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Literal

try:
    from agents.sandbox.entries.mounts.base import (
        InContainerMountStrategy,
        Mount,
        MountStrategyBase,
    )
    from agents.sandbox.entries.mounts.patterns import RcloneMountPattern
    from agents.sandbox.errors import MountConfigError
    from agents.sandbox.materialization import MaterializedFile

    _HAS_AGENTS = True
except ImportError:
    _HAS_AGENTS = False

if TYPE_CHECKING:
    from agents.sandbox.session.base_sandbox_session import BaseSandboxSession

logger = logging.getLogger(__name__)

_INSTALL_RETRIES = 3

if _HAS_AGENTS:

    # ---------------------------------------------------------------------------
    # Tool provisioning helpers
    # ---------------------------------------------------------------------------


    async def _has_command(session: BaseSandboxSession, cmd: str) -> bool:
        """Return True if *cmd* is on PATH or at a well-known location."""
        check = await session.exec(
            "sh",
            "-lc",
            f"command -v {cmd} >/dev/null 2>&1 || test -x /usr/local/bin/{cmd}",
            shell=False,
        )
        return check.ok()


    async def _pkg_install(
        session: BaseSandboxSession,
        package: str,
        *,
        what: str,
    ) -> None:
        """Install *package* via apt-get or apk with retries.

        Detects the available package manager (apt-get for Debian/Ubuntu, apk for
        Alpine) and installs the package.  Raises :class:`MountConfigError` with an
        actionable message if neither is available or all install attempts fail.
        """
        if await _has_command(session, "apt-get"):
            install_cmd = (
                "apt-get update -qq && "
                f"DEBIAN_FRONTEND=noninteractive apt-get install -y -qq {package}"
            )
        elif await _has_command(session, "apk"):
            install_cmd = f"apk add --no-cache {package}"
        else:
            raise MountConfigError(
                message=(
                    f"{what} is not installed and cannot be auto-installed "
                    f"(no supported package manager found). Preinstall {package} "
                    "in your InstaVM image."
                ),
                context={"package": package},
            )

        last_exit_code = -1
        for attempt in range(_INSTALL_RETRIES):
            result = await session.exec(
                "sh",
                "-lc",
                install_cmd,
                shell=False,
                timeout=180,
                user="root",
            )
            if result.ok():
                return
            last_exit_code = result.exit_code
            logger.warning(
                "%s install attempt %d/%d failed (exit %d)",
                package,
                attempt + 1,
                _INSTALL_RETRIES,
                result.exit_code,
            )

        raise MountConfigError(
            message=f"failed to install {package} after {_INSTALL_RETRIES} attempts",
            context={"package": package, "exit_code": last_exit_code},
        )


    # ---------------------------------------------------------------------------
    # Preflight checks
    # ---------------------------------------------------------------------------

    _FUSE_ALLOW_OTHER = (
        "chmod a+rw /dev/fuse && "
        "touch /etc/fuse.conf && "
        "(grep -qxF user_allow_other /etc/fuse.conf || "
        "printf '\\nuser_allow_other\\n' >> /etc/fuse.conf)"
    )


    async def _ensure_fuse_support(session: BaseSandboxSession) -> None:
        """Verify the sandbox has FUSE support, install fuse3 if needed."""
        dev_fuse = await session.exec("sh", "-lc", "test -c /dev/fuse", shell=False)
        if not dev_fuse.ok():
            raise MountConfigError(
                message="/dev/fuse not available in this InstaVM sandbox",
                context={"missing": "/dev/fuse"},
            )

        kmod = await session.exec(
            "sh",
            "-lc",
            "grep -qw fuse /proc/filesystems",
            shell=False,
        )
        if not kmod.ok():
            raise MountConfigError(
                message="FUSE kernel module not loaded in this InstaVM sandbox",
                context={"missing": "fuse in /proc/filesystems"},
            )

        # Userspace tooling — install if missing, re-verify after install.
        if await _has_command(session, "fusermount3") or await _has_command(
            session, "fusermount"
        ):
            pass
        else:
            logger.info("fusermount not found; installing fuse3")
            await _pkg_install(session, "fuse3", what="fusermount")

            if not (
                await _has_command(session, "fusermount3")
                or await _has_command(session, "fusermount")
            ):
                raise MountConfigError(
                    message="fuse3 was installed but fusermount is still not available",
                    context={"package": "fuse3"},
                )

        # Enable user_allow_other so non-root processes can access FUSE mounts.
        chmod_result = await session.exec(
            "sh",
            "-lc",
            _FUSE_ALLOW_OTHER,
            shell=False,
            timeout=30,
            user="root",
        )
        if not chmod_result.ok():
            raise MountConfigError(
                message="failed to make /dev/fuse accessible",
                context={"exit_code": chmod_result.exit_code},
            )


    async def _ensure_rclone(
        session: BaseSandboxSession,
        *,
        allow_curl_installer: bool = False,
    ) -> None:
        """Install rclone inside the sandbox if not already available.

        When *allow_curl_installer* is ``True``, a curl-pipe-bash fallback is
        tried after the package-manager path fails.  The default (``False``)
        raises an actionable error instead of running an unsigned remote script.
        """
        if await _has_command(session, "rclone"):
            return

        # Try package manager first.
        logger.info("rclone not found in sandbox; installing via package manager")
        try:
            await _pkg_install(session, "rclone", what="rclone")
        except MountConfigError:
            pass

        if await _has_command(session, "rclone"):
            return

        if not allow_curl_installer:
            raise MountConfigError(
                message=(
                    "rclone is not installed and could not be auto-installed via "
                    "the system package manager. Either preinstall rclone in your "
                    "InstaVM image, or set allow_curl_installer=True on "
                    "InstaVMCloudBucketMountStrategy to enable the curl-pipe-bash "
                    "fallback installer."
                ),
                context={"package": "rclone"},
            )

        # Explicit opt-in: curl-based installer fallback.
        logger.warning(
            "Package-manager rclone install failed; using curl-pipe-bash "
            "fallback (allow_curl_installer=True)"
        )
        result = await session.exec(
            "sh",
            "-lc",
            "curl -fsSL https://rclone.org/install.sh | bash",
            shell=False,
            timeout=300,
            user="root",
        )
        if not result.ok():
            raise MountConfigError(
                message="failed to install rclone via curl installer",
                context={"package": "rclone", "exit_code": result.exit_code},
            )

        if not await _has_command(session, "rclone"):
            raise MountConfigError(
                message="rclone is still not available after installation attempts",
                context={"package": "rclone"},
            )


    # ---------------------------------------------------------------------------
    # User ID helpers (for rclone FUSE --uid/--gid flags)
    # ---------------------------------------------------------------------------


    async def _default_user_ids(
        session: BaseSandboxSession,
    ) -> tuple[str, str] | None:
        """Return ``(uid, gid)`` for the default session user, or ``None``."""
        result = await session.exec("sh", "-lc", "id -u; id -g", shell=False, timeout=30)
        if not result.ok():
            return None

        lines = result.stdout.decode("utf-8", errors="replace").splitlines()
        if len(lines) < 2 or not lines[0].isdigit() or not lines[1].isdigit():
            return None
        return lines[0], lines[1]


    def _append_option(args: list[str], option: str, *values: str) -> None:
        """Append *option* (and optional *values*) to *args* if not already present."""
        if option not in args:
            args.extend([option, *values])


    async def _rclone_pattern_for_session(
        session: BaseSandboxSession,
        pattern: RcloneMountPattern,
    ) -> RcloneMountPattern:
        """Return *pattern* augmented with ``--allow-other``, ``--uid``, and ``--gid``."""
        if pattern.mode != "fuse":
            return pattern

        extra_args = list(pattern.extra_args)
        _append_option(extra_args, "--allow-other")
        user_ids = await _default_user_ids(session)
        if user_ids is not None:
            uid, gid = user_ids
            _append_option(extra_args, "--uid", uid)
            _append_option(extra_args, "--gid", gid)

        return pattern.model_copy(update={"extra_args": extra_args})


    # ---------------------------------------------------------------------------
    # Session guard
    # ---------------------------------------------------------------------------


    def _assert_instavm_session(session: BaseSandboxSession) -> None:
        """Raise if *session* is not an InstaVMSandboxSession."""
        if type(session).__name__ != "InstaVMSandboxSession":
            raise MountConfigError(
                message="InstaVM cloud bucket mounts require an InstaVMSandboxSession",
                context={"session_type": type(session).__name__},
            )


    # ---------------------------------------------------------------------------
    # Cloud bucket mount strategy
    # ---------------------------------------------------------------------------


    class InstaVMCloudBucketMountStrategy(MountStrategyBase):
        """Mount cloud buckets in InstaVM sandboxes via rclone+FUSE.

        Wraps :class:`InContainerMountStrategy` with automatic ``rclone`` and FUSE
        provisioning.  Use with any provider mount (:class:`S3Mount`,
        :class:`R2Mount`, :class:`GCSMount`, :class:`AzureBlobMount`) and let the
        generic framework handle config generation and mount execution.

        InstaVM VMs are full Linux virtual machines with FUSE support, so rclone
        FUSE mounts work out of the box after tool installation.

        Usage::

            from instavm.integrations.mounts import InstaVMCloudBucketMountStrategy
            from agents.sandbox.entries import S3Mount
            from pathlib import Path

            mount = S3Mount(
                bucket="my-bucket",
                access_key_id="...",
                secret_access_key="...",
                mount_path=Path("/mnt/bucket"),
                mount_strategy=InstaVMCloudBucketMountStrategy(),
            )
        """

        type: Literal["instavm_cloud_bucket"] = "instavm_cloud_bucket"
        pattern: RcloneMountPattern = RcloneMountPattern(mode="fuse")
        allow_curl_installer: bool = False

        def _delegate(self) -> InContainerMountStrategy:
            """Create a plain InContainerMountStrategy with the current pattern."""
            return InContainerMountStrategy(pattern=self.pattern)

        async def _delegate_for_session(
            self,
            session: BaseSandboxSession,
        ) -> InContainerMountStrategy:
            """Create an InContainerMountStrategy with session-aware rclone flags."""
            return InContainerMountStrategy(
                pattern=await _rclone_pattern_for_session(session, self.pattern),
            )

        def validate_mount(self, mount: Mount) -> None:
            self._delegate().validate_mount(mount)

        async def activate(
            self,
            mount: Mount,
            session: BaseSandboxSession,
            dest: Path,
            base_dir: Path,
        ) -> list[MaterializedFile]:
            _assert_instavm_session(session)
            if self.pattern.mode == "fuse":
                await _ensure_fuse_support(session)
            await _ensure_rclone(session, allow_curl_installer=self.allow_curl_installer)
            delegate = await self._delegate_for_session(session)
            return await delegate.activate(mount, session, dest, base_dir)

        async def deactivate(
            self,
            mount: Mount,
            session: BaseSandboxSession,
            dest: Path,
            base_dir: Path,
        ) -> None:
            _assert_instavm_session(session)
            await self._delegate().deactivate(mount, session, dest, base_dir)

        async def teardown_for_snapshot(
            self,
            mount: Mount,
            session: BaseSandboxSession,
            path: Path,
        ) -> None:
            _assert_instavm_session(session)
            await self._delegate().teardown_for_snapshot(mount, session, path)

        async def restore_after_snapshot(
            self,
            mount: Mount,
            session: BaseSandboxSession,
            path: Path,
        ) -> None:
            _assert_instavm_session(session)
            if self.pattern.mode == "fuse":
                await _ensure_fuse_support(session)
            await _ensure_rclone(session, allow_curl_installer=self.allow_curl_installer)
            delegate = await self._delegate_for_session(session)
            await delegate.restore_after_snapshot(mount, session, path)

        def build_docker_volume_driver_config(
            self,
            mount: Mount,
        ) -> tuple[str, dict[str, str], bool] | None:
            return None

else:

    def __getattr__(name: str) -> object:  # type: ignore[misc]
        _public = {"InstaVMCloudBucketMountStrategy"}
        if name in _public:
            raise ImportError(
                f"instavm.integrations.mounts requires the agents extra. "
                f"Install it with: pip install instavm[agents]"
            )
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "InstaVMCloudBucketMountStrategy",
]
