"""
Unit tests for the InstaVM OpenAI Agents SDK sandbox integration.

These tests mock the InstaVM SDK client and validate that all 4 integration
classes behave correctly without making any real API calls.

Run:
    python -m pytest tests/test_openai_agents_integration.py -v
"""

from __future__ import annotations

import asyncio
import base64
import io
import json
import uuid
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from agents.sandbox.manifest import Manifest
from agents.sandbox.session.sandbox_client import BaseSandboxClientOptions
from agents.sandbox.session.sandbox_session_state import SandboxSessionState
from agents.sandbox.snapshot import resolve_snapshot

from instavm.integrations.openai_agents import (
    DEFAULT_INSTAVM_WORKSPACE_ROOT,
    InstaVMSandboxClient,
    InstaVMSandboxClientOptions,
    InstaVMSandboxSession,
    InstaVMSandboxSessionState,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_state(**overrides) -> InstaVMSandboxSessionState:
    sid = uuid.uuid4()
    defaults = dict(
        session_id=sid,
        manifest=Manifest(root=DEFAULT_INSTAVM_WORKSPACE_ROOT),
        snapshot=resolve_snapshot(None, str(sid)),
        instavm_session_id="ivm-sess-1234",
        base_url="https://api.instavm.io",
    )
    defaults.update(overrides)
    return InstaVMSandboxSessionState(**defaults)


def _make_instavm_mock(
    *,
    execute_return=None,
    session_id="ivm-sess-1234",
    start_session_return="ivm-new-sess",
    status_return=None,
) -> MagicMock:
    """Create a mocked InstaVM client."""
    mock = MagicMock()
    mock.session_id = session_id
    mock.start_session.return_value = start_session_return
    mock.execute.return_value = execute_return or {"stdout": "", "stderr": ""}
    mock.get_session_status.return_value = status_return or {
        "exists": True, "vm_assigned": True, "vm_alive": True,
    }
    mock.kill.return_value = None
    mock.get_session_app_url.return_value = {"app_url": "https://vm-1234.instavm.dev:443"}
    mock.download_file.return_value = {"content": b"", "status": "success"}
    mock.upload_file.return_value = {"status": "success"}
    # shares sub-manager mock (used by _resolve_exposed_port).
    mock.shares = MagicMock()
    mock.shares.create.return_value = {"share_id": "test-share", "url": "https://test-share.instavm.site/"}
    return mock


# ---------------------------------------------------------------------------
# Auto-registration
# ---------------------------------------------------------------------------


class TestAutoRegistration:
    def test_client_options_registered(self):
        assert "instavm" in BaseSandboxClientOptions._subclass_registry
        assert BaseSandboxClientOptions._subclass_registry["instavm"] is InstaVMSandboxClientOptions

    def test_session_state_registered(self):
        assert "instavm" in SandboxSessionState._subclass_registry
        assert SandboxSessionState._subclass_registry["instavm"] is InstaVMSandboxSessionState


# ---------------------------------------------------------------------------
# InstaVMSandboxClientOptions
# ---------------------------------------------------------------------------


class TestClientOptions:
    def test_defaults(self):
        opts = InstaVMSandboxClientOptions()
        assert opts.type == "instavm"
        assert opts.memory_mb is None
        assert opts.cpu_count is None
        assert opts.timeout == 300
        assert opts.env == {}
        assert opts.metadata == {}
        assert opts.snapshot_id is None
        assert opts.exposed_ports == ()

    def test_custom_values(self):
        opts = InstaVMSandboxClientOptions(
            memory_mb=4096,
            cpu_count=4,
            timeout=600,
            env={"APP": "test"},
            metadata={"team": "platform"},
            snapshot_id="snap-abc",
            exposed_ports=(8080, 3000),
        )
        assert opts.memory_mb == 4096
        assert opts.cpu_count == 4
        assert opts.timeout == 600
        assert opts.env == {"APP": "test"}
        assert opts.metadata == {"team": "platform"}
        assert opts.snapshot_id == "snap-abc"
        assert opts.exposed_ports == (8080, 3000)

    def test_frozen(self):
        opts = InstaVMSandboxClientOptions()
        with pytest.raises(Exception):
            opts.memory_mb = 1024


# ---------------------------------------------------------------------------
# InstaVMSandboxSessionState
# ---------------------------------------------------------------------------


class TestSessionState:
    def test_defaults(self):
        state = _make_state()
        assert state.type == "instavm"
        assert state.instavm_session_id == "ivm-sess-1234"
        assert state.base_url == "https://api.instavm.io"
        assert state.timeout == 300
        # api_key should NOT be in serialized state.
        assert not hasattr(state, "api_key")

    def test_serialization_roundtrip(self):
        state = _make_state(
            cpu_count=4,
            memory_mb=2048,
            env={"FOO": "bar"},
        )
        payload = state.model_dump()
        assert payload["type"] == "instavm"
        assert payload["instavm_session_id"] == "ivm-sess-1234"
        assert payload["cpu_count"] == 4

        restored = InstaVMSandboxSessionState.model_validate(payload)
        assert restored.instavm_session_id == state.instavm_session_id
        assert restored.cpu_count == state.cpu_count
        assert restored.env == state.env

    def test_deserialization_via_base_class(self):
        """The auto-registry should let the base class deserialize our type."""
        state = _make_state()
        payload = state.model_dump()
        # The base class registry should recognize type="instavm".
        cls = SandboxSessionState._subclass_registry.get("instavm")
        assert cls is not None
        restored = cls.model_validate(payload)
        assert isinstance(restored, InstaVMSandboxSessionState)


# ---------------------------------------------------------------------------
# InstaVMSandboxSession
# ---------------------------------------------------------------------------


class TestSandboxSession:
    @pytest.fixture
    def session(self):
        state = _make_state()
        mock_client = _make_instavm_mock()
        sess = InstaVMSandboxSession(state=state, client=mock_client, api_key="test-key")
        # Pre-set to sentinel mode so existing tests don't trigger the probe.
        sess._api_has_exit_code = False
        return sess, mock_client

    @pytest.mark.asyncio
    async def test_exec_internal(self, session):
        sess, mock = session
        mock.execute.return_value = {
            "stdout": "hello\n\n__INSTAVM_EC__0\n",
            "stderr": "",
        }

        result = await sess._exec_internal("echo", "hello")
        assert result.ok()
        assert result.stdout == b"hello\n"
        assert result.exit_code == 0
        mock.execute.assert_called_once()

    @pytest.mark.asyncio
    async def test_exec_internal_nonzero(self, session):
        sess, mock = session
        mock.execute.return_value = {
            "stdout": "\n__INSTAVM_EC__127\n",
            "stderr": "not found",
        }

        result = await sess._exec_internal("nonexistent_cmd")
        assert not result.ok()
        assert result.exit_code == 127
        assert b"not found" in result.stderr

    @pytest.mark.asyncio
    async def test_exec_exit_code_from_stderr_fallback(self, session):
        """When the sentinel isn't in stdout, parse exit code from CalledProcessError."""
        sess, mock = session
        mock.execute.return_value = {
            "stdout": "",
            "stderr": "CalledProcessError: Command returned non-zero exit status 42.",
        }

        result = await sess._exec_internal("exit", "42")
        assert result.exit_code == 42
        assert not result.ok()

    @pytest.mark.asyncio
    async def test_exec_timeout(self, session):
        sess, mock = session

        async def slow(*a, **kw):
            await asyncio.sleep(10)

        with patch("instavm.integrations.openai_agents.asyncio.to_thread", side_effect=slow):
            from agents.sandbox.errors import ExecTimeoutError
            with pytest.raises(ExecTimeoutError):
                await sess._exec_internal("sleep", "100", timeout=0.1)

    @pytest.mark.asyncio
    async def test_exec_transport_error(self, session):
        sess, mock = session
        mock.execute.side_effect = ConnectionError("connection refused")

        from agents.sandbox.errors import ExecTransportError
        with pytest.raises(ExecTransportError):
            await sess._exec_internal("echo", "hello")

    @pytest.mark.asyncio
    async def test_read_file(self, session):
        sess, mock = session
        content = b"file contents here"
        encoded = base64.b64encode(content).decode("ascii")
        # First call: containment check (realpath); second call: actual read.
        containment_ok = {"stdout": "ok\n\n__INSTAVM_EC__0\n", "stderr": ""}
        read_result = {"stdout": f"{encoded}\n\n__INSTAVM_EC__0\n", "stderr": ""}
        mock.execute.side_effect = [containment_ok, read_result]

        result = await sess.read(Path("test.txt"))
        assert isinstance(result, io.IOBase)
        assert result.read() == content

    @pytest.mark.asyncio
    async def test_read_file_not_found(self, session):
        sess, mock = session
        # Containment check succeeds, read fails.
        containment_ok = {"stdout": "ok\n\n__INSTAVM_EC__0\n", "stderr": ""}
        read_fail = {"stdout": "\n__INSTAVM_EC__1\n", "stderr": "No such file"}
        mock.execute.side_effect = [containment_ok, read_fail]

        from agents.sandbox.errors import WorkspaceReadNotFoundError
        with pytest.raises(WorkspaceReadNotFoundError):
            await sess.read(Path("missing.txt"))

    @pytest.mark.asyncio
    async def test_write_file(self, session):
        sess, mock = session
        mock.execute.return_value = {"stdout": "\n__INSTAVM_EC__0\n", "stderr": ""}

        data = io.BytesIO(b"hello world")
        await sess.write(Path("output.txt"), data)

        # Should have called execute three times — mkdir, containment check, then write.
        assert mock.execute.call_count == 3

    @pytest.mark.asyncio
    async def test_write_file_str_data(self, session):
        sess, mock = session
        mock.execute.return_value = {"stdout": "\n__INSTAVM_EC__0\n", "stderr": ""}

        data = io.StringIO("text content")
        await sess.write(Path("output.txt"), data)
        assert mock.execute.call_count == 3

    @pytest.mark.asyncio
    async def test_read_rejects_user_arg(self, session):
        sess, mock = session
        from agents.sandbox.errors import ConfigurationError
        with pytest.raises(ConfigurationError, match="does not support sandbox-local users"):
            await sess.read(Path("test.txt"), user="someuser")

    @pytest.mark.asyncio
    async def test_write_rejects_user_arg(self, session):
        sess, mock = session
        from agents.sandbox.errors import ConfigurationError
        with pytest.raises(ConfigurationError, match="does not support sandbox-local users"):
            await sess.write(Path("test.txt"), io.BytesIO(b"data"), user="someuser")

    @pytest.mark.asyncio
    async def test_read_symlink_escape_blocked(self, session):
        sess, mock = session
        # Containment check exits 111 (symlink escape detected).
        mock.execute.return_value = {"stdout": "\n__INSTAVM_EC__111\n", "stderr": ""}

        from agents.sandbox.errors import InvalidManifestPathError
        with pytest.raises(InvalidManifestPathError):
            await sess.read(Path("link_to_etc"))

    @pytest.mark.asyncio
    async def test_write_symlink_escape_blocked(self, session):
        sess, mock = session
        # mkdir succeeds but containment check detects escape.
        mkdir_ok = {"stdout": "\n__INSTAVM_EC__0\n", "stderr": ""}
        escape_detected = {"stdout": "\n__INSTAVM_EC__111\n", "stderr": ""}
        mock.execute.side_effect = [mkdir_ok, escape_detected]

        from agents.sandbox.errors import InvalidManifestPathError
        with pytest.raises(InvalidManifestPathError):
            await sess.write(Path("link_to_etc/passwd"), io.BytesIO(b"pwned"))

    @pytest.mark.asyncio
    async def test_running_true(self, session):
        sess, mock = session
        mock.get_session_status.return_value = {
            "exists": True, "vm_assigned": True, "vm_alive": True,
        }

        assert await sess.running() is True

    @pytest.mark.asyncio
    async def test_running_false_on_stopped(self, session):
        sess, mock = session
        mock.get_session_status.return_value = {
            "exists": True, "vm_assigned": True, "vm_alive": False,
        }

        assert await sess.running() is False

    @pytest.mark.asyncio
    async def test_running_false_on_error(self, session):
        sess, mock = session
        mock.get_session_status.side_effect = ConnectionError("gone")

        assert await sess.running() is False

    @pytest.mark.asyncio
    async def test_persist_workspace(self, session):
        sess, mock = session
        tar_bytes = b"fake-tar-archive"
        encoded = base64.b64encode(tar_bytes).decode("ascii")
        mock.execute.return_value = {
            "stdout": f"{encoded}\n\n__INSTAVM_EC__0\n",
            "stderr": "",
        }

        result = await sess.persist_workspace()
        assert isinstance(result, io.IOBase)
        assert result.read() == tar_bytes

    @pytest.mark.asyncio
    async def test_hydrate_workspace(self, session):
        sess, mock = session
        mock.execute.return_value = {"stdout": "\n__INSTAVM_EC__0\n", "stderr": ""}

        tar_data = io.BytesIO(b"fake-tar")
        await sess.hydrate_workspace(tar_data)

        # Should have multiple exec calls: rm, chunk write, mkdir, extract, cleanup.
        assert mock.execute.call_count >= 4

    @pytest.mark.asyncio
    async def test_ensure_backend_started_reconnect(self, session):
        sess, mock = session
        mock.get_session_status.return_value = {
            "exists": True, "vm_assigned": True, "vm_alive": True,
        }

        await sess._ensure_backend_started()
        mock.start_session.assert_not_called()

    @pytest.mark.asyncio
    async def test_ensure_backend_started_new_session(self, session):
        sess, mock = session
        mock.get_session_status.side_effect = Exception("gone")
        mock.start_session.return_value = "ivm-new-sess"

        await sess._ensure_backend_started()
        mock.start_session.assert_called_once()
        assert sess.state.instavm_session_id == "ivm-new-sess"

    @pytest.mark.asyncio
    async def test_shutdown(self, session):
        sess, mock = session
        await sess.shutdown()
        mock.kill.assert_called_once_with("ivm-sess-1234")
        assert sess._client is None

    @pytest.mark.asyncio
    async def test_shutdown_tolerates_failure(self, session):
        sess, mock = session
        mock.kill.side_effect = Exception("already dead")

        # Should not raise.
        await sess.shutdown()
        assert sess._client is None

    def test_from_state(self):
        state = _make_state()
        sess = InstaVMSandboxSession.from_state(state)
        assert sess.state is state
        assert sess._client is None

    def test_normalize_path_relative(self):
        state = _make_state()
        sess = InstaVMSandboxSession(state=state, client=_make_instavm_mock())
        result = sess.normalize_path(Path("src/main.py"))
        assert str(result) == "/workspace/src/main.py"

    def test_normalize_path_escape_rejected(self):
        state = _make_state()
        sess = InstaVMSandboxSession(state=state, client=_make_instavm_mock())
        from agents.sandbox.errors import InvalidManifestPathError
        with pytest.raises(InvalidManifestPathError):
            sess.normalize_path(Path("../../etc/passwd"))


# ---------------------------------------------------------------------------
# Exit code auto-detection
# ---------------------------------------------------------------------------


class TestExitCodeAutoDetect:
    """Tests for the native exit_code probe / sentinel fallback logic."""

    @pytest.mark.asyncio
    async def test_probe_detects_native_exit_code(self):
        """When the API returns exit_code on the no-op probe, use native path."""
        mock = _make_instavm_mock()
        # First call: no-op probe returns exit_code.
        # Second call: the actual user command via native path.
        mock.execute.side_effect = [
            {"stdout": "", "stderr": "", "exit_code": 0},   # probe with 'true'
            {"stdout": "hello\n", "stderr": "", "exit_code": 0},  # user command
        ]
        state = _make_state()
        sess = InstaVMSandboxSession(state=state, client=mock, api_key="test")
        assert sess._api_has_exit_code is None

        result = await sess._exec_internal("echo", "hello")

        assert sess._api_has_exit_code is True
        assert result.exit_code == 0
        assert result.stdout == b"hello\n"
        # Two calls: probe + user command.
        assert mock.execute.call_count == 2

    @pytest.mark.asyncio
    async def test_probe_detects_native_nonzero(self):
        mock = _make_instavm_mock()
        # Probe succeeds with exit_code; user command fails.
        mock.execute.side_effect = [
            {"stdout": "", "stderr": "", "exit_code": 0},           # probe
            {"stdout": "", "stderr": "not found", "exit_code": 127},  # user cmd
        ]
        state = _make_state()
        sess = InstaVMSandboxSession(state=state, client=mock, api_key="test")

        result = await sess._exec_internal("nonexistent")

        assert sess._api_has_exit_code is True
        assert result.exit_code == 127
        assert not result.ok()

    @pytest.mark.asyncio
    async def test_probe_falls_back_to_sentinel(self):
        """When probe returns no exit_code, fall back to sentinel for the user command."""
        mock = _make_instavm_mock()
        # Probe: old API, no exit_code.
        # User command: sentinel-wrapped result.
        mock.execute.side_effect = [
            {"stdout": "", "stderr": ""},                          # probe
            {"stdout": "hello\n\n__INSTAVM_EC__0\n", "stderr": ""},  # sentinel
        ]
        state = _make_state()
        sess = InstaVMSandboxSession(state=state, client=mock, api_key="test")

        result = await sess._exec_internal("echo", "hello")

        assert sess._api_has_exit_code is False
        assert result.exit_code == 0
        assert result.stdout == b"hello\n"
        # Two calls: probe + sentinel-wrapped user command.
        assert mock.execute.call_count == 2

    @pytest.mark.asyncio
    async def test_subsequent_calls_skip_probe_native(self):
        """Once native is detected, subsequent calls go straight to native path."""
        mock = _make_instavm_mock()
        mock.execute.side_effect = [
            {"stdout": "", "stderr": "", "exit_code": 0},       # probe
            {"stdout": "ok\n", "stderr": "", "exit_code": 0},   # call 1
            {"stdout": "ok\n", "stderr": "", "exit_code": 0},   # call 2
            {"stdout": "ok\n", "stderr": "", "exit_code": 0},   # call 3
        ]
        state = _make_state()
        sess = InstaVMSandboxSession(state=state, client=mock, api_key="test")

        await sess._exec_internal("echo", "1")
        await sess._exec_internal("echo", "2")
        await sess._exec_internal("echo", "3")

        # 4 calls total: 1 probe + 3 user commands.
        assert mock.execute.call_count == 4

    @pytest.mark.asyncio
    async def test_subsequent_calls_skip_probe_sentinel(self):
        """Once sentinel is detected, subsequent calls go straight to sentinel path."""
        mock = _make_instavm_mock()
        mock.execute.side_effect = [
            {"stdout": "", "stderr": ""},                         # probe (no exit_code)
            {"stdout": "\n__INSTAVM_EC__0\n", "stderr": ""},     # call 1 sentinel
            {"stdout": "a\n\n__INSTAVM_EC__0\n", "stderr": ""},  # call 2 sentinel
            {"stdout": "b\n\n__INSTAVM_EC__0\n", "stderr": ""},  # call 3 sentinel
        ]
        state = _make_state()
        sess = InstaVMSandboxSession(state=state, client=mock, api_key="test")

        await sess._exec_internal("echo", "1")
        assert sess._api_has_exit_code is False
        await sess._exec_internal("echo", "2")
        await sess._exec_internal("echo", "3")

        # 4 calls: 1 probe + 3 sentinel.
        assert mock.execute.call_count == 4

    @pytest.mark.asyncio
    async def test_native_exit_code_none_triggers_fallback(self):
        """If probe returns exit_code=None, treat as old API."""
        mock = _make_instavm_mock()
        mock.execute.side_effect = [
            {"stdout": "", "stderr": "", "exit_code": None},     # probe
            {"stdout": "\n__INSTAVM_EC__0\n", "stderr": ""},     # sentinel
        ]
        state = _make_state()
        sess = InstaVMSandboxSession(state=state, client=mock, api_key="test")

        result = await sess._exec_internal("true")
        assert sess._api_has_exit_code is False
        assert result.exit_code == 0


# ---------------------------------------------------------------------------
# InstaVMSandboxClient
# ---------------------------------------------------------------------------


class TestSandboxClient:
    @pytest.fixture
    def client(self):
        return InstaVMSandboxClient(api_key="test-key")

    def test_backend_id(self, client):
        assert client.backend_id == "instavm"

    def test_api_key_from_env(self):
        with patch.dict("os.environ", {"INSTAVM_API_KEY": "env-key"}):
            c = InstaVMSandboxClient()
            assert c._api_key == "env-key"

    @pytest.mark.asyncio
    async def test_create(self, client):
        opts = InstaVMSandboxClientOptions(memory_mb=2048, cpu_count=2)

        with patch("instavm.integrations.openai_agents.InstaVM") as MockInstaVM:
            mock_ivm = _make_instavm_mock()
            MockInstaVM.return_value = mock_ivm

            session = await client.create(options=opts)
            mock_ivm.start_session.assert_called_once()
            assert session is not None

    @pytest.mark.asyncio
    async def test_create_sets_default_workspace_root(self, client):
        opts = InstaVMSandboxClientOptions()

        with patch("instavm.integrations.openai_agents.InstaVM") as MockInstaVM:
            mock_ivm = _make_instavm_mock()
            MockInstaVM.return_value = mock_ivm

            session = await client.create(options=opts)
            inner = session._inner
            assert isinstance(inner, InstaVMSandboxSession)
            assert inner.state.manifest.root == DEFAULT_INSTAVM_WORKSPACE_ROOT

    @pytest.mark.asyncio
    async def test_delete(self, client):
        state = _make_state()
        mock_ivm = _make_instavm_mock()
        inner = InstaVMSandboxSession(state=state, client=mock_ivm, api_key="test-key")
        from agents.sandbox.session.manager import Instrumentation
        session = client._wrap_session(inner, instrumentation=Instrumentation())

        result = await client.delete(session)
        mock_ivm.kill.assert_called_once()
        assert result is session

    @pytest.mark.asyncio
    async def test_resume_reconnect(self, client):
        state = _make_state()

        with patch("instavm.integrations.openai_agents.InstaVM") as MockInstaVM:
            mock_ivm = _make_instavm_mock()
            mock_ivm.get_session_status.return_value = {
                "exists": True, "vm_assigned": True, "vm_alive": True,
            }
            MockInstaVM.return_value = mock_ivm

            session = await client.resume(state)
            assert session is not None
            mock_ivm.start_session.assert_not_called()

    @pytest.mark.asyncio
    async def test_resume_creates_new_session_on_failure(self, client):
        state = _make_state()

        with patch("instavm.integrations.openai_agents.InstaVM") as MockInstaVM:
            mock_ivm = _make_instavm_mock()
            mock_ivm.get_session_status.side_effect = Exception("gone")
            mock_ivm.start_session.return_value = "ivm-fresh"
            MockInstaVM.return_value = mock_ivm

            session = await client.resume(state)
            assert session is not None
            mock_ivm.start_session.assert_called_once()
            assert state.instavm_session_id == "ivm-fresh"
            assert state.workspace_root_ready is False

    def test_deserialize_session_state(self, client):
        state = _make_state()
        payload = state.model_dump()
        # Ensure non-serializable types are converted.
        payload["session_id"] = str(payload["session_id"])

        result = client.deserialize_session_state(payload)
        assert isinstance(result, InstaVMSandboxSessionState)
        assert result.instavm_session_id == "ivm-sess-1234"

    @pytest.mark.asyncio
    async def test_create_requires_options(self, client):
        with pytest.raises(ValueError, match="requires options"):
            await client.create(options=None)


# ---------------------------------------------------------------------------
# Snapshot encode / decode helpers
# ---------------------------------------------------------------------------


class TestSnapshotRefCodec:
    def test_encode_produces_magic_prefix(self):
        from instavm.integrations.openai_agents import (
            _INSTAVM_SNAPSHOT_MAGIC,
            _encode_instavm_snapshot_ref,
        )

        data = _encode_instavm_snapshot_ref(snapshot_id="snap-abc-123")
        assert data.startswith(_INSTAVM_SNAPSHOT_MAGIC)

    def test_roundtrip(self):
        from instavm.integrations.openai_agents import (
            _decode_instavm_snapshot_ref,
            _encode_instavm_snapshot_ref,
        )

        snap_id = "snap-abc-123"
        encoded = _encode_instavm_snapshot_ref(snapshot_id=snap_id)
        decoded = _decode_instavm_snapshot_ref(encoded)
        assert decoded == snap_id

    def test_decode_returns_none_for_arbitrary_bytes(self):
        from instavm.integrations.openai_agents import _decode_instavm_snapshot_ref

        assert _decode_instavm_snapshot_ref(b"random tar data") is None

    def test_decode_returns_none_for_bad_json(self):
        from instavm.integrations.openai_agents import (
            _INSTAVM_SNAPSHOT_MAGIC,
            _decode_instavm_snapshot_ref,
        )

        bad = _INSTAVM_SNAPSHOT_MAGIC + b"not json"
        assert _decode_instavm_snapshot_ref(bad) is None

    def test_decode_returns_none_for_missing_snapshot_id(self):
        from instavm.integrations.openai_agents import (
            _INSTAVM_SNAPSHOT_MAGIC,
            _decode_instavm_snapshot_ref,
        )

        body = json.dumps({"other": "stuff"}).encode()
        assert _decode_instavm_snapshot_ref(_INSTAVM_SNAPSHOT_MAGIC + body) is None


# ---------------------------------------------------------------------------
# Native snapshot persist / hydrate
# ---------------------------------------------------------------------------


class TestNativeSnapshots:
    @pytest.fixture
    def session_with_snapshot(self):
        """Session whose InstaVM client supports vms.snapshot()."""
        state = _make_state()
        mock = _make_instavm_mock()
        # get_session_status returns a vm_id so persist can snapshot.
        mock.get_session_status.return_value = {
            "exists": True, "vm_assigned": True, "vm_alive": True,
            "vm_id": "vm-abcdef",
        }
        mock.vms = MagicMock()
        mock.vms.snapshot.return_value = {"id": "snap-12345", "status": "ready"}
        mock.vms.create.return_value = {"vm_id": "vm-new", "session_id": "sess-new"}
        sess = InstaVMSandboxSession(state=state, client=mock, api_key="k")
        return sess, mock

    @pytest.mark.asyncio
    async def test_persist_workspace_native_snapshot(self, session_with_snapshot):
        sess, mock = session_with_snapshot
        result = await sess.persist_workspace()
        data = result.read()
        mock.vms.snapshot.assert_called_once()

        from instavm.integrations.openai_agents import _decode_instavm_snapshot_ref
        assert _decode_instavm_snapshot_ref(data) == "snap-12345"

    @pytest.mark.asyncio
    async def test_persist_workspace_falls_back_to_tar(self):
        """When the VM has no vm_id, fall back to tar-based persistence."""
        state = _make_state()
        mock = _make_instavm_mock()
        mock.get_session_status.return_value = {
            "exists": True, "vm_assigned": True, "vm_alive": True,
        }
        tar_data = base64.b64encode(b"fake-tar-data").decode()
        mock.execute.return_value = {
            "stdout": f"__INSTAVM_EC__0\n{tar_data}\n__INSTAVM_EC__0",
            "stderr": "",
        }
        sess = InstaVMSandboxSession(state=state, client=mock, api_key="k")

        result = await sess.persist_workspace()
        data = result.read()
        # Should be raw tar data, not a snapshot reference.
        from instavm.integrations.openai_agents import _decode_instavm_snapshot_ref
        assert _decode_instavm_snapshot_ref(data) is None

    @pytest.mark.asyncio
    async def test_hydrate_from_native_snapshot(self, session_with_snapshot):
        sess, mock = session_with_snapshot
        from instavm.integrations.openai_agents import _encode_instavm_snapshot_ref

        payload = _encode_instavm_snapshot_ref(snapshot_id="snap-12345")
        await sess.hydrate_workspace(io.BytesIO(payload))

        mock.vms.create.assert_called_once()
        # Session ID should be updated to the one from the new VM.
        assert sess.state.instavm_session_id == "sess-new"

    @pytest.mark.asyncio
    async def test_hydrate_from_tar(self):
        """Non-snapshot bytes are extracted as a tar archive."""
        state = _make_state()
        mock = _make_instavm_mock()
        mock.execute.return_value = {
            "stdout": "__INSTAVM_EC__0",
            "stderr": "",
        }
        sess = InstaVMSandboxSession(state=state, client=mock, api_key="k")

        await sess.hydrate_workspace(io.BytesIO(b"fake-tar"))
        # At minimum, mkdir and tar extract commands should have been called.
        assert mock.execute.call_count >= 2

    @pytest.mark.asyncio
    async def test_hydrate_native_snapshot_kills_old_session(self, session_with_snapshot):
        sess, mock = session_with_snapshot
        from instavm.integrations.openai_agents import _encode_instavm_snapshot_ref

        old_sid = sess.state.instavm_session_id
        payload = _encode_instavm_snapshot_ref(snapshot_id="snap-12345")
        await sess.hydrate_workspace(io.BytesIO(payload))
        mock.kill.assert_called_once_with(old_sid)


# ---------------------------------------------------------------------------
# Exposed port resolution
# ---------------------------------------------------------------------------


class TestExposedPorts:
    @pytest.mark.asyncio
    async def test_resolve_exposed_port(self):
        state = _make_state()
        mock = _make_instavm_mock()
        mock.shares.create.return_value = {
            "share_id": "abc-share",
            "url": "https://abc-share.instavm.site/",
        }
        sess = InstaVMSandboxSession(state=state, client=mock, api_key="k")

        endpoint = await sess._resolve_exposed_port(8080)
        assert endpoint.host == "abc-share.instavm.site"
        assert endpoint.tls is True

    @pytest.mark.asyncio
    async def test_resolve_exposed_port_fallback_to_app_url(self):
        """When shares.create returns no URL, fall back to get_session_app_url."""
        state = _make_state()
        mock = _make_instavm_mock()
        mock.shares.create.return_value = {"share_id": "x", "url": ""}
        mock.get_session_app_url.return_value = {
            "direct_url": "https://vm-5678-8080.sandbox.instavm.io/",
            "url": "https://api.instavm.io/v1/app/sid/8080/",
        }
        sess = InstaVMSandboxSession(state=state, client=mock, api_key="k")

        endpoint = await sess._resolve_exposed_port(8080)
        assert endpoint.host == "vm-5678-8080.sandbox.instavm.io"
        assert endpoint.tls is True

    @pytest.mark.asyncio
    async def test_resolve_exposed_port_raises_on_empty_url(self):
        state = _make_state()
        mock = _make_instavm_mock()
        mock.shares.create.side_effect = Exception("share creation failed")
        mock.get_session_app_url.return_value = {"url": "", "direct_url": ""}
        sess = InstaVMSandboxSession(state=state, client=mock, api_key="k")

        from agents.sandbox.errors import ExposedPortUnavailableError
        with pytest.raises(ExposedPortUnavailableError):
            await sess._resolve_exposed_port(3000)


# ---------------------------------------------------------------------------
# Snapshot-on-terminate support
# ---------------------------------------------------------------------------


class TestSnapshotOnTerminate:
    @pytest.mark.asyncio
    async def test_create_with_snapshot_on_terminate(self):
        """snapshot_on_terminate is passed through to vms.create."""
        client = InstaVMSandboxClient(api_key="test-key")
        opts = InstaVMSandboxClientOptions(
            snapshot_on_terminate=True,
            snapshot_name="my-checkpoint",
        )

        with patch("instavm.integrations.openai_agents.InstaVM") as MockInstaVM:
            mock_ivm = _make_instavm_mock()
            mock_ivm.vms = MagicMock()
            mock_ivm.vms.create.return_value = {
                "vm_id": "vm-1", "session_id": "sess-1", "status": "active",
            }
            MockInstaVM.return_value = mock_ivm

            session = await client.create(options=opts)
            mock_ivm.vms.create.assert_called_once()
            call_kwargs = mock_ivm.vms.create.call_args
            # snapshot_on_terminate should be in the kwargs.
            assert call_kwargs[1].get("snapshot_on_terminate") is True
            assert call_kwargs[1].get("snapshot_name") == "my-checkpoint"

    @pytest.mark.asyncio
    async def test_create_with_snapshot_id(self):
        """Creating from an existing snapshot uses vms.create with snapshot_id."""
        client = InstaVMSandboxClient(api_key="test-key")
        opts = InstaVMSandboxClientOptions(snapshot_id="snap-existing")

        with patch("instavm.integrations.openai_agents.InstaVM") as MockInstaVM:
            mock_ivm = _make_instavm_mock()
            mock_ivm.vms = MagicMock()
            mock_ivm.vms.create.return_value = {
                "vm_id": "vm-2", "session_id": "sess-2", "status": "active",
            }
            MockInstaVM.return_value = mock_ivm

            session = await client.create(options=opts)
            mock_ivm.vms.create.assert_called_once()
            call_kwargs = mock_ivm.vms.create.call_args
            assert call_kwargs[1].get("snapshot_id") == "snap-existing"
            # start_session should NOT be called because vms.create returns session_id.
            mock_ivm.start_session.assert_not_called()

    def test_snapshot_on_terminate_defaults_false(self):
        opts = InstaVMSandboxClientOptions()
        assert opts.snapshot_on_terminate is False
        assert opts.snapshot_name is None


# ---------------------------------------------------------------------------
# SDK conformance: roundtrip, discriminator, type registration
# ---------------------------------------------------------------------------


class TestSDKConformance:
    """Tests modeled after openai-agents-python/tests/sandbox/ conformance
    patterns to verify InstaVM types integrate with the Pydantic discriminator
    registry correctly.
    """

    def test_options_parse_via_base_class(self):
        """BaseSandboxClientOptions.parse({'type': 'instavm', ...}) works."""
        raw = {"type": "instavm", "memory_mb": 4096}
        parsed = BaseSandboxClientOptions.parse(raw)
        assert isinstance(parsed, InstaVMSandboxClientOptions)
        assert parsed.memory_mb == 4096

    def test_options_json_roundtrip(self):
        opts = InstaVMSandboxClientOptions(
            memory_mb=2048, cpu_count=4, timeout=600,
            snapshot_on_terminate=True, snapshot_name="chk",
        )
        raw_json = opts.model_dump_json()
        restored = InstaVMSandboxClientOptions.model_validate_json(raw_json)
        assert restored.memory_mb == 2048
        assert restored.cpu_count == 4
        assert restored.snapshot_on_terminate is True
        assert restored.snapshot_name == "chk"

    def test_session_state_json_roundtrip(self):
        state = _make_state(instavm_session_id="sess-rt")
        raw_json = state.model_dump_json()
        restored = InstaVMSandboxSessionState.model_validate_json(raw_json)
        assert restored.instavm_session_id == "sess-rt"
        assert restored.type == "instavm"

    def test_session_state_roundtrip_via_base_class(self):
        """Deserialize through SandboxSessionState.parse() (uses type discriminator)."""
        state = _make_state(instavm_session_id="sess-disc")
        payload = json.loads(state.model_dump_json())
        restored = SandboxSessionState.parse(payload)
        assert isinstance(restored, InstaVMSandboxSessionState)
        assert restored.instavm_session_id == "sess-disc"

    def test_options_frozen(self):
        opts = InstaVMSandboxClientOptions(memory_mb=1024)
        with pytest.raises(Exception):
            opts.memory_mb = 2048

    def test_state_api_key_not_serialized(self):
        """Ensure api_key is NOT in serialized state (security)."""
        state = _make_state()
        payload = state.model_dump()
        assert "api_key" not in payload
        raw_json = state.model_dump_json()
        assert "api_key" not in raw_json or '"api_key":' not in raw_json


# ---------------------------------------------------------------------------
# Egress / network policy
# ---------------------------------------------------------------------------


class TestEgressPolicy:
    """Tests for egress control wiring on options, state, and session."""

    def test_options_egress_defaults(self):
        opts = InstaVMSandboxClientOptions()
        assert opts.allow_internet_access is True
        assert opts.allow_http is True
        assert opts.allow_https is True
        assert opts.allow_package_managers is True
        assert opts.allowed_domains == ()
        assert opts.allowed_cidrs == ()

    def test_options_egress_restricted(self):
        opts = InstaVMSandboxClientOptions(
            allow_internet_access=False,
            allowed_domains=["pypi.org", "npmjs.com"],
            allowed_cidrs=["10.0.0.0/8"],
        )
        assert opts.allow_internet_access is False
        assert opts.allowed_domains == ("pypi.org", "npmjs.com")
        assert opts.allowed_cidrs == ("10.0.0.0/8",)

    def test_options_accepts_list_for_domains_and_cidrs(self):
        opts = InstaVMSandboxClientOptions(
            allowed_domains=["example.com"],
            allowed_cidrs=["192.168.0.0/16"],
        )
        # Should be stored as tuples.
        assert isinstance(opts.allowed_domains, tuple)
        assert isinstance(opts.allowed_cidrs, tuple)

    def test_state_egress_fields_persist(self):
        state = _make_state(
            allow_internet_access=False,
            allow_http=False,
            allow_https=True,
            allow_package_managers=True,
            allowed_domains=("api.example.com",),
            allowed_cidrs=("10.0.0.0/8",),
        )
        payload = json.loads(state.model_dump_json())
        restored = InstaVMSandboxSessionState.model_validate(payload)
        assert restored.allow_internet_access is False
        assert restored.allow_http is False
        assert restored.allow_https is True
        assert restored.allow_package_managers is True
        assert restored.allowed_domains == ("api.example.com",)
        assert restored.allowed_cidrs == ("10.0.0.0/8",)

    def test_state_has_egress_restrictions_default(self):
        state = _make_state()
        assert not state._has_egress_restrictions

    def test_state_has_egress_restrictions_when_restricted(self):
        state = _make_state(allow_internet_access=False)
        assert state._has_egress_restrictions

    def test_state_has_egress_restrictions_with_domains(self):
        state = _make_state(allowed_domains=("example.com",))
        assert state._has_egress_restrictions

    def test_state_has_egress_restrictions_with_cidrs(self):
        state = _make_state(allowed_cidrs=("10.0.0.0/8",))
        assert state._has_egress_restrictions

    def test_state_has_egress_restrictions_pkg_managers_off(self):
        state = _make_state(allow_package_managers=False)
        assert state._has_egress_restrictions

    @pytest.mark.asyncio
    async def test_set_egress_policy_calls_sdk(self):
        mock = _make_instavm_mock()
        mock.set_session_egress.return_value = {"status": "ok"}
        state = _make_state()
        session = InstaVMSandboxSession.from_state(state, client=mock, api_key="test")

        result = await session.set_egress_policy(
            allow_http=False,
            allow_https=True,
            allow_package_managers=True,
            allowed_domains=["api.openai.com"],
            allowed_cidrs=["10.0.0.0/8"],
        )

        mock.set_session_egress.assert_called_once_with(
            "ivm-sess-1234",
            allow_package_managers=True,
            allow_http=False,
            allow_https=True,
            allowed_domains=["api.openai.com"],
            allowed_cidrs=["10.0.0.0/8"],
        )
        assert result == {"status": "ok"}

    @pytest.mark.asyncio
    async def test_get_egress_policy_calls_sdk(self):
        mock = _make_instavm_mock()
        mock.get_session_egress.return_value = {
            "allow_http": True, "allow_https": True,
            "allow_public_repos": True, "allowed_domains": [], "allowed_cidrs": [],
        }
        state = _make_state()
        session = InstaVMSandboxSession.from_state(state, client=mock, api_key="test")

        result = await session.get_egress_policy()
        mock.get_session_egress.assert_called_once_with("ivm-sess-1234")
        assert result["allow_http"] is True

    @pytest.mark.asyncio
    async def test_apply_egress_from_state_noop_when_unrestricted(self):
        mock = _make_instavm_mock()
        state = _make_state()
        session = InstaVMSandboxSession.from_state(state, client=mock, api_key="test")

        await session._apply_egress_from_state()
        mock.set_session_egress.assert_not_called()

    @pytest.mark.asyncio
    async def test_apply_egress_from_state_blocks_all_when_no_internet(self):
        mock = _make_instavm_mock()
        mock.set_session_egress.return_value = {"status": "ok"}
        state = _make_state(allow_internet_access=False)
        session = InstaVMSandboxSession.from_state(state, client=mock, api_key="test")

        await session._apply_egress_from_state()
        mock.set_session_egress.assert_called_once_with(
            "ivm-sess-1234",
            allow_package_managers=False,
            allow_http=False,
            allow_https=False,
            allowed_domains=[],
            allowed_cidrs=[],
        )

    @pytest.mark.asyncio
    async def test_apply_egress_from_state_custom_policy(self):
        mock = _make_instavm_mock()
        mock.set_session_egress.return_value = {"status": "ok"}
        state = _make_state(
            allow_http=True,
            allow_https=True,
            allow_package_managers=False,
            allowed_domains=("api.openai.com",),
            allowed_cidrs=("10.0.0.0/8",),
        )
        session = InstaVMSandboxSession.from_state(state, client=mock, api_key="test")

        await session._apply_egress_from_state()
        mock.set_session_egress.assert_called_once_with(
            "ivm-sess-1234",
            allow_package_managers=False,
            allow_http=True,
            allow_https=True,
            allowed_domains=["api.openai.com"],
            allowed_cidrs=["10.0.0.0/8"],
        )

    @pytest.mark.asyncio
    async def test_create_applies_egress_policy(self):
        """InstaVMSandboxClient.create applies egress when options restrict it."""
        client = InstaVMSandboxClient(api_key="test-key")
        mock = _make_instavm_mock()
        mock.set_session_egress.return_value = {"status": "ok"}

        with patch.object(client, "_make_instavm_client", return_value=mock):
            opts = InstaVMSandboxClientOptions(
                allow_internet_access=False,
                allowed_domains=["trusted.com"],
            )
            await client.create(options=opts)
            mock.set_session_egress.assert_called_once()
            call_kwargs = mock.set_session_egress.call_args
            assert call_kwargs[1]["allow_http"] is False
            assert call_kwargs[1]["allow_https"] is False

    @pytest.mark.asyncio
    async def test_create_skips_egress_when_unrestricted(self):
        """Unrestricted options should NOT call set_session_egress."""
        client = InstaVMSandboxClient(api_key="test-key")
        mock = _make_instavm_mock()

        with patch.object(client, "_make_instavm_client", return_value=mock):
            opts = InstaVMSandboxClientOptions()
            await client.create(options=opts)
            mock.set_session_egress.assert_not_called()

    @pytest.mark.asyncio
    async def test_resume_reapplies_egress_policy(self):
        """Egress policy from state should be re-applied on resume."""
        client = InstaVMSandboxClient(api_key="test-key")
        mock = _make_instavm_mock()
        mock.set_session_egress.return_value = {"status": "ok"}

        state = _make_state(
            allow_internet_access=False,
            allowed_cidrs=("172.16.0.0/12",),
        )

        with patch("instavm.integrations.openai_agents.InstaVM", return_value=mock):
            await client.resume(state)
            mock.set_session_egress.assert_called_once()

    def test_options_json_roundtrip_with_egress(self):
        opts = InstaVMSandboxClientOptions(
            allow_internet_access=False,
            allow_http=False,
            allow_https=True,
            allow_package_managers=True,
            allowed_domains=["pypi.org", "*.github.com"],
            allowed_cidrs=["10.0.0.0/8", "172.16.0.0/12"],
        )
        payload = json.loads(opts.model_dump_json())
        restored = InstaVMSandboxClientOptions.model_validate(payload)
        assert restored.allow_internet_access is False
        assert restored.allow_http is False
        assert restored.allow_https is True
        assert restored.allowed_domains == ("pypi.org", "*.github.com")
        assert restored.allowed_cidrs == ("10.0.0.0/8", "172.16.0.0/12")


# ---------------------------------------------------------------------------
# Regression tests for review fixes
# ---------------------------------------------------------------------------


class TestSentinelNoNewline:
    """Verify that commands with no trailing newline don't corrupt stdout."""

    @pytest.mark.asyncio
    async def test_printf_without_newline(self):
        """printf 'hi' (no trailing newline) must not merge with sentinel."""
        mock = _make_instavm_mock()
        # The blank echo we now inject guarantees a newline separator.
        mock.execute.return_value = {
            "stdout": "hi\n\n__INSTAVM_EC__0\n",
            "stderr": "",
        }
        state = _make_state()
        sess = InstaVMSandboxSession(state=state, client=mock, api_key="test")
        sess._api_has_exit_code = False

        result = await sess._exec_internal("printf", "hi")
        assert result.exit_code == 0
        assert result.stdout == b"hi\n"

    @pytest.mark.asyncio
    async def test_sentinel_not_in_stdout_when_no_trailing_newline(self):
        """Sentinel must never appear in returned stdout."""
        mock = _make_instavm_mock()
        mock.execute.return_value = {
            "stdout": "data\n\n__INSTAVM_EC__42\n",
            "stderr": "",
        }
        state = _make_state()
        sess = InstaVMSandboxSession(state=state, client=mock, api_key="test")
        sess._api_has_exit_code = False

        result = await sess._exec_internal("some_cmd")
        assert b"__INSTAVM_EC__" not in result.stdout
        assert result.exit_code == 42


class TestSymlinkEscapeProtection:
    """Verify that write containment checks catch existing symlinks at the leaf."""

    @pytest.mark.asyncio
    async def test_write_rejects_leaf_symlink_outside_workspace(self):
        """If the leaf is a symlink resolving outside workspace, write must fail."""
        from agents.sandbox.errors import InvalidManifestPathError

        mock = _make_instavm_mock()
        # mkdir -p succeeds (parent creation).
        # First realpath (full path) resolves to /etc/passwd — outside workspace.
        call_count = 0

        def fake_execute(cmd, lang, timeout=None):
            nonlocal call_count
            call_count += 1
            if "mkdir" in cmd:
                return {"stdout": "\n\n__INSTAVM_EC__0\n", "stderr": ""}
            if "realpath" in cmd:
                # Full realpath resolves to outside workspace — exit 111.
                return {"stdout": "\n\n__INSTAVM_EC__111\n", "stderr": ""}
            return {"stdout": "\n\n__INSTAVM_EC__0\n", "stderr": ""}

        mock.execute.side_effect = fake_execute
        state = _make_state()
        sess = InstaVMSandboxSession(state=state, client=mock, api_key="test")
        sess._api_has_exit_code = False
        sess._workspace_root_ready = True

        with pytest.raises(InvalidManifestPathError):
            await sess.write(
                Path("/workspace/evil_link"),
                io.BytesIO(b"payload"),
            )


class TestWriteErrorClassification:
    """Verify write transport failures raise WorkspaceArchiveWriteError, not Type."""

    @pytest.mark.asyncio
    async def test_write_failure_raises_archive_write_error(self):
        from agents.sandbox.errors import WorkspaceArchiveWriteError

        mock = _make_instavm_mock()
        call_count = 0

        def fake_execute(cmd, lang, timeout=None):
            nonlocal call_count
            call_count += 1
            if "mkdir" in cmd:
                return {"stdout": "\n\n__INSTAVM_EC__0\n", "stderr": ""}
            if "realpath" in cmd or "case" in cmd:
                return {"stdout": "ok\n\n__INSTAVM_EC__0\n", "stderr": ""}
            # The actual write command fails.
            return {"stdout": "\n\n__INSTAVM_EC__1\n", "stderr": "disk full"}

        mock.execute.side_effect = fake_execute
        state = _make_state()
        sess = InstaVMSandboxSession(state=state, client=mock, api_key="test")
        sess._api_has_exit_code = False
        sess._workspace_root_ready = True

        with pytest.raises(WorkspaceArchiveWriteError):
            await sess.write(
                Path("/workspace/file.txt"),
                io.BytesIO(b"data"),
            )
