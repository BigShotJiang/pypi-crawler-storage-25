"""
Unit tests for the PtyManager (sandbox_client.py).

Mocks HTTP requests — no real API calls.

Run:
    python -m pytest tests/test_pty_manager.py -v
"""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from instavm.sandbox_client import InstaVM, PtyManager


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def mock_client():
    """InstaVM client with _request_json mocked."""
    with patch.object(InstaVM, "__init__", lambda self, **kw: None):
        client = InstaVM.__new__(InstaVM)
        client.api_key = "test-key"
        client.base_url = "https://api.instavm.io"
        client._request_json = MagicMock()
        client.session_id = "sess-abc"
        client.pty = PtyManager(client)
    return client


# ---------------------------------------------------------------------------
# PtyManager.create
# ---------------------------------------------------------------------------


class TestPtyCreate:
    def test_create_default_params(self, mock_client):
        mock_client._request_json.return_value = {
            "session_id": "pty-001",
            "active": True,
            "pid": 42,
            "cols": 80,
            "rows": 24,
        }
        result = mock_client.pty.create("sess-abc")
        mock_client._request_json.assert_called_once_with(
            "POST",
            "/v1/sessions/sess-abc/pty/sessions",
            json_data={"cols": 80, "rows": 24},
        )
        assert result["session_id"] == "pty-001"
        assert result["active"] is True

    def test_create_custom_size(self, mock_client):
        mock_client._request_json.return_value = {"session_id": "pty-002"}
        mock_client.pty.create("sess-abc", cols=120, rows=40)
        mock_client._request_json.assert_called_once_with(
            "POST",
            "/v1/sessions/sess-abc/pty/sessions",
            json_data={"cols": 120, "rows": 40},
        )

    def test_create_with_pty_id(self, mock_client):
        mock_client._request_json.return_value = {"session_id": "my-pty"}
        mock_client.pty.create("sess-abc", pty_id="my-pty")
        call_kwargs = mock_client._request_json.call_args
        assert call_kwargs[1]["json_data"]["id"] == "my-pty"

    def test_create_with_command(self, mock_client):
        mock_client._request_json.return_value = {"session_id": "pty-003"}
        mock_client.pty.create("sess-abc", command="/bin/zsh")
        call_kwargs = mock_client._request_json.call_args
        # The SDK maps 'command' → 'shell' to match the backend PTY API
        assert call_kwargs[1]["json_data"]["shell"] == "/bin/zsh"


# ---------------------------------------------------------------------------
# PtyManager.list / get
# ---------------------------------------------------------------------------


class TestPtyListGet:
    def test_list_returns_array(self, mock_client):
        mock_client._request_json.return_value = [
            {"session_id": "pty-001", "active": True},
            {"session_id": "pty-002", "active": False},
        ]
        result = mock_client.pty.list("sess-abc")
        assert len(result) == 2
        mock_client._request_json.assert_called_once_with(
            "GET", "/v1/sessions/sess-abc/pty/sessions"
        )

    def test_list_unwraps_sessions_key(self, mock_client):
        mock_client._request_json.return_value = {
            "sessions": [{"session_id": "pty-001"}]
        }
        result = mock_client.pty.list("sess-abc")
        assert len(result) == 1

    def test_get_single(self, mock_client):
        mock_client._request_json.return_value = {
            "session_id": "pty-001",
            "active": True,
            "exit_code": None,
        }
        result = mock_client.pty.get("sess-abc", "pty-001")
        assert result["session_id"] == "pty-001"
        mock_client._request_json.assert_called_once_with(
            "GET", "/v1/sessions/sess-abc/pty/sessions/pty-001"
        )


# ---------------------------------------------------------------------------
# PtyManager.resize / kill
# ---------------------------------------------------------------------------


class TestPtyResizeKill:
    def test_resize(self, mock_client):
        mock_client._request_json.return_value = {"ok": True}
        mock_client.pty.resize("sess-abc", "pty-001", 200, 50)
        mock_client._request_json.assert_called_once_with(
            "POST",
            "/v1/sessions/sess-abc/pty/sessions/pty-001/resize",
            json_data={"cols": 200, "rows": 50},
        )

    def test_kill(self, mock_client):
        mock_client._request_json.return_value = {"ok": True}
        mock_client.pty.kill("sess-abc", "pty-001")
        mock_client._request_json.assert_called_once_with(
            "DELETE", "/v1/sessions/sess-abc/pty/sessions/pty-001"
        )


# ---------------------------------------------------------------------------
# PtyManager.ws_url
# ---------------------------------------------------------------------------


class TestPtyWsUrl:
    def test_ws_url_https(self, mock_client):
        url = mock_client.pty.ws_url("sess-abc", "pty-001")
        assert url.startswith("wss://")
        assert "/v1/sessions/sess-abc/pty/pty-001/connect" in url
        assert "api_key=test-key" in url

    def test_ws_url_http(self, mock_client):
        mock_client.base_url = "http://localhost:8000"
        url = mock_client.pty.ws_url("sess-abc", "pty-001")
        assert url.startswith("ws://")
        assert "localhost:8000" in url
