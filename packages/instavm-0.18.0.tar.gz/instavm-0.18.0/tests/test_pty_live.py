#!/usr/bin/env python3
"""
Exhaustive live PTY tests against a running InstaVM staging (or production) API.

Covers:
  1. Raw SDK PTY lifecycle (create, list, get, resize, kill, ws_url)
  2. WebSocket I/O (echo, interactive cat, Python REPL, long output)
  3. OpenAI Agents SDK integration (supports_pty, pty_exec_start, pty_write_stdin,
     pty_terminate_all, non-TTY exec, exit-code propagation)
  4. Edge cases (bad session, timeout, concurrent PTYs, cleanup)

Usage:
    INSTAVM_API_KEY=xxx python -m pytest tests/test_pty_live.py -v -s
    # or for staging:
    INSTAVM_API_KEY=xxx INSTAVM_BASE_URL=https://staging.api.instavm.io \
        python -m pytest tests/test_pty_live.py -v -s

Requires: instavm[pty] and openai-agents installed.
"""

import asyncio
import json
import os
import time

import pytest

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
API_KEY = os.environ.get("INSTAVM_API_KEY", "")
BASE_URL = os.environ.get("INSTAVM_BASE_URL", "https://staging.api.instavm.io")
SKIP_REASON = "Set INSTAVM_API_KEY to run live PTY tests"

pytestmark = [
    pytest.mark.skipif(not API_KEY, reason=SKIP_REASON),
    pytest.mark.live,
]


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def client():
    """Create InstaVM client with a fresh session for the entire module."""
    from instavm import InstaVM

    c = InstaVM(
        api_key=API_KEY,
        base_url=BASE_URL,
        timeout=600,
        auto_start_session=True,
    )
    assert c.session_id, "Session creation failed"
    print(f"\n[fixture] Session: {c.session_id}")
    yield c
    # Cleanup: terminate the session
    try:
        c.close_session()
        print("[fixture] Session closed")
    except Exception as e:
        print(f"[fixture] Session cleanup failed: {e}")


@pytest.fixture(scope="module")
def session_id(client):
    return client.session_id


@pytest.fixture()
def pty_id(client, session_id):
    """Create a single PTY session and yield its ID, then kill it."""
    info = client.pty.create(session_id)
    pid = info.get("session_id") or info.get("id")
    assert pid, f"No PTY session ID in response: {info}"
    yield pid
    try:
        client.pty.kill(session_id, pid)
    except Exception:
        pass


# ===========================================================================
# 1. Raw SDK PTY lifecycle
# ===========================================================================

class TestPtyLifecycle:
    """Test the PtyManager REST operations."""

    def test_create_pty_session(self, client, session_id):
        info = client.pty.create(session_id)
        pid = info.get("session_id") or info.get("id")
        assert pid, f"No session ID: {info}"
        # Cleanup
        client.pty.kill(session_id, pid)

    def test_create_with_custom_size(self, client, session_id):
        info = client.pty.create(session_id, cols=120, rows=40)
        pid = info.get("session_id") or info.get("id")
        assert pid
        client.pty.kill(session_id, pid)

    def test_create_with_command(self, client, session_id):
        info = client.pty.create(session_id, command="/bin/sh")
        pid = info.get("session_id") or info.get("id")
        assert pid
        client.pty.kill(session_id, pid)

    def test_list_pty_sessions(self, client, session_id, pty_id):
        sessions = client.pty.list(session_id)
        assert isinstance(sessions, list)
        ids = [s.get("session_id") or s.get("id") for s in sessions]
        assert pty_id in ids

    def test_get_pty_session(self, client, session_id, pty_id):
        info = client.pty.get(session_id, pty_id)
        retrieved_id = info.get("session_id") or info.get("id")
        assert retrieved_id == pty_id

    def test_resize_pty_session(self, client, session_id, pty_id):
        result = client.pty.resize(session_id, pty_id, cols=200, rows=50)
        # Should not raise

    def test_kill_pty_session(self, client, session_id):
        info = client.pty.create(session_id)
        pid = info.get("session_id") or info.get("id")
        client.pty.kill(session_id, pid)
        # Verify it's gone or inactive
        info = client.pty.get(session_id, pid)
        assert not info.get("active", True), f"PTY should be inactive after kill: {info}"

    def test_ws_url_generation(self, client, session_id, pty_id):
        url = client.pty.ws_url(session_id, pty_id)
        assert "wss://" in url or "ws://" in url
        assert pty_id in url
        assert "api_key=" in url


# ===========================================================================
# 2. WebSocket I/O tests
# ===========================================================================

class TestPtyWebSocketIO:
    """Test bidirectional WebSocket communication with PTY."""

    @pytest.mark.asyncio
    async def test_echo_command(self, client, session_id):
        """Send echo and verify output."""
        import websockets

        info = client.pty.create(session_id)
        pid = info.get("session_id") or info.get("id")
        url = client.pty.ws_url(session_id, pid)

        try:
            async with websockets.connect(url) as ws:
                await ws.send(b"echo PTY_ECHO_TEST_123\n")
                output = b""
                deadline = time.monotonic() + 5
                while time.monotonic() < deadline:
                    try:
                        msg = await asyncio.wait_for(ws.recv(), timeout=2)
                        if isinstance(msg, bytes):
                            output += msg
                            if b"PTY_ECHO_TEST_123" in output:
                                break
                    except asyncio.TimeoutError:
                        break

                assert b"PTY_ECHO_TEST_123" in output, f"Expected echo in output: {output!r}"
        finally:
            client.pty.kill(session_id, pid)

    @pytest.mark.asyncio
    async def test_interactive_cat(self, client, session_id):
        """Interactive cat: send lines, expect them echoed."""
        import websockets

        info = client.pty.create(session_id)
        pid = info.get("session_id") or info.get("id")
        url = client.pty.ws_url(session_id, pid)

        try:
            async with websockets.connect(url) as ws:
                await ws.send(b"cat\n")
                await asyncio.sleep(0.3)

                await ws.send(b"hello from cat\n")
                output = b""
                deadline = time.monotonic() + 5
                while time.monotonic() < deadline:
                    try:
                        msg = await asyncio.wait_for(ws.recv(), timeout=2)
                        if isinstance(msg, bytes):
                            output += msg
                            if b"hello from cat" in output:
                                break
                    except asyncio.TimeoutError:
                        break

                assert b"hello from cat" in output
        finally:
            client.pty.kill(session_id, pid)

    @pytest.mark.asyncio
    async def test_python_repl(self, client, session_id):
        """Start python3 REPL, compute 2+2, verify result."""
        import websockets

        info = client.pty.create(session_id, command="python3")
        pid = info.get("session_id") or info.get("id")
        url = client.pty.ws_url(session_id, pid)

        try:
            async with websockets.connect(url) as ws:
                # Wait for REPL prompt
                await asyncio.sleep(1)

                await ws.send(b"print(2 + 2)\n")
                output = b""
                deadline = time.monotonic() + 5
                while time.monotonic() < deadline:
                    try:
                        msg = await asyncio.wait_for(ws.recv(), timeout=2)
                        if isinstance(msg, bytes):
                            output += msg
                            if b"4" in output:
                                break
                    except asyncio.TimeoutError:
                        break

                assert b"4" in output, f"Expected '4' in output: {output!r}"

                # Send exit
                await ws.send(b"exit()\n")
        finally:
            client.pty.kill(session_id, pid)

    @pytest.mark.asyncio
    async def test_resize_control_frame(self, client, session_id):
        """Send a resize JSON control frame via WebSocket."""
        import websockets

        info = client.pty.create(session_id)
        pid = info.get("session_id") or info.get("id")
        url = client.pty.ws_url(session_id, pid)

        try:
            async with websockets.connect(url) as ws:
                resize_msg = json.dumps({"type": "resize", "cols": 160, "rows": 48})
                await ws.send(resize_msg)
                await asyncio.sleep(0.5)
                # No error = success (resize is fire-and-forget)
        finally:
            client.pty.kill(session_id, pid)

    @pytest.mark.asyncio
    async def test_exit_code_propagation(self, client, session_id):
        """Shell exit should send a JSON exit frame."""
        import websockets

        info = client.pty.create(session_id, command="/bin/sh")
        pid = info.get("session_id") or info.get("id")
        url = client.pty.ws_url(session_id, pid)

        exit_code = None
        try:
            async with websockets.connect(url) as ws:
                await asyncio.sleep(0.5)
                await ws.send(b"exit 42\n")

                deadline = time.monotonic() + 5
                while time.monotonic() < deadline:
                    try:
                        msg = await asyncio.wait_for(ws.recv(), timeout=2)
                        if isinstance(msg, str):
                            frame = json.loads(msg)
                            if frame.get("type") == "exit":
                                exit_code = frame.get("exit_code")
                                break
                    except asyncio.TimeoutError:
                        break
                    except Exception:
                        break

            assert exit_code == 42, f"Expected exit code 42, got {exit_code}"
        finally:
            try:
                client.pty.kill(session_id, pid)
            except Exception:
                pass

    @pytest.mark.asyncio
    async def test_large_output(self, client, session_id):
        """Generate large output (1000 lines) and verify we receive it."""
        import websockets

        info = client.pty.create(session_id)
        pid = info.get("session_id") or info.get("id")
        url = client.pty.ws_url(session_id, pid)

        try:
            async with websockets.connect(url) as ws:
                await ws.send(b"seq 1 1000\n")
                output = b""
                deadline = time.monotonic() + 10
                while time.monotonic() < deadline:
                    try:
                        msg = await asyncio.wait_for(ws.recv(), timeout=3)
                        if isinstance(msg, bytes):
                            output += msg
                            if b"1000" in output:
                                break
                    except asyncio.TimeoutError:
                        break

                assert b"1000" in output, f"Expected '1000' in output (got {len(output)} bytes)"
        finally:
            client.pty.kill(session_id, pid)


# ===========================================================================
# 3. OpenAI Agents SDK integration
# ===========================================================================

class TestAgentsIntegration:
    """Test the InstaVMSandboxSession PTY contract."""

    @pytest.fixture()
    def sandbox_session(self, client, session_id):
        """Build an InstaVMSandboxSession around the live client."""
        from instavm.integrations.openai_agents import (
            InstaVMSandboxSession,
            InstaVMSandboxSessionState,
        )
        from agents.sandbox.snapshot import NoopSnapshot
        from agents.sandbox.manifest import Manifest

        state = InstaVMSandboxSessionState(
            instavm_session_id=session_id,
            sandbox_id=session_id,
            snapshot=NoopSnapshot(id="test"),
            manifest=Manifest(),
        )
        session = InstaVMSandboxSession.__new__(InstaVMSandboxSession)
        session.state = state
        session._client = client
        session._api_key = API_KEY
        session._base_url = BASE_URL
        # Init PTY state
        session._pty_entries = {}
        session._reserved_pty_ids = set()
        session._pty_lock = asyncio.Lock()
        return session

    def test_supports_pty_true(self, sandbox_session):
        assert sandbox_session.supports_pty() is True

    @pytest.mark.asyncio
    async def test_pty_exec_start_echo(self, sandbox_session):
        """pty_exec_start('echo', 'HELLO') should return output with HELLO."""
        result = await sandbox_session.pty_exec_start(
            "echo", "HELLO_AGENTS_PTY",
            timeout=15,
            yield_time_s=3,
            tty=True,
        )
        assert result.process_id is not None, "Process should still be running"
        output_text = result.output.decode("utf-8") if isinstance(result.output, bytes) else result.output
        print(f"  pty_exec_start output: {output_text!r}")
        assert "HELLO_AGENTS_PTY" in output_text, f"Expected HELLO_AGENTS_PTY in: {output_text!r}"
        # Cleanup
        await sandbox_session.pty_terminate_all()

    @pytest.mark.asyncio
    async def test_pty_exec_start_non_tty(self, sandbox_session):
        """Non-TTY exec should work without creating a real PTY."""
        result = await sandbox_session.pty_exec_start(
            "echo", "NON_TTY_TEST",
            timeout=15,
            tty=False,
            yield_time_s=3,
        )
        output_text = result.output.decode("utf-8") if isinstance(result.output, bytes) else result.output
        print(f"  non-TTY output: {output_text!r}")
        assert "NON_TTY_TEST" in output_text
        await sandbox_session.pty_terminate_all()

    @pytest.mark.asyncio
    async def test_pty_write_stdin_interactive(self, sandbox_session):
        """Start cat, write stdin, read back."""
        start = await sandbox_session.pty_exec_start(
            "cat",
            timeout=10,
            tty=True,
            yield_time_s=1,
        )
        assert start.process_id is not None

        result = await sandbox_session.pty_write_stdin(
            session_id=start.process_id,
            chars="interactive_input_test\n",
            yield_time_s=2,
        )
        output_text = result.output.decode("utf-8") if isinstance(result.output, bytes) else result.output
        print(f"  write_stdin output: {output_text!r}")
        assert "interactive_input_test" in output_text
        await sandbox_session.pty_terminate_all()

    @pytest.mark.asyncio
    async def test_pty_write_stdin_python_repl(self, sandbox_session):
        """Start python3 REPL, compute 6*7, verify 42."""
        start = await sandbox_session.pty_exec_start(
            "python3",
            timeout=15,
            tty=True,
            yield_time_s=2,
        )
        assert start.process_id is not None

        result = await sandbox_session.pty_write_stdin(
            session_id=start.process_id,
            chars="print(6 * 7)\n",
            yield_time_s=2,
        )
        output_text = result.output.decode("utf-8") if isinstance(result.output, bytes) else result.output
        print(f"  REPL output: {output_text!r}")
        assert "42" in output_text
        await sandbox_session.pty_terminate_all()

    @pytest.mark.asyncio
    async def test_pty_write_stdin_nonexistent_session(self, sandbox_session):
        """Writing to a nonexistent session should raise PtySessionNotFoundError."""
        from agents.sandbox.errors import PtySessionNotFoundError

        with pytest.raises(PtySessionNotFoundError):
            await sandbox_session.pty_write_stdin(
                session_id=99999,
                chars="this should fail\n",
            )

    @pytest.mark.asyncio
    async def test_pty_write_stdin_non_tty_raises(self, sandbox_session):
        """Writing stdin to a non-TTY process should raise RuntimeError."""
        start = await sandbox_session.pty_exec_start(
            "echo", "done",
            timeout=10,
            tty=False,
            yield_time_s=1,
        )
        if start.process_id is not None:
            with pytest.raises(RuntimeError, match="stdin is not available"):
                await sandbox_session.pty_write_stdin(
                    session_id=start.process_id,
                    chars="fail\n",
                )
        await sandbox_session.pty_terminate_all()

    @pytest.mark.asyncio
    async def test_pty_terminate_all(self, sandbox_session):
        """Start multiple PTYs, terminate all, verify empty."""
        await sandbox_session.pty_exec_start("bash", tty=True, yield_time_s=0.5)
        await sandbox_session.pty_exec_start("bash", tty=True, yield_time_s=0.5)
        assert len(sandbox_session._pty_entries) == 2

        await sandbox_session.pty_terminate_all()
        assert len(sandbox_session._pty_entries) == 0
        assert len(sandbox_session._reserved_pty_ids) == 0

    @pytest.mark.asyncio
    async def test_exit_code_on_completion(self, sandbox_session):
        """Run a command that exits with a specific code."""
        result = await sandbox_session.pty_exec_start(
            "sh", "-c", "exit 7",
            timeout=10,
            tty=True,
            yield_time_s=3,
        )
        # The command should have exited; check exit code
        output_text = result.output.decode("utf-8") if isinstance(result.output, bytes) else result.output
        print(f"  exit code result: pid={result.process_id}, exit={result.exit_code}, out={output_text!r}")
        # After yield, the process should be done
        if result.exit_code is not None:
            assert result.exit_code == 7
        await sandbox_session.pty_terminate_all()


# ===========================================================================
# 4. Edge cases
# ===========================================================================

class TestEdgeCases:
    """Test edge cases and error handling."""

    def test_create_many_pty_sessions(self, client, session_id):
        """Create several PTY sessions, verify they all exist."""
        pids = []
        for i in range(5):
            info = client.pty.create(session_id)
            pid = info.get("session_id") or info.get("id")
            assert pid, f"Failed to create PTY {i}"
            pids.append(pid)

        sessions = client.pty.list(session_id)
        listed_ids = {s.get("session_id") or s.get("id") for s in sessions}
        for pid in pids:
            assert pid in listed_ids, f"PTY {pid} not in list"

        # Cleanup
        for pid in pids:
            client.pty.kill(session_id, pid)

    @pytest.mark.asyncio
    async def test_ws_connect_to_killed_pty(self, client, session_id):
        """Connecting WS to a killed PTY should fail gracefully."""
        import websockets

        info = client.pty.create(session_id)
        pid = info.get("session_id") or info.get("id")
        client.pty.kill(session_id, pid)

        url = client.pty.ws_url(session_id, pid)
        with pytest.raises(Exception):
            async with websockets.connect(url) as ws:
                await ws.recv()

    @pytest.mark.asyncio
    async def test_rapid_create_kill_cycles(self, client, session_id):
        """Rapidly create and kill PTY sessions to test cleanup."""
        for i in range(10):
            info = client.pty.create(session_id)
            pid = info.get("session_id") or info.get("id")
            client.pty.kill(session_id, pid)

        # Should still be able to create new ones
        info = client.pty.create(session_id)
        pid = info.get("session_id") or info.get("id")
        assert pid
        client.pty.kill(session_id, pid)
