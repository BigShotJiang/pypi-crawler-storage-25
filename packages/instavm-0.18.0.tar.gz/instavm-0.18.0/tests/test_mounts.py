"""
Unit tests for InstaVM mount strategies and volume helpers.

Tests the ``InstaVMCloudBucketMountStrategy`` and the volume methods on
``InstaVMSandboxSession`` (``mount_volume``, ``unmount_volume``,
``list_mounted_volumes``).

Run:
    python -m pytest tests/test_mounts.py -v
"""

from __future__ import annotations

import asyncio
import uuid
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from agents.sandbox.entries.mounts.base import (
    InContainerMountStrategy,
    MountStrategyBase,
)
from agents.sandbox.entries.mounts.patterns import RcloneMountPattern
from agents.sandbox.errors import MountConfigError
from agents.sandbox.manifest import Manifest
from agents.sandbox.snapshot import resolve_snapshot

from instavm.integrations.mounts import (
    InstaVMCloudBucketMountStrategy,
    _assert_instavm_session,
    _ensure_fuse_support,
    _ensure_rclone,
    _has_command,
    _pkg_install,
)
from instavm.integrations.openai_agents import (
    DEFAULT_INSTAVM_WORKSPACE_ROOT,
    InstaVMSandboxClientOptions,
    InstaVMSandboxSession,
    InstaVMSandboxSessionState,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_state(**overrides) -> InstaVMSandboxSessionState:
    sid = uuid.uuid4()
    defaults = dict(
        session_id=sid,
        manifest=Manifest(root=DEFAULT_INSTAVM_WORKSPACE_ROOT),
        snapshot=resolve_snapshot(None, str(sid)),
        instavm_session_id="ivm-sess-1234",
        base_url="https://api.instavm.io",
    )
    defaults.update(overrides)
    return InstaVMSandboxSessionState(**defaults)


def _make_instavm_mock(
    *,
    session_id="ivm-sess-1234",
    status_return=None,
) -> MagicMock:
    """Create a mocked InstaVM client."""
    mock = MagicMock()
    mock.session_id = session_id
    mock.start_session.return_value = "ivm-new-sess"
    mock.execute.return_value = {"stdout": "", "stderr": ""}
    mock.get_session_status.return_value = status_return or {
        "exists": True,
        "vm_assigned": True,
        "vm_alive": True,
        "vm_id": "vm-abcd-1234",
    }
    mock.kill.return_value = None
    mock.shares = MagicMock()
    mock.shares.create.return_value = {
        "share_id": "test-share",
        "url": "https://test-share.instavm.site/",
    }
    # Volume sub-manager mocks.
    mock.vms = MagicMock()
    mock.vms.mount_volume.return_value = {"status": "ok", "mount_path": "/data"}
    mock.vms.unmount_volume.return_value = {"status": "ok"}
    mock.vms.list_volumes.return_value = [
        {"volume_id": "vol-1", "mount_path": "/data", "mode": "rw"},
    ]
    return mock


class _FakeExecResult:
    """Minimal stand-in for agents.sandbox ExecResult."""

    def __init__(self, exit_code: int = 0, stdout: bytes = b"", stderr: bytes = b""):
        self.exit_code = exit_code
        self.stdout = stdout
        self.stderr = stderr

    def ok(self) -> bool:
        return self.exit_code == 0


# ---------------------------------------------------------------------------
# Mount strategy auto-registration
# ---------------------------------------------------------------------------


class TestMountStrategyRegistration:
    def test_registered_in_subclass_registry(self):
        assert "instavm_cloud_bucket" in MountStrategyBase._subclass_registry
        assert (
            MountStrategyBase._subclass_registry["instavm_cloud_bucket"]
            is InstaVMCloudBucketMountStrategy
        )

    def test_parse_roundtrip(self):
        strategy = InstaVMCloudBucketMountStrategy()
        payload = strategy.model_dump()
        restored = MountStrategyBase.parse(payload)
        assert isinstance(restored, InstaVMCloudBucketMountStrategy)
        assert restored.type == "instavm_cloud_bucket"


# ---------------------------------------------------------------------------
# Cloud bucket mount strategy
# ---------------------------------------------------------------------------


class TestCloudBucketMountStrategy:
    def test_defaults(self):
        strategy = InstaVMCloudBucketMountStrategy()
        assert strategy.type == "instavm_cloud_bucket"
        assert isinstance(strategy.pattern, RcloneMountPattern)
        assert strategy.pattern.mode == "fuse"

    def test_custom_pattern(self):
        pattern = RcloneMountPattern(mode="nfs")
        strategy = InstaVMCloudBucketMountStrategy(pattern=pattern)
        assert strategy.pattern.mode == "nfs"

    def test_delegate_creates_in_container_strategy(self):
        strategy = InstaVMCloudBucketMountStrategy()
        delegate = strategy._delegate()
        assert isinstance(delegate, InContainerMountStrategy)
        assert isinstance(delegate.pattern, RcloneMountPattern)

    def test_build_docker_volume_driver_config_returns_none(self):
        strategy = InstaVMCloudBucketMountStrategy()
        mock_mount = MagicMock()
        assert strategy.build_docker_volume_driver_config(mock_mount) is None


# ---------------------------------------------------------------------------
# Session guard
# ---------------------------------------------------------------------------


class TestSessionGuard:
    def test_rejects_non_instavm_session(self):
        mock_session = MagicMock()
        type(mock_session).__name__ = "E2BSandboxSession"
        with pytest.raises(MountConfigError):
            _assert_instavm_session(mock_session)

    def test_accepts_instavm_session(self):
        mock_session = MagicMock()
        type(mock_session).__name__ = "InstaVMSandboxSession"
        _assert_instavm_session(mock_session)  # Should not raise.


# ---------------------------------------------------------------------------
# Preflight helpers
# ---------------------------------------------------------------------------


class TestHasCommand:
    @pytest.mark.asyncio
    async def test_has_command_true(self):
        session = MagicMock()
        session.exec = AsyncMock(return_value=_FakeExecResult(exit_code=0))
        assert await _has_command(session, "rclone") is True

    @pytest.mark.asyncio
    async def test_has_command_false(self):
        session = MagicMock()
        session.exec = AsyncMock(return_value=_FakeExecResult(exit_code=1))
        assert await _has_command(session, "rclone") is False


class TestPkgInstall:
    @pytest.mark.asyncio
    async def test_installs_via_apt(self):
        session = MagicMock()
        # First call: check for apt-get → success.
        # Second call: install → success.
        session.exec = AsyncMock(
            side_effect=[
                _FakeExecResult(exit_code=0),  # apt-get available
                _FakeExecResult(exit_code=0),  # install succeeds
            ]
        )
        await _pkg_install(session, "fuse3", what="fusermount")

    @pytest.mark.asyncio
    async def test_installs_via_apk_fallback(self):
        session = MagicMock()
        session.exec = AsyncMock(
            side_effect=[
                _FakeExecResult(exit_code=1),  # no apt-get
                _FakeExecResult(exit_code=0),  # apk available
                _FakeExecResult(exit_code=0),  # install succeeds
            ]
        )
        await _pkg_install(session, "fuse3", what="fusermount")

    @pytest.mark.asyncio
    async def test_raises_when_no_package_manager(self):
        session = MagicMock()
        session.exec = AsyncMock(
            side_effect=[
                _FakeExecResult(exit_code=1),  # no apt-get
                _FakeExecResult(exit_code=1),  # no apk
            ]
        )
        with pytest.raises(MountConfigError, match="no supported package manager"):
            await _pkg_install(session, "fuse3", what="fusermount")

    @pytest.mark.asyncio
    async def test_retries_on_failure(self):
        session = MagicMock()
        session.exec = AsyncMock(
            side_effect=[
                _FakeExecResult(exit_code=0),  # apt-get available
                _FakeExecResult(exit_code=1),  # attempt 1 fails
                _FakeExecResult(exit_code=1),  # attempt 2 fails
                _FakeExecResult(exit_code=0),  # attempt 3 succeeds
            ]
        )
        await _pkg_install(session, "rclone", what="rclone")

    @pytest.mark.asyncio
    async def test_raises_after_all_retries_fail(self):
        session = MagicMock()
        session.exec = AsyncMock(
            side_effect=[
                _FakeExecResult(exit_code=0),  # apt-get available
                _FakeExecResult(exit_code=1),  # attempt 1
                _FakeExecResult(exit_code=1),  # attempt 2
                _FakeExecResult(exit_code=1),  # attempt 3
            ]
        )
        with pytest.raises(MountConfigError, match="failed to install"):
            await _pkg_install(session, "rclone", what="rclone")


class TestEnsureFuseSupport:
    @pytest.mark.asyncio
    async def test_succeeds_when_fuse_present(self):
        session = MagicMock()
        session.exec = AsyncMock(
            side_effect=[
                _FakeExecResult(exit_code=0),  # /dev/fuse exists
                _FakeExecResult(exit_code=0),  # fuse in /proc/filesystems
                _FakeExecResult(exit_code=0),  # fusermount3 available
                _FakeExecResult(exit_code=0),  # fusermount available (fallback)
                _FakeExecResult(exit_code=0),  # chmod /dev/fuse
            ]
        )
        await _ensure_fuse_support(session)

    @pytest.mark.asyncio
    async def test_raises_when_no_dev_fuse(self):
        session = MagicMock()
        session.exec = AsyncMock(return_value=_FakeExecResult(exit_code=1))
        with pytest.raises(MountConfigError, match="/dev/fuse"):
            await _ensure_fuse_support(session)

    @pytest.mark.asyncio
    async def test_raises_when_no_fuse_kmod(self):
        session = MagicMock()
        session.exec = AsyncMock(
            side_effect=[
                _FakeExecResult(exit_code=0),  # /dev/fuse ok
                _FakeExecResult(exit_code=1),  # no fuse in /proc/filesystems
            ]
        )
        with pytest.raises(MountConfigError, match="FUSE kernel module"):
            await _ensure_fuse_support(session)


class TestEnsureRclone:
    @pytest.mark.asyncio
    async def test_already_installed(self):
        session = MagicMock()
        session.exec = AsyncMock(return_value=_FakeExecResult(exit_code=0))
        await _ensure_rclone(session)
        # Only one exec call to check.
        assert session.exec.await_count == 1

    @pytest.mark.asyncio
    async def test_installs_via_pkg_manager(self):
        call_count = 0

        async def fake_exec(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            cmd = args[2] if len(args) > 2 else ""
            # First check: rclone not found.
            if call_count == 1:
                return _FakeExecResult(exit_code=1)
            # apt-get check: found.
            if "apt-get" in str(cmd):
                return _FakeExecResult(exit_code=0)
            # Install: success.
            # Post-install check: found.
            return _FakeExecResult(exit_code=0)

        session = MagicMock()
        session.exec = AsyncMock(side_effect=fake_exec)
        await _ensure_rclone(session)


# ---------------------------------------------------------------------------
# Volume helpers on InstaVMSandboxSession
# ---------------------------------------------------------------------------


class TestVolumeHelpers:
    @pytest.mark.asyncio
    async def test_get_vm_id(self):
        mock_client = _make_instavm_mock()
        state = _make_state()
        session = InstaVMSandboxSession(state=state, client=mock_client)
        vm_id = await session._get_vm_id()
        assert vm_id == "vm-abcd-1234"
        mock_client.get_session_status.assert_called_once_with("ivm-sess-1234")

    @pytest.mark.asyncio
    async def test_get_vm_id_caches(self):
        mock_client = _make_instavm_mock()
        state = _make_state()
        session = InstaVMSandboxSession(state=state, client=mock_client)
        vm_id1 = await session._get_vm_id()
        vm_id2 = await session._get_vm_id()
        assert vm_id1 == vm_id2
        # Only one API call despite two invocations.
        assert mock_client.get_session_status.call_count == 1

    @pytest.mark.asyncio
    async def test_get_vm_id_raises_when_no_vm(self):
        mock_client = _make_instavm_mock(
            status_return={
                "exists": True,
                "vm_assigned": False,
                "vm_alive": False,
            }
        )
        state = _make_state()
        session = InstaVMSandboxSession(state=state, client=mock_client)
        with pytest.raises(Exception, match="Cannot determine VM ID"):
            await session._get_vm_id()

    @pytest.mark.asyncio
    async def test_mount_volume(self):
        mock_client = _make_instavm_mock()
        state = _make_state()
        session = InstaVMSandboxSession(state=state, client=mock_client)
        result = await session.mount_volume("vol-123", "/data")
        assert result["status"] == "ok"
        mock_client.vms.mount_volume.assert_called_once_with(
            "vm-abcd-1234", "vol-123", "/data", "rw", None,
        )

    @pytest.mark.asyncio
    async def test_mount_volume_with_options(self):
        mock_client = _make_instavm_mock()
        state = _make_state()
        session = InstaVMSandboxSession(state=state, client=mock_client)
        await session.mount_volume(
            "vol-456", "/mnt/storage", mode="ro", checkpoint_id="cp-001",
        )
        mock_client.vms.mount_volume.assert_called_once_with(
            "vm-abcd-1234", "vol-456", "/mnt/storage", "ro", "cp-001",
        )

    @pytest.mark.asyncio
    async def test_unmount_volume(self):
        mock_client = _make_instavm_mock()
        state = _make_state()
        session = InstaVMSandboxSession(state=state, client=mock_client)
        result = await session.unmount_volume("vol-123", "/data")
        assert result["status"] == "ok"
        mock_client.vms.unmount_volume.assert_called_once_with(
            "vm-abcd-1234", "vol-123", "/data",
        )

    @pytest.mark.asyncio
    async def test_list_mounted_volumes(self):
        mock_client = _make_instavm_mock()
        state = _make_state()
        session = InstaVMSandboxSession(state=state, client=mock_client)
        result = await session.list_mounted_volumes()
        assert len(result) == 1
        assert result[0]["volume_id"] == "vol-1"
        mock_client.vms.list_volumes.assert_called_once_with("vm-abcd-1234")


# ---------------------------------------------------------------------------
# Mount strategy lifecycle (mocked delegate)
# ---------------------------------------------------------------------------


class TestMountStrategyLifecycle:
    """Test activate/deactivate/teardown/restore with mocked delegation."""

    @pytest.mark.asyncio
    async def test_activate_rejects_non_instavm_session(self):
        strategy = InstaVMCloudBucketMountStrategy()
        mock_session = MagicMock()
        type(mock_session).__name__ = "SomeOtherSession"
        mock_mount = MagicMock()
        with pytest.raises(MountConfigError, match="InstaVMSandboxSession"):
            await strategy.activate(
                mock_mount, mock_session, Path("/workspace"), Path("/workspace"),
            )

    @pytest.mark.asyncio
    async def test_deactivate_rejects_non_instavm_session(self):
        strategy = InstaVMCloudBucketMountStrategy()
        mock_session = MagicMock()
        type(mock_session).__name__ = "SomeOtherSession"
        mock_mount = MagicMock()
        with pytest.raises(MountConfigError, match="InstaVMSandboxSession"):
            await strategy.deactivate(
                mock_mount, mock_session, Path("/workspace"), Path("/workspace"),
            )

    @pytest.mark.asyncio
    async def test_teardown_for_snapshot_rejects_non_instavm(self):
        strategy = InstaVMCloudBucketMountStrategy()
        mock_session = MagicMock()
        type(mock_session).__name__ = "SomeOtherSession"
        mock_mount = MagicMock()
        with pytest.raises(MountConfigError, match="InstaVMSandboxSession"):
            await strategy.teardown_for_snapshot(
                mock_mount, mock_session, Path("/mnt/s3"),
            )

    @pytest.mark.asyncio
    async def test_restore_after_snapshot_rejects_non_instavm(self):
        strategy = InstaVMCloudBucketMountStrategy()
        mock_session = MagicMock()
        type(mock_session).__name__ = "SomeOtherSession"
        mock_mount = MagicMock()
        with pytest.raises(MountConfigError, match="InstaVMSandboxSession"):
            await strategy.restore_after_snapshot(
                mock_mount, mock_session, Path("/mnt/s3"),
            )

    def test_json_roundtrip(self):
        strategy = InstaVMCloudBucketMountStrategy(
            pattern=RcloneMountPattern(mode="nfs"),
        )
        payload = strategy.model_dump()
        restored = MountStrategyBase.parse(payload)
        assert isinstance(restored, InstaVMCloudBucketMountStrategy)
        assert restored.pattern.mode == "nfs"

    def test_validate_mount_delegates(self):
        strategy = InstaVMCloudBucketMountStrategy()
        # Validate delegates to InContainerMountStrategy which calls
        # mount.in_container_adapter().validate(). Just confirm it doesn't
        # crash when the mount supports RcloneMountPattern.
        mock_mount = MagicMock()
        adapter = MagicMock()
        mock_mount.in_container_adapter.return_value = adapter
        strategy.validate_mount(mock_mount)
        adapter.validate.assert_called_once()
