#!/usr/bin/env python3
"""
End-to-end test: OpenAI SandboxAgent with Shell capability over InstaVM PTY.

Creates a real sandbox, runs a SandboxAgent with GPT that uses exec + write_stdin,
and verifies the full flow works.

Usage:
    INSTAVM_API_KEY=xxx OPENAI_API_KEY=xxx python tests/test_pty_agent_e2e.py
    # For staging:
    INSTAVM_API_KEY=xxx OPENAI_API_KEY=xxx INSTAVM_BASE_URL=https://staging.api.instavm.io \
        python tests/test_pty_agent_e2e.py

Requires: instavm[pty] and openai-agents >=0.14.0 installed.
"""

import asyncio
import os
import sys
import traceback

API_KEY = os.environ.get("INSTAVM_API_KEY", "")
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")
BASE_URL = os.environ.get("INSTAVM_BASE_URL", "https://staging.api.instavm.io")

PASS = "✅"
FAIL = "❌"
SKIP = "⏭️"


def report(name: str, passed: bool, detail: str = ""):
    icon = PASS if passed else FAIL
    print(f"  {icon} {name}")
    if detail:
        print(f"     {detail}")


async def main() -> int:
    failures = 0

    if not API_KEY:
        print("ERROR: Set INSTAVM_API_KEY")
        return 1
    if not OPENAI_API_KEY:
        print("ERROR: Set OPENAI_API_KEY")
        return 1

    # ----- 1. Create sandbox session -----
    print("\n=== 1. Create sandbox session ===")
    from instavm import InstaVM

    client = InstaVM(
        api_key=API_KEY,
        base_url=BASE_URL,
        timeout=600,
        auto_start_session=True,
    )
    session_id = client.session_id
    if session_id:
        report("Session created", True, f"session_id={session_id}")
    else:
        report("Session created", False, "No session_id returned")
        return 1

    try:
        # ----- 2. Build InstaVMSandboxSession -----
        print("\n=== 2. Build sandbox session wrapper ===")
        from instavm.integrations.openai_agents import (
            InstaVMSandboxSession,
            InstaVMSandboxSessionState,
        )
        from agents.sandbox.snapshot import NoopSnapshot
        from agents.sandbox.manifest import Manifest

        state = InstaVMSandboxSessionState(
            instavm_session_id=session_id,
            sandbox_id=session_id,
            snapshot=NoopSnapshot(id="e2e"),
            manifest=Manifest(),
        )
        sandbox_session = InstaVMSandboxSession.__new__(InstaVMSandboxSession)
        sandbox_session.state = state
        sandbox_session._client = client
        sandbox_session._api_key = API_KEY
        sandbox_session._base_url = BASE_URL
        sandbox_session._pty_entries = {}
        sandbox_session._reserved_pty_ids = set()
        sandbox_session._pty_lock = asyncio.Lock()

        pty_supported = sandbox_session.supports_pty()
        report("supports_pty()", pty_supported)
        if not pty_supported:
            failures += 1

        # ----- 3. Direct pty_exec_start (TTY) -----
        print("\n=== 3. pty_exec_start (TTY mode) ===")
        try:
            result = await sandbox_session.pty_exec_start(
                "echo", "AGENT_PTY_WORKS",
                timeout=15,
                tty=True,
                yield_time_s=3,
            )
            output = result.output.decode("utf-8") if isinstance(result.output, bytes) else str(result.output)
            ok = "AGENT_PTY_WORKS" in output
            report("pty_exec_start (TTY echo)", ok, f"pid={result.process_id}, output={output[:200]!r}")
            if not ok:
                failures += 1
        except Exception as e:
            report("pty_exec_start (TTY echo)", False, f"{e}")
            traceback.print_exc()
            failures += 1

        # ----- 4. pty_exec_start (non-TTY) -----
        print("\n=== 4. pty_exec_start (non-TTY mode) ===")
        try:
            result = await sandbox_session.pty_exec_start(
                "echo", "NON_TTY_OUTPUT",
                timeout=15,
                tty=False,
                yield_time_s=3,
            )
            output = result.output.decode("utf-8") if isinstance(result.output, bytes) else str(result.output)
            ok = "NON_TTY_OUTPUT" in output
            report("pty_exec_start (non-TTY)", ok, f"output={output[:200]!r}")
            if not ok:
                failures += 1
        except Exception as e:
            report("pty_exec_start (non-TTY)", False, f"{e}")
            traceback.print_exc()
            failures += 1

        # ----- 5. Interactive write_stdin -----
        print("\n=== 5. pty_write_stdin (interactive cat) ===")
        try:
            start = await sandbox_session.pty_exec_start(
                "cat",
                timeout=10,
                tty=True,
                yield_time_s=1,
            )
            assert start.process_id is not None
            result = await sandbox_session.pty_write_stdin(
                session_id=start.process_id,
                chars="INTERACTIVE_STDIN_TEST\n",
                yield_time_s=2,
            )
            output = result.output.decode("utf-8") if isinstance(result.output, bytes) else str(result.output)
            ok = "INTERACTIVE_STDIN_TEST" in output
            report("pty_write_stdin (cat)", ok, f"output={output[:200]!r}")
            if not ok:
                failures += 1
        except Exception as e:
            report("pty_write_stdin (cat)", False, f"{e}")
            traceback.print_exc()
            failures += 1

        # ----- 6. Python REPL via write_stdin -----
        print("\n=== 6. pty_write_stdin (Python REPL) ===")
        try:
            start = await sandbox_session.pty_exec_start(
                "python3",
                timeout=15,
                tty=True,
                yield_time_s=2,
            )
            assert start.process_id is not None
            result = await sandbox_session.pty_write_stdin(
                session_id=start.process_id,
                chars="print(6 * 7)\n",
                yield_time_s=2,
            )
            output = result.output.decode("utf-8") if isinstance(result.output, bytes) else str(result.output)
            ok = "42" in output
            report("pty_write_stdin (python REPL)", ok, f"output={output[:200]!r}")
            if not ok:
                failures += 1
        except Exception as e:
            report("pty_write_stdin (python REPL)", False, f"{e}")
            traceback.print_exc()
            failures += 1

        # ----- 7. Full SandboxAgent with Shell tool -----
        print("\n=== 7. SandboxAgent with Shell capability ===")
        try:
            from agents import Runner, RunConfig
            from agents.sandbox import SandboxAgent, SandboxRunConfig

            agent = SandboxAgent(
                name="PTY Test Agent",
                model="gpt-4.1-mini",
                instructions=(
                    "You have a shell. Run `echo SANDBOX_AGENT_OK` and report the output. "
                    "Answer with exactly the output, nothing else."
                ),
            )

            # Build a minimal sandbox run config with our session
            from instavm.integrations.openai_agents import (
                InstaVMSandboxClient,
            )

            sandbox_client = InstaVMSandboxClient(
                api_key=API_KEY,
                base_url=BASE_URL,
            )

            result = await Runner.run(
                agent,
                "Run echo SANDBOX_AGENT_OK in the shell and tell me the output.",
                run_config=RunConfig(
                    sandbox=SandboxRunConfig(client=sandbox_client),
                ),
            )
            output_str = str(result.final_output)
            ok = "SANDBOX_AGENT_OK" in output_str
            report("SandboxAgent Shell run", ok, f"output={output_str[:300]!r}")
            if not ok:
                failures += 1

        except ImportError as e:
            print(f"  {SKIP} SandboxAgent test skipped: {e}")
        except Exception as e:
            report("SandboxAgent Shell run", False, f"{e}")
            traceback.print_exc()
            failures += 1

        # ----- 8. pty_terminate_all -----
        print("\n=== 8. pty_terminate_all ===")
        try:
            await sandbox_session.pty_terminate_all()
            ok = len(sandbox_session._pty_entries) == 0
            report("pty_terminate_all", ok, f"entries={len(sandbox_session._pty_entries)}")
            if not ok:
                failures += 1
        except Exception as e:
            report("pty_terminate_all", False, f"{e}")
            failures += 1

    finally:
        print("\n=== Cleanup ===")
        try:
            client.close_session()
            print("  Session terminated")
        except Exception as e:
            print(f"  Session cleanup error: {e}")

    print(f"\n{'='*40}")
    if failures == 0:
        print(f"{PASS} ALL TESTS PASSED")
    else:
        print(f"{FAIL} {failures} TEST(S) FAILED")
    return failures


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
