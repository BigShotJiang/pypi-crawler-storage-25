"""
Unit tests for PTY support in InstaVMSandboxSession (openai_agents.py).

Mocks the InstaVM client and websockets — no real API or WS calls.

Run:
    python -m pytest tests/test_agents_pty.py -v
"""

from __future__ import annotations

import asyncio
import json
import uuid
from collections import deque
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from agents.sandbox.manifest import Manifest
from agents.sandbox.session.pty_types import (
    PTY_PROCESSES_MAX,
    PtyExecUpdate,
)
from agents.sandbox.snapshot import resolve_snapshot

from instavm.integrations.openai_agents import (
    DEFAULT_INSTAVM_WORKSPACE_ROOT,
    InstaVMSandboxSession,
    InstaVMSandboxSessionState,
    _RemotePtyEntry,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_state(**overrides) -> InstaVMSandboxSessionState:
    sid = uuid.uuid4()
    defaults = dict(
        session_id=sid,
        manifest=Manifest(root=DEFAULT_INSTAVM_WORKSPACE_ROOT),
        snapshot=resolve_snapshot(None, str(sid)),
        instavm_session_id="ivm-sess-1234",
        base_url="https://api.instavm.io",
    )
    defaults.update(overrides)
    return InstaVMSandboxSessionState(**defaults)


def _make_mock_client() -> MagicMock:
    """InstaVM mock with pty sub-manager."""
    mock = MagicMock()
    mock.session_id = "ivm-sess-1234"
    mock.api_key = "test-key"
    mock.base_url = "https://api.instavm.io"

    # PTY sub-manager
    mock.pty = MagicMock()
    mock.pty.create.return_value = {"session_id": "pty-abc", "active": True, "pid": 99}
    mock.pty.ws_url.return_value = "wss://api.instavm.io/v1/sessions/ivm-sess-1234/pty/pty-abc/connect?api_key=test-key"
    mock.pty.kill.return_value = {"ok": True}

    # Standard client methods
    mock.execute.return_value = {"stdout": "", "stderr": ""}
    mock.kill.return_value = None
    return mock


def _make_session(client=None) -> InstaVMSandboxSession:
    state = _make_state()
    c = client or _make_mock_client()
    return InstaVMSandboxSession(state=state, client=c)


# ---------------------------------------------------------------------------
# supports_pty
# ---------------------------------------------------------------------------


class TestSupportsPty:
    def test_returns_true(self):
        session = _make_session()
        assert session.supports_pty() is True


# ---------------------------------------------------------------------------
# pty_terminate_all
# ---------------------------------------------------------------------------


class TestPtyTerminateAll:
    @pytest.mark.asyncio
    async def test_clears_entries(self):
        session = _make_session()
        # Manually insert a fake entry
        entry = _RemotePtyEntry(pty_id="pty-1", tty=True)
        session._pty_entries[1000] = entry
        session._reserved_pty_ids.add(1000)

        await session.pty_terminate_all()

        assert len(session._pty_entries) == 0
        assert len(session._reserved_pty_ids) == 0

    @pytest.mark.asyncio
    async def test_calls_rest_cleanup(self):
        mock_client = _make_mock_client()
        session = _make_session(client=mock_client)

        entry = _RemotePtyEntry(pty_id="pty-kill-me", tty=True)
        session._pty_entries[2000] = entry
        session._reserved_pty_ids.add(2000)

        await session.pty_terminate_all()
        # The teardown calls pty.kill via _run_in_thread
        mock_client.pty.kill.assert_called()


# ---------------------------------------------------------------------------
# _evict_lru_pty
# ---------------------------------------------------------------------------


class TestEvictLruPty:
    def test_no_eviction_below_capacity(self):
        session = _make_session()
        # Only 1 entry, well below PTY_PROCESSES_MAX
        session._pty_entries[1] = _RemotePtyEntry(pty_id="a", tty=True)
        result = session._evict_lru_pty()
        assert result is None

    def test_evicts_at_capacity(self):
        session = _make_session()
        import time
        for i in range(PTY_PROCESSES_MAX):
            e = _RemotePtyEntry(pty_id=f"pty-{i}", tty=True)
            e.last_used = time.monotonic() + i  # newer entries have higher last_used
            session._pty_entries[i + 1000] = e
            session._reserved_pty_ids.add(i + 1000)

        evicted = session._evict_lru_pty()
        assert evicted is not None
        assert len(session._pty_entries) == PTY_PROCESSES_MAX - 1


# ---------------------------------------------------------------------------
# _RemotePtyEntry dataclass
# ---------------------------------------------------------------------------


class TestRemotePtyEntry:
    def test_defaults(self):
        entry = _RemotePtyEntry(pty_id="test", tty=True)
        assert entry.ws is None
        assert entry.closed is False
        assert entry.exit_code is None
        assert isinstance(entry.output_chunks, deque)
        assert entry.pump_task is None

    def test_output_buffering(self):
        entry = _RemotePtyEntry(pty_id="buf", tty=True)
        entry.output_chunks.append(b"hello ")
        entry.output_chunks.append(b"world")
        combined = b"".join(entry.output_chunks)
        assert combined == b"hello world"


# ---------------------------------------------------------------------------
# _collect_pty_output
# ---------------------------------------------------------------------------


class TestCollectPtyOutput:
    @pytest.mark.asyncio
    async def test_drains_buffered_output(self):
        session = _make_session()
        entry = _RemotePtyEntry(pty_id="col", tty=True)
        entry.output_chunks.append(b"line1\n")
        entry.output_chunks.append(b"line2\n")
        entry.closed = True

        output, token_count = await session._collect_pty_output(
            entry=entry,
            yield_time_ms=250,
            max_output_tokens=None,
        )
        assert b"line1" in output
        assert b"line2" in output

    @pytest.mark.asyncio
    async def test_returns_empty_when_no_data(self):
        session = _make_session()
        entry = _RemotePtyEntry(pty_id="empty", tty=True)
        entry.closed = True

        output, _ = await session._collect_pty_output(
            entry=entry,
            yield_time_ms=250,
            max_output_tokens=None,
        )
        assert output == b""


# ---------------------------------------------------------------------------
# _finalize_pty_update
# ---------------------------------------------------------------------------


class TestFinalizePtyUpdate:
    @pytest.mark.asyncio
    async def test_live_process(self):
        session = _make_session()
        entry = _RemotePtyEntry(pty_id="live", tty=True)
        session._pty_entries[5000] = entry
        session._reserved_pty_ids.add(5000)

        update = await session._finalize_pty_update(
            process_id=5000,
            entry=entry,
            output=b"output",
            original_token_count=None,
        )
        assert isinstance(update, PtyExecUpdate)
        assert update.process_id == 5000  # still alive
        assert update.exit_code is None
        assert update.output == b"output"

    @pytest.mark.asyncio
    async def test_closed_process_removed(self):
        mock_client = _make_mock_client()
        session = _make_session(client=mock_client)
        entry = _RemotePtyEntry(pty_id="done", tty=True)
        entry.closed = True
        entry.exit_code = 0
        session._pty_entries[6000] = entry
        session._reserved_pty_ids.add(6000)

        update = await session._finalize_pty_update(
            process_id=6000,
            entry=entry,
            output=b"bye",
            original_token_count=None,
        )
        assert update.process_id is None  # removed
        assert update.exit_code == 0
        assert 6000 not in session._pty_entries
        assert 6000 not in session._reserved_pty_ids


# ---------------------------------------------------------------------------
# pty_exec_start (mocked WS)
# ---------------------------------------------------------------------------


class TestPtyExecStart:
    @pytest.mark.asyncio
    async def test_creates_pty_and_returns_update(self):
        mock_client = _make_mock_client()
        session = _make_session(client=mock_client)

        # Mock websockets module (lazily imported inside pty_exec_start)
        mock_ws = AsyncMock()
        mock_ws.send = AsyncMock()
        mock_ws.close = AsyncMock()
        # Simulate the WS producing some output then closing
        async def _ws_messages():
            yield b"$ echo hello\r\nhello\r\n"
            yield json.dumps({"type": "exit", "exit_code": 0})

        mock_ws.__aiter__ = lambda self: _ws_messages()
        # Make it callable on the mock itself (not via self)
        mock_ws.__aiter__ = MagicMock(return_value=_ws_messages())

        mock_ws_module = MagicMock()
        mock_ws_module.connect = AsyncMock(return_value=mock_ws)

        with patch.dict("sys.modules", {"websockets": mock_ws_module}):
            update = await session.pty_exec_start(
                "echo", "hello",
                tty=True,
                yield_time_s=1.0,
            )

        assert isinstance(update, PtyExecUpdate)
        mock_client.pty.create.assert_called_once()


# ---------------------------------------------------------------------------
# pty_write_stdin
# ---------------------------------------------------------------------------


class TestPtyWriteStdin:
    @pytest.mark.asyncio
    async def test_write_sends_to_ws(self):
        session = _make_session()

        mock_ws = AsyncMock()
        mock_ws.send = AsyncMock()
        entry = _RemotePtyEntry(pty_id="write-test", tty=True, ws=mock_ws)

        session._pty_entries[7000] = entry
        session._reserved_pty_ids.add(7000)

        update = await session.pty_write_stdin(
            session_id=7000,
            chars="ls\n",
            yield_time_s=0.3,
        )
        assert isinstance(update, PtyExecUpdate)
        mock_ws.send.assert_called_once()

    @pytest.mark.asyncio
    async def test_write_missing_session_raises(self):
        session = _make_session()
        from agents.sandbox.errors import PtySessionNotFoundError

        with pytest.raises(PtySessionNotFoundError):
            await session.pty_write_stdin(
                session_id=99999,
                chars="nope",
            )
