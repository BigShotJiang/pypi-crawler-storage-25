from __future__ import annotations

import pytest

from agentic_base.evaluation.settings import FaissVectorStoreSettings
from agentic_base.exceptions import (
    DatasetSchemaError,
    RerankerHTTPError,
    RerankerResponseFormatError,
    RerankerValidationError,
)


def test_faiss_vector_store_settings_normalizes_string_values() -> None:
    settings = FaissVectorStoreSettings(
        module_path="agentic_base.evaluation.vector_stores.FaissVectorStore",
        index_type="FLAT_IP",
        normalize=True,
    )

    assert settings.index_type == "flat_ip"


def test_faiss_vector_store_settings_rejects_invalid_values() -> None:
    with pytest.raises(ValueError, match="Invalid FAISS index_type"):
        FaissVectorStoreSettings(
            module_path="x",
            index_type="bogus",
            normalize=False,
        )


def test_exceptions_preserve_context() -> None:
    http_error = RerankerHTTPError(503, "unavailable", {"query": "x"})
    validation_error = RerankerValidationError("bad request", {"query": "x"})
    format_error = RerankerResponseFormatError({"bad": "payload"})
    schema_error = DatasetSchemaError({"missing"}, ["a"], ["a.b"])

    assert http_error.status_code == 503
    assert "503" in str(http_error)
    assert validation_error.payload == {"query": "x"}
    assert "Invalid response" in str(format_error)
    assert "Missing columns" in str(schema_error)
