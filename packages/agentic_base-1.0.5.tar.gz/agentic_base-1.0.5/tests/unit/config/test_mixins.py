from __future__ import annotations

from pathlib import Path

import pytest
from pydantic_settings import SettingsConfigDict

from agentic_base.mixins import FromConfigMixin
from agentic_base.settings import FromConfigMixinSettings
from tests.fixtures.fakes import FakeRuntime, FakeRuntimeSettings


def test_from_config_mixin_exposes_config_class() -> None:
    assert FakeRuntime.get_config_class() is FakeRuntimeSettings


def test_from_config_mixin_loads_from_yaml_and_kwargs(tmp_path: Path) -> None:
    config_path = tmp_path / "component.yaml"
    config_path.write_text(
        "component:\n  module_path: tests.fixtures.fakes.FakeRuntime\n  value: 7\n",
        encoding="utf-8",
    )

    runtime = FakeRuntime.from_yaml(str(config_path), key="component")
    runtime_from_kwargs = FakeRuntime.from_kwargs(
        module_path="tests.fixtures.fakes.FakeRuntime",
        value=11,
    )

    assert runtime.config.value == 7
    assert runtime_from_kwargs.config.value == 11


@pytest.mark.asyncio
async def test_from_config_mixin_supports_async_yaml_factory(tmp_path: Path) -> None:
    config_path = tmp_path / "component.yaml"
    config_path.write_text(
        "module_path: tests.fixtures.fakes.FakeRuntime\nvalue: 13\n",
        encoding="utf-8",
    )

    runtime = await FakeRuntime.from_yaml_async(str(config_path))

    assert runtime.config.value == 13


def test_from_settings_uses_pydantic_settings_sources(tmp_path: Path) -> None:
    config_path = tmp_path / "settings.yaml"
    config_path.write_text(
        "module_path: tests.unit.config.test_mixins.LocalRuntime\nvalue: 29\n",
        encoding="utf-8",
    )

    class LocalSettings(FromConfigMixinSettings):
        value: int
        model_config = SettingsConfigDict(yaml_file=str(config_path), extra="ignore")

    class LocalRuntime(FromConfigMixin[LocalSettings]):
        pass

    instance = LocalRuntime.from_settings()

    assert instance.config.value == 29
