from __future__ import annotations

from types import SimpleNamespace

import pytest

from agentic_base.ingestion import TextIngestionPipeline
from tests.fixtures.fakes import (
    FakeDatasetConnector,
    FakeDatasetConnectorSettings,
    FakeTextPreprocessor,
    FakeTextPreprocessorSettings,
)


def test_text_ingestion_pipeline_loads_connector_and_preprocessor(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    dataset_rows = [
        {"page_content": "hello", "metadata": {"doc_id": "1"}},
        {"page_content": "world", "metadata": {"doc_id": "2"}},
    ]

    def fake_load_class(path: str) -> type:
        mapping = {
            "tests.fixtures.fakes.FakeDatasetConnector": FakeDatasetConnector,
            "tests.fixtures.fakes.FakeTextPreprocessor": FakeTextPreprocessor,
        }
        return mapping[path]

    monkeypatch.setattr("agentic_base.ingestion.load_class", fake_load_class)
    pipeline = TextIngestionPipeline(
        SimpleNamespace(
            connector=FakeDatasetConnectorSettings(
                module_path="tests.fixtures.fakes.FakeDatasetConnector",
                rows=dataset_rows,
            ),
            preprocessor=FakeTextPreprocessorSettings(
                module_path="tests.fixtures.fakes.FakeTextPreprocessor",
                suffix="!",
            ),
        )
    )

    ingested = pipeline.ingest()

    assert ingested.polars["page_content"].to_list() == ["hello!", "world!"]
