from __future__ import annotations

from types import SimpleNamespace

import pytest
from langchain_core.documents import Document

from agentic_base.evaluation import VectorStore
from agentic_base.evaluation.retrievers import Retriever
from agentic_base.settings import FromConfigMixinSettings
from tests.fixtures.fakes import ReverseReranker


class DummyRetrieverSettings(FromConfigMixinSettings):
    reranker: object | None = None


class DummyRetriever(Retriever[DummyRetrieverSettings]):
    def __init__(self, config: DummyRetrieverSettings) -> None:
        super().__init__(config)
        self.calls: list[tuple[str, int]] = []

    async def _retrieve(self, query: str, limit: int) -> VectorStore.QueryResponse:
        self.calls.append((query, limit))
        return VectorStore.QueryResponse(
            points=[
                VectorStore.ScoredPoint(
                    score=1.0,
                    document=Document(page_content=query, metadata={}),
                )
            ]
        )


@pytest.mark.asyncio
async def test_retriever_validates_final_limit_usage() -> None:
    retriever = DummyRetriever(DummyRetrieverSettings(module_path="x", reranker=None))

    response = await retriever.retrieve("query", retrieve_limit=2)
    assert response.points[0].document.page_content == "query"

    with pytest.raises(ValueError, match="cannot be used without a reranker"):
        await retriever.retrieve("query", retrieve_limit=2, final_limit=1)


@pytest.mark.asyncio
async def test_retriever_applies_reranker_when_present() -> None:
    reranker = ReverseReranker(SimpleNamespace())
    retriever = DummyRetriever(DummyRetrieverSettings(module_path="x", reranker=None))
    retriever.reranker = reranker

    response = await retriever.retrieve("query", retrieve_limit=2, final_limit=1)

    assert len(response.points) == 1
