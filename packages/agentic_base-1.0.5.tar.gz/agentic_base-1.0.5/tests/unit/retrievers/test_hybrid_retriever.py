from __future__ import annotations

from types import SimpleNamespace

from langchain_core.documents import Document

from agentic_base.evaluation import VectorStore
from agentic_base.evaluation.retrievers.dense.retrievers import HybridRetriever


def _response(*texts: str) -> VectorStore.QueryResponse:
    return VectorStore.QueryResponse(
        points=[
            VectorStore.ScoredPoint(
                score=float(len(text)),
                document=Document(page_content=text, metadata={}),
            )
            for text in texts
        ]
    )


def test_hybrid_retriever_fuses_rankings() -> None:
    retriever = object.__new__(HybridRetriever)
    retriever.config = SimpleNamespace(rrf_k=60)

    fused = retriever._fuse(
        _response("a", "b"),
        _response("b", "c"),
        limit=3,
    )

    assert [point.document.page_content for point in fused.points] == ["b", "a", "c"]
