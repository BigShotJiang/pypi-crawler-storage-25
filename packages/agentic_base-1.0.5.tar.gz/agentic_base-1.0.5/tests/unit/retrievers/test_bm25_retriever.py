from __future__ import annotations

import pytest

from agentic_base.dataset.polars import PolarsTextDataset
from agentic_base.evaluation.retrievers import BM25Retriever


def test_bm25_retriever_returns_best_matching_documents(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    dataset = PolarsTextDataset.from_records(
        [
            ("alpha beta", {"doc_id": "1", "query": "alpha"}),
            ("gamma delta", {"doc_id": "2", "query": "gamma"}),
        ]
    )

    class FakeConnector:
        @classmethod
        def from_config(cls, _config: object) -> FakeConnector:
            return cls()

        def load_text(self) -> PolarsTextDataset:
            return dataset

    monkeypatch.setattr(
        "agentic_base.evaluation.retrievers.load_class",
        lambda path: FakeConnector,
    )
    retriever = BM25Retriever(
        type(
            "Config",
            (),
            {
                "dataset_connector": type("Connector", (), {"module_path": "fake"})(),
                "reranker": None,
            },
        )()
    )

    response = retriever._retrieve_sync("alpha", limit=1)

    assert response.points[0].document.page_content == "alpha beta"
