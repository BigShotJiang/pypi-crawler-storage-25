from __future__ import annotations

from types import SimpleNamespace

import pytest

from agentic_base.evaluation.retrievers.dense import DenseRetriever
from tests.fixtures import fakes


@pytest.mark.asyncio
async def test_dense_retriever_coordinates_embedder_store_and_reranker(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def fake_load_class(path: str) -> type:
        mapping = {
            "tests.fixtures.fakes.RecordingEmbedder": fakes.RecordingEmbedder,
            "tests.fixtures.fakes.EchoVectorStore": fakes.EchoVectorStore,
            "tests.fixtures.fakes.PrefixProcessor": fakes.PrefixProcessor,
            "tests.fixtures.fakes.ReverseReranker": fakes.ReverseReranker,
        }
        return mapping[path]

    monkeypatch.setattr(
        "agentic_base.evaluation.retrievers.dense.load_class",
        fake_load_class,
    )
    config = SimpleNamespace(
        reranker=SimpleNamespace(module_path="tests.fixtures.fakes.ReverseReranker"),
        embedder=SimpleNamespace(
            module_path="tests.fixtures.fakes.RecordingEmbedder",
            model_name="m",
        ),
        vector_store=SimpleNamespace(module_path="tests.fixtures.fakes.EchoVectorStore"),
        processor=SimpleNamespace(
            module_path="tests.fixtures.fakes.PrefixProcessor",
            prefix="p",
        ),
    )
    retriever = DenseRetriever(config)

    batch = await retriever.retrieve_batch(["alpha", "beta"], limit=2, final_limit=1)
    single = await retriever.retrieve("alpha", retrieve_limit=2, final_limit=1)

    assert len(batch) == 2
    assert batch[0].points[0].document.page_content.startswith("doc:")
    assert len(single.points) == 1
