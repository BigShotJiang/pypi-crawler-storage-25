from __future__ import annotations

import pytest

from agentic_base.evaluation.evaluators.python.scores import (
    MRRAtK,
    NDCGAtK,
    PrecisionAtK,
    RecallAtK,
)
from agentic_base.evaluation.settings import (
    MRRAtKScoreSettings,
    NDCGAtKScoreSettings,
    PrecisionAtKScoreSettings,
    RecallAtKScoreSettings,
)
from agentic_base.exceptions import AgenticValueError


def test_scores_compute_expected_values() -> None:
    hits = [True, False, True]

    recall = RecallAtK(RecallAtKScoreSettings(module_path="x", ks=[1, 3]))
    precision = PrecisionAtK(PrecisionAtKScoreSettings(module_path="x", ks=[1, 3]))
    mrr = MRRAtK(MRRAtKScoreSettings(module_path="x", ks=[1, 3]))
    ndcg = NDCGAtK(NDCGAtKScoreSettings(module_path="x", ks=[1, 3]))

    assert [r.value for r in recall(hits, total_relevant=2)] == [0.5, 1.0]
    assert [r.value for r in precision(hits)] == [1.0, 2 / 3]
    assert [r.value for r in mrr(hits)] == [1.0, 1.0]
    assert pytest.approx([r.value for r in ndcg(hits, total_relevant=2)]) == [1.0, 0.9197207891481876]


def test_scores_require_total_relevant_when_needed() -> None:
    recall = RecallAtK(RecallAtKScoreSettings(module_path="x", ks=[1]))
    ndcg = NDCGAtK(NDCGAtKScoreSettings(module_path="x", ks=[1]))

    with pytest.raises(AgenticValueError):
        recall([True])
    with pytest.raises(AgenticValueError):
        ndcg([True])
