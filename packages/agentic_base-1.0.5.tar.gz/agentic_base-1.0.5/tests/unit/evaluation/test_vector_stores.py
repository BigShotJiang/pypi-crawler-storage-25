from __future__ import annotations

import asyncio
from types import SimpleNamespace

import numpy as np
import pytest
from langchain_core.documents import Document

from agentic_base.enums import FAISSIndexType
from agentic_base.evaluation.vector_stores import FaissVectorStore, QdrantVectorStore
from tests.fixtures.fakes import EchoVectorStore, EchoVectorStoreSettings


@pytest.mark.asyncio
async def test_vector_store_query_helpers_wrap_request_objects() -> None:
    store = EchoVectorStore(EchoVectorStoreSettings(module_path="x"))

    batch_responses = await store.abatch_query_points([[1.0], [2.0, 3.0]], limit=4)
    single_response = await store.aquery_points([9.0], limit=2)

    assert [r.points[0].score for r in batch_responses] == [1.0, 5.0]
    assert single_response.points[0].document.metadata == {"limit": 2}


def test_faiss_vector_store_indexes_and_queries_documents() -> None:
    store = FaissVectorStore(SimpleNamespace(index_type=FAISSIndexType.FLAT_IP, normalize=False, module_path="x"))
    embeddings = np.asarray([[1.0, 0.0], [0.0, 1.0]], dtype="float32")
    store.index = store.build_faiss_index(2)
    store.add_documents(
        [
            Document(page_content="x", metadata={}),
            Document(page_content="y", metadata={}),
        ],
        embeddings,
    )

    response = asyncio.run(store._aquery_points_one([1.0, 0.0], limit=1))

    assert response.points[0].document.page_content == "x"


def test_qdrant_vector_store_parses_payloads_and_validates_required_fields() -> None:
    store = object.__new__(QdrantVectorStore)
    store.config = SimpleNamespace(collection_name="docs")

    valid_response = SimpleNamespace(
        points=[
            SimpleNamespace(
                score=0.7,
                payload={"page_content": "hello", "metadata": {"a": 1}},
            )
        ]
    )
    parsed = store._parse_query_response(valid_response)

    assert parsed.points[0].document.page_content == "hello"
    assert parsed.points[0].document.metadata == {"a": 1}

    with pytest.raises(ValueError, match="no payload"):
        store._parse_query_response(SimpleNamespace(points=[SimpleNamespace(score=0.7, payload=None)]))

    with pytest.raises(KeyError, match="page_content"):
        store._parse_query_response(SimpleNamespace(points=[SimpleNamespace(score=0.7, payload={"x": 1})]))
