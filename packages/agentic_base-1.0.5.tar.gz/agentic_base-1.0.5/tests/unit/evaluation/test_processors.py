from __future__ import annotations

from agentic_base.enums import EmbeddingPurposeEnum
from agentic_base.evaluation.processors import NomicProcessor
from agentic_base.evaluation.settings import NomicProcessorSettings


def test_nomic_processor_prefixes_text_by_purpose() -> None:
    processor = NomicProcessor(NomicProcessorSettings(module_path="x"))

    assert processor("doc", EmbeddingPurposeEnum.DOCUMENT) == "search_document: doc"
    assert processor("query", EmbeddingPurposeEnum.QUERY) == "search_query: query"
