from __future__ import annotations

import pytest
from langchain_core.documents import Document

from agentic_base.evaluation.rerankers import HTTPReranker
from agentic_base.evaluation.settings import HTTPRerankerSettings
from agentic_base.exceptions import RerankerHTTPError, RerankerValidationError
from tests.fixtures.fakes import EchoVectorStore


@pytest.mark.asyncio
async def test_http_reranker_batches_and_sorts_results() -> None:
    class FakeResponse:
        status_code = 200
        text = "ok"

        def json(self) -> list[dict[str, float | int]]:
            return [{"index": 1, "score": 0.9}, {"index": 0, "score": 0.1}]

    class FakeClient:
        def __init__(self) -> None:
            self.closed = False

        async def post(self, url: str, json: dict[str, object]) -> FakeResponse:
            return FakeResponse()

        async def aclose(self) -> None:
            self.closed = True

    reranker = HTTPReranker(
        HTTPRerankerSettings(
            module_path="x",
            url="https://rerank.local",
            timeout=1.0,
            max_batch_size=8,
            batch_timeout_ms=5.0,
        )
    )
    reranker.client = FakeClient()
    response = EchoVectorStore.QueryResponse(
        points=[
            EchoVectorStore.ScoredPoint(score=0.0, document=Document(page_content="first", metadata={})),
            EchoVectorStore.ScoredPoint(score=0.0, document=Document(page_content="second", metadata={})),
        ]
    )

    reranked = await reranker.rerank("query", response, limit=2)
    await reranker.aclose()

    assert [point.document.page_content for point in reranked.points] == [
        "second",
        "first",
    ]
    assert reranker.client.closed is True


@pytest.mark.asyncio
async def test_http_reranker_raises_http_and_validation_errors() -> None:
    class ValidationResponse:
        status_code = 422
        text = "invalid"

    class ErrorClient:
        async def post(self, url: str, json: dict[str, object]) -> ValidationResponse:
            return ValidationResponse()

        async def aclose(self) -> None:
            return None

    reranker = HTTPReranker(
        HTTPRerankerSettings(
            module_path="x",
            url="https://rerank.local",
            timeout=1.0,
            max_batch_size=4,
            batch_timeout_ms=1.0,
        )
    )
    reranker.client = ErrorClient()

    with pytest.raises(RerankerValidationError):
        await reranker._batch_fn([("q", "text")])

    class FailingClient:
        async def post(self, url: str, json: dict[str, object]) -> object:
            raise RuntimeError("network down")

        async def aclose(self) -> None:
            return None

    reranker.client = FailingClient()

    with pytest.raises(RerankerHTTPError):
        await reranker._batch_fn([("q", "text")])
