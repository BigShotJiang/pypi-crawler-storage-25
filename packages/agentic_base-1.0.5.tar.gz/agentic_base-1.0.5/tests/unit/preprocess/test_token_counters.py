from __future__ import annotations

from agentic_base.dataset.preprocess.token_counter import HeuristicTokenCounter
from agentic_base.dataset.settings import HeuristicTokenCounterSettings


def _token_counter_settings() -> HeuristicTokenCounterSettings:
    return HeuristicTokenCounterSettings(
        module_path="agentic_base.dataset.preprocess.token_counter.HeuristicTokenCounter",
        chars_per_token=2,
    )


def test_heuristic_token_counter_counts_single_and_batch() -> None:
    counter = HeuristicTokenCounter(_token_counter_settings())

    assert counter.count("abcdef") == 3
    assert counter.count_batch(["ab", "abcdef"]) == [1, 3]
