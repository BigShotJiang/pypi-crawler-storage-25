from __future__ import annotations

import polars as pl

from agentic_base.dataset.polars import PolarsTextDataset
from agentic_base.dataset.preprocess.preprocess import (
    MaxTokenFilter,
    MinTokenFilter,
    PreprocessPipeline,
    QuantileTokenFilter,
    SigmaBandTokenFilter,
)
from agentic_base.dataset.settings import (
    HeuristicTokenCounterSettings,
    MaxTokenFilterSettings,
    MinTokenFilterSettings,
    PreprocessPipelineSettings,
    QuantileTokenFilterSettings,
    SigmaBandTokenFilterSettings,
)


def _text_dataset() -> PolarsTextDataset:
    return PolarsTextDataset.from_polars(
        pl.DataFrame(
            {
                "page_content": ["aa", "bbbb", "cccccc", "dddddddd"],
                "metadata": [{"i": i} for i in range(4)],
            }
        )
    )


def _token_counter_settings() -> HeuristicTokenCounterSettings:
    return HeuristicTokenCounterSettings(
        module_path="agentic_base.dataset.preprocess.token_counter.HeuristicTokenCounter",
        chars_per_token=2,
    )


def test_min_and_max_token_filters_apply_thresholds() -> None:
    dataset = _text_dataset()
    min_filter = MinTokenFilter(
        MinTokenFilterSettings(
            module_path="agentic_base.dataset.preprocess.preprocess.MinTokenFilter",
            kind="min_tokens",
            min_tokens=2,
            token_counter=_token_counter_settings(),
        )
    )
    max_filter = MaxTokenFilter(
        MaxTokenFilterSettings(
            module_path="agentic_base.dataset.preprocess.preprocess.MaxTokenFilter",
            kind="max_tokens",
            max_tokens=2,
            token_counter=_token_counter_settings(),
        )
    )

    assert min_filter.apply(dataset).polars["page_content"].to_list() == [
        "bbbb",
        "cccccc",
        "dddddddd",
    ]
    assert max_filter.apply(dataset).polars["page_content"].to_list() == [
        "aa",
        "bbbb",
    ]


def test_quantile_and_sigma_filters_reduce_dataset() -> None:
    dataset = _text_dataset()
    quantile_filter = QuantileTokenFilter(
        QuantileTokenFilterSettings(
            module_path="agentic_base.dataset.preprocess.preprocess.QuantileTokenFilter",
            kind="quantile",
            q=0.5,
            token_counter=_token_counter_settings(),
        )
    )
    sigma_filter = SigmaBandTokenFilter(
        SigmaBandTokenFilterSettings(
            module_path="agentic_base.dataset.preprocess.preprocess.SigmaBandTokenFilter",
            kind="sigma",
            z=0.8,
            token_counter=_token_counter_settings(),
        )
    )

    assert quantile_filter.apply(dataset).polars["page_content"].to_list() == [
        "aa",
        "bbbb",
        "cccccc",
    ]
    assert sigma_filter.apply(dataset).polars["page_content"].to_list() == [
        "bbbb",
        "cccccc",
    ]


def test_preprocess_pipeline_applies_steps_in_order() -> None:
    dataset = _text_dataset()
    pipeline = PreprocessPipeline(
        PreprocessPipelineSettings(
            module_path="agentic_base.dataset.preprocess.preprocess.PreprocessPipeline",
            kind="steps",
            steps=[
                MinTokenFilterSettings(
                    module_path="agentic_base.dataset.preprocess.preprocess.MinTokenFilter",
                    kind="min_tokens",
                    min_tokens=2,
                    token_counter=_token_counter_settings(),
                ),
                MaxTokenFilterSettings(
                    module_path="agentic_base.dataset.preprocess.preprocess.MaxTokenFilter",
                    kind="max_tokens",
                    max_tokens=3,
                    token_counter=_token_counter_settings(),
                ),
            ],
        )
    )

    assert pipeline.apply(dataset).polars["page_content"].to_list() == [
        "bbbb",
        "cccccc",
    ]
