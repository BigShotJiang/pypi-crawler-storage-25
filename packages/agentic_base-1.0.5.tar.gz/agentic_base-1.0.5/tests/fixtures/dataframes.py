from __future__ import annotations

import polars as pl
import pytest


@pytest.fixture
def sample_text_df() -> pl.DataFrame:
    return pl.DataFrame(
        {
            "page_content": ["alpha", "beta beta", "gamma gamma gamma"],
            "metadata": [
                {"doc_id": "a", "query": "alpha"},
                {"doc_id": "b", "query": "beta"},
                {"doc_id": "c", "query": "gamma"},
            ],
        }
    )


@pytest.fixture
def sample_nested_df() -> pl.DataFrame:
    return pl.DataFrame(
        {
            "page_content": ["hello", "world"],
            "metadata": [
                {"query": "q1", "doc_id": "d1"},
                {"query": "q2", "doc_id": "d2"},
            ],
            "payload": [
                {"nested": {"label": "x"}},
                {"nested": {"label": "y"}},
            ],
        }
    )
