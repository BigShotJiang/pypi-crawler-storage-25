from __future__ import annotations

from typing import Any

import polars as pl
from langchain_core.documents import Document

from agentic_base.connector import DatasetConnector
from agentic_base.connector.settings import DatasetConnectorSettings
from agentic_base.dataset.polars import PolarsTextDataset
from agentic_base.dataset.preprocess import TextPreprocessor
from agentic_base.dataset.settings import TextPreprocessorSettings
from agentic_base.enums import EmbeddingPurposeEnum
from agentic_base.evaluation import Embedder, Processor, Reranker, VectorStore
from agentic_base.evaluation.settings import (
    EmbedderSettings,
    ProcessorSettings,
    RerankerSettings,
    VectorStoreSettings,
)
from agentic_base.mixins import FromConfigMixin
from agentic_base.settings import FromConfigMixinSettings


class FakeRuntimeSettings(FromConfigMixinSettings):
    value: int


class FakeRuntime(FromConfigMixin[FakeRuntimeSettings]):
    pass


class FakeDatasetConnectorSettings(DatasetConnectorSettings):
    rows: list[dict[str, Any]]


class FakeDatasetConnector(DatasetConnector[FakeDatasetConnectorSettings]):
    last_written: pl.DataFrame | None = None

    def _load(self) -> pl.DataFrame:
        return pl.DataFrame(self.config.rows)

    def to(self, ds: Any) -> None:
        self.__class__.last_written = ds.polars


class FakeTextPreprocessorSettings(TextPreprocessorSettings):
    kind: str = "suffix"
    suffix: str


class FakeTextPreprocessor(TextPreprocessor[FakeTextPreprocessorSettings]):
    def apply(self, ds: PolarsTextDataset) -> PolarsTextDataset:
        return ds.__class__.from_polars(
            ds.polars.with_columns((pl.col("page_content") + self.config.suffix).alias("page_content"))
        )


class PrefixProcessorSettings(ProcessorSettings):
    prefix: str


class PrefixProcessor(Processor[PrefixProcessorSettings]):
    def __call__(self, text: str, purpose: EmbeddingPurposeEnum) -> str:
        return f"{purpose}:{self.config.prefix}:{text}"


class RecordingEmbedderSettings(EmbedderSettings):
    pass


class RecordingEmbedder(Embedder[RecordingEmbedderSettings]):
    def __init__(self, config: RecordingEmbedderSettings) -> None:
        super().__init__(config)
        self.calls: list[list[str]] = []

    async def _aembed(self, texts: list[str]) -> list[list[float]]:
        self.calls.append(texts)
        return [[float(len(text))] for text in texts]


class EchoVectorStoreSettings(VectorStoreSettings):
    pass


class EchoVectorStore(VectorStore[EchoVectorStoreSettings]):
    def __init__(self, config: EchoVectorStoreSettings) -> None:
        super().__init__(config)
        self.calls: list[list[VectorStore.VectorQuery]] = []

    async def _abatch_query_points(
        self,
        requests: list[VectorStore.VectorQuery],
    ) -> list[VectorStore.QueryResponse]:
        self.calls.append(requests)
        return [
            VectorStore.QueryResponse(
                points=[
                    VectorStore.ScoredPoint(
                        score=float(sum(request.vector)),
                        document=Document(
                            page_content=f"doc:{request.vector}",
                            metadata={"limit": request.limit},
                        ),
                    )
                ]
            )
            for request in requests
        ]


class ReverseRerankerSettings(RerankerSettings):
    pass


class ReverseReranker(Reranker[ReverseRerankerSettings]):
    async def rerank(
        self,
        query: str,
        response: VectorStore.QueryResponse,
        limit: int,
    ) -> VectorStore.QueryResponse:
        return VectorStore.QueryResponse(points=list(reversed(response.points))[:limit])
