from __future__ import annotations

import importlib
import sys
from types import ModuleType, SimpleNamespace

import polars as pl
import pytest

from agentic_base.exceptions import DatasetSchemaError


def test_huggingface_adapter_converts_polars_dataset(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake_datasets = ModuleType("datasets")

    class FakeHFDataset:
        @staticmethod
        def from_dict(data: dict[str, list[object]]) -> dict[str, list[object]]:
            return data

    fake_datasets.Dataset = FakeHFDataset
    monkeypatch.setitem(sys.modules, "datasets", fake_datasets)
    sys.modules.pop("agentic_base.dataset.hf", None)

    hf_module = importlib.import_module("agentic_base.dataset.hf")
    from agentic_base.dataset.polars import PolarsTextDataset

    class FakeConnector:
        @classmethod
        def from_config(cls, _config: object) -> FakeConnector:
            return cls()

        def load_text(self) -> PolarsTextDataset:
            return PolarsTextDataset.from_polars(
                pl.DataFrame(
                    {
                        "page_content": ["hello"],
                        "metadata": [{"query": "q1", "doc_id": "d1"}],
                    }
                )
            )

    monkeypatch.setattr(hf_module, "load_class", lambda path: FakeConnector)

    settings = SimpleNamespace(
        connector=SimpleNamespace(module_path="fake.connector"),
        columns_mapping={"text": "page_content", "query": "metadata.query"},
    )
    adapter = hf_module.HuggingFaceDatasetAdaptater(settings)

    assert adapter.to_hf() == {"text": ["hello"], "query": ["q1"]}


def test_huggingface_adapter_raises_schema_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake_datasets = ModuleType("datasets")
    fake_datasets.Dataset = type(
        "FakeHFDataset",
        (),
        {"from_dict": staticmethod(dict)},
    )
    monkeypatch.setitem(sys.modules, "datasets", fake_datasets)
    sys.modules.pop("agentic_base.dataset.hf", None)

    hf_module = importlib.import_module("agentic_base.dataset.hf")
    from agentic_base.dataset.polars import PolarsTextDataset

    class FakeConnector:
        @classmethod
        def from_config(cls, _config: object) -> FakeConnector:
            return cls()

        def load_text(self) -> PolarsTextDataset:
            return PolarsTextDataset.from_polars(
                pl.DataFrame(
                    {
                        "page_content": ["hello"],
                        "metadata": [{"query": "q1"}],
                    }
                )
            )

    monkeypatch.setattr(hf_module, "load_class", lambda path: FakeConnector)

    settings = SimpleNamespace(
        connector=SimpleNamespace(module_path="fake.connector"),
        columns_mapping={"label": "payload.label"},
    )
    adapter = hf_module.HuggingFaceDatasetAdaptater(settings)

    with pytest.raises(DatasetSchemaError):
        adapter.to_hf()
