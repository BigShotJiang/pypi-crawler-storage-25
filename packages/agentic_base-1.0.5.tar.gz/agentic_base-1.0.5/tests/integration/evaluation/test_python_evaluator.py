from __future__ import annotations

from types import SimpleNamespace

from langchain_core.documents import Document

from agentic_base.dataset.polars import PolarsTextDataset
from agentic_base.evaluation import VectorStore
from agentic_base.evaluation.evaluators.python import PythonEvaluator
from agentic_base.evaluation.evaluators.python.evaluators import FaissPythonEvaluator


def _response(*texts: str) -> VectorStore.QueryResponse:
    return VectorStore.QueryResponse(
        points=[
            VectorStore.ScoredPoint(
                score=float(len(text)),
                document=Document(page_content=text, metadata={}),
            )
            for text in texts
        ]
    )


def test_python_evaluator_helpers_aggregate_scores(sample_text_df) -> None:
    evaluator = object.__new__(PythonEvaluator)
    evaluator.dataset = PolarsTextDataset.from_polars(sample_text_df)
    evaluator.scores = [lambda hits, total_relevant=None: [SimpleNamespace(name="metric", value=float(sum(hits)))]]
    evaluator.NB_LOGS_PER_QUERIES = 100
    evaluator.BATCH_SIZE = 2
    evaluator.config = SimpleNamespace(limit=2, retriever=SimpleNamespace(reranker=None))

    batches = list(evaluator.batch_iter())
    scores_all = evaluator._score_batches(
        [batches[0]],
        [[_response("alpha"), _response("beta beta")]],
    )
    aggregated = evaluator._aggregate_scores(scores_all)

    assert len(batches) == 2
    assert aggregated == {"metric": 1.0}


def test_faiss_python_evaluator_extracts_unique_documents(sample_text_df) -> None:
    evaluator = object.__new__(FaissPythonEvaluator)
    evaluator.dataset = PolarsTextDataset.from_polars(sample_text_df.vstack(sample_text_df.head(1)))

    docs = evaluator.get_docs()

    assert [doc.metadata["doc_id"] for doc in docs] == ["a", "b", "c"]
