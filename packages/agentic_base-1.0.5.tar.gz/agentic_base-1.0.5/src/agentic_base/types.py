from typing import TYPE_CHECKING, Any, Literal, TypeVar

import polars as pl

if TYPE_CHECKING:
    from agentic_base.connector.settings import DatasetConnectorSettings
    from agentic_base.dataset.settings import (
        HuggingFaceDatasetAdaptaterSettings,
        TextPreprocessorSettings,
        TokenCounterSettings,
    )
    from agentic_base.evaluation.settings import (
        DenseRetrieverSettings,
        EmbedderSettings,
        EvaluatorSettings,
        FaissEvaluatorSettings,
        HybridRetrieverSettings,
        ProcessorSettings,
        PythonEvaluatorSettings,
        RerankerSettings,
        RetrieverSettings,
        ScoreSettings,
        VectorStoreSettings,
    )
    from agentic_base.ingestion.settings import TextIngestionPipelineSettings
    from agentic_base.settings import FromConfigMixinSettings

TDataset = TypeVar("TDataset")
type ParquetCompression = Literal["lz4", "uncompressed", "snappy", "gzip", "brotli", "zstd"]
TCFromConfigMixin = TypeVar("TCFromConfigMixin", bound="FromConfigMixinSettings")
TCHFDatasetAdaptater = TypeVar("TCHFDatasetAdaptater", bound="HuggingFaceDatasetAdaptaterSettings")
TCEmbedder = TypeVar("TCEmbedder", bound="EmbedderSettings")
TCEvaluator = TypeVar("TCEvaluator", bound="EvaluatorSettings")
TCPythonEvaluator = TypeVar("TCPythonEvaluator", bound="PythonEvaluatorSettings")
TCPythonDenseEvaluator = TypeVar(
    "TCPythonDenseEvaluator",
    bound="PythonEvaluatorSettings[Any, DenseRetrieverSettings[Any, Any, Any, Any]]",
)
TCProcessor = TypeVar("TCProcessor", bound="ProcessorSettings")
TCRetriever = TypeVar("TCRetriever", bound="RetrieverSettings")
TCDenseRetriever = TypeVar("TCDenseRetriever", bound="DenseRetrieverSettings")
TCHybridRetriever = TypeVar("TCHybridRetriever", bound="HybridRetrieverSettings[Any, Any, Any]")
TCReranker = TypeVar("TCReranker", bound="RerankerSettings")
TCFaissEvaluator = TypeVar("TCFaissEvaluator", bound="FaissEvaluatorSettings[Any]")
TCScore = TypeVar("TCScore", bound="ScoreSettings")
TCVectorStore = TypeVar("TCVectorStore", bound="VectorStoreSettings")
TCTextPreprocessor = TypeVar("TCTextPreprocessor", bound="TextPreprocessorSettings")
TCTokenCounter = TypeVar("TCTokenCounter", bound="TokenCounterSettings")
TCDatasetConnector = TypeVar("TCDatasetConnector", bound="DatasetConnectorSettings")
TCTextIngestionPipeline = TypeVar("TCTextIngestionPipeline", bound="TextIngestionPipelineSettings")
InputT = TypeVar("InputT")
OutputT = TypeVar("OutputT")


SchemaLike = dict[str, pl.DataType] | list[pl.Field]
