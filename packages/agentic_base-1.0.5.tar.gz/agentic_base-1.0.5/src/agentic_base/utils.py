import importlib
from pathlib import Path
from typing import TYPE_CHECKING, Any

import polars as pl
import yaml
from pydantic import SecretStr

from agentic_base.mixins import FromConfigMixin

if TYPE_CHECKING:
    from agentic_base.connector.minio import MinioDatasetConnector
    from agentic_base.connector.parquet import ParquetDatasetConnector


def load_class(path: str) -> Any:
    module_path, class_name = path.rsplit(".", 1)
    module = importlib.import_module(module_path)
    return getattr(module, class_name)


def _get_minio_connector(
    bucket: str, key: str, endpoint: str, access_key: str, secret_key: str
) -> "MinioDatasetConnector":
    from agentic_base.connector.minio import MinioDatasetConnector
    from agentic_base.connector.settings import MinioDatasetConnectorSettings

    config = MinioDatasetConnectorSettings(
        module_path="",
        endpoint=endpoint,
        bucket=bucket,
        key=key,
        access_key=SecretStr(access_key),
        secret_key=SecretStr(secret_key),
    )
    return MinioDatasetConnector(config)


def _get_parquet_connector(path: str, *, lazy: bool) -> "ParquetDatasetConnector":
    from agentic_base.connector.parquet import ParquetDatasetConnector
    from agentic_base.connector.settings import ParquetDatasetConnectorSettings

    config = ParquetDatasetConnectorSettings(module_path="", path=path, lazy=lazy)
    return ParquetDatasetConnector(config)


def extract_schema_columns(
    schema: dict[str, pl.DataType] | list[pl.Field],
    prefix: str = "",
) -> list[str]:
    cols: list[str] = []
    if isinstance(schema, dict):
        items = schema.items()
    else:
        items = ((field.name, field.dtype) for field in schema)  # type: ignore[assignment]
    for name, dtype in items:
        full_name = f"{prefix}.{name}" if prefix else name

        if isinstance(dtype, pl.Struct):
            nested = extract_schema_columns(dtype.fields, full_name)
            cols.extend(nested)
        else:
            cols.append(full_name)
    return cols


def resolve_column(path: str) -> pl.Expr:
    parts = path.split(".")

    expr = pl.col(parts[0])
    for p in parts[1:]:
        expr = expr.struct.field(p)

    return expr


def build_schema(
    df: pl.DataFrame,
    schema: dict[str, str],
) -> pl.DataFrame:
    exprs = []

    for target_col, source_path in schema.items():
        expr = resolve_column(source_path).alias(target_col)
        exprs.append(expr)

    return df.select(exprs)


def comp(
    path: str,
    key: str | None = None,
) -> FromConfigMixin[Any]:
    """
    Generic factory:
    - loads YAML
    - resolves module_path
    - instantiates component via FromConfigMixin
    """
    yaml_path = Path(path)
    with yaml_path.open("r") as f:
        raw: dict[str, Any] = yaml.safe_load(f)
    if key is not None:
        raw = raw[key]
    module_path = raw.pop("module_path")
    cls: type[FromConfigMixin[Any]] = load_class(module_path)
    return cls.from_yaml(path, key=key)
