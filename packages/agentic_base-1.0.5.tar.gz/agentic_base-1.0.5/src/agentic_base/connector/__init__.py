import logging
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

import polars as pl

from agentic_base.mixins import FromConfigMixin
from agentic_base.types import TCDatasetConnector as TCDatasetConnector

if TYPE_CHECKING:
    from agentic_base.dataset import Dataset, TextDataset

_logger = logging.getLogger(__name__)


class DatasetConnector[TCDatasetConnector](
    FromConfigMixin[TCDatasetConnector],
    ABC,
):
    def __init__(self, config: TCDatasetConnector):
        super().__init__(config)

        _logger.info(
            f"Initializing dataset connector | class={self.__class__.__name__} | module={self.__class__.__module__}"
        )

    @abstractmethod
    def _load(self) -> pl.DataFrame | pl.LazyFrame:
        """
        Load raw data as Polars DataFrame or LazyFrame.
        """
        raise NotImplementedError()

    @abstractmethod
    def to(self, ds: "Dataset[Any]") -> None:
        raise NotImplementedError()

    def load(self) -> "Dataset[pl.DataFrame | pl.LazyFrame]":
        from agentic_base.dataset.polars import PolarsDataset

        _logger.info(f"Loading dataset | connector={self.__class__.__name__}")

        df = self._load()
        self._log_polars_info(df)

        return PolarsDataset.from_polars(df)

    def load_text(self) -> "TextDataset[pl.DataFrame | pl.LazyFrame]":
        from agentic_base.dataset.polars import PolarsTextDataset

        _logger.info(f"Loading text dataset | connector={self.__class__.__name__}")

        df = self._load()
        self._log_polars_info(df)

        return PolarsTextDataset.from_polars(df)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _log_polars_info(self, df: pl.DataFrame | pl.LazyFrame) -> None:
        """
        Log dataset structure without forcing materialization.
        """
        if isinstance(df, pl.DataFrame):
            schema = df.schema
            _logger.info(f"Loaded DataFrame | columns={len(schema)} | schema={list(schema.items())}")
