from enum import StrEnum


class EmbeddingPurposeEnum(StrEnum):
    DOCUMENT = "document"
    QUERY = "query"


class FAISSIndexType(StrEnum):
    FLAT_IP = "flat_ip"
    FLAT_L2 = "flat_l2"
