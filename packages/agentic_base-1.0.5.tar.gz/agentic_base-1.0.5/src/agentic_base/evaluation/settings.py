from typing import Any

from pydantic import field_validator

from agentic_base.connector.settings import MinioDatasetConnectorSettings
from agentic_base.enums import FAISSIndexType
from agentic_base.settings import FromConfigMixinSettings
from agentic_base.types import TCDatasetConnector as TCDatasetConnector
from agentic_base.types import TCDenseRetriever as TCDenseRetriever
from agentic_base.types import TCEmbedder as TCEmbedder
from agentic_base.types import TCProcessor as TCProcessor
from agentic_base.types import TCReranker as TCReranker
from agentic_base.types import TCRetriever as TCRetriever
from agentic_base.types import TCVectorStore as TCVectorStore


class EmbedderSettings(FromConfigMixinSettings):
    model_name: str


class OpenAICompatibleEmbedderSettings(EmbedderSettings):
    base_url: str


class ProcessorSettings(FromConfigMixinSettings):
    pass


class NomicProcessorSettings(ProcessorSettings):
    pass


class ScoreSettings(FromConfigMixinSettings):
    ks: list[int]


class RecallAtKScoreSettings(ScoreSettings):
    pass


class PrecisionAtKScoreSettings(ScoreSettings):
    pass


class MRRAtKScoreSettings(ScoreSettings):
    pass


class NDCGAtKScoreSettings(ScoreSettings):
    pass


class VectorStoreSettings(FromConfigMixinSettings):
    pass


class QdrantVectorStoreSettings(VectorStoreSettings):
    url: str
    collection_name: str
    timeout: int | None


class FaissVectorStoreSettings(VectorStoreSettings):
    index_type: FAISSIndexType
    normalize: bool

    @field_validator("index_type", mode="before")
    @classmethod
    def normalize_index_type(cls, v: Any) -> FAISSIndexType:
        if isinstance(v, FAISSIndexType):
            return v
        if isinstance(v, str):
            try:
                return FAISSIndexType(v.lower())
            except ValueError as e:
                raise ValueError(f"Invalid FAISS index_type '{v}'.") from e
        raise TypeError(f"index_type must be a string or FAISSIndexType, got {type(v).__name__}")


class RerankerSettings(FromConfigMixinSettings):
    pass


class HFRerankerSettings(RerankerSettings):
    model_name: str
    revision: str | None
    device: str


class HTTPRerankerSettings(RerankerSettings):
    url: str
    timeout: float
    max_batch_size: int
    batch_timeout_ms: float


class RetrieverSettings[TCReranker](FromConfigMixinSettings):
    reranker: TCReranker | None


class BM25RetrieverSettings[TCDatasetConnector, TCReranker](
    RetrieverSettings[TCReranker],
):
    dataset_connector: TCDatasetConnector


class DenseRetrieverSettings[TCEmbedder, TCVectorStore, TCProcessor, TCReranker](
    RetrieverSettings[TCReranker],
):
    embedder: TCEmbedder
    vector_store: TCVectorStore
    processor: TCProcessor


class HybridRetrieverSettings[TCDenseRetriever, TCDatasetConnector, TCReranker](
    RetrieverSettings[TCReranker],
):
    dense_retriever: TCDenseRetriever
    bm25_retriever: BM25RetrieverSettings[TCDatasetConnector, TCReranker]
    rrf_k: int


class BM25QdrantVLLMHybridRetrieverSettings(
    HybridRetrieverSettings[
        DenseRetrieverSettings[
            OpenAICompatibleEmbedderSettings,
            QdrantVectorStoreSettings,
            NomicProcessorSettings,
            RerankerSettings,
        ],
        MinioDatasetConnectorSettings,
        RerankerSettings,
    ]
):
    pass


class EvaluatorSettings[TCDatasetConnector, TCRetriever](FromConfigMixinSettings):
    dataset_connector: TCDatasetConnector
    retriever: TCRetriever


class PythonEvaluatorSettings[TCDatasetConnector, TCRetriever](
    EvaluatorSettings[TCDatasetConnector, TCRetriever],
):
    scores: list[ScoreSettings]
    limit: int


class QdrantEvaluatorSettings(
    PythonEvaluatorSettings[
        MinioDatasetConnectorSettings,
        DenseRetrieverSettings[
            OpenAICompatibleEmbedderSettings,
            QdrantVectorStoreSettings,
            NomicProcessorSettings,
            RerankerSettings,
        ],
    ]
):
    pass


class FaissEvaluatorSettings[TCEmbedder](
    PythonEvaluatorSettings[
        MinioDatasetConnectorSettings,
        DenseRetrieverSettings[
            TCEmbedder,
            FaissVectorStoreSettings,
            NomicProcessorSettings,
            RerankerSettings,
        ],
    ],
):
    pass


class BM25EvaluatorSettings(
    PythonEvaluatorSettings[
        MinioDatasetConnectorSettings,
        BM25RetrieverSettings[MinioDatasetConnectorSettings, RerankerSettings],
    ]
):
    pass


class HybridRetrieverEvaluatorSettings(
    PythonEvaluatorSettings[
        MinioDatasetConnectorSettings,
        BM25QdrantVLLMHybridRetrieverSettings,
    ]
):
    pass
