from agentic_base.enums import EmbeddingPurposeEnum
from agentic_base.evaluation import Processor
from agentic_base.evaluation.settings import NomicProcessorSettings


class NomicProcessor(Processor[NomicProcessorSettings]):
    def __init__(self, config: NomicProcessorSettings) -> None:
        super().__init__(config)

    def __call__(self, text: str, purpose: EmbeddingPurposeEnum) -> str:
        if purpose == EmbeddingPurposeEnum.DOCUMENT:
            return f"search_document: {text}"
        if purpose == EmbeddingPurposeEnum.QUERY:
            return f"search_query: {text}"
        raise ValueError(f"Unsupported embedding purpose {purpose}")
