from openai import AsyncOpenAI

from agentic_base.evaluation import Embedder
from agentic_base.evaluation.settings import OpenAICompatibleEmbedderSettings


class OpenAICompatibleEmbedder(Embedder[OpenAICompatibleEmbedderSettings]):
    def __init__(self, config: OpenAICompatibleEmbedderSettings):
        super().__init__(config)
        self.client = AsyncOpenAI(
            base_url=self.config.base_url,
        )

    async def _aembed(self, texts: list[str]) -> list[list[float]]:
        """
        Works with:
        - vLLM
        - TEI (/v1/embeddings)
        - OpenAI
        """

        response = await self.client.embeddings.create(
            model=self.config.model_name,
            input=texts,
        )

        # Preserve order
        return [item.embedding for item in response.data]
