import logging
from abc import ABC, abstractmethod
from typing import Any

from agentic_base.dataset import TextDataset
from agentic_base.evaluation.retrievers import Retriever
from agentic_base.mixins import FromConfigMixin
from agentic_base.types import TCEvaluator as TCEvaluator
from agentic_base.utils import load_class

_logger = logging.getLogger(__name__)


class Evaluator[TCEvaluator](FromConfigMixin[TCEvaluator], ABC):
    NB_LOGS_PER_QUERIES = 100
    BATCH_SIZE = 96

    def __init__(self, config: TCEvaluator) -> None:
        super().__init__(config)
        _logger.info(f"Initializing Evaluator | class={self.__class__.__name__}")
        self.dataset: TextDataset[Any] = self._load_dataset()
        self.retriever: Retriever[Any] = load_class(self.config.retriever.module_path).from_config(
            self.config.retriever
        )
        _logger.info(f"{self.retriever.__class__.__name__} loaded ")

    def _load_dataset(self) -> TextDataset[Any]:
        dataset: TextDataset[Any] = (
            load_class(self.config.dataset_connector.module_path).from_config(self.config.dataset_connector).load_text()
        )
        _logger.info(f"Dataset loaded | size={len(dataset)}")
        return dataset

    @abstractmethod
    async def eval(self) -> dict[str, float]:
        raise NotImplementedError()
