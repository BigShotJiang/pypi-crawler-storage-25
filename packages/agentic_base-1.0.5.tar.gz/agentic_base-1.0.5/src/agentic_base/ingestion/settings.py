from agentic_base.settings import FromConfigMixinSettings
from agentic_base.types import TCDatasetConnector as TCDatasetConnector
from agentic_base.types import TCTextPreprocessor as TCTextPreprocessor


class TextIngestionPipelineSettings[TCDatasetConnector, TCTextPreprocessor](FromConfigMixinSettings):
    connector: TCDatasetConnector
    preprocessor: TCTextPreprocessor
