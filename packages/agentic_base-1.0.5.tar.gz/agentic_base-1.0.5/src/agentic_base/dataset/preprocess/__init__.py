from abc import ABC, abstractmethod
from typing import Any

from agentic_base.dataset.polars import TextDataset
from agentic_base.mixins import FromConfigMixin
from agentic_base.types import TCTextPreprocessor as TCTextPreprocessor
from agentic_base.types import TCTokenCounter as TCTokenCounter


class TextPreprocessor[TCTextPreprocessor](FromConfigMixin[TCTextPreprocessor], ABC):
    def __init__(self, config: TCTextPreprocessor) -> None:
        self.config = config

    @abstractmethod
    def apply(self, ds: TextDataset[Any]) -> TextDataset[Any]:
        raise NotImplementedError


class TokenCounter[TCTokenCounter](FromConfigMixin[TCTokenCounter], ABC):
    def __init__(self, config: TCTokenCounter) -> None:
        self.config = config

    @abstractmethod
    def count(self, text: str) -> int:
        raise NotImplementedError()

    def count_batch(self, texts: list[str]) -> list[int]:
        return [self.count(t) for t in texts]
