from typing import Literal

from agentic_base.settings import FromConfigMixinSettings


class TextPreprocessorSettings(FromConfigMixinSettings):
    kind: str


class TokenCounterSettings(FromConfigMixinSettings):
    pass


class HeuristicTokenCounterSettings(TokenCounterSettings):
    chars_per_token: int


class HuggingFaceTokenCounterSettings(TokenCounterSettings):
    name: str
    add_special_tokens: bool
    revision: str | None


class TokenFilterSettings[TCTokenCounter](TextPreprocessorSettings):
    token_counter: TCTokenCounter


class MinTokenFilterSettings[TCTokenCounter](TokenFilterSettings[TCTokenCounter]):
    kind: Literal["min_tokens"]
    min_tokens: int


class MaxTokenFilterSettings[TCTokenCounter](TokenFilterSettings[TCTokenCounter]):
    kind: Literal["max_tokens"]
    max_tokens: int


class QuantileTokenFilterSettings[TCTokenCounter](TokenFilterSettings[TCTokenCounter]):
    kind: Literal["quantile"]
    q: float


class SigmaBandTokenFilterSettings[TCTokenCounter](TokenFilterSettings[TCTokenCounter]):
    kind: Literal["sigma"]
    z: float


BaseTextPreprocessorUnion = (
    MinTokenFilterSettings[HuggingFaceTokenCounterSettings]
    | MaxTokenFilterSettings[HuggingFaceTokenCounterSettings]
    | QuantileTokenFilterSettings[HuggingFaceTokenCounterSettings]
    | SigmaBandTokenFilterSettings[HuggingFaceTokenCounterSettings]
)


class PreprocessPipelineSettings[TCTextPreprocessor](TextPreprocessorSettings):
    kind: Literal["steps"]
    steps: list[TCTextPreprocessor]


class HuggingFaceDatasetAdaptaterSettings[TCDatasetConnector](FromConfigMixinSettings):
    connector: TCDatasetConnector
    columns_mapping: dict[str, str]
