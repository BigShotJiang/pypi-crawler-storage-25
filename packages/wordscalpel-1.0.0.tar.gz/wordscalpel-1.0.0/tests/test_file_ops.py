import pytest
import os
import sys
import tempfile
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from wordscalpel.file_ops import process_file, file_count_occurrences, file_get_positions
from wordscalpel.exceptions import EmptyInputError, OccurrenceNotFoundError


@pytest.fixture
def sample_file(tmp_path):
    f = tmp_path / "sample.txt"
    f.write_text("the quick brown fox jumps over the lazy dog and the fox ran away")
    return str(f)


@pytest.fixture
def output_file(tmp_path):
    return str(tmp_path / "output.txt")


class TestProcessFile:
    def test_remove_nth(self, sample_file, output_file):
        result = process_file(sample_file, output_file, "the", n=2, operation="remove")
        assert result["original_count"] == 3
        assert result["result_count"] == 2

    def test_remove_all(self, sample_file, output_file):
        result = process_file(sample_file, output_file, "the", operation="remove")
        assert result["result_count"] == 0

    def test_replace_nth(self, sample_file, output_file):
        result = process_file(sample_file, output_file, "fox", n=1, operation="replace", replacement="cat")
        content = open(output_file).read()
        assert "cat" in content

    def test_replace_all(self, sample_file, output_file):
        result = process_file(sample_file, output_file, "fox", operation="replace", replacement="cat")
        content = open(output_file).read()
        assert "fox" not in content
        assert content.count("cat") == 2

    def test_file_not_found(self, output_file):
        with pytest.raises(FileNotFoundError):
            process_file("nonexistent.txt", output_file, "word")

    def test_empty_file_raises(self, tmp_path, output_file):
        empty = tmp_path / "empty.txt"
        empty.write_text("")
        with pytest.raises(EmptyInputError):
            process_file(str(empty), output_file, "word")

    def test_unknown_operation(self, sample_file, output_file):
        with pytest.raises(ValueError):
            process_file(sample_file, output_file, "the", operation="explode")


class TestFileCountOccurrences:
    def test_count(self, sample_file):
        assert file_count_occurrences(sample_file, "the") == 3

    def test_count_zero(self, sample_file):
        assert file_count_occurrences(sample_file, "xyz") == 0

    def test_case_insensitive(self, tmp_path):
        f = tmp_path / "mixed.txt"
        f.write_text("The the THE")
        assert file_count_occurrences(str(f), "the", case_sensitive=False) == 3


class TestFileGetPositions:
    def test_positions(self, sample_file):
        positions = file_get_positions(sample_file, "fox")
        assert len(positions) == 2

    def test_no_match(self, sample_file):
        positions = file_get_positions(sample_file, "elephant")
        assert positions == []
