import pytest
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from wordscalpel.core import (
    count_occurrences,
    get_positions,
    remove_occurrence,
    remove_occurrence_range,
    remove_all_occurrences,
    replace_occurrence,
    replace_all_occurrences,
)
from wordscalpel.exceptions import (
    OccurrenceNotFoundError,
    InvalidRangeError,
    EmptyInputError,
)


# ── count_occurrences ──────────────────────────────────────────────────────────

class TestCountOccurrences:
    def test_basic(self):
        assert count_occurrences("the cat and the dog", "the") == 2

    def test_zero(self):
        assert count_occurrences("hello world", "foo") == 0

    def test_case_sensitive(self):
        assert count_occurrences("The the THE", "the") == 1

    def test_case_insensitive(self):
        assert count_occurrences("The the THE", "the", case_sensitive=False) == 3

    def test_empty_raises(self):
        with pytest.raises(EmptyInputError):
            count_occurrences("", "word")

    def test_whitespace_only_raises(self):
        with pytest.raises(EmptyInputError):
            count_occurrences("   ", "word")

    def test_unicode(self):
        assert count_occurrences("café café latte", "café") == 2


# ── get_positions ──────────────────────────────────────────────────────────────

class TestGetPositions:
    def test_basic(self):
        positions = get_positions("the cat and the dog", "the")
        assert positions == [(0, 3), (12, 15)]

    def test_no_match(self):
        assert get_positions("hello world", "foo") == []

    def test_punctuation_adjacent(self):
        # "word," should still match "word"
        positions = get_positions("word, word. word!", "word")
        assert len(positions) == 3


# ── remove_occurrence ──────────────────────────────────────────────────────────

class TestRemoveOccurrence:
    def test_remove_first(self):
        result = remove_occurrence("the cat and the dog", "the", 1)
        assert result == " cat and the dog"

    def test_remove_second(self):
        result = remove_occurrence("the cat and the dog", "the", 2)
        assert result == "the cat and  dog"

    def test_remove_with_punctuation(self):
        result = remove_occurrence("error, error, error", "error", 2)
        assert "error" in result
        assert result.count("error") == 2

    def test_n_exceeds_count_raises(self):
        with pytest.raises(OccurrenceNotFoundError) as exc_info:
            remove_occurrence("one two three", "one", 5)
        assert exc_info.value.n == 5
        assert exc_info.value.total == 1

    def test_n_zero_raises(self):
        with pytest.raises(ValueError):
            remove_occurrence("hello hello", "hello", 0)

    def test_n_negative_raises(self):
        with pytest.raises(ValueError):
            remove_occurrence("hello hello", "hello", -1)

    def test_empty_text_raises(self):
        with pytest.raises(EmptyInputError):
            remove_occurrence("", "word", 1)

    def test_case_insensitive(self):
        result = remove_occurrence("Hello hello HELLO", "hello", 2, case_sensitive=False)
        assert result.count("hello") + result.count("Hello") + result.count("HELLO") == 2


# ── remove_occurrence_range ────────────────────────────────────────────────────

class TestRemoveOccurrenceRange:
    def test_remove_middle_range(self):
        result = remove_occurrence_range("a a a a a", "a", 2, 4)
        remaining = [c for c in result if c == "a"]
        assert len(remaining) == 2

    def test_invalid_start_raises(self):
        with pytest.raises(InvalidRangeError):
            remove_occurrence_range("a a a", "a", 0, 2)

    def test_end_exceeds_total_raises(self):
        with pytest.raises(InvalidRangeError):
            remove_occurrence_range("a a a", "a", 1, 10)

    def test_end_before_start_raises(self):
        with pytest.raises(InvalidRangeError):
            remove_occurrence_range("a a a", "a", 3, 1)


# ── remove_all_occurrences ─────────────────────────────────────────────────────

class TestRemoveAllOccurrences:
    def test_removes_all(self):
        result = remove_all_occurrences("the cat and the dog and the bird", "the")
        assert "the" not in result.split()

    def test_no_match_unchanged(self):
        text = "hello world"
        result = remove_all_occurrences(text, "foo")
        assert result == text


# ── replace_occurrence ─────────────────────────────────────────────────────────

class TestReplaceOccurrence:
    def test_replace_first(self):
        result = replace_occurrence("foo foo foo", "foo", "bar", 1)
        assert result == "bar foo foo"

    def test_replace_second(self):
        result = replace_occurrence("foo foo foo", "foo", "bar", 2)
        assert result == "foo bar foo"

    def test_replace_third(self):
        result = replace_occurrence("foo foo foo", "foo", "bar", 3)
        assert result == "foo foo bar"

    def test_not_found_raises(self):
        with pytest.raises(OccurrenceNotFoundError):
            replace_occurrence("hello world", "foo", "bar", 1)

    def test_empty_replacement(self):
        result = replace_occurrence("hello hello", "hello", "", 1)
        assert result == " hello"

    def test_empty_text_raises(self):
        with pytest.raises(EmptyInputError):
            replace_occurrence("", "word", "x", 1)


# ── replace_all_occurrences ────────────────────────────────────────────────────

class TestReplaceAllOccurrences:
    def test_replaces_all(self):
        result = replace_all_occurrences("foo and foo and foo", "foo", "bar")
        assert result == "bar and bar and bar"

    def test_no_match_unchanged(self):
        text = "hello world"
        result = replace_all_occurrences(text, "xyz", "abc")
        assert result == text

    def test_case_insensitive(self):
        result = replace_all_occurrences("Foo foo FOO", "foo", "bar", case_sensitive=False)
        assert result == "bar bar bar"
