"""
core.py — Main occurrence-based word manipulation logic.
"""

from wordscalpel.utils import find_all_spans, validate_text
from wordscalpel.exceptions import (
    OccurrenceNotFoundError,
    InvalidRangeError,
    EmptyInputError,
)


def count_occurrences(text: str, word: str, case_sensitive: bool = True) -> int:
    """
    Count how many times a word appears in the text.

    Args:
        text: The input string.
        word: The word to count.
        case_sensitive: Whether matching should be case-sensitive.

    Returns:
        Integer count of occurrences.

    Raises:
        EmptyInputError: If text is empty.

    Example:
        >>> count_occurrences("the cat sat on the mat", "the")
        2
    """
    validate_text(text)
    return len(find_all_spans(text, word, case_sensitive))


def get_positions(text: str, word: str, case_sensitive: bool = True) -> list:
    """
    Get the character positions of all occurrences of a word.

    Args:
        text: The input string.
        word: The word to locate.
        case_sensitive: Whether matching should be case-sensitive.

    Returns:
        List of (start, end) tuples for each occurrence.

    Raises:
        EmptyInputError: If text is empty.

    Example:
        >>> get_positions("the cat and the dog", "the")
        [(0, 3), (12, 15)]
    """
    validate_text(text)
    return find_all_spans(text, word, case_sensitive)


def remove_occurrence(
    text: str, word: str, n: int, case_sensitive: bool = True
) -> str:
    """
    Remove the nth occurrence of a word from the text.

    Args:
        text: The input string.
        word: The word to remove.
        n: Which occurrence to remove (1-based index).
        case_sensitive: Whether matching should be case-sensitive.

    Returns:
        Modified string with the nth occurrence removed.

    Raises:
        EmptyInputError: If text is empty.
        OccurrenceNotFoundError: If nth occurrence doesn't exist.
        ValueError: If n is less than 1.

    Example:
        >>> remove_occurrence("the cat and the dog and the bird", "the", 2)
        'the cat and  dog and the bird'
    """
    validate_text(text)
    if n < 1:
        raise ValueError(f"n must be >= 1, got {n}")

    spans = find_all_spans(text, word, case_sensitive)
    total = len(spans)

    if n > total:
        raise OccurrenceNotFoundError(word, n, total)

    start, end = spans[n - 1]
    return text[:start] + text[end:]


def remove_occurrence_range(
    text: str, word: str, start_n: int, end_n: int, case_sensitive: bool = True
) -> str:
    """
    Remove occurrences of a word within a range (inclusive).

    Args:
        text: The input string.
        word: The word to remove.
        start_n: Start of range (1-based, inclusive).
        end_n: End of range (1-based, inclusive).
        case_sensitive: Whether matching should be case-sensitive.

    Returns:
        Modified string with occurrences in range removed.

    Raises:
        EmptyInputError: If text is empty.
        InvalidRangeError: If range is invalid or out of bounds.

    Example:
        >>> remove_occurrence_range("a a a a a", "a", 2, 4)
        'a  a'
    """
    validate_text(text)

    if start_n < 1 or end_n < start_n:
        raise InvalidRangeError(start_n, end_n, 0)

    spans = find_all_spans(text, word, case_sensitive)
    total = len(spans)

    if start_n > total or end_n > total:
        raise InvalidRangeError(start_n, end_n, total)

    # Remove in reverse order to preserve indices
    target_spans = spans[start_n - 1: end_n]
    result = list(text)
    for s, e in reversed(target_spans):
        del result[s:e]

    return "".join(result)


def remove_all_occurrences(
    text: str, word: str, case_sensitive: bool = True
) -> str:
    """
    Remove all occurrences of a word from the text.

    Args:
        text: The input string.
        word: The word to remove entirely.
        case_sensitive: Whether matching should be case-sensitive.

    Returns:
        Modified string with all occurrences removed.

    Raises:
        EmptyInputError: If text is empty.

    Example:
        >>> remove_all_occurrences("the cat and the dog", "the")
        ' cat and  dog'
    """
    validate_text(text)
    spans = find_all_spans(text, word, case_sensitive)
    result = list(text)
    for s, e in reversed(spans):
        del result[s:e]
    return "".join(result)


def replace_occurrence(
    text: str,
    word: str,
    replacement: str,
    n: int,
    case_sensitive: bool = True,
) -> str:
    """
    Replace the nth occurrence of a word with a replacement string.

    Args:
        text: The input string.
        word: The word to replace.
        replacement: The string to insert in place of the word.
        n: Which occurrence to replace (1-based index).
        case_sensitive: Whether matching should be case-sensitive.

    Returns:
        Modified string with nth occurrence replaced.

    Raises:
        EmptyInputError: If text is empty.
        OccurrenceNotFoundError: If nth occurrence doesn't exist.
        ValueError: If n is less than 1.

    Example:
        >>> replace_occurrence("foo foo foo", "foo", "bar", 2)
        'foo bar foo'
    """
    validate_text(text)
    if n < 1:
        raise ValueError(f"n must be >= 1, got {n}")

    spans = find_all_spans(text, word, case_sensitive)
    total = len(spans)

    if n > total:
        raise OccurrenceNotFoundError(word, n, total)

    start, end = spans[n - 1]
    return text[:start] + replacement + text[end:]


def replace_all_occurrences(
    text: str,
    word: str,
    replacement: str,
    case_sensitive: bool = True,
) -> str:
    """
    Replace all occurrences of a word with a replacement string.

    Args:
        text: The input string.
        word: The word to replace.
        replacement: The replacement string.
        case_sensitive: Whether matching should be case-sensitive.

    Returns:
        Modified string with all occurrences replaced.

    Raises:
        EmptyInputError: If text is empty.

    Example:
        >>> replace_all_occurrences("foo and foo", "foo", "bar")
        'bar and bar'
    """
    validate_text(text)
    spans = find_all_spans(text, word, case_sensitive)
    result = text
    offset = 0
    for s, e in spans:
        s += offset
        e += offset
        result = result[:s] + replacement + result[e:]
        offset += len(replacement) - (e - s)
    return result
