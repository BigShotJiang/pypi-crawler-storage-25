"""
file_ops.py — File-level read/write operations with streaming support.
"""

import os
from wordscalpel.exceptions import EmptyInputError
from wordscalpel.core import (
    remove_occurrence,
    remove_occurrence_range,
    remove_all_occurrences,
    replace_occurrence,
    replace_all_occurrences,
    count_occurrences,
    get_positions,
)

CHUNK_SIZE = 1024 * 1024  # 1MB chunks


def _read_file(path: str) -> str:
    """Read a file and return its content."""
    if not os.path.exists(path):
        raise FileNotFoundError(f"File not found: {path}")
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
    if not content.strip():
        raise EmptyInputError(f"file '{path}'")
    return content


def _write_file(path: str, content: str) -> None:
    """Write content to a file."""
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)


def process_file(
    input_path: str,
    output_path: str,
    word: str,
    n: int = None,
    operation: str = "remove",
    replacement: str = "",
    start_n: int = None,
    end_n: int = None,
    case_sensitive: bool = True,
) -> dict:
    """
    Apply word operations to a file.

    Args:
        input_path: Path to the input file.
        output_path: Path to write the result.
        word: The word to operate on.
        n: Which occurrence (1-based). Use None for 'all'.
        operation: One of 'remove', 'replace', 'remove_range'.
        replacement: Replacement string (for 'replace' operation).
        start_n: Start of range for 'remove_range'.
        end_n: End of range for 'remove_range'.
        case_sensitive: Whether matching is case-sensitive.

    Returns:
        Dict with keys: original_count, result_count, output_path.

    Raises:
        FileNotFoundError: If input file doesn't exist.
        EmptyInputError: If file is empty.
        ValueError: If operation is unknown.

    Example:
        >>> process_file("input.txt", "output.txt", "error", n=2, operation="remove")
    """
    content = _read_file(input_path)
    original_count = count_occurrences(content, word, case_sensitive)

    if operation == "remove":
        if n is None:
            result = remove_all_occurrences(content, word, case_sensitive)
        else:
            result = remove_occurrence(content, word, n, case_sensitive)

    elif operation == "replace":
        if n is None:
            result = replace_all_occurrences(content, word, replacement, case_sensitive)
        else:
            result = replace_occurrence(content, word, replacement, n, case_sensitive)

    elif operation == "remove_range":
        result = remove_occurrence_range(content, word, start_n, end_n, case_sensitive)

    else:
        raise ValueError(f"Unknown operation '{operation}'. Use: remove, replace, remove_range")

    _write_file(output_path, result)
    result_count = count_occurrences(result, word, case_sensitive)

    return {
        "original_count": original_count,
        "result_count": result_count,
        "output_path": output_path,
    }


def file_count_occurrences(
    path: str, word: str, case_sensitive: bool = True
) -> int:
    """
    Count occurrences of a word in a file.

    Args:
        path: Path to the file.
        word: The word to count.
        case_sensitive: Whether matching is case-sensitive.

    Returns:
        Integer count.
    """
    content = _read_file(path)
    return count_occurrences(content, word, case_sensitive)


def file_get_positions(
    path: str, word: str, case_sensitive: bool = True
) -> list:
    """
    Get character positions of all word occurrences in a file.

    Args:
        path: Path to the file.
        word: The word to find.
        case_sensitive: Whether matching is case-sensitive.

    Returns:
        List of (start, end) tuples.
    """
    content = _read_file(path)
    return get_positions(content, word, case_sensitive)
