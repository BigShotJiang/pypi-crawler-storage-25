"""
wordscalpel — Surgical, occurrence-based word manipulation for strings and files.
"""

from wordscalpel.core import (
    count_occurrences,
    get_positions,
    remove_occurrence,
    remove_occurrence_range,
    remove_all_occurrences,
    replace_occurrence,
    replace_all_occurrences,
)
from wordscalpel.file_ops import (
    process_file,
    file_count_occurrences,
    file_get_positions,
)
from wordscalpel.exceptions import (
    OccurrenceNotFoundError,
    InvalidRangeError,
    EmptyInputError,
)

__version__ = "1.0.0"
__all__ = [
    "count_occurrences",
    "get_positions",
    "remove_occurrence",
    "remove_occurrence_range",
    "remove_all_occurrences",
    "replace_occurrence",
    "replace_all_occurrences",
    "process_file",
    "file_count_occurrences",
    "file_get_positions",
    "OccurrenceNotFoundError",
    "InvalidRangeError",
    "EmptyInputError",
]
