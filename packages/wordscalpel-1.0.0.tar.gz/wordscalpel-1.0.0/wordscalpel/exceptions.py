class OccurrenceNotFoundError(Exception):
    """Raised when the nth occurrence of a word does not exist in the text."""
    def __init__(self, word, n, total):
        self.word = word
        self.n = n
        self.total = total
        super().__init__(
            f"Occurrence {n} of '{word}' not found. "
            f"Total occurrences found: {total}"
        )


class InvalidRangeError(Exception):
    """Raised when the specified range is invalid or out of bounds."""
    def __init__(self, start, end, total):
        self.start = start
        self.end = end
        self.total = total
        super().__init__(
            f"Range [{start}, {end}] is invalid. "
            f"Total occurrences found: {total}"
        )


class EmptyInputError(Exception):
    """Raised when the input text or file is empty."""
    def __init__(self, source="input"):
        super().__init__(f"The {source} is empty. Please provide valid content.")
