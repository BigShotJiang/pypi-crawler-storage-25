# Actuator Extension Model

This package provides Spring Boot-style management endpoints under `/actuator`.

## Defaults

- `register_actuator_router(app)` mounts `/actuator` and auto-wires built-in plugins.
- `/_info` and `/_info/health` are separate versioning introspection endpoints and remain unchanged.
- Consumers can pass plugin overrides via `configure_versioned_api(..., actuator_plugins=[...])`
  or `create_versioned_app(..., actuator_plugins=[...])`. On name conflicts,
  consumer plugins override built-in plugins.

## Plugin Contract

Implement the `ActuatorPlugin` protocol from `plugins/base.py`:

- `name`: short plugin identifier
- `register(router, app=..., prefix=...)`: add routes and return link metadata

The returned link metadata is merged into the root payload:

```json
{
  "_links": {
    "self": {"href": ".../actuator", "templated": false}
  }
}
```

When the info plugin is active and the metadata file exists, the root
payload also includes an `info` link.

When the env plugin is active, the root payload includes an `env` link.
When the env plugin is active, the root payload also includes a templated
`env-toMatch` link.

## Built-in Plugin

`InfoActuatorPlugin` serves `/actuator/info` by reading JSON metadata from:

1. `ACTUATOR_INFO_PATH` environment variable
2. `service_info.json` (default, relative to the process working directory)

If the resolved file does not exist, `/actuator/info` is not registered.
If the file exists but is invalid JSON, the endpoint returns `{}`.

`EnvActuatorPlugin` serves `/actuator/env` with runtime profile metadata:

```json
{
  "activeProfiles": ["dev", "stage"],
  "defaultProfiles": [],
  "propertySources": []
}
```

Profiles are read from `SPRING_PROFILES_ACTIVE` as a comma-separated list.

`EnvActuatorPlugin` also serves `/actuator/env/{toMatch}` and filters
environment variables by case-insensitive key match into `propertySources`.

`HealthActuatorPlugin` serves `/actuator/health` with composable health
indicators:

```json
{
  "status": "UP",
  "groups": ["liveness", "readiness"],
  "components": {
    "ping": {"status": "UP"},
    "diskSpace": {"status": "UP", "details": {"total": ..., "free": ..., "threshold": 10485760, "path": ".", "exists": true}},
    "livenessState": {"status": "UP"},
    "readinessState": {"status": "UP"}
  }
}
```

Default indicators: `PingHealthIndicator`, `DiskSpaceHealthIndicator`,
`LivenessIndicator`, `ReadinessIndicator`.

Default health groups:
- `liveness` → `["livenessState"]`
- `readiness` → `["readinessState", "ping", "diskSpace"]`

`/actuator/health/{component}` returns an individual indicator's status.
`/actuator/health/{group}` returns the aggregated status for a health group.

### Custom Indicators

Extend `BaseHealthIndicator` for exception-safe custom indicators.
Override `_check()` — the base class wraps it in try/except automatically:

```python
from api_versioning.fastapi.versioning.actuator.plugins import BaseHealthIndicator

class MyDatabaseIndicator(BaseHealthIndicator):
    _name = "db"

    def __init__(self, pool):
        self._pool = pool

    def _check(self):
        self._pool.execute("SELECT 1")
        return {"status": "UP"}
```

Both sync and async `_check()` are supported:

```python
class MyAsyncIndicator(BaseHealthIndicator):
    _name = "myService"

    async def _check(self):
        result = await some_client.ping()
        return {"status": "UP", "details": result}
```

Register via `HealthActuatorPlugin.with_indicators()`:

```python
HealthActuatorPlugin.with_indicators(db=MyDatabaseIndicator(pool))
```

### Auto-Discovery

When `auto_discover=True` (the default), the health plugin inspects
`app.state` on each request and registers indicators for detected services:

| Indicator        | `app.state` key                   | Source package                      |
|------------------|-----------------------------------|-------------------------------------|
| `rabbit`         | `rabbit`                          | RabbitMQ client                     |
| `kafka`          | `kafka_producer_manager` / `kafka_consumer_manager` | Kafka client |
| `mongo`          | `mongo_client`                    | MongoDB client                      |
| `launchDarkly`   | `launchdarkly_client`             | LaunchDarkly client                 |

Auto-discovered indicators are appended to the `readiness` group.
Consumer-provided indicators with the same name take precedence.

To build custom `app.state`-based indicators, extend `AppStateHealthIndicator`
which adds `_get_state(key)` and `_require_attr(obj, attr)` helpers with
one-time attribute-missing warnings:

```python
from api_versioning.fastapi.versioning.actuator.plugins import AppStateHealthIndicator

class ElasticHealthIndicator(AppStateHealthIndicator):
    _name = "elastic"

    def _check(self):
        client = self._get_state("elastic_client")
        if client is None:
            return {"status": "DOWN", "details": {"error": "State removed"}}
        ok, ping = self._require_attr(client, "ping")
        if not ok:
            return {"status": "DOWN", "details": {"error": "No ping method"}}
        ping()
        return {"status": "UP"}
```

Disable auto-discovery with `auto_discover=False`:

```python
HealthActuatorPlugin(auto_discover=False)
```

### Indicator Class Hierarchy

```
HealthIndicator (Protocol — duck-typing contract)
│
BaseHealthIndicator (exception-safe template method)
├── PingHealthIndicator
├── LivenessIndicator
├── ReadinessIndicator
├── DiskSpaceHealthIndicator
│
└── AppStateHealthIndicator (adds app.state helpers + attribute guards)
    ├── RabbitHealthIndicator
    ├── KafkaHealthIndicator
    ├── MongoHealthIndicator
    └── LaunchDarklyHealthIndicator
```

### ShowDetails

`ShowDetails` controls component visibility:

- `ALWAYS` (default) – include `components` with per-indicator details
- `NEVER` – only return `{"status": "UP"}`
- `WHEN_AUTHORIZED` – reserved; currently behaves like `NEVER`

Build-time generation patterns (including Docker multi-stage examples) live in
`tools/README.md`.

## Property Sources

`EnvActuatorPlugin` uses a `PropertySourceRegistry` to collect environment
metadata from composable providers.

Built-in providers (registered when `with_defaults=True`):

- `SystemEnvironmentProvider` – `os.environ` snapshot
- `SystemPropertiesProvider` – Python runtime info (`sys.version`, platform, etc.)
- `DockerConfigProvider` – Docker-related env vars (when present)

All values are wrapped in `{"value": ...}` dicts, matching Spring Boot format.

### Custom Providers

Implement the `PropertySourceProvider` protocol:

```python
class PropertySourceProvider(Protocol):
    def get_sources(self, to_match: str | None = None) -> list[dict[str, Any]]: ...
```

Register via `EnvActuatorPlugin.with_providers()`:

```python
EnvActuatorPlugin.with_providers(
    myFeatures=MyFeatureProvider(),
)
```

### Auto-Wiring

Plugins that extend `BaseActuatorPlugin` can contribute property source
providers via `register_property_source_provider(name=..., provider=...)`.
During plugin resolution, `_wire_env_property_sources()` collects all
contributions and injects them into the env plugin automatically.

## Sanitization

Property values are redacted by default. Control behavior with
`SanitizationConfig`:

```python
from api_versioning.fastapi.versioning.actuator.plugins import (
    EnvActuatorPlugin, SanitizationConfig, ShowValues,
)

EnvActuatorPlugin.with_providers(
    sanitization=SanitizationConfig(show_values=ShowValues.ALWAYS),
)
```

`ShowValues` modes:

- `NEVER` (default) – redact **all** values to `"******"`
- `ALWAYS` – show benign values; sensitive keys still redacted
- `WHEN_AUTHORIZED` – reserved; currently behaves like `NEVER` (safe default until auth is wired)

Sensitive keys matched by default: `password`, `secret`, `key`, `token`,
`.*credentials.*`, `vcap_services`. Extend with `additional_keys_to_sanitize`
or replace entirely with `keys_to_sanitize`.

## Adding a Plugin

1. Add a module under `plugins/`.
2. Implement `ActuatorPlugin`.
3. Add it to `default_actuator_plugins()` in `plugins/__init__.py`.
