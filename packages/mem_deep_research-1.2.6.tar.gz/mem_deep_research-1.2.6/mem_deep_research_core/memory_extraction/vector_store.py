"""VectorStoreStrategy — Offload 发生时把原内容同步到 vector store

工具结果被 offload 到本地文件时，strategy 同步把内容 chunk 化后入 vector store。
LLM 需要时通过 "检索工具"（由用户注册）查询相关片段。

默认不启用。用户按需传入 vector store client：
    VectorStoreStrategy(vector_store_client=pinecone_client)

Vector store client 接口（duck-typed）：
    - upsert(namespace: str, documents: list[dict]) -> Awaitable[None]
"""

import logging
from typing import Any

from mem_deep_research_core.memory_extraction.base import (
    ExtractionContext,
    MemoryExtractionStrategy,
)

logger = logging.getLogger("mem_deep_research")


class VectorStoreStrategy(MemoryExtractionStrategy):
    """Offload 发生时把原内容 chunk 化后入 vector store。

    注意：本 strategy 只管写入 vector store；检索由用户注册的工具完成。
    框架不内置检索工具（避免和特定 vector store 强绑定）。
    """

    name = "vector_store"

    def __init__(
        self,
        vector_store_client: Any = None,
        chunk_size: int = 500,
        chunk_overlap: int = 50,
        namespace_fn=None,
    ):
        """
        Args:
            vector_store_client: 提供 upsert(namespace, documents) 的客户端
            chunk_size: chunk 字符数
            chunk_overlap: chunk 之间重叠字符数
            namespace_fn: (ctx) -> str，给每条 chunk 的 namespace；默认使用 task_description
        """
        super().__init__()
        self.store = vector_store_client
        self.chunk_size = chunk_size
        self.chunk_overlap = max(0, min(chunk_overlap, chunk_size - 1))
        self.namespace_fn = namespace_fn or (lambda ctx: ctx.task_description or "default")
        # 已入库的 ref 集合，resume 后避免重写
        self._stored_refs: set[str] = set()

    async def on_offload(
        self,
        ref: str,
        tool_name: str,
        original_content: str,
        ctx: ExtractionContext,
    ) -> None:
        if self.store is None:
            return
        if ref in self._stored_refs:
            return
        if not original_content:
            return

        chunks = self._chunk(original_content)
        if not chunks:
            return

        namespace = self.namespace_fn(ctx)
        documents = [
            {
                "id": f"{ref}:chunk{i}",
                "text": chunk,
                "metadata": {"tool": tool_name, "ref": ref, "chunk_index": i},
            }
            for i, chunk in enumerate(chunks)
        ]

        try:
            result = self.store.upsert(namespace=namespace, documents=documents)
            if hasattr(result, "__await__"):
                await result
            self._stored_refs.add(ref)
            logger.info(
                f"[VectorStore] Upserted {len(chunks)} chunks for ref={ref} (tool={tool_name})"
            )
        except Exception as e:
            logger.warning(f"[VectorStore] Upsert failed for ref={ref}: {e}")

    def _chunk(self, text: str) -> list[str]:
        """固定大小 + overlap 的 chunking。"""
        if len(text) <= self.chunk_size:
            return [text]
        chunks: list[str] = []
        step = self.chunk_size - self.chunk_overlap
        for i in range(0, len(text), step):
            chunk = text[i : i + self.chunk_size]
            if chunk:
                chunks.append(chunk)
            if i + self.chunk_size >= len(text):
                break
        return chunks

    # ========== Snapshot ==========

    def snapshot(self) -> dict:
        return {"stored_refs": list(self._stored_refs)}

    def restore(self, state: dict) -> None:
        self._stored_refs = set(state.get("stored_refs", []))
