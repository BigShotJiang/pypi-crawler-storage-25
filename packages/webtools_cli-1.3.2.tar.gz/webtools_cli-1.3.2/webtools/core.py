import sys,os,re,requests,random,subprocess,time,socket,shutil,json,zipfile,atexit,concurrent.futures,threading,qrcode,logging,queue,urllib3,base64,traceback,csv,io,mtranslate,hashlib,uuid
sys.dont_write_bytecode = True

# Enforce UTF-8 encoding for standard output to avoid UnicodeEncodeError on Windows (Emojis)
if sys.stdout.encoding and sys.stdout.encoding.lower() != 'utf-8':
    try:
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    except Exception: pass

# --- Dependencies are managed by pyproject.toml / pip install ---


# --- PACKAGE PATHS ---
PACKAGE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(os.path.expanduser('~'), '.webtools')
DB_PATH = os.path.join(DATA_DIR, 'app.db')
# Scraped results are stored in a local 'webfiles' folder for better visibility
SCRAPED_DIR = os.path.join(os.getcwd(), 'webfiles', 'scraped')
os.makedirs(SCRAPED_DIR, exist_ok=True)
import sqlite3

def _init_db():
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute('''
            CREATE TABLE IF NOT EXISTS adb_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                device_id TEXT,
                device_model TEXT,
                package TEXT,
                label TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"Database error: {e}")

_init_db()

try:
    from colorama import init, Fore, Style
    init(autoreset=True)
    COLOR_SUPPORT = True
except ImportError:
    COLOR_SUPPORT = False
import numpy as np
from bs4 import BeautifulSoup
from collections import Counter
from flask import Flask, render_template_string, send_from_directory, request, jsonify, send_file, after_this_request
from PIL import Image,ExifTags,ImageChops,ImageEnhance
from io import BytesIO
# --- MEGA.NZ SUPPORT (Lazy: installed on first use via --no-deps) ---
MEGA_AVAILABLE = False
mega_engine = None
mega_sessions = {}
active_mega_email = None

def _ensure_mega():
    """Install mega.py (without its broken deps) on first use and initialize"""
    global MEGA_AVAILABLE, mega_engine
    if MEGA_AVAILABLE:
        return True
    try:
        from mega import Mega
        MEGA_AVAILABLE = True
    except ImportError:
        print("\n📦 Installing mega.py (cloud storage support)...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "mega.py", "--no-deps"],
                                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            from mega import Mega
            MEGA_AVAILABLE = True
            print("✅ mega.py installed successfully!\n")
        except Exception as e:
            print(f"❌ Failed to install mega.py: {e}")
            return False
    
    # Import mega sub-modules and apply patches
    _init_mega_internals()
    return True

def _init_mega_internals():
    """Initialize mega imports, monkey patches, and RobustMega after mega is available"""
    global mega_engine, RequestError
    
    from mega import Mega
    
    try:
        from mega.errors import RequestError as _RequestError
        from mega.crypto import (
            base64_to_a32, decrypt_key, base64_url_decode, a32_to_str, 
            encrypt_key, str_to_a32, mpi_to_int, base64_url_encode
        )
        from Crypto.PublicKey import RSA
        import binascii
        globals()['RequestError'] = _RequestError
        globals()['base64_to_a32'] = base64_to_a32
        globals()['decrypt_key'] = decrypt_key
        globals()['base64_url_decode'] = base64_url_decode
        globals()['a32_to_str'] = a32_to_str
        globals()['encrypt_key'] = encrypt_key
        globals()['str_to_a32'] = str_to_a32
        globals()['mpi_to_int'] = mpi_to_int
        globals()['base64_url_encode'] = base64_url_encode
        globals()['RSA'] = RSA
        globals()['binascii'] = binascii
    except ImportError:
        pass
    
    # Monkey patch for mega.py (fixes TypeError in AES calls)
    try:
        from Crypto.Cipher import AES
        import mega.mega as mega_module
        _original_aes_new = AES.new
        
        def _patched_aes_new(key, *args, **kwargs):
            if isinstance(key, str):
                key = key.encode('latin-1')
            new_args = list(args)
            for i in range(len(new_args)):
                if isinstance(new_args[i], str):
                    new_args[i] = new_args[i].encode('latin-1')
            for k in kwargs:
                if isinstance(kwargs[k], str):
                    kwargs[k] = kwargs[k].encode('latin-1')
            return _original_aes_new(key, *new_args, **kwargs)
        
        AES.new = _patched_aes_new
        if hasattr(mega_module, 'AES'):
            mega_module.AES.new = _patched_aes_new
    except Exception:
        pass
    
    # Build RobustMega class dynamically
    class RobustMega(Mega):
        """Patched version of Mega library to handle fragile API responses."""
        def _login_process(self, resp, password):
            encrypted_master_key = base64_to_a32(resp['k'])
            self.master_key = decrypt_key(encrypted_master_key, password)
            if 'tsid' in resp:
                tsid = base64_url_decode(resp['tsid'])
                key_encrypted = a32_to_str(
                    encrypt_key(str_to_a32(tsid[:16]), self.master_key)
                )
                if key_encrypted == tsid[-16:]:
                    self.sid = resp['tsid']
            elif 'csid' in resp:
                encrypted_rsa_private_key = base64_to_a32(resp['privk'])
                rsa_private_key = decrypt_key(
                    encrypted_rsa_private_key, self.master_key
                )
                private_key_str = a32_to_str(rsa_private_key)
                self.rsa_private_key = [0, 0, 0, 0]
                for i in range(4):
                    l = int(((private_key_str[0]) * 256 + (private_key_str[1]) + 7) / 8) + 2
                    self.rsa_private_key[i] = mpi_to_int(private_key_str[:l])
                    private_key_str = private_key_str[l:]
                encrypted_sid = mpi_to_int(base64_url_decode(resp['csid']))
                p = self.rsa_private_key[0]
                q = self.rsa_private_key[1]
                d = self.rsa_private_key[2]
                n = p * q
                phi = (p - 1) * (q - 1)
                try:
                    e = pow(d, -1, phi)
                    rsa_decrypter = RSA.construct((n, e, d, p, q))
                except:
                    e = 65537
                    rsa_decrypter = RSA.construct((n, e, d, p, q), consistency_check=False)
                key_obj = rsa_decrypter.key if hasattr(rsa_decrypter, 'key') else rsa_decrypter
                sid_int = key_obj._decrypt(encrypted_sid)
                sid_hex = '%x' % sid_int
                if len(sid_hex) % 2:
                    sid_hex = '0' + sid_hex
                sid_bytes = binascii.unhexlify(sid_hex)
                self.sid = base64_url_encode(sid_bytes[:43])

        def _api_request(self, data):
            params = {'id': self.sequence_num}
            self.sequence_num += 1
            if self.sid:
                params.update({'sid': self.sid})
            if not isinstance(data, list):
                data = [data]
            url = '{0}://g.api.{1}/cs'.format(self.schema, self.domain)
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
                'Accept': '*/*',
                'Accept-Language': 'en-US,en;q=0.9',
                'Origin': 'https://mega.nz',
                'Referer': 'https://mega.nz/'
            }
            try:
                req = requests.post(
                    url, params=params, data=json.dumps(data),
                    headers=headers, timeout=self.timeout,
                )
                content = req.text.strip() if req.text else ""
                if not content:
                    if req.status_code == 402:
                        raise Exception("Mega.nz is temporarily blocking this connection (Status 402). This usually happens due to rate-limiting. Please try again later or use a different network.")
                    raise Exception(f"Mega API returned empty response (Status {req.status_code})")
                try:
                    json_resp = json.loads(content)
                except json.JSONDecodeError:
                    try:
                        val = int(content)
                        raise RequestError(val)
                    except (ValueError, RequestError):
                        if content.startswith("-") and content[1:].isdigit():
                             raise RequestError(int(content))
                        raise Exception(f"Mega API error: {content[:100]}")
                if isinstance(json_resp, int):
                    if json_resp == -3:
                        time.sleep(0.5)
                        return self._api_request(data=data)
                    raise RequestError(json_resp)
                return json_resp[0]
            except Exception:
                raise
    
    globals()['RobustMega'] = RobustMega
    mega_engine = RobustMega()
    globals()['mega_engine'] = mega_engine

# Placeholder for RequestError when mega is not installed
class RequestError(Exception): pass

try:
    from playwright.sync_api import sync_playwright
    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    PLAYWRIGHT_AVAILABLE = False

def check_playwright_browsers():
    """Check if Playwright browsers are installed by attempting a quick launch"""
    if not PLAYWRIGHT_AVAILABLE:
        return False
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            browser.close()
        return True
    except:
        return False

def install_playwright_browsers():
    """Install Playwright browsers if not already installed"""
    if not PLAYWRIGHT_AVAILABLE:
        return False
    
    print("\n📦 Playwright browsers not found. Auto-installing...")
    try:
        import subprocess
        subprocess.run([sys.executable, "-m", "playwright", "install", "chromium"], check=True)
        print("✓ Playwright Chromium installed successfully\n")
        return True
    except Exception as e:
        print(f"⚠️ Failed to install Playwright browsers: {e}\n")
        return False

# Global Tracking for Active Scrapes (Client Cancellation on Reload)
ACTIVE_SCRAPES = {}

# --- CLI AUTOCOMPLETE SETUP ---
try:
    if os.name == 'nt':
        try:
            from pyreadline3 import Readline
            readline = Readline()
        except (ImportError, AttributeError):
            import pyreadline3 as readline
    else:
        import readline
    
    HISTORY_FILE = os.path.join(DATA_DIR, 'history')
    
    def setup_autocomplete(commands):
        def completer(text, state):
            options = [i for i in commands if i.startswith(text)]
            if state < len(options):
                return options[state]
            else:
                return None
        
        # Ensure the object has the required methods
        if hasattr(readline, 'set_completer'):
            readline.set_completer(completer)
            if 'libedit' in (getattr(readline, '__doc__', '') or ''):
                readline.parse_and_bind("bind ^I rl_complete")
            else:
                readline.parse_and_bind("tab: complete")
                if os.name != 'nt' and hasattr(readline, 'parse_and_bind'):
                    readline.parse_and_bind("set show-all-if-ambiguous on")
            
            if hasattr(readline, 'set_completer_delims'):
                readline.set_completer_delims(' ')
            
            # Load History
            if os.path.exists(HISTORY_FILE):
                try:
                    readline.read_history_file(HISTORY_FILE)
                except: pass
            
            # Save on exit
            def save_history():
                try:
                    os.makedirs(os.path.dirname(HISTORY_FILE), exist_ok=True)
                    readline.write_history_file(HISTORY_FILE)
                except: pass
            
            atexit.register(save_history)

    AUTOCOMPLETE_AVAILABLE = True
except Exception:
    def setup_autocomplete(commands): pass
    AUTOCOMPLETE_AVAILABLE = False

def print_gradient_text(text, start_rgb, end_rgb):
    """Prints text with a vertical/horizontal color gradient using 24-bit ANSI"""
    lines = text.splitlines()
    if not lines: return
    
    for i, line in enumerate(lines):
        # Calculate ratio for this line
        ratio = i / max(1, len(lines) - 1)
        
        # Interpolate RGB
        r = int(start_rgb[0] + (end_rgb[0] - start_rgb[0]) * ratio)
        g = int(start_rgb[1] + (end_rgb[1] - start_rgb[1]) * ratio)
        b = int(start_rgb[2] + (end_rgb[2] - start_rgb[2]) * ratio)
        
        # Apply 24-bit color ANSI
        print(f"\033[38;2;{r};{g};{b}m{line}\033[0m")

# Flask logs ko suppress karo
log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)

# SSL warnings ko globally band karo
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Directories setup kar rahe hain
os.makedirs(os.path.join(SCRAPED_DIR, 'images'), exist_ok=True)
os.makedirs(os.path.join(SCRAPED_DIR, 'videos'), exist_ok=True)

# --- PERFORMANCE AUDITOR ---
class PerformanceTracker:
    def __init__(self):
        self.stats_file = os.path.join(DATA_DIR, 'performance_stats.json')
        self.data = self.load_data()
        self.current_report = {}
        self.last_mark = 0
        self.session_url = ""

    def load_data(self):
        if os.path.exists(self.stats_file):
            try:
                with open(self.stats_file, 'r') as f:
                    return json.load(f)
            except: pass
        return {'best': float('inf'), 'worst': 0, 'total_time': 0, 'count': 0}

    def save_data(self):
        try:
            with open(self.stats_file, 'w') as f:
                json.dump(self.data, f)
        except: pass

    def start_session(self, url):
        self.current_report = {}
        self.last_mark = time.perf_counter()
        self.session_url = url

    def record_phase(self, name):
        now = time.perf_counter()
        duration = now - self.last_mark
        self.current_report[name] = self.current_report.get(name, 0) + duration
        self.last_mark = now

    def finish_and_print(self):
        total = sum(self.current_report.values())
        if total <= 0: return {}

        self.data['count'] += 1
        self.data['total_time'] += total
        if total < self.data['best']: self.data['best'] = total
        if total > self.data['worst']: self.data['worst'] = total
        self.save_data()

        avg = self.data['total_time'] / self.data['count']
        
        return {
            'total': total,
            'phases': dict(self.current_report),
            'avg': avg,
            'best': self.data['best'],
            'worst': self.data['worst']
        }

perf_tracker = PerformanceTracker()

class MoonSpinner:
    """Threaded moon-phase loading animation"""
    def __init__(self, message="Processing"):
        self.message = message
        self.frames = ['🌑', '🌒', '🌓', '🌔', '🌕', '🌖', '🌗', '🌘']
        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self._animate, daemon=True)

    def _animate(self):
        while not self.stop_event.is_set():
            for f in self.frames:
                if self.stop_event.is_set(): break
                sys.stdout.write(f'\r{self.message} {f}   ')
                sys.stdout.flush()
                time.sleep(0.2)

    def __enter__(self):
        self.thread.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.stop_event.set()
        self.thread.join(timeout=1.0)
        sys.stdout.write(f'\r{self.message} 🌕 Done!     \n')
        sys.stdout.flush()

# --- PROXY aur UA MANAGER ---
class ProxyManager:
    def __init__(self):
        self.proxies = []
        self.last_fetch = 0
        self.fetch_interval = 300  # Har 5 minute mein refresh hoga
        self.user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (iPhone; CPU iPhone OS 17_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Mobile/15E148 Safari/604.1'
        ]
        
        # Background mein validation logic
        self.valid_proxies = queue.Queue()
        self.lock = threading.Lock()
        self.running = True

        # Smart Learner (Scores setup)
        self.scores_file = os.path.join(DATA_DIR, 'scores.json')
        self.scores = self.load_scores()
        
        # Background thread chalao
        threading.Thread(target=self._background_validator, daemon=True).start()

    def load_scores(self):
        if os.path.exists(self.scores_file):
            try:
                with open(self.scores_file, 'r') as f:
                    return json.load(f)
            except:
                pass
        return {}

    def save_scores(self):
        try:
            with open(self.scores_file, 'w') as f:
                json.dump(self.scores, f, indent=2)
        except Exception as e:
            print(f"Failed to save scores: {e}")

    def report_success(self, proxy, domain, task_type, success):
        with self.lock:
            # Score ke liye composite key (jaise "youtube.com::video")
            score_key = f"{domain}::{task_type}"
            
            if score_key not in self.scores:
                self.scores[score_key] = {}
            
            if proxy not in self.scores[score_key]:
                self.scores[score_key][proxy] = {'success': 0, 'fail': 0, 'score': 0.5}
            
            stats = self.scores[score_key][proxy]
            if success:
                stats['success'] += 1
                # Score badhao (Stickiness factor)
                stats['score'] = min(1.0, stats['score'] + 0.25)
            else:
                stats['fail'] += 1
                # Penalty laga rahe hain
                stats['score'] = max(0.0, stats['score'] - 0.2)
            
            self.save_scores()

    def get_prioritized_proxies(self, domain, task_type='general', count=5):
        # Sort and return the best performing proxies, filtering out bad ones
        score_key = f"{domain}::{task_type}"
        best_proxies = []
        
        # Get all known proxies for this task
        if score_key in self.scores:
            domain_scores = self.scores[score_key]
            # Sort by score descending
            sorted_proxies = sorted(domain_scores.items(), key=lambda x: x[1]['score'], reverse=True)
            # Sirf achhe proxies (score >= 0.2) add karo
            best_proxies = [p[0] for p in sorted_proxies if p[1]['score'] >= 0.2]
            
        # Agar count poora nahi hua toh general task type se backfill karo
        if len(best_proxies) < count and task_type != 'general':
            gen_key = f"{domain}::general"
            if gen_key in self.scores:
                gen_scores = self.scores[gen_key]
                sorted_gen = sorted(gen_scores.items(), key=lambda x: x[1]['score'], reverse=True)
                for p, data in sorted_gen:
                    if data['score'] >= 0.2 and p not in best_proxies:
                        best_proxies.append(p)
                        if len(best_proxies) >= count: break
                        
        # Still need more? Random unseen valid proxies se bhar do
        attempts = 0 # To prevent infinite loops if queue is empty
        while len(best_proxies) < count and attempts < 10:
            attempts += 1
            rp = self.get_valid_proxy()
            if not rp: break 
            if rp not in best_proxies:
                best_proxies.append(rp)
                
        # Agar kuch bhi nahi mila toh jo mila wahi bhejo
        return best_proxies[:count]

    def fetch_proxies(self):
        # Sirf tab fetch karo jab list empty ya purani ho
        with self.lock:
             if self.proxies and (time.time() - self.last_fetch < self.fetch_interval):
                return
        
        # Quiet mode if background
        # print("Fetching new proxies...")
        try:
            # Optimized timing: timeout=3000 (3s)
            url = "https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=3000&country=all&ssl=all&anonymity=elite,anonymous"
            resp = requests.get(url, timeout=5)
            if resp.status_code == 200:
                proxy_list = resp.text.strip().split('\r\n')
                with self.lock:
                    self.proxies = [p for p in proxy_list if p]
                    self.last_fetch = time.time()
                # print(f"Fetched {len(self.proxies)} high-quality proxies.")
        except Exception as e:
            print(f"Failed to fetch proxies: {e}")

    def _background_validator(self):
        while self.running:
            # Queue bhar ke rakho (target: 20 valid proxies)
            if self.valid_proxies.qsize() < 20:
                self.fetch_proxies()
                
                with self.lock:
                    if not self.proxies:
                        time.sleep(5)
                        continue
                    candidates = list(self.proxies)

                # Random proxy select karo
                proxy = random.choice(candidates)
                
                if self._check_proxy(proxy):
                    self.valid_proxies.put(proxy)
                    # print(f"P: {proxy} ({self.valid_proxies.qsize()})")
                else:
                    pass
            else:
                time.sleep(1) # Queue full

    def _check_proxy(self, proxy):
         try:
            proxies = {'http': proxy, 'https': proxy}
            # Jaldi wala check
            resp = requests.get("http://httpbin.org/ip", proxies=proxies, timeout=3, verify=False)
            return resp.status_code == 200
         except:
             return False

    def get_valid_proxy(self):
        # Agar available ho toh turant result do
        try:
            return self.valid_proxies.get_nowait()
        except:
             # Agar queue empty ho toh random unvalidated proxy use karo
             return self.get_random_proxy()

    def get_random_proxy(self):
        self.fetch_proxies()
        if not self.proxies:
            return None
        return random.choice(self.proxies)

    def get_random_ua(self):
        return random.choice(self.user_agents)

proxy_manager = ProxyManager()
# ---------------------

def get_free_port():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(('', 0))
    port = sock.getsockname()[1]
    sock.close()
    return port

PORT = get_free_port()
WEB_DIR = os.path.join(PACKAGE_DIR, 'web')
app = Flask(__name__)

# Video Extraction wala updated HTML UI
@app.route('/')
def index():
    return send_from_directory(WEB_DIR, 'index.html')

@app.route('/style.css')
def serve_css():
    return send_from_directory(WEB_DIR, 'style.css')

@app.route('/script.js')
def serve_js():
    return send_from_directory(WEB_DIR, 'script.js')

@app.route('/favicon.png')
def serve_favicon():
    return send_from_directory(WEB_DIR, 'Web_Tools.png')

@app.route('/download/<path:filename>')
def serve_scraped_file(filename):
    return send_from_directory(SCRAPED_DIR, filename)

# --- CLOUD STORAGE APIs (MEGA.NZ) ---

def _get_node_by_path(path, client=None):
    if not client:
        global active_mega_email, mega_sessions
        if not active_mega_email or active_mega_email not in mega_sessions:
            return None
        client = mega_sessions[active_mega_email]['client']
        
    if not path or path == '/':
        files = client.get_files()
        for k, v in files.items():
            if v.get('t') == 2: # Root node
                return k
        return None
    else:
        node = client.find(path)
        if node:
            if isinstance(node, tuple):
                return node[0]
            elif hasattr(node, '__getitem__'):
                return node[0]
        return None

def _get_or_create_node(name, parent_id, client):
    """Find a folder by name under parent_id, or create it if missing."""
    files = client.get_files()
    for k, v in files.items():
        if v.get('p') == parent_id and v.get('t') == 1 and v.get('a', {}).get('n') == name:
            return k
    # Not found, create it
    new_node = client.create_folder(name, dest=parent_id)
    # create_folder returns the new dict or node id depending on version
    if isinstance(new_node, dict):
        # find it again to be sure
        files = client.get_files()
        for k, v in files.items():
             if v.get('p') == parent_id and v.get('t') == 1 and v.get('a', {}).get('n') == name:
                return k
    return new_node

@app.route('/api/cloud/login', methods=['POST'])
def cloud_login():
    global mega_sessions, active_mega_email
    if not _ensure_mega():
        return jsonify({'success': False, 'error': 'mega.py is not available. Install it with: pip install mega.py --no-deps'}), 500
    try:
        data = request.json or {}
        email = data.get('email', '').strip()
        password = data.get('password', '').strip()
        if not email or not password:
            return jsonify({'success': False, 'error': 'Email and password required'}), 400
            
        client = mega_engine.login(email, password)
        user_info = client.get_user()
        quota_raw = client.get_quota()
        # Normalize quota (some versions use total/space_used, others total/used)
        quota = {
            'total': quota_raw.get('total', 0) if isinstance(quota_raw, dict) else 0,
            'used': quota_raw.get('space_used', quota_raw.get('used', 0)) if isinstance(quota_raw, dict) else 0
        }
        
        # Store in sessions
        mega_sessions[email] = {
            'client': client,
            'info': user_info,
            'quota': quota
        }
        active_mega_email = email
        
        return jsonify({
            'success': True, 
            'message': f'Logged in as {email}',
            'user': user_info,
            'quota': quota,
            'active_email': active_mega_email,
            'all_accounts': list(mega_sessions.keys())
        })
    except Exception as e:
        error_msg = str(e)
        if "-9" in error_msg: error_msg = "Invalid email or password"
        elif "-11" in error_msg: error_msg = "Access denied (Blocked/Banned)"
        elif "-3" in error_msg: error_msg = "Too many requests, please wait"
        return jsonify({'success': False, 'error': error_msg}), 401

@app.route('/api/cloud/switch_account', methods=['POST'])
def cloud_switch_account():
    global active_mega_email, mega_sessions
    data = request.json or {}
    email = data.get('email')
    if email in mega_sessions:
        active_mega_email = email
        return jsonify({'success': True, 'active_email': active_mega_email})
    return jsonify({'success': False, 'error': 'Account not found'}), 404

@app.route('/api/cloud/check_auth', methods=['GET'])
def cloud_check_auth():
    global active_mega_email, mega_sessions
    accounts = []
    for email, session in mega_sessions.items():
        try:
            # Quick check if still valid
            quota_raw = session['client'].get_quota()
            quota = {
                'total': quota_raw.get('total', 0) if isinstance(quota_raw, dict) else 0,
                'used': quota_raw.get('space_used', quota_raw.get('used', 0)) if isinstance(quota_raw, dict) else 0
            }
            session['quota'] = quota # update quota
            accounts.append({
                'email': email,
                'user': session['info'],
                'quota': quota
            })
        except:
            # Session might have died
            pass
            
    return jsonify({
        'success': True, 
        'authenticated': len(accounts) > 0,
        'active_email': active_mega_email,
        'accounts': accounts
    })

@app.route('/api/cloud/logout', methods=['POST'])
def cloud_logout():
    global mega_sessions, active_mega_email
    data = request.json or {}
    email = data.get('email', active_mega_email)
    if email in mega_sessions:
        del mega_sessions[email]
        if active_mega_email == email:
            active_mega_email = list(mega_sessions.keys())[0] if mega_sessions else None
    return jsonify({'success': True, 'message': 'Logged out', 'active_email': active_mega_email})

@app.route('/api/cloud/files', methods=['GET'])
def cloud_list_files():
    global mega_sessions, active_mega_email
    email = request.args.get('email', active_mega_email)
    if not email or email not in mega_sessions:
        return jsonify({'success': False, 'error': 'Not authenticated'}), 401
        
    try:
        client = mega_sessions[email]['client']
        req_path = request.args.get('path', '').strip('/')
        parent_id = _get_node_by_path(req_path, client)
        if not parent_id:
             return jsonify({'success': False, 'error': 'Directory not found'}), 404
             
        files = client.get_files()
        items = []
        for k, v in files.items():
            if v.get('p') == parent_id:
                items.append({
                    'name': v.get('a', {}).get('n'),
                    'is_dir': v.get('t') == 1,
                    'size': v.get('s', 0),
                    'modified_at': v.get('ts', 0)
                })
                
        items.sort(key=lambda x: (not x['is_dir'], (x['name'] or '').lower()))
        return jsonify({'success': True, 'path': req_path, 'items': items})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/cloud/import_local', methods=['POST'])
def cloud_import_local():
    global mega_sessions, active_mega_email
    try:
        data = request.json or {}
        local_path = data.get('path') # relative to SCRAPED_DIR or static/uploads?
        file_type = data.get('type') # 'image' or 'video'
        page_title = data.get('title', 'Imported Media').strip() or 'Imported Media'
        email = data.get('email', active_mega_email)
        
        if not email or email not in mega_sessions:
            return jsonify({'success': False, 'error': 'Cloud login required'}), 401
            
        if not local_path:
            return jsonify({'success': False, 'error': 'No file path provided'}), 400

        # Handle local path check
        # Usually scraped files are in SCRAPED_DIR
        # If path starts with /download/ we strip it
        clean_path = local_path.split('?')[0] # remove cache busters
        if clean_path.startswith('/download/'):
            filename = clean_path.replace('/download/', '')
            disk_path = os.path.join(SCRAPED_DIR, filename)
        elif clean_path.startswith('http://') or clean_path.startswith('https://'):
            # The URL is an external link (like an m3u8 playlist or external video).
            # We need to temporarily download it to upload it to MEGA.
            filename = os.path.basename(requests.compat.urlparse(clean_path).path)
            if not filename:
                filename = 'stream.m3u8' if 'm3u8' in clean_path else 'video.mp4'
            
            temp_dir = os.path.join(PACKAGE_DIR, 'tmp_mega')
            os.makedirs(temp_dir, exist_ok=True)
            disk_path = os.path.join(temp_dir, filename)
            
            try:
                # Download external file
                r = requests.get(clean_path, stream=True, timeout=10)
                r.raise_for_status()
                with open(disk_path, 'wb') as f:
                    for chunk in r.iter_content(chunk_size=8192):
                        f.write(chunk)
            except Exception as e:
                return jsonify({'success': False, 'error': f'Failed to download external media: {str(e)}'}), 400
        else:
            # Ad-hoc filenames
            filename = os.path.basename(clean_path)
            disk_path = os.path.join(SCRAPED_DIR, filename)
            
        if not os.path.exists(disk_path):
             return jsonify({'success': False, 'error': f'File not found: {filename}'}), 404

        client = mega_sessions[email]['client']
        
        # 1. Ensure Root Folder for this Page
        root_node = _get_node_by_path('', client)
        page_node = _get_or_create_node(page_title, root_node, client)
        
        # 2. Ensure Type Folder (Images / Videos)
        type_folder_name = "Images" if file_type == 'image' else "Videos"
        type_node = _get_or_create_node(type_folder_name, page_node, client)
        
        # 3. Upload
        client.upload(disk_path, dest=type_node)
        
        # 4. Cleanup if it was a temporary external download
        if clean_path.startswith('http://') or clean_path.startswith('https://'):
            try:
                os.remove(disk_path)
            except:
                pass
        
        return jsonify({'success': True, 'message': f'Saved to {page_title}/{type_folder_name}'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/cloud/upload', methods=['POST'])
def cloud_upload():
    global mega_sessions, active_mega_email
    email = request.form.get('email', active_mega_email)
    if not email or email not in mega_sessions:
        return jsonify({'success': False, 'error': 'Not authenticated'}), 401
    try:
        client = mega_sessions[email]['client']
        req_path = request.form.get('path', '').strip('/')
        parent_id = _get_node_by_path(req_path, client)
        if not parent_id:
            return jsonify({'success': False, 'error': 'Invalid path'}), 403
            
        if 'file' not in request.files:
            return jsonify({'success': False, 'error': 'No file part'}), 400
            
        file = request.files['file']
        if file.filename == '':
            return jsonify({'success': False, 'error': 'No selected file'}), 400
            
        from werkzeug.utils import secure_filename
        filename = secure_filename(file.filename)
        
        temp_dir = os.path.join(PACKAGE_DIR, 'tmp_mega')
        os.makedirs(temp_dir, exist_ok=True)
        temp_path = os.path.join(temp_dir, filename)
        file.save(temp_path)
        
        client.upload(temp_path, parent_id)
        
        try: os.remove(temp_path)
        except: pass
        
        return jsonify({'success': True, 'message': 'File uploaded successfully'})
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/cloud/mkdir', methods=['POST'])
def cloud_mkdir():
    global mega_sessions, active_mega_email
    data = request.json or {}
    email = data.get('email', active_mega_email)
    if not email or email not in mega_sessions:
        return jsonify({'success': False, 'error': 'Not authenticated'}), 401
    try:
        client = mega_sessions[email]['client']
        req_path = data.get('path', '').strip('/')
        folder_name = data.get('folder_name', '').strip()
        
        if not folder_name:
            return jsonify({'success': False, 'error': 'Folder name required'}), 400
            
        parent_id = _get_node_by_path(req_path, client)
        if not parent_id:
             return jsonify({'success': False, 'error': 'Invalid path'}), 403
             
        client.create_folder(folder_name, parent_id)
        return jsonify({'success': True, 'message': 'Folder created'})
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/cloud/delete', methods=['DELETE'])
def cloud_delete():
    global mega_sessions, active_mega_email
    data = request.json or {}
    email = data.get('email', active_mega_email)
    if not email or email not in mega_sessions:
        return jsonify({'success': False, 'error': 'Not authenticated'}), 401
    try:
        client = mega_sessions[email]['client']
        req_path = data.get('path', '').strip('/')
        item_name = data.get('item_name', '').strip()
        
        parent_id = _get_node_by_path(req_path, client)
        if not parent_id:
             return jsonify({'success': False, 'error': 'Path not found'}), 404
             
        node_id = None
        files = client.get_files()
        for k, v in files.items():
            if v.get('p') == parent_id and v.get('a', {}).get('n') == item_name:
                node_id = k
                break
        
        if not node_id:
             return jsonify({'success': False, 'error': 'Item not found'}), 404
             
        client.destroy(node_id)
        return jsonify({'success': True, 'message': 'Item deleted'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/cloud/download/<path:filepath>')
def cloud_download(filepath):
    global mega_sessions, active_mega_email
    email = request.args.get('email', active_mega_email)
    if not email or email not in mega_sessions:
        return "Not authenticated", 401
    try:
        client = mega_sessions[email]['client']
        node_id = _get_node_by_path(filepath, client)
        if not node_id:
            return "File not found", 404
            
        # Download to local temp folder, then serve it
        temp_dir = os.path.join(PACKAGE_DIR, 'tmp_mega_dl')
        os.makedirs(temp_dir, exist_ok=True)
        # find node object first
        files = client.get_files()
        node = {node_id: files[node_id]}
        downloaded_path = client.download(node, temp_dir)
        
        @after_this_request
        def remove_file(response):
            try: os.remove(downloaded_path)
            except: pass
            return response
            
        return send_file(downloaded_path, as_attachment=True)
    except Exception as e:
        return str(e), 500

# --- ADB WEB APIs ---

@app.route('/api/adb/status', methods=['GET'])
def adb_status():
    global _active_device
    ok, devices_out = _adb_run([ADB_CMD, 'devices'])
    connected, offline = [], []
    if ok:
        for line in devices_out.splitlines()[1:]:
            parts = line.strip().split('\t')
            if len(parts) == 2:
                if parts[1] == 'device':
                    connected.append(parts[0])
                elif parts[1] in ('offline', 'unauthorized'):
                    offline.append({'id': parts[0], 'status': parts[1]})
    
    if connected:
        _active_device = connected[0]
        return jsonify({
            'status': 'connected',
            'device_id': connected[0],
            'device_model': _adb_get_device_info(connected[0]),
            'other_devices': len(connected) - 1
        })
    elif offline:
        return jsonify({
            'status': 'error',
            'error_type': offline[0]['status'],
            'device_id': offline[0]['id']
        })
    
    return jsonify({'status': 'disconnected'})

@app.route('/api/adb/pair', methods=['POST'])
def adb_pair():
    data = request.json or {}
    ip = data.get('ip', '').strip()
    port = data.get('port', '').strip()
    code = data.get('code', '').strip()
    connect_port = data.get('connect_port', '').strip()
    
    if not (ip and port and code and connect_port):
        return jsonify({'success': False, 'error': 'Missing required fields'}), 400
        
    ok, out = _adb_run([ADB_CMD, 'pair', f'{ip}:{port}', code], timeout=20)
    if ok and ('success' in out.lower() or 'paired' in out.lower()):
        ok2, out2 = _adb_run([ADB_CMD, 'connect', f'{ip}:{connect_port}'], timeout=10)
        if ok2 and 'connected' in out2.lower():
            return jsonify({'success': True, 'message': 'Device paired and connected successfully!'})
        return jsonify({'success': False, 'error': f'Paired, but failed to connect: {out2}'})
    return jsonify({'success': False, 'error': f'Pairing failed: {out}'})

@app.route('/api/adb/apps', methods=['GET'])
def adb_apps():
    filter_type = request.args.get('type', 'all')
    search = request.args.get('search', '').lower()
    
    # Check connection first
    status_res = adb_status().json
    if status_res.get('status') != 'connected':
        return jsonify({'success': False, 'error': 'Device not connected'})
        
    all_pkgs = _adb_get_packages('third_party' if filter_type == 'third_party' else 'all')
    
    if filter_type == 'system':
        all_pkgs = [p for p in all_pkgs if p in KNOWN_BLOATWARE]
        
    results = []
    for pkg in all_pkgs:
        label = _get_app_label(pkg)
        if search and search not in pkg.lower() and search not in label.lower():
            continue
            
        app_type = 'normal'
        if pkg in CRITICAL_PACKAGES:
            app_type = 'critical'
        elif pkg in KNOWN_BLOATWARE:
            app_type = 'bloatware'
            
        results.append({
            'package': pkg,
            'label': label,
            'type': app_type
        })
        
    return jsonify({'success': True, 'apps': results})

@app.route('/api/adb/uninstall', methods=['POST'])
def adb_uninstall():
    data = request.json or {}
    pkg = data.get('package')
    label = data.get('label', pkg) # Accept label from frontend or default to pkg
    if not pkg:
        return jsonify({'success': False, 'error': 'Package required'}), 400
        
    # Get current device info for history tracking
    device_id, device_model = "", ""
    status_res = adb_status().json
    if status_res.get('status') == 'connected':
        device_id = status_res.get('device_id', '')
        device_model = status_res.get('device_model', '')
        
    # Safety Check natively implemented in backend just in case
    if pkg in CRITICAL_PACKAGES and not data.get('force_critical'):
        return jsonify({'success': False, 'error': 'CRITICAL_PACKAGE_WARNING'})
        
    def _log_history():
        if not device_id: return
        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            # Check if already in history first to avoid dupes
            c.execute('SELECT id FROM adb_history WHERE device_id=? AND package=?', (device_id, pkg))
            if not c.fetchone():
                c.execute('INSERT INTO adb_history (device_id, device_model, package, label) VALUES (?, ?, ?, ?)',
                          (device_id, device_model, pkg, label))
                conn.commit()
            conn.close()
        except Exception as e:
            print(f"Failed to log uninstall history: {e}")

    # Method 1
    ok, out = _adb_run([ADB_CMD, 'shell', 'pm', 'uninstall', '-k', '--user', '0', pkg])
    if ok and 'success' in out.lower():
        _log_history()
        return jsonify({'success': True, 'method': 'safe'})
        
    # Method 2
    ok, out = _adb_run([ADB_CMD, 'shell', 'pm', 'uninstall', '--user', '0', pkg])
    if ok and 'success' in out.lower():
        _log_history()
        return jsonify({'success': True, 'method': 'force'})
        
    # Method 3
    ok, out = _adb_run([ADB_CMD, 'shell', 'pm', 'disable-user', '--user', '0', pkg])
    if ok and ('disabled' in out.lower() or 'new state' in out.lower()):
        _log_history()
        return jsonify({'success': True, 'method': 'disable'})
        
    return jsonify({'success': False, 'error': out})

@app.route('/api/adb/history', methods=['GET'])
def adb_history():
    status_res = adb_status().json
    if status_res.get('status') != 'connected':
        return jsonify({'success': False, 'error': 'Device not connected'})
        
    device_id = status_res.get('device_id', '')
    if not device_id:
        return jsonify({'success': True, 'history': []})
        
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute('SELECT package, label, timestamp FROM adb_history WHERE device_id=? ORDER BY timestamp DESC', (device_id,))
        rows = c.fetchall()
        conn.close()
        
        history = [{'package': row['package'], 'label': row['label'], 'timestamp': row['timestamp']} for row in rows]
        return jsonify({'success': True, 'history': history})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/adb/reinstall', methods=['POST'])
def adb_reinstall():
    data = request.json or {}
    pkg = data.get('package')
    if not pkg:
        return jsonify({'success': False, 'error': 'Package required'}), 400
        
    ok, out = _adb_run([ADB_CMD, 'shell', 'cmd', 'package', 'install-existing', pkg])
    if ok and 'installed' in out.lower():
        return jsonify({'success': True, 'message': f'Successfully reinstalled {pkg}'})
    return jsonify({'success': False, 'error': out or 'Package unavailable for reinstall'})


def _run_playwright_scrape(url):
    """Internal: Actually run the Playwright scrape"""
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        
        # Stealth settings ke sath context
        context = browser.new_context(
            viewport={'width': 1920, 'height': 1080},
            user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        )
        
        page = context.new_page()
        
        try:
            # Heavy sites ke liye 30s ka timeout
            page.goto(url, timeout=30000, wait_until='domcontentloaded')
            
            # Smart wait: network idle hone tak ruko (max 10s)
            try:
                page.wait_for_load_state('networkidle', timeout=10000)
            except:
                pass  # Timeout ho gaya toh aage badho
            
            # Lazy loads trigger karne ke liye niche scroll karo
            page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            time.sleep(1)
            
            content = page.content()
            return content
        except Exception as e:
            print(f"❌ Playwright navigation failed: {e}")
            return None
        finally:
            browser.close()

def scrape_with_playwright(url, proxy=None):
    if not PLAYWRIGHT_AVAILABLE:
        return None
    
    try:
        return _run_playwright_scrape(url)
    except Exception as e:
        error_msg = str(e).lower()
        # Auto-install browsers if they're missing
        if 'playwright install' in error_msg or 'executable doesn' in error_msg or 'browser was not found' in error_msg:
            print("\n🔧 Playwright browsers not found. Auto-installing...")
            if install_playwright_browsers():
                try:
                    return _run_playwright_scrape(url)
                except Exception as e2:
                    print(f"❌ Playwright error after install: {e2}")
                    return None
        print(f"❌ Playwright error: {e}")
        return None


# --- OSINT HELPERS ---
def extract_emails(text):
    """Regex se emails nikalo"""
    # Sahi wala regex:
    # 1. Start with alnum/dots/dashes
    # 2. @ symbol
    # 3. Domain name (alnum/dashes)
    # 4. TLD (2+ chars)
    # Filter: length < 50, accidental image matches remove karo
    raw = re.findall(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', text)
    valid = []
    for email in set(raw):
        if len(email) > 50: continue
        if email.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg')): continue
        valid.append(email)
    return valid

def extract_phones(text):
    """Phone numbers nikalo (+91 aur intl formats par focus)"""
    phones = set()
    
    # 1. Strict Indian Mobile Numbers: +91 9876543210 / 9876543210 / 09876543210
    # Matches: +91-9876543210, +91 98765 43210, 9876543210
    # Indian mobiles ke liye [6-9] starting digit search karo
    indian_regex = r'(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?([6-9]\d{3}[\s\-]?\d{6})'
    for match in re.findall(indian_regex, text):
        # match[1] number wala part hai
        full_num = match[1].replace(' ', '').replace('-', '')
        if len(full_num) == 10:
             phones.add("+91 " + full_num)

    # 2. General International (Fallback) jaise +1 etc.
    # Explicit plus sign aur digits search karo
    intl_regex = r'\+(?:9[976]\d|8[987530]\d|6[987]\d|5[90]\d|42\d|3[875]\d|2[98654321]\d|9[8543210]|8[6421]|6[6543210]|5[87654321]|4[987654310]|3[9643210]|2[70]|7|1)\W*\d\W*\d\W*\d\W*\d\W*\d\W*\d\W*\d\W*\d\W*(\d{1,2})?'
    for p in re.findall(intl_regex, text):
         # Yeh thoda complex match hai, noise avoid karne ke liye simple rakhte hain
         pass 

    # 3. "Tel:" links ke liye simple grab
    # (Regex ne handle kar liya hoga par safe rehne ke liye)
    
    return list(phones)

def extract_locations(soup):
    """Physical addresses nikalo"""
    locations = set()
    
    # 1. Schema.org Parsing
    for item in soup.find_all(attrs={"itemtype": re.compile(r"schema.org/PostalAddress", re.I)}):
        text = item.get_text(separator=', ').strip()
        if len(text) > 10: locations.add(text)
        
    # 2. Google Maps Embeds
    for iframe in soup.find_all('iframe', src=True):
        if 'maps.google' in iframe['src']:
            # Query nikalne ki koshish karo
            match = re.search(r'q=([^&]+)', iframe['src'])
            if match:
                import urllib.parse
                addr = urllib.parse.unquote(match.group(1).replace('+', ' '))
                locations.add(addr)
    
    # 3. Heuristic Keywords (Footer/Contact)
    # Search ko footer ya contact sections tak limit rakho
    search_area = soup.find('footer') or soup.find(id='contact') or soup.body
    if search_area:
        text = search_area.get_text(separator=' ')
        # "Address: ..." ke liye rough regex
        matches = re.findall(r'(?:Address|Location|Office):\s*([a-zA-Z0-9,\.\-\s]{10,100})', text, re.I)
        for m in matches:
            locations.add(m.strip())

    return list(locations)


def extract_social_media(soup):
    """Social media profile links nikalo"""
    social_domains = {
        'facebook.com': 'Facebook',
        'twitter.com': 'Twitter',
        'x.com': 'X (Twitter)',
        'instagram.com': 'Instagram',
        'linkedin.com': 'LinkedIn',
        'youtube.com': 'YouTube',
        'tiktok.com': 'TikTok',
        'pinterest.com': 'Pinterest',
        'github.com': 'GitHub',
        'gitlab.com': 'GitLab',
        'discord.gg': 'Discord',
        't.me': 'Telegram'
    }
    found = {}
    for a in soup.find_all('a', href=True):
        href = a['href'].lower()
        for domain, name in social_domains.items():
            if domain in href and name not in found:
                # Share links avoid karne ke liye basic check
                if 'share' not in href and 'intent' not in href:
                    found[name] = a['href']
    
    return [{'platform': k, 'url': v} for k, v in found.items()]

def detect_tech_stack(soup, response):
    """Site par kaunsi technologies used hain woh check karo"""
    stack = set()
    
    # 1. Headers
    if 'Server' in response.headers:
        stack.add(f"Server: {response.headers['Server']}")
    if 'X-Powered-By' in response.headers:
        stack.add(f"Powered By: {response.headers['X-Powered-By']}")
    if 'Via' in response.headers:
        stack.add(f"Via: {response.headers['Via']}")
        
    # 2. Meta Tags
    generator = soup.find('meta', attrs={'name': 'generator'})
    if generator and generator.get('content'):
        stack.add(generator['content'])
        
    # 3. Scripts / HTML Patterns
    html_str = str(soup).lower()
    if 'wp-content' in html_str: stack.add('WordPress')
    if 'shopify' in html_str: stack.add('Shopify')
    if 'wix.com' in html_str: stack.add('Wix')
    if 'squarespace' in html_str: stack.add('Squarespace')
    if 'react' in html_str or '_next' in html_str: stack.add('React/Next.js')
    if 'vue' in html_str or 'nuxt' in html_str: stack.add('Vue.js')
    if 'bootstrap' in html_str: stack.add('Bootstrap')
    if 'tailwind' in html_str: stack.add('Tailwind CSS')
    if 'jquery' in html_str: stack.add('jQuery')
    if 'cloudflare' in html_str: stack.add('Cloudflare')
    if 'google-analytics' in html_str: stack.add('Google Analytics')
    
    return list(stack)

def ensure_textblob_corpora(download=False):
    """Ensure necessary NLTK corpora for TextBlob are downloaded"""
    try:
        import nltk
        needed = ['punkt', 'brown', 'averaged_perceptron_tagger']
        all_present = True
        for corpus in needed:
            try:
                nltk.data.find(f'tokenizers/{corpus}' if corpus == 'punkt' else f'corpora/{corpus}')
            except (LookupError, AttributeError):
                if download:
                    print(f"Downloading required AI data: {corpus}...")
                    nltk.download(corpus, quiet=True)
                else:
                    all_present = False
        return all_present
    except:
        return False

def analyze_ai_content(text):
    """Text analyze karo (sentiment, summary, readability, aur keywords)"""
    try:
        if not ensure_textblob_corpora(download=False):
            return {
                'skipped': True,
                'message': 'AI analysis skipped (Missing AI data).'
            }
            
        from textblob import TextBlob
        import re
        
        # Text clean karo
        clean_text = re.sub(r'\s+', ' ', text).strip()
        if not clean_text: return None
        
        blob = TextBlob(clean_text)
        sentiment = blob.sentiment
        
        # 1. Summarization (Simple Frequency-based)
        sentences = blob.sentences
        if len(sentences) > 0:
            # Simple summary: pehla sentence + 2 interesting sentences
            # NLTK/Spacy jaisi heavy libraries avoid karne ka tareeka
            summary_sentences = [sentences[0].string]
            
            # Baaki ke diverse sentences search karo
            remaining = sentences[1:]
            remaining.sort(key=lambda s: len(s.noun_phrases), reverse=True)
            for s in remaining[:2]:
                summary_sentences.append(s.string)
                
            summary = ' '.join(summary_sentences)
        else:
            summary = clean_text[:200] + "..."

        # 2. Readability (Flesch Reading Ease)
        # Formula: 206.835 - 1.015 (total words / total sentences) - 84.6 (total syllables / total words)
        words = blob.words
        num_sentences = len(sentences) or 1
        num_words = len(words) or 1
        
        # Syllable approximation (vowel groups)
        def count_syllables(word):
            word = word.lower()
            count = len(re.findall(r'[aeiouy]+', word))
            if word.endswith('e'): count -= 1
            return max(1, count)
            
        num_syllables = sum(count_syllables(w) for w in words)
        
        flesch_score = 206.835 - 1.015 * (num_words / num_sentences) - 84.6 * (num_syllables / num_words)
        
        readability_level = "Standard"
        if flesch_score > 80: readability_level = "Very Easy (Kids)"
        elif flesch_score > 60: readability_level = "Plain English"
        elif flesch_score > 40: readability_level = "Difficult (College)"
        else: readability_level = "Very Difficult (Academic)"

        # 3. Enhanced Keywords
        keywords = []
        seen = set()
        for phrase in blob.noun_phrases:
            p = phrase.lower().strip()
            # Junk aur chhote words filter karo
            if len(p) > 4 and p not in seen and not re.match(r'^\d+$', p) and len(keywords) < 12:
                keywords.append(phrase.title())
                seen.add(p)
                
        return {
            'sentiment': {
                'polarity': round(sentiment.polarity, 2),
                'subjectivity': round(sentiment.subjectivity, 2),
                'label': 'Positive' if sentiment.polarity > 0.1 else 'Negative' if sentiment.polarity < -0.1 else 'Neutral',
                'subjectivity_label': 'Opinionated' if sentiment.subjectivity > 0.5 else 'Objective'
            },
            'summary': summary,
            'readability': {
                'score': round(flesch_score, 1),
                'level': readability_level
            },
            'keywords': keywords
        }
    except Exception as e:
        print(f"AI Analysis failed: {e}")
        return None

def check_broken_links(url, soup, headers):
    """Broken links (404s) check karo (parallel mein)."""
    broken_links = []
    links_to_check = []
    
    from urllib.parse import urlparse, urljoin
    base_domain = urlparse(url).netloc

    # Links deduplicate karo
    seen_links = set()
    
    for a in soup.find_all('a', href=True):
        href = a['href']
        full_url = urljoin(url, href)
        
        # Faltu ya non-http links skip karo
        if not full_url.startswith('http') or full_url in seen_links:
            continue
            
        seen_links.add(full_url)
        
        is_internal = base_domain in full_url
        link_text = a.get_text().strip()[:50] # Text truncate karo
        
        links_to_check.append({
            'url': full_url,
            'text': link_text or "No Text",
            'is_internal': is_internal
        })

    # Iss demo ke performance ke liye 50 links tak limit rakho
    links_to_check = links_to_check[:50]

    def check_status(link_info):
        try:
            # Speed ke liye Head request use karo
            r = requests.head(link_info['url'], headers=headers, timeout=5, allow_redirects=True, verify=False)
            if r.status_code >= 400:
                return {
                    'url': link_info['url'],
                    'text': link_info['text'],
                    'status': r.status_code,
                    'is_internal': link_info['is_internal']
                }
        except Exception:
            # Agar head fail ho jaye toh get try karo (kuch servers HEAD block karte hain)
            try:
                r = requests.get(link_info['url'], headers=headers, stream=True, timeout=5, verify=False)
                if r.status_code >= 400:
                    return {
                        'url': link_info['url'],
                        'text': link_info['text'],
                        'status': r.status_code,
                        'is_internal': link_info['is_internal']
                    }
            except Exception:
                 return {
                    'url': link_info['url'],
                    'text': link_info['text'],
                    'status': 0, # Connection Error
                    'is_internal': link_info['is_internal']
                }
        return None

    # Parallel Execution
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
        results = list(executor.map(check_status, links_to_check))
    
    # Filter Nones
    broken_links = [r for r in results if r]
    
    return broken_links

def execute_scrape_logic(url, fetch_images=False, fetch_videos=False, fetch_fonts=False, crawl_depth=1, use_proxy=False, device='desktop', cancel_event=None):
    try:
        if not url.startswith('http'):
            url = 'https://' + url
           
        # Start performance session
        perf_tracker.start_session(url)

        # Connection Reuse ke liye Session
        session = requests.Session()
        
        # UA rotate karo
        ua = proxy_manager.get_random_ua()
        headers = {'User-Agent': ua}
        print(f"Using UA: {ua}")
        
        # SSL warnings band karo
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        
        perf_tracker.record_phase("Setup & Proxy")
        
        try:
            response = None
            if use_proxy:
                # Smart Learning ke liye Domain nikalo
                from urllib.parse import urlparse
                domain = urlparse(url).netloc
                
                # Task Type decide karo
                task_type = 'general'
                if fetch_videos: task_type = 'video'
                elif fetch_images: task_type = 'image'

                # Smart Loop: Fetch up to 5 prioritized proxies (best first)
                print(f"Selecting prioritized proxies for {domain} (Task: {task_type})...")
                prioritized_proxies = proxy_manager.get_prioritized_proxies(domain, task_type, count=5)
                
                for attempt, proxy in enumerate(prioritized_proxies):
                    if not proxy: 
                        break 

                    print(f"Using proxy: {proxy} (Attempt {attempt+1})")
                    proxies = {'http': proxy, 'https': proxy}
                    try:
                        # SSL errors bypass karne ke liye verify=False
                        session.proxies = proxies
                        session.verify = False
                        response = session.get(url, headers=headers, timeout=30)
                        if response.status_code == 200:
                            # SUCCESS: Model train karo
                            print(f"✅ Proxy {proxy} worked for {domain} ({task_type}). Boosting score!")
                            proxy_manager.report_success(proxy, domain, task_type, True)
                            break
                        else:
                            # FAIL (Non-200): Model train karo
                            print(f"❌ Proxy {proxy} failed for {domain} ({task_type}) (Status {response.status_code}). Penalizing.")
                            proxy_manager.report_success(proxy, domain, task_type, False)
                    except Exception as e:
                        # FAIL (Exception): Model train karo
                        print(f"❌ Proxy {proxy} error for {domain} ({task_type}): {e}. Penalizing.")
                        proxy_manager.report_success(proxy, domain, task_type, False)
                        continue
                            
                if response is None or response.status_code != 200:
                     print("All proxies failed. Falling back to direct connection.")
                     session.proxies = {}
                     session.verify = False
                     response = session.get(url, headers=headers, timeout=30)
            else:
                # Direct Request (SPA Check ke sath)
                block_domains = ['linkedin.com', 'instagram.com', 'facebook.com', 'twitter.com', 'x.com', 'xhamster', 'pornhub', 'xnxx']
                if any(domain in url.lower() for domain in block_domains):
                    print(f"High-Security Domain detected. Skipping direct requests...")
                    response = None # Playwright force karo
                else:
                    session.verify = False
                    response = session.get(url, headers=headers, timeout=30)
            
            # Block ya failure check karo
            if response and response.status_code in [403, 401, 406, 429]:
                 print(f"⚠️ Access Denied ({response.status_code}). Triggering Headless Browser...")
                 response = None # Force Playwright

            if response is None:
                raise Exception("SPA/Auth Wall ke liye Playwright force karo")

            response.raise_for_status()
            perf_tracker.record_phase("Fetch Content")

        except Exception as e:
            # Agar requests fail hon toh Playwright use karo
            print(f"Requests failed ({e}). Attempting Playwright Fallback...")
            if PLAYWRIGHT_AVAILABLE:
                pw_html = scrape_with_playwright(url)
                if pw_html:
                    # Compatibility ke liye mock response object
                    class MockResponse:
                        def __init__(self, text):
                            self.text = text
                            self.content = text.encode('utf-8')
                            self.status_code = 200
                            self.headers = {}
                    response = MockResponse(pw_html)
                else:
                    return {'success': False, 'error': f'Request failed and Playwright fallback failed: {str(e)}'}
            else:
                error_msg = f"Request failed: {str(e)}"
                if response and response.status_code == 404:
                    error_msg += "\n💡 Tip: URL might be expired or the site is blocking direct requests. Install Playwright for better results: pip install webtools-cli[playwright]"
                else:
                    error_msg += "\n💡 Tip: Try installing Playwright for better bypassing: pip install webtools-cli[playwright]"
                return {'success': False, 'error': error_msg}

        if cancel_event and cancel_event.is_set():
            return {'success': False, 'error': 'Scrape cancelled by user'}

        soup = BeautifulSoup(response.text, 'html.parser')
        perf_tracker.record_phase("HTML Parsing")

        # --- HONEYPOT DETECTOR (Security Scout) ---
        security_report = {'level': 'LOW', 'threats': [], 'honeypots': 0}
        
        # 1. Status Code Check
        if response.status_code in [403, 406, 429, 503]:
            security_report['threats'].append(f"Suspicious Status Code: {response.status_code}")
            security_report['level'] = 'HIGH'

        # 2. Keyword Analysis (Anti-Bot)
        page_text_lower = response.text.lower()
        threat_keywords = ['cloudflare', 'managed challenge', 'captcha', 'security check', 'access denied', 'waf']
        found_threats = [kw for kw in threat_keywords if kw in page_text_lower]
        if found_threats:
            security_report['threats'].append(f"Anti-Bot Detected: {', '.join(found_threats)}")
            if 'captcha' in found_threats or 'challenge' in found_threats:
                 security_report['level'] = 'HIGH'
            elif security_report['level'] == 'LOW':
                 security_report['level'] = 'MEDIUM'

        # 3. Honeypot Link Detection (CSS Traps)
        # Aise links nikalo jo bots ko dikhte hain par humans ko nahi
        honeypot_links = 0
        for a in soup.find_all('a', style=True):
            style = a['style'].lower().replace(' ', '')
            if 'display:none' in style or 'visibility:hidden' in style or 'opacity:0' in style:
                honeypot_links += 1
        
        if honeypot_links > 0:
            security_report['honeypots'] = honeypot_links
            security_report['threats'].append(f"Honeypot Traps: {honeypot_links} hidden links found")
            if security_report['level'] == 'LOW': security_report['level'] = 'MEDIUM'
        # ------------------------------------------
        
        # Containers initialize karo
        videos = []
        video_count = 0
        images = []
        image_count = 0
        seen_images = set()

        # Helper validation
        def cleaner_url_validator(url):
            try:
                # Http se start hona chahiye, dot hona chahiye, spaces nahi
                if not url.startswith('http'): return False
                if ' ' in url: return False
                if '.' not in url.split('://')[1]: return False
                return True
            except:
                return False

        # Turbo-Fetch (Parallel Chunk Download) ke liye helper
        def download_file_turbo(url, filepath):
            try:
                # 1. Size nikalo
                head = session.head(url, headers=headers, timeout=5)
                size = int(head.headers.get('content-length', 0))
                
                # 2MB se bade files ke liye Turbo use karo
                if size < 2 * 1024 * 1024:
                    return False 

                print(f"Turbo-Fetch active: {os.path.basename(filepath)} ({size/1024/1024:.1f} MB)")
                
                # 2. Chunks calculate karo (8 parts)
                num_chunks = 8
                chunk_size = size // num_chunks
                chunks = []
                for i in range(num_chunks):
                    start = i * chunk_size
                    end = start + chunk_size - 1 if i < num_chunks - 1 else size - 1
                    chunks.append((start, end, i))
                
                # 3. Parallel Download
                file_data = bytearray(size)
                
                def download_chunk(c):
                    start, end, idx = c
                    h = headers.copy()
                    h['Range'] = f'bytes={start}-{end}'
                    r = session.get(url, headers=h, timeout=20)
                    if r.status_code in [200, 206]:
                        # Seedha buffer mein likho
                        file_data[start:end+1] = r.content
                        return True
                    return False

                with concurrent.futures.ThreadPoolExecutor(max_workers=8) as exc:
                    futures = [exc.submit(download_chunk, c) for c in chunks]
                    concurrent.futures.wait(futures)
                    
                # 4. Disk par save karo
                with open(filepath, 'wb') as f:
                    f.write(file_data)
                    
                return True
                
            except Exception as e:
                print(f"Turbo failed: {e}")
                return False

        def process_video_download_task(task_item):
            v_url, quality, title_hint = task_item
            
            # Sabse pehle m3u8 (HLS) check karo
            if v_url.split('?')[0].lower().endswith('.m3u8'):
                 return {
                    'url': v_url,
                    'original_url': v_url,
                    'filename': 'Stream.m3u8',
                    'external': True,
                    'is_m3u8': True,
                    'quality': quality or 'auto'
                }

            # RETRY LOOP (Max 3 attempts)
            for attempt in range(3):
                try:
                    # verify=False use karo
                    # Stability ke liye 15s timeout, stream=True
                    vid_data = session.get(v_url, headers=headers, timeout=15, stream=True)
                    
                    if vid_data.status_code == 200:
                        content_type = vid_data.headers.get('content-type', '').lower()
                        
                        # Minimum size filter: 2MB se chhoti videos skip karo
                        content_length = vid_data.headers.get('content-length')
                        if content_length:
                            size_mb = int(content_length) / (1024 * 1024)
                            if size_mb < 2:
                                return None
                        
                        if 'video' in content_type or 'octet-stream' in content_type or v_url.endswith(('.mp4', '.webm', '.mov')) or 'mpegurl' in content_type:
                            if 'mpegurl' in content_type or v_url.split('?')[0].lower().endswith('.m3u8'):
                                 return {
                                    'url': v_url,
                                    'original_url': v_url,
                                    'filename': 'Stream.m3u8',
                                    'external': True,
                                    'is_m3u8': True
                                }
                            filename = os.path.basename(v_url.split('?')[0]) or 'video.mp4'
                            if not filename.endswith(('.mp4', '.webm', '.ogg', '.mov', '.avi', '.mkv')):
                                filename += '.mp4'
                            
                            # Title sanitize karo aur filename generate karo

                            
                            if title_hint:
                                safe_title = re.sub(r'[^a-zA-Z0-9_\-\. ]', '', title_hint).strip().replace(' ', '_')[:50]
                                if safe_title:
                                    base, ext = os.path.splitext(filename)
                                    filename = f"{safe_title}_{uuid.uuid4().hex[:8]}{ext}"
                                else:
                                    base, ext = os.path.splitext(filename)
                                    if quality and quality != 'unknown':
                                         filename = f"{base}_{quality}_{uuid.uuid4().hex[:8]}{ext}"
                                    else:
                                         filename = f"{base}_{uuid.uuid4().hex[:8]}{ext}"
                            else:
                                base, ext = os.path.splitext(filename)
                                if quality and quality != 'unknown':
                                     filename = f"{base}_{quality}_{uuid.uuid4().hex[:8]}{ext}"
                                else:
                                     filename = f"{base}_{uuid.uuid4().hex[:8]}{ext}"

                            filepath = os.path.join(SCRAPED_DIR, 'videos', filename)
                            
                            # Pehle TURBO FETCH try karo
                            if not download_file_turbo(v_url, filepath):
                                # Standard stream par wapas jao (fallback)
                                with open(filepath, 'wb') as f:
                                    for chunk in vid_data.iter_content(chunk_size=8192):
                                        f.write(chunk)
                            return {
                            'url': f'/download/videos/{filename}',
                            'original_url': v_url,
                            'filename': filename,
                            'external': False,
                            'quality': quality
                            }
                    elif vid_data.status_code in [403, 404, 401]:
                        # In errors par retry mat karo
                        return None
                        
                except Exception as ex:
                    # Sirf aakhri attempt par poora error print karo
                    if attempt == 2:
                        err_str = str(ex)
                        if 'NameResolutionError' in err_str:
                             print(f"⚠️ DNS Error (Ad/Tracker ho sakta hai)")
                        elif 'RemoteDisconnected' in err_str:
                             print(f"⚠️ Connection Dropped: {v_url}")
                        else:
                             print(f"❌ Failed {v_url}: {ex}")
                    else:
                        time.sleep(0.3) # Retry se pehle thoda wait karo
                        continue
            return None

        # OpenCV Image Validation
        def validate_image_quality(image_bytes):
            try:
                import cv2
                import numpy as np
                
                # Image decode karo
                nparr = np.frombuffer(image_bytes, np.uint8)
                img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
                
                if img is None: return False
                
                # Check 1: Resolution (Chhote icons/thumbnails skip karo)
                h, w, _ = img.shape
                # Increased strictness from 50 to 150
                if w < 150 or h < 150: 
                    return False
                
                # Check 2: Variance (Solid colors ya flat images)
                gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                variance = cv2.Laplacian(gray, cv2.CV_64F).var()
                # Increased strictness from 50 to 100
                if variance < 100: 
                    return False # Zyada blurry ya flat hai
                
                # Check 3: Entropy (Information density)
                hist = cv2.calcHist([gray], [0], None, [256], [0, 256])
                hist_norm = hist.ravel() / hist.sum()
                logs = np.log2(hist_norm + 0.0001)
                entropy = -np.sum(hist_norm * logs)
                
                # Increased strictness from 3.5 to 5.0
                if entropy < 5.0: 
                    return False # Information kam hai
                
                return True
            except Exception as e:
                return True # Safe rehne ke liye fail open karo

        def is_valuable_media(url_path, element, media_type='image'):
            """Ads aur logos ke liye filtering logic."""
            try:
                # 1. URL Path Keywords
                lower_url = url_path.lower()
                ad_keywords = [
                    'ad', 'advert', 'banner', 'doubleclick', 'googleads', 
                    'syndication', 'amazon-adsystem', 'wp-content/ads/', 
                    'promoted', 'sponsored', 'pixel', 'tracking', 'taboola', 'outbrain'
                ]
                # Logos
                logo_keywords = ['logo', 'brand-logo', 'header-logo', 'footer-logo', 'favicon']
                
                # Ads check karo
                if any(k in lower_url for k in ad_keywords):
                    return False
                
                # Logos check karo
                if any(k in lower_url for k in logo_keywords):
                    return False
                
                # 2. Metadata (Alt/Title)
                alt = element.get('alt', '').lower() if element.get('alt') else ""
                title = element.get('title', '').lower() if element.get('title') else ""
                metadata_text = f"{alt} {title}"
                
                if any(k in metadata_text for k in ['ad ', 'ads ', 'advertisement', 'sponsored', 'logo', 'branding']):
                    return False
                
                # 3. CSS Metadata (Class/ID)
                classes = " ".join(element.get('class', [])) if isinstance(element.get('class'), list) else str(element.get('class', ''))
                id_val = str(element.get('id', ''))
                
                # Parents check karo (simple BS4 method)
                parent_context = ""
                parent = element.parent
                levels = 0
                while parent and levels < 3:
                    p_classes = " ".join(parent.get('class', [])) if isinstance(parent.get('class'), list) else str(parent.get('class', ''))
                    parent_context += p_classes + " " + str(parent.get('id', '')) + " "
                    parent = parent.parent
                    levels += 1
                
                context_text = (classes + " " + id_val + " " + parent_context).lower()
                bad_contexts = [' ad ', ' ads ', 'banner', 'logo', 'brand', 'sponsored', 'advert', 'widget-area']
                if any(k in context_text for k in bad_contexts):
                    # Header ya sidebar check karo (risk areas hain)
                    if any(x in context_text for x in ['header', 'sidebar', 'footer', 'nav']):
                        return False

                # 4. Dimensions (sirf image ke liye)
                width = element.get('width')
                height = element.get('height')
                if width and height:
                    try:
                        w = int(width)
                        h = int(height)
                        if h > 0:
                            ratio = w / h
                            # Banners aksar bahut wide ya tall hote hain
                            if (ratio > 4 or ratio < 0.25) and (w < 900 and h < 900):
                                return False
                    except:
                        pass

                return True
            except:
                return True # Fail open

        # Images download karne ke liye helper
        def process_image_download_task(img_src):
            try:
                img_url = requests.compat.urljoin(url, img_src)
                img_data = requests.get(img_url, headers=headers, timeout=3, verify=False)
                if img_data.status_code == 200:
                    content = img_data.content
                    
                    # QUALITY CHECK KARO
                    if not validate_image_quality(content):
                        return None
                    
                    filename = os.path.basename(img_url.split('?')[0]) or 'image.jpg'
                    if not filename.endswith(('.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg')):
                        filename += '.jpg'
                    

                    
                    image_hash = hashlib.md5(content).hexdigest()
                    
                    filename = f"{uuid.uuid4().hex[:8]}_{filename}"

                    filepath = os.path.join(SCRAPED_DIR, 'images', filename)
                    with open(filepath, 'wb') as f:
                        f.write(content)
                    return (img_src, f'images/{filename}', f'/download/images/{filename}', image_hash, filepath)
            except:
                pass
            return None

        # CSS nikalo
        css_content = []
        for style in soup.find_all('style'):
            css_content.append(style.string or '')
            style.extract()
        # Parallel CSS/JS fetching
        css_tasks = []
        for link in soup.find_all('link', rel='stylesheet'):
            href = link.get('href')
            if href: css_tasks.append((link, href))
            
        js_tasks = []
        js_content = []
        for script in soup.find_all('script'):
            script_type = script.get('type', '').lower()
            if script_type and script_type not in ['text/javascript', 'application/javascript', 'module']:
                script.extract()
                continue
            if script.string and not script.get('src'):
                js_content.append(script.string)
                script.extract()
            elif script.get('src'):
                js_tasks.append((script, script.get('src')))

        def fetch_css(task):
            link_node, href = task
            try:
                css_url = requests.compat.urljoin(url, href)
                css_resp = session.get(css_url, headers=headers, timeout=5)
                return f'/* From {href} */\n' + css_resp.text
            except:
                return None

        def fetch_js(task):
            script_node, src = task
            try:
                js_url = requests.compat.urljoin(url, src)
                js_resp = session.get(js_url, headers=headers, timeout=5)
                return f'// From {src}\n' + js_resp.text
            except:
                return None

        # Fetch in parallel
        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
            css_futures = [executor.submit(fetch_css, t) for t in css_tasks]
            js_futures = [executor.submit(fetch_js, t) for t in js_tasks]
            
            for future in concurrent.futures.as_completed(css_futures):
                res = future.result()
                if res: css_content.append(res)
                
            for future in concurrent.futures.as_completed(js_futures):
                res = future.result()
                if res: js_content.append(res)

        # Remove original tags
        for t, _ in css_tasks: t.extract()
        for t, _ in js_tasks: t.extract()
        
        # Image Tasks collect karo
        image_tasks = []
        if fetch_images:
            os.makedirs(os.path.join(SCRAPED_DIR, 'images'), exist_ok=True)
            
            # Exclude karne ke liye Video Posters ID karo
            poster_blacklist = set()
            for video in soup.find_all('video'):
                poster = video.get('poster')
                if poster: poster_blacklist.add(poster)
            
            for img in soup.find_all('img'):
                if len(image_tasks) >= 50: break # Limit to 50 images to prevent timeout
                src = img.get('src') or img.get('data-src') or img.get('data-lazy-src')
                # Also check srcset for higher quality images
                if not src:
                    srcset = img.get('srcset')
                    if srcset:
                        # Take the first URL from srcset
                        src = srcset.split(',')[0].strip().split(' ')[0]
                if src and not src.startswith('data:') and not src.lower().endswith('.svg'):
                     # Make absolute URL if relative
                     if not src.startswith('http'):
                         src = requests.compat.urljoin(url, src)
                     # Exclude video posters
                     if src in poster_blacklist:
                         continue
                         
                     # VALUABLE MEDIA FILTER (Ads/Logos)
                     if not is_valuable_media(src, img):
                         continue
                         
                     # Extension check - accept common image extensions OR extensionless image URLs (CDNs)
                     lower_src = src.lower().split('?')[0]  # Remove query params
                     has_image_ext = any(lower_src.endswith(ext) for ext in ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.tiff', '.avif'])
                     is_image_cdn = any(cdn in lower_src for cdn in ['/image/', '/images/', '/photo/', '/photos/', '/img/', '/media/', '/uploads/'])
                     if has_image_ext or is_image_cdn:
                        image_tasks.append(src)

        # =========================================================
        # PERFORMANCE OPTIMIZATION: Images PEHLE process honge
        # Images download faster than videos, so they're prioritized
        # to improve perceived performance and provide quicker feedback.
        # =========================================================
        
        # Image Downloads execute karo
        if fetch_images and image_tasks:
            seen_hashes = set()
            total_images = len(image_tasks)
            completed_images = 0
            with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
                future_to_img = {executor.submit(process_image_download_task, src): src for src in image_tasks}
                try:
                    while any(not f.done() for f in future_to_img):
                        if cancel_event and cancel_event.is_set():
                            raise RuntimeError("Scrape cancelled by user")
                        time.sleep(0.1)
                except RuntimeError as e:
                    print(f"\n⚠️ Cancelling image downloads: {e}")
                    executor.shutdown(wait=False, cancel_futures=True)
                    return {'success': False, 'error': str(e)}

                for future in concurrent.futures.as_completed(future_to_img):
                    if cancel_event and cancel_event.is_set():
                        break
                    completed_images += 1
                    progress = int((completed_images / total_images) * 100)
                    frames = ['🌑','🌒','🌓','🌔','🌕','🌖','🌗','🌘']
                    spinner = frames[completed_images % len(frames)]
                    sys.stdout.write(f'\r{spinner} Images: {completed_images}/{total_images} ({progress}%)   ')
                    sys.stdout.flush()
                    result = future.result()
                    if result:
                        orig_src, relative_path, download_path, img_hash, filepath = result
                        if img_hash in seen_hashes:
                            # Duplicate content, delete file
                            try:
                                os.remove(filepath)
                            except:
                                pass
                            continue
                        seen_hashes.add(img_hash)
                        # Update soup
                        for img in soup.find_all('img', src=orig_src):
                            img['src'] = relative_path
                        images.append(download_path)
                        image_count += 1
            sys.stdout.write(f'\r🌕 Images Done! ✅ {image_count} accepted     \n')
            sys.stdout.flush()
        # Video Tasks collect karo
        video_tasks = []
        if fetch_videos:
            os.makedirs(os.path.join(SCRAPED_DIR, 'videos'), exist_ok=True)
            # -------------------------------------------------------------------------
            # RESOURCE SNIFFER (Deep Scan)
            # Scans raw HTML/JS for hidden video links (mp4, m3u8, etc)
            # -------------------------------------------------------------------------
            # Video extensions wale links dhundhne ka pattern
            # Handles escaped slashes (common in JSON)
            # Captures: "https://example.com/video.mp4"
            sniffer_regex = r'(https?:\\?\/\\?\/[^"\'\s<>]+?\.(?:mp4|m3u8|webm|mov|mkv|ts|flv|wmv|3gp|f4v|mpg|mpeg|avi|m4v|ogg)(?:[^"\'\s<>]*)?)'
            matches = re.findall(sniffer_regex, response.text)
            sniffed_count = 0
            for match in matches:
                # Fix escaped slashes (e.g. from JSON: https:\/\/example.com)
                clean_url = match.replace('\\/', '/')
                # Basic validation
                if len(clean_url) > 200: continue # Likely garbage
                if not cleaner_url_validator(clean_url): continue

                # Sniffed links ke liye AD FILTER
                ad_domains = ['doubleclick', 'adnxs', 'amazon-adsystem', 'googlesyndication', 'taboola', 'outbrain', 'ads-twitter', 'fb-ads']
                if any(ad in clean_url.lower() for ad in ad_domains):
                    continue
                # URL mein quality clues check karo
                quality = 'unknown'
                lower_url = clean_url.lower()
                if '1080' in lower_url: quality = '1080p'
                elif '720' in lower_url: quality = '720p'
                elif '480' in lower_url: quality = '480p'
                # Avoid duplicates
                is_duplicate = False
                # Avoid duplicates
                is_duplicate = False
                for existing_url, _, _ in video_tasks:
                     if existing_url == clean_url: is_duplicate = True; break
                for existing_vid in videos:
                     if existing_vid['original_url'] == clean_url: is_duplicate = True; break
                if not is_duplicate:
                    if any(x in clean_url for x in ['youtube', 'youtu.be', 'vimeo', 'dailymotion']):
                         pass # Skip external for simple sniffer, usually handled by iframes
                    else:
                        video_tasks.append((clean_url, quality, f"sniffed_video_{sniffed_count}"))
                        sniffed_count += 1
            # Video tags dhundho (sources aur qualities scan karo)
            for video in soup.find_all('video'):
                # VALUABLE MEDIA FILTER
                if not is_valuable_media(video.get('src', ''), video, 'video'):
                    continue
                
                # Check for source tags
                sources = video.find_all('source')
                found_src = False
                
                if sources:
                    for source in sources:
                        src = source.get('src')
                        if src:
                            # Detect quality from attributes or text
                            quality = 'unknown'
                            s_text = (str(source) + src).lower()
                            if '1080' in s_text: quality = '1080p'
                            elif '720' in s_text: quality = '720p'
                            elif '480' in s_text: quality = '480p'
                            if src.startswith('http'):
                                video_url = src
                            else:
                                video_url = requests.compat.urljoin(url, src)
                            # Check external
                            if any(x in video_url for x in ['youtube', 'youtu.be', 'vimeo', 'dailymotion']):
                                videos.append({'url': video_url,'original_url': video_url,'filename': 'External Video','external': True})
                                video_count += 1
                            else:
                                # Extract Title from Video Tag or Context
                                video_title = video.get('title') or video.get('aria-label')
                                if not video_title:
                                    # Try previous sibling header
                                    prev = video.find_previous(['h1', 'h2', 'h3', 'h4', 'h5', 'h6'])
                                    if prev: video_title = prev.get_text().strip()
                                
                                video_tasks.append((video_url, quality, video_title))
                    found_src = True

                # Fallback to direct src on video tag
                if not found_src:
                    src = video.get('src')
                    if src:
                        if src.startswith('http'):
                            video_url = src
                        else:
                            video_url = requests.compat.urljoin(url, src)
                        
                        if any(x in video_url for x in ['youtube', 'youtu.be', 'vimeo', 'dailymotion']):
                             videos.append({'url': video_url,'original_url': video_url,'filename': 'External Video','external': True})
                             video_count += 1
                        else:
                            # Extract Title
                            video_title = video.get('title') or video.get('aria-label')
                            if not video_title:
                                prev = video.find_previous(['h1', 'h2', 'h3', 'h4', 'h5', 'h6'])
                                if prev: video_title = prev.get_text().strip()
                            video_tasks.append((video_url, 'unknown', video_title))
            # Video files ke links (a tags) dhundho
            for a in soup.find_all('a'):
                href = a.get('href')
                if href:
                    # VALUABLE MEDIA FILTER
                    if not is_valuable_media(href, a, 'video'):
                        continue
                    lower_href = href.lower()
                    if lower_href.endswith(('.mp4', '.webm', '.ogg', '.mov', '.avi', '.mkv', '.m4v', '.m3u8', '.flv', '.wmv', '.3gp', '.f4v', '.mpg', '.mpeg', '.ts')) or \
                       (('/video/' in lower_href or '/videos/' in lower_href) and '.' in list(filter(None, lower_href.split('/')))[-1]):
                        # Detect quality from link text
                        quality = 'unknown'
                        a_text = a.get_text().lower()
                        if '1080' in a_text: quality = '1080p'
                        elif '720' in a_text: quality = '720p'
                        elif '480' in a_text: quality = '480p'
                        if href.startswith('http'):
                            video_url = href
                        else:
                            video_url = requests.compat.urljoin(url, href)
                        if any(x in video_url for x in ['youtube', 'youtu.be', 'vimeo', 'dailymotion']):
                            videos.append({'url': video_url,'original_url': video_url,'filename': 'External Video','external': True})
                            video_count += 1
                        else:
                            # Extract Title from Link Text or Attributes
                            video_title = a.get('title') or a.get('aria-label') or a.get_text().strip()
                            if not video_title:
                                prev = a.find_previous(['h1', 'h2', 'h3', 'h4', 'h5', 'h6'])
                                if prev: video_title = prev.get_text().strip()
                            
                            # Fallback to Page Title if single video or very few
                            if not video_title:
                                page_title = soup.title.string if soup.title else ""
                                if page_title:
                                     # Clean up page title (remove site name usually at end)
                                    video_title = page_title.split('|')[0].split('-')[0].strip()


                            video_tasks.append((video_url, quality, video_title))

            # Find iframes with video embeds
            for iframe in soup.find_all('iframe'):
                src = iframe.get('src', '')
                # VALUABLE MEDIA FILTER
                if not is_valuable_media(src, iframe, 'video'):
                    continue
                if any(x in src for x in ['youtube', 'youtu.be', 'vimeo', 'dailymotion']):
                     if not any(v['original_url'] == src for v in videos):
                        videos.append({'url': src,'original_url': src,'filename': f'Embed: {src.split("/")[2]}','external': True,'quality': 'unknown'})
                        video_count += 1
        # Video Downloads execute karo
        if fetch_videos and video_tasks:
            total_videos = len(video_tasks)
            completed_videos = 0
            with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
                future_to_vid = {executor.submit(process_video_download_task, item): item for item in video_tasks}
                try:
                    while any(not f.done() for f in future_to_vid):
                        if cancel_event and cancel_event.is_set():
                            raise RuntimeError("Scrape cancelled by user")
                        time.sleep(0.1)
                except RuntimeError as e:
                    print(f"\n⚠️ Cancelling video downloads: {e}")
                    executor.shutdown(wait=False, cancel_futures=True)
                    return {'success': False, 'error': str(e)}
                
                for future in concurrent.futures.as_completed(future_to_vid):
                    if cancel_event and cancel_event.is_set():
                        break
                    completed_videos += 1
                    progress = int((completed_videos / total_videos) * 100)
                    frames = ['🌑','🌒','🌓','🌔','🌕','🌖','🌗','🌘']
                    spinner = frames[completed_videos % len(frames)]
                    sys.stdout.write(f'\r{spinner} Videos: {completed_videos}/{total_videos} ({progress}%)   ')
                    sys.stdout.flush()
                    result = future.result()
                    if result:
                        # Avoid duplicates in final list
                        if not any(v['original_url'] == result['original_url'] for v in videos):
                             videos.append(result)
                             video_count += 1
            sys.stdout.write(f'\r🌕 Videos Done! ✅ {video_count} found     \n')
            sys.stdout.flush()
        # HTML update karo
        head = soup.find('head')
        if head:
            for link in head.find_all('link', rel='stylesheet'):
                link.extract()
            css_link = soup.new_tag('link', rel='stylesheet', href='style.css')
            head.insert(0, css_link)
        body = soup.find('body')
        if body:
            js_script = soup.new_tag('script', src='script.js')
            body.append(js_script)
        # Files save karo
        html_content = str(soup)
        with open(os.path.join(SCRAPED_DIR, 'index.html'), 'w', encoding='utf-8') as f:
            f.write(html_content)
        with open(os.path.join(SCRAPED_DIR, 'style.css'), 'w', encoding='utf-8') as f:
            f.write('\n\n'.join(css_content) or '/* No CSS found */')
        with open(os.path.join(SCRAPED_DIR, 'script.js'), 'w', encoding='utf-8') as f:
            f.write('\n\n'.join(js_content) or '// No JS found */')
        # Stats calculate karo
        def get_size(content):
            size = len(content.encode('utf-8'))
            if size < 1024:
                return f'{size} B'
            elif size < 1024*1024:
                return f'{size/1024:.1f} KB'
            else:
                return f'{size/(1024*1024):.1f} MB'
        # --- DESIGN INSPECTOR ---
        design_data = {'colors': [], 'fonts': []}
        full_css = '\n'.join(css_content) + '\n' + html_content
        # Colors (Hex) nikalo
        hex_colors = re.findall(r'#(?:[0-9a-fA-F]{3}){1,2}\b', full_css)
        # Filter for unique and sort by frequency
        unique_colors = Counter(hex_colors).most_common(20) # Top 20
        design_data['colors'] = [c[0] for c in unique_colors]

        # Fonts nikalo
        fonts = re.findall(r'font-family:\s*([^;]+)', full_css, re.IGNORECASE)
        unique_fonts = Counter([f.strip().strip("'").strip('"') for f in fonts]).most_common(10)
        design_data['fonts'] = [f[0] for f in unique_fonts]

        # --- SEO ANALYSIS ---
        seo_data = {
            'title': soup.title.string if soup.title else None,
            'description': None,'keywords': None,
            'headings': {'h1': 0, 'h2': 0, 'h3': 0},
            'images_analysis': {'total': 0, 'missing_alt': 0},
            'links_internal': 0,'links_external': 0,'score': 0
        }

        # Meta tags check karo
        msg_desc = soup.find('meta', attrs={'name': 'description'}) or soup.find('meta', attrs={'property': 'og:description'})
        if msg_desc: seo_data['description'] = msg_desc.get('content')
        msg_keys = soup.find('meta', attrs={'name': 'keywords'})
        if msg_keys: seo_data['keywords'] = msg_keys.get('content')
        # Headings check karo
        seo_data['headings'] = {
            'h1': len(soup.find_all('h1')),'h2': len(soup.find_all('h2')),'h3': len(soup.find_all('h3')),
        }

        # Images
        imgs = soup.find_all('img')
        seo_data['images_analysis']['total'] = len(imgs)
        seo_data['images_analysis']['missing_alt'] = len([img for img in imgs if not img.get('alt')])
        # Links aur Auditor logic
        all_links = soup.find_all('a')
        domain = requests.compat.urlparse(url).netloc
        check_urls = set()
        for link in all_links:
            href = link.get('href', '')
            if not href or href.startswith('#') or href.startswith('javascript'): continue
            if domain in href or href.startswith('/'):
                seo_data['links_internal'] += 1
            else:
                seo_data['links_external'] += 1        
            # Collect for auditing (limit to 50 to avoid timeout)
            if href.startswith('http'):
                check_urls.add(href)
            elif href.startswith('/'):
                check_urls.add(requests.compat.urljoin(url, href))
        
        # Link Auditor (Threaded logic)
        broken_links = []
        def check_link(l_url):
            try:
                r = session.head(l_url, headers=headers, timeout=3)
                if r.status_code >= 400:
                    return {'url': l_url, 'status': r.status_code}
            except:
                return {'url': l_url, 'status': 'Failed'}
            return None

        # Verify up to 30 unique links
        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
            futures = [executor.submit(check_link, u) for u in list(check_urls)[:30]]
            for f in concurrent.futures.as_completed(futures):
                res = f.result()
                if res: broken_links.append(res)
        seo_data['broken_links'] = broken_links
        # --- DEEP CRAWL LOGIC ---
        site_structure = {'url': url, 'title': seo_data['title'], 'children': []}
        perf_tracker.record_phase("SEO & Parsing")
        
        if crawl_depth > 1:
            # Simple recursive scraper logic
            def scrape_node(node_url, current_level):
                # Max depth par ruk jao
                if current_level > crawl_depth: return None
                try:
                    # Reuse headers/verify settings
                    nr = session.get(node_url, headers=headers, timeout=3)
                    if nr.status_code == 200:
                        ns = BeautifulSoup(nr.text, 'html.parser')
                        node_title = (ns.title.string or node_url).strip()[:50] # Limit title length
                        
                        child_nodes = []
                        # Agar max depth nahi pahoochi, toh children dhundho
                        if current_level < crawl_depth:
                            n_links = []
                            for na in ns.find_all('a', href=True):
                                nh = na['href']
                                if not nh or nh.startswith('#') or nh.startswith('javascript'): continue
                                n_full = requests.compat.urljoin(node_url, nh)
                                # Strict Internal Domain Check
                                if domain in n_full:
                                    if n_full not in n_links and n_full != node_url:
                                        n_links.append(n_full)
                            
                            # Recurse for top 3 links to keep it fast
                            # We don't parallelize here to avoid spawning too many threads recursively
                            for nl in list(set(n_links))[:3]:
                                child = scrape_node(nl, current_level + 1)
                                if child: child_nodes.append(child)
                        
                        return {'url': node_url, 'title': node_title, 'children': child_nodes}
                except: 
                    pass
                return {'url': node_url, 'title': 'Unreachable', 'children': []}

            # Filter start links (Limit 5)
            start_links = list(set([u for u in check_urls if domain in u]))[:5]

            # First level ko parallelize karo
            with concurrent.futures.ThreadPoolExecutor(max_workers=3) as crawler:
                 try:
                     futures = {crawler.submit(scrape_node, u, 2): u for u in start_links}
                     for f in concurrent.futures.as_completed(futures):
                         res = f.result()
                         if res: site_structure['children'].append(res)
                 except RuntimeError:
                     # Agar user abruptly exit kare (Ctrl+C), nayi futures schedule hone par RuntimeError aayega
                     pass
            perf_tracker.record_phase("Deep Crawl")
        score = 0
        if seo_data['title']: score += 20
        if seo_data['description']: score += 20
        if seo_data['headings']['h1'] > 0: score += 20
        if url.startswith('https'): score += 10
        
        if seo_data['images_analysis']['total'] > 0:
            ratio = 1 - (seo_data['images_analysis']['missing_alt'] / seo_data['images_analysis']['total'])
            score += int(30 * ratio)
        else:
            score += 30

        seo_data['score'] = min(100, score)
        
        result = {
            'success': True,
            'security': security_report,
            'site_structure': site_structure,
            'seo': seo_data,
            'design': design_data,
            'stats': {
                'html': get_size(html_content),
                'css': get_size('\n\n'.join(css_content)),
                'js': get_size('\n\n'.join(js_content)),
                'image_count': image_count,
                'video_count': video_count
            },
            'images': images,
            'videos': videos,
            'broken_links': broken_links,
            'intel': {
                'emails': extract_emails(response.text),
                'phones': extract_phones(response.text),
                'locations': extract_locations(soup),
                'socials': extract_social_media(soup),
                'tech_stack': detect_tech_stack(soup, response),
                'ai_analysis': analyze_ai_content(soup.get_text(separator=' ', strip=True)[:50000]) # Limit to 50k chars for perf
            }
        }
        
        perf_tracker.record_phase("AI & Intel")
        perf_data = perf_tracker.finish_and_print()
        result['performance'] = perf_data
        
        return result
        
    except Exception as e:
        print(f"Error in execute_scrape_logic: {e}")
        traceback.print_exc()
        return {'success': False, 'error': str(e)}

@app.route('/api/scrape', methods=['POST'])
def api_scrape():
    try:
        data = request.get_json(silent=True) or {}
        url = data.get('url', '')
        fetch_images = data.get('fetch_images', False)
        fetch_videos = data.get('fetch_videos', False)
        fetch_fonts = data.get('fetch_fonts', False)
        crawl_depth = int(data.get('crawl_depth', 2))
        use_proxy = data.get('use_proxy', False)
        device = data.get('device', 'desktop')
        client_id = data.get('client_id', None)
        
        cancel_event = threading.Event()
        if client_id:
            ACTIVE_SCRAPES[client_id] = cancel_event
        
        result = execute_scrape_logic(url, fetch_images=fetch_images, fetch_videos=fetch_videos, fetch_fonts=fetch_fonts, crawl_depth=crawl_depth, use_proxy=use_proxy, device=device, cancel_event=cancel_event)
        
        if client_id and client_id in ACTIVE_SCRAPES:
            del ACTIVE_SCRAPES[client_id]

        if result.get('success'):
            return jsonify(result)
        else:
            return jsonify(result), 500
    except Exception as e:
        print(f"Flask API Error: {e}")
        traceback.print_exc()
        return jsonify({'success': False, 'error': f"Internal Server Error: {str(e)}"}), 500

@app.route('/api/cancel', methods=['POST'])
def api_cancel():
    try:
        data = request.get_json(silent=True) or {}
        client_id = data.get('client_id')
        if client_id and client_id in ACTIVE_SCRAPES:
            ACTIVE_SCRAPES[client_id].set()  # Signal thread to stop
            del ACTIVE_SCRAPES[client_id]
            return jsonify({'success': True, 'message': 'Scrape cancelled successfully'})
        return jsonify({'success': False, 'message': 'No active scrape found for this client'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/bulk', methods=['POST'])
def api_bulk():
    try:
        data = request.get_json()
        urls = data.get('urls', [])
        fetch_images = data.get('fetch_images', False)
        client_id = data.get('client_id')
        
        cancel_event = threading.Event()
        if client_id:
            ACTIVE_SCRAPES[client_id] = cancel_event
        
        if not urls:
            return jsonify({'success': False, 'error': 'No URLs provided'})

        timestamp = int(time.time())
        base_folder = f'webfiles/bulk/batch_{timestamp}'
        os.makedirs(base_folder, exist_ok=True)
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
        processed = 0
        for i, url in enumerate(urls):
            if cancel_event.is_set():
                print("Bulk scrape cancelled by user")
                break
            if not url.strip(): continue
            try:
                if not url.startswith('http'): url = 'https://' + url
                
                # Subfolder banao
                domain = requests.compat.urlparse(url).netloc.replace(':', '_')
                site_folder = f'{base_folder}/{i+1}_{domain}'
                os.makedirs(site_folder, exist_ok=True)
                os.makedirs(f'{site_folder}/images', exist_ok=True)
                
                # Fetch karo
                response = requests.get(url, headers=headers, timeout=10)
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # HTML save karo
                with open(f'{site_folder}/index.html', 'w', encoding='utf-8') as f:
                    f.write(str(soup))
                
                # CSS logic
                css_content = []
                for link in soup.find_all('link', rel='stylesheet'):
                    href = link.get('href')
                    if href:
                        try:
                            css_url = requests.compat.urljoin(url, href)
                            css_content.append(requests.get(css_url, headers=headers, timeout=5).text)
                        except: pass
                with open(f'{site_folder}/style.css', 'w', encoding='utf-8') as f:
                    f.write('\n'.join(css_content))

                # Images check karo
                if fetch_images:
                    for img in soup.find_all('img'):
                        src = img.get('src')
                        if src and not src.startswith('data:') and not src.lower().endswith('.svg'):
                            try:
                                img_url = requests.compat.urljoin(url, src)
                                fname = os.path.basename(img_url.split('?')[0]) or 'image.jpg'
                                if not fname.endswith(('.jpg','.png','.jpeg','.webp')): fname += '.jpg'
                                
                                r = requests.get(img_url, headers=headers, timeout=5)
                                if r.status_code == 200:
                                    with open(f'{site_folder}/images/{fname}', 'wb') as f:
                                        f.write(r.content)
                            except: pass
                
                processed += 1
            except Exception as e:
                print(f"Failed to scrape {url}: {e}")

        # ZIP banao
        shutil.make_archive(base_folder, 'zip', base_folder)
        shutil.rmtree(base_folder) # Folder saaf karo, sirf ZIP rakho
        
        if client_id and client_id in ACTIVE_SCRAPES:
            del ACTIVE_SCRAPES[client_id]
            
        return jsonify({
            'success': True,
            'message': f'Successfully scraped {processed} sites.',
            'download_url': f'/download/bulk/batch_{timestamp}.zip'
        })

    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/download/bulk/<path:filename>')
def serve_bulk_file(filename):
    return send_from_directory('webfiles/bulk', filename)

@app.route('/api/save', methods=['POST'])
def api_save():
    try:
        data = request.get_json()
        filename = data.get('filename')
        content = data.get('content')
        
        if filename in ['index.html', 'style.css', 'script.js']:
            with open(f'webfiles/scraped/{filename}', 'w', encoding='utf-8') as f:
                f.write(content)
            return jsonify({'success': True})
        else:
            return jsonify({'success': False, 'error': 'Invalid filename'}), 400
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/download-zip')
def download_zip():
    try:
        zip_path = os.path.join(DATA_DIR, 'scraped_files.zip')
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(SCRAPED_DIR):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, SCRAPED_DIR)
                    zipf.write(file_path, arcname)
        
        return send_file(zip_path, as_attachment=True, download_name='scraped_files.zip')
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def clear_scraped_data():
    try:
        if os.path.exists(SCRAPED_DIR):
            shutil.rmtree(SCRAPED_DIR)
        os.makedirs(os.path.join(SCRAPED_DIR, 'images'), exist_ok=True)
        os.makedirs(os.path.join(SCRAPED_DIR, 'videos'), exist_ok=True)
        return True
    except Exception as e:
        print(f"Cleanup Error: {e}")
        return False

@app.route('/api/clear', methods=['POST'])
def api_clear():
    if clear_scraped_data():
        return jsonify({'success': True})
    else:
        return jsonify({'success': False, 'error': 'Cleanup failed'}), 500

@app.route('/api/export', methods=['POST'])
def api_export():
    try:
        req_data = request.get_json()
        data = req_data.get('data')
        export_format = req_data.get('format', 'csv').lower()
        filename = req_data.get('filename', 'export')
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400

        # Buffer create karo
        if export_format == 'csv':
            si = io.StringIO()
            # Check karo data simple list hai ya list of dicts
            if isinstance(data, list) and len(data) > 0:
                if isinstance(data[0], dict):
                    # List of Dicts (e.g. Socials)
                    keys = data[0].keys()
                    writer = csv.DictWriter(si, fieldnames=keys)
                    writer.writeheader()
                    writer.writerows(data)
                else:
                    # Simple List (e.g. Emails)
                    writer = csv.writer(si)
                    writer.writerow(['Value']) # Generic header
                    for item in data:
                        writer.writerow([item])
            
            output = si.getvalue()
            mem = io.BytesIO()
            mem.write(output.encode('utf-8'))
            mem.seek(0)
            
            return send_file(
                mem,
                mimetype='text/csv',
                as_attachment=True,
                download_name=f'{filename}.csv'
            )
            
        elif export_format == 'json':
            mem = io.BytesIO()
            mem.write(json.dumps(data, indent=2).encode('utf-8'))
            mem.seek(0)
            
            return send_file(
                mem,
                mimetype='application/json',
                as_attachment=True,
                download_name=f'{filename}.json'
            )
            
        else:
            return jsonify({'error': 'Unsupported format'}), 400

    except Exception as e:
        print(f"Export Error: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/translate', methods=['POST'])
def api_translate():
    try:
        data = request.get_json()
        text = data.get('text')
        target_lang = data.get('target', 'hi') # Default to Hindi
        
        if not text:
            return jsonify({'error': 'No text provided'}), 400
            
        translated = mtranslate.translate(text, target_lang)
        return jsonify({
            'success': True,
            'translated': translated
        })
    except Exception as e:
        print(f"Translation Error: {e}")
        return jsonify({'error': str(e)}), 500

def wait_for_server(port, timeout=10):
    start = time.time()
    while time.time() - start < timeout:
        try:
            import urllib.request
            urllib.request.urlopen(f'http://127.0.0.1:{port}/', timeout=1)
            return True
        except:
            time.sleep(0.5)
    return False


# --- IMAGE ANALYSIS FEATURE ---

def get_decimal_from_dms(dms, ref):
    degrees = dms[0]
    minutes = dms[1]
    seconds = dms[2]
    
    decimal = degrees + (minutes / 60.0) + (seconds / 3600.0)
    if ref in ['S', 'W']:
        decimal = -decimal
    return decimal

def get_image_metadata(image):
    info = {
        "Format": image.format,
        "Mode": image.mode,
        "Size": f"{image.width} x {image.height}",
        "Width": image.width,
        "Height": image.height,
        "Info": image.info.get('comment', '')
    }
    
    # EXIF data
    exif_data = {}
    gps_data = {}
    
    try:
        exif = image._getexif()
        if exif:
            for tag, value in exif.items():
                decoded = ExifTags.TAGS.get(tag, tag)
                if decoded == "GPSInfo":
                    gps_data = {}
                    for t in value:
                        sub_decoded = ExifTags.GPSTAGS.get(t, t)
                        gps_data[sub_decoded] = value[t]
                else:
                    # Binary data filter karo
                    if isinstance(value, bytes):
                        try:
                            value = value.decode()
                        except:
                            value = "<binary data>"
                    exif_data[decoded] = str(value)
    except Exception as e:
        print(f"EXIF Error: {e}")

    # GPS data process karo
    location = None
    if gps_data:
        try:
            lat = get_decimal_from_dms(gps_data.get('GPSLatitude'), gps_data.get('GPSLatitudeRef'))
            lon = get_decimal_from_dms(gps_data.get('GPSLongitude'), gps_data.get('GPSLongitudeRef'))
            location = {'lat': lat, 'lon': lon, 'map_url': f"https://www.google.com/maps?q={lat},{lon}"}
        except Exception as e:
            print(f"GPS Parse Error: {e}")

    return {
        "basic": info,
        "exif": exif_data,
        "gps": str(gps_data),
        "location": location
    }

def generate_ela(image, quality=90, scale=10):
    """
    ELA (Error Level Analysis) image generate karta hai.
    1. Original image ko specific quality (compression) pe save karta hai.
    2. Original aur compressed ke beech ka difference nikalta hai.
    3. Visualisation ke liye difference ko enhance karta hai.
    """
    try:
        # Agar RGB nahi hai (jaise RGBA, P) toh convert karo
        if image.mode != 'RGB':
            image = image.convert('RGB')

        # Compressed version memory mein save karo
        buffer = BytesIO()
        image.save(buffer, 'JPEG', quality=quality)
        buffer.seek(0)
        compressed_image = Image.open(buffer)

        # Difference calculate karo
        ela_image = ImageChops.difference(image, compressed_image)

        # Differences dikhne ke liye brightness badhao
        ela_image = ImageEnhance.Brightness(ela_image).enhance(scale)

        return ela_image
    except Exception as e:
        print(f"ELA Error: {e}")
        return None

@app.route('/api/analyze/ela', methods=['POST'])
def analyze_ela():
    try:
        if 'image' not in request.files:
            return jsonify({'error': 'No image file provided'}), 400
            
        file = request.files['image']
        image = Image.open(file.stream)
        
        ela_image = generate_ela(image)
        
        if ela_image:
            # ELA result ko base64 mein convert karo
            buffered = BytesIO()
            ela_image.save(buffered, format="PNG") # ELA details ke liye PNG format
            img_str = base64.b64encode(buffered.getvalue()).decode()
            return jsonify({'success': True, 'ela_image': f"data:image/png;base64,{img_str}"})
        else:
            return jsonify({'error': 'Failed to generate ELA'}), 500
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def compute_ai_likelihood(image):
    """
    Image mein AI generation artifacts check karta hai (FFT use karke).
    Likelihood score (0-100) aur label return karta hai.
    """
    try:
        # Greyscale aur resize (consistent analysis ke liye)
        img_gray = image.convert('L').resize((512, 512))
        img_array = np.array(img_gray)

        # FFT logic
        f = np.fft.fft2(img_array)
        fshift = np.fft.fftshift(f)
        magnitude_spectrum = 20 * np.log(np.abs(fshift) + 1e-10) # Log scale

        # Heuristic: AI images mein aksar high-frequency energy ya grid artifacts hote hain.
        # High-frequency components ka variance calculate karenge.
        
        # High-pass mask banao
        rows, cols = img_array.shape
        crow, ccol = rows//2, cols//2
        mask_radius = 50
        
        # Low frequencies (center) mask karo
        magnetude_high_freq = magnitude_spectrum.copy()
        magnetude_high_freq[crow-mask_radius:crow+mask_radius, ccol-mask_radius:ccol+mask_radius] = 0
        
        # High frequencies par stats calculate karo
        hf_mean = np.mean(magnetude_high_freq)
        hf_std = np.std(magnetude_high_freq)
        
        # Simple heuristic mapping (demo ke liye tuned)
        # Real images mein HF variance kam hoti hai jab tak textured na ho.
        # GANs aksar high-energy artifacts chhod dete hain.
        
        # Score normalize karo (estimation hai)
        # Maan ke chalte hain natural image std 30-50 hai, AI zyada ho sakta hai.
        # Natural variations ke liye sigmoid-like mapping use karenge.
        
        score = min(100, max(0, (hf_std - 40) * 2 + 50)) 
        
        # Refinement: "checkerboard" artifacts check karo jo strong indicators hote hain
        # Peak detection chahiye par variance bhi achha proxy hai.
        
        label = "Likely Real"
        if score > 60:
            label = "Possible AI / Edited"
        if score > 80:
            label = "Likely AI Generated"
            
        return {
            "score": round(score, 1),
            "label": label,
            "details": f"HF Variance: {round(hf_std, 2)}"
        }
    except Exception as e:
        print(f"AI Detection Error: {e}")
        return {"score": 0, "label": "Error", "details": str(e)}

@app.route('/api/analyze/ai', methods=['POST'])
def analyze_ai():
    try:
        if 'image' not in request.files:
            return jsonify({'error': 'No image file provided'}), 400
            
        file = request.files['image']
        image = Image.open(file.stream)
        
        result = compute_ai_likelihood(image)
        
        return jsonify({'success': True, 'data': result})
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/analyze-image', methods=['POST'])
def analyze_image():
    try:
        image = None
        source_type = "upload"
        
        # 1. File upload check karo
        if 'file' in request.files:
            file = request.files['file']
            if file.filename == '':
                return jsonify({'error': 'No selected file'}), 400
            try:
                image = Image.open(file.stream)
            except Exception as e:
                 return jsonify({'error': f'Invalid image file: {e}'}), 400
                 
        # 2. URL check karo
        elif 'url' in request.form or (request.is_json and 'url' in request.get_json()):
            data = request.get_json() if request.is_json else request.form
            url = data.get('url')
            if not url:
                 return jsonify({'error': 'No URL provided'}), 400
            
            source_type = "url"
            try:
                headers = {'User-Agent': 'Mozilla/5.0'}
                resp = requests.get(url, headers=headers, stream=True, timeout=15, verify=False)
                resp.raise_for_status()
                image = Image.open(BytesIO(resp.content))
            except Exception as e:
                return jsonify({'error': f'Failed to fetch image from URL: {e}'}), 400
        
        else:
            return jsonify({'error': 'No image provided (file or url)'}), 400

        # Image process karo
        metadata = get_image_metadata(image)
        ai_detection = compute_ai_likelihood(image)
        
        return jsonify({
            'success': True,
            'source': source_type,
            'data': metadata,
            'ai_detection': ai_detection
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

def display_qr_image(url):
    """QR code generate aur ASCII format mein terminal pe dikhao"""
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(url)
    qr.make(fit=True)
    
    # ASCII QR code print karo (invert=True better options hai)
    qr.print_ascii(invert=True)
    print(f"\n🔗 {url}")

def start_cloudflare_tunnel(port):
    try:
        if os.name == 'nt':
            os.system("taskkill /F /IM cloudflared.exe >NUL 2>&1")
        else:
            os.system("pkill -f cloudflared 2>/dev/null")
        time.sleep(1)
        
        # OS ke hisaab se executable choose karo
        cf_executable = os.path.join(DATA_DIR, 'cloudflared.exe') if os.name == 'nt' else os.path.join(DATA_DIR, 'cloudflared')
        
        # Agar missing ho toh download karo
        if not os.path.exists(cf_executable):
            print(f"Downloading cloudflared for {os.name}...")
            if os.name == 'nt':
                # Windows binary download URL
                win_url = "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe"
                resp = requests.get(win_url, stream=True)
                with open(cf_executable, 'wb') as f:
                    for chunk in resp.iter_content(chunk_size=8192):
                        f.write(chunk)
            else:
                # Linux binary download URL
                subprocess.run(['wget', '-q', '-O', cf_executable, 'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64'])
                subprocess.run(['chmod', '+x', cf_executable])
        
        process = subprocess.Popen(
            [cf_executable, 'tunnel', '--protocol', 'http2', '--url', f'http://127.0.0.1:{port}'],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1
        )
        
        url_pattern = r'https://[a-z0-9-]+\.trycloudflare\.com'
        start_time = time.time()
        
        while time.time() - start_time < 30:
            line = process.stdout.readline()
            if line:
                match = re.search(url_pattern, line)
                if match:
                    url = match.group(0)
                    time.sleep(2)
                    return url, process
        return None, None
    except:
        return None, None

def print_cli_report(data):
    """Beautiful Colorized two-column report for CLI mode"""
    if not data.get('success'):
        print(f"\n{Fore.RED if COLOR_SUPPORT else ''}❌ Scrape Failed: {data.get('error')}")
        return

    c_b = Fore.CYAN if COLOR_SUPPORT else ""
    c_g = Fore.GREEN if COLOR_SUPPORT else ""
    c_y = Fore.YELLOW if COLOR_SUPPORT else ""
    c_r = Fore.RED if COLOR_SUPPORT else ""
    c_m = Fore.MAGENTA if COLOR_SUPPORT else ""
    c_w = Fore.WHITE if COLOR_SUPPORT else ""
    R = Style.RESET_ALL if COLOR_SUPPORT else ""

    W = 37  # Inner width per column
    SEP = "─"

    def vlen(s):
        return len(re.sub(r'\033\[[0-9;]*m', '', s))

    def pad(s, w):
        return s + ' ' * max(0, w - vlen(s))

    # --- Build LEFT column: Security + SEO + Intel ---
    left = []
    sec = data['security']
    sec_icon = "🟢" if sec['level'] == 'LOW' else "🟡" if sec['level'] == 'MEDIUM' else "🔴"
    sec_c = c_g if sec['level'] == 'LOW' else c_y if sec['level'] == 'MEDIUM' else c_r
    left.append(f"SECURITY: {sec_icon} {sec_c}{sec['level']}{R}")
    for t in sec['threats'][:3]:
        left.append(f" - {t[:W-3]}")
    left.append(SEP)

    seo = data['seo']
    bar = '█' * int(seo['score']/5)
    left.append(f"SEO: {c_g}{seo['score']}{R}/100 {bar}")
    left.append(f"H1:{seo['headings']['h1']} H2:{seo['headings']['h2']} H3:{seo['headings']['h3']}")
    left.append(f"Imgs: {seo['images_analysis']['total']} total, {seo['images_analysis']['missing_alt']} no-alt")
    left.append(SEP)

    intel = data['intel']
    left.append(f"INTEL (OSINT):")
    left.append(f" 📧 Emails: {len(intel['emails'])}")
    for e in intel['emails'][:2]:
        left.append(f"    {e[:W-4]}")
    left.append(f" 📱 Phones: {len(intel['phones'])}")
    for p in intel['phones'][:2]:
        left.append(f"    {p[:W-4]}")
    left.append(f" 📍 Locations: {len(intel['locations'])}")
    left.append(f" 🛠️ {c_m}{', '.join(intel['tech_stack'][:3])[:W-4]}{R}")

    # --- Build RIGHT column: AI + Performance ---
    right = []
    if intel.get('ai_analysis'):
        ai = intel['ai_analysis']
        if ai.get('skipped'):
            right.append(f"AI ANALYSIS: {c_y}Skipped{R}")
            right.append(f" {ai.get('message', 'Missing AI data')}")
        elif ai.get('sentiment'):
            right.append(f"AI ANALYSIS:")
            right.append(f" Sentiment: {c_m}{ai['sentiment']['label']}{R} ({ai['sentiment']['polarity']})")
            right.append(f" Readability: {ai['readability']['level']} ({ai['readability']['score']})")
            right.append(f" Keywords:")
            kw = ', '.join(ai.get('keywords', [])[:5])
            right.append(f"  {kw[:W-2]}")
        else:
            right.append(f"AI ANALYSIS: {c_y}Unavailable{R}")
    right.append(SEP)

    perf = data.get('performance', {})
    if perf and perf.get('total'):
        right.append(f"PERFORMANCE: {c_y}{perf['total']:.2f}s{R}")
        for phase, dur in perf['phases'].items():
            perc = (dur / perf['total']) * 100
            bl = int(perc / 5)
            b = "█" * bl
            right.append(f" {phase[:12]:<12} {c_g}{b:<10}{R} {perc:>3.0f}%")
        right.append(f" Avg:{perf['avg']:.1f}s Best:{perf['best']:.1f}s")

    # --- Media Stats ---
    stats = data.get('stats', {})
    imgs_scraped = len(data.get('images', []))
    vids_scraped = len(data.get('videos', []))
    imgs_found = stats.get('image_count', imgs_scraped)
    vids_found = stats.get('video_count', vids_scraped)
    if imgs_found or vids_found or imgs_scraped or vids_scraped:
        right.append(SEP)
        right.append(f"MEDIA:")
        right.append(f" 🖼️ Images: {c_g}{imgs_scraped}{R} scraped / {imgs_found} found")
        right.append(f" 🎬 Videos: {c_g}{vids_scraped}{R} scraped / {vids_found} found")

    # Equalize rows
    mx = max(len(left), len(right))
    while len(left) < mx: left.append("")
    while len(right) < mx: right.append("")

    # --- Render ---
    url_display = data['site_structure']['url'][:W*2]
    total_w = W * 2 + 5  # inner total

    print(f"\n{c_b}╔{'═'*total_w}╗{R}")
    print(f"{c_b}║ {R}{pad('intelligence report: ' + url_display, total_w - 1)}{c_b}║{R}")
    print(f"{c_b}╠{'═'*W}═╦═{'═'*W}══╣{R}")

    for i in range(mx):
        l, r = left[i], right[i]
        l_sep = (l == SEP)
        r_sep = (r == SEP)

        if l_sep and r_sep:
            print(f"{c_b}╟{'─'*W}─╫─{'─'*W}──╢{R}")
        elif l_sep:
            print(f"{c_b}╟{'─'*W}─╫ {R}{pad(r, W+1)}{c_b}║{R}")
        elif r_sep:
            print(f"{c_b}║ {R}{pad(l, W)}{c_b}╟ {R}{' '*W} {c_b}║{R}")
        else:
            print(f"{c_b}║ {R}{pad(l, W)}{c_b}║ {R}{pad(r, W+1)}{c_b}║{R}")

    print(f"{c_b}╚{'═'*W}═╩═{'═'*W}══╝{R}\n")

def is_valid_url(text):
    """Smart detection for URLs/Domains - Ultra Strict"""
    text = text.lower().strip()
    if not text or ' ' in text or len(text) < 4: return False
    if text.startswith('http'): return True
    if text.startswith(('/', '.', '@')): return False
    
    # Must have a legitimate domain-like structure
    parts = text.split('.')
    if len(parts) >= 2:
        # Check TLD (2-12 chars, letters only)
        tld = parts[-1].split('/')[0]
        if tld.isalpha() and 2 <= len(tld) <= 12:
            # Common file types to exclude
            if tld in ['py', 'json', 'txt', 'md', 'exe', 'log', 'bat', 'sh', 'zip', 'rar']:
                return False
            # Ensure the domain part isn't empty or invalid
            domain_part = parts[-2]
            if domain_part and any(c.isalnum() for c in domain_part):
                return True
    return False

def run_cli_mode(initial_url=None):
    """Interactive CLI prompting flow"""
    if initial_url and not is_valid_url(initial_url):
        print(f"\n{Fore.RED}⚠️ Invalid Link: {Fore.WHITE}{initial_url}")
        time.sleep(1.5)
        return

    os.system('cls' if os.name == 'nt' else 'clear')
    banner = r"""██╗    ██╗███████╗██████╗     ████████╗ ██████╗  ██████╗ ██╗     ███████╗
██║    ██║██╔════╝██╔══██╗    ╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔════╝
██║ █╗ ██║█████╗  ██████╔╝       ██║   ██║   ██║██║   ██║██║     ███████╗
██║███╗██║██╔══╝  ██╔══██╗       ██║   ██║   ██║██║   ██║██║     ╚════██║
╚███╔███╔╝███████╗██████╔╝       ██║   ╚██████╔╝╚██████╔╝███████╗███████║
 ╚══╝╚══╝ ╚══════╝╚═════╝        ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝"""
    print_gradient_text(banner, (0, 255, 255), (255, 0, 255))
    print(f"{' ' * 45}{Fore.WHITE}{Style.DIM}Dev: Abhinav Adarsh{Style.RESET_ALL}")
    print(f"{Fore.CYAN}{Style.BRIGHT}           ADVANCED CLI INTELLIGENCE MODE{Style.RESET_ALL}")
    
    try:
        url = initial_url if initial_url else input(f"{Fore.LIGHTGREEN_EX if COLOR_SUPPORT else ''}link > {Style.RESET_ALL}").strip()
        if not url: return
        
        # Double check validity if manual input
        if not initial_url and not is_valid_url(url):
            print(f"\n{Fore.RED}⚠️ Invalid Link: {Fore.WHITE}{url}")
            time.sleep(1.5)
            return
        
        if AUTOCOMPLETE_AVAILABLE:
            if not url.startswith('/'):
                try: readline.write_history_file(HISTORY_FILE)
                except: pass
            else:
                try: readline.remove_history_item(readline.get_current_history_length() - 1)
                except: pass

        print("\n⚙️  Scrape Options:")
        fetch_img = input("   - Fetch & Analyze Images? (y/N) > ").lower() == 'y'
        if AUTOCOMPLETE_AVAILABLE:
            try: readline.remove_history_item(readline.get_current_history_length() - 1)
            except: pass
        fetch_vid = input("   - Fetch & Deep-Scan Videos? (y/N) > ").lower() == 'y'
        if AUTOCOMPLETE_AVAILABLE:
            try: readline.remove_history_item(readline.get_current_history_length() - 1)
            except: pass
        depth = input("   - Crawl Depth (1-3) [Default 2] > ").strip()
        depth = int(depth) if depth.isdigit() else 2
        if AUTOCOMPLETE_AVAILABLE:
            try: readline.remove_history_item(readline.get_current_history_length() - 1)
            except: pass
        use_proxy = input("   - Use Intelligent Proxies? (y/N) > ").lower() == 'y'
        if AUTOCOMPLETE_AVAILABLE:
            try: readline.remove_history_item(readline.get_current_history_length() - 1)
            except: pass

        with MoonSpinner("Scanning"):
            result = execute_scrape_logic(url, fetch_images=fetch_img, fetch_videos=fetch_vid, crawl_depth=depth, use_proxy=use_proxy)
        print_cli_report(result)
        
        input("Press Enter to return to main menu and CLEAR session data...")
        clear_scraped_data()
        print("🧹 Session data cleared.")
        time.sleep(1)
    except KeyboardInterrupt:
        print("\n\n⚠️ Input interrupted. Returning to menu...")
        time.sleep(1)

def run_image_forensics_mode(initial_image=None):
    """CLI flow for image analysis"""
    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        banner = r"""██╗███╗   ███╗ █████╗  ██████╗ ███████╗    ███████╗ ██████╗ ██████╗ ███████╗███╗   ██╗███████╗██╗ ██████╗███████╗
██║████╗ ████║██╔══██╗██╔════╝ ██╔════╝    ██╔════╝██╔═══██╗██╔══██╗██╔════╝████╗  ██║██╔════╝██║██╔════╝██╔════╝
██║██╔████╔██║███████║██║  ███╗█████╗      █████╗  ██║   ██║██████╔╝█████╗  ██╔██╗ ██║███████╗██║██║     ███████╗
██║██║╚██╔╝██║██╔══██║██║   ██║██╔══╝      ██╔══╝  ██║   ██║██╔══██╗██╔══╝  ██║╚██╗██║╚════██║██║██║     ╚════██║
██║██║ ╚═╝ ██║██║  ██║╚██████╔╝███████╗    ██║     ╚██████╔╝██║  ██║███████╗██║ ╚████║███████║██║╚██████╗███████║
╚═╝╚═╝     ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝    ╚═╝      ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═══╝╚══════╝╚═╝ ╚═════╝╚══════╝"""
        print_gradient_text(banner, (255, 100, 100), (100, 100, 255))
        print(f"{' ' * 45}{Fore.WHITE}{Style.DIM}Dev : Abhinav Adarsh{Style.RESET_ALL}\n")

        try:
            user_input = initial_image if initial_image else input(f"{Fore.LIGHTGREEN_EX if COLOR_SUPPORT else ''}image link or local path (or {Fore.RED}/q{Fore.LIGHTGREEN_EX if COLOR_SUPPORT else ''} to quit) > {Style.RESET_ALL}").strip()
            
            if user_input in ['/q', '/quit']:
                print("\n Returning to main menu...")
                time.sleep(1)
                return
            
            if not user_input:
                if initial_image:
                    return
                continue

            # Handle quotes (e.g. from copy-pasting path)
            user_input = user_input.strip('"\'')

            image = None
            source_type = "local"

            with MoonSpinner("Analyzing Image"):
                try:
                    # Is it a URL?
                    if user_input.startswith(('http://', 'https://')):
                        source_type = "url"
                        headers = {'User-Agent': proxy_manager.get_random_ua()}
                        resp = requests.get(user_input, headers=headers, stream=True, timeout=15, verify=False)
                        resp.raise_for_status()
                        image = Image.open(BytesIO(resp.content))
                    else:
                        # Assume it's a local path
                        if os.path.exists(user_input):
                            image = Image.open(user_input)
                        else:
                            print(f"\n{Fore.RED}Error: File or URL not found: {Fore.WHITE}{user_input}")
                            time.sleep(2)
                            if initial_image:
                                return
                            continue

                    if not image:
                        raise Exception("Failed to load image")

                    # Process
                    metadata = get_image_metadata(image)
                    ai_detection = compute_ai_likelihood(image)
                    
                    print_image_forensics_report({
                        'source': source_type,
                        'path': user_input,
                        'metadata': metadata,
                        'ai': ai_detection
                    })

                except Exception as e:
                    print(f"\n{Fore.RED}Analysis Failed: {Fore.WHITE}{e}")
                    time.sleep(2)
                    if initial_image:
                        return
                    continue

            if initial_image:
                input("\nPress Enter to return to main menu...")
                return
            
            response = input(f"\nAnalyze another image? (y/n or {Fore.RED}/q{Style.RESET_ALL} to quit): ").strip().lower()
            if response in ['/q', '/quit', 'n', 'no']:
                print("\n Returning to main menu...")
                time.sleep(1)
                return
                
        except KeyboardInterrupt:
            print("\n Returning to main menu...")
            time.sleep(1)
            return

def print_image_forensics_report(data):
    """Beautiful terminal table for image analysis results"""
    c_b = Fore.CYAN if COLOR_SUPPORT else ""
    c_g = Fore.GREEN if COLOR_SUPPORT else ""
    c_y = Fore.YELLOW if COLOR_SUPPORT else ""
    c_r = Fore.RED if COLOR_SUPPORT else ""
    c_w = Fore.WHITE if COLOR_SUPPORT else ""
    R = Style.RESET_ALL if COLOR_SUPPORT else ""

    meta = data['metadata']
    basic = meta['basic']
    ai = data['ai']
    
    total_w = 80
    def vlen(s): return len(re.sub(r'\033\[[0-9;]*m', '', s))
    def pad(s, w): return s + ' ' * (w - vlen(s))

    print(f"\n{c_b}╔{'═'*(total_w-2)}╗{R}")
    title = f" forensic report: {os.path.basename(data['path'])[:40]} "
    print(f"{c_b}║{R}{c_w}{Style.BRIGHT}{title.center(total_w-2)}{R}{c_b}║{R}")
    print(f"{c_b}╠{'═'*(total_w-2)}╣{R}")

    # Row helper
    def print_row(key, val, color=c_w):
        k = f" {key}:"
        line = f"{c_y}{pad(k, 20)}{R} {color}{val}{R}"
        print(f"{c_b}║{R} {pad(line, total_w-4)} {c_b}║{R}")

    # Basic Info
    print_row("Source Type", data['source'].upper(), c_g)
    print_row("Format", basic['Format'])
    print_row("Resolution", basic['Size'])
    print_row("Color Mode", basic['Mode'])
    
    # AI Detection
    ai_score = ai['score']
    ai_color = c_r if ai_score > 70 else (c_y if ai_score > 40 else c_g)
    print_row("AI Likelihood", f"{ai_score}% ({ai['label']})", ai_color)

    # GPS / Location
    if meta.get('location'):
        print_row("GPS Coordinates", f"{meta['location']['lat']}, {meta['location']['lon']}", c_m := (Fore.MAGENTA if COLOR_SUPPORT else ""))
        print_row("Map Link", meta['location']['map_url'], c_b)

    # Crucial EXIF
    exif = meta['exif']
    important_tags = ['Make', 'Model', 'Software', 'DateTime', 'LensModel', 'ExposureTime', 'ISOSpeedRatings']
    found_exif = False
    for tag in important_tags:
        if tag in exif:
            if not found_exif:
                print(f"{c_b}╟{'─'*(total_w-2)}╢{R}")
                found_exif = True
            print_row(tag, exif[tag])

    print(f"{c_b}╚{'═'*(total_w-2)}╝{R}\n")

def main_launcher():
    """Mode selection menu on startup"""
    menu_commands = ['/web', '/cli', '/image', '/adb', '/help', '/clear', '/quit', '/history', '/w', '/c', '/i', '/a', '/h', '/q', '/hi', '--help']
    setup_autocomplete(menu_commands)
    
    while True:
        try:
            os.system('cls' if os.name == 'nt' else 'clear')
            banner = r"""██╗    ██╗███████╗██████╗     ████████╗ ██████╗  ██████╗ ██╗     ███████╗
██║    ██║██╔════╝██╔══██╗    ╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔════╝
██║ █╗ ██║█████╗  ██████╔╝       ██║   ██║   ██║██║   ██║██║     ███████╗
██║███╗██║██╔══╝  ██╔══██╗       ██║   ██║   ██║██║   ██║██║     ╚════██║
╚███╔███╔╝███████╗██████╔╝       ██║   ╚██████╔╝╚██████╔╝███████╗███████║
 ╚══╝╚══╝ ╚══════╝╚═════╝        ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝"""
            print_gradient_text(banner, (0, 255, 255), (255, 0, 255))
            print(f"{' ' * 45}{Fore.WHITE}{Style.DIM}Dev: Abhinav Adarsh{Style.RESET_ALL}")
            print(f"{Fore.WHITE}Type {Fore.CYAN}/help{Fore.WHITE} or {Fore.CYAN}/h{Fore.WHITE} to see all commands.")
            
            choice = input(f"{Fore.LIGHTGREEN_EX if COLOR_SUPPORT else ''}> {Style.RESET_ALL}").strip().lower()
            if AUTOCOMPLETE_AVAILABLE:
                try: readline.remove_history_item(readline.get_current_history_length() - 1)
                except: pass
            
            if choice in ['/web', '/w']:
                start_web_server()
            elif choice in ['/cli', '/c']:
                run_cli_mode()
            elif choice in ['/image', '/i']:
                run_image_forensics_mode()
            elif choice in ['/help', '/h', '--help']:
                print(f"\n{Fore.CYAN if COLOR_SUPPORT else ''}Available Commands:")
                print(f"  {Fore.CYAN}/web{Style.RESET_ALL}     - Launches the web engine for browser-based auditing. (Alias: /w)")
                print(f"  {Fore.CYAN}/cli{Style.RESET_ALL}     - Runs a deep-scan intelligence report in the terminal. (Alias: /c)")
                print(f"  {Fore.CYAN}/image{Style.RESET_ALL}   - Local/Remote Image Forensics & AI detection. (Alias: /i)")
                print(f"  {Fore.CYAN}/adb{Style.RESET_ALL}     - ADB Bloatware Remover for Android devices. (Alias: /a)")
                print(f"  {Fore.CYAN}/clear{Style.RESET_ALL}   - Purges the 'webfiles/scraped' directory and clears screen.")
                print(f"  {Fore.CYAN}/history{Style.RESET_ALL} - Shows command history. (Alias: /hi)")
                print(f"  {Fore.CYAN}/help{Style.RESET_ALL}    - Displays this help message. (Alias: /h, --help)")
                print(f"  {Fore.RED}/quit{Style.RESET_ALL}    - Shuts down the application safely. (Alias: /q)")
                print(f"\n{Fore.YELLOW}Tip:{Style.RESET_ALL} While in /web mode, type {Fore.RED}/q{Style.RESET_ALL} to return to main menu.")
                input("\nPress Enter to continue...")
            elif choice in ['/history', '/hi']:
                if AUTOCOMPLETE_AVAILABLE and os.path.exists(HISTORY_FILE):
                    print(f"\n{Fore.CYAN}--- Command History ---{Style.RESET_ALL}")
                    with open(HISTORY_FILE, 'r') as f:
                        lines = f.readlines()
                        for i, line in enumerate(lines[-20:]): # Show last 20
                            print(f"{Fore.WHITE}{i+1}. {line.strip()}")
                else:
                    print(f"\n{Fore.YELLOW}No history found.")
                input("\nPress Enter to continue...")
            elif choice in ['/clear', '/c']:
                clear_scraped_data()
                os.system('cls' if os.name == 'nt' else 'clear')
                print("Cache purged and screen cleared.")
                time.sleep(1)
            elif choice in ['/quit', '/q']:
                print(f"\n{Fore.YELLOW if COLOR_SUPPORT else ''}Goodbye!")
                sys.exit()
            elif choice in ['/adb', '/a']:
                run_adb_mode()
            elif is_valid_url(choice):
                run_cli_mode(choice)
        except KeyboardInterrupt:
            print("\n\nGoodbye!")
            sys.exit()

# --- ADB BLOATWARE REMOVER ---

def _get_adb_cmd():
    """Get the correct adb command, auto-installing if missing"""
    def check_exists(cmd):
        try:
            # shell=True sometimes needed on Windows if not checking .exe directly, but subprocess works fine with .exe
            res = subprocess.run([cmd, 'version'], capture_output=True, timeout=5)
            if res.returncode == 0: return True
        except: pass
        return False

    is_wsl = False
    try:
        with open('/proc/version', 'r') as f:
            if 'microsoft' in f.read().lower():
                is_wsl = True
    except: pass
    
    if is_wsl and check_exists('adb.exe'): return 'adb.exe'
    if check_exists('adb'): return 'adb'
    if os.name == 'nt' and check_exists('adb.exe'): return 'adb.exe'
    
    # Check local downloaded ADB
    platform_tools_dir = os.path.join(DATA_DIR, 'platform-tools')
    os_suffix = '.exe' if os.name == 'nt' or is_wsl else ''
    local_adb = os.path.join(platform_tools_dir, f'adb{os_suffix}')
    
    if os.path.exists(local_adb) and check_exists(local_adb):
        return local_adb
        
    # Auto-Install Protocol
    import platform
    sys_name = platform.system().lower()
    
    print(f"\n  {Fore.CYAN}Downloading Android SDK Platform Tools (ADB)...{Style.RESET_ALL}")
    
    if is_wsl or sys_name == 'windows':
        url = "https://dl.google.com/android/repository/platform-tools-latest-windows.zip"
    elif sys_name == 'darwin':
        url = "https://dl.google.com/android/repository/platform-tools-latest-darwin.zip"
    else:
        url = "https://dl.google.com/android/repository/platform-tools-latest-linux.zip"
        
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        zip_path = os.path.join(DATA_DIR, "platform-tools.zip")
        
        # Download
        import requests
        response = requests.get(url, stream=True, timeout=30)
        response.raise_for_status()
        with open(zip_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
                
        # Extract
        print(f"  {Fore.CYAN}Extracting Platform Tools...{Style.RESET_ALL}")
        import zipfile
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(DATA_DIR)
            
        os.remove(zip_path)
        
        # Make executable on Unix
        if not os.name == 'nt' and not is_wsl:
            os.chmod(local_adb, 0o755)
            
        if check_exists(local_adb):
            print(f"  {Fore.GREEN}✅ ADB installed successfully!{Style.RESET_ALL}")
            return local_adb
    except Exception as e:
        print(f"  {Fore.RED}❌ Failed to download/install ADB: {e}{Style.RESET_ALL}")
        
    return 'adb'

ADB_CMD = None # Lazy initialized when needed
_active_device = None  # Track the active device ID for multi-device support

def _ensure_adb():
    """Ensure ADB is downloaded and return the command path"""
    global ADB_CMD
    if ADB_CMD is None:
        ADB_CMD = _get_adb_cmd()
    return ADB_CMD

KNOWN_BLOATWARE = {
    # Facebook
    'com.facebook.appmanager': 'Facebook App Manager',
    'com.facebook.services': 'Facebook Services',
    'com.facebook.system': 'Facebook System',
    'com.facebook.katana': 'Facebook App',
    # Samsung
    'com.samsung.android.game.gamehome': 'Samsung Game Home',
    'com.samsung.android.game.gametools': 'Samsung Game Tools',
    'com.samsung.android.app.spage': 'Samsung Free / Bixby',
    'com.samsung.android.bixby.agent': 'Bixby Voice',
    'com.samsung.android.bixby.service': 'Bixby Service',
    'com.samsung.android.visionintelligence': 'Bixby Vision',
    'com.samsung.android.forest': 'Samsung Kids',
    'com.samsung.android.app.tips': 'Samsung Tips',
    'com.samsung.android.ardrawing': 'AR Doodle',
    'com.samsung.android.aremoji': 'AR Emoji',
    'com.samsung.android.arzone': 'AR Zone',
    'com.samsung.android.app.routines': 'Bixby Routines',
    'com.samsung.android.samsungpass': 'Samsung Pass',
    'com.samsung.android.samsungpay.gear': 'Samsung Pay Watch',
    'com.samsung.android.spay': 'Samsung Pay',
    'com.samsung.android.mobileservice': 'Samsung Experience Service',
    'com.samsung.android.app.cocktailbarservice': 'Edge Panel',
    # Xiaomi / MIUI
    'com.miui.analytics': 'MIUI Analytics',
    'com.miui.msa.global': 'MIUI System Ads',
    'com.miui.cloudservice': 'Mi Cloud',
    'com.miui.cloudbackup': 'Mi Cloud Backup',
    'com.xiaomi.glgm': 'Xiaomi Games',
    'com.xiaomi.mipicks': 'Mi Picks (GetApps)',
    'com.miui.player': 'Mi Music',
    'com.miui.videoplayer': 'Mi Video',
    'com.miui.yellowpage': 'Mi Yellow Pages',
    'com.miui.bugreport': 'MIUI Bug Report',
    'com.miui.miservice': 'Mi Service',
    'com.xiaomi.midrop': 'Mi Share',
    'com.mi.globalbrowser': 'Mi Browser',
    # Oppo / ColorOS
    'com.coloros.gamespace': 'Game Space',
    'com.heytap.browser': 'HeyTap Browser',
    'com.heytap.music': 'HeyTap Music',
    'com.heytap.cloud': 'HeyTap Cloud',
    'com.oppo.market': 'Oppo App Market',
    # Vivo / FuntouchOS
    'com.vivo.browser': 'Vivo Browser',
    'com.vivo.weather': 'Vivo Weather',
    'com.vivo.game': 'Vivo Game Center',
    'com.vivo.appstore': 'Vivo App Store',
    'com.vivo.easyshare': 'Vivo EasyShare',
    # Realme
    'com.heytap.market': 'Realme App Market',
    # OnePlus
    'com.oneplus.gamespace': 'OnePlus Game Space',
    'com.oneplus.membership': 'OnePlus Community',
    # Google (optional removals)
    'com.google.android.apps.magazines': 'Google News',
    'com.google.android.apps.tachyon': 'Google Duo / Meet',
    'com.google.android.videos': 'Google TV',
    'com.google.android.music': 'Google Play Music',
    'com.google.android.apps.youtube.music': 'YouTube Music',
    'com.google.android.apps.docs': 'Google Docs',
    'com.google.android.apps.maps': 'Google Maps',
    'com.google.ar.core': 'Google AR Core',
}

CRITICAL_PACKAGES = {
    'com.android.systemui', 'com.android.settings', 'com.android.phone',
    'com.android.server.telecom', 'com.android.providers.contacts',
    'com.android.providers.telephony', 'com.android.launcher3',
    'com.android.inputmethod.latin', 'com.android.bluetooth',
    'com.android.nfc', 'com.android.wifi', 'com.android.shell',
    'com.android.packageinstaller', 'com.android.permissioncontroller',
    'com.google.android.gms', 'com.google.android.gsf',
    'com.android.vending', 'com.android.providers.settings',
}

def _adb_run(cmd, timeout=15, device=None):
    """Run an adb command and return (success, stdout). If device is specified, adds -s <device> flag."""
    # Auto-inject -s <device_id> for device-specific commands
    if device and len(cmd) > 1 and cmd[0] == ADB_CMD and cmd[1] != 'devices':
        cmd = [cmd[0], '-s', device] + cmd[1:]
    elif _active_device and len(cmd) > 1 and cmd[0] == ADB_CMD and cmd[1] not in ('devices', 'version', 'pair', 'connect'):
        cmd = [cmd[0], '-s', _active_device] + cmd[1:]
    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout
        )
        output = result.stdout.strip()
        if not output and result.stderr:
            output = result.stderr.strip()
        return result.returncode == 0, output
    except FileNotFoundError:
        return False, "ADB not found"
    except subprocess.TimeoutExpired:
        return False, "Command timed out"
    except Exception as e:
        return False, str(e)

def _adb_get_device_info(device=None):
    """Get connected device model name"""
    ok, out = _adb_run([ADB_CMD, 'shell', 'getprop', 'ro.product.model'], device=device)
    if ok and out:
        return out
    return "Unknown Device"

def _adb_get_packages(filter_type='all'):
    """Get list of packages. filter_type: 'all', 'system', 'third_party'"""
    cmd = [ADB_CMD, 'shell', 'pm', 'list', 'packages']
    if filter_type == 'system':
        cmd.append('-s')
    elif filter_type == 'third_party':
        cmd.append('-3')
    
    ok, out = _adb_run(cmd, timeout=30)
    if not ok:
        if out:
            print(f"  {Fore.RED}ADB Error: {out}{Style.RESET_ALL}")
        return []
    
    packages = []
    for line in out.splitlines():
        pkg = line.replace('package:', '').strip()
        if pkg:
            packages.append(pkg)
    return sorted(packages)

def _get_app_label(pkg):
    """Get human-readable app label from package name"""
    # 1. Check known bloatware database first
    if pkg in KNOWN_BLOATWARE:
        return KNOWN_BLOATWARE[pkg]
    
    # 2. Derive a readable name from the package name
    # com.whatsapp -> Whatsapp
    # com.instagram.android -> Instagram
    # com.google.android.youtube -> Youtube
    parts = pkg.split('.')
    
    # Remove common prefixes
    skip = {'com', 'org', 'net', 'android', 'google', 'samsung', 'xiaomi', 
            'miui', 'oppo', 'vivo', 'oneplus', 'huawei', 'sec', 'app', 'apps', 'mobile'}
    
    # Find the most meaningful part (usually the last non-generic segment)
    meaningful = [p for p in parts if p.lower() not in skip and len(p) > 1]
    
    if meaningful:
        # Use the last meaningful part, title-cased
        name = meaningful[-1].replace('_', ' ').replace('-', ' ').title()
        return name
    
    # Fallback: use last part of package name
    return parts[-1].title() if parts else pkg

def _adb_display_packages(packages, search_filter=None):
    """Display packages in a nice table and return the filtered list"""
    filtered = packages
    if search_filter:
        q = search_filter.lower()
        filtered = [p for p in packages if q in p.lower() or 
                     q in _get_app_label(p).lower()]
    
    if not filtered:
        if search_filter:
            print(f"\n  {Fore.YELLOW}No packages found matching '{search_filter}'.{Style.RESET_ALL}")
        else:
            print(f"\n  {Fore.YELLOW}No packages found.{Style.RESET_ALL}")
        return []
    
    print(f"\n  {Fore.CYAN}{'#':<5} {'App Name':<30} {'Package Name'}{Style.RESET_ALL}")
    print(f"  {'─'*5} {'─'*30} {'─'*45}")
    
    for i, pkg in enumerate(filtered, 1):
        label = _get_app_label(pkg)
        
        if pkg in CRITICAL_PACKAGES:
            color = Fore.RED
            label = f"⚠️  {label}"
        elif pkg in KNOWN_BLOATWARE:
            color = Fore.YELLOW
            label = f"🗑️  {label}"
        else:
            color = Fore.WHITE
        
        print(f"  {color}{i:<5} {label:<30} {pkg}{Style.RESET_ALL}")
    
    print(f"\n  {Fore.WHITE}Total: {len(filtered)} packages{Style.RESET_ALL}")
    return filtered

def run_adb_mode():
    """ADB Bloatware Remover - Interactive Mode"""
    global _active_device
    # Ensure ADB is downloaded first
    _ensure_adb()
    
    # Step 1: Check if ADB is available
    ok, version_out = _adb_run([ADB_CMD, 'version'])
    if not ok:
        print(f"\n  {Fore.RED}❌ ADB is not installed or not in PATH.{Style.RESET_ALL}")
        print(f"  {Fore.WHITE}Install Android SDK Platform Tools:")
        print(f"  {Fore.CYAN}https://developer.android.com/tools/releases/platform-tools{Style.RESET_ALL}")
        input("\n  Press Enter to return...")
        return
    
    adb_version_line = version_out.splitlines()[0] if version_out else "ADB"
    
    while True:
        try:
            os.system('cls' if os.name == 'nt' else 'clear')
            
            # Header
            adb_banner = r"""
     █████╗ ██████╗ ██████╗ 
    ██╔══██╗██╔══██╗██╔══██╗
    ███████║██║  ██║██████╔╝
    ██╔══██║██║  ██║██╔══██╗
    ██║  ██║██████╔╝██████╔╝
    ╚═╝  ╚═╝╚═════╝ ╚═════╝"""
            print_gradient_text(adb_banner, (255, 200, 0), (180, 0, 255))
            print(f"  {Fore.WHITE}{Style.DIM}Bloatware Remover  •  {adb_version_line}{Style.RESET_ALL}")
            
            # Device status
            ok, devices_out = _adb_run([ADB_CMD, 'devices'])
            connected_devices = []
            offline_devices = []
            if ok:
                for line in devices_out.splitlines()[1:]:
                    parts = line.strip().split('\t')
                    if len(parts) == 2:
                        if parts[1] == 'device':
                            connected_devices.append(parts[0])
                        elif parts[1] in ('offline', 'unauthorized'):
                            offline_devices.append((parts[0], parts[1]))
            
            if connected_devices:
                _active_device = connected_devices[0]
                device_name = _adb_get_device_info(connected_devices[0])
                print(f"\n  {Fore.GREEN}✅ Connected: {device_name} ({connected_devices[0]}){Style.RESET_ALL}")
                if len(connected_devices) > 1:
                    print(f"  {Fore.YELLOW}   + {len(connected_devices)-1} more device(s){Style.RESET_ALL}")
            elif offline_devices:
                for dev_id, status in offline_devices:
                    print(f"\n  {Fore.RED}⚠  Device {dev_id} is {status.upper()}{Style.RESET_ALL}")
                    if status == 'offline':
                        print(f"  {Fore.WHITE}{Style.DIM}   Try: Disconnect & reconnect USB, or re-pair wirelessly.{Style.RESET_ALL}")
                    elif status == 'unauthorized':
                        print(f"  {Fore.WHITE}{Style.DIM}   Check your phone — tap 'Allow USB Debugging' on the popup.{Style.RESET_ALL}")
            else:
                print(f"\n  {Fore.YELLOW}⚠  No devices connected.{Style.RESET_ALL}")
                print(f"  {Fore.WHITE}{Style.DIM}   Enable USB Debugging on your phone, or use WiFi pairing below.{Style.RESET_ALL}")
            
            # Menu
            print(f"\n  {Fore.WHITE}Commands:{Style.RESET_ALL}")
            if connected_devices:
                print(f"  {Fore.CYAN}[1]{Style.RESET_ALL} List all apps")
                print(f"  {Fore.CYAN}[2]{Style.RESET_ALL} List system bloatware {Fore.YELLOW}(recommended removals){Style.RESET_ALL}")
                print(f"  {Fore.CYAN}[3]{Style.RESET_ALL} List 3rd-party apps")
                print(f"  {Fore.CYAN}[4]{Style.RESET_ALL} Search by name")
                print(f"  {Fore.CYAN}[5]{Style.RESET_ALL} Reinstall a removed app")
                print(f"  {Fore.CYAN}[6]{Style.RESET_ALL} Uninstalled Apps History")
            else:
                print(f"  {Fore.CYAN}[1]{Style.RESET_ALL} Pair device wirelessly {Fore.MAGENTA}(Android 11+){Style.RESET_ALL}")
            print(f"  {Fore.RED}[b]{Style.RESET_ALL} Back to main menu")
            
            choice = input(f"\n  {Fore.LIGHTGREEN_EX}>{Style.RESET_ALL} ").strip().lower()
            
            if choice == 'b':
                return
            
            elif choice == '1':
                if not connected_devices:
                    # Pair wirelessly
                    _adb_qr_pair()
                    input("\n  Press Enter...")
                    continue
                print(f"\n  {Fore.CYAN}Loading all packages...{Style.RESET_ALL}")
                pkgs = _adb_get_packages('all')
                filtered = _adb_display_packages(pkgs)
                if filtered:
                    _adb_uninstall_prompt(filtered)
                else:
                    input("\n  Press Enter...")
            
            elif choice == '2' and connected_devices:
                print(f"\n  {Fore.CYAN}Scanning for known bloatware...{Style.RESET_ALL}")
                all_pkgs = _adb_get_packages('all')
                bloat = [p for p in all_pkgs if p in KNOWN_BLOATWARE]
                if bloat:
                    filtered = _adb_display_packages(bloat)
                    if filtered:
                        _adb_uninstall_prompt(filtered)
                else:
                    print(f"\n  {Fore.GREEN}✅ No known bloatware found! Your device is clean.{Style.RESET_ALL}")
                    input("\n  Press Enter...")
            
            elif choice == '3' and connected_devices:
                print(f"\n  {Fore.CYAN}Loading 3rd-party apps...{Style.RESET_ALL}")
                pkgs = _adb_get_packages('third_party')
                filtered = _adb_display_packages(pkgs)
                if filtered:
                    _adb_uninstall_prompt(filtered)
                else:
                    input("\n  Press Enter...")
            
            elif choice == '4' and connected_devices:
                query = input(f"\n  {Fore.WHITE}Search: {Style.RESET_ALL}").strip()
                if query:
                    all_pkgs = _adb_get_packages('all')
                    filtered = _adb_display_packages(all_pkgs, search_filter=query)
                    if filtered:
                        _adb_uninstall_prompt(filtered)
                    else:
                        input("\n  Press Enter...")
            
            elif choice == '5' and connected_devices:
                pkg_name = input(f"\n  {Fore.WHITE}Enter package name to reinstall: {Style.RESET_ALL}").strip()
                if pkg_name:
                    print(f"\n  {Fore.CYAN}Reinstalling {pkg_name}...{Style.RESET_ALL}")
                    ok, out = _adb_run([ADB_CMD, 'shell', 'cmd', 'package', 'install-existing', pkg_name])
                    if ok and 'installed' in out.lower():
                        print(f"  {Fore.GREEN}✅ {pkg_name} reinstalled successfully!{Style.RESET_ALL}")
                    else:
                        print(f"  {Fore.RED}❌ Failed: {out or 'Package may not be available for reinstall.'}{Style.RESET_ALL}")
                input("\n  Press Enter...")
                
            elif choice == '6' and connected_devices:
                _adb_show_history()
            
        except KeyboardInterrupt:
            return

def _log_history_cli(pkg, label):
    """Log history from CLI mode without depending on Flask requests"""
    ok, out = _adb_run([ADB_CMD, 'devices'])
    if not ok: return
    
    device_id, device_model = "", ""
    for line in out.splitlines()[1:]:
        p = line.strip().split('\t')
        if len(p) == 2 and p[1] == 'device':
            device_id = p[0]
            device_model = _adb_get_device_info()
            break
            
    if not device_id: return
    
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute('SELECT id FROM adb_history WHERE device_id=? AND package=?', (device_id, pkg))
        if not c.fetchone():
            c.execute('INSERT INTO adb_history (device_id, device_model, package, label) VALUES (?, ?, ?, ?)',
                      (device_id, device_model, pkg, label))
            conn.commit()
        conn.close()
    except Exception as e:
        print(f"Failed to log history: {e}")

def _adb_qr_pair():
    """Wireless ADB pairing (Android 11+) using pairing code"""
    
    print(f"\n  {Fore.CYAN}{'─'*50}{Style.RESET_ALL}")
    print(f"  {Fore.MAGENTA}📲 Wireless Pairing (Android 11+){Style.RESET_ALL}")
    print(f"  {Fore.CYAN}{'─'*50}{Style.RESET_ALL}")
    print(f"\n  {Fore.WHITE}On your phone:{Style.RESET_ALL}")
    print(f"  {Fore.WHITE}  1. Go to Settings > Developer Options{Style.RESET_ALL}")
    print(f"  {Fore.WHITE}  2. Enable Wireless Debugging{Style.RESET_ALL}")
    print(f"  {Fore.WHITE}  3. Tap 'Pair device with pairing code'{Style.RESET_ALL}")
    print(f"  {Fore.WHITE}  4. Note the Wi-Fi pairing code, IP address & Port{Style.RESET_ALL}")
    
    # Get phone's pairing details
    phone_ip = input(f"\n  {Fore.WHITE}Phone IP address (e.g. 192.168.1.5): {Style.RESET_ALL}").strip()
    if not phone_ip:
        print(f"  {Fore.RED}Cancelled.{Style.RESET_ALL}")
        return
    
    pair_port = input(f"  {Fore.WHITE}Phone pairing port (shown on pairing screen): {Style.RESET_ALL}").strip()
    if not pair_port:
        print(f"  {Fore.RED}Cancelled.{Style.RESET_ALL}")
        return
    
    pair_code = input(f"  {Fore.WHITE}Pairing code (6 digits): {Style.RESET_ALL}").strip()
    if not pair_code:
        print(f"  {Fore.RED}Cancelled.{Style.RESET_ALL}")
        return
    
    # Step 1: Pair
    print(f"\n  {Fore.CYAN}Pairing with {phone_ip}:{pair_port}...{Style.RESET_ALL}")
    ok, out = _adb_run([ADB_CMD, 'pair', f'{phone_ip}:{pair_port}', pair_code], timeout=20)
    
    if ok and ('success' in out.lower() or 'paired' in out.lower()):
        print(f"  {Fore.GREEN}✅ Paired successfully!{Style.RESET_ALL}")
        
        # Step 2: Connect
        print(f"\n  {Fore.WHITE}Now enter the connect port (shown under 'Wireless Debugging' main screen,{Style.RESET_ALL}")
        print(f"  {Fore.WHITE}NOT the pairing port — it's a different number):{Style.RESET_ALL}")
        connect_port = input(f"  {Fore.WHITE}Connect port: {Style.RESET_ALL}").strip()
        
        if connect_port:
            print(f"\n  {Fore.CYAN}Connecting to {phone_ip}:{connect_port}...{Style.RESET_ALL}")
            ok2, out2 = _adb_run([ADB_CMD, 'connect', f'{phone_ip}:{connect_port}'], timeout=10)
            if ok2 and 'connected' in out2.lower():
                print(f"  {Fore.GREEN}✅ Connected! Device is ready.{Style.RESET_ALL}")
            else:
                print(f"  {Fore.RED}❌ Connection failed: {out2}{Style.RESET_ALL}")
                print(f"  {Fore.WHITE}Tip: Make sure the connect port is correct (different from pairing port).{Style.RESET_ALL}")
    else:
        print(f"  {Fore.RED}❌ Pairing failed: {out}{Style.RESET_ALL}")
        print(f"  {Fore.WHITE}Tip: Make sure your phone and PC are on the same WiFi network.{Style.RESET_ALL}")
        print(f"  {Fore.WHITE}      Also ensure the pairing dialog is still open on your phone.{Style.RESET_ALL}")

def _adb_uninstall_prompt(packages):
    """Prompt user to select packages for uninstall"""
    print(f"\n  {Fore.WHITE}Enter package numbers to uninstall (comma-separated), or 'c' to cancel:{Style.RESET_ALL}")
    selection = input(f"  {Fore.LIGHTGREEN_EX}>{Style.RESET_ALL} ").strip()
    
    if selection.lower() == 'c' or not selection:
        return
    
    try:
        indices = [int(x.strip()) - 1 for x in selection.split(',')]
        selected = [packages[i] for i in indices if 0 <= i < len(packages)]
    except (ValueError, IndexError):
        print(f"  {Fore.RED}Invalid selection.{Style.RESET_ALL}")
        input("\n  Press Enter...")
        return
    
    if not selected:
        return
    
    # Safety check
    critical_found = [p for p in selected if p in CRITICAL_PACKAGES]
    if critical_found:
        print(f"\n  {Fore.RED}{'═'*50}{Style.RESET_ALL}")
        print(f"  {Fore.RED}⚠️  WARNING: CRITICAL SYSTEM PACKAGES DETECTED!{Style.RESET_ALL}")
        print(f"  {Fore.RED}{'═'*50}{Style.RESET_ALL}")
        for p in critical_found:
            print(f"  {Fore.RED}  • {p}{Style.RESET_ALL}")
        print(f"\n  {Fore.RED}Removing these can BRICK your device!{Style.RESET_ALL}")
        confirm = input(f"  {Fore.RED}Type 'YES I UNDERSTAND' to proceed: {Style.RESET_ALL}").strip()
        if confirm != 'YES I UNDERSTAND':
            print(f"  {Fore.GREEN}Cancelled. Smart choice!{Style.RESET_ALL}")
            input("\n  Press Enter...")
            return
    
    # Confirm
    print(f"\n  {Fore.YELLOW}The following {len(selected)} app(s) will be uninstalled:{Style.RESET_ALL}")
    for pkg in selected:
        label = KNOWN_BLOATWARE.get(pkg, pkg)
        print(f"  {Fore.WHITE}  • {pkg} {Fore.YELLOW}({label}){Style.RESET_ALL}")
    
    confirm = input(f"\n  {Fore.WHITE}Proceed? (y/n): {Style.RESET_ALL}").strip().lower()
    if confirm != 'y':
        print(f"  {Fore.WHITE}Cancelled.{Style.RESET_ALL}")
        input("\n  Press Enter...")
        return
    
    # Uninstall
    success_count = 0
    for pkg in selected:
        label = _get_app_label(pkg)
        print(f"  {Fore.CYAN}Removing {label}...{Style.RESET_ALL}", end=' ')
        
        # Method 1: Uninstall keeping data (-k)
        ok, out = _adb_run([ADB_CMD, 'shell', 'pm', 'uninstall', '-k', '--user', '0', pkg])
        if ok and 'success' in out.lower():
            print(f"{Fore.GREEN}✅ Done{Style.RESET_ALL}")
            success_count += 1
            continue
        
        # Method 2: Force uninstall (remove data too)
        ok, out = _adb_run([ADB_CMD, 'shell', 'pm', 'uninstall', '--user', '0', pkg])
        if ok and 'success' in out.lower():
            print(f"{Fore.GREEN}✅ Done (force){Style.RESET_ALL}")
            success_count += 1
            _log_history_cli(pkg, label)
            continue
        
        # Method 3: Disable the app as last resort
        ok, out = _adb_run([ADB_CMD, 'shell', 'pm', 'disable-user', '--user', '0', pkg])
        if ok and ('disabled' in out.lower() or 'new state' in out.lower()):
            print(f"{Fore.YELLOW}✅ Disabled (could not fully remove){Style.RESET_ALL}")
            success_count += 1
            _log_history_cli(pkg, label)
            continue
        
        print(f"{Fore.RED}❌ Failed: {out}{Style.RESET_ALL}")
    
    print(f"\n  {Fore.GREEN}✅ {success_count}/{len(selected)} apps removed/disabled successfully.{Style.RESET_ALL}")
    print(f"  {Fore.WHITE}{Style.DIM}Tip: Use option [5] or [6] to reinstall any accidentally removed app.{Style.RESET_ALL}")
    input("\n  Press Enter...")

def _adb_show_history():
    """Show uninstalled apps history for the connected device"""
    ok, out = _adb_run([ADB_CMD, 'devices'])
    if not ok: return
    
    device_id = None
    for line in out.splitlines()[1:]:
        p = line.strip().split('\t')
        if len(p) == 2 and p[1] == 'device':
            device_id = p[0]
            break
            
    if not device_id:
        print(f"\n  {Fore.YELLOW}No device connected.{Style.RESET_ALL}")
        input("\n  Press Enter...")
        return
    
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute('SELECT package, label, timestamp FROM adb_history WHERE device_id=? ORDER BY timestamp DESC', (device_id,))
        rows = c.fetchall()
        conn.close()
        
        if not rows:
            print(f"\n  {Fore.YELLOW}No uninstallation history found for this device.{Style.RESET_ALL}")
            input("\n  Press Enter...")
            return
            
        print(f"\n  {Fore.CYAN}{'#':<5} {'App Name':<30} {'Package Name'}{Style.RESET_ALL}")
        print(f"  {'─'*5} {'─'*30} {'─'*45}")
        
        packages = []
        for i, row in enumerate(rows, 1):
            packages.append(row['package'])
            print(f"  {Fore.WHITE}{i:<5} {row['label']:<30} {row['package']}{Style.RESET_ALL}")
            
        print(f"\n  {Fore.WHITE}Total: {len(packages)} apps previously uninstalled{Style.RESET_ALL}")
        
        print(f"\n  {Fore.WHITE}Enter package number(s) to reinstall, or 'c' to go back:{Style.RESET_ALL}")
        selection = input(f"  {Fore.LIGHTGREEN_EX}>{Style.RESET_ALL} ").strip()
        
        if selection.lower() == 'c' or not selection:
            return
            
        try:
            indices = [int(x.strip()) - 1 for x in selection.split(',')]
            selected = [packages[i] for i in indices if 0 <= i < len(packages)]
        except: return
        
        for pkg in selected:
            print(f"\n  {Fore.CYAN}Reinstalling {pkg}...{Style.RESET_ALL}")
            ok, out = _adb_run([ADB_CMD, 'shell', 'cmd', 'package', 'install-existing', pkg])
            if ok and 'installed' in out.lower():
                print(f"  {Fore.GREEN}✅ {pkg} reinstalled successfully!{Style.RESET_ALL}")
            else:
                print(f"  {Fore.RED}❌ Failed: {out or 'Package may not be available for reinstall.'}{Style.RESET_ALL}")
                
        input("\n  Press Enter...")
        
    except Exception as e:
        print(f"  {Fore.RED}Error viewing history: {e}{Style.RESET_ALL}")
        input("\n  Press Enter...")

def start_web_server():
    """Original server startup logic"""
    public_url, tunnel_proc = None, None
    with MoonSpinner("Initializing Web Engine"):
        threading.Thread(target=lambda: app.run(host='0.0.0.0', port=PORT, debug=False, use_reloader=False, threaded=True), daemon=True).start()
        
        if wait_for_server(PORT, timeout=10):
            public_url, tunnel_proc = start_cloudflare_tunnel(PORT)
        else:
            print("❌ Server failed to start")
            return

    if public_url:
        os.system('cls' if os.name == 'nt' else 'clear')
        print(f"Scan this QR code :\n")
        display_qr_image(public_url)
        print(f"\nType {Fore.RED}/q{Style.RESET_ALL} or press Ctrl+C to return to main menu.")
        
        try:
            if 'google.colab' in sys.modules:
                print("\n Running in Background. Type /q to stop.")
                while True:
                    user_input = input().strip()
                    if user_input in ['/q', '/quit']:
                        print("\n Returning to main menu...")
                        break
                    time.sleep(0.1)
            else:
                while True:
                    try:
                        user_input = input().strip()
                        if user_input in ['/q', '/quit']:
                            print("\n Returning to main menu...")
                            break
                    except EOFError:
                        time.sleep(1)
        except KeyboardInterrupt:
            print("\n Returning to main menu...")
        finally:
            if tunnel_proc:
                try: tunnel_proc.terminate()
                except: pass
    else:
        print("❌ Failed to create tunnel")

# Sab start karo
if __name__ == '__main__':
    main_launcher()