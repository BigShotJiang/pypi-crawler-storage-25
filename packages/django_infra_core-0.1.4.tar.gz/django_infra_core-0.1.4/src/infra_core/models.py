from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models
import os


INSTITUTION_TYPE_CHOICES = [
    ("ortaokul", "Ortaokul"),
    ("lise", "Lise"),
    ("hafızlık", "Hafızlık"),
]

GENDER_CHOICES = [
    ("erkek", "Erkek"),
    ("kız", "Kız"),
]

GRADE_CHOICES_BY_INSTITUTION_TYPE = {
    "ortaokul": [
        ("5", "5. Sınıf"),
        ("6", "6. Sınıf"),
        ("7", "7. Sınıf"),
        ("8", "8. Sınıf"),
    ],
    "lise": [
        ("9", "9. Sınıf"),
        ("10", "10. Sınıf"),
        ("11", "11. Sınıf"),
        ("12", "12. Sınıf"),
    ],
    "hafızlık": [
        ("d1", "Dönem 1"),
        ("d2", "Dönem 2"),
        ("d3", "Dönem 3"),
        ("d4", "Dönem 4"),
        ("d5", "Dönem 5"),
        ("d6", "Dönem 6"),
        ("d7", "Dönem 7"),
        ("d8", "Dönem 8"),
        ("d9", "Dönem 9"),
        ("d10", "Dönem 10"),
    ],
}

LEVEL_CHOICES_BY_INSTITUTION_TYPE = {
    "ortaokul": [
        ("1", "Seviye 1"),
        ("2", "Seviye 2"),
        ("3", "Seviye 3"),
    ],
    "lise": [
        ("1", "Seviye 1"),
        ("2", "Seviye 2"),
        ("3", "Seviye 3"),
    ],
    "hafızlık": [
        ("2", "Hafızlık"),
        ("1", "Hazırlık"),
    ],
}


def _merge_choices(choice_groups):
    merged = []
    seen = set()
    for group in choice_groups:
        for value, label in group:
            if value in seen:
                continue
            merged.append((value, label))
            seen.add(value)
    return merged


ALL_GRADE_CHOICES = _merge_choices(GRADE_CHOICES_BY_INSTITUTION_TYPE.values())
ALL_LEVEL_CHOICES = _merge_choices(LEVEL_CHOICES_BY_INSTITUTION_TYPE.values())

DEFAULT_INSTITUTION_TYPE = os.getenv("INSTITUTION_TYPE", "").strip().lower()


def _environment_choices(choice_map):
    if DEFAULT_INSTITUTION_TYPE in choice_map:
        return choice_map[DEFAULT_INSTITUTION_TYPE]
    return _merge_choices(choice_map.values())


DEFAULT_GRADE_CHOICES = _environment_choices(GRADE_CHOICES_BY_INSTITUTION_TYPE)
DEFAULT_LEVEL_CHOICES = _environment_choices(LEVEL_CHOICES_BY_INSTITUTION_TYPE)


class TimeStampedModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Oluşturulma Tarihi")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Güncellenme Tarihi")

    class Meta:
        abstract = True


class BaseInstitution(TimeStampedModel):
    name = models.CharField(max_length=200, verbose_name="Kurum Adı")
    code = models.SlugField(max_length=60, unique=True, verbose_name="Kurum Kodu")
    address = models.CharField(max_length=255, blank=True, verbose_name="Adres")
    location = models.CharField(max_length=255, blank=True, verbose_name="Konum")
    phone = models.CharField(max_length=20, blank=True, verbose_name="Telefon")
    email = models.EmailField(blank=True, verbose_name="E-posta")
    gender = models.CharField(
        max_length=20,
        choices=GENDER_CHOICES,
        blank=True,
        null=True,
        verbose_name="Cinsiyet",
    )
    institution_type = models.CharField(
        max_length=50,
        choices=INSTITUTION_TYPE_CHOICES,
        blank=True,
        null=True,
        verbose_name="Kurum Türü",
    )
    manager = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="managed_institution",
        blank=True,
        null=True,
        verbose_name="Kurum Yöneticisi",
    )

    class Meta:
        abstract = True
        ordering = ["name"]

    def __str__(self):
        return self.name


class BaseStudent(TimeStampedModel):
    first_name = models.CharField(max_length=255, verbose_name="Öğrenci Adı")
    last_name = models.CharField(max_length=255, verbose_name="Öğrenci Soyadı")
    grade = models.CharField(max_length=50, choices=DEFAULT_GRADE_CHOICES, verbose_name="Sınıf")
    level = models.CharField(max_length=50, choices=DEFAULT_LEVEL_CHOICES, blank=True, verbose_name="Seviye")
    status = models.BooleanField(default=True, verbose_name="Aktif")

    class Meta:
        abstract = True
        ordering = ["first_name", "last_name"]

    def __str__(self):
        return f"{self.first_name} {self.last_name}".strip()

    @staticmethod
    def get_grade_choices(institution_type):
        return GRADE_CHOICES_BY_INSTITUTION_TYPE.get((institution_type or "").lower(), [])

    @staticmethod
    def get_level_choices(institution_type):
        return LEVEL_CHOICES_BY_INSTITUTION_TYPE.get((institution_type or "").lower(), [])

    def clean(self):
        super().clean()

        institution = getattr(self, "institution", None)
        institution_type = getattr(institution, "institution_type", None)
        if not institution_type:
            return

        allowed_grades = {value for value, _ in self.get_grade_choices(institution_type)}
        allowed_levels = {value for value, _ in self.get_level_choices(institution_type)}

        errors = {}
        if self.grade and allowed_grades and self.grade not in allowed_grades:
            errors["grade"] = "Seçilen kurum türü için geçersiz sınıf değeri."
        if self.level and allowed_levels and self.level not in allowed_levels:
            errors["level"] = "Seçilen kurum türü için geçersiz seviye değeri."

        if errors:
            raise ValidationError(errors)
