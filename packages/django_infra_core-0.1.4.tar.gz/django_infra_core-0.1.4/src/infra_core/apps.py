from django.apps import AppConfig


class InfraCoreConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "infra_core"
    verbose_name = "Infra Core"
