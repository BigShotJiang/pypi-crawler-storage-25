from django.core.exceptions import ValidationError

try:
    from import_export.admin import ImportExportModelAdmin
    from import_export import resources
except ImportError:  # pragma: no cover - optional dependency
    ImportExportModelAdmin = object
    resources = None


class BaseModelResource(resources.ModelResource if resources else object):
    """
    Ortak import/export davranışı için temel resource sınıfı.
    """

    class Meta:
        skip_unchanged = True
        report_skipped = True


class ImportExportAdminMixin(ImportExportModelAdmin):
    """
    Ortak import/export admin ayarları.
    """

    import_id_fields = ("id",)


class InstitutionScopedAdminMixin:
    """
    Restrict non-superusers to records tied to their managed institution.
    """

    institution_fk_name = "institution"
    user_institution_attr = "managed_institution"

    def _user_institution(self, request):
        if request.user.is_superuser:
            return None
        return getattr(request.user, self.user_institution_attr, None)

    def _in_scope(self, request, obj=None):
        if request.user.is_superuser:
            return True

        institution = self._user_institution(request)
        if not institution:
            return False
        if obj is None:
            return True

        obj_institution = getattr(obj, self.institution_fk_name, None)
        return getattr(obj_institution, "id", None) == getattr(institution, "id", None)

    def get_queryset(self, request):
        queryset = super().get_queryset(request)
        if request.user.is_superuser:
            return queryset

        institution = self._user_institution(request)
        if not institution:
            return queryset.none()

        return queryset.filter(**{self.institution_fk_name: institution})

    def has_view_permission(self, request, obj=None):
        return super().has_view_permission(request, obj) and self._in_scope(request, obj)

    def has_change_permission(self, request, obj=None):
        return super().has_change_permission(request, obj) and self._in_scope(request, obj)

    def has_delete_permission(self, request, obj=None):
        return super().has_delete_permission(request, obj) and self._in_scope(request, obj)

    def has_add_permission(self, request):
        return super().has_add_permission(request) and self._in_scope(request, obj=None)

    def save_model(self, request, obj, form, change):
        if not request.user.is_superuser:
            institution = self._user_institution(request)
            if not institution:
                raise ValidationError("No managed institution assigned for the current user.")
            setattr(obj, self.institution_fk_name, institution)

        return super().save_model(request, obj, form, change)

    def get_readonly_fields(self, request, obj=None):
        readonly_fields = list(super().get_readonly_fields(request, obj))
        if not request.user.is_superuser and self.institution_fk_name not in readonly_fields:
            readonly_fields.append(self.institution_fk_name)
        return readonly_fields
