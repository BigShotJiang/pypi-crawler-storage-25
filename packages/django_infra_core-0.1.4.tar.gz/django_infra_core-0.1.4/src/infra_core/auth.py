from functools import wraps

from django.core.exceptions import PermissionDenied


def get_user_institution(user, attr_name="managed_institution"):
    if getattr(user, "is_superuser", False):
        return None
    return getattr(user, attr_name, None)


class InstitutionContextMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        request.institution = None
        if request.user.is_authenticated:
            request.institution = get_user_institution(request.user)
        return self.get_response(request)


def institution_required(view_func):
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        if request.user.is_superuser:
            return view_func(request, *args, **kwargs)
        if not getattr(request.user, "is_authenticated", False):
            raise PermissionDenied("Authentication required.")
        if not get_user_institution(request.user):
            raise PermissionDenied("User has no managed institution.")
        return view_func(request, *args, **kwargs)

    return wrapper
