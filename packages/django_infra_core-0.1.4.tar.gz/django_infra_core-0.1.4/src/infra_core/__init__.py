default_app_config = "infra_core.apps.InfraCoreConfig"
