import os

from django.core.management.utils import get_random_secret_key


def env_bool(name, default=False):
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def env_list(name, default=""):
    raw = os.getenv(name, default)
    return [item.strip() for item in raw.split(",") if item.strip()]


def normalize_public_storage_origin(value):
    if not value:
        return ""

    value = value.strip().rstrip("/")
    if value.startswith("http://") or value.startswith("https://"):
        parts = value.split("//", 1)
        host = parts[1].split("/", 1)[0]
        return f"{parts[0]}//{host}"

    host = value.split("/", 1)[0]
    return f"https://{host}"


def build_security_config(
    default_csrf_trusted_origins="",
    default_allowed_hosts="*",
):
    debug = env_bool("DEBUG", env_bool("DJANGO_DEBUG", False))

    return {
        "DEBUG": debug,
        "SECRET_KEY": os.getenv("DJANGO_SECRET_KEY", get_random_secret_key()),
        "SECURE_CONTENT_TYPE_NOSNIFF": True,
        "SECURE_HSTS_SECONDS": 31536000 if not debug else 0,
        "SECURE_HSTS_INCLUDE_SUBDOMAINS": not debug,
        "SECURE_HSTS_PRELOAD": not debug,
        "SECURE_SSL_REDIRECT": env_bool("SECURE_SSL_REDIRECT", False),
        "USE_X_FORWARDED_HOST": True,
        "SECURE_PROXY_SSL_HEADER": ("HTTP_X_FORWARDED_PROTO", "https"),
        "CSRF_TRUSTED_ORIGINS": env_list(
            "DJANGO_CSRF_TRUSTED_ORIGINS",
            default_csrf_trusted_origins,
        ),
        "ALLOWED_HOSTS": env_list("DJANGO_ALLOWED_HOSTS", default_allowed_hosts),
        "CSRF_COOKIE_SECURE": not debug,
        "SESSION_COOKIE_SECURE": not debug,
    }


def build_database_config(prefix="POSTGRES"):
    return {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": os.getenv(f"{prefix}_DB", "postgres"),
        "USER": os.getenv(f"{prefix}_USER", "postgres"),
        "PASSWORD": os.getenv(f"{prefix}_PASSWORD", "postgres"),
        "HOST": os.getenv(f"{prefix}_HOST", "postgres-service"),
        "PORT": os.getenv(f"{prefix}_PORT", "5432"),
    }


def build_storage_config():
    storage_type = os.getenv("STORAGE_TYPE", "local").strip().lower()
    if storage_type != "cloud":
        return None

    bucket_name = os.getenv("AWS_STORAGE_BUCKET_NAME")
    endpoint_url = os.getenv("AWS_S3_ENDPOINT_URL")
    custom_domain = os.getenv("AWS_S3_CUSTOM_DOMAIN")
    region_name = os.getenv("AWS_S3_REGION_NAME", "auto")
    prefix = os.getenv("CLOUD_STORAGE_PREFIX", "").strip("/")

    location_static = f"{prefix}/static" if prefix else "static"
    location_media = f"{prefix}/media" if prefix else "media"

    return {
        "bucket_name": bucket_name,
        "endpoint_url": endpoint_url,
        "custom_domain": custom_domain,
        "region_name": region_name,
        "storages": {
            "default": {
                "BACKEND": "storages.backends.s3.S3Storage",
                "OPTIONS": {
                    "location": location_media,
                    "default_acl": None,
                    "file_overwrite": False,
                },
            },
            "staticfiles": {
                "BACKEND": "storages.backends.s3.S3Storage",
                "OPTIONS": {
                    "location": location_static,
                    "default_acl": None,
                },
            },
        },
    }
