import requests
import os
from typing import Optional

class LifelineClient:
    def __init__(self, api_key: Optional[str] = None, base_url: str = "https://asad999-lifelineopenapi.hf.space"):
        """
        Initialize the SDK.
        The base_url defaults to your live Hugging Face API.
        An api_key is required for analyzing images, but not for generating keys.
        """
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")

    def generate_api_key(self, email: str, admin_secret: str) -> dict:
        """
        Generates a new API key for a user.
        Requires the master admin_secret set in your Hugging Face space.
        """
        endpoint = f"{self.base_url}/v1/keys/generate"
        
        # FastAPI translates 'admin_secret' to 'admin-secret' in headers
        headers = {
            "admin-secret": admin_secret,
            "Content-Type": "application/json"
        }
        
        payload = {"email": email}
        
        response = requests.post(endpoint, headers=headers, json=payload)
        
        # Raise an error if unauthorized or limit reached
        response.raise_for_status() 
        
        return response.json()

    def delete_oldest_api_key(self, email: str, admin_secret: str) -> dict:
        """
        Deletes the oldest API key associated with the provided email.
        Requires the master admin_secret set in your Hugging Face space.
        """
        endpoint = f"{self.base_url}/v1/keys/delete-oldest"
        
        headers = {
            "admin-secret": admin_secret,
            "Content-Type": "application/json"
        }
        
        payload = {"email": email}
        
        # Using requests.delete instead of post
        response = requests.delete(endpoint, headers=headers, json=payload)
        
        # Raise an error if unauthorized, email missing, or no keys found
        response.raise_for_status() 
        
        return response.json()

    def analyze(self, image_path: str) -> dict:
        """
        Uploads an ECG image to the backend and returns the prediction 
        from the original image-only pipeline.
        """
        if not self.api_key:
            raise ValueError("An API key is required to use the analyze function. Initialize LifelineClient with api_key='your_key'.")
            
        if not os.path.exists(image_path):
            raise FileNotFoundError(f"Could not find image at {image_path}")

        endpoint = f"{self.base_url}/v1/analyze"
        
        # Inject the API key into the headers
        headers = {"x-api-key": self.api_key}

        # Open the file in binary mode and send it as multipart/form-data
        with open(image_path, "rb") as f:
            files = {"file": (os.path.basename(image_path), f, "image/jpeg")}
            response = requests.post(endpoint, headers=headers, files=files)

        response.raise_for_status() 
        
        return response.json()

    def analyze_dynamic(self, prompt: str, image_path: Optional[str] = None, context: Optional[str] = None) -> dict:
        """
        Sends a multimodal request to the dynamic LLM pipeline.
        Requires a prompt. Image and context are optional.
        """
        if not self.api_key:
            raise ValueError("An API key is required to use the analyze_dynamic function. Initialize LifelineClient with api_key='your_key'.")

        endpoint = f"{self.base_url}/v1/analyze-dynamic"
        
        headers = {"x-api-key": self.api_key}

        # Prepare the form data for text inputs
        data_payload = {
            "prompt": prompt
        }
        if context:
            data_payload["context"] = context

        # If an image is provided, send as multipart/form-data
        if image_path:
            if not os.path.exists(image_path):
                raise FileNotFoundError(f"Could not find image at {image_path}")
                
            with open(image_path, "rb") as f:
                # Let requests library automatically handle content-type detection based on file extension
                files = {"file": (os.path.basename(image_path), f)}
                response = requests.post(endpoint, headers=headers, data=data_payload, files=files)
        
        # If no image is provided, send as standard form data
        else:
            response = requests.post(endpoint, headers=headers, data=data_payload)

        response.raise_for_status() 
        
        return response.json()