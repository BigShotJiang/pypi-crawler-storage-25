"""Click CLI interface for planner-auto."""

import asyncio
import json
import logging
import os
import shutil
import sqlite3

import click

from planner_auto import load_env

# Load .env at CLI startup so API keys are available without manual shell exports.
load_env()

logger = logging.getLogger(__name__)

from planner_auto.db import (
    CURRENT_SCHEMA_VERSION,
    DEFAULT_DB_PATH,
    add_context_entry,
    create_session,
    get_all_plan_drafts,
    get_context_entries,
    get_messages,
    get_open_blockers,
    get_schema_version,
    get_session,
    get_session_config,
    init_schema,
    open_db,
    resolve_blocker,
    save_session_config,
    update_session_status,
)
from planner_auto.errors import (
    CommandNotAllowedError,
    SDKError,
    SessionNotFoundError,
)
from planner_auto.git_utils import discover_repo_root
from planner_auto.sdk_wrapper import resolve_default_backend
from planner_auto.inspect import (
    dump_session_json,
    format_config,
    format_dispositions,
    format_raw_response,
    format_reviews_table,
    reconstruct_history,
)
from planner_auto.logging import setup_session_logging
from planner_auto.loop.engine import ReviewLoopEngine
from planner_auto.session import SessionManager
from planner_auto.state import Phase


def _get_conn(ctx: click.Context) -> sqlite3.Connection:
    """Get or create a database connection from Click context."""
    if "conn" not in ctx.obj:
        conn = open_db(ctx.obj.get("db_path"))
        init_schema(conn)
        ctx.obj["conn"] = conn
    return ctx.obj["conn"]


def _resolve_session_backend(conn: sqlite3.Connection, session_id: str) -> str:
    """Read claude_backend from session config, falling back to auto-detect."""
    cfg_row = get_session_config(conn, session_id)
    if cfg_row:
        try:
            cfg = json.loads(cfg_row["config_json"])
            backend = cfg.get("claude_backend")
            if backend in ("direct", "sdk"):
                return backend
        except (json.JSONDecodeError, TypeError):
            pass
    return resolve_default_backend()


@click.group()
@click.option("--db-path", default=None, envvar="PLANNER_AUTO_DB", help="Custom DB path.")
@click.pass_context
def cli(ctx, db_path):
    """Planner-auto: Interactive planning session manager."""
    ctx.ensure_object(dict)
    if db_path:
        ctx.obj["db_path"] = db_path


@cli.command()
@click.option("--project", required=True, help="Project name.")
@click.option("--verbose", is_flag=True, default=False, help="Verbose logging to stderr.")
@click.option("--debug", is_flag=True, default=False, help="Debug logging to stderr.")
@click.option(
    "--repo-root",
    default=None,
    help="Override repository root path (auto-detected from cwd if not provided).",
)
@click.option(
    "--claude-backend",
    "claude_backend",
    default=None,
    type=click.Choice(["direct", "sdk"]),
    help="Claude backend: 'direct' (Anthropic API) or 'sdk' (CLI subprocess). Auto-detected from auth if not set.",
)
@click.pass_context
def start(ctx, project, verbose, debug, repo_root, claude_backend):
    """Start a new planning session."""
    ctx.obj["debug"] = debug
    conn = _get_conn(ctx)

    session_id = create_session(conn, project)

    # Resolve repo root: explicit flag takes precedence, then auto-detect.
    if repo_root is not None:
        resolved_repo_root = os.path.abspath(repo_root)
    else:
        resolved_repo_root = discover_repo_root()

    # Resolve Claude backend: explicit flag > auth-based auto-detect.
    if claude_backend is None:
        claude_backend = resolve_default_backend()
    else:
        # Warn if user forces direct with only OAuth
        if claude_backend == "direct" and not os.environ.get("ANTHROPIC_API_KEY") and os.environ.get("CLAUDE_CODE_OAUTH_TOKEN"):
            click.echo(
                "Warning: direct backend selected but only OAuth token found. "
                "Direct API requires ANTHROPIC_API_KEY.",
                err=True,
            )

    # Save initial config snapshot (includes repo_root for .kafra handoff)
    config = {
        "project": project,
        "model_default": "claude-sonnet-4-6",
        "repo_root": resolved_repo_root,
        "claude_backend": claude_backend,
    }
    save_session_config(conn, session_id, json.dumps(config))
    conn.commit()

    # Set up session logger (creates log file)
    setup_session_logging(session_id, verbose=verbose, debug=debug)
    logger.info("Command invoked: start, session_id=%s, project=%s, claude_backend=%s, verbose=%s, debug=%s",
                session_id, project, claude_backend, verbose, debug)

    click.echo(f"Session created: {session_id}")
    click.echo(f"Project: {project}")
    click.echo(f"Phase: SETUP")
    click.echo(f"Status: ACTIVE")
    click.echo(f"Claude backend: {claude_backend}")
    if resolved_repo_root:
        click.echo(f"Repo root: {resolved_repo_root}")


@cli.command("list")
@click.option("--status", "status_filter", default=None, help="Filter by status (ACTIVE, PAUSED, COMPLETE, FAILED).")
@click.pass_context
def list_sessions(ctx, status_filter):
    """List all sessions."""
    conn = _get_conn(ctx)

    if status_filter:
        rows = conn.execute(
            "SELECT id, project, phase, status, created_at FROM sessions WHERE status = ? ORDER BY created_at DESC",
            (status_filter.upper(),),
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT id, project, phase, status, created_at FROM sessions ORDER BY created_at DESC"
        ).fetchall()

    if not rows:
        click.echo("No sessions found.")
        return

    # Formatted table output
    click.echo(f"{'ID':<12} {'PROJECT':<20} {'PHASE':<14} {'STATUS':<10} {'CREATED'}")
    click.echo("-" * 78)
    for row in rows:
        click.echo(
            f"{row['id']:<12} {row['project']:<20} {row['phase']:<14} "
            f"{row['status']:<10} {row['created_at']}"
        )


@cli.command()
@click.argument("session_id")
@click.option("--verbose", is_flag=True, default=False, help="Verbose logging to stderr.")
@click.option("--debug", is_flag=True, default=False, help="Debug logging to stderr.")
@click.pass_context
def status(ctx, session_id, verbose, debug):
    """Show detailed session status."""
    ctx.obj["debug"] = debug
    conn = _get_conn(ctx)
    setup_session_logging(session_id, verbose=verbose, debug=debug)
    logger.info("status: session=%s", session_id)

    session = get_session(conn, session_id)
    if session is None:
        click.echo(f"Error: Session not found: {session_id}", err=True)
        ctx.exit(1)
        return

    messages = get_messages(conn, session_id)
    context_entries = get_context_entries(conn, session_id)
    drafts = get_all_plan_drafts(conn, session_id)
    blockers = get_open_blockers(conn, session_id)

    click.echo("=" * 60)
    click.echo("SESSION STATUS")
    click.echo("=" * 60)
    click.echo(f"Session ID:      {session['id']}")
    click.echo(f"Project:         {session['project']}")
    click.echo(f"Phase:           {session['phase']}")
    click.echo(f"Status:          {session['status']}")
    click.echo(f"Created:         {session['created_at']}")
    click.echo(f"Updated:         {session['updated_at']}")
    click.echo(f"Messages:        {len(messages)}")
    click.echo(f"Context entries: {len(context_entries)}")
    click.echo(f"Plan drafts:     {len(drafts)}")
    click.echo(f"Open blockers:   {len(blockers)}")

    if blockers:
        click.echo("")
        click.echo("OPEN BLOCKERS:")
        for b in blockers:
            click.echo(f"  [{b['id']}] ({b['source']}) {b['question']}")


@cli.command()
@click.argument("session_id")
@click.option("--verbose", is_flag=True, default=False, help="Verbose logging to stderr.")
@click.option("--debug", is_flag=True, default=False, help="Debug logging to stderr.")
@click.pass_context
def resume(ctx, session_id, verbose, debug):
    """Resume a paused or active session, resolving open blockers."""
    ctx.obj["debug"] = debug
    conn = _get_conn(ctx)
    setup_session_logging(session_id, verbose=verbose, debug=debug)
    logger.info("Command invoked: resume, session_id=%s, verbose=%s, debug=%s",
                session_id, verbose, debug)

    session = get_session(conn, session_id)
    if session is None:
        click.echo(f"Error: Session not found: {session_id}", err=True)
        ctx.exit(1)
        return

    current_status = session["status"]
    if current_status not in ("ACTIVE", "PAUSED"):
        click.echo(
            f"Error: Cannot resume session with status '{current_status}'. "
            f"Only ACTIVE or PAUSED sessions can be resumed.",
            err=True,
        )
        ctx.exit(1)
        return

    blockers = get_open_blockers(conn, session_id)
    if blockers:
        click.echo(f"Resolving {len(blockers)} open blocker(s):")
        for b in blockers:
            click.echo(f"\n  Blocker [{b['id']}] ({b['source']}): {b['question']}")
            answer = click.prompt("  Your answer")
            resolve_blocker(conn, b["id"], answer)
            conn.commit()
            click.echo("  Resolved.")

    # Set status back to ACTIVE
    if current_status == "PAUSED":
        update_session_status(conn, session_id, "ACTIVE")
        conn.commit()

    session = get_session(conn, session_id)
    click.echo(f"\nSession {session_id} resumed.")
    click.echo(f"Phase: {session['phase']}")
    click.echo(f"Status: {session['status']}")


@cli.command("add-context")
@click.argument("session_id")
@click.option("--file", "file_path", type=click.Path(), default=None, help="Path to a file to add as context.")
@click.option("--note", default=None, help="Text note to add as context.")
@click.option("--verbose", is_flag=True, default=False, help="Verbose logging to stderr.")
@click.option("--debug", is_flag=True, default=False, help="Debug logging to stderr.")
@click.pass_context
def add_context(ctx, session_id, file_path, note, verbose, debug):
    """Add a context entry (file or note) to a session."""
    ctx.obj["debug"] = debug
    conn = _get_conn(ctx)
    setup_session_logging(session_id, verbose=verbose, debug=debug)
    logger.info("add-context: session=%s, file=%s, note=%s", session_id, file_path, bool(note))

    session = get_session(conn, session_id)
    if session is None:
        click.echo(f"Error: Session not found: {session_id}", err=True)
        ctx.exit(1)
        return

    # Check command permission
    sm = SessionManager(conn)
    try:
        sm.check_command(session_id, "add-context")
    except CommandNotAllowedError as e:
        click.echo(f"Error: {e}", err=True)
        if ctx.obj.get("debug"):
            import traceback
            click.echo(traceback.format_exc(), err=True)
        ctx.exit(1)
        return

    if file_path is None and note is None:
        click.echo("Error: Provide either --file or --note.", err=True)
        ctx.exit(1)
        return

    if file_path is not None and note is not None:
        click.echo("Error: Provide either --file or --note, not both.", err=True)
        ctx.exit(1)
        return

    from planner_auto.context_service import ContextError, add_context_entry as svc_add_context

    if file_path is not None:
        try:
            result = svc_add_context(conn, session_id, "file", file_path, sm=sm)
            click.echo(f"Context added: file '{result['key']}' ({result['size']} chars)")
        except ContextError as e:
            click.echo(f"Error: {e}", err=True)
            ctx.exit(1)
            return
    else:
        try:
            result = svc_add_context(conn, session_id, "note", note, sm=sm)
            click.echo(f"Context added: note '{result['key']}'")
        except ContextError as e:
            click.echo(f"Error: {e}", err=True)
            ctx.exit(1)
            return

    # Report phase advancement if it happened
    session_after = get_session(conn, session_id)
    if session_after and session_after["phase"] != session["phase"]:
        click.echo(f"Phase advanced to {session_after['phase']}.")


    # Legacy helpers removed — context_service handles validation and storage.


@cli.command()
@click.argument("session_id")
@click.argument("message", required=False, default=None)
@click.option("--interactive", is_flag=True, default=False, help="Enter interactive discussion mode.")
@click.option("--done", is_flag=True, default=False, help="Advance to PLANNING after this message.")
@click.option("--verbose", is_flag=True, default=False, help="Verbose logging to stderr.")
@click.option("--debug", is_flag=True, default=False, help="Debug logging to stderr.")
@click.pass_context
def discuss(ctx, session_id, message, interactive, done, verbose, debug):
    """Send a discussion message or enter interactive mode."""
    from planner_auto.agents import discuss as discuss_fn

    ctx.obj["debug"] = debug
    conn = _get_conn(ctx)
    setup_session_logging(session_id, verbose=verbose, debug=debug)
    logger.info("Command invoked: discuss, session_id=%s, interactive=%s, done=%s, verbose=%s, debug=%s",
                session_id, interactive, done, verbose, debug)

    session = get_session(conn, session_id)
    if session is None:
        click.echo(f"Error: Session not found: {session_id}", err=True)
        ctx.exit(1)
        return

    sm = SessionManager(conn)

    # Advance to DISCUSSION if in CONTEXT
    if session["phase"] == Phase.CONTEXT.value:
        sm.advance_phase(session_id, Phase.DISCUSSION.value)
        click.echo("Phase advanced to DISCUSSION.")

    claude_backend = _resolve_session_backend(conn, session_id)

    if interactive:
        _discuss_interactive(ctx, conn, sm, session_id, claude_backend)
    elif message:
        success = _discuss_single(ctx, conn, session_id, message, discuss_fn, claude_backend)
        if done and success:
            try:
                sm.advance_phase(session_id, Phase.PLANNING.value)
                click.echo("Phase advanced to PLANNING.")
            except Exception as e:
                click.echo(f"Error advancing phase: {e}", err=True)
        elif done and not success:
            click.echo("Warning: --done ignored because the discussion call failed.", err=True)
    else:
        click.echo("Error: Provide a message or use --interactive.", err=True)
        ctx.exit(1)


def _discuss_single(ctx, conn, session_id, message, discuss_fn, claude_backend="direct"):
    """Send a single discussion message. Returns True on success, False on failure."""
    try:
        response = asyncio.run(discuss_fn(session_id, message, conn, backend=claude_backend))
        click.echo(f"\nAssistant: {response}")
        return True
    except SDKError as e:
        click.echo(f"Error: {e}", err=True)
        if ctx.obj.get("debug"):
            import traceback
            click.echo(traceback.format_exc(), err=True)
        return False
    except CommandNotAllowedError as e:
        click.echo(f"Error: {e}", err=True)
        if ctx.obj.get("debug"):
            import traceback
            click.echo(traceback.format_exc(), err=True)


def _discuss_interactive(ctx, conn, sm, session_id, claude_backend="direct"):
    """Enter interactive discussion mode with prompt_toolkit."""
    from planner_auto.agents import discuss as discuss_fn

    try:
        from prompt_toolkit import prompt as pt_prompt
    except ImportError:
        click.echo("Error: prompt_toolkit is required for interactive mode.", err=True)
        ctx.exit(1)
        return

    click.echo("Interactive discussion mode. Type '/done' to finish.\n")

    while True:
        try:
            user_input = pt_prompt("You: ")
        except (EOFError, KeyboardInterrupt):
            click.echo("\nExiting discussion.")
            break

        if user_input.strip() == "/done":
            # Advance to PLANNING
            try:
                sm.advance_phase(session_id, Phase.PLANNING.value)
                click.echo("Phase advanced to PLANNING.")
            except Exception as e:
                click.echo(f"Error advancing phase: {e}", err=True)
                if ctx.obj.get("debug"):
                    import traceback
                    click.echo(traceback.format_exc(), err=True)
            break

        if not user_input.strip():
            continue

        try:
            response = asyncio.run(discuss_fn(session_id, user_input, conn, backend=claude_backend))
            click.echo(f"\nAssistant: {response}\n")
        except SDKError as e:
            click.echo(f"SDK Error: {e}", err=True)
            click.echo("You can retry or type '/done' to exit.\n", err=True)
            if ctx.obj.get("debug"):
                import traceback
                click.echo(traceback.format_exc(), err=True)
        except CommandNotAllowedError as e:
            click.echo(f"Error: {e}", err=True)
            if ctx.obj.get("debug"):
                import traceback
                click.echo(traceback.format_exc(), err=True)


@cli.command()
@click.argument("session_id")
@click.option("--model", default="claude-sonnet-4-6", help="Model for plan generation.")
@click.option("--verbose", is_flag=True, default=False, help="Verbose logging to stderr.")
@click.option("--debug", is_flag=True, default=False, help="Debug logging to stderr.")
@click.pass_context
def generate(ctx, session_id, model, verbose, debug):
    """Generate an implementation plan."""
    from planner_auto.agents import generate_plan
    from planner_auto.validation import validate_plan_format

    ctx.obj["debug"] = debug
    conn = _get_conn(ctx)
    setup_session_logging(session_id, verbose=verbose, debug=debug)
    logger.info("Command invoked: generate, session_id=%s, model=%s, verbose=%s, debug=%s",
                session_id, model, verbose, debug)

    session = get_session(conn, session_id)
    if session is None:
        click.echo(f"Error: Session not found: {session_id}", err=True)
        ctx.exit(1)
        return

    sm = SessionManager(conn)
    try:
        sm.check_command(session_id, "generate")
    except CommandNotAllowedError as e:
        click.echo(f"Error: {e}", err=True)
        if ctx.obj.get("debug"):
            import traceback
            traceback.print_exc()
        ctx.exit(1)
        return

    claude_backend = _resolve_session_backend(conn, session_id)
    try:
        plan = asyncio.run(generate_plan(session_id, conn, model=model, backend=claude_backend))
        click.echo("\n" + plan)

        # Validate format and print warnings
        warnings = validate_plan_format(plan)
        if warnings:
            click.echo("\nPlan format warnings:")
            for w in warnings:
                click.echo(f"  - {w}")
        else:
            click.echo("\nPlan format validation: OK")

    except SDKError as e:
        click.echo(f"Error: {e}", err=True)
        click.echo("Hint: Check your API key and network connection.", err=True)
        if ctx.obj.get("debug"):
            import traceback
            click.echo(traceback.format_exc(), err=True)


@cli.command("export")
@click.argument("session_id")
@click.option("--output-dir", default=None, help="Override output directory.")
@click.option("--verbose", is_flag=True, default=False, help="Verbose logging to stderr.")
@click.option("--debug", is_flag=True, default=False, help="Debug logging to stderr.")
@click.pass_context
def export_cmd(ctx, session_id, output_dir, verbose, debug):
    """Export session artifacts to disk."""
    from planner_auto.export import export_session

    ctx.obj["debug"] = debug
    conn = _get_conn(ctx)
    setup_session_logging(session_id, verbose=verbose, debug=debug)
    logger.info("Command invoked: export, session_id=%s, output_dir=%s, verbose=%s, debug=%s",
                session_id, output_dir, verbose, debug)

    session = get_session(conn, session_id)
    if session is None:
        click.echo(f"Error: Session not found: {session_id}", err=True)
        ctx.exit(1)
        return

    paths = export_session(session_id, conn, output_dir=output_dir)
    click.echo(f"Exported {len(paths)} file(s):")
    for p in paths:
        click.echo(f"  {p}")


@cli.command()
@click.argument("session_id")
@click.option("--verbose", is_flag=True, default=False, help="Verbose logging to stderr.")
@click.option("--debug", is_flag=True, default=False, help="Debug logging to stderr.")
@click.pass_context
def complete(ctx, session_id, verbose, debug):
    """Complete a session — checks blockers, advances phase, auto-exports."""
    from planner_auto.export import export_session

    ctx.obj["debug"] = debug
    conn = _get_conn(ctx)
    setup_session_logging(session_id, verbose=verbose, debug=debug)
    logger.info("Command invoked: complete, session_id=%s, verbose=%s, debug=%s",
                session_id, verbose, debug)

    session = get_session(conn, session_id)
    if session is None:
        click.echo(f"Error: Session not found: {session_id}", err=True)
        ctx.exit(1)
        return

    # Check command is allowed in current phase/status (catches PAUSED)
    sm = SessionManager(conn)
    try:
        sm.check_command(session_id, "complete")
    except CommandNotAllowedError as e:
        click.echo(f"Error: {e}", err=True)
        if ctx.obj.get("debug"):
            import traceback
            traceback.print_exc()
        ctx.exit(1)
        return

    # Check for open blockers
    blockers = get_open_blockers(conn, session_id)
    if blockers:
        click.echo("Error: Cannot complete session with open blockers:", err=True)
        for b in blockers:
            click.echo(f"  [{b['id']}] ({b['source']}) {b['question']}", err=True)
        ctx.exit(1)
        return

    # Advance phase to COMPLETE
    try:
        sm.advance_phase(session_id, Phase.COMPLETE.value)
    except Exception as e:
        click.echo(f"Error advancing phase: {e}", err=True)
        if ctx.obj.get("debug"):
            import traceback
            click.echo(traceback.format_exc(), err=True)
        ctx.exit(1)
        return

    # Set status to COMPLETE
    update_session_status(conn, session_id, "COMPLETE")
    conn.commit()

    # Auto-export
    paths = export_session(session_id, conn)
    click.echo(f"Session {session_id} completed.")
    click.echo(f"Exported {len(paths)} file(s):")
    for p in paths:
        click.echo(f"  {p}")


@cli.command()
@click.argument("session_id", required=False, default=None)
@click.option("--project", default=None, help="Project name (creates new session).")
@click.option("--tui", is_flag=True, default=False, help="Launch the session TUI.")
@click.option(
    "--repo-root",
    default=None,
    help="Override repository root path.",
)
@click.option(
    "--claude-backend",
    "claude_backend",
    default=None,
    type=click.Choice(["direct", "sdk"]),
    help="Claude backend: 'direct' or 'sdk'.",
)
@click.option("--verbose", is_flag=True, default=False, help="Verbose logging to stderr.")
@click.option("--debug", is_flag=True, default=False, help="Debug logging to stderr.")
@click.pass_context
def session(ctx, session_id, project, tui, repo_root, claude_backend, verbose, debug):
    """Launch the session TUI for a new or existing session.

    Two invocation patterns:
      planner-auto session --project <name> --tui   (create new)
      planner-auto session <session-id> --tui        (resume existing)
    """
    ctx.obj["debug"] = debug

    if not tui:
        click.echo("Session TUI requires --tui flag.", err=True)
        ctx.exit(1)
        return

    # Validate invocation: need either --project or session_id
    if session_id is None and project is None:
        click.echo("Error: Provide either --project <name> (new) or <session-id> (resume).", err=True)
        ctx.exit(1)
        return

    if session_id is not None and project is not None:
        click.echo("Error: Provide either --project (new session) or session-id (resume), not both.", err=True)
        ctx.exit(1)
        return

    conn = _get_conn(ctx)

    if project is not None:
        # Create new session (same logic as `start` command)
        sid = create_session(conn, project)

        if repo_root is not None:
            resolved_repo_root = os.path.abspath(repo_root)
        else:
            resolved_repo_root = discover_repo_root()

        if claude_backend is None:
            claude_backend = resolve_default_backend()

        config = {
            "project": project,
            "model_default": "claude-sonnet-4-6",
            "repo_root": resolved_repo_root,
            "claude_backend": claude_backend,
        }
        save_session_config(conn, sid, json.dumps(config))
        conn.commit()
    else:
        # Resume existing session
        sid = session_id
        sess = get_session(conn, sid)
        if sess is None:
            click.echo(f"Error: Session not found: {sid}", err=True)
            ctx.exit(1)
            return

    # Set up session logging
    setup_session_logging(sid, verbose=verbose, debug=debug)
    logger.info("Command invoked: session, session_id=%s, project=%s, tui=%s", sid, project, tui)

    # Lazy import of session TUI
    try:
        from planner_auto.tui.session_app import SessionTUI
    except ImportError:
        click.echo(
            "Error: Textual is not installed. Install with: pip install 'textual>=0.40'",
            err=True,
        )
        ctx.exit(1)
        return

    # Resolve db_path for TUI
    db_path = ctx.obj.get("db_path")

    app = SessionTUI(session_id=sid, db_path=db_path)
    app.run()

    ctx.exit(app.exit_code)


@cli.command()
@click.argument("session_id")
@click.option("--fast", is_flag=True, default=False, help="Fast mode: 4 rounds, no history, basic prompt.")
@click.option("--max-rounds", default=None, type=int, help="Override maximum review rounds.")
@click.option("--no-review-history", is_flag=True, default=False, help="Disable review history context.")
@click.option("--reviewer-model", default="gpt-5.4", show_default=True, help="GPT model for review.")
@click.option("--reviewer-reasoning", default="high", show_default=True, help="Reasoning effort level.")
@click.option(
    "--complexity",
    "complexity_override",
    default=None,
    type=click.Choice(["standard", "complex"]),
    help="Override complexity detection.",
)
@click.option("--repo-root", default=None, help="Override repository root for .kafra handoff.")
@click.option("--verbose", is_flag=True, default=False, help="Verbose logging to stderr.")
@click.option("--debug", is_flag=True, default=False, help="Debug logging to stderr.")
@click.option("--tui", is_flag=True, default=False, help="Launch Textual TUI dashboard.")
@click.pass_context
def review(
    ctx,
    session_id,
    fast,
    max_rounds,
    no_review_history,
    reviewer_model,
    reviewer_reasoning,
    complexity_override,
    repo_root,
    verbose,
    debug,
    tui,
):
    """Run the GPT review loop for a planning session."""
    from planner_auto.review_workflow import FinalizeResult, PreparedReview, ReviewOpts, ReviewWorkflow

    ctx.obj["debug"] = debug
    conn = _get_conn(ctx)
    setup_session_logging(session_id, verbose=verbose, debug=debug)
    logger.info(
        "Command invoked: review, session_id=%s, fast=%s, reviewer_model=%s, verbose=%s, debug=%s, tui=%s",
        session_id, fast, reviewer_model, verbose, debug, tui,
    )

    # Resolve verbosity from CLI flags: debug > verbose > quiet.
    if debug:
        verbosity = "debug"
    elif verbose:
        verbosity = "verbose"
    else:
        verbosity = "quiet"

    claude_backend = _resolve_session_backend(conn, session_id)

    opts = ReviewOpts(
        fast=fast,
        max_rounds=max_rounds,
        no_review_history=no_review_history,
        reviewer_model=reviewer_model,
        reviewer_reasoning=reviewer_reasoning,
        complexity_override=complexity_override,
        repo_root=repo_root,
        verbosity=verbosity,
        debug=debug,
    )

    # Track phase before prepare to detect advancement.
    session_before = get_session(conn, session_id)
    phase_before = session_before["phase"] if session_before else None

    # --- Shared prepare phase ---
    try:
        prepared = ReviewWorkflow.prepare(conn, session_id, opts, claude_backend=claude_backend)
    except SessionNotFoundError:
        click.echo(f"Error: Session not found: {session_id}", err=True)
        ctx.exit(1)
        return
    except CommandNotAllowedError as e:
        click.echo(f"Error: {e}", err=True)
        if ctx.obj.get("debug"):
            import traceback
            traceback.print_exc()
        ctx.exit(1)
        return
    except ValueError as e:
        click.echo(f"Error: {e}", err=True)
        ctx.exit(1)
        return

    # Emit CLI status messages (prepare doesn't print).
    if phase_before == Phase.PLANNING.value:
        session_after = get_session(conn, session_id)
        if session_after and session_after["phase"] == Phase.REVIEW.value:
            click.echo("Phase advanced to REVIEW.")

    # --- TUI path ---
    if tui:
        try:
            from planner_auto.tui import get_review_app_class
        except ImportError:
            click.echo(
                "Error: Textual is not installed. Install with: pip install planner-auto[tui]",
                err=True,
            )
            ctx.exit(1)
            return

        # Resolve db_path for the TUI worker thread.
        db_path = prepared.db_path
        if not db_path:
            db_path = ctx.obj.get("db_path")

        prepared.engine_config["verbosity"] = "tui"

        ReviewTUI = get_review_app_class()
        app = ReviewTUI(prepared=prepared, session_id=session_id, db_path=db_path)
        app.run()

        # After TUI exits, handle finalize.
        if getattr(app, "loop_result", None) is not None:
            fin = ReviewWorkflow.finalize(conn, session_id, app.loop_result, prepared)
            if fin.converged:
                if verbosity != "quiet":
                    click.echo(f"Exported {len(fin.export_paths)} artifact(s).")
                    if fin.kafra_path:
                        click.echo(f".kafra handoff: {fin.kafra_path}")
                    click.echo(f"Session {session_id} completed.")
            else:
                click.echo(f"Session paused. Blocker: {(fin.blocker_text or '')[:120]}")
        elif getattr(app, "loop_error", None) is not None:
            click.echo(f"Error during review loop: {app.loop_error}", err=True)
            ctx.exit(1)
        # else: user quit before loop started — exit 0 silently
        return

    # --- CLI path ---
    engine = ReviewLoopEngine(
        conn=conn,
        session_id=session_id,
        reviewer=prepared.reviewer,
        planner_model=prepared.planner_model,
        config=prepared.engine_config,
    )

    if verbosity != "quiet":
        click.echo(
            f"Starting review loop (max_rounds={prepared.max_rounds}, "
            f"complexity={prepared.complexity}, fast={fast})..."
        )

    try:
        result = ReviewWorkflow.run(engine, prepared.current_plan, prepared.max_rounds)
    except Exception as exc:
        click.echo(f"Error during review loop: {exc}", err=True)
        if ctx.obj.get("debug"):
            import traceback
            click.echo(traceback.format_exc(), err=True)
        ctx.exit(1)
        return

    # Engine owns the final summary line via _emit_final(). No CLI duplicate.

    fin = ReviewWorkflow.finalize(conn, session_id, result, prepared)

    if fin.converged:
        if verbosity != "quiet":
            click.echo(f"Exported {len(fin.export_paths)} artifact(s).")
            if fin.kafra_path:
                click.echo(f".kafra handoff: {fin.kafra_path}")
            click.echo(f"Session {session_id} completed.")
    else:
        click.echo(f"Session paused. Blocker: {(fin.blocker_text or '')[:120]}")


# ---------------------------------------------------------------------------
# inspect subgroup
# ---------------------------------------------------------------------------

@cli.group()
def inspect():
    """Inspect session data stored in the database."""


@inspect.command("reviews")
@click.argument("session_id")
@click.pass_context
def inspect_reviews(ctx, session_id):
    """Show a table of all reviews for a session."""
    conn = _get_conn(ctx)
    click.echo(format_reviews_table(conn, session_id))


@inspect.command("dispositions")
@click.argument("session_id")
@click.option("--round", "round_num", type=int, default=None, help="Filter to a single round.")
@click.pass_context
def inspect_dispositions(ctx, session_id, round_num):
    """Show issue dispositions (ACCEPT/DEFER/REJECT) for a session."""
    conn = _get_conn(ctx)
    click.echo(format_dispositions(conn, session_id, round_num))


@inspect.command("config")
@click.argument("session_id")
@click.pass_context
def inspect_config(ctx, session_id):
    """Show the latest config snapshot for a session."""
    conn = _get_conn(ctx)
    click.echo(format_config(conn, session_id))


@inspect.command("history")
@click.argument("session_id")
@click.option("--round", "round_num", required=True, type=int, help="Review round number.")
@click.pass_context
def inspect_history(ctx, session_id, round_num):
    """Show review history context for a round (reconstructed from DB state, not stored)."""
    conn = _get_conn(ctx)
    click.echo(reconstruct_history(conn, session_id, round_num))


@inspect.command("raw-response")
@click.argument("session_id")
@click.option("--round", "round_num", required=True, type=int, help="Review round number.")
@click.pass_context
def inspect_raw_response(ctx, session_id, round_num):
    """Show the raw reviewer API response for a round.

    ⚠ Output may contain repository content and API responses.
    Do not share without redaction.
    """
    conn = _get_conn(ctx)
    click.echo(format_raw_response(conn, session_id, round_num))


@inspect.command("dump")
@click.argument("session_id")
@click.option("--output", "output_path", default=None, type=click.Path(), help="Save JSON to file instead of stdout.")
@click.pass_context
def inspect_dump(ctx, session_id, output_path):
    """Dump all session data as JSON.

    ⚠ Output may contain repository content and API responses.
    Do not share without redaction.
    """
    conn = _get_conn(ctx)
    click.echo(
        "⚠ Output may contain repository content and API responses. "
        "Do not share without redaction.",
        err=True,
    )
    json_output = dump_session_json(conn, session_id)
    if output_path:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(json_output)
        click.echo(f"Dump saved to: {output_path}", err=True)
    else:
        click.echo(json_output)


# ---------------------------------------------------------------------------
# check command
# ---------------------------------------------------------------------------

@cli.command("check")
@click.option("--probe", is_flag=True, default=False,
              help="Send trivial live API calls to verify connectivity and measure latency.")
@click.option(
    "--claude-backend",
    "probe_backend",
    default=None,
    type=click.Choice(["direct", "sdk"]),
    help="With --probe, test a specific backend instead of the default.",
)
@click.option("--session", "session_id", default=None,
              help="Validate the backend configured for a specific session.")
@click.pass_context
def check(ctx, probe, probe_backend, session_id):
    """Validate the planner-auto environment.

    Default (safe): checks env vars, CLI tools on PATH, importable packages,
    DB writability, and schema version -- no live API calls.

    With --probe: sends a trivial prompt to each API and reports latency.
    With --session: validates the backend configured for a specific session.
    """
    import importlib
    import time

    results: list[tuple[str, bool, str]] = []  # (label, passed, detail)

    # ---- Auth checks -------------------------------------------------------
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY", "")
    oauth_token = os.environ.get("CLAUDE_CODE_OAUTH_TOKEN", "")
    claude_auth_ok = bool(anthropic_key or oauth_token)
    if claude_auth_ok:
        src = "ANTHROPIC_API_KEY" if anthropic_key else "CLAUDE_CODE_OAUTH_TOKEN"
        results.append(("Claude auth", True, f"set via {src}"))
    else:
        results.append(("Claude auth", False,
                        "neither ANTHROPIC_API_KEY nor CLAUDE_CODE_OAUTH_TOKEN is set"))

    openai_key = os.environ.get("OPENAI_API_KEY", "")
    results.append((
        "OPENAI_API_KEY",
        bool(openai_key),
        "set" if openai_key else "not set",
    ))

    # ---- Default backend ---------------------------------------------------
    default_backend = resolve_default_backend()
    if anthropic_key:
        backend_reason = "ANTHROPIC_API_KEY"
    elif oauth_token:
        backend_reason = "OAuth requires CLI subprocess"
    else:
        backend_reason = "no credentials (will fail at call time)"
    results.append(("Default backend", True, f"{default_backend} (based on {backend_reason})"))

    # ---- Session backend (optional) ----------------------------------------
    effective_backend = default_backend  # used for PATH/import pass/fail decisions
    if session_id:
        conn = _get_conn(ctx)
        session = get_session(conn, session_id)
        if session is None:
            results.append(("Session backend", False, f"session {session_id} not found"))
        else:
            session_backend = _resolve_session_backend(conn, session_id)
            results.append(("Session backend", True, f"{session_backend} (session {session_id})"))
            effective_backend = session_backend  # validate against session's backend

    # ---- PATH checks -------------------------------------------------------
    claude_path = shutil.which("claude")
    # claude on PATH is only required if effective backend is sdk
    claude_required = effective_backend == "sdk"
    if claude_required:
        results.append((
            "claude on PATH",
            claude_path is not None,
            claude_path or "not found (required for sdk backend)",
        ))
    else:
        results.append((
            "claude on PATH",
            True,  # informational only when direct is default
            claude_path or "not found (optional, sdk backend only)",
        ))

    # ---- Import checks -----------------------------------------------------
    openai_importable = importlib.util.find_spec("openai") is not None
    results.append((
        "openai importable",
        openai_importable,
        "yes" if openai_importable else "not installed (pip install openai)",
    ))

    # anthropic package check
    try:
        import anthropic as _anth
        _anth_ver = getattr(_anth, "__version__", "unknown")
        anthropic_importable = True
        # Fail only if direct is the default backend
        results.append(("anthropic importable", True, f"v{_anth_ver}"))
    except ImportError:
        anthropic_importable = False
        is_required = effective_backend == "direct"
        results.append((
            "anthropic importable",
            not is_required,  # fail if direct is effective backend, info-only otherwise
            "not installed (required for direct backend)" if is_required
            else "not installed (optional, direct backend only)",
        ))

    try:
        import claude_agent_sdk as _cas
        _cas_ver = getattr(_cas, "__version__", "unknown")
        results.append(("claude_agent_sdk importable", True, f"v{_cas_ver}"))
    except ImportError:
        is_required = effective_backend == "sdk"
        results.append((
            "claude_agent_sdk importable",
            not is_required,
            "not installed (required for sdk backend)" if is_required
            else "not installed (optional, sdk backend only)",
        ))

    # ---- DB path writable --------------------------------------------------
    db_path = ctx.obj.get("db_path") or DEFAULT_DB_PATH
    db_dir = os.path.dirname(db_path)
    db_ver = None
    try:
        os.makedirs(db_dir, exist_ok=True)
        test_conn = open_db(db_path)
        # Verify write access with a probe table
        test_conn.execute("CREATE TABLE IF NOT EXISTS _probe_test (id INTEGER)")
        test_conn.execute("DROP TABLE _probe_test")
        results.append(("DB path writable", True, db_path))
        try:
            db_ver = get_schema_version(test_conn)
        except Exception:
            # Fresh/empty DB with no schema tables yet — that's fine
            db_ver = "uninitialized"
        test_conn.close()
    except Exception as exc:
        results.append(("DB path writable", False, f"{exc}"))

    # ---- Schema version ----------------------------------------------------
    if db_ver == "uninitialized":
        results.append(("Schema version", True, "uninitialized (will be created on first use)"))
    elif db_ver is not None:
        schema_current = db_ver == CURRENT_SCHEMA_VERSION
        results.append((
            "Schema version",
            schema_current,
            f"v{db_ver}" + ("" if schema_current else f" (expected v{CURRENT_SCHEMA_VERSION})"),
        ))
    else:
        results.append(("Schema version", False, "could not read (DB not writable)"))

    # ---- Live probe (optional) ---------------------------------------------
    if probe:
        probe_target = probe_backend or default_backend
        # Claude probe via the specified backend
        try:
            import asyncio as _asyncio
            from planner_auto.sdk_wrapper import query_claude
            _t0 = time.monotonic()

            async def _probe_claude():
                return await query_claude(
                    messages=[{"role": "user", "content": "Say OK"}],
                    system_prompt="Respond with OK.",
                    model="claude-haiku-4-5-20251001",
                    timeout_sec=15,
                    backend=probe_target,
                )

            _asyncio.run(_probe_claude())
            _ms = int((time.monotonic() - _t0) * 1000)
            results.append((f"Claude API probe ({probe_target})", True, f"{_ms}ms"))
        except Exception as exc:
            results.append((f"Claude API probe ({probe_target})", False, str(exc)[:80]))

        # OpenAI probe
        if openai_importable and openai_key:
            try:
                import openai as _openai
                _t0 = time.monotonic()
                _client = _openai.OpenAI(api_key=openai_key)
                _client.chat.completions.create(
                    model="gpt-4o-mini",
                    messages=[{"role": "user", "content": "Say OK"}],
                    max_tokens=5,
                )
                _ms = int((time.monotonic() - _t0) * 1000)
                results.append(("OpenAI API probe", True, f"{_ms}ms"))
            except Exception as exc:
                results.append(("OpenAI API probe", False, str(exc)[:80]))
        elif probe:
            results.append(("OpenAI API probe", False,
                            "skipped (openai not installed or OPENAI_API_KEY not set)"))

    # ---- Print results -----------------------------------------------------
    all_passed = all(ok for _, ok, _ in results)
    click.echo("planner-auto environment check")
    click.echo("=" * 50)
    for label, ok, detail in results:
        icon = "✓" if ok else "✗"
        click.echo(f"  {icon}  {label:<28} {detail}")
    click.echo("=" * 50)
    if all_passed:
        click.echo("All checks passed.")
    else:
        failed = [label for label, ok, _ in results if not ok]
        click.echo(f"{len(failed)} check(s) failed: {', '.join(failed)}")
        ctx.exit(1)
