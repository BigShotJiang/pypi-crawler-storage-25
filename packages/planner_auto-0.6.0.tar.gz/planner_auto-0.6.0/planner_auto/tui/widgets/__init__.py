"""TUI widget package."""
