def fuzzy_operations(A, B):
    union = {}
    intersection = {}
    complement_A = {}
    difference = {}

    for key in A:
        union[key] = max(A[key], B[key])
        intersection[key] = min(A[key], B[key])
        complement_A[key] = 1 - A[key]
        difference[key] = min(A[key], 1 - B[key])

    return {
        "union": union,
        "intersection": intersection,
        "complement_A": complement_A,
        "difference": difference
    }