# MyPackage

A Python package containing multiple utility scripts.

## Installation

```bash
pip install mypackage