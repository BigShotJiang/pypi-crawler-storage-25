import heapq

def a_star(grid, start, goal):
    
    # Heuristic (Manhattan distance)
    def h(pos):
        return abs(pos[0] - goal[0]) + abs(pos[1] - goal[1])

    pq = []
    heapq.heappush(pq, (h(start), 0, start))  # (f, g, position)

    visited = set()
    parent = {start: None}

    while pq:
        f, g, current = heapq.heappop(pq)

        # Goal check
        if current == goal:
            path = []
            while current:
                path.append(current)
                current = parent[current]
            print("Path:", path[::-1])
            print("Cost:", g)
            return

        if current in visited:
            continue
        visited.add(current)

        x, y = current

        # Possible moves
        for dx, dy in [(0,1), (1,0), (0,-1), (-1,0)]:
            nx, ny = x + dx, y + dy

            # Check valid move
            if 0 <= nx < len(grid) and 0 <= ny < len(grid[0]) and grid[nx][ny] == 0:
                if (nx, ny) not in visited:
                    new_g = g + 1
                    new_f = new_g + h((nx, ny))

                    parent[(nx, ny)] = current
                    heapq.heappush(pq, (new_f, new_g, (nx, ny)))

    print("No path found")


# Example grid
grid = [
    [0, 0, 1, 0],
    [0, 0, 1, 0],
    [0, 0, 0, 0],
    [0, 1, 1, 0]
]

start = (0, 0)
goal = (3, 3)

print("A* Robot Navigation:")
a_star(grid, start, goal)