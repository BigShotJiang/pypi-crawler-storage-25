import math

def print_board(board):
    for row in board:
        print(" | ".join(row))
    print("-" * 9)


def check_winner(board):
    # Rows
    for row in board:
        if row[0] == row[1] == row[2] and row[0] != " ":
            return row[0]

    # Columns
    for col in range(3):
        if board[0][col] == board[1][col] == board[2][col] and board[0][col] != " ":
            return board[0][col]

    # Diagonals
    if board[0][0] == board[1][1] == board[2][2] and board[0][0] != " ":
        return board[0][0]

    if board[0][2] == board[1][1] == board[2][0] and board[0][2] != " ":
        return board[0][2]

    return None


def is_full(board):
    return all(cell != " " for row in board for cell in row)


def minimax(board, is_maximizing):
    winner = check_winner(board)

    if winner == 'X':
        return 1
    if winner == 'O':
        return -1
    if is_full(board):
        return 0

    if is_maximizing:
        best = -math.inf
        for i in range(3):
            for j in range(3):
                if board[i][j] == " ":
                    board[i][j] = 'X'
                    score = minimax(board, False)
                    board[i][j] = " "
                    best = max(best, score)
        return best
    else:
        best = math.inf
        for i in range(3):
            for j in range(3):
                if board[i][j] == " ":
                    board[i][j] = 'O'
                    score = minimax(board, True)
                    board[i][j] = " "
                    best = min(best, score)
        return best


def best_move(board):
    best_score = -math.inf
    move = None

    for i in range(3):
        for j in range(3):
            if board[i][j] == " ":
                board[i][j] = 'X'
                score = minimax(board, False)
                board[i][j] = " "

                if score > best_score:
                    best_score = score
                    move = (i, j)

    return move


# Example board
board = [
    ['O', 'X', ' '],
    [' ', 'X', ' '],
    [' ', ' ', 'O']
]

print("Current Board:")
print_board(board)

move = best_move(board)
print("Best move for X:", move)