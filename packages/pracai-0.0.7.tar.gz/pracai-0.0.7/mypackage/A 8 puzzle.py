import heapq
import copy

goal = [[1,2,3],
        [4,5,6],
        [7,8,0]]

# Heuristic: Manhattan Distance
def heuristic(state):
    h = 0
    for i in range(3):
        for j in range(3):
            val = state[i][j]
            if val != 0:
                goal_x = (val - 1) // 3
                goal_y = (val - 1) % 3
                h += abs(i - goal_x) + abs(j - goal_y)
    return h

# Get neighbors
def get_neighbors(state):
    neighbors = []

    for i in range(3):
        for j in range(3):
            if state[i][j] == 0:
                x, y = i, j

    moves = [(0,1), (1,0), (0,-1), (-1,0)]

    for dx, dy in moves:
        nx, ny = x + dx, y + dy
        if 0 <= nx < 3 and 0 <= ny < 3:
            new_state = copy.deepcopy(state)
            new_state[x][y], new_state[nx][ny] = new_state[nx][ny], new_state[x][y]
            neighbors.append(new_state)

    return neighbors


def a_star(initial):
    pq = []
    heapq.heappush(pq, (heuristic(initial), 0, initial))  # (f, g, state)

    visited = set()

    while pq:
        f, g, current = heapq.heappop(pq)

        print("\nCurrent State:")
        for row in current:
            print(row)

        if current == goal:
            print("\nGoal Reached!")
            return

        visited.add(str(current))

        for neighbor in get_neighbors(current):
            if str(neighbor) not in visited:
                new_g = g + 1
                new_f = new_g + heuristic(neighbor)
                heapq.heappush(pq, (new_f, new_g, neighbor))


# Initial state
initial = [[1,2,3],
           [4,5,6],
           [0,7,8]]

print("A* Algorithm for 8 Puzzle:")
a_star(initial)