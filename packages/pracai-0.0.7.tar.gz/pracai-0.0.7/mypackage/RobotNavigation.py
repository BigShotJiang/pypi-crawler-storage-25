import heapq

def best_first_search(grid, start, goal):
    
    # Heuristic function (Manhattan Distance)
    def h(pos):
        return abs(pos[0] - goal[0]) + abs(pos[1] - goal[1])

    pq = [(h(start), start)]
    visited = set([start])
    parent = {start: None}

    while pq:
        _, current = heapq.heappop(pq)

        # Goal check
        if current == goal:
            path = []
            while current:
                path.append(current)
                current = parent[current]
            print("Path:", path[::-1])
            return

        x, y = current

        # Possible moves: right, down, left, up
        for dx, dy in [(0,1), (1,0), (0,-1), (-1,0)]:
            nx, ny = x + dx, y + dy

            # Check valid move
            if 0 <= nx < len(grid) and 0 <= ny < len(grid[0]) and grid[nx][ny] == 0:
                if (nx, ny) not in visited:
                    visited.add((nx, ny))
                    parent[(nx, ny)] = current
                    heapq.heappush(pq, (h((nx, ny)), (nx, ny)))

    print("No path found")


# Example grid
grid = [
    [0, 0, 1, 0],
    [0, 0, 1, 0],
    [0, 0, 0, 0],
    [0, 1, 1, 0]
]

start = (0, 0)
goal = (3, 3)

print("Robot Navigation using Best First Search:")
best_first_search(grid, start, goal)