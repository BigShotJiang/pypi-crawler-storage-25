def is_safe(graph, color, node, c):
    for i in range(len(graph)):
        if graph[node][i] == 1 and color[i] == c:
            return False
    return True


def solve(graph, m, color, node):
    # If all nodes colored
    if node == len(graph):
        return True

    for c in range(1, m + 1):
        if is_safe(graph, color, node, c):
            color[node] = c

            if solve(graph, m, color, node + 1):
                return True

            color[node] = 0  # backtrack

    return False


def map_coloring():
    # Adjacency matrix
    graph = [
        [0, 1, 1, 1],
        [1, 0, 1, 0],
        [1, 1, 0, 1],
        [1, 0, 1, 0]
    ]

    m = 3  # number of colors
    color = [0] * len(graph)

    if solve(graph, m, color, 0):
        print("Color assignment:")
        for i in range(len(color)):
            print(f"Region {i} -> Color {color[i]}")
    else:
        print("No solution exists")


# Run
map_coloring()