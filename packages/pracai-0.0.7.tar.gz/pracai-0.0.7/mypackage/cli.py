import os
import importlib

def main():
    path = os.path.dirname(__file__)

    files = sorted([
        f[:-3]
        for f in os.listdir(path)
        if f.endswith(".py")
        and f not in ["__init__.py", "cli.py"]
    ])

    print("\nAvailable modules:\n")

    for i, file in enumerate(files, 1):
        print(f"{i}. {file}")

    choice = int(input("\nEnter module number: "))
    selected = files[choice - 1]

    print("\n1. Run module")
    print("2. View source code")

    action = input("\nChoose option: ")

    if action == "1":
        print(f"\nLoading {selected}...\n")
        importlib.import_module(f"mypackage.{selected}")

    elif action == "2":
        filepath = os.path.join(path, selected + ".py")

        with open(filepath, "r", encoding="utf-8") as f:
            print("\n")
            print(f.read())

    else:
        print("Invalid option")

if __name__ == "__main__":
    main()
