import heapq

# Graph (city connections with distances)
graph = {
    'A': [('B', 1), ('C', 4)],
    'B': [('A', 1), ('D', 2), ('E', 5)],
    'C': [('A', 4), ('F', 3)],
    'D': [('B', 2), ('G', 1)],
    'E': [('B', 5), ('G', 2)],
    'F': [('C', 3), ('G', 6)],
    'G': []
}

# Heuristic values (estimated distance to goal G)
heuristic = {
    'A': 6, 'B': 5, 'C': 4,
    'D': 3, 'E': 2, 'F': 5, 'G': 0
}

def best_first_search(start, goal):
    pq = [(heuristic[start], start)]  # (h, city)
    visited = set()
    parent = {start: None}

    while pq:
        _, current = heapq.heappop(pq)

        # Goal check
        if current == goal:
            path = []
            while current:
                path.append(current)
                current = parent[current]
            print("Path:", " -> ".join(path[::-1]))
            return

        visited.add(current)

        for neighbor, _ in graph[current]:
            if neighbor not in visited:
                parent[neighbor] = current
                heapq.heappush(pq, (heuristic[neighbor], neighbor))

    print("No path found")


# Run
print("Best First Search (Cities Distance):")
best_first_search('A', 'G')