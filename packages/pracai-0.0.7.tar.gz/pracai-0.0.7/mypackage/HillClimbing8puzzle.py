import copy

# Heuristic: count misplaced tiles
def heuristic(state, goal):
    h = 0
    for i in range(3):
        for j in range(3):
            if state[i][j] != 0 and state[i][j] != goal[i][j]:
                h += 1
    return h


# Get neighbors by moving blank (0)
def get_neighbors(state):
    neighbors = []
    
    # Find position of 0
    for i in range(3):
        for j in range(3):
            if state[i][j] == 0:
                x, y = i, j

    # Possible moves
    moves = [(0,1), (1,0), (0,-1), (-1,0)]

    for dx, dy in moves:
        nx, ny = x + dx, y + dy
        
        if 0 <= nx < 3 and 0 <= ny < 3:
            new_state = copy.deepcopy(state)
            new_state[x][y], new_state[nx][ny] = new_state[nx][ny], new_state[x][y]
            neighbors.append(new_state)

    return neighbors


def hill_climbing(initial, goal):
    current = initial

    while True:
        print("\nCurrent State:")
        for row in current:
            print(row)

        # Check goal
        if current == goal:
            print("\nGoal Reached!")
            return

        neighbors = get_neighbors(current)

        # Choose best neighbor
        next_state = min(neighbors, key=lambda x: heuristic(x, goal))

        # If no improvement → stop
        if heuristic(next_state, goal) >= heuristic(current, goal):
            print("\nReached Local Optimum (stuck)")
            return

        current = next_state


# Initial and Goal
initial = [[1,2,3],
           [4,5,6],
           [0,7,8]]

goal = [[1,2,3],
        [4,5,6],
        [7,8,0]]

print("Hill Climbing for 8 Puzzle:")
hill_climbing(initial, goal)