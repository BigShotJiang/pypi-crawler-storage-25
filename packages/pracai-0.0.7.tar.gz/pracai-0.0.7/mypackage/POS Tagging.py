import nltk

def pos_tagging():
    text = input("Enter a sentence: ")

    # Tokenize words
    words = nltk.word_tokenize(text)

    # POS tagging
    tags = nltk.pos_tag(words)

    print("\nPOS Tags:")
    for word, tag in tags:
        print(word, "->", tag)


# Download required data (only first time)
nltk.download('punkt')
nltk.download('punkt_tab')
nltk.download('averaged_perceptron_tagger')
nltk.download('averaged_perceptron_tagger_eng')

# Run
pos_tagging()