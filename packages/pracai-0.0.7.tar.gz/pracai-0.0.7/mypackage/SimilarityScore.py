from collections import Counter
import math

def cosine_similarity(text1, text2):
    # Convert to word frequency
    vec1 = Counter(text1.lower().split())
    vec2 = Counter(text2.lower().split())

    # Common words
    intersection = set(vec1.keys()) & set(vec2.keys())

    # Numerator
    numerator = sum(vec1[x] * vec2[x] for x in intersection)

    # Denominator
    sum1 = sum(v**2 for v in vec1.values())
    sum2 = sum(v**2 for v in vec2.values())

    denominator = math.sqrt(sum1) * math.sqrt(sum2)

    if denominator == 0:
        return 0.0

    return numerator / denominator


# Input
t1 = input("Enter first sentence: ")
t2 = input("Enter second sentence: ")

score = cosine_similarity(t1, t2)

print("\nSimilarity Score:", round(score, 4))