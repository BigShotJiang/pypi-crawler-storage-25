import heapq

# Graph with distances
graph = {
    'A': [('B', 1), ('C', 4)],
    'B': [('A', 1), ('D', 2), ('E', 5)],
    'C': [('A', 4), ('F', 3)],
    'D': [('B', 2), ('G', 1)],
    'E': [('B', 5), ('G', 2)],
    'F': [('C', 3), ('G', 6)],
    'G': []
}

# Heuristic values (estimated distance to goal G)
heuristic = {
    'A': 6, 'B': 5, 'C': 4,
    'D': 3, 'E': 2, 'F': 5, 'G': 0
}

def a_star(start, goal):
    pq = []
    heapq.heappush(pq, (heuristic[start], 0, start))  # (f, g, node)

    visited = set()
    parent = {start: None}

    while pq:
        f, g, current = heapq.heappop(pq)

        if current in visited:
            continue
        visited.add(current)

        # Goal check
        if current == goal:
            path = []
            while current:
                path.append(current)
                current = parent[current]

            print("Shortest Path:", " -> ".join(path[::-1]))
            print("Total Cost:", g)
            return

        # Explore neighbors
        for neighbor, cost in graph[current]:
            if neighbor not in visited:
                parent[neighbor] = current
                new_g = g + cost
                new_f = new_g + heuristic[neighbor]
                heapq.heappush(pq, (new_f, new_g, neighbor))

    print("No path found")


# Run
print("A* for Cities Distance:")
a_star('A', 'G')