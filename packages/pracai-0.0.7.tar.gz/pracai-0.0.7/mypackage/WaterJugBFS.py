from collections import deque

def water_jug_bfs(cap1, cap2, target):
    visited = set()
    queue = deque([((0, 0), [])])  # (state, path)

    while queue:
        (jug1, jug2), path = queue.popleft()

        # If already visited, skip
        if (jug1, jug2) in visited:
            continue

        visited.add((jug1, jug2))
        path = path + [(jug1, jug2)]

        # Goal condition
        if jug1 == target or jug2 == target:
            print("Solution Path:")
            for state in path:
                print(state)
            return

        # All possible operations
        next_states = [
            (cap1, jug2),  # Fill jug1
            (jug1, cap2),  # Fill jug2
            (0, jug2),     # Empty jug1
            (jug1, 0),     # Empty jug2
            # Pour jug1 -> jug2
            (jug1 - min(jug1, cap2 - jug2), jug2 + min(jug1, cap2 - jug2)),
            # Pour jug2 -> jug1
            (jug1 + min(jug2, cap1 - jug1), jug2 - min(jug2, cap1 - jug1))
        ]

        # Add new states to queue
        for state in next_states:
            if state not in visited:
                queue.append((state, path))

    print("No solution found")


# Example
water_jug_bfs(3, 5, 4)