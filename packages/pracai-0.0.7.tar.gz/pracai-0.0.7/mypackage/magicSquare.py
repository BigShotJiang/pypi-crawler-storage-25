# Magic Square (Odd Order) - Non AI

def generate_magic_square(n):
    magic = [[0]*n for _ in range(n)]

    i = 0
    j = n // 2   # middle column

    for num in range(1, n*n + 1):
        magic[i][j] = num

        new_i = (i - 1) % n
        new_j = (j + 1) % n

        if magic[new_i][new_j]:
            i = (i + 1) % n
        else:
            i = new_i
            j = new_j

    return magic

def print_square(square):
    for row in square:
        print(" ".join(str(x) for x in row))

def main():
    n = int(input("Enter odd number (n): "))

    if n % 2 == 0:
        print("Magic square only works for odd n")
        return

    square = generate_magic_square(n)

    print("\nMagic Square:")
    print_square(square)

main()