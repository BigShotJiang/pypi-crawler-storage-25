# Tic Tac Toe - Non AI (Simple Version)

board = [" " for _ in range(9)]

def print_board():
    print()
    print(board[0], "|", board[1], "|", board[2])
    print("--+---+--")
    print(board[3], "|", board[4], "|", board[5])
    print("--+---+--")
    print(board[6], "|", board[7], "|", board[8])
    print()

def check_winner(player):
    win_positions = [
        [0,1,2], [3,4,5], [6,7,8],   # rows
        [0,3,6], [1,4,7], [2,5,8],   # columns
        [0,4,8], [2,4,6]             # diagonals
    ]
    
    for pos in win_positions:
        if board[pos[0]] == player and \
           board[pos[1]] == player and \
           board[pos[2]] == player:
            return True
    return False

def play_game():
    player = "X"
    
    for turn in range(9):
        print_board()
        move = int(input(f"Player {player}, enter position (0-8): "))

        if move < 0 or move > 8:
            print("Invalid input! Try again.")
            continue

        if board[move] != " ":
            print("Position already taken!")
            continue

        board[move] = player

        if check_winner(player):
            print_board()
            print(f"Player {player} wins!")
            return

        # switch player
        if player == "X":
            player = "O"
        else:
            player = "X"

    print_board()
    print("Match Draw!")

play_game()