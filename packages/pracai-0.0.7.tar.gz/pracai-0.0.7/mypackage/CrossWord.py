def print_grid(grid):
    for row in grid:
        print("".join(row))
    print()


def can_place_h(grid, word, row, col):
    if col + len(word) > len(grid[0]):
        return False
    for i in range(len(word)):
        if grid[row][col + i] != '-' and grid[row][col + i] != word[i]:
            return False
    return True


def can_place_v(grid, word, row, col):
    if row + len(word) > len(grid):
        return False
    for i in range(len(word)):
        if grid[row + i][col] != '-' and grid[row + i][col] != word[i]:
            return False
    return True


def place_h(grid, word, row, col):
    temp = []
    for i in range(len(word)):
        temp.append(grid[row][col + i])
        grid[row][col + i] = word[i]
    return temp


def place_v(grid, word, row, col):
    temp = []
    for i in range(len(word)):
        temp.append(grid[row + i][col])
        grid[row + i][col] = word[i]
    return temp


def unplace_h(grid, temp, row, col):
    for i in range(len(temp)):
        grid[row][col + i] = temp[i]


def unplace_v(grid, temp, row, col):
    for i in range(len(temp)):
        grid[row + i][col] = temp[i]


def solve_crossword(grid, words):
    if not words:
        return True

    word = words[0]

    for i in range(len(grid)):
        for j in range(len(grid[0])):

            # Horizontal
            if can_place_h(grid, word, i, j):
                temp = place_h(grid, word, i, j)
                if solve_crossword(grid, words[1:]):
                    return True
                unplace_h(grid, temp, i, j)

            # Vertical
            if can_place_v(grid, word, i, j):
                temp = place_v(grid, word, i, j)
                if solve_crossword(grid, words[1:]):
                    return True
                unplace_v(grid, temp, i, j)

    return False


# Grid
grid = [
    ['+', '-', '+', '+', '+'],
    ['+', '-', '-', '-', '+'],
    ['+', '-', '+', '+', '+'],
    ['+', '+', '+', '+', '+']
]

words = ["HI", "IT"]

print("Solving Crossword...\n")

if solve_crossword(grid, words):
    print_grid(grid)
else:
    print("No solution found")