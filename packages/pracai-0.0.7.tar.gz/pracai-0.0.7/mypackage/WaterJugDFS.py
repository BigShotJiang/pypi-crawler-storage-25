# Water Jug Problem using DFS

def dfs(jug1, jug2, visited, path, cap1, cap2, target):
    
    # If already visited, stop
    if (jug1, jug2) in visited:
        return False

    visited.add((jug1, jug2))
    path.append((jug1, jug2))

    # Goal condition
    if jug1 == target or jug2 == target:
        return True

    # All possible operations

    # Fill jug1
    if dfs(cap1, jug2, visited, path, cap1, cap2, target):
        return True

    # Fill jug2
    if dfs(jug1, cap2, visited, path, cap1, cap2, target):
        return True

    # Empty jug1
    if dfs(0, jug2, visited, path, cap1, cap2, target):
        return True

    # Empty jug2
    if dfs(jug1, 0, visited, path, cap1, cap2, target):
        return True

    # Pour jug1 → jug2
    pour = min(jug1, cap2 - jug2)
    if dfs(jug1 - pour, jug2 + pour, visited, path, cap1, cap2, target):
        return True

    # Pour jug2 → jug1
    pour = min(jug2, cap1 - jug1)
    if dfs(jug1 + pour, jug2 - pour, visited, path, cap1, cap2, target):
        return True

    path.pop()  # backtrack
    return False


def water_jug_dfs(cap1, cap2, target):
    visited = set()
    path = []

    if dfs(0, 0, visited, path, cap1, cap2, target):
        print("Solution Path:")
        for state in path:
            print(state)
    else:
        print("No solution")


# Example
water_jug_dfs(3, 5, 4)