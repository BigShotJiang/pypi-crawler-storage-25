import itertools

def solve_cryptarithmetic():
    letters = "SENDMORY"
    
    print("Solving SEND + MORE = MONEY...\n")

    # Try all permutations of digits
    for perm in itertools.permutations(range(10), len(letters)):
        s, e, n, d, m, o, r, y = perm

        # Leading digit cannot be 0
        if s == 0 or m == 0:
            continue

        # Form numbers
        send  = s*1000 + e*100 + n*10 + d
        more  = m*1000 + o*100 + r*10 + e
        money = m*10000 + o*1000 + n*100 + e*10 + y

        # Check condition
        if send + more == money:
            print("Solution Found!\n")
            print(" SEND =", send)
            print(" MORE =", more)
            print("MONEY =", money)
            print("\nMapping:")
            print(dict(zip(letters, perm)))
            return

    print("No solution found")

# Run
solve_cryptarithmetic()