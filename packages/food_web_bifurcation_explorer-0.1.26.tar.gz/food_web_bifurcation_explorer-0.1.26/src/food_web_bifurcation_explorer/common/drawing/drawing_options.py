from food_web_bifurcation_explorer.common.drawing.drawing_bifurcation_options import DrawingBifurcationOptions
from food_web_bifurcation_explorer.common.drawing.drawing_eigenvalue_spectrum_options import DrawingEigenvalueSpectrumOptions
from food_web_bifurcation_explorer.common.drawing.drawing_scatter_options import DrawingScatterOptions
from food_web_bifurcation_explorer.enums.types.bifurcation_diagram_types import BifurcationDiagramTypes
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.types.hopf_parameter_types import HopfParameterTypes


class DrawingOptions:
    def __init__(self) -> None:
        # scatter options
        self.scatter_ternary_bifurcation: DrawingBifurcationOptions = DrawingBifurcationOptions(True, True)
        self.scatter_ternary_options: DrawingScatterOptions = DrawingScatterOptions()

        # bifurcation diagrams options
        self.bifurcation_diagrams_bifurcations: dict[BifurcationDiagramTypes, DrawingBifurcationOptions] = {}
        self.bifurcation_diagrams_options: dict[BifurcationDiagramTypes, DrawingScatterOptions] = {}
        for bifurcation_diagram in BifurcationDiagramTypes:
            self.bifurcation_diagrams_bifurcations[bifurcation_diagram] = DrawingBifurcationOptions(True, True)
            self.bifurcation_diagrams_options[bifurcation_diagram] = DrawingScatterOptions()

        # eigenvalues spectrum options
        self.eigenvalue_spectrum: dict[BranchTypes, DrawingEigenvalueSpectrumOptions] = {}
        for branch_type in BranchTypes:
            self.eigenvalue_spectrum[branch_type] = DrawingEigenvalueSpectrumOptions()

        # specific redrawing hopf bifurcations plots
        self.redraw_hopf_bifurcation: dict[HopfParameterTypes, bool] = {}
        for hopf_parameter_type in HopfParameterTypes:
            self.redraw_hopf_bifurcation[hopf_parameter_type] = True

        # heatmap options
        self.bifurcation_heatmap_ternary: DrawingBifurcationOptions = DrawingBifurcationOptions(True, False)

        # distribution options
        self.bifurcation_distribution = DrawingBifurcationOptions(True, False)

    def redraw_all_scatter_graphs(self) -> None:

        # redraw scater
        self.scatter_ternary_bifurcation.redraw_all()
        self.scatter_ternary_options.redraw_all()

        # redraw bifurcation diagrams
        for bifurcation_diagram in BifurcationDiagramTypes:
            self.redraw_bifurcation_diagram_graphs(bifurcation_diagram)

        # redraw hopf bifurcations
        self.redraw_hopf_bifurcations_graphs()

    def redraw_bifurcation_diagram_graphs(self, bifurcation_diagram: BifurcationDiagramTypes) -> None:
        self.bifurcation_diagrams_bifurcations[bifurcation_diagram].redraw_all()
        self.bifurcation_diagrams_options[bifurcation_diagram].redraw_all()

        # redraw eigenvalue spectrum only if this is the first
        if bifurcation_diagram == BifurcationDiagramTypes.FIRST:
            self.redraw_eigenvalue_spectrums_graphs()

    def redraw_eigenvalue_spectrums_graphs(self) -> None:
        for branch_type in BranchTypes:
            self.eigenvalue_spectrum[branch_type].redraw_all()

    def redraw_hopf_bifurcations_graphs(self) -> None:
        for hopf_parameter_type in HopfParameterTypes:
            self.redraw_hopf_bifurcation[hopf_parameter_type] = True

    def update_scatter_flags(
        self,
        # bifurcations
        saddlenode_empirical: bool,
        saddlenode_alternative: bool,
        transcritical_empirical: bool,
        transcritical_alternative: bool,
        hopf_subcritical_empirical: bool,
        hopf_subcritical_alternative: bool,
        hopf_supercritical_empirical: bool,
        hopf_supercritical_alternative: bool,
        bautin: bool,
        bogdanov_takens: bool,
        double_hopf: bool,
        # scatter options
        equilibria_area: bool,
        equilibria_stable: bool,
        equilibria_unstable: bool,
        equilibria_over_information: bool,
        hopf_envelope_empirical: bool,
        hopf_envelope_alternative: bool,
        extinct: bool,
        internal_error: bool,
        eigenvalue_spectrum_symbols: bool,
        draw_branch_empirical: bool,
        draw_branch_alternative: bool,
        draw_lines: bool,
        draw_points: bool,
    ) -> None:
        """Update scatter flags"""
        # ternary
        self.scatter_ternary_bifurcation.update_bifurcation_options_flags(
            saddlenode_empirical,
            saddlenode_alternative,
            transcritical_empirical,
            transcritical_alternative,
            hopf_subcritical_empirical,
            hopf_subcritical_alternative,
            hopf_supercritical_empirical,
            hopf_supercritical_alternative,
            bautin,
            bogdanov_takens,
            double_hopf,
            draw_lines,
            draw_points,
        )
        self.scatter_ternary_options.update_scatter_options_flags(
            equilibria_area,
            equilibria_stable,
            equilibria_unstable,
            equilibria_over_information,
            extinct,
            internal_error,
            eigenvalue_spectrum_symbols,
            draw_branch_empirical,
            draw_branch_alternative,
            hopf_envelope_empirical,
            hopf_envelope_alternative,
            draw_lines,
            draw_points,
        )
        # bifurcation diagrams
        for bifurcation_diagram in BifurcationDiagramTypes:
            self.bifurcation_diagrams_bifurcations[bifurcation_diagram].update_bifurcation_options_flags(
                saddlenode_empirical,
                saddlenode_alternative,
                transcritical_empirical,
                transcritical_alternative,
                hopf_subcritical_empirical,
                hopf_subcritical_alternative,
                hopf_supercritical_empirical,
                hopf_supercritical_alternative,
                bautin,
                bogdanov_takens,
                double_hopf,
                draw_lines,
                draw_points,
            )
            self.bifurcation_diagrams_options[bifurcation_diagram].update_scatter_options_flags(
                equilibria_area,
                equilibria_stable,
                equilibria_unstable,
                equilibria_over_information,
                extinct,
                internal_error,
                eigenvalue_spectrum_symbols,
                draw_branch_empirical,
                draw_branch_alternative,
                hopf_envelope_empirical,
                hopf_envelope_alternative,
                draw_lines,
                draw_points,
            )
        # eigenvalue spectrums
        self.eigenvalue_spectrum[BranchTypes.EMPIRICAL].update_eigenvalue_spectrum_options_flags()
        self.eigenvalue_spectrum[BranchTypes.ALTERNATIVE].update_eigenvalue_spectrum_options_flags()

    def update_heatmap_flags(
        self,
        # bifurcations
        saddlenode_empirical: bool,
        saddlenode_alternative: bool,
        transcritical_empirical: bool,
        transcritical_alternative: bool,
        hopf_subcritical_empirical: bool,
        hopf_subcritical_alternative: bool,
        hopf_supercritical_empirical: bool,
        hopf_supercritical_alternative: bool,
        bautin: bool,
        bogdanov_takens: bool,
        double_hopf: bool,
    ) -> None:
        """Update heatmap flags"""
        # ternary
        self.bifurcation_heatmap_ternary.update_bifurcation_options_flags(
            saddlenode_empirical,
            saddlenode_alternative,
            transcritical_empirical,
            transcritical_alternative,
            hopf_subcritical_empirical,
            hopf_subcritical_alternative,
            hopf_supercritical_empirical,
            hopf_supercritical_alternative,
            bautin,
            bogdanov_takens,
            double_hopf,
            False,
            False,
        )

    def update_distribution_flags(
        self,
        # bifurcations
        saddlenode_empirical: bool,
        saddlenode_alternative: bool,
        transcritical_empirical: bool,
        transcritical_alternative: bool,
        hopf_subcritical_empirical: bool,
        hopf_subcritical_alternative: bool,
        hopf_supercritical_empirical: bool,
        hopf_supercritical_alternative: bool,
        bautin: bool,
        bogdanov_takens: bool,
        double_hopf: bool,
    ) -> None:
        """Update distribution flags"""
        self.bifurcation_distribution.update_bifurcation_options_flags(
            saddlenode_empirical,
            saddlenode_alternative,
            transcritical_empirical,
            transcritical_alternative,
            hopf_subcritical_empirical,
            hopf_subcritical_alternative,
            hopf_supercritical_empirical,
            hopf_supercritical_alternative,
            bautin,
            bogdanov_takens,
            double_hopf,
            False,
            False,
        )

    # redraw hopf parameters
    def redraw_hopf_parameters(self) -> None:
        for hopf_parameter_type in HopfParameterTypes:
            self.redraw_hopf_bifurcation[hopf_parameter_type] = True

    def is_scatter_redraw_required(self) -> None:
        """Check all drawing components to see if any redraw is required.
        Evaluates all of them to ensure all warnings are printed before returning.
        """
        # Scatter ternary
        self.scatter_ternary_bifurcation.is_redraw_required("Scatter ternary")
        self.scatter_ternary_options.is_redraw_required("Scatter ternary")

        # Bifurcation diagrams
        for bifurcation_diagram_type_bifurcation, bifurcation_diagram_bifurcation in self.bifurcation_diagrams_bifurcations.items():
            bifurcation_diagram_bifurcation.is_redraw_required(f"bifurcation diagram {bifurcation_diagram_type_bifurcation.value}")

        for bifurcation_diagram_type_option, bifurcation_diagram_options in self.bifurcation_diagrams_options.items():
            bifurcation_diagram_options.is_redraw_required(f"bifurcation diagram {bifurcation_diagram_type_option.value}")

        # Eigenvalue spectrums
        for branch_type, branch_options in self.eigenvalue_spectrum.items():
            branch_options.is_redraw_required(f"eigenvalue spectrum {branch_type.value}")

        # Hopf bifurcations
        for hopf_type, needs_redraw in self.redraw_hopf_bifurcation.items():
            if needs_redraw:
                print(f"Redraw required in Hopf bifurcation plot due to: {hopf_type.name}")
