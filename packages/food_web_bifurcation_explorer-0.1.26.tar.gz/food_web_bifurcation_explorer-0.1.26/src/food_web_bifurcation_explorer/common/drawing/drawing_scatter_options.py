from food_web_bifurcation_explorer.common.drawing.drawing_mode import DrawingMode


class DrawingScatterOptions:
    def __init__(self) -> None:
        # flags to indicate if drawing an specific element of scatter diagrams
        self.equilibria_area: bool = True
        self.equilibria_stable: bool = True
        self.equilibria_unstable: bool = True
        self.equilibria_over_information: bool = True
        self.extinct: bool = True
        self.internal_error: bool = True
        self.eigenvalue_spectrum_symbols: bool = True
        self.branch_empirical: bool = True
        self.branch_alternative: bool = True
        self.hopf_envelope_empirical: bool = True
        self.hopf_envelope_alternative: bool = True
        # drawing mode for lines and points
        self.drawing_mode: DrawingMode = DrawingMode()
        # flags to indicate if redraw is required for scater diagarms
        self.redraw_equilibria_area: bool = True
        self.redraw_equilibria_stable: bool = True
        self.redraw_equilibria_unstable: bool = True
        self.redraw_internal_error: bool = True
        self.redraw_extinct: bool = True
        self.redraw_ternary_branches: bool = True
        self.redraw_hopf_envelope_empirical: bool = True
        self.redraw_hopf_envelope_alternative: bool = True
        self.redraw_eigenvalue_spectrum_symbol_empirical: bool = True
        self.redraw_eigenvalue_spectrum_symbol_alternative: bool = True

    def update_scatter_options_flags(
        self,
        equilibria_area: bool,
        equilibria_stable: bool,
        equilibria_unstable: bool,
        equilibria_over_information: bool,
        extinct: bool,
        internal_error: bool,
        eigenvalue_spectrum_symbols: bool,
        draw_branch_empirical: bool,
        draw_branch_alternative: bool,
        hopf_envelope_empirical: bool,
        hopf_envelope_alternative: bool,
        lines: bool,
        points: bool,
    ) -> None:
        """Update scatter flags"""
        # update values
        self.redraw_equilibria_area = self.redraw_equilibria_area or (self.equilibria_area != equilibria_area)
        self.redraw_equilibria_stable = self.redraw_equilibria_stable or (self.equilibria_stable != equilibria_stable)
        self.redraw_equilibria_unstable = self.redraw_equilibria_unstable or (self.equilibria_unstable != equilibria_unstable)
        self.redraw_extinct = self.redraw_extinct or (self.extinct != extinct)
        self.redraw_internal_error = self.redraw_internal_error or (self.internal_error != internal_error)
        self.redraw_ternary_branches = self.redraw_ternary_branches or (self.branch_empirical != draw_branch_empirical)
        self.redraw_hopf_envelope_empirical = self.redraw_hopf_envelope_empirical or (self.hopf_envelope_empirical != hopf_envelope_empirical)
        self.redraw_hopf_envelope_alternative = self.redraw_hopf_envelope_alternative or (self.hopf_envelope_alternative != hopf_envelope_alternative)
        # special case for eigenvalue spectrum (shares the same flag)
        self.redraw_eigenvalue_spectrum_symbol_empirical = (
            self.redraw_eigenvalue_spectrum_symbol_empirical or self.eigenvalue_spectrum_symbols != eigenvalue_spectrum_symbols
        )
        self.redraw_eigenvalue_spectrum_symbol_alternative = (
            self.redraw_eigenvalue_spectrum_symbol_alternative or self.eigenvalue_spectrum_symbols != eigenvalue_spectrum_symbols
        )
        # special case for drawing options (this requiere to redraw all)
        if self.equilibria_over_information != equilibria_over_information:
            self.redraw_all()
        if self.drawing_mode.lines != lines:
            self.redraw_all()
        if self.drawing_mode.points != points:
            self.redraw_all()
        # update values
        self.equilibria_area = equilibria_area
        self.equilibria_stable = equilibria_stable
        self.equilibria_unstable = equilibria_unstable
        self.equilibria_over_information = equilibria_over_information
        self.extinct = extinct
        self.internal_error = internal_error
        self.eigenvalue_spectrum_symbols = eigenvalue_spectrum_symbols
        self.branch_empirical = draw_branch_empirical
        self.branch_alternative = draw_branch_alternative
        self.hopf_envelope_empirical = hopf_envelope_empirical
        self.hopf_envelope_alternative = hopf_envelope_alternative
        # update drawing mode flags
        self.drawing_mode.update_drawing_mode_flags(lines, points)

    def redraw_all(self) -> None:
        """Set all redraw flags to True."""
        self.redraw_equilibria_area = True
        self.redraw_equilibria_stable = True
        self.redraw_equilibria_unstable = True
        self.redraw_extinct = True
        self.redraw_internal_error = True
        self.redraw_ternary_branches = True
        self.redraw_eigenvalue_spectrum_symbol_empirical = True
        self.redraw_eigenvalue_spectrum_symbol_alternative = True

    def is_redraw_required(self, parent: str) -> None:
        """Check if any element requires a redraw, and print a warning with the reasons."""
        # use the items of dictionary vinculated with this
        reasons = [attr.replace("redraw_", "") for attr, value in self.__dict__.items() if attr.startswith("redraw_") and value is True]
        # show info
        if reasons:
            formatted_reasons = "\n".join(f"- {reason}" for reason in reasons)
            print(f"Redraw required in {parent} due to:\n{formatted_reasons}")
