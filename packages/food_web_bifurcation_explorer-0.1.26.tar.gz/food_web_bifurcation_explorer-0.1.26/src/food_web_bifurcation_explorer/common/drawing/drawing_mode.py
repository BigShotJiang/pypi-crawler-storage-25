class DrawingMode:
    def __init__(self) -> None:
        self.lines: bool = True
        self.points: bool = True

    def update_drawing_mode_flags(
        self,
        lines: bool,
        points: bool,
    ) -> None:
        self.lines = lines
        self.points = points

    def get_drawing_mode(self) -> str:
        """Get drawing mode (lines, points or both)"""
        if self.lines and self.points:
            return "lines+markers"
        elif self.lines:
            return "lines"
        elif self.points:
            return "markers"
        else:
            return "none"
