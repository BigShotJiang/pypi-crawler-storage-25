import plotly.graph_objects as go

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.common.drawing.drawing_bifurcation_options import DrawingBifurcationOptions
from food_web_bifurcation_explorer.common.drawing.drawing_scatter_options import DrawingScatterOptions
from food_web_bifurcation_explorer.data.ternary_data import TernaryData
from food_web_bifurcation_explorer.data.ternary_line import TernaryLine
from food_web_bifurcation_explorer.enums.static_options import StaticOptions
from food_web_bifurcation_explorer.enums.traces.ternary_traces import TernaryTraces
from food_web_bifurcation_explorer.enums.types.area_types import AreaTypes
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.types.visual.bifurcation_codimension_one_visual_types import BifurcationCodimensionOneVisualTypes
from food_web_bifurcation_explorer.enums.types.visual.bifurcation_codimension_two_visual_types import BifurcationCodimensionTwoVisualTypes
from food_web_bifurcation_explorer.enums.types.visual.extinctions_visual_types import ExtinctVisualTypes
from food_web_bifurcation_explorer.enums.types.visual.other_visual_types import OtherVisualTypes
from food_web_bifurcation_explorer.graph.ternary.ternary_hover_template import ternary_hover_template


def update_codimension_one_bifurcation_trace(
    ternary: go.Figure,
    ternary_trace: TernaryTraces,
    branch_type: BranchTypes,
    bifurcation_codimension_one_type: BifurcationCodimensionOneVisualTypes,
    drawing_mode: str,
    is_active: bool,
) -> go.Figure:
    # declare combined lists for a, b, c
    sls_combined: list[float | None] = []
    sds_combined: list[float | None] = []
    srs_combined: list[float | None] = []

    # only populate if active, otherwise leave empty to clear the trace
    if is_active:
        # get ternary data
        ternary_data: TernaryData = glob.plot_data.ternary_data

        # obtain relevant indexes for the given branch and trace type
        indexes = ternary_data.get_codimension_one_bifurcation_indexes(branch_type, bifurcation_codimension_one_type)

        # iterate over all indexes
        for idx in indexes:
            # retrieve a, b, c values for the current index
            sds, srs, sls = ternary_data.get_bifurcation_codimension_one_ternary_values(branch_type, bifurcation_codimension_one_type, idx)

            # only add to combined lists if there are valid points (a_list is not empty)
            if sls and len(sls) > 0:
                # append to combined lists
                sls_combined.extend(sls)
                sds_combined.extend(sds)
                srs_combined.extend(srs)

                # insert None to break lines between segments
                if "lines" in drawing_mode:
                    sls_combined.append(None)
                    sds_combined.append(None)
                    srs_combined.append(None)
    # set over info
    hover_info = "all" if glob.config.drawing_options.scatter_ternary_options.equilibria_over_information and sls_combined else "skip"

    # update traces
    ternary.update_traces(
        selector={"name": str(ternary_trace.value)},
        a=sls_combined,
        b=sds_combined,
        c=srs_combined,
        mode=drawing_mode if sls_combined else "markers",
        hoverinfo=hover_info,
        hovertemplate=(
            ternary_hover_template(
                ternary_trace.value, StaticOptions.SCATTER_RESOLUTION, glob.config.drawing_options.scatter_ternary_options.equilibria_over_information
            )
            if sls_combined
            else None
        ),
    )


def update_codimension_two_bifurcation_trace(
    ternary: go.Figure,
    ternary_trace: TernaryTraces,
    bifurcation_codimension_two_type: BifurcationCodimensionTwoVisualTypes,
    is_active: bool,
) -> go.Figure:
    # declare combined lists for a, b, c
    sds: list[float] = []
    srs: list[float] = []
    sls: list[float] = []

    # only populate if active, otherwise leave empty to clear the trace
    if is_active:
        # retrieve a, b, c values for the current index
        sds, srs, sls = glob.plot_data.ternary_data.get_two_codimension_bifurcation_ternary_values(bifurcation_codimension_two_type)

    # set over info
    hover_info = "all" if glob.config.drawing_options.scatter_ternary_options.equilibria_over_information and sls else "skip"

    # update traces
    ternary.update_traces(
        selector={"name": str(ternary_trace.value)},
        a=sls,
        b=sds,
        c=srs,
        mode="markers",
        hoverinfo=hover_info,
        hovertemplate=(
            ternary_hover_template(
                ternary_trace.value, StaticOptions.SCATTER_RESOLUTION, glob.config.drawing_options.scatter_ternary_options.equilibria_over_information
            )
            if sls
            else None
        ),
    )


def update_extinction_trace(
    ternary: go.Figure,
    ternary_trace: TernaryTraces,
    branch_type: BranchTypes,
    extinction_type: ExtinctVisualTypes,
    drawing_mode: str,
    is_active: bool,
) -> go.Figure:
    # declare combined lists for a, b, c
    sls_combined: list[float | None] = []
    sds_combined: list[float | None] = []
    srs_combined: list[float | None] = []

    # only populate if active, otherwise leave empty to clear the trace
    if is_active:
        # get ternary data
        ternary_data: TernaryData = glob.plot_data.ternary_data

        # obtain relevant indexes for the given branch and trace type
        indexes = ternary_data.get_extinction_indexes(branch_type, extinction_type)

        # iterate over all indexes
        for idx in indexes:
            # retrieve a, b, c values for the current index
            sds, srs, sls = ternary_data.get_extinction_ternary_values(branch_type, extinction_type, idx)

            # only add to combined lists if there are valid points (a_list is not empty)
            if sls and len(sls) > 0:
                # append to combined lists
                sls_combined.extend(sls)
                sds_combined.extend(sds)
                srs_combined.extend(srs)

                # insert None to break lines between segments
                if "lines" in drawing_mode:
                    sls_combined.append(None)
                    sds_combined.append(None)
                    srs_combined.append(None)
    # set over info
    hover_info = "all" if glob.config.drawing_options.scatter_ternary_options.equilibria_over_information and sls_combined else "skip"

    # update traces
    ternary.update_traces(
        selector={"name": str(ternary_trace.value)},
        a=sls_combined,
        b=sds_combined,
        c=srs_combined,
        mode=drawing_mode if sls_combined else "markers",
        hoverinfo=hover_info,
        hovertemplate=(
            ternary_hover_template(
                ternary_trace.value, StaticOptions.SCATTER_RESOLUTION, glob.config.drawing_options.scatter_ternary_options.equilibria_over_information
            )
            if sls_combined
            else None
        ),
    )


def update_other_trace(
    ternary: go.Figure,
    ternary_trace: TernaryTraces,
    branch_type: BranchTypes,
    other_type: OtherVisualTypes,
    is_active: bool,
) -> go.Figure:
    # declare combined lists for a, b, c
    sds: list[float] = []
    srs: list[float] = []
    sls: list[float] = []

    # only populate if active, otherwise leave empty to clear the trace
    if is_active:
        # retrieve a, b, c values
        sds, srs, sls = glob.plot_data.ternary_data.get_other_ternary_values(branch_type, other_type)

    # set over info
    hover_info = "all" if glob.config.drawing_options.scatter_ternary_options.equilibria_over_information and sls else "skip"

    # update traces
    ternary.update_traces(
        selector={"name": str(ternary_trace.value)},
        a=sls,
        b=sds,
        c=srs,
        mode="markers",
        hoverinfo=hover_info,
        hovertemplate=(
            ternary_hover_template(
                ternary_trace.value, StaticOptions.SCATTER_RESOLUTION, glob.config.drawing_options.scatter_ternary_options.equilibria_over_information
            )
            if sls
            else None
        ),
    )


def update_scatter_ternary() -> go.Figure:

    # get ternary
    ternary: go.Figure = glob.figures.scatter_ternary

    # adjust layout size based on resolution
    ternary.update_layout(width=glob.config.resolution * 2, height=glob.config.resolution * 2)

    # get ternary options
    scatter_ternary_options: DrawingScatterOptions = glob.config.drawing_options.scatter_ternary_options
    scatter_ternary_bifurcation: DrawingBifurcationOptions = glob.config.drawing_options.scatter_ternary_bifurcation

    # Stable area
    if scatter_ternary_options.equilibria_area:
        sd, sr, sl = glob.plot_data.ternary_data.shape_data.get_perimeter_coordinates(AreaTypes.STABLE)
        ternary.update_traces(selector={"name": str(TernaryTraces.STABLE_EQUILIBRIA_AREA.value)}, a=sl, b=sd, c=sr)
    else:
        ternary.update_traces(selector={"name": str(TernaryTraces.STABLE_EQUILIBRIA_AREA.value)}, a=[], b=[], c=[])

    # Unstable area
    if scatter_ternary_options.equilibria_area:
        sd, sr, sl = glob.plot_data.ternary_data.shape_data.get_perimeter_coordinates(AreaTypes.UNSTABLE)
        ternary.update_traces(selector={"name": str(TernaryTraces.UNSTABLE_EQUILIBRIA_AREA.value)}, a=sl, b=sd, c=sr)
    else:
        ternary.update_traces(selector={"name": str(TernaryTraces.UNSTABLE_EQUILIBRIA_AREA.value)}, a=[], b=[], c=[])

    # ternary line
    if scatter_ternary_options.redraw_ternary_branches:
        # create line
        ternary_line = TernaryLine()

        # Stable
        sl, sd, sr = (ternary_line.stable_sl, ternary_line.stable_sd, ternary_line.stable_sr) if ternary_line.stable_sl else ([], [], [])
        ternary.update_traces(
            selector={"name": str(TernaryTraces.STABLE_EQUILIBRIA.value)},
            a=sl,
            b=sd,
            c=sr,
            mode="lines",
            hovertemplate=ternary_hover_template(
                "Empirical stable equilibrium", StaticOptions.SCATTER_RESOLUTION, scatter_ternary_options.equilibria_over_information
            ),
        )

        # Unstable
        sl, sd, sr = (ternary_line.unstable_sl, ternary_line.unstable_sd, ternary_line.unstable_sr) if ternary_line.unstable_sl else ([], [], [])
        ternary.update_traces(
            selector={"name": str(TernaryTraces.UNSTABLE_EQUILIBRIA.value)},
            a=sl,
            b=sd,
            c=sr,
            mode="lines",
            hovertemplate=ternary_hover_template(
                "Empirical unstable equilibrium", StaticOptions.SCATTER_RESOLUTION, scatter_ternary_options.equilibria_over_information
            ),
        )
        scatter_ternary_options.redraw_ternary_branches = False

    # extinctions
    if scatter_ternary_options.redraw_extinct:
        update_extinction_trace(
            ternary,
            TernaryTraces.EXTINCT,
            BranchTypes.ALTERNATIVE,
            ExtinctVisualTypes.EXTINCT,
            scatter_ternary_options.drawing_mode.get_drawing_mode(),
            scatter_ternary_options.extinct,
        )
        scatter_ternary_options.redraw_extinct = False

    # saddle node empirical
    if scatter_ternary_bifurcation.redraw_saddlenode_empirical:
        update_codimension_one_bifurcation_trace(
            ternary,
            TernaryTraces.SADDLENODE_EMPIRICAL,
            BranchTypes.EMPIRICAL,
            BifurcationCodimensionOneVisualTypes.SADDLENODE,
            scatter_ternary_options.drawing_mode.get_drawing_mode(),
            scatter_ternary_bifurcation.saddlenode_empirical,
        )
        scatter_ternary_bifurcation.redraw_saddlenode_empirical = False

    # saddle node alternative
    if scatter_ternary_bifurcation.redraw_saddlenode_alternative:
        update_codimension_one_bifurcation_trace(
            ternary,
            TernaryTraces.SADDLENODE_ALTERNATIVE,
            BranchTypes.ALTERNATIVE,
            BifurcationCodimensionOneVisualTypes.SADDLENODE,
            scatter_ternary_options.drawing_mode.get_drawing_mode(),
            scatter_ternary_bifurcation.saddlenode_alternative,
        )
        scatter_ternary_bifurcation.redraw_saddlenode_alternative = False

    # transcritical empirical
    if scatter_ternary_bifurcation.redraw_transcritical_empirical:
        update_codimension_one_bifurcation_trace(
            ternary,
            TernaryTraces.TRANSCRITICAL_EMPIRICAL,
            BranchTypes.EMPIRICAL,
            BifurcationCodimensionOneVisualTypes.TRANSCRITICAL,
            scatter_ternary_options.drawing_mode.get_drawing_mode(),
            scatter_ternary_bifurcation.transcritical_empirical,
        )
        scatter_ternary_bifurcation.redraw_transcritical_empirical = False

    # transcritical alternative
    if scatter_ternary_bifurcation.redraw_transcritical_alternative:
        update_codimension_one_bifurcation_trace(
            ternary,
            TernaryTraces.TRANSCRITICAL_ALTERNATIVE,
            BranchTypes.ALTERNATIVE,
            BifurcationCodimensionOneVisualTypes.TRANSCRITICAL,
            scatter_ternary_options.drawing_mode.get_drawing_mode(),
            scatter_ternary_bifurcation.transcritical_alternative,
        )
        scatter_ternary_bifurcation.redraw_transcritical_alternative = False

    # hopf subcritical empirical
    if scatter_ternary_bifurcation.redraw_hopf_subcritical_empirical:
        update_codimension_one_bifurcation_trace(
            ternary,
            TernaryTraces.HOPF_SUBCRITICAL_EMPIRICAL,
            BranchTypes.EMPIRICAL,
            BifurcationCodimensionOneVisualTypes.HOPF_SUBCRITICAL,
            scatter_ternary_options.drawing_mode.get_drawing_mode(),
            scatter_ternary_bifurcation.hopf_subcritical_empirical,
        )
        scatter_ternary_bifurcation.redraw_hopf_subcritical_empirical = False

    # hopf subcritical alternative
    if scatter_ternary_bifurcation.redraw_hopf_subcritical_alternative:
        update_codimension_one_bifurcation_trace(
            ternary,
            TernaryTraces.HOPF_SUBCRITICAL_ALTERNATIVE,
            BranchTypes.ALTERNATIVE,
            BifurcationCodimensionOneVisualTypes.HOPF_SUBCRITICAL,
            scatter_ternary_options.drawing_mode.get_drawing_mode(),
            scatter_ternary_bifurcation.hopf_subcritical_alternative,
        )
        scatter_ternary_bifurcation.redraw_hopf_subcritical_alternative = False

    # hopf supercritical empirical
    if scatter_ternary_bifurcation.redraw_hopf_supercritical_empirical:
        update_codimension_one_bifurcation_trace(
            ternary,
            TernaryTraces.HOPF_SUPERCRITICAL_EMPIRICAL,
            BranchTypes.EMPIRICAL,
            BifurcationCodimensionOneVisualTypes.HOPF_SUPERCRITICAL,
            scatter_ternary_options.drawing_mode.get_drawing_mode(),
            scatter_ternary_bifurcation.hopf_supercritical_empirical,
        )
        scatter_ternary_bifurcation.redraw_hopf_supercritical_empirical = False

    # hopf supercritical alternative
    if scatter_ternary_bifurcation.redraw_hopf_supercritical_alternative:
        update_codimension_one_bifurcation_trace(
            ternary,
            TernaryTraces.HOPF_SUPERCRITICAL_ALTERNATIVE,
            BranchTypes.ALTERNATIVE,
            BifurcationCodimensionOneVisualTypes.HOPF_SUPERCRITICAL,
            scatter_ternary_options.drawing_mode.get_drawing_mode(),
            scatter_ternary_bifurcation.hopf_supercritical_alternative,
        )
        scatter_ternary_bifurcation.redraw_hopf_supercritical_alternative = False

    # bautin
    if scatter_ternary_bifurcation.redraw_bautin:
        update_codimension_two_bifurcation_trace(
            ternary,
            TernaryTraces.BAUTIN,
            BifurcationCodimensionTwoVisualTypes.BAUTIN,
            scatter_ternary_bifurcation.bautin,
        )
        scatter_ternary_bifurcation.redraw_bautin = False

    # bogdanov-takens
    if scatter_ternary_bifurcation.redraw_bogdanov_takens:
        update_codimension_two_bifurcation_trace(
            ternary,
            TernaryTraces.BOGDANOV_TAKENS,
            BifurcationCodimensionTwoVisualTypes.BOGDANOV_TAKENS,
            scatter_ternary_bifurcation.bogdanov_takens,
        )
        scatter_ternary_bifurcation.redraw_bogdanov_takens = False

    # double hopf
    if scatter_ternary_bifurcation.redraw_double_hopf:
        update_codimension_two_bifurcation_trace(
            ternary,
            TernaryTraces.DOUBLE_HOPF,
            BifurcationCodimensionTwoVisualTypes.DOUBLE_HOPF,
            scatter_ternary_bifurcation.double_hopf,
        )
        scatter_ternary_bifurcation.redraw_double_hopf = False

    # internal error
    if scatter_ternary_options.redraw_internal_error:
        update_other_trace(
            ternary,
            TernaryTraces.INTERNAL_ERROR,
            BranchTypes.ALTERNATIVE,
            OtherVisualTypes.INTERNAL_ERROR,
            scatter_ternary_options.internal_error,
        )
        scatter_ternary_options.redraw_internal_error = False

    return ternary
