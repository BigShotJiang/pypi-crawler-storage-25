import plotly.graph_objects as go  # type: ignore

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.colors.bifurcation_colors import BifurcationColors
from food_web_bifurcation_explorer.enums.colors.stability_colors import StabilityColors
from food_web_bifurcation_explorer.enums.traces.ternary_traces import TernaryTraces
from food_web_bifurcation_explorer.graph.ternary.add_ternary_arrows import add_ternary_arrows


def build_scatter_ternary() -> go.Figure:

    # declare line width
    line_width: int = 4

    # create figure
    fig = go.Figure()

    # equilibria areas (filled polygons)
    fig.add_trace(
        go.Scatterternary(
            name=str(TernaryTraces.STABLE_EQUILIBRIA_AREA.value),
            a=[],
            b=[],
            c=[],
            mode="lines",
            fill="toself",
            fillcolor=StabilityColors.STABLE_AREA,
            line={"width": line_width, "color": StabilityColors.STABLE_AREA},
            opacity=1.0,
            showlegend=False,
            hoverinfo="skip",
        )
    )
    fig.add_trace(
        go.Scatterternary(
            name=str(TernaryTraces.UNSTABLE_EQUILIBRIA_AREA.value),
            a=[],
            b=[],
            c=[],
            mode="lines",
            fill="toself",
            fillcolor=StabilityColors.UNSTABLE_AREA,
            line={"width": line_width, "color": StabilityColors.UNSTABLE_AREA},
            opacity=1.0,
            showlegend=False,
            hoverinfo="skip",
        )
    )

    # equilibra lines
    fig.add_trace(
        go.Scatterternary(
            name=str(TernaryTraces.STABLE_EQUILIBRIA.value),
            a=[],
            b=[],
            c=[],
            mode="lines",
            line={"color": StabilityColors.STABLE, "width": line_width},
            showlegend=False,
        )
    )
    fig.add_trace(
        go.Scatterternary(
            name=str(TernaryTraces.UNSTABLE_EQUILIBRIA.value),
            a=[],
            b=[],
            c=[],
            mode="lines",
            line={"color": StabilityColors.UNSTABLE, "width": line_width},
            showlegend=False,
        )
    )

    # combination of traces and colors
    traces_to_add = [
        # termination
        (TernaryTraces.EXTINCT, BifurcationColors.EXTINCT),
        # bifurcation of codimension one
        (TernaryTraces.SADDLENODE_EMPIRICAL, BifurcationColors.SADDLENODE_EMPIRICAL),
        (TernaryTraces.SADDLENODE_ALTERNATIVE, BifurcationColors.SADDLENODE_ALTERNATIVE),
        (TernaryTraces.TRANSCRITICAL_EMPIRICAL, BifurcationColors.TRANSCRITICAL_EMPIRICAL),
        (TernaryTraces.TRANSCRITICAL_ALTERNATIVE, BifurcationColors.TRANSCRITICAL_ALTERNATIVE),
        (TernaryTraces.HOPF_SUBCRITICAL_EMPIRICAL, BifurcationColors.HOPF_SUBCRITICAL_EMPIRICAL),
        (TernaryTraces.HOPF_SUBCRITICAL_ALTERNATIVE, BifurcationColors.HOPF_SUBCRITICAL_ALTERNATIVE),
        (TernaryTraces.HOPF_SUPERCRITICAL_EMPIRICAL, BifurcationColors.HOPF_SUPERCRITICAL_EMPIRICAL),
        (TernaryTraces.HOPF_SUPERCRITICAL_ALTERNATIVE, BifurcationColors.HOPF_SUPERCRITICAL_ALTERNATIVE),
        # bifurcation of codimension two
        (TernaryTraces.BAUTIN, BifurcationColors.BAUTIN),
        (TernaryTraces.BOGDANOV_TAKENS, BifurcationColors.BOGDANOV_TAKENS),
        (TernaryTraces.DOUBLE_HOPF, BifurcationColors.DOUBLE_HOPF),
        # internal error aways the last
        (TernaryTraces.INTERNAL_ERROR, BifurcationColors.INTERNAL_ERROR),
    ]
    # add traces with corresponding colors
    for trace_enum, color in traces_to_add:
        fig.add_trace(
            go.Scatterternary(
                name=str(trace_enum.value),
                a=[],
                b=[],
                c=[],
                mode="lines+markers",
                marker={"size": 6, "color": color, "opacity": 1},
                line={"color": color, "width": line_width},
                showlegend=False,
            )
        )

    # configure layout
    tick_vals_increase = [round(i * 0.1, 1) for i in range(11)]
    tick_vals_decrease = [round(i * 0.1, 1) for i in range(10, -1, -1)]
    tick_text_decrease = [f"{val:g}" for val in tick_vals_decrease]
    marging = 0.05

    # set ternary layout with custom ticks and gridlines
    fig.update_layout(
        ternary={
            "domain": {"x": [marging, 1 - marging], "y": [marging, 1 - marging]},
            "sum": 1,
            "aaxis": {
                "min": 0,
                "tickvals": tick_vals_increase,
                "ticktext": tick_text_decrease,
                "tickangle": 60,
                "title": "",
                "linecolor": "black",
                "gridcolor": "lightgray",
            },
            "baxis": {
                "min": 0,
                "tickvals": tick_vals_increase,
                "ticktext": tick_text_decrease,
                "tickangle": -60,
                "title": "",
                "linecolor": "black",
                "gridcolor": "lightgray",
            },
            "caxis": {
                "min": 0,
                "tickvals": tick_vals_increase,
                "ticktext": tick_text_decrease,
                "tickangle": 0,
                "title": "",
                "linecolor": "black",
                "gridcolor": "lightgray",
            },
            "bgcolor": "white",
        },
        xaxis={
            "range": [0, 1],
            "scaleanchor": "y",
            "scaleratio": 1,
            "visible": False,
            "showgrid": False,
            "zeroline": False,
            "showticklabels": False,
            "fixedrange": False,
        },
        yaxis={"range": [0, 1], "visible": False, "showgrid": False, "zeroline": False, "showticklabels": False, "fixedrange": False},
        plot_bgcolor="rgba(0,0,0,0)",
        paper_bgcolor="rgba(0,0,0,0)",
        showlegend=False,
        uirevision="ternary",
        width=glob.config.resolution * 2,
        height=glob.config.resolution * 2,
    )

    # add ternary arrows
    fig = add_ternary_arrows(fig)

    # return ternary heatmap figure
    return fig
