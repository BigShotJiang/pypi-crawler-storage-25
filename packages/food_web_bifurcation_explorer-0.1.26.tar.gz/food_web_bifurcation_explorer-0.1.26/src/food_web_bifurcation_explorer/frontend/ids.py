from enum import Enum, unique

from food_web_bifurcation_explorer.common.decorators import consistent_ids


@unique
@consistent_ids
class IDs(str, Enum):
    """Enumeration for frontend IDs."""

    # control for scatter ternary
    DROPDOWN_SCATTER_COMPARTMENT_FIRST = "dropdown-scatter-compartment-first"
    DROPDOWN_SCATTER_COMPARTMENT_SECOND = "dropdown-scatter-compartment-second"
    DROPDOWN_SCATTER_NETWORK = "dropdown-scatter-network"
    DROPDOWN_SCATTER_PARAMETER_TYPE = "dropdown-scatter-parameter-type"
    DROPDOWN_SCATTER_SIZE = "dropdown-scatter-size"
    TEXTFIELD_SCATTER_FIXED_PARAMETER_VALUE = "textfield-scatter-fixed-parameter-value"
    # eigen values spectrum for scatter ternary
    TEXTFIELD_SCATTER_EIGENVALUE_SPECTRUM_INDEX_ALTERNATIVE = "textfield-scatter-eigenvalue-spectrum-index-alternative"
    TEXTFIELD_SCATTER_EIGENVALUE_SPECTRUM_INDEX_EMPIRICAL = "textfield-scatter-eigenvalue-spectrum-index-empirical"
    # checkbox branches for scatter ternary
    CHECKBOX_SCATTER_EQUILIBRIA_AREA = "checkbox-scatter-equilibria-area"
    CHECKBOX_SCATTER_EQUILIBRIA_OVERINFORMATION = "checkbox-scatter-equilibria-overinformation"
    CHECKBOX_SCATTER_EQUILIBRIA_STABLE = "checkbox-scatter-equilibria-stable"
    CHECKBOX_SCATTER_EQUILIBRIA_UNSTABLE = "checkbox-scatter-equilibria-unstable"
    # checkbox bifurcations for bifurcation codimension one
    CHECKBOX_SCATTER_BIFURCATIONS_HOPF_SUBCRITICAL_ALTERNATIVE = "checkbox-scatter-bifurcations-hopf-subcritical-alternative"
    CHECKBOX_SCATTER_BIFURCATIONS_HOPF_SUBCRITICAL_EMPIRICAL = "checkbox-scatter-bifurcations-hopf-subcritical-empirical"
    CHECKBOX_SCATTER_BIFURCATIONS_HOPF_SUPERCRITICAL_ALTERNATIVE = "checkbox-scatter-bifurcations-hopf-supercritical-alternative"
    CHECKBOX_SCATTER_BIFURCATIONS_HOPF_SUPERCRITICAL_EMPIRICAL = "checkbox-scatter-bifurcations-hopf-supercritical-empirical"
    CHECKBOX_SCATTER_BIFURCATIONS_SADDLENODE_ALTERNATIVE = "checkbox-scatter-bifurcations-saddlenode-alternative"
    CHECKBOX_SCATTER_BIFURCATIONS_SADDLENODE_EMPIRICAL = "checkbox-scatter-bifurcations-saddlenode-empirical"
    CHECKBOX_SCATTER_BIFURCATIONS_TRANSCRITICAL_ALTERNATIVE = "checkbox-scatter-bifurcations-transcritical-alternative"
    CHECKBOX_SCATTER_BIFURCATIONS_TRANSCRITICAL_EMPIRICAL = "checkbox-scatter-bifurcations-transcritical-empirical"
    # checkbox bifurcations for bifurcation codimension two
    CHECKBOX_SCATTER_BIFURCATIONS_BAUTIN = "checkbox-scatter-bifurcations-bautin"
    CHECKBOX_SCATTER_BIFURCATIONS_BOGDANOV_TAKENS = "checkbox-scatter-bifurcations-bogdanov-takens"
    CHECKBOX_SCATTER_BIFURCATIONS_DOUBLE_HOPF = "checkbox-scatter-bifurcations-double-hopf"
    # checkbox for envelopes
    CHECKBOX_SCATTER_BIFURCATIONS_HOPF_ENVELOPE_EMPIRICAL = "checkbox-scatter-bifurcations-hopf-envelope-empirical"
    CHECKBOX_SCATTER_BIFURCATIONS_HOPF_ENVELOPE_ALTERNATIVE = "checkbox-scatter-bifurcations-hopf-envelope-alternative"
    # others
    CHECKBOX_SCATTER_OTHERS_EIGENVALUE_SPECTRUM_INDEX = "checkbox-scatter-others-eigenvalue-spectrum-index"
    CHECKBOX_SCATTER_OTHERS_EXTINCT = "checkbox-scatter-others-extinct"
    CHECKBOX_SCATTER_OTHERS_INTERNALERROR = "checkbox-scatter-others-internalerror"
    # draw options
    CHECKBOX_SCATTER_DRAW_BRANCH_ALTERNATIVE = "checkbox-scatter-draw-branch-alternative"
    CHECKBOX_SCATTER_DRAW_BRANCH_EMPIRICAL = "checkbox-scatter-draw-branch-empirical"
    CHECKBOX_SCATTER_DRAW_LINES = "checkbox-scatter-draw-lines"
    CHECKBOX_SCATTER_DRAW_POINTS = "checkbox-scatter-draw-points"
    # eigen values jump (empirical)
    BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_EMPIRICAL_A = "button-scatter-eigenvalue-spectrum-jump-empirical-a"
    BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_EMPIRICAL_B = "button-scatter-eigenvalue-spectrum-jump-empirical-b"
    BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_EMPIRICAL_C = "button-scatter-eigenvalue-spectrum-jump-empirical-c"
    BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_EMPIRICAL_D = "button-scatter-eigenvalue-spectrum-jump-empirical-d"
    BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_EMPIRICAL_E = "button-scatter-eigenvalue-spectrum-jump-empirical-e"
    # eigen values jump (alternative)
    BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_ALTERNATIVE_A = "button-scatter-eigenvalue-spectrum-jump-alternative-a"
    BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_ALTERNATIVE_B = "button-scatter-eigenvalue-spectrum-jump-alternative-b"
    BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_ALTERNATIVE_C = "button-scatter-eigenvalue-spectrum-jump-alternative-c"
    BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_ALTERNATIVE_D = "button-scatter-eigenvalue-spectrum-jump-alternative-d"
    BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_ALTERNATIVE_E = "button-scatter-eigenvalue-spectrum-jump-alternative-e"
    # heatmap
    TEXTFIELD_HEATMAP_MIN_VALUE = "textfield-heatmap-min-value"
    CHECKBOX_HEATMAP_LOGARITHMIC = "checkbox-heatmap-logarithmic"
    DROPDOWN_HEATMAP_RESOLUTION = "dropdown-heatmap-resolution"
    COLOR_HEATMAP_START_PICKER = "color-heatmap-start-picker"
    COLOR_HEATMAP_END_PICKER = "color-heatmap-end-picker"
    # checkbox bifurcations for bifurcation codimension one
    CHECKBOX_HEATMAP_BIFURCATIONS_HOPF_SUBCRITICAL_ALTERNATIVE = "checkbox-heatmap-bifurcations-hopf-subcritical-alternative"
    CHECKBOX_HEATMAP_BIFURCATIONS_HOPF_SUBCRITICAL_EMPIRICAL = "checkbox-heatmap-bifurcations-hopf-subcritical-empirical"
    CHECKBOX_HEATMAP_BIFURCATIONS_HOPF_SUPERCRITICAL_ALTERNATIVE = "checkbox-heatmap-bifurcations-hopf-supercritical-alternative"
    CHECKBOX_HEATMAP_BIFURCATIONS_HOPF_SUPERCRITICAL_EMPIRICAL = "checkbox-heatmap-bifurcations-hopf-supercritical-empirical"
    CHECKBOX_HEATMAP_BIFURCATIONS_SADDLENODE_ALTERNATIVE = "checkbox-heatmap-bifurcations-saddlenode-alternative"
    CHECKBOX_HEATMAP_BIFURCATIONS_SADDLENODE_EMPIRICAL = "checkbox-heatmap-bifurcations-saddlenode-empirical"
    CHECKBOX_HEATMAP_BIFURCATIONS_TRANSCRITICAL_ALTERNATIVE = "checkbox-heatmap-bifurcations-transcritical-alternative"
    CHECKBOX_HEATMAP_BIFURCATIONS_TRANSCRITICAL_EMPIRICAL = "checkbox-heatmap-bifurcations-transcritical-empirical"
    # checkbox bifurcations for bifurcation codimension two
    CHECKBOX_HEATMAP_BIFURCATIONS_BAUTIN = "checkbox-heatmap-bifurcations-bautin"
    CHECKBOX_HEATMAP_BIFURCATIONS_BOGDANOV_TAKENS = "checkbox-heatmap-bifurcations-bogdanov-takens"
    CHECKBOX_HEATMAP_BIFURCATIONS_DOUBLE_HOPF = "checkbox-heatmap-bifurcations-double-hopf"
    # bifurcation distributions
    TEXTFIELD_DISTRIBUTION_USE_CONTOURS = "textfield-distribution-use-contours"
    TEXTFIELD_DISTRIBUTION_NUM_CONTOURS = "textfield-distribution-num-contours"
    TEXTFIELD_DISTRIBUTION_NUM_BINS = "textfield-distribution-num-bins"
    CHECKBOX_DISTRIBUTION_LOGARITHMIC = "checkbox-distribution-logarithmic"
    # checkbox bifurcations for bifurcation codimension one
    CHECKBOX_DISTRIBUTION_BIFURCATIONS_HOPF_SUBCRITICAL_ALTERNATIVE = "checkbox-distribution-bifurcations-hopf-subcritical-alternative"
    CHECKBOX_DISTRIBUTION_BIFURCATIONS_HOPF_SUBCRITICAL_EMPIRICAL = "checkbox-distribution-bifurcations-hopf-subcritical-empirical"
    CHECKBOX_DISTRIBUTION_BIFURCATIONS_HOPF_SUPERCRITICAL_ALTERNATIVE = "checkbox-distribution-bifurcations-hopf-supercritical-alternative"
    CHECKBOX_DISTRIBUTION_BIFURCATIONS_HOPF_SUPERCRITICAL_EMPIRICAL = "checkbox-distribution-bifurcations-hopf-supercritical-empirical"
    CHECKBOX_DISTRIBUTION_BIFURCATIONS_SADDLENODE_ALTERNATIVE = "checkbox-distribution-bifurcations-saddlenode-alternative"
    CHECKBOX_DISTRIBUTION_BIFURCATIONS_SADDLENODE_EMPIRICAL = "checkbox-distribution-bifurcations-saddlenode-empirical"
    CHECKBOX_DISTRIBUTION_BIFURCATIONS_TRANSCRITICAL_ALTERNATIVE = "checkbox-distribution-bifurcations-transcritical-alternative"
    CHECKBOX_DISTRIBUTION_BIFURCATIONS_TRANSCRITICAL_EMPIRICAL = "checkbox-distribution-bifurcations-transcritical-empirical"
    # checkbox bifurcations for bifurcation codimension two
    CHECKBOX_DISTRIBUTION_BIFURCATIONS_BAUTIN = "checkbox-distribution-bifurcations-bautin"
    CHECKBOX_DISTRIBUTION_BIFURCATIONS_BOGDANOV_TAKENS = "checkbox-distribution-bifurcations-bogdanov-takens"
    CHECKBOX_DISTRIBUTION_BIFURCATIONS_DOUBLE_HOPF = "checkbox-distribution-bifurcations-double-hopf"
    # scatter graphs
    FIGURE_SCATTER_BIFURCATION_DIAGRAM_FIRST = "figure-scatter-bifurcation-diagram-first"
    FIGURE_SCATTER_BIFURCATION_DIAGRAM_SECOND = "figure-scatter-bifurcation-diagram-second"
    FIGURE_SCATTER_EIGENVALUE_SPECTRUM_ALTERNATIVE = "figure-scatter-eigenvalue-spectrum-alternative"
    FIGURE_SCATTER_EIGENVALUE_SPECTRUM_EMPIRICAL = "figure-scatter-eigenvalue-spectrum-empirical"
    FIGURE_SCATTER_HOPF_PARAMETER_PLOT_L1 = "figure-scatter-hopf-parameter-plot-l1"
    FIGURE_SCATTER_HOPF_PARAMETER_PLOT_NORMALIZATION_ERROR = "figure-scatter-hopf-parameter-plot-normalization-error"
    FIGURE_SCATTER_HOPF_PARAMETER_PLOT_OSCILLATION_FREQUENCY = "figure-scatter-hopf-parameter-plot-oscillation-frequency"
    FIGURE_SCATTER_HOPF_PARAMETER_PLOT_TRANSVERSAL_CROSSING_SPEED = "figure-scatter-hopf-parameter-plot-transversal-crossing-speed"
    FIGURE_SCATTER_TERNARY = "figure-scatter-ternary"
    # heatmap graphs
    FIGURE_HEATMAP_TERNARY = "figure-heatmap-ternary"
    TEXT_HEATMAP_NETWORK_LIST = "text-heatmap-network-list"
    # distribution graphs
    FIGURE_DISTRIBUTION_SD_SR = "figure-distribution-sd-sr"
    FIGURE_DISTRIBUTION_SL_SD = "figure-distribution-sl-sd"
    FIGURE_DISTRIBUTION_SR_SL = "figure-distribution-sr-sl"
    # scatter divs
    DIV_SCATTER_ROW_PLOTS_A = "div-scatter-row-plots-a"
    DIV_SCATTER_ROW_PLOTS_B = "div-scatter-row-plots-b"
    DIV_SCATTER_BIFURCATION_DIAGRAM_FIRST = "div-scatter-bifurcation-diagram-first"
    DIV_SCATTER_BIFURCATION_DIAGRAM_SECOND = "div-scatter-bifurcation-diagram-second"
    DIV_SCATTER_EIGENVALUE_SPECTRUM_ALTERNATIVE = "div-scatter-eigenvalue-spectrum-alternative"
    DIV_SCATTER_EIGENVALUE_SPECTRUM_EMPIRICAL = "div-scatter-eigenvalue-spectrum-empirical"
    DIV_SCATTER_FOUR_PLOTS_ROW = "div-scatter-four-plots-row"
    DIV_SCATTER_HOPF_PARAMETER_PLOT_FREQUENCY = "div-scatter-hopf-parameter-plot-frequency"
    DIV_SCATTER_HOPF_PARAMETER_PLOT_L1 = "div-scatter-hopf-parameter-plot-l1"
    DIV_SCATTER_HOPF_PARAMETER_PLOT_NORMALIZATION_ERROR = "div-scatter-hopf-parameter-plot-normalization-error"
    DIV_SCATTER_HOPF_PARAMETER_PLOT_TRANSVERSAL_CROSSING_SPEED = "div-scatter-hopf-parameter-plot-transversal-crossing-speed"
    DIV_SCATTER_TERNARY = "div-scatter-ternary"
    # heatmap div
    DIV_HEATMAP_TERNARY = "div-heatmap-ternary"
    DIV_HEATMAP_NETWORK_LIST = "div-heatmap-network-list"
    # distribution div
    DIV_DISTRIBUTION_SD_SR = "div-distribution-sd-sr"
    DIV_DISTRIBUTION_SL_SD = "div-distribution-sl-sd"
    DIV_DISTRIBUTION_SR_SL = "div-distribution-sr-sl"
    # other divs
    DIV_MATRIX_01 = "div-matrix-01"
    DIV_MATRIX_02 = "div-matrix-02"
    DIV_MATRIX_03 = "div-matrix-03"
