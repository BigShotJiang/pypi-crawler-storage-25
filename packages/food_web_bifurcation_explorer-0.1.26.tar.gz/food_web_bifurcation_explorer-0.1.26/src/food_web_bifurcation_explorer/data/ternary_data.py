"""Module for managing ternary plot data from bifurcation analysis.

This module contains the TernaryData class which handles loading, storing, and processing
bifurcation analysis data for ternary plots across different branch types, parameter types,
and bifurcation types.
"""

import os
import zipfile

import pandas as pd

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.data.shape_data import ShapeData
from food_web_bifurcation_explorer.enums.numbers.integer_numbers import IntegerNumbers
from food_web_bifurcation_explorer.enums.types.area_types import AreaTypes
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.types.hopf_parameter_types import HopfParameterTypes
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes
from food_web_bifurcation_explorer.enums.types.visual.bifurcation_codimension_one_visual_types import BifurcationCodimensionOneVisualTypes
from food_web_bifurcation_explorer.enums.types.visual.bifurcation_codimension_two_visual_types import BifurcationCodimensionTwoVisualTypes
from food_web_bifurcation_explorer.enums.types.visual.extinctions_visual_types import ExtinctVisualTypes
from food_web_bifurcation_explorer.enums.types.visual.other_visual_types import OtherVisualTypes


class TernaryData:
    """Branch data container for storing and processing bifurcation analysis data."""

    def __init__(self) -> None:
        # declare dictionary for codimension one bifurcation dataframes
        self.codimension_one_bifurcation_dataframes: dict[BranchTypes, dict[ParameterTypes, dict[BifurcationCodimensionOneVisualTypes, dict[int, pd.DataFrame]]]] = {}

        # declare dictionary for termination type dataframes
        self.extinction_dataframes: dict[BranchTypes, dict[ParameterTypes, dict[ExtinctVisualTypes, dict[int, pd.DataFrame]]]] = {}

        # declare dictionary for other type dataframes
        self.other_dataframes: dict[BranchTypes, dict[ParameterTypes, dict[OtherVisualTypes, pd.DataFrame]]] = {}

        # declare dictionary for codimension two bifurcation dataframes
        self.codimension_two_bifurcation_dataframes: dict[BifurcationCodimensionTwoVisualTypes, pd.DataFrame] = {}

        # init dictionaries with empty dataframes
        for branch_type in BranchTypes:
            self.codimension_one_bifurcation_dataframes[branch_type] = {}
            self.extinction_dataframes[branch_type] = {}
            self.other_dataframes[branch_type] = {}
            for parameter_type in ParameterTypes:

                # codimension one bifurcations
                self.codimension_one_bifurcation_dataframes[branch_type][parameter_type] = {}
                for bifurcation_codimension_one_type in BifurcationCodimensionOneVisualTypes:
                    self.codimension_one_bifurcation_dataframes[branch_type][parameter_type][bifurcation_codimension_one_type] = {}
                    for index in range(IntegerNumbers.TRACES_NUM_MAX):
                        self.codimension_one_bifurcation_dataframes[branch_type][parameter_type][bifurcation_codimension_one_type][index] = pd.DataFrame()
                
                # extinct
                self.extinction_dataframes[branch_type][parameter_type] = {}
                for extinct_type in ExtinctVisualTypes:
                    self.extinction_dataframes[branch_type][parameter_type][extinct_type] = {}
                    for index in range(IntegerNumbers.TRACES_NUM_MAX_EXTINCTIONS):
                        self.extinction_dataframes[branch_type][parameter_type][extinct_type][index] = pd.DataFrame()

                # other
                self.other_dataframes[branch_type][parameter_type] = {}
                for other_type in OtherVisualTypes:
                    self.other_dataframes[branch_type][parameter_type][other_type] = pd.DataFrame()

        # init codimension two bifurcations dictionary with empty dataframes
        for bifurcation_codimension_two_visual_types in BifurcationCodimensionTwoVisualTypes:
            self.codimension_two_bifurcation_dataframes[bifurcation_codimension_two_visual_types] = pd.DataFrame()

        # declare shape data
        self.shape_data: ShapeData = ShapeData()

        # declare auxiliar dictionaries using for loading data
        self.codimension_one_temporal_dictionary: dict[BranchTypes, dict[ParameterTypes, dict[BifurcationCodimensionOneVisualTypes, dict[int, list[dict]]]]] = {}
        self.extinctions_temporal_dictionary: dict[BranchTypes, dict[ParameterTypes, dict[ExtinctVisualTypes, dict[int, list[dict]]]]] = {}
        self.other_temporal_dictionary: dict[BranchTypes, dict[ParameterTypes, dict[OtherVisualTypes, list[dict]]]] = {}

    def clear_data(self) -> None:
        """Reset all dataframes"""
        # reset dataframes
        for branch_type in BranchTypes:
            for parameter_type in ParameterTypes:

                # codimension one bifurcations
                for bifurcation_codimension_one_type in BifurcationCodimensionOneVisualTypes:
                    for index in range(IntegerNumbers.TRACES_NUM_MAX):
                        self.codimension_one_bifurcation_dataframes[branch_type][parameter_type][bifurcation_codimension_one_type][index] = pd.DataFrame()

                # extinctions
                for extinction_type in ExtinctVisualTypes:
                    for index in range(IntegerNumbers.TRACES_NUM_MAX_EXTINCTIONS):
                        self.extinction_dataframes[branch_type][parameter_type][extinction_type][index] = pd.DataFrame()

                # termination
                for other_type in OtherVisualTypes:
                    self.other_dataframes[branch_type][parameter_type][other_type] = pd.DataFrame()

        # reset codimension two bifurcation dataframes
        for bifurcation_codimension_two_visual_types in BifurcationCodimensionTwoVisualTypes:
            self.codimension_two_bifurcation_dataframes[bifurcation_codimension_two_visual_types] = pd.DataFrame()

    def get_bifurcation_codimension_one_ternary_values(
        self, 
        branch_type: BranchTypes, 
        bifurcation_codimension_one_type: BifurcationCodimensionOneVisualTypes, 
        index: int
    ) -> tuple[list[int | None], list[int | None], list[int | None]]:
        """Get the list of values for a given branch, parameter, trace type and index."""
        # get dataframe for current branch, parameter, trace type and index
        dataframe: pd.DataFrame = self.codimension_one_bifurcation_dataframes[branch_type][glob.config.fixed_parameter_type][bifurcation_codimension_one_type][index]
        # declare values arrays filled with None
        sd_values: list[int | None] = [None] * IntegerNumbers.MAX_FIXED_PARAMETERS
        sr_values: list[int | None] = [None] * IntegerNumbers.MAX_FIXED_PARAMETERS
        sl_values: list[int | None] = [None] * IntegerNumbers.MAX_FIXED_PARAMETERS
        # check that dataframe isn't empty
        if not dataframe.empty:
            # Populate the arrays using the fixed_value directly as the array index
            for (
                sd_val,
                sr_val,
                sl_val,
                fixed_pos,
            ) in zip(
                # parameters
                dataframe[ParameterTypes.DONOR.value],
                dataframe[ParameterTypes.RECIPIENT.value],
                dataframe[ParameterTypes.LOTKAVOLTERRA.value],
                # index
                dataframe["fixed_value"],
            ):
                # position in the array
                pos = int(fixed_pos)
                # parameters
                sd_values[pos] = sd_val
                sr_values[pos] = sr_val
                sl_values[pos] = sl_val
        # return values
        return (sd_values, sr_values, sl_values)

    def get_two_codimension_bifurcation_ternary_values(
        self,
        bifurcation_codimension_two_type: BifurcationCodimensionTwoVisualTypes
    ) -> tuple[list[float], list[float], list[float]]:
        """Get the list of values for a given branch, parameter, trace type and index."""
        # get dataframe for current branch, parameter, trace type and index
        dataframe: pd.DataFrame = self.codimension_two_bifurcation_dataframes[bifurcation_codimension_two_type]
        # check that dataframe isn't empty
        if not dataframe.empty:
            return (
                dataframe[ParameterTypes.DONOR.value].tolist(),
                dataframe[ParameterTypes.RECIPIENT.value].tolist(),
                dataframe[ParameterTypes.LOTKAVOLTERRA.value].tolist(),
            )
        # return values
        return ([], [], [])

    def get_extinction_ternary_values(
        self, 
        branch_type: BranchTypes, 
        extinction_type: ExtinctVisualTypes, 
        index: int
    ) -> tuple[list[int | None], list[int | None], list[int | None]]:
        """Get the list of values for a given branch, parameter, trace type and index."""
        # get dataframe for current branch, parameter, trace type and index
        dataframe: pd.DataFrame = self.extinction_dataframes[branch_type][glob.config.fixed_parameter_type][extinction_type][index]
        # declare values arrays filled with None
        sd_values: list[int | None] = [None] * IntegerNumbers.MAX_FIXED_PARAMETERS
        sr_values: list[int | None] = [None] * IntegerNumbers.MAX_FIXED_PARAMETERS
        sl_values: list[int | None] = [None] * IntegerNumbers.MAX_FIXED_PARAMETERS
        # check that dataframe isn't empty
        if not dataframe.empty:
            # Populate the arrays using the fixed_value directly as the array index
            for (
                sd_val,
                sr_val,
                sl_val,
                fixed_pos,
            ) in zip(
                # parameters
                dataframe[ParameterTypes.DONOR.value],
                dataframe[ParameterTypes.RECIPIENT.value],
                dataframe[ParameterTypes.LOTKAVOLTERRA.value],
                # index
                dataframe["fixed_value"],
            ):
                # position in the array
                pos = int(fixed_pos)
                # parameters
                sd_values[pos] = sd_val
                sr_values[pos] = sr_val
                sl_values[pos] = sl_val
        # return values
        return (sd_values, sr_values, sl_values)

    def get_other_ternary_values(
        self, 
        branch_type: BranchTypes, 
        other_type: OtherVisualTypes, 
    ) -> tuple[list[float], list[float], list[float]]:
        """Get the list of values for a given branch, parameter, trace type and index."""
        # get dataframe for current branch, parameter, trace type and index
        dataframe: pd.DataFrame = self.other_dataframes[branch_type][glob.config.fixed_parameter_type][other_type]
        # check that dataframe isn't empty
        if dataframe.empty:
            return ([], [], [])
        # return values directly from dataframe
        return (
            dataframe[ParameterTypes.DONOR.value].tolist(),
            dataframe[ParameterTypes.RECIPIENT.value].tolist(),
            dataframe[ParameterTypes.LOTKAVOLTERRA.value].tolist(),
        )

    def get_hopf_parameter_values(
        self,
        hopf_parameter_type: HopfParameterTypes,
        hopf_bifurcation_type: BifurcationCodimensionOneVisualTypes
    ) -> list[int | None]:
        """Get the hopf parameterlist of values for a given branch, parameter, trace type and index."""
        # get dataframe for current branch, parameter, trace type and index
        dataframe = self.codimension_one_bifurcation_dataframes[BranchTypes.EMPIRICAL][glob.config.fixed_parameter_type][hopf_bifurcation_type][1]
        # declare values arrays filled with None
        values: list[int | None] = [None] * IntegerNumbers.MAX_FIXED_PARAMETERS
        # check that dataframe isn't empty
        if not dataframe.empty:
            # Populate the arrays using the fixed_value directly as the array index
            for fixed_pos, value in zip(dataframe["fixed_value"], dataframe[hopf_parameter_type]):
                if value is not None:
                    # position in the array
                    pos = int(fixed_pos)
                    # specific of hopf bifurcations
                    values[pos] = value
        # return values
        return values

    def get_codimension_one_bifurcation_indexes(self, branch_type: BranchTypes, bifurcation_codimension_one_type: BifurcationCodimensionOneVisualTypes) -> list[int]:
        """Get the list of index columns for a given branch, parameter and trace type."""
        # declare empty index list
        indexes: list[int] = []
        # check for every index if the dataframe is not empty, then add to the list of indexes
        for index in range(IntegerNumbers.TRACES_NUM_MAX):
            if not self.codimension_one_bifurcation_dataframes[branch_type][glob.config.fixed_parameter_type][bifurcation_codimension_one_type][index].empty:
                indexes.append(index)
        return indexes

    def get_extinction_indexes(self, branch_type: BranchTypes, extinction_type: ExtinctVisualTypes) -> list[int]:
        """Get the list of index columns for a given branch, parameter and trace type."""
        # declare empty index list
        indexes: list[int] = []
        # check for every index if the dataframe is not empty, then add to the list of indexes
        for index in range(IntegerNumbers.TRACES_NUM_MAX_EXTINCTIONS):
            if not self.extinction_dataframes[branch_type][glob.config.fixed_parameter_type][extinction_type][index].empty:
                indexes.append(index)
        return indexes

    def load_parquet_data(self, ternary_zip_file: zipfile.ZipFile) -> None:
        """Load parquet data from a parquet file stream and set fixed parameter information."""
        # first clear data
        self.clear_data()
        # try to load branch parquet file from zip
        for branch_type in BranchTypes:
            for parameter_type in ParameterTypes:

                # bifuraction codimension one types
                for bifurcation_codimension_one_type in BifurcationCodimensionOneVisualTypes:
                    for index in range(IntegerNumbers.TRACES_NUM_MAX):
                        try:
                            parquet_file = glob.files.get_ternary_parquet_file(branch_type, parameter_type, bifurcation_codimension_one_type, index)
                            with ternary_zip_file.open(parquet_file) as f:
                                self.codimension_one_bifurcation_dataframes[branch_type][parameter_type][bifurcation_codimension_one_type][index] = pd.read_parquet(f)
                        except:
                            pass

                # extinctions types
                for extinct_types in ExtinctVisualTypes:
                    for index in range(IntegerNumbers.TRACES_NUM_MAX_EXTINCTIONS):
                        try:
                            parquet_file = glob.files.get_ternary_parquet_file(branch_type, parameter_type, extinct_types, index)
                            with ternary_zip_file.open(parquet_file) as f:
                                self.extinction_dataframes[branch_type][parameter_type][extinct_types][index] = pd.read_parquet(f)
                        except:
                            pass

                # other types
                for other_visual_types in OtherVisualTypes:
                    try:
                        parquet_file = glob.files.get_ternary_parquet_file(branch_type, parameter_type, other_visual_types, None)
                        with ternary_zip_file.open(parquet_file) as f:
                            self.other_dataframes[branch_type][parameter_type][other_visual_types] = pd.read_parquet(f)
                    except:
                        pass

        # load codimension two files
        for bifurcation_codimension_two_type in BifurcationCodimensionTwoVisualTypes:
            with ternary_zip_file.open(bifurcation_codimension_two_type.value) as f:
                self.codimension_two_bifurcation_dataframes[bifurcation_codimension_two_type] = pd.read_parquet(f)

        # load ternary shape file
        for area_type in AreaTypes:
            parquet_file = glob.files.get_ternary_shape_file(area_type)
            with ternary_zip_file.open(parquet_file) as f:
                self.shape_data.perimeters[area_type] = pd.read_parquet(f)

    def read_continuation_files(self) -> None:
        """Read ternary data from continuation files."""
        # first clear data
        self.clear_data()

        # create temporal dictionaries
        for branch_type in BranchTypes:
            self.codimension_one_temporal_dictionary[branch_type] = {}
            self.extinctions_temporal_dictionary[branch_type] = {}
            self.other_temporal_dictionary[branch_type] = {}
            for parameter_type in ParameterTypes:

                # codimension one
                self.codimension_one_temporal_dictionary[branch_type][parameter_type] = {}
                for bifurcation_codimension_one_type in BifurcationCodimensionOneVisualTypes:
                    self.codimension_one_temporal_dictionary[branch_type][parameter_type][bifurcation_codimension_one_type] = {}
                    for index in range(IntegerNumbers.TRACES_NUM_MAX):
                        self.codimension_one_temporal_dictionary[branch_type][parameter_type][bifurcation_codimension_one_type][index] = []
                
                # termination
                self.extinctions_temporal_dictionary[branch_type][parameter_type] = {}
                for extinction_type in ExtinctVisualTypes:
                    self.extinctions_temporal_dictionary[branch_type][parameter_type][extinction_type] = {}
                    for index in range(IntegerNumbers.TRACES_NUM_MAX_EXTINCTIONS):
                        self.extinctions_temporal_dictionary[branch_type][parameter_type][extinction_type][index] = []
                
                # other
                self.other_temporal_dictionary[branch_type][parameter_type] = {}
                for other_type in OtherVisualTypes:
                    self.other_temporal_dictionary[branch_type][parameter_type][other_type] = []
         
        # now read data for every zip file
        for index, fixed_parameter_value in enumerate(glob.config.fixed_parameter_values_str):
            # show current processed value
            print(fixed_parameter_value)
            # get continuation zip file path
            continuation_zip_file_path = glob.files.get_continuation_zip_file(fixed_parameter_value)
            # check if file exists
            if os.path.exists(continuation_zip_file_path):
                # open continuation zip file
                with zipfile.ZipFile(continuation_zip_file_path, "r") as continuation_zip_file:
                    # open CSV for every parameter and branch type
                    for branch_type in BranchTypes:
                        for parameter_type in ParameterTypes:
                            # parse CSV in temporal dataframe
                            with continuation_zip_file.open(f"bifurcations_{branch_type.value}_{parameter_type.value}_{fixed_parameter_value}.csv") as file:
                                tmp_dataframe = pd.read_csv(file)
                            # read codimension one bifurcations
                            for bifurcation_codimension_one_type in BifurcationCodimensionOneVisualTypes:
                                # filter rows for current bifuraction codimension one type
                                bifurcation_codimension_one_rows = tmp_dataframe[tmp_dataframe["type"] == bifurcation_codimension_one_type.value]
                                # iterate using zip
                                for (
                                    sd_val,
                                    sr_val,
                                    sl_val,
                                    index_val,
                                    l1,
                                    oscillation_frequency,
                                    transversal_crossing_speed,
                                    normalization_error,
                                ) in zip(
                                    # parameters
                                    bifurcation_codimension_one_rows[ParameterTypes.DONOR.value],
                                    bifurcation_codimension_one_rows[ParameterTypes.RECIPIENT.value],
                                    bifurcation_codimension_one_rows[ParameterTypes.LOTKAVOLTERRA.value],
                                    # index
                                    bifurcation_codimension_one_rows["index"],
                                    # hopf bifurcation specific parameters
                                    bifurcation_codimension_one_rows[HopfParameterTypes.L1.value],
                                    bifurcation_codimension_one_rows[HopfParameterTypes.OSCILLATION_FREQUENCY.value],
                                    bifurcation_codimension_one_rows[HopfParameterTypes.TRANSVERSAL_CROSSING_SPEED.value],
                                    bifurcation_codimension_one_rows[HopfParameterTypes.NORMALIZATION_ERROR.value],
                                ):
                                    # get index value as integer
                                    index_value = int(index_val)
                                    # ensure that index value is less than max num of traces, otherwise skip (to avoid out of range errors)
                                    if index_value < IntegerNumbers.TRACES_NUM_MAX:
                                        # declare row to save in temporal frame
                                        row = {
                                            # parameters
                                            ParameterTypes.DONOR.value: sd_val,
                                            ParameterTypes.RECIPIENT.value: sr_val,
                                            ParameterTypes.LOTKAVOLTERRA.value: sl_val,
                                            # index
                                            "fixed_value": index,
                                            # hopf bifurcation specific parameters
                                            HopfParameterTypes.L1.value: l1,
                                            HopfParameterTypes.OSCILLATION_FREQUENCY.value: oscillation_frequency,
                                            HopfParameterTypes.TRANSVERSAL_CROSSING_SPEED.value: transversal_crossing_speed,
                                            HopfParameterTypes.NORMALIZATION_ERROR.value: normalization_error,
                                        }
                                        self.codimension_one_temporal_dictionary[branch_type][parameter_type][bifurcation_codimension_one_type][index_value].append(row)
                            
                            # read terminations
                            for extinction_type in ExtinctVisualTypes:
                                # filter rows for current termination type
                                extinctions_rows = tmp_dataframe[tmp_dataframe["type"] == extinction_type.value]
                                # iterate using zip
                                for (
                                    sd_val,
                                    sr_val,
                                    sl_val,
                                    index_val
                                ) in zip(
                                    # parameters
                                    extinctions_rows[ParameterTypes.DONOR.value],
                                    extinctions_rows[ParameterTypes.RECIPIENT.value],
                                    extinctions_rows[ParameterTypes.LOTKAVOLTERRA.value],
                                    # index
                                    extinctions_rows["index"],
                                ):
                                    # get index value as integer
                                    index_value = int(index_val)
                                    # ensure that index value is less than max num of traces, otherwise skip (to avoid out of range errors)
                                    if index_value < IntegerNumbers.TRACES_NUM_MAX_EXTINCTIONS:
                                        # declare row to save in temporal frame
                                        row = {
                                            # parameters
                                            ParameterTypes.DONOR.value: sd_val,
                                            ParameterTypes.RECIPIENT.value: sr_val,
                                            ParameterTypes.LOTKAVOLTERRA.value: sl_val,
                                            # index
                                            "fixed_value": index,
                                        }
                                        self.extinctions_temporal_dictionary[branch_type][parameter_type][extinction_type][index_value].append(row)

                            # read other
                            for other_type in OtherVisualTypes:
                                # filter rows for current termination type
                                other_rows = tmp_dataframe[tmp_dataframe["type"] == other_type.value]
                                # iterate using zip
                                for (
                                    sd_val,
                                    sr_val,
                                    sl_val,
                                ) in zip(
                                    # parameters
                                    other_rows[ParameterTypes.DONOR.value],
                                    other_rows[ParameterTypes.RECIPIENT.value],
                                    other_rows[ParameterTypes.LOTKAVOLTERRA.value],
                                ):
                                    # declare row to save in temporal frame
                                    row = {
                                        # parameters
                                        ParameterTypes.DONOR.value: sd_val,
                                        ParameterTypes.RECIPIENT.value: sr_val,
                                        ParameterTypes.LOTKAVOLTERRA.value: sl_val,
                                    }
                                    self.other_temporal_dictionary[branch_type][parameter_type][other_type].append(row)
            # load shape data for current fixed parameter value
            self.shape_data.load_shape_data(index, fixed_parameter_value)

        # load codimension two bifurcations
        codimension_two_dataframe: pd.DataFrame = pd.read_csv(os.path.join(glob.files.result_folder, "bifurcations_codimension_two", "bifurcations_codimension_two_" + glob.config.network + ".csv"))
        
        # populate the dictionary by filtering the loaded dataframe
        for bifurcation_codimension_two_type in BifurcationCodimensionTwoVisualTypes:

            # filter the dataframe where the 'type' column matches the enum value
            filtered_df = codimension_two_dataframe[codimension_two_dataframe["type"] == bifurcation_codimension_two_type.value]
            
            # assign the filtered dataframe (using .copy() to prevent SettingWithCopyWarning if modified later)
            self.codimension_two_bifurcation_dataframes[bifurcation_codimension_two_type] = filtered_df.copy()
            
            # optional: reset the index so each dataframe starts from 0
            self.codimension_two_bifurcation_dataframes[bifurcation_codimension_two_type].reset_index(drop=True, inplace=True)

        # update data frames
        for branch_type in BranchTypes:
            for parameter_type in ParameterTypes:

                # fill codimension one dataframes
                for bifurcation_codimension_one_type in BifurcationCodimensionOneVisualTypes:
                    for index_value in range(IntegerNumbers.TRACES_NUM_MAX):
                        # extract list of data
                        data_list = self.codimension_one_temporal_dictionary[branch_type][parameter_type][bifurcation_codimension_one_type][index_value]
                        if data_list:
                            # Create the dataframe for this specific index
                            bifurcation_codimension_one_dataframe = pd.DataFrame(data_list)
                            # Ensure columns are ordered correctly just in case
                            bifurcation_codimension_one_dataframe = bifurcation_codimension_one_dataframe.reindex(
                                columns=[
                                    ParameterTypes.DONOR.value,
                                    ParameterTypes.RECIPIENT.value,
                                    ParameterTypes.LOTKAVOLTERRA.value,
                                    "fixed_value",
                                    HopfParameterTypes.L1.value,
                                    HopfParameterTypes.OSCILLATION_FREQUENCY.value,
                                    HopfParameterTypes.TRANSVERSAL_CROSSING_SPEED.value,
                                    HopfParameterTypes.NORMALIZATION_ERROR.value,
                                ]
                            )
                            # Assign the fully built dataframe to the class attribute
                            self.codimension_one_bifurcation_dataframes[branch_type][parameter_type][bifurcation_codimension_one_type][index_value] = bifurcation_codimension_one_dataframe
                        else:
                            pass

                # fill extinction dataframes
                for extinction_type in ExtinctVisualTypes:
                    for index_value in range(IntegerNumbers.TRACES_NUM_MAX_EXTINCTIONS):
                        # extract list of data
                        data_list = self.extinctions_temporal_dictionary[branch_type][parameter_type][extinction_type][index_value]
                        if data_list:
                            # Create the dataframe for this specific index
                            extinction_dataframe = pd.DataFrame(data_list)
                            # Ensure columns are ordered correctly just in case
                            extinction_dataframe = extinction_dataframe.reindex(
                                columns=[
                                    ParameterTypes.DONOR.value,
                                    ParameterTypes.RECIPIENT.value,
                                    ParameterTypes.LOTKAVOLTERRA.value,
                                    "fixed_value",
                                ]
                            )
                            # Assign the fully built dataframe to the class attribute
                            self.extinction_dataframes[branch_type][parameter_type][extinction_type][index_value] = extinction_dataframe
                        else:
                            pass

                # fill other dataframes
                for other_type in OtherVisualTypes:
                    # extract list of data
                    data_list = self.other_temporal_dictionary[branch_type][parameter_type][other_type]
                    if data_list:
                        # Create the dataframe for this specific index
                        other_dataframe = pd.DataFrame(data_list)
                        # Ensure columns are ordered correctly just in case
                        other_dataframe = other_dataframe.reindex(
                            columns=[
                                ParameterTypes.DONOR.value,
                                ParameterTypes.RECIPIENT.value,
                                ParameterTypes.LOTKAVOLTERRA.value,
                            ]
                        )
                        # Assign the fully built dataframe to the class attribute
                        self.other_dataframes[branch_type][parameter_type][other_type] = other_dataframe
                    else:
                        pass

        # reset auxiliar structures to free memory
        self.codimension_one_temporal_dictionary = {}
        self.extinctions_temporal_dictionary = {}
        self.other_temporal_dictionary = {}

        # process shape data
        self.shape_data.process_shape_data()