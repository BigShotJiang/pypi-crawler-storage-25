import zipfile
from typing import IO

import numpy as np
import pandas as pd

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.common.config import BifurcationDiagramTypes
from food_web_bifurcation_explorer.common.exceptions import ParameterTypeError
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes


class BranchData:
    """Branch data container for storing and processing bifurcation analysis data."""

    def __init__(self, branch_type: BranchTypes, parameter_type: ParameterTypes) -> None:

        # parameter associated with this branch
        self.fixed_parameter_type: ParameterTypes = parameter_type
        self.branch_type: BranchTypes = branch_type
        self.fixed_parameter_value: str | None = None
        self.n: int = 0

        # data frames
        self.branch_dataframe: pd.DataFrame = pd.DataFrame()
        self.bifurcations_dataframe: pd.DataFrame = pd.DataFrame()

        # Processed DataFrames: one column per biomass component
        self.stablenodes_dataframe: pd.DataFrame = pd.DataFrame()
        self.unstablenodes_dataframe: pd.DataFrame = pd.DataFrame()
        self.transition_stabletounstablenodes_dataframe: pd.DataFrame = pd.DataFrame()
        self.transition_unstabletostablenodes_dataframe: pd.DataFrame = pd.DataFrame()

        # transition variables unificadas en una sola lista
        self.transition_indexes: list[int] = []

    def load(self, fixed_parameter_value: str, stream: IO[bytes]) -> None:
        """Load branch data from a parquet file stream and set fixed parameter information."""
        # read parquet files
        self.branch_dataframe = pd.read_parquet(stream)
        self.fixed_parameter_value = fixed_parameter_value
        # process data after loading
        self.process_data()

    def clear_data(self) -> None:
        """Clear all data containers and reset to initial state."""
        self.branch_dataframe = pd.DataFrame()
        self.stablenodes_dataframe = pd.DataFrame()
        self.unstablenodes_dataframe = pd.DataFrame()
        self.transition_stabletounstablenodes_dataframe = pd.DataFrame()
        self.transition_unstabletostablenodes_dataframe = pd.DataFrame()
        self.n = 0
        self.transition_indexes = []

    def get_eigenvalue_spectrum_x(self) -> list:
        idx = glob.config.eigenvalue_spectrum_index[self.branch_type]
        if idx < len(self.branch_dataframe):
            return [self.branch_dataframe.at[idx, "parameter_values"]]
        return []

    def get_eigenvalue_spectrum_y(self) -> list:
        """Get eigenvalue spectrum Y values (first biomass component at current index)."""
        idx = glob.config.eigenvalue_spectrum_index[self.branch_type]
        if idx < len(self.branch_dataframe):
            return [self.branch_dataframe.at[idx, f"b_{glob.config.compartment_index[BifurcationDiagramTypes.FIRST] + 1}"]]
        return []

    def get_eigenvalue_spectrum_values(self) -> tuple[list[float], list[float], float, float]:
        """Get eigenvalue spectrum values including real/imaginary parts and conjugate pairs.

        Returns:
            A tuple containing (sorted by real part descending, then imaginary part ascending):
            - real_parts: List of real parts of all eigenvalues
            - imaginary_parts: List of imaginary parts of all eigenvalues
            - fixed_parameter: Float value of the fixed parameter
            - dynamic_parameter: Float value of the dynamic parameter at current index

        """
        idx = glob.config.eigenvalue_spectrum_index[self.branch_type]

        # ensure that we have elements
        if idx not in self.branch_dataframe.index:
            return ([], [], 0.0, 0.0)

        # get column names
        columns = self.branch_dataframe.columns
        real_column = [c for c in columns if c.startswith("ev_r_")]
        imaginary_column = [c for c in columns if c.startswith("ev_i_")]

        # check that we have elements
        if not real_column or not imaginary_column:
            return ([], [], 0.0, 0.0)

        try:
            # extract data
            real_parts = self.branch_dataframe.loc[idx, :].filter(like="ev_r_").tolist()
            imaginary_parts = self.branch_dataframe.loc[idx, :].filter(like="ev_i_").tolist()

            # extract parameter values
            dynamic_param = float(self.branch_dataframe.at[idx, "parameter_values"])  # type: ignore[arg-type]
            fixed_param = float(self.fixed_parameter_value) if self.fixed_parameter_value is not None else 0.0

        except (KeyError, IndexError, ValueError):
            return ([], [], 0.0, 0.0)

        # combine and sort
        eigenvalues = sorted(zip(real_parts, imaginary_parts), key=lambda x: (-x[0], x[1]))

        # security check
        if not eigenvalues:
            return ([], [], fixed_param, dynamic_param)

        # split sorted list
        sorted_real, sorted_imag = map(list, zip(*eigenvalues))

        # return results
        return (sorted_real, sorted_imag, fixed_param, dynamic_param)

    def read_branch_data(self, continuation_zip_file: zipfile.ZipFile, fixed_parameter_type: ParameterTypes, fixed_parameter_value: str) -> None:
        """Read branch data from a continuation zip file and set fixed parameter information."""
        # first clear data
        self.clear_data()

        # set values
        self.fixed_parameter_type = fixed_parameter_type
        self.fixed_parameter_value = fixed_parameter_value

        # try to read data from zip file, if fail clear data
        try:
            # parse CSVs
            with continuation_zip_file.open(f"{self.branch_type.value}_{self.fixed_parameter_type.value}_{self.fixed_parameter_value}.csv") as file:
                self.branch_dataframe = pd.read_csv(file)
            with continuation_zip_file.open(
                f"bifurcations_{self.branch_type.value}_{self.fixed_parameter_type.value}_{self.fixed_parameter_value}.csv"
            ) as file:
                self.bifurcations_dataframe = pd.read_csv(file)
            # remove unnecesaria parameter columns
            if self.fixed_parameter_type == ParameterTypes.DONOR:
                self.branch_dataframe = self.branch_dataframe.drop(columns=["sd", "sr"])
                self.bifurcations_dataframe = self.bifurcations_dataframe.drop(columns=["sd", "sr"])
                self.branch_dataframe = self.branch_dataframe.rename(columns={"sl": "parameter_values"})
                self.bifurcations_dataframe = self.bifurcations_dataframe.rename(columns={"sl": "parameter_values"})
            elif self.fixed_parameter_type == ParameterTypes.RECIPIENT:
                self.branch_dataframe = self.branch_dataframe.drop(columns=["sr", "sl"])
                self.bifurcations_dataframe = self.bifurcations_dataframe.drop(columns=["sr", "sl"])
                self.branch_dataframe = self.branch_dataframe.rename(columns={"sd": "parameter_values"})
                self.bifurcations_dataframe = self.bifurcations_dataframe.rename(columns={"sd": "parameter_values"})
            elif self.fixed_parameter_type == ParameterTypes.LOTKAVOLTERRA:
                self.branch_dataframe = self.branch_dataframe.drop(columns=["sl", "sd"])
                self.bifurcations_dataframe = self.bifurcations_dataframe.drop(columns=["sl", "sd"])
                self.branch_dataframe = self.branch_dataframe.rename(columns={"sr": "parameter_values"})
                self.bifurcations_dataframe = self.bifurcations_dataframe.rename(columns={"sr": "parameter_values"})
            else:
                raise ParameterTypeError("invalid parameter")
        except Exception:
            self.clear_data()

        # process data after reading (needed to update n)
        self.process_data()

    def process_data(self) -> None:
        """Process loaded data to separate stable/unstable nodes and identify transitions."""
        if self.branch_dataframe.empty:
            return

        # Update n using biomass columns
        biomass_columns = [c for c in self.branch_dataframe.columns if c.startswith("b_")]
        self.n = len(biomass_columns)

        # extract node types and biomass values as numpy arrays for efficient processing
        node_types = self.branch_dataframe["type"].to_numpy()
        biomass_matrix = self.branch_dataframe[biomass_columns].to_numpy()

        # declare mask for stable and unstable nodes
        stable_mask = node_types == 0
        unstable_mask = node_types == 1

        # create stable and unstable biomass matrices using masks, filling non-relevant rows with NaN
        stable_matrix = np.where(stable_mask[:, None], biomass_matrix, np.nan)
        unstable_matrix = np.where(unstable_mask[:, None], biomass_matrix, np.nan)

        # calculate difference between consecutive elements
        stability_diffs = np.diff(node_types)

        # get indexes where transitions occur
        indexes_stable_to_unstable = np.where(stability_diffs == 1)[0]
        indexes_unstable_to_stable = np.where(stability_diffs == -1)[0]

        # save unified indexes
        all_transition_indices = np.where(stability_diffs != 0)[0]
        self.transition_indexes = (all_transition_indices + 1).tolist()

        # prepare arrays for transition dataframes (filled with NaN initially)
        transition_stabletounstable = np.full_like(biomass_matrix, np.nan, dtype=float)
        transition_ustabletostable = np.full_like(biomass_matrix, np.nan, dtype=float)

        # fill transition matrix
        for index in indexes_stable_to_unstable:
            transition_stabletounstable[index] = biomass_matrix[index]
            transition_stabletounstable[index + 1] = biomass_matrix[index + 1]

        for index in indexes_unstable_to_stable:
            transition_ustabletostable[index] = biomass_matrix[index]
            transition_ustabletostable[index + 1] = biomass_matrix[index + 1]

        # save results in dataframes with appropriate column names
        cols = [f"b_{j + 1}" for j in range(self.n)]
        self.stablenodes_dataframe = pd.DataFrame(stable_matrix, columns=cols)
        self.unstablenodes_dataframe = pd.DataFrame(unstable_matrix, columns=cols)
        self.transition_stabletounstablenodes_dataframe = pd.DataFrame(transition_stabletounstable, columns=cols)
        self.transition_unstabletostablenodes_dataframe = pd.DataFrame(transition_ustabletostable, columns=cols)
