from enum import Enum, unique


@unique
class ExtinctVisualTypes(str, Enum):
    """Enumeration for termination types."""

    EXTINCT = "extinction"
