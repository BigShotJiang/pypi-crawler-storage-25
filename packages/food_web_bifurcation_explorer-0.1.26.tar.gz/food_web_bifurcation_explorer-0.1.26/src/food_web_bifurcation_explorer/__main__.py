from food_web_bifurcation_explorer import FoodWebBifurcationExplorer

"""Entry point for the command line (python -m food_web_bifurcation_explorer)"""


def run() -> None:
    FoodWebBifurcationExplorer()


if __name__ == "__main__":
    run()
