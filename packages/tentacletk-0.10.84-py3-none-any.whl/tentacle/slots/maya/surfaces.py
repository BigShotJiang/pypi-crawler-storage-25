# !/usr/bin/python
# coding=utf-8
import mayatk as mtk

# From this package:
from tentacle.slots.maya._slots_maya import SlotsMaya


class SurfacesSlots(SlotsMaya):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.sb = kwargs.get("switchboard")
        self.ui = self.sb.handlers.ui.get("surfaces", header=True)


# --------------------------------------------------------------------------------------------

# module name
# print(__name__)
# --------------------------------------------------------------------------------------------
# Notes
# --------------------------------------------------------------------------------------------
