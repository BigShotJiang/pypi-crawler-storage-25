# !/usr/bin/python
# coding=utf-8
import mayatk as mtk

# From this package:
from tentacle.slots.maya._slots_maya import SlotsMaya


class MeshDisplaySlots(SlotsMaya):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.sb = kwargs.get("switchboard")
        self.ui = self.sb.handlers.ui.get("mesh_display", header=True)


# --------------------------------------------------------------------------------------------

# module name
# print(__name__)
# --------------------------------------------------------------------------------------------
# Notes
# --------------------------------------------------------------------------------------------
