# !/usr/bin/python
# coding=utf-8
import os

import maya.cmds as cmds
import maya.mel as mel
import pythontk as ptk
import mayatk as mtk
from uitk import Signals
from tentacle.slots.maya._slots_maya import SlotsMaya


class SceneSlots(SlotsMaya):
    def __init__(self, switchboard):
        super().__init__(switchboard)

        self.sb = switchboard
        self.ui = self.sb.loaded_ui.scene
        self.submenu = self.sb.loaded_ui.scene_submenu

    def header_init(self, widget):
        """Initialize Header"""
        if not widget.is_initialized:
            widget.menu.add(
                "QPushButton",
                setToolTip="Export scene assets with environment checks and presets.",
                setText="Scene Exporter",
                setObjectName="b002",
            )
            widget.menu.add(
                "QPushButton",
                setText="Quick Export Scene Geo",
                setObjectName="b003",
                setToolTip="Export the scene geometry as FBX to the current maya file's directory.\nThe file name will be the same as the current scene and overwrite the current file if it exists.",
            )
            widget.menu.add(
                "QPushButton",
                setText="Reference Manager",
                setObjectName="b001",
                setToolTip="Open the reference manager.",
            )
            widget.menu.add(
                "QPushButton",
                setText="Hierarchy Manager",
                setObjectName="b004",
                setToolTip="Open the hierarchy manager.",
            )
            widget.menu.add(
                "QPushButton",
                setText="Naming",
                setObjectName="b005",
                setToolTip="Open the naming tool.",
            )
            widget.menu.add(
                "QPushButton",
                setText="Cleanup Unknown",
                setObjectName="b006",
                setToolTip="Fix common scene issues:\n• Remove unknown/legacy nodes/plugins/expressions",
            )
            widget.menu.add(
                "QPushButton",
                setText="Fix OCIO",
                setObjectName="b009",
                setToolTip="Fix Maya Color Management / OCIO config preferences.",
            )
            widget.menu.add(
                "QPushButton",
                setText="Fix Color Spaces",
                setObjectName="b011",
                setToolTip="Fix missing color space errors on file texture nodes.\nAuto-detects sRGB vs Raw based on texture type.",
            )
            widget.menu.add(
                "QPushButton",
                setText="Scene Audit",
                setObjectName="b010",
                setToolTip="Analyze scene for performance issues (poly count, draw calls, textures).",
            )
            widget.menu.add(
                "QPushButton",
                setText="Toggle Command Ports",
                setObjectName="b012",
                setToolTip="Toggle Maya command ports on/off (MEL :7001, Python :7002).\nUsed for external editor connections.",
            )

    @Signals("textChanged", "returnPressed")
    def txt000(self, widget):
        """Workspace Scenes: Filter"""
        self.ui.cmb000.init_slot()

    def cmb000_init(self, widget):
        """Initialize Workspace Scenes"""
        if not widget.is_initialized:
            widget.refresh_on_show = True  # Call this method on show
            cmds.scriptJob(event=["workspaceChanged", self.ui.cmb000.init_slot])

        include = self.ui.txt000.text() or None

        scenes = {
            ptk.format_path(f, "file"): f
            for f in mtk.get_workspace_scenes(
                recursive=True, inc=include, basename_only=True
            )
        }
        widget.add(
            scenes,
            header="Scenes:",
            clear=True,
        )

    def cmb000(self, index, widget):
        """Workspace Scenes"""
        scene = widget.items[index]
        cmds.file(scene, open=True, force=True)

    def cmb002_init(self, widget):
        """Initialize Autosave"""
        # Fetch recent autosave files
        recent_autosaves = mtk.get_recent_autosave(
            filter_time=24, timestamp_format="%H:%M:%S"
        )

        # Prepare dictionary for ComboBox: key is 'path + timestamp', value is 'path'
        autosave_dict = {
            f"{i[1]}  {ptk.format_path(i[0], 'file')}": i[0] for i in recent_autosaves
        }

        # Add items to the ComboBox
        widget.add(
            autosave_dict,
            header="Autosave:",
            clear=True,
        )

    def cmb002(self, index, widget):
        """Autosave"""
        file = widget.items[index]
        cmds.file(file, open=True, force=True)

    def cmb003_init(self, widget):
        """Initialize Import"""
        widget.add(
            [
                "Import File",
                "Import Options",
                "FBX Import Presets",
                "OBJ Import Presets",
            ],
            header="Import",
        )

    def cmb003(self, index, widget):
        """Import"""
        text = widget.items[index]
        if text == "Import File":  # Import
            mel.eval("Import")
        elif text == "Import Options":  # Import options
            mel.eval("ImportOptions")
        elif text == "FBX Import Presets":  # FBX Import Presets
            mel.eval('FBXUICallBack -1 "editImportPresetInNewWindow" "fbx"')
        elif text == "OBJ Import Presets":  # Obj Import Presets
            mel.eval('FBXUICallBack -1 "editImportPresetInNewWindow" "obj"')

    def cmb004_init(self, widget):
        """Initialize Export"""
        items = [
            "Export Selection",
            "Export All",
            "Send to Unreal",
            "Send to Unity",
            "GoZ",
            "Send to 3dsMax: As New Scene",
            "Send to 3dsMax: Update Current",
            "Send to 3dsMax: Add to Current",
            "Export to Offline File",
            "Export Options",
            "FBX Export Presets",
            "OBJ Export Presets",
        ]
        widget.add(items, header="Export")

    def cmb004(self, index, widget):
        """Export"""
        text = widget.items[index]
        if text == "Export Selection":
            mel.eval("ExportSelection")
        elif text == "Export All":
            mel.eval("Export")
        elif text == "Send to Unreal":
            mel.eval("SendToUnrealSelection")
        elif text == "Send to Unity":
            mel.eval("SendToUnitySelection")
        elif text == "GoZ":
            mel.eval(
                'print("GoZ"); source"C:/Users/Public/Pixologic/GoZApps/Maya/GoZBrushFromMaya.mel"; source "C:/Users/Public/Pixologic/GoZApps/Maya/GoZScript.mel";'
            )
        elif text == "Send to 3dsMax: As New Scene":  # Send to 3dsMax: As New Scene
            mel.eval("SendAsNewScene3dsMax")
        elif text == "Send to 3dsMax: Update Current":  # Send to 3dsMax: Update Current
            mel.eval("UpdateCurrentScene3dsMax")
        elif text == "Send to 3dsMax: Add to Current":  # Send to 3dsMax: Add to Current
            mel.eval("AddToCurrentScene3dsMax")
        elif text == "Export to Offline File":  # Export to Offline File
            mel.eval("ExportOfflineFileOptions")
        elif text == "Export Options":  # Export options
            mel.eval("ExportSelectionOptions")
        elif text == "FBX Export Presets":  # FBX Export Presets
            mel.eval('FBXUICallBack -1 "editExportPresetInNewWindow" "fbx"')
        elif text == "OBJ Export Presets":  # Obj Export Presets
            mel.eval('FBXUICallBack -1 "editExportPresetInNewWindow" "obj"')

    def cmb005_init(self, widget):
        """Initialize Recent Files"""
        recent_files = mtk.get_recent_files(slice(0, 20))
        truncated = ptk.truncate(recent_files, 165)
        widget.add(zip(truncated, recent_files), header="Recent Files", clear=True)

    def cmb005(self, index: int, widget):
        """Recent Files"""
        force = not mtk.get_env_info("scene_modified")
        cmds.file(widget.items[index], open=True, force=force, ignoreVersion=True)

    def tb000_init(self, widget):
        """Initialize Set Workspace"""
        if not widget.is_initialized:
            widget.refresh_on_show = True
            widget.setToolTip("Click to set the project directory.")
            widget.option_box.menu.setTitle("Workspace Options")
            widget.option_box.menu.add(
                "QPushButton",
                setObjectName="lbl005",
                setText="Auto Set Workspace",
                setToolTip="Determine the workspace directory by moving up directory levels until a workspace is found.",
            )
            widget.option_box.menu.add(
                "QPushButton",
                setObjectName="lbl004",
                setText="Open Workspace Root",
                setToolTip="Open the project root directory.",
            )

            from uitk.widgets.optionBox.options.recent_values import RecentValuesOption

            self._recent_workspaces = RecentValuesOption(
                wrapped_widget=widget,
                settings_key="workspace_recent_projects",
                max_recent=10,
            )
            widget.option_box.add_option(self._recent_workspaces)

            # Seed from Maya's recent projects (only valid workspaces)
            if not self._recent_workspaces.recent_values:
                for p in mtk.get_recent_projects(slice(0, 10), format="standard"):
                    if os.path.isfile(os.path.join(p, "workspace.mel")):
                        self._recent_workspaces.add_recent_value(p)

            self._recent_workspaces.value_selected.connect(self._open_recent_workspace)

        # Update button text to current workspace name
        workspace_dir = mtk.get_env_info("workspace_dir")
        widget.setText(workspace_dir or "Set Workspace")

    def tb000(self, widget):
        """Set Workspace"""
        mel.eval("SetProject")
        # Record the newly set workspace
        workspace = mtk.get_env_info("workspace")
        if hasattr(self, "_recent_workspaces") and workspace:
            self._recent_workspaces.record(workspace)
        widget.init_slot()

    def _open_recent_workspace(self, path):
        """Open a workspace from the recent list."""
        if not os.path.isfile(os.path.join(str(path), "workspace.mel")):
            self.sb.message_box("Not a valid workspace.")
            return
        cmds.workspace(path, openWorkspace=True)
        workspace_name = os.path.basename(path)
        self.sb.message_box(f"Workspace set to {workspace_name}.")
        self.ui.tb000.init_slot()

    def list000_init(self, widget):
        """Initialize Recent Files"""
        widget.fixed_item_height = 18
        widget.apply_preset("expand_up")
        recent_files = mtk.get_recent_files(slice(0, 11))
        w1 = widget.add("Recent Files")
        truncated = ptk.truncate(recent_files, 65)
        w1.sublist.add(zip(truncated, recent_files))
        widget.setVisible(bool(recent_files))

    @Signals("on_item_interacted")
    def list000(self, item):
        """Recent Files"""
        data = item.item_data()
        cmds.file(data, open=True, force=True)

    def lbl004(self):
        """Open current project root"""
        dir_ = cmds.workspace(q=True, rd=1)  # current project path.
        os.startfile(ptk.format_path(dir_))

    def lbl005(self):
        """Auto Set Workspace"""
        workspace = mtk.find_workspace_using_path()
        if workspace:
            cmds.workspace(workspace, openWorkspace=True)
            workspace_name = os.path.basename(workspace)
            self.sb.message_box(f"Workspace set to {workspace_name}.")
            self.ui.tb000.init_slot()
        else:
            self.sb.message_box("No workspace found.")

    def b000(self):
        """Autosave: Open Directory"""
        autosave_dir = os.environ.get("MAYA_AUTOSAVE_FOLDER", "")
        if not autosave_dir:
            return
        dirs = autosave_dir.split(";")[0]

        try:
            os.startfile(ptk.format_path(dirs))

        except FileNotFoundError:
            self.sb.message_box("The system cannot find the file specified.")

    def b001(self):
        """Open Reference Manager"""
        self.sb.handlers.marking_menu.show("reference_manager")

    def b002(self):
        """Scene Exporter"""
        self.sb.handlers.marking_menu.show("scene_exporter")

    def b003(self):
        """Quick Export Scene Geo"""
        mtk.export_scene_as_fbx()

    def b004(self):
        """Open Hierarchy Manager"""
        self.sb.handlers.marking_menu.show("hierarchy_manager")

    def b005(self):
        """Open Naming Tool"""
        self.sb.handlers.marking_menu.show("naming")

    def b006(self):
        """Scene Cleanup"""
        mtk.Diagnostics.cleanup_scene()

    def b009(self):
        """Fix OCIO"""
        mtk.Diagnostics.fix_ocio()

    def b010(self):
        """Scene Audit"""
        mtk.SceneAnalyzer.run_audit(adaptive=True)

    def b011(self):
        """Fix Color Spaces"""
        mtk.Diagnostics.fix_missing_color_spaces(force_update=True)

    def b012(self):
        """Toggle Command Ports"""
        is_open, ports = mtk.MayaConnection.toggle_command_ports()
        port_lines = "".join(
            f"<br> \u2022 {port} ({src})" for port, src in ports.items()
        )
        state = "OPENED" if is_open else "CLOSED"
        self.sb.message_box(
            f"Command Ports <hl>{state}</hl>{port_lines}",
            timeout=4,
        )
        # Mirror to console
        console_lines = ", ".join(f"{p} ({s})" for p, s in ports.items())
        print(f"Command Ports {state}: {console_lines}")

    def b007(self):
        """Import file"""
        self.ui.cmb003.call_slot(0)

    def b008(self):
        """Export Selection"""
        self.ui.cmb004.call_slot(0)

    def b015(self):
        """Remove String From Object Names."""
        # asterisk denotes startswith*, *endswith, *contains*
        from_ = str(self.ui.t000.text())
        to = str(self.ui.t001.text())
        replace = self.ui.chk004.isChecked()
        selected = self.ui.chk005.isChecked()

        objects = cmds.ls(from_) or []  # Stores a list of all objects starting with 'from_'
        if selected:  # get user selected objects instead
            objects = cmds.ls(sl=True) or []
        from_ = from_.strip("*")  # strip modifier asterisk from user input

        for obj in objects:  # Get a list of it's direct parent
            relatives = cmds.listRelatives(obj, parent=1) or []
            # If that parent starts with group, it came in root level and is pasted in a group, so ungroup it
            if relatives and "group" in relatives[0]:
                cmds.ungroup(relatives[0])

            newName = to
            if replace:
                newName = obj.replace(from_, to)
            cmds.rename(obj, newName)  # Rename the object with the new name


# --------------------------------------------------------------------------------------------

# module name
# print(__name__)
# --------------------------------------------------------------------------------------------
# Notes
# --------------------------------------------------------------------------------------------
