"""
Build status command for the PyLocket CLI.

    pylocket status --build <BUILD_ID>
    pylocket status --app <APP_ID> --latest
"""
from __future__ import annotations

import asyncio
import functools
import json as json_mod
import sys
from typing import Any, Callable, Optional

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from cli.client import AuthenticationError, PyLocketAPIError, PyLocketClient
from cli.config import resolve_api_url

console = Console()
err_console = Console(stderr=True)


def _async(fn: Callable[..., Any]) -> Callable[..., Any]:
    @functools.wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        return asyncio.run(fn(*args, **kwargs))
    return wrapper


def _handle_error(exc: Exception, api_url: str) -> None:
    if isinstance(exc, AuthenticationError):
        err_console.print(
            Panel(
                "[red]You are not authenticated.[/red]\n"
                "Run [bold cyan]pylocket login[/bold cyan] first.",
                title="[bold red]Authentication Required[/bold red]",
                border_style="red",
            )
        )
        sys.exit(1)
    elif isinstance(exc, PyLocketAPIError):
        err_console.print(
            Panel(
                f"[red]{exc.message}[/red]",
                title=f"[bold red]API Error ({exc.status_code})[/bold red]",
                border_style="red",
            )
        )
        sys.exit(1)
    else:
        err_console.print(
            Panel(
                f"[red]Could not connect to {api_url}:[/red]\n{exc}",
                title="[bold red]Connection Error[/bold red]",
                border_style="red",
            )
        )
        sys.exit(1)


def _format_size(n: int | None) -> str:
    if n is None:
        return "-"
    for unit in ("B", "KB", "MB", "GB"):
        if abs(n) < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024  # type: ignore[assignment]
    return f"{n:.1f} TB"


def _format_datetime(dt_str: str | None) -> str:
    if not dt_str:
        return "-"
    # ISO timestamps: keep date + time, drop microseconds + tz
    if "T" in dt_str:
        return dt_str.split(".")[0].replace("T", " ")
    return dt_str


# ---------------------------------------------------------------------------
# pylocket status
# ---------------------------------------------------------------------------
@click.command()
@click.option("--build", "build_id", default=None, help="Build UUID to inspect.")
@click.option("--app", "app_id", default=None, help="App ID (used with --latest).")
@click.option("--latest", is_flag=True, default=False, help="Show the most recent build for the app.")
@click.option("--format", "output_format", default="table",
              type=click.Choice(["table", "json"], case_sensitive=False),
              help="Output format.")
@click.pass_context
@_async
async def status(ctx: click.Context, build_id: Optional[str], app_id: Optional[str],
                 latest: bool, output_format: str) -> None:
    """Show the status and details of a protection build."""
    if not build_id and not (app_id and latest):
        raise click.UsageError("Provide --build <BUILD_ID> or --app <APP_ID> --latest")

    api_url = resolve_api_url(ctx.obj.get("api_url") if ctx.obj else None)
    token = ctx.obj.get("token") if ctx.obj else None

    try:
        async with PyLocketClient(api_url=api_url, token=token) as client:
            with console.status(
                "[bold cyan]Fetching build status...[/bold cyan]", spinner="dots"
            ):
                if build_id:
                    build = await client.get_build(build_id, app_id=app_id)
                else:
                    build = await client.get_latest_build(app_id)  # type: ignore[arg-type]
    except Exception as exc:
        _handle_error(exc, api_url)
        return

    if output_format == "json":
        console.print_json(json_mod.dumps(build, indent=2, default=str))
        return

    # Determine status styling
    build_status = build.get("status", "unknown")
    status_styles = {
        "pending": ("yellow", "PENDING"),
        "processing": ("cyan", "PROCESSING"),
        "completed": ("green", "COMPLETED"),
        "failed": ("red", "FAILED"),
    }
    color, label = status_styles.get(build_status, ("white", build_status.upper()))

    # Build detail table
    table = Table(
        show_header=False,
        border_style=color,
        title=f"Build Status: [{color}]{label}[/{color}]",
        title_style=f"bold {color}",
        show_lines=True,
        min_width=50,
    )
    table.add_column("Field", style="bold white", min_width=18)
    table.add_column("Value", style="white")

    table.add_row("Build ID", str(build.get("id", "-")))
    table.add_row("App ID", str(build.get("app_id", "-")))
    table.add_row("Version", build.get("version", "-"))
    table.add_row("Status", Text(label, style=f"bold {color}"))
    table.add_row("File Size", _format_size(build.get("file_size_bytes")))
    table.add_row("SHA-256", build.get("file_hash_sha256", "-") or "-")
    table.add_row("Created", _format_datetime(build.get("created_at")))
    table.add_row("Completed", _format_datetime(build.get("completed_at")))

    # Error message (only for failed builds)
    error_msg = build.get("error_message")
    if error_msg:
        table.add_row("Error", Text(error_msg, style="red"))

    console.print()
    console.print(table)
    console.print()

    # Actionable hints
    if build_status == "completed":
        console.print(
            f"  [dim]Download with:[/dim] "
            f"[cyan]pylocket fetch --build {build_id} --out ./protected/[/cyan]"
        )
    elif build_status in ("pending", "processing"):
        console.print(
            f"  [dim]Build is still in progress. Check again shortly.[/dim]"
        )
    elif build_status == "failed":
        console.print(
            f"  [dim]Re-submit with:[/dim] "
            f"[cyan]pylocket protect --app {build.get('app_id', '<APP_ID>')} "
            f"--artifact <PATH>[/cyan]"
        )
    console.print()
