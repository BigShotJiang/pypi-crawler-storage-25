"""
Application management commands for the PyLocket CLI.

    pylocket apps list                  -- list all apps
    pylocket apps create --name NAME    -- create a new app
    pylocket apps update --app ID       -- update an app
    pylocket apps delete --app ID       -- delete an app
"""
from __future__ import annotations

import asyncio
import functools
import sys
from typing import Any, Callable, Optional

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from cli.client import AuthenticationError, PyLocketAPIError, PyLocketClient
from cli.config import resolve_api_url

console = Console()
err_console = Console(stderr=True)


def _async(fn: Callable[..., Any]) -> Callable[..., Any]:
    @functools.wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        return asyncio.run(fn(*args, **kwargs))
    return wrapper


def _handle_error(exc: Exception, api_url: str) -> None:
    """Centralised error handler for command exceptions."""
    if isinstance(exc, AuthenticationError):
        err_console.print(
            Panel(
                "[red]You are not authenticated.[/red]\n"
                "Run [bold cyan]pylocket login[/bold cyan] first.",
                title="[bold red]Authentication Required[/bold red]",
                border_style="red",
            )
        )
        sys.exit(1)
    elif isinstance(exc, PyLocketAPIError):
        err_console.print(
            Panel(
                f"[red]{exc.message}[/red]",
                title=f"[bold red]API Error ({exc.status_code})[/bold red]",
                border_style="red",
            )
        )
        sys.exit(1)
    else:
        err_console.print(
            Panel(
                f"[red]Could not connect to {api_url}:[/red]\n{exc}",
                title="[bold red]Connection Error[/bold red]",
                border_style="red",
            )
        )
        sys.exit(1)


# ---------------------------------------------------------------------------
# Group
# ---------------------------------------------------------------------------
@click.group(name="apps")
@click.pass_context
def apps(ctx: click.Context) -> None:
    """Manage your PyLocket applications."""
    ctx.ensure_object(dict)


# ---------------------------------------------------------------------------
# pylocket apps list
# ---------------------------------------------------------------------------
@apps.command(name="list")
@click.option("--page", default=1, type=int, help="Page number.")
@click.option("--page-size", default=20, type=int, help="Items per page.")
@click.pass_context
@_async
async def list_apps(ctx: click.Context, page: int, page_size: int) -> None:
    """List all applications belonging to your account."""
    api_url = resolve_api_url(ctx.obj.get("api_url"))
    token = ctx.obj.get("token")

    try:
        async with PyLocketClient(api_url=api_url, token=token) as client:
            result = await client.list_apps(page=page, page_size=page_size)
    except Exception as exc:
        _handle_error(exc, api_url)
        return  # unreachable, _handle_error calls sys.exit

    data = result.get("data", [])
    meta = result.get("meta", {})

    if not data:
        console.print()
        console.print(
            Panel(
                "[yellow]No applications found.[/yellow]\n"
                "Create one with [bold cyan]pylocket apps create --name <NAME>[/bold cyan]",
                title="[bold yellow]Apps[/bold yellow]",
                border_style="yellow",
            )
        )
        return

    # Build Rich table
    table = Table(
        title="Your Applications",
        title_style="bold cyan",
        border_style="cyan",
        show_lines=True,
    )
    table.add_column("ID", style="dim", no_wrap=True)
    table.add_column("Name", style="bold white")
    table.add_column("Platform", style="magenta")
    table.add_column("Status", justify="center")
    table.add_column("Created", style="dim")

    status_colors = {
        "active": "green",
        "archived": "yellow",
        "suspended": "red",
    }

    for app in data:
        status_val = app.get("status", "unknown")
        color = status_colors.get(status_val, "white")
        status_text = Text(status_val.upper(), style=f"bold {color}")

        created = app.get("created_at", "")
        if isinstance(created, str) and "T" in created:
            created = created.split("T")[0]

        table.add_row(
            str(app.get("id", "")),
            app.get("name", ""),
            app.get("platform", ""),
            status_text,
            created,
        )

    console.print()
    console.print(table)

    # Pagination footer
    total = meta.get("total", len(data))
    total_pages = meta.get("total_pages", 1)
    current_page = meta.get("page", page)
    console.print(
        f"  [dim]Page {current_page}/{total_pages}  |  {total} total app(s)[/dim]"
    )
    console.print()


# ---------------------------------------------------------------------------
# pylocket apps create
# ---------------------------------------------------------------------------
@apps.command(name="create")
@click.option("--name", "-n", required=True, help="Application name.")
@click.option(
    "--platform",
    "-p",
    default="python",
    show_default=True,
    help="Target platform.",
)
@click.option("--description", "-d", default=None, help="Application description.")
@click.pass_context
@_async
async def create_app(
    ctx: click.Context,
    name: str,
    platform: str,
    description: Optional[str],
) -> None:
    """Create a new PyLocket application."""
    api_url = resolve_api_url(ctx.obj.get("api_url"))
    token = ctx.obj.get("token")

    with console.status("[bold cyan]Creating application...[/bold cyan]", spinner="dots"):
        try:
            async with PyLocketClient(api_url=api_url, token=token) as client:
                result = await client.create_app(
                    name=name,
                    platform=platform,
                    description=description,
                )
        except Exception as exc:
            _handle_error(exc, api_url)
            return

    app_id = result.get("id", "unknown")
    console.print()
    console.print(
        Panel(
            f"[green]Application created successfully![/green]\n\n"
            f"  [bold]Name:[/bold]     {result.get('name', name)}\n"
            f"  [bold]ID:[/bold]       [cyan]{app_id}[/cyan]\n"
            f"  [bold]Platform:[/bold] {result.get('platform', platform)}\n"
            f"  [bold]Status:[/bold]   {result.get('status', 'active')}\n\n"
            f"[dim]Use this ID with:[/dim]\n"
            f"  pylocket protect --app {app_id} --artifact <PATH>",
            title="[bold green]App Created[/bold green]",
            border_style="green",
        )
    )


# ---------------------------------------------------------------------------
# pylocket apps update
# ---------------------------------------------------------------------------
@apps.command(name="update")
@click.option("--app", "app_id", required=True, help="Application ID.")
@click.option("--name", "-n", default=None, help="New display name.")
@click.option("--platform", "-p", default=None, help="Replace platform list.")
@click.option("--offline-grace-hours", default=None, type=int, help="Offline grace period in hours.")
@click.pass_context
@_async
async def update_app(
    ctx: click.Context,
    app_id: str,
    name: Optional[str],
    platform: Optional[str],
    offline_grace_hours: Optional[int],
) -> None:
    """Update an existing application."""
    api_url = resolve_api_url(ctx.obj.get("api_url"))
    token = ctx.obj.get("token")

    if name is None and platform is None and offline_grace_hours is None:
        err_console.print("[yellow]No updates specified. Use --name, --platform, or --offline-grace-hours.[/yellow]")
        return

    try:
        async with PyLocketClient(api_url=api_url, token=token) as client:
            result = await client.update_app(
                app_id, name=name, platform=platform,
                offline_grace_hours=offline_grace_hours,
            )
    except Exception as exc:
        _handle_error(exc, api_url)
        return

    console.print()
    console.print(
        Panel(
            f"[green]Application updated![/green]\n\n"
            f"  [bold]ID:[/bold]       [cyan]{app_id}[/cyan]\n"
            f"  [bold]Name:[/bold]     {result.get('name', '-')}",
            title="[bold green]App Updated[/bold green]",
            border_style="green",
        )
    )


# ---------------------------------------------------------------------------
# pylocket apps delete
# ---------------------------------------------------------------------------
@apps.command(name="delete")
@click.option("--app", "app_id", required=True, help="Application ID.")
@click.confirmation_option(prompt="This will revoke all licenses and remove all builds. Continue?")
@click.pass_context
@_async
async def delete_app(ctx: click.Context, app_id: str) -> None:
    """Delete an application and all associated data."""
    api_url = resolve_api_url(ctx.obj.get("api_url"))
    token = ctx.obj.get("token")

    try:
        async with PyLocketClient(api_url=api_url, token=token) as client:
            await client.delete_app(app_id)
    except Exception as exc:
        _handle_error(exc, api_url)
        return

    console.print(f"[green]Application [bold]{app_id}[/bold] has been deleted.[/green]")
