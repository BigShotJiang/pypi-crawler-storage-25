"""
License management commands for the PyLocket CLI.

    pylocket licenses list --app <APP_ID>
    pylocket licenses create --app <APP_ID> [--email EMAIL] [--device-limit N] [--expires DATE] [--type TYPE]
    pylocket licenses get --license <LICENSE_KEY>
    pylocket licenses revoke --license <LICENSE_KEY>
    pylocket licenses reset-devices --license <LICENSE_KEY>
    pylocket licenses extend --license <LICENSE_KEY> --expires <DATE>
"""
from __future__ import annotations

import asyncio
import functools
import json as json_mod
import sys
from typing import Any, Callable, Optional

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from cli.client import AuthenticationError, PyLocketAPIError, PyLocketClient
from cli.config import resolve_api_url

console = Console()
err_console = Console(stderr=True)


def _async(fn: Callable[..., Any]) -> Callable[..., Any]:
    @functools.wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        return asyncio.run(fn(*args, **kwargs))
    return wrapper


def _handle_error(exc: Exception, api_url: str) -> None:
    if isinstance(exc, AuthenticationError):
        err_console.print(
            Panel(
                "[red]You are not authenticated.[/red]\n"
                "Run [bold cyan]pylocket login[/bold cyan] first.",
                title="[bold red]Authentication Required[/bold red]",
                border_style="red",
            )
        )
        sys.exit(1)
    elif isinstance(exc, PyLocketAPIError):
        err_console.print(
            Panel(
                f"[red]{exc.message}[/red]",
                title=f"[bold red]API Error ({exc.status_code})[/bold red]",
                border_style="red",
            )
        )
        sys.exit(1)
    else:
        err_console.print(
            Panel(
                f"[red]Could not connect to {api_url}:[/red]\n{exc}",
                title="[bold red]Connection Error[/bold red]",
                border_style="red",
            )
        )
        sys.exit(1)


# ---------------------------------------------------------------------------
# Group
# ---------------------------------------------------------------------------
@click.group(name="licenses")
@click.pass_context
def licenses(ctx: click.Context) -> None:
    """Manage end-user licenses."""
    ctx.ensure_object(dict)


# ---------------------------------------------------------------------------
# pylocket licenses list
# ---------------------------------------------------------------------------
@licenses.command(name="list")
@click.option("--app", "app_id", required=True, help="Application ID.")
@click.option("--status", "filter_status", default=None,
              type=click.Choice(["active", "revoked", "expired", "demo"], case_sensitive=False),
              help="Filter by status.")
@click.option("--format", "output_format", default="table",
              type=click.Choice(["table", "json"], case_sensitive=False),
              help="Output format.")
@click.pass_context
@_async
async def list_licenses(ctx: click.Context, app_id: str, filter_status: Optional[str], output_format: str) -> None:
    """List licenses for an application."""
    api_url = resolve_api_url(ctx.obj.get("api_url"))
    token = ctx.obj.get("token")

    try:
        async with PyLocketClient(api_url=api_url, token=token) as client:
            result = await client.list_licenses(app_id, status=filter_status)
    except Exception as exc:
        _handle_error(exc, api_url)
        return

    data = result.get("data", result.get("items", []))

    if output_format == "json":
        console.print_json(json_mod.dumps(data, indent=2, default=str))
        return

    if not data:
        console.print(Panel("[yellow]No licenses found.[/yellow]", border_style="yellow"))
        return

    table = Table(title="Licenses", title_style="bold cyan", border_style="cyan", show_lines=True)
    table.add_column("License Key", style="bold white", no_wrap=True)
    table.add_column("Email", style="dim")
    table.add_column("Status", justify="center")
    table.add_column("Devices", justify="center")
    table.add_column("Expires", style="dim")

    status_colors = {"active": "green", "revoked": "red", "expired": "yellow", "demo": "magenta"}

    for lic in data:
        s = lic.get("status", "unknown")
        color = status_colors.get(s, "white")
        expires = lic.get("expires_at", "-") or "-"
        if isinstance(expires, str) and "T" in expires:
            expires = expires.split("T")[0]
        devices = f"{lic.get('activations', 0)}/{lic.get('device_limit', '-')}"
        table.add_row(
            lic.get("license_key", lic.get("key", "-")),
            lic.get("email", "-"),
            Text(s.upper(), style=f"bold {color}"),
            devices,
            expires,
        )

    console.print()
    console.print(table)
    console.print()


# ---------------------------------------------------------------------------
# pylocket licenses create
# ---------------------------------------------------------------------------
@licenses.command(name="create")
@click.option("--app", "app_id", required=True, help="Application ID.")
@click.option("--email", default=None, help="End-user email.")
@click.option("--device-limit", default=2, type=int, show_default=True, help="Max devices.")
@click.option("--expires", default=None, help="Expiration date (YYYY-MM-DD).")
@click.option("--type", "license_type", default="standard",
              type=click.Choice(["standard", "demo"], case_sensitive=False),
              show_default=True, help="License type.")
@click.pass_context
@_async
async def create_license(ctx: click.Context, app_id: str, email: Optional[str],
                         device_limit: int, expires: Optional[str], license_type: str) -> None:
    """Create a new license key."""
    api_url = resolve_api_url(ctx.obj.get("api_url"))
    token = ctx.obj.get("token")

    try:
        async with PyLocketClient(api_url=api_url, token=token) as client:
            result = await client.create_license(
                app_id, email=email, device_limit=device_limit,
                expires=expires, license_type=license_type,
            )
    except Exception as exc:
        _handle_error(exc, api_url)
        return

    key = result.get("license_key", result.get("key", "unknown"))
    console.print()
    console.print(
        Panel(
            f"[green]License created![/green]\n\n"
            f"  [bold]Key:[/bold]          [cyan]{key}[/cyan]\n"
            f"  [bold]Type:[/bold]         {license_type}\n"
            f"  [bold]Device Limit:[/bold] {device_limit}\n"
            f"  [bold]Expires:[/bold]      {expires or 'Never'}",
            title="[bold green]License Created[/bold green]",
            border_style="green",
        )
    )


# ---------------------------------------------------------------------------
# pylocket licenses get
# ---------------------------------------------------------------------------
@licenses.command(name="get")
@click.option("--license", "license_key", required=True, help="License key.")
@click.pass_context
@_async
async def get_license(ctx: click.Context, license_key: str) -> None:
    """Get details for a specific license."""
    api_url = resolve_api_url(ctx.obj.get("api_url"))
    token = ctx.obj.get("token")

    try:
        async with PyLocketClient(api_url=api_url, token=token) as client:
            result = await client.get_license(license_key)
    except Exception as exc:
        _handle_error(exc, api_url)
        return

    console.print()
    console.print_json(json_mod.dumps(result, indent=2, default=str))
    console.print()


# ---------------------------------------------------------------------------
# pylocket licenses revoke
# ---------------------------------------------------------------------------
@licenses.command(name="revoke")
@click.option("--license", "license_key", required=True, help="License key to revoke.")
@click.pass_context
@_async
async def revoke_license(ctx: click.Context, license_key: str) -> None:
    """Revoke a license."""
    api_url = resolve_api_url(ctx.obj.get("api_url"))
    token = ctx.obj.get("token")

    try:
        async with PyLocketClient(api_url=api_url, token=token) as client:
            await client.revoke_license(license_key)
    except Exception as exc:
        _handle_error(exc, api_url)
        return

    console.print(f"[green]License [bold]{license_key}[/bold] has been revoked.[/green]")


# ---------------------------------------------------------------------------
# pylocket licenses reset-devices
# ---------------------------------------------------------------------------
@licenses.command(name="reset-devices")
@click.option("--license", "license_key", required=True, help="License key.")
@click.pass_context
@_async
async def reset_devices(ctx: click.Context, license_key: str) -> None:
    """Clear all device activations for a license."""
    api_url = resolve_api_url(ctx.obj.get("api_url"))
    token = ctx.obj.get("token")

    try:
        async with PyLocketClient(api_url=api_url, token=token) as client:
            await client.reset_license_devices(license_key)
    except Exception as exc:
        _handle_error(exc, api_url)
        return

    console.print(f"[green]Device activations for [bold]{license_key}[/bold] have been reset.[/green]")


# ---------------------------------------------------------------------------
# pylocket licenses extend
# ---------------------------------------------------------------------------
@licenses.command(name="extend")
@click.option("--license", "license_key", required=True, help="License key.")
@click.option("--expires", required=True, help="New expiration date (YYYY-MM-DD).")
@click.pass_context
@_async
async def extend_license(ctx: click.Context, license_key: str, expires: str) -> None:
    """Extend a license expiration date."""
    api_url = resolve_api_url(ctx.obj.get("api_url"))
    token = ctx.obj.get("token")

    try:
        async with PyLocketClient(api_url=api_url, token=token) as client:
            await client.extend_license(license_key, expires)
    except Exception as exc:
        _handle_error(exc, api_url)
        return

    console.print(f"[green]License [bold]{license_key}[/bold] extended to [bold]{expires}[/bold].[/green]")
