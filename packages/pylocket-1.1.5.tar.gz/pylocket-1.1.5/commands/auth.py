"""
Authentication commands for the PyLocket CLI.

    pylocket login                     -- interactive email/password login
    pylocket auth api-keys rotate      -- rotate API key
    pylocket auth 2fa setup            -- start 2FA setup
    pylocket auth 2fa confirm --code X -- confirm 2FA
    pylocket auth 2fa status           -- check 2FA status
    pylocket auth 2fa disable --code X -- disable 2FA
"""
from __future__ import annotations

import asyncio
import functools
import sys
from typing import Any, Callable

import click
from rich.console import Console
from rich.panel import Panel

from cli.client import AuthenticationError, PyLocketClient, PyLocketAPIError
from cli.config import (
    load_credentials,
    resolve_api_url,
    save_credentials,
    update_tokens,
)

console = Console()
err_console = Console(stderr=True)


def _async(fn: Callable[..., Any]) -> Callable[..., Any]:
    @functools.wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        return asyncio.run(fn(*args, **kwargs))
    return wrapper


def _handle_error(exc: Exception, api_url: str) -> None:
    if isinstance(exc, AuthenticationError):
        err_console.print(
            Panel(
                "[red]You are not authenticated.[/red]\n"
                "Run [bold cyan]pylocket login[/bold cyan] first.",
                title="[bold red]Authentication Required[/bold red]",
                border_style="red",
            )
        )
        sys.exit(1)
    elif isinstance(exc, PyLocketAPIError):
        err_console.print(
            Panel(
                f"[red]{exc.message}[/red]",
                title=f"[bold red]API Error ({exc.status_code})[/bold red]",
                border_style="red",
            )
        )
        sys.exit(1)
    else:
        err_console.print(
            Panel(
                f"[red]Could not connect to {api_url}:[/red]\n{exc}",
                title="[bold red]Connection Error[/bold red]",
                border_style="red",
            )
        )
        sys.exit(1)


# ---------------------------------------------------------------------------
# pylocket login (standalone command, registered directly on the root group)
# ---------------------------------------------------------------------------
@click.command()
@click.option("--email", "-e", default=None, help="Account email address.")
@click.option("--password", "-p", default=None, help="Account password (will prompt if omitted).")
@click.option("--token", default=None, help="Authenticate directly with an API token (skips interactive login).")
@click.pass_context
@_async
async def login(ctx: click.Context, email: str | None, password: str | None, token: str | None) -> None:
    """Authenticate with the PyLocket platform.

    Stores an access token and refresh token in ~/.pylocket/credentials
    so subsequent commands do not require re-authentication.
    """
    api_url = resolve_api_url(ctx.obj.get("api_url") if ctx.obj else None)

    # Token-based login (for CI/CD)
    if token:
        creds = update_tokens(
            access_token=token,
            refresh_token="",
            expires_in=86400,
            api_url=api_url,
        )
        console.print(
            Panel(
                "[green]Authenticated with API token.[/green]\n"
                f"[dim]Credentials stored in ~/.pylocket/credentials[/dim]",
                title="[bold green]Logged In[/bold green]",
                border_style="green",
            )
        )
        return

    console.print()
    console.print(
        Panel(
            "[bold cyan]PyLocket Login[/bold cyan]\n"
            f"API: [dim]{api_url}[/dim]",
            border_style="cyan",
        )
    )
    console.print()

    if not email:
        email = click.prompt(click.style("  Email", fg="cyan"), type=str)
    if not password:
        password = click.prompt(click.style("  Password", fg="cyan"), hide_input=True, type=str)

    console.print()

    with console.status("[bold cyan]Authenticating...[/bold cyan]", spinner="dots"):
        try:
            async with PyLocketClient(api_url=api_url) as client:
                data = await client.login(email, password)
        except (AuthenticationError, PyLocketAPIError, Exception) as exc:
            _handle_error(exc, api_url)
            return

    # Handle 2FA challenge
    if data.get("mfa_required"):
        mfa_token = data["mfa_token"]
        code = click.prompt(click.style("  2FA Code", fg="cyan"), type=str)
        with console.status("[bold cyan]Verifying 2FA...[/bold cyan]", spinner="dots"):
            try:
                async with PyLocketClient(api_url=api_url) as client:
                    data = await client._raw_request(
                        "POST", "/v1/auth/login/verify-2fa",
                        json={"mfa_token": mfa_token, "code": code},
                        _skip_auth=True,
                    )
                    data = data.json()
            except Exception as exc:
                _handle_error(exc, api_url)
                return

    creds = update_tokens(
        access_token=data["access_token"],
        refresh_token=data["refresh_token"],
        expires_in=data.get("expires_in", 1800),
        api_url=api_url,
        email=email,
    )

    console.print(
        Panel(
            f"[green]Successfully authenticated as[/green] [bold]{email}[/bold]\n"
            f"[dim]Credentials stored in ~/.pylocket/credentials[/dim]",
            title="[bold green]Logged In[/bold green]",
            border_style="green",
        )
    )


# ---------------------------------------------------------------------------
# pylocket auth (group for subcommands)
# ---------------------------------------------------------------------------
@click.group(name="auth")
@click.pass_context
def auth(ctx: click.Context) -> None:
    """Manage authentication and security settings."""
    ctx.ensure_object(dict)


# ---------------------------------------------------------------------------
# pylocket auth api-keys
# ---------------------------------------------------------------------------
@auth.group(name="api-keys")
@click.pass_context
def api_keys(ctx: click.Context) -> None:
    """Manage API keys."""
    ctx.ensure_object(dict)


@api_keys.command(name="rotate")
@click.pass_context
@_async
async def rotate_api_key(ctx: click.Context) -> None:
    """Generate a new API key and invalidate the old one."""
    api_url = resolve_api_url(ctx.obj.get("api_url"))
    token = ctx.obj.get("token")

    try:
        async with PyLocketClient(api_url=api_url, token=token) as client:
            with console.status("[bold cyan]Rotating API key...[/bold cyan]", spinner="dots"):
                result = await client.rotate_api_key()
    except Exception as exc:
        _handle_error(exc, api_url)
        return

    new_key = result.get("api_key", result.get("key", ""))
    console.print()
    console.print(
        Panel(
            f"[green]API key rotated![/green]\n\n"
            f"  [bold]New Key:[/bold] [cyan]{new_key}[/cyan]\n\n"
            f"[yellow]The old key is now invalid. Update your CI/CD secrets.[/yellow]",
            title="[bold green]API Key Rotated[/bold green]",
            border_style="green",
        )
    )


# ---------------------------------------------------------------------------
# pylocket auth 2fa
# ---------------------------------------------------------------------------
@auth.group(name="2fa")
@click.pass_context
def twofa(ctx: click.Context) -> None:
    """Manage two-factor authentication."""
    ctx.ensure_object(dict)


@twofa.command(name="setup")
@click.pass_context
@_async
async def setup_2fa(ctx: click.Context) -> None:
    """Start 2FA setup. Returns a QR code URI for your authenticator app."""
    api_url = resolve_api_url(ctx.obj.get("api_url"))
    token = ctx.obj.get("token")

    try:
        async with PyLocketClient(api_url=api_url, token=token) as client:
            result = await client.setup_2fa()
    except Exception as exc:
        _handle_error(exc, api_url)
        return

    uri = result.get("provisioning_uri", result.get("uri", ""))
    console.print()
    console.print(
        Panel(
            f"[cyan]Scan this URI with your authenticator app:[/cyan]\n\n"
            f"  {uri}\n\n"
            f"[dim]Then confirm with: pylocket auth 2fa confirm --code <CODE>[/dim]",
            title="[bold cyan]2FA Setup[/bold cyan]",
            border_style="cyan",
        )
    )


@twofa.command(name="confirm")
@click.option("--code", required=True, help="TOTP code from your authenticator app.")
@click.pass_context
@_async
async def confirm_2fa(ctx: click.Context, code: str) -> None:
    """Confirm 2FA setup with a TOTP code."""
    api_url = resolve_api_url(ctx.obj.get("api_url"))
    token = ctx.obj.get("token")

    try:
        async with PyLocketClient(api_url=api_url, token=token) as client:
            result = await client.confirm_2fa(code)
    except Exception as exc:
        _handle_error(exc, api_url)
        return

    backup_codes = result.get("backup_codes", [])
    codes_str = "\n".join(f"  {c}" for c in backup_codes) if backup_codes else "  (none returned)"
    console.print()
    console.print(
        Panel(
            f"[green]2FA enabled![/green]\n\n"
            f"[bold]Backup codes (save these securely):[/bold]\n{codes_str}",
            title="[bold green]2FA Confirmed[/bold green]",
            border_style="green",
        )
    )


@twofa.command(name="status")
@click.pass_context
@_async
async def status_2fa(ctx: click.Context) -> None:
    """Check 2FA status and remaining backup codes."""
    api_url = resolve_api_url(ctx.obj.get("api_url"))
    token = ctx.obj.get("token")

    try:
        async with PyLocketClient(api_url=api_url, token=token) as client:
            result = await client.get_2fa_status()
    except Exception as exc:
        _handle_error(exc, api_url)
        return

    enabled = result.get("enabled", False)
    remaining = result.get("backup_codes_remaining", "?")
    status_text = "[green]Enabled[/green]" if enabled else "[yellow]Disabled[/yellow]"
    console.print()
    console.print(f"  2FA Status:          {status_text}")
    console.print(f"  Backup codes left:   {remaining}")
    console.print()


@twofa.command(name="disable")
@click.option("--code", required=True, help="TOTP code to confirm disabling.")
@click.pass_context
@_async
async def disable_2fa(ctx: click.Context, code: str) -> None:
    """Disable 2FA."""
    api_url = resolve_api_url(ctx.obj.get("api_url"))
    token = ctx.obj.get("token")

    try:
        async with PyLocketClient(api_url=api_url, token=token) as client:
            await client.disable_2fa(code)
    except Exception as exc:
        _handle_error(exc, api_url)
        return

    console.print("[green]2FA has been disabled.[/green]")
