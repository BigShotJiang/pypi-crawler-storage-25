# PyLocket CLI v1.1.2

Protect and distribute Python applications from the command line.

## Installation

```bash
pip install pylocket
```

Or download platform-specific binaries from your [Developer Portal](https://portal.pylocket.com/cli).

## Supported Python Versions

- Python 3.12
- Python 3.13
- Python 3.14

## Quick Start

```bash
# Authenticate with your PyLocket account
pylocket login

# List your apps
pylocket apps list

# Protect a PyInstaller executable
pylocket protect --app <APP_ID> --artifact dist/myapp.exe

# Check build status
pylocket status --build <BUILD_ID>

# Download the protected artifact
pylocket fetch --build <BUILD_ID> --out ./protected/
```

## Commands

| Command | Description |
|---------|-------------|
| `pylocket login` | Authenticate with your PyLocket account |
| `pylocket apps list` | List all your applications |
| `pylocket apps create` | Create a new application |
| `pylocket protect` | Upload and protect an artifact |
| `pylocket status` | Check build protection status |
| `pylocket fetch` | Download a protected artifact |

## What's New in v1.1.2

- **Fixed `status` and `fetch` commands** — both commands now work with just `--build` (no `--app` required)
- **Added `--app` option to `fetch`** — optional flag for consistency with `status` command

### v1.1.1

- **Real-time progress bar** — the `protect` command now displays a live progress bar showing each protection stage (scanning, protecting, packaging, etc.)
- **Malware rejection handling** — builds flagged by security scanning now display a clear "Build Rejected" message instead of a generic failure
- **Improved reliability** — fixed upload and download flow for faster, more reliable artifact processing

## Documentation

Full documentation: [docs.pylocket.com](https://docs.pylocket.com)

## Support

- Documentation: https://docs.pylocket.com
- Developer Portal: https://portal.pylocket.com
- Email: support@pylocket.com
