import re
from collections.abc import Iterable
from enum import StrEnum
from typing import cast

import icu
from collections_extended import RangeMap
from pydantic import BaseModel, Field
from pymultirole_plugins.v1.processor import ProcessorBase, ProcessorParameters
from pymultirole_plugins.v1.schema import Annotation, Document


class ConsolidationType(StrEnum):
    default = "default"
    linker = "linker"
    unknown = "unknown"
    unknown_only = "unknown_only"


class ConsolidateParameters(ProcessorParameters):
    type: ConsolidationType = Field(
        ConsolidationType.default,
        description="""Type of consolidation:<br />
    <li><b>default</b> deduplicate and keep only the longest match when spans overlap</li>
    <li><b>linker</b> retain only known entities (linked to a knowledge base term)</li>
    <li><b>unknown</b> retain all, prepend <code>unknown_prefix</code> to unlinked entity labels</li>
    <li><b>unknown_only</b> retain only unlinked entities with <code>unknown_prefix</code> prepended</li>""",
    )
    kill_label: str | None = Field(
        None,
        description="Label name of the kill list — annotations with this label are removed from the output",
        json_schema_extra={"extra": "label"},
    )
    unknown_prefix: str | None = Field(
        "Unknown ",
        description="Prefix prepended to unlinked entity labels (used by unknown/unknown_only types)",
        json_schema_extra={"extra": "advanced"},
    )


class ConsolidateProcessor(ProcessorBase):
    """Consolidate and deduplicate annotations from multiple NER/NED components.

    Resolves overlapping spans by keeping the longest match, optionally filters
    annotations based on knowledge-base linkage, and supports kill-list removal.
    """

    def process(self, documents: list[Document], parameters: ProcessorParameters) -> list[Document]:
        def has_knowledge(a: Annotation):
            return a.terms is not None or a.properties is not None

        params: ConsolidateParameters = cast(ConsolidateParameters, parameters)
        for document in documents:
            if document.annotations:
                anns = self.filter_annotations(document, params.kill_label)
                if params.type in [
                    ConsolidationType.unknown_only,
                    ConsolidationType.unknown,
                ]:
                    for a in anns:
                        unknown_labelName = sanitize_label(params.unknown_prefix + (a.label or a.labelName))
                        if not has_knowledge(a):
                            a.labelName = unknown_labelName
                            if a.label:
                                a.label = params.unknown_prefix + a.label
                    if params.type == ConsolidationType.unknown_only:
                        anns = [a for a in anns if not has_knowledge(a)]
                elif params.type == ConsolidationType.linker:
                    anns = [a for a in anns if has_knowledge(a)]
                document.annotations = anns
        return documents

    @classmethod
    def get_model(cls) -> type[BaseModel]:
        return ConsolidateParameters

    def filter_annotations(self, input: Document, kill_label: str = None):
        """Filter a sequence of annotations and remove duplicates or overlaps.

        When spans overlap, the (first) longest span is preferred over shorter spans.
        Annotations in the kill list are always removed.

        Args:
            input: The document whose annotations to filter.
            kill_label: Label name whose annotations act as a kill list.

        Returns:
            The filtered and sorted list of annotations.
        """

        def get_sort_key(a: Annotation):
            return a.end - a.start, -a.start, a.labelName == kill_label

        sorted_annotations: Iterable[Annotation] = sorted(input.annotations, key=get_sort_key, reverse=True)
        result = []
        seen_offsets = RangeMap()
        for ann in sorted_annotations:
            # Check for end - 1 here because boundaries are inclusive
            if seen_offsets.get(ann.start) is None and seen_offsets.get(ann.end - 1) is None:
                if ann.text is None:
                    ann.text = input.text[ann.start : ann.end]
                result.append(ann)
                seen_offsets[ann.start : ann.end] = ann
            else:
                target = seen_offsets.get(ann.start) or seen_offsets.get(ann.end - 1)
                if (
                    target.labelName != kill_label
                    and (target.start - ann.start == 0 or target.end - ann.end == 0)
                    and (ann.end - ann.start) / (target.end - target.start) > 0.8
                ):
                    if ann.terms:
                        terms = set(target.terms or [])
                        terms.update(ann.terms)
                        target.terms = list(terms)
                    if ann.properties:
                        props = target.properties or {}
                        props.update(ann.properties)
                        target.properties = props
        if kill_label is not None:
            result = [ann for ann in result if ann.labelName != kill_label]
        result = sorted(
            result,
            key=lambda ann: ann.start,
        )
        return result


nonAlphanum = re.compile(r"[\W]+", flags=re.ASCII)
underscores = re.compile("_{2,}", flags=re.ASCII)
trailingAndLeadingUnderscores = re.compile(r"^_+|_+\$", flags=re.ASCII)
# see http://userguide.icu-project.org/transforms/general
transliterator = icu.Transliterator.createInstance(
    "Any-Latin; NFD; [:Nonspacing Mark:] Remove; NFC; Latin-ASCII; Lower;",
    icu.UTransDirection.FORWARD,
)


def sanitize_label(string):
    result = transliterator.transliterate(string)
    result = re.sub(nonAlphanum, "_", result)
    result = re.sub(underscores, "_", result)
    result = re.sub(trailingAndLeadingUnderscores, "", result)
    return result
