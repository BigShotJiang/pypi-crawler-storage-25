# HiddenLayer MSFT Agent Framework Guardrails

[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](LICENSE)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)

HiddenLayer MSFT Agent Framework Guardrails provides AI safety middleware for the Azure Agent Framework, enabling real-time detection and mitigation of malicious inputs, prompt injections, and unsafe AI agent behaviors.

## Features

- **Input Scanning**: Analyze user messages for prompt injections and malicious content
- **Output Filtering**: Monitor and filter AI-generated responses
- **Redaction Support**: Automatically redact sensitive or unsafe content
- **Streaming Compatible**: Works with both streaming and non-streaming responses
- **Easy Integration**: Simple middleware integration with Azure Agent Framework

## Installation

```bash
pip install hiddenlayer-msft-agent-framework-guardrails
```

## Configuration

Set the following environment variables:

```bash
# Required: Your HiddenLayer API credentials
export HIDDENLAYER_API_ID="your-api-id"
export HIDDENLAYER_API_KEY="your-api-key"

# Optional: Project-specific configuration
export HIDDENLAYER_PROJECT_ID="your-project-id"
export HIDDENLAYER_REQUESTER_ID="your-app-name"
```

## Usage

### Basic Example

```python
import asyncio
from agent_framework.openai import OpenAIChatClient
from hiddenlayer_msft_agent_framework_guardrails.middleware import (
    HiddenlayerChatMiddleware,
    HiddenLayerParams,
)

# Configure HiddenLayer parameters
params = HiddenLayerParams(model="gpt-4o-mini")


async def main():
    # Create agent with HiddenLayer guardrails
    agent = OpenAIChatClient().as_agent(
        name="MyAgent",
        model="gpt-4o-mini",
        instructions="You are a helpful assistant.",
        middleware=[
            HiddenlayerChatMiddleware(params),
        ],
    )

    # Run query
    query = "Hello!"
    print(f"User: {query}")
    result = await agent.run(query)
    print(f"Result: {result}")


if __name__ == "__main__":
    asyncio.run(main())
```

## Advanced Examples

### Streaming Responses

```python
async def streaming_example():
    agent = OpenAIChatClient().as_agent(
        name="MyAgent",
        instructions="You are a helpful assistant.",
        middleware=[
            HiddenlayerChatMiddleware(params),
        ],
    )

    query = "Hello!"
    print(f"User: {query}")
    print("Agent: ", end="", flush=True)

    async for chunk in agent.run(query, stream=True):
        if chunk.text:
            print(chunk.text, end="", flush=True)
    print()
```

### Capability Matrix

| | Alert | Block | Redact |
|---|:---:|:---:|:---:|
| **Input Guardrails** | :white_check_mark: | :white_check_mark: | :white_check_mark: |
| **Output Guardrails** | :white_check_mark: | :white_check_mark: | :white_check_mark: |
| **Streaming Output Guardrails** | :white_check_mark: | :x: | :x: |

## License

This project is licensed under the Apache License 2.0 - see the [LICENSE](LICENSE) file for details.

## Support

For issues, questions, or contributions:
- GitHub Issues: [Report a bug or request a feature](https://github.com/hiddenlayer/hiddenlayer-msft-agent-framework-guardrails/issues)
- Email: sdks@hiddenlayer.com

## Related Projects

- [Azure Agent Framework](https://github.com/microsoft/agent-framework)
- [HiddenLayer SDK](https://github.com/hiddenlayer/hiddenlayer-sdk-python)
