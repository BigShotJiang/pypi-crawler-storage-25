from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("hiddenlayer-msft-agent-framework-guardrails")
except PackageNotFoundError:  # package not installed (e.g. running from source)
    __version__ = "unknown"
