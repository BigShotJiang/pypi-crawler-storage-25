import json
import logging
import os
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Literal
from uuid import uuid4

import httpx
from agent_framework import (
    AgentResponse,
    ChatContext,
    ChatMiddleware,
    ChatResponse,
    Content,
    Message,
    MiddlewareTermination,
    ResponseStream,
)
from hiddenlayer import AsyncHiddenLayer, RequestOptions
from pydantic import BaseModel

from hiddenlayer_msft_agent_framework_guardrails import __version__

logger = logging.Logger(__name__)

Role = Literal["user", "assistant"]


class HiddenLayerParams(BaseModel):
    """HiddenLayer request metadata and policy routing parameters."""

    model: str | None = None
    project_id: str | None = os.getenv("HIDDENLAYER_PROJECT_ID")
    requester_id: str = os.getenv("HIDDENLAYER_REQUESTER_ID", "hiddenlayer-msft-agent-framework-integration")


@dataclass
class AnalysisResult:
    """Normalized evaluation outcome for a single analysis call.

    ``block`` is ``True`` when the ``hl-runtime-action: block`` response header is present.
    ``messages`` is the full messages array returned by HiddenLayer — it mirrors the shape
    sent in the request body but with any redactions already applied in-place.
    """

    block: bool
    messages: list[dict[str, Any]] = field(default_factory=list)


REQUEST_EVAL_PATH = "/detection/v2/request-evaluations"
RESPONSE_EVAL_PATH = "/detection/v2/response-evaluations"


def _build_request_body(
    messages: list[dict[str, Any]],
    tools: list[dict[str, Any]] | None = None,
    context_options: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Build an OpenAI Chat Completions request body for the HiddenLayer request-evaluation endpoint."""
    # Prepend a system message if the caller supplied instructions via context options.
    all_messages = list(messages)
    instructions = (context_options or {}).get("instructions")
    if instructions:
        all_messages = [{"role": "system", "content": instructions}] + all_messages

    body: dict[str, Any] = {"messages": all_messages}
    if tools:
        body["tools"] = tools
    model_id = (context_options or {}).get("model_id")
    if model_id:
        body["model"] = model_id
    return body


def _build_response_body(
    message: dict[str, Any],
    params: HiddenLayerParams,
) -> dict[str, Any]:
    """Build an OpenAI Chat Completions response body for the HiddenLayer response-evaluation endpoint."""
    finish_reason = "tool_calls" if message.get("tool_calls") else "stop"
    body: dict[str, Any] = {
        "choices": [
            {
                "index": 0,
                "message": message,
                "finish_reason": finish_reason,
            }
        ]
    }
    if params.model:
        body["model"] = params.model
    return body


def _extract_result(response: httpx.Response) -> AnalysisResult:
    """Extract block decision and redacted messages from a HiddenLayer v2 raw HTTP response.

    Blocking is signaled via the ``hl-runtime-action: block`` response header.
    Redaction is applied in-place inside the response body, which mirrors the shape of the
    request: request-evaluations return a ``messages`` array; response-evaluations return a
    ``choices`` array whose first entry contains the (possibly redacted) assistant message.
    """
    # Block is communicated entirely through the response header.
    action = response.headers.get("hl-runtime-action", "")
    block = action.lower() == "block"

    body = response.json()

    # Parse body and collect the messages array.
    messages: list[dict[str, Any]] = []
    if isinstance(body, dict):
        # Request-evaluation: body contains a top-level "messages" key.
        messages = list(body.get("messages") or [])

        # Response-evaluation: body contains "choices"; extract the assistant message.
        if not messages:
            choices = body.get("choices") or []
            if choices:
                first = choices[0]
                msg = first.get("message") if isinstance(first, dict) else None
                if msg:
                    messages = [msg]
    else:
        msgs_attr = getattr(body, "messages", None)
        if msgs_attr:
            messages = list(msgs_attr)

    logger.debug("HiddenLayer hl-runtime-action=%r messages=%r", action, messages)
    return AnalysisResult(block=block, messages=messages)


def _context_messages_to_openai(messages: Sequence[Message]) -> list[dict[str, Any]]:
    """Convert agent framework messages to OpenAI-format dicts, preserving tool_calls and tool_call_id.

    Each ``Message`` has a ``contents`` list whose items carry a ``type`` discriminator:
    * ``"text"``            — plain text content with a ``text`` field.
    * ``"function_call"``   — tool-call request with ``call_id``, ``name``, and ``arguments`` (JSON string).
    * ``"function_result"`` — tool output with ``call_id``, ``result`` (string), and an ``items`` fallback array.
    """
    result: list[dict[str, Any]] = []
    for msg in messages:
        tool_call_contents = [c for c in msg.contents if c.type == "function_call"]
        tool_result_contents = [c for c in msg.contents if c.type == "function_result"]
        text_contents = [c for c in msg.contents if c.type == "text"]

        if tool_call_contents:
            # Assistant message requesting one or more tool calls.
            # arguments may arrive as a JSON string or a mapping — normalise to a JSON string.
            tool_calls = []
            for c in tool_call_contents:
                args = json.dumps(c.arguments) if isinstance(c.arguments, Mapping) else (c.arguments or "")
                tool_calls.append(
                    {"id": c.call_id, "type": "function", "function": {"name": c.name, "arguments": args}}
                )
            result.append({"role": msg.role, "content": None, "tool_calls": tool_calls})
        elif tool_result_contents:
            # Each function_result becomes a separate "tool" role message.
            # Prefer the top-level ``result`` string; fall back to the first text item in ``items``.
            for c in tool_result_contents:
                content = c.result
                if content is None:
                    text_items = [
                        item for item in (getattr(c, "items", None) or []) if getattr(item, "type", None) == "text"
                    ]
                    content = text_items[0].text if text_items else ""
                result.append({"role": "tool", "tool_call_id": c.call_id, "content": content})
        else:
            # Plain text message — join all ``type=="text"`` content items explicitly.
            text = " ".join(c.text for c in text_contents) if text_contents else (msg.text or "")  # ty:ignore[no-matching-overload]
            result.append({"role": msg.role, "content": text})
    return result


def _openai_messages_to_context(
    hl_messages: list[dict[str, Any]],
    original: Sequence[Message],
) -> list[Message]:
    """Apply HiddenLayer's (possibly redacted) messages back onto the Azure agent framework message list.

    HiddenLayer returns the same message array that was sent, with any sensitive content already
    substituted in-place.  Because one Azure ``Message`` can expand into several OpenAI-format
    dicts (e.g. multiple tool-result rows), we iterate both lists in lock-step and reconstruct
    each Azure message using HL's (potentially redacted) values for all three shapes:

    * **Plain text** — ``type=="text"`` contents; HL returns ``{"role": "user"|"assistant", "content": "..."}``
      and we write the redacted string back to the matching ``text`` content item.
    * **Tool calls** — ``type=="function_call"`` contents; HL returns
      ``{"role": "assistant", "tool_calls": [{"id", "type", "function": {"name", "arguments"}}]}``
      (one HL dict → one Azure ``Message``).  HL may redact individual ``arguments`` strings.
    * **Tool results** — ``type=="function_result"`` contents; HL returns
      ``{"role": "tool", "tool_call_id": "...", "content": "..."}``
      (N HL dicts → one Azure ``Message``).  HL may redact the ``content`` string, which maps back
      to ``result`` (and the ``items`` text fallback) on the original content object.
    """
    result: list[Message] = []

    # azure agents message array doesn't have the system prompt in it, so we have to remove it
    system_prompt_idx = -1
    for idx, message in enumerate(hl_messages):
        if message.get("role") == "system":
            system_prompt_idx = idx

    if system_prompt_idx > 0:
        hl_messages.pop(system_prompt_idx)

    if len(hl_messages) != len(original):
        logger.info("HL and Azure messages are not the same length.")
        return list(original)

    for hl_msg, orig_msg in zip(hl_messages, original):
        tool_call_contents = [c for c in orig_msg.contents if c.type == "function_call"]
        tool_result_contents = [c for c in orig_msg.contents if c.type == "function_result"]

        if tool_call_contents:
            # One OpenAI dict covers the entire tool-call batch.
            # HL may redact individual ``function.arguments`` strings (kept as JSON strings).
            hl_tool_calls = hl_msg.get("tool_calls") or [] if isinstance(hl_msg, dict) else []
            new_contents: list[Content] = [
                Content.from_function_call(
                    orig_c.call_id,
                    orig_c.name,
                    # arguments stays a JSON string; HL redacts in-place within that string.
                    arguments=(hl_tc.get("function") or {}).get("arguments", orig_c.arguments),
                )
                for orig_c, hl_tc in zip(tool_call_contents, hl_tool_calls)
            ]
            # Preserve any non-function_call content items (e.g. a text prefix) unchanged.
            other_contents = [c for c in orig_msg.contents if c.type != "function_call"]
            result.append(Message(role=orig_msg.role, contents=new_contents + other_contents))

        elif tool_result_contents:
            # Each function_result was serialised as its own ``{"role": "tool", ...}`` dict.
            # HL's ``content`` field maps back to the ``result`` string (and items fallback).
            new_result_contents: list[Content] = []
            for orig_c in tool_result_contents:
                # HL returns the (possibly redacted) result in the ``content`` field.
                hl_content = hl_msg.get("content") if isinstance(hl_msg, dict) else None
                redacted_result = hl_content if hl_content is not None else orig_c.result
                new_result_contents.append(Content.from_function_result(orig_c.call_id, result=redacted_result))
            result.append(Message(role=orig_msg.role, contents=new_result_contents))

        else:
            # Plain text message — HL returns the (possibly redacted) text in ``content``.
            content = hl_msg.get("content") if isinstance(hl_msg, dict) else None
            result.append(Message(role=orig_msg.role, contents=[content]) if content is not None else orig_msg)

    return result


def _context_tools_to_openai(context: Any) -> list[dict[str, Any]] | None:
    """Extract tools from a context's options and convert to OpenAI-format tool definitions."""
    tools = (getattr(context, "options", None) or {}).get("tools")
    if not tools:
        return None
    if not isinstance(tools, (list, tuple)):
        tools = [tools]
    result = []
    for tool in tools:
        if callable(tool) and not hasattr(tool, "name"):
            continue
        result.append(
            {
                "type": "function",
                "function": {
                    "name": tool.name,
                    "description": tool.description or "",
                    "parameters": tool.parameters(),
                },
            }
        )
    return result or None


class HiddenlayerMiddleware(ChatMiddleware):
    def __init__(self, params: HiddenLayerParams, client: AsyncHiddenLayer | None = None):
        super().__init__()
        self.client = client or AsyncHiddenLayer()
        self.params = params

    def _build_options(self, roundtrip_id: str, session_id: str | None = None) -> RequestOptions:
        options: RequestOptions = {
            "headers": {
                "HL-RoundTrip-Id": roundtrip_id,
                "HL-Runtime-Edge-Provider": "aws-strands-sdk",
                "HL-Runtime-Edge-Provider-Version": __version__,
            }
        }
        if self.params.project_id:
            options["headers"]["hl-project-id"] = self.params.project_id
        if session_id:
            options["headers"]["hl-runtime-session-id"] = session_id

        return options

    async def process(
        self,
        context: ChatContext,
        call_next: Callable[[], Awaitable[None]],
    ):

        roundtrip_id = str(uuid4())
        openai_tools = _context_tools_to_openai(context)
        context_options = getattr(context, "options", None) or {}
        session_id: str | None = context_options.get("hl_session_id")

        # --- Scan chat input (request evaluation) ---
        if context.messages:
            openai_messages = _context_messages_to_openai(context.messages)
            body = _build_request_body(
                openai_messages,
                tools=openai_tools,
                context_options=context_options,
            )
            raw_resp = await self.client.post(
                REQUEST_EVAL_PATH,
                cast_to=httpx.Response,
                body=body,
                options=self._build_options(roundtrip_id, session_id=session_id),
            )
            hl_result = _extract_result(raw_resp)
            if hl_result.block:
                context.result = ChatResponse(messages=[Message(role="assistant", contents=["Blocked by HiddenLayer"])])
                raise MiddlewareTermination(result=context.result)

            # Replace context.messages with HL's version — redactions have been applied in-place.
            if hl_result.messages:
                context.messages = _openai_messages_to_context(hl_result.messages, context.messages)

        await call_next()

        # --- Scan chat output (response evaluation) ---
        if context.result:
            if context.stream and isinstance(context.result, ResponseStream):
                collected: list[str] = []

                def collect_update(update):
                    if update.text:
                        collected.append(update.text)
                    return update

                async def analyze_after_stream() -> None:
                    full_text = "".join(collected)
                    if full_text:
                        assistant_message = {"role": "assistant", "content": full_text}
                        body = _build_response_body(assistant_message, self.params)
                        raw_resp = await self.client.post(
                            RESPONSE_EVAL_PATH,
                            cast_to=httpx.Response,
                            body=body,
                            options=self._build_options(roundtrip_id, session_id=session_id),
                        )
                        hl_result = _extract_result(raw_resp)
                        if hl_result.block:
                            context.result = AgentResponse(
                                messages=[Message(role="assistant", contents=["Blocked by HiddenLayer"])]
                            )
                            raise MiddlewareTermination(result=context.result)

                context.result = context.result.with_transform_hook(collect_update).with_cleanup_hook(
                    analyze_after_stream
                )
            elif isinstance(context.result, ChatResponse):
                result_messages = list(context.result.messages) if context.result.messages else []
                if result_messages:
                    openai_result_messages = _context_messages_to_openai(result_messages)
                    redacted_openai_messages: list[dict[str, Any]] = []

                    for openai_msg in openai_result_messages:
                        body = _build_response_body(openai_msg, self.params)
                        raw_resp = await self.client.post(
                            RESPONSE_EVAL_PATH,
                            cast_to=httpx.Response,
                            body=body,
                            options=self._build_options(roundtrip_id, session_id=session_id),
                        )
                        hl_result = _extract_result(raw_resp)
                        if hl_result.block:
                            context.result = ChatResponse(
                                messages=[Message(role="assistant", contents=["Blocked by HiddenLayer"])]
                            )
                            raise MiddlewareTermination(result=context.result)
                        # hl_result.messages contains the (possibly redacted) single message
                        redacted_openai_messages.extend(hl_result.messages if hl_result.messages else [openai_msg])

                    # Map the (possibly redacted) OpenAI messages back to Azure agent Message objects.
                    updated_messages = _openai_messages_to_context(redacted_openai_messages, result_messages)
                    context.result = ChatResponse(messages=updated_messages)
