"""Download MeteoSwiss data from the STAC API and opendata.swiss."""

from __future__ import annotations

import json
import zipfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from foehn.collections import (
    CLIMATE_NORMALS_ZIP_URL,
    COLLECTIONS,
    FORECAST_CSV_COLLECTIONS,
    STAC_API_BASE,
)
from foehn.stac import get_collection_items, get_collection_metadata

_ALLOWED_DOMAINS = {"data.geo.admin.ch", "opendata.swiss", "rgw.cscs.ch"}

# Default concurrency for per-asset downloads. Kept modest to stay polite on the
# MeteoSwiss/CSCS CDNs — they handle bursts fine but we don't need to hammer them.
DEFAULT_WORKERS = 8


@dataclass
class DownloadResult:
    """Summary of a download call. Returned by all download_* functions.

    Callers use this to decide whether to run expensive downstream work
    (e.g. Spark MERGE INTO) without scanning the output directory.
    """

    total_assets: int = 0
    downloaded: int = 0
    skipped: int = 0
    filenames: list[str] = field(default_factory=list)


def _retry_session(
    retries: int = 3,
    backoff_factor: float = 1.0,
    status_forcelist: tuple[int, ...] = (500, 502, 503, 504),
    pool_maxsize: int = DEFAULT_WORKERS,
) -> requests.Session:
    """Return a requests session with automatic retry on transient errors."""
    session = requests.Session()
    retry = Retry(
        total=retries,
        backoff_factor=backoff_factor,
        status_forcelist=status_forcelist,
        allowed_methods=["GET"],
        raise_on_status=False,
        connect=retries,
        read=retries,
    )
    adapter = HTTPAdapter(
        max_retries=retry,
        pool_connections=pool_maxsize,
        pool_maxsize=pool_maxsize,
    )
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    return session


def _validate_href(href: str) -> str:
    """Raise ValueError if *href* points outside the trusted MeteoSwiss domains."""
    parsed = urlparse(href)
    if parsed.hostname not in _ALLOWED_DOMAINS:
        raise ValueError(f"Untrusted download domain: {parsed.hostname}")
    return href


# --- State files (ETags + last-run timestamp) ---


def load_etags(data_dir: Path) -> dict:
    path = data_dir / "_etags.json"
    if path.exists():
        return json.loads(path.read_text())
    return {}


def save_etags(data_dir: Path, etags: dict):
    path = data_dir / "_etags.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(etags, indent=2))


def load_last_run(data_dir: Path) -> str | None:
    """Return ISO timestamp of last successful run, or None."""
    path = data_dir / "_last_run.json"
    if path.exists():
        data = json.loads(path.read_text())
        return data.get("timestamp")
    return None


def save_last_run(data_dir: Path):
    path = data_dir / "_last_run.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"timestamp": datetime.now(timezone.utc).isoformat()}))


# --- CSV downloads ---


def _download_csv(
    session: requests.Session,
    href: str,
    filepath: Path,
    old_etag: str | None,
) -> tuple[str, str, str, str | None]:
    """Fetch a single CSV, re-encode to UTF-8, and write it to disk.

    Returns (status, href, filename, new_etag) where status is "downloaded" or "skipped".
    """
    _validate_href(href)
    filename = filepath.name
    headers = {"If-None-Match": old_etag} if old_etag and filepath.exists() else {}
    resp = session.get(href, headers=headers, timeout=60)
    if resp.status_code == 304:
        return ("skipped", href, filename, None)
    resp.raise_for_status()
    # MeteoSwiss CSVs are Windows-1252; re-encode to UTF-8
    try:
        content = resp.content.decode("utf-8-sig")
    except UnicodeDecodeError:
        content = resp.content.decode("windows-1252")
    filepath.write_text(content, encoding="utf-8")
    return ("downloaded", href, filename, resp.headers.get("ETag"))


def download_collection(
    collection_key: str,
    output_dir: Path,
    data_types: list[str] | None = None,
    since: str | None = None,
    workers: int = DEFAULT_WORKERS,
) -> DownloadResult:
    """Download CSVs for a collection.

    Args:
        collection_key: Key from COLLECTIONS (e.g. "smn").
        output_dir: Root directory for bronze downloads (files go to output_dir/<key>/).
        data_types: List of "historical", "recent", "now". Defaults to ["recent"].
        since: ISO timestamp — only process items updated after this time.
        workers: Number of concurrent HTTP downloads.

    Returns:
        DownloadResult with counts and list of newly downloaded filenames.
    """
    if data_types is None:
        data_types = ["recent"]

    collection_id = COLLECTIONS[collection_key]
    out_dir = output_dir / collection_key
    out_dir.mkdir(parents=True, exist_ok=True)

    etags = load_etags(output_dir.parent)

    print(f"\n{'=' * 60}", flush=True)
    print(f"Collection: {collection_id}", flush=True)
    print(f"Data types: {data_types}", flush=True)
    print(f"Output dir: {out_dir}", flush=True)
    print(f"{'=' * 60}", flush=True)

    items = get_collection_items(collection_id)
    print(f"  Found {len(items)} items", flush=True)

    # Filter to items updated since last run
    if since:
        items = [item for item in items if item.get("properties", {}).get("updated", "") > since]
        print(f"  {len(items)} items updated since last run", flush=True)
        if not items:
            print("  Nothing changed — skipping", flush=True)
            return DownloadResult()

    # For forecast collections, only keep the latest item (newest forecast run)
    if collection_key in FORECAST_CSV_COLLECTIONS and items:
        items.sort(
            key=lambda x: x.get("properties", {}).get("datetime", x.get("id", "")),
            reverse=True,
        )
        items = items[:1]
        print(f"  Using latest forecast: {items[0].get('id', '?')}", flush=True)

    # Collect matching CSV assets
    skip_data_type_filter = collection_key in FORECAST_CSV_COLLECTIONS
    csv_assets = []
    for item in items:
        assets = item.get("assets", {})
        for asset_info in assets.values():
            href = asset_info.get("href", "")
            if not href.endswith(".csv"):
                continue
            if not skip_data_type_filter:
                has_time_slice = any(ts in href for ts in ("historical", "recent", "now"))
                if has_time_slice and not any(dt in href for dt in data_types):
                    continue
            csv_assets.append((href, asset_info))

    print(f"  {len(csv_assets)} CSV files to process", flush=True)

    session = _retry_session(pool_maxsize=workers)
    total = len(csv_assets)
    downloaded = 0
    skipped = 0
    filenames: list[str] = []
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = [
            pool.submit(
                _download_csv,
                session,
                href,
                out_dir / href.split("?")[0].split("/")[-1],
                etags.get(href),
            )
            for href, _ in csv_assets
        ]
        for i, fut in enumerate(as_completed(futures), 1):
            status, href, filename, new_etag = fut.result()
            if status == "skipped":
                skipped += 1
                continue
            if new_etag:
                etags[href] = new_etag
            downloaded += 1
            filenames.append(filename)
            print(f"  [{i}/{total}] Downloaded: {filename}", flush=True)

    save_etags(output_dir.parent, etags)
    if skipped:
        print(f"  Skipped {skipped} unchanged files", flush=True)
    print(f"  Done — {downloaded} files downloaded", flush=True)

    return DownloadResult(total_assets=total, downloaded=downloaded, skipped=skipped, filenames=filenames)


# --- Metadata downloads ---


def download_metadata(collection_key: str, output_dir: Path, workers: int = DEFAULT_WORKERS) -> DownloadResult:
    """Download collection-level metadata files (stations, parameters, inventory)."""
    collection_id = COLLECTIONS[collection_key]
    out_dir = output_dir / collection_key
    out_dir.mkdir(parents=True, exist_ok=True)

    coll = get_collection_metadata(collection_id)
    assets = coll.get("assets", {})
    if not assets:
        return DownloadResult()

    targets = [
        (asset_info["href"], out_dir / asset_info["href"].split("?")[0].split("/")[-1])
        for asset_info in assets.values()
        if asset_info.get("href", "").endswith(".csv")
    ]
    if not targets:
        return DownloadResult()

    session = _retry_session(pool_maxsize=workers)
    downloaded = 0
    filenames: list[str] = []
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(_download_csv, session, href, filepath, None) for href, filepath in targets]
        for fut in as_completed(futures):
            filename = fut.result()[2]
            downloaded += 1
            filenames.append(filename)
            print(f"  Metadata: {filename}", flush=True)

    if downloaded:
        print(f"  {downloaded} metadata files downloaded", flush=True)

    return DownloadResult(total_assets=len(targets), downloaded=downloaded, skipped=0, filenames=filenames)


# --- GRIB2 / HDF5 downloads ---


def _needs_redownload(filepath: Path, remote_updated: str) -> bool:
    """Decide whether to (re)download a binary asset.

    Handles MeteoSwiss's in-place overwrites — e.g. CombiPrecip reanalysis
    (CPCH) replaces the original CPC hourly file with the same filename
    ~8 days later. A plain exists() check would leave the stale version
    on disk; comparing the STAC "updated" timestamp against local mtime
    picks up those server-side updates.
    """
    if not filepath.exists():
        return True
    if not remote_updated:
        return False
    try:
        remote_dt = datetime.fromisoformat(remote_updated.replace("Z", "+00:00"))
        local_dt = datetime.fromtimestamp(filepath.stat().st_mtime, tz=timezone.utc)
    except (ValueError, OSError):
        return False
    return remote_dt > local_dt


def _download_binary(session: requests.Session, href: str, filepath: Path, timeout: int = 120) -> str:
    """Stream a binary asset to disk. Returns the filename."""
    _validate_href(href)
    with session.get(href, stream=True, timeout=timeout) as resp:
        resp.raise_for_status()
        with filepath.open("wb") as f:
            for chunk in resp.iter_content(chunk_size=65536):
                f.write(chunk)
    return filepath.name


def download_grib2(
    collection_key: str,
    output_dir: Path,
    since: str | None = None,
    workers: int = DEFAULT_WORKERS,
) -> DownloadResult:
    """Download GRIB2/HDF5 binary files (latest page only)."""
    collection_id = COLLECTIONS[collection_key]
    out_dir = output_dir / collection_key
    out_dir.mkdir(parents=True, exist_ok=True)

    print(f"\n{'=' * 60}", flush=True)
    print(f"GRIB2 Collection: {collection_id}", flush=True)
    print(f"Output dir: {out_dir}", flush=True)
    print(f"{'=' * 60}", flush=True)

    # Only fetch first page — forecast/radar data is ephemeral
    url = f"{STAC_API_BASE}/collections/{collection_id}/items?limit=100"
    resp = _retry_session().get(url, timeout=30)
    resp.raise_for_status()
    items = resp.json().get("features", [])
    print(f"  Found {len(items)} items (latest page)", flush=True)

    if since:
        items = [item for item in items if item.get("properties", {}).get("updated", "") > since]
        print(f"  {len(items)} items updated since last run", flush=True)
        if not items:
            print("  Nothing changed — skipping", flush=True)
            return DownloadResult()

    binary_assets = []
    for item in items:
        item_updated = item.get("properties", {}).get("updated", "")
        assets = item.get("assets", {})
        for asset_info in assets.values():
            href = asset_info.get("href", "")
            clean = href.split("?")[0]
            # Accept grib2, h5, and other binary formats
            if any(clean.endswith(ext) for ext in (".grib2", ".h5", ".hdf5")):
                # Per-asset "updated" is preferred when present (STAC allows it),
                # otherwise fall back to the item-level updated timestamp.
                updated = asset_info.get("updated") or item_updated
                binary_assets.append((href, clean.split("/")[-1], updated))

    print(f"  {len(binary_assets)} binary files to download", flush=True)

    to_fetch = [
        (href, out_dir / filename)
        for href, filename, updated in binary_assets
        if _needs_redownload(out_dir / filename, updated)
    ]

    session = _retry_session(pool_maxsize=workers)
    total = len(to_fetch)
    downloaded = 0
    filenames: list[str] = []
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(_download_binary, session, href, filepath) for href, filepath in to_fetch]
        for i, fut in enumerate(as_completed(futures), 1):
            filename = fut.result()
            downloaded += 1
            filenames.append(filename)
            print(f"  [{i}/{total}] Downloaded: {filename}", flush=True)

    print(f"\n  Done — {downloaded} binary files downloaded", flush=True)

    return DownloadResult(
        total_assets=len(binary_assets),
        downloaded=downloaded,
        skipped=len(binary_assets) - total,
        filenames=filenames,
    )


# --- NetCDF / GeoTIFF / ZIP downloads ---


def download_netcdf(
    collection_key: str,
    output_dir: Path,
    since: str | None = None,
    workers: int = DEFAULT_WORKERS,
) -> DownloadResult:
    """Download NetCDF, GeoTIFF, and ZIP files for spatial/static collections.

    Args:
        collection_key: Key from COLLECTIONS.
        output_dir: Root directory for bronze downloads.
        since: ISO timestamp — only process items updated after this time.
        workers: Number of concurrent HTTP downloads.
    """
    collection_id = COLLECTIONS[collection_key]
    out_dir = output_dir / collection_key
    out_dir.mkdir(parents=True, exist_ok=True)

    print(f"\n{'=' * 60}", flush=True)
    print(f"NetCDF Collection: {collection_id}", flush=True)
    print(f"Output dir: {out_dir}", flush=True)
    print(f"{'=' * 60}", flush=True)

    items = get_collection_items(collection_id, require_csv=False)
    print(f"  Found {len(items)} items", flush=True)

    if since:
        items = [item for item in items if item.get("properties", {}).get("updated", "") > since]
        print(f"  {len(items)} items updated since last run", flush=True)
        if not items:
            print("  Nothing changed — skipping", flush=True)
            return DownloadResult()

    total_assets = 0
    targets: list[tuple[str, Path]] = []
    for item in items:
        for asset_info in item.get("assets", {}).values():
            href = asset_info.get("href", "")
            clean = href.split("?")[0]
            if not clean.endswith((".nc", ".tif", ".zip")):
                continue
            total_assets += 1
            filepath = out_dir / clean.split("/")[-1]
            if filepath.exists():
                continue
            targets.append((href, filepath))

    session = _retry_session(pool_maxsize=workers)
    downloaded = 0
    filenames: list[str] = []
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(_download_binary, session, href, filepath) for href, filepath in targets]
        for fut in as_completed(futures):
            filename = fut.result()
            downloaded += 1
            filenames.append(filename)
            print(f"  Downloaded: {filename}", flush=True)

    print(f"  Done — {downloaded} files downloaded", flush=True)

    return DownloadResult(
        total_assets=total_assets,
        downloaded=downloaded,
        skipped=total_assets - downloaded,
        filenames=filenames,
    )


# --- C6 climate normals ZIP ---


def download_climate_normals_zip(output_dir: Path, force: bool = False) -> DownloadResult:
    """Download C6 climate normals ZIP from opendata.swiss and extract."""
    out_dir = output_dir / "climate_normals"
    out_dir.mkdir(parents=True, exist_ok=True)
    filepath = out_dir / "normwerte.zip"

    if filepath.exists() and not force:
        print("\n  Climate normals ZIP already downloaded — skipping", flush=True)
        return DownloadResult(total_assets=1, downloaded=0, skipped=1, filenames=[])

    print(f"\n{'=' * 60}", flush=True)
    print("Climate normals (C6): downloading from opendata.swiss", flush=True)
    print(f"{'=' * 60}", flush=True)

    resp = _retry_session().get(CLIMATE_NORMALS_ZIP_URL, timeout=120)
    resp.raise_for_status()
    filepath.write_bytes(resp.content)
    print(f"  Downloaded: normwerte.zip ({len(resp.content) / 1024:.0f} KB)", flush=True)

    with zipfile.ZipFile(filepath, "r") as zf:
        resolved_out_dir = out_dir.resolve()
        for member in zf.infolist():
            target = (resolved_out_dir / member.filename).resolve()
            if not str(target).startswith(str(resolved_out_dir) + "/"):
                raise ValueError(f"Unsafe path in ZIP: {member.filename!r}")
        zf.extractall(out_dir)
        print(f"  Extracted {len(zf.namelist())} files", flush=True)

    return DownloadResult(total_assets=1, downloaded=1, skipped=0, filenames=["normwerte.zip"])
