"""Main Cogitus Module."""
