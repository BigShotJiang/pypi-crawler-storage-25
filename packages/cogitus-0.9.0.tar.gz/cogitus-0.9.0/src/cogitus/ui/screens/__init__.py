"""Screen components for Cogitus."""
