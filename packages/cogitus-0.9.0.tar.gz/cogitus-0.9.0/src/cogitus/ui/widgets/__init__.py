"""Widget components for Cogitus."""
