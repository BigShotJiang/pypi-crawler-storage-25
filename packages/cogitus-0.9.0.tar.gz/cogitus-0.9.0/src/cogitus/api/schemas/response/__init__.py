"""Response schemas package."""
