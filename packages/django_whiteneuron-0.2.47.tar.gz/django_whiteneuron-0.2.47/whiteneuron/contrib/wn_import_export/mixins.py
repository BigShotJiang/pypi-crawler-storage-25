class BeforeExportResourceMixin:
    pass