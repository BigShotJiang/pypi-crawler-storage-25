"""Textual Messages for inter-widget communication in the chat module.

These messages enable loose coupling between widgets. Child widgets post
messages that bubble up to parents, allowing the ChatScreen orchestrator
to coordinate actions without tight coupling.
"""

from uuid import UUID

from textual.message import Message

from alloy_runtime_types.dtos.sessions import MessageResponse, SessionSummary


# =============================================================================
# Session Events
# =============================================================================


class SessionSelected(Message):
    """User selected a session from the sidebar."""

    def __init__(self, session_id: UUID) -> None:
        self.session_id = session_id
        super().__init__()


class SessionCreated(Message):
    """A new session was successfully created."""

    def __init__(
        self,
        session_id: UUID,
        agent_id: UUID | None,
        agent_name: str | None,
    ) -> None:
        self.session_id = session_id
        self.agent_id = agent_id
        self.agent_name = agent_name
        super().__init__()


class SessionsLoaded(Message):
    """Sessions list was loaded/refreshed."""

    def __init__(self, sessions: list[SessionSummary]) -> None:
        self.sessions = sessions
        super().__init__()


class SessionsLoadError(Message):
    """Failed to load sessions."""

    def __init__(self, error: str) -> None:
        self.error = error
        super().__init__()


# =============================================================================
# Message Events
# =============================================================================


class MessagesLoaded(Message):
    """Messages for current session were loaded."""

    def __init__(self, messages: list[MessageResponse]) -> None:
        self.messages = messages
        super().__init__()


class SendMessageRequested(Message):
    """User wants to send a message."""

    def __init__(self, content: str) -> None:
        self.content = content
        super().__init__()


class RegenerateRequested(Message):
    """User wants to regenerate the last response."""

    pass


class UndoRequested(Message):
    """User wants to undo the last conversation turn."""

    pass


# =============================================================================
# Streaming Events
# =============================================================================


class StreamingStarted(Message):
    """Response streaming has begun."""

    def __init__(self, execution_id: UUID) -> None:
        self.execution_id = execution_id
        super().__init__()


class StreamingChunk(Message):
    """A chunk of streamed content received."""

    def __init__(self, content: str, is_reasoning: bool = False) -> None:
        self.content = content
        self.is_reasoning = is_reasoning
        super().__init__()


class StreamingCompleted(Message):
    """Response streaming finished successfully."""

    def __init__(self, full_content: str) -> None:
        self.full_content = full_content
        super().__init__()


class StreamingError(Message):
    """Error occurred during streaming."""

    def __init__(self, error: str) -> None:
        self.error = error
        super().__init__()


# =============================================================================
# UI Events
# =============================================================================


class FocusInputRequested(Message):
    """Request to focus the chat input."""

    pass


class FocusSessionSearchRequested(Message):
    """Request to focus the session search input."""

    pass


class CopyToClipboardRequested(Message):
    """Request to copy content to clipboard."""

    def __init__(self, content: str, label: str = "Content") -> None:
        self.content = content
        self.label = label
        super().__init__()


class NewSessionRequested(Message):
    """User wants to create a new session."""

    pass


class OpenEditorRequested(Message):
    """User wants to open the current input in $EDITOR."""

    def __init__(self, current_text: str) -> None:
        self.current_text = current_text
        super().__init__()


class EditorContentReturned(Message):
    """Content was returned from the external editor."""

    def __init__(self, content: str) -> None:
        self.content = content
        super().__init__()


# =============================================================================
# Slash Command Events
# =============================================================================


class SlashCommandExecuted(Message):
    """A slash command was executed by the user.

    Some commands are handled directly (e.g., /clear, /copy), while others
    signal actions to be performed by the screen (e.g., /new, /undo).
    """

    def __init__(self, command_name: str, args: str = "") -> None:
        self.command_name = command_name
        self.args = args
        super().__init__()


class UnknownSlashCommand(Message):
    """User entered an unknown slash command."""

    def __init__(self, command_text: str) -> None:
        self.command_text = command_text
        super().__init__()


# =============================================================================
# Welcome Screen Events
# =============================================================================


class AgentQuickSelected(Message):
    """User selected an agent from quick start list for immediate session creation."""

    def __init__(self, agent_id: UUID, agent_name: str) -> None:
        self.agent_id = agent_id
        self.agent_name = agent_name
        super().__init__()


class RecentSessionSelected(Message):
    """User selected a recent session from the welcome screen."""

    def __init__(self, session_id: UUID) -> None:
        self.session_id = session_id
        super().__init__()
