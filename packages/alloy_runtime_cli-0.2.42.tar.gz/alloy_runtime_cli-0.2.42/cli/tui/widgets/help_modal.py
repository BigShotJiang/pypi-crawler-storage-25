"""Help modal showing keyboard shortcuts and features.

Provides a modal screen with comprehensive keyboard shortcut reference
for all screens in the TUI application.
"""

from typing import Any

from textual import on
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import Button, Static


class HelpModal(ModalScreen[None]):
    """Modal showing keyboard shortcuts and help information.

    Usage:
        self.app.push_screen(HelpModal())
    """

    BINDINGS = [
        Binding("escape", "close", "Close", show=True),
        Binding("q", "close", "Close", show=False),
    ]

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Static("Keyboard Shortcuts", classes="modal-title")

            with VerticalScroll():
                # Global navigation (works everywhere)
                yield Static("[bold]Global Navigation[/]", classes="section-title")
                yield Static("[cyan]c[/]         Switch to Chat screen")
                yield Static("[cyan]a[/]         Switch to Agents screen")
                yield Static("[cyan]t[/]         Switch to Templates screen")
                yield Static("[cyan]m[/]         Switch to Content (media) screen")
                yield Static("[cyan]s[/]         Switch to Schemas screen")
                yield Static("[cyan]g[/]         Switch to Tool Configs screen")
                yield Static("[cyan]d[/]         Show Dashboard")
                yield Static("[cyan]?[/]         Show this help")
                yield Static("[cyan]Ctrl+C[/]    Quit application")

                # Chat screen
                yield Static("[bold]Chat Screen[/]", classes="section-title")
                yield Static("[cyan]Ctrl+N[/]    New chat session")
                yield Static("[cyan]Ctrl+D[/]    Send message")
                yield Static("[cyan]Ctrl+E[/]    Open message in $EDITOR")
                yield Static("[cyan]Ctrl+R[/]    Regenerate last response")
                yield Static("[cyan]Ctrl+U[/]    Undo last turn")
                yield Static("[cyan]Ctrl+Y[/]    Copy last response")
                yield Static("[cyan]Ctrl+Shift+Y[/]  Copy all messages")
                yield Static("[cyan]Ctrl+L[/]    Clear display")
                yield Static("[cyan]Ctrl+B[/]    Toggle sidebar")
                yield Static("[cyan]Escape[/]    Cancel streaming / Focus input")
                yield Static("[cyan]g[/]         Scroll to top")
                yield Static("[cyan]G[/]         Scroll to bottom")

                # Chat split view
                yield Static("[bold]Chat Split View[/]", classes="section-title")
                yield Static("[cyan]Ctrl+Shift+S[/]  Toggle split view")
                yield Static("[cyan]Ctrl+Shift+Tab[/]  Switch between panes")
                yield Static("[cyan]Ctrl+Shift+Y[/]  Toggle sync mode (send to both)")

                # Welcome screen (when no session active)
                yield Static(
                    "[bold]Welcome Screen (Agent Quick Select)[/]",
                    classes="section-title",
                )
                yield Static("[cyan]1-9[/]       Select agent by number")

                # Browser screens (Agents/Templates/Content/Schemas)
                yield Static(
                    "[bold]Browser Screens (Agents/Templates/Content/Schemas)[/]",
                    classes="section-title",
                )
                yield Static("[cyan]Ctrl+F[/]    Focus search input")
                yield Static("[cyan]Ctrl+R[/]    Refresh results")
                yield Static("[cyan]Ctrl+Y[/]    Copy name/content")
                yield Static("[cyan]Ctrl+N[/]    Create new item")
                yield Static("[cyan]Escape[/]    Focus list")
                yield Static("[cyan]Enter[/]     Copy name/content")
                yield Static("[cyan]Up/Down[/]   Navigate list")

                # Agents specific
                yield Static("[bold]Agents Screen[/]", classes="section-title")
                yield Static("[cyan]Ctrl+E[/]    Edit selected agent")
                yield Static("[cyan]Ctrl+D[/]    Delete selected agent")

                # Templates specific
                yield Static("[bold]Templates Screen[/]", classes="section-title")
                yield Static("[cyan]Ctrl+Shift+Y[/]  Copy template content")
                yield Static("[cyan]Ctrl+E[/]    Edit template in $EDITOR")
                yield Static("[cyan]Ctrl+U[/]    Edit template name/description")
                yield Static("[cyan]Ctrl+V[/]    Create new version")
                yield Static("[cyan]Ctrl+O[/]    Render and open template")

                # Content specific
                yield Static("[bold]Content Screen[/]", classes="section-title")
                yield Static(
                    "[cyan]Three search inputs:[/] Fuzzy, Tag filter, External ID"
                )
                yield Static(
                    "[cyan]Ctrl+I[/]    Copy ID (external_id if set, else UUID)"
                )
                yield Static("[cyan]Ctrl+T[/]    Manage tags")
                yield Static("[cyan]Ctrl+E[/]    View in $EDITOR")
                yield Static("[cyan]Ctrl+D[/]    Delete selected content")

                # Schemas specific
                yield Static("[bold]Schemas Screen[/]", classes="section-title")
                yield Static("[cyan]Ctrl+Shift+Y[/]  Copy schema definition")
                yield Static("[cyan]Ctrl+E[/]    Edit definition in $EDITOR")
                yield Static("[cyan]Ctrl+U[/]    Edit schema name/description")
                yield Static("[cyan]Ctrl+V[/]    Create new version")

                # Tool Configs specific
                yield Static("[bold]Tool Configs Screen[/]", classes="section-title")
                yield Static("[cyan]Ctrl+E[/]    Edit selected config")
                yield Static(
                    "[cyan]Ctrl+D[/]    Delete selected config (blocked if in use)"
                )

                # Modals
                yield Static("[bold]Modals & Dialogs[/]", classes="section-title")
                yield Static("[cyan]Escape[/]    Cancel / Close modal")
                yield Static("[cyan]Ctrl+S[/]    Submit form")
                yield Static("[cyan]n[/]         Cancel (confirmation dialogs)")

            with Vertical(classes="button-row"):
                yield Button("Close", id="close-btn", variant="primary")

    @on(Button.Pressed, "#close-btn")
    def on_close_pressed(self, event: Button.Pressed) -> None:
        """Close the modal."""
        self.dismiss(None)

    def action_close(self) -> None:
        """Close via escape or q key."""
        self.dismiss(None)
