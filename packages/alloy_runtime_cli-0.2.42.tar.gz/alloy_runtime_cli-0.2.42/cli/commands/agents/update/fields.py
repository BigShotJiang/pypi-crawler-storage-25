"""Field definitions for agent update presentation."""

from alloy_runtime_types.dtos.agents import UpdateAgentResponse


def format_models(response: UpdateAgentResponse) -> str:
    """Format models list for display."""
    return ", ".join(
        f"{m.provider_key.value}:{m.provider_model_name}" for m in response.models
    )


def format_tools(response: UpdateAgentResponse) -> str:
    """Format tools list for display."""
    if not response.tools:
        return "(none)"
    return ", ".join(t.tool_id for t in response.tools)


def format_tags(response: UpdateAgentResponse) -> str:
    """Format tags list for display."""
    if not response.tags:
        return "(none)"
    return ", ".join(t.tag_path for t in response.tags)


def format_generation_params(response: UpdateAgentResponse) -> str:
    """Format generation parameters for display."""
    if not response.generation_params:
        return "(default)"

    params: list[str] = []
    if response.generation_params.temperature is not None:
        params.append(f"temp={response.generation_params.temperature}")
    if response.generation_params.max_tokens is not None:
        params.append(f"max_tokens={response.generation_params.max_tokens}")
    if response.generation_params.reasoning_effort is not None:
        params.append(f"reasoning={response.generation_params.reasoning_effort}")

    return ", ".join(params) if params else "(default)"
