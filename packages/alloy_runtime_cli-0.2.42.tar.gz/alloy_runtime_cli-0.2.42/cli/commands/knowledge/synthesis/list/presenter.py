"""Presenter for synthesis list output."""

from typing import Any, cast

from pydantic import BaseModel
from alloy_runtime_types.dtos.knowledge import ListSynthesesResponse
from cli.infrastructure.formatting.fields import format_datetime, format_uuid
from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.list_renderer import ColumnConfig


def _format_stale(value: bool) -> str:
    return "stale" if value else "current"


def _format_collections(value: list[Any]) -> Any:
    if not value:
        return cast(str, None)
    return ", ".join(str(collection_id) for collection_id in value)


def present_syntheses_list(response: ListSynthesesResponse) -> None:
    items = cast(list[BaseModel], list(response.syntheses))
    OutputService.get().table(
        items,
        f"Syntheses ({response.total})",
        [
            ColumnConfig("id", "ID", lambda value: format_uuid(value, short=True)),
            ColumnConfig("title", "Title"),
            ColumnConfig("status", "Status"),
            ColumnConfig("is_stale", "Stale", _format_stale),
            ColumnConfig("source_chunk_count", "Sources"),
            ColumnConfig("collection_ids", "Collections", _format_collections),
            ColumnConfig("created_at", "Created", format_datetime),
        ],
        raw_payload=response,
    )
