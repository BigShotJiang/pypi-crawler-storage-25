"""Knowledge synthesis get command implementation."""

import typer

from cli.commands.flag_utils import validate_uuid
from cli.commands.knowledge.synthesis.get.presenter import present_synthesis_details
from cli.infrastructure.command import async_command, authenticated_client


def knowledge_synthesis_get_command(
    synthesis_id: str = typer.Argument(
        ...,
        help="Synthesis UUID",
    ),
) -> None:
    """Get synthesis details.

    Returns the full synthesis details including content (if completed),
    status, staleness information, and source tracking.

    Examples:
        alloy knowledge synthesis get <synthesis-uuid>
    """
    _execute_get_from_flags(synthesis_id=synthesis_id)


def _execute_get_from_flags(synthesis_id: str) -> None:
    """Validate flags and execute get."""
    # Validate synthesis UUID
    validate_uuid(synthesis_id, "synthesis")

    _execute_get(synthesis_id)


@async_command
async def _execute_get(synthesis_id: str) -> None:
    """Execute synthesis get."""
    async with authenticated_client() as (_config, client):
        response = await client.get_synthesis(synthesis_id)

    present_synthesis_details(response)
