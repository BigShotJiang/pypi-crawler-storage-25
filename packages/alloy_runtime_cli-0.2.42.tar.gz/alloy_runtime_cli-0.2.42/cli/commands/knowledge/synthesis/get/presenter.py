"""Presenter for synthesis get output."""

import json
from typing import Any, cast
from uuid import UUID

from cli.infrastructure.formatting.fields import format_datetime
from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig
from alloy_runtime_types.dtos.knowledge import GetSynthesisResponse


def _format_optional_uuid(value: UUID | None) -> Any:
    if value is None:
        return cast(str, None)
    return str(value)


def _format_metadata(value: dict[str, Any] | None) -> Any:
    if value is None:
        return cast(str, None)
    return json.dumps(value, indent=2, sort_keys=True)


def _format_collection_ids(collection_ids: list[UUID]) -> str:
    if not collection_ids:
        return "[]"
    return "\n".join(str(collection_id) for collection_id in collection_ids)


def _format_optional_datetime(value: Any) -> Any:
    if value is None:
        return cast(str, None)
    return format_datetime(value)


def present_synthesis_details(response: GetSynthesisResponse) -> None:
    output = OutputService.get()

    fields = [
        FieldConfig("id", "ID", str),
        FieldConfig("title", "Title"),
        FieldConfig("topic", "Topic"),
        FieldConfig("status", "Status"),
        FieldConfig("is_stale", "Is Stale"),
        FieldConfig("staleness_reason", "Staleness Reason"),
        FieldConfig("source_chunk_count", "Source Chunks"),
        FieldConfig("collection_ids", "Collections", _format_collection_ids),
        FieldConfig(
            "synthesizer_agent_id",
            "Synthesizer Agent ID",
            _format_optional_uuid,
        ),
        FieldConfig("execution_id", "Execution ID", _format_optional_uuid),
        FieldConfig("error_message", "Error Message"),
        FieldConfig("metadata", "Metadata", _format_metadata),
        FieldConfig("synthesis_content", "Synthesis Content"),
        FieldConfig("created_at", "Created At", _format_optional_datetime),
        FieldConfig("updated_at", "Updated At", _format_optional_datetime),
    ]

    output.entity(
        response,
        f"Synthesis: {response.title}",
        fields,
        raw_payload=response,
    )
