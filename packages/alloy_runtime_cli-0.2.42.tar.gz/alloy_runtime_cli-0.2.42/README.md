# alloy-runtime-cli

Terminal client for Alloy Runtime.

## Install

```bash
pip install alloy-runtime-cli
```

For isolated user installs, `pipx` is also a good fit:

```bash
pipx install alloy-runtime-cli
```

## Command

The installed command is `alloy`.

```bash
alloy --help
alloy --help-json
alloy --help-markdown
alloy --help-toon
alloy --format table pipelines list
alloy --format json agents list
alloy login
alloy credentials supported
alloy credentials supported --kind tools
alloy --api-url https://your-alloy-runtime-host ping
alloy api-keys create --scope read --scope update --scope use --description "automation key"
```

Use `alloy --help-json` when automation or agents need recursive machine-readable CLI help as JSON.
Use `alloy --help-markdown` for the same help tree rendered as Markdown.
Use `alloy --help-toon` for the same help tree rendered as TOON.
For session-wide help rendering, set `ALLOY_RUNTIME_HELP_FORMAT=json`, `ALLOY_RUNTIME_HELP_FORMAT=markdown`, or `ALLOY_RUNTIME_HELP_FORMAT=toon` and run `alloy --help`.

For scoped create commands such as `agents create`, `schemas create`, `tool-configs create`, and `templates create`, the CLI now defaults omitted ownership scope to **organization**. Pass `--scope user` only when you want a personal resource.

Use `alloy --format compact` for the existing psql-style human-readable record view.
Use `alloy --format table` for Rich table output in the non-TUI CLI.
Use `alloy --format json` for automation-friendly machine-readable output.

`alloy ping` is the authenticated connectivity check. It confirms who you are, which host you reached, and which server build answered the request.

The CLI pins `toon-format` from the upstream GitHub source because the PyPI stub release is not usable yet.

## Configuration

The CLI reads configuration in this order:

1. CLI flags such as `--api-url` and `--api-key`
2. Environment variables like `ALLOY_RUNTIME_API_URL`
3. Stored credentials in `~/.alloy-runtime/config`

Use `alloy login` to save an API key locally, or set the environment variables when
running on a VPS.

