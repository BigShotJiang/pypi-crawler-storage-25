# Full API

## Differentiation

::: asdex.jacobian
::: asdex.value_and_jacobian
::: asdex.hessian
::: asdex.value_and_hessian

---

::: asdex.jacobian_from_coloring
::: asdex.value_and_jacobian_from_coloring
::: asdex.hessian_from_coloring
::: asdex.value_and_hessian_from_coloring

## Coloring

::: asdex.jacobian_coloring
::: asdex.hessian_coloring

---

::: asdex.jacobian_coloring_from_sparsity
::: asdex.hessian_coloring_from_sparsity

---

::: asdex.color_rows
::: asdex.color_cols
::: asdex.color_symmetric

## Visualization

::: asdex.spy

## Sparsity Detection

::: asdex.jacobian_sparsity
::: asdex.hessian_sparsity

## Data Structures

::: asdex.SparsityPattern
::: asdex.ColoredPattern

---

::: asdex.JacobianMode
::: asdex.HessianMode
::: asdex.VerificationError
