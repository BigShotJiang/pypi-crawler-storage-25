"""Sidebar menu entries owned by the base module.

Only the Dashboard and Apps roots live here — other navigation groups
(Settings, Security, Workflows) belong to the ``admin`` module, since
they front admin-owned models. Apps that ship their own pages
contribute their own MENUS through their data files (see crm,
partners, etc.).
"""

from pyvelm.builders import menu_item
from pyvelm.types import Menu

_ICON_HOME = (
    '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.8">'
    '<path stroke-linecap="round" stroke-linejoin="round" '
    'd="M2.25 12l8.954-8.955a1.5 1.5 0 012.122 0l8.954 8.955M4.5 9.75v9.75a.75.75 0 '
    '00.75.75H9V15a1.5 1.5 0 011.5-1.5h3a1.5 1.5 0 011.5 1.5v5.25h3.75a.75.75 0 '
    '00.75-.75V9.75M8.25 21h7.5"/></svg>'
)

_ICON_APPS = (
    '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.8">'
    '<path stroke-linecap="round" stroke-linejoin="round" '
    'd="M14.25 6.087c0-.355.186-.676.401-.959.221-.29.349-.634.349-1.003 0-1.036-1.007-1.875-2.25-1.875s-2.25.84-2.25 1.875c0 .369.128.713.349 1.003.215.283.401.604.401.959v0a.64.64 0 01-.657.643 48.39 48.39 0 01-4.163-.3c.186 1.613.293 3.25.315 4.907a.656.656 0 01-.658.663v0c-.355 0-.676-.186-.959-.401a1.647 1.647 0 00-1.003-.349c-1.036 0-1.875 1.007-1.875 2.25s.84 2.25 1.875 2.25c.369 0 .713-.128 1.003-.349.283-.215.604-.401.959-.401v0c.31 0 .555.26.532.57a48.039 48.039 0 01-.642 5.056c1.518.19 3.058.309 4.616.354a.64.64 0 00.657-.643v0c0-.355-.186-.676-.401-.959a1.647 1.647 0 01-.349-1.003c0-1.035 1.008-1.875 2.25-1.875 1.243 0 2.25.84 2.25 1.875 0 .369-.128.713-.349 1.003-.215.283-.4.604-.4.959v0c0 .333.277.599.61.58a48.1 48.1 0 005.427-.63 48.05 48.05 0 00.582-4.717.532.532 0 00-.533-.57v0c-.355 0-.676.186-.959.401-.29.221-.634.349-1.003.349-1.035 0-1.875-1.007-1.875-2.25s.84-2.25 1.875-2.25c.37 0 .713.128 1.003.349.283.215.604.401.96.401v0a.656.656 0 00.658-.663 48.422 48.422 0 00-.37-5.36c-1.886.342-3.81.574-5.766.689a.578.578 0 01-.61-.58v0z"/></svg>'
)


# Root-level standalone items (no parent group, icon shown in sidebar).
MENUS: list[Menu] = [
    menu_item("dashboard", "Dashboard", href="/web/admin", icon=_ICON_HOME, sequence=10),
    menu_item("apps",      "Apps",      href="/web/apps",  icon=_ICON_APPS, sequence=100),
]
