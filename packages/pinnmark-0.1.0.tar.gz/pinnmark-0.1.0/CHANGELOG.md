# Changelog

## 0.1.0 - 2026-04-18

### Added
- Initial `pinnmark` PyPI packaging layer on top of the existing `pinn_bench` runtime.
- Console entry point `pinnmark-run`.
- Packaging metadata via `setup.py`, `pyproject.toml`, and `MANIFEST.in`.
- Versioned `requirements.txt` for runtime dependencies.
- README install instructions for `pip install pinnmark`.

### Packaging
- Publishable distribution now includes the `pinnmark` facade package and the existing `pinn_bench` implementation package.
- Source distributions exclude heavy benchmark artifacts, outputs, papers, figures, and tests from the installable package payload.

### CLI
- `pinnmark-run --help` now proxies to the benchmark CLI.
- `pinnmark-run --version` reports the published package version.

### Notes
- The packaged CLI is intended for benchmark execution and inspection commands provided by `pinn_bench`.
- Full repository benchmark assets remain in the source repository and are not bundled into the PyPI wheel.
