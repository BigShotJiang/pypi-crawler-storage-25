"""PyPI-facing CLI facade for PINNMark."""

from __future__ import annotations

from collections.abc import Sequence
import sys

from pinn_bench import __version__ as PINNMARK_VERSION
from pinn_bench.run import main as pinn_bench_main


def main(argv: Sequence[str] | None = None) -> None:
    resolved = list(sys.argv[1:] if argv is None else argv)
    if any(flag in resolved for flag in {"--version", "-V"}):
        print(f"pinnmark {PINNMARK_VERSION}")
        return
    pinn_bench_main(resolved)


if __name__ == "__main__":
    main()
