"""PyPI-facing PINNMark facade package."""

from __future__ import annotations

from pinn_bench import __version__ as __version__

from . import run_full_inverse_benchmark

__all__ = ["__version__", "run_full_inverse_benchmark"]
