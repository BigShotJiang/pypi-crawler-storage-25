from __future__ import annotations

from pinnmark.run_full_inverse_benchmark import main


if __name__ == "__main__":
    main()
