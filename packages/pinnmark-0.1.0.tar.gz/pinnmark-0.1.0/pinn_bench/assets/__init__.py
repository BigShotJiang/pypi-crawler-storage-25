"""Package assets for benchmark reference data."""
