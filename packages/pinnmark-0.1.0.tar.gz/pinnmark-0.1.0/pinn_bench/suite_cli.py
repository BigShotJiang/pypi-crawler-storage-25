"""CLI front door for suite-level execution and inspection."""

from __future__ import annotations

import argparse
import json
from collections.abc import Sequence

from pinn_bench.suite import Suite
from pinn_bench.suite_frontdoor import (
    default_launch_manifest_path,
    format_suite_inspect_summary,
    format_suite_list,
    format_suite_run_summary,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pinn-bench suite",
        description=(
            "Unified suite front door for the NeurIPS 2026 first-wave suites. "
            "Use this when you want one entrypoint for native, transfer, and reference suites."
        ),
    )
    subparsers = parser.add_subparsers(dest="suite_command")

    list_parser = subparsers.add_parser("list", help="List the available suite names and runner types.")
    list_parser.add_argument(
        "--launch-manifest",
        default=str(default_launch_manifest_path()),
        help="Override the compiled first-wave launch manifest.",
    )
    list_parser.add_argument("--json", action="store_true", help="Emit JSON instead of plain text.")

    run_parser = subparsers.add_parser("run", help="Run one suite through a single thin front door.")
    run_parser.add_argument("--suite", required=True, help="Stable suite name.")
    run_parser.add_argument(
        "--launch-manifest",
        default=str(default_launch_manifest_path()),
        help="Override the compiled first-wave launch manifest.",
    )
    run_parser.add_argument(
        "--results-root",
        default=None,
        help=(
            "Optional custom results root. By default suite run writes to a safe local root under "
            "outputs_playground/suite_runs/<suite_name>."
        ),
    )
    run_parser.add_argument(
        "--use-launch-root",
        action="store_true",
        help="Run against the launch manifest's configured results root instead of the safe local suite root.",
    )
    run_parser.add_argument(
        "--family-id",
        action="append",
        default=None,
        help="Optional exact family id filter. Repeat to run multiple families.",
    )
    run_parser.add_argument(
        "--seeds",
        nargs="+",
        type=int,
        default=None,
        help="Optional runtime seeds override.",
    )
    run_parser.add_argument(
        "--max-runs",
        type=int,
        default=None,
        help="Optional maximum expanded runs. Applies only to native matrix suites.",
    )
    run_parser.add_argument(
        "--skip-existing",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Skip completed runs. Use --no-skip-existing to force reruns.",
    )
    run_parser.add_argument("--dry-run", action="store_true", help="Plan without launching training.")
    run_parser.add_argument("--json", action="store_true", help="Emit JSON instead of plain text.")

    inspect_parser = subparsers.add_parser(
        "inspect",
        help="Show one suite summary that unifies runtime, figures, claims, and key artifact paths.",
    )
    inspect_parser.add_argument("--suite", required=True, help="Stable suite name.")
    inspect_parser.add_argument(
        "--launch-manifest",
        default=str(default_launch_manifest_path()),
        help="Override the compiled first-wave launch manifest.",
    )
    inspect_parser.add_argument(
        "--results-root",
        default=None,
        help=(
            "Optional custom runtime root to inspect. By default inspect prefers an existing "
            "outputs_playground/suite_runs/<suite_name> root and otherwise falls back to the launch root."
        ),
    )
    inspect_parser.add_argument(
        "--use-launch-root",
        action="store_true",
        help="Inspect the launch manifest's configured runtime root even if a local suite root exists.",
    )
    inspect_parser.add_argument("--json", action="store_true", help="Emit JSON instead of plain text.")
    return parser


def main(argv: Sequence[str] | None = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)
    if not args.suite_command:
        parser.print_help()
        return

    if args.suite_command == "list":
        payload = {
            "launch_manifest_path": args.launch_manifest,
            "suites": [entry.to_dict() for entry in Suite.catalog(args.launch_manifest)],
        }
        if args.json:
            print(json.dumps(payload, indent=2))
            return
        print(format_suite_list(payload["suites"]))
        return

    if args.suite_command == "run":
        suite = Suite.load(args.suite, launch_manifest_path=args.launch_manifest)
        payload = suite.run(
            results_root=args.results_root,
            use_launch_root=bool(args.use_launch_root),
            family_ids=args.family_id,
            seeds=args.seeds,
            max_runs=args.max_runs,
            skip_existing=bool(args.skip_existing),
            dry_run=bool(args.dry_run),
        )
        if args.json:
            print(json.dumps(payload.to_dict(), indent=2))
            return
        print(format_suite_run_summary(payload))
        return

    if args.suite_command == "inspect":
        suite = Suite.load(args.suite, launch_manifest_path=args.launch_manifest)
        payload = suite.summary(
            results_root=args.results_root,
            use_launch_root=bool(args.use_launch_root),
        )
        if args.json:
            print(json.dumps(payload.to_dict(), indent=2))
            return
        print(format_suite_inspect_summary(payload))
        return

    raise SystemExit(f"Unknown suite subcommand '{args.suite_command}'.")
