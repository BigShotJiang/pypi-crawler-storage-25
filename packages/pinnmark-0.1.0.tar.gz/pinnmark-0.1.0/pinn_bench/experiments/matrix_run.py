"""Local sequential runner for formal matrix experiments."""

from __future__ import annotations

import argparse
import csv
import json
import subprocess
import sys
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter

from pinn_bench.leaderboard.aggregate import load_matrix_manifest
from pinn_bench.resources import resolve_manifest_path, resolve_repo_root

REPORT_COLUMNS = [
    "family_id",
    "seed",
    "config_path",
    "output_dir",
    "status",
    "return_code",
    "duration_seconds",
    "error_message",
]
COMPLETE_ARTIFACTS = ("metrics.json", "config_snapshot.yaml")
STDERR_TAIL_LINES = 20


@dataclass(frozen=True)
class MatrixRunPlan:
    family_id: str
    seed: int
    config_path: Path
    output_dir: Path


@dataclass(frozen=True)
class MatrixContext:
    matrix_name: str
    manifest_path: Path
    outputs_root: Path
    report_dir: Path
    report_json_path: Path
    report_csv_path: Path



def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run a formal PINN baseline matrix sequentially.")
    parser.add_argument("--matrix-manifest", required=True, type=str, help="Path to baseline matrix manifest YAML.")
    parser.add_argument(
        "--outputs-root",
        type=str,
        default=None,
        help="Optional results root override. Defaults to manifest results_root.",
    )
    parser.add_argument("--skip-existing", action="store_true", help="Skip runs with completed output artifacts.")
    parser.add_argument(
        "--seeds",
        nargs="+",
        type=int,
        default=None,
        help="Optional seed override list. Defaults to manifest default_seeds.",
    )
    parser.add_argument(
        "--family-filter",
        type=str,
        default=None,
        help="Optional case-insensitive substring filter on family run_id.",
    )
    parser.add_argument(
        "--run-id",
        nargs="+",
        default=None,
        help="Optional exact family run_id selection. Mutually exclusive with --family-filter.",
    )
    parser.add_argument(
        "--max-runs",
        type=int,
        default=None,
        help="Optional limit on expanded runs after filtering.",
    )
    parser.add_argument("--dry-run", action="store_true", help="Plan runs and write reports without launching training.")
    return parser



def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    return build_parser().parse_args(argv)



def normalize_seed_override(seeds: Sequence[int] | None) -> list[int] | None:
    if seeds is None:
        return None
    ordered: list[int] = []
    seen: set[int] = set()
    for seed in seeds:
        if seed in seen:
            continue
        seen.add(seed)
        ordered.append(int(seed))
    if not ordered:
        raise ValueError("Seed override must contain at least one integer.")
    return ordered



def normalize_run_ids(run_ids: Sequence[str] | None) -> list[str] | None:
    if run_ids is None:
        return None
    ordered: list[str] = []
    seen: set[str] = set()
    for run_id in run_ids:
        normalized = str(run_id).strip()
        if not normalized or normalized in seen:
            continue
        seen.add(normalized)
        ordered.append(normalized)
    if not ordered:
        raise ValueError("--run-id must contain at least one non-empty family id.")
    return ordered



def derive_matrix_name(manifest_path: Path) -> str:
    return manifest_path.stem



def build_matrix_context(manifest_path: Path, outputs_root: Path) -> MatrixContext:
    matrix_name = derive_matrix_name(manifest_path)
    report_dir = outputs_root / "_matrix_runs"
    return MatrixContext(
        matrix_name=matrix_name,
        manifest_path=manifest_path.resolve(),
        outputs_root=outputs_root,
        report_dir=report_dir,
        report_json_path=report_dir / f"{matrix_name}_run_report.json",
        report_csv_path=report_dir / f"{matrix_name}_run_report.csv",
    )



def _resolve_outputs_root(manifest: dict, outputs_root_override: str | None) -> Path:
    if outputs_root_override is not None:
        return Path(outputs_root_override).resolve()
    manifest_path = Path(manifest["manifest_path"])
    configured_root = Path(str(manifest["results_root"]))
    if configured_root.is_absolute():
        return configured_root.resolve()
    repo_root = resolve_repo_root(manifest_path)
    project_management_root = (repo_root / "project_management").resolve()
    if project_management_root in manifest_path.resolve().parents:
        return (repo_root / configured_root).resolve()
    if len(manifest_path.parents) >= 3:
        return (manifest_path.parents[2] / configured_root).resolve()
    return (Path.cwd() / configured_root).resolve()



def build_execution_plan(
    manifest: dict,
    outputs_root: Path,
    seeds_override: Sequence[int] | None = None,
    family_filter: str | None = None,
    run_ids: Sequence[str] | None = None,
    max_runs: int | None = None,
) -> list[MatrixRunPlan]:
    if family_filter is not None and run_ids is not None:
        raise ValueError("--run-id and --family-filter are mutually exclusive.")
    seeds = manifest["default_seeds"] if seeds_override is None else normalize_seed_override(seeds_override)
    selected_run_ids = normalize_run_ids(run_ids)
    filter_value = None if family_filter is None else family_filter.strip().lower()
    if selected_run_ids is not None:
        available_runs = {str(run["run_id"]): run for run in manifest["runs"]}
        missing_run_ids = [run_id for run_id in selected_run_ids if run_id not in available_runs]
        if missing_run_ids:
            raise ValueError("Unknown matrix run_id(s): " + ", ".join(missing_run_ids))
        candidate_runs = [available_runs[run_id] for run_id in selected_run_ids]
    elif filter_value:
        candidate_runs = [run for run in manifest["runs"] if filter_value in str(run["run_id"]).lower()]
    else:
        candidate_runs = list(manifest["runs"])
    if not candidate_runs:
        filter_label = family_filter if family_filter is not None else "<empty>"
        raise ValueError(f"No matrix runs matched family filter '{filter_label}'.")
    if max_runs is not None and max_runs <= 0:
        raise ValueError("--max-runs must be a positive integer when provided.")

    plans: list[MatrixRunPlan] = []
    for run in candidate_runs:
        run_id = str(run["run_id"])
        config_path = Path(run["resolved_config_path"]).resolve()
        for seed in seeds:
            plans.append(
                MatrixRunPlan(
                    family_id=run_id,
                    seed=int(seed),
                    config_path=config_path,
                    output_dir=(outputs_root / f"{run_id}_seed{seed}").resolve(),
                )
            )
    if max_runs is not None:
        plans = plans[:max_runs]
    return plans



def is_completed_run(output_dir: Path) -> bool:
    return all((output_dir / artifact_name).exists() for artifact_name in COMPLETE_ARTIFACTS)



def summarize_stderr(stderr: str) -> str | None:
    text = stderr.strip()
    if not text:
        return None
    lines = text.splitlines()
    tail = lines[-STDERR_TAIL_LINES:]
    return "\n".join(tail)



def run_plan_entry(plan: MatrixRunPlan, repo_root: Path) -> dict[str, object]:
    command = [
        sys.executable,
        "-m",
        "pinn_bench.run",
        "--config",
        str(plan.config_path),
        "--seed",
        str(plan.seed),
        "--output-dir",
        str(plan.output_dir),
    ]
    started_at = perf_counter()
    completed = subprocess.run(command, cwd=repo_root, check=False, capture_output=True, text=True)
    duration_seconds = round(perf_counter() - started_at, 6)
    succeeded = completed.returncode == 0
    return {
        "family_id": plan.family_id,
        "seed": plan.seed,
        "config_path": str(plan.config_path),
        "output_dir": str(plan.output_dir),
        "status": "succeeded" if succeeded else "failed",
        "return_code": int(completed.returncode),
        "duration_seconds": duration_seconds,
        "error_message": None if succeeded else summarize_stderr(completed.stderr),
    }



def create_report_entry(
    plan: MatrixRunPlan,
    *,
    status: str,
    return_code: int | None = None,
    duration_seconds: float | None = None,
    error_message: str | None = None,
) -> dict[str, object]:
    return {
        "family_id": plan.family_id,
        "seed": int(plan.seed),
        "config_path": str(plan.config_path),
        "output_dir": str(plan.output_dir),
        "status": status,
        "return_code": return_code,
        "duration_seconds": duration_seconds,
        "error_message": error_message,
    }



def build_summary(entries: Sequence[dict[str, object]]) -> dict[str, int]:
    return {
        "total_runs_planned": len(entries),
        "total_runs_attempted": sum(1 for entry in entries if entry["status"] in {"succeeded", "failed"}),
        "total_runs_succeeded": sum(1 for entry in entries if entry["status"] == "succeeded"),
        "total_runs_failed": sum(1 for entry in entries if entry["status"] == "failed"),
        "total_runs_skipped": sum(1 for entry in entries if entry["status"] == "skipped"),
    }



def write_csv_report(path: Path, rows: Sequence[dict[str, object]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=REPORT_COLUMNS)
        writer.writeheader()
        for row in rows:
            writer.writerow({column: row.get(column) for column in REPORT_COLUMNS})



def write_report(context: MatrixContext, entries: Sequence[dict[str, object]]) -> dict[str, object]:
    context.report_dir.mkdir(parents=True, exist_ok=True)
    payload = {
        "matrix_name": context.matrix_name,
        "manifest_path": str(context.manifest_path),
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "outputs_root": str(context.outputs_root),
        "summary": build_summary(entries),
        "runs": list(entries),
    }
    context.report_json_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    write_csv_report(context.report_csv_path, entries)
    return payload



def execute_matrix_runs(
    manifest_path: Path,
    *,
    outputs_root_override: str | None = None,
    seeds_override: Sequence[int] | None = None,
    family_filter: str | None = None,
    run_ids: Sequence[str] | None = None,
    max_runs: int | None = None,
    skip_existing: bool = False,
    dry_run: bool = False,
) -> dict[str, object]:
    manifest = load_matrix_manifest(manifest_path)
    outputs_root = _resolve_outputs_root(manifest, outputs_root_override)
    plans = build_execution_plan(
        manifest=manifest,
        outputs_root=outputs_root,
        seeds_override=seeds_override,
        family_filter=family_filter,
        run_ids=run_ids,
        max_runs=max_runs,
    )
    context = build_matrix_context(manifest_path=Path(manifest["manifest_path"]), outputs_root=outputs_root)
    repo_root = Path(__file__).resolve().parents[2]

    entries: list[dict[str, object]] = []
    for plan in plans:
        if skip_existing and is_completed_run(plan.output_dir):
            entries.append(create_report_entry(plan, status="skipped"))
            write_report(context, entries)
            continue
        if dry_run:
            entries.append(create_report_entry(plan, status="planned"))
            write_report(context, entries)
            continue
        entries.append(run_plan_entry(plan, repo_root=repo_root))
        write_report(context, entries)

    return write_report(context, entries)



def _format_run_label(entry: dict[str, object]) -> str:
    return f"{entry['family_id']} seed={entry['seed']} -> {entry['status']}"



def main(argv: Sequence[str] | None = None) -> None:
    args = parse_args(argv)
    manifest_path = resolve_manifest_path(args.matrix_manifest)
    payload = execute_matrix_runs(
        manifest_path=manifest_path,
        outputs_root_override=args.outputs_root,
        seeds_override=args.seeds,
        family_filter=args.family_filter,
        run_ids=args.run_id,
        max_runs=args.max_runs,
        skip_existing=bool(args.skip_existing),
        dry_run=bool(args.dry_run),
    )
    print(f"Matrix report written to {payload['outputs_root']}/_matrix_runs")
    summary = payload["summary"]
    print(
        "Planned {planned} runs: attempted={attempted}, succeeded={succeeded}, failed={failed}, skipped={skipped}".format(
            planned=summary["total_runs_planned"],
            attempted=summary["total_runs_attempted"],
            succeeded=summary["total_runs_succeeded"],
            failed=summary["total_runs_failed"],
            skipped=summary["total_runs_skipped"],
        )
    )
    if args.dry_run:
        for entry in payload["runs"]:
            print(_format_run_label(entry))


if __name__ == "__main__":
    main()
