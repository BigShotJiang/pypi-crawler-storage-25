"""Snapshot formal release assets and archive run reports."""

from __future__ import annotations

import argparse
import csv
import json
import shutil
from collections.abc import Mapping, Sequence
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from pinn_bench.utils.io import write_json

RELEASE_SNAPSHOT_FILENAME = "_release_snapshot.json"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Snapshot formal release assets and archive the latest run report.")
    parser.add_argument("--outputs-root", required=True, type=str, help="Formal outputs root, for example outputs_v02.")
    parser.add_argument("--matrix-name", required=True, type=str, help="Formal matrix name, for example baseline_v0_2.")
    parser.add_argument("--version-label", required=True, type=str, help="Frozen version label, for example v0.2.")
    parser.add_argument("--tag", default=None, type=str, help="Optional path-safe tag appended to archived run report filenames.")
    return parser



def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    return build_parser().parse_args(argv)



def _normalize_tag(tag: str | None) -> str | None:
    if tag is None:
        return None
    normalized = tag.strip().replace(" ", "_")
    if not normalized:
        raise ValueError("Snapshot tag must not be empty when provided.")
    if "/" in normalized or "\\" in normalized:
        raise ValueError("Snapshot tag must not contain path separators.")
    return normalized



def require_file(path: Path, *, label: str) -> Path:
    if not path.exists():
        raise FileNotFoundError(f"{label} does not exist: {path}")
    return path



def load_json_file(path: Path, *, label: str) -> dict[str, Any]:
    resolved = require_file(path, label=label)
    payload = json.loads(resolved.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        raise ValueError(f"{label} must contain a top-level mapping: {resolved}")
    return dict(payload)



def count_csv_rows(path: Path, *, label: str) -> int:
    resolved = require_file(path, label=label)
    with resolved.open("r", encoding="utf-8", newline="") as handle:
        return sum(1 for _ in csv.DictReader(handle))



def _utc_now() -> datetime:
    return datetime.now(timezone.utc)



def _format_history_timestamp(moment: datetime) -> str:
    return moment.strftime("%Y%m%dT%H%M%SZ")



def snapshot_release_assets(
    *,
    outputs_root: Path,
    matrix_name: str,
    version_label: str,
    tag: str | None = None,
) -> dict[str, Any]:
    resolved_outputs_root = Path(outputs_root).resolve()
    normalized_tag = _normalize_tag(tag)

    report_dir = resolved_outputs_root / "_matrix_runs"
    report_json_path = report_dir / f"{matrix_name}_run_report.json"
    report_csv_path = report_dir / f"{matrix_name}_run_report.csv"
    grouped_json_path = resolved_outputs_root / "_leaderboard" / "leaderboard_grouped.json"
    reporting_csv_path = resolved_outputs_root / "_leaderboard" / "reporting" / f"{matrix_name}_baseline_table.csv"
    pareto_csv_path = resolved_outputs_root / "_leaderboard" / "pareto" / f"{matrix_name}_pareto.csv"

    run_report = load_json_file(report_json_path, label="Run report JSON")
    grouped_payload = load_json_file(grouped_json_path, label="Grouped leaderboard JSON")
    require_file(report_csv_path, label="Run report CSV")

    if str(run_report.get("matrix_name", "")) != matrix_name:
        raise ValueError(
            f"Run report matrix_name '{run_report.get('matrix_name')}' does not match requested matrix '{matrix_name}'."
        )

    summary = run_report.get("summary")
    if not isinstance(summary, Mapping):
        raise ValueError(f"Run report summary must be a mapping: {report_json_path}")

    snapshot_moment = _utc_now()
    snapshot_generated_at = snapshot_moment.isoformat()
    archive_timestamp = _format_history_timestamp(snapshot_moment)

    reporting_rows = count_csv_rows(reporting_csv_path, label="Reporting CSV")
    pareto_rows = count_csv_rows(pareto_csv_path, label="Pareto CSV")

    snapshot_payload: dict[str, Any] = {
        "version": version_label,
        "matrix_name": matrix_name,
        "manifest_path": str(run_report.get("manifest_path", "")),
        "outputs_root": str(resolved_outputs_root),
        "generated_at": snapshot_generated_at,
        "run_report_generated_at": str(run_report.get("generated_at", "")),
        "planned": int(summary.get("total_runs_planned", 0) or 0),
        "attempted": int(summary.get("total_runs_attempted", 0) or 0),
        "succeeded": int(summary.get("total_runs_succeeded", 0) or 0),
        "failed": int(summary.get("total_runs_failed", 0) or 0),
        "skipped": int(summary.get("total_runs_skipped", 0) or 0),
        "grouped_rows": len(grouped_payload.get("rows", [])),
        "grouped_warnings": len(grouped_payload.get("warnings", [])),
        "reporting_rows": reporting_rows,
        "pareto_rows": pareto_rows,
    }

    snapshot_path = resolved_outputs_root / RELEASE_SNAPSHOT_FILENAME
    write_json(snapshot_path, snapshot_payload)

    history_dir = report_dir / "history"
    history_dir.mkdir(parents=True, exist_ok=True)
    tag_suffix = "" if normalized_tag is None else f"_{normalized_tag}"
    archived_json_path = history_dir / f"{matrix_name}_run_report_{archive_timestamp}{tag_suffix}.json"
    archived_csv_path = history_dir / f"{matrix_name}_run_report_{archive_timestamp}{tag_suffix}.csv"
    shutil.copy2(report_json_path, archived_json_path)
    shutil.copy2(report_csv_path, archived_csv_path)

    return {
        "snapshot_path": str(snapshot_path),
        "archived_json_path": str(archived_json_path),
        "archived_csv_path": str(archived_csv_path),
        "history_dir": str(history_dir),
        "snapshot": snapshot_payload,
    }


# Backward-compatible internal aliases for older imports.
_require_file = require_file
_load_json = load_json_file
_count_csv_rows = count_csv_rows



def main(argv: Sequence[str] | None = None) -> None:
    args = parse_args(argv)
    result = snapshot_release_assets(
        outputs_root=Path(args.outputs_root),
        matrix_name=args.matrix_name,
        version_label=args.version_label,
        tag=args.tag,
    )
    print(f"Release snapshot written to {result['snapshot_path']}")
    print(f"Archived run report JSON to {result['archived_json_path']}")
    print(f"Archived run report CSV to {result['archived_csv_path']}")


if __name__ == "__main__":
    main()
