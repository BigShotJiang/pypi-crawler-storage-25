"""Adaptive sampling helpers for solver profiles that resample interior points."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import replace
from typing import Any

import torch

from pinn_bench.tasks.base import SampleBatch, TrainBatches


def _to_mapping(value: Any) -> Mapping[str, Any]:
    if isinstance(value, Mapping):
        return value
    return {}


def maybe_adapt_train_batches(
    *,
    task: Any,
    model: torch.nn.Module,
    batches: TrainBatches,
    sampling_config: Mapping[str, Any] | None,
    device: torch.device,
) -> TrainBatches:
    """Apply residual-adaptive resampling without changing the total interior point budget."""

    config = _to_mapping(sampling_config)
    strategy = str(config.get("strategy", "uniform")).strip().lower()
    if strategy != "residual_adaptive":
        return batches
    if batches.interior is None or batches.interior.inputs.shape[0] == 0:
        return batches

    candidate_multiplier = max(1, int(config.get("candidate_multiplier", 4)))
    if candidate_multiplier == 1:
        return batches
    if not hasattr(task, "compute_residual"):
        return batches

    original_count = int(batches.interior.inputs.shape[0])
    candidate_batches: list[SampleBatch] = [batches.interior]
    for _ in range(candidate_multiplier - 1):
        extra_batches = task.sample_train_batches(device=device)
        if extra_batches.interior is None or extra_batches.interior.inputs.shape[0] == 0:
            continue
        candidate_batches.append(extra_batches.interior)

    if len(candidate_batches) == 1:
        return batches

    candidate_inputs = torch.cat([batch.inputs for batch in candidate_batches], dim=0)
    model_was_training = model.training
    try:
        model.eval()
        residuals = task.compute_residual(model=model, inputs=candidate_inputs)
    finally:
        if model_was_training:
            model.train()

    residual_values = residuals.detach()
    if residual_values.ndim > 1:
        residual_scores = residual_values.reshape(residual_values.shape[0], -1).abs().mean(dim=1)
    else:
        residual_scores = residual_values.abs()
    selected = torch.topk(residual_scores, k=original_count, largest=True).indices
    ordered_selected = torch.sort(selected).values
    adapted_interior = SampleBatch(
        inputs=candidate_inputs.index_select(0, ordered_selected),
        targets=None if batches.interior.targets is None else batches.interior.targets,
        weights=None if batches.interior.weights is None else batches.interior.weights,
        metadata={
            **dict(batches.interior.metadata),
            "sampling_strategy": "residual_adaptive",
            "adaptive_candidate_count": int(candidate_inputs.shape[0]),
        },
    )
    return replace(batches, interior=adapted_interior)
