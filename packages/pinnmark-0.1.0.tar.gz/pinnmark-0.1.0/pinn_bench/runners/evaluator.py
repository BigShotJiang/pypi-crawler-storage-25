"""Evaluation loop implementation."""

from __future__ import annotations

from typing import Any

import torch

from pinn_bench.registry import get_metric
from pinn_bench.tasks.base import BaseTask, EvaluationBatch, weighted_mse_loss


class Evaluator:
    """Minimal evaluator with additive field-output support."""

    def __init__(
        self,
        model: torch.nn.Module,
        task: BaseTask,
        device: torch.device,
        metric_names: list[str],
        num_samples: int = 256,
        grid_x: int | None = None,
        grid_t: int | None = None,
        grid_y: int | None = None,
    ) -> None:
        self.model = model
        self.task = task
        self.device = device
        self.metric_names = metric_names
        self.num_samples = num_samples
        self.grid_x = grid_x
        self.grid_t = grid_t
        self.grid_y = grid_y
        self.last_batch_metadata: dict[str, Any] = {}

    def _evaluation_mode(self, batch: EvaluationBatch) -> str:
        metadata_mode = batch.metadata.get("evaluation_mode") if isinstance(batch.metadata, dict) else None
        if metadata_mode is not None:
            return str(metadata_mode)
        return str(getattr(self.task, "task_mode", "pointwise"))

    def _predict_field(self, batch: EvaluationBatch) -> torch.Tensor:
        grid_shape = batch.metadata.get("grid_shape") if isinstance(batch.metadata, dict) else None
        if not isinstance(grid_shape, (list, tuple)):
            raise ValueError("Field evaluation requires EvaluationBatch.metadata['grid_shape'].")

        condition_inputs = batch.metadata.get("condition_inputs") if isinstance(batch.metadata, dict) else None
        if hasattr(self.model, "forward_field"):
            return self.model.forward_field(
                condition_inputs=condition_inputs,
                query_inputs=batch.inputs,
                metadata=batch.metadata,
            )
        if bool(getattr(self.model, "supports_flattened_field", False)):
            return self.model(batch.inputs)
        raise ValueError(
            "Field evaluation requires a model with forward_field(...) or supports_flattened_field=True."
        )

    @staticmethod
    def _align_predictions(predictions: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        if predictions.shape == targets.shape:
            return predictions
        if predictions.numel() == targets.numel():
            return predictions.reshape_as(targets)
        raise ValueError(
            f"Prediction shape {tuple(predictions.shape)} does not match target shape {tuple(targets.shape)}."
        )

    @staticmethod
    def _resolve_metric_weights(batch: EvaluationBatch, targets: torch.Tensor) -> torch.Tensor | None:
        if not isinstance(batch.metadata, dict):
            return None
        weights = batch.metadata.get("metric_weights")
        if not isinstance(weights, torch.Tensor):
            return None
        resolved = weights.to(device=targets.device, dtype=targets.dtype)
        while resolved.ndim < targets.ndim:
            resolved = resolved.unsqueeze(-1)
        return resolved.expand_as(targets)

    @staticmethod
    def _weighted_relative_l2(predictions: torch.Tensor, targets: torch.Tensor, weights: torch.Tensor, eps: float = 1e-12) -> float:
        scaled_errors = torch.sqrt(weights) * (predictions - targets)
        scaled_targets = torch.sqrt(weights) * targets
        numerator = torch.linalg.norm(scaled_errors)
        denominator = torch.linalg.norm(scaled_targets) + eps
        return float((numerator / denominator).item())

    def _evaluate_builtin_metric(
        self,
        metric_name: str,
        *,
        predictions: torch.Tensor,
        targets: torch.Tensor,
        batch: EvaluationBatch,
    ) -> float:
        metric_fn = get_metric(metric_name)
        weights = self._resolve_metric_weights(batch, targets)
        if weights is None:
            return metric_fn(predictions, targets)
        if metric_name in {"mse", "field_mse"}:
            return float(weighted_mse_loss(predictions, targets, weights=weights).detach().item())
        if metric_name in {"relative_l2", "field_relative_l2"}:
            return self._weighted_relative_l2(predictions, targets, weights)
        return metric_fn(predictions, targets)

    def evaluate(self) -> dict[str, float]:
        """Evaluate model on a structured validation batch."""
        self.model.eval()
        with torch.no_grad():
            batch = self.task.sample_evaluation_batch(
                device=self.device,
                num_samples=self.num_samples,
                grid_x=self.grid_x,
                grid_t=self.grid_t,
                grid_y=self.grid_y,
            )
            self.last_batch_metadata = dict(batch.metadata)
            targets = batch.targets if batch.targets is not None else self.task.exact_solution(batch.inputs)
            if targets is None:
                raise ValueError("Evaluation requires targets or an exact solution.")

            if self._evaluation_mode(batch) == "field":
                predictions = self._predict_field(batch)
            else:
                predictions = self.model(batch.inputs)
            predictions = self._align_predictions(predictions, targets)
        metric_values: dict[str, float] = {}
        for metric_name in self.metric_names:
            try:
                metric_values[metric_name] = self._evaluate_builtin_metric(
                    metric_name,
                    predictions=predictions,
                    targets=targets,
                    batch=batch,
                )
                continue
            except KeyError:
                task_metric = self.task.compute_metric(
                    metric_name,
                    model=self.model,
                    batch=batch,
                    predictions=predictions,
                    targets=targets,
                )
                if task_metric is None:
                    raise
                metric_values[metric_name] = float(task_metric)
        return metric_values
