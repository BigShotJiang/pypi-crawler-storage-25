"""Runtime helpers for profile-contract execution semantics."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

import torch
from torch import nn

from pinn_bench.config.schema import ExperimentConfig


def resolve_profile_contract(config: ExperimentConfig) -> dict[str, Any]:
    value = config.train.extras.get("profile_contract", {})
    if isinstance(value, Mapping):
        return dict(value)
    return {}


class BoundaryLiftedPoissonModel(nn.Module):
    """Wrap a pointwise model with an exact zero-Dirichlet boundary lift."""

    def __init__(self, base_model: nn.Module, *, domain: Mapping[str, float]) -> None:
        super().__init__()
        self.base_model = base_model
        self.domain = {str(key): float(value) for key, value in domain.items()}
        self.model_mode = str(getattr(base_model, "model_mode", "pointwise"))

    def forward(self, inputs: torch.Tensor) -> torch.Tensor:
        x = inputs[:, :1]
        y = inputs[:, 1:2]
        factor = (
            (x - float(self.domain["x_min"]))
            * (float(self.domain["x_max"]) - x)
            * (y - float(self.domain["y_min"]))
            * (float(self.domain["y_max"]) - y)
        )
        return factor * self.base_model(inputs)


def apply_model_profile_contract(
    model: nn.Module,
    *,
    task_name: str,
    task_params: Mapping[str, Any],
    profile_contract: Mapping[str, Any] | None,
) -> nn.Module:
    contract = dict(profile_contract or {})
    semantics = str(contract.get("adapter_semantics", "")).strip()
    if semantics != "hard_constraint_boundary_profile":
        return model
    if task_name != "poisson2d":
        return model
    domain = task_params.get("domain")
    if not isinstance(domain, Mapping):
        return model
    return BoundaryLiftedPoissonModel(model, domain=domain)


def build_epoch_loss_weights(
    *,
    base_weights: Mapping[str, float],
    profile_contract: Mapping[str, Any] | None,
    epoch: int,
    total_epochs: int,
    previous_scalar_terms: Mapping[str, float] | None,
) -> tuple[dict[str, float], str | None]:
    weights = {str(name): float(value) for name, value in base_weights.items()}
    contract = dict(profile_contract or {})
    semantics = str(contract.get("adapter_semantics", "")).strip()

    if semantics == "residual_weighted":
        previous_physics = 0.0 if previous_scalar_terms is None else float(previous_scalar_terms.get("physics", 0.0))
        if epoch > 1:
            weights["physics"] = min(max(1.0 + min(max(previous_physics, 0.0), 1.0) * 3.0, 1.0), 4.0)
        return weights, "residual_weighted"

    if semantics == "curriculum":
        progress = 0.0 if total_epochs <= 0 else float(epoch - 1) / float(total_epochs)
        base_physics = float(weights.get("physics", 1.0))
        base_boundary = float(weights.get("boundary", 1.0))
        base_initial = float(weights.get("initial", 1.0))
        if progress < 0.25:
            weights["physics"] = base_physics * 0.5
            weights["boundary"] = base_boundary * 2.0
            if "initial" in weights:
                weights["initial"] = base_initial * 2.0
            return weights, "warmup"
        if progress >= 0.75:
            weights["physics"] = min(base_physics * 2.0, 4.0)
            weights["boundary"] = base_boundary
            if "initial" in weights:
                weights["initial"] = base_initial
            return weights, "late"
        return weights, "nominal"

    return weights, None
