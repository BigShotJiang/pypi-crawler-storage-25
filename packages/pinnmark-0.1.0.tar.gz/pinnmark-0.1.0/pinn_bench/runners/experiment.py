"""Experiment orchestrator."""

from __future__ import annotations

from pathlib import Path
from time import perf_counter
from collections.abc import Mapping
from typing import Any

from pinn_bench.config.schema import ExperimentConfig
from pinn_bench.logging.logger import BasicLogger
from pinn_bench.logging_hooks import build_logging_hook
from pinn_bench.plotting.curves import plot_loss_curve
from pinn_bench.registry import create_model, create_task, get_model_catalog_entry
from pinn_bench.results.schema import (
    ExternalModelMetadata,
    GeometryMetadata,
    InverseMetadata,
    PrimaryMethodMetadata,
    RegimeMetadata,
    RobustnessMetadata,
    RunMetadata,
    RunResults,
    TrainSummary,
)
from pinn_bench.results.writer import (
    save_config_snapshot,
    save_model,
    write_metrics,
    write_provenance,
    write_train_log,
)
from pinn_bench.robustness import RobustnessTaskAdapter, create_robustness_protocol
from pinn_bench.runners.evaluator import Evaluator
from pinn_bench.runners.profile_contracts import apply_model_profile_contract, resolve_profile_contract
from pinn_bench.runners.trainer import Trainer, summarize_history
from pinn_bench.utils.device import resolve_device
from pinn_bench.utils.paths import ensure_output_dir
from pinn_bench.utils.seed import set_seed


def _apply_external_runtime_hooks(
    *,
    model: Any,
    task: Any,
) -> Any:
    """Apply task-coupled hooks required by some external families."""
    marker = getattr(model, "__pinn_bench_external_constraint__", None)
    if not isinstance(marker, Mapping):
        return model
    kind = str(marker.get("kind", "")).strip().lower()
    if kind != "hard_constraint":
        return model
    from pinn_bench.models.external_adapters import HardConstraintWrappedModel

    alpha = float(marker.get("alpha", 5.0))
    return HardConstraintWrappedModel(base_model=model, task=task, alpha=alpha)


def _inverse_budget_class(*, protocol_name: str, level: float) -> str:
    if protocol_name == "sparsity":
        if level >= 0.5:
            return "moderate"
        if level >= 0.25:
            return "sparse"
        return "very_sparse"
    return "moderate"


def _inverse_pattern_family(*, protocol_name: str, target_scopes: list[str]) -> str:
    scopes = {str(scope).strip().lower() for scope in target_scopes if str(scope).strip()}
    if protocol_name == "bcic_corruption" or {"boundary", "initial"} & scopes:
        return "boundary_only"
    return "random_sensor"


def _normalize_inverse_metadata(
    *,
    task_name: str,
    robustness_protocol_name: str,
    robustness_level: float,
    target_scopes: list[str],
    metadata: Mapping[str, Any] | None,
) -> InverseMetadata | None:
    raw = metadata if isinstance(metadata, Mapping) else {}
    inverse_parameter_name = str(raw.get("inverse_parameter_name") or "").strip()
    if not inverse_parameter_name:
        return None
    inverse_target_family = str(raw.get("inverse_target_family") or "coefficient").strip() or "coefficient"
    inverse_target_type = str(raw.get("inverse_target_type") or "parameter").strip() or "parameter"
    observation_budget_class = str(raw.get("observation_budget_class") or "").strip() or _inverse_budget_class(
        protocol_name=robustness_protocol_name,
        level=robustness_level,
    )
    observation_pattern_family = str(raw.get("observation_pattern_family") or "").strip() or _inverse_pattern_family(
        protocol_name=robustness_protocol_name,
        target_scopes=target_scopes,
    )
    identifiability_metadata = raw.get("identifiability_metadata")
    diagnostic_status = str(raw.get("diagnostic_status") or "").strip() or None
    diagnostic_reason = str(raw.get("diagnostic_reason") or "").strip() or None
    return InverseMetadata(
        observation_budget_class=observation_budget_class,
        observation_pattern_family=observation_pattern_family,
        inverse_target_family=inverse_target_family,
        inverse_parameter_name=inverse_parameter_name,
        inverse_target_type=inverse_target_type,
        true_parameter_value=None if raw.get("true_parameter_value") is None else float(raw.get("true_parameter_value")),
        estimated_parameter_value=None
        if raw.get("estimated_parameter_value") is None
        else float(raw.get("estimated_parameter_value")),
        supervision_source=None if raw.get("supervision_source") is None else str(raw.get("supervision_source")),
        diagnostic_status=diagnostic_status,
        diagnostic_reason=diagnostic_reason,
        identifiability_metadata=dict(identifiability_metadata) if isinstance(identifiability_metadata, Mapping) else {},
    )


class ExperimentRunner:
    """Lightweight experiment runner that builds and executes one run."""

    def __init__(self, config: ExperimentConfig) -> None:
        self.config = config

    @classmethod
    def from_config(cls, config: ExperimentConfig) -> "ExperimentRunner":
        """Create an experiment runner from config."""
        return cls(config=config)

    def run(self) -> RunResults:
        """Run one end-to-end benchmark experiment."""
        set_seed(self.config.train.seed)
        device = resolve_device(self.config.train.device)
        output_dir = ensure_output_dir(self.config.output.root_dir)

        logger = BasicLogger(log_every=self.config.logging.log_every)
        logger.info(
            f"Starting run: model={self.config.model.name}, task={self.config.task.name}, device={device}"
        )

        tensorboard = build_logging_hook(backend=self.config.logging.backend, config=self.config, output_dir=output_dir)

        model_params = dict(self.config.model.params)
        primary_method_id = model_params.pop("_pinn_primary_method_id", None)
        model_params.pop("_pinn_requested_model_name", None)
        decomposition_config = self.config.train.extras.get("decomposition", {})
        if isinstance(decomposition_config, Mapping):
            for key, value in decomposition_config.items():
                model_params.setdefault(str(key), value)

        model_lookup_name = str(primary_method_id or self.config.model.name)
        model_entry = get_model_catalog_entry(model_lookup_name)
        model = create_model(model_lookup_name, **model_params)
        parameter_count = sum(parameter.numel() for parameter in model.parameters())
        raw_task_params = dict(self.config.task.params)
        task_params = dict(raw_task_params)
        task_params.pop("regime_slice", None)
        task = create_task(self.config.task.name, **task_params)
        model = apply_model_profile_contract(
            model,
            task_name=self.config.task.name,
            task_params=raw_task_params,
            profile_contract=resolve_profile_contract(self.config),
        ).to(device)
        model = _apply_external_runtime_hooks(model=model, task=task).to(device)
        task_parameter_count = sum(parameter.numel() for parameter in task.trainable_parameters())

        task_mode = str(getattr(task, "task_mode", "pointwise"))
        model_mode = str(getattr(model, "model_mode", "pointwise"))

        robustness_protocol = create_robustness_protocol(
            config=self.config.robustness,
            task_name=self.config.task.name,
            task=task,
            task_params=raw_task_params,
        )
        if robustness_protocol.protocol_name != "none":
            task = RobustnessTaskAdapter(
                task=task,
                protocol=robustness_protocol,
                task_name=self.config.task.name,
            )
        regime_metadata = robustness_protocol.regime_metadata_dict()
        geometry_metadata = robustness_protocol.geometry_metadata_dict()

        trainer = Trainer(
            model=model,
            task=task,
            config=self.config,
            device=device,
            logger=logger,
            tensorboard=tensorboard,
        )
        train_started_at = perf_counter()
        history = trainer.train()
        train_duration_seconds = round(perf_counter() - train_started_at, 6)

        evaluator = Evaluator(
            model=model,
            task=task,
            device=device,
            metric_names=self.config.metrics.names,
            num_samples=self.config.evaluation.num_samples,
            grid_x=self.config.evaluation.grid_x,
            grid_t=self.config.evaluation.grid_t,
            grid_y=self.config.evaluation.grid_y,
        )
        eval_metrics = evaluator.evaluate()
        if "parameter_relative_error" in eval_metrics and "inverse_target_relative_error" not in eval_metrics:
            eval_metrics["inverse_target_relative_error"] = float(eval_metrics["parameter_relative_error"])
        evaluation_mode = str(evaluator.last_batch_metadata.get("evaluation_mode") or task_mode)
        inverse_metadata = _normalize_inverse_metadata(
            task_name=self.config.task.name,
            robustness_protocol_name=robustness_protocol.protocol_name,
            robustness_level=float(robustness_protocol.level),
            target_scopes=list(robustness_protocol.resolved_target_scopes),
            metadata=evaluator.last_batch_metadata,
        )
        history_summary = summarize_history(history)
        runtime_external_entry = None
        if model_entry.get("external_model_id") is not None:
            runtime_external_entry = model_entry
        elif isinstance(model_entry.get("resolved_runtime_entry"), dict):
            candidate = model_entry["resolved_runtime_entry"]
            if candidate.get("external_model_id") is not None:
                runtime_external_entry = candidate

        results = RunResults(
            metadata=RunMetadata(
                task_name=self.config.task.name,
                model_name=str(model_entry.get("canonical_name") or self.config.model.name),
                seed=int(self.config.train.seed),
                device=str(device),
                robustness=RobustnessMetadata(
                    protocol=robustness_protocol.protocol_name,
                    level=float(robustness_protocol.level),
                    severity_label=robustness_protocol.severity_label,
                    target_scopes=list(robustness_protocol.resolved_target_scopes),
                    components=[dict(component) for component in robustness_protocol.components],
                    train_time_range=(
                        None if robustness_protocol.train_time_range is None else list(robustness_protocol.train_time_range)
                    ),
                    eval_time_range=(
                        None if robustness_protocol.eval_time_range is None else list(robustness_protocol.eval_time_range)
                    ),
                    train_support_ratio=robustness_protocol.train_support_ratio,
                    support_axis=robustness_protocol.support_axis,
                ),
                parameter_count=int(parameter_count),
                task_parameter_count=int(task_parameter_count),
                total_trainable_parameter_count=int(parameter_count + task_parameter_count),
                model_mode=model_mode,
                task_mode=task_mode,
                evaluation_mode=evaluation_mode,
                comparison=self.config.comparison,
                regime=None if regime_metadata is None else RegimeMetadata(**regime_metadata),
                geometry=None if geometry_metadata is None else GeometryMetadata(**geometry_metadata),
                inverse=inverse_metadata,
                external_model=(
                    None
                    if runtime_external_entry is None
                    else ExternalModelMetadata(
                        external_model_id=str(runtime_external_entry["external_model_id"]),
                        source_benchmark=str(runtime_external_entry["source_benchmark"]),
                        source_family_name=str(runtime_external_entry["source_family_name"]),
                        canonical_name=str(runtime_external_entry["canonical_name"]),
                        integration_state=str(runtime_external_entry["integration_state"]),
                        adapter_name=None if runtime_external_entry.get("adapter_name") is None else str(runtime_external_entry.get("adapter_name")),
                        runnable_status=None
                        if runtime_external_entry.get("runnable_status") is None
                        else str(runtime_external_entry.get("runnable_status")),
                        native_equivalent=None
                        if runtime_external_entry.get("native_equivalent") is None
                        else str(runtime_external_entry.get("native_equivalent")),
                        is_pinn_family=bool(runtime_external_entry.get("is_pinn_family")),
                        is_operator_family=bool(runtime_external_entry.get("is_operator_family")),
                        is_solver_adjacent=bool(runtime_external_entry.get("is_solver_adjacent")),
                        comparability_scope=None
                        if runtime_external_entry.get("comparability_scope") is None
                        else str(runtime_external_entry.get("comparability_scope")),
                        capability_tags=[str(item) for item in runtime_external_entry.get("capability_tags", [])],
                        repo_path=None if runtime_external_entry.get("repo_path") is None else str(runtime_external_entry.get("repo_path")),
                    )
                ),
                primary_method=(
                    None
                    if model_entry.get("kind") != "primary_method"
                    else PrimaryMethodMetadata(
                        method_id=str(model_entry["primary_method_id"]),
                        method_name=str(model_entry["primary_method_name"]),
                        top_level_family=str(model_entry["top_level_family"]),
                        benchmark_primary_subfamily=bool(model_entry.get("benchmark_primary_subfamily")),
                        formulation_type=str(model_entry["formulation_type"]),
                        internalization_level=str(model_entry["internalization_state"]),
                        runnable_status=str(model_entry["runnable_status"]),
                        comparability_status=str(model_entry["comparability_status"]),
                        evidence_status=str(model_entry["evidence_status"]),
                        source_lineage=[str(item) for item in model_entry.get("source_lineage", [])],
                        default_runtime_name=(
                            None
                            if model_entry.get("default_runtime_name") is None
                            else str(model_entry["default_runtime_name"])
                        ),
                    )
                ),
            ),
            train=TrainSummary(
                final_loss=float(history_summary["final_loss"]),
                best_loss=float(history_summary["best_loss"]),
                epochs=int(self.config.train.epochs),
                final_loss_terms=dict(history_summary["final_loss_terms"]),
                duration_seconds=float(train_duration_seconds),
            ),
            eval=eval_metrics,
        )

        save_config_snapshot(config=self.config, output_dir=output_dir)
        write_train_log(history=history, output_dir=output_dir)
        write_metrics(metrics=results.to_dict(), output_dir=output_dir)
        write_provenance(config=self.config, metrics=results.to_dict(), output_dir=output_dir)
        save_model(model=model, output_dir=output_dir)
        plot_loss_curve(history=history, output_path=output_dir / "loss_curve.png")

        tensorboard.close()
        logger.info(f"Run completed. Artifacts written to {Path(output_dir).resolve()}")
        return results



def run_experiment(config: ExperimentConfig) -> dict[str, object]:
    """Compatibility wrapper around ExperimentRunner."""
    return ExperimentRunner.from_config(config).run().to_dict()
