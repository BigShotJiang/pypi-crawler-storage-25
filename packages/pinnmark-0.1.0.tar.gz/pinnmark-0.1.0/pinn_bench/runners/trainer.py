"""Training loop implementation."""

from __future__ import annotations

from collections.abc import Sequence
from collections.abc import Mapping

import torch

from pinn_bench.config.schema import ExperimentConfig
from pinn_bench.logging.logger import BasicLogger
from typing import Any
from pinn_bench.losses.composer import LossComposer
from pinn_bench.runners.adaptive_sampling import maybe_adapt_train_batches
from pinn_bench.runners.profile_contracts import build_epoch_loss_weights, resolve_profile_contract
from pinn_bench.tasks.base import BaseTask


class Trainer:
    """Minimal trainer for Phase 2."""

    def __init__(
        self,
        model: torch.nn.Module,
        task: BaseTask,
        config: ExperimentConfig,
        device: torch.device,
        logger: BasicLogger,
        tensorboard: Any,
    ) -> None:
        self.model = model
        self.task = task
        self.config = config
        self.device = device
        self.logger = logger
        self.tensorboard = tensorboard
        self.loss_composer = LossComposer()
        self.profile_contract = resolve_profile_contract(config)
        self.base_loss_weights = {str(name): float(weight) for name, weight in config.train.loss_weights.items()}
        trainable_parameters = list(self.model.parameters()) + list(self.task.trainable_parameters())
        self.optimizer = torch.optim.Adam(trainable_parameters, lr=config.train.lr)

    def _sampling_config(self) -> Mapping[str, Any]:
        sampling = self.config.train.extras.get("sampling", {})
        if isinstance(sampling, Mapping):
            return sampling
        return {}

    def train(self) -> list[dict[str, float]]:
        """Run training epochs and return history rows."""
        history: list[dict[str, float]] = []
        self.model.train()
        previous_scalar_terms: dict[str, float] | None = None

        for epoch in range(1, self.config.train.epochs + 1):
            batches = self.task.sample_train_batches(device=self.device)
            sampling_config = self._sampling_config()
            refresh_every = max(1, int(sampling_config.get("refresh_every", 1)))
            if epoch % refresh_every == 0:
                batches = maybe_adapt_train_batches(
                    task=self.task,
                    model=self.model,
                    batches=batches,
                    sampling_config=sampling_config,
                    device=self.device,
                )

            self.optimizer.zero_grad(set_to_none=True)
            loss_terms = self.task.compute_loss_terms(model=self.model, batches=batches)
            model_extra_loss_terms = getattr(self.model, "extra_loss_terms", None)
            if callable(model_extra_loss_terms):
                extra_terms = model_extra_loss_terms()
                if isinstance(extra_terms, Mapping):
                    loss_terms = {**loss_terms, **extra_terms}
            method_loss_terms = getattr(self.model, "method_loss_terms", None)
            if callable(method_loss_terms):
                extra_terms = method_loss_terms(
                    task=self.task,
                    batches=batches,
                    epoch=epoch,
                    total_epochs=self.config.train.epochs,
                    device=self.device,
                )
                if isinstance(extra_terms, Mapping):
                    loss_terms = {**loss_terms, **extra_terms}
            active_weights, profile_phase = build_epoch_loss_weights(
                base_weights=self.base_loss_weights,
                profile_contract=self.profile_contract,
                epoch=epoch,
                total_epochs=self.config.train.epochs,
                previous_scalar_terms=previous_scalar_terms,
            )
            model_weight_overrides = getattr(self.model, "loss_weight_overrides", None)
            if callable(model_weight_overrides):
                overrides = model_weight_overrides(
                    loss_terms=loss_terms,
                    epoch=epoch,
                    total_epochs=self.config.train.epochs,
                    base_weights=dict(active_weights),
                )
                if isinstance(overrides, Mapping):
                    for key, value in overrides.items():
                        active_weights[str(key)] = float(value)
            total_loss, scalar_terms = self.loss_composer.compose(
                loss_terms=loss_terms,
                weights=active_weights,
            )
            total_loss.backward()
            self.optimizer.step()

            row = {
                "epoch": float(epoch),
                "loss": float(total_loss.detach().item()),
                **scalar_terms,
            }
            tracked_weight_names = sorted(set(active_weights) | {key.removeprefix("loss_") for key in scalar_terms})
            for name in tracked_weight_names:
                row[f"weight_{name}"] = float(active_weights.get(name, 1.0))
            if profile_phase is not None:
                row["profile_phase"] = profile_phase
            history.append(row)
            self.logger.log_epoch(epoch=epoch, metrics=row)
            self.tensorboard.log_scalar("train/loss", row["loss"], epoch)
            for name, value in scalar_terms.items():
                self.tensorboard.log_scalar(f"train/{name}", value, epoch)
            previous_scalar_terms = {key.removeprefix("loss_"): float(value) for key, value in scalar_terms.items()}

        return history


def summarize_history(history: Sequence[dict[str, float]]) -> dict[str, float | dict[str, float]]:
    """Create summary statistics from history."""
    if not history:
        return {"final_loss": 0.0, "best_loss": 0.0, "final_loss_terms": {}}

    final_row = history[-1]
    final_loss_terms = {
        key.removeprefix("loss_"): float(value)
        for key, value in final_row.items()
        if key.startswith("loss_") and key != "loss"
    }
    return {
        "final_loss": float(final_row["loss"]),
        "best_loss": float(min(row["loss"] for row in history)),
        "final_loss_terms": final_loss_terms,
    }
