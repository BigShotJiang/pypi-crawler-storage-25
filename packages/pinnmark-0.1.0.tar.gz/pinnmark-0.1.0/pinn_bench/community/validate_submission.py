"""Validate submission bundles against the community v1 contract."""

from __future__ import annotations

import argparse
import json
from collections.abc import Mapping, Sequence
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import yaml

from pinn_bench.comparison import parse_comparison_config
from pinn_bench.community.bundle import (
    ALLOWED_PROTOCOLS,
    ALLOWED_SOURCE_TYPES,
    OPTIONAL_SUBMISSION_FIELDS,
    REQUIRED_BUNDLE_FILES,
    REQUIRED_SUBMISSION_FIELDS,
    SUBMISSION_SCHEMA_V1,
    bundle_metric,
    infer_benchmark_line_from_manifest_path,
    infer_manifest_name_for_line,
)
from pinn_bench.community.admission import build_preliminary_admission
from pinn_bench.resources import resolve_manifest_path
from pinn_bench.superbench.contracts import (
    ALLOWED_ARTIFACT_EVIDENCE_TIERS,
    ALLOWED_BRIDGE_STATUSES,
    SUPERBENCH_SUBMISSION_OPTIONAL_FIELDS,
)
from pinn_bench.version import LATEST_FORMAL_BASELINE


@dataclass(frozen=True)
class ValidationCheck:
    code: str
    severity: str
    status: str
    message: str
    path: str | None = None


@dataclass(frozen=True)
class CompatibilityResult:
    status: str
    target_line: str
    reasons: list[str]


def _result(code: str, severity: str, passed: bool, message: str, path: Path | None = None) -> ValidationCheck:
    return ValidationCheck(
        code=code,
        severity=severity,
        status="pass" if passed else "fail",
        message=message,
        path=None if path is None else str(path.resolve()),
    )


def _builtin_names() -> tuple[set[str], set[str]]:
    import pinn_bench.models  # noqa: F401
    import pinn_bench.tasks  # noqa: F401
    from pinn_bench.registry import list_models, list_tasks

    return set(list_tasks()), set(list_models())


def _safe_load_json(path: Path) -> tuple[dict[str, Any] | None, str | None]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception as error:
        return None, str(error)
    if not isinstance(payload, Mapping):
        return None, "Top-level JSON payload must be an object."
    return dict(payload), None


def _safe_load_yaml(path: Path) -> tuple[dict[str, Any] | None, str | None]:
    try:
        payload = yaml.safe_load(path.read_text(encoding="utf-8"))
    except Exception as error:
        return None, str(error)
    if not isinstance(payload, Mapping):
        return None, "Top-level YAML payload must be a mapping."
    return dict(payload), None


def _load_target_rules(target_line: str) -> dict[str, Any]:
    manifest_name = infer_manifest_name_for_line(target_line)
    if manifest_name is None:
        raise ValueError(f"Unsupported benchmark line '{target_line}'.")
    manifest_path = resolve_manifest_path(manifest_name)
    payload, error = _safe_load_yaml(manifest_path)
    if payload is None:
        raise ValueError(f"Could not load manifest for target line '{target_line}': {error}")
    runs = payload.get("runs") if isinstance(payload.get("runs"), list) else []
    tasks: set[str] = set()
    models: set[str] = set()
    legal_protocols_by_task: dict[str, set[str]] = {}
    for run in runs:
        if not isinstance(run, Mapping):
            continue
        task_name = str(run.get("task_name", "")).strip()
        model_name = str(run.get("model_name", "")).strip()
        protocol = str(run.get("protocol", "")).strip()
        if task_name:
            tasks.add(task_name)
            legal_protocols_by_task.setdefault(task_name, set()).add(protocol)
        if model_name:
            models.add(model_name)
    return {
        "manifest_path": str(manifest_path.resolve()),
        "tasks": tasks,
        "models": models,
        "legal_protocols_by_task": legal_protocols_by_task,
    }


def _resolve_target_contract(
    *,
    against_benchmark_line: str | None,
    against_manifest: str | Path | None,
) -> tuple[str, Path]:
    requested_line = None if against_benchmark_line is None else str(against_benchmark_line).strip()
    resolved_manifest: Path | None = None
    inferred_line = None

    if against_manifest is not None:
        resolved_manifest = resolve_manifest_path(against_manifest)
        inferred_line = infer_benchmark_line_from_manifest_path(resolved_manifest)
        if inferred_line is None:
            raise ValueError(
                f"Could not infer benchmark line from manifest path '{resolved_manifest}'. Use a baseline_v0_* manifest or baseline_v1_0_formal.yaml."
            )

    if requested_line and inferred_line and requested_line != inferred_line:
        raise ValueError(
            f"Requested target line '{requested_line}' does not match manifest target '{inferred_line}'."
        )

    target_line = requested_line or inferred_line or LATEST_FORMAL_BASELINE
    if resolved_manifest is None:
        manifest_name = infer_manifest_name_for_line(target_line)
        if manifest_name is None:
            raise ValueError(f"Unsupported benchmark line '{target_line}'.")
        resolved_manifest = resolve_manifest_path(manifest_name)
    return target_line, resolved_manifest.resolve()


def _typed_nonempty(value: Any, expected_type: type) -> bool:
    if expected_type is int:
        return isinstance(value, int)
    return isinstance(value, expected_type) and bool(str(value).strip())


def _collect_error_messages(checks: list[ValidationCheck]) -> list[str]:
    return [check.message for check in checks if check.severity == "error" and check.status == "fail"]


def _validate_artifacts_manifest(payload: Mapping[str, Any]) -> tuple[bool, list[str]]:
    reasons: list[str] = []
    if not isinstance(payload.get("schema_version"), str) or not str(payload.get("schema_version")).strip():
        reasons.append("artifacts_manifest.json must include a non-empty schema_version.")
    if not isinstance(payload.get("generated_at"), str) or not str(payload.get("generated_at")).strip():
        reasons.append("artifacts_manifest.json must include a non-empty generated_at timestamp.")
    artifacts = payload.get("artifacts")
    if not isinstance(artifacts, list):
        reasons.append("artifacts_manifest.json must include an artifacts list.")
        return False, reasons
    artifact_paths: set[str] = set()
    for index, entry in enumerate(artifacts):
        if not isinstance(entry, Mapping):
            reasons.append(f"artifacts[{index}] must be an object.")
            continue
        path = entry.get("path")
        role = entry.get("role")
        required = entry.get("required")
        sha256 = entry.get("sha256")
        if not isinstance(path, str) or not path.strip():
            reasons.append(f"artifacts[{index}].path must be a non-empty string.")
        else:
            artifact_paths.add(path)
        if not isinstance(role, str) or not role.strip():
            reasons.append(f"artifacts[{index}].role must be a non-empty string.")
        if not isinstance(required, bool):
            reasons.append(f"artifacts[{index}].required must be a boolean.")
        if sha256 is not None and not isinstance(sha256, str):
            reasons.append(f"artifacts[{index}].sha256 must be null or a string.")
    for filename in REQUIRED_BUNDLE_FILES:
        if filename not in artifact_paths:
            reasons.append(f"artifacts_manifest.json must list required artifact `{filename}`.")
    return not reasons, reasons


def determine_bundle_compatibility(
    *,
    submission: Mapping[str, Any] | None,
    metrics: Mapping[str, Any] | None,
    valid: bool,
    checks: list[ValidationCheck],
    target_line: str,
) -> CompatibilityResult:
    if not valid:
        return CompatibilityResult(status="incompatible", target_line=target_line, reasons=_collect_error_messages(checks))
    if submission is None or metrics is None:
        return CompatibilityResult(
            status="incompatible",
            target_line=target_line,
            reasons=["Bundle payloads could not be loaded."],
        )

    rules = _load_target_rules(target_line)
    reasons: list[str] = []
    partial_reasons: list[str] = []

    compatibility_target = submission.get("compatibility_target")
    if isinstance(compatibility_target, str) and compatibility_target.strip() and compatibility_target != target_line:
        reasons.append(
            f"Bundle declares compatibility_target='{compatibility_target}', which conflicts with requested target line '{target_line}'."
        )

    task_name = str(submission.get("task_name", "")).strip()
    model_name = str(submission.get("model_name", "")).strip()
    protocol = str(submission.get("protocol", "")).strip()
    source_type = str(submission.get("source_type", "")).strip().lower()
    benchmark_line = str(submission.get("benchmark_line", "")).strip()

    if task_name not in rules["tasks"]:
        reasons.append(f"Task '{task_name}' is not part of the target benchmark line '{target_line}'.")
    legal_protocols = rules["legal_protocols_by_task"].get(task_name, set())
    if protocol not in legal_protocols:
        reasons.append(f"Protocol '{protocol}' is not legal for task '{task_name}' under '{target_line}'.")

    try:
        bundle_metric(metrics)
    except Exception as error:
        reasons.append(str(error))

    if source_type == "external":
        if task_name in rules["tasks"] and model_name not in rules["models"]:
            partial_reasons.append(
                f"External model '{model_name}' is not part of the official '{target_line}' model vocabulary; slice-local comparison remains available."
            )
        if submission.get("benchmark_manifest") is None:
            partial_reasons.append(
                "External bundle omits benchmark_manifest, which is acceptable but reduces official lineage detail."
            )
    elif source_type == "official":
        manifest_path = submission.get("benchmark_manifest")
        if not isinstance(manifest_path, str) or not manifest_path.strip():
            reasons.append("Official bundles must declare benchmark_manifest.")
    else:
        reasons.append("source_type must be 'official' or 'external'.")

    if benchmark_line and benchmark_line != target_line:
        partial_reasons.append(
            f"Bundle benchmark_line='{benchmark_line}' differs from target line '{target_line}'; comparison is treated as cross-line slice matching."
        )

    if reasons:
        return CompatibilityResult(status="incompatible", target_line=target_line, reasons=reasons)
    if partial_reasons:
        return CompatibilityResult(status="partially_compatible", target_line=target_line, reasons=partial_reasons)
    return CompatibilityResult(
        status="compatible",
        target_line=target_line,
        reasons=["Bundle is fully comparable against the target line."],
    )


def _validation_status(*, valid: bool, warning_count: int, compatibility_status: str) -> str:
    if (not valid) or compatibility_status == "incompatible":
        return "invalid"
    if warning_count or compatibility_status == "partially_compatible":
        return "valid_with_warnings"
    return "valid"


def build_submission_validation_payload(
    bundle_dir: Path,
    *,
    schema_version: str = SUBMISSION_SCHEMA_V1,
    against_benchmark_line: str | None = LATEST_FORMAL_BASELINE,
    against_manifest: str | Path | None = None,
    profile: str | None = None,
) -> dict[str, Any]:
    target_line, target_manifest_path = _resolve_target_contract(
        against_benchmark_line=against_benchmark_line,
        against_manifest=against_manifest,
    )
    requested_profile = None if profile is None else str(profile).strip().lower()
    if requested_profile is not None and requested_profile not in ALLOWED_SOURCE_TYPES:
        raise ValueError("--profile must be one of: official, external")

    resolved = bundle_dir.resolve()
    checks: list[ValidationCheck] = []

    for filename in REQUIRED_BUNDLE_FILES:
        path = resolved / filename
        checks.append(
            _result(
                f"bundle.required.{filename}",
                "error",
                path.exists(),
                f"Found required bundle file `{filename}`." if path.exists() else f"Missing required bundle file `{filename}`.",
                path,
            )
        )

    submission_path = resolved / "submission.json"
    metrics_path = resolved / "metrics.json"
    config_path = resolved / "config_snapshot.yaml"
    env_path = resolved / "env.json"
    artifacts_path = resolved / "artifacts_manifest.json"

    submission: dict[str, Any] | None = None
    if submission_path.exists():
        submission, error = _safe_load_json(submission_path)
        checks.append(
            _result(
                "submission.top_level.mapping",
                "error",
                error is None,
                "submission.json is a JSON object." if error is None else f"submission.json is invalid: {error}",
                submission_path,
            )
        )

    metrics: dict[str, Any] | None = None
    if metrics_path.exists():
        metrics, error = _safe_load_json(metrics_path)
        checks.append(
            _result(
                "metrics.top_level.mapping",
                "error",
                error is None,
                "metrics.json is a JSON object." if error is None else f"metrics.json is invalid: {error}",
                metrics_path,
            )
        )

    config_payload: dict[str, Any] | None = None
    if config_path.exists():
        config_payload, error = _safe_load_yaml(config_path)
        checks.append(
            _result(
                "config_snapshot.top_level.mapping",
                "error",
                error is None,
                "config_snapshot.yaml is a YAML mapping." if error is None else f"config_snapshot.yaml is invalid: {error}",
                config_path,
            )
        )

    env_payload: dict[str, Any] | None = None
    if env_path.exists():
        env_payload, error = _safe_load_json(env_path)
        checks.append(
            _result(
                "env.top_level.mapping",
                "error",
                error is None,
                "env.json is a JSON object." if error is None else f"env.json is invalid: {error}",
                env_path,
            )
        )

    artifacts_payload: dict[str, Any] | None = None
    if artifacts_path.exists():
        artifacts_payload, error = _safe_load_json(artifacts_path)
        checks.append(
            _result(
                "artifacts_manifest.top_level.mapping",
                "error",
                error is None,
                "artifacts_manifest.json is a JSON object." if error is None else f"artifacts_manifest.json is invalid: {error}",
                artifacts_path,
            )
        )

    builtin_tasks, builtin_models = _builtin_names()
    if isinstance(submission, Mapping):
        for field, expected_type in REQUIRED_SUBMISSION_FIELDS.items():
            value = submission.get(field)
            passed = _typed_nonempty(value, expected_type)
            checks.append(
                _result(
                    f"submission.field.{field}",
                    "error",
                    passed,
                    f"Submission field `{field}` is present and typed correctly."
                    if passed
                    else f"Submission field `{field}` is missing or has the wrong type.",
                    submission_path,
                )
            )
        checks.append(
            _result(
                "submission.schema_version",
                "error",
                str(submission.get("schema_version", "")).strip() == schema_version,
                f"submission.json uses expected schema_version '{schema_version}'."
                if str(submission.get("schema_version", "")).strip() == schema_version
                else f"submission.json schema_version must equal '{schema_version}'.",
                submission_path,
            )
        )
        for field, expected_type in OPTIONAL_SUBMISSION_FIELDS.items():
            if field not in submission or submission.get(field) is None:
                continue
            checks.append(
                _result(
                    f"submission.optional.{field}",
                    "error",
                    _typed_nonempty(submission.get(field), expected_type),
                    f"Optional submission field `{field}` is typed correctly."
                    if _typed_nonempty(submission.get(field), expected_type)
                    else f"Optional submission field `{field}` has the wrong type.",
                    submission_path,
                )
            )
        try:
            parse_comparison_config(submission.get("comparison"), location="submission.comparison")
            comparison_valid = True
            comparison_message = "Optional submission comparison metadata is valid."
        except ValueError as error:
            comparison_valid = False
            comparison_message = str(error)
        checks.append(
            _result(
                "submission.optional.comparison.contract",
                "error",
                submission.get("comparison") is None or comparison_valid,
                comparison_message if submission.get("comparison") is not None else "submission.json omits optional comparison metadata.",
                submission_path,
            )
        )

        if any(submission.get(field) not in {None, ""} for field in SUPERBENCH_SUBMISSION_OPTIONAL_FIELDS):
            artifact_evidence_tier = str(submission.get("artifact_evidence_tier", "")).strip()
            if artifact_evidence_tier:
                checks.append(
                    _result(
                        "submission.superbench.artifact_evidence_tier.allowed",
                        "error",
                        artifact_evidence_tier in ALLOWED_ARTIFACT_EVIDENCE_TIERS,
                        f"Super-benchmark artifact_evidence_tier `{artifact_evidence_tier}` is supported."
                        if artifact_evidence_tier in ALLOWED_ARTIFACT_EVIDENCE_TIERS
                        else f"Unsupported super-benchmark artifact_evidence_tier `{artifact_evidence_tier}`.",
                        submission_path,
                    )
                )
            bridge_status = str(submission.get("bridge_status", "")).strip()
            if bridge_status:
                checks.append(
                    _result(
                        "submission.superbench.bridge_status.allowed",
                        "error",
                        bridge_status in ALLOWED_BRIDGE_STATUSES,
                        f"Super-benchmark bridge_status `{bridge_status}` is supported."
                        if bridge_status in ALLOWED_BRIDGE_STATUSES
                        else f"Unsupported super-benchmark bridge_status `{bridge_status}`.",
                        submission_path,
                    )
                )
            if submission.get("cohort_id") not in {None, ""} and submission.get("canonical_task_id") in {None, ""}:
                checks.append(
                    _result(
                        "submission.superbench.cohort_requires_canonical_task",
                        "warning",
                        False,
                        "cohort_id is present but canonical_task_id is missing; the bundle can stay reviewable but cannot be officialized into a super-benchmark cohort.",
                        submission_path,
                    )
                )

        protocol = str(submission.get("protocol", "")).strip().lower()
        checks.append(
            _result(
                "submission.protocol.allowed",
                "error",
                protocol in ALLOWED_PROTOCOLS,
                f"Submission protocol `{protocol}` is supported." if protocol in ALLOWED_PROTOCOLS else f"Unsupported protocol `{protocol}`.",
                submission_path,
            )
        )

        source_type = str(submission.get("source_type", "")).strip().lower()
        checks.append(
            _result(
                "submission.source_type.allowed",
                "error",
                source_type in ALLOWED_SOURCE_TYPES,
                f"Submission source_type `{source_type}` is supported."
                if source_type in ALLOWED_SOURCE_TYPES
                else "Submission source_type must be `official` or `external`.",
                submission_path,
            )
        )
        checks.append(
            _result(
                "submission.profile.requested",
                "error",
                requested_profile is None or source_type == requested_profile,
                "Submission source_type matches the requested validation profile."
                if requested_profile is None or source_type == requested_profile
                else f"Submission source_type '{source_type}' conflicts with requested profile '{requested_profile}'.",
                submission_path,
            )
        )

        benchmark_line = str(submission.get("benchmark_line", "")).strip()
        checks.append(
            _result(
                "submission.benchmark_line.target_consistency",
                "warning",
                not benchmark_line or benchmark_line == target_line,
                "Bundle benchmark_line matches the requested comparison target."
                if not benchmark_line or benchmark_line == target_line
                else f"Bundle benchmark_line '{benchmark_line}' differs from requested target '{target_line}'.",
                submission_path,
            )
        )

        manifest_path = submission.get("benchmark_manifest")
        if isinstance(manifest_path, str) and manifest_path.strip():
            manifest_line = infer_benchmark_line_from_manifest_path(manifest_path)
            checks.append(
                _result(
                    "submission.benchmark_manifest.line_consistency",
                    "error" if source_type == "official" else "warning",
                    manifest_line is None or not benchmark_line or manifest_line == benchmark_line,
                    "benchmark_manifest is consistent with benchmark_line."
                    if manifest_line is None or not benchmark_line or manifest_line == benchmark_line
                    else f"benchmark_manifest resolves to '{manifest_line}', which conflicts with benchmark_line '{benchmark_line}'.",
                    submission_path,
                )
            )

        task_name = str(submission.get("task_name", "")).strip()
        model_name = str(submission.get("model_name", "")).strip()
        if source_type == "official":
            checks.append(
                _result(
                    "submission.official.task_name",
                    "error",
                    task_name in builtin_tasks,
                    f"Official bundle task `{task_name}` is a registered builtin."
                    if task_name in builtin_tasks
                    else f"Official bundle task `{task_name}` is not a registered builtin.",
                    submission_path,
                )
            )
            checks.append(
                _result(
                    "submission.official.model_name",
                    "error",
                    model_name in builtin_models,
                    f"Official bundle model `{model_name}` is a registered builtin."
                    if model_name in builtin_models
                    else f"Official bundle model `{model_name}` is not a registered builtin.",
                    submission_path,
                )
            )
            manifest_ok = isinstance(manifest_path, str) and bool(manifest_path.strip())
            checks.append(
                _result(
                    "submission.official.benchmark_manifest",
                    "error",
                    manifest_ok,
                    "Official bundle declares benchmark_manifest." if manifest_ok else "Official bundle must declare benchmark_manifest.",
                    submission_path,
                )
            )
        elif source_type == "external":
            checks.append(
                _result(
                    "submission.external.task_name",
                    "warning" if task_name not in builtin_tasks else "info",
                    bool(task_name) and task_name in builtin_tasks,
                    f"External bundle task `{task_name}` is recognized as a builtin."
                    if task_name in builtin_tasks
                    else f"External bundle task `{task_name}` is accepted but not builtin to the current formal line.",
                    submission_path,
                )
            )
            checks.append(
                _result(
                    "submission.external.model_name",
                    "warning" if model_name not in builtin_models else "info",
                    bool(model_name) and model_name in builtin_models,
                    f"External bundle model `{model_name}` is recognized as a builtin."
                    if model_name in builtin_models
                    else f"External bundle model `{model_name}` is accepted but not builtin to the current formal line.",
                    submission_path,
                )
            )

    if isinstance(metrics, Mapping):
        for field in ("metadata", "train", "eval"):
            value = metrics.get(field)
            checks.append(
                _result(
                    f"metrics.section.{field}",
                    "error",
                    isinstance(value, Mapping),
                    f"metrics.json contains `{field}`." if isinstance(value, Mapping) else f"metrics.json is missing `{field}` or it is not an object.",
                    metrics_path,
                )
            )
        metric_ok = True
        metric_error = None
        try:
            bundle_metric(metrics)
        except Exception as error:
            metric_ok = False
            metric_error = str(error)
        checks.append(
            _result(
                "metrics.comparison_metric",
                "error",
                metric_ok,
                "metrics.json provides a comparison metric (eval.relative_l2 or eval.mse)."
                if metric_ok
                else metric_error or "metrics.json does not provide a supported comparison metric.",
                metrics_path,
            )
        )
        metadata_payload = metrics.get("metadata")
        metadata_comparison = metadata_payload.get("comparison") if isinstance(metadata_payload, Mapping) else None
        try:
            parse_comparison_config(metadata_comparison, location="metrics.metadata.comparison")
            metadata_comparison_valid = True
            metadata_comparison_message = "metrics.json comparison metadata is valid."
        except ValueError as error:
            metadata_comparison_valid = False
            metadata_comparison_message = str(error)
        checks.append(
            _result(
                "metrics.metadata.comparison.contract",
                "error",
                metadata_comparison is None or metadata_comparison_valid,
                metadata_comparison_message if metadata_comparison is not None else "metrics.json omits optional comparison metadata.",
                metrics_path,
            )
        )

    if isinstance(env_payload, Mapping):
        checks.append(
            _result(
                "env.required.python_version",
                "error",
                isinstance(env_payload.get("python_version"), str) and bool(str(env_payload.get("python_version")).strip()),
                "env.json contains python_version."
                if isinstance(env_payload.get("python_version"), str) and bool(str(env_payload.get("python_version")).strip())
                else "env.json must include python_version.",
                env_path,
            )
        )

    if isinstance(artifacts_payload, Mapping):
        manifest_ok, manifest_reasons = _validate_artifacts_manifest(artifacts_payload)
        checks.append(
            _result(
                "artifacts_manifest.contract",
                "error",
                manifest_ok,
                "artifacts_manifest.json matches the v1 artifact contract." if manifest_ok else "; ".join(manifest_reasons),
                artifacts_path,
            )
        )

    if isinstance(config_payload, Mapping):
        checks.append(
            _result(
                "config_snapshot.sections",
                "error",
                isinstance(config_payload.get("task"), Mapping) and isinstance(config_payload.get("model"), Mapping),
                "config_snapshot.yaml contains task and model sections."
                if isinstance(config_payload.get("task"), Mapping) and isinstance(config_payload.get("model"), Mapping)
                else "config_snapshot.yaml must contain task and model sections.",
                config_path,
            )
        )
        try:
            parse_comparison_config(config_payload.get("comparison"), location="config_snapshot.comparison")
            config_comparison_valid = True
            config_comparison_message = "config_snapshot comparison metadata is valid."
        except ValueError as error:
            config_comparison_valid = False
            config_comparison_message = str(error)
        checks.append(
            _result(
                "config_snapshot.comparison.contract",
                "error",
                config_payload.get("comparison") is None or config_comparison_valid,
                config_comparison_message if config_payload.get("comparison") is not None else "config_snapshot.yaml omits optional comparison metadata.",
                config_path,
            )
        )

    summary = {
        "info": sum(1 for check in checks if check.severity == "info"),
        "warning": sum(1 for check in checks if check.severity == "warning" and check.status == "fail"),
        "error": sum(1 for check in checks if check.severity == "error" and check.status == "fail"),
        "pass": sum(1 for check in checks if check.status == "pass"),
        "fail": sum(1 for check in checks if check.status == "fail"),
    }
    valid = summary["error"] == 0
    compatibility = determine_bundle_compatibility(
        submission=submission,
        metrics=metrics,
        valid=valid,
        checks=checks,
        target_line=target_line,
    )
    status = _validation_status(
        valid=valid,
        warning_count=int(summary["warning"]),
        compatibility_status=str(compatibility.status),
    )
    admission = build_preliminary_admission(
        submission={} if submission is None else submission,
        valid=valid,
        summary=summary,
        compatibility=asdict(compatibility),
    )
    return {
        "bundle_dir": str(resolved),
        "schema_version": schema_version,
        "against_benchmark_line": target_line,
        "against_manifest": None if against_manifest is None else str(Path(str(against_manifest))),
        "target_manifest_path": str(target_manifest_path),
        "profile": requested_profile,
        "checks": [asdict(check) for check in checks],
        "summary": summary,
        "valid": valid,
        "status": status,
        "compatibility": asdict(compatibility),
        "admission": admission,
        "admission_disposition": admission.get("disposition"),
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Validate a pinn_bench submission bundle.")
    parser.add_argument("bundle_dir", type=str, help="Path to the bundle directory.")
    parser.add_argument("--json", action="store_true", help="Emit a machine-readable validation payload.")
    parser.add_argument("--strict", action="store_true", help="Return non-zero on any warning or partial compatibility.")
    parser.add_argument(
        "--schema-version",
        type=str,
        default=SUBMISSION_SCHEMA_V1,
        help=f"Expected submission schema version. Defaults to {SUBMISSION_SCHEMA_V1}.",
    )
    parser.add_argument(
        "--against-benchmark-line",
        type=str,
        default=None,
        help=f"Benchmark line to validate compatibility against. Defaults to {LATEST_FORMAL_BASELINE} when omitted.",
    )
    parser.add_argument(
        "--against-manifest",
        type=str,
        default=None,
        help="Optional benchmark manifest path. If supplied with --against-benchmark-line, both must resolve to the same target.",
    )
    parser.add_argument(
        "--profile",
        type=str,
        choices=sorted(ALLOWED_SOURCE_TYPES),
        default=None,
        help="Optional validation profile that must agree with submission.json source_type.",
    )
    return parser


def _format_text(payload: dict[str, Any]) -> str:
    lines = ["pinn_bench validate-submission"]
    for check in payload["checks"]:
        path_text = f" ({check['path']})" if check.get("path") else ""
        lines.append(f"[{str(check['severity']).upper()}][{str(check['status']).upper()}] {check['message']}{path_text}")
    summary = payload["summary"]
    compatibility = payload["compatibility"]
    lines.append(f"Validation status: {payload['status']}")
    lines.append(
        "Summary: pass={pass_count}, fail={fail_count}, warnings={warning_count}, errors={error_count}".format(
            pass_count=summary["pass"],
            fail_count=summary["fail"],
            warning_count=summary["warning"],
            error_count=summary["error"],
        )
    )
    lines.append(
        "Compatibility: status={status}, target_line={target_line}".format(
            status=compatibility["status"],
            target_line=compatibility["target_line"],
        )
    )
    lines.append(f"Admission disposition: {payload.get('admission_disposition')}")
    if payload.get("target_manifest_path"):
        lines.append(f"Target manifest: {payload['target_manifest_path']}")
    for reason in compatibility.get("reasons", []):
        lines.append(f"- {reason}")
    return "\n".join(lines)


def _exit_code(payload: dict[str, Any], *, strict: bool) -> int:
    compatibility = payload.get("compatibility", {})
    compatibility_status = str(compatibility.get("status", "incompatible"))
    status = str(payload.get("status", "invalid"))
    if strict:
        return 1 if status != "valid" or compatibility_status != "compatible" else 0
    return 1 if status == "invalid" or compatibility_status == "incompatible" else 0


def main(argv: Sequence[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    try:
        payload = build_submission_validation_payload(
            Path(args.bundle_dir),
            schema_version=str(args.schema_version),
            against_benchmark_line=None if args.against_benchmark_line is None else str(args.against_benchmark_line),
            against_manifest=args.against_manifest,
            profile=args.profile,
        )
    except ValueError as error:
        raise SystemExit(str(error))
    if args.json:
        print(json.dumps(payload, indent=2))
    else:
        print(_format_text(payload))
    raise SystemExit(_exit_code(payload, strict=bool(args.strict)))


if __name__ == "__main__":
    main()
