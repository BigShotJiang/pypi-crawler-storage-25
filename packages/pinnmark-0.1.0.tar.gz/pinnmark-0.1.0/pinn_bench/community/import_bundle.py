"""Import a bundle into local comparison-ready artifacts."""

from __future__ import annotations

import argparse
import json
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

from pinn_bench.community.admission import (
    build_leaderboard_entry_candidate,
    build_leaderboard_governance_packet,
    render_leaderboard_governance_packet_markdown,
)
from pinn_bench.community.bundle import load_bundle_files
from pinn_bench.community.compare_bundle import build_bundle_comparison_payload, render_bundle_comparison_from_payload
from pinn_bench.community.validate_submission import SUBMISSION_SCHEMA_V1


def _normalized_bundle_payload(bundle_dir: Path) -> dict[str, Any]:
    loaded = load_bundle_files(bundle_dir)
    summary_path = bundle_dir.resolve() / "summary.md"
    readme_path = bundle_dir.resolve() / "README.md"
    return {
        "bundle_dir": str(bundle_dir.resolve()),
        "submission": loaded.get("submission.json"),
        "metrics": loaded.get("metrics.json"),
        "config_snapshot": loaded.get("config_snapshot.yaml"),
        "env": loaded.get("env.json"),
        "artifacts_manifest": loaded.get("artifacts_manifest.json"),
        "summary_md": summary_path.read_text(encoding="utf-8") if summary_path.exists() else None,
        "readme_md": readme_path.read_text(encoding="utf-8") if readme_path.exists() else None,
    }


def import_bundle(
    bundle_dir: Path,
    *,
    grouped_json: Path,
    output_dir: Path,
    against_benchmark_line: str | None = None,
    schema_version: str = SUBMISSION_SCHEMA_V1,
) -> dict[str, str]:
    comparison = build_bundle_comparison_payload(
        bundle_dir,
        grouped_json,
        schema_version=schema_version,
        against_benchmark_line=against_benchmark_line,
    )
    validation = comparison["validation"]
    entry_candidate = build_leaderboard_entry_candidate(comparison_payload=comparison)
    governance_packet = build_leaderboard_governance_packet(comparison_payload=comparison, candidate=entry_candidate)

    destination = output_dir.resolve()
    destination.mkdir(parents=True, exist_ok=True)

    normalized_path = destination / "normalized_bundle.json"
    validation_path = destination / "validation.json"
    comparison_json_path = destination / "comparison.json"
    comparison_md_path = destination / "comparison.md"
    entry_candidate_path = destination / "leaderboard_entry_candidate.json"
    governance_json_path = destination / "leaderboard_governance_packet.json"
    governance_md_path = destination / "leaderboard_governance_packet.md"

    normalized_path.write_text(json.dumps(_normalized_bundle_payload(bundle_dir), indent=2), encoding="utf-8")
    validation_path.write_text(json.dumps(validation, indent=2), encoding="utf-8")
    comparison_json_path.write_text(json.dumps(comparison, indent=2), encoding="utf-8")
    comparison_md_path.write_text(render_bundle_comparison_from_payload(comparison), encoding="utf-8")
    entry_candidate_path.write_text(json.dumps(entry_candidate, indent=2), encoding="utf-8")
    governance_json_path.write_text(json.dumps(governance_packet, indent=2), encoding="utf-8")
    governance_md_path.write_text(render_leaderboard_governance_packet_markdown(governance_packet), encoding="utf-8")

    return {
        "normalized_bundle.json": str(normalized_path),
        "validation.json": str(validation_path),
        "comparison.json": str(comparison_json_path),
        "comparison.md": str(comparison_md_path),
        "leaderboard_entry_candidate.json": str(entry_candidate_path),
        "leaderboard_governance_packet.json": str(governance_json_path),
        "leaderboard_governance_packet.md": str(governance_md_path),
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Import a bundle into local comparison-ready artifacts.")
    parser.add_argument("bundle_dir", type=str, help="Path to the bundle directory.")
    parser.add_argument("--against", required=True, type=str, help="Path to a grouped leaderboard JSON file.")
    parser.add_argument("--output-dir", required=True, type=str, help="Directory where local comparison artifacts will be written.")
    parser.add_argument(
        "--against-benchmark-line",
        type=str,
        default=None,
        help="Optional explicit target benchmark line. If supplied, it must match the grouped payload target.",
    )
    parser.add_argument(
        "--schema-version",
        type=str,
        default=SUBMISSION_SCHEMA_V1,
        help=f"Expected submission bundle schema version. Defaults to {SUBMISSION_SCHEMA_V1}.",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    try:
        written = import_bundle(
            Path(args.bundle_dir),
            grouped_json=Path(args.against),
            output_dir=Path(args.output_dir),
            against_benchmark_line=args.against_benchmark_line,
            schema_version=str(args.schema_version),
        )
    except ValueError as error:
        raise SystemExit(str(error))
    print("Imported bundle artifacts:")
    for name in sorted(written):
        print(f"- {name}: {Path(written[name]).resolve()}")


if __name__ == "__main__":
    main()
