"""Render leaderboard-protocol artifacts from grouped results and imported bundle sidecars."""

from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from collections.abc import Mapping, Sequence
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from pinn_bench.analysis.fairness import assess_stress_comparability
from pinn_bench.comparison import comparison_dict_from_mapping, comparison_dict_from_record
from pinn_bench.community.bundle import infer_benchmark_line_from_manifest_path
from pinn_bench.leaderboard.reporting import load_grouped_payload
from pinn_bench.regime import GEOMETRY_RAW_FIELDS, REGIME_DERIVED_FIELDS, REGIME_RAW_FIELDS
from pinn_bench.resources import resolve_repo_root
from pinn_bench.stress import apply_stress_metadata
from pinn_bench.version import KNOWN_PREVIEW_OUTPUTS_ROOT, LATEST_COMPLETED_PREVIEW_OUTPUTS_ROOT

PROTOCOL_BUNDLE_SCHEMA_VERSION = "leaderboard_protocol_bundle.v0.1"
ADMISSION_REGISTRY_SCHEMA_VERSION = "leaderboard_protocol_admission_registry.v0.1"
LEADERBOARD_VIEW_SCHEMA_VERSION = "leaderboard_protocol_view.v0.1"
GOVERNANCE_PACKET_SCHEMA_VERSION = "leaderboard_protocol_governance.v0.1"


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _default_outputs_root() -> Path:
    repo_root = resolve_repo_root()
    root_name = KNOWN_PREVIEW_OUTPUTS_ROOT or LATEST_COMPLETED_PREVIEW_OUTPUTS_ROOT
    if root_name is None:
        raise ValueError("No preview outputs root is available for leaderboard-protocol defaults.")
    return (repo_root / root_name).resolve()


def _resolve_outputs_root(outputs_root: str | Path | None) -> Path:
    if outputs_root is None:
        return _default_outputs_root()
    return Path(outputs_root).resolve()


def _load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        raise ValueError(f"Expected a JSON object in {path}.")
    return dict(payload)


def _write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _normalize_metric_name(entry: Mapping[str, Any]) -> str:
    metric_name = str(entry.get("metric_name") or "").strip()
    if metric_name:
        return metric_name
    if entry.get("metric_value") is not None:
        return "eval.relative_l2"
    return "unknown"


def _coerce_float(value: Any) -> float | None:
    if value in {None, ""}:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _render_value(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float):
        return f"{value:.6g}"
    return str(value)


def _official_entry_from_row(row: Mapping[str, Any]) -> dict[str, Any] | None:
    if int(row.get("run_count", 0) or 0) <= 0:
        return None
    metric_value = _coerce_float(row.get("eval_relative_l2_mean"))
    metric_name = "eval.relative_l2"
    if metric_value is None:
        metric_value = _coerce_float(row.get("eval_mse_mean"))
        metric_name = "eval.mse"
    if metric_value is None:
        return None

    enriched = apply_stress_metadata(dict(row))
    protocol = str(row.get("protocol") or "none")
    duration = _coerce_float(row.get("train_duration_seconds_mean"))
    if protocol == "none":
        eligible_views = ["admission_registry", "main_leaderboard", "pareto_leaderboard", "parameter_efficiency"]
        comparability_class = "official_nominal"
    else:
        eligible_views = ["admission_registry", "stress_leaderboard", "parameter_efficiency"]
        comparability_class = str(enriched.get("stress_comparability_class") or "official_stress")
    if duration is not None:
        eligible_views.append("convergence_efficiency")
    comparison = comparison_dict_from_record(row)
    regime_fields = {field: row.get(field) for field in [*REGIME_RAW_FIELDS, *GEOMETRY_RAW_FIELDS, *REGIME_DERIVED_FIELDS]}

    return {
        "entry_id": f"official::{row.get('run_id')}",
        "source_kind": "official_grouped_row",
        "disposition": "official",
        "appendix_only": False,
        "eligible_views": eligible_views,
        "comparability_class": comparability_class,
        "task_name": row.get("task_name"),
        "task_mode": row.get("task_mode") or "pointwise",
        "model_name": row.get("model_name"),
        "model_mode": row.get("model_mode") or "pointwise",
        "evaluation_mode": row.get("evaluation_mode") or row.get("task_mode") or "pointwise",
        "protocol": protocol,
        "setting": row.get("protocol_setting"),
        "comparison": comparison,
        "baseline_family": None if comparison is None else comparison.get("baseline_family"),
        "data_budget_class": None if comparison is None else comparison.get("data_budget_class"),
        "compute_budget_class": None if comparison is None else comparison.get("compute_budget_class"),
        "tuning_budget_class": None if comparison is None else comparison.get("tuning_budget_class"),
        "comparison_scope": None if comparison is None else comparison.get("comparison_scope"),
        "metric_name": metric_name,
        "metric_value": metric_value,
        "parameter_count": row.get("parameter_count"),
        "train_duration_seconds": duration,
        "is_stress_run": bool(enriched.get("is_stress_run")),
        "stress_family": enriched.get("stress_family"),
        "stress_severity": enriched.get("stress_severity"),
        "stress_case_id": enriched.get("stress_case_id"),
        "nominal_peer_run_id": enriched.get("nominal_peer_run_id"),
        **regime_fields,
        "reasons": [],
        "target_benchmark_line": None,
    }


def _candidate_paths(imports_root: Path) -> list[Path]:
    if not imports_root.exists():
        return []
    return sorted(imports_root.rglob("leaderboard_entry_candidate.json"))


def _governance_path_for_candidate(candidate_path: Path) -> Path:
    return candidate_path.with_name("leaderboard_governance_packet.json")


def _normalize_imported_entry(candidate: Mapping[str, Any], *, candidate_path: Path, target_line: str | None) -> dict[str, Any]:
    governance_path = _governance_path_for_candidate(candidate_path)
    candidate_target = str(candidate.get("target_benchmark_line") or "").strip() or None
    target_match = target_line is None or candidate_target is None or candidate_target == target_line
    eligible_views = list(candidate.get("eligible_views", [])) if isinstance(candidate.get("eligible_views"), list) else []
    disposition = str(candidate.get("disposition") or "appendix_only")
    if not target_match:
        eligible_views = ["admission_registry"]
        disposition = "appendix_only"
    comparison = comparison_dict_from_mapping(candidate.get("comparison"), location="leaderboard_entry_candidate.comparison")
    regime_fields = {field: candidate.get(field) for field in [*REGIME_RAW_FIELDS, *GEOMETRY_RAW_FIELDS, *REGIME_DERIVED_FIELDS]}

    return {
        "entry_id": candidate.get("entry_id"),
        "source_kind": "imported_bundle",
        "source_type": candidate.get("source_type"),
        "bundle_dir": candidate.get("bundle_dir"),
        "candidate_path": str(candidate_path.resolve()),
        "governance_path": str(governance_path.resolve()) if governance_path.exists() else None,
        "disposition": disposition,
        "appendix_only": disposition in {"appendix_only", "rejected"},
        "eligible_views": eligible_views,
        "comparability_class": candidate.get("comparability_class"),
        "task_name": candidate.get("task_name"),
        "task_mode": candidate.get("task_mode") or "pointwise",
        "model_name": candidate.get("model_name"),
        "model_mode": candidate.get("model_mode") or "pointwise",
        "evaluation_mode": candidate.get("evaluation_mode") or candidate.get("task_mode") or "pointwise",
        "protocol": candidate.get("protocol") or "none",
        "setting": candidate.get("setting"),
        "comparison": comparison,
        "baseline_family": candidate.get("baseline_family") if comparison is None else comparison.get("baseline_family"),
        "data_budget_class": candidate.get("data_budget_class") if comparison is None else comparison.get("data_budget_class"),
        "compute_budget_class": candidate.get("compute_budget_class") if comparison is None else comparison.get("compute_budget_class"),
        "tuning_budget_class": candidate.get("tuning_budget_class") if comparison is None else comparison.get("tuning_budget_class"),
        "comparison_scope": candidate.get("comparison_scope") if comparison is None else comparison.get("comparison_scope"),
        "metric_name": _normalize_metric_name(candidate),
        "metric_value": _coerce_float(candidate.get("metric_value")),
        "parameter_count": candidate.get("parameter_count"),
        "train_duration_seconds": _coerce_float(candidate.get("train_duration_seconds")),
        "is_stress_run": bool(candidate.get("is_stress_run")),
        "stress_family": candidate.get("stress_family"),
        "stress_severity": candidate.get("stress_severity"),
        "stress_case_id": candidate.get("stress_case_id"),
        "nominal_peer_run_id": candidate.get("nominal_peer_run_id"),
        **regime_fields,
        "reasons": list(candidate.get("reasons", [])) if isinstance(candidate.get("reasons"), list) else [],
        "target_benchmark_line": candidate_target,
        "target_line_match": target_match,
    }


def _load_imported_entries(imports_root: Path, *, target_line: str | None) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[str]]:
    entries: list[dict[str, Any]] = []
    governance_packets: list[dict[str, Any]] = []
    warnings: list[str] = []
    for candidate_path in _candidate_paths(imports_root):
        candidate = _load_json(candidate_path)
        entry = _normalize_imported_entry(candidate, candidate_path=candidate_path, target_line=target_line)
        if not bool(entry.get("target_line_match", True)):
            warnings.append(
                f"Imported candidate {entry.get('entry_id')} targets {entry.get('target_benchmark_line')}, not {target_line}; keeping it registry-only."
            )
        governance_path = _governance_path_for_candidate(candidate_path)
        if governance_path.exists():
            governance_packets.append(_load_json(governance_path))
        else:
            warnings.append(f"Imported candidate {entry.get('entry_id')} is missing leaderboard_governance_packet.json.")
        entries.append(entry)
    return entries, governance_packets, warnings


def _group_key(entry: Mapping[str, Any], *, stress: bool = False) -> tuple[str, ...]:
    base = (
        str(entry.get("task_name") or ""),
        str(entry.get("task_mode") or "pointwise"),
        str(entry.get("model_mode") or "pointwise"),
        str(entry.get("evaluation_mode") or "pointwise"),
        str(entry.get("protocol") or "none"),
    )
    if stress:
        return base + (
            str(entry.get("model_name") or ""),
            str(entry.get("stress_family") or ""),
            str(entry.get("stress_severity") or ""),
        )
    return base


def _cohort_label(group_key: tuple[str, ...], *, stress: bool = False) -> str:
    if stress:
        task_name, task_mode, model_mode, evaluation_mode, protocol, model_name, family, severity = group_key
        return (
            f"task={task_name}|task_mode={task_mode}|model={model_name}|model_mode={model_mode}|"
            f"evaluation_mode={evaluation_mode}|protocol={protocol}|stress_family={family}|stress_severity={severity}"
        )
    task_name, task_mode, model_mode, evaluation_mode, protocol = group_key
    return f"task={task_name}|task_mode={task_mode}|model_mode={model_mode}|evaluation_mode={evaluation_mode}|protocol={protocol}"


def _entry_sort_key(entry: Mapping[str, Any]) -> tuple[float, float, str]:
    metric_value = _coerce_float(entry.get("metric_value"))
    parameter_count = _coerce_float(entry.get("parameter_count"))
    metric_key = float("inf") if metric_value is None else metric_value
    parameter_key = float("inf") if parameter_count is None else parameter_count
    return metric_key, parameter_key, str(entry.get("entry_id") or "")


def _cohort_payload(entries: Sequence[Mapping[str, Any]], *, stress: bool = False) -> list[dict[str, Any]]:
    grouped: dict[tuple[str, ...], list[dict[str, Any]]] = defaultdict(list)
    for entry in entries:
        grouped[_group_key(entry, stress=stress)].append(dict(entry))
    cohorts: list[dict[str, Any]] = []
    for key in sorted(grouped):
        ranked = sorted(grouped[key], key=_entry_sort_key)
        for index, entry in enumerate(ranked, start=1):
            entry["rank"] = index
        cohorts.append(
            {
                "cohort": _cohort_label(key, stress=stress),
                "entry_count": len(ranked),
                "entries": ranked,
            }
        )
    return cohorts


def _dominates(left: Mapping[str, Any], right: Mapping[str, Any]) -> bool:
    left_metric = _coerce_float(left.get("metric_value"))
    right_metric = _coerce_float(right.get("metric_value"))
    left_params = _coerce_float(left.get("parameter_count"))
    right_params = _coerce_float(right.get("parameter_count"))
    if left_metric is None or right_metric is None or left_params is None or right_params is None:
        return False
    return left_metric <= right_metric and left_params <= right_params and (left_metric < right_metric or left_params < right_params)


def _pareto_front(entries: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    front: list[dict[str, Any]] = []
    for candidate in entries:
        if candidate.get("metric_value") is None or candidate.get("parameter_count") is None:
            continue
        dominated = any(_dominates(other, candidate) for other in entries if other is not candidate)
        if not dominated:
            front.append(dict(candidate))
    return sorted(front, key=_entry_sort_key)


def _admission_summary(entries: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    by_disposition = Counter(str(entry.get("disposition") or "unknown") for entry in entries)
    view_counts = Counter()
    for entry in entries:
        for view in entry.get("eligible_views", []):
            view_counts[str(view)] += 1
    return {
        "entry_count": len(entries),
        "official_count": sum(1 for entry in entries if entry.get("disposition") == "official"),
        "imported_count": sum(1 for entry in entries if entry.get("source_kind") == "imported_bundle"),
        "by_disposition": dict(sorted(by_disposition.items())),
        "view_counts": dict(sorted(view_counts.items())),
    }


def _admission_registry(entries: Sequence[Mapping[str, Any]], *, target_line: str | None) -> dict[str, Any]:
    return {
        "schema_version": ADMISSION_REGISTRY_SCHEMA_VERSION,
        "target_benchmark_line": target_line,
        "generated_at": _utc_now(),
        "summary": _admission_summary(entries),
        "entries": list(entries),
    }


def _main_entries(entries: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    return [
        dict(entry)
        for entry in entries
        if str(entry.get("protocol") or "none") == "none"
        and str(entry.get("disposition") or "") in {"official", "unofficial"}
        and "main_leaderboard" in entry.get("eligible_views", [])
    ]


def _stress_entries(entries: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    return [
        dict(entry)
        for entry in entries
        if bool(entry.get("is_stress_run"))
        and str(entry.get("disposition") or "") in {"official", "stress_only"}
        and bool(entry.get("stress_family"))
        and bool(entry.get("stress_severity"))
        and "stress_leaderboard" in entry.get("eligible_views", [])
    ]


def _build_view_payload(*, view_name: str, description: str, entries: Sequence[Mapping[str, Any]], stress: bool = False) -> dict[str, Any]:
    cohorts = _cohort_payload(entries, stress=stress)
    return {
        "schema_version": LEADERBOARD_VIEW_SCHEMA_VERSION,
        "view": view_name,
        "description": description,
        "generated_at": _utc_now(),
        "entry_count": len(entries),
        "cohort_count": len(cohorts),
        "cohorts": cohorts,
    }


def _build_pareto_view(entries: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    grouped: dict[tuple[str, ...], list[dict[str, Any]]] = defaultdict(list)
    for entry in entries:
        if entry.get("parameter_count") is None:
            continue
        grouped[_group_key(entry, stress=False)].append(dict(entry))
    cohorts: list[dict[str, Any]] = []
    for key in sorted(grouped):
        front = _pareto_front(grouped[key])
        for index, entry in enumerate(front, start=1):
            entry["pareto_rank"] = index
        cohorts.append(
            {
                "cohort": _cohort_label(key, stress=False),
                "entry_count": len(front),
                "entries": front,
            }
        )
    return {
        "schema_version": LEADERBOARD_VIEW_SCHEMA_VERSION,
        "view": "pareto_leaderboard",
        "description": "Cohort-local Pareto front over metric quality and parameter count.",
        "generated_at": _utc_now(),
        "entry_count": sum(cohort["entry_count"] for cohort in cohorts),
        "cohort_count": len(cohorts),
        "cohorts": cohorts,
    }


def _build_parameter_efficiency(entries: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    filtered = [dict(entry) for entry in entries if entry.get("parameter_count") is not None and "parameter_efficiency" in entry.get("eligible_views", [])]
    grouped: dict[tuple[str, ...], list[dict[str, Any]]] = defaultdict(list)
    for entry in filtered:
        grouped[_group_key(entry, stress=bool(entry.get("is_stress_run")))].append(entry)
    cohorts: list[dict[str, Any]] = []
    for key in sorted(grouped):
        ranked = sorted(
            grouped[key],
            key=lambda entry: (
                _coerce_float(entry.get("parameter_count")) or float("inf"),
                _coerce_float(entry.get("metric_value")) or float("inf"),
                str(entry.get("entry_id") or ""),
            ),
        )
        for index, entry in enumerate(ranked, start=1):
            entry["parameter_rank"] = index
        cohorts.append(
            {
                "cohort": _cohort_label(key, stress=bool(ranked[0].get("is_stress_run"))) if ranked else "",
                "entry_count": len(ranked),
                "entries": ranked,
            }
        )
    return {
        "schema_version": LEADERBOARD_VIEW_SCHEMA_VERSION,
        "view": "parameter_efficiency",
        "description": "Admitted entries ranked by parameter count within comparable cohorts.",
        "generated_at": _utc_now(),
        "entry_count": len(filtered),
        "cohort_count": len(cohorts),
        "cohorts": cohorts,
    }


def _build_convergence_efficiency(entries: Sequence[Mapping[str, Any]]) -> tuple[dict[str, Any] | None, str | None]:
    admitted = [
        dict(entry)
        for entry in entries
        if str(entry.get("disposition") or "") in {"official", "unofficial", "stress_only"}
        and "convergence_efficiency" in entry.get("eligible_views", [])
    ]
    if not admitted:
        return None, "Convergence efficiency is unavailable because no admitted cohort exposes train-duration evidence."
    if any(entry.get("train_duration_seconds") is None for entry in admitted):
        return None, "Convergence efficiency is unavailable because at least one admitted cohort lacks complete train-duration evidence."

    grouped: dict[tuple[str, ...], list[dict[str, Any]]] = defaultdict(list)
    for entry in admitted:
        grouped[_group_key(entry, stress=bool(entry.get("is_stress_run")))].append(entry)
    cohorts: list[dict[str, Any]] = []
    for key in sorted(grouped):
        ranked = sorted(
            grouped[key],
            key=lambda entry: (
                _coerce_float(entry.get("train_duration_seconds")) or float("inf"),
                _coerce_float(entry.get("metric_value")) or float("inf"),
                str(entry.get("entry_id") or ""),
            ),
        )
        for index, entry in enumerate(ranked, start=1):
            entry["convergence_rank"] = index
        cohorts.append(
            {
                "cohort": _cohort_label(key, stress=bool(ranked[0].get("is_stress_run"))) if ranked else "",
                "entry_count": len(ranked),
                "entries": ranked,
            }
        )
    return {
        "schema_version": LEADERBOARD_VIEW_SCHEMA_VERSION,
        "view": "convergence_efficiency",
        "description": "Admitted entries ranked by train duration within comparable cohorts.",
        "generated_at": _utc_now(),
        "entry_count": len(admitted),
        "cohort_count": len(cohorts),
        "cohorts": cohorts,
    }, None


def _render_view_markdown(title: str, payload: Mapping[str, Any]) -> str:
    lines = [f"# {title}", ""]
    if payload.get("description"):
        lines.append(str(payload.get("description")))
        lines.append("")
    lines.append(f"- Entries: `{payload.get('entry_count', 0)}`")
    lines.append(f"- Cohorts: `{payload.get('cohort_count', 0)}`")
    lines.append("")
    for cohort in payload.get("cohorts", []):
        lines.append(f"## {cohort.get('cohort')}")
        lines.append("")
        for entry in cohort.get("entries", []):
            lines.append(
                "- `{entry_id}` | disposition=`{disposition}` | model=`{model}` | metric=`{metric}` | value=`{value}` | params=`{params}` | duration=`{duration}`".format(
                    entry_id=entry.get("entry_id"),
                    disposition=entry.get("disposition"),
                    model=entry.get("model_name"),
                    metric=entry.get("metric_name"),
                    value=_render_value(entry.get("metric_value")),
                    params=_render_value(entry.get("parameter_count")),
                    duration=_render_value(entry.get("train_duration_seconds")),
                )
            )
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def _render_admission_registry_markdown(payload: Mapping[str, Any]) -> str:
    summary = payload.get("summary", {})
    lines = [
        "# Admission Registry",
        "",
        f"- Target benchmark line: `{payload.get('target_benchmark_line')}`",
        f"- Total entries: `{summary.get('entry_count')}`",
        f"- Official entries: `{summary.get('official_count')}`",
        f"- Imported entries: `{summary.get('imported_count')}`",
        f"- Disposition counts: `{summary.get('by_disposition')}`",
        "",
    ]
    for entry in payload.get("entries", []):
        lines.append(
            "- `{entry_id}` | disposition=`{disposition}` | protocol=`{protocol}` | eligible_views=`{views}`".format(
                entry_id=entry.get("entry_id"),
                disposition=entry.get("disposition"),
                protocol=entry.get("protocol"),
                views=entry.get("eligible_views"),
            )
        )
    lines.append("")
    return "\n".join(lines)


def _build_governance_packet(
    *,
    target_line: str | None,
    grouped_payload: Mapping[str, Any],
    entries: Sequence[Mapping[str, Any]],
    governance_packets: Sequence[Mapping[str, Any]],
    warnings: Sequence[str],
) -> dict[str, Any]:
    imported_entries = [entry for entry in entries if entry.get("source_kind") == "imported_bundle"]
    disposition_counts = Counter(str(entry.get("disposition") or "unknown") for entry in imported_entries)
    official_rows = [dict(row) for row in grouped_payload.get("rows", []) if isinstance(row, Mapping)]
    stress_policy = assess_stress_comparability(official_rows)
    return {
        "schema_version": GOVERNANCE_PACKET_SCHEMA_VERSION,
        "generated_at": _utc_now(),
        "target_benchmark_line": target_line,
        "summary": {
            "official_entry_count": sum(1 for entry in entries if entry.get("disposition") == "official"),
            "imported_entry_count": len(imported_entries),
            "imported_disposition_counts": dict(sorted(disposition_counts.items())),
            "stress_policy_class": stress_policy.get("policy_class"),
        },
        "imported_entries": [
            {
                "entry_id": entry.get("entry_id"),
                "disposition": entry.get("disposition"),
                "eligible_views": entry.get("eligible_views"),
                "comparability_class": entry.get("comparability_class"),
                "reasons": entry.get("reasons"),
            }
            for entry in imported_entries
        ],
        "imported_governance_packets": list(governance_packets),
        "caveats": [
            "Imported bundles are never promoted to official in v1.2-preview.",
            "Stress views remain family-matched, severity-matched, and cohort-local.",
            *[str(item) for item in warnings],
        ],
    }


def _render_governance_markdown(payload: Mapping[str, Any]) -> str:
    lines = [
        "# Leaderboard Governance Packet",
        "",
        f"- Target benchmark line: `{payload.get('target_benchmark_line')}`",
        f"- Summary: `{payload.get('summary')}`",
        "",
        "## Imported Entries",
        "",
    ]
    for entry in payload.get("imported_entries", []):
        lines.append(
            "- `{entry_id}` | disposition=`{disposition}` | comparability=`{comparability}` | views=`{views}`".format(
                entry_id=entry.get("entry_id"),
                disposition=entry.get("disposition"),
                comparability=entry.get("comparability_class"),
                views=entry.get("eligible_views"),
            )
        )
        for reason in entry.get("reasons", []):
            lines.append(f"  - {reason}")
    lines.extend(["", "## Caveats", ""])
    for caveat in payload.get("caveats", []):
        lines.append(f"- {caveat}")
    lines.append("")
    return "\n".join(lines)


def _write_view(output_dir: Path, name: str, payload: Mapping[str, Any], *, title: str) -> tuple[str, str]:
    json_path = output_dir / f"{name}.json"
    md_path = output_dir / f"{name}.md"
    _write_json(json_path, payload)
    md_path.write_text(_render_view_markdown(title, payload), encoding="utf-8")
    return str(json_path.resolve()), str(md_path.resolve())


def _view_coverage_summary(view_payloads: Mapping[str, Mapping[str, Any]]) -> dict[str, Any]:
    return {
        name: {
            "entry_count": int(payload.get("entry_count", 0) or 0),
            "cohort_count": int(payload.get("cohort_count", 0) or 0),
        }
        for name, payload in view_payloads.items()
    }


def export_leaderboard_protocol(
    *,
    outputs_root: str | Path | None = None,
    grouped_json: str | Path | None = None,
    imports_root: str | Path | None = None,
    output_dir: str | Path | None = None,
) -> dict[str, Any]:
    resolved_outputs_root = _resolve_outputs_root(outputs_root)
    resolved_grouped_json = (resolved_outputs_root / "_leaderboard" / "leaderboard_grouped.json").resolve() if grouped_json is None else Path(grouped_json).resolve()
    resolved_imports_root = (resolved_outputs_root / "_submission_imports").resolve() if imports_root is None else Path(imports_root).resolve()
    resolved_output_dir = (resolved_outputs_root / "_leaderboard_protocol").resolve() if output_dir is None else Path(output_dir).resolve()
    resolved_output_dir.mkdir(parents=True, exist_ok=True)

    grouped_payload = load_grouped_payload(resolved_grouped_json)
    target_line = infer_benchmark_line_from_manifest_path(grouped_payload.get("matrix_manifest"))

    official_entries = [entry for entry in (_official_entry_from_row(row) for row in grouped_payload.get("rows", [])) if entry is not None]
    imported_entries, governance_packets, warnings = _load_imported_entries(resolved_imports_root, target_line=target_line)
    all_entries = sorted([*official_entries, *imported_entries], key=lambda entry: str(entry.get("entry_id") or ""))

    admission_registry = _admission_registry(all_entries, target_line=target_line)
    admission_registry_json = resolved_output_dir / "admission_registry.json"
    admission_registry_md = resolved_output_dir / "admission_registry.md"
    _write_json(admission_registry_json, admission_registry)
    admission_registry_md.write_text(_render_admission_registry_markdown(admission_registry), encoding="utf-8")

    main_view = _build_view_payload(
        view_name="main_leaderboard",
        description="Official and unofficial nominal-comparable entries grouped by nominal cohort.",
        entries=_main_entries(all_entries),
    )
    stress_view = _build_view_payload(
        view_name="stress_leaderboard",
        description="Official stress rows plus admitted stress-only imports, grouped by severity-matched cohort.",
        entries=_stress_entries(all_entries),
        stress=True,
    )
    pareto_view = _build_pareto_view(_main_entries(all_entries))
    parameter_efficiency = _build_parameter_efficiency(all_entries)
    convergence_efficiency, unavailable_note = _build_convergence_efficiency(all_entries)
    governance_packet = _build_governance_packet(
        target_line=target_line,
        grouped_payload=grouped_payload,
        entries=all_entries,
        governance_packets=governance_packets,
        warnings=warnings,
    )
    governance_json = resolved_output_dir / "governance_packet.json"
    governance_md = resolved_output_dir / "governance_packet.md"
    _write_json(governance_json, governance_packet)
    governance_md.write_text(_render_governance_markdown(governance_packet), encoding="utf-8")

    written_views = {}
    for name, payload, title in [
        ("main_leaderboard", main_view, "Main Leaderboard"),
        ("stress_leaderboard", stress_view, "Stress Leaderboard"),
        ("pareto_leaderboard", pareto_view, "Pareto Leaderboard"),
        ("parameter_efficiency", parameter_efficiency, "Parameter Efficiency"),
    ]:
        written_views[name] = _write_view(resolved_output_dir, name, payload, title=title)

    if convergence_efficiency is not None:
        written_views["convergence_efficiency"] = _write_view(
            resolved_output_dir,
            "convergence_efficiency",
            convergence_efficiency,
            title="Convergence Efficiency",
        )
    else:
        unavailable_path = resolved_output_dir / "convergence_efficiency_unavailable.md"
        unavailable_path.write_text(
            "# Convergence Efficiency Unavailable\n\n" + str(unavailable_note or "No convergence evidence is available.") + "\n",
            encoding="utf-8",
        )
        written_views["convergence_efficiency_unavailable"] = (None, str(unavailable_path.resolve()))

    stress_policy = assess_stress_comparability([dict(row) for row in grouped_payload.get("rows", []) if isinstance(row, Mapping)])
    bundle = {
        "schema_version": PROTOCOL_BUNDLE_SCHEMA_VERSION,
        "generated_at": _utc_now(),
        "outputs_root": str(resolved_outputs_root),
        "grouped_json": str(resolved_grouped_json),
        "imports_root": str(resolved_imports_root),
        "output_dir": str(resolved_output_dir),
        "matrix_manifest": grouped_payload.get("matrix_manifest"),
        "target_benchmark_line": target_line,
        "admission_summary": admission_registry.get("summary"),
        "view_coverage_summary": _view_coverage_summary(
            {
                "main_leaderboard": main_view,
                "stress_leaderboard": stress_view,
                "pareto_leaderboard": pareto_view,
                "parameter_efficiency": parameter_efficiency,
                **({"convergence_efficiency": convergence_efficiency} if convergence_efficiency is not None else {}),
            }
        ),
        "comparison_fairness": {
            "stress_policy": stress_policy,
        },
        "regime_summary": dict(grouped_payload.get("regime_summary", {})),
        "regime_groups": list(grouped_payload.get("regime_groups", [])),
        "imported_examples": [
            {
                "entry_id": entry.get("entry_id"),
                "disposition": entry.get("disposition"),
                "candidate_path": entry.get("candidate_path"),
                "governance_path": entry.get("governance_path"),
            }
            for entry in imported_entries
        ],
        "warnings": warnings,
        "artifacts": {
            "admission_registry": {
                "json": str(admission_registry_json.resolve()),
                "md": str(admission_registry_md.resolve()),
            },
            "main_leaderboard": {"json": written_views["main_leaderboard"][0], "md": written_views["main_leaderboard"][1]},
            "stress_leaderboard": {"json": written_views["stress_leaderboard"][0], "md": written_views["stress_leaderboard"][1]},
            "pareto_leaderboard": {"json": written_views["pareto_leaderboard"][0], "md": written_views["pareto_leaderboard"][1]},
            "parameter_efficiency": {"json": written_views["parameter_efficiency"][0], "md": written_views["parameter_efficiency"][1]},
            "governance_packet": {
                "json": str(governance_json.resolve()),
                "md": str(governance_md.resolve()),
            },
        },
    }
    if convergence_efficiency is not None:
        bundle["artifacts"]["convergence_efficiency"] = {
            "json": written_views["convergence_efficiency"][0],
            "md": written_views["convergence_efficiency"][1],
        }
    else:
        bundle["artifacts"]["convergence_efficiency_unavailable"] = {
            "md": written_views["convergence_efficiency_unavailable"][1],
        }

    bundle_path = resolved_output_dir / "leaderboard_protocol_bundle.json"
    _write_json(bundle_path, bundle)
    return {
        "bundle_path": str(bundle_path.resolve()),
        "output_dir": str(resolved_output_dir),
        "admission_summary": admission_registry.get("summary"),
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Render static leaderboard protocol artifacts for a preview outputs root.")
    parser.add_argument(
        "--outputs-root",
        type=str,
        default=None,
        help="Preview outputs root. Defaults to the current preview root when available.",
    )
    parser.add_argument(
        "--grouped-json",
        type=str,
        default=None,
        help="Grouped leaderboard JSON. Defaults to <outputs-root>/_leaderboard/leaderboard_grouped.json.",
    )
    parser.add_argument(
        "--imports-root",
        type=str,
        default=None,
        help="Submission imports root. Defaults to <outputs-root>/_submission_imports.",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default=None,
        help="Output directory. Defaults to <outputs-root>/_leaderboard_protocol.",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    result = export_leaderboard_protocol(
        outputs_root=args.outputs_root,
        grouped_json=args.grouped_json,
        imports_root=args.imports_root,
        output_dir=args.output_dir,
    )
    print(f"Leaderboard protocol bundle written to {result['bundle_path']}")
    print(f"Output directory: {result['output_dir']}")
    print(f"Admission summary: {result['admission_summary']}")


if __name__ == "__main__":
    main()
