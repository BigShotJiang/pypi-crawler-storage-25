"""Compare a submission bundle against grouped official results."""

from __future__ import annotations

import argparse
import json
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

from pinn_bench.comparison import comparison_dict_from_mapping
from pinn_bench.analysis.fairness import assess_comparison_fairness
from pinn_bench.community.admission import build_resolved_admission, derive_bundle_stress_profile
from pinn_bench.community.bundle import bundle_metric, infer_benchmark_line_from_manifest_path, load_bundle_files
from pinn_bench.community.validate_submission import SUBMISSION_SCHEMA_V1, build_submission_validation_payload
from pinn_bench.leaderboard.reporting import load_grouped_payload
from pinn_bench.superbench.contracts import SUPERBENCH_SUBMISSION_OPTIONAL_FIELDS
from pinn_bench.version import LATEST_FORMAL_BASELINE


def _resolve_grouped_target_line(grouped_payload: Mapping[str, Any]) -> str:
    inferred = infer_benchmark_line_from_manifest_path(grouped_payload.get("matrix_manifest"))
    return inferred or LATEST_FORMAL_BASELINE


def _metrics_metadata(metrics: Mapping[str, Any]) -> dict[str, Any]:
    metadata = metrics.get("metadata")
    return dict(metadata) if isinstance(metadata, Mapping) else {}


def _artifact_completeness(validation: Mapping[str, Any]) -> str:
    if not bool(validation.get("valid")):
        return "missing_critical"
    if int(validation.get("summary", {}).get("warning", 0) or 0) > 0:
        return "partial"
    return "complete"


def _bundle_modes(metrics: Mapping[str, Any]) -> dict[str, str]:
    metadata = _metrics_metadata(metrics)
    return {
        "task_mode": str(metadata.get("task_mode") or "pointwise"),
        "model_mode": str(metadata.get("model_mode") or "pointwise"),
        "evaluation_mode": str(metadata.get("evaluation_mode") or metadata.get("task_mode") or "pointwise"),
    }


def _build_stress_alignment(*, submission: Mapping[str, Any], metrics: Mapping[str, Any], grouped_rows: list[dict[str, Any]]) -> dict[str, Any]:
    stress_profile = derive_bundle_stress_profile(submission=submission, metrics=metrics)
    protocol = str(submission.get("protocol") or "none")
    if not bool(stress_profile.get("is_stress_run")):
        return {
            "eligible": False,
            "matched_row_count": 0,
            "mode_compatible": True,
            "reason": "Nominal bundles do not use the stress-only admission path.",
            "stress_profile": stress_profile,
        }

    modes = _bundle_modes(metrics)
    task_name = str(submission.get("task_name") or "")
    model_name = str(submission.get("model_name") or "")
    family = str(stress_profile.get("stress_family") or "")
    severity = str(stress_profile.get("stress_severity") or "")
    matched = [
        row
        for row in grouped_rows
        if str(row.get("task_name") or "") == task_name
        and str(row.get("model_name") or "") == model_name
        and str(row.get("protocol") or "") == protocol
        and str(row.get("task_mode") or modes["task_mode"]) == modes["task_mode"]
        and str(row.get("model_mode") or modes["model_mode"]) == modes["model_mode"]
        and str(row.get("evaluation_mode") or modes["evaluation_mode"]) == modes["evaluation_mode"]
        and str(row.get("stress_family") or "") == family
        and str(row.get("stress_severity") or "") == severity
        and int(row.get("run_count", 0) or 0) > 0
    ]
    eligible = bool(matched) and bool(family) and bool(severity)
    reason = (
        "Stress bundle has a severity- and cohort-matched official comparison slice."
        if eligible
        else "Stress bundle lacks a severity- and cohort-matched official comparison slice, so it remains appendix-only."
    )
    return {
        "eligible": eligible,
        "matched_row_count": len(matched),
        "mode_compatible": bool(matched) or not bool(family),
        "reason": reason,
        "stress_profile": stress_profile,
    }


def build_bundle_comparison_payload(
    bundle_dir: Path,
    grouped_json: Path,
    *,
    schema_version: str = SUBMISSION_SCHEMA_V1,
    against_benchmark_line: str | None = None,
) -> dict[str, Any]:
    grouped_payload = load_grouped_payload(grouped_json)
    grouped_target_line = _resolve_grouped_target_line(grouped_payload)
    if against_benchmark_line is not None and str(against_benchmark_line).strip() != grouped_target_line:
        raise ValueError(
            f"Requested target line '{against_benchmark_line}' does not match grouped payload target '{grouped_target_line}'."
        )
    target_line = grouped_target_line
    grouped_manifest = grouped_payload.get("matrix_manifest")
    validation = build_submission_validation_payload(
        bundle_dir,
        schema_version=schema_version,
        against_benchmark_line=target_line,
        against_manifest=str(grouped_manifest) if grouped_manifest else None,
    )
    compatibility = validation["compatibility"]
    if not validation["valid"]:
        raise ValueError("Bundle validation failed. Run `pinn-bench validate-submission` first.")
    if str(compatibility.get("status")) == "incompatible":
        reasons = "; ".join(str(item) for item in compatibility.get("reasons", []))
        raise ValueError(f"Bundle is incompatible with target line {target_line}: {reasons}")

    loaded = load_bundle_files(bundle_dir)
    submission_raw = loaded.get("submission.json")
    metrics_raw = loaded.get("metrics.json")
    if not isinstance(submission_raw, Mapping) or not isinstance(metrics_raw, Mapping):
        raise ValueError("Bundle payload is missing submission.json or metrics.json.")
    submission = dict(submission_raw)
    metrics = dict(metrics_raw)
    metadata = _metrics_metadata(metrics)
    bundle_comparison = comparison_dict_from_mapping(submission.get("comparison"), location="submission.comparison")
    superbench = {
        field: submission.get(field)
        for field in SUPERBENCH_SUBMISSION_OPTIONAL_FIELDS
        if submission.get(field) not in {None, ""}
    }

    grouped_rows = grouped_payload.get("rows") if isinstance(grouped_payload.get("rows"), list) else []
    task_name = str(submission["task_name"])
    protocol = str(submission["protocol"])
    metric_name, bundle_value = bundle_metric(metrics)
    grouped_metric_name = "eval_relative_l2_mean" if metric_name.endswith("relative_l2") else "eval_mse_mean"

    slice_rows = [
        row
        for row in grouped_rows
        if isinstance(row, Mapping)
        and str(row.get("task_name", "")) == task_name
        and str(row.get("protocol", "")) == protocol
        and int(row.get("run_count", 0) or 0) > 0
        and row.get(grouped_metric_name) is not None
    ]
    if not slice_rows:
        raise ValueError(
            f"No grouped slice matched task '{task_name}' with protocol '{protocol}' in {grouped_json.resolve()}."
        )

    sorted_rows = sorted(slice_rows, key=lambda row: float(row[grouped_metric_name]))
    best_row = sorted_rows[0]
    better_than = sum(1 for row in sorted_rows if float(row[grouped_metric_name]) > bundle_value)
    behind = sum(1 for row in sorted_rows if float(row[grouped_metric_name]) < bundle_value)
    tied = len(sorted_rows) - better_than - behind
    delta_vs_best = bundle_value - float(best_row[grouped_metric_name])

    stress_alignment = _build_stress_alignment(submission=submission, metrics=metrics, grouped_rows=[dict(row) for row in grouped_rows if isinstance(row, Mapping)])
    artifact_completeness = _artifact_completeness(validation)
    fairness = assess_comparison_fairness(
        benchmark_line_match=str(submission.get("benchmark_line") or "").strip() == target_line,
        slice_match=bool(sorted_rows),
        protocol_supported=str(compatibility.get("status")) != "incompatible",
        mode_compatible=bool(stress_alignment.get("mode_compatible", True)),
        artifact_completeness=artifact_completeness,
        reference_available=bool(sorted_rows),
        context_label="Bundle comparison",
    )
    train = metrics.get("train") if isinstance(metrics.get("train"), Mapping) else {}
    train_duration_seconds = train.get("duration_seconds")
    admission = build_resolved_admission(
        submission=submission,
        compatibility=compatibility,
        fairness=fairness,
        stress_alignment=stress_alignment,
        has_duration=train_duration_seconds not in {None, ""},
    )

    caveats = [] if compatibility["status"] == "compatible" else [str(item) for item in compatibility.get("reasons", [])]
    caveats.extend(str(item) for item in fairness.get("rank_context_notes", []))
    payload = {
        "bundle": {
            "dir": str(bundle_dir.resolve()),
            "benchmark_line": str(submission.get("benchmark_line", "")),
            "source_type": str(submission.get("source_type", "")),
            "task_name": task_name,
            "model_name": str(submission.get("model_name", "")),
            "protocol": protocol,
            "setting": str(submission.get("setting", "")),
            "seed": submission.get("seed"),
        },
        "target": {
            "grouped_json": str(grouped_json.resolve()),
            "matrix_manifest": str(grouped_manifest or ""),
            "benchmark_line": target_line,
        },
        "validation": validation,
        "compatibility": compatibility,
        "metric": {
            "name": metric_name,
            "grouped_field": grouped_metric_name,
            "bundle_value": bundle_value,
        },
        "slice_match": {
            "task_name": task_name,
            "protocol": protocol,
            "matched_official_rows": len(sorted_rows),
        },
        "best_official": {
            "run_id": str(best_row.get("run_id", "")),
            "model_name": str(best_row.get("model_name", "")),
            "metric_value": float(best_row[grouped_metric_name]),
        },
        "delta_vs_best": delta_vs_best,
        "ranking": {
            "better_than": better_than,
            "behind": behind,
            "tied": tied,
            "rank_if_inserted": behind + 1,
            "official_family_count": len(sorted_rows),
        },
        "metrics_metadata": {
            "task_mode": metadata.get("task_mode") or "pointwise",
            "model_mode": metadata.get("model_mode") or "pointwise",
            "evaluation_mode": metadata.get("evaluation_mode") or metadata.get("task_mode") or "pointwise",
            "inverse": dict(metadata.get("inverse")) if isinstance(metadata.get("inverse"), Mapping) else None,
        },
        "comparison": bundle_comparison,
        "parameter_count": metadata.get("parameter_count"),
        "train_duration_seconds": train_duration_seconds,
        "stress_profile": stress_alignment["stress_profile"],
        "stress_alignment": {
            "eligible": stress_alignment.get("eligible"),
            "matched_row_count": stress_alignment.get("matched_row_count"),
            "mode_compatible": stress_alignment.get("mode_compatible"),
            "reason": stress_alignment.get("reason"),
        },
        "fairness": fairness,
        "fairness_category": fairness.get("fairness_category"),
        "comparison_strength": fairness.get("comparison_strength"),
        "appendix_only_recommended": fairness.get("appendix_only_recommended"),
        "admission": admission,
        "admission_disposition": admission.get("disposition"),
        "caveats": caveats,
        "superbench": superbench,
    }
    return payload


def render_bundle_comparison_from_payload(payload: Mapping[str, Any]) -> str:
    bundle = payload["bundle"]
    target = payload["target"]
    metric = payload["metric"]
    best_official = payload["best_official"]
    ranking = payload["ranking"]
    fairness = payload.get("fairness", {})
    admission = payload.get("admission", {})
    lines = [
        "# Bundle Comparison",
        "",
        f"- Bundle dir: `{bundle['dir']}`",
        f"- Bundle line / source: `{bundle['benchmark_line']}` / `{bundle['source_type']}`",
        f"- Target line: `{target['benchmark_line']}`",
        f"- Compared against: `{target['grouped_json']}`",
        f"- Compatibility: `{payload['compatibility']['status']}`",
        f"- Admission disposition: `{payload.get('admission_disposition')}`",
        f"- Fairness category: `{fairness.get('fairness_category')}`",
        f"- Comparison strength: `{fairness.get('comparison_strength')}`",
        f"- Fair-budget metadata: `{payload.get('comparison')}`",
        f"- Appendix-only recommended: `{fairness.get('appendix_only_recommended')}`",
        f"- Slice: task=`{bundle['task_name']}` protocol=`{bundle['protocol']}`",
        f"- Metric used: `{metric['name']}`",
        f"- Bundle metric value: `{metric['bundle_value']:.6g}`",
        f"- Best official family in slice: `{best_official['run_id']}` with `{best_official['metric_value']:.6g}`",
        f"- Delta vs best: `{payload['delta_vs_best']:.6g}`",
        (
            f"- Approximate position: inserted rank `{ranking['rank_if_inserted']}` across `{ranking['official_family_count'] + 1}` rows; "
            f"better than `{ranking['better_than']}`, behind `{ranking['behind']}`, tied with `{ranking['tied']}` official families."
        ),
        f"- Eligible leaderboard views: `{admission.get('eligible_views')}`",
    ]
    stress_alignment = payload.get("stress_alignment", {})
    if bundle.get("protocol") != "none":
        lines.append(f"- Stress alignment eligible: `{stress_alignment.get('eligible')}`")
        lines.append(f"- Stress alignment reason: {stress_alignment.get('reason')}")
    if payload.get("caveats"):
        lines.append("- Caveats:")
        for caveat in payload["caveats"]:
            lines.append(f"  - {caveat}")
    lines.extend(["", "This comparison is slice-local and intentionally lightweight.", ""])
    return "\n".join(lines)


def render_bundle_comparison(
    bundle_dir: Path,
    grouped_json: Path,
    *,
    schema_version: str = SUBMISSION_SCHEMA_V1,
    against_benchmark_line: str | None = None,
) -> str:
    payload = build_bundle_comparison_payload(
        bundle_dir,
        grouped_json,
        schema_version=schema_version,
        against_benchmark_line=against_benchmark_line,
    )
    return render_bundle_comparison_from_payload(payload)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Compare a result bundle against grouped official baseline results.")
    parser.add_argument("bundle_dir", type=str, help="Path to the bundle directory.")
    parser.add_argument("--against", required=True, type=str, help="Path to a grouped leaderboard JSON file.")
    parser.add_argument("--output-file", type=str, default=None, help="Optional Markdown/text or JSON output file.")
    parser.add_argument(
        "--against-benchmark-line",
        type=str,
        default=None,
        help="Optional explicit target benchmark line. If supplied, it must match the grouped payload target.",
    )
    format_group = parser.add_mutually_exclusive_group()
    format_group.add_argument("--json", action="store_true", help="Emit a machine-readable comparison payload.")
    format_group.add_argument("--markdown", action="store_true", help="Force Markdown/text rendering.")
    return parser


def main(argv: Sequence[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    bundle_dir = Path(args.bundle_dir)
    grouped_json = Path(args.against)
    try:
        payload = build_bundle_comparison_payload(
            bundle_dir,
            grouped_json,
            against_benchmark_line=args.against_benchmark_line,
        )
        rendered = json.dumps(payload, indent=2) if args.json else render_bundle_comparison_from_payload(payload)
    except ValueError as error:
        raise SystemExit(str(error))

    if args.output_file is not None:
        output_path = Path(args.output_file).resolve()
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(rendered, encoding="utf-8")
        print(f"Bundle comparison written to {output_path}")
    print(rendered)


if __name__ == "__main__":
    main()
