"""Package one run directory into a submission bundle."""

from __future__ import annotations

import argparse
from collections.abc import Sequence
from pathlib import Path

from pinn_bench.community.bundle import SUBMISSION_SCHEMA_V1, copy_bundle_artifacts


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Package a single run directory into a community submission bundle.")
    parser.add_argument(
        "run_dir",
        type=str,
        help="Path to a single run directory containing metrics.json and config_snapshot.yaml.",
    )
    parser.add_argument("--output-dir", required=True, type=str, help="Directory where the submission bundle will be written.")
    parser.add_argument(
        "--schema-version",
        type=str,
        default=SUBMISSION_SCHEMA_V1,
        help=f"Submission bundle schema version to write. Defaults to {SUBMISSION_SCHEMA_V1}.",
    )
    parser.add_argument("--include-train-log", action="store_true", help="Copy train_log.csv into optional/train_log.csv if present.")
    parser.add_argument("--include-plots", action="store_true", help="Copy PNG plots into optional/plots/ if present.")
    parser.add_argument("--include-model-card", action="store_true", help="Copy the builtin model card into optional/model_card.md when available.")
    parser.add_argument("--include-task-card", action="store_true", help="Copy the builtin task card into optional/task_card.md when available.")
    return parser


def main(argv: Sequence[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    written = copy_bundle_artifacts(
        run_dir=Path(args.run_dir),
        output_dir=Path(args.output_dir),
        schema_version=str(args.schema_version),
        include_train_log=bool(args.include_train_log),
        include_plots=bool(args.include_plots),
        include_model_card=bool(args.include_model_card),
        include_task_card=bool(args.include_task_card),
    )
    print("Packaged bundle artifacts:")
    for name in sorted(written):
        print(f"- {name}: {Path(written[name]).resolve()}")


if __name__ == "__main__":
    main()
