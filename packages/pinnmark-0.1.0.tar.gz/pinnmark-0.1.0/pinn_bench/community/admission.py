"""Admission helpers for bundle review and leaderboard protocol surfaces."""

from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path
from typing import Any

from pinn_bench.comparison import comparison_dict_from_mapping
from pinn_bench.stress import apply_stress_metadata
from pinn_bench.superbench.contracts import derive_cohort_id


PRELIMINARY_SCHEMA_VERSION = "submission_admission.v0.1"
ENTRY_CANDIDATE_SCHEMA_VERSION = "leaderboard.entry_candidate.v0.1"
GOVERNANCE_PACKET_SCHEMA_VERSION = "leaderboard.governance_packet.v0.1"


def _coerce_float(value: Any) -> float | None:
    if value in {None, ""}:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _submission_protocol(submission: Mapping[str, Any]) -> str:
    return str(submission.get("protocol") or "none").strip().lower()


def derive_bundle_stress_profile(*, submission: Mapping[str, Any], metrics: Mapping[str, Any]) -> dict[str, Any]:
    metadata = metrics.get("metadata") if isinstance(metrics.get("metadata"), Mapping) else {}
    robustness = metadata.get("robustness") if isinstance(metadata.get("robustness"), Mapping) else {}
    train_time_range = robustness.get("train_time_range") if isinstance(robustness.get("train_time_range"), (list, tuple)) else None
    eval_time_range = robustness.get("eval_time_range") if isinstance(robustness.get("eval_time_range"), (list, tuple)) else None
    row = {
        "run_id": str(submission.get("run_id") or ""),
        "protocol": _submission_protocol(submission),
        "robustness_level": robustness.get("level"),
        "train_time_range_start": train_time_range[0] if train_time_range and len(train_time_range) == 2 else None,
        "train_time_range_end": train_time_range[1] if train_time_range and len(train_time_range) == 2 else None,
        "eval_time_range_start": eval_time_range[0] if eval_time_range and len(eval_time_range) == 2 else None,
        "eval_time_range_end": eval_time_range[1] if eval_time_range and len(eval_time_range) == 2 else None,
        "degradation_ratio_vs_standard": None,
    }
    return apply_stress_metadata(row)


def _base_eligible_views(disposition: str, *, protocol: str, has_duration: bool) -> list[str]:
    if disposition == "rejected":
        return []
    if disposition == "appendix_only":
        return ["admission_registry"]
    if disposition == "stress_only":
        views = ["admission_registry", "stress_leaderboard", "parameter_efficiency"]
        if has_duration:
            views.append("convergence_efficiency")
        return views
    views = ["admission_registry", "main_leaderboard", "pareto_leaderboard", "parameter_efficiency"]
    if has_duration:
        views.append("convergence_efficiency")
    if protocol != "none":
        views = [view for view in views if view not in {"main_leaderboard", "pareto_leaderboard"}]
        views.insert(1, "stress_leaderboard")
    return views


def build_preliminary_admission(
    *,
    submission: Mapping[str, Any],
    valid: bool,
    summary: Mapping[str, Any],
    compatibility: Mapping[str, Any],
) -> dict[str, Any]:
    protocol = _submission_protocol(submission)
    warning_count = int(summary.get("warning", 0) or 0)
    compatibility_status = str(compatibility.get("status") or "incompatible")
    reasons = [str(item) for item in compatibility.get("reasons", [])]
    source_type = str(submission.get("source_type") or "").strip().lower()
    if (not valid) or compatibility_status == "incompatible":
        disposition = "rejected"
        comparability_class = "incompatible"
        appendix_only = True
        missing_critical_evidence = True
    elif warning_count or compatibility_status == "partially_compatible":
        disposition = "appendix_only"
        comparability_class = "partial"
        appendix_only = True
        missing_critical_evidence = False
    elif protocol != "none":
        disposition = "stress_only"
        comparability_class = "stress_candidate"
        appendix_only = False
        missing_critical_evidence = False
    else:
        disposition = "unofficial"
        comparability_class = "nominal_candidate"
        appendix_only = False
        missing_critical_evidence = False
    if not reasons:
        if disposition == "stress_only":
            reasons = ["Validation is compatible; final stress admission depends on severity- and cohort-matched comparison."]
        elif disposition == "unofficial":
            reasons = ["Validation is compatible; final leaderboard admission remains comparison-local."]
        elif disposition == "appendix_only":
            reasons = ["Bundle remains reviewable, but current validation signals already require caveated treatment."]
        else:
            reasons = ["Bundle is invalid or incompatible for the requested benchmark line."]
    return {
        "schema_version": PRELIMINARY_SCHEMA_VERSION,
        "stage": "validation",
        "source_type": source_type,
        "disposition": disposition,
        "reasons": reasons,
        "eligible_views": _base_eligible_views(disposition, protocol=protocol, has_duration=False),
        "appendix_only": appendix_only,
        "comparability_class": comparability_class,
        "missing_critical_evidence": missing_critical_evidence,
    }


def build_resolved_admission(
    *,
    submission: Mapping[str, Any],
    compatibility: Mapping[str, Any],
    fairness: Mapping[str, Any],
    stress_alignment: Mapping[str, Any],
    has_duration: bool,
) -> dict[str, Any]:
    protocol = _submission_protocol(submission)
    compatibility_status = str(compatibility.get("status") or "incompatible")
    fairness_category = str(fairness.get("fairness_category") or "not_comparable")
    comparison_strength = str(fairness.get("comparison_strength") or "none")
    appendix_only_recommended = bool(fairness.get("appendix_only_recommended", True))
    reasons = [str(item) for item in fairness.get("fairness_notes", [])]
    reasons.extend(str(item) for item in compatibility.get("reasons", []))

    if compatibility_status == "incompatible":
        disposition = "rejected"
        comparability_class = "incompatible"
    elif protocol != "none":
        if bool(stress_alignment.get("eligible")) and not appendix_only_recommended:
            disposition = "stress_only"
            comparability_class = "stress_within_cohort"
        else:
            disposition = "appendix_only"
            comparability_class = "stress_appendix_only"
    elif comparison_strength in {"strong", "moderate"} and fairness_category in {"fair", "mostly_fair"} and not appendix_only_recommended:
        disposition = "unofficial"
        comparability_class = "nominal_slice_local"
    else:
        disposition = "appendix_only"
        comparability_class = "appendix_only"

    if disposition == "stress_only" and stress_alignment.get("reason"):
        reasons.insert(0, str(stress_alignment.get("reason")))
    if disposition == "appendix_only" and stress_alignment.get("reason") and protocol != "none":
        reasons.insert(0, str(stress_alignment.get("reason")))

    deduped_reasons: list[str] = []
    seen: set[str] = set()
    for reason in reasons:
        if reason and reason not in seen:
            deduped_reasons.append(reason)
            seen.add(reason)

    return {
        "schema_version": PRELIMINARY_SCHEMA_VERSION,
        "stage": "comparison",
        "disposition": disposition,
        "reasons": deduped_reasons,
        "eligible_views": _base_eligible_views(disposition, protocol=protocol, has_duration=has_duration),
        "appendix_only": disposition == "appendix_only",
        "comparability_class": comparability_class,
        "missing_critical_evidence": disposition == "rejected",
    }


def build_leaderboard_entry_candidate(*, comparison_payload: Mapping[str, Any]) -> dict[str, Any]:
    bundle = comparison_payload.get("bundle", {})
    metric = comparison_payload.get("metric", {})
    admission = comparison_payload.get("admission", {})
    fairness = comparison_payload.get("fairness", {})
    stress_profile = comparison_payload.get("stress_profile", {})
    metrics_metadata = comparison_payload.get("metrics_metadata", {})
    superbench = comparison_payload.get("superbench", {}) if isinstance(comparison_payload.get("superbench"), Mapping) else {}
    comparison = comparison_dict_from_mapping(comparison_payload.get("comparison"), location="comparison_payload.comparison")
    entry_id = f"imported::{Path(str(bundle.get('dir') or '')).name}"
    return {
        "schema_version": ENTRY_CANDIDATE_SCHEMA_VERSION,
        "entry_id": entry_id,
        "source_kind": "imported_bundle",
        "source_type": bundle.get("source_type"),
        "bundle_dir": bundle.get("dir"),
        "bundle_benchmark_line": bundle.get("benchmark_line"),
        "target_benchmark_line": comparison_payload.get("target", {}).get("benchmark_line"),
        "task_name": bundle.get("task_name"),
        "task_mode": metrics_metadata.get("task_mode") or "pointwise",
        "model_name": bundle.get("model_name"),
        "model_mode": metrics_metadata.get("model_mode") or "pointwise",
        "evaluation_mode": metrics_metadata.get("evaluation_mode") or metrics_metadata.get("task_mode") or "pointwise",
        "inverse": dict(metrics_metadata.get("inverse", {})) if isinstance(metrics_metadata.get("inverse"), Mapping) else None,
        "protocol": bundle.get("protocol"),
        "setting": bundle.get("setting"),
        "seed": bundle.get("seed"),
        "comparison": comparison,
        "baseline_family": None if comparison is None else comparison.get("baseline_family"),
        "data_budget_class": None if comparison is None else comparison.get("data_budget_class"),
        "compute_budget_class": None if comparison is None else comparison.get("compute_budget_class"),
        "tuning_budget_class": None if comparison is None else comparison.get("tuning_budget_class"),
        "comparison_scope": None if comparison is None else comparison.get("comparison_scope"),
        "is_stress_run": stress_profile.get("is_stress_run"),
        "stress_family": stress_profile.get("stress_family"),
        "stress_severity": stress_profile.get("stress_severity"),
        "stress_case_id": stress_profile.get("stress_case_id"),
        "nominal_peer_run_id": stress_profile.get("nominal_peer_run_id"),
        "metric_name": metric.get("name"),
        "metric_grouped_field": metric.get("grouped_field"),
        "metric_value": metric.get("bundle_value"),
        "delta_vs_best": comparison_payload.get("delta_vs_best"),
        "parameter_count": comparison_payload.get("parameter_count"),
        "train_duration_seconds": comparison_payload.get("train_duration_seconds"),
        "compatibility_status": comparison_payload.get("compatibility", {}).get("status"),
        "fairness_category": fairness.get("fairness_category"),
        "comparison_strength": fairness.get("comparison_strength"),
        "appendix_only_recommended": fairness.get("appendix_only_recommended"),
        "disposition": admission.get("disposition"),
        "eligible_views": list(admission.get("eligible_views", [])),
        "comparability_class": admission.get("comparability_class"),
        "reasons": list(admission.get("reasons", [])),
        "ranking": dict(comparison_payload.get("ranking", {})),
        "source_benchmark_id": superbench.get("source_benchmark_id"),
        "source_benchmark_version": superbench.get("source_benchmark_version"),
        "source_adapter_version": superbench.get("source_adapter_version"),
        "canonical_task_id": superbench.get("canonical_task_id"),
        "metric_id": superbench.get("metric_id"),
        "artifact_evidence_tier": superbench.get("artifact_evidence_tier"),
        "rerun_provenance_id": superbench.get("rerun_provenance_id"),
        "cohort_id": superbench.get("cohort_id"),
        "derived_cohort_id": derive_cohort_id(
            {
                "canonical_task_id": superbench.get("canonical_task_id"),
                "observation_surface": superbench.get("observation_surface"),
                "target_surface": superbench.get("target_surface"),
                "evaluation_mode": metrics_metadata.get("evaluation_mode") or bundle.get("protocol") or "pointwise",
                "protocol_family": bundle.get("protocol") or "none",
                "severity_level": stress_profile.get("stress_severity") or "nominal",
                "metric_id": superbench.get("metric_id") or metric.get("name"),
            }
        ),
        "bridge_status": superbench.get("bridge_status"),
    }


def build_leaderboard_governance_packet(*, comparison_payload: Mapping[str, Any], candidate: Mapping[str, Any]) -> dict[str, Any]:
    disposition = str(candidate.get("disposition") or "appendix_only")
    fairness = comparison_payload.get("fairness", {})
    stress_alignment = comparison_payload.get("stress_alignment", {})
    why_admitted = None
    why_appendix_only = None
    if disposition in {"unofficial", "stress_only"}:
        why_admitted = f"Entry is {disposition} because comparison strength is `{fairness.get('comparison_strength')}` and compatibility remains `{comparison_payload.get('compatibility', {}).get('status')}`."
    if disposition == "appendix_only":
        why_appendix_only = f"Entry stays appendix-only because fairness category is `{fairness.get('fairness_category')}` and appendix_only_recommended is `{fairness.get('appendix_only_recommended')}`."
    if disposition == "rejected":
        why_appendix_only = "Entry is rejected because the bundle is invalid or incompatible for the requested benchmark line."
    return {
        "schema_version": GOVERNANCE_PACKET_SCHEMA_VERSION,
        "entry_id": candidate.get("entry_id"),
        "disposition": disposition,
        "summary": {
            "task_name": candidate.get("task_name"),
            "model_name": candidate.get("model_name"),
            "protocol": candidate.get("protocol"),
            "target_benchmark_line": candidate.get("target_benchmark_line"),
            "fairness_category": candidate.get("fairness_category"),
            "comparison_strength": candidate.get("comparison_strength"),
            "comparability_class": candidate.get("comparability_class"),
        },
        "eligible_views": list(candidate.get("eligible_views", [])),
        "why_admitted": why_admitted,
        "why_unofficial": why_admitted if disposition == "unofficial" else None,
        "why_appendix_only": why_appendix_only,
        "comparability_caveat": stress_alignment.get("reason") if stress_alignment else None,
        "reasons": list(candidate.get("reasons", [])),
    }


def render_leaderboard_governance_packet_markdown(payload: Mapping[str, Any]) -> str:
    lines = [
        "# Leaderboard Governance Packet",
        "",
        f"- Entry id: `{payload.get('entry_id')}`",
        f"- Disposition: `{payload.get('disposition')}`",
        f"- Eligible views: `{payload.get('eligible_views')}`",
        f"- Summary: `{payload.get('summary')}`",
    ]
    if payload.get("why_admitted"):
        lines.append(f"- Why admitted: {payload.get('why_admitted')}")
    if payload.get("why_unofficial"):
        lines.append(f"- Why unofficial: {payload.get('why_unofficial')}")
    if payload.get("why_appendix_only"):
        lines.append(f"- Why appendix-only: {payload.get('why_appendix_only')}")
    if payload.get("comparability_caveat"):
        lines.append(f"- Comparability caveat: {payload.get('comparability_caveat')}")
    for reason in payload.get("reasons", []):
        lines.append(f"- Reason: {reason}")
    lines.append("")
    return "\n".join(lines)
