"""Shared helpers for community submission bundles."""

from __future__ import annotations

import json
import platform
import shutil
import sys
from collections.abc import Mapping
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

from pinn_bench import __version__
from pinn_bench.comparison import comparison_dict_from_mapping
from pinn_bench.resources import resolve_repo_root
from pinn_bench.superbench.contracts import SUPERBENCH_SUBMISSION_OPTIONAL_FIELDS
from pinn_bench.version import LATEST_FORMAL_BASELINE

SUBMISSION_SCHEMA_V1 = "submission_bundle.v1"
REQUIRED_BUNDLE_FILES = (
    "submission.json",
    "metrics.json",
    "config_snapshot.yaml",
    "env.json",
    "artifacts_manifest.json",
    "summary.md",
)
OPTIONAL_BUNDLE_FILES = ("README.md",)
ALLOWED_PROTOCOLS = {
    "none",
    "noise",
    "sparsity",
    "extrapolation",
    "bcic_corruption",
    "parameter_shift",
    "resolution_shift",
    "bc_family_shift",
    "ic_family_shift",
}
ALLOWED_SOURCE_TYPES = {"official", "external"}
REQUIRED_SUBMISSION_FIELDS: dict[str, type] = {
    "schema_version": str,
    "benchmark_line": str,
    "compatibility_target": str,
    "task_name": str,
    "model_name": str,
    "protocol": str,
    "setting": str,
    "seed": int,
    "source_type": str,
    "package_version": str,
    "created_at": str,
}
OPTIONAL_SUBMISSION_FIELDS: dict[str, type] = {
    "benchmark_manifest": str,
    "submitter_name": str,
    "notes": str,
    "comparison": dict,
    "inverse": dict,
    **SUPERBENCH_SUBMISSION_OPTIONAL_FIELDS,
}

_OUTPUT_IDENTITIES: list[tuple[str, str, str | None]] = [
    ("outputs_preview_v19", "v1.9-preview", "baseline_v1_9_preview.yaml"),
    ("outputs_preview_v18", "v1.8-preview", "baseline_v1_8_preview.yaml"),
    ("outputs_preview_v17", "v1.7-preview", "baseline_v1_7_preview.yaml"),
    ("outputs_preview_v16", "v1.6-preview", "baseline_v1_6_preview.yaml"),
    ("outputs_preview_v12", "v1.2-preview", "baseline_v1_2_preview.yaml"),
    ("outputs_preview_v11", "v1.1-preview", "baseline_v1_1_preview.yaml"),
    ("outputs_v10", "v1.0", "baseline_v1_0_formal.yaml"),
    ("outputs_v06", "v0.6", "baseline_v0_6.yaml"),
    ("outputs_preview_v06", "v0.6-preview", "baseline_v0_6_preview.yaml"),
    ("outputs_preview_v05", "v0.5-preview", "baseline_v0_5_preview.yaml"),
    ("outputs_preview_v04", "v0.4-preview", "baseline_v0_4_preview.yaml"),
    ("outputs_preview_v03", "v0.3-preview", None),
    ("outputs_v04", "v0.4", "baseline_v0_4.yaml"),
    ("outputs_v05", "v0.5", "baseline_v0_5.yaml"),
    ("outputs_v03", "v0.3", "baseline_v0_3.yaml"),
    ("outputs_v02", "v0.2", "baseline_v0_2.yaml"),
    ("outputs", "v0.1", "baseline_v0_1.yaml"),
]


def _load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        raise ValueError(f"Expected a JSON object in {path}.")
    return dict(payload)



def _load_yaml(path: Path) -> dict[str, Any]:
    payload = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        raise ValueError(f"Expected a YAML mapping in {path}.")
    return dict(payload)



def load_bundle_files(bundle_dir: Path) -> dict[str, dict[str, Any] | None]:
    resolved = bundle_dir.resolve()
    files: dict[str, dict[str, Any] | None] = {}
    for filename in REQUIRED_BUNDLE_FILES + OPTIONAL_BUNDLE_FILES:
        path = resolved / filename
        if not path.exists():
            files[filename] = None
            continue
        if path.suffix == ".json":
            files[filename] = _load_json(path)
        elif path.suffix in {".yaml", ".yml"}:
            files[filename] = _load_yaml(path)
        else:
            files[filename] = None
    return files



def _builtin_names() -> tuple[set[str], set[str]]:
    import pinn_bench.models  # noqa: F401
    import pinn_bench.tasks  # noqa: F401
    from pinn_bench.registry import list_models, list_tasks

    return set(list_tasks()), set(list_models())



def infer_source_type(task_name: str, model_name: str) -> str:
    builtin_tasks, builtin_models = _builtin_names()
    return "official" if task_name in builtin_tasks and model_name in builtin_models else "external"



def infer_benchmark_identity(path: Path) -> tuple[str, str | None]:
    parts = set(path.resolve().parts)
    for root_name, line, manifest_name in _OUTPUT_IDENTITIES:
        if root_name in parts:
            return line, manifest_name
    return "custom", None



def infer_benchmark_line(run_dir: Path) -> str:
    line, _manifest_name = infer_benchmark_identity(run_dir)
    return line



def infer_benchmark_manifest(run_dir: Path) -> str | None:
    _line, manifest_name = infer_benchmark_identity(run_dir)
    if manifest_name is None:
        return None
    return f"configs/matrix/{manifest_name}"



def infer_benchmark_line_from_manifest_path(manifest_path: str | Path | None) -> str | None:
    if manifest_path is None:
        return None
    stem = Path(str(manifest_path)).stem
    if not stem.startswith("baseline_v"):
        return None
    body = stem.removeprefix("baseline_v")
    parts = body.split("_")
    if len(parts) == 2:
        major, minor = parts
        if major.isdigit() and minor.isdigit():
            return f"v{major}.{minor}"
        return None
    if len(parts) != 3:
        return None
    major, minor, suffix = parts
    if not (major.isdigit() and minor.isdigit()):
        return None
    if suffix == "preview":
        return f"v{major}.{minor}-preview"
    if suffix == "formal":
        return f"v{major}.{minor}"
    return None



def infer_manifest_name_for_line(line: str) -> str | None:
    normalized = str(line).strip()
    if not normalized.startswith("v"):
        return None
    if normalized.endswith("-preview"):
        version_bits = normalized.removeprefix("v").removesuffix("-preview").split(".")
        if len(version_bits) == 2 and all(bit.isdigit() for bit in version_bits):
            major, minor = version_bits
            return f"baseline_v{major}_{minor}_preview.yaml"
        return None
    version_bits = normalized.removeprefix("v").split(".")
    if len(version_bits) != 2 or not all(bit.isdigit() for bit in version_bits):
        return None
    major, minor = version_bits
    if major == "1" and minor == "0":
        return "baseline_v1_0_formal.yaml"
    if major == "0":
        return f"baseline_v{major}_{minor}.yaml"
    return None



def _format_setting(protocol: str, metadata: Mapping[str, Any], config: Mapping[str, Any]) -> str:
    robustness_meta = metadata.get("robustness") if isinstance(metadata.get("robustness"), Mapping) else {}
    robustness_cfg = config.get("robustness") if isinstance(config.get("robustness"), Mapping) else {}
    if protocol == "none":
        return "standard"

    level = robustness_meta.get("level", robustness_cfg.get("level"))
    if level not in {None, ""}:
        numeric = float(level)
        return f"{numeric:g}"

    train_range = robustness_meta.get("train_time_range", robustness_cfg.get("train_time_range"))
    eval_range = robustness_meta.get("eval_time_range", robustness_cfg.get("eval_time_range"))
    if isinstance(train_range, list) and isinstance(eval_range, list) and len(train_range) == 2 and len(eval_range) == 2:
        return f"train={train_range[0]}-{train_range[1]}, eval={eval_range[0]}-{eval_range[1]}"
    return "custom"



def _env_payload() -> dict[str, Any]:
    payload: dict[str, Any] = {
        "python_version": sys.version.split()[0],
        "platform": platform.platform(),
        "pinn_bench_version": __version__,
    }
    try:
        import torch

        payload["torch_version"] = torch.__version__
    except Exception:
        pass
    return payload



def bundle_metric(metrics: Mapping[str, Any]) -> tuple[str, float]:
    eval_payload = metrics.get("eval") if isinstance(metrics.get("eval"), Mapping) else {}
    relative_l2 = eval_payload.get("relative_l2")
    if relative_l2 is not None:
        return "eval.relative_l2", float(relative_l2)
    mse = eval_payload.get("mse")
    if mse is not None:
        return "eval.mse", float(mse)
    raise ValueError("Bundle metrics must contain eval.relative_l2 or eval.mse for comparison.")



def build_submission_payload_from_run(
    run_dir: Path,
    *,
    schema_version: str = SUBMISSION_SCHEMA_V1,
    compatibility_target: str = LATEST_FORMAL_BASELINE,
    submission_overrides: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    resolved = run_dir.resolve()
    metrics = _load_json(resolved / "metrics.json")
    config = _load_yaml(resolved / "config_snapshot.yaml")
    metadata = metrics.get("metadata") if isinstance(metrics.get("metadata"), Mapping) else {}

    task_name = str(metadata.get("task_name") or config.get("task", {}).get("name") or "")
    model_name = str(metadata.get("model_name") or config.get("model", {}).get("name") or "")
    robustness = metadata.get("robustness") if isinstance(metadata.get("robustness"), Mapping) else {}
    protocol = str(robustness.get("protocol") or config.get("robustness", {}).get("protocol") or "none")
    setting = _format_setting(protocol, metadata=metadata, config=config)
    seed = int(metadata.get("seed") or config.get("train", {}).get("seed") or 0)
    benchmark_line = infer_benchmark_line(resolved)
    benchmark_manifest = infer_benchmark_manifest(resolved)
    source_type = infer_source_type(task_name, model_name)

    payload: dict[str, Any] = {
        "schema_version": schema_version,
        "benchmark_line": benchmark_line,
        "task_name": task_name,
        "model_name": model_name,
        "protocol": protocol,
        "setting": setting,
        "seed": seed,
        "package_version": __version__,
        "source_type": source_type,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "compatibility_target": compatibility_target,
    }
    comparison_payload = comparison_dict_from_mapping(config.get("comparison"), location="config_snapshot.comparison")
    if comparison_payload is not None:
        payload["comparison"] = comparison_payload
    inverse_payload = metadata.get("inverse") if isinstance(metadata.get("inverse"), Mapping) else None
    if inverse_payload is not None:
        payload["inverse"] = dict(inverse_payload)
    if benchmark_manifest is not None and source_type == "official":
        payload["benchmark_manifest"] = benchmark_manifest
    if submission_overrides:
        for key, value in submission_overrides.items():
            if value is None:
                payload.pop(str(key), None)
                continue
            payload[str(key)] = value
    return payload



def _artifact_entry(*, path: str, role: str, required: bool, sha256: str | None = None) -> dict[str, Any]:
    return {
        "path": path,
        "role": role,
        "required": required,
        "sha256": sha256,
    }



def _copy_if_exists(*, source: Path, destination: Path) -> bool:
    if not source.exists():
        return False
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)
    return True



def _optional_doc_path(*, category: str, name: str) -> Path:
    repo_root = resolve_repo_root()
    filename = f"{name}-card.md"
    return repo_root / "docs" / category / filename



def _summary_lines(
    *,
    run_dir: Path,
    submission: Mapping[str, Any],
    bundled_optional: list[str],
) -> list[str]:
    lines = [
        "# Submission Bundle Summary",
        "",
        f"- Source run: `{run_dir.resolve()}`",
        f"- Schema version: `{submission.get('schema_version')}`",
        f"- Benchmark line: `{submission.get('benchmark_line')}`",
        f"- Compatibility target: `{submission.get('compatibility_target', LATEST_FORMAL_BASELINE)}`",
        f"- Task / model / protocol: `{submission.get('task_name')}` / `{submission.get('model_name')}` / `{submission.get('protocol')}`",
        f"- Setting / seed: `{submission.get('setting')}` / `{submission.get('seed')}`",
    ]
    benchmark_manifest = submission.get("benchmark_manifest")
    if benchmark_manifest:
        lines.append(f"- Benchmark manifest: `{benchmark_manifest}`")
    lines.extend(["", "## Included Optional Artifacts", ""])
    if bundled_optional:
        lines.extend([f"- `{item}`" for item in bundled_optional])
    else:
        lines.append("- No optional artifacts were bundled.")
        lines.extend(
        [
            "",
            "## Next Steps",
            "",
            "- `pinn-bench validate-submission <bundle_dir>`",
            "- Validate the bundle against the current formal line or an explicit benchmark line.",
            "- Compare the bundle against grouped official results with `pinn-bench compare-bundle <bundle_dir> --against <grouped_json>`.",
            "- Import a comparison-ready local view with `pinn-bench import-bundle <bundle_dir> --against <grouped_json> --output-dir <dir>`.",
            "",
            "Only reproducibility and comparison artifacts are bundled by default; checkpoints are intentionally excluded.",
        ]
    )
    return lines



def copy_bundle_artifacts(
    *,
    run_dir: Path,
    output_dir: Path,
    schema_version: str = SUBMISSION_SCHEMA_V1,
    compatibility_target: str = LATEST_FORMAL_BASELINE,
    submission_overrides: Mapping[str, Any] | None = None,
    include_train_log: bool = False,
    include_plots: bool = False,
    include_model_card: bool = False,
    include_task_card: bool = False,
) -> dict[str, str]:
    resolved_run_dir = run_dir.resolve()
    resolved_output_dir = output_dir.resolve()
    resolved_output_dir.mkdir(parents=True, exist_ok=True)

    copied: dict[str, str] = {}
    artifact_entries: list[dict[str, Any]] = []
    for filename in ("metrics.json", "config_snapshot.yaml"):
        source = resolved_run_dir / filename
        if not source.exists():
            raise FileNotFoundError(f"Missing required run artifact: {source}")
        destination = resolved_output_dir / filename
        shutil.copy2(source, destination)
        copied[filename] = str(destination)
        artifact_entries.append(_artifact_entry(path=filename, role=filename.removesuffix(".json").removesuffix(".yaml"), required=True))

    submission = build_submission_payload_from_run(
        resolved_run_dir,
        schema_version=schema_version,
        compatibility_target=compatibility_target,
        submission_overrides=submission_overrides,
    )
    task_name = str(submission["task_name"])
    model_name = str(submission["model_name"])

    submission_path = resolved_output_dir / "submission.json"
    submission_path.write_text(json.dumps(submission, indent=2), encoding="utf-8")
    copied["submission.json"] = str(submission_path)
    artifact_entries.append(_artifact_entry(path="submission.json", role="submission", required=True))

    env_path = resolved_output_dir / "env.json"
    env_path.write_text(json.dumps(_env_payload(), indent=2), encoding="utf-8")
    copied["env.json"] = str(env_path)
    artifact_entries.append(_artifact_entry(path="env.json", role="environment", required=True))

    bundled_optional: list[str] = []
    optional_root = resolved_output_dir / "optional"
    if include_train_log and _copy_if_exists(source=resolved_run_dir / "train_log.csv", destination=optional_root / "train_log.csv"):
        copied["optional/train_log.csv"] = str((optional_root / "train_log.csv").resolve())
        bundled_optional.append("optional/train_log.csv")
        artifact_entries.append(_artifact_entry(path="optional/train_log.csv", role="train_log", required=False))

    if include_model_card and _copy_if_exists(
        source=_optional_doc_path(category="models", name=model_name),
        destination=optional_root / "model_card.md",
    ):
        copied["optional/model_card.md"] = str((optional_root / "model_card.md").resolve())
        bundled_optional.append("optional/model_card.md")
        artifact_entries.append(_artifact_entry(path="optional/model_card.md", role="model_card", required=False))

    if include_task_card and _copy_if_exists(
        source=_optional_doc_path(category="tasks", name=task_name),
        destination=optional_root / "task_card.md",
    ):
        copied["optional/task_card.md"] = str((optional_root / "task_card.md").resolve())
        bundled_optional.append("optional/task_card.md")
        artifact_entries.append(_artifact_entry(path="optional/task_card.md", role="task_card", required=False))

    if include_plots:
        plot_paths = sorted(path for path in resolved_run_dir.glob("*.png") if path.is_file())
        if plot_paths:
            plots_root = optional_root / "plots"
            lines = ["# Optional Plot Index", "", f"- Source run: `{resolved_run_dir}`", ""]
            for plot_path in plot_paths:
                destination = plots_root / plot_path.name
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(plot_path, destination)
                relative = str(destination.relative_to(resolved_output_dir))
                copied[relative] = str(destination.resolve())
                bundled_optional.append(relative)
                artifact_entries.append(_artifact_entry(path=relative, role="plot", required=False))
                lines.append(f"- `{relative}`")
            index_path = plots_root / "index.md"
            index_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
            relative_index = str(index_path.relative_to(resolved_output_dir))
            copied[relative_index] = str(index_path.resolve())
            bundled_optional.append(relative_index)
            artifact_entries.append(_artifact_entry(path=relative_index, role="plot_index", required=False))

    summary_lines = _summary_lines(run_dir=resolved_run_dir, submission=submission, bundled_optional=bundled_optional)
    summary_path = resolved_output_dir / "summary.md"
    summary_path.write_text("\n".join(summary_lines) + "\n", encoding="utf-8")
    copied["summary.md"] = str(summary_path)
    artifact_entries.append(_artifact_entry(path="summary.md", role="summary", required=True))

    readme_path = resolved_output_dir / "README.md"
    readme_path.write_text("\n".join(summary_lines).replace("# Submission Bundle Summary", "# Result Bundle") + "\n", encoding="utf-8")
    copied["README.md"] = str(readme_path)
    artifact_entries.append(_artifact_entry(path="README.md", role="readme", required=False))

    artifacts_manifest_path = resolved_output_dir / "artifacts_manifest.json"
    artifact_entries.append(_artifact_entry(path="artifacts_manifest.json", role="artifacts_manifest", required=True))
    artifacts_manifest = {
        "schema_version": schema_version,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "artifacts": artifact_entries,
    }
    artifacts_manifest_path.write_text(json.dumps(artifacts_manifest, indent=2), encoding="utf-8")
    copied["artifacts_manifest.json"] = str(artifacts_manifest_path)
    return copied
