"""Reporting-friendly exports for grouped baseline leaderboard results."""

from __future__ import annotations

import argparse
import json
from collections import defaultdict
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

from pinn_bench.regime import REGIME_OOD_PROTOCOLS
from pinn_bench.utils.io import write_csv

REPORTING_COLUMNS = [
    "Task",
    "Task Mode",
    "Model",
    "Model Mode",
    "Evaluation Mode",
    "Protocol",
    "Setting",
    "Degradation vs Standard",
    "Noise Degradation",
    "Sparsity Degradation",
    "Extrapolation Degradation",
    "Mean Relative L2",
    "Std Relative L2",
    "Mean MSE",
    "Std MSE",
    "Count",
]
MATCHED_BUDGET_COLUMNS = [
    "Task",
    "Baseline Family",
    "Model / Reference",
    "Data Budget",
    "Compute Budget",
    "Tuning Budget",
    "Comparison Scope",
    "Metric",
    "Metric Value",
    "Parameter Count",
    "Train Duration Seconds",
]
OOD_SLICE_COLUMNS = [
    "Task",
    "Model",
    "Task Mode",
    "Protocol",
    "OOD Family",
    "Slice ID",
    "Regime Board Cell",
    "Regime Program",
    "Mean Relative L2",
    "Mean MSE",
    "Parameter Count",
    "Train Duration Seconds",
]
INVERSE_TRUST_COLUMNS = [
    "Task",
    "Model",
    "Protocol",
    "Observation Budget",
    "Observation Pattern",
    "Inverse Target",
    "Inverse Parameter",
    "Mean Parameter Error",
    "Mean Parameter Relative Error",
    "Mean Field Recovery Error",
    "Mean BC Violation",
    "Mean IC Violation",
    "Mean Residual Metric",
    "Mean Calibration Error",
    "Mean Interval Coverage",
    "Identifiability Status",
]
SPARSE_OBSERVATION_COLUMNS = [
    "Task",
    "Model",
    "Protocol",
    "Observation Budget",
    "Observation Pattern",
    "Inverse Target",
    "Mean Parameter Relative Error",
    "Mean Field Recovery Error",
    "Mean Calibration Error",
    "Mean Interval Coverage",
]


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Export reporting-friendly grouped baseline tables.")
    parser.add_argument(
        "--grouped-json",
        required=True,
        type=str,
        help="Path to leaderboard_grouped.json produced by the grouped leaderboard export.",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default=None,
        help="Directory for reporting-friendly baseline tables. Defaults to <grouped-json-dir>/reporting.",
    )
    return parser



def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    return build_parser().parse_args(argv)



def load_grouped_payload(grouped_json_path: Path) -> dict[str, Any]:
    if not grouped_json_path.exists():
        raise FileNotFoundError(f"Grouped leaderboard JSON does not exist: {grouped_json_path}")
    payload = json.loads(grouped_json_path.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        raise ValueError("Grouped leaderboard JSON must contain a top-level mapping.")
    required_keys = {"rows", "groups", "warnings", "matrix_manifest", "default_seeds"}
    missing = sorted(required_keys.difference(payload.keys()))
    if missing:
        raise ValueError(f"Grouped leaderboard JSON is missing required keys: {', '.join(missing)}")
    if not str(payload.get("matrix_manifest", "")).strip():
        raise ValueError("Grouped leaderboard JSON must include a non-empty 'matrix_manifest'.")
    rows = payload.get("rows")
    if not isinstance(rows, list):
        raise ValueError("Grouped leaderboard JSON 'rows' must be a list.")
    return dict(payload)



def derive_matrix_name(payload: Mapping[str, Any]) -> str:
    matrix_manifest = str(payload.get("matrix_manifest", "")).strip()
    if not matrix_manifest:
        raise ValueError("Cannot derive matrix name without 'matrix_manifest'.")
    return Path(matrix_manifest).stem



def _format_float(value: Any) -> str:
    if value is None:
        return ""
    return f"{float(value):.6g}"



def _display_protocol(protocol: str) -> str:
    return "standard" if protocol == "none" else protocol



def _display_mode(value: Any) -> str:
    text = str(value or "pointwise").strip()
    return text or "pointwise"


def _coerce_float(value: Any) -> float | None:
    if value in {None, "", "None", "nan"}:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _fair_budget_groups(payload: Mapping[str, Any]) -> list[dict[str, Any]]:
    groups = payload.get("fair_budget_groups")
    if not isinstance(groups, list):
        return []
    return [dict(group) for group in groups if isinstance(group, Mapping)]


def _regime_groups(payload: Mapping[str, Any]) -> list[dict[str, Any]]:
    groups = payload.get("regime_groups")
    if not isinstance(groups, list):
        return []
    return [dict(group) for group in groups if isinstance(group, Mapping)]


def _grouped_rows(payload: Mapping[str, Any]) -> list[dict[str, Any]]:
    rows = payload.get("rows")
    if not isinstance(rows, list):
        return []
    return [dict(row) for row in rows if isinstance(row, Mapping)]


def _inverse_grouped_rows(payload: Mapping[str, Any]) -> list[dict[str, Any]]:
    rows = []
    for row in _grouped_rows(payload):
        if str(row.get("inverse_parameter_name") or "").strip() or str(row.get("inverse_target_family") or "").strip():
            rows.append(row)
    return rows



def _mode_sort_bucket(*, task_mode: Any, model_mode: Any, evaluation_mode: Any) -> int:
    modes = {_display_mode(task_mode), _display_mode(model_mode), _display_mode(evaluation_mode)}
    return 1 if "field" in modes else 0



def _protocol_sort_bucket(protocol: Any) -> tuple[int, str]:
    text = str(protocol or "").strip().lower()
    order = {
        "standard": 0,
        "none": 0,
        "noise": 1,
        "sparsity": 2,
        "extrapolation": 3,
    }
    return order.get(text, 99), text



def sort_reporting_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    def sort_key(row: dict[str, Any]) -> tuple[Any, Any, Any, Any, Any, Any]:
        return (
            _mode_sort_bucket(
                task_mode=row.get("Task Mode"),
                model_mode=row.get("Model Mode"),
                evaluation_mode=row.get("Evaluation Mode"),
            ),
            str(row.get("Task", "")),
            str(row.get("Model", "")),
            *_protocol_sort_bucket(row.get("Protocol")),
            str(row.get("Setting", "")),
        )

    return sorted(rows, key=sort_key)



def build_reporting_rows(payload: Mapping[str, Any]) -> tuple[list[dict[str, Any]], list[str]]:
    rows = payload.get("rows", [])
    reporting_rows: list[dict[str, Any]] = []
    omitted_families: list[str] = []
    for row in rows:
        if not isinstance(row, Mapping):
            continue
        run_count = int(row.get("run_count", 0) or 0)
        if run_count <= 0:
            omitted_families.append(str(row.get("run_id", "")))
            continue
        protocol = str(row.get("protocol", ""))
        normalized_protocol = "support_extrapolation" if protocol == "extrapolation" else protocol
        degradation = row.get("degradation_ratio_vs_standard")
        reporting_rows.append(
            {
                "Task": str(row.get("task_name", "")),
                "Task Mode": _display_mode(row.get("task_mode")),
                "Model": str(row.get("model_name", "")),
                "Model Mode": _display_mode(row.get("model_mode")),
                "Evaluation Mode": _display_mode(row.get("evaluation_mode")),
                "Protocol": _display_protocol(protocol),
                "Setting": str(row.get("protocol_setting", "")),
                "Degradation vs Standard": _format_float(degradation),
                "Noise Degradation": _format_float(row.get("noise_degradation_ratio") if row.get("noise_degradation_ratio") is not None else (degradation if protocol == "noise" else None)),
                "Sparsity Degradation": _format_float(row.get("sparsity_degradation_ratio") if row.get("sparsity_degradation_ratio") is not None else (degradation if protocol == "sparsity" else None)),
                "Extrapolation Degradation": _format_float(
                    row.get("support_extrapolation_degradation_ratio")
                    if row.get("support_extrapolation_degradation_ratio") is not None
                    else (
                        row.get("extrapolation_degradation_ratio")
                        if row.get("extrapolation_degradation_ratio") is not None
                        else (degradation if normalized_protocol == "support_extrapolation" else None)
                    )
                ),
                "Mean Relative L2": _format_float(row.get("eval_relative_l2_mean")),
                "Std Relative L2": _format_float(row.get("eval_relative_l2_std")),
                "Mean MSE": _format_float(row.get("eval_mse_mean")),
                "Std MSE": _format_float(row.get("eval_mse_std")),
                "Count": int(run_count),
            }
        )
    return sort_reporting_rows(reporting_rows), sorted(name for name in omitted_families if name)



def build_reporting_groups(rows: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        groups[str(row["Task"])].append(row)
    return dict(groups)


def build_regime_map_payload(payload: Mapping[str, Any]) -> dict[str, Any]:
    summary = payload.get("regime_summary")
    normalized_summary = dict(summary) if isinstance(summary, Mapping) else {}
    cells: list[dict[str, Any]] = []
    for group in _regime_groups(payload):
        blockers = [str(code) for code in group.get("regime_claim_blocker_codes", [])]
        row_count = int(group.get("row_count", 0) or 0)
        cells.append(
            {
                "regime_board_cell_id": group.get("regime_board_cell_id"),
                "ood_family": group.get("ood_family"),
                "regime_problem_class": group.get("regime_problem_class"),
                "regime_dynamics_class": group.get("regime_dynamics_class"),
                "regime_observation_class": group.get("regime_observation_class"),
                "regime_distribution_class": group.get("regime_distribution_class"),
                "regime_horizon_class": group.get("regime_horizon_class"),
                "regime_geometry_class": group.get("regime_geometry_class"),
                "regime_program": group.get("regime_program"),
                "row_count": row_count,
                "baseline_families": list(group.get("baseline_families_present", [])),
                "headline_eligible_count": row_count
                if bool(group.get("regime_claim_complete")) and str(group.get("regime_program") or "") == "headline"
                else 0,
                "coverage_only_count": int(group.get("coverage_only_row_count", 0) or 0),
                "blocked_count": row_count if blockers else 0,
                "blocker_codes": blockers,
            }
        )
    cells.sort(
        key=lambda cell: (
            str(cell.get("regime_board_cell_id") or ""),
            str(cell.get("ood_family") or ""),
            str(cell.get("regime_program") or ""),
        )
    )
    normalized_summary["cell_count"] = len(cells)
    return {"summary": normalized_summary, "cells": cells}


def build_regime_map_markdown_report(*, grouped_json_path: Path, payload: Mapping[str, Any], regime_map: Mapping[str, Any]) -> str:
    lines = [
        "# Regime Map",
        "",
        f"Grouped source: `{grouped_json_path.resolve()}`",
        f"Matrix manifest: `{payload['matrix_manifest']}`",
        "",
        "## Summary",
        "",
    ]
    for key, value in dict(regime_map.get("summary", {})).items():
        lines.append(f"- {key}: `{value}`")
    lines.extend(["", "## Cells", ""])
    cells = regime_map.get("cells", [])
    if not isinstance(cells, list) or not cells:
        lines.extend(["No regime cells were exported.", ""])
        return "\n".join(lines)
    for cell in cells:
        if not isinstance(cell, Mapping):
            continue
        lines.append(f"- `{cell.get('regime_board_cell_id')}`")
        lines.append(f"  - ood_family=`{cell.get('ood_family')}` regime_program=`{cell.get('regime_program')}`")
        lines.append(
            "  - problem=`{}` dynamics=`{}` observation=`{}` distribution=`{}` horizon=`{}` geometry=`{}`".format(
                cell.get("regime_problem_class"),
                cell.get("regime_dynamics_class"),
                cell.get("regime_observation_class"),
                cell.get("regime_distribution_class"),
                cell.get("regime_horizon_class"),
                cell.get("regime_geometry_class"),
            )
        )
        lines.append(
            f"  - row_count=`{cell.get('row_count')}` headline_eligible_count=`{cell.get('headline_eligible_count')}` coverage_only_count=`{cell.get('coverage_only_count')}` blocked_count=`{cell.get('blocked_count')}`"
        )
        lines.append(f"  - baseline_families=`{cell.get('baseline_families')}` blocker_codes=`{cell.get('blocker_codes')}`")
    lines.append("")
    return "\n".join(lines)


def build_ood_slice_leaderboard_rows(payload: Mapping[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for row in _grouped_rows(payload):
        if str(row.get("regime_distribution_class") or "") != "OOD":
            continue
        if not bool(row.get("regime_claim_complete")):
            continue
        rows.append(
            {
                "Task": str(row.get("task_name", "")),
                "Model": str(row.get("model_name", "")),
                "Task Mode": _display_mode(row.get("task_mode")),
                "Protocol": str(row.get("protocol", "")),
                "OOD Family": str(row.get("ood_family", "")),
                "Slice ID": str(row.get("regime_slice_id", "")),
                "Regime Board Cell": str(row.get("regime_board_cell_id", "")),
                "Regime Program": str(row.get("regime_program", "")),
                "Mean Relative L2": _format_float(row.get("eval_relative_l2_mean")),
                "Mean MSE": _format_float(row.get("eval_mse_mean")),
                "Parameter Count": "" if row.get("parameter_count") is None else str(row.get("parameter_count")),
                "Train Duration Seconds": _format_float(row.get("train_duration_seconds_mean")),
            }
        )
    return sorted(
        rows,
        key=lambda row: (
            str(row.get("Task", "")),
            str(row.get("OOD Family", "")),
            str(row.get("Model", "")),
            _coerce_float(row.get("Mean Relative L2")) if _coerce_float(row.get("Mean Relative L2")) is not None else float("inf"),
        ),
    )


def build_ood_slice_leaderboard_markdown_report(
    *,
    grouped_json_path: Path,
    payload: Mapping[str, Any],
    rows: list[dict[str, Any]],
) -> str:
    lines = [
        "# OOD Slice Leaderboard",
        "",
        f"Grouped source: `{grouped_json_path.resolve()}`",
        f"Matrix manifest: `{payload['matrix_manifest']}`",
        "",
    ]
    if not rows:
        lines.extend(["No headline-eligible OOD slice rows were found.", ""])
        return "\n".join(lines)
    lines.extend(
        [
            "| " + " | ".join(OOD_SLICE_COLUMNS) + " |",
            "| " + " | ".join("---" for _ in OOD_SLICE_COLUMNS) + " |",
        ]
    )
    for row in rows:
        lines.append("| " + " | ".join(str(row.get(column, "")) for column in OOD_SLICE_COLUMNS) + " |")
    lines.append("")
    return "\n".join(lines)


def _identifiability_status(row: Mapping[str, Any]) -> str:
    status = row.get("eval_identifiability_failure_code")
    if status in {None, ""}:
        status = row.get("inverse_identifiability_failure_code")
    text = str(status or "").strip()
    return text or "not_reported"


def build_inverse_trust_rows(payload: Mapping[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for row in _inverse_grouped_rows(payload):
        if int(row.get("run_count", 0) or 0) <= 0:
            continue
        rows.append(
            {
                "Task": str(row.get("task_name", "")),
                "Model": str(row.get("model_name", "")),
                "Protocol": _display_protocol(str(row.get("protocol", ""))),
                "Observation Budget": str(row.get("observation_budget_class", "")),
                "Observation Pattern": str(row.get("observation_pattern_family", "")),
                "Inverse Target": str(row.get("inverse_target_family", "")),
                "Inverse Parameter": str(row.get("inverse_parameter_name", "")),
                "Mean Parameter Error": _format_float(row.get("eval_parameter_error_mean")),
                "Mean Parameter Relative Error": _format_float(row.get("eval_parameter_relative_error_mean")),
                "Mean Field Recovery Error": _format_float(row.get("eval_field_recovery_error_mean")),
                "Mean BC Violation": _format_float(row.get("eval_bc_violation_mean")),
                "Mean IC Violation": _format_float(row.get("eval_ic_violation_mean")),
                "Mean Residual Metric": _format_float(row.get("eval_residual_metric_mean")),
                "Mean Calibration Error": _format_float(row.get("eval_calibration_error_mean")),
                "Mean Interval Coverage": _format_float(row.get("eval_interval_coverage_mean")),
                "Identifiability Status": _identifiability_status(row),
            }
        )
    return sorted(
        rows,
        key=lambda row: (
            str(row.get("Task", "")),
            str(row.get("Observation Budget", "")),
            str(row.get("Inverse Target", "")),
            str(row.get("Model", "")),
            _coerce_float(row.get("Mean Parameter Relative Error"))
            if _coerce_float(row.get("Mean Parameter Relative Error")) is not None
            else float("inf"),
        ),
    )


def build_inverse_trust_markdown_report(*, grouped_json_path: Path, payload: Mapping[str, Any], rows: list[dict[str, Any]]) -> str:
    lines = [
        "# Inverse Trust Table",
        "",
        f"Grouped source: `{grouped_json_path.resolve()}`",
        f"Matrix manifest: `{payload['matrix_manifest']}`",
        "",
    ]
    if not rows:
        lines.extend(["No inverse-trust grouped rows were found.", ""])
        return "\n".join(lines)
    lines.extend(
        [
            "| " + " | ".join(INVERSE_TRUST_COLUMNS) + " |",
            "| " + " | ".join("---" for _ in INVERSE_TRUST_COLUMNS) + " |",
        ]
    )
    for row in rows:
        lines.append("| " + " | ".join(str(row.get(column, "")) for column in INVERSE_TRUST_COLUMNS) + " |")
    lines.append("")
    return "\n".join(lines)


def build_inverse_trust_latex_report(*, grouped_json_path: Path, payload: Mapping[str, Any], rows: list[dict[str, Any]]) -> str:
    lines = [
        f"% Inverse-trust table generated from {grouped_json_path.resolve()}",
        f"% Matrix manifest: {payload['matrix_manifest']}",
        "",
    ]
    if not rows:
        lines.append("% No inverse-trust grouped rows were found.")
        return "\n".join(lines).rstrip() + "\n"
    lines.extend(
        [
            r"\begin{tabular}{llllllllllllllll}",
            "Task & Model & Protocol & Observation Budget & Observation Pattern & Inverse Target & Inverse Parameter & Mean Parameter Error & Mean Parameter Relative Error & Mean Field Recovery Error & Mean BC Violation & Mean IC Violation & Mean Residual Metric & Mean Calibration Error & Mean Interval Coverage & Identifiability Status \\",
            r"\hline",
        ]
    )
    for row in rows:
        rendered = [_latex_escape(str(row.get(column, ""))) for column in INVERSE_TRUST_COLUMNS]
        lines.append(" & ".join(rendered) + r" \\")
    lines.extend([r"\end{tabular}", ""])
    return "\n".join(lines).rstrip() + "\n"


def build_identifiability_map_payload(payload: Mapping[str, Any]) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    status_counts: dict[str, int] = defaultdict(int)
    for row in _inverse_grouped_rows(payload):
        status = _identifiability_status(row)
        status_counts[status] += 1
        rows.append(
            {
                "run_id": row.get("run_id"),
                "task_name": row.get("task_name"),
                "model_name": row.get("model_name"),
                "protocol": row.get("protocol"),
                "observation_budget_class": row.get("observation_budget_class"),
                "observation_pattern_family": row.get("observation_pattern_family"),
                "inverse_target_family": row.get("inverse_target_family"),
                "inverse_parameter_name": row.get("inverse_parameter_name"),
                "parameter_relative_error": _coerce_float(row.get("eval_parameter_relative_error_mean")),
                "interval_coverage": _coerce_float(row.get("eval_interval_coverage_mean")),
                "calibration_error": _coerce_float(row.get("eval_calibration_error_mean")),
                "identifiability_status": status,
            }
        )
    rows.sort(
        key=lambda row: (
            str(row.get("task_name") or ""),
            str(row.get("observation_budget_class") or ""),
            str(row.get("inverse_target_family") or ""),
            str(row.get("model_name") or ""),
        )
    )
    return {
        "summary": {
            "row_count": len(rows),
            "status_counts": dict(sorted(status_counts.items())),
        },
        "rows": rows,
    }


def build_identifiability_map_markdown_report(
    *,
    grouped_json_path: Path,
    payload: Mapping[str, Any],
    identifiability_map: Mapping[str, Any],
) -> str:
    lines = [
        "# Identifiability Map",
        "",
        f"Grouped source: `{grouped_json_path.resolve()}`",
        f"Matrix manifest: `{payload['matrix_manifest']}`",
        "",
        "## Summary",
        "",
    ]
    for key, value in dict(identifiability_map.get("summary", {})).items():
        lines.append(f"- {key}: `{value}`")
    rows = identifiability_map.get("rows", [])
    lines.extend(["", "## Rows", ""])
    if not isinstance(rows, list) or not rows:
        lines.extend(["No inverse identifiability rows were exported.", ""])
        return "\n".join(lines)
    for row in rows:
        if not isinstance(row, Mapping):
            continue
        lines.append(
            "- `{}` task=`{}` model=`{}` budget=`{}` pattern=`{}` target=`{}` parameter_relative_error=`{}` interval_coverage=`{}` calibration_error=`{}` identifiability_status=`{}`".format(
                row.get("run_id"),
                row.get("task_name"),
                row.get("model_name"),
                row.get("observation_budget_class"),
                row.get("observation_pattern_family"),
                row.get("inverse_target_family"),
                row.get("parameter_relative_error"),
                row.get("interval_coverage"),
                row.get("calibration_error"),
                row.get("identifiability_status"),
            )
        )
    lines.append("")
    return "\n".join(lines)


def build_calibration_report_payload(payload: Mapping[str, Any]) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    calibration_values: list[float] = []
    coverage_values: list[float] = []
    for row in _inverse_grouped_rows(payload):
        calibration_error = _coerce_float(row.get("eval_calibration_error_mean"))
        interval_coverage = _coerce_float(row.get("eval_interval_coverage_mean"))
        if calibration_error is not None:
            calibration_values.append(calibration_error)
        if interval_coverage is not None:
            coverage_values.append(interval_coverage)
        rows.append(
            {
                "run_id": row.get("run_id"),
                "task_name": row.get("task_name"),
                "model_name": row.get("model_name"),
                "protocol": row.get("protocol"),
                "observation_budget_class": row.get("observation_budget_class"),
                "observation_pattern_family": row.get("observation_pattern_family"),
                "calibration_error": calibration_error,
                "interval_coverage": interval_coverage,
            }
        )
    rows.sort(
        key=lambda row: (
            str(row.get("task_name") or ""),
            str(row.get("observation_budget_class") or ""),
            str(row.get("model_name") or ""),
        )
    )
    mean_calibration = None if not calibration_values else sum(calibration_values) / len(calibration_values)
    mean_coverage = None if not coverage_values else sum(coverage_values) / len(coverage_values)
    return {
        "summary": {
            "row_count": len(rows),
            "rows_with_calibration_error": len(calibration_values),
            "rows_with_interval_coverage": len(coverage_values),
            "mean_calibration_error": mean_calibration,
            "mean_interval_coverage": mean_coverage,
        },
        "rows": rows,
    }


def build_calibration_report_markdown_report(
    *,
    grouped_json_path: Path,
    payload: Mapping[str, Any],
    calibration_report: Mapping[str, Any],
) -> str:
    lines = [
        "# Calibration Report",
        "",
        f"Grouped source: `{grouped_json_path.resolve()}`",
        f"Matrix manifest: `{payload['matrix_manifest']}`",
        "",
        "## Summary",
        "",
    ]
    for key, value in dict(calibration_report.get("summary", {})).items():
        lines.append(f"- {key}: `{value}`")
    rows = calibration_report.get("rows", [])
    lines.extend(["", "## Rows", ""])
    if not isinstance(rows, list) or not rows:
        lines.extend(["No inverse calibration rows were exported.", ""])
        return "\n".join(lines)
    for row in rows:
        if not isinstance(row, Mapping):
            continue
        lines.append(
            "- `{}` task=`{}` model=`{}` budget=`{}` pattern=`{}` calibration_error=`{}` interval_coverage=`{}`".format(
                row.get("run_id"),
                row.get("task_name"),
                row.get("model_name"),
                row.get("observation_budget_class"),
                row.get("observation_pattern_family"),
                row.get("calibration_error"),
                row.get("interval_coverage"),
            )
        )
    lines.append("")
    return "\n".join(lines)


def build_sparse_observation_leaderboard_rows(payload: Mapping[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for row in _inverse_grouped_rows(payload):
        budget_class = str(row.get("observation_budget_class") or "")
        if budget_class not in {"sparse", "very_sparse"}:
            continue
        rows.append(
            {
                "Task": str(row.get("task_name", "")),
                "Model": str(row.get("model_name", "")),
                "Protocol": _display_protocol(str(row.get("protocol", ""))),
                "Observation Budget": budget_class,
                "Observation Pattern": str(row.get("observation_pattern_family", "")),
                "Inverse Target": str(row.get("inverse_target_family", "")),
                "Mean Parameter Relative Error": _format_float(row.get("eval_parameter_relative_error_mean")),
                "Mean Field Recovery Error": _format_float(row.get("eval_field_recovery_error_mean")),
                "Mean Calibration Error": _format_float(row.get("eval_calibration_error_mean")),
                "Mean Interval Coverage": _format_float(row.get("eval_interval_coverage_mean")),
            }
        )
    return sorted(
        rows,
        key=lambda row: (
            str(row.get("Task", "")),
            str(row.get("Observation Budget", "")),
            str(row.get("Inverse Target", "")),
            _coerce_float(row.get("Mean Parameter Relative Error"))
            if _coerce_float(row.get("Mean Parameter Relative Error")) is not None
            else float("inf"),
        ),
    )


def build_sparse_observation_markdown_report(
    *,
    grouped_json_path: Path,
    payload: Mapping[str, Any],
    rows: list[dict[str, Any]],
) -> str:
    lines = [
        "# Sparse-Observation Leaderboard",
        "",
        f"Grouped source: `{grouped_json_path.resolve()}`",
        f"Matrix manifest: `{payload['matrix_manifest']}`",
        "",
    ]
    if not rows:
        lines.extend(["No sparse-observation inverse rows were found.", ""])
        return "\n".join(lines)
    lines.extend(
        [
            "| " + " | ".join(SPARSE_OBSERVATION_COLUMNS) + " |",
            "| " + " | ".join("---" for _ in SPARSE_OBSERVATION_COLUMNS) + " |",
        ]
    )
    for row in rows:
        lines.append("| " + " | ".join(str(row.get(column, "")) for column in SPARSE_OBSERVATION_COLUMNS) + " |")
    lines.append("")
    return "\n".join(lines)


def _missing_physics_metrics(row: Mapping[str, Any]) -> bool:
    return all(
        _coerce_float(row.get(field)) is None
        for field in ("eval_residual_metric_mean", "eval_bc_violation_mean", "eval_ic_violation_mean")
    )


def build_failure_atlas_payload(payload: Mapping[str, Any]) -> dict[str, Any]:
    grouped: dict[tuple[str, str, str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in _grouped_rows(payload):
        if str(row.get("regime_distribution_class") or "") != "OOD":
            continue
        key = (
            str(row.get("baseline_family") or "unspecified"),
            str(row.get("ood_family") or ""),
            str(row.get("regime_dynamics_class") or ""),
            str(row.get("regime_geometry_class") or "regular_geometry"),
        )
        grouped[key].append(row)

    groups: list[dict[str, Any]] = []
    coverage_gap_group_count = 0
    for (baseline_family, ood_family, dynamics_class, geometry_class), rows in sorted(grouped.items()):
        representative = max(
            rows,
            key=lambda row: (
                _coerce_float(row.get("eval_relative_l2_mean")) if _coerce_float(row.get("eval_relative_l2_mean")) is not None else float("-inf"),
                _coerce_float(row.get("degradation_ratio_vs_standard"))
                if _coerce_float(row.get("degradation_ratio_vs_standard")) is not None
                else float("-inf"),
                str(row.get("run_id") or ""),
            ),
        )
        coverage_gaps: list[str] = []
        if baseline_family == "unspecified":
            coverage_gaps.append("missing_baseline_family")
        if any(_coerce_float(row.get("degradation_ratio_vs_standard")) is None for row in rows):
            coverage_gaps.append("missing_clean_reference_degradation_context")
        if any(str(row.get("regime_program") or "") == "coverage_only" for row in rows):
            coverage_gaps.append("coverage_only_program")
        if any(_missing_physics_metrics(row) for row in rows):
            coverage_gaps.append("missing_physics_metrics")
        if coverage_gaps:
            coverage_gap_group_count += 1
        groups.append(
            {
                "baseline_family": baseline_family,
                "ood_family": ood_family,
                "regime_dynamics_class": dynamics_class,
                "regime_geometry_class": geometry_class,
                "case_count": len(rows),
                "representative_worst_row_id": representative.get("run_id"),
                "representative_task_name": representative.get("task_name"),
                "representative_model_name": representative.get("model_name"),
                "worst_mean_relative_l2": _coerce_float(representative.get("eval_relative_l2_mean")),
                "worst_degradation_ratio": _coerce_float(representative.get("degradation_ratio_vs_standard")),
                "coverage_gaps": coverage_gaps,
            }
        )
    return {
        "summary": {
            "group_count": len(groups),
            "ood_case_count": sum(group["case_count"] for group in groups),
            "coverage_gap_group_count": coverage_gap_group_count,
        },
        "groups": groups,
    }


def build_failure_atlas_markdown_report(
    *,
    grouped_json_path: Path,
    payload: Mapping[str, Any],
    atlas: Mapping[str, Any],
) -> str:
    lines = [
        "# Failure Atlas",
        "",
        f"Grouped source: `{grouped_json_path.resolve()}`",
        f"Matrix manifest: `{payload['matrix_manifest']}`",
        "",
        "## Summary",
        "",
    ]
    for key, value in dict(atlas.get("summary", {})).items():
        lines.append(f"- {key}: `{value}`")
    lines.extend(["", "## Groups", ""])
    groups = atlas.get("groups", [])
    if not isinstance(groups, list) or not groups:
        lines.extend(["No OOD failure-atlas groups were exported.", ""])
        return "\n".join(lines)
    for group in groups:
        if not isinstance(group, Mapping):
            continue
        lines.append(
            "- baseline_family=`{}` ood_family=`{}` regime_dynamics_class=`{}` regime_geometry_class=`{}` case_count=`{}`".format(
                group.get("baseline_family"),
                group.get("ood_family"),
                group.get("regime_dynamics_class"),
                group.get("regime_geometry_class"),
                group.get("case_count"),
            )
        )
        lines.append(
            "  - representative=`{}` task=`{}` model=`{}` worst_mean_relative_l2=`{}` worst_degradation_ratio=`{}`".format(
                group.get("representative_worst_row_id"),
                group.get("representative_task_name"),
                group.get("representative_model_name"),
                group.get("worst_mean_relative_l2"),
                group.get("worst_degradation_ratio"),
            )
        )
        lines.append(f"  - coverage_gaps=`{group.get('coverage_gaps')}`")
    lines.append("")
    return "\n".join(lines)


def _is_regime_candidate_row(row: Mapping[str, Any]) -> bool:
    return any(
        row.get(field) not in {None, ""}
        for field in (
            "regime_protocol_family",
            "regime_slice_id",
            "ood_family",
            "regime_board_cell_id",
            "regime_program",
        )
    ) or str(row.get("protocol") or "") in REGIME_OOD_PROTOCOLS


def build_physics_consistency_dashboard_payload(payload: Mapping[str, Any]) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    pointwise_rows_with_metrics_count = 0
    pointwise_rows_missing_expected_metrics_count = 0
    operator_rows_not_available_count = 0
    for row in _grouped_rows(payload):
        if not _is_regime_candidate_row(row):
            continue
        task_mode = _display_mode(row.get("task_mode"))
        residual_metric = _coerce_float(row.get("eval_residual_metric_mean"))
        bc_violation = _coerce_float(row.get("eval_bc_violation_mean"))
        ic_violation = _coerce_float(row.get("eval_ic_violation_mean"))
        if task_mode == "field":
            metric_status = "available" if any(value is not None for value in (residual_metric, bc_violation, ic_violation)) else "not_available_in_R2A"
            if metric_status == "not_available_in_R2A":
                operator_rows_not_available_count += 1
        else:
            metric_status = "available" if any(value is not None for value in (residual_metric, bc_violation, ic_violation)) else "missing_expected_metrics"
            if metric_status == "available":
                pointwise_rows_with_metrics_count += 1
            else:
                pointwise_rows_missing_expected_metrics_count += 1
        rows.append(
            {
                "run_id": row.get("run_id"),
                "task_name": row.get("task_name"),
                "model_name": row.get("model_name"),
                "task_mode": task_mode,
                "ood_family": row.get("ood_family"),
                "regime_program": row.get("regime_program"),
                "metric_status": metric_status,
                "residual_metric": residual_metric,
                "bc_violation": bc_violation,
                "ic_violation": ic_violation,
            }
        )
    rows.sort(
        key=lambda row: (
            str(row.get("task_name") or ""),
            str(row.get("ood_family") or ""),
            str(row.get("model_name") or ""),
            str(row.get("run_id") or ""),
        )
    )
    return {
        "summary": {
            "row_count": len(rows),
            "pointwise_rows_with_physics_metrics_count": pointwise_rows_with_metrics_count,
            "pointwise_rows_missing_expected_metrics_count": pointwise_rows_missing_expected_metrics_count,
            "operator_rows_not_available_count": operator_rows_not_available_count,
        },
        "rows": rows,
    }


def build_physics_consistency_dashboard_markdown_report(
    *,
    grouped_json_path: Path,
    payload: Mapping[str, Any],
    dashboard: Mapping[str, Any],
) -> str:
    lines = [
        "# Physics Consistency Dashboard",
        "",
        f"Grouped source: `{grouped_json_path.resolve()}`",
        f"Matrix manifest: `{payload['matrix_manifest']}`",
        "",
        "## Summary",
        "",
    ]
    for key, value in dict(dashboard.get("summary", {})).items():
        lines.append(f"- {key}: `{value}`")
    lines.extend(["", "## Rows", ""])
    rows = dashboard.get("rows", [])
    if not isinstance(rows, list) or not rows:
        lines.extend(["No regime candidate rows were exported.", ""])
        return "\n".join(lines)
    for row in rows:
        if not isinstance(row, Mapping):
            continue
        lines.append(
            "- `{}` task=`{}` model=`{}` mode=`{}` ood_family=`{}` regime_program=`{}` metric_status=`{}` residual_metric=`{}` bc_violation=`{}` ic_violation=`{}`".format(
                row.get("run_id"),
                row.get("task_name"),
                row.get("model_name"),
                row.get("task_mode"),
                row.get("ood_family"),
                row.get("regime_program"),
                row.get("metric_status"),
                row.get("residual_metric"),
                row.get("bc_violation"),
                row.get("ic_violation"),
            )
        )
    lines.append("")
    return "\n".join(lines)


def build_matched_budget_rows(payload: Mapping[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for group in _fair_budget_groups(payload):
        if not bool(group.get("headline_claim_eligible")):
            continue
        for entry in group.get("rows", []):
            if not isinstance(entry, Mapping) or not bool(entry.get("headline_claim_eligible")):
                continue
            rows.append(
                {
                    "Task": str(group.get("task_name", "")),
                    "Baseline Family": str(entry.get("baseline_family", "")),
                    "Model / Reference": str(entry.get("model_name", "")),
                    "Data Budget": str(group.get("data_budget_class", "")),
                    "Compute Budget": str(group.get("compute_budget_class", "")),
                    "Tuning Budget": str(group.get("tuning_budget_class", "")),
                    "Comparison Scope": str(group.get("comparison_scope", "")),
                    "Metric": str(entry.get("metric_name", "")),
                    "Metric Value": _format_float(entry.get("metric_value")),
                    "Parameter Count": "" if entry.get("parameter_count") is None else str(entry.get("parameter_count")),
                    "Train Duration Seconds": _format_float(entry.get("train_duration_seconds")),
                }
            )
    return sorted(
        rows,
        key=lambda row: (
            str(row.get("Task", "")),
            str(row.get("Baseline Family", "")),
            str(row.get("Model / Reference", "")),
            str(row.get("Metric Value", "")),
        ),
    )


def build_fairness_coverage_payload(payload: Mapping[str, Any]) -> dict[str, Any]:
    summary = payload.get("fair_budget_summary")
    normalized_summary = dict(summary) if isinstance(summary, Mapping) else {}
    groups: list[dict[str, Any]] = []
    for group in _fair_budget_groups(payload):
        groups.append(
            {
                "matched_budget_group_id": group.get("matched_budget_group_id"),
                "task_name": group.get("task_name"),
                "protocol": group.get("protocol"),
                "headline_program": bool(group.get("headline_program")),
                "headline_claim_eligible": bool(group.get("headline_claim_eligible")),
                "headline_blocker_codes": list(group.get("headline_blocker_codes", [])),
                "baseline_families_present": list(group.get("baseline_families_present", [])),
                "row_ids": [
                    str(entry.get("row_id"))
                    for entry in group.get("rows", [])
                    if isinstance(entry, Mapping) and entry.get("row_id") is not None
                ],
            }
        )
    return {
        "summary": normalized_summary,
        "groups": groups,
    }



def _markdown_table(rows: list[dict[str, Any]]) -> list[str]:
    lines = [
        "| " + " | ".join(REPORTING_COLUMNS) + " |",
        "| " + " | ".join("---" for _ in REPORTING_COLUMNS) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(str(row.get(column, "")) for column in REPORTING_COLUMNS) + " |")
    return lines



def build_markdown_report(
    *,
    grouped_json_path: Path,
    payload: Mapping[str, Any],
    rows: list[dict[str, Any]],
    omitted_families: list[str],
) -> str:
    matrix_manifest = str(payload["matrix_manifest"])
    warnings = [str(item) for item in payload.get("warnings", [])]
    groups = build_reporting_groups(rows)

    lines = [
        "# Baseline Reporting Tables",
        "",
        f"Grouped source: `{grouped_json_path.resolve()}`",
        f"Matrix manifest: `{matrix_manifest}`",
        "",
    ]
    if omitted_families:
        lines.extend([
            "## Omitted Incomplete Families",
            "",
            *[f"- {family}" for family in omitted_families],
            "",
        ])
    if warnings:
        lines.extend([
            "## Upstream Grouped Warnings",
            "",
            *[f"- {warning}" for warning in warnings],
            "",
        ])

    for task_name, task_rows in groups.items():
        lines.extend([f"## {task_name}", ""])
        lines.extend(_markdown_table(task_rows))
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def build_matched_budget_markdown_report(*, grouped_json_path: Path, payload: Mapping[str, Any], rows: list[dict[str, Any]]) -> str:
    lines = [
        "# Matched-Budget Leaderboard",
        "",
        f"Grouped source: `{grouped_json_path.resolve()}`",
        f"Matrix manifest: `{payload['matrix_manifest']}`",
        "",
    ]
    if not rows:
        lines.extend(["No headline-eligible matched-budget rows were found.", ""])
        return "\n".join(lines)
    lines.extend(
        [
            "| " + " | ".join(MATCHED_BUDGET_COLUMNS) + " |",
            "| " + " | ".join("---" for _ in MATCHED_BUDGET_COLUMNS) + " |",
        ]
    )
    for row in rows:
        lines.append("| " + " | ".join(str(row.get(column, "")) for column in MATCHED_BUDGET_COLUMNS) + " |")
    lines.append("")
    return "\n".join(lines)


def build_matched_budget_latex_report(*, grouped_json_path: Path, payload: Mapping[str, Any], rows: list[dict[str, Any]]) -> str:
    lines = [
        f"% Matched-budget leaderboard generated from {grouped_json_path.resolve()}",
        f"% Matrix manifest: {payload['matrix_manifest']}",
        "",
    ]
    if not rows:
        lines.append("% No headline-eligible matched-budget rows were found.")
        return "\n".join(lines).rstrip() + "\n"
    lines.extend(
        [
            r"\begin{tabular}{lllllllllll}",
            "Task & Baseline Family & Model / Reference & Data Budget & Compute Budget & Tuning Budget & Comparison Scope & Metric & Metric Value & Parameter Count & Train Duration Seconds \\",
            r"\hline",
        ]
    )
    for row in rows:
        rendered = [_latex_escape(str(row.get(column, ""))) for column in MATCHED_BUDGET_COLUMNS]
        lines.append(" & ".join(rendered) + r" \\")
    lines.extend([r"\end{tabular}", ""])
    return "\n".join(lines).rstrip() + "\n"


def build_fairness_coverage_markdown_report(*, grouped_json_path: Path, payload: Mapping[str, Any], coverage: Mapping[str, Any]) -> str:
    summary = coverage.get("summary", {})
    lines = [
        "# Fairness Coverage Report",
        "",
        f"Grouped source: `{grouped_json_path.resolve()}`",
        f"Matrix manifest: `{payload['matrix_manifest']}`",
        "",
        "## Summary",
        "",
    ]
    for key, value in summary.items():
        lines.append(f"- {key}: `{value}`")
    lines.extend(["", "## Groups", ""])
    for group in coverage.get("groups", []):
        lines.append(f"- `{group.get('matched_budget_group_id')}`")
        lines.append(f"  - task=`{group.get('task_name')}` protocol=`{group.get('protocol')}`")
        lines.append(f"  - headline_program=`{group.get('headline_program')}` headline_claim_eligible=`{group.get('headline_claim_eligible')}`")
        lines.append(f"  - baseline_families_present=`{group.get('baseline_families_present')}`")
        lines.append(f"  - headline_blocker_codes=`{group.get('headline_blocker_codes')}`")
        lines.append(f"  - row_ids=`{group.get('row_ids')}`")
    lines.append("")
    return "\n".join(lines)



def _latex_escape(value: str) -> str:
    replacements = {
        "\\": r"\textbackslash{}",
        "_": r"\_",
        "%": r"\%",
        "&": r"\&",
        "#": r"\#",
        "$": r"\$",
        "{": r"\{",
        "}": r"\}",
    }
    result = value
    for source, target in replacements.items():
        result = result.replace(source, target)
    return result



def build_latex_report(
    *,
    grouped_json_path: Path,
    payload: Mapping[str, Any],
    rows: list[dict[str, Any]],
    omitted_families: list[str],
) -> str:
    groups = build_reporting_groups(rows)
    warnings = [str(item) for item in payload.get("warnings", [])]
    lines = [
        f"% Baseline reporting tables generated from {grouped_json_path.resolve()}",
        f"% Matrix manifest: {payload['matrix_manifest']}",
    ]
    if omitted_families:
        lines.append("% Omitted incomplete families: " + ", ".join(omitted_families))
    if warnings:
        lines.append("% Upstream grouped warnings:")
        lines.extend(f"% {warning}" for warning in warnings)
    lines.append("")

    column_spec = "lllllllrrrrrrrr"
    for task_name, task_rows in groups.items():
        lines.extend(
            [
                f"% Task: {task_name}",
                r"\begin{tabular}{" + column_spec + "}",
                "Task & Task Mode & Model & Model Mode & Evaluation Mode & Protocol & Setting & Degradation vs Standard & Noise Degradation & Sparsity Degradation & Extrapolation Degradation & Mean Relative L2 & Std Relative L2 & Mean MSE & Std MSE & Count \\",
                r"\hline",
            ]
        )
        for row in task_rows:
            rendered = [_latex_escape(str(row.get(column, ""))) for column in REPORTING_COLUMNS]
            lines.append(" & ".join(rendered) + r" \\")
        lines.extend([r"\end{tabular}", ""])
    return "\n".join(lines).rstrip() + "\n"



def export_reporting_tables(grouped_json_path: Path, output_dir: Path | None = None) -> dict[str, Any]:
    payload = load_grouped_payload(grouped_json_path)
    matrix_name = derive_matrix_name(payload)
    report_dir = grouped_json_path.parent / "reporting" if output_dir is None else output_dir
    report_dir.mkdir(parents=True, exist_ok=True)

    rows, omitted_families = build_reporting_rows(payload)
    csv_path = report_dir / f"{matrix_name}_baseline_table.csv"
    markdown_path = report_dir / f"{matrix_name}_baseline_table.md"
    latex_path = report_dir / f"{matrix_name}_baseline_table.tex"
    matched_budget_rows = build_matched_budget_rows(payload)
    matched_budget_csv_path = report_dir / f"{matrix_name}_matched_budget_table.csv"
    matched_budget_markdown_path = report_dir / f"{matrix_name}_matched_budget_table.md"
    matched_budget_latex_path = report_dir / f"{matrix_name}_matched_budget_table.tex"
    fairness_coverage = build_fairness_coverage_payload(payload)
    fairness_coverage_json_path = report_dir / f"{matrix_name}_fairness_coverage.json"
    fairness_coverage_markdown_path = report_dir / f"{matrix_name}_fairness_coverage.md"
    regime_map = build_regime_map_payload(payload)
    regime_map_json_path = report_dir / f"{matrix_name}_regime_map.json"
    regime_map_markdown_path = report_dir / f"{matrix_name}_regime_map.md"
    ood_slice_rows = build_ood_slice_leaderboard_rows(payload)
    ood_slice_csv_path = report_dir / f"{matrix_name}_ood_slice_leaderboard.csv"
    ood_slice_markdown_path = report_dir / f"{matrix_name}_ood_slice_leaderboard.md"
    failure_atlas = build_failure_atlas_payload(payload)
    failure_atlas_json_path = report_dir / f"{matrix_name}_failure_atlas.json"
    failure_atlas_markdown_path = report_dir / f"{matrix_name}_failure_atlas.md"
    physics_consistency_dashboard = build_physics_consistency_dashboard_payload(payload)
    physics_consistency_json_path = report_dir / f"{matrix_name}_physics_consistency_dashboard.json"
    physics_consistency_markdown_path = report_dir / f"{matrix_name}_physics_consistency_dashboard.md"
    inverse_trust_rows = build_inverse_trust_rows(payload)
    inverse_trust_csv_path = report_dir / f"{matrix_name}_inverse_trust_table.csv"
    inverse_trust_markdown_path = report_dir / f"{matrix_name}_inverse_trust_table.md"
    inverse_trust_latex_path = report_dir / f"{matrix_name}_inverse_trust_table.tex"
    identifiability_map = build_identifiability_map_payload(payload)
    identifiability_map_json_path = report_dir / f"{matrix_name}_identifiability_map.json"
    identifiability_map_markdown_path = report_dir / f"{matrix_name}_identifiability_map.md"
    calibration_report = build_calibration_report_payload(payload)
    calibration_report_json_path = report_dir / f"{matrix_name}_calibration_report.json"
    calibration_report_markdown_path = report_dir / f"{matrix_name}_calibration_report.md"
    sparse_observation_rows = build_sparse_observation_leaderboard_rows(payload)
    sparse_observation_csv_path = report_dir / f"{matrix_name}_sparse_observation_leaderboard.csv"
    sparse_observation_markdown_path = report_dir / f"{matrix_name}_sparse_observation_leaderboard.md"

    write_csv(path=csv_path, rows=rows, fieldnames=REPORTING_COLUMNS)
    write_csv(path=matched_budget_csv_path, rows=matched_budget_rows, fieldnames=MATCHED_BUDGET_COLUMNS)
    write_csv(path=ood_slice_csv_path, rows=ood_slice_rows, fieldnames=OOD_SLICE_COLUMNS)
    markdown_path.write_text(
        build_markdown_report(
            grouped_json_path=grouped_json_path,
            payload=payload,
            rows=rows,
            omitted_families=omitted_families,
        ),
        encoding="utf-8",
    )
    matched_budget_markdown_path.write_text(
        build_matched_budget_markdown_report(
            grouped_json_path=grouped_json_path,
            payload=payload,
            rows=matched_budget_rows,
        ),
        encoding="utf-8",
    )
    latex_path.write_text(
        build_latex_report(
            grouped_json_path=grouped_json_path,
            payload=payload,
            rows=rows,
            omitted_families=omitted_families,
        ),
        encoding="utf-8",
    )
    matched_budget_latex_path.write_text(
        build_matched_budget_latex_report(
            grouped_json_path=grouped_json_path,
            payload=payload,
            rows=matched_budget_rows,
        ),
        encoding="utf-8",
    )
    fairness_coverage_json_path.write_text(json.dumps(fairness_coverage, indent=2), encoding="utf-8")
    fairness_coverage_markdown_path.write_text(
        build_fairness_coverage_markdown_report(
            grouped_json_path=grouped_json_path,
            payload=payload,
            coverage=fairness_coverage,
        ),
        encoding="utf-8",
    )
    regime_map_json_path.write_text(json.dumps(regime_map, indent=2), encoding="utf-8")
    regime_map_markdown_path.write_text(
        build_regime_map_markdown_report(
            grouped_json_path=grouped_json_path,
            payload=payload,
            regime_map=regime_map,
        ),
        encoding="utf-8",
    )
    ood_slice_markdown_path.write_text(
        build_ood_slice_leaderboard_markdown_report(
            grouped_json_path=grouped_json_path,
            payload=payload,
            rows=ood_slice_rows,
        ),
        encoding="utf-8",
    )
    failure_atlas_json_path.write_text(json.dumps(failure_atlas, indent=2), encoding="utf-8")
    failure_atlas_markdown_path.write_text(
        build_failure_atlas_markdown_report(
            grouped_json_path=grouped_json_path,
            payload=payload,
            atlas=failure_atlas,
        ),
        encoding="utf-8",
    )
    physics_consistency_json_path.write_text(json.dumps(physics_consistency_dashboard, indent=2), encoding="utf-8")
    physics_consistency_markdown_path.write_text(
        build_physics_consistency_dashboard_markdown_report(
            grouped_json_path=grouped_json_path,
            payload=payload,
            dashboard=physics_consistency_dashboard,
        ),
        encoding="utf-8",
    )
    if inverse_trust_rows:
        write_csv(path=inverse_trust_csv_path, rows=inverse_trust_rows, fieldnames=INVERSE_TRUST_COLUMNS)
        inverse_trust_markdown_path.write_text(
            build_inverse_trust_markdown_report(
                grouped_json_path=grouped_json_path,
                payload=payload,
                rows=inverse_trust_rows,
            ),
            encoding="utf-8",
        )
        inverse_trust_latex_path.write_text(
            build_inverse_trust_latex_report(
                grouped_json_path=grouped_json_path,
                payload=payload,
                rows=inverse_trust_rows,
            ),
            encoding="utf-8",
        )
        identifiability_map_json_path.write_text(json.dumps(identifiability_map, indent=2), encoding="utf-8")
        identifiability_map_markdown_path.write_text(
            build_identifiability_map_markdown_report(
                grouped_json_path=grouped_json_path,
                payload=payload,
                identifiability_map=identifiability_map,
            ),
            encoding="utf-8",
        )
        calibration_report_json_path.write_text(json.dumps(calibration_report, indent=2), encoding="utf-8")
        calibration_report_markdown_path.write_text(
            build_calibration_report_markdown_report(
                grouped_json_path=grouped_json_path,
                payload=payload,
                calibration_report=calibration_report,
            ),
            encoding="utf-8",
        )
        write_csv(path=sparse_observation_csv_path, rows=sparse_observation_rows, fieldnames=SPARSE_OBSERVATION_COLUMNS)
        sparse_observation_markdown_path.write_text(
            build_sparse_observation_markdown_report(
                grouped_json_path=grouped_json_path,
                payload=payload,
                rows=sparse_observation_rows,
            ),
            encoding="utf-8",
        )
    return {
        "matrix_name": matrix_name,
        "grouped_json": str(grouped_json_path.resolve()),
        "output_dir": str(report_dir.resolve()),
        "row_count": len(rows),
        "matched_budget_row_count": len(matched_budget_rows),
        "omitted_incomplete_families": omitted_families,
        "csv_path": str(csv_path.resolve()),
        "markdown_path": str(markdown_path.resolve()),
        "latex_path": str(latex_path.resolve()),
        "matched_budget_csv_path": str(matched_budget_csv_path.resolve()),
        "matched_budget_markdown_path": str(matched_budget_markdown_path.resolve()),
        "matched_budget_latex_path": str(matched_budget_latex_path.resolve()),
        "fairness_coverage_json_path": str(fairness_coverage_json_path.resolve()),
        "fairness_coverage_markdown_path": str(fairness_coverage_markdown_path.resolve()),
        "regime_map_json_path": str(regime_map_json_path.resolve()),
        "regime_map_markdown_path": str(regime_map_markdown_path.resolve()),
        "ood_slice_csv_path": str(ood_slice_csv_path.resolve()),
        "ood_slice_markdown_path": str(ood_slice_markdown_path.resolve()),
        "failure_atlas_json_path": str(failure_atlas_json_path.resolve()),
        "failure_atlas_markdown_path": str(failure_atlas_markdown_path.resolve()),
        "physics_consistency_json_path": str(physics_consistency_json_path.resolve()),
        "physics_consistency_markdown_path": str(physics_consistency_markdown_path.resolve()),
        "inverse_trust_row_count": len(inverse_trust_rows),
        "inverse_trust_csv_path": None if not inverse_trust_rows else str(inverse_trust_csv_path.resolve()),
        "inverse_trust_markdown_path": None if not inverse_trust_rows else str(inverse_trust_markdown_path.resolve()),
        "inverse_trust_latex_path": None if not inverse_trust_rows else str(inverse_trust_latex_path.resolve()),
        "identifiability_map_json_path": None if not inverse_trust_rows else str(identifiability_map_json_path.resolve()),
        "identifiability_map_markdown_path": None if not inverse_trust_rows else str(identifiability_map_markdown_path.resolve()),
        "calibration_report_json_path": None if not inverse_trust_rows else str(calibration_report_json_path.resolve()),
        "calibration_report_markdown_path": None if not inverse_trust_rows else str(calibration_report_markdown_path.resolve()),
        "sparse_observation_csv_path": None if not inverse_trust_rows else str(sparse_observation_csv_path.resolve()),
        "sparse_observation_markdown_path": None if not inverse_trust_rows else str(sparse_observation_markdown_path.resolve()),
    }



def main(argv: Sequence[str] | None = None) -> None:
    args = parse_args(argv)
    grouped_json_path = Path(args.grouped_json)
    output_dir = None if args.output_dir is None else Path(args.output_dir)
    result = export_reporting_tables(grouped_json_path=grouped_json_path, output_dir=output_dir)
    print(f"Reporting tables written to {result['output_dir']}")
    print(f"Exported {result['row_count']} reporting rows for {result['matrix_name']}")


if __name__ == "__main__":
    main()
