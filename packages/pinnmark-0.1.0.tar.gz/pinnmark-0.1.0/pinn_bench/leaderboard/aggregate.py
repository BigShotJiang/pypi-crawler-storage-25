"""Aggregation helpers for leaderboard exports."""

from __future__ import annotations

import json
from collections import defaultdict
from collections.abc import Mapping
from pathlib import Path
from statistics import fmean, stdev
from typing import Any

import yaml

from pinn_bench.comparison import (
    COMPARISON_FIELDS,
    HEADLINE_PINN_MODELS,
    HEADLINE_REQUIRED_BASELINE_FAMILIES,
    comparison_contract_complete,
    comparison_dict_from_mapping,
    comparison_dict_from_record,
    is_headline_task,
)
from pinn_bench.config.loader import load_config
from pinn_bench.regime import (
    GEOMETRY_RAW_FIELDS,
    REGIME_DERIVED_FIELDS,
    REGIME_RAW_FIELDS,
    build_regime_payload,
    geometry_dict_from_record,
    normalize_regime_metadata_mapping,
    normalize_geometry_metadata_mapping,
    regime_dict_from_record,
    regime_raw_fields_from_config,
)
from pinn_bench.resources import resolve_config_path
from pinn_bench.robustness import resolve_target_scopes
from pinn_bench.stress import apply_stress_metadata

SCHEMA_VERSION = "leaderboard.v0.1"
GROUPED_SCHEMA_VERSION = "leaderboard.grouped.v0.1"
MATRIX_SCHEMA_VERSION = "baseline_matrix.v0.1"
INVERSE_RAW_FIELDS = [
    "observation_budget_class",
    "observation_pattern_family",
    "inverse_target_family",
    "inverse_parameter_name",
    "true_parameter_value",
    "estimated_parameter_value",
    "supervision_source",
]
STABLE_ARTIFACT_NAMES = {
    "config_snapshot.yaml",
    "loss_curve.png",
    "metrics.json",
    "model.pt",
    "train_log.csv",
}
FIXED_COLUMNS = [
    "output_dir",
    "task_name",
    "task_mode",
    "model_name",
    "model_mode",
    "evaluation_mode",
    *COMPARISON_FIELDS,
    "seed",
    "device",
    "protocol",
    "protocol_setting",
    *INVERSE_RAW_FIELDS,
    *REGIME_RAW_FIELDS,
    *GEOMETRY_RAW_FIELDS,
    "robustness_level",
    "severity_label",
    "target_scopes",
    "train_time_range_start",
    "train_time_range_end",
    "eval_time_range_start",
    "eval_time_range_end",
    "train_support_ratio",
    "support_axis",
    "train_final_loss",
    "train_best_loss",
    "train_epochs",
    "parameter_count",
    "task_parameter_count",
    "total_trainable_parameter_count",
    "train_duration_seconds",
]
GROUPED_COLUMNS = [
    "run_id",
    "task_name",
    "task_mode",
    "model_name",
    "model_mode",
    "evaluation_mode",
    *COMPARISON_FIELDS,
    *INVERSE_RAW_FIELDS,
    *REGIME_RAW_FIELDS,
    *GEOMETRY_RAW_FIELDS,
    "protocol",
    "protocol_setting",
    "expected_seeds",
    "found_seeds",
    "missing_seeds",
    "run_count",
    "parameter_count",
    "task_parameter_count",
    "total_trainable_parameter_count",
    "train_duration_seconds_mean",
    "degradation_ratio_vs_standard",
    "noise_degradation_ratio",
    "sparsity_degradation_ratio",
    "support_extrapolation_degradation_ratio",
    "extrapolation_degradation_ratio",
    "bcic_corruption_degradation_ratio",
    "eval_mse_mean",
    "eval_mse_std",
    "eval_mse_min",
    "eval_mse_max",
    "eval_relative_l2_mean",
    "eval_relative_l2_std",
    "eval_relative_l2_min",
    "eval_relative_l2_max",
    "eval_near_boundary_relative_l2_mean",
    "eval_near_boundary_relative_l2_std",
    "eval_near_boundary_relative_l2_min",
    "eval_near_boundary_relative_l2_max",
    "eval_residual_metric_mean",
    "eval_residual_metric_std",
    "eval_residual_metric_min",
    "eval_residual_metric_max",
    "eval_bc_violation_mean",
    "eval_bc_violation_std",
    "eval_bc_violation_min",
    "eval_bc_violation_max",
    "eval_ic_violation_mean",
    "eval_ic_violation_std",
    "eval_ic_violation_min",
    "eval_ic_violation_max",
    "is_stress_run",
    "stress_family",
    "stress_severity",
    "stress_case_id",
    "nominal_peer_run_id",
    "stress_comparability_class",
    "stability_category",
    "matched_budget_group_id",
    "comparison_contract_complete",
    "headline_program",
    "headline_claim_eligible",
    "headline_blocker_codes",
    "baseline_families_present",
    *REGIME_DERIVED_FIELDS,
]


def _empty_comparison_fields() -> dict[str, Any]:
    return {field: None for field in COMPARISON_FIELDS}


def _normalized_comparison_payload(raw: Mapping[str, Any] | None, *, location: str) -> dict[str, Any]:
    try:
        normalized = comparison_dict_from_mapping(raw, location=location)
    except ValueError:
        normalized = None
    return _empty_comparison_fields() if normalized is None else dict(normalized)


def _comparison_from_run_dir(run_dir: Path, metadata: Mapping[str, Any]) -> dict[str, Any]:
    metadata_comparison = metadata.get("comparison") if isinstance(metadata.get("comparison"), Mapping) else None
    if metadata_comparison is not None:
        return _normalized_comparison_payload(metadata_comparison, location="metrics.metadata.comparison")
    config_snapshot_path = run_dir / "config_snapshot.yaml"
    if config_snapshot_path.exists():
        try:
            payload = yaml.safe_load(config_snapshot_path.read_text(encoding="utf-8"))
        except yaml.YAMLError:
            payload = None
        if isinstance(payload, Mapping):
            return _normalized_comparison_payload(payload.get("comparison"), location="config_snapshot.comparison")
    return _empty_comparison_fields()


def _grouped_inverse_calibration_summary(found_rows: list[dict[str, Any]]) -> dict[str, Any]:
    estimates = [
        value
        for value in (_coerce_float(row.get("estimated_parameter_value")) for row in found_rows)
        if value is not None
    ]
    true_values = [
        value
        for value in (_coerce_float(row.get("true_parameter_value")) for row in found_rows)
        if value is not None
    ]
    if not estimates or not true_values:
        return {}
    true_value = true_values[0]
    lower = min(estimates)
    upper = max(estimates)
    interval_coverage = 1.0 if lower <= true_value <= upper else 0.0
    calibration_error = abs(interval_coverage - 0.8)
    return {
        "eval_interval_coverage_mean": interval_coverage,
        "eval_interval_coverage_std": 0.0,
        "eval_interval_coverage_min": interval_coverage,
        "eval_interval_coverage_max": interval_coverage,
        "eval_calibration_error_mean": calibration_error,
        "eval_calibration_error_std": 0.0,
        "eval_calibration_error_min": calibration_error,
        "eval_calibration_error_max": calibration_error,
    }


def _normalize_inverse_metadata(raw: Mapping[str, Any] | None) -> dict[str, Any]:
    payload = raw if isinstance(raw, Mapping) else {}
    return {
        "observation_budget_class": payload.get("observation_budget_class"),
        "observation_pattern_family": payload.get("observation_pattern_family"),
        "inverse_target_family": payload.get("inverse_target_family"),
        "inverse_parameter_name": payload.get("inverse_parameter_name"),
        "true_parameter_value": _coerce_float(payload.get("true_parameter_value")),
        "estimated_parameter_value": _coerce_float(payload.get("estimated_parameter_value")),
        "supervision_source": payload.get("supervision_source"),
    }


def _matched_budget_group_id(record: Mapping[str, Any]) -> str | None:
    if not comparison_contract_complete(record):
        return None
    task_name = str(record.get("task_name") or "").strip()
    protocol = str(record.get("protocol") or "none").strip()
    task_mode = str(record.get("task_mode") or "pointwise").strip()
    evaluation_mode = str(record.get("evaluation_mode") or record.get("task_mode") or "pointwise").strip()
    parts = [
        f"task_name={task_name}",
        f"protocol={protocol}",
        f"task_mode={task_mode}",
        f"evaluation_mode={evaluation_mode}",
        f"data_budget_class={record.get('data_budget_class')}",
        f"compute_budget_class={record.get('compute_budget_class')}",
        f"tuning_budget_class={record.get('tuning_budget_class')}",
        f"comparison_scope={record.get('comparison_scope')}",
    ]
    return "|".join(parts)


def _fair_budget_base_key(record: Mapping[str, Any]) -> tuple[str, ...] | None:
    if not comparison_contract_complete(record):
        return None
    return (
        str(record.get("task_name") or ""),
        str(record.get("protocol") or "none"),
        str(record.get("task_mode") or "pointwise"),
        str(record.get("evaluation_mode") or record.get("task_mode") or "pointwise"),
        str(record.get("data_budget_class") or ""),
        str(record.get("compute_budget_class") or ""),
    )


def _fair_budget_group_row(
    *,
    source_kind: str,
    row_id: str,
    record: Mapping[str, Any],
) -> dict[str, Any]:
    metric_value = (
        _coerce_float(record.get("eval_relative_l2_mean"))
        if source_kind == "official_grouped_row"
        else _coerce_float(record.get("metric_value"))
    )
    metric_name = "eval.relative_l2"
    if metric_value is None:
        metric_value = (
            _coerce_float(record.get("eval_mse_mean"))
            if source_kind == "official_grouped_row"
            else _coerce_float(record.get("metric_value"))
        )
        metric_name = "eval.mse"
    duration = (
        _coerce_float(record.get("train_duration_seconds_mean"))
        if source_kind == "official_grouped_row"
        else _coerce_float(record.get("train_duration_seconds"))
    )
    row = {
        "source_kind": source_kind,
        "row_id": row_id,
        "task_name": record.get("task_name"),
        "task_mode": record.get("task_mode") or "pointwise",
        "model_name": record.get("model_name"),
        "model_mode": record.get("model_mode") or "pointwise",
        "evaluation_mode": record.get("evaluation_mode") or record.get("task_mode") or "pointwise",
        "protocol": record.get("protocol") or "none",
        "protocol_setting": record.get("protocol_setting") or record.get("setting"),
        "metric_name": metric_name,
        "metric_value": metric_value,
        "parameter_count": _coerce_int(record.get("parameter_count")),
        "train_duration_seconds": duration,
        **_empty_comparison_fields(),
    }
    row.update(comparison_dict_from_record(record) or _empty_comparison_fields())
    row["matched_budget_group_id"] = _matched_budget_group_id(row)
    return row


def _load_imported_fair_budget_rows(results_dir: Path) -> list[dict[str, Any]]:
    imports_root = results_dir / "_submission_imports"
    if not imports_root.exists():
        return []
    imported_rows: list[dict[str, Any]] = []
    for candidate_path in sorted(imports_root.rglob("leaderboard_entry_candidate.json")):
        try:
            payload = json.loads(candidate_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if not isinstance(payload, Mapping):
            continue
        row_id = str(payload.get("entry_id") or candidate_path.parent.name)
        imported_rows.append(_fair_budget_group_row(source_kind="imported_bundle", row_id=row_id, record=payload))
    return imported_rows


def _build_fair_budget_payload(*, grouped_rows: list[dict[str, Any]], results_dir: Path) -> tuple[dict[str, Any], list[dict[str, Any]], dict[str, dict[str, Any]]]:
    official_rows = [
        _fair_budget_group_row(source_kind="official_grouped_row", row_id=str(row.get("run_id") or ""), record=row)
        for row in grouped_rows
    ]
    imported_rows = _load_imported_fair_budget_rows(results_dir)
    fair_rows = official_rows + imported_rows
    complete_rows = [row for row in fair_rows if comparison_contract_complete(row)]
    incomplete_rows = [row for row in fair_rows if not comparison_contract_complete(row)]

    base_scope_sets: dict[tuple[str, ...], set[str]] = defaultdict(set)
    base_tuning_sets: dict[tuple[str, ...], set[str]] = defaultdict(set)
    for row in complete_rows:
        base_key = _fair_budget_base_key(row)
        if base_key is None:
            continue
        base_scope_sets[base_key].add(str(row.get("comparison_scope") or ""))
        base_tuning_sets[base_key].add(str(row.get("tuning_budget_class") or ""))

    grouped_complete_rows: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in complete_rows:
        group_id = str(row.get("matched_budget_group_id") or "")
        if group_id:
            grouped_complete_rows[group_id].append(dict(row))

    fair_budget_groups: list[dict[str, Any]] = []
    group_index: dict[str, dict[str, Any]] = {}
    for group_id in sorted(grouped_complete_rows):
        rows = grouped_complete_rows[group_id]
        example = rows[0]
        baseline_families_present = sorted({str(row.get("baseline_family") or "") for row in rows if row.get("baseline_family")})
        base_key = _fair_budget_base_key(example)
        headline_program = is_headline_task(str(example.get("task_name") or ""))
        blocker_codes: list[str] = []
        if not headline_program:
            blocker_codes.append("coverage_only_program")
        if base_key is not None and len(base_scope_sets.get(base_key, set())) > 1:
            blocker_codes.append("mixed_comparison_scope")
        if base_key is not None and len(base_tuning_sets.get(base_key, set())) > 1:
            blocker_codes.append("mixed_tuning_budget_class")
        if headline_program and str(example.get("comparison_scope") or "") != "matched_all":
            blocker_codes.append("non_headline_scope")
        if headline_program and str(example.get("tuning_budget_class") or "") != "fixed_recipe":
            blocker_codes.append("non_headline_tuning_budget")
        if headline_program:
            for family in HEADLINE_REQUIRED_BASELINE_FAMILIES:
                if family not in baseline_families_present:
                    blocker_codes.append(f"missing_required_baseline_family:{family}")

        headline_group_eligible = headline_program and not blocker_codes
        enriched_rows: list[dict[str, Any]] = []
        for row in rows:
            row_blockers = list(blocker_codes)
            row_headline_member = False
            baseline_family = str(row.get("baseline_family") or "")
            if headline_program:
                if baseline_family == "classical_reference":
                    row_headline_member = True
                elif baseline_family == "pinn" and str(row.get("model_name") or "") in HEADLINE_PINN_MODELS:
                    row_headline_member = True
                else:
                    row_blockers.append("non_headline_baseline_member")
            enriched_row = dict(row)
            enriched_row["headline_claim_eligible"] = headline_group_eligible and row_headline_member
            enriched_row["headline_blocker_codes"] = sorted(dict.fromkeys(code for code in row_blockers if code))
            enriched_rows.append(enriched_row)

        group_payload = {
            "matched_budget_group_id": group_id,
            "task_name": example.get("task_name"),
            "task_mode": example.get("task_mode"),
            "evaluation_mode": example.get("evaluation_mode"),
            "protocol": example.get("protocol"),
            "data_budget_class": example.get("data_budget_class"),
            "compute_budget_class": example.get("compute_budget_class"),
            "tuning_budget_class": example.get("tuning_budget_class"),
            "comparison_scope": example.get("comparison_scope"),
            "comparison_contract_complete": True,
            "headline_program": headline_program,
            "headline_claim_eligible": headline_group_eligible,
            "headline_blocker_codes": sorted(dict.fromkeys(code for code in blocker_codes if code)),
            "baseline_families_present": baseline_families_present,
            "family_row_count": len(enriched_rows),
            "rows": enriched_rows,
        }
        fair_budget_groups.append(group_payload)
        group_index[group_id] = group_payload

    summary = {
        "comparison_metadata_complete_row_count": len(complete_rows),
        "comparison_metadata_missing_row_count": len(incomplete_rows),
        "matched_budget_group_count": len(fair_budget_groups),
        "headline_eligible_group_count": sum(1 for group in fair_budget_groups if bool(group.get("headline_claim_eligible"))),
        "coverage_only_group_count": sum(1 for group in fair_budget_groups if not bool(group.get("headline_program"))),
        "blocked_group_count": sum(1 for group in fair_budget_groups if bool(group.get("headline_blocker_codes"))),
        "mixed_scope_group_count": sum(
            1 for group in fair_budget_groups if "mixed_comparison_scope" in group.get("headline_blocker_codes", [])
        ),
        "mixed_tuning_group_count": sum(
            1 for group in fair_budget_groups if "mixed_tuning_budget_class" in group.get("headline_blocker_codes", [])
        ),
        "missing_required_family_group_count": sum(
            1
            for group in fair_budget_groups
            if any(str(code).startswith("missing_required_baseline_family:") for code in group.get("headline_blocker_codes", []))
        ),
        "imported_reference_row_count": sum(
            1
            for row in imported_rows
            if str(row.get("baseline_family") or "") == "classical_reference"
        ),
    }
    return summary, fair_budget_groups, group_index



def _is_relative_to(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False



def _coerce_float(value: Any) -> float | None:
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None



def _coerce_int(value: Any) -> int | None:
    if value is None:
        return None
    return int(value)



def _format_number(value: float | int | None) -> str:
    if value is None:
        return ""
    numeric = float(value)
    if numeric.is_integer():
        return f"{numeric:.1f}"
    return f"{numeric:g}"



def _serialize_seeds(seeds: list[int]) -> str:
    return ",".join(str(seed) for seed in seeds)



def _normalize_robustness(metadata: Mapping[str, Any] | None) -> dict[str, Any]:
    raw = metadata.get("robustness") if metadata is not None else None
    if not isinstance(raw, Mapping):
        return {
            "protocol": "none",
            "level": 0.0,
            "severity_label": None,
            "target_scopes": [],
            "train_time_range": None,
            "eval_time_range": None,
            "train_support_ratio": None,
            "support_axis": None,
        }

    target_scopes = raw.get("target_scopes", [])
    if not isinstance(target_scopes, list):
        target_scopes = []

    train_time_range = raw.get("train_time_range")
    if not isinstance(train_time_range, list) or len(train_time_range) != 2:
        train_time_range = None

    eval_time_range = raw.get("eval_time_range")
    if not isinstance(eval_time_range, list) or len(eval_time_range) != 2:
        eval_time_range = None

    return {
        "protocol": str(raw.get("protocol", "none")),
        "level": float(raw.get("level", 0.0)),
        "severity_label": None if raw.get("severity_label") is None else str(raw.get("severity_label")),
        "target_scopes": [str(scope) for scope in target_scopes],
        "components": [dict(component) for component in raw.get("components", []) if isinstance(component, Mapping)],
        "train_time_range": None if train_time_range is None else [float(train_time_range[0]), float(train_time_range[1])],
        "eval_time_range": None if eval_time_range is None else [float(eval_time_range[0]), float(eval_time_range[1])],
        "train_support_ratio": None if raw.get("train_support_ratio") is None else float(raw.get("train_support_ratio")),
        "support_axis": None if raw.get("support_axis") is None else str(raw.get("support_axis")),
    }



def _format_protocol_setting(row: Mapping[str, Any]) -> str:
    protocol = str(row.get("protocol", "none"))
    if protocol == "none":
        return "standard"

    if protocol == "noise":
        scopes = str(row.get("target_scopes", "")) or "none"
        return f"noise(level={_format_number(_coerce_float(row.get('robustness_level')))}; scopes={scopes})"

    if protocol == "sparsity":
        scopes = str(row.get("target_scopes", "")) or "none"
        return f"sparsity(retain={_format_number(_coerce_float(row.get('robustness_level')))}; scopes={scopes})"

    if protocol == "bcic_corruption":
        scopes = str(row.get("target_scopes", "")) or "none"
        return f"bcic_corruption(level={_format_number(_coerce_float(row.get('robustness_level')))}; scopes={scopes})"

    if protocol == "composite":
        components = row.get("robustness_components")
        if not isinstance(components, list):
            components = []
        rendered_components = []
        for component in components:
            if not isinstance(component, Mapping):
                continue
            rendered_components.append(
                "{protocol}(level={level})".format(
                    protocol=str(component.get("protocol", "")),
                    level=_format_number(_coerce_float(component.get("level"))),
                )
            )
        scopes = str(row.get("target_scopes", "")) or "none"
        if rendered_components:
            return f"composite({'; '.join(rendered_components)}; scopes={scopes})"
        return f"composite(scopes={scopes})"

    if protocol in {"extrapolation", "support_extrapolation"}:
        support_ratio = _coerce_float(row.get("train_support_ratio"))
        if support_ratio is not None:
            axis = str(row.get("support_axis", "")).strip()
            axis_suffix = f"; axis={axis}" if axis else ""
            return f"{protocol}(train_ratio={_format_number(support_ratio)}{axis_suffix})"
        train_start = _format_number(_coerce_float(row.get("train_time_range_start")))
        train_end = _format_number(_coerce_float(row.get("train_time_range_end")))
        eval_start = _format_number(_coerce_float(row.get("eval_time_range_start")))
        eval_end = _format_number(_coerce_float(row.get("eval_time_range_end")))
        return f"{protocol}(train=[{train_start},{train_end}]; eval=[{eval_start},{eval_end}])"

    return protocol



def _format_protocol_setting_from_config(config_path: Path, task_name: str) -> tuple[str, str]:
    config = load_config(config_path)
    protocol = str(config.robustness.protocol)
    if protocol in {"noise", "sparsity", "bcic_corruption"}:
        target_scopes = config.robustness.target_scopes or resolve_target_scopes(config=config.robustness, task_name=task_name)
        row = {
            "protocol": protocol,
            "robustness_level": config.robustness.level,
            "target_scopes": ",".join(target_scopes),
        }
        return protocol, _format_protocol_setting(row)
    if protocol == "composite":
        target_scopes = config.robustness.target_scopes or resolve_target_scopes(config=config.robustness, task_name=task_name)
        row = {
            "protocol": protocol,
            "robustness_level": config.robustness.level,
            "target_scopes": ",".join(target_scopes),
            "robustness_components": list(config.robustness.components),
        }
        return protocol, _format_protocol_setting(row)
    if protocol in {"extrapolation", "support_extrapolation"}:
        row = {
            "protocol": protocol,
            "robustness_level": config.robustness.level,
            "target_scopes": "",
            "train_support_ratio": config.robustness.train_support_ratio,
            "train_time_range_start": None if config.robustness.train_time_range is None else config.robustness.train_time_range[0],
            "train_time_range_end": None if config.robustness.train_time_range is None else config.robustness.train_time_range[1],
            "eval_time_range_start": None if config.robustness.eval_time_range is None else config.robustness.eval_time_range[0],
            "eval_time_range_end": None if config.robustness.eval_time_range is None else config.robustness.eval_time_range[1],
        }
        return protocol, _format_protocol_setting(row)
    return protocol, _format_protocol_setting({"protocol": protocol})



def _resolve_manifest_path(manifest_path: Path, candidate: str) -> Path:
    candidate_path = Path(candidate)
    if candidate_path.is_absolute():
        return candidate_path
    manifest_relative = (manifest_path.parent / candidate_path).resolve()
    if manifest_relative.exists():
        return manifest_relative
    try:
        return resolve_config_path(candidate_path)
    except FileNotFoundError:
        cwd_relative = candidate_path.resolve()
        return cwd_relative



def load_matrix_manifest(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"Matrix manifest does not exist: {path}")

    with path.open("r", encoding="utf-8") as handle:
        raw = yaml.safe_load(handle)
    if not isinstance(raw, Mapping):
        raise ValueError("Matrix manifest must contain a top-level mapping.")

    schema_version = str(raw.get("schema_version", "")).strip()
    if schema_version != MATRIX_SCHEMA_VERSION:
        raise ValueError(f"Unsupported matrix schema_version '{schema_version}'. Expected '{MATRIX_SCHEMA_VERSION}'.")

    default_seeds = raw.get("default_seeds")
    if not isinstance(default_seeds, list) or not default_seeds or not all(isinstance(seed, int) for seed in default_seeds):
        raise ValueError("Matrix manifest 'default_seeds' must be a non-empty list of integers.")
    if len(set(default_seeds)) != len(default_seeds):
        raise ValueError("Matrix manifest 'default_seeds' must not contain duplicates.")

    results_root = raw.get("results_root")
    if not isinstance(results_root, str) or not results_root.strip():
        raise ValueError("Matrix manifest 'results_root' must be a non-empty string.")

    runs = raw.get("runs")
    if not isinstance(runs, list) or not runs:
        raise ValueError("Matrix manifest 'runs' must be a non-empty list.")

    normalized_runs: list[dict[str, Any]] = []
    seen_run_ids: set[str] = set()
    for index, item in enumerate(runs):
        if not isinstance(item, Mapping):
            raise ValueError(f"Matrix manifest run entry at index {index} must be a mapping.")
        run_id = str(item.get("run_id", "")).strip()
        config_path_value = str(item.get("config_path", "")).strip()
        task_name = str(item.get("task_name", "")).strip()
        model_name = str(item.get("model_name", "")).strip()
        protocol = str(item.get("protocol", "")).strip()
        if not all([run_id, config_path_value, task_name, model_name, protocol]):
            raise ValueError(
                "Each matrix run must define non-empty 'run_id', 'config_path', 'task_name', 'model_name', and 'protocol'."
            )
        if run_id in seen_run_ids:
            raise ValueError(f"Duplicate matrix run_id '{run_id}'.")
        seen_run_ids.add(run_id)

        resolved_config_path = _resolve_manifest_path(path, config_path_value)
        if not resolved_config_path.exists():
            raise FileNotFoundError(f"Matrix config_path does not exist for run '{run_id}': {resolved_config_path}")

        config = load_config(resolved_config_path)
        if config.task.name != task_name:
            raise ValueError(f"Matrix run '{run_id}' task_name '{task_name}' does not match config task '{config.task.name}'.")
        if config.model.name != model_name:
            raise ValueError(f"Matrix run '{run_id}' model_name '{model_name}' does not match config model '{config.model.name}'.")
        config_protocol, protocol_setting = _format_protocol_setting_from_config(resolved_config_path, task_name=task_name)
        if config_protocol != protocol:
            raise ValueError(
                f"Matrix run '{run_id}' protocol '{protocol}' does not match config robustness protocol '{config_protocol}'."
            )
        comparison_payload = _empty_comparison_fields() if config.comparison is None else dict(config.comparison.to_dict())
        regime_payload = regime_raw_fields_from_config(protocol=protocol, task_params=config.task.params)

        normalized_runs.append(
            {
                "run_id": run_id,
                "config_path": config_path_value,
                "resolved_config_path": resolved_config_path,
                "task_name": task_name,
                "model_name": model_name,
                "protocol": protocol,
                "protocol_setting": protocol_setting,
                **comparison_payload,
                **regime_payload,
            }
        )

    return {
        "schema_version": schema_version,
        "manifest_path": path.resolve(),
        "default_seeds": list(default_seeds),
        "results_root": results_root,
        "runs": normalized_runs,
    }



def discover_run_dirs(results_dir: Path, output_dir: Path | None = None) -> list[Path]:
    run_dirs: set[Path] = set()
    for artifact_name in STABLE_ARTIFACT_NAMES:
        for artifact_path in results_dir.rglob(artifact_name):
            if output_dir is not None and _is_relative_to(artifact_path, output_dir):
                continue
            run_dirs.add(artifact_path.parent.resolve())
    return sorted(run_dirs)



def flatten_metrics_payload(metrics: Mapping[str, Any], *, run_dir: Path, results_dir: Path) -> dict[str, Any]:
    metadata = metrics.get("metadata")
    metadata = metadata if isinstance(metadata, Mapping) else {}
    train = metrics.get("train")
    train = train if isinstance(train, Mapping) else {}
    eval_metrics = metrics.get("eval")
    eval_metrics = eval_metrics if isinstance(eval_metrics, Mapping) else {}
    final_loss_terms = train.get("final_loss_terms")
    final_loss_terms = final_loss_terms if isinstance(final_loss_terms, Mapping) else {}

    robustness = _normalize_robustness(metadata)
    train_time_range = robustness["train_time_range"]
    eval_time_range = robustness["eval_time_range"]
    output_dir = str(run_dir.resolve().relative_to(results_dir.resolve()))
    comparison = _comparison_from_run_dir(run_dir, metadata)
    inverse = _normalize_inverse_metadata(metadata.get("inverse"))
    regime = normalize_regime_metadata_mapping(metadata.get("regime"))
    geometry = normalize_geometry_metadata_mapping(metadata.get("geometry"))
    row: dict[str, Any] = {
        "output_dir": output_dir,
        "task_name": metadata.get("task_name"),
        "task_mode": metadata.get("task_mode") or "pointwise",
        "model_name": metadata.get("model_name"),
        "model_mode": metadata.get("model_mode") or "pointwise",
        "evaluation_mode": metadata.get("evaluation_mode") or metadata.get("task_mode") or "pointwise",
        **comparison,
        "seed": _coerce_int(metadata.get("seed")),
        "device": metadata.get("device"),
        "protocol": robustness["protocol"],
        "robustness_level": robustness["level"],
        **inverse,
        **regime,
        **geometry,
        "severity_label": robustness["severity_label"],
        "target_scopes": ",".join(robustness["target_scopes"]),
        "train_time_range_start": None if train_time_range is None else train_time_range[0],
        "train_time_range_end": None if train_time_range is None else train_time_range[1],
        "eval_time_range_start": None if eval_time_range is None else eval_time_range[0],
        "eval_time_range_end": None if eval_time_range is None else eval_time_range[1],
        "train_support_ratio": robustness["train_support_ratio"],
        "support_axis": robustness["support_axis"],
        "train_final_loss": _coerce_float(train.get("final_loss")),
        "train_best_loss": _coerce_float(train.get("best_loss")),
        "train_epochs": _coerce_int(train.get("epochs")),
        "parameter_count": _coerce_int(metadata.get("parameter_count")),
        "task_parameter_count": _coerce_int(metadata.get("task_parameter_count")),
        "total_trainable_parameter_count": _coerce_int(metadata.get("total_trainable_parameter_count")),
        "train_duration_seconds": _coerce_float(train.get("duration_seconds")),
    }
    row["protocol_setting"] = _format_protocol_setting(row)

    for loss_name, loss_value in sorted(final_loss_terms.items()):
        row[f"train_loss_{loss_name}"] = _coerce_float(loss_value)
    for metric_name, metric_value in sorted(eval_metrics.items()):
        row[f"eval_{metric_name}"] = _coerce_float(metric_value)
    return row


def _first_present(values: list[dict[str, Any]], key: str) -> Any:
    for row in values:
        value = row.get(key)
        if value not in {None, ""}:
            return value
    return None



def _ranking_value(value: Any) -> tuple[int, float]:
    numeric = _coerce_float(value)
    if numeric is None:
        return (1, float("inf"))
    return (0, numeric)



def sort_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return sorted(
        rows,
        key=lambda row: (
            str(row.get("task_name") or ""),
            _ranking_value(row.get("eval_relative_l2")),
            _ranking_value(row.get("eval_mse")),
            str(row.get("model_name") or ""),
            str(row.get("protocol") or ""),
            str(row.get("output_dir") or ""),
        ),
    )



def build_grouped_rows(rows: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in sort_rows(rows):
        task_name = str(row.get("task_name") or "unknown")
        groups[task_name].append(dict(row))
    return {task_name: grouped_rows for task_name, grouped_rows in sorted(groups.items())}



def collect_leaderboard_rows(results_dir: Path, output_dir: Path | None = None) -> tuple[list[str], list[dict[str, Any]], list[str]]:
    warnings: list[str] = []
    rows: list[dict[str, Any]] = []
    dynamic_columns: set[str] = set()

    for run_dir in discover_run_dirs(results_dir=results_dir, output_dir=output_dir):
        metrics_path = run_dir / "metrics.json"
        relative_run_dir = run_dir.resolve().relative_to(results_dir.resolve())
        if not metrics_path.exists():
            warnings.append(f"Skipped {relative_run_dir}: missing metrics.json")
            continue
        try:
            with metrics_path.open("r", encoding="utf-8") as handle:
                metrics = json.load(handle)
        except (OSError, json.JSONDecodeError) as exc:
            warnings.append(f"Skipped {relative_run_dir}: unreadable metrics.json ({exc})")
            continue
        if not isinstance(metrics, Mapping):
            warnings.append(f"Skipped {relative_run_dir}: metrics.json must contain a JSON object")
            continue

        row = flatten_metrics_payload(metrics, run_dir=run_dir, results_dir=results_dir)
        rows.append(row)
        dynamic_columns.update(key for key in row.keys() if key not in FIXED_COLUMNS)

    columns = list(FIXED_COLUMNS) + sorted(dynamic_columns)
    normalized_rows: list[dict[str, Any]] = []
    for row in sort_rows(rows):
        normalized_rows.append({column: row.get(column) for column in columns})
    return columns, normalized_rows, warnings



def _compute_metric_summary(values: list[float]) -> tuple[float | None, float | None, float | None, float | None]:
    if not values:
        return None, None, None, None
    mean = fmean(values)
    std = 0.0 if len(values) == 1 else float(stdev(values))
    return mean, std, min(values), max(values)



def _format_grouped_seed_status(found: list[int], missing: list[int]) -> str:
    found_text = _serialize_seeds(found)
    missing_text = _serialize_seeds(missing)
    if found and missing:
        return f"{found_text} (missing: {missing_text})"
    if missing:
        return f"missing: {missing_text}"
    return found_text



def _format_grouped_metric(mean: float | None, std: float | None) -> str:
    if mean is None or std is None:
        return ""
    return f"{mean:.6g} ± {std:.6g}"



def sort_grouped_summary_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return sorted(
        rows,
        key=lambda row: (
            str(row.get("task_name") or ""),
            _ranking_value(row.get("eval_relative_l2_mean")),
            _ranking_value(row.get("eval_mse_mean")),
            str(row.get("model_name") or ""),
            str(row.get("protocol") or ""),
            str(row.get("run_id") or ""),
        ),
    )



def build_grouped_summary_groups(rows: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in sort_grouped_summary_rows(rows):
        task_name = str(row.get("task_name") or "unknown")
        groups[task_name].append(dict(row))
    return {task_name: grouped_rows for task_name, grouped_rows in sorted(groups.items())}



def collect_grouped_summary_rows(
    *,
    results_dir: Path,
    matrix_manifest_path: Path,
) -> tuple[dict[str, Any], list[str], list[dict[str, Any]], list[str]]:
    manifest = load_matrix_manifest(matrix_manifest_path)
    warnings: list[str] = []
    grouped_rows: list[dict[str, Any]] = []

    for run in manifest["runs"]:
        run_id = run["run_id"]
        expected_seeds: list[int] = list(manifest["default_seeds"])
        found_rows: list[dict[str, Any]] = []
        found_seeds: list[int] = []
        missing_seeds: list[int] = []

        for seed in expected_seeds:
            run_dir = results_dir / f"{run_id}_seed{seed}"
            metrics_path = run_dir / "metrics.json"
            if not metrics_path.exists():
                missing_seeds.append(seed)
                continue
            try:
                with metrics_path.open("r", encoding="utf-8") as handle:
                    metrics = json.load(handle)
            except (OSError, json.JSONDecodeError) as exc:
                missing_seeds.append(seed)
                warnings.append(f"Skipped expected run {run_id}_seed{seed}: unreadable metrics.json ({exc})")
                continue
            if not isinstance(metrics, Mapping):
                missing_seeds.append(seed)
                warnings.append(f"Skipped expected run {run_id}_seed{seed}: metrics.json must contain a JSON object")
                continue

            found_rows.append(flatten_metrics_payload(metrics, run_dir=run_dir, results_dir=results_dir))
            found_seeds.append(seed)

        if missing_seeds:
            warnings.append(f"Missing expected baseline runs for {run_id}: seeds {_serialize_seeds(missing_seeds)}")

        mse_values = [value for value in (_coerce_float(row.get("eval_mse")) for row in found_rows) if value is not None]
        relative_l2_values = [
            value for value in (_coerce_float(row.get("eval_relative_l2")) for row in found_rows) if value is not None
        ]
        parameter_counts = [value for value in (_coerce_int(row.get("parameter_count")) for row in found_rows) if value is not None]
        task_parameter_counts = [value for value in (_coerce_int(row.get("task_parameter_count")) for row in found_rows) if value is not None]
        total_trainable_parameter_counts = [
            value for value in (_coerce_int(row.get("total_trainable_parameter_count")) for row in found_rows) if value is not None
        ]
        train_durations = [
            value for value in (_coerce_float(row.get("train_duration_seconds")) for row in found_rows) if value is not None
        ]
        mse_mean, mse_std, mse_min, mse_max = _compute_metric_summary(mse_values)
        rel_mean, rel_std, rel_min, rel_max = _compute_metric_summary(relative_l2_values)
        parameter_count = None if not parameter_counts else parameter_counts[0]
        task_parameter_count = None if not task_parameter_counts else task_parameter_counts[0]
        total_trainable_parameter_count = None if not total_trainable_parameter_counts else total_trainable_parameter_counts[0]
        train_duration_seconds_mean = None if not train_durations else fmean(train_durations)

        model_mode = next((row.get("model_mode") for row in found_rows if row.get("model_mode") is not None), None)
        task_mode = next((row.get("task_mode") for row in found_rows if row.get("task_mode") is not None), None)
        evaluation_mode = next((row.get("evaluation_mode") for row in found_rows if row.get("evaluation_mode") is not None), None)
        geometry_metadata = {
            field: _first_present(found_rows, field)
            for field in GEOMETRY_RAW_FIELDS
        }
        inverse_metadata = {
            field: _first_present(found_rows, field)
            for field in INVERSE_RAW_FIELDS
        }
        additional_eval_summary: dict[str, Any] = {}
        additional_metric_names = sorted(
            {
                key.removeprefix("eval_")
                for row in found_rows
                for key in row
                if key.startswith("eval_")
                and key not in {"eval_mse", "eval_relative_l2"}
                and any(_coerce_float(candidate_row.get(key)) is not None for candidate_row in found_rows)
            }
        )
        for metric_name in additional_metric_names:
            values = [
                value
                for value in (_coerce_float(row.get(f"eval_{metric_name}")) for row in found_rows)
                if value is not None
            ]
            mean, std, min_value, max_value = _compute_metric_summary(values)
            additional_eval_summary[f"eval_{metric_name}_mean"] = mean
            additional_eval_summary[f"eval_{metric_name}_std"] = std
            additional_eval_summary[f"eval_{metric_name}_min"] = min_value
            additional_eval_summary[f"eval_{metric_name}_max"] = max_value
        if "eval_interval_coverage_mean" not in additional_eval_summary or "eval_calibration_error_mean" not in additional_eval_summary:
            additional_eval_summary.update(
                {
                    key: value
                    for key, value in _grouped_inverse_calibration_summary(found_rows).items()
                    if key not in additional_eval_summary
                }
            )

        grouped_rows.append(
            {
                "run_id": run_id,
                "task_name": run["task_name"],
                "task_mode": task_mode,
                "model_name": run["model_name"],
                "model_mode": model_mode,
                "evaluation_mode": evaluation_mode,
                **{field: run.get(field) for field in COMPARISON_FIELDS},
                **inverse_metadata,
                **{field: run.get(field) for field in REGIME_RAW_FIELDS},
                **geometry_metadata,
                "protocol": run["protocol"],
                "protocol_setting": run["protocol_setting"],
                "expected_seeds": _serialize_seeds(expected_seeds),
                "found_seeds": _serialize_seeds(found_seeds),
                "missing_seeds": _serialize_seeds(missing_seeds),
                "run_count": len(found_rows),
                "parameter_count": parameter_count,
                "task_parameter_count": task_parameter_count,
                "total_trainable_parameter_count": total_trainable_parameter_count,
                "train_duration_seconds_mean": train_duration_seconds_mean,
                "degradation_ratio_vs_standard": None,
                "noise_degradation_ratio": None,
                "sparsity_degradation_ratio": None,
                "support_extrapolation_degradation_ratio": None,
                "extrapolation_degradation_ratio": None,
                "bcic_corruption_degradation_ratio": None,
                "eval_mse_mean": mse_mean,
                "eval_mse_std": mse_std,
                "eval_mse_min": mse_min,
                "eval_mse_max": mse_max,
                "eval_relative_l2_mean": rel_mean,
                "eval_relative_l2_std": rel_std,
                "eval_relative_l2_min": rel_min,
                "eval_relative_l2_max": rel_max,
                **additional_eval_summary,
            }
        )

    standard_rows = {
        (str(row.get("task_name")), str(row.get("model_name"))): row
        for row in grouped_rows
        if str(row.get("protocol")) == "none"
    }
    for row in grouped_rows:
        if str(row.get("protocol")) == "none":
            continue
        baseline = standard_rows.get((str(row.get("task_name")), str(row.get("model_name"))))
        if baseline is None:
            continue
        baseline_value = _coerce_float(baseline.get("eval_relative_l2_mean"))
        row_value = _coerce_float(row.get("eval_relative_l2_mean"))
        if baseline_value is None or row_value is None:
            continue
        ratio = row_value if baseline_value <= 0 else row_value / baseline_value
        row["degradation_ratio_vs_standard"] = ratio
        protocol = str(row.get("protocol") or "")
        if protocol == "noise":
            row["noise_degradation_ratio"] = ratio
        elif protocol == "sparsity":
            row["sparsity_degradation_ratio"] = ratio
        elif protocol in {"extrapolation", "support_extrapolation"}:
            row["support_extrapolation_degradation_ratio"] = ratio
            row["extrapolation_degradation_ratio"] = ratio
        elif protocol == "bcic_corruption":
            row["bcic_corruption_degradation_ratio"] = ratio

    normalized_rows = []
    fair_budget_summary, fair_budget_groups, fair_budget_group_index = _build_fair_budget_payload(
        grouped_rows=grouped_rows,
        results_dir=results_dir,
    )
    regime_summary, regime_groups, regime_group_index = build_regime_payload(grouped_rows=grouped_rows)
    for row in sort_grouped_summary_rows(grouped_rows):
        enriched_row = apply_stress_metadata(row)
        group_id = _matched_budget_group_id(enriched_row)
        group_payload = None if group_id is None else fair_budget_group_index.get(group_id)
        enriched_row.update(regime_dict_from_record(enriched_row))
        enriched_row["matched_budget_group_id"] = group_id
        enriched_row["comparison_contract_complete"] = comparison_contract_complete(enriched_row)
        enriched_row["headline_program"] = bool(group_payload and group_payload.get("headline_program"))
        enriched_row["headline_claim_eligible"] = bool(
            group_payload
            and any(
                entry.get("source_kind") == "official_grouped_row"
                and entry.get("row_id") == enriched_row.get("run_id")
                and entry.get("headline_claim_eligible")
                for entry in group_payload.get("rows", [])
            )
        )
        enriched_row["headline_blocker_codes"] = (
            sorted(group_payload.get("headline_blocker_codes", []))
            if group_payload is not None
            else (["missing_comparison_metadata"] if not comparison_contract_complete(enriched_row) else [])
        )
        enriched_row["baseline_families_present"] = (
            ",".join(group_payload.get("baseline_families_present", []))
            if group_payload is not None
            else ""
        )
        regime_entry = None
        regime_group = None
        for candidate_group in regime_group_index.values():
            regime_entry = next(
                (
                    item
                    for item in candidate_group.get("rows", [])
                    if str(item.get("run_id") or "") == str(enriched_row.get("run_id") or "")
                ),
                None,
            )
            if regime_entry is not None:
                regime_group = candidate_group
                break
        if regime_entry is not None and regime_group is not None:
            enriched_row["ood_family"] = regime_entry.get("ood_family")
            enriched_row["regime_problem_class"] = regime_entry.get("regime_problem_class")
            enriched_row["regime_dynamics_class"] = regime_entry.get("regime_dynamics_class")
            enriched_row["regime_observation_class"] = regime_entry.get("regime_observation_class")
            enriched_row["regime_distribution_class"] = regime_entry.get("regime_distribution_class")
            enriched_row["regime_horizon_class"] = regime_entry.get("regime_horizon_class")
            enriched_row["regime_geometry_class"] = regime_entry.get("regime_geometry_class")
            enriched_row["regime_board_cell_id"] = regime_group.get("regime_board_cell_id")
            enriched_row["regime_claim_complete"] = regime_entry.get("regime_claim_complete")
            enriched_row["regime_claim_blocker_codes"] = regime_entry.get("regime_claim_blocker_codes", [])
            enriched_row["regime_program"] = regime_entry.get("regime_program")
        else:
            enriched_row["ood_family"] = None
            enriched_row["regime_problem_class"] = None
            enriched_row["regime_dynamics_class"] = None
            enriched_row["regime_observation_class"] = None
            enriched_row["regime_distribution_class"] = None
            enriched_row["regime_horizon_class"] = None
            enriched_row["regime_geometry_class"] = None
            enriched_row["regime_board_cell_id"] = None
            enriched_row["regime_claim_complete"] = None
            enriched_row["regime_claim_blocker_codes"] = []
            enriched_row["regime_program"] = None
        normalized_rows.append(enriched_row)
    manifest["fair_budget_summary"] = fair_budget_summary
    manifest["fair_budget_groups"] = fair_budget_groups
    manifest["regime_summary"] = regime_summary
    manifest["regime_groups"] = regime_groups
    dynamic_columns = sorted(
        {
            key
            for row in normalized_rows
            for key in row
            if key not in GROUPED_COLUMNS
        }
    )
    columns = list(GROUPED_COLUMNS) + dynamic_columns
    return (
        manifest,
        columns,
        [{column: row.get(column) for column in columns} for row in normalized_rows],
        warnings,
    )
