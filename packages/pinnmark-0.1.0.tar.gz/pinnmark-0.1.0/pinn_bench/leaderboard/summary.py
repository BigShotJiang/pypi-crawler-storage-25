"""Narrative grouped benchmark summary exporter."""

from __future__ import annotations

import argparse
import json
from collections import defaultdict
from collections.abc import Sequence
from pathlib import Path
from statistics import fmean
from typing import Any



def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Generate a benchmark narrative summary from grouped leaderboard JSON.")
    parser.add_argument("--grouped-json", required=True, type=str, help="Path to leaderboard_grouped.json.")
    parser.add_argument("--output-file", default=None, type=str, help="Optional destination path. Defaults to <grouped-json-dir>/benchmark_summary.md.")
    parser.add_argument("--analysis-dir", default=None, type=str, help="Optional analysis directory containing analysis_bundle.json.")
    return parser



def _load_grouped_payload(grouped_json_path: Path) -> dict[str, Any]:
    payload = json.loads(grouped_json_path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"Grouped JSON must contain a top-level mapping: {grouped_json_path}")
    return payload



def _load_analysis_bundle(analysis_dir: Path | None) -> dict[str, Any] | None:
    if analysis_dir is None:
        return None
    bundle_path = analysis_dir / "analysis_bundle.json"
    payload = json.loads(bundle_path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"Analysis bundle must contain a top-level mapping: {bundle_path}")
    return payload



def _coerce_float(value: Any) -> float | None:
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None



def _coerce_int(value: Any) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None



def _display_mode(value: Any) -> str:
    text = str(value or "pointwise").strip()
    return text or "pointwise"



def _format_protocol_label(row: dict[str, Any]) -> str:
    protocol = str(row.get("protocol") or "none")
    if protocol == "none":
        return "standard"
    setting = str(row.get("protocol_setting") or "").strip()
    return protocol if not setting or setting == "standard" else f"{protocol} ({setting})"



def _expected_seed_count(row: dict[str, Any], default_seed_count: int) -> int:
    raw = str(row.get("expected_seeds") or "").strip()
    if not raw:
        return default_seed_count
    return len([item for item in raw.split(",") if item.strip()])



def _best_rows_by_task(rows: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    winners: dict[str, dict[str, Any]] = {}
    for row in rows:
        task_name = str(row.get("task_name") or "unknown")
        metric = _coerce_float(row.get("eval_relative_l2_mean"))
        mse = _coerce_float(row.get("eval_mse_mean"))
        if metric is None:
            continue
        incumbent = winners.get(task_name)
        if incumbent is None:
            winners[task_name] = row
            continue
        incumbent_key = (
            _coerce_float(incumbent.get("eval_relative_l2_mean")) or float("inf"),
            _coerce_float(incumbent.get("eval_mse_mean")) or float("inf"),
            _coerce_float(incumbent.get("parameter_count")) or float("inf"),
            _coerce_float(incumbent.get("train_duration_seconds_mean")) or float("inf"),
            str(incumbent.get("run_id") or ""),
        )
        candidate_key = (
            metric,
            mse or float("inf"),
            _coerce_float(row.get("parameter_count")) or float("inf"),
            _coerce_float(row.get("train_duration_seconds_mean")) or float("inf"),
            str(row.get("run_id") or ""),
        )
        if candidate_key < incumbent_key:
            winners[task_name] = row
    return winners



def _best_clean_rows_by_task(rows: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    clean_rows = [row for row in rows if str(row.get("protocol")) == "none"]
    return _best_rows_by_task(clean_rows)



def _largest_degradation(rows: list[dict[str, Any]]) -> tuple[dict[str, Any] | None, float | None]:
    standard_rows: dict[tuple[str, str], dict[str, Any]] = {}
    for row in rows:
        if str(row.get("protocol")) == "none":
            standard_rows[(str(row.get("task_name")), str(row.get("model_name")))] = row

    worst_row: dict[str, Any] | None = None
    worst_ratio: float | None = None
    for row in rows:
        if str(row.get("protocol")) == "none":
            continue
        metric = _coerce_float(row.get("eval_relative_l2_mean"))
        if metric is None:
            continue
        baseline = standard_rows.get((str(row.get("task_name")), str(row.get("model_name"))))
        if baseline is None:
            continue
        baseline_metric = _coerce_float(baseline.get("eval_relative_l2_mean"))
        if baseline_metric is None:
            continue
        ratio = metric / baseline_metric if baseline_metric > 0 else metric
        if worst_ratio is None or ratio > worst_ratio:
            worst_ratio = ratio
            worst_row = row
    return worst_row, worst_ratio



def _lightest_family(rows: list[dict[str, Any]]) -> dict[str, Any] | None:
    candidates = [row for row in rows if _coerce_int(row.get("run_count")) not in {None, 0}]
    if not candidates:
        return None
    return min(
        candidates,
        key=lambda row: (
            _coerce_float(row.get("parameter_count")) or float("inf"),
            _coerce_float(row.get("train_duration_seconds_mean")) or float("inf"),
            _coerce_float(row.get("eval_relative_l2_mean")) or float("inf"),
        ),
    )



def _most_stable_family(rows: list[dict[str, Any]]) -> tuple[dict[str, Any] | None, float | None]:
    grouped: dict[tuple[str, str], list[float]] = {}
    standard_rows: dict[tuple[str, str], dict[str, Any]] = {}
    for row in rows:
        task_model = (str(row.get("task_name")), str(row.get("model_name")))
        if str(row.get("protocol")) == "none":
            standard_rows[task_model] = row
            continue
        ratio = _coerce_float(row.get("degradation_ratio_vs_standard"))
        if ratio is None:
            continue
        grouped.setdefault(task_model, []).append(ratio)

    best_row: dict[str, Any] | None = None
    best_score: float | None = None
    for task_model, ratios in grouped.items():
        if not ratios:
            continue
        score = fmean(ratios)
        standard = standard_rows.get(task_model)
        if standard is None:
            continue
        if best_score is None or score < best_score:
            best_score = score
            best_row = standard
    return best_row, best_score



def _widest_gap_protocol(rows: list[dict[str, Any]]) -> tuple[str | None, float | None]:
    grouped: dict[str, list[float]] = {}
    for row in rows:
        protocol = str(row.get("protocol"))
        if protocol == "none":
            continue
        ratio = _coerce_float(row.get("degradation_ratio_vs_standard"))
        if ratio is None:
            continue
        grouped.setdefault(protocol, []).append(ratio)
    if not grouped:
        return None, None
    protocol, ratios = max(grouped.items(), key=lambda item: fmean(item[1]))
    return protocol, fmean(ratios)



def _incomplete_rows(rows: list[dict[str, Any]], default_seed_count: int) -> list[dict[str, Any]]:
    incomplete: list[dict[str, Any]] = []
    for row in rows:
        run_count = _coerce_int(row.get("run_count")) or 0
        expected = _expected_seed_count(row, default_seed_count)
        missing_seeds = str(row.get("missing_seeds") or "").strip()
        if run_count < expected or missing_seeds:
            incomplete.append(row)
    return incomplete



def _leader_payload(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "task_name": str(row.get("task_name") or "unknown"),
        "task_mode": _display_mode(row.get("task_mode")),
        "run_id": str(row.get("run_id") or "unknown"),
        "model_name": str(row.get("model_name") or "unknown"),
        "model_mode": _display_mode(row.get("model_mode")),
        "evaluation_mode": _display_mode(row.get("evaluation_mode")),
        "protocol_label": _format_protocol_label(row),
        "eval_relative_l2_mean": _coerce_float(row.get("eval_relative_l2_mean")),
        "eval_mse_mean": _coerce_float(row.get("eval_mse_mean")),
    }



def _operator_preview_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    for row in rows:
        if _display_mode(row.get("task_mode")) == "field" or _display_mode(row.get("model_mode")) == "field" or _display_mode(row.get("evaluation_mode")) == "field":
            output.append(
                {
                    "run_id": str(row.get("run_id") or "unknown"),
                    "task_name": str(row.get("task_name") or "unknown"),
                    "task_mode": _display_mode(row.get("task_mode")),
                    "model_name": str(row.get("model_name") or "unknown"),
                    "model_mode": _display_mode(row.get("model_mode")),
                    "evaluation_mode": _display_mode(row.get("evaluation_mode")),
                    "protocol_label": _format_protocol_label(row),
                }
            )
    protocol_order = {"standard": 0, "none": 0, "noise": 1, "sparsity": 2, "extrapolation": 3}
    return sorted(
        output,
        key=lambda row: (
            str(row.get("task_name") or ""),
            str(row.get("model_name") or ""),
            protocol_order.get(str(row.get("protocol_label") or "").split(" ", 1)[0].lower(), 99),
            str(row.get("protocol_label") or ""),
        ),
    )



def _group_operator_preview_rows(rows: list[dict[str, Any]]) -> dict[str, dict[str, list[str]]]:
    grouped: dict[str, dict[str, list[str]]] = {}
    for row in rows:
        task_name = str(row.get("task_name") or "unknown")
        model_name = str(row.get("model_name") or "unknown")
        grouped.setdefault(task_name, {}).setdefault(model_name, []).append(str(row.get("protocol_label") or "unknown"))
    return grouped



def build_summary_facts(payload: dict[str, Any]) -> dict[str, Any]:
    rows = payload.get("rows")
    rows = rows if isinstance(rows, list) else []
    warnings = payload.get("warnings")
    warnings = warnings if isinstance(warnings, list) else []
    default_seed_count = len(payload.get("default_seeds") or [])
    matrix_manifest = payload.get("matrix_manifest")
    matrix_name = Path(str(matrix_manifest or "grouped_results")).stem

    winners = _best_rows_by_task(rows)
    clean_winners = _best_clean_rows_by_task(rows)
    worst_row, worst_ratio = _largest_degradation(rows)
    lightest = _lightest_family(rows)
    stable_row, stable_score = _most_stable_family(rows)
    widest_protocol, widest_gap_ratio = _widest_gap_protocol(rows)
    incomplete = _incomplete_rows(rows, default_seed_count=default_seed_count)
    operator_rows = _operator_preview_rows(rows)

    return {
        "matrix_name": matrix_name,
        "matrix_manifest": None if matrix_manifest is None else str(matrix_manifest),
        "task_leaders": [_leader_payload(winners[task_name]) for task_name in sorted(winners)],
        "clean_task_leaders": [_leader_payload(clean_winners[task_name]) for task_name in sorted(clean_winners)],
        "operator_preview_rows": operator_rows,
        "worst_protocol_degradation": None
        if worst_row is None or worst_ratio is None
        else {
            "run_id": str(worst_row.get("run_id") or "unknown"),
            "task_name": str(worst_row.get("task_name") or "unknown"),
            "protocol_label": _format_protocol_label(worst_row),
            "ratio": worst_ratio,
        },
        "lightest_family": None
        if lightest is None
        else {
            "run_id": str(lightest.get("run_id") or "unknown"),
            "parameter_count": _coerce_int(lightest.get("parameter_count")),
            "train_duration_seconds_mean": _coerce_float(lightest.get("train_duration_seconds_mean")),
        },
        "most_stable_family": None
        if stable_row is None or stable_score is None
        else {
            "run_id": str(stable_row.get("run_id") or "unknown"),
            "task_name": str(stable_row.get("task_name") or "unknown"),
            "model_name": str(stable_row.get("model_name") or "unknown"),
            "mean_degradation_ratio": stable_score,
        },
        "widest_gap_protocol": None
        if widest_protocol is None or widest_gap_ratio is None
        else {
            "protocol": widest_protocol,
            "mean_degradation_ratio": widest_gap_ratio,
        },
        "incomplete_family_count": len(incomplete),
        "incomplete_run_ids": [str(row.get("run_id") or "unknown") for row in incomplete],
        "grouped_warning_count": len(warnings),
        "warnings": [str(item) for item in warnings],
    }



def _append_analysis_sections(lines: list[str], analysis_bundle: dict[str, Any]) -> None:
    comparative = analysis_bundle.get("comparative_report", {})
    diagnostics = analysis_bundle.get("diagnostics", {})
    decision = analysis_bundle.get("decision_support", {})
    release_review = analysis_bundle.get("release_review", {})
    cross_version = analysis_bundle.get("cross_version_review", {})
    hardness_report = analysis_bundle.get("hardness_report", {})
    review_packet = analysis_bundle.get("review_packet", {})
    promotion_gap_report = analysis_bundle.get("promotion_gap_report", {})
    observation_snapshot = analysis_bundle.get("observation_snapshot", {})

    lines.extend(["", "## Protocol Fragility Observations", ""])
    protocol_intelligence = comparative.get("protocol_intelligence", {})
    rankings = protocol_intelligence.get("rankings", [])
    if rankings:
        for item in rankings[:3]:
            lines.append(
                "- `{protocol_label}`: mean degradation ratio `{mean_degradation_ratio:.3f}` across `{case_count}` cases. Source: `_analysis/comparative_report.json`.".format(
                    **item
                )
            )
    else:
        lines.append("- No analysis-backed protocol fragility observations were available.")
    for note in protocol_intelligence.get("observations", []):
        lines.append(f"- {note} Source: `_analysis/comparative_report.json`.")

    lines.extend(["", "## Operator vs Pointwise Observations", ""])
    mode_comparison = comparative.get("mode_comparison", {})
    mode_items = []
    mode_items.extend(mode_comparison.get("evidence_backed_observations", []))
    mode_items.extend(mode_comparison.get("cautionary_interpretation", []))
    mode_items.extend(mode_comparison.get("fair_comparisons", []))
    if mode_items:
        for note in mode_items:
            lines.append(f"- {note} Source: `_analysis/comparative_report.json`.")
    else:
        lines.append("- No mode-comparison observations were available.")

    lines.extend(["", "## Task Hardness Observations", ""])
    task_ranking = hardness_report.get("task_ranking", [])
    if task_ranking:
        for item in task_ranking[:3]:
            lines.append(
                "- `{task_name}`: score=`{score}` confidence=`{confidence}`. {explanation} Caution: {caution_note} Source: `_analysis/hardness_report.json`.".format(
                    **item
                )
            )
    else:
        lines.append("- No task-hardness observations were available.")

    lines.extend(["", "## Diagnostics and Interpretation Cautions", ""])
    caution_findings = [
        item
        for item in diagnostics.get("findings", [])
        if str(item.get("severity")) in {"warning", "caution"}
    ]
    if not caution_findings:
        lines.append("- No caution-level diagnostics were emitted.")
    else:
        for item in caution_findings:
            lines.append(
                "- `{code}` (`{family}`) on `{subject}`: {message} Recommendation: {recommendation} Source: `_analysis/diagnostics.json`.".format(
                    **item
                )
            )

    lines.extend(["", "## Current Preview Interpretation", ""])
    for item in release_review.get("evidence_backed_observations", []):
        lines.append(f"- {item} Source: `_analysis/release_review.json`.")
    for point in cross_version.get("preview_vs_current_formal", {}).get("key_points", [])[:2]:
        lines.append(f"- {point} Source: `_analysis/cross_version_review.json`.")
    if observation_snapshot:
        lines.append(
            "- Observation snapshot currently reports smallest remaining gap `{gap}` with formal-discussion signal `{signal}`. Source: `_analysis/observation_snapshot.json`.".format(
                gap=observation_snapshot.get("smallest_remaining_gap"),
                signal=observation_snapshot.get("current_formal_discussion_signal"),
            )
        )

    lines.extend(["", "## Formal-Discussion Takeaway", ""])
    lines.append(
        "- Overall recommendation: `{recommendation}`. Source: `_analysis/decision_support.json`.".format(
            recommendation=decision.get("overall_recommendation")
        )
    )
    lines.append(
        "- Formal-discussion recommendation: `{recommendation}`; analysis readiness conclusion = `{conclusion}`. Source: `_analysis/review_packet.json`.".format(
            recommendation=decision.get("formal_discussion_recommendation"),
            conclusion=review_packet.get("analysis_readiness_conclusion"),
        )
    )
    lines.append(
        "- Promotion-gap report records smallest remaining gap `{gap}` with blocking issues `{blocking}` and non-blocking issues `{non_blocking}`. Source: `_analysis/promotion_gap_report.json`.".format(
            gap=promotion_gap_report.get("smallest_remaining_gap"),
            blocking=promotion_gap_report.get("blocking_issue_count"),
            non_blocking=promotion_gap_report.get("non_blocking_issue_count"),
        )
    )



def render_benchmark_summary_from_facts(
    facts: dict[str, Any],
    *,
    grouped_json_path: Path,
    analysis_bundle: dict[str, Any] | None = None,
) -> str:
    lines = [
        "# Benchmark Summary",
        "",
        f"Matrix manifest: `{facts.get('matrix_manifest') or grouped_json_path}`",
        f"Grouped source: `{grouped_json_path.resolve()}`",
        "",
        "## Task Leaders",
        "",
    ]

    task_leaders = facts.get("task_leaders") or []
    if not task_leaders:
        lines.append("- No grouped task leaders with benchmark metrics were available.")
    else:
        for leader in task_leaders:
            lines.append(
                "- {task}: `{run_id}` ({model}, {protocol}; task_mode={task_mode}; model_mode={model_mode}; evaluation_mode={evaluation_mode}) with mean Relative L2 `{rel:.6g}` and mean MSE `{mse:.6g}`.".format(
                    task=leader["task_name"],
                    run_id=leader["run_id"],
                    model=leader["model_name"],
                    protocol=leader["protocol_label"],
                    task_mode=leader["task_mode"],
                    model_mode=leader["model_mode"],
                    evaluation_mode=leader["evaluation_mode"],
                    rel=leader["eval_relative_l2_mean"] or float("nan"),
                    mse=leader["eval_mse_mean"] or float("nan"),
                )
            )

    lines.extend(["", "## Clean Leaders", ""])
    clean_task_leaders = facts.get("clean_task_leaders") or []
    if not clean_task_leaders:
        lines.append("- No clean grouped rows with benchmark metrics were available.")
    else:
        for leader in clean_task_leaders:
            lines.append(
                "- {task}: `{run_id}` ({model}, {protocol}) with mean Relative L2 `{rel:.6g}` and mean MSE `{mse:.6g}`.".format(
                    task=leader["task_name"],
                    run_id=leader["run_id"],
                    model=leader["model_name"],
                    protocol=leader["protocol_label"],
                    rel=leader["eval_relative_l2_mean"] or float("nan"),
                    mse=leader["eval_mse_mean"] or float("nan"),
                )
            )

    operator_rows = facts.get("operator_preview_rows") or []
    lines.extend(["", "## Preview Theme", ""])
    if analysis_bundle is not None:
        lines.append("- Current preview theme: benchmark intelligence, comparative analysis, diagnostics, and decision support over the frozen `v0.6` benchmark slice.")
        lines.append("- This preview intentionally keeps benchmark content fixed and widens only the interpretation layer under `_analysis/`.")
        lines.append("- Analysis-backed preview conclusions remain preview-only and should not be mistaken for a new frozen benchmark line.")
    elif operator_rows or "v0_6_preview" in str(facts.get("matrix_name") or ""):
        lines.append("- Current preview theme: operator-ready compatibility for field-output models beside the pointwise benchmark core.")
        lines.append("- This preview keeps pointwise families visible while validating a mixed pointwise + field slice.")
        lines.append("- Operator rows remain preview-only and do not imply a formal operator benchmark or FNO/DeepONet maturity claim.")
    elif "v0_5_preview" in str(facts.get("matrix_name") or ""):
        lines.append("- Current preview theme: submission standard + external integration + benchmark packaging.")
        lines.append("- Bundle workflow is available through `package-run`, `validate-submission`, `compare-bundle`, and `import-bundle`.")
    else:
        lines.append("- Preview/theme note: standard grouped benchmark reporting flow.")

    pointwise_leaders = [leader for leader in clean_task_leaders if leader.get("task_mode") == "pointwise"]
    lines.extend(["", "## Pointwise Slice", ""])
    if not pointwise_leaders:
        lines.append("- No pointwise clean grouped leaders were available.")
    else:
        for leader in pointwise_leaders:
            lines.append(
                "- {task}: `{run_id}` ({model}, {protocol}) keeps task_mode=`{task_mode}`, model_mode=`{model_mode}`, evaluation_mode=`{evaluation_mode}`.".format(
                    task=leader["task_name"],
                    run_id=leader["run_id"],
                    model=leader["model_name"],
                    protocol=leader["protocol_label"],
                    task_mode=leader["task_mode"],
                    model_mode=leader["model_mode"],
                    evaluation_mode=leader["evaluation_mode"],
                )
            )

    lines.extend(["", "## Operator Preview Slice", ""])
    if not operator_rows:
        lines.append("- No operator-preview grouped rows were present in this grouped payload.")
    else:
        lines.append("- This section groups preview operator breadth by task, then baseline, while keeping protocol support explicit.")
        for task_name, model_groups in _group_operator_preview_rows(operator_rows).items():
            lines.extend(["", f"### {task_name}"])
            for model_name, protocol_labels in model_groups.items():
                rendered_protocols = ", ".join(protocol_labels)
                lines.append(
                    f"- `{model_name}`: {rendered_protocols} (task_mode=`field`, model_mode=`field`, evaluation_mode=`field`)."
                )

    worst = facts.get("worst_protocol_degradation")
    lines.extend(["", "## Robustness Notes", ""])
    if worst is None:
        lines.append("- No protocol degradation comparison against standard grouped rows was available.")
    else:
        lines.append(
            "- Largest relative degradation versus standard: `{run_id}` on `{task}` ({protocol}) at `{ratio:.3f}x` the standard mean Relative L2 for the same task/model pair.".format(
                run_id=worst["run_id"],
                task=worst["task_name"],
                protocol=worst["protocol_label"],
                ratio=worst["ratio"],
            )
        )

    stable = facts.get("most_stable_family")
    if stable is None:
        lines.append("- Robustness stability leader: unavailable because no degradation ratios were computed.")
    else:
        lines.append(
            "- Robustness stability leader: `{run_id}` on `{task_name}` with mean degradation ratio `{mean_degradation_ratio:.3f}` across available non-standard protocols.".format(
                **stable
            )
        )

    widest_gap = facts.get("widest_gap_protocol")
    if widest_gap is None:
        lines.append("- No protocol-level gap comparison was available.")
    else:
        lines.append(
            "- Protocol that opens the widest relative gap: `{protocol}` with mean degradation ratio `{mean_degradation_ratio:.3f}`.".format(
                **widest_gap
            )
        )

    lines.extend(["", "## Bundle Compare Path", ""])
    lines.append("- Package reference runs with `pinn-bench package-run <run_dir> --output-dir <bundle_dir>`.")
    lines.append("- Validate bundles with `pinn-bench validate-submission <bundle_dir>`.")
    lines.append("- Compare official or external bundles against grouped results with `pinn-bench compare-bundle <bundle_dir> --against <grouped_json>`.")
    lines.append("- Export reusable local comparison artifacts with `pinn-bench import-bundle <bundle_dir> --against <grouped_json> --output-dir <dir>`.")

    lightest = facts.get("lightest_family")
    lines.extend(["", "## Efficiency Notes", ""])
    if lightest is None:
        lines.append("- No grouped rows with efficiency metadata were available.")
    else:
        lines.append(
            "- Lightest grouped family: `{run_id}` with parameter count `{params}` and mean train duration `{duration:.6g}` seconds.".format(
                run_id=lightest["run_id"],
                params=lightest["parameter_count"] or "unknown",
                duration=lightest["train_duration_seconds_mean"] or float("nan"),
            )
        )

    incomplete_count = int(facts.get("incomplete_family_count", 0) or 0)
    incomplete_ids = list(facts.get("incomplete_run_ids") or [])
    lines.extend(["", "## Coverage Notes", ""])
    if incomplete_count:
        preview = ", ".join(str(item) for item in incomplete_ids[:5])
        lines.append(f"- Incomplete or partially populated grouped families: {incomplete_count} ({preview}).")
    else:
        lines.append("- All grouped rows appear complete for their expected seed counts.")

    warning_count = int(facts.get("grouped_warning_count", 0) or 0)
    lines.append(f"- Upstream grouped warnings: {warning_count}.")

    if analysis_bundle is not None:
        _append_analysis_sections(lines, analysis_bundle)

    lines.extend(["", f"Generated narrative summary for `{facts.get('matrix_name', 'grouped_results')}`.", ""])
    return "\n".join(lines)



def render_benchmark_summary(payload: dict[str, Any], *, grouped_json_path: Path, analysis_bundle: dict[str, Any] | None = None) -> str:
    return render_benchmark_summary_from_facts(build_summary_facts(payload), grouped_json_path=grouped_json_path, analysis_bundle=analysis_bundle)



def export_benchmark_summary(grouped_json_path: Path, output_file: Path | None = None, analysis_dir: Path | None = None) -> Path:
    payload = _load_grouped_payload(grouped_json_path)
    analysis_bundle = _load_analysis_bundle(analysis_dir)
    destination = grouped_json_path.parent / "benchmark_summary.md" if output_file is None else output_file
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(render_benchmark_summary(payload, grouped_json_path=grouped_json_path, analysis_bundle=analysis_bundle), encoding="utf-8")
    return destination



def main(argv: Sequence[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    grouped_json_path = Path(args.grouped_json)
    output_file = None if args.output_file is None else Path(args.output_file)
    analysis_dir = None if args.analysis_dir is None else Path(args.analysis_dir)
    destination = export_benchmark_summary(grouped_json_path=grouped_json_path, output_file=output_file, analysis_dir=analysis_dir)
    print(f"Benchmark summary written to {destination.resolve()}")


if __name__ == "__main__":
    main()
