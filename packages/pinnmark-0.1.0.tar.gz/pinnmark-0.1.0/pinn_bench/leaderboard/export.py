"""Export aggregated leaderboard assets."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from pinn_bench.leaderboard.aggregate import (
    GROUPED_SCHEMA_VERSION,
    SCHEMA_VERSION,
    build_grouped_rows,
    build_grouped_summary_groups,
    collect_grouped_summary_rows,
    collect_leaderboard_rows,
)
from pinn_bench.utils.io import write_csv, write_json

PER_RUN_MARKDOWN_COLUMNS = [
    ("Run", "run_name"),
    ("Model", "model_name"),
    ("Protocol", "protocol"),
    ("Setting", "protocol_setting"),
    ("Seed", "seed"),
    ("MSE", "eval_mse"),
    ("Relative L2", "eval_relative_l2"),
]
GROUPED_MARKDOWN_COLUMNS = [
    ("Run", "run_id"),
    ("Model", "model_name"),
    ("Protocol", "protocol"),
    ("Setting", "protocol_setting"),
    ("Count", "run_count"),
    ("Seeds", "seed_status"),
    ("MSE mean±std", "eval_mse_summary"),
    ("Relative L2 mean±std", "eval_relative_l2_summary"),
]



def _format_markdown_value(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float):
        return f"{value:.6g}"
    return str(value)



def _build_markdown(
    groups: dict[str, list[dict[str, Any]]],
    *,
    results_dir: Path,
    warnings: list[str],
    columns: list[tuple[str, str]],
) -> str:
    lines = [
        "# Leaderboard",
        "",
        f"Generated from `{results_dir.resolve()}`.",
        "",
    ]
    if warnings:
        lines.extend([
            "## Warnings",
            "",
            *[f"- {warning}" for warning in warnings],
            "",
        ])

    for task_name, rows in groups.items():
        lines.extend([
            f"## {task_name}",
            "",
            "| " + " | ".join(header for header, _ in columns) + " |",
            "| " + " | ".join("---" for _ in columns) + " |",
        ])
        for row in rows:
            lines.append("| " + " | ".join(_format_markdown_value(row.get(key)) for _, key in columns) + " |")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"



def _prepare_per_run_markdown_groups(groups: dict[str, list[dict[str, Any]]]) -> dict[str, list[dict[str, Any]]]:
    prepared: dict[str, list[dict[str, Any]]] = {}
    for task_name, rows in groups.items():
        prepared_rows: list[dict[str, Any]] = []
        for row in rows:
            prepared_row = dict(row)
            prepared_row["run_name"] = Path(str(row.get("output_dir", ""))).name
            prepared_rows.append(prepared_row)
        prepared[task_name] = prepared_rows
    return prepared



def _format_grouped_seed_status(row: dict[str, Any]) -> str:
    found = str(row.get("found_seeds") or "")
    missing = str(row.get("missing_seeds") or "")
    if found and missing:
        return f"{found} (missing: {missing})"
    if missing:
        return f"missing: {missing}"
    return found



def _format_grouped_metric_summary(row: dict[str, Any], *, prefix: str) -> str:
    mean = row.get(f"{prefix}_mean")
    std = row.get(f"{prefix}_std")
    if mean is None or std is None:
        return ""
    return f"{float(mean):.6g} ± {float(std):.6g}"



def _prepare_grouped_markdown_groups(groups: dict[str, list[dict[str, Any]]]) -> dict[str, list[dict[str, Any]]]:
    prepared: dict[str, list[dict[str, Any]]] = {}
    for task_name, rows in groups.items():
        prepared_rows: list[dict[str, Any]] = []
        for row in rows:
            prepared_row = dict(row)
            prepared_row["seed_status"] = _format_grouped_seed_status(prepared_row)
            prepared_row["eval_mse_summary"] = _format_grouped_metric_summary(prepared_row, prefix="eval_mse")
            prepared_row["eval_relative_l2_summary"] = _format_grouped_metric_summary(prepared_row, prefix="eval_relative_l2")
            prepared_rows.append(prepared_row)
        prepared[task_name] = prepared_rows
    return prepared



def export_grouped_results(results_dir: Path, output_dir: Path, matrix_manifest: Path) -> dict[str, Any]:
    manifest, columns, rows, warnings = collect_grouped_summary_rows(
        results_dir=results_dir,
        matrix_manifest_path=matrix_manifest,
    )
    groups = build_grouped_summary_groups(rows)

    write_csv(path=output_dir / "grouped_summary.csv", rows=rows, fieldnames=columns)
    payload: dict[str, Any] = {
        "schema_version": GROUPED_SCHEMA_VERSION,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "results_dir": str(results_dir.resolve()),
        "matrix_manifest": str(Path(matrix_manifest).resolve()),
        "default_seeds": list(manifest["default_seeds"]),
        "columns": columns,
        "rows": rows,
        "groups": groups,
        "warnings": warnings,
        "fair_budget_summary": dict(manifest.get("fair_budget_summary", {})),
        "fair_budget_groups": list(manifest.get("fair_budget_groups", [])),
        "regime_summary": dict(manifest.get("regime_summary", {})),
        "regime_groups": list(manifest.get("regime_groups", [])),
    }
    write_json(path=output_dir / "leaderboard_grouped.json", payload=payload)
    (output_dir / "leaderboard_grouped.md").write_text(
        _build_markdown(
            groups=_prepare_grouped_markdown_groups(groups),
            results_dir=results_dir,
            warnings=warnings,
            columns=GROUPED_MARKDOWN_COLUMNS,
        ),
        encoding="utf-8",
    )
    return payload



def export_results(results_dir: Path, output_dir: Path, matrix_manifest: Path | None = None) -> dict[str, Any]:
    """Aggregate run-level metrics and write leaderboard assets."""
    if not results_dir.exists():
        raise FileNotFoundError(f"Results directory does not exist: {results_dir}")

    output_dir.mkdir(parents=True, exist_ok=True)
    columns, rows, warnings = collect_leaderboard_rows(results_dir=results_dir, output_dir=output_dir)
    groups = build_grouped_rows(rows)

    write_csv(path=output_dir / "summary.csv", rows=rows, fieldnames=columns)
    payload: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "results_dir": str(results_dir.resolve()),
        "columns": columns,
        "rows": rows,
        "groups": groups,
        "warnings": warnings,
    }
    write_json(path=output_dir / "leaderboard.json", payload=payload)
    (output_dir / "leaderboard.md").write_text(
        _build_markdown(
            groups=_prepare_per_run_markdown_groups(groups),
            results_dir=results_dir,
            warnings=warnings,
            columns=PER_RUN_MARKDOWN_COLUMNS,
        ),
        encoding="utf-8",
    )

    if matrix_manifest is not None:
        export_grouped_results(results_dir=results_dir, output_dir=output_dir, matrix_manifest=matrix_manifest)
    return payload
