"""Command-line entrypoint for leaderboard export."""

from __future__ import annotations

import argparse
from collections.abc import Sequence
from pathlib import Path

from pinn_bench.leaderboard.export import export_results
from pinn_bench.resources import resolve_manifest_path, resolve_outputs_root



def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Aggregate PINN benchmark runs into leaderboard artifacts.")
    parser.add_argument(
        "--results-dir",
        type=str,
        default="outputs",
        help="Directory containing run outputs with metrics.json files.",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default="outputs/_leaderboard",
        help="Directory where leaderboard artifacts will be written.",
    )
    parser.add_argument(
        "--matrix-manifest",
        type=str,
        default=None,
        help="Optional baseline matrix manifest for grouped multi-seed summary export.",
    )
    return parser



def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    return build_parser().parse_args(argv)



def main(argv: Sequence[str] | None = None) -> None:
    args = parse_args(argv)
    results_dir = resolve_outputs_root(args.results_dir)
    output_dir = resolve_outputs_root(args.output_dir)
    manifest = None if args.matrix_manifest is None else resolve_manifest_path(args.matrix_manifest)

    payload = export_results(results_dir=results_dir, output_dir=output_dir, matrix_manifest=manifest)
    print(f"Leaderboard artifacts written to {output_dir.resolve()}")
    print(f"Aggregated {len(payload['rows'])} per-run rows with {len(payload['warnings'])} warning(s).")
    if manifest is not None:
        print("Grouped baseline summary artifacts written alongside the per-run leaderboard outputs.")


if __name__ == "__main__":
    main()
