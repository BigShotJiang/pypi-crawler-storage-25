"""Internal robustness summary exporter for grouped benchmark results."""

from __future__ import annotations

import json
from collections.abc import Mapping
from pathlib import Path
from statistics import fmean
from typing import Any

from pinn_bench.leaderboard.reporting import load_grouped_payload
from pinn_bench.utils.io import write_json


PROTOCOL_COLUMNS = ["noise", "sparsity", "support_extrapolation", "bcic_corruption"]


def _normalize_protocol_name(protocol: str) -> str:
    normalized = str(protocol).strip().lower()
    if normalized == "extrapolation":
        return "support_extrapolation"
    return normalized


def _display_protocol_name(protocol: str) -> str:
    if protocol == "support_extrapolation":
        return "extrapolation"
    return protocol


def _protocol_ratio(row: Mapping[str, Any], protocol: str) -> float | None:
    value = row.get(f"{protocol}_degradation_ratio")
    if value is None and protocol == "support_extrapolation":
        value = row.get("extrapolation_degradation_ratio")
    if value is None:
        value = row.get("degradation_ratio_vs_standard") if _normalize_protocol_name(str(row.get("protocol"))) == protocol else None
    return None if value is None else float(value)


def build_robustness_summary_rows(payload: Mapping[str, Any]) -> list[dict[str, Any]]:
    rows = payload.get("rows") if isinstance(payload.get("rows"), list) else []
    standard_rows: dict[tuple[str, str], Mapping[str, Any]] = {}
    output_rows: list[dict[str, Any]] = []

    for row in rows:
        if not isinstance(row, Mapping):
            continue
        if str(row.get("protocol")) == "none":
            standard_rows[(str(row.get("task_name")), str(row.get("model_name")))] = row

    for (task_name, model_name), standard in sorted(standard_rows.items()):
        protocol_ratios: dict[str, float | None] = {protocol: None for protocol in PROTOCOL_COLUMNS}
        for row in rows:
            if not isinstance(row, Mapping):
                continue
            if str(row.get("task_name")) != task_name or str(row.get("model_name")) != model_name:
                continue
            protocol = _normalize_protocol_name(str(row.get("protocol")))
            if protocol in PROTOCOL_COLUMNS:
                protocol_ratios[protocol] = _protocol_ratio(row, protocol)

        available = {protocol: ratio for protocol, ratio in protocol_ratios.items() if ratio is not None}
        missing = [_display_protocol_name(protocol) for protocol, ratio in protocol_ratios.items() if ratio is None]
        best_protocol_note = None
        worst_protocol_note = None
        average_degradation_ratio = None
        if available:
            best_protocol, best_value = min(available.items(), key=lambda item: item[1])
            worst_protocol, worst_value = max(available.items(), key=lambda item: item[1])
            best_protocol_note = f"{_display_protocol_name(best_protocol)} ({best_value:.3f}x)"
            worst_protocol_note = f"{_display_protocol_name(worst_protocol)} ({worst_value:.3f}x)"
            average_degradation_ratio = round(fmean(available.values()), 6)

        output_rows.append(
            {
                "task_name": task_name,
                "model_name": model_name,
                "standard_relative_l2": standard.get("eval_relative_l2_mean"),
                "noise_degradation_ratio": protocol_ratios["noise"],
                "sparsity_degradation_ratio": protocol_ratios["sparsity"],
                "support_extrapolation_degradation_ratio": protocol_ratios["support_extrapolation"],
                "extrapolation_degradation_ratio": protocol_ratios["support_extrapolation"],
                "bcic_corruption_degradation_ratio": protocol_ratios["bcic_corruption"],
                "protocol_coverage_count": len(available),
                "average_degradation_ratio": average_degradation_ratio,
                "best_protocol_note": best_protocol_note,
                "worst_protocol_note": worst_protocol_note,
                "missing_protocols": missing,
            }
        )
    return output_rows


def render_robustness_summary_markdown(*, rows: list[dict[str, Any]], grouped_json_path: Path) -> str:
    lines = [
        "# Robustness Summary",
        "",
        f"Grouped source: `{grouped_json_path.resolve()}`",
        "",
        "| Task | Model | Standard Relative L2 | Noise Ratio | Sparsity Ratio | Support Extrapolation Ratio | BC/IC Corruption Ratio | Coverage | Average Ratio | Best Protocol | Worst Protocol | Missing Protocols |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for row in rows:
        rendered = {key: (", ".join(value) if isinstance(value, list) else ("" if value is None else value)) for key, value in row.items()}
        lines.append(
            "| {task_name} | {model_name} | {standard_relative_l2} | {noise_degradation_ratio} | {sparsity_degradation_ratio} | {support_extrapolation_degradation_ratio} | {bcic_corruption_degradation_ratio} | {protocol_coverage_count} | {average_degradation_ratio} | {best_protocol_note} | {worst_protocol_note} | {missing_protocols} |".format(
                **rendered
            )
        )
    lines.append("")
    return "\n".join(lines)


def export_robustness_summary(*, grouped_json_path: Path, output_dir: Path | None = None) -> dict[str, str | int]:
    payload = load_grouped_payload(grouped_json_path)
    rows = build_robustness_summary_rows(payload)
    destination_dir = grouped_json_path.parent if output_dir is None else output_dir.resolve()
    destination_dir.mkdir(parents=True, exist_ok=True)
    json_path = destination_dir / "robustness_summary.json"
    md_path = destination_dir / "robustness_summary.md"
    write_json(json_path, {"grouped_json": str(grouped_json_path.resolve()), "rows": rows})
    md_path.write_text(render_robustness_summary_markdown(rows=rows, grouped_json_path=grouped_json_path), encoding="utf-8")
    return {"json_path": str(json_path.resolve()), "md_path": str(md_path.resolve()), "row_count": len(rows)}


def load_robustness_summary(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        raise ValueError(f"Robustness summary must contain a JSON mapping: {path}")
    return dict(payload)
