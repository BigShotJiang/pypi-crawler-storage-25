"""Pareto-friendly exports for grouped baseline results."""

from __future__ import annotations

import argparse
import json
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

from pinn_bench.leaderboard.reporting import derive_matrix_name, load_grouped_payload
from pinn_bench.utils.io import write_csv

PARETO_COLUMNS = [
    "task_name",
    "task_mode",
    "model_name",
    "model_mode",
    "evaluation_mode",
    "protocol",
    "setting",
    "mean_relative_l2",
    "mean_mse",
    "parameter_count",
    "train_duration_seconds",
]
ACCURACY_COST_COLUMNS = [
    "matched_budget_group_id",
    "task_name",
    "baseline_family",
    "model_or_reference",
    "protocol",
    "comparison_scope",
    "data_budget_class",
    "compute_budget_class",
    "tuning_budget_class",
    "metric_name",
    "metric_value",
    "parameter_count",
    "train_duration_seconds",
    "source_kind",
]


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Export Pareto-friendly grouped baseline assets.")
    parser.add_argument(
        "--grouped-json",
        required=True,
        type=str,
        help="Path to leaderboard_grouped.json produced by the grouped leaderboard export.",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default=None,
        help="Directory for Pareto-friendly exports. Defaults to <grouped-json-dir>/pareto.",
    )
    return parser



def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    return build_parser().parse_args(argv)



def _display_protocol(protocol: str) -> str:
    return "standard" if protocol == "none" else protocol



def _display_mode(value: Any) -> str:
    text = str(value or "pointwise").strip()
    return text or "pointwise"



def _mode_sort_bucket(*, task_mode: Any, model_mode: Any, evaluation_mode: Any) -> int:
    modes = {_display_mode(task_mode), _display_mode(model_mode), _display_mode(evaluation_mode)}
    return 1 if "field" in modes else 0



def _protocol_sort_bucket(protocol: Any) -> tuple[int, str]:
    text = str(protocol or "").strip().lower()
    order = {
        "standard": 0,
        "none": 0,
        "noise": 1,
        "sparsity": 2,
        "extrapolation": 3,
    }
    return order.get(text, 99), text



def _format_float(value: Any) -> str:
    if value is None:
        return ""
    return f"{float(value):.6g}"



def _sort_key(row: dict[str, Any]) -> tuple[Any, Any, Any, Any, Any, Any]:
    return (
        _mode_sort_bucket(
            task_mode=row.get("task_mode"),
            model_mode=row.get("model_mode"),
            evaluation_mode=row.get("evaluation_mode"),
        ),
        str(row.get("task_name", "")),
        str(row.get("model_name", "")),
        *_protocol_sort_bucket(row.get("protocol")),
        str(row.get("setting", "")),
    )


def _fair_budget_groups(payload: Mapping[str, Any]) -> list[dict[str, Any]]:
    groups = payload.get("fair_budget_groups")
    if not isinstance(groups, list):
        return []
    return [dict(group) for group in groups if isinstance(group, Mapping)]



def build_pareto_rows(payload: Mapping[str, Any]) -> tuple[list[dict[str, Any]], list[str]]:
    source_rows = payload.get("rows", [])
    pareto_rows: list[dict[str, Any]] = []
    omitted_families: list[str] = []
    for row in source_rows:
        if not isinstance(row, Mapping):
            continue
        run_count = int(row.get("run_count", 0) or 0)
        if run_count <= 0:
            omitted_families.append(str(row.get("run_id", "")))
            continue
        pareto_rows.append(
            {
                "task_name": str(row.get("task_name", "")),
                "task_mode": _display_mode(row.get("task_mode")),
                "model_name": str(row.get("model_name", "")),
                "model_mode": _display_mode(row.get("model_mode")),
                "evaluation_mode": _display_mode(row.get("evaluation_mode")),
                "protocol": _display_protocol(str(row.get("protocol", ""))),
                "setting": str(row.get("protocol_setting", "")),
                "mean_relative_l2": row.get("eval_relative_l2_mean"),
                "mean_mse": row.get("eval_mse_mean"),
                "parameter_count": row.get("parameter_count"),
                "train_duration_seconds": row.get("train_duration_seconds_mean"),
            }
        )
    return sorted(pareto_rows, key=_sort_key), sorted(name for name in omitted_families if name)


def build_accuracy_cost_pareto_rows(payload: Mapping[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for group in _fair_budget_groups(payload):
        for entry in group.get("rows", []):
            if not isinstance(entry, Mapping):
                continue
            rows.append(
                {
                    "matched_budget_group_id": group.get("matched_budget_group_id"),
                    "task_name": group.get("task_name"),
                    "baseline_family": entry.get("baseline_family"),
                    "model_or_reference": entry.get("model_name"),
                    "protocol": entry.get("protocol"),
                    "comparison_scope": group.get("comparison_scope"),
                    "data_budget_class": group.get("data_budget_class"),
                    "compute_budget_class": group.get("compute_budget_class"),
                    "tuning_budget_class": group.get("tuning_budget_class"),
                    "metric_name": entry.get("metric_name"),
                    "metric_value": entry.get("metric_value"),
                    "parameter_count": entry.get("parameter_count"),
                    "train_duration_seconds": entry.get("train_duration_seconds"),
                    "source_kind": entry.get("source_kind"),
                }
            )
    return sorted(
        rows,
        key=lambda row: (
            str(row.get("task_name", "")),
            str(row.get("baseline_family", "")),
            str(row.get("model_or_reference", "")),
            float(row.get("metric_value")) if row.get("metric_value") not in {None, ""} else float("inf"),
        ),
    )



def build_markdown_report(
    *,
    grouped_json_path: Path,
    payload: Mapping[str, Any],
    rows: list[dict[str, Any]],
    omitted_families: list[str],
) -> str:
    warnings = [str(item) for item in payload.get("warnings", [])]
    lines = [
        "# Pareto-Friendly Baseline Export",
        "",
        f"Grouped source: `{grouped_json_path.resolve()}`",
        f"Matrix manifest: `{payload['matrix_manifest']}`",
        "",
    ]
    if omitted_families:
        lines.extend([
            "## Omitted Incomplete Families",
            "",
            *[f"- {family}" for family in omitted_families],
            "",
        ])
    if warnings:
        lines.extend([
            "## Upstream Grouped Warnings",
            "",
            *[f"- {warning}" for warning in warnings],
            "",
        ])
    lines.extend(
        [
            "| " + " | ".join(PARETO_COLUMNS) + " |",
            "| " + " | ".join("---" for _ in PARETO_COLUMNS) + " |",
        ]
    )
    for row in rows:
        rendered = []
        for column in PARETO_COLUMNS:
            value = row.get(column)
            if column in {"mean_relative_l2", "mean_mse", "train_duration_seconds"}:
                rendered.append(_format_float(value))
            else:
                rendered.append("" if value is None else str(value))
        lines.append("| " + " | ".join(rendered) + " |")
    lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def build_accuracy_cost_markdown_report(*, grouped_json_path: Path, payload: Mapping[str, Any], rows: list[dict[str, Any]]) -> str:
    lines = [
        "# Accuracy-vs-Cost Pareto Export",
        "",
        f"Grouped source: `{grouped_json_path.resolve()}`",
        f"Matrix manifest: `{payload['matrix_manifest']}`",
        "",
    ]
    lines.extend(
        [
            "| " + " | ".join(ACCURACY_COST_COLUMNS) + " |",
            "| " + " | ".join("---" for _ in ACCURACY_COST_COLUMNS) + " |",
        ]
    )
    for row in rows:
        rendered: list[str] = []
        for column in ACCURACY_COST_COLUMNS:
            value = row.get(column)
            if column in {"metric_value", "train_duration_seconds"}:
                rendered.append(_format_float(value))
            else:
                rendered.append("" if value is None else str(value))
        lines.append("| " + " | ".join(rendered) + " |")
    lines.append("")
    return "\n".join(lines).rstrip() + "\n"



def export_pareto_tables(grouped_json_path: Path, output_dir: Path | None = None) -> dict[str, Any]:
    payload = load_grouped_payload(grouped_json_path)
    matrix_name = derive_matrix_name(payload)
    resolved_output_dir = grouped_json_path.parent / 'pareto' if output_dir is None else Path(output_dir)
    resolved_output_dir.mkdir(parents=True, exist_ok=True)

    rows, omitted_families = build_pareto_rows(payload)
    accuracy_cost_rows = build_accuracy_cost_pareto_rows(payload)
    csv_path = resolved_output_dir / f"{matrix_name}_pareto.csv"
    markdown_path = resolved_output_dir / f"{matrix_name}_pareto.md"
    accuracy_cost_csv_path = resolved_output_dir / f"{matrix_name}_accuracy_cost_pareto.csv"
    accuracy_cost_markdown_path = resolved_output_dir / f"{matrix_name}_accuracy_cost_pareto.md"

    write_csv(path=csv_path, rows=rows, fieldnames=PARETO_COLUMNS)
    write_csv(path=accuracy_cost_csv_path, rows=accuracy_cost_rows, fieldnames=ACCURACY_COST_COLUMNS)
    markdown_path.write_text(
        build_markdown_report(
            grouped_json_path=grouped_json_path,
            payload=payload,
            rows=rows,
            omitted_families=omitted_families,
        ),
        encoding='utf-8',
    )
    accuracy_cost_markdown_path.write_text(
        build_accuracy_cost_markdown_report(
            grouped_json_path=grouped_json_path,
            payload=payload,
            rows=accuracy_cost_rows,
        ),
        encoding='utf-8',
    )
    return {
        'matrix_name': matrix_name,
        'row_count': len(rows),
        'accuracy_cost_row_count': len(accuracy_cost_rows),
        'csv_path': str(csv_path.resolve()),
        'markdown_path': str(markdown_path.resolve()),
        'accuracy_cost_csv_path': str(accuracy_cost_csv_path.resolve()),
        'accuracy_cost_markdown_path': str(accuracy_cost_markdown_path.resolve()),
    }



def main(argv: Sequence[str] | None = None) -> None:
    args = parse_args(argv)
    grouped_json_path = Path(args.grouped_json)
    output_dir = None if args.output_dir is None else Path(args.output_dir)
    result = export_pareto_tables(grouped_json_path=grouped_json_path, output_dir=output_dir)
    print(f"Pareto exports written to {Path(result['csv_path']).parent}")
    print(f"Exported {result['row_count']} Pareto rows for {result['matrix_name']}")


if __name__ == '__main__':
    main()
