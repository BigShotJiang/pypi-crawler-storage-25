"""Release audit tooling for formal and preview benchmark lines."""

from __future__ import annotations

import argparse
import json
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from pinn_bench.analysis.normalize import list_history_entries
from pinn_bench.doctor import FORMAL_MODE, PREVIEW_MODE, STARTER_MODE, build_doctor_payload
from pinn_bench.experiments.snapshot_assets import count_csv_rows, load_json_file
from pinn_bench.leaderboard.summary import build_summary_facts
from pinn_bench.regime import summarize_regime_governance
from pinn_bench.resources import resolve_manifest_path, resolve_outputs_root, resolve_repo_root
from pinn_bench.utils.io import write_json
from pinn_bench.version import build_version_payload

READY_FOR_FREEZE = "ready_for_freeze"
READY_FOR_PREVIEW_ONLY = "ready_for_preview_only"
READY_FOR_STARTER_ONLY = "ready_for_starter_only"
INCOMPLETE = "incomplete"


@dataclass(frozen=True)
class AuditLineSpec:
    profile: str
    benchmark_line: str
    report_basename: str
    manifest_name: str | None
    default_outputs_root: str
    required_runbook: str | None
    required_release_doc: str | None
    required_preview_doc: str | None
    required_product_doc: str | None
    required_starter_doc: str | None = None


FORMAL_V02 = AuditLineSpec(
    profile=FORMAL_MODE,
    benchmark_line="v0.2",
    report_basename="baseline_v0_2",
    manifest_name="baseline_v0_2.yaml",
    default_outputs_root="outputs_v02",
    required_runbook="docs/experiments/v0_2_runbook.md",
    required_release_doc="docs/experiments/v0_2_release.md",
    required_preview_doc=None,
    required_product_doc="docs/product/index.md",
)

FORMAL_V03 = AuditLineSpec(
    profile=FORMAL_MODE,
    benchmark_line="v0.3",
    report_basename="baseline_v0_3",
    manifest_name="baseline_v0_3.yaml",
    default_outputs_root="outputs_v03",
    required_runbook="docs/experiments/v0_3_runbook.md",
    required_release_doc="docs/experiments/v0_3_release.md",
    required_preview_doc=None,
    required_product_doc="docs/product/index.md",
)

FORMAL_V04 = AuditLineSpec(
    profile=FORMAL_MODE,
    benchmark_line="v0.4",
    report_basename="baseline_v0_4",
    manifest_name="baseline_v0_4.yaml",
    default_outputs_root="outputs_v04",
    required_runbook="docs/experiments/v0_4_runbook.md",
    required_release_doc="docs/experiments/v0_4_release.md",
    required_preview_doc=None,
    required_product_doc="docs/product/index.md",
)

FORMAL_V05 = AuditLineSpec(
    profile=FORMAL_MODE,
    benchmark_line="v0.5",
    report_basename="baseline_v0_5",
    manifest_name="baseline_v0_5.yaml",
    default_outputs_root="outputs_v05",
    required_runbook="docs/experiments/v0_5_runbook.md",
    required_release_doc="docs/experiments/v0_5_release.md",
    required_preview_doc=None,
    required_product_doc="docs/product/index.md",
)

FORMAL_V06 = AuditLineSpec(
    profile=FORMAL_MODE,
    benchmark_line="v0.6",
    report_basename="baseline_v0_6",
    manifest_name="baseline_v0_6.yaml",
    default_outputs_root="outputs_v06",
    required_runbook="docs/experiments/v0_6_runbook.md",
    required_release_doc="docs/experiments/v0_6_release.md",
    required_preview_doc=None,
    required_product_doc="docs/product/index.md",
)

FORMAL_V10 = AuditLineSpec(
    profile=FORMAL_MODE,
    benchmark_line="v1.0",
    report_basename="baseline_v1_0_formal",
    manifest_name="baseline_v1_0_formal.yaml",
    default_outputs_root="outputs_v10",
    required_runbook="docs/product/v1_0_freeze_complete.md",
    required_release_doc="docs/product/v1_0_freeze_decision.md",
    required_preview_doc=None,
    required_product_doc="docs/product/index.md",
)

PREVIEW_V03 = AuditLineSpec(
    profile=PREVIEW_MODE,
    benchmark_line="v0.3-preview",
    report_basename="v0_3_preview",
    manifest_name=None,
    default_outputs_root="outputs_preview_v03",
    required_runbook=None,
    required_release_doc=None,
    required_preview_doc="docs/experiments/v0_3_preview.md",
    required_product_doc="docs/product/index.md",
)

PREVIEW_V04 = AuditLineSpec(
    profile=PREVIEW_MODE,
    benchmark_line="v0.4-preview",
    report_basename="v0_4_preview",
    manifest_name="baseline_v0_4_preview.yaml",
    default_outputs_root="outputs_preview_v04",
    required_runbook=None,
    required_release_doc=None,
    required_preview_doc="docs/experiments/v0_4_preview.md",
    required_product_doc="docs/product/index.md",
)

PREVIEW_V05 = AuditLineSpec(
    profile=PREVIEW_MODE,
    benchmark_line="v0.5-preview",
    report_basename="v0_5_preview",
    manifest_name="baseline_v0_5_preview.yaml",
    default_outputs_root="outputs_preview_v05",
    required_runbook=None,
    required_release_doc=None,
    required_preview_doc="docs/experiments/v0_5_preview.md",
    required_product_doc="docs/product/index.md",
)

PREVIEW_V06 = AuditLineSpec(
    profile=PREVIEW_MODE,
    benchmark_line="v0.6-preview",
    report_basename="v0_6_preview",
    manifest_name="baseline_v0_6_preview.yaml",
    default_outputs_root="outputs_preview_v06",
    required_runbook=None,
    required_release_doc=None,
    required_preview_doc="docs/experiments/v0_6_preview.md",
    required_product_doc="docs/product/index.md",
)

PREVIEW_V07 = AuditLineSpec(
    profile=PREVIEW_MODE,
    benchmark_line="v0.7-preview",
    report_basename="v0_7_preview",
    manifest_name="baseline_v0_7_preview.yaml",
    default_outputs_root="outputs_preview_v07",
    required_runbook=None,
    required_release_doc=None,
    required_preview_doc="docs/experiments/v0_7_preview.md",
    required_product_doc="docs/product/index.md",
)

PREVIEW_V08 = AuditLineSpec(
    profile=PREVIEW_MODE,
    benchmark_line="v0.8-preview",
    report_basename="v0_8_preview",
    manifest_name="baseline_v0_8_preview.yaml",
    default_outputs_root="outputs_preview_v08",
    required_runbook=None,
    required_release_doc=None,
    required_preview_doc="docs/experiments/v0_8_preview.md",
    required_product_doc="docs/product/index.md",
)

PREVIEW_V09 = AuditLineSpec(
    profile=PREVIEW_MODE,
    benchmark_line="v0.9-preview",
    report_basename="v0_9_preview",
    manifest_name="baseline_v0_9_preview.yaml",
    default_outputs_root="outputs_preview_v09",
    required_runbook=None,
    required_release_doc=None,
    required_preview_doc="docs/experiments/v0_9_preview.md",
    required_product_doc="docs/product/index.md",
)

PREVIEW_V11 = AuditLineSpec(
    profile=PREVIEW_MODE,
    benchmark_line="v1.1-preview",
    report_basename="v1_1_preview",
    manifest_name="baseline_v1_1_preview.yaml",
    default_outputs_root="outputs_preview_v11",
    required_runbook=None,
    required_release_doc=None,
    required_preview_doc="docs/product/v1_1_preview.md",
    required_product_doc="docs/product/index.md",
)

PREVIEW_V12 = AuditLineSpec(
    profile=PREVIEW_MODE,
    benchmark_line="v1.2-preview",
    report_basename="v1_2_preview",
    manifest_name="baseline_v1_2_preview.yaml",
    default_outputs_root="outputs_preview_v12",
    required_runbook=None,
    required_release_doc=None,
    required_preview_doc="docs/product/v1_2_preview.md",
    required_product_doc="docs/product/index.md",
)

PREVIEW_V13 = AuditLineSpec(
    profile=PREVIEW_MODE,
    benchmark_line="v1.3-preview",
    report_basename="v1_3_preview",
    manifest_name="baseline_v1_3_preview.yaml",
    default_outputs_root="outputs_preview_v13",
    required_runbook=None,
    required_release_doc=None,
    required_preview_doc="docs/product/v1_3_preview.md",
    required_product_doc="docs/product/index.md",
)

PREVIEW_V14 = AuditLineSpec(
    profile=PREVIEW_MODE,
    benchmark_line="v1.4-preview",
    report_basename="v1_4_preview",
    manifest_name="baseline_v1_4_preview.yaml",
    default_outputs_root="outputs_preview_v14",
    required_runbook=None,
    required_release_doc=None,
    required_preview_doc="docs/product/v1_4_preview.md",
    required_product_doc="docs/product/index.md",
)

PREVIEW_V15 = AuditLineSpec(
    profile=PREVIEW_MODE,
    benchmark_line="v1.5-preview",
    report_basename="v1_5_preview",
    manifest_name="baseline_v1_5_preview.yaml",
    default_outputs_root="outputs_preview_v15",
    required_runbook=None,
    required_release_doc=None,
    required_preview_doc="docs/product/v1_5_preview.md",
    required_product_doc="docs/product/index.md",
)

PREVIEW_V16 = AuditLineSpec(
    profile=PREVIEW_MODE,
    benchmark_line="v1.6-preview",
    report_basename="v1_6_preview",
    manifest_name="baseline_v1_6_preview.yaml",
    default_outputs_root="outputs_preview_v16",
    required_runbook=None,
    required_release_doc=None,
    required_preview_doc="docs/product/v1_6_preview.md",
    required_product_doc="docs/product/index.md",
)

PREVIEW_V17 = AuditLineSpec(
    profile=PREVIEW_MODE,
    benchmark_line="v1.7-preview",
    report_basename="v1_7_preview",
    manifest_name="baseline_v1_7_preview.yaml",
    default_outputs_root="outputs_preview_v17",
    required_runbook=None,
    required_release_doc=None,
    required_preview_doc="docs/product/v1_7_preview.md",
    required_product_doc="docs/product/index.md",
)

PREVIEW_V18 = AuditLineSpec(
    profile=PREVIEW_MODE,
    benchmark_line="v1.8-preview",
    report_basename="v1_8_preview",
    manifest_name="baseline_v1_8_preview.yaml",
    default_outputs_root="outputs_preview_v18",
    required_runbook=None,
    required_release_doc=None,
    required_preview_doc="docs/product/v1_8_preview.md",
    required_product_doc="docs/product/index.md",
)

PREVIEW_V19 = AuditLineSpec(
    profile=PREVIEW_MODE,
    benchmark_line="v1.9-preview",
    report_basename="v1_9_preview",
    manifest_name="baseline_v1_9_preview.yaml",
    default_outputs_root="outputs_preview_v19",
    required_runbook=None,
    required_release_doc=None,
    required_preview_doc="docs/product/v1_9_preview.md",
    required_product_doc="docs/product/index.md",
)

STARTER_POST_V18_GEOMETRY = AuditLineSpec(
    profile=STARTER_MODE,
    benchmark_line="post-v1.8-geometry",
    report_basename="post_v1_8_geometry_starter",
    manifest_name="post_v1_8_geometry_starter.yaml",
    default_outputs_root="outputs_post_v1_8_geometry",
    required_runbook=None,
    required_release_doc=None,
    required_preview_doc=None,
    required_product_doc="docs/product/index.md",
    required_starter_doc="docs/product/post_v1_8_geometry_starter_pack.md",
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Audit a formal line, preview line, or draft-governed starter pack.")
    mode_group = parser.add_mutually_exclusive_group(required=True)
    mode_group.add_argument("--formal", type=str, default=None, help="Formal benchmark line label to audit. Supported values: v0.2, v0.3, v0.4, v0.5, v0.6, v1.0.")
    mode_group.add_argument("--preview", type=str, default=None, help="Preview benchmark line label to audit. Supported values: v0.3-preview, v0.4-preview, v0.5-preview, v0.6-preview, v0.7-preview, v0.8-preview, v0.9-preview, v1.1-preview, v1.2-preview, v1.3-preview, v1.4-preview, v1.5-preview, v1.6-preview, v1.7-preview, v1.8-preview, v1.9-preview.")
    mode_group.add_argument("--starter", type=str, default=None, help="Starter-pack label to audit. Supported values: post-v1.8-geometry.")
    parser.add_argument("--outputs-root", type=str, default=None, help="Optional outputs root override.")
    parser.add_argument("--output-dir", type=str, default=None, help="Optional audit artifact output directory override. Read-only mode resolves this path but does not create it unless --write is supplied.")
    parser.add_argument("--json", action="store_true", help="Print the audit JSON payload to stdout without writing files unless --write is also supplied.")
    parser.add_argument("--write", action="store_true", help="Persist canonical audit JSON and Markdown artifacts to the resolved output directory.")
    return parser



def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    return build_parser().parse_args(argv)



def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


PROTECTED_REPO_OUTPUT_ROOTS = ("outputs_v02", "outputs_v03", "outputs_v04", "outputs_v05", "outputs_v06")


def _protected_repo_output_roots() -> tuple[Path, ...]:
    repo_root = resolve_repo_root()
    return tuple((repo_root / name).resolve() for name in PROTECTED_REPO_OUTPUT_ROOTS)


def _protected_root_name_for_path(path: Path) -> str | None:
    resolved = path.resolve()
    for protected_root in _protected_repo_output_roots():
        if resolved == protected_root or protected_root in resolved.parents:
            return protected_root.name
    return None


def ensure_audit_write_allowed(*, output_dir: Path) -> None:
    protected_root_name = _protected_root_name_for_path(output_dir)
    if protected_root_name is not None:
        raise SystemExit(
            f"writing audit artifacts is not allowed for protected historical formal roots: {protected_root_name}"
        )



def resolve_audit_line(*, formal: str | None, preview: str | None, starter: str | None) -> AuditLineSpec:
    if formal is not None:
        if formal == FORMAL_V02.benchmark_line:
            return FORMAL_V02
        if formal == FORMAL_V03.benchmark_line:
            return FORMAL_V03
        if formal == FORMAL_V04.benchmark_line:
            return FORMAL_V04
        if formal == FORMAL_V05.benchmark_line:
            return FORMAL_V05
        if formal == FORMAL_V06.benchmark_line:
            return FORMAL_V06
        if formal == FORMAL_V10.benchmark_line:
            return FORMAL_V10
        raise ValueError(
            f"Unsupported audit line: formal '{formal}'. Supported formal lines are '{FORMAL_V02.benchmark_line}', '{FORMAL_V03.benchmark_line}', '{FORMAL_V04.benchmark_line}', '{FORMAL_V05.benchmark_line}', '{FORMAL_V06.benchmark_line}', and '{FORMAL_V10.benchmark_line}'."
        )
    if preview is not None:
        if preview == PREVIEW_V03.benchmark_line:
            return PREVIEW_V03
        if preview == PREVIEW_V04.benchmark_line:
            return PREVIEW_V04
        if preview == PREVIEW_V05.benchmark_line:
            return PREVIEW_V05
        if preview == PREVIEW_V06.benchmark_line:
            return PREVIEW_V06
        if preview == PREVIEW_V07.benchmark_line:
            return PREVIEW_V07
        if preview == PREVIEW_V08.benchmark_line:
            return PREVIEW_V08
        if preview == PREVIEW_V09.benchmark_line:
            return PREVIEW_V09
        if preview == PREVIEW_V11.benchmark_line:
            return PREVIEW_V11
        if preview == PREVIEW_V12.benchmark_line:
            return PREVIEW_V12
        if preview == PREVIEW_V13.benchmark_line:
            return PREVIEW_V13
        if preview == PREVIEW_V14.benchmark_line:
            return PREVIEW_V14
        if preview == PREVIEW_V15.benchmark_line:
            return PREVIEW_V15
        if preview == PREVIEW_V16.benchmark_line:
            return PREVIEW_V16
        if preview == PREVIEW_V17.benchmark_line:
            return PREVIEW_V17
        if preview == PREVIEW_V18.benchmark_line:
            return PREVIEW_V18
        if preview == PREVIEW_V19.benchmark_line:
            return PREVIEW_V19
        raise ValueError(
            f"Unsupported audit line: preview '{preview}'. Supported preview lines are '{PREVIEW_V03.benchmark_line}', '{PREVIEW_V04.benchmark_line}', '{PREVIEW_V05.benchmark_line}', '{PREVIEW_V06.benchmark_line}', '{PREVIEW_V07.benchmark_line}', '{PREVIEW_V08.benchmark_line}', '{PREVIEW_V09.benchmark_line}', '{PREVIEW_V11.benchmark_line}', '{PREVIEW_V12.benchmark_line}', '{PREVIEW_V13.benchmark_line}', '{PREVIEW_V14.benchmark_line}', '{PREVIEW_V15.benchmark_line}', '{PREVIEW_V16.benchmark_line}', '{PREVIEW_V17.benchmark_line}', '{PREVIEW_V18.benchmark_line}', and '{PREVIEW_V19.benchmark_line}'."
        )
    if starter is not None:
        if starter == STARTER_POST_V18_GEOMETRY.benchmark_line:
            return STARTER_POST_V18_GEOMETRY
        raise ValueError(
            f"Unsupported audit line: starter '{starter}'. Supported starter packs are '{STARTER_POST_V18_GEOMETRY.benchmark_line}'."
        )
    raise ValueError("One of --formal, --preview, or --starter is required.")



def resolve_default_outputs_root(spec: AuditLineSpec) -> Path:
    return resolve_outputs_root(resolve_repo_root() / spec.default_outputs_root)



def resolve_default_output_dir(*, spec: AuditLineSpec, outputs_root: Path) -> Path:
    repo_root = resolve_repo_root()
    if spec.profile == FORMAL_MODE and spec.benchmark_line in {FORMAL_V03.benchmark_line, FORMAL_V04.benchmark_line, FORMAL_V05.benchmark_line, FORMAL_V06.benchmark_line, FORMAL_V10.benchmark_line}:
        return (outputs_root / "_audit").resolve()
    if spec.profile == FORMAL_MODE:
        return (repo_root / "outputs_preview_v03" / "audits" / spec.benchmark_line).resolve()
    if spec.profile == STARTER_MODE:
        return (outputs_root / "_audit" / spec.benchmark_line.replace(".", "_").replace("-", "_")).resolve()
    return (outputs_root / "_audit" / spec.benchmark_line).resolve()



def _maybe_asset(path: Path | None) -> dict[str, Any]:
    if path is None:
        return {"exists": False, "path": None}
    return {"exists": path.exists(), "path": str(path.resolve())}



def _first_match(directory: Path, pattern: str) -> Path | None:
    if not directory.exists():
        return None
    matches = sorted(directory.glob(pattern))
    return None if not matches else matches[0].resolve()


def _preferred_match(directory: Path, basenames: Sequence[str], suffix: str) -> Path | None:
    if not directory.exists():
        return None
    for basename in basenames:
        candidate = (directory / f"{basename}{suffix}").resolve()
        if candidate.exists():
            return candidate
    return None


def _resolved_manifest_path(manifest_name: str | None) -> Path | None:
    if manifest_name is None:
        return None
    try:
        return resolve_manifest_path(manifest_name)
    except FileNotFoundError:
        return (resolve_repo_root() / "configs" / "matrix" / manifest_name).resolve()



def _safe_load_json(path: Path | None) -> tuple[dict[str, Any] | None, str | None]:
    if path is None or not path.exists():
        return None, None
    try:
        return load_json_file(path, label=path.name), None
    except Exception as error:  # pragma: no cover - defensive branch
        return None, str(error)



def _safe_count_rows(path: Path | None) -> tuple[int, str | None]:
    if path is None or not path.exists():
        return 0, None
    try:
        return count_csv_rows(path, label=path.name), None
    except Exception as error:  # pragma: no cover - defensive branch
        return 0, str(error)



def resolve_audit_assets(*, spec: AuditLineSpec, outputs_root: Path) -> dict[str, Any]:
    repo_root = resolve_repo_root()
    manifest_path = _resolved_manifest_path(spec.manifest_name)
    asset_basename = spec.report_basename if spec.manifest_name is None else Path(spec.manifest_name).stem
    candidate_basenames = [asset_basename]
    if spec.report_basename not in candidate_basenames:
        candidate_basenames.append(spec.report_basename)
    grouped_json_path = (outputs_root / "_leaderboard" / "leaderboard_grouped.json").resolve()
    reporting_dir = (outputs_root / "_leaderboard" / "reporting").resolve()
    pareto_dir = (outputs_root / "_leaderboard" / "pareto").resolve()
    run_report_dir = (outputs_root / "_matrix_runs").resolve()
    release_snapshot_path = (outputs_root / "_release_snapshot.json").resolve()
    analysis_dir = (outputs_root / "_analysis").resolve()

    if spec.profile == FORMAL_MODE:
        reporting_csv_path = (reporting_dir / f"{spec.report_basename}_baseline_table.csv").resolve()
        pareto_csv_path = (pareto_dir / f"{spec.report_basename}_pareto.csv").resolve()
        run_report_json_path = (run_report_dir / f"{spec.report_basename}_run_report.json").resolve()
        run_report_csv_path = (run_report_dir / f"{spec.report_basename}_run_report.csv").resolve()
    else:
        if spec.manifest_name is not None:
            reporting_csv_path = _preferred_match(reporting_dir, candidate_basenames, "_baseline_table.csv")
            pareto_csv_path = _preferred_match(pareto_dir, candidate_basenames, "_pareto.csv")
            run_report_json_path = _preferred_match(run_report_dir, candidate_basenames, "_run_report.json")
            run_report_csv_path = _preferred_match(run_report_dir, candidate_basenames, "_run_report.csv")
        else:
            reporting_csv_path = _first_match(reporting_dir, "*_baseline_table.csv")
            pareto_csv_path = _first_match(pareto_dir, "*_pareto.csv")
            run_report_json_path = _first_match(run_report_dir, "*_run_report.json")
            run_report_csv_path = _first_match(run_report_dir, "*_run_report.csv")

    runbook_path = None if spec.required_runbook is None else (repo_root / spec.required_runbook).resolve()
    release_doc_path = None if spec.required_release_doc is None else (repo_root / spec.required_release_doc).resolve()
    preview_doc_path = None if spec.required_preview_doc is None else (repo_root / spec.required_preview_doc).resolve()
    product_doc_path = None if spec.required_product_doc is None else (repo_root / spec.required_product_doc).resolve()
    starter_doc_path = None if spec.required_starter_doc is None else (repo_root / spec.required_starter_doc).resolve()

    return {
        "manifest": _maybe_asset(manifest_path),
        "grouped_json": _maybe_asset(grouped_json_path),
        "reporting_dir": _maybe_asset(reporting_dir),
        "reporting_csv": _maybe_asset(reporting_csv_path),
        "matched_budget_csv": _maybe_asset((reporting_dir / f"{asset_basename}_matched_budget_table.csv").resolve()),
        "matched_budget_md": _maybe_asset((reporting_dir / f"{asset_basename}_matched_budget_table.md").resolve()),
        "matched_budget_tex": _maybe_asset((reporting_dir / f"{asset_basename}_matched_budget_table.tex").resolve()),
        "fairness_coverage_json": _maybe_asset((reporting_dir / f"{asset_basename}_fairness_coverage.json").resolve()),
        "fairness_coverage_md": _maybe_asset((reporting_dir / f"{asset_basename}_fairness_coverage.md").resolve()),
        "regime_map_json": _maybe_asset((reporting_dir / f"{asset_basename}_regime_map.json").resolve()),
        "regime_map_md": _maybe_asset((reporting_dir / f"{asset_basename}_regime_map.md").resolve()),
        "ood_slice_leaderboard_csv": _maybe_asset((reporting_dir / f"{asset_basename}_ood_slice_leaderboard.csv").resolve()),
        "ood_slice_leaderboard_md": _maybe_asset((reporting_dir / f"{asset_basename}_ood_slice_leaderboard.md").resolve()),
        "failure_atlas_json": _maybe_asset((reporting_dir / f"{asset_basename}_failure_atlas.json").resolve()),
        "failure_atlas_md": _maybe_asset((reporting_dir / f"{asset_basename}_failure_atlas.md").resolve()),
        "physics_consistency_dashboard_json": _maybe_asset((reporting_dir / f"{asset_basename}_physics_consistency_dashboard.json").resolve()),
        "physics_consistency_dashboard_md": _maybe_asset((reporting_dir / f"{asset_basename}_physics_consistency_dashboard.md").resolve()),
        "pareto_dir": _maybe_asset(pareto_dir),
        "pareto_csv": _maybe_asset(pareto_csv_path),
        "accuracy_cost_pareto_csv": _maybe_asset((pareto_dir / f"{asset_basename}_accuracy_cost_pareto.csv").resolve()),
        "accuracy_cost_pareto_md": _maybe_asset((pareto_dir / f"{asset_basename}_accuracy_cost_pareto.md").resolve()),
        "run_report_dir": _maybe_asset(run_report_dir),
        "run_report_json": _maybe_asset(run_report_json_path),
        "run_report_csv": _maybe_asset(run_report_csv_path),
        "release_snapshot": _maybe_asset(release_snapshot_path),
        "analysis_dir": _maybe_asset(analysis_dir),
        "analysis_bundle": _maybe_asset(analysis_dir / "analysis_bundle.json"),
        "comparative_report_json": _maybe_asset(analysis_dir / "comparative_report.json"),
        "comparative_report_md": _maybe_asset(analysis_dir / "comparative_report.md"),
        "diagnostics_json": _maybe_asset(analysis_dir / "diagnostics.json"),
        "diagnostics_md": _maybe_asset(analysis_dir / "diagnostics.md"),
        "decision_support_json": _maybe_asset(analysis_dir / "decision_support.json"),
        "decision_support_md": _maybe_asset(analysis_dir / "decision_support.md"),
        "release_review_json": _maybe_asset(analysis_dir / "release_review.json"),
        "release_review_md": _maybe_asset(analysis_dir / "release_review.md"),
        "table_hints_json": _maybe_asset(analysis_dir / "table_hints.json"),
        "table_hints_md": _maybe_asset(analysis_dir / "table_hints.md"),
        "cross_version_review_json": _maybe_asset(analysis_dir / "cross_version_review.json"),
        "cross_version_review_md": _maybe_asset(analysis_dir / "cross_version_review.md"),
        "hardness_report_json": _maybe_asset(analysis_dir / "hardness_report.json"),
        "hardness_report_md": _maybe_asset(analysis_dir / "hardness_report.md"),
        "observation_snapshot_json": _maybe_asset(analysis_dir / "observation_snapshot.json"),
        "observation_snapshot_md": _maybe_asset(analysis_dir / "observation_snapshot.md"),
        "preview_evolution_record_json": _maybe_asset(analysis_dir / "preview_evolution_record.json"),
        "preview_evolution_record_md": _maybe_asset(analysis_dir / "preview_evolution_record.md"),
        "review_packet_json": _maybe_asset(analysis_dir / "review_packet.json"),
        "review_packet_md": _maybe_asset(analysis_dir / "review_packet.md"),
        "release_packet_draft_json": _maybe_asset(analysis_dir / "release_packet_draft.json"),
        "release_packet_draft_md": _maybe_asset(analysis_dir / "release_packet_draft.md"),
        "readiness_matrix_json": _maybe_asset(analysis_dir / "readiness_matrix.json"),
        "readiness_matrix_md": _maybe_asset(analysis_dir / "readiness_matrix.md"),
        "promotion_gap_report_json": _maybe_asset(analysis_dir / "promotion_gap_report.json"),
        "promotion_gap_report_md": _maybe_asset(analysis_dir / "promotion_gap_report.md"),
        "diagnostics_compact_md": _maybe_asset(analysis_dir / "diagnostics_compact.md"),
        "executive_summary_md": _maybe_asset(analysis_dir / "executive_summary.md"),
        "observation_consistency_json": _maybe_asset(analysis_dir / "observation_consistency.json"),
        "observation_consistency_md": _maybe_asset(analysis_dir / "observation_consistency.md"),
        "comparison_fairness_json": _maybe_asset(analysis_dir / "comparison_fairness.json"),
        "comparison_fairness_md": _maybe_asset(analysis_dir / "comparison_fairness.md"),
        "leaderboard_protocol_bundle": _maybe_asset((outputs_root / "_leaderboard_protocol" / "leaderboard_protocol_bundle.json").resolve()),
        "admission_registry_json": _maybe_asset((outputs_root / "_leaderboard_protocol" / "admission_registry.json").resolve()),
        "admission_registry_md": _maybe_asset((outputs_root / "_leaderboard_protocol" / "admission_registry.md").resolve()),
        "main_leaderboard_json": _maybe_asset((outputs_root / "_leaderboard_protocol" / "main_leaderboard.json").resolve()),
        "main_leaderboard_md": _maybe_asset((outputs_root / "_leaderboard_protocol" / "main_leaderboard.md").resolve()),
        "stress_leaderboard_json": _maybe_asset((outputs_root / "_leaderboard_protocol" / "stress_leaderboard.json").resolve()),
        "stress_leaderboard_md": _maybe_asset((outputs_root / "_leaderboard_protocol" / "stress_leaderboard.md").resolve()),
        "pareto_leaderboard_json": _maybe_asset((outputs_root / "_leaderboard_protocol" / "pareto_leaderboard.json").resolve()),
        "pareto_leaderboard_md": _maybe_asset((outputs_root / "_leaderboard_protocol" / "pareto_leaderboard.md").resolve()),
        "parameter_efficiency_json": _maybe_asset((outputs_root / "_leaderboard_protocol" / "parameter_efficiency.json").resolve()),
        "parameter_efficiency_md": _maybe_asset((outputs_root / "_leaderboard_protocol" / "parameter_efficiency.md").resolve()),
        "convergence_efficiency_json": _maybe_asset((outputs_root / "_leaderboard_protocol" / "convergence_efficiency.json").resolve()),
        "convergence_efficiency_md": _maybe_asset((outputs_root / "_leaderboard_protocol" / "convergence_efficiency.md").resolve()),
        "convergence_efficiency_unavailable_md": _maybe_asset((outputs_root / "_leaderboard_protocol" / "convergence_efficiency_unavailable.md").resolve()),
        "governance_packet_json": _maybe_asset((outputs_root / "_leaderboard_protocol" / "governance_packet.json").resolve()),
        "governance_packet_md": _maybe_asset((outputs_root / "_leaderboard_protocol" / "governance_packet.md").resolve()),
        "formal_discussion_memo_md": _maybe_asset(analysis_dir / "formal_discussion_memo.md"),
        "discussion_questions_md": _maybe_asset(analysis_dir / "discussion_questions.md"),
        "formal_discussion_checklist_md": _maybe_asset(analysis_dir / "formal_discussion_checklist.md"),
        "freeze_packet_json": _maybe_asset(analysis_dir / "freeze_packet.json"),
        "freeze_packet_md": _maybe_asset(analysis_dir / "freeze_packet.md"),
        "freeze_readiness_report_json": _maybe_asset(analysis_dir / "freeze_readiness_report.json"),
        "freeze_readiness_report_md": _maybe_asset(analysis_dir / "freeze_readiness_report.md"),
        "formal_baseline_summary_md": _maybe_asset(analysis_dir / "formal_baseline_summary.md"),
        "v1_0_formal_manifest_json": _maybe_asset(analysis_dir / "v1_0_formal_manifest.json"),
        "v1_0_formal_manifest_md": _maybe_asset(analysis_dir / "v1_0_formal_manifest.md"),
        "freeze_governance_record_md": _maybe_asset(analysis_dir / "freeze_governance_record.md"),
        "freeze_decision_brief_md": _maybe_asset(analysis_dir / "freeze_decision_brief.md"),
        "runbook": _maybe_asset(runbook_path),
        "release_doc": _maybe_asset(release_doc_path),
        "preview_doc": _maybe_asset(preview_doc_path),
        "product_doc": _maybe_asset(product_doc_path),
        "starter_doc": _maybe_asset(starter_doc_path),
    }



def _extract_run_report_counts(run_report: dict[str, Any] | None) -> dict[str, int]:
    summary = run_report.get("summary") if isinstance(run_report, dict) else None
    if not isinstance(summary, dict):
        return {"planned": 0, "attempted": 0, "succeeded": 0, "failed": 0, "skipped": 0}
    return {
        "planned": int(summary.get("total_runs_planned", 0) or 0),
        "attempted": int(summary.get("total_runs_attempted", 0) or 0),
        "succeeded": int(summary.get("total_runs_succeeded", 0) or 0),
        "failed": int(summary.get("total_runs_failed", 0) or 0),
        "skipped": int(summary.get("total_runs_skipped", 0) or 0),
    }



def _doctor_strict_passed(payload: dict[str, Any]) -> bool:
    summary = payload.get("summary")
    if not isinstance(summary, dict):
        return False
    return not summary.get("warning") and not summary.get("error")



def _doctor_has_errors(payload: dict[str, Any]) -> bool:
    summary = payload.get("summary")
    if not isinstance(summary, dict):
        return True
    return bool(summary.get("error"))



def _notable_checks(payload: dict[str, Any]) -> list[dict[str, Any]]:
    checks = payload.get("checks")
    if not isinstance(checks, list):
        return []
    return [check for check in checks if isinstance(check, dict) and str(check.get("severity")) in {"warning", "error"}]


def _operator_slice_facts(
    grouped_payload: dict[str, Any] | None,
    *,
    reporting_rows: int,
    pareto_rows: int,
) -> dict[str, Any]:
    rows = grouped_payload.get("rows") if isinstance(grouped_payload, dict) else None
    if not isinstance(rows, list):
        rows = []
    field_rows = [
        row
        for row in rows
        if isinstance(row, dict)
        and any(str(row.get(key, "")).lower() == "field" for key in ("task_mode", "model_mode", "evaluation_mode"))
    ]
    protocol_order = {"none": 0, "noise": 1, "sparsity": 2, "extrapolation": 3}
    protocols = sorted(
        {str(row.get("protocol") or "none") for row in field_rows},
        key=lambda value: (protocol_order.get(value, 99), value),
    )
    mode_fields_present = bool(field_rows) and all(
        bool(row.get("task_mode")) and bool(row.get("model_mode")) and bool(row.get("evaluation_mode"))
        for row in field_rows
    )
    task_count = len({str(row.get("task_name")) for row in field_rows if row.get("task_name")})
    baseline_count = len({str(row.get("model_name")) for row in field_rows if row.get("model_name")})
    return {
        "task_count": task_count,
        "baseline_count": baseline_count,
        "field_grouped_row_count": len(field_rows),
        "protocols": protocols,
        "shape": "widened" if task_count >= 2 and baseline_count >= 2 else "narrow",
        "assets_complete": bool(field_rows) and reporting_rows > 0 and pareto_rows > 0 and mode_fields_present,
    }



def _analysis_surface_facts(assets: dict[str, Any], *, benchmark_line: str) -> dict[str, Any]:
    starter_line = benchmark_line == STARTER_POST_V18_GEOMETRY.benchmark_line
    required_names = [
        "analysis_bundle",
        "comparative_report_json",
        "comparative_report_md",
        "diagnostics_json",
        "diagnostics_md",
        "decision_support_json",
        "decision_support_md",
        "release_review_json",
        "release_review_md",
        "table_hints_json",
        "table_hints_md",
        "cross_version_review_json",
        "cross_version_review_md",
        "hardness_report_json",
        "hardness_report_md",
        "observation_snapshot_json",
        "observation_snapshot_md",
        "preview_evolution_record_json",
        "preview_evolution_record_md",
        "review_packet_json",
        "review_packet_md",
        "release_packet_draft_json",
        "release_packet_draft_md",
        "readiness_matrix_json",
        "readiness_matrix_md",
        "promotion_gap_report_json",
        "promotion_gap_report_md",
        "diagnostics_compact_md",
        "executive_summary_md",
    ]
    if benchmark_line in {"v0.9-preview", "v1.1-preview", "v1.2-preview", "v1.3-preview", "v1.4-preview", "v1.5-preview", "v1.6-preview", "v1.7-preview", "v1.8-preview", "v1.9-preview", STARTER_POST_V18_GEOMETRY.benchmark_line}:
        required_names.extend(
            [
                "observation_consistency_json",
                "observation_consistency_md",
                "comparison_fairness_json",
                "comparison_fairness_md",
            ]
        )
    if benchmark_line in {"v1.2-preview", "v1.3-preview", "v1.4-preview", "v1.5-preview", "v1.6-preview", "v1.7-preview", "v1.8-preview", "v1.9-preview", STARTER_POST_V18_GEOMETRY.benchmark_line}:
        required_names.extend(
            [
                "leaderboard_protocol_bundle",
                "admission_registry_json",
                "admission_registry_md",
                "main_leaderboard_json",
                "main_leaderboard_md",
                "stress_leaderboard_json",
                "stress_leaderboard_md",
                "pareto_leaderboard_json",
                "pareto_leaderboard_md",
                "parameter_efficiency_json",
                "parameter_efficiency_md",
                "governance_packet_json",
                "governance_packet_md",
            ]
        )
    if benchmark_line in {"v1.7-preview", "v1.8-preview", "v1.9-preview"}:
        required_names.extend(
            [
                "matched_budget_csv",
                "matched_budget_md",
                "matched_budget_tex",
                "fairness_coverage_json",
                "fairness_coverage_md",
                "accuracy_cost_pareto_csv",
                "accuracy_cost_pareto_md",
            ]
        )
    if benchmark_line == "v0.9-preview":
        required_names.extend(["formal_discussion_memo_md", "discussion_questions_md"])
    complete = all(bool(assets[name]["exists"]) for name in required_names)
    history_entry_count = 0
    formal_discussion_signal = None
    analysis_readiness_conclusion = None
    provenance_surface_present = False
    observation_consistency_present = False
    comparison_fairness_present = False
    previous_preview_linkage_present = False
    packet_completeness_present = False
    dx_surface_present = False
    template_catalog_present = False
    quickstart_surface_present = False
    logging_hook_summary_present = False
    capability_surface_present = False
    observation_target_surface_present = False
    operator_ready_summary_present = False
    stress_surface_summary_present = False
    cross_line_consolidation_summary_present = False
    external_adoption_summary_present = False
    publication_packaging_summary_present = False
    benchmark_positioning_summary_present = False
    pack_identity_present = False
    starter_pack_identity_matches = False
    if assets["analysis_dir"]["exists"] and assets["analysis_dir"]["path"] is not None:
        history_entry_count = len(list_history_entries(Path(str(assets["analysis_dir"]["path"]))))
    if assets["analysis_bundle"]["exists"] and assets["analysis_bundle"]["path"] is not None:
        bundle_payload, _ = _safe_load_json(Path(str(assets["analysis_bundle"]["path"])))
        if isinstance(bundle_payload, dict):
            formal_discussion_signal = bundle_payload.get("decision_support", {}).get("formal_discussion_recommendation")
            analysis_readiness_conclusion = bundle_payload.get("review_packet", {}).get("analysis_readiness_conclusion")
            provenance_surface_present = bool(bundle_payload.get("reproducibility_facts", {}).get("provenance_surface_present"))
            observation_consistency_present = bool(bundle_payload.get("observation_consistency"))
            comparison_fairness_present = bool(bundle_payload.get("comparison_fairness"))
            previous_preview_linkage_present = bundle_payload.get("previous_preview_root") is not None
            dx_surface_present = bool(bundle_payload.get("dx_surface_summary"))
            template_catalog_present = bool(bundle_payload.get("template_catalog_summary"))
            quickstart_surface_present = bool(bundle_payload.get("quickstart_surface_summary"))
            logging_hook_summary_present = bool(bundle_payload.get("logging_hook_summary"))
            capability_surface_present = bool(bundle_payload.get("capability_surface_summary"))
            observation_target_surface_present = bool(bundle_payload.get("observation_target_surface_summary"))
            operator_ready_summary_present = bool(bundle_payload.get("operator_ready_summary"))
            stress_surface_summary_present = bool(bundle_payload.get("stress_surface_summary"))
            cross_line_consolidation_summary_present = bool(bundle_payload.get("cross_line_consolidation_summary"))
            external_adoption_summary_present = bool(bundle_payload.get("external_adoption_summary"))
            publication_packaging_summary_present = bool(bundle_payload.get("publication_packaging_summary"))
            benchmark_positioning_summary_present = bool(bundle_payload.get("benchmark_positioning_summary"))
            pack_identity = bundle_payload.get("pack_identity")
            pack_identity_present = isinstance(pack_identity, dict) and bool(pack_identity)
            starter_pack_identity_matches = bool(
                starter_line
                and isinstance(pack_identity, dict)
                and pack_identity.get("pack_kind") == "starter"
                and pack_identity.get("starter_pack_id") == STARTER_POST_V18_GEOMETRY.benchmark_line
                and pack_identity.get("reference_preview_line") == "v1.8-preview"
            )
            review_packet = bundle_payload.get("review_packet", {})
            packet_completeness_present = all(
                key in review_packet
                for key in (
                    "engineering_status",
                    "reproducibility_status",
                    "observation_consistency_status",
                    "asset_completeness_status",
                    "comparison_fairness_summary",
                )
            )
    protocol_bundle_payload, _ = _safe_load_json(Path(str(assets["leaderboard_protocol_bundle"]["path"]))) if assets["leaderboard_protocol_bundle"]["path"] is not None else (None, None)
    example_import_count = len(list((Path(str(assets["grouped_json"]["path"])).resolve().parent.parent / "_submission_imports" / "examples").rglob("leaderboard_entry_candidate.json"))) if assets["grouped_json"]["path"] is not None else 0
    return {
        "analysis_bundle_present": bool(assets["analysis_bundle"]["exists"]),
        "views_complete": complete,
        "available_views": [name for name in required_names if bool(assets[name]["exists"])],
        "history_entry_count": history_entry_count,
        "observation_snapshot_present": bool(assets["observation_snapshot_json"]["exists"]),
        "review_packet_present": bool(assets["review_packet_json"]["exists"]),
        "promotion_gap_report_present": bool(assets["promotion_gap_report_json"]["exists"]),
        "provenance_surface_present": provenance_surface_present,
        "observation_consistency_present": observation_consistency_present,
        "comparison_fairness_present": comparison_fairness_present,
        "previous_preview_linkage_present": previous_preview_linkage_present,
        "packet_completeness_present": packet_completeness_present,
        "dx_surface_present": dx_surface_present,
        "template_catalog_present": template_catalog_present,
        "quickstart_surface_present": quickstart_surface_present,
        "logging_hook_summary_present": logging_hook_summary_present,
        "capability_surface_present": capability_surface_present,
        "observation_target_surface_present": observation_target_surface_present,
        "operator_ready_summary_present": operator_ready_summary_present,
        "stress_surface_summary_present": stress_surface_summary_present,
        "cross_line_consolidation_summary_present": cross_line_consolidation_summary_present,
        "external_adoption_summary_present": external_adoption_summary_present,
        "publication_packaging_summary_present": publication_packaging_summary_present,
        "benchmark_positioning_summary_present": benchmark_positioning_summary_present,
        "pack_identity_present": pack_identity_present,
        "starter_pack_identity_matches": starter_pack_identity_matches,
        "formal_discussion_signal_present": formal_discussion_signal is not None,
        "formal_discussion_signal": formal_discussion_signal,
        "analysis_readiness_conclusion": analysis_readiness_conclusion,
        "leaderboard_protocol_present": bool(assets["leaderboard_protocol_bundle"]["exists"]),
        "admission_registry_present": bool(assets["admission_registry_json"]["exists"]),
        "governance_packet_present": bool(assets["governance_packet_json"]["exists"]),
        "leaderboard_protocol_policy_class": None if not isinstance(protocol_bundle_payload, dict) else protocol_bundle_payload.get("comparison_fairness", {}).get("stress_policy", {}).get("policy_class"),
        "example_import_count": example_import_count,
        "fair_budget_assets_complete": all(
            bool(assets[name]["exists"])
            for name in (
                "matched_budget_csv",
                "matched_budget_md",
                "matched_budget_tex",
                "fairness_coverage_json",
                "fairness_coverage_md",
                "accuracy_cost_pareto_csv",
                "accuracy_cost_pareto_md",
            )
        )
        if benchmark_line in {"v1.7-preview", "v1.8-preview", "v1.9-preview"}
        else False,
        "regime_assets_complete": all(
            bool(assets[name]["exists"])
            for name in (
                "regime_map_json",
                "regime_map_md",
                "ood_slice_leaderboard_csv",
                "ood_slice_leaderboard_md",
                "failure_atlas_json",
                "failure_atlas_md",
                "physics_consistency_dashboard_json",
                "physics_consistency_dashboard_md",
            )
        )
        if benchmark_line in {"v1.8-preview", "v1.9-preview", STARTER_POST_V18_GEOMETRY.benchmark_line}
        else False,
    }


def _fair_budget_surface_facts(grouped_payload: dict[str, Any] | None, *, benchmark_line: str) -> dict[str, Any] | None:
    if benchmark_line not in {"v1.7-preview", "v1.8-preview", "v1.9-preview"} or not isinstance(grouped_payload, dict):
        return None
    groups = grouped_payload.get("fair_budget_groups") if isinstance(grouped_payload.get("fair_budget_groups"), list) else []
    summary = grouped_payload.get("fair_budget_summary") if isinstance(grouped_payload.get("fair_budget_summary"), dict) else {}
    headline_groups = [group for group in groups if isinstance(group, dict) and bool(group.get("headline_program"))]
    eligible_groups = [group for group in headline_groups if bool(group.get("headline_claim_eligible"))]
    blocked_headline_groups = [group for group in headline_groups if not bool(group.get("headline_claim_eligible"))]
    tasks_with_eligible_groups = sorted(
        {
            str(group.get("task_name") or "").strip()
            for group in eligible_groups
            if str(group.get("task_name") or "").strip()
        }
    )
    return {
        "fair_budget_summary": dict(summary),
        "matched_budget_group_count": len(groups),
        "headline_group_count": len(headline_groups),
        "headline_eligible_group_count": len(eligible_groups),
        "blocked_headline_group_count": len(blocked_headline_groups),
        "headline_tasks_with_eligible_groups": tasks_with_eligible_groups,
    }


def _regime_surface_facts(
    grouped_payload: dict[str, Any] | None,
    *,
    assets: dict[str, Any],
    benchmark_line: str,
) -> dict[str, Any] | None:
    if benchmark_line not in {"v1.8-preview", "v1.9-preview", STARTER_POST_V18_GEOMETRY.benchmark_line}:
        return None
    regime_map_path = Path(str(assets["regime_map_json"]["path"])) if assets["regime_map_json"]["exists"] else None
    regime_map_payload, _ = _safe_load_json(regime_map_path)
    facts = summarize_regime_governance(grouped_payload, regime_map_payload=regime_map_payload)
    return {
        "regime_summary": dict(facts.get("regime_summary", {})),
        "regime_group_count": int(facts.get("regime_group_count", 0) or 0),
        "headline_regime_group_count": int(facts.get("headline_regime_group_count", 0) or 0),
        "blocked_regime_group_count": int(facts.get("blocked_regime_group_count", 0) or 0),
        "mixed_distribution_group_count": int(facts.get("mixed_distribution_group_count", 0) or 0),
        "mixed_ood_family_group_count": int(facts.get("mixed_ood_family_group_count", 0) or 0),
        "coverage_only_regime_group_count": int(facts.get("coverage_only_regime_group_count", 0) or 0),
        "ood_protocol_families_present": list(facts.get("ood_protocol_families_present", [])),
        "regime_hosts_with_complete_labels": dict(facts.get("regime_hosts_with_complete_labels", {})),
        "targeted_rows_missing_complete_labels_count": int(facts.get("targeted_rows_missing_complete_labels_count", 0) or 0),
        "targeted_rows_missing_complete_labels": list(facts.get("targeted_rows_missing_complete_labels", [])),
        "host_requirements": dict(facts.get("host_requirements", {})),
        "missing_host_requirements": list(facts.get("missing_host_requirements", [])),
        "geometry_targeted_row_count": int(facts.get("geometry_targeted_row_count", 0) or 0),
        "geometry_targeted_rows_missing_complete_labels_count": int(
            facts.get("geometry_targeted_rows_missing_complete_labels_count", 0) or 0
        ),
        "geometry_targeted_rows_missing_geometry_labels_count": int(
            facts.get("geometry_targeted_rows_missing_geometry_labels_count", 0) or 0
        ),
        "geometry_targeted_rows_missing_required_metrics_count": int(
            facts.get("geometry_targeted_rows_missing_required_metrics_count", 0) or 0
        ),
        "geometry_group_count": int(facts.get("geometry_group_count", 0) or 0),
        "mixed_geometry_distribution_group_count": int(facts.get("mixed_geometry_distribution_group_count", 0) or 0),
        "mixed_geometry_class_group_count": int(facts.get("mixed_geometry_class_group_count", 0) or 0),
        "geometry_hosts_with_complete_labels": dict(facts.get("geometry_hosts_with_complete_labels", {})),
        "geometry_host_requirements": dict(facts.get("geometry_host_requirements", {})),
        "missing_geometry_host_requirements": list(facts.get("missing_geometry_host_requirements", [])),
    }


def _core_formal_assets_present(assets: dict[str, Any]) -> bool:
    required = [
        "manifest",
        "grouped_json",
        "reporting_csv",
        "pareto_csv",
        "run_report_json",
        "run_report_csv",
    ]
    return all(bool(assets[name]["exists"]) for name in required)



def _core_preview_assets_present(assets: dict[str, Any], *, spec: AuditLineSpec) -> bool:
    required = ["grouped_json", "reporting_csv", "pareto_csv", "product_doc"]
    if spec.required_preview_doc is not None:
        required.append("preview_doc")
    if not all(bool(assets[name]["exists"]) for name in required):
        return False
    manifest_asset = assets.get("manifest")
    if isinstance(manifest_asset, dict) and manifest_asset.get("path") is not None:
        return bool(manifest_asset.get("exists"))
    return True


def _core_starter_assets_present(assets: dict[str, Any]) -> bool:
    required = [
        "manifest",
        "grouped_json",
        "reporting_dir",
        "reporting_csv",
        "run_report_json",
        "run_report_csv",
        "release_snapshot",
        "analysis_dir",
        "analysis_bundle",
        "leaderboard_protocol_bundle",
        "starter_doc",
        "product_doc",
    ]
    return all(bool(assets[name]["exists"]) for name in required)



def _formal_freeze_surface_facts(assets: dict[str, Any]) -> dict[str, Any]:
    required = [
        "freeze_packet_json",
        "freeze_packet_md",
        "freeze_readiness_report_json",
        "freeze_readiness_report_md",
        "formal_baseline_summary_md",
        "v1_0_formal_manifest_json",
        "v1_0_formal_manifest_md",
        "freeze_governance_record_md",
        "freeze_decision_brief_md",
    ]
    return {
        "assets_complete": all(bool(assets[name]["exists"]) for name in required),
        "available_assets": [name for name in required if bool(assets[name]["exists"])],
    }




def compute_audit_result(*, spec: AuditLineSpec, outputs_root: Path, output_dir: Path) -> dict[str, Any]:
    assets = resolve_audit_assets(spec=spec, outputs_root=outputs_root)

    grouped_json_path = Path(assets["grouped_json"]["path"]) if assets["grouped_json"]["exists"] else None
    reporting_csv_path = Path(assets["reporting_csv"]["path"]) if assets["reporting_csv"]["exists"] else None
    pareto_csv_path = Path(assets["pareto_csv"]["path"]) if assets["pareto_csv"]["exists"] else None
    run_report_json_path = Path(assets["run_report_json"]["path"]) if assets["run_report_json"]["exists"] else None

    grouped_payload, grouped_error = _safe_load_json(grouped_json_path)
    run_report_payload, run_report_error = _safe_load_json(run_report_json_path)
    reporting_rows, reporting_error = _safe_count_rows(reporting_csv_path)
    pareto_rows, pareto_error = _safe_count_rows(pareto_csv_path)

    if spec.profile == FORMAL_MODE:
        doctor_payload = build_doctor_payload(
            mode=FORMAL_MODE,
            outputs_root_arg=str(outputs_root),
            matrix_manifest_arg=spec.manifest_name,
            strict=True,
        )
    elif spec.profile == STARTER_MODE:
        doctor_payload = build_doctor_payload(
            mode=STARTER_MODE,
            outputs_root_arg=str(outputs_root),
            matrix_manifest_arg=spec.manifest_name,
            strict=True,
        )
    else:
        doctor_payload = build_doctor_payload(
            mode=PREVIEW_MODE,
            outputs_root_arg=str(outputs_root),
            matrix_manifest_arg=None,
            strict=True,
        )

    summary_facts = build_summary_facts(grouped_payload) if isinstance(grouped_payload, dict) else {
        "matrix_name": spec.report_basename,
        "matrix_manifest": None,
        "clean_task_leaders": [],
        "worst_protocol_degradation": None,
        "lightest_family": None,
        "most_stable_family": None,
        "widest_gap_protocol": None,
        "incomplete_family_count": 0,
        "incomplete_run_ids": [],
        "grouped_warning_count": 0,
        "warnings": [],
    }

    run_counts = _extract_run_report_counts(run_report_payload)
    grouped_rows = len(grouped_payload.get("rows", [])) if isinstance(grouped_payload, dict) else 0
    grouped_warnings = len(grouped_payload.get("warnings", [])) if isinstance(grouped_payload, dict) else 0
    preview_like_profile = spec.profile in {PREVIEW_MODE, STARTER_MODE}
    operator_slice = _operator_slice_facts(grouped_payload, reporting_rows=reporting_rows, pareto_rows=pareto_rows) if preview_like_profile else None
    analysis_surface = _analysis_surface_facts(assets, benchmark_line=spec.benchmark_line) if preview_like_profile else None
    fair_budget_surface = _fair_budget_surface_facts(grouped_payload, benchmark_line=spec.benchmark_line) if spec.profile == PREVIEW_MODE else None
    regime_surface = _regime_surface_facts(grouped_payload, assets=assets, benchmark_line=spec.benchmark_line) if preview_like_profile else None
    formal_freeze_surface = _formal_freeze_surface_facts(assets) if spec.profile == FORMAL_MODE and spec.benchmark_line == FORMAL_V10.benchmark_line else None

    reasons: list[str] = []
    if grouped_error is not None:
        reasons.append(f"Grouped leaderboard is unreadable: {grouped_error}")
    if run_report_error is not None:
        reasons.append(f"Run report JSON is unreadable: {run_report_error}")
    if reporting_error is not None:
        reasons.append(f"Reporting CSV is unreadable: {reporting_error}")
    if pareto_error is not None:
        reasons.append(f"Pareto CSV is unreadable: {pareto_error}")

    if spec.profile == FORMAL_MODE:
        if not _core_formal_assets_present(assets):
            reasons.append("One or more core formal machine-readable assets are missing.")
            status = INCOMPLETE
        else:
            freeze_requirements_met = (
                bool(assets["release_snapshot"]["exists"])
                and bool(assets["runbook"]["exists"])
                and bool(assets["release_doc"]["exists"])
                and _doctor_strict_passed(doctor_payload)
                and grouped_warnings == 0
                and reporting_rows > 0
                and pareto_rows > 0
                and (formal_freeze_surface is None or bool(formal_freeze_surface["assets_complete"]))
            )
            if freeze_requirements_met:
                reasons.append("Formal release gates are satisfied.")
                status = READY_FOR_FREEZE
            else:
                if not assets["release_snapshot"]["exists"]:
                    reasons.append("Release snapshot is missing.")
                if not assets["runbook"]["exists"]:
                    reasons.append("Formal runbook is missing.")
                if not assets["release_doc"]["exists"]:
                    reasons.append("Formal release doc is missing.")
                if grouped_warnings != 0:
                    reasons.append(f"Grouped warnings must be 0 for formal freeze; found {grouped_warnings}.")
                if not _doctor_strict_passed(doctor_payload):
                    reasons.append("Doctor strict does not pass for the formal profile.")
                if formal_freeze_surface is not None and not formal_freeze_surface["assets_complete"]:
                    reasons.append("Formal freeze-analysis assets are incomplete for v1.0.")
                if reporting_rows <= 0:
                    reasons.append("Reporting CSV has no rows.")
                if pareto_rows <= 0:
                    reasons.append("Pareto CSV has no rows.")
                status = READY_FOR_PREVIEW_ONLY
    elif spec.profile == PREVIEW_MODE:
        if not _core_preview_assets_present(assets, spec=spec):
            reasons.append("One or more core preview assets or docs are missing.")
            status = INCOMPLETE
        elif reporting_rows <= 0 or pareto_rows <= 0:
            if reporting_rows <= 0:
                reasons.append("Reporting CSV has no rows.")
            if pareto_rows <= 0:
                reasons.append("Pareto CSV has no rows.")
            status = INCOMPLETE
        elif _doctor_has_errors(doctor_payload):
            reasons.append("Doctor reports one or more error checks for the preview profile.")
            status = INCOMPLETE
        else:
            if spec.benchmark_line == "v1.9-preview":
                headline_tasks_with_eligible_groups = set((fair_budget_surface or {}).get("headline_tasks_with_eligible_groups") or [])
                missing_headline_tasks = sorted({"heat1d", "burgers1d", "poisson2d", "allencahn1d"} - headline_tasks_with_eligible_groups)
                preview_requirements_met = (
                    _doctor_strict_passed(doctor_payload)
                    and grouped_warnings == 0
                    and bool(analysis_surface and analysis_surface.get("fair_budget_assets_complete"))
                    and bool(analysis_surface and analysis_surface.get("regime_assets_complete"))
                    and bool(fair_budget_surface)
                    and bool(regime_surface)
                    and int((fair_budget_surface or {}).get("blocked_headline_group_count") or 0) == 0
                    and not missing_headline_tasks
                    and int((regime_surface or {}).get("targeted_rows_missing_complete_labels_count") or 0) == 0
                    and int((regime_surface or {}).get("headline_regime_group_count") or 0) >= 8
                    and int((regime_surface or {}).get("coverage_only_regime_group_count") or 0) == 0
                    and int((regime_surface or {}).get("blocked_regime_group_count") or 0) == 0
                    and int((regime_surface or {}).get("mixed_distribution_group_count") or 0) == 0
                    and int((regime_surface or {}).get("mixed_ood_family_group_count") or 0) == 0
                    and not (regime_surface or {}).get("missing_host_requirements")
                    and int((regime_surface or {}).get("geometry_targeted_rows_missing_complete_labels_count") or 0) == 0
                    and int((regime_surface or {}).get("geometry_targeted_rows_missing_required_metrics_count") or 0) == 0
                    and int((regime_surface or {}).get("mixed_geometry_distribution_group_count") or 0) == 0
                    and int((regime_surface or {}).get("mixed_geometry_class_group_count") or 0) == 0
                    and not (regime_surface or {}).get("missing_geometry_host_requirements")
                )
                if preview_requirements_met:
                    reasons.append("Preview release gates are satisfied.")
                    status = READY_FOR_PREVIEW_ONLY
                else:
                    if not _doctor_strict_passed(doctor_payload):
                        reasons.append("Doctor strict does not pass for the evidence-rich v1.9 preview profile.")
                    if grouped_warnings != 0:
                        reasons.append(f"Grouped warnings must be 0 for v1.9 closeout; found {grouped_warnings}.")
                    if not (analysis_surface and analysis_surface.get("fair_budget_assets_complete")):
                        reasons.append("One or more carried-forward fair-budget reporting assets are missing.")
                    if not (analysis_surface and analysis_surface.get("regime_assets_complete")):
                        reasons.append("One or more regime/OOD reporting artifacts are missing.")
                    if int((fair_budget_surface or {}).get("blocked_headline_group_count") or 0) != 0:
                        reasons.append("One or more headline matched-budget groups remain blocked.")
                    if missing_headline_tasks:
                        reasons.append(f"Missing headline-eligible matched-budget groups for: {', '.join(missing_headline_tasks)}.")
                    if int((regime_surface or {}).get("targeted_rows_missing_complete_labels_count") or 0) != 0:
                        reasons.append("One or more v1.9 targeted grouped rows are missing complete regime labels.")
                    if int((regime_surface or {}).get("headline_regime_group_count") or 0) < 8:
                        reasons.append("The v1.9 regime surface does not yet expose eight headline-complete groups.")
                    if int((regime_surface or {}).get("coverage_only_regime_group_count") or 0) != 0:
                        reasons.append("One or more operator regime groups remain coverage-only in v1.9.")
                    if int((regime_surface or {}).get("blocked_regime_group_count") or 0) != 0:
                        reasons.append("One or more headline regime groups remain blocked.")
                    if int((regime_surface or {}).get("mixed_distribution_group_count") or 0) != 0:
                        reasons.append("One or more headline regime groups mix ID and OOD rows.")
                    if int((regime_surface or {}).get("mixed_ood_family_group_count") or 0) != 0:
                        reasons.append("One or more headline regime groups mix multiple OOD protocol families.")
                    missing_host_requirements = list((regime_surface or {}).get("missing_host_requirements") or [])
                    if missing_host_requirements:
                        reasons.append(f"Missing regime host coverage for: {', '.join(missing_host_requirements)}.")
                    if int((regime_surface or {}).get("geometry_targeted_rows_missing_complete_labels_count") or 0) != 0:
                        reasons.append("One or more geometry-targeted grouped rows are missing complete geometry or regime labels.")
                    if int((regime_surface or {}).get("geometry_targeted_rows_missing_required_metrics_count") or 0) != 0:
                        reasons.append("One or more geometry-targeted grouped rows are missing near-boundary or residual metrics.")
                    if int((regime_surface or {}).get("mixed_geometry_distribution_group_count") or 0) != 0:
                        reasons.append("One or more geometry claim groups mix multiple geometry-distribution labels.")
                    if int((regime_surface or {}).get("mixed_geometry_class_group_count") or 0) != 0:
                        reasons.append("One or more geometry claim groups mix multiple derived geometry classes.")
                    missing_geometry_host_requirements = list((regime_surface or {}).get("missing_geometry_host_requirements") or [])
                    if missing_geometry_host_requirements:
                        reasons.append(
                            f"Missing geometry host coverage for: {', '.join(missing_geometry_host_requirements)}."
                        )
                    status = INCOMPLETE
            elif spec.benchmark_line == "v1.8-preview":
                headline_tasks_with_eligible_groups = set((fair_budget_surface or {}).get("headline_tasks_with_eligible_groups") or [])
                missing_headline_tasks = sorted({"heat1d", "burgers1d", "poisson2d", "allencahn1d"} - headline_tasks_with_eligible_groups)
                geometry_claims_present = int((regime_surface or {}).get("geometry_targeted_row_count") or 0) > 0
                preview_requirements_met = (
                    _doctor_strict_passed(doctor_payload)
                    and grouped_warnings == 0
                    and bool(analysis_surface and analysis_surface.get("fair_budget_assets_complete"))
                    and bool(analysis_surface and analysis_surface.get("regime_assets_complete"))
                    and bool(fair_budget_surface)
                    and bool(regime_surface)
                    and int((fair_budget_surface or {}).get("blocked_headline_group_count") or 0) == 0
                    and not missing_headline_tasks
                    and int((regime_surface or {}).get("targeted_rows_missing_complete_labels_count") or 0) == 0
                    and int((regime_surface or {}).get("blocked_regime_group_count") or 0) == 0
                    and int((regime_surface or {}).get("mixed_distribution_group_count") or 0) == 0
                    and int((regime_surface or {}).get("mixed_ood_family_group_count") or 0) == 0
                    and not (regime_surface or {}).get("missing_host_requirements")
                    and (
                        not geometry_claims_present
                        or (
                            int((regime_surface or {}).get("geometry_targeted_rows_missing_complete_labels_count") or 0) == 0
                            and int((regime_surface or {}).get("geometry_targeted_rows_missing_required_metrics_count") or 0) == 0
                            and int((regime_surface or {}).get("mixed_geometry_distribution_group_count") or 0) == 0
                            and int((regime_surface or {}).get("mixed_geometry_class_group_count") or 0) == 0
                            and not (regime_surface or {}).get("missing_geometry_host_requirements")
                        )
                    )
                )
                if preview_requirements_met:
                    reasons.append("Preview release gates are satisfied.")
                    status = READY_FOR_PREVIEW_ONLY
                else:
                    if not _doctor_strict_passed(doctor_payload):
                        reasons.append("Doctor strict does not pass for the regime-aware preview profile.")
                    if grouped_warnings != 0:
                        reasons.append(f"Grouped warnings must be 0 for v1.8 closeout; found {grouped_warnings}.")
                    if not (analysis_surface and analysis_surface.get("fair_budget_assets_complete")):
                        reasons.append("One or more carried-forward fair-budget reporting assets are missing.")
                    if not (analysis_surface and analysis_surface.get("regime_assets_complete")):
                        reasons.append("One or more regime/OOD reporting artifacts are missing.")
                    if int((fair_budget_surface or {}).get("blocked_headline_group_count") or 0) != 0:
                        reasons.append("One or more headline matched-budget groups remain blocked.")
                    if missing_headline_tasks:
                        reasons.append(f"Missing headline-eligible matched-budget groups for: {', '.join(missing_headline_tasks)}.")
                    if int((regime_surface or {}).get("targeted_rows_missing_complete_labels_count") or 0) != 0:
                        reasons.append("One or more R2-A targeted grouped rows are missing complete regime labels.")
                    if int((regime_surface or {}).get("blocked_regime_group_count") or 0) != 0:
                        reasons.append("One or more headline regime groups remain blocked.")
                    if int((regime_surface or {}).get("mixed_distribution_group_count") or 0) != 0:
                        reasons.append("One or more headline regime groups mix ID and OOD rows.")
                    if int((regime_surface or {}).get("mixed_ood_family_group_count") or 0) != 0:
                        reasons.append("One or more headline regime groups mix multiple OOD protocol families.")
                    missing_host_requirements = list((regime_surface or {}).get("missing_host_requirements") or [])
                    if missing_host_requirements:
                        reasons.append(f"Missing regime host coverage for: {', '.join(missing_host_requirements)}.")
                    if geometry_claims_present:
                        if int((regime_surface or {}).get("geometry_targeted_rows_missing_complete_labels_count") or 0) != 0:
                            reasons.append("One or more geometry-targeted grouped rows are missing complete geometry or regime labels.")
                        if int((regime_surface or {}).get("geometry_targeted_rows_missing_required_metrics_count") or 0) != 0:
                            reasons.append("One or more geometry-targeted grouped rows are missing near-boundary or residual metrics.")
                        if int((regime_surface or {}).get("mixed_geometry_distribution_group_count") or 0) != 0:
                            reasons.append("One or more geometry claim groups mix multiple geometry-distribution labels.")
                        if int((regime_surface or {}).get("mixed_geometry_class_group_count") or 0) != 0:
                            reasons.append("One or more geometry claim groups mix multiple derived geometry classes.")
                        missing_geometry_host_requirements = list((regime_surface or {}).get("missing_geometry_host_requirements") or [])
                        if missing_geometry_host_requirements:
                            reasons.append(
                                f"Missing geometry host coverage for: {', '.join(missing_geometry_host_requirements)}."
                            )
                    status = INCOMPLETE
            elif spec.benchmark_line == "v1.7-preview":
                headline_tasks_with_eligible_groups = set((fair_budget_surface or {}).get("headline_tasks_with_eligible_groups") or [])
                missing_headline_tasks = sorted({"heat1d", "burgers1d", "poisson2d", "allencahn1d"} - headline_tasks_with_eligible_groups)
                preview_requirements_met = (
                    _doctor_strict_passed(doctor_payload)
                    and grouped_warnings == 0
                    and bool(analysis_surface and analysis_surface.get("fair_budget_assets_complete"))
                    and bool(fair_budget_surface)
                    and int((fair_budget_surface or {}).get("blocked_headline_group_count") or 0) == 0
                    and not missing_headline_tasks
                )
                if preview_requirements_met:
                    reasons.append("Preview release gates are satisfied.")
                    status = READY_FOR_PREVIEW_ONLY
                else:
                    if not _doctor_strict_passed(doctor_payload):
                        reasons.append("Doctor strict does not pass for the fair-budget preview profile.")
                    if grouped_warnings != 0:
                        reasons.append(f"Grouped warnings must be 0 for v1.7 closeout; found {grouped_warnings}.")
                    if not (analysis_surface and analysis_surface.get("fair_budget_assets_complete")):
                        reasons.append("One or more fair-budget reporting assets are missing.")
                    if int((fair_budget_surface or {}).get("blocked_headline_group_count") or 0) != 0:
                        reasons.append("One or more headline matched-budget groups remain blocked.")
                    if missing_headline_tasks:
                        reasons.append(f"Missing headline-eligible matched-budget groups for: {', '.join(missing_headline_tasks)}.")
                    status = INCOMPLETE
            else:
                reasons.append("Preview release gates are satisfied.")
                status = READY_FOR_PREVIEW_ONLY
    else:
        if not _core_starter_assets_present(assets):
            reasons.append("One or more core starter-pack assets or docs are missing.")
            status = INCOMPLETE
        elif reporting_rows <= 0:
            reasons.append("Reporting CSV has no rows.")
            status = INCOMPLETE
        elif _doctor_has_errors(doctor_payload):
            reasons.append("Doctor reports one or more error checks for the starter-pack profile.")
            status = INCOMPLETE
        else:
            geometry_hosts_with_complete_labels = (regime_surface or {}).get("geometry_hosts_with_complete_labels") or {}
            pointwise_geometry_hosts = set(geometry_hosts_with_complete_labels.get("pointwise_tasks") or []) if isinstance(geometry_hosts_with_complete_labels, dict) else set()
            operator_geometry_hosts = set(geometry_hosts_with_complete_labels.get("operator_tasks") or []) if isinstance(geometry_hosts_with_complete_labels, dict) else set()
            geometry_classes_present = set(((regime_surface or {}).get("regime_summary") or {}).get("geometry_classes_present") or [])
            starter_requirements_met = (
                _doctor_strict_passed(doctor_payload)
                and grouped_warnings == 0
                and bool(analysis_surface and analysis_surface.get("views_complete"))
                and bool(analysis_surface and analysis_surface.get("regime_assets_complete"))
                and bool(analysis_surface and analysis_surface.get("pack_identity_present"))
                and bool(analysis_surface and analysis_surface.get("starter_pack_identity_matches"))
                and bool(regime_surface)
                and int((regime_surface or {}).get("geometry_targeted_row_count") or 0) > 0
                and int((regime_surface or {}).get("geometry_targeted_rows_missing_geometry_labels_count") or 0) == 0
                and int((regime_surface or {}).get("geometry_targeted_rows_missing_required_metrics_count") or 0) == 0
                and int((regime_surface or {}).get("mixed_geometry_distribution_group_count") or 0) == 0
                and int((regime_surface or {}).get("mixed_geometry_class_group_count") or 0) == 0
                and not (regime_surface or {}).get("missing_geometry_host_requirements")
                and {"regular_geometry", "geometry_id", "geometry_ood"}.issubset(geometry_classes_present)
                and "poisson2d" in pointwise_geometry_hosts
                and "poisson2d_field" in operator_geometry_hosts
            )
            if starter_requirements_met:
                reasons.append("Starter-pack geometry readiness gates are satisfied.")
                status = READY_FOR_STARTER_ONLY
            else:
                if not _doctor_strict_passed(doctor_payload):
                    reasons.append("Doctor strict does not pass for the starter-pack profile.")
                if grouped_warnings != 0:
                    reasons.append(f"Grouped warnings must be 0 for the starter pack; found {grouped_warnings}.")
                if not (analysis_surface and analysis_surface.get("views_complete")):
                    reasons.append("One or more starter-pack analysis views are missing.")
                if not (analysis_surface and analysis_surface.get("regime_assets_complete")):
                    reasons.append("One or more starter-pack geometry regime artifacts are missing.")
                if not (analysis_surface and analysis_surface.get("pack_identity_present")):
                    reasons.append("Starter-pack analysis bundle is missing pack identity metadata.")
                if not (analysis_surface and analysis_surface.get("starter_pack_identity_matches")):
                    reasons.append("Starter-pack analysis bundle does not identify `post-v1.8-geometry` correctly.")
                if int((regime_surface or {}).get("geometry_targeted_row_count") or 0) <= 0:
                    reasons.append("Starter pack must contain geometry-targeted grouped rows.")
                if int((regime_surface or {}).get("geometry_targeted_rows_missing_geometry_labels_count") or 0) != 0:
                    reasons.append("One or more starter geometry rows are missing complete geometry metadata.")
                if int((regime_surface or {}).get("geometry_targeted_rows_missing_required_metrics_count") or 0) != 0:
                    reasons.append("One or more starter geometry rows are missing near-boundary or residual metrics.")
                if int((regime_surface or {}).get("mixed_geometry_distribution_group_count") or 0) != 0:
                    reasons.append("One or more starter geometry claim groups mix multiple geometry-distribution labels.")
                if int((regime_surface or {}).get("mixed_geometry_class_group_count") or 0) != 0:
                    reasons.append("One or more starter geometry claim groups mix multiple derived geometry classes.")
                missing_geometry_host_requirements = list((regime_surface or {}).get("missing_geometry_host_requirements") or [])
                if missing_geometry_host_requirements:
                    reasons.append(
                        f"Missing starter geometry host coverage for: {', '.join(missing_geometry_host_requirements)}."
                    )
                missing_geometry_classes = sorted({"regular_geometry", "geometry_id", "geometry_ood"} - geometry_classes_present)
                if missing_geometry_classes:
                    reasons.append(
                        f"Starter pack is missing geometry classes: {', '.join(missing_geometry_classes)}."
                    )
                if "poisson2d" not in pointwise_geometry_hosts or "poisson2d_field" not in operator_geometry_hosts:
                    reasons.append("Starter pack must include both `poisson2d` and `poisson2d_field` geometry hosts.")
                status = INCOMPLETE

    return {
        "identity": {
            "profile": spec.profile,
            "benchmark_line": spec.benchmark_line,
            "manifest_path": None if spec.manifest_name is None else str(_resolved_manifest_path(spec.manifest_name)),
            "outputs_root": str(outputs_root.resolve()),
            "output_dir": str(output_dir.resolve()),
            "starter_pack": spec.benchmark_line if spec.profile == STARTER_MODE else None,
            "reference_preview_line": "v1.8-preview" if spec.profile == STARTER_MODE else None,
        },
        "version_state": build_version_payload(),
        "assets": assets,
        "completeness": {
            **run_counts,
            "grouped_rows": grouped_rows,
            "grouped_warnings": grouped_warnings,
            "reporting_rows": reporting_rows,
            "pareto_rows": pareto_rows,
        },
        "health": {
            "doctor_strict_passed": _doctor_strict_passed(doctor_payload),
            "doctor_summary": doctor_payload.get("summary", {}),
            "notable_checks": _notable_checks(doctor_payload),
        },
        "operator_slice": operator_slice,
        "analysis_surface": analysis_surface,
        "fair_budget_surface": fair_budget_surface,
        "regime_surface": regime_surface,
        "formal_freeze_surface": formal_freeze_surface,
        "narrative": summary_facts,
        "verdict": {
            "status": status,
            "reasons": reasons,
        },
    }


def finalize_audit_payload(result: dict[str, Any], *, generated_at: str | None = None) -> dict[str, Any]:
    payload = dict(result)
    identity = dict(result["identity"])
    identity["generated_at"] = _utc_now() if generated_at is None else generated_at
    payload["identity"] = identity
    return payload


def render_audit_markdown(payload: dict[str, Any]) -> str:
    identity = payload["identity"]
    assets = payload["assets"]
    completeness = payload["completeness"]
    health = payload["health"]
    operator_slice = payload.get("operator_slice")
    analysis_surface = payload.get("analysis_surface")
    fair_budget_surface = payload.get("fair_budget_surface")
    regime_surface = payload.get("regime_surface")
    narrative = payload["narrative"]
    verdict = payload["verdict"]

    lines = [
        "# Audit Report",
        "",
        "## Identity",
        "",
        f"- Profile: `{identity['profile']}`",
        f"- Benchmark line: `{identity['benchmark_line']}`",
        f"- Manifest path: `{identity['manifest_path']}`",
        f"- Outputs root: `{identity['outputs_root']}`",
        f"- Output dir: `{identity['output_dir']}`",
        f"- Generated at: `{identity['generated_at']}`",
        "",
        "## Assets",
        "",
    ]
    if identity.get("starter_pack") is not None:
        lines[4:4] = [
            f"- Starter pack: `{identity['starter_pack']}`",
            f"- Reference preview line: `{identity['reference_preview_line']}`",
        ]
    for name in [
        "manifest",
        "grouped_json",
        "reporting_dir",
        "reporting_csv",
        "matched_budget_csv",
        "matched_budget_md",
        "matched_budget_tex",
        "fairness_coverage_json",
        "fairness_coverage_md",
        "regime_map_json",
        "regime_map_md",
        "ood_slice_leaderboard_csv",
        "ood_slice_leaderboard_md",
        "failure_atlas_json",
        "failure_atlas_md",
        "physics_consistency_dashboard_json",
        "physics_consistency_dashboard_md",
        "pareto_dir",
        "pareto_csv",
        "run_report_dir",
        "run_report_json",
        "run_report_csv",
        "release_snapshot",
        "analysis_dir",
        "analysis_bundle",
        "hardness_report_json",
        "observation_snapshot_json",
        "preview_evolution_record_json",
        "review_packet_json",
        "release_packet_draft_json",
        "readiness_matrix_json",
        "promotion_gap_report_json",
        "diagnostics_compact_md",
        "executive_summary_md",
        "observation_consistency_json",
        "comparison_fairness_json",
        "formal_discussion_memo_md",
        "discussion_questions_md",
        "freeze_packet_json",
        "freeze_readiness_report_json",
        "formal_baseline_summary_md",
        "v1_0_formal_manifest_json",
        "freeze_governance_record_md",
        "freeze_decision_brief_md",
        "runbook",
        "release_doc",
        "preview_doc",
        "starter_doc",
        "product_doc",
    ]:
        asset = assets[name]
        lines.append(f"- `{name}`: exists=`{asset['exists']}` path=`{asset['path']}`")

    lines.extend(
        [
            "",
            "## Completeness",
            "",
            f"- Planned: `{completeness['planned']}`",
            f"- Attempted: `{completeness['attempted']}`",
            f"- Succeeded: `{completeness['succeeded']}`",
            f"- Failed: `{completeness['failed']}`",
            f"- Skipped: `{completeness['skipped']}`",
            f"- Grouped rows: `{completeness['grouped_rows']}`",
            f"- Grouped warnings: `{completeness['grouped_warnings']}`",
            f"- Reporting rows: `{completeness['reporting_rows']}`",
            f"- Pareto rows: `{completeness['pareto_rows']}`",
            "",
            "## Health",
            "",
            f"- Doctor strict passed: `{health['doctor_strict_passed']}`",
            f"- Doctor summary: `{health['doctor_summary']}`",
        ]
    )
    notable_checks = health.get("notable_checks") or []
    if notable_checks:
        lines.extend(["- Notable checks:"])
        for check in notable_checks:
            lines.append(
                f"  - `{check['severity']}` `{check['code']}`: {check['message']} ({check.get('path')})"
            )
    else:
        lines.append("- Notable checks: none")

    if isinstance(operator_slice, dict):
        protocol_text = ', '.join(operator_slice['protocols']) if operator_slice['protocols'] else 'none'
        lines.extend(
            [
                "",
                "## Operator Slice",
                "",
                f"- Task count: `{operator_slice['task_count']}`",
                f"- Baseline count: `{operator_slice['baseline_count']}`",
                f"- Field grouped rows: `{operator_slice['field_grouped_row_count']}`",
                f"- Protocols: `{protocol_text}`",
                f"- Shape: `{operator_slice['shape']}`",
                f"- Assets complete: `{operator_slice['assets_complete']}`",
            ]
        )

    if isinstance(analysis_surface, dict):
        lines.extend(
            [
                "",
                "## Analysis Surface",
                "",
                f"- Analysis bundle present: `{analysis_surface['analysis_bundle_present']}`",
                f"- Derived views complete: `{analysis_surface['views_complete']}`",
                f"- Available views: `{analysis_surface['available_views']}`",
                f"- History entry count: `{analysis_surface['history_entry_count']}`",
                f"- Observation snapshot present: `{analysis_surface['observation_snapshot_present']}`",
                f"- Review packet present: `{analysis_surface['review_packet_present']}`",
                f"- Promotion gap report present: `{analysis_surface['promotion_gap_report_present']}`",
                f"- Provenance surface present: `{analysis_surface['provenance_surface_present']}`",
                f"- Observation consistency present: `{analysis_surface['observation_consistency_present']}`",
                f"- Comparison fairness present: `{analysis_surface['comparison_fairness_present']}`",
                f"- Fair-budget assets complete: `{analysis_surface['fair_budget_assets_complete']}`",
                f"- Regime assets complete: `{analysis_surface['regime_assets_complete']}`",
                f"- Previous-preview linkage present: `{analysis_surface['previous_preview_linkage_present']}`",
                f"- Packet completeness present: `{analysis_surface['packet_completeness_present']}`",
                f"- Formal-discussion signal present: `{analysis_surface['formal_discussion_signal_present']}`",
                f"- Formal-discussion signal: `{analysis_surface['formal_discussion_signal']}`",
                f"- Analysis readiness conclusion: `{analysis_surface['analysis_readiness_conclusion']}`",
                f"- Pack identity present: `{analysis_surface['pack_identity_present']}`",
                f"- Starter-pack identity matches: `{analysis_surface['starter_pack_identity_matches']}`",
            ]
        )

    if isinstance(fair_budget_surface, dict):
        lines.extend(
            [
                "",
                "## Fair-Budget Surface",
                "",
                f"- Matched-budget group count: `{fair_budget_surface['matched_budget_group_count']}`",
                f"- Headline group count: `{fair_budget_surface['headline_group_count']}`",
                f"- Headline-eligible group count: `{fair_budget_surface['headline_eligible_group_count']}`",
                f"- Blocked headline group count: `{fair_budget_surface['blocked_headline_group_count']}`",
                f"- Headline tasks with eligible groups: `{fair_budget_surface['headline_tasks_with_eligible_groups']}`",
                f"- Fair-budget summary: `{fair_budget_surface['fair_budget_summary']}`",
            ]
        )

    if isinstance(regime_surface, dict):
        lines.extend(
            [
                "",
                "## Regime Surface",
                "",
                f"- Regime group count: `{regime_surface['regime_group_count']}`",
                f"- Headline regime group count: `{regime_surface['headline_regime_group_count']}`",
                f"- Blocked headline regime group count: `{regime_surface['blocked_regime_group_count']}`",
                f"- Mixed ID/OOD headline groups: `{regime_surface['mixed_distribution_group_count']}`",
                f"- Mixed OOD-family headline groups: `{regime_surface['mixed_ood_family_group_count']}`",
                f"- Coverage-only regime group count: `{regime_surface['coverage_only_regime_group_count']}`",
                f"- OOD protocol families present: `{regime_surface['ood_protocol_families_present']}`",
                f"- Targeted rows missing complete labels: `{regime_surface['targeted_rows_missing_complete_labels_count']}`",
                f"- Missing host requirements: `{regime_surface['missing_host_requirements']}`",
                f"- Regime hosts with complete labels: `{regime_surface['regime_hosts_with_complete_labels']}`",
                f"- Geometry targeted row count: `{regime_surface['geometry_targeted_row_count']}`",
                f"- Geometry group count: `{regime_surface['geometry_group_count']}`",
                f"- Geometry rows missing geometry labels: `{regime_surface['geometry_targeted_rows_missing_geometry_labels_count']}`",
                f"- Geometry rows missing complete labels: `{regime_surface['geometry_targeted_rows_missing_complete_labels_count']}`",
                f"- Geometry rows missing required metrics: `{regime_surface['geometry_targeted_rows_missing_required_metrics_count']}`",
                f"- Mixed geometry-distribution groups: `{regime_surface['mixed_geometry_distribution_group_count']}`",
                f"- Mixed geometry-class groups: `{regime_surface['mixed_geometry_class_group_count']}`",
                f"- Geometry hosts with complete labels: `{regime_surface['geometry_hosts_with_complete_labels']}`",
                f"- Missing geometry host requirements: `{regime_surface['missing_geometry_host_requirements']}`",
            ]
        )

    formal_freeze_surface = payload.get("formal_freeze_surface")
    if isinstance(formal_freeze_surface, dict):
        lines.extend(
            [
                "",
                "## Formal Freeze Surface",
                "",
                f"- Assets complete: `{formal_freeze_surface['assets_complete']}`",
                f"- Available assets: `{formal_freeze_surface['available_assets']}`",
            ]
        )

    lines.extend(["", "## Narrative", ""])
    task_leaders = narrative.get("clean_task_leaders") or narrative.get("task_leaders") or []
    if task_leaders:
        lines.append("- Task leaders:")
        for leader in task_leaders:
            lines.append(
                "  - `{task_name}` -> `{run_id}` ({model_name}, {protocol_label}) rel_l2=`{eval_relative_l2_mean}` mse=`{eval_mse_mean}`".format(
                    **leader
                )
            )
    else:
        lines.append("- Task leaders: none")
    worst = narrative.get("worst_protocol_degradation")
    lines.append(f"- Worst protocol degradation: `{worst}`")
    lightest = narrative.get("lightest_family")
    lines.append(f"- Lightest family: `{lightest}`")
    lines.append(f"- Incomplete family count: `{narrative.get('incomplete_family_count', 0)}`")

    lines.extend(["", "## Verdict", "", f"- Status: `{verdict['status']}`", "- Reasons:"])
    for reason in verdict.get("reasons", []):
        lines.append(f"  - {reason}")

    next_actions: list[str]
    if verdict["status"] == READY_FOR_FREEZE:
        next_actions = ["Use the audit JSON/Markdown report as the release record sidecar."]
    elif verdict["status"] == READY_FOR_PREVIEW_ONLY:
        next_actions = [
            "Fix the listed freeze-gate issues, then rerun `pinn-bench audit`.",
            "Keep using preview/demo roots until the formal gates are clean.",
        ]
    elif verdict["status"] == READY_FOR_STARTER_ONLY:
        next_actions = [
            "Use this starter pack as the engineering entrypoint for the post-`v1.8` geometry tranche.",
            "Keep repo truth pointed at `v1.8-preview` until geometry and inverse scopes are ready for a named line decision.",
        ]
    else:
        next_actions = [
            "Repair missing machine-readable assets first.",
            "Re-export grouped/reporting/pareto assets before rerunning audit.",
        ]
    lines.extend(["", "## Next Actions", ""])
    for action in next_actions:
        lines.append(f"- {action}")
    lines.append("")
    return "\n".join(lines)






def persist_audit_outputs(*, payload: dict[str, Any], output_dir: Path, report_basename: str) -> dict[str, str]:
    output_dir.mkdir(parents=True, exist_ok=True)
    json_path = output_dir / f"{report_basename}_audit.json"
    md_path = output_dir / f"{report_basename}_audit.md"
    write_json(json_path, payload)
    md_path.write_text(render_audit_markdown(payload), encoding="utf-8")
    return {"json_path": str(json_path.resolve()), "md_path": str(md_path.resolve())}


def render_audit_summary(*, payload: dict[str, Any], written: dict[str, str] | None = None) -> str:
    verdict_status = str(payload["verdict"]["status"])
    if written is None:
        return "\n".join(
            [
                f"Audit verdict: {verdict_status}",
                "Audit artifacts were not written.",
                f"Re-run with --write to persist reports under {payload['identity']['output_dir']}.",
            ]
        )
    return "\n".join(
        [
            f"Audit JSON written to {written['json_path']}",
            f"Audit Markdown written to {written['md_path']}",
            f"Audit verdict: {verdict_status}",
        ]
    )


def _exit_code(profile: str, verdict_status: str) -> int:
    if profile == FORMAL_MODE:
        return 0 if verdict_status == READY_FOR_FREEZE else 1
    if profile == STARTER_MODE:
        return 0 if verdict_status == READY_FOR_STARTER_ONLY else 1
    return 0 if verdict_status == READY_FOR_PREVIEW_ONLY else 1




def main(argv: Sequence[str] | None = None) -> None:
    args = parse_args(argv)
    spec = resolve_audit_line(formal=args.formal, preview=args.preview, starter=args.starter)
    outputs_root = resolve_default_outputs_root(spec) if args.outputs_root is None else resolve_outputs_root(args.outputs_root)
    output_dir = resolve_default_output_dir(spec=spec, outputs_root=outputs_root) if args.output_dir is None else resolve_outputs_root(args.output_dir)
    if args.write:
        ensure_audit_write_allowed(output_dir=output_dir)
    result = compute_audit_result(spec=spec, outputs_root=outputs_root, output_dir=output_dir)
    payload = finalize_audit_payload(result)
    written = None
    if args.write:
        written = persist_audit_outputs(payload=payload, output_dir=output_dir, report_basename=spec.report_basename)
    if args.json:
        print(json.dumps(payload, indent=2))
    else:
        print(render_audit_summary(payload=payload, written=written))
    raise SystemExit(_exit_code(spec.profile, str(payload['verdict']['status'])))


if __name__ == "__main__":
    main()
