"""Optional experiment logging hooks for user-facing DX flows."""

from __future__ import annotations

import importlib
from pathlib import Path
from typing import Any

from pinn_bench.config.schema import ExperimentConfig
from pinn_bench.logging.tensorboard import TensorBoardLogger

_SUPPORTED_BACKENDS = ("basic", "none", "tensorboard", "wandb")


class NullLoggingHook:
    """No-op scalar logging hook."""

    def log_scalar(self, tag: str, value: float, step: int) -> None:
        del tag, value, step

    def close(self) -> None:
        return None


class WandbLogger:
    """Optional W&B scalar logger."""

    def __init__(self, *, config: ExperimentConfig, output_dir: Path) -> None:
        try:
            module = importlib.import_module("wandb")
        except ModuleNotFoundError as error:
            raise ValueError(
                "Logging backend 'wandb' requires the optional 'wandb' package. Install it or use --log-backend none|basic|tensorboard."
            ) from error
        project = str(config.logging.extras.get("project", "pinn_bench"))
        run_name = str(config.logging.extras.get("run_name", f"{config.task.name}_{config.model.name}_{config.train.seed}"))
        self._module = module
        self._run = module.init(
            project=project,
            name=run_name,
            dir=str(output_dir),
            config={
                "model": config.model.name,
                "task": config.task.name,
                "seed": config.train.seed,
                "backend": config.logging.backend,
            },
            reinit=True,
        )

    def log_scalar(self, tag: str, value: float, step: int) -> None:
        self._module.log({tag: value, "step": step})

    def close(self) -> None:
        finish = getattr(self._module, "finish", None)
        if callable(finish):
            finish()


class CompositeLoggingHook:
    """Chain multiple scalar logging hooks behind one interface."""

    def __init__(self, *hooks: Any) -> None:
        self._hooks = hooks

    def log_scalar(self, tag: str, value: float, step: int) -> None:
        for hook in self._hooks:
            hook.log_scalar(tag, value, step)

    def close(self) -> None:
        for hook in self._hooks:
            hook.close()



def supported_logging_backends() -> tuple[str, ...]:
    return _SUPPORTED_BACKENDS



def build_logging_hook(*, backend: str, config: ExperimentConfig, output_dir: Path) -> Any:
    normalized = str(backend or "basic").strip().lower()
    if normalized not in _SUPPORTED_BACKENDS:
        supported = ", ".join(_SUPPORTED_BACKENDS)
        raise ValueError(f"Unsupported logging backend '{backend}'. Supported backends: {supported}")
    if normalized in {"basic", "none"}:
        return NullLoggingHook()
    if normalized == "tensorboard":
        return CompositeLoggingHook(TensorBoardLogger(enabled=True, log_dir=output_dir / "tensorboard"))
    return CompositeLoggingHook(WandbLogger(config=config, output_dir=output_dir))
