"""Results schemas and writers."""

from pinn_bench.results.schema import (
    GeometryMetadata,
    InverseMetadata,
    RegimeMetadata,
    RobustnessMetadata,
    RunMetadata,
    RunResults,
    TrainSummary,
)
from pinn_bench.results.writer import (
    save_config_snapshot,
    save_model,
    write_metrics,
    write_train_log,
)

__all__ = [
    "GeometryMetadata",
    "InverseMetadata",
    "RegimeMetadata",
    "RobustnessMetadata",
    "RunMetadata",
    "RunResults",
    "TrainSummary",
    "save_config_snapshot",
    "save_model",
    "write_metrics",
    "write_train_log",
]
