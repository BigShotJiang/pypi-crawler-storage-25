"""Result schemas for benchmark outputs."""

from __future__ import annotations

from dataclasses import dataclass, field

from pinn_bench.comparison import ComparisonConfig


@dataclass
class RegimeMetadata:
    """Regime-slice metadata written additively with each run."""

    protocol_family: str
    slice_id: str
    shift_dimension: str
    train_variant_label: str
    eval_variant_label: str
    parameter_name: str | None = None

    def to_dict(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "protocol_family": self.protocol_family,
            "slice_id": self.slice_id,
            "shift_dimension": self.shift_dimension,
            "train_variant_label": self.train_variant_label,
            "eval_variant_label": self.eval_variant_label,
        }
        if self.parameter_name is not None:
            payload["parameter_name"] = str(self.parameter_name)
        return payload


@dataclass
class GeometryMetadata:
    """Geometry-slice metadata written additively with each run."""

    representation: str
    geometry_split_id: str
    train_geometry_family: str
    eval_geometry_family: str
    geometry_distribution: str
    boundary_band_epsilon: float

    def to_dict(self) -> dict[str, object]:
        return {
            "representation": self.representation,
            "geometry_split_id": self.geometry_split_id,
            "train_geometry_family": self.train_geometry_family,
            "eval_geometry_family": self.eval_geometry_family,
            "geometry_distribution": self.geometry_distribution,
            "boundary_band_epsilon": float(self.boundary_band_epsilon),
        }


@dataclass
class InverseMetadata:
    """Inverse-slice metadata written additively with each run."""

    observation_budget_class: str
    observation_pattern_family: str
    inverse_target_family: str
    inverse_parameter_name: str
    inverse_target_type: str = "parameter"
    true_parameter_value: float | None = None
    estimated_parameter_value: float | None = None
    supervision_source: str | None = None
    diagnostic_status: str | None = None
    diagnostic_reason: str | None = None
    identifiability_metadata: dict[str, object] = field(default_factory=dict)

    def to_dict(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "observation_budget_class": self.observation_budget_class,
            "observation_pattern_family": self.observation_pattern_family,
            "inverse_target_family": self.inverse_target_family,
            "inverse_target_type": self.inverse_target_type,
            "inverse_parameter_name": self.inverse_parameter_name,
            "identifiability_metadata": dict(self.identifiability_metadata),
        }
        if self.true_parameter_value is not None:
            payload["true_parameter_value"] = float(self.true_parameter_value)
        if self.estimated_parameter_value is not None:
            payload["estimated_parameter_value"] = float(self.estimated_parameter_value)
        if self.supervision_source is not None:
            payload["supervision_source"] = str(self.supervision_source)
        if self.diagnostic_status is not None:
            payload["diagnostic_status"] = str(self.diagnostic_status)
        if self.diagnostic_reason is not None:
            payload["diagnostic_reason"] = str(self.diagnostic_reason)
        return payload


@dataclass
class RobustnessMetadata:
    """Robustness information written with each run."""

    protocol: str = "none"
    level: float = 0.0
    severity_label: str | None = None
    target_scopes: list[str] = field(default_factory=list)
    components: list[dict[str, object]] = field(default_factory=list)
    train_time_range: list[float] | None = None
    eval_time_range: list[float] | None = None
    train_support_ratio: float | None = None
    support_axis: str | None = None

    def to_dict(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "protocol": self.protocol,
            "level": self.level,
            "target_scopes": list(self.target_scopes),
        }
        if self.components:
            payload["components"] = [dict(component) for component in self.components]
        if self.severity_label is not None:
            payload["severity_label"] = str(self.severity_label)
        if self.train_time_range is not None:
            payload["train_time_range"] = list(self.train_time_range)
        if self.eval_time_range is not None:
            payload["eval_time_range"] = list(self.eval_time_range)
        if self.train_support_ratio is not None:
            payload["train_support_ratio"] = float(self.train_support_ratio)
        if self.support_axis is not None:
            payload["support_axis"] = str(self.support_axis)
        return payload


@dataclass
class ExternalModelMetadata:
    """External model identity written additively with each run."""

    external_model_id: str
    source_benchmark: str
    source_family_name: str
    canonical_name: str
    integration_state: str
    adapter_name: str | None = None
    runnable_status: str | None = None
    native_equivalent: str | None = None
    is_pinn_family: bool = False
    is_operator_family: bool = False
    is_solver_adjacent: bool = False
    comparability_scope: str | None = None
    capability_tags: list[str] = field(default_factory=list)
    repo_path: str | None = None

    def to_dict(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "external_model_id": self.external_model_id,
            "source_benchmark": self.source_benchmark,
            "source_family_name": self.source_family_name,
            "canonical_name": self.canonical_name,
            "integration_state": self.integration_state,
            "is_pinn_family": bool(self.is_pinn_family),
            "is_operator_family": bool(self.is_operator_family),
            "is_solver_adjacent": bool(self.is_solver_adjacent),
            "capability_tags": list(self.capability_tags),
        }
        if self.adapter_name is not None:
            payload["adapter_name"] = self.adapter_name
        if self.runnable_status is not None:
            payload["runnable_status"] = self.runnable_status
        if self.native_equivalent is not None:
            payload["native_equivalent"] = self.native_equivalent
        if self.comparability_scope is not None:
            payload["comparability_scope"] = self.comparability_scope
        if self.repo_path is not None:
            payload["repo_path"] = self.repo_path
        return payload


@dataclass
class PrimaryMethodMetadata:
    """Primary benchmark-method metadata written additively with each run."""

    method_id: str
    method_name: str
    top_level_family: str
    benchmark_primary_subfamily: bool
    formulation_type: str
    internalization_level: str
    runnable_status: str
    comparability_status: str
    evidence_status: str
    source_lineage: list[str] = field(default_factory=list)
    default_runtime_name: str | None = None

    def to_dict(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "method_id": self.method_id,
            "method_name": self.method_name,
            "top_level_family": self.top_level_family,
            "benchmark_primary_subfamily": bool(self.benchmark_primary_subfamily),
            "formulation_type": self.formulation_type,
            "internalization_level": self.internalization_level,
            "runnable_status": self.runnable_status,
            "comparability_status": self.comparability_status,
            "evidence_status": self.evidence_status,
            "source_lineage": list(self.source_lineage),
        }
        if self.default_runtime_name is not None:
            payload["default_runtime_name"] = str(self.default_runtime_name)
        return payload


@dataclass
class RunMetadata:
    """Run metadata written for each experiment."""

    task_name: str
    model_name: str
    seed: int
    device: str
    robustness: RobustnessMetadata = field(default_factory=RobustnessMetadata)
    parameter_count: int | None = None
    task_parameter_count: int | None = None
    total_trainable_parameter_count: int | None = None
    model_mode: str | None = None
    task_mode: str | None = None
    evaluation_mode: str | None = None
    comparison: ComparisonConfig | None = None
    regime: RegimeMetadata | None = None
    geometry: GeometryMetadata | None = None
    inverse: InverseMetadata | None = None
    external_model: ExternalModelMetadata | None = None
    primary_method: PrimaryMethodMetadata | None = None

    def to_dict(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "task_name": self.task_name,
            "model_name": self.model_name,
            "seed": self.seed,
            "device": self.device,
            "robustness": self.robustness.to_dict(),
        }
        if self.parameter_count is not None:
            payload["parameter_count"] = int(self.parameter_count)
        if self.task_parameter_count is not None:
            payload["task_parameter_count"] = int(self.task_parameter_count)
        if self.total_trainable_parameter_count is not None:
            payload["total_trainable_parameter_count"] = int(self.total_trainable_parameter_count)
        if self.model_mode is not None:
            payload["model_mode"] = str(self.model_mode)
        if self.task_mode is not None:
            payload["task_mode"] = str(self.task_mode)
        if self.evaluation_mode is not None:
            payload["evaluation_mode"] = str(self.evaluation_mode)
        if self.comparison is not None:
            payload["comparison"] = self.comparison.to_dict()
        if self.regime is not None:
            payload["regime"] = self.regime.to_dict()
        if self.geometry is not None:
            payload["geometry"] = self.geometry.to_dict()
        if self.inverse is not None:
            payload["inverse"] = self.inverse.to_dict()
        if self.external_model is not None:
            payload["external_model"] = self.external_model.to_dict()
        if self.primary_method is not None:
            payload["primary_method"] = self.primary_method.to_dict()
        return payload


@dataclass
class TrainSummary:
    """Training summary written for each run."""

    final_loss: float
    best_loss: float
    epochs: int
    final_loss_terms: dict[str, float] = field(default_factory=dict)
    duration_seconds: float | None = None

    def to_dict(self) -> dict[str, float | int | dict[str, float]]:
        payload: dict[str, float | int | dict[str, float]] = {
            "final_loss": self.final_loss,
            "best_loss": self.best_loss,
            "epochs": self.epochs,
            "final_loss_terms": dict(self.final_loss_terms),
        }
        if self.duration_seconds is not None:
            payload["duration_seconds"] = float(self.duration_seconds)
        return payload


@dataclass
class RunResults:
    """Structured run results written to metrics.json."""

    metadata: RunMetadata
    train: TrainSummary
    eval: dict[str, float] = field(default_factory=dict)

    def to_dict(self) -> dict[str, object]:
        return {
            "metadata": self.metadata.to_dict(),
            "train": self.train.to_dict(),
            "eval": dict(self.eval),
        }
