"""Writers for config, metrics, logs, and model artifacts."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

import torch
import yaml

from pinn_bench.config.schema import ExperimentConfig
from pinn_bench.provenance import infer_line_and_manifest, write_run_provenance
from pinn_bench.utils.io import write_csv, write_json


def save_config_snapshot(config: ExperimentConfig, output_dir: Path) -> Path:
    """Write the final resolved config snapshot."""
    path = output_dir / "config_snapshot.yaml"
    with path.open("w", encoding="utf-8") as handle:
        yaml.safe_dump(config.to_dict(), handle, sort_keys=False)
    return path


def write_metrics(metrics: Mapping[str, Any], output_dir: Path) -> Path:
    """Write metrics JSON payload."""
    path = output_dir / "metrics.json"
    write_json(path=path, payload=dict(metrics))
    return path


def write_train_log(history: Sequence[Mapping[str, Any]], output_dir: Path) -> Path:
    """Write per-epoch training log CSV."""
    path = output_dir / "train_log.csv"
    rows = [dict(item) for item in history]
    if not rows:
        write_csv(path=path, rows=[], fieldnames=["epoch", "loss"])
        return path

    fieldnames: list[str] = []
    for row in rows:
        for key in row.keys():
            if key not in fieldnames:
                fieldnames.append(key)
    write_csv(path=path, rows=rows, fieldnames=fieldnames)
    return path



def write_provenance(*, config: ExperimentConfig, metrics: Mapping[str, Any], output_dir: Path) -> Path:
    """Write optional additive provenance facts for reproducibility-aware preview lines."""
    benchmark_line, _manifest_path = infer_line_and_manifest(output_dir)
    if benchmark_line != "v0.9-preview":
        return output_dir / "provenance.json"
    return write_run_provenance(run_dir=output_dir, config_payload=config.to_dict(), metrics_payload=dict(metrics))

def save_model(model: torch.nn.Module, output_dir: Path) -> Path:
    """Save final model checkpoint."""
    path = output_dir / "model.pt"
    torch.save(model.state_dict(), path)
    return path
