"""Lightweight multi-fidelity correction MLP for bounded MF-PIDNN-style runtime support."""

from __future__ import annotations

from typing import Any

import torch
from torch import nn

from pinn_bench.models.base import BaseModel
from pinn_bench.models.mlp import _build_activation
from pinn_bench.registry import register_model


def _build_mlp(layer_dims: list[int], activation: str) -> nn.Sequential:
    layers: list[nn.Module] = []
    for idx in range(len(layer_dims) - 1):
        layers.append(nn.Linear(layer_dims[idx], layer_dims[idx + 1]))
        if idx < len(layer_dims) - 2:
            layers.append(_build_activation(activation))
    return nn.Sequential(*layers)


@register_model("mf_pidnn_mlp")
class MultiFidelityMLP(BaseModel):
    """Two-stage low-/high-fidelity correction network."""

    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        hidden_dims: list[int] | None = None,
        activation: str = "tanh",
        correction_scale: float = 1.0,
        correction_penalty_weight: float = 1e-5,
        **_: Any,
    ) -> None:
        super().__init__()
        hidden_dims = [int(value) for value in (hidden_dims or [64, 64])]
        layer_dims = [int(input_dim), *hidden_dims, int(output_dim)]
        self.low_fidelity_net = _build_mlp(layer_dims, activation)
        self.high_fidelity_correction_net = _build_mlp(layer_dims, activation)
        self.correction_scale = float(correction_scale)
        self.correction_penalty_weight = float(correction_penalty_weight)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        low = self.low_fidelity_net(x)
        correction = self.high_fidelity_correction_net(x)
        return low + self.correction_scale * correction

    def extra_loss_terms(self) -> dict[str, torch.Tensor]:
        penalty = torch.zeros((), device=next(self.parameters()).device)
        for parameter in self.high_fidelity_correction_net.parameters():
            penalty = penalty + parameter.square().mean()
        return {"multifidelity_correction_penalty": penalty * self.correction_penalty_weight}
