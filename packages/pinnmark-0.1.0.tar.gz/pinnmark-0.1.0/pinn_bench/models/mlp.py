"""Minimal MLP model for Phase 1."""

from __future__ import annotations

from typing import Any

import torch
from torch import nn

from pinn_bench.models.base import BaseModel
from pinn_bench.registry import register_model


def _build_activation(name: str) -> nn.Module:
    activation_name = name.lower()
    activation_map = {
        "relu": nn.ReLU,
        "gelu": nn.GELU,
        "tanh": nn.Tanh,
        "silu": nn.SiLU,
    }
    if activation_name not in activation_map:
        supported = ", ".join(sorted(activation_map))
        raise ValueError(f"Unsupported activation '{name}'. Supported: {supported}")
    return activation_map[activation_name]()


@register_model("mlp")
class MLP(BaseModel):
    """Simple fully-connected network."""

    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        hidden_dims: list[int] | None = None,
        activation: str = "tanh",
        **_: Any,
    ) -> None:
        super().__init__()
        hidden_dims = hidden_dims or [64, 64, 64]
        layer_dims = [input_dim, *hidden_dims, output_dim]

        layers: list[nn.Module] = []
        for idx in range(len(layer_dims) - 1):
            in_features = layer_dims[idx]
            out_features = layer_dims[idx + 1]
            layers.append(nn.Linear(in_features, out_features))
            if idx < len(layer_dims) - 2:
                layers.append(_build_activation(activation))

        self.network = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.network(x)

