"""Bounded runnable implementations for advanced primary methods.

These models are not claimed as full source-faithful reproductions. They provide
method-typed runnable paths so the primary method universe can be executed
honestly under one of:

- bounded_native_runnable
- source_backed_runnable
- task_scoped_runnable
"""

from __future__ import annotations

from typing import Any

import torch
from torch import nn

from pinn_bench.models.base import BaseModel, BaseOperatorModel
from pinn_bench.models.mlp import _build_activation
from pinn_bench.registry import register_model


def _safe_interior_inputs(batches: Any) -> torch.Tensor | None:
    interior = getattr(batches, "interior", None)
    if interior is None or getattr(interior, "inputs", None) is None:
        return None
    x = interior.inputs.detach().clone()
    x.requires_grad_(True)
    return x


def _operator_supervision_inputs(batches: Any) -> tuple[torch.Tensor, torch.Tensor] | None:
    supervision = getattr(batches, "supervision", None)
    if supervision is None or getattr(supervision, "inputs", None) is None:
        return None
    metadata = getattr(supervision, "metadata", {}) or {}
    condition_inputs = metadata.get("condition_inputs")
    if condition_inputs is None:
        return None
    query_inputs = supervision.inputs.detach().clone()
    query_inputs.requires_grad_(True)
    return condition_inputs.detach().clone(), query_inputs


class _SimpleMLP(nn.Module):
    def __init__(self, dims: list[int], activation: str) -> None:
        super().__init__()
        layers: list[nn.Module] = []
        for idx, (in_dim, out_dim) in enumerate(zip(dims[:-1], dims[1:])):
            layers.append(nn.Linear(int(in_dim), int(out_dim)))
            if idx < len(dims) - 2:
                layers.append(_build_activation(activation))
        self.net = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


@register_model("vpinn_variational_mlp")
class VariationalPINNModel(BaseModel):
    """Bounded task-scoped runnable surrogate for VPINN-like methods."""

    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        hidden_dims: list[int] | None = None,
        activation: str = "tanh",
        variational_weight: float = 1e-3,
        **_: Any,
    ) -> None:
        super().__init__()
        hidden_dims = [int(value) for value in (hidden_dims or [64, 64])]
        self.network = _SimpleMLP([int(input_dim), *hidden_dims, int(output_dim)], activation)
        self.variational_weight = float(variational_weight)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.network(x)

    def method_loss_terms(self, *, batches: Any, **_: Any) -> dict[str, torch.Tensor]:
        interior_inputs = _safe_interior_inputs(batches)
        if interior_inputs is None:
            return {}
        predictions = self.forward(interior_inputs)
        gradient = torch.autograd.grad(predictions.sum(), interior_inputs, create_graph=True)[0]
        return {"variational_energy": gradient.square().mean() * self.variational_weight}


@register_model("hp_vpinn_variational_mlp")
class HPVariationalPINNModel(VariationalPINNModel):
    """Bounded task-scoped runnable surrogate for hp-VPINN-like methods."""

    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        hidden_dims: list[int] | None = None,
        activation: str = "tanh",
        variational_weight: float = 1e-3,
        partition_weight: float = 5e-4,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            input_dim=input_dim,
            output_dim=output_dim,
            hidden_dims=hidden_dims,
            activation=activation,
            variational_weight=variational_weight,
            **kwargs,
        )
        self.partition_weight = float(partition_weight)

    def method_loss_terms(self, *, batches: Any, **kwargs: Any) -> dict[str, torch.Tensor]:
        payload = super().method_loss_terms(batches=batches, **kwargs)
        interior_inputs = _safe_interior_inputs(batches)
        if interior_inputs is None or interior_inputs.shape[0] < 2:
            return payload
        predictions = self.forward(interior_inputs)
        midpoint = interior_inputs[:, :1].median()
        left = predictions[interior_inputs[:, 0:1] <= midpoint]
        right = predictions[interior_inputs[:, 0:1] > midpoint]
        if left.numel() == 0 or right.numel() == 0:
            payload["hp_partition_consistency"] = predictions.square().mean() * 0.0
        else:
            payload["hp_partition_consistency"] = (left.mean() - right.mean()).square() * self.partition_weight
        return payload


@register_model("sa_pinn_mlp")
class SAPINNModel(BaseModel):
    """Self-adaptive weighting PINN with trainable loss weights."""

    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        hidden_dims: list[int] | None = None,
        activation: str = "tanh",
        **_: Any,
    ) -> None:
        super().__init__()
        hidden_dims = [int(value) for value in (hidden_dims or [64, 64])]
        self.network = _SimpleMLP([int(input_dim), *hidden_dims, int(output_dim)], activation)
        self.log_weight_physics = nn.Parameter(torch.zeros(()))
        self.log_weight_boundary = nn.Parameter(torch.zeros(()))
        self.log_weight_initial = nn.Parameter(torch.zeros(()))
        self.log_weight_supervision = nn.Parameter(torch.zeros(()))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.network(x)

    def loss_weight_overrides(self, *, base_weights: dict[str, float], **_: Any) -> dict[str, float]:
        payload = dict(base_weights)
        payload["physics"] = float(torch.nn.functional.softplus(self.log_weight_physics).detach().item() + 1e-3)
        payload["boundary"] = float(torch.nn.functional.softplus(self.log_weight_boundary).detach().item() + 1e-3)
        payload["initial"] = float(torch.nn.functional.softplus(self.log_weight_initial).detach().item() + 1e-3)
        payload["supervision"] = float(torch.nn.functional.softplus(self.log_weight_supervision).detach().item() + 1e-3)
        return payload


class _ResidualBlock(nn.Module):
    def __init__(self, width: int, activation: str) -> None:
        super().__init__()
        self.lin1 = nn.Linear(width, width)
        self.lin2 = nn.Linear(width, width)
        self.alpha = nn.Parameter(torch.tensor(0.1))
        self.activation = _build_activation(activation)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        x = self.activation(self.lin1(x))
        x = self.lin2(x)
        return residual + self.alpha * x


@register_model("piratenets_mlp")
class PirateNetsModel(BaseModel):
    """Residual-adaptive bounded runnable architecture for PirateNets-like methods."""

    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        hidden_dims: list[int] | None = None,
        activation: str = "tanh",
        **_: Any,
    ) -> None:
        super().__init__()
        hidden_dims = [int(value) for value in (hidden_dims or [64, 64])]
        width = hidden_dims[0]
        self.input_proj = nn.Linear(int(input_dim), width)
        self.blocks = nn.ModuleList([_ResidualBlock(width, activation) for _ in hidden_dims])
        self.output_proj = nn.Linear(width, int(output_dim))
        self.activation = _build_activation(activation)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.activation(self.input_proj(x))
        for block in self.blocks:
            x = self.activation(block(x))
        return self.output_proj(x)


@register_model("pinnsformer_model")
class PINNsFormerModel(BaseModel):
    """Minimal transformer-style bounded runnable architecture for PINNsFormer."""

    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        model_dim: int = 64,
        num_heads: int = 4,
        num_layers: int = 2,
        **_: Any,
    ) -> None:
        super().__init__()
        self.input_dim = int(input_dim)
        self.scalar_embed = nn.Linear(1, model_dim)
        self.position_embed = nn.Parameter(torch.zeros(1, self.input_dim, model_dim))
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=model_dim,
            nhead=int(num_heads),
            dim_feedforward=model_dim * 2,
            batch_first=True,
            activation="gelu",
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=int(num_layers))
        self.head = nn.Linear(model_dim, int(output_dim))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        tokens = self.scalar_embed(x.unsqueeze(-1)) + self.position_embed[:, : x.shape[1], :]
        encoded = self.encoder(tokens)
        pooled = encoded.mean(dim=1)
        return self.head(pooled)


@register_model("piann_model")
class PIANNModel(BaseModel):
    """Attention/recurrent bounded runnable architecture for PIANN-like methods."""

    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        hidden_dim: int = 64,
        **_: Any,
    ) -> None:
        super().__init__()
        self.input_dim = int(input_dim)
        self.scalar_embed = nn.Linear(1, hidden_dim)
        self.gru = nn.GRU(hidden_dim, hidden_dim, batch_first=True, bidirectional=True)
        self.attn = nn.Linear(hidden_dim * 2, 1)
        self.head = nn.Linear(hidden_dim * 2, int(output_dim))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        tokens = self.scalar_embed(x.unsqueeze(-1))
        encoded, _ = self.gru(tokens)
        scores = torch.softmax(self.attn(encoded).squeeze(-1), dim=1).unsqueeze(-1)
        pooled = (encoded * scores).sum(dim=1)
        return self.head(pooled)


@register_model("spinn_model")
class SPINNModel(BaseModel):
    """Separable factorized bounded runnable architecture for SPINN-like methods."""

    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        latent_dim: int = 32,
        hidden_dim: int = 32,
        activation: str = "tanh",
        **_: Any,
    ) -> None:
        super().__init__()
        self.input_dim = int(input_dim)
        self.factor_nets = nn.ModuleList(
            [_SimpleMLP([1, hidden_dim, int(latent_dim)], activation) for _ in range(self.input_dim)]
        )
        self.head = nn.Linear(int(latent_dim), int(output_dim))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        factors = []
        for index, net in enumerate(self.factor_nets):
            factors.append(net(x[:, index : index + 1]))
        fused = torch.stack(factors, dim=0).prod(dim=0)
        return self.head(fused)


@register_model("causal_sweeping_mlp")
class CausalSweepingPINNModel(BaseModel):
    """Task-scoped runnable model with causal training schedule hooks."""

    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        hidden_dims: list[int] | None = None,
        activation: str = "tanh",
        **_: Any,
    ) -> None:
        super().__init__()
        hidden_dims = [int(value) for value in (hidden_dims or [64, 64])]
        self.network = _SimpleMLP([int(input_dim), *hidden_dims, int(output_dim)], activation)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.network(x)

    def loss_weight_overrides(
        self,
        *,
        epoch: int,
        total_epochs: int,
        base_weights: dict[str, float],
        **_: Any,
    ) -> dict[str, float]:
        payload = dict(base_weights)
        progress = float(epoch) / float(max(1, total_epochs))
        payload["initial"] = max(payload.get("initial", 1.0), 1.0 + (1.0 - progress))
        payload["boundary"] = max(payload.get("boundary", 1.0), 1.0 + 0.5 * (1.0 - progress))
        payload["physics"] = max(payload.get("physics", 1.0), 0.5 + progress)
        return payload


class _OperatorMLP(nn.Module):
    def __init__(self, dims: list[int], activation: str) -> None:
        super().__init__()
        self.net = _SimpleMLP(dims, activation)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class _OperatorResponseBase(BaseOperatorModel):
    model_mode = "field"

    def __init__(
        self,
        *,
        query_dim: int = 2,
        condition_dim: int = 11,
        output_dim: int = 1,
        hidden_dims: list[int] | None = None,
        activation: str = "tanh",
    ) -> None:
        super().__init__()
        hidden_dims = [int(value) for value in (hidden_dims or [64, 64])]
        self.query_dim = int(query_dim)
        self.condition_dim = int(condition_dim)
        self.output_dim = int(output_dim)
        self.branch = _OperatorMLP([self.condition_dim, *hidden_dims, self.output_dim * hidden_dims[-1]], activation)
        self.trunk = _OperatorMLP([self.query_dim, *hidden_dims, self.output_dim * hidden_dims[-1]], activation)
        self.latent_dim = hidden_dims[-1]
        self.bias = nn.Parameter(torch.zeros(self.output_dim))

    def _geometry_embedding(self, metadata: dict[str, Any] | None, batch: int, device: torch.device) -> torch.Tensor:
        del metadata
        return torch.zeros(batch, self.latent_dim, device=device)

    def forward_field(
        self,
        condition_inputs: torch.Tensor | None,
        query_inputs: torch.Tensor | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> torch.Tensor:
        if condition_inputs is None or query_inputs is None:
            raise ValueError(f"{self.__class__.__name__} requires both condition_inputs and query_inputs.")
        branch = self.branch(condition_inputs).reshape(condition_inputs.shape[0], self.output_dim, self.latent_dim)
        trunk = self.trunk(query_inputs).reshape(query_inputs.shape[0], self.output_dim, self.latent_dim)
        geometry = self._geometry_embedding(metadata, query_inputs.shape[0], query_inputs.device).unsqueeze(1)
        trunk = torch.tanh(trunk + geometry)
        return torch.einsum("bcl,bcl->bc", branch, trunk) + self.bias

    def _field_smoothness_penalty(self, *, batches: Any) -> torch.Tensor:
        payload = _operator_supervision_inputs(batches)
        if payload is None:
            return torch.zeros((), device=next(self.parameters()).device)
        condition_inputs, query_inputs = payload
        predictions = self.forward_field(condition_inputs, query_inputs, getattr(getattr(batches, "supervision", None), "metadata", None))
        gradient = torch.autograd.grad(predictions.sum(), query_inputs, create_graph=True)[0]
        return gradient.square().mean()


@register_model("pino_operator")
class PINOOperatorModel(_OperatorResponseBase):
    """Bounded native runnable operator with physics-style regularization for PINO."""

    def __init__(self, *args: Any, physics_weight: float = 1e-3, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.physics_weight = float(physics_weight)

    def method_loss_terms(self, *, batches: Any, **_: Any) -> dict[str, torch.Tensor]:
        return {"operator_physics_surrogate": self._field_smoothness_penalty(batches=batches) * self.physics_weight}


@register_model("pi_deeponet_operator")
class PIDeepONetOperatorModel(_OperatorResponseBase):
    """Bounded source-backed runnable PI-DeepONet-style operator."""

    def __init__(self, *args: Any, physics_weight: float = 1e-3, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.physics_weight = float(physics_weight)

    def method_loss_terms(self, *, batches: Any, **_: Any) -> dict[str, torch.Tensor]:
        return {"pi_deeponet_physics": self._field_smoothness_penalty(batches=batches) * self.physics_weight}


@register_model("pi_dion_operator")
class PIDIONOperatorModel(_OperatorResponseBase):
    """Bounded runnable inverse-operator surrogate for PI-DION-like methods."""

    def __init__(self, *args: Any, inverse_weight: float = 1e-3, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.inverse_head = nn.Linear(self.latent_dim, self.output_dim)
        self.inverse_weight = float(inverse_weight)

    def method_loss_terms(self, *, batches: Any, **_: Any) -> dict[str, torch.Tensor]:
        payload = _operator_supervision_inputs(batches)
        if payload is None:
            return {}
        condition_inputs, _query_inputs = payload
        branch_state = self.branch(condition_inputs).reshape(condition_inputs.shape[0], self.output_dim, self.latent_dim)
        inverse_state = self.inverse_head(branch_state.mean(dim=1))
        return {"inverse_operator_surrogate": inverse_state.square().mean() * self.inverse_weight}


@register_model("pi_gano_operator")
class PIGANOOperatorModel(_OperatorResponseBase):
    """Bounded geometry-aware operator runtime for PI-GANO-like methods."""

    def __init__(self, *args: Any, geometry_dim: int = 4, geometry_weight: float = 1e-3, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.geometry_dim = int(geometry_dim)
        self.geometry_encoder = nn.Linear(self.geometry_dim, self.latent_dim)
        self.geometry_weight = float(geometry_weight)

    def _geometry_embedding(self, metadata: dict[str, Any] | None, batch: int, device: torch.device) -> torch.Tensor:
        if metadata is None:
            geometry_code = torch.zeros(batch, self.geometry_dim, device=device)
        else:
            geometry_code = metadata.get("geometry_code")
            if geometry_code is None:
                geometry_code = torch.zeros(batch, self.geometry_dim, device=device)
            elif not torch.is_tensor(geometry_code):
                geometry_code = torch.as_tensor(geometry_code, dtype=torch.float32, device=device)
        return self.geometry_encoder(geometry_code)

    def method_loss_terms(self, *, batches: Any, **_: Any) -> dict[str, torch.Tensor]:
        return {"geometry_operator_surrogate": self._field_smoothness_penalty(batches=batches) * self.geometry_weight}


@register_model("vino_operator")
class VINOOperatorModel(_OperatorResponseBase):
    """Bounded task-scoped runnable variational operator surrogate for VINO."""

    def __init__(self, *args: Any, variational_weight: float = 1e-3, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.variational_weight = float(variational_weight)

    def method_loss_terms(self, *, batches: Any, **_: Any) -> dict[str, torch.Tensor]:
        return {"variational_operator_energy": self._field_smoothness_penalty(batches=batches) * self.variational_weight}
