"""Surface-aware comparability map for external model families."""

from __future__ import annotations

from dataclasses import dataclass
import json
from functools import lru_cache
from pathlib import Path

from pinn_bench.models.external_registry import ExternalModelRecord, list_external_model_records

SURFACES = (
    "nominal_anchor",
    "inverse_core",
    "sparse_extension",
    "noisy_extension",
    "joint_local_grid",
    "transfer_expansion",
    "reference_context",
)

STATUS_MAINLINE = "mainline_comparable"
STATUS_NOMINAL_ONLY = "nominal_only_comparable"
STATUS_INVERSE_CORE = "inverse_core_comparable"
STATUS_BOUNDED = "bounded_comparable"
STATUS_APPENDIX = "appendix_only_comparable"
STATUS_RUNNABLE_NOT_YET = "runnable_but_not_yet_comparable"
STATUS_REGISTRY_ONLY = "registry_only"
STATUS_BLOCKED = "blocked"


@dataclass(frozen=True)
class ExternalModelComparabilityRecord:
    external_model_id: str
    canonical_name: str
    source_benchmark: str
    model_category: str
    integration_state: str
    runnable_status: str
    nominal_anchor_status: str
    inverse_core_status: str
    sparse_extension_status: str
    noisy_extension_status: str
    joint_local_grid_status: str
    transfer_expansion_status: str
    reference_context_status: str
    headline_eligibility: str
    benchmark_scope: str
    comparability_reason: str
    blocking_reason: str
    required_conditions: str
    notes: str

    def to_dict(self) -> dict[str, object]:
        return {
            "external_model_id": self.external_model_id,
            "canonical_name": self.canonical_name,
            "source_benchmark": self.source_benchmark,
            "model_category": self.model_category,
            "integration_state": self.integration_state,
            "runnable_status": self.runnable_status,
            "nominal_anchor_status": self.nominal_anchor_status,
            "inverse_core_status": self.inverse_core_status,
            "sparse_extension_status": self.sparse_extension_status,
            "noisy_extension_status": self.noisy_extension_status,
            "joint_local_grid_status": self.joint_local_grid_status,
            "transfer_expansion_status": self.transfer_expansion_status,
            "reference_context_status": self.reference_context_status,
            "headline_eligibility": self.headline_eligibility,
            "benchmark_scope": self.benchmark_scope,
            "comparability_reason": self.comparability_reason,
            "blocking_reason": self.blocking_reason,
            "required_conditions": self.required_conditions,
            "notes": self.notes,
        }

    def surface_status(self, surface: str) -> str:
        mapping = {
            "nominal_anchor": self.nominal_anchor_status,
            "inverse_core": self.inverse_core_status,
            "sparse_extension": self.sparse_extension_status,
            "noisy_extension": self.noisy_extension_status,
            "joint_local_grid": self.joint_local_grid_status,
            "transfer_expansion": self.transfer_expansion_status,
            "reference_context": self.reference_context_status,
        }
        return mapping[str(surface)]


_DIRECT_POINTWISE_FAMILIES = {
    "PINNacle::fnn",
    "PINNacle::laaf",
    "PDENNEval::PINN",
    "PDEBench::pinn",
}
_DECOMPOSITION_PROXY_FAMILIES = {"PINNacle::fbpinns"}
_FRAMEWORK_ONLY_FAMILIES = {"PINNacle::deepxde"}
_TASK_HOOK_BLOCKED_FAMILIES: set[str] = set()
_TASK_CONSTRAINED_RUNNABLE_FAMILIES = {"PINNacle::hard_constraint"}
_VARIATIONAL_BLOCKED_FAMILIES = {"PINNacle::vpinn"}
_SECOND_WAVE_OPERATOR_FAMILIES = {
    "PDENNEval::PINO",
    "PDENNEval::DeepONet",
    "PDENNEval::FNO",
    "PDEBench::fno",
}
_OPERATOR_APPENDIX_INCLUDED = {
    "PDEBench::fno",
    "PDENNEval::FNO",
    "PDENNEval::DeepONet",
}
_OPERATOR_APPENDIX_ASSESSED_ONLY = {
    "PDENNEval::PINO",
}
_WRAPPER_BLOCKED_FAMILIES = {
    "pdearena::pdemodel",
    "pdearena::cond_pdemodel",
    "pdearena::pderefiner",
    "PDEBench::inverse",
}


@lru_cache(maxsize=1)
def _evidence_summary() -> dict[str, list[dict[str, object]]]:
    path = (
        Path(__file__).resolve().parents[2]
        / "artifacts"
        / "benchmark_model_inventory"
        / "external_model_executed_evidence_summary.json"
    )
    if not path.exists():
        return {}
    payload = json.loads(path.read_text(encoding="utf-8"))
    rows = payload.get("rows", [])
    grouped: dict[str, list[dict[str, object]]] = {}
    if not isinstance(rows, list):
        return grouped
    for row in rows:
        if not isinstance(row, dict) or not bool(row.get("succeeded")):
            continue
        grouped.setdefault(str(row["external_model_id"]), []).append(row)
    return grouped


def _has_nominal_bridge(record: ExternalModelRecord) -> bool:
    rows = _evidence_summary().get(record.external_model_id, [])
    tasks = {str(row.get("task_name")) for row in rows if row.get("evidence_kind") == "nominal_bridge"}
    return tasks >= {"allencahn1d", "burgers1d", "heat1d", "poisson2d"}


def _has_temporal_nominal_bridge(record: ExternalModelRecord) -> bool:
    rows = _evidence_summary().get(record.external_model_id, [])
    tasks = {str(row.get("task_name")) for row in rows if row.get("evidence_kind") == "temporal_nominal_bridge"}
    return tasks >= {"allencahn1d", "burgers1d", "heat1d"}


def _has_operator_nominal_bridge(record: ExternalModelRecord) -> bool:
    rows = _evidence_summary().get(record.external_model_id, [])
    return any(row.get("evidence_kind") == "operator_nominal_bridge" for row in rows)


def _make_record(
    record: ExternalModelRecord,
    *,
    nominal_anchor_status: str,
    inverse_core_status: str,
    sparse_extension_status: str,
    noisy_extension_status: str,
    joint_local_grid_status: str,
    transfer_expansion_status: str,
    reference_context_status: str,
    headline_eligibility: str,
    benchmark_scope: str,
    comparability_reason: str,
    blocking_reason: str,
    required_conditions: str,
    notes: str,
) -> ExternalModelComparabilityRecord:
    return ExternalModelComparabilityRecord(
        external_model_id=record.external_model_id,
        canonical_name=record.canonical_name,
        source_benchmark=record.source_benchmark,
        model_category=record.model_category,
        integration_state=record.integration_state,
        runnable_status=record.runnable_status,
        nominal_anchor_status=nominal_anchor_status,
        inverse_core_status=inverse_core_status,
        sparse_extension_status=sparse_extension_status,
        noisy_extension_status=noisy_extension_status,
        joint_local_grid_status=joint_local_grid_status,
        transfer_expansion_status=transfer_expansion_status,
        reference_context_status=reference_context_status,
        headline_eligibility=headline_eligibility,
        benchmark_scope=benchmark_scope,
        comparability_reason=comparability_reason,
        blocking_reason=blocking_reason,
        required_conditions=required_conditions,
        notes=notes,
    )


def _classify_record(record: ExternalModelRecord) -> ExternalModelComparabilityRecord:
    ext_id = record.external_model_id

    if ext_id in _DIRECT_POINTWISE_FAMILIES:
        if _has_nominal_bridge(record):
            return _make_record(
                record,
                nominal_anchor_status=STATUS_NOMINAL_ONLY,
                inverse_core_status=STATUS_RUNNABLE_NOT_YET,
                sparse_extension_status=STATUS_RUNNABLE_NOT_YET,
                noisy_extension_status=STATUS_RUNNABLE_NOT_YET,
                joint_local_grid_status=STATUS_BOUNDED,
                transfer_expansion_status=STATUS_APPENDIX,
                reference_context_status=STATUS_APPENDIX,
                headline_eligibility="nominal_bridge_ready_appendix_candidate",
                benchmark_scope="pointwise_pinn_nominal_bridge",
                comparability_reason=(
                    "This family now has executed nominal bridge evidence across the four anchor pointwise tasks under the external evidence push, so it can support a nominal-only comparison surface."
                ),
                blocking_reason=(
                    "inverse/sparse/noisy suite evidence still absent; benchmark rights remain limited to the nominal bridge"
                ),
                required_conditions=(
                    "promote from nominal-only to broader benchmark use only after inverse_core and focal sparse/noisy suite reruns under fixed budget"
                ),
                notes=record.notes,
            )
        return _make_record(
            record,
            nominal_anchor_status=STATUS_APPENDIX,
            inverse_core_status=STATUS_RUNNABLE_NOT_YET,
            sparse_extension_status=STATUS_RUNNABLE_NOT_YET,
            noisy_extension_status=STATUS_RUNNABLE_NOT_YET,
            joint_local_grid_status=STATUS_BOUNDED,
            transfer_expansion_status=STATUS_APPENDIX,
            reference_context_status=STATUS_APPENDIX,
            headline_eligibility="future_mainline_candidate_after_executed_suite_evidence",
            benchmark_scope="pointwise_pinn_mainline_candidate",
            comparability_reason=(
                "This family is semantically closest to the current pointwise PINN benchmark kernel and already has a runnable adapter path, "
                "but it has not yet been executed under the checked-in 2026 nominal/inverse/sparse/noisy suite surfaces."
            ),
            blocking_reason=(
                "insufficient_executed_evidence; budget_comparability_not_yet_demonstrated; no current suite-level figure/claim surface for this external identity"
            ),
            required_conditions=(
                "matched-budget nominal rerun under the canonical anchor shell; inverse_main_benchmark rerun with seed stability and physics pairing; "
                "focal sparse/noisy reruns under the same shell and budget contract"
            ),
            notes=record.notes,
        )

    if ext_id in _DECOMPOSITION_PROXY_FAMILIES:
        return _make_record(
            record,
            nominal_anchor_status=STATUS_APPENDIX,
            inverse_core_status=STATUS_APPENDIX,
            sparse_extension_status=STATUS_APPENDIX,
            noisy_extension_status=STATUS_APPENDIX,
            joint_local_grid_status=STATUS_BOUNDED,
            transfer_expansion_status=STATUS_APPENDIX,
            reference_context_status=STATUS_APPENDIX,
            headline_eligibility="bounded_support_only",
            benchmark_scope="decomposition_proxy_family",
            comparability_reason=(
                "This decomposition-style PINN family is relevant to the benchmark story, but the current runnable path is a native XPINN proxy rather than a benchmark-faithful external-runtime port."
            ),
            blocking_reason=(
                "insufficient_adapter_faithfulness; decomposition_budget_not_normalized; no executed 2026 suite evidence for the external identity itself"
            ),
            required_conditions=(
                "explicit decomposition budget contract; source-faithful reruns across nominal/inverse focal shells; proxy disclosure in any paper-facing comparison"
            ),
            notes=record.notes,
        )

    if ext_id in _FRAMEWORK_ONLY_FAMILIES:
        return _make_record(
            record,
            nominal_anchor_status=STATUS_REGISTRY_ONLY,
            inverse_core_status=STATUS_REGISTRY_ONLY,
            sparse_extension_status=STATUS_REGISTRY_ONLY,
            noisy_extension_status=STATUS_REGISTRY_ONLY,
            joint_local_grid_status=STATUS_REGISTRY_ONLY,
            transfer_expansion_status=STATUS_REGISTRY_ONLY,
            reference_context_status=STATUS_REGISTRY_ONLY,
            headline_eligibility="registry_presence_only",
            benchmark_scope="framework_identity_only",
            comparability_reason=(
                "This entry represents a framework/runtime family rather than one benchmark-comparable model identity."
            ),
            blocking_reason="family_abstract_not_directly_comparable",
            required_conditions="select a concrete architecture subtype and rerun it under one canonical benchmark protocol",
            notes=record.notes,
        )

    if ext_id in _TASK_CONSTRAINED_RUNNABLE_FAMILIES:
        if _has_temporal_nominal_bridge(record):
            return _make_record(
                record,
                nominal_anchor_status=STATUS_APPENDIX,
                inverse_core_status=STATUS_RUNNABLE_NOT_YET,
                sparse_extension_status=STATUS_RUNNABLE_NOT_YET,
                noisy_extension_status=STATUS_RUNNABLE_NOT_YET,
                joint_local_grid_status=STATUS_BOUNDED,
                transfer_expansion_status=STATUS_APPENDIX,
                reference_context_status=STATUS_APPENDIX,
                headline_eligibility="temporal_appendix_evidence_ready",
                benchmark_scope="temporal_pointwise_constraint_family",
                comparability_reason=(
                    "This task-coupled family now has executed temporal nominal bridge evidence on multiple temporal pointwise tasks, but it still does not cover the full nominal anchor or inverse-centered suite surfaces."
                ),
                blocking_reason=(
                    "task_shell_compatibility_limited; no inverse/sparse/noisy suite evidence; output-transform fidelity not yet benchmarked broadly"
                ),
                required_conditions=(
                    "extend evidence to inverse/sparse/noisy temporal shells and verify protocol comparability against unconstrained baselines"
                ),
                notes=record.notes,
            )
        return _make_record(
            record,
            nominal_anchor_status=STATUS_APPENDIX,
            inverse_core_status=STATUS_RUNNABLE_NOT_YET,
            sparse_extension_status=STATUS_RUNNABLE_NOT_YET,
            noisy_extension_status=STATUS_RUNNABLE_NOT_YET,
            joint_local_grid_status=STATUS_BOUNDED,
            transfer_expansion_status=STATUS_APPENDIX,
            reference_context_status=STATUS_APPENDIX,
            headline_eligibility="task_conditioned_appendix_candidate",
            benchmark_scope="temporal_pointwise_constraint_family",
            comparability_reason=(
                "The family is now runnable through a task-coupled output-transform hook and is relevant to temporal pointwise PINN evaluation, but it remains narrower than a benchmark-wide nominal or inverse comparison family."
            ),
            blocking_reason=(
                "task_shell_compatibility_limited; insufficient_executed_suite_evidence; output-transform fidelity not yet benchmarked across suites"
            ),
            required_conditions=(
                "demonstrate matched-budget temporal nominal bridge evidence; run inverse/sparse/noisy focal-shell evaluations on compatible temporal tasks; verify the constraint hook does not distort protocol comparability"
            ),
            notes=record.notes,
        )

    if ext_id in _TASK_HOOK_BLOCKED_FAMILIES:
        return _make_record(
            record,
            nominal_anchor_status=STATUS_BLOCKED,
            inverse_core_status=STATUS_BLOCKED,
            sparse_extension_status=STATUS_BLOCKED,
            noisy_extension_status=STATUS_BLOCKED,
            joint_local_grid_status=STATUS_BLOCKED,
            transfer_expansion_status=STATUS_BLOCKED,
            reference_context_status=STATUS_BLOCKED,
            headline_eligibility="blocked_until_runtime_hook_support",
            benchmark_scope="task_coupled_constraint_family",
            comparability_reason=(
                "The family could matter most on inverse- and boundary-sensitive surfaces, but it is not runnable without task-owned output-transform hooks."
            ),
            blocking_reason="runtime_semantics_mismatch; missing_output_transform_task_hook",
            required_conditions="formalize task-owned BC/IC output-transform hook; implement benchmark-faithful wrapper injection; produce executed suite evidence",
            notes=record.notes,
        )

    if ext_id in _VARIATIONAL_BLOCKED_FAMILIES:
        return _make_record(
            record,
            nominal_anchor_status=STATUS_BLOCKED,
            inverse_core_status=STATUS_BLOCKED,
            sparse_extension_status=STATUS_BLOCKED,
            noisy_extension_status=STATUS_BLOCKED,
            joint_local_grid_status=STATUS_BLOCKED,
            transfer_expansion_status=STATUS_BLOCKED,
            reference_context_status=STATUS_BLOCKED,
            headline_eligibility="blocked_until_variational_runtime_exists",
            benchmark_scope="variational_pinn_family",
            comparability_reason=(
                "This is a genuine PINN family with possible scientific value for the benchmark, but the current runtime does not expose its weak-form / quadrature semantics."
            ),
            blocking_reason="variational_runtime_missing; quadrature_semantics_not_supported",
            required_conditions="add weak-form task/runtime contract; add quadrature-aware training path; rerun on benchmark surfaces",
            notes=record.notes,
        )

    if ext_id in _SECOND_WAVE_OPERATOR_FAMILIES:
        if record.integration_state == "external_runnable" and _has_operator_nominal_bridge(record):
            return _make_record(
                record,
                nominal_anchor_status=STATUS_APPENDIX,
                inverse_core_status=STATUS_BLOCKED,
                sparse_extension_status=STATUS_BLOCKED,
                noisy_extension_status=STATUS_BLOCKED,
                joint_local_grid_status=STATUS_BLOCKED,
                transfer_expansion_status=STATUS_APPENDIX,
                reference_context_status=STATUS_APPENDIX,
                headline_eligibility="operator_appendix_evidence_ready",
                benchmark_scope="operator_nominal_appendix_branch",
                comparability_reason=(
                    "This operator family now has executed operator nominal bridge evidence, making it usable as appendix/operator-support evidence, but it still does not belong in the current pointwise inverse-centered mainline."
                ),
                blocking_reason="evaluation_surface_mismatch_with_current_mainline_story",
                required_conditions=(
                    "establish an operator-native matched-budget benchmark branch before claiming stronger comparability"
                ),
                notes=record.notes,
            )
        return _make_record(
            record,
            nominal_anchor_status=STATUS_BLOCKED,
            inverse_core_status=STATUS_BLOCKED,
            sparse_extension_status=STATUS_BLOCKED,
            noisy_extension_status=STATUS_BLOCKED,
            joint_local_grid_status=STATUS_BLOCKED,
            transfer_expansion_status=STATUS_BLOCKED,
            reference_context_status=STATUS_BLOCKED,
            headline_eligibility="future_operator_second_wave_only",
            benchmark_scope="operator_second_wave_family",
            comparability_reason=(
                "This family belongs to a future operator-native benchmark branch rather than the current pointwise inverse-centered 2026 story."
            ),
            blocking_reason="evaluation_surface_mismatch; no_benchmark_faithful_operator_runtime_in_current_story",
            required_conditions="establish an operator-native benchmark surface with matched budgets, fieldwise rollout claims, and benchmark-faithful family adapters",
            notes=record.notes,
        )

    if ext_id in _WRAPPER_BLOCKED_FAMILIES:
        return _make_record(
            record,
            nominal_anchor_status=STATUS_BLOCKED,
            inverse_core_status=STATUS_BLOCKED,
            sparse_extension_status=STATUS_BLOCKED,
            noisy_extension_status=STATUS_BLOCKED,
            joint_local_grid_status=STATUS_BLOCKED,
            transfer_expansion_status=STATUS_BLOCKED,
            reference_context_status=STATUS_BLOCKED,
            headline_eligibility="blocked",
            benchmark_scope="wrapper_or_heavy_runtime_surface",
            comparability_reason=(
                "This entry is a heavy wrapper/runtime surface rather than a clean external model family that can be benchmarked under the current PINNMark contracts."
            ),
            blocking_reason="wrapper_runtime_semantics_mismatch",
            required_conditions="factor a standalone comparable model identity out of the external runtime, or build a dedicated wrapper-aware benchmark line",
            notes=record.notes,
        )

    if record.integration_state == "external_registry_only":
        return _make_record(
            record,
            nominal_anchor_status=STATUS_REGISTRY_ONLY,
            inverse_core_status=STATUS_REGISTRY_ONLY,
            sparse_extension_status=STATUS_REGISTRY_ONLY,
            noisy_extension_status=STATUS_REGISTRY_ONLY,
            joint_local_grid_status=STATUS_REGISTRY_ONLY,
            transfer_expansion_status=STATUS_REGISTRY_ONLY,
            reference_context_status=STATUS_REGISTRY_ONLY,
            headline_eligibility="registry_presence_only",
            benchmark_scope="registry_only_family",
            comparability_reason=(
                "The family is cataloged and provenance-complete, but current integration depth is below the threshold needed for benchmark use."
            ),
            blocking_reason="adapter_unavailable_or_insufficient; no_executed_suite_evidence",
            required_conditions="promote to adapter-backed state, then rerun under one benchmark surface before any paper-facing comparison",
            notes=record.notes,
        )

    if record.integration_state == "external_blocked":
        return _make_record(
            record,
            nominal_anchor_status=STATUS_BLOCKED,
            inverse_core_status=STATUS_BLOCKED,
            sparse_extension_status=STATUS_BLOCKED,
            noisy_extension_status=STATUS_BLOCKED,
            joint_local_grid_status=STATUS_BLOCKED,
            transfer_expansion_status=STATUS_BLOCKED,
            reference_context_status=STATUS_BLOCKED,
            headline_eligibility="blocked",
            benchmark_scope="blocked_family",
            comparability_reason="The family is known to the registry but structurally blocked from fair benchmark use today.",
            blocking_reason="integration_blocked",
            required_conditions="remove the blocking runtime or semantic mismatch before revisiting comparability",
            notes=record.notes,
        )

    return _make_record(
        record,
        nominal_anchor_status=STATUS_REGISTRY_ONLY,
        inverse_core_status=STATUS_REGISTRY_ONLY,
        sparse_extension_status=STATUS_REGISTRY_ONLY,
        noisy_extension_status=STATUS_REGISTRY_ONLY,
        joint_local_grid_status=STATUS_REGISTRY_ONLY,
        transfer_expansion_status=STATUS_REGISTRY_ONLY,
        reference_context_status=STATUS_REGISTRY_ONLY,
        headline_eligibility="registry_presence_only",
        benchmark_scope="unclassified_external_family",
        comparability_reason="The family is cataloged but does not yet have a benchmark-use recommendation.",
        blocking_reason="unclassified",
        required_conditions="classify the family and execute it under one controlled benchmark surface",
        notes=record.notes,
    )


def list_external_model_comparability_records() -> list[ExternalModelComparabilityRecord]:
    """Return surface-aware comparability records for all external families."""
    return [_classify_record(record) for record in list_external_model_records()]


def query_external_model_comparability(
    *,
    surface: str | None = None,
    status: str | None = None,
    headline_only: bool = False,
) -> list[ExternalModelComparabilityRecord]:
    """Filter comparability records by one surface/status pair or headline eligibility."""
    rows = list_external_model_comparability_records()
    if headline_only:
        rows = [row for row in rows if row.headline_eligibility not in {"registry_presence_only", "blocked", "blocked_until_runtime_hook_support", "blocked_until_variational_runtime_exists"}]
    if surface is not None and status is not None:
        rows = [row for row in rows if row.surface_status(surface) == status]
    return rows


def list_operator_appendix_branch_records() -> list[ExternalModelComparabilityRecord]:
    """Return the operator-family records relevant to the appendix branch."""
    return [
        row
        for row in list_external_model_comparability_records()
        if row.external_model_id in (_OPERATOR_APPENDIX_INCLUDED | _OPERATOR_APPENDIX_ASSESSED_ONLY)
    ]


__all__ = [
    "ExternalModelComparabilityRecord",
    "STATUS_APPENDIX",
    "STATUS_BLOCKED",
    "STATUS_BOUNDED",
    "STATUS_INVERSE_CORE",
    "STATUS_MAINLINE",
    "STATUS_NOMINAL_ONLY",
    "STATUS_REGISTRY_ONLY",
    "STATUS_RUNNABLE_NOT_YET",
    "SURFACES",
    "list_operator_appendix_branch_records",
    "list_external_model_comparability_records",
    "query_external_model_comparability",
]
