"""Model implementations and registrations."""

from pinn_bench.models.adaptive_mlp import AdaptiveMLP
from pinn_bench.models.advanced_methods import (
    CausalSweepingPINNModel,
    HPVariationalPINNModel,
    PIDeepONetOperatorModel,
    PIDIONOperatorModel,
    PIGANOOperatorModel,
    PIANNModel,
    PINNsFormerModel,
    PINOOperatorModel,
    PirateNetsModel,
    SAPINNModel,
    SPINNModel,
    VINOOperatorModel,
    VariationalPINNModel,
)
from pinn_bench.models.bayesian_mlp import BayesianMLP
from pinn_bench.models.base import BaseModel, BaseOperatorModel
from pinn_bench.models.grid_mlp import GridMLP
from pinn_bench.models.kan import KAN, KANLinear, KanModel
from pinn_bench.models.mlp import MLP
from pinn_bench.models.mini_fno import MiniFNO
from pinn_bench.models.multifidelity_mlp import MultiFidelityMLP
from pinn_bench.models.siren import SIREN, SirenModel, SineLayer
from pinn_bench.models.spectral_mlp import SpectralMLP
from pinn_bench.models.xpinn_mlp import XPINNMLP

__all__ = [
    "AdaptiveMLP",
    "CausalSweepingPINNModel",
    "BayesianMLP",
    "BaseModel",
    "BaseOperatorModel",
    "GridMLP",
    "HPVariationalPINNModel",
    "SpectralMLP",
    "MiniFNO",
    "MultiFidelityMLP",
    "MLP",
    "KAN",
    "KANLinear",
    "KanModel",
    "SIREN",
    "SineLayer",
    "SirenModel",
    "PIGANOOperatorModel",
    "PIDIONOperatorModel",
    "PIDeepONetOperatorModel",
    "PIANNModel",
    "PINNsFormerModel",
    "PINOOperatorModel",
    "PirateNetsModel",
    "SAPINNModel",
    "SPINNModel",
    "VINOOperatorModel",
    "VariationalPINNModel",
    "XPINNMLP",
]
