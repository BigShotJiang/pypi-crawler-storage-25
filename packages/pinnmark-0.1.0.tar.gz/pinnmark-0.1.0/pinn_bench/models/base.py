"""Base interfaces for benchmark models."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

import torch
from torch import nn


class BaseModel(nn.Module, ABC):
    """Common interface for pointwise benchmark models."""

    model_mode = "pointwise"
    supports_flattened_field = False

    @abstractmethod
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Run forward pass."""


class BaseOperatorModel(nn.Module, ABC):
    """Parallel contract for operator-ready field models."""

    model_mode = "field"
    supports_flattened_field = False

    @abstractmethod
    def forward_field(
        self,
        condition_inputs: torch.Tensor | None,
        query_inputs: torch.Tensor | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> torch.Tensor:
        """Predict a flattened field from condition/query inputs."""
